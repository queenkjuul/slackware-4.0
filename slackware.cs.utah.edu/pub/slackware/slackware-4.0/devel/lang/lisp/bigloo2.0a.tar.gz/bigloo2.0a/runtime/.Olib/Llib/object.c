/*===========================================================================*/
/*   (Llib/object.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>


/* Object type definitions */

static obj_t _class_hash_144___object(obj_t, obj_t);
static obj_t _add_generic_1555_154___object(obj_t, obj_t, obj_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t object_write_132___object(object_t, obj_t);
static obj_t method_init_76___object();
extern obj_t string_to_symbol(char *);
extern obj_t current_output_port;
static obj_t object_display_default1017_64___object(object_t, obj_t);
static obj_t _object_display1567_135___object(obj_t, obj_t, obj_t);
static obj_t _class__187___object(obj_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _object_equal_1566_89___object(obj_t, obj_t, obj_t);
static obj_t _class_subclasses_86___object(obj_t, obj_t);
static obj_t extend_vector_160___object(obj_t, obj_t, long);
static obj_t _object__148___object(obj_t, obj_t);
static obj_t _object_write_default1018_31___object(obj_t, obj_t, obj_t);
static obj_t _next_class_num1562_170___object(obj_t, obj_t);
static obj_t _class_fields__244___object(obj_t, obj_t);
static obj_t _class_field_len_accessor_58___object(obj_t, obj_t);
static obj_t _object__struct1569_129___object(obj_t, obj_t);
static obj_t _generics__29___object = BUNSPEC;
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t class_fields_215___object(obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t class_subclasses_99___object(obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern bool_t class_field_mutable__211___object(obj_t);
extern bool_t object__44___object(obj_t);
static obj_t _wide_object_1565_204___object(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _object_class1548_155___object(obj_t, obj_t);
extern object_t allocate_instance_244___object(obj_t);
static obj_t object__struct_default1019_241___object(object_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _generic_pre_method1551_28___object(obj_t, obj_t);
static obj_t object_write_default1018_79___object(object_t, obj_t);
static obj_t _generic_default1549_158___object(obj_t, obj_t);
extern obj_t object_class_242___object(object_t);
extern obj_t module_initialization_70___object(long, char *);
static obj_t _class_constructor_88___object(obj_t, obj_t);
static obj_t _find_super_class_method1560_155___object(obj_t, obj_t, obj_t, obj_t);
extern obj_t find_runtime_type_96___error(obj_t);
static obj_t _class_field_name_107___object(obj_t, obj_t);
static object_t struct_object__object_default1020_163___object(object_t, obj_t);
extern obj_t class_field_len_accessor_212___object(obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _add_inlined_method_1557_204___object(obj_t, obj_t, obj_t, obj_t);
extern obj_t class_constructor_163___object(obj_t);
extern long list_length(obj_t);
extern long class_num_218___object(obj_t);
static obj_t _object_class_num1546_73___object(obj_t, obj_t);
extern obj_t method_array_ref_188___object(obj_t, long);
static obj_t _nb_generics_max__185___object = BUNSPEC;
static obj_t object_write_display_42___object(object_t, obj_t, bool_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
extern bool_t wide_object__208___object(object_t);
static obj_t _struct_object__object_default1020_71___object(obj_t, obj_t, obj_t);
static obj_t _add_method_1556_144___object(obj_t, obj_t, obj_t, obj_t);
extern obj_t class_field_name_28___object(obj_t);
static obj_t _nb_generics__142___object = BUNSPEC;
static obj_t _find_method_from1561_159___object(obj_t, obj_t, obj_t, obj_t);
extern object_t allocate_object_214___object();
static obj_t _class_fields_252___object(obj_t, obj_t);
extern bool_t object_equal__12___object(object_t, object_t);
static obj_t _generic_method_array1550_197___object(obj_t, obj_t);
static obj_t _class_field_accessor_230___object(obj_t, obj_t);
static obj_t double_nb_generics__239___object();
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t initialize_objects__138___object();
extern obj_t object_class_num_set__124___object(obj_t, long);
extern long object_class_num_83___object(object_t);
static obj_t _struct_object__object1570_9___object(obj_t, obj_t, obj_t);
static obj_t _method_array_ref1553_55___object(obj_t, obj_t, obj_t);
static obj_t _class_field_indexed__52___object(obj_t, obj_t);
extern obj_t find_inline_method_206___object(object_t, obj_t);
extern obj_t generic_pre_method_set__80___object(obj_t, obj_t);
static obj_t add_method_proc_or_num__68___object(obj_t, obj_t, obj_t);
static obj_t _nb_classes__240___object = BUNSPEC;
static obj_t _allocate_instance1564_134___object(obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern bool_t class_fields__63___object(obj_t);
static obj_t toplevel_init_63___object();
extern object_t struct__object_175___object(obj_t);
extern obj_t create_vector(long);
extern obj_t class_name_139___object(obj_t);
extern long next_class_num_45___object(long);
static obj_t _allocate_object_100___object(obj_t);
static obj_t symbol3415___object = BUNSPEC;
static obj_t _make_object_124___object(obj_t);
static obj_t symbol3412___object = BUNSPEC;
static obj_t symbol3411___object = BUNSPEC;
static obj_t symbol3399___object = BUNSPEC;
static obj_t symbol3410___object = BUNSPEC;
static obj_t symbol3398___object = BUNSPEC;
static obj_t symbol3408___object = BUNSPEC;
static obj_t symbol3407___object = BUNSPEC;
static obj_t symbol3396___object = BUNSPEC;
static obj_t symbol3395___object = BUNSPEC;
static obj_t symbol3404___object = BUNSPEC;
static obj_t symbol3403___object = BUNSPEC;
static obj_t symbol3392___object = BUNSPEC;
static obj_t symbol3391___object = BUNSPEC;
static obj_t symbol3389___object = BUNSPEC;
static obj_t symbol3390___object = BUNSPEC;
static obj_t symbol3400___object = BUNSPEC;
static obj_t symbol3386___object = BUNSPEC;
static obj_t symbol3382___object = BUNSPEC;
static obj_t symbol3378___object = BUNSPEC;
static obj_t symbol3376___object = BUNSPEC;
static obj_t symbol3369___object = BUNSPEC;
static obj_t symbol3367___object = BUNSPEC;
static obj_t symbol3363___object = BUNSPEC;
static obj_t symbol3359___object = BUNSPEC;
static obj_t symbol3357___object = BUNSPEC;
static obj_t symbol3356___object = BUNSPEC;
static obj_t symbol3355___object = BUNSPEC;
static obj_t symbol3354___object = BUNSPEC;
static obj_t symbol3351___object = BUNSPEC;
extern long class_hash_237___object(obj_t);
static obj_t symbol3347___object = BUNSPEC;
static obj_t symbol3343___object = BUNSPEC;
static obj_t symbol3342___object = BUNSPEC;
static obj_t symbol3340___object = BUNSPEC;
static obj_t symbol3335___object = BUNSPEC;
static obj_t symbol3333___object = BUNSPEC;
static obj_t symbol3331___object = BUNSPEC;
static obj_t symbol3329___object = BUNSPEC;
static obj_t symbol3327___object = BUNSPEC;
static obj_t symbol3326___object = BUNSPEC;
static obj_t symbol3322___object = BUNSPEC;
static obj_t symbol3319___object = BUNSPEC;
static obj_t symbol3317___object = BUNSPEC;
static obj_t symbol3316___object = BUNSPEC;
static obj_t symbol3313___object = BUNSPEC;
extern obj_t find_method_204___object(object_t, obj_t);
static obj_t symbol3312___object = BUNSPEC;
static obj_t symbol3311___object = BUNSPEC;
static obj_t symbol3309___object = BUNSPEC;
static obj_t symbol3310___object = BUNSPEC;
static obj_t symbol3308___object = BUNSPEC;
static obj_t symbol3297___object = BUNSPEC;
static obj_t symbol3307___object = BUNSPEC;
static obj_t symbol3293___object = BUNSPEC;
static obj_t symbol3292___object = BUNSPEC;
static obj_t symbol3302___object = BUNSPEC;
static obj_t symbol3289___object = BUNSPEC;
static obj_t symbol3290___object = BUNSPEC;
static obj_t symbol3300___object = BUNSPEC;
static obj_t symbol3285___object = BUNSPEC;
static obj_t symbol3284___object = BUNSPEC;
static obj_t symbol3283___object = BUNSPEC;
static obj_t symbol3282___object = BUNSPEC;
static obj_t symbol3281___object = BUNSPEC;
static obj_t symbol3280___object = BUNSPEC;
static obj_t symbol3275___object = BUNSPEC;
static obj_t symbol3273___object = BUNSPEC;
static obj_t symbol3272___object = BUNSPEC;
static obj_t symbol3271___object = BUNSPEC;
static obj_t symbol3269___object = BUNSPEC;
static obj_t symbol3270___object = BUNSPEC;
static obj_t symbol3268___object = BUNSPEC;
static obj_t symbol3267___object = BUNSPEC;
obj_t object___object = BUNSPEC;
static obj_t symbol3266___object = BUNSPEC;
static obj_t symbol3265___object = BUNSPEC;
static obj_t symbol3264___object = BUNSPEC;
static obj_t symbol3263___object = BUNSPEC;
static obj_t symbol3262___object = BUNSPEC;
static obj_t symbol3261___object = BUNSPEC;
static obj_t symbol3259___object = BUNSPEC;
static obj_t symbol3260___object = BUNSPEC;
static obj_t symbol3255___object = BUNSPEC;
static obj_t list3409___object = BUNSPEC;
static obj_t list3397___object = BUNSPEC;
static obj_t symbol3251___object = BUNSPEC;
static obj_t list3406___object = BUNSPEC;
static obj_t symbol3250___object = BUNSPEC;
static obj_t list3394___object = BUNSPEC;
static obj_t symbol3247___object = BUNSPEC;
static obj_t symbol3245___object = BUNSPEC;
static obj_t symbol3244___object = BUNSPEC;
static obj_t list3388___object = BUNSPEC;
static obj_t list3387___object = BUNSPEC;
static obj_t symbol3239___object = BUNSPEC;
static obj_t symbol3240___object = BUNSPEC;
static obj_t list3385___object = BUNSPEC;
static obj_t symbol3238___object = BUNSPEC;
static obj_t list3384___object = BUNSPEC;
static obj_t symbol3237___object = BUNSPEC;
static obj_t list3383___object = BUNSPEC;
static obj_t symbol3236___object = BUNSPEC;
static obj_t symbol3235___object = BUNSPEC;
static obj_t list3381___object = BUNSPEC;
static obj_t symbol3234___object = BUNSPEC;
static obj_t list3379___object = BUNSPEC;
static obj_t list3380___object = BUNSPEC;
static obj_t symbol3233___object = BUNSPEC;
static obj_t symbol3232___object = BUNSPEC;
static obj_t list3377___object = BUNSPEC;
static obj_t symbol3231___object = BUNSPEC;
static obj_t symbol3229___object = BUNSPEC;
static obj_t symbol3230___object = BUNSPEC;
static obj_t list3375___object = BUNSPEC;
static obj_t symbol3228___object = BUNSPEC;
static obj_t list3374___object = BUNSPEC;
static obj_t symbol3227___object = BUNSPEC;
static obj_t list3373___object = BUNSPEC;
static obj_t symbol3226___object = BUNSPEC;
static obj_t list3372___object = BUNSPEC;
static obj_t list3371___object = BUNSPEC;
static obj_t symbol3224___object = BUNSPEC;
static obj_t list3370___object = BUNSPEC;
static obj_t _is_a__25___object(obj_t, obj_t, obj_t);
static obj_t symbol3223___object = BUNSPEC;
static obj_t list3368___object = BUNSPEC;
static obj_t symbol3222___object = BUNSPEC;
static obj_t symbol3221___object = BUNSPEC;
static obj_t list3366___object = BUNSPEC;
static obj_t symbol3219___object = BUNSPEC;
static obj_t symbol3220___object = BUNSPEC;
static obj_t list3365___object = BUNSPEC;
static obj_t symbol3218___object = BUNSPEC;
static obj_t list3364___object = BUNSPEC;
static obj_t symbol3217___object = BUNSPEC;
static obj_t symbol3216___object = BUNSPEC;
static obj_t list3362___object = BUNSPEC;
static obj_t symbol3215___object = BUNSPEC;
static obj_t list3361___object = BUNSPEC;
static obj_t symbol3214___object = BUNSPEC;
static obj_t list3360___object = BUNSPEC;
static obj_t symbol3213___object = BUNSPEC;
static obj_t list3358___object = BUNSPEC;
static obj_t symbol3212___object = BUNSPEC;
static obj_t symbol3211___object = BUNSPEC;
static obj_t symbol3210___object = BUNSPEC;
static obj_t symbol3198___object = BUNSPEC;
static obj_t symbol3208___object = BUNSPEC;
static obj_t symbol3207___object = BUNSPEC;
static obj_t list3353___object = BUNSPEC;
static obj_t symbol3206___object = BUNSPEC;
static obj_t list3352___object = BUNSPEC;
static obj_t symbol3205___object = BUNSPEC;
static obj_t list3349___object = BUNSPEC;
static obj_t list3350___object = BUNSPEC;
static obj_t list3348___object = BUNSPEC;
static obj_t symbol3192___object = BUNSPEC;
static obj_t symbol3201___object = BUNSPEC;
static obj_t list3346___object = BUNSPEC;
static obj_t symbol3189___object = BUNSPEC;
static obj_t symbol3200___object = BUNSPEC;
static obj_t list3345___object = BUNSPEC;
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol3188___object = BUNSPEC;
static obj_t list3344___object = BUNSPEC;
static obj_t list3341___object = BUNSPEC;
static obj_t list3339___object = BUNSPEC;
static obj_t list3338___object = BUNSPEC;
static obj_t list3337___object = BUNSPEC;
static obj_t list3336___object = BUNSPEC;
static obj_t list3334___object = BUNSPEC;
static obj_t list3332___object = BUNSPEC;
static obj_t list3330___object = BUNSPEC;
static obj_t list3328___object = BUNSPEC;
static obj_t list3325___object = BUNSPEC;
static obj_t list3324___object = BUNSPEC;
static obj_t list3323___object = BUNSPEC;
static obj_t list3321___object = BUNSPEC;
static obj_t list3320___object = BUNSPEC;
static obj_t list3318___object = BUNSPEC;
static obj_t list3315___object = BUNSPEC;
static obj_t list3299___object = BUNSPEC;
static obj_t list3306___object = BUNSPEC;
static obj_t list3305___object = BUNSPEC;
static obj_t list3294___object = BUNSPEC;
static obj_t list3304___object = BUNSPEC;
static obj_t list3303___object = BUNSPEC;
static obj_t list3291___object = BUNSPEC;
static obj_t list3301___object = BUNSPEC;
static obj_t loop___object(obj_t, obj_t, obj_t, obj_t);
static obj_t list3288___object = BUNSPEC;
static obj_t list3279___object = BUNSPEC;
extern obj_t bigloo_type_error_msg_127___error(obj_t, obj_t, obj_t);
static obj_t lambda1074___object(obj_t, obj_t);
static obj_t _class_num_205___object(obj_t, obj_t);
static obj_t _class_depth_246___object(obj_t, obj_t);
extern obj_t class_field_accessor_18___object(obj_t);
static obj_t _class_field_mutator_181___object(obj_t, obj_t);
extern object_t make_object_188___object();
static obj_t _generic_pre_method_set_1552_229___object(obj_t, obj_t, obj_t);
extern obj_t object_display_243___object(object_t, obj_t);
static obj_t _object_display_default1017_129___object(obj_t, obj_t, obj_t);
static obj_t double_nb_classes__118___object();
static obj_t _find_method1558_180___object(obj_t, obj_t, obj_t);
static obj_t _add_class_1554_219___object(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t class_field_indexed__189___object(obj_t);
static obj_t object_init_111___object();
extern long class_depth_60___object(obj_t);
static obj_t _struct__object1563_129___object(obj_t, obj_t);
static obj_t _find_inline_method1559_78___object(obj_t, obj_t, obj_t);
obj_t _classes__134___object = BUNSPEC;
extern obj_t generic_pre_method_24___object(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _class_super_213___object(obj_t, obj_t);
static obj_t _object_class_num_set_1547_94___object(obj_t, obj_t, obj_t);
static obj_t _nb_classes_max__8___object = BUNSPEC;
static obj_t generics_add_class__12___object(long, long);
static obj_t _object_write1568_82___object(obj_t, obj_t, obj_t);
extern obj_t find_method_from_44___object(object_t, obj_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
static obj_t _class_name_50___object(obj_t, obj_t);
extern obj_t generic_default_171___object(obj_t);
static obj_t require_initialization_114___object = BUNSPEC;
static obj_t _class_field_mutable__51___object(obj_t, obj_t);
extern bool_t class__60___object(obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t cnst_init_137___object();
static obj_t _object__struct_default1019_206___object(obj_t, obj_t);
extern obj_t generic_method_array_21___object(obj_t);
extern obj_t class_field_mutator_255___object(obj_t);
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE( proc3246___object, lambda1074___object3440, va_generic_entry, lambda1074___object, -1 );
DEFINE_EXPORT_PROCEDURE( find_method_from_env_43___object, _find_method_from1561_159___object3441, _find_method_from1561_159___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( find_super_class_method_env_187___object, _find_super_class_method1560_155___object3442, _find_super_class_method1560_155___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( class_field_mutable__env_219___object, _class_field_mutable__51___object3443, _class_field_mutable__51___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( generic_pre_method_env_6___object, _generic_pre_method1551_28___object3444, _generic_pre_method1551_28___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_constructor_env_255___object, _class_constructor_88___object3445, _class_constructor_88___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( method_array_ref_env_14___object, _method_array_ref1553_55___object3446, _method_array_ref1553_55___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( object__env_43___object, _object__148___object3447, _object__148___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( add_inlined_method__env_212___object, _add_inlined_method_1557_204___object3448, _add_inlined_method_1557_204___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( allocate_object_env_103___object, _allocate_object_100___object3449, _allocate_object_100___object, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( class_super_env_1___object, _class_super_213___object3450, _class_super_213___object, 0L, 1 );
DEFINE_STATIC_PROCEDURE( struct_object__object_default1020_env_255___object, _struct_object__object_default1020_71___object3451, _struct_object__object_default1020_71___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( class_depth_env_46___object, _class_depth_246___object3452, _class_depth_246___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( is_a__env_220___object, _is_a__25___object3453, _is_a__25___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( allocate_instance_env_212___object, _allocate_instance1564_134___object3454, _allocate_instance1564_134___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_num_env_12___object, _class_num_205___object3455, _class_num_205___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( add_class__env_135___object, _add_class_1554_219___object3456, _add_class_1554_219___object, 0L, 6 );
DEFINE_EXPORT_GENERIC( struct_object__object_env_209___object, _struct_object__object1570_9___object3457, _struct_object__object1570_9___object, 0L, 2 );
DEFINE_STATIC_PROCEDURE( object_display_default1017_env_41___object, _object_display_default1017_129___object3458, va_generic_entry, _object_display_default1017_129___object, -2 );
DEFINE_EXPORT_PROCEDURE( class_fields_env_167___object, _class_fields_252___object3459, _class_fields_252___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_object_env_14___object, _make_object_124___object3460, _make_object_124___object, 0L, 0 );
DEFINE_EXPORT_GENERIC( object_write_env_104___object, _object_write1568_82___object3461, va_generic_entry, _object_write1568_82___object, -2 );
DEFINE_EXPORT_PROCEDURE( class_subclasses_env_184___object, _class_subclasses_86___object3462, _class_subclasses_86___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( add_generic__env_128___object, _add_generic_1555_154___object3463, _add_generic_1555_154___object, 0L, 2 );
DEFINE_STATIC_PROCEDURE( object_write_default1018_env_141___object, _object_write_default1018_31___object3464, va_generic_entry, _object_write_default1018_31___object, -2 );
DEFINE_EXPORT_PROCEDURE( object_equal__env_74___object, _object_equal_1566_89___object3465, _object_equal_1566_89___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( generic_pre_method_set__env_134___object, _generic_pre_method_set_1552_229___object3466, _generic_pre_method_set_1552_229___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( class_field_indexed__env_214___object, _class_field_indexed__52___object3467, _class_field_indexed__52___object, 0L, 1 );
DEFINE_STATIC_PROCEDURE( object__struct_default1019_env_180___object, _object__struct_default1019_206___object3468, _object__struct_default1019_206___object, 0L, 1 );
DEFINE_STRING( string3414___object, string3414___object3469, "This structure can't be converted", 33 );
DEFINE_STRING( string3413___object, string3413___object3470, "struct+object->object", 21 );
DEFINE_EXPORT_PROCEDURE( add_method__env_233___object, _add_method_1556_144___object3471, _add_method_1556_144___object, 0L, 3 );
DEFINE_STRING( string3405___object, string3405___object3472, "STRUCT+OBJECT->OBJECT:Wrong number of arguments", 47 );
DEFINE_STRING( string3393___object, string3393___object3473, "OBJECT->STRUCT:Wrong number of arguments", 40 );
DEFINE_STRING( string3402___object, string3402___object3474, "This object can't be converted", 30 );
DEFINE_STRING( string3401___object, string3401___object3475, "object->struct", 14 );
DEFINE_STRING( string3314___object, string3314___object3476, "Wrong number of arguments", 25 );
DEFINE_STRING( string3298___object, string3298___object3477, "OBJECT-EQUAL?:Wrong number of arguments", 39 );
DEFINE_STRING( string3296___object, string3296___object3478, "...", 3 );
DEFINE_STRING( string3295___object, string3295___object3479, "#|", 2 );
DEFINE_STRING( string3287___object, string3287___object3480, "OBJECT-WRITE/DISPLAY:Wrong number of arguments", 46 );
DEFINE_STRING( string3286___object, string3286___object3481, " [", 2 );
DEFINE_STRING( string3278___object, string3278___object3482, "ALLOCATE-INSTANCE:Wrong number of arguments", 43 );
DEFINE_STRING( string3277___object, string3277___object3483, "Can't find class", 16 );
DEFINE_STRING( string3276___object, string3276___object3484, "allocate-instance", 17 );
DEFINE_STRING( string3274___object, string3274___object3485, "STRUCT", 6 );
DEFINE_STRING( string3258___object, string3258___object3486, "Illegal class", 13 );
DEFINE_STRING( string3257___object, string3257___object3487, "arity mismatch", 14 );
DEFINE_STRING( string3256___object, string3256___object3488, "add-method!", 11 );
DEFINE_STRING( string3254___object, string3254___object3489, "argument not a list", 19 );
DEFINE_STRING( string3253___object, string3253___object3490, "for-each", 8 );
DEFINE_EXPORT_PROCEDURE( class__env_46___object, _class__187___object3491, _class__187___object, 0L, 1 );
DEFINE_STRING( string3252___object, string3252___object3492, "PAIR", 4 );
DEFINE_STRING( string3249___object, string3249___object3493, "No default behaviour", 20 );
DEFINE_STRING( string3248___object, string3248___object3494, "generic", 7 );
DEFINE_STRING( string3243___object, string3243___object3495, "vector-set!", 11 );
DEFINE_STRING( string3242___object, string3242___object3496, "Illegal super class for class", 29 );
DEFINE_STRING( string3241___object, string3241___object3497, "add-class!", 10 );
DEFINE_STRING( string3225___object, string3225___object3498, "OBJECT", 6 );
DEFINE_STRING( string3199___object, string3199___object3499, "LONG", 4 );
DEFINE_STRING( string3209___object, string3209___object3500, "PROCEDURE", 9 );
DEFINE_STRING( string3197___object, string3197___object3501, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string3196___object, string3196___object3502, "index out of range", 18 );
DEFINE_STRING( string3195___object, string3195___object3503, "vector-ref", 10 );
DEFINE_STRING( string3194___object, string3194___object3504, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/vector.scm", 59 );
DEFINE_STRING( string3204___object, string3204___object3505, "class-fields", 12 );
DEFINE_STRING( string3193___object, string3193___object3506, "SYMBOL", 6 );
DEFINE_STRING( string3203___object, string3203___object3507, "Class", 5 );
DEFINE_STRING( string3202___object, string3202___object3508, "runtime type error", 18 );
DEFINE_STRING( string3191___object, string3191___object3509, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/object.scm", 59 );
DEFINE_STRING( string3190___object, string3190___object3510, "VECTOR", 6 );
DEFINE_EXPORT_PROCEDURE( struct__object_env_176___object, _struct__object1563_129___object3511, _struct__object1563_129___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_hash_env_30___object, _class_hash_144___object3512, _class_hash_144___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_name_env_116___object, _class_name_50___object3513, _class_name_50___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( find_inline_method_env_227___object, _find_inline_method1559_78___object3514, _find_inline_method1559_78___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( wide_object__env_54___object, _wide_object_1565_204___object3515, _wide_object_1565_204___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( object_class_env_200___object, _object_class1548_155___object3516, _object_class1548_155___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( object_class_num_set__env_55___object, _object_class_num_set_1547_94___object3517, _object_class_num_set_1547_94___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( class_field_accessor_env_90___object, _class_field_accessor_230___object3518, _class_field_accessor_230___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_fields__env_111___object, _class_fields__244___object3519, _class_fields__244___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_field_name_env_131___object, _class_field_name_107___object3520, _class_field_name_107___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_field_len_accessor_env_145___object, _class_field_len_accessor_58___object3521, _class_field_len_accessor_58___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( generic_default_env_115___object, _generic_default1549_158___object3522, _generic_default1549_158___object, 0L, 1 );
DEFINE_EXPORT_GENERIC( object_display_env_20___object, _object_display1567_135___object3523, va_generic_entry, _object_display1567_135___object, -2 );
DEFINE_EXPORT_PROCEDURE( find_method_env_236___object, _find_method1558_180___object3524, _find_method1558_180___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( next_class_num_env_125___object, _next_class_num1562_170___object3525, _next_class_num1562_170___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( generic_method_array_env_123___object, _generic_method_array1550_197___object3526, _generic_method_array1550_197___object, 0L, 1 );
DEFINE_EXPORT_GENERIC( object__struct_env_210___object, _object__struct1569_129___object3527, _object__struct1569_129___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( object_class_num_env_245___object, _object_class_num1546_73___object3528, _object_class_num1546_73___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_field_mutator_env_194___object, _class_field_mutator_181___object3529, _class_field_mutator_181___object, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___object(long checksum_3858, char * from_3859)
{
if(CBOOL(require_initialization_114___object)){
require_initialization_114___object = BBOOL(((bool_t)0));
cnst_init_137___object();
object_init_111___object();
method_init_76___object();
toplevel_init_63___object();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___object()
{
symbol3188___object = string_to_symbol("TOPLEVEL-INIT");
symbol3189___object = string_to_symbol("CLASS?");
symbol3192___object = string_to_symbol("CLASS-NAME");
symbol3198___object = string_to_symbol("CLASS-NUM");
symbol3200___object = string_to_symbol("CLASS-DEPTH");
symbol3201___object = string_to_symbol("CLASS-FIELDS");
symbol3205___object = string_to_symbol("CLASS-FIELDS?");
symbol3206___object = string_to_symbol("CLASS-FIELD-NAME");
symbol3207___object = string_to_symbol("CLASS-FIELD-INDEXED?");
symbol3208___object = string_to_symbol("CLASS-FIELD-ACCESSOR");
symbol3210___object = string_to_symbol("CLASS-FIELD-MUTABLE?");
symbol3211___object = string_to_symbol("CLASS-FIELD-MUTATOR");
symbol3212___object = string_to_symbol("CLASS-FIELD-LEN-ACCESSOR");
symbol3213___object = string_to_symbol("CLASS-SUPER");
symbol3214___object = string_to_symbol("CLASS-SUBCLASSES");
symbol3215___object = string_to_symbol("CLASS-HASH");
symbol3216___object = string_to_symbol("CLASS-CONSTRUCTOR");
symbol3217___object = string_to_symbol("INITIALIZE-OBJECTS!");
symbol3218___object = string_to_symbol("DONE");
symbol3219___object = string_to_symbol("EXTEND-VECTOR");
symbol3220___object = string_to_symbol("DOUBLE-NB-CLASSES!");
symbol3221___object = string_to_symbol("DOUBLE-NB-GENERICS!");
symbol3222___object = string_to_symbol("OBJECT?");
symbol3223___object = string_to_symbol("OBJECT-CLASS-NUM");
symbol3224___object = string_to_symbol("_OBJECT-CLASS-NUM1546");
symbol3226___object = string_to_symbol("OBJECT-CLASS-NUM-SET!");
symbol3227___object = string_to_symbol("_OBJECT-CLASS-NUM-SET!1547");
symbol3228___object = string_to_symbol("OBJECT-CLASS");
symbol3229___object = string_to_symbol("_OBJECT-CLASS1548");
symbol3230___object = string_to_symbol("GENERIC-DEFAULT");
symbol3231___object = string_to_symbol("_GENERIC-DEFAULT1549");
symbol3232___object = string_to_symbol("GENERIC-METHOD-ARRAY");
symbol3233___object = string_to_symbol("_GENERIC-METHOD-ARRAY1550");
symbol3234___object = string_to_symbol("GENERIC-PRE-METHOD");
symbol3235___object = string_to_symbol("_GENERIC-PRE-METHOD1551");
symbol3236___object = string_to_symbol("GENERIC-PRE-METHOD-SET!");
symbol3237___object = string_to_symbol("_GENERIC-PRE-METHOD-SET!1552");
symbol3238___object = string_to_symbol("_METHOD-ARRAY-REF1553");
symbol3239___object = string_to_symbol("GENERICS-ADD-CLASS!");
symbol3240___object = string_to_symbol("ADD-CLASS!");
symbol3244___object = string_to_symbol("_ADD-CLASS!1554");
symbol3245___object = string_to_symbol("ADD-GENERIC!");
symbol3247___object = string_to_symbol("_ADD-GENERIC!1555");
symbol3250___object = string_to_symbol("ADD-METHOD/PROC-OR-NUM!");
symbol3251___object = string_to_symbol("LOOP");
symbol3255___object = string_to_symbol("ADD-METHOD!");
symbol3259___object = string_to_symbol("_ADD-METHOD!1556");
symbol3260___object = string_to_symbol("ADD-INLINED-METHOD!");
symbol3261___object = string_to_symbol("_ADD-INLINED-METHOD!1557");
symbol3262___object = string_to_symbol("FIND-METHOD");
symbol3263___object = string_to_symbol("_FIND-METHOD1558");
symbol3264___object = string_to_symbol("FIND-INLINE-METHOD");
symbol3265___object = string_to_symbol("_FIND-INLINE-METHOD1559");
symbol3266___object = string_to_symbol("FIND-SUPER-CLASS-METHOD");
symbol3267___object = string_to_symbol("_FIND-SUPER-CLASS-METHOD1560");
symbol3268___object = string_to_symbol("FIND-METHOD-FROM");
symbol3269___object = string_to_symbol("_FIND-METHOD-FROM1561");
symbol3270___object = string_to_symbol("NEXT-CLASS-NUM");
symbol3271___object = string_to_symbol("_NEXT-CLASS-NUM1562");
symbol3272___object = string_to_symbol("IS-A?");
symbol3273___object = string_to_symbol("_STRUCT->OBJECT1563");
symbol3275___object = string_to_symbol("ALLOCATE-INSTANCE");
symbol3280___object = string_to_symbol("FUNCALL");
symbol3281___object = string_to_symbol("fun1113");
{
obj_t aux_3931;
{
obj_t aux_3932;
aux_3932 = MAKE_PAIR(symbol3281___object, BNIL);
aux_3931 = MAKE_PAIR(symbol3281___object, aux_3932);
}
list3279___object = MAKE_PAIR(symbol3280___object, aux_3931);
}
symbol3282___object = string_to_symbol("_");
symbol3283___object = string_to_symbol("_ALLOCATE-INSTANCE1564");
symbol3284___object = string_to_symbol("_WIDE-OBJECT?1565");
symbol3285___object = string_to_symbol("OBJECT-WRITE/DISPLAY");
symbol3289___object = string_to_symbol("get-len");
symbol3290___object = string_to_symbol("obj");
{
obj_t aux_3942;
{
obj_t aux_3943;
{
obj_t aux_3944;
aux_3944 = MAKE_PAIR(symbol3290___object, BNIL);
aux_3943 = MAKE_PAIR(symbol3289___object, aux_3944);
}
aux_3942 = MAKE_PAIR(symbol3289___object, aux_3943);
}
list3288___object = MAKE_PAIR(symbol3280___object, aux_3942);
}
symbol3292___object = string_to_symbol("get-value");
symbol3293___object = string_to_symbol("i");
{
obj_t aux_3951;
{
obj_t aux_3952;
{
obj_t aux_3953;
{
obj_t aux_3954;
aux_3954 = MAKE_PAIR(symbol3293___object, BNIL);
aux_3953 = MAKE_PAIR(symbol3290___object, aux_3954);
}
aux_3952 = MAKE_PAIR(symbol3292___object, aux_3953);
}
aux_3951 = MAKE_PAIR(symbol3292___object, aux_3952);
}
list3291___object = MAKE_PAIR(symbol3280___object, aux_3951);
}
{
obj_t aux_3960;
{
obj_t aux_3961;
{
obj_t aux_3962;
aux_3962 = MAKE_PAIR(symbol3290___object, BNIL);
aux_3961 = MAKE_PAIR(symbol3292___object, aux_3962);
}
aux_3960 = MAKE_PAIR(symbol3292___object, aux_3961);
}
list3294___object = MAKE_PAIR(symbol3280___object, aux_3960);
}
symbol3297___object = string_to_symbol("OBJECT-EQUAL?");
symbol3300___object = string_to_symbol("obj1");
{
obj_t aux_3969;
{
obj_t aux_3970;
{
obj_t aux_3971;
aux_3971 = MAKE_PAIR(symbol3300___object, BNIL);
aux_3970 = MAKE_PAIR(symbol3289___object, aux_3971);
}
aux_3969 = MAKE_PAIR(symbol3289___object, aux_3970);
}
list3299___object = MAKE_PAIR(symbol3280___object, aux_3969);
}
symbol3302___object = string_to_symbol("obj2");
{
obj_t aux_3977;
{
obj_t aux_3978;
{
obj_t aux_3979;
aux_3979 = MAKE_PAIR(symbol3302___object, BNIL);
aux_3978 = MAKE_PAIR(symbol3289___object, aux_3979);
}
aux_3977 = MAKE_PAIR(symbol3289___object, aux_3978);
}
list3301___object = MAKE_PAIR(symbol3280___object, aux_3977);
}
{
obj_t aux_3984;
{
obj_t aux_3985;
{
obj_t aux_3986;
{
obj_t aux_3987;
aux_3987 = MAKE_PAIR(symbol3293___object, BNIL);
aux_3986 = MAKE_PAIR(symbol3300___object, aux_3987);
}
aux_3985 = MAKE_PAIR(symbol3292___object, aux_3986);
}
aux_3984 = MAKE_PAIR(symbol3292___object, aux_3985);
}
list3303___object = MAKE_PAIR(symbol3280___object, aux_3984);
}
{
obj_t aux_3993;
{
obj_t aux_3994;
{
obj_t aux_3995;
{
obj_t aux_3996;
aux_3996 = MAKE_PAIR(symbol3293___object, BNIL);
aux_3995 = MAKE_PAIR(symbol3302___object, aux_3996);
}
aux_3994 = MAKE_PAIR(symbol3292___object, aux_3995);
}
aux_3993 = MAKE_PAIR(symbol3292___object, aux_3994);
}
list3304___object = MAKE_PAIR(symbol3280___object, aux_3993);
}
{
obj_t aux_4002;
{
obj_t aux_4003;
{
obj_t aux_4004;
aux_4004 = MAKE_PAIR(symbol3300___object, BNIL);
aux_4003 = MAKE_PAIR(symbol3292___object, aux_4004);
}
aux_4002 = MAKE_PAIR(symbol3292___object, aux_4003);
}
list3305___object = MAKE_PAIR(symbol3280___object, aux_4002);
}
{
obj_t aux_4009;
{
obj_t aux_4010;
{
obj_t aux_4011;
aux_4011 = MAKE_PAIR(symbol3302___object, BNIL);
aux_4010 = MAKE_PAIR(symbol3292___object, aux_4011);
}
aux_4009 = MAKE_PAIR(symbol3292___object, aux_4010);
}
list3306___object = MAKE_PAIR(symbol3280___object, aux_4009);
}
symbol3307___object = string_to_symbol("_OBJECT-EQUAL?1566");
symbol3308___object = string_to_symbol("OBJECT-INIT");
symbol3309___object = string_to_symbol("OBJECT");
symbol3310___object = string_to_symbol("ALLOCATE-OBJECT");
symbol3311___object = string_to_symbol("MAKE-OBJECT");
symbol3312___object = string_to_symbol("METHOD-INIT");
symbol3313___object = string_to_symbol("OBJECT-DISPLAY");
symbol3316___object = string_to_symbol("APPLY");
symbol3317___object = string_to_symbol("method1398");
symbol3319___object = string_to_symbol("LET");
symbol3322___object = string_to_symbol("list1410");
symbol3326___object = string_to_symbol("arg1411");
symbol3327___object = string_to_symbol("port");
{
obj_t aux_4029;
aux_4029 = MAKE_PAIR(symbol3327___object, BNIL);
list3325___object = MAKE_PAIR(symbol3326___object, aux_4029);
}
symbol3329___object = string_to_symbol("arg1413");
symbol3331___object = string_to_symbol("QUOTE");
{
obj_t aux_4034;
aux_4034 = MAKE_PAIR(BNIL, BNIL);
list3330___object = MAKE_PAIR(symbol3331___object, aux_4034);
}
{
obj_t aux_4037;
aux_4037 = MAKE_PAIR(list3330___object, BNIL);
list3328___object = MAKE_PAIR(symbol3329___object, aux_4037);
}
{
obj_t aux_4040;
aux_4040 = MAKE_PAIR(list3328___object, BNIL);
list3324___object = MAKE_PAIR(list3325___object, aux_4040);
}
symbol3333___object = string_to_symbol("c-cons");
{
obj_t aux_4044;
{
obj_t aux_4045;
aux_4045 = MAKE_PAIR(symbol3329___object, BNIL);
aux_4044 = MAKE_PAIR(symbol3326___object, aux_4045);
}
list3332___object = MAKE_PAIR(symbol3333___object, aux_4044);
}
{
obj_t aux_4049;
{
obj_t aux_4050;
aux_4050 = MAKE_PAIR(list3332___object, BNIL);
aux_4049 = MAKE_PAIR(list3324___object, aux_4050);
}
list3323___object = MAKE_PAIR(symbol3319___object, aux_4049);
}
{
obj_t aux_4054;
aux_4054 = MAKE_PAIR(list3323___object, BNIL);
list3321___object = MAKE_PAIR(symbol3322___object, aux_4054);
}
list3320___object = MAKE_PAIR(list3321___object, BNIL);
symbol3335___object = string_to_symbol("cons*");
{
obj_t aux_4059;
{
obj_t aux_4060;
aux_4060 = MAKE_PAIR(symbol3322___object, BNIL);
aux_4059 = MAKE_PAIR(symbol3290___object, aux_4060);
}
list3334___object = MAKE_PAIR(symbol3335___object, aux_4059);
}
{
obj_t aux_4064;
{
obj_t aux_4065;
aux_4065 = MAKE_PAIR(list3334___object, BNIL);
aux_4064 = MAKE_PAIR(list3320___object, aux_4065);
}
list3318___object = MAKE_PAIR(symbol3319___object, aux_4064);
}
{
obj_t aux_4069;
{
obj_t aux_4070;
aux_4070 = MAKE_PAIR(list3318___object, BNIL);
aux_4069 = MAKE_PAIR(symbol3317___object, aux_4070);
}
list3315___object = MAKE_PAIR(symbol3316___object, aux_4069);
}
symbol3340___object = string_to_symbol("res1454");
symbol3342___object = string_to_symbol("procedure-ref");
symbol3343___object = string_to_symbol("object-display-env");
{
obj_t aux_4077;
{
obj_t aux_4078;
{
obj_t aux_4079;
aux_4079 = BINT(((long)0));
aux_4078 = MAKE_PAIR(aux_4079, BNIL);
}
aux_4077 = MAKE_PAIR(symbol3343___object, aux_4078);
}
list3341___object = MAKE_PAIR(symbol3342___object, aux_4077);
}
{
obj_t aux_4084;
aux_4084 = MAKE_PAIR(list3341___object, BNIL);
list3339___object = MAKE_PAIR(symbol3340___object, aux_4084);
}
list3338___object = MAKE_PAIR(list3339___object, BNIL);
{
obj_t aux_4088;
{
obj_t aux_4089;
aux_4089 = MAKE_PAIR(symbol3340___object, BNIL);
aux_4088 = MAKE_PAIR(list3338___object, aux_4089);
}
list3337___object = MAKE_PAIR(symbol3319___object, aux_4088);
}
symbol3347___object = string_to_symbol("list1190");
symbol3351___object = string_to_symbol("arg1191");
{
obj_t aux_4095;
aux_4095 = MAKE_PAIR(list3330___object, BNIL);
list3350___object = MAKE_PAIR(symbol3351___object, aux_4095);
}
list3349___object = MAKE_PAIR(list3350___object, BNIL);
{
obj_t aux_4099;
{
obj_t aux_4100;
aux_4100 = MAKE_PAIR(symbol3351___object, BNIL);
aux_4099 = MAKE_PAIR(symbol3327___object, aux_4100);
}
list3352___object = MAKE_PAIR(symbol3333___object, aux_4099);
}
{
obj_t aux_4104;
{
obj_t aux_4105;
aux_4105 = MAKE_PAIR(list3352___object, BNIL);
aux_4104 = MAKE_PAIR(list3349___object, aux_4105);
}
list3348___object = MAKE_PAIR(symbol3319___object, aux_4104);
}
{
obj_t aux_4109;
aux_4109 = MAKE_PAIR(list3348___object, BNIL);
list3346___object = MAKE_PAIR(symbol3347___object, aux_4109);
}
list3345___object = MAKE_PAIR(list3346___object, BNIL);
{
obj_t aux_4113;
{
obj_t aux_4114;
aux_4114 = MAKE_PAIR(symbol3347___object, BNIL);
aux_4113 = MAKE_PAIR(symbol3290___object, aux_4114);
}
list3353___object = MAKE_PAIR(symbol3335___object, aux_4113);
}
{
obj_t aux_4118;
{
obj_t aux_4119;
aux_4119 = MAKE_PAIR(list3353___object, BNIL);
aux_4118 = MAKE_PAIR(list3345___object, aux_4119);
}
list3344___object = MAKE_PAIR(symbol3319___object, aux_4118);
}
{
obj_t aux_4123;
{
obj_t aux_4124;
aux_4124 = MAKE_PAIR(list3344___object, BNIL);
aux_4123 = MAKE_PAIR(list3337___object, aux_4124);
}
list3336___object = MAKE_PAIR(symbol3316___object, aux_4123);
}
symbol3354___object = string_to_symbol("_OBJECT-DISPLAY1567");
symbol3355___object = string_to_symbol("OBJECT-DISPLAY-DEFAULT1017");
symbol3356___object = string_to_symbol("_OBJECT-DISPLAY-DEFAULT1017");
symbol3357___object = string_to_symbol("OBJECT-WRITE");
symbol3359___object = string_to_symbol("method1381");
symbol3363___object = string_to_symbol("list1391");
symbol3367___object = string_to_symbol("arg1392");
{
obj_t aux_4135;
aux_4135 = MAKE_PAIR(symbol3327___object, BNIL);
list3366___object = MAKE_PAIR(symbol3367___object, aux_4135);
}
symbol3369___object = string_to_symbol("arg1393");
{
obj_t aux_4139;
aux_4139 = MAKE_PAIR(list3330___object, BNIL);
list3368___object = MAKE_PAIR(symbol3369___object, aux_4139);
}
{
obj_t aux_4142;
aux_4142 = MAKE_PAIR(list3368___object, BNIL);
list3365___object = MAKE_PAIR(list3366___object, aux_4142);
}
{
obj_t aux_4145;
{
obj_t aux_4146;
aux_4146 = MAKE_PAIR(symbol3369___object, BNIL);
aux_4145 = MAKE_PAIR(symbol3367___object, aux_4146);
}
list3370___object = MAKE_PAIR(symbol3333___object, aux_4145);
}
{
obj_t aux_4150;
{
obj_t aux_4151;
aux_4151 = MAKE_PAIR(list3370___object, BNIL);
aux_4150 = MAKE_PAIR(list3365___object, aux_4151);
}
list3364___object = MAKE_PAIR(symbol3319___object, aux_4150);
}
{
obj_t aux_4155;
aux_4155 = MAKE_PAIR(list3364___object, BNIL);
list3362___object = MAKE_PAIR(symbol3363___object, aux_4155);
}
list3361___object = MAKE_PAIR(list3362___object, BNIL);
{
obj_t aux_4159;
{
obj_t aux_4160;
aux_4160 = MAKE_PAIR(symbol3363___object, BNIL);
aux_4159 = MAKE_PAIR(symbol3290___object, aux_4160);
}
list3371___object = MAKE_PAIR(symbol3335___object, aux_4159);
}
{
obj_t aux_4164;
{
obj_t aux_4165;
aux_4165 = MAKE_PAIR(list3371___object, BNIL);
aux_4164 = MAKE_PAIR(list3361___object, aux_4165);
}
list3360___object = MAKE_PAIR(symbol3319___object, aux_4164);
}
{
obj_t aux_4169;
{
obj_t aux_4170;
aux_4170 = MAKE_PAIR(list3360___object, BNIL);
aux_4169 = MAKE_PAIR(symbol3359___object, aux_4170);
}
list3358___object = MAKE_PAIR(symbol3316___object, aux_4169);
}
symbol3376___object = string_to_symbol("res1455");
symbol3378___object = string_to_symbol("object-write-env");
{
obj_t aux_4176;
{
obj_t aux_4177;
{
obj_t aux_4178;
aux_4178 = BINT(((long)0));
aux_4177 = MAKE_PAIR(aux_4178, BNIL);
}
aux_4176 = MAKE_PAIR(symbol3378___object, aux_4177);
}
list3377___object = MAKE_PAIR(symbol3342___object, aux_4176);
}
{
obj_t aux_4183;
aux_4183 = MAKE_PAIR(list3377___object, BNIL);
list3375___object = MAKE_PAIR(symbol3376___object, aux_4183);
}
list3374___object = MAKE_PAIR(list3375___object, BNIL);
{
obj_t aux_4187;
{
obj_t aux_4188;
aux_4188 = MAKE_PAIR(symbol3376___object, BNIL);
aux_4187 = MAKE_PAIR(list3374___object, aux_4188);
}
list3373___object = MAKE_PAIR(symbol3319___object, aux_4187);
}
symbol3382___object = string_to_symbol("list1193");
symbol3386___object = string_to_symbol("arg1194");
{
obj_t aux_4194;
aux_4194 = MAKE_PAIR(list3330___object, BNIL);
list3385___object = MAKE_PAIR(symbol3386___object, aux_4194);
}
list3384___object = MAKE_PAIR(list3385___object, BNIL);
{
obj_t aux_4198;
{
obj_t aux_4199;
aux_4199 = MAKE_PAIR(symbol3386___object, BNIL);
aux_4198 = MAKE_PAIR(symbol3327___object, aux_4199);
}
list3387___object = MAKE_PAIR(symbol3333___object, aux_4198);
}
{
obj_t aux_4203;
{
obj_t aux_4204;
aux_4204 = MAKE_PAIR(list3387___object, BNIL);
aux_4203 = MAKE_PAIR(list3384___object, aux_4204);
}
list3383___object = MAKE_PAIR(symbol3319___object, aux_4203);
}
{
obj_t aux_4208;
aux_4208 = MAKE_PAIR(list3383___object, BNIL);
list3381___object = MAKE_PAIR(symbol3382___object, aux_4208);
}
list3380___object = MAKE_PAIR(list3381___object, BNIL);
{
obj_t aux_4212;
{
obj_t aux_4213;
aux_4213 = MAKE_PAIR(symbol3382___object, BNIL);
aux_4212 = MAKE_PAIR(symbol3290___object, aux_4213);
}
list3388___object = MAKE_PAIR(symbol3335___object, aux_4212);
}
{
obj_t aux_4217;
{
obj_t aux_4218;
aux_4218 = MAKE_PAIR(list3388___object, BNIL);
aux_4217 = MAKE_PAIR(list3380___object, aux_4218);
}
list3379___object = MAKE_PAIR(symbol3319___object, aux_4217);
}
{
obj_t aux_4222;
{
obj_t aux_4223;
aux_4223 = MAKE_PAIR(list3379___object, BNIL);
aux_4222 = MAKE_PAIR(list3373___object, aux_4223);
}
list3372___object = MAKE_PAIR(symbol3316___object, aux_4222);
}
symbol3389___object = string_to_symbol("_OBJECT-WRITE1568");
symbol3390___object = string_to_symbol("OBJECT-WRITE-DEFAULT1018");
symbol3391___object = string_to_symbol("_OBJECT-WRITE-DEFAULT1018");
symbol3392___object = string_to_symbol("OBJECT->STRUCT");
symbol3395___object = string_to_symbol("method1365");
symbol3396___object = string_to_symbol("object");
{
obj_t aux_4233;
{
obj_t aux_4234;
{
obj_t aux_4235;
aux_4235 = MAKE_PAIR(symbol3396___object, BNIL);
aux_4234 = MAKE_PAIR(symbol3395___object, aux_4235);
}
aux_4233 = MAKE_PAIR(symbol3395___object, aux_4234);
}
list3394___object = MAKE_PAIR(symbol3280___object, aux_4233);
}
symbol3398___object = string_to_symbol("fun1196");
{
obj_t aux_4241;
{
obj_t aux_4242;
{
obj_t aux_4243;
aux_4243 = MAKE_PAIR(symbol3396___object, BNIL);
aux_4242 = MAKE_PAIR(symbol3398___object, aux_4243);
}
aux_4241 = MAKE_PAIR(symbol3398___object, aux_4242);
}
list3397___object = MAKE_PAIR(symbol3280___object, aux_4241);
}
symbol3399___object = string_to_symbol("_OBJECT->STRUCT1569");
symbol3400___object = string_to_symbol("OBJECT->STRUCT-DEFAULT1019");
symbol3403___object = string_to_symbol("_OBJECT->STRUCT-DEFAULT1019");
symbol3404___object = string_to_symbol("STRUCT+OBJECT->OBJECT");
symbol3407___object = string_to_symbol("method1347");
symbol3408___object = string_to_symbol("struct");
{
obj_t aux_4254;
{
obj_t aux_4255;
{
obj_t aux_4256;
{
obj_t aux_4257;
aux_4257 = MAKE_PAIR(symbol3408___object, BNIL);
aux_4256 = MAKE_PAIR(symbol3396___object, aux_4257);
}
aux_4255 = MAKE_PAIR(symbol3407___object, aux_4256);
}
aux_4254 = MAKE_PAIR(symbol3407___object, aux_4255);
}
list3406___object = MAKE_PAIR(symbol3280___object, aux_4254);
}
symbol3410___object = string_to_symbol("fun1197");
{
obj_t aux_4264;
{
obj_t aux_4265;
{
obj_t aux_4266;
{
obj_t aux_4267;
aux_4267 = MAKE_PAIR(symbol3408___object, BNIL);
aux_4266 = MAKE_PAIR(symbol3396___object, aux_4267);
}
aux_4265 = MAKE_PAIR(symbol3410___object, aux_4266);
}
aux_4264 = MAKE_PAIR(symbol3410___object, aux_4265);
}
list3409___object = MAKE_PAIR(symbol3280___object, aux_4264);
}
symbol3411___object = string_to_symbol("_STRUCT+OBJECT->OBJECT1570");
symbol3412___object = string_to_symbol("STRUCT+OBJECT->OBJECT-DEFAULT1020");
return (symbol3415___object = string_to_symbol("_STRUCT+OBJECT->OBJECT-DEFAULT1020"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___object()
{
{
obj_t symbol1461_1848;
symbol1461_1848 = symbol3188___object;
{
PUSH_TRACE(symbol1461_1848);
BUNSPEC;
{
obj_t aux1460_1849;
BUNSPEC;
BUNSPEC;
BUNSPEC;
BUNSPEC;
BUNSPEC;
BUNSPEC;
aux1460_1849 = BUNSPEC;
POP_TRACE();
return aux1460_1849;
}
}
}
}


/* class? */bool_t class__60___object(obj_t obj_11)
{
{
bool_t _andtest_1006_3577;
_andtest_1006_3577 = VECTORP(obj_11);
if(_andtest_1006_3577){
long arg1021_3578;
{
obj_t vector_3579;
if(_andtest_1006_3577){
vector_3579 = obj_11;
}
 else {
bigloo_type_error_location_103___error(symbol3189___object, string3190___object, obj_11, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_3578 = VECTOR_LENGTH(vector_3579);
}
return (arg1021_3578==((long)10));
}
 else {
return ((bool_t)0);
}
}
}


/* _class? */obj_t _class__187___object(obj_t env_1934, obj_t obj_1935)
{
{
bool_t aux_4286;
{
obj_t obj_3580;
obj_3580 = obj_1935;
{
bool_t _andtest_1006_3581;
_andtest_1006_3581 = VECTORP(obj_3580);
if(_andtest_1006_3581){
long arg1021_3582;
{
obj_t vector_3583;
if(_andtest_1006_3581){
vector_3583 = obj_3580;
}
 else {
bigloo_type_error_location_103___error(symbol3189___object, string3190___object, obj_3580, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_3582 = VECTOR_LENGTH(vector_3583);
}
aux_4286 = (arg1021_3582==((long)10));
}
 else {
aux_4286 = ((bool_t)0);
}
}
}
return BBOOL(aux_4286);
}
}


/* class-name */obj_t class_name_139___object(obj_t class_12)
{
{
obj_t vector_857;
if(VECTORP(class_12)){
vector_857 = class_12;
}
 else {
bigloo_type_error_location_103___error(symbol3192___object, string3190___object, class_12, string3191___object, BINT(((long)7060)));
exit( -1 );}
{
bool_t test1338_859;
{
long aux_4301;
aux_4301 = VECTOR_LENGTH(vector_857);
test1338_859 = BOUND_CHECK(((long)0), aux_4301);
}
if(test1338_859){
obj_t aux1587_2075;
aux1587_2075 = VECTOR_REF(vector_857, ((long)0));
if(SYMBOLP(aux1587_2075)){
return aux1587_2075;
}
 else {
bigloo_type_error_location_103___error(symbol3192___object, string3193___object, aux1587_2075, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1595_2081;
aux1595_2081 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)0)), string3197___object, BINT(((long)7610)));
if(SYMBOLP(aux1595_2081)){
return aux1595_2081;
}
 else {
bigloo_type_error_location_103___error(symbol3192___object, string3193___object, aux1595_2081, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
}


/* _class-name */obj_t _class_name_50___object(obj_t env_1936, obj_t class_1937)
{
return class_name_139___object(class_1937);
}


/* class-num */long class_num_218___object(obj_t class_13)
{
{
obj_t vector_865;
if(VECTORP(class_13)){
vector_865 = class_13;
}
 else {
bigloo_type_error_location_103___error(symbol3198___object, string3190___object, class_13, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_4325;
{
obj_t aux1610_2093;
aux1610_2093 = VECTOR_REF(vector_865, ((long)1));
if(INTEGERP(aux1610_2093)){
aux_4325 = aux1610_2093;
}
 else {
bigloo_type_error_location_103___error(symbol3198___object, string3199___object, aux1610_2093, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
return (long)CINT(aux_4325);
}
}
}


/* _class-num */obj_t _class_num_205___object(obj_t env_1938, obj_t class_1939)
{
{
long aux_4333;
aux_4333 = class_num_218___object(class_1939);
return BINT(aux_4333);
}
}


/* class-depth */long class_depth_60___object(obj_t class_14)
{
{
obj_t vector_867;
if(VECTORP(class_14)){
vector_867 = class_14;
}
 else {
bigloo_type_error_location_103___error(symbol3200___object, string3190___object, class_14, string3191___object, BINT(((long)7614)));
exit( -1 );}
{
obj_t aux_4341;
{
obj_t aux1624_2105;
aux1624_2105 = VECTOR_REF(vector_867, ((long)2));
if(INTEGERP(aux1624_2105)){
aux_4341 = aux1624_2105;
}
 else {
bigloo_type_error_location_103___error(symbol3200___object, string3199___object, aux1624_2105, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
return (long)CINT(aux_4341);
}
}
}


/* _class-depth */obj_t _class_depth_246___object(obj_t env_1940, obj_t class_1941)
{
{
long aux_4349;
aux_4349 = class_depth_60___object(class_1941);
return BINT(aux_4349);
}
}


/* class-fields */obj_t class_fields_215___object(obj_t class_15)
{
{
obj_t symbol1463_1850;
symbol1463_1850 = symbol3201___object;
{
PUSH_TRACE(symbol1463_1850);
BUNSPEC;
{
obj_t aux1462_1851;
{
bool_t test1023_368;
{
bool_t res1418_877;
{
bool_t _andtest_1006_870;
_andtest_1006_870 = VECTORP(class_15);
if(_andtest_1006_870){
long arg1021_871;
{
obj_t vector_874;
if(_andtest_1006_870){
vector_874 = class_15;
}
 else {
bigloo_type_error_location_103___error(symbol3201___object, string3190___object, class_15, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_871 = VECTOR_LENGTH(vector_874);
}
res1418_877 = (arg1021_871==((long)10));
}
 else {
res1418_877 = ((bool_t)0);
}
}
test1023_368 = res1418_877;
}
if(test1023_368){
obj_t vector_878;
if(VECTORP(class_15)){
vector_878 = class_15;
}
 else {
bigloo_type_error_location_103___error(symbol3201___object, string3190___object, class_15, string3191___object, BINT(((long)7919)));
exit( -1 );}
{
bool_t test1338_880;
{
long aux_4367;
aux_4367 = VECTOR_LENGTH(vector_878);
test1338_880 = BOUND_CHECK(((long)8), aux_4367);
}
if(test1338_880){
aux1462_1851 = VECTOR_REF(vector_878, ((long)8));
}
 else {
aux1462_1851 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)8)), string3197___object, BINT(((long)7610)));
}
}
}
 else {
obj_t arg1026_370;
{
obj_t arg1029_373;
arg1029_373 = find_runtime_type_96___error(class_15);
arg1026_370 = bigloo_type_error_msg_127___error(string3202___object, string3203___object, arg1029_373);
}
aux1462_1851 = debug_error_location_199___error(string3204___object, arg1026_370, class_15, string3197___object, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1462_1851;
}
}
}
}


/* _class-fields */obj_t _class_fields_252___object(obj_t env_1942, obj_t class_1943)
{
return class_fields_215___object(class_1943);
}


/* class-fields? */bool_t class_fields__63___object(obj_t fields_16)
{
{
obj_t symbol1465_3584;
symbol1465_3584 = symbol3205___object;
{
PUSH_TRACE(symbol1465_3584);
BUNSPEC;
{
bool_t aux1464_3585;
{
bool_t _ortest_1007_3586;
_ortest_1007_3586 = PAIRP(fields_16);
if(_ortest_1007_3586){
aux1464_3585 = _ortest_1007_3586;
}
 else {
aux1464_3585 = NULLP(fields_16);
}
}
POP_TRACE();
return aux1464_3585;
}
}
}
}


/* _class-fields? */obj_t _class_fields__244___object(obj_t env_1944, obj_t fields_1945)
{
{
bool_t aux_4386;
{
obj_t fields_3587;
fields_3587 = fields_1945;
{
obj_t symbol1465_3588;
symbol1465_3588 = symbol3205___object;
{
PUSH_TRACE(symbol1465_3588);
BUNSPEC;
{
bool_t aux1464_3589;
{
bool_t _ortest_1007_3590;
_ortest_1007_3590 = PAIRP(fields_3587);
if(_ortest_1007_3590){
aux1464_3589 = _ortest_1007_3590;
}
 else {
aux1464_3589 = NULLP(fields_3587);
}
}
POP_TRACE();
aux_4386 = aux1464_3589;
}
}
}
}
return BBOOL(aux_4386);
}
}


/* class-field-name */obj_t class_field_name_28___object(obj_t field_17)
{
{
obj_t symbol1467_3591;
symbol1467_3591 = symbol3206___object;
{
PUSH_TRACE(symbol1467_3591);
BUNSPEC;
{
obj_t aux1466_3592;
{
obj_t vector_3593;
if(VECTORP(field_17)){
vector_3593 = field_17;
}
 else {
bigloo_type_error_location_103___error(symbol3206___object, string3190___object, field_17, string3191___object, BINT(((long)8663)));
exit( -1 );}
{
bool_t test1338_3594;
{
long aux_4399;
aux_4399 = VECTOR_LENGTH(vector_3593);
test1338_3594 = BOUND_CHECK(((long)0), aux_4399);
}
if(test1338_3594){
obj_t aux1656_3595;
aux1656_3595 = VECTOR_REF(vector_3593, ((long)0));
if(SYMBOLP(aux1656_3595)){
aux1466_3592 = aux1656_3595;
}
 else {
bigloo_type_error_location_103___error(symbol3206___object, string3193___object, aux1656_3595, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1664_3596;
aux1664_3596 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)0)), string3197___object, BINT(((long)7610)));
if(SYMBOLP(aux1664_3596)){
aux1466_3592 = aux1664_3596;
}
 else {
bigloo_type_error_location_103___error(symbol3206___object, string3193___object, aux1664_3596, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1466_3592;
}
}
}
}


/* _class-field-name */obj_t _class_field_name_107___object(obj_t env_1946, obj_t field_1947)
{
{
obj_t field_3597;
field_3597 = field_1947;
{
obj_t symbol1467_3598;
symbol1467_3598 = symbol3206___object;
{
PUSH_TRACE(symbol1467_3598);
BUNSPEC;
{
obj_t aux1466_3599;
{
obj_t vector_3600;
if(VECTORP(field_3597)){
vector_3600 = field_3597;
}
 else {
bigloo_type_error_location_103___error(symbol3206___object, string3190___object, field_3597, string3191___object, BINT(((long)8663)));
exit( -1 );}
{
bool_t test1338_3601;
{
long aux_4424;
aux_4424 = VECTOR_LENGTH(vector_3600);
test1338_3601 = BOUND_CHECK(((long)0), aux_4424);
}
if(test1338_3601){
obj_t aux1656_3602;
aux1656_3602 = VECTOR_REF(vector_3600, ((long)0));
if(SYMBOLP(aux1656_3602)){
aux1466_3599 = aux1656_3602;
}
 else {
bigloo_type_error_location_103___error(symbol3206___object, string3193___object, aux1656_3602, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1664_3603;
aux1664_3603 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)0)), string3197___object, BINT(((long)7610)));
if(SYMBOLP(aux1664_3603)){
aux1466_3599 = aux1664_3603;
}
 else {
bigloo_type_error_location_103___error(symbol3206___object, string3193___object, aux1664_3603, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1466_3599;
}
}
}
}
}


/* class-field-indexed? */bool_t class_field_indexed__189___object(obj_t field_18)
{
{
obj_t symbol1469_3604;
symbol1469_3604 = symbol3207___object;
{
PUSH_TRACE(symbol1469_3604);
BUNSPEC;
{
bool_t aux1468_3605;
{
obj_t arg1030_3606;
{
obj_t vector_3607;
if(VECTORP(field_18)){
vector_3607 = field_18;
}
 else {
bigloo_type_error_location_103___error(symbol3207___object, string3190___object, field_18, string3191___object, BINT(((long)8973)));
exit( -1 );}
{
bool_t test1338_3608;
{
long aux_4449;
aux_4449 = VECTOR_LENGTH(vector_3607);
test1338_3608 = BOUND_CHECK(((long)3), aux_4449);
}
if(test1338_3608){
arg1030_3606 = VECTOR_REF(vector_3607, ((long)3));
}
 else {
arg1030_3606 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
aux1468_3605 = PROCEDUREP(arg1030_3606);
}
POP_TRACE();
return aux1468_3605;
}
}
}
}


/* _class-field-indexed? */obj_t _class_field_indexed__52___object(obj_t env_1948, obj_t field_1949)
{
{
bool_t aux_4459;
{
obj_t field_3609;
field_3609 = field_1949;
{
obj_t symbol1469_3610;
symbol1469_3610 = symbol3207___object;
{
PUSH_TRACE(symbol1469_3610);
BUNSPEC;
{
bool_t aux1468_3611;
{
obj_t arg1030_3612;
{
obj_t vector_3613;
if(VECTORP(field_3609)){
vector_3613 = field_3609;
}
 else {
bigloo_type_error_location_103___error(symbol3207___object, string3190___object, field_3609, string3191___object, BINT(((long)8973)));
exit( -1 );}
{
bool_t test1338_3614;
{
long aux_4466;
aux_4466 = VECTOR_LENGTH(vector_3613);
test1338_3614 = BOUND_CHECK(((long)3), aux_4466);
}
if(test1338_3614){
arg1030_3612 = VECTOR_REF(vector_3613, ((long)3));
}
 else {
arg1030_3612 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
aux1468_3611 = PROCEDUREP(arg1030_3612);
}
POP_TRACE();
aux_4459 = aux1468_3611;
}
}
}
}
return BBOOL(aux_4459);
}
}


/* class-field-accessor */obj_t class_field_accessor_18___object(obj_t field_19)
{
{
obj_t symbol1471_3615;
symbol1471_3615 = symbol3208___object;
{
PUSH_TRACE(symbol1471_3615);
BUNSPEC;
{
obj_t aux1470_3616;
{
obj_t vector_3617;
if(VECTORP(field_19)){
vector_3617 = field_19;
}
 else {
bigloo_type_error_location_103___error(symbol3208___object, string3190___object, field_19, string3191___object, BINT(((long)9277)));
exit( -1 );}
{
bool_t test1338_3618;
{
long aux_4483;
aux_4483 = VECTOR_LENGTH(vector_3617);
test1338_3618 = BOUND_CHECK(((long)1), aux_4483);
}
if(test1338_3618){
obj_t aux1683_3619;
aux1683_3619 = VECTOR_REF(vector_3617, ((long)1));
if(PROCEDUREP(aux1683_3619)){
aux1470_3616 = aux1683_3619;
}
 else {
bigloo_type_error_location_103___error(symbol3208___object, string3209___object, aux1683_3619, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1690_3620;
aux1690_3620 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)1)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux1690_3620)){
aux1470_3616 = aux1690_3620;
}
 else {
bigloo_type_error_location_103___error(symbol3208___object, string3209___object, aux1690_3620, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1470_3616;
}
}
}
}


/* _class-field-accessor */obj_t _class_field_accessor_230___object(obj_t env_1950, obj_t field_1951)
{
{
obj_t field_3621;
field_3621 = field_1951;
{
obj_t symbol1471_3622;
symbol1471_3622 = symbol3208___object;
{
PUSH_TRACE(symbol1471_3622);
BUNSPEC;
{
obj_t aux1470_3623;
{
obj_t vector_3624;
if(VECTORP(field_3621)){
vector_3624 = field_3621;
}
 else {
bigloo_type_error_location_103___error(symbol3208___object, string3190___object, field_3621, string3191___object, BINT(((long)9277)));
exit( -1 );}
{
bool_t test1338_3625;
{
long aux_4508;
aux_4508 = VECTOR_LENGTH(vector_3624);
test1338_3625 = BOUND_CHECK(((long)1), aux_4508);
}
if(test1338_3625){
obj_t aux1683_3626;
aux1683_3626 = VECTOR_REF(vector_3624, ((long)1));
if(PROCEDUREP(aux1683_3626)){
aux1470_3623 = aux1683_3626;
}
 else {
bigloo_type_error_location_103___error(symbol3208___object, string3209___object, aux1683_3626, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1690_3627;
aux1690_3627 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)1)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux1690_3627)){
aux1470_3623 = aux1690_3627;
}
 else {
bigloo_type_error_location_103___error(symbol3208___object, string3209___object, aux1690_3627, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1470_3623;
}
}
}
}
}


/* class-field-mutable? */bool_t class_field_mutable__211___object(obj_t field_20)
{
{
obj_t symbol1473_3628;
symbol1473_3628 = symbol3210___object;
{
PUSH_TRACE(symbol1473_3628);
BUNSPEC;
{
bool_t aux1472_3629;
{
obj_t arg1031_3630;
{
obj_t vector_3631;
if(VECTORP(field_20)){
vector_3631 = field_20;
}
 else {
bigloo_type_error_location_103___error(symbol3210___object, string3190___object, field_20, string3191___object, BINT(((long)9587)));
exit( -1 );}
{
bool_t test1338_3632;
{
long aux_4533;
aux_4533 = VECTOR_LENGTH(vector_3631);
test1338_3632 = BOUND_CHECK(((long)2), aux_4533);
}
if(test1338_3632){
arg1031_3630 = VECTOR_REF(vector_3631, ((long)2));
}
 else {
arg1031_3630 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)2)), string3197___object, BINT(((long)7610)));
}
}
}
aux1472_3629 = PROCEDUREP(arg1031_3630);
}
POP_TRACE();
return aux1472_3629;
}
}
}
}


/* _class-field-mutable? */obj_t _class_field_mutable__51___object(obj_t env_1952, obj_t field_1953)
{
{
bool_t aux_4543;
{
obj_t field_3633;
field_3633 = field_1953;
{
obj_t symbol1473_3634;
symbol1473_3634 = symbol3210___object;
{
PUSH_TRACE(symbol1473_3634);
BUNSPEC;
{
bool_t aux1472_3635;
{
obj_t arg1031_3636;
{
obj_t vector_3637;
if(VECTORP(field_3633)){
vector_3637 = field_3633;
}
 else {
bigloo_type_error_location_103___error(symbol3210___object, string3190___object, field_3633, string3191___object, BINT(((long)9587)));
exit( -1 );}
{
bool_t test1338_3638;
{
long aux_4550;
aux_4550 = VECTOR_LENGTH(vector_3637);
test1338_3638 = BOUND_CHECK(((long)2), aux_4550);
}
if(test1338_3638){
arg1031_3636 = VECTOR_REF(vector_3637, ((long)2));
}
 else {
arg1031_3636 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)2)), string3197___object, BINT(((long)7610)));
}
}
}
aux1472_3635 = PROCEDUREP(arg1031_3636);
}
POP_TRACE();
aux_4543 = aux1472_3635;
}
}
}
}
return BBOOL(aux_4543);
}
}


/* class-field-mutator */obj_t class_field_mutator_255___object(obj_t field_21)
{
{
obj_t symbol1475_3639;
symbol1475_3639 = symbol3211___object;
{
PUSH_TRACE(symbol1475_3639);
BUNSPEC;
{
obj_t aux1474_3640;
{
obj_t vector_3641;
if(VECTORP(field_21)){
vector_3641 = field_21;
}
 else {
bigloo_type_error_location_103___error(symbol3211___object, string3190___object, field_21, string3191___object, BINT(((long)9890)));
exit( -1 );}
{
bool_t test1338_3642;
{
long aux_4567;
aux_4567 = VECTOR_LENGTH(vector_3641);
test1338_3642 = BOUND_CHECK(((long)2), aux_4567);
}
if(test1338_3642){
obj_t aux1708_3643;
aux1708_3643 = VECTOR_REF(vector_3641, ((long)2));
if(PROCEDUREP(aux1708_3643)){
aux1474_3640 = aux1708_3643;
}
 else {
bigloo_type_error_location_103___error(symbol3211___object, string3209___object, aux1708_3643, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1714_3644;
aux1714_3644 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)2)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux1714_3644)){
aux1474_3640 = aux1714_3644;
}
 else {
bigloo_type_error_location_103___error(symbol3211___object, string3209___object, aux1714_3644, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1474_3640;
}
}
}
}


/* _class-field-mutator */obj_t _class_field_mutator_181___object(obj_t env_1954, obj_t field_1955)
{
{
obj_t field_3645;
field_3645 = field_1955;
{
obj_t symbol1475_3646;
symbol1475_3646 = symbol3211___object;
{
PUSH_TRACE(symbol1475_3646);
BUNSPEC;
{
obj_t aux1474_3647;
{
obj_t vector_3648;
if(VECTORP(field_3645)){
vector_3648 = field_3645;
}
 else {
bigloo_type_error_location_103___error(symbol3211___object, string3190___object, field_3645, string3191___object, BINT(((long)9890)));
exit( -1 );}
{
bool_t test1338_3649;
{
long aux_4592;
aux_4592 = VECTOR_LENGTH(vector_3648);
test1338_3649 = BOUND_CHECK(((long)2), aux_4592);
}
if(test1338_3649){
obj_t aux1708_3650;
aux1708_3650 = VECTOR_REF(vector_3648, ((long)2));
if(PROCEDUREP(aux1708_3650)){
aux1474_3647 = aux1708_3650;
}
 else {
bigloo_type_error_location_103___error(symbol3211___object, string3209___object, aux1708_3650, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1714_3651;
aux1714_3651 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)2)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux1714_3651)){
aux1474_3647 = aux1714_3651;
}
 else {
bigloo_type_error_location_103___error(symbol3211___object, string3209___object, aux1714_3651, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1474_3647;
}
}
}
}
}


/* class-field-len-accessor */obj_t class_field_len_accessor_212___object(obj_t field_22)
{
{
obj_t symbol1477_3652;
symbol1477_3652 = symbol3212___object;
{
PUSH_TRACE(symbol1477_3652);
BUNSPEC;
{
obj_t aux1476_3653;
{
obj_t vector_3654;
if(VECTORP(field_22)){
vector_3654 = field_22;
}
 else {
bigloo_type_error_location_103___error(symbol3212___object, string3190___object, field_22, string3191___object, BINT(((long)10197)));
exit( -1 );}
{
bool_t test1338_3655;
{
long aux_4617;
aux_4617 = VECTOR_LENGTH(vector_3654);
test1338_3655 = BOUND_CHECK(((long)3), aux_4617);
}
if(test1338_3655){
obj_t aux1727_3656;
aux1727_3656 = VECTOR_REF(vector_3654, ((long)3));
if(PROCEDUREP(aux1727_3656)){
aux1476_3653 = aux1727_3656;
}
 else {
bigloo_type_error_location_103___error(symbol3212___object, string3209___object, aux1727_3656, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1733_3657;
aux1733_3657 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux1733_3657)){
aux1476_3653 = aux1733_3657;
}
 else {
bigloo_type_error_location_103___error(symbol3212___object, string3209___object, aux1733_3657, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1476_3653;
}
}
}
}


/* _class-field-len-accessor */obj_t _class_field_len_accessor_58___object(obj_t env_1956, obj_t field_1957)
{
{
obj_t field_3658;
field_3658 = field_1957;
{
obj_t symbol1477_3659;
symbol1477_3659 = symbol3212___object;
{
PUSH_TRACE(symbol1477_3659);
BUNSPEC;
{
obj_t aux1476_3660;
{
obj_t vector_3661;
if(VECTORP(field_3658)){
vector_3661 = field_3658;
}
 else {
bigloo_type_error_location_103___error(symbol3212___object, string3190___object, field_3658, string3191___object, BINT(((long)10197)));
exit( -1 );}
{
bool_t test1338_3662;
{
long aux_4642;
aux_4642 = VECTOR_LENGTH(vector_3661);
test1338_3662 = BOUND_CHECK(((long)3), aux_4642);
}
if(test1338_3662){
obj_t aux1727_3663;
aux1727_3663 = VECTOR_REF(vector_3661, ((long)3));
if(PROCEDUREP(aux1727_3663)){
aux1476_3660 = aux1727_3663;
}
 else {
bigloo_type_error_location_103___error(symbol3212___object, string3209___object, aux1727_3663, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux1733_3664;
aux1733_3664 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux1733_3664)){
aux1476_3660 = aux1733_3664;
}
 else {
bigloo_type_error_location_103___error(symbol3212___object, string3209___object, aux1733_3664, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1476_3660;
}
}
}
}
}


/* class-super */obj_t class_super_145___object(obj_t class_23)
{
{
obj_t vector_944;
if(VECTORP(class_23)){
vector_944 = class_23;
}
 else {
bigloo_type_error_location_103___error(symbol3213___object, string3190___object, class_23, string3191___object, BINT(((long)10473)));
exit( -1 );}
{
bool_t test1338_946;
{
long aux_4666;
aux_4666 = VECTOR_LENGTH(vector_944);
test1338_946 = BOUND_CHECK(((long)3), aux_4666);
}
if(test1338_946){
return VECTOR_REF(vector_944, ((long)3));
}
 else {
return debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
}


/* _class-super */obj_t _class_super_213___object(obj_t env_1958, obj_t class_1959)
{
return class_super_145___object(class_1959);
}


/* class-subclasses */obj_t class_subclasses_99___object(obj_t class_24)
{
{
obj_t vector_952;
if(VECTORP(class_24)){
vector_952 = class_24;
}
 else {
bigloo_type_error_location_103___error(symbol3214___object, string3190___object, class_24, string3191___object, BINT(((long)10761)));
exit( -1 );}
{
bool_t test1338_954;
{
long aux_4680;
aux_4680 = VECTOR_LENGTH(vector_952);
test1338_954 = BOUND_CHECK(((long)4), aux_4680);
}
if(test1338_954){
return VECTOR_REF(vector_952, ((long)4));
}
 else {
return debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)4)), string3197___object, BINT(((long)7610)));
}
}
}
}


/* _class-subclasses */obj_t _class_subclasses_86___object(obj_t env_1960, obj_t class_1961)
{
return class_subclasses_99___object(class_1961);
}


/* class-hash */long class_hash_237___object(obj_t class_29)
{
{
obj_t symbol1479_1866;
symbol1479_1866 = symbol3215___object;
{
PUSH_TRACE(symbol1479_1866);
BUNSPEC;
{
long aux1478_1867;
{
obj_t vector_967;
if(VECTORP(class_29)){
vector_967 = class_29;
}
 else {
bigloo_type_error_location_103___error(symbol3215___object, string3190___object, class_29, string3191___object, BINT(((long)11907)));
exit( -1 );}
{
obj_t aux_4695;
{
obj_t aux1768_2225;
aux1768_2225 = VECTOR_REF(vector_967, ((long)7));
if(INTEGERP(aux1768_2225)){
aux_4695 = aux1768_2225;
}
 else {
bigloo_type_error_location_103___error(symbol3215___object, string3199___object, aux1768_2225, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
aux1478_1867 = (long)CINT(aux_4695);
}
}
POP_TRACE();
return aux1478_1867;
}
}
}
}


/* _class-hash */obj_t _class_hash_144___object(obj_t env_1962, obj_t class_1963)
{
{
long aux_4704;
aux_4704 = class_hash_237___object(class_1963);
return BINT(aux_4704);
}
}


/* class-constructor */obj_t class_constructor_163___object(obj_t class_30)
{
{
obj_t vector_969;
if(VECTORP(class_30)){
vector_969 = class_30;
}
 else {
bigloo_type_error_location_103___error(symbol3216___object, string3190___object, class_30, string3191___object, BINT(((long)12191)));
exit( -1 );}
{
bool_t test1338_971;
{
long aux_4712;
aux_4712 = VECTOR_LENGTH(vector_969);
test1338_971 = BOUND_CHECK(((long)9), aux_4712);
}
if(test1338_971){
return VECTOR_REF(vector_969, ((long)9));
}
 else {
return debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)9)), string3197___object, BINT(((long)7610)));
}
}
}
}


/* _class-constructor */obj_t _class_constructor_88___object(obj_t env_1964, obj_t class_1965)
{
return class_constructor_163___object(class_1965);
}


/* initialize-objects! */obj_t initialize_objects__138___object()
{
{
obj_t symbol1481_1868;
symbol1481_1868 = symbol3217___object;
{
PUSH_TRACE(symbol1481_1868);
BUNSPEC;
{
obj_t aux1480_1869;
{
bool_t test1032_377;
{
obj_t obj_978;
obj_978 = _nb_classes__240___object;
test1032_377 = INTEGERP(obj_978);
}
if(test1032_377){
aux1480_1869 = symbol3218___object;
}
 else {
_nb_classes__240___object = BINT(((long)0));
_nb_classes_max__8___object = BINT(((long)50));
{
long aux_4726;
{
obj_t aux_4727;
{
obj_t aux1780_2237;
aux1780_2237 = _nb_classes_max__8___object;
if(INTEGERP(aux1780_2237)){
aux_4727 = aux1780_2237;
}
 else {
bigloo_type_error_location_103___error(symbol3217___object, string3199___object, aux1780_2237, string3191___object, BINT(((long)14112)));
exit( -1 );}
}
aux_4726 = (long)CINT(aux_4727);
}
_classes__134___object = make_vector(aux_4726, BFALSE);
}
_nb_generics_max__185___object = BINT(((long)50));
_nb_generics__142___object = BINT(((long)0));
{
long aux_4737;
{
obj_t aux_4738;
{
obj_t aux1790_2243;
aux1790_2243 = _nb_generics_max__185___object;
if(INTEGERP(aux1790_2243)){
aux_4738 = aux1790_2243;
}
 else {
bigloo_type_error_location_103___error(symbol3217___object, string3199___object, aux1790_2243, string3191___object, BINT(((long)14244)));
exit( -1 );}
}
aux_4737 = (long)CINT(aux_4738);
}
aux1480_1869 = (_generics__29___object = make_vector(aux_4737, BFALSE),
BUNSPEC);
}
}
}
POP_TRACE();
return aux1480_1869;
}
}
}
}


/* extend-vector */obj_t extend_vector_160___object(obj_t old_vec_37_31, obj_t fill_32, long extend_33)
{
{
obj_t symbol1483_1870;
symbol1483_1870 = symbol3219___object;
{
PUSH_TRACE(symbol1483_1870);
BUNSPEC;
{
obj_t aux1482_1871;
{
long old_len_227_378;
{
obj_t vector_979;
if(VECTORP(old_vec_37_31)){
vector_979 = old_vec_37_31;
}
 else {
bigloo_type_error_location_103___error(symbol3219___object, string3190___object, old_vec_37_31, string3191___object, BINT(((long)14570)));
exit( -1 );}
old_len_227_378 = VECTOR_LENGTH(vector_979);
}
{
obj_t new_vec_94_380;
{
long aux_4754;
aux_4754 = (extend_33+old_len_227_378);
new_vec_94_380 = make_vector(aux_4754, fill_32);
}
{
{
long i_381;
i_381 = ((long)0);
loop_382:
if((i_381==old_len_227_378)){
aux1482_1871 = new_vec_94_380;
}
 else {
{
obj_t arg1034_384;
{
obj_t vector_984;
if(VECTORP(old_vec_37_31)){
vector_984 = old_vec_37_31;
}
 else {
bigloo_type_error_location_103___error(symbol3219___object, string3190___object, old_vec_37_31, string3191___object, BINT(((long)14771)));
exit( -1 );}
arg1034_384 = VECTOR_REF(vector_984, i_381);
}
VECTOR_SET(new_vec_94_380, i_381, arg1034_384);
}
{
long i_4766;
i_4766 = (i_381+((long)1));
i_381 = i_4766;
goto loop_382;
}
}
}
}
}
}
POP_TRACE();
return aux1482_1871;
}
}
}
}


/* double-nb-classes! */obj_t double_nb_classes__118___object()
{
{
obj_t symbol1485_1872;
symbol1485_1872 = symbol3220___object;
{
PUSH_TRACE(symbol1485_1872);
BUNSPEC;
{
obj_t aux1484_1873;
{
long z2_994;
{
obj_t aux_4770;
{
obj_t aux1810_2261;
aux1810_2261 = _nb_classes_max__8___object;
if(INTEGERP(aux1810_2261)){
aux_4770 = aux1810_2261;
}
 else {
bigloo_type_error_location_103___error(symbol3220___object, string3199___object, aux1810_2261, string3191___object, BINT(((long)15433)));
exit( -1 );}
}
z2_994 = (long)CINT(aux_4770);
}
{
long aux_4777;
aux_4777 = (((long)2)*z2_994);
_nb_classes_max__8___object = BINT(aux_4777);
}
}
{
obj_t old_vec_37_995;
old_vec_37_995 = _classes__134___object;
{
long arg1037_997;
{
obj_t vector_998;
if(VECTORP(old_vec_37_995)){
vector_998 = old_vec_37_995;
}
 else {
bigloo_type_error_location_103___error(symbol3220___object, string3190___object, old_vec_37_995, string3191___object, BINT(((long)15119)));
exit( -1 );}
arg1037_997 = VECTOR_LENGTH(vector_998);
}
_classes__134___object = extend_vector_160___object(old_vec_37_995, BFALSE, arg1037_997);
}
}
{
long i_387;
i_387 = ((long)0);
loop_388:
{
bool_t test1038_389;
{
long n2_1000;
{
obj_t aux_4787;
{
obj_t aux1823_2273;
aux1823_2273 = _nb_generics__142___object;
if(INTEGERP(aux1823_2273)){
aux_4787 = aux1823_2273;
}
 else {
bigloo_type_error_location_103___error(symbol3220___object, string3199___object, aux1823_2273, string3191___object, BINT(((long)15539)));
exit( -1 );}
}
n2_1000 = (long)CINT(aux_4787);
}
test1038_389 = (i_387==n2_1000);
}
if(test1038_389){
aux1484_1873 = symbol3218___object;
}
 else {
obj_t generic_390;
{
obj_t vector_1001;
vector_1001 = _generics__29___object;
{
bool_t test1338_1003;
{
long aux_4796;
aux_4796 = VECTOR_LENGTH(vector_1001);
test1338_1003 = BOUND_CHECK(i_387, aux_4796);
}
if(test1338_1003){
generic_390 = VECTOR_REF(vector_1001, i_387);
}
 else {
generic_390 = debug_error_location_199___error(string3195___object, string3196___object, BINT(i_387), string3197___object, BINT(((long)7610)));
}
}
}
{
obj_t old_method_array_215_391;
{
obj_t generic_1009;
if(PROCEDUREP(generic_390)){
generic_1009 = generic_390;
}
 else {
bigloo_type_error_location_103___error(symbol3220___object, string3209___object, generic_390, string3191___object, BINT(((long)15642)));
exit( -1 );}
old_method_array_215_391 = PROCEDURE_REF(generic_1009, ((long)1));
}
{
{
obj_t arg1039_392;
{
long arg1037_1012;
{
obj_t vector_1013;
if(VECTORP(old_method_array_215_391)){
vector_1013 = old_method_array_215_391;
}
 else {
bigloo_type_error_location_103___error(symbol3220___object, string3190___object, old_method_array_215_391, string3191___object, BINT(((long)15119)));
exit( -1 );}
arg1037_1012 = VECTOR_LENGTH(vector_1013);
}
arg1039_392 = extend_vector_160___object(old_method_array_215_391, BFALSE, arg1037_1012);
}
{
obj_t generic_1014;
if(PROCEDUREP(generic_390)){
generic_1014 = generic_390;
}
 else {
bigloo_type_error_location_103___error(symbol3220___object, string3209___object, generic_390, string3191___object, BINT(((long)15680)));
exit( -1 );}
PROCEDURE_SET(generic_1014, ((long)1), arg1039_392);
}
}
{
long i_4823;
i_4823 = (i_387+((long)1));
i_387 = i_4823;
goto loop_388;
}
}
}
}
}
}
POP_TRACE();
return aux1484_1873;
}
}
}
}


/* double-nb-generics! */obj_t double_nb_generics__239___object()
{
{
obj_t symbol1487_1874;
symbol1487_1874 = symbol3221___object;
{
PUSH_TRACE(symbol1487_1874);
BUNSPEC;
{
obj_t aux1486_1875;
{
long z2_1019;
{
obj_t aux_4827;
{
obj_t aux1854_2297;
aux1854_2297 = _nb_generics_max__185___object;
if(INTEGERP(aux1854_2297)){
aux_4827 = aux1854_2297;
}
 else {
bigloo_type_error_location_103___error(symbol3221___object, string3199___object, aux1854_2297, string3191___object, BINT(((long)16069)));
exit( -1 );}
}
z2_1019 = (long)CINT(aux_4827);
}
{
long aux_4834;
aux_4834 = (((long)2)*z2_1019);
_nb_generics_max__185___object = BINT(aux_4834);
}
}
{
obj_t old_vec_37_1020;
old_vec_37_1020 = _generics__29___object;
aux1486_1875 = (_generics__29___object = extend_vector_160___object(old_vec_37_1020, BFALSE, VECTOR_LENGTH(old_vec_37_1020)),
BUNSPEC);
}
POP_TRACE();
return aux1486_1875;
}
}
}
}


/* object? */bool_t object__44___object(obj_t obj_36)
{
{
obj_t symbol1489_3665;
symbol1489_3665 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3665);
BUNSPEC;
{
bool_t aux1488_3666;
aux1488_3666 = (POINTERP( obj_36 ) && (TYPE( obj_36 ) >= OBJECT_TYPE));
POP_TRACE();
return aux1488_3666;
}
}
}
}


/* _object? */obj_t _object__148___object(obj_t env_1966, obj_t obj_1967)
{
{
bool_t aux_4843;
{
obj_t obj_3667;
obj_3667 = obj_1967;
{
obj_t symbol1489_3668;
symbol1489_3668 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3668);
BUNSPEC;
{
bool_t aux1488_3669;
aux1488_3669 = (POINTERP( obj_3667 ) && (TYPE( obj_3667 ) >= OBJECT_TYPE));
POP_TRACE();
aux_4843 = aux1488_3669;
}
}
}
}
return BBOOL(aux_4843);
}
}


/* object-class-num */long object_class_num_83___object(object_t obj_37)
{
{
obj_t symbol1491_3670;
symbol1491_3670 = symbol3223___object;
{
PUSH_TRACE(symbol1491_3670);
BUNSPEC;
{
long aux1490_3671;
aux1490_3671 = TYPE( obj_37 );
POP_TRACE();
return aux1490_3671;
}
}
}
}


/* _object-class-num1546 */obj_t _object_class_num1546_73___object(obj_t env_1968, obj_t obj_1969)
{
{
long aux_4851;
{
object_t obj_3676;
{
bool_t test1861_2304;
{
bool_t res3416_3675;
{
obj_t obj_3672;
obj_3672 = obj_1969;
{
obj_t symbol1489_3673;
symbol1489_3673 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3673);
BUNSPEC;
{
bool_t aux1488_3674;
aux1488_3674 = (POINTERP( obj_3672 ) && (TYPE( obj_3672 ) >= OBJECT_TYPE));
POP_TRACE();
res3416_3675 = aux1488_3674;
}
}
}
}
test1861_2304 = res3416_3675;
}
if(test1861_2304){
obj_3676 = (object_t)(obj_1969);
}
 else {
bigloo_type_error_location_103___error(symbol3224___object, string3225___object, obj_1969, string3191___object, BINT(((long)16694)));
exit( -1 );}
}
{
obj_t symbol1491_3677;
symbol1491_3677 = symbol3223___object;
{
PUSH_TRACE(symbol1491_3677);
BUNSPEC;
{
long aux1490_3678;
aux1490_3678 = TYPE( obj_3676 );
POP_TRACE();
aux_4851 = aux1490_3678;
}
}
}
}
return BINT(aux_4851);
}
}


/* object-class-num-set! */obj_t object_class_num_set__124___object(obj_t obj_38, long num_39)
{
{
obj_t symbol1493_3679;
symbol1493_3679 = symbol3226___object;
{
PUSH_TRACE(symbol1493_3679);
BUNSPEC;
{
obj_t aux1492_3680;
aux1492_3680 = (((obj_t)CREF(obj_38))->header = MAKE_HEADER( num_39, 0 ), BUNSPEC);
POP_TRACE();
return aux1492_3680;
}
}
}
}


/* _object-class-num-set!1547 */obj_t _object_class_num_set_1547_94___object(obj_t env_1970, obj_t obj_1971, obj_t num_1972)
{
{
obj_t obj_3681;
long num_3682;
obj_3681 = obj_1971;
{
obj_t aux_4867;
if(INTEGERP(num_1972)){
aux_4867 = num_1972;
}
 else {
bigloo_type_error_location_103___error(symbol3227___object, string3199___object, num_1972, string3191___object, BINT(((long)16991)));
exit( -1 );}
num_3682 = (long)CINT(aux_4867);
}
{
obj_t symbol1493_3683;
symbol1493_3683 = symbol3226___object;
{
PUSH_TRACE(symbol1493_3683);
BUNSPEC;
{
obj_t aux1492_3684;
aux1492_3684 = (((obj_t)CREF(obj_3681))->header = MAKE_HEADER( num_3682, 0 ), BUNSPEC);
POP_TRACE();
return aux1492_3684;
}
}
}
}
}


/* object-class */obj_t object_class_242___object(object_t object_40)
{
{
long arg1041_3685;
{
long arg1042_3686;
long arg1043_3687;
arg1042_3686 = TYPE( object_40 );
arg1043_3687 = OBJECT_TYPE;
arg1041_3685 = (arg1042_3686-arg1043_3687);
}
{
obj_t vector_3688;
{
obj_t aux1872_3689;
aux1872_3689 = _classes__134___object;
if(VECTORP(aux1872_3689)){
vector_3688 = aux1872_3689;
}
 else {
bigloo_type_error_location_103___error(symbol3228___object, string3190___object, aux1872_3689, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
return VECTOR_REF(vector_3688, arg1041_3685);
}
}
}


/* _object-class1548 */obj_t _object_class1548_155___object(obj_t env_1973, obj_t object_1974)
{
{
object_t object_3694;
{
bool_t test1879_2322;
{
bool_t res3417_3693;
{
obj_t obj_3690;
obj_3690 = object_1974;
{
obj_t symbol1489_3691;
symbol1489_3691 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3691);
BUNSPEC;
{
bool_t aux1488_3692;
aux1488_3692 = (POINTERP( obj_3690 ) && (TYPE( obj_3690 ) >= OBJECT_TYPE));
POP_TRACE();
res3417_3693 = aux1488_3692;
}
}
}
}
test1879_2322 = res3417_3693;
}
if(test1879_2322){
object_3694 = (object_t)(object_1974);
}
 else {
bigloo_type_error_location_103___error(symbol3229___object, string3225___object, object_1974, string3191___object, BINT(((long)17352)));
exit( -1 );}
}
{
long arg1041_3695;
{
long arg1042_3696;
long arg1043_3697;
arg1042_3696 = TYPE( object_3694 );
arg1043_3697 = OBJECT_TYPE;
arg1041_3695 = (arg1042_3696-arg1043_3697);
}
{
obj_t vector_3698;
{
obj_t aux1872_3699;
aux1872_3699 = _classes__134___object;
if(VECTORP(aux1872_3699)){
vector_3698 = aux1872_3699;
}
 else {
bigloo_type_error_location_103___error(symbol3228___object, string3190___object, aux1872_3699, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
return VECTOR_REF(vector_3698, arg1041_3695);
}
}
}
}


/* generic-default */obj_t generic_default_171___object(obj_t generic_41)
{
{
obj_t symbol1495_3700;
symbol1495_3700 = symbol3230___object;
{
PUSH_TRACE(symbol1495_3700);
BUNSPEC;
{
obj_t aux1494_3701;
{
obj_t aux1885_3702;
aux1885_3702 = PROCEDURE_REF(generic_41, ((long)0));
if(PROCEDUREP(aux1885_3702)){
aux1494_3701 = aux1885_3702;
}
 else {
bigloo_type_error_location_103___error(symbol3230___object, string3209___object, aux1885_3702, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
POP_TRACE();
return aux1494_3701;
}
}
}
}


/* _generic-default1549 */obj_t _generic_default1549_158___object(obj_t env_1975, obj_t generic_1976)
{
{
obj_t generic_3703;
if(PROCEDUREP(generic_1976)){
generic_3703 = generic_1976;
}
 else {
bigloo_type_error_location_103___error(symbol3231___object, string3209___object, generic_1976, string3191___object, BINT(((long)17716)));
exit( -1 );}
{
obj_t symbol1495_3704;
symbol1495_3704 = symbol3230___object;
{
PUSH_TRACE(symbol1495_3704);
BUNSPEC;
{
obj_t aux1494_3705;
{
obj_t aux1885_3706;
aux1885_3706 = PROCEDURE_REF(generic_3703, ((long)0));
if(PROCEDUREP(aux1885_3706)){
aux1494_3705 = aux1885_3706;
}
 else {
bigloo_type_error_location_103___error(symbol3230___object, string3209___object, aux1885_3706, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
POP_TRACE();
return aux1494_3705;
}
}
}
}
}


/* generic-method-array */obj_t generic_method_array_21___object(obj_t generic_44)
{
{
obj_t symbol1497_3707;
symbol1497_3707 = symbol3232___object;
{
PUSH_TRACE(symbol1497_3707);
BUNSPEC;
{
obj_t aux1496_3708;
aux1496_3708 = PROCEDURE_REF(generic_44, ((long)1));
POP_TRACE();
return aux1496_3708;
}
}
}
}


/* _generic-method-array1550 */obj_t _generic_method_array1550_197___object(obj_t env_1977, obj_t generic_1978)
{
{
obj_t generic_3709;
if(PROCEDUREP(generic_1978)){
generic_3709 = generic_1978;
}
 else {
bigloo_type_error_location_103___error(symbol3233___object, string3209___object, generic_1978, string3191___object, BINT(((long)18326)));
exit( -1 );}
{
obj_t symbol1497_3710;
symbol1497_3710 = symbol3232___object;
{
PUSH_TRACE(symbol1497_3710);
BUNSPEC;
{
obj_t aux1496_3711;
aux1496_3711 = PROCEDURE_REF(generic_3709, ((long)1));
POP_TRACE();
return aux1496_3711;
}
}
}
}
}


/* generic-pre-method */obj_t generic_pre_method_24___object(obj_t generic_47)
{
{
obj_t symbol1499_3712;
symbol1499_3712 = symbol3234___object;
{
PUSH_TRACE(symbol1499_3712);
BUNSPEC;
{
obj_t aux1498_3713;
aux1498_3713 = PROCEDURE_REF(generic_47, ((long)2));
POP_TRACE();
return aux1498_3713;
}
}
}
}


/* _generic-pre-method1551 */obj_t _generic_pre_method1551_28___object(obj_t env_1979, obj_t generic_1980)
{
{
obj_t generic_3714;
if(PROCEDUREP(generic_1980)){
generic_3714 = generic_1980;
}
 else {
bigloo_type_error_location_103___error(symbol3235___object, string3209___object, generic_1980, string3191___object, BINT(((long)18956)));
exit( -1 );}
{
obj_t symbol1499_3715;
symbol1499_3715 = symbol3234___object;
{
PUSH_TRACE(symbol1499_3715);
BUNSPEC;
{
obj_t aux1498_3716;
aux1498_3716 = PROCEDURE_REF(generic_3714, ((long)2));
POP_TRACE();
return aux1498_3716;
}
}
}
}
}


/* generic-pre-method-set! */obj_t generic_pre_method_set__80___object(obj_t generic_48, obj_t pre_method_105_49)
{
{
obj_t symbol1501_3717;
symbol1501_3717 = symbol3236___object;
{
PUSH_TRACE(symbol1501_3717);
BUNSPEC;
{
obj_t aux1500_3718;
aux1500_3718 = PROCEDURE_SET(generic_48, ((long)2), pre_method_105_49);
POP_TRACE();
return aux1500_3718;
}
}
}
}


/* _generic-pre-method-set!1552 */obj_t _generic_pre_method_set_1552_229___object(obj_t env_1981, obj_t generic_1982, obj_t pre_method_105_1983)
{
{
obj_t generic_3719;
obj_t pre_method_105_3720;
if(PROCEDUREP(generic_1982)){
generic_3719 = generic_1982;
}
 else {
bigloo_type_error_location_103___error(symbol3237___object, string3209___object, generic_1982, string3191___object, BINT(((long)19253)));
exit( -1 );}
pre_method_105_3720 = pre_method_105_1983;
{
obj_t symbol1501_3721;
symbol1501_3721 = symbol3236___object;
{
PUSH_TRACE(symbol1501_3721);
BUNSPEC;
{
obj_t aux1500_3722;
aux1500_3722 = PROCEDURE_SET(generic_3719, ((long)2), pre_method_105_3720);
POP_TRACE();
return aux1500_3722;
}
}
}
}
}


/* method-array-ref */obj_t method_array_ref_188___object(obj_t array_50, long offset_51)
{
{
long arg1044_3723;
{
long arg1045_3724;
arg1045_3724 = OBJECT_TYPE;
arg1044_3723 = (offset_51-arg1045_3724);
}
return VECTOR_REF(array_50, arg1044_3723);
}
}


/* _method-array-ref1553 */obj_t _method_array_ref1553_55___object(obj_t env_1984, obj_t array_1985, obj_t offset_1986)
{
{
obj_t array_3725;
long offset_3726;
if(VECTORP(array_1985)){
array_3725 = array_1985;
}
 else {
bigloo_type_error_location_103___error(symbol3238___object, string3190___object, array_1985, string3191___object, BINT(((long)19578)));
exit( -1 );}
{
obj_t aux_4965;
if(INTEGERP(offset_1986)){
aux_4965 = offset_1986;
}
 else {
bigloo_type_error_location_103___error(symbol3238___object, string3199___object, offset_1986, string3191___object, BINT(((long)19578)));
exit( -1 );}
offset_3726 = (long)CINT(aux_4965);
}
{
long arg1044_3727;
{
long arg1045_3728;
arg1045_3728 = OBJECT_TYPE;
arg1044_3727 = (offset_3726-arg1045_3728);
}
return VECTOR_REF(array_3725, arg1044_3727);
}
}
}


/* generics-add-class! */obj_t generics_add_class__12___object(long class_num_218_55, long super_num_34_56)
{
{
obj_t symbol1503_1890;
symbol1503_1890 = symbol3239___object;
{
PUSH_TRACE(symbol1503_1890);
BUNSPEC;
{
obj_t aux1502_1891;
{
long g_401;
g_401 = ((long)0);
loop_402:
{
bool_t test1048_403;
{
long n2_1046;
{
obj_t aux_4976;
{
obj_t aux1932_2369;
aux1932_2369 = _nb_generics__142___object;
if(INTEGERP(aux1932_2369)){
aux_4976 = aux1932_2369;
}
 else {
bigloo_type_error_location_103___error(symbol3239___object, string3199___object, aux1932_2369, string3191___object, BINT(((long)20501)));
exit( -1 );}
}
n2_1046 = (long)CINT(aux_4976);
}
test1048_403 = (g_401==n2_1046);
}
if(test1048_403){
aux1502_1891 = symbol3218___object;
}
 else {
obj_t generic_404;
{
obj_t vector_1047;
vector_1047 = _generics__29___object;
{
bool_t test1338_1049;
{
long aux_4985;
aux_4985 = VECTOR_LENGTH(vector_1047);
test1338_1049 = BOUND_CHECK(g_401, aux_4985);
}
if(test1338_1049){
generic_404 = VECTOR_REF(vector_1047, g_401);
}
 else {
generic_404 = debug_error_location_199___error(string3195___object, string3196___object, BINT(g_401), string3197___object, BINT(((long)7610)));
}
}
}
{
obj_t method_array_88_405;
{
obj_t generic_1055;
if(PROCEDUREP(generic_404)){
generic_1055 = generic_404;
}
 else {
bigloo_type_error_location_103___error(symbol3239___object, string3209___object, generic_404, string3191___object, BINT(((long)20596)));
exit( -1 );}
method_array_88_405 = PROCEDURE_REF(generic_1055, ((long)1));
}
{
{
obj_t arg1049_406;
{
obj_t array_1056;
if(VECTORP(method_array_88_405)){
array_1056 = method_array_88_405;
}
 else {
bigloo_type_error_location_103___error(symbol3239___object, string3190___object, method_array_88_405, string3191___object, BINT(((long)20685)));
exit( -1 );}
{
long arg1044_1058;
{
long arg1045_1059;
arg1045_1059 = OBJECT_TYPE;
arg1044_1058 = (super_num_34_56-arg1045_1059);
}
arg1049_406 = VECTOR_REF(array_1056, arg1044_1058);
}
}
{
long arg1046_1067;
{
long arg1047_1068;
arg1047_1068 = OBJECT_TYPE;
arg1046_1067 = (class_num_218_55-arg1047_1068);
}
{
obj_t vector_1071;
if(VECTORP(method_array_88_405)){
vector_1071 = method_array_88_405;
}
 else {
bigloo_type_error_location_103___error(symbol3239___object, string3190___object, method_array_88_405, string3191___object, BINT(((long)19971)));
exit( -1 );}
VECTOR_SET(vector_1071, arg1046_1067, arg1049_406);
}
}
}
{
long g_5015;
g_5015 = (g_401+((long)1));
g_401 = g_5015;
goto loop_402;
}
}
}
}
}
}
POP_TRACE();
return aux1502_1891;
}
}
}
}


/* add-class! */obj_t add_class__117___object(obj_t name_57, obj_t super_58, obj_t allocate_59, long hash_60, obj_t def_61, obj_t constructor_62)
{
{
obj_t symbol1505_1892;
symbol1505_1892 = symbol3240___object;
{
PUSH_TRACE(symbol1505_1892);
BUNSPEC;
{
obj_t aux1504_1893;
initialize_objects__138___object();
{
bool_t test1051_408;
if(CBOOL(super_58)){
bool_t test1052_409;
{
bool_t res1419_1084;
{
bool_t _andtest_1006_1077;
_andtest_1006_1077 = VECTORP(super_58);
if(_andtest_1006_1077){
long arg1021_1078;
{
obj_t vector_1081;
if(_andtest_1006_1077){
vector_1081 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1078 = VECTOR_LENGTH(vector_1081);
}
res1419_1084 = (arg1021_1078==((long)10));
}
 else {
res1419_1084 = ((bool_t)0);
}
}
test1052_409 = res1419_1084;
}
if(test1052_409){
test1051_408 = ((bool_t)0);
}
 else {
test1051_408 = ((bool_t)1);
}
}
 else {
test1051_408 = ((bool_t)0);
}
if(test1051_408){
debug_error_location_199___error(string3241___object, string3242___object, name_57, string3197___object, BINT(((long)7610)));
}
 else {
BUNSPEC;
}
}
{
bool_t test1053_410;
{
long n1_1088;
long n2_1089;
{
obj_t aux_5034;
{
obj_t aux1964_2399;
aux1964_2399 = _nb_classes__240___object;
if(INTEGERP(aux1964_2399)){
aux_5034 = aux1964_2399;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux1964_2399, string3191___object, BINT(((long)21192)));
exit( -1 );}
}
n1_1088 = (long)CINT(aux_5034);
}
{
obj_t aux_5041;
{
obj_t aux1973_2405;
aux1973_2405 = _nb_classes_max__8___object;
if(INTEGERP(aux1973_2405)){
aux_5041 = aux1973_2405;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux1973_2405, string3191___object, BINT(((long)21196)));
exit( -1 );}
}
n2_1089 = (long)CINT(aux_5041);
}
test1053_410 = (n1_1088==n2_1089);
}
if(test1053_410){
double_nb_classes__118___object();
}
 else {
BUNSPEC;
}
}
{
long num_411;
{
long arg1067_428;
arg1067_428 = OBJECT_TYPE;
{
long z2_1091;
{
obj_t aux_5052;
{
obj_t aux1980_2411;
aux1980_2411 = _nb_classes__240___object;
if(INTEGERP(aux1980_2411)){
aux_5052 = aux1980_2411;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux1980_2411, string3191___object, BINT(((long)21277)));
exit( -1 );}
}
z2_1091 = (long)CINT(aux_5052);
}
num_411 = (arg1067_428+z2_1091);
}
}
{
long depth_412;
{
bool_t test1063_425;
{
bool_t res1420_1100;
{
bool_t _andtest_1006_1093;
_andtest_1006_1093 = VECTORP(super_58);
if(_andtest_1006_1093){
long arg1021_1094;
{
obj_t vector_1097;
if(_andtest_1006_1093){
vector_1097 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1094 = VECTOR_LENGTH(vector_1097);
}
res1420_1100 = (arg1021_1094==((long)10));
}
 else {
res1420_1100 = ((bool_t)0);
}
}
test1063_425 = res1420_1100;
}
if(test1063_425){
long arg1065_426;
{
long res1421_1104;
{
obj_t vector_1102;
if(VECTORP(super_58)){
vector_1102 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)7614)));
exit( -1 );}
{
obj_t aux_5074;
{
obj_t aux2001_2429;
aux2001_2429 = VECTOR_REF(vector_1102, ((long)2));
if(INTEGERP(aux2001_2429)){
aux_5074 = aux2001_2429;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux2001_2429, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1421_1104 = (long)CINT(aux_5074);
}
}
arg1065_426 = res1421_1104;
}
depth_412 = (arg1065_426+((long)1));
}
 else {
depth_412 = ((long)1);
}
}
{
obj_t ancestors_413;
{
bool_t test1060_421;
{
bool_t res1422_1115;
{
bool_t _andtest_1006_1108;
_andtest_1006_1108 = VECTORP(super_58);
if(_andtest_1006_1108){
long arg1021_1109;
{
obj_t vector_1112;
if(_andtest_1006_1108){
vector_1112 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1109 = VECTOR_LENGTH(vector_1112);
}
res1422_1115 = (arg1021_1109==((long)10));
}
 else {
res1422_1115 = ((bool_t)0);
}
}
test1060_421 = res1422_1115;
}
if(test1060_421){
obj_t arg1061_422;
{
obj_t vector_1117;
if(VECTORP(super_58)){
vector_1117 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)11347)));
exit( -1 );}
arg1061_422 = VECTOR_REF(vector_1117, ((long)5));
}
ancestors_413 = extend_vector_160___object(arg1061_422, super_58, ((long)1));
}
 else {
obj_t v1008_424;
v1008_424 = create_vector(((long)1));
VECTOR_SET(v1008_424, ((long)0), super_58);
ancestors_413 = v1008_424;
}
}
{
obj_t class_414;
{
obj_t name_1122;
if(SYMBOLP(name_57)){
name_1122 = name_57;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3193___object, name_57, string3191___object, BINT(((long)21519)));
exit( -1 );}
{
obj_t v1005_1132;
v1005_1132 = create_vector(((long)10));
VECTOR_SET(v1005_1132, ((long)9), constructor_62);
VECTOR_SET(v1005_1132, ((long)8), def_61);
{
obj_t aux_5109;
aux_5109 = BINT(hash_60);
VECTOR_SET(v1005_1132, ((long)7), aux_5109);
}
VECTOR_SET(v1005_1132, ((long)6), allocate_59);
VECTOR_SET(v1005_1132, ((long)5), ancestors_413);
VECTOR_SET(v1005_1132, ((long)4), BNIL);
VECTOR_SET(v1005_1132, ((long)3), super_58);
{
obj_t aux_5116;
aux_5116 = BINT(depth_412);
VECTOR_SET(v1005_1132, ((long)2), aux_5116);
}
{
obj_t aux_5119;
aux_5119 = BINT(num_411);
VECTOR_SET(v1005_1132, ((long)1), aux_5119);
}
VECTOR_SET(v1005_1132, ((long)0), name_1122);
class_414 = v1005_1132;
}
}
{
{
bool_t test1054_415;
{
bool_t res1423_1171;
{
bool_t _andtest_1006_1164;
_andtest_1006_1164 = VECTORP(super_58);
if(_andtest_1006_1164){
long arg1021_1165;
{
obj_t vector_1168;
if(_andtest_1006_1164){
vector_1168 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1165 = VECTOR_LENGTH(vector_1168);
}
res1423_1171 = (arg1021_1165==((long)10));
}
 else {
res1423_1171 = ((bool_t)0);
}
}
test1054_415 = res1423_1171;
}
if(test1054_415){
obj_t arg1055_416;
{
obj_t arg1056_417;
{
obj_t vector_1173;
if(VECTORP(super_58)){
vector_1173 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)10761)));
exit( -1 );}
{
bool_t test1338_1175;
{
long aux_5137;
aux_5137 = VECTOR_LENGTH(vector_1173);
test1338_1175 = BOUND_CHECK(((long)4), aux_5137);
}
if(test1338_1175){
arg1056_417 = VECTOR_REF(vector_1173, ((long)4));
}
 else {
arg1056_417 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)4)), string3197___object, BINT(((long)7610)));
}
}
}
arg1055_416 = MAKE_PAIR(class_414, arg1056_417);
}
{
obj_t vector_1185;
if(VECTORP(super_58)){
vector_1185 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)11059)));
exit( -1 );}
VECTOR_SET(vector_1185, ((long)4), arg1055_416);
}
}
 else {
BUNSPEC;
}
}
{
obj_t vector_1188;
long k_1189;
{
obj_t aux2047_2471;
aux2047_2471 = _classes__134___object;
if(VECTORP(aux2047_2471)){
vector_1188 = aux2047_2471;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, aux2047_2471, string3191___object, BINT(((long)21869)));
exit( -1 );}
}
{
obj_t aux_5157;
{
obj_t aux2053_2477;
aux2053_2477 = _nb_classes__240___object;
if(INTEGERP(aux2053_2477)){
aux_5157 = aux2053_2477;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux2053_2477, string3191___object, BINT(((long)21869)));
exit( -1 );}
}
k_1189 = (long)CINT(aux_5157);
}
{
bool_t test1335_1191;
{
long aux_5164;
aux_5164 = VECTOR_LENGTH(vector_1188);
test1335_1191 = BOUND_CHECK(k_1189, aux_5164);
}
if(test1335_1191){
VECTOR_SET(vector_1188, k_1189, class_414);
}
 else {
debug_error_location_199___error(string3243___object, string3196___object, BINT(k_1189), string3197___object, BINT(((long)7610)));
}
}
}
{
long z1_1197;
{
obj_t aux_5172;
{
obj_t aux2059_2483;
aux2059_2483 = _nb_classes__240___object;
if(INTEGERP(aux2059_2483)){
aux_5172 = aux2059_2483;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux2059_2483, string3191___object, BINT(((long)21983)));
exit( -1 );}
}
z1_1197 = (long)CINT(aux_5172);
}
{
long aux_5179;
aux_5179 = (z1_1197+((long)1));
_nb_classes__240___object = BINT(aux_5179);
}
}
{
long arg1057_418;
{
bool_t test1058_419;
{
bool_t res1424_1207;
{
bool_t _andtest_1006_1200;
_andtest_1006_1200 = VECTORP(super_58);
if(_andtest_1006_1200){
long arg1021_1201;
{
obj_t vector_1204;
if(_andtest_1006_1200){
vector_1204 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1201 = VECTOR_LENGTH(vector_1204);
}
res1424_1207 = (arg1021_1201==((long)10));
}
 else {
res1424_1207 = ((bool_t)0);
}
}
test1058_419 = res1424_1207;
}
if(test1058_419){
long res1425_1211;
{
obj_t vector_1209;
if(VECTORP(super_58)){
vector_1209 = super_58;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3190___object, super_58, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5196;
{
obj_t aux2077_2501;
aux2077_2501 = VECTOR_REF(vector_1209, ((long)1));
if(INTEGERP(aux2077_2501)){
aux_5196 = aux2077_2501;
}
 else {
bigloo_type_error_location_103___error(symbol3240___object, string3199___object, aux2077_2501, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1425_1211 = (long)CINT(aux_5196);
}
}
arg1057_418 = res1425_1211;
}
 else {
arg1057_418 = num_411;
}
}
generics_add_class__12___object(num_411, arg1057_418);
}
aux1504_1893 = class_414;
}
}
}
}
}
POP_TRACE();
return aux1504_1893;
}
}
}
}


/* _add-class!1554 */obj_t _add_class_1554_219___object(obj_t env_1987, obj_t name_1988, obj_t super_1989, obj_t allocate_1990, obj_t hash_1991, obj_t def_1992, obj_t constructor_1993)
{
{
long aux_5212;
obj_t aux_5206;
{
obj_t aux_5213;
if(INTEGERP(hash_1991)){
aux_5213 = hash_1991;
}
 else {
bigloo_type_error_location_103___error(symbol3244___object, string3199___object, hash_1991, string3191___object, BINT(((long)20977)));
exit( -1 );}
aux_5212 = (long)CINT(aux_5213);
}
if(PROCEDUREP(allocate_1990)){
aux_5206 = allocate_1990;
}
 else {
bigloo_type_error_location_103___error(symbol3244___object, string3209___object, allocate_1990, string3191___object, BINT(((long)20977)));
exit( -1 );}
return add_class__117___object(name_1988, super_1989, aux_5206, aux_5212, def_1992, constructor_1993);
}
}


/* add-generic! */obj_t add_generic__110___object(obj_t generic_64, obj_t default_65)
{
{
obj_t symbol1507_1894;
symbol1507_1894 = symbol3245___object;
{
PUSH_TRACE(symbol1507_1894);
BUNSPEC;
{
obj_t aux1506_1895;
{
bool_t test_5222;
{
obj_t aux_5223;
aux_5223 = PROCEDURE_REF(generic_64, ((long)1));
test_5222 = VECTORP(aux_5223);
}
if(test_5222){
{
bool_t test1070_431;
test1070_431 = PROCEDUREP(default_65);
if(test1070_431){
obj_t default_199_1221;
if(test1070_431){
default_199_1221 = default_65;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3209___object, default_65, string3191___object, BINT(((long)23568)));
exit( -1 );}
PROCEDURE_SET(generic_64, ((long)0), default_199_1221);
}
 else {
BUNSPEC;
}
}
aux1506_1895 = BUNSPEC;
}
 else {
{
bool_t test1071_432;
{
long n1_1222;
long n2_1223;
{
obj_t aux_5233;
{
obj_t aux2101_2525;
aux2101_2525 = _nb_generics__142___object;
if(INTEGERP(aux2101_2525)){
aux_5233 = aux2101_2525;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3199___object, aux2101_2525, string3191___object, BINT(((long)23081)));
exit( -1 );}
}
n1_1222 = (long)CINT(aux_5233);
}
{
obj_t aux_5240;
{
obj_t aux2108_2531;
aux2108_2531 = _nb_generics_max__185___object;
if(INTEGERP(aux2108_2531)){
aux_5240 = aux2108_2531;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3199___object, aux2108_2531, string3191___object, BINT(((long)23085)));
exit( -1 );}
}
n2_1223 = (long)CINT(aux_5240);
}
test1071_432 = (n1_1222==n2_1223);
}
if(test1071_432){
double_nb_generics__239___object();
}
 else {
BUNSPEC;
}
}
{
obj_t vector_1224;
long k_1225;
vector_1224 = _generics__29___object;
{
obj_t aux_5250;
{
obj_t aux2115_2537;
aux2115_2537 = _nb_generics__142___object;
if(INTEGERP(aux2115_2537)){
aux_5250 = aux2115_2537;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3199___object, aux2115_2537, string3191___object, BINT(((long)23151)));
exit( -1 );}
}
k_1225 = (long)CINT(aux_5250);
}
{
bool_t test1335_1227;
{
long aux_5257;
aux_5257 = VECTOR_LENGTH(vector_1224);
test1335_1227 = BOUND_CHECK(k_1225, aux_5257);
}
if(test1335_1227){
VECTOR_SET(vector_1224, k_1225, generic_64);
}
 else {
debug_error_location_199___error(string3243___object, string3196___object, BINT(k_1225), string3197___object, BINT(((long)7610)));
}
}
}
{
long z1_1233;
{
obj_t aux_5265;
{
obj_t aux2123_2543;
aux2123_2543 = _nb_generics__142___object;
if(INTEGERP(aux2123_2543)){
aux_5265 = aux2123_2543;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3199___object, aux2123_2543, string3191___object, BINT(((long)23221)));
exit( -1 );}
}
z1_1233 = (long)CINT(aux_5265);
}
{
long aux_5272;
aux_5272 = (z1_1233+((long)1));
_nb_generics__142___object = BINT(aux_5272);
}
}
{
obj_t arg1072_433;
if(PROCEDUREP(default_65)){
arg1072_433 = default_65;
}
 else {
obj_t lambda1074_1994;
lambda1074_1994 = proc3246___object;
arg1072_433 = lambda1074_1994;
}
{
obj_t default_199_1240;
if(PROCEDUREP(arg1072_433)){
default_199_1240 = arg1072_433;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3209___object, arg1072_433, string3191___object, BINT(((long)23247)));
exit( -1 );}
PROCEDURE_SET(generic_64, ((long)0), default_199_1240);
}
}
{
obj_t arg1076_437;
{
long aux_5283;
{
obj_t aux_5284;
{
obj_t aux2138_2555;
aux2138_2555 = _nb_classes_max__8___object;
if(INTEGERP(aux2138_2555)){
aux_5284 = aux2138_2555;
}
 else {
bigloo_type_error_location_103___error(symbol3245___object, string3199___object, aux2138_2555, string3191___object, BINT(((long)22724)));
exit( -1 );}
}
aux_5283 = (long)CINT(aux_5284);
}
arg1076_437 = make_vector(aux_5283, BFALSE);
}
PROCEDURE_SET(generic_64, ((long)1), arg1076_437);
}
aux1506_1895 = BUNSPEC;
}
}
POP_TRACE();
return aux1506_1895;
}
}
}
}


/* _add-generic!1555 */obj_t _add_generic_1555_154___object(obj_t env_1995, obj_t generic_1996, obj_t default_1997)
{
{
obj_t aux_5294;
if(PROCEDUREP(generic_1996)){
aux_5294 = generic_1996;
}
 else {
bigloo_type_error_location_103___error(symbol3247___object, string3209___object, generic_1996, string3191___object, BINT(((long)22982)));
exit( -1 );}
return add_generic__110___object(aux_5294, default_1997);
}
}


/* lambda1074 */obj_t lambda1074___object(obj_t env_1998, obj_t l_1999)
{
{
obj_t l_435;
l_435 = l_1999;
return debug_error_location_199___error(string3248___object, string3249___object, l_435, string3197___object, BINT(((long)7610)));
}
}


/* add-method/proc-or-num! */obj_t add_method_proc_or_num__68___object(obj_t generic_66, obj_t class_67, obj_t proc_or_num_128_68)
{
{
obj_t symbol1509_1896;
symbol1509_1896 = symbol3250___object;
{
PUSH_TRACE(symbol1509_1896);
BUNSPEC;
{
obj_t aux1508_1897;
{
bool_t test_5304;
{
obj_t aux_5305;
aux_5305 = PROCEDURE_REF(generic_66, ((long)1));
test_5304 = VECTORP(aux_5305);
}
if(test_5304){
BUNSPEC;
}
 else {
add_generic__110___object(generic_66, BFALSE);
}
}
{
obj_t method_array_88_439;
method_array_88_439 = PROCEDURE_REF(generic_66, ((long)1));
{
obj_t previous_440;
{
long arg1084_453;
{
long res1426_1251;
{
obj_t vector_1249;
if(VECTORP(class_67)){
vector_1249 = class_67;
}
 else {
bigloo_type_error_location_103___error(symbol3250___object, string3190___object, class_67, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5315;
{
obj_t aux2157_2573;
aux2157_2573 = VECTOR_REF(vector_1249, ((long)1));
if(INTEGERP(aux2157_2573)){
aux_5315 = aux2157_2573;
}
 else {
bigloo_type_error_location_103___error(symbol3250___object, string3199___object, aux2157_2573, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1426_1251 = (long)CINT(aux_5315);
}
}
arg1084_453 = res1426_1251;
}
{
obj_t array_1252;
if(VECTORP(method_array_88_439)){
array_1252 = method_array_88_439;
}
 else {
bigloo_type_error_location_103___error(symbol3250___object, string3190___object, method_array_88_439, string3191___object, BINT(((long)24135)));
exit( -1 );}
{
long arg1044_1254;
{
long arg1045_1255;
arg1045_1255 = OBJECT_TYPE;
arg1044_1254 = (arg1084_453-arg1045_1255);
}
previous_440 = VECTOR_REF(array_1252, arg1044_1254);
}
}
}
{
loop___object(proc_or_num_128_68, previous_440, method_array_88_439, class_67);
}
}
}
aux1508_1897 = proc_or_num_128_68;
POP_TRACE();
return aux1508_1897;
}
}
}
}


/* loop */obj_t loop___object(obj_t proc_or_num_128_2062, obj_t previous_2061, obj_t method_array_88_2060, obj_t class_441)
{
{
long cnum_443;
{
long res1427_1263;
{
obj_t vector_1261;
if(VECTORP(class_441)){
vector_1261 = class_441;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3190___object, class_441, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5338;
{
obj_t aux2176_2591;
aux2176_2591 = VECTOR_REF(vector_1261, ((long)1));
if(INTEGERP(aux2176_2591)){
aux_5338 = aux2176_2591;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3199___object, aux2176_2591, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1427_1263 = (long)CINT(aux_5338);
}
}
cnum_443 = res1427_1263;
}
{
obj_t current_444;
{
obj_t array_1264;
if(VECTORP(method_array_88_2060)){
array_1264 = method_array_88_2060;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3190___object, method_array_88_2060, string3191___object, BINT(((long)24268)));
exit( -1 );}
{
long arg1044_1266;
{
long arg1045_1267;
arg1045_1267 = OBJECT_TYPE;
arg1044_1266 = (cnum_443-arg1045_1267);
}
current_444 = VECTOR_REF(array_1264, arg1044_1266);
}
}
{
{
bool_t test_5354;
if(CBOOL(current_444)){
test_5354 = (current_444==previous_2061);
}
 else {
test_5354 = ((bool_t)1);
}
if(test_5354){
{
long arg1046_1277;
{
long arg1047_1278;
arg1047_1278 = OBJECT_TYPE;
arg1046_1277 = (cnum_443-arg1047_1278);
}
{
obj_t vector_1281;
if(VECTORP(method_array_88_2060)){
vector_1281 = method_array_88_2060;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3190___object, method_array_88_2060, string3191___object, BINT(((long)19971)));
exit( -1 );}
VECTOR_SET(vector_1281, arg1046_1277, proc_or_num_128_2062);
}
}
{
obj_t l1009_446;
{
obj_t arg1079_448;
{
obj_t vector_1285;
if(VECTORP(class_441)){
vector_1285 = class_441;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3190___object, class_441, string3191___object, BINT(((long)10761)));
exit( -1 );}
{
bool_t test1338_1287;
{
long aux_5371;
aux_5371 = VECTOR_LENGTH(vector_1285);
test1338_1287 = BOUND_CHECK(((long)4), aux_5371);
}
if(test1338_1287){
arg1079_448 = VECTOR_REF(vector_1285, ((long)4));
}
 else {
arg1079_448 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)4)), string3197___object, BINT(((long)7610)));
}
}
}
l1009_446 = arg1079_448;
lname1010_447:
{
bool_t test1080_449;
test1080_449 = PAIRP(l1009_446);
if(test1080_449){
{
obj_t arg1081_450;
{
obj_t pair_1294;
if(test1080_449){
pair_1294 = l1009_446;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3252___object, l1009_446, string3191___object, BINT(((long)24500)));
exit( -1 );}
arg1081_450 = CAR(pair_1294);
}
loop___object(proc_or_num_128_2062, previous_2061, method_array_88_2060, arg1081_450);
}
{
obj_t arg1082_451;
{
obj_t pair_1295;
if(PAIRP(l1009_446)){
pair_1295 = l1009_446;
}
 else {
bigloo_type_error_location_103___error(symbol3251___object, string3252___object, l1009_446, string3191___object, BINT(((long)24500)));
exit( -1 );}
arg1082_451 = CDR(pair_1295);
}
{
obj_t l1009_5393;
l1009_5393 = arg1082_451;
l1009_446 = l1009_5393;
goto lname1010_447;
}
}
}
 else {
if(NULLP(l1009_446)){
return BTRUE;
}
 else {
return debug_error_location_199___error(string3253___object, string3254___object, l1009_446, string3197___object, BINT(((long)7610)));
}
}
}
}
}
}
 else {
return BUNSPEC;
}
}
}
}
}
}


/* add-method! */obj_t add_method__1___object(obj_t generic_69, obj_t class_70, obj_t method_71)
{
{
obj_t symbol1511_1898;
symbol1511_1898 = symbol3255___object;
{
PUSH_TRACE(symbol1511_1898);
BUNSPEC;
{
obj_t aux1510_1899;
{
bool_t test1085_454;
{
bool_t res1428_1308;
{
bool_t _andtest_1006_1301;
_andtest_1006_1301 = VECTORP(class_70);
if(_andtest_1006_1301){
long arg1021_1302;
{
obj_t vector_1305;
if(_andtest_1006_1301){
vector_1305 = class_70;
}
 else {
bigloo_type_error_location_103___error(symbol3255___object, string3190___object, class_70, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1302 = VECTOR_LENGTH(vector_1305);
}
res1428_1308 = (arg1021_1302==((long)10));
}
 else {
res1428_1308 = ((bool_t)0);
}
}
test1085_454 = res1428_1308;
}
if(test1085_454){
bool_t test1086_455;
{
long arg1090_459;
long arg1091_460;
arg1090_459 = PROCEDURE_ARITY(generic_69);
arg1091_460 = PROCEDURE_ARITY(method_71);
test1086_455 = (arg1090_459==arg1091_460);
}
if(test1086_455){
{
obj_t aux2221_2633;
aux2221_2633 = add_method_proc_or_num__68___object(generic_69, class_70, method_71);
if(PROCEDUREP(aux2221_2633)){
aux1510_1899 = aux2221_2633;
}
 else {
bigloo_type_error_location_103___error(symbol3255___object, string3209___object, aux2221_2633, string3191___object, BINT(((long)25075)));
exit( -1 );}
}
}
 else {
{
obj_t arg1089_458;
arg1089_458 = MAKE_PAIR(generic_69, method_71);
{
obj_t aux2227_2639;
aux2227_2639 = debug_error_location_199___error(string3256___object, string3257___object, arg1089_458, string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux2227_2639)){
aux1510_1899 = aux2227_2639;
}
 else {
bigloo_type_error_location_103___error(symbol3255___object, string3209___object, aux2227_2639, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
}
 else {
{
obj_t aux2233_2645;
aux2233_2645 = debug_error_location_199___error(string3256___object, string3258___object, class_70, string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux2233_2645)){
aux1510_1899 = aux2233_2645;
}
 else {
bigloo_type_error_location_103___error(symbol3255___object, string3209___object, aux2233_2645, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1510_1899;
}
}
}
}


/* _add-method!1556 */obj_t _add_method_1556_144___object(obj_t env_2000, obj_t generic_2001, obj_t class_2002, obj_t method_2003)
{
{
obj_t aux_5440;
obj_t aux_5434;
if(PROCEDUREP(method_2003)){
aux_5440 = method_2003;
}
 else {
bigloo_type_error_location_103___error(symbol3259___object, string3209___object, method_2003, string3191___object, BINT(((long)24785)));
exit( -1 );}
if(PROCEDUREP(generic_2001)){
aux_5434 = generic_2001;
}
 else {
bigloo_type_error_location_103___error(symbol3259___object, string3209___object, generic_2001, string3191___object, BINT(((long)24785)));
exit( -1 );}
return add_method__1___object(aux_5434, class_2002, aux_5440);
}
}


/* add-inlined-method! */long add_inlined_method__244___object(obj_t generic_72, obj_t class_73, long method_num_210_74)
{
{
obj_t symbol1513_1900;
symbol1513_1900 = symbol3260___object;
{
PUSH_TRACE(symbol1513_1900);
BUNSPEC;
{
long aux1512_1901;
{
obj_t aux_5448;
{
obj_t aux2257_2663;
aux2257_2663 = add_method_proc_or_num__68___object(generic_72, class_73, BINT(method_num_210_74));
if(INTEGERP(aux2257_2663)){
aux_5448 = aux2257_2663;
}
 else {
bigloo_type_error_location_103___error(symbol3260___object, string3199___object, aux2257_2663, string3191___object, BINT(((long)25406)));
exit( -1 );}
}
aux1512_1901 = (long)CINT(aux_5448);
}
POP_TRACE();
return aux1512_1901;
}
}
}
}


/* _add-inlined-method!1557 */obj_t _add_inlined_method_1557_204___object(obj_t env_2004, obj_t generic_2005, obj_t class_2006, obj_t method_num_210_2007)
{
{
long aux_5458;
{
long aux_5465;
obj_t aux_5459;
{
obj_t aux_5466;
if(INTEGERP(method_num_210_2007)){
aux_5466 = method_num_210_2007;
}
 else {
bigloo_type_error_location_103___error(symbol3261___object, string3199___object, method_num_210_2007, string3191___object, BINT(((long)25348)));
exit( -1 );}
aux_5465 = (long)CINT(aux_5466);
}
if(PROCEDUREP(generic_2005)){
aux_5459 = generic_2005;
}
 else {
bigloo_type_error_location_103___error(symbol3261___object, string3209___object, generic_2005, string3191___object, BINT(((long)25348)));
exit( -1 );}
aux_5458 = add_inlined_method__244___object(aux_5459, class_2006, aux_5465);
}
return BINT(aux_5458);
}
}


/* find-method */obj_t find_method_204___object(object_t obj_75, obj_t generic_76)
{
{
obj_t symbol1515_3729;
symbol1515_3729 = symbol3262___object;
{
PUSH_TRACE(symbol1515_3729);
BUNSPEC;
{
obj_t aux1514_3730;
{
long obj_class_num_177_3731;
obj_class_num_177_3731 = TYPE( obj_75 );
{
obj_t arg1092_3732;
arg1092_3732 = PROCEDURE_REF(generic_76, ((long)1));
{
obj_t array_3733;
if(VECTORP(arg1092_3732)){
array_3733 = arg1092_3732;
}
 else {
bigloo_type_error_location_103___error(symbol3262___object, string3190___object, arg1092_3732, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_3734;
{
long arg1045_3735;
arg1045_3735 = OBJECT_TYPE;
arg1044_3734 = (obj_class_num_177_3731-arg1045_3735);
}
aux1514_3730 = VECTOR_REF(array_3733, arg1044_3734);
}
}
}
}
POP_TRACE();
return aux1514_3730;
}
}
}
}


/* _find-method1558 */obj_t _find_method1558_180___object(obj_t env_2008, obj_t obj_2009, obj_t generic_2010)
{
{
object_t obj_3740;
obj_t generic_3741;
{
bool_t test2283_2688;
{
bool_t res3418_3739;
{
obj_t obj_3736;
obj_3736 = obj_2009;
{
obj_t symbol1489_3737;
symbol1489_3737 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3737);
BUNSPEC;
{
bool_t aux1488_3738;
aux1488_3738 = (POINTERP( obj_3736 ) && (TYPE( obj_3736 ) >= OBJECT_TYPE));
POP_TRACE();
res3418_3739 = aux1488_3738;
}
}
}
}
test2283_2688 = res3418_3739;
}
if(test2283_2688){
obj_3740 = (object_t)(obj_2009);
}
 else {
bigloo_type_error_location_103___error(symbol3263___object, string3225___object, obj_2009, string3191___object, BINT(((long)25836)));
exit( -1 );}
}
if(PROCEDUREP(generic_2010)){
generic_3741 = generic_2010;
}
 else {
bigloo_type_error_location_103___error(symbol3263___object, string3209___object, generic_2010, string3191___object, BINT(((long)25836)));
exit( -1 );}
{
obj_t symbol1515_3742;
symbol1515_3742 = symbol3262___object;
{
PUSH_TRACE(symbol1515_3742);
BUNSPEC;
{
obj_t aux1514_3743;
{
long obj_class_num_177_3744;
obj_class_num_177_3744 = TYPE( obj_3740 );
{
obj_t arg1092_3745;
arg1092_3745 = PROCEDURE_REF(generic_3741, ((long)1));
{
obj_t array_3746;
if(VECTORP(arg1092_3745)){
array_3746 = arg1092_3745;
}
 else {
bigloo_type_error_location_103___error(symbol3262___object, string3190___object, arg1092_3745, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_3747;
{
long arg1045_3748;
arg1045_3748 = OBJECT_TYPE;
arg1044_3747 = (obj_class_num_177_3744-arg1045_3748);
}
aux1514_3743 = VECTOR_REF(array_3746, arg1044_3747);
}
}
}
}
POP_TRACE();
return aux1514_3743;
}
}
}
}
}


/* find-inline-method */obj_t find_inline_method_206___object(object_t obj_77, obj_t generic_78)
{
{
obj_t symbol1517_3749;
symbol1517_3749 = symbol3264___object;
{
PUSH_TRACE(symbol1517_3749);
BUNSPEC;
{
obj_t aux1516_3750;
{
obj_t pre_method_105_3751;
pre_method_105_3751 = PROCEDURE_REF(generic_78, ((long)2));
if(INTEGERP(pre_method_105_3751)){
PROCEDURE_SET(generic_78, ((long)2), BUNSPEC);
aux1516_3750 = pre_method_105_3751;
}
 else {
long obj_class_num_177_3752;
obj_class_num_177_3752 = TYPE( obj_77 );
{
obj_t arg1092_3753;
arg1092_3753 = PROCEDURE_REF(generic_78, ((long)1));
{
obj_t array_3754;
if(VECTORP(arg1092_3753)){
array_3754 = arg1092_3753;
}
 else {
bigloo_type_error_location_103___error(symbol3264___object, string3190___object, arg1092_3753, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_3755;
{
long arg1045_3756;
arg1045_3756 = OBJECT_TYPE;
arg1044_3755 = (obj_class_num_177_3752-arg1045_3756);
}
aux1516_3750 = VECTOR_REF(array_3754, arg1044_3755);
}
}
}
}
}
POP_TRACE();
return aux1516_3750;
}
}
}
}


/* _find-inline-method1559 */obj_t _find_inline_method1559_78___object(obj_t env_2011, obj_t obj_2012, obj_t generic_2013)
{
{
object_t obj_3761;
obj_t generic_3762;
{
bool_t test2302_2706;
{
bool_t res3419_3760;
{
obj_t obj_3757;
obj_3757 = obj_2012;
{
obj_t symbol1489_3758;
symbol1489_3758 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3758);
BUNSPEC;
{
bool_t aux1488_3759;
aux1488_3759 = (POINTERP( obj_3757 ) && (TYPE( obj_3757 ) >= OBJECT_TYPE));
POP_TRACE();
res3419_3760 = aux1488_3759;
}
}
}
}
test2302_2706 = res3419_3760;
}
if(test2302_2706){
obj_3761 = (object_t)(obj_2012);
}
 else {
bigloo_type_error_location_103___error(symbol3265___object, string3225___object, obj_2012, string3191___object, BINT(((long)26591)));
exit( -1 );}
}
if(PROCEDUREP(generic_2013)){
generic_3762 = generic_2013;
}
 else {
bigloo_type_error_location_103___error(symbol3265___object, string3209___object, generic_2013, string3191___object, BINT(((long)26591)));
exit( -1 );}
{
obj_t symbol1517_3763;
symbol1517_3763 = symbol3264___object;
{
PUSH_TRACE(symbol1517_3763);
BUNSPEC;
{
obj_t aux1516_3764;
{
obj_t pre_method_105_3765;
pre_method_105_3765 = PROCEDURE_REF(generic_3762, ((long)2));
if(INTEGERP(pre_method_105_3765)){
PROCEDURE_SET(generic_3762, ((long)2), BUNSPEC);
aux1516_3764 = pre_method_105_3765;
}
 else {
long obj_class_num_177_3766;
obj_class_num_177_3766 = TYPE( obj_3761 );
{
obj_t arg1092_3767;
arg1092_3767 = PROCEDURE_REF(generic_3762, ((long)1));
{
obj_t array_3768;
if(VECTORP(arg1092_3767)){
array_3768 = arg1092_3767;
}
 else {
bigloo_type_error_location_103___error(symbol3264___object, string3190___object, arg1092_3767, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_3769;
{
long arg1045_3770;
arg1045_3770 = OBJECT_TYPE;
arg1044_3769 = (obj_class_num_177_3766-arg1045_3770);
}
aux1516_3764 = VECTOR_REF(array_3768, arg1044_3769);
}
}
}
}
}
POP_TRACE();
return aux1516_3764;
}
}
}
}
}


/* find-super-class-method */obj_t find_super_class_method_167___object(object_t obj_79, obj_t generic_80, obj_t class_81)
{
{
obj_t super_465;
{
obj_t arg1094_467;
{
obj_t vector_1352;
if(VECTORP(class_81)){
vector_1352 = class_81;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3190___object, class_81, string3191___object, BINT(((long)10473)));
exit( -1 );}
{
bool_t test1338_1354;
{
long aux_5562;
aux_5562 = VECTOR_LENGTH(vector_1352);
test1338_1354 = BOUND_CHECK(((long)3), aux_5562);
}
if(test1338_1354){
arg1094_467 = VECTOR_REF(vector_1352, ((long)3));
}
 else {
arg1094_467 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
super_465 = arg1094_467;
loop_466:
{
bool_t test1095_468;
{
bool_t res1429_1368;
{
bool_t _andtest_1006_1361;
_andtest_1006_1361 = VECTORP(super_465);
if(_andtest_1006_1361){
long arg1021_1362;
{
obj_t vector_1365;
if(_andtest_1006_1361){
vector_1365 = super_465;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3190___object, super_465, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1362 = VECTOR_LENGTH(vector_1365);
}
res1429_1368 = (arg1021_1362==((long)10));
}
 else {
res1429_1368 = ((bool_t)0);
}
}
test1095_468 = res1429_1368;
}
if(test1095_468){
long obj_super_class_num_147_469;
{
long res1430_1372;
{
obj_t vector_1370;
if(VECTORP(super_465)){
vector_1370 = super_465;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3190___object, super_465, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5584;
{
obj_t aux2329_2729;
aux2329_2729 = VECTOR_REF(vector_1370, ((long)1));
if(INTEGERP(aux2329_2729)){
aux_5584 = aux2329_2729;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3199___object, aux2329_2729, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1430_1372 = (long)CINT(aux_5584);
}
}
obj_super_class_num_147_469 = res1430_1372;
}
{
obj_t method_470;
{
obj_t arg1096_472;
arg1096_472 = PROCEDURE_REF(generic_80, ((long)1));
{
obj_t array_1374;
if(VECTORP(arg1096_472)){
array_1374 = arg1096_472;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3190___object, arg1096_472, string3191___object, BINT(((long)27431)));
exit( -1 );}
{
long arg1044_1376;
{
long arg1045_1377;
arg1045_1377 = OBJECT_TYPE;
arg1044_1376 = (obj_super_class_num_147_469-arg1045_1377);
}
method_470 = VECTOR_REF(array_1374, arg1044_1376);
}
}
}
if(CBOOL(method_470)){
return method_470;
}
 else {
obj_t new_super_240_471;
{
obj_t vector_1383;
if(VECTORP(super_465)){
vector_1383 = super_465;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3190___object, super_465, string3191___object, BINT(((long)10473)));
exit( -1 );}
{
bool_t test1338_1385;
{
long aux_5608;
aux_5608 = VECTOR_LENGTH(vector_1383);
test1338_1385 = BOUND_CHECK(((long)3), aux_5608);
}
if(test1338_1385){
new_super_240_471 = VECTOR_REF(vector_1383, ((long)3));
}
 else {
new_super_240_471 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
{
obj_t super_5616;
super_5616 = new_super_240_471;
super_465 = super_5616;
goto loop_466;
}
}
}
}
 else {
obj_t res1431_1392;
{
obj_t aux2347_2747;
aux2347_2747 = PROCEDURE_REF(generic_80, ((long)0));
if(PROCEDUREP(aux2347_2747)){
res1431_1392 = aux2347_2747;
}
 else {
bigloo_type_error_location_103___error(symbol3266___object, string3209___object, aux2347_2747, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
return res1431_1392;
}
}
}
}
}


/* _find-super-class-method1560 */obj_t _find_super_class_method1560_155___object(obj_t env_2014, obj_t obj_2015, obj_t generic_2016, obj_t class_2017)
{
{
obj_t aux_5632;
object_t aux_5623;
if(PROCEDUREP(generic_2016)){
aux_5632 = generic_2016;
}
 else {
bigloo_type_error_location_103___error(symbol3267___object, string3209___object, generic_2016, string3191___object, BINT(((long)27206)));
exit( -1 );}
{
bool_t test2360_2760;
{
bool_t res3420_3774;
{
obj_t obj_3771;
obj_3771 = obj_2015;
{
obj_t symbol1489_3772;
symbol1489_3772 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3772);
BUNSPEC;
{
bool_t aux1488_3773;
aux1488_3773 = (POINTERP( obj_3771 ) && (TYPE( obj_3771 ) >= OBJECT_TYPE));
POP_TRACE();
res3420_3774 = aux1488_3773;
}
}
}
}
test2360_2760 = res3420_3774;
}
if(test2360_2760){
aux_5623 = (object_t)(obj_2015);
}
 else {
bigloo_type_error_location_103___error(symbol3267___object, string3225___object, obj_2015, string3191___object, BINT(((long)27206)));
exit( -1 );}
}
return find_super_class_method_167___object(aux_5623, aux_5632, class_2017);
}
}


/* find-method-from */obj_t find_method_from_44___object(object_t obj_82, obj_t generic_83, obj_t class_84)
{
{
obj_t symbol1519_1906;
symbol1519_1906 = symbol3268___object;
{
PUSH_TRACE(symbol1519_1906);
BUNSPEC;
{
obj_t aux1518_1907;
{
obj_t class_473;
class_473 = class_84;
loop_474:
{
bool_t test1097_475;
{
bool_t res1432_1401;
{
bool_t _andtest_1006_1394;
_andtest_1006_1394 = VECTORP(class_473);
if(_andtest_1006_1394){
long arg1021_1395;
{
obj_t vector_1398;
if(_andtest_1006_1394){
vector_1398 = class_473;
}
 else {
bigloo_type_error_location_103___error(symbol3268___object, string3190___object, class_473, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1395 = VECTOR_LENGTH(vector_1398);
}
res1432_1401 = (arg1021_1395==((long)10));
}
 else {
res1432_1401 = ((bool_t)0);
}
}
test1097_475 = res1432_1401;
}
if(test1097_475){
long obj_super_class_num_147_476;
{
long res1433_1405;
{
obj_t vector_1403;
if(VECTORP(class_473)){
vector_1403 = class_473;
}
 else {
bigloo_type_error_location_103___error(symbol3268___object, string3190___object, class_473, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5654;
{
obj_t aux2385_2783;
aux2385_2783 = VECTOR_REF(vector_1403, ((long)1));
if(INTEGERP(aux2385_2783)){
aux_5654 = aux2385_2783;
}
 else {
bigloo_type_error_location_103___error(symbol3268___object, string3199___object, aux2385_2783, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1433_1405 = (long)CINT(aux_5654);
}
}
obj_super_class_num_147_476 = res1433_1405;
}
{
obj_t method_477;
{
obj_t arg1099_479;
arg1099_479 = PROCEDURE_REF(generic_83, ((long)1));
{
obj_t array_1407;
if(VECTORP(arg1099_479)){
array_1407 = arg1099_479;
}
 else {
bigloo_type_error_location_103___error(symbol3268___object, string3190___object, arg1099_479, string3191___object, BINT(((long)28031)));
exit( -1 );}
{
long arg1044_1409;
{
long arg1045_1410;
arg1045_1410 = OBJECT_TYPE;
arg1044_1409 = (obj_super_class_num_147_476-arg1045_1410);
}
method_477 = VECTOR_REF(array_1407, arg1044_1409);
}
}
}
if(CBOOL(method_477)){
aux1518_1907 = MAKE_PAIR(class_473, method_477);
}
 else {
obj_t arg1098_478;
{
obj_t vector_1418;
if(VECTORP(class_473)){
vector_1418 = class_473;
}
 else {
bigloo_type_error_location_103___error(symbol3268___object, string3190___object, class_473, string3191___object, BINT(((long)10473)));
exit( -1 );}
{
bool_t test1338_1420;
{
long aux_5679;
aux_5679 = VECTOR_LENGTH(vector_1418);
test1338_1420 = BOUND_CHECK(((long)3), aux_5679);
}
if(test1338_1420){
arg1098_478 = VECTOR_REF(vector_1418, ((long)3));
}
 else {
arg1098_478 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
{
obj_t class_5687;
class_5687 = arg1098_478;
class_473 = class_5687;
goto loop_474;
}
}
}
}
 else {
aux1518_1907 = MAKE_PAIR(BFALSE, BFALSE);
}
}
}
POP_TRACE();
return aux1518_1907;
}
}
}
}


/* _find-method-from1561 */obj_t _find_method_from1561_159___object(obj_t env_2018, obj_t obj_2019, obj_t generic_2020, obj_t class_2021)
{
{
obj_t aux_5699;
object_t aux_5690;
if(PROCEDUREP(generic_2020)){
aux_5699 = generic_2020;
}
 else {
bigloo_type_error_location_103___error(symbol3269___object, string3209___object, generic_2020, string3191___object, BINT(((long)27840)));
exit( -1 );}
{
bool_t test2409_2802;
{
bool_t res3421_3778;
{
obj_t obj_3775;
obj_3775 = obj_2019;
{
obj_t symbol1489_3776;
symbol1489_3776 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3776);
BUNSPEC;
{
bool_t aux1488_3777;
aux1488_3777 = (POINTERP( obj_3775 ) && (TYPE( obj_3775 ) >= OBJECT_TYPE));
POP_TRACE();
res3421_3778 = aux1488_3777;
}
}
}
}
test2409_2802 = res3421_3778;
}
if(test2409_2802){
aux_5690 = (object_t)(obj_2019);
}
 else {
bigloo_type_error_location_103___error(symbol3269___object, string3225___object, obj_2019, string3191___object, BINT(((long)27840)));
exit( -1 );}
}
return find_method_from_44___object(aux_5690, aux_5699, class_2021);
}
}


/* next-class-num */long next_class_num_45___object(long num_85)
{
if((num_85<((long)0))){
return ((long)-1);
}
 else {
bool_t test1101_481;
{
long n2_1431;
{
obj_t aux_5708;
{
obj_t aux2420_2813;
aux2420_2813 = _nb_classes__240___object;
if(INTEGERP(aux2420_2813)){
aux_5708 = aux2420_2813;
}
 else {
bigloo_type_error_location_103___error(symbol3270___object, string3199___object, aux2420_2813, string3191___object, BINT(((long)28510)));
exit( -1 );}
}
n2_1431 = (long)CINT(aux_5708);
}
test1101_481 = (num_85>=n2_1431);
}
if(test1101_481){
return ((long)-1);
}
 else {
{
obj_t class_482;
{
obj_t vector_1432;
{
obj_t aux2426_2819;
aux2426_2819 = _classes__134___object;
if(VECTORP(aux2426_2819)){
vector_1432 = aux2426_2819;
}
 else {
bigloo_type_error_location_103___error(symbol3270___object, string3190___object, aux2426_2819, string3191___object, BINT(((long)28572)));
exit( -1 );}
}
class_482 = VECTOR_REF(vector_1432, num_85);
}
{
long res1434_1437;
{
obj_t vector_1435;
if(VECTORP(class_482)){
vector_1435 = class_482;
}
 else {
bigloo_type_error_location_103___error(symbol3270___object, string3190___object, class_482, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5728;
{
obj_t aux2438_2831;
aux2438_2831 = VECTOR_REF(vector_1435, ((long)1));
if(INTEGERP(aux2438_2831)){
aux_5728 = aux2438_2831;
}
 else {
bigloo_type_error_location_103___error(symbol3270___object, string3199___object, aux2438_2831, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1434_1437 = (long)CINT(aux_5728);
}
}
return res1434_1437;
}
}
}
}
}


/* _next-class-num1562 */obj_t _next_class_num1562_170___object(obj_t env_2022, obj_t num_2023)
{
{
long aux_5736;
{
long aux_5737;
{
obj_t aux_5738;
if(INTEGERP(num_2023)){
aux_5738 = num_2023;
}
 else {
bigloo_type_error_location_103___error(symbol3271___object, string3199___object, num_2023, string3191___object, BINT(((long)28417)));
exit( -1 );}
aux_5737 = (long)CINT(aux_5738);
}
aux_5736 = next_class_num_45___object(aux_5737);
}
return BINT(aux_5736);
}
}


/* is-a? */bool_t is_a__118___object(obj_t obj_86, obj_t class_87)
{
{
bool_t test1102_483;
test1102_483 = (POINTERP( obj_86 ) && (TYPE( obj_86 ) >= OBJECT_TYPE));
if(test1102_483){
bool_t test1103_484;
{
long arg1107_491;
long arg1108_492;
{
object_t obj_1439;
{
bool_t test2451_2844;
{
bool_t res3422_3782;
{
obj_t obj_3779;
obj_3779 = obj_86;
{
obj_t symbol1489_3780;
symbol1489_3780 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3780);
BUNSPEC;
{
bool_t aux1488_3781;
aux1488_3781 = (POINTERP( obj_3779 ) && (TYPE( obj_3779 ) >= OBJECT_TYPE));
POP_TRACE();
res3422_3782 = aux1488_3781;
}
}
}
}
test2451_2844 = res3422_3782;
}
if(test2451_2844){
obj_1439 = (object_t)(obj_86);
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3225___object, obj_86, string3191___object, BINT(((long)29066)));
exit( -1 );}
}
arg1107_491 = TYPE( obj_1439 );
}
{
long res1435_1443;
{
obj_t vector_1441;
if(VECTORP(class_87)){
vector_1441 = class_87;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3190___object, class_87, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_5763;
{
obj_t aux2462_2855;
aux2462_2855 = VECTOR_REF(vector_1441, ((long)1));
if(INTEGERP(aux2462_2855)){
aux_5763 = aux2462_2855;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3199___object, aux2462_2855, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1435_1443 = (long)CINT(aux_5763);
}
}
arg1108_492 = res1435_1443;
}
test1103_484 = (arg1107_491==arg1108_492);
}
if(test1103_484){
return ((bool_t)1);
}
 else {
obj_t direct_class_91_485;
{
object_t object_1446;
{
bool_t test2469_2862;
{
bool_t res3423_3786;
{
obj_t obj_3783;
obj_3783 = obj_86;
{
obj_t symbol1489_3784;
symbol1489_3784 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3784);
BUNSPEC;
{
bool_t aux1488_3785;
aux1488_3785 = (POINTERP( obj_3783 ) && (TYPE( obj_3783 ) >= OBJECT_TYPE));
POP_TRACE();
res3423_3786 = aux1488_3785;
}
}
}
}
test2469_2862 = res3423_3786;
}
if(test2469_2862){
object_1446 = (object_t)(obj_86);
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3225___object, obj_86, string3191___object, BINT(((long)29140)));
exit( -1 );}
}
{
long arg1041_1447;
{
long arg1042_1448;
long arg1043_1449;
arg1042_1448 = TYPE( object_1446 );
arg1043_1449 = OBJECT_TYPE;
arg1041_1447 = (arg1042_1448-arg1043_1449);
}
{
obj_t vector_1453;
{
obj_t aux2474_2867;
aux2474_2867 = _classes__134___object;
if(VECTORP(aux2474_2867)){
vector_1453 = aux2474_2867;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3190___object, aux2474_2867, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
direct_class_91_485 = VECTOR_REF(vector_1453, arg1041_1447);
}
}
}
{
long direct_depth_224_486;
{
long res1436_1458;
{
obj_t vector_1456;
if(VECTORP(direct_class_91_485)){
vector_1456 = direct_class_91_485;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3190___object, direct_class_91_485, string3191___object, BINT(((long)7614)));
exit( -1 );}
{
obj_t aux_5795;
{
obj_t aux2487_2879;
aux2487_2879 = VECTOR_REF(vector_1456, ((long)2));
if(INTEGERP(aux2487_2879)){
aux_5795 = aux2487_2879;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3199___object, aux2487_2879, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1436_1458 = (long)CINT(aux_5795);
}
}
direct_depth_224_486 = res1436_1458;
}
{
long depth_487;
{
long res1437_1462;
{
obj_t vector_1460;
if(VECTORP(class_87)){
vector_1460 = class_87;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3190___object, class_87, string3191___object, BINT(((long)7614)));
exit( -1 );}
{
obj_t aux_5808;
{
obj_t aux2500_2891;
aux2500_2891 = VECTOR_REF(vector_1460, ((long)2));
if(INTEGERP(aux2500_2891)){
aux_5808 = aux2500_2891;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3199___object, aux2500_2891, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1437_1462 = (long)CINT(aux_5808);
}
}
depth_487 = res1437_1462;
}
{
if((depth_487<direct_depth_224_486)){
obj_t arg1105_489;
{
obj_t arg1106_490;
{
obj_t vector_1466;
if(VECTORP(direct_class_91_485)){
vector_1466 = direct_class_91_485;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3190___object, direct_class_91_485, string3191___object, BINT(((long)11347)));
exit( -1 );}
arg1106_490 = VECTOR_REF(vector_1466, ((long)5));
}
{
obj_t vector_1468;
if(VECTORP(arg1106_490)){
vector_1468 = arg1106_490;
}
 else {
bigloo_type_error_location_103___error(symbol3272___object, string3190___object, arg1106_490, string3191___object, BINT(((long)29290)));
exit( -1 );}
arg1105_489 = VECTOR_REF(vector_1468, depth_487);
}
}
return (arg1105_489==class_87);
}
 else {
return ((bool_t)0);
}
}
}
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _is-a? */obj_t _is_a__25___object(obj_t env_2024, obj_t obj_2025, obj_t class_2026)
{
{
bool_t aux_5831;
aux_5831 = is_a__118___object(obj_2025, class_2026);
return BBOOL(aux_5831);
}
}


/* struct->object */object_t struct__object_175___object(obj_t struct_102)
{
{
object_t arg1109_1472;
arg1109_1472 = allocate_instance_244___object(STRUCT_KEY(struct_102));
return struct_object__object_93___object(arg1109_1472, struct_102);
}
}


/* _struct->object1563 */obj_t _struct__object1563_129___object(obj_t env_2027, obj_t struct_2028)
{
{
object_t aux_5837;
{
obj_t aux_5838;
if(STRUCTP(struct_2028)){
aux_5838 = struct_2028;
}
 else {
bigloo_type_error_location_103___error(symbol3273___object, string3274___object, struct_2028, string3191___object, BINT(((long)31250)));
exit( -1 );}
aux_5837 = struct__object_175___object(aux_5838);
}
return (obj_t)(aux_5837);
}
}


/* allocate-instance */object_t allocate_instance_244___object(obj_t cname_103)
{
{
obj_t symbol1521_1908;
symbol1521_1908 = symbol3275___object;
{
PUSH_TRACE(symbol1521_1908);
BUNSPEC;
{
object_t aux1520_1909;
{
long i_495;
{
obj_t aux2581_2965;
i_495 = ((long)0);
loop_496:
{
bool_t test1111_497;
{
long n2_1476;
{
obj_t aux_5847;
{
obj_t aux2527_2915;
aux2527_2915 = _nb_classes__240___object;
if(INTEGERP(aux2527_2915)){
aux_5847 = aux2527_2915;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3199___object, aux2527_2915, string3191___object, BINT(((long)31682)));
exit( -1 );}
}
n2_1476 = (long)CINT(aux_5847);
}
test1111_497 = (i_495==n2_1476);
}
if(test1111_497){
aux2581_2965 = debug_error_location_199___error(string3276___object, string3277___object, cname_103, string3197___object, BINT(((long)7610)));
}
 else {
obj_t class_498;
{
obj_t vector_1480;
{
obj_t aux2533_2921;
aux2533_2921 = _classes__134___object;
if(VECTORP(aux2533_2921)){
vector_1480 = aux2533_2921;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3190___object, aux2533_2921, string3191___object, BINT(((long)31771)));
exit( -1 );}
}
class_498 = VECTOR_REF(vector_1480, i_495);
}
{
bool_t test1112_499;
{
obj_t arg1115_502;
{
obj_t res1438_1491;
{
obj_t vector_1483;
if(VECTORP(class_498)){
vector_1483 = class_498;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3190___object, class_498, string3191___object, BINT(((long)7060)));
exit( -1 );}
{
bool_t test1338_1485;
{
long aux_5869;
aux_5869 = VECTOR_LENGTH(vector_1483);
test1338_1485 = BOUND_CHECK(((long)0), aux_5869);
}
if(test1338_1485){
obj_t aux2545_2933;
aux2545_2933 = VECTOR_REF(vector_1483, ((long)0));
if(SYMBOLP(aux2545_2933)){
res1438_1491 = aux2545_2933;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3193___object, aux2545_2933, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2552_2939;
aux2552_2939 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)0)), string3197___object, BINT(((long)7610)));
if(SYMBOLP(aux2552_2939)){
res1438_1491 = aux2552_2939;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3193___object, aux2552_2939, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
arg1115_502 = res1438_1491;
}
test1112_499 = (arg1115_502==cname_103);
}
if(test1112_499){
obj_t fun1113_500;
{
obj_t res1439_1497;
{
obj_t vector_1495;
if(VECTORP(class_498)){
vector_1495 = class_498;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3190___object, class_498, string3191___object, BINT(((long)11629)));
exit( -1 );}
{
obj_t aux2566_2951;
aux2566_2951 = VECTOR_REF(vector_1495, ((long)6));
if(PROCEDUREP(aux2566_2951)){
res1439_1497 = aux2566_2951;
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3209___object, aux2566_2951, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
}
fun1113_500 = res1439_1497;
}
{
bool_t test2580_2964;
test2580_2964 = PROCEDURE_CORRECT_ARITYP(fun1113_500, ((long)0));
if(test2580_2964){
aux2581_2965 = PROCEDURE_ENTRY(fun1113_500)(fun1113_500, BEOA);
}
 else {
error_location_112___error(string3278___object, list3279___object, fun1113_500, string3191___object, BINT(((long)31844)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
 else {
long i_5907;
i_5907 = (i_495+((long)1));
i_495 = i_5907;
goto loop_496;
}
}
}
}
{
bool_t test2582_2966;
{
bool_t res3424_3790;
{
obj_t obj_3787;
obj_3787 = aux2581_2965;
{
obj_t symbol1489_3788;
symbol1489_3788 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3788);
BUNSPEC;
{
bool_t aux1488_3789;
aux1488_3789 = (POINTERP( obj_3787 ) && (TYPE( obj_3787 ) >= OBJECT_TYPE));
POP_TRACE();
res3424_3790 = aux1488_3789;
}
}
}
}
test2582_2966 = res3424_3790;
}
if(test2582_2966){
aux1520_1909 = (object_t)(aux2581_2965);
}
 else {
bigloo_type_error_location_103___error(symbol3275___object, string3225___object, aux2581_2965, string3191___object, BINT(((long)31649)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1520_1909;
}
}
}
}


/* _allocate-instance1564 */obj_t _allocate_instance1564_134___object(obj_t env_2029, obj_t cname_2030)
{
{
object_t aux_5918;
{
obj_t aux_5919;
if(SYMBOLP(cname_2030)){
aux_5919 = cname_2030;
}
 else {
bigloo_type_error_location_103___error(symbol3283___object, string3193___object, cname_2030, string3191___object, BINT(((long)31596)));
exit( -1 );}
aux_5918 = allocate_instance_244___object(aux_5919);
}
return (obj_t)(aux_5918);
}
}


/* wide-object? */bool_t wide_object__208___object(object_t object_104)
{
{
bool_t test_5927;
{
obj_t aux_5928;
aux_5928 = OBJECT_WIDENING(object_104);
test_5927 = CBOOL(aux_5928);
}
if(test_5927){
return ((bool_t)1);
}
 else {
return ((bool_t)0);
}
}
}


/* _wide-object?1565 */obj_t _wide_object_1565_204___object(obj_t env_2031, obj_t object_2032)
{
{
bool_t aux_5931;
{
object_t object_3795;
{
bool_t test2595_2978;
{
bool_t res3425_3794;
{
obj_t obj_3791;
obj_3791 = object_2032;
{
obj_t symbol1489_3792;
symbol1489_3792 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3792);
BUNSPEC;
{
bool_t aux1488_3793;
aux1488_3793 = (POINTERP( obj_3791 ) && (TYPE( obj_3791 ) >= OBJECT_TYPE));
POP_TRACE();
res3425_3794 = aux1488_3793;
}
}
}
}
test2595_2978 = res3425_3794;
}
if(test2595_2978){
object_3795 = (object_t)(object_2032);
}
 else {
bigloo_type_error_location_103___error(symbol3284___object, string3225___object, object_2032, string3191___object, BINT(((long)32123)));
exit( -1 );}
}
{
bool_t test_5940;
{
obj_t aux_5941;
aux_5941 = OBJECT_WIDENING(object_3795);
test_5940 = CBOOL(aux_5941);
}
if(test_5940){
aux_5931 = ((bool_t)1);
}
 else {
aux_5931 = ((bool_t)0);
}
}
}
return BBOOL(aux_5931);
}
}


/* object-write/display */obj_t object_write_display_42___object(object_t obj_105, obj_t port_106, bool_t flag_107)
{
{
obj_t symbol1523_1910;
symbol1523_1910 = symbol3285___object;
{
PUSH_TRACE(symbol1523_1910);
BUNSPEC;
{
obj_t aux1522_1911;
{
obj_t field_530;
{
obj_t class_505;
{
long arg1041_1502;
{
long arg1042_1503;
long arg1043_1504;
arg1042_1503 = TYPE( obj_105 );
arg1043_1504 = OBJECT_TYPE;
arg1041_1502 = (arg1042_1503-arg1043_1504);
}
{
obj_t vector_1508;
{
obj_t aux2707_3089;
aux2707_3089 = _classes__134___object;
if(VECTORP(aux2707_3089)){
vector_1508 = aux2707_3089;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, aux2707_3089, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
class_505 = VECTOR_REF(vector_1508, arg1041_1502);
}
}
{
obj_t class_name_139_506;
{
obj_t res1440_1519;
{
obj_t vector_1511;
if(VECTORP(class_505)){
vector_1511 = class_505;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, class_505, string3191___object, BINT(((long)7060)));
exit( -1 );}
{
bool_t test1338_1513;
{
long aux_5960;
aux_5960 = VECTOR_LENGTH(vector_1511);
test1338_1513 = BOUND_CHECK(((long)0), aux_5960);
}
if(test1338_1513){
obj_t aux2719_3101;
aux2719_3101 = VECTOR_REF(vector_1511, ((long)0));
if(SYMBOLP(aux2719_3101)){
res1440_1519 = aux2719_3101;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3193___object, aux2719_3101, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2726_3107;
aux2726_3107 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)0)), string3197___object, BINT(((long)7610)));
if(SYMBOLP(aux2726_3107)){
res1440_1519 = aux2726_3107;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3193___object, aux2726_3107, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
class_name_139_506 = res1440_1519;
}
{
obj_t fields_507;
fields_507 = class_fields_215___object(class_505);
{
{
obj_t list1117_508;
list1117_508 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(string3295___object, list1117_508);
}
{
obj_t list1119_510;
list1119_510 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(class_name_139_506, list1119_510);
}
{
bool_t test_5983;
{
bool_t _ortest_1007_1521;
_ortest_1007_1521 = PAIRP(fields_507);
if(_ortest_1007_1521){
test_5983 = _ortest_1007_1521;
}
 else {
test_5983 = NULLP(fields_507);
}
}
if(test_5983){
obj_t fields_513;
obj_t class_514;
fields_513 = fields_507;
class_514 = class_505;
loop_515:
if(NULLP(fields_513)){
{
obj_t super_517;
{
obj_t vector_1527;
if(VECTORP(class_514)){
vector_1527 = class_514;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, class_514, string3191___object, BINT(((long)10473)));
exit( -1 );}
{
bool_t test1338_1529;
{
long aux_5994;
aux_5994 = VECTOR_LENGTH(vector_1527);
test1338_1529 = BOUND_CHECK(((long)3), aux_5994);
}
if(test1338_1529){
super_517 = VECTOR_REF(vector_1527, ((long)3));
}
 else {
super_517 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
{
bool_t test1123_518;
{
bool_t res1442_1543;
{
bool_t _andtest_1006_1536;
_andtest_1006_1536 = VECTORP(super_517);
if(_andtest_1006_1536){
long arg1021_1537;
{
obj_t vector_1540;
if(_andtest_1006_1536){
vector_1540 = super_517;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, super_517, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1537 = VECTOR_LENGTH(vector_1540);
}
res1442_1543 = (arg1021_1537==((long)10));
}
 else {
res1442_1543 = ((bool_t)0);
}
}
test1123_518 = res1442_1543;
}
if(test1123_518){
obj_t arg1124_519;
arg1124_519 = class_fields_215___object(super_517);
{
obj_t class_6013;
obj_t fields_6012;
fields_6012 = arg1124_519;
class_6013 = super_517;
class_514 = class_6013;
fields_513 = fields_6012;
goto loop_515;
}
}
 else {
obj_t list1125_520;
list1125_520 = MAKE_PAIR(port_106, BNIL);
aux1522_1911 = display___r4_output_6_10_3(BCHAR(((unsigned char)'|')), list1125_520);
}
}
}
}
 else {
if((fields_513==BUNSPEC)){
{
obj_t list1128_523;
list1128_523 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(string3296___object, list1128_523);
}
{
obj_t fields_6021;
fields_6021 = BNIL;
fields_513 = fields_6021;
goto loop_515;
}
}
 else {
{
obj_t arg1131_526;
{
obj_t pair_1546;
if(PAIRP(fields_513)){
pair_1546 = fields_513;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3252___object, fields_513, string3191___object, BINT(((long)33879)));
exit( -1 );}
arg1131_526 = CAR(pair_1546);
}
field_530 = arg1131_526;
{
obj_t name_532;
{
obj_t res1443_1557;
{
obj_t vector_1549;
if(VECTORP(field_530)){
vector_1549 = field_530;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, field_530, string3191___object, BINT(((long)8663)));
exit( -1 );}
{
bool_t test1338_1551;
{
long aux_6033;
aux_6033 = VECTOR_LENGTH(vector_1549);
test1338_1551 = BOUND_CHECK(((long)0), aux_6033);
}
if(test1338_1551){
obj_t aux2607_2989;
aux2607_2989 = VECTOR_REF(vector_1549, ((long)0));
if(SYMBOLP(aux2607_2989)){
res1443_1557 = aux2607_2989;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3193___object, aux2607_2989, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2613_2995;
aux2613_2995 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)0)), string3197___object, BINT(((long)7610)));
if(SYMBOLP(aux2613_2995)){
res1443_1557 = aux2613_2995;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3193___object, aux2613_2995, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
name_532 = res1443_1557;
}
{
obj_t get_value_98_533;
{
obj_t res1444_1567;
{
obj_t vector_1559;
if(VECTORP(field_530)){
vector_1559 = field_530;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, field_530, string3191___object, BINT(((long)9277)));
exit( -1 );}
{
bool_t test1338_1561;
{
long aux_6056;
aux_6056 = VECTOR_LENGTH(vector_1559);
test1338_1561 = BOUND_CHECK(((long)1), aux_6056);
}
if(test1338_1561){
obj_t aux2625_3007;
aux2625_3007 = VECTOR_REF(vector_1559, ((long)1));
if(PROCEDUREP(aux2625_3007)){
res1444_1567 = aux2625_3007;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3209___object, aux2625_3007, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2631_3013;
aux2631_3013 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)1)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux2631_3013)){
res1444_1567 = aux2631_3013;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3209___object, aux2631_3013, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
get_value_98_533 = res1444_1567;
}
{
{
obj_t list1136_534;
list1136_534 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(string3286___object, list1136_534);
}
{
obj_t list1138_536;
list1138_536 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(name_532, list1138_536);
}
{
obj_t list1140_538;
list1140_538 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)':')), list1140_538);
}
{
bool_t test1142_540;
{
bool_t res1445_1579;
{
obj_t arg1030_1569;
{
obj_t vector_1570;
if(VECTORP(field_530)){
vector_1570 = field_530;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, field_530, string3191___object, BINT(((long)8973)));
exit( -1 );}
{
bool_t test1338_1572;
{
long aux_6086;
aux_6086 = VECTOR_LENGTH(vector_1570);
test1338_1572 = BOUND_CHECK(((long)3), aux_6086);
}
if(test1338_1572){
arg1030_1569 = VECTOR_REF(vector_1570, ((long)3));
}
 else {
arg1030_1569 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
res1445_1579 = PROCEDUREP(arg1030_1569);
}
test1142_540 = res1445_1579;
}
if(test1142_540){
obj_t get_len_134_541;
{
obj_t res1446_1589;
{
obj_t vector_1581;
if(VECTORP(field_530)){
vector_1581 = field_530;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3190___object, field_530, string3191___object, BINT(((long)10197)));
exit( -1 );}
{
bool_t test1338_1583;
{
long aux_6101;
aux_6101 = VECTOR_LENGTH(vector_1581);
test1338_1583 = BOUND_CHECK(((long)3), aux_6101);
}
if(test1338_1583){
obj_t aux2651_3031;
aux2651_3031 = VECTOR_REF(vector_1581, ((long)3));
if(PROCEDUREP(aux2651_3031)){
res1446_1589 = aux2651_3031;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3209___object, aux2651_3031, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2657_3037;
aux2657_3037 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux2657_3037)){
res1446_1589 = aux2657_3037;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3209___object, aux2657_3037, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
get_len_134_541 = res1446_1589;
}
{
obj_t len_542;
{
bool_t test2669_3050;
test2669_3050 = PROCEDURE_CORRECT_ARITYP(get_len_134_541, ((long)1));
if(test2669_3050){
len_542 = PROCEDURE_ENTRY(get_len_134_541)(get_len_134_541, (obj_t)(obj_105), BEOA);
}
 else {
error_location_112___error(string3287___object, list3288___object, get_len_134_541, string3191___object, BINT(((long)33051)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
{
long i_543;
i_543 = ((long)0);
loop_544:
{
bool_t test1143_545;
{
long n2_1591;
{
obj_t aux_6127;
if(INTEGERP(len_542)){
aux_6127 = len_542;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3199___object, len_542, string3191___object, BINT(((long)33101)));
exit( -1 );}
n2_1591 = (long)CINT(aux_6127);
}
test1143_545 = (i_543==n2_1591);
}
if(test1143_545){
obj_t list1144_546;
list1144_546 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)']')), list1144_546);
}
 else {
{
obj_t list1146_548;
list1146_548 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)' ')), list1146_548);
}
if(flag_107){
obj_t arg1148_550;
{
bool_t test2684_3064;
test2684_3064 = PROCEDURE_CORRECT_ARITYP(get_value_98_533, ((long)2));
if(test2684_3064){
arg1148_550 = PROCEDURE_ENTRY(get_value_98_533)(get_value_98_533, (obj_t)(obj_105), BINT(i_543), BEOA);
}
 else {
error_location_112___error(string3287___object, list3291___object, get_value_98_533, string3191___object, BINT(((long)33212)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
obj_t list1149_551;
list1149_551 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(arg1148_550, list1149_551);
}
}
 else {
obj_t arg1151_553;
{
bool_t test2692_3072;
test2692_3072 = PROCEDURE_CORRECT_ARITYP(get_value_98_533, ((long)2));
if(test2692_3072){
arg1151_553 = PROCEDURE_ENTRY(get_value_98_533)(get_value_98_533, (obj_t)(obj_105), BINT(i_543), BEOA);
}
 else {
error_location_112___error(string3287___object, list3291___object, get_value_98_533, string3191___object, BINT(((long)33252)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
obj_t list1152_554;
list1152_554 = MAKE_PAIR(port_106, BNIL);
write___r4_output_6_10_3(arg1151_553, list1152_554);
}
}
{
long i_6165;
i_6165 = (i_543+((long)1));
i_543 = i_6165;
goto loop_544;
}
}
}
}
}
}
}
 else {
{
obj_t list1155_557;
list1155_557 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)' ')), list1155_557);
}
if(flag_107){
obj_t arg1157_559;
{
bool_t test2699_3080;
test2699_3080 = PROCEDURE_CORRECT_ARITYP(get_value_98_533, ((long)1));
if(test2699_3080){
arg1157_559 = PROCEDURE_ENTRY(get_value_98_533)(get_value_98_533, (obj_t)(obj_105), BEOA);
}
 else {
error_location_112___error(string3287___object, list3294___object, get_value_98_533, string3191___object, BINT(((long)32866)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
obj_t list1158_560;
list1158_560 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(arg1157_559, list1158_560);
}
}
 else {
obj_t arg1161_562;
{
bool_t test2706_3088;
test2706_3088 = PROCEDURE_CORRECT_ARITYP(get_value_98_533, ((long)1));
if(test2706_3088){
arg1161_562 = PROCEDURE_ENTRY(get_value_98_533)(get_value_98_533, (obj_t)(obj_105), BEOA);
}
 else {
error_location_112___error(string3287___object, list3294___object, get_value_98_533, string3191___object, BINT(((long)32901)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
obj_t list1162_563;
list1162_563 = MAKE_PAIR(port_106, BNIL);
write___r4_output_6_10_3(arg1161_562, list1162_563);
}
}
{
obj_t list1164_565;
list1164_565 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)']')), list1164_565);
}
}
}
}
}
}
}
{
obj_t arg1132_527;
{
obj_t pair_1547;
if(PAIRP(fields_513)){
pair_1547 = fields_513;
}
 else {
bigloo_type_error_location_103___error(symbol3285___object, string3252___object, fields_513, string3191___object, BINT(((long)33902)));
exit( -1 );}
arg1132_527 = CDR(pair_1547);
}
{
obj_t fields_6200;
fields_6200 = arg1132_527;
fields_513 = fields_6200;
goto loop_515;
}
}
}
}
}
 else {
obj_t list1133_528;
list1133_528 = MAKE_PAIR(port_106, BNIL);
aux1522_1911 = display___r4_output_6_10_3(BCHAR(((unsigned char)'|')), list1133_528);
}
}
}
}
}
}
}
POP_TRACE();
return aux1522_1911;
}
}
}
}


/* object-equal? */bool_t object_equal__12___object(object_t obj1_108, object_t obj2_109)
{
{
obj_t symbol1525_1912;
symbol1525_1912 = symbol3297___object;
{
PUSH_TRACE(symbol1525_1912);
BUNSPEC;
{
bool_t aux1524_1913;
{
obj_t field_585;
{
obj_t class1_569;
obj_t class2_570;
{
long arg1041_1595;
{
long arg1042_1596;
long arg1043_1597;
arg1042_1596 = TYPE( obj1_108 );
arg1043_1597 = OBJECT_TYPE;
arg1041_1595 = (arg1042_1596-arg1043_1597);
}
{
obj_t vector_1601;
{
obj_t aux2858_3245;
aux2858_3245 = _classes__134___object;
if(VECTORP(aux2858_3245)){
vector_1601 = aux2858_3245;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, aux2858_3245, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
class1_569 = VECTOR_REF(vector_1601, arg1041_1595);
}
}
{
long arg1041_1604;
{
long arg1042_1605;
long arg1043_1606;
arg1042_1605 = TYPE( obj2_109 );
arg1043_1606 = OBJECT_TYPE;
arg1041_1604 = (arg1042_1605-arg1043_1606);
}
{
obj_t vector_1610;
{
obj_t aux2864_3251;
aux2864_3251 = _classes__134___object;
if(VECTORP(aux2864_3251)){
vector_1610 = aux2864_3251;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, aux2864_3251, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
class2_570 = VECTOR_REF(vector_1610, arg1041_1604);
}
}
if((class1_569==class2_570)){
{
obj_t fields_572;
fields_572 = class_fields_215___object(class1_569);
{
bool_t test_6227;
{
bool_t _ortest_1007_1615;
_ortest_1007_1615 = PAIRP(fields_572);
if(_ortest_1007_1615){
test_6227 = _ortest_1007_1615;
}
 else {
test_6227 = NULLP(fields_572);
}
}
if(test_6227){
obj_t fields_574;
obj_t class_575;
fields_574 = fields_572;
class_575 = class1_569;
loop_576:
if(NULLP(fields_574)){
{
obj_t super_578;
{
obj_t vector_1621;
if(VECTORP(class_575)){
vector_1621 = class_575;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, class_575, string3191___object, BINT(((long)10473)));
exit( -1 );}
{
bool_t test1338_1623;
{
long aux_6238;
aux_6238 = VECTOR_LENGTH(vector_1621);
test1338_1623 = BOUND_CHECK(((long)3), aux_6238);
}
if(test1338_1623){
super_578 = VECTOR_REF(vector_1621, ((long)3));
}
 else {
super_578 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
{
bool_t test1169_579;
{
bool_t res1448_1637;
{
bool_t _andtest_1006_1630;
_andtest_1006_1630 = VECTORP(super_578);
if(_andtest_1006_1630){
long arg1021_1631;
{
obj_t vector_1634;
if(_andtest_1006_1630){
vector_1634 = super_578;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, super_578, string3191___object, BINT(((long)6782)));
exit( -1 );}
arg1021_1631 = VECTOR_LENGTH(vector_1634);
}
res1448_1637 = (arg1021_1631==((long)10));
}
 else {
res1448_1637 = ((bool_t)0);
}
}
test1169_579 = res1448_1637;
}
if(test1169_579){
obj_t fields_580;
fields_580 = class_fields_215___object(super_578);
{
bool_t test_6256;
{
bool_t _ortest_1007_1639;
_ortest_1007_1639 = PAIRP(fields_580);
if(_ortest_1007_1639){
test_6256 = _ortest_1007_1639;
}
 else {
test_6256 = NULLP(fields_580);
}
}
if(test_6256){
obj_t class_6261;
obj_t fields_6260;
fields_6260 = fields_580;
class_6261 = super_578;
class_575 = class_6261;
fields_574 = fields_6260;
goto loop_576;
}
 else {
aux1524_1913 = ((bool_t)0);
}
}
}
 else {
aux1524_1913 = ((bool_t)1);
}
}
}
}
 else {
bool_t test1171_582;
{
obj_t arg1173_584;
{
obj_t pair_1643;
if(PAIRP(fields_574)){
pair_1643 = fields_574;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3252___object, fields_574, string3191___object, BINT(((long)35505)));
exit( -1 );}
arg1173_584 = CAR(pair_1643);
}
field_585 = arg1173_584;
{
obj_t get_value_98_587;
{
obj_t res1450_1654;
{
obj_t vector_1646;
if(VECTORP(field_585)){
vector_1646 = field_585;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, field_585, string3191___object, BINT(((long)9277)));
exit( -1 );}
{
bool_t test1338_1648;
{
long aux_6273;
aux_6273 = VECTOR_LENGTH(vector_1646);
test1338_1648 = BOUND_CHECK(((long)1), aux_6273);
}
if(test1338_1648){
obj_t aux2762_3143;
aux2762_3143 = VECTOR_REF(vector_1646, ((long)1));
if(PROCEDUREP(aux2762_3143)){
res1450_1654 = aux2762_3143;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3209___object, aux2762_3143, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2768_3149;
aux2768_3149 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)1)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux2768_3149)){
res1450_1654 = aux2768_3149;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3209___object, aux2768_3149, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
get_value_98_587 = res1450_1654;
}
{
bool_t test1175_588;
{
bool_t res1451_1666;
{
obj_t arg1030_1656;
{
obj_t vector_1657;
if(VECTORP(field_585)){
vector_1657 = field_585;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, field_585, string3191___object, BINT(((long)8973)));
exit( -1 );}
{
bool_t test1338_1659;
{
long aux_6296;
aux_6296 = VECTOR_LENGTH(vector_1657);
test1338_1659 = BOUND_CHECK(((long)3), aux_6296);
}
if(test1338_1659){
arg1030_1656 = VECTOR_REF(vector_1657, ((long)3));
}
 else {
arg1030_1656 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
}
}
}
res1451_1666 = PROCEDUREP(arg1030_1656);
}
test1175_588 = res1451_1666;
}
if(test1175_588){
obj_t get_len_134_589;
{
obj_t res1452_1676;
{
obj_t vector_1668;
if(VECTORP(field_585)){
vector_1668 = field_585;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3190___object, field_585, string3191___object, BINT(((long)10197)));
exit( -1 );}
{
bool_t test1338_1670;
{
long aux_6311;
aux_6311 = VECTOR_LENGTH(vector_1668);
test1338_1670 = BOUND_CHECK(((long)3), aux_6311);
}
if(test1338_1670){
obj_t aux2786_3167;
aux2786_3167 = VECTOR_REF(vector_1668, ((long)3));
if(PROCEDUREP(aux2786_3167)){
res1452_1676 = aux2786_3167;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3209___object, aux2786_3167, string3194___object, BINT(((long)5033)));
exit( -1 );}
}
 else {
obj_t aux2792_3173;
aux2792_3173 = debug_error_location_199___error(string3195___object, string3196___object, BINT(((long)3)), string3197___object, BINT(((long)7610)));
if(PROCEDUREP(aux2792_3173)){
res1452_1676 = aux2792_3173;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3209___object, aux2792_3173, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
}
get_len_134_589 = res1452_1676;
}
{
obj_t len1_590;
{
bool_t test2804_3186;
test2804_3186 = PROCEDURE_CORRECT_ARITYP(get_len_134_589, ((long)1));
if(test2804_3186){
len1_590 = PROCEDURE_ENTRY(get_len_134_589)(get_len_134_589, (obj_t)(obj1_108), BEOA);
}
 else {
error_location_112___error(string3298___object, list3299___object, get_len_134_589, string3191___object, BINT(((long)34616)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
obj_t len2_591;
{
bool_t test2811_3194;
test2811_3194 = PROCEDURE_CORRECT_ARITYP(get_len_134_589, ((long)1));
if(test2811_3194){
len2_591 = PROCEDURE_ENTRY(get_len_134_589)(get_len_134_589, (obj_t)(obj2_109), BEOA);
}
 else {
error_location_112___error(string3298___object, list3301___object, get_len_134_589, string3191___object, BINT(((long)34647)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
{
bool_t _andtest_1011_592;
{
long n1_1677;
long n2_1678;
{
obj_t aux_6345;
if(INTEGERP(len1_590)){
aux_6345 = len1_590;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3199___object, len1_590, string3191___object, BINT(((long)34672)));
exit( -1 );}
n1_1677 = (long)CINT(aux_6345);
}
{
obj_t aux_6352;
if(INTEGERP(len2_591)){
aux_6352 = len2_591;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3199___object, len2_591, string3191___object, BINT(((long)34676)));
exit( -1 );}
n2_1678 = (long)CINT(aux_6352);
}
_andtest_1011_592 = (n1_1677==n2_1678);
}
if(_andtest_1011_592){
long i_593;
i_593 = ((long)0);
loop_594:
{
bool_t test1176_595;
{
long n2_1680;
{
obj_t aux_6361;
if(INTEGERP(len1_590)){
aux_6361 = len1_590;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3199___object, len1_590, string3191___object, BINT(((long)34733)));
exit( -1 );}
n2_1680 = (long)CINT(aux_6361);
}
test1176_595 = (i_593==n2_1680);
}
if(test1176_595){
test1171_582 = ((bool_t)1);
}
 else {
bool_t test1177_596;
{
obj_t arg1179_598;
obj_t arg1180_599;
{
bool_t test2836_3220;
test2836_3220 = PROCEDURE_CORRECT_ARITYP(get_value_98_587, ((long)2));
if(test2836_3220){
arg1179_598 = PROCEDURE_ENTRY(get_value_98_587)(get_value_98_587, (obj_t)(obj1_108), BINT(i_593), BEOA);
}
 else {
error_location_112___error(string3298___object, list3303___object, get_value_98_587, string3191___object, BINT(((long)34767)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
bool_t test2843_3228;
test2843_3228 = PROCEDURE_CORRECT_ARITYP(get_value_98_587, ((long)2));
if(test2843_3228){
arg1180_599 = PROCEDURE_ENTRY(get_value_98_587)(get_value_98_587, (obj_t)(obj2_109), BINT(i_593), BEOA);
}
 else {
error_location_112___error(string3298___object, list3304___object, get_value_98_587, string3191___object, BINT(((long)34786)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
test1177_596 = equal__25___r4_equivalence_6_2(arg1179_598, arg1180_599);
}
if(test1177_596){
{
long i_6390;
i_6390 = (i_593+((long)1));
i_593 = i_6390;
goto loop_594;
}
}
 else {
test1171_582 = ((bool_t)0);
}
}
}
}
 else {
test1171_582 = ((bool_t)0);
}
}
}
}
}
}
 else {
obj_t arg1181_600;
obj_t arg1182_601;
{
bool_t test2850_3236;
test2850_3236 = PROCEDURE_CORRECT_ARITYP(get_value_98_587, ((long)1));
if(test2850_3236){
arg1181_600 = PROCEDURE_ENTRY(get_value_98_587)(get_value_98_587, (obj_t)(obj1_108), BEOA);
}
 else {
error_location_112___error(string3298___object, list3305___object, get_value_98_587, string3191___object, BINT(((long)34446)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
{
bool_t test2857_3244;
test2857_3244 = PROCEDURE_CORRECT_ARITYP(get_value_98_587, ((long)1));
if(test2857_3244){
arg1182_601 = PROCEDURE_ENTRY(get_value_98_587)(get_value_98_587, (obj_t)(obj2_109), BEOA);
}
 else {
error_location_112___error(string3298___object, list3306___object, get_value_98_587, string3191___object, BINT(((long)34463)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
test1171_582 = equal__25___r4_equivalence_6_2(arg1181_600, arg1182_601);
}
}
}
}
if(test1171_582){
{
obj_t arg1172_583;
{
obj_t pair_1644;
if(PAIRP(fields_574)){
pair_1644 = fields_574;
}
 else {
bigloo_type_error_location_103___error(symbol3297___object, string3252___object, fields_574, string3191___object, BINT(((long)35528)));
exit( -1 );}
arg1172_583 = CDR(pair_1644);
}
{
obj_t fields_6416;
fields_6416 = arg1172_583;
fields_574 = fields_6416;
goto loop_576;
}
}
}
 else {
aux1524_1913 = ((bool_t)0);
}
}
}
 else {
aux1524_1913 = ((bool_t)0);
}
}
}
}
 else {
aux1524_1913 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1524_1913;
}
}
}
}


/* _object-equal?1566 */obj_t _object_equal_1566_89___object(obj_t env_2033, obj_t obj1_2034, obj_t obj2_2035)
{
{
bool_t aux_6418;
{
object_t aux_6428;
object_t aux_6419;
{
bool_t test2904_3288;
{
bool_t res3427_3803;
{
obj_t obj_3800;
obj_3800 = obj2_2035;
{
obj_t symbol1489_3801;
symbol1489_3801 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3801);
BUNSPEC;
{
bool_t aux1488_3802;
aux1488_3802 = (POINTERP( obj_3800 ) && (TYPE( obj_3800 ) >= OBJECT_TYPE));
POP_TRACE();
res3427_3803 = aux1488_3802;
}
}
}
}
test2904_3288 = res3427_3803;
}
if(test2904_3288){
aux_6428 = (object_t)(obj2_2035);
}
 else {
bigloo_type_error_location_103___error(symbol3307___object, string3225___object, obj2_2035, string3191___object, BINT(((long)34178)));
exit( -1 );}
}
{
bool_t test2898_3282;
{
bool_t res3426_3799;
{
obj_t obj_3796;
obj_3796 = obj1_2034;
{
obj_t symbol1489_3797;
symbol1489_3797 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3797);
BUNSPEC;
{
bool_t aux1488_3798;
aux1488_3798 = (POINTERP( obj_3796 ) && (TYPE( obj_3796 ) >= OBJECT_TYPE));
POP_TRACE();
res3426_3799 = aux1488_3798;
}
}
}
}
test2898_3282 = res3426_3799;
}
if(test2898_3282){
aux_6419 = (object_t)(obj1_2034);
}
 else {
bigloo_type_error_location_103___error(symbol3307___object, string3225___object, obj1_2034, string3191___object, BINT(((long)34178)));
exit( -1 );}
}
aux_6418 = object_equal__12___object(aux_6419, aux_6428);
}
return BBOOL(aux_6418);
}
}


/* object-init */obj_t object_init_111___object()
{
{
obj_t symbol1527_1914;
symbol1527_1914 = symbol3308___object;
{
PUSH_TRACE(symbol1527_1914);
BUNSPEC;
{
obj_t aux1526_1915;
aux1526_1915 = (object___object = add_class__117___object(symbol3309___object, BFALSE, allocate_object_env_103___object, ((long)46311), BNIL, BFALSE),
BUNSPEC);
POP_TRACE();
return aux1526_1915;
}
}
}
}


/* allocate-object */object_t allocate_object_214___object()
{
{
obj_t symbol1529_1916;
symbol1529_1916 = symbol3310___object;
{
PUSH_TRACE(symbol1529_1916);
BUNSPEC;
{
object_t aux1528_1917;
{
object_t new1004_608;
new1004_608 = ((object_t)BREF( GC_MALLOC( sizeof(struct object) )));
{
long arg1188_609;
{
long res1453_1687;
{
obj_t class_1684;
class_1684 = object___object;
{
obj_t vector_1685;
if(VECTORP(class_1684)){
vector_1685 = class_1684;
}
 else {
bigloo_type_error_location_103___error(symbol3310___object, string3190___object, class_1684, string3191___object, BINT(((long)7335)));
exit( -1 );}
{
obj_t aux_6449;
{
obj_t aux2915_3299;
aux2915_3299 = VECTOR_REF(vector_1685, ((long)1));
if(INTEGERP(aux2915_3299)){
aux_6449 = aux2915_3299;
}
 else {
bigloo_type_error_location_103___error(symbol3310___object, string3199___object, aux2915_3299, string3194___object, BINT(((long)5785)));
exit( -1 );}
}
res1453_1687 = (long)CINT(aux_6449);
}
}
}
arg1188_609 = res1453_1687;
}
{
obj_t obj_1688;
obj_1688 = (obj_t)(new1004_608);
(((obj_t)CREF(obj_1688))->header = MAKE_HEADER( arg1188_609, 0 ), BUNSPEC);
}
}
OBJECT_WIDENING_SET(new1004_608, BFALSE);
aux1528_1917 = new1004_608;
}
POP_TRACE();
return aux1528_1917;
}
}
}
}


/* _allocate-object */obj_t _allocate_object_100___object(obj_t env_2036)
{
{
object_t aux_6461;
aux_6461 = allocate_object_214___object();
return (obj_t)(aux_6461);
}
}


/* make-object */object_t make_object_188___object()
{
{
obj_t symbol1531_3804;
symbol1531_3804 = symbol3311___object;
{
PUSH_TRACE(symbol1531_3804);
BUNSPEC;
{
object_t aux1530_3805;
{
object_t new1002_3806;
new1002_3806 = ((object_t)BREF( GC_MALLOC( sizeof(struct object) )));
{
long arg1189_3807;
arg1189_3807 = class_num_218___object(object___object);
{
obj_t obj_3808;
obj_3808 = (obj_t)(new1002_3806);
(((obj_t)CREF(obj_3808))->header = MAKE_HEADER( arg1189_3807, 0 ), BUNSPEC);
}
}
OBJECT_WIDENING_SET(new1002_3806, BFALSE);
{
aux1530_3805 = new1002_3806;
}
}
POP_TRACE();
return aux1530_3805;
}
}
}
}


/* _make-object */obj_t _make_object_124___object(obj_t env_2037)
{
{
object_t aux_6471;
{
obj_t symbol1531_3809;
symbol1531_3809 = symbol3311___object;
{
PUSH_TRACE(symbol1531_3809);
BUNSPEC;
{
object_t aux1530_3810;
{
object_t new1002_3811;
new1002_3811 = ((object_t)BREF( GC_MALLOC( sizeof(struct object) )));
{
long arg1189_3812;
arg1189_3812 = class_num_218___object(object___object);
{
obj_t obj_3813;
obj_3813 = (obj_t)(new1002_3811);
(((obj_t)CREF(obj_3813))->header = MAKE_HEADER( arg1189_3812, 0 ), BUNSPEC);
}
}
OBJECT_WIDENING_SET(new1002_3811, BFALSE);
{
aux1530_3810 = new1002_3811;
}
}
POP_TRACE();
aux_6471 = aux1530_3810;
}
}
}
return (obj_t)(aux_6471);
}
}


/* method-init */obj_t method_init_76___object()
{
{
obj_t symbol1533_1920;
symbol1533_1920 = symbol3312___object;
{
PUSH_TRACE(symbol1533_1920);
BUNSPEC;
{
obj_t aux1532_1921;
add_generic__110___object(object_display_env_20___object, object_display_default1017_env_41___object);
add_generic__110___object(object_write_env_104___object, object_write_default1018_env_141___object);
add_generic__110___object(object__struct_env_210___object, object__struct_default1019_env_180___object);
aux1532_1921 = add_generic__110___object(struct_object__object_env_209___object, struct_object__object_default1020_env_255___object);
POP_TRACE();
return aux1532_1921;
}
}
}
}


/* object-display */obj_t object_display_243___object(object_t obj_88, obj_t port_89)
{
{
obj_t symbol1535_1922;
symbol1535_1922 = symbol3313___object;
{
PUSH_TRACE(symbol1535_1922);
BUNSPEC;
{
obj_t aux1534_1923;
{
obj_t method1398_802;
obj_t class1403_803;
{
obj_t arg1405_800;
obj_t arg1407_801;
{
obj_t pre_method_105_1695;
pre_method_105_1695 = PROCEDURE_REF(object_display_env_20___object, ((long)2));
if(INTEGERP(pre_method_105_1695)){
PROCEDURE_SET(object_display_env_20___object, ((long)2), BUNSPEC);
arg1405_800 = pre_method_105_1695;
}
 else {
long obj_class_num_177_1700;
obj_class_num_177_1700 = TYPE( obj_88 );
{
obj_t arg1092_1701;
arg1092_1701 = PROCEDURE_REF(object_display_env_20___object, ((long)1));
{
obj_t array_1703;
if(VECTORP(arg1092_1701)){
array_1703 = arg1092_1701;
}
 else {
bigloo_type_error_location_103___error(symbol3313___object, string3190___object, arg1092_1701, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_1705;
{
long arg1045_1706;
arg1045_1706 = OBJECT_TYPE;
arg1044_1705 = (obj_class_num_177_1700-arg1045_1706);
}
arg1405_800 = VECTOR_REF(array_1703, arg1044_1705);
}
}
}
}
}
{
long arg1041_1712;
{
long arg1042_1713;
long arg1043_1714;
arg1042_1713 = TYPE( obj_88 );
arg1043_1714 = OBJECT_TYPE;
arg1041_1712 = (arg1042_1713-arg1043_1714);
}
{
obj_t vector_1718;
{
obj_t aux2954_3341;
aux2954_3341 = _classes__134___object;
if(VECTORP(aux2954_3341)){
vector_1718 = aux2954_3341;
}
 else {
bigloo_type_error_location_103___error(symbol3313___object, string3190___object, aux2954_3341, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
arg1407_801 = VECTOR_REF(vector_1718, arg1041_1712);
}
}
method1398_802 = arg1405_800;
class1403_803 = arg1407_801;
{
bool_t test1409_807;
test1409_807 = PROCEDUREP(method1398_802);
if(test1409_807){
obj_t fun_3311;
obj_t val_3312;
if(test1409_807){
fun_3311 = method1398_802;
}
 else {
bigloo_type_error_location_103___error(symbol3313___object, string3209___object, method1398_802, string3191___object, BINT(((long)29604)));
exit( -1 );}
{
obj_t list1410_808;
list1410_808 = MAKE_PAIR(port_89, BNIL);
val_3312 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_88), list1410_808);
}
{
bool_t test2934_3319;
{
long aux_6519;
aux_6519 = list_length(val_3312);
test2934_3319 = PROCEDURE_CORRECT_ARITYP(fun_3311, aux_6519);
}
if(test2934_3319){
aux1534_1923 = apply(fun_3311, val_3312);
}
 else {
error_location_112___error(symbol3313___object, string3314___object, list3315___object, string3191___object, BINT(((long)29604)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
 else {
obj_t fun_3326;
obj_t val_3327;
{
obj_t res1454_1721;
{
obj_t aux2935_3320;
aux2935_3320 = PROCEDURE_REF(object_display_env_20___object, ((long)0));
if(PROCEDUREP(aux2935_3320)){
res1454_1721 = aux2935_3320;
}
 else {
bigloo_type_error_location_103___error(symbol3313___object, string3209___object, aux2935_3320, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
fun_3326 = res1454_1721;
}
{
obj_t list1190_612;
list1190_612 = MAKE_PAIR(port_89, BNIL);
val_3327 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_88), list1190_612);
}
{
bool_t test2947_3334;
{
long aux_6537;
aux_6537 = list_length(val_3327);
test2947_3334 = PROCEDURE_CORRECT_ARITYP(fun_3326, aux_6537);
}
if(test2947_3334){
aux1534_1923 = apply(fun_3326, val_3327);
}
 else {
error_location_112___error(symbol3313___object, string3314___object, list3336___object, string3191___object, BINT(((long)29604)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
}
}
}
POP_TRACE();
return aux1534_1923;
}
}
}
}


/* _object-display1567 */obj_t _object_display1567_135___object(obj_t env_2038, obj_t obj_2039, obj_t port_2040)
{
{
object_t aux_6547;
{
bool_t test2962_3348;
{
bool_t res3428_3817;
{
obj_t obj_3814;
obj_3814 = obj_2039;
{
obj_t symbol1489_3815;
symbol1489_3815 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3815);
BUNSPEC;
{
bool_t aux1488_3816;
aux1488_3816 = (POINTERP( obj_3814 ) && (TYPE( obj_3814 ) >= OBJECT_TYPE));
POP_TRACE();
res3428_3817 = aux1488_3816;
}
}
}
}
test2962_3348 = res3428_3817;
}
if(test2962_3348){
aux_6547 = (object_t)(obj_2039);
}
 else {
bigloo_type_error_location_103___error(symbol3354___object, string3225___object, obj_2039, string3191___object, BINT(((long)29604)));
exit( -1 );}
}
return object_display_243___object(aux_6547, port_2040);
}
}


/* object-display-default1017 */obj_t object_display_default1017_64___object(object_t obj_90, obj_t port_91)
{
{
obj_t symbol1537_1924;
symbol1537_1924 = symbol3355___object;
{
PUSH_TRACE(symbol1537_1924);
BUNSPEC;
{
obj_t aux1536_1925;
{
obj_t port_1722;
{
bool_t test1192_1723;
test1192_1723 = PAIRP(port_91);
if(test1192_1723){
obj_t pair_1725;
if(test1192_1723){
pair_1725 = port_91;
}
 else {
bigloo_type_error_location_103___error(symbol3355___object, string3252___object, port_91, string3191___object, BINT(((long)29689)));
exit( -1 );}
port_1722 = CAR(pair_1725);
}
 else {
port_1722 = current_output_port;
}
}
aux1536_1925 = object_write_display_42___object(obj_90, port_1722, ((bool_t)1));
}
POP_TRACE();
return aux1536_1925;
}
}
}
}


/* _object-display-default1017 */obj_t _object_display_default1017_129___object(obj_t env_2041, obj_t obj_2042, obj_t port_2043)
{
{
object_t aux_6567;
{
bool_t test2974_3360;
{
bool_t res3429_3821;
{
obj_t obj_3818;
obj_3818 = obj_2042;
{
obj_t symbol1489_3819;
symbol1489_3819 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3819);
BUNSPEC;
{
bool_t aux1488_3820;
aux1488_3820 = (POINTERP( obj_3818 ) && (TYPE( obj_3818 ) >= OBJECT_TYPE));
POP_TRACE();
res3429_3821 = aux1488_3820;
}
}
}
}
test2974_3360 = res3429_3821;
}
if(test2974_3360){
aux_6567 = (object_t)(obj_2042);
}
 else {
bigloo_type_error_location_103___error(symbol3356___object, string3225___object, obj_2042, string3191___object, BINT(((long)1112)));
exit( -1 );}
}
return object_display_default1017_64___object(aux_6567, port_2043);
}
}


/* object-write */obj_t object_write_132___object(object_t obj_92, obj_t port_93)
{
{
obj_t symbol1539_1926;
symbol1539_1926 = symbol3357___object;
{
PUSH_TRACE(symbol1539_1926);
BUNSPEC;
{
obj_t aux1538_1927;
{
obj_t method1381_782;
obj_t class1386_783;
{
obj_t arg1387_780;
obj_t arg1388_781;
{
obj_t pre_method_105_1727;
pre_method_105_1727 = PROCEDURE_REF(object_write_env_104___object, ((long)2));
if(INTEGERP(pre_method_105_1727)){
PROCEDURE_SET(object_write_env_104___object, ((long)2), BUNSPEC);
arg1387_780 = pre_method_105_1727;
}
 else {
long obj_class_num_177_1732;
obj_class_num_177_1732 = TYPE( obj_92 );
{
obj_t arg1092_1733;
arg1092_1733 = PROCEDURE_REF(object_write_env_104___object, ((long)1));
{
obj_t array_1735;
if(VECTORP(arg1092_1733)){
array_1735 = arg1092_1733;
}
 else {
bigloo_type_error_location_103___error(symbol3357___object, string3190___object, arg1092_1733, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_1737;
{
long arg1045_1738;
arg1045_1738 = OBJECT_TYPE;
arg1044_1737 = (obj_class_num_177_1732-arg1045_1738);
}
arg1387_780 = VECTOR_REF(array_1735, arg1044_1737);
}
}
}
}
}
{
long arg1041_1744;
{
long arg1042_1745;
long arg1043_1746;
arg1042_1745 = TYPE( obj_92 );
arg1043_1746 = OBJECT_TYPE;
arg1041_1744 = (arg1042_1745-arg1043_1746);
}
{
obj_t vector_1750;
{
obj_t aux3015_3401;
aux3015_3401 = _classes__134___object;
if(VECTORP(aux3015_3401)){
vector_1750 = aux3015_3401;
}
 else {
bigloo_type_error_location_103___error(symbol3357___object, string3190___object, aux3015_3401, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
arg1388_781 = VECTOR_REF(vector_1750, arg1041_1744);
}
}
method1381_782 = arg1387_780;
class1386_783 = arg1388_781;
{
bool_t test1390_787;
test1390_787 = PROCEDUREP(method1381_782);
if(test1390_787){
obj_t fun_3371;
obj_t val_3372;
if(test1390_787){
fun_3371 = method1381_782;
}
 else {
bigloo_type_error_location_103___error(symbol3357___object, string3209___object, method1381_782, string3191___object, BINT(((long)29990)));
exit( -1 );}
{
obj_t list1391_788;
list1391_788 = MAKE_PAIR(port_93, BNIL);
val_3372 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_92), list1391_788);
}
{
bool_t test2994_3379;
{
long aux_6610;
aux_6610 = list_length(val_3372);
test2994_3379 = PROCEDURE_CORRECT_ARITYP(fun_3371, aux_6610);
}
if(test2994_3379){
aux1538_1927 = apply(fun_3371, val_3372);
}
 else {
error_location_112___error(symbol3357___object, string3314___object, list3358___object, string3191___object, BINT(((long)29990)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
 else {
obj_t fun_3386;
obj_t val_3387;
{
obj_t res1455_1753;
{
obj_t aux2995_3380;
aux2995_3380 = PROCEDURE_REF(object_write_env_104___object, ((long)0));
if(PROCEDUREP(aux2995_3380)){
res1455_1753 = aux2995_3380;
}
 else {
bigloo_type_error_location_103___error(symbol3357___object, string3209___object, aux2995_3380, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
fun_3386 = res1455_1753;
}
{
obj_t list1193_616;
list1193_616 = MAKE_PAIR(port_93, BNIL);
val_3387 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_92), list1193_616);
}
{
bool_t test3008_3394;
{
long aux_6628;
aux_6628 = list_length(val_3387);
test3008_3394 = PROCEDURE_CORRECT_ARITYP(fun_3386, aux_6628);
}
if(test3008_3394){
aux1538_1927 = apply(fun_3386, val_3387);
}
 else {
error_location_112___error(symbol3357___object, string3314___object, list3372___object, string3191___object, BINT(((long)29990)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
}
}
}
POP_TRACE();
return aux1538_1927;
}
}
}
}


/* _object-write1568 */obj_t _object_write1568_82___object(obj_t env_2044, obj_t obj_2045, obj_t port_2046)
{
{
object_t aux_6638;
{
bool_t test3022_3408;
{
bool_t res3430_3825;
{
obj_t obj_3822;
obj_3822 = obj_2045;
{
obj_t symbol1489_3823;
symbol1489_3823 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3823);
BUNSPEC;
{
bool_t aux1488_3824;
aux1488_3824 = (POINTERP( obj_3822 ) && (TYPE( obj_3822 ) >= OBJECT_TYPE));
POP_TRACE();
res3430_3825 = aux1488_3824;
}
}
}
}
test3022_3408 = res3430_3825;
}
if(test3022_3408){
aux_6638 = (object_t)(obj_2045);
}
 else {
bigloo_type_error_location_103___error(symbol3389___object, string3225___object, obj_2045, string3191___object, BINT(((long)29990)));
exit( -1 );}
}
return object_write_132___object(aux_6638, port_2046);
}
}


/* object-write-default1018 */obj_t object_write_default1018_79___object(object_t obj_94, obj_t port_95)
{
{
obj_t symbol1541_1928;
symbol1541_1928 = symbol3390___object;
{
PUSH_TRACE(symbol1541_1928);
BUNSPEC;
{
obj_t aux1540_1929;
{
obj_t port_1754;
{
bool_t test1195_1755;
test1195_1755 = PAIRP(port_95);
if(test1195_1755){
obj_t pair_1757;
if(test1195_1755){
pair_1757 = port_95;
}
 else {
bigloo_type_error_location_103___error(symbol3390___object, string3252___object, port_95, string3191___object, BINT(((long)30073)));
exit( -1 );}
port_1754 = CAR(pair_1757);
}
 else {
port_1754 = current_output_port;
}
}
aux1540_1929 = object_write_display_42___object(obj_94, port_1754, ((bool_t)0));
}
POP_TRACE();
return aux1540_1929;
}
}
}
}


/* _object-write-default1018 */obj_t _object_write_default1018_31___object(obj_t env_2047, obj_t obj_2048, obj_t port_2049)
{
{
object_t aux_6658;
{
bool_t test3034_3420;
{
bool_t res3431_3829;
{
obj_t obj_3826;
obj_3826 = obj_2048;
{
obj_t symbol1489_3827;
symbol1489_3827 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3827);
BUNSPEC;
{
bool_t aux1488_3828;
aux1488_3828 = (POINTERP( obj_3826 ) && (TYPE( obj_3826 ) >= OBJECT_TYPE));
POP_TRACE();
res3431_3829 = aux1488_3828;
}
}
}
}
test3034_3420 = res3431_3829;
}
if(test3034_3420){
aux_6658 = (object_t)(obj_2048);
}
 else {
bigloo_type_error_location_103___error(symbol3391___object, string3225___object, obj_2048, string3191___object, BINT(((long)1112)));
exit( -1 );}
}
return object_write_default1018_79___object(aux_6658, port_2049);
}
}


/* object->struct */obj_t object__struct_50___object(object_t object_96)
{
{
obj_t arg1372_763;
obj_t arg1373_764;
{
obj_t pre_method_105_1759;
pre_method_105_1759 = PROCEDURE_REF(object__struct_env_210___object, ((long)2));
if(INTEGERP(pre_method_105_1759)){
PROCEDURE_SET(object__struct_env_210___object, ((long)2), BUNSPEC);
arg1372_763 = pre_method_105_1759;
}
 else {
long obj_class_num_177_1764;
obj_class_num_177_1764 = TYPE( object_96 );
{
obj_t arg1092_1765;
arg1092_1765 = PROCEDURE_REF(object__struct_env_210___object, ((long)1));
{
obj_t array_1767;
if(VECTORP(arg1092_1765)){
array_1767 = arg1092_1765;
}
 else {
bigloo_type_error_location_103___error(symbol3392___object, string3190___object, arg1092_1765, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_1769;
{
long arg1045_1770;
arg1045_1770 = OBJECT_TYPE;
arg1044_1769 = (obj_class_num_177_1764-arg1045_1770);
}
arg1372_763 = VECTOR_REF(array_1767, arg1044_1769);
}
}
}
}
}
{
long arg1041_1776;
{
long arg1042_1777;
long arg1043_1778;
arg1042_1777 = TYPE( object_96 );
arg1043_1778 = OBJECT_TYPE;
arg1041_1776 = (arg1042_1777-arg1043_1778);
}
{
obj_t vector_1782;
{
obj_t aux3045_3431;
aux3045_3431 = _classes__134___object;
if(VECTORP(aux3045_3431)){
vector_1782 = aux3045_3431;
}
 else {
bigloo_type_error_location_103___error(symbol3392___object, string3190___object, aux3045_3431, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
arg1373_764 = VECTOR_REF(vector_1782, arg1041_1776);
}
}
{
bool_t test1375_1786;
test1375_1786 = PROCEDUREP(arg1372_763);
if(test1375_1786){
obj_t fun_3443;
if(test1375_1786){
fun_3443 = arg1372_763;
}
 else {
bigloo_type_error_location_103___error(symbol3392___object, string3209___object, arg1372_763, string3191___object, BINT(((long)30374)));
exit( -1 );}
{
bool_t test3069_3456;
test3069_3456 = PROCEDURE_CORRECT_ARITYP(fun_3443, ((long)1));
if(test3069_3456){
obj_t aux3058_3444;
aux3058_3444 = PROCEDURE_ENTRY(fun_3443)(arg1372_763, (obj_t)(object_96), BEOA);
if(STRUCTP(aux3058_3444)){
return aux3058_3444;
}
 else {
bigloo_type_error_location_103___error(symbol3392___object, string3274___object, aux3058_3444, string3191___object, BINT(((long)30374)));
exit( -1 );}
}
 else {
error_location_112___error(string3393___object, list3394___object, fun_3443, string3191___object, BINT(((long)30374)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
 else {
obj_t fun1196_1787;
{
obj_t res1456_1789;
{
obj_t aux3070_3457;
aux3070_3457 = PROCEDURE_REF(object__struct_env_210___object, ((long)0));
if(PROCEDUREP(aux3070_3457)){
res1456_1789 = aux3070_3457;
}
 else {
bigloo_type_error_location_103___error(symbol3392___object, string3209___object, aux3070_3457, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
fun1196_1787 = res1456_1789;
}
{
bool_t test3088_3476;
test3088_3476 = PROCEDURE_CORRECT_ARITYP(fun1196_1787, ((long)1));
if(test3088_3476){
obj_t aux3077_3464;
aux3077_3464 = PROCEDURE_ENTRY(fun1196_1787)(fun1196_1787, (obj_t)(object_96), BEOA);
if(STRUCTP(aux3077_3464)){
return aux3077_3464;
}
 else {
bigloo_type_error_location_103___error(symbol3392___object, string3274___object, aux3077_3464, string3191___object, BINT(((long)30374)));
exit( -1 );}
}
 else {
error_location_112___error(string3393___object, list3397___object, fun1196_1787, string3191___object, BINT(((long)30374)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
}
}
}


/* _object->struct1569 */obj_t _object__struct1569_129___object(obj_t env_2050, obj_t object_2051)
{
{
object_t aux_6729;
{
bool_t test3090_3478;
{
bool_t res3432_3833;
{
obj_t obj_3830;
obj_3830 = object_2051;
{
obj_t symbol1489_3831;
symbol1489_3831 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3831);
BUNSPEC;
{
bool_t aux1488_3832;
aux1488_3832 = (POINTERP( obj_3830 ) && (TYPE( obj_3830 ) >= OBJECT_TYPE));
POP_TRACE();
res3432_3833 = aux1488_3832;
}
}
}
}
test3090_3478 = res3432_3833;
}
if(test3090_3478){
aux_6729 = (object_t)(object_2051);
}
 else {
bigloo_type_error_location_103___error(symbol3399___object, string3225___object, object_2051, string3191___object, BINT(((long)30374)));
exit( -1 );}
}
return object__struct_50___object(aux_6729);
}
}


/* object->struct-default1019 */obj_t object__struct_default1019_241___object(object_t object_97)
{
{
obj_t symbol1543_1930;
symbol1543_1930 = symbol3400___object;
{
PUSH_TRACE(symbol1543_1930);
BUNSPEC;
{
obj_t aux1542_1931;
{
obj_t aux3095_3483;
aux3095_3483 = debug_error_location_199___error(string3401___object, string3402___object, (obj_t)(object_97), string3197___object, BINT(((long)7610)));
if(STRUCTP(aux3095_3483)){
aux1542_1931 = aux3095_3483;
}
 else {
bigloo_type_error_location_103___error(symbol3400___object, string3274___object, aux3095_3483, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
POP_TRACE();
return aux1542_1931;
}
}
}
}


/* _object->struct-default1019 */obj_t _object__struct_default1019_206___object(obj_t env_2052, obj_t object_2053)
{
{
object_t aux_6749;
{
bool_t test3102_3490;
{
bool_t res3433_3837;
{
obj_t obj_3834;
obj_3834 = object_2053;
{
obj_t symbol1489_3835;
symbol1489_3835 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3835);
BUNSPEC;
{
bool_t aux1488_3836;
aux1488_3836 = (POINTERP( obj_3834 ) && (TYPE( obj_3834 ) >= OBJECT_TYPE));
POP_TRACE();
res3433_3837 = aux1488_3836;
}
}
}
}
test3102_3490 = res3433_3837;
}
if(test3102_3490){
aux_6749 = (object_t)(object_2053);
}
 else {
bigloo_type_error_location_103___error(symbol3403___object, string3225___object, object_2053, string3191___object, BINT(((long)1112)));
exit( -1 );}
}
return object__struct_default1019_241___object(aux_6749);
}
}


/* struct+object->object */object_t struct_object__object_93___object(object_t object_98, obj_t struct_99)
{
{
obj_t arg1353_746;
obj_t arg1355_747;
{
obj_t pre_method_105_1798;
pre_method_105_1798 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)2));
if(INTEGERP(pre_method_105_1798)){
PROCEDURE_SET(struct_object__object_env_209___object, ((long)2), BUNSPEC);
arg1353_746 = pre_method_105_1798;
}
 else {
long obj_class_num_177_1803;
obj_class_num_177_1803 = TYPE( object_98 );
{
obj_t arg1092_1804;
arg1092_1804 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)1));
{
obj_t array_1806;
if(VECTORP(arg1092_1804)){
array_1806 = arg1092_1804;
}
 else {
bigloo_type_error_location_103___error(symbol3404___object, string3190___object, arg1092_1804, string3191___object, BINT(((long)25932)));
exit( -1 );}
{
long arg1044_1808;
{
long arg1045_1809;
arg1045_1809 = OBJECT_TYPE;
arg1044_1808 = (obj_class_num_177_1803-arg1045_1809);
}
arg1353_746 = VECTOR_REF(array_1806, arg1044_1808);
}
}
}
}
}
{
long arg1041_1815;
{
long arg1042_1816;
long arg1043_1817;
arg1042_1816 = TYPE( object_98 );
arg1043_1817 = OBJECT_TYPE;
arg1041_1815 = (arg1042_1816-arg1043_1817);
}
{
obj_t vector_1821;
{
obj_t aux3113_3501;
aux3113_3501 = _classes__134___object;
if(VECTORP(aux3113_3501)){
vector_1821 = aux3113_3501;
}
 else {
bigloo_type_error_location_103___error(symbol3404___object, string3190___object, aux3113_3501, string3191___object, BINT(((long)17400)));
exit( -1 );}
}
arg1355_747 = VECTOR_REF(vector_1821, arg1041_1815);
}
}
{
bool_t test1357_1825;
test1357_1825 = PROCEDUREP(arg1353_746);
if(test1357_1825){
obj_t fun_3513;
if(test1357_1825){
fun_3513 = arg1353_746;
}
 else {
bigloo_type_error_location_103___error(symbol3404___object, string3209___object, arg1353_746, string3191___object, BINT(((long)30870)));
exit( -1 );}
{
bool_t test3138_3526;
test3138_3526 = PROCEDURE_CORRECT_ARITYP(fun_3513, ((long)2));
if(test3138_3526){
obj_t aux3126_3514;
aux3126_3514 = PROCEDURE_ENTRY(fun_3513)(arg1353_746, (obj_t)(object_98), struct_99, BEOA);
{
bool_t test3127_3515;
{
bool_t res3434_3841;
{
obj_t obj_3838;
obj_3838 = aux3126_3514;
{
obj_t symbol1489_3839;
symbol1489_3839 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3839);
BUNSPEC;
{
bool_t aux1488_3840;
aux1488_3840 = (POINTERP( obj_3838 ) && (TYPE( obj_3838 ) >= OBJECT_TYPE));
POP_TRACE();
res3434_3841 = aux1488_3840;
}
}
}
}
test3127_3515 = res3434_3841;
}
if(test3127_3515){
return (object_t)(aux3126_3514);
}
 else {
bigloo_type_error_location_103___error(symbol3404___object, string3225___object, aux3126_3514, string3191___object, BINT(((long)30870)));
exit( -1 );}
}
}
 else {
error_location_112___error(string3405___object, list3406___object, fun_3513, string3191___object, BINT(((long)30870)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
 else {
obj_t fun1197_1826;
{
obj_t res1458_1828;
{
obj_t aux3139_3527;
aux3139_3527 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)0));
if(PROCEDUREP(aux3139_3527)){
res1458_1828 = aux3139_3527;
}
 else {
bigloo_type_error_location_103___error(symbol3404___object, string3209___object, aux3139_3527, string3191___object, BINT(((long)17760)));
exit( -1 );}
}
fun1197_1826 = res1458_1828;
}
{
bool_t test3157_3546;
test3157_3546 = PROCEDURE_CORRECT_ARITYP(fun1197_1826, ((long)2));
if(test3157_3546){
obj_t aux3146_3534;
aux3146_3534 = PROCEDURE_ENTRY(fun1197_1826)(fun1197_1826, (obj_t)(object_98), struct_99, BEOA);
{
bool_t test3147_3535;
{
bool_t res3435_3845;
{
obj_t obj_3842;
obj_3842 = aux3146_3534;
{
obj_t symbol1489_3843;
symbol1489_3843 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3843);
BUNSPEC;
{
bool_t aux1488_3844;
aux1488_3844 = (POINTERP( obj_3842 ) && (TYPE( obj_3842 ) >= OBJECT_TYPE));
POP_TRACE();
res3435_3845 = aux1488_3844;
}
}
}
}
test3147_3535 = res3435_3845;
}
if(test3147_3535){
return (object_t)(aux3146_3534);
}
 else {
bigloo_type_error_location_103___error(symbol3404___object, string3225___object, aux3146_3534, string3191___object, BINT(((long)30870)));
exit( -1 );}
}
}
 else {
error_location_112___error(string3405___object, list3409___object, fun1197_1826, string3191___object, BINT(((long)30870)));
FAILURE(symbol3282___object,symbol3282___object,symbol3282___object);}
}
}
}
}
}


/* _struct+object->object1570 */obj_t _struct_object__object1570_9___object(obj_t env_2054, obj_t object_2055, obj_t struct_2056)
{
{
object_t aux_6826;
{
obj_t aux_6836;
object_t aux_6827;
if(STRUCTP(struct_2056)){
aux_6836 = struct_2056;
}
 else {
bigloo_type_error_location_103___error(symbol3411___object, string3274___object, struct_2056, string3191___object, BINT(((long)30870)));
exit( -1 );}
{
bool_t test3159_3548;
{
bool_t res3436_3849;
{
obj_t obj_3846;
obj_3846 = object_2055;
{
obj_t symbol1489_3847;
symbol1489_3847 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3847);
BUNSPEC;
{
bool_t aux1488_3848;
aux1488_3848 = (POINTERP( obj_3846 ) && (TYPE( obj_3846 ) >= OBJECT_TYPE));
POP_TRACE();
res3436_3849 = aux1488_3848;
}
}
}
}
test3159_3548 = res3436_3849;
}
if(test3159_3548){
aux_6827 = (object_t)(object_2055);
}
 else {
bigloo_type_error_location_103___error(symbol3411___object, string3225___object, object_2055, string3191___object, BINT(((long)30870)));
exit( -1 );}
}
aux_6826 = struct_object__object_93___object(aux_6827, aux_6836);
}
return (obj_t)(aux_6826);
}
}


/* struct+object->object-default1020 */object_t struct_object__object_default1020_163___object(object_t object_100, obj_t struct_101)
{
{
obj_t symbol1545_1932;
symbol1545_1932 = symbol3412___object;
{
PUSH_TRACE(symbol1545_1932);
BUNSPEC;
{
object_t aux1544_1933;
{
obj_t aux3170_3559;
aux3170_3559 = debug_error_location_199___error(string3413___object, string3414___object, struct_101, string3197___object, BINT(((long)7610)));
{
bool_t test3171_3560;
{
bool_t res3437_3853;
{
obj_t obj_3850;
obj_3850 = aux3170_3559;
{
obj_t symbol1489_3851;
symbol1489_3851 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3851);
BUNSPEC;
{
bool_t aux1488_3852;
aux1488_3852 = (POINTERP( obj_3850 ) && (TYPE( obj_3850 ) >= OBJECT_TYPE));
POP_TRACE();
res3437_3853 = aux1488_3852;
}
}
}
}
test3171_3560 = res3437_3853;
}
if(test3171_3560){
aux1544_1933 = (object_t)(aux3170_3559);
}
 else {
bigloo_type_error_location_103___error(symbol3412___object, string3225___object, aux3170_3559, string3197___object, BINT(((long)7610)));
exit( -1 );}
}
}
POP_TRACE();
return aux1544_1933;
}
}
}
}


/* _struct+object->object-default1020 */obj_t _struct_object__object_default1020_71___object(obj_t env_2057, obj_t object_2058, obj_t struct_2059)
{
{
object_t aux_6856;
{
obj_t aux_6866;
object_t aux_6857;
if(STRUCTP(struct_2059)){
aux_6866 = struct_2059;
}
 else {
bigloo_type_error_location_103___error(symbol3415___object, string3274___object, struct_2059, string3191___object, BINT(((long)1112)));
exit( -1 );}
{
bool_t test3177_3566;
{
bool_t res3438_3857;
{
obj_t obj_3854;
obj_3854 = object_2058;
{
obj_t symbol1489_3855;
symbol1489_3855 = symbol3222___object;
{
PUSH_TRACE(symbol1489_3855);
BUNSPEC;
{
bool_t aux1488_3856;
aux1488_3856 = (POINTERP( obj_3854 ) && (TYPE( obj_3854 ) >= OBJECT_TYPE));
POP_TRACE();
res3438_3857 = aux1488_3856;
}
}
}
}
test3177_3566 = res3438_3857;
}
if(test3177_3566){
aux_6857 = (object_t)(object_2058);
}
 else {
bigloo_type_error_location_103___error(symbol3415___object, string3225___object, object_2058, string3191___object, BINT(((long)1112)));
exit( -1 );}
}
aux_6856 = struct_object__object_default1020_163___object(aux_6857, aux_6866);
}
return (obj_t)(aux_6856);
}
}

