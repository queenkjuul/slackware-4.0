/*===========================================================================*/
/*   (Read/reader.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t string_to_obj(obj_t);
extern obj_t _reader__83_engine_param;
extern obj_t module_initialization_70_read_reader(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___intext(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t compiler_read_18_read_reader(obj_t);
static obj_t imported_modules_init_94_read_reader();
static obj_t library_modules_init_112_read_reader();
extern obj_t open_input_string(obj_t);
static obj_t _compiler_read_208_read_reader(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_read_reader = BUNSPEC;
static obj_t cnst_init_137_read_reader();
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(compiler_read_env_90_read_reader, _compiler_read_208_read_reader1016, va_generic_entry, _compiler_read_208_read_reader, -1);
DEFINE_STRING(string1009_read_reader, string1009_read_reader1017, "INTERN ", 7);
DEFINE_STRING(string1008_read_reader, string1008_read_reader1018, "Illegal intern value", 20);
DEFINE_STRING(string1007_read_reader, string1007_read_reader1019, "", 0);


/* module-initialization */ obj_t 
module_initialization_70_read_reader(long checksum_25, char *from_26)
{
   if (CBOOL(require_initialization_114_read_reader))
     {
	require_initialization_114_read_reader = BBOOL(((bool_t) 0));
	library_modules_init_112_read_reader();
	cnst_init_137_read_reader();
	imported_modules_init_94_read_reader();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_read_reader()
{
   module_initialization_70___intext(((long) 0), "READ_READER");
   module_initialization_70___reader(((long) 0), "READ_READER");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_read_reader()
{
   {
      obj_t cnst_port_138_17;
      cnst_port_138_17 = open_input_string(string1009_read_reader);
      {
	 long i_18;
	 i_18 = ((long) 0);
       loop_19:
	 {
	    bool_t test1010_20;
	    test1010_20 = (i_18 == ((long) -1));
	    if (test1010_20)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1011_21;
		    {
		       obj_t list1012_22;
		       {
			  obj_t arg1014_23;
			  arg1014_23 = BNIL;
			  list1012_22 = MAKE_PAIR(cnst_port_138_17, arg1014_23);
		       }
		       arg1011_21 = read___reader(list1012_22);
		    }
		    CNST_TABLE_SET(i_18, arg1011_21);
		 }
		 {
		    int aux_24;
		    {
		       long aux_41;
		       aux_41 = (i_18 - ((long) 1));
		       aux_24 = (int) (aux_41);
		    }
		    {
		       long i_44;
		       i_44 = (long) (aux_24);
		       i_18 = i_44;
		       goto loop_19;
		    }
		 }
	      }
	 }
      }
   }
}


/* compiler-read */ obj_t 
compiler_read_18_read_reader(obj_t args_1)
{
   {
      obj_t value_2;
      value_2 = read___reader(args_1);
      {
	 bool_t test1002_3;
	 {
	    obj_t obj1_8;
	    obj1_8 = _reader__83_engine_param;
	    {
	       obj_t aux_47;
	       aux_47 = CNST_TABLE_REF(((long) 0));
	       test1002_3 = (obj1_8 == aux_47);
	    }
	 }
	 if (test1002_3)
	   {
	      bool_t test1003_4;
	      test1003_4 = EOF_OBJECTP(value_2);
	      if (test1003_4)
		{
		   return value_2;
		}
	      else
		{
		   if (STRINGP(value_2))
		     {
			return string_to_obj(value_2);
		     }
		   else
		     {
			FAILURE(string1007_read_reader, string1008_read_reader, value_2);
		     }
		}
	   }
	 else
	   {
	      return value_2;
	   }
      }
   }
}


/* _compiler-read */ obj_t 
_compiler_read_208_read_reader(obj_t env_15, obj_t args_16)
{
   return compiler_read_18_read_reader(args_16);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_read_reader()
{
   return module_initialization_70_engine_param(((long) 0), "READ_READER");
}
