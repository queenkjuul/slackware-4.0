/*===========================================================================*/
/*   (Expand/expander.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t create_struct(obj_t, long);
extern obj_t get_hash_29___hash(obj_t, obj_t);
extern obj_t module_initialization_70_expand_expander(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___hash(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern long get_hash_power_number(char *, long);
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
static obj_t _find_o_expander1080_88_expand_expander(obj_t, obj_t);
static obj_t _initialize_oenv__218_expand_expander(obj_t);
static obj_t imported_modules_init_94_expand_expander();
static obj_t _expander_name_103_expand_expander(obj_t, obj_t);
static obj_t _unbind_o_expander_1081_5_expand_expander(obj_t, obj_t);
extern obj_t _optim_o_macro___96_engine_param;
extern obj_t initialize_oenv__233_expand_expander();
static obj_t library_modules_init_112_expand_expander();
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_expand_expander();
extern obj_t open_input_string(obj_t);
extern obj_t put_hash__129___hash(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t arg1039_expand_expander(obj_t, obj_t);
static obj_t _install_o_comptime_expander1079_192_expand_expander(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t expander_name_181_expand_expander(obj_t);
extern obj_t install_o_comptime_expander_57_expand_expander(obj_t, obj_t);
static obj_t require_initialization_114_expand_expander = BUNSPEC;
static obj_t _oenv__72_expand_expander = BUNSPEC;
extern obj_t rem_key_hash__152___hash(obj_t, obj_t);
static obj_t cnst_init_137_expand_expander();
extern obj_t unbind_o_expander__20_expand_expander(obj_t);
extern obj_t find_o_expander_0_expand_expander(obj_t);
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(unbind_o_expander__env_49_expand_expander, _unbind_o_expander_1081_5_expand_expander1144, _unbind_o_expander_1081_5_expand_expander, 0L, 1);
DEFINE_EXPORT_PROCEDURE(install_o_comptime_expander_env_240_expand_expander, _install_o_comptime_expander1079_192_expand_expander1145, _install_o_comptime_expander1079_192_expand_expander, 0L, 2);
extern obj_t eq__env_189___r4_equivalence_6_2;
DEFINE_STATIC_PROCEDURE(proc1082_expand_expander, arg1039_expand_expander1146, arg1039_expand_expander, 0L, 1);
DEFINE_STATIC_PROCEDURE(expander_name_env_60_expand_expander, _expander_name_103_expand_expander1147, _expander_name_103_expand_expander, 0L, 1);
DEFINE_EXPORT_PROCEDURE(initialize_oenv__env_40_expand_expander, _initialize_oenv__218_expand_expander1148, _initialize_oenv__218_expand_expander, 0L, 0);
DEFINE_EXPORT_PROCEDURE(find_o_expander_env_93_expand_expander, _find_o_expander1080_88_expand_expander1149, _find_o_expander1080_88_expand_expander, 0L, 1);
DEFINE_STRING(string1085_expand_expander, string1085_expand_expander1150, "EXPANDER ", 9);
DEFINE_STRING(string1084_expand_expander, string1084_expand_expander1151, "Illegal re-installation of O-expander", 37);
DEFINE_STRING(string1083_expand_expander, string1083_expand_expander1152, "install-O-comptime-expander", 27);


/* module-initialization */ obj_t 
module_initialization_70_expand_expander(long checksum_131, char *from_132)
{
   if (CBOOL(require_initialization_114_expand_expander))
     {
	require_initialization_114_expand_expander = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_expander();
	cnst_init_137_expand_expander();
	imported_modules_init_94_expand_expander();
	toplevel_init_63_expand_expander();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_expander()
{
   module_initialization_70___hash(((long) 0), "EXPAND_EXPANDER");
   module_initialization_70___reader(((long) 0), "EXPAND_EXPANDER");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_expander()
{
   {
      obj_t cnst_port_138_123;
      cnst_port_138_123 = open_input_string(string1085_expand_expander);
      {
	 long i_124;
	 i_124 = ((long) 0);
       loop_125:
	 {
	    bool_t test1086_126;
	    test1086_126 = (i_124 == ((long) -1));
	    if (test1086_126)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1137_127;
		    {
		       obj_t list1138_128;
		       {
			  obj_t arg1142_129;
			  arg1142_129 = BNIL;
			  list1138_128 = MAKE_PAIR(cnst_port_138_123, arg1142_129);
		       }
		       arg1137_127 = read___reader(list1138_128);
		    }
		    CNST_TABLE_SET(i_124, arg1137_127);
		 }
		 {
		    int aux_130;
		    {
		       long aux_148;
		       aux_148 = (i_124 - ((long) 1));
		       aux_130 = (int) (aux_148);
		    }
		    {
		       long i_151;
		       i_151 = (long) (aux_130);
		       i_124 = i_151;
		       goto loop_125;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_expander()
{
   return (_oenv__72_expand_expander = BNIL,
      BUNSPEC);
}


/* expander-name */ obj_t 
expander_name_181_expand_expander(obj_t s_8)
{
   return STRUCT_REF(s_8, ((long) 0));
}


/* _expander-name */ obj_t 
_expander_name_103_expand_expander(obj_t env_106, obj_t s_107)
{
   return expander_name_181_expand_expander(s_107);
}


/* initialize-oenv! */ obj_t 
initialize_oenv__233_expand_expander()
{
   {
      obj_t arg1039_108;
      arg1039_108 = proc1082_expand_expander;
      {
	 obj_t list1041_35;
	 {
	    obj_t aux_155;
	    aux_155 = BINT(((long) 1024));
	    list1041_35 = MAKE_PAIR(aux_155, BNIL);
	 }
	 return (_oenv__72_expand_expander = make_hash_table_174___hash(((long) 4096), arg1039_108, expander_name_env_60_expand_expander, eq__env_189___r4_equivalence_6_2, list1041_35),
	    BUNSPEC);
      }
   }
}


/* _initialize-oenv! */ obj_t 
_initialize_oenv__218_expand_expander(obj_t env_109)
{
   return initialize_oenv__233_expand_expander();
}


/* arg1039 */ obj_t 
arg1039_expand_expander(obj_t env_110, obj_t o_111)
{
   {
      obj_t o_37;
      {
	 long aux_160;
	 o_37 = o_111;
	 {
	    obj_t arg1055_75;
	    arg1055_75 = SYMBOL_TO_STRING(o_37);
	    {
	       char *aux_162;
	       aux_162 = BSTRING_TO_STRING(arg1055_75);
	       aux_160 = get_hash_power_number(aux_162, ((long) 12));
	    }
	 }
	 return BINT(aux_160);
      }
   }
}


/* install-o-comptime-expander */ obj_t 
install_o_comptime_expander_57_expand_expander(obj_t keyword_11, obj_t function_12)
{
   {
      bool_t test1067_42;
      {
	 obj_t arg1077_44;
	 {
	    obj_t _andtest_1002_81;
	    _andtest_1002_81 = _optim_o_macro___96_engine_param;
	    if (CBOOL(_andtest_1002_81))
	      {
		 arg1077_44 = get_hash_29___hash(keyword_11, _oenv__72_expand_expander);
	      }
	    else
	      {
		 arg1077_44 = BFALSE;
	      }
	 }
	 if (STRUCTP(arg1077_44))
	   {
	      obj_t aux_173;
	      obj_t aux_171;
	      aux_173 = CNST_TABLE_REF(((long) 0));
	      aux_171 = STRUCT_KEY(arg1077_44);
	      test1067_42 = (aux_171 == aux_173);
	   }
	 else
	   {
	      test1067_42 = ((bool_t) 0);
	   }
      }
      if (test1067_42)
	{
	   return internal_error_43_tools_error(string1083_expand_expander, string1084_expand_expander, keyword_11);
	}
      else
	{
	   obj_t new_43;
	   {
	      obj_t new_92;
	      {
		 obj_t aux_178;
		 aux_178 = CNST_TABLE_REF(((long) 0));
		 new_92 = create_struct(aux_178, ((long) 2));
	      }
	      STRUCT_SET(new_92, ((long) 1), function_12);
	      STRUCT_SET(new_92, ((long) 0), keyword_11);
	      new_43 = new_92;
	   }
	   put_hash__129___hash(new_43, _oenv__72_expand_expander);
	   return new_43;
	}
   }
}


/* _install-o-comptime-expander1079 */ obj_t 
_install_o_comptime_expander1079_192_expand_expander(obj_t env_115, obj_t keyword_116, obj_t function_117)
{
   return install_o_comptime_expander_57_expand_expander(keyword_116, function_117);
}


/* find-o-expander */ obj_t 
find_o_expander_0_expand_expander(obj_t symbol_13)
{
   {
      obj_t _andtest_1002_105;
      _andtest_1002_105 = _optim_o_macro___96_engine_param;
      if (CBOOL(_andtest_1002_105))
	{
	   return get_hash_29___hash(symbol_13, _oenv__72_expand_expander);
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _find-o-expander1080 */ obj_t 
_find_o_expander1080_88_expand_expander(obj_t env_118, obj_t symbol_119)
{
   return find_o_expander_0_expand_expander(symbol_119);
}


/* unbind-o-expander! */ obj_t 
unbind_o_expander__20_expand_expander(obj_t symbol_14)
{
   return rem_key_hash__152___hash(symbol_14, _oenv__72_expand_expander);
}


/* _unbind-o-expander!1081 */ obj_t 
_unbind_o_expander_1081_5_expand_expander(obj_t env_120, obj_t symbol_121)
{
   return unbind_o_expander__20_expand_expander(symbol_121);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_expander()
{
   module_initialization_70_tools_error(((long) 0), "EXPAND_EXPANDER");
   return module_initialization_70_engine_param(((long) 0), "EXPAND_EXPANDER");
}
