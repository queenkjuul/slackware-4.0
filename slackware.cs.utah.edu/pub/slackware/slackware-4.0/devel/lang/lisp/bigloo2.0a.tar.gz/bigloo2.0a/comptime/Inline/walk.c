/*===========================================================================*/
/*   (Inline/walk.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t show_stat__192_inline_walk();
static obj_t method_init_76_inline_walk();
extern obj_t inline_sfun__229_inline_inline(variable_t, long, obj_t);
extern obj_t _optim__89_engine_param;
static obj_t _inline_setup_1641_167_inline_walk(obj_t, obj_t);
extern obj_t current_error_port;
extern obj_t _inlining_kfactor__130_engine_param;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t leave_function_170_tools_error();
static obj_t _reset_stat__205_inline_walk(obj_t);
static obj_t _inline_walk_1640_82_inline_walk(obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t reset_stat__225_inline_walk();
extern obj_t module_initialization_70_inline_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _show_stat__92_inline_walk(obj_t);
static obj_t imported_modules_init_94_inline_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t library_modules_init_112_inline_walk();
static obj_t toplevel_init_63_inline_walk();
extern obj_t open_input_string(obj_t);
obj_t _non_inlined_calls__201_inline_walk = BUNSPEC;
extern obj_t string_to_bstring(char *);
extern obj_t inline_walk__185_inline_walk(obj_t, obj_t);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
obj_t _kfactor__149_inline_walk = BUNSPEC;
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
obj_t _inlined_calls__118_inline_walk = BUNSPEC;
extern obj_t inline_setup__219_inline_walk(obj_t);
static obj_t require_initialization_114_inline_walk = BUNSPEC;
static obj_t cnst_init_137_inline_walk();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[7];

DEFINE_STATIC_PROCEDURE(show_stat__env_142_inline_walk, _show_stat__92_inline_walk1659, _show_stat__92_inline_walk, 0L, 0);
DEFINE_STATIC_PROCEDURE(reset_stat__env_118_inline_walk, _reset_stat__205_inline_walk1660, _reset_stat__205_inline_walk, 0L, 0);
DEFINE_EXPORT_PROCEDURE(inline_setup__env_11_inline_walk, _inline_setup_1641_167_inline_walk1661, _inline_setup_1641_167_inline_walk, 0L, 1);
DEFINE_EXPORT_PROCEDURE(inline_walk__env_203_inline_walk, _inline_walk_1640_82_inline_walk1662, _inline_walk_1640_82_inline_walk, 0L, 2);
DEFINE_STRING(string1653_inline_walk, string1653_inline_walk1663, "REDUCER ALL (SHOW-STAT!) INLINE SIFUN (RESET-STAT!) PASS-STARTED ", 65);
DEFINE_STRING(string1652_inline_walk, string1652_inline_walk1664, "Illegal mode", 12);
DEFINE_STRING(string1651_inline_walk, string1651_inline_walk1665, "inline-setup!", 13);
DEFINE_STRING(string1649_inline_walk, string1649_inline_walk1666, "      (inlined calls     : ", 27);
DEFINE_STRING(string1650_inline_walk, string1650_inline_walk1667, "      (non inlined calls : ", 27);
DEFINE_STRING(string1648_inline_walk, string1648_inline_walk1668, ")\n", 2);
DEFINE_STRING(string1647_inline_walk, string1647_inline_walk1669, "failure during postlude hook", 28);
DEFINE_STRING(string1646_inline_walk, string1646_inline_walk1670, " error", 6);
DEFINE_STRING(string1645_inline_walk, string1645_inline_walk1671, " occured, ending ...", 20);
DEFINE_STRING(string1644_inline_walk, string1644_inline_walk1672, "failure during prelude hook", 27);
DEFINE_STRING(string1643_inline_walk, string1643_inline_walk1673, "   . ", 5);
DEFINE_STRING(string1642_inline_walk, string1642_inline_walk1674, "Inlining", 8);


/* module-initialization */ obj_t 
module_initialization_70_inline_walk(long checksum_1185, char *from_1186)
{
   if (CBOOL(require_initialization_114_inline_walk))
     {
	require_initialization_114_inline_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_walk();
	cnst_init_137_inline_walk();
	imported_modules_init_94_inline_walk();
	method_init_76_inline_walk();
	toplevel_init_63_inline_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "INLINE_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "INLINE_WALK");
   module_initialization_70___reader(((long) 0), "INLINE_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_walk()
{
   {
      obj_t cnst_port_138_1177;
      cnst_port_138_1177 = open_input_string(string1653_inline_walk);
      {
	 long i_1178;
	 i_1178 = ((long) 6);
       loop_1179:
	 {
	    bool_t test1654_1180;
	    test1654_1180 = (i_1178 == ((long) -1));
	    if (test1654_1180)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1655_1181;
		    {
		       obj_t list1656_1182;
		       {
			  obj_t arg1657_1183;
			  arg1657_1183 = BNIL;
			  list1656_1182 = MAKE_PAIR(cnst_port_138_1177, arg1657_1183);
		       }
		       arg1655_1181 = read___reader(list1656_1182);
		    }
		    CNST_TABLE_SET(i_1178, arg1655_1181);
		 }
		 {
		    int aux_1184;
		    {
		       long aux_1205;
		       aux_1205 = (i_1178 - ((long) 1));
		       aux_1184 = (int) (aux_1205);
		    }
		    {
		       long i_1208;
		       i_1208 = (long) (aux_1184);
		       i_1178 = i_1208;
		       goto loop_1179;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_inline_walk()
{
   _inlined_calls__118_inline_walk = BINT(((long) 0));
   _non_inlined_calls__201_inline_walk = BINT(((long) 0));
   return (_kfactor__149_inline_walk = BINT(((long) 1)),
      BUNSPEC);
}


/* inline-walk! */ obj_t 
inline_walk__185_inline_walk(obj_t globals_1, obj_t what_2)
{
   {
      obj_t list1445_706;
      {
	 obj_t arg1448_708;
	 {
	    obj_t arg1450_710;
	    {
	       obj_t aux_1213;
	       aux_1213 = BCHAR(((unsigned char) '\n'));
	       arg1450_710 = MAKE_PAIR(aux_1213, BNIL);
	    }
	    arg1448_708 = MAKE_PAIR(string1642_inline_walk, arg1450_710);
	 }
	 list1445_706 = MAKE_PAIR(string1643_inline_walk, arg1448_708);
      }
      verbose_tools_speek(BINT(((long) 1)), list1445_706);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1642_inline_walk;
   {
      obj_t hooks_712;
      obj_t hnames_713;
      {
	 obj_t arg1454_715;
	 obj_t arg1455_716;
	 {
	    obj_t list1456_717;
	    list1456_717 = MAKE_PAIR(reset_stat__env_118_inline_walk, BNIL);
	    arg1454_715 = list1456_717;
	 }
	 arg1455_716 = CNST_TABLE_REF(((long) 1));
	 hooks_712 = arg1454_715;
	 hnames_713 = arg1455_716;
       loop_714:
	 if (NULLP(hooks_712))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1460_720;
	      {
		 obj_t fun1468_726;
		 fun1468_726 = CAR(hooks_712);
		 {
		    obj_t aux_1227;
		    aux_1227 = PROCEDURE_ENTRY(fun1468_726) (fun1468_726, BEOA);
		    test1460_720 = CBOOL(aux_1227);
		 }
	      }
	      if (test1460_720)
		{
		   {
		      obj_t hnames_1234;
		      obj_t hooks_1232;
		      hooks_1232 = CDR(hooks_712);
		      hnames_1234 = CDR(hnames_713);
		      hnames_713 = hnames_1234;
		      hooks_712 = hooks_1232;
		      goto loop_714;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1642_inline_walk, string1644_inline_walk, CAR(hnames_713));
		}
	   }
      }
   }
   inline_setup__219_inline_walk(what_2);
   {
      obj_t l1443_727;
      l1443_727 = globals_1;
    lname1444_728:
      if (PAIRP(l1443_727))
	{
	   {
	      obj_t g_730;
	      g_730 = CAR(l1443_727);
	      {
		 obj_t kfactor_731;
		 {
		    bool_t test_1242;
		    {
		       obj_t aux_1249;
		       obj_t aux_1243;
		       aux_1249 = CNST_TABLE_REF(((long) 2));
		       {
			  sfun_t obj_1140;
			  {
			     value_t aux_1244;
			     {
				global_t obj_1139;
				obj_1139 = (global_t) (g_730);
				aux_1244 = (((global_t) CREF(obj_1139))->value);
			     }
			     obj_1140 = (sfun_t) (aux_1244);
			  }
			  aux_1243 = (((sfun_t) CREF(obj_1140))->class);
		       }
		       test_1242 = (aux_1243 == aux_1249);
		    }
		    if (test_1242)
		      {
			 kfactor_731 = BINT(((long) 1));
		      }
		    else
		      {
			 kfactor_731 = _kfactor__149_inline_walk;
		      }
		 }
		 {
		    obj_t aux_1253;
		    {
		       global_t obj_1143;
		       obj_1143 = (global_t) (g_730);
		       aux_1253 = (((global_t) CREF(obj_1143))->id);
		    }
		    enter_function_81_tools_error(aux_1253);
		 }
		 inline_sfun__229_inline_inline((variable_t) (g_730), (long) CINT(kfactor_731), BNIL);
		 leave_function_170_tools_error();
	      }
	   }
	   {
	      obj_t l1443_1261;
	      l1443_1261 = CDR(l1443_727);
	      l1443_727 = l1443_1261;
	      goto lname1444_728;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t globals_739;
      obj_t new_globals_42_740;
      globals_739 = globals_1;
      new_globals_42_740 = BNIL;
    loop_741:
      if (NULLP(globals_739))
	{
	   {
	      obj_t value_744;
	      {
		 obj_t arg1507_771;
		 obj_t arg1510_772;
		 arg1507_771 = CNST_TABLE_REF(((long) 3));
		 arg1510_772 = reverse__39___r4_pairs_and_lists_6_3(new_globals_42_740);
		 value_744 = remove_var_123_ast_remove(arg1507_771, arg1510_772);
	      }
	      {
		 bool_t test1479_745;
		 {
		    long n1_1146;
		    n1_1146 = (long) CINT(_nb_error_on_pass__70_tools_error);
		    test1479_745 = (n1_1146 > ((long) 0));
		 }
		 if (test1479_745)
		   {
		      {
			 char *arg1483_748;
			 {
			    bool_t test1490_755;
			    {
			       bool_t test1491_756;
			       {
				  obj_t obj_1148;
				  obj_1148 = _nb_error_on_pass__70_tools_error;
				  test1491_756 = INTEGERP(obj_1148);
			       }
			       if (test1491_756)
				 {
				    test1490_755 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
				 }
			       else
				 {
				    test1490_755 = ((bool_t) 0);
				 }
			    }
			    if (test1490_755)
			      {
				 arg1483_748 = "s";
			      }
			    else
			      {
				 arg1483_748 = "";
			      }
			 }
			 {
			    obj_t list1485_750;
			    {
			       obj_t arg1486_751;
			       {
				  obj_t arg1487_752;
				  {
				     obj_t arg1488_753;
				     arg1488_753 = MAKE_PAIR(string1645_inline_walk, BNIL);
				     {
					obj_t aux_1277;
					aux_1277 = string_to_bstring(arg1483_748);
					arg1487_752 = MAKE_PAIR(aux_1277, arg1488_753);
				     }
				  }
				  arg1486_751 = MAKE_PAIR(string1646_inline_walk, arg1487_752);
			       }
			       list1485_750 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1486_751);
			    }
			    fprint___r4_output_6_10_3(current_error_port, list1485_750);
			 }
		      }
		      {
			 obj_t res1639_1150;
			 exit(((long) -1));
			 res1639_1150 = BINT(((long) -1));
			 return res1639_1150;
		      }
		   }
		 else
		   {
		      obj_t hooks_757;
		      obj_t hnames_758;
		      {
			 obj_t arg1494_760;
			 obj_t arg1496_761;
			 {
			    obj_t list1497_762;
			    list1497_762 = MAKE_PAIR(show_stat__env_142_inline_walk, BNIL);
			    arg1494_760 = list1497_762;
			 }
			 arg1496_761 = CNST_TABLE_REF(((long) 4));
			 hooks_757 = arg1494_760;
			 hnames_758 = arg1496_761;
		       loop_759:
			 if (NULLP(hooks_757))
			   {
			      return value_744;
			   }
			 else
			   {
			      bool_t test1500_765;
			      {
				 obj_t fun1506_770;
				 fun1506_770 = CAR(hooks_757);
				 {
				    obj_t aux_1290;
				    aux_1290 = PROCEDURE_ENTRY(fun1506_770) (fun1506_770, BEOA);
				    test1500_765 = CBOOL(aux_1290);
				 }
			      }
			      if (test1500_765)
				{
				   {
				      obj_t hnames_1297;
				      obj_t hooks_1295;
				      hooks_1295 = CDR(hooks_757);
				      hnames_1297 = CDR(hnames_758);
				      hnames_758 = hnames_1297;
				      hooks_757 = hooks_1295;
				      goto loop_759;
				   }
				}
			      else
				{
				   return internal_error_43_tools_error(_current_pass__25_engine_pass, string1647_inline_walk, CAR(hnames_758));
				}
			   }
		      }
		   }
	      }
	   }
	}
      else
	{
	   bool_t test1511_773;
	   {
	      obj_t obj2_1160;
	      obj2_1160 = _module__166_module_module;
	      {
		 obj_t aux_1301;
		 {
		    global_t obj_1158;
		    {
		       obj_t aux_1302;
		       aux_1302 = CAR(globals_739);
		       obj_1158 = (global_t) (aux_1302);
		    }
		    aux_1301 = (((global_t) CREF(obj_1158))->module);
		 }
		 test1511_773 = (aux_1301 == obj2_1160);
	      }
	   }
	   if (test1511_773)
	     {
		{
		   obj_t arg1513_774;
		   obj_t arg1514_775;
		   arg1513_774 = CDR(globals_739);
		   {
		      obj_t aux_1309;
		      aux_1309 = CAR(globals_739);
		      arg1514_775 = MAKE_PAIR(aux_1309, new_globals_42_740);
		   }
		   {
		      obj_t new_globals_42_1313;
		      obj_t globals_1312;
		      globals_1312 = arg1513_774;
		      new_globals_42_1313 = arg1514_775;
		      new_globals_42_740 = new_globals_42_1313;
		      globals_739 = globals_1312;
		      goto loop_741;
		   }
		}
	     }
	   else
	     {
		{
		   obj_t globals_1314;
		   globals_1314 = CDR(globals_739);
		   globals_739 = globals_1314;
		   goto loop_741;
		}
	     }
	}
   }
}


/* _inline-walk!1640 */ obj_t 
_inline_walk_1640_82_inline_walk(obj_t env_1170, obj_t globals_1171, obj_t what_1172)
{
   return inline_walk__185_inline_walk(globals_1171, what_1172);
}


/* reset-stat! */ obj_t 
reset_stat__225_inline_walk()
{
   _inlined_calls__118_inline_walk = BINT(((long) 0));
   return (_non_inlined_calls__201_inline_walk = BINT(((long) 0)),
      BUNSPEC);
}


/* _reset-stat! */ obj_t 
_reset_stat__205_inline_walk(obj_t env_1173)
{
   return reset_stat__225_inline_walk();
}


/* show-stat! */ obj_t 
show_stat__192_inline_walk()
{
   {
      obj_t list1519_780;
      {
	 obj_t arg1524_782;
	 {
	    obj_t arg1525_783;
	    arg1525_783 = MAKE_PAIR(string1648_inline_walk, BNIL);
	    arg1524_782 = MAKE_PAIR(_inlined_calls__118_inline_walk, arg1525_783);
	 }
	 list1519_780 = MAKE_PAIR(string1649_inline_walk, arg1524_782);
      }
      verbose_tools_speek(BINT(((long) 2)), list1519_780);
   }
   {
      obj_t list1528_786;
      {
	 obj_t arg1530_788;
	 {
	    obj_t arg1531_789;
	    arg1531_789 = MAKE_PAIR(string1648_inline_walk, BNIL);
	    arg1530_788 = MAKE_PAIR(_non_inlined_calls__201_inline_walk, arg1531_789);
	 }
	 list1528_786 = MAKE_PAIR(string1650_inline_walk, arg1530_788);
      }
      return verbose_tools_speek(BINT(((long) 2)), list1528_786);
   }
}


/* _show-stat! */ obj_t 
_show_stat__92_inline_walk(obj_t env_1174)
{
   return show_stat__192_inline_walk();
}


/* inline-setup! */ obj_t 
inline_setup__219_inline_walk(obj_t what_3)
{
   {
      bool_t test_1331;
      {
	 obj_t aux_1332;
	 aux_1332 = CNST_TABLE_REF(((long) 5));
	 test_1331 = (what_3 == aux_1332);
      }
      if (test_1331)
	{
	   return (_kfactor__149_inline_walk = PROCEDURE_ENTRY(_inlining_kfactor__130_engine_param) (_inlining_kfactor__130_engine_param, _optim__89_engine_param, BEOA),
	      BUNSPEC);
	}
      else
	{
	   bool_t test_1337;
	   {
	      obj_t aux_1338;
	      aux_1338 = CNST_TABLE_REF(((long) 6));
	      test_1337 = (what_3 == aux_1338);
	   }
	   if (test_1337)
	     {
		return (_kfactor__149_inline_walk = BINT(((long) 1)),
		   BUNSPEC);
	     }
	   else
	     {
		return internal_error_43_tools_error(string1651_inline_walk, string1652_inline_walk, what_3);
	     }
	}
   }
}


/* _inline-setup!1641 */ obj_t 
_inline_setup_1641_167_inline_walk(obj_t env_1175, obj_t what_1176)
{
   return inline_setup__219_inline_walk(what_1176);
}


/* method-init */ obj_t 
method_init_76_inline_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_walk()
{
   module_initialization_70_tools_speek(((long) 0), "INLINE_WALK");
   module_initialization_70_tools_error(((long) 0), "INLINE_WALK");
   module_initialization_70_engine_pass(((long) 0), "INLINE_WALK");
   module_initialization_70_tools_trace(((long) 0), "INLINE_WALK");
   module_initialization_70_type_type(((long) 0), "INLINE_WALK");
   module_initialization_70_ast_var(((long) 0), "INLINE_WALK");
   module_initialization_70_ast_node(((long) 0), "INLINE_WALK");
   module_initialization_70_tools_shape(((long) 0), "INLINE_WALK");
   module_initialization_70_module_module(((long) 0), "INLINE_WALK");
   module_initialization_70_engine_param(((long) 0), "INLINE_WALK");
   module_initialization_70_ast_remove(((long) 0), "INLINE_WALK");
   return module_initialization_70_inline_inline(((long) 0), "INLINE_WALK");
}
