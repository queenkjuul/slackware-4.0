/*===========================================================================*/
/*   (Cc/exec.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t system_kill_147_cc_exec(obj_t);
extern obj_t module_initialization_70_cc_exec(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t imported_modules_init_94_cc_exec();
static obj_t library_modules_init_112_cc_exec();
extern obj_t print___r4_output_6_10_3(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t exec_cc_exec(obj_t, bool_t, obj_t);
extern obj_t _shell__121_engine_param;
static obj_t _exec1008_cc_exec(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_cc_exec = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(exec_env_142_cc_exec, _exec1008_cc_exec1012, _exec1008_cc_exec, 0L, 3);
DEFINE_STRING(string1009_cc_exec, string1009_cc_exec1013, "system/kill", 11);
DEFINE_STRING(string1010_cc_exec, string1010_cc_exec1014, "Can't execute cmd", 17);


/* module-initialization */ obj_t 
module_initialization_70_cc_exec(long checksum_20, char *from_21)
{
   if (CBOOL(require_initialization_114_cc_exec))
     {
	require_initialization_114_cc_exec = BBOOL(((bool_t) 0));
	library_modules_init_112_cc_exec();
	imported_modules_init_94_cc_exec();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cc_exec()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CC_EXEC");
   return BUNSPEC;
}


/* exec */ obj_t 
exec_cc_exec(obj_t cmd_1, bool_t flag_2, obj_t name_3)
{
   {
      bool_t test1002_5;
      if (flag_2)
	{
	   test1002_5 = ((bool_t) 1);
	}
      else
	{
	   bool_t test1004_8;
	   {
	      obj_t obj_12;
	      obj_12 = _shell__121_engine_param;
	      test1004_8 = STRINGP(obj_12);
	   }
	   if (test1004_8)
	     {
		test1002_5 = ((bool_t) 0);
	     }
	   else
	     {
		test1002_5 = ((bool_t) 1);
	     }
	}
      if (test1002_5)
	{
	   {
	      int res_6;
	      {
		 char *aux_32;
		 aux_32 = BSTRING_TO_STRING(cmd_1);
		 res_6 = system(aux_32);
	      }
	      {
		 bool_t test_35;
		 {
		    long aux_36;
		    aux_36 = (long) (res_6);
		    test_35 = (aux_36 == ((long) 0));
		 }
		 if (test_35)
		   {
		      return BINT(res_6);
		   }
		 else
		   {
		      return exit_bigloo_229_init_main(BINT(((long) 1)));
		   }
	      }
	   }
	}
      else
	{
	   return system_kill_147_cc_exec(cmd_1);
	}
   }
}


/* _exec1008 */ obj_t 
_exec1008_cc_exec(obj_t env_16, obj_t cmd_17, obj_t flag_18, obj_t name_19)
{
   return exec_cc_exec(cmd_17, CBOOL(flag_18), name_19);
}


/* system/kill */ obj_t 
system_kill_147_cc_exec(obj_t cmd_4)
{
   {
      int arg1005_9;
      {
	 char *aux_49;
	 char *aux_47;
	 char *aux_45;
	 aux_49 = BSTRING_TO_STRING(cmd_4);
	 aux_47 = BSTRING_TO_STRING(_shell__121_engine_param);
	 aux_45 = BSTRING_TO_STRING(_shell__121_engine_param);
	 arg1005_9 = execl(aux_45, aux_47, "-c", aux_49, ((long) 0));
      }
      {
	 obj_t list1006_10;
	 {
	    obj_t aux_52;
	    aux_52 = BINT(arg1005_9);
	    list1006_10 = MAKE_PAIR(aux_52, BNIL);
	 }
	 print___r4_output_6_10_3(list1006_10);
      }
   }
   return internal_error_43_tools_error(string1009_cc_exec, string1010_cc_exec, cmd_4);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cc_exec()
{
   module_initialization_70_tools_trace(((long) 0), "CC_EXEC");
   module_initialization_70_tools_error(((long) 0), "CC_EXEC");
   module_initialization_70_engine_param(((long) 0), "CC_EXEC");
   return module_initialization_70_init_main(((long) 0), "CC_EXEC");
}
