/*===========================================================================*/
/*   (Type/tenv.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


static obj_t method_init_76_type_env();
extern obj_t for_each_hash_105___hash(obj_t, obj_t);
extern obj_t get_tenv_245_type_env();
static type_t bind_type__113_type_env(obj_t, bool_t);
static obj_t _add_tenv__212_type_env(obj_t, obj_t);
extern obj_t type_type_type;
extern type_t declare_type__118_type_env(obj_t, obj_t, obj_t);
extern type_t declare_aliastype__27_type_env(obj_t, obj_t, obj_t, type_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t __in_name__215_type_tools(obj_t);
extern obj_t get_hash_29___hash(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _set_tenv__160_type_env(obj_t, obj_t);
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70___hash(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern bool_t sub_type__174_type_env(type_t, type_t);
static bool_t _types_already_checked___82_type_env;
extern long get_hash_power_number(char *, long);
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
static obj_t _initialize_tenv__4_type_env(obj_t);
extern long class_num_218___object(obj_t);
extern type_t find_type_26_type_env(obj_t);
static obj_t imported_modules_init_94_type_env();
extern obj_t initialize_tenv__150_type_env();
extern bool_t type_exists__12_type_env(obj_t);
extern obj_t heap_add_class__147_object_class(class_t);
static obj_t _check_types_155_type_env(obj_t);
static obj_t library_modules_init_112_type_env();
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_type_env();
extern obj_t check_types_141_type_env();
extern obj_t open_input_string(obj_t);
static obj_t _type_id_65_type_env(obj_t, obj_t);
extern obj_t put_hash__129___hash(obj_t, obj_t);
static obj_t _use_foreign_type__63_type_env(obj_t, obj_t);
static obj_t _sub_type__69_type_env(obj_t, obj_t, obj_t);
extern obj_t class_object_class;
static obj_t _for_each_type__79_type_env(obj_t, obj_t);
static long get_hash_number_100_type_env(obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern type_t use_foreign_type__12_type_env(obj_t);
static obj_t _declare_type__130_type_env(obj_t, obj_t, obj_t, obj_t);
static obj_t _declare_aliastype__93_type_env(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t add_tenv__100_type_env(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t _type_exists__25_type_env(obj_t, obj_t);
static obj_t arg1353_type_env(obj_t, obj_t);
static obj_t type_id_229_type_env(type_t);
static obj_t uninitialized_types_97_type_env();
static obj_t arg1268_type_env(obj_t, obj_t);
static obj_t _find_type_214_type_env(obj_t, obj_t);
static obj_t arg1252_type_env(obj_t, obj_t);
extern obj_t _module__166_module_module;
static obj_t _declare_subtype__52_type_env(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t for_each_type__69_type_env(obj_t);
static obj_t _get_hash_number_209_type_env(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t set_tenv__70_type_env(obj_t);
extern obj_t _lib_mode__85_engine_param;
extern type_t declare_subtype__66_type_env(obj_t, obj_t, obj_t, obj_t);
static obj_t _tenv__6_type_env = BUNSPEC;
static obj_t require_initialization_114_type_env = BUNSPEC;
static obj_t _use_type__224_type_env(obj_t, obj_t);
static obj_t _get_tenv_246_type_env(obj_t);
static obj_t cnst_init_137_type_env();
static obj_t __cnst[6];

DEFINE_STATIC_PROCEDURE(get_hash_number_env_189_type_env, _get_hash_number_209_type_env1425, _get_hash_number_209_type_env, 0L, 1);
extern obj_t eq__env_189___r4_equivalence_6_2;
DEFINE_STATIC_PROCEDURE(proc1408_type_env, arg1268_type_env1426, arg1268_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(get_tenv_env_113_type_env, _get_tenv_246_type_env1427, _get_tenv_246_type_env, 0L, 0);
DEFINE_EXPORT_PROCEDURE(initialize_tenv__env_9_type_env, _initialize_tenv__4_type_env1428, _initialize_tenv__4_type_env, 0L, 0);
DEFINE_EXPORT_PROCEDURE(use_type__env_198_type_env, _use_type__224_type_env1429, _use_type__224_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(declare_aliastype__env_64_type_env, _declare_aliastype__93_type_env1430, _declare_aliastype__93_type_env, 0L, 4);
DEFINE_EXPORT_PROCEDURE(set_tenv__env_79_type_env, _set_tenv__160_type_env1431, _set_tenv__160_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(declare_type__env_220_type_env, _declare_type__130_type_env1432, _declare_type__130_type_env, 0L, 3);
DEFINE_EXPORT_PROCEDURE(add_tenv__env_189_type_env, _add_tenv__212_type_env1433, _add_tenv__212_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sub_type__env_156_type_env, _sub_type__69_type_env1434, _sub_type__69_type_env, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_exists__env_74_type_env, _type_exists__25_type_env1435, _type_exists__25_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(for_each_type__env_84_type_env, _for_each_type__79_type_env1436, _for_each_type__79_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(use_foreign_type__env_74_type_env, _use_foreign_type__63_type_env1437, _use_foreign_type__63_type_env, 0L, 1);
DEFINE_STRING(string1418_type_env, string1418_type_env1438, "(BIGLOO C _) BIGLOO EQ? TYPE-ID GET-HASH-NUMBER THE-GLOBAL-ENVIRONMENT ", 71);
DEFINE_STRING(string1417_type_env, string1417_type_env1439, "These types are used but not defined", 36);
DEFINE_STRING(string1416_type_env, string1416_type_env1440, "Illegal type class", 18);
DEFINE_STRING(string1415_type_env, string1415_type_env1441, "declare-type!", 13);
DEFINE_STRING(string1414_type_env, string1414_type_env1442, "use-type!", 9);
DEFINE_STRING(string1413_type_env, string1413_type_env1443, "Type redefinition", 17);
DEFINE_STRING(string1412_type_env, string1412_type_env1444, "bind-type!", 10);
DEFINE_STRING(string1411_type_env, string1411_type_env1445, "Can't find type", 15);
DEFINE_STRING(string1409_type_env, string1409_type_env1446, "Illegal type heap redefinition", 30);
DEFINE_STRING(string1410_type_env, string1410_type_env1447, "find-type", 9);
DEFINE_STRING(string1407_type_env, string1407_type_env1448, "Can't find super class of", 25);
DEFINE_STRING(string1406_type_env, string1406_type_env1449, "add-Tenv", 8);
DEFINE_EXPORT_PROCEDURE(find_type_env_252_type_env, _find_type_214_type_env1450, _find_type_214_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(check_types_env_232_type_env, _check_types_155_type_env1451, _check_types_155_type_env, 0L, 0);
DEFINE_STATIC_PROCEDURE(type_id_env_218_type_env, _type_id_65_type_env1452, _type_id_65_type_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(declare_subtype__env_86_type_env, _declare_subtype__52_type_env1453, _declare_subtype__52_type_env, 0L, 4);


/* module-initialization */ obj_t 
module_initialization_70_type_env(long checksum_1026, char *from_1027)
{
   if (CBOOL(require_initialization_114_type_env))
     {
	require_initialization_114_type_env = BBOOL(((bool_t) 0));
	library_modules_init_112_type_env();
	cnst_init_137_type_env();
	imported_modules_init_94_type_env();
	method_init_76_type_env();
	toplevel_init_63_type_env();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_env()
{
   module_initialization_70___hash(((long) 0), "TYPE_ENV");
   module_initialization_70___object(((long) 0), "TYPE_ENV");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TYPE_ENV");
   module_initialization_70___reader(((long) 0), "TYPE_ENV");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_type_env()
{
   {
      obj_t cnst_port_138_1018;
      cnst_port_138_1018 = open_input_string(string1418_type_env);
      {
	 long i_1019;
	 i_1019 = ((long) 5);
       loop_1020:
	 {
	    bool_t test1419_1021;
	    test1419_1021 = (i_1019 == ((long) -1));
	    if (test1419_1021)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1421_1022;
		    {
		       obj_t list1422_1023;
		       {
			  obj_t arg1423_1024;
			  arg1423_1024 = BNIL;
			  list1422_1023 = MAKE_PAIR(cnst_port_138_1018, arg1423_1024);
		       }
		       arg1421_1022 = read___reader(list1422_1023);
		    }
		    CNST_TABLE_SET(i_1019, arg1421_1022);
		 }
		 {
		    int aux_1025;
		    {
		       long aux_1046;
		       aux_1046 = (i_1019 - ((long) 1));
		       aux_1025 = (int) (aux_1046);
		    }
		    {
		       long i_1049;
		       i_1049 = (long) (aux_1025);
		       i_1019 = i_1049;
		       goto loop_1020;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_type_env()
{
   _tenv__6_type_env = CNST_TABLE_REF(((long) 0));
   return (_types_already_checked___82_type_env = ((bool_t) 0),
      BUNSPEC);
}


/* get-hash-number */ long 
get_hash_number_100_type_env(obj_t o_19)
{
   {
      obj_t arg1250_761;
      arg1250_761 = SYMBOL_TO_STRING(o_19);
      {
	 char *aux_1053;
	 aux_1053 = BSTRING_TO_STRING(arg1250_761);
	 return get_hash_power_number(aux_1053, ((long) 10));
      }
   }
}


/* _get-hash-number */ obj_t 
_get_hash_number_209_type_env(obj_t env_963, obj_t o_964)
{
   {
      long aux_1056;
      aux_1056 = get_hash_number_100_type_env(o_964);
      return BINT(aux_1056);
   }
}


/* set-tenv! */ obj_t 
set_tenv__70_type_env(obj_t tenv_20)
{
   _tenv__6_type_env = tenv_20;
   {
      obj_t s_766;
      s_766 = _tenv__6_type_env;
      STRUCT_SET(s_766, ((long) 2), get_hash_number_env_189_type_env);
   }
   {
      obj_t s_768;
      s_768 = _tenv__6_type_env;
      STRUCT_SET(s_768, ((long) 3), type_id_env_218_type_env);
   }
   {
      obj_t s_770;
      s_770 = _tenv__6_type_env;
      return STRUCT_SET(s_770, ((long) 5), eq__env_189___r4_equivalence_6_2);
   }
}


/* _set-tenv! */ obj_t 
_set_tenv__160_type_env(obj_t env_965, obj_t tenv_966)
{
   return set_tenv__70_type_env(tenv_966);
}


/* add-tenv! */ obj_t 
add_tenv__100_type_env(obj_t tenv_21)
{
   {
      obj_t remember_list_194_449;
      remember_list_194_449 = MAKE_CELL(BNIL);
      {
	 obj_t arg1252_973;
	 arg1252_973 = make_fx_procedure(arg1252_type_env, ((long) 1), ((long) 1));
	 PROCEDURE_SET(arg1252_973, ((long) 0), remember_list_194_449);
	 for_each_hash_105___hash(arg1252_973, tenv_21);
      }
      {
	 obj_t l1221_459;
	 l1221_459 = CELL_REF(remember_list_194_449);
       lname1222_460:
	 if (PAIRP(l1221_459))
	   {
	      {
		 obj_t new_462;
		 new_462 = CAR(l1221_459);
		 {
		    bool_t test1258_463;
		    test1258_463 = is_a__118___object(new_462, class_object_class);
		    if (test1258_463)
		      {
			 obj_t super_464;
			 {
			    class_t obj_784;
			    obj_784 = (class_t) (new_462);
			    {
			       obj_t aux_1072;
			       {
				  object_t aux_1073;
				  aux_1073 = (object_t) (obj_784);
				  aux_1072 = OBJECT_WIDENING(aux_1073);
			       }
			       super_464 = (((class_t) CREF(aux_1072))->its_super_214);
			    }
			 }
			 {
			    bool_t test1259_465;
			    test1259_465 = is_a__118___object(super_464, class_object_class);
			    if (test1259_465)
			      {
				 type_t old_s_201_467;
				 {
				    obj_t aux_1079;
				    {
				       type_t obj_786;
				       obj_786 = (type_t) (super_464);
				       aux_1079 = (((type_t) CREF(obj_786))->id);
				    }
				    old_s_201_467 = find_type_26_type_env(aux_1079);
				 }
				 {
				    {
				       bool_t test1260_468;
				       test1260_468 = is_a__118___object((obj_t) (old_s_201_467), class_object_class);
				       if (test1260_468)
					 {
					    class_t obj_788;
					    obj_t val1213_789;
					    obj_788 = (class_t) (new_462);
					    val1213_789 = (obj_t) (old_s_201_467);
					    {
					       obj_t aux_1088;
					       {
						  object_t aux_1089;
						  aux_1089 = (object_t) (obj_788);
						  aux_1088 = OBJECT_WIDENING(aux_1089);
					       }
					       ((((class_t) CREF(aux_1088))->its_super_214) = ((obj_t) val1213_789), BUNSPEC);
					    }
					 }
				       else
					 {
					    obj_t aux_1093;
					    {
					       type_t obj_790;
					       obj_790 = (type_t) (new_462);
					       aux_1093 = (((type_t) CREF(obj_790))->name);
					    }
					    FAILURE(string1406_type_env, string1407_type_env, aux_1093);
					 }
				    }
				 }
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
		      }
		    else
		      {
			 BUNSPEC;
		      }
		 }
	      }
	      {
		 obj_t l1221_1097;
		 l1221_1097 = CDR(l1221_459);
		 l1221_459 = l1221_1097;
		 goto lname1222_460;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   {
      obj_t arg1268_972;
      arg1268_972 = proc1408_type_env;
      return for_each_hash_105___hash(arg1268_972, _tenv__6_type_env);
   }
}


/* _add-tenv! */ obj_t 
_add_tenv__212_type_env(obj_t env_974, obj_t tenv_975)
{
   return add_tenv__100_type_env(tenv_975);
}


/* arg1268 */ obj_t 
arg1268_type_env(obj_t env_976, obj_t new_977)
{
   {
      obj_t new_474;
      {
	 bool_t aux_1101;
	 new_474 = new_977;
	 {
	    obj_t type_506;
	    type_506 = new_474;
	    {
	       obj_t l1217_508;
	       {
		  type_t obj_821;
		  obj_821 = (type_t) (type_506);
		  l1217_508 = (((type_t) CREF(obj_821))->coerce_to_204);
	       }
	     lname1218_509:
	       if (PAIRP(l1217_508))
		 {
		    {
		       obj_t coercer_512;
		       coercer_512 = CAR(l1217_508);
		       {
			  obj_t to_514;
			  to_514 = STRUCT_REF(coercer_512, ((long) 1));
			  {
			     type_t arg1294_515;
			     {
				obj_t aux_1106;
				{
				   type_t obj_830;
				   {
				      obj_t aux_1107;
				      aux_1107 = STRUCT_REF(coercer_512, ((long) 0));
				      obj_830 = (type_t) (aux_1107);
				   }
				   aux_1106 = (((type_t) CREF(obj_830))->id);
				}
				arg1294_515 = find_type_26_type_env(aux_1106);
			     }
			     {
				obj_t aux_1112;
				aux_1112 = (obj_t) (arg1294_515);
				STRUCT_SET(coercer_512, ((long) 0), aux_1112);
			     }
			  }
			  {
			     type_t arg1296_517;
			     {
				obj_t aux_1115;
				{
				   type_t obj_836;
				   obj_836 = (type_t) (to_514);
				   aux_1115 = (((type_t) CREF(obj_836))->id);
				}
				arg1296_517 = find_type_26_type_env(aux_1115);
			     }
			     {
				obj_t aux_1119;
				aux_1119 = (obj_t) (arg1296_517);
				STRUCT_SET(coercer_512, ((long) 1), aux_1119);
			     }
			  }
		       }
		    }
		    {
		       obj_t l1217_1122;
		       l1217_1122 = CDR(l1217_508);
		       l1217_508 = l1217_1122;
		       goto lname1218_509;
		    }
		 }
	       else
		 {
		    aux_1101 = ((bool_t) 1);
		 }
	    }
	 }
	 return BBOOL(aux_1101);
      }
   }
}


/* arg1252 */ obj_t 
arg1252_type_env(obj_t env_978, obj_t new_980)
{
   {
      obj_t remember_list_194_979;
      remember_list_194_979 = PROCEDURE_REF(env_978, ((long) 0));
      {
	 obj_t new_451;
	 new_451 = new_980;
	 {
	    obj_t old_477;
	    obj_t new_478;
	    obj_t from_495;
	    type_t to_496;
	    {
	       obj_t id_453;
	       {
		  type_t obj_772;
		  obj_772 = (type_t) (new_451);
		  id_453 = (((type_t) CREF(obj_772))->id);
	       }
	       {
		  obj_t old_454;
		  old_454 = get_hash_29___hash(id_453, _tenv__6_type_env);
		  {
		     {
			bool_t test1254_455;
			test1254_455 = is_a__118___object(old_454, type_type_type);
			if (test1254_455)
			  {
			     bool_t test_1133;
			     {
				type_t obj_774;
				obj_774 = (type_t) (old_454);
				test_1133 = (((type_t) CREF(obj_774))->init__47);
			     }
			     if (test_1133)
			       {
				  {
				     bool_t aux_1136;
				     old_477 = old_454;
				     new_478 = new_451;
				     {
					obj_t l1219_480;
					{
					   type_t obj_795;
					   obj_795 = (type_t) (new_478);
					   l1219_480 = (((type_t) CREF(obj_795))->coerce_to_204);
					}
				      lname1220_481:
					if (PAIRP(l1219_480))
					  {
					     {
						obj_t coercer_484;
						coercer_484 = CAR(l1219_480);
						{
						   obj_t tid_487;
						   {
						      type_t obj_804;
						      {
							 obj_t aux_1140;
							 aux_1140 = STRUCT_REF(coercer_484, ((long) 1));
							 obj_804 = (type_t) (aux_1140);
						      }
						      tid_487 = (((type_t) CREF(obj_804))->id);
						   }
						   {
						      {
							 bool_t test1274_489;
							 if (type_exists__12_type_env(tid_487))
							   {
							      bool_t test1279_492;
							      {
								 type_t arg1281_493;
								 arg1281_493 = find_type_26_type_env(tid_487);
								 {
								    obj_t aux_1147;
								    from_495 = old_477;
								    to_496 = arg1281_493;
								    {
								       obj_t coercer_498;
								       {
									  type_t obj_811;
									  obj_811 = (type_t) (from_495);
									  coercer_498 = (((type_t) CREF(obj_811))->coerce_to_204);
								       }
								     loop_499:
								       if (NULLP(coercer_498))
									 {
									    aux_1147 = BFALSE;
									 }
								       else
									 {
									    bool_t test_1150;
									    {
									       obj_t aux_1155;
									       obj_t aux_1151;
									       aux_1155 = (obj_t) (to_496);
									       {
										  obj_t aux_1152;
										  aux_1152 = CAR(coercer_498);
										  aux_1151 = STRUCT_REF(aux_1152, ((long) 1));
									       }
									       test_1150 = (aux_1151 == aux_1155);
									    }
									    if (test_1150)
									      {
										 aux_1147 = CAR(coercer_498);
									      }
									    else
									      {
										 {
										    obj_t coercer_1159;
										    coercer_1159 = CDR(coercer_498);
										    coercer_498 = coercer_1159;
										    goto loop_499;
										 }
									      }
									 }
								    }
								    test1279_492 = CBOOL(aux_1147);
								 }
							      }
							      if (test1279_492)
								{
								   test1274_489 = ((bool_t) 0);
								}
							      else
								{
								   test1274_489 = ((bool_t) 1);
								}
							   }
							 else
							   {
							      test1274_489 = ((bool_t) 1);
							   }
							 if (test1274_489)
							   {
							      obj_t arg1277_490;
							      {
								 obj_t aux_1166;
								 {
								    type_t obj_805;
								    obj_805 = (type_t) (old_477);
								    aux_1166 = (((type_t) CREF(obj_805))->coerce_to_204);
								 }
								 arg1277_490 = MAKE_PAIR(coercer_484, aux_1166);
							      }
							      {
								 type_t obj_808;
								 obj_808 = (type_t) (old_477);
								 ((((type_t) CREF(obj_808))->coerce_to_204) = ((obj_t) arg1277_490), BUNSPEC);
							      }
							   }
							 else
							   {
							      BUNSPEC;
							   }
						      }
						   }
						}
					     }
					     {
						obj_t l1219_1172;
						l1219_1172 = CDR(l1219_480);
						l1219_480 = l1219_1172;
						goto lname1220_481;
					     }
					  }
					else
					  {
					     aux_1136 = ((bool_t) 1);
					  }
				     }
				     return BBOOL(aux_1136);
				  }
			       }
			     else
			       {
				  FAILURE(string1406_type_env, string1409_type_env, id_453);
			       }
			  }
			else
			  {
			     put_hash__129___hash(new_451, _tenv__6_type_env);
			     {
				bool_t test1256_457;
				test1256_457 = is_a__118___object(new_451, class_object_class);
				if (test1256_457)
				  {
				     heap_add_class__147_object_class((class_t) (new_451));
				     {
					obj_t aux_981;
					{
					   obj_t obj2_780;
					   obj2_780 = CELL_REF(remember_list_194_979);
					   aux_981 = MAKE_PAIR(new_451, obj2_780);
					}
					return CELL_SET(remember_list_194_979, aux_981);
				     }
				  }
				else
				  {
				     return BUNSPEC;
				  }
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* get-tenv */ obj_t 
get_tenv_245_type_env()
{
   {
      obj_t s_843;
      s_843 = _tenv__6_type_env;
      {
	 obj_t aux_1187;
	 aux_1187 = CNST_TABLE_REF(((long) 1));
	 STRUCT_SET(s_843, ((long) 2), aux_1187);
      }
   }
   {
      obj_t s_846;
      s_846 = _tenv__6_type_env;
      {
	 obj_t aux_1190;
	 aux_1190 = CNST_TABLE_REF(((long) 2));
	 STRUCT_SET(s_846, ((long) 3), aux_1190);
      }
   }
   {
      obj_t s_849;
      s_849 = _tenv__6_type_env;
      {
	 obj_t aux_1193;
	 aux_1193 = CNST_TABLE_REF(((long) 3));
	 STRUCT_SET(s_849, ((long) 5), aux_1193);
      }
   }
   return _tenv__6_type_env;
}


/* _get-tenv */ obj_t 
_get_tenv_246_type_env(obj_t env_982)
{
   return get_tenv_245_type_env();
}


/* initialize-tenv! */ obj_t 
initialize_tenv__150_type_env()
{
   {
      obj_t list1305_529;
      {
	 obj_t aux_1197;
	 aux_1197 = BINT(((long) 256));
	 list1305_529 = MAKE_PAIR(aux_1197, BNIL);
      }
      return (_tenv__6_type_env = make_hash_table_174___hash(((long) 1024), get_hash_number_env_189_type_env, type_id_env_218_type_env, eq__env_189___r4_equivalence_6_2, list1305_529),
	 BUNSPEC);
   }
}


/* _initialize-tenv! */ obj_t 
_initialize_tenv__4_type_env(obj_t env_983)
{
   return initialize_tenv__150_type_env();
}


/* find-type */ type_t 
find_type_26_type_env(obj_t id_22)
{
   {
      obj_t type_532;
      type_532 = get_hash_29___hash(id_22, _tenv__6_type_env);
      {
	 bool_t test1309_533;
	 test1309_533 = is_a__118___object(type_532, type_type_type);
	 if (test1309_533)
	   {
	      return (type_t) (type_532);
	   }
	 else
	   {
	      FAILURE(string1410_type_env, string1411_type_env, id_22);
	   }
      }
   }
}


/* _find-type */ obj_t 
_find_type_214_type_env(obj_t env_984, obj_t id_985)
{
   {
      type_t aux_1207;
      aux_1207 = find_type_26_type_env(id_985);
      return (obj_t) (aux_1207);
   }
}


/* type-exists? */ bool_t 
type_exists__12_type_env(obj_t id_23)
{
   {
      obj_t type_534;
      type_534 = get_hash_29___hash(id_23, _tenv__6_type_env);
      {
	 bool_t test1310_535;
	 test1310_535 = is_a__118___object(type_534, type_type_type);
	 if (test1310_535)
	   {
	      type_t obj_857;
	      obj_857 = (type_t) (type_534);
	      return (((type_t) CREF(obj_857))->init__47);
	   }
	 else
	   {
	      return ((bool_t) 0);
	   }
      }
   }
}


/* _type-exists? */ obj_t 
_type_exists__25_type_env(obj_t env_986, obj_t id_987)
{
   {
      bool_t aux_1215;
      aux_1215 = type_exists__12_type_env(id_987);
      return BBOOL(aux_1215);
   }
}


/* bind-type! */ type_t 
bind_type__113_type_env(obj_t id_24, bool_t init__47_25)
{
   {
      obj_t type_536;
      type_536 = get_hash_29___hash(id_24, _tenv__6_type_env);
      {
	 bool_t test1311_537;
	 test1311_537 = is_a__118___object(type_536, type_type_type);
	 if (test1311_537)
	   {
	      bool_t test1312_538;
	      if (CBOOL(_lib_mode__85_engine_param))
		{
		   test1312_538 = ((bool_t) 0);
		}
	      else
		{
		   type_t obj_859;
		   obj_859 = (type_t) (type_536);
		   test1312_538 = (((type_t) CREF(obj_859))->init__47);
		}
	      if (test1312_538)
		{
		   obj_t arg1316_541;
		   arg1316_541 = shape_tools_shape(type_536);
		   {
		      obj_t aux_1227;
		      aux_1227 = user_error_151_tools_error(string1412_type_env, string1413_type_env, arg1316_541, BNIL);
		      return (type_t) (aux_1227);
		   }
		}
	      else
		{
		   if (init__47_25)
		     {
			type_t obj_860;
			obj_860 = (type_t) (type_536);
			((((type_t) CREF(obj_860))->init__47) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		     }
		   else
		     {
			BUNSPEC;
		     }
		   return (type_t) (type_536);
		}
	   }
	 else
	   {
	      type_t new_543;
	      {
		 obj_t arg1321_545;
		 arg1321_545 = CNST_TABLE_REF(((long) 4));
		 {
		    type_t res1405_890;
		    {
		       obj_t __57_870;
		       obj_t alias_871;
		       obj_t pointed_to_by_76_872;
		       __57_870 = BTRUE;
		       alias_871 = BFALSE;
		       pointed_to_by_76_872 = BFALSE;
		       {
			  type_t new1165_874;
			  new1165_874 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
			  {
			     long arg1370_875;
			     arg1370_875 = class_num_218___object(type_type_type);
			     {
				obj_t obj_888;
				obj_888 = (obj_t) (new1165_874);
				(((obj_t) CREF(obj_888))->header = MAKE_HEADER(arg1370_875, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_1239;
			     aux_1239 = (object_t) (new1165_874);
			     OBJECT_WIDENING_SET(aux_1239, alias_871);
			  }
			  ((((type_t) CREF(new1165_874))->id) = ((obj_t) id_24), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->name) = ((obj_t) BUNSPEC), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->size) = ((obj_t) BUNSPEC), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->class) = ((obj_t) arg1321_545), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->coerce_to_204) = ((obj_t) BNIL), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->parents) = ((obj_t) BNIL), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->init__47) = ((bool_t) init__47_25), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->magic__53) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->__57) = ((obj_t) __57_870), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->alias) = ((obj_t) alias_871), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_872), BUNSPEC);
			  ((((type_t) CREF(new1165_874))->tvector) = ((obj_t) BUNSPEC), BUNSPEC);
			  res1405_890 = new1165_874;
		       }
		    }
		    new_543 = res1405_890;
		 }
	      }
	      put_hash__129___hash((obj_t) (new_543), _tenv__6_type_env);
	      return new_543;
	   }
      }
   }
}


/* use-type! */ type_t 
use_type__231_type_env(obj_t id_26)
{
   {
      obj_t type_549;
      type_549 = get_hash_29___hash(id_26, _tenv__6_type_env);
      {
	 bool_t test1325_550;
	 test1325_550 = is_a__118___object(type_549, type_type_type);
	 if (test1325_550)
	   {
	      return (type_t) (type_549);
	   }
	 else
	   {
	      if (_types_already_checked___82_type_env)
		{
		   FAILURE(string1414_type_env, string1411_type_env, id_26);
		}
	      else
		{
		   return bind_type__113_type_env(id_26, ((bool_t) 0));
		}
	   }
      }
   }
}


/* _use-type! */ obj_t 
_use_type__224_type_env(obj_t env_988, obj_t id_989)
{
   {
      type_t aux_1263;
      aux_1263 = use_type__231_type_env(id_989);
      return (obj_t) (aux_1263);
   }
}


/* use-foreign-type! */ type_t 
use_foreign_type__12_type_env(obj_t id_27)
{
   {
      obj_t tid_551;
      tid_551 = parse_id_241_ast_ident(id_27);
      {
	 bool_t test1326_552;
	 {
	    obj_t arg1330_554;
	    type_t arg1331_555;
	    arg1330_554 = CDR(tid_551);
	    arg1331_555 = get_default_type_181_type_cache();
	    {
	       obj_t aux_1269;
	       aux_1269 = (obj_t) (arg1331_555);
	       test1326_552 = (arg1330_554 == aux_1269);
	    }
	 }
	 if (test1326_552)
	   {
	      return use_type__231_type_env(CAR(tid_551));
	   }
	 else
	   {
	      obj_t aux_1275;
	      aux_1275 = CDR(tid_551);
	      return (type_t) (aux_1275);
	   }
      }
   }
}


/* _use-foreign-type! */ obj_t 
_use_foreign_type__63_type_env(obj_t env_990, obj_t id_991)
{
   {
      type_t aux_1278;
      aux_1278 = use_foreign_type__12_type_env(id_991);
      return (obj_t) (aux_1278);
   }
}


/* declare-type! */ type_t 
declare_type__118_type_env(obj_t id_28, obj_t name_29, obj_t class_30)
{
   {
      bool_t test_1281;
      {
	 obj_t aux_1282;
	 aux_1282 = memq___r4_pairs_and_lists_6_3(class_30, CNST_TABLE_REF(((long) 5)));
	 test_1281 = CBOOL(aux_1282);
      }
      if (test_1281)
	{
	   type_t type_557;
	   type_557 = bind_type__113_type_env(id_28, ((bool_t) 1));
	   ((((type_t) CREF(type_557))->name) = ((obj_t) name_29), BUNSPEC);
	   {
	      obj_t arg1333_558;
	      arg1333_558 = __in_name__215_type_tools(name_29);
	      ((((type_t) CREF(type_557))->__57) = ((obj_t) arg1333_558), BUNSPEC);
	   }
	   ((((type_t) CREF(type_557))->class) = ((obj_t) class_30), BUNSPEC);
	   return type_557;
	}
      else
	{
	   obj_t aux_1291;
	   aux_1291 = user_error_151_tools_error(string1415_type_env, string1416_type_env, class_30, BNIL);
	   return (type_t) (aux_1291);
	}
   }
}


/* _declare-type! */ obj_t 
_declare_type__130_type_env(obj_t env_992, obj_t id_993, obj_t name_994, obj_t class_995)
{
   {
      type_t aux_1294;
      aux_1294 = declare_type__118_type_env(id_993, name_994, class_995);
      return (obj_t) (aux_1294);
   }
}


/* declare-subtype! */ type_t 
declare_subtype__66_type_env(obj_t id_31, obj_t name_32, obj_t parents_33, obj_t class_34)
{
   {
      type_t type_561;
      obj_t parents_562;
      type_561 = bind_type__113_type_env(id_31, ((bool_t) 1));
      if (NULLP(parents_33))
	{
	   parents_562 = BNIL;
	}
      else
	{
	   obj_t head1226_566;
	   {
	      type_t arg1350_577;
	      arg1350_577 = find_type_26_type_env(CAR(parents_33));
	      {
		 obj_t aux_1302;
		 aux_1302 = (obj_t) (arg1350_577);
		 head1226_566 = MAKE_PAIR(aux_1302, BNIL);
	      }
	   }
	   {
	      obj_t l1224_567;
	      obj_t tail1227_568;
	      l1224_567 = CDR(parents_33);
	      tail1227_568 = head1226_566;
	    lname1225_569:
	      if (NULLP(l1224_567))
		{
		   parents_562 = head1226_566;
		}
	      else
		{
		   obj_t newtail1228_572;
		   {
		      type_t arg1345_574;
		      arg1345_574 = find_type_26_type_env(CAR(l1224_567));
		      {
			 obj_t aux_1309;
			 aux_1309 = (obj_t) (arg1345_574);
			 newtail1228_572 = MAKE_PAIR(aux_1309, BNIL);
		      }
		   }
		   SET_CDR(tail1227_568, newtail1228_572);
		   {
		      obj_t tail1227_1315;
		      obj_t l1224_1313;
		      l1224_1313 = CDR(l1224_567);
		      tail1227_1315 = newtail1228_572;
		      tail1227_568 = tail1227_1315;
		      l1224_567 = l1224_1313;
		      goto lname1225_569;
		   }
		}
	   }
	}
      ((((type_t) CREF(type_561))->name) = ((obj_t) name_32), BUNSPEC);
      {
	 obj_t arg1339_563;
	 arg1339_563 = __in_name__215_type_tools(name_32);
	 ((((type_t) CREF(type_561))->__57) = ((obj_t) arg1339_563), BUNSPEC);
      }
      ((((type_t) CREF(type_561))->class) = ((obj_t) class_34), BUNSPEC);
      ((((type_t) CREF(type_561))->parents) = ((obj_t) parents_562), BUNSPEC);
      return type_561;
   }
}


/* _declare-subtype! */ obj_t 
_declare_subtype__52_type_env(obj_t env_996, obj_t id_997, obj_t name_998, obj_t parents_999, obj_t class_1000)
{
   {
      type_t aux_1322;
      aux_1322 = declare_subtype__66_type_env(id_997, name_998, parents_999, class_1000);
      return (obj_t) (aux_1322);
   }
}


/* declare-aliastype! */ type_t 
declare_aliastype__27_type_env(obj_t id_35, obj_t name_36, obj_t class_37, type_t alias_38)
{
   {
      type_t type_926;
      type_926 = declare_type__118_type_env(id_35, name_36, class_37);
      {
	 obj_t val1187_928;
	 val1187_928 = (obj_t) (alias_38);
	 ((((type_t) CREF(type_926))->alias) = ((obj_t) val1187_928), BUNSPEC);
      }
      return type_926;
   }
}


/* _declare-aliastype! */ obj_t 
_declare_aliastype__93_type_env(obj_t env_1001, obj_t id_1002, obj_t name_1003, obj_t class_1004, obj_t alias_1005)
{
   {
      type_t aux_1328;
      aux_1328 = declare_aliastype__27_type_env(id_1002, name_1003, class_1004, (type_t) (alias_1005));
      return (obj_t) (aux_1328);
   }
}


/* for-each-type! */ obj_t 
for_each_type__69_type_env(obj_t proc_39)
{
   return for_each_hash_105___hash(proc_39, _tenv__6_type_env);
}


/* _for-each-type! */ obj_t 
_for_each_type__79_type_env(obj_t env_1006, obj_t proc_1007)
{
   return for_each_type__69_type_env(proc_1007);
}


/* uninitialized-types */ obj_t 
uninitialized_types_97_type_env()
{
   {
      obj_t uninit_581;
      uninit_581 = MAKE_CELL(BNIL);
      {
	 obj_t arg1353_1008;
	 arg1353_1008 = make_fx_procedure(arg1353_type_env, ((long) 1), ((long) 1));
	 PROCEDURE_SET(arg1353_1008, ((long) 0), uninit_581);
	 for_each_hash_105___hash(arg1353_1008, _tenv__6_type_env);
      }
      return CELL_REF(uninit_581);
   }
}


/* arg1353 */ obj_t 
arg1353_type_env(obj_t env_1009, obj_t t_1011)
{
   {
      obj_t uninit_1010;
      uninit_1010 = PROCEDURE_REF(env_1009, ((long) 0));
      {
	 obj_t t_583;
	 t_583 = t_1011;
	 {
	    bool_t test_1338;
	    {
	       type_t obj_929;
	       obj_929 = (type_t) (t_583);
	       test_1338 = (((type_t) CREF(obj_929))->init__47);
	    }
	    if (test_1338)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 obj_t aux_1012;
		 {
		    obj_t obj2_931;
		    obj2_931 = CELL_REF(uninit_1010);
		    aux_1012 = MAKE_PAIR(t_583, obj2_931);
		 }
		 return CELL_SET(uninit_1010, aux_1012);
	      }
	 }
      }
   }
}


/* check-types */ obj_t 
check_types_141_type_env()
{
   {
      obj_t ut_587;
      ut_587 = uninitialized_types_97_type_env();
      if (PAIRP(ut_587))
	{
	   obj_t arg1361_590;
	   arg1361_590 = shape_tools_shape(ut_587);
	   {
	      obj_t proc_933;
	      proc_933 = _module__166_module_module;
	      FAILURE(proc_933, string1417_type_env, arg1361_590);
	   }
	}
      else
	{
	   return (_types_already_checked___82_type_env = ((bool_t) 1),
	      BUNSPEC);
	}
   }
}


/* _check-types */ obj_t 
_check_types_155_type_env(obj_t env_1013)
{
   return check_types_141_type_env();
}


/* sub-type? */ bool_t 
sub_type__174_type_env(type_t minor_40, type_t major_41)
{
   {
      bool_t test_1348;
      {
	 obj_t aux_1351;
	 obj_t aux_1349;
	 aux_1351 = (obj_t) (major_41);
	 aux_1349 = (obj_t) (minor_40);
	 test_1348 = (aux_1349 == aux_1351);
      }
      if (test_1348)
	{
	   return ((bool_t) 1);
	}
      else
	{
	   bool_t test_1354;
	   {
	      obj_t aux_1355;
	      aux_1355 = memq___r4_pairs_and_lists_6_3((obj_t) (major_41), (((type_t) CREF(minor_40))->parents));
	      test_1354 = CBOOL(aux_1355);
	   }
	   if (test_1354)
	     {
		return ((bool_t) 1);
	     }
	   else
	     {
		return ((bool_t) 0);
	     }
	}
   }
}


/* _sub-type? */ obj_t 
_sub_type__69_type_env(obj_t env_1014, obj_t minor_1015, obj_t major_1016)
{
   {
      bool_t aux_1360;
      aux_1360 = sub_type__174_type_env((type_t) (minor_1015), (type_t) (major_1016));
      return BBOOL(aux_1360);
   }
}


/* type-id */ obj_t 
type_id_229_type_env(type_t obj_129)
{
   return (((type_t) CREF(obj_129))->id);
}


/* _type-id */ obj_t 
_type_id_65_type_env(obj_t env_967, obj_t obj_968)
{
   return type_id_229_type_env((type_t) (obj_968));
}


/* method-init */ obj_t 
method_init_76_type_env()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_env()
{
   module_initialization_70_tools_trace(((long) 0), "TYPE_ENV");
   module_initialization_70_tools_shape(((long) 0), "TYPE_ENV");
   module_initialization_70_tools_error(((long) 0), "TYPE_ENV");
   module_initialization_70_ast_ident(((long) 0), "TYPE_ENV");
   module_initialization_70_ast_var(((long) 0), "TYPE_ENV");
   module_initialization_70_engine_param(((long) 0), "TYPE_ENV");
   module_initialization_70_module_module(((long) 0), "TYPE_ENV");
   module_initialization_70_type_type(((long) 0), "TYPE_ENV");
   module_initialization_70_type_tools(((long) 0), "TYPE_ENV");
   module_initialization_70_type_cache(((long) 0), "TYPE_ENV");
   return module_initialization_70_object_class(((long) 0), "TYPE_ENV");
}
