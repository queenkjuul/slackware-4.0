/*===========================================================================*/
/*   (Lalr/driver.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static long _stack_size_increment__39___lalr_driver;
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t symbol1197___lalr_driver = BUNSPEC;
static obj_t symbol1196___lalr_driver = BUNSPEC;
static obj_t symbol1192___lalr_driver = BUNSPEC;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___lalr_driver();
static obj_t grow_stack__56___lalr_driver(obj_t);
obj_t _debug_parser__183___lalr_driver = BUNSPEC;
extern obj_t list__string_78___r4_strings_6_7(obj_t);
extern obj_t __push___lalr_driver(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1014___lalr_driver(obj_t, obj_t, obj_t, obj_t);
static obj_t ___push___lalr_driver(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_string(long, unsigned char);
extern obj_t module_initialization_70___lalr_driver(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static long _max_stack_size__150___lalr_driver;
extern obj_t __make_parser_228___lalr_driver(obj_t, obj_t);
static obj_t imported_modules_init_94___lalr_driver();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t require_initialization_114___lalr_driver = BUNSPEC;
static obj_t ___make_parser_139___lalr_driver(obj_t, obj_t, obj_t);
static obj_t cnst_init_137___lalr_driver();
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( __make_parser_env_140___lalr_driver, ___make_parser_139___lalr_driver1202, ___make_parser_139___lalr_driver, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( __push_env_29___lalr_driver, ___push___lalr_driver1203, ___push___lalr_driver, 0L, 5 );
DEFINE_STRING( string1199___lalr_driver, string1199___lalr_driver1204, "parse error (unexpected token `", 31 );
DEFINE_STRING( string1198___lalr_driver, string1198___lalr_driver1205, "')", 2 );
DEFINE_STRING( string1195___lalr_driver, string1195___lalr_driver1206, "  sp=", 5 );
DEFINE_STRING( string1194___lalr_driver, string1194___lalr_driver1207, "  state=", 8 );
DEFINE_STRING( string1193___lalr_driver, string1193___lalr_driver1208, "** PARSER TRACE: input=", 23 );
DEFINE_STRING( string1200___lalr_driver, string1200___lalr_driver1209, "parser", 6 );


/* module-initialization */obj_t module_initialization_70___lalr_driver(long checksum_670, char * from_671)
{
if(CBOOL(require_initialization_114___lalr_driver)){
require_initialization_114___lalr_driver = BBOOL(((bool_t)0));
cnst_init_137___lalr_driver();
imported_modules_init_94___lalr_driver();
toplevel_init_63___lalr_driver();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___lalr_driver()
{
symbol1192___lalr_driver = string_to_symbol("*EOI*");
symbol1196___lalr_driver = string_to_symbol("ACCEPT");
return (symbol1197___lalr_driver = string_to_symbol("*ERROR*"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___lalr_driver()
{
_max_stack_size__150___lalr_driver = ((long)500);
_stack_size_increment__39___lalr_driver = ((long)200);
return (_debug_parser__183___lalr_driver = BFALSE,
BUNSPEC);
}


/* grow-stack! */obj_t grow_stack__56___lalr_driver(obj_t v_1)
{
{
long len_324;
len_324 = VECTOR_LENGTH(v_1);
{
obj_t v2_325;
{
obj_t aux_684;
long aux_682;
aux_684 = BINT(((long)0));
aux_682 = (len_324+((long)200));
v2_325 = make_vector(aux_682, aux_684);
}
{
{
long i_326;
i_326 = ((long)0);
loop_327:
if((i_326<len_324)){
{
obj_t aux_689;
aux_689 = VECTOR_REF(v_1, i_326);
VECTOR_SET(v2_325, i_326, aux_689);
}
{
long i_692;
i_692 = (i_326+((long)1));
i_326 = i_692;
goto loop_327;
}
}
 else {
return v2_325;
}
}
}
}
}
}


/* __push */obj_t __push___lalr_driver(obj_t stack_2, obj_t sp_3, obj_t new_cat_213_4, obj_t goto_table_156_5, obj_t lval_6)
{
{
long new_sp_136_557;
{
long aux_694;
aux_694 = (long)CINT(sp_3);
new_sp_136_557 = (aux_694+((long)2));
}
{
{
obj_t aux_697;
{
obj_t aux_698;
{
obj_t aux_699;
{
long aux_700;
{
obj_t aux_701;
{
long aux_702;
aux_702 = (long)CINT(sp_3);
aux_701 = VECTOR_REF(stack_2, aux_702);
}
aux_700 = (long)CINT(aux_701);
}
aux_699 = VECTOR_REF(goto_table_156_5, aux_700);
}
aux_698 = assq___r4_pairs_and_lists_6_3(new_cat_213_4, aux_699);
}
aux_697 = CDR(aux_698);
}
VECTOR_SET(stack_2, new_sp_136_557, aux_697);
}
{
long aux_710;
aux_710 = (new_sp_136_557-((long)1));
VECTOR_SET(stack_2, aux_710, lval_6);
}
return BINT(new_sp_136_557);
}
}
}


/* ___push */obj_t ___push___lalr_driver(obj_t env_654, obj_t stack_655, obj_t sp_656, obj_t new_cat_213_657, obj_t goto_table_156_658, obj_t lval_659)
{
return __push___lalr_driver(stack_655, sp_656, new_cat_213_657, goto_table_156_658, lval_659);
}


/* __make-parser */obj_t __make_parser_228___lalr_driver(obj_t action_table_22_7, obj_t reduction_function_42_8)
{
{
obj_t lambda1014_660;
lambda1014_660 = make_fx_procedure(lambda1014___lalr_driver, ((long)3), ((long)2));
PROCEDURE_SET(lambda1014_660, ((long)0), action_table_22_7);
PROCEDURE_SET(lambda1014_660, ((long)1), reduction_function_42_8);
return lambda1014_660;
}
}


/* ___make-parser */obj_t ___make_parser_139___lalr_driver(obj_t env_661, obj_t action_table_22_662, obj_t reduction_function_42_663)
{
return __make_parser_228___lalr_driver(action_table_22_662, reduction_function_42_663);
}


/* lambda1014 */obj_t lambda1014___lalr_driver(obj_t env_664, obj_t rgc_667, obj_t input_port_219_668, obj_t is_eof__68_669)
{
{
obj_t action_table_22_665;
obj_t reduction_function_42_666;
action_table_22_665 = PROCEDURE_REF(env_664, ((long)0));
reduction_function_42_666 = PROCEDURE_REF(env_664, ((long)1));
{
obj_t rgc_339;
obj_t input_port_219_340;
obj_t is_eof__68_341;
rgc_339 = rgc_667;
input_port_219_340 = input_port_219_668;
is_eof__68_341 = is_eof__68_669;
{
obj_t stack_344;
obj_t state_345;
obj_t input_346;
obj_t in_347;
obj_t attr_348;
obj_t acts_349;
obj_t act_350;
bool_t eof__196_351;
{
obj_t aux_721;
aux_721 = BINT(((long)0));
stack_344 = make_vector(((long)500), aux_721);
}
state_345 = BFALSE;
input_346 = BFALSE;
in_347 = BFALSE;
attr_348 = BFALSE;
acts_349 = BFALSE;
act_350 = BFALSE;
eof__196_351 = ((bool_t)0);
{
obj_t sp_352;
sp_352 = BINT(((long)0));
loop_353:
{
obj_t vector_574;
vector_574 = stack_344;
{
long aux_724;
aux_724 = (long)CINT(sp_352);
state_345 = VECTOR_REF(vector_574, aux_724);
}
}
{
long k_577;
k_577 = (long)CINT(state_345);
acts_349 = VECTOR_REF(action_table_22_665, k_577);
}
{
bool_t test1015_354;
{
obj_t arg1018_357;
{
obj_t pair_578;
pair_578 = acts_349;
arg1018_357 = CDR(pair_578);
}
test1015_354 = NULLP(arg1018_357);
}
if(test1015_354){
obj_t pair_580;
pair_580 = acts_349;
{
obj_t aux_732;
aux_732 = CAR(pair_580);
act_350 = CDR(aux_732);
}
}
 else {
if(CBOOL(input_346)){
BUNSPEC;
}
 else {
input_346 = PROCEDURE_ENTRY(rgc_339)(rgc_339, input_port_219_340, BEOA);
}
{
bool_t test1016_355;
{
obj_t aux_739;
aux_739 = PROCEDURE_ENTRY(is_eof__68_341)(is_eof__68_341, input_346, BEOA);
test1016_355 = CBOOL(aux_739);
}
if(test1016_355){
in_347 = symbol1192___lalr_driver;
attr_348 = BFALSE;
eof__196_351 = ((bool_t)1);
}
 else {
bool_t test1017_356;
{
obj_t obj_586;
obj_586 = input_346;
test1017_356 = PAIRP(obj_586);
}
if(test1017_356){
{
obj_t pair_587;
pair_587 = input_346;
in_347 = CAR(pair_587);
}
{
obj_t pair_588;
pair_588 = input_346;
attr_348 = CDR(pair_588);
}
}
 else {
in_347 = input_346;
attr_348 = BFALSE;
}
}
}
{
obj_t x_589;
obj_t l_590;
x_589 = in_347;
l_590 = acts_349;
{
obj_t y_591;
y_591 = assq___r4_pairs_and_lists_6_3(x_589, l_590);
if(CBOOL(y_591)){
act_350 = CDR(y_591);
}
 else {
obj_t aux_752;
aux_752 = CAR(l_590);
act_350 = CDR(aux_752);
}
}
}
}
}
if(CBOOL(_debug_parser__183___lalr_driver)){
display___r4_output_6_10_3(string1193___lalr_driver, BNIL);
display___r4_output_6_10_3(in_347, BNIL);
display___r4_output_6_10_3(string1194___lalr_driver, BNIL);
display___r4_output_6_10_3(state_345, BNIL);
display___r4_output_6_10_3(string1195___lalr_driver, BNIL);
display___r4_output_6_10_3(sp_352, BNIL);
newline___r4_output_6_10_3(BNIL);
}
 else {
BUNSPEC;
}
{
bool_t test1026_365;
{
obj_t obj1_597;
obj1_597 = act_350;
test1026_365 = (obj1_597==symbol1196___lalr_driver);
}
if(test1026_365){
{
obj_t vector_599;
vector_599 = stack_344;
return VECTOR_REF(vector_599, ((long)1));
}
}
 else {
bool_t test1027_366;
{
obj_t obj1_601;
obj1_601 = act_350;
test1027_366 = (obj1_601==symbol1197___lalr_driver);
}
if(test1027_366){
{
obj_t msg_367;
{
obj_t arg1029_369;
{
bool_t test1035_375;
{
obj_t obj_603;
obj_603 = in_347;
test1035_375 = SYMBOLP(obj_603);
}
if(test1035_375){
{
obj_t symbol_604;
symbol_604 = in_347;
arg1029_369 = SYMBOL_TO_STRING(symbol_604);
}
}
 else {
bool_t test1036_376;
{
obj_t obj_605;
obj_605 = in_347;
test1036_376 = CHARP(obj_605);
}
if(test1036_376){
{
obj_t list1037_377;
list1037_377 = MAKE_PAIR(in_347, BNIL);
{
obj_t res1191_612;
{
unsigned char aux_779;
long aux_775;
{
obj_t aux_780;
aux_780 = CAR(list1037_377);
aux_779 = (unsigned char)CCHAR(aux_780);
}
{
int aux_776;
aux_776 = (int)(((long)1));
aux_775 = (long)(aux_776);
}
res1191_612 = make_string(aux_775, aux_779);
}
arg1029_369 = res1191_612;
}
}
}
 else {
{
obj_t arg1039_379;
{
obj_t list1040_380;
list1040_380 = MAKE_PAIR(in_347, BNIL);
arg1039_379 = list1040_380;
}
arg1029_369 = list__string_78___r4_strings_6_7(arg1039_379);
}
}
}
}
{
obj_t list1031_371;
{
obj_t arg1032_372;
{
obj_t arg1033_373;
arg1033_373 = MAKE_PAIR(string1198___lalr_driver, BNIL);
arg1032_372 = MAKE_PAIR(arg1029_369, arg1033_373);
}
list1031_371 = MAKE_PAIR(string1199___lalr_driver, arg1032_372);
}
msg_367 = string_append_106___r4_strings_6_7(list1031_371);
}
}
{
obj_t object_616;
object_616 = input_346;
FAILURE(string1200___lalr_driver,msg_367,object_616);}
}
}
 else {
bool_t test1042_382;
{
long n1_617;
n1_617 = (long)CINT(act_350);
test1042_382 = (n1_617>=((long)0));
}
if(test1042_382){
{
bool_t test1043_383;
{
long arg1044_384;
{
long arg1045_385;
{
obj_t vector_619;
vector_619 = stack_344;
arg1045_385 = VECTOR_LENGTH(vector_619);
}
arg1044_384 = (arg1045_385-((long)2));
}
{
long aux_796;
aux_796 = (long)CINT(sp_352);
test1043_383 = (aux_796>=arg1044_384);
}
}
if(test1043_383){
stack_344 = grow_stack__56___lalr_driver(stack_344);
}
 else {
BUNSPEC;
}
}
{
obj_t vector_626;
obj_t obj_628;
vector_626 = stack_344;
obj_628 = attr_348;
{
long aux_801;
{
long aux_802;
aux_802 = (long)CINT(sp_352);
aux_801 = (aux_802+((long)1));
}
VECTOR_SET(vector_626, aux_801, obj_628);
}
}
{
obj_t vector_631;
obj_t obj_633;
vector_631 = stack_344;
obj_633 = act_350;
{
long aux_806;
{
long aux_807;
aux_807 = (long)CINT(sp_352);
aux_806 = (aux_807+((long)2));
}
VECTOR_SET(vector_631, aux_806, obj_633);
}
}
if(eof__196_351){
BUNSPEC;
}
 else {
input_346 = BFALSE;
}
{
obj_t sp_812;
{
long aux_813;
{
long aux_814;
aux_814 = (long)CINT(sp_352);
aux_813 = (aux_814+((long)2));
}
sp_812 = BINT(aux_813);
}
sp_352 = sp_812;
goto loop_353;
}
}
 else {
{
obj_t arg1050_390;
{
long arg1051_391;
{
long n1_636;
n1_636 = (long)CINT(act_350);
arg1051_391 = NEG(n1_636);
}
arg1050_390 = PROCEDURE_ENTRY(reduction_function_42_666)(reduction_function_42_666, BINT(arg1051_391), stack_344, sp_352, BEOA);
}
{
obj_t sp_823;
sp_823 = arg1050_390;
sp_352 = sp_823;
goto loop_353;
}
}
}
}
}
}
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___lalr_driver()
{
return module_initialization_70___error(((long)0), "__LALR_DRIVER");
}

