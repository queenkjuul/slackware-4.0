/*===========================================================================*/
/*   (Cfa/procedure.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t loose_alloc__make_procedure_app_211_cfa_procedure(obj_t, obj_t);
static obj_t method_init_76_cfa_procedure();
static obj_t _disable_x_t_2504_158_cfa_procedure(obj_t, obj_t);
static obj_t node_setup__pre_procedure_set__app_200_cfa_procedure(obj_t, obj_t);
extern obj_t cfa_export_var__93_cfa_iterate(value_t, obj_t);
extern obj_t disable_x_t__211_cfa_procedure(approx_t);
extern obj_t var_ast_node;
extern obj_t get_node_atom_value_135_cfa_approx(node_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t _obj__252_type_cache;
extern obj_t pre_procedure_set__app_208_cfa_info;
extern approx_t make_type_approx_184_cfa_approx(type_t);
static obj_t stack_loose_alloc__make_procedure_app_108_cfa_procedure(obj_t, obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern approx_t make_empty_approx_131_cfa_approx();
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_cfa_procedure(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_setup(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_closure(long, char *);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t pre_clo_env_191_cfa_info;
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern obj_t procedure_ref_app_49_cfa_info;
extern obj_t add_procedure_ref__36_cfa_closure(node_t);
static obj_t node_setup__pre_make_procedure_app_207_cfa_procedure(obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t cfa__procedure_set__app_197_cfa_procedure(obj_t, obj_t);
extern obj_t node_setup___185_cfa_setup(obj_t);
extern obj_t procedure_set__app_32_cfa_info;
static obj_t _stack_loose_alloc_2513_64_cfa_loose(obj_t, obj_t, obj_t);
extern obj_t fun_ast_var;
static obj_t _loose_alloc_2510_102_cfa_loose(obj_t, obj_t);
static obj_t stack__make_procedure_app_154_cfa_procedure(obj_t, obj_t);
static obj_t imported_modules_init_94_cfa_procedure();
extern obj_t stack_loose_alloc__95_cfa_loose(node_t, obj_t);
extern obj_t stack___129_cfa_stack(obj_t);
extern obj_t node_setup__189_cfa_setup(node_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
extern obj_t pre_make_procedure_app_60_cfa_info;
static obj_t library_modules_init_112_cfa_procedure();
extern approx_t cfa__102_cfa_cfa(node_t);
extern node_t node_heap__stack__239_cfa_stack(app_t, bool_t);
static obj_t _node_setup_2506_121_cfa_setup(obj_t, obj_t);
static obj_t arg2466_cfa_procedure(obj_t, obj_t);
static obj_t arg2460_cfa_procedure(obj_t, obj_t);
static obj_t arg2443_cfa_procedure(obj_t, obj_t);
static obj_t arg2435_cfa_procedure(obj_t, obj_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t toplevel_init_63_cfa_procedure();
static obj_t node_setup__pre_procedure_ref_app_179_cfa_procedure(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t arg2111_cfa_procedure(obj_t, obj_t);
static obj_t arg2106_cfa_procedure(obj_t, obj_t);
static obj_t _cfa_2508_47_cfa_cfa(obj_t, obj_t);
static obj_t cfa__make_procedure_app_58_cfa_procedure(obj_t, obj_t);
extern obj_t variable_ast_var;
extern obj_t make_procedure_app_48_cfa_info;
extern obj_t add_make_procedure__219_cfa_closure(node_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t pre_procedure_ref_app_85_cfa_info;
static obj_t _stack_2515_183_cfa_stack(obj_t, obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
static obj_t stack_loose_procedure_env__187_cfa_procedure(make_procedure_app_48_t, obj_t);
extern obj_t svar_cinfo_166_cfa_info;
extern obj_t _cfa_stamp__16_cfa_iterate;
static obj_t require_initialization_114_cfa_procedure = BUNSPEC;
extern approx_t make_type_alloc_approx_134_cfa_approx(type_t, node_t);
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t cfa__procedure_ref_app_118_cfa_procedure(obj_t, obj_t);
static obj_t cnst_init_137_cfa_procedure();
static obj_t __cnst[2];

extern obj_t loose_alloc__env_83_cfa_loose;
DEFINE_STATIC_PROCEDURE(proc2525_cfa_procedure, stack__make_procedure_app_154_cfa_procedure2532, stack__make_procedure_app_154_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2524_cfa_procedure, stack_loose_alloc__make_procedure_app_108_cfa_procedure2533, stack_loose_alloc__make_procedure_app_108_cfa_procedure, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2523_cfa_procedure, loose_alloc__make_procedure_app_211_cfa_procedure2534, loose_alloc__make_procedure_app_211_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2522_cfa_procedure, cfa__procedure_set__app_197_cfa_procedure2535, cfa__procedure_set__app_197_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2521_cfa_procedure, cfa__procedure_ref_app_118_cfa_procedure2536, cfa__procedure_ref_app_118_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2519_cfa_procedure, node_setup__pre_procedure_set__app_200_cfa_procedure2537, node_setup__pre_procedure_set__app_200_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2520_cfa_procedure, cfa__make_procedure_app_58_cfa_procedure2538, cfa__make_procedure_app_58_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2518_cfa_procedure, node_setup__pre_procedure_ref_app_179_cfa_procedure2539, node_setup__pre_procedure_ref_app_179_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2517_cfa_procedure, node_setup__pre_make_procedure_app_207_cfa_procedure2540, node_setup__pre_make_procedure_app_207_cfa_procedure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2516_cfa_procedure, arg2106_cfa_procedure2541, arg2106_cfa_procedure, 0L, 1);
extern obj_t cfa__env_153_cfa_cfa;
extern obj_t stack_loose_alloc__env_147_cfa_loose;
DEFINE_EXPORT_PROCEDURE(disable_x_t__env_219_cfa_procedure, _disable_x_t_2504_158_cfa_procedure2542, _disable_x_t_2504_158_cfa_procedure, 0L, 1);
DEFINE_STRING(string2526_cfa_procedure, string2526_cfa_procedure2543, "DONE ALL ", 9);
extern obj_t node_setup__env_214_cfa_setup;
extern obj_t stack__env_104_cfa_stack;


/* module-initialization */ obj_t 
module_initialization_70_cfa_procedure(long checksum_3763, char *from_3764)
{
   if (CBOOL(require_initialization_114_cfa_procedure))
     {
	require_initialization_114_cfa_procedure = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_procedure();
	cnst_init_137_cfa_procedure();
	imported_modules_init_94_cfa_procedure();
	method_init_76_cfa_procedure();
	toplevel_init_63_cfa_procedure();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_procedure()
{
   module_initialization_70___object(((long) 0), "CFA_PROCEDURE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_PROCEDURE");
   module_initialization_70___reader(((long) 0), "CFA_PROCEDURE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_procedure()
{
   {
      obj_t cnst_port_138_3755;
      cnst_port_138_3755 = open_input_string(string2526_cfa_procedure);
      {
	 long i_3756;
	 i_3756 = ((long) 1);
       loop_3757:
	 {
	    bool_t test2527_3758;
	    test2527_3758 = (i_3756 == ((long) -1));
	    if (test2527_3758)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2528_3759;
		    {
		       obj_t list2529_3760;
		       {
			  obj_t arg2530_3761;
			  arg2530_3761 = BNIL;
			  list2529_3760 = MAKE_PAIR(cnst_port_138_3755, arg2530_3761);
		       }
		       arg2528_3759 = read___reader(list2529_3760);
		    }
		    CNST_TABLE_SET(i_3756, arg2528_3759);
		 }
		 {
		    int aux_3762;
		    {
		       long aux_3782;
		       aux_3782 = (i_3756 - ((long) 1));
		       aux_3762 = (int) (aux_3782);
		    }
		    {
		       long i_3785;
		       i_3785 = (long) (aux_3762);
		       i_3756 = i_3785;
		       goto loop_3757;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_procedure()
{
   return BUNSPEC;
}


/* disable-x-t! */ obj_t 
disable_x_t__211_cfa_procedure(approx_t approx_1)
{
   {
      obj_t arg2106_3689;
      arg2106_3689 = proc2516_cfa_procedure;
      return for_each_approx_alloc_83_cfa_approx(arg2106_3689, approx_1);
   }
}


/* _disable-x-t!2504 */ obj_t 
_disable_x_t_2504_158_cfa_procedure(obj_t env_3690, obj_t approx_3691)
{
   return disable_x_t__211_cfa_procedure((approx_t) (approx_3691));
}


/* arg2106 */ obj_t 
arg2106_cfa_procedure(obj_t env_3692, obj_t app_3693)
{
   {
      obj_t app_2111;
      app_2111 = app_3693;
      {
	 bool_t test2108_2113;
	 test2108_2113 = is_a__118___object(app_2111, make_procedure_app_48_cfa_info);
	 if (test2108_2113)
	   {
	      make_procedure_app_48_t obj_3101;
	      obj_3101 = (make_procedure_app_48_t) (app_2111);
	      {
		 obj_t aux_3793;
		 {
		    object_t aux_3794;
		    aux_3794 = (object_t) (obj_3101);
		    aux_3793 = OBJECT_WIDENING(aux_3794);
		 }
		 return ((((make_procedure_app_48_t) CREF(aux_3793))->x_t__142) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	      }
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* stack-loose-procedure-env! */ obj_t 
stack_loose_procedure_env__187_cfa_procedure(make_procedure_app_48_t alloc_11, obj_t cowner_12)
{
   {
      long len_2115;
      {
	 obj_t aux_3798;
	 {
	    object_t aux_3799;
	    aux_3799 = (object_t) (alloc_11);
	    aux_3798 = OBJECT_WIDENING(aux_3799);
	 }
	 len_2115 = (((make_procedure_app_48_t) CREF(aux_3798))->values_approx_len_106);
      }
      {
	 long i_2116;
	 i_2116 = ((long) 0);
       loop_2117:
	 if ((i_2116 < len_2115))
	   {
	      {
		 approx_t arg2112_2120;
		 {
		    obj_t aux_3805;
		    {
		       object_t aux_3806;
		       aux_3806 = (object_t) (alloc_11);
		       aux_3805 = OBJECT_WIDENING(aux_3806);
		    }
		    arg2112_2120 = (((make_procedure_app_48_t) CREF(aux_3805))->values_approx_79)[i_2116];
		 }
		 {
		    obj_t arg2111_3694;
		    arg2111_3694 = make_fx_procedure(arg2111_cfa_procedure, ((long) 1), ((long) 1));
		    PROCEDURE_SET(arg2111_3694, ((long) 0), cowner_12);
		    for_each_approx_alloc_83_cfa_approx(arg2111_3694, arg2112_2120);
		 }
	      }
	      {
		 long i_3813;
		 i_3813 = (i_2116 + ((long) 1));
		 i_2116 = i_3813;
		 goto loop_2117;
	      }
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* arg2111 */ obj_t 
arg2111_cfa_procedure(obj_t env_3695, obj_t alloc_3697)
{
   {
      obj_t cowner_3696;
      cowner_3696 = PROCEDURE_REF(env_3695, ((long) 0));
      {
	 obj_t alloc_2121;
	 alloc_2121 = alloc_3697;
	 return stack_loose_alloc__95_cfa_loose((node_t) (alloc_2121), cowner_3696);
      }
   }
}


/* method-init */ obj_t 
method_init_76_cfa_procedure()
{
   {
      obj_t node_setup__pre_make_procedure_app_207_3710;
      node_setup__pre_make_procedure_app_207_3710 = proc2517_cfa_procedure;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_make_procedure_app_60_cfa_info, node_setup__pre_make_procedure_app_207_3710);
   }
   {
      obj_t node_setup__pre_procedure_ref_app_179_3709;
      node_setup__pre_procedure_ref_app_179_3709 = proc2518_cfa_procedure;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_procedure_ref_app_85_cfa_info, node_setup__pre_procedure_ref_app_179_3709);
   }
   {
      obj_t node_setup__pre_procedure_set__app_200_3708;
      node_setup__pre_procedure_set__app_200_3708 = proc2519_cfa_procedure;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_procedure_set__app_208_cfa_info, node_setup__pre_procedure_set__app_200_3708);
   }
   {
      obj_t cfa__make_procedure_app_58_3707;
      cfa__make_procedure_app_58_3707 = proc2520_cfa_procedure;
      add_method__1___object(cfa__env_153_cfa_cfa, make_procedure_app_48_cfa_info, cfa__make_procedure_app_58_3707);
   }
   {
      obj_t cfa__procedure_ref_app_118_3706;
      cfa__procedure_ref_app_118_3706 = proc2521_cfa_procedure;
      add_method__1___object(cfa__env_153_cfa_cfa, procedure_ref_app_49_cfa_info, cfa__procedure_ref_app_118_3706);
   }
   {
      obj_t cfa__procedure_set__app_197_3703;
      cfa__procedure_set__app_197_3703 = proc2522_cfa_procedure;
      add_method__1___object(cfa__env_153_cfa_cfa, procedure_set__app_32_cfa_info, cfa__procedure_set__app_197_3703);
   }
   {
      obj_t loose_alloc__make_procedure_app_211_3700;
      loose_alloc__make_procedure_app_211_3700 = proc2523_cfa_procedure;
      add_method__1___object(loose_alloc__env_83_cfa_loose, make_procedure_app_48_cfa_info, loose_alloc__make_procedure_app_211_3700);
   }
   {
      obj_t stack_loose_alloc__make_procedure_app_108_3699;
      stack_loose_alloc__make_procedure_app_108_3699 = proc2524_cfa_procedure;
      add_method__1___object(stack_loose_alloc__env_147_cfa_loose, make_procedure_app_48_cfa_info, stack_loose_alloc__make_procedure_app_108_3699);
   }
   {
      obj_t stack__make_procedure_app_154_3698;
      stack__make_procedure_app_154_3698 = proc2525_cfa_procedure;
      return add_method__1___object(stack__env_104_cfa_stack, make_procedure_app_48_cfa_info, stack__make_procedure_app_154_3698);
   }
}


/* stack!-make-procedure-app */ obj_t 
stack__make_procedure_app_154_cfa_procedure(obj_t env_3713, obj_t node_3714)
{
   {
      make_procedure_app_48_t node_3089;
      {
	 node_t aux_3827;
	 node_3089 = (make_procedure_app_48_t) (node_3714);
	 {
	    obj_t aux_3828;
	    {
	       app_t obj_3684;
	       obj_3684 = (app_t) (node_3089);
	       aux_3828 = (((app_t) CREF(obj_3684))->args);
	    }
	    stack___129_cfa_stack(aux_3828);
	 }
	 {
	    bool_t aux_3832;
	    {
	       bool_t test_3834;
	       {
		  long aux_3835;
		  {
		     obj_t aux_3836;
		     {
			object_t aux_3837;
			aux_3837 = (object_t) (node_3089);
			aux_3836 = OBJECT_WIDENING(aux_3837);
		     }
		     aux_3835 = (((make_procedure_app_48_t) CREF(aux_3836))->lost_stamp_114);
		  }
		  test_3834 = (aux_3835 == ((long) -1));
	       }
	       if (test_3834)
		 {
		    obj_t aux_3842;
		    {
		       object_t aux_3843;
		       aux_3843 = (object_t) (node_3089);
		       aux_3842 = OBJECT_WIDENING(aux_3843);
		    }
		    aux_3832 = (((make_procedure_app_48_t) CREF(aux_3842))->stackable__42);
		 }
	       else
		 {
		    aux_3832 = ((bool_t) 0);
		 }
	    }
	    aux_3827 = node_heap__stack__239_cfa_stack((app_t) (node_3089), aux_3832);
	 }
	 return (obj_t) (aux_3827);
      }
   }
}


/* stack-loose-alloc!-make-procedure-app */ obj_t 
stack_loose_alloc__make_procedure_app_108_cfa_procedure(obj_t env_3715, obj_t alloc_3716, obj_t cowner_3717)
{
   {
      make_procedure_app_48_t alloc_3069;
      obj_t cowner_3070;
      alloc_3069 = (make_procedure_app_48_t) (alloc_3716);
      cowner_3070 = cowner_3717;
      {
	 bool_t test_3850;
	 {
	    bool_t test_3851;
	    {
	       obj_t aux_3852;
	       {
		  object_t aux_3853;
		  aux_3853 = (object_t) (alloc_3069);
		  aux_3852 = OBJECT_WIDENING(aux_3853);
	       }
	       test_3851 = (((make_procedure_app_48_t) CREF(aux_3852))->stackable__42);
	    }
	    if (test_3851)
	      {
		 obj_t aux_3857;
		 {
		    obj_t aux_3858;
		    {
		       obj_t aux_3859;
		       {
			  object_t aux_3860;
			  aux_3860 = (object_t) (alloc_3069);
			  aux_3859 = OBJECT_WIDENING(aux_3860);
		       }
		       aux_3858 = (((make_procedure_app_48_t) CREF(aux_3859))->stack_stamp_31);
		    }
		    aux_3857 = memq___r4_pairs_and_lists_6_3(cowner_3070, aux_3858);
		 }
		 test_3850 = CBOOL(aux_3857);
	      }
	    else
	      {
		 test_3850 = ((bool_t) 1);
	      }
	 }
	 if (test_3850)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 obj_t arg2484_3075;
		 {
		    obj_t aux_3866;
		    {
		       obj_t aux_3867;
		       {
			  object_t aux_3868;
			  aux_3868 = (object_t) (alloc_3069);
			  aux_3867 = OBJECT_WIDENING(aux_3868);
		       }
		       aux_3866 = (((make_procedure_app_48_t) CREF(aux_3867))->stack_stamp_31);
		    }
		    arg2484_3075 = MAKE_PAIR(cowner_3070, aux_3866);
		 }
		 {
		    obj_t aux_3873;
		    {
		       object_t aux_3874;
		       aux_3874 = (object_t) (alloc_3069);
		       aux_3873 = OBJECT_WIDENING(aux_3874);
		    }
		    ((((make_procedure_app_48_t) CREF(aux_3873))->stack_stamp_31) = ((obj_t) arg2484_3075), BUNSPEC);
		 }
	      }
	      {
		 bool_t test2486_3077;
		 {
		    bool_t test2488_3079;
		    test2488_3079 = is_a__118___object(cowner_3070, variable_ast_var);
		    if (test2488_3079)
		      {
			 obj_t aux_3880;
			 {
			    variable_t aux_3881;
			    {
			       obj_t aux_3882;
			       {
				  object_t aux_3883;
				  aux_3883 = (object_t) (alloc_3069);
				  aux_3882 = OBJECT_WIDENING(aux_3883);
			       }
			       aux_3881 = (((make_procedure_app_48_t) CREF(aux_3882))->owner);
			    }
			    aux_3880 = (obj_t) (aux_3881);
			 }
			 test2486_3077 = (aux_3880 == cowner_3070);
		      }
		    else
		      {
			 test2486_3077 = ((bool_t) 1);
		      }
		 }
		 if (test2486_3077)
		   {
		      {
			 obj_t aux_3890;
			 {
			    object_t aux_3891;
			    aux_3891 = (object_t) (alloc_3069);
			    aux_3890 = OBJECT_WIDENING(aux_3891);
			 }
			 ((((make_procedure_app_48_t) CREF(aux_3890))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		      stack_loose_procedure_env__187_cfa_procedure(alloc_3069, CNST_TABLE_REF(((long) 0)));
		   }
		 else
		   {
		      stack_loose_procedure_env__187_cfa_procedure(alloc_3069, cowner_3070);
		   }
	      }
	      {
		 variable_t v_3082;
		 {
		    var_t obj_3682;
		    {
		       obj_t aux_3898;
		       {
			  obj_t aux_3899;
			  {
			     app_t obj_3680;
			     obj_3680 = (app_t) (alloc_3069);
			     aux_3899 = (((app_t) CREF(obj_3680))->args);
			  }
			  aux_3898 = CAR(aux_3899);
		       }
		       obj_3682 = (var_t) (aux_3898);
		    }
		    v_3082 = (((var_t) CREF(obj_3682))->variable);
		 }
		 {
		    return cfa_export_var__93_cfa_iterate((((variable_t) CREF(v_3082))->value), cowner_3070);
		 }
	      }
	   }
      }
   }
}


/* loose-alloc!-make-procedure-app */ obj_t 
loose_alloc__make_procedure_app_211_cfa_procedure(obj_t env_3718, obj_t alloc_3719)
{
   {
      make_procedure_app_48_t alloc_3057;
      alloc_3057 = (make_procedure_app_48_t) (alloc_3719);
      {
	 bool_t test2479_3061;
	 {
	    long arg2481_3066;
	    {
	       obj_t aux_3908;
	       {
		  object_t aux_3909;
		  aux_3909 = (object_t) (alloc_3057);
		  aux_3908 = OBJECT_WIDENING(aux_3909);
	       }
	       arg2481_3066 = (((make_procedure_app_48_t) CREF(aux_3908))->lost_stamp_114);
	    }
	    {
	       long n2_3660;
	       n2_3660 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	       test2479_3061 = (arg2481_3066 == n2_3660);
	    }
	 }
	 if (test2479_3061)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 long val1851_3662;
		 val1851_3662 = (long) CINT(_cfa_stamp__16_cfa_iterate);
		 {
		    obj_t aux_3917;
		    {
		       object_t aux_3918;
		       aux_3918 = (object_t) (alloc_3057);
		       aux_3917 = OBJECT_WIDENING(aux_3918);
		    }
		    ((((make_procedure_app_48_t) CREF(aux_3917))->lost_stamp_114) = ((long) val1851_3662), BUNSPEC);
		 }
	      }
	      {
		 variable_t v_3063;
		 {
		    var_t obj_3665;
		    {
		       obj_t aux_3922;
		       {
			  obj_t aux_3923;
			  {
			     app_t obj_3663;
			     obj_3663 = (app_t) (alloc_3057);
			     aux_3923 = (((app_t) CREF(obj_3663))->args);
			  }
			  aux_3922 = CAR(aux_3923);
		       }
		       obj_3665 = (var_t) (aux_3922);
		    }
		    v_3063 = (((var_t) CREF(obj_3665))->variable);
		 }
		 {
		    return cfa_export_var__93_cfa_iterate((((variable_t) CREF(v_3063))->value), (obj_t) (v_3063));
		 }
	      }
	   }
      }
   }
}


/* cfa!-procedure-set!-app */ obj_t 
cfa__procedure_set__app_197_cfa_procedure(obj_t env_3720, obj_t node_3721)
{
   {
      procedure_set__app_32_t node_3018;
      {
	 approx_t aux_3933;
	 node_3018 = (procedure_set__app_32_t) (node_3721);
	 {
	    node_t aux_3934;
	    {
	       obj_t aux_3935;
	       {
		  obj_t aux_3936;
		  {
		     obj_t aux_3937;
		     {
			app_t obj_3622;
			obj_3622 = (app_t) (node_3018);
			aux_3937 = (((app_t) CREF(obj_3622))->args);
		     }
		     aux_3936 = CDR(aux_3937);
		  }
		  aux_3935 = CAR(aux_3936);
	       }
	       aux_3934 = (node_t) (aux_3935);
	    }
	    cfa__102_cfa_cfa(aux_3934);
	 }
	 {
	    approx_t proc_approx_11_3024;
	    obj_t offset_3025;
	    approx_t val_approx_22_3026;
	    {
	       node_t aux_3944;
	       {
		  obj_t aux_3945;
		  {
		     obj_t aux_3946;
		     {
			app_t obj_3627;
			obj_3627 = (app_t) (node_3018);
			aux_3946 = (((app_t) CREF(obj_3627))->args);
		     }
		     aux_3945 = CAR(aux_3946);
		  }
		  aux_3944 = (node_t) (aux_3945);
	       }
	       proc_approx_11_3024 = cfa__102_cfa_cfa(aux_3944);
	    }
	    {
	       node_t aux_3952;
	       {
		  obj_t aux_3953;
		  {
		     obj_t aux_3954;
		     {
			obj_t aux_3955;
			{
			   app_t obj_3629;
			   obj_3629 = (app_t) (node_3018);
			   aux_3955 = (((app_t) CREF(obj_3629))->args);
			}
			aux_3954 = CDR(aux_3955);
		     }
		     aux_3953 = CAR(aux_3954);
		  }
		  aux_3952 = (node_t) (aux_3953);
	       }
	       offset_3025 = get_node_atom_value_135_cfa_approx(aux_3952);
	    }
	    {
	       node_t aux_3962;
	       {
		  obj_t aux_3963;
		  {
		     obj_t aux_3964;
		     {
			obj_t aux_3965;
			{
			   obj_t aux_3966;
			   {
			      app_t obj_3634;
			      obj_3634 = (app_t) (node_3018);
			      aux_3966 = (((app_t) CREF(obj_3634))->args);
			   }
			   aux_3965 = CDR(aux_3966);
			}
			aux_3964 = CDR(aux_3965);
		     }
		     aux_3963 = CAR(aux_3964);
		  }
		  aux_3962 = (node_t) (aux_3963);
	       }
	       val_approx_22_3026 = cfa__102_cfa_cfa(aux_3962);
	    }
	    if ((((approx_t) CREF(proc_approx_11_3024))->top__138))
	      {
		 approx_t aux_3976;
		 aux_3976 = loose__226_cfa_loose(val_approx_22_3026, CNST_TABLE_REF(((long) 0)));
		 (obj_t) (aux_3976);
	      }
	    else
	      {
		 if (INTEGERP(offset_3025))
		   {
		      obj_t arg2460_3701;
		      arg2460_3701 = make_fx_procedure(arg2460_cfa_procedure, ((long) 1), ((long) 2));
		      PROCEDURE_SET(arg2460_3701, ((long) 0), offset_3025);
		      {
			 obj_t aux_3984;
			 aux_3984 = (obj_t) (val_approx_22_3026);
			 PROCEDURE_SET(arg2460_3701, ((long) 1), aux_3984);
		      }
		      for_each_approx_alloc_83_cfa_approx(arg2460_3701, proc_approx_11_3024);
		   }
		 else
		   {
		      obj_t arg2466_3702;
		      arg2466_3702 = make_fx_procedure(arg2466_cfa_procedure, ((long) 1), ((long) 1));
		      {
			 obj_t aux_3989;
			 aux_3989 = (obj_t) (val_approx_22_3026);
			 PROCEDURE_SET(arg2466_3702, ((long) 0), aux_3989);
		      }
		      for_each_approx_alloc_83_cfa_approx(arg2466_3702, proc_approx_11_3024);
		   }
	      }
	    {
	       obj_t aux_3993;
	       {
		  object_t aux_3994;
		  aux_3994 = (object_t) (node_3018);
		  aux_3993 = OBJECT_WIDENING(aux_3994);
	       }
	       aux_3933 = (((procedure_set__app_32_t) CREF(aux_3993))->approx);
	    }
	 }
	 return (obj_t) (aux_3933);
      }
   }
}


/* arg2460 */ obj_t 
arg2460_cfa_procedure(obj_t env_3722, obj_t app_3725)
{
   {
      obj_t offset_3723;
      obj_t val_approx_22_3724;
      offset_3723 = PROCEDURE_REF(env_3722, ((long) 0));
      val_approx_22_3724 = PROCEDURE_REF(env_3722, ((long) 1));
      {
	 obj_t app_3031;
	 app_3031 = app_3725;
	 {
	    bool_t test2462_3033;
	    {
	       bool_t test2464_3035;
	       test2464_3035 = is_a__118___object(app_3031, make_procedure_app_48_cfa_info);
	       if (test2464_3035)
		 {
		    long aux_4006;
		    long aux_4004;
		    {
		       make_procedure_app_48_t obj_3644;
		       obj_3644 = (make_procedure_app_48_t) (app_3031);
		       {
			  obj_t aux_4008;
			  {
			     object_t aux_4009;
			     aux_4009 = (object_t) (obj_3644);
			     aux_4008 = OBJECT_WIDENING(aux_4009);
			  }
			  aux_4006 = (((make_procedure_app_48_t) CREF(aux_4008))->values_approx_len_106);
		       }
		    }
		    aux_4004 = (long) CINT(offset_3723);
		    test2462_3033 = (aux_4004 < aux_4006);
		 }
	       else
		 {
		    test2462_3033 = ((bool_t) 0);
		 }
	    }
	    if (test2462_3033)
	      {
		 approx_t aux_4015;
		 {
		    approx_t aux_4016;
		    {
		       make_procedure_app_48_t obj_3647;
		       long index_3648;
		       obj_3647 = (make_procedure_app_48_t) (app_3031);
		       index_3648 = (long) CINT(offset_3723);
		       {
			  obj_t aux_4019;
			  {
			     object_t aux_4020;
			     aux_4020 = (object_t) (obj_3647);
			     aux_4019 = OBJECT_WIDENING(aux_4020);
			  }
			  aux_4016 = (((make_procedure_app_48_t) CREF(aux_4019))->values_approx_79)[index_3648];
		       }
		    }
		    aux_4015 = union_approx__241_cfa_approx(aux_4016, (approx_t) (val_approx_22_3724));
		 }
		 return (obj_t) (aux_4015);
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* arg2466 */ obj_t 
arg2466_cfa_procedure(obj_t env_3726, obj_t app_3728)
{
   {
      obj_t val_approx_22_3727;
      val_approx_22_3727 = PROCEDURE_REF(env_3726, ((long) 0));
      {
	 obj_t app_3039;
	 app_3039 = app_3728;
	 {
	    bool_t test2468_3041;
	    test2468_3041 = is_a__118___object(app_3039, make_procedure_app_48_cfa_info);
	    if (test2468_3041)
	      {
		 long len_3042;
		 {
		    make_procedure_app_48_t obj_3650;
		    obj_3650 = (make_procedure_app_48_t) (app_3039);
		    {
		       obj_t aux_4031;
		       {
			  object_t aux_4032;
			  aux_4032 = (object_t) (obj_3650);
			  aux_4031 = OBJECT_WIDENING(aux_4032);
		       }
		       len_3042 = (((make_procedure_app_48_t) CREF(aux_4031))->values_approx_len_106);
		    }
		 }
		 {
		    long i_3043;
		    i_3043 = ((long) 0);
		  loop_3044:
		    if ((i_3043 < len_3042))
		      {
			 {
			    approx_t aux_4038;
			    {
			       make_procedure_app_48_t obj_3653;
			       obj_3653 = (make_procedure_app_48_t) (app_3039);
			       {
				  obj_t aux_4040;
				  {
				     object_t aux_4041;
				     aux_4041 = (object_t) (obj_3653);
				     aux_4040 = OBJECT_WIDENING(aux_4041);
				  }
				  aux_4038 = (((make_procedure_app_48_t) CREF(aux_4040))->values_approx_79)[i_3043];
			       }
			    }
			    union_approx__241_cfa_approx(aux_4038, (approx_t) (val_approx_22_3727));
			 }
			 {
			    long i_4047;
			    i_4047 = (i_3043 + ((long) 1));
			    i_3043 = i_4047;
			    goto loop_3044;
			 }
		      }
		    else
		      {
			 return BUNSPEC;
		      }
		 }
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* cfa!-procedure-ref-app */ obj_t 
cfa__procedure_ref_app_118_cfa_procedure(obj_t env_3729, obj_t node_3730)
{
   {
      procedure_ref_app_49_t node_2979;
      {
	 approx_t aux_4049;
	 node_2979 = (procedure_ref_app_49_t) (node_3730);
	 {
	    node_t aux_4050;
	    {
	       obj_t aux_4051;
	       {
		  obj_t aux_4052;
		  {
		     obj_t aux_4053;
		     {
			app_t obj_3589;
			obj_3589 = (app_t) (node_2979);
			aux_4053 = (((app_t) CREF(obj_3589))->args);
		     }
		     aux_4052 = CDR(aux_4053);
		  }
		  aux_4051 = CAR(aux_4052);
	       }
	       aux_4050 = (node_t) (aux_4051);
	    }
	    cfa__102_cfa_cfa(aux_4050);
	 }
	 {
	    approx_t proc_approx_11_2985;
	    obj_t offset_2986;
	    {
	       node_t aux_4060;
	       {
		  obj_t aux_4061;
		  {
		     obj_t aux_4062;
		     {
			app_t obj_3594;
			obj_3594 = (app_t) (node_2979);
			aux_4062 = (((app_t) CREF(obj_3594))->args);
		     }
		     aux_4061 = CAR(aux_4062);
		  }
		  aux_4060 = (node_t) (aux_4061);
	       }
	       proc_approx_11_2985 = cfa__102_cfa_cfa(aux_4060);
	    }
	    {
	       node_t aux_4068;
	       {
		  obj_t aux_4069;
		  {
		     obj_t aux_4070;
		     {
			obj_t aux_4071;
			{
			   app_t obj_3596;
			   obj_3596 = (app_t) (node_2979);
			   aux_4071 = (((app_t) CREF(obj_3596))->args);
			}
			aux_4070 = CDR(aux_4071);
		     }
		     aux_4069 = CAR(aux_4070);
		  }
		  aux_4068 = (node_t) (aux_4069);
	       }
	       offset_2986 = get_node_atom_value_135_cfa_approx(aux_4068);
	    }
	    if ((((approx_t) CREF(proc_approx_11_2985))->top__138))
	      {
		 approx_t aux_4080;
		 {
		    obj_t aux_4081;
		    {
		       object_t aux_4082;
		       aux_4082 = (object_t) (node_2979);
		       aux_4081 = OBJECT_WIDENING(aux_4082);
		    }
		    aux_4080 = (((procedure_ref_app_49_t) CREF(aux_4081))->approx);
		 }
		 approx_set_top__187_cfa_approx(aux_4080);
	      }
	    else
	      {
		 BUNSPEC;
	      }
	    if (INTEGERP(offset_2986))
	      {
		 obj_t arg2435_3704;
		 arg2435_3704 = make_fx_procedure(arg2435_cfa_procedure, ((long) 1), ((long) 2));
		 PROCEDURE_SET(arg2435_3704, ((long) 0), offset_2986);
		 {
		    obj_t aux_4091;
		    aux_4091 = (obj_t) (node_2979);
		    PROCEDURE_SET(arg2435_3704, ((long) 1), aux_4091);
		 }
		 for_each_approx_alloc_83_cfa_approx(arg2435_3704, proc_approx_11_2985);
	      }
	    else
	      {
		 obj_t arg2443_3705;
		 arg2443_3705 = make_fx_procedure(arg2443_cfa_procedure, ((long) 1), ((long) 1));
		 {
		    obj_t aux_4096;
		    aux_4096 = (obj_t) (node_2979);
		    PROCEDURE_SET(arg2443_3705, ((long) 0), aux_4096);
		 }
		 for_each_approx_alloc_83_cfa_approx(arg2443_3705, proc_approx_11_2985);
	      }
	    {
	       obj_t aux_4100;
	       {
		  object_t aux_4101;
		  aux_4101 = (object_t) (node_2979);
		  aux_4100 = OBJECT_WIDENING(aux_4101);
	       }
	       aux_4049 = (((procedure_ref_app_49_t) CREF(aux_4100))->approx);
	    }
	 }
	 return (obj_t) (aux_4049);
      }
   }
}


/* arg2435 */ obj_t 
arg2435_cfa_procedure(obj_t env_3731, obj_t app_3734)
{
   {
      obj_t offset_3732;
      obj_t instance2090_3733;
      offset_3732 = PROCEDURE_REF(env_3731, ((long) 0));
      instance2090_3733 = PROCEDURE_REF(env_3731, ((long) 1));
      {
	 obj_t app_2991;
	 app_2991 = app_3734;
	 {
	    bool_t test2437_2993;
	    {
	       bool_t test2441_2997;
	       test2441_2997 = is_a__118___object(app_2991, make_procedure_app_48_cfa_info);
	       if (test2441_2997)
		 {
		    long aux_4113;
		    long aux_4111;
		    {
		       make_procedure_app_48_t obj_3605;
		       obj_3605 = (make_procedure_app_48_t) (app_2991);
		       {
			  obj_t aux_4115;
			  {
			     object_t aux_4116;
			     aux_4116 = (object_t) (obj_3605);
			     aux_4115 = OBJECT_WIDENING(aux_4116);
			  }
			  aux_4113 = (((make_procedure_app_48_t) CREF(aux_4115))->values_approx_len_106);
		       }
		    }
		    aux_4111 = (long) CINT(offset_3732);
		    test2437_2993 = (aux_4111 < aux_4113);
		 }
	       else
		 {
		    test2437_2993 = ((bool_t) 0);
		 }
	    }
	    if (test2437_2993)
	      {
		 approx_t aux_4122;
		 {
		    approx_t aux_4130;
		    approx_t aux_4123;
		    {
		       make_procedure_app_48_t obj_3609;
		       long index_3610;
		       obj_3609 = (make_procedure_app_48_t) (app_2991);
		       index_3610 = (long) CINT(offset_3732);
		       {
			  obj_t aux_4133;
			  {
			     object_t aux_4134;
			     aux_4134 = (object_t) (obj_3609);
			     aux_4133 = OBJECT_WIDENING(aux_4134);
			  }
			  aux_4130 = (((make_procedure_app_48_t) CREF(aux_4133))->values_approx_79)[index_3610];
		       }
		    }
		    {
		       procedure_ref_app_49_t obj_3608;
		       obj_3608 = (procedure_ref_app_49_t) (instance2090_3733);
		       {
			  obj_t aux_4125;
			  {
			     object_t aux_4126;
			     aux_4126 = (object_t) (obj_3608);
			     aux_4125 = OBJECT_WIDENING(aux_4126);
			  }
			  aux_4123 = (((procedure_ref_app_49_t) CREF(aux_4125))->approx);
		       }
		    }
		    aux_4122 = union_approx__241_cfa_approx(aux_4123, aux_4130);
		 }
		 return (obj_t) (aux_4122);
	      }
	    else
	      {
		 approx_t aux_4140;
		 {
		    procedure_ref_app_49_t obj_3611;
		    obj_3611 = (procedure_ref_app_49_t) (instance2090_3733);
		    {
		       obj_t aux_4142;
		       {
			  object_t aux_4143;
			  aux_4143 = (object_t) (obj_3611);
			  aux_4142 = OBJECT_WIDENING(aux_4143);
		       }
		       aux_4140 = (((procedure_ref_app_49_t) CREF(aux_4142))->approx);
		    }
		 }
		 return approx_set_top__187_cfa_approx(aux_4140);
	      }
	 }
      }
   }
}


/* arg2443 */ obj_t 
arg2443_cfa_procedure(obj_t env_3735, obj_t app_3737)
{
   {
      obj_t instance2090_3736;
      instance2090_3736 = PROCEDURE_REF(env_3735, ((long) 0));
      {
	 obj_t app_3001;
	 app_3001 = app_3737;
	 {
	    bool_t test2445_3003;
	    test2445_3003 = is_a__118___object(app_3001, make_procedure_app_48_cfa_info);
	    if (test2445_3003)
	      {
		 long len_3004;
		 {
		    make_procedure_app_48_t obj_3613;
		    obj_3613 = (make_procedure_app_48_t) (app_3001);
		    {
		       obj_t aux_4152;
		       {
			  object_t aux_4153;
			  aux_4153 = (object_t) (obj_3613);
			  aux_4152 = OBJECT_WIDENING(aux_4153);
		       }
		       len_3004 = (((make_procedure_app_48_t) CREF(aux_4152))->values_approx_len_106);
		    }
		 }
		 {
		    long i_3005;
		    {
		       approx_t aux_4157;
		       i_3005 = ((long) 0);
		     loop_3006:
		       if ((i_3005 < len_3004))
			 {
			    {
			       approx_t aux_4167;
			       approx_t aux_4160;
			       {
				  make_procedure_app_48_t obj_3617;
				  obj_3617 = (make_procedure_app_48_t) (app_3001);
				  {
				     obj_t aux_4169;
				     {
					object_t aux_4170;
					aux_4170 = (object_t) (obj_3617);
					aux_4169 = OBJECT_WIDENING(aux_4170);
				     }
				     aux_4167 = (((make_procedure_app_48_t) CREF(aux_4169))->values_approx_79)[i_3005];
				  }
			       }
			       {
				  procedure_ref_app_49_t obj_3616;
				  obj_3616 = (procedure_ref_app_49_t) (instance2090_3736);
				  {
				     obj_t aux_4162;
				     {
					object_t aux_4163;
					aux_4163 = (object_t) (obj_3616);
					aux_4162 = OBJECT_WIDENING(aux_4163);
				     }
				     aux_4160 = (((procedure_ref_app_49_t) CREF(aux_4162))->approx);
				  }
			       }
			       aux_4157 = union_approx__241_cfa_approx(aux_4160, aux_4167);
			    }
			 }
		       else
			 {
			    long i_4175;
			    i_4175 = (i_3005 + ((long) 1));
			    i_3005 = i_4175;
			    goto loop_3006;
			 }
		       return (obj_t) (aux_4157);
		    }
		 }
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* cfa!-make-procedure-app */ obj_t 
cfa__make_procedure_app_58_cfa_procedure(obj_t env_3738, obj_t node_3739)
{
   {
      make_procedure_app_48_t node_2958;
      {
	 approx_t aux_4178;
	 node_2958 = (make_procedure_app_48_t) (node_3739);
	 {
	    {
	       approx_t aux_4203;
	       approx_t aux_4179;
	       {
		  obj_t aux_4204;
		  {
		     object_t aux_4205;
		     aux_4205 = (object_t) (node_2958);
		     aux_4204 = OBJECT_WIDENING(aux_4205);
		  }
		  aux_4203 = (((make_procedure_app_48_t) CREF(aux_4204))->approx);
	       }
	       {
		  svar_cinfo_166_t obj_3582;
		  {
		     value_t aux_4180;
		     {
			local_t obj_3581;
			{
			   obj_t aux_4181;
			   {
			      obj_t aux_4182;
			      {
				 sfun_t obj_3579;
				 {
				    value_t aux_4183;
				    {
				       variable_t arg2423_2969;
				       {
					  var_t obj_3577;
					  {
					     obj_t aux_4184;
					     {
						obj_t aux_4185;
						{
						   app_t obj_3575;
						   obj_3575 = (app_t) (node_2958);
						   aux_4185 = (((app_t) CREF(obj_3575))->args);
						}
						aux_4184 = CAR(aux_4185);
					     }
					     obj_3577 = (var_t) (aux_4184);
					  }
					  arg2423_2969 = (((var_t) CREF(obj_3577))->variable);
				       }
				       aux_4183 = (((variable_t) CREF(arg2423_2969))->value);
				    }
				    obj_3579 = (sfun_t) (aux_4183);
				 }
				 aux_4182 = (((sfun_t) CREF(obj_3579))->args);
			      }
			      aux_4181 = CAR(aux_4182);
			   }
			   obj_3581 = (local_t) (aux_4181);
			}
			aux_4180 = (((local_t) CREF(obj_3581))->value);
		     }
		     obj_3582 = (svar_cinfo_166_t) (aux_4180);
		  }
		  {
		     obj_t aux_4198;
		     {
			object_t aux_4199;
			aux_4199 = (object_t) (obj_3582);
			aux_4198 = OBJECT_WIDENING(aux_4199);
		     }
		     aux_4179 = (((svar_cinfo_166_t) CREF(aux_4198))->approx);
		  }
	       }
	       union_approx__241_cfa_approx(aux_4179, aux_4203);
	    }
	 }
	 {
	    obj_t l2088_2971;
	    {
	       app_t obj_3584;
	       obj_3584 = (app_t) (node_2958);
	       l2088_2971 = (((app_t) CREF(obj_3584))->args);
	    }
	  lname2089_2972:
	    if (PAIRP(l2088_2971))
	      {
		 {
		    node_t aux_4212;
		    {
		       obj_t aux_4213;
		       aux_4213 = CAR(l2088_2971);
		       aux_4212 = (node_t) (aux_4213);
		    }
		    cfa__102_cfa_cfa(aux_4212);
		 }
		 {
		    obj_t l2088_4217;
		    l2088_4217 = CDR(l2088_2971);
		    l2088_2971 = l2088_4217;
		    goto lname2089_2972;
		 }
	      }
	    else
	      {
		 ((bool_t) 1);
	      }
	 }
	 {
	    obj_t aux_4221;
	    {
	       object_t aux_4222;
	       aux_4222 = (object_t) (node_2958);
	       aux_4221 = OBJECT_WIDENING(aux_4222);
	    }
	    aux_4178 = (((make_procedure_app_48_t) CREF(aux_4221))->approx);
	 }
	 return (obj_t) (aux_4178);
      }
   }
}


/* node-setup!-pre-procedure-set!-app */ obj_t 
node_setup__pre_procedure_set__app_200_cfa_procedure(obj_t env_3740, obj_t node_3741)
{
   {
      pre_procedure_set__app_208_t node_2942;
      {
	 procedure_set__app_32_t aux_4228;
	 node_2942 = (pre_procedure_set__app_208_t) (node_3741);
	 add_procedure_ref__36_cfa_closure((node_t) (node_2942));
	 {
	    obj_t aux_4231;
	    {
	       app_t obj_3557;
	       obj_3557 = (app_t) (node_2942);
	       aux_4231 = (((app_t) CREF(obj_3557))->args);
	    }
	    node_setup___185_cfa_setup(aux_4231);
	 }
	 {
	    pre_procedure_set__app_208_t node_2947;
	    {
	       long arg2415_2953;
	       {
		  obj_t arg2416_2954;
		  {
		     obj_t arg2417_2955;
		     {
			object_t object_3558;
			object_3558 = (object_t) (node_2942);
			{
			   long arg1180_3559;
			   {
			      long arg1181_3560;
			      long arg1182_3561;
			      arg1181_3560 = TYPE(object_3558);
			      arg1182_3561 = OBJECT_TYPE;
			      arg1180_3559 = (arg1181_3560 - arg1182_3561);
			   }
			   {
			      obj_t vector_3565;
			      vector_3565 = _classes__134___object;
			      arg2417_2955 = VECTOR_REF(vector_3565, arg1180_3559);
			   }
			}
		     }
		     arg2416_2954 = class_super_145___object(arg2417_2955);
		  }
		  arg2415_2953 = class_num_218___object(arg2416_2954);
	       }
	       {
		  obj_t obj_3567;
		  obj_3567 = (obj_t) (node_2942);
		  (((obj_t) CREF(obj_3567))->header = MAKE_HEADER(arg2415_2953, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4244;
	       aux_4244 = (object_t) (node_2942);
	       OBJECT_WIDENING_SET(aux_4244, BFALSE);
	    }
	    node_2947 = node_2942;
	    {
	       procedure_set__app_32_t obj2086_2948;
	       obj2086_2948 = ((procedure_set__app_32_t) (node_2947));
	       {
		  procedure_set__app_32_t arg2412_2949;
		  {
		     approx_t arg2413_2950;
		     arg2413_2950 = make_type_approx_184_cfa_approx((type_t) (_unspec__87_type_cache));
		     {
			procedure_set__app_32_t res2503_3572;
			{
			   procedure_set__app_32_t new1870_3570;
			   new1870_3570 = ((procedure_set__app_32_t) BREF(GC_MALLOC(sizeof(struct procedure_set__app_32))));
			   ((((procedure_set__app_32_t) CREF(new1870_3570))->approx) = ((approx_t) arg2413_2950), BUNSPEC);
			   res2503_3572 = new1870_3570;
			}
			arg2412_2949 = res2503_3572;
		     }
		  }
		  {
		     obj_t aux_4254;
		     object_t aux_4252;
		     aux_4254 = (obj_t) (arg2412_2949);
		     aux_4252 = (object_t) (obj2086_2948);
		     OBJECT_WIDENING_SET(aux_4252, aux_4254);
		  }
	       }
	       {
		  long arg2414_2951;
		  arg2414_2951 = class_num_218___object(procedure_set__app_32_cfa_info);
		  {
		     obj_t obj_3573;
		     obj_3573 = (obj_t) (obj2086_2948);
		     (((obj_t) CREF(obj_3573))->header = MAKE_HEADER(arg2414_2951, 0), BUNSPEC);
		  }
	       }
	       aux_4228 = obj2086_2948;
	    }
	 }
	 return (obj_t) (aux_4228);
      }
   }
}


/* node-setup!-pre-procedure-ref-app */ obj_t 
node_setup__pre_procedure_ref_app_179_cfa_procedure(obj_t env_3742, obj_t node_3743)
{
   {
      pre_procedure_ref_app_85_t node_2926;
      {
	 procedure_ref_app_49_t aux_4262;
	 node_2926 = (pre_procedure_ref_app_85_t) (node_3743);
	 add_procedure_ref__36_cfa_closure((node_t) (node_2926));
	 {
	    obj_t aux_4265;
	    {
	       app_t obj_3539;
	       obj_3539 = (app_t) (node_2926);
	       aux_4265 = (((app_t) CREF(obj_3539))->args);
	    }
	    node_setup___185_cfa_setup(aux_4265);
	 }
	 {
	    pre_procedure_ref_app_85_t node_2931;
	    {
	       long arg2407_2937;
	       {
		  obj_t arg2408_2938;
		  {
		     obj_t arg2409_2939;
		     {
			object_t object_3540;
			object_3540 = (object_t) (node_2926);
			{
			   long arg1180_3541;
			   {
			      long arg1181_3542;
			      long arg1182_3543;
			      arg1181_3542 = TYPE(object_3540);
			      arg1182_3543 = OBJECT_TYPE;
			      arg1180_3541 = (arg1181_3542 - arg1182_3543);
			   }
			   {
			      obj_t vector_3547;
			      vector_3547 = _classes__134___object;
			      arg2409_2939 = VECTOR_REF(vector_3547, arg1180_3541);
			   }
			}
		     }
		     arg2408_2938 = class_super_145___object(arg2409_2939);
		  }
		  arg2407_2937 = class_num_218___object(arg2408_2938);
	       }
	       {
		  obj_t obj_3549;
		  obj_3549 = (obj_t) (node_2926);
		  (((obj_t) CREF(obj_3549))->header = MAKE_HEADER(arg2407_2937, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4278;
	       aux_4278 = (object_t) (node_2926);
	       OBJECT_WIDENING_SET(aux_4278, BFALSE);
	    }
	    node_2931 = node_2926;
	    {
	       procedure_ref_app_49_t obj2083_2932;
	       obj2083_2932 = ((procedure_ref_app_49_t) (node_2931));
	       {
		  procedure_ref_app_49_t arg2404_2933;
		  {
		     approx_t arg2405_2934;
		     arg2405_2934 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
		     {
			procedure_ref_app_49_t res2502_3554;
			{
			   procedure_ref_app_49_t new1858_3552;
			   new1858_3552 = ((procedure_ref_app_49_t) BREF(GC_MALLOC(sizeof(struct procedure_ref_app_49))));
			   ((((procedure_ref_app_49_t) CREF(new1858_3552))->approx) = ((approx_t) arg2405_2934), BUNSPEC);
			   res2502_3554 = new1858_3552;
			}
			arg2404_2933 = res2502_3554;
		     }
		  }
		  {
		     obj_t aux_4288;
		     object_t aux_4286;
		     aux_4288 = (obj_t) (arg2404_2933);
		     aux_4286 = (object_t) (obj2083_2932);
		     OBJECT_WIDENING_SET(aux_4286, aux_4288);
		  }
	       }
	       {
		  long arg2406_2935;
		  arg2406_2935 = class_num_218___object(procedure_ref_app_49_cfa_info);
		  {
		     obj_t obj_3555;
		     obj_3555 = (obj_t) (obj2083_2932);
		     (((obj_t) CREF(obj_3555))->header = MAKE_HEADER(arg2406_2935, 0), BUNSPEC);
		  }
	       }
	       aux_4262 = obj2083_2932;
	    }
	 }
	 return (obj_t) (aux_4262);
      }
   }
}


/* node-setup!-pre-make-procedure-app */ obj_t 
node_setup__pre_make_procedure_app_207_cfa_procedure(obj_t env_3744, obj_t node_3745)
{
   {
      pre_make_procedure_app_60_t node_2878;
      node_2878 = (pre_make_procedure_app_60_t) (node_3745);
      {
	 add_make_procedure__219_cfa_closure((node_t) (node_2878));
	 {
	    obj_t aux_4298;
	    {
	       app_t obj_3457;
	       obj_3457 = (app_t) (node_2878);
	       aux_4298 = (((app_t) CREF(obj_3457))->args);
	    }
	    node_setup___185_cfa_setup(aux_4298);
	 }
	 {
	    variable_t owner_2883;
	    {
	       obj_t aux_4302;
	       {
		  object_t aux_4303;
		  aux_4303 = (object_t) (node_2878);
		  aux_4302 = OBJECT_WIDENING(aux_4303);
	       }
	       owner_2883 = (((pre_make_procedure_app_60_t) CREF(aux_4302))->owner);
	    }
	    {
	       pre_make_procedure_app_60_t node_2884;
	       {
		  long arg2399_2921;
		  {
		     obj_t arg2400_2922;
		     {
			obj_t arg2401_2923;
			{
			   object_t object_3459;
			   object_3459 = (object_t) (node_2878);
			   {
			      long arg1180_3460;
			      {
				 long arg1181_3461;
				 long arg1182_3462;
				 arg1181_3461 = TYPE(object_3459);
				 arg1182_3462 = OBJECT_TYPE;
				 arg1180_3460 = (arg1181_3461 - arg1182_3462);
			      }
			      {
				 obj_t vector_3466;
				 vector_3466 = _classes__134___object;
				 arg2401_2923 = VECTOR_REF(vector_3466, arg1180_3460);
			      }
			   }
			}
			arg2400_2922 = class_super_145___object(arg2401_2923);
		     }
		     arg2399_2921 = class_num_218___object(arg2400_2922);
		  }
		  {
		     obj_t obj_3468;
		     obj_3468 = (obj_t) (node_2878);
		     (((obj_t) CREF(obj_3468))->header = MAKE_HEADER(arg2399_2921, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_4316;
		  aux_4316 = (object_t) (node_2878);
		  OBJECT_WIDENING_SET(aux_4316, BFALSE);
	       }
	       node_2884 = node_2878;
	       {
		  {
		     obj_t proc_size_203_2885;
		     obj_t proc_2886;
		     {
			node_t aux_4319;
			{
			   obj_t aux_4320;
			   {
			      obj_t aux_4321;
			      {
				 obj_t aux_4322;
				 {
				    obj_t aux_4323;
				    {
				       app_t obj_3470;
				       obj_3470 = (app_t) (node_2878);
				       aux_4323 = (((app_t) CREF(obj_3470))->args);
				    }
				    aux_4322 = CDR(aux_4323);
				 }
				 aux_4321 = CDR(aux_4322);
			      }
			      aux_4320 = CAR(aux_4321);
			   }
			   aux_4319 = (node_t) (aux_4320);
			}
			proc_size_203_2885 = get_node_atom_value_135_cfa_approx(aux_4319);
		     }
		     {
			obj_t aux_4331;
			{
			   app_t obj_3477;
			   obj_3477 = (app_t) (node_2878);
			   aux_4331 = (((app_t) CREF(obj_3477))->args);
			}
			proc_2886 = CAR(aux_4331);
		     }
		     {
			bool_t test2366_2887;
			if (INTEGERP(proc_size_203_2885))
			  {
			     bool_t test2387_2914;
			     test2387_2914 = is_a__118___object(proc_2886, var_ast_node);
			     if (test2387_2914)
			       {
				  obj_t aux_4339;
				  {
				     value_t aux_4340;
				     {
					variable_t arg2390_2916;
					{
					   var_t obj_3481;
					   obj_3481 = (var_t) (proc_2886);
					   arg2390_2916 = (((var_t) CREF(obj_3481))->variable);
					}
					aux_4340 = (((variable_t) CREF(arg2390_2916))->value);
				     }
				     aux_4339 = (obj_t) (aux_4340);
				  }
				  test2366_2887 = is_a__118___object(aux_4339, fun_ast_var);
			       }
			     else
			       {
				  test2366_2887 = ((bool_t) 0);
			       }
			  }
			else
			  {
			     test2366_2887 = ((bool_t) 0);
			  }
			if (test2366_2887)
			  {
			     make_procedure_app_48_t node_2888;
			     {
				make_procedure_app_48_t obj2079_2904;
				obj2079_2904 = ((make_procedure_app_48_t) (node_2884));
				{
				   make_procedure_app_48_t arg2377_2905;
				   {
				      approx_t arg2378_2906;
				      approx_t arg2380_2908;
				      arg2378_2906 = make_empty_approx_131_cfa_approx();
				      arg2380_2908 = make_empty_approx_131_cfa_approx();
				      {
					 make_procedure_app_48_t res2500_3513;
					 {
					    long values_approx_len_106_3485;
					    values_approx_len_106_3485 = (long) CINT(proc_size_203_2885);
					    {
					       make_procedure_app_48_t new1829_3494;
					       new1829_3494 = ((make_procedure_app_48_t) BREF(GC_MALLOC(sizeof(struct make_procedure_app_48))));
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->approx) = ((approx_t) arg2378_2906), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->values_approx_len_106) = ((long) values_approx_len_106_3485), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->values_approx_79) = ((approx_t *) GC_MALLOC(sizeof(struct approx) * values_approx_len_106_3485)), BUNSPEC);
					       {
						  long i1830_3506;
						  i1830_3506 = ((long) 0);
						loop1833_3505:
						  if ((i1830_3506 == values_approx_len_106_3485))
						    {
						       CNST_TABLE_REF(((long) 1));
						    }
						  else
						    {
						       ((((make_procedure_app_48_t) CREF(new1829_3494))->values_approx_79)[i1830_3506] = ((approx_t) arg2380_2908), BUNSPEC);
						       {
							  long i1830_4360;
							  i1830_4360 = (i1830_3506 + ((long) 1));
							  i1830_3506 = i1830_4360;
							  goto loop1833_3505;
						       }
						    }
					       }
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->x_t__142) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->x) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->t) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->owner) = ((variable_t) owner_2883), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->stackable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					       ((((make_procedure_app_48_t) CREF(new1829_3494))->stack_stamp_31) = ((obj_t) BNIL), BUNSPEC);
					       res2500_3513 = new1829_3494;
					    }
					 }
					 arg2377_2905 = res2500_3513;
				      }
				   }
				   {
				      obj_t aux_4371;
				      object_t aux_4369;
				      aux_4371 = (obj_t) (arg2377_2905);
				      aux_4369 = (object_t) (obj2079_2904);
				      OBJECT_WIDENING_SET(aux_4369, aux_4371);
				   }
				}
				{
				   long arg2385_2912;
				   arg2385_2912 = class_num_218___object(make_procedure_app_48_cfa_info);
				   {
				      obj_t obj_3514;
				      obj_3514 = (obj_t) (obj2079_2904);
				      (((obj_t) CREF(obj_3514))->header = MAKE_HEADER(arg2385_2912, 0), BUNSPEC);
				   }
				}
				node_2888 = obj2079_2904;
			     }
			     {
				approx_t arg2367_2889;
				arg2367_2889 = make_type_alloc_approx_134_cfa_approx((type_t) (_procedure__226_type_cache), (node_t) (node_2888));
				{
				   obj_t aux_4380;
				   {
				      object_t aux_4381;
				      aux_4381 = (object_t) (node_2888);
				      aux_4380 = OBJECT_WIDENING(aux_4381);
				   }
				   ((((make_procedure_app_48_t) CREF(aux_4380))->approx) = ((approx_t) arg2367_2889), BUNSPEC);
				}
			     }
			     {
				value_t vclo_2891;
				{
				   local_t obj_3522;
				   {
				      obj_t aux_4385;
				      {
					 obj_t aux_4386;
					 {
					    sfun_t obj_3520;
					    {
					       value_t aux_4387;
					       {
						  variable_t arg2373_2898;
						  {
						     var_t obj_3518;
						     obj_3518 = (var_t) (proc_2886);
						     arg2373_2898 = (((var_t) CREF(obj_3518))->variable);
						  }
						  aux_4387 = (((variable_t) CREF(arg2373_2898))->value);
					       }
					       obj_3520 = (sfun_t) (aux_4387);
					    }
					    aux_4386 = (((sfun_t) CREF(obj_3520))->args);
					 }
					 aux_4385 = CAR(aux_4386);
				      }
				      obj_3522 = (local_t) (aux_4385);
				   }
				   vclo_2891 = (((local_t) CREF(obj_3522))->value);
				}
				{
				   {
				      bool_t test2368_2892;
				      test2368_2892 = is_a__118___object((obj_t) (vclo_2891), svar_cinfo_166_cfa_info);
				      if (test2368_2892)
					{
					   {
					      svar_cinfo_166_t obj_3524;
					      obj_3524 = (svar_cinfo_166_t) (vclo_2891);
					      {
						 obj_t aux_4400;
						 {
						    object_t aux_4401;
						    aux_4401 = (object_t) (obj_3524);
						    aux_4400 = OBJECT_WIDENING(aux_4401);
						 }
						 ((((svar_cinfo_166_t) CREF(aux_4400))->clo_env__87) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					      }
					   }
					}
				      else
					{
					   pre_clo_env_191_t obj2080_2893;
					   obj2080_2893 = ((pre_clo_env_191_t) (vclo_2891));
					   {
					      obj_t aux_4408;
					      object_t aux_4406;
					      {
						 pre_clo_env_191_t aux_4409;
						 {
						    aux_4409 = ((pre_clo_env_191_t) BREF(GC_MALLOC(sizeof(struct pre_clo_env_191))));
						 }
						 aux_4408 = (obj_t) (aux_4409);
					      }
					      aux_4406 = (object_t) (obj2080_2893);
					      OBJECT_WIDENING_SET(aux_4406, aux_4408);
					   }
					   {
					      long arg2370_2895;
					      arg2370_2895 = class_num_218___object(pre_clo_env_191_cfa_info);
					      {
						 obj_t obj_3528;
						 obj_3528 = (obj_t) (obj2080_2893);
						 (((obj_t) CREF(obj_3528))->header = MAKE_HEADER(arg2370_2895, 0), BUNSPEC);
					      }
					   }
					   (obj_t) (obj2080_2893);
					}
				   }
				}
			     }
			     {
				long i_2899;
				i_2899 = ((long) 0);
			      loop_2900:
				{
				   bool_t test_4417;
				   {
				      long aux_4418;
				      aux_4418 = (long) CINT(proc_size_203_2885);
				      test_4417 = (i_2899 < aux_4418);
				   }
				   if (test_4417)
				     {
					{
					   approx_t arg2375_2902;
					   arg2375_2902 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
					   {
					      obj_t aux_4423;
					      {
						 object_t aux_4424;
						 aux_4424 = (object_t) (node_2888);
						 aux_4423 = OBJECT_WIDENING(aux_4424);
					      }
					      ((((make_procedure_app_48_t) CREF(aux_4423))->values_approx_79)[i_2899] = ((approx_t) arg2375_2902), BUNSPEC);
					   }
					}
					{
					   long i_4428;
					   i_4428 = (i_2899 + ((long) 1));
					   i_2899 = i_4428;
					   goto loop_2900;
					}
				     }
				   else
				     {
					return BUNSPEC;
				     }
				}
			     }
			  }
			else
			  {
			     {
				obj_t next_method2096_242_2924;
				next_method2096_242_2924 = find_super_class_method_167___object((object_t) (node_2878), node_setup__env_214_cfa_setup, pre_make_procedure_app_60_cfa_info);
				if (PROCEDUREP(next_method2096_242_2924))
				  {
				     return PROCEDURE_ENTRY(next_method2096_242_2924) (next_method2096_242_2924, (obj_t) (node_2878), BEOA);
				  }
				else
				  {
				     PROCEDURE_SET(node_setup__env_214_cfa_setup, ((long) 2), next_method2096_242_2924);
				     return node_setup__189_cfa_setup((node_t) (node_2878));
				  }
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_procedure()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_tools_error(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_tools_shape(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_type_type(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_type_cache(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_ast_var(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_ast_node(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_info(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_loose(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_setup(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_approx(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_PROCEDURE");
   module_initialization_70_cfa_closure(((long) 0), "CFA_PROCEDURE");
   return module_initialization_70_cfa_stack(((long) 0), "CFA_PROCEDURE");
}
