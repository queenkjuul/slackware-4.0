/*===========================================================================*/
/*   (Ast/node.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern obj_t cast_arg_set__132_ast_node(cast_t, node_t);
static obj_t _make_cast2595_213_ast_node(obj_t, obj_t, obj_t, obj_t);
static obj_t struct_object__object_var_138_ast_node(obj_t, obj_t, obj_t);
static obj_t _node_effect_type2673_60_ast_node(obj_t, obj_t);
extern obj_t set_ex_it_type_set__207_ast_node(set_ex_it_116_t, type_t);
extern obj_t let_fun_locals_set__199_ast_node(let_fun_218_t, obj_t);
static obj_t _app_ly_loc2621_94_ast_node(obj_t, obj_t);
static obj_t method_init_76_ast_node();
static obj_t _set_ex_it_loc2526_190_ast_node(obj_t, obj_t);
obj_t make_box_202_ast_node = BUNSPEC;
static obj_t object__struct_jump_ex_it_205_ast_node(obj_t, obj_t);
static obj_t _pragma_args2609_133_ast_node(obj_t, obj_t);
static obj_t _setq_type_set_2589_129_ast_node(obj_t, obj_t, obj_t);
static obj_t _app_side_effect_2633_41_ast_node(obj_t, obj_t);
extern obj_t conditional_true_set__127_ast_node(conditional_t, node_t);
extern obj_t box_ref_loc_220_ast_node(box_ref_242_t);
extern node_t jump_ex_it_exit_9_ast_node(jump_ex_it_184_t);
static obj_t _make_box_set_2493_36_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t);
obj_t funcall_ast_node = BUNSPEC;
extern obj_t sequence_nodes_243_ast_node(sequence_t);
static obj_t _var__148_ast_node(obj_t, obj_t);
extern app_t make_app_213_ast_node(obj_t, type_t, obj_t, obj_t, var_t, obj_t, obj_t);
extern bool_t box_set___31_ast_node(obj_t);
extern obj_t app_side_effect__set__78_ast_node(app_t, obj_t);
obj_t node_effect_213_ast_node = BUNSPEC;
static obj_t object__struct_app_142_ast_node(obj_t, obj_t);
static obj_t object__struct_app_ly_240_ast_node(obj_t, obj_t);
static obj_t _make_let_var2533_130_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _atom_value_set_2668_157_ast_node(obj_t, obj_t, obj_t);
static obj_t _box_ref_type_set_2503_209_ast_node(obj_t, obj_t, obj_t);
static obj_t _setq_value_set_2593_255_ast_node(obj_t, obj_t, obj_t);
static obj_t _var_loc2659_203_ast_node(obj_t, obj_t);
static obj_t _make_var2658_215_ast_node(obj_t, obj_t, obj_t, obj_t);
extern obj_t box_ref_key_221_ast_node(box_ref_242_t);
extern node_t jump_ex_it_value_145_ast_node(jump_ex_it_184_t);
extern obj_t funcall_args_151_ast_node(funcall_t);
static obj_t _make_let_fun2545_205_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t set_ex_it_loc_71_ast_node(set_ex_it_116_t);
static obj_t _pragma_args_set_2608_116_ast_node(obj_t, obj_t, obj_t);
obj_t fail_ast_node = BUNSPEC;
extern obj_t make_box_side_effect__set__123_ast_node(make_box_202_t, obj_t);
extern obj_t fail_type_set__42_ast_node(fail_t, type_t);
static obj_t _box_ref_var_set_2507_170_ast_node(obj_t, obj_t, obj_t);
static obj_t _allocate_let_fun_123_ast_node(obj_t);
static obj_t _make_node_effect2670_29_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t);
extern node_t allocate_node_189_ast_node();
static obj_t _box_set__type_set_2495_39_ast_node(obj_t, obj_t, obj_t);
extern node_t make_node_187_ast_node(obj_t, type_t);
static obj_t struct_object__object_select_156_ast_node(obj_t, obj_t, obj_t);
obj_t box_ref_242_ast_node = BUNSPEC;
static obj_t _let_var__141_ast_node(obj_t, obj_t);
extern type_t node_effect_type_0_ast_node(node_effect_213_t);
static obj_t _fail_proc_set_2569_97_ast_node(obj_t, obj_t, obj_t);
static obj_t _atom_loc2665_165_ast_node(obj_t, obj_t);
static obj_t struct_object__object_funcall_136_ast_node(obj_t, obj_t, obj_t);
extern type_t cast_type_139_ast_node(cast_t);
extern set_ex_it_116_t make_set_ex_it_81_ast_node(obj_t, type_t, var_t, node_t);
static obj_t _make_atom2664_96_ast_node(obj_t, obj_t, obj_t, obj_t);
static obj_t _make_box_value2516_193_ast_node(obj_t, obj_t);
extern obj_t node_effect_key_set__83_ast_node(node_effect_213_t, obj_t);
extern obj_t select_side_effect__set__210_ast_node(select_t, obj_t);
obj_t sequence_ast_node = BUNSPEC;
obj_t let_var_6_ast_node = BUNSPEC;
static obj_t _select_type_set_2557_134_ast_node(obj_t, obj_t, obj_t);
static obj_t _app_stack_info2639_72_ast_node(obj_t, obj_t);
static obj_t _fail__57_ast_node(obj_t, obj_t);
obj_t var_ast_node = BUNSPEC;
static obj_t _sequence_nodes2646_170_ast_node(obj_t, obj_t);
static obj_t object__struct_make_box_59_ast_node(obj_t, obj_t);
static obj_t _funcall_args_set_2616_3_ast_node(obj_t, obj_t, obj_t);
extern obj_t let_var_bindings_42_ast_node(let_var_6_t);
extern node_t conditional_test_2_ast_node(conditional_t);
static obj_t _sequence_loc2641_133_ast_node(obj_t, obj_t);
extern obj_t make_box_type_set__149_ast_node(make_box_202_t, type_t);
static obj_t _app_type2631_39_ast_node(obj_t, obj_t);
extern obj_t make_box_side_effect__247_ast_node(make_box_202_t);
static obj_t _allocate_make_box_168_ast_node(obj_t);
static obj_t _allocate_pragma_246_ast_node(obj_t);
extern variable_t closure_variable_234_ast_node(closure_t);
extern obj_t conditional_loc_211_ast_node(conditional_t);
extern bool_t sequence__190_ast_node(obj_t);
static obj_t object__struct_node_0_ast_node(obj_t, obj_t);
static obj_t object__struct_funcall_68_ast_node(obj_t, obj_t);
static obj_t _let_fun_key_set__133_ast_node(obj_t, obj_t, obj_t);
obj_t closure_ast_node = BUNSPEC;
extern obj_t select_key_set__149_ast_node(select_t, obj_t);
static obj_t _make_jump_ex_it2517_208_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t let_var__167_ast_node(obj_t);
static obj_t struct_object__object_box_ref_217_ast_node(obj_t, obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _let_var_type_set_2535_18_ast_node(obj_t, obj_t, obj_t);
extern obj_t pragma_type_set__19_ast_node(pragma_t, type_t);
extern bool_t atom__231_ast_node(obj_t);
extern bool_t make_box__243_ast_node(obj_t);
obj_t pragma_ast_node = BUNSPEC;
extern obj_t conditional_key_55_ast_node(conditional_t);
extern variable_t var_variable_114_ast_node(var_t);
static obj_t _funcall_loc2611_9_ast_node(obj_t, obj_t);
static obj_t _app_ly__224_ast_node(obj_t, obj_t);
static obj_t _var_type2661_41_ast_node(obj_t, obj_t);
static obj_t _make_box_key_set__73_ast_node(obj_t, obj_t, obj_t);
static obj_t _let_var_key_set__226_ast_node(obj_t, obj_t, obj_t);
extern let_fun_218_t allocate_let_fun_35_ast_node();
static obj_t _select_test2562_140_ast_node(obj_t, obj_t);
static obj_t _jump_ex_it_type_set_2519_242_ast_node(obj_t, obj_t, obj_t);
extern make_box_202_t allocate_make_box_201_ast_node();
static obj_t _fail_msg_set_2571_24_ast_node(obj_t, obj_t, obj_t);
static obj_t struct_object__object_let_var_153_ast_node(obj_t, obj_t, obj_t);
extern type_t let_var_type_128_ast_node(let_var_6_t);
obj_t set_ex_it_116_ast_node = BUNSPEC;
extern bool_t var__222_ast_node(obj_t);
static obj_t _make_box_ref2501_60_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _let_var_loc2534_1_ast_node(obj_t, obj_t);
static obj_t _make_make_box2509_255_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _select_clauses2563_85_ast_node(obj_t, obj_t);
extern obj_t funcall_args_set__108_ast_node(funcall_t, obj_t);
extern obj_t cast_type_set__214_ast_node(cast_t, type_t);
extern obj_t jump_ex_it_loc_88_ast_node(jump_ex_it_184_t);
static obj_t object__struct_box_ref_94_ast_node(obj_t, obj_t);
extern obj_t pragma_side_effect__84_ast_node(pragma_t);
static obj_t _set_ex_it__35_ast_node(obj_t, obj_t);
static obj_t _set_ex_it_var_set_2529_51_ast_node(obj_t, obj_t, obj_t);
extern obj_t pragma_args_116_ast_node(pragma_t);
static obj_t _app_ly_fun_set_2624_61_ast_node(obj_t, obj_t, obj_t);
static obj_t _fail_obj2574_73_ast_node(obj_t, obj_t);
extern make_box_202_t make_make_box_156_ast_node(obj_t, type_t, obj_t, obj_t, node_t);
extern app_ly_162_t allocate_app_ly_30_ast_node();
static obj_t _closure_variable_set_2656_122_ast_node(obj_t, obj_t, obj_t);
static obj_t _conditional_loc2576_171_ast_node(obj_t, obj_t);
static obj_t _fail_obj_set_2573_88_ast_node(obj_t, obj_t, obj_t);
extern pragma_t make_pragma_155_ast_node(obj_t, type_t, obj_t, obj_t, obj_t, obj_t);
static obj_t struct_object__object_closure_48_ast_node(obj_t, obj_t, obj_t);
extern obj_t select_test_set__37_ast_node(select_t, node_t);
static obj_t object__struct_sequence_112_ast_node(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t make_box_key_set__183_ast_node(make_box_202_t, obj_t);
static obj_t _funcall__161_ast_node(obj_t, obj_t);
extern obj_t app_type_set__90_ast_node(app_t, type_t);
static obj_t object__struct_let_var_26_ast_node(obj_t, obj_t);
static obj_t _app_key_202_ast_node(obj_t, obj_t);
static obj_t object__struct_set_ex_it_235_ast_node(obj_t, obj_t);
static obj_t _allocate_sequence_156_ast_node(obj_t);
extern obj_t sequence_loc_124_ast_node(sequence_t);
extern type_t select_item_type_206_ast_node(select_t);
static obj_t _cast_arg_set_2599_159_ast_node(obj_t, obj_t, obj_t);
static obj_t struct_object__object_node_196_ast_node(obj_t, obj_t, obj_t);
extern bool_t cast__213_ast_node(obj_t);
static obj_t _fail_loc2566_8_ast_node(obj_t, obj_t);
static obj_t _select_key_153_ast_node(obj_t, obj_t);
extern atom_t allocate_atom_199_ast_node();
static obj_t _box_ref_key_set__224_ast_node(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t let_fun_key_set__227_ast_node(let_fun_218_t, obj_t);
extern atom_t make_atom_145_ast_node(obj_t, type_t, obj_t);
static obj_t _let_var_bindings_set_2539_217_ast_node(obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_exit_set__84_ast_node(jump_ex_it_184_t, node_t);
extern cast_t allocate_cast_68_ast_node();
static obj_t _pragma_key_199_ast_node(obj_t, obj_t);
static obj_t object__struct_closure_29_ast_node(obj_t, obj_t);
extern cast_t make_cast_147_ast_node(obj_t, type_t, node_t);
static obj_t _app_stack_info_set_2638_87_ast_node(obj_t, obj_t, obj_t);
extern type_t app_ly_type_138_ast_node(app_ly_162_t);
static obj_t _let_var_body_set_2541_175_ast_node(obj_t, obj_t, obj_t);
extern obj_t pragma_side_effect__set__174_ast_node(pragma_t, obj_t);
extern obj_t sequence_key_75_ast_node(sequence_t);
extern obj_t app_ly_arg_set__254_ast_node(app_ly_162_t, node_t);
extern type_t atom_type_43_ast_node(atom_t);
static obj_t _struct_object__object2684_232___object(obj_t, obj_t, obj_t);
static obj_t _box_ref_side_effect_2506_100_ast_node(obj_t, obj_t);
extern var_t box_set__var_177_ast_node(box_set__221_t);
static obj_t _let_fun_side_effect_2550_53_ast_node(obj_t, obj_t);
static obj_t _pragma_side_effect_2606_219_ast_node(obj_t, obj_t);
extern obj_t jump_ex_it_value_set__158_ast_node(jump_ex_it_184_t, node_t);
static obj_t _app_fun2635_82_ast_node(obj_t, obj_t);
static obj_t _allocate_fail_214_ast_node(obj_t);
extern type_t make_box_type_89_ast_node(make_box_202_t);
static obj_t _jump_ex_it_exit2522_236_ast_node(obj_t, obj_t);
static obj_t _sequence_side_effect__set_2644_117_ast_node(obj_t, obj_t, obj_t);
extern sequence_t allocate_sequence_235_ast_node();
extern obj_t let_var_key_set__86_ast_node(let_var_6_t, obj_t);
extern bool_t app_ly__191_ast_node(obj_t);
static obj_t _conditional_test2582_188_ast_node(obj_t, obj_t);
static obj_t _kwote_value2651_145_ast_node(obj_t, obj_t);
static obj_t _let_var_bindings2540_152_ast_node(obj_t, obj_t);
extern type_t closure_type_101_ast_node(closure_t);
static obj_t _app_args2637_94_ast_node(obj_t, obj_t);
extern bool_t funcall__35_ast_node(obj_t);
extern var_t allocate_var_186_ast_node();
extern obj_t box_set__var_set__52_ast_node(box_set__221_t, var_t);
extern obj_t closure_variable_set__129_ast_node(closure_t, variable_t);
extern type_t jump_ex_it_type_39_ast_node(jump_ex_it_184_t);
extern obj_t closure_loc_195_ast_node(closure_t);
static obj_t _make_box_loc2510_15_ast_node(obj_t, obj_t);
extern obj_t app_loc_208_ast_node(app_t);
static obj_t _let_fun_type2548_212_ast_node(obj_t, obj_t);
extern sequence_t make_sequence_237_ast_node(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t let_fun_side_effect__189_ast_node(let_fun_218_t);
extern obj_t let_fun_body_set__147_ast_node(let_fun_218_t, node_t);
static obj_t _app_type_set_2630_109_ast_node(obj_t, obj_t, obj_t);
static obj_t _allocate_jump_ex_it_189_ast_node(obj_t);
extern obj_t pragma_format_172_ast_node(pragma_t);
static obj_t object__struct_atom_114_ast_node(obj_t, obj_t);
extern obj_t box_set__value_set__195_ast_node(box_set__221_t, node_t);
static obj_t _cast_loc2596_220_ast_node(obj_t, obj_t);
static obj_t _sequence_type_set_2642_133_ast_node(obj_t, obj_t, obj_t);
static obj_t _setq_type2590_177_ast_node(obj_t, obj_t);
static obj_t _set_ex_it_var2530_147_ast_node(obj_t, obj_t);
extern setq_t allocate_setq_54_ast_node();
static obj_t object__struct_cast_161_ast_node(obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern setq_t make_setq_237_ast_node(obj_t, type_t, var_t, node_t);
static obj_t _funcall_type2613_180_ast_node(obj_t, obj_t);
extern obj_t let_var_side_effect__set__111_ast_node(let_var_6_t, obj_t);
static obj_t _setq__97_ast_node(obj_t, obj_t);
static obj_t _app_ly_fun2625_151_ast_node(obj_t, obj_t);
extern obj_t app_key_150_ast_node(app_t);
static obj_t _select_key_set__222_ast_node(obj_t, obj_t, obj_t);
static obj_t struct_object__object_box_set__45_ast_node(obj_t, obj_t, obj_t);
static obj_t _set_ex_it_type_set_2527_157_ast_node(obj_t, obj_t, obj_t);
static obj_t _let_var_type2536_61_ast_node(obj_t, obj_t);
extern obj_t let_fun_type_set__1_ast_node(let_fun_218_t, type_t);
extern obj_t closure_type_set__162_ast_node(closure_t, type_t);
static obj_t _make_box_type2512_97_ast_node(obj_t, obj_t);
extern obj_t select_type_set__138_ast_node(select_t, type_t);
obj_t node_ast_node = BUNSPEC;
static obj_t struct_object__object_app_63_ast_node(obj_t, obj_t, obj_t);
extern obj_t box_ref_key_set__192_ast_node(box_ref_242_t, obj_t);
extern obj_t box_ref_side_effect__200_ast_node(box_ref_242_t);
static obj_t _setq_var_set_2591_219_ast_node(obj_t, obj_t, obj_t);
extern obj_t sequence_type_set__237_ast_node(sequence_t, type_t);
extern type_t app_type_114_ast_node(app_t);
extern obj_t select_clauses_248_ast_node(select_t);
static obj_t _make_box_side_effect_2514_177_ast_node(obj_t, obj_t);
extern bool_t node_effect__37_ast_node(obj_t);
extern var_t setq_var_152_ast_node(setq_t);
static obj_t _conditional_key_147_ast_node(obj_t, obj_t);
obj_t let_fun_218_ast_node = BUNSPEC;
static obj_t _allocate_set_ex_it_70_ast_node(obj_t);
static obj_t _jump_ex_it__165_ast_node(obj_t, obj_t);
extern node_t fail_proc_182_ast_node(fail_t);
extern obj_t box_ref_var_set__147_ast_node(box_ref_242_t, var_t);
static obj_t _box_set___53_ast_node(obj_t, obj_t);
static obj_t _closure__33_ast_node(obj_t, obj_t);
extern node_t set_ex_it_body_246_ast_node(set_ex_it_116_t);
extern obj_t box_ref_type_set__106_ast_node(box_ref_242_t, type_t);
extern type_t let_fun_type_250_ast_node(let_fun_218_t);
static obj_t struct_object__object_pragma_2_ast_node(obj_t, obj_t, obj_t);
static obj_t _funcall_fun_set_2614_75_ast_node(obj_t, obj_t, obj_t);
extern obj_t box_ref_side_effect__set__120_ast_node(box_ref_242_t, obj_t);
static obj_t imported_modules_init_94_ast_node();
static obj_t _select_item_type2564_114_ast_node(obj_t, obj_t);
static obj_t object__struct_setq_205_ast_node(obj_t, obj_t);
extern node_t fail_obj_122_ast_node(fail_t);
static obj_t object__struct_select_180_ast_node(obj_t, obj_t);
extern node_t fail_msg_210_ast_node(fail_t);
extern var_t app_fun_173_ast_node(app_t);
static obj_t _allocate_app_ly_138_ast_node(obj_t);
static obj_t _box_set__type2496_192_ast_node(obj_t, obj_t);
static obj_t _var_variable2663_13_ast_node(obj_t, obj_t);
static obj_t _fail_msg2572_162_ast_node(obj_t, obj_t);
static obj_t _kwote_loc2648_52_ast_node(obj_t, obj_t);
static obj_t struct_object__object_atom_177_ast_node(obj_t, obj_t, obj_t);
static obj_t _fail_type_set_2567_138_ast_node(obj_t, obj_t, obj_t);
extern obj_t kwote_loc_85_ast_node(kwote_t);
static obj_t _box_ref_type2504_178_ast_node(obj_t, obj_t);
static obj_t struct_object__object_cast_16_ast_node(obj_t, obj_t, obj_t);
extern obj_t fail_loc_117_ast_node(fail_t);
extern obj_t box_set__loc_237_ast_node(box_set__221_t);
extern obj_t pragma_key_set__102_ast_node(pragma_t, obj_t);
obj_t app_ly_162_ast_node = BUNSPEC;
static obj_t struct_object__object_let_fun_200_ast_node(obj_t, obj_t, obj_t);
static obj_t _make_closure2652_85_ast_node(obj_t, obj_t, obj_t, obj_t);
extern bool_t closure__53_ast_node(obj_t);
extern bool_t jump_ex_it__122_ast_node(obj_t);
static obj_t _app__141_ast_node(obj_t, obj_t);
extern bool_t node__79_ast_node(obj_t);
extern obj_t kwote_value_104_ast_node(kwote_t);
extern type_t kwote_type_217_ast_node(kwote_t);
static obj_t _box_set__value_set_2499_21_ast_node(obj_t, obj_t, obj_t);
static obj_t _app_ly_arg_set_2626_69_ast_node(obj_t, obj_t, obj_t);
extern obj_t fail_proc_set__82_ast_node(fail_t, node_t);
static obj_t _var_variable_set_2662_236_ast_node(obj_t, obj_t, obj_t);
static obj_t _set_ex_it_body_set_2531_199_ast_node(obj_t, obj_t, obj_t);
static obj_t _app_fun_set_2634_22_ast_node(obj_t, obj_t, obj_t);
static obj_t _let_fun_locals2552_73_ast_node(obj_t, obj_t);
static obj_t _conditional_key_set__89_ast_node(obj_t, obj_t, obj_t);
extern type_t setq_type_225_ast_node(setq_t);
static obj_t _jump_ex_it_loc2518_20_ast_node(obj_t, obj_t);
extern funcall_t make_funcall_190_ast_node(obj_t, type_t, node_t, obj_t, obj_t);
static obj_t _conditional_false_set_2585_128_ast_node(obj_t, obj_t, obj_t);
extern obj_t let_fun_side_effect__set__106_ast_node(let_fun_218_t, obj_t);
extern obj_t let_var_bindings_set__143_ast_node(let_var_6_t, obj_t);
obj_t app_ast_node = BUNSPEC;
static obj_t _pragma_side_effect__set_2605_45_ast_node(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_ast_node();
static obj_t _let_var_removable__set_2543_208_ast_node(obj_t, obj_t, obj_t);
static obj_t _sequence__76_ast_node(obj_t, obj_t);
static obj_t object__struct_let_fun_125_ast_node(obj_t, obj_t);
static obj_t struct_object__object_kwote_75_ast_node(obj_t, obj_t, obj_t);
static obj_t _funcall_args2617_165_ast_node(obj_t, obj_t);
extern app_ly_162_t make_app_ly_64_ast_node(obj_t, type_t, node_t, node_t);
extern type_t node_type_175_ast_node(node_t);
extern bool_t kwote__251_ast_node(obj_t);
extern type_t funcall_type_93_ast_node(funcall_t);
extern obj_t funcall_fun_set__22_ast_node(funcall_t, node_t);
static obj_t struct_object__object_setq_124_ast_node(obj_t, obj_t, obj_t);
static obj_t _jump_ex_it_value_set_2523_69_ast_node(obj_t, obj_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern type_t fail_type_93_ast_node(fail_t);
static obj_t _select_type2558_223_ast_node(obj_t, obj_t);
static obj_t _make_box__204_ast_node(obj_t, obj_t);
static obj_t _app_side_effect__set_2632_76_ast_node(obj_t, obj_t, obj_t);
static obj_t _node_effect_side_effect_2675_102_ast_node(obj_t, obj_t);
extern node_t conditional_false_181_ast_node(conditional_t);
static obj_t _funcall_fun2615_153_ast_node(obj_t, obj_t);
static obj_t _node_effect_side_effect__set_2674_173_ast_node(obj_t, obj_t, obj_t);
static obj_t _box_set__loc2494_37_ast_node(obj_t, obj_t);
extern obj_t app_ly_fun_set__208_ast_node(app_ly_162_t, node_t);
static obj_t _let_fun__236_ast_node(obj_t, obj_t);
static obj_t _box_ref_loc2502_223_ast_node(obj_t, obj_t);
extern box_ref_242_t make_box_ref_158_ast_node(obj_t, type_t, obj_t, obj_t, var_t);
static obj_t _sequence_side_effect_2645_115_ast_node(obj_t, obj_t);
static obj_t _app_ly_arg2627_163_ast_node(obj_t, obj_t);
static obj_t object__struct_kwote_66_ast_node(obj_t, obj_t);
extern type_t select_type_6_ast_node(select_t);
static obj_t _closure_loc2653_80_ast_node(obj_t, obj_t);
extern bool_t conditional__146_ast_node(obj_t);
extern obj_t setq_loc_177_ast_node(setq_t);
static obj_t _let_fun_type_set_2547_72_ast_node(obj_t, obj_t, obj_t);
obj_t atom_ast_node = BUNSPEC;
extern obj_t node_loc_29_ast_node(node_t);
extern obj_t funcall_loc_117_ast_node(funcall_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t struct_object__object_set_ex_it_208_ast_node(obj_t, obj_t, obj_t);
extern obj_t app_stack_info_87_ast_node(app_t);
static obj_t _var_type_set_2660_138_ast_node(obj_t, obj_t, obj_t);
static obj_t _sequence_key_229_ast_node(obj_t, obj_t);
static obj_t _node_type2679_26_ast_node(obj_t, obj_t);
obj_t cast_ast_node = BUNSPEC;
extern obj_t make_box_value_set__112_ast_node(make_box_202_t, node_t);
static obj_t toplevel_init_63_ast_node();
static obj_t _pragma_loc2602_15_ast_node(obj_t, obj_t);
extern obj_t var_variable_set__90_ast_node(var_t, variable_t);
static obj_t _node_effect_loc2671_156_ast_node(obj_t, obj_t);
static obj_t _allocate_conditional_184_ast_node(obj_t);
extern obj_t conditional_test_set__179_ast_node(conditional_t, node_t);
extern let_var_6_t make_let_var_217_ast_node(obj_t, type_t, obj_t, obj_t, obj_t, node_t, bool_t);
extern jump_ex_it_184_t allocate_jump_ex_it_22_ast_node();
extern type_t box_ref_type_189_ast_node(box_ref_242_t);
extern node_t setq_value_119_ast_node(setq_t);
extern obj_t node_effect_side_effect__249_ast_node(node_effect_213_t);
static obj_t _pragma__23_ast_node(obj_t, obj_t);
static obj_t _pragma_type_set_2603_242_ast_node(obj_t, obj_t, obj_t);
static obj_t _allocate_var_93_ast_node(obj_t);
static obj_t _closure_variable2657_254_ast_node(obj_t, obj_t);
obj_t jump_ex_it_184_ast_node = BUNSPEC;
extern obj_t open_input_string(obj_t);
static obj_t _set_ex_it_type2528_118_ast_node(obj_t, obj_t);
obj_t kwote_ast_node = BUNSPEC;
extern conditional_t make_conditional_43_ast_node(obj_t, type_t, obj_t, obj_t, node_t, node_t, node_t);
static obj_t _make_box_value_set_2515_68_ast_node(obj_t, obj_t, obj_t);
extern select_t allocate_select_194_ast_node();
static obj_t _make_conditional2575_101_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _allocate_node_227_ast_node(obj_t);
static obj_t _let_fun_side_effect__set_2549_170_ast_node(obj_t, obj_t, obj_t);
static obj_t _select_side_effect_2560_103_ast_node(obj_t, obj_t);
static obj_t _kwote__112_ast_node(obj_t, obj_t);
extern obj_t let_var_side_effect__154_ast_node(let_var_6_t);
extern bool_t let_fun__0_ast_node(obj_t);
extern closure_t make_closure_70_ast_node(obj_t, type_t, variable_t);
extern node_t let_var_body_232_ast_node(let_var_6_t);
static obj_t _atom__186_ast_node(obj_t, obj_t);
extern obj_t node_effect_loc_61_ast_node(node_effect_213_t);
extern obj_t cast_loc_174_ast_node(cast_t);
extern type_t box_set__type_38_ast_node(box_set__221_t);
static obj_t _setq_loc2588_95_ast_node(obj_t, obj_t);
extern obj_t conditional_false_set__184_ast_node(conditional_t, node_t);
static obj_t _node_loc2677_157_ast_node(obj_t, obj_t);
extern bool_t app__230_ast_node(obj_t);
obj_t setq_ast_node = BUNSPEC;
extern var_t make_var_69_ast_node(obj_t, type_t, variable_t);
static obj_t _box_set__value2500_46_ast_node(obj_t, obj_t);
extern obj_t app_ly_loc_83_ast_node(app_ly_162_t);
extern obj_t make_box_loc_202_ast_node(make_box_202_t);
static obj_t _fail_proc2570_42_ast_node(obj_t, obj_t);
extern obj_t setq_var_set__217_ast_node(setq_t, var_t);
static obj_t object__struct_var_159_ast_node(obj_t, obj_t);
extern obj_t sequence_side_effect__144_ast_node(sequence_t);
static obj_t _let_fun_body2554_75_ast_node(obj_t, obj_t);
static obj_t _select_side_effect__set_2559_195_ast_node(obj_t, obj_t, obj_t);
static obj_t _conditional_type2578_94_ast_node(obj_t, obj_t);
static obj_t _make_app_ly2620_72_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _select__4_ast_node(obj_t, obj_t);
static obj_t _let_var_removable_2544_155_ast_node(obj_t, obj_t);
static obj_t object__struct_conditional_60_ast_node(obj_t, obj_t);
obj_t box_set__221_ast_node = BUNSPEC;
static obj_t _funcall_type_set_2612_24_ast_node(obj_t, obj_t, obj_t);
static obj_t _atom_type2667_50_ast_node(obj_t, obj_t);
static obj_t _conditional_test_set_2581_5_ast_node(obj_t, obj_t, obj_t);
extern obj_t node_effect_key_249_ast_node(node_effect_213_t);
extern bool_t fail__35_ast_node(obj_t);
extern node_t funcall_fun_37_ast_node(funcall_t);
extern obj_t funcall_strength_set__57_ast_node(funcall_t, obj_t);
extern obj_t box_set__type_set__0_ast_node(box_set__221_t, type_t);
static obj_t _node_effect__62_ast_node(obj_t, obj_t);
static obj_t _conditional_side_effect_2580_200_ast_node(obj_t, obj_t);
static obj_t _allocate_node_effect_20_ast_node(obj_t);
static obj_t _pragma_key_set__110_ast_node(obj_t, obj_t, obj_t);
extern obj_t kwote_type_set__119_ast_node(kwote_t, type_t);
extern obj_t object___object;
extern type_t pragma_type_32_ast_node(pragma_t);
static obj_t _let_fun_body_set_2553_147_ast_node(obj_t, obj_t, obj_t);
extern obj_t funcall_strength_157_ast_node(funcall_t);
extern obj_t funcall_type_set__42_ast_node(funcall_t, type_t);
extern obj_t let_var_body_set__15_ast_node(let_var_6_t, node_t);
extern obj_t make_box_key_223_ast_node(make_box_202_t);
static obj_t _make_app2628_2_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern type_t var_type_150_ast_node(var_t);
extern obj_t pragma_args_set__199_ast_node(pragma_t, obj_t);
extern obj_t var_loc_140_ast_node(var_t);
extern app_t allocate_app_15_ast_node();
extern node_effect_213_t make_node_effect_87_ast_node(obj_t, type_t, obj_t, obj_t);
static obj_t _let_var_body2542_190_ast_node(obj_t, obj_t);
extern obj_t app_key_set__45_ast_node(app_t, obj_t);
static obj_t struct_object__object_app_ly_165_ast_node(obj_t, obj_t, obj_t);
static obj_t _app_ly_type2623_46_ast_node(obj_t, obj_t);
extern type_t sequence_type_18_ast_node(sequence_t);
static obj_t _kwote_type2650_225_ast_node(obj_t, obj_t);
static obj_t _allocate_funcall_93_ast_node(obj_t);
static obj_t _allocate_kwote_245_ast_node(obj_t);
static obj_t _cast__220_ast_node(obj_t, obj_t);
extern bool_t pragma__55_ast_node(obj_t);
extern obj_t select_side_effect__205_ast_node(select_t);
extern obj_t conditional_side_effect__145_ast_node(conditional_t);
extern obj_t app_side_effect__179_ast_node(app_t);
static obj_t struct_object__object_make_box_39_ast_node(obj_t, obj_t, obj_t);
static obj_t _let_var_side_effect__set_2537_236_ast_node(obj_t, obj_t, obj_t);
extern obj_t let_var_type_set__107_ast_node(let_var_6_t, type_t);
static obj_t struct_object__object_conditional_24_ast_node(obj_t, obj_t, obj_t);
static obj_t _cast_type2598_33_ast_node(obj_t, obj_t);
static obj_t _make_funcall2610_87_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t conditional_type_set__131_ast_node(conditional_t, type_t);
static obj_t _make_box_side_effect__set_2513_73_ast_node(obj_t, obj_t, obj_t);
extern obj_t var_type_set__45_ast_node(var_t, type_t);
extern obj_t atom_type_set__253_ast_node(atom_t, type_t);
static obj_t _box_set__var_set_2497_175_ast_node(obj_t, obj_t, obj_t);
extern obj_t setq_type_set__224_ast_node(setq_t, type_t);
extern type_t conditional_type_236_ast_node(conditional_t);
extern obj_t let_var_removable__set__39_ast_node(let_var_6_t, bool_t);
static obj_t object__struct_pragma_207_ast_node(obj_t, obj_t);
static obj_t object__struct_node_effect_233_ast_node(obj_t, obj_t);
static obj_t _closure_type2655_215_ast_node(obj_t, obj_t);
extern obj_t conditional_key_set__247_ast_node(conditional_t, obj_t);
extern node_t app_ly_fun_107_ast_node(app_ly_162_t);
static obj_t _make_box_type_set_2511_87_ast_node(obj_t, obj_t, obj_t);
extern obj_t atom_loc_1_ast_node(atom_t);
extern fail_t allocate_fail_46_ast_node();
extern obj_t app_args_set__223_ast_node(app_t, obj_t);
static obj_t _make_kwote2647_26_ast_node(obj_t, obj_t, obj_t, obj_t);
static obj_t _allocate_box_ref_230_ast_node(obj_t);
extern fail_t make_fail_231_ast_node(obj_t, type_t, node_t, node_t, node_t);
static obj_t _sequence_key_set__223_ast_node(obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_type_set__142_ast_node(jump_ex_it_184_t, type_t);
extern bool_t select__208_ast_node(obj_t);
static obj_t object__struct_box_set__198_ast_node(obj_t, obj_t);
static obj_t _atom_type_set_2666_88_ast_node(obj_t, obj_t, obj_t);
static obj_t _make_sequence2640_62_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t conditional_side_effect__set__158_ast_node(conditional_t, obj_t);
extern jump_ex_it_184_t make_jump_ex_it_21_ast_node(obj_t, type_t, node_t, node_t);
static obj_t object_init_111_ast_node();
static obj_t _box_ref__132_ast_node(obj_t, obj_t);
static obj_t _allocate_box_set__43_ast_node(obj_t);
static obj_t _node_effect_type_set_2672_137_ast_node(obj_t, obj_t, obj_t);
extern obj_t sequence_side_effect__set__38_ast_node(sequence_t, obj_t);
static obj_t _conditional_true2584_27_ast_node(obj_t, obj_t);
static obj_t _allocate_atom_130_ast_node(obj_t);
static obj_t _app_args_set_2636_222_ast_node(obj_t, obj_t, obj_t);
static obj_t _allocate_let_var_179_ast_node(obj_t);
extern obj_t atom_value_177_ast_node(atom_t);
static obj_t _allocate_cast_146_ast_node(obj_t);
static obj_t struct_object__object_node_effect_227_ast_node(obj_t, obj_t, obj_t);
static obj_t _allocate_select_101_ast_node(obj_t);
static obj_t _let_var_key_202_ast_node(obj_t, obj_t);
extern obj_t node_effect_side_effect__set__83_ast_node(node_effect_213_t, obj_t);
extern funcall_t allocate_funcall_80_ast_node();
extern obj_t sequence_key_set__139_ast_node(sequence_t, obj_t);
static obj_t _make_fail2565_1_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t struct_object__object_sequence_200_ast_node(obj_t, obj_t, obj_t);
extern obj_t let_fun_locals_116_ast_node(let_fun_218_t);
extern node_t let_fun_body_141_ast_node(let_fun_218_t);
static obj_t _allocate_closure_68_ast_node(obj_t);
static obj_t object__struct_fail_140_ast_node(obj_t, obj_t);
static obj_t _let_var_side_effect_2538_65_ast_node(obj_t, obj_t);
static obj_t _node_type_set_2678_183_ast_node(obj_t, obj_t, obj_t);
static obj_t _pragma_format2607_223_ast_node(obj_t, obj_t);
extern node_t cast_arg_174_ast_node(cast_t);
static obj_t _conditional__140_ast_node(obj_t, obj_t);
static obj_t _conditional_true_set_2583_74_ast_node(obj_t, obj_t, obj_t);
static obj_t _let_fun_key_252_ast_node(obj_t, obj_t);
extern obj_t fail_msg_set__47_ast_node(fail_t, node_t);
static obj_t _pragma_type2604_183_ast_node(obj_t, obj_t);
extern box_set__221_t allocate_box_set__237_ast_node();
extern var_t box_ref_var_141_ast_node(box_ref_242_t);
static obj_t _node_effect_key_set__9_ast_node(obj_t, obj_t, obj_t);
extern conditional_t allocate_conditional_174_ast_node();
extern obj_t fail_obj_set__117_ast_node(fail_t, node_t);
obj_t select_ast_node = BUNSPEC;
static obj_t _conditional_false2586_217_ast_node(obj_t, obj_t);
extern obj_t app_stack_info_set__168_ast_node(app_t, obj_t);
extern node_t app_ly_arg_131_ast_node(app_ly_162_t);
extern let_fun_218_t make_let_fun_154_ast_node(obj_t, type_t, obj_t, obj_t, obj_t, node_t);
extern bool_t box_ref__165_ast_node(obj_t);
extern obj_t let_var_loc_249_ast_node(let_var_6_t);
static obj_t _funcall_strength_set_2618_194_ast_node(obj_t, obj_t, obj_t);
extern set_ex_it_116_t allocate_set_ex_it_57_ast_node();
static obj_t _select_test_set_2561_102_ast_node(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _cast_type_set_2597_150_ast_node(obj_t, obj_t, obj_t);
extern box_set__221_t make_box_set__226_ast_node(obj_t, type_t, var_t, node_t);
extern node_t conditional_true_226_ast_node(conditional_t);
static obj_t _node_effect_key_98_ast_node(obj_t, obj_t);
static obj_t _jump_ex_it_exit_set_2521_158_ast_node(obj_t, obj_t, obj_t);
extern node_t box_set__value_123_ast_node(box_set__221_t);
static obj_t _allocate_setq_253_ast_node(obj_t);
extern box_ref_242_t allocate_box_ref_100_ast_node();
extern bool_t let_var_removable__69_ast_node(let_var_6_t);
static obj_t _select_loc2556_23_ast_node(obj_t, obj_t);
static obj_t _box_set__var2498_218_ast_node(obj_t, obj_t);
extern obj_t let_fun_loc_207_ast_node(let_fun_218_t);
extern bool_t set_ex_it__46_ast_node(obj_t);
static obj_t _box_ref_var2508_88_ast_node(obj_t, obj_t);
extern node_t make_box_value_197_ast_node(make_box_202_t);
static obj_t _conditional_side_effect__set_2579_13_ast_node(obj_t, obj_t, obj_t);
extern var_t set_ex_it_var_31_ast_node(set_ex_it_116_t);
static obj_t _cast_arg2600_154_ast_node(obj_t, obj_t);
extern obj_t let_var_key_52_ast_node(let_var_6_t);
extern bool_t setq__41_ast_node(obj_t);
extern obj_t select_loc_168_ast_node(select_t);
extern obj_t set_ex_it_var_set__67_ast_node(set_ex_it_116_t, var_t);
static obj_t _app_ly_type_set_2622_144_ast_node(obj_t, obj_t, obj_t);
extern select_t make_select_245_ast_node(obj_t, type_t, obj_t, obj_t, node_t, obj_t, type_t);
static obj_t struct_object__object_jump_ex_it_246_ast_node(obj_t, obj_t, obj_t);
extern kwote_t allocate_kwote_110_ast_node();
static obj_t _jump_ex_it_type2520_122_ast_node(obj_t, obj_t);
static obj_t _make_node2676_204_ast_node(obj_t, obj_t, obj_t);
static obj_t _conditional_type_set_2577_38_ast_node(obj_t, obj_t, obj_t);
extern obj_t app_ly_type_set__172_ast_node(app_ly_162_t, type_t);
extern obj_t pragma_loc_254_ast_node(pragma_t);
extern let_var_6_t allocate_let_var_32_ast_node();
extern obj_t app_fun_set__26_ast_node(app_t, var_t);
static obj_t _make_select2555_239_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t let_fun_key_253_ast_node(let_fun_218_t);
extern obj_t app_args_229_ast_node(app_t);
static obj_t _make_setq2587_87_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_pragma2601_250_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _node__81_ast_node(obj_t, obj_t);
static obj_t _set_ex_it_body2532_170_ast_node(obj_t, obj_t);
static obj_t _sequence_type2643_232_ast_node(obj_t, obj_t);
extern pragma_t allocate_pragma_110_ast_node();
extern obj_t node_type_set__235_ast_node(node_t, type_t);
static obj_t require_initialization_114_ast_node = BUNSPEC;
extern obj_t select_key_89_ast_node(select_t);
static obj_t _app_loc2629_107_ast_node(obj_t, obj_t);
static obj_t _fail_type2568_237_ast_node(obj_t, obj_t);
obj_t conditional_ast_node = BUNSPEC;
extern node_effect_213_t allocate_node_effect_98_ast_node();
extern kwote_t make_kwote_191_ast_node(obj_t, type_t, obj_t);
extern node_t select_test_184_ast_node(select_t);
static obj_t struct_object__object_fail_96_ast_node(obj_t, obj_t, obj_t);
static obj_t _make_set_ex_it2525_29_ast_node(obj_t, obj_t, obj_t, obj_t, obj_t);
extern closure_t allocate_closure_237_ast_node();
static obj_t _object__struct2681_6___object(obj_t, obj_t);
extern obj_t pragma_key_211_ast_node(pragma_t);
static obj_t _atom_value2669_108_ast_node(obj_t, obj_t);
static obj_t _jump_ex_it_value2524_58_ast_node(obj_t, obj_t);
extern obj_t atom_value_set__52_ast_node(atom_t, obj_t);
extern obj_t set_ex_it_body_set__234_ast_node(set_ex_it_116_t, node_t);
static obj_t _let_fun_locals_set_2551_38_ast_node(obj_t, obj_t, obj_t);
static obj_t _kwote_type_set_2649_70_ast_node(obj_t, obj_t, obj_t);
static obj_t _closure_type_set_2654_234_ast_node(obj_t, obj_t, obj_t);
static obj_t _make_box_key_238_ast_node(obj_t, obj_t);
static obj_t _setq_var2592_194_ast_node(obj_t, obj_t);
static obj_t _setq_value2594_157_ast_node(obj_t, obj_t);
static obj_t cnst_init_137_ast_node();
static obj_t _box_ref_key_225_ast_node(obj_t, obj_t);
static obj_t _let_fun_loc2546_121_ast_node(obj_t, obj_t);
static obj_t _box_ref_side_effect__set_2505_194_ast_node(obj_t, obj_t, obj_t);
static obj_t _allocate_app_162_ast_node(obj_t);
static obj_t _funcall_strength2619_138_ast_node(obj_t, obj_t);
static obj_t _app_key_set__226_ast_node(obj_t, obj_t, obj_t);
extern type_t set_ex_it_type_46_ast_node(set_ex_it_116_t);
extern obj_t node_effect_type_set__91_ast_node(node_effect_213_t, type_t);
extern obj_t setq_value_set__233_ast_node(setq_t, node_t);
static obj_t __cnst[23];

DEFINE_EXPORT_PROCEDURE(funcall_type_env_209_ast_node, _funcall_type2613_180_ast_node2737, _funcall_type2613_180_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(setq__env_66_ast_node, _setq__97_ast_node2738, _setq__97_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_ly_fun_set__env_54_ast_node, _app_ly_fun_set_2624_61_ast_node2739, _app_ly_fun_set_2624_61_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_var_type_env_80_ast_node, _let_var_type2536_61_ast_node2740, _let_var_type2536_61_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_loc_env_219_ast_node, _conditional_loc2576_171_ast_node2741, _conditional_loc2576_171_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_side_effect__env_1_ast_node, _conditional_side_effect_2580_200_ast_node2742, _conditional_side_effect_2580_200_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(setq_type_set__env_33_ast_node, _setq_type_set_2589_129_ast_node2743, _setq_type_set_2589_129_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_ly_type_env_67_ast_node, _app_ly_type2623_46_ast_node2744, _app_ly_type2623_46_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node__env_141_ast_node, _node__81_ast_node2745, _node__81_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_box_side_effect__set__env_229_ast_node, _make_box_side_effect__set_2513_73_ast_node2746, _make_box_side_effect__set_2513_73_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(funcall__env_44_ast_node, _funcall__161_ast_node2747, _funcall__161_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_select_env_246_ast_node, _allocate_select_101_ast_node2748, _allocate_select_101_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(node_effect_key_env_215_ast_node, _node_effect_key_98_ast_node2749, _node_effect_key_98_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(funcall_args_set__env_26_ast_node, _funcall_args_set_2616_3_ast_node2750, _funcall_args_set_2616_3_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_pragma_env_128_ast_node, _allocate_pragma_246_ast_node2751, _allocate_pragma_246_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(fail__env_44_ast_node, _fail__57_ast_node2752, _fail__57_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_exit_env_107_ast_node, _jump_ex_it_exit2522_236_ast_node2753, _jump_ex_it_exit2522_236_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_box_ref_env_189_ast_node, _allocate_box_ref_230_ast_node2754, _allocate_box_ref_230_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(select__env_54_ast_node, _select__4_ast_node2755, _select__4_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_type_set__env_23_ast_node, _let_var_type_set_2535_18_ast_node2756, _let_var_type_set_2535_18_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_jump_ex_it_env_98_ast_node, _allocate_jump_ex_it_189_ast_node2757, _allocate_jump_ex_it_189_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(box_ref_type_env_214_ast_node, _box_ref_type2504_178_ast_node2758, _box_ref_type2504_178_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_set__type_set__env_93_ast_node, _box_set__type_set_2495_39_ast_node2759, _box_set__type_set_2495_39_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fail_proc_set__env_106_ast_node, _fail_proc_set_2569_97_ast_node2760, _fail_proc_set_2569_97_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_var_bindings_env_73_ast_node, _let_var_bindings2540_152_ast_node2761, _let_var_bindings2540_152_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_atom_env_206_ast_node, _allocate_atom_130_ast_node2762, _allocate_atom_130_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(app_ly_fun_env_23_ast_node, _app_ly_fun2625_151_ast_node2763, _app_ly_fun2625_151_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_box_value_env_244_ast_node, _make_box_value2516_193_ast_node2764, _make_box_value2516_193_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(var_variable_env_16_ast_node, _var_variable2663_13_ast_node2765, _var_variable2663_13_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_test_env_146_ast_node, _conditional_test2582_188_ast_node2766, _conditional_test2582_188_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_ref__env_35_ast_node, _box_ref__132_ast_node2767, _box_ref__132_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2729_ast_node, object__struct_node_0_ast_node2768, object__struct_node_0_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2730_ast_node, struct_object__object_node_196_ast_node2769, struct_object__object_node_196_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2728_ast_node, struct_object__object_node_effect_227_ast_node2770, struct_object__object_node_effect_227_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2727_ast_node, object__struct_node_effect_233_ast_node2771, object__struct_node_effect_233_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2726_ast_node, struct_object__object_atom_177_ast_node2772, struct_object__object_atom_177_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2725_ast_node, object__struct_atom_114_ast_node2773, object__struct_atom_114_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2724_ast_node, struct_object__object_var_138_ast_node2774, struct_object__object_var_138_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_atom_env_1_ast_node, _make_atom2664_96_ast_node2775, _make_atom2664_96_ast_node, 0L, 3);
DEFINE_STATIC_PROCEDURE(proc2723_ast_node, object__struct_var_159_ast_node2776, object__struct_var_159_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2722_ast_node, struct_object__object_closure_48_ast_node2777, struct_object__object_closure_48_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2721_ast_node, object__struct_closure_29_ast_node2778, object__struct_closure_29_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2719_ast_node, object__struct_kwote_66_ast_node2779, object__struct_kwote_66_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2720_ast_node, struct_object__object_kwote_75_ast_node2780, struct_object__object_kwote_75_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2718_ast_node, struct_object__object_sequence_200_ast_node2781, struct_object__object_sequence_200_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2717_ast_node, object__struct_sequence_112_ast_node2782, object__struct_sequence_112_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2716_ast_node, struct_object__object_app_63_ast_node2783, struct_object__object_app_63_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2715_ast_node, object__struct_app_142_ast_node2784, object__struct_app_142_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2714_ast_node, struct_object__object_app_ly_165_ast_node2785, struct_object__object_app_ly_165_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2713_ast_node, object__struct_app_ly_240_ast_node2786, object__struct_app_ly_240_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2712_ast_node, struct_object__object_funcall_136_ast_node2787, struct_object__object_funcall_136_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2711_ast_node, object__struct_funcall_68_ast_node2788, object__struct_funcall_68_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2699_ast_node, object__struct_select_180_ast_node2789, object__struct_select_180_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2709_ast_node, object__struct_pragma_207_ast_node2790, object__struct_pragma_207_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2710_ast_node, struct_object__object_pragma_2_ast_node2791, struct_object__object_pragma_2_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2698_ast_node, struct_object__object_let_fun_200_ast_node2792, struct_object__object_let_fun_200_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2708_ast_node, struct_object__object_cast_16_ast_node2793, struct_object__object_cast_16_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2697_ast_node, object__struct_let_fun_125_ast_node2794, object__struct_let_fun_125_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2707_ast_node, object__struct_cast_161_ast_node2795, object__struct_cast_161_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2696_ast_node, struct_object__object_let_var_153_ast_node2796, struct_object__object_let_var_153_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2706_ast_node, struct_object__object_setq_124_ast_node2797, struct_object__object_setq_124_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2695_ast_node, object__struct_let_var_26_ast_node2798, object__struct_let_var_26_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2705_ast_node, object__struct_setq_205_ast_node2799, object__struct_setq_205_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2694_ast_node, struct_object__object_set_ex_it_208_ast_node2800, struct_object__object_set_ex_it_208_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2704_ast_node, struct_object__object_conditional_24_ast_node2801, struct_object__object_conditional_24_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2693_ast_node, object__struct_set_ex_it_235_ast_node2802, object__struct_set_ex_it_235_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2703_ast_node, object__struct_conditional_60_ast_node2803, object__struct_conditional_60_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2692_ast_node, struct_object__object_jump_ex_it_246_ast_node2804, struct_object__object_jump_ex_it_246_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2702_ast_node, struct_object__object_fail_96_ast_node2805, struct_object__object_fail_96_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2691_ast_node, object__struct_jump_ex_it_205_ast_node2806, object__struct_jump_ex_it_205_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2701_ast_node, object__struct_fail_140_ast_node2807, object__struct_fail_140_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2689_ast_node, object__struct_make_box_59_ast_node2808, object__struct_make_box_59_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2690_ast_node, struct_object__object_make_box_39_ast_node2809, struct_object__object_make_box_39_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2700_ast_node, struct_object__object_select_156_ast_node2810, struct_object__object_select_156_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2688_ast_node, struct_object__object_box_ref_217_ast_node2811, struct_object__object_box_ref_217_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2687_ast_node, object__struct_box_ref_94_ast_node2812, object__struct_box_ref_94_ast_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2686_ast_node, struct_object__object_box_set__45_ast_node2813, struct_object__object_box_set__45_ast_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2685_ast_node, object__struct_box_set__198_ast_node2814, object__struct_box_set__198_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_closure_env_79_ast_node, _make_closure2652_85_ast_node2815, _make_closure2652_85_ast_node, 0L, 3);
DEFINE_EXPORT_PROCEDURE(app_stack_info_env_234_ast_node, _app_stack_info2639_72_ast_node2816, _app_stack_info2639_72_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sequence_nodes_env_20_ast_node, _sequence_nodes2646_170_ast_node2817, _sequence_nodes2646_170_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_fun_set__env_252_ast_node, _app_fun_set_2634_22_ast_node2818, _app_fun_set_2634_22_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cast_arg_env_156_ast_node, _cast_arg2600_154_ast_node2819, _cast_arg2600_154_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_set___env_99_ast_node, _box_set___53_ast_node2820, _box_set___53_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(var_type_set__env_125_ast_node, _var_type_set_2660_138_ast_node2821, _var_type_set_2660_138_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(pragma_type_env_250_ast_node, _pragma_type2604_183_ast_node2822, _pragma_type2604_183_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_effect_key_set__env_245_ast_node, _node_effect_key_set__9_ast_node2823, _node_effect_key_set__9_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(funcall_args_env_101_ast_node, _funcall_args2617_165_ast_node2824, _funcall_args2617_165_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_set__loc_env_30_ast_node, _box_set__loc2494_37_ast_node2825, _box_set__loc2494_37_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_key_env_59_ast_node, _let_var_key_202_ast_node2826, _let_var_key_202_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_ref_var_env_232_ast_node, _box_ref_var2508_88_ast_node2827, _box_ref_var2508_88_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_body_set__env_27_ast_node, _let_var_body_set_2541_175_ast_node2828, _let_var_body_set_2541_175_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(pragma__env_231_ast_node, _pragma__23_ast_node2829, _pragma__23_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_key_set__env_138_ast_node, _let_var_key_set__226_ast_node2830, _let_var_key_set__226_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(select_clauses_env_124_ast_node, _select_clauses2563_85_ast_node2831, _select_clauses2563_85_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_item_type_env_227_ast_node, _select_item_type2564_114_ast_node2832, _select_item_type2564_114_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(var__env_97_ast_node, _var__148_ast_node2833, _var__148_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(funcall_fun_set__env_98_ast_node, _funcall_fun_set_2614_75_ast_node2834, _funcall_fun_set_2614_75_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sequence__env_188_ast_node, _sequence__76_ast_node2835, _sequence__76_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(setq_var_env_114_ast_node, _setq_var2592_194_ast_node2836, _setq_var2592_194_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_key_env_9_ast_node, _app_key_202_ast_node2837, _app_key_202_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_ex_it_var_set__env_109_ast_node, _set_ex_it_var_set_2529_51_ast_node2838, _set_ex_it_var_set_2529_51_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sequence_key_set__env_116_ast_node, _sequence_key_set__223_ast_node2839, _sequence_key_set__223_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_select_env_113_ast_node, _make_select2555_239_ast_node2840, _make_select2555_239_ast_node, 0L, 7);
DEFINE_EXPORT_PROCEDURE(closure_variable_set__env_10_ast_node, _closure_variable_set_2656_122_ast_node2841, _closure_variable_set_2656_122_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_pragma_env_228_ast_node, _make_pragma2601_250_ast_node2842, _make_pragma2601_250_ast_node, 0L, 6);
DEFINE_EXPORT_PROCEDURE(allocate_kwote_env_128_ast_node, _allocate_kwote_245_ast_node2843, _allocate_kwote_245_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(conditional__env_211_ast_node, _conditional__140_ast_node2844, _conditional__140_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_bindings_set__env_42_ast_node, _let_var_bindings_set_2539_217_ast_node2845, _let_var_bindings_set_2539_217_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_ly_arg_set__env_85_ast_node, _app_ly_arg_set_2626_69_ast_node2846, _app_ly_arg_set_2626_69_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_app_env_27_ast_node, _allocate_app_162_ast_node2847, _allocate_app_162_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(select_key_env_133_ast_node, _select_key_153_ast_node2848, _select_key_153_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_stack_info_set__env_132_ast_node, _app_stack_info_set_2638_87_ast_node2849, _app_stack_info_set_2638_87_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_fun_loc_env_8_ast_node, _let_fun_loc2546_121_ast_node2850, _let_fun_loc2546_121_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(pragma_side_effect__env_72_ast_node, _pragma_side_effect_2606_219_ast_node2851, _pragma_side_effect_2606_219_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_ly_arg_env_91_ast_node, _app_ly_arg2627_163_ast_node2852, _app_ly_arg2627_163_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_key_set__env_191_ast_node, _select_key_set__222_ast_node2853, _select_key_set__222_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(conditional_key_set__env_62_ast_node, _conditional_key_set__89_ast_node2854, _conditional_key_set__89_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_key_set__env_125_ast_node, _app_key_set__226_ast_node2855, _app_key_set__226_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(conditional_false_set__env_161_ast_node, _conditional_false_set_2585_128_ast_node2856, _conditional_false_set_2585_128_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_node_effect_env_65_ast_node, _allocate_node_effect_20_ast_node2857, _allocate_node_effect_20_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(let_fun_body_env_232_ast_node, _let_fun_body2554_75_ast_node2858, _let_fun_body2554_75_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(pragma_loc_env_85_ast_node, _pragma_loc2602_15_ast_node2859, _pragma_loc2602_15_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_var_env_84_ast_node, _make_var2658_215_ast_node2860, _make_var2658_215_ast_node, 0L, 3);
DEFINE_EXPORT_PROCEDURE(conditional_side_effect__set__env_48_ast_node, _conditional_side_effect__set_2579_13_ast_node2861, _conditional_side_effect__set_2579_13_ast_node, 0L, 2);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(let_var_body_env_96_ast_node, _let_var_body2542_190_ast_node2862, _let_var_body2542_190_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(pragma_args_env_159_ast_node, _pragma_args2609_133_ast_node2863, _pragma_args2609_133_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(setq_type_env_118_ast_node, _setq_type2590_177_ast_node2864, _setq_type2590_177_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_ex_it_type_set__env_8_ast_node, _set_ex_it_type_set_2527_157_ast_node2865, _set_ex_it_type_set_2527_157_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(atom_loc_env_233_ast_node, _atom_loc2665_165_ast_node2866, _atom_loc2665_165_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_sequence_env_30_ast_node, _make_sequence2640_62_ast_node2867, _make_sequence2640_62_ast_node, 0L, 5);
DEFINE_EXPORT_PROCEDURE(allocate_closure_env_30_ast_node, _allocate_closure_68_ast_node2868, _allocate_closure_68_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_funcall_env_188_ast_node, _make_funcall2610_87_ast_node2869, _make_funcall2610_87_ast_node, 0L, 5);
DEFINE_EXPORT_PROCEDURE(make_box_side_effect__env_62_ast_node, _make_box_side_effect_2514_177_ast_node2870, _make_box_side_effect_2514_177_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sequence_type_set__env_30_ast_node, _sequence_type_set_2642_133_ast_node2871, _sequence_type_set_2642_133_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_effect_loc_env_205_ast_node, _node_effect_loc2671_156_ast_node2872, _node_effect_loc2671_156_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(pragma_type_set__env_102_ast_node, _pragma_type_set_2603_242_ast_node2873, _pragma_type_set_2603_242_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_args_set__env_126_ast_node, _app_args_set_2636_222_ast_node2874, _app_args_set_2636_222_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_type_env_16_ast_node, _app_type2631_39_ast_node2875, _app_type2631_39_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_conditional_env_37_ast_node, _make_conditional2575_101_ast_node2876, _make_conditional2575_101_ast_node, 0L, 7);
DEFINE_EXPORT_PROCEDURE(closure_variable_env_144_ast_node, _closure_variable2657_254_ast_node2877, _closure_variable2657_254_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(closure_type_env_25_ast_node, _closure_type2655_215_ast_node2878, _closure_type2655_215_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(var_variable_set__env_237_ast_node, _var_variable_set_2662_236_ast_node2879, _var_variable_set_2662_236_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(pragma_format_env_224_ast_node, _pragma_format2607_223_ast_node2880, _pragma_format2607_223_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(kwote_type_env_152_ast_node, _kwote_type2650_225_ast_node2881, _kwote_type2650_225_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_type_set__env_73_ast_node, _fail_type_set_2567_138_ast_node2882, _fail_type_set_2567_138_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_fun_side_effect__set__env_17_ast_node, _let_fun_side_effect__set_2549_170_ast_node2883, _let_fun_side_effect__set_2549_170_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(kwote_loc_env_171_ast_node, _kwote_loc2648_52_ast_node2884, _kwote_loc2648_52_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_type_env_94_ast_node, _conditional_type2578_94_ast_node2885, _conditional_type2578_94_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(var_type_env_9_ast_node, _var_type2661_41_ast_node2886, _var_type2661_41_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_set__value_set__env_57_ast_node, _box_set__value_set_2499_21_ast_node2887, _box_set__value_set_2499_21_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_var_removable__set__env_230_ast_node, _let_var_removable__set_2543_208_ast_node2888, _let_var_removable__set_2543_208_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sequence_key_env_163_ast_node, _sequence_key_229_ast_node2889, _sequence_key_229_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_obj_env_238_ast_node, _fail_obj2574_73_ast_node2890, _fail_obj2574_73_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_ex_it_body_set__env_144_ast_node, _set_ex_it_body_set_2531_199_ast_node2891, _set_ex_it_body_set_2531_199_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_fun_type_set__env_233_ast_node, _let_fun_type_set_2547_72_ast_node2892, _let_fun_type_set_2547_72_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_loc_env_168_ast_node, _jump_ex_it_loc2518_20_ast_node2893, _jump_ex_it_loc2518_20_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_fun_locals_env_159_ast_node, _let_fun_locals2552_73_ast_node2894, _let_fun_locals2552_73_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_ex_it__env_28_ast_node, _set_ex_it__35_ast_node2895, _set_ex_it__35_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_loc_env_135_ast_node, _fail_loc2566_8_ast_node2896, _fail_loc2566_8_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_test_env_161_ast_node, _select_test2562_140_ast_node2897, _select_test2562_140_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_kwote_env_2_ast_node, _make_kwote2647_26_ast_node2898, _make_kwote2647_26_ast_node, 0L, 3);
DEFINE_EXPORT_PROCEDURE(funcall_loc_env_135_ast_node, _funcall_loc2611_9_ast_node2899, _funcall_loc2611_9_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_loc_env_215_ast_node, _let_var_loc2534_1_ast_node2900, _let_var_loc2534_1_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_set__var_env_7_ast_node, _box_set__var2498_218_ast_node2901, _box_set__var2498_218_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_var_side_effect__env_58_ast_node, _let_var_side_effect_2538_65_ast_node2902, _let_var_side_effect_2538_65_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_ref_key_env_4_ast_node, _box_ref_key_225_ast_node2903, _box_ref_key_225_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sequence_type_env_90_ast_node, _sequence_type2643_232_ast_node2904, _sequence_type2643_232_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_value_set__env_48_ast_node, _jump_ex_it_value_set_2523_69_ast_node2905, _jump_ex_it_value_set_2523_69_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_var_side_effect__set__env_190_ast_node, _let_var_side_effect__set_2537_236_ast_node2906, _let_var_side_effect__set_2537_236_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_side_effect__set__env_249_ast_node, _app_side_effect__set_2632_76_ast_node2907, _app_side_effect__set_2632_76_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_loc_env_54_ast_node, _app_loc2629_107_ast_node2908, _app_loc2629_107_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_exit_set__env_72_ast_node, _jump_ex_it_exit_set_2521_158_ast_node2909, _jump_ex_it_exit_set_2521_158_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_args_env_218_ast_node, _app_args2637_94_ast_node2910, _app_args2637_94_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sequence_side_effect__env_243_ast_node, _sequence_side_effect_2645_115_ast_node2911, _sequence_side_effect_2645_115_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_sequence_env_201_ast_node, _allocate_sequence_156_ast_node2912, _allocate_sequence_156_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(set_ex_it_loc_env_136_ast_node, _set_ex_it_loc2526_190_ast_node2913, _set_ex_it_loc2526_190_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(funcall_type_set__env_73_ast_node, _funcall_type_set_2612_24_ast_node2914, _funcall_type_set_2612_24_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_box_value_set__env_202_ast_node, _make_box_value_set_2515_68_ast_node2915, _make_box_value_set_2515_68_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_box_set__env_222_ast_node, _make_box_set_2493_36_ast_node2916, _make_box_set_2493_36_ast_node, 0L, 4);
DEFINE_EXPORT_PROCEDURE(node_type_env_176_ast_node, _node_type2679_26_ast_node2917, _node_type2679_26_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_fun_body_set__env_177_ast_node, _let_fun_body_set_2553_147_ast_node2918, _let_fun_body_set_2553_147_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(set_ex_it_type_env_28_ast_node, _set_ex_it_type2528_118_ast_node2919, _set_ex_it_type2528_118_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cast_loc_env_156_ast_node, _cast_loc2596_220_ast_node2920, _cast_loc2596_220_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_true_env_222_ast_node, _conditional_true2584_27_ast_node2921, _conditional_true2584_27_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_side_effect__env_76_ast_node, _select_side_effect_2560_103_ast_node2922, _select_side_effect_2560_103_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_loc_env_132_ast_node, _select_loc2556_23_ast_node2923, _select_loc2556_23_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_effect__env_121_ast_node, _node_effect__62_ast_node2924, _node_effect__62_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_box_key_env_126_ast_node, _make_box_key_238_ast_node2925, _make_box_key_238_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_funcall_env_134_ast_node, _allocate_funcall_93_ast_node2926, _allocate_funcall_93_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cast__env_36_ast_node, _cast__220_ast_node2927, _cast__220_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_set__value_env_229_ast_node, _box_set__value2500_46_ast_node2928, _box_set__value2500_46_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sequence_side_effect__set__env_162_ast_node, _sequence_side_effect__set_2644_117_ast_node2929, _sequence_side_effect__set_2644_117_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(kwote_value_env_5_ast_node, _kwote_value2651_145_ast_node2930, _kwote_value2651_145_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_var_env_196_ast_node, _allocate_var_93_ast_node2931, _allocate_var_93_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(box_set__var_set__env_59_ast_node, _box_set__var_set_2497_175_ast_node2932, _box_set__var_set_2497_175_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fail_proc_env_127_ast_node, _fail_proc2570_42_ast_node2933, _fail_proc2570_42_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_test_set__env_121_ast_node, _select_test_set_2561_102_ast_node2934, _select_test_set_2561_102_ast_node, 0L, 2);
DEFINE_STRING(string2731_ast_node, string2731_ast_node2935, "BOX-SET! BOX-REF MAKE-BOX JUMP-EX-IT SET-EX-IT LET-VAR LET-FUN SELECT FAIL CONDITIONAL SETQ CAST PRAGMA FUNCALL APP-LY APP SEQUENCE KWOTE CLOSURE VAR ATOM NODE/EFFECT NODE ", 172);
DEFINE_EXPORT_PROCEDURE(conditional_test_set__env_112_ast_node, _conditional_test_set_2581_5_ast_node2936, _conditional_test_set_2581_5_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(var_loc_env_143_ast_node, _var_loc2659_203_ast_node2937, _var_loc2659_203_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(atom_type_env_37_ast_node, _atom_type2667_50_ast_node2938, _atom_type2667_50_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_let_var_env_152_ast_node, _make_let_var2533_130_ast_node2939, _make_let_var2533_130_ast_node, 0L, 7);
DEFINE_EXPORT_PROCEDURE(let_var_removable__env_84_ast_node, _let_var_removable_2544_155_ast_node2940, _let_var_removable_2544_155_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_key_env_231_ast_node, _conditional_key_147_ast_node2941, _conditional_key_147_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_type_env_230_ast_node, _jump_ex_it_type2520_122_ast_node2942, _jump_ex_it_type2520_122_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_msg_env_38_ast_node, _fail_msg2572_162_ast_node2943, _fail_msg2572_162_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_let_fun_env_58_ast_node, _make_let_fun2545_205_ast_node2944, _make_let_fun2545_205_ast_node, 0L, 6);
DEFINE_EXPORT_PROCEDURE(atom_value_env_7_ast_node, _atom_value2669_108_ast_node2945, _atom_value2669_108_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(setq_value_env_51_ast_node, _setq_value2594_157_ast_node2946, _setq_value2594_157_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_ly_type_set__env_224_ast_node, _app_ly_type_set_2622_144_ast_node2947, _app_ly_type_set_2622_144_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_var__env_187_ast_node, _let_var__141_ast_node2948, _let_var__141_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_box_key_set__env_122_ast_node, _make_box_key_set__73_ast_node2949, _make_box_key_set__73_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cast_type_env_116_ast_node, _cast_type2598_33_ast_node2950, _cast_type2598_33_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_set_ex_it_env_240_ast_node, _allocate_set_ex_it_70_ast_node2951, _allocate_set_ex_it_70_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_value_env_1_ast_node, _jump_ex_it_value2524_58_ast_node2952, _jump_ex_it_value2524_58_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_ly_loc_env_245_ast_node, _app_ly_loc2621_94_ast_node2953, _app_ly_loc2621_94_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(kwote_type_set__env_51_ast_node, _kwote_type_set_2649_70_ast_node2954, _kwote_type_set_2649_70_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_box_type_set__env_191_ast_node, _make_box_type_set_2511_87_ast_node2955, _make_box_type_set_2511_87_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_make_box_env_108_ast_node, _make_make_box2509_255_ast_node2956, _make_make_box2509_255_ast_node, 0L, 5);
DEFINE_EXPORT_PROCEDURE(conditional_false_env_60_ast_node, _conditional_false2586_217_ast_node2957, _conditional_false2586_217_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_msg_set__env_61_ast_node, _fail_msg_set_2571_24_ast_node2958, _fail_msg_set_2571_24_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(funcall_strength_env_24_ast_node, _funcall_strength2619_138_ast_node2959, _funcall_strength2619_138_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_box_set__env_30_ast_node, _allocate_box_set__43_ast_node2960, _allocate_box_set__43_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_app_ly_env_193_ast_node, _allocate_app_ly_138_ast_node2961, _allocate_app_ly_138_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(pragma_key_set__env_153_ast_node, _pragma_key_set__110_ast_node2962, _pragma_key_set__110_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_fail_env_28_ast_node, _allocate_fail_214_ast_node2963, _allocate_fail_214_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sequence_loc_env_55_ast_node, _sequence_loc2641_133_ast_node2964, _sequence_loc2641_133_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(atom_type_set__env_31_ast_node, _atom_type_set_2666_88_ast_node2965, _atom_type_set_2666_88_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(box_ref_side_effect__set__env_192_ast_node, _box_ref_side_effect__set_2505_194_ast_node2966, _box_ref_side_effect__set_2505_194_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app_ly__env_2_ast_node, _app_ly__224_ast_node2967, _app_ly__224_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(atom__env_198_ast_node, _atom__186_ast_node2968, _atom__186_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_conditional_env_156_ast_node, _allocate_conditional_184_ast_node2969, _allocate_conditional_184_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(fail_obj_set__env_135_ast_node, _fail_obj_set_2573_88_ast_node2970, _fail_obj_set_2573_88_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_effect_type_env_93_ast_node, _node_effect_type2673_60_ast_node2971, _node_effect_type2673_60_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_effect_type_set__env_87_ast_node, _node_effect_type_set_2672_137_ast_node2972, _node_effect_type_set_2672_137_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_box__env_20_ast_node, _make_box__204_ast_node2973, _make_box__204_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_fail_env_198_ast_node, _make_fail2565_1_ast_node2974, _make_fail2565_1_ast_node, 0L, 5);
DEFINE_EXPORT_PROCEDURE(app_side_effect__env_112_ast_node, _app_side_effect_2633_41_ast_node2975, _app_side_effect_2633_41_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(closure__env_92_ast_node, _closure__33_ast_node2976, _closure__33_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_box_ref_env_48_ast_node, _make_box_ref2501_60_ast_node2977, _make_box_ref2501_60_ast_node, 0L, 5);
DEFINE_EXPORT_PROCEDURE(setq_value_set__env_40_ast_node, _setq_value_set_2593_255_ast_node2978, _setq_value_set_2593_255_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(jump_ex_it__env_238_ast_node, _jump_ex_it__165_ast_node2979, _jump_ex_it__165_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(atom_value_set__env_59_ast_node, _atom_value_set_2668_157_ast_node2980, _atom_value_set_2668_157_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cast_arg_set__env_104_ast_node, _cast_arg_set_2599_159_ast_node2981, _cast_arg_set_2599_159_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(conditional_true_set__env_254_ast_node, _conditional_true_set_2583_74_ast_node2982, _conditional_true_set_2583_74_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(box_ref_var_set__env_177_ast_node, _box_ref_var_set_2507_170_ast_node2983, _box_ref_var_set_2507_170_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(pragma_side_effect__set__env_156_ast_node, _pragma_side_effect__set_2605_45_ast_node2984, _pragma_side_effect__set_2605_45_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(box_ref_loc_env_155_ast_node, _box_ref_loc2502_223_ast_node2985, _box_ref_loc2502_223_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_type_env_15_ast_node, _select_type2558_223_ast_node2986, _select_type2558_223_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(pragma_args_set__env_206_ast_node, _pragma_args_set_2608_116_ast_node2987, _pragma_args_set_2608_116_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_type_set__env_201_ast_node, _node_type_set_2678_183_ast_node2988, _node_type_set_2678_183_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(jump_ex_it_type_set__env_160_ast_node, _jump_ex_it_type_set_2519_242_ast_node2989, _jump_ex_it_type_set_2519_242_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(funcall_fun_env_121_ast_node, _funcall_fun2615_153_ast_node2990, _funcall_fun2615_153_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(funcall_strength_set__env_240_ast_node, _funcall_strength_set_2618_194_ast_node2991, _funcall_strength_set_2618_194_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cast_type_set__env_103_ast_node, _cast_type_set_2597_150_ast_node2992, _cast_type_set_2597_150_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(setq_loc_env_7_ast_node, _setq_loc2588_95_ast_node2993, _setq_loc2588_95_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_node_effect_env_234_ast_node, _make_node_effect2670_29_ast_node2994, _make_node_effect2670_29_ast_node, 0L, 4);
DEFINE_EXPORT_PROCEDURE(closure_loc_env_57_ast_node, _closure_loc2653_80_ast_node2995, _closure_loc2653_80_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_setq_env_19_ast_node, _allocate_setq_253_ast_node2996, _allocate_setq_253_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_node_env_214_ast_node, _allocate_node_227_ast_node2997, _allocate_node_227_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(closure_type_set__env_197_ast_node, _closure_type_set_2654_234_ast_node2998, _closure_type_set_2654_234_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(app__env_253_ast_node, _app__141_ast_node2999, _app__141_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_effect_side_effect__env_215_ast_node, _node_effect_side_effect_2675_102_ast_node3000, _node_effect_side_effect_2675_102_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(select_type_set__env_67_ast_node, _select_type_set_2557_134_ast_node3001, _select_type_set_2557_134_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_fun_key_set__env_129_ast_node, _let_fun_key_set__133_ast_node3002, _let_fun_key_set__133_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_loc_env_117_ast_node, _node_loc2677_157_ast_node3003, _node_loc2677_157_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_ex_it_var_env_99_ast_node, _set_ex_it_var2530_147_ast_node3004, _set_ex_it_var2530_147_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(app_fun_env_56_ast_node, _app_fun2635_82_ast_node3005, _app_fun2635_82_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(conditional_type_set__env_91_ast_node, _conditional_type_set_2577_38_ast_node3006, _conditional_type_set_2577_38_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_let_var_env_250_ast_node, _allocate_let_var_179_ast_node3007, _allocate_let_var_179_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(set_ex_it_body_env_50_ast_node, _set_ex_it_body2532_170_ast_node3008, _set_ex_it_body2532_170_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_setq_env_30_ast_node, _make_setq2587_87_ast_node3009, _make_setq2587_87_ast_node, 0L, 4);
DEFINE_EXPORT_PROCEDURE(app_type_set__env_237_ast_node, _app_type_set_2630_109_ast_node3010, _app_type_set_2630_109_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_jump_ex_it_env_123_ast_node, _make_jump_ex_it2517_208_ast_node3011, _make_jump_ex_it2517_208_ast_node, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_node_env_151_ast_node, _make_node2676_204_ast_node3012, _make_node2676_204_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_fun__env_93_ast_node, _let_fun__236_ast_node3013, _let_fun__236_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_type_env_209_ast_node, _fail_type2568_237_ast_node3014, _fail_type2568_237_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_set_ex_it_env_226_ast_node, _make_set_ex_it2525_29_ast_node3015, _make_set_ex_it2525_29_ast_node, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_box_type_env_133_ast_node, _make_box_type2512_97_ast_node3016, _make_box_type2512_97_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_let_fun_env_44_ast_node, _allocate_let_fun_123_ast_node3017, _allocate_let_fun_123_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_app_env_36_ast_node, _make_app2628_2_ast_node3018, _make_app2628_2_ast_node, 0L, 7);
DEFINE_EXPORT_PROCEDURE(box_ref_type_set__env_17_ast_node, _box_ref_type_set_2503_209_ast_node3019, _box_ref_type_set_2503_209_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(let_fun_locals_set__env_206_ast_node, _let_fun_locals_set_2551_38_ast_node3020, _let_fun_locals_set_2551_38_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_box_loc_env_69_ast_node, _make_box_loc2510_15_ast_node3021, _make_box_loc2510_15_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_fun_key_env_31_ast_node, _let_fun_key_252_ast_node3022, _let_fun_key_252_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(box_ref_key_set__env_142_ast_node, _box_ref_key_set__224_ast_node3023, _box_ref_key_set__224_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_cast_env_179_ast_node, _allocate_cast_146_ast_node3024, _allocate_cast_146_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(let_fun_type_env_150_ast_node, _let_fun_type2548_212_ast_node3025, _let_fun_type2548_212_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(setq_var_set__env_152_ast_node, _setq_var_set_2591_219_ast_node3026, _setq_var_set_2591_219_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_make_box_env_148_ast_node, _allocate_make_box_168_ast_node3027, _allocate_make_box_168_ast_node, 0L, 0);
DEFINE_EXPORT_PROCEDURE(box_ref_side_effect__env_68_ast_node, _box_ref_side_effect_2506_100_ast_node3028, _box_ref_side_effect_2506_100_ast_node, 0L, 1);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(pragma_key_env_219_ast_node, _pragma_key_199_ast_node3029, _pragma_key_199_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(let_fun_side_effect__env_214_ast_node, _let_fun_side_effect_2550_53_ast_node3030, _let_fun_side_effect_2550_53_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_app_ly_env_41_ast_node, _make_app_ly2620_72_ast_node3031, _make_app_ly2620_72_ast_node, 0L, 4);
DEFINE_EXPORT_PROCEDURE(make_cast_env_177_ast_node, _make_cast2595_213_ast_node3032, _make_cast2595_213_ast_node, 0L, 3);
DEFINE_EXPORT_PROCEDURE(kwote__env_173_ast_node, _kwote__112_ast_node3033, _kwote__112_ast_node, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_effect_side_effect__set__env_245_ast_node, _node_effect_side_effect__set_2674_173_ast_node3034, _node_effect_side_effect__set_2674_173_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(select_side_effect__set__env_38_ast_node, _select_side_effect__set_2559_195_ast_node3035, _select_side_effect__set_2559_195_ast_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(box_set__type_env_162_ast_node, _box_set__type2496_192_ast_node3036, _box_set__type2496_192_ast_node, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_ast_node(long checksum_3723, char *from_3724)
{
   if (CBOOL(require_initialization_114_ast_node))
     {
	require_initialization_114_ast_node = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_node();
	cnst_init_137_ast_node();
	imported_modules_init_94_ast_node();
	object_init_111_ast_node();
	method_init_76_ast_node();
	toplevel_init_63_ast_node();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_node()
{
   module_initialization_70___object(((long) 0), "AST_NODE");
   module_initialization_70___reader(((long) 0), "AST_NODE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_node()
{
   {
      obj_t cnst_port_138_3715;
      cnst_port_138_3715 = open_input_string(string2731_ast_node);
      {
	 long i_3716;
	 i_3716 = ((long) 22);
       loop_3717:
	 {
	    bool_t test2732_3718;
	    test2732_3718 = (i_3716 == ((long) -1));
	    if (test2732_3718)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2733_3719;
		    {
		       obj_t list2734_3720;
		       {
			  obj_t arg2735_3721;
			  arg2735_3721 = BNIL;
			  list2734_3720 = MAKE_PAIR(cnst_port_138_3715, arg2735_3721);
		       }
		       arg2733_3719 = read___reader(list2734_3720);
		    }
		    CNST_TABLE_SET(i_3716, arg2733_3719);
		 }
		 {
		    int aux_3722;
		    {
		       long aux_3742;
		       aux_3742 = (i_3716 - ((long) 1));
		       aux_3722 = (int) (aux_3742);
		    }
		    {
		       long i_3745;
		       i_3745 = (long) (aux_3722);
		       i_3716 = i_3745;
		       goto loop_3717;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_node()
{
   return BUNSPEC;
}


/* object-init */ obj_t 
object_init_111_ast_node()
{
   {
      obj_t arg1953_762;
      arg1953_762 = object___object;
      node_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 0)), arg1953_762, allocate_node_env_214_ast_node, ((long) 29579), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1958_766;
      arg1958_766 = node_ast_node;
      node_effect_213_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1958_766, allocate_node_effect_env_65_ast_node, ((long) 53365), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1962_770;
      arg1962_770 = node_ast_node;
      atom_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1962_770, allocate_atom_env_206_ast_node, ((long) 51461), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1967_774;
      arg1967_774 = node_ast_node;
      var_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 3)), arg1967_774, allocate_var_env_196_ast_node, ((long) 23313), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1973_778;
      arg1973_778 = var_ast_node;
      closure_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 4)), arg1973_778, allocate_closure_env_30_ast_node, ((long) 48469), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1978_782;
      arg1978_782 = node_ast_node;
      kwote_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 5)), arg1978_782, allocate_kwote_env_128_ast_node, ((long) 35302), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1982_786;
      arg1982_786 = node_effect_213_ast_node;
      sequence_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 6)), arg1982_786, allocate_sequence_env_201_ast_node, ((long) 12441), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1986_790;
      arg1986_790 = node_effect_213_ast_node;
      app_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 7)), arg1986_790, allocate_app_env_27_ast_node, ((long) 50317), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1990_794;
      arg1990_794 = node_ast_node;
      app_ly_162_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 8)), arg1990_794, allocate_app_ly_env_193_ast_node, ((long) 40452), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1994_798;
      arg1994_798 = node_ast_node;
      funcall_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 9)), arg1994_798, allocate_funcall_env_134_ast_node, ((long) 61754), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2001_802;
      arg2001_802 = node_effect_213_ast_node;
      pragma_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 10)), arg2001_802, allocate_pragma_env_128_ast_node, ((long) 8731), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2006_806;
      arg2006_806 = node_ast_node;
      cast_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 11)), arg2006_806, allocate_cast_env_179_ast_node, ((long) 10303), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2012_810;
      arg2012_810 = node_ast_node;
      setq_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 12)), arg2012_810, allocate_setq_env_19_ast_node, ((long) 7212), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2016_814;
      arg2016_814 = node_effect_213_ast_node;
      conditional_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 13)), arg2016_814, allocate_conditional_env_156_ast_node, ((long) 53673), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2020_818;
      arg2020_818 = node_ast_node;
      fail_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 14)), arg2020_818, allocate_fail_env_28_ast_node, ((long) 57614), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2024_822;
      arg2024_822 = node_effect_213_ast_node;
      select_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 15)), arg2024_822, allocate_select_env_246_ast_node, ((long) 25857), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2029_826;
      arg2029_826 = node_effect_213_ast_node;
      let_fun_218_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 16)), arg2029_826, allocate_let_fun_env_44_ast_node, ((long) 49470), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2033_830;
      arg2033_830 = node_effect_213_ast_node;
      let_var_6_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 17)), arg2033_830, allocate_let_var_env_250_ast_node, ((long) 54082), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2039_834;
      arg2039_834 = node_ast_node;
      set_ex_it_116_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 18)), arg2039_834, allocate_set_ex_it_env_240_ast_node, ((long) 21934), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2043_838;
      arg2043_838 = node_ast_node;
      jump_ex_it_184_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 19)), arg2043_838, allocate_jump_ex_it_env_98_ast_node, ((long) 23339), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2047_842;
      arg2047_842 = node_effect_213_ast_node;
      make_box_202_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 20)), arg2047_842, allocate_make_box_env_148_ast_node, ((long) 53395), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2051_846;
      arg2051_846 = node_effect_213_ast_node;
      box_ref_242_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 21)), arg2051_846, allocate_box_ref_env_189_ast_node, ((long) 51205), BUNSPEC, BFALSE);
   }
   {
      obj_t arg2055_850;
      arg2055_850 = node_ast_node;
      box_set__221_ast_node = add_class__117___object(CNST_TABLE_REF(((long) 22)), arg2055_850, allocate_box_set__env_30_ast_node, ((long) 23650), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-box-set! */ box_set__221_t 
allocate_box_set__237_ast_node()
{
   {
      box_set__221_t new1887_853;
      new1887_853 = ((box_set__221_t) BREF(GC_MALLOC(sizeof(struct box_set__221))));
      {
	 long arg2058_854;
	 arg2058_854 = class_num_218___object(box_set__221_ast_node);
	 {
	    obj_t obj_1841;
	    obj_1841 = (obj_t) (new1887_853);
	    (((obj_t) CREF(obj_1841))->header = MAKE_HEADER(arg2058_854, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3797;
	 aux_3797 = (object_t) (new1887_853);
	 OBJECT_WIDENING_SET(aux_3797, BFALSE);
      }
      return new1887_853;
   }
}


/* _allocate-box-set! */ obj_t 
_allocate_box_set__43_ast_node(obj_t env_2927)
{
   {
      box_set__221_t aux_3800;
      aux_3800 = allocate_box_set__237_ast_node();
      return (obj_t) (aux_3800);
   }
}


/* box-set!? */ bool_t 
box_set___31_ast_node(obj_t obj_4)
{
   return is_a__118___object(obj_4, box_set__221_ast_node);
}


/* _box-set!? */ obj_t 
_box_set___53_ast_node(obj_t env_2928, obj_t obj_2929)
{
   {
      bool_t aux_3804;
      aux_3804 = box_set___31_ast_node(obj_2929);
      return BBOOL(aux_3804);
   }
}


/* make-box-set! */ box_set__221_t 
make_box_set__226_ast_node(obj_t loc_5, type_t type_6, var_t var_7, node_t value_8)
{
   {
      box_set__221_t new1878_1843;
      new1878_1843 = ((box_set__221_t) BREF(GC_MALLOC(sizeof(struct box_set__221))));
      {
	 long arg2059_1844;
	 arg2059_1844 = class_num_218___object(box_set__221_ast_node);
	 {
	    obj_t obj_1849;
	    obj_1849 = (obj_t) (new1878_1843);
	    (((obj_t) CREF(obj_1849))->header = MAKE_HEADER(arg2059_1844, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3811;
	 aux_3811 = (object_t) (new1878_1843);
	 OBJECT_WIDENING_SET(aux_3811, BFALSE);
      }
      ((((box_set__221_t) CREF(new1878_1843))->loc) = ((obj_t) loc_5), BUNSPEC);
      ((((box_set__221_t) CREF(new1878_1843))->type) = ((type_t) type_6), BUNSPEC);
      ((((box_set__221_t) CREF(new1878_1843))->var) = ((var_t) var_7), BUNSPEC);
      ((((box_set__221_t) CREF(new1878_1843))->value) = ((node_t) value_8), BUNSPEC);
      return new1878_1843;
   }
}


/* _make-box-set!2493 */ obj_t 
_make_box_set_2493_36_ast_node(obj_t env_2930, obj_t loc_2931, obj_t type_2932, obj_t var_2933, obj_t value_2934)
{
   {
      box_set__221_t aux_3818;
      aux_3818 = make_box_set__226_ast_node(loc_2931, (type_t) (type_2932), (var_t) (var_2933), (node_t) (value_2934));
      return (obj_t) (aux_3818);
   }
}


/* box-set!-loc */ obj_t 
box_set__loc_237_ast_node(box_set__221_t obj_9)
{
   return (((box_set__221_t) CREF(obj_9))->loc);
}


/* _box-set!-loc2494 */ obj_t 
_box_set__loc2494_37_ast_node(obj_t env_2935, obj_t obj_2936)
{
   return box_set__loc_237_ast_node((box_set__221_t) (obj_2936));
}


/* box-set!-type-set! */ obj_t 
box_set__type_set__0_ast_node(box_set__221_t obj_10, type_t val1884_11)
{
   return ((((box_set__221_t) CREF(obj_10))->type) = ((type_t) val1884_11), BUNSPEC);
}


/* _box-set!-type-set!2495 */ obj_t 
_box_set__type_set_2495_39_ast_node(obj_t env_2937, obj_t obj_2938, obj_t val1884_2939)
{
   return box_set__type_set__0_ast_node((box_set__221_t) (obj_2938), (type_t) (val1884_2939));
}


/* box-set!-type */ type_t 
box_set__type_38_ast_node(box_set__221_t obj_12)
{
   return (((box_set__221_t) CREF(obj_12))->type);
}


/* _box-set!-type2496 */ obj_t 
_box_set__type2496_192_ast_node(obj_t env_2940, obj_t obj_2941)
{
   {
      type_t aux_3832;
      aux_3832 = box_set__type_38_ast_node((box_set__221_t) (obj_2941));
      return (obj_t) (aux_3832);
   }
}


/* box-set!-var-set! */ obj_t 
box_set__var_set__52_ast_node(box_set__221_t obj_13, var_t val1885_14)
{
   return ((((box_set__221_t) CREF(obj_13))->var) = ((var_t) val1885_14), BUNSPEC);
}


/* _box-set!-var-set!2497 */ obj_t 
_box_set__var_set_2497_175_ast_node(obj_t env_2942, obj_t obj_2943, obj_t val1885_2944)
{
   return box_set__var_set__52_ast_node((box_set__221_t) (obj_2943), (var_t) (val1885_2944));
}


/* box-set!-var */ var_t 
box_set__var_177_ast_node(box_set__221_t obj_15)
{
   return (((box_set__221_t) CREF(obj_15))->var);
}


/* _box-set!-var2498 */ obj_t 
_box_set__var2498_218_ast_node(obj_t env_2945, obj_t obj_2946)
{
   {
      var_t aux_3841;
      aux_3841 = box_set__var_177_ast_node((box_set__221_t) (obj_2946));
      return (obj_t) (aux_3841);
   }
}


/* box-set!-value-set! */ obj_t 
box_set__value_set__195_ast_node(box_set__221_t obj_16, node_t val1886_17)
{
   return ((((box_set__221_t) CREF(obj_16))->value) = ((node_t) val1886_17), BUNSPEC);
}


/* _box-set!-value-set!2499 */ obj_t 
_box_set__value_set_2499_21_ast_node(obj_t env_2947, obj_t obj_2948, obj_t val1886_2949)
{
   return box_set__value_set__195_ast_node((box_set__221_t) (obj_2948), (node_t) (val1886_2949));
}


/* box-set!-value */ node_t 
box_set__value_123_ast_node(box_set__221_t obj_18)
{
   return (((box_set__221_t) CREF(obj_18))->value);
}


/* _box-set!-value2500 */ obj_t 
_box_set__value2500_46_ast_node(obj_t env_2950, obj_t obj_2951)
{
   {
      node_t aux_3850;
      aux_3850 = box_set__value_123_ast_node((box_set__221_t) (obj_2951));
      return (obj_t) (aux_3850);
   }
}


/* allocate-box-ref */ box_ref_242_t 
allocate_box_ref_100_ast_node()
{
   {
      box_ref_242_t new1855_861;
      new1855_861 = ((box_ref_242_t) BREF(GC_MALLOC(sizeof(struct box_ref_242))));
      {
	 long arg2060_862;
	 arg2060_862 = class_num_218___object(box_ref_242_ast_node);
	 {
	    obj_t obj_1851;
	    obj_1851 = (obj_t) (new1855_861);
	    (((obj_t) CREF(obj_1851))->header = MAKE_HEADER(arg2060_862, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3858;
	 aux_3858 = (object_t) (new1855_861);
	 OBJECT_WIDENING_SET(aux_3858, BFALSE);
      }
      return new1855_861;
   }
}


/* _allocate-box-ref */ obj_t 
_allocate_box_ref_230_ast_node(obj_t env_2926)
{
   {
      box_ref_242_t aux_3861;
      aux_3861 = allocate_box_ref_100_ast_node();
      return (obj_t) (aux_3861);
   }
}


/* box-ref? */ bool_t 
box_ref__165_ast_node(obj_t obj_22)
{
   return is_a__118___object(obj_22, box_ref_242_ast_node);
}


/* _box-ref? */ obj_t 
_box_ref__132_ast_node(obj_t env_2952, obj_t obj_2953)
{
   {
      bool_t aux_3865;
      aux_3865 = box_ref__165_ast_node(obj_2953);
      return BBOOL(aux_3865);
   }
}


/* make-box-ref */ box_ref_242_t 
make_box_ref_158_ast_node(obj_t loc_23, type_t type_24, obj_t side_effect__165_25, obj_t key_26, var_t var_27)
{
   {
      box_ref_242_t new1844_1853;
      new1844_1853 = ((box_ref_242_t) BREF(GC_MALLOC(sizeof(struct box_ref_242))));
      {
	 long arg2061_1854;
	 arg2061_1854 = class_num_218___object(box_ref_242_ast_node);
	 {
	    obj_t obj_1860;
	    obj_1860 = (obj_t) (new1844_1853);
	    (((obj_t) CREF(obj_1860))->header = MAKE_HEADER(arg2061_1854, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3872;
	 aux_3872 = (object_t) (new1844_1853);
	 OBJECT_WIDENING_SET(aux_3872, BFALSE);
      }
      ((((box_ref_242_t) CREF(new1844_1853))->loc) = ((obj_t) loc_23), BUNSPEC);
      ((((box_ref_242_t) CREF(new1844_1853))->type) = ((type_t) type_24), BUNSPEC);
      ((((box_ref_242_t) CREF(new1844_1853))->side_effect__165) = ((obj_t) side_effect__165_25), BUNSPEC);
      ((((box_ref_242_t) CREF(new1844_1853))->key) = ((obj_t) key_26), BUNSPEC);
      ((((box_ref_242_t) CREF(new1844_1853))->var) = ((var_t) var_27), BUNSPEC);
      return new1844_1853;
   }
}


/* _make-box-ref2501 */ obj_t 
_make_box_ref2501_60_ast_node(obj_t env_2954, obj_t loc_2955, obj_t type_2956, obj_t side_effect__165_2957, obj_t key_2958, obj_t var_2959)
{
   {
      box_ref_242_t aux_3880;
      aux_3880 = make_box_ref_158_ast_node(loc_2955, (type_t) (type_2956), side_effect__165_2957, key_2958, (var_t) (var_2959));
      return (obj_t) (aux_3880);
   }
}


/* box-ref-loc */ obj_t 
box_ref_loc_220_ast_node(box_ref_242_t obj_28)
{
   return (((box_ref_242_t) CREF(obj_28))->loc);
}


/* _box-ref-loc2502 */ obj_t 
_box_ref_loc2502_223_ast_node(obj_t env_2960, obj_t obj_2961)
{
   return box_ref_loc_220_ast_node((box_ref_242_t) (obj_2961));
}


/* box-ref-type-set! */ obj_t 
box_ref_type_set__106_ast_node(box_ref_242_t obj_29, type_t val1851_30)
{
   return ((((box_ref_242_t) CREF(obj_29))->type) = ((type_t) val1851_30), BUNSPEC);
}


/* _box-ref-type-set!2503 */ obj_t 
_box_ref_type_set_2503_209_ast_node(obj_t env_2962, obj_t obj_2963, obj_t val1851_2964)
{
   return box_ref_type_set__106_ast_node((box_ref_242_t) (obj_2963), (type_t) (val1851_2964));
}


/* box-ref-type */ type_t 
box_ref_type_189_ast_node(box_ref_242_t obj_31)
{
   return (((box_ref_242_t) CREF(obj_31))->type);
}


/* _box-ref-type2504 */ obj_t 
_box_ref_type2504_178_ast_node(obj_t env_2965, obj_t obj_2966)
{
   {
      type_t aux_3893;
      aux_3893 = box_ref_type_189_ast_node((box_ref_242_t) (obj_2966));
      return (obj_t) (aux_3893);
   }
}


/* box-ref-side-effect?-set! */ obj_t 
box_ref_side_effect__set__120_ast_node(box_ref_242_t obj_32, obj_t val1852_33)
{
   return ((((box_ref_242_t) CREF(obj_32))->side_effect__165) = ((obj_t) val1852_33), BUNSPEC);
}


/* _box-ref-side-effect?-set!2505 */ obj_t 
_box_ref_side_effect__set_2505_194_ast_node(obj_t env_2967, obj_t obj_2968, obj_t val1852_2969)
{
   return box_ref_side_effect__set__120_ast_node((box_ref_242_t) (obj_2968), val1852_2969);
}


/* box-ref-side-effect? */ obj_t 
box_ref_side_effect__200_ast_node(box_ref_242_t obj_34)
{
   return (((box_ref_242_t) CREF(obj_34))->side_effect__165);
}


/* _box-ref-side-effect?2506 */ obj_t 
_box_ref_side_effect_2506_100_ast_node(obj_t env_2970, obj_t obj_2971)
{
   return box_ref_side_effect__200_ast_node((box_ref_242_t) (obj_2971));
}


/* box-ref-key-set! */ obj_t 
box_ref_key_set__192_ast_node(box_ref_242_t obj_35, obj_t val1853_36)
{
   return ((((box_ref_242_t) CREF(obj_35))->key) = ((obj_t) val1853_36), BUNSPEC);
}


/* _box-ref-key-set! */ obj_t 
_box_ref_key_set__224_ast_node(obj_t env_2972, obj_t obj_2973, obj_t val1853_2974)
{
   return box_ref_key_set__192_ast_node((box_ref_242_t) (obj_2973), val1853_2974);
}


/* box-ref-key */ obj_t 
box_ref_key_221_ast_node(box_ref_242_t obj_37)
{
   return (((box_ref_242_t) CREF(obj_37))->key);
}


/* _box-ref-key */ obj_t 
_box_ref_key_225_ast_node(obj_t env_2975, obj_t obj_2976)
{
   return box_ref_key_221_ast_node((box_ref_242_t) (obj_2976));
}


/* box-ref-var-set! */ obj_t 
box_ref_var_set__147_ast_node(box_ref_242_t obj_38, var_t val1854_39)
{
   return ((((box_ref_242_t) CREF(obj_38))->var) = ((var_t) val1854_39), BUNSPEC);
}


/* _box-ref-var-set!2507 */ obj_t 
_box_ref_var_set_2507_170_ast_node(obj_t env_2977, obj_t obj_2978, obj_t val1854_2979)
{
   return box_ref_var_set__147_ast_node((box_ref_242_t) (obj_2978), (var_t) (val1854_2979));
}


/* box-ref-var */ var_t 
box_ref_var_141_ast_node(box_ref_242_t obj_40)
{
   return (((box_ref_242_t) CREF(obj_40))->var);
}


/* _box-ref-var2508 */ obj_t 
_box_ref_var2508_88_ast_node(obj_t env_2980, obj_t obj_2981)
{
   {
      var_t aux_3914;
      aux_3914 = box_ref_var_141_ast_node((box_ref_242_t) (obj_2981));
      return (obj_t) (aux_3914);
   }
}


/* allocate-make-box */ make_box_202_t 
allocate_make_box_201_ast_node()
{
   {
      make_box_202_t new1821_870;
      new1821_870 = ((make_box_202_t) BREF(GC_MALLOC(sizeof(struct make_box_202))));
      {
	 long arg2062_871;
	 arg2062_871 = class_num_218___object(make_box_202_ast_node);
	 {
	    obj_t obj_1862;
	    obj_1862 = (obj_t) (new1821_870);
	    (((obj_t) CREF(obj_1862))->header = MAKE_HEADER(arg2062_871, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3922;
	 aux_3922 = (object_t) (new1821_870);
	 OBJECT_WIDENING_SET(aux_3922, BFALSE);
      }
      return new1821_870;
   }
}


/* _allocate-make-box */ obj_t 
_allocate_make_box_168_ast_node(obj_t env_2925)
{
   {
      make_box_202_t aux_3925;
      aux_3925 = allocate_make_box_201_ast_node();
      return (obj_t) (aux_3925);
   }
}


/* make-box? */ bool_t 
make_box__243_ast_node(obj_t obj_44)
{
   return is_a__118___object(obj_44, make_box_202_ast_node);
}


/* _make-box? */ obj_t 
_make_box__204_ast_node(obj_t env_2982, obj_t obj_2983)
{
   {
      bool_t aux_3929;
      aux_3929 = make_box__243_ast_node(obj_2983);
      return BBOOL(aux_3929);
   }
}


/* make-make-box */ make_box_202_t 
make_make_box_156_ast_node(obj_t loc_45, type_t type_46, obj_t side_effect__165_47, obj_t key_48, node_t value_49)
{
   {
      make_box_202_t new1810_1864;
      new1810_1864 = ((make_box_202_t) BREF(GC_MALLOC(sizeof(struct make_box_202))));
      {
	 long arg2063_1865;
	 arg2063_1865 = class_num_218___object(make_box_202_ast_node);
	 {
	    obj_t obj_1871;
	    obj_1871 = (obj_t) (new1810_1864);
	    (((obj_t) CREF(obj_1871))->header = MAKE_HEADER(arg2063_1865, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3936;
	 aux_3936 = (object_t) (new1810_1864);
	 OBJECT_WIDENING_SET(aux_3936, BFALSE);
      }
      ((((make_box_202_t) CREF(new1810_1864))->loc) = ((obj_t) loc_45), BUNSPEC);
      ((((make_box_202_t) CREF(new1810_1864))->type) = ((type_t) type_46), BUNSPEC);
      ((((make_box_202_t) CREF(new1810_1864))->side_effect__165) = ((obj_t) side_effect__165_47), BUNSPEC);
      ((((make_box_202_t) CREF(new1810_1864))->key) = ((obj_t) key_48), BUNSPEC);
      ((((make_box_202_t) CREF(new1810_1864))->value) = ((node_t) value_49), BUNSPEC);
      return new1810_1864;
   }
}


/* _make-make-box2509 */ obj_t 
_make_make_box2509_255_ast_node(obj_t env_2984, obj_t loc_2985, obj_t type_2986, obj_t side_effect__165_2987, obj_t key_2988, obj_t value_2989)
{
   {
      make_box_202_t aux_3944;
      aux_3944 = make_make_box_156_ast_node(loc_2985, (type_t) (type_2986), side_effect__165_2987, key_2988, (node_t) (value_2989));
      return (obj_t) (aux_3944);
   }
}


/* make-box-loc */ obj_t 
make_box_loc_202_ast_node(make_box_202_t obj_50)
{
   return (((make_box_202_t) CREF(obj_50))->loc);
}


/* _make-box-loc2510 */ obj_t 
_make_box_loc2510_15_ast_node(obj_t env_2990, obj_t obj_2991)
{
   return make_box_loc_202_ast_node((make_box_202_t) (obj_2991));
}


/* make-box-type-set! */ obj_t 
make_box_type_set__149_ast_node(make_box_202_t obj_51, type_t val1817_52)
{
   return ((((make_box_202_t) CREF(obj_51))->type) = ((type_t) val1817_52), BUNSPEC);
}


/* _make-box-type-set!2511 */ obj_t 
_make_box_type_set_2511_87_ast_node(obj_t env_2992, obj_t obj_2993, obj_t val1817_2994)
{
   return make_box_type_set__149_ast_node((make_box_202_t) (obj_2993), (type_t) (val1817_2994));
}


/* make-box-type */ type_t 
make_box_type_89_ast_node(make_box_202_t obj_53)
{
   return (((make_box_202_t) CREF(obj_53))->type);
}


/* _make-box-type2512 */ obj_t 
_make_box_type2512_97_ast_node(obj_t env_2995, obj_t obj_2996)
{
   {
      type_t aux_3957;
      aux_3957 = make_box_type_89_ast_node((make_box_202_t) (obj_2996));
      return (obj_t) (aux_3957);
   }
}


/* make-box-side-effect?-set! */ obj_t 
make_box_side_effect__set__123_ast_node(make_box_202_t obj_54, obj_t val1818_55)
{
   return ((((make_box_202_t) CREF(obj_54))->side_effect__165) = ((obj_t) val1818_55), BUNSPEC);
}


/* _make-box-side-effect?-set!2513 */ obj_t 
_make_box_side_effect__set_2513_73_ast_node(obj_t env_2997, obj_t obj_2998, obj_t val1818_2999)
{
   return make_box_side_effect__set__123_ast_node((make_box_202_t) (obj_2998), val1818_2999);
}


/* make-box-side-effect? */ obj_t 
make_box_side_effect__247_ast_node(make_box_202_t obj_56)
{
   return (((make_box_202_t) CREF(obj_56))->side_effect__165);
}


/* _make-box-side-effect?2514 */ obj_t 
_make_box_side_effect_2514_177_ast_node(obj_t env_3000, obj_t obj_3001)
{
   return make_box_side_effect__247_ast_node((make_box_202_t) (obj_3001));
}


/* make-box-key-set! */ obj_t 
make_box_key_set__183_ast_node(make_box_202_t obj_57, obj_t val1819_58)
{
   return ((((make_box_202_t) CREF(obj_57))->key) = ((obj_t) val1819_58), BUNSPEC);
}


/* _make-box-key-set! */ obj_t 
_make_box_key_set__73_ast_node(obj_t env_3002, obj_t obj_3003, obj_t val1819_3004)
{
   return make_box_key_set__183_ast_node((make_box_202_t) (obj_3003), val1819_3004);
}


/* make-box-key */ obj_t 
make_box_key_223_ast_node(make_box_202_t obj_59)
{
   return (((make_box_202_t) CREF(obj_59))->key);
}


/* _make-box-key */ obj_t 
_make_box_key_238_ast_node(obj_t env_3005, obj_t obj_3006)
{
   return make_box_key_223_ast_node((make_box_202_t) (obj_3006));
}


/* make-box-value-set! */ obj_t 
make_box_value_set__112_ast_node(make_box_202_t obj_60, node_t val1820_61)
{
   return ((((make_box_202_t) CREF(obj_60))->value) = ((node_t) val1820_61), BUNSPEC);
}


/* _make-box-value-set!2515 */ obj_t 
_make_box_value_set_2515_68_ast_node(obj_t env_3007, obj_t obj_3008, obj_t val1820_3009)
{
   return make_box_value_set__112_ast_node((make_box_202_t) (obj_3008), (node_t) (val1820_3009));
}


/* make-box-value */ node_t 
make_box_value_197_ast_node(make_box_202_t obj_62)
{
   return (((make_box_202_t) CREF(obj_62))->value);
}


/* _make-box-value2516 */ obj_t 
_make_box_value2516_193_ast_node(obj_t env_3010, obj_t obj_3011)
{
   {
      node_t aux_3978;
      aux_3978 = make_box_value_197_ast_node((make_box_202_t) (obj_3011));
      return (obj_t) (aux_3978);
   }
}


/* allocate-jump-ex-it */ jump_ex_it_184_t 
allocate_jump_ex_it_22_ast_node()
{
   {
      jump_ex_it_184_t new1791_879;
      new1791_879 = ((jump_ex_it_184_t) BREF(GC_MALLOC(sizeof(struct jump_ex_it_184))));
      {
	 long arg2064_880;
	 arg2064_880 = class_num_218___object(jump_ex_it_184_ast_node);
	 {
	    obj_t obj_1873;
	    obj_1873 = (obj_t) (new1791_879);
	    (((obj_t) CREF(obj_1873))->header = MAKE_HEADER(arg2064_880, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3986;
	 aux_3986 = (object_t) (new1791_879);
	 OBJECT_WIDENING_SET(aux_3986, BFALSE);
      }
      return new1791_879;
   }
}


/* _allocate-jump-ex-it */ obj_t 
_allocate_jump_ex_it_189_ast_node(obj_t env_2924)
{
   {
      jump_ex_it_184_t aux_3989;
      aux_3989 = allocate_jump_ex_it_22_ast_node();
      return (obj_t) (aux_3989);
   }
}


/* jump-ex-it? */ bool_t 
jump_ex_it__122_ast_node(obj_t obj_66)
{
   return is_a__118___object(obj_66, jump_ex_it_184_ast_node);
}


/* _jump-ex-it? */ obj_t 
_jump_ex_it__165_ast_node(obj_t env_3012, obj_t obj_3013)
{
   {
      bool_t aux_3993;
      aux_3993 = jump_ex_it__122_ast_node(obj_3013);
      return BBOOL(aux_3993);
   }
}


/* make-jump-ex-it */ jump_ex_it_184_t 
make_jump_ex_it_21_ast_node(obj_t loc_67, type_t type_68, node_t exit_69, node_t value_70)
{
   {
      jump_ex_it_184_t new1782_1875;
      new1782_1875 = ((jump_ex_it_184_t) BREF(GC_MALLOC(sizeof(struct jump_ex_it_184))));
      {
	 long arg2065_1876;
	 arg2065_1876 = class_num_218___object(jump_ex_it_184_ast_node);
	 {
	    obj_t obj_1881;
	    obj_1881 = (obj_t) (new1782_1875);
	    (((obj_t) CREF(obj_1881))->header = MAKE_HEADER(arg2065_1876, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4000;
	 aux_4000 = (object_t) (new1782_1875);
	 OBJECT_WIDENING_SET(aux_4000, BFALSE);
      }
      ((((jump_ex_it_184_t) CREF(new1782_1875))->loc) = ((obj_t) loc_67), BUNSPEC);
      ((((jump_ex_it_184_t) CREF(new1782_1875))->type) = ((type_t) type_68), BUNSPEC);
      ((((jump_ex_it_184_t) CREF(new1782_1875))->exit) = ((node_t) exit_69), BUNSPEC);
      ((((jump_ex_it_184_t) CREF(new1782_1875))->value) = ((node_t) value_70), BUNSPEC);
      return new1782_1875;
   }
}


/* _make-jump-ex-it2517 */ obj_t 
_make_jump_ex_it2517_208_ast_node(obj_t env_3014, obj_t loc_3015, obj_t type_3016, obj_t exit_3017, obj_t value_3018)
{
   {
      jump_ex_it_184_t aux_4007;
      aux_4007 = make_jump_ex_it_21_ast_node(loc_3015, (type_t) (type_3016), (node_t) (exit_3017), (node_t) (value_3018));
      return (obj_t) (aux_4007);
   }
}


/* jump-ex-it-loc */ obj_t 
jump_ex_it_loc_88_ast_node(jump_ex_it_184_t obj_71)
{
   return (((jump_ex_it_184_t) CREF(obj_71))->loc);
}


/* _jump-ex-it-loc2518 */ obj_t 
_jump_ex_it_loc2518_20_ast_node(obj_t env_3019, obj_t obj_3020)
{
   return jump_ex_it_loc_88_ast_node((jump_ex_it_184_t) (obj_3020));
}


/* jump-ex-it-type-set! */ obj_t 
jump_ex_it_type_set__142_ast_node(jump_ex_it_184_t obj_72, type_t val1788_73)
{
   return ((((jump_ex_it_184_t) CREF(obj_72))->type) = ((type_t) val1788_73), BUNSPEC);
}


/* _jump-ex-it-type-set!2519 */ obj_t 
_jump_ex_it_type_set_2519_242_ast_node(obj_t env_3021, obj_t obj_3022, obj_t val1788_3023)
{
   return jump_ex_it_type_set__142_ast_node((jump_ex_it_184_t) (obj_3022), (type_t) (val1788_3023));
}


/* jump-ex-it-type */ type_t 
jump_ex_it_type_39_ast_node(jump_ex_it_184_t obj_74)
{
   return (((jump_ex_it_184_t) CREF(obj_74))->type);
}


/* _jump-ex-it-type2520 */ obj_t 
_jump_ex_it_type2520_122_ast_node(obj_t env_3024, obj_t obj_3025)
{
   {
      type_t aux_4021;
      aux_4021 = jump_ex_it_type_39_ast_node((jump_ex_it_184_t) (obj_3025));
      return (obj_t) (aux_4021);
   }
}


/* jump-ex-it-exit-set! */ obj_t 
jump_ex_it_exit_set__84_ast_node(jump_ex_it_184_t obj_75, node_t val1789_76)
{
   return ((((jump_ex_it_184_t) CREF(obj_75))->exit) = ((node_t) val1789_76), BUNSPEC);
}


/* _jump-ex-it-exit-set!2521 */ obj_t 
_jump_ex_it_exit_set_2521_158_ast_node(obj_t env_3026, obj_t obj_3027, obj_t val1789_3028)
{
   return jump_ex_it_exit_set__84_ast_node((jump_ex_it_184_t) (obj_3027), (node_t) (val1789_3028));
}


/* jump-ex-it-exit */ node_t 
jump_ex_it_exit_9_ast_node(jump_ex_it_184_t obj_77)
{
   return (((jump_ex_it_184_t) CREF(obj_77))->exit);
}


/* _jump-ex-it-exit2522 */ obj_t 
_jump_ex_it_exit2522_236_ast_node(obj_t env_3029, obj_t obj_3030)
{
   {
      node_t aux_4030;
      aux_4030 = jump_ex_it_exit_9_ast_node((jump_ex_it_184_t) (obj_3030));
      return (obj_t) (aux_4030);
   }
}


/* jump-ex-it-value-set! */ obj_t 
jump_ex_it_value_set__158_ast_node(jump_ex_it_184_t obj_78, node_t val1790_79)
{
   return ((((jump_ex_it_184_t) CREF(obj_78))->value) = ((node_t) val1790_79), BUNSPEC);
}


/* _jump-ex-it-value-set!2523 */ obj_t 
_jump_ex_it_value_set_2523_69_ast_node(obj_t env_3031, obj_t obj_3032, obj_t val1790_3033)
{
   return jump_ex_it_value_set__158_ast_node((jump_ex_it_184_t) (obj_3032), (node_t) (val1790_3033));
}


/* jump-ex-it-value */ node_t 
jump_ex_it_value_145_ast_node(jump_ex_it_184_t obj_80)
{
   return (((jump_ex_it_184_t) CREF(obj_80))->value);
}


/* _jump-ex-it-value2524 */ obj_t 
_jump_ex_it_value2524_58_ast_node(obj_t env_3034, obj_t obj_3035)
{
   {
      node_t aux_4039;
      aux_4039 = jump_ex_it_value_145_ast_node((jump_ex_it_184_t) (obj_3035));
      return (obj_t) (aux_4039);
   }
}


/* allocate-set-ex-it */ set_ex_it_116_t 
allocate_set_ex_it_57_ast_node()
{
   {
      set_ex_it_116_t new1762_887;
      new1762_887 = ((set_ex_it_116_t) BREF(GC_MALLOC(sizeof(struct set_ex_it_116))));
      {
	 long arg2067_888;
	 arg2067_888 = class_num_218___object(set_ex_it_116_ast_node);
	 {
	    obj_t obj_1883;
	    obj_1883 = (obj_t) (new1762_887);
	    (((obj_t) CREF(obj_1883))->header = MAKE_HEADER(arg2067_888, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4047;
	 aux_4047 = (object_t) (new1762_887);
	 OBJECT_WIDENING_SET(aux_4047, BFALSE);
      }
      return new1762_887;
   }
}


/* _allocate-set-ex-it */ obj_t 
_allocate_set_ex_it_70_ast_node(obj_t env_2923)
{
   {
      set_ex_it_116_t aux_4050;
      aux_4050 = allocate_set_ex_it_57_ast_node();
      return (obj_t) (aux_4050);
   }
}


/* set-ex-it? */ bool_t 
set_ex_it__46_ast_node(obj_t obj_84)
{
   return is_a__118___object(obj_84, set_ex_it_116_ast_node);
}


/* _set-ex-it? */ obj_t 
_set_ex_it__35_ast_node(obj_t env_3036, obj_t obj_3037)
{
   {
      bool_t aux_4054;
      aux_4054 = set_ex_it__46_ast_node(obj_3037);
      return BBOOL(aux_4054);
   }
}


/* make-set-ex-it */ set_ex_it_116_t 
make_set_ex_it_81_ast_node(obj_t loc_85, type_t type_86, var_t var_87, node_t body_88)
{
   {
      set_ex_it_116_t new1753_1885;
      new1753_1885 = ((set_ex_it_116_t) BREF(GC_MALLOC(sizeof(struct set_ex_it_116))));
      {
	 long arg2068_1886;
	 arg2068_1886 = class_num_218___object(set_ex_it_116_ast_node);
	 {
	    obj_t obj_1891;
	    obj_1891 = (obj_t) (new1753_1885);
	    (((obj_t) CREF(obj_1891))->header = MAKE_HEADER(arg2068_1886, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4061;
	 aux_4061 = (object_t) (new1753_1885);
	 OBJECT_WIDENING_SET(aux_4061, BFALSE);
      }
      ((((set_ex_it_116_t) CREF(new1753_1885))->loc) = ((obj_t) loc_85), BUNSPEC);
      ((((set_ex_it_116_t) CREF(new1753_1885))->type) = ((type_t) type_86), BUNSPEC);
      ((((set_ex_it_116_t) CREF(new1753_1885))->var) = ((var_t) var_87), BUNSPEC);
      ((((set_ex_it_116_t) CREF(new1753_1885))->body) = ((node_t) body_88), BUNSPEC);
      return new1753_1885;
   }
}


/* _make-set-ex-it2525 */ obj_t 
_make_set_ex_it2525_29_ast_node(obj_t env_3038, obj_t loc_3039, obj_t type_3040, obj_t var_3041, obj_t body_3042)
{
   {
      set_ex_it_116_t aux_4068;
      aux_4068 = make_set_ex_it_81_ast_node(loc_3039, (type_t) (type_3040), (var_t) (var_3041), (node_t) (body_3042));
      return (obj_t) (aux_4068);
   }
}


/* set-ex-it-loc */ obj_t 
set_ex_it_loc_71_ast_node(set_ex_it_116_t obj_89)
{
   return (((set_ex_it_116_t) CREF(obj_89))->loc);
}


/* _set-ex-it-loc2526 */ obj_t 
_set_ex_it_loc2526_190_ast_node(obj_t env_3043, obj_t obj_3044)
{
   return set_ex_it_loc_71_ast_node((set_ex_it_116_t) (obj_3044));
}


/* set-ex-it-type-set! */ obj_t 
set_ex_it_type_set__207_ast_node(set_ex_it_116_t obj_90, type_t val1759_91)
{
   return ((((set_ex_it_116_t) CREF(obj_90))->type) = ((type_t) val1759_91), BUNSPEC);
}


/* _set-ex-it-type-set!2527 */ obj_t 
_set_ex_it_type_set_2527_157_ast_node(obj_t env_3045, obj_t obj_3046, obj_t val1759_3047)
{
   return set_ex_it_type_set__207_ast_node((set_ex_it_116_t) (obj_3046), (type_t) (val1759_3047));
}


/* set-ex-it-type */ type_t 
set_ex_it_type_46_ast_node(set_ex_it_116_t obj_92)
{
   return (((set_ex_it_116_t) CREF(obj_92))->type);
}


/* _set-ex-it-type2528 */ obj_t 
_set_ex_it_type2528_118_ast_node(obj_t env_3048, obj_t obj_3049)
{
   {
      type_t aux_4082;
      aux_4082 = set_ex_it_type_46_ast_node((set_ex_it_116_t) (obj_3049));
      return (obj_t) (aux_4082);
   }
}


/* set-ex-it-var-set! */ obj_t 
set_ex_it_var_set__67_ast_node(set_ex_it_116_t obj_93, var_t val1760_94)
{
   return ((((set_ex_it_116_t) CREF(obj_93))->var) = ((var_t) val1760_94), BUNSPEC);
}


/* _set-ex-it-var-set!2529 */ obj_t 
_set_ex_it_var_set_2529_51_ast_node(obj_t env_3050, obj_t obj_3051, obj_t val1760_3052)
{
   return set_ex_it_var_set__67_ast_node((set_ex_it_116_t) (obj_3051), (var_t) (val1760_3052));
}


/* set-ex-it-var */ var_t 
set_ex_it_var_31_ast_node(set_ex_it_116_t obj_95)
{
   return (((set_ex_it_116_t) CREF(obj_95))->var);
}


/* _set-ex-it-var2530 */ obj_t 
_set_ex_it_var2530_147_ast_node(obj_t env_3053, obj_t obj_3054)
{
   {
      var_t aux_4091;
      aux_4091 = set_ex_it_var_31_ast_node((set_ex_it_116_t) (obj_3054));
      return (obj_t) (aux_4091);
   }
}


/* set-ex-it-body-set! */ obj_t 
set_ex_it_body_set__234_ast_node(set_ex_it_116_t obj_96, node_t val1761_97)
{
   return ((((set_ex_it_116_t) CREF(obj_96))->body) = ((node_t) val1761_97), BUNSPEC);
}


/* _set-ex-it-body-set!2531 */ obj_t 
_set_ex_it_body_set_2531_199_ast_node(obj_t env_3055, obj_t obj_3056, obj_t val1761_3057)
{
   return set_ex_it_body_set__234_ast_node((set_ex_it_116_t) (obj_3056), (node_t) (val1761_3057));
}


/* set-ex-it-body */ node_t 
set_ex_it_body_246_ast_node(set_ex_it_116_t obj_98)
{
   return (((set_ex_it_116_t) CREF(obj_98))->body);
}


/* _set-ex-it-body2532 */ obj_t 
_set_ex_it_body2532_170_ast_node(obj_t env_3058, obj_t obj_3059)
{
   {
      node_t aux_4100;
      aux_4100 = set_ex_it_body_246_ast_node((set_ex_it_116_t) (obj_3059));
      return (obj_t) (aux_4100);
   }
}


/* allocate-let-var */ let_var_6_t 
allocate_let_var_32_ast_node()
{
   {
      let_var_6_t new1722_895;
      new1722_895 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
      {
	 long arg2069_896;
	 arg2069_896 = class_num_218___object(let_var_6_ast_node);
	 {
	    obj_t obj_1893;
	    obj_1893 = (obj_t) (new1722_895);
	    (((obj_t) CREF(obj_1893))->header = MAKE_HEADER(arg2069_896, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4108;
	 aux_4108 = (object_t) (new1722_895);
	 OBJECT_WIDENING_SET(aux_4108, BFALSE);
      }
      return new1722_895;
   }
}


/* _allocate-let-var */ obj_t 
_allocate_let_var_179_ast_node(obj_t env_2922)
{
   {
      let_var_6_t aux_4111;
      aux_4111 = allocate_let_var_32_ast_node();
      return (obj_t) (aux_4111);
   }
}


/* let-var? */ bool_t 
let_var__167_ast_node(obj_t obj_102)
{
   return is_a__118___object(obj_102, let_var_6_ast_node);
}


/* _let-var? */ obj_t 
_let_var__141_ast_node(obj_t env_3060, obj_t obj_3061)
{
   {
      bool_t aux_4115;
      aux_4115 = let_var__167_ast_node(obj_3061);
      return BBOOL(aux_4115);
   }
}


/* make-let-var */ let_var_6_t 
make_let_var_217_ast_node(obj_t loc_103, type_t type_104, obj_t side_effect__165_105, obj_t key_106, obj_t bindings_107, node_t body_108, bool_t removable__42_109)
{
   {
      let_var_6_t new1707_1895;
      new1707_1895 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
      {
	 long arg2070_1896;
	 arg2070_1896 = class_num_218___object(let_var_6_ast_node);
	 {
	    obj_t obj_1904;
	    obj_1904 = (obj_t) (new1707_1895);
	    (((obj_t) CREF(obj_1904))->header = MAKE_HEADER(arg2070_1896, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4122;
	 aux_4122 = (object_t) (new1707_1895);
	 OBJECT_WIDENING_SET(aux_4122, BFALSE);
      }
      ((((let_var_6_t) CREF(new1707_1895))->loc) = ((obj_t) loc_103), BUNSPEC);
      ((((let_var_6_t) CREF(new1707_1895))->type) = ((type_t) type_104), BUNSPEC);
      ((((let_var_6_t) CREF(new1707_1895))->side_effect__165) = ((obj_t) side_effect__165_105), BUNSPEC);
      ((((let_var_6_t) CREF(new1707_1895))->key) = ((obj_t) key_106), BUNSPEC);
      ((((let_var_6_t) CREF(new1707_1895))->bindings) = ((obj_t) bindings_107), BUNSPEC);
      ((((let_var_6_t) CREF(new1707_1895))->body) = ((node_t) body_108), BUNSPEC);
      ((((let_var_6_t) CREF(new1707_1895))->removable__42) = ((bool_t) removable__42_109), BUNSPEC);
      return new1707_1895;
   }
}


/* _make-let-var2533 */ obj_t 
_make_let_var2533_130_ast_node(obj_t env_3062, obj_t loc_3063, obj_t type_3064, obj_t side_effect__165_3065, obj_t key_3066, obj_t bindings_3067, obj_t body_3068, obj_t removable__42_3069)
{
   {
      let_var_6_t aux_4132;
      aux_4132 = make_let_var_217_ast_node(loc_3063, (type_t) (type_3064), side_effect__165_3065, key_3066, bindings_3067, (node_t) (body_3068), CBOOL(removable__42_3069));
      return (obj_t) (aux_4132);
   }
}


/* let-var-loc */ obj_t 
let_var_loc_249_ast_node(let_var_6_t obj_110)
{
   return (((let_var_6_t) CREF(obj_110))->loc);
}


/* _let-var-loc2534 */ obj_t 
_let_var_loc2534_1_ast_node(obj_t env_3070, obj_t obj_3071)
{
   return let_var_loc_249_ast_node((let_var_6_t) (obj_3071));
}


/* let-var-type-set! */ obj_t 
let_var_type_set__107_ast_node(let_var_6_t obj_111, type_t val1716_112)
{
   return ((((let_var_6_t) CREF(obj_111))->type) = ((type_t) val1716_112), BUNSPEC);
}


/* _let-var-type-set!2535 */ obj_t 
_let_var_type_set_2535_18_ast_node(obj_t env_3072, obj_t obj_3073, obj_t val1716_3074)
{
   return let_var_type_set__107_ast_node((let_var_6_t) (obj_3073), (type_t) (val1716_3074));
}


/* let-var-type */ type_t 
let_var_type_128_ast_node(let_var_6_t obj_113)
{
   return (((let_var_6_t) CREF(obj_113))->type);
}


/* _let-var-type2536 */ obj_t 
_let_var_type2536_61_ast_node(obj_t env_3075, obj_t obj_3076)
{
   {
      type_t aux_4146;
      aux_4146 = let_var_type_128_ast_node((let_var_6_t) (obj_3076));
      return (obj_t) (aux_4146);
   }
}


/* let-var-side-effect?-set! */ obj_t 
let_var_side_effect__set__111_ast_node(let_var_6_t obj_114, obj_t val1717_115)
{
   return ((((let_var_6_t) CREF(obj_114))->side_effect__165) = ((obj_t) val1717_115), BUNSPEC);
}


/* _let-var-side-effect?-set!2537 */ obj_t 
_let_var_side_effect__set_2537_236_ast_node(obj_t env_3077, obj_t obj_3078, obj_t val1717_3079)
{
   return let_var_side_effect__set__111_ast_node((let_var_6_t) (obj_3078), val1717_3079);
}


/* let-var-side-effect? */ obj_t 
let_var_side_effect__154_ast_node(let_var_6_t obj_116)
{
   return (((let_var_6_t) CREF(obj_116))->side_effect__165);
}


/* _let-var-side-effect?2538 */ obj_t 
_let_var_side_effect_2538_65_ast_node(obj_t env_3080, obj_t obj_3081)
{
   return let_var_side_effect__154_ast_node((let_var_6_t) (obj_3081));
}


/* let-var-key-set! */ obj_t 
let_var_key_set__86_ast_node(let_var_6_t obj_117, obj_t val1718_118)
{
   return ((((let_var_6_t) CREF(obj_117))->key) = ((obj_t) val1718_118), BUNSPEC);
}


/* _let-var-key-set! */ obj_t 
_let_var_key_set__226_ast_node(obj_t env_3082, obj_t obj_3083, obj_t val1718_3084)
{
   return let_var_key_set__86_ast_node((let_var_6_t) (obj_3083), val1718_3084);
}


/* let-var-key */ obj_t 
let_var_key_52_ast_node(let_var_6_t obj_119)
{
   return (((let_var_6_t) CREF(obj_119))->key);
}


/* _let-var-key */ obj_t 
_let_var_key_202_ast_node(obj_t env_3085, obj_t obj_3086)
{
   return let_var_key_52_ast_node((let_var_6_t) (obj_3086));
}


/* let-var-bindings-set! */ obj_t 
let_var_bindings_set__143_ast_node(let_var_6_t obj_120, obj_t val1719_121)
{
   return ((((let_var_6_t) CREF(obj_120))->bindings) = ((obj_t) val1719_121), BUNSPEC);
}


/* _let-var-bindings-set!2539 */ obj_t 
_let_var_bindings_set_2539_217_ast_node(obj_t env_3087, obj_t obj_3088, obj_t val1719_3089)
{
   return let_var_bindings_set__143_ast_node((let_var_6_t) (obj_3088), val1719_3089);
}


/* let-var-bindings */ obj_t 
let_var_bindings_42_ast_node(let_var_6_t obj_122)
{
   return (((let_var_6_t) CREF(obj_122))->bindings);
}


/* _let-var-bindings2540 */ obj_t 
_let_var_bindings2540_152_ast_node(obj_t env_3090, obj_t obj_3091)
{
   return let_var_bindings_42_ast_node((let_var_6_t) (obj_3091));
}


/* let-var-body-set! */ obj_t 
let_var_body_set__15_ast_node(let_var_6_t obj_123, node_t val1720_124)
{
   return ((((let_var_6_t) CREF(obj_123))->body) = ((node_t) val1720_124), BUNSPEC);
}


/* _let-var-body-set!2541 */ obj_t 
_let_var_body_set_2541_175_ast_node(obj_t env_3092, obj_t obj_3093, obj_t val1720_3094)
{
   return let_var_body_set__15_ast_node((let_var_6_t) (obj_3093), (node_t) (val1720_3094));
}


/* let-var-body */ node_t 
let_var_body_232_ast_node(let_var_6_t obj_125)
{
   return (((let_var_6_t) CREF(obj_125))->body);
}


/* _let-var-body2542 */ obj_t 
_let_var_body2542_190_ast_node(obj_t env_3095, obj_t obj_3096)
{
   {
      node_t aux_4173;
      aux_4173 = let_var_body_232_ast_node((let_var_6_t) (obj_3096));
      return (obj_t) (aux_4173);
   }
}


/* let-var-removable?-set! */ obj_t 
let_var_removable__set__39_ast_node(let_var_6_t obj_126, bool_t val1721_127)
{
   return ((((let_var_6_t) CREF(obj_126))->removable__42) = ((bool_t) val1721_127), BUNSPEC);
}


/* _let-var-removable?-set!2543 */ obj_t 
_let_var_removable__set_2543_208_ast_node(obj_t env_3097, obj_t obj_3098, obj_t val1721_3099)
{
   return let_var_removable__set__39_ast_node((let_var_6_t) (obj_3098), CBOOL(val1721_3099));
}


/* let-var-removable? */ bool_t 
let_var_removable__69_ast_node(let_var_6_t obj_128)
{
   return (((let_var_6_t) CREF(obj_128))->removable__42);
}


/* _let-var-removable?2544 */ obj_t 
_let_var_removable_2544_155_ast_node(obj_t env_3100, obj_t obj_3101)
{
   {
      bool_t aux_4182;
      aux_4182 = let_var_removable__69_ast_node((let_var_6_t) (obj_3101));
      return BBOOL(aux_4182);
   }
}


/* allocate-let-fun */ let_fun_218_t 
allocate_let_fun_35_ast_node()
{
   {
      let_fun_218_t new1680_906;
      new1680_906 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
      {
	 long arg2071_907;
	 arg2071_907 = class_num_218___object(let_fun_218_ast_node);
	 {
	    obj_t obj_1906;
	    obj_1906 = (obj_t) (new1680_906);
	    (((obj_t) CREF(obj_1906))->header = MAKE_HEADER(arg2071_907, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4190;
	 aux_4190 = (object_t) (new1680_906);
	 OBJECT_WIDENING_SET(aux_4190, BFALSE);
      }
      return new1680_906;
   }
}


/* _allocate-let-fun */ obj_t 
_allocate_let_fun_123_ast_node(obj_t env_2921)
{
   {
      let_fun_218_t aux_4193;
      aux_4193 = allocate_let_fun_35_ast_node();
      return (obj_t) (aux_4193);
   }
}


/* let-fun? */ bool_t 
let_fun__0_ast_node(obj_t obj_132)
{
   return is_a__118___object(obj_132, let_fun_218_ast_node);
}


/* _let-fun? */ obj_t 
_let_fun__236_ast_node(obj_t env_3102, obj_t obj_3103)
{
   {
      bool_t aux_4197;
      aux_4197 = let_fun__0_ast_node(obj_3103);
      return BBOOL(aux_4197);
   }
}


/* make-let-fun */ let_fun_218_t 
make_let_fun_154_ast_node(obj_t loc_133, type_t type_134, obj_t side_effect__165_135, obj_t key_136, obj_t locals_137, node_t body_138)
{
   {
      let_fun_218_t new1667_1908;
      new1667_1908 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
      {
	 long arg2072_1909;
	 arg2072_1909 = class_num_218___object(let_fun_218_ast_node);
	 {
	    obj_t obj_1916;
	    obj_1916 = (obj_t) (new1667_1908);
	    (((obj_t) CREF(obj_1916))->header = MAKE_HEADER(arg2072_1909, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4204;
	 aux_4204 = (object_t) (new1667_1908);
	 OBJECT_WIDENING_SET(aux_4204, BFALSE);
      }
      ((((let_fun_218_t) CREF(new1667_1908))->loc) = ((obj_t) loc_133), BUNSPEC);
      ((((let_fun_218_t) CREF(new1667_1908))->type) = ((type_t) type_134), BUNSPEC);
      ((((let_fun_218_t) CREF(new1667_1908))->side_effect__165) = ((obj_t) side_effect__165_135), BUNSPEC);
      ((((let_fun_218_t) CREF(new1667_1908))->key) = ((obj_t) key_136), BUNSPEC);
      ((((let_fun_218_t) CREF(new1667_1908))->locals) = ((obj_t) locals_137), BUNSPEC);
      ((((let_fun_218_t) CREF(new1667_1908))->body) = ((node_t) body_138), BUNSPEC);
      return new1667_1908;
   }
}


/* _make-let-fun2545 */ obj_t 
_make_let_fun2545_205_ast_node(obj_t env_3104, obj_t loc_3105, obj_t type_3106, obj_t side_effect__165_3107, obj_t key_3108, obj_t locals_3109, obj_t body_3110)
{
   {
      let_fun_218_t aux_4213;
      aux_4213 = make_let_fun_154_ast_node(loc_3105, (type_t) (type_3106), side_effect__165_3107, key_3108, locals_3109, (node_t) (body_3110));
      return (obj_t) (aux_4213);
   }
}


/* let-fun-loc */ obj_t 
let_fun_loc_207_ast_node(let_fun_218_t obj_139)
{
   return (((let_fun_218_t) CREF(obj_139))->loc);
}


/* _let-fun-loc2546 */ obj_t 
_let_fun_loc2546_121_ast_node(obj_t env_3111, obj_t obj_3112)
{
   return let_fun_loc_207_ast_node((let_fun_218_t) (obj_3112));
}


/* let-fun-type-set! */ obj_t 
let_fun_type_set__1_ast_node(let_fun_218_t obj_140, type_t val1675_141)
{
   return ((((let_fun_218_t) CREF(obj_140))->type) = ((type_t) val1675_141), BUNSPEC);
}


/* _let-fun-type-set!2547 */ obj_t 
_let_fun_type_set_2547_72_ast_node(obj_t env_3113, obj_t obj_3114, obj_t val1675_3115)
{
   return let_fun_type_set__1_ast_node((let_fun_218_t) (obj_3114), (type_t) (val1675_3115));
}


/* let-fun-type */ type_t 
let_fun_type_250_ast_node(let_fun_218_t obj_142)
{
   return (((let_fun_218_t) CREF(obj_142))->type);
}


/* _let-fun-type2548 */ obj_t 
_let_fun_type2548_212_ast_node(obj_t env_3116, obj_t obj_3117)
{
   {
      type_t aux_4226;
      aux_4226 = let_fun_type_250_ast_node((let_fun_218_t) (obj_3117));
      return (obj_t) (aux_4226);
   }
}


/* let-fun-side-effect?-set! */ obj_t 
let_fun_side_effect__set__106_ast_node(let_fun_218_t obj_143, obj_t val1676_144)
{
   return ((((let_fun_218_t) CREF(obj_143))->side_effect__165) = ((obj_t) val1676_144), BUNSPEC);
}


/* _let-fun-side-effect?-set!2549 */ obj_t 
_let_fun_side_effect__set_2549_170_ast_node(obj_t env_3118, obj_t obj_3119, obj_t val1676_3120)
{
   return let_fun_side_effect__set__106_ast_node((let_fun_218_t) (obj_3119), val1676_3120);
}


/* let-fun-side-effect? */ obj_t 
let_fun_side_effect__189_ast_node(let_fun_218_t obj_145)
{
   return (((let_fun_218_t) CREF(obj_145))->side_effect__165);
}


/* _let-fun-side-effect?2550 */ obj_t 
_let_fun_side_effect_2550_53_ast_node(obj_t env_3121, obj_t obj_3122)
{
   return let_fun_side_effect__189_ast_node((let_fun_218_t) (obj_3122));
}


/* let-fun-key-set! */ obj_t 
let_fun_key_set__227_ast_node(let_fun_218_t obj_146, obj_t val1677_147)
{
   return ((((let_fun_218_t) CREF(obj_146))->key) = ((obj_t) val1677_147), BUNSPEC);
}


/* _let-fun-key-set! */ obj_t 
_let_fun_key_set__133_ast_node(obj_t env_3123, obj_t obj_3124, obj_t val1677_3125)
{
   return let_fun_key_set__227_ast_node((let_fun_218_t) (obj_3124), val1677_3125);
}


/* let-fun-key */ obj_t 
let_fun_key_253_ast_node(let_fun_218_t obj_148)
{
   return (((let_fun_218_t) CREF(obj_148))->key);
}


/* _let-fun-key */ obj_t 
_let_fun_key_252_ast_node(obj_t env_3126, obj_t obj_3127)
{
   return let_fun_key_253_ast_node((let_fun_218_t) (obj_3127));
}


/* let-fun-locals-set! */ obj_t 
let_fun_locals_set__199_ast_node(let_fun_218_t obj_149, obj_t val1678_150)
{
   return ((((let_fun_218_t) CREF(obj_149))->locals) = ((obj_t) val1678_150), BUNSPEC);
}


/* _let-fun-locals-set!2551 */ obj_t 
_let_fun_locals_set_2551_38_ast_node(obj_t env_3128, obj_t obj_3129, obj_t val1678_3130)
{
   return let_fun_locals_set__199_ast_node((let_fun_218_t) (obj_3129), val1678_3130);
}


/* let-fun-locals */ obj_t 
let_fun_locals_116_ast_node(let_fun_218_t obj_151)
{
   return (((let_fun_218_t) CREF(obj_151))->locals);
}


/* _let-fun-locals2552 */ obj_t 
_let_fun_locals2552_73_ast_node(obj_t env_3131, obj_t obj_3132)
{
   return let_fun_locals_116_ast_node((let_fun_218_t) (obj_3132));
}


/* let-fun-body-set! */ obj_t 
let_fun_body_set__147_ast_node(let_fun_218_t obj_152, node_t val1679_153)
{
   return ((((let_fun_218_t) CREF(obj_152))->body) = ((node_t) val1679_153), BUNSPEC);
}


/* _let-fun-body-set!2553 */ obj_t 
_let_fun_body_set_2553_147_ast_node(obj_t env_3133, obj_t obj_3134, obj_t val1679_3135)
{
   return let_fun_body_set__147_ast_node((let_fun_218_t) (obj_3134), (node_t) (val1679_3135));
}


/* let-fun-body */ node_t 
let_fun_body_141_ast_node(let_fun_218_t obj_154)
{
   return (((let_fun_218_t) CREF(obj_154))->body);
}


/* _let-fun-body2554 */ obj_t 
_let_fun_body2554_75_ast_node(obj_t env_3136, obj_t obj_3137)
{
   {
      node_t aux_4253;
      aux_4253 = let_fun_body_141_ast_node((let_fun_218_t) (obj_3137));
      return (obj_t) (aux_4253);
   }
}


/* allocate-select */ select_t 
allocate_select_194_ast_node()
{
   {
      select_t new1636_916;
      new1636_916 = ((select_t) BREF(GC_MALLOC(sizeof(struct select))));
      {
	 long arg2073_917;
	 arg2073_917 = class_num_218___object(select_ast_node);
	 {
	    obj_t obj_1918;
	    obj_1918 = (obj_t) (new1636_916);
	    (((obj_t) CREF(obj_1918))->header = MAKE_HEADER(arg2073_917, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4261;
	 aux_4261 = (object_t) (new1636_916);
	 OBJECT_WIDENING_SET(aux_4261, BFALSE);
      }
      return new1636_916;
   }
}


/* _allocate-select */ obj_t 
_allocate_select_101_ast_node(obj_t env_2920)
{
   {
      select_t aux_4264;
      aux_4264 = allocate_select_194_ast_node();
      return (obj_t) (aux_4264);
   }
}


/* select? */ bool_t 
select__208_ast_node(obj_t obj_158)
{
   return is_a__118___object(obj_158, select_ast_node);
}


/* _select? */ obj_t 
_select__4_ast_node(obj_t env_3138, obj_t obj_3139)
{
   {
      bool_t aux_4268;
      aux_4268 = select__208_ast_node(obj_3139);
      return BBOOL(aux_4268);
   }
}


/* make-select */ select_t 
make_select_245_ast_node(obj_t loc_159, type_t type_160, obj_t side_effect__165_161, obj_t key_162, node_t test_163, obj_t clauses_164, type_t item_type_130_165)
{
   {
      select_t new1623_1920;
      new1623_1920 = ((select_t) BREF(GC_MALLOC(sizeof(struct select))));
      {
	 long arg2074_1921;
	 arg2074_1921 = class_num_218___object(select_ast_node);
	 {
	    obj_t obj_1929;
	    obj_1929 = (obj_t) (new1623_1920);
	    (((obj_t) CREF(obj_1929))->header = MAKE_HEADER(arg2074_1921, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4275;
	 aux_4275 = (object_t) (new1623_1920);
	 OBJECT_WIDENING_SET(aux_4275, BFALSE);
      }
      ((((select_t) CREF(new1623_1920))->loc) = ((obj_t) loc_159), BUNSPEC);
      ((((select_t) CREF(new1623_1920))->type) = ((type_t) type_160), BUNSPEC);
      ((((select_t) CREF(new1623_1920))->side_effect__165) = ((obj_t) side_effect__165_161), BUNSPEC);
      ((((select_t) CREF(new1623_1920))->key) = ((obj_t) key_162), BUNSPEC);
      ((((select_t) CREF(new1623_1920))->test) = ((node_t) test_163), BUNSPEC);
      ((((select_t) CREF(new1623_1920))->clauses) = ((obj_t) clauses_164), BUNSPEC);
      ((((select_t) CREF(new1623_1920))->item_type_130) = ((type_t) item_type_130_165), BUNSPEC);
      return new1623_1920;
   }
}


/* _make-select2555 */ obj_t 
_make_select2555_239_ast_node(obj_t env_3140, obj_t loc_3141, obj_t type_3142, obj_t side_effect__165_3143, obj_t key_3144, obj_t test_3145, obj_t clauses_3146, obj_t item_type_130_3147)
{
   {
      select_t aux_4285;
      aux_4285 = make_select_245_ast_node(loc_3141, (type_t) (type_3142), side_effect__165_3143, key_3144, (node_t) (test_3145), clauses_3146, (type_t) (item_type_130_3147));
      return (obj_t) (aux_4285);
   }
}


/* select-loc */ obj_t 
select_loc_168_ast_node(select_t obj_166)
{
   return (((select_t) CREF(obj_166))->loc);
}


/* _select-loc2556 */ obj_t 
_select_loc2556_23_ast_node(obj_t env_3148, obj_t obj_3149)
{
   return select_loc_168_ast_node((select_t) (obj_3149));
}


/* select-type-set! */ obj_t 
select_type_set__138_ast_node(select_t obj_167, type_t val1632_168)
{
   return ((((select_t) CREF(obj_167))->type) = ((type_t) val1632_168), BUNSPEC);
}


/* _select-type-set!2557 */ obj_t 
_select_type_set_2557_134_ast_node(obj_t env_3150, obj_t obj_3151, obj_t val1632_3152)
{
   return select_type_set__138_ast_node((select_t) (obj_3151), (type_t) (val1632_3152));
}


/* select-type */ type_t 
select_type_6_ast_node(select_t obj_169)
{
   return (((select_t) CREF(obj_169))->type);
}


/* _select-type2558 */ obj_t 
_select_type2558_223_ast_node(obj_t env_3153, obj_t obj_3154)
{
   {
      type_t aux_4299;
      aux_4299 = select_type_6_ast_node((select_t) (obj_3154));
      return (obj_t) (aux_4299);
   }
}


/* select-side-effect?-set! */ obj_t 
select_side_effect__set__210_ast_node(select_t obj_170, obj_t val1633_171)
{
   return ((((select_t) CREF(obj_170))->side_effect__165) = ((obj_t) val1633_171), BUNSPEC);
}


/* _select-side-effect?-set!2559 */ obj_t 
_select_side_effect__set_2559_195_ast_node(obj_t env_3155, obj_t obj_3156, obj_t val1633_3157)
{
   return select_side_effect__set__210_ast_node((select_t) (obj_3156), val1633_3157);
}


/* select-side-effect? */ obj_t 
select_side_effect__205_ast_node(select_t obj_172)
{
   return (((select_t) CREF(obj_172))->side_effect__165);
}


/* _select-side-effect?2560 */ obj_t 
_select_side_effect_2560_103_ast_node(obj_t env_3158, obj_t obj_3159)
{
   return select_side_effect__205_ast_node((select_t) (obj_3159));
}


/* select-key-set! */ obj_t 
select_key_set__149_ast_node(select_t obj_173, obj_t val1634_174)
{
   return ((((select_t) CREF(obj_173))->key) = ((obj_t) val1634_174), BUNSPEC);
}


/* _select-key-set! */ obj_t 
_select_key_set__222_ast_node(obj_t env_3160, obj_t obj_3161, obj_t val1634_3162)
{
   return select_key_set__149_ast_node((select_t) (obj_3161), val1634_3162);
}


/* select-key */ obj_t 
select_key_89_ast_node(select_t obj_175)
{
   return (((select_t) CREF(obj_175))->key);
}


/* _select-key */ obj_t 
_select_key_153_ast_node(obj_t env_3163, obj_t obj_3164)
{
   return select_key_89_ast_node((select_t) (obj_3164));
}


/* select-test-set! */ obj_t 
select_test_set__37_ast_node(select_t obj_176, node_t val1635_177)
{
   return ((((select_t) CREF(obj_176))->test) = ((node_t) val1635_177), BUNSPEC);
}


/* _select-test-set!2561 */ obj_t 
_select_test_set_2561_102_ast_node(obj_t env_3165, obj_t obj_3166, obj_t val1635_3167)
{
   return select_test_set__37_ast_node((select_t) (obj_3166), (node_t) (val1635_3167));
}


/* select-test */ node_t 
select_test_184_ast_node(select_t obj_178)
{
   return (((select_t) CREF(obj_178))->test);
}


/* _select-test2562 */ obj_t 
_select_test2562_140_ast_node(obj_t env_3168, obj_t obj_3169)
{
   {
      node_t aux_4320;
      aux_4320 = select_test_184_ast_node((select_t) (obj_3169));
      return (obj_t) (aux_4320);
   }
}


/* select-clauses */ obj_t 
select_clauses_248_ast_node(select_t obj_179)
{
   return (((select_t) CREF(obj_179))->clauses);
}


/* _select-clauses2563 */ obj_t 
_select_clauses2563_85_ast_node(obj_t env_3170, obj_t obj_3171)
{
   return select_clauses_248_ast_node((select_t) (obj_3171));
}


/* select-item-type */ type_t 
select_item_type_206_ast_node(select_t obj_180)
{
   return (((select_t) CREF(obj_180))->item_type_130);
}


/* _select-item-type2564 */ obj_t 
_select_item_type2564_114_ast_node(obj_t env_3172, obj_t obj_3173)
{
   {
      type_t aux_4328;
      aux_4328 = select_item_type_206_ast_node((select_t) (obj_3173));
      return (obj_t) (aux_4328);
   }
}


/* allocate-fail */ fail_t 
allocate_fail_46_ast_node()
{
   {
      fail_t new1600_927;
      new1600_927 = ((fail_t) BREF(GC_MALLOC(sizeof(struct fail))));
      {
	 long arg2075_928;
	 arg2075_928 = class_num_218___object(fail_ast_node);
	 {
	    obj_t obj_1931;
	    obj_1931 = (obj_t) (new1600_927);
	    (((obj_t) CREF(obj_1931))->header = MAKE_HEADER(arg2075_928, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4336;
	 aux_4336 = (object_t) (new1600_927);
	 OBJECT_WIDENING_SET(aux_4336, BFALSE);
      }
      return new1600_927;
   }
}


/* _allocate-fail */ obj_t 
_allocate_fail_214_ast_node(obj_t env_2919)
{
   {
      fail_t aux_4339;
      aux_4339 = allocate_fail_46_ast_node();
      return (obj_t) (aux_4339);
   }
}


/* fail? */ bool_t 
fail__35_ast_node(obj_t obj_184)
{
   return is_a__118___object(obj_184, fail_ast_node);
}


/* _fail? */ obj_t 
_fail__57_ast_node(obj_t env_3174, obj_t obj_3175)
{
   {
      bool_t aux_4343;
      aux_4343 = fail__35_ast_node(obj_3175);
      return BBOOL(aux_4343);
   }
}


/* make-fail */ fail_t 
make_fail_231_ast_node(obj_t loc_185, type_t type_186, node_t proc_187, node_t msg_188, node_t obj_189)
{
   {
      fail_t new1589_1933;
      new1589_1933 = ((fail_t) BREF(GC_MALLOC(sizeof(struct fail))));
      {
	 long arg2076_1934;
	 arg2076_1934 = class_num_218___object(fail_ast_node);
	 {
	    obj_t obj_1940;
	    obj_1940 = (obj_t) (new1589_1933);
	    (((obj_t) CREF(obj_1940))->header = MAKE_HEADER(arg2076_1934, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4350;
	 aux_4350 = (object_t) (new1589_1933);
	 OBJECT_WIDENING_SET(aux_4350, BFALSE);
      }
      ((((fail_t) CREF(new1589_1933))->loc) = ((obj_t) loc_185), BUNSPEC);
      ((((fail_t) CREF(new1589_1933))->type) = ((type_t) type_186), BUNSPEC);
      ((((fail_t) CREF(new1589_1933))->proc) = ((node_t) proc_187), BUNSPEC);
      ((((fail_t) CREF(new1589_1933))->msg) = ((node_t) msg_188), BUNSPEC);
      ((((fail_t) CREF(new1589_1933))->obj) = ((node_t) obj_189), BUNSPEC);
      return new1589_1933;
   }
}


/* _make-fail2565 */ obj_t 
_make_fail2565_1_ast_node(obj_t env_3176, obj_t loc_3177, obj_t type_3178, obj_t proc_3179, obj_t msg_3180, obj_t obj_3181)
{
   {
      fail_t aux_4358;
      aux_4358 = make_fail_231_ast_node(loc_3177, (type_t) (type_3178), (node_t) (proc_3179), (node_t) (msg_3180), (node_t) (obj_3181));
      return (obj_t) (aux_4358);
   }
}


/* fail-loc */ obj_t 
fail_loc_117_ast_node(fail_t obj_190)
{
   return (((fail_t) CREF(obj_190))->loc);
}


/* _fail-loc2566 */ obj_t 
_fail_loc2566_8_ast_node(obj_t env_3182, obj_t obj_3183)
{
   return fail_loc_117_ast_node((fail_t) (obj_3183));
}


/* fail-type-set! */ obj_t 
fail_type_set__42_ast_node(fail_t obj_191, type_t val1596_192)
{
   return ((((fail_t) CREF(obj_191))->type) = ((type_t) val1596_192), BUNSPEC);
}


/* _fail-type-set!2567 */ obj_t 
_fail_type_set_2567_138_ast_node(obj_t env_3184, obj_t obj_3185, obj_t val1596_3186)
{
   return fail_type_set__42_ast_node((fail_t) (obj_3185), (type_t) (val1596_3186));
}


/* fail-type */ type_t 
fail_type_93_ast_node(fail_t obj_193)
{
   return (((fail_t) CREF(obj_193))->type);
}


/* _fail-type2568 */ obj_t 
_fail_type2568_237_ast_node(obj_t env_3187, obj_t obj_3188)
{
   {
      type_t aux_4373;
      aux_4373 = fail_type_93_ast_node((fail_t) (obj_3188));
      return (obj_t) (aux_4373);
   }
}


/* fail-proc-set! */ obj_t 
fail_proc_set__82_ast_node(fail_t obj_194, node_t val1597_195)
{
   return ((((fail_t) CREF(obj_194))->proc) = ((node_t) val1597_195), BUNSPEC);
}


/* _fail-proc-set!2569 */ obj_t 
_fail_proc_set_2569_97_ast_node(obj_t env_3189, obj_t obj_3190, obj_t val1597_3191)
{
   return fail_proc_set__82_ast_node((fail_t) (obj_3190), (node_t) (val1597_3191));
}


/* fail-proc */ node_t 
fail_proc_182_ast_node(fail_t obj_196)
{
   return (((fail_t) CREF(obj_196))->proc);
}


/* _fail-proc2570 */ obj_t 
_fail_proc2570_42_ast_node(obj_t env_3192, obj_t obj_3193)
{
   {
      node_t aux_4382;
      aux_4382 = fail_proc_182_ast_node((fail_t) (obj_3193));
      return (obj_t) (aux_4382);
   }
}


/* fail-msg-set! */ obj_t 
fail_msg_set__47_ast_node(fail_t obj_197, node_t val1598_198)
{
   return ((((fail_t) CREF(obj_197))->msg) = ((node_t) val1598_198), BUNSPEC);
}


/* _fail-msg-set!2571 */ obj_t 
_fail_msg_set_2571_24_ast_node(obj_t env_3194, obj_t obj_3195, obj_t val1598_3196)
{
   return fail_msg_set__47_ast_node((fail_t) (obj_3195), (node_t) (val1598_3196));
}


/* fail-msg */ node_t 
fail_msg_210_ast_node(fail_t obj_199)
{
   return (((fail_t) CREF(obj_199))->msg);
}


/* _fail-msg2572 */ obj_t 
_fail_msg2572_162_ast_node(obj_t env_3197, obj_t obj_3198)
{
   {
      node_t aux_4391;
      aux_4391 = fail_msg_210_ast_node((fail_t) (obj_3198));
      return (obj_t) (aux_4391);
   }
}


/* fail-obj-set! */ obj_t 
fail_obj_set__117_ast_node(fail_t obj_200, node_t val1599_201)
{
   return ((((fail_t) CREF(obj_200))->obj) = ((node_t) val1599_201), BUNSPEC);
}


/* _fail-obj-set!2573 */ obj_t 
_fail_obj_set_2573_88_ast_node(obj_t env_3199, obj_t obj_3200, obj_t val1599_3201)
{
   return fail_obj_set__117_ast_node((fail_t) (obj_3200), (node_t) (val1599_3201));
}


/* fail-obj */ node_t 
fail_obj_122_ast_node(fail_t obj_202)
{
   return (((fail_t) CREF(obj_202))->obj);
}


/* _fail-obj2574 */ obj_t 
_fail_obj2574_73_ast_node(obj_t env_3202, obj_t obj_3203)
{
   {
      node_t aux_4400;
      aux_4400 = fail_obj_122_ast_node((fail_t) (obj_3203));
      return (obj_t) (aux_4400);
   }
}


/* allocate-conditional */ conditional_t 
allocate_conditional_174_ast_node()
{
   {
      conditional_t new1558_936;
      new1558_936 = ((conditional_t) BREF(GC_MALLOC(sizeof(struct conditional))));
      {
	 long arg2077_937;
	 arg2077_937 = class_num_218___object(conditional_ast_node);
	 {
	    obj_t obj_1942;
	    obj_1942 = (obj_t) (new1558_936);
	    (((obj_t) CREF(obj_1942))->header = MAKE_HEADER(arg2077_937, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4408;
	 aux_4408 = (object_t) (new1558_936);
	 OBJECT_WIDENING_SET(aux_4408, BFALSE);
      }
      return new1558_936;
   }
}


/* _allocate-conditional */ obj_t 
_allocate_conditional_184_ast_node(obj_t env_2918)
{
   {
      conditional_t aux_4411;
      aux_4411 = allocate_conditional_174_ast_node();
      return (obj_t) (aux_4411);
   }
}


/* conditional? */ bool_t 
conditional__146_ast_node(obj_t obj_206)
{
   return is_a__118___object(obj_206, conditional_ast_node);
}


/* _conditional? */ obj_t 
_conditional__140_ast_node(obj_t env_3204, obj_t obj_3205)
{
   {
      bool_t aux_4415;
      aux_4415 = conditional__146_ast_node(obj_3205);
      return BBOOL(aux_4415);
   }
}


/* make-conditional */ conditional_t 
make_conditional_43_ast_node(obj_t loc_207, type_t type_208, obj_t side_effect__165_209, obj_t key_210, node_t test_211, node_t true_212, node_t false_213)
{
   {
      conditional_t new1543_1944;
      new1543_1944 = ((conditional_t) BREF(GC_MALLOC(sizeof(struct conditional))));
      {
	 long arg2078_1945;
	 arg2078_1945 = class_num_218___object(conditional_ast_node);
	 {
	    obj_t obj_1953;
	    obj_1953 = (obj_t) (new1543_1944);
	    (((obj_t) CREF(obj_1953))->header = MAKE_HEADER(arg2078_1945, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4422;
	 aux_4422 = (object_t) (new1543_1944);
	 OBJECT_WIDENING_SET(aux_4422, BFALSE);
      }
      ((((conditional_t) CREF(new1543_1944))->loc) = ((obj_t) loc_207), BUNSPEC);
      ((((conditional_t) CREF(new1543_1944))->type) = ((type_t) type_208), BUNSPEC);
      ((((conditional_t) CREF(new1543_1944))->side_effect__165) = ((obj_t) side_effect__165_209), BUNSPEC);
      ((((conditional_t) CREF(new1543_1944))->key) = ((obj_t) key_210), BUNSPEC);
      ((((conditional_t) CREF(new1543_1944))->test) = ((node_t) test_211), BUNSPEC);
      ((((conditional_t) CREF(new1543_1944))->true) = ((node_t) true_212), BUNSPEC);
      ((((conditional_t) CREF(new1543_1944))->false) = ((node_t) false_213), BUNSPEC);
      return new1543_1944;
   }
}


/* _make-conditional2575 */ obj_t 
_make_conditional2575_101_ast_node(obj_t env_3206, obj_t loc_3207, obj_t type_3208, obj_t side_effect__165_3209, obj_t key_3210, obj_t test_3211, obj_t true_3212, obj_t false_3213)
{
   {
      conditional_t aux_4432;
      aux_4432 = make_conditional_43_ast_node(loc_3207, (type_t) (type_3208), side_effect__165_3209, key_3210, (node_t) (test_3211), (node_t) (true_3212), (node_t) (false_3213));
      return (obj_t) (aux_4432);
   }
}


/* conditional-loc */ obj_t 
conditional_loc_211_ast_node(conditional_t obj_214)
{
   return (((conditional_t) CREF(obj_214))->loc);
}


/* _conditional-loc2576 */ obj_t 
_conditional_loc2576_171_ast_node(obj_t env_3214, obj_t obj_3215)
{
   return conditional_loc_211_ast_node((conditional_t) (obj_3215));
}


/* conditional-type-set! */ obj_t 
conditional_type_set__131_ast_node(conditional_t obj_215, type_t val1552_216)
{
   return ((((conditional_t) CREF(obj_215))->type) = ((type_t) val1552_216), BUNSPEC);
}


/* _conditional-type-set!2577 */ obj_t 
_conditional_type_set_2577_38_ast_node(obj_t env_3216, obj_t obj_3217, obj_t val1552_3218)
{
   return conditional_type_set__131_ast_node((conditional_t) (obj_3217), (type_t) (val1552_3218));
}


/* conditional-type */ type_t 
conditional_type_236_ast_node(conditional_t obj_217)
{
   return (((conditional_t) CREF(obj_217))->type);
}


/* _conditional-type2578 */ obj_t 
_conditional_type2578_94_ast_node(obj_t env_3219, obj_t obj_3220)
{
   {
      type_t aux_4447;
      aux_4447 = conditional_type_236_ast_node((conditional_t) (obj_3220));
      return (obj_t) (aux_4447);
   }
}


/* conditional-side-effect?-set! */ obj_t 
conditional_side_effect__set__158_ast_node(conditional_t obj_218, obj_t val1553_219)
{
   return ((((conditional_t) CREF(obj_218))->side_effect__165) = ((obj_t) val1553_219), BUNSPEC);
}


/* _conditional-side-effect?-set!2579 */ obj_t 
_conditional_side_effect__set_2579_13_ast_node(obj_t env_3221, obj_t obj_3222, obj_t val1553_3223)
{
   return conditional_side_effect__set__158_ast_node((conditional_t) (obj_3222), val1553_3223);
}


/* conditional-side-effect? */ obj_t 
conditional_side_effect__145_ast_node(conditional_t obj_220)
{
   return (((conditional_t) CREF(obj_220))->side_effect__165);
}


/* _conditional-side-effect?2580 */ obj_t 
_conditional_side_effect_2580_200_ast_node(obj_t env_3224, obj_t obj_3225)
{
   return conditional_side_effect__145_ast_node((conditional_t) (obj_3225));
}


/* conditional-key-set! */ obj_t 
conditional_key_set__247_ast_node(conditional_t obj_221, obj_t val1554_222)
{
   return ((((conditional_t) CREF(obj_221))->key) = ((obj_t) val1554_222), BUNSPEC);
}


/* _conditional-key-set! */ obj_t 
_conditional_key_set__89_ast_node(obj_t env_3226, obj_t obj_3227, obj_t val1554_3228)
{
   return conditional_key_set__247_ast_node((conditional_t) (obj_3227), val1554_3228);
}


/* conditional-key */ obj_t 
conditional_key_55_ast_node(conditional_t obj_223)
{
   return (((conditional_t) CREF(obj_223))->key);
}


/* _conditional-key */ obj_t 
_conditional_key_147_ast_node(obj_t env_3229, obj_t obj_3230)
{
   return conditional_key_55_ast_node((conditional_t) (obj_3230));
}


/* conditional-test-set! */ obj_t 
conditional_test_set__179_ast_node(conditional_t obj_224, node_t val1555_225)
{
   return ((((conditional_t) CREF(obj_224))->test) = ((node_t) val1555_225), BUNSPEC);
}


/* _conditional-test-set!2581 */ obj_t 
_conditional_test_set_2581_5_ast_node(obj_t env_3231, obj_t obj_3232, obj_t val1555_3233)
{
   return conditional_test_set__179_ast_node((conditional_t) (obj_3232), (node_t) (val1555_3233));
}


/* conditional-test */ node_t 
conditional_test_2_ast_node(conditional_t obj_226)
{
   return (((conditional_t) CREF(obj_226))->test);
}


/* _conditional-test2582 */ obj_t 
_conditional_test2582_188_ast_node(obj_t env_3234, obj_t obj_3235)
{
   {
      node_t aux_4468;
      aux_4468 = conditional_test_2_ast_node((conditional_t) (obj_3235));
      return (obj_t) (aux_4468);
   }
}


/* conditional-true-set! */ obj_t 
conditional_true_set__127_ast_node(conditional_t obj_227, node_t val1556_228)
{
   return ((((conditional_t) CREF(obj_227))->true) = ((node_t) val1556_228), BUNSPEC);
}


/* _conditional-true-set!2583 */ obj_t 
_conditional_true_set_2583_74_ast_node(obj_t env_3236, obj_t obj_3237, obj_t val1556_3238)
{
   return conditional_true_set__127_ast_node((conditional_t) (obj_3237), (node_t) (val1556_3238));
}


/* conditional-true */ node_t 
conditional_true_226_ast_node(conditional_t obj_229)
{
   return (((conditional_t) CREF(obj_229))->true);
}


/* _conditional-true2584 */ obj_t 
_conditional_true2584_27_ast_node(obj_t env_3239, obj_t obj_3240)
{
   {
      node_t aux_4477;
      aux_4477 = conditional_true_226_ast_node((conditional_t) (obj_3240));
      return (obj_t) (aux_4477);
   }
}


/* conditional-false-set! */ obj_t 
conditional_false_set__184_ast_node(conditional_t obj_230, node_t val1557_231)
{
   return ((((conditional_t) CREF(obj_230))->false) = ((node_t) val1557_231), BUNSPEC);
}


/* _conditional-false-set!2585 */ obj_t 
_conditional_false_set_2585_128_ast_node(obj_t env_3241, obj_t obj_3242, obj_t val1557_3243)
{
   return conditional_false_set__184_ast_node((conditional_t) (obj_3242), (node_t) (val1557_3243));
}


/* conditional-false */ node_t 
conditional_false_181_ast_node(conditional_t obj_232)
{
   return (((conditional_t) CREF(obj_232))->false);
}


/* _conditional-false2586 */ obj_t 
_conditional_false2586_217_ast_node(obj_t env_3244, obj_t obj_3245)
{
   {
      node_t aux_4486;
      aux_4486 = conditional_false_181_ast_node((conditional_t) (obj_3245));
      return (obj_t) (aux_4486);
   }
}


/* allocate-setq */ setq_t 
allocate_setq_54_ast_node()
{
   {
      setq_t new1524_947;
      new1524_947 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
      {
	 long arg2079_948;
	 arg2079_948 = class_num_218___object(setq_ast_node);
	 {
	    obj_t obj_1955;
	    obj_1955 = (obj_t) (new1524_947);
	    (((obj_t) CREF(obj_1955))->header = MAKE_HEADER(arg2079_948, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4494;
	 aux_4494 = (object_t) (new1524_947);
	 OBJECT_WIDENING_SET(aux_4494, BFALSE);
      }
      return new1524_947;
   }
}


/* _allocate-setq */ obj_t 
_allocate_setq_253_ast_node(obj_t env_2917)
{
   {
      setq_t aux_4497;
      aux_4497 = allocate_setq_54_ast_node();
      return (obj_t) (aux_4497);
   }
}


/* setq? */ bool_t 
setq__41_ast_node(obj_t obj_236)
{
   return is_a__118___object(obj_236, setq_ast_node);
}


/* _setq? */ obj_t 
_setq__97_ast_node(obj_t env_3246, obj_t obj_3247)
{
   {
      bool_t aux_4501;
      aux_4501 = setq__41_ast_node(obj_3247);
      return BBOOL(aux_4501);
   }
}


/* make-setq */ setq_t 
make_setq_237_ast_node(obj_t loc_237, type_t type_238, var_t var_239, node_t value_240)
{
   {
      setq_t new1515_1957;
      new1515_1957 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
      {
	 long arg2080_1958;
	 arg2080_1958 = class_num_218___object(setq_ast_node);
	 {
	    obj_t obj_1963;
	    obj_1963 = (obj_t) (new1515_1957);
	    (((obj_t) CREF(obj_1963))->header = MAKE_HEADER(arg2080_1958, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4508;
	 aux_4508 = (object_t) (new1515_1957);
	 OBJECT_WIDENING_SET(aux_4508, BFALSE);
      }
      ((((setq_t) CREF(new1515_1957))->loc) = ((obj_t) loc_237), BUNSPEC);
      ((((setq_t) CREF(new1515_1957))->type) = ((type_t) type_238), BUNSPEC);
      ((((setq_t) CREF(new1515_1957))->var) = ((var_t) var_239), BUNSPEC);
      ((((setq_t) CREF(new1515_1957))->value) = ((node_t) value_240), BUNSPEC);
      return new1515_1957;
   }
}


/* _make-setq2587 */ obj_t 
_make_setq2587_87_ast_node(obj_t env_3248, obj_t loc_3249, obj_t type_3250, obj_t var_3251, obj_t value_3252)
{
   {
      setq_t aux_4515;
      aux_4515 = make_setq_237_ast_node(loc_3249, (type_t) (type_3250), (var_t) (var_3251), (node_t) (value_3252));
      return (obj_t) (aux_4515);
   }
}


/* setq-loc */ obj_t 
setq_loc_177_ast_node(setq_t obj_241)
{
   return (((setq_t) CREF(obj_241))->loc);
}


/* _setq-loc2588 */ obj_t 
_setq_loc2588_95_ast_node(obj_t env_3253, obj_t obj_3254)
{
   return setq_loc_177_ast_node((setq_t) (obj_3254));
}


/* setq-type-set! */ obj_t 
setq_type_set__224_ast_node(setq_t obj_242, type_t val1521_243)
{
   return ((((setq_t) CREF(obj_242))->type) = ((type_t) val1521_243), BUNSPEC);
}


/* _setq-type-set!2589 */ obj_t 
_setq_type_set_2589_129_ast_node(obj_t env_3255, obj_t obj_3256, obj_t val1521_3257)
{
   return setq_type_set__224_ast_node((setq_t) (obj_3256), (type_t) (val1521_3257));
}


/* setq-type */ type_t 
setq_type_225_ast_node(setq_t obj_244)
{
   return (((setq_t) CREF(obj_244))->type);
}


/* _setq-type2590 */ obj_t 
_setq_type2590_177_ast_node(obj_t env_3258, obj_t obj_3259)
{
   {
      type_t aux_4529;
      aux_4529 = setq_type_225_ast_node((setq_t) (obj_3259));
      return (obj_t) (aux_4529);
   }
}


/* setq-var-set! */ obj_t 
setq_var_set__217_ast_node(setq_t obj_245, var_t val1522_246)
{
   return ((((setq_t) CREF(obj_245))->var) = ((var_t) val1522_246), BUNSPEC);
}


/* _setq-var-set!2591 */ obj_t 
_setq_var_set_2591_219_ast_node(obj_t env_3260, obj_t obj_3261, obj_t val1522_3262)
{
   return setq_var_set__217_ast_node((setq_t) (obj_3261), (var_t) (val1522_3262));
}


/* setq-var */ var_t 
setq_var_152_ast_node(setq_t obj_247)
{
   return (((setq_t) CREF(obj_247))->var);
}


/* _setq-var2592 */ obj_t 
_setq_var2592_194_ast_node(obj_t env_3263, obj_t obj_3264)
{
   {
      var_t aux_4538;
      aux_4538 = setq_var_152_ast_node((setq_t) (obj_3264));
      return (obj_t) (aux_4538);
   }
}


/* setq-value-set! */ obj_t 
setq_value_set__233_ast_node(setq_t obj_248, node_t val1523_249)
{
   return ((((setq_t) CREF(obj_248))->value) = ((node_t) val1523_249), BUNSPEC);
}


/* _setq-value-set!2593 */ obj_t 
_setq_value_set_2593_255_ast_node(obj_t env_3265, obj_t obj_3266, obj_t val1523_3267)
{
   return setq_value_set__233_ast_node((setq_t) (obj_3266), (node_t) (val1523_3267));
}


/* setq-value */ node_t 
setq_value_119_ast_node(setq_t obj_250)
{
   return (((setq_t) CREF(obj_250))->value);
}


/* _setq-value2594 */ obj_t 
_setq_value2594_157_ast_node(obj_t env_3268, obj_t obj_3269)
{
   {
      node_t aux_4547;
      aux_4547 = setq_value_119_ast_node((setq_t) (obj_3269));
      return (obj_t) (aux_4547);
   }
}


/* allocate-cast */ cast_t 
allocate_cast_68_ast_node()
{
   {
      cast_t new1500_955;
      new1500_955 = ((cast_t) BREF(GC_MALLOC(sizeof(struct cast))));
      {
	 long arg2081_956;
	 arg2081_956 = class_num_218___object(cast_ast_node);
	 {
	    obj_t obj_1965;
	    obj_1965 = (obj_t) (new1500_955);
	    (((obj_t) CREF(obj_1965))->header = MAKE_HEADER(arg2081_956, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4555;
	 aux_4555 = (object_t) (new1500_955);
	 OBJECT_WIDENING_SET(aux_4555, BFALSE);
      }
      return new1500_955;
   }
}


/* _allocate-cast */ obj_t 
_allocate_cast_146_ast_node(obj_t env_2916)
{
   {
      cast_t aux_4558;
      aux_4558 = allocate_cast_68_ast_node();
      return (obj_t) (aux_4558);
   }
}


/* cast? */ bool_t 
cast__213_ast_node(obj_t obj_254)
{
   return is_a__118___object(obj_254, cast_ast_node);
}


/* _cast? */ obj_t 
_cast__220_ast_node(obj_t env_3270, obj_t obj_3271)
{
   {
      bool_t aux_4562;
      aux_4562 = cast__213_ast_node(obj_3271);
      return BBOOL(aux_4562);
   }
}


/* make-cast */ cast_t 
make_cast_147_ast_node(obj_t loc_255, type_t type_256, node_t arg_257)
{
   {
      cast_t new1493_1967;
      new1493_1967 = ((cast_t) BREF(GC_MALLOC(sizeof(struct cast))));
      {
	 long arg2082_1968;
	 arg2082_1968 = class_num_218___object(cast_ast_node);
	 {
	    obj_t obj_1972;
	    obj_1972 = (obj_t) (new1493_1967);
	    (((obj_t) CREF(obj_1972))->header = MAKE_HEADER(arg2082_1968, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4569;
	 aux_4569 = (object_t) (new1493_1967);
	 OBJECT_WIDENING_SET(aux_4569, BFALSE);
      }
      ((((cast_t) CREF(new1493_1967))->loc) = ((obj_t) loc_255), BUNSPEC);
      ((((cast_t) CREF(new1493_1967))->type) = ((type_t) type_256), BUNSPEC);
      ((((cast_t) CREF(new1493_1967))->arg) = ((node_t) arg_257), BUNSPEC);
      return new1493_1967;
   }
}


/* _make-cast2595 */ obj_t 
_make_cast2595_213_ast_node(obj_t env_3272, obj_t loc_3273, obj_t type_3274, obj_t arg_3275)
{
   {
      cast_t aux_4575;
      aux_4575 = make_cast_147_ast_node(loc_3273, (type_t) (type_3274), (node_t) (arg_3275));
      return (obj_t) (aux_4575);
   }
}


/* cast-loc */ obj_t 
cast_loc_174_ast_node(cast_t obj_258)
{
   return (((cast_t) CREF(obj_258))->loc);
}


/* _cast-loc2596 */ obj_t 
_cast_loc2596_220_ast_node(obj_t env_3276, obj_t obj_3277)
{
   return cast_loc_174_ast_node((cast_t) (obj_3277));
}


/* cast-type-set! */ obj_t 
cast_type_set__214_ast_node(cast_t obj_259, type_t val1498_260)
{
   return ((((cast_t) CREF(obj_259))->type) = ((type_t) val1498_260), BUNSPEC);
}


/* _cast-type-set!2597 */ obj_t 
_cast_type_set_2597_150_ast_node(obj_t env_3278, obj_t obj_3279, obj_t val1498_3280)
{
   return cast_type_set__214_ast_node((cast_t) (obj_3279), (type_t) (val1498_3280));
}


/* cast-type */ type_t 
cast_type_139_ast_node(cast_t obj_261)
{
   return (((cast_t) CREF(obj_261))->type);
}


/* _cast-type2598 */ obj_t 
_cast_type2598_33_ast_node(obj_t env_3281, obj_t obj_3282)
{
   {
      type_t aux_4588;
      aux_4588 = cast_type_139_ast_node((cast_t) (obj_3282));
      return (obj_t) (aux_4588);
   }
}


/* cast-arg-set! */ obj_t 
cast_arg_set__132_ast_node(cast_t obj_262, node_t val1499_263)
{
   return ((((cast_t) CREF(obj_262))->arg) = ((node_t) val1499_263), BUNSPEC);
}


/* _cast-arg-set!2599 */ obj_t 
_cast_arg_set_2599_159_ast_node(obj_t env_3283, obj_t obj_3284, obj_t val1499_3285)
{
   return cast_arg_set__132_ast_node((cast_t) (obj_3284), (node_t) (val1499_3285));
}


/* cast-arg */ node_t 
cast_arg_174_ast_node(cast_t obj_264)
{
   return (((cast_t) CREF(obj_264))->arg);
}


/* _cast-arg2600 */ obj_t 
_cast_arg2600_154_ast_node(obj_t env_3286, obj_t obj_3287)
{
   {
      node_t aux_4597;
      aux_4597 = cast_arg_174_ast_node((cast_t) (obj_3287));
      return (obj_t) (aux_4597);
   }
}


/* allocate-pragma */ pragma_t 
allocate_pragma_110_ast_node()
{
   {
      pragma_t new1466_962;
      new1466_962 = ((pragma_t) BREF(GC_MALLOC(sizeof(struct pragma))));
      {
	 long arg2083_963;
	 arg2083_963 = class_num_218___object(pragma_ast_node);
	 {
	    obj_t obj_1974;
	    obj_1974 = (obj_t) (new1466_962);
	    (((obj_t) CREF(obj_1974))->header = MAKE_HEADER(arg2083_963, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4605;
	 aux_4605 = (object_t) (new1466_962);
	 OBJECT_WIDENING_SET(aux_4605, BFALSE);
      }
      return new1466_962;
   }
}


/* _allocate-pragma */ obj_t 
_allocate_pragma_246_ast_node(obj_t env_2915)
{
   {
      pragma_t aux_4608;
      aux_4608 = allocate_pragma_110_ast_node();
      return (obj_t) (aux_4608);
   }
}


/* pragma? */ bool_t 
pragma__55_ast_node(obj_t obj_268)
{
   return is_a__118___object(obj_268, pragma_ast_node);
}


/* _pragma? */ obj_t 
_pragma__23_ast_node(obj_t env_3288, obj_t obj_3289)
{
   {
      bool_t aux_4612;
      aux_4612 = pragma__55_ast_node(obj_3289);
      return BBOOL(aux_4612);
   }
}


/* make-pragma */ pragma_t 
make_pragma_155_ast_node(obj_t loc_269, type_t type_270, obj_t side_effect__165_271, obj_t key_272, obj_t format_273, obj_t args_274)
{
   {
      pragma_t new1454_1976;
      new1454_1976 = ((pragma_t) BREF(GC_MALLOC(sizeof(struct pragma))));
      {
	 long arg2084_1977;
	 arg2084_1977 = class_num_218___object(pragma_ast_node);
	 {
	    obj_t obj_1984;
	    obj_1984 = (obj_t) (new1454_1976);
	    (((obj_t) CREF(obj_1984))->header = MAKE_HEADER(arg2084_1977, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4619;
	 aux_4619 = (object_t) (new1454_1976);
	 OBJECT_WIDENING_SET(aux_4619, BFALSE);
      }
      ((((pragma_t) CREF(new1454_1976))->loc) = ((obj_t) loc_269), BUNSPEC);
      ((((pragma_t) CREF(new1454_1976))->type) = ((type_t) type_270), BUNSPEC);
      ((((pragma_t) CREF(new1454_1976))->side_effect__165) = ((obj_t) side_effect__165_271), BUNSPEC);
      ((((pragma_t) CREF(new1454_1976))->key) = ((obj_t) key_272), BUNSPEC);
      ((((pragma_t) CREF(new1454_1976))->format) = ((obj_t) format_273), BUNSPEC);
      ((((pragma_t) CREF(new1454_1976))->args) = ((obj_t) args_274), BUNSPEC);
      return new1454_1976;
   }
}


/* _make-pragma2601 */ obj_t 
_make_pragma2601_250_ast_node(obj_t env_3290, obj_t loc_3291, obj_t type_3292, obj_t side_effect__165_3293, obj_t key_3294, obj_t format_3295, obj_t args_3296)
{
   {
      pragma_t aux_4628;
      aux_4628 = make_pragma_155_ast_node(loc_3291, (type_t) (type_3292), side_effect__165_3293, key_3294, format_3295, args_3296);
      return (obj_t) (aux_4628);
   }
}


/* pragma-loc */ obj_t 
pragma_loc_254_ast_node(pragma_t obj_275)
{
   return (((pragma_t) CREF(obj_275))->loc);
}


/* _pragma-loc2602 */ obj_t 
_pragma_loc2602_15_ast_node(obj_t env_3297, obj_t obj_3298)
{
   return pragma_loc_254_ast_node((pragma_t) (obj_3298));
}


/* pragma-type-set! */ obj_t 
pragma_type_set__19_ast_node(pragma_t obj_276, type_t val1462_277)
{
   return ((((pragma_t) CREF(obj_276))->type) = ((type_t) val1462_277), BUNSPEC);
}


/* _pragma-type-set!2603 */ obj_t 
_pragma_type_set_2603_242_ast_node(obj_t env_3299, obj_t obj_3300, obj_t val1462_3301)
{
   return pragma_type_set__19_ast_node((pragma_t) (obj_3300), (type_t) (val1462_3301));
}


/* pragma-type */ type_t 
pragma_type_32_ast_node(pragma_t obj_278)
{
   return (((pragma_t) CREF(obj_278))->type);
}


/* _pragma-type2604 */ obj_t 
_pragma_type2604_183_ast_node(obj_t env_3302, obj_t obj_3303)
{
   {
      type_t aux_4640;
      aux_4640 = pragma_type_32_ast_node((pragma_t) (obj_3303));
      return (obj_t) (aux_4640);
   }
}


/* pragma-side-effect?-set! */ obj_t 
pragma_side_effect__set__174_ast_node(pragma_t obj_279, obj_t val1463_280)
{
   return ((((pragma_t) CREF(obj_279))->side_effect__165) = ((obj_t) val1463_280), BUNSPEC);
}


/* _pragma-side-effect?-set!2605 */ obj_t 
_pragma_side_effect__set_2605_45_ast_node(obj_t env_3304, obj_t obj_3305, obj_t val1463_3306)
{
   return pragma_side_effect__set__174_ast_node((pragma_t) (obj_3305), val1463_3306);
}


/* pragma-side-effect? */ obj_t 
pragma_side_effect__84_ast_node(pragma_t obj_281)
{
   return (((pragma_t) CREF(obj_281))->side_effect__165);
}


/* _pragma-side-effect?2606 */ obj_t 
_pragma_side_effect_2606_219_ast_node(obj_t env_3307, obj_t obj_3308)
{
   return pragma_side_effect__84_ast_node((pragma_t) (obj_3308));
}


/* pragma-key-set! */ obj_t 
pragma_key_set__102_ast_node(pragma_t obj_282, obj_t val1464_283)
{
   return ((((pragma_t) CREF(obj_282))->key) = ((obj_t) val1464_283), BUNSPEC);
}


/* _pragma-key-set! */ obj_t 
_pragma_key_set__110_ast_node(obj_t env_3309, obj_t obj_3310, obj_t val1464_3311)
{
   return pragma_key_set__102_ast_node((pragma_t) (obj_3310), val1464_3311);
}


/* pragma-key */ obj_t 
pragma_key_211_ast_node(pragma_t obj_284)
{
   return (((pragma_t) CREF(obj_284))->key);
}


/* _pragma-key */ obj_t 
_pragma_key_199_ast_node(obj_t env_3312, obj_t obj_3313)
{
   return pragma_key_211_ast_node((pragma_t) (obj_3313));
}


/* pragma-format */ obj_t 
pragma_format_172_ast_node(pragma_t obj_285)
{
   return (((pragma_t) CREF(obj_285))->format);
}


/* _pragma-format2607 */ obj_t 
_pragma_format2607_223_ast_node(obj_t env_3314, obj_t obj_3315)
{
   return pragma_format_172_ast_node((pragma_t) (obj_3315));
}


/* pragma-args-set! */ obj_t 
pragma_args_set__199_ast_node(pragma_t obj_286, obj_t val1465_287)
{
   return ((((pragma_t) CREF(obj_286))->args) = ((obj_t) val1465_287), BUNSPEC);
}


/* _pragma-args-set!2608 */ obj_t 
_pragma_args_set_2608_116_ast_node(obj_t env_3316, obj_t obj_3317, obj_t val1465_3318)
{
   return pragma_args_set__199_ast_node((pragma_t) (obj_3317), val1465_3318);
}


/* pragma-args */ obj_t 
pragma_args_116_ast_node(pragma_t obj_288)
{
   return (((pragma_t) CREF(obj_288))->args);
}


/* _pragma-args2609 */ obj_t 
_pragma_args2609_133_ast_node(obj_t env_3319, obj_t obj_3320)
{
   return pragma_args_116_ast_node((pragma_t) (obj_3320));
}


/* allocate-funcall */ funcall_t 
allocate_funcall_80_ast_node()
{
   {
      funcall_t new1431_972;
      new1431_972 = ((funcall_t) BREF(GC_MALLOC(sizeof(struct funcall))));
      {
	 long arg2085_973;
	 arg2085_973 = class_num_218___object(funcall_ast_node);
	 {
	    obj_t obj_1986;
	    obj_1986 = (obj_t) (new1431_972);
	    (((obj_t) CREF(obj_1986))->header = MAKE_HEADER(arg2085_973, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4669;
	 aux_4669 = (object_t) (new1431_972);
	 OBJECT_WIDENING_SET(aux_4669, BFALSE);
      }
      return new1431_972;
   }
}


/* _allocate-funcall */ obj_t 
_allocate_funcall_93_ast_node(obj_t env_2914)
{
   {
      funcall_t aux_4672;
      aux_4672 = allocate_funcall_80_ast_node();
      return (obj_t) (aux_4672);
   }
}


/* funcall? */ bool_t 
funcall__35_ast_node(obj_t obj_292)
{
   return is_a__118___object(obj_292, funcall_ast_node);
}


/* _funcall? */ obj_t 
_funcall__161_ast_node(obj_t env_3321, obj_t obj_3322)
{
   {
      bool_t aux_4676;
      aux_4676 = funcall__35_ast_node(obj_3322);
      return BBOOL(aux_4676);
   }
}


/* make-funcall */ funcall_t 
make_funcall_190_ast_node(obj_t loc_293, type_t type_294, node_t fun_295, obj_t args_296, obj_t strength_297)
{
   {
      funcall_t new1420_1988;
      new1420_1988 = ((funcall_t) BREF(GC_MALLOC(sizeof(struct funcall))));
      {
	 long arg2086_1989;
	 arg2086_1989 = class_num_218___object(funcall_ast_node);
	 {
	    obj_t obj_1995;
	    obj_1995 = (obj_t) (new1420_1988);
	    (((obj_t) CREF(obj_1995))->header = MAKE_HEADER(arg2086_1989, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4683;
	 aux_4683 = (object_t) (new1420_1988);
	 OBJECT_WIDENING_SET(aux_4683, BFALSE);
      }
      ((((funcall_t) CREF(new1420_1988))->loc) = ((obj_t) loc_293), BUNSPEC);
      ((((funcall_t) CREF(new1420_1988))->type) = ((type_t) type_294), BUNSPEC);
      ((((funcall_t) CREF(new1420_1988))->fun) = ((node_t) fun_295), BUNSPEC);
      ((((funcall_t) CREF(new1420_1988))->args) = ((obj_t) args_296), BUNSPEC);
      ((((funcall_t) CREF(new1420_1988))->strength) = ((obj_t) strength_297), BUNSPEC);
      return new1420_1988;
   }
}


/* _make-funcall2610 */ obj_t 
_make_funcall2610_87_ast_node(obj_t env_3323, obj_t loc_3324, obj_t type_3325, obj_t fun_3326, obj_t args_3327, obj_t strength_3328)
{
   {
      funcall_t aux_4691;
      aux_4691 = make_funcall_190_ast_node(loc_3324, (type_t) (type_3325), (node_t) (fun_3326), args_3327, strength_3328);
      return (obj_t) (aux_4691);
   }
}


/* funcall-loc */ obj_t 
funcall_loc_117_ast_node(funcall_t obj_298)
{
   return (((funcall_t) CREF(obj_298))->loc);
}


/* _funcall-loc2611 */ obj_t 
_funcall_loc2611_9_ast_node(obj_t env_3329, obj_t obj_3330)
{
   return funcall_loc_117_ast_node((funcall_t) (obj_3330));
}


/* funcall-type-set! */ obj_t 
funcall_type_set__42_ast_node(funcall_t obj_299, type_t val1427_300)
{
   return ((((funcall_t) CREF(obj_299))->type) = ((type_t) val1427_300), BUNSPEC);
}


/* _funcall-type-set!2612 */ obj_t 
_funcall_type_set_2612_24_ast_node(obj_t env_3331, obj_t obj_3332, obj_t val1427_3333)
{
   return funcall_type_set__42_ast_node((funcall_t) (obj_3332), (type_t) (val1427_3333));
}


/* funcall-type */ type_t 
funcall_type_93_ast_node(funcall_t obj_301)
{
   return (((funcall_t) CREF(obj_301))->type);
}


/* _funcall-type2613 */ obj_t 
_funcall_type2613_180_ast_node(obj_t env_3334, obj_t obj_3335)
{
   {
      type_t aux_4704;
      aux_4704 = funcall_type_93_ast_node((funcall_t) (obj_3335));
      return (obj_t) (aux_4704);
   }
}


/* funcall-fun-set! */ obj_t 
funcall_fun_set__22_ast_node(funcall_t obj_302, node_t val1428_303)
{
   return ((((funcall_t) CREF(obj_302))->fun) = ((node_t) val1428_303), BUNSPEC);
}


/* _funcall-fun-set!2614 */ obj_t 
_funcall_fun_set_2614_75_ast_node(obj_t env_3336, obj_t obj_3337, obj_t val1428_3338)
{
   return funcall_fun_set__22_ast_node((funcall_t) (obj_3337), (node_t) (val1428_3338));
}


/* funcall-fun */ node_t 
funcall_fun_37_ast_node(funcall_t obj_304)
{
   return (((funcall_t) CREF(obj_304))->fun);
}


/* _funcall-fun2615 */ obj_t 
_funcall_fun2615_153_ast_node(obj_t env_3339, obj_t obj_3340)
{
   {
      node_t aux_4713;
      aux_4713 = funcall_fun_37_ast_node((funcall_t) (obj_3340));
      return (obj_t) (aux_4713);
   }
}


/* funcall-args-set! */ obj_t 
funcall_args_set__108_ast_node(funcall_t obj_305, obj_t val1429_306)
{
   return ((((funcall_t) CREF(obj_305))->args) = ((obj_t) val1429_306), BUNSPEC);
}


/* _funcall-args-set!2616 */ obj_t 
_funcall_args_set_2616_3_ast_node(obj_t env_3341, obj_t obj_3342, obj_t val1429_3343)
{
   return funcall_args_set__108_ast_node((funcall_t) (obj_3342), val1429_3343);
}


/* funcall-args */ obj_t 
funcall_args_151_ast_node(funcall_t obj_307)
{
   return (((funcall_t) CREF(obj_307))->args);
}


/* _funcall-args2617 */ obj_t 
_funcall_args2617_165_ast_node(obj_t env_3344, obj_t obj_3345)
{
   return funcall_args_151_ast_node((funcall_t) (obj_3345));
}


/* funcall-strength-set! */ obj_t 
funcall_strength_set__57_ast_node(funcall_t obj_308, obj_t val1430_309)
{
   return ((((funcall_t) CREF(obj_308))->strength) = ((obj_t) val1430_309), BUNSPEC);
}


/* _funcall-strength-set!2618 */ obj_t 
_funcall_strength_set_2618_194_ast_node(obj_t env_3346, obj_t obj_3347, obj_t val1430_3348)
{
   return funcall_strength_set__57_ast_node((funcall_t) (obj_3347), val1430_3348);
}


/* funcall-strength */ obj_t 
funcall_strength_157_ast_node(funcall_t obj_310)
{
   return (((funcall_t) CREF(obj_310))->strength);
}


/* _funcall-strength2619 */ obj_t 
_funcall_strength2619_138_ast_node(obj_t env_3349, obj_t obj_3350)
{
   return funcall_strength_157_ast_node((funcall_t) (obj_3350));
}


/* allocate-app-ly */ app_ly_162_t 
allocate_app_ly_30_ast_node()
{
   {
      app_ly_162_t new1401_981;
      new1401_981 = ((app_ly_162_t) BREF(GC_MALLOC(sizeof(struct app_ly_162))));
      {
	 long arg2087_982;
	 arg2087_982 = class_num_218___object(app_ly_162_ast_node);
	 {
	    obj_t obj_1997;
	    obj_1997 = (obj_t) (new1401_981);
	    (((obj_t) CREF(obj_1997))->header = MAKE_HEADER(arg2087_982, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4733;
	 aux_4733 = (object_t) (new1401_981);
	 OBJECT_WIDENING_SET(aux_4733, BFALSE);
      }
      return new1401_981;
   }
}


/* _allocate-app-ly */ obj_t 
_allocate_app_ly_138_ast_node(obj_t env_2913)
{
   {
      app_ly_162_t aux_4736;
      aux_4736 = allocate_app_ly_30_ast_node();
      return (obj_t) (aux_4736);
   }
}


/* app-ly? */ bool_t 
app_ly__191_ast_node(obj_t obj_314)
{
   return is_a__118___object(obj_314, app_ly_162_ast_node);
}


/* _app-ly? */ obj_t 
_app_ly__224_ast_node(obj_t env_3351, obj_t obj_3352)
{
   {
      bool_t aux_4740;
      aux_4740 = app_ly__191_ast_node(obj_3352);
      return BBOOL(aux_4740);
   }
}


/* make-app-ly */ app_ly_162_t 
make_app_ly_64_ast_node(obj_t loc_315, type_t type_316, node_t fun_317, node_t arg_318)
{
   {
      app_ly_162_t new1392_1999;
      new1392_1999 = ((app_ly_162_t) BREF(GC_MALLOC(sizeof(struct app_ly_162))));
      {
	 long arg2088_2000;
	 arg2088_2000 = class_num_218___object(app_ly_162_ast_node);
	 {
	    obj_t obj_2005;
	    obj_2005 = (obj_t) (new1392_1999);
	    (((obj_t) CREF(obj_2005))->header = MAKE_HEADER(arg2088_2000, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4747;
	 aux_4747 = (object_t) (new1392_1999);
	 OBJECT_WIDENING_SET(aux_4747, BFALSE);
      }
      ((((app_ly_162_t) CREF(new1392_1999))->loc) = ((obj_t) loc_315), BUNSPEC);
      ((((app_ly_162_t) CREF(new1392_1999))->type) = ((type_t) type_316), BUNSPEC);
      ((((app_ly_162_t) CREF(new1392_1999))->fun) = ((node_t) fun_317), BUNSPEC);
      ((((app_ly_162_t) CREF(new1392_1999))->arg) = ((node_t) arg_318), BUNSPEC);
      return new1392_1999;
   }
}


/* _make-app-ly2620 */ obj_t 
_make_app_ly2620_72_ast_node(obj_t env_3353, obj_t loc_3354, obj_t type_3355, obj_t fun_3356, obj_t arg_3357)
{
   {
      app_ly_162_t aux_4754;
      aux_4754 = make_app_ly_64_ast_node(loc_3354, (type_t) (type_3355), (node_t) (fun_3356), (node_t) (arg_3357));
      return (obj_t) (aux_4754);
   }
}


/* app-ly-loc */ obj_t 
app_ly_loc_83_ast_node(app_ly_162_t obj_319)
{
   return (((app_ly_162_t) CREF(obj_319))->loc);
}


/* _app-ly-loc2621 */ obj_t 
_app_ly_loc2621_94_ast_node(obj_t env_3358, obj_t obj_3359)
{
   return app_ly_loc_83_ast_node((app_ly_162_t) (obj_3359));
}


/* app-ly-type-set! */ obj_t 
app_ly_type_set__172_ast_node(app_ly_162_t obj_320, type_t val1398_321)
{
   return ((((app_ly_162_t) CREF(obj_320))->type) = ((type_t) val1398_321), BUNSPEC);
}


/* _app-ly-type-set!2622 */ obj_t 
_app_ly_type_set_2622_144_ast_node(obj_t env_3360, obj_t obj_3361, obj_t val1398_3362)
{
   return app_ly_type_set__172_ast_node((app_ly_162_t) (obj_3361), (type_t) (val1398_3362));
}


/* app-ly-type */ type_t 
app_ly_type_138_ast_node(app_ly_162_t obj_322)
{
   return (((app_ly_162_t) CREF(obj_322))->type);
}


/* _app-ly-type2623 */ obj_t 
_app_ly_type2623_46_ast_node(obj_t env_3363, obj_t obj_3364)
{
   {
      type_t aux_4768;
      aux_4768 = app_ly_type_138_ast_node((app_ly_162_t) (obj_3364));
      return (obj_t) (aux_4768);
   }
}


/* app-ly-fun-set! */ obj_t 
app_ly_fun_set__208_ast_node(app_ly_162_t obj_323, node_t val1399_324)
{
   return ((((app_ly_162_t) CREF(obj_323))->fun) = ((node_t) val1399_324), BUNSPEC);
}


/* _app-ly-fun-set!2624 */ obj_t 
_app_ly_fun_set_2624_61_ast_node(obj_t env_3365, obj_t obj_3366, obj_t val1399_3367)
{
   return app_ly_fun_set__208_ast_node((app_ly_162_t) (obj_3366), (node_t) (val1399_3367));
}


/* app-ly-fun */ node_t 
app_ly_fun_107_ast_node(app_ly_162_t obj_325)
{
   return (((app_ly_162_t) CREF(obj_325))->fun);
}


/* _app-ly-fun2625 */ obj_t 
_app_ly_fun2625_151_ast_node(obj_t env_3368, obj_t obj_3369)
{
   {
      node_t aux_4777;
      aux_4777 = app_ly_fun_107_ast_node((app_ly_162_t) (obj_3369));
      return (obj_t) (aux_4777);
   }
}


/* app-ly-arg-set! */ obj_t 
app_ly_arg_set__254_ast_node(app_ly_162_t obj_326, node_t val1400_327)
{
   return ((((app_ly_162_t) CREF(obj_326))->arg) = ((node_t) val1400_327), BUNSPEC);
}


/* _app-ly-arg-set!2626 */ obj_t 
_app_ly_arg_set_2626_69_ast_node(obj_t env_3370, obj_t obj_3371, obj_t val1400_3372)
{
   return app_ly_arg_set__254_ast_node((app_ly_162_t) (obj_3371), (node_t) (val1400_3372));
}


/* app-ly-arg */ node_t 
app_ly_arg_131_ast_node(app_ly_162_t obj_328)
{
   return (((app_ly_162_t) CREF(obj_328))->arg);
}


/* _app-ly-arg2627 */ obj_t 
_app_ly_arg2627_163_ast_node(obj_t env_3373, obj_t obj_3374)
{
   {
      node_t aux_4786;
      aux_4786 = app_ly_arg_131_ast_node((app_ly_162_t) (obj_3374));
      return (obj_t) (aux_4786);
   }
}


/* allocate-app */ app_t 
allocate_app_15_ast_node()
{
   {
      app_t new1361_989;
      new1361_989 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
      {
	 long arg2089_990;
	 arg2089_990 = class_num_218___object(app_ast_node);
	 {
	    obj_t obj_2007;
	    obj_2007 = (obj_t) (new1361_989);
	    (((obj_t) CREF(obj_2007))->header = MAKE_HEADER(arg2089_990, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4794;
	 aux_4794 = (object_t) (new1361_989);
	 OBJECT_WIDENING_SET(aux_4794, BFALSE);
      }
      return new1361_989;
   }
}


/* _allocate-app */ obj_t 
_allocate_app_162_ast_node(obj_t env_2912)
{
   {
      app_t aux_4797;
      aux_4797 = allocate_app_15_ast_node();
      return (obj_t) (aux_4797);
   }
}


/* app? */ bool_t 
app__230_ast_node(obj_t obj_332)
{
   return is_a__118___object(obj_332, app_ast_node);
}


/* _app? */ obj_t 
_app__141_ast_node(obj_t env_3375, obj_t obj_3376)
{
   {
      bool_t aux_4801;
      aux_4801 = app__230_ast_node(obj_3376);
      return BBOOL(aux_4801);
   }
}


/* make-app */ app_t 
make_app_213_ast_node(obj_t loc_333, type_t type_334, obj_t side_effect__165_335, obj_t key_336, var_t fun_337, obj_t args_338, obj_t stack_info_255_339)
{
   {
      app_t new1346_2009;
      new1346_2009 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
      {
	 long arg2090_2010;
	 arg2090_2010 = class_num_218___object(app_ast_node);
	 {
	    obj_t obj_2018;
	    obj_2018 = (obj_t) (new1346_2009);
	    (((obj_t) CREF(obj_2018))->header = MAKE_HEADER(arg2090_2010, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4808;
	 aux_4808 = (object_t) (new1346_2009);
	 OBJECT_WIDENING_SET(aux_4808, BFALSE);
      }
      ((((app_t) CREF(new1346_2009))->loc) = ((obj_t) loc_333), BUNSPEC);
      ((((app_t) CREF(new1346_2009))->type) = ((type_t) type_334), BUNSPEC);
      ((((app_t) CREF(new1346_2009))->side_effect__165) = ((obj_t) side_effect__165_335), BUNSPEC);
      ((((app_t) CREF(new1346_2009))->key) = ((obj_t) key_336), BUNSPEC);
      ((((app_t) CREF(new1346_2009))->fun) = ((var_t) fun_337), BUNSPEC);
      ((((app_t) CREF(new1346_2009))->args) = ((obj_t) args_338), BUNSPEC);
      ((((app_t) CREF(new1346_2009))->stack_info_255) = ((obj_t) stack_info_255_339), BUNSPEC);
      return new1346_2009;
   }
}


/* _make-app2628 */ obj_t 
_make_app2628_2_ast_node(obj_t env_3377, obj_t loc_3378, obj_t type_3379, obj_t side_effect__165_3380, obj_t key_3381, obj_t fun_3382, obj_t args_3383, obj_t stack_info_255_3384)
{
   {
      app_t aux_4818;
      aux_4818 = make_app_213_ast_node(loc_3378, (type_t) (type_3379), side_effect__165_3380, key_3381, (var_t) (fun_3382), args_3383, stack_info_255_3384);
      return (obj_t) (aux_4818);
   }
}


/* app-loc */ obj_t 
app_loc_208_ast_node(app_t obj_340)
{
   return (((app_t) CREF(obj_340))->loc);
}


/* _app-loc2629 */ obj_t 
_app_loc2629_107_ast_node(obj_t env_3385, obj_t obj_3386)
{
   return app_loc_208_ast_node((app_t) (obj_3386));
}


/* app-type-set! */ obj_t 
app_type_set__90_ast_node(app_t obj_341, type_t val1355_342)
{
   return ((((app_t) CREF(obj_341))->type) = ((type_t) val1355_342), BUNSPEC);
}


/* _app-type-set!2630 */ obj_t 
_app_type_set_2630_109_ast_node(obj_t env_3387, obj_t obj_3388, obj_t val1355_3389)
{
   return app_type_set__90_ast_node((app_t) (obj_3388), (type_t) (val1355_3389));
}


/* app-type */ type_t 
app_type_114_ast_node(app_t obj_343)
{
   return (((app_t) CREF(obj_343))->type);
}


/* _app-type2631 */ obj_t 
_app_type2631_39_ast_node(obj_t env_3390, obj_t obj_3391)
{
   {
      type_t aux_4831;
      aux_4831 = app_type_114_ast_node((app_t) (obj_3391));
      return (obj_t) (aux_4831);
   }
}


/* app-side-effect?-set! */ obj_t 
app_side_effect__set__78_ast_node(app_t obj_344, obj_t val1356_345)
{
   return ((((app_t) CREF(obj_344))->side_effect__165) = ((obj_t) val1356_345), BUNSPEC);
}


/* _app-side-effect?-set!2632 */ obj_t 
_app_side_effect__set_2632_76_ast_node(obj_t env_3392, obj_t obj_3393, obj_t val1356_3394)
{
   return app_side_effect__set__78_ast_node((app_t) (obj_3393), val1356_3394);
}


/* app-side-effect? */ obj_t 
app_side_effect__179_ast_node(app_t obj_346)
{
   return (((app_t) CREF(obj_346))->side_effect__165);
}


/* _app-side-effect?2633 */ obj_t 
_app_side_effect_2633_41_ast_node(obj_t env_3395, obj_t obj_3396)
{
   return app_side_effect__179_ast_node((app_t) (obj_3396));
}


/* app-key-set! */ obj_t 
app_key_set__45_ast_node(app_t obj_347, obj_t val1357_348)
{
   return ((((app_t) CREF(obj_347))->key) = ((obj_t) val1357_348), BUNSPEC);
}


/* _app-key-set! */ obj_t 
_app_key_set__226_ast_node(obj_t env_3397, obj_t obj_3398, obj_t val1357_3399)
{
   return app_key_set__45_ast_node((app_t) (obj_3398), val1357_3399);
}


/* app-key */ obj_t 
app_key_150_ast_node(app_t obj_349)
{
   return (((app_t) CREF(obj_349))->key);
}


/* _app-key */ obj_t 
_app_key_202_ast_node(obj_t env_3400, obj_t obj_3401)
{
   return app_key_150_ast_node((app_t) (obj_3401));
}


/* app-fun-set! */ obj_t 
app_fun_set__26_ast_node(app_t obj_350, var_t val1358_351)
{
   return ((((app_t) CREF(obj_350))->fun) = ((var_t) val1358_351), BUNSPEC);
}


/* _app-fun-set!2634 */ obj_t 
_app_fun_set_2634_22_ast_node(obj_t env_3402, obj_t obj_3403, obj_t val1358_3404)
{
   return app_fun_set__26_ast_node((app_t) (obj_3403), (var_t) (val1358_3404));
}


/* app-fun */ var_t 
app_fun_173_ast_node(app_t obj_352)
{
   return (((app_t) CREF(obj_352))->fun);
}


/* _app-fun2635 */ obj_t 
_app_fun2635_82_ast_node(obj_t env_3405, obj_t obj_3406)
{
   {
      var_t aux_4852;
      aux_4852 = app_fun_173_ast_node((app_t) (obj_3406));
      return (obj_t) (aux_4852);
   }
}


/* app-args-set! */ obj_t 
app_args_set__223_ast_node(app_t obj_353, obj_t val1359_354)
{
   return ((((app_t) CREF(obj_353))->args) = ((obj_t) val1359_354), BUNSPEC);
}


/* _app-args-set!2636 */ obj_t 
_app_args_set_2636_222_ast_node(obj_t env_3407, obj_t obj_3408, obj_t val1359_3409)
{
   return app_args_set__223_ast_node((app_t) (obj_3408), val1359_3409);
}


/* app-args */ obj_t 
app_args_229_ast_node(app_t obj_355)
{
   return (((app_t) CREF(obj_355))->args);
}


/* _app-args2637 */ obj_t 
_app_args2637_94_ast_node(obj_t env_3410, obj_t obj_3411)
{
   return app_args_229_ast_node((app_t) (obj_3411));
}


/* app-stack-info-set! */ obj_t 
app_stack_info_set__168_ast_node(app_t obj_356, obj_t val1360_357)
{
   return ((((app_t) CREF(obj_356))->stack_info_255) = ((obj_t) val1360_357), BUNSPEC);
}


/* _app-stack-info-set!2638 */ obj_t 
_app_stack_info_set_2638_87_ast_node(obj_t env_3412, obj_t obj_3413, obj_t val1360_3414)
{
   return app_stack_info_set__168_ast_node((app_t) (obj_3413), val1360_3414);
}


/* app-stack-info */ obj_t 
app_stack_info_87_ast_node(app_t obj_358)
{
   return (((app_t) CREF(obj_358))->stack_info_255);
}


/* _app-stack-info2639 */ obj_t 
_app_stack_info2639_72_ast_node(obj_t env_3415, obj_t obj_3416)
{
   return app_stack_info_87_ast_node((app_t) (obj_3416));
}


/* allocate-sequence */ sequence_t 
allocate_sequence_235_ast_node()
{
   {
      sequence_t new1323_1000;
      new1323_1000 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
      {
	 long arg2091_1001;
	 arg2091_1001 = class_num_218___object(sequence_ast_node);
	 {
	    obj_t obj_2020;
	    obj_2020 = (obj_t) (new1323_1000);
	    (((obj_t) CREF(obj_2020))->header = MAKE_HEADER(arg2091_1001, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4872;
	 aux_4872 = (object_t) (new1323_1000);
	 OBJECT_WIDENING_SET(aux_4872, BFALSE);
      }
      return new1323_1000;
   }
}


/* _allocate-sequence */ obj_t 
_allocate_sequence_156_ast_node(obj_t env_2911)
{
   {
      sequence_t aux_4875;
      aux_4875 = allocate_sequence_235_ast_node();
      return (obj_t) (aux_4875);
   }
}


/* sequence? */ bool_t 
sequence__190_ast_node(obj_t obj_362)
{
   return is_a__118___object(obj_362, sequence_ast_node);
}


/* _sequence? */ obj_t 
_sequence__76_ast_node(obj_t env_3417, obj_t obj_3418)
{
   {
      bool_t aux_4879;
      aux_4879 = sequence__190_ast_node(obj_3418);
      return BBOOL(aux_4879);
   }
}


/* make-sequence */ sequence_t 
make_sequence_237_ast_node(obj_t loc_363, type_t type_364, obj_t side_effect__165_365, obj_t key_366, obj_t nodes_367)
{
   {
      sequence_t new1313_2022;
      new1313_2022 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
      {
	 long arg2092_2023;
	 arg2092_2023 = class_num_218___object(sequence_ast_node);
	 {
	    obj_t obj_2029;
	    obj_2029 = (obj_t) (new1313_2022);
	    (((obj_t) CREF(obj_2029))->header = MAKE_HEADER(arg2092_2023, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4886;
	 aux_4886 = (object_t) (new1313_2022);
	 OBJECT_WIDENING_SET(aux_4886, BFALSE);
      }
      ((((sequence_t) CREF(new1313_2022))->loc) = ((obj_t) loc_363), BUNSPEC);
      ((((sequence_t) CREF(new1313_2022))->type) = ((type_t) type_364), BUNSPEC);
      ((((sequence_t) CREF(new1313_2022))->side_effect__165) = ((obj_t) side_effect__165_365), BUNSPEC);
      ((((sequence_t) CREF(new1313_2022))->key) = ((obj_t) key_366), BUNSPEC);
      ((((sequence_t) CREF(new1313_2022))->nodes) = ((obj_t) nodes_367), BUNSPEC);
      return new1313_2022;
   }
}


/* _make-sequence2640 */ obj_t 
_make_sequence2640_62_ast_node(obj_t env_3419, obj_t loc_3420, obj_t type_3421, obj_t side_effect__165_3422, obj_t key_3423, obj_t nodes_3424)
{
   {
      sequence_t aux_4894;
      aux_4894 = make_sequence_237_ast_node(loc_3420, (type_t) (type_3421), side_effect__165_3422, key_3423, nodes_3424);
      return (obj_t) (aux_4894);
   }
}


/* sequence-loc */ obj_t 
sequence_loc_124_ast_node(sequence_t obj_368)
{
   return (((sequence_t) CREF(obj_368))->loc);
}


/* _sequence-loc2641 */ obj_t 
_sequence_loc2641_133_ast_node(obj_t env_3425, obj_t obj_3426)
{
   return sequence_loc_124_ast_node((sequence_t) (obj_3426));
}


/* sequence-type-set! */ obj_t 
sequence_type_set__237_ast_node(sequence_t obj_369, type_t val1320_370)
{
   return ((((sequence_t) CREF(obj_369))->type) = ((type_t) val1320_370), BUNSPEC);
}


/* _sequence-type-set!2642 */ obj_t 
_sequence_type_set_2642_133_ast_node(obj_t env_3427, obj_t obj_3428, obj_t val1320_3429)
{
   return sequence_type_set__237_ast_node((sequence_t) (obj_3428), (type_t) (val1320_3429));
}


/* sequence-type */ type_t 
sequence_type_18_ast_node(sequence_t obj_371)
{
   return (((sequence_t) CREF(obj_371))->type);
}


/* _sequence-type2643 */ obj_t 
_sequence_type2643_232_ast_node(obj_t env_3430, obj_t obj_3431)
{
   {
      type_t aux_4906;
      aux_4906 = sequence_type_18_ast_node((sequence_t) (obj_3431));
      return (obj_t) (aux_4906);
   }
}


/* sequence-side-effect?-set! */ obj_t 
sequence_side_effect__set__38_ast_node(sequence_t obj_372, obj_t val1321_373)
{
   return ((((sequence_t) CREF(obj_372))->side_effect__165) = ((obj_t) val1321_373), BUNSPEC);
}


/* _sequence-side-effect?-set!2644 */ obj_t 
_sequence_side_effect__set_2644_117_ast_node(obj_t env_3432, obj_t obj_3433, obj_t val1321_3434)
{
   return sequence_side_effect__set__38_ast_node((sequence_t) (obj_3433), val1321_3434);
}


/* sequence-side-effect? */ obj_t 
sequence_side_effect__144_ast_node(sequence_t obj_374)
{
   return (((sequence_t) CREF(obj_374))->side_effect__165);
}


/* _sequence-side-effect?2645 */ obj_t 
_sequence_side_effect_2645_115_ast_node(obj_t env_3435, obj_t obj_3436)
{
   return sequence_side_effect__144_ast_node((sequence_t) (obj_3436));
}


/* sequence-key-set! */ obj_t 
sequence_key_set__139_ast_node(sequence_t obj_375, obj_t val1322_376)
{
   return ((((sequence_t) CREF(obj_375))->key) = ((obj_t) val1322_376), BUNSPEC);
}


/* _sequence-key-set! */ obj_t 
_sequence_key_set__223_ast_node(obj_t env_3437, obj_t obj_3438, obj_t val1322_3439)
{
   return sequence_key_set__139_ast_node((sequence_t) (obj_3438), val1322_3439);
}


/* sequence-key */ obj_t 
sequence_key_75_ast_node(sequence_t obj_377)
{
   return (((sequence_t) CREF(obj_377))->key);
}


/* _sequence-key */ obj_t 
_sequence_key_229_ast_node(obj_t env_3440, obj_t obj_3441)
{
   return sequence_key_75_ast_node((sequence_t) (obj_3441));
}


/* sequence-nodes */ obj_t 
sequence_nodes_243_ast_node(sequence_t obj_378)
{
   return (((sequence_t) CREF(obj_378))->nodes);
}


/* _sequence-nodes2646 */ obj_t 
_sequence_nodes2646_170_ast_node(obj_t env_3442, obj_t obj_3443)
{
   return sequence_nodes_243_ast_node((sequence_t) (obj_3443));
}


/* allocate-kwote */ kwote_t 
allocate_kwote_110_ast_node()
{
   {
      kwote_t new1298_1009;
      new1298_1009 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
      {
	 long arg2093_1010;
	 arg2093_1010 = class_num_218___object(kwote_ast_node);
	 {
	    obj_t obj_2031;
	    obj_2031 = (obj_t) (new1298_1009);
	    (((obj_t) CREF(obj_2031))->header = MAKE_HEADER(arg2093_1010, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4929;
	 aux_4929 = (object_t) (new1298_1009);
	 OBJECT_WIDENING_SET(aux_4929, BFALSE);
      }
      return new1298_1009;
   }
}


/* _allocate-kwote */ obj_t 
_allocate_kwote_245_ast_node(obj_t env_2910)
{
   {
      kwote_t aux_4932;
      aux_4932 = allocate_kwote_110_ast_node();
      return (obj_t) (aux_4932);
   }
}


/* kwote? */ bool_t 
kwote__251_ast_node(obj_t obj_382)
{
   return is_a__118___object(obj_382, kwote_ast_node);
}


/* _kwote? */ obj_t 
_kwote__112_ast_node(obj_t env_3444, obj_t obj_3445)
{
   {
      bool_t aux_4936;
      aux_4936 = kwote__251_ast_node(obj_3445);
      return BBOOL(aux_4936);
   }
}


/* make-kwote */ kwote_t 
make_kwote_191_ast_node(obj_t loc_383, type_t type_384, obj_t value_385)
{
   {
      kwote_t new1292_2033;
      new1292_2033 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
      {
	 long arg2094_2034;
	 arg2094_2034 = class_num_218___object(kwote_ast_node);
	 {
	    obj_t obj_2038;
	    obj_2038 = (obj_t) (new1292_2033);
	    (((obj_t) CREF(obj_2038))->header = MAKE_HEADER(arg2094_2034, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4943;
	 aux_4943 = (object_t) (new1292_2033);
	 OBJECT_WIDENING_SET(aux_4943, BFALSE);
      }
      ((((kwote_t) CREF(new1292_2033))->loc) = ((obj_t) loc_383), BUNSPEC);
      ((((kwote_t) CREF(new1292_2033))->type) = ((type_t) type_384), BUNSPEC);
      ((((kwote_t) CREF(new1292_2033))->value) = ((obj_t) value_385), BUNSPEC);
      return new1292_2033;
   }
}


/* _make-kwote2647 */ obj_t 
_make_kwote2647_26_ast_node(obj_t env_3446, obj_t loc_3447, obj_t type_3448, obj_t value_3449)
{
   {
      kwote_t aux_4949;
      aux_4949 = make_kwote_191_ast_node(loc_3447, (type_t) (type_3448), value_3449);
      return (obj_t) (aux_4949);
   }
}


/* kwote-loc */ obj_t 
kwote_loc_85_ast_node(kwote_t obj_386)
{
   return (((kwote_t) CREF(obj_386))->loc);
}


/* _kwote-loc2648 */ obj_t 
_kwote_loc2648_52_ast_node(obj_t env_3450, obj_t obj_3451)
{
   return kwote_loc_85_ast_node((kwote_t) (obj_3451));
}


/* kwote-type-set! */ obj_t 
kwote_type_set__119_ast_node(kwote_t obj_387, type_t val1297_388)
{
   return ((((kwote_t) CREF(obj_387))->type) = ((type_t) val1297_388), BUNSPEC);
}


/* _kwote-type-set!2649 */ obj_t 
_kwote_type_set_2649_70_ast_node(obj_t env_3452, obj_t obj_3453, obj_t val1297_3454)
{
   return kwote_type_set__119_ast_node((kwote_t) (obj_3453), (type_t) (val1297_3454));
}


/* kwote-type */ type_t 
kwote_type_217_ast_node(kwote_t obj_389)
{
   return (((kwote_t) CREF(obj_389))->type);
}


/* _kwote-type2650 */ obj_t 
_kwote_type2650_225_ast_node(obj_t env_3455, obj_t obj_3456)
{
   {
      type_t aux_4961;
      aux_4961 = kwote_type_217_ast_node((kwote_t) (obj_3456));
      return (obj_t) (aux_4961);
   }
}


/* kwote-value */ obj_t 
kwote_value_104_ast_node(kwote_t obj_390)
{
   return (((kwote_t) CREF(obj_390))->value);
}


/* _kwote-value2651 */ obj_t 
_kwote_value2651_145_ast_node(obj_t env_3457, obj_t obj_3458)
{
   return kwote_value_104_ast_node((kwote_t) (obj_3458));
}


/* allocate-closure */ closure_t 
allocate_closure_237_ast_node()
{
   {
      closure_t new1277_1016;
      new1277_1016 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
      {
	 long arg2095_1017;
	 arg2095_1017 = class_num_218___object(closure_ast_node);
	 {
	    obj_t obj_2040;
	    obj_2040 = (obj_t) (new1277_1016);
	    (((obj_t) CREF(obj_2040))->header = MAKE_HEADER(arg2095_1017, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4972;
	 aux_4972 = (object_t) (new1277_1016);
	 OBJECT_WIDENING_SET(aux_4972, BFALSE);
      }
      return new1277_1016;
   }
}


/* _allocate-closure */ obj_t 
_allocate_closure_68_ast_node(obj_t env_2909)
{
   {
      closure_t aux_4975;
      aux_4975 = allocate_closure_237_ast_node();
      return (obj_t) (aux_4975);
   }
}


/* closure? */ bool_t 
closure__53_ast_node(obj_t obj_394)
{
   return is_a__118___object(obj_394, closure_ast_node);
}


/* _closure? */ obj_t 
_closure__33_ast_node(obj_t env_3459, obj_t obj_3460)
{
   {
      bool_t aux_4979;
      aux_4979 = closure__53_ast_node(obj_3460);
      return BBOOL(aux_4979);
   }
}


/* make-closure */ closure_t 
make_closure_70_ast_node(obj_t loc_395, type_t type_396, variable_t variable_397)
{
   {
      closure_t new1270_2042;
      new1270_2042 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
      {
	 long arg2096_2043;
	 arg2096_2043 = class_num_218___object(closure_ast_node);
	 {
	    obj_t obj_2047;
	    obj_2047 = (obj_t) (new1270_2042);
	    (((obj_t) CREF(obj_2047))->header = MAKE_HEADER(arg2096_2043, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_4986;
	 aux_4986 = (object_t) (new1270_2042);
	 OBJECT_WIDENING_SET(aux_4986, BFALSE);
      }
      ((((closure_t) CREF(new1270_2042))->loc) = ((obj_t) loc_395), BUNSPEC);
      ((((closure_t) CREF(new1270_2042))->type) = ((type_t) type_396), BUNSPEC);
      ((((closure_t) CREF(new1270_2042))->variable) = ((variable_t) variable_397), BUNSPEC);
      return new1270_2042;
   }
}


/* _make-closure2652 */ obj_t 
_make_closure2652_85_ast_node(obj_t env_3461, obj_t loc_3462, obj_t type_3463, obj_t variable_3464)
{
   {
      closure_t aux_4992;
      aux_4992 = make_closure_70_ast_node(loc_3462, (type_t) (type_3463), (variable_t) (variable_3464));
      return (obj_t) (aux_4992);
   }
}


/* closure-loc */ obj_t 
closure_loc_195_ast_node(closure_t obj_398)
{
   return (((closure_t) CREF(obj_398))->loc);
}


/* _closure-loc2653 */ obj_t 
_closure_loc2653_80_ast_node(obj_t env_3465, obj_t obj_3466)
{
   return closure_loc_195_ast_node((closure_t) (obj_3466));
}


/* closure-type-set! */ obj_t 
closure_type_set__162_ast_node(closure_t obj_399, type_t val1275_400)
{
   return ((((closure_t) CREF(obj_399))->type) = ((type_t) val1275_400), BUNSPEC);
}


/* _closure-type-set!2654 */ obj_t 
_closure_type_set_2654_234_ast_node(obj_t env_3467, obj_t obj_3468, obj_t val1275_3469)
{
   return closure_type_set__162_ast_node((closure_t) (obj_3468), (type_t) (val1275_3469));
}


/* closure-type */ type_t 
closure_type_101_ast_node(closure_t obj_401)
{
   return (((closure_t) CREF(obj_401))->type);
}


/* _closure-type2655 */ obj_t 
_closure_type2655_215_ast_node(obj_t env_3470, obj_t obj_3471)
{
   {
      type_t aux_5005;
      aux_5005 = closure_type_101_ast_node((closure_t) (obj_3471));
      return (obj_t) (aux_5005);
   }
}


/* closure-variable-set! */ obj_t 
closure_variable_set__129_ast_node(closure_t obj_402, variable_t val1276_403)
{
   return ((((closure_t) CREF(obj_402))->variable) = ((variable_t) val1276_403), BUNSPEC);
}


/* _closure-variable-set!2656 */ obj_t 
_closure_variable_set_2656_122_ast_node(obj_t env_3472, obj_t obj_3473, obj_t val1276_3474)
{
   return closure_variable_set__129_ast_node((closure_t) (obj_3473), (variable_t) (val1276_3474));
}


/* closure-variable */ variable_t 
closure_variable_234_ast_node(closure_t obj_404)
{
   return (((closure_t) CREF(obj_404))->variable);
}


/* _closure-variable2657 */ obj_t 
_closure_variable2657_254_ast_node(obj_t env_3475, obj_t obj_3476)
{
   {
      variable_t aux_5014;
      aux_5014 = closure_variable_234_ast_node((closure_t) (obj_3476));
      return (obj_t) (aux_5014);
   }
}


/* allocate-var */ var_t 
allocate_var_186_ast_node()
{
   {
      var_t new1255_1023;
      new1255_1023 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
      {
	 long arg2097_1024;
	 arg2097_1024 = class_num_218___object(var_ast_node);
	 {
	    obj_t obj_2049;
	    obj_2049 = (obj_t) (new1255_1023);
	    (((obj_t) CREF(obj_2049))->header = MAKE_HEADER(arg2097_1024, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5022;
	 aux_5022 = (object_t) (new1255_1023);
	 OBJECT_WIDENING_SET(aux_5022, BFALSE);
      }
      return new1255_1023;
   }
}


/* _allocate-var */ obj_t 
_allocate_var_93_ast_node(obj_t env_2908)
{
   {
      var_t aux_5025;
      aux_5025 = allocate_var_186_ast_node();
      return (obj_t) (aux_5025);
   }
}


/* var? */ bool_t 
var__222_ast_node(obj_t obj_408)
{
   return is_a__118___object(obj_408, var_ast_node);
}


/* _var? */ obj_t 
_var__148_ast_node(obj_t env_3477, obj_t obj_3478)
{
   {
      bool_t aux_5029;
      aux_5029 = var__222_ast_node(obj_3478);
      return BBOOL(aux_5029);
   }
}


/* make-var */ var_t 
make_var_69_ast_node(obj_t loc_409, type_t type_410, variable_t variable_411)
{
   {
      var_t new1248_2051;
      new1248_2051 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
      {
	 long arg2098_2052;
	 arg2098_2052 = class_num_218___object(var_ast_node);
	 {
	    obj_t obj_2056;
	    obj_2056 = (obj_t) (new1248_2051);
	    (((obj_t) CREF(obj_2056))->header = MAKE_HEADER(arg2098_2052, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5036;
	 aux_5036 = (object_t) (new1248_2051);
	 OBJECT_WIDENING_SET(aux_5036, BFALSE);
      }
      ((((var_t) CREF(new1248_2051))->loc) = ((obj_t) loc_409), BUNSPEC);
      ((((var_t) CREF(new1248_2051))->type) = ((type_t) type_410), BUNSPEC);
      ((((var_t) CREF(new1248_2051))->variable) = ((variable_t) variable_411), BUNSPEC);
      return new1248_2051;
   }
}


/* _make-var2658 */ obj_t 
_make_var2658_215_ast_node(obj_t env_3479, obj_t loc_3480, obj_t type_3481, obj_t variable_3482)
{
   {
      var_t aux_5042;
      aux_5042 = make_var_69_ast_node(loc_3480, (type_t) (type_3481), (variable_t) (variable_3482));
      return (obj_t) (aux_5042);
   }
}


/* var-loc */ obj_t 
var_loc_140_ast_node(var_t obj_412)
{
   return (((var_t) CREF(obj_412))->loc);
}


/* _var-loc2659 */ obj_t 
_var_loc2659_203_ast_node(obj_t env_3483, obj_t obj_3484)
{
   return var_loc_140_ast_node((var_t) (obj_3484));
}


/* var-type-set! */ obj_t 
var_type_set__45_ast_node(var_t obj_413, type_t val1253_414)
{
   return ((((var_t) CREF(obj_413))->type) = ((type_t) val1253_414), BUNSPEC);
}


/* _var-type-set!2660 */ obj_t 
_var_type_set_2660_138_ast_node(obj_t env_3485, obj_t obj_3486, obj_t val1253_3487)
{
   return var_type_set__45_ast_node((var_t) (obj_3486), (type_t) (val1253_3487));
}


/* var-type */ type_t 
var_type_150_ast_node(var_t obj_415)
{
   return (((var_t) CREF(obj_415))->type);
}


/* _var-type2661 */ obj_t 
_var_type2661_41_ast_node(obj_t env_3488, obj_t obj_3489)
{
   {
      type_t aux_5055;
      aux_5055 = var_type_150_ast_node((var_t) (obj_3489));
      return (obj_t) (aux_5055);
   }
}


/* var-variable-set! */ obj_t 
var_variable_set__90_ast_node(var_t obj_416, variable_t val1254_417)
{
   return ((((var_t) CREF(obj_416))->variable) = ((variable_t) val1254_417), BUNSPEC);
}


/* _var-variable-set!2662 */ obj_t 
_var_variable_set_2662_236_ast_node(obj_t env_3490, obj_t obj_3491, obj_t val1254_3492)
{
   return var_variable_set__90_ast_node((var_t) (obj_3491), (variable_t) (val1254_3492));
}


/* var-variable */ variable_t 
var_variable_114_ast_node(var_t obj_418)
{
   return (((var_t) CREF(obj_418))->variable);
}


/* _var-variable2663 */ obj_t 
_var_variable2663_13_ast_node(obj_t env_3493, obj_t obj_3494)
{
   {
      variable_t aux_5064;
      aux_5064 = var_variable_114_ast_node((var_t) (obj_3494));
      return (obj_t) (aux_5064);
   }
}


/* allocate-atom */ atom_t 
allocate_atom_199_ast_node()
{
   {
      atom_t new1233_1030;
      new1233_1030 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
      {
	 long arg2099_1031;
	 arg2099_1031 = class_num_218___object(atom_ast_node);
	 {
	    obj_t obj_2058;
	    obj_2058 = (obj_t) (new1233_1030);
	    (((obj_t) CREF(obj_2058))->header = MAKE_HEADER(arg2099_1031, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5072;
	 aux_5072 = (object_t) (new1233_1030);
	 OBJECT_WIDENING_SET(aux_5072, BFALSE);
      }
      return new1233_1030;
   }
}


/* _allocate-atom */ obj_t 
_allocate_atom_130_ast_node(obj_t env_2907)
{
   {
      atom_t aux_5075;
      aux_5075 = allocate_atom_199_ast_node();
      return (obj_t) (aux_5075);
   }
}


/* atom? */ bool_t 
atom__231_ast_node(obj_t obj_422)
{
   return is_a__118___object(obj_422, atom_ast_node);
}


/* _atom? */ obj_t 
_atom__186_ast_node(obj_t env_3495, obj_t obj_3496)
{
   {
      bool_t aux_5079;
      aux_5079 = atom__231_ast_node(obj_3496);
      return BBOOL(aux_5079);
   }
}


/* make-atom */ atom_t 
make_atom_145_ast_node(obj_t loc_423, type_t type_424, obj_t value_425)
{
   {
      atom_t new1226_2060;
      new1226_2060 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
      {
	 long arg2100_2061;
	 arg2100_2061 = class_num_218___object(atom_ast_node);
	 {
	    obj_t obj_2065;
	    obj_2065 = (obj_t) (new1226_2060);
	    (((obj_t) CREF(obj_2065))->header = MAKE_HEADER(arg2100_2061, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5086;
	 aux_5086 = (object_t) (new1226_2060);
	 OBJECT_WIDENING_SET(aux_5086, BFALSE);
      }
      ((((atom_t) CREF(new1226_2060))->loc) = ((obj_t) loc_423), BUNSPEC);
      ((((atom_t) CREF(new1226_2060))->type) = ((type_t) type_424), BUNSPEC);
      ((((atom_t) CREF(new1226_2060))->value) = ((obj_t) value_425), BUNSPEC);
      return new1226_2060;
   }
}


/* _make-atom2664 */ obj_t 
_make_atom2664_96_ast_node(obj_t env_3497, obj_t loc_3498, obj_t type_3499, obj_t value_3500)
{
   {
      atom_t aux_5092;
      aux_5092 = make_atom_145_ast_node(loc_3498, (type_t) (type_3499), value_3500);
      return (obj_t) (aux_5092);
   }
}


/* atom-loc */ obj_t 
atom_loc_1_ast_node(atom_t obj_426)
{
   return (((atom_t) CREF(obj_426))->loc);
}


/* _atom-loc2665 */ obj_t 
_atom_loc2665_165_ast_node(obj_t env_3501, obj_t obj_3502)
{
   return atom_loc_1_ast_node((atom_t) (obj_3502));
}


/* atom-type-set! */ obj_t 
atom_type_set__253_ast_node(atom_t obj_427, type_t val1231_428)
{
   return ((((atom_t) CREF(obj_427))->type) = ((type_t) val1231_428), BUNSPEC);
}


/* _atom-type-set!2666 */ obj_t 
_atom_type_set_2666_88_ast_node(obj_t env_3503, obj_t obj_3504, obj_t val1231_3505)
{
   return atom_type_set__253_ast_node((atom_t) (obj_3504), (type_t) (val1231_3505));
}


/* atom-type */ type_t 
atom_type_43_ast_node(atom_t obj_429)
{
   return (((atom_t) CREF(obj_429))->type);
}


/* _atom-type2667 */ obj_t 
_atom_type2667_50_ast_node(obj_t env_3506, obj_t obj_3507)
{
   {
      type_t aux_5104;
      aux_5104 = atom_type_43_ast_node((atom_t) (obj_3507));
      return (obj_t) (aux_5104);
   }
}


/* atom-value-set! */ obj_t 
atom_value_set__52_ast_node(atom_t obj_430, obj_t val1232_431)
{
   return ((((atom_t) CREF(obj_430))->value) = ((obj_t) val1232_431), BUNSPEC);
}


/* _atom-value-set!2668 */ obj_t 
_atom_value_set_2668_157_ast_node(obj_t env_3508, obj_t obj_3509, obj_t val1232_3510)
{
   return atom_value_set__52_ast_node((atom_t) (obj_3509), val1232_3510);
}


/* atom-value */ obj_t 
atom_value_177_ast_node(atom_t obj_432)
{
   return (((atom_t) CREF(obj_432))->value);
}


/* _atom-value2669 */ obj_t 
_atom_value2669_108_ast_node(obj_t env_3511, obj_t obj_3512)
{
   return atom_value_177_ast_node((atom_t) (obj_3512));
}


/* allocate-node/effect */ node_effect_213_t 
allocate_node_effect_98_ast_node()
{
   {
      node_effect_213_t new1207_1037;
      new1207_1037 = ((node_effect_213_t) BREF(GC_MALLOC(sizeof(struct node_effect_213))));
      {
	 long arg2101_1038;
	 arg2101_1038 = class_num_218___object(node_effect_213_ast_node);
	 {
	    obj_t obj_2067;
	    obj_2067 = (obj_t) (new1207_1037);
	    (((obj_t) CREF(obj_2067))->header = MAKE_HEADER(arg2101_1038, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5118;
	 aux_5118 = (object_t) (new1207_1037);
	 OBJECT_WIDENING_SET(aux_5118, BFALSE);
      }
      return new1207_1037;
   }
}


/* _allocate-node/effect */ obj_t 
_allocate_node_effect_20_ast_node(obj_t env_2906)
{
   {
      node_effect_213_t aux_5121;
      aux_5121 = allocate_node_effect_98_ast_node();
      return (obj_t) (aux_5121);
   }
}


/* node/effect? */ bool_t 
node_effect__37_ast_node(obj_t obj_436)
{
   return is_a__118___object(obj_436, node_effect_213_ast_node);
}


/* _node/effect? */ obj_t 
_node_effect__62_ast_node(obj_t env_3513, obj_t obj_3514)
{
   {
      bool_t aux_5125;
      aux_5125 = node_effect__37_ast_node(obj_3514);
      return BBOOL(aux_5125);
   }
}


/* make-node/effect */ node_effect_213_t 
make_node_effect_87_ast_node(obj_t loc_437, type_t type_438, obj_t side_effect__165_439, obj_t key_440)
{
   {
      node_effect_213_t new1198_2069;
      new1198_2069 = ((node_effect_213_t) BREF(GC_MALLOC(sizeof(struct node_effect_213))));
      {
	 long arg2102_2070;
	 arg2102_2070 = class_num_218___object(node_effect_213_ast_node);
	 {
	    obj_t obj_2075;
	    obj_2075 = (obj_t) (new1198_2069);
	    (((obj_t) CREF(obj_2075))->header = MAKE_HEADER(arg2102_2070, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5132;
	 aux_5132 = (object_t) (new1198_2069);
	 OBJECT_WIDENING_SET(aux_5132, BFALSE);
      }
      ((((node_effect_213_t) CREF(new1198_2069))->loc) = ((obj_t) loc_437), BUNSPEC);
      ((((node_effect_213_t) CREF(new1198_2069))->type) = ((type_t) type_438), BUNSPEC);
      ((((node_effect_213_t) CREF(new1198_2069))->side_effect__165) = ((obj_t) side_effect__165_439), BUNSPEC);
      ((((node_effect_213_t) CREF(new1198_2069))->key) = ((obj_t) key_440), BUNSPEC);
      return new1198_2069;
   }
}


/* _make-node/effect2670 */ obj_t 
_make_node_effect2670_29_ast_node(obj_t env_3515, obj_t loc_3516, obj_t type_3517, obj_t side_effect__165_3518, obj_t key_3519)
{
   {
      node_effect_213_t aux_5139;
      aux_5139 = make_node_effect_87_ast_node(loc_3516, (type_t) (type_3517), side_effect__165_3518, key_3519);
      return (obj_t) (aux_5139);
   }
}


/* node/effect-loc */ obj_t 
node_effect_loc_61_ast_node(node_effect_213_t obj_441)
{
   return (((node_effect_213_t) CREF(obj_441))->loc);
}


/* _node/effect-loc2671 */ obj_t 
_node_effect_loc2671_156_ast_node(obj_t env_3520, obj_t obj_3521)
{
   return node_effect_loc_61_ast_node((node_effect_213_t) (obj_3521));
}


/* node/effect-type-set! */ obj_t 
node_effect_type_set__91_ast_node(node_effect_213_t obj_442, type_t val1204_443)
{
   return ((((node_effect_213_t) CREF(obj_442))->type) = ((type_t) val1204_443), BUNSPEC);
}


/* _node/effect-type-set!2672 */ obj_t 
_node_effect_type_set_2672_137_ast_node(obj_t env_3522, obj_t obj_3523, obj_t val1204_3524)
{
   return node_effect_type_set__91_ast_node((node_effect_213_t) (obj_3523), (type_t) (val1204_3524));
}


/* node/effect-type */ type_t 
node_effect_type_0_ast_node(node_effect_213_t obj_444)
{
   return (((node_effect_213_t) CREF(obj_444))->type);
}


/* _node/effect-type2673 */ obj_t 
_node_effect_type2673_60_ast_node(obj_t env_3525, obj_t obj_3526)
{
   {
      type_t aux_5151;
      aux_5151 = node_effect_type_0_ast_node((node_effect_213_t) (obj_3526));
      return (obj_t) (aux_5151);
   }
}


/* node/effect-side-effect?-set! */ obj_t 
node_effect_side_effect__set__83_ast_node(node_effect_213_t obj_445, obj_t val1205_446)
{
   return ((((node_effect_213_t) CREF(obj_445))->side_effect__165) = ((obj_t) val1205_446), BUNSPEC);
}


/* _node/effect-side-effect?-set!2674 */ obj_t 
_node_effect_side_effect__set_2674_173_ast_node(obj_t env_3527, obj_t obj_3528, obj_t val1205_3529)
{
   return node_effect_side_effect__set__83_ast_node((node_effect_213_t) (obj_3528), val1205_3529);
}


/* node/effect-side-effect? */ obj_t 
node_effect_side_effect__249_ast_node(node_effect_213_t obj_447)
{
   return (((node_effect_213_t) CREF(obj_447))->side_effect__165);
}


/* _node/effect-side-effect?2675 */ obj_t 
_node_effect_side_effect_2675_102_ast_node(obj_t env_3530, obj_t obj_3531)
{
   return node_effect_side_effect__249_ast_node((node_effect_213_t) (obj_3531));
}


/* node/effect-key-set! */ obj_t 
node_effect_key_set__83_ast_node(node_effect_213_t obj_448, obj_t val1206_449)
{
   return ((((node_effect_213_t) CREF(obj_448))->key) = ((obj_t) val1206_449), BUNSPEC);
}


/* _node/effect-key-set! */ obj_t 
_node_effect_key_set__9_ast_node(obj_t env_3532, obj_t obj_3533, obj_t val1206_3534)
{
   return node_effect_key_set__83_ast_node((node_effect_213_t) (obj_3533), val1206_3534);
}


/* node/effect-key */ obj_t 
node_effect_key_249_ast_node(node_effect_213_t obj_450)
{
   return (((node_effect_213_t) CREF(obj_450))->key);
}


/* _node/effect-key */ obj_t 
_node_effect_key_98_ast_node(obj_t env_3535, obj_t obj_3536)
{
   return node_effect_key_249_ast_node((node_effect_213_t) (obj_3536));
}


/* allocate-node */ node_t 
allocate_node_189_ast_node()
{
   {
      node_t new1187_1045;
      new1187_1045 = ((node_t) BREF(GC_MALLOC(sizeof(struct node))));
      {
	 long arg2103_1046;
	 arg2103_1046 = class_num_218___object(node_ast_node);
	 {
	    obj_t obj_2077;
	    obj_2077 = (obj_t) (new1187_1045);
	    (((obj_t) CREF(obj_2077))->header = MAKE_HEADER(arg2103_1046, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5171;
	 aux_5171 = (object_t) (new1187_1045);
	 OBJECT_WIDENING_SET(aux_5171, BFALSE);
      }
      return new1187_1045;
   }
}


/* _allocate-node */ obj_t 
_allocate_node_227_ast_node(obj_t env_2905)
{
   {
      node_t aux_5174;
      aux_5174 = allocate_node_189_ast_node();
      return (obj_t) (aux_5174);
   }
}


/* node? */ bool_t 
node__79_ast_node(obj_t obj_454)
{
   return is_a__118___object(obj_454, node_ast_node);
}


/* _node? */ obj_t 
_node__81_ast_node(obj_t env_3537, obj_t obj_3538)
{
   {
      bool_t aux_5178;
      aux_5178 = node__79_ast_node(obj_3538);
      return BBOOL(aux_5178);
   }
}


/* make-node */ node_t 
make_node_187_ast_node(obj_t loc_455, type_t type_456)
{
   {
      node_t new1182_2079;
      new1182_2079 = ((node_t) BREF(GC_MALLOC(sizeof(struct node))));
      {
	 long arg2105_2080;
	 arg2105_2080 = class_num_218___object(node_ast_node);
	 {
	    obj_t obj_2083;
	    obj_2083 = (obj_t) (new1182_2079);
	    (((obj_t) CREF(obj_2083))->header = MAKE_HEADER(arg2105_2080, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_5185;
	 aux_5185 = (object_t) (new1182_2079);
	 OBJECT_WIDENING_SET(aux_5185, BFALSE);
      }
      ((((node_t) CREF(new1182_2079))->loc) = ((obj_t) loc_455), BUNSPEC);
      ((((node_t) CREF(new1182_2079))->type) = ((type_t) type_456), BUNSPEC);
      return new1182_2079;
   }
}


/* _make-node2676 */ obj_t 
_make_node2676_204_ast_node(obj_t env_3539, obj_t loc_3540, obj_t type_3541)
{
   {
      node_t aux_5190;
      aux_5190 = make_node_187_ast_node(loc_3540, (type_t) (type_3541));
      return (obj_t) (aux_5190);
   }
}


/* node-loc */ obj_t 
node_loc_29_ast_node(node_t obj_457)
{
   return (((node_t) CREF(obj_457))->loc);
}


/* _node-loc2677 */ obj_t 
_node_loc2677_157_ast_node(obj_t env_3542, obj_t obj_3543)
{
   return node_loc_29_ast_node((node_t) (obj_3543));
}


/* node-type-set! */ obj_t 
node_type_set__235_ast_node(node_t obj_458, type_t val1186_459)
{
   return ((((node_t) CREF(obj_458))->type) = ((type_t) val1186_459), BUNSPEC);
}


/* _node-type-set!2678 */ obj_t 
_node_type_set_2678_183_ast_node(obj_t env_3544, obj_t obj_3545, obj_t val1186_3546)
{
   return node_type_set__235_ast_node((node_t) (obj_3545), (type_t) (val1186_3546));
}


/* node-type */ type_t 
node_type_175_ast_node(node_t obj_460)
{
   return (((node_t) CREF(obj_460))->type);
}


/* _node-type2679 */ obj_t 
_node_type2679_26_ast_node(obj_t env_3547, obj_t obj_3548)
{
   {
      type_t aux_5202;
      aux_5202 = node_type_175_ast_node((node_t) (obj_3548));
      return (obj_t) (aux_5202);
   }
}


/* method-init */ obj_t 
method_init_76_ast_node()
{
   {
      obj_t object__struct_box_set__198_3594;
      object__struct_box_set__198_3594 = proc2685_ast_node;
      add_method__1___object(object__struct_env_210___object, box_set__221_ast_node, object__struct_box_set__198_3594);
   }
   {
      obj_t struct_object__object_box_set__45_3593;
      struct_object__object_box_set__45_3593 = proc2686_ast_node;
      add_method__1___object(struct_object__object_env_209___object, box_set__221_ast_node, struct_object__object_box_set__45_3593);
   }
   {
      obj_t object__struct_box_ref_94_3592;
      object__struct_box_ref_94_3592 = proc2687_ast_node;
      add_method__1___object(object__struct_env_210___object, box_ref_242_ast_node, object__struct_box_ref_94_3592);
   }
   {
      obj_t struct_object__object_box_ref_217_3591;
      struct_object__object_box_ref_217_3591 = proc2688_ast_node;
      add_method__1___object(struct_object__object_env_209___object, box_ref_242_ast_node, struct_object__object_box_ref_217_3591);
   }
   {
      obj_t object__struct_make_box_59_3590;
      object__struct_make_box_59_3590 = proc2689_ast_node;
      add_method__1___object(object__struct_env_210___object, make_box_202_ast_node, object__struct_make_box_59_3590);
   }
   {
      obj_t struct_object__object_make_box_39_3589;
      struct_object__object_make_box_39_3589 = proc2690_ast_node;
      add_method__1___object(struct_object__object_env_209___object, make_box_202_ast_node, struct_object__object_make_box_39_3589);
   }
   {
      obj_t object__struct_jump_ex_it_205_3588;
      object__struct_jump_ex_it_205_3588 = proc2691_ast_node;
      add_method__1___object(object__struct_env_210___object, jump_ex_it_184_ast_node, object__struct_jump_ex_it_205_3588);
   }
   {
      obj_t struct_object__object_jump_ex_it_246_3587;
      struct_object__object_jump_ex_it_246_3587 = proc2692_ast_node;
      add_method__1___object(struct_object__object_env_209___object, jump_ex_it_184_ast_node, struct_object__object_jump_ex_it_246_3587);
   }
   {
      obj_t object__struct_set_ex_it_235_3586;
      object__struct_set_ex_it_235_3586 = proc2693_ast_node;
      add_method__1___object(object__struct_env_210___object, set_ex_it_116_ast_node, object__struct_set_ex_it_235_3586);
   }
   {
      obj_t struct_object__object_set_ex_it_208_3585;
      struct_object__object_set_ex_it_208_3585 = proc2694_ast_node;
      add_method__1___object(struct_object__object_env_209___object, set_ex_it_116_ast_node, struct_object__object_set_ex_it_208_3585);
   }
   {
      obj_t object__struct_let_var_26_3584;
      object__struct_let_var_26_3584 = proc2695_ast_node;
      add_method__1___object(object__struct_env_210___object, let_var_6_ast_node, object__struct_let_var_26_3584);
   }
   {
      obj_t struct_object__object_let_var_153_3583;
      struct_object__object_let_var_153_3583 = proc2696_ast_node;
      add_method__1___object(struct_object__object_env_209___object, let_var_6_ast_node, struct_object__object_let_var_153_3583);
   }
   {
      obj_t object__struct_let_fun_125_3582;
      object__struct_let_fun_125_3582 = proc2697_ast_node;
      add_method__1___object(object__struct_env_210___object, let_fun_218_ast_node, object__struct_let_fun_125_3582);
   }
   {
      obj_t struct_object__object_let_fun_200_3581;
      struct_object__object_let_fun_200_3581 = proc2698_ast_node;
      add_method__1___object(struct_object__object_env_209___object, let_fun_218_ast_node, struct_object__object_let_fun_200_3581);
   }
   {
      obj_t object__struct_select_180_3580;
      object__struct_select_180_3580 = proc2699_ast_node;
      add_method__1___object(object__struct_env_210___object, select_ast_node, object__struct_select_180_3580);
   }
   {
      obj_t struct_object__object_select_156_3579;
      struct_object__object_select_156_3579 = proc2700_ast_node;
      add_method__1___object(struct_object__object_env_209___object, select_ast_node, struct_object__object_select_156_3579);
   }
   {
      obj_t object__struct_fail_140_3578;
      object__struct_fail_140_3578 = proc2701_ast_node;
      add_method__1___object(object__struct_env_210___object, fail_ast_node, object__struct_fail_140_3578);
   }
   {
      obj_t struct_object__object_fail_96_3577;
      struct_object__object_fail_96_3577 = proc2702_ast_node;
      add_method__1___object(struct_object__object_env_209___object, fail_ast_node, struct_object__object_fail_96_3577);
   }
   {
      obj_t object__struct_conditional_60_3576;
      object__struct_conditional_60_3576 = proc2703_ast_node;
      add_method__1___object(object__struct_env_210___object, conditional_ast_node, object__struct_conditional_60_3576);
   }
   {
      obj_t struct_object__object_conditional_24_3575;
      struct_object__object_conditional_24_3575 = proc2704_ast_node;
      add_method__1___object(struct_object__object_env_209___object, conditional_ast_node, struct_object__object_conditional_24_3575);
   }
   {
      obj_t object__struct_setq_205_3574;
      object__struct_setq_205_3574 = proc2705_ast_node;
      add_method__1___object(object__struct_env_210___object, setq_ast_node, object__struct_setq_205_3574);
   }
   {
      obj_t struct_object__object_setq_124_3573;
      struct_object__object_setq_124_3573 = proc2706_ast_node;
      add_method__1___object(struct_object__object_env_209___object, setq_ast_node, struct_object__object_setq_124_3573);
   }
   {
      obj_t object__struct_cast_161_3572;
      object__struct_cast_161_3572 = proc2707_ast_node;
      add_method__1___object(object__struct_env_210___object, cast_ast_node, object__struct_cast_161_3572);
   }
   {
      obj_t struct_object__object_cast_16_3571;
      struct_object__object_cast_16_3571 = proc2708_ast_node;
      add_method__1___object(struct_object__object_env_209___object, cast_ast_node, struct_object__object_cast_16_3571);
   }
   {
      obj_t object__struct_pragma_207_3570;
      object__struct_pragma_207_3570 = proc2709_ast_node;
      add_method__1___object(object__struct_env_210___object, pragma_ast_node, object__struct_pragma_207_3570);
   }
   {
      obj_t struct_object__object_pragma_2_3569;
      struct_object__object_pragma_2_3569 = proc2710_ast_node;
      add_method__1___object(struct_object__object_env_209___object, pragma_ast_node, struct_object__object_pragma_2_3569);
   }
   {
      obj_t object__struct_funcall_68_3568;
      object__struct_funcall_68_3568 = proc2711_ast_node;
      add_method__1___object(object__struct_env_210___object, funcall_ast_node, object__struct_funcall_68_3568);
   }
   {
      obj_t struct_object__object_funcall_136_3567;
      struct_object__object_funcall_136_3567 = proc2712_ast_node;
      add_method__1___object(struct_object__object_env_209___object, funcall_ast_node, struct_object__object_funcall_136_3567);
   }
   {
      obj_t object__struct_app_ly_240_3566;
      object__struct_app_ly_240_3566 = proc2713_ast_node;
      add_method__1___object(object__struct_env_210___object, app_ly_162_ast_node, object__struct_app_ly_240_3566);
   }
   {
      obj_t struct_object__object_app_ly_165_3565;
      struct_object__object_app_ly_165_3565 = proc2714_ast_node;
      add_method__1___object(struct_object__object_env_209___object, app_ly_162_ast_node, struct_object__object_app_ly_165_3565);
   }
   {
      obj_t object__struct_app_142_3564;
      object__struct_app_142_3564 = proc2715_ast_node;
      add_method__1___object(object__struct_env_210___object, app_ast_node, object__struct_app_142_3564);
   }
   {
      obj_t struct_object__object_app_63_3563;
      struct_object__object_app_63_3563 = proc2716_ast_node;
      add_method__1___object(struct_object__object_env_209___object, app_ast_node, struct_object__object_app_63_3563);
   }
   {
      obj_t object__struct_sequence_112_3562;
      object__struct_sequence_112_3562 = proc2717_ast_node;
      add_method__1___object(object__struct_env_210___object, sequence_ast_node, object__struct_sequence_112_3562);
   }
   {
      obj_t struct_object__object_sequence_200_3561;
      struct_object__object_sequence_200_3561 = proc2718_ast_node;
      add_method__1___object(struct_object__object_env_209___object, sequence_ast_node, struct_object__object_sequence_200_3561);
   }
   {
      obj_t object__struct_kwote_66_3560;
      object__struct_kwote_66_3560 = proc2719_ast_node;
      add_method__1___object(object__struct_env_210___object, kwote_ast_node, object__struct_kwote_66_3560);
   }
   {
      obj_t struct_object__object_kwote_75_3559;
      struct_object__object_kwote_75_3559 = proc2720_ast_node;
      add_method__1___object(struct_object__object_env_209___object, kwote_ast_node, struct_object__object_kwote_75_3559);
   }
   {
      obj_t object__struct_closure_29_3558;
      object__struct_closure_29_3558 = proc2721_ast_node;
      add_method__1___object(object__struct_env_210___object, closure_ast_node, object__struct_closure_29_3558);
   }
   {
      obj_t struct_object__object_closure_48_3557;
      struct_object__object_closure_48_3557 = proc2722_ast_node;
      add_method__1___object(struct_object__object_env_209___object, closure_ast_node, struct_object__object_closure_48_3557);
   }
   {
      obj_t object__struct_var_159_3556;
      object__struct_var_159_3556 = proc2723_ast_node;
      add_method__1___object(object__struct_env_210___object, var_ast_node, object__struct_var_159_3556);
   }
   {
      obj_t struct_object__object_var_138_3555;
      struct_object__object_var_138_3555 = proc2724_ast_node;
      add_method__1___object(struct_object__object_env_209___object, var_ast_node, struct_object__object_var_138_3555);
   }
   {
      obj_t object__struct_atom_114_3554;
      object__struct_atom_114_3554 = proc2725_ast_node;
      add_method__1___object(object__struct_env_210___object, atom_ast_node, object__struct_atom_114_3554);
   }
   {
      obj_t struct_object__object_atom_177_3553;
      struct_object__object_atom_177_3553 = proc2726_ast_node;
      add_method__1___object(struct_object__object_env_209___object, atom_ast_node, struct_object__object_atom_177_3553);
   }
   {
      obj_t object__struct_node_effect_233_3552;
      object__struct_node_effect_233_3552 = proc2727_ast_node;
      add_method__1___object(object__struct_env_210___object, node_effect_213_ast_node, object__struct_node_effect_233_3552);
   }
   {
      obj_t struct_object__object_node_effect_227_3551;
      struct_object__object_node_effect_227_3551 = proc2728_ast_node;
      add_method__1___object(struct_object__object_env_209___object, node_effect_213_ast_node, struct_object__object_node_effect_227_3551);
   }
   {
      obj_t object__struct_node_0_3550;
      object__struct_node_0_3550 = proc2729_ast_node;
      add_method__1___object(object__struct_env_210___object, node_ast_node, object__struct_node_0_3550);
   }
   {
      obj_t struct_object__object_node_196_3549;
      struct_object__object_node_196_3549 = proc2730_ast_node;
      return add_method__1___object(struct_object__object_env_209___object, node_ast_node, struct_object__object_node_196_3549);
   }
}


/* struct+object->object-node */ obj_t 
struct_object__object_node_196_ast_node(obj_t env_3595, obj_t o_3596, obj_t s_3597)
{
   {
      node_t o_1832;
      obj_t s_1833;
      {
	 node_t aux_5252;
	 o_1832 = (node_t) (o_3596);
	 s_1833 = s_3597;
	 {
	    obj_t aux_5255;
	    object_t aux_5253;
	    aux_5255 = STRUCT_REF(s_1833, ((long) 0));
	    aux_5253 = (object_t) (o_1832);
	    OBJECT_WIDENING_SET(aux_5253, aux_5255);
	 }
	 {
	    obj_t v1192_1837;
	    v1192_1837 = STRUCT_REF(s_1833, ((long) 1));
	    ((((node_t) CREF(o_1832))->loc) = ((obj_t) v1192_1837), BUNSPEC);
	 }
	 {
	    type_t v1196_1838;
	    {
	       obj_t aux_5260;
	       aux_5260 = STRUCT_REF(s_1833, ((long) 2));
	       v1196_1838 = (type_t) (aux_5260);
	    }
	    ((((node_t) CREF(o_1832))->type) = ((type_t) v1196_1838), BUNSPEC);
	 }
	 aux_5252 = o_1832;
	 return (obj_t) (aux_5252);
      }
   }
}


/* object->struct-node */ obj_t 
object__struct_node_0_ast_node(obj_t env_3598, obj_t obj1188_3599)
{
   {
      node_t obj1188_1820;
      obj1188_1820 = (node_t) (obj1188_3599);
      {
	 obj_t res1189_1823;
	 {
	    obj_t aux_5266;
	    aux_5266 = CNST_TABLE_REF(((long) 0));
	    res1189_1823 = make_struct(aux_5266, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1189_1823, ((long) 0), BFALSE);
	 {
	    obj_t aux_5270;
	    aux_5270 = (((node_t) CREF(obj1188_1820))->loc);
	    STRUCT_SET(res1189_1823, ((long) 1), aux_5270);
	 }
	 {
	    obj_t aux_5273;
	    {
	       type_t aux_5274;
	       aux_5274 = (((node_t) CREF(obj1188_1820))->type);
	       aux_5273 = (obj_t) (aux_5274);
	    }
	    STRUCT_SET(res1189_1823, ((long) 2), aux_5273);
	 }
	 return res1189_1823;
      }
   }
}


/* struct+object->object-node/effect */ obj_t 
struct_object__object_node_effect_227_ast_node(obj_t env_3600, obj_t o_3601, obj_t s_3602)
{
   {
      node_effect_213_t o_1809;
      obj_t s_1810;
      {
	 node_effect_213_t aux_5279;
	 o_1809 = (node_effect_213_t) (o_3601);
	 s_1810 = s_3602;
	 {
	    obj_t aux_5282;
	    object_t aux_5280;
	    aux_5282 = STRUCT_REF(s_1810, ((long) 0));
	    aux_5280 = (object_t) (o_1809);
	    OBJECT_WIDENING_SET(aux_5280, aux_5282);
	 }
	 {
	    obj_t v1212_1814;
	    v1212_1814 = STRUCT_REF(s_1810, ((long) 1));
	    ((((node_effect_213_t) CREF(o_1809))->loc) = ((obj_t) v1212_1814), BUNSPEC);
	 }
	 {
	    type_t v1216_1815;
	    {
	       obj_t aux_5287;
	       aux_5287 = STRUCT_REF(s_1810, ((long) 2));
	       v1216_1815 = (type_t) (aux_5287);
	    }
	    ((((node_effect_213_t) CREF(o_1809))->type) = ((type_t) v1216_1815), BUNSPEC);
	 }
	 {
	    obj_t v1220_1816;
	    v1220_1816 = STRUCT_REF(s_1810, ((long) 3));
	    ((((node_effect_213_t) CREF(o_1809))->side_effect__165) = ((obj_t) v1220_1816), BUNSPEC);
	 }
	 {
	    obj_t v1224_1817;
	    v1224_1817 = STRUCT_REF(s_1810, ((long) 4));
	    ((((node_effect_213_t) CREF(o_1809))->key) = ((obj_t) v1224_1817), BUNSPEC);
	 }
	 aux_5279 = o_1809;
	 return (obj_t) (aux_5279);
      }
   }
}


/* object->struct-node/effect */ obj_t 
object__struct_node_effect_233_ast_node(obj_t env_3603, obj_t obj1208_3604)
{
   {
      node_effect_213_t obj1208_1793;
      obj1208_1793 = (node_effect_213_t) (obj1208_3604);
      {
	 obj_t res1209_1796;
	 {
	    obj_t aux_5297;
	    aux_5297 = CNST_TABLE_REF(((long) 1));
	    res1209_1796 = make_struct(aux_5297, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1209_1796, ((long) 0), BFALSE);
	 {
	    obj_t aux_5301;
	    aux_5301 = (((node_effect_213_t) CREF(obj1208_1793))->loc);
	    STRUCT_SET(res1209_1796, ((long) 1), aux_5301);
	 }
	 {
	    obj_t aux_5304;
	    {
	       type_t aux_5305;
	       aux_5305 = (((node_effect_213_t) CREF(obj1208_1793))->type);
	       aux_5304 = (obj_t) (aux_5305);
	    }
	    STRUCT_SET(res1209_1796, ((long) 2), aux_5304);
	 }
	 {
	    obj_t aux_5309;
	    aux_5309 = (((node_effect_213_t) CREF(obj1208_1793))->side_effect__165);
	    STRUCT_SET(res1209_1796, ((long) 3), aux_5309);
	 }
	 {
	    obj_t aux_5312;
	    aux_5312 = (((node_effect_213_t) CREF(obj1208_1793))->key);
	    STRUCT_SET(res1209_1796, ((long) 4), aux_5312);
	 }
	 return res1209_1796;
      }
   }
}


/* struct+object->object-atom */ obj_t 
struct_object__object_atom_177_ast_node(obj_t env_3605, obj_t o_3606, obj_t s_3607)
{
   {
      atom_t o_1783;
      obj_t s_1784;
      {
	 atom_t aux_5316;
	 o_1783 = (atom_t) (o_3606);
	 s_1784 = s_3607;
	 {
	    obj_t aux_5319;
	    object_t aux_5317;
	    aux_5319 = STRUCT_REF(s_1784, ((long) 0));
	    aux_5317 = (object_t) (o_1783);
	    OBJECT_WIDENING_SET(aux_5317, aux_5319);
	 }
	 {
	    obj_t v1238_1788;
	    v1238_1788 = STRUCT_REF(s_1784, ((long) 1));
	    ((((atom_t) CREF(o_1783))->loc) = ((obj_t) v1238_1788), BUNSPEC);
	 }
	 {
	    type_t v1242_1789;
	    {
	       obj_t aux_5324;
	       aux_5324 = STRUCT_REF(s_1784, ((long) 2));
	       v1242_1789 = (type_t) (aux_5324);
	    }
	    ((((atom_t) CREF(o_1783))->type) = ((type_t) v1242_1789), BUNSPEC);
	 }
	 {
	    obj_t v1246_1790;
	    v1246_1790 = STRUCT_REF(s_1784, ((long) 3));
	    ((((atom_t) CREF(o_1783))->value) = ((obj_t) v1246_1790), BUNSPEC);
	 }
	 aux_5316 = o_1783;
	 return (obj_t) (aux_5316);
      }
   }
}


/* object->struct-atom */ obj_t 
object__struct_atom_114_ast_node(obj_t env_3608, obj_t obj1234_3609)
{
   {
      atom_t obj1234_1769;
      obj1234_1769 = (atom_t) (obj1234_3609);
      {
	 obj_t res1235_1772;
	 {
	    obj_t aux_5332;
	    aux_5332 = CNST_TABLE_REF(((long) 2));
	    res1235_1772 = make_struct(aux_5332, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1235_1772, ((long) 0), BFALSE);
	 {
	    obj_t aux_5336;
	    aux_5336 = (((atom_t) CREF(obj1234_1769))->loc);
	    STRUCT_SET(res1235_1772, ((long) 1), aux_5336);
	 }
	 {
	    obj_t aux_5339;
	    {
	       type_t aux_5340;
	       aux_5340 = (((atom_t) CREF(obj1234_1769))->type);
	       aux_5339 = (obj_t) (aux_5340);
	    }
	    STRUCT_SET(res1235_1772, ((long) 2), aux_5339);
	 }
	 {
	    obj_t aux_5344;
	    aux_5344 = (((atom_t) CREF(obj1234_1769))->value);
	    STRUCT_SET(res1235_1772, ((long) 3), aux_5344);
	 }
	 return res1235_1772;
      }
   }
}


/* struct+object->object-var */ obj_t 
struct_object__object_var_138_ast_node(obj_t env_3610, obj_t o_3611, obj_t s_3612)
{
   {
      var_t o_1759;
      obj_t s_1760;
      {
	 var_t aux_5348;
	 o_1759 = (var_t) (o_3611);
	 s_1760 = s_3612;
	 {
	    obj_t aux_5351;
	    object_t aux_5349;
	    aux_5351 = STRUCT_REF(s_1760, ((long) 0));
	    aux_5349 = (object_t) (o_1759);
	    OBJECT_WIDENING_SET(aux_5349, aux_5351);
	 }
	 {
	    obj_t v1260_1764;
	    v1260_1764 = STRUCT_REF(s_1760, ((long) 1));
	    ((((var_t) CREF(o_1759))->loc) = ((obj_t) v1260_1764), BUNSPEC);
	 }
	 {
	    type_t v1264_1765;
	    {
	       obj_t aux_5356;
	       aux_5356 = STRUCT_REF(s_1760, ((long) 2));
	       v1264_1765 = (type_t) (aux_5356);
	    }
	    ((((var_t) CREF(o_1759))->type) = ((type_t) v1264_1765), BUNSPEC);
	 }
	 {
	    variable_t v1268_1766;
	    {
	       obj_t aux_5360;
	       aux_5360 = STRUCT_REF(s_1760, ((long) 3));
	       v1268_1766 = (variable_t) (aux_5360);
	    }
	    ((((var_t) CREF(o_1759))->variable) = ((variable_t) v1268_1766), BUNSPEC);
	 }
	 aux_5348 = o_1759;
	 return (obj_t) (aux_5348);
      }
   }
}


/* object->struct-var */ obj_t 
object__struct_var_159_ast_node(obj_t env_3613, obj_t obj1256_3614)
{
   {
      var_t obj1256_1745;
      obj1256_1745 = (var_t) (obj1256_3614);
      {
	 obj_t res1257_1748;
	 {
	    obj_t aux_5366;
	    aux_5366 = CNST_TABLE_REF(((long) 3));
	    res1257_1748 = make_struct(aux_5366, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1257_1748, ((long) 0), BFALSE);
	 {
	    obj_t aux_5370;
	    aux_5370 = (((var_t) CREF(obj1256_1745))->loc);
	    STRUCT_SET(res1257_1748, ((long) 1), aux_5370);
	 }
	 {
	    obj_t aux_5373;
	    {
	       type_t aux_5374;
	       aux_5374 = (((var_t) CREF(obj1256_1745))->type);
	       aux_5373 = (obj_t) (aux_5374);
	    }
	    STRUCT_SET(res1257_1748, ((long) 2), aux_5373);
	 }
	 {
	    obj_t aux_5378;
	    {
	       variable_t aux_5379;
	       aux_5379 = (((var_t) CREF(obj1256_1745))->variable);
	       aux_5378 = (obj_t) (aux_5379);
	    }
	    STRUCT_SET(res1257_1748, ((long) 3), aux_5378);
	 }
	 return res1257_1748;
      }
   }
}


/* struct+object->object-closure */ obj_t 
struct_object__object_closure_48_ast_node(obj_t env_3615, obj_t o_3616, obj_t s_3617)
{
   {
      closure_t o_1735;
      obj_t s_1736;
      {
	 closure_t aux_5384;
	 o_1735 = (closure_t) (o_3616);
	 s_1736 = s_3617;
	 {
	    obj_t aux_5387;
	    object_t aux_5385;
	    aux_5387 = STRUCT_REF(s_1736, ((long) 0));
	    aux_5385 = (object_t) (o_1735);
	    OBJECT_WIDENING_SET(aux_5385, aux_5387);
	 }
	 {
	    obj_t v1282_1740;
	    v1282_1740 = STRUCT_REF(s_1736, ((long) 1));
	    ((((closure_t) CREF(o_1735))->loc) = ((obj_t) v1282_1740), BUNSPEC);
	 }
	 {
	    type_t v1286_1741;
	    {
	       obj_t aux_5392;
	       aux_5392 = STRUCT_REF(s_1736, ((long) 2));
	       v1286_1741 = (type_t) (aux_5392);
	    }
	    ((((closure_t) CREF(o_1735))->type) = ((type_t) v1286_1741), BUNSPEC);
	 }
	 {
	    variable_t v1290_1742;
	    {
	       obj_t aux_5396;
	       aux_5396 = STRUCT_REF(s_1736, ((long) 3));
	       v1290_1742 = (variable_t) (aux_5396);
	    }
	    ((((closure_t) CREF(o_1735))->variable) = ((variable_t) v1290_1742), BUNSPEC);
	 }
	 aux_5384 = o_1735;
	 return (obj_t) (aux_5384);
      }
   }
}


/* object->struct-closure */ obj_t 
object__struct_closure_29_ast_node(obj_t env_3618, obj_t obj1278_3619)
{
   {
      closure_t obj1278_1721;
      obj1278_1721 = (closure_t) (obj1278_3619);
      {
	 obj_t res1279_1724;
	 {
	    obj_t aux_5402;
	    aux_5402 = CNST_TABLE_REF(((long) 4));
	    res1279_1724 = make_struct(aux_5402, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1279_1724, ((long) 0), BFALSE);
	 {
	    obj_t aux_5406;
	    aux_5406 = (((closure_t) CREF(obj1278_1721))->loc);
	    STRUCT_SET(res1279_1724, ((long) 1), aux_5406);
	 }
	 {
	    obj_t aux_5409;
	    {
	       type_t aux_5410;
	       aux_5410 = (((closure_t) CREF(obj1278_1721))->type);
	       aux_5409 = (obj_t) (aux_5410);
	    }
	    STRUCT_SET(res1279_1724, ((long) 2), aux_5409);
	 }
	 {
	    obj_t aux_5414;
	    {
	       variable_t aux_5415;
	       aux_5415 = (((closure_t) CREF(obj1278_1721))->variable);
	       aux_5414 = (obj_t) (aux_5415);
	    }
	    STRUCT_SET(res1279_1724, ((long) 3), aux_5414);
	 }
	 return res1279_1724;
      }
   }
}


/* struct+object->object-kwote */ obj_t 
struct_object__object_kwote_75_ast_node(obj_t env_3620, obj_t o_3621, obj_t s_3622)
{
   {
      kwote_t o_1711;
      obj_t s_1712;
      {
	 kwote_t aux_5420;
	 o_1711 = (kwote_t) (o_3621);
	 s_1712 = s_3622;
	 {
	    obj_t aux_5423;
	    object_t aux_5421;
	    aux_5423 = STRUCT_REF(s_1712, ((long) 0));
	    aux_5421 = (object_t) (o_1711);
	    OBJECT_WIDENING_SET(aux_5421, aux_5423);
	 }
	 {
	    obj_t v1303_1716;
	    v1303_1716 = STRUCT_REF(s_1712, ((long) 1));
	    ((((kwote_t) CREF(o_1711))->loc) = ((obj_t) v1303_1716), BUNSPEC);
	 }
	 {
	    type_t v1307_1717;
	    {
	       obj_t aux_5428;
	       aux_5428 = STRUCT_REF(s_1712, ((long) 2));
	       v1307_1717 = (type_t) (aux_5428);
	    }
	    ((((kwote_t) CREF(o_1711))->type) = ((type_t) v1307_1717), BUNSPEC);
	 }
	 {
	    obj_t v1311_1718;
	    v1311_1718 = STRUCT_REF(s_1712, ((long) 3));
	    ((((kwote_t) CREF(o_1711))->value) = ((obj_t) v1311_1718), BUNSPEC);
	 }
	 aux_5420 = o_1711;
	 return (obj_t) (aux_5420);
      }
   }
}


/* object->struct-kwote */ obj_t 
object__struct_kwote_66_ast_node(obj_t env_3623, obj_t obj1299_3624)
{
   {
      kwote_t obj1299_1697;
      obj1299_1697 = (kwote_t) (obj1299_3624);
      {
	 obj_t res1300_1700;
	 {
	    obj_t aux_5436;
	    aux_5436 = CNST_TABLE_REF(((long) 5));
	    res1300_1700 = make_struct(aux_5436, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1300_1700, ((long) 0), BFALSE);
	 {
	    obj_t aux_5440;
	    aux_5440 = (((kwote_t) CREF(obj1299_1697))->loc);
	    STRUCT_SET(res1300_1700, ((long) 1), aux_5440);
	 }
	 {
	    obj_t aux_5443;
	    {
	       type_t aux_5444;
	       aux_5444 = (((kwote_t) CREF(obj1299_1697))->type);
	       aux_5443 = (obj_t) (aux_5444);
	    }
	    STRUCT_SET(res1300_1700, ((long) 2), aux_5443);
	 }
	 {
	    obj_t aux_5448;
	    aux_5448 = (((kwote_t) CREF(obj1299_1697))->value);
	    STRUCT_SET(res1300_1700, ((long) 3), aux_5448);
	 }
	 return res1300_1700;
      }
   }
}


/* struct+object->object-sequence */ obj_t 
struct_object__object_sequence_200_ast_node(obj_t env_3625, obj_t o_3626, obj_t s_3627)
{
   {
      sequence_t o_1685;
      obj_t s_1686;
      {
	 sequence_t aux_5452;
	 o_1685 = (sequence_t) (o_3626);
	 s_1686 = s_3627;
	 {
	    obj_t aux_5455;
	    object_t aux_5453;
	    aux_5455 = STRUCT_REF(s_1686, ((long) 0));
	    aux_5453 = (object_t) (o_1685);
	    OBJECT_WIDENING_SET(aux_5453, aux_5455);
	 }
	 {
	    obj_t v1328_1690;
	    v1328_1690 = STRUCT_REF(s_1686, ((long) 1));
	    ((((sequence_t) CREF(o_1685))->loc) = ((obj_t) v1328_1690), BUNSPEC);
	 }
	 {
	    type_t v1332_1691;
	    {
	       obj_t aux_5460;
	       aux_5460 = STRUCT_REF(s_1686, ((long) 2));
	       v1332_1691 = (type_t) (aux_5460);
	    }
	    ((((sequence_t) CREF(o_1685))->type) = ((type_t) v1332_1691), BUNSPEC);
	 }
	 {
	    obj_t v1336_1692;
	    v1336_1692 = STRUCT_REF(s_1686, ((long) 3));
	    ((((sequence_t) CREF(o_1685))->side_effect__165) = ((obj_t) v1336_1692), BUNSPEC);
	 }
	 {
	    obj_t v1340_1693;
	    v1340_1693 = STRUCT_REF(s_1686, ((long) 4));
	    ((((sequence_t) CREF(o_1685))->key) = ((obj_t) v1340_1693), BUNSPEC);
	 }
	 {
	    obj_t v1344_1694;
	    v1344_1694 = STRUCT_REF(s_1686, ((long) 5));
	    ((((sequence_t) CREF(o_1685))->nodes) = ((obj_t) v1344_1694), BUNSPEC);
	 }
	 aux_5452 = o_1685;
	 return (obj_t) (aux_5452);
      }
   }
}


/* object->struct-sequence */ obj_t 
object__struct_sequence_112_ast_node(obj_t env_3628, obj_t obj1324_3629)
{
   {
      sequence_t obj1324_1667;
      obj1324_1667 = (sequence_t) (obj1324_3629);
      {
	 obj_t res1325_1670;
	 {
	    obj_t aux_5472;
	    aux_5472 = CNST_TABLE_REF(((long) 6));
	    res1325_1670 = make_struct(aux_5472, ((long) 6), BUNSPEC);
	 }
	 STRUCT_SET(res1325_1670, ((long) 0), BFALSE);
	 {
	    obj_t aux_5476;
	    aux_5476 = (((sequence_t) CREF(obj1324_1667))->loc);
	    STRUCT_SET(res1325_1670, ((long) 1), aux_5476);
	 }
	 {
	    obj_t aux_5479;
	    {
	       type_t aux_5480;
	       aux_5480 = (((sequence_t) CREF(obj1324_1667))->type);
	       aux_5479 = (obj_t) (aux_5480);
	    }
	    STRUCT_SET(res1325_1670, ((long) 2), aux_5479);
	 }
	 {
	    obj_t aux_5484;
	    aux_5484 = (((sequence_t) CREF(obj1324_1667))->side_effect__165);
	    STRUCT_SET(res1325_1670, ((long) 3), aux_5484);
	 }
	 {
	    obj_t aux_5487;
	    aux_5487 = (((sequence_t) CREF(obj1324_1667))->key);
	    STRUCT_SET(res1325_1670, ((long) 4), aux_5487);
	 }
	 {
	    obj_t aux_5490;
	    aux_5490 = (((sequence_t) CREF(obj1324_1667))->nodes);
	    STRUCT_SET(res1325_1670, ((long) 5), aux_5490);
	 }
	 return res1325_1670;
      }
   }
}


/* struct+object->object-app */ obj_t 
struct_object__object_app_63_ast_node(obj_t env_3630, obj_t o_3631, obj_t s_3632)
{
   {
      app_t o_1653;
      obj_t s_1654;
      {
	 app_t aux_5494;
	 o_1653 = (app_t) (o_3631);
	 s_1654 = s_3632;
	 {
	    obj_t aux_5497;
	    object_t aux_5495;
	    aux_5497 = STRUCT_REF(s_1654, ((long) 0));
	    aux_5495 = (object_t) (o_1653);
	    OBJECT_WIDENING_SET(aux_5495, aux_5497);
	 }
	 {
	    obj_t v1366_1658;
	    v1366_1658 = STRUCT_REF(s_1654, ((long) 1));
	    ((((app_t) CREF(o_1653))->loc) = ((obj_t) v1366_1658), BUNSPEC);
	 }
	 {
	    type_t v1370_1659;
	    {
	       obj_t aux_5502;
	       aux_5502 = STRUCT_REF(s_1654, ((long) 2));
	       v1370_1659 = (type_t) (aux_5502);
	    }
	    ((((app_t) CREF(o_1653))->type) = ((type_t) v1370_1659), BUNSPEC);
	 }
	 {
	    obj_t v1374_1660;
	    v1374_1660 = STRUCT_REF(s_1654, ((long) 3));
	    ((((app_t) CREF(o_1653))->side_effect__165) = ((obj_t) v1374_1660), BUNSPEC);
	 }
	 {
	    obj_t v1378_1661;
	    v1378_1661 = STRUCT_REF(s_1654, ((long) 4));
	    ((((app_t) CREF(o_1653))->key) = ((obj_t) v1378_1661), BUNSPEC);
	 }
	 {
	    var_t v1382_1662;
	    {
	       obj_t aux_5510;
	       aux_5510 = STRUCT_REF(s_1654, ((long) 5));
	       v1382_1662 = (var_t) (aux_5510);
	    }
	    ((((app_t) CREF(o_1653))->fun) = ((var_t) v1382_1662), BUNSPEC);
	 }
	 {
	    obj_t v1386_1663;
	    v1386_1663 = STRUCT_REF(s_1654, ((long) 6));
	    ((((app_t) CREF(o_1653))->args) = ((obj_t) v1386_1663), BUNSPEC);
	 }
	 {
	    obj_t v1390_1664;
	    v1390_1664 = STRUCT_REF(s_1654, ((long) 7));
	    ((((app_t) CREF(o_1653))->stack_info_255) = ((obj_t) v1390_1664), BUNSPEC);
	 }
	 aux_5494 = o_1653;
	 return (obj_t) (aux_5494);
      }
   }
}


/* object->struct-app */ obj_t 
object__struct_app_142_ast_node(obj_t env_3633, obj_t obj1362_3634)
{
   {
      app_t obj1362_1631;
      obj1362_1631 = (app_t) (obj1362_3634);
      {
	 obj_t res1363_1634;
	 {
	    obj_t aux_5520;
	    aux_5520 = CNST_TABLE_REF(((long) 7));
	    res1363_1634 = make_struct(aux_5520, ((long) 8), BUNSPEC);
	 }
	 STRUCT_SET(res1363_1634, ((long) 0), BFALSE);
	 {
	    obj_t aux_5524;
	    aux_5524 = (((app_t) CREF(obj1362_1631))->loc);
	    STRUCT_SET(res1363_1634, ((long) 1), aux_5524);
	 }
	 {
	    obj_t aux_5527;
	    {
	       type_t aux_5528;
	       aux_5528 = (((app_t) CREF(obj1362_1631))->type);
	       aux_5527 = (obj_t) (aux_5528);
	    }
	    STRUCT_SET(res1363_1634, ((long) 2), aux_5527);
	 }
	 {
	    obj_t aux_5532;
	    aux_5532 = (((app_t) CREF(obj1362_1631))->side_effect__165);
	    STRUCT_SET(res1363_1634, ((long) 3), aux_5532);
	 }
	 {
	    obj_t aux_5535;
	    aux_5535 = (((app_t) CREF(obj1362_1631))->key);
	    STRUCT_SET(res1363_1634, ((long) 4), aux_5535);
	 }
	 {
	    obj_t aux_5538;
	    {
	       var_t aux_5539;
	       aux_5539 = (((app_t) CREF(obj1362_1631))->fun);
	       aux_5538 = (obj_t) (aux_5539);
	    }
	    STRUCT_SET(res1363_1634, ((long) 5), aux_5538);
	 }
	 {
	    obj_t aux_5543;
	    aux_5543 = (((app_t) CREF(obj1362_1631))->args);
	    STRUCT_SET(res1363_1634, ((long) 6), aux_5543);
	 }
	 {
	    obj_t aux_5546;
	    aux_5546 = (((app_t) CREF(obj1362_1631))->stack_info_255);
	    STRUCT_SET(res1363_1634, ((long) 7), aux_5546);
	 }
	 return res1363_1634;
      }
   }
}


/* struct+object->object-app-ly */ obj_t 
struct_object__object_app_ly_165_ast_node(obj_t env_3635, obj_t o_3636, obj_t s_3637)
{
   {
      app_ly_162_t o_1620;
      obj_t s_1621;
      {
	 app_ly_162_t aux_5550;
	 o_1620 = (app_ly_162_t) (o_3636);
	 s_1621 = s_3637;
	 {
	    obj_t aux_5553;
	    object_t aux_5551;
	    aux_5553 = STRUCT_REF(s_1621, ((long) 0));
	    aux_5551 = (object_t) (o_1620);
	    OBJECT_WIDENING_SET(aux_5551, aux_5553);
	 }
	 {
	    obj_t v1406_1625;
	    v1406_1625 = STRUCT_REF(s_1621, ((long) 1));
	    ((((app_ly_162_t) CREF(o_1620))->loc) = ((obj_t) v1406_1625), BUNSPEC);
	 }
	 {
	    type_t v1410_1626;
	    {
	       obj_t aux_5558;
	       aux_5558 = STRUCT_REF(s_1621, ((long) 2));
	       v1410_1626 = (type_t) (aux_5558);
	    }
	    ((((app_ly_162_t) CREF(o_1620))->type) = ((type_t) v1410_1626), BUNSPEC);
	 }
	 {
	    node_t v1414_1627;
	    {
	       obj_t aux_5562;
	       aux_5562 = STRUCT_REF(s_1621, ((long) 3));
	       v1414_1627 = (node_t) (aux_5562);
	    }
	    ((((app_ly_162_t) CREF(o_1620))->fun) = ((node_t) v1414_1627), BUNSPEC);
	 }
	 {
	    node_t v1418_1628;
	    {
	       obj_t aux_5566;
	       aux_5566 = STRUCT_REF(s_1621, ((long) 4));
	       v1418_1628 = (node_t) (aux_5566);
	    }
	    ((((app_ly_162_t) CREF(o_1620))->arg) = ((node_t) v1418_1628), BUNSPEC);
	 }
	 aux_5550 = o_1620;
	 return (obj_t) (aux_5550);
      }
   }
}


/* object->struct-app-ly */ obj_t 
object__struct_app_ly_240_ast_node(obj_t env_3638, obj_t obj1402_3639)
{
   {
      app_ly_162_t obj1402_1604;
      obj1402_1604 = (app_ly_162_t) (obj1402_3639);
      {
	 obj_t res1403_1607;
	 {
	    obj_t aux_5572;
	    aux_5572 = CNST_TABLE_REF(((long) 8));
	    res1403_1607 = make_struct(aux_5572, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1403_1607, ((long) 0), BFALSE);
	 {
	    obj_t aux_5576;
	    aux_5576 = (((app_ly_162_t) CREF(obj1402_1604))->loc);
	    STRUCT_SET(res1403_1607, ((long) 1), aux_5576);
	 }
	 {
	    obj_t aux_5579;
	    {
	       type_t aux_5580;
	       aux_5580 = (((app_ly_162_t) CREF(obj1402_1604))->type);
	       aux_5579 = (obj_t) (aux_5580);
	    }
	    STRUCT_SET(res1403_1607, ((long) 2), aux_5579);
	 }
	 {
	    obj_t aux_5584;
	    {
	       node_t aux_5585;
	       aux_5585 = (((app_ly_162_t) CREF(obj1402_1604))->fun);
	       aux_5584 = (obj_t) (aux_5585);
	    }
	    STRUCT_SET(res1403_1607, ((long) 3), aux_5584);
	 }
	 {
	    obj_t aux_5589;
	    {
	       node_t aux_5590;
	       aux_5590 = (((app_ly_162_t) CREF(obj1402_1604))->arg);
	       aux_5589 = (obj_t) (aux_5590);
	    }
	    STRUCT_SET(res1403_1607, ((long) 4), aux_5589);
	 }
	 return res1403_1607;
      }
   }
}


/* struct+object->object-funcall */ obj_t 
struct_object__object_funcall_136_ast_node(obj_t env_3640, obj_t o_3641, obj_t s_3642)
{
   {
      funcall_t o_1592;
      obj_t s_1593;
      {
	 funcall_t aux_5595;
	 o_1592 = (funcall_t) (o_3641);
	 s_1593 = s_3642;
	 {
	    obj_t aux_5598;
	    object_t aux_5596;
	    aux_5598 = STRUCT_REF(s_1593, ((long) 0));
	    aux_5596 = (object_t) (o_1592);
	    OBJECT_WIDENING_SET(aux_5596, aux_5598);
	 }
	 {
	    obj_t v1436_1597;
	    v1436_1597 = STRUCT_REF(s_1593, ((long) 1));
	    ((((funcall_t) CREF(o_1592))->loc) = ((obj_t) v1436_1597), BUNSPEC);
	 }
	 {
	    type_t v1440_1598;
	    {
	       obj_t aux_5603;
	       aux_5603 = STRUCT_REF(s_1593, ((long) 2));
	       v1440_1598 = (type_t) (aux_5603);
	    }
	    ((((funcall_t) CREF(o_1592))->type) = ((type_t) v1440_1598), BUNSPEC);
	 }
	 {
	    node_t v1444_1599;
	    {
	       obj_t aux_5607;
	       aux_5607 = STRUCT_REF(s_1593, ((long) 3));
	       v1444_1599 = (node_t) (aux_5607);
	    }
	    ((((funcall_t) CREF(o_1592))->fun) = ((node_t) v1444_1599), BUNSPEC);
	 }
	 {
	    obj_t v1448_1600;
	    v1448_1600 = STRUCT_REF(s_1593, ((long) 4));
	    ((((funcall_t) CREF(o_1592))->args) = ((obj_t) v1448_1600), BUNSPEC);
	 }
	 {
	    obj_t v1452_1601;
	    v1452_1601 = STRUCT_REF(s_1593, ((long) 5));
	    ((((funcall_t) CREF(o_1592))->strength) = ((obj_t) v1452_1601), BUNSPEC);
	 }
	 aux_5595 = o_1592;
	 return (obj_t) (aux_5595);
      }
   }
}


/* object->struct-funcall */ obj_t 
object__struct_funcall_68_ast_node(obj_t env_3643, obj_t obj1432_3644)
{
   {
      funcall_t obj1432_1574;
      obj1432_1574 = (funcall_t) (obj1432_3644);
      {
	 obj_t res1433_1577;
	 {
	    obj_t aux_5617;
	    aux_5617 = CNST_TABLE_REF(((long) 9));
	    res1433_1577 = make_struct(aux_5617, ((long) 6), BUNSPEC);
	 }
	 STRUCT_SET(res1433_1577, ((long) 0), BFALSE);
	 {
	    obj_t aux_5621;
	    aux_5621 = (((funcall_t) CREF(obj1432_1574))->loc);
	    STRUCT_SET(res1433_1577, ((long) 1), aux_5621);
	 }
	 {
	    obj_t aux_5624;
	    {
	       type_t aux_5625;
	       aux_5625 = (((funcall_t) CREF(obj1432_1574))->type);
	       aux_5624 = (obj_t) (aux_5625);
	    }
	    STRUCT_SET(res1433_1577, ((long) 2), aux_5624);
	 }
	 {
	    obj_t aux_5629;
	    {
	       node_t aux_5630;
	       aux_5630 = (((funcall_t) CREF(obj1432_1574))->fun);
	       aux_5629 = (obj_t) (aux_5630);
	    }
	    STRUCT_SET(res1433_1577, ((long) 3), aux_5629);
	 }
	 {
	    obj_t aux_5634;
	    aux_5634 = (((funcall_t) CREF(obj1432_1574))->args);
	    STRUCT_SET(res1433_1577, ((long) 4), aux_5634);
	 }
	 {
	    obj_t aux_5637;
	    aux_5637 = (((funcall_t) CREF(obj1432_1574))->strength);
	    STRUCT_SET(res1433_1577, ((long) 5), aux_5637);
	 }
	 return res1433_1577;
      }
   }
}


/* struct+object->object-pragma */ obj_t 
struct_object__object_pragma_2_ast_node(obj_t env_3645, obj_t o_3646, obj_t s_3647)
{
   {
      pragma_t o_1561;
      obj_t s_1562;
      {
	 pragma_t aux_5641;
	 o_1561 = (pragma_t) (o_3646);
	 s_1562 = s_3647;
	 {
	    obj_t aux_5644;
	    object_t aux_5642;
	    aux_5644 = STRUCT_REF(s_1562, ((long) 0));
	    aux_5642 = (object_t) (o_1561);
	    OBJECT_WIDENING_SET(aux_5642, aux_5644);
	 }
	 {
	    obj_t v1471_1566;
	    v1471_1566 = STRUCT_REF(s_1562, ((long) 1));
	    ((((pragma_t) CREF(o_1561))->loc) = ((obj_t) v1471_1566), BUNSPEC);
	 }
	 {
	    type_t v1475_1567;
	    {
	       obj_t aux_5649;
	       aux_5649 = STRUCT_REF(s_1562, ((long) 2));
	       v1475_1567 = (type_t) (aux_5649);
	    }
	    ((((pragma_t) CREF(o_1561))->type) = ((type_t) v1475_1567), BUNSPEC);
	 }
	 {
	    obj_t v1479_1568;
	    v1479_1568 = STRUCT_REF(s_1562, ((long) 3));
	    ((((pragma_t) CREF(o_1561))->side_effect__165) = ((obj_t) v1479_1568), BUNSPEC);
	 }
	 {
	    obj_t v1483_1569;
	    v1483_1569 = STRUCT_REF(s_1562, ((long) 4));
	    ((((pragma_t) CREF(o_1561))->key) = ((obj_t) v1483_1569), BUNSPEC);
	 }
	 {
	    obj_t v1487_1570;
	    v1487_1570 = STRUCT_REF(s_1562, ((long) 5));
	    ((((pragma_t) CREF(o_1561))->format) = ((obj_t) v1487_1570), BUNSPEC);
	 }
	 {
	    obj_t v1491_1571;
	    v1491_1571 = STRUCT_REF(s_1562, ((long) 6));
	    ((((pragma_t) CREF(o_1561))->args) = ((obj_t) v1491_1571), BUNSPEC);
	 }
	 aux_5641 = o_1561;
	 return (obj_t) (aux_5641);
      }
   }
}


/* object->struct-pragma */ obj_t 
object__struct_pragma_207_ast_node(obj_t env_3648, obj_t obj1467_3649)
{
   {
      pragma_t obj1467_1541;
      obj1467_1541 = (pragma_t) (obj1467_3649);
      {
	 obj_t res1468_1544;
	 {
	    obj_t aux_5663;
	    aux_5663 = CNST_TABLE_REF(((long) 10));
	    res1468_1544 = make_struct(aux_5663, ((long) 7), BUNSPEC);
	 }
	 STRUCT_SET(res1468_1544, ((long) 0), BFALSE);
	 {
	    obj_t aux_5667;
	    aux_5667 = (((pragma_t) CREF(obj1467_1541))->loc);
	    STRUCT_SET(res1468_1544, ((long) 1), aux_5667);
	 }
	 {
	    obj_t aux_5670;
	    {
	       type_t aux_5671;
	       aux_5671 = (((pragma_t) CREF(obj1467_1541))->type);
	       aux_5670 = (obj_t) (aux_5671);
	    }
	    STRUCT_SET(res1468_1544, ((long) 2), aux_5670);
	 }
	 {
	    obj_t aux_5675;
	    aux_5675 = (((pragma_t) CREF(obj1467_1541))->side_effect__165);
	    STRUCT_SET(res1468_1544, ((long) 3), aux_5675);
	 }
	 {
	    obj_t aux_5678;
	    aux_5678 = (((pragma_t) CREF(obj1467_1541))->key);
	    STRUCT_SET(res1468_1544, ((long) 4), aux_5678);
	 }
	 {
	    obj_t aux_5681;
	    aux_5681 = (((pragma_t) CREF(obj1467_1541))->format);
	    STRUCT_SET(res1468_1544, ((long) 5), aux_5681);
	 }
	 {
	    obj_t aux_5684;
	    aux_5684 = (((pragma_t) CREF(obj1467_1541))->args);
	    STRUCT_SET(res1468_1544, ((long) 6), aux_5684);
	 }
	 return res1468_1544;
      }
   }
}


/* struct+object->object-cast */ obj_t 
struct_object__object_cast_16_ast_node(obj_t env_3650, obj_t o_3651, obj_t s_3652)
{
   {
      cast_t o_1531;
      obj_t s_1532;
      {
	 cast_t aux_5688;
	 o_1531 = (cast_t) (o_3651);
	 s_1532 = s_3652;
	 {
	    obj_t aux_5691;
	    object_t aux_5689;
	    aux_5691 = STRUCT_REF(s_1532, ((long) 0));
	    aux_5689 = (object_t) (o_1531);
	    OBJECT_WIDENING_SET(aux_5689, aux_5691);
	 }
	 {
	    obj_t v1505_1536;
	    v1505_1536 = STRUCT_REF(s_1532, ((long) 1));
	    ((((cast_t) CREF(o_1531))->loc) = ((obj_t) v1505_1536), BUNSPEC);
	 }
	 {
	    type_t v1509_1537;
	    {
	       obj_t aux_5696;
	       aux_5696 = STRUCT_REF(s_1532, ((long) 2));
	       v1509_1537 = (type_t) (aux_5696);
	    }
	    ((((cast_t) CREF(o_1531))->type) = ((type_t) v1509_1537), BUNSPEC);
	 }
	 {
	    node_t v1513_1538;
	    {
	       obj_t aux_5700;
	       aux_5700 = STRUCT_REF(s_1532, ((long) 3));
	       v1513_1538 = (node_t) (aux_5700);
	    }
	    ((((cast_t) CREF(o_1531))->arg) = ((node_t) v1513_1538), BUNSPEC);
	 }
	 aux_5688 = o_1531;
	 return (obj_t) (aux_5688);
      }
   }
}


/* object->struct-cast */ obj_t 
object__struct_cast_161_ast_node(obj_t env_3653, obj_t obj1501_3654)
{
   {
      cast_t obj1501_1517;
      obj1501_1517 = (cast_t) (obj1501_3654);
      {
	 obj_t res1502_1520;
	 {
	    obj_t aux_5706;
	    aux_5706 = CNST_TABLE_REF(((long) 11));
	    res1502_1520 = make_struct(aux_5706, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1502_1520, ((long) 0), BFALSE);
	 {
	    obj_t aux_5710;
	    aux_5710 = (((cast_t) CREF(obj1501_1517))->loc);
	    STRUCT_SET(res1502_1520, ((long) 1), aux_5710);
	 }
	 {
	    obj_t aux_5713;
	    {
	       type_t aux_5714;
	       aux_5714 = (((cast_t) CREF(obj1501_1517))->type);
	       aux_5713 = (obj_t) (aux_5714);
	    }
	    STRUCT_SET(res1502_1520, ((long) 2), aux_5713);
	 }
	 {
	    obj_t aux_5718;
	    {
	       node_t aux_5719;
	       aux_5719 = (((cast_t) CREF(obj1501_1517))->arg);
	       aux_5718 = (obj_t) (aux_5719);
	    }
	    STRUCT_SET(res1502_1520, ((long) 3), aux_5718);
	 }
	 return res1502_1520;
      }
   }
}


/* struct+object->object-setq */ obj_t 
struct_object__object_setq_124_ast_node(obj_t env_3655, obj_t o_3656, obj_t s_3657)
{
   {
      setq_t o_1506;
      obj_t s_1507;
      {
	 setq_t aux_5724;
	 o_1506 = (setq_t) (o_3656);
	 s_1507 = s_3657;
	 {
	    obj_t aux_5727;
	    object_t aux_5725;
	    aux_5727 = STRUCT_REF(s_1507, ((long) 0));
	    aux_5725 = (object_t) (o_1506);
	    OBJECT_WIDENING_SET(aux_5725, aux_5727);
	 }
	 {
	    obj_t v1529_1511;
	    v1529_1511 = STRUCT_REF(s_1507, ((long) 1));
	    ((((setq_t) CREF(o_1506))->loc) = ((obj_t) v1529_1511), BUNSPEC);
	 }
	 {
	    type_t v1533_1512;
	    {
	       obj_t aux_5732;
	       aux_5732 = STRUCT_REF(s_1507, ((long) 2));
	       v1533_1512 = (type_t) (aux_5732);
	    }
	    ((((setq_t) CREF(o_1506))->type) = ((type_t) v1533_1512), BUNSPEC);
	 }
	 {
	    var_t v1537_1513;
	    {
	       obj_t aux_5736;
	       aux_5736 = STRUCT_REF(s_1507, ((long) 3));
	       v1537_1513 = (var_t) (aux_5736);
	    }
	    ((((setq_t) CREF(o_1506))->var) = ((var_t) v1537_1513), BUNSPEC);
	 }
	 {
	    node_t v1541_1514;
	    {
	       obj_t aux_5740;
	       aux_5740 = STRUCT_REF(s_1507, ((long) 4));
	       v1541_1514 = (node_t) (aux_5740);
	    }
	    ((((setq_t) CREF(o_1506))->value) = ((node_t) v1541_1514), BUNSPEC);
	 }
	 aux_5724 = o_1506;
	 return (obj_t) (aux_5724);
      }
   }
}


/* object->struct-setq */ obj_t 
object__struct_setq_205_ast_node(obj_t env_3658, obj_t obj1525_3659)
{
   {
      setq_t obj1525_1490;
      obj1525_1490 = (setq_t) (obj1525_3659);
      {
	 obj_t res1526_1493;
	 {
	    obj_t aux_5746;
	    aux_5746 = CNST_TABLE_REF(((long) 12));
	    res1526_1493 = make_struct(aux_5746, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1526_1493, ((long) 0), BFALSE);
	 {
	    obj_t aux_5750;
	    aux_5750 = (((setq_t) CREF(obj1525_1490))->loc);
	    STRUCT_SET(res1526_1493, ((long) 1), aux_5750);
	 }
	 {
	    obj_t aux_5753;
	    {
	       type_t aux_5754;
	       aux_5754 = (((setq_t) CREF(obj1525_1490))->type);
	       aux_5753 = (obj_t) (aux_5754);
	    }
	    STRUCT_SET(res1526_1493, ((long) 2), aux_5753);
	 }
	 {
	    obj_t aux_5758;
	    {
	       var_t aux_5759;
	       aux_5759 = (((setq_t) CREF(obj1525_1490))->var);
	       aux_5758 = (obj_t) (aux_5759);
	    }
	    STRUCT_SET(res1526_1493, ((long) 3), aux_5758);
	 }
	 {
	    obj_t aux_5763;
	    {
	       node_t aux_5764;
	       aux_5764 = (((setq_t) CREF(obj1525_1490))->value);
	       aux_5763 = (obj_t) (aux_5764);
	    }
	    STRUCT_SET(res1526_1493, ((long) 4), aux_5763);
	 }
	 return res1526_1493;
      }
   }
}


/* struct+object->object-conditional */ obj_t 
struct_object__object_conditional_24_ast_node(obj_t env_3660, obj_t o_3661, obj_t s_3662)
{
   {
      conditional_t o_1476;
      obj_t s_1477;
      {
	 conditional_t aux_5769;
	 o_1476 = (conditional_t) (o_3661);
	 s_1477 = s_3662;
	 {
	    obj_t aux_5772;
	    object_t aux_5770;
	    aux_5772 = STRUCT_REF(s_1477, ((long) 0));
	    aux_5770 = (object_t) (o_1476);
	    OBJECT_WIDENING_SET(aux_5770, aux_5772);
	 }
	 {
	    obj_t v1563_1481;
	    v1563_1481 = STRUCT_REF(s_1477, ((long) 1));
	    ((((conditional_t) CREF(o_1476))->loc) = ((obj_t) v1563_1481), BUNSPEC);
	 }
	 {
	    type_t v1567_1482;
	    {
	       obj_t aux_5777;
	       aux_5777 = STRUCT_REF(s_1477, ((long) 2));
	       v1567_1482 = (type_t) (aux_5777);
	    }
	    ((((conditional_t) CREF(o_1476))->type) = ((type_t) v1567_1482), BUNSPEC);
	 }
	 {
	    obj_t v1571_1483;
	    v1571_1483 = STRUCT_REF(s_1477, ((long) 3));
	    ((((conditional_t) CREF(o_1476))->side_effect__165) = ((obj_t) v1571_1483), BUNSPEC);
	 }
	 {
	    obj_t v1575_1484;
	    v1575_1484 = STRUCT_REF(s_1477, ((long) 4));
	    ((((conditional_t) CREF(o_1476))->key) = ((obj_t) v1575_1484), BUNSPEC);
	 }
	 {
	    node_t v1579_1485;
	    {
	       obj_t aux_5785;
	       aux_5785 = STRUCT_REF(s_1477, ((long) 5));
	       v1579_1485 = (node_t) (aux_5785);
	    }
	    ((((conditional_t) CREF(o_1476))->test) = ((node_t) v1579_1485), BUNSPEC);
	 }
	 {
	    node_t v1583_1486;
	    {
	       obj_t aux_5789;
	       aux_5789 = STRUCT_REF(s_1477, ((long) 6));
	       v1583_1486 = (node_t) (aux_5789);
	    }
	    ((((conditional_t) CREF(o_1476))->true) = ((node_t) v1583_1486), BUNSPEC);
	 }
	 {
	    node_t v1587_1487;
	    {
	       obj_t aux_5793;
	       aux_5793 = STRUCT_REF(s_1477, ((long) 7));
	       v1587_1487 = (node_t) (aux_5793);
	    }
	    ((((conditional_t) CREF(o_1476))->false) = ((node_t) v1587_1487), BUNSPEC);
	 }
	 aux_5769 = o_1476;
	 return (obj_t) (aux_5769);
      }
   }
}


/* object->struct-conditional */ obj_t 
object__struct_conditional_60_ast_node(obj_t env_3663, obj_t obj1559_3664)
{
   {
      conditional_t obj1559_1454;
      obj1559_1454 = (conditional_t) (obj1559_3664);
      {
	 obj_t res1560_1457;
	 {
	    obj_t aux_5799;
	    aux_5799 = CNST_TABLE_REF(((long) 13));
	    res1560_1457 = make_struct(aux_5799, ((long) 8), BUNSPEC);
	 }
	 STRUCT_SET(res1560_1457, ((long) 0), BFALSE);
	 {
	    obj_t aux_5803;
	    aux_5803 = (((conditional_t) CREF(obj1559_1454))->loc);
	    STRUCT_SET(res1560_1457, ((long) 1), aux_5803);
	 }
	 {
	    obj_t aux_5806;
	    {
	       type_t aux_5807;
	       aux_5807 = (((conditional_t) CREF(obj1559_1454))->type);
	       aux_5806 = (obj_t) (aux_5807);
	    }
	    STRUCT_SET(res1560_1457, ((long) 2), aux_5806);
	 }
	 {
	    obj_t aux_5811;
	    aux_5811 = (((conditional_t) CREF(obj1559_1454))->side_effect__165);
	    STRUCT_SET(res1560_1457, ((long) 3), aux_5811);
	 }
	 {
	    obj_t aux_5814;
	    aux_5814 = (((conditional_t) CREF(obj1559_1454))->key);
	    STRUCT_SET(res1560_1457, ((long) 4), aux_5814);
	 }
	 {
	    obj_t aux_5817;
	    {
	       node_t aux_5818;
	       aux_5818 = (((conditional_t) CREF(obj1559_1454))->test);
	       aux_5817 = (obj_t) (aux_5818);
	    }
	    STRUCT_SET(res1560_1457, ((long) 5), aux_5817);
	 }
	 {
	    obj_t aux_5822;
	    {
	       node_t aux_5823;
	       aux_5823 = (((conditional_t) CREF(obj1559_1454))->true);
	       aux_5822 = (obj_t) (aux_5823);
	    }
	    STRUCT_SET(res1560_1457, ((long) 6), aux_5822);
	 }
	 {
	    obj_t aux_5827;
	    {
	       node_t aux_5828;
	       aux_5828 = (((conditional_t) CREF(obj1559_1454))->false);
	       aux_5827 = (obj_t) (aux_5828);
	    }
	    STRUCT_SET(res1560_1457, ((long) 7), aux_5827);
	 }
	 return res1560_1457;
      }
   }
}


/* struct+object->object-fail */ obj_t 
struct_object__object_fail_96_ast_node(obj_t env_3665, obj_t o_3666, obj_t s_3667)
{
   {
      fail_t o_1442;
      obj_t s_1443;
      {
	 fail_t aux_5833;
	 o_1442 = (fail_t) (o_3666);
	 s_1443 = s_3667;
	 {
	    obj_t aux_5836;
	    object_t aux_5834;
	    aux_5836 = STRUCT_REF(s_1443, ((long) 0));
	    aux_5834 = (object_t) (o_1442);
	    OBJECT_WIDENING_SET(aux_5834, aux_5836);
	 }
	 {
	    obj_t v1605_1447;
	    v1605_1447 = STRUCT_REF(s_1443, ((long) 1));
	    ((((fail_t) CREF(o_1442))->loc) = ((obj_t) v1605_1447), BUNSPEC);
	 }
	 {
	    type_t v1609_1448;
	    {
	       obj_t aux_5841;
	       aux_5841 = STRUCT_REF(s_1443, ((long) 2));
	       v1609_1448 = (type_t) (aux_5841);
	    }
	    ((((fail_t) CREF(o_1442))->type) = ((type_t) v1609_1448), BUNSPEC);
	 }
	 {
	    node_t v1613_1449;
	    {
	       obj_t aux_5845;
	       aux_5845 = STRUCT_REF(s_1443, ((long) 3));
	       v1613_1449 = (node_t) (aux_5845);
	    }
	    ((((fail_t) CREF(o_1442))->proc) = ((node_t) v1613_1449), BUNSPEC);
	 }
	 {
	    node_t v1617_1450;
	    {
	       obj_t aux_5849;
	       aux_5849 = STRUCT_REF(s_1443, ((long) 4));
	       v1617_1450 = (node_t) (aux_5849);
	    }
	    ((((fail_t) CREF(o_1442))->msg) = ((node_t) v1617_1450), BUNSPEC);
	 }
	 {
	    node_t v1621_1451;
	    {
	       obj_t aux_5853;
	       aux_5853 = STRUCT_REF(s_1443, ((long) 5));
	       v1621_1451 = (node_t) (aux_5853);
	    }
	    ((((fail_t) CREF(o_1442))->obj) = ((node_t) v1621_1451), BUNSPEC);
	 }
	 aux_5833 = o_1442;
	 return (obj_t) (aux_5833);
      }
   }
}


/* object->struct-fail */ obj_t 
object__struct_fail_140_ast_node(obj_t env_3668, obj_t obj1601_3669)
{
   {
      fail_t obj1601_1424;
      obj1601_1424 = (fail_t) (obj1601_3669);
      {
	 obj_t res1602_1427;
	 {
	    obj_t aux_5859;
	    aux_5859 = CNST_TABLE_REF(((long) 14));
	    res1602_1427 = make_struct(aux_5859, ((long) 6), BUNSPEC);
	 }
	 STRUCT_SET(res1602_1427, ((long) 0), BFALSE);
	 {
	    obj_t aux_5863;
	    aux_5863 = (((fail_t) CREF(obj1601_1424))->loc);
	    STRUCT_SET(res1602_1427, ((long) 1), aux_5863);
	 }
	 {
	    obj_t aux_5866;
	    {
	       type_t aux_5867;
	       aux_5867 = (((fail_t) CREF(obj1601_1424))->type);
	       aux_5866 = (obj_t) (aux_5867);
	    }
	    STRUCT_SET(res1602_1427, ((long) 2), aux_5866);
	 }
	 {
	    obj_t aux_5871;
	    {
	       node_t aux_5872;
	       aux_5872 = (((fail_t) CREF(obj1601_1424))->proc);
	       aux_5871 = (obj_t) (aux_5872);
	    }
	    STRUCT_SET(res1602_1427, ((long) 3), aux_5871);
	 }
	 {
	    obj_t aux_5876;
	    {
	       node_t aux_5877;
	       aux_5877 = (((fail_t) CREF(obj1601_1424))->msg);
	       aux_5876 = (obj_t) (aux_5877);
	    }
	    STRUCT_SET(res1602_1427, ((long) 4), aux_5876);
	 }
	 {
	    obj_t aux_5881;
	    {
	       node_t aux_5882;
	       aux_5882 = (((fail_t) CREF(obj1601_1424))->obj);
	       aux_5881 = (obj_t) (aux_5882);
	    }
	    STRUCT_SET(res1602_1427, ((long) 5), aux_5881);
	 }
	 return res1602_1427;
      }
   }
}


/* struct+object->object-select */ obj_t 
struct_object__object_select_156_ast_node(obj_t env_3670, obj_t o_3671, obj_t s_3672)
{
   {
      select_t o_1410;
      obj_t s_1411;
      {
	 select_t aux_5887;
	 o_1410 = (select_t) (o_3671);
	 s_1411 = s_3672;
	 {
	    obj_t aux_5890;
	    object_t aux_5888;
	    aux_5890 = STRUCT_REF(s_1411, ((long) 0));
	    aux_5888 = (object_t) (o_1410);
	    OBJECT_WIDENING_SET(aux_5888, aux_5890);
	 }
	 {
	    obj_t v1641_1415;
	    v1641_1415 = STRUCT_REF(s_1411, ((long) 1));
	    ((((select_t) CREF(o_1410))->loc) = ((obj_t) v1641_1415), BUNSPEC);
	 }
	 {
	    type_t v1645_1416;
	    {
	       obj_t aux_5895;
	       aux_5895 = STRUCT_REF(s_1411, ((long) 2));
	       v1645_1416 = (type_t) (aux_5895);
	    }
	    ((((select_t) CREF(o_1410))->type) = ((type_t) v1645_1416), BUNSPEC);
	 }
	 {
	    obj_t v1649_1417;
	    v1649_1417 = STRUCT_REF(s_1411, ((long) 3));
	    ((((select_t) CREF(o_1410))->side_effect__165) = ((obj_t) v1649_1417), BUNSPEC);
	 }
	 {
	    obj_t v1653_1418;
	    v1653_1418 = STRUCT_REF(s_1411, ((long) 4));
	    ((((select_t) CREF(o_1410))->key) = ((obj_t) v1653_1418), BUNSPEC);
	 }
	 {
	    node_t v1657_1419;
	    {
	       obj_t aux_5903;
	       aux_5903 = STRUCT_REF(s_1411, ((long) 5));
	       v1657_1419 = (node_t) (aux_5903);
	    }
	    ((((select_t) CREF(o_1410))->test) = ((node_t) v1657_1419), BUNSPEC);
	 }
	 {
	    obj_t v1661_1420;
	    v1661_1420 = STRUCT_REF(s_1411, ((long) 6));
	    ((((select_t) CREF(o_1410))->clauses) = ((obj_t) v1661_1420), BUNSPEC);
	 }
	 {
	    type_t v1665_1421;
	    {
	       obj_t aux_5909;
	       aux_5909 = STRUCT_REF(s_1411, ((long) 7));
	       v1665_1421 = (type_t) (aux_5909);
	    }
	    ((((select_t) CREF(o_1410))->item_type_130) = ((type_t) v1665_1421), BUNSPEC);
	 }
	 aux_5887 = o_1410;
	 return (obj_t) (aux_5887);
      }
   }
}


/* object->struct-select */ obj_t 
object__struct_select_180_ast_node(obj_t env_3673, obj_t obj1637_3674)
{
   {
      select_t obj1637_1388;
      obj1637_1388 = (select_t) (obj1637_3674);
      {
	 obj_t res1638_1391;
	 {
	    obj_t aux_5915;
	    aux_5915 = CNST_TABLE_REF(((long) 15));
	    res1638_1391 = make_struct(aux_5915, ((long) 8), BUNSPEC);
	 }
	 STRUCT_SET(res1638_1391, ((long) 0), BFALSE);
	 {
	    obj_t aux_5919;
	    aux_5919 = (((select_t) CREF(obj1637_1388))->loc);
	    STRUCT_SET(res1638_1391, ((long) 1), aux_5919);
	 }
	 {
	    obj_t aux_5922;
	    {
	       type_t aux_5923;
	       aux_5923 = (((select_t) CREF(obj1637_1388))->type);
	       aux_5922 = (obj_t) (aux_5923);
	    }
	    STRUCT_SET(res1638_1391, ((long) 2), aux_5922);
	 }
	 {
	    obj_t aux_5927;
	    aux_5927 = (((select_t) CREF(obj1637_1388))->side_effect__165);
	    STRUCT_SET(res1638_1391, ((long) 3), aux_5927);
	 }
	 {
	    obj_t aux_5930;
	    aux_5930 = (((select_t) CREF(obj1637_1388))->key);
	    STRUCT_SET(res1638_1391, ((long) 4), aux_5930);
	 }
	 {
	    obj_t aux_5933;
	    {
	       node_t aux_5934;
	       aux_5934 = (((select_t) CREF(obj1637_1388))->test);
	       aux_5933 = (obj_t) (aux_5934);
	    }
	    STRUCT_SET(res1638_1391, ((long) 5), aux_5933);
	 }
	 {
	    obj_t aux_5938;
	    aux_5938 = (((select_t) CREF(obj1637_1388))->clauses);
	    STRUCT_SET(res1638_1391, ((long) 6), aux_5938);
	 }
	 {
	    obj_t aux_5941;
	    {
	       type_t aux_5942;
	       aux_5942 = (((select_t) CREF(obj1637_1388))->item_type_130);
	       aux_5941 = (obj_t) (aux_5942);
	    }
	    STRUCT_SET(res1638_1391, ((long) 7), aux_5941);
	 }
	 return res1638_1391;
      }
   }
}


/* struct+object->object-let-fun */ obj_t 
struct_object__object_let_fun_200_ast_node(obj_t env_3675, obj_t o_3676, obj_t s_3677)
{
   {
      let_fun_218_t o_1375;
      obj_t s_1376;
      {
	 let_fun_218_t aux_5947;
	 o_1375 = (let_fun_218_t) (o_3676);
	 s_1376 = s_3677;
	 {
	    obj_t aux_5950;
	    object_t aux_5948;
	    aux_5950 = STRUCT_REF(s_1376, ((long) 0));
	    aux_5948 = (object_t) (o_1375);
	    OBJECT_WIDENING_SET(aux_5948, aux_5950);
	 }
	 {
	    obj_t v1685_1380;
	    v1685_1380 = STRUCT_REF(s_1376, ((long) 1));
	    ((((let_fun_218_t) CREF(o_1375))->loc) = ((obj_t) v1685_1380), BUNSPEC);
	 }
	 {
	    type_t v1689_1381;
	    {
	       obj_t aux_5955;
	       aux_5955 = STRUCT_REF(s_1376, ((long) 2));
	       v1689_1381 = (type_t) (aux_5955);
	    }
	    ((((let_fun_218_t) CREF(o_1375))->type) = ((type_t) v1689_1381), BUNSPEC);
	 }
	 {
	    obj_t v1693_1382;
	    v1693_1382 = STRUCT_REF(s_1376, ((long) 3));
	    ((((let_fun_218_t) CREF(o_1375))->side_effect__165) = ((obj_t) v1693_1382), BUNSPEC);
	 }
	 {
	    obj_t v1697_1383;
	    v1697_1383 = STRUCT_REF(s_1376, ((long) 4));
	    ((((let_fun_218_t) CREF(o_1375))->key) = ((obj_t) v1697_1383), BUNSPEC);
	 }
	 {
	    obj_t v1701_1384;
	    v1701_1384 = STRUCT_REF(s_1376, ((long) 5));
	    ((((let_fun_218_t) CREF(o_1375))->locals) = ((obj_t) v1701_1384), BUNSPEC);
	 }
	 {
	    node_t v1705_1385;
	    {
	       obj_t aux_5965;
	       aux_5965 = STRUCT_REF(s_1376, ((long) 6));
	       v1705_1385 = (node_t) (aux_5965);
	    }
	    ((((let_fun_218_t) CREF(o_1375))->body) = ((node_t) v1705_1385), BUNSPEC);
	 }
	 aux_5947 = o_1375;
	 return (obj_t) (aux_5947);
      }
   }
}


/* object->struct-let-fun */ obj_t 
object__struct_let_fun_125_ast_node(obj_t env_3678, obj_t obj1681_3679)
{
   {
      let_fun_218_t obj1681_1355;
      obj1681_1355 = (let_fun_218_t) (obj1681_3679);
      {
	 obj_t res1682_1358;
	 {
	    obj_t aux_5971;
	    aux_5971 = CNST_TABLE_REF(((long) 16));
	    res1682_1358 = make_struct(aux_5971, ((long) 7), BUNSPEC);
	 }
	 STRUCT_SET(res1682_1358, ((long) 0), BFALSE);
	 {
	    obj_t aux_5975;
	    aux_5975 = (((let_fun_218_t) CREF(obj1681_1355))->loc);
	    STRUCT_SET(res1682_1358, ((long) 1), aux_5975);
	 }
	 {
	    obj_t aux_5978;
	    {
	       type_t aux_5979;
	       aux_5979 = (((let_fun_218_t) CREF(obj1681_1355))->type);
	       aux_5978 = (obj_t) (aux_5979);
	    }
	    STRUCT_SET(res1682_1358, ((long) 2), aux_5978);
	 }
	 {
	    obj_t aux_5983;
	    aux_5983 = (((let_fun_218_t) CREF(obj1681_1355))->side_effect__165);
	    STRUCT_SET(res1682_1358, ((long) 3), aux_5983);
	 }
	 {
	    obj_t aux_5986;
	    aux_5986 = (((let_fun_218_t) CREF(obj1681_1355))->key);
	    STRUCT_SET(res1682_1358, ((long) 4), aux_5986);
	 }
	 {
	    obj_t aux_5989;
	    aux_5989 = (((let_fun_218_t) CREF(obj1681_1355))->locals);
	    STRUCT_SET(res1682_1358, ((long) 5), aux_5989);
	 }
	 {
	    obj_t aux_5992;
	    {
	       node_t aux_5993;
	       aux_5993 = (((let_fun_218_t) CREF(obj1681_1355))->body);
	       aux_5992 = (obj_t) (aux_5993);
	    }
	    STRUCT_SET(res1682_1358, ((long) 6), aux_5992);
	 }
	 return res1682_1358;
      }
   }
}


/* struct+object->object-let-var */ obj_t 
struct_object__object_let_var_153_ast_node(obj_t env_3680, obj_t o_3681, obj_t s_3682)
{
   {
      let_var_6_t o_1341;
      obj_t s_1342;
      {
	 let_var_6_t aux_5998;
	 o_1341 = (let_var_6_t) (o_3681);
	 s_1342 = s_3682;
	 {
	    obj_t aux_6001;
	    object_t aux_5999;
	    aux_6001 = STRUCT_REF(s_1342, ((long) 0));
	    aux_5999 = (object_t) (o_1341);
	    OBJECT_WIDENING_SET(aux_5999, aux_6001);
	 }
	 {
	    obj_t v1727_1346;
	    v1727_1346 = STRUCT_REF(s_1342, ((long) 1));
	    ((((let_var_6_t) CREF(o_1341))->loc) = ((obj_t) v1727_1346), BUNSPEC);
	 }
	 {
	    type_t v1731_1347;
	    {
	       obj_t aux_6006;
	       aux_6006 = STRUCT_REF(s_1342, ((long) 2));
	       v1731_1347 = (type_t) (aux_6006);
	    }
	    ((((let_var_6_t) CREF(o_1341))->type) = ((type_t) v1731_1347), BUNSPEC);
	 }
	 {
	    obj_t v1735_1348;
	    v1735_1348 = STRUCT_REF(s_1342, ((long) 3));
	    ((((let_var_6_t) CREF(o_1341))->side_effect__165) = ((obj_t) v1735_1348), BUNSPEC);
	 }
	 {
	    obj_t v1739_1349;
	    v1739_1349 = STRUCT_REF(s_1342, ((long) 4));
	    ((((let_var_6_t) CREF(o_1341))->key) = ((obj_t) v1739_1349), BUNSPEC);
	 }
	 {
	    obj_t v1743_1350;
	    v1743_1350 = STRUCT_REF(s_1342, ((long) 5));
	    ((((let_var_6_t) CREF(o_1341))->bindings) = ((obj_t) v1743_1350), BUNSPEC);
	 }
	 {
	    node_t v1747_1351;
	    {
	       obj_t aux_6016;
	       aux_6016 = STRUCT_REF(s_1342, ((long) 6));
	       v1747_1351 = (node_t) (aux_6016);
	    }
	    ((((let_var_6_t) CREF(o_1341))->body) = ((node_t) v1747_1351), BUNSPEC);
	 }
	 {
	    bool_t v1751_1352;
	    {
	       obj_t aux_6020;
	       aux_6020 = STRUCT_REF(s_1342, ((long) 7));
	       v1751_1352 = CBOOL(aux_6020);
	    }
	    ((((let_var_6_t) CREF(o_1341))->removable__42) = ((bool_t) v1751_1352), BUNSPEC);
	 }
	 aux_5998 = o_1341;
	 return (obj_t) (aux_5998);
      }
   }
}


/* object->struct-let-var */ obj_t 
object__struct_let_var_26_ast_node(obj_t env_3683, obj_t obj1723_3684)
{
   {
      let_var_6_t obj1723_1319;
      obj1723_1319 = (let_var_6_t) (obj1723_3684);
      {
	 obj_t res1724_1322;
	 {
	    obj_t aux_6026;
	    aux_6026 = CNST_TABLE_REF(((long) 17));
	    res1724_1322 = make_struct(aux_6026, ((long) 8), BUNSPEC);
	 }
	 STRUCT_SET(res1724_1322, ((long) 0), BFALSE);
	 {
	    obj_t aux_6030;
	    aux_6030 = (((let_var_6_t) CREF(obj1723_1319))->loc);
	    STRUCT_SET(res1724_1322, ((long) 1), aux_6030);
	 }
	 {
	    obj_t aux_6033;
	    {
	       type_t aux_6034;
	       aux_6034 = (((let_var_6_t) CREF(obj1723_1319))->type);
	       aux_6033 = (obj_t) (aux_6034);
	    }
	    STRUCT_SET(res1724_1322, ((long) 2), aux_6033);
	 }
	 {
	    obj_t aux_6038;
	    aux_6038 = (((let_var_6_t) CREF(obj1723_1319))->side_effect__165);
	    STRUCT_SET(res1724_1322, ((long) 3), aux_6038);
	 }
	 {
	    obj_t aux_6041;
	    aux_6041 = (((let_var_6_t) CREF(obj1723_1319))->key);
	    STRUCT_SET(res1724_1322, ((long) 4), aux_6041);
	 }
	 {
	    obj_t aux_6044;
	    aux_6044 = (((let_var_6_t) CREF(obj1723_1319))->bindings);
	    STRUCT_SET(res1724_1322, ((long) 5), aux_6044);
	 }
	 {
	    obj_t aux_6047;
	    {
	       node_t aux_6048;
	       aux_6048 = (((let_var_6_t) CREF(obj1723_1319))->body);
	       aux_6047 = (obj_t) (aux_6048);
	    }
	    STRUCT_SET(res1724_1322, ((long) 6), aux_6047);
	 }
	 {
	    obj_t aux_6052;
	    {
	       bool_t aux_6053;
	       aux_6053 = (((let_var_6_t) CREF(obj1723_1319))->removable__42);
	       aux_6052 = BBOOL(aux_6053);
	    }
	    STRUCT_SET(res1724_1322, ((long) 7), aux_6052);
	 }
	 return res1724_1322;
      }
   }
}


/* struct+object->object-set-ex-it */ obj_t 
struct_object__object_set_ex_it_208_ast_node(obj_t env_3685, obj_t o_3686, obj_t s_3687)
{
   {
      set_ex_it_116_t o_1308;
      obj_t s_1309;
      {
	 set_ex_it_116_t aux_6058;
	 o_1308 = (set_ex_it_116_t) (o_3686);
	 s_1309 = s_3687;
	 {
	    obj_t aux_6061;
	    object_t aux_6059;
	    aux_6061 = STRUCT_REF(s_1309, ((long) 0));
	    aux_6059 = (object_t) (o_1308);
	    OBJECT_WIDENING_SET(aux_6059, aux_6061);
	 }
	 {
	    obj_t v1768_1313;
	    v1768_1313 = STRUCT_REF(s_1309, ((long) 1));
	    ((((set_ex_it_116_t) CREF(o_1308))->loc) = ((obj_t) v1768_1313), BUNSPEC);
	 }
	 {
	    type_t v1772_1314;
	    {
	       obj_t aux_6066;
	       aux_6066 = STRUCT_REF(s_1309, ((long) 2));
	       v1772_1314 = (type_t) (aux_6066);
	    }
	    ((((set_ex_it_116_t) CREF(o_1308))->type) = ((type_t) v1772_1314), BUNSPEC);
	 }
	 {
	    var_t v1776_1315;
	    {
	       obj_t aux_6070;
	       aux_6070 = STRUCT_REF(s_1309, ((long) 3));
	       v1776_1315 = (var_t) (aux_6070);
	    }
	    ((((set_ex_it_116_t) CREF(o_1308))->var) = ((var_t) v1776_1315), BUNSPEC);
	 }
	 {
	    node_t v1780_1316;
	    {
	       obj_t aux_6074;
	       aux_6074 = STRUCT_REF(s_1309, ((long) 4));
	       v1780_1316 = (node_t) (aux_6074);
	    }
	    ((((set_ex_it_116_t) CREF(o_1308))->body) = ((node_t) v1780_1316), BUNSPEC);
	 }
	 aux_6058 = o_1308;
	 return (obj_t) (aux_6058);
      }
   }
}


/* object->struct-set-ex-it */ obj_t 
object__struct_set_ex_it_235_ast_node(obj_t env_3688, obj_t obj1764_3689)
{
   {
      set_ex_it_116_t obj1764_1292;
      obj1764_1292 = (set_ex_it_116_t) (obj1764_3689);
      {
	 obj_t res1765_1295;
	 {
	    obj_t aux_6080;
	    aux_6080 = CNST_TABLE_REF(((long) 18));
	    res1765_1295 = make_struct(aux_6080, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1765_1295, ((long) 0), BFALSE);
	 {
	    obj_t aux_6084;
	    aux_6084 = (((set_ex_it_116_t) CREF(obj1764_1292))->loc);
	    STRUCT_SET(res1765_1295, ((long) 1), aux_6084);
	 }
	 {
	    obj_t aux_6087;
	    {
	       type_t aux_6088;
	       aux_6088 = (((set_ex_it_116_t) CREF(obj1764_1292))->type);
	       aux_6087 = (obj_t) (aux_6088);
	    }
	    STRUCT_SET(res1765_1295, ((long) 2), aux_6087);
	 }
	 {
	    obj_t aux_6092;
	    {
	       var_t aux_6093;
	       aux_6093 = (((set_ex_it_116_t) CREF(obj1764_1292))->var);
	       aux_6092 = (obj_t) (aux_6093);
	    }
	    STRUCT_SET(res1765_1295, ((long) 3), aux_6092);
	 }
	 {
	    obj_t aux_6097;
	    {
	       node_t aux_6098;
	       aux_6098 = (((set_ex_it_116_t) CREF(obj1764_1292))->body);
	       aux_6097 = (obj_t) (aux_6098);
	    }
	    STRUCT_SET(res1765_1295, ((long) 4), aux_6097);
	 }
	 return res1765_1295;
      }
   }
}


/* struct+object->object-jump-ex-it */ obj_t 
struct_object__object_jump_ex_it_246_ast_node(obj_t env_3690, obj_t o_3691, obj_t s_3692)
{
   {
      jump_ex_it_184_t o_1281;
      obj_t s_1282;
      {
	 jump_ex_it_184_t aux_6103;
	 o_1281 = (jump_ex_it_184_t) (o_3691);
	 s_1282 = s_3692;
	 {
	    obj_t aux_6106;
	    object_t aux_6104;
	    aux_6106 = STRUCT_REF(s_1282, ((long) 0));
	    aux_6104 = (object_t) (o_1281);
	    OBJECT_WIDENING_SET(aux_6104, aux_6106);
	 }
	 {
	    obj_t v1796_1286;
	    v1796_1286 = STRUCT_REF(s_1282, ((long) 1));
	    ((((jump_ex_it_184_t) CREF(o_1281))->loc) = ((obj_t) v1796_1286), BUNSPEC);
	 }
	 {
	    type_t v1800_1287;
	    {
	       obj_t aux_6111;
	       aux_6111 = STRUCT_REF(s_1282, ((long) 2));
	       v1800_1287 = (type_t) (aux_6111);
	    }
	    ((((jump_ex_it_184_t) CREF(o_1281))->type) = ((type_t) v1800_1287), BUNSPEC);
	 }
	 {
	    node_t v1804_1288;
	    {
	       obj_t aux_6115;
	       aux_6115 = STRUCT_REF(s_1282, ((long) 3));
	       v1804_1288 = (node_t) (aux_6115);
	    }
	    ((((jump_ex_it_184_t) CREF(o_1281))->exit) = ((node_t) v1804_1288), BUNSPEC);
	 }
	 {
	    node_t v1808_1289;
	    {
	       obj_t aux_6119;
	       aux_6119 = STRUCT_REF(s_1282, ((long) 4));
	       v1808_1289 = (node_t) (aux_6119);
	    }
	    ((((jump_ex_it_184_t) CREF(o_1281))->value) = ((node_t) v1808_1289), BUNSPEC);
	 }
	 aux_6103 = o_1281;
	 return (obj_t) (aux_6103);
      }
   }
}


/* object->struct-jump-ex-it */ obj_t 
object__struct_jump_ex_it_205_ast_node(obj_t env_3693, obj_t obj1792_3694)
{
   {
      jump_ex_it_184_t obj1792_1265;
      obj1792_1265 = (jump_ex_it_184_t) (obj1792_3694);
      {
	 obj_t res1793_1268;
	 {
	    obj_t aux_6125;
	    aux_6125 = CNST_TABLE_REF(((long) 19));
	    res1793_1268 = make_struct(aux_6125, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1793_1268, ((long) 0), BFALSE);
	 {
	    obj_t aux_6129;
	    aux_6129 = (((jump_ex_it_184_t) CREF(obj1792_1265))->loc);
	    STRUCT_SET(res1793_1268, ((long) 1), aux_6129);
	 }
	 {
	    obj_t aux_6132;
	    {
	       type_t aux_6133;
	       aux_6133 = (((jump_ex_it_184_t) CREF(obj1792_1265))->type);
	       aux_6132 = (obj_t) (aux_6133);
	    }
	    STRUCT_SET(res1793_1268, ((long) 2), aux_6132);
	 }
	 {
	    obj_t aux_6137;
	    {
	       node_t aux_6138;
	       aux_6138 = (((jump_ex_it_184_t) CREF(obj1792_1265))->exit);
	       aux_6137 = (obj_t) (aux_6138);
	    }
	    STRUCT_SET(res1793_1268, ((long) 3), aux_6137);
	 }
	 {
	    obj_t aux_6142;
	    {
	       node_t aux_6143;
	       aux_6143 = (((jump_ex_it_184_t) CREF(obj1792_1265))->value);
	       aux_6142 = (obj_t) (aux_6143);
	    }
	    STRUCT_SET(res1793_1268, ((long) 4), aux_6142);
	 }
	 return res1793_1268;
      }
   }
}


/* struct+object->object-make-box */ obj_t 
struct_object__object_make_box_39_ast_node(obj_t env_3695, obj_t o_3696, obj_t s_3697)
{
   {
      make_box_202_t o_1253;
      obj_t s_1254;
      {
	 make_box_202_t aux_6148;
	 o_1253 = (make_box_202_t) (o_3696);
	 s_1254 = s_3697;
	 {
	    obj_t aux_6151;
	    object_t aux_6149;
	    aux_6151 = STRUCT_REF(s_1254, ((long) 0));
	    aux_6149 = (object_t) (o_1253);
	    OBJECT_WIDENING_SET(aux_6149, aux_6151);
	 }
	 {
	    obj_t v1826_1258;
	    v1826_1258 = STRUCT_REF(s_1254, ((long) 1));
	    ((((make_box_202_t) CREF(o_1253))->loc) = ((obj_t) v1826_1258), BUNSPEC);
	 }
	 {
	    type_t v1830_1259;
	    {
	       obj_t aux_6156;
	       aux_6156 = STRUCT_REF(s_1254, ((long) 2));
	       v1830_1259 = (type_t) (aux_6156);
	    }
	    ((((make_box_202_t) CREF(o_1253))->type) = ((type_t) v1830_1259), BUNSPEC);
	 }
	 {
	    obj_t v1834_1260;
	    v1834_1260 = STRUCT_REF(s_1254, ((long) 3));
	    ((((make_box_202_t) CREF(o_1253))->side_effect__165) = ((obj_t) v1834_1260), BUNSPEC);
	 }
	 {
	    obj_t v1838_1261;
	    v1838_1261 = STRUCT_REF(s_1254, ((long) 4));
	    ((((make_box_202_t) CREF(o_1253))->key) = ((obj_t) v1838_1261), BUNSPEC);
	 }
	 {
	    node_t v1842_1262;
	    {
	       obj_t aux_6164;
	       aux_6164 = STRUCT_REF(s_1254, ((long) 5));
	       v1842_1262 = (node_t) (aux_6164);
	    }
	    ((((make_box_202_t) CREF(o_1253))->value) = ((node_t) v1842_1262), BUNSPEC);
	 }
	 aux_6148 = o_1253;
	 return (obj_t) (aux_6148);
      }
   }
}


/* object->struct-make-box */ obj_t 
object__struct_make_box_59_ast_node(obj_t env_3698, obj_t obj1822_3699)
{
   {
      make_box_202_t obj1822_1235;
      obj1822_1235 = (make_box_202_t) (obj1822_3699);
      {
	 obj_t res1823_1238;
	 {
	    obj_t aux_6170;
	    aux_6170 = CNST_TABLE_REF(((long) 20));
	    res1823_1238 = make_struct(aux_6170, ((long) 6), BUNSPEC);
	 }
	 STRUCT_SET(res1823_1238, ((long) 0), BFALSE);
	 {
	    obj_t aux_6174;
	    aux_6174 = (((make_box_202_t) CREF(obj1822_1235))->loc);
	    STRUCT_SET(res1823_1238, ((long) 1), aux_6174);
	 }
	 {
	    obj_t aux_6177;
	    {
	       type_t aux_6178;
	       aux_6178 = (((make_box_202_t) CREF(obj1822_1235))->type);
	       aux_6177 = (obj_t) (aux_6178);
	    }
	    STRUCT_SET(res1823_1238, ((long) 2), aux_6177);
	 }
	 {
	    obj_t aux_6182;
	    aux_6182 = (((make_box_202_t) CREF(obj1822_1235))->side_effect__165);
	    STRUCT_SET(res1823_1238, ((long) 3), aux_6182);
	 }
	 {
	    obj_t aux_6185;
	    aux_6185 = (((make_box_202_t) CREF(obj1822_1235))->key);
	    STRUCT_SET(res1823_1238, ((long) 4), aux_6185);
	 }
	 {
	    obj_t aux_6188;
	    {
	       node_t aux_6189;
	       aux_6189 = (((make_box_202_t) CREF(obj1822_1235))->value);
	       aux_6188 = (obj_t) (aux_6189);
	    }
	    STRUCT_SET(res1823_1238, ((long) 5), aux_6188);
	 }
	 return res1823_1238;
      }
   }
}


/* struct+object->object-box-ref */ obj_t 
struct_object__object_box_ref_217_ast_node(obj_t env_3700, obj_t o_3701, obj_t s_3702)
{
   {
      box_ref_242_t o_1223;
      obj_t s_1224;
      {
	 box_ref_242_t aux_6194;
	 o_1223 = (box_ref_242_t) (o_3701);
	 s_1224 = s_3702;
	 {
	    obj_t aux_6197;
	    object_t aux_6195;
	    aux_6197 = STRUCT_REF(s_1224, ((long) 0));
	    aux_6195 = (object_t) (o_1223);
	    OBJECT_WIDENING_SET(aux_6195, aux_6197);
	 }
	 {
	    obj_t v1860_1228;
	    v1860_1228 = STRUCT_REF(s_1224, ((long) 1));
	    ((((box_ref_242_t) CREF(o_1223))->loc) = ((obj_t) v1860_1228), BUNSPEC);
	 }
	 {
	    type_t v1864_1229;
	    {
	       obj_t aux_6202;
	       aux_6202 = STRUCT_REF(s_1224, ((long) 2));
	       v1864_1229 = (type_t) (aux_6202);
	    }
	    ((((box_ref_242_t) CREF(o_1223))->type) = ((type_t) v1864_1229), BUNSPEC);
	 }
	 {
	    obj_t v1868_1230;
	    v1868_1230 = STRUCT_REF(s_1224, ((long) 3));
	    ((((box_ref_242_t) CREF(o_1223))->side_effect__165) = ((obj_t) v1868_1230), BUNSPEC);
	 }
	 {
	    obj_t v1872_1231;
	    v1872_1231 = STRUCT_REF(s_1224, ((long) 4));
	    ((((box_ref_242_t) CREF(o_1223))->key) = ((obj_t) v1872_1231), BUNSPEC);
	 }
	 {
	    var_t v1876_1232;
	    {
	       obj_t aux_6210;
	       aux_6210 = STRUCT_REF(s_1224, ((long) 5));
	       v1876_1232 = (var_t) (aux_6210);
	    }
	    ((((box_ref_242_t) CREF(o_1223))->var) = ((var_t) v1876_1232), BUNSPEC);
	 }
	 aux_6194 = o_1223;
	 return (obj_t) (aux_6194);
      }
   }
}


/* object->struct-box-ref */ obj_t 
object__struct_box_ref_94_ast_node(obj_t env_3703, obj_t obj1856_3704)
{
   {
      box_ref_242_t obj1856_1205;
      obj1856_1205 = (box_ref_242_t) (obj1856_3704);
      {
	 obj_t res1857_1208;
	 {
	    obj_t aux_6216;
	    aux_6216 = CNST_TABLE_REF(((long) 21));
	    res1857_1208 = make_struct(aux_6216, ((long) 6), BUNSPEC);
	 }
	 STRUCT_SET(res1857_1208, ((long) 0), BFALSE);
	 {
	    obj_t aux_6220;
	    aux_6220 = (((box_ref_242_t) CREF(obj1856_1205))->loc);
	    STRUCT_SET(res1857_1208, ((long) 1), aux_6220);
	 }
	 {
	    obj_t aux_6223;
	    {
	       type_t aux_6224;
	       aux_6224 = (((box_ref_242_t) CREF(obj1856_1205))->type);
	       aux_6223 = (obj_t) (aux_6224);
	    }
	    STRUCT_SET(res1857_1208, ((long) 2), aux_6223);
	 }
	 {
	    obj_t aux_6228;
	    aux_6228 = (((box_ref_242_t) CREF(obj1856_1205))->side_effect__165);
	    STRUCT_SET(res1857_1208, ((long) 3), aux_6228);
	 }
	 {
	    obj_t aux_6231;
	    aux_6231 = (((box_ref_242_t) CREF(obj1856_1205))->key);
	    STRUCT_SET(res1857_1208, ((long) 4), aux_6231);
	 }
	 {
	    obj_t aux_6234;
	    {
	       var_t aux_6235;
	       aux_6235 = (((box_ref_242_t) CREF(obj1856_1205))->var);
	       aux_6234 = (obj_t) (aux_6235);
	    }
	    STRUCT_SET(res1857_1208, ((long) 5), aux_6234);
	 }
	 return res1857_1208;
      }
   }
}


/* struct+object->object-box-set! */ obj_t 
struct_object__object_box_set__45_ast_node(obj_t env_3705, obj_t o_3706, obj_t s_3707)
{
   {
      box_set__221_t o_1194;
      obj_t s_1195;
      {
	 box_set__221_t aux_6240;
	 o_1194 = (box_set__221_t) (o_3706);
	 s_1195 = s_3707;
	 {
	    obj_t aux_6243;
	    object_t aux_6241;
	    aux_6243 = STRUCT_REF(s_1195, ((long) 0));
	    aux_6241 = (object_t) (o_1194);
	    OBJECT_WIDENING_SET(aux_6241, aux_6243);
	 }
	 {
	    obj_t v1892_1199;
	    v1892_1199 = STRUCT_REF(s_1195, ((long) 1));
	    ((((box_set__221_t) CREF(o_1194))->loc) = ((obj_t) v1892_1199), BUNSPEC);
	 }
	 {
	    type_t v1896_1200;
	    {
	       obj_t aux_6248;
	       aux_6248 = STRUCT_REF(s_1195, ((long) 2));
	       v1896_1200 = (type_t) (aux_6248);
	    }
	    ((((box_set__221_t) CREF(o_1194))->type) = ((type_t) v1896_1200), BUNSPEC);
	 }
	 {
	    var_t v1900_1201;
	    {
	       obj_t aux_6252;
	       aux_6252 = STRUCT_REF(s_1195, ((long) 3));
	       v1900_1201 = (var_t) (aux_6252);
	    }
	    ((((box_set__221_t) CREF(o_1194))->var) = ((var_t) v1900_1201), BUNSPEC);
	 }
	 {
	    node_t v1904_1202;
	    {
	       obj_t aux_6256;
	       aux_6256 = STRUCT_REF(s_1195, ((long) 4));
	       v1904_1202 = (node_t) (aux_6256);
	    }
	    ((((box_set__221_t) CREF(o_1194))->value) = ((node_t) v1904_1202), BUNSPEC);
	 }
	 aux_6240 = o_1194;
	 return (obj_t) (aux_6240);
      }
   }
}


/* object->struct-box-set! */ obj_t 
object__struct_box_set__198_ast_node(obj_t env_3708, obj_t obj1888_3709)
{
   {
      box_set__221_t obj1888_1178;
      obj1888_1178 = (box_set__221_t) (obj1888_3709);
      {
	 obj_t res1889_1181;
	 {
	    obj_t aux_6262;
	    aux_6262 = CNST_TABLE_REF(((long) 22));
	    res1889_1181 = make_struct(aux_6262, ((long) 5), BUNSPEC);
	 }
	 STRUCT_SET(res1889_1181, ((long) 0), BFALSE);
	 {
	    obj_t aux_6266;
	    aux_6266 = (((box_set__221_t) CREF(obj1888_1178))->loc);
	    STRUCT_SET(res1889_1181, ((long) 1), aux_6266);
	 }
	 {
	    obj_t aux_6269;
	    {
	       type_t aux_6270;
	       aux_6270 = (((box_set__221_t) CREF(obj1888_1178))->type);
	       aux_6269 = (obj_t) (aux_6270);
	    }
	    STRUCT_SET(res1889_1181, ((long) 2), aux_6269);
	 }
	 {
	    obj_t aux_6274;
	    {
	       var_t aux_6275;
	       aux_6275 = (((box_set__221_t) CREF(obj1888_1178))->var);
	       aux_6274 = (obj_t) (aux_6275);
	    }
	    STRUCT_SET(res1889_1181, ((long) 3), aux_6274);
	 }
	 {
	    obj_t aux_6279;
	    {
	       node_t aux_6280;
	       aux_6280 = (((box_set__221_t) CREF(obj1888_1178))->value);
	       aux_6279 = (obj_t) (aux_6280);
	    }
	    STRUCT_SET(res1889_1181, ((long) 4), aux_6279);
	 }
	 return res1889_1181;
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_node()
{
   module_initialization_70_type_type(((long) 0), "AST_NODE");
   return module_initialization_70_ast_var(((long) 0), "AST_NODE");
}
