/*===========================================================================*/
/*   (Object/class.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


extern class_t make_class_185_object_class(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, global_t, obj_t, long, bool_t, obj_t);
extern obj_t class_tvector_28_object_class(type_t);
static obj_t method_init_76_object_class();
static obj_t _declare_class_type__21_object_class(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t class_widening_213_object_class(class_t);
static obj_t _type_subclass__143_object_class(obj_t, obj_t, obj_t);
static obj_t _class_size_set__221_object_class(obj_t, obj_t, obj_t);
static obj_t _class_final__173_object_class(obj_t, obj_t);
static obj_t _class__187_object_class(obj_t, obj_t);
static obj_t _class_init__set__12_object_class(obj_t, obj_t, obj_t);
static obj_t _class_magic__112_object_class(obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
extern class_t widening1002_class_162_object_class(obj_t, obj_t, global_t, obj_t, long, bool_t, obj_t);
static obj_t _class___set__85_object_class(obj_t, obj_t, obj_t);
extern obj_t type_type_type;
extern obj_t class_pointed_to_by_set__1_object_class(type_t, obj_t);
static obj_t _find_class_constructors1489_106_object_class(obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern type_t declare_type__118_type_env(obj_t, obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _object__struct1494_97___object(obj_t, obj_t);
extern obj_t class_init__set__101_object_class(type_t, bool_t);
extern obj_t get_object_type_154_type_cache();
static obj_t _class_parents_102_object_class(obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern bool_t type_subclass__90_object_class(type_t, type_t);
static obj_t _final_class__214_object_class(obj_t, obj_t);
static obj_t _wide_class__223_object_class(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _class_init__204_object_class(obj_t, obj_t);
extern type_t declare_class_type__110_object_class(obj_t, global_t, obj_t, bool_t, obj_t);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_object_tools(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _class_constructor_88_object_class(obj_t, obj_t);
extern obj_t class_its_super_90_object_class(class_t);
static obj_t _class_pointed_to_by_138_object_class(obj_t, obj_t);
extern bool_t wide_class__100_object_class(obj_t);
static obj_t _class_id_54_object_class(obj_t, obj_t);
static obj_t _make_class_28_object_class(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t class_constructor_163_object_class(class_t);
extern bool_t class_init__242_object_class(type_t);
static obj_t _class_parents_set__46_object_class(obj_t, obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _class_coerce_to_set__132_object_class(obj_t, obj_t, obj_t);
static obj_t _class_class_56_object_class(obj_t, obj_t);
extern obj_t class_id_86_object_class(type_t);
extern obj_t class_tvector_set__125_object_class(type_t, obj_t);
static obj_t imported_modules_init_94_object_class();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t class_class_86_object_class(type_t);
static obj_t _class_alias_149_object_class(obj_t, obj_t);
static obj_t _class_alias_set__148_object_class(obj_t, obj_t, obj_t);
static obj_t _class_slots_24_object_class(obj_t, obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t _class_its_super_160_object_class(obj_t, obj_t);
extern obj_t id__name_228_ast_ident(obj_t);
extern obj_t heap_add_class__147_object_class(class_t);
static obj_t _struct_object__object1492_161___object(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_object_class();
static obj_t _class_tvector_206_object_class(obj_t, obj_t);
static obj_t _class_slots_set__80_object_class(obj_t, obj_t, obj_t);
extern obj_t class_size_35_object_class(type_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t class_name_set__214_object_class(type_t, obj_t);
extern obj_t class_alias_73_object_class(type_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t class_slots_173_object_class(class_t);
extern obj_t class_pointed_to_by_250_object_class(type_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t struct_object__object_class_152_object_class(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_object_class();
extern obj_t class_alias_set__87_object_class(type_t, obj_t);
static obj_t _class_its_super_set__186_object_class(obj_t, obj_t, obj_t);
static obj_t _class___26_object_class(obj_t, obj_t);
static obj_t _widening1002_class_137_object_class(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _class_class_set__27_object_class(obj_t, obj_t, obj_t);
static obj_t object__struct_class_161_object_class(obj_t, obj_t);
extern obj_t class_name_139_object_class(type_t);
extern obj_t class_coerce_to_set__33_object_class(type_t, obj_t);
static obj_t _class_magic__set__166_object_class(obj_t, obj_t, obj_t);
extern global_t class_holder_88_object_class(class_t);
extern obj_t class_slots_set__26_object_class(class_t, obj_t);
extern obj_t class_parents_195_object_class(type_t);
obj_t class_object_class = BUNSPEC;
extern obj_t class_magic__set__200_object_class(type_t, bool_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern obj_t class___24_object_class(type_t);
extern obj_t _case_sensitive__90_engine_param;
extern obj_t class_class_set__34_object_class(type_t, obj_t);
static obj_t _class_depth_246_object_class(obj_t, obj_t);
static obj_t _class_type_list__185_object_class = BUNSPEC;
static obj_t _class_name_set__29_object_class(obj_t, obj_t, obj_t);
static obj_t _allocate_class_74_object_class(obj_t);
extern obj_t class_coerce_to_190_object_class(type_t);
extern bool_t class_final__216_object_class(class_t);
static obj_t _class_depth_set__234_object_class(obj_t, obj_t, obj_t);
extern bool_t class_magic__8_object_class(type_t);
static obj_t object_init_111_object_class();
extern obj_t class___set__80_object_class(type_t, obj_t);
extern long class_depth_60_object_class(class_t);
extern obj_t class_parents_set__241_object_class(type_t, obj_t);
static obj_t _class_widening_123_object_class(obj_t, obj_t);
static obj_t _emit_class_types_128_object_class(obj_t, obj_t);
extern obj_t class_size_set__10_object_class(type_t, obj_t);
static obj_t cross_name_74_object_class(obj_t);
extern obj_t class_its_super_set__79_object_class(class_t, obj_t);
static obj_t _class_size_220_object_class(obj_t, obj_t);
static obj_t _heap_add_class_1488_165_object_class(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t class_depth_set__230_object_class(class_t, long);
static obj_t _class_holder_46_object_class(obj_t, obj_t);
static obj_t _class_tvector_set__189_object_class(obj_t, obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
static obj_t _class_name_50_object_class(obj_t, obj_t);
extern obj_t emit_class_types_26_object_class(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_object_class = BUNSPEC;
extern bool_t final_class__126_object_class(obj_t);
extern bool_t class__60_object_class(obj_t);
extern type_t allocate_class_37_object_class();
static obj_t _class_pointed_to_by_set__172_object_class(obj_t, obj_t, obj_t);
static obj_t _class_coerce_to_174_object_class(obj_t, obj_t);
extern obj_t find_class_constructors_231_object_class(class_t);
static obj_t cnst_init_137_object_class();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(class_alias_set__env_234_object_class, _class_alias_set__148_object_class1519, _class_alias_set__148_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_widening_env_36_object_class, _class_widening_123_object_class1520, _class_widening_123_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_class_set__env_70_object_class, _class_class_set__27_object_class1521, _class_class_set__27_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_alias_env_83_object_class, _class_alias_149_object_class1522, _class_alias_149_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_constructor_env_255_object_class, _class_constructor_88_object_class1523, _class_constructor_88_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_its_super_env_237_object_class, _class_its_super_160_object_class1524, _class_its_super_160_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_init__env_200_object_class, _class_init__204_object_class1525, _class_init__204_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(wide_class__env_189_object_class, _wide_class__223_object_class1526, _wide_class__223_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_class_env_121_object_class, _allocate_class_74_object_class1527, _allocate_class_74_object_class, 0L, 0);
DEFINE_EXPORT_PROCEDURE(class_depth_env_46_object_class, _class_depth_246_object_class1528, _class_depth_246_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_tvector_set__env_217_object_class, _class_tvector_set__189_object_class1529, _class_tvector_set__189_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_size_set__env_71_object_class, _class_size_set__221_object_class1530, _class_size_set__221_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(declare_class_type__env_128_object_class, _declare_class_type__21_object_class1531, _declare_class_type__21_object_class, 0L, 5);
DEFINE_EXPORT_PROCEDURE(class_tvector_env_131_object_class, _class_tvector_206_object_class1532, _class_tvector_206_object_class, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(class_id_env_138_object_class, _class_id_54_object_class1533, _class_id_54_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_slots_set__env_252_object_class, _class_slots_set__80_object_class1534, _class_slots_set__80_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_coerce_to_set__env_63_object_class, _class_coerce_to_set__132_object_class1535, _class_coerce_to_set__132_object_class, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1512_object_class, struct_object__object_class_152_object_class1536, struct_object__object_class_152_object_class, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1511_object_class, object__struct_class_161_object_class1537, object__struct_class_161_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_parents_env_57_object_class, _class_parents_102_object_class1538, _class_parents_102_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class___set__env_134_object_class, _class___set__85_object_class1539, _class___set__85_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_its_super_set__env_141_object_class, _class_its_super_set__186_object_class1540, _class_its_super_set__186_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(heap_add_class__env_177_object_class, _heap_add_class_1488_165_object_class1541, _heap_add_class_1488_165_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_class_env_203_object_class, _make_class_28_object_class1542, _make_class_28_object_class, 0L, 19);
DEFINE_EXPORT_PROCEDURE(final_class__env_178_object_class, _final_class__214_object_class1543, _final_class__214_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_name_set__env_103_object_class, _class_name_set__29_object_class1544, _class_name_set__29_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_depth_set__env_253_object_class, _class_depth_set__234_object_class1545, _class_depth_set__234_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_coerce_to_env_188_object_class, _class_coerce_to_174_object_class1546, _class_coerce_to_174_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_slots_env_56_object_class, _class_slots_24_object_class1547, _class_slots_24_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_magic__set__env_68_object_class, _class_magic__set__166_object_class1548, _class_magic__set__166_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class___env_6_object_class, _class___26_object_class1549, _class___26_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class__env_46_object_class, _class__187_object_class1550, _class__187_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_holder_env_168_object_class, _class_holder_46_object_class1551, _class_holder_46_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1002_class_env_197_object_class, _widening1002_class_137_object_class1552, _widening1002_class_137_object_class, 0L, 7);
DEFINE_EXPORT_PROCEDURE(class_name_env_116_object_class, _class_name_50_object_class1553, _class_name_50_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(emit_class_types_env_252_object_class, _emit_class_types_128_object_class1554, _emit_class_types_128_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_magic__env_130_object_class, _class_magic__112_object_class1555, _class_magic__112_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_parents_set__env_180_object_class, _class_parents_set__46_object_class1556, _class_parents_set__46_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_class_env_138_object_class, _class_class_56_object_class1557, _class_class_56_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_size_env_44_object_class, _class_size_220_object_class1558, _class_size_220_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_pointed_to_by_set__env_233_object_class, _class_pointed_to_by_set__172_object_class1559, _class_pointed_to_by_set__172_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_init__set__env_25_object_class, _class_init__set__12_object_class1560, _class_init__set__12_object_class, 0L, 2);
DEFINE_EXPORT_PROCEDURE(class_final__env_213_object_class, _class_final__173_object_class1561, _class_final__173_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(class_pointed_to_by_env_150_object_class, _class_pointed_to_by_138_object_class1562, _class_pointed_to_by_138_object_class, 0L, 1);
DEFINE_STRING(string1513_object_class, string1513_object_class1563, "CLASS BIGLOO ", 13);
DEFINE_STRING(string1499_object_class, string1499_object_class1564, " {", 2);
DEFINE_STRING(string1509_object_class, string1509_object_class1565, ";\n", 2);
DEFINE_STRING(string1510_object_class, string1510_object_class1566, "} *", 3);
DEFINE_STRING(string1498_object_class, string1498_object_class1567, "/* Object type definitions */", 29);
DEFINE_STRING(string1508_object_class, string1508_object_class1568, " ", 1);
DEFINE_STRING(string1497_object_class, string1497_object_class1569, " *", 2);
DEFINE_STRING(string1507_object_class, string1507_object_class1570, "[ ", 2);
DEFINE_STRING(string1496_object_class, string1496_object_class1571, "_t", 2);
DEFINE_STRING(string1506_object_class, string1506_object_class1572, " ]", 2);
DEFINE_STRING(string1495_object_class, string1495_object_class1573, "struct ", 7);
DEFINE_STRING(string1505_object_class, string1505_object_class1574, "   ", 3);
DEFINE_STRING(string1504_object_class, string1504_object_class1575, ";", 1);
DEFINE_STRING(string1503_object_class, string1503_object_class1576, "   obj_t    widening;", 21);
DEFINE_STRING(string1502_object_class, string1502_object_class1577, "   header_t header;", 19);
DEFINE_STRING(string1501_object_class, string1501_object_class1578, "   char dummy;", 14);
DEFINE_STRING(string1500_object_class, string1500_object_class1579, "typedef ", 8);
DEFINE_EXPORT_PROCEDURE(find_class_constructors_env_198_object_class, _find_class_constructors1489_106_object_class1580, _find_class_constructors1489_106_object_class, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_subclass__env_237_object_class, _type_subclass__143_object_class1581, _type_subclass__143_object_class, 0L, 2);
extern obj_t object__struct_env_210___object;


/* module-initialization */ obj_t 
module_initialization_70_object_class(long checksum_1287, char *from_1288)
{
   if (CBOOL(require_initialization_114_object_class))
     {
	require_initialization_114_object_class = BBOOL(((bool_t) 0));
	library_modules_init_112_object_class();
	cnst_init_137_object_class();
	imported_modules_init_94_object_class();
	object_init_111_object_class();
	method_init_76_object_class();
	toplevel_init_63_object_class();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_class()
{
   module_initialization_70___object(((long) 0), "OBJECT_CLASS");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_CLASS");
   module_initialization_70___r4_output_6_10_3(((long) 0), "OBJECT_CLASS");
   module_initialization_70___reader(((long) 0), "OBJECT_CLASS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_CLASS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_class()
{
   {
      obj_t cnst_port_138_1279;
      cnst_port_138_1279 = open_input_string(string1513_object_class);
      {
	 long i_1280;
	 i_1280 = ((long) 1);
       loop_1281:
	 {
	    bool_t test1514_1282;
	    test1514_1282 = (i_1280 == ((long) -1));
	    if (test1514_1282)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1515_1283;
		    {
		       obj_t list1516_1284;
		       {
			  obj_t arg1517_1285;
			  arg1517_1285 = BNIL;
			  list1516_1284 = MAKE_PAIR(cnst_port_138_1279, arg1517_1285);
		       }
		       arg1515_1283 = read___reader(list1516_1284);
		    }
		    CNST_TABLE_SET(i_1280, arg1515_1283);
		 }
		 {
		    int aux_1286;
		    {
		       long aux_1309;
		       aux_1309 = (i_1280 - ((long) 1));
		       aux_1286 = (int) (aux_1309);
		    }
		    {
		       long i_1312;
		       i_1312 = (long) (aux_1286);
		       i_1280 = i_1312;
		       goto loop_1281;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_class()
{
   return (_class_type_list__185_object_class = BNIL,
      BUNSPEC);
}


/* heap-add-class! */ obj_t 
heap_add_class__147_object_class(class_t type_63)
{
   {
      obj_t obj2_877;
      obj2_877 = _class_type_list__185_object_class;
      {
	 obj_t aux_1314;
	 aux_1314 = (obj_t) (type_63);
	 return (_class_type_list__185_object_class = MAKE_PAIR(aux_1314, obj2_877),
	    BUNSPEC);
      }
   }
}


/* _heap-add-class!1488 */ obj_t 
_heap_add_class_1488_165_object_class(obj_t env_1136, obj_t type_1137)
{
   return heap_add_class__147_object_class((class_t) (type_1137));
}


/* declare-class-type! */ type_t 
declare_class_type__110_object_class(obj_t class_def_12_64, global_t class_holder_88_65, obj_t widening_66, bool_t final__12_67, obj_t src_68)
{
   {
      obj_t class_ident_60_481;
      class_ident_60_481 = parse_id_241_ast_ident(CAR(class_def_12_64));
      {
	 obj_t class_id_86_482;
	 class_id_86_482 = CAR(class_ident_60_481);
	 {
	    obj_t super_483;
	    {
	       obj_t super_502;
	       super_502 = CDR(class_ident_60_481);
	       {
		  bool_t test_1323;
		  {
		     obj_t aux_1324;
		     {
			type_t obj_881;
			obj_881 = (type_t) (super_502);
			aux_1324 = (((type_t) CREF(obj_881))->id);
		     }
		     test_1323 = (aux_1324 == class_id_86_482);
		  }
		  if (test_1323)
		    {
		       super_483 = BFALSE;
		    }
		  else
		    {
		       bool_t test1270_504;
		       {
			  obj_t obj2_885;
			  obj2_885 = ____74_type_cache;
			  test1270_504 = (super_502 == obj2_885);
		       }
		       if (test1270_504)
			 {
			    super_483 = get_object_type_154_type_cache();
			 }
		       else
			 {
			    super_483 = super_502;
			 }
		    }
	       }
	    }
	    {
	       obj_t name_484;
	       if (CBOOL(_case_sensitive__90_engine_param))
		 {
		    name_484 = id__name_228_ast_ident(class_id_86_482);
		 }
	       else
		 {
		    obj_t arg1268_501;
		    arg1268_501 = id__name_228_ast_ident(class_id_86_482);
		    name_484 = string_downcase_77___r4_strings_6_7(arg1268_501);
		 }
	       {
		  obj_t sizeof_485;
		  sizeof_485 = string_append(string1495_object_class, name_484);
		  {
		     obj_t t_name_82_486;
		     t_name_82_486 = string_append(name_484, string1496_object_class);
		     {
			type_t type_487;
			type_487 = declare_type__118_type_env(class_id_86_482, t_name_82_486, CNST_TABLE_REF(((long) 0)));
			{
			   {
			      class_t obj1223_488;
			      obj1223_488 = ((class_t) (type_487));
			      {
				 class_t arg1254_489;
				 {
				    long arg1258_493;
				    obj_t arg1260_495;
				    {
				       bool_t test1261_496;
				       test1261_496 = is_a__118___object(super_483, class_object_class);
				       if (test1261_496)
					 {
					    long aux_1343;
					    {
					       class_t obj_887;
					       obj_887 = (class_t) (super_483);
					       {
						  obj_t aux_1345;
						  {
						     object_t aux_1346;
						     aux_1346 = (object_t) (obj_887);
						     aux_1345 = OBJECT_WIDENING(aux_1346);
						  }
						  aux_1343 = (((class_t) CREF(aux_1345))->depth);
					       }
					    }
					    arg1258_493 = (aux_1343 + ((long) 1));
					 }
				       else
					 {
					    arg1258_493 = ((long) 0);
					 }
				    }
				    {
				       obj_t aux_1351;
				       aux_1351 = CDR(class_def_12_64);
				       arg1260_495 = CAR(aux_1351);
				    }
				    {
				       class_t res1484_909;
				       {
					  class_t new1191_901;
					  new1191_901 = ((class_t) BREF(GC_MALLOC(sizeof(struct class))));
					  ((((class_t) CREF(new1191_901))->its_super_214) = ((obj_t) super_483), BUNSPEC);
					  ((((class_t) CREF(new1191_901))->slots) = ((obj_t) BUNSPEC), BUNSPEC);
					  ((((class_t) CREF(new1191_901))->holder) = ((global_t) class_holder_88_65), BUNSPEC);
					  ((((class_t) CREF(new1191_901))->widening) = ((obj_t) widening_66), BUNSPEC);
					  ((((class_t) CREF(new1191_901))->depth) = ((long) arg1258_493), BUNSPEC);
					  ((((class_t) CREF(new1191_901))->final__12) = ((bool_t) final__12_67), BUNSPEC);
					  ((((class_t) CREF(new1191_901))->constructor) = ((obj_t) arg1260_495), BUNSPEC);
					  res1484_909 = new1191_901;
				       }
				       arg1254_489 = res1484_909;
				    }
				 }
				 {
				    obj_t aux_1364;
				    object_t aux_1362;
				    aux_1364 = (obj_t) (arg1254_489);
				    aux_1362 = (object_t) (obj1223_488);
				    OBJECT_WIDENING_SET(aux_1362, aux_1364);
				 }
			      }
			      {
				 long arg1265_499;
				 arg1265_499 = class_num_218___object(class_object_class);
				 {
				    obj_t obj_910;
				    obj_910 = (obj_t) (obj1223_488);
				    (((obj_t) CREF(obj_910))->header = MAKE_HEADER(arg1265_499, 0), BUNSPEC);
				 }
			      }
			      obj1223_488;
			   }
			   ((((type_t) CREF(type_487))->size) = ((obj_t) sizeof_485), BUNSPEC);
			   {
			      obj_t obj2_915;
			      obj2_915 = _class_type_list__185_object_class;
			      {
				 obj_t aux_1371;
				 aux_1371 = (obj_t) (type_487);
				 _class_type_list__185_object_class = MAKE_PAIR(aux_1371, obj2_915);
			      }
			   }
			   return type_487;
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _declare-class-type! */ obj_t 
_declare_class_type__21_object_class(obj_t env_1138, obj_t class_def_12_1139, obj_t class_holder_88_1140, obj_t widening_1141, obj_t final__12_1142, obj_t src_1143)
{
   {
      type_t aux_1374;
      aux_1374 = declare_class_type__110_object_class(class_def_12_1139, (global_t) (class_holder_88_1140), widening_1141, CBOOL(final__12_1142), src_1143);
      return (obj_t) (aux_1374);
   }
}


/* cross-name */ obj_t 
cross_name_74_object_class(obj_t type_69)
{
   {
      bool_t test1274_507;
      test1274_507 = is_a__118___object(type_69, class_object_class);
      if (test1274_507)
	{
	   obj_t aux_1381;
	   {
	      type_t obj_917;
	      obj_917 = (type_t) (type_69);
	      aux_1381 = (((type_t) CREF(obj_917))->size);
	   }
	   return string_append(aux_1381, string1497_object_class);
	}
      else
	{
	   type_t obj_918;
	   obj_918 = (type_t) (type_69);
	   return (((type_t) CREF(obj_918))->name);
	}
   }
}


/* emit-class-types */ obj_t 
emit_class_types_26_object_class(obj_t oport_70)
{
   {
      bool_t test1279_510;
      {
	 obj_t obj_919;
	 obj_919 = _class_type_list__185_object_class;
	 test1279_510 = PAIRP(obj_919);
      }
      if (test1279_510)
	{
	   obj_t list1280_511;
	   {
	      obj_t arg1281_512;
	      arg1281_512 = MAKE_PAIR(string1498_object_class, BNIL);
	      {
		 obj_t aux_1390;
		 aux_1390 = BCHAR(((unsigned char) '\n'));
		 list1280_511 = MAKE_PAIR(aux_1390, arg1281_512);
	      }
	   }
	   fprint___r4_output_6_10_3(oport_70, list1280_511);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t l1224_515;
      {
	 obj_t arg1284_517;
	 arg1284_517 = reverse__39___r4_pairs_and_lists_6_3(_class_type_list__185_object_class);
	 l1224_515 = arg1284_517;
       lname1225_516:
	 if (PAIRP(l1224_515))
	   {
	      {
		 obj_t class_519;
		 class_519 = CAR(l1224_515);
		 {
		    bool_t test1286_520;
		    {
		       obj_t arg1378_594;
		       arg1378_594 = get_object_type_154_type_cache();
		       test1286_520 = (class_519 == arg1378_594);
		    }
		    if (test1286_520)
		      {
			 BUNSPEC;
		      }
		    else
		      {
			 {
			    obj_t arg1288_522;
			    {
			       type_t obj_924;
			       obj_924 = (type_t) (class_519);
			       arg1288_522 = (((type_t) CREF(obj_924))->size);
			    }
			    {
			       obj_t list1291_524;
			       {
				  obj_t arg1292_525;
				  {
				     obj_t arg1294_526;
				     arg1294_526 = MAKE_PAIR(string1499_object_class, BNIL);
				     arg1292_525 = MAKE_PAIR(arg1288_522, arg1294_526);
				  }
				  list1291_524 = MAKE_PAIR(string1500_object_class, arg1292_525);
			       }
			       fprint___r4_output_6_10_3(oport_70, list1291_524);
			    }
			 }
			 {
			    bool_t test_1407;
			    {
			       class_t obj_925;
			       obj_925 = (class_t) (class_519);
			       {
				  obj_t aux_1409;
				  {
				     obj_t aux_1410;
				     {
					object_t aux_1411;
					aux_1411 = (object_t) (obj_925);
					aux_1410 = OBJECT_WIDENING(aux_1411);
				     }
				     aux_1409 = (((class_t) CREF(aux_1410))->widening);
				  }
				  test_1407 = CBOOL(aux_1409);
			       }
			    }
			    if (test_1407)
			      {
				 bool_t test_1416;
				 {
				    obj_t aux_1417;
				    {
				       class_t obj_926;
				       obj_926 = (class_t) (class_519);
				       {
					  obj_t aux_1419;
					  {
					     object_t aux_1420;
					     aux_1420 = (object_t) (obj_926);
					     aux_1419 = OBJECT_WIDENING(aux_1420);
					  }
					  aux_1417 = (((class_t) CREF(aux_1419))->slots);
				       }
				    }
				    test_1416 = NULLP(aux_1417);
				 }
				 if (test_1416)
				   {
				      obj_t list1298_530;
				      list1298_530 = MAKE_PAIR(string1501_object_class, BNIL);
				      fprint___r4_output_6_10_3(oport_70, list1298_530);
				   }
				 else
				   {
				      BUNSPEC;
				   }
			      }
			    else
			      {
				 {
				    obj_t list1302_534;
				    list1302_534 = MAKE_PAIR(string1502_object_class, BNIL);
				    fprint___r4_output_6_10_3(oport_70, list1302_534);
				 }
				 {
				    obj_t list1305_537;
				    list1305_537 = MAKE_PAIR(string1503_object_class, BNIL);
				    fprint___r4_output_6_10_3(oport_70, list1305_537);
				 }
			      }
			 }
			 {
			    obj_t l1226_540;
			    {
			       class_t obj_928;
			       obj_928 = (class_t) (class_519);
			       {
				  obj_t aux_1476;
				  {
				     object_t aux_1477;
				     aux_1477 = (object_t) (obj_928);
				     aux_1476 = OBJECT_WIDENING(aux_1477);
				  }
				  l1226_540 = (((class_t) CREF(aux_1476))->slots);
			       }
			    }
			  lname1227_541:
			    if (PAIRP(l1226_540))
			      {
				 {
				    obj_t slot_544;
				    slot_544 = CAR(l1226_540);
				    {
				       obj_t name_545;
				       name_545 = cross_name_74_object_class(STRUCT_REF(slot_544, ((long) 2)));
				       {
					  bool_t test_1436;
					  {
					     obj_t aux_1437;
					     aux_1437 = STRUCT_REF(slot_544, ((long) 11));
					     test_1436 = CBOOL(aux_1437);
					  }
					  if (test_1436)
					    {
					       BUNSPEC;
					    }
					  else
					    {
					       bool_t test_1440;
					       {
						  obj_t aux_1441;
						  aux_1441 = STRUCT_REF(slot_544, ((long) 5));
						  test_1440 = CBOOL(aux_1441);
					       }
					       if (test_1440)
						 {
						    {
						       obj_t arg1316_550;
						       arg1316_550 = STRUCT_REF(slot_544, ((long) 1));
						       {
							  obj_t list1320_552;
							  {
							     obj_t arg1321_553;
							     {
								obj_t arg1322_554;
								{
								   obj_t arg1323_555;
								   {
								      obj_t arg1324_556;
								      arg1324_556 = MAKE_PAIR(string1504_object_class, BNIL);
								      arg1323_555 = MAKE_PAIR(arg1316_550, arg1324_556);
								   }
								   arg1322_554 = MAKE_PAIR(string1497_object_class, arg1323_555);
								}
								arg1321_553 = MAKE_PAIR(name_545, arg1322_554);
							     }
							     list1320_552 = MAKE_PAIR(string1505_object_class, arg1321_553);
							  }
							  fprint___r4_output_6_10_3(oport_70, list1320_552);
						       }
						    }
						 }
					       else
						 {
						    bool_t test_1451;
						    {
						       obj_t aux_1452;
						       aux_1452 = STRUCT_REF(slot_544, ((long) 3));
						       test_1451 = CBOOL(aux_1452);
						    }
						    if (test_1451)
						      {
							 {
							    obj_t arg1331_561;
							    obj_t arg1333_563;
							    arg1331_561 = STRUCT_REF(slot_544, ((long) 1));
							    arg1333_563 = STRUCT_REF(slot_544, ((long) 4));
							    {
							       obj_t list1338_566;
							       {
								  obj_t arg1339_567;
								  {
								     obj_t arg1340_568;
								     {
									obj_t arg1342_569;
									{
									   obj_t arg1343_570;
									   {
									      obj_t arg1344_571;
									      {
										 obj_t arg1345_572;
										 {
										    obj_t arg1347_573;
										    arg1347_573 = MAKE_PAIR(string1504_object_class, BNIL);
										    arg1345_572 = MAKE_PAIR(string1506_object_class, arg1347_573);
										 }
										 arg1344_571 = MAKE_PAIR(arg1333_563, arg1345_572);
									      }
									      arg1343_570 = MAKE_PAIR(string1507_object_class, arg1344_571);
									   }
									   arg1342_569 = MAKE_PAIR(arg1331_561, arg1343_570);
									}
									arg1340_568 = MAKE_PAIR(string1508_object_class, arg1342_569);
								     }
								     arg1339_567 = MAKE_PAIR(name_545, arg1340_568);
								  }
								  list1338_566 = MAKE_PAIR(string1505_object_class, arg1339_567);
							       }
							       fprint___r4_output_6_10_3(oport_70, list1338_566);
							    }
							 }
						      }
						    else
						      {
							 {
							    obj_t arg1352_577;
							    arg1352_577 = STRUCT_REF(slot_544, ((long) 1));
							    {
							       obj_t list1354_579;
							       {
								  obj_t arg1355_580;
								  {
								     obj_t arg1356_581;
								     {
									obj_t arg1357_582;
									{
									   obj_t arg1361_583;
									   arg1361_583 = MAKE_PAIR(string1504_object_class, BNIL);
									   arg1357_582 = MAKE_PAIR(arg1352_577, arg1361_583);
									}
									arg1356_581 = MAKE_PAIR(string1508_object_class, arg1357_582);
								     }
								     arg1355_580 = MAKE_PAIR(name_545, arg1356_581);
								  }
								  list1354_579 = MAKE_PAIR(string1505_object_class, arg1355_580);
							       }
							       fprint___r4_output_6_10_3(oport_70, list1354_579);
							    }
							 }
						      }
						 }
					    }
				       }
				    }
				 }
				 {
				    obj_t l1226_1473;
				    l1226_1473 = CDR(l1226_540);
				    l1226_540 = l1226_1473;
				    goto lname1227_541;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t arg1368_588;
			    {
			       type_t obj_956;
			       obj_956 = (type_t) (class_519);
			       arg1368_588 = (((type_t) CREF(obj_956))->name);
			    }
			    {
			       obj_t list1370_590;
			       {
				  obj_t arg1372_591;
				  {
				     obj_t arg1373_592;
				     arg1373_592 = MAKE_PAIR(string1509_object_class, BNIL);
				     arg1372_591 = MAKE_PAIR(arg1368_588, arg1373_592);
				  }
				  list1370_590 = MAKE_PAIR(string1510_object_class, arg1372_591);
			       }
			       fprint___r4_output_6_10_3(oport_70, list1370_590);
			    }
			 }
		      }
		 }
	      }
	      {
		 obj_t l1224_1487;
		 l1224_1487 = CDR(l1224_515);
		 l1224_515 = l1224_1487;
		 goto lname1225_516;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   {
      bool_t test1380_596;
      {
	 obj_t obj_958;
	 obj_958 = _class_type_list__185_object_class;
	 test1380_596 = PAIRP(obj_958);
      }
      if (test1380_596)
	{
	   obj_t list1381_597;
	   list1381_597 = MAKE_PAIR(oport_70, BNIL);
	   return newline___r4_output_6_10_3(list1381_597);
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _emit-class-types */ obj_t 
_emit_class_types_128_object_class(obj_t env_1144, obj_t oport_1145)
{
   return emit_class_types_26_object_class(oport_1145);
}


/* final-class? */ bool_t 
final_class__126_object_class(obj_t class_71)
{
   {
      bool_t _andtest_1228_959;
      _andtest_1228_959 = is_a__118___object(class_71, class_object_class);
      if (_andtest_1228_959)
	{
	   class_t obj_961;
	   obj_961 = (class_t) (class_71);
	   {
	      obj_t aux_1497;
	      {
		 object_t aux_1498;
		 aux_1498 = (object_t) (obj_961);
		 aux_1497 = OBJECT_WIDENING(aux_1498);
	      }
	      return (((class_t) CREF(aux_1497))->final__12);
	   }
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* _final-class? */ obj_t 
_final_class__214_object_class(obj_t env_1146, obj_t class_1147)
{
   {
      bool_t aux_1502;
      aux_1502 = final_class__126_object_class(class_1147);
      return BBOOL(aux_1502);
   }
}


/* wide-class? */ bool_t 
wide_class__100_object_class(obj_t class_72)
{
   {
      bool_t _andtest_1229_962;
      _andtest_1229_962 = is_a__118___object(class_72, class_object_class);
      if (_andtest_1229_962)
	{
	   class_t obj_964;
	   obj_964 = (class_t) (class_72);
	   {
	      obj_t aux_1508;
	      {
		 obj_t aux_1509;
		 {
		    object_t aux_1510;
		    aux_1510 = (object_t) (obj_964);
		    aux_1509 = OBJECT_WIDENING(aux_1510);
		 }
		 aux_1508 = (((class_t) CREF(aux_1509))->widening);
	      }
	      return CBOOL(aux_1508);
	   }
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* _wide-class? */ obj_t 
_wide_class__223_object_class(obj_t env_1148, obj_t class_1149)
{
   {
      bool_t aux_1515;
      aux_1515 = wide_class__100_object_class(class_1149);
      return BBOOL(aux_1515);
   }
}


/* type-subclass? */ bool_t 
type_subclass__90_object_class(type_t subclass_73, type_t class_74)
{
   {
      bool_t test1384_601;
      test1384_601 = is_a__118___object((obj_t) (class_74), class_object_class);
      if (test1384_601)
	{
	   bool_t test1385_602;
	   test1385_602 = is_a__118___object((obj_t) (subclass_73), class_object_class);
	   if (test1385_602)
	     {
		{
		   obj_t subclass_603;
		   subclass_603 = (obj_t) (subclass_73);
		 loop_604:
		   {
		      bool_t test_1524;
		      {
			 obj_t aux_1525;
			 aux_1525 = (obj_t) (class_74);
			 test_1524 = (subclass_603 == aux_1525);
		      }
		      if (test_1524)
			{
			   return ((bool_t) 1);
			}
		      else
			{
			   bool_t test1387_606;
			   test1387_606 = is_a__118___object(subclass_603, class_object_class);
			   if (test1387_606)
			     {
				bool_t test_1530;
				{
				   obj_t aux_1531;
				   {
				      class_t obj_970;
				      obj_970 = (class_t) (subclass_603);
				      {
					 obj_t aux_1533;
					 {
					    object_t aux_1534;
					    aux_1534 = (object_t) (obj_970);
					    aux_1533 = OBJECT_WIDENING(aux_1534);
					 }
					 aux_1531 = (((class_t) CREF(aux_1533))->its_super_214);
				      }
				   }
				   test_1530 = (aux_1531 == subclass_603);
				}
				if (test_1530)
				  {
				     return ((bool_t) 0);
				  }
				else
				  {
				     {
					obj_t subclass_1539;
					{
					   class_t obj_973;
					   obj_973 = (class_t) (subclass_603);
					   {
					      obj_t aux_1541;
					      {
						 object_t aux_1542;
						 aux_1542 = (object_t) (obj_973);
						 aux_1541 = OBJECT_WIDENING(aux_1542);
					      }
					      subclass_1539 = (((class_t) CREF(aux_1541))->its_super_214);
					   }
					}
					subclass_603 = subclass_1539;
					goto loop_604;
				     }
				  }
			     }
			   else
			     {
				return ((bool_t) 0);
			     }
			}
		   }
		}
	     }
	   else
	     {
		return ((bool_t) 0);
	     }
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* _type-subclass? */ obj_t 
_type_subclass__143_object_class(obj_t env_1150, obj_t subclass_1151, obj_t class_1152)
{
   {
      bool_t aux_1547;
      aux_1547 = type_subclass__90_object_class((type_t) (subclass_1151), (type_t) (class_1152));
      return BBOOL(aux_1547);
   }
}


/* find-class-constructors */ obj_t 
find_class_constructors_231_object_class(class_t class_75)
{
   {
      obj_t class_610;
      class_610 = (obj_t) (class_75);
    loop_611:
      {
	 bool_t test1391_613;
	 {
	    bool_t test1397_619;
	    test1397_619 = is_a__118___object(class_610, class_object_class);
	    if (test1397_619)
	      {
		 obj_t aux_1554;
		 {
		    class_t obj_975;
		    obj_975 = (class_t) (class_610);
		    {
		       obj_t aux_1556;
		       {
			  object_t aux_1557;
			  aux_1557 = (object_t) (obj_975);
			  aux_1556 = OBJECT_WIDENING(aux_1557);
		       }
		       aux_1554 = (((class_t) CREF(aux_1556))->its_super_214);
		    }
		 }
		 test1391_613 = (class_610 == aux_1554);
	      }
	    else
	      {
		 test1391_613 = ((bool_t) 1);
	      }
	 }
	 if (test1391_613)
	   {
	      return BNIL;
	   }
	 else
	   {
	      bool_t test_1563;
	      {
		 class_t obj_978;
		 obj_978 = (class_t) (class_610);
		 {
		    obj_t aux_1565;
		    {
		       obj_t aux_1566;
		       {
			  object_t aux_1567;
			  aux_1567 = (object_t) (obj_978);
			  aux_1566 = OBJECT_WIDENING(aux_1567);
		       }
		       aux_1565 = (((class_t) CREF(aux_1566))->constructor);
		    }
		    test_1563 = CBOOL(aux_1565);
		 }
	      }
	      if (test_1563)
		{
		   {
		      obj_t list1394_616;
		      {
			 obj_t aux_1572;
			 {
			    class_t obj_979;
			    obj_979 = (class_t) (class_610);
			    {
			       obj_t aux_1574;
			       {
				  object_t aux_1575;
				  aux_1575 = (object_t) (obj_979);
				  aux_1574 = OBJECT_WIDENING(aux_1575);
			       }
			       aux_1572 = (((class_t) CREF(aux_1574))->constructor);
			    }
			 }
			 list1394_616 = MAKE_PAIR(aux_1572, BNIL);
		      }
		      return list1394_616;
		   }
		}
	      else
		{
		   {
		      obj_t class_1580;
		      {
			 class_t obj_981;
			 obj_981 = (class_t) (class_610);
			 {
			    obj_t aux_1582;
			    {
			       object_t aux_1583;
			       aux_1583 = (object_t) (obj_981);
			       aux_1582 = OBJECT_WIDENING(aux_1583);
			    }
			    class_1580 = (((class_t) CREF(aux_1582))->its_super_214);
			 }
		      }
		      class_610 = class_1580;
		      goto loop_611;
		   }
		}
	   }
      }
   }
}


/* _find-class-constructors1489 */ obj_t 
_find_class_constructors1489_106_object_class(obj_t env_1153, obj_t class_1154)
{
   return find_class_constructors_231_object_class((class_t) (class_1154));
}


/* object-init */ obj_t 
object_init_111_object_class()
{
   {
      obj_t arg1401_622;
      arg1401_622 = type_type_type;
      class_object_class = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1401_622, allocate_class_env_121_object_class, ((long) 57959), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-class */ type_t 
allocate_class_37_object_class()
{
   {
      type_t new1216_625;
      new1216_625 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1405_626;
	 arg1405_626 = class_num_218___object(class_object_class);
	 {
	    obj_t obj_982;
	    obj_982 = (obj_t) (new1216_625);
	    (((obj_t) CREF(obj_982))->header = MAKE_HEADER(arg1405_626, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_1596;
	 aux_1596 = (object_t) (new1216_625);
	 OBJECT_WIDENING_SET(aux_1596, BFALSE);
      }
      return new1216_625;
   }
}


/* _allocate-class */ obj_t 
_allocate_class_74_object_class(obj_t env_1155)
{
   {
      type_t aux_1599;
      aux_1599 = allocate_class_37_object_class();
      return (obj_t) (aux_1599);
   }
}


/* class? */ bool_t 
class__60_object_class(obj_t obj_79)
{
   return is_a__118___object(obj_79, class_object_class);
}


/* _class? */ obj_t 
_class__187_object_class(obj_t env_1156, obj_t obj_1157)
{
   {
      bool_t aux_1603;
      aux_1603 = class__60_object_class(obj_1157);
      return BBOOL(aux_1603);
   }
}


/* widening1002-class */ class_t 
widening1002_class_162_object_class(obj_t its_super_214_80, obj_t slots_81, global_t holder_82, obj_t widening_83, long depth_84, bool_t final__12_85, obj_t constructor_86)
{
   {
      class_t new1191_984;
      new1191_984 = ((class_t) BREF(GC_MALLOC(sizeof(struct class))));
      ((((class_t) CREF(new1191_984))->its_super_214) = ((obj_t) its_super_214_80), BUNSPEC);
      ((((class_t) CREF(new1191_984))->slots) = ((obj_t) slots_81), BUNSPEC);
      ((((class_t) CREF(new1191_984))->holder) = ((global_t) holder_82), BUNSPEC);
      ((((class_t) CREF(new1191_984))->widening) = ((obj_t) widening_83), BUNSPEC);
      ((((class_t) CREF(new1191_984))->depth) = ((long) depth_84), BUNSPEC);
      ((((class_t) CREF(new1191_984))->final__12) = ((bool_t) final__12_85), BUNSPEC);
      ((((class_t) CREF(new1191_984))->constructor) = ((obj_t) constructor_86), BUNSPEC);
      return new1191_984;
   }
}


/* _widening1002-class */ obj_t 
_widening1002_class_137_object_class(obj_t env_1158, obj_t its_super_214_1159, obj_t slots_1160, obj_t holder_1161, obj_t widening_1162, obj_t depth_1163, obj_t final__12_1164, obj_t constructor_1165)
{
   {
      class_t aux_1614;
      aux_1614 = widening1002_class_162_object_class(its_super_214_1159, slots_1160, (global_t) (holder_1161), widening_1162, (long) CINT(depth_1163), CBOOL(final__12_1164), constructor_1165);
      return (obj_t) (aux_1614);
   }
}


/* make-class */ class_t 
make_class_185_object_class(obj_t id_87, obj_t name_88, obj_t size_89, obj_t class_90, obj_t coerce_to_204_91, obj_t parents_92, bool_t init__47_93, bool_t magic__53_94, obj_t __57_95, obj_t alias_96, obj_t pointed_to_by_76_97, obj_t tvector_98, obj_t its_super_214_99, obj_t slots_100, global_t holder_101, obj_t widening_102, long depth_103, bool_t final__12_104, obj_t constructor_105)
{
   {
      type_t aux1200_992;
      {
	 type_t res1485_1024;
	 {
	    type_t new1003_1008;
	    new1003_1008 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1448_1009;
	       arg1448_1009 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_1022;
		  obj_1022 = (obj_t) (new1003_1008);
		  (((obj_t) CREF(obj_1022))->header = MAKE_HEADER(arg1448_1009, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_1624;
	       aux_1624 = (object_t) (new1003_1008);
	       OBJECT_WIDENING_SET(aux_1624, BFALSE);
	    }
	    ((((type_t) CREF(new1003_1008))->id) = ((obj_t) id_87), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->name) = ((obj_t) name_88), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->size) = ((obj_t) size_89), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->class) = ((obj_t) class_90), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->coerce_to_204) = ((obj_t) coerce_to_204_91), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->parents) = ((obj_t) parents_92), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->init__47) = ((bool_t) init__47_93), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->magic__53) = ((bool_t) magic__53_94), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->__57) = ((obj_t) __57_95), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->alias) = ((obj_t) alias_96), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_97), BUNSPEC);
	    ((((type_t) CREF(new1003_1008))->tvector) = ((obj_t) tvector_98), BUNSPEC);
	    res1485_1024 = new1003_1008;
	 }
	 aux1200_992 = res1485_1024;
      }
      {
	 class_t new1201_993;
	 new1201_993 = ((class_t) (aux1200_992));
	 {
	    long arg1407_994;
	    arg1407_994 = class_num_218___object(class_object_class);
	    {
	       obj_t obj_1025;
	       obj_1025 = (obj_t) (new1201_993);
	       (((obj_t) CREF(obj_1025))->header = MAKE_HEADER(arg1407_994, 0), BUNSPEC);
	    }
	 }
	 {
	    class_t arg1408_995;
	    {
	       class_t res1486_1042;
	       {
		  class_t new1191_1034;
		  new1191_1034 = ((class_t) BREF(GC_MALLOC(sizeof(struct class))));
		  ((((class_t) CREF(new1191_1034))->its_super_214) = ((obj_t) its_super_214_99), BUNSPEC);
		  ((((class_t) CREF(new1191_1034))->slots) = ((obj_t) slots_100), BUNSPEC);
		  ((((class_t) CREF(new1191_1034))->holder) = ((global_t) holder_101), BUNSPEC);
		  ((((class_t) CREF(new1191_1034))->widening) = ((obj_t) widening_102), BUNSPEC);
		  ((((class_t) CREF(new1191_1034))->depth) = ((long) depth_103), BUNSPEC);
		  ((((class_t) CREF(new1191_1034))->final__12) = ((bool_t) final__12_104), BUNSPEC);
		  ((((class_t) CREF(new1191_1034))->constructor) = ((obj_t) constructor_105), BUNSPEC);
		  res1486_1042 = new1191_1034;
	       }
	       arg1408_995 = res1486_1042;
	    }
	    {
	       obj_t aux_1653;
	       object_t aux_1651;
	       aux_1653 = (obj_t) (arg1408_995);
	       aux_1651 = (object_t) (new1201_993);
	       OBJECT_WIDENING_SET(aux_1651, aux_1653);
	    }
	 }
	 return new1201_993;
      }
   }
}


/* _make-class */ obj_t 
_make_class_28_object_class(obj_t env_1166, obj_t id_1167, obj_t name_1168, obj_t size_1169, obj_t class_1170, obj_t coerce_to_204_1171, obj_t parents_1172, obj_t init__47_1173, obj_t magic__53_1174, obj_t __57_1175, obj_t alias_1176, obj_t pointed_to_by_76_1177, obj_t tvector_1178, obj_t its_super_214_1179, obj_t slots_1180, obj_t holder_1181, obj_t widening_1182, obj_t depth_1183, obj_t final__12_1184, obj_t constructor_1185)
{
   {
      class_t aux_1656;
      aux_1656 = make_class_185_object_class(id_1167, name_1168, size_1169, class_1170, coerce_to_204_1171, parents_1172, CBOOL(init__47_1173), CBOOL(magic__53_1174), __57_1175, alias_1176, pointed_to_by_76_1177, tvector_1178, its_super_214_1179, slots_1180, (global_t) (holder_1181), widening_1182, (long) CINT(depth_1183), CBOOL(final__12_1184), constructor_1185);
      return (obj_t) (aux_1656);
   }
}


/* class-id */ obj_t 
class_id_86_object_class(type_t obj_106)
{
   return (((type_t) CREF(obj_106))->id);
}


/* _class-id */ obj_t 
_class_id_54_object_class(obj_t env_1186, obj_t obj_1187)
{
   return class_id_86_object_class((type_t) (obj_1187));
}


/* class-name-set! */ obj_t 
class_name_set__214_object_class(type_t obj_107, obj_t val1202_108)
{
   return ((((type_t) CREF(obj_107))->name) = ((obj_t) val1202_108), BUNSPEC);
}


/* _class-name-set! */ obj_t 
_class_name_set__29_object_class(obj_t env_1188, obj_t obj_1189, obj_t val1202_1190)
{
   return class_name_set__214_object_class((type_t) (obj_1189), val1202_1190);
}


/* class-name */ obj_t 
class_name_139_object_class(type_t obj_109)
{
   return (((type_t) CREF(obj_109))->name);
}


/* _class-name */ obj_t 
_class_name_50_object_class(obj_t env_1191, obj_t obj_1192)
{
   return class_name_139_object_class((type_t) (obj_1192));
}


/* class-size-set! */ obj_t 
class_size_set__10_object_class(type_t obj_110, obj_t val1203_111)
{
   return ((((type_t) CREF(obj_110))->size) = ((obj_t) val1203_111), BUNSPEC);
}


/* _class-size-set! */ obj_t 
_class_size_set__221_object_class(obj_t env_1193, obj_t obj_1194, obj_t val1203_1195)
{
   return class_size_set__10_object_class((type_t) (obj_1194), val1203_1195);
}


/* class-size */ obj_t 
class_size_35_object_class(type_t obj_112)
{
   return (((type_t) CREF(obj_112))->size);
}


/* _class-size */ obj_t 
_class_size_220_object_class(obj_t env_1196, obj_t obj_1197)
{
   return class_size_35_object_class((type_t) (obj_1197));
}


/* class-class-set! */ obj_t 
class_class_set__34_object_class(type_t obj_113, obj_t val1204_114)
{
   return ((((type_t) CREF(obj_113))->class) = ((obj_t) val1204_114), BUNSPEC);
}


/* _class-class-set! */ obj_t 
_class_class_set__27_object_class(obj_t env_1198, obj_t obj_1199, obj_t val1204_1200)
{
   return class_class_set__34_object_class((type_t) (obj_1199), val1204_1200);
}


/* class-class */ obj_t 
class_class_86_object_class(type_t obj_115)
{
   return (((type_t) CREF(obj_115))->class);
}


/* _class-class */ obj_t 
_class_class_56_object_class(obj_t env_1201, obj_t obj_1202)
{
   return class_class_86_object_class((type_t) (obj_1202));
}


/* class-coerce-to-set! */ obj_t 
class_coerce_to_set__33_object_class(type_t obj_116, obj_t val1205_117)
{
   return ((((type_t) CREF(obj_116))->coerce_to_204) = ((obj_t) val1205_117), BUNSPEC);
}


/* _class-coerce-to-set! */ obj_t 
_class_coerce_to_set__132_object_class(obj_t env_1203, obj_t obj_1204, obj_t val1205_1205)
{
   return class_coerce_to_set__33_object_class((type_t) (obj_1204), val1205_1205);
}


/* class-coerce-to */ obj_t 
class_coerce_to_190_object_class(type_t obj_118)
{
   return (((type_t) CREF(obj_118))->coerce_to_204);
}


/* _class-coerce-to */ obj_t 
_class_coerce_to_174_object_class(obj_t env_1206, obj_t obj_1207)
{
   return class_coerce_to_190_object_class((type_t) (obj_1207));
}


/* class-parents-set! */ obj_t 
class_parents_set__241_object_class(type_t obj_119, obj_t val1206_120)
{
   return ((((type_t) CREF(obj_119))->parents) = ((obj_t) val1206_120), BUNSPEC);
}


/* _class-parents-set! */ obj_t 
_class_parents_set__46_object_class(obj_t env_1208, obj_t obj_1209, obj_t val1206_1210)
{
   return class_parents_set__241_object_class((type_t) (obj_1209), val1206_1210);
}


/* class-parents */ obj_t 
class_parents_195_object_class(type_t obj_121)
{
   return (((type_t) CREF(obj_121))->parents);
}


/* _class-parents */ obj_t 
_class_parents_102_object_class(obj_t env_1211, obj_t obj_1212)
{
   return class_parents_195_object_class((type_t) (obj_1212));
}


/* class-init?-set! */ obj_t 
class_init__set__101_object_class(type_t obj_122, bool_t val1207_123)
{
   return ((((type_t) CREF(obj_122))->init__47) = ((bool_t) val1207_123), BUNSPEC);
}


/* _class-init?-set! */ obj_t 
_class_init__set__12_object_class(obj_t env_1213, obj_t obj_1214, obj_t val1207_1215)
{
   return class_init__set__101_object_class((type_t) (obj_1214), CBOOL(val1207_1215));
}


/* class-init? */ bool_t 
class_init__242_object_class(type_t obj_124)
{
   return (((type_t) CREF(obj_124))->init__47);
}


/* _class-init? */ obj_t 
_class_init__204_object_class(obj_t env_1216, obj_t obj_1217)
{
   {
      bool_t aux_1702;
      aux_1702 = class_init__242_object_class((type_t) (obj_1217));
      return BBOOL(aux_1702);
   }
}


/* class-magic?-set! */ obj_t 
class_magic__set__200_object_class(type_t obj_125, bool_t val1208_126)
{
   return ((((type_t) CREF(obj_125))->magic__53) = ((bool_t) val1208_126), BUNSPEC);
}


/* _class-magic?-set! */ obj_t 
_class_magic__set__166_object_class(obj_t env_1218, obj_t obj_1219, obj_t val1208_1220)
{
   return class_magic__set__200_object_class((type_t) (obj_1219), CBOOL(val1208_1220));
}


/* class-magic? */ bool_t 
class_magic__8_object_class(type_t obj_127)
{
   return (((type_t) CREF(obj_127))->magic__53);
}


/* _class-magic? */ obj_t 
_class_magic__112_object_class(obj_t env_1221, obj_t obj_1222)
{
   {
      bool_t aux_1711;
      aux_1711 = class_magic__8_object_class((type_t) (obj_1222));
      return BBOOL(aux_1711);
   }
}


/* class-$-set! */ obj_t 
class___set__80_object_class(type_t obj_128, obj_t val1209_129)
{
   return ((((type_t) CREF(obj_128))->__57) = ((obj_t) val1209_129), BUNSPEC);
}


/* _class-$-set! */ obj_t 
_class___set__85_object_class(obj_t env_1223, obj_t obj_1224, obj_t val1209_1225)
{
   return class___set__80_object_class((type_t) (obj_1224), val1209_1225);
}


/* class-$ */ obj_t 
class___24_object_class(type_t obj_130)
{
   return (((type_t) CREF(obj_130))->__57);
}


/* _class-$ */ obj_t 
_class___26_object_class(obj_t env_1226, obj_t obj_1227)
{
   return class___24_object_class((type_t) (obj_1227));
}


/* class-alias-set! */ obj_t 
class_alias_set__87_object_class(type_t obj_131, obj_t val1210_132)
{
   return ((((type_t) CREF(obj_131))->alias) = ((obj_t) val1210_132), BUNSPEC);
}


/* _class-alias-set! */ obj_t 
_class_alias_set__148_object_class(obj_t env_1228, obj_t obj_1229, obj_t val1210_1230)
{
   return class_alias_set__87_object_class((type_t) (obj_1229), val1210_1230);
}


/* class-alias */ obj_t 
class_alias_73_object_class(type_t obj_133)
{
   return (((type_t) CREF(obj_133))->alias);
}


/* _class-alias */ obj_t 
_class_alias_149_object_class(obj_t env_1231, obj_t obj_1232)
{
   return class_alias_73_object_class((type_t) (obj_1232));
}


/* class-pointed-to-by-set! */ obj_t 
class_pointed_to_by_set__1_object_class(type_t obj_134, obj_t val1211_135)
{
   return ((((type_t) CREF(obj_134))->pointed_to_by_76) = ((obj_t) val1211_135), BUNSPEC);
}


/* _class-pointed-to-by-set! */ obj_t 
_class_pointed_to_by_set__172_object_class(obj_t env_1233, obj_t obj_1234, obj_t val1211_1235)
{
   return class_pointed_to_by_set__1_object_class((type_t) (obj_1234), val1211_1235);
}


/* class-pointed-to-by */ obj_t 
class_pointed_to_by_250_object_class(type_t obj_136)
{
   return (((type_t) CREF(obj_136))->pointed_to_by_76);
}


/* _class-pointed-to-by */ obj_t 
_class_pointed_to_by_138_object_class(obj_t env_1236, obj_t obj_1237)
{
   return class_pointed_to_by_250_object_class((type_t) (obj_1237));
}


/* class-tvector-set! */ obj_t 
class_tvector_set__125_object_class(type_t obj_137, obj_t val1212_138)
{
   return ((((type_t) CREF(obj_137))->tvector) = ((obj_t) val1212_138), BUNSPEC);
}


/* _class-tvector-set! */ obj_t 
_class_tvector_set__189_object_class(obj_t env_1238, obj_t obj_1239, obj_t val1212_1240)
{
   return class_tvector_set__125_object_class((type_t) (obj_1239), val1212_1240);
}


/* class-tvector */ obj_t 
class_tvector_28_object_class(type_t obj_139)
{
   return (((type_t) CREF(obj_139))->tvector);
}


/* _class-tvector */ obj_t 
_class_tvector_206_object_class(obj_t env_1241, obj_t obj_1242)
{
   return class_tvector_28_object_class((type_t) (obj_1242));
}


/* class-its-super-set! */ obj_t 
class_its_super_set__79_object_class(class_t obj_140, obj_t val1213_141)
{
   {
      obj_t aux_1739;
      {
	 object_t aux_1740;
	 aux_1740 = (object_t) (obj_140);
	 aux_1739 = OBJECT_WIDENING(aux_1740);
      }
      return ((((class_t) CREF(aux_1739))->its_super_214) = ((obj_t) val1213_141), BUNSPEC);
   }
}


/* _class-its-super-set! */ obj_t 
_class_its_super_set__186_object_class(obj_t env_1243, obj_t obj_1244, obj_t val1213_1245)
{
   return class_its_super_set__79_object_class((class_t) (obj_1244), val1213_1245);
}


/* class-its-super */ obj_t 
class_its_super_90_object_class(class_t obj_142)
{
   {
      obj_t aux_1746;
      {
	 object_t aux_1747;
	 aux_1747 = (object_t) (obj_142);
	 aux_1746 = OBJECT_WIDENING(aux_1747);
      }
      return (((class_t) CREF(aux_1746))->its_super_214);
   }
}


/* _class-its-super */ obj_t 
_class_its_super_160_object_class(obj_t env_1246, obj_t obj_1247)
{
   return class_its_super_90_object_class((class_t) (obj_1247));
}


/* class-slots-set! */ obj_t 
class_slots_set__26_object_class(class_t obj_143, obj_t val1214_144)
{
   {
      obj_t aux_1753;
      {
	 object_t aux_1754;
	 aux_1754 = (object_t) (obj_143);
	 aux_1753 = OBJECT_WIDENING(aux_1754);
      }
      return ((((class_t) CREF(aux_1753))->slots) = ((obj_t) val1214_144), BUNSPEC);
   }
}


/* _class-slots-set! */ obj_t 
_class_slots_set__80_object_class(obj_t env_1248, obj_t obj_1249, obj_t val1214_1250)
{
   return class_slots_set__26_object_class((class_t) (obj_1249), val1214_1250);
}


/* class-slots */ obj_t 
class_slots_173_object_class(class_t obj_145)
{
   {
      obj_t aux_1760;
      {
	 object_t aux_1761;
	 aux_1761 = (object_t) (obj_145);
	 aux_1760 = OBJECT_WIDENING(aux_1761);
      }
      return (((class_t) CREF(aux_1760))->slots);
   }
}


/* _class-slots */ obj_t 
_class_slots_24_object_class(obj_t env_1251, obj_t obj_1252)
{
   return class_slots_173_object_class((class_t) (obj_1252));
}


/* class-holder */ global_t 
class_holder_88_object_class(class_t obj_146)
{
   {
      obj_t aux_1767;
      {
	 object_t aux_1768;
	 aux_1768 = (object_t) (obj_146);
	 aux_1767 = OBJECT_WIDENING(aux_1768);
      }
      return (((class_t) CREF(aux_1767))->holder);
   }
}


/* _class-holder */ obj_t 
_class_holder_46_object_class(obj_t env_1253, obj_t obj_1254)
{
   {
      global_t aux_1772;
      aux_1772 = class_holder_88_object_class((class_t) (obj_1254));
      return (obj_t) (aux_1772);
   }
}


/* class-widening */ obj_t 
class_widening_213_object_class(class_t obj_147)
{
   {
      obj_t aux_1776;
      {
	 object_t aux_1777;
	 aux_1777 = (object_t) (obj_147);
	 aux_1776 = OBJECT_WIDENING(aux_1777);
      }
      return (((class_t) CREF(aux_1776))->widening);
   }
}


/* _class-widening */ obj_t 
_class_widening_123_object_class(obj_t env_1255, obj_t obj_1256)
{
   return class_widening_213_object_class((class_t) (obj_1256));
}


/* class-depth-set! */ obj_t 
class_depth_set__230_object_class(class_t obj_148, long val1215_149)
{
   {
      obj_t aux_1783;
      {
	 object_t aux_1784;
	 aux_1784 = (object_t) (obj_148);
	 aux_1783 = OBJECT_WIDENING(aux_1784);
      }
      return ((((class_t) CREF(aux_1783))->depth) = ((long) val1215_149), BUNSPEC);
   }
}


/* _class-depth-set! */ obj_t 
_class_depth_set__234_object_class(obj_t env_1257, obj_t obj_1258, obj_t val1215_1259)
{
   return class_depth_set__230_object_class((class_t) (obj_1258), (long) CINT(val1215_1259));
}


/* class-depth */ long 
class_depth_60_object_class(class_t obj_150)
{
   {
      obj_t aux_1791;
      {
	 object_t aux_1792;
	 aux_1792 = (object_t) (obj_150);
	 aux_1791 = OBJECT_WIDENING(aux_1792);
      }
      return (((class_t) CREF(aux_1791))->depth);
   }
}


/* _class-depth */ obj_t 
_class_depth_246_object_class(obj_t env_1260, obj_t obj_1261)
{
   {
      long aux_1796;
      aux_1796 = class_depth_60_object_class((class_t) (obj_1261));
      return BINT(aux_1796);
   }
}


/* class-final? */ bool_t 
class_final__216_object_class(class_t obj_151)
{
   {
      obj_t aux_1800;
      {
	 object_t aux_1801;
	 aux_1801 = (object_t) (obj_151);
	 aux_1800 = OBJECT_WIDENING(aux_1801);
      }
      return (((class_t) CREF(aux_1800))->final__12);
   }
}


/* _class-final? */ obj_t 
_class_final__173_object_class(obj_t env_1262, obj_t obj_1263)
{
   {
      bool_t aux_1805;
      aux_1805 = class_final__216_object_class((class_t) (obj_1263));
      return BBOOL(aux_1805);
   }
}


/* class-constructor */ obj_t 
class_constructor_163_object_class(class_t obj_152)
{
   {
      obj_t aux_1809;
      {
	 object_t aux_1810;
	 aux_1810 = (object_t) (obj_152);
	 aux_1809 = OBJECT_WIDENING(aux_1810);
      }
      return (((class_t) CREF(aux_1809))->constructor);
   }
}


/* _class-constructor */ obj_t 
_class_constructor_88_object_class(obj_t env_1264, obj_t obj_1265)
{
   return class_constructor_163_object_class((class_t) (obj_1265));
}


/* method-init */ obj_t 
method_init_76_object_class()
{
   {
      obj_t object__struct_class_161_1270;
      object__struct_class_161_1270 = proc1511_object_class;
      add_method__1___object(object__struct_env_210___object, class_object_class, object__struct_class_161_1270);
   }
   {
      obj_t struct_object__object_class_152_1266;
      struct_object__object_class_152_1266 = proc1512_object_class;
      return add_method__1___object(struct_object__object_env_209___object, class_object_class, struct_object__object_class_152_1266);
   }
}


/* struct+object->object-class */ obj_t 
struct_object__object_class_152_object_class(obj_t env_1273, obj_t o_1274, obj_t s_1275)
{
   {
      class_t o_800;
      obj_t s_801;
      {
	 class_t aux_1818;
	 o_800 = (class_t) (o_1274);
	 s_801 = s_1275;
	 {
	    {
	       obj_t old1220_804;
	       obj_t aux1221_805;
	       {
		  obj_t next_method1232_118_816;
		  next_method1232_118_816 = find_super_class_method_167___object((object_t) (o_800), struct_object__object_env_209___object, class_object_class);
		  if (PROCEDUREP(next_method1232_118_816))
		    {
		       old1220_804 = PROCEDURE_ENTRY(next_method1232_118_816) (next_method1232_118_816, (obj_t) (o_800), s_801, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1232_118_816);
		       {
			  object_t aux_1827;
			  aux_1827 = struct_object__object_93___object((object_t) (o_800), s_801);
			  old1220_804 = (obj_t) (aux_1827);
		       }
		    }
	       }
	       aux1221_805 = STRUCT_REF(s_801, ((long) 0));
	       {
		  class_t new1222_806;
		  new1222_806 = ((class_t) (old1220_804));
		  {
		     long arg1473_807;
		     arg1473_807 = class_num_218___object(class_object_class);
		     {
			obj_t obj_1102;
			obj_1102 = (obj_t) (new1222_806);
			(((obj_t) CREF(obj_1102))->header = MAKE_HEADER(arg1473_807, 0), BUNSPEC);
		     }
		  }
		  {
		     class_t arg1474_808;
		     {
			obj_t arg1475_809;
			obj_t arg1476_810;
			obj_t arg1478_812;
			obj_t arg1481_815;
			arg1475_809 = STRUCT_REF(aux1221_805, ((long) 0));
			arg1476_810 = STRUCT_REF(aux1221_805, ((long) 1));
			arg1478_812 = STRUCT_REF(aux1221_805, ((long) 3));
			arg1481_815 = STRUCT_REF(aux1221_805, ((long) 6));
			{
			   class_t res1487_1133;
			   {
			      global_t holder_1120;
			      long depth_1122;
			      bool_t final__12_1123;
			      {
				 obj_t aux_1840;
				 aux_1840 = STRUCT_REF(aux1221_805, ((long) 2));
				 holder_1120 = (global_t) (aux_1840);
			      }
			      {
				 obj_t aux_1843;
				 aux_1843 = STRUCT_REF(aux1221_805, ((long) 4));
				 depth_1122 = (long) CINT(aux_1843);
			      }
			      {
				 obj_t aux_1846;
				 aux_1846 = STRUCT_REF(aux1221_805, ((long) 5));
				 final__12_1123 = CBOOL(aux_1846);
			      }
			      {
				 class_t new1191_1125;
				 new1191_1125 = ((class_t) BREF(GC_MALLOC(sizeof(struct class))));
				 ((((class_t) CREF(new1191_1125))->its_super_214) = ((obj_t) arg1475_809), BUNSPEC);
				 ((((class_t) CREF(new1191_1125))->slots) = ((obj_t) arg1476_810), BUNSPEC);
				 ((((class_t) CREF(new1191_1125))->holder) = ((global_t) holder_1120), BUNSPEC);
				 ((((class_t) CREF(new1191_1125))->widening) = ((obj_t) arg1478_812), BUNSPEC);
				 ((((class_t) CREF(new1191_1125))->depth) = ((long) depth_1122), BUNSPEC);
				 ((((class_t) CREF(new1191_1125))->final__12) = ((bool_t) final__12_1123), BUNSPEC);
				 ((((class_t) CREF(new1191_1125))->constructor) = ((obj_t) arg1481_815), BUNSPEC);
				 res1487_1133 = new1191_1125;
			      }
			   }
			   arg1474_808 = res1487_1133;
			}
		     }
		     {
			obj_t aux_1859;
			object_t aux_1857;
			aux_1859 = (obj_t) (arg1474_808);
			aux_1857 = (object_t) (new1222_806);
			OBJECT_WIDENING_SET(aux_1857, aux_1859);
		     }
		  }
		  aux_1818 = new1222_806;
	       }
	    }
	 }
	 return (obj_t) (aux_1818);
      }
   }
}


/* object->struct-class */ obj_t 
object__struct_class_161_object_class(obj_t env_1276, obj_t obj1217_1277)
{
   {
      class_t obj1217_775;
      obj1217_775 = (class_t) (obj1217_1277);
      {
	 {
	    obj_t res1218_778;
	    {
	       obj_t next_method1231_138_798;
	       next_method1231_138_798 = find_super_class_method_167___object((object_t) (obj1217_775), object__struct_env_210___object, class_object_class);
	       if (PROCEDUREP(next_method1231_138_798))
		 {
		    res1218_778 = PROCEDURE_ENTRY(next_method1231_138_798) (next_method1231_138_798, (obj_t) (obj1217_775), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1231_138_798);
		    res1218_778 = object__struct_50___object((object_t) (obj1217_775));
		 }
	    }
	    {
	       obj_t aux1219_779;
	       {
		  obj_t aux_1874;
		  aux_1874 = CNST_TABLE_REF(((long) 1));
		  aux1219_779 = make_struct(aux_1874, ((long) 7), BUNSPEC);
	       }
	       {
		  obj_t aux_1877;
		  {
		     obj_t aux_1878;
		     {
			object_t aux_1879;
			aux_1879 = (object_t) (obj1217_775);
			aux_1878 = OBJECT_WIDENING(aux_1879);
		     }
		     aux_1877 = (((class_t) CREF(aux_1878))->its_super_214);
		  }
		  STRUCT_SET(aux1219_779, ((long) 0), aux_1877);
	       }
	       {
		  obj_t aux_1884;
		  {
		     obj_t aux_1885;
		     {
			object_t aux_1886;
			aux_1886 = (object_t) (obj1217_775);
			aux_1885 = OBJECT_WIDENING(aux_1886);
		     }
		     aux_1884 = (((class_t) CREF(aux_1885))->slots);
		  }
		  STRUCT_SET(aux1219_779, ((long) 1), aux_1884);
	       }
	       {
		  obj_t aux_1891;
		  {
		     global_t aux_1892;
		     {
			obj_t aux_1893;
			{
			   object_t aux_1894;
			   aux_1894 = (object_t) (obj1217_775);
			   aux_1893 = OBJECT_WIDENING(aux_1894);
			}
			aux_1892 = (((class_t) CREF(aux_1893))->holder);
		     }
		     aux_1891 = (obj_t) (aux_1892);
		  }
		  STRUCT_SET(aux1219_779, ((long) 2), aux_1891);
	       }
	       {
		  obj_t aux_1900;
		  {
		     obj_t aux_1901;
		     {
			object_t aux_1902;
			aux_1902 = (object_t) (obj1217_775);
			aux_1901 = OBJECT_WIDENING(aux_1902);
		     }
		     aux_1900 = (((class_t) CREF(aux_1901))->widening);
		  }
		  STRUCT_SET(aux1219_779, ((long) 3), aux_1900);
	       }
	       {
		  obj_t aux_1907;
		  {
		     long aux_1908;
		     {
			obj_t aux_1909;
			{
			   object_t aux_1910;
			   aux_1910 = (object_t) (obj1217_775);
			   aux_1909 = OBJECT_WIDENING(aux_1910);
			}
			aux_1908 = (((class_t) CREF(aux_1909))->depth);
		     }
		     aux_1907 = BINT(aux_1908);
		  }
		  STRUCT_SET(aux1219_779, ((long) 4), aux_1907);
	       }
	       {
		  obj_t aux_1916;
		  {
		     bool_t aux_1917;
		     {
			obj_t aux_1918;
			{
			   object_t aux_1919;
			   aux_1919 = (object_t) (obj1217_775);
			   aux_1918 = OBJECT_WIDENING(aux_1919);
			}
			aux_1917 = (((class_t) CREF(aux_1918))->final__12);
		     }
		     aux_1916 = BBOOL(aux_1917);
		  }
		  STRUCT_SET(aux1219_779, ((long) 5), aux_1916);
	       }
	       {
		  obj_t aux_1925;
		  {
		     obj_t aux_1926;
		     {
			object_t aux_1927;
			aux_1927 = (object_t) (obj1217_775);
			aux_1926 = OBJECT_WIDENING(aux_1927);
		     }
		     aux_1925 = (((class_t) CREF(aux_1926))->constructor);
		  }
		  STRUCT_SET(aux1219_779, ((long) 6), aux_1925);
	       }
	       STRUCT_SET(res1218_778, ((long) 0), aux1219_779);
	       {
		  obj_t aux_1933;
		  aux_1933 = STRUCT_KEY(res1218_778);
		  STRUCT_KEY_SET(aux1219_779, aux_1933);
	       }
	       {
		  obj_t aux_1936;
		  aux_1936 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1218_778, aux_1936);
	       }
	       return res1218_778;
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_class()
{
   module_initialization_70_tools_error(((long) 0), "OBJECT_CLASS");
   module_initialization_70_type_type(((long) 0), "OBJECT_CLASS");
   module_initialization_70_type_cache(((long) 0), "OBJECT_CLASS");
   module_initialization_70_type_env(((long) 0), "OBJECT_CLASS");
   module_initialization_70_object_tools(((long) 0), "OBJECT_CLASS");
   module_initialization_70_module_module(((long) 0), "OBJECT_CLASS");
   module_initialization_70_engine_param(((long) 0), "OBJECT_CLASS");
   module_initialization_70_ast_var(((long) 0), "OBJECT_CLASS");
   return module_initialization_70_ast_ident(((long) 0), "OBJECT_CLASS");
}
