/*===========================================================================*/
/*   (Object/inline.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


static obj_t method_init_76_object_inline();
extern long add_generic_method__111_object_inline(global_t, type_t, obj_t, obj_t);
extern obj_t inline_methods__72_object_inline();
static obj_t _intern_generic__171_object_inline = BUNSPEC;
static obj_t make_case_clauses_101_object_inline(obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _method_inlining_enabled__235_object_inline(obj_t);
extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t disable_method_inlining__113_object_inline();
extern obj_t module_initialization_70_object_inline(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t _inline_methods__227_object_inline(obj_t);
extern bool_t method_inlining_enabled__91_object_inline();
static obj_t imported_modules_init_94_object_inline();
static obj_t inline_method_clause_150_object_inline(obj_t, obj_t);
static obj_t _add_generic_for_method_inlining__161_object_inline(obj_t, obj_t);
extern obj_t _optim_inline_method___30_engine_param;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_object_inline();
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_object_inline();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t comptime_expand_37_expand_eps(obj_t);
extern obj_t class_object_class;
extern obj_t add_generic_for_method_inlining__147_object_inline(obj_t);
static obj_t inline_method__105_object_inline(obj_t);
static obj_t _add_generic_method__195_object_inline(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_object_inline = BUNSPEC;
static obj_t cnst_init_137_object_inline();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[27];

DEFINE_EXPORT_PROCEDURE(add_generic_for_method_inlining__env_177_object_inline, _add_generic_for_method_inlining__161_object_inline1969, _add_generic_for_method_inlining__161_object_inline, 0L, 1);
DEFINE_EXPORT_PROCEDURE(add_generic_method__env_190_object_inline, _add_generic_method__195_object_inline1970, _add_generic_method__195_object_inline, 0L, 4);
DEFINE_EXPORT_PROCEDURE(inline_methods__env_13_object_inline, _inline_methods__227_object_inline1971, _inline_methods__227_object_inline, 0L, 0);
DEFINE_EXPORT_PROCEDURE(method_inlining_enabled__env_87_object_inline, _method_inlining_enabled__235_object_inline1972, _method_inlining_enabled__235_object_inline, 0L, 0);
DEFINE_STRING(string1962_object_inline, string1962_object_inline1973, "VALUE OBJECT? OBJECT-CLASS FIND-INLINE-METHOD ELSE CASE CAR CDR FIND-METHOD-FROM CLASS-SUPER CLASS? LET* CALL-NEXT-METHOD LET LAMBDA LETREC CLASS CONS* APPLY PROCEDURE? IF LARG AUX SUPER LOOP METHOD IMETHOD ", 207);
DEFINE_STRING(string1961_object_inline, string1961_object_inline1974, "   . Method inlining", 20);


/* module-initialization */ obj_t 
module_initialization_70_object_inline(long checksum_1681, char *from_1682)
{
   if (CBOOL(require_initialization_114_object_inline))
     {
	require_initialization_114_object_inline = BBOOL(((bool_t) 0));
	library_modules_init_112_object_inline();
	cnst_init_137_object_inline();
	imported_modules_init_94_object_inline();
	method_init_76_object_inline();
	toplevel_init_63_object_inline();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_inline()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_INLINE");
   module_initialization_70___object(((long) 0), "OBJECT_INLINE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_INLINE");
   module_initialization_70___reader(((long) 0), "OBJECT_INLINE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_inline()
{
   {
      obj_t cnst_port_138_1673;
      cnst_port_138_1673 = open_input_string(string1962_object_inline);
      {
	 long i_1674;
	 i_1674 = ((long) 26);
       loop_1675:
	 {
	    bool_t test1963_1676;
	    test1963_1676 = (i_1674 == ((long) -1));
	    if (test1963_1676)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1964_1677;
		    {
		       obj_t list1965_1678;
		       {
			  obj_t arg1967_1679;
			  arg1967_1679 = BNIL;
			  list1965_1678 = MAKE_PAIR(cnst_port_138_1673, arg1967_1679);
		       }
		       arg1964_1677 = read___reader(list1965_1678);
		    }
		    CNST_TABLE_SET(i_1674, arg1964_1677);
		 }
		 {
		    int aux_1680;
		    {
		       long aux_1701;
		       aux_1701 = (i_1674 - ((long) 1));
		       aux_1680 = (int) (aux_1701);
		    }
		    {
		       long i_1704;
		       i_1704 = (long) (aux_1680);
		       i_1674 = i_1704;
		       goto loop_1675;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_inline()
{
   _intern_generic__171_object_inline = BNIL;
   return BUNSPEC;
}


/* method-inlining-enabled? */ bool_t 
method_inlining_enabled__91_object_inline()
{
   return CBOOL(_optim_inline_method___30_engine_param);
}


/* _method-inlining-enabled? */ obj_t 
_method_inlining_enabled__235_object_inline(obj_t env_1663)
{
   {
      bool_t aux_1707;
      aux_1707 = method_inlining_enabled__91_object_inline();
      return BBOOL(aux_1707);
   }
}


/* disable-method-inlining! */ obj_t 
disable_method_inlining__113_object_inline()
{
   _intern_generic__171_object_inline = BNIL;
   return (_optim_inline_method___30_engine_param = BFALSE,
      BUNSPEC);
}


/* add-generic-for-method-inlining! */ obj_t 
add_generic_for_method_inlining__147_object_inline(obj_t generic_1)
{
   {
      bool_t test1475_790;
      {
	 bool_t test1480_795;
	 {
	    bool_t res1959_1495;
	    res1959_1495 = CBOOL(_optim_inline_method___30_engine_param);
	    test1480_795 = res1959_1495;
	 }
	 if (test1480_795)
	   {
	      bool_t test1481_796;
	      {
		 obj_t arg1483_797;
		 arg1483_797 = assq___r4_pairs_and_lists_6_3(generic_1, _intern_generic__171_object_inline);
		 test1481_796 = PAIRP(arg1483_797);
	      }
	      if (test1481_796)
		{
		   test1475_790 = ((bool_t) 0);
		}
	      else
		{
		   test1475_790 = ((bool_t) 1);
		}
	   }
	 else
	   {
	      test1475_790 = ((bool_t) 0);
	   }
      }
      if (test1475_790)
	{
	   obj_t arg1476_791;
	   {
	      obj_t arg1477_792;
	      {
		 obj_t aux_1716;
		 aux_1716 = BINT(((long) 0));
		 arg1477_792 = MAKE_PAIR(aux_1716, BNIL);
	      }
	      arg1476_791 = MAKE_PAIR(generic_1, arg1477_792);
	   }
	   {
	      obj_t obj2_1502;
	      obj2_1502 = _intern_generic__171_object_inline;
	      return (_intern_generic__171_object_inline = MAKE_PAIR(arg1476_791, obj2_1502),
		 BUNSPEC);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _add-generic-for-method-inlining! */ obj_t 
_add_generic_for_method_inlining__161_object_inline(obj_t env_1664, obj_t generic_1665)
{
   return add_generic_for_method_inlining__147_object_inline(generic_1665);
}


/* add-generic-method! */ long 
add_generic_method__111_object_inline(global_t generic_16, type_t type_17, obj_t args_18, obj_t body_19)
{
   {
      obj_t cell_815;
      cell_815 = assq___r4_pairs_and_lists_6_3((obj_t) (generic_16), _intern_generic__171_object_inline);
      {
	 obj_t num_816;
	 {
	    obj_t aux_1724;
	    aux_1724 = CDR(cell_815);
	    num_816 = CAR(aux_1724);
	 }
	 {
	    obj_t aux_1729;
	    obj_t aux_1727;
	    {
	       long aux_1730;
	       {
		  long aux_1731;
		  aux_1731 = (long) CINT(num_816);
		  aux_1730 = (aux_1731 + ((long) 1));
	       }
	       aux_1729 = BINT(aux_1730);
	    }
	    aux_1727 = CDR(cell_815);
	    SET_CAR(aux_1727, aux_1729);
	 }
	 {
	    obj_t arg1505_819;
	    obj_t arg1507_820;
	    arg1505_819 = CDR(cell_815);
	    {
	       obj_t arg1510_821;
	       obj_t arg1511_822;
	       {
		  obj_t new_1549;
		  {
		     obj_t aux_1737;
		     aux_1737 = CNST_TABLE_REF(((long) 0));
		     new_1549 = create_struct(aux_1737, ((long) 3));
		  }
		  STRUCT_SET(new_1549, ((long) 2), num_816);
		  STRUCT_SET(new_1549, ((long) 1), body_19);
		  STRUCT_SET(new_1549, ((long) 0), args_18);
		  arg1510_821 = new_1549;
	       }
	       {
		  obj_t aux_1743;
		  aux_1743 = CDR(cell_815);
		  arg1511_822 = CDR(aux_1743);
	       }
	       arg1507_820 = MAKE_PAIR(arg1510_821, arg1511_822);
	    }
	    SET_CDR(arg1505_819, arg1507_820);
	 }
	 return (long) CINT(num_816);
      }
   }
}


/* _add-generic-method! */ obj_t 
_add_generic_method__195_object_inline(obj_t env_1666, obj_t generic_1667, obj_t type_1668, obj_t args_1669, obj_t body_1670)
{
   {
      long aux_1749;
      aux_1749 = add_generic_method__111_object_inline((global_t) (generic_1667), (type_t) (type_1668), args_1669, body_1670);
      return BINT(aux_1749);
   }
}


/* inline-methods! */ obj_t 
inline_methods__72_object_inline()
{
   {
      bool_t test1512_823;
      {
	 bool_t test1520_833;
	 {
	    bool_t res1960_1575;
	    res1960_1575 = CBOOL(_optim_inline_method___30_engine_param);
	    test1520_833 = res1960_1575;
	 }
	 if (test1520_833)
	   {
	      obj_t obj_1576;
	      obj_1576 = _intern_generic__171_object_inline;
	      test1512_823 = PAIRP(obj_1576);
	   }
	 else
	   {
	      test1512_823 = ((bool_t) 0);
	   }
      }
      if (test1512_823)
	{
	   {
	      obj_t list1513_824;
	      {
		 obj_t arg1515_826;
		 {
		    obj_t aux_1758;
		    aux_1758 = BCHAR(((unsigned char) '\n'));
		    arg1515_826 = MAKE_PAIR(aux_1758, BNIL);
		 }
		 list1513_824 = MAKE_PAIR(string1961_object_inline, arg1515_826);
	      }
	      verbose_tools_speek(BINT(((long) 1)), list1513_824);
	   }
	   {
	      obj_t l1462_828;
	      l1462_828 = _intern_generic__171_object_inline;
	    lname1463_829:
	      if (PAIRP(l1462_828))
		{
		   inline_method__105_object_inline(CAR(l1462_828));
		   {
		      obj_t l1462_1768;
		      l1462_1768 = CDR(l1462_828);
		      l1462_828 = l1462_1768;
		      goto lname1463_829;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return disable_method_inlining__113_object_inline();
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _inline-methods! */ obj_t 
_inline_methods__227_object_inline(obj_t env_1671)
{
   return inline_methods__72_object_inline();
}


/* inline-method! */ obj_t 
inline_method__105_object_inline(obj_t cell_20)
{
   {
      obj_t generic_834;
      generic_834 = CAR(cell_20);
      {
	 obj_t imethods_835;
	 {
	    obj_t aux_1773;
	    {
	       obj_t aux_1774;
	       aux_1774 = CDR(cell_20);
	       aux_1773 = CDR(aux_1774);
	    }
	    imethods_835 = reverse__39___r4_pairs_and_lists_6_3(aux_1773);
	 }
	 {
	    value_t sfun_836;
	    {
	       global_t obj_1585;
	       obj_1585 = (global_t) (generic_834);
	       sfun_836 = (((global_t) CREF(obj_1585))->value);
	    }
	    {
	       obj_t old_body_129_838;
	       {
		  sfun_t obj_1587;
		  obj_1587 = (sfun_t) (sfun_836);
		  old_body_129_838 = (((sfun_t) CREF(obj_1587))->body);
	       }
	       {
		  obj_t args_839;
		  {
		     sfun_t obj_1588;
		     obj_1588 = (sfun_t) (sfun_836);
		     args_839 = (((sfun_t) CREF(obj_1588))->args);
		  }
		  {
		     long arity_840;
		     {
			sfun_t obj_1589;
			obj_1589 = (sfun_t) (sfun_836);
			arity_840 = (((sfun_t) CREF(obj_1589))->arity);
		     }
		     {
			obj_t marg_841;
			marg_841 = CAR(args_839);
			{
			   obj_t method_842;
			   method_842 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
			   {
			      obj_t loop_843;
			      loop_843 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
			      {
				 obj_t super_844;
				 super_844 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
				 {
				    obj_t aux_845;
				    aux_845 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
				    {
				       obj_t larg_846;
				       larg_846 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
				       {
					  obj_t largs_847;
					  {
					     obj_t aux_1802;
					     aux_1802 = CDR(args_839);
					     largs_847 = MAKE_PAIR(larg_846, aux_1802);
					  }
					  {
					     obj_t other_body_17_848;
					     {
						obj_t arg1774_1052;
						obj_t arg1776_1053;
						obj_t arg1777_1054;
						arg1774_1052 = CNST_TABLE_REF(((long) 6));
						{
						   obj_t arg1788_1061;
						   arg1788_1061 = CNST_TABLE_REF(((long) 7));
						   {
						      obj_t list1790_1063;
						      {
							 obj_t arg1791_1064;
							 arg1791_1064 = MAKE_PAIR(BNIL, BNIL);
							 list1790_1063 = MAKE_PAIR(method_842, arg1791_1064);
						      }
						      arg1776_1053 = cons__138___r4_pairs_and_lists_6_3(arg1788_1061, list1790_1063);
						   }
						}
						if ((arity_840 >= ((long) 0)))
						  {
						     obj_t arg1794_1067;
						     {
							obj_t arg1797_1070;
							arg1797_1070 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							arg1794_1067 = append_2_18___r4_pairs_and_lists_6_3(args_839, arg1797_1070);
						     }
						     {
							obj_t list1795_1068;
							list1795_1068 = MAKE_PAIR(arg1794_1067, BNIL);
							arg1777_1054 = cons__138___r4_pairs_and_lists_6_3(method_842, list1795_1068);
						     }
						  }
						else
						  {
						     obj_t arg1802_1073;
						     obj_t arg1803_1074;
						     arg1802_1073 = CNST_TABLE_REF(((long) 8));
						     {
							obj_t arg1809_1080;
							obj_t arg1810_1081;
							arg1809_1080 = CNST_TABLE_REF(((long) 9));
							{
							   obj_t arg1813_1084;
							   arg1813_1084 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							   arg1810_1081 = append_2_18___r4_pairs_and_lists_6_3(args_839, arg1813_1084);
							}
							{
							   obj_t list1811_1082;
							   list1811_1082 = MAKE_PAIR(arg1810_1081, BNIL);
							   arg1803_1074 = cons__138___r4_pairs_and_lists_6_3(arg1809_1080, list1811_1082);
							}
						     }
						     {
							obj_t list1805_1076;
							{
							   obj_t arg1806_1077;
							   {
							      obj_t arg1807_1078;
							      arg1807_1078 = MAKE_PAIR(BNIL, BNIL);
							      arg1806_1077 = MAKE_PAIR(arg1803_1074, arg1807_1078);
							   }
							   list1805_1076 = MAKE_PAIR(method_842, arg1806_1077);
							}
							arg1777_1054 = cons__138___r4_pairs_and_lists_6_3(arg1802_1073, list1805_1076);
						     }
						  }
						{
						   obj_t list1779_1056;
						   {
						      obj_t arg1780_1057;
						      {
							 obj_t arg1781_1058;
							 {
							    obj_t arg1783_1059;
							    arg1783_1059 = MAKE_PAIR(BNIL, BNIL);
							    arg1781_1058 = MAKE_PAIR(old_body_129_838, arg1783_1059);
							 }
							 arg1780_1057 = MAKE_PAIR(arg1777_1054, arg1781_1058);
						      }
						      list1779_1056 = MAKE_PAIR(arg1776_1053, arg1780_1057);
						   }
						   other_body_17_848 = cons__138___r4_pairs_and_lists_6_3(arg1774_1052, list1779_1056);
						}
					     }
					     {
						obj_t class_849;
						class_849 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 10)), BEOA);
						{
						   {
						      obj_t new_body_215_850;
						      {
							 obj_t arg1526_854;
							 {
							    obj_t arg1527_855;
							    obj_t arg1528_856;
							    obj_t arg1529_857;
							    arg1527_855 = CNST_TABLE_REF(((long) 11));
							    {
							       obj_t arg1535_863;
							       {
								  obj_t arg1540_867;
								  {
								     obj_t arg1549_872;
								     obj_t arg1550_873;
								     obj_t arg1552_874;
								     arg1549_872 = CNST_TABLE_REF(((long) 12));
								     {
									obj_t list1559_881;
									{
									   obj_t arg1560_882;
									   arg1560_882 = MAKE_PAIR(BNIL, BNIL);
									   list1559_881 = MAKE_PAIR(class_849, arg1560_882);
									}
									arg1550_873 = cons__138___r4_pairs_and_lists_6_3(method_842, list1559_881);
								     }
								     {
									obj_t arg1562_884;
									obj_t arg1563_885;
									obj_t arg1564_886;
									arg1562_884 = CNST_TABLE_REF(((long) 13));
									{
									   obj_t arg1572_892;
									   {
									      obj_t arg1578_896;
									      obj_t arg1580_897;
									      arg1578_896 = CNST_TABLE_REF(((long) 14));
									      {
										 obj_t arg1585_902;
										 obj_t arg1587_904;
										 arg1585_902 = CNST_TABLE_REF(((long) 12));
										 {
										    obj_t arg1595_910;
										    obj_t arg1598_911;
										    obj_t arg1600_912;
										    arg1595_910 = CNST_TABLE_REF(((long) 15));
										    {
										       obj_t arg1608_918;
										       obj_t arg1609_919;
										       {
											  obj_t arg1615_924;
											  {
											     obj_t arg1622_929;
											     obj_t arg1623_930;
											     obj_t arg1624_931;
											     arg1622_929 = CNST_TABLE_REF(((long) 6));
											     {
												obj_t arg1633_938;
												arg1633_938 = CNST_TABLE_REF(((long) 16));
												{
												   obj_t list1635_940;
												   {
												      obj_t arg1636_941;
												      arg1636_941 = MAKE_PAIR(BNIL, BNIL);
												      list1635_940 = MAKE_PAIR(class_849, arg1636_941);
												   }
												   arg1623_930 = cons__138___r4_pairs_and_lists_6_3(arg1633_938, list1635_940);
												}
											     }
											     {
												obj_t arg1639_943;
												arg1639_943 = CNST_TABLE_REF(((long) 17));
												{
												   obj_t list1641_945;
												   {
												      obj_t arg1645_946;
												      arg1645_946 = MAKE_PAIR(BNIL, BNIL);
												      list1641_945 = MAKE_PAIR(class_849, arg1645_946);
												   }
												   arg1624_931 = cons__138___r4_pairs_and_lists_6_3(arg1639_943, list1641_945);
												}
											     }
											     {
												obj_t list1626_933;
												{
												   obj_t arg1627_934;
												   {
												      obj_t arg1628_935;
												      {
													 obj_t arg1630_936;
													 arg1630_936 = MAKE_PAIR(BNIL, BNIL);
													 arg1628_935 = MAKE_PAIR(BFALSE, arg1630_936);
												      }
												      arg1627_934 = MAKE_PAIR(arg1624_931, arg1628_935);
												   }
												   list1626_933 = MAKE_PAIR(arg1623_930, arg1627_934);
												}
												arg1615_924 = cons__138___r4_pairs_and_lists_6_3(arg1622_929, list1626_933);
											     }
											  }
											  {
											     obj_t list1618_926;
											     {
												obj_t arg1620_927;
												arg1620_927 = MAKE_PAIR(BNIL, BNIL);
												list1618_926 = MAKE_PAIR(arg1615_924, arg1620_927);
											     }
											     arg1608_918 = cons__138___r4_pairs_and_lists_6_3(super_844, list1618_926);
											  }
										       }
										       {
											  obj_t arg1647_948;
											  {
											     obj_t arg1653_953;
											     arg1653_953 = CNST_TABLE_REF(((long) 18));
											     {
												obj_t list1655_955;
												{
												   obj_t arg1656_956;
												   {
												      obj_t arg1657_957;
												      {
													 obj_t arg1658_958;
													 arg1658_958 = MAKE_PAIR(BNIL, BNIL);
													 arg1657_957 = MAKE_PAIR(super_844, arg1658_958);
												      }
												      arg1656_956 = MAKE_PAIR(generic_834, arg1657_957);
												   }
												   list1655_955 = MAKE_PAIR(marg_841, arg1656_956);
												}
												arg1647_948 = cons__138___r4_pairs_and_lists_6_3(arg1653_953, list1655_955);
											     }
											  }
											  {
											     obj_t list1649_950;
											     {
												obj_t arg1650_951;
												arg1650_951 = MAKE_PAIR(BNIL, BNIL);
												list1649_950 = MAKE_PAIR(arg1647_948, arg1650_951);
											     }
											     arg1609_919 = cons__138___r4_pairs_and_lists_6_3(aux_845, list1649_950);
											  }
										       }
										       {
											  obj_t list1611_921;
											  {
											     obj_t arg1612_922;
											     arg1612_922 = MAKE_PAIR(BNIL, BNIL);
											     list1611_921 = MAKE_PAIR(arg1609_919, arg1612_922);
											  }
											  arg1598_911 = cons__138___r4_pairs_and_lists_6_3(arg1608_918, list1611_921);
										       }
										    }
										    {
										       obj_t arg1661_960;
										       obj_t arg1663_961;
										       {
											  obj_t arg1670_967;
											  arg1670_967 = CNST_TABLE_REF(((long) 19));
											  {
											     obj_t list1673_969;
											     {
												obj_t arg1675_970;
												arg1675_970 = MAKE_PAIR(BNIL, BNIL);
												list1673_969 = MAKE_PAIR(aux_845, arg1675_970);
											     }
											     arg1661_960 = cons__138___r4_pairs_and_lists_6_3(arg1670_967, list1673_969);
											  }
										       }
										       {
											  obj_t arg1677_972;
											  arg1677_972 = CNST_TABLE_REF(((long) 20));
											  {
											     obj_t list1679_974;
											     {
												obj_t arg1680_975;
												arg1680_975 = MAKE_PAIR(BNIL, BNIL);
												list1679_974 = MAKE_PAIR(aux_845, arg1680_975);
											     }
											     arg1663_961 = cons__138___r4_pairs_and_lists_6_3(arg1677_972, list1679_974);
											  }
										       }
										       {
											  obj_t list1666_963;
											  {
											     obj_t arg1667_964;
											     {
												obj_t arg1668_965;
												arg1668_965 = MAKE_PAIR(BNIL, BNIL);
												arg1667_964 = MAKE_PAIR(arg1663_961, arg1668_965);
											     }
											     list1666_963 = MAKE_PAIR(arg1661_960, arg1667_964);
											  }
											  arg1600_912 = cons__138___r4_pairs_and_lists_6_3(loop_843, list1666_963);
										       }
										    }
										    {
										       obj_t list1603_914;
										       {
											  obj_t arg1605_915;
											  {
											     obj_t arg1606_916;
											     arg1606_916 = MAKE_PAIR(BNIL, BNIL);
											     arg1605_915 = MAKE_PAIR(arg1600_912, arg1606_916);
											  }
											  list1603_914 = MAKE_PAIR(arg1598_911, arg1605_915);
										       }
										       arg1587_904 = cons__138___r4_pairs_and_lists_6_3(arg1595_910, list1603_914);
										    }
										 }
										 {
										    obj_t list1589_906;
										    {
										       obj_t arg1592_907;
										       {
											  obj_t arg1593_908;
											  arg1593_908 = MAKE_PAIR(BNIL, BNIL);
											  arg1592_907 = MAKE_PAIR(arg1587_904, arg1593_908);
										       }
										       list1589_906 = MAKE_PAIR(BNIL, arg1592_907);
										    }
										    arg1580_897 = cons__138___r4_pairs_and_lists_6_3(arg1585_902, list1589_906);
										 }
									      }
									      {
										 obj_t list1582_899;
										 {
										    obj_t arg1583_900;
										    arg1583_900 = MAKE_PAIR(BNIL, BNIL);
										    list1582_899 = MAKE_PAIR(arg1580_897, arg1583_900);
										 }
										 arg1572_892 = cons__138___r4_pairs_and_lists_6_3(arg1578_896, list1582_899);
									      }
									   }
									   {
									      obj_t list1574_894;
									      list1574_894 = MAKE_PAIR(BNIL, BNIL);
									      arg1563_885 = cons__138___r4_pairs_and_lists_6_3(arg1572_892, list1574_894);
									   }
									}
									{
									   obj_t arg1682_977;
									   obj_t arg1683_978;
									   arg1682_977 = CNST_TABLE_REF(((long) 21));
									   {
									      obj_t arg1688_982;
									      obj_t arg1689_983;
									      arg1688_982 = make_case_clauses_101_object_inline(args_839, imethods_835);
									      {
										 obj_t arg1691_984;
										 {
										    obj_t arg1695_988;
										    arg1695_988 = CNST_TABLE_REF(((long) 22));
										    {
										       obj_t list1698_990;
										       {
											  obj_t arg1699_991;
											  arg1699_991 = MAKE_PAIR(BNIL, BNIL);
											  list1698_990 = MAKE_PAIR(other_body_17_848, arg1699_991);
										       }
										       arg1691_984 = cons__138___r4_pairs_and_lists_6_3(arg1695_988, list1698_990);
										    }
										 }
										 {
										    obj_t list1693_986;
										    list1693_986 = MAKE_PAIR(BNIL, BNIL);
										    arg1689_983 = cons__138___r4_pairs_and_lists_6_3(arg1691_984, list1693_986);
										 }
									      }
									      arg1683_978 = append_2_18___r4_pairs_and_lists_6_3(arg1688_982, arg1689_983);
									   }
									   {
									      obj_t list1684_979;
									      {
										 obj_t arg1685_980;
										 arg1685_980 = MAKE_PAIR(arg1683_978, BNIL);
										 list1684_979 = MAKE_PAIR(method_842, arg1685_980);
									      }
									      arg1564_886 = cons__138___r4_pairs_and_lists_6_3(arg1682_977, list1684_979);
									   }
									}
									{
									   obj_t list1566_888;
									   {
									      obj_t arg1568_889;
									      {
										 obj_t arg1569_890;
										 arg1569_890 = MAKE_PAIR(BNIL, BNIL);
										 arg1568_889 = MAKE_PAIR(arg1564_886, arg1569_890);
									      }
									      list1566_888 = MAKE_PAIR(arg1563_885, arg1568_889);
									   }
									   arg1552_874 = cons__138___r4_pairs_and_lists_6_3(arg1562_884, list1566_888);
									}
								     }
								     {
									obj_t list1554_876;
									{
									   obj_t arg1555_877;
									   {
									      obj_t arg1556_878;
									      arg1556_878 = MAKE_PAIR(BNIL, BNIL);
									      arg1555_877 = MAKE_PAIR(arg1552_874, arg1556_878);
									   }
									   list1554_876 = MAKE_PAIR(arg1550_873, arg1555_877);
									}
									arg1540_867 = cons__138___r4_pairs_and_lists_6_3(arg1549_872, list1554_876);
								     }
								  }
								  {
								     obj_t list1543_869;
								     {
									obj_t arg1545_870;
									arg1545_870 = MAKE_PAIR(BNIL, BNIL);
									list1543_869 = MAKE_PAIR(arg1540_867, arg1545_870);
								     }
								     arg1535_863 = cons__138___r4_pairs_and_lists_6_3(loop_843, list1543_869);
								  }
							       }
							       {
								  obj_t list1537_865;
								  list1537_865 = MAKE_PAIR(BNIL, BNIL);
								  arg1528_856 = cons__138___r4_pairs_and_lists_6_3(arg1535_863, list1537_865);
							       }
							    }
							    {
							       bool_t test1701_993;
							       {
								  obj_t aux_1922;
								  {
								     type_t aux_1923;
								     {
									local_t obj_1596;
									obj_1596 = (local_t) (marg_841);
									aux_1923 = (((local_t) CREF(obj_1596))->type);
								     }
								     aux_1922 = (obj_t) (aux_1923);
								  }
								  test1701_993 = is_a__118___object(aux_1922, class_object_class);
							       }
							       if (test1701_993)
								 {
								    obj_t arg1702_994;
								    obj_t arg1703_995;
								    {
								       obj_t arg1709_1001;
								       arg1709_1001 = CNST_TABLE_REF(((long) 23));
								       {
									  obj_t list1711_1003;
									  {
									     obj_t arg1712_1004;
									     {
										obj_t arg1713_1005;
										arg1713_1005 = MAKE_PAIR(BNIL, BNIL);
										arg1712_1004 = MAKE_PAIR(generic_834, arg1713_1005);
									     }
									     list1711_1003 = MAKE_PAIR(marg_841, arg1712_1004);
									  }
									  arg1702_994 = cons__138___r4_pairs_and_lists_6_3(arg1709_1001, list1711_1003);
								       }
								    }
								    {
								       obj_t arg1716_1007;
								       arg1716_1007 = CNST_TABLE_REF(((long) 24));
								       {
									  obj_t list1718_1009;
									  {
									     obj_t arg1720_1010;
									     arg1720_1010 = MAKE_PAIR(BNIL, BNIL);
									     list1718_1009 = MAKE_PAIR(marg_841, arg1720_1010);
									  }
									  arg1703_995 = cons__138___r4_pairs_and_lists_6_3(arg1716_1007, list1718_1009);
								       }
								    }
								    {
								       obj_t list1705_997;
								       {
									  obj_t arg1706_998;
									  {
									     obj_t arg1707_999;
									     arg1707_999 = MAKE_PAIR(BNIL, BNIL);
									     arg1706_998 = MAKE_PAIR(arg1703_995, arg1707_999);
									  }
									  list1705_997 = MAKE_PAIR(arg1702_994, arg1706_998);
								       }
								       arg1529_857 = cons__138___r4_pairs_and_lists_6_3(loop_843, list1705_997);
								    }
								 }
							       else
								 {
								    obj_t arg1722_1012;
								    obj_t arg1723_1013;
								    obj_t arg1724_1014;
								    obj_t arg1725_1015;
								    arg1722_1012 = CNST_TABLE_REF(((long) 6));
								    {
								       obj_t arg1732_1022;
								       arg1732_1022 = CNST_TABLE_REF(((long) 25));
								       {
									  obj_t list1734_1024;
									  {
									     obj_t arg1738_1025;
									     arg1738_1025 = MAKE_PAIR(BNIL, BNIL);
									     list1734_1024 = MAKE_PAIR(marg_841, arg1738_1025);
									  }
									  arg1723_1013 = cons__138___r4_pairs_and_lists_6_3(arg1732_1022, list1734_1024);
								       }
								    }
								    {
								       obj_t arg1740_1027;
								       obj_t arg1743_1028;
								       {
									  obj_t arg1749_1034;
									  arg1749_1034 = CNST_TABLE_REF(((long) 23));
									  {
									     obj_t list1754_1036;
									     {
										obj_t arg1755_1037;
										{
										   obj_t arg1758_1038;
										   arg1758_1038 = MAKE_PAIR(BNIL, BNIL);
										   arg1755_1037 = MAKE_PAIR(generic_834, arg1758_1038);
										}
										list1754_1036 = MAKE_PAIR(marg_841, arg1755_1037);
									     }
									     arg1740_1027 = cons__138___r4_pairs_and_lists_6_3(arg1749_1034, list1754_1036);
									  }
								       }
								       {
									  obj_t arg1760_1040;
									  arg1760_1040 = CNST_TABLE_REF(((long) 24));
									  {
									     obj_t list1762_1042;
									     {
										obj_t arg1765_1043;
										arg1765_1043 = MAKE_PAIR(BNIL, BNIL);
										list1762_1042 = MAKE_PAIR(marg_841, arg1765_1043);
									     }
									     arg1743_1028 = cons__138___r4_pairs_and_lists_6_3(arg1760_1040, list1762_1042);
									  }
								       }
								       {
									  obj_t list1745_1030;
									  {
									     obj_t arg1746_1031;
									     {
										obj_t arg1747_1032;
										arg1747_1032 = MAKE_PAIR(BNIL, BNIL);
										arg1746_1031 = MAKE_PAIR(arg1743_1028, arg1747_1032);
									     }
									     list1745_1030 = MAKE_PAIR(arg1740_1027, arg1746_1031);
									  }
									  arg1724_1014 = cons__138___r4_pairs_and_lists_6_3(loop_843, list1745_1030);
								       }
								    }
								    {
								       obj_t list1768_1046;
								       {
									  obj_t arg1769_1047;
									  {
									     obj_t arg1770_1048;
									     arg1770_1048 = MAKE_PAIR(BNIL, BNIL);
									     arg1769_1047 = MAKE_PAIR(BFALSE, arg1770_1048);
									  }
									  list1768_1046 = MAKE_PAIR(BFALSE, arg1769_1047);
								       }
								       arg1725_1015 = cons__138___r4_pairs_and_lists_6_3(loop_843, list1768_1046);
								    }
								    {
								       obj_t list1727_1017;
								       {
									  obj_t arg1728_1018;
									  {
									     obj_t arg1729_1019;
									     {
										obj_t arg1730_1020;
										arg1730_1020 = MAKE_PAIR(BNIL, BNIL);
										arg1729_1019 = MAKE_PAIR(arg1725_1015, arg1730_1020);
									     }
									     arg1728_1018 = MAKE_PAIR(arg1724_1014, arg1729_1019);
									  }
									  list1727_1017 = MAKE_PAIR(arg1723_1013, arg1728_1018);
								       }
								       arg1529_857 = cons__138___r4_pairs_and_lists_6_3(arg1722_1012, list1727_1017);
								    }
								 }
							    }
							    {
							       obj_t list1531_859;
							       {
								  obj_t arg1532_860;
								  {
								     obj_t arg1533_861;
								     arg1533_861 = MAKE_PAIR(BNIL, BNIL);
								     arg1532_860 = MAKE_PAIR(arg1529_857, arg1533_861);
								  }
								  list1531_859 = MAKE_PAIR(arg1528_856, arg1532_860);
							       }
							       arg1526_854 = cons__138___r4_pairs_and_lists_6_3(arg1527_855, list1531_859);
							    }
							 }
							 new_body_215_850 = comptime_expand_37_expand_eps(arg1526_854);
						      }
						      {
							 node_t arg1522_851;
							 {
							    obj_t aux_1974;
							    {
							       node_t obj_1598;
							       obj_1598 = (node_t) (old_body_129_838);
							       aux_1974 = (((node_t) CREF(obj_1598))->loc);
							    }
							    arg1522_851 = sexp__node_235_ast_sexp(new_body_215_850, args_839, aux_1974, CNST_TABLE_REF(((long) 26)));
							 }
							 {
							    sfun_t obj_1599;
							    obj_t val1136_1600;
							    obj_1599 = (sfun_t) (sfun_836);
							    val1136_1600 = (obj_t) (arg1522_851);
							    return ((((sfun_t) CREF(obj_1599))->body) = ((obj_t) val1136_1600), BUNSPEC);
							 }
						      }
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-case-clauses */ obj_t 
make_case_clauses_101_object_inline(obj_t args_21, obj_t imethods_22)
{
   if (NULLP(imethods_22))
     {
	return BNIL;
     }
   else
     {
	obj_t head1466_1096;
	head1466_1096 = MAKE_PAIR(BNIL, BNIL);
	{
	   obj_t l1464_1097;
	   obj_t tail1467_1098;
	   l1464_1097 = imethods_22;
	   tail1467_1098 = head1466_1096;
	 lname1465_1099:
	   if (NULLP(l1464_1097))
	     {
		return CDR(head1466_1096);
	     }
	   else
	     {
		obj_t newtail1468_1101;
		{
		   obj_t arg1827_1103;
		   arg1827_1103 = inline_method_clause_150_object_inline(args_21, CAR(l1464_1097));
		   newtail1468_1101 = MAKE_PAIR(arg1827_1103, BNIL);
		}
		SET_CDR(tail1467_1098, newtail1468_1101);
		{
		   obj_t tail1467_1994;
		   obj_t l1464_1992;
		   l1464_1992 = CDR(l1464_1097);
		   tail1467_1994 = newtail1468_1101;
		   tail1467_1098 = tail1467_1994;
		   l1464_1097 = l1464_1992;
		   goto lname1465_1099;
		}
	     }
	}
     }
}


/* inline-method-clause */ obj_t 
inline_method_clause_150_object_inline(obj_t generic_args_72_23, obj_t imethod_24)
{
   {
      obj_t num_1109;
      obj_t body_1110;
      num_1109 = STRUCT_REF(imethod_24, ((long) 2));
      body_1110 = STRUCT_REF(imethod_24, ((long) 1));
      {
	 obj_t arg1832_1111;
	 obj_t arg1833_1112;
	 {
	    obj_t list1839_1118;
	    list1839_1118 = MAKE_PAIR(BNIL, BNIL);
	    arg1832_1111 = cons__138___r4_pairs_and_lists_6_3(num_1109, list1839_1118);
	 }
	 {
	    obj_t arg1843_1120;
	    obj_t arg1847_1121;
	    arg1843_1120 = CNST_TABLE_REF(((long) 13));
	    {
	       obj_t ll1469_1127;
	       ll1469_1127 = args___args_list_50_tools_args(STRUCT_REF(imethod_24, ((long) 0)));
	       if (NULLP(ll1469_1127))
		 {
		    arg1847_1121 = BNIL;
		 }
	       else
		 {
		    obj_t head1471_1130;
		    {
		       obj_t arg1868_1148;
		       {
			  obj_t arg1870_1150;
			  arg1870_1150 = CAR(ll1469_1127);
			  {
			     obj_t list1872_1152;
			     {
				obj_t arg1874_1153;
				{
				   obj_t aux_2005;
				   aux_2005 = CAR(generic_args_72_23);
				   arg1874_1153 = MAKE_PAIR(aux_2005, BNIL);
				}
				list1872_1152 = MAKE_PAIR(arg1870_1150, arg1874_1153);
			     }
			     arg1868_1148 = list1872_1152;
			  }
		       }
		       head1471_1130 = MAKE_PAIR(arg1868_1148, BNIL);
		    }
		    {
		       obj_t ll1469_1131;
		       obj_t ll1470_1132;
		       obj_t tail1472_1133;
		       ll1469_1131 = CDR(ll1469_1127);
		       ll1470_1132 = CDR(generic_args_72_23);
		       tail1472_1133 = head1471_1130;
		     lname1474_1134:
		       if (NULLP(ll1469_1131))
			 {
			    arg1847_1121 = head1471_1130;
			 }
		       else
			 {
			    obj_t newtail1473_1138;
			    {
			       obj_t arg1861_1141;
			       {
				  obj_t arg1863_1143;
				  arg1863_1143 = CAR(ll1469_1131);
				  {
				     obj_t list1865_1145;
				     {
					obj_t arg1866_1146;
					{
					   obj_t aux_2013;
					   aux_2013 = CAR(ll1470_1132);
					   arg1866_1146 = MAKE_PAIR(aux_2013, BNIL);
					}
					list1865_1145 = MAKE_PAIR(arg1863_1143, arg1866_1146);
				     }
				     arg1861_1141 = list1865_1145;
				  }
			       }
			       newtail1473_1138 = MAKE_PAIR(arg1861_1141, BNIL);
			    }
			    SET_CDR(tail1472_1133, newtail1473_1138);
			    {
			       obj_t tail1472_2023;
			       obj_t ll1470_2021;
			       obj_t ll1469_2019;
			       ll1469_2019 = CDR(ll1469_1131);
			       ll1470_2021 = CDR(ll1470_1132);
			       tail1472_2023 = newtail1473_1138;
			       tail1472_1133 = tail1472_2023;
			       ll1470_1132 = ll1470_2021;
			       ll1469_1131 = ll1469_2019;
			       goto lname1474_1134;
			    }
			 }
		    }
		 }
	    }
	    {
	       obj_t list1849_1123;
	       {
		  obj_t arg1850_1124;
		  {
		     obj_t arg1851_1125;
		     arg1851_1125 = MAKE_PAIR(BNIL, BNIL);
		     arg1850_1124 = MAKE_PAIR(body_1110, arg1851_1125);
		  }
		  list1849_1123 = MAKE_PAIR(arg1847_1121, arg1850_1124);
	       }
	       arg1833_1112 = cons__138___r4_pairs_and_lists_6_3(arg1843_1120, list1849_1123);
	    }
	 }
	 {
	    obj_t list1835_1114;
	    {
	       obj_t arg1836_1115;
	       arg1836_1115 = MAKE_PAIR(BNIL, BNIL);
	       list1835_1114 = MAKE_PAIR(arg1833_1112, arg1836_1115);
	    }
	    return cons__138___r4_pairs_and_lists_6_3(arg1832_1111, list1835_1114);
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_object_inline()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_inline()
{
   module_initialization_70_tools_trace(((long) 0), "OBJECT_INLINE");
   module_initialization_70_engine_param(((long) 0), "OBJECT_INLINE");
   module_initialization_70_tools_shape(((long) 0), "OBJECT_INLINE");
   module_initialization_70_tools_speek(((long) 0), "OBJECT_INLINE");
   module_initialization_70_tools_args(((long) 0), "OBJECT_INLINE");
   module_initialization_70_type_type(((long) 0), "OBJECT_INLINE");
   module_initialization_70_expand_eps(((long) 0), "OBJECT_INLINE");
   module_initialization_70_ast_var(((long) 0), "OBJECT_INLINE");
   module_initialization_70_ast_node(((long) 0), "OBJECT_INLINE");
   module_initialization_70_ast_sexp(((long) 0), "OBJECT_INLINE");
   return module_initialization_70_object_class(((long) 0), "OBJECT_INLINE");
}
