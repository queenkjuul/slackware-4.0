/*===========================================================================*/
/*   (Expand/assert.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t expand_assert_18_expand_assert(obj_t, obj_t);
static obj_t make_one_assert_167_expand_assert(obj_t, obj_t, obj_t, obj_t);
extern obj_t location_full_fname_231_tools_location(obj_t);
static obj_t _expand_assert1332_163_expand_assert(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_expand_assert(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern bool_t list__240___r4_pairs_and_lists_6_3(obj_t);
static obj_t imported_modules_init_94_expand_assert();
static obj_t dup_expand_assert(obj_t);
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_assert();
static obj_t toplevel_init_63_expand_assert();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t find_location_120_tools_location(obj_t);
static obj_t require_initialization_114_expand_assert = BUNSPEC;
static obj_t cnst_init_137_expand_assert();
static obj_t __cnst[12];

DEFINE_EXPORT_PROCEDURE(expand_assert_env_90_expand_assert, _expand_assert1332_163_expand_assert1341, _expand_assert1332_163_expand_assert, 0L, 2);
DEFINE_STRING(string1334_expand_assert, string1334_expand_assert1342, "UNBIND-PRIMOP! NOTIFY-ASSERT-FAIL LOCATION FOREIGN __EVMEANING_ADDRESS @ QUOTE DEFINE-PRIMOP-REF! BEGIN IF CHECK ASSERT ", 120);
DEFINE_STRING(string1333_expand_assert, string1333_expand_assert1343, "Illegal `assert' form", 21);


/* module-initialization */ obj_t 
module_initialization_70_expand_assert(long checksum_298, char *from_299)
{
   if (CBOOL(require_initialization_114_expand_assert))
     {
	require_initialization_114_expand_assert = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_assert();
	cnst_init_137_expand_assert();
	imported_modules_init_94_expand_assert();
	toplevel_init_63_expand_assert();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_assert()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_ASSERT");
   module_initialization_70___reader(((long) 0), "EXPAND_ASSERT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_assert()
{
   {
      obj_t cnst_port_138_290;
      cnst_port_138_290 = open_input_string(string1334_expand_assert);
      {
	 long i_291;
	 i_291 = ((long) 11);
       loop_292:
	 {
	    bool_t test1335_293;
	    test1335_293 = (i_291 == ((long) -1));
	    if (test1335_293)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1337_294;
		    {
		       obj_t list1338_295;
		       {
			  obj_t arg1339_296;
			  arg1339_296 = BNIL;
			  list1338_295 = MAKE_PAIR(cnst_port_138_290, arg1339_296);
		       }
		       arg1337_294 = read___reader(list1338_295);
		    }
		    CNST_TABLE_SET(i_291, arg1337_294);
		 }
		 {
		    int aux_297;
		    {
		       long aux_315;
		       aux_315 = (i_291 - ((long) 1));
		       aux_297 = (int) (aux_315);
		    }
		    {
		       long i_318;
		       i_318 = (long) (aux_297);
		       i_291 = i_318;
		       goto loop_292;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_assert()
{
   return BUNSPEC;
}


/* expand-assert */ obj_t 
expand_assert_18_expand_assert(obj_t x_15, obj_t e_16)
{
   {
      obj_t vars_42;
      obj_t pred_43;
      obj_t vars_39;
      obj_t body_40;
      if (PAIRP(x_15))
	{
	   obj_t cdr_111_186_48;
	   cdr_111_186_48 = CDR(x_15);
	   if (PAIRP(cdr_111_186_48))
	     {
		obj_t cdr_115_115_50;
		cdr_115_115_50 = CDR(cdr_111_186_48);
		{
		   bool_t test_326;
		   {
		      obj_t aux_329;
		      obj_t aux_327;
		      aux_329 = CNST_TABLE_REF(((long) 1));
		      aux_327 = CAR(cdr_111_186_48);
		      test_326 = (aux_327 == aux_329);
		   }
		   if (test_326)
		     {
			if (PAIRP(cdr_115_115_50))
			  {
			     obj_t car_118_222_53;
			     car_118_222_53 = CAR(cdr_115_115_50);
			     if (PAIRP(car_118_222_53))
			       {
				  vars_39 = car_118_222_53;
				  body_40 = CDR(cdr_115_115_50);
				  {
				     obj_t new_70;
				     {
					obj_t arg1145_71;
					obj_t arg1150_72;
					arg1145_71 = CNST_TABLE_REF(((long) 0));
					{
					   obj_t arg1163_76;
					   arg1163_76 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					   arg1150_72 = append_2_18___r4_pairs_and_lists_6_3(body_40, arg1163_76);
					}
					{
					   obj_t list1151_73;
					   {
					      obj_t arg1157_74;
					      arg1157_74 = MAKE_PAIR(arg1150_72, BNIL);
					      list1151_73 = MAKE_PAIR(vars_39, arg1157_74);
					   }
					   new_70 = cons__138___r4_pairs_and_lists_6_3(arg1145_71, list1151_73);
					}
				     }
				     replace__160_tools_misc(x_15, new_70);
				     return PROCEDURE_ENTRY(e_16) (e_16, x_15, e_16, BEOA);
				  }
			       }
			     else
			       {
				  obj_t car_131_9_57;
				  car_131_9_57 = CAR(cdr_111_186_48);
				  if (list__240___r4_pairs_and_lists_6_3(car_131_9_57))
				    {
				       vars_42 = car_131_9_57;
				       pred_43 = CDR(cdr_111_186_48);
				     tag_102_241_44:
				       {
					  bool_t test1177_79;
					  {
					     bool_t test1178_81;
					     {
						obj_t obj_241;
						obj_241 = _compiler_debug__134_engine_param;
						test1178_81 = INTEGERP(obj_241);
					     }
					     if (test1178_81)
					       {
						  long n1_242;
						  n1_242 = (long) CINT(_compiler_debug__134_engine_param);
						  test1177_79 = (n1_242 >= ((long) 1));
					       }
					     else
					       {
						  test1177_79 = ((bool_t) 0);
					       }
					  }
					  if (test1177_79)
					    {
					       obj_t new_80;
					       new_80 = make_one_assert_167_expand_assert(e_16, x_15, vars_42, pred_43);
					       return replace__160_tools_misc(x_15, new_80);
					    }
					  else
					    {
					       return BUNSPEC;
					    }
				       }
				    }
				  else
				    {
				     tag_103_156_45:
				       FAILURE(BFALSE, string1333_expand_assert, x_15);
				    }
			       }
			  }
			else
			  {
			     obj_t car_144_227_61;
			     car_144_227_61 = CAR(cdr_111_186_48);
			     if (list__240___r4_pairs_and_lists_6_3(car_144_227_61))
			       {
				  obj_t pred_363;
				  obj_t vars_362;
				  vars_362 = car_144_227_61;
				  pred_363 = CDR(cdr_111_186_48);
				  pred_43 = pred_363;
				  vars_42 = vars_362;
				  goto tag_102_241_44;
			       }
			     else
			       {
				  goto tag_103_156_45;
			       }
			  }
		     }
		   else
		     {
			obj_t car_157_166_65;
			car_157_166_65 = CAR(cdr_111_186_48);
			if (list__240___r4_pairs_and_lists_6_3(car_157_166_65))
			  {
			     obj_t pred_369;
			     obj_t vars_368;
			     vars_368 = car_157_166_65;
			     pred_369 = CDR(cdr_111_186_48);
			     pred_43 = pred_369;
			     vars_42 = vars_368;
			     goto tag_102_241_44;
			  }
			else
			  {
			     goto tag_103_156_45;
			  }
		     }
		}
	     }
	   else
	     {
		goto tag_103_156_45;
	     }
	}
      else
	{
	   goto tag_103_156_45;
	}
   }
}


/* _expand-assert1332 */ obj_t 
_expand_assert1332_163_expand_assert(obj_t env_286, obj_t x_287, obj_t e_288)
{
   return expand_assert_18_expand_assert(x_287, e_288);
}


/* make-one-assert */ obj_t 
make_one_assert_167_expand_assert(obj_t e_17, obj_t exp_18, obj_t vars_19, obj_t pred_20)
{
   {
      obj_t old_pred_232_82;
      old_pred_232_82 = dup_expand_assert(pred_20);
      {
	 obj_t arg1187_83;
	 obj_t arg1188_84;
	 obj_t arg1190_85;
	 arg1187_83 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t arg1197_92;
	    arg1197_92 = normalize_progn_143_tools_progn(pred_20);
	    arg1188_84 = PROCEDURE_ENTRY(e_17) (e_17, arg1197_92, e_17, BEOA);
	 }
	 {
	    obj_t arg1199_93;
	    obj_t arg1200_94;
	    arg1199_93 = CNST_TABLE_REF(((long) 3));
	    {
	       obj_t arg1203_97;
	       obj_t arg1204_98;
	       {
		  obj_t vars_99;
		  obj_t defs_100;
		  vars_99 = vars_19;
		  defs_100 = BNIL;
		loop_101:
		  if (NULLP(vars_99))
		    {
		       arg1203_97 = defs_100;
		    }
		  else
		    {
		       obj_t arg1207_104;
		       obj_t arg1209_105;
		       arg1207_104 = CDR(vars_99);
		       {
			  obj_t arg1210_106;
			  {
			     obj_t arg1211_107;
			     obj_t arg1213_108;
			     obj_t arg1214_109;
			     arg1211_107 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t arg1222_115;
				obj_t arg1224_116;
				arg1222_115 = CNST_TABLE_REF(((long) 5));
				arg1224_116 = CAR(vars_99);
				{
				   obj_t list1226_118;
				   {
				      obj_t arg1228_119;
				      arg1228_119 = MAKE_PAIR(BNIL, BNIL);
				      list1226_118 = MAKE_PAIR(arg1224_116, arg1228_119);
				   }
				   arg1213_108 = cons__138___r4_pairs_and_lists_6_3(arg1222_115, list1226_118);
				}
			     }
			     {
				obj_t arg1232_121;
				obj_t arg1233_122;
				{
				   obj_t arg1240_127;
				   obj_t arg1241_128;
				   obj_t arg1243_129;
				   arg1240_127 = CNST_TABLE_REF(((long) 6));
				   arg1241_128 = CNST_TABLE_REF(((long) 7));
				   arg1243_129 = CNST_TABLE_REF(((long) 8));
				   {
				      obj_t list1245_131;
				      {
					 obj_t arg1247_132;
					 {
					    obj_t arg1248_133;
					    arg1248_133 = MAKE_PAIR(BNIL, BNIL);
					    arg1247_132 = MAKE_PAIR(arg1243_129, arg1248_133);
					 }
					 list1245_131 = MAKE_PAIR(arg1241_128, arg1247_132);
				      }
				      arg1232_121 = cons__138___r4_pairs_and_lists_6_3(arg1240_127, list1245_131);
				   }
				}
				arg1233_122 = CAR(vars_99);
				{
				   obj_t list1235_124;
				   {
				      obj_t arg1236_125;
				      arg1236_125 = MAKE_PAIR(BNIL, BNIL);
				      list1235_124 = MAKE_PAIR(arg1233_122, arg1236_125);
				   }
				   arg1214_109 = cons__138___r4_pairs_and_lists_6_3(arg1232_121, list1235_124);
				}
			     }
			     {
				obj_t list1217_111;
				{
				   obj_t arg1219_112;
				   {
				      obj_t arg1220_113;
				      arg1220_113 = MAKE_PAIR(BNIL, BNIL);
				      arg1219_112 = MAKE_PAIR(arg1214_109, arg1220_113);
				   }
				   list1217_111 = MAKE_PAIR(arg1213_108, arg1219_112);
				}
				arg1210_106 = cons__138___r4_pairs_and_lists_6_3(arg1211_107, list1217_111);
			     }
			  }
			  arg1209_105 = MAKE_PAIR(arg1210_106, defs_100);
		       }
		       {
			  obj_t defs_404;
			  obj_t vars_403;
			  vars_403 = arg1207_104;
			  defs_404 = arg1209_105;
			  defs_100 = defs_404;
			  vars_99 = vars_403;
			  goto loop_101;
		       }
		    }
	       }
	       {
		  obj_t arg1251_135;
		  obj_t arg1252_136;
		  {
		     obj_t loc_139;
		     {
			obj_t loc_171;
			loc_171 = find_location_120_tools_location(exp_18);
			{
			   bool_t test_406;
			   if (STRUCTP(loc_171))
			     {
				obj_t aux_411;
				obj_t aux_409;
				aux_411 = CNST_TABLE_REF(((long) 9));
				aux_409 = STRUCT_KEY(loc_171);
				test_406 = (aux_409 == aux_411);
			     }
			   else
			     {
				test_406 = ((bool_t) 0);
			     }
			   if (test_406)
			     {
				loc_139 = loc_171;
			     }
			   else
			     {
				loc_139 = find_location_120_tools_location(pred_20);
			     }
			}
		     }
		     {
			obj_t arg1255_140;
			obj_t arg1256_141;
			obj_t arg1257_142;
			obj_t arg1258_143;
			arg1255_140 = CNST_TABLE_REF(((long) 10));
			{
			   obj_t arg1268_150;
			   arg1268_150 = CNST_TABLE_REF(((long) 5));
			   {
			      obj_t list1270_152;
			      {
				 obj_t arg1272_153;
				 arg1272_153 = MAKE_PAIR(BNIL, BNIL);
				 list1270_152 = MAKE_PAIR(vars_19, arg1272_153);
			      }
			      arg1256_141 = cons__138___r4_pairs_and_lists_6_3(arg1268_150, list1270_152);
			   }
			}
			{
			   obj_t arg1274_155;
			   obj_t arg1277_156;
			   arg1274_155 = CNST_TABLE_REF(((long) 5));
			   {
			      obj_t aux_421;
			      aux_421 = CNST_TABLE_REF(((long) 3));
			      arg1277_156 = MAKE_PAIR(aux_421, old_pred_232_82);
			   }
			   {
			      obj_t list1279_158;
			      {
				 obj_t arg1281_159;
				 arg1281_159 = MAKE_PAIR(BNIL, BNIL);
				 list1279_158 = MAKE_PAIR(arg1277_156, arg1281_159);
			      }
			      arg1257_142 = cons__138___r4_pairs_and_lists_6_3(arg1274_155, list1279_158);
			   }
			}
			{
			   bool_t test_427;
			   if (STRUCTP(loc_139))
			     {
				obj_t aux_432;
				obj_t aux_430;
				aux_432 = CNST_TABLE_REF(((long) 9));
				aux_430 = STRUCT_KEY(loc_139);
				test_427 = (aux_430 == aux_432);
			     }
			   else
			     {
				test_427 = ((bool_t) 0);
			     }
			   if (test_427)
			     {
				obj_t arg1285_163;
				obj_t arg1286_164;
				arg1285_163 = CNST_TABLE_REF(((long) 5));
				{
				   obj_t arg1292_169;
				   obj_t arg1294_170;
				   arg1292_169 = location_full_fname_231_tools_location(loc_139);
				   arg1294_170 = STRUCT_REF(loc_139, ((long) 1));
				   arg1286_164 = MAKE_PAIR(arg1292_169, arg1294_170);
				}
				{
				   obj_t list1288_166;
				   {
				      obj_t arg1290_167;
				      arg1290_167 = MAKE_PAIR(BNIL, BNIL);
				      list1288_166 = MAKE_PAIR(arg1286_164, arg1290_167);
				   }
				   arg1258_143 = cons__138___r4_pairs_and_lists_6_3(arg1285_163, list1288_166);
				}
			     }
			   else
			     {
				arg1258_143 = BFALSE;
			     }
			}
			{
			   obj_t list1260_145;
			   {
			      obj_t arg1262_146;
			      {
				 obj_t arg1263_147;
				 {
				    obj_t arg1265_148;
				    arg1265_148 = MAKE_PAIR(BNIL, BNIL);
				    arg1263_147 = MAKE_PAIR(arg1258_143, arg1265_148);
				 }
				 arg1262_146 = MAKE_PAIR(arg1257_142, arg1263_147);
			      }
			      list1260_145 = MAKE_PAIR(arg1256_141, arg1262_146);
			   }
			   arg1251_135 = cons__138___r4_pairs_and_lists_6_3(arg1255_140, list1260_145);
			}
		     }
		  }
		  {
		     obj_t arg1296_173;
		     obj_t arg1297_174;
		     {
			obj_t vars_175;
			obj_t defs_176;
			vars_175 = vars_19;
			defs_176 = BNIL;
		      loop_177:
			if (NULLP(vars_175))
			  {
			     arg1296_173 = defs_176;
			  }
			else
			  {
			     obj_t arg1300_180;
			     obj_t arg1301_181;
			     arg1300_180 = CDR(vars_175);
			     {
				obj_t arg1302_182;
				{
				   obj_t arg1303_183;
				   obj_t arg1304_184;
				   arg1303_183 = CNST_TABLE_REF(((long) 11));
				   {
				      obj_t arg1311_189;
				      obj_t arg1313_190;
				      arg1311_189 = CNST_TABLE_REF(((long) 5));
				      arg1313_190 = CAR(vars_175);
				      {
					 obj_t list1316_192;
					 {
					    obj_t arg1319_193;
					    arg1319_193 = MAKE_PAIR(BNIL, BNIL);
					    list1316_192 = MAKE_PAIR(arg1313_190, arg1319_193);
					 }
					 arg1304_184 = cons__138___r4_pairs_and_lists_6_3(arg1311_189, list1316_192);
				      }
				   }
				   {
				      obj_t list1308_186;
				      {
					 obj_t arg1309_187;
					 arg1309_187 = MAKE_PAIR(BNIL, BNIL);
					 list1308_186 = MAKE_PAIR(arg1304_184, arg1309_187);
				      }
				      arg1302_182 = cons__138___r4_pairs_and_lists_6_3(arg1303_183, list1308_186);
				   }
				}
				arg1301_181 = MAKE_PAIR(arg1302_182, defs_176);
			     }
			     {
				obj_t defs_461;
				obj_t vars_460;
				vars_460 = arg1300_180;
				defs_461 = arg1301_181;
				defs_176 = defs_461;
				vars_175 = vars_460;
				goto loop_177;
			     }
			  }
		     }
		     arg1297_174 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		     arg1252_136 = append_2_18___r4_pairs_and_lists_6_3(arg1296_173, arg1297_174);
		  }
		  {
		     obj_t list1253_137;
		     list1253_137 = MAKE_PAIR(arg1252_136, BNIL);
		     arg1204_98 = cons__138___r4_pairs_and_lists_6_3(arg1251_135, list1253_137);
		  }
	       }
	       arg1200_94 = append_2_18___r4_pairs_and_lists_6_3(arg1203_97, arg1204_98);
	    }
	    {
	       obj_t list1201_95;
	       list1201_95 = MAKE_PAIR(arg1200_94, BNIL);
	       arg1190_85 = cons__138___r4_pairs_and_lists_6_3(arg1199_93, list1201_95);
	    }
	 }
	 {
	    obj_t list1192_87;
	    {
	       obj_t arg1193_88;
	       {
		  obj_t arg1194_89;
		  {
		     obj_t arg1195_90;
		     arg1195_90 = MAKE_PAIR(BNIL, BNIL);
		     arg1194_89 = MAKE_PAIR(arg1190_85, arg1195_90);
		  }
		  arg1193_88 = MAKE_PAIR(BUNSPEC, arg1194_89);
	       }
	       list1192_87 = MAKE_PAIR(arg1188_84, arg1193_88);
	    }
	    return cons__138___r4_pairs_and_lists_6_3(arg1187_83, list1192_87);
	 }
      }
   }
}


/* dup */ obj_t 
dup_expand_assert(obj_t pred_21)
{
   if (PAIRP(pred_21))
     {
	{
	   obj_t arg1325_198;
	   obj_t arg1326_199;
	   arg1325_198 = dup_expand_assert(CAR(pred_21));
	   arg1326_199 = dup_expand_assert(CDR(pred_21));
	   return MAKE_PAIR(arg1325_198, arg1326_199);
	}
     }
   else
     {
	return pred_21;
     }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_assert()
{
   module_initialization_70_engine_param(((long) 0), "EXPAND_ASSERT");
   module_initialization_70_tools_misc(((long) 0), "EXPAND_ASSERT");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_ASSERT");
   return module_initialization_70_tools_location(((long) 0), "EXPAND_ASSERT");
}
