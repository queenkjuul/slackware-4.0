/*===========================================================================*/
/*   (Init/setrc.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t string_append(obj_t, obj_t);
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t module_initialization_70_init_setrc(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
static obj_t imported_modules_init_94_init_setrc();
static obj_t library_modules_init_112_init_setrc();
static obj_t _setup_library_values1003_201_init_setrc(obj_t, obj_t);
static obj_t _setup_default_values_76_init_setrc(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t _lib_dir__34_engine_param;
extern obj_t loadq___eval(obj_t);
extern obj_t setup_library_values_14_init_setrc(obj_t);
extern obj_t setup_default_values_46_init_setrc();
static obj_t require_initialization_114_init_setrc = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(setup_default_values_env_28_init_setrc, _setup_default_values_76_init_setrc1007, _setup_default_values_76_init_setrc, 0L, 0);
DEFINE_STRING(string1005_init_setrc, string1005_init_setrc1008, ".init", 5);
DEFINE_STRING(string1004_init_setrc, string1004_init_setrc1009, ".bigloorc", 9);
DEFINE_EXPORT_PROCEDURE(setup_library_values_env_225_init_setrc, _setup_library_values1003_201_init_setrc1010, _setup_library_values1003_201_init_setrc, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_init_setrc(long checksum_16, char *from_17)
{
   if (CBOOL(require_initialization_114_init_setrc))
     {
	require_initialization_114_init_setrc = BBOOL(((bool_t) 0));
	library_modules_init_112_init_setrc();
	imported_modules_init_94_init_setrc();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_init_setrc()
{
   module_initialization_70___eval(((long) 0), "INIT_SETRC");
   return BUNSPEC;
}


/* setup-default-values */ obj_t 
setup_default_values_46_init_setrc()
{
   {
      obj_t path_2;
      {
	 obj_t home_4;
	 {
	    bool_t test1190_9;
	    test1190_9 = (long) getenv("HOME");
	    if (test1190_9)
	      {
		 char *aux_26;
		 aux_26 = (char *) getenv("HOME");
		 home_4 = string_to_bstring(aux_26);
	      }
	    else
	      {
		 home_4 = BFALSE;
	      }
	 }
	 if (STRINGP(home_4))
	   {
	      obj_t obj2_12;
	      obj2_12 = _lib_dir__34_engine_param;
	      path_2 = MAKE_PAIR(home_4, obj2_12);
	   }
	 else
	   {
	      path_2 = _lib_dir__34_engine_param;
	   }
      }
      {
	 obj_t fname_3;
	 fname_3 = find_file_path_55_tools_file(string1004_init_setrc, path_2);
	 {
	    if (CBOOL(fname_3))
	      {
		 return loadq___eval(fname_3);
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* _setup-default-values */ obj_t 
_setup_default_values_76_init_setrc(obj_t env_13)
{
   return setup_default_values_46_init_setrc();
}


/* setup-library-values */ obj_t 
setup_library_values_14_init_setrc(obj_t library_1)
{
   {
      obj_t init_name_142_6;
      init_name_142_6 = string_append(library_1, string1005_init_setrc);
      {
	 obj_t fname_7;
	 fname_7 = find_file_path_55_tools_file(init_name_142_6, _lib_dir__34_engine_param);
	 {
	    if (CBOOL(fname_7))
	      {
		 return loadq___eval(fname_7);
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* _setup-library-values1003 */ obj_t 
_setup_library_values1003_201_init_setrc(obj_t env_14, obj_t library_15)
{
   return setup_library_values_14_init_setrc(library_15);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_init_setrc()
{
   module_initialization_70_engine_param(((long) 0), "INIT_SETRC");
   return module_initialization_70_tools_file(((long) 0), "INIT_SETRC");
}
