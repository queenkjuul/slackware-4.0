/*===========================================================================*/
/*   (Match/s2cfun.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern char * number__string_214___r4_numbers_6_5(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t symbol1274___match_s2cfun = BUNSPEC;
static obj_t symbol1273___match_s2cfun = BUNSPEC;
static obj_t toplevel_init_63___match_s2cfun();
static obj_t _ormap___match_s2cfun(obj_t, obj_t, obj_t);
static obj_t _atom__186___match_s2cfun(obj_t, obj_t);
extern obj_t ormap___match_s2cfun(obj_t, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t atom__231___match_s2cfun(obj_t);
extern obj_t concat___match_s2cfun(obj_t);
extern obj_t andmap___match_s2cfun(obj_t, obj_t);
static obj_t lambda1042___match_s2cfun(obj_t, obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t module_initialization_70___match_s2cfun(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _concat___match_s2cfun(obj_t, obj_t);
static obj_t _andmap___match_s2cfun(obj_t, obj_t, obj_t);
obj_t jim_gensym_58___match_s2cfun = BUNSPEC;
extern long list_length(obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
static obj_t imported_modules_init_94___match_s2cfun();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t require_initialization_114___match_s2cfun = BUNSPEC;
static obj_t cnst_init_137___match_s2cfun();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( ormap_env_127___match_s2cfun, _ormap___match_s2cfun1277, va_generic_entry, _ormap___match_s2cfun, -2 );
DEFINE_EXPORT_PROCEDURE( concat_env_140___match_s2cfun, _concat___match_s2cfun1278, va_generic_entry, _concat___match_s2cfun, -1 );
DEFINE_EXPORT_PROCEDURE( atom__env_198___match_s2cfun, _atom__186___match_s2cfun1279, _atom__186___match_s2cfun, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( andmap_env_165___match_s2cfun, _andmap___match_s2cfun1280, va_generic_entry, _andmap___match_s2cfun, -2 );
DEFINE_STRING( string1275___match_s2cfun, string1275___match_s2cfun1281, "", 0 );


/* module-initialization */obj_t module_initialization_70___match_s2cfun(long checksum_956, char * from_957)
{
if(CBOOL(require_initialization_114___match_s2cfun)){
require_initialization_114___match_s2cfun = BBOOL(((bool_t)0));
cnst_init_137___match_s2cfun();
imported_modules_init_94___match_s2cfun();
toplevel_init_63___match_s2cfun();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___match_s2cfun()
{
symbol1273___match_s2cfun = string_to_symbol("G");
return (symbol1274___match_s2cfun = string_to_symbol("CONCAT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___match_s2cfun()
{
{
obj_t counter_322;
{
obj_t cellval_966;
cellval_966 = BINT(((long)100));
counter_322 = MAKE_CELL(cellval_966);
}
{
obj_t lambda1042_941;
lambda1042_941 = make_va_procedure(lambda1042___match_s2cfun, ((long)-1), ((long)1));
PROCEDURE_SET(lambda1042_941, ((long)0), counter_322);
return (jim_gensym_58___match_s2cfun = lambda1042_941,
BUNSPEC);
}
}
}


/* lambda1042 */obj_t lambda1042___match_s2cfun(obj_t env_942, obj_t args_944)
{
{
obj_t counter_943;
counter_943 = PROCEDURE_REF(env_942, ((long)0));
{
obj_t args_323;
args_323 = args_944;
{
obj_t aux_945;
aux_945 = _2__168___r4_numbers_6_5(CELL_REF(counter_943), BINT(((long)1)));
CELL_SET(counter_943, aux_945);
}
{
obj_t arg1043_325;
if(PAIRP(args_323)){
arg1043_325 = CAR(args_323);
}
 else {
arg1043_325 = symbol1273___match_s2cfun;
}
{
obj_t list1044_326;
{
obj_t arg1045_327;
{
obj_t aux_976;
aux_976 = CELL_REF(counter_943);
arg1045_327 = MAKE_PAIR(aux_976, BNIL);
}
list1044_326 = MAKE_PAIR(arg1043_325, arg1045_327);
}
return concat___match_s2cfun(list1044_326);
}
}
}
}
}


/* atom? */obj_t atom__231___match_s2cfun(obj_t e_1)
{
if(PAIRP(e_1)){
return BFALSE;
}
 else {
return BTRUE;
}
}


/* _atom? */obj_t _atom__186___match_s2cfun(obj_t env_946, obj_t e_947)
{
return atom__231___match_s2cfun(e_947);
}


/* concat */obj_t concat___match_s2cfun(obj_t args_2)
{
{
obj_t arg1049_331;
{
obj_t runner1064_352;
if(NULLP(args_2)){
runner1064_352 = BNIL;
}
 else {
obj_t head1004_334;
head1004_334 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_335;
obj_t tail1005_336;
l1002_335 = args_2;
tail1005_336 = head1004_334;
lname1003_337:
if(NULLP(l1002_335)){
runner1064_352 = CDR(head1004_334);
}
 else {
obj_t newtail1006_339;
{
obj_t arg1054_341;
{
obj_t s_343;
s_343 = CAR(l1002_335);
if(STRINGP(s_343)){
arg1054_341 = s_343;
}
 else {
if(SYMBOLP(s_343)){
arg1054_341 = SYMBOL_TO_STRING(s_343);
}
 else {
bool_t test_995;
if(INTEGERP(s_343)){
test_995 = ((bool_t)1);
}
 else {
test_995 = REALP(s_343);
}
if(test_995){
{
char * aux_999;
aux_999 = number__string_214___r4_numbers_6_5(s_343, BNIL);
arg1054_341 = string_to_bstring(aux_999);
}
}
 else {
FAILURE(symbol1274___match_s2cfun,string1275___match_s2cfun,args_2);}
}
}
}
newtail1006_339 = MAKE_PAIR(arg1054_341, BNIL);
}
SET_CDR(tail1005_336, newtail1006_339);
{
obj_t tail1005_1007;
obj_t l1002_1005;
l1002_1005 = CDR(l1002_335);
tail1005_1007 = newtail1006_339;
tail1005_336 = tail1005_1007;
l1002_335 = l1002_1005;
goto lname1003_337;
}
}
}
}
arg1049_331 = string_append_106___r4_strings_6_7(runner1064_352);
}
{
char * aux_1009;
aux_1009 = BSTRING_TO_STRING(arg1049_331);
return string_to_symbol(aux_1009);
}
}
}


/* _concat */obj_t _concat___match_s2cfun(obj_t env_948, obj_t args_949)
{
return concat___match_s2cfun(args_949);
}


/* andmap */obj_t andmap___match_s2cfun(obj_t p_3, obj_t args_4)
{
{
obj_t args_353;
obj_t value_354;
args_353 = args_4;
value_354 = BTRUE;
andmap_355:
{
bool_t test_1013;
{
obj_t ls_392;
ls_392 = args_353;
any_at_end__212_393:
if(PAIRP(ls_392)){
bool_t _ortest_1008_395;
{
bool_t test_1016;
{
obj_t aux_1017;
aux_1017 = CAR(ls_392);
test_1016 = PAIRP(aux_1017);
}
if(test_1016){
_ortest_1008_395 = ((bool_t)0);
}
 else {
_ortest_1008_395 = ((bool_t)1);
}
}
if(_ortest_1008_395){
test_1013 = _ortest_1008_395;
}
 else {
obj_t ls_1021;
ls_1021 = CDR(ls_392);
ls_392 = ls_1021;
goto any_at_end__212_393;
}
}
 else {
test_1013 = ((bool_t)0);
}
}
if(test_1013){
return value_354;
}
 else {
obj_t value_357;
{
obj_t aux_1023;
if(NULLP(args_353)){
aux_1023 = BNIL;
}
 else {
obj_t head1011_378;
{
obj_t aux_1026;
{
obj_t aux_1027;
aux_1027 = CAR(args_353);
aux_1026 = CAR(aux_1027);
}
head1011_378 = MAKE_PAIR(aux_1026, BNIL);
}
{
obj_t l1009_645;
obj_t tail1012_646;
l1009_645 = CDR(args_353);
tail1012_646 = head1011_378;
lname1010_644:
if(NULLP(l1009_645)){
aux_1023 = head1011_378;
}
 else {
obj_t newtail1013_654;
{
obj_t aux_1033;
{
obj_t aux_1034;
aux_1034 = CAR(l1009_645);
aux_1033 = CAR(aux_1034);
}
newtail1013_654 = MAKE_PAIR(aux_1033, BNIL);
}
SET_CDR(tail1012_646, newtail1013_654);
{
obj_t tail1012_1041;
obj_t l1009_1039;
l1009_1039 = CDR(l1009_645);
tail1012_1041 = newtail1013_654;
tail1012_646 = tail1012_1041;
l1009_645 = l1009_1039;
goto lname1010_644;
}
}
}
}
value_357 = apply(p_3, aux_1023);
}
if(CBOOL(value_357)){
obj_t arg1066_359;
if(NULLP(args_353)){
arg1066_359 = BNIL;
}
 else {
obj_t head1017_362;
{
obj_t aux_1048;
{
obj_t aux_1049;
aux_1049 = CAR(args_353);
aux_1048 = CDR(aux_1049);
}
head1017_362 = MAKE_PAIR(aux_1048, BNIL);
}
{
obj_t l1015_704;
obj_t tail1018_705;
l1015_704 = CDR(args_353);
tail1018_705 = head1017_362;
lname1016_703:
if(NULLP(l1015_704)){
arg1066_359 = head1017_362;
}
 else {
obj_t newtail1019_713;
{
obj_t aux_1055;
{
obj_t aux_1056;
aux_1056 = CAR(l1015_704);
aux_1055 = CDR(aux_1056);
}
newtail1019_713 = MAKE_PAIR(aux_1055, BNIL);
}
SET_CDR(tail1018_705, newtail1019_713);
{
obj_t tail1018_1063;
obj_t l1015_1061;
l1015_1061 = CDR(l1015_704);
tail1018_1063 = newtail1019_713;
tail1018_705 = tail1018_1063;
l1015_704 = l1015_1061;
goto lname1016_703;
}
}
}
}
{
obj_t value_1066;
obj_t args_1065;
args_1065 = arg1066_359;
value_1066 = value_357;
value_354 = value_1066;
args_353 = args_1065;
goto andmap_355;
}
}
 else {
return BFALSE;
}
}
}
}
}


/* _andmap */obj_t _andmap___match_s2cfun(obj_t env_950, obj_t p_951, obj_t args_952)
{
return andmap___match_s2cfun(p_951, args_952);
}


/* ormap */obj_t ormap___match_s2cfun(obj_t p_5, obj_t args_6)
{
{
bool_t test_1068;
{
obj_t aux_1069;
{
long aux_1070;
aux_1070 = list_length(args_6);
aux_1069 = BINT(aux_1070);
}
test_1068 = _2__95___r4_numbers_6_5(aux_1069, BINT(((long)1)));
}
if(test_1068){
obj_t arg1094_400;
{
obj_t l1020_401;
l1020_401 = CAR(args_6);
if(NULLP(l1020_401)){
arg1094_400 = BNIL;
}
 else {
obj_t head1022_403;
{
obj_t arg1102_414;
arg1102_414 = PROCEDURE_ENTRY(p_5)(p_5, CAR(l1020_401), BEOA);
head1022_403 = MAKE_PAIR(arg1102_414, BNIL);
}
{
obj_t l1020_763;
obj_t tail1023_764;
l1020_763 = CDR(l1020_401);
tail1023_764 = head1022_403;
lname1021_762:
if(NULLP(l1020_763)){
arg1094_400 = head1022_403;
}
 else {
obj_t newtail1024_772;
{
obj_t arg1099_773;
arg1099_773 = PROCEDURE_ENTRY(p_5)(p_5, CAR(l1020_763), BEOA);
newtail1024_772 = MAKE_PAIR(arg1099_773, BNIL);
}
SET_CDR(tail1023_764, newtail1024_772);
{
obj_t tail1023_1091;
obj_t l1020_1089;
l1020_1089 = CDR(l1020_763);
tail1023_1091 = newtail1024_772;
tail1023_764 = tail1023_1091;
l1020_763 = l1020_1089;
goto lname1021_762;
}
}
}
}
}
return member___r4_pairs_and_lists_6_3(BTRUE, arg1094_400);
}
 else {
obj_t args_417;
obj_t value_418;
args_417 = args_6;
value_418 = BFALSE;
ormap_419:
{
bool_t test_1094;
{
obj_t ls_456;
ls_456 = args_417;
any_at_end__212_457:
if(PAIRP(ls_456)){
bool_t _ortest_1026_459;
{
bool_t test_1097;
{
obj_t aux_1098;
aux_1098 = CAR(ls_456);
test_1097 = PAIRP(aux_1098);
}
if(test_1097){
_ortest_1026_459 = ((bool_t)0);
}
 else {
_ortest_1026_459 = ((bool_t)1);
}
}
if(_ortest_1026_459){
test_1094 = _ortest_1026_459;
}
 else {
obj_t ls_1102;
ls_1102 = CDR(ls_456);
ls_456 = ls_1102;
goto any_at_end__212_457;
}
}
 else {
test_1094 = ((bool_t)0);
}
}
if(test_1094){
return value_418;
}
 else {
obj_t value_421;
{
obj_t aux_1104;
if(NULLP(args_417)){
aux_1104 = BNIL;
}
 else {
obj_t head1029_442;
{
obj_t aux_1107;
{
obj_t aux_1108;
aux_1108 = CAR(args_417);
aux_1107 = CAR(aux_1108);
}
head1029_442 = MAKE_PAIR(aux_1107, BNIL);
}
{
obj_t l1027_823;
obj_t tail1030_824;
l1027_823 = CDR(args_417);
tail1030_824 = head1029_442;
lname1028_822:
if(NULLP(l1027_823)){
aux_1104 = head1029_442;
}
 else {
obj_t newtail1031_832;
{
obj_t aux_1114;
{
obj_t aux_1115;
aux_1115 = CAR(l1027_823);
aux_1114 = CAR(aux_1115);
}
newtail1031_832 = MAKE_PAIR(aux_1114, BNIL);
}
SET_CDR(tail1030_824, newtail1031_832);
{
obj_t tail1030_1122;
obj_t l1027_1120;
l1027_1120 = CDR(l1027_823);
tail1030_1122 = newtail1031_832;
tail1030_824 = tail1030_1122;
l1027_823 = l1027_1120;
goto lname1028_822;
}
}
}
}
value_421 = apply(p_5, aux_1104);
}
if(CBOOL(value_421)){
return value_421;
}
 else {
obj_t arg1106_423;
if(NULLP(args_417)){
arg1106_423 = BNIL;
}
 else {
obj_t head1035_426;
{
obj_t aux_1129;
{
obj_t aux_1130;
aux_1130 = CAR(args_417);
aux_1129 = CDR(aux_1130);
}
head1035_426 = MAKE_PAIR(aux_1129, BNIL);
}
{
obj_t l1033_882;
obj_t tail1036_883;
l1033_882 = CDR(args_417);
tail1036_883 = head1035_426;
lname1034_881:
if(NULLP(l1033_882)){
arg1106_423 = head1035_426;
}
 else {
obj_t newtail1037_891;
{
obj_t aux_1136;
{
obj_t aux_1137;
aux_1137 = CAR(l1033_882);
aux_1136 = CDR(aux_1137);
}
newtail1037_891 = MAKE_PAIR(aux_1136, BNIL);
}
SET_CDR(tail1036_883, newtail1037_891);
{
obj_t tail1036_1144;
obj_t l1033_1142;
l1033_1142 = CDR(l1033_882);
tail1036_1144 = newtail1037_891;
tail1036_883 = tail1036_1144;
l1033_882 = l1033_1142;
goto lname1034_881;
}
}
}
}
{
obj_t value_1147;
obj_t args_1146;
args_1146 = arg1106_423;
value_1147 = value_421;
value_418 = value_1147;
args_417 = args_1146;
goto ormap_419;
}
}
}
}
}
}
}


/* _ormap */obj_t _ormap___match_s2cfun(obj_t env_953, obj_t p_954, obj_t args_955)
{
return ormap___match_s2cfun(p_954, args_955);
}


/* imported-modules-init */obj_t imported_modules_init_94___match_s2cfun()
{
return module_initialization_70___error(((long)0), "__MATCH_S2CFUN");
}

