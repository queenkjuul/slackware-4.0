/*===========================================================================*/
/*   (Eval/expd-define.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t symbol1476___expander_define = BUNSPEC;
static obj_t symbol1475___expander_define = BUNSPEC;
static obj_t symbol1473___expander_define = BUNSPEC;
static obj_t symbol1472___expander_define = BUNSPEC;
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t expand_eval_external_define_170___expander_define(obj_t, obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
static obj_t toplevel_init_63___expander_define();
extern obj_t replace__160___progn(obj_t, obj_t);
extern obj_t expand_eval_define_inline_157___expander_define(obj_t, obj_t);
extern obj_t parse_formal_ident_54___expand(obj_t);
extern obj_t expand_eval_lambda_55___expander_define(obj_t, obj_t);
extern obj_t expand_eval_define_165___expander_define(obj_t, obj_t);
static obj_t _expand_eval_define_inline_59___expander_define(obj_t, obj_t, obj_t);
static obj_t _expand_eval_lambda_20___expander_define(obj_t, obj_t, obj_t);
static obj_t _expand_eval_define_192___expander_define(obj_t, obj_t, obj_t);
static obj_t lambda_defines_105___expander_define(obj_t);
static obj_t expand_eval_internal_define_207___expander_define(obj_t, obj_t);
static obj_t lambda1132___expander_define(obj_t, obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t module_initialization_70___expander_define(long, char *);
extern obj_t module_initialization_70___expand(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
static obj_t internal_begin_expander_196___expander_define(obj_t);
extern long list_length(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_define();
static obj_t require_initialization_114___expander_define = BUNSPEC;
extern obj_t normalize_progn_143___progn(obj_t);
static obj_t cnst_init_137___expander_define();
static bool_t internal_definition__7___expander_define;
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_eval_define_inline_env_24___expander_define, _expand_eval_define_inline_59___expander_define1479, _expand_eval_define_inline_59___expander_define, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( expand_eval_lambda_env_231___expander_define, _expand_eval_lambda_20___expander_define1480, _expand_eval_lambda_20___expander_define, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( expand_eval_define_env_35___expander_define, _expand_eval_define_192___expander_define1481, _expand_eval_define_192___expander_define, 0L, 2 );
DEFINE_STRING( string1477___expander_define, string1477___expander_define1482, "define-inline", 13 );
DEFINE_STRING( string1474___expander_define, string1474___expander_define1483, "define", 6 );
DEFINE_STRING( string1471___expander_define, string1471___expander_define1484, "Illegal form", 12 );
DEFINE_STRING( string1470___expander_define, string1470___expander_define1485, "lambda", 6 );


/* module-initialization */obj_t module_initialization_70___expander_define(long checksum_1155, char * from_1156)
{
if(CBOOL(require_initialization_114___expander_define)){
require_initialization_114___expander_define = BBOOL(((bool_t)0));
cnst_init_137___expander_define();
imported_modules_init_94___expander_define();
toplevel_init_63___expander_define();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_define()
{
symbol1472___expander_define = string_to_symbol("LAMBDA");
symbol1473___expander_define = string_to_symbol("DEFINE");
symbol1475___expander_define = string_to_symbol("BEGIN");
return (symbol1476___expander_define = string_to_symbol("SET!"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___expander_define()
{
return (internal_definition__7___expander_define = ((bool_t)0),
BUNSPEC);
}


/* expand-eval-lambda */obj_t expand_eval_lambda_55___expander_define(obj_t x_1, obj_t e_2)
{
{
bool_t old_internal_68_328;
old_internal_68_328 = internal_definition__7___expander_define;
internal_definition__7___expander_define = ((bool_t)1);
{
obj_t res_329;
if(PAIRP(x_1)){
obj_t cdr_109_69_336;
cdr_109_69_336 = CDR(x_1);
if(PAIRP(cdr_109_69_336)){
obj_t cdr_113_28_338;
cdr_113_28_338 = CDR(cdr_109_69_336);
if((cdr_113_28_338==BNIL)){
FAILURE(string1470___expander_define,string1471___expander_define,x_1);}
 else {
obj_t arg1014_340;
arg1014_340 = CAR(cdr_109_69_336);
{
obj_t e_829;
e_829 = internal_begin_expander_196___expander_define(e_2);
{
obj_t arg1016_830;
obj_t arg1017_831;
arg1016_830 = symbol1472___expander_define;
{
obj_t arg1023_833;
arg1023_833 = normalize_progn_143___progn(cdr_113_28_338);
arg1017_831 = PROCEDURE_ENTRY(e_829)(e_829, arg1023_833, e_829, BEOA);
}
{
obj_t list1019_834;
{
obj_t arg1020_835;
{
obj_t arg1021_836;
arg1021_836 = MAKE_PAIR(BNIL, BNIL);
arg1020_835 = MAKE_PAIR(arg1017_831, arg1021_836);
}
list1019_834 = MAKE_PAIR(arg1014_340, arg1020_835);
}
res_329 = cons__138___r4_pairs_and_lists_6_3(arg1016_830, list1019_834);
}
}
}
}
}
 else {
FAILURE(string1470___expander_define,string1471___expander_define,x_1);}
}
 else {
FAILURE(string1470___expander_define,string1471___expander_define,x_1);}
internal_definition__7___expander_define = old_internal_68_328;
return replace__160___progn(x_1, res_329);
}
}
}


/* _expand-eval-lambda */obj_t _expand_eval_lambda_20___expander_define(obj_t env_1141, obj_t x_1142, obj_t e_1143)
{
return expand_eval_lambda_55___expander_define(x_1142, e_1143);
}


/* expand-eval-define */obj_t expand_eval_define_165___expander_define(obj_t x_3, obj_t e_4)
{
if(internal_definition__7___expander_define){
return expand_eval_internal_define_207___expander_define(x_3, e_4);
}
 else {
return expand_eval_external_define_170___expander_define(x_3, e_4);
}
}


/* _expand-eval-define */obj_t _expand_eval_define_192___expander_define(obj_t env_1144, obj_t x_1145, obj_t e_1146)
{
return expand_eval_define_165___expander_define(x_1145, e_1146);
}


/* expand-eval-internal-define */obj_t expand_eval_internal_define_207___expander_define(obj_t x_5, obj_t e_6)
{
{
obj_t name_355;
obj_t value_356;
obj_t name_351;
obj_t args_352;
obj_t body_353;
if(PAIRP(x_5)){
obj_t cdr_133_55_361;
cdr_133_55_361 = CDR(x_5);
if(PAIRP(cdr_133_55_361)){
obj_t car_137_155_363;
obj_t cdr_138_77_364;
car_137_155_363 = CAR(cdr_133_55_361);
cdr_138_77_364 = CDR(cdr_133_55_361);
if(PAIRP(car_137_155_363)){
if((cdr_138_77_364==BNIL)){
obj_t cdr_156_22_368;
cdr_156_22_368 = CDR(cdr_133_55_361);
if(PAIRP(cdr_156_22_368)){
obj_t car_160_190_370;
car_160_190_370 = CAR(cdr_156_22_368);
if(PAIRP(car_160_190_370)){
obj_t cdr_165_174_372;
cdr_165_174_372 = CDR(car_160_190_370);
{
bool_t test_1211;
{
obj_t aux_1212;
aux_1212 = CAR(car_160_190_370);
test_1211 = (aux_1212==symbol1472___expander_define);
}
if(test_1211){
if(PAIRP(cdr_165_174_372)){
obj_t cdr_169_170_375;
cdr_169_170_375 = CDR(cdr_165_174_372);
if((cdr_169_170_375==BNIL)){
obj_t cdr_182_91_378;
cdr_182_91_378 = CDR(cdr_133_55_361);
{
bool_t test_1221;
{
obj_t aux_1222;
aux_1222 = CDR(cdr_182_91_378);
test_1221 = (aux_1222==BNIL);
}
if(test_1221){
name_355 = CAR(cdr_133_55_361);
value_356 = CAR(cdr_182_91_378);
tag_118_180_357:
{
obj_t res_488;
{
obj_t arg1123_489;
obj_t arg1124_490;
obj_t arg1125_491;
arg1123_489 = symbol1473___expander_define;
{
obj_t arg1131_497;
arg1131_497 = parse_formal_ident_54___expand(name_355);
arg1124_490 = CAR(arg1131_497);
}
arg1125_491 = PROCEDURE_ENTRY(e_6)(e_6, value_356, e_6, BEOA);
{
obj_t list1127_493;
{
obj_t arg1128_494;
{
obj_t arg1129_495;
arg1129_495 = MAKE_PAIR(BNIL, BNIL);
arg1128_494 = MAKE_PAIR(arg1125_491, arg1129_495);
}
list1127_493 = MAKE_PAIR(arg1124_490, arg1128_494);
}
res_488 = cons__138___r4_pairs_and_lists_6_3(arg1123_489, list1127_493);
}
}
return replace__160___progn(x_5, res_488);
}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
 else {
bool_t test_1237;
{
obj_t aux_1238;
aux_1238 = CDR(cdr_156_22_368);
test_1237 = (aux_1238==BNIL);
}
if(test_1237){
name_351 = CAR(cdr_133_55_361);
args_352 = CAR(cdr_165_174_372);
body_353 = cdr_169_170_375;
tag_117_96_354:
{
obj_t res_470;
{
obj_t arg1106_471;
obj_t arg1107_472;
obj_t arg1108_473;
arg1106_471 = symbol1473___expander_define;
{
obj_t arg1114_479;
arg1114_479 = parse_formal_ident_54___expand(name_351);
arg1107_472 = CAR(arg1114_479);
}
{
obj_t arg1115_480;
obj_t arg1116_481;
arg1115_480 = symbol1472___expander_define;
{
obj_t arg1122_487;
arg1122_487 = normalize_progn_143___progn(body_353);
arg1116_481 = PROCEDURE_ENTRY(e_6)(e_6, arg1122_487, e_6, BEOA);
}
{
obj_t list1118_483;
{
obj_t arg1119_484;
{
obj_t arg1120_485;
arg1120_485 = MAKE_PAIR(BNIL, BNIL);
arg1119_484 = MAKE_PAIR(arg1116_481, arg1120_485);
}
list1118_483 = MAKE_PAIR(args_352, arg1119_484);
}
arg1108_473 = cons__138___r4_pairs_and_lists_6_3(arg1115_480, list1118_483);
}
}
{
obj_t list1110_475;
{
obj_t arg1111_476;
{
obj_t arg1112_477;
arg1112_477 = MAKE_PAIR(BNIL, BNIL);
arg1111_476 = MAKE_PAIR(arg1108_473, arg1112_477);
}
list1110_475 = MAKE_PAIR(arg1107_472, arg1111_476);
}
res_470 = cons__138___r4_pairs_and_lists_6_3(arg1106_471, list1110_475);
}
}
return replace__160___progn(x_5, res_470);
}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
 else {
obj_t cdr_201_92_391;
cdr_201_92_391 = CDR(cdr_133_55_361);
{
bool_t test_1259;
{
obj_t aux_1260;
aux_1260 = CDR(cdr_201_92_391);
test_1259 = (aux_1260==BNIL);
}
if(test_1259){
obj_t value_1265;
obj_t name_1263;
name_1263 = CAR(cdr_133_55_361);
value_1265 = CAR(cdr_201_92_391);
value_356 = value_1265;
name_355 = name_1263;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
}
 else {
obj_t cdr_216_67_398;
cdr_216_67_398 = CDR(cdr_133_55_361);
{
bool_t test_1269;
{
obj_t aux_1270;
aux_1270 = CDR(cdr_216_67_398);
test_1269 = (aux_1270==BNIL);
}
if(test_1269){
obj_t value_1275;
obj_t name_1273;
name_1273 = CAR(cdr_133_55_361);
value_1275 = CAR(cdr_216_67_398);
value_356 = value_1275;
name_355 = name_1273;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
}
}
 else {
obj_t cdr_231_213_407;
cdr_231_213_407 = CDR(cdr_133_55_361);
{
bool_t test_1279;
{
obj_t aux_1280;
aux_1280 = CDR(cdr_231_213_407);
test_1279 = (aux_1280==BNIL);
}
if(test_1279){
obj_t value_1285;
obj_t name_1283;
name_1283 = CAR(cdr_133_55_361);
value_1285 = CAR(cdr_231_213_407);
value_356 = value_1285;
name_355 = name_1283;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
}
 else {
obj_t cdr_246_68_414;
cdr_246_68_414 = CDR(cdr_133_55_361);
if(PAIRP(cdr_246_68_414)){
bool_t test_1291;
{
obj_t aux_1292;
aux_1292 = CDR(cdr_246_68_414);
test_1291 = (aux_1292==BNIL);
}
if(test_1291){
obj_t value_1297;
obj_t name_1295;
name_1295 = CAR(cdr_133_55_361);
value_1297 = CAR(cdr_246_68_414);
value_356 = value_1297;
name_355 = name_1295;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
 else {
obj_t body_1305;
obj_t args_1303;
obj_t name_1301;
name_1301 = CAR(car_137_155_363);
args_1303 = CDR(car_137_155_363);
body_1305 = cdr_138_77_364;
body_353 = body_1305;
args_352 = args_1303;
name_351 = name_1301;
goto tag_117_96_354;
}
}
 else {
obj_t cdr_261_29_425;
cdr_261_29_425 = CDR(cdr_133_55_361);
if(PAIRP(cdr_261_29_425)){
obj_t car_265_225_427;
car_265_225_427 = CAR(cdr_261_29_425);
if(PAIRP(car_265_225_427)){
obj_t cdr_270_183_429;
cdr_270_183_429 = CDR(car_265_225_427);
{
bool_t test_1313;
{
obj_t aux_1314;
aux_1314 = CAR(car_265_225_427);
test_1313 = (aux_1314==symbol1472___expander_define);
}
if(test_1313){
if(PAIRP(cdr_270_183_429)){
obj_t cdr_274_124_432;
cdr_274_124_432 = CDR(cdr_270_183_429);
if((cdr_274_124_432==BNIL)){
obj_t cdr_289_3_435;
cdr_289_3_435 = CDR(cdr_133_55_361);
{
bool_t test_1323;
{
obj_t aux_1324;
aux_1324 = CDR(cdr_289_3_435);
test_1323 = (aux_1324==BNIL);
}
if(test_1323){
obj_t value_1329;
obj_t name_1327;
name_1327 = CAR(cdr_133_55_361);
value_1329 = CAR(cdr_289_3_435);
value_356 = value_1329;
name_355 = name_1327;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
 else {
bool_t test_1332;
{
obj_t aux_1333;
aux_1333 = CDR(cdr_261_29_425);
test_1332 = (aux_1333==BNIL);
}
if(test_1332){
obj_t body_1340;
obj_t args_1338;
obj_t name_1336;
name_1336 = CAR(cdr_133_55_361);
args_1338 = CAR(cdr_270_183_429);
body_1340 = cdr_274_124_432;
body_353 = body_1340;
args_352 = args_1338;
name_351 = name_1336;
goto tag_117_96_354;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
 else {
obj_t cdr_312_54_448;
cdr_312_54_448 = CDR(cdr_133_55_361);
{
bool_t test_1343;
{
obj_t aux_1344;
aux_1344 = CDR(cdr_312_54_448);
test_1343 = (aux_1344==BNIL);
}
if(test_1343){
obj_t value_1349;
obj_t name_1347;
name_1347 = CAR(cdr_133_55_361);
value_1349 = CAR(cdr_312_54_448);
value_356 = value_1349;
name_355 = name_1347;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
}
 else {
obj_t cdr_330_162_455;
cdr_330_162_455 = CDR(cdr_133_55_361);
{
bool_t test_1353;
{
obj_t aux_1354;
aux_1354 = CDR(cdr_330_162_455);
test_1353 = (aux_1354==BNIL);
}
if(test_1353){
obj_t value_1359;
obj_t name_1357;
name_1357 = CAR(cdr_133_55_361);
value_1359 = CAR(cdr_330_162_455);
value_356 = value_1359;
name_355 = name_1357;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
}
}
 else {
obj_t cdr_348_25_464;
cdr_348_25_464 = CDR(cdr_133_55_361);
{
bool_t test_1363;
{
obj_t aux_1364;
aux_1364 = CDR(cdr_348_25_464);
test_1363 = (aux_1364==BNIL);
}
if(test_1363){
obj_t value_1369;
obj_t name_1367;
name_1367 = CAR(cdr_133_55_361);
value_1369 = CAR(cdr_348_25_464);
value_356 = value_1369;
name_355 = name_1367;
goto tag_118_180_357;
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_5);}
}
}


/* internal-begin-expander */obj_t internal_begin_expander_196___expander_define(obj_t old_expander_200_7)
{
{
obj_t lambda1132_1147;
lambda1132_1147 = make_fx_procedure(lambda1132___expander_define, ((long)2), ((long)1));
PROCEDURE_SET(lambda1132_1147, ((long)0), old_expander_200_7);
return lambda1132_1147;
}
}


/* lambda1132 */obj_t lambda1132___expander_define(obj_t env_1148, obj_t expr_1150, obj_t expander_1151)
{
{
obj_t old_expander_200_1149;
old_expander_200_1149 = PROCEDURE_REF(env_1148, ((long)0));
{
obj_t expr_498;
obj_t expander_499;
expr_498 = expr_1150;
expander_499 = expander_1151;
{
obj_t res_501;
{
obj_t rest_503;
if(PAIRP(expr_498)){
bool_t test_1380;
{
obj_t aux_1381;
aux_1381 = CAR(expr_498);
test_1380 = (aux_1381==symbol1475___expander_define);
}
if(test_1380){
bool_t test_1384;
{
obj_t aux_1385;
aux_1385 = CDR(expr_498);
test_1384 = (aux_1385==BNIL);
}
if(test_1384){
FAILURE(symbol1475___expander_define,string1471___expander_define,expr_498);}
 else {
rest_503 = CDR(expr_498);
{
obj_t arg1144_517;
obj_t arg1145_518;
arg1144_517 = symbol1475___expander_define;
{
obj_t arg1148_521;
obj_t arg1150_522;
{
obj_t arg1151_523;
if(NULLP(rest_503)){
arg1151_523 = BNIL;
}
 else {
obj_t head1004_526;
head1004_526 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_527;
obj_t tail1005_528;
l1002_527 = rest_503;
tail1005_528 = head1004_526;
lname1003_529:
if(NULLP(l1002_527)){
arg1151_523 = CDR(head1004_526);
}
 else {
obj_t newtail1006_531;
{
obj_t arg1155_533;
arg1155_533 = PROCEDURE_ENTRY(expander_499)(expander_499, CAR(l1002_527), expander_499, BEOA);
newtail1006_531 = MAKE_PAIR(arg1155_533, BNIL);
}
SET_CDR(tail1005_528, newtail1006_531);
{
obj_t tail1005_1402;
obj_t l1002_1400;
l1002_1400 = CDR(l1002_527);
tail1005_1402 = newtail1006_531;
tail1005_528 = tail1005_1402;
l1002_527 = l1002_1400;
goto lname1003_529;
}
}
}
}
arg1148_521 = lambda_defines_105___expander_define(arg1151_523);
}
arg1150_522 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1145_518 = append_2_18___r4_pairs_and_lists_6_3(arg1148_521, arg1150_522);
}
{
obj_t list1146_519;
list1146_519 = MAKE_PAIR(arg1145_518, BNIL);
res_501 = cons__138___r4_pairs_and_lists_6_3(arg1144_517, list1146_519);
}
}
}
}
 else {
res_501 = PROCEDURE_ENTRY(old_expander_200_1149)(old_expander_200_1149, expr_498, expander_499, BEOA);
}
}
 else {
res_501 = PROCEDURE_ENTRY(old_expander_200_1149)(old_expander_200_1149, expr_498, expander_499, BEOA);
}
}
return replace__160___progn(expr_498, res_501);
}
}
}
}


/* lambda-defines */obj_t lambda_defines_105___expander_define(obj_t body_8)
{
{
obj_t oldforms_540;
obj_t newforms_541;
obj_t vars_542;
obj_t sets_543;
oldforms_540 = body_8;
newforms_541 = BNIL;
vars_542 = BNIL;
sets_543 = BNIL;
loop_544:
if(PAIRP(oldforms_540)){
obj_t form_549;
form_549 = CAR(oldforms_540);
{
bool_t test_1417;
if(PAIRP(form_549)){
bool_t test_1420;
{
obj_t aux_1421;
aux_1421 = CAR(form_549);
test_1420 = (aux_1421==symbol1473___expander_define);
}
if(test_1420){
test_1417 = ((bool_t)0);
}
 else {
test_1417 = ((bool_t)1);
}
}
 else {
test_1417 = ((bool_t)1);
}
if(test_1417){
{
obj_t arg1167_551;
obj_t arg1168_552;
arg1167_551 = CDR(oldforms_540);
arg1168_552 = MAKE_PAIR(form_549, newforms_541);
{
obj_t newforms_1427;
obj_t oldforms_1426;
oldforms_1426 = arg1167_551;
newforms_1427 = arg1168_552;
newforms_541 = newforms_1427;
oldforms_540 = oldforms_1426;
goto loop_544;
}
}
}
 else {
{
obj_t arg1169_553;
obj_t arg1170_554;
obj_t arg1171_555;
arg1169_553 = CDR(oldforms_540);
{
obj_t aux_1429;
{
obj_t aux_1430;
aux_1430 = CDR(form_549);
aux_1429 = CAR(aux_1430);
}
arg1170_554 = MAKE_PAIR(aux_1429, vars_542);
}
{
obj_t arg1173_557;
{
obj_t arg1174_558;
obj_t arg1175_559;
obj_t arg1176_560;
arg1174_558 = symbol1476___expander_define;
{
obj_t aux_1434;
aux_1434 = CDR(form_549);
arg1175_559 = CAR(aux_1434);
}
{
obj_t aux_1437;
{
obj_t aux_1438;
aux_1438 = CDR(form_549);
aux_1437 = CDR(aux_1438);
}
arg1176_560 = CAR(aux_1437);
}
{
obj_t list1178_562;
{
obj_t arg1179_563;
{
obj_t arg1180_564;
arg1180_564 = MAKE_PAIR(BNIL, BNIL);
arg1179_563 = MAKE_PAIR(arg1176_560, arg1180_564);
}
list1178_562 = MAKE_PAIR(arg1175_559, arg1179_563);
}
arg1173_557 = cons__138___r4_pairs_and_lists_6_3(arg1174_558, list1178_562);
}
}
arg1171_555 = MAKE_PAIR(arg1173_557, sets_543);
}
{
obj_t sets_1449;
obj_t vars_1448;
obj_t oldforms_1447;
oldforms_1447 = arg1169_553;
vars_1448 = arg1170_554;
sets_1449 = arg1171_555;
sets_543 = sets_1449;
vars_542 = vars_1448;
oldforms_540 = oldforms_1447;
goto loop_544;
}
}
}
}
}
 else {
if(NULLP(vars_542)){
return body_8;
}
 else {
obj_t arg1187_571;
{
obj_t arg1191_575;
obj_t arg1192_576;
{
obj_t arg1195_579;
obj_t arg1196_580;
arg1195_579 = symbol1472___expander_define;
{
obj_t arg1202_586;
obj_t arg1203_587;
arg1202_586 = symbol1475___expander_define;
{
obj_t arg1206_590;
obj_t arg1207_591;
arg1206_590 = reverse___r4_pairs_and_lists_6_3(sets_543);
{
obj_t arg1209_592;
{
obj_t arg1211_594;
obj_t arg1213_595;
arg1211_594 = reverse___r4_pairs_and_lists_6_3(newforms_541);
arg1213_595 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1209_592 = append_2_18___r4_pairs_and_lists_6_3(arg1211_594, arg1213_595);
}
arg1207_591 = cons__138___r4_pairs_and_lists_6_3(arg1209_592, BNIL);
}
arg1203_587 = append_2_18___r4_pairs_and_lists_6_3(arg1206_590, arg1207_591);
}
{
obj_t list1204_588;
list1204_588 = MAKE_PAIR(arg1203_587, BNIL);
arg1196_580 = cons__138___r4_pairs_and_lists_6_3(arg1202_586, list1204_588);
}
}
{
obj_t list1198_582;
{
obj_t arg1199_583;
{
obj_t arg1200_584;
arg1200_584 = MAKE_PAIR(BNIL, BNIL);
arg1199_583 = MAKE_PAIR(arg1196_580, arg1200_584);
}
list1198_582 = MAKE_PAIR(vars_542, arg1199_583);
}
arg1191_575 = cons__138___r4_pairs_and_lists_6_3(arg1195_579, list1198_582);
}
}
{
obj_t arg1216_598;
obj_t arg1219_599;
{
obj_t arg1220_600;
{
obj_t aux_1466;
long aux_1464;
aux_1466 = BINT(((long)0));
aux_1464 = list_length(vars_542);
arg1220_600 = make_vector(aux_1464, aux_1466);
}
arg1216_598 = vector__list_155___r4_vectors_6_8(arg1220_600);
}
arg1219_599 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1192_576 = append_2_18___r4_pairs_and_lists_6_3(arg1216_598, arg1219_599);
}
{
obj_t list1193_577;
list1193_577 = MAKE_PAIR(arg1192_576, BNIL);
arg1187_571 = cons__138___r4_pairs_and_lists_6_3(arg1191_575, list1193_577);
}
}
{
obj_t list1189_573;
list1189_573 = MAKE_PAIR(BNIL, BNIL);
return cons__138___r4_pairs_and_lists_6_3(arg1187_571, list1189_573);
}
}
}
}
}


/* expand-eval-external-define */obj_t expand_eval_external_define_170___expander_define(obj_t x_9, obj_t e_10)
{
internal_definition__7___expander_define = ((bool_t)1);
{
obj_t e_605;
e_605 = internal_begin_expander_196___expander_define(e_10);
{
obj_t res_606;
{
bool_t test_1477;
if(PAIRP(x_9)){
bool_t test_1480;
{
obj_t aux_1481;
aux_1481 = CDR(x_9);
test_1480 = PAIRP(aux_1481);
}
if(test_1480){
obj_t aux_1484;
{
obj_t aux_1485;
aux_1485 = CDR(x_9);
aux_1484 = CDR(aux_1485);
}
test_1477 = PAIRP(aux_1484);
}
 else {
test_1477 = ((bool_t)0);
}
}
 else {
test_1477 = ((bool_t)0);
}
if(test_1477){
obj_t type_608;
{
obj_t aux_1489;
aux_1489 = CDR(x_9);
type_608 = CAR(aux_1489);
}
if(PAIRP(type_608)){
obj_t arg1228_610;
obj_t arg1231_611;
obj_t arg1232_612;
arg1228_610 = symbol1473___expander_define;
arg1231_611 = CAR(type_608);
{
obj_t arg1240_618;
obj_t arg1241_619;
obj_t arg1243_620;
arg1240_618 = symbol1472___expander_define;
arg1241_619 = CDR(type_608);
{
obj_t arg1251_626;
{
obj_t aux_1496;
{
obj_t aux_1497;
aux_1497 = CDR(x_9);
aux_1496 = CDR(aux_1497);
}
arg1251_626 = normalize_progn_143___progn(aux_1496);
}
arg1243_620 = PROCEDURE_ENTRY(e_605)(e_605, arg1251_626, e_605, BEOA);
}
{
obj_t list1245_622;
{
obj_t arg1247_623;
{
obj_t arg1248_624;
arg1248_624 = MAKE_PAIR(BNIL, BNIL);
arg1247_623 = MAKE_PAIR(arg1243_620, arg1248_624);
}
list1245_622 = MAKE_PAIR(arg1241_619, arg1247_623);
}
arg1232_612 = cons__138___r4_pairs_and_lists_6_3(arg1240_618, list1245_622);
}
}
{
obj_t list1234_614;
{
obj_t arg1235_615;
{
obj_t arg1236_616;
arg1236_616 = MAKE_PAIR(BNIL, BNIL);
arg1235_615 = MAKE_PAIR(arg1232_612, arg1236_616);
}
list1234_614 = MAKE_PAIR(arg1231_611, arg1235_615);
}
res_606 = cons__138___r4_pairs_and_lists_6_3(arg1228_610, list1234_614);
}
}
 else {
obj_t arg1253_628;
obj_t arg1254_629;
arg1253_628 = symbol1473___expander_define;
{
obj_t arg1260_635;
{
obj_t aux_1511;
{
obj_t aux_1512;
aux_1512 = CDR(x_9);
aux_1511 = CDR(aux_1512);
}
arg1260_635 = normalize_progn_143___progn(aux_1511);
}
arg1254_629 = PROCEDURE_ENTRY(e_605)(e_605, arg1260_635, e_605, BEOA);
}
{
obj_t list1256_631;
{
obj_t arg1257_632;
{
obj_t arg1258_633;
arg1258_633 = MAKE_PAIR(BNIL, BNIL);
arg1257_632 = MAKE_PAIR(arg1254_629, arg1258_633);
}
list1256_631 = MAKE_PAIR(type_608, arg1257_632);
}
res_606 = cons__138___r4_pairs_and_lists_6_3(arg1253_628, list1256_631);
}
}
}
 else {
FAILURE(string1474___expander_define,string1471___expander_define,x_9);}
}
internal_definition__7___expander_define = ((bool_t)0);
return replace__160___progn(x_9, res_606);
}
}
}


/* expand-eval-define-inline */obj_t expand_eval_define_inline_157___expander_define(obj_t x_11, obj_t e_12)
{
{
obj_t fun_641;
obj_t formals_642;
obj_t body_643;
if(PAIRP(x_11)){
obj_t cdr_400_210_648;
cdr_400_210_648 = CDR(x_11);
if(PAIRP(cdr_400_210_648)){
obj_t car_404_54_650;
obj_t cdr_405_2_651;
car_404_54_650 = CAR(cdr_400_210_648);
cdr_405_2_651 = CDR(cdr_400_210_648);
if(PAIRP(car_404_54_650)){
if((cdr_405_2_651==BNIL)){
FAILURE(string1477___expander_define,string1471___expander_define,x_11);}
 else {
fun_641 = CAR(car_404_54_650);
formals_642 = CDR(car_404_54_650);
body_643 = cdr_405_2_651;
{
obj_t res_657;
{
obj_t arg1277_658;
obj_t arg1278_659;
obj_t arg1281_660;
arg1277_658 = symbol1473___expander_define;
{
obj_t arg1287_666;
arg1287_666 = parse_formal_ident_54___expand(fun_641);
arg1278_659 = CAR(arg1287_666);
}
{
obj_t arg1288_667;
obj_t arg1290_668;
arg1288_667 = symbol1472___expander_define;
{
obj_t arg1297_674;
arg1297_674 = normalize_progn_143___progn(body_643);
arg1290_668 = PROCEDURE_ENTRY(e_12)(e_12, arg1297_674, e_12, BEOA);
}
{
obj_t list1292_670;
{
obj_t arg1294_671;
{
obj_t arg1295_672;
arg1295_672 = MAKE_PAIR(BNIL, BNIL);
arg1294_671 = MAKE_PAIR(arg1290_668, arg1295_672);
}
list1292_670 = MAKE_PAIR(formals_642, arg1294_671);
}
arg1281_660 = cons__138___r4_pairs_and_lists_6_3(arg1288_667, list1292_670);
}
}
{
obj_t list1283_662;
{
obj_t arg1284_663;
{
obj_t arg1285_664;
arg1285_664 = MAKE_PAIR(BNIL, BNIL);
arg1284_663 = MAKE_PAIR(arg1281_660, arg1285_664);
}
list1283_662 = MAKE_PAIR(arg1278_659, arg1284_663);
}
res_657 = cons__138___r4_pairs_and_lists_6_3(arg1277_658, list1283_662);
}
}
return replace__160___progn(x_11, res_657);
}
}
}
 else {
FAILURE(string1477___expander_define,string1471___expander_define,x_11);}
}
 else {
FAILURE(string1477___expander_define,string1471___expander_define,x_11);}
}
 else {
FAILURE(string1477___expander_define,string1471___expander_define,x_11);}
}
}


/* _expand-eval-define-inline */obj_t _expand_eval_define_inline_59___expander_define(obj_t env_1152, obj_t x_1153, obj_t e_1154)
{
return expand_eval_define_inline_157___expander_define(x_1153, e_1154);
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_define()
{
module_initialization_70___error(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___bigloo(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___tvector(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___structure(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___bexit(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_DEFINE");
module_initialization_70___progn(((long)0), "__EXPANDER_DEFINE");
return module_initialization_70___expand(((long)0), "__EXPANDER_DEFINE");
}

