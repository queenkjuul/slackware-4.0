/*===========================================================================*/
/*   (Tools/location.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t location_shape_18_tools_location(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _find_location_loc_173_tools_location(obj_t, obj_t, obj_t);
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t warning___error(obj_t);
extern obj_t location_full_fname_231_tools_location(obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t pwd___os();
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern bool_t fexists(char *);
extern obj_t _lib_src_dir__208_engine_param;
static obj_t imported_modules_init_94_tools_location();
static obj_t _find_location_125_tools_location(obj_t, obj_t);
static obj_t library_modules_init_112_tools_location();
static obj_t toplevel_init_63_tools_location();
extern obj_t create_vector(long);
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t _location_shape___48_engine_param;
static obj_t _location_shape_246_tools_location(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _location_full_fname_123_tools_location(obj_t, obj_t);
extern obj_t find_location_120_tools_location(obj_t);
static obj_t require_initialization_114_tools_location = BUNSPEC;
extern obj_t make_file_name_203___os(obj_t, obj_t);
static obj_t cnst_init_137_tools_location();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(find_location_loc_env_20_tools_location, _find_location_loc_173_tools_location1218, _find_location_loc_173_tools_location, 0L, 2);
DEFINE_EXPORT_PROCEDURE(find_location_env_192_tools_location, _find_location_125_tools_location1219, _find_location_125_tools_location, 0L, 1);
DEFINE_EXPORT_PROCEDURE(location_full_fname_env_198_tools_location, _location_full_fname_123_tools_location1220, _location_full_fname_123_tools_location, 0L, 1);
DEFINE_EXPORT_PROCEDURE(location_shape_env_90_tools_location, _location_shape_246_tools_location1221, _location_shape_246_tools_location, 0L, 2);
DEFINE_STRING(string1209_tools_location, string1209_tools_location1222, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string1210_tools_location, string1210_tools_location1223, "LOCATION AT ", 12);
DEFINE_STRING(string1208_tools_location, string1208_tools_location1224, "cer", 3);
DEFINE_STRING(string1207_tools_location, string1207_tools_location1225, "find-location", 13);
DEFINE_STRING(string1206_tools_location, string1206_tools_location1226, "obsolete `at' format -- ", 24);


/* module-initialization */ obj_t 
module_initialization_70_tools_location(long checksum_284, char *from_285)
{
   if (CBOOL(require_initialization_114_tools_location))
     {
	require_initialization_114_tools_location = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_location();
	cnst_init_137_tools_location();
	imported_modules_init_94_tools_location();
	toplevel_init_63_tools_location();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_location()
{
   module_initialization_70___error(((long) 0), "TOOLS_LOCATION");
   module_initialization_70___os(((long) 0), "TOOLS_LOCATION");
   module_initialization_70___reader(((long) 0), "TOOLS_LOCATION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_tools_location()
{
   {
      obj_t cnst_port_138_276;
      cnst_port_138_276 = open_input_string(string1210_tools_location);
      {
	 long i_277;
	 i_277 = ((long) 1);
       loop_278:
	 {
	    bool_t test1211_279;
	    test1211_279 = (i_277 == ((long) -1));
	    if (test1211_279)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1213_280;
		    {
		       obj_t list1214_281;
		       {
			  obj_t arg1216_282;
			  arg1216_282 = BNIL;
			  list1214_281 = MAKE_PAIR(cnst_port_138_276, arg1216_282);
		       }
		       arg1213_280 = read___reader(list1214_281);
		    }
		    CNST_TABLE_SET(i_277, arg1213_280);
		 }
		 {
		    int aux_283;
		    {
		       long aux_302;
		       aux_302 = (i_277 - ((long) 1));
		       aux_283 = (int) (aux_302);
		    }
		    {
		       long i_305;
		       i_305 = (long) (aux_283);
		       i_277 = i_305;
		       goto loop_278;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_tools_location()
{
   return BUNSPEC;
}


/* find-location */ obj_t 
find_location_120_tools_location(obj_t exp_15)
{
   {
      obj_t loc_41;
      {
	 bool_t test1035_39;
	 test1035_39 = EXTENDED_PAIRP(exp_15);
	 if (test1035_39)
	   {
	      {
		 obj_t arg1038_40;
		 {
		    bool_t test1137_145;
		    test1137_145 = EXTENDED_PAIRP(exp_15);
		    if (test1137_145)
		      {
			 arg1038_40 = CER(exp_15);
		      }
		    else
		      {
			 FAILURE(string1208_tools_location, string1209_tools_location, exp_15);
		      }
		 }
		 loc_41 = arg1038_40;
		 {
		    obj_t fname_43;
		    obj_t pos_44;
		    if (PAIRP(loc_41))
		      {
			 obj_t cdr_111_186_53;
			 cdr_111_186_53 = CDR(loc_41);
			 {
			    bool_t test_316;
			    {
			       obj_t aux_319;
			       obj_t aux_317;
			       aux_319 = CNST_TABLE_REF(((long) 0));
			       aux_317 = CAR(loc_41);
			       test_316 = (aux_317 == aux_319);
			    }
			    if (test_316)
			      {
				 if (PAIRP(cdr_111_186_53))
				   {
				      obj_t cdr_115_115_56;
				      cdr_115_115_56 = CDR(cdr_111_186_53);
				      if (PAIRP(cdr_115_115_56))
					{
					   bool_t test_327;
					   {
					      obj_t aux_328;
					      aux_328 = CDR(cdr_115_115_56);
					      test_327 = (aux_328 == BNIL);
					   }
					   if (test_327)
					     {
						fname_43 = CAR(cdr_111_186_53);
						pos_44 = CAR(cdr_115_115_56);
						{
						   obj_t list1164_75;
						   {
						      obj_t arg1176_77;
						      {
							 obj_t arg1188_79;
							 arg1188_79 = MAKE_PAIR(loc_41, BNIL);
							 arg1176_77 = MAKE_PAIR(string1206_tools_location, arg1188_79);
						      }
						      list1164_75 = MAKE_PAIR(string1207_tools_location, arg1176_77);
						   }
						   return warning___error(list1164_75);
						}
					     }
					   else
					     {
						obj_t cdr_137_164_62;
						cdr_137_164_62 = CDR(cdr_111_186_53);
						{
						   obj_t cdr_144_157_63;
						   cdr_144_157_63 = CDR(cdr_137_164_62);
						   if (PAIRP(cdr_144_157_63))
						     {
							bool_t test_341;
							{
							   obj_t aux_342;
							   aux_342 = CDR(cdr_144_157_63);
							   test_341 = (aux_342 == BNIL);
							}
							if (test_341)
							  {
							     obj_t arg1077_66;
							     obj_t arg1137_67;
							     obj_t arg1142_68;
							     arg1077_66 = CAR(cdr_111_186_53);
							     arg1137_67 = CAR(cdr_137_164_62);
							     arg1142_68 = CAR(cdr_144_157_63);
							     {
								obj_t new_179;
								{
								   obj_t aux_348;
								   aux_348 = CNST_TABLE_REF(((long) 1));
								   new_179 = create_struct(aux_348, ((long) 3));
								}
								STRUCT_SET(new_179, ((long) 2), arg1142_68);
								STRUCT_SET(new_179, ((long) 1), arg1137_67);
								STRUCT_SET(new_179, ((long) 0), arg1077_66);
								return new_179;
							     }
							  }
							else
							  {
							     return BFALSE;
							  }
						     }
						   else
						     {
							return BFALSE;
						     }
						}
					     }
					}
				      else
					{
					   return BFALSE;
					}
				   }
				 else
				   {
				      return BFALSE;
				   }
			      }
			    else
			      {
				 return BFALSE;
			      }
			 }
		      }
		    else
		      {
			 return BFALSE;
		      }
		 }
	      }
	   }
	 else
	   {
	      return BFALSE;
	   }
      }
   }
}


/* _find-location */ obj_t 
_find_location_125_tools_location(obj_t env_265, obj_t exp_266)
{
   return find_location_120_tools_location(exp_266);
}


/* find-location/loc */ obj_t 
find_location_loc_243_tools_location(obj_t exp_16, obj_t loc_17)
{
   {
      obj_t new_loc_78_218;
      new_loc_78_218 = find_location_120_tools_location(exp_16);
      {
	 bool_t test_356;
	 if (STRUCTP(new_loc_78_218))
	   {
	      obj_t aux_361;
	      obj_t aux_359;
	      aux_361 = CNST_TABLE_REF(((long) 1));
	      aux_359 = STRUCT_KEY(new_loc_78_218);
	      test_356 = (aux_359 == aux_361);
	   }
	 else
	   {
	      test_356 = ((bool_t) 0);
	   }
	 if (test_356)
	   {
	      return new_loc_78_218;
	   }
	 else
	   {
	      return loc_17;
	   }
      }
   }
}


/* _find-location/loc */ obj_t 
_find_location_loc_173_tools_location(obj_t env_267, obj_t exp_268, obj_t loc_269)
{
   return find_location_loc_243_tools_location(exp_268, loc_269);
}


/* location-full-fname */ obj_t 
location_full_fname_231_tools_location(obj_t loc_18)
{
   {
      obj_t file_name_128_84;
      file_name_128_84 = STRUCT_REF(loc_18, ((long) 0));
      {
	 obj_t pwd_85;
	 {
	    obj_t vpwd_90;
	    {
	       bool_t test1190_232;
	       test1190_232 = (long) getenv("PWD");
	       if (test1190_232)
		 {
		    char *aux_368;
		    aux_368 = (char *) getenv("PWD");
		    vpwd_90 = string_to_bstring(aux_368);
		 }
	       else
		 {
		    vpwd_90 = BFALSE;
		 }
	    }
	    if (STRINGP(vpwd_90))
	      {
		 pwd_85 = vpwd_90;
	      }
	    else
	      {
		 pwd_85 = pwd___os();
	      }
	 }
	 {
	    obj_t full_name_119_86;
	    full_name_119_86 = make_file_name_203___os(pwd_85, file_name_128_84);
	    {
	       {
		  bool_t test1192_87;
		  {
		     char *aux_375;
		     aux_375 = BSTRING_TO_STRING(full_name_119_86);
		     test1192_87 = fexists(aux_375);
		  }
		  if (test1192_87)
		    {
		       return full_name_119_86;
		    }
		  else
		    {
		       obj_t lib_name_97_88;
		       lib_name_97_88 = make_file_name_203___os(_lib_src_dir__208_engine_param, file_name_128_84);
		       {
			  bool_t test1193_89;
			  {
			     char *aux_380;
			     aux_380 = BSTRING_TO_STRING(lib_name_97_88);
			     test1193_89 = fexists(aux_380);
			  }
			  if (test1193_89)
			    {
			       return lib_name_97_88;
			    }
			  else
			    {
			       return file_name_128_84;
			    }
		       }
		    }
	       }
	    }
	 }
      }
   }
}


/* _location-full-fname */ obj_t 
_location_full_fname_123_tools_location(obj_t env_270, obj_t loc_271)
{
   return location_full_fname_231_tools_location(loc_271);
}


/* location-shape */ obj_t 
location_shape_18_tools_location(obj_t loc_19, obj_t l_20)
{
   {
      bool_t test1195_92;
      if (CBOOL(_location_shape___48_engine_param))
	{
	   if (STRUCTP(loc_19))
	     {
		obj_t aux_391;
		obj_t aux_389;
		aux_391 = CNST_TABLE_REF(((long) 1));
		aux_389 = STRUCT_KEY(loc_19);
		test1195_92 = (aux_389 == aux_391);
	     }
	   else
	     {
		test1195_92 = ((bool_t) 0);
	     }
	}
      else
	{
	   test1195_92 = ((bool_t) 0);
	}
      if (test1195_92)
	{
	   obj_t arg1196_93;
	   {
	      obj_t v1002_94;
	      v1002_94 = create_vector(((long) 3));
	      {
		 obj_t aux_396;
		 aux_396 = STRUCT_REF(loc_19, ((long) 2));
		 VECTOR_SET(v1002_94, ((long) 2), aux_396);
	      }
	      {
		 obj_t aux_399;
		 aux_399 = STRUCT_REF(loc_19, ((long) 1));
		 VECTOR_SET(v1002_94, ((long) 1), aux_399);
	      }
	      {
		 obj_t arg1203_100;
		 {
		    char *aux_402;
		    {
		       obj_t aux_403;
		       aux_403 = STRUCT_REF(loc_19, ((long) 0));
		       aux_402 = BSTRING_TO_STRING(aux_403);
		    }
		    arg1203_100 = string_to_symbol(aux_402);
		 }
		 VECTOR_SET(v1002_94, ((long) 0), arg1203_100);
	      }
	      arg1196_93 = v1002_94;
	   }
	   return MAKE_PAIR(arg1196_93, l_20);
	}
      else
	{
	   return l_20;
	}
   }
}


/* _location-shape */ obj_t 
_location_shape_246_tools_location(obj_t env_272, obj_t loc_273, obj_t l_274)
{
   return location_shape_18_tools_location(loc_273, l_274);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_location()
{
   return module_initialization_70_engine_param(((long) 0), "TOOLS_LOCATION");
}
