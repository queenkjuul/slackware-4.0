/*===========================================================================*/
/*   (Prof/unit.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_prof_walk();
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t create_struct(obj_t, long);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_prof_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
static obj_t imported_modules_init_94_prof_walk();
static obj_t library_modules_init_112_prof_walk();
static obj_t toplevel_init_63_prof_walk();
static obj_t _make_prof_unit_78_prof_walk(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t make_prof_unit_161_prof_walk();
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t get_toplevel_unit_weight_75_module_include();
static obj_t require_initialization_114_prof_walk = BUNSPEC;
static obj_t cnst_init_137_prof_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(make_prof_unit_env_53_prof_walk, _make_prof_unit_78_prof_walk1582, _make_prof_unit_78_prof_walk, 0L, 0);
DEFINE_STRING(string1575_prof_walk, string1575_prof_walk1583, "UNIT (BEGIN (PRAGMA \"write_bprof_table()\")) PROF PASS-STARTED ", 62);
DEFINE_STRING(string1574_prof_walk, string1574_prof_walk1584, "failure during prelude hook", 27);
DEFINE_STRING(string1573_prof_walk, string1573_prof_walk1585, "   . ", 5);
DEFINE_STRING(string1572_prof_walk, string1572_prof_walk1586, "Prof", 4);


/* module-initialization */ obj_t 
module_initialization_70_prof_walk(long checksum_1156, char *from_1157)
{
   if (CBOOL(require_initialization_114_prof_walk))
     {
	require_initialization_114_prof_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_prof_walk();
	cnst_init_137_prof_walk();
	imported_modules_init_94_prof_walk();
	method_init_76_prof_walk();
	toplevel_init_63_prof_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_prof_walk()
{
   module_initialization_70___r4_numbers_6_5(((long) 0), "PROF_WALK");
   module_initialization_70___reader(((long) 0), "PROF_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_prof_walk()
{
   {
      obj_t cnst_port_138_1148;
      cnst_port_138_1148 = open_input_string(string1575_prof_walk);
      {
	 long i_1149;
	 i_1149 = ((long) 3);
       loop_1150:
	 {
	    bool_t test1576_1151;
	    test1576_1151 = (i_1149 == ((long) -1));
	    if (test1576_1151)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1578_1152;
		    {
		       obj_t list1579_1153;
		       {
			  obj_t arg1580_1154;
			  arg1580_1154 = BNIL;
			  list1579_1153 = MAKE_PAIR(cnst_port_138_1148, arg1580_1154);
		       }
		       arg1578_1152 = read___reader(list1579_1153);
		    }
		    CNST_TABLE_SET(i_1149, arg1578_1152);
		 }
		 {
		    int aux_1155;
		    {
		       long aux_1174;
		       aux_1174 = (i_1149 - ((long) 1));
		       aux_1155 = (int) (aux_1174);
		    }
		    {
		       long i_1177;
		       i_1177 = (long) (aux_1155);
		       i_1149 = i_1177;
		       goto loop_1150;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_prof_walk()
{
   return BUNSPEC;
}


/* make-prof-unit */ obj_t 
make_prof_unit_161_prof_walk()
{
   {
      obj_t list1457_727;
      {
	 obj_t arg1460_729;
	 {
	    obj_t arg1463_731;
	    {
	       obj_t aux_1179;
	       aux_1179 = BCHAR(((unsigned char) '\n'));
	       arg1463_731 = MAKE_PAIR(aux_1179, BNIL);
	    }
	    arg1460_729 = MAKE_PAIR(string1572_prof_walk, arg1463_731);
	 }
	 list1457_727 = MAKE_PAIR(string1573_prof_walk, arg1460_729);
      }
      verbose_tools_speek(BINT(((long) 1)), list1457_727);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1572_prof_walk;
   {
      obj_t hooks_733;
      obj_t hnames_734;
      hooks_733 = BNIL;
      hnames_734 = BNIL;
    loop_735:
      if (NULLP(hooks_733))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1469_740;
	   {
	      obj_t fun1476_746;
	      fun1476_746 = CAR(hooks_733);
	      {
		 obj_t aux_1191;
		 aux_1191 = PROCEDURE_ENTRY(fun1476_746) (fun1476_746, BEOA);
		 test1469_740 = CBOOL(aux_1191);
	      }
	   }
	   if (test1469_740)
	     {
		{
		   obj_t hnames_1198;
		   obj_t hooks_1196;
		   hooks_1196 = CDR(hooks_733);
		   hnames_1198 = CDR(hnames_734);
		   hnames_734 = hnames_1198;
		   hooks_733 = hooks_1196;
		   goto loop_735;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1572_prof_walk, string1574_prof_walk, CAR(hnames_734));
	     }
	}
   }
   {
      obj_t arg1477_747;
      obj_t arg1478_748;
      obj_t arg1479_749;
      arg1477_747 = CNST_TABLE_REF(((long) 1));
      {
	 obj_t arg1481_751;
	 arg1481_751 = get_toplevel_unit_weight_75_module_include();
	 arg1478_748 = _2__168___r4_numbers_6_5(BINT(((long) 100)), arg1481_751);
      }
      arg1479_749 = CNST_TABLE_REF(((long) 2));
      {
	 obj_t new_1123;
	 {
	    obj_t aux_1207;
	    aux_1207 = CNST_TABLE_REF(((long) 3));
	    new_1123 = create_struct(aux_1207, ((long) 4));
	 }
	 STRUCT_SET(new_1123, ((long) 3), BTRUE);
	 STRUCT_SET(new_1123, ((long) 2), arg1479_749);
	 STRUCT_SET(new_1123, ((long) 1), arg1478_748);
	 STRUCT_SET(new_1123, ((long) 0), arg1477_747);
	 return new_1123;
      }
   }
}


/* _make-prof-unit */ obj_t 
_make_prof_unit_78_prof_walk(obj_t env_1146)
{
   return make_prof_unit_161_prof_walk();
}


/* method-init */ obj_t 
method_init_76_prof_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_prof_walk()
{
   module_initialization_70_tools_speek(((long) 0), "PROF_WALK");
   module_initialization_70_tools_error(((long) 0), "PROF_WALK");
   module_initialization_70_engine_pass(((long) 0), "PROF_WALK");
   module_initialization_70_tools_shape(((long) 0), "PROF_WALK");
   module_initialization_70_engine_param(((long) 0), "PROF_WALK");
   module_initialization_70_type_type(((long) 0), "PROF_WALK");
   module_initialization_70_module_include(((long) 0), "PROF_WALK");
   module_initialization_70_ast_var(((long) 0), "PROF_WALK");
   return module_initialization_70_ast_node(((long) 0), "PROF_WALK");
}
