/*===========================================================================*/
/*   (Engine/link.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t _src_files__222_engine_param;
static obj_t _tmp_main_file_name__139_engine_link = BUNSPEC;
extern obj_t _mco_suffix__47_engine_param;
extern obj_t string_append(obj_t, obj_t);
extern obj_t _load_path__54___eval;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
static obj_t find_libraries_1_engine_link(obj_t);
extern obj_t compiler_engine_compiler();
extern obj_t warning___error(obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t gensym___r4_symbols_6_4;
static obj_t find_src_file_253_engine_link(obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
static obj_t handling_function1273_engine_link();
extern obj_t _additional_bigloo_libraries__50_engine_param;
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t suffix___os(obj_t);
extern obj_t module_initialization_70_engine_link(long, char *);
extern obj_t module_initialization_70_cc_ld(long, char *);
extern obj_t module_initialization_70_read_reader(long, char *);
extern obj_t module_initialization_70_engine_compiler(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_bdb_setting(long, char *);
extern obj_t module_initialization_70_module_alibrary(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t _warning__61___error;
extern obj_t compiler_read_18_read_reader(obj_t);
extern bool_t fexists(char *);
static obj_t imported_modules_init_94_engine_link();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t prefix___os(obj_t);
extern obj_t bdb_setting__207_bdb_setting();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _rest_args__8_engine_param;
static obj_t library_modules_init_112_engine_link();
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t link_with_5_engine_link(obj_t);
extern obj_t _o_files__27_engine_param;
static obj_t toplevel_init_63_engine_link();
extern obj_t open_input_string(obj_t);
static obj_t unprof_src_name_11_engine_link(obj_t);
static obj_t _link_engine_link(obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t basename___os(obj_t);
extern obj_t close_input_port(obj_t);
extern obj_t c_substring(obj_t, long, long);
extern obj_t ld_cc_ld(obj_t, bool_t);
extern obj_t _bigloo_name__170_engine_param;
extern obj_t link_engine_link();
extern obj_t read___reader(obj_t);
extern obj_t _profile_mode__105_engine_param;
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _bigloo_tmp__142_engine_param;
extern obj_t open_output_file(obj_t);
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114_engine_link = BUNSPEC;
extern obj_t make_file_name_203___os(obj_t, obj_t);
extern obj_t _src_suffix__192_engine_param;
static obj_t make_tmp_main_229_engine_link(obj_t, obj_t, obj_t);
extern obj_t make_library_name_119_module_alibrary(obj_t);
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
static obj_t cnst_init_137_engine_link();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(link_env_76_engine_link, _link_engine_link1506, _link_engine_link, 0L, 0);
DEFINE_STRING(string1499_engine_link, string1499_engine_link1507, "Can't open output file", 22);
DEFINE_STRING(string1498_engine_link, string1498_engine_link1508, "(main *the-command-line*)", 25);
DEFINE_STRING(string1497_engine_link, string1497_engine_link1509, "It won't be possible to debug that program", 42);
DEFINE_STRING(string1496_engine_link, string1496_engine_link1510, "-- It contains no MAIN function!", 32);
DEFINE_STRING(string1495_engine_link, string1495_engine_link1511, ";; ==================================", 37);
DEFINE_STRING(string1494_engine_link, string1494_engine_link1512, ";; !!! generated file, don't edit !!!", 37);
DEFINE_STRING(string1493_engine_link, string1493_engine_link1513, ";; ", 3);
DEFINE_STRING(string1492_engine_link, string1492_engine_link1514, "Illegal file", 12);
DEFINE_STRING(string1491_engine_link, string1491_engine_link1515, "Redeclaration of the main (files ", 33);
DEFINE_STRING(string1489_engine_link, string1489_engine_link1516, ")", 1);
DEFINE_STRING(string1490_engine_link, string1490_engine_link1517, " and ", 5);
DEFINE_STRING(string1500_engine_link, string1500_engine_link1518, "IMPORT LIBRARY MAIN MODULE ", 27);
DEFINE_STRING(string1488_engine_link, string1488_engine_link1519, "\"", 1);
DEFINE_STRING(string1487_engine_link, string1487_engine_link1520, ".o", 2);
DEFINE_STRING(string1486_engine_link, string1486_engine_link1521, ".c", 2);
DEFINE_STRING(string1485_engine_link, string1485_engine_link1522, "No source file found", 20);
DEFINE_STRING(string1484_engine_link, string1484_engine_link1523, " -- ", 4);
DEFINE_STRING(string1483_engine_link, string1483_engine_link1524, ".", 1);
DEFINE_STRING(string1482_engine_link, string1482_engine_link1525, "link", 4);
DEFINE_STRING(string1481_engine_link, string1481_engine_link1526, "No Bigloo module found for -- ", 30);
DEFINE_STRING(string1479_engine_link, string1479_engine_link1527, "@", 1);
DEFINE_STRING(string1480_engine_link, string1480_engine_link1528, "main-tmp", 8);
DEFINE_STRING(string1478_engine_link, string1478_engine_link1529, "", 0);


/* module-initialization */ obj_t 
module_initialization_70_engine_link(long checksum_512, char *from_513)
{
   if (CBOOL(require_initialization_114_engine_link))
     {
	require_initialization_114_engine_link = BBOOL(((bool_t) 0));
	library_modules_init_112_engine_link();
	cnst_init_137_engine_link();
	imported_modules_init_94_engine_link();
	toplevel_init_63_engine_link();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_engine_link()
{
   module_initialization_70___bexit(((long) 0), "ENGINE_LINK");
   module_initialization_70___eval(((long) 0), "ENGINE_LINK");
   module_initialization_70___error(((long) 0), "ENGINE_LINK");
   module_initialization_70___r4_symbols_6_4(((long) 0), "ENGINE_LINK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "ENGINE_LINK");
   module_initialization_70___os(((long) 0), "ENGINE_LINK");
   module_initialization_70___r4_strings_6_7(((long) 0), "ENGINE_LINK");
   module_initialization_70___r4_output_6_10_3(((long) 0), "ENGINE_LINK");
   module_initialization_70___reader(((long) 0), "ENGINE_LINK");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "ENGINE_LINK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_engine_link()
{
   {
      obj_t cnst_port_138_504;
      cnst_port_138_504 = open_input_string(string1500_engine_link);
      {
	 long i_505;
	 i_505 = ((long) 3);
       loop_506:
	 {
	    bool_t test1501_507;
	    test1501_507 = (i_505 == ((long) -1));
	    if (test1501_507)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1502_508;
		    {
		       obj_t list1503_509;
		       {
			  obj_t arg1504_510;
			  arg1504_510 = BNIL;
			  list1503_509 = MAKE_PAIR(cnst_port_138_504, arg1504_510);
		       }
		       arg1502_508 = read___reader(list1503_509);
		    }
		    CNST_TABLE_SET(i_505, arg1502_508);
		 }
		 {
		    int aux_511;
		    {
		       long aux_537;
		       aux_537 = (i_505 - ((long) 1));
		       aux_511 = (int) (aux_537);
		    }
		    {
		       long i_540;
		       i_540 = (long) (aux_511);
		       i_505 = i_540;
		       goto loop_506;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_engine_link()
{
   {
      obj_t arg1014_9;
      {
	 obj_t arg1020_12;
	 obj_t arg1025_13;
	 {
	    obj_t user_19;
	    {
	       bool_t test1190_339;
	       test1190_339 = (long) getenv("USER");
	       if (test1190_339)
		 {
		    char *aux_544;
		    aux_544 = (char *) getenv("USER");
		    user_19 = string_to_bstring(aux_544);
		 }
	       else
		 {
		    user_19 = BFALSE;
		 }
	    }
	    if (STRINGP(user_19))
	      {
		 arg1020_12 = user_19;
	      }
	    else
	      {
		 arg1020_12 = string1478_engine_link;
	      }
	 }
	 {
	    obj_t pair_341;
	    pair_341 = _src_suffix__192_engine_param;
	    arg1025_13 = CAR(pair_341);
	 }
	 {
	    obj_t list1026_14;
	    {
	       obj_t arg1032_15;
	       {
		  obj_t arg1034_16;
		  {
		     obj_t arg1038_17;
		     arg1038_17 = MAKE_PAIR(arg1025_13, BNIL);
		     arg1034_16 = MAKE_PAIR(arg1020_12, arg1038_17);
		  }
		  arg1032_15 = MAKE_PAIR(string1479_engine_link, arg1034_16);
	       }
	       list1026_14 = MAKE_PAIR(string1480_engine_link, arg1032_15);
	    }
	    arg1014_9 = string_append_106___r4_strings_6_7(list1026_14);
	 }
      }
      return (_tmp_main_file_name__139_engine_link = make_file_name_203___os(_bigloo_tmp__142_engine_param, arg1014_9),
	 BUNSPEC);
   }
}


/* link */ obj_t 
link_engine_link()
{
   {
      bool_t test1043_21;
      {
	 long n1_342;
	 n1_342 = (long) CINT(_bdb_debug__1_engine_param);
	 test1043_21 = (n1_342 > ((long) 0));
      }
      if (test1043_21)
	{
	   bdb_setting__207_bdb_setting();
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t o_files_97_22;
      obj_t scm_files_107_23;
      o_files_97_22 = _o_files__27_engine_param;
      scm_files_107_23 = BNIL;
    loop_24:
      if (NULLP(o_files_97_22))
	{
	   return link_with_5_engine_link(scm_files_107_23);
	}
      else
	{
	   obj_t pref_27;
	   {
	      obj_t arg1175_43;
	      arg1175_43 = prefix___os(CAR(o_files_97_22));
	      pref_27 = unprof_src_name_11_engine_link(arg1175_43);
	   }
	   {
	      obj_t bpref_28;
	      bpref_28 = basename___os(pref_27);
	      {
		 obj_t scm_file_96_29;
		 scm_file_96_29 = find_src_file_253_engine_link(pref_27, bpref_28);
		 {
		    if (STRINGP(scm_file_96_29))
		      {
			 obj_t arg1077_31;
			 obj_t arg1137_32;
			 arg1077_31 = CDR(o_files_97_22);
			 arg1137_32 = MAKE_PAIR(scm_file_96_29, scm_files_107_23);
			 {
			    obj_t scm_files_107_573;
			    obj_t o_files_97_572;
			    o_files_97_572 = arg1077_31;
			    scm_files_107_573 = arg1137_32;
			    scm_files_107_23 = scm_files_107_573;
			    o_files_97_22 = o_files_97_572;
			    goto loop_24;
			 }
		      }
		    else
		      {
			 {
			    bool_t test1139_33;
			    {
			       bool_t test1162_41;
			       {
				  bool_t res1477_354;
				  {
				     obj_t obj_350;
				     obj_350 = _warning__61___error;
				     if (INTEGERP(obj_350))
				       {
					  res1477_354 = ((bool_t) 1);
				       }
				     else
				       {
					  res1477_354 = REALP(obj_350);
				       }
				  }
				  test1162_41 = res1477_354;
			       }
			       if (test1162_41)
				 {
				    long n1_355;
				    n1_355 = (long) CINT(_warning__61___error);
				    test1139_33 = (n1_355 >= ((long) 2));
				 }
			       else
				 {
				    test1139_33 = ((bool_t) 0);
				 }
			    }
			    if (test1139_33)
			      {
				 obj_t list1146_37;
				 {
				    obj_t arg1150_38;
				    {
				       obj_t arg1157_39;
				       {
					  obj_t aux_581;
					  aux_581 = CAR(o_files_97_22);
					  arg1157_39 = MAKE_PAIR(aux_581, BNIL);
				       }
				       arg1150_38 = MAKE_PAIR(string1481_engine_link, arg1157_39);
				    }
				    list1146_37 = MAKE_PAIR(string1482_engine_link, arg1150_38);
				 }
				 warning___error(list1146_37);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
			 {
			    obj_t o_files_97_587;
			    o_files_97_587 = CDR(o_files_97_22);
			    o_files_97_22 = o_files_97_587;
			    goto loop_24;
			 }
		      }
		 }
	      }
	   }
	}
   }
}


/* _link */ obj_t 
_link_engine_link(obj_t env_503)
{
   return link_engine_link();
}


/* unprof-src-name */ obj_t 
unprof_src_name_11_engine_link(obj_t name_1)
{
   if (CBOOL(_profile_mode__105_engine_param))
     {
	long len_45;
	len_45 = STRING_LENGTH(name_1);
	{
	   bool_t test_593;
	   if ((len_45 > ((long) 2)))
	     {
		bool_t test_596;
		{
		   unsigned char aux_597;
		   {
		      long aux_598;
		      aux_598 = (len_45 - ((long) 1));
		      aux_597 = STRING_REF(name_1, aux_598);
		   }
		   test_596 = (aux_597 == ((unsigned char) 'p'));
		}
		if (test_596)
		  {
		     unsigned char aux_602;
		     {
			long aux_603;
			aux_603 = (len_45 - ((long) 2));
			aux_602 = STRING_REF(name_1, aux_603);
		     }
		     test_593 = (aux_602 == ((unsigned char) '_'));
		  }
		else
		  {
		     test_593 = ((bool_t) 0);
		  }
	     }
	   else
	     {
		test_593 = ((bool_t) 0);
	     }
	   if (test_593)
	     {
		long aux_607;
		aux_607 = (len_45 - ((long) 2));
		return c_substring(name_1, ((long) 0), aux_607);
	     }
	   else
	     {
		return name_1;
	     }
	}
     }
   else
     {
	return name_1;
     }
}


/* find-src-file */ obj_t 
find_src_file_253_engine_link(obj_t prefix_2, obj_t bname_3)
{
   {
      obj_t suffix_55;
      suffix_55 = _src_suffix__192_engine_param;
    loop_56:
      if (NULLP(suffix_55))
	{
	   return BFALSE;
	}
      else
	{
	   obj_t suf_58;
	   suf_58 = CAR(suffix_55);
	   {
	      obj_t f_59;
	      {
		 obj_t arg1206_70;
		 {
		    obj_t list1207_71;
		    {
		       obj_t arg1209_72;
		       {
			  obj_t arg1211_74;
			  arg1211_74 = MAKE_PAIR(suf_58, BNIL);
			  arg1209_72 = MAKE_PAIR(string1483_engine_link, arg1211_74);
		       }
		       list1207_71 = MAKE_PAIR(prefix_2, arg1209_72);
		    }
		    arg1206_70 = string_append_106___r4_strings_6_7(list1207_71);
		 }
		 f_59 = find_file_path_55_tools_file(arg1206_70, _load_path__54___eval);
	      }
	      {
		 if (STRINGP(f_59))
		   {
		      return f_59;
		   }
		 else
		   {
		      obj_t f_61;
		      {
			 obj_t arg1200_64;
			 {
			    obj_t list1201_65;
			    {
			       obj_t arg1202_66;
			       {
				  obj_t arg1204_68;
				  arg1204_68 = MAKE_PAIR(suf_58, BNIL);
				  arg1202_66 = MAKE_PAIR(string1483_engine_link, arg1204_68);
			       }
			       list1201_65 = MAKE_PAIR(bname_3, arg1202_66);
			    }
			    arg1200_64 = string_append_106___r4_strings_6_7(list1201_65);
			 }
			 f_61 = find_file_path_55_tools_file(arg1200_64, _load_path__54___eval);
		      }
		      if (STRINGP(f_61))
			{
			   return f_61;
			}
		      else
			{
			   obj_t suffix_627;
			   suffix_627 = CDR(suffix_55);
			   suffix_55 = suffix_627;
			   goto loop_56;
			}
		   }
	      }
	   }
	}
   }
}


/* link-with */ obj_t 
link_with_5_engine_link(obj_t scm_files_107_4)
{
   if (NULLP(scm_files_107_4))
     {
	obj_t first_77;
	{
	   obj_t arg1226_86;
	   {
	      obj_t pair_385;
	      pair_385 = _o_files__27_engine_param;
	      arg1226_86 = CAR(pair_385);
	   }
	   first_77 = prefix___os(arg1226_86);
	}
	{
	   obj_t list1215_78;
	   {
	      obj_t arg1219_80;
	      {
		 obj_t arg1221_82;
		 {
		    obj_t arg1224_84;
		    arg1224_84 = MAKE_PAIR(_o_files__27_engine_param, BNIL);
		    arg1221_82 = MAKE_PAIR(string1484_engine_link, arg1224_84);
		 }
		 arg1219_80 = MAKE_PAIR(string1485_engine_link, arg1221_82);
	      }
	      list1215_78 = MAKE_PAIR(string1482_engine_link, arg1219_80);
	   }
	   warning___error(list1215_78);
	}
	{
	   obj_t pair_386;
	   pair_386 = _o_files__27_engine_param;
	   _o_files__27_engine_param = CDR(pair_386);
	}
	return ld_cc_ld(first_77, ((bool_t) 0));
     }
   else
     {
	obj_t scm_files_107_87;
	obj_t cls_88;
	obj_t main_89;
	obj_t fmain_90;
	obj_t libraries_91;
	scm_files_107_87 = scm_files_107_4;
	cls_88 = BNIL;
	main_89 = BFALSE;
	fmain_90 = string1478_engine_link;
	libraries_91 = BNIL;
      loop_92:
	if (NULLP(scm_files_107_87))
	  {
	     if (CBOOL(main_89))
	       {
		  obj_t first_97;
		  {
		     obj_t arg1248_115;
		     {
			obj_t pair_388;
			pair_388 = _o_files__27_engine_param;
			arg1248_115 = CAR(pair_388);
		     }
		     first_97 = prefix___os(arg1248_115);
		  }
		  {
		     obj_t arg1234_98;
		     if (NULLP(libraries_91))
		       {
			  arg1234_98 = BNIL;
		       }
		     else
		       {
			  obj_t head1004_101;
			  {
			     obj_t arg1244_112;
			     arg1244_112 = make_library_name_119_module_alibrary(CAR(libraries_91));
			     head1004_101 = MAKE_PAIR(arg1244_112, BNIL);
			  }
			  {
			     obj_t l1002_102;
			     obj_t tail1005_103;
			     l1002_102 = CDR(libraries_91);
			     tail1005_103 = head1004_101;
			   lname1003_104:
			     if (NULLP(l1002_102))
			       {
				  arg1234_98 = head1004_101;
			       }
			     else
			       {
				  obj_t newtail1006_107;
				  {
				     obj_t arg1240_109;
				     arg1240_109 = make_library_name_119_module_alibrary(CAR(l1002_102));
				     newtail1006_107 = MAKE_PAIR(arg1240_109, BNIL);
				  }
				  SET_CDR(tail1005_103, newtail1006_107);
				  {
				     obj_t tail1005_659;
				     obj_t l1002_657;
				     l1002_657 = CDR(l1002_102);
				     tail1005_659 = newtail1006_107;
				     tail1005_103 = tail1005_659;
				     l1002_102 = l1002_657;
				     goto lname1003_104;
				  }
			       }
			  }
		       }
		     _additional_bigloo_libraries__50_engine_param = append_2_18___r4_pairs_and_lists_6_3(arg1234_98, _additional_bigloo_libraries__50_engine_param);
		  }
		  {
		     obj_t pair_401;
		     pair_401 = _o_files__27_engine_param;
		     _o_files__27_engine_param = CDR(pair_401);
		  }
		  return ld_cc_ld(first_97, ((bool_t) 0));
	       }
	     else
	       {
		  make_tmp_main_229_engine_link(cls_88, main_89, libraries_91);
		  {
		     obj_t list1249_116;
		     list1249_116 = MAKE_PAIR(_tmp_main_file_name__139_engine_link, BNIL);
		     _src_files__222_engine_param = list1249_116;
		  }
		  {
		     obj_t ra_118;
		     obj_t res_119;
		     ra_118 = _rest_args__8_engine_param;
		     res_119 = BNIL;
		   loop_120:
		     if (NULLP(ra_118))
		       {
			  _rest_args__8_engine_param = reverse__39___r4_pairs_and_lists_6_3(res_119);
		       }
		     else
		       {
			  bool_t test1253_123;
			  {
			     obj_t arg1258_128;
			     arg1258_128 = suffix___os(CAR(ra_118));
			     {
				obj_t aux_671;
				aux_671 = member___r4_pairs_and_lists_6_3(arg1258_128, _mco_suffix__47_engine_param);
				test1253_123 = CBOOL(aux_671);
			     }
			  }
			  if (test1253_123)
			    {
			       {
				  obj_t ra_675;
				  ra_675 = CDR(ra_118);
				  ra_118 = ra_675;
				  goto loop_120;
			       }
			    }
			  else
			    {
			       {
				  obj_t arg1255_125;
				  obj_t arg1256_126;
				  arg1255_125 = CDR(ra_118);
				  {
				     obj_t aux_678;
				     aux_678 = CAR(ra_118);
				     arg1256_126 = MAKE_PAIR(aux_678, res_119);
				  }
				  {
				     obj_t res_682;
				     obj_t ra_681;
				     ra_681 = arg1255_125;
				     res_682 = arg1256_126;
				     res_119 = res_682;
				     ra_118 = ra_681;
				     goto loop_120;
				  }
			       }
			    }
		       }
		  }
		  {
		     obj_t val1007_130;
		     val1007_130 = handling_function1273_engine_link();
		     {
			obj_t pre_132;
			pre_132 = prefix___os(_tmp_main_file_name__139_engine_link);
			{
			   obj_t c_file_203_133;
			   c_file_203_133 = string_append(pre_132, string1486_engine_link);
			   {
			      obj_t o_file_119_134;
			      o_file_119_134 = string_append(pre_132, string1487_engine_link);
			      {
				 {
				    obj_t l1010_135;
				    {
				       obj_t arg1260_137;
				       {
					  obj_t list1261_138;
					  {
					     obj_t arg1262_139;
					     {
						obj_t arg1263_140;
						arg1263_140 = MAKE_PAIR(o_file_119_134, BNIL);
						arg1262_139 = MAKE_PAIR(c_file_203_133, arg1263_140);
					     }
					     list1261_138 = MAKE_PAIR(_tmp_main_file_name__139_engine_link, arg1262_139);
					  }
					  arg1260_137 = list1261_138;
				       }
				       l1010_135 = arg1260_137;
				     lname1011_136:
				       if (PAIRP(l1010_135))
					 {
					    {
					       obj_t f_143;
					       f_143 = CAR(l1010_135);
					       {
						  bool_t test1267_144;
						  {
						     char *aux_693;
						     aux_693 = BSTRING_TO_STRING(f_143);
						     test1267_144 = fexists(aux_693);
						  }
						  if (test1267_144)
						    {
						       bool_t aux_697;
						       {
							  char *aux_698;
							  aux_698 = BSTRING_TO_STRING(f_143);
							  aux_697 = unlink(aux_698);
						       }
						       BBOOL(aux_697);
						    }
						  else
						    {
						       BUNSPEC;
						    }
					       }
					    }
					    {
					       obj_t l1010_702;
					       l1010_702 = CDR(l1010_135);
					       l1010_135 = l1010_702;
					       goto lname1011_136;
					    }
					 }
				       else
					 {
					    ((bool_t) 1);
					 }
				    }
				 }
			      }
			   }
			}
		     }
		     {
			bool_t test1269_146;
			{
			   obj_t aux_704;
			   aux_704 = val_from_exit__100___bexit(val1007_130);
			   test1269_146 = CBOOL(aux_704);
			}
			if (test1269_146)
			  {
			     unwind_until__178___bexit(CAR(val1007_130), CDR(val1007_130));
			  }
			else
			  {
			     val1007_130;
			  }
		     }
		  }
		  return BINT(((long) 0));
	       }
	  }
	else
	  {
	     obj_t port_152;
	     port_152 = open_input_file_61___r4_ports_6_10_1(CAR(scm_files_107_87), BNIL);
	     if (INPUT_PORTP(port_152))
	       {
		  obj_t exp_154;
		  {
		     obj_t list1369_241;
		     list1369_241 = MAKE_PAIR(port_152, BNIL);
		     exp_154 = compiler_read_18_read_reader(list1369_241);
		  }
		  close_input_port(port_152);
		  {
		     obj_t name_155;
		     obj_t new_main_52_156;
		     obj_t name_158;
		     if (PAIRP(exp_154))
		       {
			  obj_t cdr_112_210_163;
			  cdr_112_210_163 = CDR(exp_154);
			  {
			     bool_t test_722;
			     {
				obj_t aux_725;
				obj_t aux_723;
				aux_725 = CNST_TABLE_REF(((long) 0));
				aux_723 = CAR(exp_154);
				test_722 = (aux_723 == aux_725);
			     }
			     if (test_722)
			       {
				  if (PAIRP(cdr_112_210_163))
				    {
				       obj_t g_119_66_168;
				       g_119_66_168 = CDR(cdr_112_210_163);
				     try_120_69_189:
				       if (PAIRP(g_119_66_168))
					 {
					    obj_t car_122_214_171;
					    car_122_214_171 = CAR(g_119_66_168);
					    if (PAIRP(car_122_214_171))
					      {
						 obj_t cdr_126_195_173;
						 cdr_126_195_173 = CDR(car_122_214_171);
						 {
						    bool_t test_736;
						    {
						       obj_t aux_739;
						       obj_t aux_737;
						       aux_739 = CNST_TABLE_REF(((long) 1));
						       aux_737 = CAR(car_122_214_171);
						       test_736 = (aux_737 == aux_739);
						    }
						    if (test_736)
						      {
							 if (PAIRP(cdr_126_195_173))
							   {
							      bool_t test_744;
							      {
								 obj_t aux_745;
								 aux_745 = CDR(cdr_126_195_173);
								 test_744 = (aux_745 == BNIL);
							      }
							      if (test_744)
								{
								   name_155 = CAR(cdr_112_210_163);
								   new_main_52_156 = CAR(cdr_126_195_173);
								   if (CBOOL(main_89))
								     {
									obj_t arg1302_193;
									obj_t arg1303_194;
									{
									   obj_t arg1308_197;
									   arg1308_197 = CAR(scm_files_107_87);
									   {
									      obj_t list1310_199;
									      {
										 obj_t arg1311_200;
										 {
										    obj_t arg1313_201;
										    {
										       obj_t arg1315_202;
										       {
											  obj_t arg1316_203;
											  arg1316_203 = MAKE_PAIR(string1489_engine_link, BNIL);
											  arg1315_202 = MAKE_PAIR(arg1308_197, arg1316_203);
										       }
										       arg1313_201 = MAKE_PAIR(string1490_engine_link, arg1315_202);
										    }
										    arg1311_200 = MAKE_PAIR(fmain_90, arg1313_201);
										 }
										 list1310_199 = MAKE_PAIR(string1491_engine_link, arg1311_200);
									      }
									      arg1302_193 = string_append_106___r4_strings_6_7(list1310_199);
									   }
									}
									arg1303_194 = MAKE_PAIR(main_89, new_main_52_156);
									FAILURE(string1478_engine_link, arg1302_193, arg1303_194);
								     }
								   else
								     {
									BUNSPEC;
								     }
								   {
								      obj_t arg1321_205;
								      obj_t arg1322_206;
								      obj_t arg1323_207;
								      obj_t arg1324_208;
								      arg1321_205 = CDR(scm_files_107_87);
								      {
									 obj_t arg1325_209;
									 {
									    obj_t arg1326_210;
									    {
									       obj_t arg1332_215;
									       arg1332_215 = CAR(scm_files_107_87);
									       {
										  obj_t list1334_217;
										  {
										     obj_t arg1337_218;
										     {
											obj_t arg1339_219;
											arg1339_219 = MAKE_PAIR(string1488_engine_link, BNIL);
											arg1337_218 = MAKE_PAIR(arg1332_215, arg1339_219);
										     }
										     list1334_217 = MAKE_PAIR(string1488_engine_link, arg1337_218);
										  }
										  arg1326_210 = string_append_106___r4_strings_6_7(list1334_217);
									       }
									    }
									    {
									       obj_t list1327_211;
									       {
										  obj_t arg1328_212;
										  arg1328_212 = MAKE_PAIR(arg1326_210, BNIL);
										  list1327_211 = MAKE_PAIR(name_155, arg1328_212);
									       }
									       arg1325_209 = list1327_211;
									    }
									 }
									 arg1322_206 = MAKE_PAIR(arg1325_209, cls_88);
								      }
								      arg1323_207 = CAR(scm_files_107_87);
								      {
									 obj_t arg1342_221;
									 {
									    obj_t aux_769;
									    {
									       obj_t aux_770;
									       aux_770 = CDR(exp_154);
									       aux_769 = CDR(aux_770);
									    }
									    arg1342_221 = find_libraries_1_engine_link(aux_769);
									 }
									 arg1324_208 = append_2_18___r4_pairs_and_lists_6_3(arg1342_221, libraries_91);
								      }
								      {
									 obj_t libraries_779;
									 obj_t fmain_778;
									 obj_t main_777;
									 obj_t cls_776;
									 obj_t scm_files_107_775;
									 scm_files_107_775 = arg1321_205;
									 cls_776 = arg1322_206;
									 main_777 = new_main_52_156;
									 fmain_778 = arg1323_207;
									 libraries_779 = arg1324_208;
									 libraries_91 = libraries_779;
									 fmain_90 = fmain_778;
									 main_89 = main_777;
									 cls_88 = cls_776;
									 scm_files_107_87 = scm_files_107_775;
									 goto loop_92;
								      }
								   }
								}
							      else
								{
								   obj_t g_119_66_782;
								   g_119_66_782 = CDR(g_119_66_168);
								   g_119_66_168 = g_119_66_782;
								   goto try_120_69_189;
								}
							   }
							 else
							   {
							      obj_t g_119_66_784;
							      g_119_66_784 = CDR(g_119_66_168);
							      g_119_66_168 = g_119_66_784;
							      goto try_120_69_189;
							   }
						      }
						    else
						      {
							 obj_t g_119_66_786;
							 g_119_66_786 = CDR(g_119_66_168);
							 g_119_66_168 = g_119_66_786;
							 goto try_120_69_189;
						      }
						 }
					      }
					    else
					      {
						 obj_t g_119_66_788;
						 g_119_66_788 = CDR(g_119_66_168);
						 g_119_66_168 = g_119_66_788;
						 goto try_120_69_189;
					      }
					 }
				       else
					 {
					    {
					       obj_t aux_808;
					       aux_808 = CDR(exp_154);
					       name_158 = CAR(aux_808);
					    }
					    {
					       obj_t arg1344_223;
					       obj_t arg1345_224;
					       obj_t arg1347_225;
					       arg1344_223 = CDR(scm_files_107_87);
					       {
						  obj_t arg1349_226;
						  {
						     obj_t arg1350_227;
						     {
							obj_t arg1356_232;
							arg1356_232 = CAR(scm_files_107_87);
							{
							   obj_t list1358_234;
							   {
							      obj_t arg1361_235;
							      {
								 obj_t arg1363_236;
								 arg1363_236 = MAKE_PAIR(string1488_engine_link, BNIL);
								 arg1361_235 = MAKE_PAIR(arg1356_232, arg1363_236);
							      }
							      list1358_234 = MAKE_PAIR(string1488_engine_link, arg1361_235);
							   }
							   arg1350_227 = string_append_106___r4_strings_6_7(list1358_234);
							}
						     }
						     {
							obj_t list1351_228;
							{
							   obj_t arg1352_229;
							   arg1352_229 = MAKE_PAIR(arg1350_227, BNIL);
							   list1351_228 = MAKE_PAIR(name_158, arg1352_229);
							}
							arg1349_226 = list1351_228;
						     }
						  }
						  arg1345_224 = MAKE_PAIR(arg1349_226, cls_88);
					       }
					       {
						  obj_t arg1365_238;
						  {
						     obj_t aux_799;
						     {
							obj_t aux_800;
							aux_800 = CDR(exp_154);
							aux_799 = CDR(aux_800);
						     }
						     arg1365_238 = find_libraries_1_engine_link(aux_799);
						  }
						  arg1347_225 = append_2_18___r4_pairs_and_lists_6_3(arg1365_238, libraries_91);
					       }
					       {
						  obj_t libraries_807;
						  obj_t cls_806;
						  obj_t scm_files_107_805;
						  scm_files_107_805 = arg1344_223;
						  cls_806 = arg1345_224;
						  libraries_807 = arg1347_225;
						  libraries_91 = libraries_807;
						  cls_88 = cls_806;
						  scm_files_107_87 = scm_files_107_805;
						  goto loop_92;
					       }
					    }
					 }
				    }
				  else
				    {
				     tag_103_156_160:
				       {
					  obj_t scm_files_107_812;
					  scm_files_107_812 = CDR(scm_files_107_87);
					  scm_files_107_87 = scm_files_107_812;
					  goto loop_92;
				       }
				    }
			       }
			     else
			       {
				  goto tag_103_156_160;
			       }
			  }
		       }
		     else
		       {
			  goto tag_103_156_160;
		       }
		  }
	       }
	     else
	       {
		  FAILURE(string1478_engine_link, string1492_engine_link, CAR(scm_files_107_87));
	       }
	  }
     }
}


/* handling_function1273 */ obj_t 
handling_function1273_engine_link()
{
   jmp_buf jmpbuf;
   obj_t an_exit1008_150;
   if (SET_EXIT(an_exit1008_150))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1008_150 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1008_150, ((bool_t) 0));
	   {
	      obj_t val1009_151;
	      val1009_151 = compiler_engine_compiler();
	      POP_EXIT();
	      return val1009_151;
	   }
	}
     }
}


/* find-libraries */ obj_t 
find_libraries_1_engine_link(obj_t clauses_5)
{
   {
      obj_t clauses_248;
      obj_t libraries_249;
      clauses_248 = clauses_5;
      libraries_249 = BNIL;
    loop_250:
      {
	 if ((clauses_248 == BNIL))
	   {
	      return reverse__39___r4_pairs_and_lists_6_3(libraries_249);
	   }
	 else
	   {
	      if (PAIRP(clauses_248))
		{
		   obj_t car_166_211_260;
		   car_166_211_260 = CAR(clauses_248);
		   if (PAIRP(car_166_211_260))
		     {
			bool_t test_829;
			{
			   obj_t aux_832;
			   obj_t aux_830;
			   aux_832 = CNST_TABLE_REF(((long) 2));
			   aux_830 = CAR(car_166_211_260);
			   test_829 = (aux_830 == aux_832);
			}
			if (test_829)
			  {
			     obj_t libraries_837;
			     obj_t clauses_835;
			     clauses_835 = CDR(clauses_248);
			     libraries_837 = append_2_18___r4_pairs_and_lists_6_3(CDR(car_166_211_260), libraries_249);
			     libraries_249 = libraries_837;
			     clauses_248 = clauses_835;
			     goto loop_250;
			  }
			else
			  {
			   tag_158_23_256:
			     {
				obj_t clauses_840;
				clauses_840 = CDR(clauses_248);
				clauses_248 = clauses_840;
				goto loop_250;
			     }
			  }
		     }
		   else
		     {
			goto tag_158_23_256;
		     }
		}
	      else
		{
		   goto tag_158_23_256;
		}
	   }
      }
   }
}


/* make-tmp-main */ obj_t 
make_tmp_main_229_engine_link(obj_t clauses_6, obj_t main_7, obj_t libraries_8)
{
   {
      obj_t pout_270;
      pout_270 = open_output_file(_tmp_main_file_name__139_engine_link);
      if (OUTPUT_PORTP(pout_270))
	{
	   {
	      obj_t list1395_272;
	      {
		 obj_t arg1397_274;
		 arg1397_274 = MAKE_PAIR(_bigloo_name__170_engine_param, BNIL);
		 list1395_272 = MAKE_PAIR(string1493_engine_link, arg1397_274);
	      }
	      fprint___r4_output_6_10_3(pout_270, list1395_272);
	   }
	   {
	      obj_t list1399_276;
	      list1399_276 = MAKE_PAIR(string1494_engine_link, BNIL);
	      fprint___r4_output_6_10_3(pout_270, list1399_276);
	   }
	   {
	      obj_t list1403_279;
	      list1403_279 = MAKE_PAIR(string1495_engine_link, BNIL);
	      fprint___r4_output_6_10_3(pout_270, list1403_279);
	   }
	   {
	      obj_t list1408_282;
	      list1408_282 = MAKE_PAIR(pout_270, BNIL);
	      newline___r4_output_6_10_3(list1408_282);
	   }
	   {
	      bool_t test1411_284;
	      if (CBOOL(main_7))
		{
		   test1411_284 = ((bool_t) 0);
		}
	      else
		{
		   long n1_494;
		   n1_494 = (long) CINT(_bdb_debug__1_engine_param);
		   test1411_284 = (n1_494 > ((long) 0));
		}
	      if (test1411_284)
		{
		   obj_t list1412_285;
		   {
		      obj_t arg1414_287;
		      {
			 obj_t arg1416_289;
			 arg1416_289 = MAKE_PAIR(string1496_engine_link, BNIL);
			 arg1414_287 = MAKE_PAIR(string1497_engine_link, arg1416_289);
		      }
		      list1412_285 = MAKE_PAIR(string1482_engine_link, arg1414_287);
		   }
		   warning___error(list1412_285);
		}
	      else
		{
		   BUNSPEC;
		}
	   }
	   {
	      obj_t libs_292;
	      libs_292 = libraries_8;
	      {
		 obj_t module_293;
		 {
		    obj_t arg1426_298;
		    obj_t arg1427_299;
		    obj_t arg1428_300;
		    obj_t arg1431_301;
		    arg1426_298 = CNST_TABLE_REF(((long) 0));
		    arg1427_299 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
		    {
		       obj_t arg1440_307;
		       obj_t arg1441_308;
		       arg1440_307 = CNST_TABLE_REF(((long) 3));
		       {
			  obj_t arg1444_311;
			  obj_t arg1446_312;
			  arg1444_311 = reverse___r4_pairs_and_lists_6_3(clauses_6);
			  arg1446_312 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			  arg1441_308 = append_2_18___r4_pairs_and_lists_6_3(arg1444_311, arg1446_312);
		       }
		       {
			  obj_t list1442_309;
			  list1442_309 = MAKE_PAIR(arg1441_308, BNIL);
			  arg1428_300 = cons__138___r4_pairs_and_lists_6_3(arg1440_307, list1442_309);
		       }
		    }
		    {
		       obj_t arg1450_315;
		       obj_t arg1453_316;
		       if (PAIRP(libs_292))
			 {
			    obj_t arg1455_318;
			    {
			       obj_t arg1460_322;
			       obj_t arg1461_323;
			       arg1460_322 = CNST_TABLE_REF(((long) 2));
			       {
				  obj_t arg1464_326;
				  arg1464_326 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				  arg1461_323 = append_2_18___r4_pairs_and_lists_6_3(libs_292, arg1464_326);
			       }
			       {
				  obj_t list1462_324;
				  list1462_324 = MAKE_PAIR(arg1461_323, BNIL);
				  arg1455_318 = cons__138___r4_pairs_and_lists_6_3(arg1460_322, list1462_324);
			       }
			    }
			    {
			       obj_t list1457_320;
			       list1457_320 = MAKE_PAIR(BNIL, BNIL);
			       arg1450_315 = cons__138___r4_pairs_and_lists_6_3(arg1455_318, list1457_320);
			    }
			 }
		       else
			 {
			    arg1450_315 = BNIL;
			 }
		       arg1453_316 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		       arg1431_301 = append_2_18___r4_pairs_and_lists_6_3(arg1450_315, arg1453_316);
		    }
		    {
		       obj_t list1432_302;
		       {
			  obj_t arg1433_303;
			  {
			     obj_t arg1436_304;
			     arg1436_304 = MAKE_PAIR(arg1431_301, BNIL);
			     arg1433_303 = MAKE_PAIR(arg1428_300, arg1436_304);
			  }
			  list1432_302 = MAKE_PAIR(arg1427_299, arg1433_303);
		       }
		       module_293 = cons__138___r4_pairs_and_lists_6_3(arg1426_298, list1432_302);
		    }
		 }
		 {
		    {
		       obj_t list1419_294;
		       list1419_294 = MAKE_PAIR(module_293, BNIL);
		       fprint___r4_output_6_10_3(pout_270, list1419_294);
		    }
		    {
		       obj_t list1422_296;
		       list1422_296 = MAKE_PAIR(pout_270, BNIL);
		       newline___r4_output_6_10_3(list1422_296);
		    }
		 }
	      }
	   }
	   if (CBOOL(main_7))
	     {
		{
		   obj_t list1471_333;
		   list1471_333 = MAKE_PAIR(string1498_engine_link, BNIL);
		   fprint___r4_output_6_10_3(pout_270, list1471_333);
		}
		{
		   obj_t list1475_336;
		   list1475_336 = MAKE_PAIR(pout_270, BNIL);
		   newline___r4_output_6_10_3(list1475_336);
		}
	     }
	   else
	     {
		BUNSPEC;
	     }
	   return close_output_port(pout_270);
	}
      else
	{
	   FAILURE(string1478_engine_link, string1499_engine_link, _tmp_main_file_name__139_engine_link);
	}
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_engine_link()
{
   module_initialization_70_cc_ld(((long) 0), "ENGINE_LINK");
   module_initialization_70_read_reader(((long) 0), "ENGINE_LINK");
   module_initialization_70_engine_compiler(((long) 0), "ENGINE_LINK");
   module_initialization_70_engine_param(((long) 0), "ENGINE_LINK");
   module_initialization_70_bdb_setting(((long) 0), "ENGINE_LINK");
   module_initialization_70_module_alibrary(((long) 0), "ENGINE_LINK");
   module_initialization_70_tools_error(((long) 0), "ENGINE_LINK");
   return module_initialization_70_tools_file(((long) 0), "ENGINE_LINK");
}
