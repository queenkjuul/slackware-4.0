/*===========================================================================*/
/*   (Prof/emit.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_prof_emit();
static obj_t _emit_prof_info_49_prof_emit(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_prof_emit(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_cgen_prototype(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t emit_prof_info_80_prof_emit(obj_t, obj_t);
static obj_t imported_modules_init_94_prof_emit();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t _prof_table_name__107_engine_param;
static obj_t library_modules_init_112_prof_emit();
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t toplevel_init_63_prof_emit();
extern obj_t set_variable_name__102_cgen_prototype(obj_t);
static obj_t require_initialization_114_prof_emit = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(emit_prof_info_env_134_prof_emit, _emit_prof_info_49_prof_emit1649, _emit_prof_info_49_prof_emit, 0L, 2);
DEFINE_STRING(string1647_prof_emit, string1647_prof_emit1650, "}\n", 2);
DEFINE_STRING(string1646_prof_emit, string1646_prof_emit1651, "   return BUNSPEC;", 18);
DEFINE_STRING(string1645_prof_emit, string1645_prof_emit1652, "   }", 4);
DEFINE_STRING(string1644_prof_emit, string1644_prof_emit1653, "      fprintf( (FILE *)bprof_port, \"(", 37);
DEFINE_STRING(string1643_prof_emit, string1643_prof_emit1654, " \\\"", 3);
DEFINE_STRING(string1642_prof_emit, string1642_prof_emit1655, "\\\")\\n\" );", 9);
DEFINE_STRING(string1641_prof_emit, string1641_prof_emit1656, "   if( bprof_port ) {", 21);
DEFINE_STRING(string1639_prof_emit, string1639_prof_emit1657, "\", \"w\" );", 9);
DEFINE_STRING(string1640_prof_emit, string1640_prof_emit1658, "   if( bprof_port == BUNSPEC ) bprof_port = (obj_t)fopen( \"", 59);
DEFINE_STRING(string1638_prof_emit, string1638_prof_emit1659, "   extern obj_t bprof_port;", 27);
DEFINE_STRING(string1637_prof_emit, string1637_prof_emit1660, "static obj_t write_bprof_table() {", 34);
DEFINE_STRING(string1636_prof_emit, string1636_prof_emit1661, "/* prof association table */", 28);


/* module-initialization */ obj_t 
module_initialization_70_prof_emit(long checksum_1191, char *from_1192)
{
   if (CBOOL(require_initialization_114_prof_emit))
     {
	require_initialization_114_prof_emit = BBOOL(((bool_t) 0));
	library_modules_init_112_prof_emit();
	imported_modules_init_94_prof_emit();
	method_init_76_prof_emit();
	toplevel_init_63_prof_emit();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_prof_emit()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "PROF_EMIT");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_prof_emit()
{
   return BUNSPEC;
}


/* emit-prof-info */ obj_t 
emit_prof_info_80_prof_emit(obj_t globals_33, obj_t port_34)
{
   {
      obj_t list1485_771;
      list1485_771 = MAKE_PAIR(port_34, BNIL);
      newline___r4_output_6_10_3(list1485_771);
   }
   {
      obj_t list1487_773;
      list1487_773 = MAKE_PAIR(port_34, BNIL);
      newline___r4_output_6_10_3(list1487_773);
   }
   {
      obj_t list1489_775;
      list1489_775 = MAKE_PAIR(string1636_prof_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1489_775);
   }
   {
      obj_t list1492_778;
      list1492_778 = MAKE_PAIR(string1637_prof_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1492_778);
   }
   {
      obj_t list1497_781;
      list1497_781 = MAKE_PAIR(string1638_prof_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1497_781);
   }
   {
      obj_t list1500_784;
      {
	 obj_t arg1502_786;
	 {
	    obj_t arg1503_787;
	    arg1503_787 = MAKE_PAIR(string1639_prof_emit, BNIL);
	    arg1502_786 = MAKE_PAIR(_prof_table_name__107_engine_param, arg1503_787);
	 }
	 list1500_784 = MAKE_PAIR(string1640_prof_emit, arg1502_786);
      }
      fprint___r4_output_6_10_3(port_34, list1500_784);
   }
   {
      obj_t list1506_790;
      list1506_790 = MAKE_PAIR(string1641_prof_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1506_790);
   }
   {
      obj_t l1443_793;
      l1443_793 = globals_33;
    lname1444_794:
      if (PAIRP(l1443_793))
	{
	   {
	      obj_t global_796;
	      global_796 = CAR(l1443_793);
	      {
		 bool_t test_1220;
		 {
		    global_t obj_1180;
		    obj_1180 = (global_t) (global_796);
		    test_1220 = (((global_t) CREF(obj_1180))->user__32);
		 }
		 if (test_1220)
		   {
		      set_variable_name__102_cgen_prototype(global_796);
		      {
			 obj_t id_800;
			 obj_t c_name_211_801;
			 {
			    global_t obj_1183;
			    obj_1183 = (global_t) (global_796);
			    id_800 = (((global_t) CREF(obj_1183))->id);
			 }
			 {
			    global_t obj_1184;
			    obj_1184 = (global_t) (global_796);
			    c_name_211_801 = (((global_t) CREF(obj_1184))->name);
			 }
			 {
			    obj_t list1513_802;
			    {
			       obj_t arg1515_804;
			       {
				  obj_t arg1516_805;
				  {
				     obj_t arg1518_807;
				     {
					obj_t arg1519_808;
					arg1519_808 = MAKE_PAIR(string1642_prof_emit, BNIL);
					arg1518_807 = MAKE_PAIR(c_name_211_801, arg1519_808);
				     }
				     arg1516_805 = MAKE_PAIR(string1643_prof_emit, arg1518_807);
				  }
				  arg1515_804 = MAKE_PAIR(id_800, arg1516_805);
			       }
			       list1513_802 = MAKE_PAIR(string1644_prof_emit, arg1515_804);
			    }
			    fprint___r4_output_6_10_3(port_34, list1513_802);
			 }
		      }
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
	   {
	      obj_t l1443_1234;
	      l1443_1234 = CDR(l1443_793);
	      l1443_793 = l1443_1234;
	      goto lname1444_794;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t list1526_812;
      list1526_812 = MAKE_PAIR(string1645_prof_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1526_812);
   }
   {
      obj_t list1529_815;
      list1529_815 = MAKE_PAIR(string1646_prof_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1529_815);
   }
   {
      obj_t list1532_818;
      list1532_818 = MAKE_PAIR(string1647_prof_emit, BNIL);
      return fprint___r4_output_6_10_3(port_34, list1532_818);
   }
}


/* _emit-prof-info */ obj_t 
_emit_prof_info_49_prof_emit(obj_t env_1186, obj_t globals_1187, obj_t port_1188)
{
   return emit_prof_info_80_prof_emit(globals_1187, port_1188);
}


/* method-init */ obj_t 
method_init_76_prof_emit()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_prof_emit()
{
   module_initialization_70_type_type(((long) 0), "PROF_EMIT");
   module_initialization_70_ast_var(((long) 0), "PROF_EMIT");
   module_initialization_70_ast_node(((long) 0), "PROF_EMIT");
   module_initialization_70_tools_shape(((long) 0), "PROF_EMIT");
   module_initialization_70_tools_error(((long) 0), "PROF_EMIT");
   module_initialization_70_tools_misc(((long) 0), "PROF_EMIT");
   module_initialization_70_type_env(((long) 0), "PROF_EMIT");
   module_initialization_70_type_cache(((long) 0), "PROF_EMIT");
   module_initialization_70_ast_sexp(((long) 0), "PROF_EMIT");
   module_initialization_70_ast_env(((long) 0), "PROF_EMIT");
   module_initialization_70_ast_ident(((long) 0), "PROF_EMIT");
   module_initialization_70_ast_unit(((long) 0), "PROF_EMIT");
   module_initialization_70_module_module(((long) 0), "PROF_EMIT");
   module_initialization_70_module_include(((long) 0), "PROF_EMIT");
   module_initialization_70_engine_param(((long) 0), "PROF_EMIT");
   return module_initialization_70_cgen_prototype(((long) 0), "PROF_EMIT");
}
