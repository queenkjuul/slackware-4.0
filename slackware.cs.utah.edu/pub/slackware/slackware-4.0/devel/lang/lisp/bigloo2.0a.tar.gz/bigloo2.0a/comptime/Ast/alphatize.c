/*===========================================================================*/
/*   (Ast/alphatize.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_alphatize();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern node_t known_app_ly__node_26_ast_apply(obj_t, obj_t, node_t, node_t, obj_t);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
static obj_t _location__189_ast_alphatize = BUNSPEC;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
static obj_t _alphatize2151_ast_alphatize(obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_ast_alphatize(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_apply(long, char *);
extern obj_t module_initialization_70_ast_app(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_ast_alphatize();
extern bool_t correct_arity_app__187_ast_app(variable_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static node_t do_alphatize_126_ast_alphatize(node_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_alphatize();
static obj_t _do_alphatize_default1562_187_ast_alphatize(obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_alphatize();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t use_variable__4_ast_sexp(variable_t, obj_t, obj_t);
extern local_t make_local_sfun_184_ast_local(obj_t, type_t, sfun_t);
extern node_t alphatize_ast_alphatize(obj_t, obj_t, obj_t, node_t);
extern obj_t sfun_ast_var;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t variable_ast_var;
static node_t do_alphatize_default1562_195_ast_alphatize(node_t);
static obj_t _do_alphatize2152_238_ast_alphatize(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern local_t make_local_sexit_184_ast_local(obj_t, type_t, sexit_t);
extern obj_t sexit_ast_var;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern node_t make_app_node_80_ast_app(obj_t, obj_t, var_t, obj_t);
static obj_t require_initialization_114_ast_alphatize = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_alphatize();
extern obj_t user_error_location_137_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t get_location_95_ast_alphatize(obj_t);
static obj_t __cnst[4];

DEFINE_STATIC_PROCEDURE(do_alphatize_default1562_env_57_ast_alphatize, _do_alphatize_default1562_187_ast_alphatize2164, _do_alphatize_default1562_187_ast_alphatize, 0L, 1);
DEFINE_EXPORT_PROCEDURE(alphatize_env_10_ast_alphatize, _alphatize2151_ast_alphatize2165, _alphatize2151_ast_alphatize, 0L, 4);
DEFINE_STATIC_GENERIC(do_alphatize_env_178_ast_alphatize, _do_alphatize2152_238_ast_alphatize2166, _do_alphatize2152_238_ast_alphatize, 0L, 1);
DEFINE_STRING(string2158_ast_alphatize, string2158_ast_alphatize2167, "DO-ALPHATIZE-DEFAULT1562 SET! VALUE LOCATION ", 45);
DEFINE_STRING(string2157_ast_alphatize, string2157_ast_alphatize2168, "No method for this object", 25);
DEFINE_STRING(string2156_ast_alphatize, string2156_ast_alphatize2169, "wrong number of argument(s)", 27);
DEFINE_STRING(string2155_ast_alphatize, string2155_ast_alphatize2170, "Illegal application", 19);
DEFINE_STRING(string2154_ast_alphatize, string2154_ast_alphatize2171, "Illegal alphatization", 21);
DEFINE_STRING(string2153_ast_alphatize, string2153_ast_alphatize2172, "alphatize", 9);


/* module-initialization */ obj_t 
module_initialization_70_ast_alphatize(long checksum_2695, char *from_2696)
{
   if (CBOOL(require_initialization_114_ast_alphatize))
     {
	require_initialization_114_ast_alphatize = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_alphatize();
	cnst_init_137_ast_alphatize();
	imported_modules_init_94_ast_alphatize();
	method_init_76_ast_alphatize();
	toplevel_init_63_ast_alphatize();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_alphatize()
{
   module_initialization_70___object(((long) 0), "AST_ALPHATIZE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_ALPHATIZE");
   module_initialization_70___reader(((long) 0), "AST_ALPHATIZE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_alphatize()
{
   {
      obj_t cnst_port_138_2687;
      cnst_port_138_2687 = open_input_string(string2158_ast_alphatize);
      {
	 long i_2688;
	 i_2688 = ((long) 3);
       loop_2689:
	 {
	    bool_t test2159_2690;
	    test2159_2690 = (i_2688 == ((long) -1));
	    if (test2159_2690)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2160_2691;
		    {
		       obj_t list2161_2692;
		       {
			  obj_t arg2162_2693;
			  arg2162_2693 = BNIL;
			  list2161_2692 = MAKE_PAIR(cnst_port_138_2687, arg2162_2693);
		       }
		       arg2160_2691 = read___reader(list2161_2692);
		    }
		    CNST_TABLE_SET(i_2688, arg2160_2691);
		 }
		 {
		    int aux_2694;
		    {
		       long aux_2714;
		       aux_2714 = (i_2688 - ((long) 1));
		       aux_2694 = (int) (aux_2714);
		    }
		    {
		       long i_2717;
		       i_2717 = (long) (aux_2694);
		       i_2688 = i_2717;
		       goto loop_2689;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_alphatize()
{
   _location__189_ast_alphatize = BFALSE;
   return BUNSPEC;
}


/* alphatize */ node_t 
alphatize_ast_alphatize(obj_t what__148_15, obj_t by__251_16, obj_t loc_17, node_t node_18)
{
   {
      obj_t ll1435_751;
      obj_t ll1436_752;
      ll1435_751 = what__148_15;
      ll1436_752 = by__251_16;
    lname1437_753:
      if (NULLP(ll1435_751))
	{
	   ((bool_t) 1);
	}
      else
	{
	   {
	      obj_t by_756;
	      by_756 = CAR(ll1436_752);
	      {
		 variable_t obj_1659;
		 {
		    obj_t aux_2722;
		    aux_2722 = CAR(ll1435_751);
		    obj_1659 = (variable_t) (aux_2722);
		 }
		 ((((variable_t) CREF(obj_1659))->fast_alpha_7) = ((obj_t) by_756), BUNSPEC);
	      }
	   }
	   {
	      obj_t ll1436_2728;
	      obj_t ll1435_2726;
	      ll1435_2726 = CDR(ll1435_751);
	      ll1436_2728 = CDR(ll1436_752);
	      ll1436_752 = ll1436_2728;
	      ll1435_751 = ll1435_2726;
	      goto lname1437_753;
	   }
	}
   }
   _location__189_ast_alphatize = loc_17;
   {
      node_t res_759;
      res_759 = do_alphatize_126_ast_alphatize(node_18);
      {
	 obj_t l1438_760;
	 l1438_760 = what__148_15;
       lname1439_761:
	 if (PAIRP(l1438_760))
	   {
	      {
		 variable_t obj_1665;
		 {
		    obj_t aux_2733;
		    aux_2733 = CAR(l1438_760);
		    obj_1665 = (variable_t) (aux_2733);
		 }
		 ((((variable_t) CREF(obj_1665))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
	      }
	      {
		 obj_t l1438_2737;
		 l1438_2737 = CDR(l1438_760);
		 l1438_760 = l1438_2737;
		 goto lname1439_761;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      return res_759;
   }
}


/* _alphatize2151 */ obj_t 
_alphatize2151_ast_alphatize(obj_t env_2677, obj_t what__148_2678, obj_t by__251_2679, obj_t loc_2680, obj_t node_2681)
{
   {
      node_t aux_2739;
      aux_2739 = alphatize_ast_alphatize(what__148_2678, by__251_2679, loc_2680, (node_t) (node_2681));
      return (obj_t) (aux_2739);
   }
}


/* get-location */ obj_t 
get_location_95_ast_alphatize(obj_t node_19)
{
   {
      bool_t test_2743;
      {
	 obj_t arg1615_766;
	 {
	    node_t obj_1668;
	    obj_1668 = (node_t) (node_19);
	    arg1615_766 = (((node_t) CREF(obj_1668))->loc);
	 }
	 if (STRUCTP(arg1615_766))
	   {
	      obj_t aux_2750;
	      obj_t aux_2748;
	      aux_2750 = CNST_TABLE_REF(((long) 0));
	      aux_2748 = STRUCT_KEY(arg1615_766);
	      test_2743 = (aux_2748 == aux_2750);
	   }
	 else
	   {
	      test_2743 = ((bool_t) 0);
	   }
      }
      if (test_2743)
	{
	   node_t obj_1677;
	   obj_1677 = (node_t) (node_19);
	   return (((node_t) CREF(obj_1677))->loc);
	}
      else
	{
	   return _location__189_ast_alphatize;
	}
   }
}


/* method-init */ obj_t 
method_init_76_ast_alphatize()
{
   add_generic__110___object(do_alphatize_env_178_ast_alphatize, do_alphatize_default1562_env_57_ast_alphatize);
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, var_ast_node, ((long) 1));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, closure_ast_node, ((long) 2));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, kwote_ast_node, ((long) 3));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, app_ast_node, ((long) 5));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, select_ast_node, ((long) 13));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, make_box_202_ast_node, ((long) 14));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, box_ref_242_ast_node, ((long) 15));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, box_set__221_ast_node, ((long) 16));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, let_fun_218_ast_node, ((long) 17));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, let_var_6_ast_node, ((long) 18));
   add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, set_ex_it_116_ast_node, ((long) 19));
   {
      long aux_2776;
      aux_2776 = add_inlined_method__244___object(do_alphatize_env_178_ast_alphatize, jump_ex_it_184_ast_node, ((long) 20));
      return BINT(aux_2776);
   }
}


/* do-alphatize */ node_t 
do_alphatize_126_ast_alphatize(node_t node_20)
{
   {
      obj_t method1708_1098;
      obj_t class1713_1099;
      {
	 obj_t arg1716_1096;
	 obj_t arg1717_1097;
	 {
	    object_t obj_1884;
	    obj_1884 = (object_t) (node_20);
	    {
	       obj_t pre_method_105_1885;
	       pre_method_105_1885 = PROCEDURE_REF(do_alphatize_env_178_ast_alphatize, ((long) 2));
	       if (INTEGERP(pre_method_105_1885))
		 {
		    PROCEDURE_SET(do_alphatize_env_178_ast_alphatize, ((long) 2), BUNSPEC);
		    arg1716_1096 = pre_method_105_1885;
		 }
	       else
		 {
		    long obj_class_num_177_1890;
		    obj_class_num_177_1890 = TYPE(obj_1884);
		    {
		       obj_t arg1177_1891;
		       arg1177_1891 = PROCEDURE_REF(do_alphatize_env_178_ast_alphatize, ((long) 1));
		       {
			  long arg1178_1895;
			  {
			     long arg1179_1896;
			     arg1179_1896 = OBJECT_TYPE;
			     arg1178_1895 = (obj_class_num_177_1890 - arg1179_1896);
			  }
			  arg1716_1096 = VECTOR_REF(arg1177_1891, arg1178_1895);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1901;
	    object_1901 = (object_t) (node_20);
	    {
	       long arg1180_1902;
	       {
		  long arg1181_1903;
		  long arg1182_1904;
		  arg1181_1903 = TYPE(object_1901);
		  arg1182_1904 = OBJECT_TYPE;
		  arg1180_1902 = (arg1181_1903 - arg1182_1904);
	       }
	       {
		  obj_t vector_1908;
		  vector_1908 = _classes__134___object;
		  arg1717_1097 = VECTOR_REF(vector_1908, arg1180_1902);
	       }
	    }
	 }
	 {
	    obj_t aux_2794;
	    method1708_1098 = arg1716_1096;
	    class1713_1099 = arg1717_1097;
	    {
	       if (INTEGERP(method1708_1098))
		 {
		    switch ((long) CINT(method1708_1098))
		      {
		      case ((long) 0):
			 {
			    atom_t node_1105;
			    node_1105 = (atom_t) (node_20);
			    {
			       atom_t new1441_1107;
			       {
				  obj_t arg1720_1108;
				  type_t arg1721_1109;
				  obj_t arg1722_1110;
				  arg1720_1108 = get_location_95_ast_alphatize((obj_t) (node_1105));
				  arg1721_1109 = (((atom_t) CREF(node_1105))->type);
				  arg1722_1110 = (((atom_t) CREF(node_1105))->value);
				  {
				     atom_t res2116_1922;
				     {
					atom_t new1198_1915;
					new1198_1915 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
					{
					   long arg1672_1916;
					   arg1672_1916 = class_num_218___object(atom_ast_node);
					   {
					      obj_t obj_1920;
					      obj_1920 = (obj_t) (new1198_1915);
					      (((obj_t) CREF(obj_1920))->header = MAKE_HEADER(arg1672_1916, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_2806;
					   aux_2806 = (object_t) (new1198_1915);
					   OBJECT_WIDENING_SET(aux_2806, BFALSE);
					}
					((((atom_t) CREF(new1198_1915))->loc) = ((obj_t) arg1720_1108), BUNSPEC);
					((((atom_t) CREF(new1198_1915))->type) = ((type_t) arg1721_1109), BUNSPEC);
					((((atom_t) CREF(new1198_1915))->value) = ((obj_t) arg1722_1110), BUNSPEC);
					res2116_1922 = new1198_1915;
				     }
				     new1441_1107 = res2116_1922;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1441_1107);
			       }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    var_t node_1111;
			    node_1111 = (var_t) (node_20);
			    {
			       variable_t var_1112;
			       var_1112 = (((var_t) CREF(node_1111))->variable);
			       {
				  obj_t alpha_1113;
				  alpha_1113 = (((variable_t) CREF(var_1112))->fast_alpha_7);
				  {
				     if ((alpha_1113 == BUNSPEC))
				       {
					  {
					     obj_t aux_2818;
					     {
						node_t obj_1927;
						obj_1927 = (node_t) (node_1111);
						aux_2818 = (((node_t) CREF(obj_1927))->loc);
					     }
					     use_variable__4_ast_sexp(var_1112, aux_2818, CNST_TABLE_REF(((long) 1)));
					  }
					  {
					     var_t new1443_1118;
					     {
						obj_t arg1726_1119;
						type_t arg1727_1120;
						variable_t arg1728_1121;
						arg1726_1119 = get_location_95_ast_alphatize((obj_t) (node_1111));
						arg1727_1120 = (((var_t) CREF(node_1111))->type);
						arg1728_1121 = (((var_t) CREF(node_1111))->variable);
						{
						   var_t res2117_1940;
						   {
						      var_t new1206_1933;
						      new1206_1933 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						      {
							 long arg1669_1934;
							 arg1669_1934 = class_num_218___object(var_ast_node);
							 {
							    obj_t obj_1938;
							    obj_1938 = (obj_t) (new1206_1933);
							    (((obj_t) CREF(obj_1938))->header = MAKE_HEADER(arg1669_1934, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_2831;
							 aux_2831 = (object_t) (new1206_1933);
							 OBJECT_WIDENING_SET(aux_2831, BFALSE);
						      }
						      ((((var_t) CREF(new1206_1933))->loc) = ((obj_t) arg1726_1119), BUNSPEC);
						      ((((var_t) CREF(new1206_1933))->type) = ((type_t) arg1727_1120), BUNSPEC);
						      ((((var_t) CREF(new1206_1933))->variable) = ((variable_t) arg1728_1121), BUNSPEC);
						      res2117_1940 = new1206_1933;
						   }
						   new1443_1118 = res2117_1940;
						}
					     }
					     {
						aux_2794 = (obj_t) (new1443_1118);
					     }
					  }
				       }
				     else
				       {
					  bool_t test1729_1122;
					  test1729_1122 = is_a__118___object(alpha_1113, variable_ast_var);
					  if (test1729_1122)
					    {
					       {
						  obj_t aux_2840;
						  {
						     node_t obj_1942;
						     obj_1942 = (node_t) (node_1111);
						     aux_2840 = (((node_t) CREF(obj_1942))->loc);
						  }
						  use_variable__4_ast_sexp((variable_t) (alpha_1113), aux_2840, CNST_TABLE_REF(((long) 1)));
					       }
					       {
						  bool_t test1732_1125;
						  {
						     obj_t aux_2846;
						     {
							value_t aux_2847;
							{
							   variable_t obj_1943;
							   obj_1943 = (variable_t) (alpha_1113);
							   aux_2847 = (((variable_t) CREF(obj_1943))->value);
							}
							aux_2846 = (obj_t) (aux_2847);
						     }
						     test1732_1125 = is_a__118___object(aux_2846, fun_ast_var);
						  }
						  if (test1732_1125)
						    {
						       obj_t arg1733_1126;
						       type_t arg1738_1127;
						       arg1733_1126 = get_location_95_ast_alphatize((obj_t) (node_1111));
						       {
							  variable_t obj_1945;
							  obj_1945 = (variable_t) (alpha_1113);
							  arg1738_1127 = (((variable_t) CREF(obj_1945))->type);
						       }
						       {
							  closure_t res2118_1956;
							  {
							     variable_t variable_1948;
							     variable_1948 = (variable_t) (alpha_1113);
							     {
								closure_t new1214_1949;
								new1214_1949 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
								{
								   long arg1667_1950;
								   arg1667_1950 = class_num_218___object(closure_ast_node);
								   {
								      obj_t obj_1954;
								      obj_1954 = (obj_t) (new1214_1949);
								      (((obj_t) CREF(obj_1954))->header = MAKE_HEADER(arg1667_1950, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_2862;
								   aux_2862 = (object_t) (new1214_1949);
								   OBJECT_WIDENING_SET(aux_2862, BFALSE);
								}
								((((closure_t) CREF(new1214_1949))->loc) = ((obj_t) arg1733_1126), BUNSPEC);
								((((closure_t) CREF(new1214_1949))->type) = ((type_t) arg1738_1127), BUNSPEC);
								((((closure_t) CREF(new1214_1949))->variable) = ((variable_t) variable_1948), BUNSPEC);
								res2118_1956 = new1214_1949;
							     }
							  }
							  aux_2794 = (obj_t) (res2118_1956);
						       }
						    }
						  else
						    {
						       var_t new1446_1130;
						       {
							  obj_t arg1740_1131;
							  type_t arg1743_1132;
							  arg1740_1131 = get_location_95_ast_alphatize((obj_t) (node_1111));
							  arg1743_1132 = (((var_t) CREF(node_1111))->type);
							  {
							     var_t res2119_1968;
							     {
								variable_t variable_1960;
								variable_1960 = (variable_t) (alpha_1113);
								{
								   var_t new1206_1961;
								   new1206_1961 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								   {
								      long arg1669_1962;
								      arg1669_1962 = class_num_218___object(var_ast_node);
								      {
									 obj_t obj_1966;
									 obj_1966 = (obj_t) (new1206_1961);
									 (((obj_t) CREF(obj_1966))->header = MAKE_HEADER(arg1669_1962, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_2877;
								      aux_2877 = (object_t) (new1206_1961);
								      OBJECT_WIDENING_SET(aux_2877, BFALSE);
								   }
								   ((((var_t) CREF(new1206_1961))->loc) = ((obj_t) arg1740_1131), BUNSPEC);
								   ((((var_t) CREF(new1206_1961))->type) = ((type_t) arg1743_1132), BUNSPEC);
								   ((((var_t) CREF(new1206_1961))->variable) = ((variable_t) variable_1960), BUNSPEC);
								   res2119_1968 = new1206_1961;
								}
							     }
							     new1446_1130 = res2119_1968;
							  }
						       }
						       {
							  aux_2794 = (obj_t) (new1446_1130);
						       }
						    }
					       }
					    }
					  else
					    {
					       bool_t test1746_1135;
					       test1746_1135 = is_a__118___object(alpha_1113, atom_ast_node);
					       if (test1746_1135)
						 {
						    {
						       atom_t duplicated1447_1136;
						       duplicated1447_1136 = (atom_t) (alpha_1113);
						       {
							  atom_t new1448_1137;
							  {
							     obj_t arg1747_1138;
							     type_t arg1748_1139;
							     obj_t arg1749_1140;
							     arg1747_1138 = (((atom_t) CREF(duplicated1447_1136))->loc);
							     arg1748_1139 = (((atom_t) CREF(duplicated1447_1136))->type);
							     arg1749_1140 = (((atom_t) CREF(duplicated1447_1136))->value);
							     {
								atom_t res2120_1983;
								{
								   atom_t new1198_1976;
								   new1198_1976 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
								   {
								      long arg1672_1977;
								      arg1672_1977 = class_num_218___object(atom_ast_node);
								      {
									 obj_t obj_1981;
									 obj_1981 = (obj_t) (new1198_1976);
									 (((obj_t) CREF(obj_1981))->header = MAKE_HEADER(arg1672_1977, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_2894;
								      aux_2894 = (object_t) (new1198_1976);
								      OBJECT_WIDENING_SET(aux_2894, BFALSE);
								   }
								   ((((atom_t) CREF(new1198_1976))->loc) = ((obj_t) arg1747_1138), BUNSPEC);
								   ((((atom_t) CREF(new1198_1976))->type) = ((type_t) arg1748_1139), BUNSPEC);
								   ((((atom_t) CREF(new1198_1976))->value) = ((obj_t) arg1749_1140), BUNSPEC);
								   res2120_1983 = new1198_1976;
								}
								new1448_1137 = res2120_1983;
							     }
							  }
							  {
							     aux_2794 = (obj_t) (new1448_1137);
							  }
						       }
						    }
						 }
					       else
						 {
						    {
						       obj_t arg1758_1143;
						       arg1758_1143 = shape_tools_shape((obj_t) (node_1111));
						       aux_2794 = internal_error_43_tools_error(string2153_ast_alphatize, string2154_ast_alphatize, arg1758_1143);
						    }
						 }
					    }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    closure_t node_1144;
			    node_1144 = (closure_t) (node_20);
			    {
			       variable_t var_1145;
			       {
				  var_t obj_1984;
				  obj_1984 = (var_t) (node_1144);
				  var_1145 = (((var_t) CREF(obj_1984))->variable);
			       }
			       {
				  obj_t alpha_1146;
				  alpha_1146 = (((variable_t) CREF(var_1145))->fast_alpha_7);
				  {
				     if ((alpha_1146 == BUNSPEC))
				       {
					  {
					     obj_t aux_2910;
					     {
						node_t obj_1988;
						obj_1988 = (node_t) (node_1144);
						aux_2910 = (((node_t) CREF(obj_1988))->loc);
					     }
					     use_variable__4_ast_sexp(var_1145, aux_2910, CNST_TABLE_REF(((long) 1)));
					  }
					  {
					     closure_t new1450_1151;
					     {
						obj_t arg1762_1152;
						type_t arg1765_1153;
						variable_t arg1766_1154;
						arg1762_1152 = get_location_95_ast_alphatize((obj_t) (node_1144));
						arg1765_1153 = (((closure_t) CREF(node_1144))->type);
						arg1766_1154 = (((closure_t) CREF(node_1144))->variable);
						{
						   closure_t res2121_2001;
						   {
						      closure_t new1214_1994;
						      new1214_1994 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
						      {
							 long arg1667_1995;
							 arg1667_1995 = class_num_218___object(closure_ast_node);
							 {
							    obj_t obj_1999;
							    obj_1999 = (obj_t) (new1214_1994);
							    (((obj_t) CREF(obj_1999))->header = MAKE_HEADER(arg1667_1995, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_2923;
							 aux_2923 = (object_t) (new1214_1994);
							 OBJECT_WIDENING_SET(aux_2923, BFALSE);
						      }
						      ((((closure_t) CREF(new1214_1994))->loc) = ((obj_t) arg1762_1152), BUNSPEC);
						      ((((closure_t) CREF(new1214_1994))->type) = ((type_t) arg1765_1153), BUNSPEC);
						      ((((closure_t) CREF(new1214_1994))->variable) = ((variable_t) arg1766_1154), BUNSPEC);
						      res2121_2001 = new1214_1994;
						   }
						   new1450_1151 = res2121_2001;
						}
					     }
					     {
						aux_2794 = (obj_t) (new1450_1151);
					     }
					  }
				       }
				     else
				       {
					  bool_t test1767_1155;
					  test1767_1155 = is_a__118___object(alpha_1146, variable_ast_var);
					  if (test1767_1155)
					    {
					       {
						  obj_t aux_2932;
						  {
						     node_t obj_2003;
						     obj_2003 = (node_t) (node_1144);
						     aux_2932 = (((node_t) CREF(obj_2003))->loc);
						  }
						  use_variable__4_ast_sexp((variable_t) (alpha_1146), aux_2932, CNST_TABLE_REF(((long) 1)));
					       }
					       {
						  closure_t new1452_1159;
						  {
						     obj_t arg1770_1160;
						     type_t arg1771_1161;
						     arg1770_1160 = get_location_95_ast_alphatize((obj_t) (node_1144));
						     arg1771_1161 = (((closure_t) CREF(node_1144))->type);
						     {
							closure_t res2122_2015;
							{
							   variable_t variable_2007;
							   variable_2007 = (variable_t) (alpha_1146);
							   {
							      closure_t new1214_2008;
							      new1214_2008 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
							      {
								 long arg1667_2009;
								 arg1667_2009 = class_num_218___object(closure_ast_node);
								 {
								    obj_t obj_2013;
								    obj_2013 = (obj_t) (new1214_2008);
								    (((obj_t) CREF(obj_2013))->header = MAKE_HEADER(arg1667_2009, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_2946;
								 aux_2946 = (object_t) (new1214_2008);
								 OBJECT_WIDENING_SET(aux_2946, BFALSE);
							      }
							      ((((closure_t) CREF(new1214_2008))->loc) = ((obj_t) arg1770_1160), BUNSPEC);
							      ((((closure_t) CREF(new1214_2008))->type) = ((type_t) arg1771_1161), BUNSPEC);
							      ((((closure_t) CREF(new1214_2008))->variable) = ((variable_t) variable_2007), BUNSPEC);
							      res2122_2015 = new1214_2008;
							   }
							}
							new1452_1159 = res2122_2015;
						     }
						  }
						  {
						     aux_2794 = (obj_t) (new1452_1159);
						  }
					       }
					    }
					  else
					    {
					       {
						  obj_t arg1776_1165;
						  arg1776_1165 = shape_tools_shape((obj_t) (node_1144));
						  aux_2794 = internal_error_43_tools_error(string2153_ast_alphatize, string2154_ast_alphatize, arg1776_1165);
					       }
					    }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    kwote_t node_1166;
			    node_1166 = (kwote_t) (node_20);
			    {
			       kwote_t new1454_1168;
			       {
				  obj_t arg1777_1169;
				  type_t arg1778_1170;
				  obj_t arg1779_1171;
				  arg1777_1169 = get_location_95_ast_alphatize((obj_t) (node_1166));
				  arg1778_1170 = (((kwote_t) CREF(node_1166))->type);
				  arg1779_1171 = (((kwote_t) CREF(node_1166))->value);
				  {
				     kwote_t res2123_2028;
				     {
					kwote_t new1222_2021;
					new1222_2021 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
					{
					   long arg1665_2022;
					   arg1665_2022 = class_num_218___object(kwote_ast_node);
					   {
					      obj_t obj_2026;
					      obj_2026 = (obj_t) (new1222_2021);
					      (((obj_t) CREF(obj_2026))->header = MAKE_HEADER(arg1665_2022, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_2965;
					   aux_2965 = (object_t) (new1222_2021);
					   OBJECT_WIDENING_SET(aux_2965, BFALSE);
					}
					((((kwote_t) CREF(new1222_2021))->loc) = ((obj_t) arg1777_1169), BUNSPEC);
					((((kwote_t) CREF(new1222_2021))->type) = ((type_t) arg1778_1170), BUNSPEC);
					((((kwote_t) CREF(new1222_2021))->value) = ((obj_t) arg1779_1171), BUNSPEC);
					res2123_2028 = new1222_2021;
				     }
				     new1454_1168 = res2123_2028;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1454_1168);
			       }
			    }
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1172;
			    node_1172 = (sequence_t) (node_20);
			    {
			       sequence_t new1456_1174;
			       {
				  obj_t arg1780_1175;
				  type_t arg1781_1176;
				  obj_t arg1783_1177;
				  obj_t arg1786_1178;
				  obj_t arg1788_1179;
				  arg1780_1175 = get_location_95_ast_alphatize((obj_t) (node_1172));
				  arg1781_1176 = (((sequence_t) CREF(node_1172))->type);
				  arg1783_1177 = (((sequence_t) CREF(node_1172))->side_effect__165);
				  arg1786_1178 = (((sequence_t) CREF(node_1172))->key);
				  {
				     obj_t l1457_1180;
				     l1457_1180 = (((sequence_t) CREF(node_1172))->nodes);
				     if (NULLP(l1457_1180))
				       {
					  arg1788_1179 = BNIL;
				       }
				     else
				       {
					  obj_t head1459_1182;
					  {
					     node_t arg1796_1193;
					     {
						node_t aux_2981;
						{
						   obj_t aux_2982;
						   aux_2982 = CAR(l1457_1180);
						   aux_2981 = (node_t) (aux_2982);
						}
						arg1796_1193 = do_alphatize_126_ast_alphatize(aux_2981);
					     }
					     {
						obj_t aux_2986;
						aux_2986 = (obj_t) (arg1796_1193);
						head1459_1182 = MAKE_PAIR(aux_2986, BNIL);
					     }
					  }
					  {
					     obj_t l1457_1183;
					     obj_t tail1460_1184;
					     l1457_1183 = CDR(l1457_1180);
					     tail1460_1184 = head1459_1182;
					   lname1458_1185:
					     if (NULLP(l1457_1183))
					       {
						  arg1788_1179 = head1459_1182;
					       }
					     else
					       {
						  obj_t newtail1461_1188;
						  {
						     node_t arg1793_1190;
						     {
							node_t aux_2991;
							{
							   obj_t aux_2992;
							   aux_2992 = CAR(l1457_1183);
							   aux_2991 = (node_t) (aux_2992);
							}
							arg1793_1190 = do_alphatize_126_ast_alphatize(aux_2991);
						     }
						     {
							obj_t aux_2996;
							aux_2996 = (obj_t) (arg1793_1190);
							newtail1461_1188 = MAKE_PAIR(aux_2996, BNIL);
						     }
						  }
						  SET_CDR(tail1460_1184, newtail1461_1188);
						  {
						     obj_t tail1460_3002;
						     obj_t l1457_3000;
						     l1457_3000 = CDR(l1457_1183);
						     tail1460_3002 = newtail1461_1188;
						     tail1460_1184 = tail1460_3002;
						     l1457_1183 = l1457_3000;
						     goto lname1458_1185;
						  }
					       }
					  }
				       }
				  }
				  {
				     sequence_t res2124_2059;
				     {
					sequence_t new1229_2050;
					new1229_2050 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
					{
					   long arg1661_2051;
					   arg1661_2051 = class_num_218___object(sequence_ast_node);
					   {
					      obj_t obj_2057;
					      obj_2057 = (obj_t) (new1229_2050);
					      (((obj_t) CREF(obj_2057))->header = MAKE_HEADER(arg1661_2051, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3008;
					   aux_3008 = (object_t) (new1229_2050);
					   OBJECT_WIDENING_SET(aux_3008, BFALSE);
					}
					((((sequence_t) CREF(new1229_2050))->loc) = ((obj_t) arg1780_1175), BUNSPEC);
					((((sequence_t) CREF(new1229_2050))->type) = ((type_t) arg1781_1176), BUNSPEC);
					((((sequence_t) CREF(new1229_2050))->side_effect__165) = ((obj_t) arg1783_1177), BUNSPEC);
					((((sequence_t) CREF(new1229_2050))->key) = ((obj_t) arg1786_1178), BUNSPEC);
					((((sequence_t) CREF(new1229_2050))->nodes) = ((obj_t) arg1788_1179), BUNSPEC);
					res2124_2059 = new1229_2050;
				     }
				     new1456_1174 = res2124_2059;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1456_1174);
			       }
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    app_t node_1196;
			    node_1196 = (app_t) (node_20);
			    {
			       app_t new1463_1198;
			       {
				  obj_t arg1800_1199;
				  type_t arg1802_1200;
				  obj_t arg1803_1201;
				  obj_t arg1804_1202;
				  obj_t arg1805_1203;
				  obj_t arg1806_1204;
				  obj_t arg1807_1205;
				  arg1800_1199 = get_location_95_ast_alphatize((obj_t) (node_1196));
				  arg1802_1200 = (((app_t) CREF(node_1196))->type);
				  arg1803_1201 = (((app_t) CREF(node_1196))->side_effect__165);
				  arg1804_1202 = (((app_t) CREF(node_1196))->key);
				  {
				     node_t var_1206;
				     {
					node_t aux_3023;
					{
					   var_t aux_3024;
					   aux_3024 = (((app_t) CREF(node_1196))->fun);
					   aux_3023 = (node_t) (aux_3024);
					}
					var_1206 = do_alphatize_126_ast_alphatize(aux_3023);
				     }
				     {
					bool_t test1808_1207;
					test1808_1207 = is_a__118___object((obj_t) (var_1206), closure_ast_node);
					if (test1808_1207)
					  {
					     var_t duplicated1464_1208;
					     duplicated1464_1208 = (var_t) (var_1206);
					     {
						var_t new1465_1209;
						{
						   obj_t arg1809_1210;
						   type_t arg1810_1211;
						   variable_t arg1811_1212;
						   arg1809_1210 = (((var_t) CREF(duplicated1464_1208))->loc);
						   arg1810_1211 = (((var_t) CREF(duplicated1464_1208))->type);
						   arg1811_1212 = (((var_t) CREF(duplicated1464_1208))->variable);
						   {
						      var_t res2125_2078;
						      {
							 var_t new1206_2071;
							 new1206_2071 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							 {
							    long arg1669_2072;
							    arg1669_2072 = class_num_218___object(var_ast_node);
							    {
							       obj_t obj_2076;
							       obj_2076 = (obj_t) (new1206_2071);
							       (((obj_t) CREF(obj_2076))->header = MAKE_HEADER(arg1669_2072, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_3039;
							    aux_3039 = (object_t) (new1206_2071);
							    OBJECT_WIDENING_SET(aux_3039, BFALSE);
							 }
							 ((((var_t) CREF(new1206_2071))->loc) = ((obj_t) arg1809_1210), BUNSPEC);
							 ((((var_t) CREF(new1206_2071))->type) = ((type_t) arg1810_1211), BUNSPEC);
							 ((((var_t) CREF(new1206_2071))->variable) = ((variable_t) arg1811_1212), BUNSPEC);
							 res2125_2078 = new1206_2071;
						      }
						      new1465_1209 = res2125_2078;
						   }
						}
						{
						   arg1805_1203 = (obj_t) (new1465_1209);
						}
					     }
					  }
					else
					  {
					     arg1805_1203 = (obj_t) (var_1206);
					  }
				     }
				  }
				  {
				     obj_t l1466_1214;
				     l1466_1214 = (((app_t) CREF(node_1196))->args);
				     if (NULLP(l1466_1214))
				       {
					  arg1806_1204 = BNIL;
				       }
				     else
				       {
					  obj_t head1468_1216;
					  {
					     node_t arg1821_1227;
					     {
						node_t aux_3050;
						{
						   obj_t aux_3051;
						   aux_3051 = CAR(l1466_1214);
						   aux_3050 = (node_t) (aux_3051);
						}
						arg1821_1227 = do_alphatize_126_ast_alphatize(aux_3050);
					     }
					     {
						obj_t aux_3055;
						aux_3055 = (obj_t) (arg1821_1227);
						head1468_1216 = MAKE_PAIR(aux_3055, BNIL);
					     }
					  }
					  {
					     obj_t l1466_1217;
					     obj_t tail1469_1218;
					     l1466_1217 = CDR(l1466_1214);
					     tail1469_1218 = head1468_1216;
					   lname1467_1219:
					     if (NULLP(l1466_1217))
					       {
						  arg1806_1204 = head1468_1216;
					       }
					     else
					       {
						  obj_t newtail1470_1222;
						  {
						     node_t arg1817_1224;
						     {
							node_t aux_3060;
							{
							   obj_t aux_3061;
							   aux_3061 = CAR(l1466_1217);
							   aux_3060 = (node_t) (aux_3061);
							}
							arg1817_1224 = do_alphatize_126_ast_alphatize(aux_3060);
						     }
						     {
							obj_t aux_3065;
							aux_3065 = (obj_t) (arg1817_1224);
							newtail1470_1222 = MAKE_PAIR(aux_3065, BNIL);
						     }
						  }
						  SET_CDR(tail1469_1218, newtail1470_1222);
						  {
						     obj_t tail1469_3071;
						     obj_t l1466_3069;
						     l1466_3069 = CDR(l1466_1217);
						     tail1469_3071 = newtail1470_1222;
						     tail1469_1218 = tail1469_3071;
						     l1466_1217 = l1466_3069;
						     goto lname1467_1219;
						  }
					       }
					  }
				       }
				  }
				  arg1807_1205 = (((app_t) CREF(node_1196))->stack_info_255);
				  {
				     app_t res2126_2111;
				     {
					var_t fun_2097;
					fun_2097 = (var_t) (arg1805_1203);
					{
					   app_t new1240_2100;
					   new1240_2100 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
					   {
					      long arg1658_2101;
					      arg1658_2101 = class_num_218___object(app_ast_node);
					      {
						 obj_t obj_2109;
						 obj_2109 = (obj_t) (new1240_2100);
						 (((obj_t) CREF(obj_2109))->header = MAKE_HEADER(arg1658_2101, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3079;
					      aux_3079 = (object_t) (new1240_2100);
					      OBJECT_WIDENING_SET(aux_3079, BFALSE);
					   }
					   ((((app_t) CREF(new1240_2100))->loc) = ((obj_t) arg1800_1199), BUNSPEC);
					   ((((app_t) CREF(new1240_2100))->type) = ((type_t) arg1802_1200), BUNSPEC);
					   ((((app_t) CREF(new1240_2100))->side_effect__165) = ((obj_t) arg1803_1201), BUNSPEC);
					   ((((app_t) CREF(new1240_2100))->key) = ((obj_t) arg1804_1202), BUNSPEC);
					   ((((app_t) CREF(new1240_2100))->fun) = ((var_t) fun_2097), BUNSPEC);
					   ((((app_t) CREF(new1240_2100))->args) = ((obj_t) arg1806_1204), BUNSPEC);
					   ((((app_t) CREF(new1240_2100))->stack_info_255) = ((obj_t) arg1807_1205), BUNSPEC);
					   res2126_2111 = new1240_2100;
					}
				     }
				     new1463_1198 = res2126_2111;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1463_1198);
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    app_ly_162_t node_1230;
			    node_1230 = (app_ly_162_t) (node_20);
			    {
			       node_t fun_1231;
			       node_t arg_1232;
			       fun_1231 = do_alphatize_126_ast_alphatize((((app_ly_162_t) CREF(node_1230))->fun));
			       arg_1232 = do_alphatize_126_ast_alphatize((((app_ly_162_t) CREF(node_1230))->arg));
			       {
				  bool_t test1824_1233;
				  test1824_1233 = is_a__118___object((obj_t) (fun_1231), closure_ast_node);
				  if (test1824_1233)
				    {
				       obj_t arg1827_1235;
				       var_t arg1829_1236;
				       obj_t arg1830_1237;
				       arg1827_1235 = get_location_95_ast_alphatize((obj_t) (node_1230));
				       {
					  var_t duplicated1471_1238;
					  duplicated1471_1238 = (var_t) (fun_1231);
					  {
					     var_t new1472_1239;
					     {
						obj_t arg1831_1240;
						type_t arg1832_1241;
						variable_t arg1833_1242;
						arg1831_1240 = (((var_t) CREF(duplicated1471_1238))->loc);
						arg1832_1241 = (((var_t) CREF(duplicated1471_1238))->type);
						arg1833_1242 = (((var_t) CREF(duplicated1471_1238))->variable);
						{
						   var_t res2127_2128;
						   {
						      var_t new1206_2121;
						      new1206_2121 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						      {
							 long arg1669_2122;
							 arg1669_2122 = class_num_218___object(var_ast_node);
							 {
							    obj_t obj_2126;
							    obj_2126 = (obj_t) (new1206_2121);
							    (((obj_t) CREF(obj_2126))->header = MAKE_HEADER(arg1669_2122, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_3108;
							 aux_3108 = (object_t) (new1206_2121);
							 OBJECT_WIDENING_SET(aux_3108, BFALSE);
						      }
						      ((((var_t) CREF(new1206_2121))->loc) = ((obj_t) arg1831_1240), BUNSPEC);
						      ((((var_t) CREF(new1206_2121))->type) = ((type_t) arg1832_1241), BUNSPEC);
						      ((((var_t) CREF(new1206_2121))->variable) = ((variable_t) arg1833_1242), BUNSPEC);
						      res2127_2128 = new1206_2121;
						   }
						   new1472_1239 = res2127_2128;
						}
					     }
					     {
						arg1829_1236 = new1472_1239;
					     }
					  }
				       }
				       arg1830_1237 = CNST_TABLE_REF(((long) 1));
				       {
					  node_t aux_3115;
					  aux_3115 = known_app_ly__node_26_ast_apply(BNIL, arg1827_1235, (node_t) (arg1829_1236), arg_1232, arg1830_1237);
					  aux_2794 = (obj_t) (aux_3115);
				       }
				    }
				  else
				    {
				       app_ly_162_t new1474_1244;
				       {
					  obj_t arg1834_1245;
					  type_t arg1835_1246;
					  arg1834_1245 = get_location_95_ast_alphatize((obj_t) (node_1230));
					  arg1835_1246 = (((app_ly_162_t) CREF(node_1230))->type);
					  {
					     app_ly_162_t res2128_2142;
					     {
						app_ly_162_t new1256_2134;
						new1256_2134 = ((app_ly_162_t) BREF(GC_MALLOC(sizeof(struct app_ly_162))));
						{
						   long arg1656_2135;
						   arg1656_2135 = class_num_218___object(app_ly_162_ast_node);
						   {
						      obj_t obj_2140;
						      obj_2140 = (obj_t) (new1256_2134);
						      (((obj_t) CREF(obj_2140))->header = MAKE_HEADER(arg1656_2135, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_3126;
						   aux_3126 = (object_t) (new1256_2134);
						   OBJECT_WIDENING_SET(aux_3126, BFALSE);
						}
						((((app_ly_162_t) CREF(new1256_2134))->loc) = ((obj_t) arg1834_1245), BUNSPEC);
						((((app_ly_162_t) CREF(new1256_2134))->type) = ((type_t) arg1835_1246), BUNSPEC);
						((((app_ly_162_t) CREF(new1256_2134))->fun) = ((node_t) fun_1231), BUNSPEC);
						((((app_ly_162_t) CREF(new1256_2134))->arg) = ((node_t) arg_1232), BUNSPEC);
						res2128_2142 = new1256_2134;
					     }
					     new1474_1244 = res2128_2142;
					  }
				       }
				       {
					  aux_2794 = (obj_t) (new1474_1244);
				       }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    funcall_t node_1251;
			    node_1251 = (funcall_t) (node_20);
			    {
			       node_t fun_1252;
			       obj_t args_1253;
			       fun_1252 = do_alphatize_126_ast_alphatize((((funcall_t) CREF(node_1251))->fun));
			       {
				  obj_t l1475_1280;
				  l1475_1280 = (((funcall_t) CREF(node_1251))->args);
				  if (NULLP(l1475_1280))
				    {
				       args_1253 = BNIL;
				    }
				  else
				    {
				       obj_t head1477_1282;
				       {
					  node_t arg1877_1293;
					  {
					     node_t aux_3140;
					     {
						obj_t aux_3141;
						aux_3141 = CAR(l1475_1280);
						aux_3140 = (node_t) (aux_3141);
					     }
					     arg1877_1293 = do_alphatize_126_ast_alphatize(aux_3140);
					  }
					  {
					     obj_t aux_3145;
					     aux_3145 = (obj_t) (arg1877_1293);
					     head1477_1282 = MAKE_PAIR(aux_3145, BNIL);
					  }
				       }
				       {
					  obj_t l1475_1283;
					  obj_t tail1478_1284;
					  l1475_1283 = CDR(l1475_1280);
					  tail1478_1284 = head1477_1282;
					lname1476_1285:
					  if (NULLP(l1475_1283))
					    {
					       args_1253 = head1477_1282;
					    }
					  else
					    {
					       obj_t newtail1479_1288;
					       {
						  node_t arg1874_1290;
						  {
						     node_t aux_3150;
						     {
							obj_t aux_3151;
							aux_3151 = CAR(l1475_1283);
							aux_3150 = (node_t) (aux_3151);
						     }
						     arg1874_1290 = do_alphatize_126_ast_alphatize(aux_3150);
						  }
						  {
						     obj_t aux_3155;
						     aux_3155 = (obj_t) (arg1874_1290);
						     newtail1479_1288 = MAKE_PAIR(aux_3155, BNIL);
						  }
					       }
					       SET_CDR(tail1478_1284, newtail1479_1288);
					       {
						  obj_t tail1478_3161;
						  obj_t l1475_3159;
						  l1475_3159 = CDR(l1475_1283);
						  tail1478_3161 = newtail1479_1288;
						  tail1478_1284 = tail1478_3161;
						  l1475_1283 = l1475_3159;
						  goto lname1476_1285;
					       }
					    }
				       }
				    }
			       }
			       {
				  bool_t test1840_1254;
				  test1840_1254 = is_a__118___object((obj_t) (fun_1252), closure_ast_node);
				  if (test1840_1254)
				    {
				       bool_t test1841_1255;
				       {
					  variable_t aux_3166;
					  {
					     var_t obj_2158;
					     obj_2158 = (var_t) (fun_1252);
					     aux_3166 = (((var_t) CREF(obj_2158))->variable);
					  }
					  test1841_1255 = correct_arity_app__187_ast_app(aux_3166, CDR(args_1253));
				       }
				       if (test1841_1255)
					 {
					    obj_t arg1843_1257;
					    var_t arg1847_1258;
					    obj_t arg1848_1259;
					    arg1843_1257 = get_location_95_ast_alphatize((obj_t) (node_1251));
					    {
					       var_t duplicated1480_1260;
					       duplicated1480_1260 = (var_t) (fun_1252);
					       {
						  var_t new1481_1261;
						  {
						     obj_t arg1850_1262;
						     type_t arg1851_1263;
						     variable_t arg1852_1264;
						     arg1850_1262 = (((var_t) CREF(duplicated1480_1260))->loc);
						     arg1851_1263 = (((var_t) CREF(duplicated1480_1260))->type);
						     arg1852_1264 = (((var_t) CREF(duplicated1480_1260))->variable);
						     {
							var_t res2129_2173;
							{
							   var_t new1206_2166;
							   new1206_2166 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							   {
							      long arg1669_2167;
							      arg1669_2167 = class_num_218___object(var_ast_node);
							      {
								 obj_t obj_2171;
								 obj_2171 = (obj_t) (new1206_2166);
								 (((obj_t) CREF(obj_2171))->header = MAKE_HEADER(arg1669_2167, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_3182;
							      aux_3182 = (object_t) (new1206_2166);
							      OBJECT_WIDENING_SET(aux_3182, BFALSE);
							   }
							   ((((var_t) CREF(new1206_2166))->loc) = ((obj_t) arg1850_1262), BUNSPEC);
							   ((((var_t) CREF(new1206_2166))->type) = ((type_t) arg1851_1263), BUNSPEC);
							   ((((var_t) CREF(new1206_2166))->variable) = ((variable_t) arg1852_1264), BUNSPEC);
							   res2129_2173 = new1206_2166;
							}
							new1481_1261 = res2129_2173;
						     }
						  }
						  {
						     arg1847_1258 = new1481_1261;
						  }
					       }
					    }
					    arg1848_1259 = CDR(args_1253);
					    {
					       node_t aux_3189;
					       aux_3189 = make_app_node_80_ast_app(BNIL, arg1843_1257, arg1847_1258, arg1848_1259);
					       aux_2794 = (obj_t) (aux_3189);
					    }
					 }
				       else
					 {
					    obj_t arg1853_1265;
					    obj_t arg1858_1268;
					    arg1853_1265 = get_location_95_ast_alphatize((obj_t) (node_1251));
					    arg1858_1268 = shape_tools_shape((obj_t) (node_1251));
					    aux_2794 = user_error_location_137_tools_error(arg1853_1265, string2155_ast_alphatize, string2156_ast_alphatize, arg1858_1268, BNIL);
					 }
				    }
				  else
				    {
				       funcall_t new1483_1273;
				       {
					  obj_t arg1862_1274;
					  type_t arg1863_1275;
					  obj_t arg1866_1278;
					  arg1862_1274 = get_location_95_ast_alphatize((obj_t) (node_1251));
					  arg1863_1275 = (((funcall_t) CREF(node_1251))->type);
					  arg1866_1278 = (((funcall_t) CREF(node_1251))->strength);
					  {
					     funcall_t res2130_2191;
					     {
						funcall_t new1266_2182;
						new1266_2182 = ((funcall_t) BREF(GC_MALLOC(sizeof(struct funcall))));
						{
						   long arg1654_2183;
						   arg1654_2183 = class_num_218___object(funcall_ast_node);
						   {
						      obj_t obj_2189;
						      obj_2189 = (obj_t) (new1266_2182);
						      (((obj_t) CREF(obj_2189))->header = MAKE_HEADER(arg1654_2183, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_3205;
						   aux_3205 = (object_t) (new1266_2182);
						   OBJECT_WIDENING_SET(aux_3205, BFALSE);
						}
						((((funcall_t) CREF(new1266_2182))->loc) = ((obj_t) arg1862_1274), BUNSPEC);
						((((funcall_t) CREF(new1266_2182))->type) = ((type_t) arg1863_1275), BUNSPEC);
						((((funcall_t) CREF(new1266_2182))->fun) = ((node_t) fun_1252), BUNSPEC);
						((((funcall_t) CREF(new1266_2182))->args) = ((obj_t) args_1253), BUNSPEC);
						((((funcall_t) CREF(new1266_2182))->strength) = ((obj_t) arg1866_1278), BUNSPEC);
						res2130_2191 = new1266_2182;
					     }
					     new1483_1273 = res2130_2191;
					  }
				       }
				       {
					  aux_2794 = (obj_t) (new1483_1273);
				       }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    pragma_t node_1296;
			    node_1296 = (pragma_t) (node_20);
			    {
			       pragma_t new1485_1298;
			       {
				  obj_t arg1880_1299;
				  type_t arg1881_1300;
				  obj_t arg1883_1301;
				  obj_t arg1884_1302;
				  obj_t arg1885_1303;
				  obj_t arg1886_1304;
				  arg1880_1299 = get_location_95_ast_alphatize((obj_t) (node_1296));
				  arg1881_1300 = (((pragma_t) CREF(node_1296))->type);
				  arg1883_1301 = (((pragma_t) CREF(node_1296))->side_effect__165);
				  arg1884_1302 = (((pragma_t) CREF(node_1296))->key);
				  arg1885_1303 = (((pragma_t) CREF(node_1296))->format);
				  {
				     obj_t l1486_1305;
				     l1486_1305 = (((pragma_t) CREF(node_1296))->args);
				     if (NULLP(l1486_1305))
				       {
					  arg1886_1304 = BNIL;
				       }
				     else
				       {
					  obj_t head1488_1307;
					  {
					     node_t arg1895_1318;
					     {
						node_t aux_3224;
						{
						   obj_t aux_3225;
						   aux_3225 = CAR(l1486_1305);
						   aux_3224 = (node_t) (aux_3225);
						}
						arg1895_1318 = do_alphatize_126_ast_alphatize(aux_3224);
					     }
					     {
						obj_t aux_3229;
						aux_3229 = (obj_t) (arg1895_1318);
						head1488_1307 = MAKE_PAIR(aux_3229, BNIL);
					     }
					  }
					  {
					     obj_t l1486_1308;
					     obj_t tail1489_1309;
					     l1486_1308 = CDR(l1486_1305);
					     tail1489_1309 = head1488_1307;
					   lname1487_1310:
					     if (NULLP(l1486_1308))
					       {
						  arg1886_1304 = head1488_1307;
					       }
					     else
					       {
						  obj_t newtail1490_1313;
						  {
						     node_t arg1892_1315;
						     {
							node_t aux_3234;
							{
							   obj_t aux_3235;
							   aux_3235 = CAR(l1486_1308);
							   aux_3234 = (node_t) (aux_3235);
							}
							arg1892_1315 = do_alphatize_126_ast_alphatize(aux_3234);
						     }
						     {
							obj_t aux_3239;
							aux_3239 = (obj_t) (arg1892_1315);
							newtail1490_1313 = MAKE_PAIR(aux_3239, BNIL);
						     }
						  }
						  SET_CDR(tail1489_1309, newtail1490_1313);
						  {
						     obj_t tail1489_3245;
						     obj_t l1486_3243;
						     l1486_3243 = CDR(l1486_1308);
						     tail1489_3245 = newtail1490_1313;
						     tail1489_1309 = tail1489_3245;
						     l1486_1308 = l1486_3243;
						     goto lname1487_1310;
						  }
					       }
					  }
				       }
				  }
				  {
				     pragma_t res2131_2225;
				     {
					pragma_t new1278_2215;
					new1278_2215 = ((pragma_t) BREF(GC_MALLOC(sizeof(struct pragma))));
					{
					   long arg1652_2216;
					   arg1652_2216 = class_num_218___object(pragma_ast_node);
					   {
					      obj_t obj_2223;
					      obj_2223 = (obj_t) (new1278_2215);
					      (((obj_t) CREF(obj_2223))->header = MAKE_HEADER(arg1652_2216, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3251;
					   aux_3251 = (object_t) (new1278_2215);
					   OBJECT_WIDENING_SET(aux_3251, BFALSE);
					}
					((((pragma_t) CREF(new1278_2215))->loc) = ((obj_t) arg1880_1299), BUNSPEC);
					((((pragma_t) CREF(new1278_2215))->type) = ((type_t) arg1881_1300), BUNSPEC);
					((((pragma_t) CREF(new1278_2215))->side_effect__165) = ((obj_t) arg1883_1301), BUNSPEC);
					((((pragma_t) CREF(new1278_2215))->key) = ((obj_t) arg1884_1302), BUNSPEC);
					((((pragma_t) CREF(new1278_2215))->format) = ((obj_t) arg1885_1303), BUNSPEC);
					((((pragma_t) CREF(new1278_2215))->args) = ((obj_t) arg1886_1304), BUNSPEC);
					res2131_2225 = new1278_2215;
				     }
				     new1485_1298 = res2131_2225;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1485_1298);
			       }
			    }
			 }
			 break;
		      case ((long) 9):
			 {
			    cast_t node_1321;
			    node_1321 = (cast_t) (node_20);
			    {
			       cast_t new1492_1323;
			       {
				  obj_t arg1898_1324;
				  type_t arg1899_1325;
				  node_t arg1900_1326;
				  arg1898_1324 = get_location_95_ast_alphatize((obj_t) (node_1321));
				  arg1899_1325 = (((cast_t) CREF(node_1321))->type);
				  arg1900_1326 = do_alphatize_126_ast_alphatize((((cast_t) CREF(node_1321))->arg));
				  {
				     cast_t res2132_2238;
				     {
					cast_t new1291_2231;
					new1291_2231 = ((cast_t) BREF(GC_MALLOC(sizeof(struct cast))));
					{
					   long arg1649_2232;
					   arg1649_2232 = class_num_218___object(cast_ast_node);
					   {
					      obj_t obj_2236;
					      obj_2236 = (obj_t) (new1291_2231);
					      (((obj_t) CREF(obj_2236))->header = MAKE_HEADER(arg1649_2232, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3271;
					   aux_3271 = (object_t) (new1291_2231);
					   OBJECT_WIDENING_SET(aux_3271, BFALSE);
					}
					((((cast_t) CREF(new1291_2231))->loc) = ((obj_t) arg1898_1324), BUNSPEC);
					((((cast_t) CREF(new1291_2231))->type) = ((type_t) arg1899_1325), BUNSPEC);
					((((cast_t) CREF(new1291_2231))->arg) = ((node_t) arg1900_1326), BUNSPEC);
					res2132_2238 = new1291_2231;
				     }
				     new1492_1323 = res2132_2238;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1492_1323);
			       }
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    setq_t node_1328;
			    node_1328 = (setq_t) (node_20);
			    {
			       var_t v_1329;
			       v_1329 = (((setq_t) CREF(node_1328))->var);
			       {
				  variable_t var_1330;
				  var_1330 = (((var_t) CREF(v_1329))->variable);
				  {
				     obj_t alpha_1331;
				     alpha_1331 = (((variable_t) CREF(var_1330))->fast_alpha_7);
				     {
					if ((alpha_1331 == BUNSPEC))
					  {
					     {
						obj_t aux_3284;
						{
						   node_t obj_2244;
						   obj_2244 = (node_t) (node_1328);
						   aux_3284 = (((node_t) CREF(obj_2244))->loc);
						}
						use_variable__4_ast_sexp(var_1330, aux_3284, CNST_TABLE_REF(((long) 2)));
					     }
					     {
						setq_t new1494_1336;
						{
						   obj_t arg1906_1337;
						   type_t arg1907_1338;
						   var_t arg1909_1339;
						   node_t arg1910_1340;
						   arg1906_1337 = get_location_95_ast_alphatize((obj_t) (node_1328));
						   arg1907_1338 = (((setq_t) CREF(node_1328))->type);
						   {
						      var_t new1496_1342;
						      {
							 obj_t arg1911_1343;
							 type_t arg1912_1344;
							 variable_t arg1913_1345;
							 arg1911_1343 = get_location_95_ast_alphatize((obj_t) (node_1328));
							 arg1912_1344 = (((var_t) CREF(v_1329))->type);
							 arg1913_1345 = (((var_t) CREF(v_1329))->variable);
							 {
							    var_t res2133_2258;
							    {
							       var_t new1206_2251;
							       new1206_2251 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							       {
								  long arg1669_2252;
								  arg1669_2252 = class_num_218___object(var_ast_node);
								  {
								     obj_t obj_2256;
								     obj_2256 = (obj_t) (new1206_2251);
								     (((obj_t) CREF(obj_2256))->header = MAKE_HEADER(arg1669_2252, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_3300;
								  aux_3300 = (object_t) (new1206_2251);
								  OBJECT_WIDENING_SET(aux_3300, BFALSE);
							       }
							       ((((var_t) CREF(new1206_2251))->loc) = ((obj_t) arg1911_1343), BUNSPEC);
							       ((((var_t) CREF(new1206_2251))->type) = ((type_t) arg1912_1344), BUNSPEC);
							       ((((var_t) CREF(new1206_2251))->variable) = ((variable_t) arg1913_1345), BUNSPEC);
							       res2133_2258 = new1206_2251;
							    }
							    new1496_1342 = res2133_2258;
							 }
						      }
						      {
							 arg1909_1339 = new1496_1342;
						      }
						   }
						   arg1910_1340 = do_alphatize_126_ast_alphatize((((setq_t) CREF(node_1328))->value));
						   {
						      setq_t res2134_2272;
						      {
							 setq_t new1299_2264;
							 new1299_2264 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
							 {
							    long arg1647_2265;
							    arg1647_2265 = class_num_218___object(setq_ast_node);
							    {
							       obj_t obj_2270;
							       obj_2270 = (obj_t) (new1299_2264);
							       (((obj_t) CREF(obj_2270))->header = MAKE_HEADER(arg1647_2265, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_3312;
							    aux_3312 = (object_t) (new1299_2264);
							    OBJECT_WIDENING_SET(aux_3312, BFALSE);
							 }
							 ((((setq_t) CREF(new1299_2264))->loc) = ((obj_t) arg1906_1337), BUNSPEC);
							 ((((setq_t) CREF(new1299_2264))->type) = ((type_t) arg1907_1338), BUNSPEC);
							 ((((setq_t) CREF(new1299_2264))->var) = ((var_t) arg1909_1339), BUNSPEC);
							 ((((setq_t) CREF(new1299_2264))->value) = ((node_t) arg1910_1340), BUNSPEC);
							 res2134_2272 = new1299_2264;
						      }
						      new1494_1336 = res2134_2272;
						   }
						}
						{
						   aux_2794 = (obj_t) (new1494_1336);
						}
					     }
					  }
					else
					  {
					     bool_t test1915_1347;
					     test1915_1347 = is_a__118___object(alpha_1331, variable_ast_var);
					     if (test1915_1347)
					       {
						  {
						     obj_t aux_3322;
						     {
							node_t obj_2274;
							obj_2274 = (node_t) (node_1328);
							aux_3322 = (((node_t) CREF(obj_2274))->loc);
						     }
						     use_variable__4_ast_sexp((variable_t) (alpha_1331), aux_3322, CNST_TABLE_REF(((long) 2)));
						  }
						  {
						     setq_t new1498_1351;
						     {
							obj_t arg1918_1352;
							type_t arg1919_1353;
							var_t arg1920_1354;
							node_t arg1921_1355;
							arg1918_1352 = get_location_95_ast_alphatize((obj_t) (node_1328));
							arg1919_1353 = (((setq_t) CREF(node_1328))->type);
							{
							   var_t new1500_1357;
							   {
							      obj_t arg1923_1358;
							      type_t arg1924_1359;
							      arg1923_1358 = get_location_95_ast_alphatize((obj_t) (node_1328));
							      arg1924_1359 = (((var_t) CREF(v_1329))->type);
							      {
								 var_t res2135_2287;
								 {
								    variable_t variable_2279;
								    variable_2279 = (variable_t) (alpha_1331);
								    {
								       var_t new1206_2280;
								       new1206_2280 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								       {
									  long arg1669_2281;
									  arg1669_2281 = class_num_218___object(var_ast_node);
									  {
									     obj_t obj_2285;
									     obj_2285 = (obj_t) (new1206_2280);
									     (((obj_t) CREF(obj_2285))->header = MAKE_HEADER(arg1669_2281, 0), BUNSPEC);
									  }
								       }
								       {
									  object_t aux_3339;
									  aux_3339 = (object_t) (new1206_2280);
									  OBJECT_WIDENING_SET(aux_3339, BFALSE);
								       }
								       ((((var_t) CREF(new1206_2280))->loc) = ((obj_t) arg1923_1358), BUNSPEC);
								       ((((var_t) CREF(new1206_2280))->type) = ((type_t) arg1924_1359), BUNSPEC);
								       ((((var_t) CREF(new1206_2280))->variable) = ((variable_t) variable_2279), BUNSPEC);
								       res2135_2287 = new1206_2280;
								    }
								 }
								 new1500_1357 = res2135_2287;
							      }
							   }
							   {
							      arg1920_1354 = new1500_1357;
							   }
							}
							arg1921_1355 = do_alphatize_126_ast_alphatize((((setq_t) CREF(node_1328))->value));
							{
							   setq_t res2136_2301;
							   {
							      setq_t new1299_2293;
							      new1299_2293 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
							      {
								 long arg1647_2294;
								 arg1647_2294 = class_num_218___object(setq_ast_node);
								 {
								    obj_t obj_2299;
								    obj_2299 = (obj_t) (new1299_2293);
								    (((obj_t) CREF(obj_2299))->header = MAKE_HEADER(arg1647_2294, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_3351;
								 aux_3351 = (object_t) (new1299_2293);
								 OBJECT_WIDENING_SET(aux_3351, BFALSE);
							      }
							      ((((setq_t) CREF(new1299_2293))->loc) = ((obj_t) arg1918_1352), BUNSPEC);
							      ((((setq_t) CREF(new1299_2293))->type) = ((type_t) arg1919_1353), BUNSPEC);
							      ((((setq_t) CREF(new1299_2293))->var) = ((var_t) arg1920_1354), BUNSPEC);
							      ((((setq_t) CREF(new1299_2293))->value) = ((node_t) arg1921_1355), BUNSPEC);
							      res2136_2301 = new1299_2293;
							   }
							   new1498_1351 = res2136_2301;
							}
						     }
						     {
							aux_2794 = (obj_t) (new1498_1351);
						     }
						  }
					       }
					     else
					       {
						  {
						     obj_t arg1930_1364;
						     arg1930_1364 = shape_tools_shape((obj_t) (node_1328));
						     aux_2794 = internal_error_43_tools_error(string2153_ast_alphatize, string2154_ast_alphatize, arg1930_1364);
						  }
					       }
					  }
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    conditional_t node_1365;
			    node_1365 = (conditional_t) (node_20);
			    {
			       conditional_t new1502_1367;
			       {
				  obj_t arg1931_1368;
				  type_t arg1932_1369;
				  obj_t arg1933_1370;
				  obj_t arg1934_1371;
				  node_t arg1935_1372;
				  node_t arg1936_1373;
				  node_t arg1937_1374;
				  arg1931_1368 = get_location_95_ast_alphatize((obj_t) (node_1365));
				  arg1932_1369 = (((conditional_t) CREF(node_1365))->type);
				  arg1933_1370 = (((conditional_t) CREF(node_1365))->side_effect__165);
				  arg1934_1371 = (((conditional_t) CREF(node_1365))->key);
				  arg1935_1372 = do_alphatize_126_ast_alphatize((((conditional_t) CREF(node_1365))->test));
				  arg1936_1373 = do_alphatize_126_ast_alphatize((((conditional_t) CREF(node_1365))->true));
				  arg1937_1374 = do_alphatize_126_ast_alphatize((((conditional_t) CREF(node_1365))->false));
				  {
				     conditional_t res2137_2326;
				     {
					conditional_t new1309_2315;
					new1309_2315 = ((conditional_t) BREF(GC_MALLOC(sizeof(struct conditional))));
					{
					   long arg1645_2316;
					   arg1645_2316 = class_num_218___object(conditional_ast_node);
					   {
					      obj_t obj_2324;
					      obj_2324 = (obj_t) (new1309_2315);
					      (((obj_t) CREF(obj_2324))->header = MAKE_HEADER(arg1645_2316, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3378;
					   aux_3378 = (object_t) (new1309_2315);
					   OBJECT_WIDENING_SET(aux_3378, BFALSE);
					}
					((((conditional_t) CREF(new1309_2315))->loc) = ((obj_t) arg1931_1368), BUNSPEC);
					((((conditional_t) CREF(new1309_2315))->type) = ((type_t) arg1932_1369), BUNSPEC);
					((((conditional_t) CREF(new1309_2315))->side_effect__165) = ((obj_t) arg1933_1370), BUNSPEC);
					((((conditional_t) CREF(new1309_2315))->key) = ((obj_t) arg1934_1371), BUNSPEC);
					((((conditional_t) CREF(new1309_2315))->test) = ((node_t) arg1935_1372), BUNSPEC);
					((((conditional_t) CREF(new1309_2315))->true) = ((node_t) arg1936_1373), BUNSPEC);
					((((conditional_t) CREF(new1309_2315))->false) = ((node_t) arg1937_1374), BUNSPEC);
					res2137_2326 = new1309_2315;
				     }
				     new1502_1367 = res2137_2326;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1502_1367);
			       }
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    fail_t node_1378;
			    node_1378 = (fail_t) (node_20);
			    {
			       fail_t new1504_1380;
			       {
				  obj_t arg1941_1381;
				  type_t arg1942_1382;
				  node_t arg1943_1383;
				  node_t arg1944_1384;
				  node_t arg1945_1385;
				  arg1941_1381 = get_location_95_ast_alphatize((obj_t) (node_1378));
				  arg1942_1382 = (((fail_t) CREF(node_1378))->type);
				  arg1943_1383 = do_alphatize_126_ast_alphatize((((fail_t) CREF(node_1378))->proc));
				  arg1944_1384 = do_alphatize_126_ast_alphatize((((fail_t) CREF(node_1378))->msg));
				  arg1945_1385 = do_alphatize_126_ast_alphatize((((fail_t) CREF(node_1378))->obj));
				  {
				     fail_t res2138_2345;
				     {
					fail_t new1325_2336;
					new1325_2336 = ((fail_t) BREF(GC_MALLOC(sizeof(struct fail))));
					{
					   long arg1640_2337;
					   arg1640_2337 = class_num_218___object(fail_ast_node);
					   {
					      obj_t obj_2343;
					      obj_2343 = (obj_t) (new1325_2336);
					      (((obj_t) CREF(obj_2343))->header = MAKE_HEADER(arg1640_2337, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3403;
					   aux_3403 = (object_t) (new1325_2336);
					   OBJECT_WIDENING_SET(aux_3403, BFALSE);
					}
					((((fail_t) CREF(new1325_2336))->loc) = ((obj_t) arg1941_1381), BUNSPEC);
					((((fail_t) CREF(new1325_2336))->type) = ((type_t) arg1942_1382), BUNSPEC);
					((((fail_t) CREF(new1325_2336))->proc) = ((node_t) arg1943_1383), BUNSPEC);
					((((fail_t) CREF(new1325_2336))->msg) = ((node_t) arg1944_1384), BUNSPEC);
					((((fail_t) CREF(new1325_2336))->obj) = ((node_t) arg1945_1385), BUNSPEC);
					res2138_2345 = new1325_2336;
				     }
				     new1504_1380 = res2138_2345;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1504_1380);
			       }
			    }
			 }
			 break;
		      case ((long) 13):
			 {
			    select_t node_1389;
			    node_1389 = (select_t) (node_20);
			    {
			       select_t new1506_1391;
			       {
				  obj_t arg1950_1392;
				  type_t arg1951_1393;
				  obj_t arg1952_1394;
				  obj_t arg1953_1395;
				  node_t arg1954_1396;
				  obj_t arg1956_1397;
				  type_t arg1957_1398;
				  arg1950_1392 = get_location_95_ast_alphatize((obj_t) (node_1389));
				  arg1951_1393 = (((select_t) CREF(node_1389))->type);
				  arg1952_1394 = (((select_t) CREF(node_1389))->side_effect__165);
				  arg1953_1395 = (((select_t) CREF(node_1389))->key);
				  arg1954_1396 = do_alphatize_126_ast_alphatize((((select_t) CREF(node_1389))->test));
				  {
				     obj_t l1507_1400;
				     l1507_1400 = (((select_t) CREF(node_1389))->clauses);
				     if (NULLP(l1507_1400))
				       {
					  arg1956_1397 = BNIL;
				       }
				     else
				       {
					  obj_t head1509_1402;
					  head1509_1402 = MAKE_PAIR(BNIL, BNIL);
					  {
					     obj_t l1507_1403;
					     obj_t tail1510_1404;
					     l1507_1403 = l1507_1400;
					     tail1510_1404 = head1509_1402;
					   lname1508_1405:
					     if (NULLP(l1507_1403))
					       {
						  arg1956_1397 = CDR(head1509_1402);
					       }
					     else
					       {
						  obj_t newtail1511_1407;
						  {
						     obj_t arg1962_1409;
						     {
							obj_t clause_1411;
							clause_1411 = CAR(l1507_1403);
							{
							   obj_t arg1964_1412;
							   node_t arg1965_1413;
							   arg1964_1412 = CAR(clause_1411);
							   {
							      node_t aux_3429;
							      {
								 obj_t aux_3430;
								 aux_3430 = CDR(clause_1411);
								 aux_3429 = (node_t) (aux_3430);
							      }
							      arg1965_1413 = do_alphatize_126_ast_alphatize(aux_3429);
							   }
							   {
							      obj_t aux_3434;
							      aux_3434 = (obj_t) (arg1965_1413);
							      arg1962_1409 = MAKE_PAIR(arg1964_1412, aux_3434);
							   }
							}
						     }
						     newtail1511_1407 = MAKE_PAIR(arg1962_1409, BNIL);
						  }
						  SET_CDR(tail1510_1404, newtail1511_1407);
						  {
						     obj_t tail1510_3441;
						     obj_t l1507_3439;
						     l1507_3439 = CDR(l1507_1403);
						     tail1510_3441 = newtail1511_1407;
						     tail1510_1404 = tail1510_3441;
						     l1507_1403 = l1507_3439;
						     goto lname1508_1405;
						  }
					       }
					  }
				       }
				  }
				  arg1957_1398 = (((select_t) CREF(node_1389))->item_type_130);
				  {
				     select_t res2139_2385;
				     {
					select_t new1337_2374;
					new1337_2374 = ((select_t) BREF(GC_MALLOC(sizeof(struct select))));
					{
					   long arg1638_2375;
					   arg1638_2375 = class_num_218___object(select_ast_node);
					   {
					      obj_t obj_2383;
					      obj_2383 = (obj_t) (new1337_2374);
					      (((obj_t) CREF(obj_2383))->header = MAKE_HEADER(arg1638_2375, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3447;
					   aux_3447 = (object_t) (new1337_2374);
					   OBJECT_WIDENING_SET(aux_3447, BFALSE);
					}
					((((select_t) CREF(new1337_2374))->loc) = ((obj_t) arg1950_1392), BUNSPEC);
					((((select_t) CREF(new1337_2374))->type) = ((type_t) arg1951_1393), BUNSPEC);
					((((select_t) CREF(new1337_2374))->side_effect__165) = ((obj_t) arg1952_1394), BUNSPEC);
					((((select_t) CREF(new1337_2374))->key) = ((obj_t) arg1953_1395), BUNSPEC);
					((((select_t) CREF(new1337_2374))->test) = ((node_t) arg1954_1396), BUNSPEC);
					((((select_t) CREF(new1337_2374))->clauses) = ((obj_t) arg1956_1397), BUNSPEC);
					((((select_t) CREF(new1337_2374))->item_type_130) = ((type_t) arg1957_1398), BUNSPEC);
					res2139_2385 = new1337_2374;
				     }
				     new1506_1391 = res2139_2385;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1506_1391);
			       }
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    make_box_202_t node_1417;
			    node_1417 = (make_box_202_t) (node_20);
			    {
			       make_box_202_t new1513_1419;
			       {
				  obj_t arg1972_1420;
				  type_t arg1973_1421;
				  obj_t arg1974_1422;
				  obj_t arg1975_1423;
				  node_t arg1977_1424;
				  arg1972_1420 = get_location_95_ast_alphatize((obj_t) (node_1417));
				  arg1973_1421 = (((make_box_202_t) CREF(node_1417))->type);
				  arg1974_1422 = (((make_box_202_t) CREF(node_1417))->side_effect__165);
				  arg1975_1423 = (((make_box_202_t) CREF(node_1417))->key);
				  arg1977_1424 = do_alphatize_126_ast_alphatize((((make_box_202_t) CREF(node_1417))->value));
				  {
				     make_box_202_t res2140_2404;
				     {
					make_box_202_t new1401_2395;
					new1401_2395 = ((make_box_202_t) BREF(GC_MALLOC(sizeof(struct make_box_202))));
					{
					   long arg1623_2396;
					   arg1623_2396 = class_num_218___object(make_box_202_ast_node);
					   {
					      obj_t obj_2402;
					      obj_2402 = (obj_t) (new1401_2395);
					      (((obj_t) CREF(obj_2402))->header = MAKE_HEADER(arg1623_2396, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3470;
					   aux_3470 = (object_t) (new1401_2395);
					   OBJECT_WIDENING_SET(aux_3470, BFALSE);
					}
					((((make_box_202_t) CREF(new1401_2395))->loc) = ((obj_t) arg1972_1420), BUNSPEC);
					((((make_box_202_t) CREF(new1401_2395))->type) = ((type_t) arg1973_1421), BUNSPEC);
					((((make_box_202_t) CREF(new1401_2395))->side_effect__165) = ((obj_t) arg1974_1422), BUNSPEC);
					((((make_box_202_t) CREF(new1401_2395))->key) = ((obj_t) arg1975_1423), BUNSPEC);
					((((make_box_202_t) CREF(new1401_2395))->value) = ((node_t) arg1977_1424), BUNSPEC);
					res2140_2404 = new1401_2395;
				     }
				     new1513_1419 = res2140_2404;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1513_1419);
			       }
			    }
			 }
			 break;
		      case ((long) 15):
			 {
			    box_ref_242_t node_1426;
			    node_1426 = (box_ref_242_t) (node_20);
			    {
			       box_ref_242_t new1515_1428;
			       {
				  obj_t arg1979_1429;
				  type_t arg1980_1430;
				  obj_t arg1981_1431;
				  obj_t arg1982_1432;
				  node_t arg1983_1433;
				  arg1979_1429 = get_location_95_ast_alphatize((obj_t) (node_1426));
				  arg1980_1430 = (((box_ref_242_t) CREF(node_1426))->type);
				  arg1981_1431 = (((box_ref_242_t) CREF(node_1426))->side_effect__165);
				  arg1982_1432 = (((box_ref_242_t) CREF(node_1426))->key);
				  {
				     node_t aux_3485;
				     {
					var_t aux_3486;
					aux_3486 = (((box_ref_242_t) CREF(node_1426))->var);
					aux_3485 = (node_t) (aux_3486);
				     }
				     arg1983_1433 = do_alphatize_126_ast_alphatize(aux_3485);
				  }
				  {
				     box_ref_242_t res2141_2423;
				     {
					var_t var_2413;
					var_2413 = (var_t) (arg1983_1433);
					{
					   box_ref_242_t new1413_2414;
					   new1413_2414 = ((box_ref_242_t) BREF(GC_MALLOC(sizeof(struct box_ref_242))));
					   {
					      long arg1621_2415;
					      arg1621_2415 = class_num_218___object(box_ref_242_ast_node);
					      {
						 obj_t obj_2421;
						 obj_2421 = (obj_t) (new1413_2414);
						 (((obj_t) CREF(obj_2421))->header = MAKE_HEADER(arg1621_2415, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3495;
					      aux_3495 = (object_t) (new1413_2414);
					      OBJECT_WIDENING_SET(aux_3495, BFALSE);
					   }
					   ((((box_ref_242_t) CREF(new1413_2414))->loc) = ((obj_t) arg1979_1429), BUNSPEC);
					   ((((box_ref_242_t) CREF(new1413_2414))->type) = ((type_t) arg1980_1430), BUNSPEC);
					   ((((box_ref_242_t) CREF(new1413_2414))->side_effect__165) = ((obj_t) arg1981_1431), BUNSPEC);
					   ((((box_ref_242_t) CREF(new1413_2414))->key) = ((obj_t) arg1982_1432), BUNSPEC);
					   ((((box_ref_242_t) CREF(new1413_2414))->var) = ((var_t) var_2413), BUNSPEC);
					   res2141_2423 = new1413_2414;
					}
				     }
				     new1515_1428 = res2141_2423;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1515_1428);
			       }
			    }
			 }
			 break;
		      case ((long) 16):
			 {
			    box_set__221_t node_1435;
			    node_1435 = (box_set__221_t) (node_20);
			    {
			       box_set__221_t new1517_1437;
			       {
				  obj_t arg1985_1438;
				  type_t arg1986_1439;
				  node_t arg1987_1440;
				  node_t arg1988_1441;
				  arg1985_1438 = get_location_95_ast_alphatize((obj_t) (node_1435));
				  arg1986_1439 = (((box_set__221_t) CREF(node_1435))->type);
				  {
				     node_t aux_3508;
				     {
					var_t aux_3509;
					aux_3509 = (((box_set__221_t) CREF(node_1435))->var);
					aux_3508 = (node_t) (aux_3509);
				     }
				     arg1987_1440 = do_alphatize_126_ast_alphatize(aux_3508);
				  }
				  arg1988_1441 = do_alphatize_126_ast_alphatize((((box_set__221_t) CREF(node_1435))->value));
				  {
				     box_set__221_t res2142_2439;
				     {
					var_t var_2429;
					var_2429 = (var_t) (arg1987_1440);
					{
					   box_set__221_t new1425_2431;
					   new1425_2431 = ((box_set__221_t) BREF(GC_MALLOC(sizeof(struct box_set__221))));
					   {
					      long arg1618_2432;
					      arg1618_2432 = class_num_218___object(box_set__221_ast_node);
					      {
						 obj_t obj_2437;
						 obj_2437 = (obj_t) (new1425_2431);
						 (((obj_t) CREF(obj_2437))->header = MAKE_HEADER(arg1618_2432, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3520;
					      aux_3520 = (object_t) (new1425_2431);
					      OBJECT_WIDENING_SET(aux_3520, BFALSE);
					   }
					   ((((box_set__221_t) CREF(new1425_2431))->loc) = ((obj_t) arg1985_1438), BUNSPEC);
					   ((((box_set__221_t) CREF(new1425_2431))->type) = ((type_t) arg1986_1439), BUNSPEC);
					   ((((box_set__221_t) CREF(new1425_2431))->var) = ((var_t) var_2429), BUNSPEC);
					   ((((box_set__221_t) CREF(new1425_2431))->value) = ((node_t) arg1988_1441), BUNSPEC);
					   res2142_2439 = new1425_2431;
					}
				     }
				     new1517_1437 = res2142_2439;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1517_1437);
			       }
			    }
			 }
			 break;
		      case ((long) 17):
			 {
			    let_fun_218_t node_1444;
			    node_1444 = (let_fun_218_t) (node_20);
			    {
			       obj_t old_locals_255_1445;
			       old_locals_255_1445 = (((let_fun_218_t) CREF(node_1444))->locals);
			       {
				  obj_t new_locals_179_1446;
				  if (NULLP(old_locals_255_1445))
				    {
				       new_locals_179_1446 = BNIL;
				    }
				  else
				    {
				       obj_t head1520_1506;
				       head1520_1506 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1518_1507;
					  obj_t tail1521_1508;
					  l1518_1507 = old_locals_255_1445;
					  tail1521_1508 = head1520_1506;
					lname1519_1509:
					  if (NULLP(l1518_1507))
					    {
					       new_locals_179_1446 = CDR(head1520_1506);
					    }
					  else
					    {
					       obj_t newtail1522_1511;
					       {
						  local_t arg2037_1513;
						  {
						     obj_t l_1515;
						     l_1515 = CAR(l1518_1507);
						     {
							sfun_t aux_3543;
							type_t aux_3540;
							obj_t aux_3537;
							{
							   value_t aux_3544;
							   {
							      local_t obj_2449;
							      obj_2449 = (local_t) (l_1515);
							      aux_3544 = (((local_t) CREF(obj_2449))->value);
							   }
							   aux_3543 = (sfun_t) (aux_3544);
							}
							{
							   local_t obj_2448;
							   obj_2448 = (local_t) (l_1515);
							   aux_3540 = (((local_t) CREF(obj_2448))->type);
							}
							{
							   local_t obj_2447;
							   obj_2447 = (local_t) (l_1515);
							   aux_3537 = (((local_t) CREF(obj_2447))->id);
							}
							arg2037_1513 = make_local_sfun_184_ast_local(aux_3537, aux_3540, aux_3543);
						     }
						  }
						  {
						     obj_t aux_3549;
						     aux_3549 = (obj_t) (arg2037_1513);
						     newtail1522_1511 = MAKE_PAIR(aux_3549, BNIL);
						  }
					       }
					       SET_CDR(tail1521_1508, newtail1522_1511);
					       {
						  obj_t tail1521_3555;
						  obj_t l1518_3553;
						  l1518_3553 = CDR(l1518_1507);
						  tail1521_3555 = newtail1522_1511;
						  tail1521_1508 = tail1521_3555;
						  l1518_1507 = l1518_3553;
						  goto lname1519_1509;
					       }
					    }
				       }
				    }
				  {
				     {
					obj_t ll1523_1447;
					obj_t ll1524_1448;
					ll1523_1447 = old_locals_255_1445;
					ll1524_1448 = new_locals_179_1446;
				      lname1525_1449:
					if (NULLP(ll1523_1447))
					  {
					     ((bool_t) 1);
					  }
					else
					  {
					     {
						obj_t new_1452;
						new_1452 = CAR(ll1524_1448);
						{
						   value_t old_sfun_249_1453;
						   {
						      local_t obj_2458;
						      {
							 obj_t aux_3559;
							 aux_3559 = CAR(ll1523_1447);
							 obj_2458 = (local_t) (aux_3559);
						      }
						      old_sfun_249_1453 = (((local_t) CREF(obj_2458))->value);
						   }
						   {
						      obj_t old_args_130_1454;
						      {
							 sfun_t obj_2459;
							 obj_2459 = (sfun_t) (old_sfun_249_1453);
							 old_args_130_1454 = (((sfun_t) CREF(obj_2459))->args);
						      }
						      {
							 obj_t new_args_235_1455;
							 if (NULLP(old_args_130_1454))
							   {
							      new_args_235_1455 = BNIL;
							   }
							 else
							   {
							      obj_t head1528_1478;
							      head1528_1478 = MAKE_PAIR(BNIL, BNIL);
							      {
								 obj_t l1526_1479;
								 obj_t tail1529_1480;
								 l1526_1479 = old_args_130_1454;
								 tail1529_1480 = head1528_1478;
							       lname1527_1481:
								 if (NULLP(l1526_1479))
								   {
								      new_args_235_1455 = CDR(head1528_1478);
								   }
								 else
								   {
								      obj_t newtail1530_1483;
								      {
									 local_t arg2016_1485;
									 {
									    obj_t l_1487;
									    l_1487 = CAR(l1526_1479);
									    {
									       type_t aux_3575;
									       obj_t aux_3572;
									       {
										  local_t obj_2467;
										  obj_2467 = (local_t) (l_1487);
										  aux_3575 = (((local_t) CREF(obj_2467))->type);
									       }
									       {
										  local_t obj_2466;
										  obj_2466 = (local_t) (l_1487);
										  aux_3572 = (((local_t) CREF(obj_2466))->id);
									       }
									       arg2016_1485 = make_local_svar_140_ast_local(aux_3572, aux_3575);
									    }
									 }
									 {
									    obj_t aux_3579;
									    aux_3579 = (obj_t) (arg2016_1485);
									    newtail1530_1483 = MAKE_PAIR(aux_3579, BNIL);
									 }
								      }
								      SET_CDR(tail1529_1480, newtail1530_1483);
								      {
									 obj_t tail1529_3585;
									 obj_t l1526_3583;
									 l1526_3583 = CDR(l1526_1479);
									 tail1529_3585 = newtail1530_1483;
									 tail1529_1480 = tail1529_3585;
									 l1526_1479 = l1526_3583;
									 goto lname1527_1481;
								      }
								   }
							      }
							   }
							 {
							    node_t new_body_215_1457;
							    {
							       node_t aux_3586;
							       {
								  obj_t aux_3591;
								  {
								     sfun_t obj_2473;
								     obj_2473 = (sfun_t) (old_sfun_249_1453);
								     aux_3591 = (((sfun_t) CREF(obj_2473))->body);
								  }
								  aux_3586 = (node_t) (aux_3591);
							       }
							       new_body_215_1457 = alphatize_ast_alphatize(append_2_18___r4_pairs_and_lists_6_3(old_locals_255_1445, old_args_130_1454), append_2_18___r4_pairs_and_lists_6_3(new_locals_179_1446, new_args_235_1455), get_location_95_ast_alphatize((obj_t) (node_1444)), aux_3586);
							    }
							    {
							       sfun_t new_sfun_134_1458;
							       {
								  sfun_t duplicated1531_1459;
								  duplicated1531_1459 = (sfun_t) (old_sfun_249_1453);
								  {
								     sfun_t new1532_1460;
								     {
									long arg1992_1461;
									obj_t arg1993_1462;
									obj_t arg1994_1463;
									obj_t arg1995_1464;
									bool_t arg1998_1465;
									obj_t arg2000_1466;
									obj_t arg2001_1467;
									obj_t arg2004_1470;
									obj_t arg2006_1471;
									obj_t arg2008_1472;
									arg1992_1461 = (((sfun_t) CREF(duplicated1531_1459))->arity);
									arg1993_1462 = (((sfun_t) CREF(duplicated1531_1459))->side_effect__165);
									arg1994_1463 = (((sfun_t) CREF(duplicated1531_1459))->predicate_of_78);
									arg1995_1464 = (((sfun_t) CREF(duplicated1531_1459))->stack_allocator_172);
									arg1998_1465 = (((sfun_t) CREF(duplicated1531_1459))->top__138);
									arg2000_1466 = (((sfun_t) CREF(duplicated1531_1459))->the_closure_238);
									arg2001_1467 = (((sfun_t) CREF(duplicated1531_1459))->property);
									arg2004_1470 = (((sfun_t) CREF(duplicated1531_1459))->class);
									arg2006_1471 = (((sfun_t) CREF(duplicated1531_1459))->dsssl_keywords_243);
									arg2008_1472 = (((sfun_t) CREF(duplicated1531_1459))->loc);
									{
									   sfun_t res2143_2512;
									   {
									      obj_t body_2492;
									      body_2492 = (obj_t) (new_body_215_1457);
									      {
										 sfun_t new1114_2496;
										 new1114_2496 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
										 {
										    long arg1691_2497;
										    arg1691_2497 = class_num_218___object(sfun_ast_var);
										    {
										       obj_t obj_2510;
										       obj_2510 = (obj_t) (new1114_2496);
										       (((obj_t) CREF(obj_2510))->header = MAKE_HEADER(arg1691_2497, 0), BUNSPEC);
										    }
										 }
										 {
										    object_t aux_3612;
										    aux_3612 = (object_t) (new1114_2496);
										    OBJECT_WIDENING_SET(aux_3612, BFALSE);
										 }
										 ((((sfun_t) CREF(new1114_2496))->arity) = ((long) arg1992_1461), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->side_effect__165) = ((obj_t) arg1993_1462), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->predicate_of_78) = ((obj_t) arg1994_1463), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->stack_allocator_172) = ((obj_t) arg1995_1464), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->top__138) = ((bool_t) arg1998_1465), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->the_closure_238) = ((obj_t) arg2000_1466), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->property) = ((obj_t) arg2001_1467), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->args) = ((obj_t) new_args_235_1455), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->body) = ((obj_t) body_2492), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->class) = ((obj_t) arg2004_1470), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->dsssl_keywords_243) = ((obj_t) arg2006_1471), BUNSPEC);
										 ((((sfun_t) CREF(new1114_2496))->loc) = ((obj_t) arg2008_1472), BUNSPEC);
										 res2143_2512 = new1114_2496;
									      }
									   }
									   new1532_1460 = res2143_2512;
									}
								     }
								     {
									new_sfun_134_1458 = new1532_1460;
								     }
								  }
							       }
							       {
								  {
								     local_t obj_2513;
								     value_t val1093_2514;
								     obj_2513 = (local_t) (new_1452);
								     val1093_2514 = (value_t) (new_sfun_134_1458);
								     ((((local_t) CREF(obj_2513))->value) = ((value_t) val1093_2514), BUNSPEC);
								  }
							       }
							    }
							 }
						      }
						   }
						}
					     }
					     {
						obj_t ll1524_3632;
						obj_t ll1523_3630;
						ll1523_3630 = CDR(ll1523_1447);
						ll1524_3632 = CDR(ll1524_1448);
						ll1524_1448 = ll1524_3632;
						ll1523_1447 = ll1523_3630;
						goto lname1525_1449;
					     }
					  }
				     }
				     {
					let_fun_218_t new1534_1495;
					{
					   obj_t arg2024_1496;
					   type_t arg2026_1497;
					   obj_t arg2027_1498;
					   obj_t arg2028_1499;
					   node_t arg2030_1501;
					   arg2024_1496 = get_location_95_ast_alphatize((obj_t) (node_1444));
					   arg2026_1497 = (((let_fun_218_t) CREF(node_1444))->type);
					   arg2027_1498 = (((let_fun_218_t) CREF(node_1444))->side_effect__165);
					   arg2028_1499 = (((let_fun_218_t) CREF(node_1444))->key);
					   arg2030_1501 = alphatize_ast_alphatize(old_locals_255_1445, new_locals_179_1446, get_location_95_ast_alphatize((obj_t) (node_1444)), (((let_fun_218_t) CREF(node_1444))->body));
					   {
					      let_fun_218_t res2144_2537;
					      {
						 let_fun_218_t new1351_2527;
						 new1351_2527 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
						 {
						    long arg1634_2528;
						    arg1634_2528 = class_num_218___object(let_fun_218_ast_node);
						    {
						       obj_t obj_2535;
						       obj_2535 = (obj_t) (new1351_2527);
						       (((obj_t) CREF(obj_2535))->header = MAKE_HEADER(arg1634_2528, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_3647;
						    aux_3647 = (object_t) (new1351_2527);
						    OBJECT_WIDENING_SET(aux_3647, BFALSE);
						 }
						 ((((let_fun_218_t) CREF(new1351_2527))->loc) = ((obj_t) arg2024_1496), BUNSPEC);
						 ((((let_fun_218_t) CREF(new1351_2527))->type) = ((type_t) arg2026_1497), BUNSPEC);
						 ((((let_fun_218_t) CREF(new1351_2527))->side_effect__165) = ((obj_t) arg2027_1498), BUNSPEC);
						 ((((let_fun_218_t) CREF(new1351_2527))->key) = ((obj_t) arg2028_1499), BUNSPEC);
						 ((((let_fun_218_t) CREF(new1351_2527))->locals) = ((obj_t) new_locals_179_1446), BUNSPEC);
						 ((((let_fun_218_t) CREF(new1351_2527))->body) = ((node_t) arg2030_1501), BUNSPEC);
						 res2144_2537 = new1351_2527;
					      }
					      new1534_1495 = res2144_2537;
					   }
					}
					{
					   aux_2794 = (obj_t) (new1534_1495);
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 18):
			 {
			    let_var_6_t node_1521;
			    node_1521 = (let_var_6_t) (node_20);
			    {
			       obj_t old_locals_255_1522;
			       {
				  obj_t l1535_1572;
				  l1535_1572 = (((let_var_6_t) CREF(node_1521))->bindings);
				  if (NULLP(l1535_1572))
				    {
				       old_locals_255_1522 = BNIL;
				    }
				  else
				    {
				       obj_t head1537_1574;
				       {
					  obj_t aux_3661;
					  {
					     obj_t aux_3662;
					     aux_3662 = CAR(l1535_1572);
					     aux_3661 = CAR(aux_3662);
					  }
					  head1537_1574 = MAKE_PAIR(aux_3661, BNIL);
				       }
				       {
					  obj_t l1535_1575;
					  obj_t tail1538_1576;
					  l1535_1575 = CDR(l1535_1572);
					  tail1538_1576 = head1537_1574;
					lname1536_1577:
					  if (NULLP(l1535_1575))
					    {
					       old_locals_255_1522 = head1537_1574;
					    }
					  else
					    {
					       obj_t newtail1539_1580;
					       {
						  obj_t aux_3668;
						  {
						     obj_t aux_3669;
						     aux_3669 = CAR(l1535_1575);
						     aux_3668 = CAR(aux_3669);
						  }
						  newtail1539_1580 = MAKE_PAIR(aux_3668, BNIL);
					       }
					       SET_CDR(tail1538_1576, newtail1539_1580);
					       {
						  obj_t tail1538_3676;
						  obj_t l1535_3674;
						  l1535_3674 = CDR(l1535_1575);
						  tail1538_3676 = newtail1539_1580;
						  tail1538_1576 = tail1538_3676;
						  l1535_1575 = l1535_3674;
						  goto lname1536_1577;
					       }
					    }
				       }
				    }
			       }
			       {
				  obj_t new_locals_179_1523;
				  if (NULLP(old_locals_255_1522))
				    {
				       new_locals_179_1523 = BNIL;
				    }
				  else
				    {
				       obj_t head1542_1558;
				       head1542_1558 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1540_1559;
					  obj_t tail1543_1560;
					  l1540_1559 = old_locals_255_1522;
					  tail1543_1560 = head1542_1558;
					lname1541_1561:
					  if (NULLP(l1540_1559))
					    {
					       new_locals_179_1523 = CDR(head1542_1558);
					    }
					  else
					    {
					       obj_t newtail1544_1563;
					       {
						  local_t arg2067_1565;
						  {
						     obj_t l_1567;
						     l_1567 = CAR(l1540_1559);
						     {
							type_t aux_3688;
							obj_t aux_3685;
							{
							   local_t obj_2560;
							   obj_2560 = (local_t) (l_1567);
							   aux_3688 = (((local_t) CREF(obj_2560))->type);
							}
							{
							   local_t obj_2559;
							   obj_2559 = (local_t) (l_1567);
							   aux_3685 = (((local_t) CREF(obj_2559))->id);
							}
							arg2067_1565 = make_local_svar_140_ast_local(aux_3685, aux_3688);
						     }
						  }
						  {
						     obj_t aux_3692;
						     aux_3692 = (obj_t) (arg2067_1565);
						     newtail1544_1563 = MAKE_PAIR(aux_3692, BNIL);
						  }
					       }
					       SET_CDR(tail1543_1560, newtail1544_1563);
					       {
						  obj_t tail1543_3698;
						  obj_t l1540_3696;
						  l1540_3696 = CDR(l1540_1559);
						  tail1543_3698 = newtail1544_1563;
						  tail1543_1560 = tail1543_3698;
						  l1540_1559 = l1540_3696;
						  goto lname1541_1561;
					       }
					    }
				       }
				    }
				  {
				     obj_t new_bindings_102_1524;
				     {
					obj_t ll1545_1536;
					ll1545_1536 = (((let_var_6_t) CREF(node_1521))->bindings);
					if (NULLP(ll1545_1536))
					  {
					     new_bindings_102_1524 = BNIL;
					  }
					else
					  {
					     obj_t head1547_1539;
					     head1547_1539 = MAKE_PAIR(BNIL, BNIL);
					     {
						obj_t ll1545_1540;
						obj_t ll1546_1541;
						obj_t tail1548_1542;
						ll1545_1540 = ll1545_1536;
						ll1546_1541 = new_locals_179_1523;
						tail1548_1542 = head1547_1539;
					      lname1550_1543:
						if (NULLP(ll1545_1540))
						  {
						     new_bindings_102_1524 = CDR(head1547_1539);
						  }
						else
						  {
						     obj_t newtail1549_1545;
						     {
							obj_t arg2057_1548;
							{
							   obj_t new_local_166_1551;
							   new_local_166_1551 = CAR(ll1546_1541);
							   {
							      node_t arg2059_1552;
							      {
								 node_t aux_3707;
								 {
								    obj_t aux_3708;
								    {
								       obj_t aux_3709;
								       aux_3709 = CAR(ll1545_1540);
								       aux_3708 = CDR(aux_3709);
								    }
								    aux_3707 = (node_t) (aux_3708);
								 }
								 arg2059_1552 = do_alphatize_126_ast_alphatize(aux_3707);
							      }
							      {
								 obj_t aux_3714;
								 aux_3714 = (obj_t) (arg2059_1552);
								 arg2057_1548 = MAKE_PAIR(new_local_166_1551, aux_3714);
							      }
							   }
							}
							newtail1549_1545 = MAKE_PAIR(arg2057_1548, BNIL);
						     }
						     SET_CDR(tail1548_1542, newtail1549_1545);
						     {
							obj_t tail1548_3723;
							obj_t ll1546_3721;
							obj_t ll1545_3719;
							ll1545_3719 = CDR(ll1545_1540);
							ll1546_3721 = CDR(ll1546_1541);
							tail1548_3723 = newtail1549_1545;
							tail1548_1542 = tail1548_3723;
							ll1546_1541 = ll1546_3721;
							ll1545_1540 = ll1545_3719;
							goto lname1550_1543;
						     }
						  }
					     }
					  }
				     }
				     {
					{
					   let_var_6_t new1552_1526;
					   {
					      obj_t arg2044_1527;
					      type_t arg2045_1528;
					      obj_t arg2046_1529;
					      obj_t arg2047_1530;
					      node_t arg2049_1532;
					      bool_t arg2050_1533;
					      arg2044_1527 = get_location_95_ast_alphatize((obj_t) (node_1521));
					      arg2045_1528 = (((let_var_6_t) CREF(node_1521))->type);
					      arg2046_1529 = (((let_var_6_t) CREF(node_1521))->side_effect__165);
					      arg2047_1530 = (((let_var_6_t) CREF(node_1521))->key);
					      arg2049_1532 = alphatize_ast_alphatize(old_locals_255_1522, new_locals_179_1523, get_location_95_ast_alphatize((obj_t) (node_1521)), (((let_var_6_t) CREF(node_1521))->body));
					      arg2050_1533 = (((let_var_6_t) CREF(node_1521))->removable__42);
					      {
						 let_var_6_t res2145_2606;
						 {
						    let_var_6_t new1365_2595;
						    new1365_2595 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
						    {
						       long arg1632_2596;
						       arg1632_2596 = class_num_218___object(let_var_6_ast_node);
						       {
							  obj_t obj_2604;
							  obj_2604 = (obj_t) (new1365_2595);
							  (((obj_t) CREF(obj_2604))->header = MAKE_HEADER(arg1632_2596, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3738;
						       aux_3738 = (object_t) (new1365_2595);
						       OBJECT_WIDENING_SET(aux_3738, BFALSE);
						    }
						    ((((let_var_6_t) CREF(new1365_2595))->loc) = ((obj_t) arg2044_1527), BUNSPEC);
						    ((((let_var_6_t) CREF(new1365_2595))->type) = ((type_t) arg2045_1528), BUNSPEC);
						    ((((let_var_6_t) CREF(new1365_2595))->side_effect__165) = ((obj_t) arg2046_1529), BUNSPEC);
						    ((((let_var_6_t) CREF(new1365_2595))->key) = ((obj_t) arg2047_1530), BUNSPEC);
						    ((((let_var_6_t) CREF(new1365_2595))->bindings) = ((obj_t) new_bindings_102_1524), BUNSPEC);
						    ((((let_var_6_t) CREF(new1365_2595))->body) = ((node_t) arg2049_1532), BUNSPEC);
						    ((((let_var_6_t) CREF(new1365_2595))->removable__42) = ((bool_t) arg2050_1533), BUNSPEC);
						    res2145_2606 = new1365_2595;
						 }
						 new1552_1526 = res2145_2606;
					      }
					   }
					   {
					      aux_2794 = (obj_t) (new1552_1526);
					   }
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 19):
			 {
			    set_ex_it_116_t node_1588;
			    node_1588 = (set_ex_it_116_t) (node_20);
			    {
			       variable_t old_var_137_1589;
			       {
				  var_t arg2102_1620;
				  arg2102_1620 = (((set_ex_it_116_t) CREF(node_1588))->var);
				  old_var_137_1589 = (((var_t) CREF(arg2102_1620))->variable);
			       }
			       {
				  value_t old_exit_224_1590;
				  {
				     local_t obj_2609;
				     obj_2609 = (local_t) (old_var_137_1589);
				     old_exit_224_1590 = (((local_t) CREF(obj_2609))->value);
				  }
				  {
				     obj_t alpha_hdlg_201_1592;
				     {
					variable_t obj_2611;
					{
					   obj_t aux_3754;
					   {
					      sexit_t obj_2610;
					      obj_2610 = (sexit_t) (old_exit_224_1590);
					      aux_3754 = (((sexit_t) CREF(obj_2610))->handler);
					   }
					   obj_2611 = (variable_t) (aux_3754);
					}
					alpha_hdlg_201_1592 = (((variable_t) CREF(obj_2611))->fast_alpha_7);
				     }
				     {
					local_t new_var_21_1593;
					{
					   obj_t arg2097_1613;
					   type_t arg2098_1614;
					   sexit_t arg2099_1615;
					   {
					      local_t obj_2612;
					      obj_2612 = (local_t) (old_var_137_1589);
					      arg2097_1613 = (((local_t) CREF(obj_2612))->id);
					   }
					   {
					      local_t obj_2613;
					      obj_2613 = (local_t) (old_var_137_1589);
					      arg2098_1614 = (((local_t) CREF(obj_2613))->type);
					   }
					   {
					      sexit_t duplicated1553_1616;
					      duplicated1553_1616 = (sexit_t) (old_exit_224_1590);
					      {
						 sexit_t new1554_1617;
						 {
						    bool_t arg2101_1619;
						    arg2101_1619 = (((sexit_t) CREF(duplicated1553_1616))->detached__120);
						    {
						       sexit_t res2146_2623;
						       {
							  sexit_t new1175_2617;
							  new1175_2617 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
							  {
							     long arg1679_2618;
							     arg1679_2618 = class_num_218___object(sexit_ast_var);
							     {
								obj_t obj_2621;
								obj_2621 = (obj_t) (new1175_2617);
								(((obj_t) CREF(obj_2621))->header = MAKE_HEADER(arg1679_2618, 0), BUNSPEC);
							     }
							  }
							  {
							     object_t aux_3769;
							     aux_3769 = (object_t) (new1175_2617);
							     OBJECT_WIDENING_SET(aux_3769, BFALSE);
							  }
							  ((((sexit_t) CREF(new1175_2617))->handler) = ((obj_t) alpha_hdlg_201_1592), BUNSPEC);
							  ((((sexit_t) CREF(new1175_2617))->detached__120) = ((bool_t) arg2101_1619), BUNSPEC);
							  res2146_2623 = new1175_2617;
						       }
						       new1554_1617 = res2146_2623;
						    }
						 }
						 {
						    arg2099_1615 = new1554_1617;
						 }
					      }
					   }
					   new_var_21_1593 = make_local_sexit_184_ast_local(arg2097_1613, arg2098_1614, arg2099_1615);
					}
					{
					   node_t old_body_129_1594;
					   old_body_129_1594 = (((set_ex_it_116_t) CREF(node_1588))->body);
					   {
					      {
						 set_ex_it_116_t new1556_1596;
						 {
						    obj_t arg2083_1597;
						    type_t arg2084_1598;
						    var_t arg2085_1599;
						    node_t arg2086_1600;
						    arg2083_1597 = get_location_95_ast_alphatize((obj_t) (node_1588));
						    arg2084_1598 = (((set_ex_it_116_t) CREF(node_1588))->type);
						    {
						       var_t duplicated1557_1601;
						       duplicated1557_1601 = (((set_ex_it_116_t) CREF(node_1588))->var);
						       {
							  var_t new1558_1602;
							  {
							     obj_t arg2087_1603;
							     type_t arg2088_1604;
							     arg2087_1603 = get_location_95_ast_alphatize((obj_t) (node_1588));
							     arg2088_1604 = (((var_t) CREF(duplicated1557_1601))->type);
							     {
								var_t res2147_2638;
								{
								   variable_t variable_2630;
								   variable_2630 = (variable_t) (new_var_21_1593);
								   {
								      var_t new1206_2631;
								      new1206_2631 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								      {
									 long arg1669_2632;
									 arg1669_2632 = class_num_218___object(var_ast_node);
									 {
									    obj_t obj_2636;
									    obj_2636 = (obj_t) (new1206_2631);
									    (((obj_t) CREF(obj_2636))->header = MAKE_HEADER(arg1669_2632, 0), BUNSPEC);
									 }
								      }
								      {
									 object_t aux_3788;
									 aux_3788 = (object_t) (new1206_2631);
									 OBJECT_WIDENING_SET(aux_3788, BFALSE);
								      }
								      ((((var_t) CREF(new1206_2631))->loc) = ((obj_t) arg2087_1603), BUNSPEC);
								      ((((var_t) CREF(new1206_2631))->type) = ((type_t) arg2088_1604), BUNSPEC);
								      ((((var_t) CREF(new1206_2631))->variable) = ((variable_t) variable_2630), BUNSPEC);
								      res2147_2638 = new1206_2631;
								   }
								}
								new1558_1602 = res2147_2638;
							     }
							  }
							  {
							     arg2085_1599 = new1558_1602;
							  }
						       }
						    }
						    {
						       obj_t arg2090_1606;
						       obj_t arg2091_1607;
						       obj_t arg2092_1608;
						       {
							  obj_t list2093_1609;
							  {
							     obj_t aux_3794;
							     aux_3794 = (obj_t) (old_var_137_1589);
							     list2093_1609 = MAKE_PAIR(aux_3794, BNIL);
							  }
							  arg2090_1606 = list2093_1609;
						       }
						       {
							  obj_t list2095_1611;
							  {
							     obj_t aux_3797;
							     aux_3797 = (obj_t) (new_var_21_1593);
							     list2095_1611 = MAKE_PAIR(aux_3797, BNIL);
							  }
							  arg2091_1607 = list2095_1611;
						       }
						       arg2092_1608 = get_location_95_ast_alphatize((obj_t) (node_1588));
						       arg2086_1600 = alphatize_ast_alphatize(arg2090_1606, arg2091_1607, arg2092_1608, old_body_129_1594);
						    }
						    {
						       set_ex_it_116_t res2148_2653;
						       {
							  set_ex_it_116_t new1381_2645;
							  new1381_2645 = ((set_ex_it_116_t) BREF(GC_MALLOC(sizeof(struct set_ex_it_116))));
							  {
							     long arg1628_2646;
							     arg1628_2646 = class_num_218___object(set_ex_it_116_ast_node);
							     {
								obj_t obj_2651;
								obj_2651 = (obj_t) (new1381_2645);
								(((obj_t) CREF(obj_2651))->header = MAKE_HEADER(arg1628_2646, 0), BUNSPEC);
							     }
							  }
							  {
							     object_t aux_3807;
							     aux_3807 = (object_t) (new1381_2645);
							     OBJECT_WIDENING_SET(aux_3807, BFALSE);
							  }
							  ((((set_ex_it_116_t) CREF(new1381_2645))->loc) = ((obj_t) arg2083_1597), BUNSPEC);
							  ((((set_ex_it_116_t) CREF(new1381_2645))->type) = ((type_t) arg2084_1598), BUNSPEC);
							  ((((set_ex_it_116_t) CREF(new1381_2645))->var) = ((var_t) arg2085_1599), BUNSPEC);
							  ((((set_ex_it_116_t) CREF(new1381_2645))->body) = ((node_t) arg2086_1600), BUNSPEC);
							  res2148_2653 = new1381_2645;
						       }
						       new1556_1596 = res2148_2653;
						    }
						 }
						 {
						    aux_2794 = (obj_t) (new1556_1596);
						 }
					      }
					   }
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 20):
			 {
			    jump_ex_it_184_t node_1621;
			    node_1621 = (jump_ex_it_184_t) (node_20);
			    {
			       jump_ex_it_184_t new1560_1623;
			       {
				  obj_t arg2103_1624;
				  type_t arg2105_1625;
				  node_t arg2106_1626;
				  node_t arg2107_1627;
				  arg2103_1624 = get_location_95_ast_alphatize((obj_t) (node_1621));
				  arg2105_1625 = (((jump_ex_it_184_t) CREF(node_1621))->type);
				  arg2106_1626 = do_alphatize_126_ast_alphatize((((jump_ex_it_184_t) CREF(node_1621))->exit));
				  arg2107_1627 = do_alphatize_126_ast_alphatize((((jump_ex_it_184_t) CREF(node_1621))->value));
				  {
				     jump_ex_it_184_t res2149_2669;
				     {
					jump_ex_it_184_t new1391_2661;
					new1391_2661 = ((jump_ex_it_184_t) BREF(GC_MALLOC(sizeof(struct jump_ex_it_184))));
					{
					   long arg1625_2662;
					   arg1625_2662 = class_num_218___object(jump_ex_it_184_ast_node);
					   {
					      obj_t obj_2667;
					      obj_2667 = (obj_t) (new1391_2661);
					      (((obj_t) CREF(obj_2667))->header = MAKE_HEADER(arg1625_2662, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3827;
					   aux_3827 = (object_t) (new1391_2661);
					   OBJECT_WIDENING_SET(aux_3827, BFALSE);
					}
					((((jump_ex_it_184_t) CREF(new1391_2661))->loc) = ((obj_t) arg2103_1624), BUNSPEC);
					((((jump_ex_it_184_t) CREF(new1391_2661))->type) = ((type_t) arg2105_1625), BUNSPEC);
					((((jump_ex_it_184_t) CREF(new1391_2661))->exit) = ((node_t) arg2106_1626), BUNSPEC);
					((((jump_ex_it_184_t) CREF(new1391_2661))->value) = ((node_t) arg2107_1627), BUNSPEC);
					res2149_2669 = new1391_2661;
				     }
				     new1560_1623 = res2149_2669;
				  }
			       }
			       {
				  aux_2794 = (obj_t) (new1560_1623);
			       }
			    }
			 }
			 break;
		      default:
		       case_else1714_1102:
			 if (PROCEDUREP(method1708_1098))
			   {
			      aux_2794 = PROCEDURE_ENTRY(method1708_1098) (method1708_1098, (obj_t) (node_20), BEOA);
			   }
			 else
			   {
			      obj_t fun1705_1092;
			      fun1705_1092 = PROCEDURE_REF(do_alphatize_env_178_ast_alphatize, ((long) 0));
			      aux_2794 = PROCEDURE_ENTRY(fun1705_1092) (fun1705_1092, (obj_t) (node_20), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1714_1102;
		 }
	    }
	    return (node_t) (aux_2794);
	 }
      }
   }
}


/* _do-alphatize2152 */ obj_t 
_do_alphatize2152_238_ast_alphatize(obj_t env_2682, obj_t node_2683)
{
   {
      node_t aux_3847;
      aux_3847 = do_alphatize_126_ast_alphatize((node_t) (node_2683));
      return (obj_t) (aux_3847);
   }
}


/* do-alphatize-default1562 */ node_t 
do_alphatize_default1562_195_ast_alphatize(node_t node_21)
{
   FAILURE(CNST_TABLE_REF(((long) 3)), string2157_ast_alphatize, (obj_t) (node_21));
}


/* _do-alphatize-default1562 */ obj_t 
_do_alphatize_default1562_187_ast_alphatize(obj_t env_2684, obj_t node_2685)
{
   {
      node_t aux_3854;
      aux_3854 = do_alphatize_default1562_195_ast_alphatize((node_t) (node_2685));
      return (obj_t) (aux_3854);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_alphatize()
{
   module_initialization_70_type_type(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_ast_var(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_ast_node(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_tools_error(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_tools_shape(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_type_cache(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_ast_sexp(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_ast_local(((long) 0), "AST_ALPHATIZE");
   module_initialization_70_ast_apply(((long) 0), "AST_ALPHATIZE");
   return module_initialization_70_ast_app(((long) 0), "AST_ALPHATIZE");
}
