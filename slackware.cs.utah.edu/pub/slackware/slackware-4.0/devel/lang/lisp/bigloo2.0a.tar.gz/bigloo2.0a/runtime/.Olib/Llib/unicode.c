/*===========================================================================*/
/*   (Llib/unicode.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t make_ucs2_string(long, ucs2_t);
extern ucs2_t ucs2_string_ref_ur_85___unicode(obj_t, long);
extern obj_t ucs2_string_set__176___unicode(obj_t, long, ucs2_t);
static obj_t _subucs2_string1281_10___unicode(obj_t, obj_t, obj_t, obj_t);
static obj_t _make_ucs2_string1265_5___unicode(obj_t, obj_t, obj_t);
extern obj_t ucs2_string_fill__51___unicode(obj_t, ucs2_t);
static obj_t _subucs2_string_ur1282_163___unicode(obj_t, obj_t, obj_t, obj_t);
extern long ucs2_string_length_125___unicode(obj_t);
extern bool_t ucs2_string____135___unicode(obj_t, obj_t);
static obj_t _ucs2_string_downcase1287_26___unicode(obj_t, obj_t);
static obj_t _ucs2_string_ref1267_212___unicode(obj_t, obj_t, obj_t);
extern obj_t subucs2_string_ur_47___unicode(obj_t, long, long);
extern bool_t ucs2_string____33___unicode(obj_t, obj_t);
extern obj_t subucs2_string_27___unicode(obj_t, long, long);
extern bool_t ucs2_string_ci____43___unicode(obj_t, obj_t);
static obj_t _ucs2_string_ref_ur1269_210___unicode(obj_t, obj_t, obj_t);
static obj_t _ucs2_string_downcase_1289_86___unicode(obj_t, obj_t);
extern obj_t ucs2_string_copy_207___unicode(obj_t);
static obj_t _ucs2_string_170___unicode(obj_t, obj_t);
extern obj_t ucs2_string_append(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t ucs2_string_set_ur__94___unicode(obj_t, long, ucs2_t);
extern bool_t ucs2_string_ci____210___unicode(obj_t, obj_t);
static obj_t loop___unicode(obj_t);
extern bool_t ucs2_string_cilt(obj_t, obj_t);
extern bool_t ucs2_string_cile(obj_t, obj_t);
extern bool_t ucs2_string_cigt(obj_t, obj_t);
static obj_t _ucs2_string_ci__1277_33___unicode(obj_t, obj_t, obj_t);
extern bool_t ucs2_string_cige(obj_t, obj_t);
extern obj_t ucs2_string_to_utf8_string(obj_t);
extern ucs2_t ucs2_string_ref_239___unicode(obj_t, long);
static obj_t _ucs2_string__171___unicode(obj_t, obj_t);
extern obj_t ucs2_string_append_106___unicode(obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t ucs2_string_194___unicode(obj_t);
extern obj_t ucs2_string__utf8_string_192___unicode(obj_t);
extern obj_t module_initialization_70___unicode(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_ucs2_string_copy(obj_t);
static obj_t _ucs2_string_copy1284_31___unicode(obj_t, obj_t);
static obj_t _ucs2_string_append_9___unicode(obj_t, obj_t);
extern bool_t ucs2_string___248___unicode(obj_t, obj_t);
extern bool_t ucs2_string___146___unicode(obj_t, obj_t);
extern bool_t ucs2_string___83___unicode(obj_t, obj_t);
static obj_t _ucs2_string__1273_120___unicode(obj_t, obj_t, obj_t);
extern obj_t ucs2_string_downcase__42___unicode(obj_t);
static obj_t _ucs2_string_set_1268_79___unicode(obj_t, obj_t, obj_t, obj_t);
extern obj_t utf8_string_to_ucs2_string(obj_t);
extern obj_t ucs2_string_upcase_71___unicode(obj_t);
static obj_t _ucs2_string_ci__1272_63___unicode(obj_t, obj_t, obj_t);
static obj_t _ucs2_string_upcase1286_140___unicode(obj_t, obj_t);
extern bool_t ucs2_strcicmp(obj_t, obj_t);
static obj_t _ucs2_string_ci___1279_130___unicode(obj_t, obj_t, obj_t);
static obj_t _ucs2_string_ci___1280_50___unicode(obj_t, obj_t, obj_t);
static obj_t _ucs2_string_fill_1285_169___unicode(obj_t, obj_t, obj_t);
static obj_t _list__ucs2_string_171___unicode(obj_t, obj_t);
extern long list_length(obj_t);
extern bool_t ucs2_string_ci___60___unicode(obj_t, obj_t);
extern obj_t utf8_string__ucs2_string_53___unicode(obj_t);
extern bool_t ucs2_string_ci___247___unicode(obj_t, obj_t);
extern bool_t ucs2_string_ci___92___unicode(obj_t, obj_t);
static obj_t _utf8_string__ucs2_string1291_1___unicode(obj_t, obj_t);
extern obj_t ucs2_string__list_125___unicode(obj_t);
extern obj_t ucs2_string_upcase__158___unicode(obj_t);
static obj_t _ucs2_string_upcase_1288_79___unicode(obj_t, obj_t);
static obj_t _ucs2_string__1271_247___unicode(obj_t, obj_t, obj_t);
extern obj_t list__ucs2_string_55___unicode(obj_t);
static obj_t _ucs2_string_ci__1278_164___unicode(obj_t, obj_t, obj_t);
static obj_t _ucs2_string__utf8_string1290_194___unicode(obj_t, obj_t);
extern obj_t c_subucs2_string(obj_t, long, long);
static obj_t symbol1899___unicode = BUNSPEC;
static obj_t symbol1909___unicode = BUNSPEC;
static obj_t symbol1898___unicode = BUNSPEC;
static obj_t symbol1897___unicode = BUNSPEC;
static obj_t symbol1907___unicode = BUNSPEC;
static obj_t symbol1896___unicode = BUNSPEC;
static obj_t symbol1906___unicode = BUNSPEC;
static obj_t symbol1895___unicode = BUNSPEC;
static obj_t symbol1905___unicode = BUNSPEC;
static obj_t symbol1894___unicode = BUNSPEC;
static obj_t symbol1904___unicode = BUNSPEC;
static obj_t symbol1893___unicode = BUNSPEC;
static obj_t symbol1903___unicode = BUNSPEC;
static obj_t symbol1892___unicode = BUNSPEC;
static obj_t symbol1902___unicode = BUNSPEC;
static obj_t symbol1891___unicode = BUNSPEC;
static obj_t symbol1901___unicode = BUNSPEC;
static obj_t symbol1889___unicode = BUNSPEC;
static obj_t symbol1890___unicode = BUNSPEC;
static obj_t symbol1900___unicode = BUNSPEC;
static obj_t symbol1888___unicode = BUNSPEC;
static obj_t symbol1887___unicode = BUNSPEC;
static obj_t symbol1886___unicode = BUNSPEC;
static obj_t symbol1885___unicode = BUNSPEC;
static obj_t symbol1884___unicode = BUNSPEC;
static obj_t symbol1881___unicode = BUNSPEC;
static obj_t symbol1879___unicode = BUNSPEC;
static obj_t symbol1880___unicode = BUNSPEC;
static obj_t symbol1878___unicode = BUNSPEC;
static obj_t symbol1877___unicode = BUNSPEC;
static obj_t symbol1876___unicode = BUNSPEC;
static obj_t symbol1875___unicode = BUNSPEC;
static obj_t symbol1874___unicode = BUNSPEC;
static obj_t symbol1873___unicode = BUNSPEC;
static obj_t symbol1872___unicode = BUNSPEC;
static obj_t symbol1871___unicode = BUNSPEC;
static obj_t symbol1869___unicode = BUNSPEC;
static obj_t symbol1870___unicode = BUNSPEC;
static obj_t symbol1868___unicode = BUNSPEC;
static obj_t symbol1867___unicode = BUNSPEC;
static obj_t imported_modules_init_94___unicode();
static obj_t symbol1866___unicode = BUNSPEC;
static obj_t symbol1865___unicode = BUNSPEC;
static obj_t symbol1864___unicode = BUNSPEC;
static obj_t symbol1863___unicode = BUNSPEC;
static obj_t symbol1862___unicode = BUNSPEC;
static obj_t symbol1861___unicode = BUNSPEC;
static obj_t symbol1859___unicode = BUNSPEC;
static obj_t symbol1860___unicode = BUNSPEC;
static obj_t symbol1858___unicode = BUNSPEC;
static obj_t symbol1857___unicode = BUNSPEC;
static obj_t symbol1856___unicode = BUNSPEC;
static obj_t symbol1854___unicode = BUNSPEC;
static obj_t symbol1852___unicode = BUNSPEC;
extern bool_t ucs2_strcmp(obj_t, obj_t);
static obj_t symbol1848___unicode = BUNSPEC;
static obj_t symbol1846___unicode = BUNSPEC;
static obj_t symbol1845___unicode = BUNSPEC;
static obj_t symbol1844___unicode = BUNSPEC;
static obj_t symbol1842___unicode = BUNSPEC;
static obj_t symbol1838___unicode = BUNSPEC;
static obj_t symbol1837___unicode = BUNSPEC;
extern bool_t ucs2_string_lt(obj_t, obj_t);
static obj_t _ucs2_string___1275_88___unicode(obj_t, obj_t, obj_t);
extern obj_t make_ucs2_string_75___unicode(int, obj_t);
extern bool_t ucs2_string_le(obj_t, obj_t);
static obj_t _ucs2_string_set_ur_1270_133___unicode(obj_t, obj_t, obj_t, obj_t);
static obj_t _ucs2_string___1276_197___unicode(obj_t, obj_t, obj_t);
extern bool_t ucs2_string_gt(obj_t, obj_t);
static obj_t require_initialization_114___unicode = BUNSPEC;
extern bool_t ucs2_string_ge(obj_t, obj_t);
static obj_t _ucs2_string__list1283_67___unicode(obj_t, obj_t);
static obj_t _ucs2_string_length1266_173___unicode(obj_t, obj_t);
static obj_t _ucs2_string__1274_197___unicode(obj_t, obj_t, obj_t);
extern bool_t ucs2_string__76___unicode(obj_t);
extern obj_t ucs2_string_downcase_77___unicode(obj_t);
static obj_t cnst_init_137___unicode();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( ucs2_string__utf8_string_env_142___unicode, _ucs2_string__utf8_string1290_194___unicode1911, _ucs2_string__utf8_string1290_194___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ci____env_38___unicode, _ucs2_string_ci___1279_130___unicode1912, _ucs2_string_ci___1279_130___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ci____env_37___unicode, _ucs2_string_ci___1280_50___unicode1913, _ucs2_string_ci___1280_50___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_fill__env_181___unicode, _ucs2_string_fill_1285_169___unicode1914, _ucs2_string_fill_1285_169___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_downcase_env_169___unicode, _ucs2_string_downcase1287_26___unicode1915, _ucs2_string_downcase1287_26___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_append_env_17___unicode, _ucs2_string_append_9___unicode1916, va_generic_entry, _ucs2_string_append_9___unicode, -1 );
DEFINE_EXPORT_PROCEDURE( make_ucs2_string_env_163___unicode, _make_ucs2_string1265_5___unicode1917, va_generic_entry, _make_ucs2_string1265_5___unicode, -2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_upcase_env_136___unicode, _ucs2_string_upcase1286_140___unicode1918, _ucs2_string_upcase1286_140___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string__list_env_217___unicode, _ucs2_string__list1283_67___unicode1919, _ucs2_string__list1283_67___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_upcase__env_48___unicode, _ucs2_string_upcase_1288_79___unicode1920, _ucs2_string_upcase_1288_79___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string___env_245___unicode, _ucs2_string__1273_120___unicode1921, _ucs2_string__1273_120___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_set_ur__env_0___unicode, _ucs2_string_set_ur_1270_133___unicode1922, _ucs2_string_set_ur_1270_133___unicode, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( ucs2_string____env_63___unicode, _ucs2_string___1275_88___unicode1923, _ucs2_string___1275_88___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ref_env_251___unicode, _ucs2_string_ref1267_212___unicode1924, _ucs2_string_ref1267_212___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string____env_18___unicode, _ucs2_string___1276_197___unicode1925, _ucs2_string___1276_197___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( list__ucs2_string_env_231___unicode, _list__ucs2_string_171___unicode1926, _list__ucs2_string_171___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string___env_211___unicode, _ucs2_string__1271_247___unicode1927, _ucs2_string__1271_247___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_length_env_217___unicode, _ucs2_string_length1266_173___unicode1928, _ucs2_string_length1266_173___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( subucs2_string_ur_env_61___unicode, _subucs2_string_ur1282_163___unicode1929, _subucs2_string_ur1282_163___unicode, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ci___env_29___unicode, _ucs2_string_ci__1277_33___unicode1930, _ucs2_string_ci__1277_33___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( subucs2_string_env_64___unicode, _subucs2_string1281_10___unicode1931, _subucs2_string1281_10___unicode, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( ucs2_string___env_124___unicode, _ucs2_string__1274_197___unicode1932, _ucs2_string__1274_197___unicode, 0L, 2 );
DEFINE_STRING( string1908___unicode, string1908___unicode1933, "BSTRING", 7 );
DEFINE_STRING( string1883___unicode, string1883___unicode1934, "Illegal index", 13 );
DEFINE_STRING( string1882___unicode, string1882___unicode1935, "subucs2-string", 14 );
DEFINE_STRING( string1855___unicode, string1855___unicode1936, "ucs2-string-set!", 16 );
DEFINE_STRING( string1853___unicode, string1853___unicode1937, "LONG", 4 );
DEFINE_STRING( string1851___unicode, string1851___unicode1938, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1849___unicode, string1849___unicode1939, "ucs2-string-ref", 15 );
DEFINE_STRING( string1850___unicode, string1850___unicode1940, "index out of range", 18 );
DEFINE_STRING( string1847___unicode, string1847___unicode1941, "UCS2STRING", 10 );
DEFINE_STRING( string1843___unicode, string1843___unicode1942, "INT", 3 );
DEFINE_STRING( string1841___unicode, string1841___unicode1943, "UCS2", 4 );
DEFINE_STRING( string1839___unicode, string1839___unicode1944, "PAIR", 4 );
DEFINE_STRING( string1840___unicode, string1840___unicode1945, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/unicode.scm", 60 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_copy_env_8___unicode, _ucs2_string_copy1284_31___unicode1946, _ucs2_string_copy1284_31___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_set__env_239___unicode, _ucs2_string_set_1268_79___unicode1947, _ucs2_string_set_1268_79___unicode, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ci___env_62___unicode, _ucs2_string_ci__1272_63___unicode1948, _ucs2_string_ci__1272_63___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_downcase__env_73___unicode, _ucs2_string_downcase_1289_86___unicode1949, _ucs2_string_downcase_1289_86___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ci___env_46___unicode, _ucs2_string_ci__1278_164___unicode1950, _ucs2_string_ci__1278_164___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( utf8_string__ucs2_string_env_92___unicode, _utf8_string__ucs2_string1291_1___unicode1951, _utf8_string__ucs2_string1291_1___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_ref_ur_env_171___unicode, _ucs2_string_ref_ur1269_210___unicode1952, _ucs2_string_ref_ur1269_210___unicode, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_string__env_22___unicode, _ucs2_string__171___unicode1953, _ucs2_string__171___unicode, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_string_env_246___unicode, _ucs2_string_170___unicode1954, va_generic_entry, _ucs2_string_170___unicode, -1 );


/* module-initialization */obj_t module_initialization_70___unicode(long checksum_1482, char * from_1483)
{
if(CBOOL(require_initialization_114___unicode)){
require_initialization_114___unicode = BBOOL(((bool_t)0));
cnst_init_137___unicode();
imported_modules_init_94___unicode();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___unicode()
{
symbol1837___unicode = string_to_symbol("UCS2-STRING?");
symbol1838___unicode = string_to_symbol("MAKE-UCS2-STRING");
symbol1842___unicode = string_to_symbol("_MAKE-UCS2-STRING1265");
symbol1844___unicode = string_to_symbol("UCS2-STRING");
symbol1845___unicode = string_to_symbol("UCS2-STRING-LENGTH");
symbol1846___unicode = string_to_symbol("_UCS2-STRING-LENGTH1266");
symbol1848___unicode = string_to_symbol("UCS2-STRING-REF");
symbol1852___unicode = string_to_symbol("_UCS2-STRING-REF1267");
symbol1854___unicode = string_to_symbol("UCS2-STRING-SET!");
symbol1856___unicode = string_to_symbol("_UCS2-STRING-SET!1268");
symbol1857___unicode = string_to_symbol("UCS2-STRING-REF-UR");
symbol1858___unicode = string_to_symbol("_UCS2-STRING-REF-UR1269");
symbol1859___unicode = string_to_symbol("UCS2-STRING-SET-UR!");
symbol1860___unicode = string_to_symbol("_UCS2-STRING-SET-UR!1270");
symbol1861___unicode = string_to_symbol("UCS2-STRING=?");
symbol1862___unicode = string_to_symbol("_UCS2-STRING=?1271");
symbol1863___unicode = string_to_symbol("UCS2-STRING-CI=?");
symbol1864___unicode = string_to_symbol("_UCS2-STRING-CI=?1272");
symbol1865___unicode = string_to_symbol("UCS2-STRING<?");
symbol1866___unicode = string_to_symbol("_UCS2-STRING<?1273");
symbol1867___unicode = string_to_symbol("UCS2-STRING>?");
symbol1868___unicode = string_to_symbol("_UCS2-STRING>?1274");
symbol1869___unicode = string_to_symbol("UCS2-STRING<=?");
symbol1870___unicode = string_to_symbol("_UCS2-STRING<=?1275");
symbol1871___unicode = string_to_symbol("UCS2-STRING>=?");
symbol1872___unicode = string_to_symbol("_UCS2-STRING>=?1276");
symbol1873___unicode = string_to_symbol("UCS2-STRING-CI<?");
symbol1874___unicode = string_to_symbol("_UCS2-STRING-CI<?1277");
symbol1875___unicode = string_to_symbol("UCS2-STRING-CI>?");
symbol1876___unicode = string_to_symbol("_UCS2-STRING-CI>?1278");
symbol1877___unicode = string_to_symbol("UCS2-STRING-CI<=?");
symbol1878___unicode = string_to_symbol("_UCS2-STRING-CI<=?1279");
symbol1879___unicode = string_to_symbol("UCS2-STRING-CI>=?");
symbol1880___unicode = string_to_symbol("_UCS2-STRING-CI>=?1280");
symbol1881___unicode = string_to_symbol("SUBUCS2-STRING");
symbol1884___unicode = string_to_symbol("_SUBUCS2-STRING1281");
symbol1885___unicode = string_to_symbol("SUBUCS2-STRING-UR");
symbol1886___unicode = string_to_symbol("_SUBUCS2-STRING-UR1282");
symbol1887___unicode = string_to_symbol("UCS2-STRING-APPEND");
symbol1888___unicode = string_to_symbol("LOOP");
symbol1889___unicode = string_to_symbol("LIST->UCS2-STRING");
symbol1890___unicode = string_to_symbol("UCS2-STRING->LIST");
symbol1891___unicode = string_to_symbol("_UCS2-STRING->LIST1283");
symbol1892___unicode = string_to_symbol("UCS2-STRING-COPY");
symbol1893___unicode = string_to_symbol("_UCS2-STRING-COPY1284");
symbol1894___unicode = string_to_symbol("UCS2-STRING-FILL!");
symbol1895___unicode = string_to_symbol("_UCS2-STRING-FILL!1285");
symbol1896___unicode = string_to_symbol("UCS2-STRING-UPCASE");
symbol1897___unicode = string_to_symbol("_UCS2-STRING-UPCASE1286");
symbol1898___unicode = string_to_symbol("UCS2-STRING-DOWNCASE");
symbol1899___unicode = string_to_symbol("_UCS2-STRING-DOWNCASE1287");
symbol1900___unicode = string_to_symbol("UCS2-STRING-UPCASE!");
symbol1901___unicode = string_to_symbol("_UCS2-STRING-UPCASE!1288");
symbol1902___unicode = string_to_symbol("UCS2-STRING-DOWNCASE!");
symbol1903___unicode = string_to_symbol("_UCS2-STRING-DOWNCASE!1289");
symbol1904___unicode = string_to_symbol("UCS2-STRING->UTF8-STRING");
symbol1905___unicode = string_to_symbol("_UCS2-STRING->UTF8-STRING1290");
symbol1906___unicode = string_to_symbol("UTF8-STRING->UCS2-STRING");
symbol1907___unicode = string_to_symbol("_UTF8-STRING->UCS2-STRING1291");
return (symbol1909___unicode = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* ucs2-string? */bool_t ucs2_string__76___unicode(obj_t obj_1)
{
{
obj_t symbol1202_1332;
symbol1202_1332 = symbol1837___unicode;
{
PUSH_TRACE(symbol1202_1332);
BUNSPEC;
{
bool_t aux1201_1333;
aux1201_1333 = UCS2_STRINGP(obj_1);
POP_TRACE();
return aux1201_1333;
}
}
}
}


/* _ucs2-string? */obj_t _ucs2_string__171___unicode(obj_t env_798, obj_t obj_799)
{
{
bool_t aux_1552;
{
obj_t obj_1334;
obj_1334 = obj_799;
{
obj_t symbol1202_1335;
symbol1202_1335 = symbol1837___unicode;
{
PUSH_TRACE(symbol1202_1335);
BUNSPEC;
{
bool_t aux1201_1336;
aux1201_1336 = UCS2_STRINGP(obj_1334);
POP_TRACE();
aux_1552 = aux1201_1336;
}
}
}
}
return BBOOL(aux_1552);
}
}


/* make-ucs2-string */obj_t make_ucs2_string_75___unicode(int k_2, obj_t ucs2_3)
{
{
obj_t symbol1204_1337;
symbol1204_1337 = symbol1838___unicode;
{
PUSH_TRACE(symbol1204_1337);
BUNSPEC;
{
obj_t aux1203_1338;
if(NULLP(ucs2_3)){
ucs2_t arg1006_1339;
{
char char_1340;
char_1340 = (char)(((unsigned char)' '));
arg1006_1339 = (ucs2_t)(char_1340);
}
{
long aux_1562;
aux_1562 = (long)(k_2);
aux1203_1338 = make_ucs2_string(aux_1562, arg1006_1339);
}
}
 else {
obj_t arg1007_1341;
{
obj_t pair_1342;
if(PAIRP(ucs2_3)){
pair_1342 = ucs2_3;
}
 else {
bigloo_type_error_location_103___error(symbol1838___unicode, string1839___unicode, ucs2_3, string1840___unicode, BINT(((long)6952)));
exit( -1 );}
arg1007_1341 = CAR(pair_1342);
}
{
ucs2_t aux_1573;
long aux_1571;
{
obj_t aux_1574;
if(UCS2P(arg1007_1341)){
aux_1574 = arg1007_1341;
}
 else {
bigloo_type_error_location_103___error(symbol1838___unicode, string1841___unicode, arg1007_1341, string1840___unicode, BINT(((long)6929)));
exit( -1 );}
aux_1573 = CUCS2(aux_1574);
}
aux_1571 = (long)(k_2);
aux1203_1338 = make_ucs2_string(aux_1571, aux_1573);
}
}
POP_TRACE();
return aux1203_1338;
}
}
}
}


/* _make-ucs2-string1265 */obj_t _make_ucs2_string1265_5___unicode(obj_t env_800, obj_t k_801, obj_t ucs2_802)
{
{
int k_1343;
obj_t ucs2_1344;
{
obj_t aux_1583;
if(INTEGERP(k_801)){
aux_1583 = k_801;
}
 else {
bigloo_type_error_location_103___error(symbol1842___unicode, string1843___unicode, k_801, string1840___unicode, BINT(((long)6808)));
exit( -1 );}
k_1343 = CINT(aux_1583);
}
ucs2_1344 = ucs2_802;
{
obj_t symbol1204_1345;
symbol1204_1345 = symbol1838___unicode;
{
PUSH_TRACE(symbol1204_1345);
BUNSPEC;
{
obj_t aux1203_1346;
if(NULLP(ucs2_1344)){
ucs2_t arg1006_1347;
{
char char_1348;
char_1348 = (char)(((unsigned char)' '));
arg1006_1347 = (ucs2_t)(char_1348);
}
{
long aux_1595;
aux_1595 = (long)(k_1343);
aux1203_1346 = make_ucs2_string(aux_1595, arg1006_1347);
}
}
 else {
obj_t arg1007_1349;
{
obj_t pair_1350;
if(PAIRP(ucs2_1344)){
pair_1350 = ucs2_1344;
}
 else {
bigloo_type_error_location_103___error(symbol1838___unicode, string1839___unicode, ucs2_1344, string1840___unicode, BINT(((long)6952)));
exit( -1 );}
arg1007_1349 = CAR(pair_1350);
}
{
ucs2_t aux_1606;
long aux_1604;
{
obj_t aux_1607;
if(UCS2P(arg1007_1349)){
aux_1607 = arg1007_1349;
}
 else {
bigloo_type_error_location_103___error(symbol1838___unicode, string1841___unicode, arg1007_1349, string1840___unicode, BINT(((long)6929)));
exit( -1 );}
aux_1606 = CUCS2(aux_1607);
}
aux_1604 = (long)(k_1343);
aux1203_1346 = make_ucs2_string(aux_1604, aux_1606);
}
}
POP_TRACE();
return aux1203_1346;
}
}
}
}
}


/* ucs2-string */obj_t ucs2_string_194___unicode(obj_t ucs2s_4)
{
{
obj_t symbol1206_1351;
symbol1206_1351 = symbol1844___unicode;
{
PUSH_TRACE(symbol1206_1351);
BUNSPEC;
{
obj_t aux1205_1352;
aux1205_1352 = list__ucs2_string_55___unicode(ucs2s_4);
POP_TRACE();
return aux1205_1352;
}
}
}
}


/* _ucs2-string */obj_t _ucs2_string_170___unicode(obj_t env_803, obj_t ucs2s_804)
{
{
obj_t ucs2s_1353;
ucs2s_1353 = ucs2s_804;
{
obj_t symbol1206_1354;
symbol1206_1354 = symbol1844___unicode;
{
PUSH_TRACE(symbol1206_1354);
BUNSPEC;
{
obj_t aux1205_1355;
aux1205_1355 = list__ucs2_string_55___unicode(ucs2s_1353);
POP_TRACE();
return aux1205_1355;
}
}
}
}
}


/* ucs2-string-length */long ucs2_string_length_125___unicode(obj_t ucs2_string_194_5)
{
{
obj_t symbol1208_1356;
symbol1208_1356 = symbol1845___unicode;
{
PUSH_TRACE(symbol1208_1356);
BUNSPEC;
{
long aux1207_1357;
aux1207_1357 = UCS2_STRING_LENGTH(ucs2_string_194_5);
POP_TRACE();
return aux1207_1357;
}
}
}
}


/* _ucs2-string-length1266 */obj_t _ucs2_string_length1266_173___unicode(obj_t env_805, obj_t ucs2_string_194_806)
{
{
long aux_1625;
{
obj_t ucs2_string_194_1358;
if(UCS2_STRINGP(ucs2_string_194_806)){
ucs2_string_194_1358 = ucs2_string_194_806;
}
 else {
bigloo_type_error_location_103___error(symbol1846___unicode, string1847___unicode, ucs2_string_194_806, string1840___unicode, BINT(((long)7479)));
exit( -1 );}
{
obj_t symbol1208_1359;
symbol1208_1359 = symbol1845___unicode;
{
PUSH_TRACE(symbol1208_1359);
BUNSPEC;
{
long aux1207_1360;
aux1207_1360 = UCS2_STRING_LENGTH(ucs2_string_194_1358);
POP_TRACE();
aux_1625 = aux1207_1360;
}
}
}
}
return BINT(aux_1625);
}
}


/* ucs2-string-ref */ucs2_t ucs2_string_ref_239___unicode(obj_t ucs2_string_194_6, long k_7)
{
{
obj_t symbol1210_1361;
symbol1210_1361 = symbol1848___unicode;
{
PUSH_TRACE(symbol1210_1361);
BUNSPEC;
{
ucs2_t aux1209_1362;
{
bool_t test_1636;
{
long aux_1637;
aux_1637 = UCS2_STRING_LENGTH(ucs2_string_194_6);
test_1636 = BOUND_CHECK(k_7, aux_1637);
}
if(test_1636){
aux1209_1362 = UCS2_STRING_REF(ucs2_string_194_6, k_7);
}
 else {
obj_t aux_1641;
{
obj_t aux1320_1363;
aux1320_1363 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(k_7), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1320_1363)){
aux_1641 = aux1320_1363;
}
 else {
bigloo_type_error_location_103___error(symbol1848___unicode, string1841___unicode, aux1320_1363, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
aux1209_1362 = CUCS2(aux_1641);
}
}
POP_TRACE();
return aux1209_1362;
}
}
}
}


/* _ucs2-string-ref1267 */obj_t _ucs2_string_ref1267_212___unicode(obj_t env_807, obj_t ucs2_string_194_808, obj_t k_809)
{
{
ucs2_t aux_1652;
{
obj_t ucs2_string_194_1364;
long k_1365;
if(UCS2_STRINGP(ucs2_string_194_808)){
ucs2_string_194_1364 = ucs2_string_194_808;
}
 else {
bigloo_type_error_location_103___error(symbol1852___unicode, string1847___unicode, ucs2_string_194_808, string1840___unicode, BINT(((long)7789)));
exit( -1 );}
{
obj_t aux_1658;
if(INTEGERP(k_809)){
aux_1658 = k_809;
}
 else {
bigloo_type_error_location_103___error(symbol1852___unicode, string1853___unicode, k_809, string1840___unicode, BINT(((long)7789)));
exit( -1 );}
k_1365 = (long)CINT(aux_1658);
}
{
obj_t symbol1210_1366;
symbol1210_1366 = symbol1848___unicode;
{
PUSH_TRACE(symbol1210_1366);
BUNSPEC;
{
ucs2_t aux1209_1367;
{
bool_t test_1666;
{
long aux_1667;
aux_1667 = UCS2_STRING_LENGTH(ucs2_string_194_1364);
test_1666 = BOUND_CHECK(k_1365, aux_1667);
}
if(test_1666){
aux1209_1367 = UCS2_STRING_REF(ucs2_string_194_1364, k_1365);
}
 else {
obj_t aux_1671;
{
obj_t aux1320_1368;
aux1320_1368 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(k_1365), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1320_1368)){
aux_1671 = aux1320_1368;
}
 else {
bigloo_type_error_location_103___error(symbol1848___unicode, string1841___unicode, aux1320_1368, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
aux1209_1367 = CUCS2(aux_1671);
}
}
POP_TRACE();
aux_1652 = aux1209_1367;
}
}
}
}
return BUCS2(aux_1652);
}
}


/* ucs2-string-set! */obj_t ucs2_string_set__176___unicode(obj_t ucs2_string_194_8, long k_9, ucs2_t ucs2_10)
{
{
obj_t symbol1212_1369;
symbol1212_1369 = symbol1854___unicode;
{
PUSH_TRACE(symbol1212_1369);
BUNSPEC;
{
obj_t aux1211_1370;
{
bool_t test_1684;
{
long aux_1685;
aux_1685 = UCS2_STRING_LENGTH(ucs2_string_194_8);
test_1684 = BOUND_CHECK(k_9, aux_1685);
}
if(test_1684){
aux1211_1370 = UCS2_STRING_SET(ucs2_string_194_8, k_9, ucs2_10);
}
 else {
aux1211_1370 = debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(k_9), string1851___unicode, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1211_1370;
}
}
}
}


/* _ucs2-string-set!1268 */obj_t _ucs2_string_set_1268_79___unicode(obj_t env_810, obj_t ucs2_string_194_811, obj_t k_812, obj_t ucs2_813)
{
{
obj_t ucs2_string_194_1371;
long k_1372;
ucs2_t ucs2_1373;
if(UCS2_STRINGP(ucs2_string_194_811)){
ucs2_string_194_1371 = ucs2_string_194_811;
}
 else {
bigloo_type_error_location_103___error(symbol1856___unicode, string1847___unicode, ucs2_string_194_811, string1840___unicode, BINT(((long)8223)));
exit( -1 );}
{
obj_t aux_1698;
if(INTEGERP(k_812)){
aux_1698 = k_812;
}
 else {
bigloo_type_error_location_103___error(symbol1856___unicode, string1853___unicode, k_812, string1840___unicode, BINT(((long)8223)));
exit( -1 );}
k_1372 = (long)CINT(aux_1698);
}
{
obj_t aux_1705;
if(UCS2P(ucs2_813)){
aux_1705 = ucs2_813;
}
 else {
bigloo_type_error_location_103___error(symbol1856___unicode, string1841___unicode, ucs2_813, string1840___unicode, BINT(((long)8223)));
exit( -1 );}
ucs2_1373 = CUCS2(aux_1705);
}
{
obj_t symbol1212_1374;
symbol1212_1374 = symbol1854___unicode;
{
PUSH_TRACE(symbol1212_1374);
BUNSPEC;
{
obj_t aux1211_1375;
{
bool_t test_1713;
{
long aux_1714;
aux_1714 = UCS2_STRING_LENGTH(ucs2_string_194_1371);
test_1713 = BOUND_CHECK(k_1372, aux_1714);
}
if(test_1713){
aux1211_1375 = UCS2_STRING_SET(ucs2_string_194_1371, k_1372, ucs2_1373);
}
 else {
aux1211_1375 = debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(k_1372), string1851___unicode, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1211_1375;
}
}
}
}
}


/* ucs2-string-ref-ur */ucs2_t ucs2_string_ref_ur_85___unicode(obj_t ucs2_string_194_11, long k_12)
{
{
obj_t symbol1214_1376;
symbol1214_1376 = symbol1857___unicode;
{
PUSH_TRACE(symbol1214_1376);
BUNSPEC;
{
ucs2_t aux1213_1377;
aux1213_1377 = UCS2_STRING_REF(ucs2_string_194_11, k_12);
POP_TRACE();
return aux1213_1377;
}
}
}
}


/* _ucs2-string-ref-ur1269 */obj_t _ucs2_string_ref_ur1269_210___unicode(obj_t env_814, obj_t ucs2_string_194_815, obj_t k_816)
{
{
ucs2_t aux_1725;
{
obj_t ucs2_string_194_1378;
long k_1379;
if(UCS2_STRINGP(ucs2_string_194_815)){
ucs2_string_194_1378 = ucs2_string_194_815;
}
 else {
bigloo_type_error_location_103___error(symbol1858___unicode, string1847___unicode, ucs2_string_194_815, string1840___unicode, BINT(((long)8669)));
exit( -1 );}
{
obj_t aux_1731;
if(INTEGERP(k_816)){
aux_1731 = k_816;
}
 else {
bigloo_type_error_location_103___error(symbol1858___unicode, string1853___unicode, k_816, string1840___unicode, BINT(((long)8669)));
exit( -1 );}
k_1379 = (long)CINT(aux_1731);
}
{
obj_t symbol1214_1380;
symbol1214_1380 = symbol1857___unicode;
{
PUSH_TRACE(symbol1214_1380);
BUNSPEC;
{
ucs2_t aux1213_1381;
aux1213_1381 = UCS2_STRING_REF(ucs2_string_194_1378, k_1379);
POP_TRACE();
aux_1725 = aux1213_1381;
}
}
}
}
return BUCS2(aux_1725);
}
}


/* ucs2-string-set-ur! */obj_t ucs2_string_set_ur__94___unicode(obj_t ucs2_string_194_13, long k_14, ucs2_t ucs2_15)
{
{
obj_t symbol1216_1382;
symbol1216_1382 = symbol1859___unicode;
{
PUSH_TRACE(symbol1216_1382);
BUNSPEC;
{
obj_t aux1215_1383;
aux1215_1383 = UCS2_STRING_SET(ucs2_string_194_13, k_14, ucs2_15);
POP_TRACE();
return aux1215_1383;
}
}
}
}


/* _ucs2-string-set-ur!1270 */obj_t _ucs2_string_set_ur_1270_133___unicode(obj_t env_817, obj_t ucs2_string_194_818, obj_t k_819, obj_t ucs2_820)
{
{
obj_t ucs2_string_194_1384;
long k_1385;
ucs2_t ucs2_1386;
if(UCS2_STRINGP(ucs2_string_194_818)){
ucs2_string_194_1384 = ucs2_string_194_818;
}
 else {
bigloo_type_error_location_103___error(symbol1860___unicode, string1847___unicode, ucs2_string_194_818, string1840___unicode, BINT(((long)8981)));
exit( -1 );}
{
obj_t aux_1750;
if(INTEGERP(k_819)){
aux_1750 = k_819;
}
 else {
bigloo_type_error_location_103___error(symbol1860___unicode, string1853___unicode, k_819, string1840___unicode, BINT(((long)8981)));
exit( -1 );}
k_1385 = (long)CINT(aux_1750);
}
{
obj_t aux_1757;
if(UCS2P(ucs2_820)){
aux_1757 = ucs2_820;
}
 else {
bigloo_type_error_location_103___error(symbol1860___unicode, string1841___unicode, ucs2_820, string1840___unicode, BINT(((long)8981)));
exit( -1 );}
ucs2_1386 = CUCS2(aux_1757);
}
{
obj_t symbol1216_1387;
symbol1216_1387 = symbol1859___unicode;
{
PUSH_TRACE(symbol1216_1387);
BUNSPEC;
{
obj_t aux1215_1388;
aux1215_1388 = UCS2_STRING_SET(ucs2_string_194_1384, k_1385, ucs2_1386);
POP_TRACE();
return aux1215_1388;
}
}
}
}
}


/* ucs2-string=? */bool_t ucs2_string___146___unicode(obj_t ucs2_string1_235_16, obj_t ucs2_string2_163_17)
{
{
obj_t symbol1218_1389;
symbol1218_1389 = symbol1861___unicode;
{
PUSH_TRACE(symbol1218_1389);
BUNSPEC;
{
bool_t aux1217_1390;
aux1217_1390 = ucs2_strcmp(ucs2_string1_235_16, ucs2_string2_163_17);
POP_TRACE();
return aux1217_1390;
}
}
}
}


/* _ucs2-string=?1271 */obj_t _ucs2_string__1271_247___unicode(obj_t env_821, obj_t ucs2_string1_235_822, obj_t ucs2_string2_163_823)
{
{
bool_t aux_1770;
{
obj_t ucs2_string1_235_1391;
obj_t ucs2_string2_163_1392;
if(UCS2_STRINGP(ucs2_string1_235_822)){
ucs2_string1_235_1391 = ucs2_string1_235_822;
}
 else {
bigloo_type_error_location_103___error(symbol1862___unicode, string1847___unicode, ucs2_string1_235_822, string1840___unicode, BINT(((long)9304)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_823)){
ucs2_string2_163_1392 = ucs2_string2_163_823;
}
 else {
bigloo_type_error_location_103___error(symbol1862___unicode, string1847___unicode, ucs2_string2_163_823, string1840___unicode, BINT(((long)9304)));
exit( -1 );}
{
obj_t symbol1218_1393;
symbol1218_1393 = symbol1861___unicode;
{
PUSH_TRACE(symbol1218_1393);
BUNSPEC;
{
bool_t aux1217_1394;
aux1217_1394 = ucs2_strcmp(ucs2_string1_235_1391, ucs2_string2_163_1392);
POP_TRACE();
aux_1770 = aux1217_1394;
}
}
}
}
return BBOOL(aux_1770);
}
}


/* ucs2-string-ci=? */bool_t ucs2_string_ci___247___unicode(obj_t ucs2_string1_235_18, obj_t ucs2_string2_163_19)
{
{
obj_t symbol1220_1395;
symbol1220_1395 = symbol1863___unicode;
{
PUSH_TRACE(symbol1220_1395);
BUNSPEC;
{
bool_t aux1219_1396;
aux1219_1396 = ucs2_strcicmp(ucs2_string1_235_18, ucs2_string2_163_19);
POP_TRACE();
return aux1219_1396;
}
}
}
}


/* _ucs2-string-ci=?1272 */obj_t _ucs2_string_ci__1272_63___unicode(obj_t env_824, obj_t ucs2_string1_235_825, obj_t ucs2_string2_163_826)
{
{
bool_t aux_1788;
{
obj_t ucs2_string1_235_1397;
obj_t ucs2_string2_163_1398;
if(UCS2_STRINGP(ucs2_string1_235_825)){
ucs2_string1_235_1397 = ucs2_string1_235_825;
}
 else {
bigloo_type_error_location_103___error(symbol1864___unicode, string1847___unicode, ucs2_string1_235_825, string1840___unicode, BINT(((long)9632)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_826)){
ucs2_string2_163_1398 = ucs2_string2_163_826;
}
 else {
bigloo_type_error_location_103___error(symbol1864___unicode, string1847___unicode, ucs2_string2_163_826, string1840___unicode, BINT(((long)9632)));
exit( -1 );}
{
obj_t symbol1220_1399;
symbol1220_1399 = symbol1863___unicode;
{
PUSH_TRACE(symbol1220_1399);
BUNSPEC;
{
bool_t aux1219_1400;
aux1219_1400 = ucs2_strcicmp(ucs2_string1_235_1397, ucs2_string2_163_1398);
POP_TRACE();
aux_1788 = aux1219_1400;
}
}
}
}
return BBOOL(aux_1788);
}
}


/* ucs2-string<? */bool_t ucs2_string___83___unicode(obj_t ucs2_string1_235_20, obj_t ucs2_string2_163_21)
{
{
obj_t symbol1222_1401;
symbol1222_1401 = symbol1865___unicode;
{
PUSH_TRACE(symbol1222_1401);
BUNSPEC;
{
bool_t aux1221_1402;
aux1221_1402 = ucs2_string_lt(ucs2_string1_235_20, ucs2_string2_163_21);
POP_TRACE();
return aux1221_1402;
}
}
}
}


/* _ucs2-string<?1273 */obj_t _ucs2_string__1273_120___unicode(obj_t env_827, obj_t ucs2_string1_235_828, obj_t ucs2_string2_163_829)
{
{
bool_t aux_1806;
{
obj_t ucs2_string1_235_1403;
obj_t ucs2_string2_163_1404;
if(UCS2_STRINGP(ucs2_string1_235_828)){
ucs2_string1_235_1403 = ucs2_string1_235_828;
}
 else {
bigloo_type_error_location_103___error(symbol1866___unicode, string1847___unicode, ucs2_string1_235_828, string1840___unicode, BINT(((long)9961)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_829)){
ucs2_string2_163_1404 = ucs2_string2_163_829;
}
 else {
bigloo_type_error_location_103___error(symbol1866___unicode, string1847___unicode, ucs2_string2_163_829, string1840___unicode, BINT(((long)9961)));
exit( -1 );}
{
obj_t symbol1222_1405;
symbol1222_1405 = symbol1865___unicode;
{
PUSH_TRACE(symbol1222_1405);
BUNSPEC;
{
bool_t aux1221_1406;
aux1221_1406 = ucs2_string_lt(ucs2_string1_235_1403, ucs2_string2_163_1404);
POP_TRACE();
aux_1806 = aux1221_1406;
}
}
}
}
return BBOOL(aux_1806);
}
}


/* ucs2-string>? */bool_t ucs2_string___248___unicode(obj_t ucs2_string1_235_22, obj_t ucs2_string2_163_23)
{
{
obj_t symbol1224_1407;
symbol1224_1407 = symbol1867___unicode;
{
PUSH_TRACE(symbol1224_1407);
BUNSPEC;
{
bool_t aux1223_1408;
aux1223_1408 = ucs2_string_gt(ucs2_string1_235_22, ucs2_string2_163_23);
POP_TRACE();
return aux1223_1408;
}
}
}
}


/* _ucs2-string>?1274 */obj_t _ucs2_string__1274_197___unicode(obj_t env_830, obj_t ucs2_string1_235_831, obj_t ucs2_string2_163_832)
{
{
bool_t aux_1824;
{
obj_t ucs2_string1_235_1409;
obj_t ucs2_string2_163_1410;
if(UCS2_STRINGP(ucs2_string1_235_831)){
ucs2_string1_235_1409 = ucs2_string1_235_831;
}
 else {
bigloo_type_error_location_103___error(symbol1868___unicode, string1847___unicode, ucs2_string1_235_831, string1840___unicode, BINT(((long)10288)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_832)){
ucs2_string2_163_1410 = ucs2_string2_163_832;
}
 else {
bigloo_type_error_location_103___error(symbol1868___unicode, string1847___unicode, ucs2_string2_163_832, string1840___unicode, BINT(((long)10288)));
exit( -1 );}
{
obj_t symbol1224_1411;
symbol1224_1411 = symbol1867___unicode;
{
PUSH_TRACE(symbol1224_1411);
BUNSPEC;
{
bool_t aux1223_1412;
aux1223_1412 = ucs2_string_gt(ucs2_string1_235_1409, ucs2_string2_163_1410);
POP_TRACE();
aux_1824 = aux1223_1412;
}
}
}
}
return BBOOL(aux_1824);
}
}


/* ucs2-string<=? */bool_t ucs2_string____33___unicode(obj_t ucs2_string1_235_24, obj_t ucs2_string2_163_25)
{
{
obj_t symbol1226_1413;
symbol1226_1413 = symbol1869___unicode;
{
PUSH_TRACE(symbol1226_1413);
BUNSPEC;
{
bool_t aux1225_1414;
aux1225_1414 = ucs2_string_le(ucs2_string1_235_24, ucs2_string2_163_25);
POP_TRACE();
return aux1225_1414;
}
}
}
}


/* _ucs2-string<=?1275 */obj_t _ucs2_string___1275_88___unicode(obj_t env_833, obj_t ucs2_string1_235_834, obj_t ucs2_string2_163_835)
{
{
bool_t aux_1842;
{
obj_t ucs2_string1_235_1415;
obj_t ucs2_string2_163_1416;
if(UCS2_STRINGP(ucs2_string1_235_834)){
ucs2_string1_235_1415 = ucs2_string1_235_834;
}
 else {
bigloo_type_error_location_103___error(symbol1870___unicode, string1847___unicode, ucs2_string1_235_834, string1840___unicode, BINT(((long)10615)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_835)){
ucs2_string2_163_1416 = ucs2_string2_163_835;
}
 else {
bigloo_type_error_location_103___error(symbol1870___unicode, string1847___unicode, ucs2_string2_163_835, string1840___unicode, BINT(((long)10615)));
exit( -1 );}
{
obj_t symbol1226_1417;
symbol1226_1417 = symbol1869___unicode;
{
PUSH_TRACE(symbol1226_1417);
BUNSPEC;
{
bool_t aux1225_1418;
aux1225_1418 = ucs2_string_le(ucs2_string1_235_1415, ucs2_string2_163_1416);
POP_TRACE();
aux_1842 = aux1225_1418;
}
}
}
}
return BBOOL(aux_1842);
}
}


/* ucs2-string>=? */bool_t ucs2_string____135___unicode(obj_t ucs2_string1_235_26, obj_t ucs2_string2_163_27)
{
{
obj_t symbol1228_1419;
symbol1228_1419 = symbol1871___unicode;
{
PUSH_TRACE(symbol1228_1419);
BUNSPEC;
{
bool_t aux1227_1420;
aux1227_1420 = ucs2_string_ge(ucs2_string1_235_26, ucs2_string2_163_27);
POP_TRACE();
return aux1227_1420;
}
}
}
}


/* _ucs2-string>=?1276 */obj_t _ucs2_string___1276_197___unicode(obj_t env_836, obj_t ucs2_string1_235_837, obj_t ucs2_string2_163_838)
{
{
bool_t aux_1860;
{
obj_t ucs2_string1_235_1421;
obj_t ucs2_string2_163_1422;
if(UCS2_STRINGP(ucs2_string1_235_837)){
ucs2_string1_235_1421 = ucs2_string1_235_837;
}
 else {
bigloo_type_error_location_103___error(symbol1872___unicode, string1847___unicode, ucs2_string1_235_837, string1840___unicode, BINT(((long)10943)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_838)){
ucs2_string2_163_1422 = ucs2_string2_163_838;
}
 else {
bigloo_type_error_location_103___error(symbol1872___unicode, string1847___unicode, ucs2_string2_163_838, string1840___unicode, BINT(((long)10943)));
exit( -1 );}
{
obj_t symbol1228_1423;
symbol1228_1423 = symbol1871___unicode;
{
PUSH_TRACE(symbol1228_1423);
BUNSPEC;
{
bool_t aux1227_1424;
aux1227_1424 = ucs2_string_ge(ucs2_string1_235_1421, ucs2_string2_163_1422);
POP_TRACE();
aux_1860 = aux1227_1424;
}
}
}
}
return BBOOL(aux_1860);
}
}


/* ucs2-string-ci<? */bool_t ucs2_string_ci___92___unicode(obj_t ucs2_string1_235_28, obj_t ucs2_string2_163_29)
{
{
obj_t symbol1230_1425;
symbol1230_1425 = symbol1873___unicode;
{
PUSH_TRACE(symbol1230_1425);
BUNSPEC;
{
bool_t aux1229_1426;
aux1229_1426 = ucs2_string_cilt(ucs2_string1_235_28, ucs2_string2_163_29);
POP_TRACE();
return aux1229_1426;
}
}
}
}


/* _ucs2-string-ci<?1277 */obj_t _ucs2_string_ci__1277_33___unicode(obj_t env_839, obj_t ucs2_string1_235_840, obj_t ucs2_string2_163_841)
{
{
bool_t aux_1878;
{
obj_t ucs2_string1_235_1427;
obj_t ucs2_string2_163_1428;
if(UCS2_STRINGP(ucs2_string1_235_840)){
ucs2_string1_235_1427 = ucs2_string1_235_840;
}
 else {
bigloo_type_error_location_103___error(symbol1874___unicode, string1847___unicode, ucs2_string1_235_840, string1840___unicode, BINT(((long)11271)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_841)){
ucs2_string2_163_1428 = ucs2_string2_163_841;
}
 else {
bigloo_type_error_location_103___error(symbol1874___unicode, string1847___unicode, ucs2_string2_163_841, string1840___unicode, BINT(((long)11271)));
exit( -1 );}
{
obj_t symbol1230_1429;
symbol1230_1429 = symbol1873___unicode;
{
PUSH_TRACE(symbol1230_1429);
BUNSPEC;
{
bool_t aux1229_1430;
aux1229_1430 = ucs2_string_cilt(ucs2_string1_235_1427, ucs2_string2_163_1428);
POP_TRACE();
aux_1878 = aux1229_1430;
}
}
}
}
return BBOOL(aux_1878);
}
}


/* ucs2-string-ci>? */bool_t ucs2_string_ci___60___unicode(obj_t ucs2_string1_235_30, obj_t ucs2_string2_163_31)
{
{
obj_t symbol1232_1431;
symbol1232_1431 = symbol1875___unicode;
{
PUSH_TRACE(symbol1232_1431);
BUNSPEC;
{
bool_t aux1231_1432;
aux1231_1432 = ucs2_string_cigt(ucs2_string1_235_30, ucs2_string2_163_31);
POP_TRACE();
return aux1231_1432;
}
}
}
}


/* _ucs2-string-ci>?1278 */obj_t _ucs2_string_ci__1278_164___unicode(obj_t env_842, obj_t ucs2_string1_235_843, obj_t ucs2_string2_163_844)
{
{
bool_t aux_1896;
{
obj_t ucs2_string1_235_1433;
obj_t ucs2_string2_163_1434;
if(UCS2_STRINGP(ucs2_string1_235_843)){
ucs2_string1_235_1433 = ucs2_string1_235_843;
}
 else {
bigloo_type_error_location_103___error(symbol1876___unicode, string1847___unicode, ucs2_string1_235_843, string1840___unicode, BINT(((long)11603)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_844)){
ucs2_string2_163_1434 = ucs2_string2_163_844;
}
 else {
bigloo_type_error_location_103___error(symbol1876___unicode, string1847___unicode, ucs2_string2_163_844, string1840___unicode, BINT(((long)11603)));
exit( -1 );}
{
obj_t symbol1232_1435;
symbol1232_1435 = symbol1875___unicode;
{
PUSH_TRACE(symbol1232_1435);
BUNSPEC;
{
bool_t aux1231_1436;
aux1231_1436 = ucs2_string_cigt(ucs2_string1_235_1433, ucs2_string2_163_1434);
POP_TRACE();
aux_1896 = aux1231_1436;
}
}
}
}
return BBOOL(aux_1896);
}
}


/* ucs2-string-ci<=? */bool_t ucs2_string_ci____210___unicode(obj_t ucs2_string1_235_32, obj_t ucs2_string2_163_33)
{
{
obj_t symbol1234_1437;
symbol1234_1437 = symbol1877___unicode;
{
PUSH_TRACE(symbol1234_1437);
BUNSPEC;
{
bool_t aux1233_1438;
aux1233_1438 = ucs2_string_cile(ucs2_string1_235_32, ucs2_string2_163_33);
POP_TRACE();
return aux1233_1438;
}
}
}
}


/* _ucs2-string-ci<=?1279 */obj_t _ucs2_string_ci___1279_130___unicode(obj_t env_845, obj_t ucs2_string1_235_846, obj_t ucs2_string2_163_847)
{
{
bool_t aux_1914;
{
obj_t ucs2_string1_235_1439;
obj_t ucs2_string2_163_1440;
if(UCS2_STRINGP(ucs2_string1_235_846)){
ucs2_string1_235_1439 = ucs2_string1_235_846;
}
 else {
bigloo_type_error_location_103___error(symbol1878___unicode, string1847___unicode, ucs2_string1_235_846, string1840___unicode, BINT(((long)11935)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_847)){
ucs2_string2_163_1440 = ucs2_string2_163_847;
}
 else {
bigloo_type_error_location_103___error(symbol1878___unicode, string1847___unicode, ucs2_string2_163_847, string1840___unicode, BINT(((long)11935)));
exit( -1 );}
{
obj_t symbol1234_1441;
symbol1234_1441 = symbol1877___unicode;
{
PUSH_TRACE(symbol1234_1441);
BUNSPEC;
{
bool_t aux1233_1442;
aux1233_1442 = ucs2_string_cile(ucs2_string1_235_1439, ucs2_string2_163_1440);
POP_TRACE();
aux_1914 = aux1233_1442;
}
}
}
}
return BBOOL(aux_1914);
}
}


/* ucs2-string-ci>=? */bool_t ucs2_string_ci____43___unicode(obj_t ucs2_string1_235_34, obj_t ucs2_string2_163_35)
{
{
obj_t symbol1236_1443;
symbol1236_1443 = symbol1879___unicode;
{
PUSH_TRACE(symbol1236_1443);
BUNSPEC;
{
bool_t aux1235_1444;
aux1235_1444 = ucs2_string_cige(ucs2_string1_235_34, ucs2_string2_163_35);
POP_TRACE();
return aux1235_1444;
}
}
}
}


/* _ucs2-string-ci>=?1280 */obj_t _ucs2_string_ci___1280_50___unicode(obj_t env_848, obj_t ucs2_string1_235_849, obj_t ucs2_string2_163_850)
{
{
bool_t aux_1932;
{
obj_t ucs2_string1_235_1445;
obj_t ucs2_string2_163_1446;
if(UCS2_STRINGP(ucs2_string1_235_849)){
ucs2_string1_235_1445 = ucs2_string1_235_849;
}
 else {
bigloo_type_error_location_103___error(symbol1880___unicode, string1847___unicode, ucs2_string1_235_849, string1840___unicode, BINT(((long)12268)));
exit( -1 );}
if(UCS2_STRINGP(ucs2_string2_163_850)){
ucs2_string2_163_1446 = ucs2_string2_163_850;
}
 else {
bigloo_type_error_location_103___error(symbol1880___unicode, string1847___unicode, ucs2_string2_163_850, string1840___unicode, BINT(((long)12268)));
exit( -1 );}
{
obj_t symbol1236_1447;
symbol1236_1447 = symbol1879___unicode;
{
PUSH_TRACE(symbol1236_1447);
BUNSPEC;
{
bool_t aux1235_1448;
aux1235_1448 = ucs2_string_cige(ucs2_string1_235_1445, ucs2_string2_163_1446);
POP_TRACE();
aux_1932 = aux1235_1448;
}
}
}
}
return BBOOL(aux_1932);
}
}


/* subucs2-string */obj_t subucs2_string_27___unicode(obj_t ucs2_string_194_36, long start_37, long end_38)
{
{
obj_t symbol1238_1449;
symbol1238_1449 = symbol1881___unicode;
{
PUSH_TRACE(symbol1238_1449);
BUNSPEC;
{
obj_t aux1237_1450;
{
bool_t test_1948;
if((end_38>=start_37)){
bool_t test_1951;
{
long aux_1952;
{
long aux_1953;
aux_1953 = UCS2_STRING_LENGTH(ucs2_string_194_36);
aux_1952 = (aux_1953+((long)1));
}
test_1951 = BOUND_CHECK(start_37, aux_1952);
}
if(test_1951){
long aux_1957;
{
long aux_1958;
aux_1958 = UCS2_STRING_LENGTH(ucs2_string_194_36);
aux_1957 = (aux_1958+((long)1));
}
test_1948 = BOUND_CHECK(end_38, aux_1957);
}
 else {
test_1948 = ((bool_t)0);
}
}
 else {
test_1948 = ((bool_t)0);
}
if(test_1948){
aux1237_1450 = c_subucs2_string(ucs2_string_194_36, start_37, end_38);
}
 else {
obj_t arg1015_1451;
{
obj_t aux_1965;
obj_t aux_1963;
aux_1965 = BINT(end_38);
aux_1963 = BINT(start_37);
arg1015_1451 = MAKE_PAIR(aux_1963, aux_1965);
}
{
obj_t aux1551_1452;
aux1551_1452 = debug_error_location_199___error(string1882___unicode, string1883___unicode, arg1015_1451, string1851___unicode, BINT(((long)7610)));
if(UCS2_STRINGP(aux1551_1452)){
aux1237_1450 = aux1551_1452;
}
 else {
bigloo_type_error_location_103___error(symbol1881___unicode, string1847___unicode, aux1551_1452, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1237_1450;
}
}
}
}


/* _subucs2-string1281 */obj_t _subucs2_string1281_10___unicode(obj_t env_851, obj_t ucs2_string_194_852, obj_t start_853, obj_t end_854)
{
{
obj_t ucs2_string_194_1453;
long start_1454;
long end_1455;
if(UCS2_STRINGP(ucs2_string_194_852)){
ucs2_string_194_1453 = ucs2_string_194_852;
}
 else {
bigloo_type_error_location_103___error(symbol1884___unicode, string1847___unicode, ucs2_string_194_852, string1840___unicode, BINT(((long)12601)));
exit( -1 );}
{
obj_t aux_1981;
if(INTEGERP(start_853)){
aux_1981 = start_853;
}
 else {
bigloo_type_error_location_103___error(symbol1884___unicode, string1853___unicode, start_853, string1840___unicode, BINT(((long)12601)));
exit( -1 );}
start_1454 = (long)CINT(aux_1981);
}
{
obj_t aux_1988;
if(INTEGERP(end_854)){
aux_1988 = end_854;
}
 else {
bigloo_type_error_location_103___error(symbol1884___unicode, string1853___unicode, end_854, string1840___unicode, BINT(((long)12601)));
exit( -1 );}
end_1455 = (long)CINT(aux_1988);
}
{
obj_t symbol1238_1456;
symbol1238_1456 = symbol1881___unicode;
{
PUSH_TRACE(symbol1238_1456);
BUNSPEC;
{
obj_t aux1237_1457;
{
bool_t test_1996;
if((end_1455>=start_1454)){
bool_t test_1999;
{
long aux_2000;
{
long aux_2001;
aux_2001 = UCS2_STRING_LENGTH(ucs2_string_194_1453);
aux_2000 = (aux_2001+((long)1));
}
test_1999 = BOUND_CHECK(start_1454, aux_2000);
}
if(test_1999){
long aux_2005;
{
long aux_2006;
aux_2006 = UCS2_STRING_LENGTH(ucs2_string_194_1453);
aux_2005 = (aux_2006+((long)1));
}
test_1996 = BOUND_CHECK(end_1455, aux_2005);
}
 else {
test_1996 = ((bool_t)0);
}
}
 else {
test_1996 = ((bool_t)0);
}
if(test_1996){
aux1237_1457 = c_subucs2_string(ucs2_string_194_1453, start_1454, end_1455);
}
 else {
obj_t arg1015_1458;
{
obj_t aux_2013;
obj_t aux_2011;
aux_2013 = BINT(end_1455);
aux_2011 = BINT(start_1454);
arg1015_1458 = MAKE_PAIR(aux_2011, aux_2013);
}
{
obj_t aux1551_1459;
aux1551_1459 = debug_error_location_199___error(string1882___unicode, string1883___unicode, arg1015_1458, string1851___unicode, BINT(((long)7610)));
if(UCS2_STRINGP(aux1551_1459)){
aux1237_1457 = aux1551_1459;
}
 else {
bigloo_type_error_location_103___error(symbol1881___unicode, string1847___unicode, aux1551_1459, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
}
}
POP_TRACE();
return aux1237_1457;
}
}
}
}
}


/* subucs2-string-ur */obj_t subucs2_string_ur_47___unicode(obj_t ucs2_string_194_39, long start_40, long end_41)
{
{
obj_t symbol1240_1460;
symbol1240_1460 = symbol1885___unicode;
{
PUSH_TRACE(symbol1240_1460);
BUNSPEC;
{
obj_t aux1239_1461;
aux1239_1461 = c_subucs2_string(ucs2_string_194_39, start_40, end_41);
POP_TRACE();
return aux1239_1461;
}
}
}
}


/* _subucs2-string-ur1282 */obj_t _subucs2_string_ur1282_163___unicode(obj_t env_855, obj_t ucs2_string_194_856, obj_t start_857, obj_t end_858)
{
{
obj_t ucs2_string_194_1462;
long start_1463;
long end_1464;
if(UCS2_STRINGP(ucs2_string_194_856)){
ucs2_string_194_1462 = ucs2_string_194_856;
}
 else {
bigloo_type_error_location_103___error(symbol1886___unicode, string1847___unicode, ucs2_string_194_856, string1840___unicode, BINT(((long)13256)));
exit( -1 );}
{
obj_t aux_2032;
if(INTEGERP(start_857)){
aux_2032 = start_857;
}
 else {
bigloo_type_error_location_103___error(symbol1886___unicode, string1853___unicode, start_857, string1840___unicode, BINT(((long)13256)));
exit( -1 );}
start_1463 = (long)CINT(aux_2032);
}
{
obj_t aux_2039;
if(INTEGERP(end_858)){
aux_2039 = end_858;
}
 else {
bigloo_type_error_location_103___error(symbol1886___unicode, string1853___unicode, end_858, string1840___unicode, BINT(((long)13256)));
exit( -1 );}
end_1464 = (long)CINT(aux_2039);
}
{
obj_t symbol1240_1465;
symbol1240_1465 = symbol1885___unicode;
{
PUSH_TRACE(symbol1240_1465);
BUNSPEC;
{
obj_t aux1239_1466;
aux1239_1466 = c_subucs2_string(ucs2_string_194_1462, start_1463, end_1464);
POP_TRACE();
return aux1239_1466;
}
}
}
}
}


/* ucs2-string-append */obj_t ucs2_string_append_106___unicode(obj_t list_42)
{
{
obj_t symbol1242_774;
symbol1242_774 = symbol1887___unicode;
{
PUSH_TRACE(symbol1242_774);
BUNSPEC;
{
obj_t aux1241_775;
if(NULLP(list_42)){
obj_t res1192_560;
{
int k_552;
k_552 = (int)(((long)0));
{
ucs2_t arg1006_555;
{
char char_166_558;
char_166_558 = (char)(((unsigned char)' '));
arg1006_555 = (ucs2_t)(char_166_558);
}
{
long aux_2055;
aux_2055 = (long)(k_552);
res1192_560 = make_ucs2_string(aux_2055, arg1006_555);
}
}
}
aux1241_775 = res1192_560;
}
 else {
obj_t aux1618_1146;
aux1618_1146 = loop___unicode(list_42);
if(UCS2_STRINGP(aux1618_1146)){
aux1241_775 = aux1618_1146;
}
 else {
bigloo_type_error_location_103___error(symbol1887___unicode, string1847___unicode, aux1618_1146, string1840___unicode, BINT(((long)13672)));
exit( -1 );}
}
POP_TRACE();
return aux1241_775;
}
}
}
}


/* loop */obj_t loop___unicode(obj_t list_314)
{
{
bool_t test1026_316;
{
obj_t arg1030_320;
{
obj_t pair_561;
if(PAIRP(list_314)){
pair_561 = list_314;
}
 else {
bigloo_type_error_location_103___error(symbol1888___unicode, string1839___unicode, list_314, string1840___unicode, BINT(((long)13711)));
exit( -1 );}
arg1030_320 = CDR(pair_561);
}
test1026_316 = NULLP(arg1030_320);
}
if(test1026_316){
obj_t pair_563;
if(PAIRP(list_314)){
pair_563 = list_314;
}
 else {
bigloo_type_error_location_103___error(symbol1888___unicode, string1839___unicode, list_314, string1840___unicode, BINT(((long)13730)));
exit( -1 );}
return CAR(pair_563);
}
 else {
obj_t arg1027_317;
obj_t arg1028_318;
{
obj_t pair_564;
if(PAIRP(list_314)){
pair_564 = list_314;
}
 else {
bigloo_type_error_location_103___error(symbol1888___unicode, string1839___unicode, list_314, string1840___unicode, BINT(((long)13770)));
exit( -1 );}
arg1027_317 = CAR(pair_564);
}
{
obj_t arg1029_319;
{
obj_t pair_565;
if(PAIRP(list_314)){
pair_565 = list_314;
}
 else {
bigloo_type_error_location_103___error(symbol1888___unicode, string1839___unicode, list_314, string1840___unicode, BINT(((long)13787)));
exit( -1 );}
arg1029_319 = CDR(pair_565);
}
arg1028_318 = loop___unicode(arg1029_319);
}
{
obj_t aux_2098;
obj_t aux_2092;
if(UCS2_STRINGP(arg1028_318)){
aux_2098 = arg1028_318;
}
 else {
bigloo_type_error_location_103___error(symbol1888___unicode, string1847___unicode, arg1028_318, string1840___unicode, BINT(((long)13747)));
exit( -1 );}
if(UCS2_STRINGP(arg1027_317)){
aux_2092 = arg1027_317;
}
 else {
bigloo_type_error_location_103___error(symbol1888___unicode, string1847___unicode, arg1027_317, string1840___unicode, BINT(((long)13747)));
exit( -1 );}
return ucs2_string_append(aux_2092, aux_2098);
}
}
}
}


/* _ucs2-string-append */obj_t _ucs2_string_append_9___unicode(obj_t env_859, obj_t list_860)
{
return ucs2_string_append_106___unicode(list_860);
}


/* list->ucs2-string */obj_t list__ucs2_string_55___unicode(obj_t list_43)
{
{
obj_t symbol1244_776;
symbol1244_776 = symbol1889___unicode;
{
PUSH_TRACE(symbol1244_776);
BUNSPEC;
{
obj_t aux1243_777;
{
long len_321;
len_321 = list_length(list_43);
{
obj_t ucs2_string_194_322;
{
obj_t res1193_574;
{
int k_566;
k_566 = (int)(len_321);
{
ucs2_t arg1006_569;
{
char char_166_572;
char_166_572 = (char)(((unsigned char)' '));
arg1006_569 = (ucs2_t)(char_166_572);
}
{
long aux_2111;
aux_2111 = (long)(k_566);
res1193_574 = make_ucs2_string(aux_2111, arg1006_569);
}
}
}
ucs2_string_194_322 = res1193_574;
}
{
{
long i_323;
obj_t l_324;
i_323 = ((long)0);
l_324 = list_43;
loop_325:
if((i_323==len_321)){
aux1243_777 = ucs2_string_194_322;
}
 else {
{
obj_t arg1032_327;
{
obj_t pair_577;
if(PAIRP(l_324)){
pair_577 = l_324;
}
 else {
bigloo_type_error_location_103___error(symbol1889___unicode, string1839___unicode, l_324, string1840___unicode, BINT(((long)14253)));
exit( -1 );}
arg1032_327 = CAR(pair_577);
}
{
ucs2_t ucs2_580;
{
obj_t aux_2122;
if(UCS2P(arg1032_327)){
aux_2122 = arg1032_327;
}
 else {
bigloo_type_error_location_103___error(symbol1889___unicode, string1841___unicode, arg1032_327, string1840___unicode, BINT(((long)14220)));
exit( -1 );}
ucs2_580 = CUCS2(aux_2122);
}
{
bool_t test_2129;
{
long aux_2130;
aux_2130 = UCS2_STRING_LENGTH(ucs2_string_194_322);
test_2129 = BOUND_CHECK(i_323, aux_2130);
}
if(test_2129){
UCS2_STRING_SET(ucs2_string_194_322, i_323, ucs2_580);
}
 else {
debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(i_323), string1851___unicode, BINT(((long)7610)));
}
}
}
}
{
long arg1033_328;
obj_t arg1034_329;
arg1033_328 = (i_323+((long)1));
{
obj_t pair_589;
if(PAIRP(l_324)){
pair_589 = l_324;
}
 else {
bigloo_type_error_location_103___error(symbol1889___unicode, string1839___unicode, l_324, string1840___unicode, BINT(((long)14280)));
exit( -1 );}
arg1034_329 = CDR(pair_589);
}
{
obj_t l_2145;
long i_2144;
i_2144 = arg1033_328;
l_2145 = arg1034_329;
l_324 = l_2145;
i_323 = i_2144;
goto loop_325;
}
}
}
}
}
}
}
POP_TRACE();
return aux1243_777;
}
}
}
}


/* _list->ucs2-string */obj_t _list__ucs2_string_171___unicode(obj_t env_861, obj_t list_862)
{
return list__ucs2_string_55___unicode(list_862);
}


/* ucs2-string->list */obj_t ucs2_string__list_125___unicode(obj_t ucs2_string_194_44)
{
{
obj_t symbol1246_778;
symbol1246_778 = symbol1890___unicode;
{
PUSH_TRACE(symbol1246_778);
BUNSPEC;
{
obj_t aux1245_779;
{
long len_331;
len_331 = UCS2_STRING_LENGTH(ucs2_string_194_44);
{
long i_332;
obj_t acc_333;
i_332 = ((long)0);
acc_333 = BNIL;
loop_334:
if((i_332==len_331)){
aux1245_779 = reverse__39___r4_pairs_and_lists_6_3(acc_333);
}
 else {
long arg1040_338;
obj_t arg1041_339;
arg1040_338 = (i_332+((long)1));
{
ucs2_t arg1042_340;
{
ucs2_t res1194_603;
{
bool_t test_2154;
{
long aux_2155;
aux_2155 = UCS2_STRING_LENGTH(ucs2_string_194_44);
test_2154 = BOUND_CHECK(i_332, aux_2155);
}
if(test_2154){
res1194_603 = UCS2_STRING_REF(ucs2_string_194_44, i_332);
}
 else {
obj_t aux_2159;
{
obj_t aux1702_1218;
aux1702_1218 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(i_332), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1702_1218)){
aux_2159 = aux1702_1218;
}
 else {
bigloo_type_error_location_103___error(symbol1890___unicode, string1841___unicode, aux1702_1218, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
res1194_603 = CUCS2(aux_2159);
}
}
arg1042_340 = res1194_603;
}
{
obj_t aux_2169;
aux_2169 = BUCS2(arg1042_340);
arg1041_339 = MAKE_PAIR(aux_2169, acc_333);
}
}
{
obj_t acc_2173;
long i_2172;
i_2172 = arg1040_338;
acc_2173 = arg1041_339;
acc_333 = acc_2173;
i_332 = i_2172;
goto loop_334;
}
}
}
}
POP_TRACE();
return aux1245_779;
}
}
}
}


/* _ucs2-string->list1283 */obj_t _ucs2_string__list1283_67___unicode(obj_t env_863, obj_t ucs2_string_194_864)
{
{
obj_t aux_2175;
if(UCS2_STRINGP(ucs2_string_194_864)){
aux_2175 = ucs2_string_194_864;
}
 else {
bigloo_type_error_location_103___error(symbol1891___unicode, string1847___unicode, ucs2_string_194_864, string1840___unicode, BINT(((long)14516)));
exit( -1 );}
return ucs2_string__list_125___unicode(aux_2175);
}
}


/* ucs2-string-copy */obj_t ucs2_string_copy_207___unicode(obj_t ucs2_string_194_45)
{
{
obj_t symbol1248_1467;
symbol1248_1467 = symbol1892___unicode;
{
PUSH_TRACE(symbol1248_1467);
BUNSPEC;
{
obj_t aux1247_1468;
aux1247_1468 = c_ucs2_string_copy(ucs2_string_194_45);
POP_TRACE();
return aux1247_1468;
}
}
}
}


/* _ucs2-string-copy1284 */obj_t _ucs2_string_copy1284_31___unicode(obj_t env_865, obj_t ucs2_string_194_866)
{
{
obj_t ucs2_string_194_1469;
if(UCS2_STRINGP(ucs2_string_194_866)){
ucs2_string_194_1469 = ucs2_string_194_866;
}
 else {
bigloo_type_error_location_103___error(symbol1893___unicode, string1847___unicode, ucs2_string_194_866, string1840___unicode, BINT(((long)14985)));
exit( -1 );}
{
obj_t symbol1248_1470;
symbol1248_1470 = symbol1892___unicode;
{
PUSH_TRACE(symbol1248_1470);
BUNSPEC;
{
obj_t aux1247_1471;
aux1247_1471 = c_ucs2_string_copy(ucs2_string_194_1469);
POP_TRACE();
return aux1247_1471;
}
}
}
}
}


/* ucs2-string-fill! */obj_t ucs2_string_fill__51___unicode(obj_t ucs2_string_194_46, ucs2_t ucs2_47)
{
{
obj_t symbol1250_782;
symbol1250_782 = symbol1894___unicode;
{
PUSH_TRACE(symbol1250_782);
BUNSPEC;
{
obj_t aux1249_783;
{
long len_341;
len_341 = UCS2_STRING_LENGTH(ucs2_string_194_46);
{
long i_342;
i_342 = ((long)0);
loop_343:
if((i_342==len_341)){
aux1249_783 = ucs2_string_194_46;
}
 else {
{
bool_t test_2197;
{
long aux_2198;
aux_2198 = UCS2_STRING_LENGTH(ucs2_string_194_46);
test_2197 = BOUND_CHECK(i_342, aux_2198);
}
if(test_2197){
UCS2_STRING_SET(ucs2_string_194_46, i_342, ucs2_47);
}
 else {
debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(i_342), string1851___unicode, BINT(((long)7610)));
}
}
{
long i_2205;
i_2205 = (i_342+((long)1));
i_342 = i_2205;
goto loop_343;
}
}
}
}
POP_TRACE();
return aux1249_783;
}
}
}
}


/* _ucs2-string-fill!1285 */obj_t _ucs2_string_fill_1285_169___unicode(obj_t env_867, obj_t ucs2_string_194_868, obj_t ucs2_869)
{
{
ucs2_t aux_2214;
obj_t aux_2208;
{
obj_t aux_2215;
if(UCS2P(ucs2_869)){
aux_2215 = ucs2_869;
}
 else {
bigloo_type_error_location_103___error(symbol1895___unicode, string1841___unicode, ucs2_869, string1840___unicode, BINT(((long)15291)));
exit( -1 );}
aux_2214 = CUCS2(aux_2215);
}
if(UCS2_STRINGP(ucs2_string_194_868)){
aux_2208 = ucs2_string_194_868;
}
 else {
bigloo_type_error_location_103___error(symbol1895___unicode, string1847___unicode, ucs2_string_194_868, string1840___unicode, BINT(((long)15291)));
exit( -1 );}
return ucs2_string_fill__51___unicode(aux_2208, aux_2214);
}
}


/* ucs2-string-upcase */obj_t ucs2_string_upcase_71___unicode(obj_t ucs2_string_194_48)
{
{
obj_t symbol1252_784;
symbol1252_784 = symbol1896___unicode;
{
PUSH_TRACE(symbol1252_784);
BUNSPEC;
{
obj_t aux1251_785;
{
long len_346;
len_346 = UCS2_STRING_LENGTH(ucs2_string_194_48);
{
obj_t res_347;
{
obj_t res1195_629;
{
int k_621;
k_621 = (int)(len_346);
{
ucs2_t arg1006_624;
{
char char_166_627;
char_166_627 = (char)(((unsigned char)' '));
arg1006_624 = (ucs2_t)(char_166_627);
}
{
long aux_2228;
aux_2228 = (long)(k_621);
res1195_629 = make_ucs2_string(aux_2228, arg1006_624);
}
}
}
res_347 = res1195_629;
}
{
{
long i_348;
i_348 = ((long)0);
loop_349:
if((i_348==len_346)){
aux1251_785 = res_347;
}
 else {
{
ucs2_t arg1046_351;
{
ucs2_t arg1047_352;
{
ucs2_t res1196_640;
{
bool_t test_2233;
{
long aux_2234;
aux_2234 = UCS2_STRING_LENGTH(ucs2_string_194_48);
test_2233 = BOUND_CHECK(i_348, aux_2234);
}
if(test_2233){
res1196_640 = UCS2_STRING_REF(ucs2_string_194_48, i_348);
}
 else {
obj_t aux_2238;
{
obj_t aux1750_1260;
aux1750_1260 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(i_348), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1750_1260)){
aux_2238 = aux1750_1260;
}
 else {
bigloo_type_error_location_103___error(symbol1896___unicode, string1841___unicode, aux1750_1260, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
res1196_640 = CUCS2(aux_2238);
}
}
arg1047_352 = res1196_640;
}
arg1046_351 = ucs2_toupper(arg1047_352);
}
{
bool_t test_2249;
{
long aux_2250;
aux_2250 = UCS2_STRING_LENGTH(res_347);
test_2249 = BOUND_CHECK(i_348, aux_2250);
}
if(test_2249){
UCS2_STRING_SET(res_347, i_348, arg1046_351);
}
 else {
debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(i_348), string1851___unicode, BINT(((long)7610)));
}
}
}
{
long i_2257;
i_2257 = (i_348+((long)1));
i_348 = i_2257;
goto loop_349;
}
}
}
}
}
}
POP_TRACE();
return aux1251_785;
}
}
}
}


/* _ucs2-string-upcase1286 */obj_t _ucs2_string_upcase1286_140___unicode(obj_t env_870, obj_t ucs2_string_194_871)
{
{
obj_t aux_2260;
if(UCS2_STRINGP(ucs2_string_194_871)){
aux_2260 = ucs2_string_194_871;
}
 else {
bigloo_type_error_location_103___error(symbol1897___unicode, string1847___unicode, ucs2_string_194_871, string1840___unicode, BINT(((long)15745)));
exit( -1 );}
return ucs2_string_upcase_71___unicode(aux_2260);
}
}


/* ucs2-string-downcase */obj_t ucs2_string_downcase_77___unicode(obj_t ucs2_string_194_49)
{
{
obj_t symbol1254_786;
symbol1254_786 = symbol1898___unicode;
{
PUSH_TRACE(symbol1254_786);
BUNSPEC;
{
obj_t aux1253_787;
{
long len_355;
len_355 = UCS2_STRING_LENGTH(ucs2_string_194_49);
{
obj_t res_356;
{
obj_t res1197_662;
{
int k_654;
k_654 = (int)(len_355);
{
ucs2_t arg1006_657;
{
char char_166_660;
char_166_660 = (char)(((unsigned char)' '));
arg1006_657 = (ucs2_t)(char_166_660);
}
{
long aux_2272;
aux_2272 = (long)(k_654);
res1197_662 = make_ucs2_string(aux_2272, arg1006_657);
}
}
}
res_356 = res1197_662;
}
{
{
long i_357;
i_357 = ((long)0);
loop_358:
if((i_357==len_355)){
aux1253_787 = res_356;
}
 else {
{
ucs2_t arg1051_360;
{
ucs2_t arg1053_361;
{
ucs2_t res1198_673;
{
bool_t test_2277;
{
long aux_2278;
aux_2278 = UCS2_STRING_LENGTH(ucs2_string_194_49);
test_2277 = BOUND_CHECK(i_357, aux_2278);
}
if(test_2277){
res1198_673 = UCS2_STRING_REF(ucs2_string_194_49, i_357);
}
 else {
obj_t aux_2282;
{
obj_t aux1780_1284;
aux1780_1284 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(i_357), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1780_1284)){
aux_2282 = aux1780_1284;
}
 else {
bigloo_type_error_location_103___error(symbol1898___unicode, string1841___unicode, aux1780_1284, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
res1198_673 = CUCS2(aux_2282);
}
}
arg1053_361 = res1198_673;
}
arg1051_360 = ucs2_tolower(arg1053_361);
}
{
bool_t test_2293;
{
long aux_2294;
aux_2294 = UCS2_STRING_LENGTH(res_356);
test_2293 = BOUND_CHECK(i_357, aux_2294);
}
if(test_2293){
UCS2_STRING_SET(res_356, i_357, arg1051_360);
}
 else {
debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(i_357), string1851___unicode, BINT(((long)7610)));
}
}
}
{
long i_2301;
i_2301 = (i_357+((long)1));
i_357 = i_2301;
goto loop_358;
}
}
}
}
}
}
POP_TRACE();
return aux1253_787;
}
}
}
}


/* _ucs2-string-downcase1287 */obj_t _ucs2_string_downcase1287_26___unicode(obj_t env_872, obj_t ucs2_string_194_873)
{
{
obj_t aux_2304;
if(UCS2_STRINGP(ucs2_string_194_873)){
aux_2304 = ucs2_string_194_873;
}
 else {
bigloo_type_error_location_103___error(symbol1899___unicode, string1847___unicode, ucs2_string_194_873, string1840___unicode, BINT(((long)16273)));
exit( -1 );}
return ucs2_string_downcase_77___unicode(aux_2304);
}
}


/* ucs2-string-upcase! */obj_t ucs2_string_upcase__158___unicode(obj_t ucs2_string_194_50)
{
{
obj_t symbol1256_788;
symbol1256_788 = symbol1900___unicode;
{
PUSH_TRACE(symbol1256_788);
BUNSPEC;
{
obj_t aux1255_789;
{
long len_364;
len_364 = UCS2_STRING_LENGTH(ucs2_string_194_50);
{
{
long i_366;
i_366 = ((long)0);
loop_367:
if((i_366==len_364)){
aux1255_789 = ucs2_string_194_50;
}
 else {
{
ucs2_t arg1057_369;
{
ucs2_t arg1058_370;
{
ucs2_t res1199_697;
{
bool_t test_2315;
{
long aux_2316;
aux_2316 = UCS2_STRING_LENGTH(ucs2_string_194_50);
test_2315 = BOUND_CHECK(i_366, aux_2316);
}
if(test_2315){
res1199_697 = UCS2_STRING_REF(ucs2_string_194_50, i_366);
}
 else {
obj_t aux_2320;
{
obj_t aux1796_1296;
aux1796_1296 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(i_366), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1796_1296)){
aux_2320 = aux1796_1296;
}
 else {
bigloo_type_error_location_103___error(symbol1900___unicode, string1841___unicode, aux1796_1296, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
res1199_697 = CUCS2(aux_2320);
}
}
arg1058_370 = res1199_697;
}
arg1057_369 = ucs2_toupper(arg1058_370);
}
{
bool_t test_2331;
{
long aux_2332;
aux_2332 = UCS2_STRING_LENGTH(ucs2_string_194_50);
test_2331 = BOUND_CHECK(i_366, aux_2332);
}
if(test_2331){
UCS2_STRING_SET(ucs2_string_194_50, i_366, arg1057_369);
}
 else {
debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(i_366), string1851___unicode, BINT(((long)7610)));
}
}
}
{
long i_2339;
i_2339 = (i_366+((long)1));
i_366 = i_2339;
goto loop_367;
}
}
}
}
}
POP_TRACE();
return aux1255_789;
}
}
}
}


/* _ucs2-string-upcase!1288 */obj_t _ucs2_string_upcase_1288_79___unicode(obj_t env_874, obj_t ucs2_string_194_875)
{
{
obj_t aux_2342;
if(UCS2_STRINGP(ucs2_string_194_875)){
aux_2342 = ucs2_string_194_875;
}
 else {
bigloo_type_error_location_103___error(symbol1901___unicode, string1847___unicode, ucs2_string_194_875, string1840___unicode, BINT(((long)16807)));
exit( -1 );}
return ucs2_string_upcase__158___unicode(aux_2342);
}
}


/* ucs2-string-downcase! */obj_t ucs2_string_downcase__42___unicode(obj_t ucs2_string_194_51)
{
{
obj_t symbol1258_790;
symbol1258_790 = symbol1902___unicode;
{
PUSH_TRACE(symbol1258_790);
BUNSPEC;
{
obj_t aux1257_791;
{
long len_372;
len_372 = UCS2_STRING_LENGTH(ucs2_string_194_51);
{
{
long i_374;
i_374 = ((long)0);
loop_375:
if((i_374==len_372)){
aux1257_791 = ucs2_string_194_51;
}
 else {
{
ucs2_t arg1061_377;
{
ucs2_t arg1062_378;
{
ucs2_t res1200_721;
{
bool_t test_2353;
{
long aux_2354;
aux_2354 = UCS2_STRING_LENGTH(ucs2_string_194_51);
test_2353 = BOUND_CHECK(i_374, aux_2354);
}
if(test_2353){
res1200_721 = UCS2_STRING_REF(ucs2_string_194_51, i_374);
}
 else {
obj_t aux_2358;
{
obj_t aux1810_1308;
aux1810_1308 = debug_error_location_199___error(string1849___unicode, string1850___unicode, BINT(i_374), string1851___unicode, BINT(((long)7610)));
if(UCS2P(aux1810_1308)){
aux_2358 = aux1810_1308;
}
 else {
bigloo_type_error_location_103___error(symbol1902___unicode, string1841___unicode, aux1810_1308, string1851___unicode, BINT(((long)7610)));
exit( -1 );}
}
res1200_721 = CUCS2(aux_2358);
}
}
arg1062_378 = res1200_721;
}
arg1061_377 = ucs2_tolower(arg1062_378);
}
{
bool_t test_2369;
{
long aux_2370;
aux_2370 = UCS2_STRING_LENGTH(ucs2_string_194_51);
test_2369 = BOUND_CHECK(i_374, aux_2370);
}
if(test_2369){
UCS2_STRING_SET(ucs2_string_194_51, i_374, arg1061_377);
}
 else {
debug_error_location_199___error(string1855___unicode, string1850___unicode, BINT(i_374), string1851___unicode, BINT(((long)7610)));
}
}
}
{
long i_2377;
i_2377 = (i_374+((long)1));
i_374 = i_2377;
goto loop_375;
}
}
}
}
}
POP_TRACE();
return aux1257_791;
}
}
}
}


/* _ucs2-string-downcase!1289 */obj_t _ucs2_string_downcase_1289_86___unicode(obj_t env_876, obj_t ucs2_string_194_877)
{
{
obj_t aux_2380;
if(UCS2_STRINGP(ucs2_string_194_877)){
aux_2380 = ucs2_string_194_877;
}
 else {
bigloo_type_error_location_103___error(symbol1903___unicode, string1847___unicode, ucs2_string_194_877, string1840___unicode, BINT(((long)17325)));
exit( -1 );}
return ucs2_string_downcase__42___unicode(aux_2380);
}
}


/* ucs2-string->utf8-string */obj_t ucs2_string__utf8_string_192___unicode(obj_t ucs2_52)
{
{
obj_t symbol1260_1472;
symbol1260_1472 = symbol1904___unicode;
{
PUSH_TRACE(symbol1260_1472);
BUNSPEC;
{
obj_t aux1259_1473;
aux1259_1473 = ucs2_string_to_utf8_string(ucs2_52);
POP_TRACE();
return aux1259_1473;
}
}
}
}


/* _ucs2-string->utf8-string1290 */obj_t _ucs2_string__utf8_string1290_194___unicode(obj_t env_878, obj_t ucs2_879)
{
{
obj_t ucs2_1474;
if(UCS2_STRINGP(ucs2_879)){
ucs2_1474 = ucs2_879;
}
 else {
bigloo_type_error_location_103___error(symbol1905___unicode, string1847___unicode, ucs2_879, string1840___unicode, BINT(((long)17855)));
exit( -1 );}
{
obj_t symbol1260_1475;
symbol1260_1475 = symbol1904___unicode;
{
PUSH_TRACE(symbol1260_1475);
BUNSPEC;
{
obj_t aux1259_1476;
aux1259_1476 = ucs2_string_to_utf8_string(ucs2_1474);
POP_TRACE();
return aux1259_1476;
}
}
}
}
}


/* utf8-string->ucs2-string */obj_t utf8_string__ucs2_string_53___unicode(obj_t utf8_53)
{
{
obj_t symbol1262_1477;
symbol1262_1477 = symbol1906___unicode;
{
PUSH_TRACE(symbol1262_1477);
BUNSPEC;
{
obj_t aux1261_1478;
aux1261_1478 = utf8_string_to_ucs2_string(utf8_53);
POP_TRACE();
return aux1261_1478;
}
}
}
}


/* _utf8-string->ucs2-string1291 */obj_t _utf8_string__ucs2_string1291_1___unicode(obj_t env_880, obj_t utf8_881)
{
{
obj_t utf8_1479;
if(STRINGP(utf8_881)){
utf8_1479 = utf8_881;
}
 else {
bigloo_type_error_location_103___error(symbol1907___unicode, string1908___unicode, utf8_881, string1840___unicode, BINT(((long)18163)));
exit( -1 );}
{
obj_t symbol1262_1480;
symbol1262_1480 = symbol1906___unicode;
{
PUSH_TRACE(symbol1262_1480);
BUNSPEC;
{
obj_t aux1261_1481;
aux1261_1481 = utf8_string_to_ucs2_string(utf8_1479);
POP_TRACE();
return aux1261_1481;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___unicode()
{
{
obj_t symbol1264_796;
symbol1264_796 = symbol1909___unicode;
{
PUSH_TRACE(symbol1264_796);
BUNSPEC;
{
obj_t aux1263_797;
aux1263_797 = module_initialization_70___error(((long)0), "__UNICODE");
POP_TRACE();
return aux1263_797;
}
}
}
}

