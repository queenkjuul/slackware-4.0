/*===========================================================================*/
/*   (Llib/process.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_keyword(char *);
extern obj_t process_exit_status_63___process(obj_t);
extern bool_t process_wait_122___process(obj_t);
extern obj_t process_input_port_25___process(obj_t);
extern obj_t process_output_port_86___process(obj_t);
static obj_t _process__54___process(obj_t, obj_t);
extern obj_t process_continue_186___process(obj_t);
static obj_t _process_input_port_248___process(obj_t, obj_t);
static obj_t _process_list_8___process(obj_t);
static obj_t _process_send_signal_25___process(obj_t, obj_t, obj_t);
extern bool_t process_alive__25___process(obj_t);
extern bool_t process__75___process(obj_t);
static obj_t _process_stop_38___process(obj_t, obj_t);
extern obj_t c_process_continue(obj_t);
static obj_t keyword1186___process = BUNSPEC;
static obj_t keyword1185___process = BUNSPEC;
static obj_t keyword1184___process = BUNSPEC;
static obj_t keyword1183___process = BUNSPEC;
static obj_t keyword1182___process = BUNSPEC;
static obj_t keyword1181___process = BUNSPEC;
static obj_t keyword1178___process = BUNSPEC;
extern obj_t c_process_list();
extern obj_t c_process_stop(obj_t);
extern obj_t c_process_send_signal(obj_t, int);
static obj_t _process_exit_status_230___process(obj_t, obj_t);
static obj_t _process_kill_194___process(obj_t, obj_t);
extern obj_t module_initialization_70___process(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _process_output_port_146___process(obj_t, obj_t);
extern obj_t process_list_172___process();
static obj_t _process_wait_128___process(obj_t, obj_t);
static obj_t _run_process_4___process(obj_t, obj_t, obj_t);
extern obj_t process_stop_113___process(obj_t);
extern obj_t process_send_signal_117___process(obj_t, int);
extern obj_t c_unregister_process(obj_t);
extern obj_t c_process_alivep(obj_t);
static obj_t _process_pid_113___process(obj_t, obj_t);
extern obj_t c_process_kill(obj_t);
extern obj_t run_process_29___process(obj_t, obj_t);
static obj_t _process_alive__232___process(obj_t, obj_t);
extern obj_t unregister_process_179___process(obj_t);
extern obj_t process_error_port_133___process(obj_t);
extern obj_t c_process_wait(obj_t);
static obj_t _process_continue_223___process(obj_t, obj_t);
extern obj_t c_process_xstatus(obj_t);
static obj_t imported_modules_init_94___process();
static obj_t _unregister_process_206___process(obj_t, obj_t);
extern obj_t c_run_process(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _process_error_port_135___process(obj_t, obj_t);
static obj_t require_initialization_114___process = BUNSPEC;
extern int process_pid_210___process(obj_t);
extern obj_t process_kill_93___process(obj_t);
static obj_t cnst_init_137___process();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( process_stop_env_39___process, _process_stop_38___process1188, _process_stop_38___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process__env_163___process, _process__54___process1189, _process__54___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_send_signal_env_135___process, _process_send_signal_25___process1190, _process_send_signal_25___process, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( process_kill_env_209___process, _process_kill_194___process1191, _process_kill_194___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_error_port_env_248___process, _process_error_port_135___process1192, _process_error_port_135___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_list_env_224___process, _process_list_8___process1193, _process_list_8___process, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( process_alive__env_47___process, _process_alive__232___process1194, _process_alive__232___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_output_port_env_138___process, _process_output_port_146___process1195, _process_output_port_146___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( run_process_env_117___process, _run_process_4___process1196, va_generic_entry, _run_process_4___process, -2 );
DEFINE_EXPORT_PROCEDURE( process_pid_env_38___process, _process_pid_113___process1197, _process_pid_113___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unregister_process_env_112___process, _unregister_process_206___process1198, _unregister_process_206___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_continue_env_196___process, _process_continue_223___process1199, _process_continue_223___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_wait_env_238___process, _process_wait_128___process1200, _process_wait_128___process, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( process_input_port_env_47___process, _process_input_port_248___process1201, _process_input_port_248___process, 0L, 1 );
DEFINE_STRING( string1179___process, string1179___process1202, "run-process", 11 );
DEFINE_STRING( string1180___process, string1180___process1203, "Illegal argument", 16 );
DEFINE_EXPORT_PROCEDURE( process_exit_status_env_111___process, _process_exit_status_230___process1204, _process_exit_status_230___process, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___process(long checksum_587, char * from_588)
{
if(CBOOL(require_initialization_114___process)){
require_initialization_114___process = BBOOL(((bool_t)0));
cnst_init_137___process();
imported_modules_init_94___process();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___process()
{
keyword1178___process = string_to_keyword("WAIT:");
keyword1181___process = string_to_keyword("FORK:");
keyword1182___process = string_to_keyword("INPUT:");
keyword1183___process = string_to_keyword("PIPE:");
keyword1184___process = string_to_keyword("OUTPUT:");
keyword1185___process = string_to_keyword("ERROR:");
return (keyword1186___process = string_to_keyword("HOST:"),
BUNSPEC);
}


/* process? */bool_t process__75___process(obj_t obj_1)
{
return PROCESSP(obj_1);
}


/* _process? */obj_t _process__54___process(obj_t env_542, obj_t obj_543)
{
{
bool_t aux_602;
{
obj_t obj_573;
obj_573 = obj_543;
aux_602 = PROCESSP(obj_573);
}
return BBOOL(aux_602);
}
}


/* process-pid */int process_pid_210___process(obj_t proc_2)
{
return PROCESS_PID(proc_2);
}


/* _process-pid */obj_t _process_pid_113___process(obj_t env_544, obj_t proc_545)
{
{
int aux_606;
{
obj_t proc_574;
proc_574 = proc_545;
aux_606 = PROCESS_PID(proc_574);
}
return BINT(aux_606);
}
}


/* process-output-port */obj_t process_output_port_86___process(obj_t proc_3)
{
return PROCESS_OUTPUT_PORT(proc_3);
}


/* _process-output-port */obj_t _process_output_port_146___process(obj_t env_546, obj_t proc_547)
{
{
obj_t proc_575;
proc_575 = proc_547;
return PROCESS_OUTPUT_PORT(proc_575);
}
}


/* process-input-port */obj_t process_input_port_25___process(obj_t proc_4)
{
return PROCESS_INPUT_PORT(proc_4);
}


/* _process-input-port */obj_t _process_input_port_248___process(obj_t env_548, obj_t proc_549)
{
{
obj_t proc_576;
proc_576 = proc_549;
return PROCESS_INPUT_PORT(proc_576);
}
}


/* process-error-port */obj_t process_error_port_133___process(obj_t proc_5)
{
return PROCESS_ERROR_PORT(proc_5);
}


/* _process-error-port */obj_t _process_error_port_135___process(obj_t env_550, obj_t proc_551)
{
{
obj_t proc_577;
proc_577 = proc_551;
return PROCESS_ERROR_PORT(proc_577);
}
}


/* process-alive? */bool_t process_alive__25___process(obj_t proc_6)
{
{
obj_t aux_615;
aux_615 = c_process_alivep(proc_6);
return CBOOL(aux_615);
}
}


/* _process-alive? */obj_t _process_alive__232___process(obj_t env_552, obj_t proc_553)
{
{
bool_t aux_618;
{
obj_t proc_578;
proc_578 = proc_553;
{
obj_t aux_619;
aux_619 = c_process_alivep(proc_578);
aux_618 = CBOOL(aux_619);
}
}
return BBOOL(aux_618);
}
}


/* process-wait */bool_t process_wait_122___process(obj_t proc_7)
{
{
obj_t aux_623;
aux_623 = c_process_wait(proc_7);
return CBOOL(aux_623);
}
}


/* _process-wait */obj_t _process_wait_128___process(obj_t env_554, obj_t proc_555)
{
{
bool_t aux_626;
{
obj_t proc_579;
proc_579 = proc_555;
{
obj_t aux_627;
aux_627 = c_process_wait(proc_579);
aux_626 = CBOOL(aux_627);
}
}
return BBOOL(aux_626);
}
}


/* process-exit-status */obj_t process_exit_status_63___process(obj_t proc_8)
{
return c_process_xstatus(proc_8);
}


/* _process-exit-status */obj_t _process_exit_status_230___process(obj_t env_556, obj_t proc_557)
{
{
obj_t proc_580;
proc_580 = proc_557;
return c_process_xstatus(proc_580);
}
}


/* process-send-signal */obj_t process_send_signal_117___process(obj_t proc_9, int signal_10)
{
return c_process_send_signal(proc_9, signal_10);
}


/* _process-send-signal */obj_t _process_send_signal_25___process(obj_t env_558, obj_t proc_559, obj_t signal_560)
{
{
obj_t proc_581;
int signal_582;
proc_581 = proc_559;
signal_582 = CINT(signal_560);
return c_process_send_signal(proc_581, signal_582);
}
}


/* process-kill */obj_t process_kill_93___process(obj_t proc_11)
{
return c_process_kill(proc_11);
}


/* _process-kill */obj_t _process_kill_194___process(obj_t env_561, obj_t proc_562)
{
{
obj_t proc_583;
proc_583 = proc_562;
return c_process_kill(proc_583);
}
}


/* process-stop */obj_t process_stop_113___process(obj_t proc_12)
{
return c_process_stop(proc_12);
}


/* _process-stop */obj_t _process_stop_38___process(obj_t env_563, obj_t proc_564)
{
{
obj_t proc_584;
proc_584 = proc_564;
return c_process_stop(proc_584);
}
}


/* process-continue */obj_t process_continue_186___process(obj_t proc_13)
{
return c_process_continue(proc_13);
}


/* _process-continue */obj_t _process_continue_223___process(obj_t env_565, obj_t proc_566)
{
{
obj_t proc_585;
proc_585 = proc_566;
return c_process_continue(proc_585);
}
}


/* process-list */obj_t process_list_172___process()
{
return c_process_list();
}


/* _process-list */obj_t _process_list_8___process(obj_t env_567)
{
return c_process_list();
}


/* run-process */obj_t run_process_29___process(obj_t command_14, obj_t rest_15)
{
{
obj_t fork_279;
obj_t wait_280;
obj_t input_281;
obj_t output_282;
obj_t error_283;
obj_t host_284;
obj_t args_285;
fork_279 = BTRUE;
wait_280 = BFALSE;
input_281 = BUNSPEC;
output_282 = BUNSPEC;
error_283 = BUNSPEC;
host_284 = BUNSPEC;
args_285 = BNIL;
{
obj_t rest_287;
rest_287 = rest_15;
loop_288:
if(NULLP(rest_287)){
{
obj_t arg1007_290;
arg1007_290 = reverse__39___r4_pairs_and_lists_6_3(args_285);
return c_run_process(host_284, fork_279, wait_280, input_281, output_282, error_283, command_14, arg1007_290);
}
}
 else {
bool_t test_648;
{
bool_t test_649;
{
obj_t aux_650;
aux_650 = CAR(rest_287);
test_649 = KEYWORDP(aux_650);
}
if(test_649){
obj_t aux_653;
aux_653 = CDR(rest_287);
test_648 = PAIRP(aux_653);
}
 else {
test_648 = ((bool_t)0);
}
}
if(test_648){
{
obj_t val_292;
{
obj_t aux_656;
aux_656 = CDR(rest_287);
val_292 = CAR(aux_656);
}
{
obj_t case_value_58_293;
case_value_58_293 = CAR(rest_287);
if((case_value_58_293==keyword1178___process)){
if(BOOLEANP(val_292)){
wait_280 = val_292;
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
 else {
if((case_value_58_293==keyword1181___process)){
if(BOOLEANP(val_292)){
fork_279 = val_292;
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
 else {
if((case_value_58_293==keyword1182___process)){
bool_t test_672;
if(STRINGP(val_292)){
test_672 = ((bool_t)1);
}
 else {
test_672 = (val_292==keyword1183___process);
}
if(test_672){
input_281 = val_292;
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
 else {
if((case_value_58_293==keyword1184___process)){
bool_t test_679;
if(STRINGP(val_292)){
test_679 = ((bool_t)1);
}
 else {
test_679 = (val_292==keyword1183___process);
}
if(test_679){
output_282 = val_292;
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
 else {
if((case_value_58_293==keyword1185___process)){
bool_t test_686;
if(STRINGP(val_292)){
test_686 = ((bool_t)1);
}
 else {
test_686 = (val_292==keyword1183___process);
}
if(test_686){
error_283 = val_292;
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
 else {
if((case_value_58_293==keyword1186___process)){
if(STRINGP(val_292)){
host_284 = val_292;
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
}
}
}
}
}
{
obj_t rest_697;
{
obj_t aux_698;
aux_698 = CDR(rest_287);
rest_697 = CDR(aux_698);
}
rest_287 = rest_697;
goto loop_288;
}
}
}
 else {
bool_t test_701;
{
obj_t aux_702;
aux_702 = CAR(rest_287);
test_701 = STRINGP(aux_702);
}
if(test_701){
{
obj_t obj2_530;
obj2_530 = args_285;
{
obj_t aux_705;
aux_705 = CAR(rest_287);
args_285 = MAKE_PAIR(aux_705, obj2_530);
}
}
{
obj_t rest_708;
rest_708 = CDR(rest_287);
rest_287 = rest_708;
goto loop_288;
}
}
 else {
FAILURE(string1179___process,string1180___process,rest_287);}
}
}
}
}
}


/* _run-process */obj_t _run_process_4___process(obj_t env_568, obj_t command_569, obj_t rest_570)
{
return run_process_29___process(command_569, rest_570);
}


/* unregister-process */obj_t unregister_process_179___process(obj_t proc_16)
{
return c_unregister_process(proc_16);
}


/* _unregister-process */obj_t _unregister_process_206___process(obj_t env_571, obj_t proc_572)
{
{
obj_t proc_586;
proc_586 = proc_572;
return c_unregister_process(proc_586);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___process()
{
return module_initialization_70___error(((long)0), "__PROCESS");
}

