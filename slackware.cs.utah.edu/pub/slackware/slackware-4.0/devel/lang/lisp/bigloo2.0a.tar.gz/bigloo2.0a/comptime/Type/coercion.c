/*===========================================================================*/
/*   (Type/coercion.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_type_coercion();
extern obj_t add_coercion__50_type_coercion(type_t, type_t, obj_t, obj_t);
extern obj_t warning___error(obj_t);
static obj_t _add_coercion_1271_76_type_coercion(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_type_coercion(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _coercer_exists_1272_223_type_coercion(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_type_coercion();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_type_coercion();
static obj_t _find_coercer1270_178_type_coercion(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_type_coercion();
extern obj_t open_input_string(obj_t);
extern obj_t shape_tools_shape(obj_t);
extern type_t get_aliased_type_1_type_type(type_t);
extern obj_t read___reader(obj_t);
extern bool_t coercer_exists__27_type_coercion(type_t, type_t);
extern obj_t _lib_mode__85_engine_param;
extern obj_t find_coercer_15_type_coercion(type_t, type_t);
static obj_t require_initialization_114_type_coercion = BUNSPEC;
static obj_t cnst_init_137_type_coercion();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(add_coercion__env_210_type_coercion, _add_coercion_1271_76_type_coercion1283, _add_coercion_1271_76_type_coercion, 0L, 4);
DEFINE_EXPORT_PROCEDURE(coercer_exists__env_64_type_coercion, _coercer_exists_1272_223_type_coercion1284, _coercer_exists_1272_223_type_coercion, 0L, 2);
DEFINE_STRING(string1276_type_coercion, string1276_type_coercion1285, "COERCER (()) ", 13);
DEFINE_STRING(string1275_type_coercion, string1275_type_coercion1286, "Can't find coercion", 19);
DEFINE_STRING(string1274_type_coercion, string1274_type_coercion1287, "add-coercion!", 13);
DEFINE_STRING(string1273_type_coercion, string1273_type_coercion1288, "Type coercion redefinition -- ", 30);
DEFINE_EXPORT_PROCEDURE(find_coercer_env_27_type_coercion, _find_coercer1270_178_type_coercion1289, _find_coercer1270_178_type_coercion, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_type_coercion(long checksum_414, char *from_415)
{
   if (CBOOL(require_initialization_114_type_coercion))
     {
	require_initialization_114_type_coercion = BBOOL(((bool_t) 0));
	library_modules_init_112_type_coercion();
	cnst_init_137_type_coercion();
	imported_modules_init_94_type_coercion();
	method_init_76_type_coercion();
	toplevel_init_63_type_coercion();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_coercion()
{
   module_initialization_70___error(((long) 0), "TYPE_COERCION");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TYPE_COERCION");
   module_initialization_70___reader(((long) 0), "TYPE_COERCION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_type_coercion()
{
   {
      obj_t cnst_port_138_406;
      cnst_port_138_406 = open_input_string(string1276_type_coercion);
      {
	 long i_407;
	 i_407 = ((long) 1);
       loop_408:
	 {
	    bool_t test1277_409;
	    test1277_409 = (i_407 == ((long) -1));
	    if (test1277_409)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1278_410;
		    {
		       obj_t list1279_411;
		       {
			  obj_t arg1281_412;
			  arg1281_412 = BNIL;
			  list1279_411 = MAKE_PAIR(cnst_port_138_406, arg1281_412);
		       }
		       arg1278_410 = read___reader(list1279_411);
		    }
		    CNST_TABLE_SET(i_407, arg1278_410);
		 }
		 {
		    int aux_413;
		    {
		       long aux_433;
		       aux_433 = (i_407 - ((long) 1));
		       aux_413 = (int) (aux_433);
		    }
		    {
		       long i_436;
		       i_436 = (long) (aux_413);
		       i_407 = i_436;
		       goto loop_408;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_type_coercion()
{
   return BUNSPEC;
}


/* find-coercer */ obj_t 
find_coercer_15_type_coercion(type_t from_19, type_t to_20)
{
   {
      type_t from_93;
      type_t to_94;
      from_93 = get_aliased_type_1_type_type(from_19);
      to_94 = get_aliased_type_1_type_type(to_20);
      {
	 obj_t coercer_95;
	 coercer_95 = (((type_t) CREF(from_93))->coerce_to_204);
       loop_96:
	 if (NULLP(coercer_95))
	   {
	      return BFALSE;
	   }
	 else
	   {
	      bool_t test_442;
	      {
		 obj_t aux_447;
		 obj_t aux_443;
		 aux_447 = (obj_t) (to_94);
		 {
		    obj_t aux_444;
		    aux_444 = CAR(coercer_95);
		    aux_443 = STRUCT_REF(aux_444, ((long) 1));
		 }
		 test_442 = (aux_443 == aux_447);
	      }
	      if (test_442)
		{
		   return CAR(coercer_95);
		}
	      else
		{
		   {
		      obj_t coercer_451;
		      coercer_451 = CDR(coercer_95);
		      coercer_95 = coercer_451;
		      goto loop_96;
		   }
		}
	   }
      }
   }
}


/* _find-coercer1270 */ obj_t 
_find_coercer1270_178_type_coercion(obj_t env_394, obj_t from_395, obj_t to_396)
{
   return find_coercer_15_type_coercion((type_t) (from_395), (type_t) (to_396));
}


/* add-coercion! */ obj_t 
add_coercion__50_type_coercion(type_t from_21, type_t to_22, obj_t check_23, obj_t coerce_24)
{
   {
      bool_t test1162_103;
      {
	 obj_t obj_280;
	 obj_280 = check_23;
	 test1162_103 = NULLP(obj_280);
      }
      if (test1162_103)
	{
	   check_23 = CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      bool_t test1163_104;
      {
	 obj_t obj_281;
	 obj_281 = coerce_24;
	 test1163_104 = NULLP(obj_281);
      }
      if (test1163_104)
	{
	   coerce_24 = CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      type_t from_105;
      type_t to_106;
      from_105 = get_aliased_type_1_type_type(from_21);
      to_106 = get_aliased_type_1_type_type(to_22);
      {
	 bool_t test1164_107;
	 {
	    obj_t arg1240_166;
	    arg1240_166 = find_coercer_15_type_coercion(from_105, to_106);
	    if (STRUCTP(arg1240_166))
	      {
		 obj_t aux_470;
		 obj_t aux_468;
		 aux_470 = CNST_TABLE_REF(((long) 1));
		 aux_468 = STRUCT_KEY(arg1240_166);
		 test1164_107 = (aux_468 == aux_470);
	      }
	    else
	      {
		 test1164_107 = ((bool_t) 0);
	      }
	 }
	 if (test1164_107)
	   {
	      if (CBOOL(_lib_mode__85_engine_param))
		{
		   return BUNSPEC;
		}
	      else
		{
		   obj_t arg1187_110;
		   {
		      obj_t arg1193_115;
		      {
			 obj_t list1194_116;
			 {
			    obj_t arg1195_117;
			    {
			       obj_t arg1196_118;
			       {
				  obj_t arg1197_119;
				  arg1197_119 = MAKE_PAIR(coerce_24, BNIL);
				  arg1196_118 = MAKE_PAIR(check_23, arg1197_119);
			       }
			       {
				  obj_t aux_478;
				  aux_478 = (obj_t) (to_106);
				  arg1195_117 = MAKE_PAIR(aux_478, arg1196_118);
			       }
			    }
			    {
			       obj_t aux_481;
			       aux_481 = (obj_t) (from_105);
			       list1194_116 = MAKE_PAIR(aux_481, arg1195_117);
			    }
			 }
			 arg1193_115 = list1194_116;
		      }
		      arg1187_110 = shape_tools_shape(arg1193_115);
		   }
		   {
		      obj_t list1188_111;
		      {
			 obj_t arg1190_112;
			 {
			    obj_t arg1191_113;
			    arg1191_113 = MAKE_PAIR(arg1187_110, BNIL);
			    arg1190_112 = MAKE_PAIR(string1273_type_coercion, arg1191_113);
			 }
			 list1188_111 = MAKE_PAIR(string1274_type_coercion, arg1190_112);
		      }
		      return warning___error(list1188_111);
		   }
		}
	   }
	 else
	   {
	      {
		 obj_t new_121;
		 {
		    obj_t check_op_210_293;
		    obj_t coerce_op_79_294;
		    check_op_210_293 = check_23;
		    coerce_op_79_294 = coerce_24;
		    {
		       obj_t new_295;
		       {
			  obj_t aux_489;
			  aux_489 = CNST_TABLE_REF(((long) 1));
			  new_295 = create_struct(aux_489, ((long) 4));
		       }
		       STRUCT_SET(new_295, ((long) 3), coerce_op_79_294);
		       STRUCT_SET(new_295, ((long) 2), check_op_210_293);
		       {
			  obj_t aux_494;
			  aux_494 = (obj_t) (to_106);
			  STRUCT_SET(new_295, ((long) 1), aux_494);
		       }
		       {
			  obj_t aux_497;
			  aux_497 = (obj_t) (from_105);
			  STRUCT_SET(new_295, ((long) 0), aux_497);
		       }
		       new_121 = new_295;
		    }
		 }
		 {
		    obj_t arg1200_122;
		    {
		       obj_t aux_500;
		       aux_500 = (((type_t) CREF(from_105))->coerce_to_204);
		       arg1200_122 = MAKE_PAIR(new_121, aux_500);
		    }
		    ((((type_t) CREF(from_105))->coerce_to_204) = ((obj_t) arg1200_122), BUNSPEC);
		 }
	      }
	      {
		 obj_t l1028_124;
		 l1028_124 = (((type_t) CREF(to_106))->parents);
	       lname1029_125:
		 if (PAIRP(l1028_124))
		   {
		      {
			 obj_t parent_128;
			 parent_128 = CAR(l1028_124);
			 {
			    bool_t test1204_129;
			    {
			       bool_t test_507;
			       {
				  obj_t aux_508;
				  aux_508 = (obj_t) (from_105);
				  test_507 = (aux_508 == parent_128);
			       }
			       if (test_507)
				 {
				    test1204_129 = ((bool_t) 0);
				 }
			       else
				 {
				    bool_t test_511;
				    {
				       obj_t aux_512;
				       aux_512 = (obj_t) (to_106);
				       test_511 = (aux_512 == parent_128);
				    }
				    if (test_511)
				      {
					 test1204_129 = ((bool_t) 0);
				      }
				    else
				      {
					 bool_t test1215_142;
					 {
					    obj_t arg1216_143;
					    arg1216_143 = find_coercer_15_type_coercion(from_105, (type_t) (parent_128));
					    if (STRUCTP(arg1216_143))
					      {
						 obj_t aux_521;
						 obj_t aux_519;
						 aux_521 = CNST_TABLE_REF(((long) 1));
						 aux_519 = STRUCT_KEY(arg1216_143);
						 test1215_142 = (aux_519 == aux_521);
					      }
					    else
					      {
						 test1215_142 = ((bool_t) 0);
					      }
					 }
					 if (test1215_142)
					   {
					      test1204_129 = ((bool_t) 0);
					   }
					 else
					   {
					      test1204_129 = ((bool_t) 1);
					   }
				      }
				 }
			    }
			    if (test1204_129)
			      {
				 obj_t coercer_p_191_130;
				 coercer_p_191_130 = find_coercer_15_type_coercion(to_106, (type_t) (parent_128));
				 {
				    bool_t test_528;
				    if (STRUCTP(coercer_p_191_130))
				      {
					 obj_t aux_533;
					 obj_t aux_531;
					 aux_533 = CNST_TABLE_REF(((long) 1));
					 aux_531 = STRUCT_KEY(coercer_p_191_130);
					 test_528 = (aux_531 == aux_533);
				      }
				    else
				      {
					 test_528 = ((bool_t) 0);
				      }
				    if (test_528)
				      {
					 obj_t arg1206_134;
					 obj_t arg1207_135;
					 arg1206_134 = append_2_18___r4_pairs_and_lists_6_3(check_23, STRUCT_REF(coercer_p_191_130, ((long) 2)));
					 arg1207_135 = append_2_18___r4_pairs_and_lists_6_3(coerce_24, STRUCT_REF(coercer_p_191_130, ((long) 3)));
					 add_coercion__50_type_coercion(from_105, (type_t) (parent_128), arg1206_134, arg1207_135);
				      }
				    else
				      {
					 obj_t arg1210_137;
					 obj_t arg1211_138;
					 arg1210_137 = shape_tools_shape((obj_t) (to_106));
					 arg1211_138 = shape_tools_shape(parent_128);
					 user_error_151_tools_error(string1275_type_coercion, arg1210_137, arg1211_138, BNIL);
				      }
				 }
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
		      }
		      {
			 obj_t l1028_546;
			 l1028_546 = CDR(l1028_124);
			 l1028_124 = l1028_546;
			 goto lname1029_125;
		      }
		   }
		 else
		   {
		      ((bool_t) 1);
		   }
	      }
	      {
		 obj_t l1030_145;
		 {
		    bool_t aux_549;
		    l1030_145 = (((type_t) CREF(from_105))->parents);
		  lname1031_146:
		    if (PAIRP(l1030_145))
		      {
			 {
			    obj_t parent_149;
			    parent_149 = CAR(l1030_145);
			    {
			       bool_t test1222_150;
			       {
				  bool_t test_553;
				  {
				     obj_t aux_554;
				     aux_554 = (obj_t) (from_105);
				     test_553 = (aux_554 == parent_149);
				  }
				  if (test_553)
				    {
				       test1222_150 = ((bool_t) 0);
				    }
				  else
				    {
				       bool_t test_557;
				       {
					  obj_t aux_558;
					  aux_558 = (obj_t) (to_106);
					  test_557 = (aux_558 == parent_149);
				       }
				       if (test_557)
					 {
					    test1222_150 = ((bool_t) 0);
					 }
				       else
					 {
					    bool_t test1235_163;
					    {
					       obj_t arg1236_164;
					       arg1236_164 = find_coercer_15_type_coercion((type_t) (parent_149), to_106);
					       if (STRUCTP(arg1236_164))
						 {
						    obj_t aux_567;
						    obj_t aux_565;
						    aux_567 = CNST_TABLE_REF(((long) 1));
						    aux_565 = STRUCT_KEY(arg1236_164);
						    test1235_163 = (aux_565 == aux_567);
						 }
					       else
						 {
						    test1235_163 = ((bool_t) 0);
						 }
					    }
					    if (test1235_163)
					      {
						 test1222_150 = ((bool_t) 0);
					      }
					    else
					      {
						 test1222_150 = ((bool_t) 1);
					      }
					 }
				    }
			       }
			       if (test1222_150)
				 {
				    obj_t coercer_p_191_151;
				    coercer_p_191_151 = find_coercer_15_type_coercion((type_t) (parent_149), from_105);
				    {
				       bool_t test_574;
				       if (STRUCTP(coercer_p_191_151))
					 {
					    obj_t aux_579;
					    obj_t aux_577;
					    aux_579 = CNST_TABLE_REF(((long) 1));
					    aux_577 = STRUCT_KEY(coercer_p_191_151);
					    test_574 = (aux_577 == aux_579);
					 }
				       else
					 {
					    test_574 = ((bool_t) 0);
					 }
				       if (test_574)
					 {
					    obj_t arg1224_155;
					    obj_t arg1225_156;
					    arg1224_155 = append_2_18___r4_pairs_and_lists_6_3(STRUCT_REF(coercer_p_191_151, ((long) 2)), check_23);
					    arg1225_156 = append_2_18___r4_pairs_and_lists_6_3(STRUCT_REF(coercer_p_191_151, ((long) 3)), coerce_24);
					    add_coercion__50_type_coercion((type_t) (parent_149), to_106, arg1224_155, arg1225_156);
					 }
				       else
					 {
					    obj_t arg1228_158;
					    obj_t arg1231_159;
					    arg1228_158 = shape_tools_shape(parent_149);
					    arg1231_159 = shape_tools_shape((obj_t) (from_105));
					    user_error_151_tools_error(string1275_type_coercion, arg1228_158, arg1231_159, BNIL);
					 }
				    }
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			 }
			 {
			    obj_t l1030_592;
			    l1030_592 = CDR(l1030_145);
			    l1030_145 = l1030_592;
			    goto lname1031_146;
			 }
		      }
		    else
		      {
			 aux_549 = ((bool_t) 1);
		      }
		    return BBOOL(aux_549);
		 }
	      }
	   }
      }
   }
}


/* _add-coercion!1271 */ obj_t 
_add_coercion_1271_76_type_coercion(obj_t env_397, obj_t from_398, obj_t to_399, obj_t check_400, obj_t coerce_401)
{
   return add_coercion__50_type_coercion((type_t) (from_398), (type_t) (to_399), check_400, coerce_401);
}


/* coercer-exists? */ bool_t 
coercer_exists__27_type_coercion(type_t to_27, type_t from_28)
{
   {
      type_t to_200;
      type_t from_201;
      to_200 = get_aliased_type_1_type_type(to_27);
      from_201 = get_aliased_type_1_type_type(from_28);
      {
	 bool_t test_601;
	 {
	    bool_t test_602;
	    {
	       obj_t aux_605;
	       obj_t aux_603;
	       aux_605 = (obj_t) (to_200);
	       aux_603 = (obj_t) (from_201);
	       test_602 = (aux_603 == aux_605);
	    }
	    if (test_602)
	      {
		 test_601 = ((bool_t) 1);
	      }
	    else
	      {
		 test_601 = (((type_t) CREF(from_201))->magic__53);
	      }
	 }
	 if (test_601)
	   {
	      return ((bool_t) 1);
	   }
	 else
	   {
	      obj_t arg1265_203;
	      arg1265_203 = find_coercer_15_type_coercion(from_201, to_200);
	      if (STRUCTP(arg1265_203))
		{
		   obj_t aux_614;
		   obj_t aux_612;
		   aux_614 = CNST_TABLE_REF(((long) 1));
		   aux_612 = STRUCT_KEY(arg1265_203);
		   return (aux_612 == aux_614);
		}
	      else
		{
		   return ((bool_t) 0);
		}
	   }
      }
   }
}


/* _coercer-exists?1272 */ obj_t 
_coercer_exists_1272_223_type_coercion(obj_t env_402, obj_t to_403, obj_t from_404)
{
   {
      bool_t aux_617;
      aux_617 = coercer_exists__27_type_coercion((type_t) (to_403), (type_t) (from_404));
      return BBOOL(aux_617);
   }
}


/* method-init */ obj_t 
method_init_76_type_coercion()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_coercion()
{
   module_initialization_70_tools_error(((long) 0), "TYPE_COERCION");
   module_initialization_70_tools_shape(((long) 0), "TYPE_COERCION");
   module_initialization_70_type_type(((long) 0), "TYPE_COERCION");
   return module_initialization_70_engine_param(((long) 0), "TYPE_COERCION");
}
