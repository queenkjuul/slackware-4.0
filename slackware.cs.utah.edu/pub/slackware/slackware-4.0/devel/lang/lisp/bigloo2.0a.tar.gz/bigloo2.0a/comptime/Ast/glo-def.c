/*===========================================================================*/
/*   (Ast/glo-def.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
extern global_t declare_global_scnst__70_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t);
extern global_t declare_global_sfun__255_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_ast_glo_def_117();
static obj_t _def_global_scnst__222_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t type_type_type;
static obj_t _check_method_definition_40_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t id_of_id_112_ast_ident(obj_t);
extern obj_t leave_function_170_tools_error();
extern global_t def_global_scnst__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern bool_t type_subclass__90_object_class(type_t, type_t);
static bool_t compatible_type__151_ast_glo_def_117(bool_t, type_t, type_t);
extern type_t type_of_id_183_ast_ident(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _def_global_sfun__109_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t dsssl_formals_encoding_15_tools_dsssl(obj_t);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_glo_decl_237(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern long list_length(obj_t);
extern obj_t svar_ast_var;
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t remove_var_from__148_ast_remove(obj_t, variable_t);
static global_t check_sfun_definition_109_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_ast_glo_def_117();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static global_t mismatch_error_84_ast_glo_def_117(global_t, obj_t, obj_t);
static obj_t library_modules_init_112_ast_glo_def_117();
static global_t check_svar_definition_92_ast_glo_def_117(obj_t, obj_t, obj_t);
extern global_t declare_global_svar__200_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t);
extern bool_t check_method_definition_71_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern int arity_tools_args(obj_t);
extern obj_t class_object_class;
extern obj_t parse_id_241_ast_ident(obj_t);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t local_ast_var;
extern obj_t shape_tools_shape(obj_t);
static obj_t _def_global_svar__252_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern global_t def_global_svar__184_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t find_location_120_tools_location(obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_glo_def_117 = BUNSPEC;
static obj_t cnst_init_137_ast_glo_def_117();
static obj_t __cnst[5];

DEFINE_EXPORT_PROCEDURE(def_global_svar__env_161_ast_glo_def_117, _def_global_svar__252_ast_glo_def_1171793, _def_global_svar__252_ast_glo_def_117, 0L, 4);
DEFINE_EXPORT_PROCEDURE(def_global_scnst__env_209_ast_glo_def_117, _def_global_scnst__222_ast_glo_def_1171794, _def_global_scnst__222_ast_glo_def_117, 0L, 4);
DEFINE_EXPORT_PROCEDURE(def_global_sfun__env_209_ast_glo_def_117, _def_global_sfun__109_ast_glo_def_1171795, _def_global_sfun__109_ast_glo_def_117, 0L, 8);
DEFINE_EXPORT_PROCEDURE(check_method_definition_env_136_ast_glo_def_117, _check_method_definition_40_ast_glo_def_1171796, _check_method_definition_40_ast_glo_def_117, 0L, 4);
DEFINE_STRING(string1787_ast_glo_def_117, string1787_ast_glo_def_1171797, "BIGLOO NOW SGFUN STATIC EXPORT ", 31);
DEFINE_STRING(string1786_ast_glo_def_117, string1786_ast_glo_def_1171798, "Prototype and definition don't match", 36);
DEFINE_STRING(string1785_ast_glo_def_117, string1785_ast_glo_def_1171799, " ", 1);
DEFINE_STRING(string1784_ast_glo_def_117, string1784_ast_glo_def_1171800, "(incompatible variable type)", 28);
DEFINE_STRING(string1783_ast_glo_def_117, string1783_ast_glo_def_1171801, "Illegal type for global variable", 32);
DEFINE_STRING(string1782_ast_glo_def_117, string1782_ast_glo_def_1171802, "(arity differs)", 15);
DEFINE_STRING(string1781_ast_glo_def_117, string1781_ast_glo_def_1171803, "(incompatible function type result)", 35);
DEFINE_STRING(string1779_ast_glo_def_117, string1779_ast_glo_def_1171804, "(incompatible formal type)", 26);
DEFINE_STRING(string1780_ast_glo_def_117, string1780_ast_glo_def_1171805, "(incompatible Dsssl prototype)", 30);
DEFINE_STRING(string1778_ast_glo_def_117, string1778_ast_glo_def_1171806, "unexpected generic arg", 22);
DEFINE_STRING(string1777_ast_glo_def_117, string1777_ast_glo_def_1171807, "check-method-definition", 23);


/* module-initialization */ obj_t 
module_initialization_70_ast_glo_def_117(long checksum_1591, char *from_1592)
{
   if (CBOOL(require_initialization_114_ast_glo_def_117))
     {
	require_initialization_114_ast_glo_def_117 = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_glo_def_117();
	cnst_init_137_ast_glo_def_117();
	imported_modules_init_94_ast_glo_def_117();
	method_init_76_ast_glo_def_117();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_glo_def_117()
{
   module_initialization_70___object(((long) 0), "AST_GLO-DEF");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_GLO-DEF");
   module_initialization_70___r4_strings_6_7(((long) 0), "AST_GLO-DEF");
   module_initialization_70___reader(((long) 0), "AST_GLO-DEF");
   module_initialization_70___r4_equivalence_6_2(((long) 0), "AST_GLO-DEF");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_glo_def_117()
{
   {
      obj_t cnst_port_138_1583;
      cnst_port_138_1583 = open_input_string(string1787_ast_glo_def_117);
      {
	 long i_1584;
	 i_1584 = ((long) 4);
       loop_1585:
	 {
	    bool_t test1788_1586;
	    test1788_1586 = (i_1584 == ((long) -1));
	    if (test1788_1586)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1789_1587;
		    {
		       obj_t list1790_1588;
		       {
			  obj_t arg1791_1589;
			  arg1791_1589 = BNIL;
			  list1790_1588 = MAKE_PAIR(cnst_port_138_1583, arg1791_1589);
		       }
		       arg1789_1587 = read___reader(list1790_1588);
		    }
		    CNST_TABLE_SET(i_1584, arg1789_1587);
		 }
		 {
		    int aux_1590;
		    {
		       long aux_1611;
		       aux_1611 = (i_1584 - ((long) 1));
		       aux_1590 = (int) (aux_1611);
		    }
		    {
		       long i_1614;
		       i_1614 = (long) (aux_1590);
		       i_1584 = i_1614;
		       goto loop_1585;
		    }
		 }
	      }
	 }
      }
   }
}


/* def-global-sfun! */ global_t 
def_global_sfun__93_ast_glo_def_117(obj_t id_1, obj_t args_2, obj_t locals_3, obj_t module_4, obj_t class_5, obj_t src_exp_176_6, obj_t rem_7, obj_t node_8)
{
   enter_function_81_tools_error(id_1);
   {
      obj_t id_type_89_803;
      id_type_89_803 = parse_id_241_ast_ident(id_1);
      {
	 obj_t type_res_48_804;
	 type_res_48_804 = CDR(id_type_89_803);
	 {
	    obj_t id_805;
	    id_805 = CAR(id_type_89_803);
	    {
	       obj_t import_806;
	       {
		  bool_t test1523_850;
		  {
		     long n1_1369;
		     n1_1369 = (long) CINT(_bdb_debug__1_engine_param);
		     test1523_850 = (n1_1369 >= ((long) 2));
		  }
		  if (test1523_850)
		    {
		       import_806 = CNST_TABLE_REF(((long) 0));
		    }
		  else
		    {
		       import_806 = CNST_TABLE_REF(((long) 1));
		    }
	       }
	       {
		  obj_t old_global_82_807;
		  {
		     obj_t list1520_848;
		     list1520_848 = MAKE_PAIR(module_4, BNIL);
		     old_global_82_807 = find_global_223_ast_env(id_805, list1520_848);
		  }
		  {
		     global_t global_808;
		     {
			bool_t test1519_847;
			test1519_847 = is_a__118___object(old_global_82_807, global_ast_var);
			if (test1519_847)
			  {
			     global_808 = check_sfun_definition_109_ast_glo_def_117(old_global_82_807, type_res_48_804, args_2, locals_3, class_5, src_exp_176_6);
			  }
			else
			  {
			     global_808 = declare_global_sfun__255_ast_glo_decl_237(id_805, args_2, module_4, import_806, class_5, src_exp_176_6);
			  }
		     }
		     {
			obj_t def_loc_185_809;
			def_loc_185_809 = find_location_120_tools_location(src_exp_176_6);
			{
			   {
			      variable_t var_1372;
			      type_t new_type_21_1373;
			      var_1372 = (variable_t) (global_808);
			      new_type_21_1373 = (type_t) (type_res_48_804);
			      {
				 bool_t test1631_1375;
				 {
				    obj_t obj2_1378;
				    obj2_1378 = ____74_type_cache;
				    {
				       obj_t aux_1634;
				       {
					  type_t aux_1635;
					  aux_1635 = (((variable_t) CREF(var_1372))->type);
					  aux_1634 = (obj_t) (aux_1635);
				       }
				       test1631_1375 = (aux_1634 == obj2_1378);
				    }
				 }
				 if (test1631_1375)
				   {
				      ((((variable_t) CREF(var_1372))->type) = ((type_t) new_type_21_1373), BUNSPEC);
				   }
				 else
				   {
				      BUNSPEC;
				   }
			      }
			   }
			   {
			      bool_t test_1641;
			      {
				 long aux_1644;
				 long aux_1642;
				 {
				    obj_t aux_1645;
				    {
				       sfun_t obj_1382;
				       {
					  value_t aux_1646;
					  aux_1646 = (((global_t) CREF(global_808))->value);
					  obj_1382 = (sfun_t) (aux_1646);
				       }
				       aux_1645 = (((sfun_t) CREF(obj_1382))->args);
				    }
				    aux_1644 = list_length(aux_1645);
				 }
				 aux_1642 = list_length(locals_3);
				 test_1641 = (aux_1642 == aux_1644);
			      }
			      if (test_1641)
				{
				   obj_t types_811;
				   {
				      obj_t l1462_820;
				      {
					 sfun_t obj_1386;
					 {
					    value_t aux_1652;
					    aux_1652 = (((global_t) CREF(global_808))->value);
					    obj_1386 = (sfun_t) (aux_1652);
					 }
					 l1462_820 = (((sfun_t) CREF(obj_1386))->args);
				      }
				      if (NULLP(l1462_820))
					{
					   types_811 = BNIL;
					}
				      else
					{
					   obj_t head1464_822;
					   head1464_822 = MAKE_PAIR(BNIL, BNIL);
					   {
					      obj_t l1462_823;
					      obj_t tail1465_824;
					      l1462_823 = l1462_820;
					      tail1465_824 = head1464_822;
					    lname1463_825:
					      if (NULLP(l1462_823))
						{
						   types_811 = CDR(head1464_822);
						}
					      else
						{
						   obj_t newtail1466_827;
						   {
						      obj_t arg1498_829;
						      {
							 obj_t a_831;
							 a_831 = CAR(l1462_823);
							 {
							    bool_t test1500_832;
							    test1500_832 = is_a__118___object(a_831, local_ast_var);
							    if (test1500_832)
							      {
								 {
								    local_t obj_1394;
								    obj_1394 = (local_t) (a_831);
								    {
								       type_t aux_1666;
								       aux_1666 = (((local_t) CREF(obj_1394))->type);
								       arg1498_829 = (obj_t) (aux_1666);
								    }
								 }
							      }
							    else
							      {
								 bool_t test1501_833;
								 test1501_833 = is_a__118___object(a_831, type_type_type);
								 if (test1501_833)
								   {
								      arg1498_829 = a_831;
								   }
								 else
								   {
								      {
									 obj_t arg1504_836;
									 arg1504_836 = shape_tools_shape(a_831);
									 arg1498_829 = internal_error_43_tools_error(string1777_ast_glo_def_117, string1778_ast_glo_def_117, arg1504_836);
								      }
								   }
							      }
							 }
						      }
						      newtail1466_827 = MAKE_PAIR(arg1498_829, BNIL);
						   }
						   SET_CDR(tail1465_824, newtail1466_827);
						   {
						      obj_t tail1465_1677;
						      obj_t l1462_1675;
						      l1462_1675 = CDR(l1462_823);
						      tail1465_1677 = newtail1466_827;
						      tail1465_824 = tail1465_1677;
						      l1462_823 = l1462_1675;
						      goto lname1463_825;
						   }
						}
					   }
					}
				   }
				   {
				      obj_t ll1467_812;
				      obj_t ll1468_813;
				      {
					 bool_t aux_1678;
					 ll1467_812 = locals_3;
					 ll1468_813 = types_811;
				       lname1469_814:
					 if (NULLP(ll1467_812))
					   {
					      aux_1678 = ((bool_t) 1);
					   }
					 else
					   {
					      {
						 variable_t var_1404;
						 type_t new_type_21_1405;
						 {
						    obj_t aux_1681;
						    aux_1681 = CAR(ll1467_812);
						    var_1404 = (variable_t) (aux_1681);
						 }
						 {
						    obj_t aux_1684;
						    aux_1684 = CAR(ll1468_813);
						    new_type_21_1405 = (type_t) (aux_1684);
						 }
						 {
						    bool_t test1631_1407;
						    {
						       obj_t obj2_1410;
						       obj2_1410 = ____74_type_cache;
						       {
							  obj_t aux_1687;
							  {
							     type_t aux_1688;
							     aux_1688 = (((variable_t) CREF(var_1404))->type);
							     aux_1687 = (obj_t) (aux_1688);
							  }
							  test1631_1407 = (aux_1687 == obj2_1410);
						       }
						    }
						    if (test1631_1407)
						      {
							 ((((variable_t) CREF(var_1404))->type) = ((type_t) new_type_21_1405), BUNSPEC);
						      }
						    else
						      {
							 BUNSPEC;
						      }
						 }
					      }
					      {
						 obj_t ll1468_1696;
						 obj_t ll1467_1694;
						 ll1467_1694 = CDR(ll1467_812);
						 ll1468_1696 = CDR(ll1468_813);
						 ll1468_813 = ll1468_1696;
						 ll1467_812 = ll1467_1694;
						 goto lname1469_814;
					      }
					   }
					 BBOOL(aux_1678);
				      }
				   }
				}
			      else
				{
				   BUNSPEC;
				}
			   }
			   remove_var_from__148_ast_remove(rem_7, (variable_t) (global_808));
			   {
			      sfun_t obj_1416;
			      {
				 value_t aux_1701;
				 aux_1701 = (((global_t) CREF(global_808))->value);
				 obj_1416 = (sfun_t) (aux_1701);
			      }
			      ((((sfun_t) CREF(obj_1416))->body) = ((obj_t) node_8), BUNSPEC);
			   }
			   {
			      sfun_t obj_1419;
			      {
				 value_t aux_1705;
				 aux_1705 = (((global_t) CREF(global_808))->value);
				 obj_1419 = (sfun_t) (aux_1705);
			      }
			      ((((sfun_t) CREF(obj_1419))->args) = ((obj_t) locals_3), BUNSPEC);
			   }
			   {
			      sfun_t obj_1422;
			      {
				 value_t aux_1709;
				 aux_1709 = (((global_t) CREF(global_808))->value);
				 obj_1422 = (sfun_t) (aux_1709);
			      }
			      ((((sfun_t) CREF(obj_1422))->loc) = ((obj_t) def_loc_185_809), BUNSPEC);
			   }
			   leave_function_170_tools_error();
			   return global_808;
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _def-global-sfun! */ obj_t 
_def_global_sfun__109_ast_glo_def_117(obj_t env_1559, obj_t id_1560, obj_t args_1561, obj_t locals_1562, obj_t module_1563, obj_t class_1564, obj_t src_exp_176_1565, obj_t rem_1566, obj_t node_1567)
{
   {
      global_t aux_1714;
      aux_1714 = def_global_sfun__93_ast_glo_def_117(id_1560, args_1561, locals_1562, module_1563, class_1564, src_exp_176_1565, rem_1566, node_1567);
      return (obj_t) (aux_1714);
   }
}


/* check-sfun-definition */ global_t 
check_sfun_definition_109_ast_glo_def_117(obj_t old_9, obj_t type_res_48_10, obj_t args_11, obj_t locals_12, obj_t class_13, obj_t src_exp_176_14)
{
   {
      value_t old_value_175_851;
      {
	 global_t obj_1424;
	 obj_1424 = (global_t) (old_9);
	 old_value_175_851 = (((global_t) CREF(obj_1424))->value);
      }
      {
	 bool_t test1524_852;
	 test1524_852 = is_a__118___object((obj_t) (old_value_175_851), sfun_ast_var);
	 if (test1524_852)
	   {
	      bool_t test_1722;
	      {
		 obj_t aux_1723;
		 {
		    sfun_t obj_1426;
		    obj_1426 = (sfun_t) (old_value_175_851);
		    aux_1723 = (((sfun_t) CREF(obj_1426))->class);
		 }
		 test_1722 = (aux_1723 == class_13);
	      }
	      if (test_1722)
		{
		   bool_t test1526_854;
		   {
		      long arg1580_908;
		      int arg1581_909;
		      {
			 sfun_t obj_1429;
			 obj_1429 = (sfun_t) (old_value_175_851);
			 arg1580_908 = (((sfun_t) CREF(obj_1429))->arity);
		      }
		      arg1581_909 = arity_tools_args(args_11);
		      {
			 long aux_1730;
			 aux_1730 = (long) (arg1581_909);
			 test1526_854 = (arg1580_908 == aux_1730);
		      }
		   }
		   if (test1526_854)
		     {
			bool_t test1527_855;
			{
			   type_t aux_1738;
			   bool_t aux_1734;
			   {
			      global_t obj_1434;
			      obj_1434 = (global_t) (old_9);
			      aux_1738 = (((global_t) CREF(obj_1434))->type);
			   }
			   {
			      obj_t aux_1735;
			      aux_1735 = CNST_TABLE_REF(((long) 2));
			      aux_1734 = (aux_1735 == class_13);
			   }
			   test1527_855 = compatible_type__151_ast_glo_def_117(aux_1734, (type_t) (type_res_48_10), aux_1738);
			}
			if (test1527_855)
			  {
			     bool_t test1528_856;
			     {
				obj_t arg1563_897;
				obj_t arg1564_898;
				{
				   sfun_t obj_1435;
				   obj_1435 = (sfun_t) (old_value_175_851);
				   arg1563_897 = (((sfun_t) CREF(obj_1435))->dsssl_keywords_243);
				}
				arg1564_898 = dsssl_formals_encoding_15_tools_dsssl(args_11);
				test1528_856 = equal__25___r4_equivalence_6_2(arg1563_897, arg1564_898);
			     }
			     if (test1528_856)
			       {
				  obj_t _ortest_1470_857;
				  {
				     obj_t locals_858;
				     obj_t types_859;
				     bool_t sub__142_860;
				     {
					obj_t arg1529_862;
					bool_t arg1530_863;
					{
					   obj_t l1471_864;
					   {
					      sfun_t obj_1436;
					      obj_1436 = (sfun_t) (old_value_175_851);
					      l1471_864 = (((sfun_t) CREF(obj_1436))->args);
					   }
					   if (NULLP(l1471_864))
					     {
						arg1529_862 = BNIL;
					     }
					   else
					     {
						obj_t head1473_866;
						head1473_866 = MAKE_PAIR(BNIL, BNIL);
						{
						   obj_t l1471_867;
						   obj_t tail1474_868;
						   l1471_867 = l1471_864;
						   tail1474_868 = head1473_866;
						 lname1472_869:
						   if (NULLP(l1471_867))
						     {
							arg1529_862 = CDR(head1473_866);
						     }
						   else
						     {
							obj_t newtail1475_871;
							{
							   obj_t arg1534_873;
							   {
							      obj_t a_875;
							      a_875 = CAR(l1471_867);
							      {
								 bool_t test1536_876;
								 test1536_876 = is_a__118___object(a_875, local_ast_var);
								 if (test1536_876)
								   {
								      {
									 local_t obj_1444;
									 obj_1444 = (local_t) (a_875);
									 {
									    type_t aux_1761;
									    aux_1761 = (((local_t) CREF(obj_1444))->type);
									    arg1534_873 = (obj_t) (aux_1761);
									 }
								      }
								   }
								 else
								   {
								      bool_t test1537_877;
								      test1537_877 = is_a__118___object(a_875, type_type_type);
								      if (test1537_877)
									{
									   arg1534_873 = a_875;
									}
								      else
									{
									   {
									      obj_t arg1542_880;
									      arg1542_880 = shape_tools_shape(a_875);
									      arg1534_873 = internal_error_43_tools_error(string1777_ast_glo_def_117, string1778_ast_glo_def_117, arg1542_880);
									   }
									}
								   }
							      }
							   }
							   newtail1475_871 = MAKE_PAIR(arg1534_873, BNIL);
							}
							SET_CDR(tail1474_868, newtail1475_871);
							{
							   obj_t tail1474_1772;
							   obj_t l1471_1770;
							   l1471_1770 = CDR(l1471_867);
							   tail1474_1772 = newtail1475_871;
							   tail1474_868 = tail1474_1772;
							   l1471_867 = l1471_1770;
							   goto lname1472_869;
							}
						     }
						}
					     }
					}
					{
					   obj_t aux_1773;
					   aux_1773 = CNST_TABLE_REF(((long) 2));
					   arg1530_863 = (aux_1773 == class_13);
					}
					locals_858 = locals_12;
					types_859 = arg1529_862;
					sub__142_860 = arg1530_863;
				      loop_861:
					if (NULLP(locals_858))
					  {
					     {
						global_t obj_1454;
						obj_1454 = (global_t) (old_9);
						((((global_t) CREF(obj_1454))->src) = ((obj_t) src_exp_176_14), BUNSPEC);
					     }
					     _ortest_1470_857 = old_9;
					  }
					else
					  {
					     bool_t test1551_885;
					     {
						type_t aux_1785;
						type_t aux_1780;
						{
						   obj_t aux_1786;
						   aux_1786 = CAR(types_859);
						   aux_1785 = (type_t) (aux_1786);
						}
						{
						   local_t obj_1457;
						   {
						      obj_t aux_1781;
						      aux_1781 = CAR(locals_858);
						      obj_1457 = (local_t) (aux_1781);
						   }
						   aux_1780 = (((local_t) CREF(obj_1457))->type);
						}
						test1551_885 = compatible_type__151_ast_glo_def_117(sub__142_860, aux_1780, aux_1785);
					     }
					     if (test1551_885)
					       {
						  {
						     bool_t sub__142_1795;
						     obj_t types_1793;
						     obj_t locals_1791;
						     locals_1791 = CDR(locals_858);
						     types_1793 = CDR(types_859);
						     sub__142_1795 = ((bool_t) 0);
						     sub__142_860 = sub__142_1795;
						     types_859 = types_1793;
						     locals_858 = locals_1791;
						     goto loop_861;
						  }
					       }
					     else
					       {
						  {
						     obj_t list1554_888;
						     list1554_888 = MAKE_PAIR(string1779_ast_glo_def_117, BNIL);
						     {
							global_t aux_1797;
							aux_1797 = mismatch_error_84_ast_glo_def_117((global_t) (old_9), src_exp_176_14, list1554_888);
							_ortest_1470_857 = (obj_t) (aux_1797);
						     }
						  }
					       }
					  }
				     }
				  }
				  if (CBOOL(_ortest_1470_857))
				    {
				       return (global_t) (_ortest_1470_857);
				    }
				  else
				    {
				       return (global_t) (old_9);
				    }
			       }
			     else
			       {
				  {
				     obj_t list1560_894;
				     list1560_894 = MAKE_PAIR(string1780_ast_glo_def_117, BNIL);
				     return mismatch_error_84_ast_glo_def_117((global_t) (old_9), src_exp_176_14, list1560_894);
				  }
			       }
			  }
			else
			  {
			     {
				obj_t list1565_899;
				list1565_899 = MAKE_PAIR(string1781_ast_glo_def_117, BNIL);
				return mismatch_error_84_ast_glo_def_117((global_t) (old_9), src_exp_176_14, list1565_899);
			     }
			  }
		     }
		   else
		     {
			{
			   obj_t list1573_905;
			   list1573_905 = MAKE_PAIR(string1782_ast_glo_def_117, BNIL);
			   return mismatch_error_84_ast_glo_def_117((global_t) (old_9), src_exp_176_14, list1573_905);
			}
		     }
		}
	      else
		{
		   return mismatch_error_84_ast_glo_def_117((global_t) (old_9), src_exp_176_14, BNIL);
		}
	   }
	 else
	   {
	      return mismatch_error_84_ast_glo_def_117((global_t) (old_9), src_exp_176_14, BNIL);
	   }
      }
   }
}


/* def-global-scnst! */ global_t 
def_global_scnst__93_ast_glo_def_117(obj_t id_15, obj_t module_16, obj_t node_17, obj_t class_18)
{
   enter_function_81_tools_error(id_15);
   {
      obj_t id_type_89_913;
      id_type_89_913 = parse_id_241_ast_ident(id_15);
      {
	 obj_t id_id_127_914;
	 id_id_127_914 = CAR(id_type_89_913);
	 {
	    obj_t old_global_82_915;
	    {
	       obj_t list1587_919;
	       list1587_919 = MAKE_PAIR(module_16, BNIL);
	       old_global_82_915 = find_global_223_ast_env(id_id_127_914, list1587_919);
	    }
	    {
	       global_t global_916;
	       global_916 = declare_global_scnst__70_ast_glo_decl_237(id_15, module_16, CNST_TABLE_REF(((long) 1)), node_17, class_18);
	       {
		  remove_var_from__148_ast_remove(CNST_TABLE_REF(((long) 3)), (variable_t) (global_916));
		  leave_function_170_tools_error();
		  return global_916;
	       }
	    }
	 }
      }
   }
}


/* _def-global-scnst! */ obj_t 
_def_global_scnst__222_ast_glo_def_117(obj_t env_1568, obj_t id_1569, obj_t module_1570, obj_t node_1571, obj_t class_1572)
{
   {
      global_t aux_1829;
      aux_1829 = def_global_scnst__93_ast_glo_def_117(id_1569, module_1570, node_1571, class_1572);
      return (obj_t) (aux_1829);
   }
}


/* def-global-svar! */ global_t 
def_global_svar__184_ast_glo_def_117(obj_t id_19, obj_t module_20, obj_t src_exp_176_21, obj_t rem_22)
{
   {
      obj_t id_type_89_921;
      id_type_89_921 = parse_id_241_ast_ident(id_19);
      {
	 obj_t id_id_127_922;
	 id_id_127_922 = CAR(id_type_89_921);
	 {
	    obj_t old_global_82_923;
	    {
	       obj_t list1605_940;
	       list1605_940 = MAKE_PAIR(module_20, BNIL);
	       old_global_82_923 = find_global_223_ast_env(id_id_127_922, list1605_940);
	    }
	    {
	       obj_t import_924;
	       {
		  bool_t test1604_939;
		  {
		     long n1_1463;
		     n1_1463 = (long) CINT(_bdb_debug__1_engine_param);
		     test1604_939 = (n1_1463 >= ((long) 2));
		  }
		  if (test1604_939)
		    {
		       import_924 = CNST_TABLE_REF(((long) 0));
		    }
		  else
		    {
		       import_924 = CNST_TABLE_REF(((long) 1));
		    }
	       }
	       {
		  obj_t type_925;
		  {
		     obj_t type_932;
		     type_932 = CDR(id_type_89_921);
		     {
			bool_t test_1842;
			{
			   obj_t aux_1846;
			   obj_t aux_1843;
			   aux_1846 = CNST_TABLE_REF(((long) 4));
			   {
			      type_t obj_1466;
			      obj_1466 = (type_t) (type_932);
			      aux_1843 = (((type_t) CREF(obj_1466))->class);
			   }
			   test_1842 = (aux_1843 == aux_1846);
			}
			if (test_1842)
			  {
			     type_925 = type_932;
			  }
			else
			  {
			     obj_t arg1600_935;
			     arg1600_935 = shape_tools_shape(type_932);
			     type_925 = user_error_151_tools_error(id_id_127_922, string1783_ast_glo_def_117, arg1600_935, BNIL);
			  }
		     }
		  }
		  {
		     global_t global_926;
		     {
			bool_t test1594_931;
			test1594_931 = is_a__118___object(old_global_82_923, global_ast_var);
			if (test1594_931)
			  {
			     global_926 = check_svar_definition_92_ast_glo_def_117(old_global_82_923, type_925, src_exp_176_21);
			  }
			else
			  {
			     global_926 = declare_global_svar__200_ast_glo_decl_237(id_19, module_20, import_924, src_exp_176_21);
			  }
		     }
		     {
			obj_t def_loc_185_927;
			def_loc_185_927 = find_location_120_tools_location(src_exp_176_21);
			{
			   {
			      variable_t var_1470;
			      type_t new_type_21_1471;
			      var_1470 = (variable_t) (global_926);
			      new_type_21_1471 = (type_t) (type_925);
			      {
				 bool_t test1631_1473;
				 {
				    obj_t obj2_1476;
				    obj2_1476 = ____74_type_cache;
				    {
				       obj_t aux_1858;
				       {
					  type_t aux_1859;
					  aux_1859 = (((variable_t) CREF(var_1470))->type);
					  aux_1858 = (obj_t) (aux_1859);
				       }
				       test1631_1473 = (aux_1858 == obj2_1476);
				    }
				 }
				 if (test1631_1473)
				   {
				      ((((variable_t) CREF(var_1470))->type) = ((type_t) new_type_21_1471), BUNSPEC);
				   }
				 else
				   {
				      BUNSPEC;
				   }
			      }
			   }
			   {
			      bool_t test1589_928;
			      {
				 obj_t aux_1865;
				 {
				    value_t aux_1866;
				    aux_1866 = (((global_t) CREF(global_926))->value);
				    aux_1865 = (obj_t) (aux_1866);
				 }
				 test1589_928 = is_a__118___object(aux_1865, svar_ast_var);
			      }
			      if (test1589_928)
				{
				   svar_t obj_1482;
				   {
				      value_t aux_1871;
				      aux_1871 = (((global_t) CREF(global_926))->value);
				      obj_1482 = (svar_t) (aux_1871);
				   }
				   ((((svar_t) CREF(obj_1482))->loc) = ((obj_t) def_loc_185_927), BUNSPEC);
				}
			      else
				{
				   BUNSPEC;
				}
			   }
			   remove_var_from__148_ast_remove(rem_22, (variable_t) (global_926));
			   return global_926;
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _def-global-svar! */ obj_t 
_def_global_svar__252_ast_glo_def_117(obj_t env_1573, obj_t id_1574, obj_t module_1575, obj_t src_exp_176_1576, obj_t rem_1577)
{
   {
      global_t aux_1877;
      aux_1877 = def_global_svar__184_ast_glo_def_117(id_1574, module_1575, src_exp_176_1576, rem_1577);
      return (obj_t) (aux_1877);
   }
}


/* check-svar-definition */ global_t 
check_svar_definition_92_ast_glo_def_117(obj_t old_23, obj_t type_24, obj_t src_exp_176_25)
{
   {
      bool_t test1607_943;
      {
	 obj_t aux_1880;
	 {
	    value_t aux_1881;
	    {
	       global_t obj_1484;
	       obj_1484 = (global_t) (old_23);
	       aux_1881 = (((global_t) CREF(obj_1484))->value);
	    }
	    aux_1880 = (obj_t) (aux_1881);
	 }
	 test1607_943 = is_a__118___object(aux_1880, svar_ast_var);
      }
      if (test1607_943)
	{
	   bool_t test1608_944;
	   {
	      type_t aux_1887;
	      {
		 global_t obj_1486;
		 obj_1486 = (global_t) (old_23);
		 aux_1887 = (((global_t) CREF(obj_1486))->type);
	      }
	      test1608_944 = compatible_type__151_ast_glo_def_117(((bool_t) 0), (type_t) (type_24), aux_1887);
	   }
	   if (test1608_944)
	     {
		return (global_t) (old_23);
	     }
	   else
	     {
		{
		   obj_t list1609_945;
		   list1609_945 = MAKE_PAIR(string1784_ast_glo_def_117, BNIL);
		   return mismatch_error_84_ast_glo_def_117((global_t) (old_23), src_exp_176_25, list1609_945);
		}
	     }
	}
      else
	{
	   return mismatch_error_84_ast_glo_def_117((global_t) (old_23), src_exp_176_25, BNIL);
	}
   }
}


/* compatible-type? */ bool_t 
compatible_type__151_ast_glo_def_117(bool_t sub__142_26, type_t new_27, type_t old_28)
{
   {
      bool_t _ortest_1476_950;
      {
	 obj_t obj2_1488;
	 obj2_1488 = ____74_type_cache;
	 {
	    obj_t aux_1899;
	    aux_1899 = (obj_t) (new_27);
	    _ortest_1476_950 = (aux_1899 == obj2_1488);
	 }
      }
      if (_ortest_1476_950)
	{
	   return _ortest_1476_950;
	}
      else
	{
	   bool_t _ortest_1477_951;
	   {
	      obj_t aux_1905;
	      obj_t aux_1903;
	      aux_1905 = (obj_t) (new_27);
	      aux_1903 = (obj_t) (old_28);
	      _ortest_1477_951 = (aux_1903 == aux_1905);
	   }
	   if (_ortest_1477_951)
	     {
		return _ortest_1477_951;
	     }
	   else
	     {
		if (sub__142_26)
		  {
		     bool_t _ortest_1479_953;
		     _ortest_1479_953 = type_subclass__90_object_class(new_27, old_28);
		     if (_ortest_1479_953)
		       {
			  return _ortest_1479_953;
		       }
		     else
		       {
			  bool_t _andtest_1480_954;
			  _andtest_1480_954 = is_a__118___object((obj_t) (new_27), class_object_class);
			  if (_andtest_1480_954)
			    {
			       obj_t obj2_1493;
			       obj2_1493 = _obj__252_type_cache;
			       {
				  obj_t aux_1915;
				  aux_1915 = (obj_t) (old_28);
				  return (aux_1915 == obj2_1493);
			       }
			    }
			  else
			    {
			       return ((bool_t) 0);
			    }
		       }
		  }
		else
		  {
		     return ((bool_t) 0);
		  }
	     }
	}
   }
}


/* mismatch-error */ global_t 
mismatch_error_84_ast_glo_def_117(global_t global_29, obj_t src_exp_176_30, obj_t add_msg_187_31)
{
   {
      obj_t arg1615_956;
      obj_t arg1617_957;
      if (PAIRP(add_msg_187_31))
	{
	   obj_t list1624_963;
	   {
	      obj_t arg1625_964;
	      {
		 obj_t arg1627_965;
		 {
		    obj_t aux_1920;
		    aux_1920 = CAR(add_msg_187_31);
		    arg1627_965 = MAKE_PAIR(aux_1920, BNIL);
		 }
		 arg1625_964 = MAKE_PAIR(string1785_ast_glo_def_117, arg1627_965);
	      }
	      list1624_963 = MAKE_PAIR(string1786_ast_glo_def_117, arg1625_964);
	   }
	   arg1615_956 = string_append_106___r4_strings_6_7(list1624_963);
	}
      else
	{
	   arg1615_956 = string1786_ast_glo_def_117;
	}
      arg1617_957 = shape_tools_shape((((global_t) CREF(global_29))->src));
      {
	 obj_t list1618_958;
	 {
	    obj_t aux_1928;
	    aux_1928 = (obj_t) (global_29);
	    list1618_958 = MAKE_PAIR(aux_1928, BNIL);
	 }
	 {
	    obj_t aux_1931;
	    aux_1931 = user_error_151_tools_error(arg1615_956, arg1617_957, src_exp_176_30, list1618_958);
	    return (global_t) (aux_1931);
	 }
      }
   }
}


/* check-method-definition */ bool_t 
check_method_definition_71_ast_glo_def_117(obj_t id_34, obj_t args_35, obj_t locals_36, obj_t src_37)
{
   {
      type_t type_res_48_970;
      obj_t method_id_209_971;
      obj_t generic_972;
      type_res_48_970 = type_of_id_183_ast_ident(id_34);
      method_id_209_971 = id_of_id_112_ast_ident(id_34);
      generic_972 = find_global_223_ast_env(id_34, BNIL);
      {
	 bool_t test1632_973;
	 test1632_973 = is_a__118___object(generic_972, global_ast_var);
	 if (test1632_973)
	   {
	      value_t generic_value_252_974;
	      {
		 global_t obj_1505;
		 obj_1505 = (global_t) (generic_972);
		 generic_value_252_974 = (((global_t) CREF(obj_1505))->value);
	      }
	      {
		 bool_t test1633_975;
		 test1633_975 = is_a__118___object((obj_t) (generic_value_252_974), sfun_ast_var);
		 if (test1633_975)
		   {
		      bool_t test_1944;
		      {
			 obj_t aux_1948;
			 obj_t aux_1945;
			 aux_1948 = CNST_TABLE_REF(((long) 2));
			 {
			    sfun_t obj_1507;
			    obj_1507 = (sfun_t) (generic_value_252_974);
			    aux_1945 = (((sfun_t) CREF(obj_1507))->class);
			 }
			 test_1944 = (aux_1945 == aux_1948);
		      }
		      if (test_1944)
			{
			   bool_t test1635_977;
			   {
			      long arg1677_1021;
			      int arg1678_1022;
			      {
				 sfun_t obj_1510;
				 obj_1510 = (sfun_t) (generic_value_252_974);
				 arg1677_1021 = (((sfun_t) CREF(obj_1510))->arity);
			      }
			      arg1678_1022 = arity_tools_args(args_35);
			      {
				 long aux_1954;
				 aux_1954 = (long) (arg1678_1022);
				 test1635_977 = (arg1677_1021 == aux_1954);
			      }
			   }
			   if (test1635_977)
			     {
				bool_t test1636_978;
				{
				   type_t aux_1958;
				   {
				      global_t obj_1513;
				      obj_1513 = (global_t) (generic_972);
				      aux_1958 = (((global_t) CREF(obj_1513))->type);
				   }
				   test1636_978 = compatible_type__151_ast_glo_def_117(((bool_t) 1), type_res_48_970, aux_1958);
				}
				if (test1636_978)
				  {
				     bool_t _ortest_1481_979;
				     {
					obj_t locals_980;
					obj_t types_981;
					bool_t sub__142_982;
					{
					   obj_t arg1638_984;
					   {
					      obj_t l1482_985;
					      {
						 sfun_t obj_1514;
						 obj_1514 = (sfun_t) (generic_value_252_974);
						 l1482_985 = (((sfun_t) CREF(obj_1514))->args);
					      }
					      if (NULLP(l1482_985))
						{
						   arg1638_984 = BNIL;
						}
					      else
						{
						   obj_t head1484_987;
						   head1484_987 = MAKE_PAIR(BNIL, BNIL);
						   {
						      obj_t l1482_988;
						      obj_t tail1485_989;
						      l1482_988 = l1482_985;
						      tail1485_989 = head1484_987;
						    lname1483_990:
						      if (NULLP(l1482_988))
							{
							   arg1638_984 = CDR(head1484_987);
							}
						      else
							{
							   obj_t newtail1486_992;
							   {
							      obj_t arg1645_994;
							      {
								 obj_t a_996;
								 a_996 = CAR(l1482_988);
								 {
								    bool_t test1647_997;
								    test1647_997 = is_a__118___object(a_996, local_ast_var);
								    if (test1647_997)
								      {
									 {
									    local_t obj_1522;
									    obj_1522 = (local_t) (a_996);
									    {
									       type_t aux_1975;
									       aux_1975 = (((local_t) CREF(obj_1522))->type);
									       arg1645_994 = (obj_t) (aux_1975);
									    }
									 }
								      }
								    else
								      {
									 bool_t test1648_998;
									 test1648_998 = is_a__118___object(a_996, type_type_type);
									 if (test1648_998)
									   {
									      arg1645_994 = a_996;
									   }
									 else
									   {
									      {
										 obj_t arg1652_1001;
										 arg1652_1001 = shape_tools_shape(a_996);
										 arg1645_994 = internal_error_43_tools_error(string1777_ast_glo_def_117, string1778_ast_glo_def_117, arg1652_1001);
									      }
									   }
								      }
								 }
							      }
							      newtail1486_992 = MAKE_PAIR(arg1645_994, BNIL);
							   }
							   SET_CDR(tail1485_989, newtail1486_992);
							   {
							      obj_t tail1485_1986;
							      obj_t l1482_1984;
							      l1482_1984 = CDR(l1482_988);
							      tail1485_1986 = newtail1486_992;
							      tail1485_989 = tail1485_1986;
							      l1482_988 = l1482_1984;
							      goto lname1483_990;
							   }
							}
						   }
						}
					   }
					   locals_980 = locals_36;
					   types_981 = arg1638_984;
					   sub__142_982 = ((bool_t) 1);
					 loop_983:
					   if (NULLP(locals_980))
					     {
						_ortest_1481_979 = ((bool_t) 1);
					     }
					   else
					     {
						bool_t test1656_1005;
						{
						   type_t aux_1994;
						   type_t aux_1989;
						   {
						      obj_t aux_1995;
						      aux_1995 = CAR(types_981);
						      aux_1994 = (type_t) (aux_1995);
						   }
						   {
						      local_t obj_1531;
						      {
							 obj_t aux_1990;
							 aux_1990 = CAR(locals_980);
							 obj_1531 = (local_t) (aux_1990);
						      }
						      aux_1989 = (((local_t) CREF(obj_1531))->type);
						   }
						   test1656_1005 = compatible_type__151_ast_glo_def_117(sub__142_982, aux_1989, aux_1994);
						}
						if (test1656_1005)
						  {
						     {
							bool_t sub__142_2004;
							obj_t types_2002;
							obj_t locals_2000;
							locals_2000 = CDR(locals_980);
							types_2002 = CDR(types_981);
							sub__142_2004 = ((bool_t) 0);
							sub__142_982 = sub__142_2004;
							types_981 = types_2002;
							locals_980 = locals_2000;
							goto loop_983;
						     }
						  }
						else
						  {
						     {
							obj_t list1659_1008;
							list1659_1008 = MAKE_PAIR(string1779_ast_glo_def_117, BNIL);
							mismatch_error_84_ast_glo_def_117((global_t) (generic_972), src_37, list1659_1008);
						     }
						     _ortest_1481_979 = ((bool_t) 0);
						  }
					     }
					}
				     }
				     if (_ortest_1481_979)
				       {
					  return _ortest_1481_979;
				       }
				     else
				       {
					  return ((bool_t) 1);
				       }
				  }
				else
				  {
				     {
					obj_t list1668_1014;
					list1668_1014 = MAKE_PAIR(string1781_ast_glo_def_117, BNIL);
					mismatch_error_84_ast_glo_def_117((global_t) (generic_972), src_37, list1668_1014);
				     }
				     return ((bool_t) 0);
				  }
			     }
			   else
			     {
				{
				   obj_t list1673_1018;
				   list1673_1018 = MAKE_PAIR(string1782_ast_glo_def_117, BNIL);
				   mismatch_error_84_ast_glo_def_117((global_t) (generic_972), src_37, list1673_1018);
				}
				return ((bool_t) 0);
			     }
			}
		      else
			{
			   mismatch_error_84_ast_glo_def_117((global_t) (generic_972), src_37, BNIL);
			   return ((bool_t) 0);
			}
		   }
		 else
		   {
		      mismatch_error_84_ast_glo_def_117((global_t) (generic_972), src_37, BNIL);
		      return ((bool_t) 0);
		   }
	      }
	   }
	 else
	   {
	      return ((bool_t) 1);
	   }
      }
   }
}


/* _check-method-definition */ obj_t 
_check_method_definition_40_ast_glo_def_117(obj_t env_1578, obj_t id_1579, obj_t args_1580, obj_t locals_1581, obj_t src_1582)
{
   {
      bool_t aux_2019;
      aux_2019 = check_method_definition_71_ast_glo_def_117(id_1579, args_1580, locals_1581, src_1582);
      return BBOOL(aux_2019);
   }
}


/* method-init */ obj_t 
method_init_76_ast_glo_def_117()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_glo_def_117()
{
   module_initialization_70_tools_trace(((long) 0), "AST_GLO-DEF");
   module_initialization_70_type_type(((long) 0), "AST_GLO-DEF");
   module_initialization_70_ast_var(((long) 0), "AST_GLO-DEF");
   module_initialization_70_ast_node(((long) 0), "AST_GLO-DEF");
   module_initialization_70_ast_env(((long) 0), "AST_GLO-DEF");
   module_initialization_70_ast_ident(((long) 0), "AST_GLO-DEF");
   module_initialization_70_ast_glo_decl_237(((long) 0), "AST_GLO-DEF");
   module_initialization_70_ast_remove(((long) 0), "AST_GLO-DEF");
   module_initialization_70_type_env(((long) 0), "AST_GLO-DEF");
   module_initialization_70_type_cache(((long) 0), "AST_GLO-DEF");
   module_initialization_70_tools_args(((long) 0), "AST_GLO-DEF");
   module_initialization_70_tools_error(((long) 0), "AST_GLO-DEF");
   module_initialization_70_tools_shape(((long) 0), "AST_GLO-DEF");
   module_initialization_70_tools_location(((long) 0), "AST_GLO-DEF");
   module_initialization_70_tools_dsssl(((long) 0), "AST_GLO-DEF");
   module_initialization_70_object_class(((long) 0), "AST_GLO-DEF");
   return module_initialization_70_engine_param(((long) 0), "AST_GLO-DEF");
}
