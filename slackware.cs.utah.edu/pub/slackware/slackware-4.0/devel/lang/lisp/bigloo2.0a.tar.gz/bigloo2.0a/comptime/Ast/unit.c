/*===========================================================================*/
/*   (Ast/unit.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
extern obj_t find_global_defs_64_ast_find_gdefs_13(obj_t);
extern obj_t make_n_proto_123_tools_args(obj_t);
static obj_t method_init_76_ast_unit();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t eta_expanse_111_ast_unit(obj_t, obj_t);
extern obj_t unit__defs_135_ast_unit(obj_t);
extern obj_t dsssl_find_first_formal_237_tools_dsssl(obj_t);
extern obj_t id_of_id_112_ast_ident(obj_t);
static obj_t _unit_list__71_ast_unit = BUNSPEC;
static obj_t make_sfun_definition_61_ast_unit(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t make_sgfun_definition_102_ast_unit(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t unit_initializer_id_235_ast_unit(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t normalize_progn_error_20_ast_unit(obj_t, obj_t);
static obj_t _unit_initializers_20_ast_unit(obj_t);
static obj_t make_svar_definition_154_ast_unit(obj_t, obj_t);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_ast_find_gdefs_13(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_object_generic(long, char *);
extern obj_t module_initialization_70_object_method(long, char *);
extern obj_t module_initialization_70_object_inline(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_class(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___dsssl(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t unit_initializers_25_ast_unit();
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel___ast_181_ast_unit(obj_t, obj_t);
extern obj_t fun_ast_var;
static obj_t _unit__defs_170_ast_unit(obj_t, obj_t);
static obj_t imported_modules_init_94_ast_unit();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t get_method_unit_151_module_class();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
extern obj_t _module_clause__117_module_module;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _user_error_251_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_ast_unit();
extern bool_t check_method_definition_71_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_ast_unit();
extern obj_t unit_init_calls_56_ast_unit();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t declare_unit__164_ast_unit(obj_t, long);
static obj_t make_sgfun_default_250_ast_unit(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
extern obj_t add_generic_for_method_inlining__147_object_inline(obj_t);
static obj_t get_global_arity_252_ast_unit(obj_t, obj_t, obj_t);
extern local_t make_user_local_svar_134_ast_local(obj_t, type_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t check_id_6_ast_ident(obj_t, obj_t);
static obj_t toplevel__ast_219_ast_unit(obj_t, obj_t);
extern obj_t unit_sexp__add__71_ast_unit(obj_t, obj_t);
static obj_t _unit_init_calls_204_ast_unit(obj_t);
extern obj_t _module__166_module_module;
extern obj_t _4dots_199_tools_misc;
static obj_t make_method_definition_178_ast_unit(obj_t, obj_t, obj_t, obj_t);
extern obj_t make_generic_body_233_object_generic(obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern global_t def_global_svar__184_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t find_location_120_tools_location(obj_t);
extern obj_t make_method_body_103_object_method(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_dsssl_function_prelude_58___dsssl(obj_t, obj_t, obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_unit = BUNSPEC;
extern obj_t get_toplevel_unit_32_module_include();
static obj_t _unit_initializer_id_32_ast_unit(obj_t, obj_t);
static obj_t cnst_init_137_ast_unit();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t _unit_sexp__add__174_ast_unit(obj_t, obj_t, obj_t);
static obj_t __cnst[25];

extern obj_t user_error_env_101_tools_error;
DEFINE_EXPORT_PROCEDURE(unit_initializer_id_env_201_ast_unit, _unit_initializer_id_32_ast_unit2321, _unit_initializer_id_32_ast_unit, 0L, 1);
DEFINE_EXPORT_PROCEDURE(unit_initializers_env_47_ast_unit, _unit_initializers_20_ast_unit2322, _unit_initializers_20_ast_unit, 0L, 0);
DEFINE_EXPORT_PROCEDURE(unit_sexp__add__env_136_ast_unit, _unit_sexp__add__174_ast_unit2323, _unit_sexp__add__174_ast_unit, 0L, 2);
DEFINE_EXPORT_PROCEDURE(unit_init_calls_env_88_ast_unit, _unit_init_calls_204_ast_unit2324, _unit_init_calls_204_ast_unit, 0L, 0);
DEFINE_STRING(string2311_ast_unit, string2311_ast_unit2325, "UNIT ADD-GENERIC! SGFUN -DEFAULT QUOTE ERROR NOW CONS* APPLY DEFINE-METHOD DEFINE-GENERIC SIFUN DEFINE-INLINE DEFINE BEGIN LAMBDA SFUN READ @ -INIT CGEN SNIFUN ::OBJ *DEBUG* SET! ", 179);
DEFINE_STRING(string2309_ast_unit, string2309_ast_unit2326, "cer", 3);
DEFINE_STRING(string2310_ast_unit, string2310_ast_unit2327, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string2308_ast_unit, string2308_ast_unit2328, "No method for this object", 25);
DEFINE_STRING(string2307_ast_unit, string2307_ast_unit2329, "Illegal '() expression", 22);
DEFINE_STRING(string2306_ast_unit, string2306_ast_unit2330, "      [", 7);
DEFINE_STRING(string2305_ast_unit, string2305_ast_unit2331, "]", 1);
DEFINE_EXPORT_PROCEDURE(unit__defs_env_18_ast_unit, _unit__defs_170_ast_unit2332, _unit__defs_170_ast_unit, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_ast_unit(long checksum_2723, char *from_2724)
{
   if (CBOOL(require_initialization_114_ast_unit))
     {
	require_initialization_114_ast_unit = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_unit();
	cnst_init_137_ast_unit();
	imported_modules_init_94_ast_unit();
	method_init_76_ast_unit();
	toplevel_init_63_ast_unit();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_unit()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_UNIT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_UNIT");
   module_initialization_70___object(((long) 0), "AST_UNIT");
   module_initialization_70___r4_strings_6_7(((long) 0), "AST_UNIT");
   module_initialization_70___reader(((long) 0), "AST_UNIT");
   module_initialization_70___dsssl(((long) 0), "AST_UNIT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_unit()
{
   {
      obj_t cnst_port_138_2715;
      cnst_port_138_2715 = open_input_string(string2311_ast_unit);
      {
	 long i_2716;
	 i_2716 = ((long) 24);
       loop_2717:
	 {
	    bool_t test2312_2718;
	    test2312_2718 = (i_2716 == ((long) -1));
	    if (test2312_2718)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2316_2719;
		    {
		       obj_t list2317_2720;
		       {
			  obj_t arg2319_2721;
			  arg2319_2721 = BNIL;
			  list2317_2720 = MAKE_PAIR(cnst_port_138_2715, arg2319_2721);
		       }
		       arg2316_2719 = read___reader(list2317_2720);
		    }
		    CNST_TABLE_SET(i_2716, arg2316_2719);
		 }
		 {
		    int aux_2722;
		    {
		       long aux_2745;
		       aux_2745 = (i_2716 - ((long) 1));
		       aux_2722 = (int) (aux_2745);
		    }
		    {
		       long i_2748;
		       i_2748 = (long) (aux_2722);
		       i_2716 = i_2748;
		       goto loop_2717;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_unit()
{
   return (_unit_list__71_ast_unit = BNIL,
      BUNSPEC);
}


/* unit-sexp*-add! */ obj_t 
unit_sexp__add__71_ast_unit(obj_t unit_19, obj_t sexp_20)
{
   {
      obj_t sexp_779;
      {
	 bool_t test1479_784;
	 {
	    bool_t test1489_793;
	    {
	       obj_t obj_2030;
	       obj_2030 = _compiler_debug__134_engine_param;
	       test1489_793 = INTEGERP(obj_2030);
	    }
	    if (test1489_793)
	      {
		 long n1_2031;
		 n1_2031 = (long) CINT(_compiler_debug__134_engine_param);
		 test1479_784 = (n1_2031 >= ((long) 3));
	      }
	    else
	      {
		 test1479_784 = ((bool_t) 0);
	      }
	 }
	 if (test1479_784)
	   {
	      obj_t arg1480_785;
	      {
		 obj_t arg1481_786;
		 obj_t arg1483_787;
		 arg1481_786 = CNST_TABLE_REF(((long) 0));
		 arg1483_787 = CNST_TABLE_REF(((long) 1));
		 {
		    obj_t list1485_789;
		    {
		       obj_t arg1486_790;
		       {
			  obj_t arg1487_791;
			  arg1487_791 = MAKE_PAIR(BNIL, BNIL);
			  arg1486_790 = MAKE_PAIR(_compiler_debug__134_engine_param, arg1487_791);
		       }
		       list1485_789 = MAKE_PAIR(arg1483_787, arg1486_790);
		    }
		    arg1480_785 = cons__138___r4_pairs_and_lists_6_3(arg1481_786, list1485_789);
		 }
	      }
	      sexp_779 = MAKE_PAIR(arg1480_785, sexp_20);
	   }
	 else
	   {
	      sexp_779 = sexp_20;
	   }
      }
      {
	 bool_t test_2762;
	 {
	    obj_t aux_2763;
	    aux_2763 = STRUCT_REF(unit_19, ((long) 2));
	    test_2762 = NULLP(aux_2763);
	 }
	 if (test_2762)
	   {
	      return STRUCT_SET(unit_19, ((long) 2), sexp_779);
	   }
	 else
	   {
	      obj_t aux_2767;
	      aux_2767 = last_pair_93___r4_pairs_and_lists_6_3(STRUCT_REF(unit_19, ((long) 2)));
	      return SET_CDR(aux_2767, sexp_779);
	   }
      }
   }
}


/* _unit-sexp*-add! */ obj_t 
_unit_sexp__add__174_ast_unit(obj_t env_2700, obj_t unit_2701, obj_t sexp_2702)
{
   return unit_sexp__add__71_ast_unit(unit_2701, sexp_2702);
}


/* unit->defs */ obj_t 
unit__defs_135_ast_unit(obj_t unit_21)
{
   {
      obj_t arg1494_796;
      {
	 obj_t arg1502_803;
	 {
	    obj_t aux_2772;
	    aux_2772 = STRUCT_REF(unit_21, ((long) 0));
	    arg1502_803 = SYMBOL_TO_STRING(aux_2772);
	 }
	 arg1494_796 = string_downcase_77___r4_strings_6_7(arg1502_803);
      }
      {
	 obj_t list1497_798;
	 {
	    obj_t arg1498_799;
	    {
	       obj_t arg1499_800;
	       {
		  obj_t arg1500_801;
		  {
		     obj_t aux_2776;
		     aux_2776 = BCHAR(((unsigned char) '\n'));
		     arg1500_801 = MAKE_PAIR(aux_2776, BNIL);
		  }
		  arg1499_800 = MAKE_PAIR(string2305_ast_unit, arg1500_801);
	       }
	       arg1498_799 = MAKE_PAIR(arg1494_796, arg1499_800);
	    }
	    list1497_798 = MAKE_PAIR(string2306_ast_unit, arg1498_799);
	 }
	 verbose_tools_speek(BINT(((long) 2)), list1497_798);
      }
   }
   {
      obj_t id_805;
      obj_t weight_806;
      obj_t sexp__30_807;
      id_805 = STRUCT_REF(unit_21, ((long) 0));
      weight_806 = STRUCT_REF(unit_21, ((long) 1));
      sexp__30_807 = STRUCT_REF(unit_21, ((long) 2));
      {
	 obj_t aexp__171_808;
	 obj_t init__202_809;
	 obj_t def__173_810;
	 {
	    obj_t arg1504_812;
	    if (PROCEDUREP(sexp__30_807))
	      {
		 arg1504_812 = PROCEDURE_ENTRY(sexp__30_807) (sexp__30_807, BEOA);
	      }
	    else
	      {
		 obj_t arg1510_816;
		 arg1510_816 = find_global_defs_64_ast_find_gdefs_13(sexp__30_807);
		 arg1504_812 = toplevel___ast_181_ast_unit(sexp__30_807, arg1510_816);
	      }
	    aexp__171_808 = arg1504_812;
	    init__202_809 = BNIL;
	    def__173_810 = BNIL;
	  loop_811:
	    if (NULLP(aexp__171_808))
	      {
		 if (PAIRP(init__202_809))
		   {
		      global_t init_819;
		      {
			 obj_t arg1516_823;
			 obj_t arg1519_826;
			 obj_t arg1522_827;
			 obj_t arg1524_828;
			 {
			    obj_t arg1525_829;
			    obj_t arg1526_830;
			    arg1525_829 = unit_initializer_id_235_ast_unit(id_805);
			    arg1526_830 = CNST_TABLE_REF(((long) 2));
			    {
			       obj_t list1527_831;
			       {
				  obj_t arg1528_832;
				  arg1528_832 = MAKE_PAIR(arg1526_830, BNIL);
				  list1527_831 = MAKE_PAIR(arg1525_829, arg1528_832);
			       }
			       arg1516_823 = symbol_append_197___r4_symbols_6_4(list1527_831);
			    }
			 }
			 arg1519_826 = CNST_TABLE_REF(((long) 3));
			 arg1522_827 = CNST_TABLE_REF(((long) 4));
			 {
			    obj_t arg1530_834;
			    arg1530_834 = reverse__39___r4_pairs_and_lists_6_3(init__202_809);
			    arg1524_828 = normalize_progn_143_tools_progn(arg1530_834);
			 }
			 init_819 = def_global_sfun__93_ast_glo_def_117(arg1516_823, BNIL, BNIL, _module__166_module_module, arg1519_826, _module_clause__117_module_module, arg1522_827, arg1524_828);
		      }
		      {
			 bool_t test1513_820;
			 {
			    obj_t arg1514_821;
			    arg1514_821 = get_toplevel_unit_32_module_include();
			    test1513_820 = (unit_21 == arg1514_821);
			 }
			 if (test1513_820)
			   {
			      BUNSPEC;
			   }
			 else
			   {
			      ((((global_t) CREF(init_819))->user__32) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			   }
		      }
		      declare_unit__164_ast_unit(id_805, (long) CINT(weight_806));
		      ((((global_t) CREF(init_819))->evaluable__248) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      {
			 obj_t arg1515_822;
			 arg1515_822 = reverse__39___r4_pairs_and_lists_6_3(def__173_810);
			 {
			    obj_t aux_2815;
			    aux_2815 = (obj_t) (init_819);
			    return MAKE_PAIR(aux_2815, arg1515_822);
			 }
		      }
		   }
		 else
		   {
		      return reverse__39___r4_pairs_and_lists_6_3(def__173_810);
		   }
	      }
	    else
	      {
		 bool_t test1531_835;
		 test1531_835 = is_a__118___object(CAR(aexp__171_808), global_ast_var);
		 if (test1531_835)
		   {
		      obj_t arg1532_836;
		      obj_t arg1533_837;
		      arg1532_836 = CDR(aexp__171_808);
		      {
			 obj_t aux_2823;
			 aux_2823 = CAR(aexp__171_808);
			 arg1533_837 = MAKE_PAIR(aux_2823, def__173_810);
		      }
		      {
			 obj_t def__173_2827;
			 obj_t aexp__171_2826;
			 aexp__171_2826 = arg1532_836;
			 def__173_2827 = arg1533_837;
			 def__173_810 = def__173_2827;
			 aexp__171_808 = aexp__171_2826;
			 goto loop_811;
		      }
		   }
		 else
		   {
		      obj_t arg1535_839;
		      obj_t arg1536_840;
		      arg1535_839 = CDR(aexp__171_808);
		      {
			 obj_t aux_2829;
			 aux_2829 = CAR(aexp__171_808);
			 arg1536_840 = MAKE_PAIR(aux_2829, init__202_809);
		      }
		      {
			 obj_t init__202_2833;
			 obj_t aexp__171_2832;
			 aexp__171_2832 = arg1535_839;
			 init__202_2833 = arg1536_840;
			 init__202_809 = init__202_2833;
			 aexp__171_808 = aexp__171_2832;
			 goto loop_811;
		      }
		   }
	      }
	 }
      }
   }
}


/* _unit->defs */ obj_t 
_unit__defs_170_ast_unit(obj_t env_2703, obj_t unit_2704)
{
   return unit__defs_135_ast_unit(unit_2704);
}


/* declare-unit! */ obj_t 
declare_unit__164_ast_unit(obj_t id_22, long weight_23)
{
   {
      bool_t test1540_843;
      {
	 bool_t test1560_861;
	 {
	    obj_t obj_2084;
	    obj_2084 = _unit_list__71_ast_unit;
	    test1560_861 = NULLP(obj_2084);
	 }
	 if (test1560_861)
	   {
	      test1540_843 = ((bool_t) 1);
	   }
	 else
	   {
	      obj_t arg1561_862;
	      {
		 obj_t arg1562_863;
		 {
		    obj_t pair_2085;
		    pair_2085 = _unit_list__71_ast_unit;
		    arg1562_863 = CAR(pair_2085);
		 }
		 arg1561_862 = CDR(arg1562_863);
	      }
	      {
		 long aux_2839;
		 aux_2839 = (long) CINT(arg1561_862);
		 test1540_843 = (weight_23 < aux_2839);
	      }
	   }
      }
      if (test1540_843)
	{
	   obj_t arg1542_844;
	   {
	      obj_t aux_2843;
	      aux_2843 = BINT(weight_23);
	      arg1542_844 = MAKE_PAIR(id_22, aux_2843);
	   }
	   {
	      obj_t obj2_2092;
	      obj2_2092 = _unit_list__71_ast_unit;
	      return (_unit_list__71_ast_unit = MAKE_PAIR(arg1542_844, obj2_2092),
		 BUNSPEC);
	   }
	}
      else
	{
	   obj_t ulist_845;
	   ulist_845 = _unit_list__71_ast_unit;
	 loop_846:
	   {
	      bool_t test_2847;
	      {
		 long aux_2848;
		 {
		    obj_t aux_2849;
		    {
		       obj_t aux_2850;
		       aux_2850 = CAR(ulist_845);
		       aux_2849 = CDR(aux_2850);
		    }
		    aux_2848 = (long) CINT(aux_2849);
		 }
		 test_2847 = (weight_23 < aux_2848);
	      }
	      if (test_2847)
		{
		   {
		      obj_t arg1545_848;
		      {
			 obj_t aux_2857;
			 obj_t aux_2855;
			 aux_2857 = CDR(ulist_845);
			 aux_2855 = CAR(ulist_845);
			 arg1545_848 = MAKE_PAIR(aux_2855, aux_2857);
		      }
		      SET_CDR(ulist_845, arg1545_848);
		   }
		   {
		      obj_t arg1550_851;
		      {
			 obj_t aux_2861;
			 aux_2861 = BINT(weight_23);
			 arg1550_851 = MAKE_PAIR(id_22, aux_2861);
		      }
		      return SET_CAR(ulist_845, arg1550_851);
		   }
		}
	      else
		{
		   bool_t test_2865;
		   {
		      obj_t aux_2866;
		      aux_2866 = CDR(ulist_845);
		      test_2865 = NULLP(aux_2866);
		   }
		   if (test_2865)
		     {
			{
			   obj_t arg1552_853;
			   {
			      obj_t arg1553_854;
			      {
				 obj_t aux_2869;
				 aux_2869 = BINT(weight_23);
				 arg1553_854 = MAKE_PAIR(id_22, aux_2869);
			      }
			      {
				 obj_t list1554_855;
				 list1554_855 = MAKE_PAIR(arg1553_854, BNIL);
				 arg1552_853 = list1554_855;
			      }
			   }
			   return SET_CDR(ulist_845, arg1552_853);
			}
		     }
		   else
		     {
			{
			   obj_t ulist_2874;
			   ulist_2874 = CDR(ulist_845);
			   ulist_845 = ulist_2874;
			   goto loop_846;
			}
		     }
		}
	   }
	}
   }
}


/* unit-initializer-id */ obj_t 
unit_initializer_id_235_ast_unit(obj_t id_24)
{
   {
      obj_t list1564_865;
      {
	 obj_t arg1565_866;
	 {
	    obj_t aux_2876;
	    aux_2876 = CNST_TABLE_REF(((long) 5));
	    arg1565_866 = MAKE_PAIR(aux_2876, BNIL);
	 }
	 list1564_865 = MAKE_PAIR(id_24, arg1565_866);
      }
      return symbol_append_197___r4_symbols_6_4(list1564_865);
   }
}


/* _unit-initializer-id */ obj_t 
_unit_initializer_id_32_ast_unit(obj_t env_2705, obj_t id_2706)
{
   return unit_initializer_id_235_ast_unit(id_2706);
}


/* unit-initializers */ obj_t 
unit_initializers_25_ast_unit()
{
   {
      obj_t l1443_868;
      l1443_868 = _unit_list__71_ast_unit;
      if (NULLP(l1443_868))
	{
	   return BNIL;
	}
      else
	{
	   obj_t head1445_870;
	   head1445_870 = MAKE_PAIR(BNIL, BNIL);
	   {
	      obj_t l1443_871;
	      obj_t tail1446_872;
	      l1443_871 = l1443_868;
	      tail1446_872 = head1445_870;
	    lname1444_873:
	      if (NULLP(l1443_871))
		{
		   return CDR(head1445_870);
		}
	      else
		{
		   obj_t newtail1447_875;
		   {
		      obj_t arg1570_877;
		      {
			 obj_t arg1573_880;
			 {
			    obj_t aux_2888;
			    {
			       obj_t aux_2889;
			       aux_2889 = CAR(l1443_871);
			       aux_2888 = CAR(aux_2889);
			    }
			    arg1573_880 = unit_initializer_id_235_ast_unit(aux_2888);
			 }
			 {
			    obj_t list1574_881;
			    list1574_881 = MAKE_PAIR(_module__166_module_module, BNIL);
			    arg1570_877 = find_global_223_ast_env(arg1573_880, list1574_881);
			 }
		      }
		      newtail1447_875 = MAKE_PAIR(arg1570_877, BNIL);
		   }
		   SET_CDR(tail1446_872, newtail1447_875);
		   {
		      obj_t tail1446_2899;
		      obj_t l1443_2897;
		      l1443_2897 = CDR(l1443_871);
		      tail1446_2899 = newtail1447_875;
		      tail1446_872 = tail1446_2899;
		      l1443_871 = l1443_2897;
		      goto lname1444_873;
		   }
		}
	   }
	}
   }
}


/* _unit-initializers */ obj_t 
_unit_initializers_20_ast_unit(obj_t env_2707)
{
   return unit_initializers_25_ast_unit();
}


/* unit-init-calls */ obj_t 
unit_init_calls_56_ast_unit()
{
   {
      obj_t l1448_886;
      l1448_886 = _unit_list__71_ast_unit;
      if (NULLP(l1448_886))
	{
	   return BNIL;
	}
      else
	{
	   obj_t head1450_888;
	   head1450_888 = MAKE_PAIR(BNIL, BNIL);
	   {
	      obj_t l1448_889;
	      obj_t tail1451_890;
	      l1448_889 = l1448_886;
	      tail1451_890 = head1450_888;
	    lname1449_891:
	      if (NULLP(l1448_889))
		{
		   return CDR(head1450_888);
		}
	      else
		{
		   obj_t newtail1452_893;
		   {
		      obj_t arg1585_895;
		      {
			 obj_t arg1587_898;
			 {
			    obj_t arg1593_902;
			    obj_t arg1594_903;
			    arg1593_902 = CNST_TABLE_REF(((long) 6));
			    {
			       obj_t aux_2908;
			       {
				  obj_t aux_2909;
				  aux_2909 = CAR(l1448_889);
				  aux_2908 = CAR(aux_2909);
			       }
			       arg1594_903 = unit_initializer_id_235_ast_unit(aux_2908);
			    }
			    {
			       obj_t list1596_905;
			       {
				  obj_t arg1598_906;
				  {
				     obj_t arg1600_907;
				     arg1600_907 = MAKE_PAIR(BNIL, BNIL);
				     arg1598_906 = MAKE_PAIR(_module__166_module_module, arg1600_907);
				  }
				  list1596_905 = MAKE_PAIR(arg1594_903, arg1598_906);
			       }
			       arg1587_898 = cons__138___r4_pairs_and_lists_6_3(arg1593_902, list1596_905);
			    }
			 }
			 {
			    obj_t list1589_900;
			    list1589_900 = MAKE_PAIR(BNIL, BNIL);
			    arg1585_895 = cons__138___r4_pairs_and_lists_6_3(arg1587_898, list1589_900);
			 }
		      }
		      newtail1452_893 = MAKE_PAIR(arg1585_895, BNIL);
		   }
		   SET_CDR(tail1451_890, newtail1452_893);
		   {
		      obj_t tail1451_2923;
		      obj_t l1448_2921;
		      l1448_2921 = CDR(l1448_889);
		      tail1451_2923 = newtail1452_893;
		      tail1451_890 = tail1451_2923;
		      l1448_889 = l1448_2921;
		      goto lname1449_891;
		   }
		}
	   }
	}
   }
}


/* _unit-init-calls */ obj_t 
_unit_init_calls_204_ast_unit(obj_t env_2708)
{
   return unit_init_calls_56_ast_unit();
}


/* toplevel*->ast */ obj_t 
toplevel___ast_181_ast_unit(obj_t sexp__30_25, obj_t gdefs_26)
{
   {
      obj_t sexp__30_912;
      obj_t aexp__171_913;
      sexp__30_912 = sexp__30_25;
      aexp__171_913 = BNIL;
    loop_914:
      if (NULLP(sexp__30_912))
	{
	   return reverse__39___r4_pairs_and_lists_6_3(aexp__171_913);
	}
      else
	{
	   obj_t arg1609_917;
	   obj_t arg1610_918;
	   arg1609_917 = CDR(sexp__30_912);
	   {
	      obj_t arg1612_919;
	      arg1612_919 = toplevel__ast_219_ast_unit(CAR(sexp__30_912), gdefs_26);
	      arg1610_918 = append_2_18___r4_pairs_and_lists_6_3(arg1612_919, aexp__171_913);
	   }
	   {
	      obj_t aexp__171_2933;
	      obj_t sexp__30_2932;
	      sexp__30_2932 = arg1609_917;
	      aexp__171_2933 = arg1610_918;
	      aexp__171_913 = aexp__171_2933;
	      sexp__30_912 = sexp__30_2932;
	      goto loop_914;
	   }
	}
   }
}


/* toplevel->ast */ obj_t 
toplevel__ast_219_ast_unit(obj_t sexp_27, obj_t gdefs_28)
{
 toplevel__ast_219_ast_unit:
   {
      obj_t var_937;
      obj_t var2_938;
      obj_t module_939;
      obj_t var_934;
      obj_t var2_935;
      obj_t var_927;
      obj_t args_928;
      obj_t exp_929;
      obj_t var_923;
      obj_t args_924;
      obj_t exp_925;
      if (PAIRP(sexp_27))
	{
	   bool_t test_2936;
	   {
	      obj_t aux_2939;
	      obj_t aux_2937;
	      aux_2939 = CNST_TABLE_REF(((long) 10));
	      aux_2937 = CAR(sexp_27);
	      test_2936 = (aux_2937 == aux_2939);
	   }
	   if (test_2936)
	     {
		obj_t arg1835_2148;
		arg1835_2148 = toplevel___ast_181_ast_unit(CDR(sexp_27), gdefs_28);
		return reverse__39___r4_pairs_and_lists_6_3(arg1835_2148);
	     }
	   else
	     {
		obj_t cdr_155_78_971;
		cdr_155_78_971 = CDR(sexp_27);
		{
		   bool_t test_2946;
		   {
		      obj_t aux_2949;
		      obj_t aux_2947;
		      aux_2949 = CNST_TABLE_REF(((long) 11));
		      aux_2947 = CAR(sexp_27);
		      test_2946 = (aux_2947 == aux_2949);
		   }
		   if (test_2946)
		     {
			if (PAIRP(cdr_155_78_971))
			  {
			     obj_t car_159_8_974;
			     car_159_8_974 = CAR(cdr_155_78_971);
			     if (PAIRP(car_159_8_974))
			       {
				  var_923 = CAR(car_159_8_974);
				  args_924 = CDR(car_159_8_974);
				  exp_925 = CDR(cdr_155_78_971);
				  {
				     obj_t id_1240;
				     id_1240 = id_of_id_112_ast_ident(var_923);
				     {
					obj_t def_1241;
					def_1241 = assq___r4_pairs_and_lists_6_3(id_1240, gdefs_28);
					{
					   obj_t global_1242;
					   {
					      obj_t list1868_1271;
					      list1868_1271 = MAKE_PAIR(_module__166_module_module, BNIL);
					      global_1242 = find_global_223_ast_env(id_1240, list1868_1271);
					   }
					   {
					      {
						 bool_t test1836_1243;
						 if (PAIRP(def_1241))
						   {
						      bool_t test_2963;
						      {
							 obj_t aux_2968;
							 obj_t aux_2964;
							 aux_2968 = CNST_TABLE_REF(((long) 7));
							 {
							    obj_t aux_2965;
							    aux_2965 = CDR(def_1241);
							    aux_2964 = CAR(aux_2965);
							 }
							 test_2963 = (aux_2964 == aux_2968);
						      }
						      if (test_2963)
							{
							   bool_t _ortest_1454_1264;
							   {
							      bool_t test1864_1267;
							      test1864_1267 = is_a__118___object(global_1242, global_ast_var);
							      if (test1864_1267)
								{
								   _ortest_1454_1264 = ((bool_t) 0);
								}
							      else
								{
								   _ortest_1454_1264 = ((bool_t) 1);
								}
							   }
							   if (_ortest_1454_1264)
							     {
								test1836_1243 = _ortest_1454_1264;
							     }
							   else
							     {
								obj_t aux_2977;
								obj_t aux_2974;
								aux_2977 = CNST_TABLE_REF(((long) 7));
								{
								   global_t obj_2523;
								   obj_2523 = (global_t) (global_1242);
								   aux_2974 = (((global_t) CREF(obj_2523))->access);
								}
								test1836_1243 = (aux_2974 == aux_2977);
							     }
							}
						      else
							{
							   test1836_1243 = ((bool_t) 0);
							}
						   }
						 else
						   {
						      test1836_1243 = ((bool_t) 1);
						   }
						 if (test1836_1243)
						   {
						      obj_t arg1837_1244;
						      obj_t arg1838_1245;
						      arg1837_1244 = normalize_progn_error_20_ast_unit(exp_925, sexp_27);
						      arg1838_1245 = CNST_TABLE_REF(((long) 8));
						      return make_sfun_definition_61_ast_unit(var_923, _module__166_module_module, args_924, arg1837_1244, sexp_27, arg1838_1245);
						   }
						 else
						   {
						      obj_t new_sexp_159_1246;
						      {
							 obj_t arg1839_1247;
							 obj_t arg1842_1248;
							 arg1839_1247 = CNST_TABLE_REF(((long) 0));
							 {
							    obj_t arg1851_1254;
							    obj_t arg1852_1255;
							    arg1851_1254 = CNST_TABLE_REF(((long) 9));
							    {
							       obj_t arg1858_1259;
							       arg1858_1259 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							       arg1852_1255 = append_2_18___r4_pairs_and_lists_6_3(exp_925, arg1858_1259);
							    }
							    {
							       obj_t list1853_1256;
							       {
								  obj_t arg1856_1257;
								  arg1856_1257 = MAKE_PAIR(arg1852_1255, BNIL);
								  list1853_1256 = MAKE_PAIR(args_924, arg1856_1257);
							       }
							       arg1842_1248 = cons__138___r4_pairs_and_lists_6_3(arg1851_1254, list1853_1256);
							    }
							 }
							 {
							    obj_t list1844_1250;
							    {
							       obj_t arg1847_1251;
							       {
								  obj_t arg1848_1252;
								  arg1848_1252 = MAKE_PAIR(BNIL, BNIL);
								  arg1847_1251 = MAKE_PAIR(arg1842_1248, arg1848_1252);
							       }
							       list1844_1250 = MAKE_PAIR(var_923, arg1847_1251);
							    }
							    new_sexp_159_1246 = cons__138___r4_pairs_and_lists_6_3(arg1839_1247, list1844_1250);
							 }
						      }
						      replace__160_tools_misc(sexp_27, new_sexp_159_1246);
						      return make_svar_definition_154_ast_unit(var_923, sexp_27);
						   }
					      }
					   }
					}
				     }
				  }
			       }
			     else
			       {
				  obj_t cdr_183_92_980;
				  cdr_183_92_980 = CDR(cdr_155_78_971);
				  if (PAIRP(cdr_183_92_980))
				    {
				       obj_t car_187_173_982;
				       car_187_173_982 = CAR(cdr_183_92_980);
				       if (PAIRP(car_187_173_982))
					 {
					    obj_t cdr_192_117_984;
					    cdr_192_117_984 = CDR(car_187_173_982);
					    {
					       bool_t test_3007;
					       {
						  obj_t aux_3010;
						  obj_t aux_3008;
						  aux_3010 = CNST_TABLE_REF(((long) 9));
						  aux_3008 = CAR(car_187_173_982);
						  test_3007 = (aux_3008 == aux_3010);
					       }
					       if (test_3007)
						 {
						    if (PAIRP(cdr_192_117_984))
						      {
							 bool_t test_3015;
							 {
							    obj_t aux_3016;
							    aux_3016 = CDR(cdr_183_92_980);
							    test_3015 = (aux_3016 == BNIL);
							 }
							 if (test_3015)
							   {
							      var_927 = CAR(cdr_155_78_971);
							      args_928 = CAR(cdr_192_117_984);
							      exp_929 = CDR(cdr_192_117_984);
							      {
								 obj_t id_1273;
								 id_1273 = id_of_id_112_ast_ident(var_927);
								 {
								    obj_t def_1274;
								    def_1274 = assq___r4_pairs_and_lists_6_3(id_1273, gdefs_28);
								    {
								       obj_t global_1275;
								       {
									  obj_t list1882_1287;
									  list1882_1287 = MAKE_PAIR(_module__166_module_module, BNIL);
									  global_1275 = find_global_223_ast_env(id_1273, list1882_1287);
								       }
								       {
									  {
									     bool_t test1870_1276;
									     {
										bool_t test_3023;
										{
										   obj_t aux_3028;
										   obj_t aux_3024;
										   aux_3028 = CNST_TABLE_REF(((long) 7));
										   {
										      obj_t aux_3025;
										      aux_3025 = CDR(def_1274);
										      aux_3024 = CAR(aux_3025);
										   }
										   test_3023 = (aux_3024 == aux_3028);
										}
										if (test_3023)
										  {
										     bool_t _ortest_1455_1280;
										     {
											bool_t test1878_1283;
											test1878_1283 = is_a__118___object(global_1275, global_ast_var);
											if (test1878_1283)
											  {
											     _ortest_1455_1280 = ((bool_t) 0);
											  }
											else
											  {
											     _ortest_1455_1280 = ((bool_t) 1);
											  }
										     }
										     if (_ortest_1455_1280)
										       {
											  test1870_1276 = _ortest_1455_1280;
										       }
										     else
										       {
											  obj_t aux_3037;
											  obj_t aux_3034;
											  aux_3037 = CNST_TABLE_REF(((long) 7));
											  {
											     global_t obj_2531;
											     obj_2531 = (global_t) (global_1275);
											     aux_3034 = (((global_t) CREF(obj_2531))->access);
											  }
											  test1870_1276 = (aux_3034 == aux_3037);
										       }
										  }
										else
										  {
										     test1870_1276 = ((bool_t) 0);
										  }
									     }
									     if (test1870_1276)
									       {
										  obj_t arg1871_1277;
										  obj_t arg1874_1278;
										  arg1871_1277 = normalize_progn_error_20_ast_unit(exp_929, sexp_27);
										  arg1874_1278 = CNST_TABLE_REF(((long) 8));
										  return make_sfun_definition_61_ast_unit(var_927, _module__166_module_module, args_928, arg1871_1277, sexp_27, arg1874_1278);
									       }
									     else
									       {
										  return make_svar_definition_154_ast_unit(var_927, sexp_27);
									       }
									  }
								       }
								    }
								 }
							      }
							   }
							 else
							   {
							      return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
							   }
						      }
						    else
						      {
							 obj_t cdr_265_143_997;
							 cdr_265_143_997 = CDR(cdr_155_78_971);
							 {
							    obj_t car_269_91_998;
							    car_269_91_998 = CAR(cdr_265_143_997);
							    if (SYMBOLP(car_269_91_998))
							      {
								 bool_t test_3054;
								 {
								    obj_t aux_3055;
								    aux_3055 = CDR(cdr_265_143_997);
								    test_3054 = (aux_3055 == BNIL);
								 }
								 if (test_3054)
								   {
								      var_934 = CAR(cdr_155_78_971);
								      var2_935 = car_269_91_998;
								    tag_124_21_936:
								      {
									 obj_t def_1290;
									 {
									    obj_t arg1892_1298;
									    arg1892_1298 = id_of_id_112_ast_ident(var_934);
									    def_1290 = assq___r4_pairs_and_lists_6_3(arg1892_1298, gdefs_28);
									 }
									 {
									    bool_t test_3060;
									    {
									       obj_t aux_3065;
									       obj_t aux_3061;
									       aux_3065 = CNST_TABLE_REF(((long) 7));
									       {
										  obj_t aux_3062;
										  aux_3062 = CDR(def_1290);
										  aux_3061 = CAR(aux_3062);
									       }
									       test_3060 = (aux_3061 == aux_3065);
									    }
									    if (test_3060)
									      {
										 obj_t arity_1292;
										 arity_1292 = get_global_arity_252_ast_unit(var2_935, BFALSE, gdefs_28);
										 if (INTEGERP(arity_1292))
										   {
										      obj_t def_1294;
										      def_1294 = eta_expanse_111_ast_unit(sexp_27, arity_1292);
										      {
											 obj_t sexp_3072;
											 sexp_3072 = def_1294;
											 sexp_27 = sexp_3072;
											 goto toplevel__ast_219_ast_unit;
										      }
										   }
										 else
										   {
										      return make_svar_definition_154_ast_unit(var_934, sexp_27);
										   }
									      }
									    else
									      {
										 return make_svar_definition_154_ast_unit(var_934, sexp_27);
									      }
									 }
								      }
								   }
								 else
								   {
								      return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
								   }
							      }
							    else
							      {
								 return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
							      }
							 }
						      }
						 }
					       else
						 {
						    obj_t cdr_341_125_1011;
						    cdr_341_125_1011 = CDR(cdr_155_78_971);
						    {
						       obj_t car_345_114_1012;
						       car_345_114_1012 = CAR(cdr_341_125_1011);
						       {
							  obj_t cdr_349_110_1013;
							  cdr_349_110_1013 = CDR(car_345_114_1012);
							  {
							     bool_t test_3083;
							     {
								obj_t aux_3086;
								obj_t aux_3084;
								aux_3086 = CNST_TABLE_REF(((long) 10));
								aux_3084 = CAR(car_345_114_1012);
								test_3083 = (aux_3084 == aux_3086);
							     }
							     if (test_3083)
							       {
								  if (PAIRP(cdr_349_110_1013))
								    {
								       bool_t test_3091;
								       {
									  obj_t aux_3092;
									  aux_3092 = CDR(cdr_349_110_1013);
									  test_3091 = (aux_3092 == BNIL);
								       }
								       if (test_3091)
									 {
									    bool_t test_3095;
									    {
									       obj_t aux_3096;
									       aux_3096 = CDR(cdr_341_125_1011);
									       test_3095 = (aux_3096 == BNIL);
									    }
									    if (test_3095)
									      {
										 {
										    obj_t aux_3101;
										    obj_t aux_3099;
										    aux_3101 = CAR(cdr_349_110_1013);
										    aux_3099 = CDR(cdr_155_78_971);
										    SET_CAR(aux_3099, aux_3101);
										 }
										 {
										    goto toplevel__ast_219_ast_unit;
										 }
									      }
									    else
									      {
										 return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
									      }
									 }
								       else
									 {
									    obj_t cdr_402_67_1026;
									    cdr_402_67_1026 = CDR(cdr_155_78_971);
									    {
									       obj_t car_406_252_1027;
									       car_406_252_1027 = CAR(cdr_402_67_1026);
									       if (SYMBOLP(car_406_252_1027))
										 {
										    bool_t test_3110;
										    {
										       obj_t aux_3111;
										       aux_3111 = CDR(cdr_402_67_1026);
										       test_3110 = (aux_3111 == BNIL);
										    }
										    if (test_3110)
										      {
											 obj_t var2_3116;
											 obj_t var_3114;
											 var_3114 = CAR(cdr_155_78_971);
											 var2_3116 = car_406_252_1027;
											 var2_935 = var2_3116;
											 var_934 = var_3114;
											 goto tag_124_21_936;
										      }
										    else
										      {
											 return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
										      }
										 }
									       else
										 {
										    return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
										 }
									    }
									 }
								    }
								  else
								    {
								       obj_t cdr_477_100_1042;
								       cdr_477_100_1042 = CDR(cdr_155_78_971);
								       {
									  obj_t car_481_225_1043;
									  car_481_225_1043 = CAR(cdr_477_100_1042);
									  if (SYMBOLP(car_481_225_1043))
									    {
									       bool_t test_3125;
									       {
										  obj_t aux_3126;
										  aux_3126 = CDR(cdr_477_100_1042);
										  test_3125 = (aux_3126 == BNIL);
									       }
									       if (test_3125)
										 {
										    obj_t var2_3131;
										    obj_t var_3129;
										    var_3129 = CAR(cdr_155_78_971);
										    var2_3131 = car_481_225_1043;
										    var2_935 = var2_3131;
										    var_934 = var_3129;
										    goto tag_124_21_936;
										 }
									       else
										 {
										    return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
										 }
									    }
									  else
									    {
									       return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
									    }
								       }
								    }
							       }
							     else
							       {
								  obj_t cdr_552_174_1056;
								  cdr_552_174_1056 = CDR(cdr_155_78_971);
								  {
								     obj_t car_556_168_1057;
								     car_556_168_1057 = CAR(cdr_552_174_1056);
								     if (SYMBOLP(car_556_168_1057))
								       {
									  bool_t test_3140;
									  {
									     obj_t aux_3141;
									     aux_3141 = CDR(cdr_552_174_1056);
									     test_3140 = (aux_3141 == BNIL);
									  }
									  if (test_3140)
									    {
									       obj_t var2_3146;
									       obj_t var_3144;
									       var_3144 = CAR(cdr_155_78_971);
									       var2_3146 = car_556_168_1057;
									       var2_935 = var2_3146;
									       var_934 = var_3144;
									       goto tag_124_21_936;
									    }
									  else
									    {
									       return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
									    }
								       }
								     else
								       {
									  obj_t cdr_603_240_1067;
									  cdr_603_240_1067 = CDR(cdr_155_78_971);
									  {
									     obj_t car_608_29_1068;
									     car_608_29_1068 = CAR(cdr_603_240_1067);
									     {
										obj_t cdr_613_171_1069;
										cdr_613_171_1069 = CDR(car_608_29_1068);
										{
										   bool_t test_3152;
										   {
										      obj_t aux_3155;
										      obj_t aux_3153;
										      aux_3155 = CNST_TABLE_REF(((long) 6));
										      aux_3153 = CAR(car_608_29_1068);
										      test_3152 = (aux_3153 == aux_3155);
										   }
										   if (test_3152)
										     {
											if (PAIRP(cdr_613_171_1069))
											  {
											     obj_t car_616_229_1072;
											     obj_t cdr_617_239_1073;
											     car_616_229_1072 = CAR(cdr_613_171_1069);
											     cdr_617_239_1073 = CDR(cdr_613_171_1069);
											     if (SYMBOLP(car_616_229_1072))
											       {
												  if (PAIRP(cdr_617_239_1073))
												    {
												       obj_t car_622_221_1076;
												       car_622_221_1076 = CAR(cdr_617_239_1073);
												       if (SYMBOLP(car_622_221_1076))
													 {
													    bool_t test_3169;
													    {
													       obj_t aux_3170;
													       aux_3170 = CDR(cdr_617_239_1073);
													       test_3169 = (aux_3170 == BNIL);
													    }
													    if (test_3169)
													      {
														 bool_t test_3173;
														 {
														    obj_t aux_3174;
														    aux_3174 = CDR(cdr_603_240_1067);
														    test_3173 = (aux_3174 == BNIL);
														 }
														 if (test_3173)
														   {
														      var_937 = CAR(cdr_155_78_971);
														      var2_938 = car_616_229_1072;
														      module_939 = car_622_221_1076;
														      {
															 obj_t def_1299;
															 {
															    obj_t arg1898_1307;
															    arg1898_1307 = id_of_id_112_ast_ident(var_937);
															    def_1299 = assq___r4_pairs_and_lists_6_3(arg1898_1307, gdefs_28);
															 }
															 {
															    bool_t test_3179;
															    {
															       obj_t aux_3184;
															       obj_t aux_3180;
															       aux_3184 = CNST_TABLE_REF(((long) 7));
															       {
																  obj_t aux_3181;
																  aux_3181 = CDR(def_1299);
																  aux_3180 = CAR(aux_3181);
															       }
															       test_3179 = (aux_3180 == aux_3184);
															    }
															    if (test_3179)
															      {
																 obj_t arity_1301;
																 arity_1301 = get_global_arity_252_ast_unit(var2_938, module_939, gdefs_28);
																 if (INTEGERP(arity_1301))
																   {
																      obj_t def_1303;
																      def_1303 = eta_expanse_111_ast_unit(sexp_27, arity_1301);
																      {
																	 obj_t sexp_3191;
																	 sexp_3191 = def_1303;
																	 sexp_27 = sexp_3191;
																	 goto toplevel__ast_219_ast_unit;
																      }
																   }
																 else
																   {
																      return make_svar_definition_154_ast_unit(var_937, sexp_27);
																   }
															      }
															    else
															      {
																 return make_svar_definition_154_ast_unit(var_937, sexp_27);
															      }
															 }
														      }
														   }
														 else
														   {
														      return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
														   }
													      }
													    else
													      {
														 return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
													      }
													 }
												       else
													 {
													    return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
													 }
												    }
												  else
												    {
												       return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
												    }
											       }
											     else
											       {
												  return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
											       }
											  }
											else
											  {
											     return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
											  }
										     }
										   else
										     {
											return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
										     }
										}
									     }
									  }
								       }
								  }
							       }
							  }
						       }
						    }
						 }
					    }
					 }
				       else
					 {
					    obj_t cdr_769_143_1113;
					    cdr_769_143_1113 = CDR(cdr_155_78_971);
					    {
					       obj_t car_773_37_1114;
					       car_773_37_1114 = CAR(cdr_769_143_1113);
					       if (SYMBOLP(car_773_37_1114))
						 {
						    bool_t test_3213;
						    {
						       obj_t aux_3214;
						       aux_3214 = CDR(cdr_769_143_1113);
						       test_3213 = (aux_3214 == BNIL);
						    }
						    if (test_3213)
						      {
							 obj_t var2_3219;
							 obj_t var_3217;
							 var_3217 = CAR(cdr_155_78_971);
							 var2_3219 = car_773_37_1114;
							 var2_935 = var2_3219;
							 var_934 = var_3217;
							 goto tag_124_21_936;
						      }
						    else
						      {
							 return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
						      }
						 }
					       else
						 {
						    return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
						 }
					    }
					 }
				    }
				  else
				    {
				       return make_svar_definition_154_ast_unit(CAR(cdr_155_78_971), sexp_27);
				    }
			       }
			  }
			else
			  {
			   tag_132_226_966:
			     {
				obj_t list1904_1313;
				list1904_1313 = MAKE_PAIR(sexp_27, BNIL);
				return list1904_1313;
			     }
			  }
		     }
		   else
		     {
			bool_t test_3227;
			{
			   obj_t aux_3230;
			   obj_t aux_3228;
			   aux_3230 = CNST_TABLE_REF(((long) 12));
			   aux_3228 = CAR(sexp_27);
			   test_3227 = (aux_3228 == aux_3230);
			}
			if (test_3227)
			  {
			     if (PAIRP(cdr_155_78_971))
			       {
				  obj_t car_998_185_1132;
				  car_998_185_1132 = CAR(cdr_155_78_971);
				  if (PAIRP(car_998_185_1132))
				    {
				       obj_t car_1003_57_1134;
				       car_1003_57_1134 = CAR(car_998_185_1132);
				       if (PAIRP(car_1003_57_1134))
					 {
					    obj_t cdr_1008_223_1136;
					    cdr_1008_223_1136 = CDR(car_1003_57_1134);
					    {
					       bool_t test_3242;
					       {
						  obj_t aux_3245;
						  obj_t aux_3243;
						  aux_3245 = CNST_TABLE_REF(((long) 6));
						  aux_3243 = CAR(car_1003_57_1134);
						  test_3242 = (aux_3243 == aux_3245);
					       }
					       if (test_3242)
						 {
						    if (PAIRP(cdr_1008_223_1136))
						      {
							 obj_t cdr_1012_92_1139;
							 cdr_1012_92_1139 = CDR(cdr_1008_223_1136);
							 if (PAIRP(cdr_1012_92_1139))
							   {
							      bool_t test_3253;
							      {
								 obj_t aux_3254;
								 aux_3254 = CDR(cdr_1012_92_1139);
								 test_3253 = (aux_3254 == BNIL);
							      }
							      if (test_3253)
								{
								   obj_t arg1755_1142;
								   obj_t arg1758_1143;
								   obj_t arg1759_1144;
								   arg1755_1142 = CAR(cdr_1008_223_1136);
								   arg1758_1143 = CAR(cdr_1012_92_1139);
								   arg1759_1144 = CDR(car_998_185_1132);
								   {
								      obj_t arg1899_2383;
								      obj_t arg1900_2384;
								      arg1899_2383 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
								      arg1900_2384 = CNST_TABLE_REF(((long) 13));
								      return make_sfun_definition_61_ast_unit(arg1755_1142, arg1758_1143, arg1759_1144, arg1899_2383, sexp_27, arg1900_2384);
								   }
								}
							      else
								{
								   obj_t car_1032_68_1147;
								   car_1032_68_1147 = CAR(cdr_155_78_971);
								   {
								      obj_t arg1761_1148;
								      obj_t arg1762_1149;
								      arg1761_1148 = CAR(car_1032_68_1147);
								      arg1762_1149 = CDR(car_1032_68_1147);
								      {
									 obj_t arg1901_2393;
									 obj_t arg1902_2394;
									 arg1901_2393 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
									 arg1902_2394 = CNST_TABLE_REF(((long) 13));
									 return make_sfun_definition_61_ast_unit(arg1761_1148, _module__166_module_module, arg1762_1149, arg1901_2393, sexp_27, arg1902_2394);
								      }
								   }
								}
							   }
							 else
							   {
							      obj_t car_1053_234_1154;
							      car_1053_234_1154 = CAR(cdr_155_78_971);
							      {
								 obj_t arg1768_1155;
								 obj_t arg1769_1156;
								 arg1768_1155 = CAR(car_1053_234_1154);
								 arg1769_1156 = CDR(car_1053_234_1154);
								 {
								    obj_t arg1901_2403;
								    obj_t arg1902_2404;
								    arg1901_2403 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
								    arg1902_2404 = CNST_TABLE_REF(((long) 13));
								    return make_sfun_definition_61_ast_unit(arg1768_1155, _module__166_module_module, arg1769_1156, arg1901_2403, sexp_27, arg1902_2404);
								 }
							      }
							   }
						      }
						    else
						      {
							 obj_t car_1074_91_1159;
							 car_1074_91_1159 = CAR(cdr_155_78_971);
							 {
							    obj_t arg1771_1160;
							    obj_t arg1772_1161;
							    arg1771_1160 = CAR(car_1074_91_1159);
							    arg1772_1161 = CDR(car_1074_91_1159);
							    {
							       obj_t arg1901_2413;
							       obj_t arg1902_2414;
							       arg1901_2413 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
							       arg1902_2414 = CNST_TABLE_REF(((long) 13));
							       return make_sfun_definition_61_ast_unit(arg1771_1160, _module__166_module_module, arg1772_1161, arg1901_2413, sexp_27, arg1902_2414);
							    }
							 }
						      }
						 }
					       else
						 {
						    obj_t car_1095_7_1164;
						    car_1095_7_1164 = CAR(cdr_155_78_971);
						    {
						       obj_t arg1774_1165;
						       obj_t arg1776_1166;
						       arg1774_1165 = CAR(car_1095_7_1164);
						       arg1776_1166 = CDR(car_1095_7_1164);
						       {
							  obj_t arg1901_2423;
							  obj_t arg1902_2424;
							  arg1901_2423 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
							  arg1902_2424 = CNST_TABLE_REF(((long) 13));
							  return make_sfun_definition_61_ast_unit(arg1774_1165, _module__166_module_module, arg1776_1166, arg1901_2423, sexp_27, arg1902_2424);
						       }
						    }
						 }
					    }
					 }
				       else
					 {
					    obj_t car_1116_227_1171;
					    car_1116_227_1171 = CAR(cdr_155_78_971);
					    {
					       obj_t arg1780_1172;
					       obj_t arg1781_1173;
					       arg1780_1172 = CAR(car_1116_227_1171);
					       arg1781_1173 = CDR(car_1116_227_1171);
					       {
						  obj_t arg1901_2433;
						  obj_t arg1902_2434;
						  arg1901_2433 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
						  arg1902_2434 = CNST_TABLE_REF(((long) 13));
						  return make_sfun_definition_61_ast_unit(arg1780_1172, _module__166_module_module, arg1781_1173, arg1901_2433, sexp_27, arg1902_2434);
					       }
					    }
					 }
				    }
				  else
				    {
				       goto tag_132_226_966;
				    }
			       }
			     else
			       {
				  goto tag_132_226_966;
			       }
			  }
			else
			  {
			     bool_t test_3299;
			     {
				obj_t aux_3302;
				obj_t aux_3300;
				aux_3302 = CNST_TABLE_REF(((long) 14));
				aux_3300 = CAR(sexp_27);
				test_3299 = (aux_3300 == aux_3302);
			     }
			     if (test_3299)
			       {
				  if (PAIRP(cdr_155_78_971))
				    {
				       obj_t car_1200_96_1178;
				       car_1200_96_1178 = CAR(cdr_155_78_971);
				       if (PAIRP(car_1200_96_1178))
					 {
					    obj_t car_1205_114_1180;
					    car_1205_114_1180 = CAR(car_1200_96_1178);
					    if (PAIRP(car_1205_114_1180))
					      {
						 obj_t cdr_1210_110_1182;
						 cdr_1210_110_1182 = CDR(car_1205_114_1180);
						 {
						    bool_t test_3314;
						    {
						       obj_t aux_3317;
						       obj_t aux_3315;
						       aux_3317 = CNST_TABLE_REF(((long) 6));
						       aux_3315 = CAR(car_1205_114_1180);
						       test_3314 = (aux_3315 == aux_3317);
						    }
						    if (test_3314)
						      {
							 if (PAIRP(cdr_1210_110_1182))
							   {
							      obj_t cdr_1214_132_1185;
							      cdr_1214_132_1185 = CDR(cdr_1210_110_1182);
							      if (PAIRP(cdr_1214_132_1185))
								{
								   bool_t test_3325;
								   {
								      obj_t aux_3326;
								      aux_3326 = CDR(cdr_1214_132_1185);
								      test_3325 = (aux_3326 == BNIL);
								   }
								   if (test_3325)
								     {
									return make_sgfun_definition_102_ast_unit(CAR(cdr_1210_110_1182), CAR(cdr_1214_132_1185), CDR(car_1200_96_1178), CDR(cdr_155_78_971), sexp_27, gdefs_28);
								     }
								   else
								     {
									obj_t car_1233_213_1193;
									car_1233_213_1193 = CAR(cdr_155_78_971);
									return make_sgfun_definition_102_ast_unit(CAR(car_1233_213_1193), _module__166_module_module, CDR(car_1233_213_1193), CDR(cdr_155_78_971), sexp_27, gdefs_28);
								     }
								}
							      else
								{
								   obj_t car_1253_248_1200;
								   car_1253_248_1200 = CAR(cdr_155_78_971);
								   return make_sgfun_definition_102_ast_unit(CAR(car_1253_248_1200), _module__166_module_module, CDR(car_1253_248_1200), CDR(cdr_155_78_971), sexp_27, gdefs_28);
								}
							   }
							 else
							   {
							      obj_t car_1273_172_1205;
							      car_1273_172_1205 = CAR(cdr_155_78_971);
							      return make_sgfun_definition_102_ast_unit(CAR(car_1273_172_1205), _module__166_module_module, CDR(car_1273_172_1205), CDR(cdr_155_78_971), sexp_27, gdefs_28);
							   }
						      }
						    else
						      {
							 obj_t car_1293_155_1210;
							 car_1293_155_1210 = CAR(cdr_155_78_971);
							 return make_sgfun_definition_102_ast_unit(CAR(car_1293_155_1210), _module__166_module_module, CDR(car_1293_155_1210), CDR(cdr_155_78_971), sexp_27, gdefs_28);
						      }
						 }
					      }
					    else
					      {
						 obj_t car_1313_238_1217;
						 car_1313_238_1217 = CAR(cdr_155_78_971);
						 return make_sgfun_definition_102_ast_unit(CAR(car_1313_238_1217), _module__166_module_module, CDR(car_1313_238_1217), CDR(cdr_155_78_971), sexp_27, gdefs_28);
					      }
					 }
				       else
					 {
					    goto tag_132_226_966;
					 }
				    }
				  else
				    {
				       goto tag_132_226_966;
				    }
			       }
			     else
			       {
				  bool_t test_3359;
				  {
				     obj_t aux_3362;
				     obj_t aux_3360;
				     aux_3362 = CNST_TABLE_REF(((long) 15));
				     aux_3360 = CAR(sexp_27);
				     test_3359 = (aux_3360 == aux_3362);
				  }
				  if (test_3359)
				    {
				       if (PAIRP(cdr_155_78_971))
					 {
					    obj_t car_1363_7_1224;
					    car_1363_7_1224 = CAR(cdr_155_78_971);
					    if (PAIRP(car_1363_7_1224))
					      {
						 obj_t arg1820_1226;
						 obj_t arg1821_1227;
						 arg1820_1226 = CAR(car_1363_7_1224);
						 arg1821_1227 = CDR(car_1363_7_1224);
						 {
						    obj_t arg1903_2515;
						    arg1903_2515 = normalize_progn_error_20_ast_unit(CDR(cdr_155_78_971), sexp_27);
						    return make_method_definition_178_ast_unit(arg1820_1226, arg1821_1227, arg1903_2515, sexp_27);
						 }
					      }
					    else
					      {
						 goto tag_132_226_966;
					      }
					 }
				       else
					 {
					    goto tag_132_226_966;
					 }
				    }
				  else
				    {
				       goto tag_132_226_966;
				    }
			       }
			  }
		     }
		}
	     }
	}
      else
	{
	   goto tag_132_226_966;
	}
   }
}


/* normalize-progn/error */ obj_t 
normalize_progn_error_20_ast_unit(obj_t exp_29, obj_t src_30)
{
   if (NULLP(exp_29))
     {
	obj_t arg1909_1317;
	arg1909_1317 = find_location_120_tools_location(src_30);
	{
	   node_t aux_3378;
	   aux_3378 = error_sexp__node_157_ast_sexp(string2307_ast_unit, src_30, arg1909_1317);
	   return (obj_t) (aux_3378);
	}
     }
   else
     {
	return normalize_progn_143_tools_progn(exp_29);
     }
}


/* get-global-arity */ obj_t 
get_global_arity_252_ast_unit(obj_t id_31, obj_t module_32, obj_t gdefs_33)
{
   {
      obj_t global_1318;
      if (SYMBOLP(module_32))
	{
	   obj_t list1915_1324;
	   list1915_1324 = MAKE_PAIR(module_32, BNIL);
	   global_1318 = find_global_223_ast_env(id_31, list1915_1324);
	}
      else
	{
	   global_1318 = find_global_223_ast_env(id_31, BNIL);
	}
      {
	 bool_t test1910_1319;
	 test1910_1319 = is_a__118___object(global_1318, global_ast_var);
	 if (test1910_1319)
	   {
	      bool_t test1911_1320;
	      {
		 obj_t aux_3389;
		 {
		    value_t aux_3390;
		    {
		       global_t obj_2560;
		       obj_2560 = (global_t) (global_1318);
		       aux_3390 = (((global_t) CREF(obj_2560))->value);
		    }
		    aux_3389 = (obj_t) (aux_3390);
		 }
		 test1911_1320 = is_a__118___object(aux_3389, fun_ast_var);
	      }
	      if (test1911_1320)
		{
		   fun_t obj_2563;
		   {
		      value_t aux_3396;
		      {
			 global_t obj_2562;
			 obj_2562 = (global_t) (global_1318);
			 aux_3396 = (((global_t) CREF(obj_2562))->value);
		      }
		      obj_2563 = (fun_t) (aux_3396);
		   }
		   {
		      long aux_3400;
		      aux_3400 = (((fun_t) CREF(obj_2563))->arity);
		      return BINT(aux_3400);
		   }
		}
	      else
		{
		   return BFALSE;
		}
	   }
	 else
	   {
	      return BFALSE;
	   }
      }
   }
}


/* eta-expanse */ obj_t 
eta_expanse_111_ast_unit(obj_t sexp_34, obj_t arity_35)
{
   {
      obj_t args_1327;
      args_1327 = make_n_proto_123_tools_args(arity_35);
      {
	 obj_t var_1355;
	 obj_t id2_1356;
	 if (PAIRP(sexp_34))
	   {
	      obj_t cdr_1463_5_1339;
	      cdr_1463_5_1339 = CDR(sexp_34);
	      {
		 bool_t test_3407;
		 {
		    obj_t aux_3410;
		    obj_t aux_3408;
		    aux_3410 = CNST_TABLE_REF(((long) 11));
		    aux_3408 = CAR(sexp_34);
		    test_3407 = (aux_3408 == aux_3410);
		 }
		 if (test_3407)
		   {
		      if (PAIRP(cdr_1463_5_1339))
			{
			   obj_t cdr_1467_193_1342;
			   cdr_1467_193_1342 = CDR(cdr_1463_5_1339);
			   if (PAIRP(cdr_1467_193_1342))
			     {
				bool_t test_3418;
				{
				   obj_t aux_3419;
				   aux_3419 = CDR(cdr_1467_193_1342);
				   test_3418 = (aux_3419 == BNIL);
				}
				if (test_3418)
				  {
				     obj_t arg1923_1345;
				     arg1923_1345 = CAR(cdr_1463_5_1339);
				     {
					obj_t id2_2579;
					id2_2579 = id_of_id_112_ast_ident(CAR(cdr_1467_193_1342));
					{
					   obj_t arg1930_2580;
					   var_1355 = arg1923_1345;
					   id2_1356 = id2_2579;
					   {
					      bool_t test_3425;
					      {
						 long aux_3426;
						 aux_3426 = (long) CINT(arity_35);
						 test_3425 = (aux_3426 >= ((long) 0));
					      }
					      if (test_3425)
						{
						   {
						      obj_t arg1934_1359;
						      obj_t arg1935_1360;
						      obj_t arg1936_1361;
						      arg1934_1359 = CNST_TABLE_REF(((long) 11));
						      arg1935_1360 = MAKE_PAIR(var_1355, args_1327);
						      {
							 obj_t arg1942_1367;
							 {
							    obj_t arg1945_1370;
							    arg1945_1370 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							    arg1942_1367 = append_2_18___r4_pairs_and_lists_6_3(args_1327, arg1945_1370);
							 }
							 {
							    obj_t list1943_1368;
							    list1943_1368 = MAKE_PAIR(arg1942_1367, BNIL);
							    arg1936_1361 = cons__138___r4_pairs_and_lists_6_3(id2_1356, list1943_1368);
							 }
						      }
						      {
							 obj_t list1938_1363;
							 {
							    obj_t arg1939_1364;
							    {
							       obj_t arg1940_1365;
							       arg1940_1365 = MAKE_PAIR(BNIL, BNIL);
							       arg1939_1364 = MAKE_PAIR(arg1936_1361, arg1940_1365);
							    }
							    list1938_1363 = MAKE_PAIR(arg1935_1360, arg1939_1364);
							 }
							 arg1930_2580 = cons__138___r4_pairs_and_lists_6_3(arg1934_1359, list1938_1363);
						      }
						   }
						}
					      else
						{
						   bool_t test_3439;
						   {
						      long aux_3440;
						      aux_3440 = (long) CINT(arity_35);
						      test_3439 = (aux_3440 == ((long) -1));
						   }
						   if (test_3439)
						     {
							{
							   obj_t arg1950_1374;
							   obj_t arg1951_1375;
							   obj_t arg1952_1376;
							   arg1950_1374 = CNST_TABLE_REF(((long) 11));
							   arg1951_1375 = MAKE_PAIR(var_1355, args_1327);
							   {
							      obj_t arg1959_1382;
							      arg1959_1382 = CNST_TABLE_REF(((long) 16));
							      {
								 obj_t list1961_1384;
								 {
								    obj_t arg1962_1385;
								    {
								       obj_t arg1963_1386;
								       arg1963_1386 = MAKE_PAIR(BNIL, BNIL);
								       arg1962_1385 = MAKE_PAIR(args_1327, arg1963_1386);
								    }
								    list1961_1384 = MAKE_PAIR(id2_1356, arg1962_1385);
								 }
								 arg1952_1376 = cons__138___r4_pairs_and_lists_6_3(arg1959_1382, list1961_1384);
							      }
							   }
							   {
							      obj_t list1954_1378;
							      {
								 obj_t arg1956_1379;
								 {
								    obj_t arg1957_1380;
								    arg1957_1380 = MAKE_PAIR(BNIL, BNIL);
								    arg1956_1379 = MAKE_PAIR(arg1952_1376, arg1957_1380);
								 }
								 list1954_1378 = MAKE_PAIR(arg1951_1375, arg1956_1379);
							      }
							      arg1930_2580 = cons__138___r4_pairs_and_lists_6_3(arg1950_1374, list1954_1378);
							   }
							}
						     }
						   else
						     {
							{
							   obj_t arg1965_1388;
							   obj_t arg1967_1389;
							   obj_t arg1970_1390;
							   arg1965_1388 = CNST_TABLE_REF(((long) 11));
							   arg1967_1389 = MAKE_PAIR(var_1355, args_1327);
							   {
							      obj_t arg1977_1396;
							      obj_t arg1978_1397;
							      arg1977_1396 = CNST_TABLE_REF(((long) 16));
							      {
								 obj_t arg1984_1403;
								 obj_t arg1985_1404;
								 arg1984_1403 = CNST_TABLE_REF(((long) 17));
								 {
								    obj_t arg1988_1407;
								    obj_t arg1989_1408;
								    arg1988_1407 = args___args_list_50_tools_args(args_1327);
								    arg1989_1408 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
								    arg1985_1404 = append_2_18___r4_pairs_and_lists_6_3(arg1988_1407, arg1989_1408);
								 }
								 {
								    obj_t list1986_1405;
								    list1986_1405 = MAKE_PAIR(arg1985_1404, BNIL);
								    arg1978_1397 = cons__138___r4_pairs_and_lists_6_3(arg1984_1403, list1986_1405);
								 }
							      }
							      {
								 obj_t list1980_1399;
								 {
								    obj_t arg1981_1400;
								    {
								       obj_t arg1982_1401;
								       arg1982_1401 = MAKE_PAIR(BNIL, BNIL);
								       arg1981_1400 = MAKE_PAIR(arg1978_1397, arg1982_1401);
								    }
								    list1980_1399 = MAKE_PAIR(id2_1356, arg1981_1400);
								 }
								 arg1970_1390 = cons__138___r4_pairs_and_lists_6_3(arg1977_1396, list1980_1399);
							      }
							   }
							   {
							      obj_t list1972_1392;
							      {
								 obj_t arg1973_1393;
								 {
								    obj_t arg1974_1394;
								    arg1974_1394 = MAKE_PAIR(BNIL, BNIL);
								    arg1973_1393 = MAKE_PAIR(arg1970_1390, arg1974_1394);
								 }
								 list1972_1392 = MAKE_PAIR(arg1967_1389, arg1973_1393);
							      }
							      arg1930_2580 = cons__138___r4_pairs_and_lists_6_3(arg1965_1388, list1972_1392);
							   }
							}
						     }
						}
					   }
					   return replace__160_tools_misc(sexp_34, arg1930_2580);
					}
				     }
				  }
				else
				  {
				     return BFALSE;
				  }
			     }
			   else
			     {
				return BFALSE;
			     }
			}
		      else
			{
			   return BFALSE;
			}
		   }
		 else
		   {
		      return BFALSE;
		   }
	      }
	   }
	 else
	   {
	      return BFALSE;
	   }
      }
   }
}


/* make-sfun-definition */ obj_t 
make_sfun_definition_61_ast_unit(obj_t id_36, obj_t module_37, obj_t args_38, obj_t body_39, obj_t src_40, obj_t class_41)
{
   {
      obj_t locals_1491;
      {
	 obj_t args_1497;
	 obj_t res_1498;
	 args_1497 = args_38;
	 res_1498 = BNIL;
       loop_1499:
	 if (NULLP(args_1497))
	   {
	      locals_1491 = reverse__39___r4_pairs_and_lists_6_3(res_1498);
	   }
	 else
	   {
	      if (PAIRP(args_1497))
		{
		   bool_t test2082_1503;
		   {
		      obj_t aux_3477;
		      aux_3477 = dsssl_named_constant__188_tools_dsssl(CAR(args_1497));
		      test2082_1503 = CBOOL(aux_3477);
		   }
		   if (test2082_1503)
		     {
			{
			   obj_t arg_1504;
			   arg_1504 = dsssl_find_first_formal_237_tools_dsssl(args_1497);
			   if (CBOOL(arg_1504))
			     {
				obj_t arg2083_1505;
				{
				   local_t arg2084_1506;
				   arg2084_1506 = make_user_local_svar_134_ast_local(arg_1504, (type_t) (_obj__252_type_cache));
				   {
				      obj_t aux_3487;
				      aux_3487 = (obj_t) (arg2084_1506);
				      arg2083_1505 = MAKE_PAIR(aux_3487, res_1498);
				   }
				}
				locals_1491 = reverse__39___r4_pairs_and_lists_6_3(arg2083_1505);
			     }
			   else
			     {
				locals_1491 = reverse__39___r4_pairs_and_lists_6_3(res_1498);
			     }
			}
		     }
		   else
		     {
			{
			   obj_t pid_1507;
			   {
			      obj_t arg2088_1513;
			      arg2088_1513 = parse_id_241_ast_ident(CAR(args_1497));
			      pid_1507 = check_id_6_ast_ident(arg2088_1513, src_40);
			   }
			   {
			      {
				 obj_t arg2085_1510;
				 obj_t arg2086_1511;
				 arg2085_1510 = CDR(args_1497);
				 {
				    local_t arg2087_1512;
				    {
				       type_t aux_3496;
				       {
					  obj_t aux_3498;
					  aux_3498 = CDR(pid_1507);
					  aux_3496 = (type_t) (aux_3498);
				       }
				       arg2087_1512 = make_user_local_svar_134_ast_local(CAR(pid_1507), aux_3496);
				    }
				    {
				       obj_t aux_3502;
				       aux_3502 = (obj_t) (arg2087_1512);
				       arg2086_1511 = MAKE_PAIR(aux_3502, res_1498);
				    }
				 }
				 {
				    obj_t res_3506;
				    obj_t args_3505;
				    args_3505 = arg2085_1510;
				    res_3506 = arg2086_1511;
				    res_1498 = res_3506;
				    args_1497 = args_3505;
				    goto loop_1499;
				 }
			      }
			   }
			}
		     }
		}
	      else
		{
		   {
		      obj_t pid_1516;
		      {
			 obj_t arg2093_1521;
			 arg2093_1521 = parse_id_241_ast_ident(args_1497);
			 pid_1516 = check_id_6_ast_ident(arg2093_1521, src_40);
		      }
		      {
			 {
			    obj_t arg2091_1519;
			    {
			       local_t arg2092_1520;
			       {
				  type_t aux_3509;
				  {
				     obj_t aux_3511;
				     aux_3511 = CDR(pid_1516);
				     aux_3509 = (type_t) (aux_3511);
				  }
				  arg2092_1520 = make_user_local_svar_134_ast_local(CAR(pid_1516), aux_3509);
			       }
			       {
				  obj_t aux_3515;
				  aux_3515 = (obj_t) (arg2092_1520);
				  arg2091_1519 = MAKE_PAIR(aux_3515, res_1498);
			       }
			    }
			    locals_1491 = reverse__39___r4_pairs_and_lists_6_3(arg2091_1519);
			 }
		      }
		   }
		}
	   }
      }
      {
	 obj_t body_1492;
	 body_1492 = make_dsssl_function_prelude_58___dsssl(id_36, args_38, body_39, user_error_env_101_tools_error);
	 {
	    {
	       global_t arg2075_1493;
	       arg2075_1493 = def_global_sfun__93_ast_glo_def_117(id_36, args_38, locals_1491, module_37, class_41, src_40, CNST_TABLE_REF(((long) 18)), body_1492);
	       {
		  obj_t list2076_1494;
		  {
		     obj_t aux_3522;
		     aux_3522 = (obj_t) (arg2075_1493);
		     list2076_1494 = MAKE_PAIR(aux_3522, BNIL);
		  }
		  return list2076_1494;
	       }
	    }
	 }
      }
   }
}


/* make-svar-definition */ obj_t 
make_svar_definition_154_ast_unit(obj_t id_42, obj_t src_43)
{
   def_global_svar__184_ast_glo_def_117(id_42, _module__166_module_module, src_43, CNST_TABLE_REF(((long) 18)));
   {
      obj_t arg2095_1523;
      obj_t arg2096_1524;
      arg2095_1523 = CDR(src_43);
      {
	 obj_t arg2097_1525;
	 {
	    obj_t arg2098_1526;
	    arg2098_1526 = parse_id_241_ast_ident(id_42);
	    arg2097_1525 = check_id_6_ast_ident(arg2098_1526, src_43);
	 }
	 arg2096_1524 = CAR(arg2097_1525);
      }
      SET_CAR(arg2095_1523, arg2096_1524);
   }
   {
      obj_t list2099_1527;
      list2099_1527 = MAKE_PAIR(src_43, BNIL);
      return list2099_1527;
   }
}


/* make-sgfun-default */ obj_t 
make_sgfun_default_250_ast_unit(obj_t name_44, obj_t type_45, obj_t args_46, obj_t body_47, obj_t src_48, obj_t gdefs_49)
{
   {
      obj_t default_tid_30_1530;
      {
	 bool_t test2139_1567;
	 {
	    obj_t obj2_2625;
	    obj2_2625 = ____74_type_cache;
	    test2139_1567 = (type_45 == obj2_2625);
	 }
	 if (test2139_1567)
	   {
	      default_tid_30_1530 = name_44;
	   }
	 else
	   {
	      obj_t list2141_1569;
	      {
		 obj_t arg2143_1570;
		 {
		    obj_t arg2144_1571;
		    {
		       obj_t aux_3535;
		       {
			  type_t obj_2626;
			  obj_2626 = (type_t) (type_45);
			  aux_3535 = (((type_t) CREF(obj_2626))->id);
		       }
		       arg2144_1571 = MAKE_PAIR(aux_3535, BNIL);
		    }
		    arg2143_1570 = MAKE_PAIR(_4dots_199_tools_misc, arg2144_1571);
		 }
		 list2141_1569 = MAKE_PAIR(name_44, arg2143_1570);
	      }
	      default_tid_30_1530 = symbol_append_197___r4_symbols_6_4(list2141_1569);
	   }
      }
      {
	 obj_t default_body_201_1531;
	 if (PAIRP(body_47))
	   {
	      default_body_201_1531 = normalize_progn_143_tools_progn(body_47);
	   }
	 else
	   {
	      obj_t arg2120_1551;
	      obj_t arg2121_1552;
	      obj_t arg2123_1554;
	      arg2120_1551 = CNST_TABLE_REF(((long) 19));
	      {
		 obj_t arg2133_1561;
		 arg2133_1561 = CNST_TABLE_REF(((long) 20));
		 {
		    obj_t list2135_1563;
		    {
		       obj_t arg2136_1564;
		       arg2136_1564 = MAKE_PAIR(BNIL, BNIL);
		       list2135_1563 = MAKE_PAIR(name_44, arg2136_1564);
		    }
		    arg2121_1552 = cons__138___r4_pairs_and_lists_6_3(arg2133_1561, list2135_1563);
		 }
	      }
	      arg2123_1554 = id_of_id_112_ast_ident(CAR(args_46));
	      {
		 obj_t list2125_1556;
		 {
		    obj_t arg2127_1557;
		    {
		       obj_t arg2129_1558;
		       {
			  obj_t arg2131_1559;
			  arg2131_1559 = MAKE_PAIR(BNIL, BNIL);
			  arg2129_1558 = MAKE_PAIR(arg2123_1554, arg2131_1559);
		       }
		       arg2127_1557 = MAKE_PAIR(string2308_ast_unit, arg2129_1558);
		    }
		    list2125_1556 = MAKE_PAIR(arg2121_1552, arg2127_1557);
		 }
		 default_body_201_1531 = cons__138___r4_pairs_and_lists_6_3(arg2120_1551, list2125_1556);
	      }
	   }
	 {
	    obj_t form_1532;
	    {
	       obj_t tmp_1538;
	       {
		  obj_t arg2111_1543;
		  obj_t arg2112_1544;
		  arg2111_1543 = CNST_TABLE_REF(((long) 11));
		  arg2112_1544 = MAKE_PAIR(default_tid_30_1530, args_46);
		  {
		     obj_t list2114_1546;
		     {
			obj_t arg2115_1547;
			{
			   obj_t arg2116_1548;
			   arg2116_1548 = MAKE_PAIR(BNIL, BNIL);
			   arg2115_1547 = MAKE_PAIR(default_body_201_1531, arg2116_1548);
			}
			list2114_1546 = MAKE_PAIR(arg2112_1544, arg2115_1547);
		     }
		     tmp_1538 = cons__138___r4_pairs_and_lists_6_3(arg2111_1543, list2114_1546);
		  }
	       }
	       {
		  bool_t test2106_1539;
		  {
		     obj_t obj_2631;
		     obj_2631 = _module_clause__117_module_module;
		     test2106_1539 = EXTENDED_PAIRP(obj_2631);
		  }
		  if (test2106_1539)
		    {
		       obj_t arg2107_1540;
		       obj_t arg2108_1541;
		       obj_t arg2109_1542;
		       arg2107_1540 = CAR(tmp_1538);
		       arg2108_1541 = CDR(tmp_1538);
		       {
			  obj_t obj_2634;
			  obj_2634 = _module_clause__117_module_module;
			  {
			     bool_t test1137_2635;
			     test1137_2635 = EXTENDED_PAIRP(obj_2634);
			     if (test1137_2635)
			       {
				  arg2109_1542 = CER(obj_2634);
			       }
			     else
			       {
				  FAILURE(string2309_ast_unit, string2310_ast_unit, obj_2634);
			       }
			  }
		       }
		       form_1532 = MAKE_EXTENDED_PAIR(arg2107_1540, arg2108_1541, arg2109_1542);
		    }
		  else
		    {
		       form_1532 = tmp_1538;
		    }
	       }
	    }
	    {
	       {
		  obj_t ast_1533;
		  ast_1533 = toplevel__ast_219_ast_unit(form_1532, gdefs_49);
		  if (PAIRP(ast_1533))
		    {
		       bool_t test2102_1535;
		       test2102_1535 = is_a__118___object(CAR(ast_1533), global_ast_var);
		       if (test2102_1535)
			 {
			    global_t obj_2647;
			    {
			       obj_t aux_3578;
			       aux_3578 = CAR(ast_1533);
			       obj_2647 = (global_t) (aux_3578);
			    }
			    ((((global_t) CREF(obj_2647))->user__32) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			 }
		       else
			 {
			    BUNSPEC;
			 }
		    }
		  else
		    {
		       BUNSPEC;
		    }
		  return ast_1533;
	       }
	    }
	 }
      }
   }
}


/* make-sgfun-definition */ obj_t 
make_sgfun_definition_102_ast_unit(obj_t id_50, obj_t module_51, obj_t args_52, obj_t body_53, obj_t src_54, obj_t gdefs_55)
{
   {
      obj_t locals_1573;
      {
	 obj_t args_1621;
	 obj_t res_1622;
	 args_1621 = args_52;
	 res_1622 = BNIL;
       loop_1623:
	 if (NULLP(args_1621))
	   {
	      locals_1573 = reverse__39___r4_pairs_and_lists_6_3(res_1622);
	   }
	 else
	   {
	      if (PAIRP(args_1621))
		{
		   {
		      obj_t pid_1627;
		      {
			 obj_t arg2193_1633;
			 arg2193_1633 = parse_id_241_ast_ident(CAR(args_1621));
			 pid_1627 = check_id_6_ast_ident(arg2193_1633, src_54);
		      }
		      {
			 {
			    obj_t arg2190_1630;
			    obj_t arg2191_1631;
			    arg2190_1630 = CDR(args_1621);
			    {
			       local_t arg2192_1632;
			       {
				  type_t aux_3591;
				  {
				     obj_t aux_3593;
				     aux_3593 = CDR(pid_1627);
				     aux_3591 = (type_t) (aux_3593);
				  }
				  arg2192_1632 = make_user_local_svar_134_ast_local(CAR(pid_1627), aux_3591);
			       }
			       {
				  obj_t aux_3597;
				  aux_3597 = (obj_t) (arg2192_1632);
				  arg2191_1631 = MAKE_PAIR(aux_3597, res_1622);
			       }
			    }
			    {
			       obj_t res_3601;
			       obj_t args_3600;
			       args_3600 = arg2190_1630;
			       res_3601 = arg2191_1631;
			       res_1622 = res_3601;
			       args_1621 = args_3600;
			       goto loop_1623;
			    }
			 }
		      }
		   }
		}
	      else
		{
		   {
		      obj_t pid_1635;
		      {
			 obj_t arg2198_1640;
			 arg2198_1640 = parse_id_241_ast_ident(args_1621);
			 pid_1635 = check_id_6_ast_ident(arg2198_1640, src_54);
		      }
		      {
			 {
			    obj_t arg2196_1638;
			    {
			       local_t arg2197_1639;
			       {
				  type_t aux_3604;
				  {
				     obj_t aux_3606;
				     aux_3606 = CDR(pid_1635);
				     aux_3604 = (type_t) (aux_3606);
				  }
				  arg2197_1639 = make_user_local_svar_134_ast_local(CAR(pid_1635), aux_3604);
			       }
			       {
				  obj_t aux_3610;
				  aux_3610 = (obj_t) (arg2197_1639);
				  arg2196_1638 = MAKE_PAIR(aux_3610, res_1622);
			       }
			    }
			    locals_1573 = reverse__39___r4_pairs_and_lists_6_3(arg2196_1638);
			 }
		      }
		   }
		}
	   }
      }
      {
	 obj_t pid_1574;
	 {
	    obj_t arg2186_1620;
	    arg2186_1620 = parse_id_241_ast_ident(id_50);
	    pid_1574 = check_id_6_ast_ident(arg2186_1620, src_54);
	 }
	 {
	    obj_t name_1575;
	    name_1575 = CAR(pid_1574);
	    {
	       obj_t type_1576;
	       type_1576 = CDR(pid_1574);
	       {
		  obj_t dname_1577;
		  {
		     obj_t arg2181_1615;
		     {
			obj_t list2183_1617;
			{
			   obj_t arg2184_1618;
			   {
			      obj_t aux_3618;
			      aux_3618 = CNST_TABLE_REF(((long) 21));
			      arg2184_1618 = MAKE_PAIR(aux_3618, BNIL);
			   }
			   list2183_1617 = MAKE_PAIR(name_1575, arg2184_1618);
			}
			arg2181_1615 = symbol_append_197___r4_symbols_6_4(list2183_1617);
		     }
		     dname_1577 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, arg2181_1615, BEOA);
		  }
		  {
		     obj_t default_1578;
		     {
			bool_t test2180_1614;
			{
			   obj_t obj2_2664;
			   obj2_2664 = _module__166_module_module;
			   test2180_1614 = (module_51 == obj2_2664);
			}
			if (test2180_1614)
			  {
			     default_1578 = make_sgfun_default_250_ast_unit(dname_1577, type_1576, args_52, body_53, src_54, gdefs_55);
			  }
			else
			  {
			     default_1578 = BNIL;
			  }
		     }
		     {
			obj_t body_1579;
			body_1579 = make_generic_body_233_object_generic(id_50, locals_1573, args_52, src_54);
			{
			   global_t generic_1580;
			   generic_1580 = def_global_sfun__93_ast_glo_def_117(id_50, args_52, locals_1573, module_51, CNST_TABLE_REF(((long) 22)), src_54, CNST_TABLE_REF(((long) 18)), body_1579);
			   {
			      add_generic_for_method_inlining__147_object_inline((obj_t) (generic_1580));
			      {
				 obj_t o_unit_142_1581;
				 obj_t sexp__30_1582;
				 o_unit_142_1581 = get_method_unit_151_module_class();
				 {
				    obj_t arg2149_1586;
				    {
				       obj_t arg2150_1587;
				       {
					  obj_t arg2151_1588;
					  {
					     obj_t arg2154_1591;
					     obj_t arg2155_1592;
					     obj_t arg2156_1593;
					     arg2154_1591 = CNST_TABLE_REF(((long) 23));
					     {
						obj_t arg2162_1599;
						obj_t arg2163_1600;
						arg2162_1599 = CNST_TABLE_REF(((long) 6));
						arg2163_1600 = (((global_t) CREF(generic_1580))->id);
						{
						   obj_t list2165_1602;
						   {
						      obj_t arg2166_1603;
						      {
							 obj_t arg2167_1604;
							 arg2167_1604 = MAKE_PAIR(BNIL, BNIL);
							 arg2166_1603 = MAKE_PAIR(module_51, arg2167_1604);
						      }
						      list2165_1602 = MAKE_PAIR(arg2163_1600, arg2166_1603);
						   }
						   arg2155_1592 = cons__138___r4_pairs_and_lists_6_3(arg2162_1599, list2165_1602);
						}
					     }
					     {
						obj_t arg2170_1606;
						arg2170_1606 = CNST_TABLE_REF(((long) 6));
						{
						   obj_t list2173_1608;
						   {
						      obj_t arg2174_1609;
						      {
							 obj_t arg2175_1610;
							 arg2175_1610 = MAKE_PAIR(BNIL, BNIL);
							 arg2174_1609 = MAKE_PAIR(_module__166_module_module, arg2175_1610);
						      }
						      list2173_1608 = MAKE_PAIR(dname_1577, arg2174_1609);
						   }
						   arg2156_1593 = cons__138___r4_pairs_and_lists_6_3(arg2170_1606, list2173_1608);
						}
					     }
					     {
						obj_t list2158_1595;
						{
						   obj_t arg2159_1596;
						   {
						      obj_t arg2160_1597;
						      arg2160_1597 = MAKE_PAIR(BNIL, BNIL);
						      arg2159_1596 = MAKE_PAIR(arg2156_1593, arg2160_1597);
						   }
						   list2158_1595 = MAKE_PAIR(arg2155_1592, arg2159_1596);
						}
						arg2151_1588 = cons__138___r4_pairs_and_lists_6_3(arg2154_1591, list2158_1595);
					     }
					  }
					  {
					     obj_t list2152_1589;
					     list2152_1589 = MAKE_PAIR(arg2151_1588, BNIL);
					     arg2150_1587 = list2152_1589;
					  }
				       }
				       arg2149_1586 = append_2_18___r4_pairs_and_lists_6_3(arg2150_1587, default_1578);
				    }
				    {
				       obj_t aux_3653;
				       aux_3653 = (obj_t) (generic_1580);
				       sexp__30_1582 = MAKE_PAIR(aux_3653, arg2149_1586);
				    }
				 }
				 {
				    bool_t test_3656;
				    if (STRUCTP(o_unit_142_1581))
				      {
					 obj_t aux_3661;
					 obj_t aux_3659;
					 aux_3661 = CNST_TABLE_REF(((long) 24));
					 aux_3659 = STRUCT_KEY(o_unit_142_1581);
					 test_3656 = (aux_3659 == aux_3661);
				      }
				    else
				      {
					 test_3656 = ((bool_t) 0);
				      }
				    if (test_3656)
				      {
					 unit_sexp__add__71_ast_unit(o_unit_142_1581, sexp__30_1582);
					 {
					    obj_t list2147_1584;
					    list2147_1584 = MAKE_PAIR(BUNSPEC, BNIL);
					    return list2147_1584;
					 }
				      }
				    else
				      {
					 return sexp__30_1582;
				      }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-method-definition */ obj_t 
make_method_definition_178_ast_unit(obj_t id_56, obj_t args_57, obj_t body_58, obj_t src_59)
{
   {
      obj_t locals_1641;
      {
	 obj_t args_1650;
	 obj_t res_1651;
	 args_1650 = args_57;
	 res_1651 = BNIL;
       loop_1652:
	 if (NULLP(args_1650))
	   {
	      locals_1641 = reverse__39___r4_pairs_and_lists_6_3(res_1651);
	   }
	 else
	   {
	      if (PAIRP(args_1650))
		{
		   {
		      obj_t pid_1656;
		      {
			 obj_t arg2211_1662;
			 arg2211_1662 = parse_id_241_ast_ident(CAR(args_1650));
			 pid_1656 = check_id_6_ast_ident(arg2211_1662, src_59);
		      }
		      {
			 {
			    obj_t arg2208_1659;
			    obj_t arg2209_1660;
			    arg2208_1659 = CDR(args_1650);
			    {
			       local_t arg2210_1661;
			       {
				  type_t aux_3675;
				  {
				     obj_t aux_3677;
				     aux_3677 = CDR(pid_1656);
				     aux_3675 = (type_t) (aux_3677);
				  }
				  arg2210_1661 = make_local_svar_140_ast_local(CAR(pid_1656), aux_3675);
			       }
			       {
				  obj_t aux_3681;
				  aux_3681 = (obj_t) (arg2210_1661);
				  arg2209_1660 = MAKE_PAIR(aux_3681, res_1651);
			       }
			    }
			    {
			       obj_t res_3685;
			       obj_t args_3684;
			       args_3684 = arg2208_1659;
			       res_3685 = arg2209_1660;
			       res_1651 = res_3685;
			       args_1650 = args_3684;
			       goto loop_1652;
			    }
			 }
		      }
		   }
		}
	      else
		{
		   {
		      obj_t pid_1664;
		      {
			 obj_t arg2216_1669;
			 arg2216_1669 = parse_id_241_ast_ident(args_1650);
			 pid_1664 = check_id_6_ast_ident(arg2216_1669, src_59);
		      }
		      {
			 {
			    obj_t arg2214_1667;
			    {
			       local_t arg2215_1668;
			       {
				  type_t aux_3688;
				  {
				     obj_t aux_3690;
				     aux_3690 = CDR(pid_1664);
				     aux_3688 = (type_t) (aux_3690);
				  }
				  arg2215_1668 = make_local_svar_140_ast_local(CAR(pid_1664), aux_3688);
			       }
			       {
				  obj_t aux_3694;
				  aux_3694 = (obj_t) (arg2215_1668);
				  arg2214_1667 = MAKE_PAIR(aux_3694, res_1651);
			       }
			    }
			    locals_1641 = reverse__39___r4_pairs_and_lists_6_3(arg2214_1667);
			 }
		      }
		   }
		}
	   }
      }
      {
	 bool_t test2199_1642;
	 test2199_1642 = check_method_definition_71_ast_glo_def_117(id_56, args_57, locals_1641, src_59);
	 if (test2199_1642)
	   {
	      obj_t o_unit_142_1643;
	      obj_t sexp__30_1644;
	      o_unit_142_1643 = get_method_unit_151_module_class();
	      sexp__30_1644 = make_method_body_103_object_method(id_56, args_57, locals_1641, body_58, src_59);
	      {
		 bool_t test_3702;
		 if (STRUCTP(o_unit_142_1643))
		   {
		      obj_t aux_3707;
		      obj_t aux_3705;
		      aux_3707 = CNST_TABLE_REF(((long) 24));
		      aux_3705 = STRUCT_KEY(o_unit_142_1643);
		      test_3702 = (aux_3705 == aux_3707);
		   }
		 else
		   {
		      test_3702 = ((bool_t) 0);
		   }
		 if (test_3702)
		   {
		      unit_sexp__add__71_ast_unit(o_unit_142_1643, sexp__30_1644);
		      {
			 obj_t list2201_1646;
			 list2201_1646 = MAKE_PAIR(BUNSPEC, BNIL);
			 return list2201_1646;
		      }
		   }
		 else
		   {
		      return sexp__30_1644;
		   }
	      }
	   }
	 else
	   {
	      obj_t list2203_1648;
	      list2203_1648 = MAKE_PAIR(BUNSPEC, BNIL);
	      return list2203_1648;
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_ast_unit()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_unit()
{
   module_initialization_70_type_type(((long) 0), "AST_UNIT");
   module_initialization_70_ast_var(((long) 0), "AST_UNIT");
   module_initialization_70_ast_node(((long) 0), "AST_UNIT");
   module_initialization_70_tools_trace(((long) 0), "AST_UNIT");
   module_initialization_70_ast_find_gdefs_13(((long) 0), "AST_UNIT");
   module_initialization_70_ast_glo_def_117(((long) 0), "AST_UNIT");
   module_initialization_70_ast_ident(((long) 0), "AST_UNIT");
   module_initialization_70_ast_env(((long) 0), "AST_UNIT");
   module_initialization_70_ast_local(((long) 0), "AST_UNIT");
   module_initialization_70_ast_sexp(((long) 0), "AST_UNIT");
   module_initialization_70_object_generic(((long) 0), "AST_UNIT");
   module_initialization_70_object_method(((long) 0), "AST_UNIT");
   module_initialization_70_object_inline(((long) 0), "AST_UNIT");
   module_initialization_70_tools_progn(((long) 0), "AST_UNIT");
   module_initialization_70_tools_args(((long) 0), "AST_UNIT");
   module_initialization_70_tools_misc(((long) 0), "AST_UNIT");
   module_initialization_70_tools_speek(((long) 0), "AST_UNIT");
   module_initialization_70_tools_shape(((long) 0), "AST_UNIT");
   module_initialization_70_tools_location(((long) 0), "AST_UNIT");
   module_initialization_70_tools_error(((long) 0), "AST_UNIT");
   module_initialization_70_tools_dsssl(((long) 0), "AST_UNIT");
   module_initialization_70_engine_param(((long) 0), "AST_UNIT");
   module_initialization_70_module_module(((long) 0), "AST_UNIT");
   module_initialization_70_module_class(((long) 0), "AST_UNIT");
   module_initialization_70_module_include(((long) 0), "AST_UNIT");
   return module_initialization_70_type_cache(((long) 0), "AST_UNIT");
}
