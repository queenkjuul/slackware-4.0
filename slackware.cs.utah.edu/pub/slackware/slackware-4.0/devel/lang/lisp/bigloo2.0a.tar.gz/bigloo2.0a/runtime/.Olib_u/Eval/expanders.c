/*===========================================================================*/
/*   (Eval/expanders.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t expand_eval_labels_169___expander_let(obj_t, obj_t);
extern obj_t expand_quote_117___expander_quote(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t expand_test_227___install_expanders(obj_t, obj_t);
extern obj_t expand_define_expander_27___eval(obj_t, obj_t);
extern obj_t expand_eval_define_struct_250___expander_struct(obj_t, obj_t);
extern obj_t install_all_expanders__168___install_expanders();
static obj_t _install_all_expanders__218___install_expanders(obj_t);
extern obj_t expand_eval_define_inline_157___expander_define(obj_t, obj_t);
extern obj_t expand_eval_lambda_55___expander_define(obj_t, obj_t);
extern obj_t install_eval_expander_92___macro(obj_t, obj_t);
extern obj_t expand_eval_define_165___expander_define(obj_t, obj_t);
extern obj_t expand_eval_letrec_133___expander_let(obj_t, obj_t);
static obj_t _expand_lalr_grammar_175___lalr_expand(obj_t, obj_t, obj_t);
extern obj_t install_expander_245___macro(obj_t, obj_t);
extern obj_t expand_eval_let__60___expander_let(obj_t, obj_t);
static obj_t _expand_regular_grammar_168___rgc_expand(obj_t, obj_t, obj_t);
extern obj_t _nil__217___eval;
extern obj_t quasiquotation___expander_quote(obj_t, obj_t);
extern obj_t expand_or_72___expander_bool(obj_t);
extern obj_t expand_do_31___expander_do(obj_t, obj_t);
static obj_t arg1367___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1363___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1356___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1353___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1350___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1347___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1343___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1339___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1334___install_expanders(obj_t, obj_t, obj_t);
extern obj_t expand_define_hygien_macro_18___eval(obj_t, obj_t);
extern obj_t module_initialization_70___install_expanders(long, char *);
extern obj_t module_initialization_70___match_expand(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___macro(long, char *);
extern obj_t module_initialization_70___expander_quote(long, char *);
extern obj_t module_initialization_70___expander_let(long, char *);
extern obj_t module_initialization_70___expander_bool(long, char *);
extern obj_t module_initialization_70___expander_case(long, char *);
extern obj_t module_initialization_70___expander_define(long, char *);
extern obj_t module_initialization_70___expander_do(long, char *);
extern obj_t module_initialization_70___expander_try(long, char *);
extern obj_t module_initialization_70___expander_struct(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___lalr_expand(long, char *);
extern obj_t module_initialization_70___rgc_expand(long, char *);
static obj_t arg1285___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1282___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1240___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1211___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1185___install_expanders(obj_t, obj_t, obj_t);
extern obj_t expand_eval_let_110___expander_let(obj_t, obj_t);
extern obj_t expand_match_case_143___match_expand(obj_t);
static obj_t arg1162___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1136___install_expanders(obj_t, obj_t, obj_t);
extern obj_t expand_and_10___expander_bool(obj_t);
static obj_t arg1110___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1098___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1106___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1095___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1102___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1092___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1088___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1084___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1080___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1077___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1073___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1069___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1065___install_expanders(obj_t, obj_t, obj_t);
static obj_t arg1061___install_expanders(obj_t, obj_t, obj_t);
extern obj_t expand_match_lambda_130___match_expand(obj_t);
extern obj_t expand_eval_case_113___expander_case(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_string_case_129___rgc_expand(obj_t, obj_t, obj_t);
extern obj_t expand_define_pattern_97___eval(obj_t);
extern obj_t expand_cond_95___expander_bool(obj_t);
extern obj_t expand_try_212___expander_try(obj_t, obj_t);
static obj_t imported_modules_init_94___install_expanders();
static obj_t require_initialization_114___install_expanders = BUNSPEC;
extern obj_t expand_define_macro_35___eval(obj_t, obj_t);
static obj_t symbol1616___install_expanders = BUNSPEC;
static obj_t symbol1599___install_expanders = BUNSPEC;
static obj_t symbol1609___install_expanders = BUNSPEC;
extern obj_t normalize_progn_143___progn(obj_t);
static obj_t symbol1597___install_expanders = BUNSPEC;
static obj_t symbol1595___install_expanders = BUNSPEC;
static obj_t symbol1605___install_expanders = BUNSPEC;
static obj_t symbol1593___install_expanders = BUNSPEC;
static obj_t symbol1603___install_expanders = BUNSPEC;
static obj_t symbol1591___install_expanders = BUNSPEC;
static obj_t symbol1601___install_expanders = BUNSPEC;
static obj_t symbol1587___install_expanders = BUNSPEC;
static obj_t symbol1585___install_expanders = BUNSPEC;
static obj_t cnst_init_137___install_expanders();
static obj_t symbol1583___install_expanders = BUNSPEC;
static obj_t symbol1581___install_expanders = BUNSPEC;
static obj_t symbol1579___install_expanders = BUNSPEC;
static obj_t symbol1577___install_expanders = BUNSPEC;
static obj_t symbol1576___install_expanders = BUNSPEC;
static obj_t symbol1575___install_expanders = BUNSPEC;
static obj_t symbol1574___install_expanders = BUNSPEC;
static obj_t symbol1572___install_expanders = BUNSPEC;
static obj_t symbol1570___install_expanders = BUNSPEC;
static obj_t symbol1568___install_expanders = BUNSPEC;
static obj_t symbol1566___install_expanders = BUNSPEC;
static obj_t symbol1564___install_expanders = BUNSPEC;
static obj_t symbol1562___install_expanders = BUNSPEC;
static obj_t symbol1560___install_expanders = BUNSPEC;
static obj_t symbol1558___install_expanders = BUNSPEC;
static obj_t symbol1556___install_expanders = BUNSPEC;
static obj_t symbol1554___install_expanders = BUNSPEC;
static obj_t symbol1552___install_expanders = BUNSPEC;
static obj_t symbol1550___install_expanders = BUNSPEC;
static obj_t symbol1548___install_expanders = BUNSPEC;
static obj_t symbol1546___install_expanders = BUNSPEC;
static obj_t symbol1545___install_expanders = BUNSPEC;
static obj_t symbol1544___install_expanders = BUNSPEC;
static obj_t symbol1543___install_expanders = BUNSPEC;
static obj_t symbol1542___install_expanders = BUNSPEC;
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE( proc1598___install_expanders, arg1350___install_expanders1619, arg1350___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1596___install_expanders, arg1347___install_expanders1620, arg1347___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1606___install_expanders, arg1367___install_expanders1621, arg1367___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1594___install_expanders, arg1343___install_expanders1622, arg1343___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1604___install_expanders, arg1363___install_expanders1623, arg1363___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1592___install_expanders, arg1339___install_expanders1624, arg1339___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1602___install_expanders, arg1356___install_expanders1625, arg1356___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1589___install_expanders, arg1285___install_expanders1626, arg1285___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1590___install_expanders, arg1334___install_expanders1627, arg1334___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1600___install_expanders, arg1353___install_expanders1628, arg1353___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1588___install_expanders, arg1282___install_expanders1629, arg1282___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1586___install_expanders, arg1240___install_expanders1630, arg1240___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1584___install_expanders, arg1211___install_expanders1631, arg1211___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1582___install_expanders, arg1185___install_expanders1632, arg1185___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1580___install_expanders, arg1162___install_expanders1633, arg1162___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1578___install_expanders, arg1136___install_expanders1634, arg1136___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1573___install_expanders, arg1110___install_expanders1635, arg1110___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1571___install_expanders, arg1106___install_expanders1636, arg1106___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1569___install_expanders, arg1102___install_expanders1637, arg1102___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1567___install_expanders, arg1098___install_expanders1638, arg1098___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1565___install_expanders, arg1095___install_expanders1639, arg1095___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1563___install_expanders, arg1092___install_expanders1640, arg1092___install_expanders, 0L, 2 );
extern obj_t expand_regular_grammar_env_93___rgc_expand;
DEFINE_STATIC_PROCEDURE( proc1561___install_expanders, arg1088___install_expanders1641, arg1088___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1559___install_expanders, arg1084___install_expanders1642, arg1084___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1557___install_expanders, arg1080___install_expanders1643, arg1080___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1555___install_expanders, arg1077___install_expanders1644, arg1077___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1553___install_expanders, arg1073___install_expanders1645, arg1073___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1551___install_expanders, arg1069___install_expanders1646, arg1069___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1549___install_expanders, arg1065___install_expanders1647, arg1065___install_expanders, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1547___install_expanders, arg1061___install_expanders1648, arg1061___install_expanders, 0L, 2 );
extern obj_t expand_string_case_env_105___rgc_expand;
DEFINE_STRING( string1617___install_expanders, string1617___install_expanders1649, "delay", 5 );
DEFINE_STRING( string1615___install_expanders, string1615___install_expanders1650, "begin", 5 );
DEFINE_STRING( string1614___install_expanders, string1614___install_expanders1651, "Illegal `failure' form", 22 );
DEFINE_STRING( string1613___install_expanders, string1613___install_expanders1652, "failure", 7 );
DEFINE_STRING( string1612___install_expanders, string1612___install_expanders1653, "bind-exit", 9 );
DEFINE_STRING( string1611___install_expanders, string1611___install_expanders1654, "unwind-protect", 14 );
DEFINE_STRING( string1610___install_expanders, string1610___install_expanders1655, "multiple-value-bind", 19 );
DEFINE_STRING( string1608___install_expanders, string1608___install_expanders1656, "Illegal form", 12 );
DEFINE_STRING( string1607___install_expanders, string1607___install_expanders1657, "if", 2 );
extern obj_t expand_lalr_grammar_env_33___lalr_expand;
DEFINE_EXPORT_PROCEDURE( install_all_expanders__env_132___install_expanders, _install_all_expanders__218___install_expanders1658, _install_all_expanders__218___install_expanders, 0L, 0 );


/* module-initialization */obj_t module_initialization_70___install_expanders(long checksum_1356, char * from_1357)
{
if(CBOOL(require_initialization_114___install_expanders)){
require_initialization_114___install_expanders = BBOOL(((bool_t)0));
cnst_init_137___install_expanders();
imported_modules_init_94___install_expanders();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___install_expanders()
{
symbol1542___install_expanders = string_to_symbol("LAMBDA");
symbol1543___install_expanders = string_to_symbol("TEST-AUX-FOR-NIL");
symbol1544___install_expanders = string_to_symbol("IF");
symbol1545___install_expanders = string_to_symbol("NULL?");
symbol1546___install_expanders = string_to_symbol("QUOTE");
symbol1548___install_expanders = string_to_symbol("QUASIQUOTE");
symbol1550___install_expanders = string_to_symbol("DEFINE-MACRO");
symbol1552___install_expanders = string_to_symbol("DEFINE-HYGIEN-MACRO");
symbol1554___install_expanders = string_to_symbol("DEFINE-EXPANDER");
symbol1556___install_expanders = string_to_symbol("OR");
symbol1558___install_expanders = string_to_symbol("AND");
symbol1560___install_expanders = string_to_symbol("COND");
symbol1562___install_expanders = string_to_symbol("DO");
symbol1564___install_expanders = string_to_symbol("TRY");
symbol1566___install_expanders = string_to_symbol("MATCH-CASE");
symbol1568___install_expanders = string_to_symbol("MATCH-LAMBDA");
symbol1570___install_expanders = string_to_symbol("DEFINE-PATTERN");
symbol1572___install_expanders = string_to_symbol("DELAY");
symbol1574___install_expanders = string_to_symbol("REGULAR-GRAMMAR");
symbol1575___install_expanders = string_to_symbol("STRING-CASE");
symbol1576___install_expanders = string_to_symbol("LALR-GRAMMAR");
symbol1577___install_expanders = string_to_symbol("BEGIN");
symbol1579___install_expanders = string_to_symbol("FAILURE");
symbol1581___install_expanders = string_to_symbol("BIND-EXIT");
symbol1583___install_expanders = string_to_symbol("UNWIND-PROTECT");
symbol1585___install_expanders = string_to_symbol("MULTIPLE-VALUE-BIND");
symbol1587___install_expanders = string_to_symbol("MODULE");
symbol1591___install_expanders = string_to_symbol("LET");
symbol1593___install_expanders = string_to_symbol("LET*");
symbol1595___install_expanders = string_to_symbol("LETREC");
symbol1597___install_expanders = string_to_symbol("LABELS");
symbol1599___install_expanders = string_to_symbol("DEFINE");
symbol1601___install_expanders = string_to_symbol("DEFINE-INLINE");
symbol1603___install_expanders = string_to_symbol("DEFINE-STRUCT");
symbol1605___install_expanders = string_to_symbol("CASE");
symbol1609___install_expanders = string_to_symbol("CALL-WITH-VALUES");
return (symbol1616___install_expanders = string_to_symbol("MAKE-PROMISE"),
BUNSPEC);
}


/* expand-test */obj_t expand_test_227___install_expanders(obj_t x_1, obj_t e_2)
{
if(CBOOL(_nil__217___eval)){
return PROCEDURE_ENTRY(e_2)(e_2, x_1, e_2, BEOA);
}
 else {
obj_t arg1016_321;
obj_t arg1017_322;
{
obj_t arg1022_327;
obj_t arg1023_328;
obj_t arg1025_329;
arg1022_327 = symbol1542___install_expanders;
{
obj_t arg1031_335;
arg1031_335 = symbol1543___install_expanders;
{
obj_t list1033_337;
list1033_337 = MAKE_PAIR(BNIL, BNIL);
arg1023_328 = cons__138___r4_pairs_and_lists_6_3(arg1031_335, list1033_337);
}
}
{
obj_t arg1035_339;
obj_t arg1037_340;
obj_t arg1038_341;
arg1035_339 = symbol1544___install_expanders;
arg1037_340 = symbol1543___install_expanders;
{
obj_t arg1045_348;
obj_t arg1046_349;
arg1045_348 = symbol1544___install_expanders;
{
obj_t arg1054_356;
obj_t arg1055_357;
arg1054_356 = symbol1545___install_expanders;
arg1055_357 = symbol1543___install_expanders;
{
obj_t list1057_359;
{
obj_t arg1058_360;
arg1058_360 = MAKE_PAIR(BNIL, BNIL);
list1057_359 = MAKE_PAIR(arg1055_357, arg1058_360);
}
arg1046_349 = cons__138___r4_pairs_and_lists_6_3(arg1054_356, list1057_359);
}
}
{
obj_t list1048_351;
{
obj_t arg1049_352;
{
obj_t arg1050_353;
{
obj_t arg1051_354;
arg1051_354 = MAKE_PAIR(BNIL, BNIL);
arg1050_353 = MAKE_PAIR(BTRUE, arg1051_354);
}
arg1049_352 = MAKE_PAIR(BFALSE, arg1050_353);
}
list1048_351 = MAKE_PAIR(arg1046_349, arg1049_352);
}
arg1038_341 = cons__138___r4_pairs_and_lists_6_3(arg1045_348, list1048_351);
}
}
{
obj_t list1040_343;
{
obj_t arg1041_344;
{
obj_t arg1042_345;
{
obj_t arg1043_346;
arg1043_346 = MAKE_PAIR(BNIL, BNIL);
arg1042_345 = MAKE_PAIR(BFALSE, arg1043_346);
}
arg1041_344 = MAKE_PAIR(arg1038_341, arg1042_345);
}
list1040_343 = MAKE_PAIR(arg1037_340, arg1041_344);
}
arg1025_329 = cons__138___r4_pairs_and_lists_6_3(arg1035_339, list1040_343);
}
}
{
obj_t list1027_331;
{
obj_t arg1028_332;
{
obj_t arg1029_333;
arg1029_333 = MAKE_PAIR(BNIL, BNIL);
arg1028_332 = MAKE_PAIR(arg1025_329, arg1029_333);
}
list1027_331 = MAKE_PAIR(arg1023_328, arg1028_332);
}
arg1016_321 = cons__138___r4_pairs_and_lists_6_3(arg1022_327, list1027_331);
}
}
arg1017_322 = PROCEDURE_ENTRY(e_2)(e_2, x_1, e_2, BEOA);
{
obj_t list1019_324;
{
obj_t arg1020_325;
arg1020_325 = MAKE_PAIR(BNIL, BNIL);
list1019_324 = MAKE_PAIR(arg1017_322, arg1020_325);
}
return cons__138___r4_pairs_and_lists_6_3(arg1016_321, list1019_324);
}
}
}


/* install-all-expanders! */obj_t install_all_expanders__168___install_expanders()
{
{
obj_t arg1060_362;
arg1060_362 = symbol1546___install_expanders;
{
obj_t arg1061_1223;
arg1061_1223 = proc1547___install_expanders;
install_expander_245___macro(arg1060_362, arg1061_1223);
}
}
{
obj_t arg1063_368;
arg1063_368 = symbol1548___install_expanders;
{
obj_t arg1065_1222;
arg1065_1222 = proc1549___install_expanders;
install_expander_245___macro(arg1063_368, arg1065_1222);
}
}
{
obj_t arg1068_375;
arg1068_375 = symbol1550___install_expanders;
{
obj_t arg1069_1221;
arg1069_1221 = proc1551___install_expanders;
install_expander_245___macro(arg1068_375, arg1069_1221);
}
}
{
obj_t arg1072_381;
arg1072_381 = symbol1552___install_expanders;
{
obj_t arg1073_1220;
arg1073_1220 = proc1553___install_expanders;
install_expander_245___macro(arg1072_381, arg1073_1220);
}
}
{
obj_t arg1076_387;
arg1076_387 = symbol1554___install_expanders;
{
obj_t arg1077_1219;
arg1077_1219 = proc1555___install_expanders;
install_expander_245___macro(arg1076_387, arg1077_1219);
}
}
{
obj_t arg1079_393;
arg1079_393 = symbol1556___install_expanders;
{
obj_t arg1080_1218;
arg1080_1218 = proc1557___install_expanders;
install_expander_245___macro(arg1079_393, arg1080_1218);
}
}
{
obj_t arg1083_400;
arg1083_400 = symbol1558___install_expanders;
{
obj_t arg1084_1217;
arg1084_1217 = proc1559___install_expanders;
install_expander_245___macro(arg1083_400, arg1084_1217);
}
}
{
obj_t arg1087_407;
arg1087_407 = symbol1560___install_expanders;
{
obj_t arg1088_1216;
arg1088_1216 = proc1561___install_expanders;
install_expander_245___macro(arg1087_407, arg1088_1216);
}
}
{
obj_t arg1091_414;
arg1091_414 = symbol1562___install_expanders;
{
obj_t arg1092_1215;
arg1092_1215 = proc1563___install_expanders;
install_expander_245___macro(arg1091_414, arg1092_1215);
}
}
{
obj_t arg1094_420;
arg1094_420 = symbol1564___install_expanders;
{
obj_t arg1095_1214;
arg1095_1214 = proc1565___install_expanders;
install_expander_245___macro(arg1094_420, arg1095_1214);
}
}
{
obj_t arg1097_426;
arg1097_426 = symbol1566___install_expanders;
{
obj_t arg1098_1213;
arg1098_1213 = proc1567___install_expanders;
install_expander_245___macro(arg1097_426, arg1098_1213);
}
}
{
obj_t arg1101_433;
arg1101_433 = symbol1568___install_expanders;
{
obj_t arg1102_1212;
arg1102_1212 = proc1569___install_expanders;
install_expander_245___macro(arg1101_433, arg1102_1212);
}
}
{
obj_t arg1105_440;
arg1105_440 = symbol1570___install_expanders;
{
obj_t arg1106_1211;
arg1106_1211 = proc1571___install_expanders;
install_expander_245___macro(arg1105_440, arg1106_1211);
}
}
{
obj_t arg1109_447;
arg1109_447 = symbol1572___install_expanders;
{
obj_t arg1110_1210;
arg1110_1210 = proc1573___install_expanders;
install_expander_245___macro(arg1109_447, arg1110_1210);
}
}
install_expander_245___macro(symbol1574___install_expanders, expand_regular_grammar_env_93___rgc_expand);
install_expander_245___macro(symbol1575___install_expanders, expand_string_case_env_105___rgc_expand);
install_expander_245___macro(symbol1576___install_expanders, expand_lalr_grammar_env_33___lalr_expand);
{
obj_t arg1135_481;
arg1135_481 = symbol1577___install_expanders;
{
obj_t arg1136_1209;
arg1136_1209 = proc1578___install_expanders;
install_expander_245___macro(arg1135_481, arg1136_1209);
}
}
{
obj_t arg1161_523;
arg1161_523 = symbol1579___install_expanders;
{
obj_t arg1162_1208;
arg1162_1208 = proc1580___install_expanders;
install_expander_245___macro(arg1161_523, arg1162_1208);
}
}
{
obj_t arg1184_558;
arg1184_558 = symbol1581___install_expanders;
{
obj_t arg1185_1207;
arg1185_1207 = proc1582___install_expanders;
install_eval_expander_92___macro(arg1184_558, arg1185_1207);
}
}
{
obj_t arg1210_593;
arg1210_593 = symbol1583___install_expanders;
{
obj_t arg1211_1206;
arg1211_1206 = proc1584___install_expanders;
install_eval_expander_92___macro(arg1210_593, arg1211_1206);
}
}
{
obj_t arg1238_633;
arg1238_633 = symbol1585___install_expanders;
{
obj_t arg1240_1205;
arg1240_1205 = proc1586___install_expanders;
install_expander_245___macro(arg1238_633, arg1240_1205);
}
}
{
obj_t arg1281_677;
arg1281_677 = symbol1587___install_expanders;
{
obj_t arg1282_1204;
arg1282_1204 = proc1588___install_expanders;
install_eval_expander_92___macro(arg1281_677, arg1282_1204);
}
}
{
obj_t arg1284_683;
arg1284_683 = symbol1544___install_expanders;
{
obj_t arg1285_1203;
arg1285_1203 = proc1589___install_expanders;
install_eval_expander_92___macro(arg1284_683, arg1285_1203);
}
}
{
obj_t arg1333_740;
arg1333_740 = symbol1542___install_expanders;
{
obj_t arg1334_1202;
arg1334_1202 = proc1590___install_expanders;
install_eval_expander_92___macro(arg1333_740, arg1334_1202);
}
}
{
obj_t arg1337_746;
arg1337_746 = symbol1591___install_expanders;
{
obj_t arg1339_1201;
arg1339_1201 = proc1592___install_expanders;
install_eval_expander_92___macro(arg1337_746, arg1339_1201);
}
}
{
obj_t arg1342_752;
arg1342_752 = symbol1593___install_expanders;
{
obj_t arg1343_1200;
arg1343_1200 = proc1594___install_expanders;
install_eval_expander_92___macro(arg1342_752, arg1343_1200);
}
}
{
obj_t arg1345_758;
arg1345_758 = symbol1595___install_expanders;
{
obj_t arg1347_1199;
arg1347_1199 = proc1596___install_expanders;
install_eval_expander_92___macro(arg1345_758, arg1347_1199);
}
}
{
obj_t arg1349_764;
arg1349_764 = symbol1597___install_expanders;
{
obj_t arg1350_1198;
arg1350_1198 = proc1598___install_expanders;
install_eval_expander_92___macro(arg1349_764, arg1350_1198);
}
}
{
obj_t arg1352_770;
arg1352_770 = symbol1599___install_expanders;
{
obj_t arg1353_1197;
arg1353_1197 = proc1600___install_expanders;
install_eval_expander_92___macro(arg1352_770, arg1353_1197);
}
}
{
obj_t arg1355_776;
arg1355_776 = symbol1601___install_expanders;
{
obj_t arg1356_1196;
arg1356_1196 = proc1602___install_expanders;
install_eval_expander_92___macro(arg1355_776, arg1356_1196);
}
}
{
obj_t arg1361_782;
arg1361_782 = symbol1603___install_expanders;
{
obj_t arg1363_1195;
arg1363_1195 = proc1604___install_expanders;
install_eval_expander_92___macro(arg1361_782, arg1363_1195);
}
}
{
obj_t arg1365_788;
arg1365_788 = symbol1605___install_expanders;
{
obj_t arg1367_1194;
arg1367_1194 = proc1606___install_expanders;
return install_eval_expander_92___macro(arg1365_788, arg1367_1194);
}
}
}


/* _install-all-expanders! */obj_t _install_all_expanders__218___install_expanders(obj_t env_1224)
{
return install_all_expanders__168___install_expanders();
}


/* arg1367 */obj_t arg1367___install_expanders(obj_t env_1225, obj_t x_1226, obj_t e_1227)
{
{
obj_t x_1324;
obj_t e_1325;
x_1324 = x_1226;
e_1325 = e_1227;
return expand_eval_case_113___expander_case(x_1324, e_1325);
}
}


/* arg1363 */obj_t arg1363___install_expanders(obj_t env_1228, obj_t x_1229, obj_t e_1230)
{
{
obj_t x_1326;
obj_t e_1327;
x_1326 = x_1229;
e_1327 = e_1230;
return expand_eval_define_struct_250___expander_struct(x_1326, e_1327);
}
}


/* arg1356 */obj_t arg1356___install_expanders(obj_t env_1231, obj_t x_1232, obj_t e_1233)
{
{
obj_t x_1328;
obj_t e_1329;
x_1328 = x_1232;
e_1329 = e_1233;
return expand_eval_define_inline_157___expander_define(x_1328, e_1329);
}
}


/* arg1353 */obj_t arg1353___install_expanders(obj_t env_1234, obj_t x_1235, obj_t e_1236)
{
{
obj_t x_1330;
obj_t e_1331;
x_1330 = x_1235;
e_1331 = e_1236;
return expand_eval_define_165___expander_define(x_1330, e_1331);
}
}


/* arg1350 */obj_t arg1350___install_expanders(obj_t env_1237, obj_t x_1238, obj_t e_1239)
{
{
obj_t x_1332;
obj_t e_1333;
x_1332 = x_1238;
e_1333 = e_1239;
return expand_eval_labels_169___expander_let(x_1332, e_1333);
}
}


/* arg1347 */obj_t arg1347___install_expanders(obj_t env_1240, obj_t x_1241, obj_t e_1242)
{
{
obj_t x_1334;
obj_t e_1335;
x_1334 = x_1241;
e_1335 = e_1242;
return expand_eval_letrec_133___expander_let(x_1334, e_1335);
}
}


/* arg1343 */obj_t arg1343___install_expanders(obj_t env_1243, obj_t x_1244, obj_t e_1245)
{
{
obj_t x_1336;
obj_t e_1337;
x_1336 = x_1244;
e_1337 = e_1245;
return expand_eval_let__60___expander_let(x_1336, e_1337);
}
}


/* arg1339 */obj_t arg1339___install_expanders(obj_t env_1246, obj_t x_1247, obj_t e_1248)
{
{
obj_t x_1338;
obj_t e_1339;
x_1338 = x_1247;
e_1339 = e_1248;
return expand_eval_let_110___expander_let(x_1338, e_1339);
}
}


/* arg1334 */obj_t arg1334___install_expanders(obj_t env_1249, obj_t x_1250, obj_t e_1251)
{
{
obj_t x_1340;
obj_t e_1341;
x_1340 = x_1250;
e_1341 = e_1251;
return expand_eval_lambda_55___expander_define(x_1340, e_1341);
}
}


/* arg1285 */obj_t arg1285___install_expanders(obj_t env_1252, obj_t x_1253, obj_t e_1254)
{
{
obj_t x_685;
obj_t e_686;
x_685 = x_1253;
e_686 = e_1254;
{
obj_t si_692;
obj_t alors_693;
if(PAIRP(x_685)){
obj_t cdr_214_210_698;
cdr_214_210_698 = CDR(x_685);
{
bool_t test_1474;
{
obj_t aux_1475;
aux_1475 = CAR(x_685);
test_1474 = (aux_1475==symbol1544___install_expanders);
}
if(test_1474){
if(PAIRP(cdr_214_210_698)){
obj_t cdr_219_190_701;
cdr_219_190_701 = CDR(cdr_214_210_698);
if(PAIRP(cdr_219_190_701)){
obj_t cdr_224_17_703;
cdr_224_17_703 = CDR(cdr_219_190_701);
if(PAIRP(cdr_224_17_703)){
bool_t test_1486;
{
obj_t aux_1487;
aux_1487 = CDR(cdr_224_17_703);
test_1486 = (aux_1487==BNIL);
}
if(test_1486){
obj_t arg1308_1142;
obj_t arg1309_1143;
obj_t arg1310_1144;
obj_t arg1311_1145;
arg1308_1142 = symbol1544___install_expanders;
arg1309_1143 = expand_test_227___install_expanders(CAR(cdr_214_210_698), e_686);
arg1310_1144 = PROCEDURE_ENTRY(e_686)(e_686, CAR(cdr_219_190_701), e_686, BEOA);
arg1311_1145 = PROCEDURE_ENTRY(e_686)(e_686, CAR(cdr_224_17_703), e_686, BEOA);
{
obj_t list1314_1147;
{
obj_t arg1315_1148;
{
obj_t arg1316_1149;
{
obj_t arg1319_1150;
arg1319_1150 = MAKE_PAIR(BNIL, BNIL);
arg1316_1149 = MAKE_PAIR(arg1311_1145, arg1319_1150);
}
arg1315_1148 = MAKE_PAIR(arg1310_1144, arg1316_1149);
}
list1314_1147 = MAKE_PAIR(arg1309_1143, arg1315_1148);
}
return cons__138___r4_pairs_and_lists_6_3(arg1308_1142, list1314_1147);
}
}
 else {
FAILURE(string1607___install_expanders,string1608___install_expanders,x_685);}
}
 else {
obj_t cdr_249_30_712;
cdr_249_30_712 = CDR(cdr_214_210_698);
{
bool_t test_1505;
{
obj_t aux_1506;
aux_1506 = CDR(cdr_249_30_712);
test_1505 = (aux_1506==BNIL);
}
if(test_1505){
si_692 = CAR(cdr_214_210_698);
alors_693 = CAR(cdr_249_30_712);
{
obj_t arg1322_730;
obj_t arg1323_731;
obj_t arg1324_732;
arg1322_730 = symbol1544___install_expanders;
arg1323_731 = expand_test_227___install_expanders(si_692, e_686);
arg1324_732 = PROCEDURE_ENTRY(e_686)(e_686, alors_693, e_686, BEOA);
{
obj_t list1326_734;
{
obj_t arg1328_735;
{
obj_t arg1330_736;
{
obj_t arg1331_737;
arg1331_737 = MAKE_PAIR(BNIL, BNIL);
arg1330_736 = MAKE_PAIR(BUNSPEC, arg1331_737);
}
arg1328_735 = MAKE_PAIR(arg1324_732, arg1330_736);
}
list1326_734 = MAKE_PAIR(arg1323_731, arg1328_735);
}
return cons__138___r4_pairs_and_lists_6_3(arg1322_730, list1326_734);
}
}
}
 else {
FAILURE(string1607___install_expanders,string1608___install_expanders,x_685);}
}
}
}
 else {
FAILURE(string1607___install_expanders,string1608___install_expanders,x_685);}
}
 else {
FAILURE(string1607___install_expanders,string1608___install_expanders,x_685);}
}
 else {
FAILURE(string1607___install_expanders,string1608___install_expanders,x_685);}
}
}
 else {
FAILURE(string1607___install_expanders,string1608___install_expanders,x_685);}
}
}
}


/* arg1282 */obj_t arg1282___install_expanders(obj_t env_1255, obj_t x_1256, obj_t e_1257)
{
{
obj_t x_1342;
x_1342 = x_1256;
return x_1342;
}
}


/* arg1240 */obj_t arg1240___install_expanders(obj_t env_1258, obj_t x_1259, obj_t e_1260)
{
{
obj_t x_635;
obj_t e_636;
x_635 = x_1259;
e_636 = e_1260;
{
obj_t vars_638;
obj_t call_639;
obj_t exprs_640;
if(PAIRP(x_635)){
obj_t cdr_190_184_645;
cdr_190_184_645 = CDR(x_635);
if(PAIRP(cdr_190_184_645)){
obj_t cdr_195_37_647;
cdr_195_37_647 = CDR(cdr_190_184_645);
if(PAIRP(cdr_195_37_647)){
vars_638 = CAR(cdr_190_184_645);
call_639 = CAR(cdr_195_37_647);
exprs_640 = CDR(cdr_195_37_647);
{
obj_t arg1250_652;
{
obj_t arg1251_653;
obj_t arg1252_654;
obj_t arg1253_655;
arg1251_653 = symbol1609___install_expanders;
{
obj_t arg1259_661;
arg1259_661 = symbol1542___install_expanders;
{
obj_t list1263_664;
{
obj_t arg1265_665;
{
obj_t arg1267_666;
arg1267_666 = MAKE_PAIR(BNIL, BNIL);
arg1265_665 = MAKE_PAIR(call_639, arg1267_666);
}
list1263_664 = MAKE_PAIR(BNIL, arg1265_665);
}
arg1252_654 = cons__138___r4_pairs_and_lists_6_3(arg1259_661, list1263_664);
}
}
{
obj_t arg1269_668;
obj_t arg1270_669;
arg1269_668 = symbol1542___install_expanders;
{
obj_t arg1274_673;
arg1274_673 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1270_669 = append_2_18___r4_pairs_and_lists_6_3(exprs_640, arg1274_673);
}
{
obj_t list1271_670;
{
obj_t arg1272_671;
arg1272_671 = MAKE_PAIR(arg1270_669, BNIL);
list1271_670 = MAKE_PAIR(vars_638, arg1272_671);
}
arg1253_655 = cons__138___r4_pairs_and_lists_6_3(arg1269_668, list1271_670);
}
}
{
obj_t list1255_657;
{
obj_t arg1256_658;
{
obj_t arg1257_659;
arg1257_659 = MAKE_PAIR(BNIL, BNIL);
arg1256_658 = MAKE_PAIR(arg1253_655, arg1257_659);
}
list1255_657 = MAKE_PAIR(arg1252_654, arg1256_658);
}
arg1250_652 = cons__138___r4_pairs_and_lists_6_3(arg1251_653, list1255_657);
}
}
return PROCEDURE_ENTRY(e_636)(e_636, arg1250_652, e_636, BEOA);
}
}
 else {
FAILURE(string1610___install_expanders,string1608___install_expanders,x_635);}
}
 else {
FAILURE(string1610___install_expanders,string1608___install_expanders,x_635);}
}
 else {
FAILURE(string1610___install_expanders,string1608___install_expanders,x_635);}
}
}
}


/* arg1211 */obj_t arg1211___install_expanders(obj_t env_1261, obj_t x_1262, obj_t e_1263)
{
{
obj_t x_595;
obj_t e_596;
x_595 = x_1262;
e_596 = e_1263;
{
obj_t body_598;
obj_t exp_599;
if(PAIRP(x_595)){
obj_t cdr_173_176_604;
cdr_173_176_604 = CDR(x_595);
if(PAIRP(cdr_173_176_604)){
body_598 = CAR(cdr_173_176_604);
exp_599 = CDR(cdr_173_176_604);
{
obj_t arg1220_608;
obj_t arg1221_609;
obj_t arg1222_610;
arg1220_608 = symbol1583___install_expanders;
arg1221_609 = PROCEDURE_ENTRY(e_596)(e_596, body_598, e_596, BEOA);
{
obj_t arg1226_614;
obj_t arg1228_615;
if(NULLP(exp_599)){
arg1226_614 = BNIL;
}
 else {
obj_t head1009_618;
head1009_618 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1007_619;
obj_t tail1010_620;
l1007_619 = exp_599;
tail1010_620 = head1009_618;
lname1008_621:
if(NULLP(l1007_619)){
arg1226_614 = CDR(head1009_618);
}
 else {
obj_t newtail1011_623;
{
obj_t arg1232_625;
arg1232_625 = PROCEDURE_ENTRY(e_596)(e_596, CAR(l1007_619), e_596, BEOA);
newtail1011_623 = MAKE_PAIR(arg1232_625, BNIL);
}
SET_CDR(tail1010_620, newtail1011_623);
{
obj_t tail1010_1573;
obj_t l1007_1571;
l1007_1571 = CDR(l1007_619);
tail1010_1573 = newtail1011_623;
tail1010_620 = tail1010_1573;
l1007_619 = l1007_1571;
goto lname1008_621;
}
}
}
}
arg1228_615 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1222_610 = append_2_18___r4_pairs_and_lists_6_3(arg1226_614, arg1228_615);
}
{
obj_t list1223_611;
{
obj_t arg1224_612;
arg1224_612 = MAKE_PAIR(arg1222_610, BNIL);
list1223_611 = MAKE_PAIR(arg1221_609, arg1224_612);
}
return cons__138___r4_pairs_and_lists_6_3(arg1220_608, list1223_611);
}
}
}
 else {
FAILURE(string1611___install_expanders,string1608___install_expanders,x_595);}
}
 else {
FAILURE(string1611___install_expanders,string1608___install_expanders,x_595);}
}
}
}


/* arg1185 */obj_t arg1185___install_expanders(obj_t env_1264, obj_t x_1265, obj_t e_1266)
{
{
obj_t x_560;
obj_t e_561;
x_560 = x_1265;
e_561 = e_1266;
{
obj_t exit_563;
obj_t body_564;
if(PAIRP(x_560)){
obj_t cdr_154_75_569;
cdr_154_75_569 = CDR(x_560);
if(PAIRP(cdr_154_75_569)){
obj_t car_157_166_571;
obj_t cdr_158_238_572;
car_157_166_571 = CAR(cdr_154_75_569);
cdr_158_238_572 = CDR(cdr_154_75_569);
if(PAIRP(car_157_166_571)){
bool_t test_1592;
{
obj_t aux_1593;
aux_1593 = CDR(car_157_166_571);
test_1592 = (aux_1593==BNIL);
}
if(test_1592){
if((cdr_158_238_572==BNIL)){
FAILURE(string1612___install_expanders,string1608___install_expanders,x_560);}
 else {
exit_563 = CAR(car_157_166_571);
body_564 = cdr_158_238_572;
{
obj_t arg1196_580;
obj_t arg1197_581;
obj_t arg1199_582;
arg1196_580 = symbol1581___install_expanders;
{
obj_t list1206_589;
list1206_589 = MAKE_PAIR(BNIL, BNIL);
arg1197_581 = cons__138___r4_pairs_and_lists_6_3(exit_563, list1206_589);
}
{
obj_t arg1209_591;
arg1209_591 = normalize_progn_143___progn(body_564);
arg1199_582 = PROCEDURE_ENTRY(e_561)(e_561, arg1209_591, e_561, BEOA);
}
{
obj_t list1201_584;
{
obj_t arg1202_585;
{
obj_t arg1203_586;
arg1203_586 = MAKE_PAIR(BNIL, BNIL);
arg1202_585 = MAKE_PAIR(arg1199_582, arg1203_586);
}
list1201_584 = MAKE_PAIR(arg1197_581, arg1202_585);
}
return cons__138___r4_pairs_and_lists_6_3(arg1196_580, list1201_584);
}
}
}
}
 else {
FAILURE(string1612___install_expanders,string1608___install_expanders,x_560);}
}
 else {
FAILURE(string1612___install_expanders,string1608___install_expanders,x_560);}
}
 else {
FAILURE(string1612___install_expanders,string1608___install_expanders,x_560);}
}
 else {
FAILURE(string1612___install_expanders,string1608___install_expanders,x_560);}
}
}
}


/* arg1162 */obj_t arg1162___install_expanders(obj_t env_1267, obj_t x_1268, obj_t e_1269)
{
{
obj_t x_525;
obj_t e_526;
x_525 = x_1268;
e_526 = e_1269;
if(PAIRP(x_525)){
obj_t cdr_130_105_535;
cdr_130_105_535 = CDR(x_525);
if(PAIRP(cdr_130_105_535)){
obj_t cdr_135_194_537;
cdr_135_194_537 = CDR(cdr_130_105_535);
if(PAIRP(cdr_135_194_537)){
obj_t cdr_140_144_539;
cdr_140_144_539 = CDR(cdr_135_194_537);
if(PAIRP(cdr_140_144_539)){
bool_t test_1624;
{
obj_t aux_1625;
aux_1625 = CDR(cdr_140_144_539);
test_1624 = (aux_1625==BNIL);
}
if(test_1624){
obj_t arg1174_1010;
obj_t arg1175_1011;
obj_t arg1176_1012;
obj_t arg1177_1013;
arg1174_1010 = symbol1579___install_expanders;
arg1175_1011 = PROCEDURE_ENTRY(e_526)(e_526, CAR(cdr_130_105_535), e_526, BEOA);
arg1176_1012 = PROCEDURE_ENTRY(e_526)(e_526, CAR(cdr_135_194_537), e_526, BEOA);
arg1177_1013 = PROCEDURE_ENTRY(e_526)(e_526, CAR(cdr_140_144_539), e_526, BEOA);
{
obj_t list1179_1015;
{
obj_t arg1180_1016;
{
obj_t arg1181_1017;
{
obj_t arg1182_1018;
arg1182_1018 = MAKE_PAIR(BNIL, BNIL);
arg1181_1017 = MAKE_PAIR(arg1177_1013, arg1182_1018);
}
arg1180_1016 = MAKE_PAIR(arg1176_1012, arg1181_1017);
}
list1179_1015 = MAKE_PAIR(arg1175_1011, arg1180_1016);
}
return cons__138___r4_pairs_and_lists_6_3(arg1174_1010, list1179_1015);
}
}
 else {
FAILURE(string1613___install_expanders,string1614___install_expanders,x_525);}
}
 else {
FAILURE(string1613___install_expanders,string1614___install_expanders,x_525);}
}
 else {
FAILURE(string1613___install_expanders,string1614___install_expanders,x_525);}
}
 else {
FAILURE(string1613___install_expanders,string1614___install_expanders,x_525);}
}
 else {
FAILURE(string1613___install_expanders,string1614___install_expanders,x_525);}
}
}


/* arg1136 */obj_t arg1136___install_expanders(obj_t env_1270, obj_t x_1271, obj_t e_1272)
{
{
obj_t x_483;
obj_t e_484;
x_483 = x_1271;
e_484 = e_1272;
{
obj_t body_486;
if(PAIRP(x_483)){
body_486 = CDR(x_483);
{
obj_t l_492;
l_492 = body_486;
loop_493:
if(NULLP(l_492)){
{
obj_t new_495;
{
obj_t arg1143_498;
obj_t arg1144_499;
arg1143_498 = symbol1577___install_expanders;
{
obj_t arg1147_502;
obj_t arg1148_503;
if(NULLP(body_486)){
arg1147_502 = BNIL;
}
 else {
obj_t head1004_506;
head1004_506 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_507;
obj_t tail1005_508;
l1002_507 = body_486;
tail1005_508 = head1004_506;
lname1003_509:
if(NULLP(l1002_507)){
arg1147_502 = CDR(head1004_506);
}
 else {
obj_t newtail1006_511;
{
obj_t arg1152_513;
arg1152_513 = PROCEDURE_ENTRY(e_484)(e_484, CAR(l1002_507), e_484, BEOA);
newtail1006_511 = MAKE_PAIR(arg1152_513, BNIL);
}
SET_CDR(tail1005_508, newtail1006_511);
{
obj_t tail1005_1664;
obj_t l1002_1662;
l1002_1662 = CDR(l1002_507);
tail1005_1664 = newtail1006_511;
tail1005_508 = tail1005_1664;
l1002_507 = l1002_1662;
goto lname1003_509;
}
}
}
}
arg1148_503 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1144_499 = append_2_18___r4_pairs_and_lists_6_3(arg1147_502, arg1148_503);
}
{
obj_t list1145_500;
list1145_500 = MAKE_PAIR(arg1144_499, BNIL);
new_495 = cons__138___r4_pairs_and_lists_6_3(arg1143_498, list1145_500);
}
}
{
obj_t aux_1669;
aux_1669 = CAR(new_495);
SET_CAR(x_483, aux_1669);
}
{
obj_t aux_1672;
aux_1672 = CDR(new_495);
SET_CDR(x_483, aux_1672);
}
return x_483;
}
}
 else {
if(PAIRP(l_492)){
{
obj_t l_1677;
l_1677 = CDR(l_492);
l_492 = l_1677;
goto loop_493;
}
}
 else {
FAILURE(string1615___install_expanders,string1608___install_expanders,x_483);}
}
}
}
 else {
FAILURE(string1615___install_expanders,string1608___install_expanders,x_483);}
}
}
}


/* arg1110 */obj_t arg1110___install_expanders(obj_t env_1273, obj_t x_1274, obj_t e_1275)
{
{
obj_t x_449;
obj_t e_450;
x_449 = x_1274;
e_450 = e_1275;
{
obj_t exp_452;
if(PAIRP(x_449)){
obj_t cdr_107_0_457;
cdr_107_0_457 = CDR(x_449);
if(PAIRP(cdr_107_0_457)){
bool_t test_1687;
{
obj_t aux_1688;
aux_1688 = CDR(cdr_107_0_457);
test_1687 = (aux_1688==BNIL);
}
if(test_1687){
exp_452 = CAR(cdr_107_0_457);
{
obj_t arg1118_463;
obj_t arg1119_464;
arg1118_463 = symbol1616___install_expanders;
{
obj_t arg1124_469;
obj_t arg1126_471;
arg1124_469 = symbol1542___install_expanders;
arg1126_471 = PROCEDURE_ENTRY(e_450)(e_450, exp_452, e_450, BEOA);
{
obj_t list1128_473;
{
obj_t arg1129_474;
{
obj_t arg1130_475;
arg1130_475 = MAKE_PAIR(BNIL, BNIL);
arg1129_474 = MAKE_PAIR(arg1126_471, arg1130_475);
}
list1128_473 = MAKE_PAIR(BNIL, arg1129_474);
}
arg1119_464 = cons__138___r4_pairs_and_lists_6_3(arg1124_469, list1128_473);
}
}
{
obj_t list1121_466;
{
obj_t arg1122_467;
arg1122_467 = MAKE_PAIR(BNIL, BNIL);
list1121_466 = MAKE_PAIR(arg1119_464, arg1122_467);
}
return cons__138___r4_pairs_and_lists_6_3(arg1118_463, list1121_466);
}
}
}
 else {
FAILURE(string1617___install_expanders,string1608___install_expanders,x_449);}
}
 else {
FAILURE(string1617___install_expanders,string1608___install_expanders,x_449);}
}
 else {
FAILURE(string1617___install_expanders,string1608___install_expanders,x_449);}
}
}
}


/* arg1106 */obj_t arg1106___install_expanders(obj_t env_1276, obj_t x_1277, obj_t e_1278)
{
{
obj_t x_442;
obj_t e_443;
x_442 = x_1277;
e_443 = e_1278;
{
obj_t arg1108_943;
arg1108_943 = expand_define_pattern_97___eval(x_442);
return PROCEDURE_ENTRY(e_443)(e_443, arg1108_943, e_443, BEOA);
}
}
}


/* arg1102 */obj_t arg1102___install_expanders(obj_t env_1279, obj_t x_1280, obj_t e_1281)
{
{
obj_t x_435;
obj_t e_436;
x_435 = x_1280;
e_436 = e_1281;
{
obj_t arg1104_942;
arg1104_942 = expand_match_lambda_130___match_expand(x_435);
return PROCEDURE_ENTRY(e_436)(e_436, arg1104_942, e_436, BEOA);
}
}
}


/* arg1098 */obj_t arg1098___install_expanders(obj_t env_1282, obj_t x_1283, obj_t e_1284)
{
{
obj_t x_428;
obj_t e_429;
x_428 = x_1283;
e_429 = e_1284;
{
obj_t arg1100_941;
arg1100_941 = expand_match_case_143___match_expand(x_428);
return PROCEDURE_ENTRY(e_429)(e_429, arg1100_941, e_429, BEOA);
}
}
}


/* arg1095 */obj_t arg1095___install_expanders(obj_t env_1285, obj_t x_1286, obj_t e_1287)
{
{
obj_t x_1344;
obj_t e_1345;
x_1344 = x_1286;
e_1345 = e_1287;
return expand_try_212___expander_try(x_1344, e_1345);
}
}


/* arg1092 */obj_t arg1092___install_expanders(obj_t env_1288, obj_t x_1289, obj_t e_1290)
{
{
obj_t x_1346;
obj_t e_1347;
x_1346 = x_1289;
e_1347 = e_1290;
return expand_do_31___expander_do(x_1346, e_1347);
}
}


/* arg1088 */obj_t arg1088___install_expanders(obj_t env_1291, obj_t x_1292, obj_t e_1293)
{
{
obj_t x_409;
obj_t e_410;
x_409 = x_1292;
e_410 = e_1293;
{
obj_t arg1090_940;
arg1090_940 = expand_cond_95___expander_bool(x_409);
return PROCEDURE_ENTRY(e_410)(e_410, arg1090_940, e_410, BEOA);
}
}
}


/* arg1084 */obj_t arg1084___install_expanders(obj_t env_1294, obj_t x_1295, obj_t e_1296)
{
{
obj_t x_402;
obj_t e_403;
x_402 = x_1295;
e_403 = e_1296;
{
obj_t arg1086_939;
arg1086_939 = expand_and_10___expander_bool(x_402);
return PROCEDURE_ENTRY(e_403)(e_403, arg1086_939, e_403, BEOA);
}
}
}


/* arg1080 */obj_t arg1080___install_expanders(obj_t env_1297, obj_t x_1298, obj_t e_1299)
{
{
obj_t x_395;
obj_t e_396;
x_395 = x_1298;
e_396 = e_1299;
{
obj_t arg1082_938;
arg1082_938 = expand_or_72___expander_bool(x_395);
return PROCEDURE_ENTRY(e_396)(e_396, arg1082_938, e_396, BEOA);
}
}
}


/* arg1077 */obj_t arg1077___install_expanders(obj_t env_1300, obj_t x_1301, obj_t e_1302)
{
{
obj_t x_1348;
obj_t e_1349;
x_1348 = x_1301;
e_1349 = e_1302;
return expand_define_expander_27___eval(x_1348, e_1349);
}
}


/* arg1073 */obj_t arg1073___install_expanders(obj_t env_1303, obj_t x_1304, obj_t e_1305)
{
{
obj_t x_1350;
obj_t e_1351;
x_1350 = x_1304;
e_1351 = e_1305;
return expand_define_hygien_macro_18___eval(x_1350, e_1351);
}
}


/* arg1069 */obj_t arg1069___install_expanders(obj_t env_1306, obj_t x_1307, obj_t e_1308)
{
{
obj_t x_1352;
obj_t e_1353;
x_1352 = x_1307;
e_1353 = e_1308;
return expand_define_macro_35___eval(x_1352, e_1353);
}
}


/* arg1065 */obj_t arg1065___install_expanders(obj_t env_1309, obj_t x_1310, obj_t e_1311)
{
{
obj_t x_370;
obj_t e_371;
x_370 = x_1310;
e_371 = e_1311;
{
obj_t arg1067_937;
arg1067_937 = quasiquotation___expander_quote(BINT(((long)1)), x_370);
return PROCEDURE_ENTRY(e_371)(e_371, arg1067_937, e_371, BEOA);
}
}
}


/* arg1061 */obj_t arg1061___install_expanders(obj_t env_1312, obj_t x_1313, obj_t e_1314)
{
{
obj_t x_1354;
obj_t e_1355;
x_1354 = x_1313;
e_1355 = e_1314;
return expand_quote_117___expander_quote(x_1354, e_1355);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___install_expanders()
{
module_initialization_70___error(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___macro(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_quote(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_let(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_bool(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_case(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_define(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_do(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_try(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___expander_struct(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___eval(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___progn(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___lalr_expand(((long)0), "__INSTALL_EXPANDERS");
module_initialization_70___rgc_expand(((long)0), "__INSTALL_EXPANDERS");
return module_initialization_70___match_expand(((long)0), "__INSTALL_EXPANDERS");
}

