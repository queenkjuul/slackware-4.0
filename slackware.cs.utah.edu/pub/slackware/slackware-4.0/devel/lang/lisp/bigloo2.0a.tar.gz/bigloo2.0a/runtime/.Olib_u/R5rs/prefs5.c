/*===========================================================================*/
/*   (R5rs/prefs5.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
obj_t set_1_241___r5_syntax_prefs = BUNSPEC;
obj_t undefined1___r5_syntax_prefs = BUNSPEC;
static obj_t toplevel_init_63___r5_syntax_prefs();
obj_t lambda1___r5_syntax_prefs = BUNSPEC;
obj_t define1___r5_syntax_prefs = BUNSPEC;
obj_t begin1___r5_syntax_prefs = BUNSPEC;
obj_t quote1___r5_syntax_prefs = BUNSPEC;
extern obj_t module_initialization_70___r5_syntax_prefs(long, char *);
obj_t if1___r5_syntax_prefs = BUNSPEC;
obj_t suffix_character_4___r5_syntax_prefs = BUNSPEC;
static obj_t require_initialization_114___r5_syntax_prefs = BUNSPEC;
static obj_t *__cnst;

DEFINE_STRING( string1147___r5_syntax_prefs, string1147___r5_syntax_prefs1149, "SET!", 4 );
DEFINE_STRING( string1146___r5_syntax_prefs, string1146___r5_syntax_prefs1150, "IF", 2 );
DEFINE_STRING( string1145___r5_syntax_prefs, string1145___r5_syntax_prefs1151, "LAMBDA", 6 );
DEFINE_STRING( string1144___r5_syntax_prefs, string1144___r5_syntax_prefs1152, "QUOTE", 5 );
DEFINE_STRING( string1143___r5_syntax_prefs, string1143___r5_syntax_prefs1153, "DEFINE", 6 );
DEFINE_STRING( string1142___r5_syntax_prefs, string1142___r5_syntax_prefs1154, "BEGIN", 5 );


/* module-initialization */obj_t module_initialization_70___r5_syntax_prefs(long checksum_462, char * from_463)
{
if(CBOOL(require_initialization_114___r5_syntax_prefs)){
require_initialization_114___r5_syntax_prefs = BBOOL(((bool_t)0));
toplevel_init_63___r5_syntax_prefs();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___r5_syntax_prefs()
{
{
char * aux_468;
aux_468 = BSTRING_TO_STRING(string1142___r5_syntax_prefs);
begin1___r5_syntax_prefs = string_to_symbol(aux_468);
}
{
char * aux_471;
aux_471 = BSTRING_TO_STRING(string1143___r5_syntax_prefs);
define1___r5_syntax_prefs = string_to_symbol(aux_471);
}
{
char * aux_474;
aux_474 = BSTRING_TO_STRING(string1144___r5_syntax_prefs);
quote1___r5_syntax_prefs = string_to_symbol(aux_474);
}
{
char * aux_477;
aux_477 = BSTRING_TO_STRING(string1145___r5_syntax_prefs);
lambda1___r5_syntax_prefs = string_to_symbol(aux_477);
}
{
char * aux_480;
aux_480 = BSTRING_TO_STRING(string1146___r5_syntax_prefs);
if1___r5_syntax_prefs = string_to_symbol(aux_480);
}
{
char * aux_483;
aux_483 = BSTRING_TO_STRING(string1147___r5_syntax_prefs);
set_1_241___r5_syntax_prefs = string_to_symbol(aux_483);
}
{
obj_t list1006_310;
list1006_310 = MAKE_PAIR(BUNSPEC, BNIL);
undefined1___r5_syntax_prefs = list1006_310;
}
return (suffix_character_4___r5_syntax_prefs = BCHAR(((unsigned char)'|')),
BUNSPEC);
}

