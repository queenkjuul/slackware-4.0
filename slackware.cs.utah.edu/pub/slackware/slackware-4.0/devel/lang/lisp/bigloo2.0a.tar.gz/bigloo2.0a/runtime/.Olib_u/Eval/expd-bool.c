/*===========================================================================*/
/*   (Eval/expd-bool.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t symbol1473___expander_bool = BUNSPEC;
static obj_t symbol1472___expander_bool = BUNSPEC;
static obj_t symbol1471___expander_bool = BUNSPEC;
static obj_t symbol1469___expander_bool = BUNSPEC;
static obj_t symbol1470___expander_bool = BUNSPEC;
static obj_t symbol1468___expander_bool = BUNSPEC;
static obj_t symbol1467___expander_bool = BUNSPEC;
static obj_t symbol1465___expander_bool = BUNSPEC;
static obj_t symbol1458___expander_bool = BUNSPEC;
static obj_t symbol1457___expander_bool = BUNSPEC;
static obj_t symbol1456___expander_bool = BUNSPEC;
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t list1464___expander_bool = BUNSPEC;
static obj_t loop_1453___expander_bool(obj_t, obj_t);
static obj_t _expand_or_196___expander_bool(obj_t, obj_t);
extern obj_t replace__160___progn(obj_t, obj_t);
static obj_t _expand_and_238___expander_bool(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t string_to_bstring(char *);
static obj_t loop___expander_bool(obj_t, obj_t);
extern obj_t expand_or_72___expander_bool(obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___expander_bool(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t expand_and_10___expander_bool(obj_t);
static obj_t _expand_cond_204___expander_bool(obj_t, obj_t);
extern long list_length(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t expand_cond_95___expander_bool(obj_t);
static obj_t get_new_test_name_58___expander_bool(char *);
static obj_t imported_modules_init_94___expander_bool();
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t require_initialization_114___expander_bool = BUNSPEC;
extern obj_t normalize_body_95___progn(obj_t);
static obj_t cnst_init_137___expander_bool();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_or_env_13___expander_bool, _expand_or_196___expander_bool1475, _expand_or_196___expander_bool, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( expand_and_env_71___expander_bool, _expand_and_238___expander_bool1476, _expand_and_238___expander_bool, 0L, 1 );
DEFINE_STRING( string1466___expander_bool, string1466___expander_bool1477, "cond-clause", 11 );
DEFINE_STRING( string1463___expander_bool, string1463___expander_bool1478, "and", 3 );
DEFINE_STRING( string1462___expander_bool, string1462___expander_bool1479, "Illegal form", 12 );
DEFINE_STRING( string1461___expander_bool, string1461___expander_bool1480, "or", 2 );
DEFINE_STRING( string1459___expander_bool, string1459___expander_bool1481, "cer", 3 );
DEFINE_STRING( string1460___expander_bool, string1460___expander_bool1482, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string1455___expander_bool, string1455___expander_bool1483, "_", 1 );
DEFINE_STRING( string1454___expander_bool, string1454___expander_bool1484, "test_", 5 );
DEFINE_EXPORT_PROCEDURE( expand_cond_env_147___expander_bool, _expand_cond_204___expander_bool1485, _expand_cond_204___expander_bool, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___expander_bool(long checksum_931, char * from_932)
{
if(CBOOL(require_initialization_114___expander_bool)){
require_initialization_114___expander_bool = BBOOL(((bool_t)0));
cnst_init_137___expander_bool();
imported_modules_init_94___expander_bool();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_bool()
{
symbol1456___expander_bool = string_to_symbol("NON-USER");
symbol1457___expander_bool = string_to_symbol("LET");
symbol1458___expander_bool = string_to_symbol("IF");
symbol1465___expander_bool = string_to_symbol("ELSE");
list1464___expander_bool = MAKE_PAIR(symbol1465___expander_bool, BNIL);
symbol1467___expander_bool = string_to_symbol("OR");
symbol1468___expander_bool = string_to_symbol("COND");
symbol1469___expander_bool = string_to_symbol("=>");
symbol1470___expander_bool = string_to_symbol("TEST-RESULT");
symbol1471___expander_bool = string_to_symbol("THUNK2");
symbol1472___expander_bool = string_to_symbol("LAMBDA");
return (symbol1473___expander_bool = string_to_symbol("THUNK3"),
BUNSPEC);
}


/* get-new-test-name */obj_t get_new_test_name_58___expander_bool(char * string_1)
{
{
obj_t symbol_320;
{
obj_t arg1007_322;
{
obj_t list1008_323;
{
obj_t arg1010_325;
{
obj_t arg1011_326;
arg1011_326 = MAKE_PAIR(string1454___expander_bool, BNIL);
{
obj_t aux_951;
aux_951 = string_to_bstring(string_1);
arg1010_325 = MAKE_PAIR(aux_951, arg1011_326);
}
}
list1008_323 = MAKE_PAIR(string1455___expander_bool, arg1010_325);
}
arg1007_322 = string_append_106___r4_strings_6_7(list1008_323);
}
symbol_320 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, arg1007_322, BEOA);
}
putprop__88___r4_symbols_6_4(symbol_320, symbol1456___expander_bool, BTRUE);
return symbol_320;
}
}


/* expand-or */obj_t expand_or_72___expander_bool(obj_t exp_2)
{
{
obj_t res_329;
res_329 = loop_1453___expander_bool(exp_2, CDR(exp_2));
return replace__160___progn(exp_2, res_329);
}
}


/* loop_1453 */obj_t loop_1453___expander_bool(obj_t exp_930, obj_t sor_330)
{
if(NULLP(sor_330)){
return BFALSE;
}
 else {
if(PAIRP(sor_330)){
bool_t test_966;
{
obj_t aux_967;
aux_967 = CDR(sor_330);
test_966 = NULLP(aux_967);
}
if(test_966){
return CAR(sor_330);
}
 else {
{
obj_t test_336;
test_336 = get_new_test_name_58___expander_bool("or");
{
obj_t res_337;
{
obj_t arg1025_344;
obj_t arg1026_345;
obj_t arg1027_346;
arg1025_344 = symbol1457___expander_bool;
{
obj_t arg1033_352;
{
obj_t arg1038_356;
arg1038_356 = CAR(sor_330);
{
obj_t list1040_358;
{
obj_t arg1041_359;
arg1041_359 = MAKE_PAIR(BNIL, BNIL);
list1040_358 = MAKE_PAIR(arg1038_356, arg1041_359);
}
arg1033_352 = cons__138___r4_pairs_and_lists_6_3(test_336, list1040_358);
}
}
{
obj_t list1035_354;
list1035_354 = MAKE_PAIR(BNIL, BNIL);
arg1026_345 = cons__138___r4_pairs_and_lists_6_3(arg1033_352, list1035_354);
}
}
{
obj_t arg1043_361;
obj_t arg1044_362;
arg1043_361 = symbol1458___expander_bool;
arg1044_362 = loop_1453___expander_bool(exp_930, CDR(sor_330));
{
obj_t list1046_364;
{
obj_t arg1047_365;
{
obj_t arg1048_366;
{
obj_t arg1049_367;
arg1049_367 = MAKE_PAIR(BNIL, BNIL);
arg1048_366 = MAKE_PAIR(arg1044_362, arg1049_367);
}
arg1047_365 = MAKE_PAIR(test_336, arg1048_366);
}
list1046_364 = MAKE_PAIR(test_336, arg1047_365);
}
arg1027_346 = cons__138___r4_pairs_and_lists_6_3(arg1043_361, list1046_364);
}
}
{
obj_t list1029_348;
{
obj_t arg1030_349;
{
obj_t arg1031_350;
arg1031_350 = MAKE_PAIR(BNIL, BNIL);
arg1030_349 = MAKE_PAIR(arg1027_346, arg1031_350);
}
list1029_348 = MAKE_PAIR(arg1026_345, arg1030_349);
}
res_337 = cons__138___r4_pairs_and_lists_6_3(arg1025_344, list1029_348);
}
}
{
{
bool_t test1018_338;
{
obj_t aux_989;
aux_989 = CAR(sor_330);
test1018_338 = EXTENDED_PAIRP(aux_989);
}
if(test1018_338){
{
obj_t arg1019_339;
obj_t arg1020_340;
obj_t arg1021_341;
arg1019_339 = CAR(res_337);
arg1020_340 = CDR(res_337);
{
obj_t arg1022_342;
arg1022_342 = CAR(sor_330);
{
bool_t test1397_745;
test1397_745 = EXTENDED_PAIRP(arg1022_342);
if(test1397_745){
arg1021_341 = CER(arg1022_342);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1022_342);}
}
}
return MAKE_EXTENDED_PAIR(arg1019_339, arg1020_340, arg1021_341);
}
}
 else {
return res_337;
}
}
}
}
}
}
}
 else {
FAILURE(string1461___expander_bool,string1462___expander_bool,exp_930);}
}
}


/* _expand-or */obj_t _expand_or_196___expander_bool(obj_t env_923, obj_t exp_924)
{
return expand_or_72___expander_bool(exp_924);
}


/* expand-and */obj_t expand_and_10___expander_bool(obj_t exp_3)
{
{
obj_t res_371;
res_371 = loop___expander_bool(exp_3, CDR(exp_3));
return replace__160___progn(exp_3, res_371);
}
}


/* loop */obj_t loop___expander_bool(obj_t exp_929, obj_t sand_372)
{
if(NULLP(sand_372)){
return BTRUE;
}
 else {
if(PAIRP(sand_372)){
bool_t test_1010;
{
obj_t aux_1011;
aux_1011 = CDR(sand_372);
test_1010 = NULLP(aux_1011);
}
if(test_1010){
return CAR(sand_372);
}
 else {
{
obj_t test_378;
test_378 = get_new_test_name_58___expander_bool("and");
{
obj_t res_379;
{
obj_t arg1065_386;
obj_t arg1066_387;
obj_t arg1067_388;
arg1065_386 = symbol1457___expander_bool;
{
obj_t arg1076_394;
{
obj_t arg1080_398;
arg1080_398 = CAR(sand_372);
{
obj_t list1082_400;
{
obj_t arg1083_401;
arg1083_401 = MAKE_PAIR(BNIL, BNIL);
list1082_400 = MAKE_PAIR(arg1080_398, arg1083_401);
}
arg1076_394 = cons__138___r4_pairs_and_lists_6_3(test_378, list1082_400);
}
}
{
obj_t list1078_396;
list1078_396 = MAKE_PAIR(BNIL, BNIL);
arg1066_387 = cons__138___r4_pairs_and_lists_6_3(arg1076_394, list1078_396);
}
}
{
obj_t arg1085_403;
obj_t arg1086_404;
arg1085_403 = symbol1458___expander_bool;
arg1086_404 = loop___expander_bool(exp_929, CDR(sand_372));
{
obj_t list1088_406;
{
obj_t arg1089_407;
{
obj_t arg1090_408;
{
obj_t arg1091_409;
arg1091_409 = MAKE_PAIR(BNIL, BNIL);
arg1090_408 = MAKE_PAIR(BFALSE, arg1091_409);
}
arg1089_407 = MAKE_PAIR(arg1086_404, arg1090_408);
}
list1088_406 = MAKE_PAIR(test_378, arg1089_407);
}
arg1067_388 = cons__138___r4_pairs_and_lists_6_3(arg1085_403, list1088_406);
}
}
{
obj_t list1069_390;
{
obj_t arg1070_391;
{
obj_t arg1072_392;
arg1072_392 = MAKE_PAIR(BNIL, BNIL);
arg1070_391 = MAKE_PAIR(arg1067_388, arg1072_392);
}
list1069_390 = MAKE_PAIR(arg1066_387, arg1070_391);
}
res_379 = cons__138___r4_pairs_and_lists_6_3(arg1065_386, list1069_390);
}
}
{
{
bool_t test1058_380;
{
obj_t aux_1033;
aux_1033 = CAR(sand_372);
test1058_380 = EXTENDED_PAIRP(aux_1033);
}
if(test1058_380){
{
obj_t arg1059_381;
obj_t arg1060_382;
obj_t arg1061_383;
arg1059_381 = CAR(res_379);
arg1060_382 = CDR(res_379);
{
obj_t arg1062_384;
arg1062_384 = CAR(sand_372);
{
bool_t test1397_770;
test1397_770 = EXTENDED_PAIRP(arg1062_384);
if(test1397_770){
arg1061_383 = CER(arg1062_384);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1062_384);}
}
}
return MAKE_EXTENDED_PAIR(arg1059_381, arg1060_382, arg1061_383);
}
}
 else {
return res_379;
}
}
}
}
}
}
}
 else {
FAILURE(string1463___expander_bool,string1462___expander_bool,exp_929);}
}
}


/* _expand-and */obj_t _expand_and_238___expander_bool(obj_t env_925, obj_t exp_926)
{
return expand_and_10___expander_bool(exp_926);
}


/* expand-cond */obj_t expand_cond_95___expander_bool(obj_t exp_4)
{
{
obj_t clauses_413;
clauses_413 = CDR(exp_4);
{
obj_t clause1_414;
if(PAIRP(clauses_413)){
clause1_414 = CAR(clauses_413);
}
 else {
clause1_414 = BNIL;
}
{
obj_t clause2__192_415;
if(PAIRP(clause1_414)){
clause2__192_415 = CDR(clauses_413);
}
 else {
clause2__192_415 = BFALSE;
}
{
if(NULLP(clause1_414)){
return BFALSE;
}
 else {
bool_t test_1056;
if(PAIRP(clause1_414)){
test_1056 = equal__25___r4_equivalence_6_2(clause1_414, list1464___expander_bool);
}
 else {
test_1056 = ((bool_t)1);
}
if(test_1056){
FAILURE(string1466___expander_bool,string1462___expander_bool,exp_4);}
 else {
bool_t test_1061;
{
obj_t aux_1062;
aux_1062 = CDR(clause1_414);
test_1061 = NULLP(aux_1062);
}
if(test_1061){
{
obj_t res_419;
{
obj_t arg1104_426;
obj_t arg1105_427;
obj_t arg1106_428;
arg1104_426 = symbol1467___expander_bool;
arg1105_427 = CAR(clause1_414);
{
obj_t arg1112_434;
obj_t arg1113_435;
arg1112_434 = symbol1468___expander_bool;
{
obj_t arg1116_438;
arg1116_438 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1113_435 = append_2_18___r4_pairs_and_lists_6_3(clause2__192_415, arg1116_438);
}
{
obj_t list1114_436;
list1114_436 = MAKE_PAIR(arg1113_435, BNIL);
arg1106_428 = cons__138___r4_pairs_and_lists_6_3(arg1112_434, list1114_436);
}
}
{
obj_t list1108_430;
{
obj_t arg1109_431;
{
obj_t arg1110_432;
arg1110_432 = MAKE_PAIR(BNIL, BNIL);
arg1109_431 = MAKE_PAIR(arg1106_428, arg1110_432);
}
list1108_430 = MAKE_PAIR(arg1105_427, arg1109_431);
}
res_419 = cons__138___r4_pairs_and_lists_6_3(arg1104_426, list1108_430);
}
}
{
bool_t test1098_420;
{
obj_t aux_1074;
aux_1074 = CAR(clause1_414);
test1098_420 = EXTENDED_PAIRP(aux_1074);
}
if(test1098_420){
obj_t arg1099_421;
obj_t arg1100_422;
obj_t arg1101_423;
arg1099_421 = CAR(res_419);
arg1100_422 = CDR(res_419);
{
obj_t arg1102_424;
arg1102_424 = CAR(clause1_414);
{
bool_t test1397_800;
test1397_800 = EXTENDED_PAIRP(arg1102_424);
if(test1397_800){
arg1101_423 = CER(arg1102_424);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1102_424);}
}
}
return MAKE_EXTENDED_PAIR(arg1099_421, arg1100_422, arg1101_423);
}
 else {
return replace__160___progn(exp_4, res_419);
}
}
}
}
 else {
bool_t test_1087;
{
bool_t test_1088;
{
obj_t aux_1089;
{
obj_t aux_1090;
aux_1090 = CDR(clause1_414);
aux_1089 = CAR(aux_1090);
}
test_1088 = (aux_1089==symbol1469___expander_bool);
}
if(test_1088){
long aux_1094;
aux_1094 = list_length(clause1_414);
test_1087 = (aux_1094==((long)3));
}
 else {
test_1087 = ((bool_t)0);
}
}
if(test_1087){
{
obj_t res_442;
{
obj_t arg1126_449;
obj_t arg1127_450;
obj_t arg1128_451;
arg1126_449 = symbol1457___expander_bool;
{
obj_t arg1134_457;
obj_t arg1135_458;
obj_t arg1136_459;
{
obj_t arg1142_465;
obj_t arg1143_466;
arg1142_465 = symbol1470___expander_bool;
arg1143_466 = CAR(clause1_414);
{
obj_t list1145_468;
{
obj_t arg1146_469;
arg1146_469 = MAKE_PAIR(BNIL, BNIL);
list1145_468 = MAKE_PAIR(arg1143_466, arg1146_469);
}
arg1134_457 = cons__138___r4_pairs_and_lists_6_3(arg1142_465, list1145_468);
}
}
{
obj_t arg1148_471;
obj_t arg1150_472;
arg1148_471 = symbol1471___expander_bool;
{
obj_t arg1155_477;
obj_t arg1157_479;
arg1155_477 = symbol1472___expander_bool;
{
obj_t aux_1101;
{
obj_t aux_1102;
aux_1102 = CDR(clause1_414);
aux_1101 = CDR(aux_1102);
}
arg1157_479 = CAR(aux_1101);
}
{
obj_t list1159_481;
{
obj_t arg1160_482;
{
obj_t arg1161_483;
arg1161_483 = MAKE_PAIR(BNIL, BNIL);
arg1160_482 = MAKE_PAIR(arg1157_479, arg1161_483);
}
list1159_481 = MAKE_PAIR(BNIL, arg1160_482);
}
arg1150_472 = cons__138___r4_pairs_and_lists_6_3(arg1155_477, list1159_481);
}
}
{
obj_t list1152_474;
{
obj_t arg1153_475;
arg1153_475 = MAKE_PAIR(BNIL, BNIL);
list1152_474 = MAKE_PAIR(arg1150_472, arg1153_475);
}
arg1135_458 = cons__138___r4_pairs_and_lists_6_3(arg1148_471, list1152_474);
}
}
{
obj_t arg1163_485;
obj_t arg1164_486;
arg1163_485 = symbol1473___expander_bool;
{
obj_t arg1169_491;
obj_t arg1171_493;
arg1169_491 = symbol1472___expander_bool;
{
obj_t arg1177_499;
obj_t arg1178_500;
arg1177_499 = symbol1468___expander_bool;
{
obj_t arg1181_503;
arg1181_503 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1178_500 = append_2_18___r4_pairs_and_lists_6_3(clause2__192_415, arg1181_503);
}
{
obj_t list1179_501;
list1179_501 = MAKE_PAIR(arg1178_500, BNIL);
arg1171_493 = cons__138___r4_pairs_and_lists_6_3(arg1177_499, list1179_501);
}
}
{
obj_t list1173_495;
{
obj_t arg1174_496;
{
obj_t arg1175_497;
arg1175_497 = MAKE_PAIR(BNIL, BNIL);
arg1174_496 = MAKE_PAIR(arg1171_493, arg1175_497);
}
list1173_495 = MAKE_PAIR(BNIL, arg1174_496);
}
arg1164_486 = cons__138___r4_pairs_and_lists_6_3(arg1169_491, list1173_495);
}
}
{
obj_t list1166_488;
{
obj_t arg1167_489;
arg1167_489 = MAKE_PAIR(BNIL, BNIL);
list1166_488 = MAKE_PAIR(arg1164_486, arg1167_489);
}
arg1136_459 = cons__138___r4_pairs_and_lists_6_3(arg1163_485, list1166_488);
}
}
{
obj_t list1138_461;
{
obj_t arg1139_462;
{
obj_t arg1140_463;
arg1140_463 = MAKE_PAIR(BNIL, BNIL);
arg1139_462 = MAKE_PAIR(arg1136_459, arg1140_463);
}
list1138_461 = MAKE_PAIR(arg1135_458, arg1139_462);
}
arg1127_450 = cons__138___r4_pairs_and_lists_6_3(arg1134_457, list1138_461);
}
}
{
obj_t arg1184_506;
obj_t arg1185_507;
obj_t arg1186_508;
obj_t arg1187_509;
arg1184_506 = symbol1458___expander_bool;
arg1185_507 = symbol1470___expander_bool;
{
obj_t arg1194_516;
obj_t arg1195_517;
{
obj_t arg1201_522;
arg1201_522 = symbol1471___expander_bool;
{
obj_t list1203_524;
list1203_524 = MAKE_PAIR(BNIL, BNIL);
arg1194_516 = cons__138___r4_pairs_and_lists_6_3(arg1201_522, list1203_524);
}
}
arg1195_517 = symbol1470___expander_bool;
{
obj_t list1197_519;
{
obj_t arg1199_520;
arg1199_520 = MAKE_PAIR(BNIL, BNIL);
list1197_519 = MAKE_PAIR(arg1195_517, arg1199_520);
}
arg1186_508 = cons__138___r4_pairs_and_lists_6_3(arg1194_516, list1197_519);
}
}
{
obj_t arg1205_526;
arg1205_526 = symbol1473___expander_bool;
{
obj_t list1207_528;
list1207_528 = MAKE_PAIR(BNIL, BNIL);
arg1187_509 = cons__138___r4_pairs_and_lists_6_3(arg1205_526, list1207_528);
}
}
{
obj_t list1189_511;
{
obj_t arg1190_512;
{
obj_t arg1191_513;
{
obj_t arg1192_514;
arg1192_514 = MAKE_PAIR(BNIL, BNIL);
arg1191_513 = MAKE_PAIR(arg1187_509, arg1192_514);
}
arg1190_512 = MAKE_PAIR(arg1186_508, arg1191_513);
}
list1189_511 = MAKE_PAIR(arg1185_507, arg1190_512);
}
arg1128_451 = cons__138___r4_pairs_and_lists_6_3(arg1184_506, list1189_511);
}
}
{
obj_t list1130_453;
{
obj_t arg1131_454;
{
obj_t arg1132_455;
arg1132_455 = MAKE_PAIR(BNIL, BNIL);
arg1131_454 = MAKE_PAIR(arg1128_451, arg1132_455);
}
list1130_453 = MAKE_PAIR(arg1127_450, arg1131_454);
}
res_442 = cons__138___r4_pairs_and_lists_6_3(arg1126_449, list1130_453);
}
}
{
bool_t test1120_443;
{
obj_t aux_1144;
aux_1144 = CAR(clause1_414);
test1120_443 = EXTENDED_PAIRP(aux_1144);
}
if(test1120_443){
obj_t arg1121_444;
obj_t arg1122_445;
obj_t arg1123_446;
arg1121_444 = CAR(res_442);
arg1122_445 = CDR(res_442);
{
obj_t arg1124_447;
arg1124_447 = CAR(clause1_414);
{
bool_t test1397_829;
test1397_829 = EXTENDED_PAIRP(arg1124_447);
if(test1397_829){
arg1123_446 = CER(arg1124_447);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1124_447);}
}
}
return MAKE_EXTENDED_PAIR(arg1121_444, arg1122_445, arg1123_446);
}
 else {
return replace__160___progn(exp_4, res_442);
}
}
}
}
 else {
bool_t test_1157;
{
obj_t aux_1158;
aux_1158 = CAR(clause1_414);
test_1157 = (aux_1158==symbol1465___expander_bool);
}
if(test_1157){
return normalize_body_95___progn(CDR(clause1_414));
}
 else {
{
obj_t ncond_532;
{
obj_t nc_562;
{
obj_t arg1259_570;
obj_t arg1260_571;
arg1259_570 = symbol1468___expander_bool;
{
obj_t arg1263_574;
arg1263_574 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1260_571 = append_2_18___r4_pairs_and_lists_6_3(clause2__192_415, arg1263_574);
}
{
obj_t list1261_572;
list1261_572 = MAKE_PAIR(arg1260_571, BNIL);
nc_562 = cons__138___r4_pairs_and_lists_6_3(arg1259_570, list1261_572);
}
}
{
bool_t test1252_563;
if(PAIRP(clause2__192_415)){
obj_t aux_1169;
aux_1169 = CAR(clause2__192_415);
test1252_563 = EXTENDED_PAIRP(aux_1169);
}
 else {
test1252_563 = ((bool_t)0);
}
if(test1252_563){
{
obj_t arg1253_564;
obj_t arg1254_565;
obj_t arg1255_566;
arg1253_564 = CAR(nc_562);
arg1254_565 = CDR(nc_562);
{
obj_t arg1256_567;
arg1256_567 = CAR(clause2__192_415);
{
bool_t test1397_848;
test1397_848 = EXTENDED_PAIRP(arg1256_567);
if(test1397_848){
arg1255_566 = CER(arg1256_567);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1256_567);}
}
}
ncond_532 = MAKE_EXTENDED_PAIR(arg1253_564, arg1254_565, arg1255_566);
}
}
 else {
ncond_532 = nc_562;
}
}
}
{
obj_t res_533;
{
obj_t arg1238_552;
obj_t arg1240_553;
obj_t arg1241_554;
arg1238_552 = symbol1458___expander_bool;
arg1240_553 = CAR(clause1_414);
arg1241_554 = normalize_body_95___progn(CDR(clause1_414));
{
obj_t list1244_556;
{
obj_t arg1245_557;
{
obj_t arg1247_558;
{
obj_t arg1248_559;
arg1248_559 = MAKE_PAIR(BNIL, BNIL);
arg1247_558 = MAKE_PAIR(ncond_532, arg1248_559);
}
arg1245_557 = MAKE_PAIR(arg1241_554, arg1247_558);
}
list1244_556 = MAKE_PAIR(arg1240_553, arg1245_557);
}
res_533 = cons__138___r4_pairs_and_lists_6_3(arg1238_552, list1244_556);
}
}
{
{
bool_t test1212_534;
{
obj_t aux_1189;
aux_1189 = CAR(clause1_414);
test1212_534 = EXTENDED_PAIRP(aux_1189);
}
if(test1212_534){
{
obj_t arg1213_535;
obj_t arg1214_536;
obj_t arg1216_537;
arg1213_535 = CAR(res_533);
arg1214_536 = CDR(res_533);
{
obj_t arg1219_538;
arg1219_538 = CAR(clause1_414);
{
bool_t test1397_864;
test1397_864 = EXTENDED_PAIRP(arg1219_538);
if(test1397_864){
arg1216_537 = CER(arg1219_538);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1219_538);}
}
}
return MAKE_EXTENDED_PAIR(arg1213_535, arg1214_536, arg1216_537);
}
}
 else {
bool_t test1220_539;
test1220_539 = EXTENDED_PAIRP(clause1_414);
if(test1220_539){
{
obj_t arg1221_540;
obj_t arg1222_541;
obj_t arg1224_542;
arg1221_540 = CAR(res_533);
arg1222_541 = CDR(res_533);
{
bool_t test1397_876;
test1397_876 = EXTENDED_PAIRP(clause1_414);
if(test1397_876){
arg1224_542 = CER(clause1_414);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,clause1_414);}
}
return MAKE_EXTENDED_PAIR(arg1221_540, arg1222_541, arg1224_542);
}
}
 else {
bool_t test1225_543;
{
bool_t test_1210;
{
obj_t aux_1211;
aux_1211 = CDR(clause1_414);
test_1210 = PAIRP(aux_1211);
}
if(test_1210){
obj_t aux_1214;
{
obj_t aux_1215;
aux_1215 = CDR(clause1_414);
aux_1214 = CAR(aux_1215);
}
test1225_543 = EXTENDED_PAIRP(aux_1214);
}
 else {
test1225_543 = ((bool_t)0);
}
}
if(test1225_543){
{
obj_t arg1226_544;
obj_t arg1228_545;
obj_t arg1231_546;
arg1226_544 = CAR(res_533);
arg1228_545 = CDR(res_533);
{
obj_t arg1232_547;
{
obj_t aux_1222;
aux_1222 = CDR(clause1_414);
arg1232_547 = CAR(aux_1222);
}
{
bool_t test1397_898;
test1397_898 = EXTENDED_PAIRP(arg1232_547);
if(test1397_898){
arg1231_546 = CER(arg1232_547);
}
 else {
FAILURE(string1459___expander_bool,string1460___expander_bool,arg1232_547);}
}
}
return MAKE_EXTENDED_PAIR(arg1226_544, arg1228_545, arg1231_546);
}
}
 else {
return replace__160___progn(exp_4, res_533);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}


/* _expand-cond */obj_t _expand_cond_204___expander_bool(obj_t env_927, obj_t exp_928)
{
return expand_cond_95___expander_bool(exp_928);
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_bool()
{
module_initialization_70___error(((long)0), "__EXPANDER_BOOL");
module_initialization_70___bigloo(((long)0), "__EXPANDER_BOOL");
module_initialization_70___tvector(((long)0), "__EXPANDER_BOOL");
module_initialization_70___structure(((long)0), "__EXPANDER_BOOL");
module_initialization_70___bexit(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_BOOL");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_BOOL");
return module_initialization_70___progn(((long)0), "__EXPANDER_BOOL");
}

