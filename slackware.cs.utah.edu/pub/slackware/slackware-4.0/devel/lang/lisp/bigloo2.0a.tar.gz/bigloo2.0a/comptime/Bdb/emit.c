/*===========================================================================*/
/*   (Bdb/emit.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t _src_files__222_engine_param;
static obj_t method_init_76_bdb_emit();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static obj_t bdb_sfun__59_bdb_emit(value_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _bdb__default1473_46_bdb_emit(obj_t, obj_t);
extern obj_t fail_ast_node;
extern obj_t leave_function_170_tools_error();
static obj_t _c_port__188_bdb_emit = BUNSPEC;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
static obj_t _emit_bdb_info1875_100_bdb_emit(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
static obj_t bdb__default1473_159_bdb_emit(node_t);
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t unit_initializer_id_235_ast_unit(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t qualified_name_205_cgen_prototype(obj_t, obj_t);
extern obj_t module_initialization_70_bdb_emit(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_cgen_prototype(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t svar_ast_var;
static obj_t bdb_global_sfun__204_bdb_emit(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_bdb_emit();
extern obj_t emit_bdb_info_67_bdb_emit(obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t id__name_228_ast_ident(obj_t);
extern obj_t _module_clause__117_module_module;
extern obj_t app_ast_node;
static obj_t library_modules_init_112_bdb_emit();
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t _bdb_1876_208_bdb_emit(obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_bdb_emit();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t enter_function_81_tools_error(obj_t);
static obj_t arg1594_bdb_emit(obj_t, obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
static obj_t bdb__20_bdb_emit(node_t);
static obj_t bdb___160_bdb_emit(obj_t);
extern obj_t _module__166_module_module;
extern obj_t _classes__134___object;
extern obj_t set_variable_name__102_cgen_prototype(obj_t);
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t find_location_120_tools_location(obj_t);
static obj_t bdb_emit_local_info__83_bdb_emit(obj_t);
static obj_t bdb_global_svar__1_bdb_emit(obj_t);
static obj_t require_initialization_114_bdb_emit = BUNSPEC;
extern obj_t conditional_ast_node;
extern obj_t get_toplevel_unit_32_module_include();
static obj_t cnst_init_137_bdb_emit();
static obj_t __cnst[4];

DEFINE_STATIC_GENERIC(bdb__env_49_bdb_emit, _bdb_1876_208_bdb_emit1905, _bdb_1876_208_bdb_emit, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1890_bdb_emit, arg1594_bdb_emit1906, arg1594_bdb_emit, 0L, 1);
DEFINE_STATIC_PROCEDURE(bdb__default1473_env_139_bdb_emit, _bdb__default1473_46_bdb_emit1907, _bdb__default1473_46_bdb_emit, 0L, 1);
DEFINE_EXPORT_PROCEDURE(emit_bdb_info_env_109_bdb_emit, _emit_bdb_info1875_100_bdb_emit1908, _emit_bdb_info1875_100_bdb_emit, 0L, 2);
DEFINE_STRING(string1899_bdb_emit, string1899_bdb_emit1909, "DONE BIGLOO EXPORT LOCATION ", 28);
DEFINE_STRING(string1898_bdb_emit, string1898_bdb_emit1910, "     {\"", 7);
DEFINE_STRING(string1897_bdb_emit, string1897_bdb_emit1911, "     {0, 0},", 12);
DEFINE_STRING(string1896_bdb_emit, string1896_bdb_emit1912, "   {", 4);
DEFINE_STRING(string1895_bdb_emit, string1895_bdb_emit1913, ", \"", 3);
DEFINE_STRING(string1894_bdb_emit, string1894_bdb_emit1914, "\"},", 3);
DEFINE_STRING(string1893_bdb_emit, string1893_bdb_emit1915, "\", 0},", 6);
DEFINE_STRING(string1892_bdb_emit, string1892_bdb_emit1916, "\", (char *)", 11);
DEFINE_STRING(string1891_bdb_emit, string1891_bdb_emit1917, "   0};\n", 7);
DEFINE_STRING(string1889_bdb_emit, string1889_bdb_emit1918, "   { 0, (char *)", 16);
DEFINE_STRING(string1888_bdb_emit, string1888_bdb_emit1919, " },", 3);
DEFINE_STRING(string1887_bdb_emit, string1887_bdb_emit1920, "0", 1);
DEFINE_STRING(string1886_bdb_emit, string1886_bdb_emit1921, "\", 0 },", 7);
DEFINE_STRING(string1885_bdb_emit, string1885_bdb_emit1922, "   {\"", 5);
DEFINE_STRING(string1884_bdb_emit, string1884_bdb_emit1923, "\", \"", 4);
DEFINE_STRING(string1883_bdb_emit, string1883_bdb_emit1924, "\" },", 4);
DEFINE_STRING(string1882_bdb_emit, string1882_bdb_emit1925, "static struct bdb_fun_info {\n", 29);
DEFINE_STRING(string1881_bdb_emit, string1881_bdb_emit1926, "   char *sname, *cname;\n", 24);
DEFINE_STRING(string1879_bdb_emit, string1879_bdb_emit1927, "__bdb_info", 10);
DEFINE_STRING(string1880_bdb_emit, string1880_bdb_emit1928, "} ", 2);
DEFINE_STRING(string1878_bdb_emit, string1878_bdb_emit1929, "[] = { ", 7);
DEFINE_STRING(string1877_bdb_emit, string1877_bdb_emit1930, "/* bdb association table */", 27);


/* module-initialization */ obj_t 
module_initialization_70_bdb_emit(long checksum_1619, char *from_1620)
{
   if (CBOOL(require_initialization_114_bdb_emit))
     {
	require_initialization_114_bdb_emit = BBOOL(((bool_t) 0));
	library_modules_init_112_bdb_emit();
	cnst_init_137_bdb_emit();
	imported_modules_init_94_bdb_emit();
	method_init_76_bdb_emit();
	toplevel_init_63_bdb_emit();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_bdb_emit()
{
   module_initialization_70___object(((long) 0), "BDB_EMIT");
   module_initialization_70___r4_output_6_10_3(((long) 0), "BDB_EMIT");
   module_initialization_70___reader(((long) 0), "BDB_EMIT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_bdb_emit()
{
   {
      obj_t cnst_port_138_1611;
      cnst_port_138_1611 = open_input_string(string1899_bdb_emit);
      {
	 long i_1612;
	 i_1612 = ((long) 3);
       loop_1613:
	 {
	    bool_t test1900_1614;
	    test1900_1614 = (i_1612 == ((long) -1));
	    if (test1900_1614)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1901_1615;
		    {
		       obj_t list1902_1616;
		       {
			  obj_t arg1903_1617;
			  arg1903_1617 = BNIL;
			  list1902_1616 = MAKE_PAIR(cnst_port_138_1611, arg1903_1617);
		       }
		       arg1901_1615 = read___reader(list1902_1616);
		    }
		    CNST_TABLE_SET(i_1612, arg1901_1615);
		 }
		 {
		    int aux_1618;
		    {
		       long aux_1638;
		       aux_1638 = (i_1612 - ((long) 1));
		       aux_1618 = (int) (aux_1638);
		    }
		    {
		       long i_1641;
		       i_1641 = (long) (aux_1618);
		       i_1612 = i_1641;
		       goto loop_1613;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_bdb_emit()
{
   _c_port__188_bdb_emit = BUNSPEC;
   return BUNSPEC;
}


/* emit-bdb-info */ obj_t 
emit_bdb_info_67_bdb_emit(obj_t globals_33, obj_t port_34)
{
   _c_port__188_bdb_emit = port_34;
   {
      obj_t list1530_794;
      list1530_794 = MAKE_PAIR(port_34, BNIL);
      newline___r4_output_6_10_3(list1530_794);
   }
   {
      obj_t list1532_796;
      list1532_796 = MAKE_PAIR(port_34, BNIL);
      newline___r4_output_6_10_3(list1532_796);
   }
   {
      obj_t list1534_798;
      list1534_798 = MAKE_PAIR(string1877_bdb_emit, BNIL);
      fprint___r4_output_6_10_3(port_34, list1534_798);
   }
   {
      obj_t list1537_802;
      {
	 obj_t arg1540_804;
	 {
	    obj_t arg1545_806;
	    {
	       obj_t arg1549_808;
	       {
		  obj_t arg1550_809;
		  arg1550_809 = MAKE_PAIR(string1878_bdb_emit, BNIL);
		  arg1549_808 = MAKE_PAIR(string1879_bdb_emit, arg1550_809);
	       }
	       arg1545_806 = MAKE_PAIR(string1880_bdb_emit, arg1549_808);
	    }
	    arg1540_804 = MAKE_PAIR(string1881_bdb_emit, arg1545_806);
	 }
	 list1537_802 = MAKE_PAIR(string1882_bdb_emit, arg1540_804);
      }
      fprint___r4_output_6_10_3(port_34, list1537_802);
   }
   {
      obj_t arg1556_814;
      {
	 obj_t arg1564_822;
	 {
	    obj_t arg1565_823;
	    {
	       obj_t arg1566_824;
	       {
		  obj_t arg1568_825;
		  arg1568_825 = get_toplevel_unit_32_module_include();
		  arg1566_824 = STRUCT_REF(arg1568_825, ((long) 0));
	       }
	       arg1565_823 = unit_initializer_id_235_ast_unit(arg1566_824);
	    }
	    arg1564_822 = id__name_228_ast_ident(arg1565_823);
	 }
	 arg1556_814 = qualified_name_205_cgen_prototype(arg1564_822, _module__166_module_module);
      }
      {
	 obj_t list1558_816;
	 {
	    obj_t arg1559_817;
	    {
	       obj_t arg1560_818;
	       {
		  obj_t arg1561_819;
		  {
		     obj_t arg1562_820;
		     arg1562_820 = MAKE_PAIR(string1883_bdb_emit, BNIL);
		     arg1561_819 = MAKE_PAIR(arg1556_814, arg1562_820);
		  }
		  arg1560_818 = MAKE_PAIR(string1884_bdb_emit, arg1561_819);
	       }
	       arg1559_817 = MAKE_PAIR(_module__166_module_module, arg1560_818);
	    }
	    list1558_816 = MAKE_PAIR(string1885_bdb_emit, arg1559_817);
	 }
	 fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1558_816);
      }
   }
   {
      obj_t l1443_826;
      l1443_826 = _src_files__222_engine_param;
    lname1444_827:
      if (PAIRP(l1443_826))
	{
	   {
	      obj_t src_829;
	      src_829 = CAR(l1443_826);
	      {
		 obj_t list1570_830;
		 {
		    obj_t arg1573_832;
		    {
		       obj_t arg1575_833;
		       arg1575_833 = MAKE_PAIR(string1886_bdb_emit, BNIL);
		       arg1573_832 = MAKE_PAIR(src_829, arg1575_833);
		    }
		    list1570_830 = MAKE_PAIR(string1885_bdb_emit, arg1573_832);
		 }
		 fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1570_830);
	      }
	   }
	   {
	      obj_t l1443_1673;
	      l1443_1673 = CDR(l1443_826);
	      l1443_826 = l1443_1673;
	      goto lname1444_827;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t arg1583_838;
      {
	 obj_t loc_844;
	 loc_844 = find_location_120_tools_location(_module_clause__117_module_module);
	 {
	    bool_t test_1676;
	    if (STRUCTP(loc_844))
	      {
		 obj_t aux_1681;
		 obj_t aux_1679;
		 aux_1681 = CNST_TABLE_REF(((long) 0));
		 aux_1679 = STRUCT_KEY(loc_844);
		 test_1676 = (aux_1679 == aux_1681);
	      }
	    else
	      {
		 test_1676 = ((bool_t) 0);
	      }
	    if (test_1676)
	      {
		 arg1583_838 = STRUCT_REF(loc_844, ((long) 2));
	      }
	    else
	      {
		 arg1583_838 = string1887_bdb_emit;
	      }
	 }
      }
      {
	 obj_t list1585_840;
	 {
	    obj_t arg1586_841;
	    {
	       obj_t arg1587_842;
	       arg1587_842 = MAKE_PAIR(string1888_bdb_emit, BNIL);
	       arg1586_841 = MAKE_PAIR(arg1583_838, arg1587_842);
	    }
	    list1585_840 = MAKE_PAIR(string1889_bdb_emit, arg1586_841);
	 }
	 fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1585_840);
      }
   }
   {
      obj_t l1445_846;
      l1445_846 = globals_33;
    lname1446_847:
      if (PAIRP(l1445_846))
	{
	   {
	      obj_t global_849;
	      global_849 = CAR(l1445_846);
	      {
		 obj_t aux_1692;
		 {
		    global_t obj_1458;
		    obj_1458 = (global_t) (global_849);
		    aux_1692 = (((global_t) CREF(obj_1458))->id);
		 }
		 enter_function_81_tools_error(aux_1692);
	      }
	      bdb_global_sfun__204_bdb_emit(global_849);
	      leave_function_170_tools_error();
	   }
	   {
	      obj_t l1445_1698;
	      l1445_1698 = CDR(l1445_846);
	      l1445_846 = l1445_1698;
	      goto lname1446_847;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t arg1594_1599;
      arg1594_1599 = proc1890_bdb_emit;
      for_each_global__88_ast_env(arg1594_1599);
   }
   {
      obj_t list1608_866;
      list1608_866 = MAKE_PAIR(string1891_bdb_emit, BNIL);
      return fprint___r4_output_6_10_3(port_34, list1608_866);
   }
}


/* _emit-bdb-info1875 */ obj_t 
_emit_bdb_info1875_100_bdb_emit(obj_t env_1600, obj_t globals_1601, obj_t port_1602)
{
   return emit_bdb_info_67_bdb_emit(globals_1601, port_1602);
}


/* arg1594 */ obj_t 
arg1594_bdb_emit(obj_t env_1603, obj_t global_1604)
{
   {
      obj_t global_853;
      global_853 = global_1604;
      {
	 bool_t test1596_855;
	 {
	    bool_t test1597_856;
	    {
	       bool_t test1599_858;
	       {
		  bool_t test1603_861;
		  {
		     obj_t obj2_1462;
		     obj2_1462 = _module__166_module_module;
		     {
			obj_t aux_1704;
			{
			   global_t obj_1460;
			   obj_1460 = (global_t) (global_853);
			   aux_1704 = (((global_t) CREF(obj_1460))->module);
			}
			test1603_861 = (aux_1704 == obj2_1462);
		     }
		  }
		  if (test1603_861)
		    {
		       obj_t aux_1712;
		       obj_t aux_1709;
		       aux_1712 = CNST_TABLE_REF(((long) 1));
		       {
			  global_t obj_1463;
			  obj_1463 = (global_t) (global_853);
			  aux_1709 = (((global_t) CREF(obj_1463))->import);
		       }
		       test1599_858 = (aux_1709 == aux_1712);
		    }
		  else
		    {
		       test1599_858 = ((bool_t) 0);
		    }
	       }
	       if (test1599_858)
		 {
		    test1597_856 = ((bool_t) 1);
		 }
	       else
		 {
		    long aux_1716;
		    {
		       global_t obj_1466;
		       obj_1466 = (global_t) (global_853);
		       aux_1716 = (((global_t) CREF(obj_1466))->occurrence);
		    }
		    test1597_856 = (aux_1716 > ((long) 0));
		 }
	    }
	    if (test1597_856)
	      {
		 obj_t aux_1721;
		 {
		    value_t aux_1722;
		    {
		       global_t obj_1469;
		       obj_1469 = (global_t) (global_853);
		       aux_1722 = (((global_t) CREF(obj_1469))->value);
		    }
		    aux_1721 = (obj_t) (aux_1722);
		 }
		 test1596_855 = is_a__118___object(aux_1721, svar_ast_var);
	      }
	    else
	      {
		 test1596_855 = ((bool_t) 0);
	      }
	 }
	 if (test1596_855)
	   {
	      return bdb_global_svar__1_bdb_emit(global_853);
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* bdb-global-sfun! */ obj_t 
bdb_global_sfun__204_bdb_emit(obj_t global_35)
{
   {
      value_t sfun_869;
      {
	 global_t obj_1471;
	 obj_1471 = (global_t) (global_35);
	 sfun_869 = (((global_t) CREF(obj_1471))->value);
      }
      {
	 obj_t sfun_loc_13_870;
	 {
	    sfun_t obj_1472;
	    obj_1472 = (sfun_t) (sfun_869);
	    sfun_loc_13_870 = (((sfun_t) CREF(obj_1472))->loc);
	 }
	 {
	    obj_t clo_871;
	    {
	       sfun_t obj_1473;
	       obj_1473 = (sfun_t) (sfun_869);
	       clo_871 = (((sfun_t) CREF(obj_1473))->the_closure_238);
	    }
	    {
	       {
		  bool_t test_1735;
		  {
		     bool_t test_1736;
		     if (STRUCTP(sfun_loc_13_870))
		       {
			  obj_t aux_1741;
			  obj_t aux_1739;
			  aux_1741 = CNST_TABLE_REF(((long) 0));
			  aux_1739 = STRUCT_KEY(sfun_loc_13_870);
			  test_1736 = (aux_1739 == aux_1741);
		       }
		     else
		       {
			  test_1736 = ((bool_t) 0);
		       }
		     if (test_1736)
		       {
			  global_t obj_1482;
			  obj_1482 = (global_t) (global_35);
			  test_1735 = (((global_t) CREF(obj_1482))->user__32);
		       }
		     else
		       {
			  test_1735 = ((bool_t) 0);
		       }
		  }
		  if (test_1735)
		    {
		       set_variable_name__102_cgen_prototype(global_35);
		       {
			  obj_t fname_873;
			  obj_t lnum_874;
			  obj_t id_875;
			  obj_t val_name_6_876;
			  obj_t bp_name_229_877;
			  fname_873 = STRUCT_REF(sfun_loc_13_870, ((long) 0));
			  lnum_874 = STRUCT_REF(sfun_loc_13_870, ((long) 2));
			  {
			     global_t obj_1489;
			     obj_1489 = (global_t) (global_35);
			     id_875 = (((global_t) CREF(obj_1489))->id);
			  }
			  {
			     bool_t test1662_915;
			     test1662_915 = is_a__118___object(clo_871, global_ast_var);
			     if (test1662_915)
			       {
				  global_t obj_1491;
				  obj_1491 = (global_t) (clo_871);
				  val_name_6_876 = (((global_t) CREF(obj_1491))->name);
			       }
			     else
			       {
				  val_name_6_876 = BINT(((long) 0));
			       }
			  }
			  {
			     global_t obj_1492;
			     obj_1492 = (global_t) (global_35);
			     bp_name_229_877 = (((global_t) CREF(obj_1492))->name);
			  }
			  {
			     obj_t list1612_878;
			     {
				obj_t arg1615_880;
				{
				   obj_t arg1617_881;
				   {
				      obj_t arg1620_883;
				      {
					 obj_t arg1621_884;
					 arg1621_884 = MAKE_PAIR(string1888_bdb_emit, BNIL);
					 arg1620_883 = MAKE_PAIR(lnum_874, arg1621_884);
				      }
				      arg1617_881 = MAKE_PAIR(string1892_bdb_emit, arg1620_883);
				   }
				   arg1615_880 = MAKE_PAIR(fname_873, arg1617_881);
				}
				list1612_878 = MAKE_PAIR(string1885_bdb_emit, arg1615_880);
			     }
			     fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1612_878);
			  }
			  {
			     obj_t list1624_887;
			     {
				obj_t arg1627_889;
				{
				   obj_t arg1628_890;
				   arg1628_890 = MAKE_PAIR(string1893_bdb_emit, BNIL);
				   arg1627_889 = MAKE_PAIR(id_875, arg1628_890);
				}
				list1624_887 = MAKE_PAIR(string1885_bdb_emit, arg1627_889);
			     }
			     fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1624_887);
			  }
			  {
			     bool_t test_1768;
			     if (INTEGERP(val_name_6_876))
			       {
				  test_1768 = ((bool_t) 1);
			       }
			     else
			       {
				  test_1768 = REALP(val_name_6_876);
			       }
			     if (test_1768)
			       {
				  obj_t list1634_894;
				  {
				     obj_t arg1638_896;
				     {
					obj_t arg1639_897;
					{
					   obj_t arg1641_899;
					   {
					      obj_t arg1645_900;
					      arg1645_900 = MAKE_PAIR(string1894_bdb_emit, BNIL);
					      arg1641_899 = MAKE_PAIR(bp_name_229_877, arg1645_900);
					   }
					   arg1639_897 = MAKE_PAIR(string1895_bdb_emit, arg1641_899);
					}
					arg1638_896 = MAKE_PAIR(val_name_6_876, arg1639_897);
				     }
				     list1634_894 = MAKE_PAIR(string1896_bdb_emit, arg1638_896);
				  }
				  fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1634_894);
			       }
			     else
			       {
				  obj_t list1648_903;
				  {
				     obj_t arg1650_905;
				     {
					obj_t arg1652_906;
					{
					   obj_t arg1654_908;
					   {
					      obj_t arg1655_909;
					      arg1655_909 = MAKE_PAIR(string1894_bdb_emit, BNIL);
					      arg1654_908 = MAKE_PAIR(bp_name_229_877, arg1655_909);
					   }
					   arg1652_906 = MAKE_PAIR(string1884_bdb_emit, arg1654_908);
					}
					arg1650_905 = MAKE_PAIR(val_name_6_876, arg1652_906);
				     }
				     list1648_903 = MAKE_PAIR(string1885_bdb_emit, arg1650_905);
				  }
				  fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1648_903);
			       }
			  }
			  bdb_sfun__59_bdb_emit(sfun_869);
			  {
			     obj_t list1658_912;
			     list1658_912 = MAKE_PAIR(string1897_bdb_emit, BNIL);
			     return fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1658_912);
			  }
		       }
		    }
		  else
		    {
		       return BUNSPEC;
		    }
	       }
	    }
	 }
      }
   }
}


/* bdb-global-svar! */ obj_t 
bdb_global_svar__1_bdb_emit(obj_t global_36)
{
   {
      obj_t svar_loc_189_918;
      {
	 svar_t obj_1499;
	 {
	    value_t aux_1787;
	    {
	       global_t obj_1498;
	       obj_1498 = (global_t) (global_36);
	       aux_1787 = (((global_t) CREF(obj_1498))->value);
	    }
	    obj_1499 = (svar_t) (aux_1787);
	 }
	 svar_loc_189_918 = (((svar_t) CREF(obj_1499))->loc);
      }
      {
	 {
	    bool_t test_1792;
	    if (STRUCTP(svar_loc_189_918))
	      {
		 obj_t aux_1797;
		 obj_t aux_1795;
		 aux_1797 = CNST_TABLE_REF(((long) 0));
		 aux_1795 = STRUCT_KEY(svar_loc_189_918);
		 test_1792 = (aux_1795 == aux_1797);
	      }
	    else
	      {
		 test_1792 = ((bool_t) 0);
	      }
	    if (test_1792)
	      {
		 set_variable_name__102_cgen_prototype(global_36);
		 {
		    obj_t fname_920;
		    obj_t lnum_921;
		    obj_t id_922;
		    obj_t name_923;
		    fname_920 = STRUCT_REF(svar_loc_189_918, ((long) 0));
		    lnum_921 = STRUCT_REF(svar_loc_189_918, ((long) 2));
		    {
		       global_t obj_1514;
		       obj_1514 = (global_t) (global_36);
		       id_922 = (((global_t) CREF(obj_1514))->id);
		    }
		    {
		       global_t obj_1515;
		       obj_1515 = (global_t) (global_36);
		       name_923 = (((global_t) CREF(obj_1515))->name);
		    }
		    {
		       obj_t list1665_924;
		       {
			  obj_t arg1667_926;
			  {
			     obj_t arg1668_927;
			     {
				obj_t arg1670_929;
				{
				   obj_t arg1672_930;
				   arg1672_930 = MAKE_PAIR(string1888_bdb_emit, BNIL);
				   arg1670_929 = MAKE_PAIR(lnum_921, arg1672_930);
				}
				arg1668_927 = MAKE_PAIR(string1892_bdb_emit, arg1670_929);
			     }
			     arg1667_926 = MAKE_PAIR(fname_920, arg1668_927);
			  }
			  list1665_924 = MAKE_PAIR(string1885_bdb_emit, arg1667_926);
		       }
		       fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1665_924);
		    }
		    {
		       obj_t list1676_933;
		       {
			  obj_t arg1678_935;
			  {
			     obj_t arg1679_936;
			     {
				obj_t arg1681_938;
				{
				   obj_t arg1682_939;
				   arg1682_939 = MAKE_PAIR(string1894_bdb_emit, BNIL);
				   arg1681_938 = MAKE_PAIR(name_923, arg1682_939);
				}
				arg1679_936 = MAKE_PAIR(string1884_bdb_emit, arg1681_938);
			     }
			     arg1678_935 = MAKE_PAIR(id_922, arg1679_936);
			  }
			  list1676_933 = MAKE_PAIR(string1885_bdb_emit, arg1678_935);
		       }
		       return fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1676_933);
		    }
		 }
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* bdb-sfun! */ obj_t 
bdb_sfun__59_bdb_emit(value_t sfun_37)
{
   {
      obj_t l1448_943;
      {
	 sfun_t obj_1516;
	 obj_1516 = (sfun_t) (sfun_37);
	 l1448_943 = (((sfun_t) CREF(obj_1516))->args);
      }
    lname1449_944:
      if (PAIRP(l1448_943))
	{
	   bdb_emit_local_info__83_bdb_emit(CAR(l1448_943));
	   {
	      obj_t l1448_1823;
	      l1448_1823 = CDR(l1448_943);
	      l1448_943 = l1448_1823;
	      goto lname1449_944;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      node_t aux_1827;
      {
	 obj_t aux_1828;
	 {
	    sfun_t obj_1520;
	    obj_1520 = (sfun_t) (sfun_37);
	    aux_1828 = (((sfun_t) CREF(obj_1520))->body);
	 }
	 aux_1827 = (node_t) (aux_1828);
      }
      return bdb__20_bdb_emit(aux_1827);
   }
}


/* bdb-emit-local-info! */ obj_t 
bdb_emit_local_info__83_bdb_emit(obj_t local_38)
{
   {
      bool_t test_1833;
      {
	 bool_t test_1834;
	 {
	    local_t obj_1521;
	    obj_1521 = (local_t) (local_38);
	    test_1834 = (((local_t) CREF(obj_1521))->user__32);
	 }
	 if (test_1834)
	   {
	      obj_t aux_1841;
	      obj_t aux_1837;
	      aux_1841 = CNST_TABLE_REF(((long) 2));
	      {
		 type_t arg1706_965;
		 {
		    local_t obj_1522;
		    obj_1522 = (local_t) (local_38);
		    arg1706_965 = (((local_t) CREF(obj_1522))->type);
		 }
		 aux_1837 = (((type_t) CREF(arg1706_965))->class);
	      }
	      test_1833 = (aux_1837 == aux_1841);
	   }
	 else
	   {
	      test_1833 = ((bool_t) 0);
	   }
      }
      if (test_1833)
	{
	   set_variable_name__102_cgen_prototype(local_38);
	   {
	      obj_t id_951;
	      obj_t name_952;
	      {
		 local_t obj_1526;
		 obj_1526 = (local_t) (local_38);
		 id_951 = (((local_t) CREF(obj_1526))->id);
	      }
	      {
		 local_t obj_1527;
		 obj_1527 = (local_t) (local_38);
		 name_952 = (((local_t) CREF(obj_1527))->name);
	      }
	      {
		 obj_t list1693_953;
		 {
		    obj_t arg1695_955;
		    {
		       obj_t arg1697_956;
		       {
			  obj_t arg1699_958;
			  {
			     obj_t arg1700_959;
			     arg1700_959 = MAKE_PAIR(string1894_bdb_emit, BNIL);
			     arg1699_958 = MAKE_PAIR(name_952, arg1700_959);
			  }
			  arg1697_956 = MAKE_PAIR(string1884_bdb_emit, arg1699_958);
		       }
		       arg1695_955 = MAKE_PAIR(id_951, arg1697_956);
		    }
		    list1693_953 = MAKE_PAIR(string1898_bdb_emit, arg1695_955);
		 }
		 return fprint___r4_output_6_10_3(_c_port__188_bdb_emit, list1693_953);
	      }
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* bdb*! */ obj_t 
bdb___160_bdb_emit(obj_t nodes_56)
{
   {
      obj_t hook_966;
      hook_966 = nodes_56;
    loop_967:
      if (NULLP(hook_966))
	{
	   return CNST_TABLE_REF(((long) 3));
	}
      else
	{
	   {
	      node_t aux_1858;
	      {
		 obj_t aux_1859;
		 aux_1859 = CAR(hook_966);
		 aux_1858 = (node_t) (aux_1859);
	      }
	      bdb__20_bdb_emit(aux_1858);
	   }
	   {
	      obj_t hook_1863;
	      hook_1863 = CDR(hook_966);
	      hook_966 = hook_1863;
	      goto loop_967;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_bdb_emit()
{
   add_generic__110___object(bdb__env_49_bdb_emit, bdb__default1473_env_139_bdb_emit);
   add_inlined_method__244___object(bdb__env_49_bdb_emit, sequence_ast_node, ((long) 0));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, pragma_ast_node, ((long) 1));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, cast_ast_node, ((long) 2));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, setq_ast_node, ((long) 3));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, conditional_ast_node, ((long) 4));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, fail_ast_node, ((long) 5));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, select_ast_node, ((long) 6));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, let_fun_218_ast_node, ((long) 7));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, let_var_6_ast_node, ((long) 8));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, set_ex_it_116_ast_node, ((long) 9));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, jump_ex_it_184_ast_node, ((long) 10));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, make_box_202_ast_node, ((long) 11));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, box_set__221_ast_node, ((long) 12));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, app_ly_162_ast_node, ((long) 13));
   add_inlined_method__244___object(bdb__env_49_bdb_emit, funcall_ast_node, ((long) 14));
   {
      long aux_1881;
      aux_1881 = add_inlined_method__244___object(bdb__env_49_bdb_emit, app_ast_node, ((long) 15));
      return BINT(aux_1881);
   }
}


/* bdb! */ obj_t 
bdb__20_bdb_emit(node_t node_39)
{
 bdb__20_bdb_emit:
   {
      obj_t method1807_1309;
      obj_t class1812_1310;
      {
	 obj_t arg1815_1307;
	 obj_t arg1816_1308;
	 {
	    object_t obj_1531;
	    obj_1531 = (object_t) (node_39);
	    {
	       obj_t pre_method_105_1532;
	       pre_method_105_1532 = PROCEDURE_REF(bdb__env_49_bdb_emit, ((long) 2));
	       if (INTEGERP(pre_method_105_1532))
		 {
		    PROCEDURE_SET(bdb__env_49_bdb_emit, ((long) 2), BUNSPEC);
		    arg1815_1307 = pre_method_105_1532;
		 }
	       else
		 {
		    long obj_class_num_177_1537;
		    obj_class_num_177_1537 = TYPE(obj_1531);
		    {
		       obj_t arg1177_1538;
		       arg1177_1538 = PROCEDURE_REF(bdb__env_49_bdb_emit, ((long) 1));
		       {
			  long arg1178_1542;
			  {
			     long arg1179_1543;
			     arg1179_1543 = OBJECT_TYPE;
			     arg1178_1542 = (obj_class_num_177_1537 - arg1179_1543);
			  }
			  arg1815_1307 = VECTOR_REF(arg1177_1538, arg1178_1542);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1548;
	    object_1548 = (object_t) (node_39);
	    {
	       long arg1180_1549;
	       {
		  long arg1181_1550;
		  long arg1182_1551;
		  arg1181_1550 = TYPE(object_1548);
		  arg1182_1551 = OBJECT_TYPE;
		  arg1180_1549 = (arg1181_1550 - arg1182_1551);
	       }
	       {
		  obj_t vector_1555;
		  vector_1555 = _classes__134___object;
		  arg1816_1308 = VECTOR_REF(vector_1555, arg1180_1549);
	       }
	    }
	 }
	 method1807_1309 = arg1815_1307;
	 class1812_1310 = arg1816_1308;
	 {
	    if (INTEGERP(method1807_1309))
	      {
		 switch ((long) CINT(method1807_1309))
		   {
		   case ((long) 0):
		      {
			 sequence_t node_1316;
			 node_1316 = (sequence_t) (node_39);
			 return bdb___160_bdb_emit((((sequence_t) CREF(node_1316))->nodes));
		      }
		      break;
		   case ((long) 1):
		      {
			 pragma_t node_1319;
			 node_1319 = (pragma_t) (node_39);
			 return bdb___160_bdb_emit((((pragma_t) CREF(node_1319))->args));
		      }
		      break;
		   case ((long) 2):
		      {
			 cast_t node_1322;
			 node_1322 = (cast_t) (node_39);
			 {
			    node_t node_1908;
			    node_1908 = (((cast_t) CREF(node_1322))->arg);
			    node_39 = node_1908;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 setq_t node_1325;
			 node_1325 = (setq_t) (node_39);
			 {
			    node_t node_1911;
			    node_1911 = (((setq_t) CREF(node_1325))->value);
			    node_39 = node_1911;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 conditional_t node_1328;
			 node_1328 = (conditional_t) (node_39);
			 bdb__20_bdb_emit((((conditional_t) CREF(node_1328))->test));
			 bdb__20_bdb_emit((((conditional_t) CREF(node_1328))->true));
			 {
			    node_t node_1918;
			    node_1918 = (((conditional_t) CREF(node_1328))->false);
			    node_39 = node_1918;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 fail_t node_1333;
			 node_1333 = (fail_t) (node_39);
			 bdb__20_bdb_emit((((fail_t) CREF(node_1333))->proc));
			 bdb__20_bdb_emit((((fail_t) CREF(node_1333))->msg));
			 {
			    node_t node_1925;
			    node_1925 = (((fail_t) CREF(node_1333))->obj);
			    node_39 = node_1925;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 select_t node_1338;
			 node_1338 = (select_t) (node_39);
			 bdb__20_bdb_emit((((select_t) CREF(node_1338))->test));
			 {
			    obj_t l1457_1341;
			    {
			       bool_t aux_1930;
			       l1457_1341 = (((select_t) CREF(node_1338))->clauses);
			     lname1458_1342:
			       if (PAIRP(l1457_1341))
				 {
				    {
				       node_t aux_1933;
				       {
					  obj_t aux_1934;
					  {
					     obj_t aux_1935;
					     aux_1935 = CAR(l1457_1341);
					     aux_1934 = CDR(aux_1935);
					  }
					  aux_1933 = (node_t) (aux_1934);
				       }
				       bdb__20_bdb_emit(aux_1933);
				    }
				    {
				       obj_t l1457_1940;
				       l1457_1940 = CDR(l1457_1341);
				       l1457_1341 = l1457_1940;
				       goto lname1458_1342;
				    }
				 }
			       else
				 {
				    aux_1930 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1930);
			    }
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 let_fun_218_t node_1348;
			 node_1348 = (let_fun_218_t) (node_39);
			 {
			    obj_t l1460_1350;
			    l1460_1350 = (((let_fun_218_t) CREF(node_1348))->locals);
			  lname1461_1351:
			    if (PAIRP(l1460_1350))
			      {
				 {
				    value_t aux_1947;
				    {
				       local_t obj_1576;
				       {
					  obj_t aux_1948;
					  aux_1948 = CAR(l1460_1350);
					  obj_1576 = (local_t) (aux_1948);
				       }
				       aux_1947 = (((local_t) CREF(obj_1576))->value);
				    }
				    bdb_sfun__59_bdb_emit(aux_1947);
				 }
				 {
				    obj_t l1460_1953;
				    l1460_1953 = CDR(l1460_1350);
				    l1460_1350 = l1460_1953;
				    goto lname1461_1351;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1956;
			    node_1956 = (((let_fun_218_t) CREF(node_1348))->body);
			    node_39 = node_1956;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 let_var_6_t node_1358;
			 node_1358 = (let_var_6_t) (node_39);
			 {
			    obj_t l1463_1360;
			    l1463_1360 = (((let_var_6_t) CREF(node_1358))->bindings);
			  lname1464_1361:
			    if (PAIRP(l1463_1360))
			      {
				 {
				    obj_t binding_1364;
				    binding_1364 = CAR(l1463_1360);
				    {
				       node_t aux_1962;
				       {
					  obj_t aux_1963;
					  aux_1963 = CDR(binding_1364);
					  aux_1962 = (node_t) (aux_1963);
				       }
				       bdb__20_bdb_emit(aux_1962);
				    }
				    bdb_emit_local_info__83_bdb_emit(CAR(binding_1364));
				 }
				 {
				    obj_t l1463_1969;
				    l1463_1969 = CDR(l1463_1360);
				    l1463_1360 = l1463_1969;
				    goto lname1464_1361;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1972;
			    node_1972 = (((let_var_6_t) CREF(node_1358))->body);
			    node_39 = node_1972;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 set_ex_it_116_t node_1370;
			 node_1370 = (set_ex_it_116_t) (node_39);
			 {
			    node_t node_1975;
			    node_1975 = (((set_ex_it_116_t) CREF(node_1370))->body);
			    node_39 = node_1975;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 jump_ex_it_184_t node_1373;
			 node_1373 = (jump_ex_it_184_t) (node_39);
			 bdb__20_bdb_emit((((jump_ex_it_184_t) CREF(node_1373))->exit));
			 {
			    node_t node_1980;
			    node_1980 = (((jump_ex_it_184_t) CREF(node_1373))->value);
			    node_39 = node_1980;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 make_box_202_t node_1377;
			 node_1377 = (make_box_202_t) (node_39);
			 {
			    node_t node_1983;
			    node_1983 = (((make_box_202_t) CREF(node_1377))->value);
			    node_39 = node_1983;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 box_set__221_t node_1380;
			 node_1380 = (box_set__221_t) (node_39);
			 {
			    node_t node_1986;
			    node_1986 = (((box_set__221_t) CREF(node_1380))->value);
			    node_39 = node_1986;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 app_ly_162_t node_1383;
			 node_1383 = (app_ly_162_t) (node_39);
			 bdb__20_bdb_emit((((app_ly_162_t) CREF(node_1383))->fun));
			 {
			    node_t node_1991;
			    node_1991 = (((app_ly_162_t) CREF(node_1383))->arg);
			    node_39 = node_1991;
			    goto bdb__20_bdb_emit;
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 funcall_t node_1387;
			 node_1387 = (funcall_t) (node_39);
			 bdb__20_bdb_emit((((funcall_t) CREF(node_1387))->fun));
			 return bdb___160_bdb_emit((((funcall_t) CREF(node_1387))->args));
		      }
		      break;
		   case ((long) 15):
		      {
			 app_t node_1391;
			 node_1391 = (app_t) (node_39);
			 return bdb___160_bdb_emit((((app_t) CREF(node_1391))->args));
		      }
		      break;
		   default:
		    case_else1813_1313:
		      if (PROCEDUREP(method1807_1309))
			{
			   return PROCEDURE_ENTRY(method1807_1309) (method1807_1309, (obj_t) (node_39), BEOA);
			}
		      else
			{
			   obj_t fun1806_1305;
			   fun1806_1305 = PROCEDURE_REF(bdb__env_49_bdb_emit, ((long) 0));
			   return PROCEDURE_ENTRY(fun1806_1305) (fun1806_1305, (obj_t) (node_39), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1813_1313;
	      }
	 }
      }
   }
}


/* _bdb!1876 */ obj_t 
_bdb_1876_208_bdb_emit(obj_t env_1605, obj_t node_1606)
{
   return bdb__20_bdb_emit((node_t) (node_1606));
}


/* bdb!-default1473 */ obj_t 
bdb__default1473_159_bdb_emit(node_t node_40)
{
   return BUNSPEC;
}


/* _bdb!-default1473 */ obj_t 
_bdb__default1473_46_bdb_emit(obj_t env_1607, obj_t node_1608)
{
   return bdb__default1473_159_bdb_emit((node_t) (node_1608));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_bdb_emit()
{
   module_initialization_70_type_type(((long) 0), "BDB_EMIT");
   module_initialization_70_ast_var(((long) 0), "BDB_EMIT");
   module_initialization_70_ast_node(((long) 0), "BDB_EMIT");
   module_initialization_70_tools_shape(((long) 0), "BDB_EMIT");
   module_initialization_70_tools_error(((long) 0), "BDB_EMIT");
   module_initialization_70_tools_misc(((long) 0), "BDB_EMIT");
   module_initialization_70_tools_location(((long) 0), "BDB_EMIT");
   module_initialization_70_type_env(((long) 0), "BDB_EMIT");
   module_initialization_70_type_cache(((long) 0), "BDB_EMIT");
   module_initialization_70_ast_sexp(((long) 0), "BDB_EMIT");
   module_initialization_70_ast_env(((long) 0), "BDB_EMIT");
   module_initialization_70_ast_ident(((long) 0), "BDB_EMIT");
   module_initialization_70_ast_unit(((long) 0), "BDB_EMIT");
   module_initialization_70_module_module(((long) 0), "BDB_EMIT");
   module_initialization_70_module_include(((long) 0), "BDB_EMIT");
   module_initialization_70_engine_param(((long) 0), "BDB_EMIT");
   return module_initialization_70_cgen_prototype(((long) 0), "BDB_EMIT");
}
