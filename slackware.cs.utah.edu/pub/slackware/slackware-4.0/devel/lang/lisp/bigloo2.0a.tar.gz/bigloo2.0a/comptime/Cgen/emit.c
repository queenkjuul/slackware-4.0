/*===========================================================================*/
/*   (Cgen/emit.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t _stop_emission__69_cgen_emit(obj_t);
extern obj_t _src_files__222_engine_param;
extern obj_t current_output_port;
extern obj_t string_append(obj_t, obj_t);
extern obj_t bigloo_license_175_tools_license();
obj_t _c_port__188_cgen_emit = BUNSPEC;
static obj_t _start_emission_1293_214_cgen_emit(obj_t, obj_t);
static obj_t _emit_garbage_collector_selection_19_cgen_emit(obj_t);
static obj_t _emit_main_24_cgen_emit(obj_t);
extern obj_t stop_emission__231_cgen_emit();
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_license(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t read_line_110___r4_input_6_10_2(obj_t);
static obj_t _emit_header_145_cgen_emit(obj_t);
extern obj_t emit_garbage_collector_selection_89_cgen_emit();
static obj_t imported_modules_init_94_cgen_emit();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t emit_header_99_cgen_emit();
static obj_t _emit_debug_activation_100_cgen_emit(obj_t);
extern obj_t _dest__217_engine_param;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t _additional_include_foreign__44_engine_param;
extern obj_t prefix___os(obj_t);
static obj_t library_modules_init_112_cgen_emit();
extern obj_t start_emission__101_cgen_emit(obj_t);
extern obj_t _user_heap_size__225_engine_param;
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t emit_include_217_cgen_emit();
static obj_t toplevel_init_63_cgen_emit();
extern obj_t open_input_string(obj_t);
extern obj_t _bigloo_licensing___64_engine_param;
extern obj_t _bigloo_author__68_engine_param;
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t _bigloo_date__70_engine_param;
extern obj_t emit_comment_138_cgen_emit(obj_t, char);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t emit_license_138_cgen_emit();
extern obj_t close_input_port(obj_t);
extern obj_t _include_foreign__253_engine_param;
extern obj_t make_string(long, unsigned char);
extern obj_t c_substring(obj_t, long, long);
extern obj_t open_output_string();
extern obj_t emit_main_179_cgen_emit();
extern obj_t _bigloo_name__170_engine_param;
static obj_t _emit_include_89_cgen_emit(obj_t);
extern obj_t emit_debug_activation_148_cgen_emit();
static long _max_col__89_cgen_emit;
extern obj_t read___reader(obj_t);
static obj_t _dest_prefix__46_cgen_emit = BUNSPEC;
static obj_t _emit_comment1294_176_cgen_emit(obj_t, obj_t, obj_t);
extern obj_t _garbage_collector__95_engine_param;
extern obj_t open_output_file(obj_t);
static obj_t require_initialization_114_cgen_emit = BUNSPEC;
extern obj_t _pass__125_engine_param;
extern long _fx_15___r4_numbers_6_5_fixnum(long, long);
static obj_t cnst_init_137_cgen_emit();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(emit_garbage_collector_selection_env_133_cgen_emit, _emit_garbage_collector_selection_19_cgen_emit1323, _emit_garbage_collector_selection_19_cgen_emit, 0L, 0);
DEFINE_EXPORT_PROCEDURE(emit_main_env_112_cgen_emit, _emit_main_24_cgen_emit1324, _emit_main_24_cgen_emit, 0L, 0);
DEFINE_EXPORT_PROCEDURE(emit_header_env_184_cgen_emit, _emit_header_145_cgen_emit1325, _emit_header_145_cgen_emit, 0L, 0);
DEFINE_EXPORT_PROCEDURE(emit_comment_env_67_cgen_emit, _emit_comment1294_176_cgen_emit1326, _emit_comment1294_176_cgen_emit, 0L, 2);
DEFINE_EXPORT_PROCEDURE(stop_emission__env_198_cgen_emit, _stop_emission__69_cgen_emit1327, _stop_emission__69_cgen_emit, 0L, 0);
DEFINE_EXPORT_PROCEDURE(emit_include_env_152_cgen_emit, _emit_include_89_cgen_emit1328, _emit_include_89_cgen_emit, 0L, 0);
DEFINE_EXPORT_PROCEDURE(start_emission__env_25_cgen_emit, _start_emission_1293_214_cgen_emit1329, _start_emission_1293_214_cgen_emit, 0L, 1);
DEFINE_EXPORT_PROCEDURE(emit_debug_activation_env_82_cgen_emit, _emit_debug_activation_100_cgen_emit1330, _emit_debug_activation_100_cgen_emit, 0L, 0);
DEFINE_STRING(string1316_cgen_emit, string1316_cgen_emit1331, "BUMPY BOEHM --TO-STDOUT (CGEN DISTRIB CC CINDENT) ", 50);
DEFINE_STRING(string1315_cgen_emit, string1315_cgen_emit1332, "{", 1);
DEFINE_STRING(string1314_cgen_emit, string1314_cgen_emit1333, "_bigloo_main(argc, argv);}", 26);
DEFINE_STRING(string1313_cgen_emit, string1313_cgen_emit1334, "extern long heap_size; heap_size = ", 35);
DEFINE_STRING(string1312_cgen_emit, string1312_cgen_emit1335, ";", 1);
DEFINE_STRING(string1311_cgen_emit, string1311_cgen_emit1336, "int BIGLOO_MAIN(int argc, char *argv[])", 39);
DEFINE_STRING(string1299_cgen_emit, string1299_cgen_emit1337, " (c)      ", 10);
DEFINE_STRING(string1309_cgen_emit, string1309_cgen_emit1338, "#define BIGLOO_DEBUG 1", 22);
DEFINE_STRING(string1310_cgen_emit, string1310_cgen_emit1339, "extern int _bigloo_main();\n", 27);
DEFINE_STRING(string1298_cgen_emit, string1298_cgen_emit1340, "", 0);
DEFINE_STRING(string1308_cgen_emit, string1308_cgen_emit1341, "/* debug mode */", 16);
DEFINE_STRING(string1297_cgen_emit, string1297_cgen_emit1342, "*/", 2);
DEFINE_STRING(string1307_cgen_emit, string1307_cgen_emit1343, "#include <", 10);
DEFINE_STRING(string1296_cgen_emit, string1296_cgen_emit1344, "/*", 2);
DEFINE_STRING(string1306_cgen_emit, string1306_cgen_emit1345, ">", 1);
DEFINE_STRING(string1295_cgen_emit, string1295_cgen_emit1346, "Can't open file for output", 26);
DEFINE_STRING(string1305_cgen_emit, string1305_cgen_emit1347, "Can't emit code for gc", 22);
DEFINE_STRING(string1304_cgen_emit, string1304_cgen_emit1348, "emit-garbage-collector-selection", 32);
DEFINE_STRING(string1303_cgen_emit, string1303_cgen_emit1349, "#define BUMPY_GC\n", 17);
DEFINE_STRING(string1302_cgen_emit, string1302_cgen_emit1350, "#define THE_GC BOEHM_GC", 23);
DEFINE_STRING(string1301_cgen_emit, string1301_cgen_emit1351, "#define THE_GC BOEHM_GC\n", 24);
DEFINE_STRING(string1300_cgen_emit, string1300_cgen_emit1352, "/* GC selection */", 18);


/* module-initialization */ obj_t 
module_initialization_70_cgen_emit(long checksum_250, char *from_251)
{
   if (CBOOL(require_initialization_114_cgen_emit))
     {
	require_initialization_114_cgen_emit = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_emit();
	cnst_init_137_cgen_emit();
	imported_modules_init_94_cgen_emit();
	toplevel_init_63_cgen_emit();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_emit()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CGEN_EMIT");
   module_initialization_70___r4_input_6_10_2(((long) 0), "CGEN_EMIT");
   module_initialization_70___r4_strings_6_7(((long) 0), "CGEN_EMIT");
   module_initialization_70___os(((long) 0), "CGEN_EMIT");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "CGEN_EMIT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CGEN_EMIT");
   module_initialization_70___reader(((long) 0), "CGEN_EMIT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_emit()
{
   {
      obj_t cnst_port_138_242;
      cnst_port_138_242 = open_input_string(string1316_cgen_emit);
      {
	 long i_243;
	 i_243 = ((long) 3);
       loop_244:
	 {
	    bool_t test1317_245;
	    test1317_245 = (i_243 == ((long) -1));
	    if (test1317_245)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1319_246;
		    {
		       obj_t list1320_247;
		       {
			  obj_t arg1321_248;
			  arg1321_248 = BNIL;
			  list1320_247 = MAKE_PAIR(cnst_port_138_242, arg1321_248);
		       }
		       arg1319_246 = read___reader(list1320_247);
		    }
		    CNST_TABLE_SET(i_243, arg1319_246);
		 }
		 {
		    int aux_249;
		    {
		       long aux_272;
		       aux_272 = (i_243 - ((long) 1));
		       aux_249 = (int) (aux_272);
		    }
		    {
		       long i_275;
		       i_275 = (long) (aux_249);
		       i_243 = i_275;
		       goto loop_244;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_emit()
{
   _dest_prefix__46_cgen_emit = BFALSE;
   _c_port__188_cgen_emit = BFALSE;
   return (_max_col__89_cgen_emit = ((long) 79),
      BUNSPEC);
}


/* start-emission! */ obj_t 
start_emission__101_cgen_emit(obj_t suffix_1)
{
   {
      obj_t prefix_4;
      {
	 bool_t test1012_11;
	 {
	    bool_t test1015_14;
	    {
	       obj_t obj_155;
	       obj_155 = _dest__217_engine_param;
	       test1015_14 = STRINGP(obj_155);
	    }
	    if (test1015_14)
	      {
		 obj_t aux_279;
		 aux_279 = memq___r4_pairs_and_lists_6_3(_pass__125_engine_param, CNST_TABLE_REF(((long) 0)));
		 test1012_11 = CBOOL(aux_279);
	      }
	    else
	      {
		 test1012_11 = ((bool_t) 0);
	      }
	 }
	 if (test1012_11)
	   {
	      prefix_4 = prefix___os(_dest__217_engine_param);
	   }
	 else
	   {
	      bool_t test1013_12;
	      {
		 obj_t obj_156;
		 obj_156 = _src_files__222_engine_param;
		 test1013_12 = PAIRP(obj_156);
	      }
	      if (test1013_12)
		{
		   {
		      obj_t arg1014_13;
		      {
			 obj_t pair_157;
			 pair_157 = _src_files__222_engine_param;
			 arg1014_13 = CAR(pair_157);
		      }
		      prefix_4 = prefix___os(arg1014_13);
		   }
		}
	      else
		{
		   prefix_4 = BFALSE;
		}
	   }
      }
      {
	 {
	    bool_t test1006_5;
	    {
	       bool_t test1008_8;
	       {
		  obj_t obj1_158;
		  obj1_158 = _dest__217_engine_param;
		  {
		     obj_t aux_289;
		     aux_289 = CNST_TABLE_REF(((long) 1));
		     test1008_8 = (obj1_158 == aux_289);
		  }
	       }
	       if (test1008_8)
		 {
		    test1006_5 = ((bool_t) 1);
		 }
	       else
		 {
		    if (STRINGP(prefix_4))
		      {
			 test1006_5 = ((bool_t) 0);
		      }
		    else
		      {
			 test1006_5 = ((bool_t) 1);
		      }
		 }
	    }
	    if (test1006_5)
	      {
		 return (_c_port__188_cgen_emit = current_output_port,
		    BUNSPEC);
	      }
	    else
	      {
		 obj_t f_name_115_6;
		 f_name_115_6 = string_append(prefix_4, suffix_1);
		 _dest_prefix__46_cgen_emit = prefix_4;
		 _c_port__188_cgen_emit = open_output_file(f_name_115_6);
		 {
		    bool_t test1007_7;
		    {
		       obj_t obj_162;
		       obj_162 = _c_port__188_cgen_emit;
		       test1007_7 = OUTPUT_PORTP(obj_162);
		    }
		    if (test1007_7)
		      {
			 return BUNSPEC;
		      }
		    else
		      {
			 obj_t proc_163;
			 proc_163 = _bigloo_name__170_engine_param;
			 FAILURE(proc_163, string1295_cgen_emit, f_name_115_6);
		      }
		 }
	      }
	 }
      }
   }
}


/* _start-emission!1293 */ obj_t 
_start_emission_1293_214_cgen_emit(obj_t env_231, obj_t suffix_232)
{
   return start_emission__101_cgen_emit(suffix_232);
}


/* stop-emission! */ obj_t 
stop_emission__231_cgen_emit()
{
   {
      bool_t test1017_16;
      {
	 obj_t obj_166;
	 obj_166 = _c_port__188_cgen_emit;
	 test1017_16 = OUTPUT_PORTP(obj_166);
      }
      if (test1017_16)
	{
	   bool_t test1019_17;
	   {
	      obj_t obj1_167;
	      obj1_167 = _c_port__188_cgen_emit;
	      test1019_17 = (obj1_167 == current_output_port);
	   }
	   if (test1019_17)
	     {
		return BFALSE;
	     }
	   else
	     {
		{
		   obj_t port_169;
		   port_169 = _c_port__188_cgen_emit;
		   FLUSH_OUTPUT_PORT(port_169);
		}
		{
		   obj_t port_170;
		   port_170 = _c_port__188_cgen_emit;
		   close_output_port(port_170);
		}
		_c_port__188_cgen_emit = BFALSE;
		return _dest_prefix__46_cgen_emit;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _stop-emission! */ obj_t 
_stop_emission__69_cgen_emit(obj_t env_233)
{
   return stop_emission__231_cgen_emit();
}


/* emit-comment */ obj_t 
emit_comment_138_cgen_emit(obj_t string_2, char fill_3)
{
   {
      obj_t string_19;
      {
	 bool_t test_309;
	 {
	    long aux_312;
	    long aux_310;
	    aux_312 = (((long) 79) - ((long) 8));
	    aux_310 = STRING_LENGTH(string_2);
	    test_309 = (aux_310 > aux_312);
	 }
	 if (test_309)
	   {
	      long aux_315;
	      aux_315 = (((long) 79) - ((long) 9));
	      string_19 = c_substring(string_2, ((long) 0), aux_315);
	   }
	 else
	   {
	      string_19 = string_2;
	   }
      }
      {
	 obj_t list1021_20;
	 list1021_20 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	 display___r4_output_6_10_3(string1296_cgen_emit, list1021_20);
      }
      {
	 long len_22;
	 len_22 = STRING_LENGTH(string_19);
	 if ((len_22 == ((long) 0)))
	   {
	      obj_t arg1032_24;
	      {
		 long arg1040_29;
		 arg1040_29 = (((long) 79) - ((long) 4));
		 {
		    obj_t list1041_30;
		    {
		       obj_t aux_324;
		       aux_324 = BCHAR(fill_3);
		       list1041_30 = MAKE_PAIR(aux_324, BNIL);
		    }
		    {
		       obj_t res1289_192;
		       {
			  unsigned char aux_331;
			  long aux_327;
			  {
			     obj_t aux_332;
			     aux_332 = CAR(list1041_30);
			     aux_331 = (unsigned char) CCHAR(aux_332);
			  }
			  {
			     int aux_328;
			     aux_328 = (int) (arg1040_29);
			     aux_327 = (long) (aux_328);
			  }
			  res1289_192 = make_string(aux_327, aux_331);
		       }
		       arg1032_24 = res1289_192;
		    }
		 }
	      }
	      {
		 obj_t list1035_26;
		 {
		    obj_t arg1038_27;
		    arg1038_27 = MAKE_PAIR(string1297_cgen_emit, BNIL);
		    list1035_26 = MAKE_PAIR(arg1032_24, arg1038_27);
		 }
		 return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1035_26);
	      }
	   }
	 else
	   {
	      {
		 obj_t arg1055_32;
		 {
		    obj_t list1058_35;
		    {
		       obj_t aux_339;
		       aux_339 = BCHAR(fill_3);
		       list1058_35 = MAKE_PAIR(aux_339, BNIL);
		    }
		    {
		       obj_t res1290_199;
		       {
			  unsigned char aux_346;
			  long aux_342;
			  {
			     obj_t aux_347;
			     aux_347 = CAR(list1058_35);
			     aux_346 = (unsigned char) CCHAR(aux_347);
			  }
			  {
			     int aux_343;
			     aux_343 = (int) (((long) 2));
			     aux_342 = (long) (aux_343);
			  }
			  res1290_199 = make_string(aux_342, aux_346);
		       }
		       arg1055_32 = res1290_199;
		    }
		 }
		 {
		    obj_t list1056_33;
		    list1056_33 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		    display___r4_output_6_10_3(arg1055_32, list1056_33);
		 }
	      }
	      {
		 obj_t list1060_37;
		 list1060_37 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		 display___r4_output_6_10_3(BCHAR(((unsigned char) ' ')), list1060_37);
	      }
	      {
		 obj_t list1062_39;
		 list1062_39 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		 display___r4_output_6_10_3(string_19, list1062_39);
	      }
	      {
		 obj_t list1064_41;
		 list1064_41 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		 display___r4_output_6_10_3(BCHAR(((unsigned char) ' ')), list1064_41);
	      }
	      {
		 obj_t arg1066_43;
		 {
		    long arg1144_48;
		    {
		       long aux_361;
		       {
			  obj_t aux_362;
			  {
			     long aux_363;
			     aux_363 = _fx_15___r4_numbers_6_5_fixnum(((long) 8), len_22);
			     aux_362 = BINT(aux_363);
			  }
			  aux_361 = (long) CINT(aux_362);
		       }
		       arg1144_48 = (((long) 79) - aux_361);
		    }
		    {
		       obj_t list1145_49;
		       {
			  obj_t aux_368;
			  aux_368 = BCHAR(fill_3);
			  list1145_49 = MAKE_PAIR(aux_368, BNIL);
		       }
		       {
			  obj_t res1291_208;
			  {
			     unsigned char aux_375;
			     long aux_371;
			     {
				obj_t aux_376;
				aux_376 = CAR(list1145_49);
				aux_375 = (unsigned char) CCHAR(aux_376);
			     }
			     {
				int aux_372;
				aux_372 = (int) (arg1144_48);
				aux_371 = (long) (aux_372);
			     }
			     res1291_208 = make_string(aux_371, aux_375);
			  }
			  arg1066_43 = res1291_208;
		       }
		    }
		 }
		 {
		    obj_t list1078_45;
		    {
		       obj_t arg1137_46;
		       arg1137_46 = MAKE_PAIR(string1297_cgen_emit, BNIL);
		       list1078_45 = MAKE_PAIR(arg1066_43, arg1137_46);
		    }
		    return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1078_45);
		 }
	      }
	   }
      }
   }
}


/* _emit-comment1294 */ obj_t 
_emit_comment1294_176_cgen_emit(obj_t env_234, obj_t string_235, obj_t fill_236)
{
   return emit_comment_138_cgen_emit(string_235, CCHAR(fill_236));
}


/* emit-license */ obj_t 
emit_license_138_cgen_emit()
{
   {
      obj_t in_57;
      {
	 obj_t arg1195_67;
	 arg1195_67 = bigloo_license_175_tools_license();
	 in_57 = open_input_string(arg1195_67);
      }
      {
	 obj_t str_58;
	 {
	    obj_t arg1187_60;
	    {
	       obj_t list1188_61;
	       list1188_61 = MAKE_PAIR(in_57, BNIL);
	       arg1187_60 = read_line_110___r4_input_6_10_2(list1188_61);
	    }
	    str_58 = arg1187_60;
	  loop_59:
	    {
	       bool_t test1191_63;
	       test1191_63 = EOF_OBJECTP(str_58);
	       if (test1191_63)
		 {
		    return close_input_port(in_57);
		 }
	       else
		 {
		    emit_comment_138_cgen_emit(str_58, (char) (((unsigned char) ' ')));
		    {
		       obj_t arg1192_64;
		       {
			  obj_t list1193_65;
			  list1193_65 = MAKE_PAIR(in_57, BNIL);
			  arg1192_64 = read_line_110___r4_input_6_10_2(list1193_65);
		       }
		       {
			  obj_t str_396;
			  str_396 = arg1192_64;
			  str_58 = str_396;
			  goto loop_59;
		       }
		    }
		 }
	    }
	 }
      }
   }
}


/* emit-header */ obj_t 
emit_header_99_cgen_emit()
{
   emit_comment_138_cgen_emit(string1298_cgen_emit, (char) (((unsigned char) '=')));
   {
      obj_t arg1196_68;
      {
	 obj_t p_69;
	 p_69 = open_output_string();
	 {
	    obj_t list1197_70;
	    list1197_70 = MAKE_PAIR(p_69, BNIL);
	    display___r4_output_6_10_3(_src_files__222_engine_param, list1197_70);
	 }
	 arg1196_68 = close_output_port(p_69);
      }
      emit_comment_138_cgen_emit(arg1196_68, (char) (((unsigned char) ' ')));
   }
   emit_comment_138_cgen_emit(_bigloo_name__170_engine_param, (char) (((unsigned char) ' ')));
   {
      obj_t arg1200_72;
      {
	 obj_t list1201_73;
	 {
	    obj_t arg1202_74;
	    {
	       obj_t arg1204_76;
	       arg1204_76 = MAKE_PAIR(_bigloo_date__70_engine_param, BNIL);
	       arg1202_74 = MAKE_PAIR(string1299_cgen_emit, arg1204_76);
	    }
	    list1201_73 = MAKE_PAIR(_bigloo_author__68_engine_param, arg1202_74);
	 }
	 arg1200_72 = string_append_106___r4_strings_6_7(list1201_73);
      }
      emit_comment_138_cgen_emit(arg1200_72, (char) (((unsigned char) ' ')));
   }
   if (CBOOL(_bigloo_licensing___64_engine_param))
     {
	emit_license_138_cgen_emit();
     }
   else
     {
	BUNSPEC;
     }
   emit_comment_138_cgen_emit(string1298_cgen_emit, (char) (((unsigned char) '=')));
   {
      obj_t list1206_78;
      list1206_78 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
      return newline___r4_output_6_10_3(list1206_78);
   }
}


/* _emit-header */ obj_t 
_emit_header_145_cgen_emit(obj_t env_237)
{
   return emit_header_99_cgen_emit();
}


/* emit-garbage-collector-selection */ obj_t 
emit_garbage_collector_selection_89_cgen_emit()
{
   {
      obj_t list1208_80;
      list1208_80 = MAKE_PAIR(string1300_cgen_emit, BNIL);
      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1208_80);
   }
   {
      obj_t case_value_58_83;
      case_value_58_83 = _garbage_collector__95_engine_param;
      {
	 bool_t test_423;
	 {
	    obj_t aux_424;
	    aux_424 = CNST_TABLE_REF(((long) 2));
	    test_423 = (case_value_58_83 == aux_424);
	 }
	 if (test_423)
	   {
	      obj_t list1212_85;
	      list1212_85 = MAKE_PAIR(string1301_cgen_emit, BNIL);
	      return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1212_85);
	   }
	 else
	   {
	      bool_t test_429;
	      {
		 obj_t aux_430;
		 aux_430 = CNST_TABLE_REF(((long) 3));
		 test_429 = (case_value_58_83 == aux_430);
	      }
	      if (test_429)
		{
		   {
		      obj_t list1216_89;
		      list1216_89 = MAKE_PAIR(string1302_cgen_emit, BNIL);
		      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1216_89);
		   }
		   {
		      obj_t list1221_92;
		      list1221_92 = MAKE_PAIR(string1303_cgen_emit, BNIL);
		      return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1221_92);
		   }
		}
	      else
		{
		   obj_t object_219;
		   object_219 = _garbage_collector__95_engine_param;
		   FAILURE(string1304_cgen_emit, string1305_cgen_emit, object_219);
		}
	   }
      }
   }
}


/* _emit-garbage-collector-selection */ obj_t 
_emit_garbage_collector_selection_19_cgen_emit(obj_t env_238)
{
   return emit_garbage_collector_selection_89_cgen_emit();
}


/* emit-include */ obj_t 
emit_include_217_cgen_emit()
{
   {
      obj_t l1002_97;
      {
	 obj_t arg1228_99;
	 arg1228_99 = reverse__39___r4_pairs_and_lists_6_3(_include_foreign__253_engine_param);
	 l1002_97 = arg1228_99;
       lname1003_98:
	 if (PAIRP(l1002_97))
	   {
	      {
		 obj_t i_101;
		 i_101 = CAR(l1002_97);
		 {
		    obj_t list1230_102;
		    {
		       obj_t arg1232_104;
		       {
			  obj_t arg1233_105;
			  arg1233_105 = MAKE_PAIR(string1306_cgen_emit, BNIL);
			  arg1232_104 = MAKE_PAIR(i_101, arg1233_105);
		       }
		       list1230_102 = MAKE_PAIR(string1307_cgen_emit, arg1232_104);
		    }
		    fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1230_102);
		 }
	      }
	      {
		 obj_t l1002_447;
		 l1002_447 = CDR(l1002_97);
		 l1002_97 = l1002_447;
		 goto lname1003_98;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   {
      obj_t l1004_109;
      {
	 obj_t arg1238_111;
	 arg1238_111 = reverse__39___r4_pairs_and_lists_6_3(_additional_include_foreign__44_engine_param);
	 l1004_109 = arg1238_111;
       lname1005_110:
	 if (PAIRP(l1004_109))
	   {
	      {
		 obj_t i_113;
		 i_113 = CAR(l1004_109);
		 {
		    obj_t list1240_114;
		    {
		       obj_t arg1243_116;
		       {
			  obj_t arg1244_117;
			  arg1244_117 = MAKE_PAIR(string1306_cgen_emit, BNIL);
			  arg1243_116 = MAKE_PAIR(i_113, arg1244_117);
		       }
		       list1240_114 = MAKE_PAIR(string1307_cgen_emit, arg1243_116);
		    }
		    fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1240_114);
		 }
	      }
	      {
		 obj_t l1004_457;
		 l1004_457 = CDR(l1004_109);
		 l1004_109 = l1004_457;
		 goto lname1005_110;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   {
      obj_t list1249_121;
      list1249_121 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
      return newline___r4_output_6_10_3(list1249_121);
   }
}


/* _emit-include */ obj_t 
_emit_include_89_cgen_emit(obj_t env_239)
{
   return emit_include_217_cgen_emit();
}


/* emit-debug-activation */ obj_t 
emit_debug_activation_148_cgen_emit()
{
   {
      obj_t list1251_123;
      list1251_123 = MAKE_PAIR(string1308_cgen_emit, BNIL);
      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1251_123);
   }
   {
      obj_t list1254_126;
      list1254_126 = MAKE_PAIR(string1309_cgen_emit, BNIL);
      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1254_126);
   }
   {
      obj_t list1257_129;
      list1257_129 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
      return newline___r4_output_6_10_3(list1257_129);
   }
}


/* _emit-debug-activation */ obj_t 
_emit_debug_activation_100_cgen_emit(obj_t env_240)
{
   return emit_debug_activation_148_cgen_emit();
}


/* emit-main */ obj_t 
emit_main_179_cgen_emit()
{
   {
      obj_t list1259_131;
      list1259_131 = MAKE_PAIR(string1310_cgen_emit, BNIL);
      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1259_131);
   }
   {
      obj_t list1263_134;
      list1263_134 = MAKE_PAIR(string1311_cgen_emit, BNIL);
      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1263_134);
   }
   {
      obj_t arg1269_138;
      {
	 bool_t test1275_144;
	 {
	    bool_t res1292_230;
	    {
	       obj_t obj_226;
	       obj_226 = _user_heap_size__225_engine_param;
	       if (INTEGERP(obj_226))
		 {
		    res1292_230 = ((bool_t) 1);
		 }
	       else
		 {
		    res1292_230 = REALP(obj_226);
		 }
	    }
	    test1275_144 = res1292_230;
	 }
	 if (test1275_144)
	   {
	      char *arg1278_146;
	      arg1278_146 = integer__string_135___r4_numbers_6_5_fixnum((long) CINT(_user_heap_size__225_engine_param), BNIL);
	      {
		 obj_t list1282_148;
		 {
		    obj_t arg1283_149;
		    {
		       obj_t arg1284_150;
		       arg1284_150 = MAKE_PAIR(string1312_cgen_emit, BNIL);
		       {
			  obj_t aux_480;
			  aux_480 = string_to_bstring(arg1278_146);
			  arg1283_149 = MAKE_PAIR(aux_480, arg1284_150);
		       }
		    }
		    list1282_148 = MAKE_PAIR(string1313_cgen_emit, arg1283_149);
		 }
		 arg1269_138 = string_append_106___r4_strings_6_7(list1282_148);
	      }
	   }
	 else
	   {
	      arg1269_138 = string1298_cgen_emit;
	   }
      }
      {
	 obj_t list1271_140;
	 {
	    obj_t arg1272_141;
	    {
	       obj_t arg1273_142;
	       arg1273_142 = MAKE_PAIR(string1314_cgen_emit, BNIL);
	       arg1272_141 = MAKE_PAIR(arg1269_138, arg1273_142);
	    }
	    list1271_140 = MAKE_PAIR(string1315_cgen_emit, arg1272_141);
	 }
	 fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1271_140);
      }
   }
   {
      obj_t list1287_153;
      list1287_153 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
      return newline___r4_output_6_10_3(list1287_153);
   }
}


/* _emit-main */ obj_t 
_emit_main_24_cgen_emit(obj_t env_241)
{
   return emit_main_179_cgen_emit();
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_emit()
{
   module_initialization_70_engine_param(((long) 0), "CGEN_EMIT");
   return module_initialization_70_tools_license(((long) 0), "CGEN_EMIT");
}
