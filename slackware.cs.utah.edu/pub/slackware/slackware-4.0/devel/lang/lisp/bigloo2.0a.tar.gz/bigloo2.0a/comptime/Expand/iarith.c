/*===========================================================================*/
/*   (Expand/iarith.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t expand__fx_28_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand__fx_224_expand_iarithmetique(obj_t, obj_t);
extern obj_t module_initialization_70_expand_iarithmetique(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _expand_i_1693_202_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i_1690_216_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i_1689_155_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand__fx1696_15_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i__1694_12_expand_iarithmetique(obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_i_1692_119_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_expand_iarithmetique();
static obj_t _expand_i_1688_75_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i__1695_8_expand_iarithmetique(obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t expand_i___111_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i___87_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__249_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__244_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__45_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__142_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__227_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__179_expand_iarithmetique(obj_t, obj_t);
extern obj_t expand_i__62_expand_iarithmetique(obj_t, obj_t);
static obj_t _expand_i_1687_108_expand_iarithmetique(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand__fx1697_218_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_i_1691_27_expand_iarithmetique(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_expand_iarithmetique = BUNSPEC;
static obj_t cnst_init_137_expand_iarithmetique();
static obj_t __cnst[18];

DEFINE_EXPORT_PROCEDURE(expand_i__env_215_expand_iarithmetique, _expand_i_1693_202_expand_iarithmetique1706, _expand_i_1693_202_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i___env_190_expand_iarithmetique, _expand_i__1695_8_expand_iarithmetique1707, _expand_i__1695_8_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i__env_160_expand_iarithmetique, _expand_i_1690_216_expand_iarithmetique1708, _expand_i_1690_216_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i__env_3_expand_iarithmetique, _expand_i_1689_155_expand_iarithmetique1709, _expand_i_1689_155_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i__env_125_expand_iarithmetique, _expand_i_1692_119_expand_iarithmetique1710, _expand_i_1692_119_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i__env_129_expand_iarithmetique, _expand_i_1688_75_expand_iarithmetique1711, _expand_i_1688_75_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand__fx_env_131_expand_iarithmetique, _expand__fx1697_218_expand_iarithmetique1712, _expand__fx1697_218_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i__env_112_expand_iarithmetique, _expand_i_1687_108_expand_iarithmetique1713, _expand_i_1687_108_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i__env_212_expand_iarithmetique, _expand_i_1691_27_expand_iarithmetique1714, _expand_i_1691_27_expand_iarithmetique, 0L, 2);
DEFINE_STRING(string1699_expand_iarithmetique, string1699_expand_iarithmetique1715, "Incorrect number of arguments for `-fx'", 39);
DEFINE_STRING(string1698_expand_iarithmetique, string1698_expand_iarithmetique1716, "Incorrect number of arguments for `+fx'", 39);
DEFINE_STRING(string1700_expand_iarithmetique, string1700_expand_iarithmetique1717, ">= >=FX <= <=FX > >FX < <FX = AND =FX /FX * *FX -FX NEGFX + +FX ", 64);
DEFINE_EXPORT_PROCEDURE(expand__fx_env_33_expand_iarithmetique, _expand__fx1696_15_expand_iarithmetique1718, _expand__fx1696_15_expand_iarithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_i___env_234_expand_iarithmetique, _expand_i__1694_12_expand_iarithmetique1719, _expand_i__1694_12_expand_iarithmetique, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_expand_iarithmetique(long checksum_877, char *from_878)
{
   if (CBOOL(require_initialization_114_expand_iarithmetique))
     {
	require_initialization_114_expand_iarithmetique = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_iarithmetique();
	cnst_init_137_expand_iarithmetique();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_iarithmetique()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_IARITHMETIQUE");
   module_initialization_70___reader(((long) 0), "EXPAND_IARITHMETIQUE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_iarithmetique()
{
   {
      obj_t cnst_port_138_869;
      cnst_port_138_869 = open_input_string(string1700_expand_iarithmetique);
      {
	 long i_870;
	 i_870 = ((long) 17);
       loop_871:
	 {
	    bool_t test1701_872;
	    test1701_872 = (i_870 == ((long) -1));
	    if (test1701_872)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1702_873;
		    {
		       obj_t list1703_874;
		       {
			  obj_t arg1704_875;
			  arg1704_875 = BNIL;
			  list1703_874 = MAKE_PAIR(cnst_port_138_869, arg1704_875);
		       }
		       arg1702_873 = read___reader(list1703_874);
		    }
		    CNST_TABLE_SET(i_870, arg1702_873);
		 }
		 {
		    int aux_876;
		    {
		       long aux_892;
		       aux_892 = (i_870 - ((long) 1));
		       aux_876 = (int) (aux_892);
		    }
		    {
		       long i_895;
		       i_895 = (long) (aux_876);
		       i_870 = i_895;
		       goto loop_871;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-i+ */ obj_t 
expand_i__179_expand_iarithmetique(obj_t x_1, obj_t e_2)
{
   {
      obj_t x_29;
      obj_t y_30;
      obj_t x_26;
      obj_t y_27;
      if (PAIRP(x_1))
	{
	   bool_t test_899;
	   {
	      obj_t aux_900;
	      aux_900 = CDR(x_1);
	      test_899 = (aux_900 == BNIL);
	   }
	   if (test_899)
	     {
		return BINT(((long) 0));
	     }
	   else
	     {
		obj_t cdr_114_48_35;
		cdr_114_48_35 = CDR(x_1);
		if (PAIRP(cdr_114_48_35))
		  {
		     bool_t test_907;
		     {
			obj_t aux_908;
			aux_908 = CDR(cdr_114_48_35);
			test_907 = (aux_908 == BNIL);
		     }
		     if (test_907)
		       {
			  return PROCEDURE_ENTRY(e_2) (e_2, CAR(cdr_114_48_35), e_2, BEOA);
		       }
		     else
		       {
			  obj_t cdr_130_105_40;
			  cdr_130_105_40 = CDR(cdr_114_48_35);
			  if (PAIRP(cdr_130_105_40))
			    {
			       bool_t test_917;
			       {
				  obj_t aux_918;
				  aux_918 = CDR(cdr_130_105_40);
				  test_917 = (aux_918 == BNIL);
			       }
			       if (test_917)
				 {
				    x_26 = CAR(cdr_114_48_35);
				    y_27 = CAR(cdr_130_105_40);
				    {
				       bool_t test_921;
				       if (INTEGERP(x_26))
					 {
					    test_921 = INTEGERP(y_27);
					 }
				       else
					 {
					    test_921 = ((bool_t) 0);
					 }
				       if (test_921)
					 {
					    {
					       long aux_925;
					       {
						  long aux_928;
						  long aux_926;
						  aux_928 = (long) CINT(y_27);
						  aux_926 = (long) CINT(x_26);
						  aux_925 = (aux_926 + aux_928);
					       }
					       return BINT(aux_925);
					    }
					 }
				       else
					 {
					    {
					       obj_t arg1053_58;
					       {
						  obj_t arg1055_59;
						  arg1055_59 = CNST_TABLE_REF(((long) 0));
						  {
						     obj_t list1057_61;
						     {
							obj_t arg1058_62;
							{
							   obj_t arg1059_63;
							   arg1059_63 = MAKE_PAIR(BNIL, BNIL);
							   arg1058_62 = MAKE_PAIR(y_27, arg1059_63);
							}
							list1057_61 = MAKE_PAIR(x_26, arg1058_62);
						     }
						     arg1053_58 = cons__138___r4_pairs_and_lists_6_3(arg1055_59, list1057_61);
						  }
					       }
					       return PROCEDURE_ENTRY(e_2) (e_2, arg1053_58, e_2, BEOA);
					    }
					 }
				    }
				 }
			       else
				 {
				    x_29 = CAR(cdr_114_48_35);
				    y_30 = CDR(cdr_114_48_35);
				  tag_104_254_31:
				    {
				       obj_t arg1077_66;
				       {
					  obj_t arg1137_67;
					  obj_t arg1142_68;
					  arg1137_67 = CNST_TABLE_REF(((long) 0));
					  {
					     obj_t arg1163_74;
					     obj_t arg1175_75;
					     arg1163_74 = CNST_TABLE_REF(((long) 1));
					     {
						obj_t arg1188_78;
						arg1188_78 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg1175_75 = append_2_18___r4_pairs_and_lists_6_3(y_30, arg1188_78);
					     }
					     {
						obj_t list1176_76;
						list1176_76 = MAKE_PAIR(arg1175_75, BNIL);
						arg1142_68 = cons__138___r4_pairs_and_lists_6_3(arg1163_74, list1176_76);
					     }
					  }
					  {
					     obj_t list1145_70;
					     {
						obj_t arg1150_71;
						{
						   obj_t arg1157_72;
						   arg1157_72 = MAKE_PAIR(BNIL, BNIL);
						   arg1150_71 = MAKE_PAIR(arg1142_68, arg1157_72);
						}
						list1145_70 = MAKE_PAIR(x_29, arg1150_71);
					     }
					     arg1077_66 = cons__138___r4_pairs_and_lists_6_3(arg1137_67, list1145_70);
					  }
				       }
				       return PROCEDURE_ENTRY(e_2) (e_2, arg1077_66, e_2, BEOA);
				    }
				 }
			    }
			  else
			    {
			       obj_t y_957;
			       obj_t x_955;
			       x_955 = CAR(cdr_114_48_35);
			       y_957 = CDR(cdr_114_48_35);
			       y_30 = y_957;
			       x_29 = x_955;
			       goto tag_104_254_31;
			    }
		       }
		  }
		else
		  {
		     return BFALSE;
		  }
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i+1687 */ obj_t 
_expand_i_1687_108_expand_iarithmetique(obj_t env_836, obj_t x_837, obj_t e_838)
{
   return expand_i__179_expand_iarithmetique(x_837, e_838);
}


/* expand-i- */ obj_t 
expand_i__227_expand_iarithmetique(obj_t x_3, obj_t e_4)
{
   {
      obj_t x_86;
      obj_t y_87;
      obj_t x_83;
      obj_t y_84;
      obj_t x_81;
      if (PAIRP(x_3))
	{
	   obj_t cdr_194_69_91;
	   cdr_194_69_91 = CDR(x_3);
	   if (PAIRP(cdr_194_69_91))
	     {
		bool_t test_965;
		{
		   obj_t aux_966;
		   aux_966 = CDR(cdr_194_69_91);
		   test_965 = (aux_966 == BNIL);
		}
		if (test_965)
		  {
		     x_81 = CAR(cdr_194_69_91);
		     if (INTEGERP(x_81))
		       {
			  {
			     long aux_971;
			     {
				long aux_972;
				aux_972 = (long) CINT(x_81);
				aux_971 = NEG(aux_972);
			     }
			     return BINT(aux_971);
			  }
		       }
		     else
		       {
			  {
			     obj_t arg1211_112;
			     obj_t arg1213_113;
			     arg1211_112 = CNST_TABLE_REF(((long) 2));
			     arg1213_113 = PROCEDURE_ENTRY(e_4) (e_4, x_81, e_4, BEOA);
			     {
				obj_t list1215_115;
				{
				   obj_t arg1216_116;
				   arg1216_116 = MAKE_PAIR(BNIL, BNIL);
				   list1215_115 = MAKE_PAIR(arg1213_113, arg1216_116);
				}
				return cons__138___r4_pairs_and_lists_6_3(arg1211_112, list1215_115);
			     }
			  }
		       }
		  }
		else
		  {
		     obj_t cdr_210_15_96;
		     cdr_210_15_96 = CDR(cdr_194_69_91);
		     if (PAIRP(cdr_210_15_96))
		       {
			  bool_t test_986;
			  {
			     obj_t aux_987;
			     aux_987 = CDR(cdr_210_15_96);
			     test_986 = (aux_987 == BNIL);
			  }
			  if (test_986)
			    {
			       x_83 = CAR(cdr_194_69_91);
			       y_84 = CAR(cdr_210_15_96);
			       {
				  bool_t test_990;
				  if (INTEGERP(x_83))
				    {
				       test_990 = INTEGERP(y_84);
				    }
				  else
				    {
				       test_990 = ((bool_t) 0);
				    }
				  if (test_990)
				    {
				       {
					  long aux_994;
					  {
					     long aux_997;
					     long aux_995;
					     aux_997 = (long) CINT(y_84);
					     aux_995 = (long) CINT(x_83);
					     aux_994 = (aux_995 - aux_997);
					  }
					  return BINT(aux_994);
				       }
				    }
				  else
				    {
				       {
					  obj_t arg1221_119;
					  {
					     obj_t arg1222_120;
					     arg1222_120 = CNST_TABLE_REF(((long) 3));
					     {
						obj_t list1225_122;
						{
						   obj_t arg1226_123;
						   {
						      obj_t arg1228_124;
						      arg1228_124 = MAKE_PAIR(BNIL, BNIL);
						      arg1226_123 = MAKE_PAIR(y_84, arg1228_124);
						   }
						   list1225_122 = MAKE_PAIR(x_83, arg1226_123);
						}
						arg1221_119 = cons__138___r4_pairs_and_lists_6_3(arg1222_120, list1225_122);
					     }
					  }
					  return PROCEDURE_ENTRY(e_4) (e_4, arg1221_119, e_4, BEOA);
				       }
				    }
			       }
			    }
			  else
			    {
			       x_86 = CAR(cdr_194_69_91);
			       y_87 = CDR(cdr_194_69_91);
			     tag_188_216_88:
			       {
				  obj_t arg1233_127;
				  {
				     obj_t arg1234_128;
				     obj_t arg1235_129;
				     arg1234_128 = CNST_TABLE_REF(((long) 3));
				     {
					obj_t arg1243_135;
					obj_t arg1244_136;
					arg1243_135 = CNST_TABLE_REF(((long) 1));
					{
					   obj_t arg1248_139;
					   arg1248_139 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					   arg1244_136 = append_2_18___r4_pairs_and_lists_6_3(y_87, arg1248_139);
					}
					{
					   obj_t list1245_137;
					   list1245_137 = MAKE_PAIR(arg1244_136, BNIL);
					   arg1235_129 = cons__138___r4_pairs_and_lists_6_3(arg1243_135, list1245_137);
					}
				     }
				     {
					obj_t list1237_131;
					{
					   obj_t arg1238_132;
					   {
					      obj_t arg1240_133;
					      arg1240_133 = MAKE_PAIR(BNIL, BNIL);
					      arg1238_132 = MAKE_PAIR(arg1235_129, arg1240_133);
					   }
					   list1237_131 = MAKE_PAIR(x_86, arg1238_132);
					}
					arg1233_127 = cons__138___r4_pairs_and_lists_6_3(arg1234_128, list1237_131);
				     }
				  }
				  return PROCEDURE_ENTRY(e_4) (e_4, arg1233_127, e_4, BEOA);
			       }
			    }
		       }
		     else
		       {
			  obj_t y_1026;
			  obj_t x_1024;
			  x_1024 = CAR(cdr_194_69_91);
			  y_1026 = CDR(cdr_194_69_91);
			  y_87 = y_1026;
			  x_86 = x_1024;
			  goto tag_188_216_88;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i-1688 */ obj_t 
_expand_i_1688_75_expand_iarithmetique(obj_t env_839, obj_t x_840, obj_t e_841)
{
   return expand_i__227_expand_iarithmetique(x_840, e_841);
}


/* expand-i* */ obj_t 
expand_i__62_expand_iarithmetique(obj_t x_5, obj_t e_6)
{
   {
      obj_t x_148;
      obj_t y_149;
      obj_t x_145;
      obj_t y_146;
      if (PAIRP(x_5))
	{
	   bool_t test_1031;
	   {
	      obj_t aux_1032;
	      aux_1032 = CDR(x_5);
	      test_1031 = (aux_1032 == BNIL);
	   }
	   if (test_1031)
	     {
		return BINT(((long) 1));
	     }
	   else
	     {
		obj_t cdr_276_172_154;
		cdr_276_172_154 = CDR(x_5);
		if (PAIRP(cdr_276_172_154))
		  {
		     bool_t test_1039;
		     {
			obj_t aux_1040;
			aux_1040 = CDR(cdr_276_172_154);
			test_1039 = (aux_1040 == BNIL);
		     }
		     if (test_1039)
		       {
			  return PROCEDURE_ENTRY(e_6) (e_6, CAR(cdr_276_172_154), e_6, BEOA);
		       }
		     else
		       {
			  obj_t cdr_292_5_159;
			  cdr_292_5_159 = CDR(cdr_276_172_154);
			  if (PAIRP(cdr_292_5_159))
			    {
			       bool_t test_1049;
			       {
				  obj_t aux_1050;
				  aux_1050 = CDR(cdr_292_5_159);
				  test_1049 = (aux_1050 == BNIL);
			       }
			       if (test_1049)
				 {
				    x_145 = CAR(cdr_276_172_154);
				    y_146 = CAR(cdr_292_5_159);
				    {
				       bool_t test_1053;
				       if (INTEGERP(x_145))
					 {
					    test_1053 = INTEGERP(y_146);
					 }
				       else
					 {
					    test_1053 = ((bool_t) 0);
					 }
				       if (test_1053)
					 {
					    {
					       long aux_1057;
					       {
						  long aux_1060;
						  long aux_1058;
						  aux_1060 = (long) CINT(y_146);
						  aux_1058 = (long) CINT(x_145);
						  aux_1057 = (aux_1058 * aux_1060);
					       }
					       return BINT(aux_1057);
					    }
					 }
				       else
					 {
					    {
					       obj_t arg1277_177;
					       {
						  obj_t arg1278_178;
						  arg1278_178 = CNST_TABLE_REF(((long) 4));
						  {
						     obj_t list1282_180;
						     {
							obj_t arg1283_181;
							{
							   obj_t arg1284_182;
							   arg1284_182 = MAKE_PAIR(BNIL, BNIL);
							   arg1283_181 = MAKE_PAIR(y_146, arg1284_182);
							}
							list1282_180 = MAKE_PAIR(x_145, arg1283_181);
						     }
						     arg1277_177 = cons__138___r4_pairs_and_lists_6_3(arg1278_178, list1282_180);
						  }
					       }
					       return PROCEDURE_ENTRY(e_6) (e_6, arg1277_177, e_6, BEOA);
					    }
					 }
				    }
				 }
			       else
				 {
				    x_148 = CAR(cdr_276_172_154);
				    y_149 = CDR(cdr_276_172_154);
				  tag_266_56_150:
				    {
				       obj_t arg1287_185;
				       {
					  obj_t arg1288_186;
					  obj_t arg1290_187;
					  arg1288_186 = CNST_TABLE_REF(((long) 4));
					  {
					     obj_t arg1297_193;
					     obj_t arg1298_194;
					     arg1297_193 = CNST_TABLE_REF(((long) 5));
					     {
						obj_t arg1301_197;
						arg1301_197 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg1298_194 = append_2_18___r4_pairs_and_lists_6_3(y_149, arg1301_197);
					     }
					     {
						obj_t list1299_195;
						list1299_195 = MAKE_PAIR(arg1298_194, BNIL);
						arg1290_187 = cons__138___r4_pairs_and_lists_6_3(arg1297_193, list1299_195);
					     }
					  }
					  {
					     obj_t list1292_189;
					     {
						obj_t arg1294_190;
						{
						   obj_t arg1295_191;
						   arg1295_191 = MAKE_PAIR(BNIL, BNIL);
						   arg1294_190 = MAKE_PAIR(arg1290_187, arg1295_191);
						}
						list1292_189 = MAKE_PAIR(x_148, arg1294_190);
					     }
					     arg1287_185 = cons__138___r4_pairs_and_lists_6_3(arg1288_186, list1292_189);
					  }
				       }
				       return PROCEDURE_ENTRY(e_6) (e_6, arg1287_185, e_6, BEOA);
				    }
				 }
			    }
			  else
			    {
			       obj_t y_1089;
			       obj_t x_1087;
			       x_1087 = CAR(cdr_276_172_154);
			       y_1089 = CDR(cdr_276_172_154);
			       y_149 = y_1089;
			       x_148 = x_1087;
			       goto tag_266_56_150;
			    }
		       }
		  }
		else
		  {
		     return BFALSE;
		  }
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i*1689 */ obj_t 
_expand_i_1689_155_expand_iarithmetique(obj_t env_842, obj_t x_843, obj_t e_844)
{
   return expand_i__62_expand_iarithmetique(x_843, e_844);
}


/* expand-i/ */ obj_t 
expand_i__142_expand_iarithmetique(obj_t x_7, obj_t e_8)
{
   {
      obj_t x_205;
      obj_t y_206;
      obj_t x_202;
      obj_t y_203;
      obj_t x_200;
      if (PAIRP(x_7))
	{
	   obj_t cdr_356_4_210;
	   cdr_356_4_210 = CDR(x_7);
	   if (PAIRP(cdr_356_4_210))
	     {
		bool_t test_1097;
		{
		   obj_t aux_1098;
		   aux_1098 = CDR(cdr_356_4_210);
		   test_1097 = (aux_1098 == BNIL);
		}
		if (test_1097)
		  {
		     x_200 = CAR(cdr_356_4_210);
		     {
			obj_t arg1325_230;
			obj_t arg1328_232;
			arg1325_230 = CNST_TABLE_REF(((long) 6));
			arg1328_232 = PROCEDURE_ENTRY(e_8) (e_8, x_200, e_8, BEOA);
			{
			   obj_t list1331_234;
			   {
			      obj_t arg1332_235;
			      {
				 obj_t arg1333_236;
				 arg1333_236 = MAKE_PAIR(BNIL, BNIL);
				 arg1332_235 = MAKE_PAIR(arg1328_232, arg1333_236);
			      }
			      {
				 obj_t aux_1106;
				 aux_1106 = BINT(((long) 1));
				 list1331_234 = MAKE_PAIR(aux_1106, arg1332_235);
			      }
			   }
			   return cons__138___r4_pairs_and_lists_6_3(arg1325_230, list1331_234);
			}
		     }
		  }
		else
		  {
		     obj_t cdr_372_212_215;
		     cdr_372_212_215 = CDR(cdr_356_4_210);
		     if (PAIRP(cdr_372_212_215))
		       {
			  bool_t test_1114;
			  {
			     obj_t aux_1115;
			     aux_1115 = CDR(cdr_372_212_215);
			     test_1114 = (aux_1115 == BNIL);
			  }
			  if (test_1114)
			    {
			       x_202 = CAR(cdr_356_4_210);
			       y_203 = CAR(cdr_372_212_215);
			       {
				  bool_t test_1118;
				  if (INTEGERP(x_202))
				    {
				       test_1118 = INTEGERP(y_203);
				    }
				  else
				    {
				       test_1118 = ((bool_t) 0);
				    }
				  if (test_1118)
				    {
				       {
					  long aux_1122;
					  {
					     long aux_1125;
					     long aux_1123;
					     aux_1125 = (long) CINT(y_203);
					     aux_1123 = (long) CINT(x_202);
					     aux_1122 = (aux_1123 / aux_1125);
					  }
					  return BINT(aux_1122);
				       }
				    }
				  else
				    {
				       {
					  obj_t arg1337_239;
					  {
					     obj_t arg1339_240;
					     arg1339_240 = CNST_TABLE_REF(((long) 6));
					     {
						obj_t list1341_242;
						{
						   obj_t arg1342_243;
						   {
						      obj_t arg1343_244;
						      arg1343_244 = MAKE_PAIR(BNIL, BNIL);
						      arg1342_243 = MAKE_PAIR(y_203, arg1343_244);
						   }
						   list1341_242 = MAKE_PAIR(x_202, arg1342_243);
						}
						arg1337_239 = cons__138___r4_pairs_and_lists_6_3(arg1339_240, list1341_242);
					     }
					  }
					  return PROCEDURE_ENTRY(e_8) (e_8, arg1337_239, e_8, BEOA);
				       }
				    }
			       }
			    }
			  else
			    {
			       x_205 = CAR(cdr_356_4_210);
			       y_206 = CDR(cdr_356_4_210);
			     tag_350_155_207:
			       {
				  obj_t arg1347_247;
				  {
				     obj_t arg1349_248;
				     obj_t arg1350_249;
				     arg1349_248 = CNST_TABLE_REF(((long) 6));
				     {
					obj_t arg1357_255;
					obj_t arg1361_256;
					arg1357_255 = CNST_TABLE_REF(((long) 5));
					{
					   obj_t arg1364_259;
					   arg1364_259 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					   arg1361_256 = append_2_18___r4_pairs_and_lists_6_3(y_206, arg1364_259);
					}
					{
					   obj_t list1362_257;
					   list1362_257 = MAKE_PAIR(arg1361_256, BNIL);
					   arg1350_249 = cons__138___r4_pairs_and_lists_6_3(arg1357_255, list1362_257);
					}
				     }
				     {
					obj_t list1352_251;
					{
					   obj_t arg1353_252;
					   {
					      obj_t arg1355_253;
					      arg1355_253 = MAKE_PAIR(BNIL, BNIL);
					      arg1353_252 = MAKE_PAIR(arg1350_249, arg1355_253);
					   }
					   list1352_251 = MAKE_PAIR(x_205, arg1353_252);
					}
					arg1347_247 = cons__138___r4_pairs_and_lists_6_3(arg1349_248, list1352_251);
				     }
				  }
				  return PROCEDURE_ENTRY(e_8) (e_8, arg1347_247, e_8, BEOA);
			       }
			    }
		       }
		     else
		       {
			  obj_t y_1154;
			  obj_t x_1152;
			  x_1152 = CAR(cdr_356_4_210);
			  y_1154 = CDR(cdr_356_4_210);
			  y_206 = y_1154;
			  x_205 = x_1152;
			  goto tag_350_155_207;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i/1690 */ obj_t 
_expand_i_1690_216_expand_iarithmetique(obj_t env_845, obj_t x_846, obj_t e_847)
{
   return expand_i__142_expand_iarithmetique(x_846, e_847);
}


/* expand-i= */ obj_t 
expand_i__244_expand_iarithmetique(obj_t x_9, obj_t e_10)
{
   {
      obj_t x_265;
      obj_t y_266;
      obj_t x_262;
      obj_t y_263;
      if (PAIRP(x_9))
	{
	   obj_t cdr_433_16_270;
	   cdr_433_16_270 = CDR(x_9);
	   if (PAIRP(cdr_433_16_270))
	     {
		obj_t cdr_437_8_272;
		cdr_437_8_272 = CDR(cdr_433_16_270);
		if (PAIRP(cdr_437_8_272))
		  {
		     bool_t test_1165;
		     {
			obj_t aux_1166;
			aux_1166 = CDR(cdr_437_8_272);
			test_1165 = (aux_1166 == BNIL);
		     }
		     if (test_1165)
		       {
			  x_262 = CAR(cdr_433_16_270);
			  y_263 = CAR(cdr_437_8_272);
			  {
			     bool_t test_1169;
			     if (INTEGERP(x_262))
			       {
				  test_1169 = INTEGERP(y_263);
			       }
			     else
			       {
				  test_1169 = ((bool_t) 0);
			       }
			     if (test_1169)
			       {
				  {
				     bool_t aux_1173;
				     {
					long aux_1176;
					long aux_1174;
					aux_1176 = (long) CINT(y_263);
					aux_1174 = (long) CINT(x_262);
					aux_1173 = (aux_1174 == aux_1176);
				     }
				     return BBOOL(aux_1173);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1387_286;
				     {
					obj_t arg1388_287;
					arg1388_287 = CNST_TABLE_REF(((long) 7));
					{
					   obj_t list1390_289;
					   {
					      obj_t arg1391_290;
					      {
						 obj_t arg1392_291;
						 arg1392_291 = MAKE_PAIR(BNIL, BNIL);
						 arg1391_290 = MAKE_PAIR(y_263, arg1392_291);
					      }
					      list1390_289 = MAKE_PAIR(x_262, arg1391_290);
					   }
					   arg1387_286 = cons__138___r4_pairs_and_lists_6_3(arg1388_287, list1390_289);
					}
				     }
				     return PROCEDURE_ENTRY(e_10) (e_10, arg1387_286, e_10, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_265 = CAR(cdr_433_16_270);
			  y_266 = CDR(cdr_433_16_270);
			tag_426_245_267:
			  {
			     obj_t arg1395_294;
			     {
				obj_t arg1396_295;
				obj_t arg1397_296;
				obj_t arg1398_297;
				arg1396_295 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1405_303;
				   obj_t arg1407_304;
				   arg1405_303 = CNST_TABLE_REF(((long) 7));
				   arg1407_304 = CAR(y_266);
				   {
				      obj_t list1409_306;
				      {
					 obj_t arg1410_307;
					 {
					    obj_t arg1411_308;
					    arg1411_308 = MAKE_PAIR(BNIL, BNIL);
					    arg1410_307 = MAKE_PAIR(arg1407_304, arg1411_308);
					 }
					 list1409_306 = MAKE_PAIR(x_265, arg1410_307);
				      }
				      arg1397_296 = cons__138___r4_pairs_and_lists_6_3(arg1405_303, list1409_306);
				   }
				}
				{
				   obj_t arg1414_310;
				   obj_t arg1415_311;
				   arg1414_310 = CNST_TABLE_REF(((long) 9));
				   {
				      obj_t arg1418_314;
				      arg1418_314 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1415_311 = append_2_18___r4_pairs_and_lists_6_3(y_266, arg1418_314);
				   }
				   {
				      obj_t list1416_312;
				      list1416_312 = MAKE_PAIR(arg1415_311, BNIL);
				      arg1398_297 = cons__138___r4_pairs_and_lists_6_3(arg1414_310, list1416_312);
				   }
				}
				{
				   obj_t list1400_299;
				   {
				      obj_t arg1401_300;
				      {
					 obj_t arg1402_301;
					 arg1402_301 = MAKE_PAIR(BNIL, BNIL);
					 arg1401_300 = MAKE_PAIR(arg1398_297, arg1402_301);
				      }
				      list1400_299 = MAKE_PAIR(arg1397_296, arg1401_300);
				   }
				   arg1395_294 = cons__138___r4_pairs_and_lists_6_3(arg1396_295, list1400_299);
				}
			     }
			     return PROCEDURE_ENTRY(e_10) (e_10, arg1395_294, e_10, BEOA);
			  }
		       }
		  }
		else
		  {
		     obj_t y_1211;
		     obj_t x_1209;
		     x_1209 = CAR(cdr_433_16_270);
		     y_1211 = CDR(cdr_433_16_270);
		     y_266 = y_1211;
		     x_265 = x_1209;
		     goto tag_426_245_267;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i=1691 */ obj_t 
_expand_i_1691_27_expand_iarithmetique(obj_t env_848, obj_t x_849, obj_t e_850)
{
   return expand_i__244_expand_iarithmetique(x_849, e_850);
}


/* expand-i< */ obj_t 
expand_i__45_expand_iarithmetique(obj_t x_11, obj_t e_12)
{
   {
      obj_t x_320;
      obj_t y_321;
      obj_t x_317;
      obj_t y_318;
      if (PAIRP(x_11))
	{
	   obj_t cdr_489_159_325;
	   cdr_489_159_325 = CDR(x_11);
	   if (PAIRP(cdr_489_159_325))
	     {
		obj_t cdr_493_219_327;
		cdr_493_219_327 = CDR(cdr_489_159_325);
		if (PAIRP(cdr_493_219_327))
		  {
		     bool_t test_1222;
		     {
			obj_t aux_1223;
			aux_1223 = CDR(cdr_493_219_327);
			test_1222 = (aux_1223 == BNIL);
		     }
		     if (test_1222)
		       {
			  x_317 = CAR(cdr_489_159_325);
			  y_318 = CAR(cdr_493_219_327);
			  {
			     bool_t test_1226;
			     if (INTEGERP(x_317))
			       {
				  test_1226 = INTEGERP(y_318);
			       }
			     else
			       {
				  test_1226 = ((bool_t) 0);
			       }
			     if (test_1226)
			       {
				  {
				     bool_t aux_1230;
				     {
					long aux_1233;
					long aux_1231;
					aux_1233 = (long) CINT(y_318);
					aux_1231 = (long) CINT(x_317);
					aux_1230 = (aux_1231 < aux_1233);
				     }
				     return BBOOL(aux_1230);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1440_341;
				     {
					obj_t arg1441_342;
					arg1441_342 = CNST_TABLE_REF(((long) 10));
					{
					   obj_t list1444_344;
					   {
					      obj_t arg1446_345;
					      {
						 obj_t arg1448_346;
						 arg1448_346 = MAKE_PAIR(BNIL, BNIL);
						 arg1446_345 = MAKE_PAIR(y_318, arg1448_346);
					      }
					      list1444_344 = MAKE_PAIR(x_317, arg1446_345);
					   }
					   arg1440_341 = cons__138___r4_pairs_and_lists_6_3(arg1441_342, list1444_344);
					}
				     }
				     return PROCEDURE_ENTRY(e_12) (e_12, arg1440_341, e_12, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_320 = CAR(cdr_489_159_325);
			  y_321 = CDR(cdr_489_159_325);
			tag_482_221_322:
			  {
			     obj_t arg1453_349;
			     {
				obj_t arg1454_350;
				obj_t arg1455_351;
				obj_t arg1456_352;
				arg1454_350 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1464_358;
				   obj_t arg1465_359;
				   arg1464_358 = CNST_TABLE_REF(((long) 10));
				   arg1465_359 = CAR(y_321);
				   {
				      obj_t list1467_361;
				      {
					 obj_t arg1468_362;
					 {
					    obj_t arg1469_363;
					    arg1469_363 = MAKE_PAIR(BNIL, BNIL);
					    arg1468_362 = MAKE_PAIR(arg1465_359, arg1469_363);
					 }
					 list1467_361 = MAKE_PAIR(x_320, arg1468_362);
				      }
				      arg1455_351 = cons__138___r4_pairs_and_lists_6_3(arg1464_358, list1467_361);
				   }
				}
				{
				   obj_t arg1471_365;
				   obj_t arg1473_366;
				   arg1471_365 = CNST_TABLE_REF(((long) 11));
				   {
				      obj_t arg1476_369;
				      arg1476_369 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1473_366 = append_2_18___r4_pairs_and_lists_6_3(y_321, arg1476_369);
				   }
				   {
				      obj_t list1474_367;
				      list1474_367 = MAKE_PAIR(arg1473_366, BNIL);
				      arg1456_352 = cons__138___r4_pairs_and_lists_6_3(arg1471_365, list1474_367);
				   }
				}
				{
				   obj_t list1459_354;
				   {
				      obj_t arg1460_355;
				      {
					 obj_t arg1461_356;
					 arg1461_356 = MAKE_PAIR(BNIL, BNIL);
					 arg1460_355 = MAKE_PAIR(arg1456_352, arg1461_356);
				      }
				      list1459_354 = MAKE_PAIR(arg1455_351, arg1460_355);
				   }
				   arg1453_349 = cons__138___r4_pairs_and_lists_6_3(arg1454_350, list1459_354);
				}
			     }
			     return PROCEDURE_ENTRY(e_12) (e_12, arg1453_349, e_12, BEOA);
			  }
		       }
		  }
		else
		  {
		     obj_t y_1268;
		     obj_t x_1266;
		     x_1266 = CAR(cdr_489_159_325);
		     y_1268 = CDR(cdr_489_159_325);
		     y_321 = y_1268;
		     x_320 = x_1266;
		     goto tag_482_221_322;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i<1692 */ obj_t 
_expand_i_1692_119_expand_iarithmetique(obj_t env_851, obj_t x_852, obj_t e_853)
{
   return expand_i__45_expand_iarithmetique(x_852, e_853);
}


/* expand-i> */ obj_t 
expand_i__249_expand_iarithmetique(obj_t x_13, obj_t e_14)
{
   {
      obj_t x_375;
      obj_t y_376;
      obj_t x_372;
      obj_t y_373;
      if (PAIRP(x_13))
	{
	   obj_t cdr_545_224_380;
	   cdr_545_224_380 = CDR(x_13);
	   if (PAIRP(cdr_545_224_380))
	     {
		obj_t cdr_549_13_382;
		cdr_549_13_382 = CDR(cdr_545_224_380);
		if (PAIRP(cdr_549_13_382))
		  {
		     bool_t test_1279;
		     {
			obj_t aux_1280;
			aux_1280 = CDR(cdr_549_13_382);
			test_1279 = (aux_1280 == BNIL);
		     }
		     if (test_1279)
		       {
			  x_372 = CAR(cdr_545_224_380);
			  y_373 = CAR(cdr_549_13_382);
			  {
			     bool_t test_1283;
			     if (INTEGERP(x_372))
			       {
				  test_1283 = INTEGERP(y_373);
			       }
			     else
			       {
				  test_1283 = ((bool_t) 0);
			       }
			     if (test_1283)
			       {
				  {
				     bool_t aux_1287;
				     {
					long aux_1290;
					long aux_1288;
					aux_1290 = (long) CINT(y_373);
					aux_1288 = (long) CINT(x_372);
					aux_1287 = (aux_1288 > aux_1290);
				     }
				     return BBOOL(aux_1287);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1494_396;
				     {
					obj_t arg1496_397;
					arg1496_397 = CNST_TABLE_REF(((long) 12));
					{
					   obj_t list1498_399;
					   {
					      obj_t arg1499_400;
					      {
						 obj_t arg1500_401;
						 arg1500_401 = MAKE_PAIR(BNIL, BNIL);
						 arg1499_400 = MAKE_PAIR(y_373, arg1500_401);
					      }
					      list1498_399 = MAKE_PAIR(x_372, arg1499_400);
					   }
					   arg1494_396 = cons__138___r4_pairs_and_lists_6_3(arg1496_397, list1498_399);
					}
				     }
				     return PROCEDURE_ENTRY(e_14) (e_14, arg1494_396, e_14, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_375 = CAR(cdr_545_224_380);
			  y_376 = CDR(cdr_545_224_380);
			tag_538_11_377:
			  {
			     obj_t arg1503_404;
			     {
				obj_t arg1504_405;
				obj_t arg1505_406;
				obj_t arg1507_407;
				arg1504_405 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1516_413;
				   obj_t arg1517_414;
				   arg1516_413 = CNST_TABLE_REF(((long) 12));
				   arg1517_414 = CAR(y_376);
				   {
				      obj_t list1519_416;
				      {
					 obj_t arg1522_417;
					 {
					    obj_t arg1524_418;
					    arg1524_418 = MAKE_PAIR(BNIL, BNIL);
					    arg1522_417 = MAKE_PAIR(arg1517_414, arg1524_418);
					 }
					 list1519_416 = MAKE_PAIR(x_375, arg1522_417);
				      }
				      arg1505_406 = cons__138___r4_pairs_and_lists_6_3(arg1516_413, list1519_416);
				   }
				}
				{
				   obj_t arg1526_420;
				   obj_t arg1527_421;
				   arg1526_420 = CNST_TABLE_REF(((long) 13));
				   {
				      obj_t arg1530_424;
				      arg1530_424 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1527_421 = append_2_18___r4_pairs_and_lists_6_3(y_376, arg1530_424);
				   }
				   {
				      obj_t list1528_422;
				      list1528_422 = MAKE_PAIR(arg1527_421, BNIL);
				      arg1507_407 = cons__138___r4_pairs_and_lists_6_3(arg1526_420, list1528_422);
				   }
				}
				{
				   obj_t list1511_409;
				   {
				      obj_t arg1513_410;
				      {
					 obj_t arg1514_411;
					 arg1514_411 = MAKE_PAIR(BNIL, BNIL);
					 arg1513_410 = MAKE_PAIR(arg1507_407, arg1514_411);
				      }
				      list1511_409 = MAKE_PAIR(arg1505_406, arg1513_410);
				   }
				   arg1503_404 = cons__138___r4_pairs_and_lists_6_3(arg1504_405, list1511_409);
				}
			     }
			     return PROCEDURE_ENTRY(e_14) (e_14, arg1503_404, e_14, BEOA);
			  }
		       }
		  }
		else
		  {
		     obj_t y_1325;
		     obj_t x_1323;
		     x_1323 = CAR(cdr_545_224_380);
		     y_1325 = CDR(cdr_545_224_380);
		     y_376 = y_1325;
		     x_375 = x_1323;
		     goto tag_538_11_377;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i>1693 */ obj_t 
_expand_i_1693_202_expand_iarithmetique(obj_t env_854, obj_t x_855, obj_t e_856)
{
   return expand_i__249_expand_iarithmetique(x_855, e_856);
}


/* expand-i<= */ obj_t 
expand_i___87_expand_iarithmetique(obj_t x_15, obj_t e_16)
{
   {
      obj_t x_430;
      obj_t y_431;
      obj_t x_427;
      obj_t y_428;
      if (PAIRP(x_15))
	{
	   obj_t cdr_601_218_435;
	   cdr_601_218_435 = CDR(x_15);
	   if (PAIRP(cdr_601_218_435))
	     {
		obj_t cdr_605_106_437;
		cdr_605_106_437 = CDR(cdr_601_218_435);
		if (PAIRP(cdr_605_106_437))
		  {
		     bool_t test_1336;
		     {
			obj_t aux_1337;
			aux_1337 = CDR(cdr_605_106_437);
			test_1336 = (aux_1337 == BNIL);
		     }
		     if (test_1336)
		       {
			  x_427 = CAR(cdr_601_218_435);
			  y_428 = CAR(cdr_605_106_437);
			  {
			     bool_t test_1340;
			     if (INTEGERP(x_427))
			       {
				  test_1340 = INTEGERP(y_428);
			       }
			     else
			       {
				  test_1340 = ((bool_t) 0);
			       }
			     if (test_1340)
			       {
				  {
				     bool_t aux_1344;
				     {
					long aux_1347;
					long aux_1345;
					aux_1347 = (long) CINT(y_428);
					aux_1345 = (long) CINT(x_427);
					aux_1344 = (aux_1345 <= aux_1347);
				     }
				     return BBOOL(aux_1344);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1552_451;
				     {
					obj_t arg1553_452;
					arg1553_452 = CNST_TABLE_REF(((long) 14));
					{
					   obj_t list1555_454;
					   {
					      obj_t arg1556_455;
					      {
						 obj_t arg1557_456;
						 arg1557_456 = MAKE_PAIR(BNIL, BNIL);
						 arg1556_455 = MAKE_PAIR(y_428, arg1557_456);
					      }
					      list1555_454 = MAKE_PAIR(x_427, arg1556_455);
					   }
					   arg1552_451 = cons__138___r4_pairs_and_lists_6_3(arg1553_452, list1555_454);
					}
				     }
				     return PROCEDURE_ENTRY(e_16) (e_16, arg1552_451, e_16, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_430 = CAR(cdr_601_218_435);
			  y_431 = CDR(cdr_601_218_435);
			tag_594_124_432:
			  {
			     obj_t arg1560_459;
			     {
				obj_t arg1561_460;
				obj_t arg1562_461;
				obj_t arg1563_462;
				arg1561_460 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1570_468;
				   obj_t arg1572_469;
				   arg1570_468 = CNST_TABLE_REF(((long) 14));
				   arg1572_469 = CAR(y_431);
				   {
				      obj_t list1574_471;
				      {
					 obj_t arg1575_472;
					 {
					    obj_t arg1578_473;
					    arg1578_473 = MAKE_PAIR(BNIL, BNIL);
					    arg1575_472 = MAKE_PAIR(arg1572_469, arg1578_473);
					 }
					 list1574_471 = MAKE_PAIR(x_430, arg1575_472);
				      }
				      arg1562_461 = cons__138___r4_pairs_and_lists_6_3(arg1570_468, list1574_471);
				   }
				}
				{
				   obj_t arg1581_475;
				   obj_t arg1582_476;
				   arg1581_475 = CNST_TABLE_REF(((long) 15));
				   {
				      obj_t arg1585_479;
				      arg1585_479 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1582_476 = append_2_18___r4_pairs_and_lists_6_3(y_431, arg1585_479);
				   }
				   {
				      obj_t list1583_477;
				      list1583_477 = MAKE_PAIR(arg1582_476, BNIL);
				      arg1563_462 = cons__138___r4_pairs_and_lists_6_3(arg1581_475, list1583_477);
				   }
				}
				{
				   obj_t list1565_464;
				   {
				      obj_t arg1566_465;
				      {
					 obj_t arg1568_466;
					 arg1568_466 = MAKE_PAIR(BNIL, BNIL);
					 arg1566_465 = MAKE_PAIR(arg1563_462, arg1568_466);
				      }
				      list1565_464 = MAKE_PAIR(arg1562_461, arg1566_465);
				   }
				   arg1560_459 = cons__138___r4_pairs_and_lists_6_3(arg1561_460, list1565_464);
				}
			     }
			     return PROCEDURE_ENTRY(e_16) (e_16, arg1560_459, e_16, BEOA);
			  }
		       }
		  }
		else
		  {
		     obj_t y_1382;
		     obj_t x_1380;
		     x_1380 = CAR(cdr_601_218_435);
		     y_1382 = CDR(cdr_601_218_435);
		     y_431 = y_1382;
		     x_430 = x_1380;
		     goto tag_594_124_432;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i<=1694 */ obj_t 
_expand_i__1694_12_expand_iarithmetique(obj_t env_857, obj_t x_858, obj_t e_859)
{
   return expand_i___87_expand_iarithmetique(x_858, e_859);
}


/* expand-i>= */ obj_t 
expand_i___111_expand_iarithmetique(obj_t x_17, obj_t e_18)
{
   {
      obj_t x_485;
      obj_t y_486;
      obj_t x_482;
      obj_t y_483;
      if (PAIRP(x_17))
	{
	   obj_t cdr_657_74_490;
	   cdr_657_74_490 = CDR(x_17);
	   if (PAIRP(cdr_657_74_490))
	     {
		obj_t cdr_661_253_492;
		cdr_661_253_492 = CDR(cdr_657_74_490);
		if (PAIRP(cdr_661_253_492))
		  {
		     bool_t test_1393;
		     {
			obj_t aux_1394;
			aux_1394 = CDR(cdr_661_253_492);
			test_1393 = (aux_1394 == BNIL);
		     }
		     if (test_1393)
		       {
			  x_482 = CAR(cdr_657_74_490);
			  y_483 = CAR(cdr_661_253_492);
			  {
			     bool_t test_1397;
			     if (INTEGERP(x_482))
			       {
				  test_1397 = INTEGERP(y_483);
			       }
			     else
			       {
				  test_1397 = ((bool_t) 0);
			       }
			     if (test_1397)
			       {
				  {
				     bool_t aux_1401;
				     {
					long aux_1404;
					long aux_1402;
					aux_1404 = (long) CINT(y_483);
					aux_1402 = (long) CINT(x_482);
					aux_1401 = (aux_1402 >= aux_1404);
				     }
				     return BBOOL(aux_1401);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1605_506;
				     {
					obj_t arg1606_507;
					arg1606_507 = CNST_TABLE_REF(((long) 16));
					{
					   obj_t list1608_509;
					   {
					      obj_t arg1609_510;
					      {
						 obj_t arg1610_511;
						 arg1610_511 = MAKE_PAIR(BNIL, BNIL);
						 arg1609_510 = MAKE_PAIR(y_483, arg1610_511);
					      }
					      list1608_509 = MAKE_PAIR(x_482, arg1609_510);
					   }
					   arg1605_506 = cons__138___r4_pairs_and_lists_6_3(arg1606_507, list1608_509);
					}
				     }
				     return PROCEDURE_ENTRY(e_18) (e_18, arg1605_506, e_18, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_485 = CAR(cdr_657_74_490);
			  y_486 = CDR(cdr_657_74_490);
			tag_650_127_487:
			  {
			     obj_t arg1615_514;
			     {
				obj_t arg1617_515;
				obj_t arg1618_516;
				obj_t arg1620_517;
				arg1617_515 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1627_523;
				   obj_t arg1628_524;
				   arg1627_523 = CNST_TABLE_REF(((long) 16));
				   arg1628_524 = CAR(y_486);
				   {
				      obj_t list1631_526;
				      {
					 obj_t arg1632_527;
					 {
					    obj_t arg1633_528;
					    arg1633_528 = MAKE_PAIR(BNIL, BNIL);
					    arg1632_527 = MAKE_PAIR(arg1628_524, arg1633_528);
					 }
					 list1631_526 = MAKE_PAIR(x_485, arg1632_527);
				      }
				      arg1618_516 = cons__138___r4_pairs_and_lists_6_3(arg1627_523, list1631_526);
				   }
				}
				{
				   obj_t arg1636_530;
				   obj_t arg1638_531;
				   arg1636_530 = CNST_TABLE_REF(((long) 17));
				   {
				      obj_t arg1641_534;
				      arg1641_534 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1638_531 = append_2_18___r4_pairs_and_lists_6_3(y_486, arg1641_534);
				   }
				   {
				      obj_t list1639_532;
				      list1639_532 = MAKE_PAIR(arg1638_531, BNIL);
				      arg1620_517 = cons__138___r4_pairs_and_lists_6_3(arg1636_530, list1639_532);
				   }
				}
				{
				   obj_t list1622_519;
				   {
				      obj_t arg1623_520;
				      {
					 obj_t arg1624_521;
					 arg1624_521 = MAKE_PAIR(BNIL, BNIL);
					 arg1623_520 = MAKE_PAIR(arg1620_517, arg1624_521);
				      }
				      list1622_519 = MAKE_PAIR(arg1618_516, arg1623_520);
				   }
				   arg1615_514 = cons__138___r4_pairs_and_lists_6_3(arg1617_515, list1622_519);
				}
			     }
			     return PROCEDURE_ENTRY(e_18) (e_18, arg1615_514, e_18, BEOA);
			  }
		       }
		  }
		else
		  {
		     obj_t y_1439;
		     obj_t x_1437;
		     x_1437 = CAR(cdr_657_74_490);
		     y_1439 = CDR(cdr_657_74_490);
		     y_486 = y_1439;
		     x_485 = x_1437;
		     goto tag_650_127_487;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-i>=1695 */ obj_t 
_expand_i__1695_8_expand_iarithmetique(obj_t env_860, obj_t x_861, obj_t e_862)
{
   return expand_i___111_expand_iarithmetique(x_861, e_862);
}


/* expand-+fx */ obj_t 
expand__fx_224_expand_iarithmetique(obj_t x_19, obj_t e_20)
{
   {
      obj_t x_537;
      obj_t y_538;
      if (PAIRP(x_19))
	{
	   obj_t cdr_713_137_543;
	   cdr_713_137_543 = CDR(x_19);
	   if (PAIRP(cdr_713_137_543))
	     {
		obj_t cdr_717_232_545;
		cdr_717_232_545 = CDR(cdr_713_137_543);
		if (PAIRP(cdr_717_232_545))
		  {
		     bool_t test_1450;
		     {
			obj_t aux_1451;
			aux_1451 = CDR(cdr_717_232_545);
			test_1450 = (aux_1451 == BNIL);
		     }
		     if (test_1450)
		       {
			  x_537 = CAR(cdr_713_137_543);
			  y_538 = CAR(cdr_717_232_545);
			  {
			     bool_t test_1454;
			     if (INTEGERP(x_537))
			       {
				  test_1454 = INTEGERP(y_538);
			       }
			     else
			       {
				  test_1454 = ((bool_t) 0);
			       }
			     if (test_1454)
			       {
				  {
				     long aux_1458;
				     {
					long aux_1461;
					long aux_1459;
					aux_1461 = (long) CINT(y_538);
					aux_1459 = (long) CINT(x_537);
					aux_1458 = (aux_1459 + aux_1461);
				     }
				     return BINT(aux_1458);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1657_553;
				     obj_t arg1658_554;
				     obj_t arg1659_555;
				     arg1657_553 = CNST_TABLE_REF(((long) 0));
				     arg1658_554 = PROCEDURE_ENTRY(e_20) (e_20, x_537, e_20, BEOA);
				     arg1659_555 = PROCEDURE_ENTRY(e_20) (e_20, y_538, e_20, BEOA);
				     {
					obj_t list1662_557;
					{
					   obj_t arg1663_558;
					   {
					      obj_t arg1665_559;
					      arg1665_559 = MAKE_PAIR(BNIL, BNIL);
					      arg1663_558 = MAKE_PAIR(arg1659_555, arg1665_559);
					   }
					   list1662_557 = MAKE_PAIR(arg1658_554, arg1663_558);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1657_553, list1662_557);
				     }
				  }
			       }
			  }
		       }
		     else
		       {
			tag_706_191_540:
			  FAILURE(BFALSE, string1698_expand_iarithmetique, x_19);
		       }
		  }
		else
		  {
		     goto tag_706_191_540;
		  }
	     }
	   else
	     {
		goto tag_706_191_540;
	     }
	}
      else
	{
	   goto tag_706_191_540;
	}
   }
}


/* _expand-+fx1696 */ obj_t 
_expand__fx1696_15_expand_iarithmetique(obj_t env_863, obj_t x_864, obj_t e_865)
{
   return expand__fx_224_expand_iarithmetique(x_864, e_865);
}


/* expand--fx */ obj_t 
expand__fx_28_expand_iarithmetique(obj_t x_21, obj_t e_22)
{
   {
      obj_t x_562;
      obj_t y_563;
      if (PAIRP(x_21))
	{
	   obj_t cdr_731_195_568;
	   cdr_731_195_568 = CDR(x_21);
	   if (PAIRP(cdr_731_195_568))
	     {
		obj_t cdr_735_80_570;
		cdr_735_80_570 = CDR(cdr_731_195_568);
		if (PAIRP(cdr_735_80_570))
		  {
		     bool_t test_1486;
		     {
			obj_t aux_1487;
			aux_1487 = CDR(cdr_735_80_570);
			test_1486 = (aux_1487 == BNIL);
		     }
		     if (test_1486)
		       {
			  x_562 = CAR(cdr_731_195_568);
			  y_563 = CAR(cdr_735_80_570);
			  {
			     bool_t test_1490;
			     if (INTEGERP(x_562))
			       {
				  test_1490 = INTEGERP(y_563);
			       }
			     else
			       {
				  test_1490 = ((bool_t) 0);
			       }
			     if (test_1490)
			       {
				  {
				     long aux_1494;
				     {
					long aux_1497;
					long aux_1495;
					aux_1497 = (long) CINT(y_563);
					aux_1495 = (long) CINT(x_562);
					aux_1494 = (aux_1495 - aux_1497);
				     }
				     return BINT(aux_1494);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1678_578;
				     obj_t arg1679_579;
				     obj_t arg1680_580;
				     arg1678_578 = CNST_TABLE_REF(((long) 3));
				     arg1679_579 = PROCEDURE_ENTRY(e_22) (e_22, x_562, e_22, BEOA);
				     arg1680_580 = PROCEDURE_ENTRY(e_22) (e_22, y_563, e_22, BEOA);
				     {
					obj_t list1682_582;
					{
					   obj_t arg1683_583;
					   {
					      obj_t arg1684_584;
					      arg1684_584 = MAKE_PAIR(BNIL, BNIL);
					      arg1683_583 = MAKE_PAIR(arg1680_580, arg1684_584);
					   }
					   list1682_582 = MAKE_PAIR(arg1679_579, arg1683_583);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1678_578, list1682_582);
				     }
				  }
			       }
			  }
		       }
		     else
		       {
			tag_724_144_565:
			  FAILURE(BFALSE, string1699_expand_iarithmetique, x_21);
		       }
		  }
		else
		  {
		     goto tag_724_144_565;
		  }
	     }
	   else
	     {
		goto tag_724_144_565;
	     }
	}
      else
	{
	   goto tag_724_144_565;
	}
   }
}


/* _expand--fx1697 */ obj_t 
_expand__fx1697_218_expand_iarithmetique(obj_t env_866, obj_t x_867, obj_t e_868)
{
   return expand__fx_28_expand_iarithmetique(x_867, e_868);
}
