/*===========================================================================*/
/*   (Module/load.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t ccomp_module_module;
static obj_t method_init_76_module_load();
extern obj_t _access_table__91_engine_param;
static obj_t load_parser_100_module_load(obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_module_load(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_read_load(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t load_module_134_read_load(obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _make_load_compiler_34_module_load(obj_t);
static obj_t imported_modules_init_94_module_load();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t library_modules_init_112_module_load();
static obj_t _load_producer_194_module_load(obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t arg1197_module_load(obj_t, obj_t, obj_t);
static obj_t arg1196_module_load(obj_t);
static obj_t arg1195_module_load(obj_t, obj_t, obj_t);
extern obj_t make_load_compiler_92_module_load();
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_module_load = BUNSPEC;
static obj_t cnst_init_137_module_load();
static obj_t load_producer_246_module_load(obj_t);
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(load_producer_env_50_module_load, _load_producer_194_module_load1298, _load_producer_194_module_load, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_load_compiler_env_29_module_load, _make_load_compiler_34_module_load1299, _make_load_compiler_34_module_load, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1285_module_load, arg1195_module_load1300, arg1195_module_load, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1284_module_load, arg1196_module_load1301, arg1196_module_load, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1283_module_load, arg1197_module_load1302, arg1197_module_load, 0L, 2);
DEFINE_STRING(string1291_module_load, string1291_module_load1303, "VOID LOAD ", 10);
DEFINE_STRING(string1289_module_load, string1289_module_load1304, "load", 4);
DEFINE_STRING(string1290_module_load, string1290_module_load1305, "Can't load module", 17);
DEFINE_STRING(string1288_module_load, string1288_module_load1306, "Illegal load clause", 19);
DEFINE_STRING(string1287_module_load, string1287_module_load1307, "Parse error", 11);
DEFINE_STRING(string1286_module_load, string1286_module_load1308, "Illegal `load' clause", 21);


/* module-initialization */ obj_t 
module_initialization_70_module_load(long checksum_590, char *from_591)
{
   if (CBOOL(require_initialization_114_module_load))
     {
	require_initialization_114_module_load = BBOOL(((bool_t) 0));
	library_modules_init_112_module_load();
	cnst_init_137_module_load();
	imported_modules_init_94_module_load();
	method_init_76_module_load();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_load()
{
   module_initialization_70___object(((long) 0), "MODULE_LOAD");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_LOAD");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_LOAD");
   module_initialization_70___reader(((long) 0), "MODULE_LOAD");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_load()
{
   {
      obj_t cnst_port_138_582;
      cnst_port_138_582 = open_input_string(string1291_module_load);
      {
	 long i_583;
	 i_583 = ((long) 1);
       loop_584:
	 {
	    bool_t test1292_585;
	    test1292_585 = (i_583 == ((long) -1));
	    if (test1292_585)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1294_586;
		    {
		       obj_t list1295_587;
		       {
			  obj_t arg1296_588;
			  arg1296_588 = BNIL;
			  list1295_587 = MAKE_PAIR(cnst_port_138_582, arg1296_588);
		       }
		       arg1294_586 = read___reader(list1295_587);
		    }
		    CNST_TABLE_SET(i_583, arg1294_586);
		 }
		 {
		    int aux_589;
		    {
		       long aux_609;
		       aux_609 = (i_583 - ((long) 1));
		       aux_589 = (int) (aux_609);
		    }
		    {
		       long i_612;
		       i_612 = (long) (aux_589);
		       i_583 = i_612;
		       goto loop_584;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-load-compiler */ obj_t 
make_load_compiler_92_module_load()
{
   {
      obj_t arg1193_315;
      arg1193_315 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1197_569;
	 obj_t arg1196_570;
	 obj_t arg1195_571;
	 arg1197_569 = proc1283_module_load;
	 arg1196_570 = proc1284_module_load;
	 arg1195_571 = proc1285_module_load;
	 {
	    ccomp_t res1282_535;
	    {
	       ccomp_t new1002_526;
	       new1002_526 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1281_527;
		  arg1281_527 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_533;
		     obj_533 = (obj_t) (new1002_526);
		     (((obj_t) CREF(obj_533))->header = MAKE_HEADER(arg1281_527, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_619;
		  aux_619 = (object_t) (new1002_526);
		  OBJECT_WIDENING_SET(aux_619, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_526))->id) = ((obj_t) arg1193_315), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_526))->producer) = ((obj_t) load_producer_env_50_module_load), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_526))->consumer) = ((obj_t) arg1195_571), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_526))->finalizer) = ((obj_t) arg1196_570), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_526))->checksummer) = ((obj_t) arg1197_569), BUNSPEC);
	       res1282_535 = new1002_526;
	    }
	    return (obj_t) (res1282_535);
	 }
      }
   }
}


/* _make-load-compiler */ obj_t 
_make_load_compiler_34_module_load(obj_t env_572)
{
   return make_load_compiler_92_module_load();
}


/* arg1197 */ obj_t 
arg1197_module_load(obj_t env_573, obj_t m_574, obj_t c_575)
{
   {
      obj_t m_324;
      obj_t c_325;
      m_324 = m_574;
      c_325 = c_575;
      return c_325;
   }
}


/* arg1196 */ obj_t 
arg1196_module_load(obj_t env_576)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1195 */ obj_t 
arg1195_module_load(obj_t env_577, obj_t m_578, obj_t c_579)
{
   {
      obj_t m_320;
      obj_t c_321;
      m_320 = m_578;
      c_321 = c_579;
      return BNIL;
   }
}


/* load-producer */ obj_t 
load_producer_246_module_load(obj_t clause_1)
{
   {
      obj_t protos_330;
      if (PAIRP(clause_1))
	{
	   bool_t aux_632;
	   protos_330 = CDR(clause_1);
	   {
	      obj_t l1191_336;
	      l1191_336 = protos_330;
	    lname1192_337:
	      if (PAIRP(l1191_336))
		{
		   load_parser_100_module_load(CAR(l1191_336), clause_1);
		   {
		      obj_t l1191_637;
		      l1191_637 = CDR(l1191_336);
		      l1191_336 = l1191_637;
		      goto lname1192_337;
		   }
		}
	      else
		{
		   aux_632 = ((bool_t) 1);
		}
	   }
	   return BBOOL(aux_632);
	}
      else
	{
	   {
	      obj_t arg1206_342;
	      {
		 obj_t list1210_346;
		 list1210_346 = MAKE_PAIR(string1286_module_load, BNIL);
		 arg1206_342 = string_append_106___r4_strings_6_7(list1210_346);
	      }
	      {
		 obj_t list1208_344;
		 list1208_344 = MAKE_PAIR(BNIL, BNIL);
		 return user_error_151_tools_error(string1287_module_load, arg1206_342, clause_1, list1208_344);
	      }
	   }
	}
   }
}


/* _load-producer */ obj_t 
_load_producer_194_module_load(obj_t env_580, obj_t clause_581)
{
   return load_producer_246_module_load(clause_581);
}


/* load-parser */ obj_t 
load_parser_100_module_load(obj_t proto_2, obj_t clause_3)
{
   {
      obj_t module_349;
      obj_t file_350;
      obj_t files_351;
      if (PAIRP(proto_2))
	{
	   obj_t car_119_235_357;
	   obj_t cdr_120_34_358;
	   car_119_235_357 = CAR(proto_2);
	   cdr_120_34_358 = CDR(proto_2);
	   if (SYMBOLP(car_119_235_357))
	     {
		if (PAIRP(cdr_120_34_358))
		  {
		     obj_t car_125_199_361;
		     car_125_199_361 = CAR(cdr_120_34_358);
		     if (STRINGP(car_125_199_361))
		       {
			  module_349 = car_119_235_357;
			  file_350 = car_125_199_361;
			  files_351 = CDR(cdr_120_34_358);
			  {
			     obj_t f_368;
			     f_368 = files_351;
			   loop_369:
			     if (NULLP(f_368))
			       {
				  {
				     obj_t arg1225_371;
				     arg1225_371 = MAKE_PAIR(file_350, files_351);
				     return load_module_134_read_load(module_349, arg1225_371);
				  }
			       }
			     else
			       {
				  bool_t test_661;
				  {
				     obj_t aux_662;
				     aux_662 = CAR(f_368);
				     test_661 = STRINGP(aux_662);
				  }
				  if (test_661)
				    {
				       {
					  obj_t f_665;
					  f_665 = CDR(f_368);
					  f_368 = f_665;
					  goto loop_369;
				       }
				    }
				  else
				    {
				       {
					  obj_t list1234_377;
					  list1234_377 = MAKE_PAIR(BNIL, BNIL);
					  return user_error_151_tools_error(string1287_module_load, string1288_module_load, clause_3, list1234_377);
				       }
				    }
			       }
			  }
		       }
		     else
		       {
			  if (SYMBOLP(proto_2))
			    {
			     tag_110_179_353:
			       {
				  obj_t b_380;
				  b_380 = assq___r4_pairs_and_lists_6_3(proto_2, _access_table__91_engine_param);
				  if (CBOOL(b_380))
				    {
				       return load_module_134_read_load(proto_2, CDR(b_380));
				    }
				  else
				    {
				       return user_error_151_tools_error(string1289_module_load, string1290_module_load, proto_2, BNIL);
				    }
			       }
			    }
			  else
			    {
			     tag_111_62_354:
			       {
				  obj_t list1244_386;
				  list1244_386 = MAKE_PAIR(BNIL, BNIL);
				  return user_error_151_tools_error(string1287_module_load, string1288_module_load, clause_3, list1244_386);
			       }
			    }
		       }
		  }
		else
		  {
		     if (SYMBOLP(proto_2))
		       {
			  goto tag_110_179_353;
		       }
		     else
		       {
			  goto tag_111_62_354;
		       }
		  }
	     }
	   else
	     {
		if (SYMBOLP(proto_2))
		  {
		     goto tag_110_179_353;
		  }
		else
		  {
		     goto tag_111_62_354;
		  }
	     }
	}
      else
	{
	   if (SYMBOLP(proto_2))
	     {
		goto tag_110_179_353;
	     }
	   else
	     {
		goto tag_111_62_354;
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_module_load()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_load()
{
   module_initialization_70_module_module(((long) 0), "MODULE_LOAD");
   module_initialization_70_engine_param(((long) 0), "MODULE_LOAD");
   module_initialization_70_tools_error(((long) 0), "MODULE_LOAD");
   module_initialization_70_type_type(((long) 0), "MODULE_LOAD");
   module_initialization_70_ast_var(((long) 0), "MODULE_LOAD");
   module_initialization_70_ast_env(((long) 0), "MODULE_LOAD");
   module_initialization_70_type_env(((long) 0), "MODULE_LOAD");
   module_initialization_70_tools_speek(((long) 0), "MODULE_LOAD");
   return module_initialization_70_read_load(((long) 0), "MODULE_LOAD");
}
