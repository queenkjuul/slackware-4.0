/*===========================================================================*/
/*   (Expand/eps.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t escape_1381_expand_eps(obj_t, obj_t);
static obj_t escape_1380_expand_eps(obj_t, obj_t);
static obj_t method_init_76_expand_eps();
static obj_t body1061_expand_eps(obj_t);
static obj_t body1053_expand_eps(obj_t);
static obj_t body1045_expand_eps(obj_t);
extern obj_t current_error_port;
extern obj_t exitd_top;
extern obj_t _nb_error_on_pass__70_tools_error;
static obj_t _add_macro_definition__254_expand_eps(obj_t, obj_t);
static obj_t _lexical_stack_103_expand_eps(obj_t);
extern obj_t get_compiler_expander_150___macro(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t fast_id_of_id_130_ast_ident(obj_t);
static obj_t handling_function1295_expand_eps(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1283_expand_eps(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1272_expand_eps(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t get_eval_expander_232___macro(obj_t);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_expand_expander(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___macro(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _identifier_expander__166_expand_eps(obj_t, obj_t);
static obj_t __application_expander__200_expand_eps(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_expand_eps();
extern obj_t expand_units_9_expand_eps(obj_t);
extern obj_t add_macro_definition__103_expand_eps(obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t handler_expand_eps(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _with_lexical1378_84_expand_eps(obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1060_expand_eps(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1052_expand_eps(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1044_expand_eps(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_eps();
static obj_t initial_expander_162_expand_eps(obj_t, obj_t);
static obj_t _comptime_expand_once_1_expand_eps(obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_expand_eps();
extern obj_t open_input_string(obj_t);
extern obj_t lexical_stack_189_expand_eps();
extern obj_t with_lexical_22_expand_eps(obj_t, obj_t, obj_t);
extern obj_t comptime_expand_37_expand_eps(obj_t);
static obj_t lambda1364_expand_eps(obj_t, obj_t, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t loop_expand_eps(obj_t, obj_t, obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t _expand_units_69_expand_eps(obj_t, obj_t);
static obj_t _macro__213_expand_eps = BUNSPEC;
static obj_t arg1343_expand_eps(obj_t, obj_t, obj_t);
static obj_t arg1297_expand_eps(obj_t);
static obj_t arg1296_expand_eps(obj_t);
static obj_t arg1285_expand_eps(obj_t);
static obj_t arg1284_expand_eps(obj_t);
static obj_t arg1274_expand_eps(obj_t);
static obj_t arg1273_expand_eps(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _initial_expander1379_84_expand_eps(obj_t, obj_t, obj_t);
extern obj_t comptime_expand_once_113_expand_eps(obj_t);
extern obj_t remove_error_handler__102___error();
static obj_t _lexical_stack__25_expand_eps = BUNSPEC;
static obj_t _comptime_expand_212_expand_eps(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _application_expander__202_expand_eps(obj_t, obj_t);
static obj_t escape_expand_eps(obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_expand_eps = BUNSPEC;
static obj_t __identifier_expander__134_expand_eps(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_expand_eps();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _current_pass__25_engine_pass;
extern obj_t find_o_expander_0_expand_expander(obj_t);
static obj_t __cnst[5];

DEFINE_STATIC_PROCEDURE(_identifier_expander__env_242_expand_eps, __identifier_expander__134_expand_eps1399, __identifier_expander__134_expand_eps, 0L, 2);
DEFINE_EXPORT_PROCEDURE(comptime_expand_once_env_39_expand_eps, _comptime_expand_once_1_expand_eps1400, _comptime_expand_once_1_expand_eps, 0L, 1);
DEFINE_STATIC_PROCEDURE(initial_expander_env_197_expand_eps, _initial_expander1379_84_expand_eps1401, _initial_expander1379_84_expand_eps, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1391_expand_eps, lambda1364_expand_eps1402, lambda1364_expand_eps, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1389_expand_eps, arg1343_expand_eps1403, arg1343_expand_eps, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1382_expand_eps, handler_expand_eps1404, handler_expand_eps, 0L, 4);
DEFINE_EXPORT_PROCEDURE(expand_units_env_107_expand_eps, _expand_units_69_expand_eps1405, _expand_units_69_expand_eps, 0L, 1);
DEFINE_EXPORT_PROCEDURE(add_macro_definition__env_21_expand_eps, _add_macro_definition__254_expand_eps1406, _add_macro_definition__254_expand_eps, 0L, 1);
DEFINE_STATIC_PROCEDURE(_application_expander__env_69_expand_eps, __application_expander__200_expand_eps1407, __application_expander__200_expand_eps, 0L, 2);
DEFINE_EXPORT_PROCEDURE(comptime_expand_env_121_expand_eps, _comptime_expand_212_expand_eps1408, _comptime_expand_212_expand_eps, 0L, 1);
DEFINE_EXPORT_PROCEDURE(lexical_stack_env_214_expand_eps, _lexical_stack_103_expand_eps1409, _lexical_stack_103_expand_eps, 0L, 0);
DEFINE_STRING(string1392_expand_eps, string1392_expand_eps1410, "(QUOTE ()) DEFINE-EXPANDER DEFINE-MACRO NOTHING PASS-STARTED ", 61);
DEFINE_STRING(string1390_expand_eps, string1390_expand_eps1411, "Illegal form", 12);
DEFINE_STRING(string1388_expand_eps, string1388_expand_eps1412, "failure during postlude hook", 28);
DEFINE_STRING(string1387_expand_eps, string1387_expand_eps1413, " error", 6);
DEFINE_STRING(string1386_expand_eps, string1386_expand_eps1414, " occured, ending ...", 20);
DEFINE_STRING(string1385_expand_eps, string1385_expand_eps1415, "failure during prelude hook", 27);
DEFINE_STRING(string1384_expand_eps, string1384_expand_eps1416, "   . ", 5);
DEFINE_STRING(string1383_expand_eps, string1383_expand_eps1417, "Expand", 6);
DEFINE_EXPORT_PROCEDURE(with_lexical_env_98_expand_eps, _with_lexical1378_84_expand_eps1418, _with_lexical1378_84_expand_eps, 0L, 3);


/* module-initialization */ obj_t 
module_initialization_70_expand_eps(long checksum_662, char *from_663)
{
   if (CBOOL(require_initialization_114_expand_eps))
     {
	require_initialization_114_expand_eps = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_eps();
	cnst_init_137_expand_eps();
	imported_modules_init_94_expand_eps();
	method_init_76_expand_eps();
	toplevel_init_63_expand_eps();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_eps()
{
   module_initialization_70___bexit(((long) 0), "EXPAND_EPS");
   module_initialization_70___macro(((long) 0), "EXPAND_EPS");
   module_initialization_70___r4_output_6_10_3(((long) 0), "EXPAND_EPS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_EPS");
   module_initialization_70___r4_control_features_6_9(((long) 0), "EXPAND_EPS");
   module_initialization_70___error(((long) 0), "EXPAND_EPS");
   module_initialization_70___r4_numbers_6_5(((long) 0), "EXPAND_EPS");
   module_initialization_70___reader(((long) 0), "EXPAND_EPS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_eps()
{
   {
      obj_t cnst_port_138_654;
      cnst_port_138_654 = open_input_string(string1392_expand_eps);
      {
	 long i_655;
	 i_655 = ((long) 4);
       loop_656:
	 {
	    bool_t test1393_657;
	    test1393_657 = (i_655 == ((long) -1));
	    if (test1393_657)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1395_658;
		    {
		       obj_t list1396_659;
		       {
			  obj_t arg1397_660;
			  arg1397_660 = BNIL;
			  list1396_659 = MAKE_PAIR(cnst_port_138_654, arg1397_660);
		       }
		       arg1395_658 = read___reader(list1396_659);
		    }
		    CNST_TABLE_SET(i_655, arg1395_658);
		 }
		 {
		    int aux_661;
		    {
		       long aux_686;
		       aux_686 = (i_655 - ((long) 1));
		       aux_661 = (int) (aux_686);
		    }
		    {
		       long i_689;
		       i_689 = (long) (aux_661);
		       i_655 = i_689;
		       goto loop_656;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_eps()
{
   _macro__213_expand_eps = BNIL;
   return (_lexical_stack__25_expand_eps = BNIL,
      BUNSPEC);
}


/* add-macro-definition! */ obj_t 
add_macro_definition__103_expand_eps(obj_t form_29)
{
   {
      obj_t obj2_399;
      obj2_399 = _macro__213_expand_eps;
      return (_macro__213_expand_eps = MAKE_PAIR(form_29, obj2_399),
	 BUNSPEC);
   }
}


/* _add-macro-definition! */ obj_t 
_add_macro_definition__254_expand_eps(obj_t env_513, obj_t form_514)
{
   return add_macro_definition__103_expand_eps(form_514);
}


/* lexical-stack */ obj_t 
lexical_stack_189_expand_eps()
{
   return _lexical_stack__25_expand_eps;
}


/* _lexical-stack */ obj_t 
_lexical_stack_103_expand_eps(obj_t env_515)
{
   return lexical_stack_189_expand_eps();
}


/* with-lexical */ obj_t 
with_lexical_22_expand_eps(obj_t new_30, obj_t mark_31, obj_t thunk_32)
{
   {
      obj_t new_id_27_123;
      obj_t old_lexical_stack_210_124;
      if (NULLP(new_30))
	{
	   new_id_27_123 = BNIL;
	}
      else
	{
	   obj_t head1030_143;
	   {
	      obj_t arg1226_154;
	      arg1226_154 = fast_id_of_id_130_ast_ident(CAR(new_30));
	      head1030_143 = MAKE_PAIR(arg1226_154, BNIL);
	   }
	   {
	      obj_t l1028_144;
	      obj_t tail1031_145;
	      l1028_144 = CDR(new_30);
	      tail1031_145 = head1030_143;
	    lname1029_146:
	      if (NULLP(l1028_144))
		{
		   new_id_27_123 = head1030_143;
		}
	      else
		{
		   obj_t newtail1032_149;
		   {
		      obj_t arg1222_151;
		      arg1222_151 = fast_id_of_id_130_ast_ident(CAR(l1028_144));
		      newtail1032_149 = MAKE_PAIR(arg1222_151, BNIL);
		   }
		   SET_CDR(tail1031_145, newtail1032_149);
		   {
		      obj_t tail1031_707;
		      obj_t l1028_705;
		      l1028_705 = CDR(l1028_144);
		      tail1031_707 = newtail1032_149;
		      tail1031_145 = tail1031_707;
		      l1028_144 = l1028_705;
		      goto lname1029_146;
		   }
		}
	   }
	}
      old_lexical_stack_210_124 = _lexical_stack__25_expand_eps;
      {
	 obj_t arg1207_125;
	 if (NULLP(new_id_27_123))
	   {
	      arg1207_125 = BNIL;
	   }
	 else
	   {
	      obj_t head1035_128;
	      head1035_128 = MAKE_PAIR(BNIL, BNIL);
	      {
		 obj_t l1033_129;
		 obj_t tail1036_130;
		 l1033_129 = new_id_27_123;
		 tail1036_130 = head1035_128;
	       lname1034_131:
		 if (NULLP(l1033_129))
		   {
		      arg1207_125 = CDR(head1035_128);
		   }
		 else
		   {
		      obj_t newtail1037_133;
		      {
			 obj_t arg1211_135;
			 {
			    obj_t aux_715;
			    aux_715 = CAR(l1033_129);
			    arg1211_135 = MAKE_PAIR(aux_715, mark_31);
			 }
			 newtail1037_133 = MAKE_PAIR(arg1211_135, BNIL);
		      }
		      SET_CDR(tail1036_130, newtail1037_133);
		      {
			 obj_t tail1036_722;
			 obj_t l1033_720;
			 l1033_720 = CDR(l1033_129);
			 tail1036_722 = newtail1037_133;
			 tail1036_130 = tail1036_722;
			 l1033_129 = l1033_720;
			 goto lname1034_131;
		      }
		   }
	      }
	   }
	 _lexical_stack__25_expand_eps = append_2_18___r4_pairs_and_lists_6_3(arg1207_125, _lexical_stack__25_expand_eps);
      }
      {
	 obj_t res_140;
	 res_140 = PROCEDURE_ENTRY(thunk_32) (thunk_32, BEOA);
	 _lexical_stack__25_expand_eps = old_lexical_stack_210_124;
	 return res_140;
      }
   }
}


/* _with-lexical1378 */ obj_t 
_with_lexical1378_84_expand_eps(obj_t env_516, obj_t new_517, obj_t mark_518, obj_t thunk_519)
{
   return with_lexical_22_expand_eps(new_517, mark_518, thunk_519);
}


/* expand-units */ obj_t 
expand_units_9_expand_eps(obj_t units_33)
{
   {
      obj_t handler_538;
      handler_538 = proc1382_expand_eps;
      {
	 obj_t list1232_158;
	 {
	    obj_t arg1234_160;
	    {
	       obj_t arg1236_162;
	       {
		  obj_t aux_727;
		  aux_727 = BCHAR(((unsigned char) '\n'));
		  arg1236_162 = MAKE_PAIR(aux_727, BNIL);
	       }
	       arg1234_160 = MAKE_PAIR(string1383_expand_eps, arg1236_162);
	    }
	    list1232_158 = MAKE_PAIR(string1384_expand_eps, arg1234_160);
	 }
	 verbose_tools_speek(BINT(((long) 1)), list1232_158);
      }
      _nb_error_on_pass__70_tools_error = BINT(((long) 0));
      _current_pass__25_engine_pass = string1383_expand_eps;
      {
	 obj_t hooks_164;
	 obj_t hnames_165;
	 hooks_164 = BNIL;
	 hnames_165 = BNIL;
       loop_166:
	 if (NULLP(hooks_164))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1244_171;
	      {
		 obj_t fun1252_177;
		 fun1252_177 = CAR(hooks_164);
		 {
		    obj_t aux_739;
		    aux_739 = PROCEDURE_ENTRY(fun1252_177) (fun1252_177, BEOA);
		    test1244_171 = CBOOL(aux_739);
		 }
	      }
	      if (test1244_171)
		{
		   {
		      obj_t hnames_746;
		      obj_t hooks_744;
		      hooks_744 = CDR(hooks_164);
		      hnames_746 = CDR(hnames_165);
		      hnames_165 = hnames_746;
		      hooks_164 = hooks_744;
		      goto loop_166;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1383_expand_eps, string1385_expand_eps, CAR(hnames_165));
		}
	   }
      }
      {
	 obj_t l1038_178;
	 {
	    obj_t arg1253_180;
	    arg1253_180 = reverse__39___r4_pairs_and_lists_6_3(_macro__213_expand_eps);
	    l1038_178 = arg1253_180;
	  lname1039_179:
	    if (PAIRP(l1038_178))
	      {
		 initial_expander_162_expand_eps(CAR(l1038_178), initial_expander_env_197_expand_eps);
		 {
		    obj_t l1038_755;
		    l1038_755 = CDR(l1038_178);
		    l1038_178 = l1038_755;
		    goto lname1039_179;
		 }
	      }
	    else
	      {
		 ((bool_t) 1);
	      }
	 }
      }
      {
	 obj_t l1040_184;
	 l1040_184 = units_33;
       lname1041_185:
	 if (PAIRP(l1040_184))
	   {
	      {
		 obj_t unit_187;
		 unit_187 = CAR(l1040_184);
		 {
		    bool_t test_760;
		    {
		       obj_t aux_761;
		       aux_761 = STRUCT_REF(unit_187, ((long) 2));
		       test_760 = PROCEDUREP(aux_761);
		    }
		    if (test_760)
		      {
			 CNST_TABLE_REF(((long) 1));
		      }
		    else
		      {
			 obj_t src_189;
			 obj_t res_190;
			 src_189 = STRUCT_REF(unit_187, ((long) 2));
			 res_190 = BNIL;
		       loop_191:
			 if (NULLP(src_189))
			   {
			      obj_t arg1262_195;
			      arg1262_195 = reverse__39___r4_pairs_and_lists_6_3(res_190);
			      {
				 obj_t x_652;
				 x_652 = STRUCT_SET(unit_187, ((long) 2), arg1262_195);
				 BUNSPEC;
			      }
			   }
			 else
			   {
			      {
				 obj_t e_123_126_199;
				 e_123_126_199 = CAR(src_189);
				 if (PAIRP(e_123_126_199))
				   {
				      bool_t test_772;
				      {
					 obj_t aux_775;
					 obj_t aux_773;
					 aux_775 = CNST_TABLE_REF(((long) 2));
					 aux_773 = CAR(e_123_126_199);
					 test_772 = (aux_773 == aux_775);
				      }
				      if (test_772)
					{
					   {
					      obj_t armed1046_207;
					      obj_t handler1043_208;
					      armed1046_207 = MAKE_CELL(BUNSPEC);
					      handler1043_208 = MAKE_CELL(BUNSPEC);
					      {
						 obj_t body1045_534;
						 obj_t rhandler1044_536;
						 body1045_534 = make_fx_procedure(body1045_expand_eps, ((long) 0), ((long) 1));
						 rhandler1044_536 = make_fx_procedure(rhandler1044_expand_eps, ((long) 4), ((long) 2));
						 PROCEDURE_SET(body1045_534, ((long) 0), src_189);
						 PROCEDURE_SET(rhandler1044_536, ((long) 0), armed1046_207);
						 PROCEDURE_SET(rhandler1044_536, ((long) 1), handler1043_208);
						 CELL_SET(handler1043_208, handler_538);
						 CELL_SET(armed1046_207, BTRUE);
						 handling_function1272_expand_eps(body1045_534, rhandler1044_536, handler1043_208, armed1046_207);
					      }
					   }
					   {
					      obj_t src_784;
					      src_784 = CDR(src_189);
					      src_189 = src_784;
					      goto loop_191;
					   }
					}
				      else
					{
					   bool_t test_786;
					   {
					      obj_t aux_789;
					      obj_t aux_787;
					      aux_789 = CNST_TABLE_REF(((long) 3));
					      aux_787 = CAR(e_123_126_199);
					      test_786 = (aux_787 == aux_789);
					   }
					   if (test_786)
					     {
						{
						   obj_t armed1054_233;
						   obj_t handler1051_234;
						   armed1054_233 = MAKE_CELL(BUNSPEC);
						   handler1051_234 = MAKE_CELL(BUNSPEC);
						   {
						      obj_t body1053_529;
						      obj_t rhandler1052_531;
						      body1053_529 = make_fx_procedure(body1053_expand_eps, ((long) 0), ((long) 1));
						      rhandler1052_531 = make_fx_procedure(rhandler1052_expand_eps, ((long) 4), ((long) 2));
						      PROCEDURE_SET(body1053_529, ((long) 0), src_189);
						      PROCEDURE_SET(rhandler1052_531, ((long) 0), armed1054_233);
						      PROCEDURE_SET(rhandler1052_531, ((long) 1), handler1051_234);
						      CELL_SET(handler1051_234, handler_538);
						      CELL_SET(armed1054_233, BTRUE);
						      handling_function1283_expand_eps(body1053_529, rhandler1052_531, handler1051_234, armed1054_233);
						   }
						}
						{
						   obj_t src_798;
						   src_798 = CDR(src_189);
						   src_189 = src_798;
						   goto loop_191;
						}
					     }
					   else
					     {
					      tag_122_225_198:
						{
						   obj_t new_body_215_259;
						   {
						      obj_t armed1062_262;
						      obj_t handler1059_263;
						      armed1062_262 = MAKE_CELL(BUNSPEC);
						      handler1059_263 = MAKE_CELL(BUNSPEC);
						      {
							 obj_t body1061_521;
							 obj_t rhandler1060_526;
							 body1061_521 = make_fx_procedure(body1061_expand_eps, ((long) 0), ((long) 1));
							 rhandler1060_526 = make_fx_procedure(rhandler1060_expand_eps, ((long) 4), ((long) 2));
							 PROCEDURE_SET(body1061_521, ((long) 0), src_189);
							 PROCEDURE_SET(rhandler1060_526, ((long) 0), armed1062_262);
							 PROCEDURE_SET(rhandler1060_526, ((long) 1), handler1059_263);
							 CELL_SET(handler1059_263, handler_538);
							 CELL_SET(armed1062_262, BTRUE);
							 new_body_215_259 = handling_function1295_expand_eps(body1061_521, rhandler1060_526, handler1059_263, armed1062_262);
						      }
						   }
						   {
						      obj_t arg1292_260;
						      obj_t arg1294_261;
						      arg1292_260 = CDR(src_189);
						      arg1294_261 = MAKE_PAIR(new_body_215_259, res_190);
						      {
							 obj_t res_809;
							 obj_t src_808;
							 src_808 = arg1292_260;
							 res_809 = arg1294_261;
							 res_190 = res_809;
							 src_189 = src_808;
							 goto loop_191;
						      }
						   }
						}
					     }
					}
				   }
				 else
				   {
				      goto tag_122_225_198;
				   }
			      }
			   }
		      }
		 }
	      }
	      {
		 obj_t l1040_811;
		 l1040_811 = CDR(l1040_184);
		 l1040_184 = l1040_811;
		 goto lname1041_185;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      {
	 bool_t test1305_290;
	 {
	    long n1_470;
	    n1_470 = (long) CINT(_nb_error_on_pass__70_tools_error);
	    test1305_290 = (n1_470 > ((long) 0));
	 }
	 if (test1305_290)
	   {
	      {
		 char *arg1309_293;
		 {
		    bool_t test1320_300;
		    {
		       bool_t test1321_301;
		       {
			  obj_t obj_472;
			  obj_472 = _nb_error_on_pass__70_tools_error;
			  test1321_301 = INTEGERP(obj_472);
		       }
		       if (test1321_301)
			 {
			    test1320_300 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			 }
		       else
			 {
			    test1320_300 = ((bool_t) 0);
			 }
		    }
		    if (test1320_300)
		      {
			 arg1309_293 = "s";
		      }
		    else
		      {
			 arg1309_293 = "";
		      }
		 }
		 {
		    obj_t list1311_295;
		    {
		       obj_t arg1313_296;
		       {
			  obj_t arg1315_297;
			  {
			     obj_t arg1316_298;
			     arg1316_298 = MAKE_PAIR(string1386_expand_eps, BNIL);
			     {
				obj_t aux_822;
				aux_822 = string_to_bstring(arg1309_293);
				arg1315_297 = MAKE_PAIR(aux_822, arg1316_298);
			     }
			  }
			  arg1313_296 = MAKE_PAIR(string1387_expand_eps, arg1315_297);
		       }
		       list1311_295 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1313_296);
		    }
		    fprint___r4_output_6_10_3(current_error_port, list1311_295);
		 }
	      }
	      {
		 obj_t res1376_474;
		 exit(((long) -1));
		 res1376_474 = BINT(((long) -1));
		 return res1376_474;
	      }
	   }
	 else
	   {
	      obj_t hooks_302;
	      obj_t hnames_303;
	      hooks_302 = BNIL;
	      hnames_303 = BNIL;
	    loop_304:
	      if (NULLP(hooks_302))
		{
		   return units_33;
		}
	      else
		{
		   bool_t test1326_309;
		   {
		      obj_t fun1333_314;
		      fun1333_314 = CAR(hooks_302);
		      {
			 obj_t aux_833;
			 aux_833 = PROCEDURE_ENTRY(fun1333_314) (fun1333_314, BEOA);
			 test1326_309 = CBOOL(aux_833);
		      }
		   }
		   if (test1326_309)
		     {
			{
			   obj_t hnames_840;
			   obj_t hooks_838;
			   hooks_838 = CDR(hooks_302);
			   hnames_840 = CDR(hnames_303);
			   hnames_303 = hnames_840;
			   hooks_302 = hooks_838;
			   goto loop_304;
			}
		     }
		   else
		     {
			return internal_error_43_tools_error(_current_pass__25_engine_pass, string1388_expand_eps, CAR(hnames_303));
		     }
		}
	   }
      }
   }
}


/* handling_function1272 */ obj_t 
handling_function1272_expand_eps(obj_t body1045_641, obj_t rhandler1044_640, obj_t handler1043_639, obj_t armed1046_638)
{
   jmp_buf jmpbuf;
   obj_t an_exit1047_212;
   if (SET_EXIT(an_exit1047_212))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1047_212 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1047_212, ((bool_t) 1));
	   {
	      obj_t an_exitd1048_213;
	      an_exitd1048_213 = exitd_top;
	      {
		 obj_t escape_535;
		 escape_535 = make_fx_procedure(escape_1381_expand_eps, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_535, ((long) 0), an_exitd1048_213);
		 {
		    obj_t res1050_216;
		    {
		       obj_t arg1274_533;
		       obj_t arg1273_537;
		       arg1274_533 = make_fx_procedure(arg1274_expand_eps, ((long) 0), ((long) 1));
		       arg1273_537 = make_fx_procedure(arg1273_expand_eps, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1274_533, ((long) 0), armed1046_638);
		       PROCEDURE_SET(arg1273_537, ((long) 0), an_exitd1048_213);
		       PROCEDURE_SET(arg1273_537, ((long) 1), armed1046_638);
		       PROCEDURE_SET(arg1273_537, ((long) 2), handler1043_639);
		       PROCEDURE_SET(arg1273_537, ((long) 3), rhandler1044_640);
		       PROCEDURE_SET(arg1273_537, ((long) 4), escape_535);
		       res1050_216 = dynamic_wind_31___r4_control_features_6_9(arg1273_537, body1045_641, arg1274_533);
		    }
		    POP_EXIT();
		    return res1050_216;
		 }
	      }
	   }
	}
     }
}


/* handling_function1283 */ obj_t 
handling_function1283_expand_eps(obj_t body1053_645, obj_t rhandler1052_644, obj_t handler1051_643, obj_t armed1054_642)
{
   jmp_buf jmpbuf;
   obj_t an_exit1055_238;
   if (SET_EXIT(an_exit1055_238))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1055_238 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1055_238, ((bool_t) 1));
	   {
	      obj_t an_exitd1056_239;
	      an_exitd1056_239 = exitd_top;
	      {
		 obj_t escape_530;
		 escape_530 = make_fx_procedure(escape_1380_expand_eps, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_530, ((long) 0), an_exitd1056_239);
		 {
		    obj_t res1058_242;
		    {
		       obj_t arg1285_528;
		       obj_t arg1284_532;
		       arg1285_528 = make_fx_procedure(arg1285_expand_eps, ((long) 0), ((long) 1));
		       arg1284_532 = make_fx_procedure(arg1284_expand_eps, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1285_528, ((long) 0), armed1054_642);
		       PROCEDURE_SET(arg1284_532, ((long) 0), an_exitd1056_239);
		       PROCEDURE_SET(arg1284_532, ((long) 1), armed1054_642);
		       PROCEDURE_SET(arg1284_532, ((long) 2), handler1051_643);
		       PROCEDURE_SET(arg1284_532, ((long) 3), rhandler1052_644);
		       PROCEDURE_SET(arg1284_532, ((long) 4), escape_530);
		       res1058_242 = dynamic_wind_31___r4_control_features_6_9(arg1284_532, body1053_645, arg1285_528);
		    }
		    POP_EXIT();
		    return res1058_242;
		 }
	      }
	   }
	}
     }
}


/* handling_function1295 */ obj_t 
handling_function1295_expand_eps(obj_t body1061_649, obj_t rhandler1060_648, obj_t handler1059_647, obj_t armed1062_646)
{
   jmp_buf jmpbuf;
   obj_t an_exit1063_267;
   if (SET_EXIT(an_exit1063_267))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1063_267 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1063_267, ((bool_t) 1));
	   {
	      obj_t an_exitd1064_268;
	      an_exitd1064_268 = exitd_top;
	      {
		 obj_t escape_525;
		 escape_525 = make_fx_procedure(escape_expand_eps, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_525, ((long) 0), an_exitd1064_268);
		 {
		    obj_t res1066_271;
		    {
		       obj_t arg1297_520;
		       obj_t arg1296_527;
		       arg1297_520 = make_fx_procedure(arg1297_expand_eps, ((long) 0), ((long) 1));
		       arg1296_527 = make_fx_procedure(arg1296_expand_eps, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1297_520, ((long) 0), armed1062_646);
		       PROCEDURE_SET(arg1296_527, ((long) 0), an_exitd1064_268);
		       PROCEDURE_SET(arg1296_527, ((long) 1), armed1062_646);
		       PROCEDURE_SET(arg1296_527, ((long) 2), handler1059_647);
		       PROCEDURE_SET(arg1296_527, ((long) 3), rhandler1060_648);
		       PROCEDURE_SET(arg1296_527, ((long) 4), escape_525);
		       res1066_271 = dynamic_wind_31___r4_control_features_6_9(arg1296_527, body1061_649, arg1297_520);
		    }
		    POP_EXIT();
		    return res1066_271;
		 }
	      }
	   }
	}
     }
}


/* _expand-units */ obj_t 
_expand_units_69_expand_eps(obj_t env_539, obj_t units_540)
{
   return expand_units_9_expand_eps(units_540);
}


/* arg1297 */ obj_t 
arg1297_expand_eps(obj_t env_541)
{
   {
      obj_t armed1062_542;
      armed1062_542 = PROCEDURE_REF(env_541, ((long) 0));
      {
	 {
	    bool_t test_891;
	    {
	       obj_t aux_892;
	       aux_892 = CELL_REF(armed1062_542);
	       test_891 = CBOOL(aux_892);
	    }
	    if (test_891)
	      {
		 CELL_SET(armed1062_542, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1061 */ obj_t 
body1061_expand_eps(obj_t env_544)
{
   {
      obj_t src_545;
      src_545 = PROCEDURE_REF(env_544, ((long) 0));
      {
	 return initial_expander_162_expand_eps(CAR(src_545), initial_expander_env_197_expand_eps);
      }
   }
}


/* arg1296 */ obj_t 
arg1296_expand_eps(obj_t env_546)
{
   {
      obj_t rhandler1060_550;
      obj_t escape_551;
      rhandler1060_550 = PROCEDURE_REF(env_546, ((long) 3));
      escape_551 = PROCEDURE_REF(env_546, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1060_550, escape_551);
      }
   }
}


/* escape */ obj_t 
escape_expand_eps(obj_t env_552, obj_t val1065_554)
{
   {
      obj_t an_exitd1064_553;
      an_exitd1064_553 = PROCEDURE_REF(env_552, ((long) 0));
      {
	 obj_t val1065_269;
	 val1065_269 = val1065_554;
	 return unwind_until__178___bexit(an_exitd1064_553, val1065_269);
      }
   }
}


/* rhandler1060 */ obj_t 
rhandler1060_expand_eps(obj_t env_555, obj_t esc_558, obj_t obj_559, obj_t proc_560, obj_t msg_561)
{
   {
      obj_t armed1062_556;
      obj_t handler1059_557;
      armed1062_556 = PROCEDURE_REF(env_555, ((long) 0));
      handler1059_557 = PROCEDURE_REF(env_555, ((long) 1));
      {
	 obj_t esc_278;
	 obj_t obj_279;
	 obj_t proc_280;
	 obj_t msg_281;
	 esc_278 = esc_558;
	 obj_279 = obj_559;
	 proc_280 = proc_560;
	 msg_281 = msg_561;
	 CELL_SET(armed1062_556, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_907;
	    aux_907 = CELL_REF(handler1059_557);
	    return PROCEDURE_ENTRY(aux_907) (CELL_REF(handler1059_557), esc_278, obj_279, proc_280, msg_281, BEOA);
	 }
      }
   }
}


/* arg1285 */ obj_t 
arg1285_expand_eps(obj_t env_563)
{
   {
      obj_t armed1054_564;
      armed1054_564 = PROCEDURE_REF(env_563, ((long) 0));
      {
	 {
	    bool_t test_909;
	    {
	       obj_t aux_910;
	       aux_910 = CELL_REF(armed1054_564);
	       test_909 = CBOOL(aux_910);
	    }
	    if (test_909)
	      {
		 CELL_SET(armed1054_564, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1053 */ obj_t 
body1053_expand_eps(obj_t env_566)
{
   {
      obj_t src_567;
      src_567 = PROCEDURE_REF(env_566, ((long) 0));
      {
	 return initial_expander_162_expand_eps(CAR(src_567), initial_expander_env_197_expand_eps);
      }
   }
}


/* arg1284 */ obj_t 
arg1284_expand_eps(obj_t env_568)
{
   {
      obj_t rhandler1052_572;
      obj_t escape_573;
      rhandler1052_572 = PROCEDURE_REF(env_568, ((long) 3));
      escape_573 = PROCEDURE_REF(env_568, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1052_572, escape_573);
      }
   }
}


/* escape_1380 */ obj_t 
escape_1380_expand_eps(obj_t env_574, obj_t val1057_576)
{
   {
      obj_t an_exitd1056_575;
      an_exitd1056_575 = PROCEDURE_REF(env_574, ((long) 0));
      {
	 obj_t val1057_240;
	 val1057_240 = val1057_576;
	 return unwind_until__178___bexit(an_exitd1056_575, val1057_240);
      }
   }
}


/* rhandler1052 */ obj_t 
rhandler1052_expand_eps(obj_t env_577, obj_t esc_580, obj_t obj_581, obj_t proc_582, obj_t msg_583)
{
   {
      obj_t armed1054_578;
      obj_t handler1051_579;
      armed1054_578 = PROCEDURE_REF(env_577, ((long) 0));
      handler1051_579 = PROCEDURE_REF(env_577, ((long) 1));
      {
	 obj_t esc_249;
	 obj_t obj_250;
	 obj_t proc_251;
	 obj_t msg_252;
	 esc_249 = esc_580;
	 obj_250 = obj_581;
	 proc_251 = proc_582;
	 msg_252 = msg_583;
	 CELL_SET(armed1054_578, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_925;
	    aux_925 = CELL_REF(handler1051_579);
	    return PROCEDURE_ENTRY(aux_925) (CELL_REF(handler1051_579), esc_249, obj_250, proc_251, msg_252, BEOA);
	 }
      }
   }
}


/* arg1274 */ obj_t 
arg1274_expand_eps(obj_t env_585)
{
   {
      obj_t armed1046_586;
      armed1046_586 = PROCEDURE_REF(env_585, ((long) 0));
      {
	 {
	    bool_t test_927;
	    {
	       obj_t aux_928;
	       aux_928 = CELL_REF(armed1046_586);
	       test_927 = CBOOL(aux_928);
	    }
	    if (test_927)
	      {
		 CELL_SET(armed1046_586, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1045 */ obj_t 
body1045_expand_eps(obj_t env_588)
{
   {
      obj_t src_589;
      src_589 = PROCEDURE_REF(env_588, ((long) 0));
      {
	 return initial_expander_162_expand_eps(CAR(src_589), initial_expander_env_197_expand_eps);
      }
   }
}


/* arg1273 */ obj_t 
arg1273_expand_eps(obj_t env_590)
{
   {
      obj_t rhandler1044_594;
      obj_t escape_595;
      rhandler1044_594 = PROCEDURE_REF(env_590, ((long) 3));
      escape_595 = PROCEDURE_REF(env_590, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1044_594, escape_595);
      }
   }
}


/* escape_1381 */ obj_t 
escape_1381_expand_eps(obj_t env_596, obj_t val1049_598)
{
   {
      obj_t an_exitd1048_597;
      an_exitd1048_597 = PROCEDURE_REF(env_596, ((long) 0));
      {
	 obj_t val1049_214;
	 val1049_214 = val1049_598;
	 return unwind_until__178___bexit(an_exitd1048_597, val1049_214);
      }
   }
}


/* rhandler1044 */ obj_t 
rhandler1044_expand_eps(obj_t env_599, obj_t esc_602, obj_t obj_603, obj_t proc_604, obj_t msg_605)
{
   {
      obj_t armed1046_600;
      obj_t handler1043_601;
      armed1046_600 = PROCEDURE_REF(env_599, ((long) 0));
      handler1043_601 = PROCEDURE_REF(env_599, ((long) 1));
      {
	 obj_t esc_223;
	 obj_t obj_224;
	 obj_t proc_225;
	 obj_t msg_226;
	 esc_223 = esc_602;
	 obj_224 = obj_603;
	 proc_225 = proc_604;
	 msg_226 = msg_605;
	 CELL_SET(armed1046_600, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_943;
	    aux_943 = CELL_REF(handler1043_601);
	    return PROCEDURE_ENTRY(aux_943) (CELL_REF(handler1043_601), esc_223, obj_224, proc_225, msg_226, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_expand_eps(obj_t env_607, obj_t escape_608, obj_t proc_609, obj_t mes_610, obj_t obj_611)
{
   {
      obj_t escape_315;
      obj_t proc_316;
      obj_t mes_317;
      obj_t obj_318;
      escape_315 = escape_608;
      proc_316 = proc_609;
      mes_317 = mes_610;
      obj_318 = obj_611;
      {
	 obj_t arg1337_481;
	 {
	    obj_t list1340_483;
	    {
	       obj_t aux_944;
	       aux_944 = CNST_TABLE_REF(((long) 4));
	       list1340_483 = MAKE_PAIR(aux_944, BNIL);
	    }
	    arg1337_481 = user_error_151_tools_error(proc_316, mes_317, obj_318, list1340_483);
	 }
	 return PROCEDURE_ENTRY(escape_315) (escape_315, arg1337_481, BEOA);
      }
   }
}


/* comptime-expand */ obj_t 
comptime_expand_37_expand_eps(obj_t x_34)
{
   return initial_expander_162_expand_eps(x_34, initial_expander_env_197_expand_eps);
}


/* _comptime-expand */ obj_t 
_comptime_expand_212_expand_eps(obj_t env_618, obj_t x_619)
{
   return comptime_expand_37_expand_eps(x_619);
}


/* comptime-expand-once */ obj_t 
comptime_expand_once_113_expand_eps(obj_t x_35)
{
   {
      obj_t arg1343_620;
      arg1343_620 = proc1389_expand_eps;
      return initial_expander_162_expand_eps(x_35, arg1343_620);
   }
}


/* _comptime-expand-once */ obj_t 
_comptime_expand_once_1_expand_eps(obj_t env_621, obj_t x_622)
{
   return comptime_expand_once_113_expand_eps(x_622);
}


/* arg1343 */ obj_t 
arg1343_expand_eps(obj_t env_623, obj_t x_624, obj_t e_625)
{
   {
      obj_t x_486;
      obj_t e_487;
      x_486 = x_624;
      e_487 = e_625;
      return x_486;
   }
}


/* initial-expander */ obj_t 
initial_expander_162_expand_eps(obj_t x_36, obj_t e_37)
{
   {
      obj_t e1_330;
      if (SYMBOLP(x_36))
	{
	   e1_330 = _identifier_expander__env_242_expand_eps;
	}
      else
	{
	   if (NULLP(x_36))
	     {
		FAILURE(BFALSE, string1390_expand_eps, BNIL);
	     }
	   else
	     {
		if (PAIRP(x_36))
		  {
		     bool_t test_961;
		     {
			obj_t aux_962;
			aux_962 = CAR(x_36);
			test_961 = SYMBOLP(aux_962);
		     }
		     if (test_961)
		       {
			  {
			     obj_t id_337;
			     id_337 = fast_id_of_id_130_ast_ident(CAR(x_36));
			     {
				obj_t b_338;
				b_338 = BUNSPEC;
				{
				   bool_t test1352_339;
				   b_338 = get_compiler_expander_150___macro(id_337);
				   test1352_339 = CBOOL(b_338);
				   if (test1352_339)
				     {
					e1_330 = b_338;
				     }
				   else
				     {
					bool_t test1353_340;
					b_338 = get_eval_expander_232___macro(id_337);
					test1353_340 = CBOOL(b_338);
					if (test1353_340)
					  {
					     e1_330 = b_338;
					  }
					else
					  {
					     bool_t test1354_341;
					     {
						obj_t arg1356_343;
						{
						   obj_t arg1357_344;
						   arg1357_344 = _lexical_stack__25_expand_eps;
						   arg1356_343 = assq___r4_pairs_and_lists_6_3(id_337, arg1357_344);
						}
						test1354_341 = PAIRP(arg1356_343);
					     }
					     if (test1354_341)
					       {
						  e1_330 = _application_expander__env_69_expand_eps;
					       }
					     else
					       {
						  bool_t test1355_342;
						  b_338 = find_o_expander_0_expand_expander(id_337);
						  test1355_342 = CBOOL(b_338);
						  if (test1355_342)
						    {
						       {
							  obj_t s_499;
							  s_499 = b_338;
							  e1_330 = STRUCT_REF(s_499, ((long) 1));
						       }
						    }
						  else
						    {
						       e1_330 = _application_expander__env_69_expand_eps;
						    }
					       }
					  }
				     }
				}
			     }
			  }
		       }
		     else
		       {
			  e1_330 = _application_expander__env_69_expand_eps;
		       }
		  }
		else
		  {
		     {
			obj_t lambda1364_626;
			lambda1364_626 = proc1391_expand_eps;
			e1_330 = lambda1364_626;
		     }
		  }
	     }
	}
      return PROCEDURE_ENTRY(e1_330) (e1_330, x_36, e_37, BEOA);
   }
}


/* _initial-expander1379 */ obj_t 
_initial_expander1379_84_expand_eps(obj_t env_522, obj_t x_523, obj_t e_524)
{
   return initial_expander_162_expand_eps(x_523, e_524);
}


/* lambda1364 */ obj_t 
lambda1364_expand_eps(obj_t env_627, obj_t x_628, obj_t e_629)
{
   {
      obj_t x_347;
      obj_t e_348;
      x_347 = x_628;
      e_348 = e_629;
      return x_347;
   }
}


/* *identifier-expander* */ obj_t 
_identifier_expander__166_expand_eps(obj_t x_38, obj_t e_39)
{
   return x_38;
}


/* _*identifier-expander* */ obj_t 
__identifier_expander__134_expand_eps(obj_t env_630, obj_t x_631, obj_t e_632)
{
   return _identifier_expander__166_expand_eps(x_631, e_632);
}


/* *application-expander* */ obj_t 
_application_expander__202_expand_eps(obj_t x_40, obj_t e_41)
{
   return loop_expand_eps(e_41, x_40, x_40);
}


/* loop */ obj_t 
loop_expand_eps(obj_t e_637, obj_t x_636, obj_t x__12_350)
{
   if (PAIRP(x__12_350))
     {
	{
	   obj_t arg1367_353;
	   arg1367_353 = PROCEDURE_ENTRY(e_637) (e_637, CAR(x__12_350), e_637, BEOA);
	   SET_CAR(x__12_350, arg1367_353);
	}
	{
	   obj_t arg1369_355;
	   arg1369_355 = loop_expand_eps(e_637, x_636, CDR(x__12_350));
	   SET_CDR(x__12_350, arg1369_355);
	}
	return x__12_350;
     }
   else
     {
	if (NULLP(x__12_350))
	  {
	     return BNIL;
	  }
	else
	  {
	     FAILURE(BFALSE, string1390_expand_eps, x_636);
	  }
     }
}


/* _*application-expander* */ obj_t 
__application_expander__200_expand_eps(obj_t env_633, obj_t x_634, obj_t e_635)
{
   return _application_expander__202_expand_eps(x_634, e_635);
}


/* method-init */ obj_t 
method_init_76_expand_eps()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_eps()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_EPS");
   module_initialization_70_tools_speek(((long) 0), "EXPAND_EPS");
   module_initialization_70_tools_error(((long) 0), "EXPAND_EPS");
   module_initialization_70_engine_pass(((long) 0), "EXPAND_EPS");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_EPS");
   module_initialization_70_type_type(((long) 0), "EXPAND_EPS");
   module_initialization_70_ast_ident(((long) 0), "EXPAND_EPS");
   return module_initialization_70_expand_expander(((long) 0), "EXPAND_EPS");
}
