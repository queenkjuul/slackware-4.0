/*===========================================================================*/
/*   (Globalize/new-body.scm)                                                */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


static obj_t method_init_76_globalize_new_body_146();
extern obj_t make_box_202_ast_node;
static bool_t is_in__90_globalize_new_body_146(obj_t, obj_t);
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static long _round__57_globalize_new_body_146;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t set_globalized_new_bodies__10_globalize_new_body_146(global_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_new_body_146(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_globalize_new_body_146();
static obj_t _rem__default1584_9_globalize_new_body_146(obj_t, obj_t, obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_globalize_new_body_146();
static node_t rem__default1584_22_globalize_new_body_146(node_t, obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_globalize_new_body_146();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _set_globalized_new_bodies_1910_242_globalize_new_body_146(obj_t, obj_t, obj_t);
static obj_t rem___100_globalize_new_body_146(obj_t, obj_t, obj_t);
static obj_t _rem_1911_20_globalize_new_body_146(obj_t, obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
static node_t rem__73_globalize_new_body_146(node_t, obj_t, obj_t);
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t set_globalized_new_body__17_globalize_new_body_146(obj_t);
static obj_t require_initialization_114_globalize_new_body_146 = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_globalize_new_body_146();
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(rem__default1584_env_98_globalize_new_body_146, _rem__default1584_9_globalize_new_body_1461919, _rem__default1584_9_globalize_new_body_146, 0L, 3);
DEFINE_STATIC_GENERIC(rem__env_83_globalize_new_body_146, _rem_1911_20_globalize_new_body_1461920, _rem_1911_20_globalize_new_body_146, 0L, 3);
DEFINE_STRING(string1913_globalize_new_body_146, string1913_globalize_new_body_1461921, "REM!-DEFAULT1584 DONE ", 22);
DEFINE_STRING(string1912_globalize_new_body_146, string1912_globalize_new_body_1461922, "No method for this object", 25);
DEFINE_EXPORT_PROCEDURE(set_globalized_new_bodies__env_71_globalize_new_body_146, _set_globalized_new_bodies_1910_242_globalize_new_body_1461923, _set_globalized_new_bodies_1910_242_globalize_new_body_146, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_globalize_new_body_146(long checksum_2093, char *from_2094)
{
   if (CBOOL(require_initialization_114_globalize_new_body_146))
     {
	require_initialization_114_globalize_new_body_146 = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_new_body_146();
	cnst_init_137_globalize_new_body_146();
	imported_modules_init_94_globalize_new_body_146();
	method_init_76_globalize_new_body_146();
	toplevel_init_63_globalize_new_body_146();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_new_body_146()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_NEW-BODY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_new_body_146()
{
   {
      obj_t cnst_port_138_2085;
      cnst_port_138_2085 = open_input_string(string1913_globalize_new_body_146);
      {
	 long i_2086;
	 i_2086 = ((long) 1);
       loop_2087:
	 {
	    bool_t test1914_2088;
	    test1914_2088 = (i_2086 == ((long) -1));
	    if (test1914_2088)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1915_2089;
		    {
		       obj_t list1916_2090;
		       {
			  obj_t arg1917_2091;
			  arg1917_2091 = BNIL;
			  list1916_2090 = MAKE_PAIR(cnst_port_138_2085, arg1917_2091);
		       }
		       arg1915_2089 = read___reader(list1916_2090);
		    }
		    CNST_TABLE_SET(i_2086, arg1915_2089);
		 }
		 {
		    int aux_2092;
		    {
		       long aux_2112;
		       aux_2112 = (i_2086 - ((long) 1));
		       aux_2092 = (int) (aux_2112);
		    }
		    {
		       long i_2115;
		       i_2115 = (long) (aux_2092);
		       i_2086 = i_2115;
		       goto loop_2087;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_new_body_146()
{
   _round__57_globalize_new_body_146 = ((long) 0);
   return BUNSPEC;
}


/* set-globalized-new-bodies! */ obj_t 
set_globalized_new_bodies__10_globalize_new_body_146(global_t global_1, obj_t locals_2)
{
   {
      long z1_1727;
      z1_1727 = _round__57_globalize_new_body_146;
      _round__57_globalize_new_body_146 = (z1_1727 + ((long) 1));
   }
   {
      value_t fun_1064;
      fun_1064 = (((global_t) CREF(global_1))->value);
      {
	 node_t arg1615_1065;
	 {
	    node_t aux_2119;
	    {
	       obj_t aux_2120;
	       {
		  sfun_t obj_1730;
		  obj_1730 = (sfun_t) (fun_1064);
		  aux_2120 = (((sfun_t) CREF(obj_1730))->body);
	       }
	       aux_2119 = (node_t) (aux_2120);
	    }
	    arg1615_1065 = rem__73_globalize_new_body_146(aux_2119, (obj_t) (global_1), (obj_t) (global_1));
	 }
	 {
	    sfun_t obj_1731;
	    obj_t val1140_1732;
	    obj_1731 = (sfun_t) (fun_1064);
	    val1140_1732 = (obj_t) (arg1615_1065);
	    ((((sfun_t) CREF(obj_1731))->body) = ((obj_t) val1140_1732), BUNSPEC);
	 }
      }
   }
   {
      obj_t l1557_1067;
      {
	 bool_t aux_2130;
	 l1557_1067 = locals_2;
       lname1558_1068:
	 if (PAIRP(l1557_1067))
	   {
	      set_globalized_new_body__17_globalize_new_body_146(CAR(l1557_1067));
	      {
		 obj_t l1557_2135;
		 l1557_2135 = CDR(l1557_1067);
		 l1557_1067 = l1557_2135;
		 goto lname1558_1068;
	      }
	   }
	 else
	   {
	      aux_2130 = ((bool_t) 1);
	   }
	 return BBOOL(aux_2130);
      }
   }
}


/* _set-globalized-new-bodies!1910 */ obj_t 
_set_globalized_new_bodies_1910_242_globalize_new_body_146(obj_t env_2074, obj_t global_2075, obj_t locals_2076)
{
   return set_globalized_new_bodies__10_globalize_new_body_146((global_t) (global_2075), locals_2076);
}


/* set-globalized-new-body! */ obj_t 
set_globalized_new_body__17_globalize_new_body_146(obj_t local_3)
{
   {
      long z1_1736;
      z1_1736 = _round__57_globalize_new_body_146;
      _round__57_globalize_new_body_146 = (z1_1736 + ((long) 1));
   }
   {
      value_t fun_1072;
      {
	 local_t obj_1738;
	 obj_1738 = (local_t) (local_3);
	 fun_1072 = (((local_t) CREF(obj_1738))->value);
      }
      {
	 obj_t old_body_129_1074;
	 {
	    sfun_t obj_1740;
	    obj_1740 = (sfun_t) (fun_1072);
	    old_body_129_1074 = (((sfun_t) CREF(obj_1740))->body);
	 }
	 {
	    obj_t obindings_1075;
	    {
	       sfun_ginfo_98_t obj_1741;
	       obj_1741 = (sfun_ginfo_98_t) (fun_1072);
	       {
		  obj_t aux_2146;
		  {
		     object_t aux_2147;
		     aux_2147 = (object_t) (obj_1741);
		     aux_2146 = OBJECT_WIDENING(aux_2147);
		  }
		  obindings_1075 = (((sfun_ginfo_98_t) CREF(aux_2146))->integrated);
	       }
	    }
	    {
	       node_t new_body_215_1076;
	       new_body_215_1076 = rem__73_globalize_new_body_146((node_t) (old_body_129_1074), local_3, local_3);
	       {
		  {
		     obj_t l1559_1077;
		     l1559_1077 = obindings_1075;
		   lname1560_1078:
		     if (PAIRP(l1559_1077))
		       {
			  {
			     obj_t f_1080;
			     f_1080 = CAR(l1559_1077);
			     {
				bool_t test1623_1081;
				{
				   long n2_1747;
				   n2_1747 = _round__57_globalize_new_body_146;
				   {
				      long aux_2156;
				      {
					 sfun_ginfo_98_t obj_1745;
					 {
					    value_t aux_2157;
					    {
					       local_t obj_1744;
					       obj_1744 = (local_t) (f_1080);
					       aux_2157 = (((local_t) CREF(obj_1744))->value);
					    }
					    obj_1745 = (sfun_ginfo_98_t) (aux_2157);
					 }
					 {
					    obj_t aux_2161;
					    {
					       object_t aux_2162;
					       aux_2162 = (object_t) (obj_1745);
					       aux_2161 = OBJECT_WIDENING(aux_2162);
					    }
					    aux_2156 = (((sfun_ginfo_98_t) CREF(aux_2161))->bmark);
					 }
				      }
				      test1623_1081 = (aux_2156 == n2_1747);
				   }
				}
				if (test1623_1081)
				  {
				     BUNSPEC;
				  }
				else
				  {
				     value_t fun_1082;
				     {
					local_t obj_1748;
					obj_1748 = (local_t) (f_1080);
					fun_1082 = (((local_t) CREF(obj_1748))->value);
				     }
				     {
					{
					   node_t arg1624_1084;
					   {
					      node_t aux_2170;
					      {
						 obj_t aux_2171;
						 {
						    sfun_t obj_1749;
						    obj_1749 = (sfun_t) (fun_1082);
						    aux_2171 = (((sfun_t) CREF(obj_1749))->body);
						 }
						 aux_2170 = (node_t) (aux_2171);
					      }
					      arg1624_1084 = rem__73_globalize_new_body_146(aux_2170, local_3, f_1080);
					   }
					   {
					      sfun_t obj_1750;
					      obj_t val1140_1751;
					      obj_1750 = (sfun_t) (fun_1082);
					      val1140_1751 = (obj_t) (arg1624_1084);
					      ((((sfun_t) CREF(obj_1750))->body) = ((obj_t) val1140_1751), BUNSPEC);
					   }
					}
				     }
				  }
			     }
			  }
			  {
			     obj_t l1559_2179;
			     l1559_2179 = CDR(l1559_1077);
			     l1559_1077 = l1559_2179;
			     goto lname1560_1078;
			  }
		       }
		     else
		       {
			  ((bool_t) 1);
		       }
		  }
		  {
		     obj_t nbindings_1088;
		     {
			obj_t nbdings_1115;
			obj_t obdings_1116;
			nbdings_1115 = BNIL;
			obdings_1116 = obindings_1075;
		      loop_1117:
			if (NULLP(obdings_1116))
			  {
			     nbindings_1088 = nbdings_1115;
			  }
			else
			  {
			     bool_t test1655_1120;
			     {
				long n2_1758;
				n2_1758 = _round__57_globalize_new_body_146;
				{
				   long aux_2183;
				   {
				      sfun_ginfo_98_t obj_1756;
				      {
					 value_t aux_2184;
					 {
					    local_t obj_1755;
					    {
					       obj_t aux_2185;
					       aux_2185 = CAR(obdings_1116);
					       obj_1755 = (local_t) (aux_2185);
					    }
					    aux_2184 = (((local_t) CREF(obj_1755))->value);
					 }
					 obj_1756 = (sfun_ginfo_98_t) (aux_2184);
				      }
				      {
					 obj_t aux_2190;
					 {
					    object_t aux_2191;
					    aux_2191 = (object_t) (obj_1756);
					    aux_2190 = OBJECT_WIDENING(aux_2191);
					 }
					 aux_2183 = (((sfun_ginfo_98_t) CREF(aux_2190))->bmark);
				      }
				   }
				   test1655_1120 = (aux_2183 == n2_1758);
				}
			     }
			     if (test1655_1120)
			       {
				  {
				     obj_t obdings_2197;
				     obdings_2197 = CDR(obdings_1116);
				     obdings_1116 = obdings_2197;
				     goto loop_1117;
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1657_1122;
				     obj_t arg1658_1123;
				     {
					obj_t aux_2199;
					aux_2199 = CAR(obdings_1116);
					arg1657_1122 = MAKE_PAIR(aux_2199, nbdings_1115);
				     }
				     arg1658_1123 = CDR(obdings_1116);
				     {
					obj_t obdings_2204;
					obj_t nbdings_2203;
					nbdings_2203 = arg1657_1122;
					obdings_2204 = arg1658_1123;
					obdings_1116 = obdings_2204;
					nbdings_1115 = nbdings_2203;
					goto loop_1117;
				     }
				  }
			       }
			  }
		     }
		     {
			obj_t new2_body_172_1089;
			if (NULLP(nbindings_1088))
			  {
			     new2_body_172_1089 = (obj_t) (new_body_215_1076);
			  }
			else
			  {
			     obj_t arg1647_1110;
			     type_t arg1648_1111;
			     {
				node_t obj_1765;
				obj_1765 = (node_t) (old_body_129_1074);
				arg1647_1110 = (((node_t) CREF(obj_1765))->loc);
			     }
			     {
				node_t obj_1766;
				obj_1766 = (node_t) (old_body_129_1074);
				arg1648_1111 = (((node_t) CREF(obj_1766))->type);
			     }
			     {
				let_fun_218_t res1908_1783;
				{
				   obj_t key_1770;
				   key_1770 = BINT(((long) -1));
				   {
				      let_fun_218_t new1356_1773;
				      new1356_1773 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
				      {
					 long arg1707_1774;
					 arg1707_1774 = class_num_218___object(let_fun_218_ast_node);
					 {
					    obj_t obj_1781;
					    obj_1781 = (obj_t) (new1356_1773);
					    (((obj_t) CREF(obj_1781))->header = MAKE_HEADER(arg1707_1774, 0), BUNSPEC);
					 }
				      }
				      {
					 object_t aux_2217;
					 aux_2217 = (object_t) (new1356_1773);
					 OBJECT_WIDENING_SET(aux_2217, BFALSE);
				      }
				      ((((let_fun_218_t) CREF(new1356_1773))->loc) = ((obj_t) arg1647_1110), BUNSPEC);
				      ((((let_fun_218_t) CREF(new1356_1773))->type) = ((type_t) arg1648_1111), BUNSPEC);
				      ((((let_fun_218_t) CREF(new1356_1773))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
				      ((((let_fun_218_t) CREF(new1356_1773))->key) = ((obj_t) key_1770), BUNSPEC);
				      ((((let_fun_218_t) CREF(new1356_1773))->locals) = ((obj_t) nbindings_1088), BUNSPEC);
				      ((((let_fun_218_t) CREF(new1356_1773))->body) = ((node_t) new_body_215_1076), BUNSPEC);
				      res1908_1783 = new1356_1773;
				   }
				}
				new2_body_172_1089 = (obj_t) (res1908_1783);
			     }
			  }
			{
			   obj_t ncto_1090;
			   obj_t nbindings_1091;
			   {
			      sfun_ginfo_98_t obj_1784;
			      obj_1784 = (sfun_ginfo_98_t) (fun_1072);
			      {
				 obj_t aux_2265;
				 {
				    object_t aux_2266;
				    aux_2266 = (object_t) (obj_1784);
				    aux_2265 = OBJECT_WIDENING(aux_2266);
				 }
				 ncto_1090 = (((sfun_ginfo_98_t) CREF(aux_2265))->cto);
			      }
			   }
			   nbindings_1091 = nbindings_1088;
			 loop_1092:
			   if (NULLP(nbindings_1091))
			     {
				sfun_ginfo_98_t obj_1786;
				obj_1786 = (sfun_ginfo_98_t) (fun_1072);
				{
				   obj_t aux_2230;
				   {
				      object_t aux_2231;
				      aux_2231 = (object_t) (obj_1786);
				      aux_2230 = OBJECT_WIDENING(aux_2231);
				   }
				   ((((sfun_ginfo_98_t) CREF(aux_2230))->cto) = ((obj_t) ncto_1090), BUNSPEC);
				}
			     }
			   else
			     {
				obj_t ncto_1095;
				obj_t lcto_1096;
				ncto_1095 = ncto_1090;
				{
				   sfun_ginfo_98_t obj_1790;
				   {
				      value_t aux_2253;
				      {
					 local_t obj_1789;
					 {
					    obj_t aux_2254;
					    aux_2254 = CAR(nbindings_1091);
					    obj_1789 = (local_t) (aux_2254);
					 }
					 aux_2253 = (((local_t) CREF(obj_1789))->value);
				      }
				      obj_1790 = (sfun_ginfo_98_t) (aux_2253);
				   }
				   {
				      obj_t aux_2259;
				      {
					 object_t aux_2260;
					 aux_2260 = (object_t) (obj_1790);
					 aux_2259 = OBJECT_WIDENING(aux_2260);
				      }
				      lcto_1096 = (((sfun_ginfo_98_t) CREF(aux_2259))->cto);
				   }
				}
			      liip_1097:
				if (NULLP(lcto_1096))
				  {
				     {
					obj_t nbindings_2238;
					obj_t ncto_2237;
					ncto_2237 = ncto_1095;
					nbindings_2238 = CDR(nbindings_1091);
					nbindings_1091 = nbindings_2238;
					ncto_1090 = ncto_2237;
					goto loop_1092;
				     }
				  }
				else
				  {
				     bool_t test_2240;
				     {
					obj_t aux_2241;
					aux_2241 = memq___r4_pairs_and_lists_6_3(CAR(lcto_1096), ncto_1095);
					test_2240 = CBOOL(aux_2241);
				     }
				     if (test_2240)
				       {
					  {
					     obj_t lcto_2245;
					     lcto_2245 = CDR(lcto_1096);
					     lcto_1096 = lcto_2245;
					     goto liip_1097;
					  }
				       }
				     else
				       {
					  {
					     obj_t arg1639_1105;
					     obj_t arg1640_1106;
					     {
						obj_t aux_2247;
						aux_2247 = CAR(lcto_1096);
						arg1639_1105 = MAKE_PAIR(aux_2247, ncto_1095);
					     }
					     arg1640_1106 = CDR(lcto_1096);
					     {
						obj_t lcto_2252;
						obj_t ncto_2251;
						ncto_2251 = arg1639_1105;
						lcto_2252 = arg1640_1106;
						lcto_1096 = lcto_2252;
						ncto_1095 = ncto_2251;
						goto liip_1097;
					     }
					  }
				       }
				  }
			     }
			}
			{
			   sfun_ginfo_98_t obj_1799;
			   obj_1799 = (sfun_ginfo_98_t) (fun_1072);
			   {
			      obj_t aux_2271;
			      {
				 object_t aux_2272;
				 aux_2272 = (object_t) (obj_1799);
				 aux_2271 = OBJECT_WIDENING(aux_2272);
			      }
			      return ((((sfun_ginfo_98_t) CREF(aux_2271))->new_body_215) = ((obj_t) new2_body_172_1089), BUNSPEC);
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* is-in? */ bool_t 
is_in__90_globalize_new_body_146(obj_t f1_4, obj_t f2_5)
{
   {
      value_t info_1128;
      {
	 local_t obj_1801;
	 obj_1801 = (local_t) (f1_4);
	 info_1128 = (((local_t) CREF(obj_1801))->value);
      }
      {
	 bool_t test_2278;
	 {
	    sfun_ginfo_98_t obj_1802;
	    obj_1802 = (sfun_ginfo_98_t) (info_1128);
	    {
	       obj_t aux_2280;
	       {
		  object_t aux_2281;
		  aux_2281 = (object_t) (obj_1802);
		  aux_2280 = OBJECT_WIDENING(aux_2281);
	       }
	       test_2278 = (((sfun_ginfo_98_t) CREF(aux_2280))->g__219);
	    }
	 }
	 if (test_2278)
	   {
	      return ((bool_t) 0);
	   }
	 else
	   {
	      bool_t test1667_1130;
	      {
		 obj_t aux_2285;
		 {
		    sfun_ginfo_98_t obj_1803;
		    obj_1803 = (sfun_ginfo_98_t) (info_1128);
		    {
		       obj_t aux_2287;
		       {
			  object_t aux_2288;
			  aux_2288 = (object_t) (obj_1803);
			  aux_2287 = OBJECT_WIDENING(aux_2288);
		       }
		       aux_2285 = (((sfun_ginfo_98_t) CREF(aux_2287))->integrator);
		    }
		 }
		 test1667_1130 = is_a__118___object(aux_2285, local_ast_var);
	      }
	      if (test1667_1130)
		{
		   bool_t test_2294;
		   {
		      obj_t aux_2295;
		      {
			 sfun_ginfo_98_t obj_1805;
			 obj_1805 = (sfun_ginfo_98_t) (info_1128);
			 {
			    obj_t aux_2297;
			    {
			       object_t aux_2298;
			       aux_2298 = (object_t) (obj_1805);
			       aux_2297 = OBJECT_WIDENING(aux_2298);
			    }
			    aux_2295 = (((sfun_ginfo_98_t) CREF(aux_2297))->integrator);
			 }
		      }
		      test_2294 = (aux_2295 == f2_5);
		   }
		   if (test_2294)
		     {
			return ((bool_t) 1);
		     }
		   else
		     {
			return ((bool_t) 0);
		     }
		}
	      else
		{
		   return ((bool_t) 1);
		}
	   }
      }
   }
}


/* rem*! */ obj_t 
rem___100_globalize_new_body_146(obj_t node__221_72, obj_t owner_73, obj_t current_74)
{
   {
      obj_t node__221_1134;
      node__221_1134 = node__221_72;
    loop_1135:
      if (NULLP(node__221_1134))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   {
	      node_t arg1672_1137;
	      {
		 node_t aux_2306;
		 {
		    obj_t aux_2307;
		    aux_2307 = CAR(node__221_1134);
		    aux_2306 = (node_t) (aux_2307);
		 }
		 arg1672_1137 = rem__73_globalize_new_body_146(aux_2306, owner_73, current_74);
	      }
	      {
		 obj_t aux_2311;
		 aux_2311 = (obj_t) (arg1672_1137);
		 SET_CAR(node__221_1134, aux_2311);
	      }
	   }
	   {
	      obj_t node__221_2314;
	      node__221_2314 = CDR(node__221_1134);
	      node__221_1134 = node__221_2314;
	      goto loop_1135;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_globalize_new_body_146()
{
   add_generic__110___object(rem__env_83_globalize_new_body_146, rem__default1584_env_98_globalize_new_body_146);
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, var_ast_node, ((long) 2));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, app_ast_node, ((long) 4));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, select_ast_node, ((long) 12));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(rem__env_83_globalize_new_body_146, box_ref_242_ast_node, ((long) 18));
   {
      long aux_2336;
      aux_2336 = add_inlined_method__244___object(rem__env_83_globalize_new_body_146, box_set__221_ast_node, ((long) 19));
      return BINT(aux_2336);
   }
}


/* rem! */ node_t 
rem__73_globalize_new_body_146(node_t node_6, obj_t owner_7, obj_t current_8)
{
   {
      obj_t method1787_1535;
      obj_t class1792_1536;
      {
	 obj_t arg1795_1533;
	 obj_t arg1796_1534;
	 {
	    object_t obj_1917;
	    obj_1917 = (object_t) (node_6);
	    {
	       obj_t pre_method_105_1918;
	       pre_method_105_1918 = PROCEDURE_REF(rem__env_83_globalize_new_body_146, ((long) 2));
	       if (INTEGERP(pre_method_105_1918))
		 {
		    PROCEDURE_SET(rem__env_83_globalize_new_body_146, ((long) 2), BUNSPEC);
		    arg1795_1533 = pre_method_105_1918;
		 }
	       else
		 {
		    long obj_class_num_177_1923;
		    obj_class_num_177_1923 = TYPE(obj_1917);
		    {
		       obj_t arg1177_1924;
		       arg1177_1924 = PROCEDURE_REF(rem__env_83_globalize_new_body_146, ((long) 1));
		       {
			  long arg1178_1928;
			  {
			     long arg1179_1929;
			     arg1179_1929 = OBJECT_TYPE;
			     arg1178_1928 = (obj_class_num_177_1923 - arg1179_1929);
			  }
			  arg1795_1533 = VECTOR_REF(arg1177_1924, arg1178_1928);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1934;
	    object_1934 = (object_t) (node_6);
	    {
	       long arg1180_1935;
	       {
		  long arg1181_1936;
		  long arg1182_1937;
		  arg1181_1936 = TYPE(object_1934);
		  arg1182_1937 = OBJECT_TYPE;
		  arg1180_1935 = (arg1181_1936 - arg1182_1937);
	       }
	       {
		  obj_t vector_1941;
		  vector_1941 = _classes__134___object;
		  arg1796_1534 = VECTOR_REF(vector_1941, arg1180_1935);
	       }
	    }
	 }
	 {
	    obj_t aux_2354;
	    method1787_1535 = arg1795_1533;
	    class1792_1536 = arg1796_1534;
	    {
	       if (INTEGERP(method1787_1535))
		 {
		    switch ((long) CINT(method1787_1535))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_2357;
			    aux_2357 = (atom_t) (node_6);
			    aux_2354 = (obj_t) (aux_2357);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_2360;
			    aux_2360 = (kwote_t) (node_6);
			    aux_2354 = (obj_t) (aux_2360);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_2363;
			    aux_2363 = (var_t) (node_6);
			    aux_2354 = (obj_t) (aux_2363);
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1551;
			    node_1551 = (sequence_t) (node_6);
			    rem___100_globalize_new_body_146((((sequence_t) CREF(node_1551))->nodes), owner_7, current_8);
			    aux_2354 = (obj_t) (node_1551);
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1556;
			    node_1556 = (app_t) (node_6);
			    rem___100_globalize_new_body_146((((app_t) CREF(node_1556))->args), owner_7, current_8);
			    aux_2354 = (obj_t) (node_1556);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1561;
			    node_1561 = (app_ly_162_t) (node_6);
			    {
			       node_t arg1802_1565;
			       arg1802_1565 = rem__73_globalize_new_body_146((((app_ly_162_t) CREF(node_1561))->fun), owner_7, current_8);
			       ((((app_ly_162_t) CREF(node_1561))->fun) = ((node_t) arg1802_1565), BUNSPEC);
			    }
			    {
			       node_t arg1804_1567;
			       arg1804_1567 = rem__73_globalize_new_body_146((((app_ly_162_t) CREF(node_1561))->arg), owner_7, current_8);
			       ((((app_ly_162_t) CREF(node_1561))->arg) = ((node_t) arg1804_1567), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1561);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1569;
			    node_1569 = (funcall_t) (node_6);
			    {
			       node_t arg1806_1573;
			       arg1806_1573 = rem__73_globalize_new_body_146((((funcall_t) CREF(node_1569))->fun), owner_7, current_8);
			       ((((funcall_t) CREF(node_1569))->fun) = ((node_t) arg1806_1573), BUNSPEC);
			    }
			    rem___100_globalize_new_body_146((((funcall_t) CREF(node_1569))->args), owner_7, current_8);
			    aux_2354 = (obj_t) (node_1569);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1576;
			    node_1576 = (pragma_t) (node_6);
			    rem___100_globalize_new_body_146((((pragma_t) CREF(node_1576))->args), owner_7, current_8);
			    aux_2354 = (obj_t) (node_1576);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1581;
			    node_1581 = (cast_t) (node_6);
			    rem__73_globalize_new_body_146((((cast_t) CREF(node_1581))->arg), owner_7, current_8);
			    aux_2354 = (obj_t) (node_1581);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1586;
			    node_1586 = (setq_t) (node_6);
			    {
			       node_t arg1811_1590;
			       arg1811_1590 = rem__73_globalize_new_body_146((((setq_t) CREF(node_1586))->value), owner_7, current_8);
			       ((((setq_t) CREF(node_1586))->value) = ((node_t) arg1811_1590), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1586);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1592;
			    node_1592 = (conditional_t) (node_6);
			    {
			       node_t arg1813_1596;
			       arg1813_1596 = rem__73_globalize_new_body_146((((conditional_t) CREF(node_1592))->test), owner_7, current_8);
			       ((((conditional_t) CREF(node_1592))->test) = ((node_t) arg1813_1596), BUNSPEC);
			    }
			    {
			       node_t arg1815_1598;
			       arg1815_1598 = rem__73_globalize_new_body_146((((conditional_t) CREF(node_1592))->true), owner_7, current_8);
			       ((((conditional_t) CREF(node_1592))->true) = ((node_t) arg1815_1598), BUNSPEC);
			    }
			    {
			       node_t arg1817_1600;
			       arg1817_1600 = rem__73_globalize_new_body_146((((conditional_t) CREF(node_1592))->false), owner_7, current_8);
			       ((((conditional_t) CREF(node_1592))->false) = ((node_t) arg1817_1600), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1592);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1602;
			    node_1602 = (fail_t) (node_6);
			    {
			       node_t arg1820_1606;
			       arg1820_1606 = rem__73_globalize_new_body_146((((fail_t) CREF(node_1602))->proc), owner_7, current_8);
			       ((((fail_t) CREF(node_1602))->proc) = ((node_t) arg1820_1606), BUNSPEC);
			    }
			    {
			       node_t arg1822_1608;
			       arg1822_1608 = rem__73_globalize_new_body_146((((fail_t) CREF(node_1602))->msg), owner_7, current_8);
			       ((((fail_t) CREF(node_1602))->msg) = ((node_t) arg1822_1608), BUNSPEC);
			    }
			    {
			       node_t arg1824_1610;
			       arg1824_1610 = rem__73_globalize_new_body_146((((fail_t) CREF(node_1602))->obj), owner_7, current_8);
			       ((((fail_t) CREF(node_1602))->obj) = ((node_t) arg1824_1610), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1602);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1612;
			    node_1612 = (select_t) (node_6);
			    {
			       node_t arg1827_1616;
			       arg1827_1616 = rem__73_globalize_new_body_146((((select_t) CREF(node_1612))->test), owner_7, current_8);
			       ((((select_t) CREF(node_1612))->test) = ((node_t) arg1827_1616), BUNSPEC);
			    }
			    {
			       obj_t l1572_1618;
			       l1572_1618 = (((select_t) CREF(node_1612))->clauses);
			     lname1573_1619:
			       if (PAIRP(l1572_1618))
				 {
				    {
				       obj_t clause_1622;
				       clause_1622 = CAR(l1572_1618);
				       {
					  node_t arg1832_1623;
					  {
					     node_t aux_2431;
					     {
						obj_t aux_2432;
						aux_2432 = CDR(clause_1622);
						aux_2431 = (node_t) (aux_2432);
					     }
					     arg1832_1623 = rem__73_globalize_new_body_146(aux_2431, owner_7, current_8);
					  }
					  {
					     obj_t aux_2436;
					     aux_2436 = (obj_t) (arg1832_1623);
					     SET_CDR(clause_1622, aux_2436);
					  }
				       }
				    }
				    {
				       obj_t l1572_2439;
				       l1572_2439 = CDR(l1572_1618);
				       l1572_1618 = l1572_2439;
				       goto lname1573_1619;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2354 = (obj_t) (node_1612);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1626;
			    node_1626 = (let_fun_218_t) (node_6);
			    {
			       node_t arg1835_1630;
			       arg1835_1630 = rem__73_globalize_new_body_146((((let_fun_218_t) CREF(node_1626))->body), owner_7, current_8);
			       ((((let_fun_218_t) CREF(node_1626))->body) = ((node_t) arg1835_1630), BUNSPEC);
			    }
			    {
			       obj_t obindings_1632;
			       obj_t nbindings_1633;
			       {
				  let_fun_218_t aux_2447;
				  obindings_1632 = (((let_fun_218_t) CREF(node_1626))->locals);
				  nbindings_1633 = BNIL;
				liip_1634:
				  if (NULLP(obindings_1632))
				    {
				       ((((let_fun_218_t) CREF(node_1626))->locals) = ((obj_t) nbindings_1633), BUNSPEC);
				       aux_2447 = node_1626;
				    }
				  else
				    {
				       bool_t test1840_1638;
				       {
					  long n2_1999;
					  n2_1999 = _round__57_globalize_new_body_146;
					  {
					     long aux_2451;
					     {
						sfun_ginfo_98_t obj_1997;
						{
						   value_t aux_2452;
						   {
						      local_t obj_1996;
						      {
							 obj_t aux_2453;
							 aux_2453 = CAR(obindings_1632);
							 obj_1996 = (local_t) (aux_2453);
						      }
						      aux_2452 = (((local_t) CREF(obj_1996))->value);
						   }
						   obj_1997 = (sfun_ginfo_98_t) (aux_2452);
						}
						{
						   obj_t aux_2458;
						   {
						      object_t aux_2459;
						      aux_2459 = (object_t) (obj_1997);
						      aux_2458 = OBJECT_WIDENING(aux_2459);
						   }
						   aux_2451 = (((sfun_ginfo_98_t) CREF(aux_2458))->bmark);
						}
					     }
					     test1840_1638 = (aux_2451 == n2_1999);
					  }
				       }
				       if (test1840_1638)
					 {
					    {
					       bool_t test_2465;
					       {
						  obj_t aux_2466;
						  {
						     sfun_ginfo_98_t obj_2002;
						     {
							value_t aux_2467;
							{
							   local_t obj_2001;
							   {
							      obj_t aux_2468;
							      aux_2468 = CAR(obindings_1632);
							      obj_2001 = (local_t) (aux_2468);
							   }
							   aux_2467 = (((local_t) CREF(obj_2001))->value);
							}
							obj_2002 = (sfun_ginfo_98_t) (aux_2467);
						     }
						     {
							obj_t aux_2473;
							{
							   object_t aux_2474;
							   aux_2474 = (object_t) (obj_2002);
							   aux_2473 = OBJECT_WIDENING(aux_2474);
							}
							aux_2466 = (((sfun_ginfo_98_t) CREF(aux_2473))->plugged_in_15);
						     }
						  }
						  test_2465 = (current_8 == aux_2466);
					       }
					       if (test_2465)
						 {
						    obj_t arg1842_1640;
						    obj_t arg1843_1641;
						    arg1842_1640 = CDR(obindings_1632);
						    {
						       obj_t aux_2480;
						       aux_2480 = CAR(obindings_1632);
						       arg1843_1641 = MAKE_PAIR(aux_2480, nbindings_1633);
						    }
						    {
						       obj_t nbindings_2484;
						       obj_t obindings_2483;
						       obindings_2483 = arg1842_1640;
						       nbindings_2484 = arg1843_1641;
						       nbindings_1633 = nbindings_2484;
						       obindings_1632 = obindings_2483;
						       goto liip_1634;
						    }
						 }
					       else
						 {
						    obj_t obindings_2485;
						    obindings_2485 = CDR(obindings_1632);
						    obindings_1632 = obindings_2485;
						    goto liip_1634;
						 }
					    }
					 }
				       else
					 {
					    if (is_in__90_globalize_new_body_146(CAR(obindings_1632), owner_7))
					      {
						 {
						    sfun_ginfo_98_t obj_2013;
						    long val1487_2014;
						    {
						       value_t aux_2490;
						       {
							  local_t obj_2012;
							  {
							     obj_t aux_2491;
							     aux_2491 = CAR(obindings_1632);
							     obj_2012 = (local_t) (aux_2491);
							  }
							  aux_2490 = (((local_t) CREF(obj_2012))->value);
						       }
						       obj_2013 = (sfun_ginfo_98_t) (aux_2490);
						    }
						    val1487_2014 = _round__57_globalize_new_body_146;
						    {
						       obj_t aux_2496;
						       {
							  object_t aux_2497;
							  aux_2497 = (object_t) (obj_2013);
							  aux_2496 = OBJECT_WIDENING(aux_2497);
						       }
						       ((((sfun_ginfo_98_t) CREF(aux_2496))->bmark) = ((long) val1487_2014), BUNSPEC);
						    }
						 }
						 {
						    sfun_ginfo_98_t obj_2017;
						    {
						       value_t aux_2501;
						       {
							  local_t obj_2016;
							  {
							     obj_t aux_2502;
							     aux_2502 = CAR(obindings_1632);
							     obj_2016 = (local_t) (aux_2502);
							  }
							  aux_2501 = (((local_t) CREF(obj_2016))->value);
						       }
						       obj_2017 = (sfun_ginfo_98_t) (aux_2501);
						    }
						    {
						       obj_t aux_2507;
						       {
							  object_t aux_2508;
							  aux_2508 = (object_t) (obj_2017);
							  aux_2507 = OBJECT_WIDENING(aux_2508);
						       }
						       ((((sfun_ginfo_98_t) CREF(aux_2507))->plugged_in_15) = ((obj_t) current_8), BUNSPEC);
						    }
						 }
						 {
						    value_t fun_1652;
						    {
						       local_t obj_2020;
						       {
							  obj_t aux_2512;
							  aux_2512 = CAR(obindings_1632);
							  obj_2020 = (local_t) (aux_2512);
						       }
						       fun_1652 = (((local_t) CREF(obj_2020))->value);
						    }
						    {
						       {
							  node_t arg1860_1654;
							  {
							     node_t aux_2516;
							     {
								obj_t aux_2517;
								{
								   sfun_t obj_2021;
								   obj_2021 = (sfun_t) (fun_1652);
								   aux_2517 = (((sfun_t) CREF(obj_2021))->body);
								}
								aux_2516 = (node_t) (aux_2517);
							     }
							     arg1860_1654 = rem__73_globalize_new_body_146(aux_2516, owner_7, CAR(obindings_1632));
							  }
							  {
							     sfun_t obj_2023;
							     obj_t val1140_2024;
							     obj_2023 = (sfun_t) (fun_1652);
							     val1140_2024 = (obj_t) (arg1860_1654);
							     ((((sfun_t) CREF(obj_2023))->body) = ((obj_t) val1140_2024), BUNSPEC);
							  }
						       }
						       {
							  obj_t arg1862_1656;
							  obj_t arg1863_1657;
							  arg1862_1656 = CDR(obindings_1632);
							  {
							     obj_t aux_2527;
							     aux_2527 = CAR(obindings_1632);
							     arg1863_1657 = MAKE_PAIR(aux_2527, nbindings_1633);
							  }
							  {
							     obj_t nbindings_2531;
							     obj_t obindings_2530;
							     obindings_2530 = arg1862_1656;
							     nbindings_2531 = arg1863_1657;
							     nbindings_1633 = nbindings_2531;
							     obindings_1632 = obindings_2530;
							     goto liip_1634;
							  }
						       }
						    }
						 }
					      }
					    else
					      {
						 bool_t test_2532;
						 {
						    local_ginfo_108_t obj_2030;
						    {
						       obj_t aux_2533;
						       aux_2533 = CAR(obindings_1632);
						       obj_2030 = (local_ginfo_108_t) (aux_2533);
						    }
						    {
						       obj_t aux_2536;
						       {
							  object_t aux_2537;
							  aux_2537 = (object_t) (obj_2030);
							  aux_2536 = OBJECT_WIDENING(aux_2537);
						       }
						       test_2532 = (((local_ginfo_108_t) CREF(aux_2536))->escape__117);
						    }
						 }
						 if (test_2532)
						   {
						      {
							 obj_t arg1867_1661;
							 obj_t arg1868_1662;
							 arg1867_1661 = CDR(obindings_1632);
							 {
							    obj_t aux_2542;
							    aux_2542 = CAR(obindings_1632);
							    arg1868_1662 = MAKE_PAIR(aux_2542, nbindings_1633);
							 }
							 {
							    obj_t nbindings_2546;
							    obj_t obindings_2545;
							    obindings_2545 = arg1867_1661;
							    nbindings_2546 = arg1868_1662;
							    nbindings_1633 = nbindings_2546;
							    obindings_1632 = obindings_2545;
							    goto liip_1634;
							 }
						      }
						   }
						 else
						   {
						      {
							 obj_t obindings_2547;
							 obindings_2547 = CDR(obindings_1632);
							 obindings_1632 = obindings_2547;
							 goto liip_1634;
						      }
						   }
					      }
					 }
				    }
				  aux_2354 = (obj_t) (aux_2447);
			       }
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1670;
			    node_1670 = (let_var_6_t) (node_6);
			    {
			       node_t arg1878_1674;
			       arg1878_1674 = rem__73_globalize_new_body_146((((let_var_6_t) CREF(node_1670))->body), owner_7, current_8);
			       ((((let_var_6_t) CREF(node_1670))->body) = ((node_t) arg1878_1674), BUNSPEC);
			    }
			    {
			       obj_t l1576_1676;
			       l1576_1676 = (((let_var_6_t) CREF(node_1670))->bindings);
			     lname1577_1677:
			       if (PAIRP(l1576_1676))
				 {
				    {
				       obj_t binding_1680;
				       binding_1680 = CAR(l1576_1676);
				       {
					  node_t arg1883_1681;
					  {
					     node_t aux_2558;
					     {
						obj_t aux_2559;
						aux_2559 = CDR(binding_1680);
						aux_2558 = (node_t) (aux_2559);
					     }
					     arg1883_1681 = rem__73_globalize_new_body_146(aux_2558, owner_7, current_8);
					  }
					  {
					     obj_t aux_2563;
					     aux_2563 = (obj_t) (arg1883_1681);
					     SET_CDR(binding_1680, aux_2563);
					  }
				       }
				    }
				    {
				       obj_t l1576_2566;
				       l1576_2566 = CDR(l1576_1676);
				       l1576_1676 = l1576_2566;
				       goto lname1577_1677;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2354 = (obj_t) (node_1670);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1684;
			    node_1684 = (set_ex_it_116_t) (node_6);
			    {
			       node_t arg1886_1688;
			       arg1886_1688 = rem__73_globalize_new_body_146((((set_ex_it_116_t) CREF(node_1684))->body), owner_7, current_8);
			       ((((set_ex_it_116_t) CREF(node_1684))->body) = ((node_t) arg1886_1688), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1684);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1690;
			    node_1690 = (jump_ex_it_184_t) (node_6);
			    {
			       node_t arg1888_1694;
			       arg1888_1694 = rem__73_globalize_new_body_146((((jump_ex_it_184_t) CREF(node_1690))->exit), owner_7, current_8);
			       ((((jump_ex_it_184_t) CREF(node_1690))->exit) = ((node_t) arg1888_1694), BUNSPEC);
			    }
			    {
			       node_t arg1892_1696;
			       arg1892_1696 = rem__73_globalize_new_body_146((((jump_ex_it_184_t) CREF(node_1690))->value), owner_7, current_8);
			       ((((jump_ex_it_184_t) CREF(node_1690))->value) = ((node_t) arg1892_1696), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1690);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1698;
			    node_1698 = (make_box_202_t) (node_6);
			    {
			       node_t arg1894_1702;
			       arg1894_1702 = rem__73_globalize_new_body_146((((make_box_202_t) CREF(node_1698))->value), owner_7, current_8);
			       ((((make_box_202_t) CREF(node_1698))->value) = ((node_t) arg1894_1702), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1698);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_ref_242_t node_1704;
			    node_1704 = (box_ref_242_t) (node_6);
			    {
			       node_t arg1896_1708;
			       {
				  node_t aux_2589;
				  {
				     var_t aux_2590;
				     aux_2590 = (((box_ref_242_t) CREF(node_1704))->var);
				     aux_2589 = (node_t) (aux_2590);
				  }
				  arg1896_1708 = rem__73_globalize_new_body_146(aux_2589, owner_7, current_8);
			       }
			       {
				  var_t val1428_2060;
				  val1428_2060 = (var_t) (arg1896_1708);
				  ((((box_ref_242_t) CREF(node_1704))->var) = ((var_t) val1428_2060), BUNSPEC);
			       }
			    }
			    aux_2354 = (obj_t) (node_1704);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_set__221_t node_1710;
			    node_1710 = (box_set__221_t) (node_6);
			    {
			       node_t arg1898_1714;
			       {
				  node_t aux_2598;
				  {
				     var_t aux_2599;
				     aux_2599 = (((box_set__221_t) CREF(node_1710))->var);
				     aux_2598 = (node_t) (aux_2599);
				  }
				  arg1898_1714 = rem__73_globalize_new_body_146(aux_2598, owner_7, current_8);
			       }
			       {
				  var_t val1437_2063;
				  val1437_2063 = (var_t) (arg1898_1714);
				  ((((box_set__221_t) CREF(node_1710))->var) = ((var_t) val1437_2063), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1900_1716;
			       arg1900_1716 = rem__73_globalize_new_body_146((((box_set__221_t) CREF(node_1710))->value), owner_7, current_8);
			       ((((box_set__221_t) CREF(node_1710))->value) = ((node_t) arg1900_1716), BUNSPEC);
			    }
			    aux_2354 = (obj_t) (node_1710);
			 }
			 break;
		      default:
		       case_else1793_1539:
			 if (PROCEDUREP(method1787_1535))
			   {
			      aux_2354 = PROCEDURE_ENTRY(method1787_1535) (method1787_1535, (obj_t) (node_6), owner_7, current_8, BEOA);
			   }
			 else
			   {
			      obj_t fun1781_1529;
			      fun1781_1529 = PROCEDURE_REF(rem__env_83_globalize_new_body_146, ((long) 0));
			      aux_2354 = PROCEDURE_ENTRY(fun1781_1529) (fun1781_1529, (obj_t) (node_6), owner_7, current_8, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1793_1539;
		 }
	    }
	    return (node_t) (aux_2354);
	 }
      }
   }
}


/* _rem!1911 */ obj_t 
_rem_1911_20_globalize_new_body_146(obj_t env_2077, obj_t node_2078, obj_t owner_2079, obj_t current_2080)
{
   {
      node_t aux_2621;
      aux_2621 = rem__73_globalize_new_body_146((node_t) (node_2078), owner_2079, current_2080);
      return (obj_t) (aux_2621);
   }
}


/* rem!-default1584 */ node_t 
rem__default1584_22_globalize_new_body_146(node_t node_9, obj_t owner_10, obj_t current_11)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1912_globalize_new_body_146, (obj_t) (node_9));
}


/* _rem!-default1584 */ obj_t 
_rem__default1584_9_globalize_new_body_146(obj_t env_2081, obj_t node_2082, obj_t owner_2083, obj_t current_2084)
{
   {
      node_t aux_2628;
      aux_2628 = rem__default1584_22_globalize_new_body_146((node_t) (node_2082), owner_2083, current_2084);
      return (obj_t) (aux_2628);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_new_body_146()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_tools_speek(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_type_cache(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_ast_sexp(((long) 0), "GLOBALIZE_NEW-BODY");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_NEW-BODY");
   return module_initialization_70_globalize_node(((long) 0), "GLOBALIZE_NEW-BODY");
}
