/*===========================================================================*/
/*   (Module/eval.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t ccomp_module_module;
extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_module_eval();
static obj_t _make_eval_compiler_216_module_eval(obj_t);
extern obj_t create_struct(obj_t, long);
static bool_t _one_eval___78_module_eval;
static obj_t eval_finalizer_221_module_eval();
extern obj_t global_ast_var;
static bool_t _all_eval___198_module_eval;
extern obj_t _obj__252_type_cache;
extern bool_t bigloo_type__118_type_type(type_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t _eval_producer_136_module_eval(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_module_eval(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_glo_decl_237(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern node_t location__node_25_ast_sexp(global_t);
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
extern obj_t scnst_ast_var;
static obj_t imported_modules_init_94_module_eval();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t remember_eval_exported__63_module_eval(obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_eval();
static obj_t set_eval_types__118_module_eval(obj_t);
static obj_t _eval_exported__84_module_eval = BUNSPEC;
extern obj_t make_eval_compiler_154_module_eval();
extern global_t declare_global_svar__200_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_module_eval();
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern node_t define_primop__node_141_ast_sexp(global_t);
static obj_t eval_producer_250_module_eval(obj_t);
static obj_t arg1593_module_eval(obj_t, obj_t);
static obj_t arg1558_module_eval(obj_t);
extern obj_t make_promise_21___r4_control_features_6_9(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
static obj_t arg1473_module_eval(obj_t, obj_t, obj_t);
static obj_t arg1470_module_eval(obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
static obj_t eval_parser_66_module_eval(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t find_location_120_tools_location(obj_t);
static obj_t get_evaluated_globals_117_module_eval();
extern obj_t _lib_mode__85_engine_param;
extern node_t define_primop_ref__node_164_ast_sexp(global_t, node_t);
extern obj_t get_toplevel_unit_weight_75_module_include();
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_module_eval = BUNSPEC;
static obj_t _eval_finalizer_230_module_eval(obj_t);
static obj_t cnst_init_137_module_eval();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t user_error_location_137_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[11];

DEFINE_STATIC_PROCEDURE(proc1732_module_eval, arg1558_module_eval1745, arg1558_module_eval, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1728_module_eval, arg1470_module_eval1746, arg1470_module_eval, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1727_module_eval, arg1473_module_eval1747, arg1473_module_eval, 0L, 2);
DEFINE_STATIC_PROCEDURE(eval_finalizer_env_4_module_eval, _eval_finalizer_230_module_eval1748, _eval_finalizer_230_module_eval, 0L, 0);
DEFINE_STATIC_PROCEDURE(eval_producer_env_150_module_eval, _eval_producer_136_module_eval1749, _eval_producer_136_module_eval, 0L, 1);
DEFINE_STRING(string1738_module_eval, string1738_module_eval1750, "(IMPORT STATIC EXPORT) (#unspecified) WRITE BEGIN VOID UNIT IMPORT @ EXPORT EXPORT-ALL EVAL ", 92);
DEFINE_STRING(string1737_module_eval, string1737_module_eval1751, "Unbound variable", 16);
DEFINE_STRING(string1736_module_eval, string1736_module_eval1752, "This variable cannot be known by eval", 37);
DEFINE_STRING(string1735_module_eval, string1735_module_eval1753, "eval-init", 9);
DEFINE_STRING(string1734_module_eval, string1734_module_eval1754, "Non bigloo prototyped value can't be evaluated", 46);
DEFINE_STRING(string1733_module_eval, string1733_module_eval1755, "eval", 4);
DEFINE_STRING(string1731_module_eval, string1731_module_eval1756, "Illegal `eval clause'", 21);
DEFINE_STRING(string1729_module_eval, string1729_module_eval1757, "Illegal `eval' clause", 21);
DEFINE_STRING(string1730_module_eval, string1730_module_eval1758, "Parse error", 11);
DEFINE_EXPORT_PROCEDURE(make_eval_compiler_env_58_module_eval, _make_eval_compiler_216_module_eval1759, _make_eval_compiler_216_module_eval, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_module_eval(long checksum_1508, char *from_1509)
{
   if (CBOOL(require_initialization_114_module_eval))
     {
	require_initialization_114_module_eval = BBOOL(((bool_t) 0));
	library_modules_init_112_module_eval();
	cnst_init_137_module_eval();
	imported_modules_init_94_module_eval();
	method_init_76_module_eval();
	toplevel_init_63_module_eval();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_eval()
{
   module_initialization_70___object(((long) 0), "MODULE_EVAL");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_EVAL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_EVAL");
   module_initialization_70___r4_control_features_6_9(((long) 0), "MODULE_EVAL");
   module_initialization_70___reader(((long) 0), "MODULE_EVAL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_eval()
{
   {
      obj_t cnst_port_138_1500;
      cnst_port_138_1500 = open_input_string(string1738_module_eval);
      {
	 long i_1501;
	 i_1501 = ((long) 10);
       loop_1502:
	 {
	    bool_t test1739_1503;
	    test1739_1503 = (i_1501 == ((long) -1));
	    if (test1739_1503)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1740_1504;
		    {
		       obj_t list1741_1505;
		       {
			  obj_t arg1743_1506;
			  arg1743_1506 = BNIL;
			  list1741_1505 = MAKE_PAIR(cnst_port_138_1500, arg1743_1506);
		       }
		       arg1740_1504 = read___reader(list1741_1505);
		    }
		    CNST_TABLE_SET(i_1501, arg1740_1504);
		 }
		 {
		    int aux_1507;
		    {
		       long aux_1529;
		       aux_1529 = (i_1501 - ((long) 1));
		       aux_1507 = (int) (aux_1529);
		    }
		    {
		       long i_1532;
		       i_1532 = (long) (aux_1507);
		       i_1501 = i_1532;
		       goto loop_1502;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_eval()
{
   _eval_exported__84_module_eval = BNIL;
   _all_eval___198_module_eval = ((bool_t) 0);
   return (_one_eval___78_module_eval = ((bool_t) 0),
      BUNSPEC);
}


/* make-eval-compiler */ obj_t 
make_eval_compiler_154_module_eval()
{
   {
      obj_t arg1468_745;
      arg1468_745 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1473_1480;
	 obj_t arg1470_1481;
	 arg1473_1480 = proc1727_module_eval;
	 arg1470_1481 = proc1728_module_eval;
	 {
	    ccomp_t res1726_1320;
	    {
	       ccomp_t new1435_1311;
	       new1435_1311 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1640_1312;
		  arg1640_1312 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_1318;
		     obj_1318 = (obj_t) (new1435_1311);
		     (((obj_t) CREF(obj_1318))->header = MAKE_HEADER(arg1640_1312, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_1539;
		  aux_1539 = (object_t) (new1435_1311);
		  OBJECT_WIDENING_SET(aux_1539, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1435_1311))->id) = ((obj_t) arg1468_745), BUNSPEC);
	       ((((ccomp_t) CREF(new1435_1311))->producer) = ((obj_t) eval_producer_env_150_module_eval), BUNSPEC);
	       ((((ccomp_t) CREF(new1435_1311))->consumer) = ((obj_t) arg1470_1481), BUNSPEC);
	       ((((ccomp_t) CREF(new1435_1311))->finalizer) = ((obj_t) eval_finalizer_env_4_module_eval), BUNSPEC);
	       ((((ccomp_t) CREF(new1435_1311))->checksummer) = ((obj_t) arg1473_1480), BUNSPEC);
	       res1726_1320 = new1435_1311;
	    }
	    return (obj_t) (res1726_1320);
	 }
      }
   }
}


/* _make-eval-compiler */ obj_t 
_make_eval_compiler_216_module_eval(obj_t env_1482)
{
   return make_eval_compiler_154_module_eval();
}


/* arg1473 */ obj_t 
arg1473_module_eval(obj_t env_1483, obj_t m_1484, obj_t c_1485)
{
   {
      obj_t m_753;
      obj_t c_754;
      m_753 = m_1484;
      c_754 = c_1485;
      return c_754;
   }
}


/* arg1470 */ obj_t 
arg1470_module_eval(obj_t env_1486, obj_t m_1487, obj_t c_1488)
{
   {
      obj_t m_750;
      obj_t c_751;
      m_750 = m_1487;
      c_751 = c_1488;
      return BNIL;
   }
}


/* eval-producer */ obj_t 
eval_producer_250_module_eval(obj_t clause_19)
{
   {
      obj_t protos_758;
      if (PAIRP(clause_19))
	{
	   protos_758 = CDR(clause_19);
	   {
	      obj_t l1444_764;
	      l1444_764 = protos_758;
	    lname1445_765:
	      if (PAIRP(l1444_764))
		{
		   eval_parser_66_module_eval(CAR(l1444_764), clause_19);
		   {
		      obj_t l1444_1555;
		      l1444_1555 = CDR(l1444_764);
		      l1444_764 = l1444_1555;
		      goto lname1445_765;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return BNIL;
	}
      else
	{
	   {
	      obj_t arg1481_770;
	      {
		 obj_t list1486_774;
		 list1486_774 = MAKE_PAIR(string1729_module_eval, BNIL);
		 arg1481_770 = string_append_106___r4_strings_6_7(list1486_774);
	      }
	      {
		 obj_t list1484_772;
		 list1484_772 = MAKE_PAIR(BNIL, BNIL);
		 return user_error_151_tools_error(string1730_module_eval, arg1481_770, clause_19, list1484_772);
	      }
	   }
	}
   }
}


/* _eval-producer */ obj_t 
_eval_producer_136_module_eval(obj_t env_1489, obj_t clause_1490)
{
   return eval_producer_250_module_eval(clause_1490);
}


/* eval-parser */ obj_t 
eval_parser_66_module_eval(obj_t proto_20, obj_t clause_21)
{
   {
      if (PAIRP(proto_20))
	{
	   bool_t test_1565;
	   {
	      obj_t aux_1568;
	      obj_t aux_1566;
	      aux_1568 = CNST_TABLE_REF(((long) 1));
	      aux_1566 = CAR(proto_20);
	      test_1565 = (aux_1566 == aux_1568);
	   }
	   if (test_1565)
	     {
		bool_t test_1571;
		{
		   obj_t aux_1572;
		   aux_1572 = CDR(proto_20);
		   test_1571 = (aux_1572 == BNIL);
		}
		if (test_1571)
		  {
		     return (_all_eval___198_module_eval = ((bool_t) 1),
			BUNSPEC);
		  }
		else
		  {
		   tag_113_246_785:
		     {
			obj_t list1536_839;
			list1536_839 = MAKE_PAIR(BNIL, BNIL);
			return user_error_151_tools_error(string1730_module_eval, string1731_module_eval, clause_21, list1536_839);
		     }
		  }
	     }
	   else
	     {
		obj_t cdr_132_143_792;
		cdr_132_143_792 = CDR(proto_20);
		{
		   bool_t test_1578;
		   {
		      obj_t aux_1581;
		      obj_t aux_1579;
		      aux_1581 = CNST_TABLE_REF(((long) 2));
		      aux_1579 = CAR(proto_20);
		      test_1578 = (aux_1579 == aux_1581);
		   }
		   if (test_1578)
		     {
			if (PAIRP(cdr_132_143_792))
			  {
			     obj_t car_134_159_795;
			     car_134_159_795 = CAR(cdr_132_143_792);
			     if (SYMBOLP(car_134_159_795))
			       {
				  bool_t test_1589;
				  {
				     obj_t aux_1590;
				     aux_1590 = CDR(cdr_132_143_792);
				     test_1589 = (aux_1590 == BNIL);
				  }
				  if (test_1589)
				    {
				       _one_eval___78_module_eval = ((bool_t) 1);
				       return remember_eval_exported__63_module_eval(car_134_159_795, _module__166_module_module, proto_20);
				    }
				  else
				    {
				       goto tag_113_246_785;
				    }
			       }
			     else
			       {
				  obj_t car_153_175_801;
				  car_153_175_801 = CAR(cdr_132_143_792);
				  if (PAIRP(car_153_175_801))
				    {
				       obj_t cdr_158_238_803;
				       cdr_158_238_803 = CDR(car_153_175_801);
				       {
					  bool_t test_1598;
					  {
					     obj_t aux_1601;
					     obj_t aux_1599;
					     aux_1601 = CNST_TABLE_REF(((long) 3));
					     aux_1599 = CAR(car_153_175_801);
					     test_1598 = (aux_1599 == aux_1601);
					  }
					  if (test_1598)
					    {
					       if (PAIRP(cdr_158_238_803))
						 {
						    obj_t car_161_104_806;
						    obj_t cdr_162_110_807;
						    car_161_104_806 = CAR(cdr_158_238_803);
						    cdr_162_110_807 = CDR(cdr_158_238_803);
						    if (SYMBOLP(car_161_104_806))
						      {
							 if (PAIRP(cdr_162_110_807))
							   {
							      obj_t car_167_57_810;
							      car_167_57_810 = CAR(cdr_162_110_807);
							      if (SYMBOLP(car_167_57_810))
								{
								   bool_t test_1615;
								   {
								      obj_t aux_1616;
								      aux_1616 = CDR(cdr_162_110_807);
								      test_1615 = (aux_1616 == BNIL);
								   }
								   if (test_1615)
								     {
									bool_t test_1619;
									{
									   obj_t aux_1620;
									   aux_1620 = CDR(cdr_132_143_792);
									   test_1619 = (aux_1620 == BNIL);
									}
									if (test_1619)
									  {
									     _one_eval___78_module_eval = ((bool_t) 1);
									     return remember_eval_exported__63_module_eval(car_161_104_806, car_167_57_810, proto_20);
									  }
									else
									  {
									     goto tag_113_246_785;
									  }
								     }
								   else
								     {
									goto tag_113_246_785;
								     }
								}
							      else
								{
								   goto tag_113_246_785;
								}
							   }
							 else
							   {
							      goto tag_113_246_785;
							   }
						      }
						    else
						      {
							 goto tag_113_246_785;
						      }
						 }
					       else
						 {
						    goto tag_113_246_785;
						 }
					    }
					  else
					    {
					       goto tag_113_246_785;
					    }
				       }
				    }
				  else
				    {
				       goto tag_113_246_785;
				    }
			       }
			  }
			else
			  {
			     goto tag_113_246_785;
			  }
		     }
		   else
		     {
			bool_t test_1624;
			{
			   obj_t aux_1627;
			   obj_t aux_1625;
			   aux_1627 = CNST_TABLE_REF(((long) 4));
			   aux_1625 = CAR(proto_20);
			   test_1624 = (aux_1625 == aux_1627);
			}
			if (test_1624)
			  {
			     if (PAIRP(cdr_132_143_792))
			       {
				  obj_t car_203_140_823;
				  car_203_140_823 = CAR(cdr_132_143_792);
				  if (SYMBOLP(car_203_140_823))
				    {
				       bool_t test_1635;
				       {
					  obj_t aux_1636;
					  aux_1636 = CDR(cdr_132_143_792);
					  test_1635 = (aux_1636 == BNIL);
				       }
				       if (test_1635)
					 {
					    global_t aux_1639;
					    aux_1639 = declare_global_svar__200_ast_glo_decl_237(car_203_140_823, CNST_TABLE_REF(((long) 0)), CNST_TABLE_REF(((long) 0)), clause_21);
					    return (obj_t) (aux_1639);
					 }
				       else
					 {
					    goto tag_113_246_785;
					 }
				    }
				  else
				    {
				       goto tag_113_246_785;
				    }
			       }
			     else
			       {
				  goto tag_113_246_785;
			       }
			  }
			else
			  {
			     goto tag_113_246_785;
			  }
		     }
		}
	     }
	}
      else
	{
	   goto tag_113_246_785;
	}
   }
}


/* remember-eval-exported! */ obj_t 
remember_eval_exported__63_module_eval(obj_t var_22, obj_t module_23, obj_t loc_24)
{
   {
      obj_t arg1539_841;
      {
	 obj_t list1540_842;
	 {
	    obj_t arg1542_843;
	    {
	       obj_t arg1545_844;
	       arg1545_844 = MAKE_PAIR(loc_24, BNIL);
	       arg1542_843 = MAKE_PAIR(module_23, arg1545_844);
	    }
	    list1540_842 = MAKE_PAIR(var_22, arg1542_843);
	 }
	 arg1539_841 = list1540_842;
      }
      {
	 obj_t obj2_1383;
	 obj2_1383 = _eval_exported__84_module_eval;
	 return (_eval_exported__84_module_eval = MAKE_PAIR(arg1539_841, obj2_1383),
	    BUNSPEC);
      }
   }
}


/* eval-finalizer */ obj_t 
eval_finalizer_221_module_eval()
{
   {
      bool_t test1549_846;
      if (_one_eval___78_module_eval)
	{
	   test1549_846 = ((bool_t) 1);
	}
      else
	{
	   test1549_846 = _all_eval___198_module_eval;
	}
      if (test1549_846)
	{
	   obj_t arg1550_847;
	   {
	      obj_t arg1553_850;
	      long arg1554_851;
	      obj_t arg1555_852;
	      arg1553_850 = CNST_TABLE_REF(((long) 0));
	      {
		 obj_t arg1556_853;
		 arg1556_853 = get_toplevel_unit_weight_75_module_include();
		 {
		    long aux_1652;
		    aux_1652 = (long) CINT(arg1556_853);
		    arg1554_851 = (aux_1652 - ((long) 2));
		 }
	      }
	      {
		 obj_t arg1558_1492;
		 arg1558_1492 = proc1732_module_eval;
		 arg1555_852 = make_promise_21___r4_control_features_6_9(arg1558_1492);
	      }
	      {
		 obj_t new_1401;
		 {
		    obj_t aux_1656;
		    aux_1656 = CNST_TABLE_REF(((long) 5));
		    new_1401 = create_struct(aux_1656, ((long) 4));
		 }
		 STRUCT_SET(new_1401, ((long) 3), BFALSE);
		 STRUCT_SET(new_1401, ((long) 2), arg1555_852);
		 {
		    obj_t aux_1661;
		    aux_1661 = BINT(arg1554_851);
		    STRUCT_SET(new_1401, ((long) 1), aux_1661);
		 }
		 STRUCT_SET(new_1401, ((long) 0), arg1553_850);
		 arg1550_847 = new_1401;
	      }
	   }
	   {
	      obj_t list1551_848;
	      list1551_848 = MAKE_PAIR(arg1550_847, BNIL);
	      return list1551_848;
	   }
	}
      else
	{
	   return CNST_TABLE_REF(((long) 6));
	}
   }
}


/* _eval-finalizer */ obj_t 
_eval_finalizer_230_module_eval(obj_t env_1491)
{
   return eval_finalizer_221_module_eval();
}


/* arg1558 */ obj_t 
arg1558_module_eval(obj_t env_1493)
{
   {
      {
	 obj_t globals_857;
	 obj_t init__202_858;
	 {
	    obj_t arg1560_860;
	    obj_t arg1561_861;
	    arg1560_860 = get_evaluated_globals_117_module_eval();
	    arg1561_861 = CNST_TABLE_REF(((long) 9));
	    globals_857 = arg1560_860;
	    init__202_858 = arg1561_861;
	  loop_859:
	    if (NULLP(globals_857))
	      {
		 obj_t arg1563_863;
		 obj_t arg1564_864;
		 arg1563_863 = CNST_TABLE_REF(((long) 7));
		 {
		    obj_t arg1568_867;
		    obj_t arg1569_868;
		    arg1568_867 = reverse__39___r4_pairs_and_lists_6_3(init__202_858);
		    arg1569_868 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		    arg1564_864 = append_2_18___r4_pairs_and_lists_6_3(arg1568_867, arg1569_868);
		 }
		 {
		    obj_t list1565_865;
		    list1565_865 = MAKE_PAIR(arg1564_864, BNIL);
		    return cons__138___r4_pairs_and_lists_6_3(arg1563_863, list1565_865);
		 }
	      }
	    else
	      {
		 obj_t g_871;
		 g_871 = CAR(globals_857);
		 set_eval_types__118_module_eval(g_871);
		 {
		    obj_t arg1572_872;
		    obj_t arg1573_873;
		    arg1572_872 = CDR(globals_857);
		    {
		       node_t arg1575_874;
		       {
			  bool_t test1576_875;
			  {
			     obj_t aux_1681;
			     {
				value_t aux_1682;
				{
				   global_t obj_1389;
				   obj_1389 = (global_t) (g_871);
				   aux_1682 = (((global_t) CREF(obj_1389))->value);
				}
				aux_1681 = (obj_t) (aux_1682);
			     }
			     test1576_875 = is_a__118___object(aux_1681, svar_ast_var);
			  }
			  if (test1576_875)
			    {
			       {
				  obj_t arg1578_876;
				  arg1578_876 = CNST_TABLE_REF(((long) 8));
				  {
				     variable_t obj_1391;
				     obj_1391 = (variable_t) (g_871);
				     ((((variable_t) CREF(obj_1391))->access) = ((obj_t) arg1578_876), BUNSPEC);
				  }
			       }
			       {
				  node_t arg1580_877;
				  arg1580_877 = location__node_25_ast_sexp((global_t) (g_871));
				  arg1575_874 = define_primop_ref__node_164_ast_sexp((global_t) (g_871), arg1580_877);
			       }
			    }
			  else
			    {
			       bool_t test1581_878;
			       {
				  obj_t aux_1695;
				  {
				     value_t aux_1696;
				     {
					global_t obj_1393;
					obj_1393 = (global_t) (g_871);
					aux_1696 = (((global_t) CREF(obj_1393))->value);
				     }
				     aux_1695 = (obj_t) (aux_1696);
				  }
				  test1581_878 = is_a__118___object(aux_1695, scnst_ast_var);
			       }
			       if (test1581_878)
				 {
				    {
				       node_t arg1582_879;
				       arg1582_879 = location__node_25_ast_sexp((global_t) (g_871));
				       arg1575_874 = define_primop_ref__node_164_ast_sexp((global_t) (g_871), arg1582_879);
				    }
				 }
			       else
				 {
				    arg1575_874 = define_primop__node_141_ast_sexp((global_t) (g_871));
				 }
			    }
		       }
		       {
			  obj_t aux_1708;
			  aux_1708 = (obj_t) (arg1575_874);
			  arg1573_873 = MAKE_PAIR(aux_1708, init__202_858);
		       }
		    }
		    {
		       obj_t init__202_1712;
		       obj_t globals_1711;
		       globals_1711 = arg1572_872;
		       init__202_1712 = arg1573_873;
		       init__202_858 = init__202_1712;
		       globals_857 = globals_1711;
		       goto loop_859;
		    }
		 }
	      }
	 }
      }
   }
}


/* set-eval-types! */ obj_t 
set_eval_types__118_module_eval(obj_t global_25)
{
   {
      bool_t test1585_884;
      {
	 obj_t aux_1713;
	 {
	    value_t aux_1714;
	    {
	       global_t obj_1425;
	       obj_1425 = (global_t) (global_25);
	       aux_1714 = (((global_t) CREF(obj_1425))->value);
	    }
	    aux_1713 = (obj_t) (aux_1714);
	 }
	 test1585_884 = is_a__118___object(aux_1713, sfun_ast_var);
      }
      if (test1585_884)
	{
	   return BUNSPEC;
	}
      else
	{
	   type_t type_885;
	   {
	      global_t obj_1427;
	      obj_1427 = (global_t) (global_25);
	      type_885 = (((global_t) CREF(obj_1427))->type);
	   }
	   {
	      bool_t test1586_886;
	      {
		 obj_t obj2_1429;
		 obj2_1429 = ____74_type_cache;
		 {
		    obj_t aux_1722;
		    aux_1722 = (obj_t) (type_885);
		    test1586_886 = (aux_1722 == obj2_1429);
		 }
	      }
	      if (test1586_886)
		{
		   {
		      global_t obj_1430;
		      type_t val1067_1431;
		      obj_1430 = (global_t) (global_25);
		      val1067_1431 = (type_t) (_obj__252_type_cache);
		      return ((((global_t) CREF(obj_1430))->type) = ((type_t) val1067_1431), BUNSPEC);
		   }
		}
	      else
		{
		   bool_t test1587_887;
		   test1587_887 = bigloo_type__118_type_type(type_885);
		   if (test1587_887)
		     {
			return BFALSE;
		     }
		   else
		     {
			{
			   obj_t aux_1731;
			   {
			      global_t obj_1432;
			      obj_1432 = (global_t) (global_25);
			      aux_1731 = (((global_t) CREF(obj_1432))->id);
			   }
			   FAILURE(string1733_module_eval, string1734_module_eval, aux_1731);
			}
		     }
		}
	   }
	}
   }
}


/* get-evaluated-globals */ obj_t 
get_evaluated_globals_117_module_eval()
{
   if (_all_eval___198_module_eval)
     {
	obj_t globals_891;
	globals_891 = MAKE_CELL(BNIL);
	{
	   obj_t arg1593_1494;
	   arg1593_1494 = make_fx_procedure(arg1593_module_eval, ((long) 1), ((long) 1));
	   PROCEDURE_SET(arg1593_1494, ((long) 0), globals_891);
	   for_each_global__88_ast_env(arg1593_1494);
	}
	return CELL_REF(globals_891);
     }
   else
     {
	obj_t eval_exported_68_903;
	obj_t res_904;
	eval_exported_68_903 = _eval_exported__84_module_eval;
	res_904 = BNIL;
      loop_905:
	if (NULLP(eval_exported_68_903))
	  {
	     return res_904;
	  }
	else
	  {
	     obj_t var_module_pos_214_908;
	     var_module_pos_214_908 = CAR(eval_exported_68_903);
	     {
		obj_t g_909;
		{
		   obj_t arg1634_934;
		   arg1634_934 = CAR(var_module_pos_214_908);
		   {
		      obj_t list1637_936;
		      {
			 obj_t aux_1743;
			 {
			    obj_t aux_1744;
			    aux_1744 = CDR(var_module_pos_214_908);
			    aux_1743 = CAR(aux_1744);
			 }
			 list1637_936 = MAKE_PAIR(aux_1743, BNIL);
		      }
		      g_909 = find_global_223_ast_env(arg1634_934, list1637_936);
		   }
		}
		{
		   bool_t test1605_910;
		   test1605_910 = is_a__118___object(g_909, global_ast_var);
		   if (test1605_910)
		     {
			bool_t test1606_911;
			if (CBOOL(_lib_mode__85_engine_param))
			  {
			     test1606_911 = ((bool_t) 0);
			  }
			else
			  {
			     global_t obj_1449;
			     obj_1449 = (global_t) (g_909);
			     test1606_911 = (((global_t) CREF(obj_1449))->library__255);
			  }
			if (test1606_911)
			  {
			     {
				obj_t eval_exported_68_1756;
				eval_exported_68_1756 = CDR(eval_exported_68_903);
				eval_exported_68_903 = eval_exported_68_1756;
				goto loop_905;
			     }
			  }
			else
			  {
			     bool_t test_1758;
			     {
				global_t obj_1451;
				obj_1451 = (global_t) (g_909);
				test_1758 = (((global_t) CREF(obj_1451))->evaluable__248);
			     }
			     if (test_1758)
			       {
				  {
				     obj_t arg1609_914;
				     obj_t arg1610_915;
				     arg1609_914 = CDR(eval_exported_68_903);
				     arg1610_915 = MAKE_PAIR(g_909, res_904);
				     {
					obj_t res_1764;
					obj_t eval_exported_68_1763;
					eval_exported_68_1763 = arg1609_914;
					res_1764 = arg1610_915;
					res_904 = res_1764;
					eval_exported_68_903 = eval_exported_68_1763;
					goto loop_905;
				     }
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1612_916;
				     obj_t arg1617_919;
				     {
					obj_t aux_1765;
					{
					   obj_t aux_1766;
					   {
					      obj_t aux_1767;
					      aux_1767 = CDR(var_module_pos_214_908);
					      aux_1766 = CDR(aux_1767);
					   }
					   aux_1765 = CAR(aux_1766);
					}
					arg1612_916 = find_location_120_tools_location(aux_1765);
				     }
				     arg1617_919 = CAR(var_module_pos_214_908);
				     {
					obj_t list1619_921;
					list1619_921 = MAKE_PAIR(BNIL, BNIL);
					user_error_location_137_tools_error(arg1612_916, string1735_module_eval, string1736_module_eval, arg1617_919, list1619_921);
				     }
				  }
				  {
				     obj_t eval_exported_68_1775;
				     eval_exported_68_1775 = CDR(eval_exported_68_903);
				     eval_exported_68_903 = eval_exported_68_1775;
				     goto loop_905;
				  }
			       }
			  }
		     }
		   else
		     {
			{
			   obj_t arg1623_925;
			   obj_t arg1627_928;
			   {
			      obj_t aux_1777;
			      {
				 obj_t aux_1778;
				 {
				    obj_t aux_1779;
				    aux_1779 = CDR(var_module_pos_214_908);
				    aux_1778 = CDR(aux_1779);
				 }
				 aux_1777 = CAR(aux_1778);
			      }
			      arg1623_925 = find_location_120_tools_location(aux_1777);
			   }
			   arg1627_928 = CAR(var_module_pos_214_908);
			   {
			      obj_t list1629_930;
			      list1629_930 = MAKE_PAIR(BNIL, BNIL);
			      user_error_location_137_tools_error(arg1623_925, string1735_module_eval, string1737_module_eval, arg1627_928, list1629_930);
			   }
			}
			{
			   obj_t eval_exported_68_1787;
			   eval_exported_68_1787 = CDR(eval_exported_68_903);
			   eval_exported_68_903 = eval_exported_68_1787;
			   goto loop_905;
			}
		     }
		}
	     }
	  }
     }
}


/* arg1593 */ obj_t 
arg1593_module_eval(obj_t env_1495, obj_t g_1497)
{
   {
      obj_t globals_1496;
      globals_1496 = PROCEDURE_REF(env_1495, ((long) 0));
      {
	 obj_t g_893;
	 g_893 = g_1497;
	 {
	    bool_t test1595_895;
	    {
	       bool_t test_1790;
	       {
		  obj_t aux_1791;
		  {
		     obj_t aux_1792;
		     {
			global_t obj_1436;
			obj_1436 = (global_t) (g_893);
			aux_1792 = (((global_t) CREF(obj_1436))->import);
		     }
		     aux_1791 = memq___r4_pairs_and_lists_6_3(aux_1792, CNST_TABLE_REF(((long) 10)));
		  }
		  test_1790 = CBOOL(aux_1791);
	       }
	       if (test_1790)
		 {
		    bool_t test_1798;
		    {
		       global_t obj_1437;
		       obj_1437 = (global_t) (g_893);
		       test_1798 = (((global_t) CREF(obj_1437))->evaluable__248);
		    }
		    if (test_1798)
		      {
			 obj_t _ortest_1446_898;
			 _ortest_1446_898 = _lib_mode__85_engine_param;
			 if (CBOOL(_ortest_1446_898))
			   {
			      test1595_895 = CBOOL(_ortest_1446_898);
			   }
			 else
			   {
			      bool_t test_1804;
			      {
				 global_t obj_1438;
				 obj_1438 = (global_t) (g_893);
				 test_1804 = (((global_t) CREF(obj_1438))->library__255);
			      }
			      if (test_1804)
				{
				   test1595_895 = ((bool_t) 0);
				}
			      else
				{
				   test1595_895 = ((bool_t) 1);
				}
			   }
		      }
		    else
		      {
			 test1595_895 = ((bool_t) 0);
		      }
		 }
	       else
		 {
		    test1595_895 = ((bool_t) 0);
		 }
	    }
	    if (test1595_895)
	      {
		 obj_t aux_1498;
		 {
		    obj_t obj2_1440;
		    obj2_1440 = CELL_REF(globals_1496);
		    aux_1498 = MAKE_PAIR(g_893, obj2_1440);
		 }
		 return CELL_SET(globals_1496, aux_1498);
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_module_eval()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_eval()
{
   module_initialization_70_type_type(((long) 0), "MODULE_EVAL");
   module_initialization_70_ast_var(((long) 0), "MODULE_EVAL");
   module_initialization_70_ast_node(((long) 0), "MODULE_EVAL");
   module_initialization_70_module_module(((long) 0), "MODULE_EVAL");
   module_initialization_70_module_include(((long) 0), "MODULE_EVAL");
   module_initialization_70_engine_param(((long) 0), "MODULE_EVAL");
   module_initialization_70_tools_shape(((long) 0), "MODULE_EVAL");
   module_initialization_70_tools_error(((long) 0), "MODULE_EVAL");
   module_initialization_70_tools_location(((long) 0), "MODULE_EVAL");
   module_initialization_70_type_cache(((long) 0), "MODULE_EVAL");
   module_initialization_70_ast_env(((long) 0), "MODULE_EVAL");
   module_initialization_70_ast_glo_decl_237(((long) 0), "MODULE_EVAL");
   return module_initialization_70_ast_sexp(((long) 0), "MODULE_EVAL");
}
