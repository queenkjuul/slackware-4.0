/*===========================================================================*/
/*   (Module/library.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_module_library();
extern obj_t get_imported_modules_153_module_impuse();
extern obj_t create_struct(obj_t, long);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t gensym___r4_symbols_6_4;
static obj_t _needed_modules__74_module_library = BUNSPEC;
extern obj_t module_initialization_70_module_library(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_bdb_setting(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t need_library_module__2_module_library(obj_t);
extern obj_t _bdb_module__96_bdb_setting;
extern obj_t module_initialization_id_110_module_module(obj_t);
static obj_t imported_modules_init_94_module_library();
static obj_t _library_finalizer_48_module_library(obj_t);
static obj_t library_modules_init_112_module_library();
extern obj_t library_finalizer_97_module_library();
static obj_t toplevel_init_63_module_library();
extern obj_t open_input_string(obj_t);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
static obj_t arg1216_module_library(obj_t, obj_t);
static obj_t _key__82_module_library = BUNSPEC;
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_module_library = BUNSPEC;
static obj_t cnst_init_137_module_library();
static obj_t __cnst[5];

DEFINE_STATIC_PROCEDURE(proc1289_module_library, arg1216_module_library1296, arg1216_module_library, 0L, 1);
DEFINE_EXPORT_PROCEDURE(library_finalizer_env_247_module_library, _library_finalizer_48_module_library1297, _library_finalizer_48_module_library, 0L, 0);
DEFINE_STRING(string1290_module_library, string1290_module_library1298, "(#unspecified) @ UNIT LIBRARY-MODULES FOREIGN ", 46);


/* module-initialization */ obj_t 
module_initialization_70_module_library(long checksum_625, char *from_626)
{
   if (CBOOL(require_initialization_114_module_library))
     {
	require_initialization_114_module_library = BBOOL(((bool_t) 0));
	library_modules_init_112_module_library();
	cnst_init_137_module_library();
	imported_modules_init_94_module_library();
	method_init_76_module_library();
	toplevel_init_63_module_library();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_library()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "MODULE_LIBRARY");
   module_initialization_70___reader(((long) 0), "MODULE_LIBRARY");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_LIBRARY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_library()
{
   {
      obj_t cnst_port_138_617;
      cnst_port_138_617 = open_input_string(string1290_module_library);
      {
	 long i_618;
	 i_618 = ((long) 4);
       loop_619:
	 {
	    bool_t test1291_620;
	    test1291_620 = (i_618 == ((long) -1));
	    if (test1291_620)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1292_621;
		    {
		       obj_t list1293_622;
		       {
			  obj_t arg1294_623;
			  arg1294_623 = BNIL;
			  list1293_622 = MAKE_PAIR(cnst_port_138_617, arg1294_623);
		       }
		       arg1292_621 = read___reader(list1293_622);
		    }
		    CNST_TABLE_SET(i_618, arg1292_621);
		 }
		 {
		    int aux_624;
		    {
		       long aux_644;
		       aux_644 = (i_618 - ((long) 1));
		       aux_624 = (int) (aux_644);
		    }
		    {
		       long i_647;
		       i_647 = (long) (aux_624);
		       i_618 = i_647;
		       goto loop_619;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_library()
{
   _needed_modules__74_module_library = BNIL;
   return (_key__82_module_library = BUNSPEC,
      BUNSPEC);
}


/* library-finalizer */ obj_t 
library_finalizer_97_module_library()
{
   _key__82_module_library = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, BEOA);
   {
      obj_t l1190_348;
      {
	 obj_t arg1210_350;
	 arg1210_350 = get_imported_modules_153_module_impuse();
	 l1190_348 = arg1210_350;
       lname1191_349:
	 if (PAIRP(l1190_348))
	   {
	      putprop__88___r4_symbols_6_4(CAR(l1190_348), _key__82_module_library, BTRUE);
	      {
		 obj_t l1190_656;
		 l1190_656 = CDR(l1190_348);
		 l1190_348 = l1190_656;
		 goto lname1191_349;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   putprop__88___r4_symbols_6_4(CNST_TABLE_REF(((long) 0)), _key__82_module_library, BTRUE);
   putprop__88___r4_symbols_6_4(_module__166_module_module, _key__82_module_library, BTRUE);
   {
      obj_t arg1216_612;
      arg1216_612 = proc1289_module_library;
      for_each_global__88_ast_env(arg1216_612);
   }
   {
      bool_t test1223_364;
      {
	 long n1_574;
	 n1_574 = (long) CINT(_bdb_debug__1_engine_param);
	 test1223_364 = (n1_574 > ((long) 0));
      }
      if (test1223_364)
	{
	   need_library_module__2_module_library(_bdb_module__96_bdb_setting);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t modules_365;
      modules_365 = _needed_modules__74_module_library;
      if (NULLP(modules_365))
	{
	   return BNIL;
	}
      else
	{
	   obj_t modules_367;
	   obj_t init_call__93_368;
	   modules_367 = modules_365;
	   init_call__93_368 = CNST_TABLE_REF(((long) 4));
	 loop_369:
	   if (NULLP(modules_367))
	     {
		obj_t arg1228_372;
		arg1228_372 = CNST_TABLE_REF(((long) 1));
		{
		   obj_t new_582;
		   {
		      obj_t aux_671;
		      aux_671 = CNST_TABLE_REF(((long) 2));
		      new_582 = create_struct(aux_671, ((long) 4));
		   }
		   STRUCT_SET(new_582, ((long) 3), BTRUE);
		   STRUCT_SET(new_582, ((long) 2), init_call__93_368);
		   {
		      obj_t aux_676;
		      aux_676 = BINT(((long) 2));
		      STRUCT_SET(new_582, ((long) 1), aux_676);
		   }
		   STRUCT_SET(new_582, ((long) 0), arg1228_372);
		   return new_582;
		}
	     }
	   else
	     {
		obj_t id_374;
		id_374 = CAR(modules_367);
		{
		   obj_t init_fun_id_230_375;
		   init_fun_id_230_375 = module_initialization_id_110_module_module(id_374);
		   {
		      {
			 obj_t arg1232_376;
			 obj_t arg1233_377;
			 arg1232_376 = CDR(modules_367);
			 {
			    obj_t arg1234_378;
			    {
			       obj_t arg1235_379;
			       obj_t arg1238_381;
			       {
				  obj_t arg1247_387;
				  arg1247_387 = CNST_TABLE_REF(((long) 3));
				  {
				     obj_t list1249_389;
				     {
					obj_t arg1250_390;
					{
					   obj_t arg1251_391;
					   arg1251_391 = MAKE_PAIR(BNIL, BNIL);
					   arg1250_390 = MAKE_PAIR(id_374, arg1251_391);
					}
					list1249_389 = MAKE_PAIR(init_fun_id_230_375, arg1250_390);
				     }
				     arg1235_379 = cons__138___r4_pairs_and_lists_6_3(arg1247_387, list1249_389);
				  }
			       }
			       {
				  obj_t symbol_607;
				  symbol_607 = _module__166_module_module;
				  arg1238_381 = SYMBOL_TO_STRING(symbol_607);
			       }
			       {
				  obj_t list1241_383;
				  {
				     obj_t arg1243_384;
				     {
					obj_t arg1244_385;
					arg1244_385 = MAKE_PAIR(BNIL, BNIL);
					arg1243_384 = MAKE_PAIR(arg1238_381, arg1244_385);
				     }
				     {
					obj_t aux_691;
					aux_691 = BINT(((long) 0));
					list1241_383 = MAKE_PAIR(aux_691, arg1243_384);
				     }
				  }
				  arg1234_378 = cons__138___r4_pairs_and_lists_6_3(arg1235_379, list1241_383);
			       }
			    }
			    arg1233_377 = MAKE_PAIR(arg1234_378, init_call__93_368);
			 }
			 {
			    obj_t init_call__93_697;
			    obj_t modules_696;
			    modules_696 = arg1232_376;
			    init_call__93_697 = arg1233_377;
			    init_call__93_368 = init_call__93_697;
			    modules_367 = modules_696;
			    goto loop_369;
			 }
		      }
		   }
		}
	     }
	}
   }
}


/* _library-finalizer */ obj_t 
_library_finalizer_48_module_library(obj_t env_613)
{
   return library_finalizer_97_module_library();
}


/* arg1216 */ obj_t 
arg1216_module_library(obj_t env_614, obj_t global_615)
{
   {
      obj_t global_356;
      global_356 = global_615;
      {
	 bool_t test_700;
	 {
	    bool_t test_701;
	    {
	       long aux_702;
	       {
		  global_t obj_569;
		  obj_569 = (global_t) (global_356);
		  aux_702 = (((global_t) CREF(obj_569))->occurrence);
	       }
	       test_701 = (aux_702 > ((long) 0));
	    }
	    if (test_701)
	      {
		 global_t obj_572;
		 obj_572 = (global_t) (global_356);
		 test_700 = (((global_t) CREF(obj_572))->library__255);
	      }
	    else
	      {
		 test_700 = ((bool_t) 0);
	      }
	 }
	 if (test_700)
	   {
	      obj_t aux_708;
	      {
		 global_t obj_573;
		 obj_573 = (global_t) (global_356);
		 aux_708 = (((global_t) CREF(obj_573))->module);
	      }
	      return need_library_module__2_module_library(aux_708);
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* need-library-module! */ obj_t 
need_library_module__2_module_library(obj_t module_19)
{
   {
      bool_t test1253_393;
      {
	 obj_t aux_712;
	 aux_712 = getprop___r4_symbols_6_4(module_19, _key__82_module_library);
	 test1253_393 = CBOOL(aux_712);
      }
      if (test1253_393)
	{
	   return BUNSPEC;
	}
      else
	{
	   putprop__88___r4_symbols_6_4(module_19, _key__82_module_library, BTRUE);
	   {
	      obj_t obj2_611;
	      obj2_611 = _needed_modules__74_module_library;
	      return (_needed_modules__74_module_library = MAKE_PAIR(module_19, obj2_611),
		 BUNSPEC);
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_module_library()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_library()
{
   module_initialization_70_type_type(((long) 0), "MODULE_LIBRARY");
   module_initialization_70_ast_var(((long) 0), "MODULE_LIBRARY");
   module_initialization_70_ast_env(((long) 0), "MODULE_LIBRARY");
   module_initialization_70_module_module(((long) 0), "MODULE_LIBRARY");
   module_initialization_70_module_impuse(((long) 0), "MODULE_LIBRARY");
   module_initialization_70_engine_param(((long) 0), "MODULE_LIBRARY");
   return module_initialization_70_bdb_setting(((long) 0), "MODULE_LIBRARY");
}
