/*===========================================================================*/
/*   (Cfa/cfa.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_cfa();
extern obj_t box_set__cinfo_94_cfa_info;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t make_box_cinfo_127_cfa_info;
extern obj_t conditional_cinfo_212_cfa_info;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t global_loose__8_cfa_loose(global_t, approx_t);
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t set_ex_it_cinfo_168_cfa_info;
extern obj_t cvar_cinfo_53_cfa_info;
extern obj_t jump_ex_it_cinfo_139_cfa_info;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t fail_cinfo_75_cfa_info;
extern obj_t intern_sfun_cinfo_192_cfa_info;
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_app(long, char *);
extern obj_t module_initialization_70_cfa_funcall(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern obj_t select_cinfo_150_cfa_info;
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_cfa_cfa();
extern obj_t scnst_cinfo_0_cfa_info;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
extern obj_t pragma_cinfo_220_cfa_info;
static obj_t _cfa__default2106_48_cfa_cfa(obj_t, obj_t);
static obj_t library_modules_init_112_cfa_cfa();
extern approx_t cfa__102_cfa_cfa(node_t);
extern obj_t cfa_variable_value_approx_39_cfa_cfa(value_t);
extern obj_t kwote_node_102_cfa_info;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_cfa_cfa();
extern obj_t open_input_string(obj_t);
static approx_t cfa__default2106_184_cfa_cfa(node_t);
extern obj_t kwote_cinfo_48_cfa_info;
static obj_t _cfa_2499_168_cfa_cfa(obj_t, obj_t);
extern obj_t box_ref_cinfo_214_cfa_info;
static obj_t _cfa_variable_value_approx_default2112_145_cfa_cfa(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t setq_cinfo_191_cfa_info;
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
static obj_t cfa_variable_value_approx_default2112_92_cfa_cfa(value_t);
extern obj_t sexit_cinfo_49_cfa_info;
extern obj_t app_ly_cinfo_234_cfa_info;
extern obj_t svar_cinfo_166_cfa_info;
static obj_t _cfa_variable_value_approx2500_252_cfa_cfa(obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cfa_cfa = BUNSPEC;
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
static obj_t cnst_init_137_cfa_cfa();
extern obj_t atom_cinfo_155_cfa_info;
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(cfa_variable_value_approx_default2112_env_29_cfa_cfa, _cfa_variable_value_approx_default2112_145_cfa_cfa2511, _cfa_variable_value_approx_default2112_145_cfa_cfa, 0L, 1);
DEFINE_EXPORT_GENERIC(cfa__env_153_cfa_cfa, _cfa_2499_168_cfa_cfa2512, _cfa_2499_168_cfa_cfa, 0L, 1);
DEFINE_STATIC_PROCEDURE(cfa__default2106_env_161_cfa_cfa, _cfa__default2106_48_cfa_cfa2513, _cfa__default2106_48_cfa_cfa, 0L, 1);
DEFINE_STRING(string2505_cfa_cfa, string2505_cfa_cfa2514, "CFA-VARIABLE-VALUE-APPROX-DEFAULT2112 ALL ", 42);
DEFINE_STRING(string2504_cfa_cfa, string2504_cfa_cfa2515, "No method for this object", 25);
DEFINE_STRING(string2503_cfa_cfa, string2503_cfa_cfa2516, "cfa!:no method for this ast", 27);
DEFINE_STRING(string2502_cfa_cfa, string2502_cfa_cfa2517, "Unexpected closure", 18);
DEFINE_STRING(string2501_cfa_cfa, string2501_cfa_cfa2518, "cfa!", 4);
DEFINE_EXPORT_GENERIC(cfa_variable_value_approx_env_230_cfa_cfa, _cfa_variable_value_approx2500_252_cfa_cfa2519, _cfa_variable_value_approx2500_252_cfa_cfa, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_cfa_cfa(long checksum_3574, char *from_3575)
{
   if (CBOOL(require_initialization_114_cfa_cfa))
     {
	require_initialization_114_cfa_cfa = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_cfa();
	cnst_init_137_cfa_cfa();
	imported_modules_init_94_cfa_cfa();
	method_init_76_cfa_cfa();
	toplevel_init_63_cfa_cfa();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_cfa()
{
   module_initialization_70___object(((long) 0), "CFA_CFA");
   module_initialization_70___reader(((long) 0), "CFA_CFA");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_cfa()
{
   {
      obj_t cnst_port_138_3566;
      cnst_port_138_3566 = open_input_string(string2505_cfa_cfa);
      {
	 long i_3567;
	 i_3567 = ((long) 1);
       loop_3568:
	 {
	    bool_t test2506_3569;
	    test2506_3569 = (i_3567 == ((long) -1));
	    if (test2506_3569)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2507_3570;
		    {
		       obj_t list2508_3571;
		       {
			  obj_t arg2509_3572;
			  arg2509_3572 = BNIL;
			  list2508_3571 = MAKE_PAIR(cnst_port_138_3566, arg2509_3572);
		       }
		       arg2507_3570 = read___reader(list2508_3571);
		    }
		    CNST_TABLE_SET(i_3567, arg2507_3570);
		 }
		 {
		    int aux_3573;
		    {
		       long aux_3592;
		       aux_3592 = (i_3567 - ((long) 1));
		       aux_3573 = (int) (aux_3592);
		    }
		    {
		       long i_3595;
		       i_3595 = (long) (aux_3573);
		       i_3567 = i_3595;
		       goto loop_3568;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_cfa()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_cfa_cfa()
{
   add_generic__110___object(cfa__env_153_cfa_cfa, cfa__default2106_env_161_cfa_cfa);
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, atom_cinfo_155_cfa_info, ((long) 0));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, kwote_cinfo_48_cfa_info, ((long) 1));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, kwote_node_102_cfa_info, ((long) 2));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, var_ast_node, ((long) 3));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, closure_ast_node, ((long) 4));
   add_generic__110___object(cfa_variable_value_approx_env_230_cfa_cfa, cfa_variable_value_approx_default2112_env_29_cfa_cfa);
   add_inlined_method__244___object(cfa_variable_value_approx_env_230_cfa_cfa, svar_cinfo_166_cfa_info, ((long) 0));
   add_inlined_method__244___object(cfa_variable_value_approx_env_230_cfa_cfa, scnst_cinfo_0_cfa_info, ((long) 1));
   add_inlined_method__244___object(cfa_variable_value_approx_env_230_cfa_cfa, cvar_cinfo_53_cfa_info, ((long) 2));
   add_inlined_method__244___object(cfa_variable_value_approx_env_230_cfa_cfa, sexit_cinfo_49_cfa_info, ((long) 3));
   add_inlined_method__244___object(cfa_variable_value_approx_env_230_cfa_cfa, intern_sfun_cinfo_192_cfa_info, ((long) 4));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, sequence_ast_node, ((long) 5));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, app_ly_cinfo_234_cfa_info, ((long) 6));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, pragma_cinfo_220_cfa_info, ((long) 7));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, setq_cinfo_191_cfa_info, ((long) 9));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, conditional_cinfo_212_cfa_info, ((long) 10));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, fail_cinfo_75_cfa_info, ((long) 11));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, select_cinfo_150_cfa_info, ((long) 12));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, set_ex_it_cinfo_168_cfa_info, ((long) 15));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, jump_ex_it_cinfo_139_cfa_info, ((long) 16));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, make_box_cinfo_127_cfa_info, ((long) 17));
   add_inlined_method__244___object(cfa__env_153_cfa_cfa, box_set__cinfo_94_cfa_info, ((long) 18));
   {
      long aux_3623;
      aux_3623 = add_inlined_method__244___object(cfa__env_153_cfa_cfa, box_ref_cinfo_214_cfa_info, ((long) 19));
      return BINT(aux_3623);
   }
}


/* cfa! */ approx_t 
cfa__102_cfa_cfa(node_t node_1)
{
   {
      obj_t method2404_2917;
      obj_t class2409_2918;
      {
	 obj_t arg2412_2915;
	 obj_t arg2413_2916;
	 {
	    object_t obj_3417;
	    obj_3417 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_3418;
	       pre_method_105_3418 = PROCEDURE_REF(cfa__env_153_cfa_cfa, ((long) 2));
	       if (INTEGERP(pre_method_105_3418))
		 {
		    PROCEDURE_SET(cfa__env_153_cfa_cfa, ((long) 2), BUNSPEC);
		    arg2412_2915 = pre_method_105_3418;
		 }
	       else
		 {
		    long obj_class_num_177_3423;
		    obj_class_num_177_3423 = TYPE(obj_3417);
		    {
		       obj_t arg1177_3424;
		       arg1177_3424 = PROCEDURE_REF(cfa__env_153_cfa_cfa, ((long) 1));
		       {
			  long arg1178_3428;
			  {
			     long arg1179_3429;
			     arg1179_3429 = OBJECT_TYPE;
			     arg1178_3428 = (obj_class_num_177_3423 - arg1179_3429);
			  }
			  arg2412_2915 = VECTOR_REF(arg1177_3424, arg1178_3428);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3434;
	    object_3434 = (object_t) (node_1);
	    {
	       long arg1180_3435;
	       {
		  long arg1181_3436;
		  long arg1182_3437;
		  arg1181_3436 = TYPE(object_3434);
		  arg1182_3437 = OBJECT_TYPE;
		  arg1180_3435 = (arg1181_3436 - arg1182_3437);
	       }
	       {
		  obj_t vector_3441;
		  vector_3441 = _classes__134___object;
		  arg2413_2916 = VECTOR_REF(vector_3441, arg1180_3435);
	       }
	    }
	 }
	 {
	    obj_t aux_3641;
	    method2404_2917 = arg2412_2915;
	    class2409_2918 = arg2413_2916;
	    {
	       if (INTEGERP(method2404_2917))
		 {
		    switch ((long) CINT(method2404_2917))
		      {
		      case ((long) 0):
			 {
			    atom_cinfo_155_t node_2924;
			    node_2924 = (atom_cinfo_155_t) (node_1);
			    {
			       approx_t aux_3645;
			       {
				  obj_t aux_3646;
				  {
				     object_t aux_3647;
				     aux_3647 = (object_t) (node_2924);
				     aux_3646 = OBJECT_WIDENING(aux_3647);
				  }
				  aux_3645 = (((atom_cinfo_155_t) CREF(aux_3646))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3645);
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_cinfo_48_t node_2926;
			    node_2926 = (kwote_cinfo_48_t) (node_1);
			    {
			       approx_t aux_3653;
			       {
				  obj_t aux_3654;
				  {
				     object_t aux_3655;
				     aux_3655 = (object_t) (node_2926);
				     aux_3654 = OBJECT_WIDENING(aux_3655);
				  }
				  aux_3653 = (((kwote_cinfo_48_t) CREF(aux_3654))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3653);
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    kwote_node_102_t knode_2928;
			    knode_2928 = (kwote_node_102_t) (node_1);
			    {
			       approx_t aux_3661;
			       {
				  node_t aux_3662;
				  {
				     obj_t aux_3663;
				     {
					object_t aux_3664;
					aux_3664 = (object_t) (knode_2928);
					aux_3663 = OBJECT_WIDENING(aux_3664);
				     }
				     aux_3662 = (((kwote_node_102_t) CREF(aux_3663))->node);
				  }
				  aux_3661 = cfa__102_cfa_cfa(aux_3662);
			       }
			       aux_3641 = (obj_t) (aux_3661);
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    var_t node_2931;
			    node_2931 = (var_t) (node_1);
			    {
			       value_t aux_3671;
			       {
				  variable_t arg2418_2934;
				  arg2418_2934 = (((var_t) CREF(node_2931))->variable);
				  aux_3671 = (((variable_t) CREF(arg2418_2934))->value);
			       }
			       aux_3641 = cfa_variable_value_approx_39_cfa_cfa(aux_3671);
			    }
			 }
			 break;
		      case ((long) 4):
			 {
			    obj_t arg2421_2938;
			    {
			       obj_t aux_3675;
			       {
				  closure_t aux_3676;
				  aux_3676 = (closure_t) (node_1);
				  aux_3675 = (obj_t) (aux_3676);
			       }
			       arg2421_2938 = shape_tools_shape(aux_3675);
			    }
			    aux_3641 = internal_error_43_tools_error(string2501_cfa_cfa, string2502_cfa_cfa, arg2421_2938);
			 }
			 break;
		      case ((long) 5):
			 {
			    sequence_t node_2939;
			    node_2939 = (sequence_t) (node_1);
			    {
			       obj_t n_2941;
			       obj_t approx_2942;
			       n_2941 = (((sequence_t) CREF(node_2939))->nodes);
			       approx_2942 = BUNSPEC;
			     loop_2943:
			       if (NULLP(n_2941))
				 {
				    aux_3641 = approx_2942;
				 }
			       else
				 {
				    obj_t arg2424_2946;
				    approx_t arg2425_2947;
				    arg2424_2946 = CDR(n_2941);
				    {
				       node_t aux_3685;
				       {
					  obj_t aux_3686;
					  aux_3686 = CAR(n_2941);
					  aux_3685 = (node_t) (aux_3686);
				       }
				       arg2425_2947 = cfa__102_cfa_cfa(aux_3685);
				    }
				    {
				       obj_t approx_3691;
				       obj_t n_3690;
				       n_3690 = arg2424_2946;
				       approx_3691 = (obj_t) (arg2425_2947);
				       approx_2942 = approx_3691;
				       n_2941 = n_3690;
				       goto loop_2943;
				    }
				 }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    app_ly_cinfo_234_t node_2949;
			    node_2949 = (app_ly_cinfo_234_t) (node_1);
			    {
			       approx_t arg2427_2951;
			       obj_t arg2428_2952;
			       {
				  node_t aux_3695;
				  {
				     app_ly_162_t obj_3452;
				     obj_3452 = (app_ly_162_t) (node_2949);
				     aux_3695 = (((app_ly_162_t) CREF(obj_3452))->arg);
				  }
				  arg2427_2951 = cfa__102_cfa_cfa(aux_3695);
			       }
			       arg2428_2952 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2427_2951, arg2428_2952);
			    }
			    {
			       approx_t arg2430_2954;
			       obj_t arg2431_2955;
			       {
				  node_t aux_3701;
				  {
				     app_ly_162_t obj_3453;
				     obj_3453 = (app_ly_162_t) (node_2949);
				     aux_3701 = (((app_ly_162_t) CREF(obj_3453))->fun);
				  }
				  arg2430_2954 = cfa__102_cfa_cfa(aux_3701);
			       }
			       arg2431_2955 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2430_2954, arg2431_2955);
			    }
			    {
			       approx_t aux_3707;
			       {
				  obj_t aux_3708;
				  {
				     object_t aux_3709;
				     aux_3709 = (object_t) (node_2949);
				     aux_3708 = OBJECT_WIDENING(aux_3709);
				  }
				  aux_3707 = (((app_ly_cinfo_234_t) CREF(aux_3708))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3707);
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_cinfo_220_t node_2957;
			    node_2957 = (pragma_cinfo_220_t) (node_1);
			    {
			       obj_t l2089_2959;
			       {
				  pragma_t obj_3455;
				  obj_3455 = (pragma_t) (node_2957);
				  l2089_2959 = (((pragma_t) CREF(obj_3455))->args);
			       }
			     lname2090_2960:
			       if (PAIRP(l2089_2959))
				 {
				    {
				       approx_t arg2435_2964;
				       obj_t arg2436_2965;
				       {
					  node_t aux_3717;
					  {
					     obj_t aux_3718;
					     aux_3718 = CAR(l2089_2959);
					     aux_3717 = (node_t) (aux_3718);
					  }
					  arg2435_2964 = cfa__102_cfa_cfa(aux_3717);
				       }
				       arg2436_2965 = CNST_TABLE_REF(((long) 0));
				       loose__226_cfa_loose(arg2435_2964, arg2436_2965);
				    }
				    {
				       obj_t l2089_3724;
				       l2089_3724 = CDR(l2089_2959);
				       l2089_2959 = l2089_3724;
				       goto lname2090_2960;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       approx_t aux_3728;
			       {
				  obj_t aux_3729;
				  {
				     object_t aux_3730;
				     aux_3730 = (object_t) (node_2957);
				     aux_3729 = OBJECT_WIDENING(aux_3730);
				  }
				  aux_3728 = (((pragma_cinfo_220_t) CREF(aux_3729))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3728);
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_2967;
			    node_2967 = (cast_t) (node_1);
			    {
			       approx_t aux_3736;
			       aux_3736 = cfa__102_cfa_cfa((((cast_t) CREF(node_2967))->arg));
			       aux_3641 = (obj_t) (aux_3736);
			    }
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_cinfo_191_t node_2970;
			    node_2970 = (setq_cinfo_191_t) (node_1);
			    {
			       approx_t var_approx_58_2972;
			       {
				  node_t aux_3741;
				  {
				     var_t aux_3742;
				     {
					setq_t obj_3461;
					obj_3461 = (setq_t) (node_2970);
					aux_3742 = (((setq_t) CREF(obj_3461))->var);
				     }
				     aux_3741 = (node_t) (aux_3742);
				  }
				  var_approx_58_2972 = cfa__102_cfa_cfa(aux_3741);
			       }
			       {
				  approx_t val_approx_22_2973;
				  {
				     node_t aux_3747;
				     {
					setq_t obj_3462;
					obj_3462 = (setq_t) (node_2970);
					aux_3747 = (((setq_t) CREF(obj_3462))->value);
				     }
				     val_approx_22_2973 = cfa__102_cfa_cfa(aux_3747);
				  }
				  {
				     variable_t v_2974;
				     {
					var_t arg2440_2976;
					{
					   setq_t obj_3463;
					   obj_3463 = (setq_t) (node_2970);
					   arg2440_2976 = (((setq_t) CREF(obj_3463))->var);
					}
					v_2974 = (((var_t) CREF(arg2440_2976))->variable);
				     }
				     {
					union_approx__241_cfa_approx(var_approx_58_2972, val_approx_22_2973);
					{
					   bool_t test2439_2975;
					   test2439_2975 = is_a__118___object((obj_t) (v_2974), global_ast_var);
					   if (test2439_2975)
					     {
						global_loose__8_cfa_loose((global_t) (v_2974), var_approx_58_2972);
					     }
					   else
					     {
						BUNSPEC;
					     }
					}
					{
					   approx_t aux_3760;
					   {
					      obj_t aux_3761;
					      {
						 object_t aux_3762;
						 aux_3762 = (object_t) (node_2970);
						 aux_3761 = OBJECT_WIDENING(aux_3762);
					      }
					      aux_3760 = (((setq_cinfo_191_t) CREF(aux_3761))->approx);
					   }
					   aux_3641 = (obj_t) (aux_3760);
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_cinfo_212_t node_2979;
			    node_2979 = (conditional_cinfo_212_t) (node_1);
			    {
			       node_t aux_3768;
			       {
				  conditional_t obj_3467;
				  obj_3467 = (conditional_t) (node_2979);
				  aux_3768 = (((conditional_t) CREF(obj_3467))->test);
			       }
			       cfa__102_cfa_cfa(aux_3768);
			    }
			    {
			       approx_t then_approx_125_2982;
			       approx_t else_approx_184_2983;
			       {
				  node_t aux_3772;
				  {
				     conditional_t obj_3468;
				     obj_3468 = (conditional_t) (node_2979);
				     aux_3772 = (((conditional_t) CREF(obj_3468))->true);
				  }
				  then_approx_125_2982 = cfa__102_cfa_cfa(aux_3772);
			       }
			       {
				  node_t aux_3776;
				  {
				     conditional_t obj_3469;
				     obj_3469 = (conditional_t) (node_2979);
				     aux_3776 = (((conditional_t) CREF(obj_3469))->false);
				  }
				  else_approx_184_2983 = cfa__102_cfa_cfa(aux_3776);
			       }
			       {
				  approx_t aux_3780;
				  {
				     obj_t aux_3781;
				     {
					object_t aux_3782;
					aux_3782 = (object_t) (node_2979);
					aux_3781 = OBJECT_WIDENING(aux_3782);
				     }
				     aux_3780 = (((conditional_cinfo_212_t) CREF(aux_3781))->approx);
				  }
				  union_approx__241_cfa_approx(aux_3780, then_approx_125_2982);
			       }
			       {
				  approx_t aux_3787;
				  {
				     obj_t aux_3788;
				     {
					object_t aux_3789;
					aux_3789 = (object_t) (node_2979);
					aux_3788 = OBJECT_WIDENING(aux_3789);
				     }
				     aux_3787 = (((conditional_cinfo_212_t) CREF(aux_3788))->approx);
				  }
				  union_approx__241_cfa_approx(aux_3787, else_approx_184_2983);
			       }
			       {
				  approx_t aux_3794;
				  {
				     obj_t aux_3795;
				     {
					object_t aux_3796;
					aux_3796 = (object_t) (node_2979);
					aux_3795 = OBJECT_WIDENING(aux_3796);
				     }
				     aux_3794 = (((conditional_cinfo_212_t) CREF(aux_3795))->approx);
				  }
				  aux_3641 = (obj_t) (aux_3794);
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_cinfo_75_t node_2988;
			    node_2988 = (fail_cinfo_75_t) (node_1);
			    {
			       approx_t arg2448_2990;
			       obj_t arg2449_2991;
			       {
				  node_t aux_3802;
				  {
				     fail_t obj_3473;
				     obj_3473 = (fail_t) (node_2988);
				     aux_3802 = (((fail_t) CREF(obj_3473))->proc);
				  }
				  arg2448_2990 = cfa__102_cfa_cfa(aux_3802);
			       }
			       arg2449_2991 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2448_2990, arg2449_2991);
			    }
			    {
			       approx_t arg2451_2993;
			       obj_t arg2452_2994;
			       {
				  node_t aux_3808;
				  {
				     fail_t obj_3474;
				     obj_3474 = (fail_t) (node_2988);
				     aux_3808 = (((fail_t) CREF(obj_3474))->msg);
				  }
				  arg2451_2993 = cfa__102_cfa_cfa(aux_3808);
			       }
			       arg2452_2994 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2451_2993, arg2452_2994);
			    }
			    {
			       approx_t arg2454_2996;
			       obj_t arg2455_2997;
			       {
				  node_t aux_3814;
				  {
				     fail_t obj_3475;
				     obj_3475 = (fail_t) (node_2988);
				     aux_3814 = (((fail_t) CREF(obj_3475))->obj);
				  }
				  arg2454_2996 = cfa__102_cfa_cfa(aux_3814);
			       }
			       arg2455_2997 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2454_2996, arg2455_2997);
			    }
			    {
			       approx_t aux_3820;
			       {
				  obj_t aux_3821;
				  {
				     object_t aux_3822;
				     aux_3822 = (object_t) (node_2988);
				     aux_3821 = OBJECT_WIDENING(aux_3822);
				  }
				  aux_3820 = (((fail_cinfo_75_t) CREF(aux_3821))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3820);
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    select_cinfo_150_t node_2999;
			    node_2999 = (select_cinfo_150_t) (node_1);
			    {
			       node_t aux_3828;
			       {
				  select_t obj_3477;
				  obj_3477 = (select_t) (node_2999);
				  aux_3828 = (((select_t) CREF(obj_3477))->test);
			       }
			       cfa__102_cfa_cfa(aux_3828);
			    }
			    {
			       approx_t res_approx_73_3002;
			       {
				  obj_t aux_3832;
				  {
				     object_t aux_3833;
				     aux_3833 = (object_t) (node_2999);
				     aux_3832 = OBJECT_WIDENING(aux_3833);
				  }
				  res_approx_73_3002 = (((select_cinfo_150_t) CREF(aux_3832))->approx);
			       }
			       {
				  obj_t cls_3003;
				  {
				     approx_t aux_3837;
				     {
					select_t obj_3479;
					obj_3479 = (select_t) (node_2999);
					cls_3003 = (((select_t) CREF(obj_3479))->clauses);
				     }
				   loop_3004:
				     if (NULLP(cls_3003))
				       {
					  aux_3837 = res_approx_73_3002;
				       }
				     else
				       {
					  approx_t new_approx_178_3007;
					  {
					     node_t aux_3840;
					     {
						obj_t aux_3841;
						{
						   obj_t aux_3842;
						   aux_3842 = CAR(cls_3003);
						   aux_3841 = CDR(aux_3842);
						}
						aux_3840 = (node_t) (aux_3841);
					     }
					     new_approx_178_3007 = cfa__102_cfa_cfa(aux_3840);
					  }
					  union_approx__241_cfa_approx(res_approx_73_3002, new_approx_178_3007);
					  {
					     obj_t cls_3848;
					     cls_3848 = CDR(cls_3003);
					     cls_3003 = cls_3848;
					     goto loop_3004;
					  }
				       }
				     aux_3641 = (obj_t) (aux_3837);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_3011;
			    node_3011 = (let_fun_218_t) (node_1);
			    {
			       approx_t aux_3854;
			       aux_3854 = cfa__102_cfa_cfa((((let_fun_218_t) CREF(node_3011))->body));
			       aux_3641 = (obj_t) (aux_3854);
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_3014;
			    node_3014 = (let_var_6_t) (node_1);
			    {
			       obj_t l2098_3016;
			       l2098_3016 = (((let_var_6_t) CREF(node_3014))->bindings);
			     lname2099_3017:
			       if (PAIRP(l2098_3016))
				 {
				    {
				       obj_t binding_3020;
				       binding_3020 = CAR(l2098_3016);
				       {
					  obj_t var_3021;
					  var_3021 = CAR(binding_3020);
					  {
					     approx_t var_approx_58_3022;
					     {
						svar_cinfo_166_t obj_3490;
						{
						   value_t aux_3863;
						   {
						      variable_t obj_3489;
						      obj_3489 = (variable_t) (var_3021);
						      aux_3863 = (((variable_t) CREF(obj_3489))->value);
						   }
						   obj_3490 = (svar_cinfo_166_t) (aux_3863);
						}
						{
						   obj_t aux_3867;
						   {
						      object_t aux_3868;
						      aux_3868 = (object_t) (obj_3490);
						      aux_3867 = OBJECT_WIDENING(aux_3868);
						   }
						   var_approx_58_3022 = (((svar_cinfo_166_t) CREF(aux_3867))->approx);
						}
					     }
					     {
						approx_t val_approx_22_3023;
						{
						   node_t aux_3872;
						   {
						      obj_t aux_3873;
						      aux_3873 = CDR(binding_3020);
						      aux_3872 = (node_t) (aux_3873);
						   }
						   val_approx_22_3023 = cfa__102_cfa_cfa(aux_3872);
						}
						{
						   {
						      type_t vtype_3024;
						      type_t atype_3025;
						      {
							 variable_t obj_3492;
							 obj_3492 = (variable_t) (var_3021);
							 vtype_3024 = (((variable_t) CREF(obj_3492))->type);
						      }
						      atype_3025 = (((approx_t) CREF(val_approx_22_3023))->type);
						      union_approx__241_cfa_approx(var_approx_58_3022, val_approx_22_3023);
						      {
							 bool_t test2467_3026;
							 {
							    bool_t test2469_3028;
							    {
							       obj_t obj2_3495;
							       obj2_3495 = ____74_type_cache;
							       {
								  obj_t aux_3881;
								  aux_3881 = (obj_t) (vtype_3024);
								  test2469_3028 = (aux_3881 == obj2_3495);
							       }
							    }
							    if (test2469_3028)
							      {
								 test2467_3026 = ((bool_t) 0);
							      }
							    else
							      {
								 bool_t test2470_3029;
								 {
								    obj_t obj2_3497;
								    obj2_3497 = _obj__252_type_cache;
								    {
								       obj_t aux_3885;
								       aux_3885 = (obj_t) (vtype_3024);
								       test2470_3029 = (aux_3885 == obj2_3497);
								    }
								 }
								 if (test2470_3029)
								   {
								      test2467_3026 = ((bool_t) 0);
								   }
								 else
								   {
								      bool_t test2471_3030;
								      {
									 obj_t obj2_3499;
									 obj2_3499 = ____74_type_cache;
									 {
									    obj_t aux_3889;
									    aux_3889 = (obj_t) (atype_3025);
									    test2471_3030 = (aux_3889 == obj2_3499);
									 }
								      }
								      if (test2471_3030)
									{
									   test2467_3026 = ((bool_t) 0);
									}
								      else
									{
									   bool_t test_3893;
									   {
									      obj_t aux_3896;
									      obj_t aux_3894;
									      aux_3896 = (obj_t) (vtype_3024);
									      aux_3894 = (obj_t) (atype_3025);
									      test_3893 = (aux_3894 == aux_3896);
									   }
									   if (test_3893)
									     {
										test2467_3026 = ((bool_t) 0);
									     }
									   else
									     {
										test2467_3026 = ((bool_t) 1);
									     }
									}
								   }
							      }
							 }
							 if (test2467_3026)
							   {
							      approx_set_top__187_cfa_approx(val_approx_22_3023);
							      {
								 approx_t aux_3901;
								 aux_3901 = loose__226_cfa_loose(val_approx_22_3023, CNST_TABLE_REF(((long) 0)));
								 (obj_t) (aux_3901);
							      }
							   }
							 else
							   {
							      BUNSPEC;
							   }
						      }
						   }
						}
					     }
					  }
				       }
				    }
				    {
				       obj_t l2098_3905;
				       l2098_3905 = CDR(l2098_3016);
				       l2098_3016 = l2098_3905;
				       goto lname2099_3017;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       approx_t aux_3908;
			       aux_3908 = cfa__102_cfa_cfa((((let_var_6_t) CREF(node_3014))->body));
			       aux_3641 = (obj_t) (aux_3908);
			    }
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_cinfo_168_t node_3036;
			    node_3036 = (set_ex_it_cinfo_168_t) (node_1);
			    {
			       approx_t arg2477_3038;
			       obj_t arg2478_3039;
			       {
				  node_t aux_3913;
				  {
				     set_ex_it_116_t obj_3504;
				     obj_3504 = (set_ex_it_116_t) (node_3036);
				     aux_3913 = (((set_ex_it_116_t) CREF(obj_3504))->body);
				  }
				  arg2477_3038 = cfa__102_cfa_cfa(aux_3913);
			       }
			       arg2478_3039 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2477_3038, arg2478_3039);
			    }
			    {
			       approx_t aux_3919;
			       {
				  obj_t aux_3920;
				  {
				     object_t aux_3921;
				     aux_3921 = (object_t) (node_3036);
				     aux_3920 = OBJECT_WIDENING(aux_3921);
				  }
				  aux_3919 = (((set_ex_it_cinfo_168_t) CREF(aux_3920))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3919);
			    }
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_cinfo_139_t node_3041;
			    node_3041 = (jump_ex_it_cinfo_139_t) (node_1);
			    {
			       node_t aux_3927;
			       {
				  jump_ex_it_184_t obj_3506;
				  obj_3506 = (jump_ex_it_184_t) (node_3041);
				  aux_3927 = (((jump_ex_it_184_t) CREF(obj_3506))->exit);
			       }
			       cfa__102_cfa_cfa(aux_3927);
			    }
			    {
			       approx_t val_approx_22_3044;
			       {
				  node_t aux_3931;
				  {
				     jump_ex_it_184_t obj_3507;
				     obj_3507 = (jump_ex_it_184_t) (node_3041);
				     aux_3931 = (((jump_ex_it_184_t) CREF(obj_3507))->value);
				  }
				  val_approx_22_3044 = cfa__102_cfa_cfa(aux_3931);
			       }
			       loose__226_cfa_loose(val_approx_22_3044, CNST_TABLE_REF(((long) 0)));
			       {
				  approx_t aux_3937;
				  {
				     obj_t aux_3938;
				     {
					object_t aux_3939;
					aux_3939 = (object_t) (node_3041);
					aux_3938 = OBJECT_WIDENING(aux_3939);
				     }
				     aux_3937 = (((jump_ex_it_cinfo_139_t) CREF(aux_3938))->approx);
				  }
				  aux_3641 = (obj_t) (aux_3937);
			       }
			    }
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_cinfo_127_t node_3047;
			    node_3047 = (make_box_cinfo_127_t) (node_1);
			    {
			       approx_t arg2484_3049;
			       obj_t arg2485_3050;
			       {
				  node_t aux_3945;
				  {
				     make_box_202_t obj_3509;
				     obj_3509 = (make_box_202_t) (node_3047);
				     aux_3945 = (((make_box_202_t) CREF(obj_3509))->value);
				  }
				  arg2484_3049 = cfa__102_cfa_cfa(aux_3945);
			       }
			       arg2485_3050 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2484_3049, arg2485_3050);
			    }
			    {
			       approx_t aux_3951;
			       {
				  obj_t aux_3952;
				  {
				     object_t aux_3953;
				     aux_3953 = (object_t) (node_3047);
				     aux_3952 = OBJECT_WIDENING(aux_3953);
				  }
				  aux_3951 = (((make_box_cinfo_127_t) CREF(aux_3952))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3951);
			    }
			 }
			 break;
		      case ((long) 18):
			 {
			    box_set__cinfo_94_t node_3052;
			    node_3052 = (box_set__cinfo_94_t) (node_1);
			    {
			       node_t aux_3959;
			       {
				  var_t aux_3960;
				  {
				     box_set__221_t obj_3511;
				     obj_3511 = (box_set__221_t) (node_3052);
				     aux_3960 = (((box_set__221_t) CREF(obj_3511))->var);
				  }
				  aux_3959 = (node_t) (aux_3960);
			       }
			       cfa__102_cfa_cfa(aux_3959);
			    }
			    {
			       approx_t arg2488_3055;
			       obj_t arg2489_3056;
			       {
				  node_t aux_3965;
				  {
				     box_set__221_t obj_3512;
				     obj_3512 = (box_set__221_t) (node_3052);
				     aux_3965 = (((box_set__221_t) CREF(obj_3512))->value);
				  }
				  arg2488_3055 = cfa__102_cfa_cfa(aux_3965);
			       }
			       arg2489_3056 = CNST_TABLE_REF(((long) 0));
			       loose__226_cfa_loose(arg2488_3055, arg2489_3056);
			    }
			    {
			       approx_t aux_3971;
			       {
				  obj_t aux_3972;
				  {
				     object_t aux_3973;
				     aux_3973 = (object_t) (node_3052);
				     aux_3972 = OBJECT_WIDENING(aux_3973);
				  }
				  aux_3971 = (((box_set__cinfo_94_t) CREF(aux_3972))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3971);
			    }
			 }
			 break;
		      case ((long) 19):
			 {
			    box_ref_cinfo_214_t node_3058;
			    node_3058 = (box_ref_cinfo_214_t) (node_1);
			    {
			       node_t aux_3979;
			       {
				  var_t aux_3980;
				  {
				     box_ref_242_t obj_3514;
				     obj_3514 = (box_ref_242_t) (node_3058);
				     aux_3980 = (((box_ref_242_t) CREF(obj_3514))->var);
				  }
				  aux_3979 = (node_t) (aux_3980);
			       }
			       cfa__102_cfa_cfa(aux_3979);
			    }
			    {
			       approx_t aux_3985;
			       {
				  obj_t aux_3986;
				  {
				     object_t aux_3987;
				     aux_3987 = (object_t) (node_3058);
				     aux_3986 = OBJECT_WIDENING(aux_3987);
				  }
				  aux_3985 = (((box_ref_cinfo_214_t) CREF(aux_3986))->approx);
			       }
			       aux_3641 = (obj_t) (aux_3985);
			    }
			 }
			 break;
		      default:
		       case_else2410_2921:
			 if (PROCEDUREP(method2404_2917))
			   {
			      aux_3641 = PROCEDURE_ENTRY(method2404_2917) (method2404_2917, (obj_t) (node_1), BEOA);
			   }
			 else
			   {
			      obj_t fun2379_2879;
			      fun2379_2879 = PROCEDURE_REF(cfa__env_153_cfa_cfa, ((long) 0));
			      aux_3641 = PROCEDURE_ENTRY(fun2379_2879) (fun2379_2879, (obj_t) (node_1), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else2410_2921;
		 }
	    }
	    return (approx_t) (aux_3641);
	 }
      }
   }
}


/* _cfa!2499 */ obj_t 
_cfa_2499_168_cfa_cfa(obj_t env_3558, obj_t node_3559)
{
   {
      approx_t aux_4004;
      aux_4004 = cfa__102_cfa_cfa((node_t) (node_3559));
      return (obj_t) (aux_4004);
   }
}


/* cfa!-default2106 */ approx_t 
cfa__default2106_184_cfa_cfa(node_t node_2)
{
   {
      obj_t arg2381_3519;
      arg2381_3519 = shape_tools_shape((obj_t) (node_2));
      {
	 obj_t aux_4010;
	 aux_4010 = internal_error_43_tools_error(string2503_cfa_cfa, (obj_t) (node_2), arg2381_3519);
	 return (approx_t) (aux_4010);
      }
   }
}


/* _cfa!-default2106 */ obj_t 
_cfa__default2106_48_cfa_cfa(obj_t env_3560, obj_t node_3561)
{
   {
      approx_t aux_4014;
      aux_4014 = cfa__default2106_184_cfa_cfa((node_t) (node_3561));
      return (obj_t) (aux_4014);
   }
}


/* cfa-variable-value-approx */ obj_t 
cfa_variable_value_approx_39_cfa_cfa(value_t value_8)
{
   {
      obj_t method2385_2888;
      obj_t class2390_2889;
      {
	 obj_t arg2394_2886;
	 obj_t arg2396_2887;
	 {
	    object_t obj_3520;
	    obj_3520 = (object_t) (value_8);
	    {
	       obj_t pre_method_105_3521;
	       pre_method_105_3521 = PROCEDURE_REF(cfa_variable_value_approx_env_230_cfa_cfa, ((long) 2));
	       if (INTEGERP(pre_method_105_3521))
		 {
		    PROCEDURE_SET(cfa_variable_value_approx_env_230_cfa_cfa, ((long) 2), BUNSPEC);
		    arg2394_2886 = pre_method_105_3521;
		 }
	       else
		 {
		    long obj_class_num_177_3526;
		    obj_class_num_177_3526 = TYPE(obj_3520);
		    {
		       obj_t arg1177_3527;
		       arg1177_3527 = PROCEDURE_REF(cfa_variable_value_approx_env_230_cfa_cfa, ((long) 1));
		       {
			  long arg1178_3531;
			  {
			     long arg1179_3532;
			     arg1179_3532 = OBJECT_TYPE;
			     arg1178_3531 = (obj_class_num_177_3526 - arg1179_3532);
			  }
			  arg2394_2886 = VECTOR_REF(arg1177_3527, arg1178_3531);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3537;
	    object_3537 = (object_t) (value_8);
	    {
	       long arg1180_3538;
	       {
		  long arg1181_3539;
		  long arg1182_3540;
		  arg1181_3539 = TYPE(object_3537);
		  arg1182_3540 = OBJECT_TYPE;
		  arg1180_3538 = (arg1181_3539 - arg1182_3540);
	       }
	       {
		  obj_t vector_3544;
		  vector_3544 = _classes__134___object;
		  arg2396_2887 = VECTOR_REF(vector_3544, arg1180_3538);
	       }
	    }
	 }
	 method2385_2888 = arg2394_2886;
	 class2390_2889 = arg2396_2887;
	 {
	    if (INTEGERP(method2385_2888))
	      {
		 switch ((long) CINT(method2385_2888))
		   {
		   case ((long) 0):
		      {
			 svar_cinfo_166_t value_2895;
			 value_2895 = (svar_cinfo_166_t) (value_8);
			 {
			    approx_t aux_4036;
			    {
			       obj_t aux_4037;
			       {
				  object_t aux_4038;
				  aux_4038 = (object_t) (value_2895);
				  aux_4037 = OBJECT_WIDENING(aux_4038);
			       }
			       aux_4036 = (((svar_cinfo_166_t) CREF(aux_4037))->approx);
			    }
			    return (obj_t) (aux_4036);
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 scnst_cinfo_0_t value_2897;
			 value_2897 = (scnst_cinfo_0_t) (value_8);
			 {
			    approx_t aux_4044;
			    {
			       obj_t aux_4045;
			       {
				  object_t aux_4046;
				  aux_4046 = (object_t) (value_2897);
				  aux_4045 = OBJECT_WIDENING(aux_4046);
			       }
			       aux_4044 = (((scnst_cinfo_0_t) CREF(aux_4045))->approx);
			    }
			    return (obj_t) (aux_4044);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 cvar_cinfo_53_t value_2899;
			 value_2899 = (cvar_cinfo_53_t) (value_8);
			 {
			    approx_t aux_4052;
			    {
			       obj_t aux_4053;
			       {
				  object_t aux_4054;
				  aux_4054 = (object_t) (value_2899);
				  aux_4053 = OBJECT_WIDENING(aux_4054);
			       }
			       aux_4052 = (((cvar_cinfo_53_t) CREF(aux_4053))->approx);
			    }
			    return (obj_t) (aux_4052);
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 sexit_cinfo_49_t value_2901;
			 value_2901 = (sexit_cinfo_49_t) (value_8);
			 {
			    approx_t aux_4060;
			    {
			       obj_t aux_4061;
			       {
				  object_t aux_4062;
				  aux_4062 = (object_t) (value_2901);
				  aux_4061 = OBJECT_WIDENING(aux_4062);
			       }
			       aux_4060 = (((sexit_cinfo_49_t) CREF(aux_4061))->approx);
			    }
			    return (obj_t) (aux_4060);
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 intern_sfun_cinfo_192_t value_2903;
			 value_2903 = (intern_sfun_cinfo_192_t) (value_8);
			 {
			    approx_t aux_4068;
			    {
			       obj_t aux_4069;
			       {
				  object_t aux_4070;
				  aux_4070 = (object_t) (value_2903);
				  aux_4069 = OBJECT_WIDENING(aux_4070);
			       }
			       aux_4068 = (((intern_sfun_cinfo_192_t) CREF(aux_4069))->approx);
			    }
			    return (obj_t) (aux_4068);
			 }
		      }
		      break;
		   default:
		    case_else2391_2892:
		      if (PROCEDUREP(method2385_2888))
			{
			   return PROCEDURE_ENTRY(method2385_2888) (method2385_2888, (obj_t) (value_8), BEOA);
			}
		      else
			{
			   obj_t fun2382_2882;
			   fun2382_2882 = PROCEDURE_REF(cfa_variable_value_approx_env_230_cfa_cfa, ((long) 0));
			   return PROCEDURE_ENTRY(fun2382_2882) (fun2382_2882, (obj_t) (value_8), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2391_2892;
	      }
	 }
      }
   }
}


/* _cfa-variable-value-approx2500 */ obj_t 
_cfa_variable_value_approx2500_252_cfa_cfa(obj_t env_3562, obj_t value_3563)
{
   return cfa_variable_value_approx_39_cfa_cfa((value_t) (value_3563));
}


/* cfa-variable-value-approx-default2112 */ obj_t 
cfa_variable_value_approx_default2112_92_cfa_cfa(value_t value_9)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string2504_cfa_cfa, (obj_t) (value_9));
}


/* _cfa-variable-value-approx-default2112 */ obj_t 
_cfa_variable_value_approx_default2112_145_cfa_cfa(obj_t env_3564, obj_t value_3565)
{
   return cfa_variable_value_approx_default2112_92_cfa_cfa((value_t) (value_3565));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_cfa()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_CFA");
   module_initialization_70_tools_shape(((long) 0), "CFA_CFA");
   module_initialization_70_tools_error(((long) 0), "CFA_CFA");
   module_initialization_70_type_type(((long) 0), "CFA_CFA");
   module_initialization_70_type_cache(((long) 0), "CFA_CFA");
   module_initialization_70_ast_var(((long) 0), "CFA_CFA");
   module_initialization_70_ast_node(((long) 0), "CFA_CFA");
   module_initialization_70_cfa_info(((long) 0), "CFA_CFA");
   module_initialization_70_cfa_loose(((long) 0), "CFA_CFA");
   module_initialization_70_cfa_approx(((long) 0), "CFA_CFA");
   module_initialization_70_cfa_app(((long) 0), "CFA_CFA");
   return module_initialization_70_cfa_funcall(((long) 0), "CFA_CFA");
}
