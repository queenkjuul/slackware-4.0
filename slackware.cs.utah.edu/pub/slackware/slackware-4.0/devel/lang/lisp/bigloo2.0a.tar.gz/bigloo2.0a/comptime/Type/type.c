/*===========================================================================*/
/*   (Type/type.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


extern obj_t type_init__set__30_type_type(type_t, bool_t);
extern obj_t type_pointed_to_by_230_type_type(type_t);
static obj_t method_init_76_type_type();
extern obj_t type_magic__set__183_type_type(type_t, bool_t);
extern obj_t type_parents_50_type_type(type_t);
extern obj_t type_alias_96_type_type(type_t);
obj_t type_type_type = BUNSPEC;
extern obj_t type_size_163_type_type(type_t);
static obj_t _make_type_208_type_type(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _type_init__228_type_type(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern bool_t bigloo_type__118_type_type(type_t);
static obj_t _type_init__set__55_type_type(obj_t, obj_t, obj_t);
static obj_t _object__struct1224_6___object(obj_t, obj_t);
extern obj_t type_name_1_type_type(type_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t _type_class_83_type_type(obj_t, obj_t);
static obj_t _type_magic__164_type_type(obj_t, obj_t);
static obj_t _type__28_type_type(obj_t, obj_t);
static obj_t _type_parents_237_type_type(obj_t, obj_t);
static obj_t _type___set__19_type_type(obj_t, obj_t, obj_t);
static obj_t _type_name_set__35_type_type(obj_t, obj_t, obj_t);
static obj_t _allocate_type_190_type_type(obj_t);
extern long class_num_218___object(obj_t);
extern obj_t type_tvector_227_type_type(type_t);
static obj_t _type_alias_230_type_type(obj_t, obj_t);
extern bool_t type_magic__223_type_type(type_t);
extern obj_t type_pointed_to_by_set__160_type_type(type_t, obj_t);
extern obj_t type___set__33_type_type(type_t, obj_t);
static obj_t _type_tvector_set__209_type_type(obj_t, obj_t, obj_t);
extern obj_t type_alias_set__154_type_type(type_t, obj_t);
static obj_t _type_coerce_to_set__177_type_type(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_type_type();
extern obj_t type_tvector_set__193_type_type(type_t, obj_t);
static obj_t _bigloo_type__228_type_type(obj_t, obj_t);
static obj_t library_modules_init_112_type_type();
extern obj_t type_name_set__141_type_type(type_t, obj_t);
static obj_t _type_size_96_type_type(obj_t, obj_t);
static obj_t _type_pointed_to_by_66_type_type(obj_t, obj_t);
extern obj_t type_class_set__5_type_type(type_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _type_coerce_to_161_type_type(obj_t, obj_t);
static obj_t _struct_object__object1227_4___object(obj_t, obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _type_name_68_type_type(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _type_alias_set__160_type_type(obj_t, obj_t, obj_t);
static obj_t _type_size_set__154_type_type(obj_t, obj_t, obj_t);
static obj_t _type_id_65_type_type(obj_t, obj_t);
static obj_t _type_tvector_54_type_type(obj_t, obj_t);
extern obj_t type_coerce_to_set__224_type_type(type_t, obj_t);
static obj_t _get_aliased_type_163_type_type(obj_t, obj_t);
extern obj_t object___object;
extern obj_t type_coerce_to_225_type_type(type_t);
static obj_t _type_class_set__124_type_type(obj_t, obj_t, obj_t);
extern obj_t type___190_type_type(type_t);
extern obj_t type_id_229_type_type(type_t);
static obj_t object_init_111_type_type();
extern type_t allocate_type_104_type_type();
extern type_t make_type_93_type_type(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t);
extern type_t get_aliased_type_1_type_type(type_t);
static obj_t _type_parents_set__4_type_type(obj_t, obj_t, obj_t);
extern obj_t type_size_set__3_type_type(type_t, obj_t);
extern bool_t type_init__169_type_type(type_t);
extern bool_t type__118_type_type(obj_t);
static obj_t _type___32_type_type(obj_t, obj_t);
extern obj_t type_parents_set__29_type_type(type_t, obj_t);
static obj_t object__struct_type_200_type_type(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _type_magic__set__236_type_type(obj_t, obj_t, obj_t);
static obj_t _type_pointed_to_by_set__215_type_type(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_type_type = BUNSPEC;
extern obj_t type_class_245_type_type(type_t);
static obj_t struct_object__object_type_132_type_type(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_type_type();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(type_size_env_255_type_type, _type_size_96_type_type1236, _type_size_96_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_tvector_set__env_149_type_type, _type_tvector_set__209_type_type1237, _type_tvector_set__209_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_alias_set__env_58_type_type, _type_alias_set__160_type_type1238, _type_alias_set__160_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type___env_188_type_type, _type___32_type_type1239, _type___32_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_alias_env_158_type_type, _type_alias_230_type_type1240, _type_alias_230_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_class_set__env_185_type_type, _type_class_set__124_type_type1241, _type_class_set__124_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_type_env_5_type_type, _allocate_type_190_type_type1242, _allocate_type_190_type_type, 0L, 0);
DEFINE_EXPORT_PROCEDURE(type_init__env_182_type_type, _type_init__228_type_type1243, _type_init__228_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_type_env_209_type_type, _make_type_208_type_type1244, _make_type_208_type_type, 0L, 12);
DEFINE_EXPORT_PROCEDURE(type_pointed_to_by_set__env_157_type_type, _type_pointed_to_by_set__215_type_type1245, _type_pointed_to_by_set__215_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type__env_220_type_type, _type__28_type_type1246, _type__28_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type___set__env_63_type_type, _type___set__19_type_type1247, _type___set__19_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(get_aliased_type_env_233_type_type, _get_aliased_type_163_type_type1248, _get_aliased_type_163_type_type, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_STATIC_PROCEDURE(proc1229_type_type, struct_object__object_type_132_type_type1249, struct_object__object_type_132_type_type, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1228_type_type, object__struct_type_200_type_type1250, object__struct_type_200_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(bigloo_type__env_220_type_type, _bigloo_type__228_type_type1251, _bigloo_type__228_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_parents_set__env_117_type_type, _type_parents_set__4_type_type1252, _type_parents_set__4_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_magic__env_126_type_type, _type_magic__164_type_type1253, _type_magic__164_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_coerce_to_set__env_33_type_type, _type_coerce_to_set__177_type_type1254, _type_coerce_to_set__177_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_tvector_env_129_type_type, _type_tvector_54_type_type1255, _type_tvector_54_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_class_env_113_type_type, _type_class_83_type_type1256, _type_class_83_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_parents_env_210_type_type, _type_parents_237_type_type1257, _type_parents_237_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_size_set__env_221_type_type, _type_size_set__154_type_type1258, _type_size_set__154_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_pointed_to_by_env_253_type_type, _type_pointed_to_by_66_type_type1259, _type_pointed_to_by_66_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_init__set__env_193_type_type, _type_init__set__55_type_type1260, _type_init__set__55_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_magic__set__env_122_type_type, _type_magic__set__236_type_type1261, _type_magic__set__236_type_type, 0L, 2);
DEFINE_EXPORT_PROCEDURE(type_id_env_218_type_type, _type_id_65_type_type1262, _type_id_65_type_type, 0L, 1);
DEFINE_STRING(string1230_type_type, string1230_type_type1263, "TYPE BIGLOO ", 12);
DEFINE_EXPORT_PROCEDURE(type_name_set__env_232_type_type, _type_name_set__35_type_type1264, _type_name_set__35_type_type, 0L, 2);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(type_name_env_233_type_type, _type_name_68_type_type1265, _type_name_68_type_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_coerce_to_env_118_type_type, _type_coerce_to_161_type_type1266, _type_coerce_to_161_type_type, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_type_type(long checksum_334, char *from_335)
{
   if (CBOOL(require_initialization_114_type_type))
     {
	require_initialization_114_type_type = BBOOL(((bool_t) 0));
	library_modules_init_112_type_type();
	cnst_init_137_type_type();
	imported_modules_init_94_type_type();
	object_init_111_type_type();
	method_init_76_type_type();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_type()
{
   module_initialization_70___object(((long) 0), "TYPE_TYPE");
   module_initialization_70___reader(((long) 0), "TYPE_TYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_type_type()
{
   {
      obj_t cnst_port_138_326;
      cnst_port_138_326 = open_input_string(string1230_type_type);
      {
	 long i_327;
	 i_327 = ((long) 1);
       loop_328:
	 {
	    bool_t test1231_329;
	    test1231_329 = (i_327 == ((long) -1));
	    if (test1231_329)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1232_330;
		    {
		       obj_t list1233_331;
		       {
			  obj_t arg1234_332;
			  arg1234_332 = BNIL;
			  list1233_331 = MAKE_PAIR(cnst_port_138_326, arg1234_332);
		       }
		       arg1232_330 = read___reader(list1233_331);
		    }
		    CNST_TABLE_SET(i_327, arg1232_330);
		 }
		 {
		    int aux_333;
		    {
		       long aux_352;
		       aux_352 = (i_327 - ((long) 1));
		       aux_333 = (int) (aux_352);
		    }
		    {
		       long i_355;
		       i_355 = (long) (aux_333);
		       i_327 = i_355;
		       goto loop_328;
		    }
		 }
	      }
	 }
      }
   }
}


/* get-aliased-type */ type_t 
get_aliased_type_1_type_type(type_t type_1)
{
   {
      obj_t type_53;
      {
	 obj_t aux_357;
	 type_53 = (obj_t) (type_1);
       loop_54:
	 {
	    bool_t test1080_55;
	    {
	       obj_t aux_358;
	       {
		  type_t obj_131;
		  obj_131 = (type_t) (type_53);
		  aux_358 = (((type_t) CREF(obj_131))->alias);
	       }
	       test1080_55 = is_a__118___object(aux_358, type_type_type);
	    }
	    if (test1080_55)
	      {
		 obj_t type_363;
		 {
		    type_t obj_133;
		    obj_133 = (type_t) (type_53);
		    type_363 = (((type_t) CREF(obj_133))->alias);
		 }
		 type_53 = type_363;
		 goto loop_54;
	      }
	    else
	      {
		 aux_357 = type_53;
	      }
	 }
	 return (type_t) (aux_357);
      }
   }
}


/* _get-aliased-type */ obj_t 
_get_aliased_type_163_type_type(obj_t env_237, obj_t type_238)
{
   {
      type_t aux_368;
      aux_368 = get_aliased_type_1_type_type((type_t) (type_238));
      return (obj_t) (aux_368);
   }
}


/* bigloo-type? */ bool_t 
bigloo_type__118_type_type(type_t type_2)
{
   {
      obj_t aux_374;
      obj_t aux_372;
      aux_374 = CNST_TABLE_REF(((long) 0));
      aux_372 = (((type_t) CREF(type_2))->class);
      return (aux_372 == aux_374);
   }
}


/* _bigloo-type? */ obj_t 
_bigloo_type__228_type_type(obj_t env_239, obj_t type_240)
{
   {
      bool_t aux_377;
      aux_377 = bigloo_type__118_type_type((type_t) (type_240));
      return BBOOL(aux_377);
   }
}


/* object-init */ obj_t 
object_init_111_type_type()
{
   {
      obj_t arg1157_61;
      arg1157_61 = object___object;
      type_type_type = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1157_61, allocate_type_env_5_type_type, ((long) 33388), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-type */ type_t 
allocate_type_104_type_type()
{
   {
      type_t new1027_64;
      new1027_64 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1175_65;
	 arg1175_65 = class_num_218___object(type_type_type);
	 {
	    obj_t obj_139;
	    obj_139 = (obj_t) (new1027_64);
	    (((obj_t) CREF(obj_139))->header = MAKE_HEADER(arg1175_65, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_387;
	 aux_387 = (object_t) (new1027_64);
	 OBJECT_WIDENING_SET(aux_387, BFALSE);
      }
      return new1027_64;
   }
}


/* _allocate-type */ obj_t 
_allocate_type_190_type_type(obj_t env_241)
{
   {
      type_t aux_390;
      aux_390 = allocate_type_104_type_type();
      return (obj_t) (aux_390);
   }
}


/* type? */ bool_t 
type__118_type_type(obj_t obj_6)
{
   return is_a__118___object(obj_6, type_type_type);
}


/* _type? */ obj_t 
_type__28_type_type(obj_t env_242, obj_t obj_243)
{
   {
      bool_t aux_394;
      aux_394 = type__118_type_type(obj_243);
      return BBOOL(aux_394);
   }
}


/* make-type */ type_t 
make_type_93_type_type(obj_t id_7, obj_t name_8, obj_t size_9, obj_t class_10, obj_t coerce_to_204_11, obj_t parents_12, bool_t init__47_13, bool_t magic__53_14, obj_t __57_15, obj_t alias_16, obj_t pointed_to_by_76_17, obj_t tvector_18)
{
   {
      type_t new1002_141;
      new1002_141 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1176_142;
	 arg1176_142 = class_num_218___object(type_type_type);
	 {
	    obj_t obj_155;
	    obj_155 = (obj_t) (new1002_141);
	    (((obj_t) CREF(obj_155))->header = MAKE_HEADER(arg1176_142, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_401;
	 aux_401 = (object_t) (new1002_141);
	 OBJECT_WIDENING_SET(aux_401, BFALSE);
      }
      ((((type_t) CREF(new1002_141))->id) = ((obj_t) id_7), BUNSPEC);
      ((((type_t) CREF(new1002_141))->name) = ((obj_t) name_8), BUNSPEC);
      ((((type_t) CREF(new1002_141))->size) = ((obj_t) size_9), BUNSPEC);
      ((((type_t) CREF(new1002_141))->class) = ((obj_t) class_10), BUNSPEC);
      ((((type_t) CREF(new1002_141))->coerce_to_204) = ((obj_t) coerce_to_204_11), BUNSPEC);
      ((((type_t) CREF(new1002_141))->parents) = ((obj_t) parents_12), BUNSPEC);
      ((((type_t) CREF(new1002_141))->init__47) = ((bool_t) init__47_13), BUNSPEC);
      ((((type_t) CREF(new1002_141))->magic__53) = ((bool_t) magic__53_14), BUNSPEC);
      ((((type_t) CREF(new1002_141))->__57) = ((obj_t) __57_15), BUNSPEC);
      ((((type_t) CREF(new1002_141))->alias) = ((obj_t) alias_16), BUNSPEC);
      ((((type_t) CREF(new1002_141))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_17), BUNSPEC);
      ((((type_t) CREF(new1002_141))->tvector) = ((obj_t) tvector_18), BUNSPEC);
      return new1002_141;
   }
}


/* _make-type */ obj_t 
_make_type_208_type_type(obj_t env_244, obj_t id_245, obj_t name_246, obj_t size_247, obj_t class_248, obj_t coerce_to_204_249, obj_t parents_250, obj_t init__47_251, obj_t magic__53_252, obj_t __57_253, obj_t alias_254, obj_t pointed_to_by_76_255, obj_t tvector_256)
{
   {
      type_t aux_416;
      aux_416 = make_type_93_type_type(id_245, name_246, size_247, class_248, coerce_to_204_249, parents_250, CBOOL(init__47_251), CBOOL(magic__53_252), __57_253, alias_254, pointed_to_by_76_255, tvector_256);
      return (obj_t) (aux_416);
   }
}


/* type-id */ obj_t 
type_id_229_type_type(type_t obj_19)
{
   return (((type_t) CREF(obj_19))->id);
}


/* _type-id */ obj_t 
_type_id_65_type_type(obj_t env_257, obj_t obj_258)
{
   return type_id_229_type_type((type_t) (obj_258));
}


/* type-name-set! */ obj_t 
type_name_set__141_type_type(type_t obj_20, obj_t val1016_21)
{
   return ((((type_t) CREF(obj_20))->name) = ((obj_t) val1016_21), BUNSPEC);
}


/* _type-name-set! */ obj_t 
_type_name_set__35_type_type(obj_t env_259, obj_t obj_260, obj_t val1016_261)
{
   return type_name_set__141_type_type((type_t) (obj_260), val1016_261);
}


/* type-name */ obj_t 
type_name_1_type_type(type_t obj_22)
{
   return (((type_t) CREF(obj_22))->name);
}


/* _type-name */ obj_t 
_type_name_68_type_type(obj_t env_262, obj_t obj_263)
{
   return type_name_1_type_type((type_t) (obj_263));
}


/* type-size-set! */ obj_t 
type_size_set__3_type_type(type_t obj_23, obj_t val1017_24)
{
   return ((((type_t) CREF(obj_23))->size) = ((obj_t) val1017_24), BUNSPEC);
}


/* _type-size-set! */ obj_t 
_type_size_set__154_type_type(obj_t env_264, obj_t obj_265, obj_t val1017_266)
{
   return type_size_set__3_type_type((type_t) (obj_265), val1017_266);
}


/* type-size */ obj_t 
type_size_163_type_type(type_t obj_25)
{
   return (((type_t) CREF(obj_25))->size);
}


/* _type-size */ obj_t 
_type_size_96_type_type(obj_t env_267, obj_t obj_268)
{
   return type_size_163_type_type((type_t) (obj_268));
}


/* type-class-set! */ obj_t 
type_class_set__5_type_type(type_t obj_26, obj_t val1018_27)
{
   return ((((type_t) CREF(obj_26))->class) = ((obj_t) val1018_27), BUNSPEC);
}


/* _type-class-set! */ obj_t 
_type_class_set__124_type_type(obj_t env_269, obj_t obj_270, obj_t val1018_271)
{
   return type_class_set__5_type_type((type_t) (obj_270), val1018_271);
}


/* type-class */ obj_t 
type_class_245_type_type(type_t obj_28)
{
   return (((type_t) CREF(obj_28))->class);
}


/* _type-class */ obj_t 
_type_class_83_type_type(obj_t env_272, obj_t obj_273)
{
   return type_class_245_type_type((type_t) (obj_273));
}


/* type-coerce-to-set! */ obj_t 
type_coerce_to_set__224_type_type(type_t obj_29, obj_t val1019_30)
{
   return ((((type_t) CREF(obj_29))->coerce_to_204) = ((obj_t) val1019_30), BUNSPEC);
}


/* _type-coerce-to-set! */ obj_t 
_type_coerce_to_set__177_type_type(obj_t env_274, obj_t obj_275, obj_t val1019_276)
{
   return type_coerce_to_set__224_type_type((type_t) (obj_275), val1019_276);
}


/* type-coerce-to */ obj_t 
type_coerce_to_225_type_type(type_t obj_31)
{
   return (((type_t) CREF(obj_31))->coerce_to_204);
}


/* _type-coerce-to */ obj_t 
_type_coerce_to_161_type_type(obj_t env_277, obj_t obj_278)
{
   return type_coerce_to_225_type_type((type_t) (obj_278));
}


/* type-parents-set! */ obj_t 
type_parents_set__29_type_type(type_t obj_32, obj_t val1020_33)
{
   return ((((type_t) CREF(obj_32))->parents) = ((obj_t) val1020_33), BUNSPEC);
}


/* _type-parents-set! */ obj_t 
_type_parents_set__4_type_type(obj_t env_279, obj_t obj_280, obj_t val1020_281)
{
   return type_parents_set__29_type_type((type_t) (obj_280), val1020_281);
}


/* type-parents */ obj_t 
type_parents_50_type_type(type_t obj_34)
{
   return (((type_t) CREF(obj_34))->parents);
}


/* _type-parents */ obj_t 
_type_parents_237_type_type(obj_t env_282, obj_t obj_283)
{
   return type_parents_50_type_type((type_t) (obj_283));
}


/* type-init?-set! */ obj_t 
type_init__set__30_type_type(type_t obj_35, bool_t val1021_36)
{
   return ((((type_t) CREF(obj_35))->init__47) = ((bool_t) val1021_36), BUNSPEC);
}


/* _type-init?-set! */ obj_t 
_type_init__set__55_type_type(obj_t env_284, obj_t obj_285, obj_t val1021_286)
{
   return type_init__set__30_type_type((type_t) (obj_285), CBOOL(val1021_286));
}


/* type-init? */ bool_t 
type_init__169_type_type(type_t obj_37)
{
   return (((type_t) CREF(obj_37))->init__47);
}


/* _type-init? */ obj_t 
_type_init__228_type_type(obj_t env_287, obj_t obj_288)
{
   {
      bool_t aux_459;
      aux_459 = type_init__169_type_type((type_t) (obj_288));
      return BBOOL(aux_459);
   }
}


/* type-magic?-set! */ obj_t 
type_magic__set__183_type_type(type_t obj_38, bool_t val1022_39)
{
   return ((((type_t) CREF(obj_38))->magic__53) = ((bool_t) val1022_39), BUNSPEC);
}


/* _type-magic?-set! */ obj_t 
_type_magic__set__236_type_type(obj_t env_289, obj_t obj_290, obj_t val1022_291)
{
   return type_magic__set__183_type_type((type_t) (obj_290), CBOOL(val1022_291));
}


/* type-magic? */ bool_t 
type_magic__223_type_type(type_t obj_40)
{
   return (((type_t) CREF(obj_40))->magic__53);
}


/* _type-magic? */ obj_t 
_type_magic__164_type_type(obj_t env_292, obj_t obj_293)
{
   {
      bool_t aux_468;
      aux_468 = type_magic__223_type_type((type_t) (obj_293));
      return BBOOL(aux_468);
   }
}


/* type-$-set! */ obj_t 
type___set__33_type_type(type_t obj_41, obj_t val1023_42)
{
   return ((((type_t) CREF(obj_41))->__57) = ((obj_t) val1023_42), BUNSPEC);
}


/* _type-$-set! */ obj_t 
_type___set__19_type_type(obj_t env_294, obj_t obj_295, obj_t val1023_296)
{
   return type___set__33_type_type((type_t) (obj_295), val1023_296);
}


/* type-$ */ obj_t 
type___190_type_type(type_t obj_43)
{
   return (((type_t) CREF(obj_43))->__57);
}


/* _type-$ */ obj_t 
_type___32_type_type(obj_t env_297, obj_t obj_298)
{
   return type___190_type_type((type_t) (obj_298));
}


/* type-alias-set! */ obj_t 
type_alias_set__154_type_type(type_t obj_44, obj_t val1024_45)
{
   return ((((type_t) CREF(obj_44))->alias) = ((obj_t) val1024_45), BUNSPEC);
}


/* _type-alias-set! */ obj_t 
_type_alias_set__160_type_type(obj_t env_299, obj_t obj_300, obj_t val1024_301)
{
   return type_alias_set__154_type_type((type_t) (obj_300), val1024_301);
}


/* type-alias */ obj_t 
type_alias_96_type_type(type_t obj_46)
{
   return (((type_t) CREF(obj_46))->alias);
}


/* _type-alias */ obj_t 
_type_alias_230_type_type(obj_t env_302, obj_t obj_303)
{
   return type_alias_96_type_type((type_t) (obj_303));
}


/* type-pointed-to-by-set! */ obj_t 
type_pointed_to_by_set__160_type_type(type_t obj_47, obj_t val1025_48)
{
   return ((((type_t) CREF(obj_47))->pointed_to_by_76) = ((obj_t) val1025_48), BUNSPEC);
}


/* _type-pointed-to-by-set! */ obj_t 
_type_pointed_to_by_set__215_type_type(obj_t env_304, obj_t obj_305, obj_t val1025_306)
{
   return type_pointed_to_by_set__160_type_type((type_t) (obj_305), val1025_306);
}


/* type-pointed-to-by */ obj_t 
type_pointed_to_by_230_type_type(type_t obj_49)
{
   return (((type_t) CREF(obj_49))->pointed_to_by_76);
}


/* _type-pointed-to-by */ obj_t 
_type_pointed_to_by_66_type_type(obj_t env_307, obj_t obj_308)
{
   return type_pointed_to_by_230_type_type((type_t) (obj_308));
}


/* type-tvector-set! */ obj_t 
type_tvector_set__193_type_type(type_t obj_50, obj_t val1026_51)
{
   return ((((type_t) CREF(obj_50))->tvector) = ((obj_t) val1026_51), BUNSPEC);
}


/* _type-tvector-set! */ obj_t 
_type_tvector_set__209_type_type(obj_t env_309, obj_t obj_310, obj_t val1026_311)
{
   return type_tvector_set__193_type_type((type_t) (obj_310), val1026_311);
}


/* type-tvector */ obj_t 
type_tvector_227_type_type(type_t obj_52)
{
   return (((type_t) CREF(obj_52))->tvector);
}


/* _type-tvector */ obj_t 
_type_tvector_54_type_type(obj_t env_312, obj_t obj_313)
{
   return type_tvector_227_type_type((type_t) (obj_313));
}


/* method-init */ obj_t 
method_init_76_type_type()
{
   {
      obj_t object__struct_type_200_315;
      object__struct_type_200_315 = proc1228_type_type;
      add_method__1___object(object__struct_env_210___object, type_type_type, object__struct_type_200_315);
   }
   {
      obj_t struct_object__object_type_132_314;
      struct_object__object_type_132_314 = proc1229_type_type;
      return add_method__1___object(struct_object__object_env_209___object, type_type_type, struct_object__object_type_132_314);
   }
}


/* struct+object->object-type */ obj_t 
struct_object__object_type_132_type_type(obj_t env_316, obj_t o_317, obj_t s_318)
{
   {
      type_t o_112;
      obj_t s_113;
      {
	 type_t aux_498;
	 o_112 = (type_t) (o_317);
	 s_113 = s_318;
	 {
	    obj_t aux_501;
	    object_t aux_499;
	    aux_501 = STRUCT_REF(s_113, ((long) 0));
	    aux_499 = (object_t) (o_112);
	    OBJECT_WIDENING_SET(aux_499, aux_501);
	 }
	 {
	    obj_t v1032_117;
	    v1032_117 = STRUCT_REF(s_113, ((long) 1));
	    ((((type_t) CREF(o_112))->id) = ((obj_t) v1032_117), BUNSPEC);
	 }
	 {
	    obj_t v1036_118;
	    v1036_118 = STRUCT_REF(s_113, ((long) 2));
	    ((((type_t) CREF(o_112))->name) = ((obj_t) v1036_118), BUNSPEC);
	 }
	 {
	    obj_t v1040_119;
	    v1040_119 = STRUCT_REF(s_113, ((long) 3));
	    ((((type_t) CREF(o_112))->size) = ((obj_t) v1040_119), BUNSPEC);
	 }
	 {
	    obj_t v1044_120;
	    v1044_120 = STRUCT_REF(s_113, ((long) 4));
	    ((((type_t) CREF(o_112))->class) = ((obj_t) v1044_120), BUNSPEC);
	 }
	 {
	    obj_t v1048_121;
	    v1048_121 = STRUCT_REF(s_113, ((long) 5));
	    ((((type_t) CREF(o_112))->coerce_to_204) = ((obj_t) v1048_121), BUNSPEC);
	 }
	 {
	    obj_t v1052_122;
	    v1052_122 = STRUCT_REF(s_113, ((long) 6));
	    ((((type_t) CREF(o_112))->parents) = ((obj_t) v1052_122), BUNSPEC);
	 }
	 {
	    bool_t v1056_123;
	    {
	       obj_t aux_516;
	       aux_516 = STRUCT_REF(s_113, ((long) 7));
	       v1056_123 = CBOOL(aux_516);
	    }
	    ((((type_t) CREF(o_112))->init__47) = ((bool_t) v1056_123), BUNSPEC);
	 }
	 {
	    bool_t v1060_124;
	    {
	       obj_t aux_520;
	       aux_520 = STRUCT_REF(s_113, ((long) 8));
	       v1060_124 = CBOOL(aux_520);
	    }
	    ((((type_t) CREF(o_112))->magic__53) = ((bool_t) v1060_124), BUNSPEC);
	 }
	 {
	    obj_t v1064_125;
	    v1064_125 = STRUCT_REF(s_113, ((long) 9));
	    ((((type_t) CREF(o_112))->__57) = ((obj_t) v1064_125), BUNSPEC);
	 }
	 {
	    obj_t v1068_126;
	    v1068_126 = STRUCT_REF(s_113, ((long) 10));
	    ((((type_t) CREF(o_112))->alias) = ((obj_t) v1068_126), BUNSPEC);
	 }
	 {
	    obj_t v1072_127;
	    v1072_127 = STRUCT_REF(s_113, ((long) 11));
	    ((((type_t) CREF(o_112))->pointed_to_by_76) = ((obj_t) v1072_127), BUNSPEC);
	 }
	 {
	    obj_t v1076_128;
	    v1076_128 = STRUCT_REF(s_113, ((long) 12));
	    ((((type_t) CREF(o_112))->tvector) = ((obj_t) v1076_128), BUNSPEC);
	 }
	 aux_498 = o_112;
	 return (obj_t) (aux_498);
      }
   }
}


/* object->struct-type */ obj_t 
object__struct_type_200_type_type(obj_t env_319, obj_t obj1028_320)
{
   {
      type_t obj1028_80;
      obj1028_80 = (type_t) (obj1028_320);
      {
	 obj_t res1029_83;
	 {
	    obj_t aux_534;
	    aux_534 = CNST_TABLE_REF(((long) 1));
	    res1029_83 = make_struct(aux_534, ((long) 13), BUNSPEC);
	 }
	 STRUCT_SET(res1029_83, ((long) 0), BFALSE);
	 {
	    obj_t aux_538;
	    aux_538 = (((type_t) CREF(obj1028_80))->id);
	    STRUCT_SET(res1029_83, ((long) 1), aux_538);
	 }
	 {
	    obj_t aux_541;
	    aux_541 = (((type_t) CREF(obj1028_80))->name);
	    STRUCT_SET(res1029_83, ((long) 2), aux_541);
	 }
	 {
	    obj_t aux_544;
	    aux_544 = (((type_t) CREF(obj1028_80))->size);
	    STRUCT_SET(res1029_83, ((long) 3), aux_544);
	 }
	 {
	    obj_t aux_547;
	    aux_547 = (((type_t) CREF(obj1028_80))->class);
	    STRUCT_SET(res1029_83, ((long) 4), aux_547);
	 }
	 {
	    obj_t aux_550;
	    aux_550 = (((type_t) CREF(obj1028_80))->coerce_to_204);
	    STRUCT_SET(res1029_83, ((long) 5), aux_550);
	 }
	 {
	    obj_t aux_553;
	    aux_553 = (((type_t) CREF(obj1028_80))->parents);
	    STRUCT_SET(res1029_83, ((long) 6), aux_553);
	 }
	 {
	    obj_t aux_556;
	    {
	       bool_t aux_557;
	       aux_557 = (((type_t) CREF(obj1028_80))->init__47);
	       aux_556 = BBOOL(aux_557);
	    }
	    STRUCT_SET(res1029_83, ((long) 7), aux_556);
	 }
	 {
	    obj_t aux_561;
	    {
	       bool_t aux_562;
	       aux_562 = (((type_t) CREF(obj1028_80))->magic__53);
	       aux_561 = BBOOL(aux_562);
	    }
	    STRUCT_SET(res1029_83, ((long) 8), aux_561);
	 }
	 {
	    obj_t aux_566;
	    aux_566 = (((type_t) CREF(obj1028_80))->__57);
	    STRUCT_SET(res1029_83, ((long) 9), aux_566);
	 }
	 {
	    obj_t aux_569;
	    aux_569 = (((type_t) CREF(obj1028_80))->alias);
	    STRUCT_SET(res1029_83, ((long) 10), aux_569);
	 }
	 {
	    obj_t aux_572;
	    aux_572 = (((type_t) CREF(obj1028_80))->pointed_to_by_76);
	    STRUCT_SET(res1029_83, ((long) 11), aux_572);
	 }
	 {
	    obj_t aux_575;
	    aux_575 = (((type_t) CREF(obj1028_80))->tvector);
	    STRUCT_SET(res1029_83, ((long) 12), aux_575);
	 }
	 return res1029_83;
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_type()
{
   return module_initialization_70_tools_location(((long) 0), "TYPE_TYPE");
}
