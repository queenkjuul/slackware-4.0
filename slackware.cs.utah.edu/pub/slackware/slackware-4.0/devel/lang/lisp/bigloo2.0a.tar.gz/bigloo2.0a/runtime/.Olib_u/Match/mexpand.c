/*===========================================================================*/
/*   (Match/mexpand.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _the_empty_env__237___match_expand = BUNSPEC;
static obj_t symbol1322___match_expand = BUNSPEC;
static obj_t symbol1321___match_expand = BUNSPEC;
static obj_t symbol1319___match_expand = BUNSPEC;
static obj_t symbol1317___match_expand = BUNSPEC;
static obj_t symbol1316___match_expand = BUNSPEC;
static obj_t symbol1314___match_expand = BUNSPEC;
static obj_t symbol1312___match_expand = BUNSPEC;
extern obj_t pcompile___match_compiler(obj_t);
static obj_t list1320___match_expand = BUNSPEC;
static obj_t list1313___match_expand = BUNSPEC;
static obj_t list1311___match_expand = BUNSPEC;
static obj_t _expand_match_lambda_111___match_expand(obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___match_expand();
static obj_t fetch_prototypes_217___match_expand(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t pattern_variables_45___match_descriptions(obj_t);
static obj_t _expand_match_case_13___match_expand(obj_t, obj_t);
extern obj_t module_initialization_70___match_expand(long, char *);
extern obj_t module_initialization_70___match_s2cfun(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___match_compiler(long, char *);
extern obj_t module_initialization_70___match_descriptions(long, char *);
extern obj_t module_initialization_70___match_normalize(long, char *);
extern obj_t expand_match_case_143___match_expand(obj_t);
static obj_t arg1072___match_expand(obj_t, obj_t, obj_t);
extern obj_t expand_match_lambda_130___match_expand(obj_t);
static obj_t arg1012___match_expand(obj_t, obj_t, obj_t);
extern obj_t jim_gensym_58___match_s2cfun;
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t normalize_pattern_10___match_normalize(obj_t);
static obj_t imported_modules_init_94___match_expand();
static obj_t require_initialization_114___match_expand = BUNSPEC;
static obj_t cnst_init_137___match_expand();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_match_lambda_env_120___match_expand, _expand_match_lambda_111___match_expand1324, _expand_match_lambda_111___match_expand, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( expand_match_case_env_42___match_expand, _expand_match_case_13___match_expand1325, _expand_match_case_13___match_expand, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1318___match_expand, arg1012___match_expand1326, arg1012___match_expand, 0L, 2 );
DEFINE_STRING( string1315___match_expand, string1315___match_expand1327, "TAG-", 4 );


/* module-initialization */obj_t module_initialization_70___match_expand(long checksum_779, char * from_780)
{
if(CBOOL(require_initialization_114___match_expand)){
require_initialization_114___match_expand = BBOOL(((bool_t)0));
cnst_init_137___match_expand();
imported_modules_init_94___match_expand();
toplevel_init_63___match_expand();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___match_expand()
{
symbol1312___match_expand = string_to_symbol("NOT");
symbol1314___match_expand = string_to_symbol("ANY");
list1313___match_expand = MAKE_PAIR(symbol1314___match_expand, BNIL);
{
obj_t aux_790;
aux_790 = MAKE_PAIR(list1313___match_expand, BNIL);
list1311___match_expand = MAKE_PAIR(symbol1312___match_expand, aux_790);
}
symbol1316___match_expand = string_to_symbol("ELSE");
symbol1317___match_expand = string_to_symbol("TAGGED-OR");
symbol1319___match_expand = string_to_symbol("LABELS");
symbol1321___match_expand = string_to_symbol("T-OR");
{
obj_t aux_797;
aux_797 = MAKE_PAIR(symbol1317___match_expand, BNIL);
list1320___match_expand = MAKE_PAIR(symbol1321___match_expand, aux_797);
}
return (symbol1322___match_expand = string_to_symbol("MATCH-LAMBDA"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___match_expand()
{
return (_the_empty_env__237___match_expand = BNIL,
BUNSPEC);
}


/* expand-match-lambda */obj_t expand_match_lambda_130___match_expand(obj_t exp_1)
{
{
obj_t clauses_344;
obj_t k_345;
{
obj_t arg1011_347;
arg1011_347 = CDR(exp_1);
{
obj_t arg1012_763;
arg1012_763 = proc1318___match_expand;
clauses_344 = arg1011_347;
k_345 = arg1012_763;
clauses__pattern_1_346:
if(NULLP(clauses_344)){
return PROCEDURE_ENTRY(k_345)(k_345, list1311___match_expand, BNIL, BEOA);
}
 else {
obj_t pattern_390;
obj_t actions_391;
obj_t rest_392;
{
obj_t aux_806;
aux_806 = CAR(clauses_344);
pattern_390 = CAR(aux_806);
}
{
obj_t aux_809;
aux_809 = CAR(clauses_344);
actions_391 = CDR(aux_809);
}
rest_392 = CDR(clauses_344);
{
obj_t tag_393;
tag_393 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string1315___match_expand, BEOA);
if((pattern_390==symbol1316___match_expand)){
obj_t arg1045_395;
obj_t arg1046_396;
{
obj_t arg1047_397;
obj_t arg1048_398;
obj_t arg1049_399;
arg1047_397 = symbol1317___match_expand;
{
obj_t arg1057_406;
arg1057_406 = symbol1314___match_expand;
{
obj_t list1059_408;
list1059_408 = MAKE_PAIR(BNIL, BNIL);
arg1048_398 = cons__138___r4_pairs_and_lists_6_3(arg1057_406, list1059_408);
}
}
{
obj_t arg1061_410;
obj_t arg1062_411;
arg1061_410 = symbol1312___match_expand;
{
obj_t arg1067_416;
arg1067_416 = symbol1314___match_expand;
{
obj_t list1069_418;
list1069_418 = MAKE_PAIR(BNIL, BNIL);
arg1062_411 = cons__138___r4_pairs_and_lists_6_3(arg1067_416, list1069_418);
}
}
{
obj_t list1064_413;
{
obj_t arg1065_414;
arg1065_414 = MAKE_PAIR(BNIL, BNIL);
list1064_413 = MAKE_PAIR(arg1062_411, arg1065_414);
}
arg1049_399 = cons__138___r4_pairs_and_lists_6_3(arg1061_410, list1064_413);
}
}
{
obj_t list1051_401;
{
obj_t arg1053_402;
{
obj_t arg1054_403;
{
obj_t arg1055_404;
arg1055_404 = MAKE_PAIR(BNIL, BNIL);
arg1054_403 = MAKE_PAIR(arg1049_399, arg1055_404);
}
arg1053_402 = MAKE_PAIR(tag_393, arg1054_403);
}
list1051_401 = MAKE_PAIR(arg1048_398, arg1053_402);
}
arg1045_395 = cons__138___r4_pairs_and_lists_6_3(arg1047_397, list1051_401);
}
}
{
obj_t arg1110_687;
arg1110_687 = MAKE_PAIR(tag_393, actions_391);
arg1046_396 = MAKE_PAIR(arg1110_687, BNIL);
}
return PROCEDURE_ENTRY(k_345)(k_345, arg1045_395, arg1046_396, BEOA);
}
 else {
obj_t arg1072_764;
arg1072_764 = make_fx_procedure(arg1072___match_expand, ((long)2), ((long)4));
PROCEDURE_SET(arg1072_764, ((long)0), pattern_390);
PROCEDURE_SET(arg1072_764, ((long)1), tag_393);
PROCEDURE_SET(arg1072_764, ((long)2), actions_391);
PROCEDURE_SET(arg1072_764, ((long)3), k_345);
{
obj_t k_839;
obj_t clauses_838;
clauses_838 = rest_392;
k_839 = arg1072_764;
k_345 = k_839;
clauses_344 = clauses_838;
goto clauses__pattern_1_346;
}
}
}
}
}
}
}
}


/* _expand-match-lambda */obj_t _expand_match_lambda_111___match_expand(obj_t env_765, obj_t exp_766)
{
return expand_match_lambda_130___match_expand(exp_766);
}


/* arg1012 */obj_t arg1012___match_expand(obj_t env_767, obj_t pat_768, obj_t env_769)
{
{
obj_t pat_349;
obj_t env_350;
pat_349 = pat_768;
env_350 = env_769;
{
obj_t compiled_pat_78_352;
obj_t prototypes_353;
compiled_pat_78_352 = pcompile___match_compiler(pat_349);
prototypes_353 = fetch_prototypes_217___match_expand(pat_349);
{
obj_t arg1014_354;
obj_t arg1015_355;
arg1014_354 = symbol1319___match_expand;
{
obj_t arg1021_361;
{
obj_t arg1023_363;
obj_t arg1025_364;
if(NULLP(prototypes_353)){
arg1023_363 = BNIL;
}
 else {
obj_t head1004_367;
head1004_367 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_368;
obj_t tail1005_369;
l1002_368 = prototypes_353;
tail1005_369 = head1004_367;
lname1003_370:
if(NULLP(l1002_368)){
arg1023_363 = CDR(head1004_367);
}
 else {
obj_t newtail1006_372;
{
obj_t arg1029_374;
{
obj_t prototype_376;
prototype_376 = CAR(l1002_368);
{
obj_t arg1031_377;
obj_t arg1032_378;
arg1031_377 = CAR(prototype_376);
{
obj_t aux_855;
obj_t aux_851;
{
obj_t aux_856;
aux_856 = assq___r4_pairs_and_lists_6_3(CAR(prototype_376), env_350);
aux_855 = CDR(aux_856);
}
{
obj_t aux_852;
aux_852 = CDR(prototype_376);
aux_851 = CAR(aux_852);
}
arg1032_378 = MAKE_PAIR(aux_851, aux_855);
}
arg1029_374 = MAKE_PAIR(arg1031_377, arg1032_378);
}
}
newtail1006_372 = MAKE_PAIR(arg1029_374, BNIL);
}
SET_CDR(tail1005_369, newtail1006_372);
{
obj_t tail1005_866;
obj_t l1002_864;
l1002_864 = CDR(l1002_368);
tail1005_866 = newtail1006_372;
tail1005_369 = tail1005_866;
l1002_368 = l1002_864;
goto lname1003_370;
}
}
}
}
arg1025_364 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1021_361 = append_2_18___r4_pairs_and_lists_6_3(arg1023_363, arg1025_364);
}
arg1015_355 = cons__138___r4_pairs_and_lists_6_3(arg1021_361, BNIL);
}
{
obj_t list1017_357;
{
obj_t arg1018_358;
{
obj_t arg1019_359;
arg1019_359 = MAKE_PAIR(BNIL, BNIL);
arg1018_358 = MAKE_PAIR(compiled_pat_78_352, arg1019_359);
}
list1017_357 = MAKE_PAIR(arg1015_355, arg1018_358);
}
return cons__138___r4_pairs_and_lists_6_3(arg1014_354, list1017_357);
}
}
}
}
}


/* arg1072 */obj_t arg1072___match_expand(obj_t env_770, obj_t pat_775, obj_t env_776)
{
{
obj_t pattern_771;
obj_t tag_772;
obj_t actions_773;
obj_t k_774;
pattern_771 = PROCEDURE_REF(env_770, ((long)0));
tag_772 = PROCEDURE_REF(env_770, ((long)1));
actions_773 = PROCEDURE_REF(env_770, ((long)2));
k_774 = PROCEDURE_REF(env_770, ((long)3));
{
obj_t pat_421;
obj_t env_422;
pat_421 = pat_775;
env_422 = env_776;
{
obj_t arg1076_424;
obj_t arg1077_425;
{
obj_t arg1078_426;
obj_t arg1079_427;
arg1078_426 = symbol1317___match_expand;
arg1079_427 = normalize_pattern_10___match_normalize(pattern_771);
{
obj_t list1081_429;
{
obj_t arg1082_430;
{
obj_t arg1083_431;
{
obj_t arg1084_432;
arg1084_432 = MAKE_PAIR(BNIL, BNIL);
arg1083_431 = MAKE_PAIR(pat_421, arg1084_432);
}
arg1082_430 = MAKE_PAIR(tag_772, arg1083_431);
}
list1081_429 = MAKE_PAIR(arg1079_427, arg1082_430);
}
arg1076_424 = cons__138___r4_pairs_and_lists_6_3(arg1078_426, list1081_429);
}
}
{
obj_t arg1110_695;
arg1110_695 = MAKE_PAIR(tag_772, actions_773);
arg1077_425 = MAKE_PAIR(arg1110_695, env_422);
}
return PROCEDURE_ENTRY(k_774)(k_774, arg1076_424, arg1077_425, BEOA);
}
}
}
}


/* fetch-prototypes */obj_t fetch_prototypes_217___match_expand(obj_t pat_2)
{
{
bool_t test_888;
{
obj_t aux_889;
aux_889 = memq___r4_pairs_and_lists_6_3(CAR(pat_2), list1320___match_expand);
test_888 = CBOOL(aux_889);
}
if(test_888){
obj_t arg1088_437;
obj_t arg1089_438;
{
obj_t arg1090_439;
obj_t arg1091_440;
{
obj_t aux_893;
{
obj_t aux_894;
aux_894 = CDR(pat_2);
aux_893 = CDR(aux_894);
}
arg1090_439 = CAR(aux_893);
}
{
obj_t aux_898;
{
obj_t aux_899;
aux_899 = CDR(pat_2);
aux_898 = CAR(aux_899);
}
arg1091_440 = pattern_variables_45___match_descriptions(aux_898);
}
{
obj_t list1093_442;
{
obj_t arg1094_443;
arg1094_443 = MAKE_PAIR(BNIL, BNIL);
list1093_442 = MAKE_PAIR(arg1091_440, arg1094_443);
}
arg1088_437 = cons__138___r4_pairs_and_lists_6_3(arg1090_439, list1093_442);
}
}
{
obj_t aux_906;
{
obj_t aux_907;
{
obj_t aux_908;
{
obj_t aux_909;
aux_909 = CDR(pat_2);
aux_908 = CDR(aux_909);
}
aux_907 = CDR(aux_908);
}
aux_906 = CAR(aux_907);
}
arg1089_438 = fetch_prototypes_217___match_expand(aux_906);
}
return MAKE_PAIR(arg1088_437, arg1089_438);
}
 else {
return BNIL;
}
}
}


/* expand-match-case */obj_t expand_match_case_143___match_expand(obj_t exp_3)
{
{
obj_t arg1100_449;
obj_t arg1101_450;
{
obj_t arg1105_454;
{
obj_t arg1106_455;
arg1106_455 = symbol1322___match_expand;
{
obj_t list1108_457;
{
obj_t aux_916;
{
obj_t aux_917;
aux_917 = CDR(exp_3);
aux_916 = CDR(aux_917);
}
list1108_457 = MAKE_PAIR(aux_916, BNIL);
}
arg1105_454 = cons__138___r4_pairs_and_lists_6_3(arg1106_455, list1108_457);
}
}
arg1100_449 = expand_match_lambda_130___match_expand(arg1105_454);
}
{
obj_t aux_923;
aux_923 = CDR(exp_3);
arg1101_450 = CAR(aux_923);
}
{
obj_t list1102_451;
{
obj_t arg1103_452;
arg1103_452 = MAKE_PAIR(arg1101_450, BNIL);
list1102_451 = MAKE_PAIR(arg1100_449, arg1103_452);
}
return list1102_451;
}
}
}


/* _expand-match-case */obj_t _expand_match_case_13___match_expand(obj_t env_777, obj_t exp_778)
{
return expand_match_case_143___match_expand(exp_778);
}


/* imported-modules-init */obj_t imported_modules_init_94___match_expand()
{
module_initialization_70___error(((long)0), "__MATCH_EXPAND");
module_initialization_70___match_compiler(((long)0), "__MATCH_EXPAND");
module_initialization_70___match_descriptions(((long)0), "__MATCH_EXPAND");
module_initialization_70___match_normalize(((long)0), "__MATCH_EXPAND");
return module_initialization_70___match_s2cfun(((long)0), "__MATCH_EXPAND");
}

