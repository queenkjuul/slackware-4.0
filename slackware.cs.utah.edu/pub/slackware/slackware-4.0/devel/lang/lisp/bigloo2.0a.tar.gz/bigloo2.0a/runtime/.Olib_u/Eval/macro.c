/*===========================================================================*/
/*   (Eval/macro.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern long get_hash_number(char *);
static obj_t symbol1206___macro = BUNSPEC;
static obj_t _install_expander_130___macro(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63___macro();
extern obj_t install_eval_expander_92___macro(obj_t, obj_t);
extern obj_t warning___error(obj_t);
extern obj_t put_hash__129___hash(obj_t, obj_t);
extern obj_t install_compiler_expander_48___macro(obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t get_compiler_expander_150___macro(obj_t);
extern obj_t install_expander_245___macro(obj_t, obj_t);
static obj_t _get_eval_expander_30___macro(obj_t, obj_t);
static obj_t _install_compiler_expander_234___macro(obj_t, obj_t, obj_t);
extern obj_t get_eval_expander_232___macro(obj_t);
static obj_t _install_eval_expander_35___macro(obj_t, obj_t, obj_t);
static obj_t lambda1009___macro(obj_t, obj_t);
extern obj_t get_hash_29___hash(obj_t, obj_t);
extern obj_t module_initialization_70___macro(long, char *);
extern obj_t module_initialization_70___hash(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _get_compiler_expander_46___macro(obj_t, obj_t);
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
static obj_t _macros_key_51___macro(obj_t, obj_t);
static obj_t imported_modules_init_94___macro();
static obj_t _macro_table__91___macro = BUNSPEC;
static obj_t require_initialization_114___macro = BUNSPEC;
static obj_t cnst_init_137___macro();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( install_eval_expander_env_29___macro, _install_eval_expander_35___macro1213, _install_eval_expander_35___macro, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( get_eval_expander_env_96___macro, _get_eval_expander_30___macro1214, _get_eval_expander_30___macro, 0L, 1 );
DEFINE_STATIC_PROCEDURE( macros_key_env_196___macro, _macros_key_51___macro1215, _macros_key_51___macro, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( install_compiler_expander_env_164___macro, _install_compiler_expander_234___macro1216, _install_compiler_expander_234___macro, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( install_expander_env_113___macro, _install_expander_130___macro1217, _install_expander_130___macro, 0L, 2 );
extern obj_t eq__env_189___r4_equivalence_6_2;
DEFINE_EXPORT_PROCEDURE( get_compiler_expander_env_9___macro, _get_compiler_expander_46___macro1218, _get_compiler_expander_46___macro, 0L, 1 );
DEFINE_STRING( string1211___macro, string1211___macro1219, "install-compiler-expander", 25 );
DEFINE_STRING( string1209___macro, string1209___macro1220, "Illegal expander expander", 25 );
DEFINE_STRING( string1210___macro, string1210___macro1221, "Illegal expander keyword", 24 );
DEFINE_STRING( string1208___macro, string1208___macro1222, "install-eval-expander", 21 );
DEFINE_STRING( string1207___macro, string1207___macro1223, "Redefinition of expander -- ", 28 );


/* module-initialization */obj_t module_initialization_70___macro(long checksum_801, char * from_802)
{
if(CBOOL(require_initialization_114___macro)){
require_initialization_114___macro = BBOOL(((bool_t)0));
cnst_init_137___macro();
imported_modules_init_94___macro();
toplevel_init_63___macro();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___macro()
{
return (symbol1206___macro = string_to_symbol("MACROS"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___macro()
{
{
obj_t arg1007_345;
{
obj_t old_key_215_347;
obj_t old_num_119_348;
old_key_215_347 = MAKE_CELL(BFALSE);
old_num_119_348 = MAKE_CELL(BFALSE);
{
obj_t lambda1009_774;
lambda1009_774 = make_fx_procedure(lambda1009___macro, ((long)1), ((long)2));
PROCEDURE_SET(lambda1009_774, ((long)0), old_key_215_347);
PROCEDURE_SET(lambda1009_774, ((long)1), old_num_119_348);
arg1007_345 = lambda1009_774;
}
}
return (_macro_table__91___macro = make_hash_table_174___hash(((long)256), arg1007_345, macros_key_env_196___macro, eq__env_189___r4_equivalence_6_2, BNIL),
BUNSPEC);
}
}


/* lambda1009 */obj_t lambda1009___macro(obj_t env_775, obj_t x_778)
{
{
obj_t old_key_215_776;
obj_t old_num_119_777;
old_key_215_776 = PROCEDURE_REF(env_775, ((long)0));
old_num_119_777 = PROCEDURE_REF(env_775, ((long)1));
{
obj_t x_349;
x_349 = x_778;
{
bool_t test1010_351;
{
obj_t obj2_558;
obj2_558 = CELL_REF(old_key_215_776);
test1010_351 = (x_349==obj2_558);
}
if(test1010_351){
return CELL_REF(old_num_119_777);
}
 else {
CELL_SET(old_key_215_776, x_349);
{
obj_t aux_780;
{
obj_t arg1011_352;
arg1011_352 = SYMBOL_TO_STRING(x_349);
{
long aux_819;
{
char * aux_820;
aux_820 = BSTRING_TO_STRING(arg1011_352);
aux_819 = get_hash_number(aux_820);
}
aux_780 = BINT(aux_819);
}
}
CELL_SET(old_num_119_777, aux_780);
}
return CELL_REF(old_num_119_777);
}
}
}
}
}


/* _macros-key */obj_t _macros_key_51___macro(obj_t env_781, obj_t s_782)
{
{
obj_t s_800;
s_800 = s_782;
return STRUCT_REF(s_800, ((long)0));
}
}


/* install-eval-expander */obj_t install_eval_expander_92___macro(obj_t keyword_15, obj_t expander_16)
{
if(SYMBOLP(keyword_15)){
if(PROCEDUREP(expander_16)){
{
obj_t macro_372;
macro_372 = get_hash_29___hash(keyword_15, _macro_table__91___macro);
{
bool_t test1031_373;
{
obj_t o_603;
o_603 = macro_372;
if(STRUCTP(o_603)){
obj_t aux_832;
aux_832 = STRUCT_KEY(o_603);
test1031_373 = (aux_832==symbol1206___macro);
}
 else {
test1031_373 = ((bool_t)0);
}
}
if(test1031_373){
BUNSPEC;
}
 else {
{
obj_t new_614;
new_614 = create_struct(symbol1206___macro, ((long)3));
STRUCT_SET(new_614, ((long)2), BFALSE);
STRUCT_SET(new_614, ((long)1), BFALSE);
STRUCT_SET(new_614, ((long)0), keyword_15);
macro_372 = new_614;
}
put_hash__129___hash(macro_372, _macro_table__91___macro);
}
}
{
bool_t test1032_374;
{
obj_t s_632;
s_632 = macro_372;
{
obj_t aux_841;
aux_841 = STRUCT_REF(s_632, ((long)1));
test1032_374 = CBOOL(aux_841);
}
}
if(test1032_374){
obj_t list1033_375;
{
obj_t arg1035_377;
{
obj_t arg1038_379;
arg1038_379 = MAKE_PAIR(keyword_15, BNIL);
arg1035_377 = MAKE_PAIR(string1207___macro, arg1038_379);
}
list1033_375 = MAKE_PAIR(string1208___macro, arg1035_377);
}
warning___error(list1033_375);
}
 else {
BUNSPEC;
}
}
{
obj_t s_635;
s_635 = macro_372;
return STRUCT_SET(s_635, ((long)1), expander_16);
}
}
}
 else {
FAILURE(string1208___macro,string1209___macro,expander_16);}
}
 else {
FAILURE(string1208___macro,string1210___macro,keyword_15);}
}


/* _install-eval-expander */obj_t _install_eval_expander_35___macro(obj_t env_786, obj_t keyword_787, obj_t expander_788)
{
return install_eval_expander_92___macro(keyword_787, expander_788);
}


/* install-compiler-expander */obj_t install_compiler_expander_48___macro(obj_t keyword_17, obj_t expander_18)
{
if(SYMBOLP(keyword_17)){
if(PROCEDUREP(expander_18)){
{
obj_t macro_383;
macro_383 = get_hash_29___hash(keyword_17, _macro_table__91___macro);
{
bool_t test1042_384;
{
obj_t o_648;
o_648 = macro_383;
if(STRUCTP(o_648)){
obj_t aux_860;
aux_860 = STRUCT_KEY(o_648);
test1042_384 = (aux_860==symbol1206___macro);
}
 else {
test1042_384 = ((bool_t)0);
}
}
if(test1042_384){
BUNSPEC;
}
 else {
{
obj_t new_659;
new_659 = create_struct(symbol1206___macro, ((long)3));
STRUCT_SET(new_659, ((long)2), BFALSE);
STRUCT_SET(new_659, ((long)1), BFALSE);
STRUCT_SET(new_659, ((long)0), keyword_17);
macro_383 = new_659;
}
put_hash__129___hash(macro_383, _macro_table__91___macro);
}
}
{
bool_t test1043_385;
{
obj_t s_677;
s_677 = macro_383;
{
obj_t aux_869;
aux_869 = STRUCT_REF(s_677, ((long)2));
test1043_385 = CBOOL(aux_869);
}
}
if(test1043_385){
obj_t list1044_386;
{
obj_t arg1046_388;
{
obj_t arg1048_390;
arg1048_390 = MAKE_PAIR(keyword_17, BNIL);
arg1046_388 = MAKE_PAIR(string1207___macro, arg1048_390);
}
list1044_386 = MAKE_PAIR(string1211___macro, arg1046_388);
}
warning___error(list1044_386);
}
 else {
BUNSPEC;
}
}
{
obj_t s_680;
s_680 = macro_383;
return STRUCT_SET(s_680, ((long)2), expander_18);
}
}
}
 else {
FAILURE(string1208___macro,string1209___macro,expander_18);}
}
 else {
FAILURE(string1208___macro,string1210___macro,keyword_17);}
}


/* _install-compiler-expander */obj_t _install_compiler_expander_234___macro(obj_t env_789, obj_t keyword_790, obj_t expander_791)
{
return install_compiler_expander_48___macro(keyword_790, expander_791);
}


/* install-expander */obj_t install_expander_245___macro(obj_t keyword_19, obj_t expander_20)
{
if(SYMBOLP(keyword_19)){
if(PROCEDUREP(expander_20)){
{
obj_t macro_394;
macro_394 = get_hash_29___hash(keyword_19, _macro_table__91___macro);
{
bool_t test1052_395;
{
obj_t o_693;
o_693 = macro_394;
if(STRUCTP(o_693)){
obj_t aux_888;
aux_888 = STRUCT_KEY(o_693);
test1052_395 = (aux_888==symbol1206___macro);
}
 else {
test1052_395 = ((bool_t)0);
}
}
if(test1052_395){
BUNSPEC;
}
 else {
{
obj_t new_704;
new_704 = create_struct(symbol1206___macro, ((long)3));
STRUCT_SET(new_704, ((long)2), BFALSE);
STRUCT_SET(new_704, ((long)1), BFALSE);
STRUCT_SET(new_704, ((long)0), keyword_19);
macro_394 = new_704;
}
put_hash__129___hash(macro_394, _macro_table__91___macro);
}
}
{
bool_t test1053_396;
{
obj_t s_722;
s_722 = macro_394;
{
obj_t aux_897;
aux_897 = STRUCT_REF(s_722, ((long)1));
test1053_396 = CBOOL(aux_897);
}
}
if(test1053_396){
obj_t list1054_397;
{
obj_t arg1056_399;
{
obj_t arg1058_401;
arg1058_401 = MAKE_PAIR(keyword_19, BNIL);
arg1056_399 = MAKE_PAIR(string1207___macro, arg1058_401);
}
list1054_397 = MAKE_PAIR(string1208___macro, arg1056_399);
}
warning___error(list1054_397);
}
 else {
BUNSPEC;
}
}
{
bool_t test1060_403;
{
obj_t s_725;
s_725 = macro_394;
{
obj_t aux_905;
aux_905 = STRUCT_REF(s_725, ((long)2));
test1060_403 = CBOOL(aux_905);
}
}
if(test1060_403){
obj_t list1061_404;
{
obj_t arg1063_406;
{
obj_t arg1066_408;
arg1066_408 = MAKE_PAIR(keyword_19, BNIL);
arg1063_406 = MAKE_PAIR(string1207___macro, arg1066_408);
}
list1061_404 = MAKE_PAIR(string1211___macro, arg1063_406);
}
warning___error(list1061_404);
}
 else {
BUNSPEC;
}
}
{
obj_t s_728;
s_728 = macro_394;
STRUCT_SET(s_728, ((long)1), expander_20);
}
{
obj_t s_733;
s_733 = macro_394;
return STRUCT_SET(s_733, ((long)2), expander_20);
}
}
}
 else {
FAILURE(string1208___macro,string1209___macro,expander_20);}
}
 else {
FAILURE(string1208___macro,string1210___macro,keyword_19);}
}


/* _install-expander */obj_t _install_expander_130___macro(obj_t env_792, obj_t keyword_793, obj_t expander_794)
{
return install_expander_245___macro(keyword_793, expander_794);
}


/* get-eval-expander */obj_t get_eval_expander_232___macro(obj_t keyword_21)
{
{
obj_t macro_744;
macro_744 = get_hash_29___hash(keyword_21, _macro_table__91___macro);
{
bool_t test_919;
if(STRUCTP(macro_744)){
obj_t aux_922;
aux_922 = STRUCT_KEY(macro_744);
test_919 = (aux_922==symbol1206___macro);
}
 else {
test_919 = ((bool_t)0);
}
if(test_919){
return STRUCT_REF(macro_744, ((long)1));
}
 else {
return BFALSE;
}
}
}
}


/* _get-eval-expander */obj_t _get_eval_expander_30___macro(obj_t env_795, obj_t keyword_796)
{
return get_eval_expander_232___macro(keyword_796);
}


/* get-compiler-expander */obj_t get_compiler_expander_150___macro(obj_t keyword_22)
{
{
obj_t macro_757;
macro_757 = get_hash_29___hash(keyword_22, _macro_table__91___macro);
{
bool_t test_928;
if(STRUCTP(macro_757)){
obj_t aux_931;
aux_931 = STRUCT_KEY(macro_757);
test_928 = (aux_931==symbol1206___macro);
}
 else {
test_928 = ((bool_t)0);
}
if(test_928){
return STRUCT_REF(macro_757, ((long)2));
}
 else {
return BFALSE;
}
}
}
}


/* _get-compiler-expander */obj_t _get_compiler_expander_46___macro(obj_t env_797, obj_t keyword_798)
{
return get_compiler_expander_150___macro(keyword_798);
}


/* imported-modules-init */obj_t imported_modules_init_94___macro()
{
module_initialization_70___error(((long)0), "__MACRO");
return module_initialization_70___hash(((long)0), "__MACRO");
}

