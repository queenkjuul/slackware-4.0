/*===========================================================================*/
/*   (Module/foreign.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;


extern obj_t ccomp_module_module;
extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_module_foreign();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t foreign_producer_77_module_foreign(obj_t);
extern obj_t make_ctype_accesses__219_foreign_access(type_t, type_t);
extern obj_t type_type_type;
static obj_t _foreign_exported__195_module_foreign = BUNSPEC;
extern obj_t user_warning_209_tools_error(obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t make_foreign_compiler_237_module_foreign();
extern type_t declare_type__118_type_env(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t declare_c_type__49_foreign_ctype(obj_t, obj_t, obj_t, obj_t);
extern global_t declare_global_cvar__13_ast_glo_decl_237(obj_t, obj_t, obj_t, bool_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t parse_c_foreign_type_105_module_foreign(obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _clause_checksummer2236_203_module_checksum(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_module_foreign(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_checksum(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_glo_decl_237(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern long class_num_218___object(obj_t);
static obj_t extern_parser_240_module_foreign(obj_t);
static obj_t _foreign_accesses__124_module_foreign = BUNSPEC;
static obj_t imported_modules_init_94_module_foreign();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t cstruct_foreign_ctype;
static obj_t _make_extern_compiler_52_module_foreign(obj_t);
static obj_t _foreign_finalizer_56_module_foreign(obj_t);
static obj_t extern_producer_85_module_foreign(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_foreign();
static obj_t foreign_finalizer_169_module_foreign();
static obj_t toplevel_init_63_module_foreign();
extern obj_t open_input_string(obj_t);
extern global_t declare_global_cfun__81_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t);
static obj_t parse_c_extern_type_73_module_foreign(obj_t);
static obj_t c_extern_type__c_foreign_type_30_module_foreign(obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
static obj_t _extern_producer_53_module_foreign(obj_t, obj_t);
extern obj_t make_extern_compiler_102_module_foreign();
extern obj_t check_id_6_ast_ident(obj_t, obj_t);
extern obj_t _include_foreign__253_engine_param;
static bool_t check_c_foreign_type_exp__43_module_foreign(obj_t);
static obj_t arg1351_module_foreign(obj_t);
static obj_t arg1350_module_foreign(obj_t, obj_t, obj_t);
static obj_t arg1342_module_foreign(obj_t, obj_t, obj_t);
static obj_t foreign_parser_183_module_foreign(obj_t);
static obj_t _make_foreign_compiler_123_module_foreign(obj_t);
static bool_t check_c_args__102_module_foreign(obj_t);
extern obj_t calias_foreign_ctype;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t make_pointer_to_name_76_type_tools(type_t);
static obj_t _foreign_producer_163_module_foreign(obj_t, obj_t);
static obj_t require_initialization_114_module_foreign = BUNSPEC;
static obj_t cnst_init_137_module_foreign();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[19];

DEFINE_STATIC_PROCEDURE(foreign_producer_env_169_module_foreign, _foreign_producer_163_module_foreign2260, _foreign_producer_163_module_foreign, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_extern_compiler_env_153_module_foreign, _make_extern_compiler_52_module_foreign2261, _make_extern_compiler_52_module_foreign, 0L, 0);
extern obj_t clause_checksummer_env_74_module_checksum;
DEFINE_STATIC_PROCEDURE(proc2239_module_foreign, arg1350_module_foreign2262, arg1350_module_foreign, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2238_module_foreign, arg1351_module_foreign2263, arg1351_module_foreign, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc2237_module_foreign, arg1342_module_foreign2264, arg1342_module_foreign, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_foreign_compiler_env_30_module_foreign, _make_foreign_compiler_123_module_foreign2265, _make_foreign_compiler_123_module_foreign, 0L, 0);
DEFINE_STRING(string2254_module_foreign, string2254_module_foreign2266, "UNIT UNION* STRUCT* ARRAY ENUM FUNCTION POINTER STRUCT UNION C * MACRO EXPORT TYPE INCLUDE INFIX VOID EXTERN FOREIGN ", 117);
DEFINE_STRING(string2253_module_foreign, string2253_module_foreign2267, "Unbound global variable", 23);
DEFINE_STRING(string2252_module_foreign, string2252_module_foreign2268, "Re-exportation of global variable (ignored)", 43);
DEFINE_STRING(string2251_module_foreign, string2251_module_foreign2269, "Foreign", 7);
DEFINE_STRING(string2249_module_foreign, string2249_module_foreign2270, "Illegal `C foreign type'", 24);
DEFINE_STRING(string2250_module_foreign, string2250_module_foreign2271, "Illegal `C extern type'", 23);
DEFINE_STRING(string2248_module_foreign, string2248_module_foreign2272, "Illegal extern form", 19);
DEFINE_STRING(string2247_module_foreign, string2247_module_foreign2273, "Illegal `variable' form", 23);
DEFINE_STRING(string2246_module_foreign, string2246_module_foreign2274, "Illegal `function' form", 23);
DEFINE_STRING(string2245_module_foreign, string2245_module_foreign2275, "Illegal `macro' form", 20);
DEFINE_STRING(string2244_module_foreign, string2244_module_foreign2276, "Illegal foreign form", 20);
DEFINE_STRING(string2243_module_foreign, string2243_module_foreign2277, "Illegal `include' clause", 24);
DEFINE_STRING(string2242_module_foreign, string2242_module_foreign2278, "Illegal `extern' clause", 23);
DEFINE_STRING(string2241_module_foreign, string2241_module_foreign2279, "Parse error", 11);
DEFINE_STRING(string2240_module_foreign, string2240_module_foreign2280, "Illegal `foreign' clause", 24);
DEFINE_STATIC_PROCEDURE(foreign_finalizer_env_182_module_foreign, _foreign_finalizer_56_module_foreign2281, _foreign_finalizer_56_module_foreign, 0L, 0);
DEFINE_STATIC_PROCEDURE(extern_producer_env_171_module_foreign, _extern_producer_53_module_foreign2282, _extern_producer_53_module_foreign, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_module_foreign(long checksum_2893, char *from_2894)
{
   if (CBOOL(require_initialization_114_module_foreign))
     {
	require_initialization_114_module_foreign = BBOOL(((bool_t) 0));
	library_modules_init_112_module_foreign();
	cnst_init_137_module_foreign();
	imported_modules_init_94_module_foreign();
	method_init_76_module_foreign();
	toplevel_init_63_module_foreign();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_foreign()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "MODULE_FOREIGN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_FOREIGN");
   module_initialization_70___object(((long) 0), "MODULE_FOREIGN");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_FOREIGN");
   module_initialization_70___reader(((long) 0), "MODULE_FOREIGN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_foreign()
{
   {
      obj_t cnst_port_138_2885;
      cnst_port_138_2885 = open_input_string(string2254_module_foreign);
      {
	 long i_2886;
	 i_2886 = ((long) 18);
       loop_2887:
	 {
	    bool_t test2255_2888;
	    test2255_2888 = (i_2886 == ((long) -1));
	    if (test2255_2888)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2256_2889;
		    {
		       obj_t list2257_2890;
		       {
			  obj_t arg2258_2891;
			  arg2258_2891 = BNIL;
			  list2257_2890 = MAKE_PAIR(cnst_port_138_2885, arg2258_2891);
		       }
		       arg2256_2889 = read___reader(list2257_2890);
		    }
		    CNST_TABLE_SET(i_2886, arg2256_2889);
		 }
		 {
		    int aux_2892;
		    {
		       long aux_2914;
		       aux_2914 = (i_2886 - ((long) 1));
		       aux_2892 = (int) (aux_2914);
		    }
		    {
		       long i_2917;
		       i_2917 = (long) (aux_2892);
		       i_2886 = i_2917;
		       goto loop_2887;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_foreign()
{
   _foreign_accesses__124_module_foreign = BNIL;
   return (_foreign_exported__195_module_foreign = BNIL,
      BUNSPEC);
}


/* make-foreign-compiler */ obj_t 
make_foreign_compiler_237_module_foreign()
{
   {
      obj_t arg1339_687;
      arg1339_687 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1342_2859;
	 arg1342_2859 = proc2237_module_foreign;
	 {
	    ccomp_t res2232_1993;
	    {
	       ccomp_t new1008_1984;
	       new1008_1984 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg2230_1985;
		  arg2230_1985 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_1991;
		     obj_1991 = (obj_t) (new1008_1984);
		     (((obj_t) CREF(obj_1991))->header = MAKE_HEADER(arg2230_1985, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_2924;
		  aux_2924 = (object_t) (new1008_1984);
		  OBJECT_WIDENING_SET(aux_2924, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1008_1984))->id) = ((obj_t) arg1339_687), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1984))->producer) = ((obj_t) foreign_producer_env_169_module_foreign), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1984))->consumer) = ((obj_t) arg1342_2859), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1984))->finalizer) = ((obj_t) foreign_finalizer_env_182_module_foreign), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1984))->checksummer) = ((obj_t) clause_checksummer_env_74_module_checksum), BUNSPEC);
	       res2232_1993 = new1008_1984;
	    }
	    return (obj_t) (res2232_1993);
	 }
      }
   }
}


/* _make-foreign-compiler */ obj_t 
_make_foreign_compiler_123_module_foreign(obj_t env_2860)
{
   return make_foreign_compiler_237_module_foreign();
}


/* arg1342 */ obj_t 
arg1342_module_foreign(obj_t env_2861, obj_t m_2862, obj_t c_2863)
{
   {
      obj_t m_692;
      obj_t c_693;
      m_692 = m_2862;
      c_693 = c_2863;
      return foreign_producer_77_module_foreign(c_693);
   }
}


/* make-extern-compiler */ obj_t 
make_extern_compiler_102_module_foreign()
{
   {
      obj_t arg1347_696;
      arg1347_696 = CNST_TABLE_REF(((long) 1));
      {
	 obj_t arg1351_2870;
	 obj_t arg1350_2871;
	 arg1351_2870 = proc2238_module_foreign;
	 arg1350_2871 = proc2239_module_foreign;
	 {
	    ccomp_t res2233_2006;
	    {
	       ccomp_t new1008_1997;
	       new1008_1997 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg2230_1998;
		  arg2230_1998 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_2004;
		     obj_2004 = (obj_t) (new1008_1997);
		     (((obj_t) CREF(obj_2004))->header = MAKE_HEADER(arg2230_1998, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_2940;
		  aux_2940 = (object_t) (new1008_1997);
		  OBJECT_WIDENING_SET(aux_2940, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1008_1997))->id) = ((obj_t) arg1347_696), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1997))->producer) = ((obj_t) extern_producer_env_171_module_foreign), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1997))->consumer) = ((obj_t) arg1350_2871), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1997))->finalizer) = ((obj_t) arg1351_2870), BUNSPEC);
	       ((((ccomp_t) CREF(new1008_1997))->checksummer) = ((obj_t) clause_checksummer_env_74_module_checksum), BUNSPEC);
	       res2233_2006 = new1008_1997;
	    }
	    return (obj_t) (res2233_2006);
	 }
      }
   }
}


/* _make-extern-compiler */ obj_t 
_make_extern_compiler_52_module_foreign(obj_t env_2872)
{
   return make_extern_compiler_102_module_foreign();
}


/* arg1351 */ obj_t 
arg1351_module_foreign(obj_t env_2873)
{
   {
      return CNST_TABLE_REF(((long) 2));
   }
}


/* arg1350 */ obj_t 
arg1350_module_foreign(obj_t env_2874, obj_t m_2875, obj_t c_2876)
{
   {
      obj_t m_701;
      obj_t c_702;
      m_701 = m_2875;
      c_702 = c_2876;
      return extern_producer_85_module_foreign(c_702);
   }
}


/* foreign-producer */ obj_t 
foreign_producer_77_module_foreign(obj_t clause_19)
{
   {
      obj_t protos_707;
      if (PAIRP(clause_19))
	{
	   protos_707 = CDR(clause_19);
	   {
	      obj_t l1311_713;
	      l1311_713 = protos_707;
	    lname1312_714:
	      if (PAIRP(l1311_713))
		{
		   foreign_parser_183_module_foreign(CAR(l1311_713));
		   {
		      obj_t l1311_2958;
		      l1311_2958 = CDR(l1311_713);
		      l1311_713 = l1311_2958;
		      goto lname1312_714;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return BNIL;
	}
      else
	{
	   {
	      obj_t arg1365_719;
	      {
		 obj_t list1370_723;
		 list1370_723 = MAKE_PAIR(string2240_module_foreign, BNIL);
		 arg1365_719 = string_append_106___r4_strings_6_7(list1370_723);
	      }
	      {
		 obj_t list1368_721;
		 list1368_721 = MAKE_PAIR(BNIL, BNIL);
		 return user_error_151_tools_error(string2241_module_foreign, arg1365_719, clause_19, list1368_721);
	      }
	   }
	}
   }
}


/* _foreign-producer */ obj_t 
_foreign_producer_163_module_foreign(obj_t env_2864, obj_t clause_2865)
{
   return foreign_producer_77_module_foreign(clause_2865);
}


/* extern-producer */ obj_t 
extern_producer_85_module_foreign(obj_t clause_20)
{
   {
      obj_t protos_726;
      if (PAIRP(clause_20))
	{
	   protos_726 = CDR(clause_20);
	   {
	      obj_t l1313_732;
	      l1313_732 = protos_726;
	    lname1314_733:
	      if (PAIRP(l1313_732))
		{
		   extern_parser_240_module_foreign(CAR(l1313_732));
		   {
		      obj_t l1313_2972;
		      l1313_2972 = CDR(l1313_732);
		      l1313_732 = l1313_2972;
		      goto lname1314_733;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   return BNIL;
	}
      else
	{
	   {
	      obj_t arg1383_738;
	      {
		 obj_t list1388_742;
		 list1388_742 = MAKE_PAIR(string2242_module_foreign, BNIL);
		 arg1383_738 = string_append_106___r4_strings_6_7(list1388_742);
	      }
	      {
		 obj_t list1385_740;
		 list1385_740 = MAKE_PAIR(BNIL, BNIL);
		 return user_error_151_tools_error(string2241_module_foreign, arg1383_738, clause_20, list1385_740);
	      }
	   }
	}
   }
}


/* _extern-producer */ obj_t 
_extern_producer_53_module_foreign(obj_t env_2877, obj_t clause_2878)
{
   return extern_producer_85_module_foreign(clause_2878);
}


/* check-c-args? */ bool_t 
check_c_args__102_module_foreign(obj_t proto_21)
{
   {
      obj_t proto_745;
      proto_745 = proto_21;
    loop_746:
      if (NULLP(proto_745))
	{
	   return ((bool_t) 1);
	}
      else
	{
	   if (SYMBOLP(proto_745))
	     {
		return ((bool_t) 1);
	     }
	   else
	     {
		if (PAIRP(proto_745))
		  {
		     bool_t test_2986;
		     {
			obj_t aux_2987;
			aux_2987 = CAR(proto_745);
			test_2986 = SYMBOLP(aux_2987);
		     }
		     if (test_2986)
		       {
			  {
			     obj_t proto_2990;
			     proto_2990 = CDR(proto_745);
			     proto_745 = proto_2990;
			     goto loop_746;
			  }
		       }
		     else
		       {
			  return ((bool_t) 0);
		       }
		  }
		else
		  {
		     return ((bool_t) 0);
		  }
	     }
	}
   }
}


/* foreign-parser */ obj_t 
foreign_parser_183_module_foreign(obj_t foreign_22)
{
   {
      obj_t type_775;
      obj_t l_name_185_776;
      obj_t c_name_211_777;
      obj_t type_770;
      obj_t l_name_185_771;
      obj_t proto_772;
      obj_t c_name_211_773;
      obj_t type_765;
      obj_t l_name_185_766;
      obj_t c_name_211_767;
      obj_t type_760;
      obj_t l_name_185_761;
      obj_t proto_762;
      obj_t c_name_211_763;
      obj_t string_753;
      if (PAIRP(foreign_22))
	{
	   obj_t cdr_156_22_782;
	   cdr_156_22_782 = CDR(foreign_22);
	   {
	      bool_t test_2995;
	      {
		 obj_t aux_2998;
		 obj_t aux_2996;
		 aux_2998 = CNST_TABLE_REF(((long) 4));
		 aux_2996 = CAR(foreign_22);
		 test_2995 = (aux_2996 == aux_2998);
	      }
	      if (test_2995)
		{
		   if (PAIRP(cdr_156_22_782))
		     {
			bool_t test_3003;
			{
			   obj_t aux_3004;
			   aux_3004 = CDR(cdr_156_22_782);
			   test_3003 = (aux_3004 == BNIL);
			}
			if (test_3003)
			  {
			     string_753 = CAR(cdr_156_22_782);
			     if (STRINGP(string_753))
			       {
				  bool_t test1524_918;
				  {
				     obj_t aux_3009;
				     aux_3009 = member___r4_pairs_and_lists_6_3(string_753, _include_foreign__253_engine_param);
				     test1524_918 = CBOOL(aux_3009);
				  }
				  if (test1524_918)
				    {
				       return BUNSPEC;
				    }
				  else
				    {
				       obj_t obj2_2165;
				       obj2_2165 = _include_foreign__253_engine_param;
				       return (_include_foreign__253_engine_param = MAKE_PAIR(string_753, obj2_2165),
					  BUNSPEC);
				    }
			       }
			     else
			       {
				  obj_t list1528_922;
				  list1528_922 = MAKE_PAIR(BNIL, BNIL);
				  return user_error_151_tools_error(string2241_module_foreign, string2243_module_foreign, foreign_22, list1528_922);
			       }
			  }
			else
			  {
			   tag_139_224_759:
			     {
				obj_t list1533_927;
				list1533_927 = MAKE_PAIR(BNIL, BNIL);
				return user_error_151_tools_error(string2241_module_foreign, string2244_module_foreign, foreign_22, list1533_927);
			     }
			  }
		     }
		   else
		     {
			goto tag_139_224_759;
		     }
		}
	      else
		{
		   bool_t test_3019;
		   {
		      obj_t aux_3022;
		      obj_t aux_3020;
		      aux_3022 = CNST_TABLE_REF(((long) 5));
		      aux_3020 = CAR(foreign_22);
		      test_3019 = (aux_3020 == aux_3022);
		   }
		   if (test_3019)
		     {
			return parse_c_foreign_type_105_module_foreign(foreign_22);
		     }
		   else
		     {
			bool_t test_3026;
			{
			   obj_t aux_3029;
			   obj_t aux_3027;
			   aux_3029 = CNST_TABLE_REF(((long) 6));
			   aux_3027 = CAR(foreign_22);
			   test_3026 = (aux_3027 == aux_3029);
			}
			if (test_3026)
			  {
			     if (PAIRP(cdr_156_22_782))
			       {
				  obj_t cdr_218_104_794;
				  cdr_218_104_794 = CDR(cdr_156_22_782);
				  {
				     bool_t test_3035;
				     {
					obj_t aux_3036;
					aux_3036 = CAR(cdr_156_22_782);
					test_3035 = SYMBOLP(aux_3036);
				     }
				     if (test_3035)
				       {
					  if (PAIRP(cdr_218_104_794))
					    {
					       bool_t test_3041;
					       {
						  obj_t aux_3042;
						  aux_3042 = CAR(cdr_218_104_794);
						  test_3041 = STRINGP(aux_3042);
					       }
					       if (test_3041)
						 {
						    bool_t test_3045;
						    {
						       obj_t aux_3046;
						       aux_3046 = CDR(cdr_218_104_794);
						       test_3045 = (aux_3046 == BNIL);
						    }
						    if (test_3045)
						      {
							 obj_t obj2_2053;
							 obj2_2053 = _foreign_exported__195_module_foreign;
							 return (_foreign_exported__195_module_foreign = MAKE_PAIR(foreign_22, obj2_2053),
							    BUNSPEC);
						      }
						    else
						      {
							 goto tag_139_224_759;
						      }
						 }
					       else
						 {
						    goto tag_139_224_759;
						 }
					    }
					  else
					    {
					       goto tag_139_224_759;
					    }
				       }
				     else
				       {
					  goto tag_139_224_759;
				       }
				  }
			       }
			     else
			       {
				  goto tag_139_224_759;
			       }
			  }
			else
			  {
			     bool_t test_3050;
			     {
				obj_t aux_3053;
				obj_t aux_3051;
				aux_3053 = CNST_TABLE_REF(((long) 7));
				aux_3051 = CAR(foreign_22);
				test_3050 = (aux_3051 == aux_3053);
			     }
			     if (test_3050)
			       {
				  if (PAIRP(cdr_156_22_782))
				    {
				       obj_t cdr_276_172_805;
				       cdr_276_172_805 = CDR(cdr_156_22_782);
				       if (PAIRP(cdr_276_172_805))
					 {
					    obj_t cdr_282_255_807;
					    cdr_282_255_807 = CDR(cdr_276_172_805);
					    if (PAIRP(cdr_282_255_807))
					      {
						 obj_t cdr_287_201_809;
						 cdr_287_201_809 = CDR(cdr_282_255_807);
						 if (PAIRP(cdr_287_201_809))
						   {
						      bool_t test_3067;
						      {
							 obj_t aux_3068;
							 aux_3068 = CDR(cdr_287_201_809);
							 test_3067 = (aux_3068 == BNIL);
						      }
						      if (test_3067)
							{
							   type_760 = CAR(cdr_156_22_782);
							   l_name_185_761 = CAR(cdr_276_172_805);
							   proto_762 = CAR(cdr_282_255_807);
							   c_name_211_763 = CAR(cdr_287_201_809);
							 tag_140_156_764:
							   {
							      bool_t test_3071;
							      if (STRINGP(c_name_211_763))
								{
								   if (SYMBOLP(type_760))
								     {
									if (SYMBOLP(l_name_185_761))
									  {
									     test_3071 = check_c_args__102_module_foreign(proto_762);
									  }
									else
									  {
									     test_3071 = ((bool_t) 0);
									  }
								     }
								   else
								     {
									test_3071 = ((bool_t) 0);
								     }
								}
							      else
								{
								   test_3071 = ((bool_t) 0);
								}
							      if (test_3071)
								{
								   global_t aux_3079;
								   {
								      bool_t aux_3080;
								      {
									 obj_t aux_3083;
									 obj_t aux_3081;
									 aux_3083 = CNST_TABLE_REF(((long) 3));
									 aux_3081 = CAR(foreign_22);
									 aux_3080 = (aux_3081 == aux_3083);
								      }
								      aux_3079 = declare_global_cfun__81_ast_glo_decl_237(l_name_185_761, c_name_211_763, type_760, proto_762, aux_3080, ((bool_t) 1), foreign_22);
								   }
								   return (obj_t) (aux_3079);
								}
							      else
								{
								   obj_t list1546_936;
								   list1546_936 = MAKE_PAIR(BNIL, BNIL);
								   return user_error_151_tools_error(string2241_module_foreign, string2245_module_foreign, foreign_22, list1546_936);
								}
							   }
							}
						      else
							{
							 tag_142_79_769:
							   {
							      obj_t list1563_952;
							      list1563_952 = MAKE_PAIR(BNIL, BNIL);
							      return user_error_151_tools_error(string2241_module_foreign, string2244_module_foreign, foreign_22, list1563_952);
							   }
							}
						   }
						 else
						   {
						      obj_t cdr_334_205_819;
						      cdr_334_205_819 = CDR(cdr_156_22_782);
						      {
							 obj_t cdr_342_170_820;
							 cdr_342_170_820 = CDR(cdr_334_205_819);
							 {
							    bool_t test_3098;
							    {
							       obj_t aux_3099;
							       aux_3099 = CDR(cdr_342_170_820);
							       test_3098 = (aux_3099 == BNIL);
							    }
							    if (test_3098)
							      {
								 type_765 = CAR(cdr_156_22_782);
								 l_name_185_766 = CAR(cdr_334_205_819);
								 c_name_211_767 = CAR(cdr_342_170_820);
								 {
								    bool_t test_3102;
								    if (STRINGP(c_name_211_767))
								      {
									 if (SYMBOLP(type_765))
									   {
									      test_3102 = SYMBOLP(l_name_185_766);
									   }
									 else
									   {
									      test_3102 = ((bool_t) 0);
									   }
								      }
								    else
								      {
									 test_3102 = ((bool_t) 0);
								      }
								    if (test_3102)
								      {
									 global_t aux_3108;
									 aux_3108 = declare_global_cvar__13_ast_glo_decl_237(l_name_185_766, c_name_211_767, type_765, ((bool_t) 1), foreign_22);
									 return (obj_t) (aux_3108);
								      }
								    else
								      {
									 obj_t list1556_945;
									 list1556_945 = MAKE_PAIR(BNIL, BNIL);
									 return user_error_151_tools_error(string2241_module_foreign, string2245_module_foreign, foreign_22, list1556_945);
								      }
								 }
							      }
							    else
							      {
								 goto tag_142_79_769;
							      }
							 }
						      }
						   }
					      }
					    else
					      {
						 goto tag_142_79_769;
					      }
					 }
				       else
					 {
					    goto tag_142_79_769;
					 }
				    }
				  else
				    {
				       goto tag_142_79_769;
				    }
			       }
			     else
			       {
				  bool_t test_3116;
				  {
				     obj_t aux_3119;
				     obj_t aux_3117;
				     aux_3119 = CNST_TABLE_REF(((long) 3));
				     aux_3117 = CAR(foreign_22);
				     test_3116 = (aux_3117 == aux_3119);
				  }
				  if (test_3116)
				    {
				       if (PAIRP(cdr_156_22_782))
					 {
					    obj_t cdr_414_70_830;
					    cdr_414_70_830 = CDR(cdr_156_22_782);
					    {
					       bool_t test_3125;
					       {
						  obj_t aux_3128;
						  obj_t aux_3126;
						  aux_3128 = CNST_TABLE_REF(((long) 7));
						  aux_3126 = CAR(cdr_156_22_782);
						  test_3125 = (aux_3126 == aux_3128);
					       }
					       if (test_3125)
						 {
						    if (PAIRP(cdr_414_70_830))
						      {
							 obj_t cdr_420_191_833;
							 cdr_420_191_833 = CDR(cdr_414_70_830);
							 if (PAIRP(cdr_420_191_833))
							   {
							      obj_t cdr_426_228_835;
							      cdr_426_228_835 = CDR(cdr_420_191_833);
							      if (PAIRP(cdr_426_228_835))
								{
								   obj_t cdr_431_26_837;
								   cdr_431_26_837 = CDR(cdr_426_228_835);
								   if (PAIRP(cdr_431_26_837))
								     {
									bool_t test_3142;
									{
									   obj_t aux_3143;
									   aux_3143 = CDR(cdr_431_26_837);
									   test_3142 = (aux_3143 == BNIL);
									}
									if (test_3142)
									  {
									     obj_t c_name_211_3152;
									     obj_t proto_3150;
									     obj_t l_name_185_3148;
									     obj_t type_3146;
									     type_3146 = CAR(cdr_414_70_830);
									     l_name_185_3148 = CAR(cdr_420_191_833);
									     proto_3150 = CAR(cdr_426_228_835);
									     c_name_211_3152 = CAR(cdr_431_26_837);
									     c_name_211_763 = c_name_211_3152;
									     proto_762 = proto_3150;
									     l_name_185_761 = l_name_185_3148;
									     type_760 = type_3146;
									     goto tag_140_156_764;
									  }
									else
									  {
									   tag_145_198_779:
									     {
										obj_t list1589_974;
										list1589_974 = MAKE_PAIR(BNIL, BNIL);
										return user_error_151_tools_error(string2241_module_foreign, string2244_module_foreign, foreign_22, list1589_974);
									     }
									  }
								     }
								   else
								     {
									goto tag_145_198_779;
								     }
								}
							      else
								{
								   obj_t cdr_523_105_847;
								   cdr_523_105_847 = CDR(cdr_156_22_782);
								   {
								      obj_t cdr_530_222_848;
								      cdr_530_222_848 = CDR(cdr_523_105_847);
								      {
									 bool_t test_3158;
									 {
									    obj_t aux_3159;
									    aux_3159 = CDR(cdr_530_222_848);
									    test_3158 = (aux_3159 == BNIL);
									 }
									 if (test_3158)
									   {
									      type_770 = CAR(foreign_22);
									      l_name_185_771 = CAR(cdr_156_22_782);
									      proto_772 = CAR(cdr_523_105_847);
									      c_name_211_773 = CAR(cdr_530_222_848);
									    tag_143_46_774:
									      {
										 bool_t test_3162;
										 if (STRINGP(c_name_211_773))
										   {
										      if (SYMBOLP(type_770))
											{
											   if (SYMBOLP(l_name_185_771))
											     {
												test_3162 = check_c_args__102_module_foreign(proto_772);
											     }
											   else
											     {
												test_3162 = ((bool_t) 0);
											     }
											}
										      else
											{
											   test_3162 = ((bool_t) 0);
											}
										   }
										 else
										   {
										      test_3162 = ((bool_t) 0);
										   }
										 if (test_3162)
										   {
										      global_t aux_3170;
										      aux_3170 = declare_global_cfun__81_ast_glo_decl_237(l_name_185_771, c_name_211_773, type_770, proto_772, ((bool_t) 0), ((bool_t) 0), foreign_22);
										      return (obj_t) (aux_3170);
										   }
										 else
										   {
										      obj_t list1570_958;
										      list1570_958 = MAKE_PAIR(BNIL, BNIL);
										      return user_error_151_tools_error(string2241_module_foreign, string2246_module_foreign, foreign_22, list1570_958);
										   }
									      }
									   }
									 else
									   {
									      goto tag_145_198_779;
									   }
								      }
								   }
								}
							   }
							 else
							   {
							      obj_t cdr_579_43_857;
							      cdr_579_43_857 = CDR(cdr_156_22_782);
							      {
								 bool_t test_3180;
								 {
								    obj_t aux_3181;
								    aux_3181 = CDR(cdr_579_43_857);
								    test_3180 = (aux_3181 == BNIL);
								 }
								 if (test_3180)
								   {
								      type_775 = CAR(foreign_22);
								      l_name_185_776 = CAR(cdr_156_22_782);
								      c_name_211_777 = CAR(cdr_579_43_857);
								    tag_144_168_778:
								      {
									 bool_t test_3184;
									 if (STRINGP(c_name_211_777))
									   {
									      if (SYMBOLP(type_775))
										{
										   test_3184 = SYMBOLP(l_name_185_776);
										}
									      else
										{
										   test_3184 = ((bool_t) 0);
										}
									   }
									 else
									   {
									      test_3184 = ((bool_t) 0);
									   }
									 if (test_3184)
									   {
									      global_t aux_3190;
									      aux_3190 = declare_global_cvar__13_ast_glo_decl_237(l_name_185_776, c_name_211_777, type_775, ((bool_t) 0), foreign_22);
									      return (obj_t) (aux_3190);
									   }
									 else
									   {
									      obj_t list1582_967;
									      list1582_967 = MAKE_PAIR(BNIL, BNIL);
									      return user_error_151_tools_error(string2241_module_foreign, string2247_module_foreign, foreign_22, list1582_967);
									   }
								      }
								   }
								 else
								   {
								      goto tag_145_198_779;
								   }
							      }
							   }
						      }
						    else
						      {
							 goto tag_145_198_779;
						      }
						 }
					       else
						 {
						    obj_t cdr_638_125_865;
						    cdr_638_125_865 = CDR(cdr_156_22_782);
						    if (PAIRP(cdr_638_125_865))
						      {
							 obj_t cdr_643_163_867;
							 cdr_643_163_867 = CDR(cdr_638_125_865);
							 if (PAIRP(cdr_643_163_867))
							   {
							      bool_t test_3204;
							      {
								 obj_t aux_3205;
								 aux_3205 = CDR(cdr_643_163_867);
								 test_3204 = (aux_3205 == BNIL);
							      }
							      if (test_3204)
								{
								   obj_t c_name_211_3214;
								   obj_t proto_3212;
								   obj_t l_name_185_3210;
								   obj_t type_3208;
								   type_3208 = CAR(foreign_22);
								   l_name_185_3210 = CAR(cdr_156_22_782);
								   proto_3212 = CAR(cdr_638_125_865);
								   c_name_211_3214 = CAR(cdr_643_163_867);
								   c_name_211_773 = c_name_211_3214;
								   proto_772 = proto_3212;
								   l_name_185_771 = l_name_185_3210;
								   type_770 = type_3208;
								   goto tag_143_46_774;
								}
							      else
								{
								   goto tag_145_198_779;
								}
							   }
							 else
							   {
							      obj_t cdr_673_88_877;
							      cdr_673_88_877 = CDR(cdr_156_22_782);
							      {
								 bool_t test_3217;
								 {
								    obj_t aux_3218;
								    aux_3218 = CDR(cdr_673_88_877);
								    test_3217 = (aux_3218 == BNIL);
								 }
								 if (test_3217)
								   {
								      obj_t c_name_211_3225;
								      obj_t l_name_185_3223;
								      obj_t type_3221;
								      type_3221 = CAR(foreign_22);
								      l_name_185_3223 = CAR(cdr_156_22_782);
								      c_name_211_3225 = CAR(cdr_673_88_877);
								      c_name_211_777 = c_name_211_3225;
								      l_name_185_776 = l_name_185_3223;
								      type_775 = type_3221;
								      goto tag_144_168_778;
								   }
								 else
								   {
								      goto tag_145_198_779;
								   }
							      }
							   }
						      }
						    else
						      {
							 goto tag_145_198_779;
						      }
						 }
					    }
					 }
				       else
					 {
					    goto tag_145_198_779;
					 }
				    }
				  else
				    {
				       if (PAIRP(cdr_156_22_782))
					 {
					    obj_t cdr_740_201_888;
					    cdr_740_201_888 = CDR(cdr_156_22_782);
					    if (PAIRP(cdr_740_201_888))
					      {
						 obj_t cdr_745_255_890;
						 cdr_745_255_890 = CDR(cdr_740_201_888);
						 if (PAIRP(cdr_745_255_890))
						   {
						      bool_t test_3235;
						      {
							 obj_t aux_3236;
							 aux_3236 = CDR(cdr_745_255_890);
							 test_3235 = (aux_3236 == BNIL);
						      }
						      if (test_3235)
							{
							   obj_t c_name_211_3245;
							   obj_t proto_3243;
							   obj_t l_name_185_3241;
							   obj_t type_3239;
							   type_3239 = CAR(foreign_22);
							   l_name_185_3241 = CAR(cdr_156_22_782);
							   proto_3243 = CAR(cdr_740_201_888);
							   c_name_211_3245 = CAR(cdr_745_255_890);
							   c_name_211_773 = c_name_211_3245;
							   proto_772 = proto_3243;
							   l_name_185_771 = l_name_185_3241;
							   type_770 = type_3239;
							   goto tag_143_46_774;
							}
						      else
							{
							   goto tag_145_198_779;
							}
						   }
						 else
						   {
						      obj_t cdr_778_237_900;
						      cdr_778_237_900 = CDR(cdr_156_22_782);
						      {
							 bool_t test_3248;
							 {
							    obj_t aux_3249;
							    aux_3249 = CDR(cdr_778_237_900);
							    test_3248 = (aux_3249 == BNIL);
							 }
							 if (test_3248)
							   {
							      obj_t c_name_211_3256;
							      obj_t l_name_185_3254;
							      obj_t type_3252;
							      type_3252 = CAR(foreign_22);
							      l_name_185_3254 = CAR(cdr_156_22_782);
							      c_name_211_3256 = CAR(cdr_778_237_900);
							      c_name_211_777 = c_name_211_3256;
							      l_name_185_776 = l_name_185_3254;
							      type_775 = type_3252;
							      goto tag_144_168_778;
							   }
							 else
							   {
							      goto tag_145_198_779;
							   }
						      }
						   }
					      }
					    else
					      {
						 goto tag_145_198_779;
					      }
					 }
				       else
					 {
					    goto tag_145_198_779;
					 }
				    }
			       }
			  }
		     }
		}
	   }
	}
      else
	{
	   goto tag_145_198_779;
	}
   }
}


/* extern-parser */ obj_t 
extern_parser_240_module_foreign(obj_t extern_23)
{
   {
      obj_t id_990;
      obj_t c_name_211_991;
      obj_t id_986;
      obj_t proto_987;
      obj_t cn_988;
      obj_t id_982;
      obj_t c_name_211_983;
      obj_t id_978;
      obj_t proto_979;
      obj_t cn_980;
      if (PAIRP(extern_23))
	{
	   bool_t test_3260;
	   {
	      obj_t aux_3263;
	      obj_t aux_3261;
	      aux_3263 = CNST_TABLE_REF(((long) 5));
	      aux_3261 = CAR(extern_23);
	      test_3260 = (aux_3261 == aux_3263);
	   }
	   if (test_3260)
	     {
		return parse_c_extern_type_73_module_foreign(extern_23);
	     }
	   else
	     {
		obj_t car_881_151_997;
		car_881_151_997 = CAR(extern_23);
		{
		   bool_t test_3268;
		   {
		      obj_t aux_3269;
		      aux_3269 = CNST_TABLE_REF(((long) 6));
		      test_3268 = (car_881_151_997 == aux_3269);
		   }
		   if (test_3268)
		     {
			return foreign_parser_183_module_foreign(extern_23);
		     }
		   else
		     {
			bool_t test_3273;
			{
			   obj_t aux_3274;
			   aux_3274 = CNST_TABLE_REF(((long) 4));
			   test_3273 = (car_881_151_997 == aux_3274);
			}
			if (test_3273)
			  {
			     return foreign_parser_183_module_foreign(extern_23);
			  }
			else
			  {
			     obj_t cdr_896_76_1000;
			     cdr_896_76_1000 = CDR(extern_23);
			     {
				bool_t test_3279;
				{
				   obj_t aux_3280;
				   aux_3280 = CNST_TABLE_REF(((long) 7));
				   test_3279 = (car_881_151_997 == aux_3280);
				}
				if (test_3279)
				  {
				     if (PAIRP(cdr_896_76_1000))
				       {
					  obj_t car_900_190_1003;
					  obj_t cdr_901_152_1004;
					  car_900_190_1003 = CAR(cdr_896_76_1000);
					  cdr_901_152_1004 = CDR(cdr_896_76_1000);
					  if (SYMBOLP(car_900_190_1003))
					    {
					       if (PAIRP(cdr_901_152_1004))
						 {
						    obj_t cdr_908_200_1007;
						    cdr_908_200_1007 = CDR(cdr_901_152_1004);
						    if (PAIRP(cdr_908_200_1007))
						      {
							 obj_t car_911_5_1009;
							 car_911_5_1009 = CAR(cdr_908_200_1007);
							 if (STRINGP(car_911_5_1009))
							   {
							      bool_t test_3297;
							      {
								 obj_t aux_3298;
								 aux_3298 = CDR(cdr_908_200_1007);
								 test_3297 = (aux_3298 == BNIL);
							      }
							      if (test_3297)
								{
								   id_978 = car_900_190_1003;
								   proto_979 = CAR(cdr_901_152_1004);
								   cn_980 = car_911_5_1009;
								 tag_864_33_981:
								   {
								      obj_t pid_1146;
								      pid_1146 = parse_id_241_ast_ident(id_978);
								      {
									 obj_t ln_1147;
									 ln_1147 = CAR(pid_1146);
									 {
									    obj_t type_1148;
									    {
									       type_t obj_2336;
									       {
										  obj_t aux_3303;
										  aux_3303 = CDR(pid_1146);
										  obj_2336 = (type_t) (aux_3303);
									       }
									       type_1148 = (((type_t) CREF(obj_2336))->id);
									    }
									    {
									       {
										  bool_t test1705_1149;
										  {
										     bool_t test1713_1158;
										     {
											obj_t x_2880;
											x_2880 = check_id_6_ast_ident(pid_1146, extern_23);
											test1713_1158 = ((bool_t) 1);
										     }
										     if (test1713_1158)
										       {
											  if (check_c_args__102_module_foreign(proto_979))
											    {
											       test1705_1149 = ((bool_t) 0);
											    }
											  else
											    {
											       test1705_1149 = ((bool_t) 1);
											    }
										       }
										     else
										       {
											  test1705_1149 = ((bool_t) 1);
										       }
										  }
										  if (test1705_1149)
										    {
										       obj_t list1709_1153;
										       list1709_1153 = MAKE_PAIR(BNIL, BNIL);
										       return user_error_151_tools_error(string2241_module_foreign, string2248_module_foreign, extern_23, list1709_1153);
										    }
										  else
										    {
										       global_t aux_3314;
										       {
											  bool_t aux_3315;
											  {
											     obj_t aux_3318;
											     obj_t aux_3316;
											     aux_3318 = CNST_TABLE_REF(((long) 3));
											     aux_3316 = CAR(extern_23);
											     aux_3315 = (aux_3316 == aux_3318);
											  }
											  aux_3314 = declare_global_cfun__81_ast_glo_decl_237(ln_1147, cn_980, type_1148, proto_979, aux_3315, ((bool_t) 1), extern_23);
										       }
										       return (obj_t) (aux_3314);
										    }
									       }
									    }
									 }
								      }
								   }
								}
							      else
								{
								 tag_866_189_985:
								   {
								      obj_t list1728_1174;
								      list1728_1174 = MAKE_PAIR(BNIL, BNIL);
								      return user_error_151_tools_error(string2241_module_foreign, string2248_module_foreign, extern_23, list1728_1174);
								   }
								}
							   }
							 else
							   {
							      goto tag_866_189_985;
							   }
						      }
						    else
						      {
							 obj_t car_963_37_1016;
							 obj_t cdr_964_146_1017;
							 car_963_37_1016 = CAR(cdr_896_76_1000);
							 cdr_964_146_1017 = CDR(cdr_896_76_1000);
							 if (SYMBOLP(car_963_37_1016))
							   {
							      obj_t car_972_152_1019;
							      car_972_152_1019 = CAR(cdr_964_146_1017);
							      if (STRINGP(car_972_152_1019))
								{
								   bool_t test_3333;
								   {
								      obj_t aux_3334;
								      aux_3334 = CDR(cdr_964_146_1017);
								      test_3333 = (aux_3334 == BNIL);
								   }
								   if (test_3333)
								     {
									id_982 = car_963_37_1016;
									c_name_211_983 = car_972_152_1019;
								      tag_865_4_984:
									{
									   obj_t pid_1161;
									   pid_1161 = parse_id_241_ast_ident(id_982);
									   {
									      obj_t l_name_185_1162;
									      l_name_185_1162 = CAR(pid_1161);
									      {
										 obj_t type_1163;
										 {
										    type_t obj_2342;
										    {
										       obj_t aux_3339;
										       aux_3339 = CDR(pid_1161);
										       obj_2342 = (type_t) (aux_3339);
										    }
										    type_1163 = (((type_t) CREF(obj_2342))->id);
										 }
										 {
										    {
										       bool_t test1717_1164;
										       {
											  obj_t x_2881;
											  x_2881 = check_id_6_ast_ident(pid_1161, extern_23);
											  test1717_1164 = ((bool_t) 1);
										       }
										       if (test1717_1164)
											 {
											    global_t aux_3345;
											    aux_3345 = declare_global_cvar__13_ast_glo_decl_237(l_name_185_1162, c_name_211_983, type_1163, ((bool_t) 1), extern_23);
											    return (obj_t) (aux_3345);
											 }
										       else
											 {
											    obj_t list1722_1168;
											    list1722_1168 = MAKE_PAIR(BNIL, BNIL);
											    return user_error_151_tools_error(string2241_module_foreign, string2248_module_foreign, extern_23, list1722_1168);
											 }
										    }
										 }
									      }
									   }
									}
								     }
								   else
								     {
									goto tag_866_189_985;
								     }
								}
							      else
								{
								   goto tag_866_189_985;
								}
							   }
							 else
							   {
							      goto tag_866_189_985;
							   }
						      }
						 }
					       else
						 {
						    goto tag_866_189_985;
						 }
					    }
					  else
					    {
					       obj_t car_1018_119_1025;
					       obj_t cdr_1019_21_1026;
					       car_1018_119_1025 = CAR(cdr_896_76_1000);
					       cdr_1019_21_1026 = CDR(cdr_896_76_1000);
					       if (SYMBOLP(car_1018_119_1025))
						 {
						    if (PAIRP(cdr_1019_21_1026))
						      {
							 obj_t car_1024_80_1029;
							 car_1024_80_1029 = CAR(cdr_1019_21_1026);
							 if (STRINGP(car_1024_80_1029))
							   {
							      bool_t test_3359;
							      {
								 obj_t aux_3360;
								 aux_3360 = CDR(cdr_1019_21_1026);
								 test_3359 = (aux_3360 == BNIL);
							      }
							      if (test_3359)
								{
								   obj_t c_name_211_3364;
								   obj_t id_3363;
								   id_3363 = car_1018_119_1025;
								   c_name_211_3364 = car_1024_80_1029;
								   c_name_211_983 = c_name_211_3364;
								   id_982 = id_3363;
								   goto tag_865_4_984;
								}
							      else
								{
								   goto tag_866_189_985;
								}
							   }
							 else
							   {
							      goto tag_866_189_985;
							   }
						      }
						    else
						      {
							 goto tag_866_189_985;
						      }
						 }
					       else
						 {
						    goto tag_866_189_985;
						 }
					    }
				       }
				     else
				       {
					  goto tag_866_189_985;
				       }
				  }
				else
				  {
				     bool_t test_3365;
				     {
					obj_t aux_3366;
					aux_3366 = CNST_TABLE_REF(((long) 3));
					test_3365 = (car_881_151_997 == aux_3366);
				     }
				     if (test_3365)
				       {
					  if (PAIRP(cdr_896_76_1000))
					    {
					       obj_t cdr_1067_84_1037;
					       cdr_1067_84_1037 = CDR(cdr_896_76_1000);
					       {
						  bool_t test_3372;
						  {
						     obj_t aux_3375;
						     obj_t aux_3373;
						     aux_3375 = CNST_TABLE_REF(((long) 7));
						     aux_3373 = CAR(cdr_896_76_1000);
						     test_3372 = (aux_3373 == aux_3375);
						  }
						  if (test_3372)
						    {
						       if (PAIRP(cdr_1067_84_1037))
							 {
							    obj_t car_1071_20_1040;
							    obj_t cdr_1072_103_1041;
							    car_1071_20_1040 = CAR(cdr_1067_84_1037);
							    cdr_1072_103_1041 = CDR(cdr_1067_84_1037);
							    if (SYMBOLP(car_1071_20_1040))
							      {
								 if (PAIRP(cdr_1072_103_1041))
								   {
								      obj_t cdr_1079_167_1044;
								      cdr_1079_167_1044 = CDR(cdr_1072_103_1041);
								      if (PAIRP(cdr_1079_167_1044))
									{
									   obj_t car_1082_234_1046;
									   car_1082_234_1046 = CAR(cdr_1079_167_1044);
									   if (STRINGP(car_1082_234_1046))
									     {
										bool_t test_3392;
										{
										   obj_t aux_3393;
										   aux_3393 = CDR(cdr_1079_167_1044);
										   test_3392 = (aux_3393 == BNIL);
										}
										if (test_3392)
										  {
										     obj_t cn_3399;
										     obj_t proto_3397;
										     obj_t id_3396;
										     id_3396 = car_1071_20_1040;
										     proto_3397 = CAR(cdr_1072_103_1041);
										     cn_3399 = car_1082_234_1046;
										     cn_980 = cn_3399;
										     proto_979 = proto_3397;
										     id_978 = id_3396;
										     goto tag_864_33_981;
										  }
										else
										  {
										   tag_869_166_993:
										     {
											obj_t list1760_1201;
											list1760_1201 = MAKE_PAIR(BNIL, BNIL);
											return user_error_151_tools_error(string2241_module_foreign, string2248_module_foreign, extern_23, list1760_1201);
										     }
										  }
									     }
									   else
									     {
										goto tag_869_166_993;
									     }
									}
								      else
									{
									   goto tag_869_166_993;
									}
								   }
								 else
								   {
								      if (SYMBOLP(car_881_151_997))
									{
									   obj_t cdr_1180_170_1055;
									   cdr_1180_170_1055 = CDR(cdr_896_76_1000);
									   {
									      obj_t car_1184_37_1056;
									      car_1184_37_1056 = CAR(cdr_1180_170_1055);
									      if (STRINGP(car_1184_37_1056))
										{
										   bool_t test_3408;
										   {
										      obj_t aux_3409;
										      aux_3409 = CDR(cdr_1180_170_1055);
										      test_3408 = (aux_3409 == BNIL);
										   }
										   if (test_3408)
										     {
											id_986 = car_881_151_997;
											proto_987 = CAR(cdr_896_76_1000);
											cn_988 = car_1184_37_1056;
										      tag_867_8_989:
											{
											   obj_t pid_1176;
											   pid_1176 = parse_id_241_ast_ident(id_986);
											   {
											      obj_t ln_1177;
											      ln_1177 = CAR(pid_1176);
											      {
												 obj_t type_1178;
												 {
												    type_t obj_2345;
												    {
												       obj_t aux_3414;
												       aux_3414 = CDR(pid_1176);
												       obj_2345 = (type_t) (aux_3414);
												    }
												    type_1178 = (((type_t) CREF(obj_2345))->id);
												 }
												 {
												    {
												       bool_t test1730_1179;
												       {
													  bool_t test1739_1185;
													  {
													     obj_t x_2882;
													     x_2882 = check_id_6_ast_ident(pid_1176, extern_23);
													     test1739_1185 = ((bool_t) 1);
													  }
													  if (test1739_1185)
													    {
													       if (check_c_args__102_module_foreign(proto_987))
														 {
														    test1730_1179 = ((bool_t) 0);
														 }
													       else
														 {
														    test1730_1179 = ((bool_t) 1);
														 }
													    }
													  else
													    {
													       test1730_1179 = ((bool_t) 1);
													    }
												       }
												       if (test1730_1179)
													 {
													    obj_t list1734_1183;
													    list1734_1183 = MAKE_PAIR(BNIL, BNIL);
													    return user_error_151_tools_error(string2241_module_foreign, string2248_module_foreign, extern_23, list1734_1183);
													 }
												       else
													 {
													    global_t aux_3425;
													    aux_3425 = declare_global_cfun__81_ast_glo_decl_237(ln_1177, cn_988, type_1178, proto_987, ((bool_t) 0), ((bool_t) 0), extern_23);
													    return (obj_t) (aux_3425);
													 }
												    }
												 }
											      }
											   }
											}
										     }
										   else
										     {
											goto tag_869_166_993;
										     }
										}
									      else
										{
										   goto tag_869_166_993;
										}
									   }
									}
								      else
									{
									   goto tag_869_166_993;
									}
								   }
							      }
							    else
							      {
								 if (SYMBOLP(car_881_151_997))
								   {
								      obj_t cdr_1228_61_1065;
								      cdr_1228_61_1065 = CDR(cdr_896_76_1000);
								      {
									 obj_t car_1231_190_1066;
									 car_1231_190_1066 = CAR(cdr_1228_61_1065);
									 if (STRINGP(car_1231_190_1066))
									   {
									      bool_t test_3435;
									      {
										 obj_t aux_3436;
										 aux_3436 = CDR(cdr_1228_61_1065);
										 test_3435 = (aux_3436 == BNIL);
									      }
									      if (test_3435)
										{
										   obj_t cn_3442;
										   obj_t proto_3440;
										   obj_t id_3439;
										   id_3439 = car_881_151_997;
										   proto_3440 = CAR(cdr_896_76_1000);
										   cn_3442 = car_1231_190_1066;
										   cn_988 = cn_3442;
										   proto_987 = proto_3440;
										   id_986 = id_3439;
										   goto tag_867_8_989;
										}
									      else
										{
										   goto tag_869_166_993;
										}
									   }
									 else
									   {
									      goto tag_869_166_993;
									   }
								      }
								   }
								 else
								   {
								      goto tag_869_166_993;
								   }
							      }
							 }
						       else
							 {
							    if (SYMBOLP(car_881_151_997))
							      {
								 obj_t car_1275_183_1075;
								 car_1275_183_1075 = CAR(cdr_896_76_1000);
								 if (STRINGP(car_1275_183_1075))
								   {
								      bool_t test_3448;
								      {
									 obj_t aux_3449;
									 aux_3449 = CDR(cdr_896_76_1000);
									 test_3448 = (aux_3449 == BNIL);
								      }
								      if (test_3448)
									{
									   id_990 = car_881_151_997;
									   c_name_211_991 = car_1275_183_1075;
									 tag_868_80_992:
									   {
									      obj_t pid_1188;
									      pid_1188 = parse_id_241_ast_ident(id_990);
									      {
										 obj_t l_name_185_1189;
										 l_name_185_1189 = CAR(pid_1188);
										 {
										    obj_t type_1190;
										    {
										       type_t obj_2348;
										       {
											  obj_t aux_3454;
											  aux_3454 = CDR(pid_1188);
											  obj_2348 = (type_t) (aux_3454);
										       }
										       type_1190 = (((type_t) CREF(obj_2348))->id);
										    }
										    {
										       {
											  bool_t test1744_1191;
											  {
											     obj_t x_2883;
											     x_2883 = check_id_6_ast_ident(pid_1188, extern_23);
											     test1744_1191 = ((bool_t) 1);
											  }
											  if (test1744_1191)
											    {
											       global_t aux_3460;
											       aux_3460 = declare_global_cvar__13_ast_glo_decl_237(l_name_185_1189, c_name_211_991, type_1190, ((bool_t) 0), extern_23);
											       return (obj_t) (aux_3460);
											    }
											  else
											    {
											       obj_t list1748_1195;
											       list1748_1195 = MAKE_PAIR(BNIL, BNIL);
											       return user_error_151_tools_error(string2241_module_foreign, string2248_module_foreign, extern_23, list1748_1195);
											    }
										       }
										    }
										 }
									      }
									   }
									}
								      else
									{
									   goto tag_869_166_993;
									}
								   }
								 else
								   {
								      goto tag_869_166_993;
								   }
							      }
							    else
							      {
								 goto tag_869_166_993;
							      }
							 }
						    }
						  else
						    {
						       if (SYMBOLP(car_881_151_997))
							 {
							    obj_t cdr_1305_252_1083;
							    cdr_1305_252_1083 = CDR(cdr_896_76_1000);
							    if (PAIRP(cdr_1305_252_1083))
							      {
								 obj_t car_1308_218_1085;
								 car_1308_218_1085 = CAR(cdr_1305_252_1083);
								 if (STRINGP(car_1308_218_1085))
								   {
								      bool_t test_3473;
								      {
									 obj_t aux_3474;
									 aux_3474 = CDR(cdr_1305_252_1083);
									 test_3473 = (aux_3474 == BNIL);
								      }
								      if (test_3473)
									{
									   obj_t cn_3480;
									   obj_t proto_3478;
									   obj_t id_3477;
									   id_3477 = car_881_151_997;
									   proto_3478 = CAR(cdr_896_76_1000);
									   cn_3480 = car_1308_218_1085;
									   cn_988 = cn_3480;
									   proto_987 = proto_3478;
									   id_986 = id_3477;
									   goto tag_867_8_989;
									}
								      else
									{
									   goto tag_869_166_993;
									}
								   }
								 else
								   {
								      goto tag_869_166_993;
								   }
							      }
							    else
							      {
								 if (SYMBOLP(car_881_151_997))
								   {
								      obj_t car_1335_75_1094;
								      car_1335_75_1094 = CAR(cdr_896_76_1000);
								      if (STRINGP(car_1335_75_1094))
									{
									   bool_t test_3486;
									   {
									      obj_t aux_3487;
									      aux_3487 = CDR(cdr_896_76_1000);
									      test_3486 = (aux_3487 == BNIL);
									   }
									   if (test_3486)
									     {
										obj_t c_name_211_3491;
										obj_t id_3490;
										id_3490 = car_881_151_997;
										c_name_211_3491 = car_1335_75_1094;
										c_name_211_991 = c_name_211_3491;
										id_990 = id_3490;
										goto tag_868_80_992;
									     }
									   else
									     {
										goto tag_869_166_993;
									     }
									}
								      else
									{
									   goto tag_869_166_993;
									}
								   }
								 else
								   {
								      goto tag_869_166_993;
								   }
							      }
							 }
						       else
							 {
							    if (SYMBOLP(car_881_151_997))
							      {
								 obj_t car_1352_93_1102;
								 car_1352_93_1102 = CAR(cdr_896_76_1000);
								 if (STRINGP(car_1352_93_1102))
								   {
								      bool_t test_3497;
								      {
									 obj_t aux_3498;
									 aux_3498 = CDR(cdr_896_76_1000);
									 test_3497 = (aux_3498 == BNIL);
								      }
								      if (test_3497)
									{
									   obj_t c_name_211_3502;
									   obj_t id_3501;
									   id_3501 = car_881_151_997;
									   c_name_211_3502 = car_1352_93_1102;
									   c_name_211_991 = c_name_211_3502;
									   id_990 = id_3501;
									   goto tag_868_80_992;
									}
								      else
									{
									   goto tag_869_166_993;
									}
								   }
								 else
								   {
								      goto tag_869_166_993;
								   }
							      }
							    else
							      {
								 goto tag_869_166_993;
							      }
							 }
						    }
					       }
					    }
					  else
					    {
					       goto tag_869_166_993;
					    }
				       }
				     else
				       {
					  if (SYMBOLP(car_881_151_997))
					    {
					       if (PAIRP(cdr_896_76_1000))
						 {
						    obj_t cdr_1403_20_1113;
						    cdr_1403_20_1113 = CDR(cdr_896_76_1000);
						    if (PAIRP(cdr_1403_20_1113))
						      {
							 obj_t car_1406_60_1115;
							 car_1406_60_1115 = CAR(cdr_1403_20_1113);
							 if (STRINGP(car_1406_60_1115))
							   {
							      bool_t test_3513;
							      {
								 obj_t aux_3514;
								 aux_3514 = CDR(cdr_1403_20_1113);
								 test_3513 = (aux_3514 == BNIL);
							      }
							      if (test_3513)
								{
								   obj_t cn_3520;
								   obj_t proto_3518;
								   obj_t id_3517;
								   id_3517 = car_881_151_997;
								   proto_3518 = CAR(cdr_896_76_1000);
								   cn_3520 = car_1406_60_1115;
								   cn_988 = cn_3520;
								   proto_987 = proto_3518;
								   id_986 = id_3517;
								   goto tag_867_8_989;
								}
							      else
								{
								   goto tag_869_166_993;
								}
							   }
							 else
							   {
							      goto tag_869_166_993;
							   }
						      }
						    else
						      {
							 if (SYMBOLP(car_881_151_997))
							   {
							      obj_t car_1438_132_1124;
							      car_1438_132_1124 = CAR(cdr_896_76_1000);
							      if (STRINGP(car_1438_132_1124))
								{
								   bool_t test_3526;
								   {
								      obj_t aux_3527;
								      aux_3527 = CDR(cdr_896_76_1000);
								      test_3526 = (aux_3527 == BNIL);
								   }
								   if (test_3526)
								     {
									obj_t c_name_211_3531;
									obj_t id_3530;
									id_3530 = car_881_151_997;
									c_name_211_3531 = car_1438_132_1124;
									c_name_211_991 = c_name_211_3531;
									id_990 = id_3530;
									goto tag_868_80_992;
								     }
								   else
								     {
									goto tag_869_166_993;
								     }
								}
							      else
								{
								   goto tag_869_166_993;
								}
							   }
							 else
							   {
							      goto tag_869_166_993;
							   }
						      }
						 }
					       else
						 {
						    goto tag_869_166_993;
						 }
					    }
					  else
					    {
					       if (SYMBOLP(car_881_151_997))
						 {
						    if (PAIRP(cdr_896_76_1000))
						      {
							 obj_t car_1460_196_1133;
							 car_1460_196_1133 = CAR(cdr_896_76_1000);
							 if (STRINGP(car_1460_196_1133))
							   {
							      bool_t test_3539;
							      {
								 obj_t aux_3540;
								 aux_3540 = CDR(cdr_896_76_1000);
								 test_3539 = (aux_3540 == BNIL);
							      }
							      if (test_3539)
								{
								   obj_t c_name_211_3544;
								   obj_t id_3543;
								   id_3543 = car_881_151_997;
								   c_name_211_3544 = car_1460_196_1133;
								   c_name_211_991 = c_name_211_3544;
								   id_990 = id_3543;
								   goto tag_868_80_992;
								}
							      else
								{
								   goto tag_869_166_993;
								}
							   }
							 else
							   {
							      goto tag_869_166_993;
							   }
						      }
						    else
						      {
							 goto tag_869_166_993;
						      }
						 }
					       else
						 {
						    goto tag_869_166_993;
						 }
					    }
				       }
				  }
			     }
			  }
		     }
		}
	     }
	}
      else
	{
	   goto tag_869_166_993;
	}
   }
}


/* parse-c-foreign-type */ obj_t 
parse_c_foreign_type_105_module_foreign(obj_t type_24)
{
   {
      obj_t id_1206;
      obj_t t_exp_39_1207;
      obj_t name_1208;
      if (PAIRP(type_24))
	{
	   obj_t cdr_1514_50_1213;
	   cdr_1514_50_1213 = CDR(type_24);
	   {
	      bool_t test_3548;
	      {
		 obj_t aux_3551;
		 obj_t aux_3549;
		 aux_3551 = CNST_TABLE_REF(((long) 5));
		 aux_3549 = CAR(type_24);
		 test_3548 = (aux_3549 == aux_3551);
	      }
	      if (test_3548)
		{
		   if (PAIRP(cdr_1514_50_1213))
		     {
			obj_t car_1517_237_1216;
			obj_t cdr_1518_8_1217;
			car_1517_237_1216 = CAR(cdr_1514_50_1213);
			cdr_1518_8_1217 = CDR(cdr_1514_50_1213);
			if (SYMBOLP(car_1517_237_1216))
			  {
			     if (PAIRP(cdr_1518_8_1217))
			       {
				  obj_t car_1523_163_1220;
				  car_1523_163_1220 = CAR(cdr_1518_8_1217);
				  if (STRINGP(car_1523_163_1220))
				    {
				       bool_t test_3565;
				       {
					  obj_t aux_3566;
					  aux_3566 = CDR(cdr_1518_8_1217);
					  test_3565 = (aux_3566 == BNIL);
				       }
				       if (test_3565)
					 {
					    type_t aux_3569;
					    aux_3569 = declare_type__118_type_env(car_1517_237_1216, car_1523_163_1220, CNST_TABLE_REF(((long) 9)));
					    return (obj_t) (aux_3569);
					 }
				       else
					 {
					    obj_t car_1543_197_1224;
					    obj_t cdr_1544_189_1225;
					    car_1543_197_1224 = CAR(cdr_1514_50_1213);
					    cdr_1544_189_1225 = CDR(cdr_1514_50_1213);
					    if (SYMBOLP(car_1543_197_1224))
					      {
						 obj_t cdr_1554_16_1227;
						 cdr_1554_16_1227 = CDR(cdr_1544_189_1225);
						 if (PAIRP(cdr_1554_16_1227))
						   {
						      obj_t car_1558_125_1229;
						      car_1558_125_1229 = CAR(cdr_1554_16_1227);
						      if (STRINGP(car_1558_125_1229))
							{
							   bool_t test_3583;
							   {
							      obj_t aux_3584;
							      aux_3584 = CDR(cdr_1554_16_1227);
							      test_3583 = (aux_3584 == BNIL);
							   }
							   if (test_3583)
							     {
								id_1206 = car_1543_197_1224;
								t_exp_39_1207 = CAR(cdr_1544_189_1225);
								name_1208 = car_1558_125_1229;
							      tag_1505_107_1209:
								if (check_c_foreign_type_exp__43_module_foreign(t_exp_39_1207))
								  {
								     obj_t ctype_1266;
								     ctype_1266 = declare_c_type__49_foreign_ctype(type_24, id_1206, t_exp_39_1207, name_1208);
								     {
									bool_t test1802_1267;
									test1802_1267 = is_a__118___object(ctype_1266, type_type_type);
									if (test1802_1267)
									  {
									     obj_t accesses_1268;
									     accesses_1268 = make_ctype_accesses__219_foreign_access((type_t) (ctype_1266), (type_t) (ctype_1266));
									     _foreign_accesses__124_module_foreign = append_2_18___r4_pairs_and_lists_6_3(accesses_1268, _foreign_accesses__124_module_foreign);
									     {
										bool_t test1803_1269;
										{
										   bool_t test1824_1289;
										   test1824_1289 = is_a__118___object(ctype_1266, calias_foreign_ctype);
										   if (test1824_1289)
										     {
											obj_t aux_3598;
											{
											   type_t obj_2407;
											   obj_2407 = (type_t) (ctype_1266);
											   aux_3598 = (((type_t) CREF(obj_2407))->alias);
											}
											test1803_1269 = is_a__118___object(aux_3598, cstruct_foreign_ctype);
										     }
										   else
										     {
											test1803_1269 = ((bool_t) 0);
										     }
										}
										if (test1803_1269)
										  {
										     obj_t arg1804_1270;
										     {
											obj_t arg1805_1271;
											obj_t arg1806_1272;
											obj_t arg1807_1273;
											obj_t arg1808_1274;
											arg1805_1271 = CNST_TABLE_REF(((long) 5));
											{
											   obj_t list1816_1282;
											   {
											      obj_t arg1817_1283;
											      {
												 obj_t aux_3604;
												 aux_3604 = CNST_TABLE_REF(((long) 8));
												 arg1817_1283 = MAKE_PAIR(aux_3604, BNIL);
											      }
											      list1816_1282 = MAKE_PAIR(id_1206, arg1817_1283);
											   }
											   arg1806_1272 = symbol_append_197___r4_symbols_6_4(list1816_1282);
											}
											{
											   obj_t list1821_1286;
											   {
											      obj_t arg1822_1287;
											      {
												 obj_t aux_3609;
												 aux_3609 = CNST_TABLE_REF(((long) 8));
												 arg1822_1287 = MAKE_PAIR(aux_3609, BNIL);
											      }
											      list1821_1286 = MAKE_PAIR(t_exp_39_1207, arg1822_1287);
											   }
											   arg1807_1273 = symbol_append_197___r4_symbols_6_4(list1821_1286);
											}
											arg1808_1274 = make_pointer_to_name_76_type_tools((type_t) (ctype_1266));
											{
											   obj_t list1810_1276;
											   {
											      obj_t arg1811_1277;
											      {
												 obj_t arg1812_1278;
												 {
												    obj_t arg1813_1279;
												    arg1813_1279 = MAKE_PAIR(BNIL, BNIL);
												    arg1812_1278 = MAKE_PAIR(arg1808_1274, arg1813_1279);
												 }
												 arg1811_1277 = MAKE_PAIR(arg1807_1273, arg1812_1278);
											      }
											      list1810_1276 = MAKE_PAIR(arg1806_1272, arg1811_1277);
											   }
											   arg1804_1270 = cons__138___r4_pairs_and_lists_6_3(arg1805_1271, list1810_1276);
											}
										     }
										     parse_c_foreign_type_105_module_foreign(arg1804_1270);
										  }
										else
										  {
										     BUNSPEC;
										  }
									     }
									  }
									else
									  {
									     BUNSPEC;
									  }
								     }
								     return BUNSPEC;
								  }
								else
								  {
								     obj_t list1831_1294;
								     list1831_1294 = MAKE_PAIR(BNIL, BNIL);
								     return user_error_151_tools_error(string2241_module_foreign, string2249_module_foreign, type_24, list1831_1294);
								  }
							     }
							   else
							     {
							      tag_1506_87_1210:
								{
								   obj_t list1836_1299;
								   list1836_1299 = MAKE_PAIR(BNIL, BNIL);
								   return user_error_151_tools_error(string2241_module_foreign, string2249_module_foreign, type_24, list1836_1299);
								}
							     }
							}
						      else
							{
							   goto tag_1506_87_1210;
							}
						   }
						 else
						   {
						      goto tag_1506_87_1210;
						   }
					      }
					    else
					      {
						 goto tag_1506_87_1210;
					      }
					 }
				    }
				  else
				    {
				       obj_t car_1576_193_1238;
				       obj_t cdr_1577_233_1239;
				       car_1576_193_1238 = CAR(cdr_1514_50_1213);
				       cdr_1577_233_1239 = CDR(cdr_1514_50_1213);
				       if (SYMBOLP(car_1576_193_1238))
					 {
					    obj_t cdr_1586_162_1241;
					    cdr_1586_162_1241 = CDR(cdr_1577_233_1239);
					    if (PAIRP(cdr_1586_162_1241))
					      {
						 obj_t car_1589_208_1243;
						 car_1589_208_1243 = CAR(cdr_1586_162_1241);
						 if (STRINGP(car_1589_208_1243))
						   {
						      bool_t test_3637;
						      {
							 obj_t aux_3638;
							 aux_3638 = CDR(cdr_1586_162_1241);
							 test_3637 = (aux_3638 == BNIL);
						      }
						      if (test_3637)
							{
							   obj_t name_3644;
							   obj_t t_exp_39_3642;
							   obj_t id_3641;
							   id_3641 = car_1576_193_1238;
							   t_exp_39_3642 = CAR(cdr_1577_233_1239);
							   name_3644 = car_1589_208_1243;
							   name_1208 = name_3644;
							   t_exp_39_1207 = t_exp_39_3642;
							   id_1206 = id_3641;
							   goto tag_1505_107_1209;
							}
						      else
							{
							   goto tag_1506_87_1210;
							}
						   }
						 else
						   {
						      goto tag_1506_87_1210;
						   }
					      }
					    else
					      {
						 goto tag_1506_87_1210;
					      }
					 }
				       else
					 {
					    goto tag_1506_87_1210;
					 }
				    }
			       }
			     else
			       {
				  goto tag_1506_87_1210;
			       }
			  }
			else
			  {
			     obj_t car_1612_95_1250;
			     obj_t cdr_1613_147_1251;
			     car_1612_95_1250 = CAR(cdr_1514_50_1213);
			     cdr_1613_147_1251 = CDR(cdr_1514_50_1213);
			     if (SYMBOLP(car_1612_95_1250))
			       {
				  if (PAIRP(cdr_1613_147_1251))
				    {
				       obj_t cdr_1620_54_1254;
				       cdr_1620_54_1254 = CDR(cdr_1613_147_1251);
				       if (PAIRP(cdr_1620_54_1254))
					 {
					    obj_t car_1623_216_1256;
					    car_1623_216_1256 = CAR(cdr_1620_54_1254);
					    if (STRINGP(car_1623_216_1256))
					      {
						 bool_t test_3657;
						 {
						    obj_t aux_3658;
						    aux_3658 = CDR(cdr_1620_54_1254);
						    test_3657 = (aux_3658 == BNIL);
						 }
						 if (test_3657)
						   {
						      obj_t name_3664;
						      obj_t t_exp_39_3662;
						      obj_t id_3661;
						      id_3661 = car_1612_95_1250;
						      t_exp_39_3662 = CAR(cdr_1613_147_1251);
						      name_3664 = car_1623_216_1256;
						      name_1208 = name_3664;
						      t_exp_39_1207 = t_exp_39_3662;
						      id_1206 = id_3661;
						      goto tag_1505_107_1209;
						   }
						 else
						   {
						      goto tag_1506_87_1210;
						   }
					      }
					    else
					      {
						 goto tag_1506_87_1210;
					      }
					 }
				       else
					 {
					    goto tag_1506_87_1210;
					 }
				    }
				  else
				    {
				       goto tag_1506_87_1210;
				    }
			       }
			     else
			       {
				  goto tag_1506_87_1210;
			       }
			  }
		     }
		   else
		     {
			goto tag_1506_87_1210;
		     }
		}
	      else
		{
		   goto tag_1506_87_1210;
		}
	   }
	}
      else
	{
	   goto tag_1506_87_1210;
	}
   }
}


/* check-c-foreign-type-exp? */ bool_t 
check_c_foreign_type_exp__43_module_foreign(obj_t t_exp_39_25)
{
   {
      obj_t slots_1309;
      obj_t slots_1302;
      if (SYMBOLP(t_exp_39_25))
	{
	   return ((bool_t) 1);
	}
      else
	{
	   if (PAIRP(t_exp_39_25))
	     {
		obj_t car_1660_149_1315;
		car_1660_149_1315 = CAR(t_exp_39_25);
		{
		   {
		      bool_t test_3670;
		      {
			 obj_t aux_3671;
			 aux_3671 = CNST_TABLE_REF(((long) 10));
			 test_3670 = (car_1660_149_1315 == aux_3671);
		      }
		      if (test_3670)
			{
			 kap_1662_215_1316:
			   slots_1302 = CDR(t_exp_39_25);
			   {
			      obj_t slots_1436;
			      slots_1436 = slots_1302;
			    loop_1437:
			      if (NULLP(slots_1436))
				{
				   return ((bool_t) 1);
				}
			      else
				{
				   {
				      obj_t e_1871_173_1441;
				      e_1871_173_1441 = CAR(slots_1436);
				      if (PAIRP(e_1871_173_1441))
					{
					   obj_t cdr_1873_223_1443;
					   cdr_1873_223_1443 = CDR(e_1871_173_1441);
					   {
					      bool_t test_3680;
					      {
						 obj_t aux_3681;
						 aux_3681 = CAR(e_1871_173_1441);
						 test_3680 = SYMBOLP(aux_3681);
					      }
					      if (test_3680)
						{
						   if (PAIRP(cdr_1873_223_1443))
						     {
							obj_t cdr_1875_213_1446;
							cdr_1875_213_1446 = CDR(cdr_1873_223_1443);
							{
							   bool_t test_3687;
							   {
							      obj_t aux_3688;
							      aux_3688 = CAR(cdr_1873_223_1443);
							      test_3687 = SYMBOLP(aux_3688);
							   }
							   if (test_3687)
							     {
								if (PAIRP(cdr_1875_213_1446))
								  {
								     bool_t test_3693;
								     {
									obj_t aux_3694;
									aux_3694 = CAR(cdr_1875_213_1446);
									test_3693 = STRINGP(aux_3694);
								     }
								     if (test_3693)
								       {
									  bool_t test_3697;
									  {
									     obj_t aux_3698;
									     aux_3698 = CDR(cdr_1875_213_1446);
									     test_3697 = (aux_3698 == BNIL);
									  }
									  if (test_3697)
									    {
									       {
										  obj_t slots_3701;
										  slots_3701 = CDR(slots_1436);
										  slots_1436 = slots_3701;
										  goto loop_1437;
									       }
									    }
									  else
									    {
									       return ((bool_t) 0);
									    }
								       }
								     else
								       {
									  return ((bool_t) 0);
								       }
								  }
								else
								  {
								     return ((bool_t) 0);
								  }
							     }
							   else
							     {
								return ((bool_t) 0);
							     }
							}
						     }
						   else
						     {
							return ((bool_t) 0);
						     }
						}
					      else
						{
						   return ((bool_t) 0);
						}
					   }
					}
				      else
					{
					   return ((bool_t) 0);
					}
				   }
				}
			   }
			}
		      else
			{
			   bool_t test_3704;
			   {
			      obj_t aux_3705;
			      aux_3705 = CNST_TABLE_REF(((long) 11));
			      test_3704 = (car_1660_149_1315 == aux_3705);
			   }
			   if (test_3704)
			     {
				goto kap_1662_215_1316;
			     }
			   else
			     {
				obj_t cdr_1667_214_1319;
				cdr_1667_214_1319 = CDR(t_exp_39_25);
				{
				   bool_t test_3709;
				   {
				      obj_t aux_3710;
				      aux_3710 = CNST_TABLE_REF(((long) 12));
				      test_3709 = (car_1660_149_1315 == aux_3710);
				   }
				   if (test_3709)
				     {
					if (PAIRP(cdr_1667_214_1319))
					  {
					     bool_t test_3715;
					     {
						obj_t aux_3716;
						aux_3716 = CAR(cdr_1667_214_1319);
						test_3715 = SYMBOLP(aux_3716);
					     }
					     if (test_3715)
					       {
						  bool_t test_3719;
						  {
						     obj_t aux_3720;
						     aux_3720 = CDR(cdr_1667_214_1319);
						     test_3719 = (aux_3720 == BNIL);
						  }
						  if (test_3719)
						    {
						       return ((bool_t) 1);
						    }
						  else
						    {
						       return ((bool_t) 0);
						    }
					       }
					     else
					       {
						  return ((bool_t) 0);
					       }
					  }
					else
					  {
					     return ((bool_t) 0);
					  }
				     }
				   else
				     {
					{
					   bool_t test_3723;
					   {
					      obj_t aux_3724;
					      aux_3724 = CNST_TABLE_REF(((long) 16));
					      test_3723 = (car_1660_149_1315 == aux_3724);
					   }
					   if (test_3723)
					     {
					      kap_1720_15_1336:
						if (PAIRP(cdr_1667_214_1319))
						  {
						     bool_t test_3729;
						     {
							obj_t aux_3730;
							aux_3730 = CAR(cdr_1667_214_1319);
							test_3729 = SYMBOLP(aux_3730);
						     }
						     if (test_3729)
						       {
							  bool_t test_3733;
							  {
							     obj_t aux_3734;
							     aux_3734 = CDR(cdr_1667_214_1319);
							     test_3733 = (aux_3734 == BNIL);
							  }
							  if (test_3733)
							    {
							       return ((bool_t) 1);
							    }
							  else
							    {
							       obj_t cdr_1729_74_1375;
							       cdr_1729_74_1375 = CDR(t_exp_39_25);
							       {
								  bool_t test_3738;
								  {
								     obj_t aux_3741;
								     obj_t aux_3739;
								     aux_3741 = CNST_TABLE_REF(((long) 13));
								     aux_3739 = CAR(t_exp_39_25);
								     test_3738 = (aux_3739 == aux_3741);
								  }
								  if (test_3738)
								    {
								       obj_t cdr_1732_77_1377;
								       cdr_1732_77_1377 = CDR(cdr_1729_74_1375);
								       {
									  bool_t test_3745;
									  {
									     obj_t aux_3746;
									     aux_3746 = CAR(cdr_1729_74_1375);
									     test_3745 = SYMBOLP(aux_3746);
									  }
									  if (test_3745)
									    {
									       if (PAIRP(cdr_1732_77_1377))
										 {
										    obj_t car_1734_79_1380;
										    car_1734_79_1380 = CAR(cdr_1732_77_1377);
										    {
										       if ((car_1734_79_1380 == BNIL))
											 {
											  kap_1738_113_1381:
											    {
											       bool_t test_3754;
											       {
												  obj_t aux_3755;
												  aux_3755 = CDR(cdr_1732_77_1377);
												  test_3754 = (aux_3755 == BNIL);
											       }
											       if (test_3754)
												 {
												    return check_c_args__102_module_foreign(car_1734_79_1380);
												 }
											       else
												 {
												    return ((bool_t) 0);
												 }
											    }
											 }
										       else
											 {
											    if (PAIRP(car_1734_79_1380))
											      {
												 goto kap_1738_113_1381;
											      }
											    else
											      {
												 return ((bool_t) 0);
											      }
											 }
										    }
										 }
									       else
										 {
										    return ((bool_t) 0);
										 }
									    }
									  else
									    {
									       return ((bool_t) 0);
									    }
								       }
								    }
								  else
								    {
								       bool_t test_3761;
								       {
									  obj_t aux_3764;
									  obj_t aux_3762;
									  aux_3764 = CNST_TABLE_REF(((long) 14));
									  aux_3762 = CAR(t_exp_39_25);
									  test_3761 = (aux_3762 == aux_3764);
								       }
								       if (test_3761)
									 {
									    slots_1309 = cdr_1729_74_1375;
									  tag_1652_79_1310:
									    {
									       obj_t slots_1457;
									       slots_1457 = slots_1309;
									     loop_1458:
									       if (NULLP(slots_1457))
										 {
										    return ((bool_t) 1);
										 }
									       else
										 {
										    {
										       obj_t e_1880_82_1462;
										       e_1880_82_1462 = CAR(slots_1457);
										       if (PAIRP(e_1880_82_1462))
											 {
											    obj_t cdr_1882_223_1464;
											    cdr_1882_223_1464 = CDR(e_1880_82_1462);
											    {
											       bool_t test_3773;
											       {
												  obj_t aux_3774;
												  aux_3774 = CAR(e_1880_82_1462);
												  test_3773 = SYMBOLP(aux_3774);
											       }
											       if (test_3773)
												 {
												    if (PAIRP(cdr_1882_223_1464))
												      {
													 bool_t test_3779;
													 {
													    obj_t aux_3780;
													    aux_3780 = CAR(cdr_1882_223_1464);
													    test_3779 = STRINGP(aux_3780);
													 }
													 if (test_3779)
													   {
													      bool_t test_3783;
													      {
														 obj_t aux_3784;
														 aux_3784 = CDR(cdr_1882_223_1464);
														 test_3783 = (aux_3784 == BNIL);
													      }
													      if (test_3783)
														{
														   {
														      obj_t slots_3787;
														      slots_3787 = CDR(slots_1457);
														      slots_1457 = slots_3787;
														      goto loop_1458;
														   }
														}
													      else
														{
														   return ((bool_t) 0);
														}
													   }
													 else
													   {
													      return ((bool_t) 0);
													   }
												      }
												    else
												      {
													 return ((bool_t) 0);
												      }
												 }
											       else
												 {
												    return ((bool_t) 0);
												 }
											    }
											 }
										       else
											 {
											    return ((bool_t) 0);
											 }
										    }
										 }
									    }
									 }
								       else
									 {
									    return ((bool_t) 0);
									 }
								    }
							       }
							    }
						       }
						     else
						       {
							  obj_t cdr_1756_13_1397;
							  cdr_1756_13_1397 = CDR(t_exp_39_25);
							  {
							     bool_t test_3790;
							     {
								obj_t aux_3793;
								obj_t aux_3791;
								aux_3793 = CNST_TABLE_REF(((long) 15));
								aux_3791 = CAR(t_exp_39_25);
								test_3790 = (aux_3791 == aux_3793);
							     }
							     if (test_3790)
							       {
								  bool_t test_3796;
								  {
								     obj_t aux_3797;
								     aux_3797 = CAR(cdr_1756_13_1397);
								     test_3796 = SYMBOLP(aux_3797);
								  }
								  if (test_3796)
								    {
								       bool_t test_3800;
								       {
									  obj_t aux_3801;
									  aux_3801 = CDR(cdr_1756_13_1397);
									  test_3800 = (aux_3801 == BNIL);
								       }
								       if (test_3800)
									 {
									    return ((bool_t) 1);
									 }
								       else
									 {
									    return ((bool_t) 0);
									 }
								    }
								  else
								    {
								       return ((bool_t) 0);
								    }
							       }
							     else
							       {
								  bool_t test_3804;
								  {
								     obj_t aux_3807;
								     obj_t aux_3805;
								     aux_3807 = CNST_TABLE_REF(((long) 13));
								     aux_3805 = CAR(t_exp_39_25);
								     test_3804 = (aux_3805 == aux_3807);
								  }
								  if (test_3804)
								    {
								       obj_t cdr_1776_125_1406;
								       cdr_1776_125_1406 = CDR(cdr_1756_13_1397);
								       {
									  bool_t test_3811;
									  {
									     obj_t aux_3812;
									     aux_3812 = CAR(cdr_1756_13_1397);
									     test_3811 = SYMBOLP(aux_3812);
									  }
									  if (test_3811)
									    {
									       if (PAIRP(cdr_1776_125_1406))
										 {
										    obj_t car_1778_192_1409;
										    car_1778_192_1409 = CAR(cdr_1776_125_1406);
										    {
										       if ((car_1778_192_1409 == BNIL))
											 {
											  kap_1782_1_1410:
											    {
											       bool_t test_3820;
											       {
												  obj_t aux_3821;
												  aux_3821 = CDR(cdr_1776_125_1406);
												  test_3820 = (aux_3821 == BNIL);
											       }
											       if (test_3820)
												 {
												    return check_c_args__102_module_foreign(car_1778_192_1409);
												 }
											       else
												 {
												    return ((bool_t) 0);
												 }
											    }
											 }
										       else
											 {
											    if (PAIRP(car_1778_192_1409))
											      {
												 goto kap_1782_1_1410;
											      }
											    else
											      {
												 return ((bool_t) 0);
											      }
											 }
										    }
										 }
									       else
										 {
										    return ((bool_t) 0);
										 }
									    }
									  else
									    {
									       return ((bool_t) 0);
									    }
								       }
								    }
								  else
								    {
								       bool_t test_3827;
								       {
									  obj_t aux_3830;
									  obj_t aux_3828;
									  aux_3830 = CNST_TABLE_REF(((long) 14));
									  aux_3828 = CAR(t_exp_39_25);
									  test_3827 = (aux_3828 == aux_3830);
								       }
								       if (test_3827)
									 {
									    obj_t slots_3833;
									    slots_3833 = cdr_1756_13_1397;
									    slots_1309 = slots_3833;
									    goto tag_1652_79_1310;
									 }
								       else
									 {
									    return ((bool_t) 0);
									 }
								    }
							       }
							  }
						       }
						  }
						else
						  {
						     bool_t test_3834;
						     {
							obj_t aux_3837;
							obj_t aux_3835;
							aux_3837 = CNST_TABLE_REF(((long) 14));
							aux_3835 = CAR(t_exp_39_25);
							test_3834 = (aux_3835 == aux_3837);
						     }
						     if (test_3834)
						       {
							  obj_t slots_3840;
							  slots_3840 = CDR(t_exp_39_25);
							  slots_1309 = slots_3840;
							  goto tag_1652_79_1310;
						       }
						     else
						       {
							  return ((bool_t) 0);
						       }
						  }
					     }
					   else
					     {
						bool_t test_3842;
						{
						   obj_t aux_3843;
						   aux_3843 = CNST_TABLE_REF(((long) 17));
						   test_3842 = (car_1660_149_1315 == aux_3843);
						}
						if (test_3842)
						  {
						     goto kap_1720_15_1336;
						  }
						else
						  {
						     bool_t test_3846;
						     {
							obj_t aux_3847;
							aux_3847 = CNST_TABLE_REF(((long) 15));
							test_3846 = (car_1660_149_1315 == aux_3847);
						     }
						     if (test_3846)
						       {
							  if (PAIRP(cdr_1667_214_1319))
							    {
							       bool_t test_3852;
							       {
								  obj_t aux_3853;
								  aux_3853 = CAR(cdr_1667_214_1319);
								  test_3852 = SYMBOLP(aux_3853);
							       }
							       if (test_3852)
								 {
								    bool_t test_3856;
								    {
								       obj_t aux_3857;
								       aux_3857 = CDR(cdr_1667_214_1319);
								       test_3856 = (aux_3857 == BNIL);
								    }
								    if (test_3856)
								      {
									 return ((bool_t) 1);
								      }
								    else
								      {
									 return ((bool_t) 0);
								      }
								 }
							       else
								 {
								    return ((bool_t) 0);
								 }
							    }
							  else
							    {
							       return ((bool_t) 0);
							    }
						       }
						     else
						       {
							  bool_t test_3860;
							  {
							     obj_t aux_3861;
							     aux_3861 = CNST_TABLE_REF(((long) 13));
							     test_3860 = (car_1660_149_1315 == aux_3861);
							  }
							  if (test_3860)
							    {
							       if (PAIRP(cdr_1667_214_1319))
								 {
								    obj_t cdr_1835_3_1350;
								    cdr_1835_3_1350 = CDR(cdr_1667_214_1319);
								    {
								       bool_t test_3867;
								       {
									  obj_t aux_3868;
									  aux_3868 = CAR(cdr_1667_214_1319);
									  test_3867 = SYMBOLP(aux_3868);
								       }
								       if (test_3867)
									 {
									    if (PAIRP(cdr_1835_3_1350))
									      {
										 obj_t car_1837_107_1353;
										 car_1837_107_1353 = CAR(cdr_1835_3_1350);
										 {
										    if ((car_1837_107_1353 == BNIL))
										      {
										       kap_1841_24_1354:
											 {
											    bool_t test_3876;
											    {
											       obj_t aux_3877;
											       aux_3877 = CDR(cdr_1835_3_1350);
											       test_3876 = (aux_3877 == BNIL);
											    }
											    if (test_3876)
											      {
												 return check_c_args__102_module_foreign(car_1837_107_1353);
											      }
											    else
											      {
												 return ((bool_t) 0);
											      }
											 }
										      }
										    else
										      {
											 if (PAIRP(car_1837_107_1353))
											   {
											      goto kap_1841_24_1354;
											   }
											 else
											   {
											      return ((bool_t) 0);
											   }
										      }
										 }
									      }
									    else
									      {
										 return ((bool_t) 0);
									      }
									 }
								       else
									 {
									    return ((bool_t) 0);
									 }
								    }
								 }
							       else
								 {
								    return ((bool_t) 0);
								 }
							    }
							  else
							    {
							       bool_t test_3883;
							       {
								  obj_t aux_3884;
								  aux_3884 = CNST_TABLE_REF(((long) 14));
								  test_3883 = (car_1660_149_1315 == aux_3884);
							       }
							       if (test_3883)
								 {
								    obj_t slots_3887;
								    slots_3887 = cdr_1667_214_1319;
								    slots_1309 = slots_3887;
								    goto tag_1652_79_1310;
								 }
							       else
								 {
								    return ((bool_t) 0);
								 }
							    }
						       }
						  }
					     }
					}
				     }
				}
			     }
			}
		   }
		}
	     }
	   else
	     {
		return ((bool_t) 0);
	     }
	}
   }
}


/* parse-c-extern-type */ obj_t 
parse_c_extern_type_73_module_foreign(obj_t type_26)
{
   {
      obj_t id_1477;
      obj_t t_exp_39_1478;
      if (PAIRP(type_26))
	{
	   obj_t cdr_1895_88_1483;
	   cdr_1895_88_1483 = CDR(type_26);
	   {
	      bool_t test_3891;
	      {
		 obj_t aux_3894;
		 obj_t aux_3892;
		 aux_3894 = CNST_TABLE_REF(((long) 5));
		 aux_3892 = CAR(type_26);
		 test_3891 = (aux_3892 == aux_3894);
	      }
	      if (test_3891)
		{
		   if (PAIRP(cdr_1895_88_1483))
		     {
			obj_t cdr_1899_116_1487;
			cdr_1899_116_1487 = CDR(cdr_1895_88_1483);
			{
			   bool_t test_3900;
			   {
			      obj_t aux_3901;
			      aux_3901 = CAR(cdr_1895_88_1483);
			      test_3900 = SYMBOLP(aux_3901);
			   }
			   if (test_3900)
			     {
				if (PAIRP(cdr_1899_116_1487))
				  {
				     bool_t test_3906;
				     {
					obj_t aux_3907;
					aux_3907 = CAR(cdr_1899_116_1487);
					test_3906 = STRINGP(aux_3907);
				     }
				     if (test_3906)
				       {
					  bool_t test_3910;
					  {
					     obj_t aux_3911;
					     aux_3911 = CDR(cdr_1899_116_1487);
					     test_3910 = (aux_3911 == BNIL);
					  }
					  if (test_3910)
					    {
					       return parse_c_foreign_type_105_module_foreign(type_26);
					    }
					  else
					    {
					       obj_t car_1921_251_1494;
					       obj_t cdr_1922_83_1495;
					       car_1921_251_1494 = CAR(cdr_1895_88_1483);
					       cdr_1922_83_1495 = CDR(cdr_1895_88_1483);
					       if (SYMBOLP(car_1921_251_1494))
						 {
						    obj_t cdr_1931_56_1497;
						    cdr_1931_56_1497 = CDR(cdr_1922_83_1495);
						    if (PAIRP(cdr_1931_56_1497))
						      {
							 bool_t test_3922;
							 {
							    obj_t aux_3923;
							    aux_3923 = CAR(cdr_1931_56_1497);
							    test_3922 = STRINGP(aux_3923);
							 }
							 if (test_3922)
							   {
							      bool_t test_3926;
							      {
								 obj_t aux_3927;
								 aux_3927 = CDR(cdr_1931_56_1497);
								 test_3926 = (aux_3927 == BNIL);
							      }
							      if (test_3926)
								{
								   id_1477 = car_1921_251_1494;
								   t_exp_39_1478 = CAR(cdr_1922_83_1495);
								 tag_1886_146_1479:
								   {
								      obj_t foreign_type_139_1534;
								      foreign_type_139_1534 = c_extern_type__c_foreign_type_30_module_foreign(t_exp_39_1478);
								      if (CBOOL(foreign_type_139_1534))
									{
									   return parse_c_foreign_type_105_module_foreign(type_26);
									}
								      else
									{
									   obj_t list2018_1538;
									   list2018_1538 = MAKE_PAIR(BNIL, BNIL);
									   return user_error_151_tools_error(string2241_module_foreign, string2250_module_foreign, type_26, list2018_1538);
									}
								   }
								}
							      else
								{
								 tag_1887_184_1480:
								   {
								      obj_t list2023_1543;
								      list2023_1543 = MAKE_PAIR(BNIL, BNIL);
								      return user_error_151_tools_error(string2241_module_foreign, string2250_module_foreign, type_26, list2023_1543);
								   }
								}
							   }
							 else
							   {
							      goto tag_1887_184_1480;
							   }
						      }
						    else
						      {
							 goto tag_1887_184_1480;
						      }
						 }
					       else
						 {
						    goto tag_1887_184_1480;
						 }
					    }
				       }
				     else
				       {
					  obj_t car_1946_71_1508;
					  obj_t cdr_1947_50_1509;
					  car_1946_71_1508 = CAR(cdr_1895_88_1483);
					  cdr_1947_50_1509 = CDR(cdr_1895_88_1483);
					  if (SYMBOLP(car_1946_71_1508))
					    {
					       obj_t cdr_1955_87_1511;
					       cdr_1955_87_1511 = CDR(cdr_1947_50_1509);
					       if (PAIRP(cdr_1955_87_1511))
						 {
						    bool_t test_3946;
						    {
						       obj_t aux_3947;
						       aux_3947 = CAR(cdr_1955_87_1511);
						       test_3946 = STRINGP(aux_3947);
						    }
						    if (test_3946)
						      {
							 bool_t test_3950;
							 {
							    obj_t aux_3951;
							    aux_3951 = CDR(cdr_1955_87_1511);
							    test_3950 = (aux_3951 == BNIL);
							 }
							 if (test_3950)
							   {
							      obj_t t_exp_39_3955;
							      obj_t id_3954;
							      id_3954 = car_1946_71_1508;
							      t_exp_39_3955 = CAR(cdr_1947_50_1509);
							      t_exp_39_1478 = t_exp_39_3955;
							      id_1477 = id_3954;
							      goto tag_1886_146_1479;
							   }
							 else
							   {
							      goto tag_1887_184_1480;
							   }
						      }
						    else
						      {
							 goto tag_1887_184_1480;
						      }
						 }
					       else
						 {
						    goto tag_1887_184_1480;
						 }
					    }
					  else
					    {
					       goto tag_1887_184_1480;
					    }
				       }
				  }
				else
				  {
				     goto tag_1887_184_1480;
				  }
			     }
			   else
			     {
				obj_t car_1972_153_1520;
				obj_t cdr_1973_27_1521;
				car_1972_153_1520 = CAR(cdr_1895_88_1483);
				cdr_1973_27_1521 = CDR(cdr_1895_88_1483);
				if (SYMBOLP(car_1972_153_1520))
				  {
				     if (PAIRP(cdr_1973_27_1521))
				       {
					  obj_t cdr_1979_132_1524;
					  cdr_1979_132_1524 = CDR(cdr_1973_27_1521);
					  if (PAIRP(cdr_1979_132_1524))
					    {
					       bool_t test_3966;
					       {
						  obj_t aux_3967;
						  aux_3967 = CAR(cdr_1979_132_1524);
						  test_3966 = STRINGP(aux_3967);
					       }
					       if (test_3966)
						 {
						    bool_t test_3970;
						    {
						       obj_t aux_3971;
						       aux_3971 = CDR(cdr_1979_132_1524);
						       test_3970 = (aux_3971 == BNIL);
						    }
						    if (test_3970)
						      {
							 obj_t t_exp_39_3975;
							 obj_t id_3974;
							 id_3974 = car_1972_153_1520;
							 t_exp_39_3975 = CAR(cdr_1973_27_1521);
							 t_exp_39_1478 = t_exp_39_3975;
							 id_1477 = id_3974;
							 goto tag_1886_146_1479;
						      }
						    else
						      {
							 goto tag_1887_184_1480;
						      }
						 }
					       else
						 {
						    goto tag_1887_184_1480;
						 }
					    }
					  else
					    {
					       goto tag_1887_184_1480;
					    }
				       }
				     else
				       {
					  goto tag_1887_184_1480;
				       }
				  }
				else
				  {
				     goto tag_1887_184_1480;
				  }
			     }
			}
		     }
		   else
		     {
			goto tag_1887_184_1480;
		     }
		}
	      else
		{
		   goto tag_1887_184_1480;
		}
	   }
	}
      else
	{
	   goto tag_1887_184_1480;
	}
   }
}


/* c-extern-type->c-foreign-type */ obj_t 
c_extern_type__c_foreign_type_30_module_foreign(obj_t t_exp_39_27)
{
   {
      obj_t slots_1553;
      obj_t slots_1546;
      if (SYMBOLP(t_exp_39_27))
	{
	   return t_exp_39_27;
	}
      else
	{
	   if (PAIRP(t_exp_39_27))
	     {
		obj_t car_2009_230_1559;
		car_2009_230_1559 = CAR(t_exp_39_27);
		{
		   {
		      bool_t test_3982;
		      {
			 obj_t aux_3983;
			 aux_3983 = CNST_TABLE_REF(((long) 10));
			 test_3982 = (car_2009_230_1559 == aux_3983);
		      }
		      if (test_3982)
			{
			 kap_2011_203_1560:
			   slots_1546 = CDR(t_exp_39_27);
			   {
			      obj_t slots_1680;
			      slots_1680 = slots_1546;
			    loop_1681:
			      if (NULLP(slots_1680))
				{
				   return t_exp_39_27;
				}
			      else
				{
				   obj_t id_1683;
				   obj_t name_1684;
				   {
				      obj_t e_2220_53_1687;
				      e_2220_53_1687 = CAR(slots_1680);
				      if (PAIRP(e_2220_53_1687))
					{
					   obj_t car_2225_124_1689;
					   obj_t cdr_2226_104_1690;
					   car_2225_124_1689 = CAR(e_2220_53_1687);
					   cdr_2226_104_1690 = CDR(e_2220_53_1687);
					   if (SYMBOLP(car_2225_124_1689))
					     {
						if (PAIRP(cdr_2226_104_1690))
						  {
						     obj_t car_2230_3_1693;
						     car_2230_3_1693 = CAR(cdr_2226_104_1690);
						     if (STRINGP(car_2230_3_1693))
						       {
							  bool_t test_4000;
							  {
							     obj_t aux_4001;
							     aux_4001 = CDR(cdr_2226_104_1690);
							     test_4000 = (aux_4001 == BNIL);
							  }
							  if (test_4000)
							    {
							       id_1683 = car_2225_124_1689;
							       name_1684 = car_2230_3_1693;
							       {
								  obj_t pid_1698;
								  pid_1698 = parse_id_241_ast_ident(id_1683);
								  {
								     obj_t sid_1699;
								     sid_1699 = CAR(pid_1698);
								     {
									obj_t type_1700;
									{
									   type_t obj_2740;
									   {
									      obj_t aux_4006;
									      aux_4006 = CDR(pid_1698);
									      obj_2740 = (type_t) (aux_4006);
									   }
									   type_1700 = (((type_t) CREF(obj_2740))->id);
									}
									{
									   {
									      bool_t test2141_1701;
									      {
										 obj_t x_2884;
										 x_2884 = check_id_6_ast_ident(pid_1698, t_exp_39_27);
										 test2141_1701 = ((bool_t) 1);
									      }
									      if (test2141_1701)
										{
										   {
										      obj_t arg2143_1702;
										      obj_t arg2144_1703;
										      arg2143_1702 = CAR(slots_1680);
										      {
											 obj_t arg2145_1704;
											 arg2145_1704 = MAKE_PAIR(name_1684, BNIL);
											 arg2144_1703 = MAKE_PAIR(sid_1699, arg2145_1704);
										      }
										      SET_CDR(arg2143_1702, arg2144_1703);
										   }
										   {
										      obj_t aux_4016;
										      aux_4016 = CAR(slots_1680);
										      SET_CAR(aux_4016, type_1700);
										   }
										   {
										      obj_t slots_4019;
										      slots_4019 = CDR(slots_1680);
										      slots_1680 = slots_4019;
										      goto loop_1681;
										   }
										}
									      else
										{
										   return BFALSE;
										}
									   }
									}
								     }
								  }
							       }
							    }
							  else
							    {
							       return BFALSE;
							    }
						       }
						     else
						       {
							  return BFALSE;
						       }
						  }
						else
						  {
						     return BFALSE;
						  }
					     }
					   else
					     {
						return BFALSE;
					     }
					}
				      else
					{
					   return BFALSE;
					}
				   }
				}
			   }
			}
		      else
			{
			   bool_t test_4022;
			   {
			      obj_t aux_4023;
			      aux_4023 = CNST_TABLE_REF(((long) 11));
			      test_4022 = (car_2009_230_1559 == aux_4023);
			   }
			   if (test_4022)
			     {
				goto kap_2011_203_1560;
			     }
			   else
			     {
				obj_t cdr_2016_89_1563;
				cdr_2016_89_1563 = CDR(t_exp_39_27);
				{
				   bool_t test_4027;
				   {
				      obj_t aux_4028;
				      aux_4028 = CNST_TABLE_REF(((long) 12));
				      test_4027 = (car_2009_230_1559 == aux_4028);
				   }
				   if (test_4027)
				     {
					if (PAIRP(cdr_2016_89_1563))
					  {
					     bool_t test_4033;
					     {
						obj_t aux_4034;
						aux_4034 = CAR(cdr_2016_89_1563);
						test_4033 = SYMBOLP(aux_4034);
					     }
					     if (test_4033)
					       {
						  bool_t test_4037;
						  {
						     obj_t aux_4038;
						     aux_4038 = CDR(cdr_2016_89_1563);
						     test_4037 = (aux_4038 == BNIL);
						  }
						  if (test_4037)
						    {
						       return t_exp_39_27;
						    }
						  else
						    {
						       return BFALSE;
						    }
					       }
					     else
					       {
						  return BFALSE;
					       }
					  }
					else
					  {
					     return BFALSE;
					  }
				     }
				   else
				     {
					{
					   bool_t test_4041;
					   {
					      obj_t aux_4042;
					      aux_4042 = CNST_TABLE_REF(((long) 16));
					      test_4041 = (car_2009_230_1559 == aux_4042);
					   }
					   if (test_4041)
					     {
					      kap_2069_146_1580:
						if (PAIRP(cdr_2016_89_1563))
						  {
						     bool_t test_4047;
						     {
							obj_t aux_4048;
							aux_4048 = CAR(cdr_2016_89_1563);
							test_4047 = SYMBOLP(aux_4048);
						     }
						     if (test_4047)
						       {
							  bool_t test_4051;
							  {
							     obj_t aux_4052;
							     aux_4052 = CDR(cdr_2016_89_1563);
							     test_4051 = (aux_4052 == BNIL);
							  }
							  if (test_4051)
							    {
							       return t_exp_39_27;
							    }
							  else
							    {
							       obj_t cdr_2078_49_1619;
							       cdr_2078_49_1619 = CDR(t_exp_39_27);
							       {
								  bool_t test_4056;
								  {
								     obj_t aux_4059;
								     obj_t aux_4057;
								     aux_4059 = CNST_TABLE_REF(((long) 13));
								     aux_4057 = CAR(t_exp_39_27);
								     test_4056 = (aux_4057 == aux_4059);
								  }
								  if (test_4056)
								    {
								       obj_t cdr_2081_176_1621;
								       cdr_2081_176_1621 = CDR(cdr_2078_49_1619);
								       {
									  bool_t test_4063;
									  {
									     obj_t aux_4064;
									     aux_4064 = CAR(cdr_2078_49_1619);
									     test_4063 = SYMBOLP(aux_4064);
									  }
									  if (test_4063)
									    {
									       if (PAIRP(cdr_2081_176_1621))
										 {
										    obj_t car_2083_191_1624;
										    car_2083_191_1624 = CAR(cdr_2081_176_1621);
										    {
										       if ((car_2083_191_1624 == BNIL))
											 {
											  kap_2087_208_1625:
											    {
											       bool_t test_4072;
											       {
												  obj_t aux_4073;
												  aux_4073 = CDR(cdr_2081_176_1621);
												  test_4072 = (aux_4073 == BNIL);
											       }
											       if (test_4072)
												 {
												    if (check_c_args__102_module_foreign(car_2083_191_1624))
												      {
													 return t_exp_39_27;
												      }
												    else
												      {
													 return BFALSE;
												      }
												 }
											       else
												 {
												    return BFALSE;
												 }
											    }
											 }
										       else
											 {
											    if (PAIRP(car_2083_191_1624))
											      {
												 goto kap_2087_208_1625;
											      }
											    else
											      {
												 return BFALSE;
											      }
											 }
										    }
										 }
									       else
										 {
										    return BFALSE;
										 }
									    }
									  else
									    {
									       return BFALSE;
									    }
								       }
								    }
								  else
								    {
								       bool_t test_4080;
								       {
									  obj_t aux_4083;
									  obj_t aux_4081;
									  aux_4083 = CNST_TABLE_REF(((long) 14));
									  aux_4081 = CAR(t_exp_39_27);
									  test_4080 = (aux_4081 == aux_4083);
								       }
								       if (test_4080)
									 {
									    slots_1553 = cdr_2078_49_1619;
									  tag_2001_85_1554:
									    {
									       obj_t slots_1710;
									       slots_1710 = slots_1553;
									     loop_1711:
									       if (NULLP(slots_1710))
										 {
										    return t_exp_39_27;
										 }
									       else
										 {
										    {
										       obj_t e_2236_186_1715;
										       e_2236_186_1715 = CAR(slots_1710);
										       if (PAIRP(e_2236_186_1715))
											 {
											    obj_t cdr_2238_3_1717;
											    cdr_2238_3_1717 = CDR(e_2236_186_1715);
											    {
											       bool_t test_4092;
											       {
												  obj_t aux_4093;
												  aux_4093 = CAR(e_2236_186_1715);
												  test_4092 = SYMBOLP(aux_4093);
											       }
											       if (test_4092)
												 {
												    if (PAIRP(cdr_2238_3_1717))
												      {
													 bool_t test_4098;
													 {
													    obj_t aux_4099;
													    aux_4099 = CAR(cdr_2238_3_1717);
													    test_4098 = STRINGP(aux_4099);
													 }
													 if (test_4098)
													   {
													      bool_t test_4102;
													      {
														 obj_t aux_4103;
														 aux_4103 = CDR(cdr_2238_3_1717);
														 test_4102 = (aux_4103 == BNIL);
													      }
													      if (test_4102)
														{
														   {
														      obj_t slots_4106;
														      slots_4106 = CDR(slots_1710);
														      slots_1710 = slots_4106;
														      goto loop_1711;
														   }
														}
													      else
														{
														   return BFALSE;
														}
													   }
													 else
													   {
													      return BFALSE;
													   }
												      }
												    else
												      {
													 return BFALSE;
												      }
												 }
											       else
												 {
												    return BFALSE;
												 }
											    }
											 }
										       else
											 {
											    return BFALSE;
											 }
										    }
										 }
									    }
									 }
								       else
									 {
									    return BFALSE;
									 }
								    }
							       }
							    }
						       }
						     else
						       {
							  obj_t cdr_2105_238_1641;
							  cdr_2105_238_1641 = CDR(t_exp_39_27);
							  {
							     bool_t test_4109;
							     {
								obj_t aux_4112;
								obj_t aux_4110;
								aux_4112 = CNST_TABLE_REF(((long) 15));
								aux_4110 = CAR(t_exp_39_27);
								test_4109 = (aux_4110 == aux_4112);
							     }
							     if (test_4109)
							       {
								  bool_t test_4115;
								  {
								     obj_t aux_4116;
								     aux_4116 = CAR(cdr_2105_238_1641);
								     test_4115 = SYMBOLP(aux_4116);
								  }
								  if (test_4115)
								    {
								       bool_t test_4119;
								       {
									  obj_t aux_4120;
									  aux_4120 = CDR(cdr_2105_238_1641);
									  test_4119 = (aux_4120 == BNIL);
								       }
								       if (test_4119)
									 {
									    return t_exp_39_27;
									 }
								       else
									 {
									    return BFALSE;
									 }
								    }
								  else
								    {
								       return BFALSE;
								    }
							       }
							     else
							       {
								  bool_t test_4123;
								  {
								     obj_t aux_4126;
								     obj_t aux_4124;
								     aux_4126 = CNST_TABLE_REF(((long) 13));
								     aux_4124 = CAR(t_exp_39_27);
								     test_4123 = (aux_4124 == aux_4126);
								  }
								  if (test_4123)
								    {
								       obj_t cdr_2125_174_1650;
								       cdr_2125_174_1650 = CDR(cdr_2105_238_1641);
								       {
									  bool_t test_4130;
									  {
									     obj_t aux_4131;
									     aux_4131 = CAR(cdr_2105_238_1641);
									     test_4130 = SYMBOLP(aux_4131);
									  }
									  if (test_4130)
									    {
									       if (PAIRP(cdr_2125_174_1650))
										 {
										    obj_t car_2127_77_1653;
										    car_2127_77_1653 = CAR(cdr_2125_174_1650);
										    {
										       if ((car_2127_77_1653 == BNIL))
											 {
											  kap_2131_246_1654:
											    {
											       bool_t test_4139;
											       {
												  obj_t aux_4140;
												  aux_4140 = CDR(cdr_2125_174_1650);
												  test_4139 = (aux_4140 == BNIL);
											       }
											       if (test_4139)
												 {
												    if (check_c_args__102_module_foreign(car_2127_77_1653))
												      {
													 return t_exp_39_27;
												      }
												    else
												      {
													 return BFALSE;
												      }
												 }
											       else
												 {
												    return BFALSE;
												 }
											    }
											 }
										       else
											 {
											    if (PAIRP(car_2127_77_1653))
											      {
												 goto kap_2131_246_1654;
											      }
											    else
											      {
												 return BFALSE;
											      }
											 }
										    }
										 }
									       else
										 {
										    return BFALSE;
										 }
									    }
									  else
									    {
									       return BFALSE;
									    }
								       }
								    }
								  else
								    {
								       bool_t test_4147;
								       {
									  obj_t aux_4150;
									  obj_t aux_4148;
									  aux_4150 = CNST_TABLE_REF(((long) 14));
									  aux_4148 = CAR(t_exp_39_27);
									  test_4147 = (aux_4148 == aux_4150);
								       }
								       if (test_4147)
									 {
									    obj_t slots_4153;
									    slots_4153 = cdr_2105_238_1641;
									    slots_1553 = slots_4153;
									    goto tag_2001_85_1554;
									 }
								       else
									 {
									    return BFALSE;
									 }
								    }
							       }
							  }
						       }
						  }
						else
						  {
						     bool_t test_4154;
						     {
							obj_t aux_4157;
							obj_t aux_4155;
							aux_4157 = CNST_TABLE_REF(((long) 14));
							aux_4155 = CAR(t_exp_39_27);
							test_4154 = (aux_4155 == aux_4157);
						     }
						     if (test_4154)
						       {
							  obj_t slots_4160;
							  slots_4160 = CDR(t_exp_39_27);
							  slots_1553 = slots_4160;
							  goto tag_2001_85_1554;
						       }
						     else
						       {
							  return BFALSE;
						       }
						  }
					     }
					   else
					     {
						bool_t test_4162;
						{
						   obj_t aux_4163;
						   aux_4163 = CNST_TABLE_REF(((long) 17));
						   test_4162 = (car_2009_230_1559 == aux_4163);
						}
						if (test_4162)
						  {
						     goto kap_2069_146_1580;
						  }
						else
						  {
						     bool_t test_4166;
						     {
							obj_t aux_4167;
							aux_4167 = CNST_TABLE_REF(((long) 15));
							test_4166 = (car_2009_230_1559 == aux_4167);
						     }
						     if (test_4166)
						       {
							  if (PAIRP(cdr_2016_89_1563))
							    {
							       bool_t test_4172;
							       {
								  obj_t aux_4173;
								  aux_4173 = CAR(cdr_2016_89_1563);
								  test_4172 = SYMBOLP(aux_4173);
							       }
							       if (test_4172)
								 {
								    bool_t test_4176;
								    {
								       obj_t aux_4177;
								       aux_4177 = CDR(cdr_2016_89_1563);
								       test_4176 = (aux_4177 == BNIL);
								    }
								    if (test_4176)
								      {
									 return t_exp_39_27;
								      }
								    else
								      {
									 return BFALSE;
								      }
								 }
							       else
								 {
								    return BFALSE;
								 }
							    }
							  else
							    {
							       return BFALSE;
							    }
						       }
						     else
						       {
							  bool_t test_4180;
							  {
							     obj_t aux_4181;
							     aux_4181 = CNST_TABLE_REF(((long) 13));
							     test_4180 = (car_2009_230_1559 == aux_4181);
							  }
							  if (test_4180)
							    {
							       if (PAIRP(cdr_2016_89_1563))
								 {
								    obj_t cdr_2184_252_1594;
								    cdr_2184_252_1594 = CDR(cdr_2016_89_1563);
								    {
								       bool_t test_4187;
								       {
									  obj_t aux_4188;
									  aux_4188 = CAR(cdr_2016_89_1563);
									  test_4187 = SYMBOLP(aux_4188);
								       }
								       if (test_4187)
									 {
									    if (PAIRP(cdr_2184_252_1594))
									      {
										 obj_t car_2186_207_1597;
										 car_2186_207_1597 = CAR(cdr_2184_252_1594);
										 {
										    if ((car_2186_207_1597 == BNIL))
										      {
										       kap_2190_221_1598:
											 {
											    bool_t test_4196;
											    {
											       obj_t aux_4197;
											       aux_4197 = CDR(cdr_2184_252_1594);
											       test_4196 = (aux_4197 == BNIL);
											    }
											    if (test_4196)
											      {
												 if (check_c_args__102_module_foreign(car_2186_207_1597))
												   {
												      return t_exp_39_27;
												   }
												 else
												   {
												      return BFALSE;
												   }
											      }
											    else
											      {
												 return BFALSE;
											      }
											 }
										      }
										    else
										      {
											 if (PAIRP(car_2186_207_1597))
											   {
											      goto kap_2190_221_1598;
											   }
											 else
											   {
											      return BFALSE;
											   }
										      }
										 }
									      }
									    else
									      {
										 return BFALSE;
									      }
									 }
								       else
									 {
									    return BFALSE;
									 }
								    }
								 }
							       else
								 {
								    return BFALSE;
								 }
							    }
							  else
							    {
							       bool_t test_4204;
							       {
								  obj_t aux_4205;
								  aux_4205 = CNST_TABLE_REF(((long) 14));
								  test_4204 = (car_2009_230_1559 == aux_4205);
							       }
							       if (test_4204)
								 {
								    obj_t slots_4208;
								    slots_4208 = cdr_2016_89_1563;
								    slots_1553 = slots_4208;
								    goto tag_2001_85_1554;
								 }
							       else
								 {
								    return BFALSE;
								 }
							    }
						       }
						  }
					     }
					}
				     }
				}
			     }
			}
		   }
		}
	     }
	   else
	     {
		return BFALSE;
	     }
	}
   }
}


/* foreign-finalizer */ obj_t 
foreign_finalizer_169_module_foreign()
{
   {
      obj_t l1315_1727;
      l1315_1727 = _foreign_exported__195_module_foreign;
    lname1316_1728:
      if (PAIRP(l1315_1727))
	{
	   {
	      obj_t foreign_1730;
	      foreign_1730 = CAR(l1315_1727);
	      {
		 obj_t global_1731;
		 obj_t name_1732;
		 {
		    obj_t aux_4212;
		    {
		       obj_t aux_4213;
		       aux_4213 = CDR(foreign_1730);
		       aux_4212 = CAR(aux_4213);
		    }
		    global_1731 = find_global_223_ast_env(aux_4212, BNIL);
		 }
		 {
		    obj_t aux_4217;
		    {
		       obj_t aux_4218;
		       aux_4218 = CDR(foreign_1730);
		       aux_4217 = CDR(aux_4218);
		    }
		    name_1732 = CAR(aux_4217);
		 }
		 {
		    bool_t test2163_1733;
		    test2163_1733 = is_a__118___object(global_1731, global_ast_var);
		    if (test2163_1733)
		      {
			 bool_t test_4224;
			 {
			    obj_t aux_4225;
			    {
			       global_t obj_2779;
			       obj_2779 = (global_t) (global_1731);
			       aux_4225 = (((global_t) CREF(obj_2779))->name);
			    }
			    test_4224 = STRINGP(aux_4225);
			 }
			 if (test_4224)
			   {
			      user_warning_209_tools_error(string2251_module_foreign, string2252_module_foreign, foreign_1730);
			   }
			 else
			   {
			      {
				 global_t obj_2781;
				 obj_2781 = (global_t) (global_1731);
				 ((((global_t) CREF(obj_2781))->name) = ((obj_t) name_1732), BUNSPEC);
			      }
			   }
		      }
		    else
		      {
			 {
			    obj_t list2170_1739;
			    list2170_1739 = MAKE_PAIR(BNIL, BNIL);
			    user_error_151_tools_error(string2251_module_foreign, string2253_module_foreign, foreign_1730, list2170_1739);
			 }
		      }
		 }
	      }
	   }
	   {
	      obj_t l1315_4234;
	      l1315_4234 = CDR(l1315_1727);
	      l1315_1727 = l1315_4234;
	      goto lname1316_1728;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   _foreign_exported__195_module_foreign = BNIL;
   {
      bool_t test2176_1744;
      {
	 obj_t obj_2784;
	 obj_2784 = _foreign_accesses__124_module_foreign;
	 test2176_1744 = NULLP(obj_2784);
      }
      if (test2176_1744)
	{
	   return CNST_TABLE_REF(((long) 2));
	}
      else
	{
	   obj_t accesses_1745;
	   accesses_1745 = reverse__39___r4_pairs_and_lists_6_3(_foreign_accesses__124_module_foreign);
	   _foreign_accesses__124_module_foreign = BNIL;
	   {
	      obj_t arg2178_1746;
	      {
		 obj_t arg2181_1749;
		 arg2181_1749 = CNST_TABLE_REF(((long) 0));
		 {
		    obj_t new_2789;
		    {
		       obj_t aux_4241;
		       aux_4241 = CNST_TABLE_REF(((long) 18));
		       new_2789 = create_struct(aux_4241, ((long) 4));
		    }
		    STRUCT_SET(new_2789, ((long) 3), BTRUE);
		    STRUCT_SET(new_2789, ((long) 2), accesses_1745);
		    {
		       obj_t aux_4246;
		       aux_4246 = BINT(((long) 48));
		       STRUCT_SET(new_2789, ((long) 1), aux_4246);
		    }
		    STRUCT_SET(new_2789, ((long) 0), arg2181_1749);
		    arg2178_1746 = new_2789;
		 }
	      }
	      {
		 obj_t list2179_1747;
		 list2179_1747 = MAKE_PAIR(arg2178_1746, BNIL);
		 return list2179_1747;
	      }
	   }
	}
   }
}


/* _foreign-finalizer */ obj_t 
_foreign_finalizer_56_module_foreign(obj_t env_2866)
{
   return foreign_finalizer_169_module_foreign();
}


/* method-init */ obj_t 
method_init_76_module_foreign()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_foreign()
{
   module_initialization_70_tools_trace(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_module_module(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_module_checksum(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_engine_param(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_ast_glo_decl_237(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_tools_error(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_tools_shape(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_type_type(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_type_env(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_type_tools(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_ast_var(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_ast_env(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_ast_ident(((long) 0), "MODULE_FOREIGN");
   module_initialization_70_foreign_ctype(((long) 0), "MODULE_FOREIGN");
   return module_initialization_70_foreign_access(((long) 0), "MODULE_FOREIGN");
}
