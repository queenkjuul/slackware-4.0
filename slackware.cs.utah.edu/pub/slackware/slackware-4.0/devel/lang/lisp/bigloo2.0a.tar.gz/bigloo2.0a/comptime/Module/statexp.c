/*===========================================================================*/
/*   (Module/statexp.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t ccomp_module_module;
static obj_t statexp_parser_81_module_statexp(obj_t, obj_t);
extern global_t declare_global_sfun__255_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_module_statexp();
extern obj_t class_finalizer_253_module_class();
static obj_t export_checksummer_174_module_statexp(obj_t, obj_t);
static obj_t _export_consumer_28_module_statexp(obj_t, obj_t, obj_t);
static obj_t _make_export_compiler_160_module_statexp(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t _local_classes__10_module_statexp = BUNSPEC;
extern type_t type_of_id_183_ast_ident(obj_t);
static obj_t _statexp_producer_253_module_statexp(obj_t, obj_t);
extern obj_t module_initialization_70_module_statexp(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_prototype(long, char *);
extern obj_t module_initialization_70_module_class(long, char *);
extern obj_t module_initialization_70_module_checksum(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_find_gdefs_13(long, char *);
extern obj_t module_initialization_70_ast_glo_decl_237(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern long get_hash_power_number(char *, long);
extern long class_num_218___object(obj_t);
static obj_t _statexp_finalizer_125_module_statexp(obj_t);
static obj_t statexp_producer_46_module_statexp(obj_t);
static obj_t statexp_finalizer_204_module_statexp();
extern obj_t make_export_compiler_49_module_statexp();
static obj_t imported_modules_init_94_module_statexp();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
static obj_t _make_static_compiler_13_module_statexp(obj_t);
static obj_t library_modules_init_112_module_statexp();
extern global_t declare_global_svar__200_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_module_statexp();
extern obj_t open_input_string(obj_t);
extern int arity_tools_args(obj_t);
static obj_t _export_checksummer_163_module_statexp(obj_t, obj_t, obj_t);
extern obj_t to_be_define__131_ast_find_gdefs_13(global_t);
extern obj_t make_promise_21___r4_control_features_6_9(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t get_class_hash_100_module_class(obj_t, obj_t);
extern obj_t declare_class__31_module_class(obj_t, obj_t, obj_t, bool_t, obj_t);
extern obj_t make_static_compiler_70_module_statexp();
static obj_t arg1290_module_statexp(obj_t);
static obj_t arg1284_module_statexp(obj_t);
static obj_t arg1278_module_statexp(obj_t);
static obj_t arg1222_module_statexp(obj_t, obj_t, obj_t);
static obj_t arg1221_module_statexp(obj_t);
static obj_t arg1220_module_statexp(obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
static obj_t export_consumer_235_module_statexp(obj_t, obj_t);
extern obj_t declare_wide_class__13_module_class(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_module_statexp = BUNSPEC;
extern obj_t parse_prototype_143_module_prototype(obj_t);
static obj_t cnst_init_137_module_statexp();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[9];

DEFINE_STATIC_PROCEDURE(statexp_producer_env_28_module_statexp, _statexp_producer_253_module_statexp1465, _statexp_producer_253_module_statexp, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_static_compiler_env_79_module_statexp, _make_static_compiler_13_module_statexp1466, _make_static_compiler_13_module_statexp, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_export_compiler_env_110_module_statexp, _make_export_compiler_160_module_statexp1467, _make_export_compiler_160_module_statexp, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1452_module_statexp, arg1220_module_statexp1468, arg1220_module_statexp, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1451_module_statexp, arg1221_module_statexp1469, arg1221_module_statexp, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1450_module_statexp, arg1222_module_statexp1470, arg1222_module_statexp, 0L, 2);
DEFINE_STATIC_PROCEDURE(statexp_finalizer_env_236_module_statexp, _statexp_finalizer_125_module_statexp1471, _statexp_finalizer_125_module_statexp, 0L, 0);
DEFINE_STATIC_PROCEDURE(export_checksummer_env_156_module_statexp, _export_checksummer_163_module_statexp1472, _export_checksummer_163_module_statexp, 0L, 2);
DEFINE_STATIC_PROCEDURE(export_consumer_env_201_module_statexp, _export_consumer_28_module_statexp1473, _export_consumer_28_module_statexp, 0L, 2);
DEFINE_STRING(string1458_module_statexp, string1458_module_statexp1474, "OBJ WIDE-CLASS FINAL-CLASS CLASS SVAR (SFUN SIFUN SGFUN) EXPORT VOID STATIC ", 76);
DEFINE_STRING(string1457_module_statexp, string1457_module_statexp1475, "Illegal prototype", 17);
DEFINE_STRING(string1456_module_statexp, string1456_module_statexp1476, "Illegal `export' clause", 23);
DEFINE_STRING(string1455_module_statexp, string1455_module_statexp1477, "Parse error", 11);
DEFINE_STRING(string1454_module_statexp, string1454_module_statexp1478, "Illegal `", 9);
DEFINE_STRING(string1453_module_statexp, string1453_module_statexp1479, "' clause", 8);


/* module-initialization */ obj_t 
module_initialization_70_module_statexp(long checksum_945, char *from_946)
{
   if (CBOOL(require_initialization_114_module_statexp))
     {
	require_initialization_114_module_statexp = BBOOL(((bool_t) 0));
	library_modules_init_112_module_statexp();
	cnst_init_137_module_statexp();
	imported_modules_init_94_module_statexp();
	method_init_76_module_statexp();
	toplevel_init_63_module_statexp();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_statexp()
{
   module_initialization_70___object(((long) 0), "MODULE_STATEXP");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_STATEXP");
   module_initialization_70___r4_control_features_6_9(((long) 0), "MODULE_STATEXP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_STATEXP");
   module_initialization_70___reader(((long) 0), "MODULE_STATEXP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_statexp()
{
   {
      obj_t cnst_port_138_937;
      cnst_port_138_937 = open_input_string(string1458_module_statexp);
      {
	 long i_938;
	 i_938 = ((long) 8);
       loop_939:
	 {
	    bool_t test1459_940;
	    test1459_940 = (i_938 == ((long) -1));
	    if (test1459_940)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1460_941;
		    {
		       obj_t list1461_942;
		       {
			  obj_t arg1463_943;
			  arg1463_943 = BNIL;
			  list1461_942 = MAKE_PAIR(cnst_port_138_937, arg1463_943);
		       }
		       arg1460_941 = read___reader(list1461_942);
		    }
		    CNST_TABLE_SET(i_938, arg1460_941);
		 }
		 {
		    int aux_944;
		    {
		       long aux_966;
		       aux_966 = (i_938 - ((long) 1));
		       aux_944 = (int) (aux_966);
		    }
		    {
		       long i_969;
		       i_969 = (long) (aux_944);
		       i_938 = i_969;
		       goto loop_939;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_statexp()
{
   return (_local_classes__10_module_statexp = BNIL,
      BUNSPEC);
}


/* make-static-compiler */ obj_t 
make_static_compiler_70_module_statexp()
{
   {
      obj_t arg1216_355;
      arg1216_355 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1222_900;
	 obj_t arg1221_901;
	 obj_t arg1220_902;
	 arg1222_900 = proc1450_module_statexp;
	 arg1221_901 = proc1451_module_statexp;
	 arg1220_902 = proc1452_module_statexp;
	 {
	    ccomp_t res1448_706;
	    {
	       ccomp_t new1002_697;
	       new1002_697 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1446_698;
		  arg1446_698 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_704;
		     obj_704 = (obj_t) (new1002_697);
		     (((obj_t) CREF(obj_704))->header = MAKE_HEADER(arg1446_698, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_976;
		  aux_976 = (object_t) (new1002_697);
		  OBJECT_WIDENING_SET(aux_976, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_697))->id) = ((obj_t) arg1216_355), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_697))->producer) = ((obj_t) statexp_producer_env_28_module_statexp), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_697))->consumer) = ((obj_t) arg1220_902), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_697))->finalizer) = ((obj_t) arg1221_901), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_697))->checksummer) = ((obj_t) arg1222_900), BUNSPEC);
	       res1448_706 = new1002_697;
	    }
	    return (obj_t) (res1448_706);
	 }
      }
   }
}


/* _make-static-compiler */ obj_t 
_make_static_compiler_13_module_statexp(obj_t env_903)
{
   return make_static_compiler_70_module_statexp();
}


/* arg1222 */ obj_t 
arg1222_module_statexp(obj_t env_904, obj_t m_905, obj_t c_906)
{
   {
      obj_t m_364;
      obj_t c_365;
      m_364 = m_905;
      c_365 = c_906;
      return c_365;
   }
}


/* arg1221 */ obj_t 
arg1221_module_statexp(obj_t env_907)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1220 */ obj_t 
arg1220_module_statexp(obj_t env_908, obj_t m_909, obj_t c_910)
{
   {
      obj_t m_360;
      obj_t c_361;
      m_360 = m_909;
      c_361 = c_910;
      return BNIL;
   }
}


/* make-export-compiler */ obj_t 
make_export_compiler_49_module_statexp()
{
   {
      obj_t arg1226_370;
      arg1226_370 = CNST_TABLE_REF(((long) 2));
      {
	 ccomp_t res1449_721;
	 {
	    ccomp_t new1002_712;
	    new1002_712 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	    {
	       long arg1446_713;
	       arg1446_713 = class_num_218___object(ccomp_module_module);
	       {
		  obj_t obj_719;
		  obj_719 = (obj_t) (new1002_712);
		  (((obj_t) CREF(obj_719))->header = MAKE_HEADER(arg1446_713, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_992;
	       aux_992 = (object_t) (new1002_712);
	       OBJECT_WIDENING_SET(aux_992, BFALSE);
	    }
	    ((((ccomp_t) CREF(new1002_712))->id) = ((obj_t) arg1226_370), BUNSPEC);
	    ((((ccomp_t) CREF(new1002_712))->producer) = ((obj_t) statexp_producer_env_28_module_statexp), BUNSPEC);
	    ((((ccomp_t) CREF(new1002_712))->consumer) = ((obj_t) export_consumer_env_201_module_statexp), BUNSPEC);
	    ((((ccomp_t) CREF(new1002_712))->finalizer) = ((obj_t) statexp_finalizer_env_236_module_statexp), BUNSPEC);
	    ((((ccomp_t) CREF(new1002_712))->checksummer) = ((obj_t) export_checksummer_env_156_module_statexp), BUNSPEC);
	    res1449_721 = new1002_712;
	 }
	 return (obj_t) (res1449_721);
      }
   }
}


/* _make-export-compiler */ obj_t 
_make_export_compiler_160_module_statexp(obj_t env_913)
{
   return make_export_compiler_49_module_statexp();
}


/* statexp-producer */ obj_t 
statexp_producer_46_module_statexp(obj_t clause_19)
{
   {
      obj_t mode_375;
      mode_375 = CAR(clause_19);
      {
	 obj_t protos_376;
	 if (PAIRP(clause_19))
	   {
	      protos_376 = CDR(clause_19);
	      {
		 obj_t l1192_382;
		 l1192_382 = protos_376;
	       lname1193_383:
		 if (PAIRP(l1192_382))
		   {
		      statexp_parser_81_module_statexp(CAR(l1192_382), mode_375);
		      {
			 obj_t l1192_1009;
			 l1192_1009 = CDR(l1192_382);
			 l1192_382 = l1192_1009;
			 goto lname1193_383;
		      }
		   }
		 else
		   {
		      ((bool_t) 1);
		   }
	      }
	      return BNIL;
	   }
	 else
	   {
	      {
		 obj_t arg1241_388;
		 {
		    obj_t arg1248_393;
		    {
		       obj_t arg1255_399;
		       arg1255_399 = SYMBOL_TO_STRING(mode_375);
		       arg1248_393 = string_downcase_77___r4_strings_6_7(arg1255_399);
		    }
		    {
		       obj_t list1251_395;
		       {
			  obj_t arg1252_396;
			  {
			     obj_t arg1253_397;
			     arg1253_397 = MAKE_PAIR(string1453_module_statexp, BNIL);
			     arg1252_396 = MAKE_PAIR(arg1248_393, arg1253_397);
			  }
			  list1251_395 = MAKE_PAIR(string1454_module_statexp, arg1252_396);
		       }
		       arg1241_388 = string_append_106___r4_strings_6_7(list1251_395);
		    }
		 }
		 {
		    obj_t list1244_390;
		    list1244_390 = MAKE_PAIR(BNIL, BNIL);
		    return user_error_151_tools_error(string1455_module_statexp, arg1241_388, clause_19, list1244_390);
		 }
	      }
	   }
      }
   }
}


/* _statexp-producer */ obj_t 
_statexp_producer_253_module_statexp(obj_t env_911, obj_t clause_912)
{
   return statexp_producer_46_module_statexp(clause_912);
}


/* export-consumer */ obj_t 
export_consumer_235_module_statexp(obj_t module_20, obj_t clause_21)
{
   {
      if (PAIRP(clause_21))
	{
	   return CDR(clause_21);
	}
      else
	{
	   {
	      obj_t list1261_409;
	      list1261_409 = MAKE_PAIR(BNIL, BNIL);
	      return user_error_151_tools_error(string1455_module_statexp, string1456_module_statexp, clause_21, list1261_409);
	   }
	}
   }
}


/* _export-consumer */ obj_t 
_export_consumer_28_module_statexp(obj_t env_914, obj_t module_915, obj_t clause_916)
{
   return export_consumer_235_module_statexp(module_915, clause_916);
}


/* statexp-parser */ obj_t 
statexp_parser_81_module_statexp(obj_t prototype_22, obj_t import_23)
{
   {
      obj_t proto_411;
      proto_411 = parse_prototype_143_module_prototype(prototype_22);
      if (PAIRP(proto_411))
	{
	   obj_t case_value_58_413;
	   case_value_58_413 = CAR(proto_411);
	   {
	      bool_t test_1031;
	      {
		 obj_t aux_1032;
		 aux_1032 = memq___r4_pairs_and_lists_6_3(case_value_58_413, CNST_TABLE_REF(((long) 3)));
		 test_1031 = CBOOL(aux_1032);
	      }
	      if (test_1031)
		{
		   global_t arg1265_415;
		   {
		      obj_t aux_1040;
		      obj_t aux_1036;
		      {
			 obj_t aux_1041;
			 {
			    obj_t aux_1042;
			    aux_1042 = CDR(proto_411);
			    aux_1041 = CDR(aux_1042);
			 }
			 aux_1040 = CAR(aux_1041);
		      }
		      {
			 obj_t aux_1037;
			 aux_1037 = CDR(proto_411);
			 aux_1036 = CAR(aux_1037);
		      }
		      arg1265_415 = declare_global_sfun__255_ast_glo_decl_237(aux_1036, aux_1040, _module__166_module_module, import_23, case_value_58_413, prototype_22);
		   }
		   return to_be_define__131_ast_find_gdefs_13(arg1265_415);
		}
	      else
		{
		   bool_t test_1048;
		   {
		      obj_t aux_1049;
		      aux_1049 = CNST_TABLE_REF(((long) 4));
		      test_1048 = (case_value_58_413 == aux_1049);
		   }
		   if (test_1048)
		     {
			global_t arg1272_420;
			{
			   obj_t aux_1052;
			   {
			      obj_t aux_1053;
			      aux_1053 = CDR(proto_411);
			      aux_1052 = CAR(aux_1053);
			   }
			   arg1272_420 = declare_global_svar__200_ast_glo_decl_237(aux_1052, _module__166_module_module, import_23, prototype_22);
			}
			return to_be_define__131_ast_find_gdefs_13(arg1272_420);
		     }
		   else
		     {
			bool_t test_1058;
			{
			   obj_t aux_1059;
			   aux_1059 = CNST_TABLE_REF(((long) 5));
			   test_1058 = (case_value_58_413 == aux_1059);
			}
			if (test_1058)
			  {
			     obj_t arg1277_423;
			     {
				obj_t arg1278_921;
				arg1278_921 = make_fx_procedure(arg1278_module_statexp, ((long) 0), ((long) 3));
				PROCEDURE_SET(arg1278_921, ((long) 0), proto_411);
				PROCEDURE_SET(arg1278_921, ((long) 1), import_23);
				PROCEDURE_SET(arg1278_921, ((long) 2), prototype_22);
				arg1277_423 = make_promise_21___r4_control_features_6_9(arg1278_921);
			     }
			     {
				obj_t obj2_756;
				obj2_756 = _local_classes__10_module_statexp;
				return (_local_classes__10_module_statexp = MAKE_PAIR(arg1277_423, obj2_756),
				   BUNSPEC);
			     }
			  }
			else
			  {
			     bool_t test_1068;
			     {
				obj_t aux_1069;
				aux_1069 = CNST_TABLE_REF(((long) 6));
				test_1068 = (case_value_58_413 == aux_1069);
			     }
			     if (test_1068)
			       {
				  obj_t arg1283_429;
				  {
				     obj_t arg1284_922;
				     arg1284_922 = make_fx_procedure(arg1284_module_statexp, ((long) 0), ((long) 3));
				     PROCEDURE_SET(arg1284_922, ((long) 0), proto_411);
				     PROCEDURE_SET(arg1284_922, ((long) 1), import_23);
				     PROCEDURE_SET(arg1284_922, ((long) 2), prototype_22);
				     arg1283_429 = make_promise_21___r4_control_features_6_9(arg1284_922);
				  }
				  {
				     obj_t obj2_762;
				     obj2_762 = _local_classes__10_module_statexp;
				     return (_local_classes__10_module_statexp = MAKE_PAIR(arg1283_429, obj2_762),
					BUNSPEC);
				  }
			       }
			     else
			       {
				  bool_t test_1078;
				  {
				     obj_t aux_1079;
				     aux_1079 = CNST_TABLE_REF(((long) 7));
				     test_1078 = (case_value_58_413 == aux_1079);
				  }
				  if (test_1078)
				    {
				       obj_t arg1288_435;
				       {
					  obj_t arg1290_923;
					  arg1290_923 = make_fx_procedure(arg1290_module_statexp, ((long) 0), ((long) 3));
					  PROCEDURE_SET(arg1290_923, ((long) 0), proto_411);
					  PROCEDURE_SET(arg1290_923, ((long) 1), import_23);
					  PROCEDURE_SET(arg1290_923, ((long) 2), prototype_22);
					  arg1288_435 = make_promise_21___r4_control_features_6_9(arg1290_923);
				       }
				       {
					  obj_t obj2_768;
					  obj2_768 = _local_classes__10_module_statexp;
					  return (_local_classes__10_module_statexp = MAKE_PAIR(arg1288_435, obj2_768),
					     BUNSPEC);
				       }
				    }
				  else
				    {
				       obj_t list1297_443;
				       list1297_443 = MAKE_PAIR(BNIL, BNIL);
				       return user_error_151_tools_error(string1455_module_statexp, string1457_module_statexp, prototype_22, list1297_443);
				    }
			       }
			  }
		     }
		}
	   }
	}
      else
	{
	   obj_t list1309_453;
	   list1309_453 = MAKE_PAIR(BNIL, BNIL);
	   return user_error_151_tools_error(string1455_module_statexp, string1457_module_statexp, prototype_22, list1309_453);
	}
   }
}


/* arg1278 */ obj_t 
arg1278_module_statexp(obj_t env_924)
{
   {
      obj_t proto_925;
      obj_t import_926;
      obj_t prototype_927;
      proto_925 = PROCEDURE_REF(env_924, ((long) 0));
      import_926 = PROCEDURE_REF(env_924, ((long) 1));
      prototype_927 = PROCEDURE_REF(env_924, ((long) 2));
      {
	 return declare_class__31_module_class(CDR(proto_925), _module__166_module_module, import_926, ((bool_t) 0), prototype_927);
      }
   }
}


/* arg1284 */ obj_t 
arg1284_module_statexp(obj_t env_928)
{
   {
      obj_t proto_929;
      obj_t import_930;
      obj_t prototype_931;
      proto_929 = PROCEDURE_REF(env_928, ((long) 0));
      import_930 = PROCEDURE_REF(env_928, ((long) 1));
      prototype_931 = PROCEDURE_REF(env_928, ((long) 2));
      {
	 return declare_class__31_module_class(CDR(proto_929), _module__166_module_module, import_930, ((bool_t) 1), prototype_931);
      }
   }
}


/* arg1290 */ obj_t 
arg1290_module_statexp(obj_t env_932)
{
   {
      obj_t proto_933;
      obj_t import_934;
      obj_t prototype_935;
      proto_933 = PROCEDURE_REF(env_932, ((long) 0));
      import_934 = PROCEDURE_REF(env_932, ((long) 1));
      prototype_935 = PROCEDURE_REF(env_932, ((long) 2));
      {
	 return declare_wide_class__13_module_class(CDR(proto_933), _module__166_module_module, import_934, prototype_935);
      }
   }
}


/* statexp-finalizer */ obj_t 
statexp_finalizer_204_module_statexp()
{
   {
      obj_t l1194_455;
      {
	 obj_t arg1311_457;
	 arg1311_457 = reverse__39___r4_pairs_and_lists_6_3(_local_classes__10_module_statexp);
	 l1194_455 = arg1311_457;
       lname1195_456:
	 if (PAIRP(l1194_455))
	   {
	      {
		 obj_t arg1313_459;
		 arg1313_459 = CAR(l1194_455);
		 PROCEDURE_ENTRY(arg1313_459) (arg1313_459, BEOA);
	      }
	      {
		 obj_t l1194_1113;
		 l1194_1113 = CDR(l1194_455);
		 l1194_455 = l1194_1113;
		 goto lname1195_456;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   _local_classes__10_module_statexp = BNIL;
   {
      obj_t classes_461;
      classes_461 = class_finalizer_253_module_class();
      if (PAIRP(classes_461))
	{
	   return classes_461;
	}
      else
	{
	   return CNST_TABLE_REF(((long) 1));
	}
   }
}


/* _statexp-finalizer */ obj_t 
_statexp_finalizer_125_module_statexp(obj_t env_917)
{
   return statexp_finalizer_204_module_statexp();
}


/* export-checksummer */ obj_t 
export_checksummer_174_module_statexp(obj_t eclause_25, obj_t checksum_26)
{
   {
      obj_t clause_472;
      obj_t checksum_473;
      {
	 obj_t clauses_464;
	 obj_t checksum_465;
	 clauses_464 = CDR(eclause_25);
	 checksum_465 = checksum_26;
       loop_466:
	 if (NULLP(clauses_464))
	   {
	      return checksum_465;
	   }
	 else
	   {
	      obj_t arg1321_469;
	      obj_t arg1322_470;
	      arg1321_469 = CDR(clauses_464);
	      clause_472 = CAR(clauses_464);
	      checksum_473 = checksum_465;
	      {
		 obj_t proto_475;
		 proto_475 = parse_prototype_143_module_prototype(clause_472);
		 if (PAIRP(proto_475))
		   {
		      obj_t case_value_58_478;
		      case_value_58_478 = CAR(proto_475);
		      {
			 bool_t test_1127;
			 {
			    obj_t aux_1128;
			    aux_1128 = memq___r4_pairs_and_lists_6_3(case_value_58_478, CNST_TABLE_REF(((long) 3)));
			    test_1127 = CBOOL(aux_1128);
			 }
			 if (test_1127)
			   {
			      long checksum_480;
			      obj_t args_481;
			      {
				 long arg1328_483;
				 obj_t arg1330_484;
				 {
				    long arg1331_485;
				    long arg1332_486;
				    {
				       obj_t arg1405_784;
				       arg1405_784 = SYMBOL_TO_STRING(case_value_58_478);
				       {
					  char *aux_1133;
					  aux_1133 = BSTRING_TO_STRING(arg1405_784);
					  arg1331_485 = get_hash_power_number(aux_1133, ((long) 16));
				       }
				    }
				    {
				       long arg1334_488;
				       long arg1337_489;
				       {
					  obj_t arg1405_794;
					  {
					     obj_t aux_1136;
					     {
						obj_t aux_1137;
						aux_1137 = CDR(proto_475);
						aux_1136 = CAR(aux_1137);
					     }
					     arg1405_794 = SYMBOL_TO_STRING(aux_1136);
					  }
					  {
					     char *aux_1141;
					     aux_1141 = BSTRING_TO_STRING(arg1405_794);
					     arg1334_488 = get_hash_power_number(aux_1141, ((long) 16));
					  }
				       }
				       {
					  int arg1340_491;
					  {
					     obj_t aux_1144;
					     {
						obj_t aux_1145;
						{
						   obj_t aux_1146;
						   aux_1146 = CDR(proto_475);
						   aux_1145 = CDR(aux_1146);
						}
						aux_1144 = CAR(aux_1145);
					     }
					     arg1340_491 = arity_tools_args(aux_1144);
					  }
					  {
					     long aux_1153;
					     long aux_1151;
					     aux_1153 = (long) CINT(checksum_473);
					     aux_1151 = (long) (arg1340_491);
					     arg1337_489 = (aux_1151 ^ aux_1153);
					  }
				       }
				       arg1332_486 = (arg1334_488 ^ arg1337_489);
				    }
				    arg1328_483 = (arg1331_485 ^ arg1332_486);
				 }
				 {
				    obj_t aux_1158;
				    {
				       obj_t aux_1159;
				       aux_1159 = CDR(proto_475);
				       aux_1158 = CDR(aux_1159);
				    }
				    arg1330_484 = CAR(aux_1158);
				 }
				 {
				    long aux_1163;
				    checksum_480 = arg1328_483;
				    args_481 = arg1330_484;
				  loop_482:
				    if (NULLP(args_481))
				      {
					 aux_1163 = checksum_480;
				      }
				    else
				      {
					 if (PAIRP(args_481))
					   {
					      bool_t test_1168;
					      {
						 obj_t aux_1169;
						 aux_1169 = CAR(args_481);
						 test_1168 = CNSTP(aux_1169);
					      }
					      if (test_1168)
						{
						   {
						      long arg1347_496;
						      obj_t arg1349_497;
						      {
							 long arg1350_498;
							 {
							    obj_t aux_1172;
							    aux_1172 = CAR(args_481);
							    arg1350_498 = CCNST(aux_1172);
							 }
							 arg1347_496 = (arg1350_498 ^ checksum_480);
						      }
						      arg1349_497 = CDR(args_481);
						      {
							 obj_t args_1178;
							 long checksum_1177;
							 checksum_1177 = arg1347_496;
							 args_1178 = arg1349_497;
							 args_481 = args_1178;
							 checksum_480 = checksum_1177;
							 goto loop_482;
						      }
						   }
						}
					      else
						{
						   {
						      type_t type_500;
						      type_500 = type_of_id_183_ast_ident(CAR(args_481));
						      {
							 {
							    long arg1352_502;
							    obj_t arg1353_503;
							    {
							       long arg1355_504;
							       {
								  obj_t arg1405_828;
								  {
								     obj_t aux_1181;
								     aux_1181 = (((type_t) CREF(type_500))->id);
								     arg1405_828 = SYMBOL_TO_STRING(aux_1181);
								  }
								  {
								     char *aux_1184;
								     aux_1184 = BSTRING_TO_STRING(arg1405_828);
								     arg1355_504 = get_hash_power_number(aux_1184, ((long) 16));
								  }
							       }
							       arg1352_502 = (arg1355_504 ^ checksum_480);
							    }
							    arg1353_503 = CDR(args_481);
							    {
							       obj_t args_1190;
							       long checksum_1189;
							       checksum_1189 = arg1352_502;
							       args_1190 = arg1353_503;
							       args_481 = args_1190;
							       checksum_480 = checksum_1189;
							       goto loop_482;
							    }
							 }
						      }
						   }
						}
					   }
					 else
					   {
					      {
						 long arg1361_507;
						 {
						    obj_t arg1405_837;
						    {
						       obj_t aux_1191;
						       aux_1191 = CNST_TABLE_REF(((long) 8));
						       arg1405_837 = SYMBOL_TO_STRING(aux_1191);
						    }
						    {
						       char *aux_1194;
						       aux_1194 = BSTRING_TO_STRING(arg1405_837);
						       arg1361_507 = get_hash_power_number(aux_1194, ((long) 16));
						    }
						 }
						 aux_1163 = (arg1361_507 ^ checksum_480);
					      }
					   }
				      }
				    arg1322_470 = BINT(aux_1163);
				 }
			      }
			   }
			 else
			   {
			      bool_t test_1199;
			      {
				 obj_t aux_1200;
				 aux_1200 = CNST_TABLE_REF(((long) 4));
				 test_1199 = (case_value_58_478 == aux_1200);
			      }
			      if (test_1199)
				{
				   long arg1365_510;
				   {
				      obj_t arg1405_851;
				      {
					 obj_t aux_1203;
					 {
					    obj_t aux_1204;
					    aux_1204 = CDR(proto_475);
					    aux_1203 = CAR(aux_1204);
					 }
					 arg1405_851 = SYMBOL_TO_STRING(aux_1203);
				      }
				      {
					 char *aux_1208;
					 aux_1208 = BSTRING_TO_STRING(arg1405_851);
					 arg1365_510 = get_hash_power_number(aux_1208, ((long) 16));
				      }
				   }
				   {
				      long aux_1211;
				      {
					 long aux_1212;
					 aux_1212 = (long) CINT(checksum_473);
					 aux_1211 = (aux_1212 ^ arg1365_510);
				      }
				      arg1322_470 = BINT(aux_1211);
				   }
				}
			      else
				{
				   bool_t test_1216;
				   {
				      obj_t aux_1217;
				      aux_1217 = CNST_TABLE_REF(((long) 5));
				      test_1216 = (case_value_58_478 == aux_1217);
				   }
				   if (test_1216)
				     {
					obj_t arg1369_513;
					{
					   obj_t aux_1220;
					   {
					      obj_t aux_1221;
					      aux_1221 = CDR(proto_475);
					      aux_1220 = CAR(aux_1221);
					   }
					   arg1369_513 = get_class_hash_100_module_class(aux_1220, clause_472);
					}
					{
					   long aux_1225;
					   {
					      long aux_1228;
					      long aux_1226;
					      aux_1228 = (long) CINT(arg1369_513);
					      aux_1226 = (long) CINT(checksum_473);
					      aux_1225 = (aux_1226 ^ aux_1228);
					   }
					   arg1322_470 = BINT(aux_1225);
					}
				     }
				   else
				     {
					bool_t test_1232;
					{
					   obj_t aux_1233;
					   aux_1233 = CNST_TABLE_REF(((long) 6));
					   test_1232 = (case_value_58_478 == aux_1233);
					}
					if (test_1232)
					  {
					     long arg1372_516;
					     {
						obj_t arg1375_518;
						{
						   obj_t aux_1236;
						   {
						      obj_t aux_1237;
						      aux_1237 = CDR(proto_475);
						      aux_1236 = CAR(aux_1237);
						   }
						   arg1375_518 = get_class_hash_100_module_class(aux_1236, clause_472);
						}
						{
						   long aux_1241;
						   aux_1241 = (long) CINT(arg1375_518);
						   arg1372_516 = (((long) 12543) ^ aux_1241);
						}
					     }
					     {
						long aux_1244;
						{
						   long aux_1245;
						   aux_1245 = (long) CINT(checksum_473);
						   aux_1244 = (aux_1245 ^ arg1372_516);
						}
						arg1322_470 = BINT(aux_1244);
					     }
					  }
					else
					  {
					     bool_t test_1249;
					     {
						obj_t aux_1250;
						aux_1250 = CNST_TABLE_REF(((long) 7));
						test_1249 = (case_value_58_478 == aux_1250);
					     }
					     if (test_1249)
					       {
						  long arg1381_521;
						  {
						     obj_t arg1384_523;
						     {
							obj_t aux_1253;
							{
							   obj_t aux_1254;
							   aux_1254 = CDR(proto_475);
							   aux_1253 = CAR(aux_1254);
							}
							arg1384_523 = get_class_hash_100_module_class(aux_1253, clause_472);
						     }
						     {
							long aux_1258;
							aux_1258 = (long) CINT(arg1384_523);
							arg1381_521 = (((long) 456747) ^ aux_1258);
						     }
						  }
						  {
						     long aux_1261;
						     {
							long aux_1262;
							aux_1262 = (long) CINT(checksum_473);
							aux_1261 = (aux_1262 ^ arg1381_521);
						     }
						     arg1322_470 = BINT(aux_1261);
						  }
					       }
					     else
					       {
						  obj_t list1390_528;
						  list1390_528 = MAKE_PAIR(BNIL, BNIL);
						  arg1322_470 = user_error_151_tools_error(string1455_module_statexp, string1457_module_statexp, clause_472, list1390_528);
					       }
					  }
				     }
				}
			   }
		      }
		   }
		 else
		   {
		      obj_t list1402_538;
		      list1402_538 = MAKE_PAIR(BNIL, BNIL);
		      arg1322_470 = user_error_151_tools_error(string1455_module_statexp, string1457_module_statexp, eclause_25, list1402_538);
		   }
	      }
	      {
		 obj_t checksum_1272;
		 obj_t clauses_1271;
		 clauses_1271 = arg1321_469;
		 checksum_1272 = arg1322_470;
		 checksum_465 = checksum_1272;
		 clauses_464 = clauses_1271;
		 goto loop_466;
	      }
	   }
      }
   }
}


/* _export-checksummer */ obj_t 
_export_checksummer_163_module_statexp(obj_t env_918, obj_t eclause_919, obj_t checksum_920)
{
   return export_checksummer_174_module_statexp(eclause_919, checksum_920);
}


/* method-init */ obj_t 
method_init_76_module_statexp()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_statexp()
{
   module_initialization_70_module_module(((long) 0), "MODULE_STATEXP");
   module_initialization_70_module_prototype(((long) 0), "MODULE_STATEXP");
   module_initialization_70_module_class(((long) 0), "MODULE_STATEXP");
   module_initialization_70_module_checksum(((long) 0), "MODULE_STATEXP");
   module_initialization_70_tools_error(((long) 0), "MODULE_STATEXP");
   module_initialization_70_tools_args(((long) 0), "MODULE_STATEXP");
   module_initialization_70_type_type(((long) 0), "MODULE_STATEXP");
   module_initialization_70_ast_var(((long) 0), "MODULE_STATEXP");
   module_initialization_70_ast_ident(((long) 0), "MODULE_STATEXP");
   module_initialization_70_ast_find_gdefs_13(((long) 0), "MODULE_STATEXP");
   return module_initialization_70_ast_glo_decl_237(((long) 0), "MODULE_STATEXP");
}
