/*===========================================================================*/
/*   (Tools/error.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t method_init_76_tools_error();
extern obj_t user_warning_location_190_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t current_error_port;
extern obj_t exitd_top;
obj_t _nb_error_on_pass__70_tools_error = BUNSPEC;
static obj_t _enter_function1687_100_tools_error(obj_t, obj_t);
extern obj_t leave_function_170_tools_error();
extern obj_t user_warning_209_tools_error(obj_t, obj_t, obj_t);
static obj_t _current_function_148_tools_error(obj_t);
extern obj_t warning___error(obj_t);
static obj_t handling_function1559_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1545_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t current_function_76_tools_error();
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t _user_warning_49_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_tools_error();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t rhandler1446_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1438_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t handler_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t bigloo_strcmp(obj_t, obj_t);
static obj_t _user_error_251_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_tools_error();
static obj_t toplevel_init_63_tools_error();
static obj_t _internal_error_86_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t warning_location_135___error(obj_t, obj_t, obj_t);
static obj_t _user_warning_location_217_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _bigloo_author__68_engine_param;
extern obj_t _trace_port__84_tools_trace;
extern obj_t close_output_port(obj_t);
extern obj_t enter_function_81_tools_error(obj_t);
static obj_t arg1561_tools_error(obj_t);
static obj_t arg1560_tools_error(obj_t);
static obj_t arg1549_tools_error(obj_t);
static obj_t arg1548_tools_error(obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t _user_error_location_187_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t c_substring(obj_t, long, long);
extern obj_t open_output_string();
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t remove_error_handler__102___error();
extern obj_t read___reader(obj_t);
static obj_t _sfun_stack__205_tools_error = BUNSPEC;
extern obj_t find_location_120_tools_location(obj_t);
static obj_t _leave_function_100_tools_error(obj_t);
static obj_t escape_tools_error(obj_t, obj_t);
extern obj_t _bigloo_email__0_engine_param;
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t escape_1686_tools_error(obj_t, obj_t);
static obj_t require_initialization_114_tools_error = BUNSPEC;
static obj_t body1447_tools_error(obj_t);
static obj_t body1439_tools_error(obj_t);
static obj_t cnst_init_137_tools_error();
extern obj_t user_error_location_137_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(internal_error_env_37_tools_error, _internal_error_86_tools_error1703, _internal_error_86_tools_error, 0L, 3);
DEFINE_EXPORT_PROCEDURE(user_warning_location_env_188_tools_error, _user_warning_location_217_tools_error1704, _user_warning_location_217_tools_error, 0L, 4);
DEFINE_EXPORT_PROCEDURE(leave_function_env_89_tools_error, _leave_function_100_tools_error1705, _leave_function_100_tools_error, 0L, 0);
DEFINE_EXPORT_PROCEDURE(user_warning_env_78_tools_error, _user_warning_49_tools_error1706, _user_warning_49_tools_error, 0L, 3);
DEFINE_EXPORT_PROCEDURE(user_error_env_101_tools_error, _user_error_251_tools_error1707, va_generic_entry, _user_error_251_tools_error, -4);
DEFINE_EXPORT_PROCEDURE(user_error_location_env_77_tools_error, _user_error_location_187_tools_error1708, va_generic_entry, _user_error_location_187_tools_error, -5);
DEFINE_EXPORT_PROCEDURE(current_function_env_22_tools_error, _current_function_148_tools_error1709, _current_function_148_tools_error, 0L, 0);
DEFINE_STRING(string1697_tools_error, string1697_tools_error1710, "LOCATION (TOP-LEVEL) ", 21);
DEFINE_STRING(string1696_tools_error, string1696_tools_error1711, " ...", 4);
DEFINE_STRING(string1695_tools_error, string1695_tools_error1712, "*** ERROR:", 10);
DEFINE_STRING(string1694_tools_error, string1694_tools_error1713, " -- ", 4);
DEFINE_STRING(string1693_tools_error, string1693_tools_error1714, "(Would you, please, send this error report and the source file to", 65);
DEFINE_STRING(string1692_tools_error, string1692_tools_error1715, " [", 2);
DEFINE_STRING(string1691_tools_error, string1691_tools_error1716, "], thank you.)", 14);
DEFINE_STRING(string1689_tools_error, string1689_tools_error1717, "*** ERROR: ", 11);
DEFINE_STRING(string1690_tools_error, string1690_tools_error1718, "*** INTERNAL-ERROR in pass: ", 28);
DEFINE_STRING(string1688_tools_error, string1688_tools_error1719, ":", 1);
DEFINE_EXPORT_PROCEDURE(enter_function_env_226_tools_error, _enter_function1687_100_tools_error1720, _enter_function1687_100_tools_error, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_tools_error(long checksum_1425, char *from_1426)
{
   if (CBOOL(require_initialization_114_tools_error))
     {
	require_initialization_114_tools_error = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_error();
	cnst_init_137_tools_error();
	imported_modules_init_94_tools_error();
	method_init_76_tools_error();
	toplevel_init_63_tools_error();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_error()
{
   module_initialization_70___bexit(((long) 0), "TOOLS_ERROR");
   module_initialization_70___r4_output_6_10_3(((long) 0), "TOOLS_ERROR");
   module_initialization_70___error(((long) 0), "TOOLS_ERROR");
   module_initialization_70___r4_strings_6_7(((long) 0), "TOOLS_ERROR");
   module_initialization_70___r4_control_features_6_9(((long) 0), "TOOLS_ERROR");
   module_initialization_70___reader(((long) 0), "TOOLS_ERROR");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_tools_error()
{
   {
      obj_t cnst_port_138_1417;
      cnst_port_138_1417 = open_input_string(string1697_tools_error);
      {
	 long i_1418;
	 i_1418 = ((long) 1);
       loop_1419:
	 {
	    bool_t test1698_1420;
	    test1698_1420 = (i_1418 == ((long) -1));
	    if (test1698_1420)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1699_1421;
		    {
		       obj_t list1700_1422;
		       {
			  obj_t arg1701_1423;
			  arg1701_1423 = BNIL;
			  list1700_1422 = MAKE_PAIR(cnst_port_138_1417, arg1701_1423);
		       }
		       arg1699_1421 = read___reader(list1700_1422);
		    }
		    CNST_TABLE_SET(i_1418, arg1699_1421);
		 }
		 {
		    int aux_1424;
		    {
		       long aux_1447;
		       aux_1447 = (i_1418 - ((long) 1));
		       aux_1424 = (int) (aux_1447);
		    }
		    {
		       long i_1450;
		       i_1450 = (long) (aux_1424);
		       i_1418 = i_1450;
		       goto loop_1419;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_tools_error()
{
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   return (_sfun_stack__205_tools_error = CNST_TABLE_REF(((long) 0)),
      BUNSPEC);
}


/* internal-error */ obj_t 
internal_error_43_tools_error(obj_t proc_15, obj_t mes_16, obj_t obj_17)
{
   {
      bool_t test1472_743;
      {
	 obj_t obj_1237;
	 obj_1237 = _trace_port__84_tools_trace;
	 test1472_743 = OUTPUT_PORTP(obj_1237);
      }
      if (test1472_743)
	{
	   obj_t list1473_744;
	   {
	      obj_t arg1475_746;
	      {
		 obj_t arg1476_747;
		 {
		    obj_t arg1478_749;
		    {
		       obj_t arg1479_750;
		       {
			  obj_t arg1481_752;
			  arg1481_752 = MAKE_PAIR(obj_17, BNIL);
			  arg1479_750 = MAKE_PAIR(string1688_tools_error, arg1481_752);
		       }
		       arg1478_749 = MAKE_PAIR(mes_16, arg1479_750);
		    }
		    arg1476_747 = MAKE_PAIR(string1688_tools_error, arg1478_749);
		 }
		 arg1475_746 = MAKE_PAIR(proc_15, arg1476_747);
	      }
	      list1473_744 = MAKE_PAIR(string1689_tools_error, arg1475_746);
	   }
	   fprint___r4_output_6_10_3(_trace_port__84_tools_trace, list1473_744);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t list1486_756;
      {
	 obj_t arg1487_757;
	 arg1487_757 = MAKE_PAIR(_current_pass__25_engine_pass, BNIL);
	 list1486_756 = MAKE_PAIR(string1690_tools_error, arg1487_757);
      }
      fprint___r4_output_6_10_3(current_error_port, list1486_756);
   }
   {
      obj_t list1495_763;
      {
	 obj_t arg1496_764;
	 {
	    obj_t arg1497_765;
	    {
	       obj_t arg1498_766;
	       {
		  obj_t arg1499_767;
		  {
		     obj_t arg1500_768;
		     arg1500_768 = MAKE_PAIR(string1691_tools_error, BNIL);
		     arg1499_767 = MAKE_PAIR(_bigloo_email__0_engine_param, arg1500_768);
		  }
		  arg1498_766 = MAKE_PAIR(string1692_tools_error, arg1499_767);
	       }
	       arg1497_765 = MAKE_PAIR(_bigloo_author__68_engine_param, arg1498_766);
	    }
	    {
	       obj_t aux_1470;
	       aux_1470 = BCHAR(((unsigned char) '\n'));
	       arg1496_764 = MAKE_PAIR(aux_1470, arg1497_765);
	    }
	 }
	 list1495_763 = MAKE_PAIR(string1693_tools_error, arg1496_764);
      }
      fprint___r4_output_6_10_3(current_error_port, list1495_763);
   }
   FAILURE(proc_15, mes_16, obj_17);
}


/* _internal-error */ obj_t 
_internal_error_86_tools_error(obj_t env_1310, obj_t proc_1311, obj_t mes_1312, obj_t obj_1313)
{
   return internal_error_43_tools_error(proc_1311, mes_1312, obj_1313);
}


/* user-warning/location */ obj_t 
user_warning_location_190_tools_error(obj_t loc_18, obj_t proc_19, obj_t mes_20, obj_t obj_21)
{
   {
      bool_t test_1479;
      if (STRUCTP(loc_18))
	{
	   obj_t aux_1484;
	   obj_t aux_1482;
	   aux_1484 = CNST_TABLE_REF(((long) 1));
	   aux_1482 = STRUCT_KEY(loc_18);
	   test_1479 = (aux_1482 == aux_1484);
	}
      else
	{
	   test_1479 = ((bool_t) 0);
	}
      if (test_1479)
	{
	   obj_t arg1503_771;
	   obj_t arg1504_772;
	   arg1503_771 = STRUCT_REF(loc_18, ((long) 0));
	   arg1504_772 = STRUCT_REF(loc_18, ((long) 1));
	   {
	      obj_t list1506_774;
	      {
		 obj_t arg1507_775;
		 {
		    obj_t arg1510_776;
		    {
		       obj_t arg1511_777;
		       arg1511_777 = MAKE_PAIR(obj_21, BNIL);
		       arg1510_776 = MAKE_PAIR(string1694_tools_error, arg1511_777);
		    }
		    arg1507_775 = MAKE_PAIR(mes_20, arg1510_776);
		 }
		 list1506_774 = MAKE_PAIR(proc_19, arg1507_775);
	      }
	      return warning_location_135___error(arg1503_771, arg1504_772, list1506_774);
	   }
	}
      else
	{
	   obj_t list1514_779;
	   {
	      obj_t arg1515_780;
	      {
		 obj_t arg1516_781;
		 {
		    obj_t arg1518_783;
		    arg1518_783 = MAKE_PAIR(obj_21, BNIL);
		    arg1516_781 = MAKE_PAIR(string1694_tools_error, arg1518_783);
		 }
		 arg1515_780 = MAKE_PAIR(mes_20, arg1516_781);
	      }
	      list1514_779 = MAKE_PAIR(proc_19, arg1515_780);
	   }
	   return warning___error(list1514_779);
	}
   }
}


/* _user-warning/location */ obj_t 
_user_warning_location_217_tools_error(obj_t env_1314, obj_t loc_1315, obj_t proc_1316, obj_t mes_1317, obj_t obj_1318)
{
   return user_warning_location_190_tools_error(loc_1315, proc_1316, mes_1317, obj_1318);
}


/* user-warning */ obj_t 
user_warning_209_tools_error(obj_t proc_22, obj_t mes_23, obj_t obj_24)
{
   {
      obj_t arg1522_1255;
      arg1522_1255 = find_location_120_tools_location(obj_24);
      return user_warning_location_190_tools_error(arg1522_1255, proc_22, mes_23, obj_24);
   }
}


/* _user-warning */ obj_t 
_user_warning_49_tools_error(obj_t env_1319, obj_t proc_1320, obj_t mes_1321, obj_t obj_1322)
{
   return user_warning_209_tools_error(proc_1320, mes_1321, obj_1322);
}


/* user-error */ obj_t 
user_error_151_tools_error(obj_t proc_25, obj_t mes_26, obj_t obj_27, obj_t continue_28)
{
   if (PAIRP(continue_28))
     {
	obj_t arg1524_787;
	obj_t arg1525_788;
	arg1524_787 = find_location_120_tools_location(obj_27);
	arg1525_788 = CAR(continue_28);
	{
	   obj_t list1526_789;
	   list1526_789 = MAKE_PAIR(arg1525_788, BNIL);
	   return user_error_location_137_tools_error(arg1524_787, proc_25, mes_26, obj_27, list1526_789);
	}
     }
   else
     {
	obj_t arg1528_791;
	arg1528_791 = find_location_120_tools_location(obj_27);
	return user_error_location_137_tools_error(arg1528_791, proc_25, mes_26, obj_27, BNIL);
     }
}


/* _user-error */ obj_t 
_user_error_251_tools_error(obj_t env_1323, obj_t proc_1324, obj_t mes_1325, obj_t obj_1326, obj_t continue_1327)
{
   return user_error_151_tools_error(proc_1324, mes_1325, obj_1326, continue_1327);
}


/* user-error/location */ obj_t 
user_error_location_137_tools_error(obj_t loc_29, obj_t proc_30, obj_t mes_31, obj_t obj_32, obj_t continue_33)
{
   {
      bool_t test1530_793;
      {
	 obj_t obj_1258;
	 obj_1258 = _trace_port__84_tools_trace;
	 test1530_793 = OUTPUT_PORTP(obj_1258);
      }
      if (test1530_793)
	{
	   obj_t list1531_794;
	   {
	      obj_t arg1533_796;
	      {
		 obj_t arg1534_797;
		 {
		    obj_t arg1536_799;
		    {
		       obj_t arg1537_800;
		       {
			  obj_t arg1540_802;
			  arg1540_802 = MAKE_PAIR(obj_32, BNIL);
			  arg1537_800 = MAKE_PAIR(string1688_tools_error, arg1540_802);
		       }
		       arg1536_799 = MAKE_PAIR(mes_31, arg1537_800);
		    }
		    arg1534_797 = MAKE_PAIR(string1688_tools_error, arg1536_799);
		 }
		 arg1533_796 = MAKE_PAIR(proc_30, arg1534_797);
	      }
	      list1531_794 = MAKE_PAIR(string1695_tools_error, arg1533_796);
	   }
	   fprint___r4_output_6_10_3(_trace_port__84_tools_trace, list1531_794);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      long z1_1259;
      z1_1259 = (long) CINT(_nb_error_on_pass__70_tools_error);
      {
	 long aux_1522;
	 aux_1522 = (z1_1259 + ((long) 1));
	 _nb_error_on_pass__70_tools_error = BINT(aux_1522);
      }
   }
   {
      obj_t proc_string_5_804;
      if (STRINGP(proc_30))
	{
	   proc_string_5_804 = proc_30;
	}
      else
	{
	   if (SYMBOLP(proc_30))
	     {
		proc_string_5_804 = SYMBOL_TO_STRING(proc_30);
	     }
	   else
	     {
		proc_string_5_804 = BFALSE;
	     }
	}
      {
	 obj_t fun_string_157_805;
	 {
	    obj_t arg1587_888;
	    {
	       obj_t pair_1264;
	       pair_1264 = _sfun_stack__205_tools_error;
	       arg1587_888 = CAR(pair_1264);
	    }
	    fun_string_157_805 = SYMBOL_TO_STRING(arg1587_888);
	 }
	 {
	    obj_t proc_806;
	    {
	       bool_t test1579_880;
	       if (STRINGP(proc_string_5_804))
		 {
		    bool_t test1586_887;
		    test1586_887 = bigloo_strcmp(proc_string_5_804, fun_string_157_805);
		    if (test1586_887)
		      {
			 test1579_880 = ((bool_t) 0);
		      }
		    else
		      {
			 test1579_880 = ((bool_t) 1);
		      }
		 }
	       else
		 {
		    test1579_880 = ((bool_t) 0);
		 }
	       if (test1579_880)
		 {
		    obj_t list1580_881;
		    {
		       obj_t arg1581_882;
		       {
			  obj_t arg1583_884;
			  arg1583_884 = MAKE_PAIR(proc_string_5_804, BNIL);
			  arg1581_882 = MAKE_PAIR(string1688_tools_error, arg1583_884);
		       }
		       list1580_881 = MAKE_PAIR(fun_string_157_805, arg1581_882);
		    }
		    proc_806 = string_append_106___r4_strings_6_7(list1580_881);
		 }
	       else
		 {
		    proc_806 = fun_string_157_805;
		 }
	    }
	    {
	       {
		  obj_t obj_prn_210_807;
		  {
		     obj_t port_864;
		     port_864 = open_output_string();
		     {
			obj_t list1566_865;
			list1566_865 = MAKE_PAIR(port_864, BNIL);
			display___r4_output_6_10_3(obj_32, list1566_865);
		     }
		     {
			obj_t string_867;
			string_867 = close_output_port(port_864);
			{
			   bool_t test_1545;
			   {
			      long aux_1546;
			      aux_1546 = STRING_LENGTH(string_867);
			      test_1545 = (aux_1546 > ((long) 45));
			   }
			   if (test_1545)
			     {
				obj_t arg1570_869;
				arg1570_869 = c_substring(string_867, ((long) 0), ((long) 44));
				obj_prn_210_807 = string_append(arg1570_869, string1696_tools_error);
			     }
			   else
			     {
				obj_prn_210_807 = string_867;
			     }
			}
		     }
		  }
		  {
		     obj_t handler_1338;
		     handler_1338 = make_fx_procedure(handler_tools_error, ((long) 4), ((long) 1));
		     PROCEDURE_SET(handler_1338, ((long) 0), continue_33);
		     {
			bool_t test_1553;
			if (STRUCTP(loc_29))
			  {
			     obj_t aux_1558;
			     obj_t aux_1556;
			     aux_1558 = CNST_TABLE_REF(((long) 1));
			     aux_1556 = STRUCT_KEY(loc_29);
			     test_1553 = (aux_1556 == aux_1558);
			  }
			else
			  {
			     test_1553 = ((bool_t) 0);
			  }
			if (test_1553)
			  {
			     if (PAIRP(continue_33))
			       {
				  obj_t armed1440_811;
				  obj_t handler1437_812;
				  armed1440_811 = MAKE_CELL(BUNSPEC);
				  handler1437_812 = MAKE_CELL(BUNSPEC);
				  {
				     obj_t body1439_1329;
				     obj_t rhandler1438_1331;
				     body1439_1329 = make_fx_procedure(body1439_tools_error, ((long) 0), ((long) 4));
				     rhandler1438_1331 = make_fx_procedure(rhandler1438_tools_error, ((long) 4), ((long) 2));
				     PROCEDURE_SET(body1439_1329, ((long) 0), loc_29);
				     PROCEDURE_SET(body1439_1329, ((long) 1), proc_806);
				     PROCEDURE_SET(body1439_1329, ((long) 2), mes_31);
				     PROCEDURE_SET(body1439_1329, ((long) 3), obj_prn_210_807);
				     PROCEDURE_SET(rhandler1438_1331, ((long) 0), armed1440_811);
				     PROCEDURE_SET(rhandler1438_1331, ((long) 1), handler1437_812);
				     CELL_SET(handler1437_812, handler_1338);
				     CELL_SET(armed1440_811, BTRUE);
				     return handling_function1545_tools_error(body1439_1329, rhandler1438_1331, handler1437_812, armed1440_811);
				  }
			       }
			     else
			       {
				  return error_location_112___error(proc_806, mes_31, obj_prn_210_807, STRUCT_REF(loc_29, ((long) 0)), STRUCT_REF(loc_29, ((long) 1)));
			       }
			  }
			else
			  {
			     if (PAIRP(continue_33))
			       {
				  obj_t armed1448_840;
				  obj_t handler1445_841;
				  armed1448_840 = MAKE_CELL(BUNSPEC);
				  handler1445_841 = MAKE_CELL(BUNSPEC);
				  {
				     obj_t body1447_1334;
				     obj_t rhandler1446_1336;
				     body1447_1334 = make_fx_procedure(body1447_tools_error, ((long) 0), ((long) 3));
				     rhandler1446_1336 = make_fx_procedure(rhandler1446_tools_error, ((long) 4), ((long) 2));
				     PROCEDURE_SET(body1447_1334, ((long) 0), proc_806);
				     PROCEDURE_SET(body1447_1334, ((long) 1), mes_31);
				     PROCEDURE_SET(body1447_1334, ((long) 2), obj_32);
				     PROCEDURE_SET(rhandler1446_1336, ((long) 0), armed1448_840);
				     PROCEDURE_SET(rhandler1446_1336, ((long) 1), handler1445_841);
				     CELL_SET(handler1445_841, handler_1338);
				     CELL_SET(armed1448_840, BTRUE);
				     return handling_function1559_tools_error(body1447_1334, rhandler1446_1336, handler1445_841, armed1448_840);
				  }
			       }
			     else
			       {
				  FAILURE(proc_806, mes_31, obj_32);
			       }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* handling_function1559 */ obj_t 
handling_function1559_tools_error(obj_t body1447_1411, obj_t rhandler1446_1410, obj_t handler1445_1409, obj_t armed1448_1408)
{
   jmp_buf jmpbuf;
   obj_t an_exit1449_845;
   if (SET_EXIT(an_exit1449_845))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1449_845 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1449_845, ((bool_t) 1));
	   {
	      obj_t an_exitd1450_846;
	      an_exitd1450_846 = exitd_top;
	      {
		 obj_t escape_1335;
		 escape_1335 = make_fx_procedure(escape_1686_tools_error, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_1335, ((long) 0), an_exitd1450_846);
		 {
		    obj_t res1452_849;
		    {
		       obj_t arg1561_1333;
		       obj_t arg1560_1337;
		       arg1561_1333 = make_fx_procedure(arg1561_tools_error, ((long) 0), ((long) 1));
		       arg1560_1337 = make_fx_procedure(arg1560_tools_error, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1561_1333, ((long) 0), armed1448_1408);
		       PROCEDURE_SET(arg1560_1337, ((long) 0), an_exitd1450_846);
		       PROCEDURE_SET(arg1560_1337, ((long) 1), armed1448_1408);
		       PROCEDURE_SET(arg1560_1337, ((long) 2), handler1445_1409);
		       PROCEDURE_SET(arg1560_1337, ((long) 3), rhandler1446_1410);
		       PROCEDURE_SET(arg1560_1337, ((long) 4), escape_1335);
		       res1452_849 = dynamic_wind_31___r4_control_features_6_9(arg1560_1337, body1447_1411, arg1561_1333);
		    }
		    POP_EXIT();
		    return res1452_849;
		 }
	      }
	   }
	}
     }
}


/* handling_function1545 */ obj_t 
handling_function1545_tools_error(obj_t body1439_1415, obj_t rhandler1438_1414, obj_t handler1437_1413, obj_t armed1440_1412)
{
   jmp_buf jmpbuf;
   obj_t an_exit1441_816;
   if (SET_EXIT(an_exit1441_816))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1441_816 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1441_816, ((bool_t) 1));
	   {
	      obj_t an_exitd1442_817;
	      an_exitd1442_817 = exitd_top;
	      {
		 obj_t escape_1330;
		 escape_1330 = make_fx_procedure(escape_tools_error, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_1330, ((long) 0), an_exitd1442_817);
		 {
		    obj_t res1444_820;
		    {
		       obj_t arg1549_1328;
		       obj_t arg1548_1332;
		       arg1549_1328 = make_fx_procedure(arg1549_tools_error, ((long) 0), ((long) 1));
		       arg1548_1332 = make_fx_procedure(arg1548_tools_error, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1549_1328, ((long) 0), armed1440_1412);
		       PROCEDURE_SET(arg1548_1332, ((long) 0), an_exitd1442_817);
		       PROCEDURE_SET(arg1548_1332, ((long) 1), armed1440_1412);
		       PROCEDURE_SET(arg1548_1332, ((long) 2), handler1437_1413);
		       PROCEDURE_SET(arg1548_1332, ((long) 3), rhandler1438_1414);
		       PROCEDURE_SET(arg1548_1332, ((long) 4), escape_1330);
		       res1444_820 = dynamic_wind_31___r4_control_features_6_9(arg1548_1332, body1439_1415, arg1549_1328);
		    }
		    POP_EXIT();
		    return res1444_820;
		 }
	      }
	   }
	}
     }
}


/* _user-error/location */ obj_t 
_user_error_location_187_tools_error(obj_t env_1339, obj_t loc_1340, obj_t proc_1341, obj_t mes_1342, obj_t obj_1343, obj_t continue_1344)
{
   return user_error_location_137_tools_error(loc_1340, proc_1341, mes_1342, obj_1343, continue_1344);
}


/* arg1549 */ obj_t 
arg1549_tools_error(obj_t env_1345)
{
   {
      obj_t armed1440_1346;
      armed1440_1346 = PROCEDURE_REF(env_1345, ((long) 0));
      {
	 {
	    bool_t test_1618;
	    {
	       obj_t aux_1619;
	       aux_1619 = CELL_REF(armed1440_1346);
	       test_1618 = CBOOL(aux_1619);
	    }
	    if (test_1618)
	      {
		 CELL_SET(armed1440_1346, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1439 */ obj_t 
body1439_tools_error(obj_t env_1348)
{
   {
      obj_t loc_1349;
      obj_t proc_1350;
      obj_t mes_1351;
      obj_t obj_prn_210_1352;
      loc_1349 = PROCEDURE_REF(env_1348, ((long) 0));
      proc_1350 = PROCEDURE_REF(env_1348, ((long) 1));
      mes_1351 = PROCEDURE_REF(env_1348, ((long) 2));
      obj_prn_210_1352 = PROCEDURE_REF(env_1348, ((long) 3));
      {
	 return error_location_112___error(proc_1350, mes_1351, obj_prn_210_1352, STRUCT_REF(loc_1349, ((long) 0)), STRUCT_REF(loc_1349, ((long) 1)));
      }
   }
}


/* arg1548 */ obj_t 
arg1548_tools_error(obj_t env_1353)
{
   {
      obj_t rhandler1438_1357;
      obj_t escape_1358;
      rhandler1438_1357 = PROCEDURE_REF(env_1353, ((long) 3));
      escape_1358 = PROCEDURE_REF(env_1353, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1438_1357, escape_1358);
      }
   }
}


/* escape */ obj_t 
escape_tools_error(obj_t env_1359, obj_t val1443_1361)
{
   {
      obj_t an_exitd1442_1360;
      an_exitd1442_1360 = PROCEDURE_REF(env_1359, ((long) 0));
      {
	 obj_t val1443_818;
	 val1443_818 = val1443_1361;
	 return unwind_until__178___bexit(an_exitd1442_1360, val1443_818);
      }
   }
}


/* rhandler1438 */ obj_t 
rhandler1438_tools_error(obj_t env_1362, obj_t esc_1365, obj_t obj_1366, obj_t proc_1367, obj_t msg_1368)
{
   {
      obj_t armed1440_1363;
      obj_t handler1437_1364;
      armed1440_1363 = PROCEDURE_REF(env_1362, ((long) 0));
      handler1437_1364 = PROCEDURE_REF(env_1362, ((long) 1));
      {
	 obj_t esc_827;
	 obj_t obj_828;
	 obj_t proc_829;
	 obj_t msg_830;
	 esc_827 = esc_1365;
	 obj_828 = obj_1366;
	 proc_829 = proc_1367;
	 msg_830 = msg_1368;
	 CELL_SET(armed1440_1363, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_1638;
	    aux_1638 = CELL_REF(handler1437_1364);
	    return PROCEDURE_ENTRY(aux_1638) (CELL_REF(handler1437_1364), esc_827, obj_828, proc_829, msg_830, BEOA);
	 }
      }
   }
}


/* arg1561 */ obj_t 
arg1561_tools_error(obj_t env_1370)
{
   {
      obj_t armed1448_1371;
      armed1448_1371 = PROCEDURE_REF(env_1370, ((long) 0));
      {
	 {
	    bool_t test_1640;
	    {
	       obj_t aux_1641;
	       aux_1641 = CELL_REF(armed1448_1371);
	       test_1640 = CBOOL(aux_1641);
	    }
	    if (test_1640)
	      {
		 CELL_SET(armed1448_1371, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1447 */ obj_t 
body1447_tools_error(obj_t env_1373)
{
   {
      obj_t proc_1374;
      obj_t mes_1375;
      obj_t obj_1376;
      proc_1374 = PROCEDURE_REF(env_1373, ((long) 0));
      mes_1375 = PROCEDURE_REF(env_1373, ((long) 1));
      obj_1376 = PROCEDURE_REF(env_1373, ((long) 2));
      {
	 FAILURE(proc_1374, mes_1375, obj_1376);
      }
   }
}


/* arg1560 */ obj_t 
arg1560_tools_error(obj_t env_1377)
{
   {
      obj_t rhandler1446_1381;
      obj_t escape_1382;
      rhandler1446_1381 = PROCEDURE_REF(env_1377, ((long) 3));
      escape_1382 = PROCEDURE_REF(env_1377, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1446_1381, escape_1382);
      }
   }
}


/* escape_1686 */ obj_t 
escape_1686_tools_error(obj_t env_1383, obj_t val1451_1385)
{
   {
      obj_t an_exitd1450_1384;
      an_exitd1450_1384 = PROCEDURE_REF(env_1383, ((long) 0));
      {
	 obj_t val1451_847;
	 val1451_847 = val1451_1385;
	 return unwind_until__178___bexit(an_exitd1450_1384, val1451_847);
      }
   }
}


/* rhandler1446 */ obj_t 
rhandler1446_tools_error(obj_t env_1386, obj_t esc_1389, obj_t obj_1390, obj_t proc_1391, obj_t msg_1392)
{
   {
      obj_t armed1448_1387;
      obj_t handler1445_1388;
      armed1448_1387 = PROCEDURE_REF(env_1386, ((long) 0));
      handler1445_1388 = PROCEDURE_REF(env_1386, ((long) 1));
      {
	 obj_t esc_856;
	 obj_t obj_857;
	 obj_t proc_858;
	 obj_t msg_859;
	 esc_856 = esc_1389;
	 obj_857 = obj_1390;
	 proc_858 = proc_1391;
	 msg_859 = msg_1392;
	 CELL_SET(armed1448_1387, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_1657;
	    aux_1657 = CELL_REF(handler1445_1388);
	    return PROCEDURE_ENTRY(aux_1657) (CELL_REF(handler1445_1388), esc_856, obj_857, proc_858, msg_859, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_tools_error(obj_t env_1394, obj_t escape_1396, obj_t proc_1397, obj_t mes_1398, obj_t obj_1399)
{
   {
      obj_t continue_1395;
      continue_1395 = PROCEDURE_REF(env_1394, ((long) 0));
      {
	 obj_t escape_873;
	 obj_t proc_874;
	 obj_t mes_875;
	 obj_t obj_876;
	 escape_873 = escape_1396;
	 proc_874 = proc_1397;
	 mes_875 = mes_1398;
	 obj_876 = obj_1399;
	 notify_error_43___error(proc_874, mes_875, obj_876);
	 return PROCEDURE_ENTRY(escape_873) (escape_873, CAR(continue_1395), BEOA);
      }
   }
}


/* enter-function */ obj_t 
enter_function_81_tools_error(obj_t var_34)
{
   {
      obj_t obj2_1307;
      obj2_1307 = _sfun_stack__205_tools_error;
      return (_sfun_stack__205_tools_error = MAKE_PAIR(var_34, obj2_1307),
	 BUNSPEC);
   }
}


/* _enter-function1687 */ obj_t 
_enter_function1687_100_tools_error(obj_t env_1404, obj_t var_1405)
{
   return enter_function_81_tools_error(var_1405);
}


/* leave-function */ obj_t 
leave_function_170_tools_error()
{
   {
      obj_t pair_1308;
      pair_1308 = _sfun_stack__205_tools_error;
      return (_sfun_stack__205_tools_error = CDR(pair_1308),
	 BUNSPEC);
   }
}


/* _leave-function */ obj_t 
_leave_function_100_tools_error(obj_t env_1406)
{
   return leave_function_170_tools_error();
}


/* current-function */ obj_t 
current_function_76_tools_error()
{
   {
      obj_t pair_1309;
      pair_1309 = _sfun_stack__205_tools_error;
      return CAR(pair_1309);
   }
}


/* _current-function */ obj_t 
_current_function_148_tools_error(obj_t env_1407)
{
   return current_function_76_tools_error();
}


/* method-init */ obj_t 
method_init_76_tools_error()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_error()
{
   module_initialization_70_type_type(((long) 0), "TOOLS_ERROR");
   module_initialization_70_ast_var(((long) 0), "TOOLS_ERROR");
   module_initialization_70_ast_node(((long) 0), "TOOLS_ERROR");
   module_initialization_70_engine_pass(((long) 0), "TOOLS_ERROR");
   module_initialization_70_engine_param(((long) 0), "TOOLS_ERROR");
   module_initialization_70_tools_location(((long) 0), "TOOLS_ERROR");
   module_initialization_70_tools_trace(((long) 0), "TOOLS_ERROR");
   return module_initialization_70_init_main(((long) 0), "TOOLS_ERROR");
}
