/*===========================================================================*/
/*   (Ieee/number.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _2__171___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2__242___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern char * number__string_214___r4_numbers_6_5(obj_t, obj_t);
static obj_t _2__101___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _exp___r4_numbers_6_5(obj_t, obj_t);
extern obj_t exact__inexact_122___r4_numbers_6_5(obj_t);
static obj_t _inexact__exact_215___r4_numbers_6_5(obj_t, obj_t);
static obj_t _floor___r4_numbers_6_5(obj_t, obj_t);
extern obj_t abs___r4_numbers_6_5(obj_t);
static obj_t _ceiling___r4_numbers_6_5(obj_t, obj_t);
extern obj_t make_real(double);
static obj_t _negative__187___r4_numbers_6_5(obj_t, obj_t);
static obj_t _cos___r4_numbers_6_5(obj_t, obj_t);
static obj_t _string__number_250___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern obj_t floor___r4_numbers_6_5(obj_t);
extern long flonum__fixnum_11___r4_numbers_6_5(obj_t);
static obj_t _inexact__53___r4_numbers_6_5(obj_t, obj_t);
extern double atan___r4_numbers_6_5(obj_t, obj_t);
extern double asin___r4_numbers_6_5(obj_t);
static obj_t _expt___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _rational__24___r4_numbers_6_5(obj_t, obj_t);
static obj_t _complex__176___r4_numbers_6_5(obj_t, obj_t);
static obj_t _number__137___r4_numbers_6_5(obj_t, obj_t);
static obj_t _abs___r4_numbers_6_5(obj_t, obj_t);
extern bool_t inexact__139___r4_numbers_6_5(obj_t);
extern double tan___r4_numbers_6_5(obj_t);
static obj_t _round___r4_numbers_6_5(obj_t, obj_t);
extern double sin___r4_numbers_6_5(obj_t);
extern char * integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t ceiling___r4_numbers_6_5(obj_t);
extern obj_t string_to_bstring(char *);
extern bool_t complex__118___r4_numbers_6_5(obj_t);
static obj_t _zero__222___r4_numbers_6_5(obj_t, obj_t);
extern bool_t negative__33___r4_numbers_6_5(obj_t);
static obj_t _positive__177___r4_numbers_6_5(obj_t, obj_t);
extern obj_t round___r4_numbers_6_5(obj_t);
extern bool_t exact__189___r4_numbers_6_5(obj_t);
extern obj_t inexact__exact_80___r4_numbers_6_5(obj_t);
static obj_t _acos___r4_numbers_6_5(obj_t, obj_t);
extern bool_t rational__51___r4_numbers_6_5(obj_t);
extern bool_t zero__228___r4_numbers_6_5(obj_t);
static obj_t _sqrt___r4_numbers_6_5(obj_t, obj_t);
extern bool_t number__102___r4_numbers_6_5(obj_t);
static obj_t _truncate___r4_numbers_6_5(obj_t, obj_t);
static obj_t _tan___r4_numbers_6_5(obj_t, obj_t);
static obj_t _sin___r4_numbers_6_5(obj_t, obj_t);
static obj_t ___149___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ___44___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ___38___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ___222___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t ___163___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t ___219___r4_numbers_6_5(obj_t, obj_t);
static obj_t ___10___r4_numbers_6_5(obj_t, obj_t);
extern obj_t string__number_104___r4_numbers_6_5(obj_t, obj_t);
extern obj_t expt___r4_numbers_6_5(obj_t, obj_t);
extern obj_t min___r4_numbers_6_5(obj_t, obj_t);
static obj_t _fixnum__flonum_153___r4_numbers_6_5(obj_t, obj_t);
static obj_t _number__string_61___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern double log___r4_numbers_6_5(obj_t);
extern obj_t max___r4_numbers_6_5(obj_t, obj_t);
static obj_t _exact__208___r4_numbers_6_5(obj_t, obj_t);
static obj_t _exact__inexact_16___r4_numbers_6_5(obj_t, obj_t);
extern obj_t truncate___r4_numbers_6_5(obj_t);
extern bool_t positive__57___r4_numbers_6_5(obj_t);
extern bool_t ___239___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t ___161___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t _2___235___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2___241___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__116___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__156___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__79___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__198___r4_numbers_6_5(obj_t, obj_t);
static obj_t _min___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _flonum__fixnum_24___r4_numbers_6_5(obj_t, obj_t);
static obj_t _log___r4_numbers_6_5(obj_t, obj_t);
static obj_t _max___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern long string__integer_39___r4_numbers_6_5_fixnum(char *, obj_t);
extern double acos___r4_numbers_6_5(obj_t);
extern double exp___r4_numbers_6_5(obj_t);
extern double sqrt___r4_numbers_6_5(obj_t);
static obj_t imported_modules_init_94___r4_numbers_6_5();
static obj_t _atan___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _asin___r4_numbers_6_5(obj_t, obj_t);
static obj_t require_initialization_114___r4_numbers_6_5 = BUNSPEC;
static obj_t _2___43___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2___117___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t ____251___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ____73___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
extern char * real_to_string(double);
extern double cos___r4_numbers_6_5(obj_t);
extern bool_t __172___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t __147___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t __124___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern obj_t __28___r4_numbers_6_5(obj_t, obj_t);
extern obj_t __186___r4_numbers_6_5(obj_t, obj_t);
extern obj_t __2___r4_numbers_6_5(obj_t);
extern obj_t __15___r4_numbers_6_5(obj_t);
static obj_t _2__130___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2__245___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2__208___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern double fixnum__flonum_13___r4_numbers_6_5(obj_t);
static obj_t _2__11___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( exact__env_214___r4_numbers_6_5, _exact__208___r4_numbers_6_51466, _exact__208___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( floor_env_50___r4_numbers_6_5, _floor___r4_numbers_6_51467, _floor___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2__env_159___r4_numbers_6_5, _2__208___r4_numbers_6_51468, _2__208___r4_numbers_6_5, 0L, 2 );
DEFINE_REAL( real1461___r4_numbers_6_5, real1461___r4_numbers_6_51469, 1.0 );
DEFINE_EXPORT_PROCEDURE( _2__env_141___r4_numbers_6_5, _2__171___r4_numbers_6_51470, _2__171___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( asin_env_88___r4_numbers_6_5, _asin___r4_numbers_6_51471, _asin___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_146___r4_numbers_6_5, ___219___r4_numbers_6_51472, va_generic_entry, ___219___r4_numbers_6_5, -1 );
DEFINE_EXPORT_PROCEDURE( cos_env_114___r4_numbers_6_5, _cos___r4_numbers_6_51473, _cos___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2___env_201___r4_numbers_6_5, _2___43___r4_numbers_6_51474, _2___43___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( log_env_219___r4_numbers_6_5, _log___r4_numbers_6_51475, _log___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_224___r4_numbers_6_5, ___149___r4_numbers_6_51476, va_generic_entry, ___149___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( fixnum__flonum_env_34___r4_numbers_6_5, _fixnum__flonum_153___r4_numbers_6_51477, _fixnum__flonum_153___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( atan_env_187___r4_numbers_6_5, _atan___r4_numbers_6_51478, va_generic_entry, _atan___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( min_env_72___r4_numbers_6_5, _min___r4_numbers_6_51479, va_generic_entry, _min___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( rational__env_181___r4_numbers_6_5, _rational__24___r4_numbers_6_51480, _rational__24___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_131___r4_numbers_6_5, ___222___r4_numbers_6_51481, va_generic_entry, ___222___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( zero__env_140___r4_numbers_6_5, _zero__222___r4_numbers_6_51482, _zero__222___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_27___r4_numbers_6_5, ___10___r4_numbers_6_51483, va_generic_entry, ___10___r4_numbers_6_5, -1 );
DEFINE_EXPORT_PROCEDURE( sin_env_239___r4_numbers_6_5, _sin___r4_numbers_6_51484, _sin___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( exp_env_94___r4_numbers_6_5, _exp___r4_numbers_6_51485, _exp___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( inexact__env_116___r4_numbers_6_5, _inexact__53___r4_numbers_6_51486, _inexact__53___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ceiling_env_45___r4_numbers_6_5, _ceiling___r4_numbers_6_51487, _ceiling___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( flonum__fixnum_env_186___r4_numbers_6_5, _flonum__fixnum_24___r4_numbers_6_51488, _flonum__fixnum_24___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_177___r4_numbers_6_5, ___44___r4_numbers_6_51489, va_generic_entry, ___44___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( string__number_env_5___r4_numbers_6_5, _string__number_250___r4_numbers_6_51490, va_generic_entry, _string__number_250___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( _2__env_132___r4_numbers_6_5, _2__242___r4_numbers_6_51491, _2__242___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( tan_env_231___r4_numbers_6_5, _tan___r4_numbers_6_51492, _tan___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ___env_53___r4_numbers_6_5, ____73___r4_numbers_6_51493, va_generic_entry, ____73___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( sqrt_env_78___r4_numbers_6_5, _sqrt___r4_numbers_6_51494, _sqrt___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( round_env_16___r4_numbers_6_5, _round___r4_numbers_6_51495, _round___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2__env_227___r4_numbers_6_5, _2__130___r4_numbers_6_51496, _2__130___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( inexact__exact_env_134___r4_numbers_6_5, _inexact__exact_215___r4_numbers_6_51497, _inexact__exact_215___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_55___r4_numbers_6_5, ___38___r4_numbers_6_51498, va_generic_entry, ___38___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( _2__env_108___r4_numbers_6_5, _2__11___r4_numbers_6_51499, _2__11___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _2__env_207___r4_numbers_6_5, _2__101___r4_numbers_6_51500, _2__101___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( __env_196___r4_numbers_6_5, ___163___r4_numbers_6_51501, va_generic_entry, ___163___r4_numbers_6_5, -2 );
DEFINE_STRING( string1464___r4_numbers_6_5, string1464___r4_numbers_6_51502, "Argument not a number", 21 );
DEFINE_STRING( string1463___r4_numbers_6_5, string1463___r4_numbers_6_51503, "number->string", 14 );
DEFINE_STRING( string1462___r4_numbers_6_5, string1462___r4_numbers_6_51504, "expt", 4 );
DEFINE_STRING( string1459___r4_numbers_6_5, string1459___r4_numbers_6_51505, "atan", 4 );
DEFINE_STRING( string1460___r4_numbers_6_5, string1460___r4_numbers_6_51506, "sqrt", 4 );
DEFINE_STRING( string1458___r4_numbers_6_5, string1458___r4_numbers_6_51507, "acos", 4 );
DEFINE_STRING( string1457___r4_numbers_6_5, string1457___r4_numbers_6_51508, "asin", 4 );
DEFINE_STRING( string1456___r4_numbers_6_5, string1456___r4_numbers_6_51509, "tan", 3 );
DEFINE_STRING( string1455___r4_numbers_6_5, string1455___r4_numbers_6_51510, "cos", 3 );
DEFINE_STRING( string1454___r4_numbers_6_5, string1454___r4_numbers_6_51511, "sin", 3 );
DEFINE_STRING( string1453___r4_numbers_6_5, string1453___r4_numbers_6_51512, "log", 3 );
DEFINE_STRING( string1452___r4_numbers_6_5, string1452___r4_numbers_6_51513, "exp", 3 );
DEFINE_STRING( string1451___r4_numbers_6_5, string1451___r4_numbers_6_51514, "round", 5 );
DEFINE_STRING( string1449___r4_numbers_6_5, string1449___r4_numbers_6_51515, "ceiling", 7 );
DEFINE_STRING( string1450___r4_numbers_6_5, string1450___r4_numbers_6_51516, "truncate", 8 );
DEFINE_STRING( string1448___r4_numbers_6_5, string1448___r4_numbers_6_51517, "floor", 5 );
DEFINE_STRING( string1447___r4_numbers_6_5, string1447___r4_numbers_6_51518, "abs", 3 );
DEFINE_STRING( string1446___r4_numbers_6_5, string1446___r4_numbers_6_51519, "/", 1 );
DEFINE_STRING( string1445___r4_numbers_6_5, string1445___r4_numbers_6_51520, "-", 1 );
DEFINE_STRING( string1444___r4_numbers_6_5, string1444___r4_numbers_6_51521, "*", 1 );
DEFINE_STRING( string1443___r4_numbers_6_5, string1443___r4_numbers_6_51522, "+", 1 );
DEFINE_STRING( string1442___r4_numbers_6_5, string1442___r4_numbers_6_51523, "negative", 8 );
DEFINE_STRING( string1441___r4_numbers_6_5, string1441___r4_numbers_6_51524, "positive", 8 );
DEFINE_STRING( string1439___r4_numbers_6_5, string1439___r4_numbers_6_51525, ">=", 2 );
DEFINE_STRING( string1440___r4_numbers_6_5, string1440___r4_numbers_6_51526, "zero", 4 );
DEFINE_STRING( string1438___r4_numbers_6_5, string1438___r4_numbers_6_51527, "<=", 2 );
DEFINE_STRING( string1437___r4_numbers_6_5, string1437___r4_numbers_6_51528, ">", 1 );
DEFINE_STRING( string1436___r4_numbers_6_5, string1436___r4_numbers_6_51529, "<", 1 );
DEFINE_STRING( string1435___r4_numbers_6_5, string1435___r4_numbers_6_51530, "not a number", 12 );
DEFINE_STRING( string1434___r4_numbers_6_5, string1434___r4_numbers_6_51531, "=", 1 );
DEFINE_EXPORT_PROCEDURE( truncate_env_98___r4_numbers_6_5, _truncate___r4_numbers_6_51532, _truncate___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2__env_147___r4_numbers_6_5, _2__245___r4_numbers_6_51533, _2__245___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ___env_251___r4_numbers_6_5, ____251___r4_numbers_6_51534, va_generic_entry, ____251___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( complex__env_220___r4_numbers_6_5, _complex__176___r4_numbers_6_51535, _complex__176___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( expt_env_52___r4_numbers_6_5, _expt___r4_numbers_6_51536, _expt___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( exact__inexact_env_238___r4_numbers_6_5, _exact__inexact_16___r4_numbers_6_51537, _exact__inexact_16___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2___env_180___r4_numbers_6_5, _2___117___r4_numbers_6_51538, _2___117___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( negative__env_63___r4_numbers_6_5, _negative__187___r4_numbers_6_51539, _negative__187___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( number__env_153___r4_numbers_6_5, _number__137___r4_numbers_6_51540, _number__137___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( number__string_env_103___r4_numbers_6_5, _number__string_61___r4_numbers_6_51541, va_generic_entry, _number__string_61___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( positive__env_240___r4_numbers_6_5, _positive__177___r4_numbers_6_51542, _positive__177___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( max_env_47___r4_numbers_6_5, _max___r4_numbers_6_51543, va_generic_entry, _max___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( acos_env_195___r4_numbers_6_5, _acos___r4_numbers_6_51544, _acos___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( abs_env_196___r4_numbers_6_5, _abs___r4_numbers_6_51545, _abs___r4_numbers_6_5, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_numbers_6_5(long checksum_1889, char * from_1890)
{
if(CBOOL(require_initialization_114___r4_numbers_6_5)){
require_initialization_114___r4_numbers_6_5 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_numbers_6_5();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* number? */bool_t number__102___r4_numbers_6_5(obj_t obj_1)
{
if(INTEGERP(obj_1)){
return ((bool_t)1);
}
 else {
return REALP(obj_1);
}
}


/* _number? */obj_t _number__137___r4_numbers_6_5(obj_t env_1757, obj_t obj_1758)
{
{
bool_t aux_1898;
{
obj_t obj_1882;
obj_1882 = obj_1758;
if(INTEGERP(obj_1882)){
aux_1898 = ((bool_t)1);
}
 else {
aux_1898 = REALP(obj_1882);
}
}
return BBOOL(aux_1898);
}
}


/* exact? */bool_t exact__189___r4_numbers_6_5(obj_t z_2)
{
return INTEGERP(z_2);
}


/* _exact? */obj_t _exact__208___r4_numbers_6_5(obj_t env_1759, obj_t z_1760)
{
{
bool_t aux_1904;
{
obj_t z_1883;
z_1883 = z_1760;
aux_1904 = INTEGERP(z_1883);
}
return BBOOL(aux_1904);
}
}


/* inexact? */bool_t inexact__139___r4_numbers_6_5(obj_t z_3)
{
return REALP(z_3);
}


/* _inexact? */obj_t _inexact__53___r4_numbers_6_5(obj_t env_1761, obj_t z_1762)
{
{
bool_t aux_1908;
{
obj_t z_1884;
z_1884 = z_1762;
aux_1908 = REALP(z_1884);
}
return BBOOL(aux_1908);
}
}


/* complex? */bool_t complex__118___r4_numbers_6_5(obj_t x_4)
{
if(INTEGERP(x_4)){
return ((bool_t)1);
}
 else {
return REALP(x_4);
}
}


/* _complex? */obj_t _complex__176___r4_numbers_6_5(obj_t env_1763, obj_t x_1764)
{
{
bool_t aux_1914;
aux_1914 = complex__118___r4_numbers_6_5(x_1764);
return BBOOL(aux_1914);
}
}


/* rational? */bool_t rational__51___r4_numbers_6_5(obj_t x_5)
{
if(INTEGERP(x_5)){
return ((bool_t)1);
}
 else {
return REALP(x_5);
}
}


/* _rational? */obj_t _rational__24___r4_numbers_6_5(obj_t env_1765, obj_t x_1766)
{
{
bool_t aux_1920;
aux_1920 = rational__51___r4_numbers_6_5(x_1766);
return BBOOL(aux_1920);
}
}


/* flonum->fixnum */long flonum__fixnum_11___r4_numbers_6_5(obj_t x_6)
{
{
double aux_1923;
aux_1923 = REAL_TO_DOUBLE(x_6);
return (long)(aux_1923);
}
}


/* _flonum->fixnum */obj_t _flonum__fixnum_24___r4_numbers_6_5(obj_t env_1767, obj_t x_1768)
{
{
long aux_1926;
{
obj_t x_1885;
x_1885 = x_1768;
{
double aux_1927;
aux_1927 = REAL_TO_DOUBLE(x_1885);
aux_1926 = (long)(aux_1927);
}
}
return BINT(aux_1926);
}
}


/* fixnum->flonum */double fixnum__flonum_13___r4_numbers_6_5(obj_t x_7)
{
{
long aux_1931;
aux_1931 = (long)CINT(x_7);
return (double)(aux_1931);
}
}


/* _fixnum->flonum */obj_t _fixnum__flonum_153___r4_numbers_6_5(obj_t env_1769, obj_t x_1770)
{
{
double aux_1934;
{
obj_t x_1886;
x_1886 = x_1770;
{
long aux_1935;
aux_1935 = (long)CINT(x_1886);
aux_1934 = (double)(aux_1935);
}
}
return make_real(aux_1934);
}
}


/* 2= */bool_t _2__95___r4_numbers_6_5(obj_t x_8, obj_t y_9)
{
if(INTEGERP(x_8)){
if(INTEGERP(y_9)){
{
long aux_1945;
long aux_1943;
aux_1945 = (long)CINT(y_9);
aux_1943 = (long)CINT(x_8);
return (aux_1943==aux_1945);
}
}
 else {
if(REALP(y_9)){
{
double arg1014_341;
{
long aux_1950;
aux_1950 = (long)CINT(x_8);
arg1014_341 = (double)(aux_1950);
}
{
double aux_1953;
aux_1953 = REAL_TO_DOUBLE(y_9);
return (arg1014_341==aux_1953);
}
}
}
 else {
FAILURE(string1434___r4_numbers_6_5,string1435___r4_numbers_6_5,y_9);}
}
}
 else {
if(REALP(x_8)){
if(REALP(y_9)){
{
double aux_1963;
double aux_1961;
aux_1963 = REAL_TO_DOUBLE(y_9);
aux_1961 = REAL_TO_DOUBLE(x_8);
return (aux_1961==aux_1963);
}
}
 else {
if(INTEGERP(y_9)){
{
double arg1018_345;
{
long aux_1968;
aux_1968 = (long)CINT(y_9);
arg1018_345 = (double)(aux_1968);
}
{
double aux_1971;
aux_1971 = REAL_TO_DOUBLE(x_8);
return (aux_1971==arg1018_345);
}
}
}
 else {
FAILURE(string1434___r4_numbers_6_5,string1435___r4_numbers_6_5,y_9);}
}
}
 else {
FAILURE(string1434___r4_numbers_6_5,string1435___r4_numbers_6_5,x_8);}
}
}


/* _2= */obj_t _2__245___r4_numbers_6_5(obj_t env_1771, obj_t x_1772, obj_t y_1773)
{
{
bool_t aux_1976;
aux_1976 = _2__95___r4_numbers_6_5(x_1772, y_1773);
return BBOOL(aux_1976);
}
}


/* = */bool_t __147___r4_numbers_6_5(obj_t x_10, obj_t y_11, obj_t z_12)
{
{
bool_t _andtest_1002_807;
_andtest_1002_807 = _2__95___r4_numbers_6_5(x_10, y_11);
if(_andtest_1002_807){
obj_t z_809;
z_809 = z_12;
__list_168_808:
if(NULLP(z_809)){
return ((bool_t)1);
}
 else {
bool_t test1021_811;
test1021_811 = _2__95___r4_numbers_6_5(y_11, CAR(z_809));
if(test1021_811){
{
obj_t z_1986;
z_1986 = CDR(z_809);
z_809 = z_1986;
goto __list_168_808;
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _= */obj_t ___44___r4_numbers_6_5(obj_t env_1774, obj_t x_1775, obj_t y_1776, obj_t z_1777)
{
{
bool_t aux_1988;
aux_1988 = __147___r4_numbers_6_5(x_1775, y_1776, z_1777);
return BBOOL(aux_1988);
}
}


/* 2< */bool_t _2__116___r4_numbers_6_5(obj_t x_13, obj_t y_14)
{
if(INTEGERP(x_13)){
if(INTEGERP(y_14)){
{
long aux_1997;
long aux_1995;
aux_1997 = (long)CINT(y_14);
aux_1995 = (long)CINT(x_13);
return (aux_1995<aux_1997);
}
}
 else {
if(REALP(y_14)){
{
double arg1027_359;
{
long aux_2002;
aux_2002 = (long)CINT(x_13);
arg1027_359 = (double)(aux_2002);
}
{
double aux_2005;
aux_2005 = REAL_TO_DOUBLE(y_14);
return (arg1027_359<aux_2005);
}
}
}
 else {
FAILURE(string1436___r4_numbers_6_5,string1435___r4_numbers_6_5,y_14);}
}
}
 else {
if(REALP(x_13)){
if(REALP(y_14)){
{
double aux_2015;
double aux_2013;
aux_2015 = REAL_TO_DOUBLE(y_14);
aux_2013 = REAL_TO_DOUBLE(x_13);
return (aux_2013<aux_2015);
}
}
 else {
if(INTEGERP(y_14)){
{
double arg1031_363;
{
long aux_2020;
aux_2020 = (long)CINT(y_14);
arg1031_363 = (double)(aux_2020);
}
{
double aux_2023;
aux_2023 = REAL_TO_DOUBLE(x_13);
return (aux_2023<arg1031_363);
}
}
}
 else {
FAILURE(string1436___r4_numbers_6_5,string1435___r4_numbers_6_5,y_14);}
}
}
 else {
FAILURE(string1436___r4_numbers_6_5,string1435___r4_numbers_6_5,x_13);}
}
}


/* _2< */obj_t _2__208___r4_numbers_6_5(obj_t env_1778, obj_t x_1779, obj_t y_1780)
{
{
bool_t aux_2028;
aux_2028 = _2__116___r4_numbers_6_5(x_1779, y_1780);
return BBOOL(aux_2028);
}
}


/* < */bool_t __124___r4_numbers_6_5(obj_t x_15, obj_t y_16, obj_t z_17)
{
{
bool_t _andtest_1003_866;
_andtest_1003_866 = _2__116___r4_numbers_6_5(x_15, y_16);
if(_andtest_1003_866){
obj_t x_868;
obj_t z_869;
x_868 = y_16;
z_869 = z_17;
__list_80_867:
if(NULLP(z_869)){
return ((bool_t)1);
}
 else {
bool_t test1034_876;
test1034_876 = _2__116___r4_numbers_6_5(x_868, CAR(z_869));
if(test1034_876){
{
obj_t z_2040;
obj_t x_2038;
x_2038 = CAR(z_869);
z_2040 = CDR(z_869);
z_869 = z_2040;
x_868 = x_2038;
goto __list_80_867;
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _< */obj_t ___38___r4_numbers_6_5(obj_t env_1781, obj_t x_1782, obj_t y_1783, obj_t z_1784)
{
{
bool_t aux_2042;
aux_2042 = __124___r4_numbers_6_5(x_1782, y_1783, z_1784);
return BBOOL(aux_2042);
}
}


/* 2> */bool_t _2__206___r4_numbers_6_5(obj_t x_18, obj_t y_19)
{
if(INTEGERP(x_18)){
if(INTEGERP(y_19)){
{
long aux_2051;
long aux_2049;
aux_2051 = (long)CINT(y_19);
aux_2049 = (long)CINT(x_18);
return (aux_2049>aux_2051);
}
}
 else {
if(REALP(y_19)){
{
double arg1042_378;
{
long aux_2056;
aux_2056 = (long)CINT(x_18);
arg1042_378 = (double)(aux_2056);
}
{
double aux_2059;
aux_2059 = REAL_TO_DOUBLE(y_19);
return (arg1042_378>aux_2059);
}
}
}
 else {
FAILURE(string1437___r4_numbers_6_5,string1435___r4_numbers_6_5,y_19);}
}
}
 else {
if(REALP(x_18)){
if(REALP(y_19)){
{
double aux_2069;
double aux_2067;
aux_2069 = REAL_TO_DOUBLE(y_19);
aux_2067 = REAL_TO_DOUBLE(x_18);
return (aux_2067>aux_2069);
}
}
 else {
if(INTEGERP(y_19)){
{
double arg1046_382;
{
long aux_2074;
aux_2074 = (long)CINT(y_19);
arg1046_382 = (double)(aux_2074);
}
{
double aux_2077;
aux_2077 = REAL_TO_DOUBLE(x_18);
return (aux_2077>arg1046_382);
}
}
}
 else {
FAILURE(string1437___r4_numbers_6_5,string1435___r4_numbers_6_5,y_19);}
}
}
 else {
FAILURE(string1437___r4_numbers_6_5,string1435___r4_numbers_6_5,x_18);}
}
}


/* _2> */obj_t _2__130___r4_numbers_6_5(obj_t env_1785, obj_t x_1786, obj_t y_1787)
{
{
bool_t aux_2082;
aux_2082 = _2__206___r4_numbers_6_5(x_1786, y_1787);
return BBOOL(aux_2082);
}
}


/* > */bool_t __172___r4_numbers_6_5(obj_t x_20, obj_t y_21, obj_t z_22)
{
{
bool_t _andtest_1004_937;
_andtest_1004_937 = _2__206___r4_numbers_6_5(x_20, y_21);
if(_andtest_1004_937){
obj_t x_939;
obj_t z_940;
x_939 = y_21;
z_940 = z_22;
__list_166_938:
if(NULLP(z_940)){
return ((bool_t)1);
}
 else {
bool_t test1049_947;
test1049_947 = _2__206___r4_numbers_6_5(x_939, CAR(z_940));
if(test1049_947){
{
obj_t z_2094;
obj_t x_2092;
x_2092 = CAR(z_940);
z_2094 = CDR(z_940);
z_940 = z_2094;
x_939 = x_2092;
goto __list_166_938;
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _> */obj_t ___149___r4_numbers_6_5(obj_t env_1788, obj_t x_1789, obj_t y_1790, obj_t z_1791)
{
{
bool_t aux_2096;
aux_2096 = __172___r4_numbers_6_5(x_1789, y_1790, z_1791);
return BBOOL(aux_2096);
}
}


/* 2<= */bool_t _2___241___r4_numbers_6_5(obj_t x_23, obj_t y_24)
{
if(INTEGERP(x_23)){
if(INTEGERP(y_24)){
{
long aux_2105;
long aux_2103;
aux_2105 = (long)CINT(y_24);
aux_2103 = (long)CINT(x_23);
return (aux_2103<=aux_2105);
}
}
 else {
if(REALP(y_24)){
{
double arg1057_397;
{
long aux_2110;
aux_2110 = (long)CINT(x_23);
arg1057_397 = (double)(aux_2110);
}
{
double aux_2113;
aux_2113 = REAL_TO_DOUBLE(y_24);
return (arg1057_397<=aux_2113);
}
}
}
 else {
FAILURE(string1438___r4_numbers_6_5,string1435___r4_numbers_6_5,y_24);}
}
}
 else {
if(REALP(x_23)){
if(REALP(y_24)){
{
double aux_2123;
double aux_2121;
aux_2123 = REAL_TO_DOUBLE(y_24);
aux_2121 = REAL_TO_DOUBLE(x_23);
return (aux_2121<=aux_2123);
}
}
 else {
if(INTEGERP(y_24)){
{
double arg1061_401;
{
long aux_2128;
aux_2128 = (long)CINT(y_24);
arg1061_401 = (double)(aux_2128);
}
{
double aux_2131;
aux_2131 = REAL_TO_DOUBLE(x_23);
return (aux_2131<=arg1061_401);
}
}
}
 else {
FAILURE(string1438___r4_numbers_6_5,string1435___r4_numbers_6_5,y_24);}
}
}
 else {
FAILURE(string1438___r4_numbers_6_5,string1435___r4_numbers_6_5,x_23);}
}
}


/* _2<= */obj_t _2___117___r4_numbers_6_5(obj_t env_1792, obj_t x_1793, obj_t y_1794)
{
{
bool_t aux_2136;
aux_2136 = _2___241___r4_numbers_6_5(x_1793, y_1794);
return BBOOL(aux_2136);
}
}


/* <= */bool_t ___161___r4_numbers_6_5(obj_t x_25, obj_t y_26, obj_t z_27)
{
{
bool_t _andtest_1005_1008;
_andtest_1005_1008 = _2___241___r4_numbers_6_5(x_25, y_26);
if(_andtest_1005_1008){
obj_t x_1010;
obj_t z_1011;
x_1010 = y_26;
z_1011 = z_27;
___list_79_1009:
if(NULLP(z_1011)){
return ((bool_t)1);
}
 else {
bool_t test1064_1018;
test1064_1018 = _2___241___r4_numbers_6_5(x_1010, CAR(z_1011));
if(test1064_1018){
{
obj_t z_2148;
obj_t x_2146;
x_2146 = CAR(z_1011);
z_2148 = CDR(z_1011);
z_1011 = z_2148;
x_1010 = x_2146;
goto ___list_79_1009;
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _<= */obj_t ____73___r4_numbers_6_5(obj_t env_1795, obj_t x_1796, obj_t y_1797, obj_t z_1798)
{
{
bool_t aux_2150;
aux_2150 = ___161___r4_numbers_6_5(x_1796, y_1797, z_1798);
return BBOOL(aux_2150);
}
}


/* 2>= */bool_t _2___235___r4_numbers_6_5(obj_t x_28, obj_t y_29)
{
if(INTEGERP(x_28)){
if(INTEGERP(y_29)){
{
long aux_2159;
long aux_2157;
aux_2159 = (long)CINT(y_29);
aux_2157 = (long)CINT(x_28);
return (aux_2157>=aux_2159);
}
}
 else {
if(REALP(y_29)){
{
double arg1072_416;
{
long aux_2164;
aux_2164 = (long)CINT(x_28);
arg1072_416 = (double)(aux_2164);
}
{
double aux_2167;
aux_2167 = REAL_TO_DOUBLE(y_29);
return (arg1072_416>=aux_2167);
}
}
}
 else {
FAILURE(string1439___r4_numbers_6_5,string1435___r4_numbers_6_5,y_29);}
}
}
 else {
if(REALP(x_28)){
if(REALP(y_29)){
{
double aux_2177;
double aux_2175;
aux_2177 = REAL_TO_DOUBLE(y_29);
aux_2175 = REAL_TO_DOUBLE(x_28);
return (aux_2175>=aux_2177);
}
}
 else {
if(INTEGERP(y_29)){
{
double arg1076_420;
{
long aux_2182;
aux_2182 = (long)CINT(y_29);
arg1076_420 = (double)(aux_2182);
}
{
double aux_2185;
aux_2185 = REAL_TO_DOUBLE(x_28);
return (aux_2185>=arg1076_420);
}
}
}
 else {
FAILURE(string1439___r4_numbers_6_5,string1435___r4_numbers_6_5,y_29);}
}
}
 else {
FAILURE(string1439___r4_numbers_6_5,string1435___r4_numbers_6_5,x_28);}
}
}


/* _2>= */obj_t _2___43___r4_numbers_6_5(obj_t env_1799, obj_t x_1800, obj_t y_1801)
{
{
bool_t aux_2190;
aux_2190 = _2___235___r4_numbers_6_5(x_1800, y_1801);
return BBOOL(aux_2190);
}
}


/* >= */bool_t ___239___r4_numbers_6_5(obj_t x_30, obj_t y_31, obj_t z_32)
{
{
bool_t _andtest_1006_1079;
_andtest_1006_1079 = _2___235___r4_numbers_6_5(x_30, y_31);
if(_andtest_1006_1079){
obj_t x_1081;
obj_t z_1082;
x_1081 = y_31;
z_1082 = z_32;
___list_225_1080:
if(NULLP(z_1082)){
return ((bool_t)1);
}
 else {
bool_t test1079_1089;
test1079_1089 = _2___235___r4_numbers_6_5(x_1081, CAR(z_1082));
if(test1079_1089){
{
obj_t z_2202;
obj_t x_2200;
x_2200 = CAR(z_1082);
z_2202 = CDR(z_1082);
z_1082 = z_2202;
x_1081 = x_2200;
goto ___list_225_1080;
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _>= */obj_t ____251___r4_numbers_6_5(obj_t env_1802, obj_t x_1803, obj_t y_1804, obj_t z_1805)
{
{
bool_t aux_2204;
aux_2204 = ___239___r4_numbers_6_5(x_1803, y_1804, z_1805);
return BBOOL(aux_2204);
}
}


/* zero? */bool_t zero__228___r4_numbers_6_5(obj_t x_33)
{
if(INTEGERP(x_33)){
{
long aux_2209;
aux_2209 = (long)CINT(x_33);
return (aux_2209==((long)0));
}
}
 else {
if(REALP(x_33)){
{
double aux_2214;
aux_2214 = REAL_TO_DOUBLE(x_33);
return (aux_2214==((double)0.0));
}
}
 else {
FAILURE(string1440___r4_numbers_6_5,string1435___r4_numbers_6_5,x_33);}
}
}


/* _zero? */obj_t _zero__222___r4_numbers_6_5(obj_t env_1806, obj_t x_1807)
{
{
bool_t aux_2218;
aux_2218 = zero__228___r4_numbers_6_5(x_1807);
return BBOOL(aux_2218);
}
}


/* positive? */bool_t positive__57___r4_numbers_6_5(obj_t x_34)
{
if(INTEGERP(x_34)){
{
long aux_2223;
aux_2223 = (long)CINT(x_34);
return (aux_2223>((long)0));
}
}
 else {
if(REALP(x_34)){
{
double aux_2228;
aux_2228 = REAL_TO_DOUBLE(x_34);
return (aux_2228>((double)0.0));
}
}
 else {
FAILURE(string1441___r4_numbers_6_5,string1435___r4_numbers_6_5,x_34);}
}
}


/* _positive? */obj_t _positive__177___r4_numbers_6_5(obj_t env_1808, obj_t x_1809)
{
{
bool_t aux_2232;
aux_2232 = positive__57___r4_numbers_6_5(x_1809);
return BBOOL(aux_2232);
}
}


/* negative? */bool_t negative__33___r4_numbers_6_5(obj_t x_35)
{
if(INTEGERP(x_35)){
{
long aux_2237;
aux_2237 = (long)CINT(x_35);
return (aux_2237<((long)0));
}
}
 else {
if(REALP(x_35)){
{
double aux_2242;
aux_2242 = REAL_TO_DOUBLE(x_35);
return (aux_2242<((double)0.0));
}
}
 else {
FAILURE(string1442___r4_numbers_6_5,string1435___r4_numbers_6_5,x_35);}
}
}


/* _negative? */obj_t _negative__187___r4_numbers_6_5(obj_t env_1810, obj_t x_1811)
{
{
bool_t aux_2246;
aux_2246 = negative__33___r4_numbers_6_5(x_1811);
return BBOOL(aux_2246);
}
}


/* max */obj_t max___r4_numbers_6_5(obj_t x_36, obj_t y_37)
{
{
obj_t x_1151;
obj_t y_1152;
x_1151 = x_36;
y_1152 = y_37;
loop_1150:
if(PAIRP(y_1152)){
obj_t arg1090_1159;
obj_t arg1091_1160;
{
bool_t test1092_1161;
test1092_1161 = _2__206___r4_numbers_6_5(x_1151, CAR(y_1152));
if(test1092_1161){
arg1090_1159 = x_1151;
}
 else {
arg1090_1159 = CAR(y_1152);
}
}
arg1091_1160 = CDR(y_1152);
{
obj_t y_2257;
obj_t x_2256;
x_2256 = arg1090_1159;
y_2257 = arg1091_1160;
y_1152 = y_2257;
x_1151 = x_2256;
goto loop_1150;
}
}
 else {
return x_1151;
}
}
}


/* _max */obj_t _max___r4_numbers_6_5(obj_t env_1812, obj_t x_1813, obj_t y_1814)
{
return max___r4_numbers_6_5(x_1813, y_1814);
}


/* min */obj_t min___r4_numbers_6_5(obj_t x_38, obj_t y_39)
{
{
obj_t x_1188;
obj_t y_1189;
x_1188 = x_38;
y_1189 = y_39;
loop_1187:
if(PAIRP(y_1189)){
obj_t arg1095_1196;
obj_t arg1096_1197;
{
bool_t test1097_1198;
test1097_1198 = _2__116___r4_numbers_6_5(x_1188, CAR(y_1189));
if(test1097_1198){
arg1095_1196 = x_1188;
}
 else {
arg1095_1196 = CAR(y_1189);
}
}
arg1096_1197 = CDR(y_1189);
{
obj_t y_2267;
obj_t x_2266;
x_2266 = arg1095_1196;
y_2267 = arg1096_1197;
y_1189 = y_2267;
x_1188 = x_2266;
goto loop_1187;
}
}
 else {
return x_1188;
}
}
}


/* _min */obj_t _min___r4_numbers_6_5(obj_t env_1815, obj_t x_1816, obj_t y_1817)
{
return min___r4_numbers_6_5(x_1816, y_1817);
}


/* 2+ */obj_t _2__168___r4_numbers_6_5(obj_t x_40, obj_t y_41)
{
if(INTEGERP(x_40)){
if(INTEGERP(y_41)){
{
long aux_2273;
{
long aux_2276;
long aux_2274;
aux_2276 = (long)CINT(y_41);
aux_2274 = (long)CINT(x_40);
aux_2273 = (aux_2274+aux_2276);
}
return BINT(aux_2273);
}
}
 else {
if(REALP(y_41)){
{
double arg1102_457;
{
long aux_2282;
aux_2282 = (long)CINT(x_40);
arg1102_457 = (double)(aux_2282);
}
{
double aux_2285;
{
double aux_2286;
aux_2286 = REAL_TO_DOUBLE(y_41);
aux_2285 = (arg1102_457+aux_2286);
}
return make_real(aux_2285);
}
}
}
 else {
FAILURE(string1443___r4_numbers_6_5,string1435___r4_numbers_6_5,y_41);}
}
}
 else {
if(REALP(x_40)){
if(REALP(y_41)){
{
double aux_2295;
{
double aux_2298;
double aux_2296;
aux_2298 = REAL_TO_DOUBLE(y_41);
aux_2296 = REAL_TO_DOUBLE(x_40);
aux_2295 = (aux_2296+aux_2298);
}
return make_real(aux_2295);
}
}
 else {
if(INTEGERP(y_41)){
{
double arg1106_461;
{
long aux_2304;
aux_2304 = (long)CINT(y_41);
arg1106_461 = (double)(aux_2304);
}
{
double aux_2307;
{
double aux_2308;
aux_2308 = REAL_TO_DOUBLE(x_40);
aux_2307 = (aux_2308+arg1106_461);
}
return make_real(aux_2307);
}
}
}
 else {
FAILURE(string1443___r4_numbers_6_5,string1435___r4_numbers_6_5,y_41);}
}
}
 else {
FAILURE(string1443___r4_numbers_6_5,string1435___r4_numbers_6_5,x_40);}
}
}


/* _2+ */obj_t _2__242___r4_numbers_6_5(obj_t env_1818, obj_t x_1819, obj_t y_1820)
{
return _2__168___r4_numbers_6_5(x_1819, y_1820);
}


/* + */obj_t __2___r4_numbers_6_5(obj_t x_42)
{
{
obj_t sum_1250;
obj_t x_1251;
sum_1250 = BINT(((long)0));
x_1251 = x_42;
loop_1249:
if(PAIRP(x_1251)){
obj_t arg1108_1257;
obj_t arg1109_1258;
arg1108_1257 = _2__168___r4_numbers_6_5(sum_1250, CAR(x_1251));
arg1109_1258 = CDR(x_1251);
{
obj_t x_2321;
obj_t sum_2320;
sum_2320 = arg1108_1257;
x_2321 = arg1109_1258;
x_1251 = x_2321;
sum_1250 = sum_2320;
goto loop_1249;
}
}
 else {
return sum_1250;
}
}
}


/* _+ */obj_t ___219___r4_numbers_6_5(obj_t env_1821, obj_t x_1822)
{
return __2___r4_numbers_6_5(x_1822);
}


/* 2* */obj_t _2__198___r4_numbers_6_5(obj_t x_43, obj_t y_44)
{
if(INTEGERP(x_43)){
if(INTEGERP(y_44)){
{
long aux_2328;
{
long aux_2331;
long aux_2329;
aux_2331 = (long)CINT(y_44);
aux_2329 = (long)CINT(x_43);
aux_2328 = (aux_2329*aux_2331);
}
return BINT(aux_2328);
}
}
 else {
if(REALP(y_44)){
{
double arg1114_472;
{
long aux_2337;
aux_2337 = (long)CINT(x_43);
arg1114_472 = (double)(aux_2337);
}
{
double aux_2340;
{
double aux_2341;
aux_2341 = REAL_TO_DOUBLE(y_44);
aux_2340 = (arg1114_472*aux_2341);
}
return make_real(aux_2340);
}
}
}
 else {
FAILURE(string1444___r4_numbers_6_5,string1435___r4_numbers_6_5,y_44);}
}
}
 else {
if(REALP(x_43)){
if(REALP(y_44)){
{
double aux_2350;
{
double aux_2353;
double aux_2351;
aux_2353 = REAL_TO_DOUBLE(y_44);
aux_2351 = REAL_TO_DOUBLE(x_43);
aux_2350 = (aux_2351*aux_2353);
}
return make_real(aux_2350);
}
}
 else {
if(INTEGERP(y_44)){
{
double arg1118_476;
{
long aux_2359;
aux_2359 = (long)CINT(y_44);
arg1118_476 = (double)(aux_2359);
}
{
double aux_2362;
{
double aux_2363;
aux_2363 = REAL_TO_DOUBLE(x_43);
aux_2362 = (aux_2363*arg1118_476);
}
return make_real(aux_2362);
}
}
}
 else {
FAILURE(string1444___r4_numbers_6_5,string1435___r4_numbers_6_5,y_44);}
}
}
 else {
FAILURE(string1444___r4_numbers_6_5,string1435___r4_numbers_6_5,x_43);}
}
}


/* _2* */obj_t _2__101___r4_numbers_6_5(obj_t env_1823, obj_t x_1824, obj_t y_1825)
{
return _2__198___r4_numbers_6_5(x_1824, y_1825);
}


/* * */obj_t __15___r4_numbers_6_5(obj_t x_45)
{
{
obj_t product_1305;
obj_t x_1306;
product_1305 = BINT(((long)1));
x_1306 = x_45;
loop_1304:
if(PAIRP(x_1306)){
obj_t arg1120_1312;
obj_t arg1121_1313;
arg1120_1312 = _2__198___r4_numbers_6_5(product_1305, CAR(x_1306));
arg1121_1313 = CDR(x_1306);
{
obj_t x_2376;
obj_t product_2375;
product_2375 = arg1120_1312;
x_2376 = arg1121_1313;
x_1306 = x_2376;
product_1305 = product_2375;
goto loop_1304;
}
}
 else {
return product_1305;
}
}
}


/* _* */obj_t ___10___r4_numbers_6_5(obj_t env_1826, obj_t x_1827)
{
return __15___r4_numbers_6_5(x_1827);
}


/* 2- */obj_t _2__79___r4_numbers_6_5(obj_t x_46, obj_t y_47)
{
if(INTEGERP(x_46)){
if(INTEGERP(y_47)){
{
long aux_2383;
{
long aux_2386;
long aux_2384;
aux_2386 = (long)CINT(y_47);
aux_2384 = (long)CINT(x_46);
aux_2383 = (aux_2384-aux_2386);
}
return BINT(aux_2383);
}
}
 else {
if(REALP(y_47)){
{
double arg1126_487;
{
long aux_2392;
aux_2392 = (long)CINT(x_46);
arg1126_487 = (double)(aux_2392);
}
{
double aux_2395;
{
double aux_2396;
aux_2396 = REAL_TO_DOUBLE(y_47);
aux_2395 = (arg1126_487-aux_2396);
}
return make_real(aux_2395);
}
}
}
 else {
FAILURE(string1445___r4_numbers_6_5,string1435___r4_numbers_6_5,y_47);}
}
}
 else {
if(REALP(x_46)){
if(REALP(y_47)){
{
double aux_2405;
{
double aux_2408;
double aux_2406;
aux_2408 = REAL_TO_DOUBLE(y_47);
aux_2406 = REAL_TO_DOUBLE(x_46);
aux_2405 = (aux_2406-aux_2408);
}
return make_real(aux_2405);
}
}
 else {
if(INTEGERP(y_47)){
{
double arg1130_491;
{
long aux_2414;
aux_2414 = (long)CINT(y_47);
arg1130_491 = (double)(aux_2414);
}
{
double aux_2417;
{
double aux_2418;
aux_2418 = REAL_TO_DOUBLE(x_46);
aux_2417 = (aux_2418-arg1130_491);
}
return make_real(aux_2417);
}
}
}
 else {
FAILURE(string1445___r4_numbers_6_5,string1435___r4_numbers_6_5,y_47);}
}
}
 else {
FAILURE(string1445___r4_numbers_6_5,string1435___r4_numbers_6_5,x_46);}
}
}


/* _2- */obj_t _2__171___r4_numbers_6_5(obj_t env_1828, obj_t x_1829, obj_t y_1830)
{
return _2__79___r4_numbers_6_5(x_1829, y_1830);
}


/* - */obj_t __186___r4_numbers_6_5(obj_t x_48, obj_t y_49)
{
if(PAIRP(y_49)){
obj_t arg1132_496;
obj_t arg1133_497;
arg1132_496 = _2__79___r4_numbers_6_5(x_48, CAR(y_49));
arg1133_497 = CDR(y_49);
{
obj_t result_1363;
obj_t args_1364;
result_1363 = arg1132_496;
args_1364 = arg1133_497;
loop_1362:
if(PAIRP(args_1364)){
obj_t arg1136_1370;
obj_t arg1137_1371;
arg1136_1370 = _2__79___r4_numbers_6_5(result_1363, CAR(args_1364));
arg1137_1371 = CDR(args_1364);
{
obj_t args_2436;
obj_t result_2435;
result_2435 = arg1136_1370;
args_2436 = arg1137_1371;
args_1364 = args_2436;
result_1363 = result_2435;
goto loop_1362;
}
}
 else {
return result_1363;
}
}
}
 else {
return _2__79___r4_numbers_6_5(BINT(((long)0)), x_48);
}
}


/* _- */obj_t ___163___r4_numbers_6_5(obj_t env_1831, obj_t x_1832, obj_t y_1833)
{
return __186___r4_numbers_6_5(x_1832, y_1833);
}


/* 2/ */obj_t _2__156___r4_numbers_6_5(obj_t x_50, obj_t y_51)
{
if(INTEGERP(x_50)){
if(INTEGERP(y_51)){
{
bool_t test1142_505;
{
long arg1145_508;
{
long aux_2446;
long aux_2444;
aux_2446 = (long)CINT(y_51);
aux_2444 = (long)CINT(x_50);
arg1145_508 = (aux_2444%aux_2446);
}
test1142_505 = (arg1145_508==((long)0));
}
if(test1142_505){
long aux_2451;
{
long aux_2454;
long aux_2452;
aux_2454 = (long)CINT(y_51);
aux_2452 = (long)CINT(x_50);
aux_2451 = (aux_2452/aux_2454);
}
return BINT(aux_2451);
}
 else {
double arg1143_506;
double arg1144_507;
{
long aux_2458;
aux_2458 = (long)CINT(x_50);
arg1143_506 = (double)(aux_2458);
}
{
long aux_2461;
aux_2461 = (long)CINT(y_51);
arg1144_507 = (double)(aux_2461);
}
{
double aux_2464;
aux_2464 = (arg1143_506/arg1144_507);
return make_real(aux_2464);
}
}
}
}
 else {
if(REALP(y_51)){
{
double arg1148_511;
{
long aux_2469;
aux_2469 = (long)CINT(x_50);
arg1148_511 = (double)(aux_2469);
}
{
double aux_2472;
{
double aux_2473;
aux_2473 = REAL_TO_DOUBLE(y_51);
aux_2472 = (arg1148_511/aux_2473);
}
return make_real(aux_2472);
}
}
}
 else {
FAILURE(string1446___r4_numbers_6_5,string1435___r4_numbers_6_5,y_51);}
}
}
 else {
if(REALP(x_50)){
if(REALP(y_51)){
{
double aux_2482;
{
double aux_2485;
double aux_2483;
aux_2485 = REAL_TO_DOUBLE(y_51);
aux_2483 = REAL_TO_DOUBLE(x_50);
aux_2482 = (aux_2483/aux_2485);
}
return make_real(aux_2482);
}
}
 else {
if(INTEGERP(y_51)){
{
double arg1152_515;
{
long aux_2491;
aux_2491 = (long)CINT(y_51);
arg1152_515 = (double)(aux_2491);
}
{
double aux_2494;
{
double aux_2495;
aux_2495 = REAL_TO_DOUBLE(x_50);
aux_2494 = (aux_2495/arg1152_515);
}
return make_real(aux_2494);
}
}
}
 else {
FAILURE(string1446___r4_numbers_6_5,string1435___r4_numbers_6_5,y_51);}
}
}
 else {
FAILURE(string1446___r4_numbers_6_5,string1435___r4_numbers_6_5,x_50);}
}
}


/* _2/ */obj_t _2__11___r4_numbers_6_5(obj_t env_1834, obj_t x_1835, obj_t y_1836)
{
return _2__156___r4_numbers_6_5(x_1835, y_1836);
}


/* / */obj_t __28___r4_numbers_6_5(obj_t x_52, obj_t y_53)
{
if(PAIRP(y_53)){
obj_t arg1154_520;
obj_t arg1155_521;
arg1154_520 = _2__156___r4_numbers_6_5(x_52, CAR(y_53));
arg1155_521 = CDR(y_53);
{
obj_t result_1429;
obj_t z_1430;
result_1429 = arg1154_520;
z_1430 = arg1155_521;
loop_1428:
if(PAIRP(z_1430)){
obj_t arg1158_1436;
obj_t arg1160_1437;
arg1158_1436 = _2__156___r4_numbers_6_5(result_1429, CAR(z_1430));
arg1160_1437 = CDR(z_1430);
{
obj_t z_2513;
obj_t result_2512;
result_2512 = arg1158_1436;
z_2513 = arg1160_1437;
z_1430 = z_2513;
result_1429 = result_2512;
goto loop_1428;
}
}
 else {
return result_1429;
}
}
}
 else {
return _2__156___r4_numbers_6_5(BINT(((long)1)), x_52);
}
}


/* _/ */obj_t ___222___r4_numbers_6_5(obj_t env_1837, obj_t x_1838, obj_t y_1839)
{
return __28___r4_numbers_6_5(x_1838, y_1839);
}


/* abs */obj_t abs___r4_numbers_6_5(obj_t x_54)
{
if(INTEGERP(x_54)){
{
long aux_2519;
{
long n_1459;
n_1459 = (long)CINT(x_54);
if((n_1459<((long)0))){
aux_2519 = NEG(n_1459);
}
 else {
aux_2519 = n_1459;
}
}
return BINT(aux_2519);
}
}
 else {
if(REALP(x_54)){
{
double aux_2527;
{
double r_1466;
r_1466 = REAL_TO_DOUBLE(x_54);
if((r_1466<((double)0.0))){
aux_2527 = NEG(r_1466);
}
 else {
aux_2527 = r_1466;
}
}
return make_real(aux_2527);
}
}
 else {
FAILURE(string1447___r4_numbers_6_5,string1435___r4_numbers_6_5,x_54);}
}
}


/* _abs */obj_t _abs___r4_numbers_6_5(obj_t env_1840, obj_t x_1841)
{
return abs___r4_numbers_6_5(x_1841);
}


/* floor */obj_t floor___r4_numbers_6_5(obj_t x_55)
{
if(INTEGERP(x_55)){
return x_55;
}
 else {
if(REALP(x_55)){
{
double aux_2539;
{
double aux_2540;
aux_2540 = REAL_TO_DOUBLE(x_55);
aux_2539 = floor(aux_2540);
}
return make_real(aux_2539);
}
}
 else {
FAILURE(string1448___r4_numbers_6_5,string1435___r4_numbers_6_5,x_55);}
}
}


/* _floor */obj_t _floor___r4_numbers_6_5(obj_t env_1842, obj_t x_1843)
{
return floor___r4_numbers_6_5(x_1843);
}


/* ceiling */obj_t ceiling___r4_numbers_6_5(obj_t x_56)
{
if(INTEGERP(x_56)){
return x_56;
}
 else {
if(REALP(x_56)){
{
double aux_2550;
{
double aux_2551;
aux_2551 = REAL_TO_DOUBLE(x_56);
aux_2550 = ceil(aux_2551);
}
return make_real(aux_2550);
}
}
 else {
FAILURE(string1449___r4_numbers_6_5,string1435___r4_numbers_6_5,x_56);}
}
}


/* _ceiling */obj_t _ceiling___r4_numbers_6_5(obj_t env_1844, obj_t x_1845)
{
return ceiling___r4_numbers_6_5(x_1845);
}


/* truncate */obj_t truncate___r4_numbers_6_5(obj_t x_57)
{
if(INTEGERP(x_57)){
return x_57;
}
 else {
if(REALP(x_57)){
{
double res1429_1502;
{
double r_1495;
r_1495 = REAL_TO_DOUBLE(x_57);
if((r_1495<((double)0.0))){
res1429_1502 = ceil(r_1495);
}
 else {
res1429_1502 = floor(r_1495);
}
}
return make_real(res1429_1502);
}
}
 else {
FAILURE(string1450___r4_numbers_6_5,string1435___r4_numbers_6_5,x_57);}
}
}


/* _truncate */obj_t _truncate___r4_numbers_6_5(obj_t env_1846, obj_t x_1847)
{
return truncate___r4_numbers_6_5(x_1847);
}


/* round */obj_t round___r4_numbers_6_5(obj_t x_58)
{
if(INTEGERP(x_58)){
return x_58;
}
 else {
if(REALP(x_58)){
{
double res1430_1515;
{
double aux_2573;
{
double aux_2574;
aux_2574 = REAL_TO_DOUBLE(x_58);
aux_2573 = (aux_2574+((double)0.5));
}
res1430_1515 = floor(aux_2573);
}
return make_real(res1430_1515);
}
}
 else {
FAILURE(string1451___r4_numbers_6_5,string1435___r4_numbers_6_5,x_58);}
}
}


/* _round */obj_t _round___r4_numbers_6_5(obj_t env_1848, obj_t x_1849)
{
return round___r4_numbers_6_5(x_1849);
}


/* exp */double exp___r4_numbers_6_5(obj_t x_59)
{
if(INTEGERP(x_59)){
{
double arg1173_538;
{
long aux_2583;
aux_2583 = (long)CINT(x_59);
arg1173_538 = (double)(aux_2583);
}
return exp(arg1173_538);
}
}
 else {
if(REALP(x_59)){
{
double aux_2589;
aux_2589 = REAL_TO_DOUBLE(x_59);
return exp(aux_2589);
}
}
 else {
FAILURE(string1452___r4_numbers_6_5,string1435___r4_numbers_6_5,x_59);}
}
}


/* _exp */obj_t _exp___r4_numbers_6_5(obj_t env_1850, obj_t x_1851)
{
{
double aux_2593;
aux_2593 = exp___r4_numbers_6_5(x_1851);
return make_real(aux_2593);
}
}


/* log */double log___r4_numbers_6_5(obj_t x_60)
{
if(INTEGERP(x_60)){
{
double arg1176_541;
{
long aux_2598;
aux_2598 = (long)CINT(x_60);
arg1176_541 = (double)(aux_2598);
}
return log(arg1176_541);
}
}
 else {
if(REALP(x_60)){
{
double aux_2604;
aux_2604 = REAL_TO_DOUBLE(x_60);
return log(aux_2604);
}
}
 else {
FAILURE(string1453___r4_numbers_6_5,string1435___r4_numbers_6_5,x_60);}
}
}


/* _log */obj_t _log___r4_numbers_6_5(obj_t env_1852, obj_t x_1853)
{
{
double aux_2608;
aux_2608 = log___r4_numbers_6_5(x_1853);
return make_real(aux_2608);
}
}


/* sin */double sin___r4_numbers_6_5(obj_t x_61)
{
if(INTEGERP(x_61)){
{
double arg1179_544;
{
long aux_2613;
aux_2613 = (long)CINT(x_61);
arg1179_544 = (double)(aux_2613);
}
return sin(arg1179_544);
}
}
 else {
if(REALP(x_61)){
{
double aux_2619;
aux_2619 = REAL_TO_DOUBLE(x_61);
return sin(aux_2619);
}
}
 else {
FAILURE(string1454___r4_numbers_6_5,string1435___r4_numbers_6_5,x_61);}
}
}


/* _sin */obj_t _sin___r4_numbers_6_5(obj_t env_1854, obj_t x_1855)
{
{
double aux_2623;
aux_2623 = sin___r4_numbers_6_5(x_1855);
return make_real(aux_2623);
}
}


/* cos */double cos___r4_numbers_6_5(obj_t x_62)
{
if(INTEGERP(x_62)){
{
double arg1182_547;
{
long aux_2628;
aux_2628 = (long)CINT(x_62);
arg1182_547 = (double)(aux_2628);
}
return cos(arg1182_547);
}
}
 else {
if(REALP(x_62)){
{
double aux_2634;
aux_2634 = REAL_TO_DOUBLE(x_62);
return cos(aux_2634);
}
}
 else {
FAILURE(string1455___r4_numbers_6_5,string1435___r4_numbers_6_5,x_62);}
}
}


/* _cos */obj_t _cos___r4_numbers_6_5(obj_t env_1856, obj_t x_1857)
{
{
double aux_2638;
aux_2638 = cos___r4_numbers_6_5(x_1857);
return make_real(aux_2638);
}
}


/* tan */double tan___r4_numbers_6_5(obj_t x_63)
{
if(INTEGERP(x_63)){
{
double arg1185_550;
{
long aux_2643;
aux_2643 = (long)CINT(x_63);
arg1185_550 = (double)(aux_2643);
}
return tan(arg1185_550);
}
}
 else {
if(REALP(x_63)){
{
double aux_2649;
aux_2649 = REAL_TO_DOUBLE(x_63);
return tan(aux_2649);
}
}
 else {
FAILURE(string1456___r4_numbers_6_5,string1435___r4_numbers_6_5,x_63);}
}
}


/* _tan */obj_t _tan___r4_numbers_6_5(obj_t env_1858, obj_t x_1859)
{
{
double aux_2653;
aux_2653 = tan___r4_numbers_6_5(x_1859);
return make_real(aux_2653);
}
}


/* asin */double asin___r4_numbers_6_5(obj_t x_64)
{
if(INTEGERP(x_64)){
{
double arg1188_553;
{
long aux_2658;
aux_2658 = (long)CINT(x_64);
arg1188_553 = (double)(aux_2658);
}
return asin(arg1188_553);
}
}
 else {
if(REALP(x_64)){
{
double aux_2664;
aux_2664 = REAL_TO_DOUBLE(x_64);
return asin(aux_2664);
}
}
 else {
FAILURE(string1457___r4_numbers_6_5,string1435___r4_numbers_6_5,x_64);}
}
}


/* _asin */obj_t _asin___r4_numbers_6_5(obj_t env_1860, obj_t x_1861)
{
{
double aux_2668;
aux_2668 = asin___r4_numbers_6_5(x_1861);
return make_real(aux_2668);
}
}


/* acos */double acos___r4_numbers_6_5(obj_t x_65)
{
if(INTEGERP(x_65)){
{
double arg1191_556;
{
long aux_2673;
aux_2673 = (long)CINT(x_65);
arg1191_556 = (double)(aux_2673);
}
return acos(arg1191_556);
}
}
 else {
if(REALP(x_65)){
{
double aux_2679;
aux_2679 = REAL_TO_DOUBLE(x_65);
return acos(aux_2679);
}
}
 else {
FAILURE(string1458___r4_numbers_6_5,string1435___r4_numbers_6_5,x_65);}
}
}


/* _acos */obj_t _acos___r4_numbers_6_5(obj_t env_1862, obj_t x_1863)
{
{
double aux_2683;
aux_2683 = acos___r4_numbers_6_5(x_1863);
return make_real(aux_2683);
}
}


/* atan */double atan___r4_numbers_6_5(obj_t x_66, obj_t y_67)
{
{
obj_t y_558;
if(PAIRP(y_67)){
obj_t y_568;
y_568 = CAR(y_67);
if(INTEGERP(y_568)){
{
double aux_2691;
{
long aux_2692;
aux_2692 = (long)CINT(y_568);
aux_2691 = (double)(aux_2692);
}
y_558 = make_real(aux_2691);
}
}
 else {
if(REALP(y_568)){
y_558 = y_568;
}
 else {
FAILURE(string1459___r4_numbers_6_5,string1435___r4_numbers_6_5,y_568);}
}
}
 else {
y_558 = BFALSE;
}
if(INTEGERP(x_66)){
{
double arg1194_561;
{
long aux_2701;
aux_2701 = (long)CINT(x_66);
arg1194_561 = (double)(aux_2701);
}
{
bool_t test_2704;
if(INTEGERP(y_558)){
test_2704 = ((bool_t)1);
}
 else {
test_2704 = REALP(y_558);
}
if(test_2704){
double aux_2708;
aux_2708 = REAL_TO_DOUBLE(y_558);
return atan2(arg1194_561, aux_2708);
}
 else {
return atan(arg1194_561);
}
}
}
}
 else {
if(REALP(x_66)){
{
bool_t test_2714;
if(INTEGERP(y_558)){
test_2714 = ((bool_t)1);
}
 else {
test_2714 = REALP(y_558);
}
if(test_2714){
double aux_2720;
double aux_2718;
aux_2720 = REAL_TO_DOUBLE(y_558);
aux_2718 = REAL_TO_DOUBLE(x_66);
return atan2(aux_2718, aux_2720);
}
 else {
double aux_2723;
aux_2723 = REAL_TO_DOUBLE(x_66);
return atan(aux_2723);
}
}
}
 else {
FAILURE(string1459___r4_numbers_6_5,string1435___r4_numbers_6_5,x_66);}
}
}
}


/* _atan */obj_t _atan___r4_numbers_6_5(obj_t env_1864, obj_t x_1865, obj_t y_1866)
{
{
double aux_2727;
aux_2727 = atan___r4_numbers_6_5(x_1865, y_1866);
return make_real(aux_2727);
}
}


/* sqrt */double sqrt___r4_numbers_6_5(obj_t x_68)
{
if(INTEGERP(x_68)){
{
double arg1202_572;
{
long aux_2732;
aux_2732 = (long)CINT(x_68);
arg1202_572 = (double)(aux_2732);
}
return sqrt(arg1202_572);
}
}
 else {
if(REALP(x_68)){
{
double aux_2738;
aux_2738 = REAL_TO_DOUBLE(x_68);
return sqrt(aux_2738);
}
}
 else {
FAILURE(string1460___r4_numbers_6_5,string1435___r4_numbers_6_5,x_68);}
}
}


/* _sqrt */obj_t _sqrt___r4_numbers_6_5(obj_t env_1867, obj_t x_1868)
{
{
double aux_2742;
aux_2742 = sqrt___r4_numbers_6_5(x_1868);
return make_real(aux_2742);
}
}


/* expt */obj_t expt___r4_numbers_6_5(obj_t x_69, obj_t y_70)
{
{
bool_t test_2745;
if(REALP(x_69)){
if(REALP(y_70)){
bool_t test_2750;
{
double aux_2751;
aux_2751 = REAL_TO_DOUBLE(x_69);
test_2750 = (aux_2751==((double)0.0));
}
if(test_2750){
double aux_2754;
aux_2754 = REAL_TO_DOUBLE(y_70);
test_2745 = (aux_2754==((double)0.0));
}
 else {
test_2745 = ((bool_t)0);
}
}
 else {
test_2745 = ((bool_t)0);
}
}
 else {
test_2745 = ((bool_t)0);
}
if(test_2745){
return real1461___r4_numbers_6_5;
}
 else {
bool_t test_2757;
if(INTEGERP(x_69)){
test_2757 = INTEGERP(y_70);
}
 else {
test_2757 = ((bool_t)0);
}
if(test_2757){
{
double arg1206_576;
{
double arg1207_577;
double arg1209_578;
{
long aux_2761;
aux_2761 = (long)CINT(x_69);
arg1207_577 = (double)(aux_2761);
}
{
long aux_2764;
aux_2764 = (long)CINT(y_70);
arg1209_578 = (double)(aux_2764);
}
arg1206_576 = pow(arg1207_577, arg1209_578);
}
{
long aux_2768;
{
double aux_2769;
{
obj_t aux_2770;
aux_2770 = make_real(arg1206_576);
aux_2769 = REAL_TO_DOUBLE(aux_2770);
}
aux_2768 = (long)(aux_2769);
}
return BINT(aux_2768);
}
}
}
 else {
if(INTEGERP(x_69)){
if(REALP(y_70)){
{
double arg1213_581;
{
long aux_2779;
aux_2779 = (long)CINT(x_69);
arg1213_581 = (double)(aux_2779);
}
{
double aux_2782;
{
double aux_2783;
aux_2783 = REAL_TO_DOUBLE(y_70);
aux_2782 = pow(arg1213_581, aux_2783);
}
return make_real(aux_2782);
}
}
}
 else {
FAILURE(string1462___r4_numbers_6_5,string1435___r4_numbers_6_5,y_70);}
}
 else {
if(REALP(x_69)){
if(REALP(y_70)){
{
double aux_2792;
{
double aux_2795;
double aux_2793;
aux_2795 = REAL_TO_DOUBLE(y_70);
aux_2793 = REAL_TO_DOUBLE(x_69);
aux_2792 = pow(aux_2793, aux_2795);
}
return make_real(aux_2792);
}
}
 else {
if(INTEGERP(y_70)){
{
double arg1219_585;
{
long aux_2801;
aux_2801 = (long)CINT(y_70);
arg1219_585 = (double)(aux_2801);
}
{
double aux_2804;
{
double aux_2805;
aux_2805 = REAL_TO_DOUBLE(x_69);
aux_2804 = pow(aux_2805, arg1219_585);
}
return make_real(aux_2804);
}
}
}
 else {
FAILURE(string1462___r4_numbers_6_5,string1435___r4_numbers_6_5,y_70);}
}
}
 else {
FAILURE(string1462___r4_numbers_6_5,string1435___r4_numbers_6_5,x_69);}
}
}
}
}
}


/* _expt */obj_t _expt___r4_numbers_6_5(obj_t env_1869, obj_t x_1870, obj_t y_1871)
{
return expt___r4_numbers_6_5(x_1870, y_1871);
}


/* exact->inexact */obj_t exact__inexact_122___r4_numbers_6_5(obj_t z_71)
{
if(INTEGERP(z_71)){
double aux_2814;
{
long aux_2815;
aux_2815 = (long)CINT(z_71);
aux_2814 = (double)(aux_2815);
}
return make_real(aux_2814);
}
 else {
return z_71;
}
}


/* _exact->inexact */obj_t _exact__inexact_16___r4_numbers_6_5(obj_t env_1872, obj_t z_1873)
{
{
obj_t z_1887;
z_1887 = z_1873;
if(INTEGERP(z_1887)){
double aux_2821;
{
long aux_2822;
aux_2822 = (long)CINT(z_1887);
aux_2821 = (double)(aux_2822);
}
return make_real(aux_2821);
}
 else {
return z_1887;
}
}
}


/* inexact->exact */obj_t inexact__exact_80___r4_numbers_6_5(obj_t z_72)
{
if(REALP(z_72)){
long aux_2828;
{
double aux_2829;
aux_2829 = REAL_TO_DOUBLE(z_72);
aux_2828 = (long)(aux_2829);
}
return BINT(aux_2828);
}
 else {
return z_72;
}
}


/* _inexact->exact */obj_t _inexact__exact_215___r4_numbers_6_5(obj_t env_1874, obj_t z_1875)
{
{
obj_t z_1888;
z_1888 = z_1875;
if(REALP(z_1888)){
long aux_2835;
{
double aux_2836;
aux_2836 = REAL_TO_DOUBLE(z_1888);
aux_2835 = (long)(aux_2836);
}
return BINT(aux_2835);
}
 else {
return z_1888;
}
}
}


/* number->string */char * number__string_214___r4_numbers_6_5(obj_t x_73, obj_t radix_74)
{
{
bool_t test1226_592;
{
obj_t obj_1669;
obj_1669 = radix_74;
test1226_592 = NULLP(obj_1669);
}
if(test1226_592){
radix_74 = BINT(((long)10));
}
 else {
obj_t pair_1670;
pair_1670 = radix_74;
radix_74 = CAR(pair_1670);
}
}
if(INTEGERP(x_73)){
{
obj_t list1228_594;
list1228_594 = MAKE_PAIR(radix_74, BNIL);
return integer__string_135___r4_numbers_6_5_fixnum((long)CINT(x_73), list1228_594);
}
}
 else {
if(REALP(x_73)){
{
double aux_2851;
aux_2851 = REAL_TO_DOUBLE(x_73);
return real_to_string(aux_2851);
}
}
 else {
FAILURE(string1463___r4_numbers_6_5,string1464___r4_numbers_6_5,x_73);}
}
}


/* _number->string */obj_t _number__string_61___r4_numbers_6_5(obj_t env_1876, obj_t x_1877, obj_t radix_1878)
{
{
char * aux_2855;
aux_2855 = number__string_214___r4_numbers_6_5(x_1877, radix_1878);
return string_to_bstring(aux_2855);
}
}


/* string->number */obj_t string__number_104___r4_numbers_6_5(obj_t x_75, obj_t radix_76)
{
{
obj_t x_603;
{
bool_t test_2858;
x_603 = x_75;
{
long i_605;
{
long aux_2896;
aux_2896 = STRING_LENGTH(x_603);
i_605 = (aux_2896-((long)1));
}
loop_606:
if((i_605==((long)-1))){
test_2858 = ((bool_t)1);
}
 else {
bool_t test_2861;
{
unsigned char aux_2862;
aux_2862 = STRING_REF(x_603, i_605);
test_2861 = (aux_2862==((unsigned char)'-'));
}
if(test_2861){
test_2858 = (i_605==((long)0));
}
 else {
bool_t test_2866;
{
bool_t test_2867;
{
unsigned char aux_2868;
aux_2868 = STRING_REF(x_603, i_605);
test_2867 = (aux_2868>=((unsigned char)'0'));
}
if(test_2867){
unsigned char aux_2871;
aux_2871 = STRING_REF(x_603, i_605);
test_2866 = (aux_2871<=((unsigned char)'9'));
}
 else {
test_2866 = ((bool_t)0);
}
}
if(test_2866){
{
long i_2874;
i_2874 = (i_605-((long)1));
i_605 = i_2874;
goto loop_606;
}
}
 else {
bool_t test_2876;
{
bool_t test_2877;
{
unsigned char aux_2878;
aux_2878 = STRING_REF(x_603, i_605);
test_2877 = (aux_2878>=((unsigned char)'a'));
}
if(test_2877){
unsigned char aux_2881;
aux_2881 = STRING_REF(x_603, i_605);
test_2876 = (aux_2881<=((unsigned char)'f'));
}
 else {
test_2876 = ((bool_t)0);
}
}
if(test_2876){
{
long i_2884;
i_2884 = (i_605-((long)1));
i_605 = i_2884;
goto loop_606;
}
}
 else {
bool_t test_2886;
{
bool_t test_2887;
{
unsigned char aux_2888;
aux_2888 = STRING_REF(x_603, i_605);
test_2887 = (aux_2888>=((unsigned char)'A'));
}
if(test_2887){
unsigned char aux_2891;
aux_2891 = STRING_REF(x_603, i_605);
test_2886 = (aux_2891<=((unsigned char)'F'));
}
 else {
test_2886 = ((bool_t)0);
}
}
if(test_2886){
{
long i_2894;
i_2894 = (i_605-((long)1));
i_605 = i_2894;
goto loop_606;
}
}
 else {
test_2858 = ((bool_t)0);
}
}
}
}
}
}
if(test_2858){
obj_t runner1235_600;
runner1235_600 = MAKE_PAIR(x_75, radix_76);
{
char * aux1234_599;
{
obj_t pair_1679;
pair_1679 = runner1235_600;
{
obj_t aux_2900;
aux_2900 = CAR(pair_1679);
aux1234_599 = BSTRING_TO_STRING(aux_2900);
}
}
{
obj_t pair_1680;
pair_1680 = runner1235_600;
runner1235_600 = CDR(pair_1680);
}
{
long aux_2904;
aux_2904 = string__integer_39___r4_numbers_6_5_fixnum(aux1234_599, runner1235_600);
return BINT(aux_2904);
}
}
}
 else {
obj_t runner1237_602;
runner1237_602 = MAKE_PAIR(x_75, radix_76);
{
char * aux1236_601;
{
obj_t pair_1683;
pair_1683 = runner1237_602;
{
obj_t aux_2908;
aux_2908 = CAR(pair_1683);
aux1236_601 = BSTRING_TO_STRING(aux_2908);
}
}
{
double aux_2911;
aux_2911 = strtod(aux1236_601, ((long)0));
return make_real(aux_2911);
}
}
}
}
}
}


/* _string->number */obj_t _string__number_250___r4_numbers_6_5(obj_t env_1879, obj_t x_1880, obj_t radix_1881)
{
return string__number_104___r4_numbers_6_5(x_1880, radix_1881);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_numbers_6_5()
{
return module_initialization_70___error(((long)0), "__R4_NUMBERS_6_5");
}

