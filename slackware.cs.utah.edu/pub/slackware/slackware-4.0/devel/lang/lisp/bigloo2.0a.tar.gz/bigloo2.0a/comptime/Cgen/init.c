/*===========================================================================*/
/*   (Cgen/init.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern obj_t _long__149_type_cache;
static obj_t method_init_76_cgen_init();
extern obj_t _module_checksum__252_module_module;
extern obj_t _obj__252_type_cache;
extern obj_t module_initialization_70_cgen_init(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_ast_occur(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t _unsafe_version__81_engine_param;
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_id_110_module_module(obj_t);
static obj_t imported_modules_init_94_cgen_init();
extern node_t coerce__182_coerce_coerce(node_t, type_t);
static obj_t _make_module_init_166_cgen_init(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cgen_init();
extern obj_t occur_node_in__115_ast_occur(node_t, global_t);
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t _unsafe_type__146_engine_param;
extern obj_t unit_init_calls_56_ast_unit();
extern obj_t open_input_string(obj_t);
extern obj_t make_module_init_70_cgen_init();
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern global_t def_global_svar__184_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t _string__3_type_cache;
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cgen_init = BUNSPEC;
static obj_t cnst_init_137_cgen_init();
static obj_t __cnst[16];

DEFINE_EXPORT_PROCEDURE(make_module_init_env_79_cgen_init, _make_module_init_166_cgen_init1642, _make_module_init_166_cgen_init, 0L, 0);
DEFINE_STRING(string1635_cgen_init, string1635_cgen_init1643, "EXPORT MODULE-INITIALIZATION SFUN (CHECKSUM FROM) VALUE FROM MODULE-INIT-ERROR CHECKSUM PRAGMA::BOOL SET! BEGIN REQUIRE-INITIALIZATION IF NOW MODULE-INITALIZATION REQUIRE-INITIALIZATION::OBJ ", 191);
DEFINE_STRING(string1634_cgen_init, string1634_cgen_init1644, "((($1) & ($2)) == ($1))", 23);


/* module-initialization */ obj_t 
module_initialization_70_cgen_init(long checksum_1138, char *from_1139)
{
   if (CBOOL(require_initialization_114_cgen_init))
     {
	require_initialization_114_cgen_init = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_init();
	cnst_init_137_cgen_init();
	imported_modules_init_94_cgen_init();
	method_init_76_cgen_init();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_init()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CGEN_INIT");
   module_initialization_70___reader(((long) 0), "CGEN_INIT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_init()
{
   {
      obj_t cnst_port_138_1130;
      cnst_port_138_1130 = open_input_string(string1635_cgen_init);
      {
	 long i_1131;
	 i_1131 = ((long) 15);
       loop_1132:
	 {
	    bool_t test1636_1133;
	    test1636_1133 = (i_1131 == ((long) -1));
	    if (test1636_1133)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1638_1134;
		    {
		       obj_t list1639_1135;
		       {
			  obj_t arg1640_1136;
			  arg1640_1136 = BNIL;
			  list1639_1135 = MAKE_PAIR(cnst_port_138_1130, arg1640_1136);
		       }
		       arg1638_1134 = read___reader(list1639_1135);
		    }
		    CNST_TABLE_SET(i_1131, arg1638_1134);
		 }
		 {
		    int aux_1137;
		    {
		       long aux_1155;
		       aux_1155 = (i_1131 - ((long) 1));
		       aux_1137 = (int) (aux_1155);
		    }
		    {
		       long i_1158;
		       i_1158 = (long) (aux_1137);
		       i_1131 = i_1158;
		       goto loop_1132;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-module-init */ obj_t 
make_module_init_70_cgen_init()
{
   {
      global_t req_703;
      req_703 = def_global_svar__184_ast_glo_def_117(CNST_TABLE_REF(((long) 0)), _module__166_module_module, CNST_TABLE_REF(((long) 1)), CNST_TABLE_REF(((long) 2)));
      {
	 obj_t ubody_704;
	 {
	    obj_t arg1499_758;
	    obj_t arg1500_759;
	    obj_t arg1501_760;
	    arg1499_758 = CNST_TABLE_REF(((long) 3));
	    arg1500_759 = CNST_TABLE_REF(((long) 4));
	    {
	       obj_t arg1511_767;
	       obj_t arg1513_768;
	       obj_t arg1514_769;
	       arg1511_767 = CNST_TABLE_REF(((long) 5));
	       {
		  obj_t arg1518_773;
		  obj_t arg1519_774;
		  arg1518_773 = CNST_TABLE_REF(((long) 6));
		  arg1519_774 = CNST_TABLE_REF(((long) 4));
		  {
		     obj_t list1523_776;
		     {
			obj_t arg1524_777;
			{
			   obj_t arg1525_778;
			   arg1525_778 = MAKE_PAIR(BNIL, BNIL);
			   arg1524_777 = MAKE_PAIR(BFALSE, arg1525_778);
			}
			list1523_776 = MAKE_PAIR(arg1519_774, arg1524_777);
		     }
		     arg1513_768 = cons__138___r4_pairs_and_lists_6_3(arg1518_773, list1523_776);
		  }
	       }
	       {
		  obj_t arg1527_780;
		  obj_t arg1528_781;
		  arg1527_780 = unit_init_calls_56_ast_unit();
		  {
		     obj_t list1530_783;
		     list1530_783 = MAKE_PAIR(BNIL, BNIL);
		     arg1528_781 = cons__138___r4_pairs_and_lists_6_3(BUNSPEC, list1530_783);
		  }
		  arg1514_769 = append_2_18___r4_pairs_and_lists_6_3(arg1527_780, arg1528_781);
	       }
	       {
		  obj_t list1515_770;
		  {
		     obj_t arg1516_771;
		     arg1516_771 = MAKE_PAIR(arg1514_769, BNIL);
		     list1515_770 = MAKE_PAIR(arg1513_768, arg1516_771);
		  }
		  arg1501_760 = cons__138___r4_pairs_and_lists_6_3(arg1511_767, list1515_770);
	       }
	    }
	    {
	       obj_t list1503_762;
	       {
		  obj_t arg1504_763;
		  {
		     obj_t arg1505_764;
		     {
			obj_t arg1507_765;
			arg1507_765 = MAKE_PAIR(BNIL, BNIL);
			arg1505_764 = MAKE_PAIR(BUNSPEC, arg1507_765);
		     }
		     arg1504_763 = MAKE_PAIR(arg1501_760, arg1505_764);
		  }
		  list1503_762 = MAKE_PAIR(arg1500_759, arg1504_763);
	       }
	       ubody_704 = cons__138___r4_pairs_and_lists_6_3(arg1499_758, list1503_762);
	    }
	 }
	 {
	    obj_t body_705;
	    if (CBOOL(_unsafe_version__81_engine_param))
	      {
		 body_705 = ubody_704;
	      }
	    else
	      {
		 obj_t arg1469_732;
		 obj_t arg1470_733;
		 obj_t arg1471_734;
		 arg1469_732 = CNST_TABLE_REF(((long) 3));
		 {
		    obj_t arg1479_741;
		    obj_t arg1481_743;
		    arg1479_741 = CNST_TABLE_REF(((long) 7));
		    arg1481_743 = CNST_TABLE_REF(((long) 8));
		    {
		       obj_t list1484_745;
		       {
			  obj_t arg1485_746;
			  {
			     obj_t arg1486_747;
			     {
				obj_t arg1487_748;
				arg1487_748 = MAKE_PAIR(BNIL, BNIL);
				arg1486_747 = MAKE_PAIR(_module_checksum__252_module_module, arg1487_748);
			     }
			     arg1485_746 = MAKE_PAIR(arg1481_743, arg1486_747);
			  }
			  list1484_745 = MAKE_PAIR(string1634_cgen_init, arg1485_746);
		       }
		       arg1470_733 = cons__138___r4_pairs_and_lists_6_3(arg1479_741, list1484_745);
		    }
		 }
		 {
		    obj_t arg1489_750;
		    obj_t arg1490_751;
		    obj_t arg1491_752;
		    arg1489_750 = CNST_TABLE_REF(((long) 9));
		    {
		       obj_t symbol_1122;
		       symbol_1122 = _module__166_module_module;
		       arg1490_751 = SYMBOL_TO_STRING(symbol_1122);
		    }
		    arg1491_752 = CNST_TABLE_REF(((long) 10));
		    {
		       obj_t list1495_754;
		       {
			  obj_t arg1496_755;
			  {
			     obj_t arg1497_756;
			     arg1497_756 = MAKE_PAIR(BNIL, BNIL);
			     arg1496_755 = MAKE_PAIR(arg1491_752, arg1497_756);
			  }
			  list1495_754 = MAKE_PAIR(arg1490_751, arg1496_755);
		       }
		       arg1471_734 = cons__138___r4_pairs_and_lists_6_3(arg1489_750, list1495_754);
		    }
		 }
		 {
		    obj_t list1474_736;
		    {
		       obj_t arg1475_737;
		       {
			  obj_t arg1476_738;
			  {
			     obj_t arg1477_739;
			     arg1477_739 = MAKE_PAIR(BNIL, BNIL);
			     arg1476_738 = MAKE_PAIR(arg1471_734, arg1477_739);
			  }
			  arg1475_737 = MAKE_PAIR(ubody_704, arg1476_738);
		       }
		       list1474_736 = MAKE_PAIR(arg1470_733, arg1475_737);
		    }
		    body_705 = cons__138___r4_pairs_and_lists_6_3(arg1469_732, list1474_736);
		 }
	      }
	    {
	       local_t cvar_706;
	       cvar_706 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 8)), (type_t) (_long__149_type_cache));
	       {
		  local_t nvar_707;
		  nvar_707 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 10)), (type_t) (_string__3_type_cache));
		  {
		     node_t node_708;
		     {
			obj_t __720;
			obj_t unsafe_type_48_721;
			__720 = ____74_type_cache;
			unsafe_type_48_721 = _unsafe_type__146_engine_param;
			____74_type_cache = _obj__252_type_cache;
			_unsafe_type__146_engine_param = BTRUE;
			{
			   node_t node_722;
			   {
			      node_t arg1458_723;
			      {
				 obj_t arg1460_724;
				 obj_t arg1463_726;
				 {
				    obj_t list1464_727;
				    {
				       obj_t arg1465_728;
				       {
					  obj_t aux_1213;
					  aux_1213 = (obj_t) (nvar_707);
					  arg1465_728 = MAKE_PAIR(aux_1213, BNIL);
				       }
				       {
					  obj_t aux_1216;
					  aux_1216 = (obj_t) (cvar_706);
					  list1464_727 = MAKE_PAIR(aux_1216, arg1465_728);
				       }
				    }
				    arg1460_724 = list1464_727;
				 }
				 arg1463_726 = CNST_TABLE_REF(((long) 11));
				 arg1458_723 = sexp__node_235_ast_sexp(body_705, arg1460_724, BNIL, arg1463_726);
			      }
			      node_722 = coerce__182_coerce_coerce(arg1458_723, (type_t) (_obj__252_type_cache));
			   }
			   ____74_type_cache = __720;
			   _unsafe_type__146_engine_param = unsafe_type_48_721;
			   node_708 = node_722;
			}
		     }
		     {
			global_t init_709;
			{
			   obj_t arg1444_711;
			   obj_t arg1446_712;
			   obj_t arg1448_713;
			   obj_t arg1449_714;
			   obj_t arg1450_715;
			   obj_t arg1453_716;
			   arg1444_711 = module_initialization_id_110_module_module(_module__166_module_module);
			   arg1446_712 = CNST_TABLE_REF(((long) 12));
			   {
			      obj_t list1454_717;
			      {
				 obj_t arg1455_718;
				 {
				    obj_t aux_1225;
				    aux_1225 = (obj_t) (nvar_707);
				    arg1455_718 = MAKE_PAIR(aux_1225, BNIL);
				 }
				 {
				    obj_t aux_1228;
				    aux_1228 = (obj_t) (cvar_706);
				    list1454_717 = MAKE_PAIR(aux_1228, arg1455_718);
				 }
			      }
			      arg1448_713 = list1454_717;
			   }
			   arg1449_714 = CNST_TABLE_REF(((long) 13));
			   arg1450_715 = CNST_TABLE_REF(((long) 14));
			   arg1453_716 = CNST_TABLE_REF(((long) 2));
			   init_709 = def_global_sfun__93_ast_glo_def_117(arg1444_711, arg1446_712, arg1448_713, _module__166_module_module, arg1449_714, arg1450_715, arg1453_716, (obj_t) (node_708));
			}
			{
			   {
			      obj_t arg1443_710;
			      arg1443_710 = CNST_TABLE_REF(((long) 15));
			      ((((global_t) CREF(init_709))->import) = ((obj_t) arg1443_710), BUNSPEC);
			   }
			   {
			      type_t val1075_1128;
			      val1075_1128 = (type_t) (_obj__252_type_cache);
			      ((((global_t) CREF(init_709))->type) = ((type_t) val1075_1128), BUNSPEC);
			   }
			   occur_node_in__115_ast_occur(node_708, init_709);
			   return (obj_t) (init_709);
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-module-init */ obj_t 
_make_module_init_166_cgen_init(obj_t env_1129)
{
   return make_module_init_70_cgen_init();
}


/* method-init */ obj_t 
method_init_76_cgen_init()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_init()
{
   module_initialization_70_engine_param(((long) 0), "CGEN_INIT");
   module_initialization_70_module_module(((long) 0), "CGEN_INIT");
   module_initialization_70_tools_shape(((long) 0), "CGEN_INIT");
   module_initialization_70_type_type(((long) 0), "CGEN_INIT");
   module_initialization_70_type_cache(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_var(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_node(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_env(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_sexp(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_local(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_glo_def_117(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_unit(((long) 0), "CGEN_INIT");
   module_initialization_70_ast_occur(((long) 0), "CGEN_INIT");
   return module_initialization_70_coerce_coerce(((long) 0), "CGEN_INIT");
}
