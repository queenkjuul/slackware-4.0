/*===========================================================================*/
/*   (Tools/license.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t bigloo_license_175_tools_license();
extern obj_t module_initialization_70_tools_license(long, char *);
static obj_t _bigloo_license_172_tools_license(obj_t);
static obj_t require_initialization_114_tools_license = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(bigloo_license_env_176_tools_license, _bigloo_license_172_tools_license1004, _bigloo_license_172_tools_license, 0L, 0);
DEFINE_STRING(string1002_tools_license, string1002_tools_license1005, " --------------------------------------------------------------------\n   A pratical implementation for the Scheme programming language     \n                                                                     \n                                    ,--^,                            \n                              _ ___/ /|/                             \n                          ,;'( )__, ) '                              \n                         ;;  //   L__.                               \n                         '   \\   /  '                               \n                              ^   ^                                  \n                                                                     \n   Copyright (c) 1992-1999 Manuel Serrano                            \n                                                                     \n     Bug descriptions, use reports, comments or suggestions are      \n     welcome. Send them to                                           \n       bigloo-request@kaolin.u"
   "nice.fr                                \n       http://kaolin.unice.fr/bigloo                                 \n                                                                     \n   This program is free software; you can redistribute it            \n   and/or modify it under the terms of the GNU General Public        \n   License as published by the Free Software Foundation; either      \n   version 2 of the License, or (at your option) any later version.  \n                                                                     \n   This program is distributed in the hope that it will be useful,   \n   but WITHOUT ANY WARRANTY; without even the implied warranty of    \n   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     \n   GNU General Public License for more details.                      \n                                                                     \n   You should have received a copy of the GNU General Public         \n   License along with this program; if not, write to the Fre"
   "e        \n   Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,   \n   MA 02111-1307, USA.                                               \n-------------------------------------------------------------------- ", 2238);


/* module-initialization */ obj_t 
module_initialization_70_tools_license(long checksum_2, char *from_3)
{
   if (CBOOL(require_initialization_114_tools_license))
     {
	require_initialization_114_tools_license = BBOOL(((bool_t) 0));
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* bigloo-license */ obj_t 
bigloo_license_175_tools_license()
{
   return string1002_tools_license;
}


/* _bigloo-license */ obj_t 
_bigloo_license_172_tools_license(obj_t env_1)
{
   return bigloo_license_175_tools_license();
}
