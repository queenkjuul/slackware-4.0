/*===========================================================================*/
/*   (Engine/signals.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t _verbose__1_engine_param;
extern obj_t signal___os(int, obj_t);
extern obj_t module_initialization_70_engine_signals(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t _install_compiler_signals__36_engine_signals(obj_t);
static obj_t imported_modules_init_94_engine_signals();
static obj_t kill_my_self_117_engine_signals(obj_t, obj_t);
static obj_t library_modules_init_112_engine_signals();
extern obj_t install_compiler_signals__223_engine_signals();
static obj_t require_initialization_114_engine_signals = BUNSPEC;
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE(proc1004_engine_signals, kill_my_self_117_engine_signals1010, kill_my_self_117_engine_signals, 0L, 1);
DEFINE_EXPORT_PROCEDURE(install_compiler_signals__env_126_engine_signals, _install_compiler_signals__36_engine_signals1011, _install_compiler_signals__36_engine_signals, 0L, 0);
DEFINE_STRING(string1008_engine_signals, string1008_engine_signals1012, "aborting", 8);
DEFINE_STRING(string1007_engine_signals, string1007_engine_signals1013, "internal error", 14);
DEFINE_STRING(string1006_engine_signals, string1006_engine_signals1014, "aborting...", 11);
DEFINE_STRING(string1005_engine_signals, string1005_engine_signals1015, "Illegal signal caught", 21);


/* module-initialization */ obj_t 
module_initialization_70_engine_signals(long checksum_12, char *from_13)
{
   if (CBOOL(require_initialization_114_engine_signals))
     {
	require_initialization_114_engine_signals = BBOOL(((bool_t) 0));
	library_modules_init_112_engine_signals();
	imported_modules_init_94_engine_signals();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_engine_signals()
{
   module_initialization_70___os(((long) 0), "ENGINE_SIGNALS");
   module_initialization_70___error(((long) 0), "ENGINE_SIGNALS");
   return BUNSPEC;
}


/* install-compiler-signals! */ obj_t 
install_compiler_signals__223_engine_signals()
{
   {
      obj_t kill_my_self_117_8;
      kill_my_self_117_8 = proc1004_engine_signals;
      signal___os(SIGFPE, kill_my_self_117_8);
      signal___os(SIGILL, kill_my_self_117_8);
      signal___os(SIGBUS, kill_my_self_117_8);
      return signal___os(SIGSEGV, kill_my_self_117_8);
   }
}


/* _install-compiler-signals! */ obj_t 
_install_compiler_signals__36_engine_signals(obj_t env_9)
{
   return install_compiler_signals__223_engine_signals();
}


/* kill-my-self */ obj_t 
kill_my_self_117_engine_signals(obj_t env_10, obj_t n_11)
{
   {
      obj_t n_2;
      n_2 = n_11;
      {
	 bool_t test1003_4;
	 {
	    long n1_6;
	    n1_6 = (long) CINT(_verbose__1_engine_param);
	    test1003_4 = (n1_6 > ((long) 0));
	 }
	 if (test1003_4)
	   {
	      notify_error_43___error(string1005_engine_signals, n_2, string1006_engine_signals);
	   }
	 else
	   {
	      notify_error_43___error(string1007_engine_signals, string1008_engine_signals, BFALSE);
	   }
      }
      return exit_bigloo_229_init_main(BINT(((long) -1)));
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_engine_signals()
{
   module_initialization_70_init_main(((long) 0), "ENGINE_SIGNALS");
   return module_initialization_70_engine_param(((long) 0), "ENGINE_SIGNALS");
}
