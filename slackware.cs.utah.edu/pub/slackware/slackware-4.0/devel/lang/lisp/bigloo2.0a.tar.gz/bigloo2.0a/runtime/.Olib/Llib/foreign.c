/*===========================================================================*/
/*   (Llib/foreign.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _string_null_1118_25___foreign(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _foreign__107___foreign(obj_t, obj_t);
static obj_t symbol1134___foreign = BUNSPEC;
static obj_t symbol1133___foreign = BUNSPEC;
static obj_t symbol1129___foreign = BUNSPEC;
static obj_t symbol1130___foreign = BUNSPEC;
static obj_t symbol1125___foreign = BUNSPEC;
extern bool_t foreign__213___foreign(obj_t);
extern bool_t foreign_null__229___foreign(obj_t);
static obj_t _foreign_null__100___foreign(obj_t, obj_t);
extern bool_t string_null__17___foreign(char *);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___foreign(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _obj__cobj_187___foreign(obj_t, obj_t);
static obj_t imported_modules_init_94___foreign();
extern long obj__cobj_132___foreign(obj_t);
static obj_t require_initialization_114___foreign = BUNSPEC;
static obj_t cnst_init_137___foreign();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( foreign__env_36___foreign, _foreign__107___foreign1136, _foreign__107___foreign, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string_null__env_195___foreign, _string_null_1118_25___foreign1137, _string_null_1118_25___foreign, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( foreign_null__env_218___foreign, _foreign_null__100___foreign1138, _foreign_null__100___foreign, 0L, 1 );
DEFINE_STRING( string1132___foreign, string1132___foreign1139, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/foreign.scm", 60 );
DEFINE_STRING( string1131___foreign, string1131___foreign1140, "STRING", 6 );
DEFINE_STRING( string1128___foreign, string1128___foreign1141, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1127___foreign, string1127___foreign1142, "not a foreign object", 20 );
DEFINE_STRING( string1126___foreign, string1126___foreign1143, "foreign-null?", 13 );
DEFINE_EXPORT_PROCEDURE( obj__cobj_env_104___foreign, _obj__cobj_187___foreign1144, _obj__cobj_187___foreign, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___foreign(long checksum_347, char * from_348)
{
if(CBOOL(require_initialization_114___foreign)){
require_initialization_114___foreign = BBOOL(((bool_t)0));
cnst_init_137___foreign();
imported_modules_init_94___foreign();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___foreign()
{
symbol1125___foreign = string_to_symbol("FOREIGN-NULL?");
symbol1129___foreign = string_to_symbol("STRING-NULL?");
symbol1130___foreign = string_to_symbol("_STRING-NULL?1118");
symbol1133___foreign = string_to_symbol("OBJ->COBJ");
return (symbol1134___foreign = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* foreign? */bool_t foreign__213___foreign(obj_t obj_1)
{
return FOREIGNP(obj_1);
}


/* _foreign? */obj_t _foreign__107___foreign(obj_t env_317, obj_t obj_318)
{
{
bool_t aux_360;
{
obj_t obj_331;
obj_331 = obj_318;
aux_360 = FOREIGNP(obj_331);
}
return BBOOL(aux_360);
}
}


/* foreign-null? */bool_t foreign_null__229___foreign(obj_t obj_2)
{
{
obj_t symbol1111_332;
symbol1111_332 = symbol1125___foreign;
{
PUSH_TRACE(symbol1111_332);
BUNSPEC;
{
bool_t aux1110_333;
if(FOREIGNP(obj_2)){
aux1110_333 = FOREIGN_NULLP(obj_2);
}
 else {
obj_t aux_367;
aux_367 = debug_error_location_199___error(string1126___foreign, string1127___foreign, obj_2, string1128___foreign, BINT(((long)7610)));
aux1110_333 = CBOOL(aux_367);
}
POP_TRACE();
return aux1110_333;
}
}
}
}


/* _foreign-null? */obj_t _foreign_null__100___foreign(obj_t env_319, obj_t obj_320)
{
{
bool_t aux_372;
{
obj_t obj_334;
obj_334 = obj_320;
{
obj_t symbol1111_335;
symbol1111_335 = symbol1125___foreign;
{
PUSH_TRACE(symbol1111_335);
BUNSPEC;
{
bool_t aux1110_336;
if(FOREIGNP(obj_334)){
aux1110_336 = FOREIGN_NULLP(obj_334);
}
 else {
obj_t aux_377;
aux_377 = debug_error_location_199___error(string1126___foreign, string1127___foreign, obj_334, string1128___foreign, BINT(((long)7610)));
aux1110_336 = CBOOL(aux_377);
}
POP_TRACE();
aux_372 = aux1110_336;
}
}
}
}
return BBOOL(aux_372);
}
}


/* string-null? */bool_t string_null__17___foreign(char * obj_3)
{
{
obj_t symbol1113_337;
symbol1113_337 = symbol1129___foreign;
{
PUSH_TRACE(symbol1113_337);
BUNSPEC;
{
bool_t aux1112_338;
aux1112_338 = (obj_3 == 0L);
POP_TRACE();
return aux1112_338;
}
}
}
}


/* _string-null?1118 */obj_t _string_null_1118_25___foreign(obj_t env_321, obj_t obj_322)
{
{
bool_t aux_386;
{
char * obj_339;
{
obj_t aux_387;
if(STRINGP(obj_322)){
aux_387 = obj_322;
}
 else {
bigloo_type_error_location_103___error(symbol1130___foreign, string1131___foreign, obj_322, string1132___foreign, BINT(((long)3209)));
exit( -1 );}
obj_339 = BSTRING_TO_STRING(aux_387);
}
{
obj_t symbol1113_340;
symbol1113_340 = symbol1129___foreign;
{
PUSH_TRACE(symbol1113_340);
BUNSPEC;
{
bool_t aux1112_341;
aux1112_341 = (obj_339 == 0L);
POP_TRACE();
aux_386 = aux1112_341;
}
}
}
}
return BBOOL(aux_386);
}
}


/* obj->cobj */long obj__cobj_132___foreign(obj_t obj_4)
{
{
obj_t symbol1115_342;
symbol1115_342 = symbol1133___foreign;
{
PUSH_TRACE(symbol1115_342);
BUNSPEC;
{
long aux1114_343;
aux1114_343 = obj_to_cobj(obj_4);
POP_TRACE();
return aux1114_343;
}
}
}
}


/* _obj->cobj */obj_t _obj__cobj_187___foreign(obj_t env_323, obj_t obj_324)
{
{
long aux_401;
{
obj_t obj_344;
obj_344 = obj_324;
{
obj_t symbol1115_345;
symbol1115_345 = symbol1133___foreign;
{
PUSH_TRACE(symbol1115_345);
BUNSPEC;
{
long aux1114_346;
aux1114_346 = obj_to_cobj(obj_344);
POP_TRACE();
aux_401 = aux1114_346;
}
}
}
}
return (obj_t)(aux_401);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___foreign()
{
{
obj_t symbol1117_315;
symbol1117_315 = symbol1134___foreign;
{
PUSH_TRACE(symbol1117_315);
BUNSPEC;
{
obj_t aux1116_316;
aux1116_316 = module_initialization_70___error(((long)0), "__FOREIGN");
POP_TRACE();
return aux1116_316;
}
}
}
}

