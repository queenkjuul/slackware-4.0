/*===========================================================================*/
/*   (Coerce/apply.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_coerce_apply();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t location_full_fname_231_tools_location(obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t current_function_76_tools_error();
extern obj_t module_initialization_70_coerce_apply(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_coerce_convert(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t _unsafe_arity__240_engine_param;
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
static obj_t imported_modules_init_94_coerce_apply();
extern obj_t app_ly_162_ast_node;
extern node_t coerce__182_coerce_coerce(node_t, type_t);
static obj_t library_modules_init_112_coerce_apply();
static obj_t _coerce_1764_213_coerce_coerce(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_coerce_apply();
extern obj_t _unsafe_type__146_engine_param;
extern obj_t open_input_string(obj_t);
extern node_t top_level_sexp__node_204_ast_sexp(obj_t, obj_t);
extern node_t convert__122_coerce_convert(node_t, type_t, type_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t shape_tools_shape(obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t read___reader(obj_t);
static node_t make_error_node_135_coerce_apply(obj_t, obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t coerce__app_ly_232_coerce_apply(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_coerce_apply = BUNSPEC;
static obj_t cnst_init_137_coerce_apply();
static obj_t __cnst[16];

DEFINE_STATIC_PROCEDURE(proc1766_coerce_apply, coerce__app_ly_232_coerce_apply1773, coerce__app_ly_232_coerce_apply, 0L, 2);
DEFINE_STRING(string1767_coerce_apply, string1767_coerce_apply1774, "CORRECT-ARITY? IF LENGTH ::LONG LET LEN VAL FUN _ FAILURE QUOTE __ERROR ERROR/LOCATION @ BEGIN LOCATION ", 104);
DEFINE_STRING(string1765_coerce_apply, string1765_coerce_apply1775, "Wrong number of arguments", 25);
extern obj_t coerce__env_127_coerce_coerce;


/* module-initialization */ obj_t 
module_initialization_70_coerce_apply(long checksum_1390, char *from_1391)
{
   if (CBOOL(require_initialization_114_coerce_apply))
     {
	require_initialization_114_coerce_apply = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_apply();
	cnst_init_137_coerce_apply();
	imported_modules_init_94_coerce_apply();
	method_init_76_coerce_apply();
	toplevel_init_63_coerce_apply();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_apply()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "COERCE_APPLY");
   module_initialization_70___object(((long) 0), "COERCE_APPLY");
   module_initialization_70___reader(((long) 0), "COERCE_APPLY");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "COERCE_APPLY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_apply()
{
   {
      obj_t cnst_port_138_1382;
      cnst_port_138_1382 = open_input_string(string1767_coerce_apply);
      {
	 long i_1383;
	 i_1383 = ((long) 15);
       loop_1384:
	 {
	    bool_t test1768_1385;
	    test1768_1385 = (i_1383 == ((long) -1));
	    if (test1768_1385)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1769_1386;
		    {
		       obj_t list1770_1387;
		       {
			  obj_t arg1771_1388;
			  arg1771_1388 = BNIL;
			  list1770_1387 = MAKE_PAIR(cnst_port_138_1382, arg1771_1388);
		       }
		       arg1769_1386 = read___reader(list1770_1387);
		    }
		    CNST_TABLE_SET(i_1383, arg1769_1386);
		 }
		 {
		    int aux_1389;
		    {
		       long aux_1410;
		       aux_1410 = (i_1383 - ((long) 1));
		       aux_1389 = (int) (aux_1410);
		    }
		    {
		       long i_1413;
		       i_1413 = (long) (aux_1389);
		       i_1383 = i_1413;
		       goto loop_1384;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_apply()
{
   return BUNSPEC;
}


/* make-error-node */ node_t 
make_error_node_135_coerce_apply(obj_t error_msg_180_17, obj_t loc_18, obj_t to_19)
{
   {
      obj_t ut_728;
      ut_728 = _unsafe_type__146_engine_param;
      _unsafe_type__146_engine_param = BTRUE;
      {
	 node_t node_729;
	 {
	    node_t arg1463_730;
	    {
	       obj_t arg1464_731;
	       {
		  bool_t test1465_732;
		  {
		     bool_t test1557_809;
		     {
			bool_t test1558_810;
			{
			   long n1_1253;
			   n1_1253 = (long) CINT(_bdb_debug__1_engine_param);
			   test1558_810 = (n1_1253 > ((long) 0));
			}
			if (test1558_810)
			  {
			     test1557_809 = ((bool_t) 1);
			  }
			else
			  {
			     long n1_1255;
			     n1_1255 = (long) CINT(_compiler_debug__134_engine_param);
			     test1557_809 = (n1_1255 > ((long) 0));
			  }
		     }
		     if (test1557_809)
		       {
			  if (STRUCTP(loc_18))
			    {
			       obj_t aux_1425;
			       obj_t aux_1423;
			       aux_1425 = CNST_TABLE_REF(((long) 0));
			       aux_1423 = STRUCT_KEY(loc_18);
			       test1465_732 = (aux_1423 == aux_1425);
			    }
			  else
			    {
			       test1465_732 = ((bool_t) 0);
			    }
		       }
		     else
		       {
			  test1465_732 = ((bool_t) 0);
		       }
		  }
		  if (test1465_732)
		    {
		       obj_t arg1466_733;
		       obj_t arg1467_734;
		       obj_t arg1468_735;
		       arg1466_733 = CNST_TABLE_REF(((long) 1));
		       {
			  obj_t arg1475_741;
			  obj_t arg1476_742;
			  obj_t arg1478_744;
			  obj_t arg1479_745;
			  {
			     obj_t arg1489_754;
			     obj_t arg1490_755;
			     obj_t arg1491_756;
			     arg1489_754 = CNST_TABLE_REF(((long) 2));
			     arg1490_755 = CNST_TABLE_REF(((long) 3));
			     arg1491_756 = CNST_TABLE_REF(((long) 4));
			     {
				obj_t list1495_758;
				{
				   obj_t arg1496_759;
				   {
				      obj_t arg1497_760;
				      arg1497_760 = MAKE_PAIR(BNIL, BNIL);
				      arg1496_759 = MAKE_PAIR(arg1491_756, arg1497_760);
				   }
				   list1495_758 = MAKE_PAIR(arg1490_755, arg1496_759);
				}
				arg1475_741 = cons__138___r4_pairs_and_lists_6_3(arg1489_754, list1495_758);
			     }
			  }
			  {
			     obj_t arg1499_762;
			     obj_t arg1500_763;
			     arg1499_762 = CNST_TABLE_REF(((long) 5));
			     arg1500_763 = current_function_76_tools_error();
			     {
				obj_t list1501_764;
				{
				   obj_t arg1502_765;
				   arg1502_765 = MAKE_PAIR(arg1500_763, BNIL);
				   list1501_764 = MAKE_PAIR(arg1499_762, arg1502_765);
				}
				arg1476_742 = list1501_764;
			     }
			  }
			  arg1478_744 = location_full_fname_231_tools_location(loc_18);
			  arg1479_745 = STRUCT_REF(loc_18, ((long) 1));
			  {
			     obj_t list1481_747;
			     {
				obj_t arg1483_748;
				{
				   obj_t arg1484_749;
				   {
				      obj_t arg1485_750;
				      {
					 obj_t arg1486_751;
					 {
					    obj_t arg1487_752;
					    arg1487_752 = MAKE_PAIR(BNIL, BNIL);
					    arg1486_751 = MAKE_PAIR(arg1479_745, arg1487_752);
					 }
					 arg1485_750 = MAKE_PAIR(arg1478_744, arg1486_751);
				      }
				      arg1484_749 = MAKE_PAIR(error_msg_180_17, arg1485_750);
				   }
				   arg1483_748 = MAKE_PAIR(string1765_coerce_apply, arg1484_749);
				}
				list1481_747 = MAKE_PAIR(arg1476_742, arg1483_748);
			     }
			     arg1467_734 = cons__138___r4_pairs_and_lists_6_3(arg1475_741, list1481_747);
			  }
		       }
		       {
			  obj_t arg1504_767;
			  obj_t arg1505_768;
			  obj_t arg1507_769;
			  obj_t arg1510_770;
			  arg1504_767 = CNST_TABLE_REF(((long) 6));
			  {
			     obj_t arg1517_777;
			     obj_t arg1518_778;
			     arg1517_777 = CNST_TABLE_REF(((long) 5));
			     arg1518_778 = CNST_TABLE_REF(((long) 7));
			     {
				obj_t list1520_780;
				{
				   obj_t arg1522_781;
				   arg1522_781 = MAKE_PAIR(BNIL, BNIL);
				   list1520_780 = MAKE_PAIR(arg1518_778, arg1522_781);
				}
				arg1505_768 = cons__138___r4_pairs_and_lists_6_3(arg1517_777, list1520_780);
			     }
			  }
			  {
			     obj_t arg1525_783;
			     obj_t arg1526_784;
			     arg1525_783 = CNST_TABLE_REF(((long) 5));
			     arg1526_784 = CNST_TABLE_REF(((long) 7));
			     {
				obj_t list1528_786;
				{
				   obj_t arg1529_787;
				   arg1529_787 = MAKE_PAIR(BNIL, BNIL);
				   list1528_786 = MAKE_PAIR(arg1526_784, arg1529_787);
				}
				arg1507_769 = cons__138___r4_pairs_and_lists_6_3(arg1525_783, list1528_786);
			     }
			  }
			  {
			     obj_t arg1531_789;
			     obj_t arg1532_790;
			     arg1531_789 = CNST_TABLE_REF(((long) 5));
			     arg1532_790 = CNST_TABLE_REF(((long) 7));
			     {
				obj_t list1534_792;
				{
				   obj_t arg1535_793;
				   arg1535_793 = MAKE_PAIR(BNIL, BNIL);
				   list1534_792 = MAKE_PAIR(arg1532_790, arg1535_793);
				}
				arg1510_770 = cons__138___r4_pairs_and_lists_6_3(arg1531_789, list1534_792);
			     }
			  }
			  {
			     obj_t list1512_772;
			     {
				obj_t arg1513_773;
				{
				   obj_t arg1514_774;
				   {
				      obj_t arg1515_775;
				      arg1515_775 = MAKE_PAIR(BNIL, BNIL);
				      arg1514_774 = MAKE_PAIR(arg1510_770, arg1515_775);
				   }
				   arg1513_773 = MAKE_PAIR(arg1507_769, arg1514_774);
				}
				list1512_772 = MAKE_PAIR(arg1505_768, arg1513_773);
			     }
			     arg1468_735 = cons__138___r4_pairs_and_lists_6_3(arg1504_767, list1512_772);
			  }
		       }
		       {
			  obj_t list1470_737;
			  {
			     obj_t arg1471_738;
			     {
				obj_t arg1473_739;
				arg1473_739 = MAKE_PAIR(BNIL, BNIL);
				arg1471_738 = MAKE_PAIR(arg1468_735, arg1473_739);
			     }
			     list1470_737 = MAKE_PAIR(arg1467_734, arg1471_738);
			  }
			  arg1464_731 = cons__138___r4_pairs_and_lists_6_3(arg1466_733, list1470_737);
		       }
		    }
		  else
		    {
		       obj_t arg1537_795;
		       obj_t arg1539_796;
		       arg1537_795 = CNST_TABLE_REF(((long) 6));
		       {
			  obj_t arg1552_804;
			  obj_t arg1553_805;
			  arg1552_804 = CNST_TABLE_REF(((long) 5));
			  arg1553_805 = current_function_76_tools_error();
			  {
			     obj_t list1554_806;
			     {
				obj_t arg1555_807;
				arg1555_807 = MAKE_PAIR(arg1553_805, BNIL);
				list1554_806 = MAKE_PAIR(arg1552_804, arg1555_807);
			     }
			     arg1539_796 = list1554_806;
			  }
		       }
		       {
			  obj_t list1543_799;
			  {
			     obj_t arg1545_800;
			     {
				obj_t arg1548_801;
				{
				   obj_t arg1549_802;
				   arg1549_802 = MAKE_PAIR(BNIL, BNIL);
				   arg1548_801 = MAKE_PAIR(error_msg_180_17, arg1549_802);
				}
				arg1545_800 = MAKE_PAIR(string1765_coerce_apply, arg1548_801);
			     }
			     list1543_799 = MAKE_PAIR(arg1539_796, arg1545_800);
			  }
			  arg1464_731 = cons__138___r4_pairs_and_lists_6_3(arg1537_795, list1543_799);
		       }
		    }
	       }
	       arg1463_730 = top_level_sexp__node_204_ast_sexp(arg1464_731, loc_18);
	    }
	    node_729 = coerce__182_coerce_coerce(arg1463_730, (type_t) (to_19));
	 }
	 _unsafe_type__146_engine_param = ut_728;
	 return node_729;
      }
   }
}


/* method-init */ obj_t 
method_init_76_coerce_apply()
{
   {
      obj_t coerce__app_ly_232_1374;
      coerce__app_ly_232_1374 = proc1766_coerce_apply;
      return add_method__1___object(coerce__env_127_coerce_coerce, app_ly_162_ast_node, coerce__app_ly_232_1374);
   }
}


/* coerce!-app-ly */ obj_t 
coerce__app_ly_232_coerce_apply(obj_t env_1375, obj_t node_1376, obj_t to_1377)
{
   {
      app_ly_162_t node_1136;
      obj_t to_1137;
      node_1136 = (app_ly_162_t) (node_1376);
      to_1137 = to_1377;
      {
	 obj_t error_msg_180_1140;
	 {
	    obj_t arg1747_1227;
	    obj_t arg1748_1228;
	    arg1747_1227 = CNST_TABLE_REF(((long) 5));
	    arg1748_1228 = shape_tools_shape((obj_t) (node_1136));
	    {
	       obj_t list1749_1229;
	       {
		  obj_t arg1753_1230;
		  arg1753_1230 = MAKE_PAIR(arg1748_1228, BNIL);
		  list1749_1229 = MAKE_PAIR(arg1747_1227, arg1753_1230);
	       }
	       error_msg_180_1140 = list1749_1229;
	    }
	 }
	 {
	    node_t arg1655_1141;
	    arg1655_1141 = coerce__182_coerce_coerce((((app_ly_162_t) CREF(node_1136))->arg), (type_t) (_obj__252_type_cache));
	    ((((app_ly_162_t) CREF(node_1136))->arg) = ((node_t) arg1655_1141), BUNSPEC);
	 }
	 {
	    node_t c_fun_136_1143;
	    c_fun_136_1143 = coerce__182_coerce_coerce((((app_ly_162_t) CREF(node_1136))->fun), (type_t) (_procedure__226_type_cache));
	    if (CBOOL(_unsafe_arity__240_engine_param))
	      {
		 {
		    bool_t test1657_1144;
		    test1657_1144 = is_a__118___object((obj_t) (c_fun_136_1143), var_ast_node);
		    if (test1657_1144)
		      {
			 ((((app_ly_162_t) CREF(node_1136))->fun) = ((node_t) c_fun_136_1143), BUNSPEC);
			 {
			    node_t aux_1507;
			    aux_1507 = convert__122_coerce_convert((node_t) (node_1136), (type_t) (_obj__252_type_cache), (type_t) (to_1137));
			    return (obj_t) (aux_1507);
			 }
		      }
		    else
		      {
			 local_t fun_1145;
			 fun_1145 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 8)), (type_t) (_procedure__226_type_cache));
			 ((((app_ly_162_t) CREF(node_1136))->fun) = ((node_t) c_fun_136_1143), BUNSPEC);
			 {
			    obj_t arg1658_1146;
			    type_t arg1659_1147;
			    obj_t arg1663_1149;
			    node_t arg1665_1150;
			    {
			       node_t obj_1298;
			       obj_1298 = (node_t) (node_1136);
			       arg1658_1146 = (((node_t) CREF(obj_1298))->loc);
			    }
			    {
			       node_t obj_1299;
			       obj_1299 = (node_t) (node_1136);
			       arg1659_1147 = (((node_t) CREF(obj_1299))->type);
			    }
			    {
			       obj_t arg1666_1151;
			       {
				  obj_t aux_1523;
				  obj_t aux_1521;
				  aux_1523 = (obj_t) (c_fun_136_1143);
				  aux_1521 = (obj_t) (fun_1145);
				  arg1666_1151 = MAKE_PAIR(aux_1521, aux_1523);
			       }
			       {
				  obj_t list1667_1152;
				  list1667_1152 = MAKE_PAIR(arg1666_1151, BNIL);
				  arg1663_1149 = list1667_1152;
			       }
			    }
			    arg1665_1150 = convert__122_coerce_convert((node_t) (node_1136), (type_t) (_obj__252_type_cache), (type_t) (to_1137));
			    {
			       let_var_6_t res1758_1321;
			       {
				  obj_t key_1306;
				  key_1306 = BINT(((long) -1));
				  {
				     let_var_6_t new1365_1310;
				     new1365_1310 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
				     {
					long arg1572_1311;
					arg1572_1311 = class_num_218___object(let_var_6_ast_node);
					{
					   obj_t obj_1319;
					   obj_1319 = (obj_t) (new1365_1310);
					   (((obj_t) CREF(obj_1319))->header = MAKE_HEADER(arg1572_1311, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_1536;
					aux_1536 = (object_t) (new1365_1310);
					OBJECT_WIDENING_SET(aux_1536, BFALSE);
				     }
				     ((((let_var_6_t) CREF(new1365_1310))->loc) = ((obj_t) arg1658_1146), BUNSPEC);
				     ((((let_var_6_t) CREF(new1365_1310))->type) = ((type_t) arg1659_1147), BUNSPEC);
				     ((((let_var_6_t) CREF(new1365_1310))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
				     ((((let_var_6_t) CREF(new1365_1310))->key) = ((obj_t) key_1306), BUNSPEC);
				     ((((let_var_6_t) CREF(new1365_1310))->bindings) = ((obj_t) arg1663_1149), BUNSPEC);
				     ((((let_var_6_t) CREF(new1365_1310))->body) = ((node_t) arg1665_1150), BUNSPEC);
				     ((((let_var_6_t) CREF(new1365_1310))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				     res1758_1321 = new1365_1310;
				  }
			       }
			       return (obj_t) (res1758_1321);
			    }
			 }
		      }
		 }
	      }
	    else
	      {
		 local_t fun_1155;
		 fun_1155 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 8)), (type_t) (_procedure__226_type_cache));
		 {
		    local_t val_1156;
		    val_1156 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 9)), (type_t) (_procedure__226_type_cache));
		    {
		       obj_t len_1157;
		       len_1157 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 10)), BEOA);
		       {
			  obj_t loc_1158;
			  {
			     node_t obj_1322;
			     obj_1322 = (node_t) (node_1136);
			     loc_1158 = (((node_t) CREF(obj_1322))->loc);
			  }
			  {
			     let_var_6_t lnode_1159;
			     {
				obj_t arg1681_1169;
				obj_t arg1683_1171;
				node_t arg1684_1172;
				arg1681_1169 = _obj__252_type_cache;
				{
				   obj_t arg1685_1173;
				   obj_t arg1686_1174;
				   {
				      obj_t aux_1560;
				      obj_t aux_1558;
				      aux_1560 = (obj_t) (c_fun_136_1143);
				      aux_1558 = (obj_t) (fun_1155);
				      arg1685_1173 = MAKE_PAIR(aux_1558, aux_1560);
				   }
				   {
				      obj_t aux_1565;
				      obj_t aux_1563;
				      {
					 node_t aux_1566;
					 aux_1566 = (((app_ly_162_t) CREF(node_1136))->arg);
					 aux_1565 = (obj_t) (aux_1566);
				      }
				      aux_1563 = (obj_t) (val_1156);
				      arg1686_1174 = MAKE_PAIR(aux_1563, aux_1565);
				   }
				   {
				      obj_t list1687_1175;
				      {
					 obj_t arg1688_1176;
					 arg1688_1176 = MAKE_PAIR(arg1686_1174, BNIL);
					 list1687_1175 = MAKE_PAIR(arg1685_1173, arg1688_1176);
				      }
				      arg1683_1171 = list1687_1175;
				   }
				}
				{
				   obj_t arg1692_1179;
				   {
				      obj_t arg1693_1180;
				      obj_t arg1694_1181;
				      obj_t arg1695_1182;
				      arg1693_1180 = CNST_TABLE_REF(((long) 11));
				      {
					 obj_t arg1702_1188;
					 {
					    obj_t arg1706_1192;
					    obj_t arg1707_1193;
					    {
					       obj_t list1713_1199;
					       {
						  obj_t arg1714_1200;
						  {
						     obj_t aux_1573;
						     aux_1573 = CNST_TABLE_REF(((long) 12));
						     arg1714_1200 = MAKE_PAIR(aux_1573, BNIL);
						  }
						  list1713_1199 = MAKE_PAIR(len_1157, arg1714_1200);
					       }
					       arg1706_1192 = symbol_append_197___r4_symbols_6_4(list1713_1199);
					    }
					    {
					       obj_t arg1717_1202;
					       arg1717_1202 = CNST_TABLE_REF(((long) 13));
					       {
						  obj_t list1719_1204;
						  {
						     obj_t arg1720_1205;
						     arg1720_1205 = MAKE_PAIR(BNIL, BNIL);
						     {
							obj_t aux_1580;
							aux_1580 = (obj_t) (val_1156);
							list1719_1204 = MAKE_PAIR(aux_1580, arg1720_1205);
						     }
						  }
						  arg1707_1193 = cons__138___r4_pairs_and_lists_6_3(arg1717_1202, list1719_1204);
					       }
					    }
					    {
					       obj_t list1709_1195;
					       {
						  obj_t arg1710_1196;
						  arg1710_1196 = MAKE_PAIR(BNIL, BNIL);
						  list1709_1195 = MAKE_PAIR(arg1707_1193, arg1710_1196);
					       }
					       arg1702_1188 = cons__138___r4_pairs_and_lists_6_3(arg1706_1192, list1709_1195);
					    }
					 }
					 {
					    obj_t list1704_1190;
					    list1704_1190 = MAKE_PAIR(BNIL, BNIL);
					    arg1694_1181 = cons__138___r4_pairs_and_lists_6_3(arg1702_1188, list1704_1190);
					 }
				      }
				      {
					 obj_t arg1722_1207;
					 obj_t arg1723_1208;
					 node_t arg1724_1209;
					 node_t arg1725_1210;
					 arg1722_1207 = CNST_TABLE_REF(((long) 14));
					 {
					    obj_t arg1732_1217;
					    arg1732_1217 = CNST_TABLE_REF(((long) 15));
					    {
					       obj_t list1734_1219;
					       {
						  obj_t arg1738_1220;
						  {
						     obj_t arg1739_1221;
						     arg1739_1221 = MAKE_PAIR(BNIL, BNIL);
						     arg1738_1220 = MAKE_PAIR(len_1157, arg1739_1221);
						  }
						  {
						     obj_t aux_1593;
						     aux_1593 = (obj_t) (fun_1155);
						     list1734_1219 = MAKE_PAIR(aux_1593, arg1738_1220);
						  }
					       }
					       arg1723_1208 = cons__138___r4_pairs_and_lists_6_3(arg1732_1217, list1734_1219);
					    }
					 }
					 arg1724_1209 = convert__122_coerce_convert((node_t) (node_1136), (type_t) (_obj__252_type_cache), (type_t) (to_1137));
					 arg1725_1210 = make_error_node_135_coerce_apply(error_msg_180_1140, loc_1158, to_1137);
					 {
					    obj_t list1727_1212;
					    {
					       obj_t arg1728_1213;
					       {
						  obj_t arg1729_1214;
						  {
						     obj_t arg1730_1215;
						     arg1730_1215 = MAKE_PAIR(BNIL, BNIL);
						     {
							obj_t aux_1603;
							aux_1603 = (obj_t) (arg1725_1210);
							arg1729_1214 = MAKE_PAIR(aux_1603, arg1730_1215);
						     }
						  }
						  {
						     obj_t aux_1606;
						     aux_1606 = (obj_t) (arg1724_1209);
						     arg1728_1213 = MAKE_PAIR(aux_1606, arg1729_1214);
						  }
					       }
					       list1727_1212 = MAKE_PAIR(arg1723_1208, arg1728_1213);
					    }
					    arg1695_1182 = cons__138___r4_pairs_and_lists_6_3(arg1722_1207, list1727_1212);
					 }
				      }
				      {
					 obj_t list1698_1184;
					 {
					    obj_t arg1699_1185;
					    {
					       obj_t arg1700_1186;
					       arg1700_1186 = MAKE_PAIR(BNIL, BNIL);
					       arg1699_1185 = MAKE_PAIR(arg1695_1182, arg1700_1186);
					    }
					    list1698_1184 = MAKE_PAIR(arg1694_1181, arg1699_1185);
					 }
					 arg1692_1179 = cons__138___r4_pairs_and_lists_6_3(arg1693_1180, list1698_1184);
				      }
				   }
				   arg1684_1172 = top_level_sexp__node_204_ast_sexp(arg1692_1179, loc_1158);
				}
				{
				   let_var_6_t res1759_1347;
				   {
				      type_t type_1330;
				      obj_t key_1332;
				      type_1330 = (type_t) (arg1681_1169);
				      key_1332 = BINT(((long) -1));
				      {
					 let_var_6_t new1365_1336;
					 new1365_1336 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
					 {
					    long arg1572_1337;
					    arg1572_1337 = class_num_218___object(let_var_6_ast_node);
					    {
					       obj_t obj_1345;
					       obj_1345 = (obj_t) (new1365_1336);
					       (((obj_t) CREF(obj_1345))->header = MAKE_HEADER(arg1572_1337, 0), BUNSPEC);
					    }
					 }
					 {
					    object_t aux_1622;
					    aux_1622 = (object_t) (new1365_1336);
					    OBJECT_WIDENING_SET(aux_1622, BFALSE);
					 }
					 ((((let_var_6_t) CREF(new1365_1336))->loc) = ((obj_t) loc_1158), BUNSPEC);
					 ((((let_var_6_t) CREF(new1365_1336))->type) = ((type_t) type_1330), BUNSPEC);
					 ((((let_var_6_t) CREF(new1365_1336))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					 ((((let_var_6_t) CREF(new1365_1336))->key) = ((obj_t) key_1332), BUNSPEC);
					 ((((let_var_6_t) CREF(new1365_1336))->bindings) = ((obj_t) arg1683_1171), BUNSPEC);
					 ((((let_var_6_t) CREF(new1365_1336))->body) = ((node_t) arg1684_1172), BUNSPEC);
					 ((((let_var_6_t) CREF(new1365_1336))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					 res1759_1347 = new1365_1336;
				      }
				   }
				   lnode_1159 = res1759_1347;
				}
			     }
			     {
				{
				   var_t arg1670_1160;
				   {
				      obj_t arg1673_1162;
				      arg1673_1162 = _procedure__226_type_cache;
				      {
					 var_t res1760_1358;
					 {
					    type_t type_1349;
					    variable_t variable_1350;
					    type_1349 = (type_t) (arg1673_1162);
					    variable_1350 = (variable_t) (fun_1155);
					    {
					       var_t new1206_1351;
					       new1206_1351 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					       {
						  long arg1612_1352;
						  arg1612_1352 = class_num_218___object(var_ast_node);
						  {
						     obj_t obj_1356;
						     obj_1356 = (obj_t) (new1206_1351);
						     (((obj_t) CREF(obj_1356))->header = MAKE_HEADER(arg1612_1352, 0), BUNSPEC);
						  }
					       }
					       {
						  object_t aux_1638;
						  aux_1638 = (object_t) (new1206_1351);
						  OBJECT_WIDENING_SET(aux_1638, BFALSE);
					       }
					       ((((var_t) CREF(new1206_1351))->loc) = ((obj_t) loc_1158), BUNSPEC);
					       ((((var_t) CREF(new1206_1351))->type) = ((type_t) type_1349), BUNSPEC);
					       ((((var_t) CREF(new1206_1351))->variable) = ((variable_t) variable_1350), BUNSPEC);
					       res1760_1358 = new1206_1351;
					    }
					 }
					 arg1670_1160 = res1760_1358;
				      }
				   }
				   {
				      node_t val1263_1360;
				      val1263_1360 = (node_t) (arg1670_1160);
				      ((((app_ly_162_t) CREF(node_1136))->fun) = ((node_t) val1263_1360), BUNSPEC);
				   }
				}
				{
				   var_t arg1676_1164;
				   {
				      obj_t arg1678_1166;
				      arg1678_1166 = _obj__252_type_cache;
				      {
					 var_t res1761_1371;
					 {
					    type_t type_1362;
					    variable_t variable_1363;
					    type_1362 = (type_t) (arg1678_1166);
					    variable_1363 = (variable_t) (val_1156);
					    {
					       var_t new1206_1364;
					       new1206_1364 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					       {
						  long arg1612_1365;
						  arg1612_1365 = class_num_218___object(var_ast_node);
						  {
						     obj_t obj_1369;
						     obj_1369 = (obj_t) (new1206_1364);
						     (((obj_t) CREF(obj_1369))->header = MAKE_HEADER(arg1612_1365, 0), BUNSPEC);
						  }
					       }
					       {
						  object_t aux_1652;
						  aux_1652 = (object_t) (new1206_1364);
						  OBJECT_WIDENING_SET(aux_1652, BFALSE);
					       }
					       ((((var_t) CREF(new1206_1364))->loc) = ((obj_t) loc_1158), BUNSPEC);
					       ((((var_t) CREF(new1206_1364))->type) = ((type_t) type_1362), BUNSPEC);
					       ((((var_t) CREF(new1206_1364))->variable) = ((variable_t) variable_1363), BUNSPEC);
					       res1761_1371 = new1206_1364;
					    }
					 }
					 arg1676_1164 = res1761_1371;
				      }
				   }
				   {
				      node_t val1264_1373;
				      val1264_1373 = (node_t) (arg1676_1164);
				      ((((app_ly_162_t) CREF(node_1136))->arg) = ((node_t) val1264_1373), BUNSPEC);
				   }
				}
				return (obj_t) (lnode_1159);
			     }
			  }
		       }
		    }
		 }
	      }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_apply()
{
   module_initialization_70_tools_trace(((long) 0), "COERCE_APPLY");
   module_initialization_70_engine_param(((long) 0), "COERCE_APPLY");
   module_initialization_70_tools_shape(((long) 0), "COERCE_APPLY");
   module_initialization_70_tools_location(((long) 0), "COERCE_APPLY");
   module_initialization_70_tools_error(((long) 0), "COERCE_APPLY");
   module_initialization_70_type_type(((long) 0), "COERCE_APPLY");
   module_initialization_70_type_cache(((long) 0), "COERCE_APPLY");
   module_initialization_70_ast_var(((long) 0), "COERCE_APPLY");
   module_initialization_70_ast_node(((long) 0), "COERCE_APPLY");
   module_initialization_70_ast_sexp(((long) 0), "COERCE_APPLY");
   module_initialization_70_ast_local(((long) 0), "COERCE_APPLY");
   module_initialization_70_coerce_coerce(((long) 0), "COERCE_APPLY");
   return module_initialization_70_coerce_convert(((long) 0), "COERCE_APPLY");
}
