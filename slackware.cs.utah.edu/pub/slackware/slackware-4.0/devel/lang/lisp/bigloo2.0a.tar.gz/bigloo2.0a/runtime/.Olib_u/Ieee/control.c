/*===========================================================================*/
/*   (Ieee/control.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t _procedure__196___r4_control_features_6_9(obj_t, obj_t);
extern obj_t force___r4_control_features_6_9(obj_t);
static obj_t _dynamic_wind1197_47___r4_control_features_6_9(obj_t, obj_t, obj_t, obj_t);
extern obj_t call_with_current_continuation_81___r4_control_features_6_9(obj_t);
extern obj_t call_cc_68___r4_control_features_6_9(obj_t);
extern obj_t call_cc(obj_t);
static obj_t loop_1199___r4_control_features_6_9(obj_t, obj_t);
static obj_t loop_1198___r4_control_features_6_9(obj_t);
static obj_t loop_1202___r4_control_features_6_9(obj_t);
static obj_t loop_1201___r4_control_features_6_9(obj_t, obj_t);
static obj_t loop_1200___r4_control_features_6_9(obj_t, obj_t);
static obj_t _call_with_current_continuation1196_127___r4_control_features_6_9(obj_t, obj_t);
extern bool_t procedure__188___r4_control_features_6_9(obj_t);
static obj_t _call_cc1195_144___r4_control_features_6_9(obj_t, obj_t);
static obj_t _make_promise1194_212___r4_control_features_6_9(obj_t, obj_t);
static obj_t loop___r4_control_features_6_9(obj_t);
static obj_t _for_each1193_173___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t lambda1071___r4_control_features_6_9(obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t make_promise_21___r4_control_features_6_9(obj_t);
static obj_t handling_function1085___r4_control_features_6_9(obj_t);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t _res_number__75___r5_control_features_6_4;
static obj_t _apply1189___r4_control_features_6_9(obj_t, obj_t, obj_t, obj_t);
extern obj_t map___r4_control_features_6_9(obj_t, obj_t);
static obj_t arg1076___r4_control_features_6_9(obj_t, obj_t);
static obj_t arg1072___r4_control_features_6_9(obj_t, obj_t);
extern obj_t apply___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t for_each_2_102___r4_control_features_6_9(obj_t, obj_t);
static obj_t _map1191___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t _for_each_21192_251___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t map_2_128___r4_control_features_6_9(obj_t, obj_t);
extern obj_t for_each_73___r4_control_features_6_9(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_control_features_6_9();
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114___r4_control_features_6_9 = BUNSPEC;
static obj_t _force___r4_control_features_6_9(obj_t, obj_t);
static obj_t _map_21190_67___r4_control_features_6_9(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( call_with_current_continuation_env_226___r4_control_features_6_9, _call_with_current_continuation1196_127___r4_control_features_6_91204, _call_with_current_continuation1196_127___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( call_cc_env_179___r4_control_features_6_9, _call_cc1195_144___r4_control_features_6_91205, _call_cc1195_144___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_promise_env_123___r4_control_features_6_9, _make_promise1194_212___r4_control_features_6_91206, _make_promise1194_212___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( apply_env_60___r4_control_features_6_9, _apply1189___r4_control_features_6_91207, va_generic_entry, _apply1189___r4_control_features_6_9, -3 );
DEFINE_EXPORT_PROCEDURE( for_each_env_83___r4_control_features_6_9, _for_each1193_173___r4_control_features_6_91208, va_generic_entry, _for_each1193_173___r4_control_features_6_9, -2 );
DEFINE_EXPORT_PROCEDURE( map_env_220___r4_control_features_6_9, _map1191___r4_control_features_6_91209, va_generic_entry, _map1191___r4_control_features_6_9, -2 );
DEFINE_EXPORT_PROCEDURE( procedure__env_14___r4_control_features_6_9, _procedure__196___r4_control_features_6_91210, _procedure__196___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( for_each_2_env_153___r4_control_features_6_9, _for_each_21192_251___r4_control_features_6_91211, _for_each_21192_251___r4_control_features_6_9, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( map_2_env_80___r4_control_features_6_9, _map_21190_67___r4_control_features_6_91212, _map_21190_67___r4_control_features_6_9, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( force_env_196___r4_control_features_6_9, _force___r4_control_features_6_91213, _force___r4_control_features_6_9, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( dynamic_wind_env_99___r4_control_features_6_9, _dynamic_wind1197_47___r4_control_features_6_91214, _dynamic_wind1197_47___r4_control_features_6_9, 0L, 3 );


/* module-initialization */obj_t module_initialization_70___r4_control_features_6_9(long checksum_709, char * from_710)
{
if(CBOOL(require_initialization_114___r4_control_features_6_9)){
require_initialization_114___r4_control_features_6_9 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_control_features_6_9();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* procedure? */bool_t procedure__188___r4_control_features_6_9(obj_t obj_1)
{
return PROCEDUREP(obj_1);
}


/* _procedure? */obj_t _procedure__196___r4_control_features_6_9(obj_t env_655, obj_t obj_656)
{
{
bool_t aux_716;
{
obj_t obj_704;
obj_704 = obj_656;
aux_716 = PROCEDUREP(obj_704);
}
return BBOOL(aux_716);
}
}


/* apply */obj_t apply___r4_control_features_6_9(obj_t proc_2, obj_t args_3, obj_t opt_4)
{
{
obj_t args_394;
if(PAIRP(opt_4)){
obj_t arg1016_396;
arg1016_396 = loop_1202___r4_control_features_6_9(opt_4);
args_394 = MAKE_PAIR(args_3, arg1016_396);
}
 else {
args_394 = args_3;
}
return apply(proc_2, args_394);
}
}


/* loop_1202 */obj_t loop_1202___r4_control_features_6_9(obj_t opt_398)
{
{
bool_t test_725;
{
obj_t aux_726;
aux_726 = CDR(opt_398);
test_725 = PAIRP(aux_726);
}
if(test_725){
obj_t arg1018_401;
obj_t arg1019_402;
arg1018_401 = CAR(opt_398);
arg1019_402 = loop_1202___r4_control_features_6_9(CDR(opt_398));
return MAKE_PAIR(arg1018_401, arg1019_402);
}
 else {
return CAR(opt_398);
}
}
}


/* _apply1189 */obj_t _apply1189___r4_control_features_6_9(obj_t env_657, obj_t proc_658, obj_t args_659, obj_t opt_660)
{
return apply___r4_control_features_6_9(proc_658, args_659, opt_660);
}


/* map-2 */obj_t map_2_128___r4_control_features_6_9(obj_t f_5, obj_t l_6)
{
return loop_1201___r4_control_features_6_9(f_5, l_6);
}


/* loop_1201 */obj_t loop_1201___r4_control_features_6_9(obj_t f_703, obj_t l_415)
{
if(NULLP(l_415)){
return BNIL;
}
 else {
obj_t arg1023_417;
obj_t arg1025_418;
arg1023_417 = PROCEDURE_ENTRY(f_703)(f_703, CAR(l_415), BEOA);
arg1025_418 = loop_1201___r4_control_features_6_9(f_703, CDR(l_415));
return MAKE_PAIR(arg1023_417, arg1025_418);
}
}


/* _map-21190 */obj_t _map_21190_67___r4_control_features_6_9(obj_t env_661, obj_t f_662, obj_t l_663)
{
{
obj_t f_705;
obj_t l_706;
f_705 = f_662;
l_706 = l_663;
return loop_1201___r4_control_features_6_9(f_705, l_706);
}
}


/* map */obj_t map___r4_control_features_6_9(obj_t f_7, obj_t l_8)
{
if(NULLP(l_8)){
return BNIL;
}
 else {
bool_t test_747;
{
obj_t aux_748;
aux_748 = CDR(l_8);
test_747 = NULLP(aux_748);
}
if(test_747){
return loop_1200___r4_control_features_6_9(f_7, CAR(l_8));
}
 else {
return loop_1199___r4_control_features_6_9(f_7, l_8);
}
}
}


/* loop */obj_t loop___r4_control_features_6_9(obj_t l_448)
{
if(NULLP(l_448)){
return BNIL;
}
 else {
obj_t arg1023_450;
obj_t arg1025_451;
{
obj_t aux_756;
aux_756 = CAR(l_448);
arg1023_450 = CAR(aux_756);
}
arg1025_451 = loop___r4_control_features_6_9(CDR(l_448));
return MAKE_PAIR(arg1023_450, arg1025_451);
}
}


/* loop_1198 */obj_t loop_1198___r4_control_features_6_9(obj_t l_462)
{
if(NULLP(l_462)){
return BNIL;
}
 else {
obj_t arg1023_464;
obj_t arg1025_465;
{
obj_t aux_764;
aux_764 = CAR(l_462);
arg1023_464 = CDR(aux_764);
}
arg1025_465 = loop_1198___r4_control_features_6_9(CDR(l_462));
return MAKE_PAIR(arg1023_464, arg1025_465);
}
}


/* loop_1199 */obj_t loop_1199___r4_control_features_6_9(obj_t f_701, obj_t l_217)
{
{
bool_t test_770;
{
obj_t aux_771;
aux_771 = CAR(l_217);
test_770 = NULLP(aux_771);
}
if(test_770){
return BNIL;
}
 else {
obj_t arg1032_220;
obj_t arg1033_221;
arg1032_220 = apply(f_701, loop___r4_control_features_6_9(l_217));
{
obj_t arg1034_222;
arg1034_222 = loop_1198___r4_control_features_6_9(l_217);
arg1033_221 = loop_1199___r4_control_features_6_9(f_701, arg1034_222);
}
return MAKE_PAIR(arg1032_220, arg1033_221);
}
}
}


/* loop_1200 */obj_t loop_1200___r4_control_features_6_9(obj_t f_702, obj_t l_433)
{
if(NULLP(l_433)){
return BNIL;
}
 else {
obj_t arg1023_435;
obj_t arg1025_436;
arg1023_435 = PROCEDURE_ENTRY(f_702)(f_702, CAR(l_433), BEOA);
arg1025_436 = loop_1200___r4_control_features_6_9(f_702, CDR(l_433));
return MAKE_PAIR(arg1023_435, arg1025_436);
}
}


/* _map1191 */obj_t _map1191___r4_control_features_6_9(obj_t env_664, obj_t f_665, obj_t l_666)
{
return map___r4_control_features_6_9(f_665, l_666);
}


/* for-each-2 */obj_t for_each_2_102___r4_control_features_6_9(obj_t f_9, obj_t l_10)
{
{
obj_t l_482;
l_482 = l_10;
loop_481:
if(NULLP(l_482)){
return BNIL;
}
 else {
PROCEDURE_ENTRY(f_9)(f_9, CAR(l_482), BEOA);
{
obj_t l_794;
l_794 = CDR(l_482);
l_482 = l_794;
goto loop_481;
}
}
}
}


/* _for-each-21192 */obj_t _for_each_21192_251___r4_control_features_6_9(obj_t env_667, obj_t f_668, obj_t l_669)
{
return for_each_2_102___r4_control_features_6_9(f_668, l_669);
}


/* for-each */obj_t for_each_73___r4_control_features_6_9(obj_t f_11, obj_t l_12)
{
if(NULLP(l_12)){
return BNIL;
}
 else {
bool_t test_799;
{
obj_t aux_800;
aux_800 = CDR(l_12);
test_799 = NULLP(aux_800);
}
if(test_799){
{
obj_t l_512;
l_512 = CAR(l_12);
loop_511:
if(NULLP(l_512)){
return BNIL;
}
 else {
PROCEDURE_ENTRY(f_11)(f_11, CAR(l_512), BEOA);
{
obj_t l_808;
l_808 = CDR(l_512);
l_512 = l_808;
goto loop_511;
}
}
}
}
 else {
{
obj_t l_233;
l_233 = l_12;
loop_234:
{
bool_t test_811;
{
obj_t aux_812;
aux_812 = CAR(l_233);
test_811 = NULLP(aux_812);
}
if(test_811){
return BNIL;
}
 else {
{
obj_t aux_815;
if(NULLP(l_233)){
aux_815 = BNIL;
}
 else {
obj_t head1004_238;
{
obj_t aux_818;
{
obj_t aux_819;
aux_819 = CAR(l_233);
aux_818 = CAR(aux_819);
}
head1004_238 = MAKE_PAIR(aux_818, BNIL);
}
{
obj_t l1002_531;
obj_t tail1005_532;
l1002_531 = CDR(l_233);
tail1005_532 = head1004_238;
lname1003_530:
if(NULLP(l1002_531)){
aux_815 = head1004_238;
}
 else {
obj_t newtail1006_540;
{
obj_t aux_825;
{
obj_t aux_826;
aux_826 = CAR(l1002_531);
aux_825 = CAR(aux_826);
}
newtail1006_540 = MAKE_PAIR(aux_825, BNIL);
}
SET_CDR(tail1005_532, newtail1006_540);
{
obj_t tail1005_833;
obj_t l1002_831;
l1002_831 = CDR(l1002_531);
tail1005_833 = newtail1006_540;
tail1005_532 = tail1005_833;
l1002_531 = l1002_831;
goto lname1003_530;
}
}
}
}
apply(f_11, aux_815);
}
{
obj_t arg1056_252;
if(NULLP(l_233)){
arg1056_252 = BNIL;
}
 else {
obj_t head1009_255;
{
obj_t aux_838;
{
obj_t aux_839;
aux_839 = CAR(l_233);
aux_838 = CDR(aux_839);
}
head1009_255 = MAKE_PAIR(aux_838, BNIL);
}
{
obj_t l1007_590;
obj_t tail1010_591;
l1007_590 = CDR(l_233);
tail1010_591 = head1009_255;
lname1008_589:
if(NULLP(l1007_590)){
arg1056_252 = head1009_255;
}
 else {
obj_t newtail1011_599;
{
obj_t aux_845;
{
obj_t aux_846;
aux_846 = CAR(l1007_590);
aux_845 = CDR(aux_846);
}
newtail1011_599 = MAKE_PAIR(aux_845, BNIL);
}
SET_CDR(tail1010_591, newtail1011_599);
{
obj_t tail1010_853;
obj_t l1007_851;
l1007_851 = CDR(l1007_590);
tail1010_853 = newtail1011_599;
tail1010_591 = tail1010_853;
l1007_590 = l1007_851;
goto lname1008_589;
}
}
}
}
{
obj_t l_855;
l_855 = arg1056_252;
l_233 = l_855;
goto loop_234;
}
}
}
}
}
}
}
}


/* _for-each1193 */obj_t _for_each1193_173___r4_control_features_6_9(obj_t env_670, obj_t f_671, obj_t l_672)
{
return for_each_73___r4_control_features_6_9(f_671, l_672);
}


/* force */obj_t force___r4_control_features_6_9(obj_t promise_13)
{
return PROCEDURE_ENTRY(promise_13)(promise_13, BEOA);
}


/* _force */obj_t _force___r4_control_features_6_9(obj_t env_673, obj_t promise_674)
{
{
obj_t promise_707;
promise_707 = promise_674;
return PROCEDURE_ENTRY(promise_707)(promise_707, BEOA);
}
}


/* make-promise */obj_t make_promise_21___r4_control_features_6_9(obj_t proc_14)
{
{
obj_t result_ready__3_271;
obj_t result_272;
result_ready__3_271 = MAKE_CELL(BFALSE);
result_272 = MAKE_CELL(BFALSE);
{
obj_t lambda1071_675;
lambda1071_675 = make_fx_procedure(lambda1071___r4_control_features_6_9, ((long)0), ((long)3));
PROCEDURE_SET(lambda1071_675, ((long)0), proc_14);
PROCEDURE_SET(lambda1071_675, ((long)1), result_ready__3_271);
PROCEDURE_SET(lambda1071_675, ((long)2), result_272);
return lambda1071_675;
}
}
}


/* _make-promise1194 */obj_t _make_promise1194_212___r4_control_features_6_9(obj_t env_676, obj_t proc_677)
{
return make_promise_21___r4_control_features_6_9(proc_677);
}


/* lambda1071 */obj_t lambda1071___r4_control_features_6_9(obj_t env_678)
{
{
obj_t proc_679;
obj_t result_ready__3_680;
obj_t result_681;
proc_679 = PROCEDURE_REF(env_678, ((long)0));
result_ready__3_680 = PROCEDURE_REF(env_678, ((long)1));
result_681 = PROCEDURE_REF(env_678, ((long)2));
{
{
bool_t test_869;
{
obj_t aux_870;
aux_870 = CELL_REF(result_ready__3_680);
test_869 = CBOOL(aux_870);
}
if(test_869){
return CELL_REF(result_681);
}
 else {
obj_t x_274;
x_274 = PROCEDURE_ENTRY(proc_679)(proc_679, BEOA);
{
bool_t test_874;
{
obj_t aux_875;
aux_875 = CELL_REF(result_ready__3_680);
test_874 = CBOOL(aux_875);
}
if(test_874){
return CELL_REF(result_681);
}
 else {
CELL_SET(result_ready__3_680, BTRUE);
CELL_SET(result_681, x_274);
return CELL_REF(result_681);
}
}
}
}
}
}
}


/* call/cc */obj_t call_cc_68___r4_control_features_6_9(obj_t proc_15)
{
{
obj_t arg1072_685;
arg1072_685 = make_fx_procedure(arg1072___r4_control_features_6_9, ((long)1), ((long)1));
PROCEDURE_SET(arg1072_685, ((long)0), proc_15);
return call_cc(arg1072_685);
}
}


/* _call/cc1195 */obj_t _call_cc1195_144___r4_control_features_6_9(obj_t env_686, obj_t proc_687)
{
return call_cc_68___r4_control_features_6_9(proc_687);
}


/* arg1072 */obj_t arg1072___r4_control_features_6_9(obj_t env_688, obj_t cont_690)
{
{
obj_t proc_689;
proc_689 = PROCEDURE_REF(env_688, ((long)0));
{
obj_t cont_276;
cont_276 = cont_690;
{
obj_t arg1076_684;
arg1076_684 = make_va_procedure(arg1076___r4_control_features_6_9, ((long)-1), ((long)1));
PROCEDURE_SET(arg1076_684, ((long)0), cont_276);
return PROCEDURE_ENTRY(proc_689)(proc_689, arg1076_684, BEOA);
}
}
}
}


/* arg1076 */obj_t arg1076___r4_control_features_6_9(obj_t env_691, obj_t vals_693)
{
{
obj_t cont_692;
cont_692 = PROCEDURE_REF(env_691, ((long)0));
{
obj_t vals_279;
vals_279 = vals_693;
{
bool_t test_887;
if(PAIRP(vals_279)){
obj_t aux_890;
aux_890 = CDR(vals_279);
test_887 = NULLP(aux_890);
}
 else {
test_887 = ((bool_t)0);
}
if(test_887){
return PROCEDURE_ENTRY(cont_692)(cont_692, CAR(vals_279), BEOA);
}
 else {
_res_number__75___r5_control_features_6_4 = BINT(((long)-1));
return PROCEDURE_ENTRY(cont_692)(cont_692, vals_279, BEOA);
}
}
}
}
}


/* call-with-current-continuation */obj_t call_with_current_continuation_81___r4_control_features_6_9(obj_t proc_16)
{
return call_cc_68___r4_control_features_6_9(proc_16);
}


/* _call-with-current-continuation1196 */obj_t _call_with_current_continuation1196_127___r4_control_features_6_9(obj_t env_694, obj_t proc_695)
{
{
obj_t proc_708;
proc_708 = proc_695;
return call_cc_68___r4_control_features_6_9(proc_708);
}
}


/* dynamic-wind */obj_t dynamic_wind_31___r4_control_features_6_9(obj_t before_17, obj_t thunk_18, obj_t after_19)
{
PROCEDURE_ENTRY(before_17)(before_17, BEOA);
{
PUSH_BEFORE(before_17);
{
obj_t val1012_646;
val1012_646 = handling_function1085___r4_control_features_6_9(thunk_18);
PROCEDURE_ENTRY(after_19)(after_19, BEOA);
POP_BEFORE();
{
bool_t test1082_650;
{
obj_t aux_908;
aux_908 = val_from_exit__100___bexit(val1012_646);
test1082_650 = CBOOL(aux_908);
}
if(test1082_650){
return unwind_until__178___bexit(CAR(val1012_646), CDR(val1012_646));
}
 else {
return val1012_646;
}
}
}
}
}


/* handling_function1085 */obj_t handling_function1085___r4_control_features_6_9(obj_t thunk_700)
{
jmp_buf jmpbuf;
obj_t an_exit1013_648;
if( SET_EXIT(an_exit1013_648) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1013_648 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1013_648, ((bool_t)0));
{
obj_t val1014_649;
val1014_649 = PROCEDURE_ENTRY(thunk_700)(thunk_700, BEOA);
POP_EXIT();
return val1014_649;
}
}
}
}


/* _dynamic-wind1197 */obj_t _dynamic_wind1197_47___r4_control_features_6_9(obj_t env_696, obj_t before_697, obj_t thunk_698, obj_t after_699)
{
return dynamic_wind_31___r4_control_features_6_9(before_697, thunk_698, after_699);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_control_features_6_9()
{
return module_initialization_70___error(((long)0), "__R4_CONTROL_FEATURES_6_9");
}

