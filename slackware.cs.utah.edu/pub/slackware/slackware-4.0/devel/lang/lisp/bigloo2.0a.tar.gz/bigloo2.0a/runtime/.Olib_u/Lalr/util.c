/*===========================================================================*/
/*   (Lalr/util.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t filter___lalr_util(obj_t, obj_t);
static obj_t _pos_in_list_3___lalr_util(obj_t, obj_t, obj_t);
static obj_t loop_1167___lalr_util(obj_t, obj_t);
static obj_t loop_1166___lalr_util(obj_t, obj_t);
static obj_t _filter___lalr_util(obj_t, obj_t, obj_t);
static obj_t loop___lalr_util(obj_t, obj_t);
extern obj_t pos_in_list_75___lalr_util(obj_t, obj_t);
static obj_t _sinsert___lalr_util(obj_t, obj_t, obj_t);
extern obj_t sunion___lalr_util(obj_t, obj_t);
extern obj_t module_initialization_70___lalr_util(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _sunion___lalr_util(obj_t, obj_t, obj_t);
extern obj_t sinsert___lalr_util(obj_t, obj_t);
static obj_t imported_modules_init_94___lalr_util();
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t require_initialization_114___lalr_util = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( sinsert_env_69___lalr_util, _sinsert___lalr_util1169, _sinsert___lalr_util, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( pos_in_list_env_163___lalr_util, _pos_in_list_3___lalr_util1170, _pos_in_list_3___lalr_util, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( filter_env_125___lalr_util, _filter___lalr_util1171, _filter___lalr_util, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( sunion_env_183___lalr_util, _sunion___lalr_util1172, _sunion___lalr_util, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___lalr_util(long checksum_600, char * from_601)
{
if(CBOOL(require_initialization_114___lalr_util)){
require_initialization_114___lalr_util = BBOOL(((bool_t)0));
imported_modules_init_94___lalr_util();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* pos-in-list */obj_t pos_in_list_75___lalr_util(obj_t x_1, obj_t lst_2)
{
{
obj_t lst_504;
long i_505;
lst_504 = lst_2;
i_505 = ((long)0);
loop_503:
if(PAIRP(lst_504)){
if(equal__25___r4_equivalence_6_2(CAR(lst_504), x_1)){
return BINT(i_505);
}
 else {
{
long i_614;
obj_t lst_612;
lst_612 = CDR(lst_504);
i_614 = (i_505+((long)1));
i_505 = i_614;
lst_504 = lst_612;
goto loop_503;
}
}
}
 else {
return BFALSE;
}
}
}


/* _pos-in-list */obj_t _pos_in_list_3___lalr_util(obj_t env_580, obj_t x_581, obj_t lst_582)
{
return pos_in_list_75___lalr_util(x_581, lst_582);
}


/* sunion */obj_t sunion___lalr_util(obj_t lst1_3, obj_t lst2_4)
{
return loop_1167___lalr_util(lst1_3, lst2_4);
}


/* loop_1167 */obj_t loop_1167___lalr_util(obj_t l1_332, obj_t l2_333)
{
loop_1167___lalr_util:
if(NULLP(l1_332)){
return l2_333;
}
 else {
if(NULLP(l2_333)){
return l1_332;
}
 else {
{
obj_t x_337;
obj_t y_338;
x_337 = CAR(l1_332);
y_338 = CAR(l2_333);
{
bool_t test_624;
{
long aux_627;
long aux_625;
aux_627 = (long)CINT(y_338);
aux_625 = (long)CINT(x_337);
test_624 = (aux_625>aux_627);
}
if(test_624){
{
obj_t arg1014_340;
arg1014_340 = loop_1167___lalr_util(l1_332, CDR(l2_333));
return MAKE_PAIR(y_338, arg1014_340);
}
}
 else {
bool_t test_633;
{
long aux_636;
long aux_634;
aux_636 = (long)CINT(y_338);
aux_634 = (long)CINT(x_337);
test_633 = (aux_634<aux_636);
}
if(test_633){
{
obj_t arg1017_343;
arg1017_343 = loop_1167___lalr_util(CDR(l1_332), l2_333);
return MAKE_PAIR(x_337, arg1017_343);
}
}
 else {
{
obj_t l1_642;
l1_642 = CDR(l1_332);
l1_332 = l1_642;
goto loop_1167___lalr_util;
}
}
}
}
}
}
}
}


/* _sunion */obj_t _sunion___lalr_util(obj_t env_583, obj_t lst1_584, obj_t lst2_585)
{
{
obj_t lst1_594;
obj_t lst2_595;
lst1_594 = lst1_584;
lst2_595 = lst2_585;
return loop_1167___lalr_util(lst1_594, lst2_595);
}
}


/* sinsert */obj_t sinsert___lalr_util(obj_t elem_5, obj_t lst_6)
{
return loop_1166___lalr_util(elem_5, lst_6);
}


/* loop_1166 */obj_t loop_1166___lalr_util(obj_t elem_593, obj_t l1_346)
{
if(NULLP(l1_346)){
return MAKE_PAIR(elem_593, l1_346);
}
 else {
obj_t x_349;
x_349 = CAR(l1_346);
{
bool_t test_650;
{
long aux_653;
long aux_651;
aux_653 = (long)CINT(x_349);
aux_651 = (long)CINT(elem_593);
test_650 = (aux_651<aux_653);
}
if(test_650){
return MAKE_PAIR(elem_593, l1_346);
}
 else {
bool_t test_657;
{
long aux_660;
long aux_658;
aux_660 = (long)CINT(x_349);
aux_658 = (long)CINT(elem_593);
test_657 = (aux_658>aux_660);
}
if(test_657){
{
obj_t arg1023_352;
arg1023_352 = loop_1166___lalr_util(elem_593, CDR(l1_346));
return MAKE_PAIR(x_349, arg1023_352);
}
}
 else {
return l1_346;
}
}
}
}
}


/* _sinsert */obj_t _sinsert___lalr_util(obj_t env_586, obj_t elem_587, obj_t lst_588)
{
{
obj_t elem_596;
obj_t lst_597;
elem_596 = elem_587;
lst_597 = lst_588;
return loop_1166___lalr_util(elem_596, lst_597);
}
}


/* filter */obj_t filter___lalr_util(obj_t p_7, obj_t lst_8)
{
return loop___lalr_util(p_7, lst_8);
}


/* loop */obj_t loop___lalr_util(obj_t p_592, obj_t l_354)
{
loop___lalr_util:
if(NULLP(l_354)){
return BNIL;
}
 else {
obj_t x_357;
obj_t y_358;
x_357 = CAR(l_354);
y_358 = CDR(l_354);
{
bool_t test1027_359;
{
obj_t aux_672;
aux_672 = PROCEDURE_ENTRY(p_592)(p_592, x_357, BEOA);
test1027_359 = CBOOL(aux_672);
}
if(test1027_359){
obj_t arg1028_360;
arg1028_360 = loop___lalr_util(p_592, y_358);
return MAKE_PAIR(x_357, arg1028_360);
}
 else {
obj_t l_679;
l_679 = y_358;
l_354 = l_679;
goto loop___lalr_util;
}
}
}
}


/* _filter */obj_t _filter___lalr_util(obj_t env_589, obj_t p_590, obj_t lst_591)
{
{
obj_t p_598;
obj_t lst_599;
p_598 = p_590;
lst_599 = lst_591;
return loop___lalr_util(p_598, lst_599);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___lalr_util()
{
return module_initialization_70___error(((long)0), "__LALR_UTIL");
}

