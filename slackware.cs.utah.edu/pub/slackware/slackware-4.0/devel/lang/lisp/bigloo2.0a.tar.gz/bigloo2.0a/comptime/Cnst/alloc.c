/*===========================================================================*/
/*   (Cnst/alloc.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t _keyword_env__205_cnst_alloc = BUNSPEC;
static obj_t method_init_76_cnst_alloc();
extern obj_t _vector_tag_set___225_cnst_cache;
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t _symbol__163_type_cache;
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
static obj_t _old_debug__29_cnst_alloc = BUNSPEC;
extern obj_t stop_cnst_alloc__36_cnst_alloc();
static obj_t _start_cnst_alloc__241_cnst_alloc(obj_t);
static obj_t _cnst_table__103_cnst_alloc = BUNSPEC;
extern bool_t tvector_c_static__211_tvector_cnst(obj_t);
extern global_t def_global_scnst__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t _shared_cnst___67_engine_param;
extern obj_t sequence_ast_node;
extern node_t cnst_alloc_procedure_240_cnst_alloc(node_t, obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t _get_cnst_set_97_cnst_alloc(obj_t);
extern obj_t start_cnst_alloc__206_cnst_alloc();
extern obj_t get_cnst_offset_21_cnst_alloc();
extern obj_t create_struct(obj_t, long);
extern obj_t _pair__244_type_cache;
extern obj_t _bdb_debug__1_engine_param;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
static obj_t _cnst_alloc_tvector_13_cnst_alloc(obj_t, obj_t, obj_t);
static obj_t _get_cnst_sexp_123_cnst_alloc(obj_t);
static obj_t _vector_env__150_cnst_alloc = BUNSPEC;
extern obj_t get_hash_29___hash(obj_t, obj_t);
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_cnst_alloc(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70_tvector_cnst(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_cnst_cache(long, char *);
extern obj_t module_initialization_70_cnst_node(long, char *);
extern obj_t module_initialization_70___hash(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t _bnil__15_type_cache;
static obj_t _global_sexp__67_cnst_alloc = BUNSPEC;
extern long get_hash_power_number(char *, long);
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
static obj_t _cnst_alloc_string2206_180_cnst_alloc(obj_t, obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _get_cnst_offset_51_cnst_alloc(obj_t);
extern obj_t _cons__148_cnst_cache;
static app_t make_cnst_table_ref_93_cnst_alloc(obj_t, obj_t);
static obj_t _cnst_table_id_95_cnst_alloc(obj_t);
static obj_t _cnst_alloc_vector2211_224_cnst_alloc(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_cnst_alloc();
extern obj_t _keyword__63_type_cache;
extern node_t cnst_alloc_list_56_cnst_alloc(obj_t, obj_t);
static obj_t _cnst_alloc_symbol2207_217_cnst_alloc(obj_t, obj_t, obj_t);
extern node_t cnst_alloc_real_118_cnst_alloc(obj_t, obj_t);
extern node_t coerce__182_coerce_coerce(node_t, type_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cnst_alloc();
static obj_t cnst_list_66_cnst_alloc(obj_t, obj_t);
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern obj_t _string__symbol__115_cnst_cache;
static obj_t typed_cnst_table_id_34_cnst_alloc();
static obj_t _get_cnst_table_79_cnst_alloc(obj_t);
extern obj_t atom_ast_node;
extern obj_t _list__vector__161_cnst_cache;
static obj_t toplevel_init_63_cnst_alloc();
static obj_t _cnst_alloc_procedure2209_10_cnst_alloc(obj_t, obj_t, obj_t);
static obj_t _string_env__83_cnst_alloc = BUNSPEC;
static obj_t _global_set__17_cnst_alloc = BUNSPEC;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t _cnst_table_ref__15_cnst_cache;
static obj_t _string__2205_21___r4_strings_6_7(obj_t, obj_t, obj_t);
static obj_t _cnst_info_cnst_76_cnst_alloc(obj_t, obj_t);
extern obj_t put_hash__129___hash(obj_t, obj_t);
static obj_t _cnst_alloc_list_46_cnst_alloc(obj_t, obj_t, obj_t);
static obj_t _symbol_env__148_cnst_alloc = BUNSPEC;
extern node_t cnst_alloc_tvector_190_cnst_alloc(obj_t, obj_t);
extern obj_t _bstring__127_type_cache;
extern obj_t get_cnst_sexp_197_cnst_alloc();
static obj_t loop_cnst_alloc(obj_t, obj_t);
static obj_t arg1592_cnst_alloc(obj_t, obj_t);
static obj_t arg1584_cnst_alloc(obj_t, obj_t);
static obj_t arg1580_cnst_alloc(obj_t, obj_t);
static obj_t _real_env__85_cnst_alloc = BUNSPEC;
extern node_t cnst_alloc_string_41_cnst_alloc(obj_t, obj_t);
extern obj_t _init_mode__183_engine_param;
extern node_t cnst_alloc_symbol_123_cnst_alloc(obj_t, obj_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t get_cnst_table_42_cnst_alloc();
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _list_env__66_cnst_alloc = BUNSPEC;
extern obj_t _module__166_module_module;
static obj_t _cnst_alloc_keyword2208_158_cnst_alloc(obj_t, obj_t, obj_t);
static long _cnst_offset__211_cnst_alloc;
static obj_t _cnst_alloc_real2210_68_cnst_alloc(obj_t, obj_t, obj_t);
extern obj_t _string__keyword__251_cnst_cache;
static obj_t cnst_info_cnst_73_cnst_alloc(obj_t);
extern obj_t get_cnst_set_138_cnst_alloc();
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cnst_table_id_232_cnst_alloc();
extern global_t def_global_svar__184_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t _string__3_type_cache;
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern node_t cnst_alloc_vector_65_cnst_alloc(obj_t, obj_t);
static obj_t require_initialization_114_cnst_alloc = BUNSPEC;
extern obj_t _vector__240_type_cache;
extern node_t cnst_alloc_keyword_47_cnst_alloc(obj_t, obj_t);
extern node_t cnst__44_cnst_node(node_t);
static obj_t _stop_cnst_alloc__84_cnst_alloc(obj_t);
static obj_t cnst_init_137_cnst_alloc();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[35];

DEFINE_EXPORT_PROCEDURE(get_cnst_set_env_67_cnst_alloc, _get_cnst_set_97_cnst_alloc2223, _get_cnst_set_97_cnst_alloc, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_string_env_66_cnst_alloc, _cnst_alloc_string2206_180_cnst_alloc2224, _cnst_alloc_string2206_180_cnst_alloc, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_procedure_env_95_cnst_alloc, _cnst_alloc_procedure2209_10_cnst_alloc2225, _cnst_alloc_procedure2209_10_cnst_alloc, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2214_cnst_alloc, arg1592_cnst_alloc2226, arg1592_cnst_alloc, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2213_cnst_alloc, arg1584_cnst_alloc2227, arg1584_cnst_alloc, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2212_cnst_alloc, arg1580_cnst_alloc2228, arg1580_cnst_alloc, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cnst_table_id_env_96_cnst_alloc, _cnst_table_id_95_cnst_alloc2229, _cnst_table_id_95_cnst_alloc, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_vector_env_32_cnst_alloc, _cnst_alloc_vector2211_224_cnst_alloc2230, _cnst_alloc_vector2211_224_cnst_alloc, 0L, 2);
extern obj_t eq__env_189___r4_equivalence_6_2;
DEFINE_EXPORT_PROCEDURE(cnst_alloc_symbol_env_229_cnst_alloc, _cnst_alloc_symbol2207_217_cnst_alloc2231, _cnst_alloc_symbol2207_217_cnst_alloc, 0L, 2);
DEFINE_EXPORT_PROCEDURE(get_cnst_sexp_env_244_cnst_alloc, _get_cnst_sexp_123_cnst_alloc2232, _get_cnst_sexp_123_cnst_alloc, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_tvector_env_188_cnst_alloc, _cnst_alloc_tvector_13_cnst_alloc2233, _cnst_alloc_tvector_13_cnst_alloc, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_real_env_220_cnst_alloc, _cnst_alloc_real2210_68_cnst_alloc2234, _cnst_alloc_real2210_68_cnst_alloc, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_list_env_88_cnst_alloc, _cnst_alloc_list_46_cnst_alloc2235, _cnst_alloc_list_46_cnst_alloc, 0L, 2);
DEFINE_STATIC_PROCEDURE(cnst_info_cnst_env_83_cnst_alloc, _cnst_info_cnst_76_cnst_alloc2236, _cnst_info_cnst_76_cnst_alloc, 0L, 1);
DEFINE_EXPORT_PROCEDURE(start_cnst_alloc__env_227_cnst_alloc, _start_cnst_alloc__241_cnst_alloc2237, _start_cnst_alloc__241_cnst_alloc, 0L, 0);
DEFINE_EXPORT_PROCEDURE(stop_cnst_alloc__env_174_cnst_alloc, _stop_cnst_alloc__84_cnst_alloc2238, _stop_cnst_alloc__84_cnst_alloc, 0L, 0);
DEFINE_EXPORT_PROCEDURE(get_cnst_table_env_73_cnst_alloc, _get_cnst_table_79_cnst_alloc2239, _get_cnst_table_79_cnst_alloc, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cnst_alloc_keyword_env_61_cnst_alloc, _cnst_alloc_keyword2208_158_cnst_alloc2240, _cnst_alloc_keyword2208_158_cnst_alloc, 0L, 2);
DEFINE_STRING(string2217_cnst_alloc, string2217_cnst_alloc2241, "GET-TVECTOR-DESCRIPTOR TVECTOR-DESCR-SET! STVECTOR ::TVECTOR TVEC VAR ::VECTOR VECTOR CNST-LIST ::PAIR LIST SREAL ::REAL REAL SFUN ::PROCEDURE PROC A-KEYWORD ::KEYWORD KEYWORD LIB @ SET! A-SYMBOL ::SYMBOL SYMBOL CNST-INFO SSTRING ::BSTRING STRING STATIC NOW CNST-VECTOR ::CNST* __CNSTS_TABLE ", 292);
DEFINE_STRING(string2216_cnst_alloc, string2216_cnst_alloc2242, "Unimplementable until bootstrap", 31);
DEFINE_STRING(string2215_cnst_alloc, string2215_cnst_alloc2243, "read-alloc-tvector", 18);
extern obj_t string___env_211___r4_strings_6_7;
DEFINE_EXPORT_PROCEDURE(get_cnst_offset_env_123_cnst_alloc, _get_cnst_offset_51_cnst_alloc2244, _get_cnst_offset_51_cnst_alloc, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_cnst_alloc(long checksum_2719, char *from_2720)
{
   if (CBOOL(require_initialization_114_cnst_alloc))
     {
	require_initialization_114_cnst_alloc = BBOOL(((bool_t) 0));
	library_modules_init_112_cnst_alloc();
	cnst_init_137_cnst_alloc();
	imported_modules_init_94_cnst_alloc();
	method_init_76_cnst_alloc();
	toplevel_init_63_cnst_alloc();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cnst_alloc()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "CNST_ALLOC");
   module_initialization_70___r4_vectors_6_8(((long) 0), "CNST_ALLOC");
   module_initialization_70___hash(((long) 0), "CNST_ALLOC");
   module_initialization_70___object(((long) 0), "CNST_ALLOC");
   module_initialization_70___reader(((long) 0), "CNST_ALLOC");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CNST_ALLOC");
   module_initialization_70___r4_equivalence_6_2(((long) 0), "CNST_ALLOC");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cnst_alloc()
{
   {
      obj_t cnst_port_138_2711;
      cnst_port_138_2711 = open_input_string(string2217_cnst_alloc);
      {
	 long i_2712;
	 i_2712 = ((long) 34);
       loop_2713:
	 {
	    bool_t test2218_2714;
	    test2218_2714 = (i_2712 == ((long) -1));
	    if (test2218_2714)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2219_2715;
		    {
		       obj_t list2220_2716;
		       {
			  obj_t arg2221_2717;
			  arg2221_2717 = BNIL;
			  list2220_2716 = MAKE_PAIR(cnst_port_138_2711, arg2221_2717);
		       }
		       arg2219_2715 = read___reader(list2220_2716);
		    }
		    CNST_TABLE_SET(i_2712, arg2219_2715);
		 }
		 {
		    int aux_2718;
		    {
		       long aux_2742;
		       aux_2742 = (i_2712 - ((long) 1));
		       aux_2718 = (int) (aux_2742);
		    }
		    {
		       long i_2745;
		       i_2745 = (long) (aux_2718);
		       i_2712 = i_2745;
		       goto loop_2713;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cnst_alloc()
{
   _cnst_table__103_cnst_alloc = BUNSPEC;
   _cnst_offset__211_cnst_alloc = ((long) -1);
   _string_env__83_cnst_alloc = BNIL;
   _real_env__85_cnst_alloc = BNIL;
   _symbol_env__148_cnst_alloc = BNIL;
   _keyword_env__205_cnst_alloc = BNIL;
   _list_env__66_cnst_alloc = BNIL;
   _vector_env__150_cnst_alloc = BNIL;
   _global_set__17_cnst_alloc = BNIL;
   _global_sexp__67_cnst_alloc = BNIL;
   return (_old_debug__29_cnst_alloc = BUNSPEC,
      BUNSPEC);
}


/* cnst-info-cnst */ obj_t 
cnst_info_cnst_73_cnst_alloc(obj_t s_18)
{
   return STRUCT_REF(s_18, ((long) 0));
}


/* _cnst-info-cnst */ obj_t 
_cnst_info_cnst_76_cnst_alloc(obj_t env_2658, obj_t s_2659)
{
   return cnst_info_cnst_73_cnst_alloc(s_2659);
}


/* get-cnst-offset */ obj_t 
get_cnst_offset_21_cnst_alloc()
{
   return BINT(_cnst_offset__211_cnst_alloc);
}


/* _get-cnst-offset */ obj_t 
_get_cnst_offset_51_cnst_alloc(obj_t env_2660)
{
   return get_cnst_offset_21_cnst_alloc();
}


/* get-cnst-set */ obj_t 
get_cnst_set_138_cnst_alloc()
{
   return _global_set__17_cnst_alloc;
}


/* _get-cnst-set */ obj_t 
_get_cnst_set_97_cnst_alloc(obj_t env_2661)
{
   return get_cnst_set_138_cnst_alloc();
}


/* get-cnst-table */ obj_t 
get_cnst_table_42_cnst_alloc()
{
   return _cnst_table__103_cnst_alloc;
}


/* _get-cnst-table */ obj_t 
_get_cnst_table_79_cnst_alloc(obj_t env_2662)
{
   return get_cnst_table_42_cnst_alloc();
}


/* get-cnst-sexp */ obj_t 
get_cnst_sexp_197_cnst_alloc()
{
   return reverse__39___r4_pairs_and_lists_6_3(_global_sexp__67_cnst_alloc);
}


/* _get-cnst-sexp */ obj_t 
_get_cnst_sexp_123_cnst_alloc(obj_t env_2663)
{
   return get_cnst_sexp_197_cnst_alloc();
}


/* cnst-table-id */ obj_t 
cnst_table_id_232_cnst_alloc()
{
   return CNST_TABLE_REF(((long) 0));
}


/* _cnst-table-id */ obj_t 
_cnst_table_id_95_cnst_alloc(obj_t env_2664)
{
   return cnst_table_id_232_cnst_alloc();
}


/* typed-cnst-table-id */ obj_t 
typed_cnst_table_id_34_cnst_alloc()
{
   {
      obj_t arg1563_856;
      arg1563_856 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t list1565_858;
	 {
	    obj_t arg1566_859;
	    {
	       obj_t aux_2758;
	       aux_2758 = CNST_TABLE_REF(((long) 1));
	       arg1566_859 = MAKE_PAIR(aux_2758, BNIL);
	    }
	    list1565_858 = MAKE_PAIR(arg1563_856, arg1566_859);
	 }
	 return symbol_append_197___r4_symbols_6_4(list1565_858);
      }
   }
}


/* start-cnst-alloc! */ obj_t 
start_cnst_alloc__206_cnst_alloc()
{
   _old_debug__29_cnst_alloc = _compiler_debug__134_engine_param;
   _compiler_debug__134_engine_param = BINT(((long) 0));
   {
      obj_t arg1569_861;
      obj_t arg1570_862;
      obj_t arg1572_863;
      arg1569_861 = typed_cnst_table_id_34_cnst_alloc();
      arg1570_862 = CNST_TABLE_REF(((long) 2));
      arg1572_863 = CNST_TABLE_REF(((long) 3));
      {
	 global_t aux_2767;
	 aux_2767 = def_global_svar__184_ast_glo_def_117(arg1569_861, _module__166_module_module, arg1570_862, arg1572_863);
	 _cnst_table__103_cnst_alloc = (obj_t) (aux_2767);
      }
   }
   {
      bool_t test1573_864;
      {
	 long n1_1771;
	 n1_1771 = (long) CINT(_bdb_debug__1_engine_param);
	 test1573_864 = (n1_1771 > ((long) 1));
      }
      if (test1573_864)
	{
	   obj_t arg1575_865;
	   arg1575_865 = CNST_TABLE_REF(((long) 4));
	   {
	      global_t obj_1773;
	      obj_1773 = (global_t) (_cnst_table__103_cnst_alloc);
	      ((((global_t) CREF(obj_1773))->import) = ((obj_t) arg1575_865), BUNSPEC);
	   }
	}
      else
	{
	   BUNSPEC;
	}
   }
   _cnst_offset__211_cnst_alloc = ((long) 0);
   {
      obj_t arg1580_2667;
      arg1580_2667 = proc2212_cnst_alloc;
      _string_env__83_cnst_alloc = make_hash_table_174___hash(((long) 1024), arg1580_2667, cnst_info_cnst_env_83_cnst_alloc, string___env_211___r4_strings_6_7, BNIL);
   }
   _real_env__85_cnst_alloc = BNIL;
   {
      obj_t arg1584_2666;
      arg1584_2666 = proc2213_cnst_alloc;
      _symbol_env__148_cnst_alloc = make_hash_table_174___hash(((long) 1024), arg1584_2666, cnst_info_cnst_env_83_cnst_alloc, eq__env_189___r4_equivalence_6_2, BNIL);
   }
   {
      obj_t arg1592_2665;
      arg1592_2665 = proc2214_cnst_alloc;
      _keyword_env__205_cnst_alloc = make_hash_table_174___hash(((long) 1024), arg1592_2665, cnst_info_cnst_env_83_cnst_alloc, eq__env_189___r4_equivalence_6_2, BNIL);
   }
   return BTRUE;
}


/* _start-cnst-alloc! */ obj_t 
_start_cnst_alloc__241_cnst_alloc(obj_t env_2668)
{
   return start_cnst_alloc__206_cnst_alloc();
}


/* arg1592 */ obj_t 
arg1592_cnst_alloc(obj_t env_2669, obj_t s_2670)
{
   {
      obj_t s_883;
      {
	 long aux_2780;
	 s_883 = s_2670;
	 {
	    obj_t arg1595_1782;
	    arg1595_1782 = KEYWORD_TO_STRING(s_883);
	    {
	       char *aux_2782;
	       aux_2782 = BSTRING_TO_STRING(arg1595_1782);
	       aux_2780 = get_hash_power_number(aux_2782, ((long) 10));
	    }
	 }
	 return BINT(aux_2780);
      }
   }
}


/* arg1584 */ obj_t 
arg1584_cnst_alloc(obj_t env_2671, obj_t s_2672)
{
   {
      obj_t s_875;
      {
	 long aux_2786;
	 s_875 = s_2672;
	 {
	    obj_t arg1587_1777;
	    arg1587_1777 = SYMBOL_TO_STRING(s_875);
	    {
	       char *aux_2788;
	       aux_2788 = BSTRING_TO_STRING(arg1587_1777);
	       aux_2786 = get_hash_power_number(aux_2788, ((long) 10));
	    }
	 }
	 return BINT(aux_2786);
      }
   }
}


/* arg1580 */ obj_t 
arg1580_cnst_alloc(obj_t env_2673, obj_t s_2674)
{
   {
      obj_t s_869;
      {
	 long aux_2792;
	 s_869 = s_2674;
	 {
	    char *aux_2793;
	    aux_2793 = BSTRING_TO_STRING(s_869);
	    aux_2792 = get_hash_power_number(aux_2793, ((long) 10));
	 }
	 return BINT(aux_2792);
      }
   }
}


/* stop-cnst-alloc! */ obj_t 
stop_cnst_alloc__36_cnst_alloc()
{
   _compiler_debug__134_engine_param = _old_debug__29_cnst_alloc;
   _string_env__83_cnst_alloc = BUNSPEC;
   _real_env__85_cnst_alloc = BUNSPEC;
   _symbol_env__148_cnst_alloc = BUNSPEC;
   _keyword_env__205_cnst_alloc = BUNSPEC;
   _list_env__66_cnst_alloc = BUNSPEC;
   _vector_env__150_cnst_alloc = BUNSPEC;
   return BTRUE;
}


/* _stop-cnst-alloc! */ obj_t 
_stop_cnst_alloc__84_cnst_alloc(obj_t env_2681)
{
   return stop_cnst_alloc__36_cnst_alloc();
}


/* make-cnst-table-ref */ app_t 
make_cnst_table_ref_93_cnst_alloc(obj_t offset_33, obj_t loc_34)
{
   {
      type_t arg1602_889;
      var_t arg1605_891;
      obj_t arg1606_892;
      arg1602_889 = get_default_type_181_type_cache();
      {
	 type_t arg1608_894;
	 obj_t arg1609_895;
	 {
	    variable_t obj_1787;
	    obj_1787 = (variable_t) (_cnst_table_ref__15_cnst_cache);
	    arg1608_894 = (((variable_t) CREF(obj_1787))->type);
	 }
	 arg1609_895 = _cnst_table_ref__15_cnst_cache;
	 {
	    var_t res2166_1798;
	    {
	       variable_t variable_1790;
	       variable_1790 = (variable_t) (arg1609_895);
	       {
		  var_t new1232_1791;
		  new1232_1791 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
		  {
		     long arg2123_1792;
		     arg2123_1792 = class_num_218___object(var_ast_node);
		     {
			obj_t obj_1796;
			obj_1796 = (obj_t) (new1232_1791);
			(((obj_t) CREF(obj_1796))->header = MAKE_HEADER(arg2123_1792, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_2806;
		     aux_2806 = (object_t) (new1232_1791);
		     OBJECT_WIDENING_SET(aux_2806, BFALSE);
		  }
		  ((((var_t) CREF(new1232_1791))->loc) = ((obj_t) loc_34), BUNSPEC);
		  ((((var_t) CREF(new1232_1791))->type) = ((type_t) arg1608_894), BUNSPEC);
		  ((((var_t) CREF(new1232_1791))->variable) = ((variable_t) variable_1790), BUNSPEC);
		  res2166_1798 = new1232_1791;
	       }
	    }
	    arg1605_891 = res2166_1798;
	 }
      }
      {
	 atom_t arg1610_896;
	 {
	    type_t arg1615_900;
	    arg1615_900 = get_default_type_181_type_cache();
	    {
	       atom_t res2167_1809;
	       {
		  atom_t new1224_1802;
		  new1224_1802 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
		  {
		     long arg2125_1803;
		     arg2125_1803 = class_num_218___object(atom_ast_node);
		     {
			obj_t obj_1807;
			obj_1807 = (obj_t) (new1224_1802);
			(((obj_t) CREF(obj_1807))->header = MAKE_HEADER(arg2125_1803, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_2817;
		     aux_2817 = (object_t) (new1224_1802);
		     OBJECT_WIDENING_SET(aux_2817, BFALSE);
		  }
		  ((((atom_t) CREF(new1224_1802))->loc) = ((obj_t) loc_34), BUNSPEC);
		  ((((atom_t) CREF(new1224_1802))->type) = ((type_t) arg1615_900), BUNSPEC);
		  ((((atom_t) CREF(new1224_1802))->value) = ((obj_t) offset_33), BUNSPEC);
		  res2167_1809 = new1224_1802;
	       }
	       arg1610_896 = res2167_1809;
	    }
	 }
	 {
	    obj_t list1611_897;
	    {
	       obj_t aux_2823;
	       aux_2823 = (obj_t) (arg1610_896);
	       list1611_897 = MAKE_PAIR(aux_2823, BNIL);
	    }
	    arg1606_892 = list1611_897;
	 }
      }
      {
	 app_t res2168_1829;
	 {
	    obj_t key_1814;
	    key_1814 = BINT(((long) -1));
	    {
	       app_t new1266_1818;
	       new1266_1818 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
	       {
		  long arg2113_1819;
		  arg2113_1819 = class_num_218___object(app_ast_node);
		  {
		     obj_t obj_1827;
		     obj_1827 = (obj_t) (new1266_1818);
		     (((obj_t) CREF(obj_1827))->header = MAKE_HEADER(arg2113_1819, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_2831;
		  aux_2831 = (object_t) (new1266_1818);
		  OBJECT_WIDENING_SET(aux_2831, BFALSE);
	       }
	       ((((app_t) CREF(new1266_1818))->loc) = ((obj_t) loc_34), BUNSPEC);
	       ((((app_t) CREF(new1266_1818))->type) = ((type_t) arg1602_889), BUNSPEC);
	       ((((app_t) CREF(new1266_1818))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
	       ((((app_t) CREF(new1266_1818))->key) = ((obj_t) key_1814), BUNSPEC);
	       ((((app_t) CREF(new1266_1818))->fun) = ((var_t) arg1605_891), BUNSPEC);
	       ((((app_t) CREF(new1266_1818))->args) = ((obj_t) arg1606_892), BUNSPEC);
	       ((((app_t) CREF(new1266_1818))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
	       res2168_1829 = new1266_1818;
	    }
	 }
	 return res2168_1829;
      }
   }
}


/* cnst-alloc-string */ node_t 
cnst_alloc_string_41_cnst_alloc(obj_t string_35, obj_t loc_36)
{
   {
      {
	 obj_t old_903;
	 {
	    obj_t _andtest_1465_907;
	    _andtest_1465_907 = _shared_cnst___67_engine_param;
	    if (CBOOL(_andtest_1465_907))
	      {
		 old_903 = get_hash_29___hash(string_35, _string_env__83_cnst_alloc);
	      }
	    else
	      {
		 old_903 = BFALSE;
	      }
	 }
	 if (CBOOL(old_903))
	   {
	      {
		 obj_t arg1620_905;
		 arg1620_905 = _bstring__127_type_cache;
		 {
		    var_t res2169_1843;
		    {
		       type_t type_1834;
		       variable_t variable_1835;
		       type_1834 = (type_t) (arg1620_905);
		       {
			  obj_t aux_2847;
			  aux_2847 = STRUCT_REF(old_903, ((long) 1));
			  variable_1835 = (variable_t) (aux_2847);
		       }
		       {
			  var_t new1232_1836;
			  new1232_1836 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			  {
			     long arg2123_1837;
			     arg2123_1837 = class_num_218___object(var_ast_node);
			     {
				obj_t obj_1841;
				obj_1841 = (obj_t) (new1232_1836);
				(((obj_t) CREF(obj_1841))->header = MAKE_HEADER(arg2123_1837, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_2854;
			     aux_2854 = (object_t) (new1232_1836);
			     OBJECT_WIDENING_SET(aux_2854, BFALSE);
			  }
			  ((((var_t) CREF(new1232_1836))->loc) = ((obj_t) loc_36), BUNSPEC);
			  ((((var_t) CREF(new1232_1836))->type) = ((type_t) type_1834), BUNSPEC);
			  ((((var_t) CREF(new1232_1836))->variable) = ((variable_t) variable_1835), BUNSPEC);
			  res2169_1843 = new1232_1836;
		       }
		    }
		    return (node_t) (res2169_1843);
		 }
	      }
	   }
	 else
	   {
	      {
		 var_t aux_2861;
		 {
		    global_t var_909;
		    {
		       obj_t arg1628_914;
		       obj_t arg1630_915;
		       {
			  obj_t arg1632_916;
			  arg1632_916 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
			  {
			     obj_t list1634_918;
			     {
				obj_t arg1636_919;
				{
				   obj_t aux_2865;
				   aux_2865 = CNST_TABLE_REF(((long) 6));
				   arg1636_919 = MAKE_PAIR(aux_2865, BNIL);
				}
				list1634_918 = MAKE_PAIR(arg1632_916, arg1636_919);
			     }
			     arg1628_914 = symbol_append_197___r4_symbols_6_4(list1634_918);
			  }
		       }
		       arg1630_915 = CNST_TABLE_REF(((long) 7));
		       var_909 = def_global_scnst__93_ast_glo_def_117(arg1628_914, _module__166_module_module, string_35, arg1630_915);
		    }
		    if (CBOOL(_shared_cnst___67_engine_param))
		      {
			 obj_t arg1623_910;
			 {
			    obj_t new_1846;
			    {
			       obj_t aux_2874;
			       aux_2874 = CNST_TABLE_REF(((long) 8));
			       new_1846 = create_struct(aux_2874, ((long) 2));
			    }
			    {
			       obj_t aux_2877;
			       aux_2877 = (obj_t) (var_909);
			       STRUCT_SET(new_1846, ((long) 1), aux_2877);
			    }
			    STRUCT_SET(new_1846, ((long) 0), string_35);
			    arg1623_910 = new_1846;
			 }
			 put_hash__129___hash(arg1623_910, _string_env__83_cnst_alloc);
		      }
		    else
		      {
			 BUNSPEC;
		      }
		    {
		       type_t arg1625_912;
		       {
			  variable_t obj_1859;
			  obj_1859 = (variable_t) (var_909);
			  arg1625_912 = (((variable_t) CREF(obj_1859))->type);
		       }
		       {
			  var_t res2170_1870;
			  {
			     variable_t variable_1862;
			     variable_1862 = (variable_t) (var_909);
			     {
				var_t new1232_1863;
				new1232_1863 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				{
				   long arg2123_1864;
				   arg2123_1864 = class_num_218___object(var_ast_node);
				   {
				      obj_t obj_1868;
				      obj_1868 = (obj_t) (new1232_1863);
				      (((obj_t) CREF(obj_1868))->header = MAKE_HEADER(arg2123_1864, 0), BUNSPEC);
				   }
				}
				{
				   object_t aux_2889;
				   aux_2889 = (object_t) (new1232_1863);
				   OBJECT_WIDENING_SET(aux_2889, BFALSE);
				}
				((((var_t) CREF(new1232_1863))->loc) = ((obj_t) loc_36), BUNSPEC);
				((((var_t) CREF(new1232_1863))->type) = ((type_t) arg1625_912), BUNSPEC);
				((((var_t) CREF(new1232_1863))->variable) = ((variable_t) variable_1862), BUNSPEC);
				res2170_1870 = new1232_1863;
			     }
			  }
			  aux_2861 = res2170_1870;
		       }
		    }
		 }
		 return (node_t) (aux_2861);
	      }
	   }
      }
   }
}


/* _cnst-alloc-string2206 */ obj_t 
_cnst_alloc_string2206_180_cnst_alloc(obj_t env_2682, obj_t string_2683, obj_t loc_2684)
{
   {
      node_t aux_2896;
      aux_2896 = cnst_alloc_string_41_cnst_alloc(string_2683, loc_2684);
      return (obj_t) (aux_2896);
   }
}


/* cnst-alloc-symbol */ node_t 
cnst_alloc_symbol_123_cnst_alloc(obj_t symbol_37, obj_t loc_38)
{
   {
      {
	 obj_t old_925;
	 obj_t symbol_as_string_235_926;
	 old_925 = get_hash_29___hash(symbol_37, _symbol_env__148_cnst_alloc);
	 symbol_as_string_235_926 = SYMBOL_TO_STRING(symbol_37);
	 if (CBOOL(old_925))
	   {
	      {
		 bool_t test1640_927;
		 {
		    obj_t obj1_1872;
		    obj1_1872 = _init_mode__183_engine_param;
		    {
		       obj_t aux_2903;
		       aux_2903 = CNST_TABLE_REF(((long) 14));
		       test1640_927 = (obj1_1872 == aux_2903);
		    }
		 }
		 if (test1640_927)
		   {
		      type_t arg1645_929;
		      obj_t arg1646_930;
		      arg1645_929 = get_default_type_181_type_cache();
		      arg1646_930 = STRUCT_REF(old_925, ((long) 1));
		      {
			 var_t res2171_1887;
			 {
			    variable_t variable_1879;
			    variable_1879 = (variable_t) (arg1646_930);
			    {
			       var_t new1232_1880;
			       new1232_1880 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			       {
				  long arg2123_1881;
				  arg2123_1881 = class_num_218___object(var_ast_node);
				  {
				     obj_t obj_1885;
				     obj_1885 = (obj_t) (new1232_1880);
				     (((obj_t) CREF(obj_1885))->header = MAKE_HEADER(arg2123_1881, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_2914;
				  aux_2914 = (object_t) (new1232_1880);
				  OBJECT_WIDENING_SET(aux_2914, BFALSE);
			       }
			       ((((var_t) CREF(new1232_1880))->loc) = ((obj_t) loc_38), BUNSPEC);
			       ((((var_t) CREF(new1232_1880))->type) = ((type_t) arg1645_929), BUNSPEC);
			       ((((var_t) CREF(new1232_1880))->variable) = ((variable_t) variable_1879), BUNSPEC);
			       res2171_1887 = new1232_1880;
			    }
			 }
			 return (node_t) (res2171_1887);
		      }
		   }
		 else
		   {
		      app_t aux_2921;
		      aux_2921 = make_cnst_table_ref_93_cnst_alloc(STRUCT_REF(old_925, ((long) 1)), loc_38);
		      return (node_t) (aux_2921);
		   }
	      }
	   }
	 else
	   {
	      bool_t test1649_933;
	      {
		 bool_t test1650_934;
		 {
		    obj_t obj1_1891;
		    obj1_1891 = _init_mode__183_engine_param;
		    {
		       obj_t aux_2925;
		       aux_2925 = CNST_TABLE_REF(((long) 14));
		       test1650_934 = (obj1_1891 == aux_2925);
		    }
		 }
		 if (test1650_934)
		   {
		      test1649_933 = ((bool_t) 1);
		   }
		 else
		   {
		      bool_t test_2929;
		      {
			 long aux_2930;
			 aux_2930 = STRING_LENGTH(symbol_as_string_235_926);
			 test_2929 = (aux_2930 == ((long) 0));
		      }
		      if (test_2929)
			{
			   test1649_933 = ((bool_t) 1);
			}
		      else
			{
			   unsigned char aux_2933;
			   aux_2933 = STRING_REF(symbol_as_string_235_926, ((long) 0));
			   test1649_933 = (aux_2933 == ((unsigned char) ';'));
			}
		   }
	      }
	      if (test1649_933)
		{
		   {
		      var_t aux_2937;
		      {
			 global_t var_944;
			 {
			    obj_t arg1703_981;
			    obj_t arg1704_982;
			    obj_t arg1705_983;
			    {
			       obj_t arg1706_984;
			       arg1706_984 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 9)), BEOA);
			       {
				  obj_t list1708_986;
				  {
				     obj_t arg1709_987;
				     {
					obj_t aux_2941;
					aux_2941 = CNST_TABLE_REF(((long) 10));
					arg1709_987 = MAKE_PAIR(aux_2941, BNIL);
				     }
				     list1708_986 = MAKE_PAIR(arg1706_984, arg1709_987);
				  }
				  arg1703_981 = symbol_append_197___r4_symbols_6_4(list1708_986);
			       }
			    }
			    arg1704_982 = CNST_TABLE_REF(((long) 11));
			    arg1705_983 = CNST_TABLE_REF(((long) 3));
			    var_944 = def_global_svar__184_ast_glo_def_117(arg1703_981, _module__166_module_module, arg1704_982, arg1705_983);
			 }
			 {
			    obj_t arg1659_945;
			    {
			       obj_t new_1921;
			       {
				  obj_t aux_2949;
				  aux_2949 = CNST_TABLE_REF(((long) 8));
				  new_1921 = create_struct(aux_2949, ((long) 2));
			       }
			       {
				  obj_t aux_2952;
				  aux_2952 = (obj_t) (var_944);
				  STRUCT_SET(new_1921, ((long) 1), aux_2952);
			       }
			       STRUCT_SET(new_1921, ((long) 0), symbol_37);
			       arg1659_945 = new_1921;
			    }
			    put_hash__129___hash(arg1659_945, _symbol_env__148_cnst_alloc);
			 }
			 {
			    obj_t arg1661_946;
			    {
			       obj_t arg1663_947;
			       obj_t arg1665_948;
			       node_t arg1666_949;
			       arg1663_947 = CNST_TABLE_REF(((long) 12));
			       {
				  obj_t arg1673_955;
				  obj_t arg1675_956;
				  obj_t arg1676_957;
				  arg1673_955 = CNST_TABLE_REF(((long) 13));
				  arg1675_956 = (((global_t) CREF(var_944))->id);
				  arg1676_957 = (((global_t) CREF(var_944))->module);
				  {
				     obj_t list1678_959;
				     {
					obj_t arg1679_960;
					{
					   obj_t arg1680_961;
					   arg1680_961 = MAKE_PAIR(BNIL, BNIL);
					   arg1679_960 = MAKE_PAIR(arg1676_957, arg1680_961);
					}
					list1678_959 = MAKE_PAIR(arg1675_956, arg1679_960);
				     }
				     arg1665_948 = cons__138___r4_pairs_and_lists_6_3(arg1673_955, list1678_959);
				  }
			       }
			       {
				  app_t arg1682_963;
				  {
				     obj_t arg1684_965;
				     var_t arg1686_967;
				     obj_t arg1688_968;
				     arg1684_965 = _symbol__163_type_cache;
				     {
					obj_t arg1691_970;
					obj_t arg1692_971;
					arg1691_970 = _symbol__163_type_cache;
					arg1692_971 = _string__symbol__115_cnst_cache;
					{
					   var_t res2172_1946;
					   {
					      type_t type_1937;
					      variable_t variable_1938;
					      type_1937 = (type_t) (arg1691_970);
					      variable_1938 = (variable_t) (arg1692_971);
					      {
						 var_t new1232_1939;
						 new1232_1939 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						 {
						    long arg2123_1940;
						    arg2123_1940 = class_num_218___object(var_ast_node);
						    {
						       obj_t obj_1944;
						       obj_1944 = (obj_t) (new1232_1939);
						       (((obj_t) CREF(obj_1944))->header = MAKE_HEADER(arg2123_1940, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_2971;
						    aux_2971 = (object_t) (new1232_1939);
						    OBJECT_WIDENING_SET(aux_2971, BFALSE);
						 }
						 ((((var_t) CREF(new1232_1939))->loc) = ((obj_t) loc_38), BUNSPEC);
						 ((((var_t) CREF(new1232_1939))->type) = ((type_t) type_1937), BUNSPEC);
						 ((((var_t) CREF(new1232_1939))->variable) = ((variable_t) variable_1938), BUNSPEC);
						 res2172_1946 = new1232_1939;
					      }
					   }
					   arg1686_967 = res2172_1946;
					}
				     }
				     {
					atom_t arg1693_972;
					{
					   obj_t arg1698_976;
					   obj_t arg1699_977;
					   arg1698_976 = _string__3_type_cache;
					   arg1699_977 = SYMBOL_TO_STRING(symbol_37);
					   {
					      atom_t res2173_1958;
					      {
						 type_t type_1949;
						 type_1949 = (type_t) (arg1698_976);
						 {
						    atom_t new1224_1951;
						    new1224_1951 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
						    {
						       long arg2125_1952;
						       arg2125_1952 = class_num_218___object(atom_ast_node);
						       {
							  obj_t obj_1956;
							  obj_1956 = (obj_t) (new1224_1951);
							  (((obj_t) CREF(obj_1956))->header = MAKE_HEADER(arg2125_1952, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_2983;
						       aux_2983 = (object_t) (new1224_1951);
						       OBJECT_WIDENING_SET(aux_2983, BFALSE);
						    }
						    ((((atom_t) CREF(new1224_1951))->loc) = ((obj_t) loc_38), BUNSPEC);
						    ((((atom_t) CREF(new1224_1951))->type) = ((type_t) type_1949), BUNSPEC);
						    ((((atom_t) CREF(new1224_1951))->value) = ((obj_t) arg1699_977), BUNSPEC);
						    res2173_1958 = new1224_1951;
						 }
					      }
					      arg1693_972 = res2173_1958;
					   }
					}
					{
					   obj_t list1694_973;
					   {
					      obj_t aux_2989;
					      aux_2989 = (obj_t) (arg1693_972);
					      list1694_973 = MAKE_PAIR(aux_2989, BNIL);
					   }
					   arg1688_968 = list1694_973;
					}
				     }
				     {
					app_t res2174_1978;
					{
					   type_t type_1961;
					   obj_t key_1963;
					   type_1961 = (type_t) (arg1684_965);
					   key_1963 = BINT(((long) -1));
					   {
					      app_t new1266_1967;
					      new1266_1967 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
					      {
						 long arg2113_1968;
						 arg2113_1968 = class_num_218___object(app_ast_node);
						 {
						    obj_t obj_1976;
						    obj_1976 = (obj_t) (new1266_1967);
						    (((obj_t) CREF(obj_1976))->header = MAKE_HEADER(arg2113_1968, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_2998;
						 aux_2998 = (object_t) (new1266_1967);
						 OBJECT_WIDENING_SET(aux_2998, BFALSE);
					      }
					      ((((app_t) CREF(new1266_1967))->loc) = ((obj_t) loc_38), BUNSPEC);
					      ((((app_t) CREF(new1266_1967))->type) = ((type_t) type_1961), BUNSPEC);
					      ((((app_t) CREF(new1266_1967))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					      ((((app_t) CREF(new1266_1967))->key) = ((obj_t) key_1963), BUNSPEC);
					      ((((app_t) CREF(new1266_1967))->fun) = ((var_t) arg1686_967), BUNSPEC);
					      ((((app_t) CREF(new1266_1967))->args) = ((obj_t) arg1688_968), BUNSPEC);
					      ((((app_t) CREF(new1266_1967))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
					      res2174_1978 = new1266_1967;
					   }
					}
					arg1682_963 = res2174_1978;
				     }
				  }
				  arg1666_949 = coerce__182_coerce_coerce((node_t) (arg1682_963), (type_t) (_obj__252_type_cache));
			       }
			       {
				  obj_t list1668_951;
				  {
				     obj_t arg1669_952;
				     {
					obj_t arg1670_953;
					arg1670_953 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t aux_3012;
					   aux_3012 = (obj_t) (arg1666_949);
					   arg1669_952 = MAKE_PAIR(aux_3012, arg1670_953);
					}
				     }
				     list1668_951 = MAKE_PAIR(arg1665_948, arg1669_952);
				  }
				  arg1661_946 = cons__138___r4_pairs_and_lists_6_3(arg1663_947, list1668_951);
			       }
			    }
			    {
			       obj_t obj2_1981;
			       obj2_1981 = _global_sexp__67_cnst_alloc;
			       _global_sexp__67_cnst_alloc = MAKE_PAIR(arg1661_946, obj2_1981);
			    }
			 }
			 {
			    type_t arg1701_979;
			    {
			       variable_t obj_1982;
			       obj_1982 = (variable_t) (var_944);
			       arg1701_979 = (((variable_t) CREF(obj_1982))->type);
			    }
			    {
			       var_t res2175_1993;
			       {
				  variable_t variable_1985;
				  variable_1985 = (variable_t) (var_944);
				  {
				     var_t new1232_1986;
				     new1232_1986 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				     {
					long arg2123_1987;
					arg2123_1987 = class_num_218___object(var_ast_node);
					{
					   obj_t obj_1991;
					   obj_1991 = (obj_t) (new1232_1986);
					   (((obj_t) CREF(obj_1991))->header = MAKE_HEADER(arg2123_1987, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_3025;
					aux_3025 = (object_t) (new1232_1986);
					OBJECT_WIDENING_SET(aux_3025, BFALSE);
				     }
				     ((((var_t) CREF(new1232_1986))->loc) = ((obj_t) loc_38), BUNSPEC);
				     ((((var_t) CREF(new1232_1986))->type) = ((type_t) arg1701_979), BUNSPEC);
				     ((((var_t) CREF(new1232_1986))->variable) = ((variable_t) variable_1985), BUNSPEC);
				     res2175_1993 = new1232_1986;
				  }
			       }
			       aux_2937 = res2175_1993;
			    }
			 }
		      }
		      return (node_t) (aux_2937);
		   }
		}
	      else
		{
		   {
		      app_t aux_3032;
		      {
			 long offset_941;
			 offset_941 = _cnst_offset__211_cnst_alloc;
			 {
			    long z2_1901;
			    z2_1901 = _cnst_offset__211_cnst_alloc;
			    _cnst_offset__211_cnst_alloc = (((long) 1) + z2_1901);
			 }
			 {
			    obj_t obj2_1903;
			    obj2_1903 = _global_set__17_cnst_alloc;
			    _global_set__17_cnst_alloc = MAKE_PAIR(symbol_37, obj2_1903);
			 }
			 {
			    obj_t arg1657_942;
			    {
			       obj_t new_1906;
			       {
				  obj_t aux_3035;
				  aux_3035 = CNST_TABLE_REF(((long) 8));
				  new_1906 = create_struct(aux_3035, ((long) 2));
			       }
			       {
				  obj_t aux_3038;
				  aux_3038 = BINT(offset_941);
				  STRUCT_SET(new_1906, ((long) 1), aux_3038);
			       }
			       STRUCT_SET(new_1906, ((long) 0), symbol_37);
			       arg1657_942 = new_1906;
			    }
			    put_hash__129___hash(arg1657_942, _symbol_env__148_cnst_alloc);
			 }
			 aux_3032 = make_cnst_table_ref_93_cnst_alloc(BINT(offset_941), loc_38);
		      }
		      return (node_t) (aux_3032);
		   }
		}
	   }
      }
   }
}


/* _cnst-alloc-symbol2207 */ obj_t 
_cnst_alloc_symbol2207_217_cnst_alloc(obj_t env_2685, obj_t symbol_2686, obj_t loc_2687)
{
   {
      node_t aux_3046;
      aux_3046 = cnst_alloc_symbol_123_cnst_alloc(symbol_2686, loc_2687);
      return (obj_t) (aux_3046);
   }
}


/* cnst-alloc-keyword */ node_t 
cnst_alloc_keyword_47_cnst_alloc(obj_t keyword_39, obj_t loc_40)
{
   {
      {
	 obj_t old_994;
	 obj_t keyword_as_string_123_995;
	 old_994 = get_hash_29___hash(keyword_39, _keyword_env__205_cnst_alloc);
	 keyword_as_string_123_995 = KEYWORD_TO_STRING(keyword_39);
	 if (CBOOL(old_994))
	   {
	      {
		 bool_t test1712_996;
		 {
		    obj_t obj1_1995;
		    obj1_1995 = _init_mode__183_engine_param;
		    {
		       obj_t aux_3053;
		       aux_3053 = CNST_TABLE_REF(((long) 14));
		       test1712_996 = (obj1_1995 == aux_3053);
		    }
		 }
		 if (test1712_996)
		   {
		      type_t arg1714_998;
		      obj_t arg1716_999;
		      arg1714_998 = get_default_type_181_type_cache();
		      arg1716_999 = STRUCT_REF(old_994, ((long) 1));
		      {
			 var_t res2176_2010;
			 {
			    variable_t variable_2002;
			    variable_2002 = (variable_t) (arg1716_999);
			    {
			       var_t new1232_2003;
			       new1232_2003 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			       {
				  long arg2123_2004;
				  arg2123_2004 = class_num_218___object(var_ast_node);
				  {
				     obj_t obj_2008;
				     obj_2008 = (obj_t) (new1232_2003);
				     (((obj_t) CREF(obj_2008))->header = MAKE_HEADER(arg2123_2004, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_3064;
				  aux_3064 = (object_t) (new1232_2003);
				  OBJECT_WIDENING_SET(aux_3064, BFALSE);
			       }
			       ((((var_t) CREF(new1232_2003))->loc) = ((obj_t) loc_40), BUNSPEC);
			       ((((var_t) CREF(new1232_2003))->type) = ((type_t) arg1714_998), BUNSPEC);
			       ((((var_t) CREF(new1232_2003))->variable) = ((variable_t) variable_2002), BUNSPEC);
			       res2176_2010 = new1232_2003;
			    }
			 }
			 return (node_t) (res2176_2010);
		      }
		   }
		 else
		   {
		      app_t aux_3071;
		      aux_3071 = make_cnst_table_ref_93_cnst_alloc(STRUCT_REF(old_994, ((long) 1)), loc_40);
		      return (node_t) (aux_3071);
		   }
	      }
	   }
	 else
	   {
	      bool_t test1719_1002;
	      {
		 bool_t test1720_1003;
		 {
		    obj_t obj1_2014;
		    obj1_2014 = _init_mode__183_engine_param;
		    {
		       obj_t aux_3075;
		       aux_3075 = CNST_TABLE_REF(((long) 14));
		       test1720_1003 = (obj1_2014 == aux_3075);
		    }
		 }
		 if (test1720_1003)
		   {
		      test1719_1002 = ((bool_t) 1);
		   }
		 else
		   {
		      bool_t test_3079;
		      {
			 long aux_3080;
			 aux_3080 = STRING_LENGTH(keyword_as_string_123_995);
			 test_3079 = (aux_3080 == ((long) 0));
		      }
		      if (test_3079)
			{
			   test1719_1002 = ((bool_t) 1);
			}
		      else
			{
			   unsigned char aux_3083;
			   aux_3083 = STRING_REF(keyword_as_string_123_995, ((long) 0));
			   test1719_1002 = (aux_3083 == ((unsigned char) ';'));
			}
		   }
	      }
	      if (test1719_1002)
		{
		   {
		      var_t aux_3087;
		      {
			 global_t var_1013;
			 {
			    obj_t arg1780_1050;
			    obj_t arg1781_1051;
			    obj_t arg1783_1052;
			    {
			       obj_t arg1786_1053;
			       arg1786_1053 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 15)), BEOA);
			       {
				  obj_t list1789_1055;
				  {
				     obj_t arg1790_1056;
				     {
					obj_t aux_3091;
					aux_3091 = CNST_TABLE_REF(((long) 16));
					arg1790_1056 = MAKE_PAIR(aux_3091, BNIL);
				     }
				     list1789_1055 = MAKE_PAIR(arg1786_1053, arg1790_1056);
				  }
				  arg1780_1050 = symbol_append_197___r4_symbols_6_4(list1789_1055);
			       }
			    }
			    arg1781_1051 = CNST_TABLE_REF(((long) 17));
			    arg1783_1052 = CNST_TABLE_REF(((long) 3));
			    var_1013 = def_global_svar__184_ast_glo_def_117(arg1780_1050, _module__166_module_module, arg1781_1051, arg1783_1052);
			 }
			 {
			    obj_t arg1729_1014;
			    {
			       obj_t new_2044;
			       {
				  obj_t aux_3099;
				  aux_3099 = CNST_TABLE_REF(((long) 8));
				  new_2044 = create_struct(aux_3099, ((long) 2));
			       }
			       {
				  obj_t aux_3102;
				  aux_3102 = (obj_t) (var_1013);
				  STRUCT_SET(new_2044, ((long) 1), aux_3102);
			       }
			       STRUCT_SET(new_2044, ((long) 0), keyword_39);
			       arg1729_1014 = new_2044;
			    }
			    put_hash__129___hash(arg1729_1014, _keyword_env__205_cnst_alloc);
			 }
			 {
			    obj_t arg1730_1015;
			    {
			       obj_t arg1731_1016;
			       obj_t arg1732_1017;
			       node_t arg1733_1018;
			       arg1731_1016 = CNST_TABLE_REF(((long) 12));
			       {
				  obj_t arg1745_1024;
				  obj_t arg1746_1025;
				  obj_t arg1747_1026;
				  arg1745_1024 = CNST_TABLE_REF(((long) 13));
				  arg1746_1025 = (((global_t) CREF(var_1013))->id);
				  arg1747_1026 = (((global_t) CREF(var_1013))->module);
				  {
				     obj_t list1749_1028;
				     {
					obj_t arg1753_1029;
					{
					   obj_t arg1755_1030;
					   arg1755_1030 = MAKE_PAIR(BNIL, BNIL);
					   arg1753_1029 = MAKE_PAIR(arg1747_1026, arg1755_1030);
					}
					list1749_1028 = MAKE_PAIR(arg1746_1025, arg1753_1029);
				     }
				     arg1732_1017 = cons__138___r4_pairs_and_lists_6_3(arg1745_1024, list1749_1028);
				  }
			       }
			       {
				  app_t arg1759_1032;
				  {
				     obj_t arg1761_1034;
				     var_t arg1765_1036;
				     obj_t arg1766_1037;
				     arg1761_1034 = _keyword__63_type_cache;
				     {
					obj_t arg1768_1039;
					obj_t arg1769_1040;
					arg1768_1039 = _keyword__63_type_cache;
					arg1769_1040 = _string__keyword__251_cnst_cache;
					{
					   var_t res2177_2069;
					   {
					      type_t type_2060;
					      variable_t variable_2061;
					      type_2060 = (type_t) (arg1768_1039);
					      variable_2061 = (variable_t) (arg1769_1040);
					      {
						 var_t new1232_2062;
						 new1232_2062 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						 {
						    long arg2123_2063;
						    arg2123_2063 = class_num_218___object(var_ast_node);
						    {
						       obj_t obj_2067;
						       obj_2067 = (obj_t) (new1232_2062);
						       (((obj_t) CREF(obj_2067))->header = MAKE_HEADER(arg2123_2063, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_3121;
						    aux_3121 = (object_t) (new1232_2062);
						    OBJECT_WIDENING_SET(aux_3121, BFALSE);
						 }
						 ((((var_t) CREF(new1232_2062))->loc) = ((obj_t) loc_40), BUNSPEC);
						 ((((var_t) CREF(new1232_2062))->type) = ((type_t) type_2060), BUNSPEC);
						 ((((var_t) CREF(new1232_2062))->variable) = ((variable_t) variable_2061), BUNSPEC);
						 res2177_2069 = new1232_2062;
					      }
					   }
					   arg1765_1036 = res2177_2069;
					}
				     }
				     {
					atom_t arg1770_1041;
					{
					   obj_t arg1774_1045;
					   obj_t arg1776_1046;
					   arg1774_1045 = _string__3_type_cache;
					   arg1776_1046 = KEYWORD_TO_STRING(keyword_39);
					   {
					      atom_t res2178_2081;
					      {
						 type_t type_2072;
						 type_2072 = (type_t) (arg1774_1045);
						 {
						    atom_t new1224_2074;
						    new1224_2074 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
						    {
						       long arg2125_2075;
						       arg2125_2075 = class_num_218___object(atom_ast_node);
						       {
							  obj_t obj_2079;
							  obj_2079 = (obj_t) (new1224_2074);
							  (((obj_t) CREF(obj_2079))->header = MAKE_HEADER(arg2125_2075, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3133;
						       aux_3133 = (object_t) (new1224_2074);
						       OBJECT_WIDENING_SET(aux_3133, BFALSE);
						    }
						    ((((atom_t) CREF(new1224_2074))->loc) = ((obj_t) loc_40), BUNSPEC);
						    ((((atom_t) CREF(new1224_2074))->type) = ((type_t) type_2072), BUNSPEC);
						    ((((atom_t) CREF(new1224_2074))->value) = ((obj_t) arg1776_1046), BUNSPEC);
						    res2178_2081 = new1224_2074;
						 }
					      }
					      arg1770_1041 = res2178_2081;
					   }
					}
					{
					   obj_t list1771_1042;
					   {
					      obj_t aux_3139;
					      aux_3139 = (obj_t) (arg1770_1041);
					      list1771_1042 = MAKE_PAIR(aux_3139, BNIL);
					   }
					   arg1766_1037 = list1771_1042;
					}
				     }
				     {
					app_t res2179_2101;
					{
					   type_t type_2084;
					   obj_t key_2086;
					   type_2084 = (type_t) (arg1761_1034);
					   key_2086 = BINT(((long) -1));
					   {
					      app_t new1266_2090;
					      new1266_2090 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
					      {
						 long arg2113_2091;
						 arg2113_2091 = class_num_218___object(app_ast_node);
						 {
						    obj_t obj_2099;
						    obj_2099 = (obj_t) (new1266_2090);
						    (((obj_t) CREF(obj_2099))->header = MAKE_HEADER(arg2113_2091, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_3148;
						 aux_3148 = (object_t) (new1266_2090);
						 OBJECT_WIDENING_SET(aux_3148, BFALSE);
					      }
					      ((((app_t) CREF(new1266_2090))->loc) = ((obj_t) loc_40), BUNSPEC);
					      ((((app_t) CREF(new1266_2090))->type) = ((type_t) type_2084), BUNSPEC);
					      ((((app_t) CREF(new1266_2090))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					      ((((app_t) CREF(new1266_2090))->key) = ((obj_t) key_2086), BUNSPEC);
					      ((((app_t) CREF(new1266_2090))->fun) = ((var_t) arg1765_1036), BUNSPEC);
					      ((((app_t) CREF(new1266_2090))->args) = ((obj_t) arg1766_1037), BUNSPEC);
					      ((((app_t) CREF(new1266_2090))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
					      res2179_2101 = new1266_2090;
					   }
					}
					arg1759_1032 = res2179_2101;
				     }
				  }
				  arg1733_1018 = coerce__182_coerce_coerce((node_t) (arg1759_1032), (type_t) (_obj__252_type_cache));
			       }
			       {
				  obj_t list1739_1020;
				  {
				     obj_t arg1740_1021;
				     {
					obj_t arg1743_1022;
					arg1743_1022 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t aux_3162;
					   aux_3162 = (obj_t) (arg1733_1018);
					   arg1740_1021 = MAKE_PAIR(aux_3162, arg1743_1022);
					}
				     }
				     list1739_1020 = MAKE_PAIR(arg1732_1017, arg1740_1021);
				  }
				  arg1730_1015 = cons__138___r4_pairs_and_lists_6_3(arg1731_1016, list1739_1020);
			       }
			    }
			    {
			       obj_t obj2_2104;
			       obj2_2104 = _global_sexp__67_cnst_alloc;
			       _global_sexp__67_cnst_alloc = MAKE_PAIR(arg1730_1015, obj2_2104);
			    }
			 }
			 {
			    type_t arg1778_1048;
			    {
			       variable_t obj_2105;
			       obj_2105 = (variable_t) (var_1013);
			       arg1778_1048 = (((variable_t) CREF(obj_2105))->type);
			    }
			    {
			       var_t res2180_2116;
			       {
				  variable_t variable_2108;
				  variable_2108 = (variable_t) (var_1013);
				  {
				     var_t new1232_2109;
				     new1232_2109 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				     {
					long arg2123_2110;
					arg2123_2110 = class_num_218___object(var_ast_node);
					{
					   obj_t obj_2114;
					   obj_2114 = (obj_t) (new1232_2109);
					   (((obj_t) CREF(obj_2114))->header = MAKE_HEADER(arg2123_2110, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_3175;
					aux_3175 = (object_t) (new1232_2109);
					OBJECT_WIDENING_SET(aux_3175, BFALSE);
				     }
				     ((((var_t) CREF(new1232_2109))->loc) = ((obj_t) loc_40), BUNSPEC);
				     ((((var_t) CREF(new1232_2109))->type) = ((type_t) arg1778_1048), BUNSPEC);
				     ((((var_t) CREF(new1232_2109))->variable) = ((variable_t) variable_2108), BUNSPEC);
				     res2180_2116 = new1232_2109;
				  }
			       }
			       aux_3087 = res2180_2116;
			    }
			 }
		      }
		      return (node_t) (aux_3087);
		   }
		}
	      else
		{
		   {
		      app_t aux_3182;
		      {
			 long offset_1010;
			 offset_1010 = _cnst_offset__211_cnst_alloc;
			 {
			    long z2_2024;
			    z2_2024 = _cnst_offset__211_cnst_alloc;
			    _cnst_offset__211_cnst_alloc = (((long) 1) + z2_2024);
			 }
			 {
			    obj_t obj2_2026;
			    obj2_2026 = _global_set__17_cnst_alloc;
			    _global_set__17_cnst_alloc = MAKE_PAIR(keyword_39, obj2_2026);
			 }
			 {
			    obj_t arg1727_1011;
			    {
			       obj_t new_2029;
			       {
				  obj_t aux_3185;
				  aux_3185 = CNST_TABLE_REF(((long) 8));
				  new_2029 = create_struct(aux_3185, ((long) 2));
			       }
			       {
				  obj_t aux_3188;
				  aux_3188 = BINT(offset_1010);
				  STRUCT_SET(new_2029, ((long) 1), aux_3188);
			       }
			       STRUCT_SET(new_2029, ((long) 0), keyword_39);
			       arg1727_1011 = new_2029;
			    }
			    put_hash__129___hash(arg1727_1011, _keyword_env__205_cnst_alloc);
			 }
			 aux_3182 = make_cnst_table_ref_93_cnst_alloc(BINT(offset_1010), loc_40);
		      }
		      return (node_t) (aux_3182);
		   }
		}
	   }
      }
   }
}


/* _cnst-alloc-keyword2208 */ obj_t 
_cnst_alloc_keyword2208_158_cnst_alloc(obj_t env_2688, obj_t keyword_2689, obj_t loc_2690)
{
   {
      node_t aux_3196;
      aux_3196 = cnst_alloc_keyword_47_cnst_alloc(keyword_2689, loc_2690);
      return (obj_t) (aux_3196);
   }
}


/* cnst-alloc-procedure */ node_t 
cnst_alloc_procedure_240_cnst_alloc(node_t procedure_41, obj_t loc_42)
{
   {
      global_t var_1061;
      {
	 obj_t arg1796_1065;
	 obj_t arg1797_1066;
	 {
	    obj_t arg1799_1067;
	    arg1799_1067 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 18)), BEOA);
	    {
	       obj_t list1801_1069;
	       {
		  obj_t arg1802_1070;
		  {
		     obj_t aux_3202;
		     aux_3202 = CNST_TABLE_REF(((long) 19));
		     arg1802_1070 = MAKE_PAIR(aux_3202, BNIL);
		  }
		  list1801_1069 = MAKE_PAIR(arg1799_1067, arg1802_1070);
	       }
	       arg1796_1065 = symbol_append_197___r4_symbols_6_4(list1801_1069);
	    }
	 }
	 arg1797_1066 = CNST_TABLE_REF(((long) 20));
	 var_1061 = def_global_scnst__93_ast_glo_def_117(arg1796_1065, _module__166_module_module, (obj_t) (procedure_41), arg1797_1066);
      }
      {
	 type_t arg1794_1063;
	 {
	    variable_t obj_2117;
	    obj_2117 = (variable_t) (var_1061);
	    arg1794_1063 = (((variable_t) CREF(obj_2117))->type);
	 }
	 {
	    var_t res2181_2128;
	    {
	       variable_t variable_2120;
	       variable_2120 = (variable_t) (var_1061);
	       {
		  var_t new1232_2121;
		  new1232_2121 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
		  {
		     long arg2123_2122;
		     arg2123_2122 = class_num_218___object(var_ast_node);
		     {
			obj_t obj_2126;
			obj_2126 = (obj_t) (new1232_2121);
			(((obj_t) CREF(obj_2126))->header = MAKE_HEADER(arg2123_2122, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_3217;
		     aux_3217 = (object_t) (new1232_2121);
		     OBJECT_WIDENING_SET(aux_3217, BFALSE);
		  }
		  ((((var_t) CREF(new1232_2121))->loc) = ((obj_t) loc_42), BUNSPEC);
		  ((((var_t) CREF(new1232_2121))->type) = ((type_t) arg1794_1063), BUNSPEC);
		  ((((var_t) CREF(new1232_2121))->variable) = ((variable_t) variable_2120), BUNSPEC);
		  res2181_2128 = new1232_2121;
	       }
	    }
	    return (node_t) (res2181_2128);
	 }
      }
   }
}


/* _cnst-alloc-procedure2209 */ obj_t 
_cnst_alloc_procedure2209_10_cnst_alloc(obj_t env_2691, obj_t procedure_2692, obj_t loc_2693)
{
   {
      node_t aux_3224;
      aux_3224 = cnst_alloc_procedure_240_cnst_alloc((node_t) (procedure_2692), loc_2693);
      return (obj_t) (aux_3224);
   }
}


/* cnst-alloc-real */ node_t 
cnst_alloc_real_118_cnst_alloc(obj_t real_43, obj_t loc_44)
{
   {
      {
	 obj_t old_1075;
	 {
	    obj_t list_1080;
	    list_1080 = _real_env__85_cnst_alloc;
	  loop_1081:
	    if (NULLP(list_1080))
	      {
		 old_1075 = BFALSE;
	      }
	    else
	      {
		 bool_t test_3230;
		 {
		    double aux_3237;
		    double aux_3231;
		    aux_3237 = REAL_TO_DOUBLE(real_43);
		    {
		       obj_t aux_3232;
		       {
			  obj_t aux_3233;
			  aux_3233 = CAR(list_1080);
			  aux_3232 = CAR(aux_3233);
		       }
		       aux_3231 = REAL_TO_DOUBLE(aux_3232);
		    }
		    test_3230 = (aux_3231 == aux_3237);
		 }
		 if (test_3230)
		   {
		      {
			 obj_t aux_3240;
			 aux_3240 = CAR(list_1080);
			 old_1075 = CDR(aux_3240);
		      }
		   }
		 else
		   {
		      {
			 obj_t list_3243;
			 list_3243 = CDR(list_1080);
			 list_1080 = list_3243;
			 goto loop_1081;
		      }
		   }
	      }
	 }
	 if (CBOOL(old_1075))
	   {
	      {
		 type_t arg1806_1077;
		 {
		    variable_t obj_2129;
		    obj_2129 = (variable_t) (old_1075);
		    arg1806_1077 = (((variable_t) CREF(obj_2129))->type);
		 }
		 {
		    var_t res2182_2140;
		    {
		       variable_t variable_2132;
		       variable_2132 = (variable_t) (old_1075);
		       {
			  var_t new1232_2133;
			  new1232_2133 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			  {
			     long arg2123_2134;
			     arg2123_2134 = class_num_218___object(var_ast_node);
			     {
				obj_t obj_2138;
				obj_2138 = (obj_t) (new1232_2133);
				(((obj_t) CREF(obj_2138))->header = MAKE_HEADER(arg2123_2134, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_3254;
			     aux_3254 = (object_t) (new1232_2133);
			     OBJECT_WIDENING_SET(aux_3254, BFALSE);
			  }
			  ((((var_t) CREF(new1232_2133))->loc) = ((obj_t) loc_44), BUNSPEC);
			  ((((var_t) CREF(new1232_2133))->type) = ((type_t) arg1806_1077), BUNSPEC);
			  ((((var_t) CREF(new1232_2133))->variable) = ((variable_t) variable_2132), BUNSPEC);
			  res2182_2140 = new1232_2133;
		       }
		    }
		    return (node_t) (res2182_2140);
		 }
	      }
	   }
	 else
	   {
	      {
		 var_t aux_3261;
		 {
		    global_t var_1089;
		    {
		       obj_t arg1821_1094;
		       obj_t arg1822_1095;
		       {
			  obj_t arg1823_1096;
			  arg1823_1096 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 21)), BEOA);
			  {
			     obj_t list1825_1098;
			     {
				obj_t arg1826_1099;
				{
				   obj_t aux_3265;
				   aux_3265 = CNST_TABLE_REF(((long) 22));
				   arg1826_1099 = MAKE_PAIR(aux_3265, BNIL);
				}
				list1825_1098 = MAKE_PAIR(arg1823_1096, arg1826_1099);
			     }
			     arg1821_1094 = symbol_append_197___r4_symbols_6_4(list1825_1098);
			  }
		       }
		       arg1822_1095 = CNST_TABLE_REF(((long) 23));
		       var_1089 = def_global_scnst__93_ast_glo_def_117(arg1821_1094, _module__166_module_module, real_43, arg1822_1095);
		    }
		    {
		       obj_t arg1816_1090;
		       {
			  obj_t aux_3272;
			  aux_3272 = (obj_t) (var_1089);
			  arg1816_1090 = MAKE_PAIR(real_43, aux_3272);
		       }
		       {
			  obj_t obj2_2152;
			  obj2_2152 = _real_env__85_cnst_alloc;
			  _real_env__85_cnst_alloc = MAKE_PAIR(arg1816_1090, obj2_2152);
		       }
		    }
		    {
		       type_t arg1818_1092;
		       {
			  variable_t obj_2153;
			  obj_2153 = (variable_t) (var_1089);
			  arg1818_1092 = (((variable_t) CREF(obj_2153))->type);
		       }
		       {
			  var_t res2183_2164;
			  {
			     variable_t variable_2156;
			     variable_2156 = (variable_t) (var_1089);
			     {
				var_t new1232_2157;
				new1232_2157 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				{
				   long arg2123_2158;
				   arg2123_2158 = class_num_218___object(var_ast_node);
				   {
				      obj_t obj_2162;
				      obj_2162 = (obj_t) (new1232_2157);
				      (((obj_t) CREF(obj_2162))->header = MAKE_HEADER(arg2123_2158, 0), BUNSPEC);
				   }
				}
				{
				   object_t aux_3283;
				   aux_3283 = (object_t) (new1232_2157);
				   OBJECT_WIDENING_SET(aux_3283, BFALSE);
				}
				((((var_t) CREF(new1232_2157))->loc) = ((obj_t) loc_44), BUNSPEC);
				((((var_t) CREF(new1232_2157))->type) = ((type_t) arg1818_1092), BUNSPEC);
				((((var_t) CREF(new1232_2157))->variable) = ((variable_t) variable_2156), BUNSPEC);
				res2183_2164 = new1232_2157;
			     }
			  }
			  aux_3261 = res2183_2164;
		       }
		    }
		 }
		 return (node_t) (aux_3261);
	      }
	   }
      }
   }
}


/* _cnst-alloc-real2210 */ obj_t 
_cnst_alloc_real2210_68_cnst_alloc(obj_t env_2694, obj_t real_2695, obj_t loc_2696)
{
   {
      node_t aux_3290;
      aux_3290 = cnst_alloc_real_118_cnst_alloc(real_2695, loc_2696);
      return (obj_t) (aux_3290);
   }
}


/* cnst-alloc-list */ node_t 
cnst_alloc_list_56_cnst_alloc(obj_t pair_45, obj_t loc_46)
{
   {
      {
	 obj_t old_1107;
	 {
	    obj_t _andtest_1486_1116;
	    _andtest_1486_1116 = _shared_cnst___67_engine_param;
	    if (CBOOL(_andtest_1486_1116))
	      {
		 obj_t env_1117;
		 env_1117 = _list_env__66_cnst_alloc;
	       loop_1118:
		 if (NULLP(env_1117))
		   {
		      old_1107 = BFALSE;
		   }
		 else
		   {
		      bool_t test_3297;
		      {
			 obj_t aux_3298;
			 {
			    obj_t aux_3299;
			    aux_3299 = CAR(env_1117);
			    aux_3298 = STRUCT_REF(aux_3299, ((long) 0));
			 }
			 test_3297 = equal__25___r4_equivalence_6_2(aux_3298, pair_45);
		      }
		      if (test_3297)
			{
			   old_1107 = CAR(env_1117);
			}
		      else
			{
			   {
			      obj_t env_3304;
			      env_3304 = CDR(env_1117);
			      env_1117 = env_3304;
			      goto loop_1118;
			   }
			}
		   }
	      }
	    else
	      {
		 old_1107 = BFALSE;
	      }
	 }
	 if (CBOOL(old_1107))
	   {
	      {
		 bool_t test1830_1108;
		 {
		    obj_t obj1_2172;
		    obj1_2172 = _init_mode__183_engine_param;
		    {
		       obj_t aux_3308;
		       aux_3308 = CNST_TABLE_REF(((long) 14));
		       test1830_1108 = (obj1_2172 == aux_3308);
		    }
		 }
		 if (test1830_1108)
		   {
		      type_t arg1832_1110;
		      obj_t arg1833_1111;
		      arg1832_1110 = get_default_type_181_type_cache();
		      arg1833_1111 = STRUCT_REF(old_1107, ((long) 1));
		      {
			 var_t res2184_2187;
			 {
			    variable_t variable_2179;
			    variable_2179 = (variable_t) (arg1833_1111);
			    {
			       var_t new1232_2180;
			       new1232_2180 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			       {
				  long arg2123_2181;
				  arg2123_2181 = class_num_218___object(var_ast_node);
				  {
				     obj_t obj_2185;
				     obj_2185 = (obj_t) (new1232_2180);
				     (((obj_t) CREF(obj_2185))->header = MAKE_HEADER(arg2123_2181, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_3319;
				  aux_3319 = (object_t) (new1232_2180);
				  OBJECT_WIDENING_SET(aux_3319, BFALSE);
			       }
			       ((((var_t) CREF(new1232_2180))->loc) = ((obj_t) loc_46), BUNSPEC);
			       ((((var_t) CREF(new1232_2180))->type) = ((type_t) arg1832_1110), BUNSPEC);
			       ((((var_t) CREF(new1232_2180))->variable) = ((variable_t) variable_2179), BUNSPEC);
			       res2184_2187 = new1232_2180;
			    }
			 }
			 return (node_t) (res2184_2187);
		      }
		   }
		 else
		   {
		      app_t aux_3326;
		      aux_3326 = make_cnst_table_ref_93_cnst_alloc(STRUCT_REF(old_1107, ((long) 1)), loc_46);
		      return (node_t) (aux_3326);
		   }
	      }
	   }
	 else
	   {
	      bool_t test1836_1114;
	      {
		 obj_t obj1_2191;
		 obj1_2191 = _init_mode__183_engine_param;
		 {
		    obj_t aux_3330;
		    aux_3330 = CNST_TABLE_REF(((long) 14));
		    test1836_1114 = (obj1_2191 == aux_3330);
		 }
	      }
	      if (test1836_1114)
		{
		   {
		      var_t aux_3334;
		      {
			 global_t var_1128;
			 {
			    obj_t arg1878_1151;
			    obj_t arg1879_1152;
			    obj_t arg1880_1153;
			    {
			       obj_t arg1881_1154;
			       arg1881_1154 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 24)), BEOA);
			       {
				  obj_t list1884_1156;
				  {
				     obj_t arg1885_1157;
				     {
					obj_t aux_3338;
					aux_3338 = CNST_TABLE_REF(((long) 25));
					arg1885_1157 = MAKE_PAIR(aux_3338, BNIL);
				     }
				     list1884_1156 = MAKE_PAIR(arg1881_1154, arg1885_1157);
				  }
				  arg1878_1151 = symbol_append_197___r4_symbols_6_4(list1884_1156);
			       }
			    }
			    arg1879_1152 = CNST_TABLE_REF(((long) 26));
			    arg1880_1153 = CNST_TABLE_REF(((long) 3));
			    var_1128 = def_global_svar__184_ast_glo_def_117(arg1878_1151, _module__166_module_module, arg1879_1152, arg1880_1153);
			 }
			 if (CBOOL(_shared_cnst___67_engine_param))
			   {
			      obj_t arg1852_1129;
			      {
				 obj_t new_2216;
				 {
				    obj_t aux_3348;
				    aux_3348 = CNST_TABLE_REF(((long) 8));
				    new_2216 = create_struct(aux_3348, ((long) 2));
				 }
				 {
				    obj_t aux_3351;
				    aux_3351 = (obj_t) (var_1128);
				    STRUCT_SET(new_2216, ((long) 1), aux_3351);
				 }
				 STRUCT_SET(new_2216, ((long) 0), pair_45);
				 arg1852_1129 = new_2216;
			      }
			      {
				 obj_t obj2_2230;
				 obj2_2230 = _list_env__66_cnst_alloc;
				 _list_env__66_cnst_alloc = MAKE_PAIR(arg1852_1129, obj2_2230);
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
			 {
			    obj_t arg1853_1130;
			    {
			       obj_t arg1856_1131;
			       obj_t arg1857_1132;
			       node_t arg1858_1133;
			       arg1856_1131 = CNST_TABLE_REF(((long) 12));
			       {
				  obj_t arg1864_1139;
				  obj_t arg1865_1140;
				  obj_t arg1866_1141;
				  arg1864_1139 = CNST_TABLE_REF(((long) 13));
				  arg1865_1140 = (((global_t) CREF(var_1128))->id);
				  arg1866_1141 = (((global_t) CREF(var_1128))->module);
				  {
				     obj_t list1868_1143;
				     {
					obj_t arg1869_1144;
					{
					   obj_t arg1870_1145;
					   arg1870_1145 = MAKE_PAIR(BNIL, BNIL);
					   arg1869_1144 = MAKE_PAIR(arg1866_1141, arg1870_1145);
					}
					list1868_1143 = MAKE_PAIR(arg1865_1140, arg1869_1144);
				     }
				     arg1857_1132 = cons__138___r4_pairs_and_lists_6_3(arg1864_1139, list1868_1143);
				  }
			       }
			       {
				  obj_t arg1874_1147;
				  arg1874_1147 = cnst_list_66_cnst_alloc(loc_46, pair_45);
				  arg1858_1133 = coerce__182_coerce_coerce((node_t) (arg1874_1147), (type_t) (_obj__252_type_cache));
			       }
			       {
				  obj_t list1860_1135;
				  {
				     obj_t arg1861_1136;
				     {
					obj_t arg1862_1137;
					arg1862_1137 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t aux_3369;
					   aux_3369 = (obj_t) (arg1858_1133);
					   arg1861_1136 = MAKE_PAIR(aux_3369, arg1862_1137);
					}
				     }
				     list1860_1135 = MAKE_PAIR(arg1857_1132, arg1861_1136);
				  }
				  arg1853_1130 = cons__138___r4_pairs_and_lists_6_3(arg1856_1131, list1860_1135);
			       }
			    }
			    {
			       obj_t obj2_2235;
			       obj2_2235 = _global_sexp__67_cnst_alloc;
			       _global_sexp__67_cnst_alloc = MAKE_PAIR(arg1853_1130, obj2_2235);
			    }
			 }
			 {
			    type_t arg1876_1149;
			    {
			       variable_t obj_2236;
			       obj_2236 = (variable_t) (var_1128);
			       arg1876_1149 = (((variable_t) CREF(obj_2236))->type);
			    }
			    {
			       var_t res2185_2247;
			       {
				  variable_t variable_2239;
				  variable_2239 = (variable_t) (var_1128);
				  {
				     var_t new1232_2240;
				     new1232_2240 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				     {
					long arg2123_2241;
					arg2123_2241 = class_num_218___object(var_ast_node);
					{
					   obj_t obj_2245;
					   obj_2245 = (obj_t) (new1232_2240);
					   (((obj_t) CREF(obj_2245))->header = MAKE_HEADER(arg2123_2241, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_3382;
					aux_3382 = (object_t) (new1232_2240);
					OBJECT_WIDENING_SET(aux_3382, BFALSE);
				     }
				     ((((var_t) CREF(new1232_2240))->loc) = ((obj_t) loc_46), BUNSPEC);
				     ((((var_t) CREF(new1232_2240))->type) = ((type_t) arg1876_1149), BUNSPEC);
				     ((((var_t) CREF(new1232_2240))->variable) = ((variable_t) variable_2239), BUNSPEC);
				     res2185_2247 = new1232_2240;
				  }
			       }
			       aux_3334 = res2185_2247;
			    }
			 }
		      }
		      return (node_t) (aux_3334);
		   }
		}
	      else
		{
		   {
		      app_t aux_3389;
		      {
			 long offset_1125;
			 offset_1125 = _cnst_offset__211_cnst_alloc;
			 {
			    long z2_2194;
			    z2_2194 = _cnst_offset__211_cnst_alloc;
			    _cnst_offset__211_cnst_alloc = (((long) 1) + z2_2194);
			 }
			 {
			    obj_t obj2_2196;
			    obj2_2196 = _global_set__17_cnst_alloc;
			    _global_set__17_cnst_alloc = MAKE_PAIR(pair_45, obj2_2196);
			 }
			 if (CBOOL(_shared_cnst___67_engine_param))
			   {
			      obj_t arg1850_1126;
			      {
				 obj_t new_2199;
				 {
				    obj_t aux_3394;
				    aux_3394 = CNST_TABLE_REF(((long) 8));
				    new_2199 = create_struct(aux_3394, ((long) 2));
				 }
				 {
				    obj_t aux_3397;
				    aux_3397 = BINT(offset_1125);
				    STRUCT_SET(new_2199, ((long) 1), aux_3397);
				 }
				 STRUCT_SET(new_2199, ((long) 0), pair_45);
				 arg1850_1126 = new_2199;
			      }
			      {
				 obj_t obj2_2213;
				 obj2_2213 = _list_env__66_cnst_alloc;
				 _list_env__66_cnst_alloc = MAKE_PAIR(arg1850_1126, obj2_2213);
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
			 aux_3389 = make_cnst_table_ref_93_cnst_alloc(BINT(offset_1125), loc_46);
		      }
		      return (node_t) (aux_3389);
		   }
		}
	   }
      }
   }
}


/* cnst-list */ obj_t 
cnst_list_66_cnst_alloc(obj_t loc_2706, obj_t pair_1160)
{
   return loop_cnst_alloc(loc_2706, pair_1160);
}


/* loop */ obj_t 
loop_cnst_alloc(obj_t loc_2707, obj_t pair_1162)
{
   if (NULLP(pair_1162))
     {
	{
	   obj_t arg1892_1166;
	   arg1892_1166 = _bnil__15_type_cache;
	   {
	      atom_t res2186_2259;
	      {
		 type_t type_2250;
		 type_2250 = (type_t) (arg1892_1166);
		 {
		    atom_t new1224_2252;
		    new1224_2252 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
		    {
		       long arg2125_2253;
		       arg2125_2253 = class_num_218___object(atom_ast_node);
		       {
			  obj_t obj_2257;
			  obj_2257 = (obj_t) (new1224_2252);
			  (((obj_t) CREF(obj_2257))->header = MAKE_HEADER(arg2125_2253, 0), BUNSPEC);
		       }
		    }
		    {
		       object_t aux_3413;
		       aux_3413 = (object_t) (new1224_2252);
		       OBJECT_WIDENING_SET(aux_3413, BFALSE);
		    }
		    ((((atom_t) CREF(new1224_2252))->loc) = ((obj_t) loc_2707), BUNSPEC);
		    ((((atom_t) CREF(new1224_2252))->type) = ((type_t) type_2250), BUNSPEC);
		    ((((atom_t) CREF(new1224_2252))->value) = ((obj_t) BNIL), BUNSPEC);
		    res2186_2259 = new1224_2252;
		 }
	      }
	      return (obj_t) (res2186_2259);
	   }
	}
     }
   else
     {
	if (PAIRP(pair_1162))
	  {
	     {
		obj_t arg1896_1170;
		var_t arg1898_1172;
		obj_t arg1899_1173;
		arg1896_1170 = _pair__244_type_cache;
		{
		   type_t arg1901_1175;
		   obj_t arg1902_1176;
		   {
		      variable_t obj_2261;
		      obj_2261 = (variable_t) (_cons__148_cnst_cache);
		      arg1901_1175 = (((variable_t) CREF(obj_2261))->type);
		   }
		   arg1902_1176 = _cons__148_cnst_cache;
		   {
		      var_t res2187_2272;
		      {
			 variable_t variable_2264;
			 variable_2264 = (variable_t) (arg1902_1176);
			 {
			    var_t new1232_2265;
			    new1232_2265 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			    {
			       long arg2123_2266;
			       arg2123_2266 = class_num_218___object(var_ast_node);
			       {
				  obj_t obj_2270;
				  obj_2270 = (obj_t) (new1232_2265);
				  (((obj_t) CREF(obj_2270))->header = MAKE_HEADER(arg2123_2266, 0), BUNSPEC);
			       }
			    }
			    {
			       object_t aux_3429;
			       aux_3429 = (object_t) (new1232_2265);
			       OBJECT_WIDENING_SET(aux_3429, BFALSE);
			    }
			    ((((var_t) CREF(new1232_2265))->loc) = ((obj_t) loc_2707), BUNSPEC);
			    ((((var_t) CREF(new1232_2265))->type) = ((type_t) arg1901_1175), BUNSPEC);
			    ((((var_t) CREF(new1232_2265))->variable) = ((variable_t) variable_2264), BUNSPEC);
			    res2187_2272 = new1232_2265;
			 }
		      }
		      arg1898_1172 = res2187_2272;
		   }
		}
		{
		   node_t arg1903_1177;
		   obj_t arg1905_1178;
		   {
		      kwote_t arg1910_1182;
		      {
			 type_t arg1912_1184;
			 obj_t arg1913_1185;
			 arg1912_1184 = get_default_type_181_type_cache();
			 arg1913_1185 = CAR(pair_1162);
			 {
			    kwote_t res2188_2284;
			    {
			       kwote_t new1248_2277;
			       new1248_2277 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
			       {
				  long arg2117_2278;
				  arg2117_2278 = class_num_218___object(kwote_ast_node);
				  {
				     obj_t obj_2282;
				     obj_2282 = (obj_t) (new1248_2277);
				     (((obj_t) CREF(obj_2282))->header = MAKE_HEADER(arg2117_2278, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_3441;
				  aux_3441 = (object_t) (new1248_2277);
				  OBJECT_WIDENING_SET(aux_3441, BFALSE);
			       }
			       ((((kwote_t) CREF(new1248_2277))->loc) = ((obj_t) loc_2707), BUNSPEC);
			       ((((kwote_t) CREF(new1248_2277))->type) = ((type_t) arg1912_1184), BUNSPEC);
			       ((((kwote_t) CREF(new1248_2277))->value) = ((obj_t) arg1913_1185), BUNSPEC);
			       res2188_2284 = new1248_2277;
			    }
			    arg1910_1182 = res2188_2284;
			 }
		      }
		      arg1903_1177 = cnst__44_cnst_node((node_t) (arg1910_1182));
		   }
		   arg1905_1178 = loop_cnst_alloc(loc_2707, CDR(pair_1162));
		   {
		      obj_t list1906_1179;
		      {
			 obj_t arg1907_1180;
			 arg1907_1180 = MAKE_PAIR(arg1905_1178, BNIL);
			 {
			    obj_t aux_3452;
			    aux_3452 = (obj_t) (arg1903_1177);
			    list1906_1179 = MAKE_PAIR(aux_3452, arg1907_1180);
			 }
		      }
		      arg1899_1173 = list1906_1179;
		   }
		}
		{
		   app_t res2189_2305;
		   {
		      type_t type_2288;
		      obj_t key_2290;
		      type_2288 = (type_t) (arg1896_1170);
		      key_2290 = BINT(((long) -1));
		      {
			 app_t new1266_2294;
			 new1266_2294 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
			 {
			    long arg2113_2295;
			    arg2113_2295 = class_num_218___object(app_ast_node);
			    {
			       obj_t obj_2303;
			       obj_2303 = (obj_t) (new1266_2294);
			       (((obj_t) CREF(obj_2303))->header = MAKE_HEADER(arg2113_2295, 0), BUNSPEC);
			    }
			 }
			 {
			    object_t aux_3461;
			    aux_3461 = (object_t) (new1266_2294);
			    OBJECT_WIDENING_SET(aux_3461, BFALSE);
			 }
			 ((((app_t) CREF(new1266_2294))->loc) = ((obj_t) loc_2707), BUNSPEC);
			 ((((app_t) CREF(new1266_2294))->type) = ((type_t) type_2288), BUNSPEC);
			 ((((app_t) CREF(new1266_2294))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			 ((((app_t) CREF(new1266_2294))->key) = ((obj_t) key_2290), BUNSPEC);
			 ((((app_t) CREF(new1266_2294))->fun) = ((var_t) arg1898_1172), BUNSPEC);
			 ((((app_t) CREF(new1266_2294))->args) = ((obj_t) arg1899_1173), BUNSPEC);
			 ((((app_t) CREF(new1266_2294))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
			 res2189_2305 = new1266_2294;
		      }
		   }
		   return (obj_t) (res2189_2305);
		}
	     }
	  }
	else
	  {
	     {
		kwote_t arg1915_1187;
		{
		   obj_t arg1917_1189;
		   arg1917_1189 = _pair__244_type_cache;
		   {
		      kwote_t res2190_2316;
		      {
			 type_t type_2307;
			 type_2307 = (type_t) (arg1917_1189);
			 {
			    kwote_t new1248_2309;
			    new1248_2309 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
			    {
			       long arg2117_2310;
			       arg2117_2310 = class_num_218___object(kwote_ast_node);
			       {
				  obj_t obj_2314;
				  obj_2314 = (obj_t) (new1248_2309);
				  (((obj_t) CREF(obj_2314))->header = MAKE_HEADER(arg2117_2310, 0), BUNSPEC);
			       }
			    }
			    {
			       object_t aux_3477;
			       aux_3477 = (object_t) (new1248_2309);
			       OBJECT_WIDENING_SET(aux_3477, BFALSE);
			    }
			    ((((kwote_t) CREF(new1248_2309))->loc) = ((obj_t) loc_2707), BUNSPEC);
			    ((((kwote_t) CREF(new1248_2309))->type) = ((type_t) type_2307), BUNSPEC);
			    ((((kwote_t) CREF(new1248_2309))->value) = ((obj_t) pair_1162), BUNSPEC);
			    res2190_2316 = new1248_2309;
			 }
		      }
		      arg1915_1187 = res2190_2316;
		   }
		}
		{
		   node_t aux_3483;
		   aux_3483 = cnst__44_cnst_node((node_t) (arg1915_1187));
		   return (obj_t) (aux_3483);
		}
	     }
	  }
     }
}


/* _cnst-alloc-list */ obj_t 
_cnst_alloc_list_46_cnst_alloc(obj_t env_2697, obj_t pair_2698, obj_t loc_2699)
{
   {
      node_t aux_3487;
      aux_3487 = cnst_alloc_list_56_cnst_alloc(pair_2698, loc_2699);
      return (obj_t) (aux_3487);
   }
}


/* cnst-alloc-vector */ node_t 
cnst_alloc_vector_65_cnst_alloc(obj_t vec_47, obj_t loc_48)
{
   {
      {
	 obj_t old_1197;
	 {
	    obj_t _andtest_1499_1206;
	    _andtest_1499_1206 = _shared_cnst___67_engine_param;
	    if (CBOOL(_andtest_1499_1206))
	      {
		 obj_t env_1207;
		 env_1207 = _vector_env__150_cnst_alloc;
	       loop_1208:
		 if (NULLP(env_1207))
		   {
		      old_1197 = BFALSE;
		   }
		 else
		   {
		      bool_t test_3494;
		      {
			 obj_t aux_3495;
			 {
			    obj_t aux_3496;
			    aux_3496 = CAR(env_1207);
			    aux_3495 = STRUCT_REF(aux_3496, ((long) 0));
			 }
			 test_3494 = equal__25___r4_equivalence_6_2(aux_3495, vec_47);
		      }
		      if (test_3494)
			{
			   old_1197 = CAR(env_1207);
			}
		      else
			{
			   {
			      obj_t env_3501;
			      env_3501 = CDR(env_1207);
			      env_1207 = env_3501;
			      goto loop_1208;
			   }
			}
		   }
	      }
	    else
	      {
		 old_1197 = BFALSE;
	      }
	 }
	 if (CBOOL(old_1197))
	   {
	      {
		 bool_t test1919_1198;
		 {
		    obj_t obj1_2324;
		    obj1_2324 = _init_mode__183_engine_param;
		    {
		       obj_t aux_3505;
		       aux_3505 = CNST_TABLE_REF(((long) 14));
		       test1919_1198 = (obj1_2324 == aux_3505);
		    }
		 }
		 if (test1919_1198)
		   {
		      type_t arg1921_1200;
		      obj_t arg1923_1201;
		      arg1921_1200 = get_default_type_181_type_cache();
		      arg1923_1201 = STRUCT_REF(old_1197, ((long) 1));
		      {
			 var_t res2191_2339;
			 {
			    variable_t variable_2331;
			    variable_2331 = (variable_t) (arg1923_1201);
			    {
			       var_t new1232_2332;
			       new1232_2332 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			       {
				  long arg2123_2333;
				  arg2123_2333 = class_num_218___object(var_ast_node);
				  {
				     obj_t obj_2337;
				     obj_2337 = (obj_t) (new1232_2332);
				     (((obj_t) CREF(obj_2337))->header = MAKE_HEADER(arg2123_2333, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_3516;
				  aux_3516 = (object_t) (new1232_2332);
				  OBJECT_WIDENING_SET(aux_3516, BFALSE);
			       }
			       ((((var_t) CREF(new1232_2332))->loc) = ((obj_t) loc_48), BUNSPEC);
			       ((((var_t) CREF(new1232_2332))->type) = ((type_t) arg1921_1200), BUNSPEC);
			       ((((var_t) CREF(new1232_2332))->variable) = ((variable_t) variable_2331), BUNSPEC);
			       res2191_2339 = new1232_2332;
			    }
			 }
			 return (node_t) (res2191_2339);
		      }
		   }
		 else
		   {
		      app_t aux_3523;
		      aux_3523 = make_cnst_table_ref_93_cnst_alloc(STRUCT_REF(old_1197, ((long) 1)), loc_48);
		      return (node_t) (aux_3523);
		   }
	      }
	   }
	 else
	   {
	      bool_t test1926_1204;
	      {
		 obj_t obj1_2343;
		 obj1_2343 = _init_mode__183_engine_param;
		 {
		    obj_t aux_3527;
		    aux_3527 = CNST_TABLE_REF(((long) 14));
		    test1926_1204 = (obj1_2343 == aux_3527);
		 }
	      }
	      if (test1926_1204)
		{
		   {
		      var_t aux_3531;
		      {
			 global_t var_1215;
			 {
			    obj_t arg1957_1237;
			    obj_t arg1958_1238;
			    obj_t arg1959_1239;
			    {
			       obj_t arg1960_1240;
			       arg1960_1240 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 27)), BEOA);
			       {
				  obj_t list1962_1242;
				  {
				     obj_t arg1963_1243;
				     {
					obj_t aux_3535;
					aux_3535 = CNST_TABLE_REF(((long) 28));
					arg1963_1243 = MAKE_PAIR(aux_3535, BNIL);
				     }
				     list1962_1242 = MAKE_PAIR(arg1960_1240, arg1963_1243);
				  }
				  arg1957_1237 = symbol_append_197___r4_symbols_6_4(list1962_1242);
			       }
			    }
			    arg1958_1238 = CNST_TABLE_REF(((long) 2));
			    arg1959_1239 = CNST_TABLE_REF(((long) 3));
			    var_1215 = def_global_svar__184_ast_glo_def_117(arg1957_1237, _module__166_module_module, arg1958_1238, arg1959_1239);
			 }
			 if (CBOOL(_shared_cnst___67_engine_param))
			   {
			      obj_t arg1934_1216;
			      {
				 obj_t new_2347;
				 {
				    obj_t aux_3545;
				    aux_3545 = CNST_TABLE_REF(((long) 8));
				    new_2347 = create_struct(aux_3545, ((long) 2));
				 }
				 {
				    obj_t aux_3548;
				    aux_3548 = (obj_t) (var_1215);
				    STRUCT_SET(new_2347, ((long) 1), aux_3548);
				 }
				 STRUCT_SET(new_2347, ((long) 0), vec_47);
				 arg1934_1216 = new_2347;
			      }
			      {
				 obj_t obj2_2361;
				 obj2_2361 = _vector_env__150_cnst_alloc;
				 _vector_env__150_cnst_alloc = MAKE_PAIR(arg1934_1216, obj2_2361);
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
			 {
			    obj_t arg1935_1217;
			    {
			       obj_t arg1936_1218;
			       obj_t arg1937_1219;
			       node_t arg1938_1220;
			       arg1936_1218 = CNST_TABLE_REF(((long) 12));
			       {
				  obj_t arg1944_1226;
				  obj_t arg1945_1227;
				  obj_t arg1947_1228;
				  arg1944_1226 = CNST_TABLE_REF(((long) 13));
				  arg1945_1227 = (((global_t) CREF(var_1215))->id);
				  arg1947_1228 = (((global_t) CREF(var_1215))->module);
				  {
				     obj_t list1949_1230;
				     {
					obj_t arg1950_1231;
					{
					   obj_t arg1951_1232;
					   arg1951_1232 = MAKE_PAIR(BNIL, BNIL);
					   arg1950_1231 = MAKE_PAIR(arg1947_1228, arg1951_1232);
					}
					list1949_1230 = MAKE_PAIR(arg1945_1227, arg1950_1231);
				     }
				     arg1937_1219 = cons__138___r4_pairs_and_lists_6_3(arg1944_1226, list1949_1230);
				  }
			       }
			       {
				  node_t arg1970_1250;
				  {
				     let_var_6_t arg1971_1251;
				     {
					local_t var_1252;
					var_1252 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 29)), (type_t) (_vector__240_type_cache));
					{
					   obj_t arg1973_1254;
					   obj_t arg1975_1256;
					   obj_t arg1977_1257;
					   arg1973_1254 = _obj__252_type_cache;
					   {
					      obj_t arg1978_1258;
					      {
						 app_t arg1981_1261;
						 {
						    obj_t arg1983_1263;
						    var_t arg1985_1265;
						    obj_t arg1986_1266;
						    arg1983_1263 = _vector__240_type_cache;
						    {
						       type_t arg1988_1268;
						       obj_t arg1989_1269;
						       {
							  variable_t obj_2400;
							  obj_2400 = (variable_t) (_list__vector__161_cnst_cache);
							  arg1988_1268 = (((variable_t) CREF(obj_2400))->type);
						       }
						       arg1989_1269 = _list__vector__161_cnst_cache;
						       {
							  var_t res2193_2411;
							  {
							     variable_t variable_2403;
							     variable_2403 = (variable_t) (arg1989_1269);
							     {
								var_t new1232_2404;
								new1232_2404 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								{
								   long arg2123_2405;
								   arg2123_2405 = class_num_218___object(var_ast_node);
								   {
								      obj_t obj_2409;
								      obj_2409 = (obj_t) (new1232_2404);
								      (((obj_t) CREF(obj_2409))->header = MAKE_HEADER(arg2123_2405, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_3571;
								   aux_3571 = (object_t) (new1232_2404);
								   OBJECT_WIDENING_SET(aux_3571, BFALSE);
								}
								((((var_t) CREF(new1232_2404))->loc) = ((obj_t) loc_48), BUNSPEC);
								((((var_t) CREF(new1232_2404))->type) = ((type_t) arg1988_1268), BUNSPEC);
								((((var_t) CREF(new1232_2404))->variable) = ((variable_t) variable_2403), BUNSPEC);
								res2193_2411 = new1232_2404;
							     }
							  }
							  arg1985_1265 = res2193_2411;
						       }
						    }
						    {
						       kwote_t arg1990_1270;
						       {
							  obj_t arg1994_1274;
							  obj_t arg1995_1275;
							  arg1994_1274 = _obj__252_type_cache;
							  arg1995_1275 = vector__list_155___r4_vectors_6_8(vec_47);
							  {
							     kwote_t res2194_2422;
							     {
								type_t type_2413;
								type_2413 = (type_t) (arg1994_1274);
								{
								   kwote_t new1248_2415;
								   new1248_2415 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
								   {
								      long arg2117_2416;
								      arg2117_2416 = class_num_218___object(kwote_ast_node);
								      {
									 obj_t obj_2420;
									 obj_2420 = (obj_t) (new1248_2415);
									 (((obj_t) CREF(obj_2420))->header = MAKE_HEADER(arg2117_2416, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_3583;
								      aux_3583 = (object_t) (new1248_2415);
								      OBJECT_WIDENING_SET(aux_3583, BFALSE);
								   }
								   ((((kwote_t) CREF(new1248_2415))->loc) = ((obj_t) loc_48), BUNSPEC);
								   ((((kwote_t) CREF(new1248_2415))->type) = ((type_t) type_2413), BUNSPEC);
								   ((((kwote_t) CREF(new1248_2415))->value) = ((obj_t) arg1995_1275), BUNSPEC);
								   res2194_2422 = new1248_2415;
								}
							     }
							     arg1990_1270 = res2194_2422;
							  }
						       }
						       {
							  obj_t list1991_1271;
							  {
							     obj_t aux_3589;
							     aux_3589 = (obj_t) (arg1990_1270);
							     list1991_1271 = MAKE_PAIR(aux_3589, BNIL);
							  }
							  arg1986_1266 = list1991_1271;
						       }
						    }
						    {
						       app_t res2195_2442;
						       {
							  type_t type_2425;
							  obj_t key_2427;
							  type_2425 = (type_t) (arg1983_1263);
							  key_2427 = BINT(((long) -1));
							  {
							     app_t new1266_2431;
							     new1266_2431 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
							     {
								long arg2113_2432;
								arg2113_2432 = class_num_218___object(app_ast_node);
								{
								   obj_t obj_2440;
								   obj_2440 = (obj_t) (new1266_2431);
								   (((obj_t) CREF(obj_2440))->header = MAKE_HEADER(arg2113_2432, 0), BUNSPEC);
								}
							     }
							     {
								object_t aux_3598;
								aux_3598 = (object_t) (new1266_2431);
								OBJECT_WIDENING_SET(aux_3598, BFALSE);
							     }
							     ((((app_t) CREF(new1266_2431))->loc) = ((obj_t) loc_48), BUNSPEC);
							     ((((app_t) CREF(new1266_2431))->type) = ((type_t) type_2425), BUNSPEC);
							     ((((app_t) CREF(new1266_2431))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
							     ((((app_t) CREF(new1266_2431))->key) = ((obj_t) key_2427), BUNSPEC);
							     ((((app_t) CREF(new1266_2431))->fun) = ((var_t) arg1985_1265), BUNSPEC);
							     ((((app_t) CREF(new1266_2431))->args) = ((obj_t) arg1986_1266), BUNSPEC);
							     ((((app_t) CREF(new1266_2431))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
							     res2195_2442 = new1266_2431;
							  }
						       }
						       arg1981_1261 = res2195_2442;
						    }
						 }
						 {
						    obj_t aux_3610;
						    obj_t aux_3608;
						    aux_3610 = (obj_t) (arg1981_1261);
						    aux_3608 = (obj_t) (var_1252);
						    arg1978_1258 = MAKE_PAIR(aux_3608, aux_3610);
						 }
					      }
					      {
						 obj_t list1979_1259;
						 list1979_1259 = MAKE_PAIR(arg1978_1258, BNIL);
						 arg1975_1256 = list1979_1259;
					      }
					   }
					   {
					      var_t var_body_120_1276;
					      {
						 type_t arg2033_1308;
						 {
						    variable_t obj_2446;
						    obj_2446 = (variable_t) (var_1252);
						    arg2033_1308 = (((variable_t) CREF(obj_2446))->type);
						 }
						 {
						    var_t res2196_2457;
						    {
						       variable_t variable_2449;
						       variable_2449 = (variable_t) (var_1252);
						       {
							  var_t new1232_2450;
							  new1232_2450 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							  {
							     long arg2123_2451;
							     arg2123_2451 = class_num_218___object(var_ast_node);
							     {
								obj_t obj_2455;
								obj_2455 = (obj_t) (new1232_2450);
								(((obj_t) CREF(obj_2455))->header = MAKE_HEADER(arg2123_2451, 0), BUNSPEC);
							     }
							  }
							  {
							     object_t aux_3621;
							     aux_3621 = (object_t) (new1232_2450);
							     OBJECT_WIDENING_SET(aux_3621, BFALSE);
							  }
							  ((((var_t) CREF(new1232_2450))->loc) = ((obj_t) loc_48), BUNSPEC);
							  ((((var_t) CREF(new1232_2450))->type) = ((type_t) arg2033_1308), BUNSPEC);
							  ((((var_t) CREF(new1232_2450))->variable) = ((variable_t) variable_2449), BUNSPEC);
							  res2196_2457 = new1232_2450;
						       }
						    }
						    var_body_120_1276 = res2196_2457;
						 }
					      }
					      {
						 bool_t test1996_1277;
						 {
						    long arg2030_1305;
						    arg2030_1305 = VECTOR_TAG(vec_47);
						    test1996_1277 = (arg2030_1305 > ((long) 0));
						 }
						 if (test1996_1277)
						   {
						      obj_t arg2000_1279;
						      obj_t arg2002_1281;
						      arg2000_1279 = _vector__240_type_cache;
						      {
							 app_t arg2003_1282;
							 {
							    obj_t arg2011_1287;
							    var_t arg2013_1289;
							    obj_t arg2014_1290;
							    arg2011_1287 = _obj__252_type_cache;
							    {
							       type_t arg2016_1292;
							       obj_t arg2017_1293;
							       {
								  variable_t obj_2461;
								  obj_2461 = (variable_t) (_vector_tag_set___225_cnst_cache);
								  arg2016_1292 = (((variable_t) CREF(obj_2461))->type);
							       }
							       arg2017_1293 = _vector_tag_set___225_cnst_cache;
							       {
								  var_t res2197_2472;
								  {
								     variable_t variable_2464;
								     variable_2464 = (variable_t) (arg2017_1293);
								     {
									var_t new1232_2465;
									new1232_2465 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
									{
									   long arg2123_2466;
									   arg2123_2466 = class_num_218___object(var_ast_node);
									   {
									      obj_t obj_2470;
									      obj_2470 = (obj_t) (new1232_2465);
									      (((obj_t) CREF(obj_2470))->header = MAKE_HEADER(arg2123_2466, 0), BUNSPEC);
									   }
									}
									{
									   object_t aux_3637;
									   aux_3637 = (object_t) (new1232_2465);
									   OBJECT_WIDENING_SET(aux_3637, BFALSE);
									}
									((((var_t) CREF(new1232_2465))->loc) = ((obj_t) loc_48), BUNSPEC);
									((((var_t) CREF(new1232_2465))->type) = ((type_t) arg2016_1292), BUNSPEC);
									((((var_t) CREF(new1232_2465))->variable) = ((variable_t) variable_2464), BUNSPEC);
									res2197_2472 = new1232_2465;
								     }
								  }
								  arg2013_1289 = res2197_2472;
							       }
							    }
							    {
							       var_t arg2018_1294;
							       atom_t arg2019_1295;
							       {
								  type_t arg2024_1300;
								  {
								     variable_t obj_2473;
								     obj_2473 = (variable_t) (var_1252);
								     arg2024_1300 = (((variable_t) CREF(obj_2473))->type);
								  }
								  {
								     var_t res2198_2484;
								     {
									variable_t variable_2476;
									variable_2476 = (variable_t) (var_1252);
									{
									   var_t new1232_2477;
									   new1232_2477 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
									   {
									      long arg2123_2478;
									      arg2123_2478 = class_num_218___object(var_ast_node);
									      {
										 obj_t obj_2482;
										 obj_2482 = (obj_t) (new1232_2477);
										 (((obj_t) CREF(obj_2482))->header = MAKE_HEADER(arg2123_2478, 0), BUNSPEC);
									      }
									   }
									   {
									      object_t aux_3650;
									      aux_3650 = (object_t) (new1232_2477);
									      OBJECT_WIDENING_SET(aux_3650, BFALSE);
									   }
									   ((((var_t) CREF(new1232_2477))->loc) = ((obj_t) loc_48), BUNSPEC);
									   ((((var_t) CREF(new1232_2477))->type) = ((type_t) arg2024_1300), BUNSPEC);
									   ((((var_t) CREF(new1232_2477))->variable) = ((variable_t) variable_2476), BUNSPEC);
									   res2198_2484 = new1232_2477;
									}
								     }
								     arg2018_1294 = res2198_2484;
								  }
							       }
							       {
								  obj_t arg2028_1303;
								  long arg2029_1304;
								  arg2028_1303 = _obj__252_type_cache;
								  arg2029_1304 = VECTOR_TAG(vec_47);
								  {
								     atom_t res2199_2496;
								     {
									type_t type_2487;
									obj_t value_2488;
									type_2487 = (type_t) (arg2028_1303);
									value_2488 = BINT(arg2029_1304);
									{
									   atom_t new1224_2489;
									   new1224_2489 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
									   {
									      long arg2125_2490;
									      arg2125_2490 = class_num_218___object(atom_ast_node);
									      {
										 obj_t obj_2494;
										 obj_2494 = (obj_t) (new1224_2489);
										 (((obj_t) CREF(obj_2494))->header = MAKE_HEADER(arg2125_2490, 0), BUNSPEC);
									      }
									   }
									   {
									      object_t aux_3663;
									      aux_3663 = (object_t) (new1224_2489);
									      OBJECT_WIDENING_SET(aux_3663, BFALSE);
									   }
									   ((((atom_t) CREF(new1224_2489))->loc) = ((obj_t) loc_48), BUNSPEC);
									   ((((atom_t) CREF(new1224_2489))->type) = ((type_t) type_2487), BUNSPEC);
									   ((((atom_t) CREF(new1224_2489))->value) = ((obj_t) value_2488), BUNSPEC);
									   res2199_2496 = new1224_2489;
									}
								     }
								     arg2019_1295 = res2199_2496;
								  }
							       }
							       {
								  obj_t list2020_1296;
								  {
								     obj_t arg2021_1297;
								     {
									obj_t aux_3669;
									aux_3669 = (obj_t) (arg2019_1295);
									arg2021_1297 = MAKE_PAIR(aux_3669, BNIL);
								     }
								     {
									obj_t aux_3672;
									aux_3672 = (obj_t) (arg2018_1294);
									list2020_1296 = MAKE_PAIR(aux_3672, arg2021_1297);
								     }
								  }
								  arg2014_1290 = list2020_1296;
							       }
							    }
							    {
							       app_t res2200_2516;
							       {
								  type_t type_2499;
								  obj_t key_2501;
								  type_2499 = (type_t) (arg2011_1287);
								  key_2501 = BINT(((long) -1));
								  {
								     app_t new1266_2505;
								     new1266_2505 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
								     {
									long arg2113_2506;
									arg2113_2506 = class_num_218___object(app_ast_node);
									{
									   obj_t obj_2514;
									   obj_2514 = (obj_t) (new1266_2505);
									   (((obj_t) CREF(obj_2514))->header = MAKE_HEADER(arg2113_2506, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_3681;
									aux_3681 = (object_t) (new1266_2505);
									OBJECT_WIDENING_SET(aux_3681, BFALSE);
								     }
								     ((((app_t) CREF(new1266_2505))->loc) = ((obj_t) loc_48), BUNSPEC);
								     ((((app_t) CREF(new1266_2505))->type) = ((type_t) type_2499), BUNSPEC);
								     ((((app_t) CREF(new1266_2505))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								     ((((app_t) CREF(new1266_2505))->key) = ((obj_t) key_2501), BUNSPEC);
								     ((((app_t) CREF(new1266_2505))->fun) = ((var_t) arg2013_1289), BUNSPEC);
								     ((((app_t) CREF(new1266_2505))->args) = ((obj_t) arg2014_1290), BUNSPEC);
								     ((((app_t) CREF(new1266_2505))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
								     res2200_2516 = new1266_2505;
								  }
							       }
							       arg2003_1282 = res2200_2516;
							    }
							 }
							 {
							    obj_t list2004_1283;
							    {
							       obj_t arg2006_1284;
							       {
								  obj_t aux_3691;
								  aux_3691 = (obj_t) (var_body_120_1276);
								  arg2006_1284 = MAKE_PAIR(aux_3691, BNIL);
							       }
							       {
								  obj_t aux_3694;
								  aux_3694 = (obj_t) (arg2003_1282);
								  list2004_1283 = MAKE_PAIR(aux_3694, arg2006_1284);
							       }
							    }
							    arg2002_1281 = list2004_1283;
							 }
						      }
						      {
							 sequence_t res2201_2532;
							 {
							    type_t type_2519;
							    obj_t key_2521;
							    type_2519 = (type_t) (arg2000_1279);
							    key_2521 = BINT(((long) -1));
							    {
							       sequence_t new1255_2523;
							       new1255_2523 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
							       {
								  long arg2115_2524;
								  arg2115_2524 = class_num_218___object(sequence_ast_node);
								  {
								     obj_t obj_2530;
								     obj_2530 = (obj_t) (new1255_2523);
								     (((obj_t) CREF(obj_2530))->header = MAKE_HEADER(arg2115_2524, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_3703;
								  aux_3703 = (object_t) (new1255_2523);
								  OBJECT_WIDENING_SET(aux_3703, BFALSE);
							       }
							       ((((sequence_t) CREF(new1255_2523))->loc) = ((obj_t) loc_48), BUNSPEC);
							       ((((sequence_t) CREF(new1255_2523))->type) = ((type_t) type_2519), BUNSPEC);
							       ((((sequence_t) CREF(new1255_2523))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
							       ((((sequence_t) CREF(new1255_2523))->key) = ((obj_t) key_2521), BUNSPEC);
							       ((((sequence_t) CREF(new1255_2523))->nodes) = ((obj_t) arg2002_1281), BUNSPEC);
							       res2201_2532 = new1255_2523;
							    }
							 }
							 arg1977_1257 = (obj_t) (res2201_2532);
						      }
						   }
						 else
						   {
						      arg1977_1257 = (obj_t) (var_body_120_1276);
						   }
					      }
					   }
					   {
					      let_var_6_t res2202_2551;
					      {
						 type_t type_2534;
						 obj_t key_2536;
						 node_t body_2538;
						 type_2534 = (type_t) (arg1973_1254);
						 key_2536 = BINT(((long) -1));
						 body_2538 = (node_t) (arg1977_1257);
						 {
						    let_var_6_t new1391_2540;
						    new1391_2540 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
						    {
						       long arg2091_2541;
						       arg2091_2541 = class_num_218___object(let_var_6_ast_node);
						       {
							  obj_t obj_2549;
							  obj_2549 = (obj_t) (new1391_2540);
							  (((obj_t) CREF(obj_2549))->header = MAKE_HEADER(arg2091_2541, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3720;
						       aux_3720 = (object_t) (new1391_2540);
						       OBJECT_WIDENING_SET(aux_3720, BFALSE);
						    }
						    ((((let_var_6_t) CREF(new1391_2540))->loc) = ((obj_t) loc_48), BUNSPEC);
						    ((((let_var_6_t) CREF(new1391_2540))->type) = ((type_t) type_2534), BUNSPEC);
						    ((((let_var_6_t) CREF(new1391_2540))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
						    ((((let_var_6_t) CREF(new1391_2540))->key) = ((obj_t) key_2536), BUNSPEC);
						    ((((let_var_6_t) CREF(new1391_2540))->bindings) = ((obj_t) arg1975_1256), BUNSPEC);
						    ((((let_var_6_t) CREF(new1391_2540))->body) = ((node_t) body_2538), BUNSPEC);
						    ((((let_var_6_t) CREF(new1391_2540))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
						    res2202_2551 = new1391_2540;
						 }
					      }
					      arg1971_1251 = res2202_2551;
					   }
					}
				     }
				     arg1970_1250 = coerce__182_coerce_coerce((node_t) (arg1971_1251), (type_t) (_obj__252_type_cache));
				  }
				  arg1938_1220 = cnst__44_cnst_node(arg1970_1250);
			       }
			       {
				  obj_t list1940_1222;
				  {
				     obj_t arg1941_1223;
				     {
					obj_t arg1942_1224;
					arg1942_1224 = MAKE_PAIR(BNIL, BNIL);
					{
					   obj_t aux_3735;
					   aux_3735 = (obj_t) (arg1938_1220);
					   arg1941_1223 = MAKE_PAIR(aux_3735, arg1942_1224);
					}
				     }
				     list1940_1222 = MAKE_PAIR(arg1937_1219, arg1941_1223);
				  }
				  arg1935_1217 = cons__138___r4_pairs_and_lists_6_3(arg1936_1218, list1940_1222);
			       }
			    }
			    {
			       obj_t obj2_2366;
			       obj2_2366 = _global_sexp__67_cnst_alloc;
			       _global_sexp__67_cnst_alloc = MAKE_PAIR(arg1935_1217, obj2_2366);
			    }
			 }
			 {
			    type_t arg1954_1235;
			    {
			       variable_t obj_2367;
			       obj_2367 = (variable_t) (var_1215);
			       arg1954_1235 = (((variable_t) CREF(obj_2367))->type);
			    }
			    {
			       var_t res2192_2378;
			       {
				  variable_t variable_2370;
				  variable_2370 = (variable_t) (var_1215);
				  {
				     var_t new1232_2371;
				     new1232_2371 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				     {
					long arg2123_2372;
					arg2123_2372 = class_num_218___object(var_ast_node);
					{
					   obj_t obj_2376;
					   obj_2376 = (obj_t) (new1232_2371);
					   (((obj_t) CREF(obj_2376))->header = MAKE_HEADER(arg2123_2372, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_3748;
					aux_3748 = (object_t) (new1232_2371);
					OBJECT_WIDENING_SET(aux_3748, BFALSE);
				     }
				     ((((var_t) CREF(new1232_2371))->loc) = ((obj_t) loc_48), BUNSPEC);
				     ((((var_t) CREF(new1232_2371))->type) = ((type_t) arg1954_1235), BUNSPEC);
				     ((((var_t) CREF(new1232_2371))->variable) = ((variable_t) variable_2370), BUNSPEC);
				     res2192_2378 = new1232_2371;
				  }
			       }
			       aux_3531 = res2192_2378;
			    }
			 }
		      }
		      return (node_t) (aux_3531);
		   }
		}
	      else
		{
		   {
		      app_t aux_3755;
		      {
			 long offset_1247;
			 offset_1247 = _cnst_offset__211_cnst_alloc;
			 {
			    long z2_2380;
			    z2_2380 = _cnst_offset__211_cnst_alloc;
			    _cnst_offset__211_cnst_alloc = (((long) 1) + z2_2380);
			 }
			 {
			    obj_t obj2_2382;
			    obj2_2382 = _global_set__17_cnst_alloc;
			    _global_set__17_cnst_alloc = MAKE_PAIR(vec_47, obj2_2382);
			 }
			 if (CBOOL(_shared_cnst___67_engine_param))
			   {
			      obj_t arg1967_1248;
			      {
				 obj_t new_2385;
				 {
				    obj_t aux_3760;
				    aux_3760 = CNST_TABLE_REF(((long) 8));
				    new_2385 = create_struct(aux_3760, ((long) 2));
				 }
				 {
				    obj_t aux_3763;
				    aux_3763 = BINT(offset_1247);
				    STRUCT_SET(new_2385, ((long) 1), aux_3763);
				 }
				 STRUCT_SET(new_2385, ((long) 0), vec_47);
				 arg1967_1248 = new_2385;
			      }
			      {
				 obj_t obj2_2399;
				 obj2_2399 = _vector_env__150_cnst_alloc;
				 _vector_env__150_cnst_alloc = MAKE_PAIR(arg1967_1248, obj2_2399);
			      }
			   }
			 else
			   {
			      BUNSPEC;
			   }
			 aux_3755 = make_cnst_table_ref_93_cnst_alloc(BINT(offset_1247), loc_48);
		      }
		      return (node_t) (aux_3755);
		   }
		}
	   }
      }
   }
}


/* _cnst-alloc-vector2211 */ obj_t 
_cnst_alloc_vector2211_224_cnst_alloc(obj_t env_2700, obj_t vec_2701, obj_t loc_2702)
{
   {
      node_t aux_3771;
      aux_3771 = cnst_alloc_vector_65_cnst_alloc(vec_2701, loc_2702);
      return (obj_t) (aux_3771);
   }
}


/* cnst-alloc-tvector */ node_t 
cnst_alloc_tvector_190_cnst_alloc(obj_t tvec_49, obj_t loc_50)
{
   {
      {
	 bool_t test2038_1316;
	 test2038_1316 = tvector_c_static__211_tvector_cnst(tvec_49);
	 if (test2038_1316)
	   {
	      var_t aux_3776;
	      {
		 global_t var_1320;
		 {
		    obj_t arg2072_1353;
		    obj_t arg2073_1354;
		    {
		       obj_t arg2074_1355;
		       arg2074_1355 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 30)), BEOA);
		       {
			  obj_t list2076_1357;
			  {
			     obj_t arg2077_1358;
			     {
				obj_t aux_3780;
				aux_3780 = CNST_TABLE_REF(((long) 31));
				arg2077_1358 = MAKE_PAIR(aux_3780, BNIL);
			     }
			     list2076_1357 = MAKE_PAIR(arg2074_1355, arg2077_1358);
			  }
			  arg2072_1353 = symbol_append_197___r4_symbols_6_4(list2076_1357);
		       }
		    }
		    arg2073_1354 = CNST_TABLE_REF(((long) 32));
		    var_1320 = def_global_scnst__93_ast_glo_def_117(arg2072_1353, _module__166_module_module, tvec_49, arg2073_1354);
		 }
		 {
		    obj_t id_1321;
		    {
		       type_t obj_2559;
		       {
			  obj_t aux_3787;
			  aux_3787 = STRUCT_REF(tvec_49, ((long) 0));
			  obj_2559 = (type_t) (aux_3787);
		       }
		       id_1321 = (((type_t) CREF(obj_2559))->id);
		    }
		    {
		       node_t aid_1322;
		       {
			  kwote_t arg2063_1345;
			  {
			     type_t arg2065_1347;
			     arg2065_1347 = get_default_type_181_type_cache();
			     {
				kwote_t res2203_2570;
				{
				   kwote_t new1248_2563;
				   new1248_2563 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
				   {
				      long arg2117_2564;
				      arg2117_2564 = class_num_218___object(kwote_ast_node);
				      {
					 obj_t obj_2568;
					 obj_2568 = (obj_t) (new1248_2563);
					 (((obj_t) CREF(obj_2568))->header = MAKE_HEADER(arg2117_2564, 0), BUNSPEC);
				      }
				   }
				   {
				      object_t aux_3796;
				      aux_3796 = (object_t) (new1248_2563);
				      OBJECT_WIDENING_SET(aux_3796, BFALSE);
				   }
				   ((((kwote_t) CREF(new1248_2563))->loc) = ((obj_t) loc_50), BUNSPEC);
				   ((((kwote_t) CREF(new1248_2563))->type) = ((type_t) arg2065_1347), BUNSPEC);
				   ((((kwote_t) CREF(new1248_2563))->value) = ((obj_t) id_1321), BUNSPEC);
				   res2203_2570 = new1248_2563;
				}
				arg2063_1345 = res2203_2570;
			     }
			  }
			  aid_1322 = cnst__44_cnst_node((node_t) (arg2063_1345));
		       }
		       {
			  {
			     obj_t arg2041_1323;
			     {
				obj_t arg2042_1324;
				obj_t arg2043_1325;
				obj_t arg2044_1326;
				arg2042_1324 = CNST_TABLE_REF(((long) 33));
				{
				   obj_t arg2050_1332;
				   obj_t arg2051_1333;
				   obj_t arg2052_1334;
				   arg2050_1332 = CNST_TABLE_REF(((long) 13));
				   arg2051_1333 = (((global_t) CREF(var_1320))->id);
				   arg2052_1334 = (((global_t) CREF(var_1320))->module);
				   {
				      obj_t list2054_1336;
				      {
					 obj_t arg2055_1337;
					 {
					    obj_t arg2056_1338;
					    arg2056_1338 = MAKE_PAIR(BNIL, BNIL);
					    arg2055_1337 = MAKE_PAIR(arg2052_1334, arg2056_1338);
					 }
					 list2054_1336 = MAKE_PAIR(arg2051_1333, arg2055_1337);
				      }
				      arg2043_1325 = cons__138___r4_pairs_and_lists_6_3(arg2050_1332, list2054_1336);
				   }
				}
				{
				   obj_t arg2058_1340;
				   arg2058_1340 = CNST_TABLE_REF(((long) 34));
				   {
				      obj_t list2060_1342;
				      {
					 obj_t arg2061_1343;
					 arg2061_1343 = MAKE_PAIR(BNIL, BNIL);
					 {
					    obj_t aux_3814;
					    aux_3814 = (obj_t) (aid_1322);
					    list2060_1342 = MAKE_PAIR(aux_3814, arg2061_1343);
					 }
				      }
				      arg2044_1326 = cons__138___r4_pairs_and_lists_6_3(arg2058_1340, list2060_1342);
				   }
				}
				{
				   obj_t list2046_1328;
				   {
				      obj_t arg2047_1329;
				      {
					 obj_t arg2048_1330;
					 arg2048_1330 = MAKE_PAIR(BNIL, BNIL);
					 arg2047_1329 = MAKE_PAIR(arg2044_1326, arg2048_1330);
				      }
				      list2046_1328 = MAKE_PAIR(arg2043_1325, arg2047_1329);
				   }
				   arg2041_1323 = cons__138___r4_pairs_and_lists_6_3(arg2042_1324, list2046_1328);
				}
			     }
			     {
				obj_t obj2_2575;
				obj2_2575 = _global_sexp__67_cnst_alloc;
				_global_sexp__67_cnst_alloc = MAKE_PAIR(arg2041_1323, obj2_2575);
			     }
			  }
		       }
		    }
		 }
		 {
		    type_t arg2070_1351;
		    {
		       variable_t obj_2576;
		       obj_2576 = (variable_t) (var_1320);
		       arg2070_1351 = (((variable_t) CREF(obj_2576))->type);
		    }
		    {
		       var_t res2204_2587;
		       {
			  variable_t variable_2579;
			  variable_2579 = (variable_t) (var_1320);
			  {
			     var_t new1232_2580;
			     new1232_2580 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			     {
				long arg2123_2581;
				arg2123_2581 = class_num_218___object(var_ast_node);
				{
				   obj_t obj_2585;
				   obj_2585 = (obj_t) (new1232_2580);
				   (((obj_t) CREF(obj_2585))->header = MAKE_HEADER(arg2123_2581, 0), BUNSPEC);
				}
			     }
			     {
				object_t aux_3830;
				aux_3830 = (object_t) (new1232_2580);
				OBJECT_WIDENING_SET(aux_3830, BFALSE);
			     }
			     ((((var_t) CREF(new1232_2580))->loc) = ((obj_t) loc_50), BUNSPEC);
			     ((((var_t) CREF(new1232_2580))->type) = ((type_t) arg2070_1351), BUNSPEC);
			     ((((var_t) CREF(new1232_2580))->variable) = ((variable_t) variable_2579), BUNSPEC);
			     res2204_2587 = new1232_2580;
			  }
		       }
		       aux_3776 = res2204_2587;
		    }
		 }
	      }
	      return (node_t) (aux_3776);
	   }
	 else
	   {
	      app_t aux_3837;
	      internal_error_43_tools_error(string2215_cnst_alloc, string2216_cnst_alloc, tvec_49);
	      {
		 long offset_1318;
		 offset_1318 = _cnst_offset__211_cnst_alloc;
		 {
		    long z2_2553;
		    z2_2553 = _cnst_offset__211_cnst_alloc;
		    _cnst_offset__211_cnst_alloc = (((long) 1) + z2_2553);
		 }
		 {
		    obj_t obj2_2555;
		    obj2_2555 = _global_set__17_cnst_alloc;
		    _global_set__17_cnst_alloc = MAKE_PAIR(tvec_49, obj2_2555);
		 }
		 aux_3837 = make_cnst_table_ref_93_cnst_alloc(BINT(offset_1318), loc_50);
	      }
	      return (node_t) (aux_3837);
	   }
      }
   }
}


/* _cnst-alloc-tvector */ obj_t 
_cnst_alloc_tvector_13_cnst_alloc(obj_t env_2703, obj_t tvec_2704, obj_t loc_2705)
{
   {
      node_t aux_3844;
      aux_3844 = cnst_alloc_tvector_190_cnst_alloc(tvec_2704, loc_2705);
      return (obj_t) (aux_3844);
   }
}


/* method-init */ obj_t 
method_init_76_cnst_alloc()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cnst_alloc()
{
   module_initialization_70_engine_param(((long) 0), "CNST_ALLOC");
   module_initialization_70_module_module(((long) 0), "CNST_ALLOC");
   module_initialization_70_tools_shape(((long) 0), "CNST_ALLOC");
   module_initialization_70_tools_error(((long) 0), "CNST_ALLOC");
   module_initialization_70_type_type(((long) 0), "CNST_ALLOC");
   module_initialization_70_type_cache(((long) 0), "CNST_ALLOC");
   module_initialization_70_tvector_tvector(((long) 0), "CNST_ALLOC");
   module_initialization_70_tvector_cnst(((long) 0), "CNST_ALLOC");
   module_initialization_70_ast_var(((long) 0), "CNST_ALLOC");
   module_initialization_70_ast_node(((long) 0), "CNST_ALLOC");
   module_initialization_70_ast_sexp(((long) 0), "CNST_ALLOC");
   module_initialization_70_ast_local(((long) 0), "CNST_ALLOC");
   module_initialization_70_ast_glo_def_117(((long) 0), "CNST_ALLOC");
   module_initialization_70_coerce_coerce(((long) 0), "CNST_ALLOC");
   module_initialization_70_cnst_cache(((long) 0), "CNST_ALLOC");
   return module_initialization_70_cnst_node(((long) 0), "CNST_ALLOC");
}
