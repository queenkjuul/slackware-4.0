/*===========================================================================*/
/*   (Expand/if.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t expand_test_227_expand_if(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static bool_t _case_enabled___36_expand_if;
extern obj_t _nil__217___eval;
static obj_t is_case__38_expand_if(obj_t);
extern obj_t module_initialization_70_expand_if(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static bool_t is_a_valid_constant__191_expand_if(obj_t);
static obj_t imported_modules_init_94_expand_if();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t expand_and_bool_91_expand_if(obj_t);
static obj_t _expand_if1583_10_expand_if(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_expand_if();
extern obj_t expand_not_139_expand_if(obj_t, obj_t);
static obj_t loop_1585_expand_if(obj_t, obj_t);
static obj_t toplevel_init_63_expand_if();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t if__case__94_expand_if(obj_t);
static obj_t loop_expand_if(obj_t, obj_t);
extern obj_t expand_if_74_expand_if(obj_t, obj_t);
static obj_t find_case_exp_129_expand_if(obj_t);
static obj_t expand_or_bool_93_expand_if(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t expand_if_with_178_expand_if(obj_t, obj_t, obj_t, bool_t);
static obj_t new_e_210_expand_if(obj_t, obj_t);
static obj_t require_initialization_114_expand_if = BUNSPEC;
static obj_t _expand_not1584_218_expand_if(obj_t, obj_t, obj_t);
static obj_t _expand_test_7_expand_if(obj_t, obj_t, obj_t);
static obj_t make_clause_253_expand_if(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_expand_if();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[13];

DEFINE_STATIC_PROCEDURE(expand_test_env_129_expand_if, _expand_test_7_expand_if1597, _expand_test_7_expand_if, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_if_env_52_expand_if, _expand_if1583_10_expand_if1598, _expand_if1583_10_expand_if, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_not_env_116_expand_if, _expand_not1584_218_expand_if1599, _expand_not1584_218_expand_if, 0L, 2);
DEFINE_STRING(string1591_expand_if, string1591_expand_if1600, "ELSE CASE QUOTE MEMQ CHAR=? =FX EQ? AND OR NULL? LET TEST IF ", 61);
DEFINE_STRING(string1589_expand_if, string1589_expand_if1601, "Illegal `if' form", 17);
DEFINE_STRING(string1590_expand_if, string1590_expand_if1602, "Illegal `not' form", 18);
DEFINE_STRING(string1588_expand_if, string1588_expand_if1603, "Illegal form", 12);
DEFINE_STRING(string1587_expand_if, string1587_expand_if1604, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string1586_expand_if, string1586_expand_if1605, "cer", 3);


/* module-initialization */ obj_t 
module_initialization_70_expand_if(long checksum_890, char *from_891)
{
   if (CBOOL(require_initialization_114_expand_if))
     {
	require_initialization_114_expand_if = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_if();
	cnst_init_137_expand_if();
	imported_modules_init_94_expand_if();
	toplevel_init_63_expand_if();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_if()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_IF");
   module_initialization_70___eval(((long) 0), "EXPAND_IF");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_IF");
   module_initialization_70___reader(((long) 0), "EXPAND_IF");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_if()
{
   {
      obj_t cnst_port_138_882;
      cnst_port_138_882 = open_input_string(string1591_expand_if);
      {
	 long i_883;
	 i_883 = ((long) 12);
       loop_884:
	 {
	    bool_t test1592_885;
	    test1592_885 = (i_883 == ((long) -1));
	    if (test1592_885)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1593_886;
		    {
		       obj_t list1594_887;
		       {
			  obj_t arg1595_888;
			  arg1595_888 = BNIL;
			  list1594_887 = MAKE_PAIR(cnst_port_138_882, arg1595_888);
		       }
		       arg1593_886 = read___reader(list1594_887);
		    }
		    CNST_TABLE_SET(i_883, arg1593_886);
		 }
		 {
		    int aux_889;
		    {
		       long aux_909;
		       aux_909 = (i_883 - ((long) 1));
		       aux_889 = (int) (aux_909);
		    }
		    {
		       long i_912;
		       i_912 = (long) (aux_889);
		       i_883 = i_912;
		       goto loop_884;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_if()
{
   return (_case_enabled___36_expand_if = ((bool_t) 1),
      BUNSPEC);
}


/* expand-or/bool */ obj_t 
expand_or_bool_93_expand_if(obj_t exp_1)
{
   {
      obj_t res_20;
      res_20 = loop_1585_expand_if(exp_1, CDR(exp_1));
      return replace__160_tools_misc(exp_1, res_20);
   }
}


/* loop_1585 */ obj_t 
loop_1585_expand_if(obj_t exp_881, obj_t sor_21)
{
   if (NULLP(sor_21))
     {
	return BFALSE;
     }
   else
     {
	if (PAIRP(sor_21))
	  {
	     bool_t test_921;
	     {
		obj_t aux_922;
		aux_922 = CDR(sor_21);
		test_921 = NULLP(aux_922);
	     }
	     if (test_921)
	       {
		  return CAR(sor_21);
	       }
	     else
	       {
		  {
		     obj_t res_27;
		     {
			obj_t arg1034_34;
			obj_t arg1038_35;
			obj_t arg1039_36;
			arg1034_34 = CNST_TABLE_REF(((long) 0));
			arg1038_35 = CAR(sor_21);
			arg1039_36 = loop_1585_expand_if(exp_881, CDR(sor_21));
			{
			   obj_t list1041_38;
			   {
			      obj_t arg1053_39;
			      {
				 obj_t arg1055_40;
				 {
				    obj_t arg1056_41;
				    arg1056_41 = MAKE_PAIR(BNIL, BNIL);
				    arg1055_40 = MAKE_PAIR(arg1039_36, arg1056_41);
				 }
				 arg1053_39 = MAKE_PAIR(BTRUE, arg1055_40);
			      }
			      list1041_38 = MAKE_PAIR(arg1038_35, arg1053_39);
			   }
			   res_27 = cons__138___r4_pairs_and_lists_6_3(arg1034_34, list1041_38);
			}
		     }
		     {
			bool_t test1015_28;
			{
			   obj_t aux_935;
			   aux_935 = CAR(sor_21);
			   test1015_28 = EXTENDED_PAIRP(aux_935);
			}
			if (test1015_28)
			  {
			     {
				obj_t arg1016_29;
				obj_t arg1018_30;
				obj_t arg1020_31;
				arg1016_29 = CAR(res_27);
				arg1018_30 = CDR(res_27);
				{
				   obj_t arg1025_32;
				   arg1025_32 = CAR(sor_21);
				   {
				      bool_t test1137_535;
				      test1137_535 = EXTENDED_PAIRP(arg1025_32);
				      if (test1137_535)
					{
					   arg1020_31 = CER(arg1025_32);
					}
				      else
					{
					   FAILURE(string1586_expand_if, string1587_expand_if, arg1025_32);
					}
				   }
				}
				return MAKE_EXTENDED_PAIR(arg1016_29, arg1018_30, arg1020_31);
			     }
			  }
			else
			  {
			     return res_27;
			  }
		     }
		  }
	       }
	  }
	else
	  {
	     FAILURE(BFALSE, string1588_expand_if, exp_881);
	  }
     }
}


/* expand-and/bool */ obj_t 
expand_and_bool_91_expand_if(obj_t exp_2)
{
   {
      obj_t res_45;
      res_45 = loop_expand_if(exp_2, CDR(exp_2));
      return replace__160_tools_misc(exp_2, res_45);
   }
}


/* loop */ obj_t 
loop_expand_if(obj_t exp_880, obj_t sand_46)
{
   if (NULLP(sand_46))
     {
	return BTRUE;
     }
   else
     {
	if (PAIRP(sand_46))
	  {
	     bool_t test_955;
	     {
		obj_t aux_956;
		aux_956 = CDR(sand_46);
		test_955 = NULLP(aux_956);
	     }
	     if (test_955)
	       {
		  return CAR(sand_46);
	       }
	     else
	       {
		  {
		     obj_t res_52;
		     {
			obj_t arg1150_59;
			obj_t arg1157_60;
			obj_t arg1161_61;
			arg1150_59 = CNST_TABLE_REF(((long) 0));
			arg1157_60 = CAR(sand_46);
			arg1161_61 = loop_expand_if(exp_880, CDR(sand_46));
			{
			   obj_t list1164_63;
			   {
			      obj_t arg1175_64;
			      {
				 obj_t arg1176_65;
				 {
				    obj_t arg1187_66;
				    arg1187_66 = MAKE_PAIR(BNIL, BNIL);
				    arg1176_65 = MAKE_PAIR(BFALSE, arg1187_66);
				 }
				 arg1175_64 = MAKE_PAIR(arg1161_61, arg1176_65);
			      }
			      list1164_63 = MAKE_PAIR(arg1157_60, arg1175_64);
			   }
			   res_52 = cons__138___r4_pairs_and_lists_6_3(arg1150_59, list1164_63);
			}
		     }
		     {
			bool_t test1070_53;
			{
			   obj_t aux_969;
			   aux_969 = CAR(sand_46);
			   test1070_53 = EXTENDED_PAIRP(aux_969);
			}
			if (test1070_53)
			  {
			     {
				obj_t arg1077_54;
				obj_t arg1137_55;
				obj_t arg1142_56;
				arg1077_54 = CAR(res_52);
				arg1137_55 = CDR(res_52);
				{
				   obj_t arg1144_57;
				   arg1144_57 = CAR(sand_46);
				   {
				      bool_t test1137_560;
				      test1137_560 = EXTENDED_PAIRP(arg1144_57);
				      if (test1137_560)
					{
					   arg1142_56 = CER(arg1144_57);
					}
				      else
					{
					   FAILURE(string1586_expand_if, string1587_expand_if, arg1144_57);
					}
				   }
				}
				return MAKE_EXTENDED_PAIR(arg1077_54, arg1137_55, arg1142_56);
			     }
			  }
			else
			  {
			     return res_52;
			  }
		     }
		  }
	       }
	  }
	else
	  {
	     FAILURE(BFALSE, string1588_expand_if, exp_880);
	  }
     }
}


/* expand-test */ obj_t 
expand_test_227_expand_if(obj_t x_3, obj_t e_4)
{
   if (CBOOL(_nil__217___eval))
     {
	obj_t res_71;
	res_71 = new_e_210_expand_if(x_3, e_4);
	{
	   bool_t test_985;
	   if (PAIRP(x_3))
	     {
		test_985 = PAIRP(res_71);
	     }
	   else
	     {
		test_985 = ((bool_t) 0);
	     }
	   if (test_985)
	     {
		return replace__160_tools_misc(x_3, res_71);
	     }
	   else
	     {
		return res_71;
	     }
	}
     }
   else
     {
	obj_t aux_74;
	aux_74 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
	{
	   obj_t arg1194_75;
	   obj_t arg1195_76;
	   obj_t arg1196_77;
	   arg1194_75 = CNST_TABLE_REF(((long) 2));
	   {
	      obj_t arg1202_83;
	      {
		 obj_t arg1206_87;
		 arg1206_87 = new_e_210_expand_if(x_3, e_4);
		 {
		    obj_t list1208_89;
		    {
		       obj_t arg1209_90;
		       arg1209_90 = MAKE_PAIR(BNIL, BNIL);
		       list1208_89 = MAKE_PAIR(arg1206_87, arg1209_90);
		    }
		    arg1202_83 = cons__138___r4_pairs_and_lists_6_3(aux_74, list1208_89);
		 }
	      }
	      {
		 obj_t list1204_85;
		 list1204_85 = MAKE_PAIR(BNIL, BNIL);
		 arg1195_76 = cons__138___r4_pairs_and_lists_6_3(arg1202_83, list1204_85);
	      }
	   }
	   {
	      obj_t arg1211_92;
	      obj_t arg1213_93;
	      arg1211_92 = CNST_TABLE_REF(((long) 0));
	      {
		 obj_t arg1222_100;
		 obj_t arg1224_101;
		 arg1222_100 = CNST_TABLE_REF(((long) 0));
		 {
		    obj_t arg1234_108;
		    arg1234_108 = CNST_TABLE_REF(((long) 3));
		    {
		       obj_t list1236_110;
		       {
			  obj_t arg1238_111;
			  arg1238_111 = MAKE_PAIR(BNIL, BNIL);
			  list1236_110 = MAKE_PAIR(aux_74, arg1238_111);
		       }
		       arg1224_101 = cons__138___r4_pairs_and_lists_6_3(arg1234_108, list1236_110);
		    }
		 }
		 {
		    obj_t list1226_103;
		    {
		       obj_t arg1228_104;
		       {
			  obj_t arg1231_105;
			  {
			     obj_t arg1232_106;
			     arg1232_106 = MAKE_PAIR(BNIL, BNIL);
			     arg1231_105 = MAKE_PAIR(BTRUE, arg1232_106);
			  }
			  arg1228_104 = MAKE_PAIR(BFALSE, arg1231_105);
		       }
		       list1226_103 = MAKE_PAIR(arg1224_101, arg1228_104);
		    }
		    arg1213_93 = cons__138___r4_pairs_and_lists_6_3(arg1222_100, list1226_103);
		 }
	      }
	      {
		 obj_t list1215_95;
		 {
		    obj_t arg1216_96;
		    {
		       obj_t arg1219_97;
		       {
			  obj_t arg1220_98;
			  arg1220_98 = MAKE_PAIR(BNIL, BNIL);
			  arg1219_97 = MAKE_PAIR(BFALSE, arg1220_98);
		       }
		       arg1216_96 = MAKE_PAIR(arg1213_93, arg1219_97);
		    }
		    list1215_95 = MAKE_PAIR(aux_74, arg1216_96);
		 }
		 arg1196_77 = cons__138___r4_pairs_and_lists_6_3(arg1211_92, list1215_95);
	      }
	   }
	   {
	      obj_t list1198_79;
	      {
		 obj_t arg1199_80;
		 {
		    obj_t arg1200_81;
		    arg1200_81 = MAKE_PAIR(BNIL, BNIL);
		    arg1199_80 = MAKE_PAIR(arg1196_77, arg1200_81);
		 }
		 list1198_79 = MAKE_PAIR(arg1195_76, arg1199_80);
	      }
	      return cons__138___r4_pairs_and_lists_6_3(arg1194_75, list1198_79);
	   }
	}
     }
}


/* new-e */ obj_t 
new_e_210_expand_if(obj_t x_114, obj_t e_115)
{
 new_e_210_expand_if:
   {
      if (PAIRP(x_114))
	{
	   bool_t test_1022;
	   {
	      obj_t aux_1025;
	      obj_t aux_1023;
	      aux_1025 = CNST_TABLE_REF(((long) 4));
	      aux_1023 = CAR(x_114);
	      test_1022 = (aux_1023 == aux_1025);
	   }
	   if (test_1022)
	     {
		{
		   obj_t arg1252_128;
		   arg1252_128 = expand_or_bool_93_expand_if(x_114);
		   {
		      obj_t x_1029;
		      x_1029 = arg1252_128;
		      x_114 = x_1029;
		      goto new_e_210_expand_if;
		   }
		}
	     }
	   else
	     {
		bool_t test_1030;
		{
		   obj_t aux_1033;
		   obj_t aux_1031;
		   aux_1033 = CNST_TABLE_REF(((long) 5));
		   aux_1031 = CAR(x_114);
		   test_1030 = (aux_1031 == aux_1033);
		}
		if (test_1030)
		  {
		     {
			obj_t arg1253_129;
			arg1253_129 = expand_and_bool_91_expand_if(x_114);
			{
			   obj_t x_1037;
			   x_1037 = arg1253_129;
			   x_114 = x_1037;
			   goto new_e_210_expand_if;
			}
		     }
		  }
		else
		  {
		   tag_122_225_119:
		     return PROCEDURE_ENTRY(e_115) (e_115, x_114, e_115, BEOA);
		  }
	     }
	}
      else
	{
	   goto tag_122_225_119;
	}
   }
}


/* _expand-test */ obj_t 
_expand_test_7_expand_if(obj_t env_871, obj_t x_872, obj_t e_873)
{
   return expand_test_227_expand_if(x_872, e_873);
}


/* expand-if */ obj_t 
expand_if_74_expand_if(obj_t x_5, obj_t e_6)
{
   {
      obj_t test_141;
      obj_t alors_142;
      obj_t test_137;
      obj_t alors_138;
      obj_t sinon_139;
      if (PAIRP(x_5))
	{
	   obj_t cdr_140_144_147;
	   cdr_140_144_147 = CDR(x_5);
	   if (PAIRP(cdr_140_144_147))
	     {
		obj_t cdr_144_157_149;
		cdr_144_157_149 = CDR(cdr_140_144_147);
		{
		   bool_t test_1047;
		   {
		      obj_t aux_1048;
		      aux_1048 = CAR(cdr_140_144_147);
		      test_1047 = (aux_1048 == BTRUE);
		   }
		   if (test_1047)
		     {
			if (PAIRP(cdr_144_157_149))
			  {
			     obj_t cdr_148_78_152;
			     cdr_148_78_152 = CDR(cdr_144_157_149);
			     if (PAIRP(cdr_148_78_152))
			       {
				  bool_t test_1056;
				  {
				     obj_t aux_1057;
				     aux_1057 = CDR(cdr_148_78_152);
				     test_1056 = (aux_1057 == BNIL);
				  }
				  if (test_1056)
				    {
				       obj_t arg1308_597;
				       arg1308_597 = PROCEDURE_ENTRY(e_6) (e_6, CAR(cdr_144_157_149), e_6, BEOA);
				       return replace__160_tools_misc(x_5, arg1308_597);
				    }
				  else
				    {
				     tag_132_226_144:
				       FAILURE(BFALSE, string1589_expand_if, x_5);
				    }
			       }
			     else
			       {
				  obj_t cdr_195_37_160;
				  cdr_195_37_160 = CDR(cdr_140_144_147);
				  {
				     bool_t test_1066;
				     {
					obj_t aux_1067;
					aux_1067 = CDR(cdr_195_37_160);
					test_1066 = (aux_1067 == BNIL);
				     }
				     if (test_1066)
				       {
					  test_141 = CAR(cdr_140_144_147);
					  alors_142 = CAR(cdr_195_37_160);
					tag_131_18_143:
					  {
					     obj_t res_230;
					     {
						obj_t arg1332_231;
						obj_t arg1333_232;
						obj_t arg1334_233;
						arg1332_231 = CNST_TABLE_REF(((long) 0));
						arg1333_232 = expand_if_with_178_expand_if(expand_test_env_129_expand_if, test_141, e_6, ((bool_t) 1));
						arg1334_233 = expand_if_with_178_expand_if(e_6, alors_142, e_6, ((bool_t) 1));
						{
						   obj_t list1338_235;
						   {
						      obj_t arg1339_236;
						      {
							 obj_t arg1340_237;
							 {
							    obj_t arg1342_238;
							    arg1342_238 = MAKE_PAIR(BNIL, BNIL);
							    arg1340_237 = MAKE_PAIR(BUNSPEC, arg1342_238);
							 }
							 arg1339_236 = MAKE_PAIR(arg1334_233, arg1340_237);
						      }
						      list1338_235 = MAKE_PAIR(arg1333_232, arg1339_236);
						   }
						   res_230 = cons__138___r4_pairs_and_lists_6_3(arg1332_231, list1338_235);
						}
					     }
					     return replace__160_tools_misc(x_5, res_230);
					  }
				       }
				     else
				       {
					  goto tag_132_226_144;
				       }
				  }
			       }
			  }
			else
			  {
			     goto tag_132_226_144;
			  }
		     }
		   else
		     {
			obj_t cdr_228_151_167;
			cdr_228_151_167 = CDR(cdr_140_144_147);
			{
			   bool_t test_1082;
			   {
			      obj_t aux_1083;
			      aux_1083 = CAR(cdr_140_144_147);
			      test_1082 = (aux_1083 == BFALSE);
			   }
			   if (test_1082)
			     {
				if (PAIRP(cdr_228_151_167))
				  {
				     obj_t cdr_232_104_170;
				     cdr_232_104_170 = CDR(cdr_228_151_167);
				     if (PAIRP(cdr_232_104_170))
				       {
					  bool_t test_1091;
					  {
					     obj_t aux_1092;
					     aux_1092 = CDR(cdr_232_104_170);
					     test_1091 = (aux_1092 == BNIL);
					  }
					  if (test_1091)
					    {
					       obj_t arg1309_620;
					       arg1309_620 = PROCEDURE_ENTRY(e_6) (e_6, CAR(cdr_232_104_170), e_6, BEOA);
					       return replace__160_tools_misc(x_5, arg1309_620);
					    }
					  else
					    {
					       goto tag_132_226_144;
					    }
				       }
				     else
				       {
					  obj_t cdr_269_208_178;
					  cdr_269_208_178 = CDR(cdr_140_144_147);
					  {
					     bool_t test_1100;
					     {
						obj_t aux_1101;
						aux_1101 = CDR(cdr_269_208_178);
						test_1100 = (aux_1101 == BNIL);
					     }
					     if (test_1100)
					       {
						  obj_t alors_1106;
						  obj_t test_1104;
						  test_1104 = CAR(cdr_140_144_147);
						  alors_1106 = CAR(cdr_269_208_178);
						  alors_142 = alors_1106;
						  test_141 = test_1104;
						  goto tag_131_18_143;
					       }
					     else
					       {
						  goto tag_132_226_144;
					       }
					  }
				       }
				  }
				else
				  {
				     goto tag_132_226_144;
				  }
			     }
			   else
			     {
				obj_t cdr_299_139_185;
				cdr_299_139_185 = CDR(cdr_140_144_147);
				if (PAIRP(cdr_299_139_185))
				  {
				     obj_t cdr_304_134_187;
				     cdr_304_134_187 = CDR(cdr_299_139_185);
				     if (PAIRP(cdr_304_134_187))
				       {
					  bool_t test_1114;
					  {
					     obj_t aux_1115;
					     aux_1115 = CDR(cdr_304_134_187);
					     test_1114 = (aux_1115 == BNIL);
					  }
					  if (test_1114)
					    {
					       test_137 = CAR(cdr_140_144_147);
					       alors_138 = CAR(cdr_299_139_185);
					       sinon_139 = CAR(cdr_304_134_187);
					       {
						  obj_t new_test_233_208;
						  obj_t new_then_104_209;
						  obj_t new_else_66_210;
						  {
						     obj_t arg1328_227;
						     arg1328_227 = expand_if_with_178_expand_if(expand_test_env_129_expand_if, test_137, e_6, ((bool_t) 1));
						     new_test_233_208 = replace__160_tools_misc(test_137, arg1328_227);
						  }
						  {
						     obj_t arg1330_228;
						     arg1330_228 = expand_if_with_178_expand_if(e_6, alors_138, e_6, ((bool_t) 1));
						     new_then_104_209 = replace__160_tools_misc(alors_138, arg1330_228);
						  }
						  {
						     obj_t arg1331_229;
						     arg1331_229 = expand_if_with_178_expand_if(e_6, sinon_139, e_6, ((bool_t) 0));
						     new_else_66_210 = replace__160_tools_misc(sinon_139, arg1331_229);
						  }
						  {
						     obj_t res_211;
						     {
							obj_t exp_212;
							{
							   obj_t arg1319_220;
							   arg1319_220 = CNST_TABLE_REF(((long) 0));
							   {
							      obj_t list1322_222;
							      {
								 obj_t arg1323_223;
								 {
								    obj_t arg1324_224;
								    {
								       obj_t arg1325_225;
								       arg1325_225 = MAKE_PAIR(BNIL, BNIL);
								       arg1324_224 = MAKE_PAIR(new_else_66_210, arg1325_225);
								    }
								    arg1323_223 = MAKE_PAIR(new_then_104_209, arg1324_224);
								 }
								 list1322_222 = MAKE_PAIR(new_test_233_208, arg1323_223);
							      }
							      exp_212 = cons__138___r4_pairs_and_lists_6_3(arg1319_220, list1322_222);
							   }
							}
							if (_case_enabled___36_expand_if)
							  {
							     obj_t new_exp_239_213;
							     new_exp_239_213 = find_case_exp_129_expand_if(exp_212);
							     if (CBOOL(new_exp_239_213))
							       {
								  obj_t new_new_exp_82_214;
								  {
								     obj_t arg1316_219;
								     arg1316_219 = if__case__94_expand_if(new_exp_239_213);
								     new_new_exp_82_214 = PROCEDURE_ENTRY(e_6) (e_6, arg1316_219, e_6, BEOA);
								  }
								  {
								     obj_t aux_1139;
								     obj_t aux_1137;
								     aux_1139 = CAR(new_new_exp_82_214);
								     aux_1137 = CAR(new_exp_239_213);
								     SET_CAR(aux_1137, aux_1139);
								  }
								  {
								     obj_t aux_1144;
								     obj_t aux_1142;
								     aux_1144 = CDR(new_new_exp_82_214);
								     aux_1142 = CAR(new_exp_239_213);
								     SET_CDR(aux_1142, aux_1144);
								  }
								  res_211 = exp_212;
							       }
							     else
							       {
								  res_211 = exp_212;
							       }
							  }
							else
							  {
							     res_211 = exp_212;
							  }
						     }
						     replace__160_tools_misc(x_5, res_211);
						  }
						  return x_5;
					       }
					    }
					  else
					    {
					       goto tag_132_226_144;
					    }
				       }
				     else
				       {
					  obj_t cdr_329_18_196;
					  cdr_329_18_196 = CDR(cdr_140_144_147);
					  {
					     bool_t test_1152;
					     {
						obj_t aux_1153;
						aux_1153 = CDR(cdr_329_18_196);
						test_1152 = (aux_1153 == BNIL);
					     }
					     if (test_1152)
					       {
						  obj_t alors_1158;
						  obj_t test_1156;
						  test_1156 = CAR(cdr_140_144_147);
						  alors_1158 = CAR(cdr_329_18_196);
						  alors_142 = alors_1158;
						  test_141 = test_1156;
						  goto tag_131_18_143;
					       }
					     else
					       {
						  goto tag_132_226_144;
					       }
					  }
				       }
				  }
				else
				  {
				     goto tag_132_226_144;
				  }
			     }
			}
		     }
		}
	     }
	   else
	     {
		goto tag_132_226_144;
	     }
	}
      else
	{
	   goto tag_132_226_144;
	}
   }
}


/* _expand-if1583 */ obj_t 
_expand_if1583_10_expand_if(obj_t env_874, obj_t x_875, obj_t e_876)
{
   return expand_if_74_expand_if(x_875, e_876);
}


/* expand-if-with */ obj_t 
expand_if_with_178_expand_if(obj_t e1_7, obj_t x_8, obj_t e2_9, bool_t case__171_10)
{
   {
      bool_t case_enabled__49_240;
      case_enabled__49_240 = _case_enabled___36_expand_if;
      _case_enabled___36_expand_if = case__171_10;
      {
	 obj_t res_241;
	 res_241 = PROCEDURE_ENTRY(e1_7) (e1_7, x_8, e2_9, BEOA);
	 _case_enabled___36_expand_if = case_enabled__49_240;
	 {
	    bool_t test_1163;
	    if (PAIRP(x_8))
	      {
		 test_1163 = PAIRP(res_241);
	      }
	    else
	      {
		 test_1163 = ((bool_t) 0);
	      }
	    if (test_1163)
	      {
		 return replace__160_tools_misc(x_8, res_241);
	      }
	    else
	      {
		 return res_241;
	      }
	 }
      }
   }
}


/* find-case-exp */ obj_t 
find_case_exp_129_expand_if(obj_t exp_11)
{
 find_case_exp_129_expand_if:
   {
      obj_t is_case_222_244;
      is_case_222_244 = is_case__38_expand_if(exp_11);
      if (CBOOL(is_case_222_244))
	{
	   return is_case_222_244;
	}
      else
	{
	   if (PAIRP(exp_11))
	     {
		obj_t cdr_379_84_250;
		cdr_379_84_250 = CDR(exp_11);
		{
		   bool_t test_1174;
		   {
		      obj_t aux_1177;
		      obj_t aux_1175;
		      aux_1177 = CNST_TABLE_REF(((long) 0));
		      aux_1175 = CAR(exp_11);
		      test_1174 = (aux_1175 == aux_1177);
		   }
		   if (test_1174)
		     {
			if (PAIRP(cdr_379_84_250))
			  {
			     obj_t cdr_382_59_253;
			     cdr_382_59_253 = CDR(cdr_379_84_250);
			     if (PAIRP(cdr_382_59_253))
			       {
				  obj_t cdr_385_232_255;
				  cdr_385_232_255 = CDR(cdr_382_59_253);
				  if (PAIRP(cdr_385_232_255))
				    {
				       bool_t test_1188;
				       {
					  obj_t aux_1189;
					  aux_1189 = CDR(cdr_385_232_255);
					  test_1188 = (aux_1189 == BNIL);
				       }
				       if (test_1188)
					 {
					    obj_t exp_1192;
					    exp_1192 = CAR(cdr_385_232_255);
					    exp_11 = exp_1192;
					    goto find_case_exp_129_expand_if;
					 }
				       else
					 {
					    return BFALSE;
					 }
				    }
				  else
				    {
				       return BFALSE;
				    }
			       }
			     else
			       {
				  return BFALSE;
			       }
			  }
			else
			  {
			     return BFALSE;
			  }
		     }
		   else
		     {
			return BFALSE;
		     }
		}
	     }
	   else
	     {
		return BFALSE;
	     }
	}
   }
}


/* is-case? */ obj_t 
is_case__38_expand_if(obj_t exp_12)
{
   {
      obj_t var_263;
      obj_t exp__202_264;
      long nb_clauses_139_265;
      var_263 = BNIL;
      exp__202_264 = exp_12;
      nb_clauses_139_265 = ((long) 1);
    loop_266:
      {
	 obj_t test_269;
	 obj_t sinon_270;
	 if (PAIRP(exp__202_264))
	   {
	      obj_t cdr_398_147_275;
	      cdr_398_147_275 = CDR(exp__202_264);
	      {
		 bool_t test_1197;
		 {
		    obj_t aux_1200;
		    obj_t aux_1198;
		    aux_1200 = CNST_TABLE_REF(((long) 0));
		    aux_1198 = CAR(exp__202_264);
		    test_1197 = (aux_1198 == aux_1200);
		 }
		 if (test_1197)
		   {
		      if (PAIRP(cdr_398_147_275))
			{
			   obj_t cdr_402_67_278;
			   cdr_402_67_278 = CDR(cdr_398_147_275);
			   if (PAIRP(cdr_402_67_278))
			     {
				obj_t cdr_406_48_280;
				cdr_406_48_280 = CDR(cdr_402_67_278);
				if (PAIRP(cdr_406_48_280))
				  {
				     bool_t test_1211;
				     {
					obj_t aux_1212;
					aux_1212 = CDR(cdr_406_48_280);
					test_1211 = (aux_1212 == BNIL);
				     }
				     if (test_1211)
				       {
					  test_269 = CAR(cdr_398_147_275);
					  sinon_270 = CAR(cdr_406_48_280);
					  {
					     obj_t new_var_21_292;
					     obj_t exp1_293;
					     obj_t exp1_289;
					     obj_t exp2_290;
					     if (PAIRP(test_269))
					       {
						  obj_t car_419_9_297;
						  obj_t cdr_420_191_298;
						  car_419_9_297 = CAR(test_269);
						  cdr_420_191_298 = CDR(test_269);
						  {
						     {
							bool_t test_1219;
							{
							   obj_t aux_1220;
							   aux_1220 = CNST_TABLE_REF(((long) 6));
							   test_1219 = (car_419_9_297 == aux_1220);
							}
							if (test_1219)
							  {
							   kap_421_231_299:
							     if (PAIRP(cdr_420_191_298))
							       {
								  obj_t cdr_425_74_329;
								  cdr_425_74_329 = CDR(cdr_420_191_298);
								  if (PAIRP(cdr_425_74_329))
								    {
								       bool_t test_1228;
								       {
									  obj_t aux_1229;
									  aux_1229 = CDR(cdr_425_74_329);
									  test_1228 = (aux_1229 == BNIL);
								       }
								       if (test_1228)
									 {
									    exp1_289 = CAR(cdr_420_191_298);
									    exp2_290 = CAR(cdr_425_74_329);
									    if (is_a_valid_constant__191_expand_if(exp1_289))
									      {
										 if (NULLP(var_263))
										   {
										      {
											 long nb_clauses_139_1238;
											 obj_t exp__202_1237;
											 obj_t var_1236;
											 var_1236 = exp2_290;
											 exp__202_1237 = sinon_270;
											 nb_clauses_139_1238 = (nb_clauses_139_265 + ((long) 1));
											 nb_clauses_139_265 = nb_clauses_139_1238;
											 exp__202_264 = exp__202_1237;
											 var_263 = var_1236;
											 goto loop_266;
										      }
										   }
										 else
										   {
										      if ((var_263 == exp2_290))
											{
											   {
											      long nb_clauses_139_1244;
											      obj_t exp__202_1243;
											      obj_t var_1242;
											      var_1242 = exp2_290;
											      exp__202_1243 = sinon_270;
											      nb_clauses_139_1244 = (nb_clauses_139_265 + ((long) 1));
											      nb_clauses_139_265 = nb_clauses_139_1244;
											      exp__202_264 = exp__202_1243;
											      var_263 = var_1242;
											      goto loop_266;
											   }
											}
										      else
											{
											   if ((nb_clauses_139_265 > ((long) 3)))
											     {
												obj_t list1423_342;
												{
												   obj_t arg1426_343;
												   {
												      obj_t arg1427_344;
												      arg1427_344 = MAKE_PAIR(exp__202_264, BNIL);
												      arg1426_343 = MAKE_PAIR(var_263, arg1427_344);
												   }
												   list1423_342 = MAKE_PAIR(exp_12, arg1426_343);
												}
												return list1423_342;
											     }
											   else
											     {
												return BFALSE;
											     }
											}
										   }
									      }
									    else
									      {
										 if (is_a_valid_constant__191_expand_if(exp2_290))
										   {
										      if (NULLP(var_263))
											{
											   {
											      long nb_clauses_139_1257;
											      obj_t exp__202_1256;
											      obj_t var_1255;
											      var_1255 = exp1_289;
											      exp__202_1256 = sinon_270;
											      nb_clauses_139_1257 = (nb_clauses_139_265 + ((long) 1));
											      nb_clauses_139_265 = nb_clauses_139_1257;
											      exp__202_264 = exp__202_1256;
											      var_263 = var_1255;
											      goto loop_266;
											   }
											}
										      else
											{
											   if ((var_263 == exp1_289))
											     {
												{
												   long nb_clauses_139_1263;
												   obj_t exp__202_1262;
												   obj_t var_1261;
												   var_1261 = exp1_289;
												   exp__202_1262 = sinon_270;
												   nb_clauses_139_1263 = (nb_clauses_139_265 + ((long) 1));
												   nb_clauses_139_265 = nb_clauses_139_1263;
												   exp__202_264 = exp__202_1262;
												   var_263 = var_1261;
												   goto loop_266;
												}
											     }
											   else
											     {
												if ((nb_clauses_139_265 > ((long) 3)))
												  {
												     obj_t list1435_352;
												     {
													obj_t arg1436_353;
													{
													   obj_t arg1437_354;
													   arg1437_354 = MAKE_PAIR(exp__202_264, BNIL);
													   arg1436_353 = MAKE_PAIR(var_263, arg1437_354);
													}
													list1435_352 = MAKE_PAIR(exp_12, arg1436_353);
												     }
												     return list1435_352;
												  }
												else
												  {
												     return BFALSE;
												  }
											     }
											}
										   }
										 else
										   {
										      return BFALSE;
										   }
									      }
									 }
								       else
									 {
									    return BFALSE;
									 }
								    }
								  else
								    {
								       return BFALSE;
								    }
							       }
							     else
							       {
								  return BFALSE;
							       }
							  }
							else
							  {
							     bool_t test_1272;
							     {
								obj_t aux_1273;
								aux_1273 = CNST_TABLE_REF(((long) 7));
								test_1272 = (car_419_9_297 == aux_1273);
							     }
							     if (test_1272)
							       {
								  goto kap_421_231_299;
							       }
							     else
							       {
								  bool_t test_1276;
								  {
								     obj_t aux_1277;
								     aux_1277 = CNST_TABLE_REF(((long) 8));
								     test_1276 = (car_419_9_297 == aux_1277);
								  }
								  if (test_1276)
								    {
								       goto kap_421_231_299;
								    }
								  else
								    {
								       bool_t test_1280;
								       {
									  obj_t aux_1281;
									  aux_1281 = CNST_TABLE_REF(((long) 9));
									  test_1280 = (car_419_9_297 == aux_1281);
								       }
								       if (test_1280)
									 {
									    if (PAIRP(cdr_420_191_298))
									      {
										 obj_t cdr_455_40_306;
										 cdr_455_40_306 = CDR(cdr_420_191_298);
										 if (PAIRP(cdr_455_40_306))
										   {
										      obj_t car_458_54_308;
										      car_458_54_308 = CAR(cdr_455_40_306);
										      if (PAIRP(car_458_54_308))
											{
											   obj_t cdr_462_56_310;
											   cdr_462_56_310 = CDR(car_458_54_308);
											   {
											      bool_t test_1293;
											      {
												 obj_t aux_1296;
												 obj_t aux_1294;
												 aux_1296 = CNST_TABLE_REF(((long) 10));
												 aux_1294 = CAR(car_458_54_308);
												 test_1293 = (aux_1294 == aux_1296);
											      }
											      if (test_1293)
												{
												   if (PAIRP(cdr_462_56_310))
												     {
													bool_t test_1301;
													{
													   obj_t aux_1302;
													   aux_1302 = CDR(cdr_462_56_310);
													   test_1301 = (aux_1302 == BNIL);
													}
													if (test_1301)
													  {
													     bool_t test_1305;
													     {
														obj_t aux_1306;
														aux_1306 = CDR(cdr_455_40_306);
														test_1305 = (aux_1306 == BNIL);
													     }
													     if (test_1305)
													       {
														  new_var_21_292 = CAR(cdr_420_191_298);
														  exp1_293 = CAR(cdr_462_56_310);
														  {
														     bool_t test_1309;
														     if (PAIRP(exp1_293))
														       {
															  obj_t exp1_372;
															  exp1_372 = exp1_293;
															loop_373:
															  if (NULLP(exp1_372))
															    {
															       test_1309 = ((bool_t) 1);
															    }
															  else
															    {
															       if (is_a_valid_constant__191_expand_if(CAR(exp1_372)))
																 {
																    {
																       obj_t exp1_1317;
																       exp1_1317 = CDR(exp1_372);
																       exp1_372 = exp1_1317;
																       goto loop_373;
																    }
																 }
															       else
																 {
																    test_1309 = ((bool_t) 0);
																 }
															    }
														       }
														     else
														       {
															  test_1309 = ((bool_t) 0);
														       }
														     if (test_1309)
														       {
															  if (NULLP(var_263))
															    {
															       {
																  long nb_clauses_139_1323;
																  obj_t exp__202_1322;
																  obj_t var_1321;
																  var_1321 = new_var_21_292;
																  exp__202_1322 = sinon_270;
																  nb_clauses_139_1323 = (nb_clauses_139_265 + ((long) 1));
																  nb_clauses_139_265 = nb_clauses_139_1323;
																  exp__202_264 = exp__202_1322;
																  var_263 = var_1321;
																  goto loop_266;
															       }
															    }
															  else
															    {
															       if ((new_var_21_292 == var_263))
																 {
																    {
																       long nb_clauses_139_1329;
																       obj_t exp__202_1328;
																       obj_t var_1327;
																       var_1327 = new_var_21_292;
																       exp__202_1328 = sinon_270;
																       nb_clauses_139_1329 = (nb_clauses_139_265 + ((long) 1));
																       nb_clauses_139_265 = nb_clauses_139_1329;
																       exp__202_264 = exp__202_1328;
																       var_263 = var_1327;
																       goto loop_266;
																    }
																 }
															       else
																 {
																    if ((nb_clauses_139_265 > ((long) 3)))
																      {
																	 obj_t list1445_362;
																	 {
																	    obj_t arg1446_363;
																	    {
																	       obj_t arg1448_364;
																	       arg1448_364 = MAKE_PAIR(exp__202_264, BNIL);
																	       arg1446_363 = MAKE_PAIR(var_263, arg1448_364);
																	    }
																	    list1445_362 = MAKE_PAIR(exp_12, arg1446_363);
																	 }
																	 return list1445_362;
																      }
																    else
																      {
																	 return BFALSE;
																      }
																 }
															    }
														       }
														     else
														       {
															  if ((nb_clauses_139_265 > ((long) 3)))
															    {
															       obj_t list1451_367;
															       {
																  obj_t arg1453_368;
																  {
																     obj_t arg1454_369;
																     arg1454_369 = MAKE_PAIR(exp__202_264, BNIL);
																     arg1453_368 = MAKE_PAIR(var_263, arg1454_369);
																  }
																  list1451_367 = MAKE_PAIR(exp_12, arg1453_368);
															       }
															       return list1451_367;
															    }
															  else
															    {
															       return BFALSE;
															    }
														       }
														  }
													       }
													     else
													       {
														  return BFALSE;
													       }
													  }
													else
													  {
													     return BFALSE;
													  }
												     }
												   else
												     {
													return BFALSE;
												     }
												}
											      else
												{
												   return BFALSE;
												}
											   }
											}
										      else
											{
											   return BFALSE;
											}
										   }
										 else
										   {
										      return BFALSE;
										   }
									      }
									    else
									      {
										 return BFALSE;
									      }
									 }
								       else
									 {
									    return BFALSE;
									 }
								    }
							       }
							  }
						     }
						  }
					       }
					     else
					       {
						  return BFALSE;
					       }
					  }
				       }
				     else
				       {
					tag_391_236_272:
					  if ((nb_clauses_139_265 > ((long) 3)))
					    {
					       obj_t list1463_379;
					       {
						  obj_t arg1464_380;
						  {
						     obj_t arg1465_381;
						     arg1465_381 = MAKE_PAIR(exp__202_264, BNIL);
						     arg1464_380 = MAKE_PAIR(var_263, arg1465_381);
						  }
						  list1463_379 = MAKE_PAIR(exp_12, arg1464_380);
					       }
					       return list1463_379;
					    }
					  else
					    {
					       return BFALSE;
					    }
				       }
				  }
				else
				  {
				     goto tag_391_236_272;
				  }
			     }
			   else
			     {
				goto tag_391_236_272;
			     }
			}
		      else
			{
			   goto tag_391_236_272;
			}
		   }
		 else
		   {
		      goto tag_391_236_272;
		   }
	      }
	   }
	 else
	   {
	      goto tag_391_236_272;
	   }
      }
   }
}


/* is-a-valid-constant? */ bool_t 
is_a_valid_constant__191_expand_if(obj_t cnst_13)
{
   {
      bool_t _ortest_1006_383;
      _ortest_1006_383 = INTEGERP(cnst_13);
      if (_ortest_1006_383)
	{
	   return _ortest_1006_383;
	}
      else
	{
	   bool_t _ortest_1008_384;
	   _ortest_1008_384 = CHARP(cnst_13);
	   if (_ortest_1008_384)
	     {
		return _ortest_1008_384;
	     }
	   else
	     {
		return CNSTP(cnst_13);
	     }
	}
   }
}


/* if->case! */ obj_t 
if__case__94_expand_if(obj_t exp_var_end_3_14)
{
   {
      obj_t exp_385;
      exp_385 = CAR(exp_var_end_3_14);
      {
	 obj_t var_386;
	 {
	    obj_t aux_1356;
	    aux_1356 = CDR(exp_var_end_3_14);
	    var_386 = CAR(aux_1356);
	 }
	 {
	    obj_t end_exp_192_387;
	    {
	       obj_t aux_1359;
	       {
		  obj_t aux_1360;
		  aux_1360 = CDR(exp_var_end_3_14);
		  aux_1359 = CDR(aux_1360);
	       }
	       end_exp_192_387 = CAR(aux_1359);
	    }
	    {
	       obj_t new_exp_239_388;
	       {
		  obj_t arg1469_391;
		  obj_t arg1470_392;
		  arg1469_391 = CNST_TABLE_REF(((long) 11));
		  {
		     obj_t arg1475_396;
		     obj_t arg1476_397;
		     {
			obj_t exp_398;
			obj_t clauses_399;
			exp_398 = exp_385;
			clauses_399 = BNIL;
		      loop_400:
			if ((exp_398 == end_exp_192_387))
			  {
			     obj_t arg1479_403;
			     {
				obj_t arg1480_404;
				{
				   obj_t arg1481_405;
				   arg1481_405 = CNST_TABLE_REF(((long) 12));
				   {
				      obj_t list1484_407;
				      {
					 obj_t arg1485_408;
					 arg1485_408 = MAKE_PAIR(BNIL, BNIL);
					 list1484_407 = MAKE_PAIR(end_exp_192_387, arg1485_408);
				      }
				      arg1480_404 = cons__138___r4_pairs_and_lists_6_3(arg1481_405, list1484_407);
				   }
				}
				arg1479_403 = MAKE_PAIR(arg1480_404, clauses_399);
			     }
			     arg1475_396 = reverse__39___r4_pairs_and_lists_6_3(arg1479_403);
			  }
			else
			  {
			     if (PAIRP(exp_398))
			       {
				  obj_t cdr_480_201_416;
				  cdr_480_201_416 = CDR(exp_398);
				  {
				     bool_t test_1376;
				     {
					obj_t aux_1379;
					obj_t aux_1377;
					aux_1379 = CNST_TABLE_REF(((long) 0));
					aux_1377 = CAR(exp_398);
					test_1376 = (aux_1377 == aux_1379);
				     }
				     if (test_1376)
				       {
					  if (PAIRP(cdr_480_201_416))
					    {
					       obj_t cdr_485_255_419;
					       cdr_485_255_419 = CDR(cdr_480_201_416);
					       if (PAIRP(cdr_485_255_419))
						 {
						    obj_t cdr_490_243_421;
						    cdr_490_243_421 = CDR(cdr_485_255_419);
						    if (PAIRP(cdr_490_243_421))
						      {
							 bool_t test_1390;
							 {
							    obj_t aux_1391;
							    aux_1391 = CDR(cdr_490_243_421);
							    test_1390 = (aux_1391 == BNIL);
							 }
							 if (test_1390)
							   {
							      obj_t arg1497_426;
							      arg1497_426 = CAR(cdr_490_243_421);
							      {
								 obj_t arg1502_807;
								 {
								    obj_t arg1503_808;
								    arg1503_808 = make_clause_253_expand_if(var_386, CAR(cdr_480_201_416), CAR(cdr_485_255_419));
								    arg1502_807 = MAKE_PAIR(arg1503_808, clauses_399);
								 }
								 {
								    obj_t clauses_1400;
								    obj_t exp_1399;
								    exp_1399 = arg1497_426;
								    clauses_1400 = arg1502_807;
								    clauses_399 = clauses_1400;
								    exp_398 = exp_1399;
								    goto loop_400;
								 }
							      }
							   }
							 else
							   {
							      arg1475_396 = BFALSE;
							   }
						      }
						    else
						      {
							 arg1475_396 = BFALSE;
						      }
						 }
					       else
						 {
						    arg1475_396 = BFALSE;
						 }
					    }
					  else
					    {
					       arg1475_396 = BFALSE;
					    }
				       }
				     else
				       {
					  arg1475_396 = BFALSE;
				       }
				  }
			       }
			     else
			       {
				  arg1475_396 = BFALSE;
			       }
			  }
		     }
		     arg1476_397 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		     arg1470_392 = append_2_18___r4_pairs_and_lists_6_3(arg1475_396, arg1476_397);
		  }
		  {
		     obj_t list1471_393;
		     {
			obj_t arg1473_394;
			arg1473_394 = MAKE_PAIR(arg1470_392, BNIL);
			list1471_393 = MAKE_PAIR(var_386, arg1473_394);
		     }
		     new_exp_239_388 = cons__138___r4_pairs_and_lists_6_3(arg1469_391, list1471_393);
		  }
	       }
	       {
		  {
		     obj_t aux_1406;
		     aux_1406 = CAR(new_exp_239_388);
		     SET_CAR(exp_385, aux_1406);
		  }
		  {
		     obj_t aux_1409;
		     aux_1409 = CDR(new_exp_239_388);
		     SET_CDR(exp_385, aux_1409);
		  }
		  return exp_385;
	       }
	    }
	 }
      }
   }
}


/* make-clause */ obj_t 
make_clause_253_expand_if(obj_t var_15, obj_t test_16, obj_t alors_17)
{
   {
      obj_t exp_438;
      obj_t exp1_435;
      obj_t exp2_436;
      if (PAIRP(test_16))
	{
	   obj_t car_504_150_442;
	   obj_t cdr_505_48_443;
	   car_504_150_442 = CAR(test_16);
	   cdr_505_48_443 = CDR(test_16);
	   {
	      {
		 bool_t test_1416;
		 {
		    obj_t aux_1417;
		    aux_1417 = CNST_TABLE_REF(((long) 6));
		    test_1416 = (car_504_150_442 == aux_1417);
		 }
		 if (test_1416)
		   {
		    kap_506_156_444:
		      if (PAIRP(cdr_505_48_443))
			{
			   obj_t cdr_510_5_473;
			   cdr_510_5_473 = CDR(cdr_505_48_443);
			   if (PAIRP(cdr_510_5_473))
			     {
				bool_t test_1425;
				{
				   obj_t aux_1426;
				   aux_1426 = CDR(cdr_510_5_473);
				   test_1425 = (aux_1426 == BNIL);
				}
				if (test_1425)
				  {
				     exp1_435 = CAR(cdr_505_48_443);
				     exp2_436 = CAR(cdr_510_5_473);
				     if ((exp1_435 == var_15))
				       {
					  obj_t arg1542_481;
					  {
					     obj_t list1551_487;
					     list1551_487 = MAKE_PAIR(BNIL, BNIL);
					     arg1542_481 = cons__138___r4_pairs_and_lists_6_3(exp2_436, list1551_487);
					  }
					  {
					     obj_t list1546_483;
					     {
						obj_t arg1548_484;
						arg1548_484 = MAKE_PAIR(BNIL, BNIL);
						list1546_483 = MAKE_PAIR(alors_17, arg1548_484);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1542_481, list1546_483);
					  }
				       }
				     else
				       {
					  obj_t arg1553_489;
					  {
					     obj_t list1559_495;
					     list1559_495 = MAKE_PAIR(BNIL, BNIL);
					     arg1553_489 = cons__138___r4_pairs_and_lists_6_3(exp1_435, list1559_495);
					  }
					  {
					     obj_t list1555_491;
					     {
						obj_t arg1556_492;
						arg1556_492 = MAKE_PAIR(BNIL, BNIL);
						list1555_491 = MAKE_PAIR(alors_17, arg1556_492);
					     }
					     return cons__138___r4_pairs_and_lists_6_3(arg1553_489, list1555_491);
					  }
				       }
				  }
				else
				  {
				     return BFALSE;
				  }
			     }
			   else
			     {
				return BFALSE;
			     }
			}
		      else
			{
			   return BFALSE;
			}
		   }
		 else
		   {
		      bool_t test_1443;
		      {
			 obj_t aux_1444;
			 aux_1444 = CNST_TABLE_REF(((long) 7));
			 test_1443 = (car_504_150_442 == aux_1444);
		      }
		      if (test_1443)
			{
			   goto kap_506_156_444;
			}
		      else
			{
			   bool_t test_1447;
			   {
			      obj_t aux_1448;
			      aux_1448 = CNST_TABLE_REF(((long) 8));
			      test_1447 = (car_504_150_442 == aux_1448);
			   }
			   if (test_1447)
			     {
				goto kap_506_156_444;
			     }
			   else
			     {
				bool_t test_1451;
				{
				   obj_t aux_1452;
				   aux_1452 = CNST_TABLE_REF(((long) 9));
				   test_1451 = (car_504_150_442 == aux_1452);
				}
				if (test_1451)
				  {
				     if (PAIRP(cdr_505_48_443))
				       {
					  obj_t cdr_529_121_451;
					  cdr_529_121_451 = CDR(cdr_505_48_443);
					  if (PAIRP(cdr_529_121_451))
					    {
					       obj_t car_531_80_453;
					       car_531_80_453 = CAR(cdr_529_121_451);
					       if (PAIRP(car_531_80_453))
						 {
						    obj_t cdr_535_10_455;
						    cdr_535_10_455 = CDR(car_531_80_453);
						    {
						       bool_t test_1464;
						       {
							  obj_t aux_1467;
							  obj_t aux_1465;
							  aux_1467 = CNST_TABLE_REF(((long) 10));
							  aux_1465 = CAR(car_531_80_453);
							  test_1464 = (aux_1465 == aux_1467);
						       }
						       if (test_1464)
							 {
							    if (PAIRP(cdr_535_10_455))
							      {
								 bool_t test_1472;
								 {
								    obj_t aux_1473;
								    aux_1473 = CDR(cdr_535_10_455);
								    test_1472 = (aux_1473 == BNIL);
								 }
								 if (test_1472)
								   {
								      bool_t test_1476;
								      {
									 obj_t aux_1477;
									 aux_1477 = CDR(cdr_529_121_451);
									 test_1476 = (aux_1477 == BNIL);
								      }
								      if (test_1476)
									{
									   exp_438 = CAR(cdr_535_10_455);
									   {
									      obj_t list1562_498;
									      {
										 obj_t arg1563_499;
										 arg1563_499 = MAKE_PAIR(BNIL, BNIL);
										 list1562_498 = MAKE_PAIR(alors_17, arg1563_499);
									      }
									      return cons__138___r4_pairs_and_lists_6_3(exp_438, list1562_498);
									   }
									}
								      else
									{
									   return BFALSE;
									}
								   }
								 else
								   {
								      return BFALSE;
								   }
							      }
							    else
							      {
								 return BFALSE;
							      }
							 }
						       else
							 {
							    return BFALSE;
							 }
						    }
						 }
					       else
						 {
						    return BFALSE;
						 }
					    }
					  else
					    {
					       return BFALSE;
					    }
				       }
				     else
				       {
					  return BFALSE;
				       }
				  }
				else
				  {
				     return BFALSE;
				  }
			     }
			}
		   }
	      }
	   }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* expand-not */ obj_t 
expand_not_139_expand_if(obj_t x_18, obj_t e_19)
{
   {
      obj_t exp_501;
      if (PAIRP(x_18))
	{
	   obj_t cdr_548_32_506;
	   cdr_548_32_506 = CDR(x_18);
	   if (PAIRP(cdr_548_32_506))
	     {
		bool_t test_1489;
		{
		   obj_t aux_1490;
		   aux_1490 = CDR(cdr_548_32_506);
		   test_1489 = (aux_1490 == BNIL);
		}
		if (test_1489)
		  {
		     exp_501 = CAR(cdr_548_32_506);
		     {
			obj_t res_512;
			{
			   obj_t arg1572_513;
			   {
			      obj_t arg1573_514;
			      arg1573_514 = CNST_TABLE_REF(((long) 0));
			      {
				 obj_t list1576_516;
				 {
				    obj_t arg1578_517;
				    {
				       obj_t arg1580_518;
				       {
					  obj_t arg1581_519;
					  arg1581_519 = MAKE_PAIR(BNIL, BNIL);
					  arg1580_518 = MAKE_PAIR(BTRUE, arg1581_519);
				       }
				       arg1578_517 = MAKE_PAIR(BFALSE, arg1580_518);
				    }
				    list1576_516 = MAKE_PAIR(exp_501, arg1578_517);
				 }
				 arg1572_513 = cons__138___r4_pairs_and_lists_6_3(arg1573_514, list1576_516);
			      }
			   }
			   res_512 = PROCEDURE_ENTRY(e_19) (e_19, arg1572_513, e_19, BEOA);
			}
			return replace__160_tools_misc(x_18, res_512);
		     }
		  }
		else
		  {
		   tag_543_197_503:
		     FAILURE(BFALSE, string1590_expand_if, x_18);
		  }
	     }
	   else
	     {
		goto tag_543_197_503;
	     }
	}
      else
	{
	   goto tag_543_197_503;
	}
   }
}


/* _expand-not1584 */ obj_t 
_expand_not1584_218_expand_if(obj_t env_877, obj_t x_878, obj_t e_879)
{
   return expand_not_139_expand_if(x_878, e_879);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_if()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_IF");
   module_initialization_70_tools_shape(((long) 0), "EXPAND_IF");
   return module_initialization_70_tools_misc(((long) 0), "EXPAND_IF");
}
