/*===========================================================================*/
/*   (Llib/hash.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _make_hash_table1357_92___hash(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _put_hash__86___hash(obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _rem_obj_hash__23___hash(obj_t, obj_t, obj_t);
extern long obj__0__255_3___hash(obj_t);
extern obj_t for_each_hash_105___hash(obj_t, obj_t);
extern long get_hash_number(char *);
extern obj_t hash_table__vector_145___hash(obj_t);
static obj_t _hash_table__vector_152___hash(obj_t, obj_t);
static obj_t toplevel_init_63___hash();
static bool_t _2_power__4___hash(obj_t);
extern long string__0__255_119___hash(char *);
static obj_t _for_each_hash1358_11___hash(obj_t, obj_t, obj_t);
extern obj_t put_hash__129___hash(obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
static obj_t get_hash_number_100___hash(obj_t, obj_t);
static obj_t _get_hash_182___hash(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t hash_table_grows__110___hash(obj_t);
extern obj_t hash_table_nb_entry_45___hash(obj_t);
extern obj_t get_hash_29___hash(obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _int__0__2_x_11362_181___hash(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___hash(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _int__0__2551361_6___hash(obj_t, obj_t);
static obj_t _hash_table__163___hash(obj_t, obj_t);
static obj_t symbol2519___hash = BUNSPEC;
static obj_t symbol2520___hash = BUNSPEC;
static obj_t symbol2518___hash = BUNSPEC;
static obj_t symbol2515___hash = BUNSPEC;
static obj_t symbol2514___hash = BUNSPEC;
static obj_t symbol2513___hash = BUNSPEC;
static obj_t symbol2512___hash = BUNSPEC;
static obj_t symbol2511___hash = BUNSPEC;
static obj_t symbol2499___hash = BUNSPEC;
static obj_t symbol2509___hash = BUNSPEC;
static obj_t symbol2510___hash = BUNSPEC;
static obj_t symbol2507___hash = BUNSPEC;
static obj_t symbol2496___hash = BUNSPEC;
static obj_t symbol2506___hash = BUNSPEC;
static obj_t symbol2495___hash = BUNSPEC;
static obj_t symbol2505___hash = BUNSPEC;
static obj_t symbol2504___hash = BUNSPEC;
static obj_t symbol2493___hash = BUNSPEC;
static obj_t symbol2503___hash = BUNSPEC;
static obj_t symbol2491___hash = BUNSPEC;
static obj_t symbol2489___hash = BUNSPEC;
static obj_t symbol2500___hash = BUNSPEC;
static obj_t symbol2486___hash = BUNSPEC;
static obj_t symbol2483___hash = BUNSPEC;
static obj_t symbol2482___hash = BUNSPEC;
static obj_t symbol2480___hash = BUNSPEC;
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2477___hash = BUNSPEC;
static obj_t symbol2474___hash = BUNSPEC;
static obj_t symbol2473___hash = BUNSPEC;
static obj_t symbol2472___hash = BUNSPEC;
static obj_t _string__0__2551359_61___hash(obj_t, obj_t);
static obj_t symbol2469___hash = BUNSPEC;
static obj_t symbol2470___hash = BUNSPEC;
static obj_t symbol2463___hash = BUNSPEC;
static obj_t symbol2459___hash = BUNSPEC;
static obj_t symbol2460___hash = BUNSPEC;
static obj_t symbol2458___hash = BUNSPEC;
static obj_t symbol2457___hash = BUNSPEC;
extern long get_hash_power_number(char *, long);
static obj_t symbol2454___hash = BUNSPEC;
static obj_t symbol2453___hash = BUNSPEC;
static obj_t symbol2451___hash = BUNSPEC;
static obj_t symbol2449___hash = BUNSPEC;
static obj_t symbol2447___hash = BUNSPEC;
static obj_t symbol2446___hash = BUNSPEC;
static obj_t symbol2441___hash = BUNSPEC;
static obj_t symbol2434___hash = BUNSPEC;
static obj_t symbol2433___hash = BUNSPEC;
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
extern long string__0__2_x_1_163___hash(char *, long);
static obj_t list2498___hash = BUNSPEC;
static obj_t list2494___hash = BUNSPEC;
static obj_t list2492___hash = BUNSPEC;
static obj_t list2490___hash = BUNSPEC;
static obj_t list2488___hash = BUNSPEC;
static obj_t list2481___hash = BUNSPEC;
static obj_t list2479___hash = BUNSPEC;
static obj_t list2476___hash = BUNSPEC;
static obj_t list2471___hash = BUNSPEC;
static obj_t list2468___hash = BUNSPEC;
static obj_t list2456___hash = BUNSPEC;
static obj_t _obj__0__2_x_11363_110___hash(obj_t, obj_t, obj_t);
extern long int__0__255_26___hash(long);
static obj_t _string__0__2_x_11360_5___hash(obj_t, obj_t, obj_t);
extern bool_t hash_table__21___hash(obj_t);
static obj_t imported_modules_init_94___hash();
extern long modulo___r4_numbers_6_5_fixnum(long, long);
static obj_t require_initialization_114___hash = BUNSPEC;
static obj_t _obj__0__255_117___hash(obj_t, obj_t);
extern obj_t rem_key_hash__152___hash(obj_t, obj_t);
extern long obj__0__2_x_1_138___hash(obj_t, long);
static obj_t _hash_table_nb_entry_102___hash(obj_t, obj_t);
static obj_t cnst_init_137___hash();
extern obj_t rem_obj_hash__55___hash(obj_t, obj_t);
static obj_t _rem_key_hash__54___hash(obj_t, obj_t, obj_t);
extern obj_t make_vector(long, obj_t);
extern long int__0__2_x_1_11___hash(long, long);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( hash_table__env_123___hash, _hash_table__163___hash2522, _hash_table__163___hash, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_hash_table_env_156___hash, _make_hash_table1357_92___hash2523, va_generic_entry, _make_hash_table1357_92___hash, -5 );
DEFINE_EXPORT_PROCEDURE( string__0__255_env_51___hash, _string__0__2551359_61___hash2524, _string__0__2551359_61___hash, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rem_key_hash__env_114___hash, _rem_key_hash__54___hash2525, _rem_key_hash__54___hash, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( int__0__2_x_1_env_186___hash, _int__0__2_x_11362_181___hash2526, _int__0__2_x_11362_181___hash, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( put_hash__env_10___hash, _put_hash__86___hash2527, _put_hash__86___hash, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( obj__0__255_env_221___hash, _obj__0__255_117___hash2528, _obj__0__255_117___hash, 0L, 1 );
DEFINE_STRING( string2517___hash, string2517___hash2529, "UCHAR", 5 );
DEFINE_STRING( string2516___hash, string2516___hash2530, "SYMBOL", 6 );
DEFINE_STRING( string2508___hash, string2508___hash2531, "STRING", 6 );
DEFINE_STRING( string2497___hash, string2497___hash2532, "FOR-EACH-HASH:Wrong number of arguments", 39 );
DEFINE_STRING( string2502___hash, string2502___hash2533, "argument not a list", 19 );
DEFINE_STRING( string2501___hash, string2501___hash2534, "for-each", 8 );
DEFINE_STRING( string2487___hash, string2487___hash2535, "REM-KEY-HASH!:Wrong number of arguments", 39 );
DEFINE_STRING( string2485___hash, string2485___hash2536, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_STRING( string2484___hash, string2484___hash2537, "REM-OBJ-HASH!:Wrong number of arguments", 39 );
DEFINE_STRING( string2478___hash, string2478___hash2538, "vector-set!", 11 );
DEFINE_STRING( string2475___hash, string2475___hash2539, "PUT-HASH!:Wrong number of arguments", 35 );
DEFINE_STRING( string2467___hash, string2467___hash2540, "GET-HASH:Wrong number of arguments", 34 );
DEFINE_STRING( string2466___hash, string2466___hash2541, "index out of range", 18 );
DEFINE_STRING( string2465___hash, string2465___hash2542, "vector-ref", 10 );
DEFINE_STRING( string2464___hash, string2464___hash2543, "VECTOR", 6 );
DEFINE_STRING( string2462___hash, string2462___hash2544, "Illegal get-hash-function", 25 );
DEFINE_STRING( string2461___hash, string2461___hash2545, "get-hash-number", 15 );
DEFINE_STRING( string2455___hash, string2455___hash2546, "GET-HASH-NUMBER:Wrong number of arguments", 41 );
DEFINE_EXPORT_PROCEDURE( obj__0__2_x_1_env_67___hash, _obj__0__2_x_11363_110___hash2547, _obj__0__2_x_11363_110___hash, 0L, 2 );
DEFINE_STRING( string2452___hash, string2452___hash2548, "struct-ref:not an instance of", 29 );
DEFINE_STRING( string2450___hash, string2450___hash2549, "STRUCT", 6 );
DEFINE_STRING( string2448___hash, string2448___hash2550, "PROCEDURE", 9 );
DEFINE_STRING( string2445___hash, string2445___hash2551, "Illegal init-size (not a 2 power)", 33 );
DEFINE_STRING( string2444___hash, string2444___hash2552, "Illegal max-size (not a 2 power)", 32 );
DEFINE_STRING( string2443___hash, string2443___hash2553, "HASHTBL", 7 );
DEFINE_STRING( string2442___hash, string2442___hash2554, "struct-set!:not an instance of", 30 );
DEFINE_STRING( string2439___hash, string2439___hash2555, "init-size greater than max-size !", 33 );
DEFINE_STRING( string2440___hash, string2440___hash2556, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2438___hash, string2438___hash2557, "make-hash-table", 15 );
DEFINE_STRING( string2437___hash, string2437___hash2558, "LONG", 4 );
DEFINE_STRING( string2436___hash, string2436___hash2559, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/hash.scm", 57 );
DEFINE_STRING( string2435___hash, string2435___hash2560, "PAIR", 4 );
DEFINE_EXPORT_PROCEDURE( rem_obj_hash__env_231___hash, _rem_obj_hash__23___hash2561, _rem_obj_hash__23___hash, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( hash_table__vector_env_1___hash, _hash_table__vector_152___hash2562, _hash_table__vector_152___hash, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( int__0__255_env_252___hash, _int__0__2551361_6___hash2563, _int__0__2551361_6___hash, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__0__2_x_1_env_255___hash, _string__0__2_x_11360_5___hash2564, _string__0__2_x_11360_5___hash, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( get_hash_env_117___hash, _get_hash_182___hash2565, _get_hash_182___hash, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( hash_table_nb_entry_env_125___hash, _hash_table_nb_entry_102___hash2566, _hash_table_nb_entry_102___hash, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( for_each_hash_env_166___hash, _for_each_hash1358_11___hash2567, _for_each_hash1358_11___hash, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___hash(long checksum_2669, char * from_2670)
{
if(CBOOL(require_initialization_114___hash)){
require_initialization_114___hash = BBOOL(((bool_t)0));
cnst_init_137___hash();
imported_modules_init_94___hash();
toplevel_init_63___hash();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___hash()
{
symbol2433___hash = string_to_symbol("TOPLEVEL-INIT");
symbol2434___hash = string_to_symbol("MAKE-HASH-TABLE");
symbol2441___hash = string_to_symbol("HASHTBL");
symbol2446___hash = string_to_symbol("2^POWER?");
symbol2447___hash = string_to_symbol("_MAKE-HASH-TABLE1357");
symbol2449___hash = string_to_symbol("HASH-TABLE?");
symbol2451___hash = string_to_symbol("HASH-TABLE-NB-ENTRY");
symbol2453___hash = string_to_symbol("HASH-TABLE->VECTOR");
symbol2454___hash = string_to_symbol("GET-HASH-NUMBER");
symbol2457___hash = string_to_symbol("FUNCALL");
symbol2458___hash = string_to_symbol("hash-function");
symbol2459___hash = string_to_symbol("key");
{
obj_t aux_2689;
{
obj_t aux_2690;
{
obj_t aux_2691;
aux_2691 = MAKE_PAIR(symbol2459___hash, BNIL);
aux_2690 = MAKE_PAIR(symbol2458___hash, aux_2691);
}
aux_2689 = MAKE_PAIR(symbol2458___hash, aux_2690);
}
list2456___hash = MAKE_PAIR(symbol2457___hash, aux_2689);
}
symbol2460___hash = string_to_symbol("_");
symbol2463___hash = string_to_symbol("GET-HASH");
symbol2469___hash = string_to_symbol("get-key");
symbol2470___hash = string_to_symbol("arg1086");
{
obj_t aux_2700;
{
obj_t aux_2701;
{
obj_t aux_2702;
aux_2702 = MAKE_PAIR(symbol2470___hash, BNIL);
aux_2701 = MAKE_PAIR(symbol2469___hash, aux_2702);
}
aux_2700 = MAKE_PAIR(symbol2469___hash, aux_2701);
}
list2468___hash = MAKE_PAIR(symbol2457___hash, aux_2700);
}
symbol2472___hash = string_to_symbol("hash-eq?");
symbol2473___hash = string_to_symbol("arg1085");
{
obj_t aux_2709;
{
obj_t aux_2710;
{
obj_t aux_2711;
{
obj_t aux_2712;
aux_2712 = MAKE_PAIR(symbol2459___hash, BNIL);
aux_2711 = MAKE_PAIR(symbol2473___hash, aux_2712);
}
aux_2710 = MAKE_PAIR(symbol2472___hash, aux_2711);
}
aux_2709 = MAKE_PAIR(symbol2472___hash, aux_2710);
}
list2471___hash = MAKE_PAIR(symbol2457___hash, aux_2709);
}
symbol2474___hash = string_to_symbol("PUT-HASH!");
symbol2477___hash = string_to_symbol("obj");
{
obj_t aux_2720;
{
obj_t aux_2721;
{
obj_t aux_2722;
aux_2722 = MAKE_PAIR(symbol2477___hash, BNIL);
aux_2721 = MAKE_PAIR(symbol2469___hash, aux_2722);
}
aux_2720 = MAKE_PAIR(symbol2469___hash, aux_2721);
}
list2476___hash = MAKE_PAIR(symbol2457___hash, aux_2720);
}
symbol2480___hash = string_to_symbol("arg1114");
{
obj_t aux_2728;
{
obj_t aux_2729;
{
obj_t aux_2730;
aux_2730 = MAKE_PAIR(symbol2480___hash, BNIL);
aux_2729 = MAKE_PAIR(symbol2469___hash, aux_2730);
}
aux_2728 = MAKE_PAIR(symbol2469___hash, aux_2729);
}
list2479___hash = MAKE_PAIR(symbol2457___hash, aux_2728);
}
symbol2482___hash = string_to_symbol("arg1113");
{
obj_t aux_2736;
{
obj_t aux_2737;
{
obj_t aux_2738;
{
obj_t aux_2739;
aux_2739 = MAKE_PAIR(symbol2459___hash, BNIL);
aux_2738 = MAKE_PAIR(symbol2482___hash, aux_2739);
}
aux_2737 = MAKE_PAIR(symbol2472___hash, aux_2738);
}
aux_2736 = MAKE_PAIR(symbol2472___hash, aux_2737);
}
list2481___hash = MAKE_PAIR(symbol2457___hash, aux_2736);
}
symbol2483___hash = string_to_symbol("REM-OBJ-HASH!");
symbol2486___hash = string_to_symbol("REM-KEY-HASH!");
symbol2489___hash = string_to_symbol("arg1150");
{
obj_t aux_2748;
{
obj_t aux_2749;
{
obj_t aux_2750;
aux_2750 = MAKE_PAIR(symbol2489___hash, BNIL);
aux_2749 = MAKE_PAIR(symbol2469___hash, aux_2750);
}
aux_2748 = MAKE_PAIR(symbol2469___hash, aux_2749);
}
list2488___hash = MAKE_PAIR(symbol2457___hash, aux_2748);
}
symbol2491___hash = string_to_symbol("arg1148");
{
obj_t aux_2756;
{
obj_t aux_2757;
{
obj_t aux_2758;
{
obj_t aux_2759;
aux_2759 = MAKE_PAIR(symbol2459___hash, BNIL);
aux_2758 = MAKE_PAIR(symbol2491___hash, aux_2759);
}
aux_2757 = MAKE_PAIR(symbol2472___hash, aux_2758);
}
aux_2756 = MAKE_PAIR(symbol2472___hash, aux_2757);
}
list2490___hash = MAKE_PAIR(symbol2457___hash, aux_2756);
}
symbol2493___hash = string_to_symbol("arg1147");
{
obj_t aux_2766;
{
obj_t aux_2767;
{
obj_t aux_2768;
aux_2768 = MAKE_PAIR(symbol2493___hash, BNIL);
aux_2767 = MAKE_PAIR(symbol2469___hash, aux_2768);
}
aux_2766 = MAKE_PAIR(symbol2469___hash, aux_2767);
}
list2492___hash = MAKE_PAIR(symbol2457___hash, aux_2766);
}
symbol2495___hash = string_to_symbol("arg1146");
{
obj_t aux_2774;
{
obj_t aux_2775;
{
obj_t aux_2776;
{
obj_t aux_2777;
aux_2777 = MAKE_PAIR(symbol2459___hash, BNIL);
aux_2776 = MAKE_PAIR(symbol2495___hash, aux_2777);
}
aux_2775 = MAKE_PAIR(symbol2472___hash, aux_2776);
}
aux_2774 = MAKE_PAIR(symbol2472___hash, aux_2775);
}
list2494___hash = MAKE_PAIR(symbol2457___hash, aux_2774);
}
symbol2496___hash = string_to_symbol("FOR-EACH-HASH");
symbol2499___hash = string_to_symbol("fun");
symbol2500___hash = string_to_symbol("arg1157");
{
obj_t aux_2786;
{
obj_t aux_2787;
{
obj_t aux_2788;
aux_2788 = MAKE_PAIR(symbol2500___hash, BNIL);
aux_2787 = MAKE_PAIR(symbol2499___hash, aux_2788);
}
aux_2786 = MAKE_PAIR(symbol2499___hash, aux_2787);
}
list2498___hash = MAKE_PAIR(symbol2457___hash, aux_2786);
}
symbol2503___hash = string_to_symbol("_FOR-EACH-HASH1358");
symbol2504___hash = string_to_symbol("HASH-TABLE-GROWS!");
symbol2505___hash = string_to_symbol("DONE");
symbol2506___hash = string_to_symbol("STRING->0..255");
symbol2507___hash = string_to_symbol("_STRING->0..2551359");
symbol2509___hash = string_to_symbol("STRING->0..2^X-1");
symbol2510___hash = string_to_symbol("_STRING->0..2^X-11360");
symbol2511___hash = string_to_symbol("INT->0..255");
symbol2512___hash = string_to_symbol("_INT->0..2551361");
symbol2513___hash = string_to_symbol("INT->0..2^X-1");
symbol2514___hash = string_to_symbol("_INT->0..2^X-11362");
symbol2515___hash = string_to_symbol("OBJ->0..255");
symbol2518___hash = string_to_symbol("OBJ->0..2^X-1");
symbol2519___hash = string_to_symbol("_OBJ->0..2^X-11363");
return (symbol2520___hash = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___hash()
{
{
obj_t symbol1320_1612;
symbol1320_1612 = symbol2433___hash;
{
PUSH_TRACE(symbol1320_1612);
BUNSPEC;
POP_TRACE();
return BUNSPEC;
}
}
}


/* make-hash-table */obj_t make_hash_table_174___hash(long max_size_171_31, obj_t get_hash_number_100_32, obj_t get_key_253_33, obj_t eq_34, obj_t init_size_5_35)
{
{
obj_t symbol1322_1614;
symbol1322_1614 = symbol2434___hash;
{
PUSH_TRACE(symbol1322_1614);
BUNSPEC;
{
obj_t aux1321_1615;
{
obj_t size_363;
if(NULLP(init_size_5_35)){
size_363 = BINT(max_size_171_31);
}
 else {
obj_t pair_860;
if(PAIRP(init_size_5_35)){
pair_860 = init_size_5_35;
}
 else {
bigloo_type_error_location_103___error(symbol2434___hash, string2435___hash, init_size_5_35, string2436___hash, BINT(((long)5005)));
exit( -1 );}
size_363 = CAR(pair_860);
}
if(_2_power__4___hash(size_363)){
if(_2_power__4___hash(BINT(max_size_171_31))){
bool_t test1072_367;
{
long n1_861;
{
obj_t aux_2825;
if(INTEGERP(size_363)){
aux_2825 = size_363;
}
 else {
bigloo_type_error_location_103___error(symbol2434___hash, string2437___hash, size_363, string2436___hash, BINT(((long)5635)));
exit( -1 );}
n1_861 = (long)CINT(aux_2825);
}
test1072_367 = (n1_861>max_size_171_31);
}
if(test1072_367){
aux1321_1615 = debug_error_location_199___error(string2438___hash, string2439___hash, size_363, string2440___hash, BINT(((long)7610)));
}
 else {
{
obj_t table_368;
{
long aux_2836;
{
obj_t aux_2837;
if(INTEGERP(size_363)){
aux_2837 = size_363;
}
 else {
bigloo_type_error_location_103___error(symbol2434___hash, string2437___hash, size_363, string2436___hash, BINT(((long)5755)));
exit( -1 );}
aux_2836 = (long)CINT(aux_2837);
}
table_368 = make_vector(aux_2836, BNIL);
}
{
obj_t new_873;
new_873 = create_struct(symbol2441___hash, ((long)7));
{
bool_t test_2846;
{
obj_t aux_2847;
aux_2847 = STRUCT_KEY(new_873);
test_2846 = (aux_2847==symbol2441___hash);
}
if(test_2846){
STRUCT_SET(new_873, ((long)6), table_368);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test_2853;
{
obj_t aux_2854;
aux_2854 = STRUCT_KEY(new_873);
test_2853 = (aux_2854==symbol2441___hash);
}
if(test_2853){
STRUCT_SET(new_873, ((long)5), eq_34);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test_2860;
{
obj_t aux_2861;
aux_2861 = STRUCT_KEY(new_873);
test_2860 = (aux_2861==symbol2441___hash);
}
if(test_2860){
obj_t aux_2864;
aux_2864 = BINT(((long)0));
STRUCT_SET(new_873, ((long)4), aux_2864);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test_2869;
{
obj_t aux_2870;
aux_2870 = STRUCT_KEY(new_873);
test_2869 = (aux_2870==symbol2441___hash);
}
if(test_2869){
STRUCT_SET(new_873, ((long)3), get_key_253_33);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test_2876;
{
obj_t aux_2877;
aux_2877 = STRUCT_KEY(new_873);
test_2876 = (aux_2877==symbol2441___hash);
}
if(test_2876){
STRUCT_SET(new_873, ((long)2), get_hash_number_100_32);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test_2883;
{
obj_t aux_2884;
aux_2884 = STRUCT_KEY(new_873);
test_2883 = (aux_2884==symbol2441___hash);
}
if(test_2883){
STRUCT_SET(new_873, ((long)1), size_363);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test_2890;
{
obj_t aux_2891;
aux_2891 = STRUCT_KEY(new_873);
test_2890 = (aux_2891==symbol2441___hash);
}
if(test_2890){
obj_t aux_2894;
aux_2894 = BINT(max_size_171_31);
STRUCT_SET(new_873, ((long)0), aux_2894);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, new_873, string2440___hash, BINT(((long)7610)));
}
}
aux1321_1615 = new_873;
}
}
}
}
 else {
aux1321_1615 = debug_error_location_199___error(string2438___hash, string2444___hash, BINT(max_size_171_31), string2440___hash, BINT(((long)7610)));
}
}
 else {
aux1321_1615 = debug_error_location_199___error(string2438___hash, string2445___hash, size_363, string2440___hash, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1321_1615;
}
}
}
}


/* 2^power? */bool_t _2_power__4___hash(obj_t size_371)
{
{
long n_373;
n_373 = ((long)1);
loop_374:
{
long num_375;
num_375 = (((long)1) << n_373);
{
bool_t test1076_376;
{
long n2_962;
{
obj_t aux_2906;
if(INTEGERP(size_371)){
aux_2906 = size_371;
}
 else {
bigloo_type_error_location_103___error(symbol2446___hash, string2437___hash, size_371, string2436___hash, BINT(((long)5312)));
exit( -1 );}
n2_962 = (long)CINT(aux_2906);
}
test1076_376 = (num_375==n2_962);
}
if(test1076_376){
return ((bool_t)1);
}
 else {
bool_t test1077_377;
{
long n2_964;
{
obj_t aux_2915;
if(INTEGERP(size_371)){
aux_2915 = size_371;
}
 else {
bigloo_type_error_location_103___error(symbol2446___hash, string2437___hash, size_371, string2436___hash, BINT(((long)5346)));
exit( -1 );}
n2_964 = (long)CINT(aux_2915);
}
test1077_377 = (num_375<n2_964);
}
if(test1077_377){
{
long n_2924;
n_2924 = (n_373+((long)1));
n_373 = n_2924;
goto loop_374;
}
}
 else {
return ((bool_t)0);
}
}
}
}
}
}


/* _make-hash-table1357 */obj_t _make_hash_table1357_92___hash(obj_t env_1650, obj_t max_size_171_1651, obj_t get_hash_number_100_1652, obj_t get_key_253_1653, obj_t eq_1654, obj_t init_size_5_1655)
{
{
obj_t aux_2946;
obj_t aux_2940;
obj_t aux_2934;
long aux_2926;
if(PROCEDUREP(eq_1654)){
aux_2946 = eq_1654;
}
 else {
bigloo_type_error_location_103___error(symbol2447___hash, string2448___hash, eq_1654, string2436___hash, BINT(((long)4862)));
exit( -1 );}
if(PROCEDUREP(get_key_253_1653)){
aux_2940 = get_key_253_1653;
}
 else {
bigloo_type_error_location_103___error(symbol2447___hash, string2448___hash, get_key_253_1653, string2436___hash, BINT(((long)4862)));
exit( -1 );}
if(PROCEDUREP(get_hash_number_100_1652)){
aux_2934 = get_hash_number_100_1652;
}
 else {
bigloo_type_error_location_103___error(symbol2447___hash, string2448___hash, get_hash_number_100_1652, string2436___hash, BINT(((long)4862)));
exit( -1 );}
{
obj_t aux_2927;
if(INTEGERP(max_size_171_1651)){
aux_2927 = max_size_171_1651;
}
 else {
bigloo_type_error_location_103___error(symbol2447___hash, string2437___hash, max_size_171_1651, string2436___hash, BINT(((long)4862)));
exit( -1 );}
aux_2926 = (long)CINT(aux_2927);
}
return make_hash_table_174___hash(aux_2926, aux_2934, aux_2940, aux_2946, init_size_5_1655);
}
}


/* hash-table? */bool_t hash_table__21___hash(obj_t obj_36)
{
{
obj_t symbol1324_1616;
symbol1324_1616 = symbol2449___hash;
{
PUSH_TRACE(symbol1324_1616);
BUNSPEC;
{
bool_t aux1323_1617;
{
bool_t test1022_968;
test1022_968 = STRUCTP(obj_36);
if(test1022_968){
obj_t arg1023_969;
obj_t arg1025_970;
{
obj_t s_972;
if(test1022_968){
s_972 = obj_36;
}
 else {
bigloo_type_error_location_103___error(symbol2449___hash, string2450___hash, obj_36, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1023_969 = STRUCT_KEY(s_972);
}
arg1025_970 = symbol2441___hash;
aux1323_1617 = (arg1023_969==arg1025_970);
}
 else {
aux1323_1617 = ((bool_t)0);
}
}
POP_TRACE();
return aux1323_1617;
}
}
}
}


/* _hash-table? */obj_t _hash_table__163___hash(obj_t env_1656, obj_t obj_1657)
{
{
bool_t aux_2963;
aux_2963 = hash_table__21___hash(obj_1657);
return BBOOL(aux_2963);
}
}


/* hash-table-nb-entry */obj_t hash_table_nb_entry_45___hash(obj_t table_37)
{
{
obj_t symbol1326_1618;
symbol1326_1618 = symbol2451___hash;
{
PUSH_TRACE(symbol1326_1618);
BUNSPEC;
{
obj_t aux1325_1619;
{
bool_t test1039_976;
{
obj_t arg1040_977;
obj_t arg1041_978;
{
obj_t s_979;
if(STRUCTP(table_37)){
s_979 = table_37;
}
 else {
bigloo_type_error_location_103___error(symbol2451___hash, string2450___hash, table_37, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_977 = STRUCT_KEY(s_979);
}
arg1041_978 = symbol2441___hash;
test1039_976 = (arg1040_977==arg1041_978);
}
if(test1039_976){
aux1325_1619 = STRUCT_REF(table_37, ((long)4));
}
 else {
aux1325_1619 = debug_error_location_199___error(string2452___hash, string2443___hash, table_37, string2440___hash, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1325_1619;
}
}
}
}


/* _hash-table-nb-entry */obj_t _hash_table_nb_entry_102___hash(obj_t env_1658, obj_t table_1659)
{
return hash_table_nb_entry_45___hash(table_1659);
}


/* hash-table->vector */obj_t hash_table__vector_145___hash(obj_t table_38)
{
{
obj_t symbol1328_1620;
symbol1328_1620 = symbol2453___hash;
{
PUSH_TRACE(symbol1328_1620);
BUNSPEC;
{
obj_t aux1327_1621;
{
bool_t test1026_986;
{
obj_t arg1027_987;
obj_t arg1028_988;
{
obj_t s_989;
if(STRUCTP(table_38)){
s_989 = table_38;
}
 else {
bigloo_type_error_location_103___error(symbol2453___hash, string2450___hash, table_38, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_987 = STRUCT_KEY(s_989);
}
arg1028_988 = symbol2441___hash;
test1026_986 = (arg1027_987==arg1028_988);
}
if(test1026_986){
aux1327_1621 = STRUCT_REF(table_38, ((long)6));
}
 else {
aux1327_1621 = debug_error_location_199___error(string2452___hash, string2443___hash, table_38, string2440___hash, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1327_1621;
}
}
}
}


/* _hash-table->vector */obj_t _hash_table__vector_152___hash(obj_t env_1660, obj_t table_1661)
{
return hash_table__vector_145___hash(table_1661);
}


/* get-hash-number */obj_t get_hash_number_100___hash(obj_t table_39, obj_t key_40)
{
{
obj_t symbol1330_1622;
symbol1330_1622 = symbol2454___hash;
{
PUSH_TRACE(symbol1330_1622);
BUNSPEC;
{
obj_t aux1329_1623;
{
obj_t hash_function_218_380;
{
bool_t test1051_996;
{
obj_t arg1053_997;
obj_t arg1054_998;
{
obj_t s_999;
if(STRUCTP(table_39)){
s_999 = table_39;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2450___hash, table_39, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1053_997 = STRUCT_KEY(s_999);
}
arg1054_998 = symbol2441___hash;
test1051_996 = (arg1053_997==arg1054_998);
}
if(test1051_996){
hash_function_218_380 = STRUCT_REF(table_39, ((long)2));
}
 else {
hash_function_218_380 = debug_error_location_199___error(string2452___hash, string2443___hash, table_39, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t max_size_171_381;
{
bool_t test1064_1006;
{
obj_t arg1065_1007;
obj_t arg1066_1008;
{
obj_t s_1009;
if(STRUCTP(table_39)){
s_1009 = table_39;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2450___hash, table_39, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1065_1007 = STRUCT_KEY(s_1009);
}
arg1066_1008 = symbol2441___hash;
test1064_1006 = (arg1065_1007==arg1066_1008);
}
if(test1064_1006){
max_size_171_381 = STRUCT_REF(table_39, ((long)0));
}
 else {
max_size_171_381 = debug_error_location_199___error(string2452___hash, string2443___hash, table_39, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t size_382;
{
bool_t test1058_1016;
{
obj_t arg1059_1017;
obj_t arg1060_1018;
{
obj_t s_1019;
if(STRUCTP(table_39)){
s_1019 = table_39;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2450___hash, table_39, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1059_1017 = STRUCT_KEY(s_1019);
}
arg1060_1018 = symbol2441___hash;
test1058_1016 = (arg1059_1017==arg1060_1018);
}
if(test1058_1016){
size_382 = STRUCT_REF(table_39, ((long)1));
}
 else {
size_382 = debug_error_location_199___error(string2452___hash, string2443___hash, table_39, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t num_383;
{
obj_t fun_1789;
if(PROCEDUREP(hash_function_218_380)){
fun_1789 = hash_function_218_380;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2448___hash, hash_function_218_380, string2436___hash, BINT(((long)7109)));
exit( -1 );}
{
bool_t test1490_1796;
test1490_1796 = PROCEDURE_CORRECT_ARITYP(fun_1789, ((long)1));
if(test1490_1796){
num_383 = PROCEDURE_ENTRY(fun_1789)(hash_function_218_380, key_40, BEOA);
}
 else {
error_location_112___error(string2455___hash, list2456___hash, fun_1789, string2436___hash, BINT(((long)7109)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
{
obj_t res_384;
{
bool_t test1081_388;
{
long n1_1025;
long n2_1026;
{
obj_t aux_3040;
if(INTEGERP(size_382)){
aux_3040 = size_382;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2437___hash, size_382, string2436___hash, BINT(((long)7153)));
exit( -1 );}
n1_1025 = (long)CINT(aux_3040);
}
{
obj_t aux_3047;
if(INTEGERP(max_size_171_381)){
aux_3047 = max_size_171_381;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2437___hash, max_size_171_381, string2436___hash, BINT(((long)7157)));
exit( -1 );}
n2_1026 = (long)CINT(aux_3047);
}
test1081_388 = (n1_1025<n2_1026);
}
if(test1081_388){
long aux_3056;
{
long aux_3065;
long aux_3057;
{
obj_t aux_3066;
if(INTEGERP(size_382)){
aux_3066 = size_382;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2437___hash, size_382, string2436___hash, BINT(((long)7188)));
exit( -1 );}
aux_3065 = (long)CINT(aux_3066);
}
{
obj_t aux_3058;
if(INTEGERP(num_383)){
aux_3058 = num_383;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2437___hash, num_383, string2436___hash, BINT(((long)7181)));
exit( -1 );}
aux_3057 = (long)CINT(aux_3058);
}
aux_3056 = modulo___r4_numbers_6_5_fixnum(aux_3057, aux_3065);
}
res_384 = BINT(aux_3056);
}
 else {
res_384 = num_383;
}
}
{
{
bool_t test1079_385;
{
long n1_1027;
long n2_1028;
{
obj_t aux_3075;
if(INTEGERP(res_384)){
aux_3075 = res_384;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2437___hash, res_384, string2436___hash, BINT(((long)7224)));
exit( -1 );}
n1_1027 = (long)CINT(aux_3075);
}
{
obj_t aux_3082;
if(INTEGERP(max_size_171_381)){
aux_3082 = max_size_171_381;
}
 else {
bigloo_type_error_location_103___error(symbol2454___hash, string2437___hash, max_size_171_381, string2436___hash, BINT(((long)7229)));
exit( -1 );}
n2_1028 = (long)CINT(aux_3082);
}
test1079_385 = (n1_1027>=n2_1028);
}
if(test1079_385){
obj_t res_386;
res_386 = debug_error_location_199___error(string2461___hash, string2462___hash, table_39, string2440___hash, BINT(((long)7610)));
if(INTEGERP(res_386)){
aux1329_1623 = res_386;
}
 else {
aux1329_1623 = BINT(((long)-1));
}
}
 else {
aux1329_1623 = res_384;
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1329_1623;
}
}
}
}


/* get-hash */obj_t get_hash_29___hash(obj_t key_41, obj_t table_42)
{
{
obj_t symbol1332_1624;
symbol1332_1624 = symbol2463___hash;
{
PUSH_TRACE(symbol1332_1624);
BUNSPEC;
{
obj_t aux1331_1625;
{
obj_t hash_num_11_389;
hash_num_11_389 = get_hash_number_100___hash(table_42, key_41);
{
obj_t hash_eq__126_390;
{
bool_t test1032_1034;
{
obj_t arg1033_1035;
obj_t arg1034_1036;
{
obj_t s_1037;
if(STRUCTP(table_42)){
s_1037 = table_42;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2450___hash, table_42, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1033_1035 = STRUCT_KEY(s_1037);
}
arg1034_1036 = symbol2441___hash;
test1032_1034 = (arg1033_1035==arg1034_1036);
}
if(test1032_1034){
hash_eq__126_390 = STRUCT_REF(table_42, ((long)5));
}
 else {
hash_eq__126_390 = debug_error_location_199___error(string2452___hash, string2443___hash, table_42, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t bucket_391;
{
obj_t arg1087_400;
{
bool_t test1026_1044;
{
obj_t arg1027_1045;
obj_t arg1028_1046;
{
obj_t s_1047;
if(STRUCTP(table_42)){
s_1047 = table_42;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2450___hash, table_42, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_1045 = STRUCT_KEY(s_1047);
}
arg1028_1046 = symbol2441___hash;
test1026_1044 = (arg1027_1045==arg1028_1046);
}
if(test1026_1044){
arg1087_400 = STRUCT_REF(table_42, ((long)6));
}
 else {
arg1087_400 = debug_error_location_199___error(string2452___hash, string2443___hash, table_42, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t vector_1053;
long k_1054;
if(VECTORP(arg1087_400)){
vector_1053 = arg1087_400;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2464___hash, arg1087_400, string2436___hash, BINT(((long)7739)));
exit( -1 );}
{
obj_t aux_3126;
if(INTEGERP(hash_num_11_389)){
aux_3126 = hash_num_11_389;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2437___hash, hash_num_11_389, string2436___hash, BINT(((long)7739)));
exit( -1 );}
k_1054 = (long)CINT(aux_3126);
}
{
bool_t test1295_1055;
{
long aux_3133;
aux_3133 = VECTOR_LENGTH(vector_1053);
test1295_1055 = BOUND_CHECK(k_1054, aux_3133);
}
if(test1295_1055){
bucket_391 = VECTOR_REF(vector_1053, k_1054);
}
 else {
bucket_391 = debug_error_location_199___error(string2465___hash, string2466___hash, BINT(k_1054), string2440___hash, BINT(((long)7610)));
}
}
}
}
{
obj_t get_key_253_392;
{
bool_t test1045_1062;
{
obj_t arg1046_1063;
obj_t arg1047_1064;
{
obj_t s_1065;
if(STRUCTP(table_42)){
s_1065 = table_42;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2450___hash, table_42, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1046_1063 = STRUCT_KEY(s_1065);
}
arg1047_1064 = symbol2441___hash;
test1045_1062 = (arg1046_1063==arg1047_1064);
}
if(test1045_1062){
get_key_253_392 = STRUCT_REF(table_42, ((long)3));
}
 else {
get_key_253_392 = debug_error_location_199___error(string2452___hash, string2443___hash, table_42, string2440___hash, BINT(((long)7610)));
}
}
{
{
obj_t bucket_393;
bucket_393 = bucket_391;
loop_394:
if(NULLP(bucket_393)){
aux1331_1625 = BFALSE;
}
 else {
bool_t test1083_396;
{
obj_t arg1085_398;
{
obj_t arg1086_399;
{
obj_t pair_1072;
if(PAIRP(bucket_393)){
pair_1072 = bucket_393;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2435___hash, bucket_393, string2436___hash, BINT(((long)7923)));
exit( -1 );}
arg1086_399 = CAR(pair_1072);
}
{
obj_t fun_1875;
if(PROCEDUREP(get_key_253_392)){
fun_1875 = get_key_253_392;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2448___hash, get_key_253_392, string2436___hash, BINT(((long)7913)));
exit( -1 );}
{
bool_t test1593_1882;
test1593_1882 = PROCEDURE_CORRECT_ARITYP(fun_1875, ((long)1));
if(test1593_1882){
arg1085_398 = PROCEDURE_ENTRY(fun_1875)(get_key_253_392, arg1086_399, BEOA);
}
 else {
error_location_112___error(string2467___hash, list2468___hash, fun_1875, string2436___hash, BINT(((long)7913)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
{
obj_t fun_1889;
if(PROCEDUREP(hash_eq__126_390)){
fun_1889 = hash_eq__126_390;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2448___hash, hash_eq__126_390, string2436___hash, BINT(((long)7903)));
exit( -1 );}
{
bool_t test1610_1896;
test1610_1896 = PROCEDURE_CORRECT_ARITYP(fun_1889, ((long)2));
if(test1610_1896){
obj_t aux_3179;
aux_3179 = PROCEDURE_ENTRY(fun_1889)(hash_eq__126_390, arg1085_398, key_41, BEOA);
test1083_396 = CBOOL(aux_3179);
}
 else {
error_location_112___error(string2467___hash, list2471___hash, fun_1889, string2436___hash, BINT(((long)7903)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
if(test1083_396){
{
obj_t pair_1073;
if(PAIRP(bucket_393)){
pair_1073 = bucket_393;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2435___hash, bucket_393, string2436___hash, BINT(((long)7948)));
exit( -1 );}
aux1331_1625 = CAR(pair_1073);
}
}
 else {
{
obj_t arg1084_397;
{
obj_t pair_1074;
if(PAIRP(bucket_393)){
pair_1074 = bucket_393;
}
 else {
bigloo_type_error_location_103___error(symbol2463___hash, string2435___hash, bucket_393, string2436___hash, BINT(((long)7985)));
exit( -1 );}
arg1084_397 = CDR(pair_1074);
}
{
obj_t bucket_3199;
bucket_3199 = arg1084_397;
bucket_393 = bucket_3199;
goto loop_394;
}
}
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1331_1625;
}
}
}
}


/* _get-hash */obj_t _get_hash_182___hash(obj_t env_1662, obj_t key_1663, obj_t table_1664)
{
return get_hash_29___hash(key_1663, table_1664);
}


/* put-hash! */obj_t put_hash__129___hash(obj_t obj_43, obj_t table_44)
{
{
obj_t symbol1334_1626;
symbol1334_1626 = symbol2474___hash;
{
PUSH_TRACE(symbol1334_1626);
BUNSPEC;
{
obj_t aux1333_1627;
{
bool_t test1088_401;
{
bool_t test1089_402;
{
obj_t arg1094_407;
obj_t arg1095_408;
{
bool_t test1058_1076;
{
obj_t arg1059_1077;
obj_t arg1060_1078;
{
obj_t s_1079;
if(STRUCTP(table_44)){
s_1079 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1059_1077 = STRUCT_KEY(s_1079);
}
arg1060_1078 = symbol2441___hash;
test1058_1076 = (arg1059_1077==arg1060_1078);
}
if(test1058_1076){
arg1094_407 = STRUCT_REF(table_44, ((long)1));
}
 else {
arg1094_407 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test1064_1086;
{
obj_t arg1065_1087;
obj_t arg1066_1088;
{
obj_t s_1089;
if(STRUCTP(table_44)){
s_1089 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1065_1087 = STRUCT_KEY(s_1089);
}
arg1066_1088 = symbol2441___hash;
test1064_1086 = (arg1065_1087==arg1066_1088);
}
if(test1064_1086){
arg1095_408 = STRUCT_REF(table_44, ((long)0));
}
 else {
arg1095_408 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
long n1_1095;
long n2_1096;
{
obj_t aux_3225;
if(INTEGERP(arg1094_407)){
aux_3225 = arg1094_407;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, arg1094_407, string2436___hash, BINT(((long)8268)));
exit( -1 );}
n1_1095 = (long)CINT(aux_3225);
}
{
obj_t aux_3232;
if(INTEGERP(arg1095_408)){
aux_3232 = arg1095_408;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, arg1095_408, string2436___hash, BINT(((long)8268)));
exit( -1 );}
n2_1096 = (long)CINT(aux_3232);
}
test1089_402 = (n1_1095<n2_1096);
}
}
if(test1089_402){
obj_t arg1090_403;
long arg1091_404;
{
bool_t test1039_1099;
{
obj_t arg1040_1100;
obj_t arg1041_1101;
{
obj_t s_1102;
if(STRUCTP(table_44)){
s_1102 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1100 = STRUCT_KEY(s_1102);
}
arg1041_1101 = symbol2441___hash;
test1039_1099 = (arg1040_1100==arg1041_1101);
}
if(test1039_1099){
arg1090_403 = STRUCT_REF(table_44, ((long)4));
}
 else {
arg1090_403 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t arg1092_405;
{
bool_t test1058_1109;
{
obj_t arg1059_1110;
obj_t arg1060_1111;
{
obj_t s_1112;
if(STRUCTP(table_44)){
s_1112 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1059_1110 = STRUCT_KEY(s_1112);
}
arg1060_1111 = symbol2441___hash;
test1058_1109 = (arg1059_1110==arg1060_1111);
}
if(test1058_1109){
arg1092_405 = STRUCT_REF(table_44, ((long)1));
}
 else {
arg1092_405 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
long z1_1118;
{
obj_t aux_3263;
if(INTEGERP(arg1092_405)){
aux_3263 = arg1092_405;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, arg1092_405, string2436___hash, BINT(((long)8361)));
exit( -1 );}
z1_1118 = (long)CINT(aux_3263);
}
arg1091_404 = (z1_1118/((long)2));
}
}
{
long n1_1120;
{
obj_t aux_3271;
if(INTEGERP(arg1090_403)){
aux_3271 = arg1090_403;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, arg1090_403, string2436___hash, BINT(((long)8325)));
exit( -1 );}
n1_1120 = (long)CINT(aux_3271);
}
test1088_401 = (n1_1120>arg1091_404);
}
}
 else {
test1088_401 = ((bool_t)0);
}
}
if(test1088_401){
hash_table_grows__110___hash(table_44);
}
 else {
BUNSPEC;
}
}
{
obj_t get_key_253_409;
{
bool_t test1045_1123;
{
obj_t arg1046_1124;
obj_t arg1047_1125;
{
obj_t s_1126;
if(STRUCTP(table_44)){
s_1126 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1046_1124 = STRUCT_KEY(s_1126);
}
arg1047_1125 = symbol2441___hash;
test1045_1123 = (arg1046_1124==arg1047_1125);
}
if(test1045_1123){
get_key_253_409 = STRUCT_REF(table_44, ((long)3));
}
 else {
get_key_253_409 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t key_410;
{
obj_t fun_1969;
if(PROCEDUREP(get_key_253_409)){
fun_1969 = get_key_253_409;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2448___hash, get_key_253_409, string2436___hash, BINT(((long)8603)));
exit( -1 );}
{
bool_t test1702_1976;
test1702_1976 = PROCEDURE_CORRECT_ARITYP(fun_1969, ((long)1));
if(test1702_1976){
key_410 = PROCEDURE_ENTRY(fun_1969)(get_key_253_409, obj_43, BEOA);
}
 else {
error_location_112___error(string2475___hash, list2476___hash, fun_1969, string2436___hash, BINT(((long)8603)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
{
obj_t hash_eq__126_411;
{
bool_t test1032_1133;
{
obj_t arg1033_1134;
obj_t arg1034_1135;
{
obj_t s_1136;
if(STRUCTP(table_44)){
s_1136 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1033_1134 = STRUCT_KEY(s_1136);
}
arg1034_1135 = symbol2441___hash;
test1032_1133 = (arg1033_1134==arg1034_1135);
}
if(test1032_1133){
hash_eq__126_411 = STRUCT_REF(table_44, ((long)5));
}
 else {
hash_eq__126_411 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t hash_num_11_412;
hash_num_11_412 = get_hash_number_100___hash(table_44, key_410);
{
obj_t vec_413;
{
bool_t test1026_1143;
{
obj_t arg1027_1144;
obj_t arg1028_1145;
{
obj_t s_1146;
if(STRUCTP(table_44)){
s_1146 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_1144 = STRUCT_KEY(s_1146);
}
arg1028_1145 = symbol2441___hash;
test1026_1143 = (arg1027_1144==arg1028_1145);
}
if(test1026_1143){
vec_413 = STRUCT_REF(table_44, ((long)6));
}
 else {
vec_413 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t bucket_414;
{
obj_t vector_1152;
long k_1153;
if(VECTORP(vec_413)){
vector_1152 = vec_413;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2464___hash, vec_413, string2436___hash, BINT(((long)8757)));
exit( -1 );}
{
obj_t aux_3332;
if(INTEGERP(hash_num_11_412)){
aux_3332 = hash_num_11_412;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, hash_num_11_412, string2436___hash, BINT(((long)8757)));
exit( -1 );}
k_1153 = (long)CINT(aux_3332);
}
{
bool_t test1295_1154;
{
long aux_3339;
aux_3339 = VECTOR_LENGTH(vector_1152);
test1295_1154 = BOUND_CHECK(k_1153, aux_3339);
}
if(test1295_1154){
bucket_414 = VECTOR_REF(vector_1152, k_1153);
}
 else {
bucket_414 = debug_error_location_199___error(string2465___hash, string2466___hash, BINT(k_1153), string2440___hash, BINT(((long)7610)));
}
}
}
{
if(NULLP(bucket_414)){
{
long arg1097_416;
{
obj_t arg1099_418;
{
bool_t test1039_1162;
{
obj_t arg1040_1163;
obj_t arg1041_1164;
{
obj_t s_1165;
if(STRUCTP(table_44)){
s_1165 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1163 = STRUCT_KEY(s_1165);
}
arg1041_1164 = symbol2441___hash;
test1039_1162 = (arg1040_1163==arg1041_1164);
}
if(test1039_1162){
arg1099_418 = STRUCT_REF(table_44, ((long)4));
}
 else {
arg1099_418 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
long z2_1172;
{
obj_t aux_3360;
if(INTEGERP(arg1099_418)){
aux_3360 = arg1099_418;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, arg1099_418, string2436___hash, BINT(((long)8855)));
exit( -1 );}
z2_1172 = (long)CINT(aux_3360);
}
arg1097_416 = (((long)1)+z2_1172);
}
}
{
bool_t test1042_1175;
{
obj_t arg1043_1176;
obj_t arg1044_1177;
{
obj_t s_1178;
if(STRUCTP(table_44)){
s_1178 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1176 = STRUCT_KEY(s_1178);
}
arg1044_1177 = symbol2441___hash;
test1042_1175 = (arg1043_1176==arg1044_1177);
}
if(test1042_1175){
obj_t aux_3376;
aux_3376 = BINT(arg1097_416);
STRUCT_SET(table_44, ((long)4), aux_3376);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t arg1100_419;
{
obj_t list1101_420;
list1101_420 = MAKE_PAIR(obj_43, BNIL);
arg1100_419 = list1101_420;
}
{
obj_t vector_1185;
long k_1186;
if(VECTORP(vec_413)){
vector_1185 = vec_413;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2464___hash, vec_413, string2436___hash, BINT(((long)8895)));
exit( -1 );}
{
obj_t aux_3387;
if(INTEGERP(hash_num_11_412)){
aux_3387 = hash_num_11_412;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, hash_num_11_412, string2436___hash, BINT(((long)8895)));
exit( -1 );}
k_1186 = (long)CINT(aux_3387);
}
{
bool_t test1293_1188;
{
long aux_3394;
aux_3394 = VECTOR_LENGTH(vector_1185);
test1293_1188 = BOUND_CHECK(k_1186, aux_3394);
}
if(test1293_1188){
VECTOR_SET(vector_1185, k_1186, arg1100_419);
}
 else {
debug_error_location_199___error(string2478___hash, string2466___hash, BINT(k_1186), string2440___hash, BINT(((long)7610)));
}
}
}
}
aux1333_1627 = obj_43;
}
 else {
obj_t bucket_422;
bucket_422 = bucket_414;
loop_423:
{
bool_t test1103_424;
{
obj_t arg1113_434;
{
obj_t arg1114_435;
{
obj_t pair_1194;
if(PAIRP(bucket_422)){
pair_1194 = bucket_422;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2435___hash, bucket_422, string2436___hash, BINT(((long)9010)));
exit( -1 );}
arg1114_435 = CAR(pair_1194);
}
{
obj_t fun_2043;
if(PROCEDUREP(get_key_253_409)){
fun_2043 = get_key_253_409;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2448___hash, get_key_253_409, string2436___hash, BINT(((long)9000)));
exit( -1 );}
{
bool_t test1790_2050;
test1790_2050 = PROCEDURE_CORRECT_ARITYP(fun_2043, ((long)1));
if(test1790_2050){
arg1113_434 = PROCEDURE_ENTRY(fun_2043)(get_key_253_409, arg1114_435, BEOA);
}
 else {
error_location_112___error(string2475___hash, list2479___hash, fun_2043, string2436___hash, BINT(((long)9000)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
{
obj_t fun_2057;
if(PROCEDUREP(hash_eq__126_411)){
fun_2057 = hash_eq__126_411;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2448___hash, hash_eq__126_411, string2436___hash, BINT(((long)8990)));
exit( -1 );}
{
bool_t test1805_2064;
test1805_2064 = PROCEDURE_CORRECT_ARITYP(fun_2057, ((long)2));
if(test1805_2064){
obj_t aux_3427;
aux_3427 = PROCEDURE_ENTRY(fun_2057)(hash_eq__126_411, arg1113_434, key_410, BEOA);
test1103_424 = CBOOL(aux_3427);
}
 else {
error_location_112___error(string2475___hash, list2481___hash, fun_2057, string2436___hash, BINT(((long)8990)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
if(test1103_424){
{
obj_t pair_1195;
if(PAIRP(bucket_422)){
pair_1195 = bucket_422;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2435___hash, bucket_422, string2436___hash, BINT(((long)9032)));
exit( -1 );}
aux1333_1627 = CAR(pair_1195);
}
}
 else {
bool_t test1104_425;
{
obj_t arg1112_433;
{
obj_t pair_1196;
if(PAIRP(bucket_422)){
pair_1196 = bucket_422;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2435___hash, bucket_422, string2436___hash, BINT(((long)9056)));
exit( -1 );}
arg1112_433 = CDR(pair_1196);
}
test1104_425 = NULLP(arg1112_433);
}
if(test1104_425){
{
long arg1105_426;
{
obj_t arg1107_428;
{
bool_t test1039_1199;
{
obj_t arg1040_1200;
obj_t arg1041_1201;
{
obj_t s_1202;
if(STRUCTP(table_44)){
s_1202 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1200 = STRUCT_KEY(s_1202);
}
arg1041_1201 = symbol2441___hash;
test1039_1199 = (arg1040_1200==arg1041_1201);
}
if(test1039_1199){
arg1107_428 = STRUCT_REF(table_44, ((long)4));
}
 else {
arg1107_428 = debug_error_location_199___error(string2452___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
{
long z2_1209;
{
obj_t aux_3460;
if(INTEGERP(arg1107_428)){
aux_3460 = arg1107_428;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2437___hash, arg1107_428, string2436___hash, BINT(((long)9101)));
exit( -1 );}
z2_1209 = (long)CINT(aux_3460);
}
arg1105_426 = (((long)1)+z2_1209);
}
}
{
bool_t test1042_1212;
{
obj_t arg1043_1213;
obj_t arg1044_1214;
{
obj_t s_1215;
if(STRUCTP(table_44)){
s_1215 = table_44;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2450___hash, table_44, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1213 = STRUCT_KEY(s_1215);
}
arg1044_1214 = symbol2441___hash;
test1042_1212 = (arg1043_1213==arg1044_1214);
}
if(test1042_1212){
obj_t aux_3476;
aux_3476 = BINT(arg1105_426);
STRUCT_SET(table_44, ((long)4), aux_3476);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_44, string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t arg1108_429;
{
obj_t list1109_430;
list1109_430 = MAKE_PAIR(obj_43, BNIL);
arg1108_429 = list1109_430;
}
{
obj_t pair_1222;
if(PAIRP(bucket_422)){
pair_1222 = bucket_422;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2435___hash, bucket_422, string2436___hash, BINT(((long)9138)));
exit( -1 );}
SET_CDR(pair_1222, arg1108_429);
}
}
aux1333_1627 = obj_43;
}
 else {
{
obj_t arg1111_432;
{
obj_t pair_1224;
if(PAIRP(bucket_422)){
pair_1224 = bucket_422;
}
 else {
bigloo_type_error_location_103___error(symbol2474___hash, string2435___hash, bucket_422, string2436___hash, BINT(((long)9193)));
exit( -1 );}
arg1111_432 = CDR(pair_1224);
}
{
obj_t bucket_3494;
bucket_3494 = arg1111_432;
bucket_422 = bucket_3494;
goto loop_423;
}
}
}
}
}
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1333_1627;
}
}
}
}


/* _put-hash! */obj_t _put_hash__86___hash(obj_t env_1665, obj_t obj_1666, obj_t table_1667)
{
return put_hash__129___hash(obj_1666, table_1667);
}


/* rem-obj-hash! */obj_t rem_obj_hash__55___hash(obj_t obj_45, obj_t table_46)
{
{
obj_t symbol1336_1628;
symbol1336_1628 = symbol2483___hash;
{
PUSH_TRACE(symbol1336_1628);
BUNSPEC;
{
obj_t aux1335_1629;
{
obj_t get_key_253_436;
{
bool_t test1045_1226;
{
obj_t arg1046_1227;
obj_t arg1047_1228;
{
obj_t s_1229;
if(STRUCTP(table_46)){
s_1229 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1046_1227 = STRUCT_KEY(s_1229);
}
arg1047_1228 = symbol2441___hash;
test1045_1226 = (arg1046_1227==arg1047_1228);
}
if(test1045_1226){
get_key_253_436 = STRUCT_REF(table_46, ((long)3));
}
 else {
get_key_253_436 = debug_error_location_199___error(string2452___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t key_437;
{
obj_t fun_2119;
if(PROCEDUREP(get_key_253_436)){
fun_2119 = get_key_253_436;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2448___hash, get_key_253_436, string2436___hash, BINT(((long)9531)));
exit( -1 );}
{
bool_t test1872_2126;
test1872_2126 = PROCEDURE_CORRECT_ARITYP(fun_2119, ((long)1));
if(test1872_2126){
key_437 = PROCEDURE_ENTRY(fun_2119)(get_key_253_436, obj_45, BEOA);
}
 else {
error_location_112___error(string2484___hash, list2476___hash, fun_2119, string2436___hash, BINT(((long)9531)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
{
obj_t hash_eq__126_438;
{
bool_t test1032_1236;
{
obj_t arg1033_1237;
obj_t arg1034_1238;
{
obj_t s_1239;
if(STRUCTP(table_46)){
s_1239 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1033_1237 = STRUCT_KEY(s_1239);
}
arg1034_1238 = symbol2441___hash;
test1032_1236 = (arg1033_1237==arg1034_1238);
}
if(test1032_1236){
hash_eq__126_438 = STRUCT_REF(table_46, ((long)5));
}
 else {
hash_eq__126_438 = debug_error_location_199___error(string2452___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t hash_num_11_439;
hash_num_11_439 = get_hash_number_100___hash(table_46, key_437);
{
obj_t vec_440;
{
bool_t test1026_1246;
{
obj_t arg1027_1247;
obj_t arg1028_1248;
{
obj_t s_1249;
if(STRUCTP(table_46)){
s_1249 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_1247 = STRUCT_KEY(s_1249);
}
arg1028_1248 = symbol2441___hash;
test1026_1246 = (arg1027_1247==arg1028_1248);
}
if(test1026_1246){
vec_440 = STRUCT_REF(table_46, ((long)6));
}
 else {
vec_440 = debug_error_location_199___error(string2452___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t bucket_441;
{
obj_t vector_1255;
long k_1256;
if(VECTORP(vec_440)){
vector_1255 = vec_440;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2464___hash, vec_440, string2436___hash, BINT(((long)9685)));
exit( -1 );}
{
obj_t aux_3549;
if(INTEGERP(hash_num_11_439)){
aux_3549 = hash_num_11_439;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2437___hash, hash_num_11_439, string2436___hash, BINT(((long)9685)));
exit( -1 );}
k_1256 = (long)CINT(aux_3549);
}
{
bool_t test1295_1257;
{
long aux_3556;
aux_3556 = VECTOR_LENGTH(vector_1255);
test1295_1257 = BOUND_CHECK(k_1256, aux_3556);
}
if(test1295_1257){
bucket_441 = VECTOR_REF(vector_1255, k_1256);
}
 else {
bucket_441 = debug_error_location_199___error(string2465___hash, string2466___hash, BINT(k_1256), string2440___hash, BINT(((long)7610)));
}
}
}
{
if(NULLP(bucket_441)){
aux1335_1629 = BFALSE;
}
 else {
bool_t test1116_443;
{
obj_t arg1130_459;
{
obj_t pair_1264;
if(PAIRP(bucket_441)){
pair_1264 = bucket_441;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_441, string2436___hash, BINT(((long)9759)));
exit( -1 );}
arg1130_459 = CAR(pair_1264);
}
test1116_443 = (arg1130_459==obj_45);
}
if(test1116_443){
{
long arg1117_444;
{
obj_t arg1118_445;
{
bool_t test1039_1268;
{
obj_t arg1040_1269;
obj_t arg1041_1270;
{
obj_t s_1271;
if(STRUCTP(table_46)){
s_1271 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1269 = STRUCT_KEY(s_1271);
}
arg1041_1270 = symbol2441___hash;
test1039_1268 = (arg1040_1269==arg1041_1270);
}
if(test1039_1268){
arg1118_445 = STRUCT_REF(table_46, ((long)4));
}
 else {
arg1118_445 = debug_error_location_199___error(string2452___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
{
long z1_1277;
{
obj_t aux_3585;
if(INTEGERP(arg1118_445)){
aux_3585 = arg1118_445;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2437___hash, arg1118_445, string2436___hash, BINT(((long)9808)));
exit( -1 );}
z1_1277 = (long)CINT(aux_3585);
}
arg1117_444 = (z1_1277-((long)1));
}
}
{
bool_t test1042_1281;
{
obj_t arg1043_1282;
obj_t arg1044_1283;
{
obj_t s_1284;
if(STRUCTP(table_46)){
s_1284 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1282 = STRUCT_KEY(s_1284);
}
arg1044_1283 = symbol2441___hash;
test1042_1281 = (arg1043_1282==arg1044_1283);
}
if(test1042_1281){
obj_t aux_3601;
aux_3601 = BINT(arg1117_444);
STRUCT_SET(table_46, ((long)4), aux_3601);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t arg1120_447;
{
obj_t pair_1290;
if(PAIRP(bucket_441)){
pair_1290 = bucket_441;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_441, string2436___hash, BINT(((long)9872)));
exit( -1 );}
arg1120_447 = CDR(pair_1290);
}
{
obj_t vector_1291;
long k_1292;
if(VECTORP(vec_440)){
vector_1291 = vec_440;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2464___hash, vec_440, string2436___hash, BINT(((long)9845)));
exit( -1 );}
{
obj_t aux_3617;
if(INTEGERP(hash_num_11_439)){
aux_3617 = hash_num_11_439;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2437___hash, hash_num_11_439, string2436___hash, BINT(((long)9845)));
exit( -1 );}
k_1292 = (long)CINT(aux_3617);
}
{
bool_t test1293_1294;
{
long aux_3624;
aux_3624 = VECTOR_LENGTH(vector_1291);
test1293_1294 = BOUND_CHECK(k_1292, aux_3624);
}
if(test1293_1294){
VECTOR_SET(vector_1291, k_1292, arg1120_447);
}
 else {
debug_error_location_199___error(string2478___hash, string2466___hash, BINT(k_1292), string2440___hash, BINT(((long)7610)));
}
}
}
}
aux1335_1629 = BTRUE;
}
 else {
{
obj_t bucket_448;
{
bool_t aux_3632;
bucket_448 = bucket_441;
loop_449:
{
bool_t test1121_450;
{
obj_t arg1129_458;
{
obj_t pair_1300;
if(PAIRP(bucket_448)){
pair_1300 = bucket_448;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_448, string2436___hash, BINT(((long)9952)));
exit( -1 );}
{
obj_t arg1290_1301;
arg1290_1301 = CDR(pair_1300);
{
obj_t pair_1303;
if(PAIRP(arg1290_1301)){
pair_1303 = arg1290_1301;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, arg1290_1301, string2485___hash, BINT(((long)7991)));
exit( -1 );}
arg1129_458 = CAR(pair_1303);
}
}
}
test1121_450 = (arg1129_458==obj_45);
}
if(test1121_450){
{
long arg1122_451;
{
obj_t arg1123_452;
{
bool_t test1039_1307;
{
obj_t arg1040_1308;
obj_t arg1041_1309;
{
obj_t s_1310;
if(STRUCTP(table_46)){
s_1310 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1308 = STRUCT_KEY(s_1310);
}
arg1041_1309 = symbol2441___hash;
test1039_1307 = (arg1040_1308==arg1041_1309);
}
if(test1039_1307){
arg1123_452 = STRUCT_REF(table_46, ((long)4));
}
 else {
arg1123_452 = debug_error_location_199___error(string2452___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
{
long z1_1316;
{
obj_t aux_3658;
if(INTEGERP(arg1123_452)){
aux_3658 = arg1123_452;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2437___hash, arg1123_452, string2436___hash, BINT(((long)10002)));
exit( -1 );}
z1_1316 = (long)CINT(aux_3658);
}
arg1122_451 = (z1_1316-((long)1));
}
}
{
bool_t test1042_1320;
{
obj_t arg1043_1321;
obj_t arg1044_1322;
{
obj_t s_1323;
if(STRUCTP(table_46)){
s_1323 = table_46;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2450___hash, table_46, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1321 = STRUCT_KEY(s_1323);
}
arg1044_1322 = symbol2441___hash;
test1042_1320 = (arg1043_1321==arg1044_1322);
}
if(test1042_1320){
obj_t aux_3674;
aux_3674 = BINT(arg1122_451);
STRUCT_SET(table_46, ((long)4), aux_3674);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_46, string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t arg1125_454;
{
obj_t pair_1329;
if(PAIRP(bucket_448)){
pair_1329 = bucket_448;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_448, string2436___hash, BINT(((long)10057)));
exit( -1 );}
{
obj_t arg1287_1330;
arg1287_1330 = CDR(pair_1329);
{
obj_t pair_1332;
if(PAIRP(arg1287_1330)){
pair_1332 = arg1287_1330;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, arg1287_1330, string2485___hash, BINT(((long)8533)));
exit( -1 );}
arg1125_454 = CDR(pair_1332);
}
}
}
{
obj_t pair_1333;
if(PAIRP(bucket_448)){
pair_1333 = bucket_448;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_448, string2436___hash, BINT(((long)10039)));
exit( -1 );}
SET_CDR(pair_1333, arg1125_454);
}
}
aux_3632 = ((bool_t)1);
}
 else {
bool_t test1126_455;
{
obj_t arg1128_457;
{
obj_t pair_1335;
if(PAIRP(bucket_448)){
pair_1335 = bucket_448;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_448, string2436___hash, BINT(((long)10089)));
exit( -1 );}
arg1128_457 = CDR(pair_1335);
}
test1126_455 = NULLP(arg1128_457);
}
if(test1126_455){
aux_3632 = ((bool_t)0);
}
 else {
{
obj_t arg1127_456;
{
obj_t pair_1337;
if(PAIRP(bucket_448)){
pair_1337 = bucket_448;
}
 else {
bigloo_type_error_location_103___error(symbol2483___hash, string2435___hash, bucket_448, string2436___hash, BINT(((long)10127)));
exit( -1 );}
arg1127_456 = CDR(pair_1337);
}
{
obj_t bucket_3711;
bucket_3711 = arg1127_456;
bucket_448 = bucket_3711;
goto loop_449;
}
}
}
}
}
aux1335_1629 = BBOOL(aux_3632);
}
}
}
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1335_1629;
}
}
}
}


/* _rem-obj-hash! */obj_t _rem_obj_hash__23___hash(obj_t env_1668, obj_t obj_1669, obj_t table_1670)
{
return rem_obj_hash__55___hash(obj_1669, table_1670);
}


/* rem-key-hash! */obj_t rem_key_hash__152___hash(obj_t key_47, obj_t table_48)
{
{
obj_t symbol1338_1630;
symbol1338_1630 = symbol2486___hash;
{
PUSH_TRACE(symbol1338_1630);
BUNSPEC;
{
obj_t aux1337_1631;
{
obj_t get_key_253_460;
{
bool_t test1045_1339;
{
obj_t arg1046_1340;
obj_t arg1047_1341;
{
obj_t s_1342;
if(STRUCTP(table_48)){
s_1342 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1046_1340 = STRUCT_KEY(s_1342);
}
arg1047_1341 = symbol2441___hash;
test1045_1339 = (arg1046_1340==arg1047_1341);
}
if(test1045_1339){
get_key_253_460 = STRUCT_REF(table_48, ((long)3));
}
 else {
get_key_253_460 = debug_error_location_199___error(string2452___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t hash_eq__126_461;
{
bool_t test1032_1349;
{
obj_t arg1033_1350;
obj_t arg1034_1351;
{
obj_t s_1352;
if(STRUCTP(table_48)){
s_1352 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1033_1350 = STRUCT_KEY(s_1352);
}
arg1034_1351 = symbol2441___hash;
test1032_1349 = (arg1033_1350==arg1034_1351);
}
if(test1032_1349){
hash_eq__126_461 = STRUCT_REF(table_48, ((long)5));
}
 else {
hash_eq__126_461 = debug_error_location_199___error(string2452___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t hash_num_11_462;
hash_num_11_462 = get_hash_number_100___hash(table_48, key_47);
{
obj_t vec_463;
{
bool_t test1026_1359;
{
obj_t arg1027_1360;
obj_t arg1028_1361;
{
obj_t s_1362;
if(STRUCTP(table_48)){
s_1362 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_1360 = STRUCT_KEY(s_1362);
}
arg1028_1361 = symbol2441___hash;
test1026_1359 = (arg1027_1360==arg1028_1361);
}
if(test1026_1359){
vec_463 = STRUCT_REF(table_48, ((long)6));
}
 else {
vec_463 = debug_error_location_199___error(string2452___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t bucket_464;
{
obj_t vector_1368;
long k_1369;
if(VECTORP(vec_463)){
vector_1368 = vec_463;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2464___hash, vec_463, string2436___hash, BINT(((long)10590)));
exit( -1 );}
{
obj_t aux_3755;
if(INTEGERP(hash_num_11_462)){
aux_3755 = hash_num_11_462;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2437___hash, hash_num_11_462, string2436___hash, BINT(((long)10590)));
exit( -1 );}
k_1369 = (long)CINT(aux_3755);
}
{
bool_t test1295_1370;
{
long aux_3762;
aux_3762 = VECTOR_LENGTH(vector_1368);
test1295_1370 = BOUND_CHECK(k_1369, aux_3762);
}
if(test1295_1370){
bucket_464 = VECTOR_REF(vector_1368, k_1369);
}
 else {
bucket_464 = debug_error_location_199___error(string2465___hash, string2466___hash, BINT(k_1369), string2440___hash, BINT(((long)7610)));
}
}
}
{
if(NULLP(bucket_464)){
aux1337_1631 = BFALSE;
}
 else {
bool_t test1132_466;
{
obj_t arg1148_483;
{
obj_t arg1150_484;
{
obj_t pair_1377;
if(PAIRP(bucket_464)){
pair_1377 = bucket_464;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_464, string2436___hash, BINT(((long)10678)));
exit( -1 );}
arg1150_484 = CAR(pair_1377);
}
{
obj_t fun_2295;
if(PROCEDUREP(get_key_253_460)){
fun_2295 = get_key_253_460;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2448___hash, get_key_253_460, string2436___hash, BINT(((long)10668)));
exit( -1 );}
{
bool_t test2065_2302;
test2065_2302 = PROCEDURE_CORRECT_ARITYP(fun_2295, ((long)1));
if(test2065_2302){
arg1148_483 = PROCEDURE_ENTRY(fun_2295)(get_key_253_460, arg1150_484, BEOA);
}
 else {
error_location_112___error(string2487___hash, list2488___hash, fun_2295, string2436___hash, BINT(((long)10668)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
{
obj_t fun_2309;
if(PROCEDUREP(hash_eq__126_461)){
fun_2309 = hash_eq__126_461;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2448___hash, hash_eq__126_461, string2436___hash, BINT(((long)10658)));
exit( -1 );}
{
bool_t test2078_2316;
test2078_2316 = PROCEDURE_CORRECT_ARITYP(fun_2309, ((long)2));
if(test2078_2316){
obj_t aux_3797;
aux_3797 = PROCEDURE_ENTRY(fun_2309)(hash_eq__126_461, arg1148_483, key_47, BEOA);
test1132_466 = CBOOL(aux_3797);
}
 else {
error_location_112___error(string2487___hash, list2490___hash, fun_2309, string2436___hash, BINT(((long)10658)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
if(test1132_466){
{
long arg1133_467;
{
obj_t arg1134_468;
{
bool_t test1039_1379;
{
obj_t arg1040_1380;
obj_t arg1041_1381;
{
obj_t s_1382;
if(STRUCTP(table_48)){
s_1382 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1380 = STRUCT_KEY(s_1382);
}
arg1041_1381 = symbol2441___hash;
test1039_1379 = (arg1040_1380==arg1041_1381);
}
if(test1039_1379){
arg1134_468 = STRUCT_REF(table_48, ((long)4));
}
 else {
arg1134_468 = debug_error_location_199___error(string2452___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
{
long z1_1388;
{
obj_t aux_3816;
if(INTEGERP(arg1134_468)){
aux_3816 = arg1134_468;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2437___hash, arg1134_468, string2436___hash, BINT(((long)10728)));
exit( -1 );}
z1_1388 = (long)CINT(aux_3816);
}
arg1133_467 = (z1_1388-((long)1));
}
}
{
bool_t test1042_1392;
{
obj_t arg1043_1393;
obj_t arg1044_1394;
{
obj_t s_1395;
if(STRUCTP(table_48)){
s_1395 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1393 = STRUCT_KEY(s_1395);
}
arg1044_1394 = symbol2441___hash;
test1042_1392 = (arg1043_1393==arg1044_1394);
}
if(test1042_1392){
obj_t aux_3832;
aux_3832 = BINT(arg1133_467);
STRUCT_SET(table_48, ((long)4), aux_3832);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t arg1136_470;
{
obj_t pair_1401;
if(PAIRP(bucket_464)){
pair_1401 = bucket_464;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_464, string2436___hash, BINT(((long)10792)));
exit( -1 );}
arg1136_470 = CDR(pair_1401);
}
{
obj_t vector_1402;
long k_1403;
if(VECTORP(vec_463)){
vector_1402 = vec_463;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2464___hash, vec_463, string2436___hash, BINT(((long)10765)));
exit( -1 );}
{
obj_t aux_3848;
if(INTEGERP(hash_num_11_462)){
aux_3848 = hash_num_11_462;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2437___hash, hash_num_11_462, string2436___hash, BINT(((long)10765)));
exit( -1 );}
k_1403 = (long)CINT(aux_3848);
}
{
bool_t test1293_1405;
{
long aux_3855;
aux_3855 = VECTOR_LENGTH(vector_1402);
test1293_1405 = BOUND_CHECK(k_1403, aux_3855);
}
if(test1293_1405){
VECTOR_SET(vector_1402, k_1403, arg1136_470);
}
 else {
debug_error_location_199___error(string2478___hash, string2466___hash, BINT(k_1403), string2440___hash, BINT(((long)7610)));
}
}
}
}
aux1337_1631 = BTRUE;
}
 else {
{
obj_t bucket_471;
{
bool_t aux_3863;
bucket_471 = bucket_464;
loop_472:
{
bool_t test1137_473;
{
obj_t arg1146_481;
{
obj_t arg1147_482;
{
obj_t pair_1411;
if(PAIRP(bucket_471)){
pair_1411 = bucket_471;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_471, string2436___hash, BINT(((long)10886)));
exit( -1 );}
{
obj_t arg1290_1412;
arg1290_1412 = CDR(pair_1411);
{
obj_t pair_1414;
if(PAIRP(arg1290_1412)){
pair_1414 = arg1290_1412;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, arg1290_1412, string2485___hash, BINT(((long)7991)));
exit( -1 );}
arg1147_482 = CAR(pair_1414);
}
}
}
{
obj_t fun_2371;
if(PROCEDUREP(get_key_253_460)){
fun_2371 = get_key_253_460;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2448___hash, get_key_253_460, string2436___hash, BINT(((long)10876)));
exit( -1 );}
{
bool_t test2145_2378;
test2145_2378 = PROCEDURE_CORRECT_ARITYP(fun_2371, ((long)1));
if(test2145_2378){
arg1146_481 = PROCEDURE_ENTRY(fun_2371)(get_key_253_460, arg1147_482, BEOA);
}
 else {
error_location_112___error(string2487___hash, list2492___hash, fun_2371, string2436___hash, BINT(((long)10876)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
{
obj_t fun_2385;
if(PROCEDUREP(hash_eq__126_461)){
fun_2385 = hash_eq__126_461;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2448___hash, hash_eq__126_461, string2436___hash, BINT(((long)10866)));
exit( -1 );}
{
bool_t test2158_2392;
test2158_2392 = PROCEDURE_CORRECT_ARITYP(fun_2385, ((long)2));
if(test2158_2392){
obj_t aux_3895;
aux_3895 = PROCEDURE_ENTRY(fun_2385)(hash_eq__126_461, arg1146_481, key_47, BEOA);
test1137_473 = CBOOL(aux_3895);
}
 else {
error_location_112___error(string2487___hash, list2494___hash, fun_2385, string2436___hash, BINT(((long)10866)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
}
if(test1137_473){
{
long arg1139_474;
{
obj_t arg1140_475;
{
bool_t test1039_1416;
{
obj_t arg1040_1417;
obj_t arg1041_1418;
{
obj_t s_1419;
if(STRUCTP(table_48)){
s_1419 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1040_1417 = STRUCT_KEY(s_1419);
}
arg1041_1418 = symbol2441___hash;
test1039_1416 = (arg1040_1417==arg1041_1418);
}
if(test1039_1416){
arg1140_475 = STRUCT_REF(table_48, ((long)4));
}
 else {
arg1140_475 = debug_error_location_199___error(string2452___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
{
long z1_1425;
{
obj_t aux_3914;
if(INTEGERP(arg1140_475)){
aux_3914 = arg1140_475;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2437___hash, arg1140_475, string2436___hash, BINT(((long)10937)));
exit( -1 );}
z1_1425 = (long)CINT(aux_3914);
}
arg1139_474 = (z1_1425-((long)1));
}
}
{
bool_t test1042_1429;
{
obj_t arg1043_1430;
obj_t arg1044_1431;
{
obj_t s_1432;
if(STRUCTP(table_48)){
s_1432 = table_48;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2450___hash, table_48, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1430 = STRUCT_KEY(s_1432);
}
arg1044_1431 = symbol2441___hash;
test1042_1429 = (arg1043_1430==arg1044_1431);
}
if(test1042_1429){
obj_t aux_3930;
aux_3930 = BINT(arg1139_474);
STRUCT_SET(table_48, ((long)4), aux_3930);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_48, string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t arg1142_477;
{
obj_t pair_1438;
if(PAIRP(bucket_471)){
pair_1438 = bucket_471;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_471, string2436___hash, BINT(((long)10992)));
exit( -1 );}
{
obj_t arg1287_1439;
arg1287_1439 = CDR(pair_1438);
{
obj_t pair_1441;
if(PAIRP(arg1287_1439)){
pair_1441 = arg1287_1439;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, arg1287_1439, string2485___hash, BINT(((long)8533)));
exit( -1 );}
arg1142_477 = CDR(pair_1441);
}
}
}
{
obj_t pair_1442;
if(PAIRP(bucket_471)){
pair_1442 = bucket_471;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_471, string2436___hash, BINT(((long)10974)));
exit( -1 );}
SET_CDR(pair_1442, arg1142_477);
}
}
aux_3863 = ((bool_t)1);
}
 else {
bool_t test1143_478;
{
obj_t arg1145_480;
{
obj_t pair_1444;
if(PAIRP(bucket_471)){
pair_1444 = bucket_471;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_471, string2436___hash, BINT(((long)11024)));
exit( -1 );}
arg1145_480 = CDR(pair_1444);
}
test1143_478 = NULLP(arg1145_480);
}
if(test1143_478){
aux_3863 = ((bool_t)0);
}
 else {
{
obj_t arg1144_479;
{
obj_t pair_1446;
if(PAIRP(bucket_471)){
pair_1446 = bucket_471;
}
 else {
bigloo_type_error_location_103___error(symbol2486___hash, string2435___hash, bucket_471, string2436___hash, BINT(((long)11062)));
exit( -1 );}
arg1144_479 = CDR(pair_1446);
}
{
obj_t bucket_3967;
bucket_3967 = arg1144_479;
bucket_471 = bucket_3967;
goto loop_472;
}
}
}
}
}
aux1337_1631 = BBOOL(aux_3863);
}
}
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1337_1631;
}
}
}
}


/* _rem-key-hash! */obj_t _rem_key_hash__54___hash(obj_t env_1671, obj_t key_1672, obj_t table_1673)
{
return rem_key_hash__152___hash(key_1672, table_1673);
}


/* for-each-hash */obj_t for_each_hash_105___hash(obj_t fun_49, obj_t table_50)
{
{
obj_t symbol1340_1632;
symbol1340_1632 = symbol2496___hash;
{
PUSH_TRACE(symbol1340_1632);
BUNSPEC;
{
obj_t aux1339_1633;
{
obj_t vec_485;
{
bool_t test1026_1448;
{
obj_t arg1027_1449;
obj_t arg1028_1450;
{
obj_t s_1451;
if(STRUCTP(table_50)){
s_1451 = table_50;
}
 else {
bigloo_type_error_location_103___error(symbol2496___hash, string2450___hash, table_50, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_1449 = STRUCT_KEY(s_1451);
}
arg1028_1450 = symbol2441___hash;
test1026_1448 = (arg1027_1449==arg1028_1450);
}
if(test1026_1448){
vec_485 = STRUCT_REF(table_50, ((long)6));
}
 else {
vec_485 = debug_error_location_199___error(string2452___hash, string2443___hash, table_50, string2440___hash, BINT(((long)7610)));
}
}
{
long i_486;
{
long arg1151_488;
{
obj_t arg1152_489;
{
bool_t test1058_1458;
{
obj_t arg1059_1459;
obj_t arg1060_1460;
{
obj_t s_1461;
if(STRUCTP(table_50)){
s_1461 = table_50;
}
 else {
bigloo_type_error_location_103___error(symbol2496___hash, string2450___hash, table_50, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1059_1459 = STRUCT_KEY(s_1461);
}
arg1060_1460 = symbol2441___hash;
test1058_1458 = (arg1059_1459==arg1060_1460);
}
if(test1058_1458){
arg1152_489 = STRUCT_REF(table_50, ((long)1));
}
 else {
arg1152_489 = debug_error_location_199___error(string2452___hash, string2443___hash, table_50, string2440___hash, BINT(((long)7610)));
}
}
{
long z1_1467;
{
obj_t aux_3994;
if(INTEGERP(arg1152_489)){
aux_3994 = arg1152_489;
}
 else {
bigloo_type_error_location_103___error(symbol2496___hash, string2437___hash, arg1152_489, string2436___hash, BINT(((long)11397)));
exit( -1 );}
z1_1467 = (long)CINT(aux_3994);
}
arg1151_488 = (z1_1467-((long)1));
}
}
i_486 = arg1151_488;
loop_487:
if((i_486==((long)-1))){
aux1339_1633 = BUNSPEC;
}
 else {
{
obj_t l1002_492;
{
obj_t arg1155_494;
{
obj_t vector_1471;
if(VECTORP(vec_485)){
vector_1471 = vec_485;
}
 else {
bigloo_type_error_location_103___error(symbol2496___hash, string2464___hash, vec_485, string2436___hash, BINT(((long)11493)));
exit( -1 );}
{
bool_t test1295_1473;
{
long aux_4009;
aux_4009 = VECTOR_LENGTH(vector_1471);
test1295_1473 = BOUND_CHECK(i_486, aux_4009);
}
if(test1295_1473){
arg1155_494 = VECTOR_REF(vector_1471, i_486);
}
 else {
arg1155_494 = debug_error_location_199___error(string2465___hash, string2466___hash, BINT(i_486), string2440___hash, BINT(((long)7610)));
}
}
}
l1002_492 = arg1155_494;
lname1003_493:
{
bool_t test1156_495;
test1156_495 = PAIRP(l1002_492);
if(test1156_495){
{
obj_t arg1157_496;
{
obj_t pair_1480;
if(test1156_495){
pair_1480 = l1002_492;
}
 else {
bigloo_type_error_location_103___error(symbol2496___hash, string2435___hash, l1002_492, string2436___hash, BINT(((long)11479)));
exit( -1 );}
arg1157_496 = CAR(pair_1480);
}
{
bool_t test2230_2460;
test2230_2460 = PROCEDURE_CORRECT_ARITYP(fun_49, ((long)1));
if(test2230_2460){
PROCEDURE_ENTRY(fun_49)(fun_49, arg1157_496, BEOA);
}
 else {
error_location_112___error(string2497___hash, list2498___hash, fun_49, string2436___hash, BINT(((long)11479)));
FAILURE(symbol2460___hash,symbol2460___hash,symbol2460___hash);}
}
}
{
obj_t arg1158_497;
{
obj_t pair_1481;
if(PAIRP(l1002_492)){
pair_1481 = l1002_492;
}
 else {
bigloo_type_error_location_103___error(symbol2496___hash, string2435___hash, l1002_492, string2436___hash, BINT(((long)11479)));
exit( -1 );}
arg1158_497 = CDR(pair_1481);
}
{
obj_t l1002_4037;
l1002_4037 = arg1158_497;
l1002_492 = l1002_4037;
goto lname1003_493;
}
}
}
 else {
if(NULLP(l1002_492)){
BTRUE;
}
 else {
debug_error_location_199___error(string2501___hash, string2502___hash, l1002_492, string2440___hash, BINT(((long)7610)));
}
}
}
}
}
{
long i_4042;
i_4042 = (i_486-((long)1));
i_486 = i_4042;
goto loop_487;
}
}
}
}
}
POP_TRACE();
return aux1339_1633;
}
}
}
}


/* _for-each-hash1358 */obj_t _for_each_hash1358_11___hash(obj_t env_1674, obj_t fun_1675, obj_t table_1676)
{
{
obj_t aux_4045;
if(PROCEDUREP(fun_1675)){
aux_4045 = fun_1675;
}
 else {
bigloo_type_error_location_103___error(symbol2503___hash, string2448___hash, fun_1675, string2436___hash, BINT(((long)11305)));
exit( -1 );}
return for_each_hash_105___hash(aux_4045, table_1676);
}
}


/* hash-table-grows! */obj_t hash_table_grows__110___hash(obj_t table_51)
{
{
obj_t symbol1342_1634;
symbol1342_1634 = symbol2504___hash;
{
PUSH_TRACE(symbol1342_1634);
BUNSPEC;
{
obj_t aux1341_1635;
{
obj_t max_size_171_500;
{
bool_t test1064_1489;
{
obj_t arg1065_1490;
obj_t arg1066_1491;
{
obj_t s_1492;
if(STRUCTP(table_51)){
s_1492 = table_51;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2450___hash, table_51, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1065_1490 = STRUCT_KEY(s_1492);
}
arg1066_1491 = symbol2441___hash;
test1064_1489 = (arg1065_1490==arg1066_1491);
}
if(test1064_1489){
max_size_171_500 = STRUCT_REF(table_51, ((long)0));
}
 else {
max_size_171_500 = debug_error_location_199___error(string2452___hash, string2443___hash, table_51, string2440___hash, BINT(((long)7610)));
}
}
{
obj_t size_501;
{
bool_t test1058_1499;
{
obj_t arg1059_1500;
obj_t arg1060_1501;
{
obj_t s_1502;
if(STRUCTP(table_51)){
s_1502 = table_51;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2450___hash, table_51, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1059_1500 = STRUCT_KEY(s_1502);
}
arg1060_1501 = symbol2441___hash;
test1058_1499 = (arg1059_1500==arg1060_1501);
}
if(test1058_1499){
size_501 = STRUCT_REF(table_51, ((long)1));
}
 else {
size_501 = debug_error_location_199___error(string2452___hash, string2443___hash, table_51, string2440___hash, BINT(((long)7610)));
}
}
{
long new_size_209_502;
{
long z1_1508;
{
obj_t aux_4075;
if(INTEGERP(size_501)){
aux_4075 = size_501;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2437___hash, size_501, string2436___hash, BINT(((long)11895)));
exit( -1 );}
z1_1508 = (long)CINT(aux_4075);
}
new_size_209_502 = (z1_1508*((long)2));
}
{
obj_t new_table_236_503;
new_table_236_503 = make_vector(new_size_209_502, BNIL);
{
obj_t old_table_227_504;
{
bool_t test1026_1512;
{
obj_t arg1027_1513;
obj_t arg1028_1514;
{
obj_t s_1515;
if(STRUCTP(table_51)){
s_1515 = table_51;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2450___hash, table_51, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1027_1513 = STRUCT_KEY(s_1515);
}
arg1028_1514 = symbol2441___hash;
test1026_1512 = (arg1027_1513==arg1028_1514);
}
if(test1026_1512){
old_table_227_504 = STRUCT_REF(table_51, ((long)6));
}
 else {
old_table_227_504 = debug_error_location_199___error(string2452___hash, string2443___hash, table_51, string2440___hash, BINT(((long)7610)));
}
}
{
{
bool_t test1061_1523;
{
obj_t arg1062_1524;
obj_t arg1063_1525;
{
obj_t s_1526;
if(STRUCTP(table_51)){
s_1526 = table_51;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2450___hash, table_51, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1062_1524 = STRUCT_KEY(s_1526);
}
arg1063_1525 = symbol2441___hash;
test1061_1523 = (arg1062_1524==arg1063_1525);
}
if(test1061_1523){
obj_t aux_4103;
aux_4103 = BINT(new_size_209_502);
STRUCT_SET(table_51, ((long)1), aux_4103);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_51, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test1029_1534;
{
obj_t arg1030_1535;
obj_t arg1031_1536;
{
obj_t s_1537;
if(STRUCTP(table_51)){
s_1537 = table_51;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2450___hash, table_51, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1030_1535 = STRUCT_KEY(s_1537);
}
arg1031_1536 = symbol2441___hash;
test1029_1534 = (arg1030_1535==arg1031_1536);
}
if(test1029_1534){
STRUCT_SET(table_51, ((long)6), new_table_236_503);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_51, string2440___hash, BINT(((long)7610)));
}
}
{
bool_t test1042_1545;
{
obj_t arg1043_1546;
obj_t arg1044_1547;
{
obj_t s_1548;
if(STRUCTP(table_51)){
s_1548 = table_51;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2450___hash, table_51, string2436___hash, BINT(((long)3711)));
exit( -1 );}
arg1043_1546 = STRUCT_KEY(s_1548);
}
arg1044_1547 = symbol2441___hash;
test1042_1545 = (arg1043_1546==arg1044_1547);
}
if(test1042_1545){
obj_t aux_4127;
aux_4127 = BINT(((long)0));
STRUCT_SET(table_51, ((long)4), aux_4127);
}
 else {
debug_error_location_199___error(string2442___hash, string2443___hash, table_51, string2440___hash, BINT(((long)7610)));
}
}
{
long i_505;
i_505 = ((long)0);
loop_506:
{
bool_t test1161_507;
{
long n2_1555;
{
obj_t aux_4132;
if(INTEGERP(size_501)){
aux_4132 = size_501;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2437___hash, size_501, string2436___hash, BINT(((long)12360)));
exit( -1 );}
n2_1555 = (long)CINT(aux_4132);
}
test1161_507 = (i_505==n2_1555);
}
if(test1161_507){
aux1341_1635 = symbol2505___hash;
}
 else {
obj_t bucket_508;
{
obj_t vector_1556;
if(VECTORP(old_table_227_504)){
vector_1556 = old_table_227_504;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2464___hash, old_table_227_504, string2436___hash, BINT(((long)12400)));
exit( -1 );}
{
bool_t test1295_1558;
{
long aux_4146;
aux_4146 = VECTOR_LENGTH(vector_1556);
test1295_1558 = BOUND_CHECK(i_505, aux_4146);
}
if(test1295_1558){
bucket_508 = VECTOR_REF(vector_1556, i_505);
}
 else {
bucket_508 = debug_error_location_199___error(string2465___hash, string2466___hash, BINT(i_505), string2440___hash, BINT(((long)7610)));
}
}
}
{
obj_t l1004_509;
l1004_509 = bucket_508;
lname1005_510:
{
bool_t test1162_511;
test1162_511 = PAIRP(l1004_509);
if(test1162_511){
{
obj_t obj_512;
{
obj_t pair_1565;
if(test1162_511){
pair_1565 = l1004_509;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2435___hash, l1004_509, string2436___hash, BINT(((long)12429)));
exit( -1 );}
obj_512 = CAR(pair_1565);
}
put_hash__129___hash(obj_512, table_51);
}
{
obj_t arg1163_513;
{
obj_t pair_1566;
if(PAIRP(l1004_509)){
pair_1566 = l1004_509;
}
 else {
bigloo_type_error_location_103___error(symbol2504___hash, string2435___hash, l1004_509, string2436___hash, BINT(((long)12429)));
exit( -1 );}
arg1163_513 = CDR(pair_1566);
}
{
obj_t l1004_4168;
l1004_4168 = arg1163_513;
l1004_509 = l1004_4168;
goto lname1005_510;
}
}
}
 else {
if(NULLP(l1004_509)){
BTRUE;
}
 else {
debug_error_location_199___error(string2501___hash, string2502___hash, l1004_509, string2440___hash, BINT(((long)7610)));
}
}
}
}
{
long i_4173;
i_4173 = (i_505+((long)1));
i_505 = i_4173;
goto loop_506;
}
}
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1341_1635;
}
}
}
}


/* string->0..255 */long string__0__255_119___hash(char * string_52)
{
{
obj_t symbol1344_2647;
symbol1344_2647 = symbol2506___hash;
{
PUSH_TRACE(symbol1344_2647);
BUNSPEC;
{
long aux1343_2648;
aux1343_2648 = get_hash_number(string_52);
POP_TRACE();
return aux1343_2648;
}
}
}
}


/* _string->0..2551359 */obj_t _string__0__2551359_61___hash(obj_t env_1677, obj_t string_1678)
{
{
long aux_4179;
{
char * string_2649;
{
obj_t aux_4180;
if(STRINGP(string_1678)){
aux_4180 = string_1678;
}
 else {
bigloo_type_error_location_103___error(symbol2507___hash, string2508___hash, string_1678, string2436___hash, BINT(((long)12744)));
exit( -1 );}
string_2649 = BSTRING_TO_STRING(aux_4180);
}
{
obj_t symbol1344_2650;
symbol1344_2650 = symbol2506___hash;
{
PUSH_TRACE(symbol1344_2650);
BUNSPEC;
{
long aux1343_2651;
aux1343_2651 = get_hash_number(string_2649);
POP_TRACE();
aux_4179 = aux1343_2651;
}
}
}
}
return BINT(aux_4179);
}
}


/* string->0..2^x-1 */long string__0__2_x_1_163___hash(char * string_53, long power_54)
{
{
obj_t symbol1346_2652;
symbol1346_2652 = symbol2509___hash;
{
PUSH_TRACE(symbol1346_2652);
BUNSPEC;
{
long aux1345_2653;
aux1345_2653 = get_hash_power_number(string_53, power_54);
POP_TRACE();
return aux1345_2653;
}
}
}
}


/* _string->0..2^x-11360 */obj_t _string__0__2_x_11360_5___hash(obj_t env_1679, obj_t string_1680, obj_t power_1681)
{
{
long aux_4194;
{
char * string_2654;
long power_2655;
{
obj_t aux_4195;
if(STRINGP(string_1680)){
aux_4195 = string_1680;
}
 else {
bigloo_type_error_location_103___error(symbol2510___hash, string2508___hash, string_1680, string2436___hash, BINT(((long)13035)));
exit( -1 );}
string_2654 = BSTRING_TO_STRING(aux_4195);
}
{
obj_t aux_4202;
if(INTEGERP(power_1681)){
aux_4202 = power_1681;
}
 else {
bigloo_type_error_location_103___error(symbol2510___hash, string2437___hash, power_1681, string2436___hash, BINT(((long)13035)));
exit( -1 );}
power_2655 = (long)CINT(aux_4202);
}
{
obj_t symbol1346_2656;
symbol1346_2656 = symbol2509___hash;
{
PUSH_TRACE(symbol1346_2656);
BUNSPEC;
{
long aux1345_2657;
aux1345_2657 = get_hash_power_number(string_2654, power_2655);
POP_TRACE();
aux_4194 = aux1345_2657;
}
}
}
}
return BINT(aux_4194);
}
}


/* int->0..255 */long int__0__255_26___hash(long int_55)
{
{
obj_t symbol1348_2658;
symbol1348_2658 = symbol2511___hash;
{
PUSH_TRACE(symbol1348_2658);
BUNSPEC;
{
long aux1347_2659;
aux1347_2659 = get_hash_number_from_int(int_55);
POP_TRACE();
return aux1347_2659;
}
}
}
}


/* _int->0..2551361 */obj_t _int__0__2551361_6___hash(obj_t env_1682, obj_t int_1683)
{
{
long aux_4216;
{
long int_184_2660;
{
obj_t aux_4217;
if(INTEGERP(int_1683)){
aux_4217 = int_1683;
}
 else {
bigloo_type_error_location_103___error(symbol2512___hash, string2437___hash, int_1683, string2436___hash, BINT(((long)13346)));
exit( -1 );}
int_184_2660 = (long)CINT(aux_4217);
}
{
obj_t symbol1348_2661;
symbol1348_2661 = symbol2511___hash;
{
PUSH_TRACE(symbol1348_2661);
BUNSPEC;
{
long aux1347_2662;
aux1347_2662 = get_hash_number_from_int(int_184_2660);
POP_TRACE();
aux_4216 = aux1347_2662;
}
}
}
}
return BINT(aux_4216);
}
}


/* int->0..2^x-1 */long int__0__2_x_1_11___hash(long int_56, long power_57)
{
{
obj_t symbol1350_2663;
symbol1350_2663 = symbol2513___hash;
{
PUSH_TRACE(symbol1350_2663);
BUNSPEC;
{
long aux1349_2664;
aux1349_2664 = get_hash_power_number_from_int(int_56, power_57);
POP_TRACE();
return aux1349_2664;
}
}
}
}


/* _int->0..2^x-11362 */obj_t _int__0__2_x_11362_181___hash(obj_t env_1684, obj_t int_1685, obj_t power_1686)
{
{
long aux_4231;
{
long int_184_2665;
long power_2666;
{
obj_t aux_4232;
if(INTEGERP(int_1685)){
aux_4232 = int_1685;
}
 else {
bigloo_type_error_location_103___error(symbol2514___hash, string2437___hash, int_1685, string2436___hash, BINT(((long)13637)));
exit( -1 );}
int_184_2665 = (long)CINT(aux_4232);
}
{
obj_t aux_4239;
if(INTEGERP(power_1686)){
aux_4239 = power_1686;
}
 else {
bigloo_type_error_location_103___error(symbol2514___hash, string2437___hash, power_1686, string2436___hash, BINT(((long)13637)));
exit( -1 );}
power_2666 = (long)CINT(aux_4239);
}
{
obj_t symbol1350_2667;
symbol1350_2667 = symbol2513___hash;
{
PUSH_TRACE(symbol1350_2667);
BUNSPEC;
{
long aux1349_2668;
aux1349_2668 = get_hash_power_number_from_int(int_184_2665, power_2666);
POP_TRACE();
aux_4231 = aux1349_2668;
}
}
}
}
return BINT(aux_4231);
}
}


/* obj->0..255 */long obj__0__255_3___hash(obj_t obj_58)
{
{
obj_t symbol1352_1644;
symbol1352_1644 = symbol2515___hash;
{
PUSH_TRACE(symbol1352_1644);
BUNSPEC;
{
long aux1351_1645;
{
bool_t test1167_517;
test1167_517 = STRINGP(obj_58);
if(test1167_517){
{
char * string_1574;
{
obj_t aux_4253;
if(test1167_517){
aux_4253 = obj_58;
}
 else {
bigloo_type_error_location_103___error(symbol2515___hash, string2508___hash, obj_58, string2436___hash, BINT(((long)14012)));
exit( -1 );}
string_1574 = BSTRING_TO_STRING(aux_4253);
}
aux1351_1645 = get_hash_number(string_1574);
}
}
 else {
bool_t test1168_518;
test1168_518 = SYMBOLP(obj_58);
if(test1168_518){
{
obj_t arg1169_519;
{
obj_t symbol_1576;
if(test1168_518){
symbol_1576 = obj_58;
}
 else {
bigloo_type_error_location_103___error(symbol2515___hash, string2516___hash, obj_58, string2436___hash, BINT(((long)14078)));
exit( -1 );}
arg1169_519 = SYMBOL_TO_STRING(symbol_1576);
}
{
char * aux_4267;
aux_4267 = BSTRING_TO_STRING(arg1169_519);
aux1351_1645 = get_hash_number(aux_4267);
}
}
}
 else {
bool_t test1170_520;
test1170_520 = INTEGERP(obj_58);
if(test1170_520){
{
long int_184_1579;
{
obj_t aux_4272;
if(test1170_520){
aux_4272 = obj_58;
}
 else {
bigloo_type_error_location_103___error(symbol2515___hash, string2437___hash, obj_58, string2436___hash, BINT(((long)14130)));
exit( -1 );}
int_184_1579 = (long)CINT(aux_4272);
}
aux1351_1645 = get_hash_number_from_int(int_184_1579);
}
}
 else {
bool_t test1171_521;
test1171_521 = CHARP(obj_58);
if(test1171_521){
{
unsigned char char_166_1581;
{
obj_t aux_4281;
if(test1171_521){
aux_4281 = obj_58;
}
 else {
bigloo_type_error_location_103___error(symbol2515___hash, string2517___hash, obj_58, string2436___hash, BINT(((long)14175)));
exit( -1 );}
char_166_1581 = (unsigned char)CCHAR(aux_4281);
}
aux1351_1645 = (char_166_1581);
}
}
 else {
aux1351_1645 = get_hash_number_from_int(obj_58);
}
}
}
}
}
POP_TRACE();
return aux1351_1645;
}
}
}
}


/* _obj->0..255 */obj_t _obj__0__255_117___hash(obj_t env_1687, obj_t obj_1688)
{
{
long aux_4290;
aux_4290 = obj__0__255_3___hash(obj_1688);
return BINT(aux_4290);
}
}


/* obj->0..2^x-1 */long obj__0__2_x_1_138___hash(obj_t obj_59, long power_60)
{
{
obj_t symbol1354_1646;
symbol1354_1646 = symbol2518___hash;
{
PUSH_TRACE(symbol1354_1646);
BUNSPEC;
{
long aux1353_1647;
{
bool_t test1172_522;
test1172_522 = STRINGP(obj_59);
if(test1172_522){
{
char * string_1583;
{
obj_t aux_4296;
if(test1172_522){
aux_4296 = obj_59;
}
 else {
bigloo_type_error_location_103___error(symbol2518___hash, string2508___hash, obj_59, string2436___hash, BINT(((long)14547)));
exit( -1 );}
string_1583 = BSTRING_TO_STRING(aux_4296);
}
aux1353_1647 = get_hash_power_number(string_1583, power_60);
}
}
 else {
bool_t test1173_523;
test1173_523 = SYMBOLP(obj_59);
if(test1173_523){
{
obj_t arg1174_524;
{
obj_t symbol_1586;
if(test1173_523){
symbol_1586 = obj_59;
}
 else {
bigloo_type_error_location_103___error(symbol2518___hash, string2516___hash, obj_59, string2436___hash, BINT(((long)14623)));
exit( -1 );}
arg1174_524 = SYMBOL_TO_STRING(symbol_1586);
}
{
char * aux_4310;
aux_4310 = BSTRING_TO_STRING(arg1174_524);
aux1353_1647 = get_hash_power_number(aux_4310, power_60);
}
}
}
 else {
bool_t test1175_525;
test1175_525 = INTEGERP(obj_59);
if(test1175_525){
{
long int_184_1590;
{
obj_t aux_4315;
if(test1175_525){
aux_4315 = obj_59;
}
 else {
bigloo_type_error_location_103___error(symbol2518___hash, string2437___hash, obj_59, string2436___hash, BINT(((long)14681)));
exit( -1 );}
int_184_1590 = (long)CINT(aux_4315);
}
aux1353_1647 = get_hash_power_number_from_int(int_184_1590, power_60);
}
}
 else {
bool_t test1176_526;
test1176_526 = CHARP(obj_59);
if(test1176_526){
{
unsigned char char_166_1593;
{
obj_t aux_4324;
if(test1176_526){
aux_4324 = obj_59;
}
 else {
bigloo_type_error_location_103___error(symbol2518___hash, string2517___hash, obj_59, string2436___hash, BINT(((long)14734)));
exit( -1 );}
char_166_1593 = (unsigned char)CCHAR(aux_4324);
}
aux1353_1647 = (char_166_1593);
}
}
 else {
aux1353_1647 = get_hash_power_number_from_int(obj_59, power_60);
}
}
}
}
}
POP_TRACE();
return aux1353_1647;
}
}
}
}


/* _obj->0..2^x-11363 */obj_t _obj__0__2_x_11363_110___hash(obj_t env_1689, obj_t obj_1690, obj_t power_1691)
{
{
long aux_4333;
{
long aux_4334;
{
obj_t aux_4335;
if(INTEGERP(power_1691)){
aux_4335 = power_1691;
}
 else {
bigloo_type_error_location_103___error(symbol2519___hash, string2437___hash, power_1691, string2436___hash, BINT(((long)14475)));
exit( -1 );}
aux_4334 = (long)CINT(aux_4335);
}
aux_4333 = obj__0__2_x_1_138___hash(obj_1690, aux_4334);
}
return BINT(aux_4333);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___hash()
{
{
obj_t symbol1356_1648;
symbol1356_1648 = symbol2520___hash;
{
PUSH_TRACE(symbol1356_1648);
BUNSPEC;
{
obj_t aux1355_1649;
aux1355_1649 = module_initialization_70___error(((long)0), "__HASH");
POP_TRACE();
return aux1355_1649;
}
}
}
}

