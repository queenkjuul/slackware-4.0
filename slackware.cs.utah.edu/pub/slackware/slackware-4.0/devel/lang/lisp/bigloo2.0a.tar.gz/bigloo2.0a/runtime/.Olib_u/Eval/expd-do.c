/*===========================================================================*/
/*   (Eval/expd-do.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t symbol1254___expander_do = BUNSPEC;
static obj_t symbol1253___expander_do = BUNSPEC;
static obj_t symbol1252___expander_do = BUNSPEC;
static obj_t symbol1251___expander_do = BUNSPEC;
static obj_t symbol1250___expander_do = BUNSPEC;
static obj_t symbol1248___expander_do = BUNSPEC;
static obj_t _expand_do_255___expander_do(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t expand_do_31___expander_do(obj_t, obj_t);
extern obj_t module_initialization_70___expander_do(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern long list_length(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_do();
static obj_t require_initialization_114___expander_do = BUNSPEC;
static obj_t cnst_init_137___expander_do();
static obj_t *__cnst;

DEFINE_STRING( string1249___expander_do, string1249___expander_do1256, "Illegal form:", 13 );
DEFINE_STRING( string1247___expander_do, string1247___expander_do1257, "Illegal form", 12 );
DEFINE_STRING( string1246___expander_do, string1246___expander_do1258, "do", 2 );
DEFINE_STRING( string1245___expander_do, string1245___expander_do1259, "do-loop--", 9 );
DEFINE_EXPORT_PROCEDURE( expand_do_env_99___expander_do, _expand_do_255___expander_do1260, _expand_do_255___expander_do, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___expander_do(long checksum_657, char * from_658)
{
if(CBOOL(require_initialization_114___expander_do)){
require_initialization_114___expander_do = BBOOL(((bool_t)0));
cnst_init_137___expander_do();
imported_modules_init_94___expander_do();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_do()
{
symbol1248___expander_do = string_to_symbol("DO");
symbol1250___expander_do = string_to_symbol("LETREC");
symbol1251___expander_do = string_to_symbol("LAMBDA");
symbol1252___expander_do = string_to_symbol("IF");
symbol1253___expander_do = string_to_symbol("BEGIN");
return (symbol1254___expander_do = string_to_symbol("EXP"),
BUNSPEC);
}


/* expand-do */obj_t expand_do_31___expander_do(obj_t exp_1, obj_t e_2)
{
{
obj_t bindings_318;
obj_t end_319;
obj_t command_320;
if(PAIRP(exp_1)){
obj_t cdr_111_186_325;
cdr_111_186_325 = CDR(exp_1);
if(PAIRP(cdr_111_186_325)){
obj_t cdr_116_15_327;
cdr_116_15_327 = CDR(cdr_111_186_325);
if(PAIRP(cdr_116_15_327)){
bindings_318 = CAR(cdr_111_186_325);
end_319 = CAR(cdr_116_15_327);
command_320 = CDR(cdr_116_15_327);
{
obj_t vars_333;
vars_333 = BNIL;
{
obj_t inits_334;
inits_334 = BNIL;
{
obj_t steps_335;
steps_335 = BNIL;
{
obj_t loop_336;
loop_336 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, string1245___expander_do, BEOA);
{
obj_t test_337;
if(PAIRP(end_319)){
test_337 = CAR(end_319);
}
 else {
FAILURE(string1246___expander_do,string1247___expander_do,exp_1);}
{
obj_t ending_338;
{
bool_t test_684;
{
obj_t aux_685;
aux_685 = CDR(end_319);
test_684 = NULLP(aux_685);
}
if(test_684){
obj_t list1098_423;
list1098_423 = MAKE_PAIR(BFALSE, BNIL);
ending_338 = list1098_423;
}
 else {
ending_338 = CDR(end_319);
}
}
{
{
obj_t l1002_340;
l1002_340 = reverse___r4_pairs_and_lists_6_3(bindings_318);
lname1003_341:
if(PAIRP(l1002_340)){
{
obj_t var_init_step_180_344;
var_init_step_180_344 = CAR(l1002_340);
{
bool_t test_693;
{
bool_t test_694;
{
long aux_695;
aux_695 = list_length(var_init_step_180_344);
test_694 = (aux_695>=((long)2));
}
if(test_694){
long aux_698;
aux_698 = list_length(var_init_step_180_344);
test_693 = (aux_698<=((long)3));
}
 else {
test_693 = ((bool_t)0);
}
}
if(test_693){
obj_t var_346;
var_346 = CAR(var_init_step_180_344);
{
obj_t init_347;
{
obj_t aux_702;
aux_702 = CDR(var_init_step_180_344);
init_347 = CAR(aux_702);
}
{
obj_t step_348;
{
bool_t test_705;
{
obj_t aux_706;
{
obj_t aux_707;
aux_707 = CDR(var_init_step_180_344);
aux_706 = CDR(aux_707);
}
test_705 = NULLP(aux_706);
}
if(test_705){
step_348 = var_346;
}
 else {
obj_t aux_711;
{
obj_t aux_712;
aux_712 = CDR(var_init_step_180_344);
aux_711 = CDR(aux_712);
}
step_348 = CAR(aux_711);
}
}
{
{
obj_t obj2_629;
obj2_629 = vars_333;
vars_333 = MAKE_PAIR(var_346, obj2_629);
}
{
obj_t obj2_631;
obj2_631 = steps_335;
steps_335 = MAKE_PAIR(step_348, obj2_631);
}
{
obj_t obj2_633;
obj2_633 = inits_334;
inits_334 = MAKE_PAIR(init_347, obj2_633);
}
}
}
}
}
 else {
FAILURE(symbol1248___expander_do,string1249___expander_do,var_init_step_180_344);}
}
}
{
obj_t l1002_720;
l1002_720 = CDR(l1002_340);
l1002_340 = l1002_720;
goto lname1003_341;
}
}
 else {
((bool_t)1);
}
}
{
obj_t arg1029_360;
{
obj_t arg1030_361;
obj_t arg1031_362;
obj_t arg1032_363;
arg1030_361 = symbol1250___expander_do;
{
obj_t arg1039_369;
{
obj_t arg1043_373;
{
obj_t arg1048_378;
obj_t arg1049_379;
arg1048_378 = symbol1251___expander_do;
{
obj_t arg1056_385;
obj_t arg1057_386;
obj_t arg1058_387;
arg1056_385 = symbol1252___expander_do;
{
obj_t arg1066_394;
obj_t arg1067_395;
arg1066_394 = symbol1253___expander_do;
{
obj_t arg1070_398;
arg1070_398 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1067_395 = append_2_18___r4_pairs_and_lists_6_3(ending_338, arg1070_398);
}
{
obj_t list1068_396;
list1068_396 = MAKE_PAIR(arg1067_395, BNIL);
arg1057_386 = cons__138___r4_pairs_and_lists_6_3(arg1066_394, list1068_396);
}
}
{
obj_t arg1076_401;
obj_t arg1077_402;
arg1076_401 = symbol1253___expander_do;
{
obj_t arg1080_405;
{
obj_t arg1081_406;
{
obj_t arg1085_410;
{
obj_t arg1088_413;
arg1088_413 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1085_410 = append_2_18___r4_pairs_and_lists_6_3(steps_335, arg1088_413);
}
{
obj_t list1086_411;
list1086_411 = MAKE_PAIR(arg1085_410, BNIL);
arg1081_406 = cons__138___r4_pairs_and_lists_6_3(loop_336, list1086_411);
}
}
{
obj_t list1083_408;
list1083_408 = MAKE_PAIR(BNIL, BNIL);
arg1080_405 = cons__138___r4_pairs_and_lists_6_3(arg1081_406, list1083_408);
}
}
arg1077_402 = append_2_18___r4_pairs_and_lists_6_3(command_320, arg1080_405);
}
{
obj_t list1078_403;
list1078_403 = MAKE_PAIR(arg1077_402, BNIL);
arg1058_387 = cons__138___r4_pairs_and_lists_6_3(arg1076_401, list1078_403);
}
}
{
obj_t list1060_389;
{
obj_t arg1061_390;
{
obj_t arg1062_391;
{
obj_t arg1063_392;
arg1063_392 = MAKE_PAIR(BNIL, BNIL);
arg1062_391 = MAKE_PAIR(arg1058_387, arg1063_392);
}
arg1061_390 = MAKE_PAIR(arg1057_386, arg1062_391);
}
list1060_389 = MAKE_PAIR(test_337, arg1061_390);
}
arg1049_379 = cons__138___r4_pairs_and_lists_6_3(arg1056_385, list1060_389);
}
}
{
obj_t list1051_381;
{
obj_t arg1053_382;
{
obj_t arg1054_383;
arg1054_383 = MAKE_PAIR(BNIL, BNIL);
arg1053_382 = MAKE_PAIR(arg1049_379, arg1054_383);
}
list1051_381 = MAKE_PAIR(vars_333, arg1053_382);
}
arg1043_373 = cons__138___r4_pairs_and_lists_6_3(arg1048_378, list1051_381);
}
}
{
obj_t list1045_375;
{
obj_t arg1046_376;
arg1046_376 = MAKE_PAIR(BNIL, BNIL);
list1045_375 = MAKE_PAIR(arg1043_373, arg1046_376);
}
arg1039_369 = cons__138___r4_pairs_and_lists_6_3(loop_336, list1045_375);
}
}
{
obj_t list1041_371;
list1041_371 = MAKE_PAIR(BNIL, BNIL);
arg1031_362 = cons__138___r4_pairs_and_lists_6_3(arg1039_369, list1041_371);
}
}
{
obj_t arg1091_416;
{
obj_t arg1094_419;
arg1094_419 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1091_416 = append_2_18___r4_pairs_and_lists_6_3(inits_334, arg1094_419);
}
{
obj_t list1092_417;
list1092_417 = MAKE_PAIR(arg1091_416, BNIL);
arg1032_363 = cons__138___r4_pairs_and_lists_6_3(loop_336, list1092_417);
}
}
{
obj_t list1034_365;
{
obj_t arg1035_366;
{
obj_t arg1037_367;
arg1037_367 = MAKE_PAIR(BNIL, BNIL);
arg1035_366 = MAKE_PAIR(arg1032_363, arg1037_367);
}
list1034_365 = MAKE_PAIR(arg1031_362, arg1035_366);
}
arg1029_360 = cons__138___r4_pairs_and_lists_6_3(arg1030_361, list1034_365);
}
}
return PROCEDURE_ENTRY(e_2)(e_2, arg1029_360, e_2, BEOA);
}
}
}
}
}
}
}
}
}
 else {
FAILURE(symbol1248___expander_do,string1247___expander_do,symbol1254___expander_do);}
}
 else {
FAILURE(symbol1248___expander_do,string1247___expander_do,symbol1254___expander_do);}
}
 else {
FAILURE(symbol1248___expander_do,string1247___expander_do,symbol1254___expander_do);}
}
}


/* _expand-do */obj_t _expand_do_255___expander_do(obj_t env_654, obj_t exp_655, obj_t e_656)
{
return expand_do_31___expander_do(exp_655, e_656);
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_do()
{
module_initialization_70___error(((long)0), "__EXPANDER_DO");
module_initialization_70___bigloo(((long)0), "__EXPANDER_DO");
module_initialization_70___tvector(((long)0), "__EXPANDER_DO");
module_initialization_70___structure(((long)0), "__EXPANDER_DO");
module_initialization_70___bexit(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_DO");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_DO");
return module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_DO");
}

