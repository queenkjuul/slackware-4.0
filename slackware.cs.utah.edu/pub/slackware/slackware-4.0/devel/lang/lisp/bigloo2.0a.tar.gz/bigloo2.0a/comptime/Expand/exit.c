/*===========================================================================*/
/*   (Expand/exit.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_expand_exit();
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t expand_set_exit_79_expand_exit(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t module_initialization_70_expand_exit(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_expand_expander(long, char *);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70_expand_lambda(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t _expand_jump_exit_199_expand_exit(obj_t, obj_t, obj_t);
static obj_t _expand_set_exit_140_expand_exit(obj_t, obj_t, obj_t);
extern obj_t expand_jump_exit_91_expand_exit(obj_t, obj_t);
static obj_t _expand_unwind_protect_22_expand_exit(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_expand_exit();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_exit();
static obj_t toplevel_init_63_expand_exit();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _expand_bind_exit_56_expand_exit(obj_t, obj_t, obj_t);
extern obj_t expand_unwind_protect_208_expand_exit(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t expand_bind_exit_231_expand_exit(obj_t, obj_t);
static obj_t require_initialization_114_expand_exit = BUNSPEC;
static obj_t cnst_init_137_expand_exit();
static obj_t __cnst[17];

DEFINE_EXPORT_PROCEDURE(expand_bind_exit_env_198_expand_exit, _expand_bind_exit_56_expand_exit1530, _expand_bind_exit_56_expand_exit, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_jump_exit_env_87_expand_exit, _expand_jump_exit_199_expand_exit1531, _expand_jump_exit_199_expand_exit, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_set_exit_env_141_expand_exit, _expand_set_exit_140_expand_exit1532, _expand_set_exit_140_expand_exit, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_unwind_protect_env_54_expand_exit, _expand_unwind_protect_22_expand_exit1533, _expand_unwind_protect_22_expand_exit, 0L, 2);
DEFINE_STRING(string1524_expand_exit, string1524_expand_exit1534, "CDR CAR VAL-FROM-EXIT? IF POP-EXIT! BEGIN UNWIND-UNTIL! LABELS *EXITD-TOP* PUSH-EXIT! LET RES VAL AN_EXITD AN_EXIT SET-EXIT JUMP-EXIT ", 134);
DEFINE_STRING(string1523_expand_exit, string1523_expand_exit1535, "Illegal `unwind-protect' form", 29);
DEFINE_STRING(string1522_expand_exit, string1522_expand_exit1536, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string1521_expand_exit, string1521_expand_exit1537, "cer", 3);
DEFINE_STRING(string1519_expand_exit, string1519_expand_exit1538, "Illegal `set-exit' form", 23);
DEFINE_STRING(string1520_expand_exit, string1520_expand_exit1539, "Illegal `bind-exit' form", 24);
DEFINE_STRING(string1518_expand_exit, string1518_expand_exit1540, "Illegal 'jump-exit' form", 24);


/* module-initialization */ obj_t 
module_initialization_70_expand_exit(long checksum_487, char *from_488)
{
   if (CBOOL(require_initialization_114_expand_exit))
     {
	require_initialization_114_expand_exit = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_exit();
	cnst_init_137_expand_exit();
	imported_modules_init_94_expand_exit();
	method_init_76_expand_exit();
	toplevel_init_63_expand_exit();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_exit()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_EXIT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_EXIT");
   module_initialization_70___reader(((long) 0), "EXPAND_EXIT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_exit()
{
   {
      obj_t cnst_port_138_479;
      cnst_port_138_479 = open_input_string(string1524_expand_exit);
      {
	 long i_480;
	 i_480 = ((long) 16);
       loop_481:
	 {
	    bool_t test1525_482;
	    test1525_482 = (i_480 == ((long) -1));
	    if (test1525_482)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1526_483;
		    {
		       obj_t list1527_484;
		       {
			  obj_t arg1528_485;
			  arg1528_485 = BNIL;
			  list1527_484 = MAKE_PAIR(cnst_port_138_479, arg1528_485);
		       }
		       arg1526_483 = read___reader(list1527_484);
		    }
		    CNST_TABLE_SET(i_480, arg1526_483);
		 }
		 {
		    int aux_486;
		    {
		       long aux_506;
		       aux_506 = (i_480 - ((long) 1));
		       aux_486 = (int) (aux_506);
		    }
		    {
		       long i_509;
		       i_509 = (long) (aux_486);
		       i_480 = i_509;
		       goto loop_481;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_exit()
{
   return BUNSPEC;
}


/* expand-jump-exit */ obj_t 
expand_jump_exit_91_expand_exit(obj_t x_11, obj_t e_12)
{
   {
      obj_t exit_83;
      obj_t value_84;
      if (PAIRP(x_11))
	{
	   obj_t cdr_128_145_89;
	   cdr_128_145_89 = CDR(x_11);
	   if (PAIRP(cdr_128_145_89))
	     {
		exit_83 = CAR(cdr_128_145_89);
		value_84 = CDR(cdr_128_145_89);
		{
		   obj_t new_93;
		   {
		      obj_t arg1145_94;
		      obj_t arg1150_95;
		      obj_t arg1157_96;
		      arg1145_94 = CNST_TABLE_REF(((long) 0));
		      arg1150_95 = PROCEDURE_ENTRY(e_12) (e_12, exit_83, e_12, BEOA);
		      {
			 obj_t arg1187_102;
			 arg1187_102 = normalize_progn_143_tools_progn(value_84);
			 arg1157_96 = PROCEDURE_ENTRY(e_12) (e_12, arg1187_102, e_12, BEOA);
		      }
		      {
			 obj_t list1162_98;
			 {
			    obj_t arg1163_99;
			    {
			       obj_t arg1175_100;
			       arg1175_100 = MAKE_PAIR(BNIL, BNIL);
			       arg1163_99 = MAKE_PAIR(arg1157_96, arg1175_100);
			    }
			    list1162_98 = MAKE_PAIR(arg1150_95, arg1163_99);
			 }
			 new_93 = cons__138___r4_pairs_and_lists_6_3(arg1145_94, list1162_98);
		      }
		   }
		   return replace__160_tools_misc(x_11, new_93);
		}
	     }
	   else
	     {
	      tag_121_151_86:
		FAILURE(BFALSE, string1518_expand_exit, x_11);
	     }
	}
      else
	{
	   goto tag_121_151_86;
	}
   }
}


/* _expand-jump-exit */ obj_t 
_expand_jump_exit_199_expand_exit(obj_t env_466, obj_t x_467, obj_t e_468)
{
   return expand_jump_exit_91_expand_exit(x_467, e_468);
}


/* expand-set-exit */ obj_t 
expand_set_exit_79_expand_exit(obj_t x_13, obj_t e_14)
{
   {
      obj_t exit_103;
      obj_t body_104;
      if (PAIRP(x_13))
	{
	   obj_t cdr_143_124_109;
	   cdr_143_124_109 = CDR(x_13);
	   if (PAIRP(cdr_143_124_109))
	     {
		obj_t car_146_142_111;
		car_146_142_111 = CAR(cdr_143_124_109);
		if (PAIRP(car_146_142_111))
		  {
		     bool_t test_539;
		     {
			obj_t aux_540;
			aux_540 = CDR(car_146_142_111);
			test_539 = (aux_540 == BNIL);
		     }
		     if (test_539)
		       {
			  exit_103 = CAR(car_146_142_111);
			  body_104 = CDR(cdr_143_124_109);
			  {
			     obj_t new_118;
			     {
				obj_t arg1199_119;
				obj_t arg1200_120;
				obj_t arg1201_121;
				arg1199_119 = CNST_TABLE_REF(((long) 1));
				{
				   obj_t list1208_128;
				   list1208_128 = MAKE_PAIR(BNIL, BNIL);
				   arg1200_120 = cons__138___r4_pairs_and_lists_6_3(exit_103, list1208_128);
				}
				{
				   obj_t arg1210_130;
				   arg1210_130 = normalize_progn_143_tools_progn(body_104);
				   arg1201_121 = PROCEDURE_ENTRY(e_14) (e_14, arg1210_130, e_14, BEOA);
				}
				{
				   obj_t list1203_123;
				   {
				      obj_t arg1204_124;
				      {
					 obj_t arg1205_125;
					 arg1205_125 = MAKE_PAIR(BNIL, BNIL);
					 arg1204_124 = MAKE_PAIR(arg1201_121, arg1205_125);
				      }
				      list1203_123 = MAKE_PAIR(arg1200_120, arg1204_124);
				   }
				   new_118 = cons__138___r4_pairs_and_lists_6_3(arg1199_119, list1203_123);
				}
			     }
			     return replace__160_tools_misc(x_13, new_118);
			  }
		       }
		     else
		       {
			tag_136_187_106:
			  FAILURE(BFALSE, string1519_expand_exit, x_13);
		       }
		  }
		else
		  {
		     goto tag_136_187_106;
		  }
	     }
	   else
	     {
		goto tag_136_187_106;
	     }
	}
      else
	{
	   goto tag_136_187_106;
	}
   }
}


/* _expand-set-exit */ obj_t 
_expand_set_exit_140_expand_exit(obj_t env_469, obj_t x_470, obj_t e_471)
{
   return expand_set_exit_79_expand_exit(x_470, e_471);
}


/* expand-bind-exit */ obj_t 
expand_bind_exit_231_expand_exit(obj_t x_15, obj_t e_16)
{
   {
      obj_t exit_131;
      obj_t body_132;
      if (PAIRP(x_15))
	{
	   obj_t cdr_161_14_137;
	   cdr_161_14_137 = CDR(x_15);
	   if (PAIRP(cdr_161_14_137))
	     {
		obj_t car_164_223_139;
		car_164_223_139 = CAR(cdr_161_14_137);
		if (PAIRP(car_164_223_139))
		  {
		     bool_t test_566;
		     {
			obj_t aux_567;
			aux_567 = CDR(car_164_223_139);
			test_566 = (aux_567 == BNIL);
		     }
		     if (test_566)
		       {
			  exit_131 = CAR(car_164_223_139);
			  body_132 = CDR(cdr_161_14_137);
			  {
			     obj_t an_exit_46_146;
			     obj_t an_exitd_79_147;
			     obj_t val_148;
			     obj_t res_149;
			     {
				obj_t arg1353_253;
				arg1353_253 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
				an_exit_46_146 = mark_symbol_non_user__17_ast_ident(arg1353_253);
			     }
			     {
				obj_t arg1356_255;
				arg1356_255 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
				an_exitd_79_147 = mark_symbol_non_user__17_ast_ident(arg1356_255);
			     }
			     {
				obj_t arg1361_257;
				arg1361_257 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
				val_148 = mark_symbol_non_user__17_ast_ident(arg1361_257);
			     }
			     {
				obj_t arg1364_259;
				arg1364_259 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
				res_149 = mark_symbol_non_user__17_ast_ident(arg1364_259);
			     }
			     {
				obj_t new_150;
				{
				   obj_t arg1222_151;
				   {
				      obj_t arg1224_152;
				      obj_t arg1225_153;
				      obj_t arg1226_154;
				      arg1224_152 = CNST_TABLE_REF(((long) 1));
				      {
					 obj_t list1235_161;
					 list1235_161 = MAKE_PAIR(BNIL, BNIL);
					 arg1225_153 = cons__138___r4_pairs_and_lists_6_3(an_exit_46_146, list1235_161);
				      }
				      {
					 obj_t arg1238_163;
					 obj_t arg1241_165;
					 obj_t arg1243_166;
					 arg1238_163 = CNST_TABLE_REF(((long) 6));
					 {
					    obj_t arg1252_173;
					    arg1252_173 = CNST_TABLE_REF(((long) 7));
					    {
					       obj_t list1254_175;
					       {
						  obj_t arg1255_176;
						  {
						     obj_t arg1256_177;
						     arg1256_177 = MAKE_PAIR(BNIL, BNIL);
						     arg1255_176 = MAKE_PAIR(BTRUE, arg1256_177);
						  }
						  list1254_175 = MAKE_PAIR(an_exit_46_146, arg1255_176);
					       }
					       arg1241_165 = cons__138___r4_pairs_and_lists_6_3(arg1252_173, list1254_175);
					    }
					 }
					 {
					    obj_t arg1258_179;
					    obj_t arg1259_180;
					    obj_t arg1260_181;
					    arg1258_179 = CNST_TABLE_REF(((long) 6));
					    {
					       obj_t arg1269_187;
					       {
						  obj_t arg1273_191;
						  arg1273_191 = CNST_TABLE_REF(((long) 8));
						  {
						     obj_t list1275_193;
						     {
							obj_t arg1277_194;
							arg1277_194 = MAKE_PAIR(BNIL, BNIL);
							list1275_193 = MAKE_PAIR(arg1273_191, arg1277_194);
						     }
						     arg1269_187 = cons__138___r4_pairs_and_lists_6_3(an_exitd_79_147, list1275_193);
						  }
					       }
					       {
						  obj_t list1271_189;
						  list1271_189 = MAKE_PAIR(BNIL, BNIL);
						  arg1259_180 = cons__138___r4_pairs_and_lists_6_3(arg1269_187, list1271_189);
					       }
					    }
					    {
					       obj_t arg1281_196;
					       obj_t arg1282_197;
					       obj_t arg1283_198;
					       arg1281_196 = CNST_TABLE_REF(((long) 9));
					       {
						  obj_t arg1290_204;
						  {
						     obj_t arg1295_208;
						     obj_t arg1296_209;
						     {
							obj_t list1303_216;
							list1303_216 = MAKE_PAIR(BNIL, BNIL);
							arg1295_208 = cons__138___r4_pairs_and_lists_6_3(val_148, list1303_216);
						     }
						     {
							obj_t arg1307_218;
							arg1307_218 = CNST_TABLE_REF(((long) 10));
							{
							   obj_t list1309_220;
							   {
							      obj_t arg1310_221;
							      {
								 obj_t arg1311_222;
								 arg1311_222 = MAKE_PAIR(BNIL, BNIL);
								 arg1310_221 = MAKE_PAIR(val_148, arg1311_222);
							      }
							      list1309_220 = MAKE_PAIR(an_exitd_79_147, arg1310_221);
							   }
							   arg1296_209 = cons__138___r4_pairs_and_lists_6_3(arg1307_218, list1309_220);
							}
						     }
						     {
							obj_t list1298_211;
							{
							   obj_t arg1299_212;
							   {
							      obj_t arg1300_213;
							      arg1300_213 = MAKE_PAIR(BNIL, BNIL);
							      arg1299_212 = MAKE_PAIR(arg1296_209, arg1300_213);
							   }
							   list1298_211 = MAKE_PAIR(arg1295_208, arg1299_212);
							}
							arg1290_204 = cons__138___r4_pairs_and_lists_6_3(exit_131, list1298_211);
						     }
						  }
						  {
						     obj_t list1292_206;
						     list1292_206 = MAKE_PAIR(BNIL, BNIL);
						     arg1282_197 = cons__138___r4_pairs_and_lists_6_3(arg1290_204, list1292_206);
						  }
					       }
					       {
						  obj_t arg1315_224;
						  obj_t arg1316_225;
						  obj_t arg1319_226;
						  arg1315_224 = CNST_TABLE_REF(((long) 6));
						  {
						     obj_t arg1328_233;
						     {
							obj_t arg1333_237;
							{
							   obj_t arg1340_242;
							   obj_t arg1342_243;
							   arg1340_242 = CNST_TABLE_REF(((long) 11));
							   {
							      obj_t arg1345_246;
							      arg1345_246 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							      arg1342_243 = append_2_18___r4_pairs_and_lists_6_3(body_132, arg1345_246);
							   }
							   {
							      obj_t list1343_244;
							      list1343_244 = MAKE_PAIR(arg1342_243, BNIL);
							      arg1333_237 = cons__138___r4_pairs_and_lists_6_3(arg1340_242, list1343_244);
							   }
							}
							{
							   obj_t list1335_239;
							   {
							      obj_t arg1337_240;
							      arg1337_240 = MAKE_PAIR(BNIL, BNIL);
							      list1335_239 = MAKE_PAIR(arg1333_237, arg1337_240);
							   }
							   arg1328_233 = cons__138___r4_pairs_and_lists_6_3(res_149, list1335_239);
							}
						     }
						     {
							obj_t list1331_235;
							list1331_235 = MAKE_PAIR(BNIL, BNIL);
							arg1316_225 = cons__138___r4_pairs_and_lists_6_3(arg1328_233, list1331_235);
						     }
						  }
						  {
						     obj_t arg1349_249;
						     arg1349_249 = CNST_TABLE_REF(((long) 12));
						     {
							obj_t list1351_251;
							list1351_251 = MAKE_PAIR(BNIL, BNIL);
							arg1319_226 = cons__138___r4_pairs_and_lists_6_3(arg1349_249, list1351_251);
						     }
						  }
						  {
						     obj_t list1322_228;
						     {
							obj_t arg1323_229;
							{
							   obj_t arg1324_230;
							   {
							      obj_t arg1325_231;
							      arg1325_231 = MAKE_PAIR(BNIL, BNIL);
							      arg1324_230 = MAKE_PAIR(res_149, arg1325_231);
							   }
							   arg1323_229 = MAKE_PAIR(arg1319_226, arg1324_230);
							}
							list1322_228 = MAKE_PAIR(arg1316_225, arg1323_229);
						     }
						     arg1283_198 = cons__138___r4_pairs_and_lists_6_3(arg1315_224, list1322_228);
						  }
					       }
					       {
						  obj_t list1285_200;
						  {
						     obj_t arg1286_201;
						     {
							obj_t arg1287_202;
							arg1287_202 = MAKE_PAIR(BNIL, BNIL);
							arg1286_201 = MAKE_PAIR(arg1283_198, arg1287_202);
						     }
						     list1285_200 = MAKE_PAIR(arg1282_197, arg1286_201);
						  }
						  arg1260_181 = cons__138___r4_pairs_and_lists_6_3(arg1281_196, list1285_200);
					       }
					    }
					    {
					       obj_t list1263_183;
					       {
						  obj_t arg1265_184;
						  {
						     obj_t arg1267_185;
						     arg1267_185 = MAKE_PAIR(BNIL, BNIL);
						     arg1265_184 = MAKE_PAIR(arg1260_181, arg1267_185);
						  }
						  list1263_183 = MAKE_PAIR(arg1259_180, arg1265_184);
					       }
					       arg1243_166 = cons__138___r4_pairs_and_lists_6_3(arg1258_179, list1263_183);
					    }
					 }
					 {
					    obj_t list1245_168;
					    {
					       obj_t arg1247_169;
					       {
						  obj_t arg1248_170;
						  {
						     obj_t arg1250_171;
						     arg1250_171 = MAKE_PAIR(BNIL, BNIL);
						     arg1248_170 = MAKE_PAIR(arg1243_166, arg1250_171);
						  }
						  arg1247_169 = MAKE_PAIR(arg1241_165, arg1248_170);
					       }
					       list1245_168 = MAKE_PAIR(BNIL, arg1247_169);
					    }
					    arg1226_154 = cons__138___r4_pairs_and_lists_6_3(arg1238_163, list1245_168);
					 }
				      }
				      {
					 obj_t list1229_156;
					 {
					    obj_t arg1231_157;
					    {
					       obj_t arg1232_158;
					       arg1232_158 = MAKE_PAIR(BNIL, BNIL);
					       arg1231_157 = MAKE_PAIR(arg1226_154, arg1232_158);
					    }
					    list1229_156 = MAKE_PAIR(arg1225_153, arg1231_157);
					 }
					 arg1222_151 = cons__138___r4_pairs_and_lists_6_3(arg1224_152, list1229_156);
				      }
				   }
				   new_150 = PROCEDURE_ENTRY(e_16) (e_16, arg1222_151, e_16, BEOA);
				}
				return replace__160_tools_misc(x_15, new_150);
			     }
			  }
		       }
		     else
		       {
			tag_154_0_134:
			  FAILURE(BFALSE, string1520_expand_exit, x_15);
		       }
		  }
		else
		  {
		     goto tag_154_0_134;
		  }
	     }
	   else
	     {
		goto tag_154_0_134;
	     }
	}
      else
	{
	   goto tag_154_0_134;
	}
   }
}


/* _expand-bind-exit */ obj_t 
_expand_bind_exit_56_expand_exit(obj_t env_472, obj_t x_473, obj_t e_474)
{
   return expand_bind_exit_231_expand_exit(x_473, e_474);
}


/* expand-unwind-protect */ obj_t 
expand_unwind_protect_208_expand_exit(obj_t x_17, obj_t e_18)
{
   {
      obj_t exp_261;
      obj_t cleanup_262;
      if (PAIRP(x_17))
	{
	   obj_t cdr_179_79_267;
	   cdr_179_79_267 = CDR(x_17);
	   if (PAIRP(cdr_179_79_267))
	     {
		obj_t cdr_183_92_269;
		cdr_183_92_269 = CDR(cdr_179_79_267);
		if (PAIRP(cdr_183_92_269))
		  {
		     exp_261 = CAR(cdr_179_79_267);
		     cleanup_262 = cdr_183_92_269;
		     {
			obj_t val_272;
			{
			   obj_t arg1513_386;
			   arg1513_386 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
			   val_272 = mark_symbol_non_user__17_ast_ident(arg1513_386);
			}
			{
			   obj_t an_exit_46_273;
			   {
			      obj_t arg1510_384;
			      arg1510_384 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
			      an_exit_46_273 = mark_symbol_non_user__17_ast_ident(arg1510_384);
			   }
			   {
			      obj_t valbis_274;
			      {
				 obj_t arg1505_382;
				 arg1505_382 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
				 valbis_274 = mark_symbol_non_user__17_ast_ident(arg1505_382);
			      }
			      {
				 obj_t eexp_275;
				 eexp_275 = PROCEDURE_ENTRY(e_18) (e_18, exp_261, e_18, BEOA);
				 {
				    obj_t aux_276;
				    {
				       obj_t arg1481_361;
				       obj_t arg1483_362;
				       obj_t arg1484_363;
				       arg1481_361 = CNST_TABLE_REF(((long) 6));
				       {
					  obj_t arg1491_370;
					  {
					     obj_t list1498_375;
					     {
						obj_t arg1499_376;
						arg1499_376 = MAKE_PAIR(BNIL, BNIL);
						list1498_375 = MAKE_PAIR(eexp_275, arg1499_376);
					     }
					     arg1491_370 = cons__138___r4_pairs_and_lists_6_3(valbis_274, list1498_375);
					  }
					  {
					     obj_t list1495_372;
					     list1495_372 = MAKE_PAIR(BNIL, BNIL);
					     arg1483_362 = cons__138___r4_pairs_and_lists_6_3(arg1491_370, list1495_372);
					  }
				       }
				       {
					  obj_t arg1501_378;
					  arg1501_378 = CNST_TABLE_REF(((long) 12));
					  {
					     obj_t list1503_380;
					     list1503_380 = MAKE_PAIR(BNIL, BNIL);
					     arg1484_363 = cons__138___r4_pairs_and_lists_6_3(arg1501_378, list1503_380);
					  }
				       }
				       {
					  obj_t list1486_365;
					  {
					     obj_t arg1487_366;
					     {
						obj_t arg1488_367;
						{
						   obj_t arg1489_368;
						   arg1489_368 = MAKE_PAIR(BNIL, BNIL);
						   arg1488_367 = MAKE_PAIR(valbis_274, arg1489_368);
						}
						arg1487_366 = MAKE_PAIR(arg1484_363, arg1488_367);
					     }
					     list1486_365 = MAKE_PAIR(arg1483_362, arg1487_366);
					  }
					  aux_276 = cons__138___r4_pairs_and_lists_6_3(arg1481_361, list1486_365);
				       }
				    }
				    {
				       obj_t eaux_277;
				       {
					  bool_t test1477_357;
					  test1477_357 = EXTENDED_PAIRP(eexp_275);
					  if (test1477_357)
					    {
					       obj_t arg1478_358;
					       obj_t arg1479_359;
					       obj_t arg1480_360;
					       arg1478_358 = CAR(aux_276);
					       arg1479_359 = CDR(aux_276);
					       {
						  bool_t test1137_455;
						  test1137_455 = EXTENDED_PAIRP(eexp_275);
						  if (test1137_455)
						    {
						       arg1480_360 = CER(eexp_275);
						    }
						  else
						    {
						       FAILURE(string1521_expand_exit, string1522_expand_exit, eexp_275);
						    }
					       }
					       eaux_277 = MAKE_EXTENDED_PAIR(arg1478_358, arg1479_359, arg1480_360);
					    }
					  else
					    {
					       eaux_277 = aux_276;
					    }
				       }
				       {
					  {
					     obj_t new_278;
					     {
						obj_t arg1370_279;
						obj_t arg1372_280;
						obj_t arg1373_281;
						obj_t arg1375_282;
						arg1370_279 = CNST_TABLE_REF(((long) 6));
						{
						   obj_t arg1387_289;
						   {
						      obj_t arg1391_293;
						      {
							 obj_t arg1397_298;
							 obj_t arg1398_299;
							 obj_t arg1399_300;
							 arg1397_298 = CNST_TABLE_REF(((long) 1));
							 {
							    obj_t list1409_307;
							    list1409_307 = MAKE_PAIR(BNIL, BNIL);
							    arg1398_299 = cons__138___r4_pairs_and_lists_6_3(an_exit_46_273, list1409_307);
							 }
							 {
							    obj_t arg1411_309;
							    obj_t arg1414_311;
							    arg1411_309 = CNST_TABLE_REF(((long) 6));
							    {
							       obj_t arg1423_318;
							       arg1423_318 = CNST_TABLE_REF(((long) 7));
							       {
								  obj_t list1427_320;
								  {
								     obj_t arg1428_321;
								     {
									obj_t arg1431_322;
									arg1431_322 = MAKE_PAIR(BNIL, BNIL);
									arg1428_321 = MAKE_PAIR(BFALSE, arg1431_322);
								     }
								     list1427_320 = MAKE_PAIR(an_exit_46_273, arg1428_321);
								  }
								  arg1414_311 = cons__138___r4_pairs_and_lists_6_3(arg1423_318, list1427_320);
							       }
							    }
							    {
							       obj_t list1416_313;
							       {
								  obj_t arg1417_314;
								  {
								     obj_t arg1418_315;
								     {
									obj_t arg1419_316;
									arg1419_316 = MAKE_PAIR(BNIL, BNIL);
									arg1418_315 = MAKE_PAIR(aux_276, arg1419_316);
								     }
								     arg1417_314 = MAKE_PAIR(arg1414_311, arg1418_315);
								  }
								  list1416_313 = MAKE_PAIR(BNIL, arg1417_314);
							       }
							       arg1399_300 = cons__138___r4_pairs_and_lists_6_3(arg1411_309, list1416_313);
							    }
							 }
							 {
							    obj_t list1402_302;
							    {
							       obj_t arg1403_303;
							       {
								  obj_t arg1405_304;
								  arg1405_304 = MAKE_PAIR(BNIL, BNIL);
								  arg1403_303 = MAKE_PAIR(arg1399_300, arg1405_304);
							       }
							       list1402_302 = MAKE_PAIR(arg1398_299, arg1403_303);
							    }
							    arg1391_293 = cons__138___r4_pairs_and_lists_6_3(arg1397_298, list1402_302);
							 }
						      }
						      {
							 obj_t list1393_295;
							 {
							    obj_t arg1395_296;
							    arg1395_296 = MAKE_PAIR(BNIL, BNIL);
							    list1393_295 = MAKE_PAIR(arg1391_293, arg1395_296);
							 }
							 arg1387_289 = cons__138___r4_pairs_and_lists_6_3(val_272, list1393_295);
						      }
						   }
						   {
						      obj_t list1389_291;
						      list1389_291 = MAKE_PAIR(BNIL, BNIL);
						      arg1372_280 = cons__138___r4_pairs_and_lists_6_3(arg1387_289, list1389_291);
						   }
						}
						{
						   obj_t arg1433_324;
						   arg1433_324 = normalize_progn_143_tools_progn(cleanup_262);
						   arg1373_281 = PROCEDURE_ENTRY(e_18) (e_18, arg1433_324, e_18, BEOA);
						}
						{
						   obj_t arg1436_325;
						   obj_t arg1437_326;
						   obj_t arg1438_327;
						   arg1436_325 = CNST_TABLE_REF(((long) 13));
						   {
						      obj_t arg1449_334;
						      arg1449_334 = CNST_TABLE_REF(((long) 14));
						      {
							 obj_t list1451_336;
							 {
							    obj_t arg1453_337;
							    arg1453_337 = MAKE_PAIR(BNIL, BNIL);
							    list1451_336 = MAKE_PAIR(val_272, arg1453_337);
							 }
							 arg1437_326 = cons__138___r4_pairs_and_lists_6_3(arg1449_334, list1451_336);
						      }
						   }
						   {
						      obj_t arg1455_339;
						      obj_t arg1456_340;
						      obj_t arg1458_341;
						      arg1455_339 = CNST_TABLE_REF(((long) 10));
						      {
							 obj_t arg1466_347;
							 arg1466_347 = CNST_TABLE_REF(((long) 15));
							 {
							    obj_t list1468_349;
							    {
							       obj_t arg1469_350;
							       arg1469_350 = MAKE_PAIR(BNIL, BNIL);
							       list1468_349 = MAKE_PAIR(val_272, arg1469_350);
							    }
							    arg1456_340 = cons__138___r4_pairs_and_lists_6_3(arg1466_347, list1468_349);
							 }
						      }
						      {
							 obj_t arg1471_352;
							 arg1471_352 = CNST_TABLE_REF(((long) 16));
							 {
							    obj_t list1474_354;
							    {
							       obj_t arg1475_355;
							       arg1475_355 = MAKE_PAIR(BNIL, BNIL);
							       list1474_354 = MAKE_PAIR(val_272, arg1475_355);
							    }
							    arg1458_341 = cons__138___r4_pairs_and_lists_6_3(arg1471_352, list1474_354);
							 }
						      }
						      {
							 obj_t list1461_343;
							 {
							    obj_t arg1463_344;
							    {
							       obj_t arg1464_345;
							       arg1464_345 = MAKE_PAIR(BNIL, BNIL);
							       arg1463_344 = MAKE_PAIR(arg1458_341, arg1464_345);
							    }
							    list1461_343 = MAKE_PAIR(arg1456_340, arg1463_344);
							 }
							 arg1438_327 = cons__138___r4_pairs_and_lists_6_3(arg1455_339, list1461_343);
						      }
						   }
						   {
						      obj_t list1441_329;
						      {
							 obj_t arg1443_330;
							 {
							    obj_t arg1444_331;
							    {
							       obj_t arg1446_332;
							       arg1446_332 = MAKE_PAIR(BNIL, BNIL);
							       arg1444_331 = MAKE_PAIR(val_272, arg1446_332);
							    }
							    arg1443_330 = MAKE_PAIR(arg1438_327, arg1444_331);
							 }
							 list1441_329 = MAKE_PAIR(arg1437_326, arg1443_330);
						      }
						      arg1375_282 = cons__138___r4_pairs_and_lists_6_3(arg1436_325, list1441_329);
						   }
						}
						{
						   obj_t list1379_284;
						   {
						      obj_t arg1381_285;
						      {
							 obj_t arg1383_286;
							 {
							    obj_t arg1384_287;
							    arg1384_287 = MAKE_PAIR(BNIL, BNIL);
							    arg1383_286 = MAKE_PAIR(arg1375_282, arg1384_287);
							 }
							 arg1381_285 = MAKE_PAIR(arg1373_281, arg1383_286);
						      }
						      list1379_284 = MAKE_PAIR(arg1372_280, arg1381_285);
						   }
						   new_278 = cons__138___r4_pairs_and_lists_6_3(arg1370_279, list1379_284);
						}
					     }
					     return replace__160_tools_misc(x_17, new_278);
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
		else
		  {
		   tag_172_8_264:
		     FAILURE(BFALSE, string1523_expand_exit, x_17);
		  }
	     }
	   else
	     {
		goto tag_172_8_264;
	     }
	}
      else
	{
	   goto tag_172_8_264;
	}
   }
}


/* _expand-unwind-protect */ obj_t 
_expand_unwind_protect_22_expand_exit(obj_t env_475, obj_t x_476, obj_t e_477)
{
   return expand_unwind_protect_208_expand_exit(x_476, e_477);
}


/* method-init */ obj_t 
method_init_76_expand_exit()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_exit()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_EXIT");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_EXIT");
   module_initialization_70_tools_args(((long) 0), "EXPAND_EXIT");
   module_initialization_70_tools_speek(((long) 0), "EXPAND_EXIT");
   module_initialization_70_tools_misc(((long) 0), "EXPAND_EXIT");
   module_initialization_70_expand_expander(((long) 0), "EXPAND_EXIT");
   module_initialization_70_expand_eps(((long) 0), "EXPAND_EXIT");
   module_initialization_70_expand_lambda(((long) 0), "EXPAND_EXIT");
   module_initialization_70_engine_param(((long) 0), "EXPAND_EXIT");
   module_initialization_70_type_type(((long) 0), "EXPAND_EXIT");
   return module_initialization_70_ast_ident(((long) 0), "EXPAND_EXIT");
}
