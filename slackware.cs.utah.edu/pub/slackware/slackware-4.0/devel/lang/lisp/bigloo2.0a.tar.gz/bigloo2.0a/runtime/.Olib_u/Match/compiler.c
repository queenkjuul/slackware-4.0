/*===========================================================================*/
/*   (Match/compiler.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern bool_t bigloo_strcmp(obj_t, obj_t);
extern obj_t pattern_plus_250___match_descriptions(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t compile__2081_179___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t pcompile___match_compiler(obj_t);
static obj_t m_init_175___match_compiler(obj_t);
extern obj_t pattern_cdr_48___match_descriptions(obj_t);
extern obj_t vector_plus_240___match_descriptions(obj_t, obj_t, obj_t);
extern obj_t pattern_car_218___match_descriptions(obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___match_compiler();
extern obj_t extend_vector_160___match_descriptions(obj_t, obj_t, obj_t);
static obj_t lambda1698___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1707___match_compiler(obj_t, obj_t);
static obj_t extend__2084_62___match_compiler(obj_t, obj_t);
static obj_t extend__2082_96___match_compiler(obj_t, obj_t);
extern obj_t compatible__222___match_descriptions(obj_t, obj_t);
static obj_t lambda1618___match_compiler(obj_t, obj_t);
static obj_t lambda1596___match_compiler(obj_t, obj_t);
extern obj_t pattern_minus_154___match_descriptions(obj_t, obj_t);
static obj_t lambda1561___match_compiler(obj_t, obj_t);
static obj_t _m_init_247___match_compiler(obj_t, obj_t);
static obj_t compile_vector_begin_230___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t more_precise__220___match_descriptions(obj_t, obj_t);
static obj_t integers_2083___match_compiler(obj_t, obj_t);
extern obj_t atom__231___match_s2cfun(obj_t);
static obj_t compile_times_196___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t instanciate_try_249___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t arg1659___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1636___match_compiler(obj_t, obj_t);
static obj_t arg1575___match_compiler(obj_t, obj_t);
static obj_t arg1573___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t extend_alist_122___match_compiler(obj_t, obj_t, obj_t);
static obj_t _z_init_73___match_compiler(obj_t, obj_t);
extern obj_t pattern_variables_45___match_descriptions(obj_t);
static obj_t arg1417___match_compiler(obj_t, obj_t);
static obj_t arg1370___match_compiler(obj_t, obj_t);
static obj_t arg1369___match_compiler(obj_t, obj_t, obj_t, obj_t);
static bool_t isdirectcall__235___match_compiler(obj_t);
static obj_t arg1308___match_compiler(obj_t, obj_t);
static obj_t arg1307___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1302___match_compiler(obj_t, obj_t);
static obj_t arg1301___match_compiler(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___match_compiler(long, char *);
extern obj_t module_initialization_70___match_descriptions(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___match_s2cfun(long, char *);
extern obj_t c_substring(obj_t, long, long);
static obj_t d_init_76___match_compiler = BUNSPEC;
static obj_t arg1193___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1183___match_compiler(obj_t, obj_t);
static obj_t arg1182___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1167___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1164___match_compiler(obj_t, obj_t);
static obj_t arg1163___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1144___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1141___match_compiler(obj_t, obj_t);
static obj_t arg1140___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1136___match_compiler(obj_t, obj_t);
static obj_t arg1135___match_compiler(obj_t, obj_t, obj_t, obj_t);
extern obj_t jim_gensym_58___match_s2cfun;
static obj_t look_for_descr_2080_128___match_compiler(obj_t, obj_t);
extern long list_length(obj_t);
extern bool_t _2___235___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__79___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t compile_or_167___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2137___match_compiler = BUNSPEC;
static obj_t symbol2136___match_compiler = BUNSPEC;
static obj_t symbol2134___match_compiler = BUNSPEC;
static obj_t symbol2132___match_compiler = BUNSPEC;
static obj_t symbol2129___match_compiler = BUNSPEC;
static obj_t symbol2128___match_compiler = BUNSPEC;
static obj_t symbol2127___match_compiler = BUNSPEC;
static obj_t symbol2124___match_compiler = BUNSPEC;
static obj_t symbol2121___match_compiler = BUNSPEC;
static obj_t symbol2119___match_compiler = BUNSPEC;
static obj_t symbol2120___match_compiler = BUNSPEC;
static obj_t symbol2116___match_compiler = BUNSPEC;
static obj_t symbol2115___match_compiler = BUNSPEC;
static obj_t symbol2113___match_compiler = BUNSPEC;
static obj_t symbol2111___match_compiler = BUNSPEC;
static obj_t build_let_227___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2099___match_compiler = BUNSPEC;
static obj_t symbol2109___match_compiler = BUNSPEC;
static obj_t compile_vector_cons_109___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2098___match_compiler = BUNSPEC;
static obj_t symbol2108___match_compiler = BUNSPEC;
static obj_t symbol2097___match_compiler = BUNSPEC;
static obj_t symbol2107___match_compiler = BUNSPEC;
static obj_t symbol2096___match_compiler = BUNSPEC;
static obj_t symbol2106___match_compiler = BUNSPEC;
static obj_t symbol2095___match_compiler = BUNSPEC;
static obj_t symbol2105___match_compiler = BUNSPEC;
static obj_t symbol2094___match_compiler = BUNSPEC;
static obj_t symbol2104___match_compiler = BUNSPEC;
static obj_t symbol2093___match_compiler = BUNSPEC;
static obj_t symbol2092___match_compiler = BUNSPEC;
static obj_t symbol2091___match_compiler = BUNSPEC;
static obj_t compile___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2089___match_compiler = BUNSPEC;
static obj_t symbol2090___match_compiler = BUNSPEC;
static obj_t symbol2100___match_compiler = BUNSPEC;
static obj_t symbol2088___match_compiler = BUNSPEC;
static obj_t symbol2086___match_compiler = BUNSPEC;
extern bool_t eqv__112___r4_equivalence_6_2(obj_t, obj_t);
static obj_t list2131___match_compiler = BUNSPEC;
static obj_t list2130___match_compiler = BUNSPEC;
static obj_t imported_modules_init_94___match_compiler();
static obj_t compile_var_237___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t list2085___match_compiler = BUNSPEC;
static obj_t compile_struct_pat_210___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t build_if_78___match_compiler(obj_t, obj_t, obj_t);
static obj_t succes_cons_170___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114___match_compiler = BUNSPEC;
static obj_t r_init_249___match_compiler = BUNSPEC;
static obj_t unfold___match_compiler(obj_t, obj_t, obj_t);
static obj_t _pcompile___match_compiler(obj_t, obj_t);
static obj_t _k_init_136___match_compiler(obj_t, obj_t, obj_t, obj_t);
static obj_t compile_cons_24___match_compiler(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137___match_compiler();
static obj_t count_occurrences_123___match_compiler(obj_t, obj_t, long);
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE( k_init_env_85___match_compiler, _k_init_136___match_compiler2139, _k_init_136___match_compiler, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( pcompile_env_25___match_compiler, _pcompile___match_compiler2140, _pcompile___match_compiler, 0L, 1 );
DEFINE_STRING( string2135___match_compiler, string2135___match_compiler2141, "No current repetition named", 27 );
DEFINE_STRING( string2133___match_compiler, string2133___match_compiler2142, "?", 1 );
DEFINE_STRING( string2126___match_compiler, string2126___match_compiler2143, "TRY-", 4 );
DEFINE_STRING( string2125___match_compiler, string2125___match_compiler2144, "G-", 2 );
DEFINE_STRING( string2123___match_compiler, string2123___match_compiler2145, "CDR-", 4 );
DEFINE_STRING( string2122___match_compiler, string2122___match_compiler2146, "CAR-", 4 );
DEFINE_STRING( string2118___match_compiler, string2118___match_compiler2147, "TAG", 3 );
DEFINE_STRING( string2117___match_compiler, string2117___match_compiler2148, "KAP", 3 );
DEFINE_STRING( string2114___match_compiler, string2114___match_compiler2149, "KAP-", 4 );
DEFINE_STRING( string2112___match_compiler, string2112___match_compiler2150, "Unrecognized pattern", 20 );
DEFINE_STRING( string2110___match_compiler, string2110___match_compiler2151, "Not yet allowed", 15 );
DEFINE_STRING( string2103___match_compiler, string2103___match_compiler2152, " *** ", 5 );
DEFINE_STRING( string2102___match_compiler, string2102___match_compiler2153, "Incorrect pattern: ", 19 );
DEFINE_STRING( string2101___match_compiler, string2101___match_compiler2154, "Tree not yet allowed", 20 );
DEFINE_STRING( string2087___match_compiler, string2087___match_compiler2155, "E-", 2 );
DEFINE_STATIC_PROCEDURE( z_init_env_105___match_compiler, _z_init_73___match_compiler2156, _z_init_73___match_compiler, 0L, 1 );
DEFINE_STATIC_PROCEDURE( m_init_env_176___match_compiler, _m_init_247___match_compiler2157, _m_init_247___match_compiler, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___match_compiler(long checksum_2908, char * from_2909)
{
if(CBOOL(require_initialization_114___match_compiler)){
require_initialization_114___match_compiler = BBOOL(((bool_t)0));
cnst_init_137___match_compiler();
imported_modules_init_94___match_compiler();
toplevel_init_63___match_compiler();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___match_compiler()
{
symbol2086___match_compiler = string_to_symbol("ANY");
list2085___match_compiler = MAKE_PAIR(symbol2086___match_compiler, BNIL);
symbol2088___match_compiler = string_to_symbol("LAMBDA");
symbol2089___match_compiler = string_to_symbol("CHECK");
symbol2090___match_compiler = string_to_symbol("IF");
symbol2091___match_compiler = string_to_symbol("QUOTE");
symbol2092___match_compiler = string_to_symbol("EQ?");
symbol2093___match_compiler = string_to_symbol("VAR");
symbol2094___match_compiler = string_to_symbol("NOT");
symbol2095___match_compiler = string_to_symbol("OR");
symbol2096___match_compiler = string_to_symbol("TAGGED-OR");
symbol2097___match_compiler = string_to_symbol("AND");
symbol2098___match_compiler = string_to_symbol("CONS");
symbol2099___match_compiler = string_to_symbol("TIMES");
symbol2100___match_compiler = string_to_symbol("TREE");
symbol2104___match_compiler = string_to_symbol("HOLE");
symbol2105___match_compiler = string_to_symbol("VECTOR-BEGIN");
symbol2106___match_compiler = string_to_symbol("VECTOR-END");
symbol2107___match_compiler = string_to_symbol("VECTOR-ANY");
symbol2108___match_compiler = string_to_symbol("VECTOR-CONS");
symbol2109___match_compiler = string_to_symbol("VECTOR-TIMES");
symbol2111___match_compiler = string_to_symbol("STRUCT-PAT");
symbol2113___match_compiler = string_to_symbol("VECTOR-LENGTH");
symbol2115___match_compiler = string_to_symbol("LABELS");
symbol2116___match_compiler = string_to_symbol("DUMMY");
symbol2119___match_compiler = string_to_symbol("UNBOUND");
symbol2120___match_compiler = string_to_symbol("LET");
symbol2121___match_compiler = string_to_symbol("PAIR?");
symbol2124___match_compiler = string_to_symbol("LETREC");
symbol2127___match_compiler = string_to_symbol("VECTOR");
symbol2128___match_compiler = string_to_symbol(">=");
symbol2129___match_compiler = string_to_symbol("VECTOR?");
list2131___match_compiler = MAKE_PAIR(symbol2127___match_compiler, BNIL);
{
obj_t aux_2949;
aux_2949 = MAKE_PAIR(list2131___match_compiler, BNIL);
list2130___match_compiler = MAKE_PAIR(symbol2094___match_compiler, aux_2949);
}
symbol2132___match_compiler = string_to_symbol("VECTOR-REF");
symbol2134___match_compiler = string_to_symbol("STRUCT-REF");
symbol2136___match_compiler = string_to_symbol("CAR");
return (symbol2137___match_compiler = string_to_symbol("CDR"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___match_compiler()
{
d_init_76___match_compiler = list2085___match_compiler;
return (r_init_249___match_compiler = BNIL,
BUNSPEC);
}


/* pcompile */obj_t pcompile___match_compiler(obj_t f_1)
{
{
obj_t s_536;
s_536 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2087___match_compiler, BEOA);
{
obj_t arg1015_537;
obj_t arg1016_538;
obj_t arg1017_539;
arg1015_537 = symbol2088___match_compiler;
{
obj_t list1024_546;
list1024_546 = MAKE_PAIR(BNIL, BNIL);
arg1016_538 = cons__138___r4_pairs_and_lists_6_3(s_536, list1024_546);
}
arg1017_539 = compile___match_compiler(f_1, s_536, BNIL, m_init_env_176___match_compiler, k_init_env_85___match_compiler, z_init_env_105___match_compiler, d_init_76___match_compiler);
{
obj_t list1019_541;
{
obj_t arg1020_542;
{
obj_t arg1021_543;
arg1021_543 = MAKE_PAIR(BNIL, BNIL);
arg1020_542 = MAKE_PAIR(arg1017_539, arg1021_543);
}
list1019_541 = MAKE_PAIR(arg1016_538, arg1020_542);
}
return cons__138___r4_pairs_and_lists_6_3(arg1015_537, list1019_541);
}
}
}
}


/* _pcompile */obj_t _pcompile___match_compiler(obj_t env_2641, obj_t f_2642)
{
return pcompile___match_compiler(f_2642);
}


/* compile */obj_t compile___match_compiler(obj_t f_2, obj_t e_3, obj_t r_4, obj_t m_5, obj_t k_6, obj_t z_7, obj_t d_8)
{
compile___match_compiler:
{
bool_t test1026_548;
{
obj_t aux_2966;
aux_2966 = more_precise__220___match_descriptions(d_8, f_2);
test1026_548 = CBOOL(aux_2966);
}
if(test1026_548){
return PROCEDURE_ENTRY(k_6)(k_6, r_4, z_7, d_8, BEOA);
}
 else {
bool_t test1027_549;
{
obj_t aux_2972;
aux_2972 = compatible__222___match_descriptions(d_8, f_2);
test1027_549 = CBOOL(aux_2972);
}
if(test1027_549){
{
obj_t case_value_58_550;
case_value_58_550 = CAR(f_2);
if((case_value_58_550==symbol2086___match_compiler)){
return PROCEDURE_ENTRY(k_6)(k_6, r_4, z_7, d_8, BEOA);
}
 else {
if((case_value_58_550==symbol2089___match_compiler)){
obj_t arg1030_553;
{
obj_t aux_2983;
aux_2983 = CDR(f_2);
arg1030_553 = CAR(aux_2983);
}
{
obj_t arg1097_1601;
obj_t arg1098_1602;
obj_t arg1099_1603;
obj_t arg1100_1604;
arg1097_1601 = symbol2090___match_compiler;
{
obj_t list1108_1607;
{
obj_t arg1109_1608;
arg1109_1608 = MAKE_PAIR(BNIL, BNIL);
list1108_1607 = MAKE_PAIR(e_3, arg1109_1608);
}
arg1098_1602 = cons__138___r4_pairs_and_lists_6_3(arg1030_553, list1108_1607);
}
arg1099_1603 = PROCEDURE_ENTRY(k_6)(k_6, r_4, z_7, d_8, BEOA);
arg1100_1604 = PROCEDURE_ENTRY(z_7)(z_7, d_8, BEOA);
{
obj_t list1102_1610;
{
obj_t arg1103_1611;
{
obj_t arg1104_1612;
{
obj_t arg1105_1613;
arg1105_1613 = MAKE_PAIR(BNIL, BNIL);
arg1104_1612 = MAKE_PAIR(arg1100_1604, arg1105_1613);
}
arg1103_1611 = MAKE_PAIR(arg1099_1603, arg1104_1612);
}
list1102_1610 = MAKE_PAIR(arg1098_1602, arg1103_1611);
}
return cons__138___r4_pairs_and_lists_6_3(arg1097_1601, list1102_1610);
}
}
}
 else {
if((case_value_58_550==symbol2091___match_compiler)){
obj_t arg1111_1624;
obj_t arg1112_1625;
obj_t arg1113_1626;
{
obj_t arg1114_1627;
obj_t arg1115_1628;
arg1114_1627 = symbol2092___match_compiler;
{
obj_t arg1121_1630;
obj_t arg1122_1631;
arg1121_1630 = symbol2091___match_compiler;
{
obj_t aux_3000;
aux_3000 = CDR(f_2);
arg1122_1631 = CAR(aux_3000);
}
{
obj_t list1124_1633;
{
obj_t arg1125_1634;
arg1125_1634 = MAKE_PAIR(BNIL, BNIL);
list1124_1633 = MAKE_PAIR(arg1122_1631, arg1125_1634);
}
arg1115_1628 = cons__138___r4_pairs_and_lists_6_3(arg1121_1630, list1124_1633);
}
}
{
obj_t list1117_1636;
{
obj_t arg1118_1637;
{
obj_t arg1119_1638;
arg1119_1638 = MAKE_PAIR(BNIL, BNIL);
arg1118_1637 = MAKE_PAIR(arg1115_1628, arg1119_1638);
}
list1117_1636 = MAKE_PAIR(e_3, arg1118_1637);
}
arg1111_1624 = cons__138___r4_pairs_and_lists_6_3(arg1114_1627, list1117_1636);
}
}
{
obj_t arg1127_1640;
{
obj_t arg1128_1641;
obj_t arg1129_1642;
arg1128_1641 = symbol2091___match_compiler;
{
obj_t aux_3010;
aux_3010 = CDR(f_2);
arg1129_1642 = CAR(aux_3010);
}
{
obj_t list1131_1644;
{
obj_t arg1132_1645;
arg1132_1645 = MAKE_PAIR(BNIL, BNIL);
list1131_1644 = MAKE_PAIR(arg1129_1642, arg1132_1645);
}
arg1127_1640 = cons__138___r4_pairs_and_lists_6_3(arg1128_1641, list1131_1644);
}
}
arg1112_1625 = PROCEDURE_ENTRY(k_6)(k_6, r_4, z_7, arg1127_1640, BEOA);
}
{
obj_t arg1134_1647;
arg1134_1647 = pattern_minus_154___match_descriptions(d_8, f_2);
arg1113_1626 = PROCEDURE_ENTRY(z_7)(z_7, arg1134_1647, BEOA);
}
return build_if_78___match_compiler(arg1111_1624, arg1112_1625, arg1113_1626);
}
 else {
if((case_value_58_550==symbol2093___match_compiler)){
obj_t aux_3024;
{
obj_t aux_3025;
aux_3025 = CDR(f_2);
aux_3024 = CAR(aux_3025);
}
return compile_var_237___match_compiler(aux_3024, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
if((case_value_58_550==symbol2094___match_compiler)){
obj_t arg1035_558;
{
obj_t aux_3031;
aux_3031 = CDR(f_2);
arg1035_558 = CAR(aux_3031);
}
{
obj_t arg1136_2651;
obj_t arg1135_2652;
arg1136_2651 = make_fx_procedure(arg1136___match_compiler, ((long)1), ((long)3));
arg1135_2652 = make_fx_procedure(arg1135___match_compiler, ((long)3), ((long)1));
PROCEDURE_SET(arg1136_2651, ((long)0), k_6);
PROCEDURE_SET(arg1136_2651, ((long)1), r_4);
PROCEDURE_SET(arg1136_2651, ((long)2), z_7);
PROCEDURE_SET(arg1135_2652, ((long)0), z_7);
{
obj_t z_3042;
obj_t k_3041;
obj_t f_3040;
f_3040 = arg1035_558;
k_3041 = arg1135_2652;
z_3042 = arg1136_2651;
z_7 = z_3042;
k_6 = k_3041;
f_2 = f_3040;
goto compile___match_compiler;
}
}
}
 else {
if((case_value_58_550==symbol2095___match_compiler)){
obj_t aux_3049;
obj_t aux_3045;
{
obj_t aux_3050;
{
obj_t aux_3051;
aux_3051 = CDR(f_2);
aux_3050 = CDR(aux_3051);
}
aux_3049 = CAR(aux_3050);
}
{
obj_t aux_3046;
aux_3046 = CDR(f_2);
aux_3045 = CAR(aux_3046);
}
return compile_or_167___match_compiler(aux_3045, aux_3049, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
if((case_value_58_550==symbol2096___match_compiler)){
obj_t arg1040_563;
obj_t arg1041_564;
obj_t arg1042_565;
{
obj_t aux_3058;
aux_3058 = CDR(f_2);
arg1040_563 = CAR(aux_3058);
}
{
obj_t aux_3061;
{
obj_t aux_3062;
aux_3062 = CDR(f_2);
aux_3061 = CDR(aux_3062);
}
arg1041_564 = CAR(aux_3061);
}
{
obj_t aux_3066;
{
obj_t aux_3067;
{
obj_t aux_3068;
aux_3068 = CDR(f_2);
aux_3067 = CDR(aux_3068);
}
aux_3066 = CDR(aux_3067);
}
arg1042_565 = CAR(aux_3066);
}
{
obj_t _vars__115_1722;
_vars__115_1722 = pattern_variables_45___match_descriptions(arg1040_563);
{
obj_t arg1183_2653;
obj_t arg1182_2654;
arg1183_2653 = make_fx_procedure(arg1183___match_compiler, ((long)1), ((long)6));
arg1182_2654 = make_fx_procedure(arg1182___match_compiler, ((long)3), ((long)2));
PROCEDURE_SET(arg1183_2653, ((long)0), arg1042_565);
PROCEDURE_SET(arg1183_2653, ((long)1), e_3);
PROCEDURE_SET(arg1183_2653, ((long)2), r_4);
PROCEDURE_SET(arg1183_2653, ((long)3), m_5);
PROCEDURE_SET(arg1183_2653, ((long)4), k_6);
PROCEDURE_SET(arg1183_2653, ((long)5), z_7);
PROCEDURE_SET(arg1182_2654, ((long)0), _vars__115_1722);
PROCEDURE_SET(arg1182_2654, ((long)1), arg1041_564);
{
obj_t z_3086;
obj_t k_3085;
obj_t f_3084;
f_3084 = arg1040_563;
k_3085 = arg1182_2654;
z_3086 = arg1183_2653;
z_7 = z_3086;
k_6 = k_3085;
f_2 = f_3084;
goto compile___match_compiler;
}
}
}
}
 else {
if((case_value_58_550==symbol2097___match_compiler)){
obj_t arg1044_567;
obj_t arg1045_568;
{
obj_t aux_3089;
aux_3089 = CDR(f_2);
arg1044_567 = CAR(aux_3089);
}
{
obj_t aux_3092;
{
obj_t aux_3093;
aux_3093 = CDR(f_2);
aux_3092 = CDR(aux_3093);
}
arg1045_568 = CAR(aux_3092);
}
{
bool_t test1192_1761;
{
obj_t aux_3097;
aux_3097 = compatible__222___match_descriptions(arg1044_567, arg1045_568);
test1192_1761 = CBOOL(aux_3097);
}
if(test1192_1761){
obj_t arg1193_2655;
arg1193_2655 = make_fx_procedure(arg1193___match_compiler, ((long)3), ((long)4));
PROCEDURE_SET(arg1193_2655, ((long)0), arg1045_568);
PROCEDURE_SET(arg1193_2655, ((long)1), e_3);
PROCEDURE_SET(arg1193_2655, ((long)2), m_5);
PROCEDURE_SET(arg1193_2655, ((long)3), k_6);
{
obj_t k_3107;
obj_t f_3106;
f_3106 = arg1044_567;
k_3107 = arg1193_2655;
k_6 = k_3107;
f_2 = f_3106;
goto compile___match_compiler;
}
}
 else {
return PROCEDURE_ENTRY(z_7)(z_7, d_8, BEOA);
}
}
}
 else {
if((case_value_58_550==symbol2098___match_compiler)){
obj_t aux_3116;
obj_t aux_3112;
{
obj_t aux_3117;
{
obj_t aux_3118;
aux_3118 = CDR(f_2);
aux_3117 = CDR(aux_3118);
}
aux_3116 = CAR(aux_3117);
}
{
obj_t aux_3113;
aux_3113 = CDR(f_2);
aux_3112 = CAR(aux_3113);
}
return compile_cons_24___match_compiler(aux_3112, aux_3116, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
if((case_value_58_550==symbol2099___match_compiler)){
obj_t aux_3135;
obj_t aux_3129;
obj_t aux_3125;
{
obj_t aux_3136;
{
obj_t aux_3137;
{
obj_t aux_3138;
aux_3138 = CDR(f_2);
aux_3137 = CDR(aux_3138);
}
aux_3136 = CDR(aux_3137);
}
aux_3135 = CAR(aux_3136);
}
{
obj_t aux_3130;
{
obj_t aux_3131;
aux_3131 = CDR(f_2);
aux_3130 = CDR(aux_3131);
}
aux_3129 = CAR(aux_3130);
}
{
obj_t aux_3126;
aux_3126 = CDR(f_2);
aux_3125 = CAR(aux_3126);
}
return compile_times_196___match_compiler(aux_3125, aux_3129, aux_3135, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
if((case_value_58_550==symbol2100___match_compiler)){
obj_t list1429_1827;
list1429_1827 = MAKE_PAIR(string2101___match_compiler, BNIL);
FAILURE(string2102___match_compiler,list1429_1827,string2103___match_compiler);}
 else {
if((case_value_58_550==symbol2104___match_compiler)){
obj_t arg1421_1847;
{
obj_t fun1428_1849;
{
obj_t aux_3150;
{
obj_t aux_3151;
aux_3151 = CDR(f_2);
aux_3150 = CAR(aux_3151);
}
fun1428_1849 = PROCEDURE_ENTRY(m_5)(m_5, aux_3150, BEOA);
}
arg1421_1847 = PROCEDURE_ENTRY(fun1428_1849)(fun1428_1849, r_4, m_5, k_6, z_7, d_8, BEOA);
}
{
obj_t list1424_1850;
{
obj_t arg1426_1851;
arg1426_1851 = MAKE_PAIR(BNIL, BNIL);
list1424_1850 = MAKE_PAIR(e_3, arg1426_1851);
}
return cons__138___r4_pairs_and_lists_6_3(arg1421_1847, list1424_1850);
}
}
 else {
if((case_value_58_550==symbol2105___match_compiler)){
obj_t aux_3167;
obj_t aux_3163;
{
obj_t aux_3168;
{
obj_t aux_3169;
aux_3169 = CDR(f_2);
aux_3168 = CDR(aux_3169);
}
aux_3167 = CAR(aux_3168);
}
{
obj_t aux_3164;
aux_3164 = CDR(f_2);
aux_3163 = CAR(aux_3164);
}
return compile_vector_begin_230___match_compiler(aux_3163, aux_3167, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
if((case_value_58_550==symbol2106___match_compiler)){
obj_t lambda1596_2656;
lambda1596_2656 = make_fx_procedure(lambda1596___match_compiler, ((long)1), ((long)5));
PROCEDURE_SET(lambda1596_2656, ((long)0), e_3);
PROCEDURE_SET(lambda1596_2656, ((long)1), k_6);
PROCEDURE_SET(lambda1596_2656, ((long)2), r_4);
PROCEDURE_SET(lambda1596_2656, ((long)3), z_7);
PROCEDURE_SET(lambda1596_2656, ((long)4), d_8);
return lambda1596_2656;
}
 else {
if((case_value_58_550==symbol2107___match_compiler)){
obj_t lambda1618_2657;
lambda1618_2657 = make_fx_procedure(lambda1618___match_compiler, ((long)1), ((long)4));
PROCEDURE_SET(lambda1618_2657, ((long)0), k_6);
PROCEDURE_SET(lambda1618_2657, ((long)1), r_4);
PROCEDURE_SET(lambda1618_2657, ((long)2), z_7);
PROCEDURE_SET(lambda1618_2657, ((long)3), d_8);
return lambda1618_2657;
}
 else {
if((case_value_58_550==symbol2108___match_compiler)){
obj_t aux_3195;
obj_t aux_3191;
{
obj_t aux_3196;
{
obj_t aux_3197;
aux_3197 = CDR(f_2);
aux_3196 = CDR(aux_3197);
}
aux_3195 = CAR(aux_3196);
}
{
obj_t aux_3192;
aux_3192 = CDR(f_2);
aux_3191 = CAR(aux_3192);
}
return compile_vector_cons_109___match_compiler(aux_3191, aux_3195, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
if((case_value_58_550==symbol2109___match_compiler)){
obj_t list1619_1941;
list1619_1941 = MAKE_PAIR(string2110___match_compiler, BNIL);
FAILURE(string2102___match_compiler,list1619_1941,string2103___match_compiler);}
 else {
if((case_value_58_550==symbol2111___match_compiler)){
return compile_struct_pat_210___match_compiler(f_2, e_3, r_4, m_5, k_6, z_7, d_8);
}
 else {
obj_t list1074_595;
{
obj_t arg1077_597;
arg1077_597 = MAKE_PAIR(f_2, BNIL);
list1074_595 = MAKE_PAIR(string2112___match_compiler, arg1077_597);
}
FAILURE(string2102___match_compiler,list1074_595,string2103___match_compiler);}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
 else {
return PROCEDURE_ENTRY(z_7)(z_7, d_8, BEOA);
}
}
}
}


/* arg1136 */obj_t arg1136___match_compiler(obj_t env_2658, obj_t d2_2662)
{
{
obj_t k_2659;
obj_t r_2660;
obj_t z_2661;
k_2659 = PROCEDURE_REF(env_2658, ((long)0));
r_2660 = PROCEDURE_REF(env_2658, ((long)1));
z_2661 = PROCEDURE_REF(env_2658, ((long)2));
{
obj_t d2_1680;
d2_1680 = d2_2662;
return PROCEDURE_ENTRY(k_2659)(k_2659, r_2660, z_2661, d2_1680, BEOA);
}
}
}


/* arg1135 */obj_t arg1135___match_compiler(obj_t env_2663, obj_t r2_2665, obj_t z2_2666, obj_t d2_2667)
{
{
obj_t z_2664;
z_2664 = PROCEDURE_REF(env_2663, ((long)0));
{
obj_t d2_2890;
d2_2890 = d2_2667;
return PROCEDURE_ENTRY(z_2664)(z_2664, d2_2890, BEOA);
}
}
}


/* arg1183 */obj_t arg1183___match_compiler(obj_t env_2668, obj_t d_2675)
{
{
obj_t f2_2669;
obj_t e_2670;
obj_t r_2671;
obj_t m_2672;
obj_t k_2673;
obj_t z_2674;
f2_2669 = PROCEDURE_REF(env_2668, ((long)0));
e_2670 = PROCEDURE_REF(env_2668, ((long)1));
r_2671 = PROCEDURE_REF(env_2668, ((long)2));
m_2672 = PROCEDURE_REF(env_2668, ((long)3));
k_2673 = PROCEDURE_REF(env_2668, ((long)4));
z_2674 = PROCEDURE_REF(env_2668, ((long)5));
{
obj_t d_1734;
d_1734 = d_2675;
return compile___match_compiler(f2_2669, e_2670, r_2671, m_2672, k_2673, z_2674, d_1734);
}
}
}


/* arg1182 */obj_t arg1182___match_compiler(obj_t env_2676, obj_t r_2679, obj_t z_2680, obj_t c_2681)
{
{
obj_t _vars__115_2677;
obj_t t1_2678;
_vars__115_2677 = PROCEDURE_REF(env_2676, ((long)0));
t1_2678 = PROCEDURE_REF(env_2676, ((long)1));
{
obj_t r_1725;
obj_t z_1726;
obj_t c_1727;
r_1725 = r_2679;
z_1726 = z_2680;
c_1727 = c_2681;
{
obj_t arg1185_1735;
{
obj_t arg1188_1736;
arg1188_1736 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1185_1735 = append_2_18___r4_pairs_and_lists_6_3(_vars__115_2677, arg1188_1736);
}
{
obj_t list1186_1739;
list1186_1739 = MAKE_PAIR(arg1185_1735, BNIL);
return cons__138___r4_pairs_and_lists_6_3(t1_2678, list1186_1739);
}
}
}
}
}


/* arg1193 */obj_t arg1193___match_compiler(obj_t env_2682, obj_t r2_2687, obj_t z2_2688, obj_t c2_2689)
{
{
obj_t f2_2683;
obj_t e_2684;
obj_t m_2685;
obj_t k_2686;
f2_2683 = PROCEDURE_REF(env_2682, ((long)0));
e_2684 = PROCEDURE_REF(env_2682, ((long)1));
m_2685 = PROCEDURE_REF(env_2682, ((long)2));
k_2686 = PROCEDURE_REF(env_2682, ((long)3));
{
obj_t r2_1763;
obj_t z2_1764;
obj_t c2_1765;
r2_1763 = r2_2687;
z2_1764 = z2_2688;
c2_1765 = c2_2689;
return compile___match_compiler(f2_2683, e_2684, r2_1763, m_2685, k_2686, z2_1764, c2_1765);
}
}
}


/* lambda1596 */obj_t lambda1596___match_compiler(obj_t env_2690, obj_t i_2696)
{
{
obj_t e_2691;
obj_t k_2692;
obj_t r_2693;
obj_t z_2694;
obj_t d_2695;
e_2691 = PROCEDURE_REF(env_2690, ((long)0));
k_2692 = PROCEDURE_REF(env_2690, ((long)1));
r_2693 = PROCEDURE_REF(env_2690, ((long)2));
z_2694 = PROCEDURE_REF(env_2690, ((long)3));
d_2695 = PROCEDURE_REF(env_2690, ((long)4));
{
obj_t i_1874;
i_1874 = i_2696;
{
obj_t arg1598_1875;
obj_t arg1600_1876;
obj_t arg1602_1877;
{
obj_t arg1603_1878;
obj_t arg1605_1879;
arg1603_1878 = symbol2092___match_compiler;
{
obj_t arg1612_1881;
arg1612_1881 = symbol2113___match_compiler;
{
obj_t list1614_1883;
{
obj_t arg1615_1884;
arg1615_1884 = MAKE_PAIR(BNIL, BNIL);
list1614_1883 = MAKE_PAIR(e_2691, arg1615_1884);
}
arg1605_1879 = cons__138___r4_pairs_and_lists_6_3(arg1612_1881, list1614_1883);
}
}
{
obj_t list1607_1886;
{
obj_t arg1608_1887;
{
obj_t arg1609_1888;
arg1609_1888 = MAKE_PAIR(BNIL, BNIL);
arg1608_1887 = MAKE_PAIR(arg1605_1879, arg1609_1888);
}
list1607_1886 = MAKE_PAIR(i_1874, arg1608_1887);
}
arg1598_1875 = cons__138___r4_pairs_and_lists_6_3(arg1603_1878, list1607_1886);
}
}
arg1600_1876 = PROCEDURE_ENTRY(k_2692)(k_2692, r_2693, z_2694, d_2695, BEOA);
arg1602_1877 = PROCEDURE_ENTRY(z_2694)(z_2694, d_2695, BEOA);
return build_if_78___match_compiler(arg1598_1875, arg1600_1876, arg1602_1877);
}
}
}
}


/* lambda1618 */obj_t lambda1618___match_compiler(obj_t env_2697, obj_t i_2702)
{
{
obj_t k_2698;
obj_t r_2699;
obj_t z_2700;
obj_t d_2701;
k_2698 = PROCEDURE_REF(env_2697, ((long)0));
r_2699 = PROCEDURE_REF(env_2697, ((long)1));
z_2700 = PROCEDURE_REF(env_2697, ((long)2));
d_2701 = PROCEDURE_REF(env_2697, ((long)3));
{
obj_t i_1899;
i_1899 = i_2702;
return PROCEDURE_ENTRY(k_2698)(k_2698, r_2699, z_2700, d_2701, BEOA);
}
}
}


/* compile-or */obj_t compile_or_167___match_compiler(obj_t f1_36, obj_t f2_37, obj_t e_38, obj_t r_39, obj_t m_40, obj_t k_41, obj_t z_42, obj_t d_43)
{
{
obj_t _k__26_665;
_k__26_665 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2114___match_compiler, BEOA);
{
obj_t _vars__115_666;
_vars__115_666 = pattern_variables_45___match_descriptions(f1_36);
{
obj_t _call__27_667;
{
obj_t arg1174_724;
{
obj_t arg1177_727;
arg1177_727 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1174_724 = append_2_18___r4_pairs_and_lists_6_3(_vars__115_666, arg1177_727);
}
{
obj_t list1175_725;
list1175_725 = MAKE_PAIR(arg1174_724, BNIL);
_call__27_667 = cons__138___r4_pairs_and_lists_6_3(_k__26_665, list1175_725);
}
}
{
obj_t success_form_130_668;
{
obj_t arg1173_723;
arg1173_723 = extend__2084_62___match_compiler(r_39, _vars__115_666);
success_form_130_668 = PROCEDURE_ENTRY(k_41)(k_41, arg1173_723, z_42, d_43, BEOA);
}
{
{
bool_t test1139_669;
if((success_form_130_668==BFALSE)){
test1139_669 = ((bool_t)1);
}
 else {
if(equal__25___r4_equivalence_6_2(CDR(_call__27_667), CDR(success_form_130_668))){
test1139_669 = ((bool_t)1);
}
 else {
test1139_669 = isdirectcall__235___match_compiler(success_form_130_668);
}
}
if(test1139_669){
obj_t arg1141_2704;
obj_t arg1140_2705;
arg1141_2704 = make_fx_procedure(arg1141___match_compiler, ((long)1), ((long)6));
arg1140_2705 = make_fx_procedure(arg1140___match_compiler, ((long)3), ((long)1));
PROCEDURE_SET(arg1141_2704, ((long)0), success_form_130_668);
PROCEDURE_SET(arg1141_2704, ((long)1), f2_37);
PROCEDURE_SET(arg1141_2704, ((long)2), e_38);
PROCEDURE_SET(arg1141_2704, ((long)3), r_39);
PROCEDURE_SET(arg1141_2704, ((long)4), m_40);
PROCEDURE_SET(arg1141_2704, ((long)5), z_42);
PROCEDURE_SET(arg1140_2705, ((long)0), success_form_130_668);
return compile___match_compiler(f1_36, e_38, r_39, m_40, arg1140_2705, arg1141_2704, d_43);
}
 else {
obj_t res_686;
{
obj_t arg1164_2707;
obj_t arg1163_2708;
arg1164_2707 = make_fx_procedure(arg1164___match_compiler, ((long)1), ((long)6));
arg1163_2708 = make_fx_procedure(arg1163___match_compiler, ((long)3), ((long)1));
PROCEDURE_SET(arg1164_2707, ((long)0), _call__27_667);
PROCEDURE_SET(arg1164_2707, ((long)1), f2_37);
PROCEDURE_SET(arg1164_2707, ((long)2), e_38);
PROCEDURE_SET(arg1164_2707, ((long)3), r_39);
PROCEDURE_SET(arg1164_2707, ((long)4), m_40);
PROCEDURE_SET(arg1164_2707, ((long)5), z_42);
PROCEDURE_SET(arg1163_2708, ((long)0), _call__27_667);
res_686 = compile___match_compiler(f1_36, e_38, r_39, m_40, arg1163_2708, arg1164_2707, d_43);
}
if(CBOOL(res_686)){
obj_t arg1146_687;
obj_t arg1147_688;
arg1146_687 = symbol2115___match_compiler;
{
obj_t arg1153_694;
{
obj_t list1158_699;
{
obj_t arg1160_700;
{
obj_t arg1161_701;
arg1161_701 = MAKE_PAIR(BNIL, BNIL);
arg1160_700 = MAKE_PAIR(success_form_130_668, arg1161_701);
}
list1158_699 = MAKE_PAIR(_vars__115_666, arg1160_700);
}
arg1153_694 = cons__138___r4_pairs_and_lists_6_3(_k__26_665, list1158_699);
}
{
obj_t list1155_696;
list1155_696 = MAKE_PAIR(BNIL, BNIL);
arg1147_688 = cons__138___r4_pairs_and_lists_6_3(arg1153_694, list1155_696);
}
}
{
obj_t list1149_690;
{
obj_t arg1150_691;
{
obj_t arg1151_692;
arg1151_692 = MAKE_PAIR(BNIL, BNIL);
arg1150_691 = MAKE_PAIR(res_686, arg1151_692);
}
list1149_690 = MAKE_PAIR(arg1147_688, arg1150_691);
}
return cons__138___r4_pairs_and_lists_6_3(arg1146_687, list1149_690);
}
}
 else {
return res_686;
}
}
}
}
}
}
}
}
}


/* extend*_2084 */obj_t extend__2084_62___match_compiler(obj_t r_2887, obj_t v__41_2007)
{
if(NULLP(v__41_2007)){
return r_2887;
}
 else {
obj_t arg1693_2009;
obj_t arg1694_2010;
obj_t arg1695_2011;
arg1693_2009 = extend__2084_62___match_compiler(r_2887, CDR(v__41_2007));
arg1694_2010 = CAR(v__41_2007);
arg1695_2011 = symbol2116___match_compiler;
return extend_alist_122___match_compiler(arg1693_2009, arg1694_2010, arg1695_2011);
}
}


/* arg1141 */obj_t arg1141___match_compiler(obj_t env_2709, obj_t d_2716)
{
{
obj_t success_form_130_2710;
obj_t f2_2711;
obj_t e_2712;
obj_t r_2713;
obj_t m_2714;
obj_t z_2715;
success_form_130_2710 = PROCEDURE_REF(env_2709, ((long)0));
f2_2711 = PROCEDURE_REF(env_2709, ((long)1));
e_2712 = PROCEDURE_REF(env_2709, ((long)2));
r_2713 = PROCEDURE_REF(env_2709, ((long)3));
m_2714 = PROCEDURE_REF(env_2709, ((long)4));
z_2715 = PROCEDURE_REF(env_2709, ((long)5));
{
obj_t d_676;
d_676 = d_2716;
{
obj_t arg1144_2703;
arg1144_2703 = make_fx_procedure(arg1144___match_compiler, ((long)3), ((long)1));
PROCEDURE_SET(arg1144_2703, ((long)0), success_form_130_2710);
return compile___match_compiler(f2_2711, e_2712, r_2713, m_2714, arg1144_2703, z_2715, d_676);
}
}
}
}


/* arg1140 */obj_t arg1140___match_compiler(obj_t env_2717, obj_t r_2719, obj_t z_2720, obj_t d_2721)
{
{
obj_t success_form_130_2718;
success_form_130_2718 = PROCEDURE_REF(env_2717, ((long)0));
return success_form_130_2718;
}
}


/* arg1144 */obj_t arg1144___match_compiler(obj_t env_2722, obj_t r_2724, obj_t z_2725, obj_t d_2726)
{
{
obj_t success_form_130_2723;
success_form_130_2723 = PROCEDURE_REF(env_2722, ((long)0));
return success_form_130_2723;
}
}


/* arg1164 */obj_t arg1164___match_compiler(obj_t env_2727, obj_t d_2734)
{
{
obj_t _call__27_2728;
obj_t f2_2729;
obj_t e_2730;
obj_t r_2731;
obj_t m_2732;
obj_t z_2733;
_call__27_2728 = PROCEDURE_REF(env_2727, ((long)0));
f2_2729 = PROCEDURE_REF(env_2727, ((long)1));
e_2730 = PROCEDURE_REF(env_2727, ((long)2));
r_2731 = PROCEDURE_REF(env_2727, ((long)3));
m_2732 = PROCEDURE_REF(env_2727, ((long)4));
z_2733 = PROCEDURE_REF(env_2727, ((long)5));
{
obj_t d_709;
d_709 = d_2734;
{
obj_t arg1167_2706;
arg1167_2706 = make_fx_procedure(arg1167___match_compiler, ((long)3), ((long)1));
PROCEDURE_SET(arg1167_2706, ((long)0), _call__27_2728);
return compile___match_compiler(f2_2729, e_2730, r_2731, m_2732, arg1167_2706, z_2733, d_709);
}
}
}
}


/* arg1163 */obj_t arg1163___match_compiler(obj_t env_2735, obj_t r_2737, obj_t z_2738, obj_t d_2739)
{
{
obj_t _call__27_2736;
_call__27_2736 = PROCEDURE_REF(env_2735, ((long)0));
return _call__27_2736;
}
}


/* arg1167 */obj_t arg1167___match_compiler(obj_t env_2740, obj_t r_2742, obj_t z_2743, obj_t d_2744)
{
{
obj_t _call__27_2741;
_call__27_2741 = PROCEDURE_REF(env_2740, ((long)0));
return _call__27_2741;
}
}


/* isdirectcall? */bool_t isdirectcall__235___match_compiler(obj_t e_44)
{
if(PAIRP(e_44)){
if(SYMBOLP(e_44)){
obj_t s_733;
{
obj_t aux_3345;
aux_3345 = CAR(e_44);
s_733 = SYMBOL_TO_STRING(aux_3345);
}
{
bool_t test_3348;
{
long aux_3349;
aux_3349 = STRING_LENGTH(s_733);
test_3348 = (aux_3349>((long)3));
}
if(test_3348){
obj_t s_735;
s_735 = c_substring(s_733, ((long)0), ((long)3));
{
bool_t _ortest_1005_736;
_ortest_1005_736 = bigloo_strcmp(s_735, string2117___match_compiler);
if(_ortest_1005_736){
return _ortest_1005_736;
}
 else {
return bigloo_strcmp(s_735, string2118___match_compiler);
}
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* compile-var */obj_t compile_var_237___match_compiler(obj_t n_62, obj_t e_63, obj_t r_64, obj_t m_65, obj_t k_66, obj_t z_67, obj_t c_68)
{
{
bool_t test_3356;
{
bool_t test_3357;
{
obj_t aux_3358;
{
bool_t test_3359;
{
obj_t aux_3360;
aux_3360 = assq___r4_pairs_and_lists_6_3(n_62, r_64);
test_3359 = CBOOL(aux_3360);
}
if(test_3359){
obj_t aux_3363;
aux_3363 = assq___r4_pairs_and_lists_6_3(n_62, r_64);
aux_3358 = CDR(aux_3363);
}
 else {
aux_3358 = symbol2119___match_compiler;
}
}
test_3357 = eqv__112___r4_equivalence_6_2(aux_3358, symbol2119___match_compiler);
}
if(test_3357){
test_3356 = ((bool_t)0);
}
 else {
test_3356 = ((bool_t)1);
}
}
if(test_3356){
obj_t arg1196_764;
obj_t arg1197_765;
obj_t arg1199_766;
{
obj_t arg1200_767;
arg1200_767 = symbol2092___match_compiler;
{
obj_t list1202_769;
{
obj_t arg1203_770;
{
obj_t arg1204_771;
arg1204_771 = MAKE_PAIR(BNIL, BNIL);
arg1203_770 = MAKE_PAIR(e_63, arg1204_771);
}
list1202_769 = MAKE_PAIR(n_62, arg1203_770);
}
arg1196_764 = cons__138___r4_pairs_and_lists_6_3(arg1200_767, list1202_769);
}
}
{
obj_t arg1206_773;
{
obj_t arg1207_774;
{
obj_t arg1209_775;
arg1209_775 = symbol2093___match_compiler;
{
obj_t list1210_776;
{
obj_t arg1211_777;
arg1211_777 = MAKE_PAIR(n_62, BNIL);
list1210_776 = MAKE_PAIR(arg1209_775, arg1211_777);
}
arg1207_774 = list1210_776;
}
}
arg1206_773 = pattern_plus_250___match_descriptions(c_68, arg1207_774);
}
arg1197_765 = PROCEDURE_ENTRY(k_66)(k_66, r_64, z_67, arg1206_773, BEOA);
}
{
obj_t arg1214_779;
{
obj_t arg1216_780;
{
obj_t arg1219_781;
arg1219_781 = symbol2093___match_compiler;
{
obj_t list1220_782;
{
obj_t arg1221_783;
arg1221_783 = MAKE_PAIR(n_62, BNIL);
list1220_782 = MAKE_PAIR(arg1219_781, arg1221_783);
}
arg1216_780 = list1220_782;
}
}
arg1214_779 = pattern_minus_154___match_descriptions(c_68, arg1216_780);
}
arg1199_766 = PROCEDURE_ENTRY(z_67)(z_67, arg1214_779, BEOA);
}
return build_if_78___match_compiler(arg1196_764, arg1197_765, arg1199_766);
}
 else {
obj_t body_785;
{
obj_t arg1245_804;
obj_t arg1247_805;
{
obj_t arg1680_2081;
obj_t arg1681_2082;
{
obj_t list1684_2083;
list1684_2083 = MAKE_PAIR(e_63, BNIL);
arg1680_2081 = cons__138___r4_pairs_and_lists_6_3(n_62, list1684_2083);
}
{
obj_t arg1686_2085;
arg1686_2085 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1681_2082 = append_2_18___r4_pairs_and_lists_6_3(r_64, arg1686_2085);
}
{
obj_t list1682_2088;
list1682_2088 = MAKE_PAIR(arg1681_2082, BNIL);
arg1245_804 = cons__138___r4_pairs_and_lists_6_3(arg1680_2081, list1682_2088);
}
}
{
obj_t arg1248_806;
{
obj_t arg1250_807;
arg1250_807 = symbol2093___match_compiler;
{
obj_t list1251_808;
{
obj_t arg1252_809;
arg1252_809 = MAKE_PAIR(n_62, BNIL);
list1251_808 = MAKE_PAIR(arg1250_807, arg1252_809);
}
arg1248_806 = list1251_808;
}
}
arg1247_805 = pattern_plus_250___match_descriptions(c_68, arg1248_806);
}
body_785 = PROCEDURE_ENTRY(k_66)(k_66, arg1245_804, z_67, arg1247_805, BEOA);
}
{
bool_t test1223_786;
{
obj_t arg1243_802;
arg1243_802 = count_occurrences_123___match_compiler(n_62, body_785, ((long)0));
test1223_786 = _2__206___r4_numbers_6_5(arg1243_802, BINT(((long)1)));
}
if(test1223_786){
obj_t arg1224_787;
obj_t arg1225_788;
arg1224_787 = symbol2120___match_compiler;
{
obj_t arg1233_794;
{
obj_t list1239_799;
{
obj_t arg1240_800;
arg1240_800 = MAKE_PAIR(BNIL, BNIL);
list1239_799 = MAKE_PAIR(e_63, arg1240_800);
}
arg1233_794 = cons__138___r4_pairs_and_lists_6_3(n_62, list1239_799);
}
{
obj_t list1235_796;
list1235_796 = MAKE_PAIR(BNIL, BNIL);
arg1225_788 = cons__138___r4_pairs_and_lists_6_3(arg1233_794, list1235_796);
}
}
{
obj_t list1227_790;
{
obj_t arg1228_791;
{
obj_t arg1231_792;
arg1231_792 = MAKE_PAIR(BNIL, BNIL);
arg1228_791 = MAKE_PAIR(body_785, arg1231_792);
}
list1227_790 = MAKE_PAIR(arg1225_788, arg1228_791);
}
return cons__138___r4_pairs_and_lists_6_3(arg1224_787, list1227_790);
}
}
 else {
return unfold___match_compiler(n_62, e_63, body_785);
}
}
}
}
}


/* count-occurrences */obj_t count_occurrences_123___match_compiler(obj_t s_69, obj_t e_70, long acc_71)
{
if(NULLP(e_70)){
return BINT(acc_71);
}
 else {
bool_t test1255_812;
{
obj_t aux_3410;
aux_3410 = atom__231___match_s2cfun(e_70);
test1255_812 = CBOOL(aux_3410);
}
if(test1255_812){
if((s_69==e_70)){
return _2__168___r4_numbers_6_5(BINT(acc_71), BINT(((long)1)));
}
 else {
return BINT(acc_71);
}
}
 else {
if(PAIRP(e_70)){
bool_t test_3422;
{
obj_t aux_3423;
aux_3423 = CAR(e_70);
test_3422 = (aux_3423==symbol2091___match_compiler);
}
if(test_3422){
return BINT(acc_71);
}
 else {
obj_t arg1259_816;
obj_t arg1260_817;
arg1259_816 = count_occurrences_123___match_compiler(s_69, CAR(e_70), acc_71);
arg1260_817 = count_occurrences_123___match_compiler(s_69, CDR(e_70), acc_71);
return _2__168___r4_numbers_6_5(arg1259_816, arg1260_817);
}
}
 else {
return BUNSPEC;
}
}
}
}


/* compile-cons */obj_t compile_cons_24___match_compiler(obj_t f1_73, obj_t f2_74, obj_t e_75, obj_t r_76, obj_t m_77, obj_t k_78, obj_t z_79, obj_t c_80)
{
{
bool_t test_3432;
{
obj_t aux_3433;
aux_3433 = CAR(c_80);
test_3432 = (aux_3433==symbol2098___match_compiler);
}
if(test_3432){
return succes_cons_170___match_compiler(f1_73, f2_74, e_75, r_76, m_77, k_78, z_79, c_80);
}
 else {
obj_t arg1270_824;
obj_t arg1272_825;
obj_t arg1273_826;
obj_t arg1274_827;
arg1270_824 = symbol2090___match_compiler;
{
obj_t arg1285_834;
arg1285_834 = symbol2121___match_compiler;
{
obj_t list1287_836;
{
obj_t arg1288_837;
arg1288_837 = MAKE_PAIR(BNIL, BNIL);
list1287_836 = MAKE_PAIR(e_75, arg1288_837);
}
arg1272_825 = cons__138___r4_pairs_and_lists_6_3(arg1285_834, list1287_836);
}
}
arg1273_826 = succes_cons_170___match_compiler(f1_73, f2_74, e_75, r_76, m_77, k_78, z_79, c_80);
{
obj_t arg1291_839;
{
obj_t arg1292_840;
{
obj_t arg1294_841;
obj_t arg1295_842;
arg1294_841 = symbol2098___match_compiler;
arg1295_842 = list2085___match_compiler;
{
obj_t list1297_844;
{
obj_t arg1298_845;
{
obj_t arg1299_846;
arg1299_846 = MAKE_PAIR(list2085___match_compiler, BNIL);
arg1298_845 = MAKE_PAIR(arg1295_842, arg1299_846);
}
list1297_844 = MAKE_PAIR(arg1294_841, arg1298_845);
}
arg1292_840 = list1297_844;
}
}
arg1291_839 = pattern_minus_154___match_descriptions(c_80, arg1292_840);
}
arg1274_827 = PROCEDURE_ENTRY(z_79)(z_79, arg1291_839, BEOA);
}
{
obj_t list1278_829;
{
obj_t arg1281_830;
{
obj_t arg1282_831;
{
obj_t arg1283_832;
arg1283_832 = MAKE_PAIR(BNIL, BNIL);
arg1282_831 = MAKE_PAIR(arg1274_827, arg1283_832);
}
arg1281_830 = MAKE_PAIR(arg1273_826, arg1282_831);
}
list1278_829 = MAKE_PAIR(arg1272_825, arg1281_830);
}
return cons__138___r4_pairs_and_lists_6_3(arg1270_824, list1278_829);
}
}
}
}


/* succes-cons */obj_t succes_cons_170___match_compiler(obj_t f1_81, obj_t f2_82, obj_t e_83, obj_t r_84, obj_t m_85, obj_t k_86, obj_t z_87, obj_t c_88)
{
{
obj_t _car__246_848;
_car__246_848 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2122___match_compiler, BEOA);
{
obj_t _cdr__54_849;
_cdr__54_849 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2123___match_compiler, BEOA);
{
obj_t body_850;
{
obj_t arg1303_853;
arg1303_853 = pattern_car_218___match_descriptions(c_88);
{
obj_t arg1302_2745;
obj_t arg1301_2748;
arg1302_2745 = make_fx_procedure(arg1302___match_compiler, ((long)1), ((long)2));
arg1301_2748 = make_fx_procedure(arg1301___match_compiler, ((long)3), ((long)6));
PROCEDURE_SET(arg1302_2745, ((long)0), c_88);
PROCEDURE_SET(arg1302_2745, ((long)1), z_87);
PROCEDURE_SET(arg1301_2748, ((long)0), c_88);
PROCEDURE_SET(arg1301_2748, ((long)1), z_87);
PROCEDURE_SET(arg1301_2748, ((long)2), k_86);
PROCEDURE_SET(arg1301_2748, ((long)3), f2_82);
PROCEDURE_SET(arg1301_2748, ((long)4), _cdr__54_849);
PROCEDURE_SET(arg1301_2748, ((long)5), m_85);
body_850 = compile___match_compiler(f1_81, _car__246_848, r_84, m_85, arg1301_2748, arg1302_2745, arg1303_853);
}
}
{
return build_let_227___match_compiler(_car__246_848, _cdr__54_849, e_83, body_850);
}
}
}
}
}


/* arg1302 */obj_t arg1302___match_compiler(obj_t env_2749, obj_t c2_2752)
{
{
obj_t c_2750;
obj_t z_2751;
c_2750 = PROCEDURE_REF(env_2749, ((long)0));
z_2751 = PROCEDURE_REF(env_2749, ((long)1));
{
obj_t c2_881;
c2_881 = c2_2752;
{
obj_t arg1328_883;
{
obj_t arg1330_884;
obj_t arg1331_885;
arg1330_884 = symbol2098___match_compiler;
arg1331_885 = pattern_cdr_48___match_descriptions(c_2750);
{
obj_t list1332_886;
{
obj_t arg1333_887;
{
obj_t arg1334_888;
arg1334_888 = MAKE_PAIR(arg1331_885, BNIL);
arg1333_887 = MAKE_PAIR(c2_881, arg1334_888);
}
list1332_886 = MAKE_PAIR(arg1330_884, arg1333_887);
}
arg1328_883 = list1332_886;
}
}
return PROCEDURE_ENTRY(z_2751)(z_2751, arg1328_883, BEOA);
}
}
}
}


/* arg1301 */obj_t arg1301___match_compiler(obj_t env_2753, obj_t r2_2760, obj_t z2_2761, obj_t c2_2762)
{
{
obj_t c_2754;
obj_t z_2755;
obj_t k_2756;
obj_t f2_2757;
obj_t _cdr__54_2758;
obj_t m_2759;
c_2754 = PROCEDURE_REF(env_2753, ((long)0));
z_2755 = PROCEDURE_REF(env_2753, ((long)1));
k_2756 = PROCEDURE_REF(env_2753, ((long)2));
f2_2757 = PROCEDURE_REF(env_2753, ((long)3));
_cdr__54_2758 = PROCEDURE_REF(env_2753, ((long)4));
m_2759 = PROCEDURE_REF(env_2753, ((long)5));
{
obj_t r2_854;
obj_t z2_855;
obj_t c2_856;
r2_854 = r2_2760;
z2_855 = z2_2761;
c2_856 = c2_2762;
{
obj_t arg1309_860;
arg1309_860 = pattern_cdr_48___match_descriptions(c_2754);
{
obj_t arg1308_2746;
obj_t arg1307_2747;
arg1308_2746 = make_fx_procedure(arg1308___match_compiler, ((long)1), ((long)2));
arg1307_2747 = make_fx_procedure(arg1307___match_compiler, ((long)3), ((long)2));
PROCEDURE_SET(arg1308_2746, ((long)0), c2_856);
PROCEDURE_SET(arg1308_2746, ((long)1), z_2755);
PROCEDURE_SET(arg1307_2747, ((long)0), c2_856);
PROCEDURE_SET(arg1307_2747, ((long)1), k_2756);
return compile___match_compiler(f2_2757, _cdr__54_2758, r2_854, m_2759, arg1307_2747, arg1308_2746, arg1309_860);
}
}
}
}
}


/* arg1308 */obj_t arg1308___match_compiler(obj_t env_2763, obj_t c3_2766)
{
{
obj_t c2_2764;
obj_t z_2765;
c2_2764 = PROCEDURE_REF(env_2763, ((long)0));
z_2765 = PROCEDURE_REF(env_2763, ((long)1));
{
obj_t c3_871;
c3_871 = c3_2766;
{
obj_t arg1321_873;
{
obj_t arg1322_874;
arg1322_874 = symbol2098___match_compiler;
{
obj_t list1323_875;
{
obj_t arg1324_876;
{
obj_t arg1325_877;
arg1325_877 = MAKE_PAIR(c3_871, BNIL);
arg1324_876 = MAKE_PAIR(c2_2764, arg1325_877);
}
list1323_875 = MAKE_PAIR(arg1322_874, arg1324_876);
}
arg1321_873 = list1323_875;
}
}
return PROCEDURE_ENTRY(z_2765)(z_2765, arg1321_873, BEOA);
}
}
}
}


/* arg1307 */obj_t arg1307___match_compiler(obj_t env_2767, obj_t r3_2770, obj_t z3_2771, obj_t c3_2772)
{
{
obj_t c2_2768;
obj_t k_2769;
c2_2768 = PROCEDURE_REF(env_2767, ((long)0));
k_2769 = PROCEDURE_REF(env_2767, ((long)1));
{
obj_t r3_861;
obj_t z3_862;
obj_t c3_863;
r3_861 = r3_2770;
z3_862 = z3_2771;
c3_863 = c3_2772;
{
obj_t arg1311_2107;
{
obj_t arg1313_2108;
arg1313_2108 = symbol2098___match_compiler;
{
obj_t list1314_2109;
{
obj_t arg1315_2110;
{
obj_t arg1316_2111;
arg1316_2111 = MAKE_PAIR(c3_863, BNIL);
arg1315_2110 = MAKE_PAIR(c2_2768, arg1316_2111);
}
list1314_2109 = MAKE_PAIR(arg1313_2108, arg1315_2110);
}
arg1311_2107 = list1314_2109;
}
}
return PROCEDURE_ENTRY(k_2769)(k_2769, r3_861, z3_862, arg1311_2107, BEOA);
}
}
}
}


/* compile-times */obj_t compile_times_196___match_compiler(obj_t n_89, obj_t f1_90, obj_t f2_91, obj_t e_92, obj_t r_93, obj_t m_94, obj_t k0_95, obj_t z0_96, obj_t d0_97)
{
{
obj_t f_env_48_892;
obj_t d_env_106_893;
f_env_48_892 = MAKE_CELL(BNIL);
d_env_106_893 = MAKE_CELL(BNIL);
{
obj_t instanciate_try_249_2776;
instanciate_try_249_2776 = make_fx_procedure(instanciate_try_249___match_compiler, ((long)5), ((long)5));
PROCEDURE_SET(instanciate_try_249_2776, ((long)0), d_env_106_893);
PROCEDURE_SET(instanciate_try_249_2776, ((long)1), n_89);
PROCEDURE_SET(instanciate_try_249_2776, ((long)2), f1_90);
PROCEDURE_SET(instanciate_try_249_2776, ((long)3), f2_91);
PROCEDURE_SET(instanciate_try_249_2776, ((long)4), f_env_48_892);
{
obj_t res_body_73_895;
{
obj_t arg1370_2774;
obj_t arg1369_2775;
arg1370_2774 = make_fx_procedure(arg1370___match_compiler, ((long)1), ((long)2));
arg1369_2775 = make_fx_procedure(arg1369___match_compiler, ((long)3), ((long)2));
PROCEDURE_SET(arg1370_2774, ((long)0), z0_96);
PROCEDURE_SET(arg1370_2774, ((long)1), d0_97);
PROCEDURE_SET(arg1369_2775, ((long)0), k0_95);
PROCEDURE_SET(arg1369_2775, ((long)1), d0_97);
res_body_73_895 = instanciate_try_249___match_compiler(instanciate_try_249_2776, r_93, m_94, arg1369_2775, arg1370_2774, d0_97);
}
{
obj_t arg1339_896;
obj_t arg1340_897;
obj_t arg1342_898;
arg1339_896 = symbol2124___match_compiler;
{
obj_t l1006_904;
l1006_904 = CELL_REF(f_env_48_892);
if(NULLP(l1006_904)){
arg1340_897 = BNIL;
}
 else {
obj_t head1008_906;
{
obj_t aux_3520;
{
obj_t aux_3521;
{
obj_t aux_3522;
{
obj_t aux_3523;
{
obj_t aux_3524;
{
obj_t aux_3525;
aux_3525 = CAR(l1006_904);
aux_3524 = CDR(aux_3525);
}
aux_3523 = CAR(aux_3524);
}
aux_3522 = CDR(aux_3523);
}
aux_3521 = CAR(aux_3522);
}
aux_3520 = CAR(aux_3521);
}
head1008_906 = MAKE_PAIR(aux_3520, BNIL);
}
{
obj_t l1006_2133;
obj_t tail1009_2134;
l1006_2133 = CDR(l1006_904);
tail1009_2134 = head1008_906;
lname1007_2132:
if(NULLP(l1006_2133)){
arg1340_897 = head1008_906;
}
 else {
obj_t newtail1010_2142;
{
obj_t aux_3535;
{
obj_t aux_3536;
{
obj_t aux_3537;
{
obj_t aux_3538;
{
obj_t aux_3539;
{
obj_t aux_3540;
aux_3540 = CAR(l1006_2133);
aux_3539 = CDR(aux_3540);
}
aux_3538 = CAR(aux_3539);
}
aux_3537 = CDR(aux_3538);
}
aux_3536 = CAR(aux_3537);
}
aux_3535 = CAR(aux_3536);
}
newtail1010_2142 = MAKE_PAIR(aux_3535, BNIL);
}
SET_CDR(tail1009_2134, newtail1010_2142);
{
obj_t tail1009_3551;
obj_t l1006_3549;
l1006_3549 = CDR(l1006_2133);
tail1009_3551 = newtail1010_2142;
tail1009_2134 = tail1009_3551;
l1006_2133 = l1006_3549;
goto lname1007_2132;
}
}
}
}
}
{
obj_t list1366_921;
{
obj_t arg1367_922;
arg1367_922 = MAKE_PAIR(BNIL, BNIL);
list1366_921 = MAKE_PAIR(e_92, arg1367_922);
}
arg1342_898 = cons__138___r4_pairs_and_lists_6_3(res_body_73_895, list1366_921);
}
{
obj_t list1344_900;
{
obj_t arg1345_901;
{
obj_t arg1347_902;
arg1347_902 = MAKE_PAIR(BNIL, BNIL);
arg1345_901 = MAKE_PAIR(arg1342_898, arg1347_902);
}
list1344_900 = MAKE_PAIR(arg1340_897, arg1345_901);
}
return cons__138___r4_pairs_and_lists_6_3(arg1339_896, list1344_900);
}
}
}
}
}
}


/* look-for-descr_2080 */obj_t look_for_descr_2080_128___match_compiler(obj_t d_2779, obj_t d_env_106_2216)
{
look_for_descr_2080_128___match_compiler:
if(NULLP(d_env_106_2216)){
return BFALSE;
}
 else {
bool_t test_3562;
{
obj_t aux_3563;
{
obj_t aux_3564;
aux_3564 = CAR(d_env_106_2216);
aux_3563 = CAR(aux_3564);
}
test_3562 = equal__25___r4_equivalence_6_2(aux_3563, d_2779);
}
if(test_3562){
return CAR(d_env_106_2216);
}
 else {
obj_t d_env_106_3569;
d_env_106_3569 = CDR(d_env_106_2216);
d_env_106_2216 = d_env_106_3569;
goto look_for_descr_2080_128___match_compiler;
}
}
}


/* arg1370 */obj_t arg1370___match_compiler(obj_t env_2780, obj_t d_2783)
{
{
obj_t z0_2781;
obj_t d0_2782;
z0_2781 = PROCEDURE_REF(env_2780, ((long)0));
d0_2782 = PROCEDURE_REF(env_2780, ((long)1));
{
obj_t d_930;
d_930 = d_2783;
return PROCEDURE_ENTRY(z0_2781)(z0_2781, d0_2782, BEOA);
}
}
}


/* arg1369 */obj_t arg1369___match_compiler(obj_t env_2784, obj_t r_2787, obj_t z_2788, obj_t d_2789)
{
{
obj_t k0_2785;
obj_t d0_2786;
k0_2785 = PROCEDURE_REF(env_2784, ((long)0));
d0_2786 = PROCEDURE_REF(env_2784, ((long)1));
{
obj_t r_926;
obj_t z_927;
obj_t d_928;
r_926 = r_2787;
z_927 = z_2788;
d_928 = d_2789;
return PROCEDURE_ENTRY(k0_2785)(k0_2785, r_926, z_927, d0_2786, BEOA);
}
}
}


/* arg1417 */obj_t arg1417___match_compiler(obj_t env_2790, obj_t d2_2802)
{
{
obj_t d_env_106_2791;
obj_t f2_2792;
obj_t f_env_48_2793;
obj_t m_2794;
obj_t n_2795;
obj_t instanciate_try_249_2796;
obj_t f1_2797;
obj_t g_2798;
obj_t r_2799;
obj_t k_2800;
obj_t z_2801;
d_env_106_2791 = PROCEDURE_REF(env_2790, ((long)0));
f2_2792 = PROCEDURE_REF(env_2790, ((long)1));
f_env_48_2793 = PROCEDURE_REF(env_2790, ((long)2));
m_2794 = PROCEDURE_REF(env_2790, ((long)3));
n_2795 = PROCEDURE_REF(env_2790, ((long)4));
instanciate_try_249_2796 = PROCEDURE_REF(env_2790, ((long)5));
f1_2797 = PROCEDURE_REF(env_2790, ((long)6));
g_2798 = PROCEDURE_REF(env_2790, ((long)7));
r_2799 = PROCEDURE_REF(env_2790, ((long)8));
k_2800 = PROCEDURE_REF(env_2790, ((long)9));
z_2801 = PROCEDURE_REF(env_2790, ((long)10));
{
obj_t d2_979;
d2_979 = d2_2802;
{
obj_t arg1419_2235;
{
obj_t lambda1707_2778;
lambda1707_2778 = make_fx_procedure(lambda1707___match_compiler, ((long)1), ((long)8));
PROCEDURE_SET(lambda1707_2778, ((long)0), d_env_106_2791);
PROCEDURE_SET(lambda1707_2778, ((long)1), n_2795);
PROCEDURE_SET(lambda1707_2778, ((long)2), f1_2797);
PROCEDURE_SET(lambda1707_2778, ((long)3), f2_2792);
PROCEDURE_SET(lambda1707_2778, ((long)4), f_env_48_2793);
PROCEDURE_SET(lambda1707_2778, ((long)5), n_2795);
PROCEDURE_SET(lambda1707_2778, ((long)6), m_2794);
PROCEDURE_SET(lambda1707_2778, ((long)7), instanciate_try_249_2796);
arg1419_2235 = lambda1707_2778;
}
return compile___match_compiler(f1_2797, g_2798, r_2799, arg1419_2235, k_2800, z_2801, d2_979);
}
}
}
}


/* lambda1707 */obj_t lambda1707___match_compiler(obj_t env_2803, obj_t x_2812)
{
{
obj_t pt_2809;
obj_t fn_2810;
obj_t instanciate_try_249_2811;
pt_2809 = PROCEDURE_REF(env_2803, ((long)5));
fn_2810 = PROCEDURE_REF(env_2803, ((long)6));
instanciate_try_249_2811 = PROCEDURE_REF(env_2803, ((long)7));
{
obj_t x_2239;
x_2239 = x_2812;
if((x_2239==pt_2809)){
return instanciate_try_249_2811;
}
 else {
return PROCEDURE_ENTRY(fn_2810)(fn_2810, x_2239, BEOA);
}
}
}
}


/* instanciate-try */obj_t instanciate_try_249___match_compiler(obj_t env_2813, obj_t r_2819, obj_t m_2820, obj_t k_2821, obj_t z_2822, obj_t d_2823)
{
{
obj_t d_env_106_2814;
obj_t n_2815;
obj_t f1_2816;
obj_t f2_2817;
obj_t f_env_48_2818;
d_env_106_2814 = PROCEDURE_REF(env_2813, ((long)0));
n_2815 = PROCEDURE_REF(env_2813, ((long)1));
f1_2816 = PROCEDURE_REF(env_2813, ((long)2));
f2_2817 = PROCEDURE_REF(env_2813, ((long)3));
f_env_48_2818 = PROCEDURE_REF(env_2813, ((long)4));
{
obj_t r_934;
obj_t m_935;
obj_t k_936;
obj_t z_937;
obj_t d_938;
r_934 = r_2819;
m_935 = m_2820;
k_936 = k_2821;
z_937 = z_2822;
d_938 = d_2823;
{
obj_t tmp_940;
tmp_940 = look_for_descr_2080_128___match_compiler(d_938, CELL_REF(d_env_106_2814));
if(CBOOL(tmp_940)){
obj_t aux_3615;
aux_3615 = CDR(tmp_940);
return CAR(aux_3615);
}
 else {
obj_t g_941;
obj_t try_942;
g_941 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2125___match_compiler, BEOA);
try_942 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2126___match_compiler, BEOA);
{
obj_t aux_2824;
{
obj_t arg1375_943;
{
obj_t list1376_944;
{
obj_t arg1378_945;
arg1378_945 = MAKE_PAIR(try_942, BNIL);
list1376_944 = MAKE_PAIR(d_938, arg1378_945);
}
arg1375_943 = list1376_944;
}
{
obj_t obj2_2234;
obj2_2234 = CELL_REF(d_env_106_2814);
aux_2824 = MAKE_PAIR(arg1375_943, obj2_2234);
}
}
CELL_SET(d_env_106_2814, aux_2824);
}
{
obj_t new_def_163_947;
{
obj_t arg1381_948;
{
obj_t arg1385_952;
obj_t arg1387_953;
arg1385_952 = symbol2124___match_compiler;
{
obj_t arg1392_958;
{
obj_t arg1396_962;
{
obj_t arg1402_967;
obj_t arg1403_968;
obj_t arg1405_969;
arg1402_967 = symbol2088___match_compiler;
{
obj_t list1415_976;
list1415_976 = MAKE_PAIR(BNIL, BNIL);
arg1403_968 = cons__138___r4_pairs_and_lists_6_3(g_941, list1415_976);
}
{
obj_t arg1417_2777;
arg1417_2777 = make_fx_procedure(arg1417___match_compiler, ((long)1), ((long)11));
PROCEDURE_SET(arg1417_2777, ((long)0), d_env_106_2814);
PROCEDURE_SET(arg1417_2777, ((long)1), f2_2817);
PROCEDURE_SET(arg1417_2777, ((long)2), f_env_48_2818);
PROCEDURE_SET(arg1417_2777, ((long)3), m_935);
PROCEDURE_SET(arg1417_2777, ((long)4), n_2815);
PROCEDURE_SET(arg1417_2777, ((long)5), env_2813);
PROCEDURE_SET(arg1417_2777, ((long)6), f1_2816);
PROCEDURE_SET(arg1417_2777, ((long)7), g_941);
PROCEDURE_SET(arg1417_2777, ((long)8), r_934);
PROCEDURE_SET(arg1417_2777, ((long)9), k_936);
PROCEDURE_SET(arg1417_2777, ((long)10), z_937);
arg1405_969 = compile___match_compiler(f2_2817, g_941, r_934, m_935, k_936, arg1417_2777, d_938);
}
{
obj_t list1408_971;
{
obj_t arg1410_972;
{
obj_t arg1411_973;
arg1411_973 = MAKE_PAIR(BNIL, BNIL);
arg1410_972 = MAKE_PAIR(arg1405_969, arg1411_973);
}
list1408_971 = MAKE_PAIR(arg1403_968, arg1410_972);
}
arg1396_962 = cons__138___r4_pairs_and_lists_6_3(arg1402_967, list1408_971);
}
}
{
obj_t list1398_964;
{
obj_t arg1399_965;
arg1399_965 = MAKE_PAIR(BNIL, BNIL);
list1398_964 = MAKE_PAIR(arg1396_962, arg1399_965);
}
arg1392_958 = cons__138___r4_pairs_and_lists_6_3(try_942, list1398_964);
}
}
{
obj_t list1394_960;
list1394_960 = MAKE_PAIR(BNIL, BNIL);
arg1387_953 = cons__138___r4_pairs_and_lists_6_3(arg1392_958, list1394_960);
}
}
{
obj_t list1389_955;
{
obj_t arg1390_956;
arg1390_956 = MAKE_PAIR(BNIL, BNIL);
list1389_955 = MAKE_PAIR(arg1387_953, arg1390_956);
}
arg1381_948 = cons__138___r4_pairs_and_lists_6_3(arg1385_952, list1389_955);
}
}
{
obj_t list1382_949;
{
obj_t arg1383_950;
arg1383_950 = MAKE_PAIR(arg1381_948, BNIL);
list1382_949 = MAKE_PAIR(try_942, arg1383_950);
}
new_def_163_947 = list1382_949;
}
}
{
obj_t aux_2825;
{
obj_t obj2_2246;
obj2_2246 = CELL_REF(f_env_48_2818);
aux_2825 = MAKE_PAIR(new_def_163_947, obj2_2246);
}
CELL_SET(f_env_48_2818, aux_2825);
}
return try_942;
}
}
}
}
}
}


/* compile-vector-begin */obj_t compile_vector_begin_230___match_compiler(obj_t lgmin_114, obj_t f_115, obj_t e_116, obj_t r_117, obj_t m_118, obj_t k_119, obj_t z_120, obj_t d_121)
{
{
bool_t test_3655;
{
obj_t aux_3656;
aux_3656 = CAR(d_121);
test_3655 = (aux_3656==symbol2127___match_compiler);
}
if(test_3655){
bool_t test_3659;
{
obj_t aux_3660;
{
obj_t aux_3661;
aux_3661 = CDR(d_121);
aux_3660 = CAR(aux_3661);
}
test_3659 = _2___235___r4_numbers_6_5(aux_3660, lgmin_114);
}
if(test_3659){
obj_t fun1437_995;
fun1437_995 = compile___match_compiler(f_115, e_116, r_117, m_118, k_119, z_120, d_121);
return PROCEDURE_ENTRY(fun1437_995)(fun1437_995, BINT(((long)0)), BEOA);
}
 else {
obj_t arg1438_997;
obj_t arg1440_998;
obj_t arg1441_999;
obj_t arg1443_1000;
arg1438_997 = symbol2090___match_compiler;
{
obj_t arg1453_1007;
obj_t arg1454_1008;
arg1453_1007 = symbol2128___match_compiler;
{
obj_t arg1463_1014;
arg1463_1014 = symbol2113___match_compiler;
{
obj_t list1465_1016;
{
obj_t arg1466_1017;
arg1466_1017 = MAKE_PAIR(BNIL, BNIL);
list1465_1016 = MAKE_PAIR(e_116, arg1466_1017);
}
arg1454_1008 = cons__138___r4_pairs_and_lists_6_3(arg1463_1014, list1465_1016);
}
}
{
obj_t list1456_1010;
{
obj_t arg1458_1011;
{
obj_t arg1460_1012;
arg1460_1012 = MAKE_PAIR(BNIL, BNIL);
arg1458_1011 = MAKE_PAIR(lgmin_114, arg1460_1012);
}
list1456_1010 = MAKE_PAIR(arg1454_1008, arg1458_1011);
}
arg1440_998 = cons__138___r4_pairs_and_lists_6_3(arg1453_1007, list1456_1010);
}
}
{
obj_t fun1470_1019;
fun1470_1019 = compile___match_compiler(f_115, e_116, r_117, m_118, k_119, z_120, d_121);
arg1441_999 = PROCEDURE_ENTRY(fun1470_1019)(fun1470_1019, BINT(((long)0)), BEOA);
}
arg1443_1000 = PROCEDURE_ENTRY(z_120)(z_120, d_121, BEOA);
{
obj_t list1445_1002;
{
obj_t arg1446_1003;
{
obj_t arg1448_1004;
{
obj_t arg1449_1005;
arg1449_1005 = MAKE_PAIR(BNIL, BNIL);
arg1448_1004 = MAKE_PAIR(arg1443_1000, arg1449_1005);
}
arg1446_1003 = MAKE_PAIR(arg1441_999, arg1448_1004);
}
list1445_1002 = MAKE_PAIR(arg1440_998, arg1446_1003);
}
return cons__138___r4_pairs_and_lists_6_3(arg1438_997, list1445_1002);
}
}
}
 else {
obj_t arg1473_1022;
obj_t arg1474_1023;
obj_t arg1475_1024;
obj_t arg1476_1025;
arg1473_1022 = symbol2090___match_compiler;
{
obj_t arg1484_1032;
arg1484_1032 = symbol2129___match_compiler;
{
obj_t list1486_1034;
{
obj_t arg1487_1035;
arg1487_1035 = MAKE_PAIR(BNIL, BNIL);
list1486_1034 = MAKE_PAIR(e_116, arg1487_1035);
}
arg1474_1023 = cons__138___r4_pairs_and_lists_6_3(arg1484_1032, list1486_1034);
}
}
{
obj_t arg1489_1037;
obj_t arg1490_1038;
obj_t arg1491_1039;
obj_t arg1494_1040;
arg1489_1037 = symbol2090___match_compiler;
{
obj_t arg1502_1047;
obj_t arg1503_1048;
arg1502_1047 = symbol2128___match_compiler;
{
obj_t arg1513_1054;
arg1513_1054 = symbol2113___match_compiler;
{
obj_t list1515_1056;
{
obj_t arg1516_1057;
arg1516_1057 = MAKE_PAIR(BNIL, BNIL);
list1515_1056 = MAKE_PAIR(e_116, arg1516_1057);
}
arg1503_1048 = cons__138___r4_pairs_and_lists_6_3(arg1513_1054, list1515_1056);
}
}
{
obj_t list1505_1050;
{
obj_t arg1507_1051;
{
obj_t arg1510_1052;
arg1510_1052 = MAKE_PAIR(BNIL, BNIL);
arg1507_1051 = MAKE_PAIR(lgmin_114, arg1510_1052);
}
list1505_1050 = MAKE_PAIR(arg1503_1048, arg1507_1051);
}
arg1490_1038 = cons__138___r4_pairs_and_lists_6_3(arg1502_1047, list1505_1050);
}
}
{
obj_t fun1531_1068;
{
obj_t arg1532_1070;
{
obj_t arg1533_1071;
obj_t arg1534_1072;
arg1533_1071 = symbol2127___match_compiler;
{
long aux_3697;
aux_3697 = (long)CINT(lgmin_114);
arg1534_1072 = make_vector(aux_3697, list2085___match_compiler);
}
{
obj_t list1536_1074;
{
obj_t arg1537_1075;
{
obj_t arg1539_1076;
arg1539_1076 = MAKE_PAIR(BNIL, BNIL);
arg1537_1075 = MAKE_PAIR(arg1534_1072, arg1539_1076);
}
list1536_1074 = MAKE_PAIR(lgmin_114, arg1537_1075);
}
arg1532_1070 = cons__138___r4_pairs_and_lists_6_3(arg1533_1071, list1536_1074);
}
}
fun1531_1068 = compile___match_compiler(f_115, e_116, r_117, m_118, k_119, z_120, arg1532_1070);
}
arg1491_1039 = PROCEDURE_ENTRY(fun1531_1068)(fun1531_1068, BINT(((long)0)), BEOA);
}
{
obj_t arg1545_1079;
{
obj_t arg1548_1080;
obj_t arg1550_1082;
arg1548_1080 = symbol2127___match_compiler;
arg1550_1082 = make_vector(((long)0), list2085___match_compiler);
{
obj_t list1553_1084;
{
obj_t arg1554_1085;
{
obj_t arg1555_1086;
arg1555_1086 = MAKE_PAIR(BNIL, BNIL);
arg1554_1085 = MAKE_PAIR(arg1550_1082, arg1555_1086);
}
{
obj_t aux_3711;
aux_3711 = BINT(((long)0));
list1553_1084 = MAKE_PAIR(aux_3711, arg1554_1085);
}
}
arg1545_1079 = cons__138___r4_pairs_and_lists_6_3(arg1548_1080, list1553_1084);
}
}
arg1494_1040 = PROCEDURE_ENTRY(z_120)(z_120, arg1545_1079, BEOA);
}
{
obj_t list1497_1042;
{
obj_t arg1498_1043;
{
obj_t arg1499_1044;
{
obj_t arg1500_1045;
arg1500_1045 = MAKE_PAIR(BNIL, BNIL);
arg1499_1044 = MAKE_PAIR(arg1494_1040, arg1500_1045);
}
arg1498_1043 = MAKE_PAIR(arg1491_1039, arg1499_1044);
}
list1497_1042 = MAKE_PAIR(arg1490_1038, arg1498_1043);
}
arg1475_1024 = cons__138___r4_pairs_and_lists_6_3(arg1489_1037, list1497_1042);
}
}
{
obj_t arg1559_1090;
arg1559_1090 = pattern_plus_250___match_descriptions(d_121, list2130___match_compiler);
arg1476_1025 = PROCEDURE_ENTRY(z_120)(z_120, arg1559_1090, BEOA);
}
{
obj_t list1478_1027;
{
obj_t arg1479_1028;
{
obj_t arg1480_1029;
{
obj_t arg1481_1030;
arg1481_1030 = MAKE_PAIR(BNIL, BNIL);
arg1480_1029 = MAKE_PAIR(arg1476_1025, arg1481_1030);
}
arg1479_1028 = MAKE_PAIR(arg1475_1024, arg1480_1029);
}
list1478_1027 = MAKE_PAIR(arg1474_1023, arg1479_1028);
}
return cons__138___r4_pairs_and_lists_6_3(arg1473_1022, list1478_1027);
}
}
}
}


/* compile-vector-cons */obj_t compile_vector_cons_109___match_compiler(obj_t f1_122, obj_t f2_123, obj_t e_124, obj_t r_125, obj_t m_126, obj_t k_127, obj_t z_128, obj_t d_129)
{
{
obj_t lambda1561_2828;
lambda1561_2828 = make_fx_procedure(lambda1561___match_compiler, ((long)1), ((long)8));
PROCEDURE_SET(lambda1561_2828, ((long)0), d_129);
PROCEDURE_SET(lambda1561_2828, ((long)1), e_124);
PROCEDURE_SET(lambda1561_2828, ((long)2), z_128);
PROCEDURE_SET(lambda1561_2828, ((long)3), f2_123);
PROCEDURE_SET(lambda1561_2828, ((long)4), m_126);
PROCEDURE_SET(lambda1561_2828, ((long)5), k_127);
PROCEDURE_SET(lambda1561_2828, ((long)6), f1_122);
PROCEDURE_SET(lambda1561_2828, ((long)7), r_125);
return lambda1561_2828;
}
}


/* lambda1561 */obj_t lambda1561___match_compiler(obj_t env_2829, obj_t i_2838)
{
{
obj_t d_2830;
obj_t e_2831;
obj_t z_2832;
obj_t f2_2833;
obj_t m_2834;
obj_t k_2835;
obj_t f1_2836;
obj_t r_2837;
d_2830 = PROCEDURE_REF(env_2829, ((long)0));
e_2831 = PROCEDURE_REF(env_2829, ((long)1));
z_2832 = PROCEDURE_REF(env_2829, ((long)2));
f2_2833 = PROCEDURE_REF(env_2829, ((long)3));
m_2834 = PROCEDURE_REF(env_2829, ((long)4));
k_2835 = PROCEDURE_REF(env_2829, ((long)5));
f1_2836 = PROCEDURE_REF(env_2829, ((long)6));
r_2837 = PROCEDURE_REF(env_2829, ((long)7));
{
obj_t i_1092;
i_1092 = i_2838;
{
bool_t test_3747;
{
obj_t aux_3748;
{
long aux_3749;
{
obj_t aux_3750;
{
obj_t aux_3751;
{
obj_t aux_3752;
aux_3752 = CDR(d_2830);
aux_3751 = CDR(aux_3752);
}
aux_3750 = CAR(aux_3751);
}
aux_3749 = VECTOR_LENGTH(aux_3750);
}
aux_3748 = BINT(aux_3749);
}
test_3747 = _2___235___r4_numbers_6_5(i_1092, aux_3748);
}
if(test_3747){
obj_t arg1563_1095;
obj_t arg1564_1096;
{
obj_t aux_3759;
aux_3759 = CDR(d_2830);
arg1563_1095 = CDR(aux_3759);
}
{
obj_t aux_3762;
{
obj_t aux_3763;
{
obj_t aux_3764;
aux_3764 = CDR(d_2830);
aux_3763 = CDR(aux_3764);
}
aux_3762 = CAR(aux_3763);
}
arg1564_1096 = extend_vector_160___match_descriptions(aux_3762, _2__168___r4_numbers_6_5(i_1092, BINT(((long)1))), list2085___match_compiler);
}
SET_CAR(arg1563_1095, arg1564_1096);
}
 else {
BTRUE;
}
}
{
obj_t arg1572_1102;
obj_t arg1578_1105;
{
obj_t arg1580_1106;
arg1580_1106 = symbol2132___match_compiler;
{
obj_t list1582_1108;
{
obj_t arg1583_1109;
{
obj_t arg1584_1110;
arg1584_1110 = MAKE_PAIR(BNIL, BNIL);
arg1583_1109 = MAKE_PAIR(i_1092, arg1584_1110);
}
list1582_1108 = MAKE_PAIR(e_2831, arg1583_1109);
}
arg1572_1102 = cons__138___r4_pairs_and_lists_6_3(arg1580_1106, list1582_1108);
}
}
{
long aux_3782;
obj_t aux_3776;
aux_3782 = (long)CINT(i_1092);
{
obj_t aux_3777;
{
obj_t aux_3778;
aux_3778 = CDR(d_2830);
aux_3777 = CDR(aux_3778);
}
aux_3776 = CAR(aux_3777);
}
arg1578_1105 = VECTOR_REF(aux_3776, aux_3782);
}
{
obj_t arg1575_2826;
obj_t arg1573_2827;
arg1575_2826 = make_fx_procedure(arg1575___match_compiler, ((long)1), ((long)3));
arg1573_2827 = make_fx_procedure(arg1573___match_compiler, ((long)3), ((long)7));
PROCEDURE_SET(arg1575_2826, ((long)0), d_2830);
PROCEDURE_SET(arg1575_2826, ((long)1), i_1092);
PROCEDURE_SET(arg1575_2826, ((long)2), z_2832);
PROCEDURE_SET(arg1573_2827, ((long)0), d_2830);
PROCEDURE_SET(arg1573_2827, ((long)1), i_1092);
PROCEDURE_SET(arg1573_2827, ((long)2), f2_2833);
PROCEDURE_SET(arg1573_2827, ((long)3), e_2831);
PROCEDURE_SET(arg1573_2827, ((long)4), m_2834);
PROCEDURE_SET(arg1573_2827, ((long)5), k_2835);
PROCEDURE_SET(arg1573_2827, ((long)6), z_2832);
return compile___match_compiler(f1_2836, arg1572_1102, r_2837, m_2834, arg1573_2827, arg1575_2826, arg1578_1105);
}
}
}
}
}


/* arg1575 */obj_t arg1575___match_compiler(obj_t env_2839, obj_t d1_2843)
{
{
obj_t d_2840;
obj_t i_2841;
obj_t z_2842;
d_2840 = PROCEDURE_REF(env_2839, ((long)0));
i_2841 = PROCEDURE_REF(env_2839, ((long)1));
z_2842 = PROCEDURE_REF(env_2839, ((long)2));
{
obj_t d1_1120;
d1_1120 = d1_2843;
{
obj_t arg1594_2300;
arg1594_2300 = vector_plus_240___match_descriptions(d_2840, i_2841, d1_1120);
return PROCEDURE_ENTRY(z_2842)(z_2842, arg1594_2300, BEOA);
}
}
}
}


/* arg1573 */obj_t arg1573___match_compiler(obj_t env_2844, obj_t r_2852, obj_t z1_2853, obj_t d1_2854)
{
{
obj_t d_2845;
obj_t i_2846;
obj_t f2_2847;
obj_t e_2848;
obj_t m_2849;
obj_t k_2850;
obj_t z_2851;
d_2845 = PROCEDURE_REF(env_2844, ((long)0));
i_2846 = PROCEDURE_REF(env_2844, ((long)1));
f2_2847 = PROCEDURE_REF(env_2844, ((long)2));
e_2848 = PROCEDURE_REF(env_2844, ((long)3));
m_2849 = PROCEDURE_REF(env_2844, ((long)4));
k_2850 = PROCEDURE_REF(env_2844, ((long)5));
z_2851 = PROCEDURE_REF(env_2844, ((long)6));
{
obj_t r_1112;
obj_t z1_1113;
obj_t d1_1114;
r_1112 = r_2852;
z1_1113 = z1_2853;
d1_1114 = d1_2854;
{
obj_t fun1589_2297;
{
obj_t arg1592_2298;
arg1592_2298 = vector_plus_240___match_descriptions(d_2845, i_2846, d1_1114);
fun1589_2297 = compile___match_compiler(f2_2847, e_2848, r_1112, m_2849, k_2850, z_2851, arg1592_2298);
}
return PROCEDURE_ENTRY(fun1589_2297)(fun1589_2297, _2__168___r4_numbers_6_5(i_2846, BINT(((long)1))), BEOA);
}
}
}
}


/* compile-struct-pat */obj_t compile_struct_pat_210___match_compiler(obj_t f_151, obj_t e_152, obj_t r_153, obj_t m_154, obj_t k_155, obj_t z_156, obj_t d_157)
{
{
obj_t nom_1148;
{
obj_t aux_3817;
aux_3817 = CDR(f_151);
nom_1148 = CAR(aux_3817);
}
{
obj_t p__29_1149;
{
obj_t aux_3820;
aux_3820 = CDR(f_151);
p__29_1149 = CDR(aux_3820);
}
{
obj_t _k__26_1150;
_k__26_1150 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2114___match_compiler, BEOA);
{
obj_t _vars__115_1151;
_vars__115_1151 = pattern_variables_45___match_descriptions(f_151);
{
obj_t _call__27_1152;
{
obj_t arg1649_1182;
{
obj_t arg1653_1185;
arg1653_1185 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1649_1182 = append_2_18___r4_pairs_and_lists_6_3(_vars__115_1151, arg1653_1185);
}
{
obj_t list1650_1183;
list1650_1183 = MAKE_PAIR(arg1649_1182, BNIL);
_call__27_1152 = cons__138___r4_pairs_and_lists_6_3(_k__26_1150, list1650_1183);
}
}
{
obj_t success_form_130_1153;
{
obj_t arg1648_1181;
arg1648_1181 = extend__2082_96___match_compiler(r_153, _vars__115_1151);
success_form_130_1153 = PROCEDURE_ENTRY(k_155)(k_155, arg1648_1181, z_156, d_157, BEOA);
}
{
obj_t failure_form_185_1154;
failure_form_185_1154 = PROCEDURE_ENTRY(z_156)(z_156, d_157, BEOA);
{
obj_t indexes_1155;
{
obj_t aux_3835;
{
obj_t aux_3836;
{
long aux_3837;
aux_3837 = list_length(p__29_1149);
aux_3836 = BINT(aux_3837);
}
aux_3835 = _2__79___r4_numbers_6_5(aux_3836, BINT(((long)1)));
}
indexes_1155 = integers_2083___match_compiler(aux_3835, BINT(((long)0)));
}
{
{
obj_t arg1622_1156;
obj_t arg1623_1157;
{
obj_t arg1624_1158;
{
obj_t arg1630_1163;
{
obj_t arg1632_1164;
arg1632_1164 = SYMBOL_TO_STRING(nom_1148);
arg1630_1163 = string_append(arg1632_1164, string2133___match_compiler);
}
{
char * aux_3846;
aux_3846 = BSTRING_TO_STRING(arg1630_1163);
arg1624_1158 = string_to_symbol(aux_3846);
}
}
{
obj_t list1626_1160;
{
obj_t arg1627_1161;
arg1627_1161 = MAKE_PAIR(BNIL, BNIL);
list1626_1160 = MAKE_PAIR(e_152, arg1627_1161);
}
arg1622_1156 = cons__138___r4_pairs_and_lists_6_3(arg1624_1158, list1626_1160);
}
}
{
obj_t arg1638_1168;
arg1638_1168 = list2085___match_compiler;
{
obj_t arg1636_2855;
arg1636_2855 = make_fx_procedure(arg1636___match_compiler, ((long)1), ((long)1));
PROCEDURE_SET(arg1636_2855, ((long)0), failure_form_185_1154);
arg1623_1157 = compile__2081_179___match_compiler(success_form_130_1153, arg1636_2855, m_154, e_152, failure_form_185_1154, p__29_1149, indexes_1155, r_153, arg1638_1168);
}
}
return build_if_78___match_compiler(arg1622_1156, arg1623_1157, failure_form_185_1154);
}
}
}
}
}
}
}
}
}
}
}


/* extend*_2082 */obj_t extend__2082_96___match_compiler(obj_t r_2885, obj_t v__41_2336)
{
if(NULLP(v__41_2336)){
return r_2885;
}
 else {
obj_t arg1693_2338;
obj_t arg1694_2339;
obj_t arg1695_2340;
arg1693_2338 = extend__2082_96___match_compiler(r_2885, CDR(v__41_2336));
arg1694_2339 = CAR(v__41_2336);
arg1695_2340 = symbol2116___match_compiler;
return extend_alist_122___match_compiler(arg1693_2338, arg1694_2339, arg1695_2340);
}
}


/* integers_2083 */obj_t integers_2083___match_compiler(obj_t arg1645_2886, obj_t from_2346)
{
if(_2__206___r4_numbers_6_5(from_2346, arg1645_2886)){
return BNIL;
}
 else {
obj_t arg1881_2351;
arg1881_2351 = integers_2083___match_compiler(arg1645_2886, _2__168___r4_numbers_6_5(from_2346, BINT(((long)1))));
return MAKE_PAIR(from_2346, arg1881_2351);
}
}


/* compile*_2081 */obj_t compile__2081_179___match_compiler(obj_t success_form_130_2862, obj_t arg1636_2861, obj_t m_2860, obj_t e_2859, obj_t failure_form_185_2858, obj_t p__29_2358, obj_t i__115_2359, obj_t r_2360, obj_t d_2361)
{
if(NULLP(p__29_2358)){
return success_form_130_2862;
}
 else {
obj_t arg1657_2363;
obj_t arg1658_2364;
obj_t arg1661_2365;
arg1657_2363 = CAR(p__29_2358);
{
obj_t arg1663_2366;
obj_t arg1665_2367;
arg1663_2366 = symbol2134___match_compiler;
arg1665_2367 = CAR(i__115_2359);
{
obj_t list1667_2369;
{
obj_t arg1668_2370;
{
obj_t arg1669_2371;
arg1669_2371 = MAKE_PAIR(BNIL, BNIL);
arg1668_2370 = MAKE_PAIR(arg1665_2367, arg1669_2371);
}
list1667_2369 = MAKE_PAIR(e_2859, arg1668_2370);
}
arg1658_2364 = cons__138___r4_pairs_and_lists_6_3(arg1663_2366, list1667_2369);
}
}
arg1661_2365 = list2085___match_compiler;
{
obj_t arg1659_2856;
arg1659_2856 = make_fx_procedure(arg1659___match_compiler, ((long)3), ((long)7));
PROCEDURE_SET(arg1659_2856, ((long)0), failure_form_185_2858);
PROCEDURE_SET(arg1659_2856, ((long)1), e_2859);
PROCEDURE_SET(arg1659_2856, ((long)2), m_2860);
PROCEDURE_SET(arg1659_2856, ((long)3), arg1636_2861);
PROCEDURE_SET(arg1659_2856, ((long)4), success_form_130_2862);
PROCEDURE_SET(arg1659_2856, ((long)5), p__29_2358);
PROCEDURE_SET(arg1659_2856, ((long)6), i__115_2359);
return compile___match_compiler(arg1657_2363, arg1658_2364, r_2360, m_2860, arg1659_2856, arg1636_2861, arg1661_2365);
}
}
}


/* arg1636 */obj_t arg1636___match_compiler(obj_t env_2863, obj_t d_2865)
{
{
obj_t failure_form_185_2864;
failure_form_185_2864 = PROCEDURE_REF(env_2863, ((long)0));
return failure_form_185_2864;
}
}


/* arg1659 */obj_t arg1659___match_compiler(obj_t env_2866, obj_t rr_2874, obj_t zz_2875, obj_t dd_2876)
{
{
obj_t failure_form_185_2867;
obj_t e_2868;
obj_t m_2869;
obj_t arg1636_2870;
obj_t success_form_130_2871;
obj_t p__29_2872;
obj_t i__115_2873;
failure_form_185_2867 = PROCEDURE_REF(env_2866, ((long)0));
e_2868 = PROCEDURE_REF(env_2866, ((long)1));
m_2869 = PROCEDURE_REF(env_2866, ((long)2));
arg1636_2870 = PROCEDURE_REF(env_2866, ((long)3));
success_form_130_2871 = PROCEDURE_REF(env_2866, ((long)4));
p__29_2872 = PROCEDURE_REF(env_2866, ((long)5));
i__115_2873 = PROCEDURE_REF(env_2866, ((long)6));
{
obj_t rr_2374;
obj_t zz_2375;
obj_t dd_2376;
rr_2374 = rr_2874;
zz_2375 = zz_2875;
dd_2376 = dd_2876;
return compile__2081_179___match_compiler(success_form_130_2871, arg1636_2870, m_2869, e_2868, failure_form_185_2867, CDR(p__29_2872), CDR(i__115_2873), rr_2374, list2085___match_compiler);
}
}
}


/* _k.init */obj_t _k_init_136___match_compiler(obj_t env_2645, obj_t r_2646, obj_t z_2647, obj_t d_2648)
{
return BBOOL(((bool_t)1));
}


/* _z.init */obj_t _z_init_73___match_compiler(obj_t env_2649, obj_t d_2650)
{
return BBOOL(((bool_t)0));
}


/* extend-alist */obj_t extend_alist_122___match_compiler(obj_t l_172, obj_t pt_173, obj_t im_174)
{
{
obj_t arg1680_2474;
obj_t arg1681_2475;
{
obj_t list1684_2476;
list1684_2476 = MAKE_PAIR(im_174, BNIL);
arg1680_2474 = cons__138___r4_pairs_and_lists_6_3(pt_173, list1684_2476);
}
{
obj_t arg1686_2478;
arg1686_2478 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1681_2475 = append_2_18___r4_pairs_and_lists_6_3(l_172, arg1686_2478);
}
{
obj_t list1682_2481;
list1682_2481 = MAKE_PAIR(arg1681_2475, BNIL);
return cons__138___r4_pairs_and_lists_6_3(arg1680_2474, list1682_2481);
}
}
}


/* m.init */obj_t m_init_175___match_compiler(obj_t n_179)
{
{
obj_t lambda1698_2877;
lambda1698_2877 = make_fx_procedure(lambda1698___match_compiler, ((long)5), ((long)1));
PROCEDURE_SET(lambda1698_2877, ((long)0), n_179);
return lambda1698_2877;
}
}


/* _m.init */obj_t _m_init_247___match_compiler(obj_t env_2643, obj_t n_2644)
{
return m_init_175___match_compiler(n_2644);
}


/* lambda1698 */obj_t lambda1698___match_compiler(obj_t env_2878, obj_t e_2880, obj_t r_2881, obj_t k_2882, obj_t z_2883, obj_t c_2884)
{
{
obj_t n_2879;
n_2879 = PROCEDURE_REF(env_2878, ((long)0));
{
obj_t e_2517;
obj_t r_2518;
obj_t k_2519;
obj_t z_2520;
obj_t c_2521;
e_2517 = e_2880;
r_2518 = r_2881;
k_2519 = k_2882;
z_2520 = z_2883;
c_2521 = c_2884;
{
obj_t list1699_2526;
{
obj_t arg1701_2528;
arg1701_2528 = MAKE_PAIR(n_2879, BNIL);
list1699_2526 = MAKE_PAIR(string2135___match_compiler, arg1701_2528);
}
FAILURE(string2102___match_compiler,list1699_2526,string2103___match_compiler);}
}
}
}


/* build-if */obj_t build_if_78___match_compiler(obj_t tst_187, obj_t then_188, obj_t else_189)
{
if((tst_187==BTRUE)){
return then_188;
}
 else {
if((tst_187==BFALSE)){
return else_189;
}
 else {
bool_t test_3915;
if((then_188==BTRUE)){
test_3915 = (else_189==BFALSE);
}
 else {
test_3915 = ((bool_t)0);
}
if(test_3915){
return tst_187;
}
 else {
bool_t test_3919;
if((then_188==BFALSE)){
test_3919 = (else_189==BTRUE);
}
 else {
test_3919 = ((bool_t)0);
}
if(test_3919){
{
obj_t arg1713_1249;
arg1713_1249 = symbol2094___match_compiler;
{
obj_t list1715_1251;
{
obj_t arg1716_1252;
arg1716_1252 = MAKE_PAIR(BNIL, BNIL);
list1715_1251 = MAKE_PAIR(tst_187, arg1716_1252);
}
return cons__138___r4_pairs_and_lists_6_3(arg1713_1249, list1715_1251);
}
}
}
 else {
{
obj_t arg1718_1254;
arg1718_1254 = symbol2090___match_compiler;
{
obj_t list1721_1256;
{
obj_t arg1722_1257;
{
obj_t arg1723_1258;
{
obj_t arg1724_1259;
arg1724_1259 = MAKE_PAIR(BNIL, BNIL);
arg1723_1258 = MAKE_PAIR(else_189, arg1724_1259);
}
arg1722_1257 = MAKE_PAIR(then_188, arg1723_1258);
}
list1721_1256 = MAKE_PAIR(tst_187, arg1722_1257);
}
return cons__138___r4_pairs_and_lists_6_3(arg1718_1254, list1721_1256);
}
}
}
}
}
}
}


/* build-let */obj_t build_let_227___match_compiler(obj_t _car__246_190, obj_t _cdr__54_191, obj_t e_192, obj_t body_193)
{
{
bool_t test1728_1263;
{
obj_t arg1866_1372;
arg1866_1372 = count_occurrences_123___match_compiler(_car__246_190, body_193, ((long)0));
test1728_1263 = _2__206___r4_numbers_6_5(arg1866_1372, BINT(((long)1)));
}
if(test1728_1263){
bool_t test1729_1264;
{
obj_t arg1810_1326;
arg1810_1326 = count_occurrences_123___match_compiler(_cdr__54_191, body_193, ((long)0));
test1729_1264 = _2__206___r4_numbers_6_5(arg1810_1326, BINT(((long)1)));
}
if(test1729_1264){
obj_t arg1730_1265;
obj_t arg1731_1266;
arg1730_1265 = symbol2120___match_compiler;
{
obj_t arg1743_1272;
obj_t arg1744_1273;
{
obj_t arg1749_1278;
{
obj_t arg1759_1283;
arg1759_1283 = symbol2136___match_compiler;
{
obj_t list1761_1285;
{
obj_t arg1762_1286;
arg1762_1286 = MAKE_PAIR(BNIL, BNIL);
list1761_1285 = MAKE_PAIR(e_192, arg1762_1286);
}
arg1749_1278 = cons__138___r4_pairs_and_lists_6_3(arg1759_1283, list1761_1285);
}
}
{
obj_t list1754_1280;
{
obj_t arg1755_1281;
arg1755_1281 = MAKE_PAIR(BNIL, BNIL);
list1754_1280 = MAKE_PAIR(arg1749_1278, arg1755_1281);
}
arg1743_1272 = cons__138___r4_pairs_and_lists_6_3(_car__246_190, list1754_1280);
}
}
{
obj_t arg1766_1288;
{
obj_t arg1771_1293;
arg1771_1293 = symbol2137___match_compiler;
{
obj_t list1773_1295;
{
obj_t arg1774_1296;
arg1774_1296 = MAKE_PAIR(BNIL, BNIL);
list1773_1295 = MAKE_PAIR(e_192, arg1774_1296);
}
arg1766_1288 = cons__138___r4_pairs_and_lists_6_3(arg1771_1293, list1773_1295);
}
}
{
obj_t list1768_1290;
{
obj_t arg1769_1291;
arg1769_1291 = MAKE_PAIR(BNIL, BNIL);
list1768_1290 = MAKE_PAIR(arg1766_1288, arg1769_1291);
}
arg1744_1273 = cons__138___r4_pairs_and_lists_6_3(_cdr__54_191, list1768_1290);
}
}
{
obj_t list1746_1275;
{
obj_t arg1747_1276;
arg1747_1276 = MAKE_PAIR(BNIL, BNIL);
list1746_1275 = MAKE_PAIR(arg1744_1273, arg1747_1276);
}
arg1731_1266 = cons__138___r4_pairs_and_lists_6_3(arg1743_1272, list1746_1275);
}
}
{
obj_t list1733_1268;
{
obj_t arg1738_1269;
{
obj_t arg1739_1270;
arg1739_1270 = MAKE_PAIR(BNIL, BNIL);
arg1738_1269 = MAKE_PAIR(body_193, arg1739_1270);
}
list1733_1268 = MAKE_PAIR(arg1731_1266, arg1738_1269);
}
return cons__138___r4_pairs_and_lists_6_3(arg1730_1265, list1733_1268);
}
}
 else {
obj_t arg1777_1298;
obj_t arg1778_1299;
obj_t arg1779_1300;
arg1777_1298 = symbol2120___match_compiler;
{
obj_t arg1789_1306;
{
obj_t arg1793_1310;
{
obj_t arg1799_1315;
arg1799_1315 = symbol2136___match_compiler;
{
obj_t list1801_1317;
{
obj_t arg1802_1318;
arg1802_1318 = MAKE_PAIR(BNIL, BNIL);
list1801_1317 = MAKE_PAIR(e_192, arg1802_1318);
}
arg1793_1310 = cons__138___r4_pairs_and_lists_6_3(arg1799_1315, list1801_1317);
}
}
{
obj_t list1795_1312;
{
obj_t arg1796_1313;
arg1796_1313 = MAKE_PAIR(BNIL, BNIL);
list1795_1312 = MAKE_PAIR(arg1793_1310, arg1796_1313);
}
arg1789_1306 = cons__138___r4_pairs_and_lists_6_3(_car__246_190, list1795_1312);
}
}
{
obj_t list1791_1308;
list1791_1308 = MAKE_PAIR(BNIL, BNIL);
arg1778_1299 = cons__138___r4_pairs_and_lists_6_3(arg1789_1306, list1791_1308);
}
}
{
obj_t arg1804_1320;
{
obj_t arg1805_1321;
arg1805_1321 = symbol2137___match_compiler;
{
obj_t list1807_1323;
{
obj_t arg1808_1324;
arg1808_1324 = MAKE_PAIR(BNIL, BNIL);
list1807_1323 = MAKE_PAIR(e_192, arg1808_1324);
}
arg1804_1320 = cons__138___r4_pairs_and_lists_6_3(arg1805_1321, list1807_1323);
}
}
arg1779_1300 = unfold___match_compiler(_cdr__54_191, arg1804_1320, body_193);
}
{
obj_t list1781_1302;
{
obj_t arg1783_1303;
{
obj_t arg1786_1304;
arg1786_1304 = MAKE_PAIR(BNIL, BNIL);
arg1783_1303 = MAKE_PAIR(arg1779_1300, arg1786_1304);
}
list1781_1302 = MAKE_PAIR(arg1778_1299, arg1783_1303);
}
return cons__138___r4_pairs_and_lists_6_3(arg1777_1298, list1781_1302);
}
}
}
 else {
bool_t test1812_1328;
{
obj_t arg1864_1370;
arg1864_1370 = count_occurrences_123___match_compiler(_cdr__54_191, body_193, ((long)0));
test1812_1328 = _2__206___r4_numbers_6_5(arg1864_1370, BINT(((long)1)));
}
if(test1812_1328){
obj_t arg1813_1329;
obj_t arg1814_1330;
obj_t arg1815_1331;
arg1813_1329 = symbol2120___match_compiler;
{
obj_t arg1822_1337;
{
obj_t arg1827_1341;
{
obj_t arg1833_1346;
arg1833_1346 = symbol2137___match_compiler;
{
obj_t list1835_1348;
{
obj_t arg1836_1349;
arg1836_1349 = MAKE_PAIR(BNIL, BNIL);
list1835_1348 = MAKE_PAIR(e_192, arg1836_1349);
}
arg1827_1341 = cons__138___r4_pairs_and_lists_6_3(arg1833_1346, list1835_1348);
}
}
{
obj_t list1830_1343;
{
obj_t arg1831_1344;
arg1831_1344 = MAKE_PAIR(BNIL, BNIL);
list1830_1343 = MAKE_PAIR(arg1827_1341, arg1831_1344);
}
arg1822_1337 = cons__138___r4_pairs_and_lists_6_3(_cdr__54_191, list1830_1343);
}
}
{
obj_t list1824_1339;
list1824_1339 = MAKE_PAIR(BNIL, BNIL);
arg1814_1330 = cons__138___r4_pairs_and_lists_6_3(arg1822_1337, list1824_1339);
}
}
{
obj_t arg1838_1351;
{
obj_t arg1839_1352;
arg1839_1352 = symbol2136___match_compiler;
{
obj_t list1843_1354;
{
obj_t arg1847_1355;
arg1847_1355 = MAKE_PAIR(BNIL, BNIL);
list1843_1354 = MAKE_PAIR(e_192, arg1847_1355);
}
arg1838_1351 = cons__138___r4_pairs_and_lists_6_3(arg1839_1352, list1843_1354);
}
}
arg1815_1331 = unfold___match_compiler(_car__246_190, arg1838_1351, body_193);
}
{
obj_t list1817_1333;
{
obj_t arg1818_1334;
{
obj_t arg1820_1335;
arg1820_1335 = MAKE_PAIR(BNIL, BNIL);
arg1818_1334 = MAKE_PAIR(arg1815_1331, arg1820_1335);
}
list1817_1333 = MAKE_PAIR(arg1814_1330, arg1818_1334);
}
return cons__138___r4_pairs_and_lists_6_3(arg1813_1329, list1817_1333);
}
}
 else {
obj_t arg1850_1357;
obj_t arg1851_1358;
{
obj_t arg1852_1359;
arg1852_1359 = symbol2137___match_compiler;
{
obj_t list1854_1361;
{
obj_t arg1856_1362;
arg1856_1362 = MAKE_PAIR(BNIL, BNIL);
list1854_1361 = MAKE_PAIR(e_192, arg1856_1362);
}
arg1850_1357 = cons__138___r4_pairs_and_lists_6_3(arg1852_1359, list1854_1361);
}
}
{
obj_t arg1858_1364;
{
obj_t arg1859_1365;
arg1859_1365 = symbol2136___match_compiler;
{
obj_t list1861_1367;
{
obj_t arg1862_1368;
arg1862_1368 = MAKE_PAIR(BNIL, BNIL);
list1861_1367 = MAKE_PAIR(e_192, arg1862_1368);
}
arg1858_1364 = cons__138___r4_pairs_and_lists_6_3(arg1859_1365, list1861_1367);
}
}
arg1851_1358 = unfold___match_compiler(_car__246_190, arg1858_1364, body_193);
}
return unfold___match_compiler(_cdr__54_191, arg1850_1357, arg1851_1358);
}
}
}
}


/* unfold */obj_t unfold___match_compiler(obj_t s_194, obj_t v_195, obj_t e_196)
{
if(NULLP(e_196)){
return BNIL;
}
 else {
bool_t test1869_1375;
{
obj_t aux_4004;
aux_4004 = atom__231___match_s2cfun(e_196);
test1869_1375 = CBOOL(aux_4004);
}
if(test1869_1375){
if((e_196==s_194)){
return v_195;
}
 else {
return e_196;
}
}
 else {
if(PAIRP(e_196)){
bool_t test_4012;
{
obj_t aux_4013;
aux_4013 = CAR(e_196);
test_4012 = (aux_4013==symbol2091___match_compiler);
}
if(test_4012){
return e_196;
}
 else {
obj_t arg1874_1381;
obj_t arg1875_1382;
arg1874_1381 = unfold___match_compiler(s_194, v_195, CAR(e_196));
arg1875_1382 = unfold___match_compiler(s_194, v_195, CDR(e_196));
{
obj_t list1876_1383;
list1876_1383 = MAKE_PAIR(arg1875_1382, BNIL);
return cons__138___r4_pairs_and_lists_6_3(arg1874_1381, list1876_1383);
}
}
}
 else {
return BUNSPEC;
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___match_compiler()
{
module_initialization_70___error(((long)0), "__MATCH_COMPILER");
module_initialization_70___match_s2cfun(((long)0), "__MATCH_COMPILER");
return module_initialization_70___match_descriptions(((long)0), "__MATCH_COMPILER");
}

