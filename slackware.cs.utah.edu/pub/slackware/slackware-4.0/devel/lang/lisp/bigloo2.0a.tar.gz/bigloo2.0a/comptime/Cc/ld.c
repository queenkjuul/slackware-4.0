/*===========================================================================*/
/*   (Cc/ld.scm)                                                             */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t list_of_string__string_91_cc_ld(obj_t);
extern obj_t _profile_library__193_engine_param;
extern obj_t _cc__215_engine_param;
extern obj_t string_append(obj_t, obj_t);
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t _unsafe_library__118_engine_param;
extern bool_t rgc_fill_buffer(obj_t);
extern obj_t _bdb_debug__1_engine_param;
static obj_t select_library_131_cc_ld(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1316_cc_ld(obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _additional_bigloo_libraries__50_engine_param;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t _bigloo_user_lib__33_engine_param;
extern obj_t module_initialization_70_cc_ld(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_cc_exec(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t make_shared_library_name_78___os(obj_t);
static obj_t make_lib_name_123_cc_ld(obj_t, obj_t);
extern obj_t _strip__173_engine_param;
extern obj_t os_class_179___os;
static obj_t unix_ld_202_cc_ld(obj_t, bool_t);
static obj_t imported_modules_init_94_cc_ld();
extern obj_t _bigloo_lib__121_engine_param;
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t _dest__217_engine_param;
extern obj_t _cc_options__252_engine_param;
extern obj_t make_static_library_name_134___os(obj_t);
extern bool_t bigloo_strcmp(obj_t, obj_t);
static obj_t library_modules_init_112_cc_ld();
extern obj_t _with_files__6_engine_param;
extern obj_t _c_debug_option__198_engine_param;
extern obj_t _o_files__27_engine_param;
extern obj_t open_input_string(obj_t);
static obj_t lib_suffix_185_cc_ld(obj_t, obj_t);
static obj_t lambda1320_cc_ld(obj_t, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t _lib_dir__34_engine_param;
static obj_t loop_cc_ld(obj_t);
extern obj_t _static_bigloo___233_engine_param;
extern obj_t close_input_port(obj_t);
extern obj_t _gc_lib__201_engine_param;
extern obj_t exec_cc_exec(obj_t, bool_t, obj_t);
extern obj_t ld_cc_ld(obj_t, bool_t);
extern obj_t _ld_options__88_engine_param;
extern obj_t _c_debug__136_engine_param;
static obj_t _ld_cc_ld(obj_t, obj_t, obj_t);
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114_cc_ld = BUNSPEC;
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE(proc1460_cc_ld, lambda1320_cc_ld1465, lambda1320_cc_ld, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ld_env_66_cc_ld, _ld_cc_ld1466, _ld_cc_ld, 0L, 2);
DEFINE_STRING(string1463_cc_ld, string1463_cc_ld1467, "Illegal match", 13);
DEFINE_STRING(string1462_cc_ld, string1462_cc_ld1468, "regular-grammar", 15);
DEFINE_STRING(string1461_cc_ld, string1461_cc_ld1469, "-L", 2);
DEFINE_STRING(string1459_cc_ld, string1459_cc_ld1470, "      [", 7);
DEFINE_STRING(string1458_cc_ld, string1458_cc_ld1471, ".o", 2);
DEFINE_STRING(string1457_cc_ld, string1457_cc_ld1472, " -o ", 4);
DEFINE_STRING(string1456_cc_ld, string1456_cc_ld1473, "libbdb", 6);
DEFINE_STRING(string1455_cc_ld, string1455_cc_ld1474, "lib", 3);
DEFINE_STRING(string1454_cc_ld, string1454_cc_ld1475, "a.out", 5);
DEFINE_STRING(string1453_cc_ld, string1453_cc_ld1476, "   . ld (", 9);
DEFINE_STRING(string1452_cc_ld, string1452_cc_ld1477, ")", 1);
DEFINE_STRING(string1451_cc_ld, string1451_cc_ld1478, "_u", 2);
DEFINE_STRING(string1449_cc_ld, string1449_cc_ld1479, "Can't find library", 18);
DEFINE_STRING(string1450_cc_ld, string1450_cc_ld1480, "_p", 2);
DEFINE_STRING(string1448_cc_ld, string1448_cc_ld1481, "make-lib-name", 13);
DEFINE_STRING(string1447_cc_ld, string1447_cc_ld1482, "Unknow os", 9);
DEFINE_STRING(string1446_cc_ld, string1446_cc_ld1483, "ld", 2);
DEFINE_STRING(string1445_cc_ld, string1445_cc_ld1484, "unix", 4);
DEFINE_STRING(string1444_cc_ld, string1444_cc_ld1485, "", 0);
DEFINE_STRING(string1443_cc_ld, string1443_cc_ld1486, " ", 1);


/* module-initialization */ obj_t 
module_initialization_70_cc_ld(long checksum_577, char *from_578)
{
   if (CBOOL(require_initialization_114_cc_ld))
     {
	require_initialization_114_cc_ld = BBOOL(((bool_t) 0));
	library_modules_init_112_cc_ld();
	imported_modules_init_94_cc_ld();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cc_ld()
{
   module_initialization_70___bexit(((long) 0), "CC_LD");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CC_LD");
   module_initialization_70___os(((long) 0), "CC_LD");
   module_initialization_70___r4_strings_6_7(((long) 0), "CC_LD");
   return BUNSPEC;
}


/* list-of-string->string */ obj_t 
list_of_string__string_91_cc_ld(obj_t l_1)
{
   {
      obj_t l_11;
      obj_t r_12;
      l_11 = reverse___r4_pairs_and_lists_6_3(l_1);
      r_12 = string1444_cc_ld;
    loop_13:
      if (NULLP(l_11))
	{
	   return r_12;
	}
      else
	{
	   obj_t arg1034_17;
	   obj_t arg1038_18;
	   arg1034_17 = CDR(l_11);
	   {
	      obj_t arg1039_19;
	      arg1039_19 = CAR(l_11);
	      {
		 obj_t list1041_21;
		 {
		    obj_t arg1053_22;
		    {
		       obj_t arg1055_23;
		       arg1055_23 = MAKE_PAIR(r_12, BNIL);
		       arg1053_22 = MAKE_PAIR(string1443_cc_ld, arg1055_23);
		    }
		    list1041_21 = MAKE_PAIR(arg1039_19, arg1053_22);
		 }
		 arg1038_18 = string_append_106___r4_strings_6_7(list1041_21);
	      }
	   }
	   {
	      obj_t r_597;
	      obj_t l_596;
	      l_596 = arg1034_17;
	      r_597 = arg1038_18;
	      r_12 = r_597;
	      l_11 = l_596;
	      goto loop_13;
	   }
	}
   }
}


/* ld */ obj_t 
ld_cc_ld(obj_t name_2, bool_t need_to_return_234_3)
{
   {
      bool_t test1067_25;
      {
	 obj_t arg1144_30;
	 arg1144_30 = PROCEDURE_ENTRY(os_class_179___os) (os_class_179___os, BEOA);
	 test1067_25 = bigloo_strcmp(arg1144_30, string1445_cc_ld);
      }
      if (test1067_25)
	{
	   return unix_ld_202_cc_ld(name_2, need_to_return_234_3);
	}
      else
	{
	   {
	      obj_t arg1142_28;
	      arg1142_28 = PROCEDURE_ENTRY(os_class_179___os) (os_class_179___os, BEOA);
	      return user_error_151_tools_error(string1446_cc_ld, string1447_cc_ld, arg1142_28, BNIL);
	   }
	}
   }
}


/* _ld */ obj_t 
_ld_cc_ld(obj_t env_570, obj_t name_571, obj_t need_to_return_234_572)
{
   return ld_cc_ld(name_571, CBOOL(need_to_return_234_572));
}


/* lib+suffix */ obj_t 
lib_suffix_185_cc_ld(obj_t lib_4, obj_t static__117_5)
{
   {
      bool_t test1146_32;
      if (CBOOL(static__117_5))
	{
	   test1146_32 = ((bool_t) 1);
	}
      else
	{
	   if (CBOOL(_static_bigloo___233_engine_param))
	     {
		test1146_32 = ((bool_t) 1);
	     }
	   else
	     {
		if (HAVE_SHARED_LIBRARY)
		  {
		     test1146_32 = ((bool_t) 0);
		  }
		else
		  {
		     test1146_32 = ((bool_t) 1);
		  }
	     }
	}
      if (test1146_32)
	{
	   return make_static_library_name_134___os(lib_4);
	}
      else
	{
	   return make_shared_library_name_78___os(lib_4);
	}
   }
}


/* make-lib-name */ obj_t 
make_lib_name_123_cc_ld(obj_t lib_name_97_6, obj_t static__117_7)
{
   {
      obj_t name_33;
      {
	 obj_t arg1150_35;
	 arg1150_35 = lib_suffix_185_cc_ld(lib_name_97_6, static__117_7);
	 name_33 = find_file_path_55_tools_file(arg1150_35, _lib_dir__34_engine_param);
      }
      if (STRINGP(name_33))
	{
	   return name_33;
	}
      else
	{
	   FAILURE(string1448_cc_ld, string1449_cc_ld, lib_name_97_6);
	}
   }
}


/* select-library */ obj_t 
select_library_131_cc_ld(obj_t lib_name_97_8)
{
   if (CBOOL(_profile_library__193_engine_param))
     {
	return string_append(lib_name_97_8, string1450_cc_ld);
     }
   else
     {
	if (CBOOL(_unsafe_library__118_engine_param))
	  {
	     return string_append(lib_name_97_8, string1451_cc_ld);
	  }
	else
	  {
	     return lib_name_97_8;
	  }
     }
}


/* unix-ld */ obj_t 
unix_ld_202_cc_ld(obj_t name_9, bool_t need_to_return_234_10)
{
   {
      obj_t list1151_36;
      {
	 obj_t arg1161_38;
	 {
	    obj_t arg1163_39;
	    {
	       obj_t arg1176_41;
	       {
		  obj_t aux_628;
		  aux_628 = BCHAR(((unsigned char) '\n'));
		  arg1176_41 = MAKE_PAIR(aux_628, BNIL);
	       }
	       arg1163_39 = MAKE_PAIR(string1452_cc_ld, arg1176_41);
	    }
	    arg1161_38 = MAKE_PAIR(_cc__215_engine_param, arg1163_39);
	 }
	 list1151_36 = MAKE_PAIR(string1453_cc_ld, arg1161_38);
      }
      verbose_tools_speek(BINT(((long) 1)), list1151_36);
   }
   {
      obj_t static__117_43;
      {
	 obj_t port1002_162;
	 {
	    obj_t string_391;
	    string_391 = _ld_options__88_engine_param;
	    port1002_162 = open_input_string(string_391);
	 }
	 {
	    obj_t val1003_163;
	    val1003_163 = handling_function1316_cc_ld(port1002_162);
	    close_input_port(port1002_162);
	    {
	       bool_t test1312_164;
	       {
		  obj_t aux_639;
		  aux_639 = val_from_exit__100___bexit(val1003_163);
		  test1312_164 = CBOOL(aux_639);
	       }
	       if (test1312_164)
		 {
		    static__117_43 = unwind_until__178___bexit(CAR(val1003_163), CDR(val1003_163));
		 }
	       else
		 {
		    static__117_43 = val1003_163;
		 }
	    }
	 }
      }
      if (CBOOL(static__117_43))
	{
	   obj_t list1188_44;
	   {
	      obj_t arg1190_45;
	      {
		 obj_t arg1192_47;
		 arg1192_47 = MAKE_PAIR(_ld_options__88_engine_param, BNIL);
		 arg1190_45 = MAKE_PAIR(string1443_cc_ld, arg1192_47);
	      }
	      {
		 obj_t aux_650;
		 aux_650 = string_to_bstring(ADDITIONAL_STATIC_LINK_OPTION);
		 list1188_44 = MAKE_PAIR(aux_650, arg1190_45);
	      }
	   }
	   _ld_options__88_engine_param = string_append_106___r4_strings_6_7(list1188_44);
	}
      else
	{
	   obj_t list1194_49;
	   {
	      obj_t arg1195_50;
	      {
		 obj_t arg1197_52;
		 arg1197_52 = MAKE_PAIR(_ld_options__88_engine_param, BNIL);
		 arg1195_50 = MAKE_PAIR(string1443_cc_ld, arg1197_52);
	      }
	      {
		 obj_t aux_656;
		 aux_656 = string_to_bstring(ADDITIONAL_SHARED_LINK_OPTION);
		 list1194_49 = MAKE_PAIR(aux_656, arg1195_50);
	      }
	   }
	   _ld_options__88_engine_param = string_append_106___r4_strings_6_7(list1194_49);
	}
      {
	 obj_t dest_54;
	 {
	    bool_t test1311_161;
	    {
	       obj_t obj_556;
	       obj_556 = _dest__217_engine_param;
	       test1311_161 = STRINGP(obj_556);
	    }
	    if (test1311_161)
	      {
		 dest_54 = _dest__217_engine_param;
	      }
	    else
	      {
		 dest_54 = string1454_cc_ld;
	      }
	 }
	 {
	    obj_t lib_name_97_55;
	    {
	       obj_t arg1310_160;
	       arg1310_160 = select_library_131_cc_ld(_bigloo_lib__121_engine_param);
	       lib_name_97_55 = string_append(string1455_cc_ld, arg1310_160);
	    }
	    {
	       obj_t bigloo_lib_22_56;
	       bigloo_lib_22_56 = make_lib_name_123_cc_ld(lib_name_97_55, static__117_43);
	       {
		  obj_t gclib_name_240_57;
		  gclib_name_240_57 = string_append(string1455_cc_ld, _gc_lib__201_engine_param);
		  {
		     obj_t gc_lib_252_58;
		     gc_lib_252_58 = make_lib_name_123_cc_ld(gclib_name_240_57, static__117_43);
		     {
			obj_t bdb_lib_142_59;
			{
			   bool_t test1308_158;
			   {
			      long n1_557;
			      n1_557 = (long) CINT(_bdb_debug__1_engine_param);
			      test1308_158 = (n1_557 > ((long) 0));
			   }
			   if (test1308_158)
			     {
				bdb_lib_142_59 = make_lib_name_123_cc_ld(string1456_cc_ld, BTRUE);
			     }
			   else
			     {
				bdb_lib_142_59 = string1444_cc_ld;
			     }
			}
			{
			   obj_t add_libs_112_60;
			   {
			      obj_t lib_142;
			      obj_t res_143;
			      lib_142 = _additional_bigloo_libraries__50_engine_param;
			      res_143 = string1444_cc_ld;
			    loop_144:
			      if (NULLP(lib_142))
				{
				   add_libs_112_60 = res_143;
				}
			      else
				{
				   obj_t arg1294_146;
				   obj_t arg1295_147;
				   arg1294_146 = CDR(lib_142);
				   {
				      obj_t arg1296_148;
				      {
					 obj_t arg1302_154;
					 {
					    obj_t arg1304_156;
					    arg1304_156 = select_library_131_cc_ld(CAR(lib_142));
					    arg1302_154 = string_append(string1455_cc_ld, arg1304_156);
					 }
					 arg1296_148 = make_lib_name_123_cc_ld(arg1302_154, static__117_43);
				      }
				      {
					 obj_t list1298_150;
					 {
					    obj_t arg1299_151;
					    {
					       obj_t arg1300_152;
					       arg1300_152 = MAKE_PAIR(res_143, BNIL);
					       arg1299_151 = MAKE_PAIR(string1443_cc_ld, arg1300_152);
					    }
					    list1298_150 = MAKE_PAIR(arg1296_148, arg1299_151);
					 }
					 arg1295_147 = string_append_106___r4_strings_6_7(list1298_150);
				      }
				   }
				   {
				      obj_t res_683;
				      obj_t lib_682;
				      lib_682 = arg1294_146;
				      res_683 = arg1295_147;
				      res_143 = res_683;
				      lib_142 = lib_682;
				      goto loop_144;
				   }
				}
			   }
			   {
			      obj_t other_libs_24_61;
			      {
				 obj_t lib_130;
				 obj_t res_131;
				 lib_130 = _bigloo_user_lib__33_engine_param;
				 res_131 = string1444_cc_ld;
			       loop_132:
				 if (NULLP(lib_130))
				   {
				      other_libs_24_61 = res_131;
				   }
				 else
				   {
				      obj_t arg1285_134;
				      obj_t arg1286_135;
				      arg1285_134 = CDR(lib_130);
				      {
					 obj_t arg1287_136;
					 arg1287_136 = CAR(lib_130);
					 {
					    obj_t list1289_138;
					    {
					       obj_t arg1290_139;
					       {
						  obj_t arg1291_140;
						  arg1291_140 = MAKE_PAIR(res_131, BNIL);
						  arg1290_139 = MAKE_PAIR(string1443_cc_ld, arg1291_140);
					       }
					       list1289_138 = MAKE_PAIR(arg1287_136, arg1290_139);
					    }
					    arg1286_135 = string_append_106___r4_strings_6_7(list1289_138);
					 }
				      }
				      {
					 obj_t res_693;
					 obj_t lib_692;
					 lib_692 = arg1285_134;
					 res_693 = arg1286_135;
					 res_131 = res_693;
					 lib_130 = lib_692;
					 goto loop_132;
				      }
				   }
			      }
			      {
				 obj_t ld_args_181_62;
				 {
				    obj_t arg1216_78;
				    obj_t arg1219_79;
				    obj_t arg1222_82;
				    char *arg1224_83;
				    obj_t arg1226_85;
				    arg1216_78 = list_of_string__string_91_cc_ld(_with_files__6_engine_param);
				    arg1219_79 = list_of_string__string_91_cc_ld(_o_files__27_engine_param);
				    {
				       bool_t test1268_116;
				       if (CBOOL(_c_debug__136_engine_param))
					 {
					    test1268_116 = ((bool_t) 1);
					 }
				       else
					 {
					    long n1_565;
					    n1_565 = (long) CINT(_bdb_debug__1_engine_param);
					    test1268_116 = (n1_565 > ((long) 0));
					 }
				       if (test1268_116)
					 {
					    arg1222_82 = string_append(string1443_cc_ld, _c_debug_option__198_engine_param);
					 }
				       else
					 {
					    arg1222_82 = string1444_cc_ld;
					 }
				    }
				    if (CBOOL(_strip__173_engine_param))
				      {
					 arg1224_83 = " -s";
				      }
				    else
				      {
					 arg1224_83 = "";
				      }
				    arg1226_85 = loop_cc_ld(_lib_dir__34_engine_param);
				    {
				       obj_t list1235_91;
				       {
					  obj_t arg1236_92;
					  {
					     obj_t arg1238_93;
					     {
						obj_t arg1240_94;
						{
						   obj_t arg1241_95;
						   {
						      obj_t arg1243_96;
						      {
							 obj_t arg1244_97;
							 {
							    obj_t arg1245_98;
							    {
							       obj_t arg1247_99;
							       {
								  obj_t arg1248_100;
								  {
								     obj_t arg1250_101;
								     {
									obj_t arg1251_102;
									{
									   obj_t arg1252_103;
									   {
									      obj_t arg1253_104;
									      {
										 obj_t arg1254_105;
										 {
										    obj_t arg1255_106;
										    {
										       obj_t arg1256_107;
										       {
											  obj_t arg1257_108;
											  {
											     obj_t arg1258_109;
											     {
												obj_t arg1259_110;
												{
												   obj_t arg1260_111;
												   {
												      obj_t arg1262_112;
												      {
													 obj_t arg1263_113;
													 {
													    obj_t arg1265_114;
													    arg1265_114 = MAKE_PAIR(other_libs_24_61, BNIL);
													    arg1263_113 = MAKE_PAIR(string1443_cc_ld, arg1265_114);
													 }
													 arg1262_112 = MAKE_PAIR(gc_lib_252_58, arg1263_113);
												      }
												      arg1260_111 = MAKE_PAIR(string1443_cc_ld, arg1262_112);
												   }
												   arg1259_110 = MAKE_PAIR(bigloo_lib_22_56, arg1260_111);
												}
												arg1258_109 = MAKE_PAIR(string1443_cc_ld, arg1259_110);
											     }
											     arg1257_108 = MAKE_PAIR(add_libs_112_60, arg1258_109);
											  }
											  arg1256_107 = MAKE_PAIR(string1443_cc_ld, arg1257_108);
										       }
										       arg1255_106 = MAKE_PAIR(bdb_lib_142_59, arg1256_107);
										    }
										    arg1254_105 = MAKE_PAIR(string1443_cc_ld, arg1255_106);
										 }
										 arg1253_104 = MAKE_PAIR(arg1226_85, arg1254_105);
									      }
									      arg1252_103 = MAKE_PAIR(_ld_options__88_engine_param, arg1253_104);
									   }
									   arg1251_102 = MAKE_PAIR(string1443_cc_ld, arg1252_103);
									}
									{
									   obj_t aux_718;
									   aux_718 = string_to_bstring(arg1224_83);
									   arg1250_101 = MAKE_PAIR(aux_718, arg1251_102);
									}
								     }
								     arg1248_100 = MAKE_PAIR(arg1222_82, arg1250_101);
								  }
								  arg1247_99 = MAKE_PAIR(_cc_options__252_engine_param, arg1248_100);
							       }
							       arg1245_98 = MAKE_PAIR(string1443_cc_ld, arg1247_99);
							    }
							    arg1244_97 = MAKE_PAIR(dest_54, arg1245_98);
							 }
							 arg1243_96 = MAKE_PAIR(string1457_cc_ld, arg1244_97);
						      }
						      arg1241_95 = MAKE_PAIR(arg1219_79, arg1243_96);
						   }
						   arg1240_94 = MAKE_PAIR(arg1216_78, arg1241_95);
						}
						arg1238_93 = MAKE_PAIR(string1443_cc_ld, arg1240_94);
					     }
					     arg1236_92 = MAKE_PAIR(string1458_cc_ld, arg1238_93);
					  }
					  list1235_91 = MAKE_PAIR(name_9, arg1236_92);
				       }
				       ld_args_181_62 = string_append_106___r4_strings_6_7(list1235_91);
				    }
				 }
				 {
				    obj_t cmd_ld_108_63;
				    {
				       obj_t list1206_71;
				       {
					  obj_t arg1207_72;
					  {
					     obj_t arg1210_74;
					     arg1210_74 = MAKE_PAIR(ld_args_181_62, BNIL);
					     arg1207_72 = MAKE_PAIR(string1443_cc_ld, arg1210_74);
					  }
					  list1206_71 = MAKE_PAIR(_cc__215_engine_param, arg1207_72);
				       }
				       cmd_ld_108_63 = string_append_106___r4_strings_6_7(list1206_71);
				    }
				    {
				       {
					  obj_t list1200_65;
					  {
					     obj_t arg1202_67;
					     {
						obj_t arg1203_68;
						{
						   obj_t arg1204_69;
						   {
						      obj_t aux_736;
						      aux_736 = BCHAR(((unsigned char) '\n'));
						      arg1204_69 = MAKE_PAIR(aux_736, BNIL);
						   }
						   {
						      obj_t aux_739;
						      aux_739 = BCHAR(((unsigned char) ']'));
						      arg1203_68 = MAKE_PAIR(aux_739, arg1204_69);
						   }
						}
						arg1202_67 = MAKE_PAIR(cmd_ld_108_63, arg1203_68);
					     }
					     list1200_65 = MAKE_PAIR(string1459_cc_ld, arg1202_67);
					  }
					  verbose_tools_speek(BINT(((long) 2)), list1200_65);
				       }
				       return exec_cc_exec(cmd_ld_108_63, need_to_return_234_10, string1446_cc_ld);
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* handling_function1316 */ obj_t 
handling_function1316_cc_ld(obj_t port1002_576)
{
   jmp_buf jmpbuf;
   obj_t an_exit1004_168;
   if (SET_EXIT(an_exit1004_168))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1004_168 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1004_168, ((bool_t) 0));
	   {
	      obj_t val1005_169;
	      {
		 obj_t arg1319_170;
		 {
		    obj_t lambda1320_573;
		    lambda1320_573 = proc1460_cc_ld;
		    arg1319_170 = lambda1320_573;
		 }
		 val1005_169 = PROCEDURE_ENTRY(arg1319_170) (arg1319_170, port1002_576, BEOA);
	      }
	      POP_EXIT();
	      return val1005_169;
	   }
	}
     }
}


/* loop */ obj_t 
loop_cc_ld(obj_t path_117)
{
   if (NULLP(path_117))
     {
	return string1444_cc_ld;
     }
   else
     {
	obj_t arg1272_121;
	obj_t arg1274_123;
	arg1272_121 = CAR(path_117);
	arg1274_123 = loop_cc_ld(CDR(path_117));
	{
	   obj_t list1275_124;
	   {
	      obj_t arg1277_125;
	      {
		 obj_t arg1278_126;
		 {
		    obj_t arg1281_127;
		    arg1281_127 = MAKE_PAIR(arg1274_123, BNIL);
		    arg1278_126 = MAKE_PAIR(string1443_cc_ld, arg1281_127);
		 }
		 arg1277_125 = MAKE_PAIR(arg1272_121, arg1278_126);
	      }
	      list1275_124 = MAKE_PAIR(string1461_cc_ld, arg1277_125);
	   }
	   return string_append_106___r4_strings_6_7(list1275_124);
	}
     }
}


/* lambda1320 */ obj_t 
lambda1320_cc_ld(obj_t env_574, obj_t input_port_219_575)
{
   {
      obj_t input_port_219_172;
      input_port_219_172 = input_port_219_575;
      {
	 long last_match_133_341;
	 long last_match_133_330;
	 long last_match_133_319;
	 long last_match_133_308;
	 long last_match_133_299;
	 long last_match_133_289;
	 long last_match_133_278;
	 long last_match_133_266;
	 long last_match_133_255;
	 long last_match_133_244;
	 long last_match_133_236;
	 RGC_START_MATCH(input_port_219_172);
	 {
	    int match_201;
	    {
	       long aux_764;
	       last_match_133_236 = ((long) 1);
	     state_0_1006_38_368:
	       {
		  int current_char_37_238;
		  current_char_37_238 = RGC_BUFFER_GET_CHAR(input_port_219_172);
		  switch ((long) (current_char_37_238))
		    {
		    case ((long) 0):
		       {
			  bool_t test1354_242;
			  test1354_242 = RGC_BUFFER_EMPTY(input_port_219_172);
			  if (test1354_242)
			    {
			       bool_t test1355_243;
			       test1355_243 = rgc_fill_buffer(input_port_219_172);
			       if (test1355_243)
				 {
				    goto state_0_1006_38_368;
				 }
			       else
				 {
				    aux_764 = last_match_133_236;
				 }
			    }
			  else
			    {
			       last_match_133_289 = last_match_133_236;
			     state_1_1007_81_363:
			       {
				  long new_match_93_291;
				  RGC_STOP_MATCH(input_port_219_172);
				  new_match_93_291 = ((long) 1);
				  {
				     int current_char_37_292;
				     current_char_37_292 = RGC_BUFFER_GET_CHAR(input_port_219_172);
				     {
					bool_t test_772;
					{
					   long aux_773;
					   aux_773 = (long) (current_char_37_292);
					   test_772 = (aux_773 == ((long) 0));
					}
					if (test_772)
					  {
					     {
						bool_t test1394_294;
						test1394_294 = RGC_BUFFER_EMPTY(input_port_219_172);
						if (test1394_294)
						  {
						     bool_t test1395_295;
						     test1395_295 = rgc_fill_buffer(input_port_219_172);
						     if (test1395_295)
						       {
							  goto state_1_1007_81_363;
						       }
						     else
						       {
							  aux_764 = new_match_93_291;
						       }
						  }
						else
						  {
						     last_match_133_299 = new_match_93_291;
						   state_4_1010_86_362:
						     {
							int current_char_37_301;
							current_char_37_301 = RGC_BUFFER_GET_CHAR(input_port_219_172);
							{
							   bool_t test_781;
							   {
							      long aux_782;
							      aux_782 = (long) (current_char_37_301);
							      test_781 = (aux_782 == ((long) 0));
							   }
							   if (test_781)
							     {
								{
								   bool_t test1401_303;
								   test1401_303 = RGC_BUFFER_EMPTY(input_port_219_172);
								   if (test1401_303)
								     {
									bool_t test1402_304;
									test1402_304 = rgc_fill_buffer(input_port_219_172);
									if (test1402_304)
									  {
									     goto state_4_1010_86_362;
									  }
									else
									  {
									     aux_764 = last_match_133_299;
									  }
								     }
								   else
								     {
									goto state_4_1010_86_362;
								     }
								}
							     }
							   else
							     {
								bool_t test1403_305;
								{
								   long aux_789;
								   aux_789 = (long) (current_char_37_301);
								   test1403_305 = (aux_789 == ((long) 45));
								}
								if (test1403_305)
								  {
								     last_match_133_278 = last_match_133_299;
								   state_5_1011_248_364:
								     {
									int current_char_37_280;
									current_char_37_280 = RGC_BUFFER_GET_CHAR(input_port_219_172);
									{
									   bool_t test_794;
									   {
									      long aux_795;
									      aux_795 = (long) (current_char_37_280);
									      test_794 = (aux_795 == ((long) 0));
									   }
									   if (test_794)
									     {
										{
										   bool_t test1385_282;
										   test1385_282 = RGC_BUFFER_EMPTY(input_port_219_172);
										   if (test1385_282)
										     {
											bool_t test1386_283;
											test1386_283 = rgc_fill_buffer(input_port_219_172);
											if (test1386_283)
											  {
											     goto state_5_1011_248_364;
											  }
											else
											  {
											     aux_764 = last_match_133_278;
											  }
										     }
										   else
										     {
											long last_match_133_802;
											last_match_133_802 = last_match_133_278;
											last_match_133_299 = last_match_133_802;
											goto state_4_1010_86_362;
										     }
										}
									     }
									   else
									     {
										bool_t test1387_284;
										{
										   long aux_803;
										   aux_803 = (long) (current_char_37_280);
										   test1387_284 = (aux_803 == ((long) 115));
										}
										if (test1387_284)
										  {
										     last_match_133_255 = last_match_133_278;
										   state_6_1012_188_366:
										     {
											int current_char_37_257;
											current_char_37_257 = RGC_BUFFER_GET_CHAR(input_port_219_172);
											{
											   bool_t test_808;
											   {
											      long aux_809;
											      aux_809 = (long) (current_char_37_257);
											      test_808 = (aux_809 == ((long) 0));
											   }
											   if (test_808)
											     {
												{
												   bool_t test1367_259;
												   test1367_259 = RGC_BUFFER_EMPTY(input_port_219_172);
												   if (test1367_259)
												     {
													bool_t test1368_260;
													test1368_260 = rgc_fill_buffer(input_port_219_172);
													if (test1368_260)
													  {
													     goto state_6_1012_188_366;
													  }
													else
													  {
													     aux_764 = last_match_133_255;
													  }
												     }
												   else
												     {
													long last_match_133_816;
													last_match_133_816 = last_match_133_255;
													last_match_133_299 = last_match_133_816;
													goto state_4_1010_86_362;
												     }
												}
											     }
											   else
											     {
												bool_t test1369_261;
												{
												   long aux_817;
												   aux_817 = (long) (current_char_37_257);
												   test1369_261 = (aux_817 == ((long) 116));
												}
												if (test1369_261)
												  {
												     last_match_133_244 = last_match_133_255;
												   state_8_1014_77_367:
												     {
													int current_char_37_246;
													current_char_37_246 = RGC_BUFFER_GET_CHAR(input_port_219_172);
													{
													   bool_t test_822;
													   {
													      long aux_823;
													      aux_823 = (long) (current_char_37_246);
													      test_822 = (aux_823 == ((long) 0));
													   }
													   if (test_822)
													     {
														{
														   bool_t test1358_248;
														   test1358_248 = RGC_BUFFER_EMPTY(input_port_219_172);
														   if (test1358_248)
														     {
															bool_t test1359_249;
															test1359_249 = rgc_fill_buffer(input_port_219_172);
															if (test1359_249)
															  {
															     goto state_8_1014_77_367;
															  }
															else
															  {
															     aux_764 = last_match_133_244;
															  }
														     }
														   else
														     {
															long last_match_133_830;
															last_match_133_830 = last_match_133_244;
															last_match_133_299 = last_match_133_830;
															goto state_4_1010_86_362;
														     }
														}
													     }
													   else
													     {
														bool_t test1360_250;
														{
														   long aux_831;
														   aux_831 = (long) (current_char_37_246);
														   test1360_250 = (aux_831 == ((long) 97));
														}
														if (test1360_250)
														  {
														     last_match_133_308 = last_match_133_244;
														   state_9_1015_96_361:
														     {
															int current_char_37_310;
															current_char_37_310 = RGC_BUFFER_GET_CHAR(input_port_219_172);
															{
															   bool_t test_836;
															   {
															      long aux_837;
															      aux_837 = (long) (current_char_37_310);
															      test_836 = (aux_837 == ((long) 0));
															   }
															   if (test_836)
															     {
																{
																   bool_t test1408_312;
																   test1408_312 = RGC_BUFFER_EMPTY(input_port_219_172);
																   if (test1408_312)
																     {
																	bool_t test1409_313;
																	test1409_313 = rgc_fill_buffer(input_port_219_172);
																	if (test1409_313)
																	  {
																	     goto state_9_1015_96_361;
																	  }
																	else
																	  {
																	     aux_764 = last_match_133_308;
																	  }
																     }
																   else
																     {
																	long last_match_133_844;
																	last_match_133_844 = last_match_133_308;
																	last_match_133_299 = last_match_133_844;
																	goto state_4_1010_86_362;
																     }
																}
															     }
															   else
															     {
																bool_t test1410_314;
																{
																   long aux_845;
																   aux_845 = (long) (current_char_37_310);
																   test1410_314 = (aux_845 == ((long) 116));
																}
																if (test1410_314)
																  {
																     last_match_133_319 = last_match_133_308;
																   state_10_1016_234_360:
																     {
																	int current_char_37_321;
																	current_char_37_321 = RGC_BUFFER_GET_CHAR(input_port_219_172);
																	{
																	   bool_t test_850;
																	   {
																	      long aux_851;
																	      aux_851 = (long) (current_char_37_321);
																	      test_850 = (aux_851 == ((long) 0));
																	   }
																	   if (test_850)
																	     {
																		{
																		   bool_t test1417_323;
																		   test1417_323 = RGC_BUFFER_EMPTY(input_port_219_172);
																		   if (test1417_323)
																		     {
																			bool_t test1418_324;
																			test1418_324 = rgc_fill_buffer(input_port_219_172);
																			if (test1418_324)
																			  {
																			     goto state_10_1016_234_360;
																			  }
																			else
																			  {
																			     aux_764 = last_match_133_319;
																			  }
																		     }
																		   else
																		     {
																			long last_match_133_858;
																			last_match_133_858 = last_match_133_319;
																			last_match_133_299 = last_match_133_858;
																			goto state_4_1010_86_362;
																		     }
																		}
																	     }
																	   else
																	     {
																		bool_t test1419_325;
																		{
																		   long aux_859;
																		   aux_859 = (long) (current_char_37_321);
																		   test1419_325 = (aux_859 == ((long) 105));
																		}
																		if (test1419_325)
																		  {
																		     last_match_133_330 = last_match_133_319;
																		   state_11_1017_235_359:
																		     {
																			int current_char_37_332;
																			current_char_37_332 = RGC_BUFFER_GET_CHAR(input_port_219_172);
																			{
																			   bool_t test_864;
																			   {
																			      long aux_865;
																			      aux_865 = (long) (current_char_37_332);
																			      test_864 = (aux_865 == ((long) 0));
																			   }
																			   if (test_864)
																			     {
																				{
																				   bool_t test1426_334;
																				   test1426_334 = RGC_BUFFER_EMPTY(input_port_219_172);
																				   if (test1426_334)
																				     {
																					bool_t test1427_335;
																					test1427_335 = rgc_fill_buffer(input_port_219_172);
																					if (test1427_335)
																					  {
																					     goto state_11_1017_235_359;
																					  }
																					else
																					  {
																					     aux_764 = last_match_133_330;
																					  }
																				     }
																				   else
																				     {
																					long last_match_133_872;
																					last_match_133_872 = last_match_133_330;
																					last_match_133_299 = last_match_133_872;
																					goto state_4_1010_86_362;
																				     }
																				}
																			     }
																			   else
																			     {
																				bool_t test1428_336;
																				{
																				   long aux_873;
																				   aux_873 = (long) (current_char_37_332);
																				   test1428_336 = (aux_873 == ((long) 99));
																				}
																				if (test1428_336)
																				  {
																				     last_match_133_341 = last_match_133_330;
																				   state_12_1018_126_358:
																				     {
																					long new_match_93_343;
																					RGC_STOP_MATCH(input_port_219_172);
																					new_match_93_343 = ((long) 0);
																					{
																					   int current_char_37_344;
																					   current_char_37_344 = RGC_BUFFER_GET_CHAR(input_port_219_172);
																					   {
																					      bool_t test_879;
																					      {
																						 long aux_880;
																						 aux_880 = (long) (current_char_37_344);
																						 test_879 = (aux_880 == ((long) 0));
																					      }
																					      if (test_879)
																						{
																						   {
																						      bool_t test1435_346;
																						      test1435_346 = RGC_BUFFER_EMPTY(input_port_219_172);
																						      if (test1435_346)
																							{
																							   bool_t test1436_347;
																							   test1436_347 = rgc_fill_buffer(input_port_219_172);
																							   if (test1436_347)
																							     {
																								goto state_12_1018_126_358;
																							     }
																							   else
																							     {
																								aux_764 = new_match_93_343;
																							     }
																							}
																						      else
																							{
																							   long last_match_133_887;
																							   last_match_133_887 = new_match_93_343;
																							   last_match_133_299 = last_match_133_887;
																							   goto state_4_1010_86_362;
																							}
																						   }
																						}
																					      else
																						{
																						   bool_t test1437_348;
																						   {
																						      long aux_888;
																						      aux_888 = (long) (current_char_37_344);
																						      test1437_348 = (aux_888 == ((long) 45));
																						   }
																						   if (test1437_348)
																						     {
																							{
																							   long last_match_133_892;
																							   last_match_133_892 = new_match_93_343;
																							   last_match_133_278 = last_match_133_892;
																							   goto state_5_1011_248_364;
																							}
																						     }
																						   else
																						     {
																							bool_t test_893;
																							{
																							   bool_t test_894;
																							   {
																							      long aux_895;
																							      aux_895 = (long) (current_char_37_344);
																							      test_894 = (aux_895 == ((long) 10));
																							   }
																							   if (test_894)
																							     {
																								test_893 = ((bool_t) 1);
																							     }
																							   else
																							     {
																								test_893 = test1437_348;
																							     }
																							}
																							if (test_893)
																							  {
																							     aux_764 = new_match_93_343;
																							  }
																							else
																							  {
																							     {
																								long last_match_133_898;
																								last_match_133_898 = new_match_93_343;
																								last_match_133_299 = last_match_133_898;
																								goto state_4_1010_86_362;
																							     }
																							  }
																						     }
																						}
																					   }
																					}
																				     }
																				  }
																				else
																				  {
																				     bool_t test1429_337;
																				     {
																					long aux_899;
																					aux_899 = (long) (current_char_37_332);
																					test1429_337 = (aux_899 == ((long) 45));
																				     }
																				     if (test1429_337)
																				       {
																					  {
																					     long last_match_133_903;
																					     last_match_133_903 = last_match_133_330;
																					     last_match_133_278 = last_match_133_903;
																					     goto state_5_1011_248_364;
																					  }
																				       }
																				     else
																				       {
																					  bool_t test_904;
																					  {
																					     bool_t test_905;
																					     {
																						long aux_906;
																						aux_906 = (long) (current_char_37_332);
																						test_905 = (aux_906 == ((long) 10));
																					     }
																					     if (test_905)
																					       {
																						  test_904 = ((bool_t) 1);
																					       }
																					     else
																					       {
																						  if (test1429_337)
																						    {
																						       test_904 = ((bool_t) 1);
																						    }
																						  else
																						    {
																						       test_904 = test1428_336;
																						    }
																					       }
																					  }
																					  if (test_904)
																					    {
																					       aux_764 = last_match_133_330;
																					    }
																					  else
																					    {
																					       {
																						  long last_match_133_910;
																						  last_match_133_910 = last_match_133_330;
																						  last_match_133_299 = last_match_133_910;
																						  goto state_4_1010_86_362;
																					       }
																					    }
																				       }
																				  }
																			     }
																			}
																		     }
																		  }
																		else
																		  {
																		     bool_t test1420_326;
																		     {
																			long aux_911;
																			aux_911 = (long) (current_char_37_321);
																			test1420_326 = (aux_911 == ((long) 45));
																		     }
																		     if (test1420_326)
																		       {
																			  {
																			     long last_match_133_915;
																			     last_match_133_915 = last_match_133_319;
																			     last_match_133_278 = last_match_133_915;
																			     goto state_5_1011_248_364;
																			  }
																		       }
																		     else
																		       {
																			  bool_t test_916;
																			  {
																			     bool_t test_917;
																			     {
																				long aux_918;
																				aux_918 = (long) (current_char_37_321);
																				test_917 = (aux_918 == ((long) 10));
																			     }
																			     if (test_917)
																			       {
																				  test_916 = ((bool_t) 1);
																			       }
																			     else
																			       {
																				  if (test1420_326)
																				    {
																				       test_916 = ((bool_t) 1);
																				    }
																				  else
																				    {
																				       test_916 = test1419_325;
																				    }
																			       }
																			  }
																			  if (test_916)
																			    {
																			       aux_764 = last_match_133_319;
																			    }
																			  else
																			    {
																			       {
																				  long last_match_133_922;
																				  last_match_133_922 = last_match_133_319;
																				  last_match_133_299 = last_match_133_922;
																				  goto state_4_1010_86_362;
																			       }
																			    }
																		       }
																		  }
																	     }
																	}
																     }
																  }
																else
																  {
																     bool_t test1411_315;
																     {
																	long aux_923;
																	aux_923 = (long) (current_char_37_310);
																	test1411_315 = (aux_923 == ((long) 45));
																     }
																     if (test1411_315)
																       {
																	  {
																	     long last_match_133_927;
																	     last_match_133_927 = last_match_133_308;
																	     last_match_133_278 = last_match_133_927;
																	     goto state_5_1011_248_364;
																	  }
																       }
																     else
																       {
																	  bool_t test_928;
																	  {
																	     bool_t test_929;
																	     {
																		long aux_930;
																		aux_930 = (long) (current_char_37_310);
																		test_929 = (aux_930 == ((long) 10));
																	     }
																	     if (test_929)
																	       {
																		  test_928 = ((bool_t) 1);
																	       }
																	     else
																	       {
																		  if (test1411_315)
																		    {
																		       test_928 = ((bool_t) 1);
																		    }
																		  else
																		    {
																		       test_928 = test1410_314;
																		    }
																	       }
																	  }
																	  if (test_928)
																	    {
																	       aux_764 = last_match_133_308;
																	    }
																	  else
																	    {
																	       {
																		  long last_match_133_934;
																		  last_match_133_934 = last_match_133_308;
																		  last_match_133_299 = last_match_133_934;
																		  goto state_4_1010_86_362;
																	       }
																	    }
																       }
																  }
															     }
															}
														     }
														  }
														else
														  {
														     bool_t test1361_251;
														     {
															long aux_935;
															aux_935 = (long) (current_char_37_246);
															test1361_251 = (aux_935 == ((long) 45));
														     }
														     if (test1361_251)
														       {
															  {
															     long last_match_133_939;
															     last_match_133_939 = last_match_133_244;
															     last_match_133_278 = last_match_133_939;
															     goto state_5_1011_248_364;
															  }
														       }
														     else
														       {
															  bool_t test_940;
															  {
															     bool_t test_941;
															     {
																long aux_942;
																aux_942 = (long) (current_char_37_246);
																test_941 = (aux_942 == ((long) 10));
															     }
															     if (test_941)
															       {
																  test_940 = ((bool_t) 1);
															       }
															     else
															       {
																  if (test1361_251)
																    {
																       test_940 = ((bool_t) 1);
																    }
																  else
																    {
																       test_940 = test1360_250;
																    }
															       }
															  }
															  if (test_940)
															    {
															       aux_764 = last_match_133_244;
															    }
															  else
															    {
															       {
																  long last_match_133_946;
																  last_match_133_946 = last_match_133_244;
																  last_match_133_299 = last_match_133_946;
																  goto state_4_1010_86_362;
															       }
															    }
														       }
														  }
													     }
													}
												     }
												  }
												else
												  {
												     bool_t test1370_262;
												     {
													long aux_947;
													aux_947 = (long) (current_char_37_257);
													test1370_262 = (aux_947 == ((long) 45));
												     }
												     if (test1370_262)
												       {
													  {
													     long last_match_133_951;
													     last_match_133_951 = last_match_133_255;
													     last_match_133_278 = last_match_133_951;
													     goto state_5_1011_248_364;
													  }
												       }
												     else
												       {
													  bool_t test_952;
													  {
													     bool_t test_953;
													     {
														long aux_954;
														aux_954 = (long) (current_char_37_257);
														test_953 = (aux_954 == ((long) 10));
													     }
													     if (test_953)
													       {
														  test_952 = ((bool_t) 1);
													       }
													     else
													       {
														  if (test1370_262)
														    {
														       test_952 = ((bool_t) 1);
														    }
														  else
														    {
														       test_952 = test1369_261;
														    }
													       }
													  }
													  if (test_952)
													    {
													       aux_764 = last_match_133_255;
													    }
													  else
													    {
													       {
														  long last_match_133_958;
														  last_match_133_958 = last_match_133_255;
														  last_match_133_299 = last_match_133_958;
														  goto state_4_1010_86_362;
													       }
													    }
												       }
												  }
											     }
											}
										     }
										  }
										else
										  {
										     bool_t test1388_285;
										     {
											long aux_959;
											aux_959 = (long) (current_char_37_280);
											test1388_285 = (aux_959 == ((long) 45));
										     }
										     if (test1388_285)
										       {
											  {
											     goto state_5_1011_248_364;
											  }
										       }
										     else
										       {
											  bool_t test_963;
											  {
											     bool_t test_964;
											     {
												long aux_965;
												aux_965 = (long) (current_char_37_280);
												test_964 = (aux_965 == ((long) 10));
											     }
											     if (test_964)
											       {
												  test_963 = ((bool_t) 1);
											       }
											     else
											       {
												  if (test1388_285)
												    {
												       test_963 = ((bool_t) 1);
												    }
												  else
												    {
												       test_963 = test1387_284;
												    }
											       }
											  }
											  if (test_963)
											    {
											       aux_764 = last_match_133_278;
											    }
											  else
											    {
											       {
												  long last_match_133_969;
												  last_match_133_969 = last_match_133_278;
												  last_match_133_299 = last_match_133_969;
												  goto state_4_1010_86_362;
											       }
											    }
										       }
										  }
									     }
									}
								     }
								  }
								else
								  {
								     bool_t test_970;
								     {
									bool_t test_971;
									{
									   long aux_972;
									   aux_972 = (long) (current_char_37_301);
									   test_971 = (aux_972 == ((long) 10));
									}
									if (test_971)
									  {
									     test_970 = ((bool_t) 1);
									  }
									else
									  {
									     test_970 = test1403_305;
									  }
								     }
								     if (test_970)
								       {
									  aux_764 = last_match_133_299;
								       }
								     else
								       {
									  {
									     goto state_4_1010_86_362;
									  }
								       }
								  }
							     }
							}
						     }
						  }
					     }
					  }
					else
					  {
					     bool_t test1396_296;
					     {
						long aux_975;
						aux_975 = (long) (current_char_37_292);
						test1396_296 = (aux_975 == ((long) 45));
					     }
					     if (test1396_296)
					       {
						  {
						     long last_match_133_979;
						     last_match_133_979 = new_match_93_291;
						     last_match_133_278 = last_match_133_979;
						     goto state_5_1011_248_364;
						  }
					       }
					     else
					       {
						  bool_t test_980;
						  {
						     bool_t test_981;
						     {
							long aux_982;
							aux_982 = (long) (current_char_37_292);
							test_981 = (aux_982 == ((long) 10));
						     }
						     if (test_981)
						       {
							  test_980 = ((bool_t) 1);
						       }
						     else
						       {
							  test_980 = test1396_296;
						       }
						  }
						  if (test_980)
						    {
						       aux_764 = new_match_93_291;
						    }
						  else
						    {
						       {
							  long last_match_133_985;
							  last_match_133_985 = new_match_93_291;
							  last_match_133_299 = last_match_133_985;
							  goto state_4_1010_86_362;
						       }
						    }
					       }
					  }
				     }
				  }
			       }
			    }
		       }
		       break;
		    case ((long) 45):
		       last_match_133_266 = last_match_133_236;
		     state_3_1009_176_365:
		       {
			  long new_match_93_268;
			  RGC_STOP_MATCH(input_port_219_172);
			  new_match_93_268 = ((long) 1);
			  {
			     int current_char_37_269;
			     current_char_37_269 = RGC_BUFFER_GET_CHAR(input_port_219_172);
			     {
				bool_t test_988;
				{
				   long aux_989;
				   aux_989 = (long) (current_char_37_269);
				   test_988 = (aux_989 == ((long) 0));
				}
				if (test_988)
				  {
				     {
					bool_t test1376_271;
					test1376_271 = RGC_BUFFER_EMPTY(input_port_219_172);
					if (test1376_271)
					  {
					     bool_t test1377_272;
					     test1377_272 = rgc_fill_buffer(input_port_219_172);
					     if (test1377_272)
					       {
						  goto state_3_1009_176_365;
					       }
					     else
					       {
						  aux_764 = new_match_93_268;
					       }
					  }
					else
					  {
					     long last_match_133_996;
					     last_match_133_996 = new_match_93_268;
					     last_match_133_299 = last_match_133_996;
					     goto state_4_1010_86_362;
					  }
				     }
				  }
				else
				  {
				     bool_t test1378_273;
				     {
					long aux_997;
					aux_997 = (long) (current_char_37_269);
					test1378_273 = (aux_997 == ((long) 115));
				     }
				     if (test1378_273)
				       {
					  {
					     long last_match_133_1001;
					     last_match_133_1001 = new_match_93_268;
					     last_match_133_255 = last_match_133_1001;
					     goto state_6_1012_188_366;
					  }
				       }
				     else
				       {
					  bool_t test1379_274;
					  {
					     long aux_1002;
					     aux_1002 = (long) (current_char_37_269);
					     test1379_274 = (aux_1002 == ((long) 45));
					  }
					  if (test1379_274)
					    {
					       {
						  long last_match_133_1006;
						  last_match_133_1006 = new_match_93_268;
						  last_match_133_278 = last_match_133_1006;
						  goto state_5_1011_248_364;
					       }
					    }
					  else
					    {
					       bool_t test_1007;
					       {
						  bool_t test_1008;
						  {
						     long aux_1009;
						     aux_1009 = (long) (current_char_37_269);
						     test_1008 = (aux_1009 == ((long) 10));
						  }
						  if (test_1008)
						    {
						       test_1007 = ((bool_t) 1);
						    }
						  else
						    {
						       if (test1379_274)
							 {
							    test_1007 = ((bool_t) 1);
							 }
						       else
							 {
							    test_1007 = test1378_273;
							 }
						    }
					       }
					       if (test_1007)
						 {
						    aux_764 = new_match_93_268;
						 }
					       else
						 {
						    {
						       long last_match_133_1013;
						       last_match_133_1013 = new_match_93_268;
						       last_match_133_299 = last_match_133_1013;
						       goto state_4_1010_86_362;
						    }
						 }
					    }
				       }
				  }
			     }
			  }
		       }
		       break;
		    case ((long) 10):
		       {
			  long new_match_93_406;
			  RGC_STOP_MATCH(input_port_219_172);
			  new_match_93_406 = ((long) 1);
			  aux_764 = new_match_93_406;
		       }
		       break;
		    default:
		       {
			  long last_match_133_1015;
			  last_match_133_1015 = last_match_133_236;
			  last_match_133_289 = last_match_133_1015;
			  goto state_1_1007_81_363;
		       }
		    }
	       }
	       match_201 = (int) (aux_764);
	    }
	    {
	       switch ((long) (match_201))
		 {
		 case ((long) 1):
		    return BFALSE;
		    break;
		 case ((long) 0):
		    return BTRUE;
		    break;
		 default:
		    FAILURE(string1462_cc_ld, string1463_cc_ld, BINT(match_201));
		 }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cc_ld()
{
   module_initialization_70_tools_speek(((long) 0), "CC_LD");
   module_initialization_70_tools_error(((long) 0), "CC_LD");
   module_initialization_70_cc_exec(((long) 0), "CC_LD");
   module_initialization_70_engine_param(((long) 0), "CC_LD");
   return module_initialization_70_tools_file(((long) 0), "CC_LD");
}
