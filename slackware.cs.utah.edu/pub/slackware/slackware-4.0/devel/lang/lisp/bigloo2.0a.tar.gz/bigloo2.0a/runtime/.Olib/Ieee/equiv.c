/*===========================================================================*/
/*   (Ieee/equiv.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>


/* Object type definitions */

extern bool_t bigloo_strcmp(obj_t, obj_t);
static obj_t symbol1458___r4_equivalence_6_2 = BUNSPEC;
static obj_t symbol1457___r4_equivalence_6_2 = BUNSPEC;
static obj_t symbol1449___r4_equivalence_6_2 = BUNSPEC;
static obj_t symbol1446___r4_equivalence_6_2 = BUNSPEC;
static obj_t symbol1445___r4_equivalence_6_2 = BUNSPEC;
static obj_t method_init_76___r4_equivalence_6_2();
extern obj_t string_to_symbol(char *);
static obj_t _equal__165___r4_equivalence_6_2(obj_t, obj_t, obj_t);
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _eqv__158___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern bool_t eqv__112___r4_equivalence_6_2(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_equivalence_6_2();
extern bool_t ucs2_strcmp(obj_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern bool_t eq__100___r4_equivalence_6_2(obj_t, obj_t);
static obj_t require_initialization_114___r4_equivalence_6_2 = BUNSPEC;
extern bool_t object_equal__12___object(object_t, object_t);
static obj_t cnst_init_137___r4_equivalence_6_2();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( equal__env_47___r4_equivalence_6_2, _equal__165___r4_equivalence_6_21460, _equal__165___r4_equivalence_6_2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( eqv__env_202___r4_equivalence_6_2, _eqv__158___r4_equivalence_6_21461, _eqv__158___r4_equivalence_6_2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( eq__env_189___r4_equivalence_6_2, _eq__190___r4_equivalence_6_21462, _eq__190___r4_equivalence_6_2, 0L, 2 );
DEFINE_STRING( string1456___r4_equivalence_6_2, string1456___r4_equivalence_6_21463, "UCS2STRING", 10 );
DEFINE_STRING( string1455___r4_equivalence_6_2, string1455___r4_equivalence_6_21464, "OBJECT", 6 );
DEFINE_STRING( string1454___r4_equivalence_6_2, string1454___r4_equivalence_6_21465, "STRUCT", 6 );
DEFINE_STRING( string1453___r4_equivalence_6_2, string1453___r4_equivalence_6_21466, "DOUBLE", 6 );
DEFINE_STRING( string1452___r4_equivalence_6_2, string1452___r4_equivalence_6_21467, "BSTRING", 7 );
DEFINE_STRING( string1451___r4_equivalence_6_2, string1451___r4_equivalence_6_21468, "VECTOR", 6 );
DEFINE_STRING( string1450___r4_equivalence_6_2, string1450___r4_equivalence_6_21469, "PAIR", 4 );
DEFINE_STRING( string1448___r4_equivalence_6_2, string1448___r4_equivalence_6_21470, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/equiv.scm", 58 );
DEFINE_STRING( string1447___r4_equivalence_6_2, string1447___r4_equivalence_6_21471, "SYMBOL", 6 );


/* module-initialization */obj_t module_initialization_70___r4_equivalence_6_2(long checksum_930, char * from_931)
{
if(CBOOL(require_initialization_114___r4_equivalence_6_2)){
require_initialization_114___r4_equivalence_6_2 = BBOOL(((bool_t)0));
cnst_init_137___r4_equivalence_6_2();
imported_modules_init_94___r4_equivalence_6_2();
method_init_76___r4_equivalence_6_2();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_equivalence_6_2()
{
symbol1445___r4_equivalence_6_2 = string_to_symbol("EQ?");
symbol1446___r4_equivalence_6_2 = string_to_symbol("EQV?");
symbol1449___r4_equivalence_6_2 = string_to_symbol("EQUAL?");
symbol1457___r4_equivalence_6_2 = string_to_symbol("METHOD-INIT");
return (symbol1458___r4_equivalence_6_2 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* eq? */bool_t eq__100___r4_equivalence_6_2(obj_t obj1_1, obj_t obj2_2)
{
{
obj_t symbol1255_922;
symbol1255_922 = symbol1445___r4_equivalence_6_2;
{
PUSH_TRACE(symbol1255_922);
BUNSPEC;
{
bool_t aux1254_923;
aux1254_923 = (obj1_1==obj2_2);
POP_TRACE();
return aux1254_923;
}
}
}
}


/* _eq? */obj_t _eq__190___r4_equivalence_6_2(obj_t env_769, obj_t obj1_770, obj_t obj2_771)
{
{
bool_t aux_946;
{
obj_t obj1_924;
obj_t obj2_925;
obj1_924 = obj1_770;
obj2_925 = obj2_771;
{
obj_t symbol1255_926;
symbol1255_926 = symbol1445___r4_equivalence_6_2;
{
PUSH_TRACE(symbol1255_926);
BUNSPEC;
{
bool_t aux1254_927;
aux1254_927 = (obj1_924==obj2_925);
POP_TRACE();
aux_946 = aux1254_927;
}
}
}
}
return BBOOL(aux_946);
}
}


/* eqv? */bool_t eqv__112___r4_equivalence_6_2(obj_t obj1_3, obj_t obj2_4)
{
{
obj_t symbol1257_761;
symbol1257_761 = symbol1446___r4_equivalence_6_2;
{
PUSH_TRACE(symbol1257_761);
BUNSPEC;
{
bool_t aux1256_762;
if(INTEGERP(obj1_3)){
if(INTEGERP(obj2_4)){
aux1256_762 = _2__95___r4_numbers_6_5(obj1_3, obj2_4);
}
 else {
aux1256_762 = ((bool_t)0);
}
}
 else {
if(REALP(obj1_3)){
if(REALP(obj2_4)){
aux1256_762 = _2__95___r4_numbers_6_5(obj1_3, obj2_4);
}
 else {
aux1256_762 = ((bool_t)0);
}
}
 else {
bool_t test1032_396;
test1032_396 = SYMBOLP(obj1_3);
if(test1032_396){
{
bool_t _andtest_1007_397;
_andtest_1007_397 = SYMBOLP(obj2_4);
if(_andtest_1007_397){
obj_t arg1033_398;
obj_t arg1034_399;
{
obj_t symbol_649;
if(test1032_396){
symbol_649 = obj1_3;
}
 else {
bigloo_type_error_location_103___error(symbol1446___r4_equivalence_6_2, string1447___r4_equivalence_6_2, obj1_3, string1448___r4_equivalence_6_2, BINT(((long)2985)));
exit( -1 );}
arg1033_398 = SYMBOL_TO_STRING(symbol_649);
}
{
obj_t symbol_650;
if(_andtest_1007_397){
symbol_650 = obj2_4;
}
 else {
bigloo_type_error_location_103___error(symbol1446___r4_equivalence_6_2, string1447___r4_equivalence_6_2, obj2_4, string1448___r4_equivalence_6_2, BINT(((long)3015)));
exit( -1 );}
arg1034_399 = SYMBOL_TO_STRING(symbol_650);
}
aux1256_762 = bigloo_strcmp(arg1033_398, arg1034_399);
}
 else {
aux1256_762 = ((bool_t)0);
}
}
}
 else {
aux1256_762 = (obj1_3==obj2_4);
}
}
}
POP_TRACE();
return aux1256_762;
}
}
}
}


/* _eqv? */obj_t _eqv__158___r4_equivalence_6_2(obj_t env_772, obj_t obj1_773, obj_t obj2_774)
{
{
bool_t aux_979;
aux_979 = eqv__112___r4_equivalence_6_2(obj1_773, obj2_774);
return BBOOL(aux_979);
}
}


/* equal? */bool_t equal__25___r4_equivalence_6_2(obj_t obj1_5, obj_t obj2_6)
{
{
obj_t symbol1260_763;
symbol1260_763 = symbol1449___r4_equivalence_6_2;
{
PUSH_TRACE(symbol1260_763);
BUNSPEC;
{
bool_t aux1259_764;
if((obj1_5==obj2_6)){
aux1259_764 = ((bool_t)1);
}
 else {
bool_t test1036_401;
test1036_401 = INTEGERP(obj1_5);
if(test1036_401){
aux1259_764 = ((bool_t)0);
}
 else {
if(SYMBOLP(obj1_5)){
aux1259_764 = ((bool_t)0);
}
 else {
if(UCS2P(obj1_5)){
aux1259_764 = ((bool_t)0);
}
 else {
bool_t test1039_404;
test1039_404 = PAIRP(obj1_5);
if(test1039_404){
{
bool_t _andtest_1008_405;
_andtest_1008_405 = PAIRP(obj2_6);
if(_andtest_1008_405){
bool_t _andtest_1009_406;
{
obj_t arg1042_409;
obj_t arg1043_410;
{
obj_t pair_660;
if(test1039_404){
pair_660 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1450___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)3523)));
exit( -1 );}
arg1042_409 = CAR(pair_660);
}
{
obj_t pair_661;
if(_andtest_1008_405){
pair_661 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1450___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)3534)));
exit( -1 );}
arg1043_410 = CAR(pair_661);
}
_andtest_1009_406 = equal__25___r4_equivalence_6_2(arg1042_409, arg1043_410);
}
if(_andtest_1009_406){
obj_t arg1040_407;
obj_t arg1041_408;
{
obj_t pair_662;
if(test1039_404){
pair_662 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1450___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)3559)));
exit( -1 );}
arg1040_407 = CDR(pair_662);
}
{
obj_t pair_663;
if(_andtest_1008_405){
pair_663 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1450___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)3570)));
exit( -1 );}
arg1041_408 = CDR(pair_663);
}
aux1259_764 = equal__25___r4_equivalence_6_2(arg1040_407, arg1041_408);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
 else {
bool_t test1044_411;
test1044_411 = VECTORP(obj1_5);
if(test1044_411){
{
long lobj1_412;
{
obj_t vector_665;
if(test1044_411){
vector_665 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1451___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)3626)));
exit( -1 );}
lobj1_412 = VECTOR_LENGTH(vector_665);
}
{
bool_t _andtest_1010_413;
_andtest_1010_413 = VECTORP(obj2_6);
if(_andtest_1010_413){
bool_t _andtest_1011_414;
{
long arg1051_426;
{
obj_t vector_667;
if(_andtest_1010_413){
vector_667 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1451___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)3685)));
exit( -1 );}
arg1051_426 = VECTOR_LENGTH(vector_667);
}
_andtest_1011_414 = (arg1051_426==lobj1_412);
}
if(_andtest_1011_414){
bool_t _andtest_1012_415;
{
long arg1049_424;
long arg1050_425;
{
obj_t vector_670;
if(test1044_411){
vector_670 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1451___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)3726)));
exit( -1 );}
arg1049_424 = VECTOR_TAG(vector_670);
}
{
obj_t vector_671;
if(_andtest_1010_413){
vector_671 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1451___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)3744)));
exit( -1 );}
arg1050_425 = VECTOR_TAG(vector_671);
}
_andtest_1012_415 = (arg1049_424==arg1050_425);
}
if(_andtest_1012_415){
long i_416;
i_416 = (lobj1_412-((long)1));
test_417:
{
bool_t _ortest_1013_419;
_ortest_1013_419 = (i_416==((long)-1));
if(_ortest_1013_419){
aux1259_764 = _ortest_1013_419;
}
 else {
bool_t _andtest_1014_420;
{
obj_t arg1047_422;
obj_t arg1048_423;
{
obj_t vector_678;
if(VECTORP(obj1_5)){
vector_678 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1451___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)3841)));
exit( -1 );}
arg1047_422 = VECTOR_REF(vector_678, i_416);
}
{
obj_t vector_680;
if(VECTORP(obj2_6)){
vector_680 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1451___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)3871)));
exit( -1 );}
arg1048_423 = VECTOR_REF(vector_680, i_416);
}
_andtest_1014_420 = equal__25___r4_equivalence_6_2(arg1047_422, arg1048_423);
}
if(_andtest_1014_420){
long i_1062;
i_1062 = (i_416-((long)1));
i_416 = i_1062;
goto test_417;
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
}
 else {
bool_t test1052_427;
test1052_427 = STRINGP(obj1_5);
if(test1052_427){
{
bool_t _andtest_1015_428;
_andtest_1015_428 = STRINGP(obj2_6);
if(_andtest_1015_428){
obj_t string1_686;
obj_t string2_687;
if(test1052_427){
string1_686 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1452___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)3973)));
exit( -1 );}
if(_andtest_1015_428){
string2_687 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1452___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)3982)));
exit( -1 );}
aux1259_764 = bigloo_strcmp(string1_686, string2_687);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
 else {
bool_t test1053_429;
test1053_429 = REALP(obj1_5);
if(test1053_429){
{
bool_t _andtest_1016_430;
_andtest_1016_430 = REALP(obj2_6);
if(_andtest_1016_430){
double r1_688;
double r2_689;
{
obj_t aux_1082;
if(test1053_429){
aux_1082 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1453___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)4054)));
exit( -1 );}
r1_688 = REAL_TO_DOUBLE(aux_1082);
}
{
obj_t aux_1088;
if(_andtest_1016_430){
aux_1088 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1453___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)4058)));
exit( -1 );}
r2_689 = REAL_TO_DOUBLE(aux_1088);
}
aux1259_764 = (r1_688==r2_689);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
 else {
bool_t test1054_431;
test1054_431 = STRUCTP(obj1_5);
if(test1054_431){
{
long lobj1_432;
{
obj_t s_690;
if(test1054_431){
s_690 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1454___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)4116)));
exit( -1 );}
lobj1_432 = STRUCT_LENGTH(s_690);
}
{
bool_t _andtest_1017_433;
_andtest_1017_433 = STRUCTP(obj2_6);
if(_andtest_1017_433){
bool_t _andtest_1018_434;
{
long arg1059_443;
{
obj_t s_692;
if(_andtest_1017_433){
s_692 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1454___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)4175)));
exit( -1 );}
arg1059_443 = STRUCT_LENGTH(s_692);
}
_andtest_1018_434 = (arg1059_443==lobj1_432);
}
if(_andtest_1018_434){
long i_435;
i_435 = (lobj1_432-((long)1));
test_436:
{
bool_t _ortest_1019_438;
_ortest_1019_438 = (i_435==((long)-1));
if(_ortest_1019_438){
aux1259_764 = _ortest_1019_438;
}
 else {
bool_t _andtest_1020_439;
{
obj_t arg1057_441;
obj_t arg1058_442;
{
obj_t s_699;
if(STRUCTP(obj1_5)){
s_699 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1454___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)4281)));
exit( -1 );}
arg1057_441 = STRUCT_REF(s_699, i_435);
}
{
obj_t s_701;
if(STRUCTP(obj2_6)){
s_701 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1454___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)4301)));
exit( -1 );}
arg1058_442 = STRUCT_REF(s_701, i_435);
}
_andtest_1020_439 = equal__25___r4_equivalence_6_2(arg1057_441, arg1058_442);
}
if(_andtest_1020_439){
long i_1127;
i_1127 = (i_435-((long)1));
i_435 = i_1127;
goto test_436;
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
}
 else {
if(CELLP(obj1_5)){
if(CELLP(obj2_6)){
obj_t arg1061_446;
obj_t arg1062_447;
arg1061_446 = CELL_REF(obj1_5);
arg1062_447 = CELL_REF(obj2_6);
aux1259_764 = equal__25___r4_equivalence_6_2(arg1061_446, arg1062_447);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
 else {
bool_t test_1137;
if(test1036_401){
test_1137 = ((bool_t)1);
}
 else {
test_1137 = test1053_429;
}
if(test_1137){
{
bool_t test_1139;
if(INTEGERP(obj2_6)){
test_1139 = ((bool_t)1);
}
 else {
test_1139 = REALP(obj2_6);
}
if(test_1139){
aux1259_764 = _2__95___r4_numbers_6_5(obj1_5, obj2_6);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
 else {
bool_t test1064_450;
test1064_450 = (POINTERP( obj1_5 ) && (TYPE( obj1_5 ) >= OBJECT_TYPE));
if(test1064_450){
{
bool_t _andtest_1023_451;
_andtest_1023_451 = (POINTERP( obj2_6 ) && (TYPE( obj2_6 ) >= OBJECT_TYPE));
if(_andtest_1023_451){
object_t aux_1155;
object_t aux_1148;
{
bool_t test1418_905;
{
obj_t obj_929;
obj_929 = obj2_6;
test1418_905 = (POINTERP( obj_929 ) && (TYPE( obj_929 ) >= OBJECT_TYPE));
}
if(test1418_905){
aux_1155 = (object_t)(obj2_6);
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1455___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)4582)));
exit( -1 );}
}
{
bool_t test1412_899;
{
obj_t obj_928;
obj_928 = obj1_5;
test1412_899 = (POINTERP( obj_928 ) && (TYPE( obj_928 ) >= OBJECT_TYPE));
}
if(test1412_899){
aux_1148 = (object_t)(obj1_5);
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1455___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)4568)));
exit( -1 );}
}
aux1259_764 = object_equal__12___object(aux_1148, aux_1155);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
 else {
bool_t test1065_452;
test1065_452 = UCS2_STRINGP(obj1_5);
if(test1065_452){
{
bool_t _andtest_1024_453;
_andtest_1024_453 = UCS2_STRINGP(obj2_6);
if(_andtest_1024_453){
obj_t ucs2_string1_235_719;
obj_t ucs2_string2_163_720;
if(test1065_452){
ucs2_string1_235_719 = obj1_5;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1456___r4_equivalence_6_2, obj1_5, string1448___r4_equivalence_6_2, BINT(((long)4655)));
exit( -1 );}
if(_andtest_1024_453){
ucs2_string2_163_720 = obj2_6;
}
 else {
bigloo_type_error_location_103___error(symbol1449___r4_equivalence_6_2, string1456___r4_equivalence_6_2, obj2_6, string1448___r4_equivalence_6_2, BINT(((long)4669)));
exit( -1 );}
aux1259_764 = ucs2_strcmp(ucs2_string1_235_719, ucs2_string2_163_720);
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
 else {
aux1259_764 = ((bool_t)0);
}
}
}
}
}
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1259_764;
}
}
}
}


/* _equal? */obj_t _equal__165___r4_equivalence_6_2(obj_t env_775, obj_t obj1_776, obj_t obj2_777)
{
{
bool_t aux_1177;
aux_1177 = equal__25___r4_equivalence_6_2(obj1_776, obj2_777);
return BBOOL(aux_1177);
}
}


/* method-init */obj_t method_init_76___r4_equivalence_6_2()
{
{
obj_t symbol1262_765;
symbol1262_765 = symbol1457___r4_equivalence_6_2;
{
PUSH_TRACE(symbol1262_765);
BUNSPEC;
POP_TRACE();
return BUNSPEC;
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_equivalence_6_2()
{
{
obj_t symbol1264_767;
symbol1264_767 = symbol1458___r4_equivalence_6_2;
{
PUSH_TRACE(symbol1264_767);
BUNSPEC;
{
obj_t aux1263_768;
aux1263_768 = module_initialization_70___error(((long)0), "__R4_EQUIVALENCE_6_2");
POP_TRACE();
return aux1263_768;
}
}
}
}

