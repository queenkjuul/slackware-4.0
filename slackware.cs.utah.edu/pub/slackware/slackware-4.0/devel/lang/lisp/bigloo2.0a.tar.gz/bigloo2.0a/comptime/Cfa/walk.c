/*===========================================================================*/
/*   (Cfa/walk.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_walk();
extern obj_t declare_approx_sets__132_cfa_approx();
extern obj_t specialize__184_cfa_specialize(obj_t);
extern obj_t closure_optimization__48_cfa_closure();
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t set_initial_approx__92_cfa_setup(obj_t);
extern obj_t vector__tvector__205_cfa_tvector(obj_t);
extern obj_t shrinkify__187_ast_shrinkify(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t show_cfa_nb_iterations_231_cfa_show();
extern obj_t show_cfa_results_28_cfa_show(obj_t);
extern obj_t module_initialization_70_cfa_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_shrinkify(long, char *);
extern obj_t module_initialization_70_cfa_collect(long, char *);
extern obj_t module_initialization_70_cfa_setup(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_show(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70_cfa_type(long, char *);
extern obj_t module_initialization_70_cfa_closure(long, char *);
extern obj_t module_initialization_70_cfa_specialize(long, char *);
extern obj_t module_initialization_70_cfa_tvector(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _unpatch_vector_set__250_cfa_tvector(obj_t);
static obj_t imported_modules_init_94_cfa_walk();
extern obj_t heap__stack__166_cfa_stack(obj_t, obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cfa_walk();
extern obj_t cfa_walk__41_cfa_walk(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t type_settings__207_cfa_type(obj_t);
extern obj_t cfa_iterate_to_fixpoint__166_cfa_iterate(obj_t);
static obj_t require_initialization_114_cfa_walk = BUNSPEC;
static obj_t _cfa_walk__129_cfa_walk(obj_t, obj_t);
extern obj_t collect_all_approx__236_cfa_collect(obj_t);
static obj_t cnst_init_137_cfa_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(cfa_walk__env_66_cfa_walk, _cfa_walk__129_cfa_walk2383, _cfa_walk__129_cfa_walk, 0L, 1);
DEFINE_STRING(string2377_cfa_walk, string2377_cfa_walk2384, "(UNPATCH-VECTOR-SET!) (CFA INLINE) PASS-STARTED ", 48);
DEFINE_STRING(string2376_cfa_walk, string2376_cfa_walk2385, "failure during postlude hook", 28);
DEFINE_STRING(string2375_cfa_walk, string2375_cfa_walk2386, " error", 6);
DEFINE_STRING(string2374_cfa_walk, string2374_cfa_walk2387, " occured, ending ...", 20);
DEFINE_STRING(string2373_cfa_walk, string2373_cfa_walk2388, "failure during prelude hook", 27);
DEFINE_STRING(string2372_cfa_walk, string2372_cfa_walk2389, "   . ", 5);
DEFINE_STRING(string2371_cfa_walk, string2371_cfa_walk2390, "Cfa", 3);
extern obj_t unpatch_vector_set__env_116_cfa_tvector;


/* module-initialization */ obj_t 
module_initialization_70_cfa_walk(long checksum_3278, char *from_3279)
{
   if (CBOOL(require_initialization_114_cfa_walk))
     {
	require_initialization_114_cfa_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_walk();
	cnst_init_137_cfa_walk();
	imported_modules_init_94_cfa_walk();
	method_init_76_cfa_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CFA_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "CFA_WALK");
   module_initialization_70___reader(((long) 0), "CFA_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_walk()
{
   {
      obj_t cnst_port_138_3270;
      cnst_port_138_3270 = open_input_string(string2377_cfa_walk);
      {
	 long i_3271;
	 i_3271 = ((long) 2);
       loop_3272:
	 {
	    bool_t test2378_3273;
	    test2378_3273 = (i_3271 == ((long) -1));
	    if (test2378_3273)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2379_3274;
		    {
		       obj_t list2380_3275;
		       {
			  obj_t arg2381_3276;
			  arg2381_3276 = BNIL;
			  list2380_3275 = MAKE_PAIR(cnst_port_138_3270, arg2381_3276);
		       }
		       arg2379_3274 = read___reader(list2380_3275);
		    }
		    CNST_TABLE_SET(i_3271, arg2379_3274);
		 }
		 {
		    int aux_3277;
		    {
		       long aux_3297;
		       aux_3297 = (i_3271 - ((long) 1));
		       aux_3277 = (int) (aux_3297);
		    }
		    {
		       long i_3300;
		       i_3300 = (long) (aux_3277);
		       i_3271 = i_3300;
		       goto loop_3272;
		    }
		 }
	      }
	 }
      }
   }
}


/* cfa-walk! */ obj_t 
cfa_walk__41_cfa_walk(obj_t globals_1)
{
   {
      obj_t list2077_2098;
      {
	 obj_t arg2079_2100;
	 {
	    obj_t arg2081_2102;
	    {
	       obj_t aux_3302;
	       aux_3302 = BCHAR(((unsigned char) '\n'));
	       arg2081_2102 = MAKE_PAIR(aux_3302, BNIL);
	    }
	    arg2079_2100 = MAKE_PAIR(string2371_cfa_walk, arg2081_2102);
	 }
	 list2077_2098 = MAKE_PAIR(string2372_cfa_walk, arg2079_2100);
      }
      verbose_tools_speek(BINT(((long) 1)), list2077_2098);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string2371_cfa_walk;
   {
      obj_t hooks_2104;
      obj_t hnames_2105;
      hooks_2104 = BNIL;
      hnames_2105 = BNIL;
    loop_2106:
      if (NULLP(hooks_2104))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test2087_2111;
	   {
	      obj_t fun2093_2117;
	      fun2093_2117 = CAR(hooks_2104);
	      {
		 obj_t aux_3314;
		 aux_3314 = PROCEDURE_ENTRY(fun2093_2117) (fun2093_2117, BEOA);
		 test2087_2111 = CBOOL(aux_3314);
	      }
	   }
	   if (test2087_2111)
	     {
		{
		   obj_t hnames_3321;
		   obj_t hooks_3319;
		   hooks_3319 = CDR(hooks_2104);
		   hnames_3321 = CDR(hnames_2105);
		   hnames_2105 = hnames_3321;
		   hooks_2104 = hooks_3319;
		   goto loop_2106;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string2371_cfa_walk, string2373_cfa_walk, CAR(hnames_2105));
	     }
	}
   }
   collect_all_approx__236_cfa_collect(globals_1);
   declare_approx_sets__132_cfa_approx();
   set_initial_approx__92_cfa_setup(globals_1);
   {
      obj_t iteration_roots_204_2118;
      iteration_roots_204_2118 = cfa_iterate_to_fixpoint__166_cfa_iterate(globals_1);
      show_cfa_nb_iterations_231_cfa_show();
      {
	 obj_t globals_2119;
	 globals_2119 = remove_var_123_ast_remove(CNST_TABLE_REF(((long) 1)), globals_1);
	 show_cfa_results_28_cfa_show(globals_2119);
	 heap__stack__166_cfa_stack(iteration_roots_204_2118, globals_2119);
	 {
	    obj_t additional_2120;
	    additional_2120 = vector__tvector__205_cfa_tvector(globals_2119);
	    type_settings__207_cfa_type(globals_2119);
	    closure_optimization__48_cfa_closure();
	    specialize__184_cfa_specialize(globals_2119);
	    {
	       obj_t value_2121;
	       value_2121 = shrinkify__187_ast_shrinkify(append_2_18___r4_pairs_and_lists_6_3(additional_2120, globals_2119));
	       {
		  bool_t test2094_2122;
		  {
		     long n1_2909;
		     n1_2909 = (long) CINT(_nb_error_on_pass__70_tools_error);
		     test2094_2122 = (n1_2909 > ((long) 0));
		  }
		  if (test2094_2122)
		    {
		       {
			  char *arg2097_2125;
			  {
			     bool_t test2104_2132;
			     {
				bool_t test2105_2133;
				{
				   obj_t obj_2911;
				   obj_2911 = _nb_error_on_pass__70_tools_error;
				   test2105_2133 = INTEGERP(obj_2911);
				}
				if (test2105_2133)
				  {
				     test2104_2132 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
				  }
				else
				  {
				     test2104_2132 = ((bool_t) 0);
				  }
			     }
			     if (test2104_2132)
			       {
				  arg2097_2125 = "s";
			       }
			     else
			       {
				  arg2097_2125 = "";
			       }
			  }
			  {
			     obj_t list2099_2127;
			     {
				obj_t arg2100_2128;
				{
				   obj_t arg2101_2129;
				   {
				      obj_t arg2102_2130;
				      arg2102_2130 = MAKE_PAIR(string2374_cfa_walk, BNIL);
				      {
					 obj_t aux_3349;
					 aux_3349 = string_to_bstring(arg2097_2125);
					 arg2101_2129 = MAKE_PAIR(aux_3349, arg2102_2130);
				      }
				   }
				   arg2100_2128 = MAKE_PAIR(string2375_cfa_walk, arg2101_2129);
				}
				list2099_2127 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg2100_2128);
			     }
			     fprint___r4_output_6_10_3(current_error_port, list2099_2127);
			  }
		       }
		       {
			  obj_t res2370_2913;
			  exit(((long) -1));
			  res2370_2913 = BINT(((long) -1));
			  return res2370_2913;
		       }
		    }
		  else
		    {
		       obj_t hooks_2134;
		       obj_t hnames_2135;
		       {
			  obj_t arg2106_2137;
			  obj_t arg2107_2138;
			  {
			     obj_t list2108_2139;
			     list2108_2139 = MAKE_PAIR(unpatch_vector_set__env_116_cfa_tvector, BNIL);
			     arg2106_2137 = list2108_2139;
			  }
			  arg2107_2138 = CNST_TABLE_REF(((long) 2));
			  hooks_2134 = arg2106_2137;
			  hnames_2135 = arg2107_2138;
			loop_2136:
			  if (NULLP(hooks_2134))
			    {
			       return value_2121;
			    }
			  else
			    {
			       bool_t test2111_2142;
			       {
				  obj_t fun2116_2147;
				  fun2116_2147 = CAR(hooks_2134);
				  {
				     obj_t aux_3362;
				     aux_3362 = PROCEDURE_ENTRY(fun2116_2147) (fun2116_2147, BEOA);
				     test2111_2142 = CBOOL(aux_3362);
				  }
			       }
			       if (test2111_2142)
				 {
				    {
				       obj_t hnames_3369;
				       obj_t hooks_3367;
				       hooks_3367 = CDR(hooks_2134);
				       hnames_3369 = CDR(hnames_2135);
				       hnames_2135 = hnames_3369;
				       hooks_2134 = hooks_3367;
				       goto loop_2136;
				    }
				 }
			       else
				 {
				    return internal_error_43_tools_error(_current_pass__25_engine_pass, string2376_cfa_walk, CAR(hnames_2135));
				 }
			    }
		       }
		    }
	       }
	    }
	 }
      }
   }
}


/* _cfa-walk! */ obj_t 
_cfa_walk__129_cfa_walk(obj_t env_3267, obj_t globals_3268)
{
   return cfa_walk__41_cfa_walk(globals_3268);
}


/* method-init */ obj_t 
method_init_76_cfa_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_walk()
{
   module_initialization_70_tools_speek(((long) 0), "CFA_WALK");
   module_initialization_70_tools_error(((long) 0), "CFA_WALK");
   module_initialization_70_engine_pass(((long) 0), "CFA_WALK");
   module_initialization_70_tools_shape(((long) 0), "CFA_WALK");
   module_initialization_70_engine_param(((long) 0), "CFA_WALK");
   module_initialization_70_type_type(((long) 0), "CFA_WALK");
   module_initialization_70_ast_remove(((long) 0), "CFA_WALK");
   module_initialization_70_ast_var(((long) 0), "CFA_WALK");
   module_initialization_70_ast_node(((long) 0), "CFA_WALK");
   module_initialization_70_ast_shrinkify(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_collect(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_setup(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_show(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_info(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_approx(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_stack(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_type(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_closure(((long) 0), "CFA_WALK");
   module_initialization_70_cfa_specialize(((long) 0), "CFA_WALK");
   return module_initialization_70_cfa_tvector(((long) 0), "CFA_WALK");
}
