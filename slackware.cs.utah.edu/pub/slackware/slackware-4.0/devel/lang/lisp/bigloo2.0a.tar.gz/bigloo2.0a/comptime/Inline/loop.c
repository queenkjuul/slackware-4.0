/*===========================================================================*/
/*   (Inline/loop.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;

typedef struct local_variant_63
  {
     bool_t variant;
  }
                *local_variant_63_t;


static obj_t _inner_loop_1844_190_inline_loop(obj_t, obj_t);
static obj_t method_init_76_inline_loop();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
static bool_t find_let_fun__default1508_172_inline_loop(node_t);
extern obj_t module_initialization_70_inline_loop(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_variant(long, char *);
extern obj_t module_initialization_70_inline_recursion(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static bool_t find_let_fun___232_inline_loop(obj_t);
extern long list_length(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t _nest_loop_1846_132_inline_loop(obj_t, obj_t, obj_t, obj_t);
extern bool_t is_loop__232_inline_loop(variable_t);
static obj_t imported_modules_init_94_inline_loop();
static obj_t _nest_loop__default1530_245_inline_loop(obj_t, obj_t, obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
static obj_t _is_loop_1843_197_inline_loop(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_inline_loop();
extern obj_t atom_ast_node;
static obj_t _find_let_fun_1845_108_inline_loop(obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_inline_loop();
static obj_t find_let_fun__180_inline_loop(node_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern bool_t inner_loop__79_inline_loop(variable_t);
extern obj_t setq_ast_node;
extern bool_t is_recursive__125_inline_recursion(variable_t);
extern obj_t box_set__221_ast_node;
static obj_t nest_loop___100_inline_loop(obj_t, local_t, obj_t);
static obj_t _find_let_fun__default1508_14_inline_loop(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_inline_loop = BUNSPEC;
extern obj_t conditional_ast_node;
static node_t nest_loop__default1530_206_inline_loop(node_t, local_t, obj_t);
extern node_t nest_loop__92_inline_loop(node_t, local_t, obj_t);
static obj_t cnst_init_137_inline_loop();
static obj_t __cnst[2];

DEFINE_EXPORT_GENERIC(nest_loop__env_29_inline_loop, _nest_loop_1846_132_inline_loop1854, _nest_loop_1846_132_inline_loop, 0L, 3);
DEFINE_STATIC_GENERIC(find_let_fun__env_154_inline_loop, _find_let_fun_1845_108_inline_loop1855, _find_let_fun_1845_108_inline_loop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(inner_loop__env_141_inline_loop, _inner_loop_1844_190_inline_loop1856, _inner_loop_1844_190_inline_loop, 0L, 1);
DEFINE_STATIC_PROCEDURE(find_let_fun__default1508_env_224_inline_loop, _find_let_fun__default1508_14_inline_loop1857, _find_let_fun__default1508_14_inline_loop, 0L, 1);
DEFINE_EXPORT_PROCEDURE(is_loop__env_96_inline_loop, _is_loop_1843_197_inline_loop1858, _is_loop_1843_197_inline_loop, 0L, 1);
DEFINE_STRING(string1848_inline_loop, string1848_inline_loop1859, "NEST-LOOP!-DEFAULT1530 DONE ", 28);
DEFINE_STRING(string1847_inline_loop, string1847_inline_loop1860, "No method for this object", 25);
DEFINE_STATIC_PROCEDURE(nest_loop__default1530_env_227_inline_loop, _nest_loop__default1530_245_inline_loop1861, _nest_loop__default1530_245_inline_loop, 0L, 3);


/* module-initialization */ obj_t 
module_initialization_70_inline_loop(long checksum_1764, char *from_1765)
{
   if (CBOOL(require_initialization_114_inline_loop))
     {
	require_initialization_114_inline_loop = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_loop();
	cnst_init_137_inline_loop();
	imported_modules_init_94_inline_loop();
	method_init_76_inline_loop();
	toplevel_init_63_inline_loop();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_loop()
{
   module_initialization_70___object(((long) 0), "INLINE_LOOP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_LOOP");
   module_initialization_70___reader(((long) 0), "INLINE_LOOP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_loop()
{
   {
      obj_t cnst_port_138_1756;
      cnst_port_138_1756 = open_input_string(string1848_inline_loop);
      {
	 long i_1757;
	 i_1757 = ((long) 1);
       loop_1758:
	 {
	    bool_t test1849_1759;
	    test1849_1759 = (i_1757 == ((long) -1));
	    if (test1849_1759)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1850_1760;
		    {
		       obj_t list1851_1761;
		       {
			  obj_t arg1852_1762;
			  arg1852_1762 = BNIL;
			  list1851_1761 = MAKE_PAIR(cnst_port_138_1756, arg1852_1762);
		       }
		       arg1850_1760 = read___reader(list1851_1761);
		    }
		    CNST_TABLE_SET(i_1757, arg1850_1760);
		 }
		 {
		    int aux_1763;
		    {
		       long aux_1783;
		       aux_1783 = (i_1757 - ((long) 1));
		       aux_1763 = (int) (aux_1783);
		    }
		    {
		       long i_1786;
		       i_1786 = (long) (aux_1763);
		       i_1757 = i_1786;
		       goto loop_1758;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_inline_loop()
{
   return BUNSPEC;
}


/* is-loop? */ bool_t 
is_loop__232_inline_loop(variable_t variable_1)
{
   {
      bool_t _andtest_1471_880;
      _andtest_1471_880 = is_recursive__125_inline_recursion(variable_1);
      if (_andtest_1471_880)
	{
	   long aux_1790;
	   {
	      obj_t aux_1791;
	      {
		 isfun_t obj_1504;
		 {
		    value_t aux_1792;
		    aux_1792 = (((variable_t) CREF(variable_1))->value);
		    obj_1504 = (isfun_t) (aux_1792);
		 }
		 {
		    obj_t aux_1795;
		    {
		       object_t aux_1796;
		       aux_1796 = (object_t) (obj_1504);
		       aux_1795 = OBJECT_WIDENING(aux_1796);
		    }
		    aux_1791 = (((isfun_t) CREF(aux_1795))->recursive_calls_44);
		 }
	      }
	      aux_1790 = list_length(aux_1791);
	   }
	   return (aux_1790 == ((long) 1));
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* _is-loop?1843 */ obj_t 
_is_loop_1843_197_inline_loop(obj_t env_1740, obj_t variable_1741)
{
   {
      bool_t aux_1802;
      aux_1802 = is_loop__232_inline_loop((variable_t) (variable_1741));
      return BBOOL(aux_1802);
   }
}


/* inner-loop? */ bool_t 
inner_loop__79_inline_loop(variable_t variable_2)
{
   {
      obj_t aux_1806;
      {
	 node_t aux_1807;
	 {
	    obj_t aux_1808;
	    {
	       sfun_t obj_1510;
	       {
		  value_t aux_1809;
		  aux_1809 = (((variable_t) CREF(variable_2))->value);
		  obj_1510 = (sfun_t) (aux_1809);
	       }
	       aux_1808 = (((sfun_t) CREF(obj_1510))->body);
	    }
	    aux_1807 = (node_t) (aux_1808);
	 }
	 aux_1806 = find_let_fun__180_inline_loop(aux_1807);
      }
      return CBOOL(aux_1806);
   }
}


/* _inner-loop?1844 */ obj_t 
_inner_loop_1844_190_inline_loop(obj_t env_1742, obj_t variable_1743)
{
   {
      bool_t aux_1816;
      aux_1816 = inner_loop__79_inline_loop((variable_t) (variable_1743));
      return BBOOL(aux_1816);
   }
}


/* find-let-fun?* */ bool_t 
find_let_fun___232_inline_loop(obj_t node__221_22)
{
   {
      obj_t node__221_887;
      node__221_887 = node__221_22;
    loop_888:
      if (NULLP(node__221_887))
	{
	   return ((bool_t) 0);
	}
      else
	{
	   bool_t test1566_890;
	   {
	      obj_t aux_1822;
	      {
		 node_t aux_1823;
		 {
		    obj_t aux_1824;
		    aux_1824 = CAR(node__221_887);
		    aux_1823 = (node_t) (aux_1824);
		 }
		 aux_1822 = find_let_fun__180_inline_loop(aux_1823);
	      }
	      test1566_890 = CBOOL(aux_1822);
	   }
	   if (test1566_890)
	     {
		return ((bool_t) 1);
	     }
	   else
	     {
		{
		   obj_t node__221_1830;
		   node__221_1830 = CDR(node__221_887);
		   node__221_887 = node__221_1830;
		   goto loop_888;
		}
	     }
	}
   }
}


/* nest-loop!* */ obj_t 
nest_loop___100_inline_loop(obj_t node__221_89, local_t var_90, obj_t nester_91)
{
   {
      obj_t node__221_893;
      node__221_893 = node__221_89;
    loop_894:
      if (NULLP(node__221_893))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   {
	      node_t arg1572_896;
	      {
		 node_t aux_1835;
		 {
		    obj_t aux_1836;
		    aux_1836 = CAR(node__221_893);
		    aux_1835 = (node_t) (aux_1836);
		 }
		 arg1572_896 = nest_loop__92_inline_loop(aux_1835, var_90, nester_91);
	      }
	      {
		 obj_t aux_1840;
		 aux_1840 = (obj_t) (arg1572_896);
		 SET_CAR(node__221_893, aux_1840);
	      }
	   }
	   {
	      obj_t node__221_1843;
	      node__221_1843 = CDR(node__221_893);
	      node__221_893 = node__221_1843;
	      goto loop_894;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_inline_loop()
{
   add_generic__110___object(find_let_fun__env_154_inline_loop, find_let_fun__default1508_env_224_inline_loop);
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, sequence_ast_node, ((long) 0));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, app_ast_node, ((long) 1));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, app_ly_162_ast_node, ((long) 2));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, funcall_ast_node, ((long) 3));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, pragma_ast_node, ((long) 4));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, cast_ast_node, ((long) 5));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, setq_ast_node, ((long) 6));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, conditional_ast_node, ((long) 7));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, fail_ast_node, ((long) 8));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, select_ast_node, ((long) 9));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, let_fun_218_ast_node, ((long) 10));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, let_var_6_ast_node, ((long) 11));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, set_ex_it_116_ast_node, ((long) 12));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, jump_ex_it_184_ast_node, ((long) 13));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, make_box_202_ast_node, ((long) 14));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, box_ref_242_ast_node, ((long) 15));
   add_inlined_method__244___object(find_let_fun__env_154_inline_loop, box_set__221_ast_node, ((long) 16));
   add_generic__110___object(nest_loop__env_29_inline_loop, nest_loop__default1530_env_227_inline_loop);
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, var_ast_node, ((long) 2));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, app_ast_node, ((long) 4));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, select_ast_node, ((long) 12));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(nest_loop__env_29_inline_loop, box_ref_242_ast_node, ((long) 18));
   {
      long aux_1883;
      aux_1883 = add_inlined_method__244___object(nest_loop__env_29_inline_loop, box_set__221_ast_node, ((long) 19));
      return BINT(aux_1883);
   }
}


/* find-let-fun? */ obj_t 
find_let_fun__180_inline_loop(node_t node_3)
{
 find_let_fun__180_inline_loop:
   {
      obj_t method1783_1415;
      obj_t class1788_1416;
      {
	 obj_t arg1791_1413;
	 obj_t arg1792_1414;
	 {
	    object_t obj_1554;
	    obj_1554 = (object_t) (node_3);
	    {
	       obj_t pre_method_105_1555;
	       pre_method_105_1555 = PROCEDURE_REF(find_let_fun__env_154_inline_loop, ((long) 2));
	       if (INTEGERP(pre_method_105_1555))
		 {
		    PROCEDURE_SET(find_let_fun__env_154_inline_loop, ((long) 2), BUNSPEC);
		    arg1791_1413 = pre_method_105_1555;
		 }
	       else
		 {
		    long obj_class_num_177_1560;
		    obj_class_num_177_1560 = TYPE(obj_1554);
		    {
		       obj_t arg1177_1561;
		       arg1177_1561 = PROCEDURE_REF(find_let_fun__env_154_inline_loop, ((long) 1));
		       {
			  long arg1178_1565;
			  {
			     long arg1179_1566;
			     arg1179_1566 = OBJECT_TYPE;
			     arg1178_1565 = (obj_class_num_177_1560 - arg1179_1566);
			  }
			  arg1791_1413 = VECTOR_REF(arg1177_1561, arg1178_1565);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1571;
	    object_1571 = (object_t) (node_3);
	    {
	       long arg1180_1572;
	       {
		  long arg1181_1573;
		  long arg1182_1574;
		  arg1181_1573 = TYPE(object_1571);
		  arg1182_1574 = OBJECT_TYPE;
		  arg1180_1572 = (arg1181_1573 - arg1182_1574);
	       }
	       {
		  obj_t vector_1578;
		  vector_1578 = _classes__134___object;
		  arg1792_1414 = VECTOR_REF(vector_1578, arg1180_1572);
	       }
	    }
	 }
	 method1783_1415 = arg1791_1413;
	 class1788_1416 = arg1792_1414;
	 {
	    if (INTEGERP(method1783_1415))
	      {
		 switch ((long) CINT(method1783_1415))
		   {
		   case ((long) 0):
		      {
			 sequence_t node_1422;
			 node_1422 = (sequence_t) (node_3);
			 {
			    bool_t aux_1904;
			    aux_1904 = find_let_fun___232_inline_loop((((sequence_t) CREF(node_1422))->nodes));
			    return BBOOL(aux_1904);
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 app_t node_1424;
			 node_1424 = (app_t) (node_3);
			 {
			    bool_t aux_1909;
			    aux_1909 = find_let_fun___232_inline_loop((((app_t) CREF(node_1424))->args));
			    return BBOOL(aux_1909);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 app_ly_162_t node_1427;
			 node_1427 = (app_ly_162_t) (node_3);
			 {
			    obj_t _ortest_1474_1429;
			    _ortest_1474_1429 = find_let_fun__180_inline_loop((((app_ly_162_t) CREF(node_1427))->fun));
			    if (CBOOL(_ortest_1474_1429))
			      {
				 return _ortest_1474_1429;
			      }
			    else
			      {
				 node_t node_1918;
				 node_1918 = (((app_ly_162_t) CREF(node_1427))->arg);
				 node_3 = node_1918;
				 goto find_let_fun__180_inline_loop;
			      }
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 funcall_t node_1432;
			 node_1432 = (funcall_t) (node_3);
			 {
			    obj_t _ortest_1476_1434;
			    _ortest_1476_1434 = find_let_fun__180_inline_loop((((funcall_t) CREF(node_1432))->fun));
			    if (CBOOL(_ortest_1476_1434))
			      {
				 return _ortest_1476_1434;
			      }
			    else
			      {
				 bool_t aux_1925;
				 aux_1925 = find_let_fun___232_inline_loop((((funcall_t) CREF(node_1432))->args));
				 return BBOOL(aux_1925);
			      }
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 pragma_t node_1437;
			 node_1437 = (pragma_t) (node_3);
			 {
			    bool_t aux_1930;
			    aux_1930 = find_let_fun___232_inline_loop((((pragma_t) CREF(node_1437))->args));
			    return BBOOL(aux_1930);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 cast_t node_1439;
			 node_1439 = (cast_t) (node_3);
			 {
			    node_t node_1935;
			    node_1935 = (((cast_t) CREF(node_1439))->arg);
			    node_3 = node_1935;
			    goto find_let_fun__180_inline_loop;
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 setq_t node_1441;
			 node_1441 = (setq_t) (node_3);
			 {
			    node_t node_1938;
			    node_1938 = (((setq_t) CREF(node_1441))->value);
			    node_3 = node_1938;
			    goto find_let_fun__180_inline_loop;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 conditional_t node_1443;
			 node_1443 = (conditional_t) (node_3);
			 {
			    obj_t _ortest_1478_1445;
			    _ortest_1478_1445 = find_let_fun__180_inline_loop((((conditional_t) CREF(node_1443))->test));
			    if (CBOOL(_ortest_1478_1445))
			      {
				 return _ortest_1478_1445;
			      }
			    else
			      {
				 obj_t _ortest_1479_1446;
				 _ortest_1479_1446 = find_let_fun__180_inline_loop((((conditional_t) CREF(node_1443))->true));
				 if (CBOOL(_ortest_1479_1446))
				   {
				      return _ortest_1479_1446;
				   }
				 else
				   {
				      node_t node_1949;
				      node_1949 = (((conditional_t) CREF(node_1443))->false);
				      node_3 = node_1949;
				      goto find_let_fun__180_inline_loop;
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 fail_t node_1450;
			 node_1450 = (fail_t) (node_3);
			 {
			    obj_t _ortest_1481_1452;
			    _ortest_1481_1452 = find_let_fun__180_inline_loop((((fail_t) CREF(node_1450))->proc));
			    if (CBOOL(_ortest_1481_1452))
			      {
				 return _ortest_1481_1452;
			      }
			    else
			      {
				 obj_t _ortest_1482_1453;
				 _ortest_1482_1453 = find_let_fun__180_inline_loop((((fail_t) CREF(node_1450))->msg));
				 if (CBOOL(_ortest_1482_1453))
				   {
				      return _ortest_1482_1453;
				   }
				 else
				   {
				      node_t node_1960;
				      node_1960 = (((fail_t) CREF(node_1450))->obj);
				      node_3 = node_1960;
				      goto find_let_fun__180_inline_loop;
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 select_t node_1457;
			 node_1457 = (select_t) (node_3);
			 {
			    obj_t clauses_1458;
			    clauses_1458 = (((select_t) CREF(node_1457))->clauses);
			  loop_1459:
			    if (NULLP(clauses_1458))
			      {
				 {
				    node_t node_1965;
				    node_1965 = (((select_t) CREF(node_1457))->test);
				    node_3 = node_1965;
				    goto find_let_fun__180_inline_loop;
				 }
			      }
			    else
			      {
				 bool_t test1815_1463;
				 {
				    obj_t aux_1967;
				    {
				       node_t aux_1968;
				       {
					  obj_t aux_1969;
					  {
					     obj_t aux_1970;
					     aux_1970 = CAR(clauses_1458);
					     aux_1969 = CDR(aux_1970);
					  }
					  aux_1968 = (node_t) (aux_1969);
				       }
				       aux_1967 = find_let_fun__180_inline_loop(aux_1968);
				    }
				    test1815_1463 = CBOOL(aux_1967);
				 }
				 if (test1815_1463)
				   {
				      return BTRUE;
				   }
				 else
				   {
				      {
					 obj_t clauses_1977;
					 clauses_1977 = CDR(clauses_1458);
					 clauses_1458 = clauses_1977;
					 goto loop_1459;
				      }
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 10):
		      return BTRUE;
		      break;
		   case ((long) 11):
		      {
			 let_var_6_t node_1468;
			 node_1468 = (let_var_6_t) (node_3);
			 {
			    obj_t bindings_1469;
			    bindings_1469 = (((let_var_6_t) CREF(node_1468))->bindings);
			  loop_1470:
			    if (NULLP(bindings_1469))
			      {
				 {
				    node_t node_1983;
				    node_1983 = (((let_var_6_t) CREF(node_1468))->body);
				    node_3 = node_1983;
				    goto find_let_fun__180_inline_loop;
				 }
			      }
			    else
			      {
				 bool_t test1823_1474;
				 {
				    obj_t aux_1985;
				    {
				       node_t aux_1986;
				       {
					  obj_t aux_1987;
					  {
					     obj_t aux_1988;
					     aux_1988 = CAR(bindings_1469);
					     aux_1987 = CDR(aux_1988);
					  }
					  aux_1986 = (node_t) (aux_1987);
				       }
				       aux_1985 = find_let_fun__180_inline_loop(aux_1986);
				    }
				    test1823_1474 = CBOOL(aux_1985);
				 }
				 if (test1823_1474)
				   {
				      return BTRUE;
				   }
				 else
				   {
				      {
					 obj_t bindings_1995;
					 bindings_1995 = CDR(bindings_1469);
					 bindings_1469 = bindings_1995;
					 goto loop_1470;
				      }
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 set_ex_it_116_t node_1478;
			 node_1478 = (set_ex_it_116_t) (node_3);
			 {
			    node_t node_1999;
			    node_1999 = (((set_ex_it_116_t) CREF(node_1478))->body);
			    node_3 = node_1999;
			    goto find_let_fun__180_inline_loop;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 jump_ex_it_184_t node_1480;
			 node_1480 = (jump_ex_it_184_t) (node_3);
			 {
			    obj_t _ortest_1484_1482;
			    _ortest_1484_1482 = find_let_fun__180_inline_loop((((jump_ex_it_184_t) CREF(node_1480))->exit));
			    if (CBOOL(_ortest_1484_1482))
			      {
				 return _ortest_1484_1482;
			      }
			    else
			      {
				 node_t node_2006;
				 node_2006 = (((jump_ex_it_184_t) CREF(node_1480))->value);
				 node_3 = node_2006;
				 goto find_let_fun__180_inline_loop;
			      }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 make_box_202_t node_1485;
			 node_1485 = (make_box_202_t) (node_3);
			 {
			    node_t node_2009;
			    node_2009 = (((make_box_202_t) CREF(node_1485))->value);
			    node_3 = node_2009;
			    goto find_let_fun__180_inline_loop;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 box_ref_242_t node_1487;
			 node_1487 = (box_ref_242_t) (node_3);
			 {
			    node_t node_2012;
			    {
			       var_t aux_2013;
			       aux_2013 = (((box_ref_242_t) CREF(node_1487))->var);
			       node_2012 = (node_t) (aux_2013);
			    }
			    node_3 = node_2012;
			    goto find_let_fun__180_inline_loop;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 box_set__221_t node_1489;
			 node_1489 = (box_set__221_t) (node_3);
			 {
			    obj_t _ortest_1486_1491;
			    {
			       node_t aux_2017;
			       {
				  var_t aux_2018;
				  aux_2018 = (((box_set__221_t) CREF(node_1489))->var);
				  aux_2017 = (node_t) (aux_2018);
			       }
			       _ortest_1486_1491 = find_let_fun__180_inline_loop(aux_2017);
			    }
			    if (CBOOL(_ortest_1486_1491))
			      {
				 return _ortest_1486_1491;
			      }
			    else
			      {
				 node_t node_2024;
				 node_2024 = (((box_set__221_t) CREF(node_1489))->value);
				 node_3 = node_2024;
				 goto find_let_fun__180_inline_loop;
			      }
			 }
		      }
		      break;
		   default:
		    case_else1789_1419:
		      if (PROCEDUREP(method1783_1415))
			{
			   return PROCEDURE_ENTRY(method1783_1415) (method1783_1415, (obj_t) (node_3), BEOA);
			}
		      else
			{
			   obj_t fun1680_1241;
			   fun1680_1241 = PROCEDURE_REF(find_let_fun__env_154_inline_loop, ((long) 0));
			   return PROCEDURE_ENTRY(fun1680_1241) (fun1680_1241, (obj_t) (node_3), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1789_1419;
	      }
	 }
      }
   }
}


/* _find-let-fun?1845 */ obj_t 
_find_let_fun_1845_108_inline_loop(obj_t env_1744, obj_t node_1745)
{
   return find_let_fun__180_inline_loop((node_t) (node_1745));
}


/* find-let-fun?-default1508 */ bool_t 
find_let_fun__default1508_172_inline_loop(node_t node_4)
{
   return ((bool_t) 0);
}


/* _find-let-fun?-default1508 */ obj_t 
_find_let_fun__default1508_14_inline_loop(obj_t env_1746, obj_t node_1747)
{
   {
      bool_t aux_2039;
      aux_2039 = find_let_fun__default1508_172_inline_loop((node_t) (node_1747));
      return BBOOL(aux_2039);
   }
}


/* nest-loop! */ node_t 
nest_loop__92_inline_loop(node_t node_23, local_t local_24, obj_t nester_25)
{
   {
      obj_t method1686_1248;
      obj_t class1691_1249;
      {
	 obj_t arg1694_1246;
	 obj_t arg1695_1247;
	 {
	    object_t obj_1616;
	    obj_1616 = (object_t) (node_23);
	    {
	       obj_t pre_method_105_1617;
	       pre_method_105_1617 = PROCEDURE_REF(nest_loop__env_29_inline_loop, ((long) 2));
	       if (INTEGERP(pre_method_105_1617))
		 {
		    PROCEDURE_SET(nest_loop__env_29_inline_loop, ((long) 2), BUNSPEC);
		    arg1694_1246 = pre_method_105_1617;
		 }
	       else
		 {
		    long obj_class_num_177_1622;
		    obj_class_num_177_1622 = TYPE(obj_1616);
		    {
		       obj_t arg1177_1623;
		       arg1177_1623 = PROCEDURE_REF(nest_loop__env_29_inline_loop, ((long) 1));
		       {
			  long arg1178_1627;
			  {
			     long arg1179_1628;
			     arg1179_1628 = OBJECT_TYPE;
			     arg1178_1627 = (obj_class_num_177_1622 - arg1179_1628);
			  }
			  arg1694_1246 = VECTOR_REF(arg1177_1623, arg1178_1627);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1633;
	    object_1633 = (object_t) (node_23);
	    {
	       long arg1180_1634;
	       {
		  long arg1181_1635;
		  long arg1182_1636;
		  arg1181_1635 = TYPE(object_1633);
		  arg1182_1636 = OBJECT_TYPE;
		  arg1180_1634 = (arg1181_1635 - arg1182_1636);
	       }
	       {
		  obj_t vector_1640;
		  vector_1640 = _classes__134___object;
		  arg1695_1247 = VECTOR_REF(vector_1640, arg1180_1634);
	       }
	    }
	 }
	 {
	    obj_t aux_2058;
	    method1686_1248 = arg1694_1246;
	    class1691_1249 = arg1695_1247;
	    {
	       if (INTEGERP(method1686_1248))
		 {
		    switch ((long) CINT(method1686_1248))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_2061;
			    aux_2061 = (atom_t) (node_23);
			    aux_2058 = (obj_t) (aux_2061);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_2064;
			    aux_2064 = (kwote_t) (node_23);
			    aux_2058 = (obj_t) (aux_2064);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_2067;
			    aux_2067 = (var_t) (node_23);
			    aux_2058 = (obj_t) (aux_2067);
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1264;
			    node_1264 = (sequence_t) (node_23);
			    nest_loop___100_inline_loop((((sequence_t) CREF(node_1264))->nodes), local_24, nester_25);
			    aux_2058 = (obj_t) (node_1264);
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1269;
			    node_1269 = (app_t) (node_23);
			    nest_loop___100_inline_loop((((app_t) CREF(node_1269))->args), local_24, nester_25);
			    {
			       bool_t test1700_1274;
			       {
				  bool_t test1701_1275;
				  {
				     obj_t aux_2077;
				     {
					var_t aux_2078;
					aux_2078 = (((app_t) CREF(node_1269))->fun);
					aux_2077 = (obj_t) (aux_2078);
				     }
				     test1701_1275 = is_a__118___object(aux_2077, var_ast_node);
				  }
				  if (test1701_1275)
				    {
				       obj_t aux_2088;
				       obj_t aux_2083;
				       aux_2088 = (obj_t) (local_24);
				       {
					  variable_t aux_2084;
					  {
					     var_t arg1703_1277;
					     arg1703_1277 = (((app_t) CREF(node_1269))->fun);
					     aux_2084 = (((var_t) CREF(arg1703_1277))->variable);
					  }
					  aux_2083 = (obj_t) (aux_2084);
				       }
				       test1700_1274 = (aux_2083 == aux_2088);
				    }
				  else
				    {
				       test1700_1274 = ((bool_t) 0);
				    }
			       }
			       if (test1700_1274)
				 {
				    aux_2058 = PROCEDURE_ENTRY(nester_25) (nester_25, (obj_t) (node_1269), BEOA);
				 }
			       else
				 {
				    aux_2058 = (obj_t) (node_1269);
				 }
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1279;
			    node_1279 = (app_ly_162_t) (node_23);
			    {
			       node_t arg1705_1283;
			       arg1705_1283 = nest_loop__92_inline_loop((((app_ly_162_t) CREF(node_1279))->fun), local_24, nester_25);
			       ((((app_ly_162_t) CREF(node_1279))->fun) = ((node_t) arg1705_1283), BUNSPEC);
			    }
			    {
			       node_t arg1707_1285;
			       arg1707_1285 = nest_loop__92_inline_loop((((app_ly_162_t) CREF(node_1279))->arg), local_24, nester_25);
			       ((((app_ly_162_t) CREF(node_1279))->arg) = ((node_t) arg1707_1285), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1279);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1287;
			    node_1287 = (funcall_t) (node_23);
			    {
			       node_t arg1709_1291;
			       arg1709_1291 = nest_loop__92_inline_loop((((funcall_t) CREF(node_1287))->fun), local_24, nester_25);
			       ((((funcall_t) CREF(node_1287))->fun) = ((node_t) arg1709_1291), BUNSPEC);
			    }
			    nest_loop___100_inline_loop((((funcall_t) CREF(node_1287))->args), local_24, nester_25);
			    aux_2058 = (obj_t) (node_1287);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1294;
			    node_1294 = (pragma_t) (node_23);
			    nest_loop___100_inline_loop((((pragma_t) CREF(node_1294))->args), local_24, nester_25);
			    aux_2058 = (obj_t) (node_1294);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1298;
			    node_1298 = (cast_t) (node_23);
			    nest_loop__92_inline_loop((((cast_t) CREF(node_1298))->arg), local_24, nester_25);
			    aux_2058 = (obj_t) (node_1298);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1302;
			    node_1302 = (setq_t) (node_23);
			    nest_loop__92_inline_loop((((setq_t) CREF(node_1302))->value), local_24, nester_25);
			    aux_2058 = (obj_t) (node_1302);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1306;
			    node_1306 = (conditional_t) (node_23);
			    {
			       node_t arg1716_1310;
			       arg1716_1310 = nest_loop__92_inline_loop((((conditional_t) CREF(node_1306))->test), local_24, nester_25);
			       ((((conditional_t) CREF(node_1306))->test) = ((node_t) arg1716_1310), BUNSPEC);
			    }
			    {
			       node_t arg1718_1312;
			       arg1718_1312 = nest_loop__92_inline_loop((((conditional_t) CREF(node_1306))->true), local_24, nester_25);
			       ((((conditional_t) CREF(node_1306))->true) = ((node_t) arg1718_1312), BUNSPEC);
			    }
			    {
			       node_t arg1721_1314;
			       arg1721_1314 = nest_loop__92_inline_loop((((conditional_t) CREF(node_1306))->false), local_24, nester_25);
			       ((((conditional_t) CREF(node_1306))->false) = ((node_t) arg1721_1314), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1306);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1316;
			    node_1316 = (fail_t) (node_23);
			    {
			       node_t arg1723_1320;
			       arg1723_1320 = nest_loop__92_inline_loop((((fail_t) CREF(node_1316))->proc), local_24, nester_25);
			       ((((fail_t) CREF(node_1316))->proc) = ((node_t) arg1723_1320), BUNSPEC);
			    }
			    {
			       node_t arg1725_1322;
			       arg1725_1322 = nest_loop__92_inline_loop((((fail_t) CREF(node_1316))->msg), local_24, nester_25);
			       ((((fail_t) CREF(node_1316))->msg) = ((node_t) arg1725_1322), BUNSPEC);
			    }
			    {
			       node_t arg1727_1324;
			       arg1727_1324 = nest_loop__92_inline_loop((((fail_t) CREF(node_1316))->obj), local_24, nester_25);
			       ((((fail_t) CREF(node_1316))->obj) = ((node_t) arg1727_1324), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1316);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1326;
			    node_1326 = (select_t) (node_23);
			    {
			       node_t arg1729_1330;
			       arg1729_1330 = nest_loop__92_inline_loop((((select_t) CREF(node_1326))->test), local_24, nester_25);
			       ((((select_t) CREF(node_1326))->test) = ((node_t) arg1729_1330), BUNSPEC);
			    }
			    {
			       obj_t l1494_1332;
			       l1494_1332 = (((select_t) CREF(node_1326))->clauses);
			     lname1495_1333:
			       if (PAIRP(l1494_1332))
				 {
				    {
				       obj_t clause_1336;
				       clause_1336 = CAR(l1494_1332);
				       {
					  node_t arg1733_1337;
					  {
					     node_t aux_2152;
					     {
						obj_t aux_2153;
						aux_2153 = CDR(clause_1336);
						aux_2152 = (node_t) (aux_2153);
					     }
					     arg1733_1337 = nest_loop__92_inline_loop(aux_2152, local_24, nester_25);
					  }
					  {
					     obj_t aux_2157;
					     aux_2157 = (obj_t) (arg1733_1337);
					     SET_CDR(clause_1336, aux_2157);
					  }
				       }
				    }
				    {
				       obj_t l1494_2160;
				       l1494_2160 = CDR(l1494_1332);
				       l1494_1332 = l1494_2160;
				       goto lname1495_1333;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2058 = (obj_t) (node_1326);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1340;
			    node_1340 = (let_fun_218_t) (node_23);
			    {
			       node_t arg1740_1344;
			       arg1740_1344 = nest_loop__92_inline_loop((((let_fun_218_t) CREF(node_1340))->body), local_24, nester_25);
			       ((((let_fun_218_t) CREF(node_1340))->body) = ((node_t) arg1740_1344), BUNSPEC);
			    }
			    {
			       obj_t l1497_1346;
			       l1497_1346 = (((let_fun_218_t) CREF(node_1340))->locals);
			     lname1498_1347:
			       if (PAIRP(l1497_1346))
				 {
				    {
				       value_t sfun_1351;
				       {
					  local_t obj_1697;
					  {
					     obj_t aux_2170;
					     aux_2170 = CAR(l1497_1346);
					     obj_1697 = (local_t) (aux_2170);
					  }
					  sfun_1351 = (((local_t) CREF(obj_1697))->value);
				       }
				       {
					  node_t arg1746_1352;
					  {
					     node_t aux_2174;
					     {
						obj_t aux_2175;
						{
						   sfun_t obj_1698;
						   obj_1698 = (sfun_t) (sfun_1351);
						   aux_2175 = (((sfun_t) CREF(obj_1698))->body);
						}
						aux_2174 = (node_t) (aux_2175);
					     }
					     arg1746_1352 = nest_loop__92_inline_loop(aux_2174, local_24, nester_25);
					  }
					  {
					     sfun_t obj_1699;
					     obj_t val1137_1700;
					     obj_1699 = (sfun_t) (sfun_1351);
					     val1137_1700 = (obj_t) (arg1746_1352);
					     ((((sfun_t) CREF(obj_1699))->body) = ((obj_t) val1137_1700), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l1497_2183;
				       l1497_2183 = CDR(l1497_1346);
				       l1497_1346 = l1497_2183;
				       goto lname1498_1347;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2058 = (obj_t) (node_1340);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1355;
			    node_1355 = (let_var_6_t) (node_23);
			    {
			       node_t arg1749_1359;
			       arg1749_1359 = nest_loop__92_inline_loop((((let_var_6_t) CREF(node_1355))->body), local_24, nester_25);
			       ((((let_var_6_t) CREF(node_1355))->body) = ((node_t) arg1749_1359), BUNSPEC);
			    }
			    {
			       obj_t l1500_1361;
			       l1500_1361 = (((let_var_6_t) CREF(node_1355))->bindings);
			     lname1501_1362:
			       if (PAIRP(l1500_1361))
				 {
				    {
				       obj_t binding_1365;
				       binding_1365 = CAR(l1500_1361);
				       {
					  node_t arg1758_1366;
					  {
					     node_t aux_2194;
					     {
						obj_t aux_2195;
						aux_2195 = CDR(binding_1365);
						aux_2194 = (node_t) (aux_2195);
					     }
					     arg1758_1366 = nest_loop__92_inline_loop(aux_2194, local_24, nester_25);
					  }
					  {
					     obj_t aux_2199;
					     aux_2199 = (obj_t) (arg1758_1366);
					     SET_CDR(binding_1365, aux_2199);
					  }
				       }
				    }
				    {
				       obj_t l1500_2202;
				       l1500_2202 = CDR(l1500_1361);
				       l1500_1361 = l1500_2202;
				       goto lname1501_1362;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2058 = (obj_t) (node_1355);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1369;
			    node_1369 = (set_ex_it_116_t) (node_23);
			    {
			       node_t arg1761_1373;
			       arg1761_1373 = nest_loop__92_inline_loop((((set_ex_it_116_t) CREF(node_1369))->body), local_24, nester_25);
			       ((((set_ex_it_116_t) CREF(node_1369))->body) = ((node_t) arg1761_1373), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1369);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1375;
			    node_1375 = (jump_ex_it_184_t) (node_23);
			    {
			       node_t arg1765_1379;
			       arg1765_1379 = nest_loop__92_inline_loop((((jump_ex_it_184_t) CREF(node_1375))->exit), local_24, nester_25);
			       ((((jump_ex_it_184_t) CREF(node_1375))->exit) = ((node_t) arg1765_1379), BUNSPEC);
			    }
			    {
			       node_t arg1767_1381;
			       arg1767_1381 = nest_loop__92_inline_loop((((jump_ex_it_184_t) CREF(node_1375))->value), local_24, nester_25);
			       ((((jump_ex_it_184_t) CREF(node_1375))->value) = ((node_t) arg1767_1381), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1375);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1383;
			    node_1383 = (make_box_202_t) (node_23);
			    {
			       node_t arg1769_1387;
			       arg1769_1387 = nest_loop__92_inline_loop((((make_box_202_t) CREF(node_1383))->value), local_24, nester_25);
			       ((((make_box_202_t) CREF(node_1383))->value) = ((node_t) arg1769_1387), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1383);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_ref_242_t node_1389;
			    node_1389 = (box_ref_242_t) (node_23);
			    {
			       node_t arg1771_1393;
			       {
				  node_t aux_2225;
				  {
				     var_t aux_2226;
				     aux_2226 = (((box_ref_242_t) CREF(node_1389))->var);
				     aux_2225 = (node_t) (aux_2226);
				  }
				  arg1771_1393 = nest_loop__92_inline_loop(aux_2225, local_24, nester_25);
			       }
			       {
				  var_t val1425_1726;
				  val1425_1726 = (var_t) (arg1771_1393);
				  ((((box_ref_242_t) CREF(node_1389))->var) = ((var_t) val1425_1726), BUNSPEC);
			       }
			    }
			    aux_2058 = (obj_t) (node_1389);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_set__221_t node_1395;
			    node_1395 = (box_set__221_t) (node_23);
			    {
			       node_t arg1773_1399;
			       {
				  node_t aux_2234;
				  {
				     var_t aux_2235;
				     aux_2235 = (((box_set__221_t) CREF(node_1395))->var);
				     aux_2234 = (node_t) (aux_2235);
				  }
				  arg1773_1399 = nest_loop__92_inline_loop(aux_2234, local_24, nester_25);
			       }
			       {
				  var_t val1434_1729;
				  val1434_1729 = (var_t) (arg1773_1399);
				  ((((box_set__221_t) CREF(node_1395))->var) = ((var_t) val1434_1729), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1776_1401;
			       arg1776_1401 = nest_loop__92_inline_loop((((box_set__221_t) CREF(node_1395))->value), local_24, nester_25);
			       ((((box_set__221_t) CREF(node_1395))->value) = ((node_t) arg1776_1401), BUNSPEC);
			    }
			    aux_2058 = (obj_t) (node_1395);
			 }
			 break;
		      default:
		       case_else1692_1252:
			 if (PROCEDUREP(method1686_1248))
			   {
			      aux_2058 = PROCEDURE_ENTRY(method1686_1248) (method1686_1248, (obj_t) (node_23), (obj_t) (local_24), nester_25, BEOA);
			   }
			 else
			   {
			      obj_t fun1683_1242;
			      fun1683_1242 = PROCEDURE_REF(nest_loop__env_29_inline_loop, ((long) 0));
			      aux_2058 = PROCEDURE_ENTRY(fun1683_1242) (fun1683_1242, (obj_t) (node_23), (obj_t) (local_24), nester_25, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1692_1252;
		 }
	    }
	    return (node_t) (aux_2058);
	 }
      }
   }
}


/* _nest-loop!1846 */ obj_t 
_nest_loop_1846_132_inline_loop(obj_t env_1748, obj_t node_1749, obj_t local_1750, obj_t nester_1751)
{
   {
      node_t aux_2259;
      aux_2259 = nest_loop__92_inline_loop((node_t) (node_1749), (local_t) (local_1750), nester_1751);
      return (obj_t) (aux_2259);
   }
}


/* nest-loop!-default1530 */ node_t 
nest_loop__default1530_206_inline_loop(node_t node_26, local_t local_27, obj_t nester_28)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1847_inline_loop, (obj_t) (node_26));
}


/* _nest-loop!-default1530 */ obj_t 
_nest_loop__default1530_245_inline_loop(obj_t env_1752, obj_t node_1753, obj_t local_1754, obj_t nester_1755)
{
   {
      node_t aux_2267;
      aux_2267 = nest_loop__default1530_206_inline_loop((node_t) (node_1753), (local_t) (local_1754), nester_1755);
      return (obj_t) (aux_2267);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_loop()
{
   module_initialization_70_tools_trace(((long) 0), "INLINE_LOOP");
   module_initialization_70_engine_param(((long) 0), "INLINE_LOOP");
   module_initialization_70_type_type(((long) 0), "INLINE_LOOP");
   module_initialization_70_ast_var(((long) 0), "INLINE_LOOP");
   module_initialization_70_ast_node(((long) 0), "INLINE_LOOP");
   module_initialization_70_ast_local(((long) 0), "INLINE_LOOP");
   module_initialization_70_ast_sexp(((long) 0), "INLINE_LOOP");
   module_initialization_70_tools_speek(((long) 0), "INLINE_LOOP");
   module_initialization_70_tools_shape(((long) 0), "INLINE_LOOP");
   module_initialization_70_tools_error(((long) 0), "INLINE_LOOP");
   module_initialization_70_inline_inline(((long) 0), "INLINE_LOOP");
   module_initialization_70_inline_variant(((long) 0), "INLINE_LOOP");
   module_initialization_70_inline_recursion(((long) 0), "INLINE_LOOP");
   return module_initialization_70_effect_effect(((long) 0), "INLINE_LOOP");
}
