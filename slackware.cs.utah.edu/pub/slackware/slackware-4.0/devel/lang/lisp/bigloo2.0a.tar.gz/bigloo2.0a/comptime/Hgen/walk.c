/*===========================================================================*/
/*   (Hgen/walk.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_hgen_walk();
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t _c_port__188_cgen_emit;
extern obj_t stop_emission__231_cgen_emit();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_hgen_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t imported_modules_init_94_hgen_walk();
extern obj_t emit_header_99_cgen_emit();
extern obj_t hgen_walk_202_hgen_walk();
static obj_t library_modules_init_112_hgen_walk();
extern obj_t start_emission__101_cgen_emit(obj_t);
extern obj_t open_input_string(obj_t);
static obj_t arg1470_hgen_walk(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _hgen_walk_236_hgen_walk(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t emit_class_types_26_object_class(obj_t);
static obj_t require_initialization_114_hgen_walk = BUNSPEC;
static obj_t cnst_init_137_hgen_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(proc1579_hgen_walk, arg1470_hgen_walk1587, arg1470_hgen_walk, 0L, 0);
DEFINE_EXPORT_PROCEDURE(hgen_walk_env_69_hgen_walk, _hgen_walk_236_hgen_walk1588, _hgen_walk_236_hgen_walk, 0L, 0);
DEFINE_STRING(string1581_hgen_walk, string1581_hgen_walk1589, "((LAMBDA () (START-EMISSION! \".h\"))) PASS-STARTED ", 50);
DEFINE_STRING(string1580_hgen_walk, string1580_hgen_walk1590, ".h", 2);
DEFINE_STRING(string1578_hgen_walk, string1578_hgen_walk1591, "failure during prelude hook", 27);
DEFINE_STRING(string1577_hgen_walk, string1577_hgen_walk1592, "   . ", 5);
DEFINE_STRING(string1576_hgen_walk, string1576_hgen_walk1593, "C headers generation", 20);


/* module-initialization */ obj_t 
module_initialization_70_hgen_walk(long checksum_1170, char *from_1171)
{
   if (CBOOL(require_initialization_114_hgen_walk))
     {
	require_initialization_114_hgen_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_hgen_walk();
	cnst_init_137_hgen_walk();
	imported_modules_init_94_hgen_walk();
	method_init_76_hgen_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_hgen_walk()
{
   module_initialization_70___reader(((long) 0), "HGEN_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_hgen_walk()
{
   {
      obj_t cnst_port_138_1162;
      cnst_port_138_1162 = open_input_string(string1581_hgen_walk);
      {
	 long i_1163;
	 i_1163 = ((long) 1);
       loop_1164:
	 {
	    bool_t test1582_1165;
	    test1582_1165 = (i_1163 == ((long) -1));
	    if (test1582_1165)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1583_1166;
		    {
		       obj_t list1584_1167;
		       {
			  obj_t arg1585_1168;
			  arg1585_1168 = BNIL;
			  list1584_1167 = MAKE_PAIR(cnst_port_138_1162, arg1585_1168);
		       }
		       arg1583_1166 = read___reader(list1584_1167);
		    }
		    CNST_TABLE_SET(i_1163, arg1583_1166);
		 }
		 {
		    int aux_1169;
		    {
		       long aux_1186;
		       aux_1186 = (i_1163 - ((long) 1));
		       aux_1169 = (int) (aux_1186);
		    }
		    {
		       long i_1189;
		       i_1189 = (long) (aux_1169);
		       i_1163 = i_1189;
		       goto loop_1164;
		    }
		 }
	      }
	 }
      }
   }
}


/* hgen-walk */ obj_t 
hgen_walk_202_hgen_walk()
{
   {
      obj_t list1462_766;
      {
	 obj_t arg1464_768;
	 {
	    obj_t arg1466_770;
	    {
	       obj_t aux_1191;
	       aux_1191 = BCHAR(((unsigned char) '\n'));
	       arg1466_770 = MAKE_PAIR(aux_1191, BNIL);
	    }
	    arg1464_768 = MAKE_PAIR(string1576_hgen_walk, arg1466_770);
	 }
	 list1462_766 = MAKE_PAIR(string1577_hgen_walk, arg1464_768);
      }
      verbose_tools_speek(BINT(((long) 1)), list1462_766);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1576_hgen_walk;
   {
      obj_t hooks_772;
      obj_t hnames_773;
      {
	 obj_t arg1468_775;
	 obj_t arg1469_776;
	 {
	    obj_t arg1470_1159;
	    arg1470_1159 = proc1579_hgen_walk;
	    {
	       obj_t list1471_778;
	       list1471_778 = MAKE_PAIR(arg1470_1159, BNIL);
	       arg1468_775 = list1471_778;
	    }
	 }
	 arg1469_776 = CNST_TABLE_REF(((long) 1));
	 hooks_772 = arg1468_775;
	 hnames_773 = arg1469_776;
       loop_774:
	 if (NULLP(hooks_772))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1476_783;
	      {
		 obj_t fun1482_789;
		 fun1482_789 = CAR(hooks_772);
		 {
		    obj_t aux_1205;
		    aux_1205 = PROCEDURE_ENTRY(fun1482_789) (fun1482_789, BEOA);
		    test1476_783 = CBOOL(aux_1205);
		 }
	      }
	      if (test1476_783)
		{
		   {
		      obj_t hnames_1212;
		      obj_t hooks_1210;
		      hooks_1210 = CDR(hooks_772);
		      hnames_1212 = CDR(hnames_773);
		      hnames_773 = hnames_1212;
		      hooks_772 = hooks_1210;
		      goto loop_774;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1576_hgen_walk, string1578_hgen_walk, CAR(hnames_773));
		}
	   }
      }
   }
   emit_header_99_cgen_emit();
   emit_class_types_26_object_class(_c_port__188_cgen_emit);
   return stop_emission__231_cgen_emit();
}


/* _hgen-walk */ obj_t 
_hgen_walk_236_hgen_walk(obj_t env_1160)
{
   return hgen_walk_202_hgen_walk();
}


/* arg1470 */ obj_t 
arg1470_hgen_walk(obj_t env_1161)
{
   {
      return start_emission__101_cgen_emit(string1580_hgen_walk);
   }
}


/* method-init */ obj_t 
method_init_76_hgen_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_hgen_walk()
{
   module_initialization_70_tools_speek(((long) 0), "HGEN_WALK");
   module_initialization_70_tools_error(((long) 0), "HGEN_WALK");
   module_initialization_70_engine_pass(((long) 0), "HGEN_WALK");
   module_initialization_70_type_type(((long) 0), "HGEN_WALK");
   module_initialization_70_object_class(((long) 0), "HGEN_WALK");
   module_initialization_70_ast_var(((long) 0), "HGEN_WALK");
   module_initialization_70_ast_node(((long) 0), "HGEN_WALK");
   return module_initialization_70_cgen_emit(((long) 0), "HGEN_WALK");
}
