/*===========================================================================*/
/*   (Globalize/walk.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_globalize_walk();
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t globalize__167_globalize_globalize(global_t);
extern obj_t globalize_walk__63_globalize_walk(obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t _globalize_walk_1590_124_globalize_walk(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_globalize_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_escape(long, char *);
extern obj_t module_initialization_70_globalize_globalize(long, char *);
extern obj_t module_initialization_70_globalize_global_closure_246(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t imported_modules_init_94_globalize_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_globalize_walk();
extern obj_t foreign_closures_19_globalize_global_closure_246();
extern obj_t open_input_string(obj_t);
extern obj_t escape_fun__53_globalize_escape(variable_t);
extern obj_t string_to_bstring(char *);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_globalize_walk = BUNSPEC;
static obj_t cnst_init_137_globalize_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(globalize_walk__env_111_globalize_walk, _globalize_walk_1590_124_globalize_walk1604, _globalize_walk_1590_124_globalize_walk, 0L, 2);
DEFINE_STRING(string1597_globalize_walk, string1597_globalize_walk1605, "PASS-STARTED ", 13);
DEFINE_STRING(string1596_globalize_walk, string1596_globalize_walk1606, "failure during postlude hook", 28);
DEFINE_STRING(string1595_globalize_walk, string1595_globalize_walk1607, " error", 6);
DEFINE_STRING(string1594_globalize_walk, string1594_globalize_walk1608, " occured, ending ...", 20);
DEFINE_STRING(string1593_globalize_walk, string1593_globalize_walk1609, "failure during prelude hook", 27);
DEFINE_STRING(string1592_globalize_walk, string1592_globalize_walk1610, "   . ", 5);
DEFINE_STRING(string1591_globalize_walk, string1591_globalize_walk1611, "Globalization", 13);


/* module-initialization */ obj_t 
module_initialization_70_globalize_walk(long checksum_1115, char *from_1116)
{
   if (CBOOL(require_initialization_114_globalize_walk))
     {
	require_initialization_114_globalize_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_walk();
	cnst_init_137_globalize_walk();
	imported_modules_init_94_globalize_walk();
	method_init_76_globalize_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_walk()
{
   {
      obj_t cnst_port_138_1107;
      cnst_port_138_1107 = open_input_string(string1597_globalize_walk);
      {
	 long i_1108;
	 i_1108 = ((long) 0);
       loop_1109:
	 {
	    bool_t test1598_1110;
	    test1598_1110 = (i_1108 == ((long) -1));
	    if (test1598_1110)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1600_1111;
		    {
		       obj_t list1601_1112;
		       {
			  obj_t arg1602_1113;
			  arg1602_1113 = BNIL;
			  list1601_1112 = MAKE_PAIR(cnst_port_138_1107, arg1602_1113);
		       }
		       arg1600_1111 = read___reader(list1601_1112);
		    }
		    CNST_TABLE_SET(i_1108, arg1600_1111);
		 }
		 {
		    int aux_1114;
		    {
		       long aux_1134;
		       aux_1134 = (i_1108 - ((long) 1));
		       aux_1114 = (int) (aux_1134);
		    }
		    {
		       long i_1137;
		       i_1137 = (long) (aux_1114);
		       i_1108 = i_1137;
		       goto loop_1109;
		    }
		 }
	      }
	 }
      }
   }
}


/* globalize-walk! */ obj_t 
globalize_walk__63_globalize_walk(obj_t globals_1, obj_t remove_2)
{
   {
      obj_t list1437_694;
      {
	 obj_t arg1440_696;
	 {
	    obj_t arg1443_698;
	    {
	       obj_t aux_1139;
	       aux_1139 = BCHAR(((unsigned char) '\n'));
	       arg1443_698 = MAKE_PAIR(aux_1139, BNIL);
	    }
	    arg1440_696 = MAKE_PAIR(string1591_globalize_walk, arg1443_698);
	 }
	 list1437_694 = MAKE_PAIR(string1592_globalize_walk, arg1440_696);
      }
      verbose_tools_speek(BINT(((long) 1)), list1437_694);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1591_globalize_walk;
   {
      obj_t hooks_700;
      obj_t hnames_701;
      hooks_700 = BNIL;
      hnames_701 = BNIL;
    loop_702:
      if (NULLP(hooks_700))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1451_707;
	   {
	      obj_t fun1459_713;
	      fun1459_713 = CAR(hooks_700);
	      {
		 obj_t aux_1151;
		 aux_1151 = PROCEDURE_ENTRY(fun1459_713) (fun1459_713, BEOA);
		 test1451_707 = CBOOL(aux_1151);
	      }
	   }
	   if (test1451_707)
	     {
		{
		   obj_t hnames_1158;
		   obj_t hooks_1156;
		   hooks_1156 = CDR(hooks_700);
		   hnames_1158 = CDR(hnames_701);
		   hnames_701 = hnames_1158;
		   hooks_700 = hooks_1156;
		   goto loop_702;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1591_globalize_walk, string1593_globalize_walk, CAR(hnames_701));
	     }
	}
   }
   {
      obj_t l1435_714;
      l1435_714 = globals_1;
    lname1436_715:
      if (PAIRP(l1435_714))
	{
	   {
	      variable_t aux_1164;
	      {
		 obj_t aux_1165;
		 aux_1165 = CAR(l1435_714);
		 aux_1164 = (variable_t) (aux_1165);
	      }
	      escape_fun__53_globalize_escape(aux_1164);
	   }
	   {
	      obj_t l1435_1169;
	      l1435_1169 = CDR(l1435_714);
	      l1435_714 = l1435_1169;
	      goto lname1436_715;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t globals_719;
      obj_t new_globals_42_720;
      globals_719 = globals_1;
      new_globals_42_720 = BNIL;
    loop_721:
      if (NULLP(globals_719))
	{
	   obj_t value_724;
	   {
	      obj_t arg1490_750;
	      {
		 obj_t arg1491_751;
		 arg1491_751 = foreign_closures_19_globalize_global_closure_246();
		 arg1490_750 = append_2_18___r4_pairs_and_lists_6_3(new_globals_42_720, arg1491_751);
	      }
	      value_724 = remove_var_123_ast_remove(remove_2, arg1490_750);
	   }
	   {
	      bool_t test1466_725;
	      {
		 long n1_1091;
		 n1_1091 = (long) CINT(_nb_error_on_pass__70_tools_error);
		 test1466_725 = (n1_1091 > ((long) 0));
	      }
	      if (test1466_725)
		{
		   {
		      char *arg1469_728;
		      {
			 bool_t test1477_735;
			 {
			    bool_t test1478_736;
			    {
			       obj_t obj_1093;
			       obj_1093 = _nb_error_on_pass__70_tools_error;
			       test1478_736 = INTEGERP(obj_1093);
			    }
			    if (test1478_736)
			      {
				 test1477_735 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			      }
			    else
			      {
				 test1477_735 = ((bool_t) 0);
			      }
			 }
			 if (test1477_735)
			   {
			      arg1469_728 = "s";
			   }
			 else
			   {
			      arg1469_728 = "";
			   }
		      }
		      {
			 obj_t list1471_730;
			 {
			    obj_t arg1473_731;
			    {
			       obj_t arg1474_732;
			       {
				  obj_t arg1475_733;
				  arg1475_733 = MAKE_PAIR(string1594_globalize_walk, BNIL);
				  {
				     obj_t aux_1185;
				     aux_1185 = string_to_bstring(arg1469_728);
				     arg1474_732 = MAKE_PAIR(aux_1185, arg1475_733);
				  }
			       }
			       arg1473_731 = MAKE_PAIR(string1595_globalize_walk, arg1474_732);
			    }
			    list1471_730 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1473_731);
			 }
			 fprint___r4_output_6_10_3(current_error_port, list1471_730);
		      }
		   }
		   {
		      obj_t res1589_1095;
		      exit(((long) -1));
		      res1589_1095 = BINT(((long) -1));
		      return res1589_1095;
		   }
		}
	      else
		{
		   obj_t hooks_737;
		   obj_t hnames_738;
		   hooks_737 = BNIL;
		   hnames_738 = BNIL;
		 loop_739:
		   if (NULLP(hooks_737))
		     {
			return value_724;
		     }
		   else
		     {
			bool_t test1483_744;
			{
			   obj_t fun1489_749;
			   fun1489_749 = CAR(hooks_737);
			   {
			      obj_t aux_1196;
			      aux_1196 = PROCEDURE_ENTRY(fun1489_749) (fun1489_749, BEOA);
			      test1483_744 = CBOOL(aux_1196);
			   }
			}
			if (test1483_744)
			  {
			     {
				obj_t hnames_1203;
				obj_t hooks_1201;
				hooks_1201 = CDR(hooks_737);
				hnames_1203 = CDR(hnames_738);
				hnames_738 = hnames_1203;
				hooks_737 = hooks_1201;
				goto loop_739;
			     }
			  }
			else
			  {
			     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1596_globalize_walk, CAR(hnames_738));
			  }
		     }
		}
	   }
	}
      else
	{
	   obj_t arg1494_752;
	   obj_t arg1496_753;
	   arg1494_752 = CDR(globals_719);
	   {
	      obj_t arg1497_754;
	      {
		 global_t aux_1208;
		 {
		    obj_t aux_1209;
		    aux_1209 = CAR(globals_719);
		    aux_1208 = (global_t) (aux_1209);
		 }
		 arg1497_754 = globalize__167_globalize_globalize(aux_1208);
	      }
	      arg1496_753 = append_2_18___r4_pairs_and_lists_6_3(arg1497_754, new_globals_42_720);
	   }
	   {
	      obj_t new_globals_42_1215;
	      obj_t globals_1214;
	      globals_1214 = arg1494_752;
	      new_globals_42_1215 = arg1496_753;
	      new_globals_42_720 = new_globals_42_1215;
	      globals_719 = globals_1214;
	      goto loop_721;
	   }
	}
   }
}


/* _globalize-walk!1590 */ obj_t 
_globalize_walk_1590_124_globalize_walk(obj_t env_1104, obj_t globals_1105, obj_t remove_1106)
{
   return globalize_walk__63_globalize_walk(globals_1105, remove_1106);
}


/* method-init */ obj_t 
method_init_76_globalize_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_walk()
{
   module_initialization_70_tools_speek(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_tools_error(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_engine_pass(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_globalize_escape(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_globalize_globalize(((long) 0), "GLOBALIZE_WALK");
   module_initialization_70_globalize_global_closure_246(((long) 0), "GLOBALIZE_WALK");
   return module_initialization_70_ast_remove(((long) 0), "GLOBALIZE_WALK");
}
