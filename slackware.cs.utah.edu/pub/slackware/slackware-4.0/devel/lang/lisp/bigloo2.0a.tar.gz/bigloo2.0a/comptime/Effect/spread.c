/*===========================================================================*/
/*   (Effect/spread.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_effect_spread();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
static bool_t spread_side_effect___103_effect_spread(obj_t);
extern obj_t module_initialization_70_effect_spread(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern bool_t spread_side_effect__136_effect_spread(node_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_effect_spread();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_effect_spread();
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_effect_spread();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
static obj_t _spread_side_effect__default1461_166_effect_spread(obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static bool_t spread_side_effect__default1461_164_effect_spread(node_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t _spread_side_effect_1666_154_effect_spread(obj_t, obj_t);
static obj_t require_initialization_114_effect_spread = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_effect_spread();
static obj_t __cnst[1];

DEFINE_STATIC_PROCEDURE(spread_side_effect__default1461_env_208_effect_spread, _spread_side_effect__default1461_166_effect_spread1674, _spread_side_effect__default1461_166_effect_spread, 0L, 1);
DEFINE_EXPORT_GENERIC(spread_side_effect__env_137_effect_spread, _spread_side_effect_1666_154_effect_spread1675, _spread_side_effect_1666_154_effect_spread, 0L, 1);
DEFINE_STRING(string1667_effect_spread, string1667_effect_spread1676, "READ ", 5);


/* module-initialization */ obj_t 
module_initialization_70_effect_spread(long checksum_1285, char *from_1286)
{
   if (CBOOL(require_initialization_114_effect_spread))
     {
	require_initialization_114_effect_spread = BBOOL(((bool_t) 0));
	library_modules_init_112_effect_spread();
	cnst_init_137_effect_spread();
	imported_modules_init_94_effect_spread();
	method_init_76_effect_spread();
	toplevel_init_63_effect_spread();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_effect_spread()
{
   module_initialization_70___object(((long) 0), "EFFECT_SPREAD");
   module_initialization_70___reader(((long) 0), "EFFECT_SPREAD");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_effect_spread()
{
   {
      obj_t cnst_port_138_1277;
      cnst_port_138_1277 = open_input_string(string1667_effect_spread);
      {
	 long i_1278;
	 i_1278 = ((long) 0);
       loop_1279:
	 {
	    bool_t test1668_1280;
	    test1668_1280 = (i_1278 == ((long) -1));
	    if (test1668_1280)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1669_1281;
		    {
		       obj_t list1670_1282;
		       {
			  obj_t arg1672_1283;
			  arg1672_1283 = BNIL;
			  list1670_1282 = MAKE_PAIR(cnst_port_138_1277, arg1672_1283);
		       }
		       arg1669_1281 = read___reader(list1670_1282);
		    }
		    CNST_TABLE_SET(i_1278, arg1669_1281);
		 }
		 {
		    int aux_1284;
		    {
		       long aux_1303;
		       aux_1303 = (i_1278 - ((long) 1));
		       aux_1284 = (int) (aux_1303);
		    }
		    {
		       long i_1306;
		       i_1306 = (long) (aux_1284);
		       i_1278 = i_1306;
		       goto loop_1279;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_effect_spread()
{
   return BUNSPEC;
}


/* spread-side-effect*! */ bool_t 
spread_side_effect___103_effect_spread(obj_t node__221_21)
{
   {
      obj_t node__221_713;
      bool_t res_714;
      node__221_713 = node__221_21;
      res_714 = ((bool_t) 0);
    loop_715:
      if (NULLP(node__221_713))
	{
	   return res_714;
	}
      else
	{
	   obj_t arg1483_717;
	   bool_t arg1484_718;
	   arg1483_717 = CDR(node__221_713);
	   {
	      bool_t _ortest_1459_719;
	      {
		 node_t aux_1311;
		 {
		    obj_t aux_1312;
		    aux_1312 = CAR(node__221_713);
		    aux_1311 = (node_t) (aux_1312);
		 }
		 _ortest_1459_719 = spread_side_effect__136_effect_spread(aux_1311);
	      }
	      if (_ortest_1459_719)
		{
		   arg1484_718 = _ortest_1459_719;
		}
	      else
		{
		   arg1484_718 = res_714;
		}
	   }
	   {
	      bool_t res_1318;
	      obj_t node__221_1317;
	      node__221_1317 = arg1483_717;
	      res_1318 = arg1484_718;
	      res_714 = res_1318;
	      node__221_713 = node__221_1317;
	      goto loop_715;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_effect_spread()
{
   add_generic__110___object(spread_side_effect__env_137_effect_spread, spread_side_effect__default1461_env_208_effect_spread);
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, var_ast_node, ((long) 0));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, sequence_ast_node, ((long) 1));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, app_ast_node, ((long) 2));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, app_ly_162_ast_node, ((long) 3));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, funcall_ast_node, ((long) 4));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, pragma_ast_node, ((long) 5));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, cast_ast_node, ((long) 6));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, setq_ast_node, ((long) 7));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, conditional_ast_node, ((long) 8));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, fail_ast_node, ((long) 9));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, select_ast_node, ((long) 10));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, let_fun_218_ast_node, ((long) 11));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, let_var_6_ast_node, ((long) 12));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, set_ex_it_116_ast_node, ((long) 13));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, jump_ex_it_184_ast_node, ((long) 14));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, make_box_202_ast_node, ((long) 15));
   add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, box_set__221_ast_node, ((long) 16));
   {
      long aux_1337;
      aux_1337 = add_inlined_method__244___object(spread_side_effect__env_137_effect_spread, box_ref_242_ast_node, ((long) 17));
      return BINT(aux_1337);
   }
}


/* spread-side-effect! */ bool_t 
spread_side_effect__136_effect_spread(node_t node_1)
{
   {
      obj_t method1577_1050;
      obj_t class1582_1051;
      {
	 obj_t arg1585_1048;
	 obj_t arg1586_1049;
	 {
	    object_t obj_1180;
	    obj_1180 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_1181;
	       pre_method_105_1181 = PROCEDURE_REF(spread_side_effect__env_137_effect_spread, ((long) 2));
	       if (INTEGERP(pre_method_105_1181))
		 {
		    PROCEDURE_SET(spread_side_effect__env_137_effect_spread, ((long) 2), BUNSPEC);
		    arg1585_1048 = pre_method_105_1181;
		 }
	       else
		 {
		    long obj_class_num_177_1186;
		    obj_class_num_177_1186 = TYPE(obj_1180);
		    {
		       obj_t arg1177_1187;
		       arg1177_1187 = PROCEDURE_REF(spread_side_effect__env_137_effect_spread, ((long) 1));
		       {
			  long arg1178_1191;
			  {
			     long arg1179_1192;
			     arg1179_1192 = OBJECT_TYPE;
			     arg1178_1191 = (obj_class_num_177_1186 - arg1179_1192);
			  }
			  arg1585_1048 = VECTOR_REF(arg1177_1187, arg1178_1191);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1197;
	    object_1197 = (object_t) (node_1);
	    {
	       long arg1180_1198;
	       {
		  long arg1181_1199;
		  long arg1182_1200;
		  arg1181_1199 = TYPE(object_1197);
		  arg1182_1200 = OBJECT_TYPE;
		  arg1180_1198 = (arg1181_1199 - arg1182_1200);
	       }
	       {
		  obj_t vector_1204;
		  vector_1204 = _classes__134___object;
		  arg1586_1049 = VECTOR_REF(vector_1204, arg1180_1198);
	       }
	    }
	 }
	 {
	    obj_t aux_1355;
	    method1577_1050 = arg1585_1048;
	    class1582_1051 = arg1586_1049;
	    {
	       if (INTEGERP(method1577_1050))
		 {
		    switch ((long) CINT(method1577_1050))
		      {
		      case ((long) 0):
			 {
			    var_t node_1057;
			    node_1057 = (var_t) (node_1);
			    {
			       bool_t test_1359;
			       {
				  obj_t aux_1363;
				  obj_t aux_1360;
				  aux_1363 = CNST_TABLE_REF(((long) 0));
				  {
				     variable_t arg1594_1061;
				     arg1594_1061 = (((var_t) CREF(node_1057))->variable);
				     aux_1360 = (((variable_t) CREF(arg1594_1061))->access);
				  }
				  test_1359 = (aux_1360 == aux_1363);
			       }
			       if (test_1359)
				 {
				    aux_1355 = BFALSE;
				 }
			       else
				 {
				    aux_1355 = BTRUE;
				 }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    sequence_t node_1062;
			    node_1062 = (sequence_t) (node_1);
			    {
			       bool_t res_1063;
			       res_1063 = spread_side_effect___103_effect_spread((((sequence_t) CREF(node_1062))->nodes));
			       {
				  obj_t val1237_1212;
				  val1237_1212 = BBOOL(res_1063);
				  ((((sequence_t) CREF(node_1062))->side_effect__165) = ((obj_t) val1237_1212), BUNSPEC);
			       }
			       aux_1355 = BBOOL(res_1063);
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    app_t node_1065;
			    node_1065 = (app_t) (node_1);
			    {
			       obj_t res_1067;
			       {
				  bool_t _ortest_1436_1068;
				  _ortest_1436_1068 = spread_side_effect___103_effect_spread((((app_t) CREF(node_1065))->args));
				  if (_ortest_1436_1068)
				    {
				       res_1067 = BBOOL(_ortest_1436_1068);
				    }
				  else
				    {
				       fun_t obj_1217;
				       {
					  value_t aux_1377;
					  {
					     variable_t arg1600_1070;
					     {
						var_t arg1602_1071;
						arg1602_1071 = (((app_t) CREF(node_1065))->fun);
						arg1600_1070 = (((var_t) CREF(arg1602_1071))->variable);
					     }
					     aux_1377 = (((variable_t) CREF(arg1600_1070))->value);
					  }
					  obj_1217 = (fun_t) (aux_1377);
				       }
				       res_1067 = (((fun_t) CREF(obj_1217))->side_effect__165);
				    }
			       }
			       ((((app_t) CREF(node_1065))->side_effect__165) = ((obj_t) res_1067), BUNSPEC);
			       aux_1355 = res_1067;
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    app_ly_162_t node_1073;
			    node_1073 = (app_ly_162_t) (node_1);
			    spread_side_effect__136_effect_spread((((app_ly_162_t) CREF(node_1073))->fun));
			    spread_side_effect__136_effect_spread((((app_ly_162_t) CREF(node_1073))->arg));
			    aux_1355 = BTRUE;
			 }
			 break;
		      case ((long) 4):
			 {
			    funcall_t node_1077;
			    node_1077 = (funcall_t) (node_1);
			    spread_side_effect__136_effect_spread((((funcall_t) CREF(node_1077))->fun));
			    spread_side_effect___103_effect_spread((((funcall_t) CREF(node_1077))->args));
			    aux_1355 = BTRUE;
			 }
			 break;
		      case ((long) 5):
			 {
			    pragma_t node_1081;
			    node_1081 = (pragma_t) (node_1);
			    {
			       obj_t res_1083;
			       {
				  bool_t _ortest_1440_1084;
				  _ortest_1440_1084 = spread_side_effect___103_effect_spread((((pragma_t) CREF(node_1081))->args));
				  if (_ortest_1440_1084)
				    {
				       res_1083 = BBOOL(_ortest_1440_1084);
				    }
				  else
				    {
				       res_1083 = (((pragma_t) CREF(node_1081))->side_effect__165);
				    }
			       }
			       ((((pragma_t) CREF(node_1081))->side_effect__165) = ((obj_t) res_1083), BUNSPEC);
			       aux_1355 = res_1083;
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    cast_t node_1086;
			    node_1086 = (cast_t) (node_1);
			    {
			       bool_t aux_1402;
			       aux_1402 = spread_side_effect__136_effect_spread((((cast_t) CREF(node_1086))->arg));
			       aux_1355 = BBOOL(aux_1402);
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    setq_t node_1089;
			    node_1089 = (setq_t) (node_1);
			    spread_side_effect__136_effect_spread((((setq_t) CREF(node_1089))->value));
			    aux_1355 = BTRUE;
			 }
			 break;
		      case ((long) 8):
			 {
			    conditional_t node_1092;
			    node_1092 = (conditional_t) (node_1);
			    {
			       bool_t res_test_153_1094;
			       res_test_153_1094 = spread_side_effect__136_effect_spread((((conditional_t) CREF(node_1092))->test));
			       {
				  bool_t res_true_149_1095;
				  res_true_149_1095 = spread_side_effect__136_effect_spread((((conditional_t) CREF(node_1092))->true));
				  {
				     bool_t res_false_133_1096;
				     res_false_133_1096 = spread_side_effect__136_effect_spread((((conditional_t) CREF(node_1092))->false));
				     {
					bool_t res_1097;
					if (res_test_153_1094)
					  {
					     res_1097 = res_test_153_1094;
					  }
					else
					  {
					     if (res_true_149_1095)
					       {
						  res_1097 = res_true_149_1095;
					       }
					     else
					       {
						  res_1097 = res_false_133_1096;
					       }
					  }
					{
					   {
					      obj_t val1319_1234;
					      val1319_1234 = BBOOL(res_1097);
					      ((((conditional_t) CREF(node_1092))->side_effect__165) = ((obj_t) val1319_1234), BUNSPEC);
					   }
					   aux_1355 = BBOOL(res_1097);
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 9):
			 {
			    fail_t node_1103;
			    node_1103 = (fail_t) (node_1);
			    {
			       bool_t res_proc_202_1105;
			       res_proc_202_1105 = spread_side_effect__136_effect_spread((((fail_t) CREF(node_1103))->proc));
			       {
				  bool_t res_msg_53_1106;
				  res_msg_53_1106 = spread_side_effect__136_effect_spread((((fail_t) CREF(node_1103))->msg));
				  {
				     bool_t res_obj_160_1107;
				     res_obj_160_1107 = spread_side_effect__136_effect_spread((((fail_t) CREF(node_1103))->obj));
				     {
					aux_1355 = BTRUE;
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    select_t node_1111;
			    node_1111 = (select_t) (node_1);
			    {
			       obj_t clauses_1113;
			       bool_t res_1114;
			       {
				  obj_t arg1622_1116;
				  bool_t arg1623_1117;
				  arg1622_1116 = (((select_t) CREF(node_1111))->clauses);
				  arg1623_1117 = spread_side_effect__136_effect_spread((((select_t) CREF(node_1111))->test));
				  {
				     bool_t aux_1432;
				     clauses_1113 = arg1622_1116;
				     res_1114 = arg1623_1117;
				   loop_1115:
				     if (NULLP(clauses_1113))
				       {
					  {
					     obj_t val1347_1242;
					     val1347_1242 = BBOOL(res_1114);
					     ((((select_t) CREF(node_1111))->side_effect__165) = ((obj_t) val1347_1242), BUNSPEC);
					  }
					  aux_1432 = res_1114;
				       }
				     else
				       {
					  obj_t arg1627_1120;
					  bool_t arg1628_1121;
					  arg1627_1120 = CDR(clauses_1113);
					  {
					     bool_t _ortest_1448_1122;
					     {
						node_t aux_1438;
						{
						   obj_t aux_1439;
						   {
						      obj_t aux_1440;
						      aux_1440 = CAR(clauses_1113);
						      aux_1439 = CDR(aux_1440);
						   }
						   aux_1438 = (node_t) (aux_1439);
						}
						_ortest_1448_1122 = spread_side_effect__136_effect_spread(aux_1438);
					     }
					     if (_ortest_1448_1122)
					       {
						  arg1628_1121 = _ortest_1448_1122;
					       }
					     else
					       {
						  arg1628_1121 = res_1114;
					       }
					  }
					  {
					     bool_t res_1447;
					     obj_t clauses_1446;
					     clauses_1446 = arg1627_1120;
					     res_1447 = arg1628_1121;
					     res_1114 = res_1447;
					     clauses_1113 = clauses_1446;
					     goto loop_1115;
					  }
				       }
				     aux_1355 = BBOOL(aux_1432);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    let_fun_218_t node_1125;
			    node_1125 = (let_fun_218_t) (node_1);
			    {
			       obj_t l1450_1127;
			       l1450_1127 = (((let_fun_218_t) CREF(node_1125))->locals);
			     lname1451_1128:
			       if (PAIRP(l1450_1127))
				 {
				    {
				       node_t aux_1452;
				       {
					  obj_t aux_1453;
					  {
					     sfun_t obj_1250;
					     {
						value_t aux_1454;
						{
						   local_t obj_1249;
						   {
						      obj_t aux_1455;
						      aux_1455 = CAR(l1450_1127);
						      obj_1249 = (local_t) (aux_1455);
						   }
						   aux_1454 = (((local_t) CREF(obj_1249))->value);
						}
						obj_1250 = (sfun_t) (aux_1454);
					     }
					     aux_1453 = (((sfun_t) CREF(obj_1250))->body);
					  }
					  aux_1452 = (node_t) (aux_1453);
				       }
				       spread_side_effect__136_effect_spread(aux_1452);
				    }
				    {
				       obj_t l1450_1463;
				       l1450_1463 = CDR(l1450_1127);
				       l1450_1127 = l1450_1463;
				       goto lname1451_1128;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       bool_t res_1135;
			       res_1135 = spread_side_effect__136_effect_spread((((let_fun_218_t) CREF(node_1125))->body));
			       {
				  obj_t val1360_1254;
				  val1360_1254 = BBOOL(res_1135);
				  ((((let_fun_218_t) CREF(node_1125))->side_effect__165) = ((obj_t) val1360_1254), BUNSPEC);
			       }
			       aux_1355 = BBOOL(res_1135);
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    let_var_6_t node_1137;
			    node_1137 = (let_var_6_t) (node_1);
			    {
			       obj_t bdgs_1139;
			       bool_t res_1140;
			       {
				  obj_t arg1641_1142;
				  bool_t arg1645_1143;
				  arg1641_1142 = (((let_var_6_t) CREF(node_1137))->bindings);
				  arg1645_1143 = spread_side_effect__136_effect_spread((((let_var_6_t) CREF(node_1137))->body));
				  {
				     bool_t aux_1475;
				     bdgs_1139 = arg1641_1142;
				     res_1140 = arg1645_1143;
				   loop_1141:
				     if (NULLP(bdgs_1139))
				       {
					  {
					     obj_t val1375_1259;
					     val1375_1259 = BBOOL(res_1140);
					     ((((let_var_6_t) CREF(node_1137))->side_effect__165) = ((obj_t) val1375_1259), BUNSPEC);
					  }
					  aux_1475 = res_1140;
				       }
				     else
				       {
					  obj_t arg1648_1146;
					  bool_t arg1649_1147;
					  arg1648_1146 = CDR(bdgs_1139);
					  {
					     bool_t _ortest_1453_1148;
					     {
						node_t aux_1481;
						{
						   obj_t aux_1482;
						   {
						      obj_t aux_1483;
						      aux_1483 = CAR(bdgs_1139);
						      aux_1482 = CDR(aux_1483);
						   }
						   aux_1481 = (node_t) (aux_1482);
						}
						_ortest_1453_1148 = spread_side_effect__136_effect_spread(aux_1481);
					     }
					     if (_ortest_1453_1148)
					       {
						  arg1649_1147 = _ortest_1453_1148;
					       }
					     else
					       {
						  arg1649_1147 = res_1140;
					       }
					  }
					  {
					     bool_t res_1490;
					     obj_t bdgs_1489;
					     bdgs_1489 = arg1648_1146;
					     res_1490 = arg1649_1147;
					     res_1140 = res_1490;
					     bdgs_1139 = bdgs_1489;
					     goto loop_1141;
					  }
				       }
				     aux_1355 = BBOOL(aux_1475);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 13):
			 {
			    set_ex_it_116_t node_1151;
			    node_1151 = (set_ex_it_116_t) (node_1);
			    {
			       bool_t aux_1493;
			       aux_1493 = spread_side_effect__136_effect_spread((((set_ex_it_116_t) CREF(node_1151))->body));
			       aux_1355 = BBOOL(aux_1493);
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    jump_ex_it_184_t node_1154;
			    node_1154 = (jump_ex_it_184_t) (node_1);
			    spread_side_effect__136_effect_spread((((jump_ex_it_184_t) CREF(node_1154))->exit));
			    spread_side_effect__136_effect_spread((((jump_ex_it_184_t) CREF(node_1154))->value));
			    aux_1355 = BTRUE;
			 }
			 break;
		      case ((long) 15):
			 {
			    make_box_202_t node_1158;
			    node_1158 = (make_box_202_t) (node_1);
			    {
			       bool_t res_1160;
			       res_1160 = spread_side_effect__136_effect_spread((((make_box_202_t) CREF(node_1158))->value));
			       {
				  obj_t val1409_1268;
				  val1409_1268 = BBOOL(res_1160);
				  ((((make_box_202_t) CREF(node_1158))->side_effect__165) = ((obj_t) val1409_1268), BUNSPEC);
			       }
			       aux_1355 = BBOOL(res_1160);
			    }
			 }
			 break;
		      case ((long) 16):
			 {
			    box_set__221_t node_1162;
			    node_1162 = (box_set__221_t) (node_1);
			    spread_side_effect__136_effect_spread((((box_set__221_t) CREF(node_1162))->value));
			    aux_1355 = BTRUE;
			 }
			 break;
		      case ((long) 17):
			 {
			    box_ref_242_t node_1165;
			    node_1165 = (box_ref_242_t) (node_1);
			    {
			       bool_t aux_1512;
			       {
				  node_t aux_1513;
				  {
				     var_t aux_1514;
				     aux_1514 = (((box_ref_242_t) CREF(node_1165))->var);
				     aux_1513 = (node_t) (aux_1514);
				  }
				  aux_1512 = spread_side_effect__136_effect_spread(aux_1513);
			       }
			       aux_1355 = BBOOL(aux_1512);
			    }
			 }
			 break;
		      default:
		       case_else1583_1054:
			 if (PROCEDUREP(method1577_1050))
			   {
			      aux_1355 = PROCEDURE_ENTRY(method1577_1050) (method1577_1050, (obj_t) (node_1), BEOA);
			   }
			 else
			   {
			      obj_t fun1576_1046;
			      fun1576_1046 = PROCEDURE_REF(spread_side_effect__env_137_effect_spread, ((long) 0));
			      aux_1355 = PROCEDURE_ENTRY(fun1576_1046) (fun1576_1046, (obj_t) (node_1), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1583_1054;
		 }
	    }
	    return CBOOL(aux_1355);
	 }
      }
   }
}


/* _spread-side-effect!1666 */ obj_t 
_spread_side_effect_1666_154_effect_spread(obj_t env_1273, obj_t node_1274)
{
   {
      bool_t aux_1531;
      aux_1531 = spread_side_effect__136_effect_spread((node_t) (node_1274));
      return BBOOL(aux_1531);
   }
}


/* spread-side-effect!-default1461 */ bool_t 
spread_side_effect__default1461_164_effect_spread(node_t node_2)
{
   return ((bool_t) 0);
}


/* _spread-side-effect!-default1461 */ obj_t 
_spread_side_effect__default1461_166_effect_spread(obj_t env_1275, obj_t node_1276)
{
   {
      bool_t aux_1535;
      aux_1535 = spread_side_effect__default1461_164_effect_spread((node_t) (node_1276));
      return BBOOL(aux_1535);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_effect_spread()
{
   module_initialization_70_type_type(((long) 0), "EFFECT_SPREAD");
   module_initialization_70_ast_var(((long) 0), "EFFECT_SPREAD");
   return module_initialization_70_ast_node(((long) 0), "EFFECT_SPREAD");
}
