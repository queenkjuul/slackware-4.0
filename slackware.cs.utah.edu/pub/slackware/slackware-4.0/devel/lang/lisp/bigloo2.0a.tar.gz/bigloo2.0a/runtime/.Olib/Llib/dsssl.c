/*===========================================================================*/
/*   (Llib/dsssl.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_keyword(char *);
extern obj_t string_to_symbol(char *);
extern obj_t string_append(obj_t, obj_t);
extern obj_t dsssl_formals__scheme_formals_201___dsssl(obj_t, obj_t);
extern obj_t dsssl_check_key_args__153___dsssl(obj_t, obj_t);
static obj_t _dsssl_formals__scheme_formals1578_11___dsssl(obj_t, obj_t, obj_t);
static obj_t optional_state_215___dsssl(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _dsssl_check_key_args__61___dsssl(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t loop___dsssl(obj_t, obj_t, obj_t, bool_t);
static obj_t exit_rest_state_151___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t optional_state_1579_63___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___dsssl(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_substring(obj_t, long, long);
static obj_t id_sans_type_130___dsssl(obj_t);
static obj_t symbol2638___dsssl = BUNSPEC;
static obj_t symbol2637___dsssl = BUNSPEC;
static obj_t symbol2636___dsssl = BUNSPEC;
static obj_t symbol2625___dsssl = BUNSPEC;
static obj_t symbol2624___dsssl = BUNSPEC;
static obj_t symbol2617___dsssl = BUNSPEC;
static obj_t no_rest_key_state_212___dsssl(obj_t, obj_t, obj_t);
static obj_t symbol2615___dsssl = BUNSPEC;
static obj_t rest_key_state_46___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2609___dsssl = BUNSPEC;
static obj_t symbol2598___dsssl = BUNSPEC;
static obj_t symbol2608___dsssl = BUNSPEC;
static obj_t symbol2607___dsssl = BUNSPEC;
static obj_t rest_state_87___dsssl(obj_t, obj_t, obj_t);
static obj_t symbol2606___dsssl = BUNSPEC;
static obj_t symbol2605___dsssl = BUNSPEC;
static obj_t symbol2604___dsssl = BUNSPEC;
static obj_t symbol2593___dsssl = BUNSPEC;
static obj_t symbol2592___dsssl = BUNSPEC;
static obj_t symbol2591___dsssl = BUNSPEC;
static obj_t symbol2601___dsssl = BUNSPEC;
static obj_t symbol2590___dsssl = BUNSPEC;
static obj_t symbol2600___dsssl = BUNSPEC;
static obj_t symbol2586___dsssl = BUNSPEC;
static obj_t symbol2585___dsssl = BUNSPEC;
static obj_t symbol2582___dsssl = BUNSPEC;
static obj_t symbol2581___dsssl = BUNSPEC;
static obj_t symbol2577___dsssl = BUNSPEC;
static obj_t symbol2576___dsssl = BUNSPEC;
static obj_t symbol2575___dsssl = BUNSPEC;
static obj_t symbol2574___dsssl = BUNSPEC;
static obj_t symbol2573___dsssl = BUNSPEC;
static obj_t symbol2570___dsssl = BUNSPEC;
static obj_t symbol2568___dsssl = BUNSPEC;
static obj_t symbol2566___dsssl = BUNSPEC;
static obj_t symbol2565___dsssl = BUNSPEC;
static obj_t symbol2564___dsssl = BUNSPEC;
static obj_t symbol2561___dsssl = BUNSPEC;
static obj_t symbol2559___dsssl = BUNSPEC;
static obj_t symbol2557___dsssl = BUNSPEC;
static obj_t symbol2556___dsssl = BUNSPEC;
static obj_t symbol2555___dsssl = BUNSPEC;
static obj_t symbol2552___dsssl = BUNSPEC;
static obj_t _dsssl_get_key_arg1577_91___dsssl(obj_t, obj_t, obj_t, obj_t);
static obj_t one_key_arg_10___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t list2635___dsssl = BUNSPEC;
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t list2632___dsssl = BUNSPEC;
static obj_t list2630___dsssl = BUNSPEC;
static obj_t list2626___dsssl = BUNSPEC;
static obj_t _make_dsssl_function_prelude1576_158___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t list2611___dsssl = BUNSPEC;
static obj_t list2603___dsssl = BUNSPEC;
static obj_t list2589___dsssl = BUNSPEC;
static obj_t list2580___dsssl = BUNSPEC;
static obj_t list2572___dsssl = BUNSPEC;
static obj_t list2569___dsssl = BUNSPEC;
static obj_t list2567___dsssl = BUNSPEC;
static obj_t list2563___dsssl = BUNSPEC;
static obj_t list2554___dsssl = BUNSPEC;
extern obj_t dsssl_get_key_arg_157___dsssl(obj_t, obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t tag_141_241___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___dsssl();
extern obj_t make_dsssl_function_prelude_58___dsssl(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114___dsssl = BUNSPEC;
static obj_t key_state_193___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137___dsssl();
static obj_t symbol__keyword_174___dsssl(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( dsssl_check_key_args__env_216___dsssl, _dsssl_check_key_args__61___dsssl2640, _dsssl_check_key_args__61___dsssl, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( dsssl_get_key_arg_env_24___dsssl, _dsssl_get_key_arg1577_91___dsssl2641, _dsssl_get_key_arg1577_91___dsssl, 0L, 3 );
DEFINE_STRING( string2634___dsssl, string2634___dsssl2642, "and `.' notation", 16 );
DEFINE_STRING( string2633___dsssl, string2633___dsssl2643, "Can't use both DSSSL named constant", 35 );
DEFINE_STRING( string2631___dsssl, string2631___dsssl2644, "symbol expected", 15 );
DEFINE_STRING( string2629___dsssl, string2629___dsssl2645, "LOOP:Wrong number of arguments", 30 );
DEFINE_STRING( string2628___dsssl, string2628___dsssl2646, "symbol or named constant expected", 33 );
DEFINE_STRING( string2627___dsssl, string2627___dsssl2647, "Illegal formal parameter", 24 );
DEFINE_STRING( string2623___dsssl, string2623___dsssl2648, "BSTRING", 7 );
DEFINE_STRING( string2622___dsssl, string2622___dsssl2649, "Illegal index", 13 );
DEFINE_STRING( string2621___dsssl, string2621___dsssl2650, "substring", 9 );
DEFINE_STRING( string2619___dsssl, string2619___dsssl2651, "index out of range", 18 );
DEFINE_STRING( string2620___dsssl, string2620___dsssl2652, "UCHAR", 5 );
DEFINE_STRING( string2618___dsssl, string2618___dsssl2653, "string-ref", 10 );
DEFINE_STRING( string2616___dsssl, string2616___dsssl2654, "KEYWORD", 7 );
DEFINE_STRING( string2614___dsssl, string2614___dsssl2655, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_STRING( string2613___dsssl, string2613___dsssl2656, "Illegal #!keys parameters", 25 );
DEFINE_STRING( string2612___dsssl, string2612___dsssl2657, "dsssl formal parsing", 20 );
DEFINE_STRING( string2599___dsssl, string2599___dsssl2658, "REST-STATE:Wrong number of arguments", 36 );
DEFINE_STRING( string2610___dsssl, string2610___dsssl2659, "Illegal Dsssl formal list (#!optional)", 38 );
DEFINE_STRING( string2597___dsssl, string2597___dsssl2660, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2596___dsssl, string2596___dsssl2661, "argument not a list", 19 );
DEFINE_STRING( string2595___dsssl, string2595___dsssl2662, "map", 3 );
DEFINE_STRING( string2594___dsssl, string2594___dsssl2663, "NO-REST-KEY-STATE:Wrong number of arguments", 43 );
DEFINE_STRING( string2602___dsssl, string2602___dsssl2664, "OPTIONAL-STATE_1579:Wrong number of arguments", 45 );
DEFINE_STRING( string2588___dsssl, string2588___dsssl2665, "EXIT-REST-STATE:Wrong number of arguments", 41 );
DEFINE_STRING( string2587___dsssl, string2587___dsssl2666, "Illegal Dsssl formal list (#!rest)", 34 );
DEFINE_STRING( string2584___dsssl, string2584___dsssl2667, ":", 1 );
DEFINE_STRING( string2583___dsssl, string2583___dsssl2668, "SYMBOL", 6 );
DEFINE_STRING( string2579___dsssl, string2579___dsssl2669, "KEY-STATE:Wrong number of arguments", 35 );
DEFINE_STRING( string2578___dsssl, string2578___dsssl2670, "Illegal Dsssl formal list (#!key)", 33 );
DEFINE_STRING( string2571___dsssl, string2571___dsssl2671, "Illegal formal list", 19 );
DEFINE_STRING( string2562___dsssl, string2562___dsssl2672, "PROCEDURE", 9 );
DEFINE_STRING( string2560___dsssl, string2560___dsssl2673, "PAIR", 4 );
DEFINE_STRING( string2558___dsssl, string2558___dsssl2674, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/dsssl.scm", 58 );
DEFINE_STRING( string2553___dsssl, string2553___dsssl2675, "MAKE-DSSSL-FUNCTION-PRELUDE:Wrong number of arguments", 53 );
DEFINE_EXPORT_PROCEDURE( make_dsssl_function_prelude_env_81___dsssl, _make_dsssl_function_prelude1576_158___dsssl2676, _make_dsssl_function_prelude1576_158___dsssl, 0L, 4 );
DEFINE_EXPORT_PROCEDURE( dsssl_formals__scheme_formals_env_148___dsssl, _dsssl_formals__scheme_formals1578_11___dsssl2677, _dsssl_formals__scheme_formals1578_11___dsssl, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___dsssl(long checksum_2144, char * from_2145)
{
if(CBOOL(require_initialization_114___dsssl)){
require_initialization_114___dsssl = BBOOL(((bool_t)0));
cnst_init_137___dsssl();
imported_modules_init_94___dsssl();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___dsssl()
{
symbol2552___dsssl = string_to_symbol("MAKE-DSSSL-FUNCTION-PRELUDE");
symbol2555___dsssl = string_to_symbol("FUNCALL");
symbol2556___dsssl = string_to_symbol("next-state");
symbol2557___dsssl = string_to_symbol("args");
{
obj_t aux_2155;
{
obj_t aux_2156;
{
obj_t aux_2157;
{
obj_t aux_2158;
aux_2158 = MAKE_PAIR(BUNSPEC, BNIL);
aux_2157 = MAKE_PAIR(symbol2557___dsssl, aux_2158);
}
aux_2156 = MAKE_PAIR(symbol2556___dsssl, aux_2157);
}
aux_2155 = MAKE_PAIR(symbol2556___dsssl, aux_2156);
}
list2554___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2155);
}
symbol2559___dsssl = string_to_symbol("_");
symbol2561___dsssl = string_to_symbol("DSSSL");
symbol2564___dsssl = string_to_symbol("gensym");
symbol2565___dsssl = string_to_symbol("arg1300");
{
obj_t aux_2168;
{
obj_t aux_2169;
{
obj_t aux_2170;
aux_2170 = MAKE_PAIR(symbol2565___dsssl, BNIL);
aux_2169 = MAKE_PAIR(symbol2564___dsssl, aux_2170);
}
aux_2168 = MAKE_PAIR(symbol2564___dsssl, aux_2169);
}
list2563___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2168);
}
symbol2566___dsssl = string_to_symbol("LET");
symbol2568___dsssl = string_to_symbol("dsssl-arg");
{
obj_t aux_2177;
{
obj_t aux_2178;
{
obj_t aux_2179;
{
obj_t aux_2180;
aux_2180 = MAKE_PAIR(symbol2568___dsssl, BNIL);
aux_2179 = MAKE_PAIR(symbol2557___dsssl, aux_2180);
}
aux_2178 = MAKE_PAIR(symbol2556___dsssl, aux_2179);
}
aux_2177 = MAKE_PAIR(symbol2556___dsssl, aux_2178);
}
list2567___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2177);
}
symbol2570___dsssl = string_to_symbol("arg1323");
{
obj_t aux_2187;
{
obj_t aux_2188;
{
obj_t aux_2189;
aux_2189 = MAKE_PAIR(symbol2570___dsssl, BNIL);
aux_2188 = MAKE_PAIR(symbol2564___dsssl, aux_2189);
}
aux_2187 = MAKE_PAIR(symbol2564___dsssl, aux_2188);
}
list2569___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2187);
}
symbol2573___dsssl = string_to_symbol("err");
symbol2574___dsssl = string_to_symbol("where");
symbol2575___dsssl = string_to_symbol("formals");
{
obj_t aux_2197;
{
obj_t aux_2198;
{
obj_t aux_2199;
{
obj_t aux_2200;
{
obj_t aux_2201;
aux_2201 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2200 = MAKE_PAIR(string2571___dsssl, aux_2201);
}
aux_2199 = MAKE_PAIR(symbol2574___dsssl, aux_2200);
}
aux_2198 = MAKE_PAIR(symbol2573___dsssl, aux_2199);
}
aux_2197 = MAKE_PAIR(symbol2573___dsssl, aux_2198);
}
list2572___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2197);
}
symbol2576___dsssl = string_to_symbol("_MAKE-DSSSL-FUNCTION-PRELUDE1576");
symbol2577___dsssl = string_to_symbol("KEY-STATE");
{
obj_t aux_2210;
{
obj_t aux_2211;
{
obj_t aux_2212;
{
obj_t aux_2213;
{
obj_t aux_2214;
aux_2214 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2213 = MAKE_PAIR(string2578___dsssl, aux_2214);
}
aux_2212 = MAKE_PAIR(symbol2574___dsssl, aux_2213);
}
aux_2211 = MAKE_PAIR(symbol2573___dsssl, aux_2212);
}
aux_2210 = MAKE_PAIR(symbol2573___dsssl, aux_2211);
}
list2580___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2210);
}
symbol2581___dsssl = string_to_symbol("DSSSL-GET-KEY-ARG");
symbol2582___dsssl = string_to_symbol("ONE-KEY-ARG");
symbol2585___dsssl = string_to_symbol("TAG-141");
symbol2586___dsssl = string_to_symbol("EXIT-REST-STATE");
{
obj_t aux_2225;
{
obj_t aux_2226;
{
obj_t aux_2227;
{
obj_t aux_2228;
{
obj_t aux_2229;
aux_2229 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2228 = MAKE_PAIR(string2587___dsssl, aux_2229);
}
aux_2227 = MAKE_PAIR(symbol2574___dsssl, aux_2228);
}
aux_2226 = MAKE_PAIR(symbol2573___dsssl, aux_2227);
}
aux_2225 = MAKE_PAIR(symbol2573___dsssl, aux_2226);
}
list2589___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2225);
}
symbol2590___dsssl = string_to_symbol("BEGIN");
symbol2591___dsssl = string_to_symbol("DSSSL-CHECK-KEY-ARGS!");
symbol2592___dsssl = string_to_symbol("QUOTE");
symbol2593___dsssl = string_to_symbol("NO-REST-KEY-STATE");
symbol2598___dsssl = string_to_symbol("REST-STATE");
symbol2600___dsssl = string_to_symbol("TMP");
symbol2601___dsssl = string_to_symbol("OPTIONAL-STATE_1579");
symbol2604___dsssl = string_to_symbol("arg1263");
{
obj_t aux_2244;
{
obj_t aux_2245;
{
obj_t aux_2246;
aux_2246 = MAKE_PAIR(symbol2604___dsssl, BNIL);
aux_2245 = MAKE_PAIR(symbol2564___dsssl, aux_2246);
}
aux_2244 = MAKE_PAIR(symbol2564___dsssl, aux_2245);
}
list2603___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2244);
}
symbol2605___dsssl = string_to_symbol("IF");
symbol2606___dsssl = string_to_symbol("NULL?");
symbol2607___dsssl = string_to_symbol("CAR");
symbol2608___dsssl = string_to_symbol("SET!");
symbol2609___dsssl = string_to_symbol("CDR");
{
obj_t aux_2256;
{
obj_t aux_2257;
{
obj_t aux_2258;
{
obj_t aux_2259;
{
obj_t aux_2260;
aux_2260 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2259 = MAKE_PAIR(string2610___dsssl, aux_2260);
}
aux_2258 = MAKE_PAIR(symbol2574___dsssl, aux_2259);
}
aux_2257 = MAKE_PAIR(symbol2573___dsssl, aux_2258);
}
aux_2256 = MAKE_PAIR(symbol2573___dsssl, aux_2257);
}
list2611___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2256);
}
symbol2615___dsssl = string_to_symbol("_DSSSL-GET-KEY-ARG1577");
symbol2617___dsssl = string_to_symbol("ID-SANS-TYPE");
symbol2624___dsssl = string_to_symbol("DSSSL-FORMALS->SCHEME-FORMALS");
symbol2625___dsssl = string_to_symbol("LOOP");
{
obj_t aux_2271;
{
obj_t aux_2272;
aux_2272 = MAKE_PAIR(BCNST(262), BNIL);
aux_2271 = MAKE_PAIR(BCNST(259), aux_2272);
}
list2626___dsssl = MAKE_PAIR(BCNST(258), aux_2271);
}
{
obj_t aux_2276;
{
obj_t aux_2277;
{
obj_t aux_2278;
{
obj_t aux_2279;
{
obj_t aux_2280;
aux_2280 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2279 = MAKE_PAIR(string2628___dsssl, aux_2280);
}
aux_2278 = MAKE_PAIR(string2627___dsssl, aux_2279);
}
aux_2277 = MAKE_PAIR(symbol2573___dsssl, aux_2278);
}
aux_2276 = MAKE_PAIR(symbol2573___dsssl, aux_2277);
}
list2630___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2276);
}
{
obj_t aux_2287;
{
obj_t aux_2288;
{
obj_t aux_2289;
{
obj_t aux_2290;
{
obj_t aux_2291;
aux_2291 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2290 = MAKE_PAIR(string2631___dsssl, aux_2291);
}
aux_2289 = MAKE_PAIR(string2627___dsssl, aux_2290);
}
aux_2288 = MAKE_PAIR(symbol2573___dsssl, aux_2289);
}
aux_2287 = MAKE_PAIR(symbol2573___dsssl, aux_2288);
}
list2632___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2287);
}
{
obj_t aux_2298;
{
obj_t aux_2299;
{
obj_t aux_2300;
{
obj_t aux_2301;
{
obj_t aux_2302;
aux_2302 = MAKE_PAIR(symbol2575___dsssl, BNIL);
aux_2301 = MAKE_PAIR(string2634___dsssl, aux_2302);
}
aux_2300 = MAKE_PAIR(string2633___dsssl, aux_2301);
}
aux_2299 = MAKE_PAIR(symbol2573___dsssl, aux_2300);
}
aux_2298 = MAKE_PAIR(symbol2573___dsssl, aux_2299);
}
list2635___dsssl = MAKE_PAIR(symbol2555___dsssl, aux_2298);
}
symbol2636___dsssl = string_to_symbol("_DSSSL-FORMALS->SCHEME-FORMALS1578");
symbol2637___dsssl = string_to_symbol("SYMBOL->KEYWORD");
return (symbol2638___dsssl = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* make-dsssl-function-prelude */obj_t make_dsssl_function_prelude_58___dsssl(obj_t where_1, obj_t formals_2, obj_t body_3, obj_t err_4)
{
{
obj_t symbol1563_1148;
symbol1563_1148 = symbol2552___dsssl;
{
PUSH_TRACE(symbol1563_1148);
BUNSPEC;
{
obj_t aux1562_1149;
{
obj_t optional_state_215_1169;
obj_t rest_state_87_1168;
obj_t no_rest_key_state_212_1167;
optional_state_215_1169 = make_fx_procedure(optional_state_215___dsssl, ((long)2), ((long)5));
rest_state_87_1168 = make_fx_procedure(rest_state_87___dsssl, ((long)2), ((long)4));
no_rest_key_state_212_1167 = make_fx_procedure(no_rest_key_state_212___dsssl, ((long)2), ((long)4));
PROCEDURE_SET(optional_state_215_1169, ((long)0), err_4);
PROCEDURE_SET(optional_state_215_1169, ((long)1), where_1);
PROCEDURE_SET(optional_state_215_1169, ((long)2), formals_2);
PROCEDURE_SET(optional_state_215_1169, ((long)3), rest_state_87_1168);
PROCEDURE_SET(optional_state_215_1169, ((long)4), body_3);
PROCEDURE_SET(rest_state_87_1168, ((long)0), body_3);
PROCEDURE_SET(rest_state_87_1168, ((long)1), err_4);
PROCEDURE_SET(rest_state_87_1168, ((long)2), where_1);
PROCEDURE_SET(rest_state_87_1168, ((long)3), formals_2);
PROCEDURE_SET(no_rest_key_state_212_1167, ((long)0), err_4);
PROCEDURE_SET(no_rest_key_state_212_1167, ((long)1), where_1);
PROCEDURE_SET(no_rest_key_state_212_1167, ((long)2), formals_2);
PROCEDURE_SET(no_rest_key_state_212_1167, ((long)3), body_3);
{
obj_t args_588;
obj_t args_524;
obj_t next_state_161_525;
args_588 = formals_2;
scheme_state_248_605:
{
bool_t test1330_590;
test1330_590 = PAIRP(args_588);
if(test1330_590){
bool_t test1331_591;
{
bool_t test1340_601;
{
obj_t arg1343_604;
{
obj_t pair_960;
if(test1330_590){
pair_960 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)2860)));
exit( -1 );}
arg1343_604 = CAR(pair_960);
}
test1340_601 = SYMBOLP(arg1343_604);
}
if(test1340_601){
test1331_591 = ((bool_t)0);
}
 else {
bool_t test1341_602;
{
obj_t arg1342_603;
{
obj_t pair_962;
if(test1330_590){
pair_962 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)2885)));
exit( -1 );}
arg1342_603 = CAR(pair_962);
}
test1341_602 = PAIRP(arg1342_603);
}
if(test1341_602){
test1331_591 = ((bool_t)0);
}
 else {
test1331_591 = ((bool_t)1);
}
}
}
if(test1331_591){
{
long aux1004_593;
{
obj_t aux1002_598;
{
obj_t pair_964;
if(test1330_590){
pair_964 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)2963)));
exit( -1 );}
aux1002_598 = CAR(pair_964);
}
if(CNSTP(aux1002_598)){
aux1004_593 = CCNST(aux1002_598);
}
 else {
aux1004_593 = ((long)-1);
}
}
switch (aux1004_593){
case ((long)258) : 
{
obj_t arg1333_595;
{
obj_t pair_966;
if(test1330_590){
pair_966 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)3020)));
exit( -1 );}
arg1333_595 = CDR(pair_966);
}
args_524 = arg1333_595;
next_state_161_525 = optional_state_215_1169;
enter_dsssl_state_31_606:
{
obj_t as_527;
as_527 = args_524;
loop_528:
if(NULLP(as_527)){
{
bool_t test1586_1245;
test1586_1245 = PROCEDURE_CORRECT_ARITYP(next_state_161_525, ((long)2));
if(test1586_1245){
aux1562_1149 = PROCEDURE_ENTRY(next_state_161_525)(next_state_161_525, args_524, BUNSPEC, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2554___dsssl, next_state_161_525, string2558___dsssl, BINT(((long)3440)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
 else {
bool_t test1266_530;
test1266_530 = PAIRP(as_527);
if(test1266_530){
bool_t test1267_531;
{
bool_t test1324_584;
{
obj_t arg1328_587;
{
obj_t pair_941;
if(test1266_530){
pair_941 = as_527;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, as_527, string2558___dsssl, BINT(((long)3570)));
exit( -1 );}
arg1328_587 = CAR(pair_941);
}
test1324_584 = SYMBOLP(arg1328_587);
}
if(test1324_584){
test1267_531 = ((bool_t)0);
}
 else {
bool_t test1325_585;
{
obj_t arg1326_586;
{
obj_t pair_943;
if(test1266_530){
pair_943 = as_527;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, as_527, string2558___dsssl, BINT(((long)3593)));
exit( -1 );}
arg1326_586 = CAR(pair_943);
}
test1325_585 = PAIRP(arg1326_586);
}
if(test1325_585){
test1267_531 = ((bool_t)0);
}
 else {
test1267_531 = ((bool_t)1);
}
}
}
if(test1267_531){
{
obj_t arg1268_532;
{
obj_t pair_945;
if(test1266_530){
pair_945 = as_527;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, as_527, string2558___dsssl, BINT(((long)3617)));
exit( -1 );}
arg1268_532 = CDR(pair_945);
}
{
obj_t as_2390;
as_2390 = arg1268_532;
as_527 = as_2390;
goto loop_528;
}
}
}
 else {
{
{
obj_t e_103_175_535;
{
obj_t pair_946;
if(test1266_530){
pair_946 = as_527;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, as_527, string2558___dsssl, BINT(((long)3657)));
exit( -1 );}
e_103_175_535 = CAR(pair_946);
}
if(SYMBOLP(e_103_175_535)){
{
obj_t dsssl_arg_196_545;
{
obj_t arg1300_563;
arg1300_563 = symbol2561___dsssl;
{
obj_t fun_1270;
{
obj_t aux1610_1264;
aux1610_1264 = gensym___r4_symbols_6_4;
if(PROCEDUREP(aux1610_1264)){
fun_1270 = aux1610_1264;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2562___dsssl, aux1610_1264, string2558___dsssl, BINT(((long)3700)));
exit( -1 );}
}
{
bool_t test1625_1277;
test1625_1277 = PROCEDURE_CORRECT_ARITYP(fun_1270, ((long)1));
if(test1625_1277){
dsssl_arg_196_545 = PROCEDURE_ENTRY(fun_1270)(gensym___r4_symbols_6_4, arg1300_563, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2563___dsssl, fun_1270, string2558___dsssl, BINT(((long)3700)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
{
obj_t arg1281_546;
obj_t arg1282_547;
obj_t arg1283_548;
arg1281_546 = symbol2566___dsssl;
{
obj_t arg1290_554;
{
obj_t arg1295_558;
{
obj_t pair_956;
if(PAIRP(as_527)){
pair_956 = as_527;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, as_527, string2558___dsssl, BINT(((long)3745)));
exit( -1 );}
arg1295_558 = CAR(pair_956);
}
{
obj_t list1297_560;
{
obj_t arg1298_561;
arg1298_561 = MAKE_PAIR(BNIL, BNIL);
list1297_560 = MAKE_PAIR(arg1295_558, arg1298_561);
}
arg1290_554 = cons__138___r4_pairs_and_lists_6_3(dsssl_arg_196_545, list1297_560);
}
}
{
obj_t list1292_556;
list1292_556 = MAKE_PAIR(BNIL, BNIL);
arg1282_547 = cons__138___r4_pairs_and_lists_6_3(arg1290_554, list1292_556);
}
}
{
bool_t test1642_1291;
test1642_1291 = PROCEDURE_CORRECT_ARITYP(next_state_161_525, ((long)2));
if(test1642_1291){
arg1283_548 = PROCEDURE_ENTRY(next_state_161_525)(next_state_161_525, args_524, dsssl_arg_196_545, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2567___dsssl, next_state_161_525, string2558___dsssl, BINT(((long)3759)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
{
obj_t list1285_550;
{
obj_t arg1286_551;
{
obj_t arg1287_552;
arg1287_552 = MAKE_PAIR(BNIL, BNIL);
arg1286_551 = MAKE_PAIR(arg1283_548, arg1287_552);
}
list1285_550 = MAKE_PAIR(arg1282_547, arg1286_551);
}
aux1562_1149 = cons__138___r4_pairs_and_lists_6_3(arg1281_546, list1285_550);
}
}
}
}
 else {
bool_t test1270_537;
test1270_537 = PAIRP(e_103_175_535);
if(test1270_537){
obj_t cdr_105_52_538;
{
obj_t pair_949;
if(test1270_537){
pair_949 = e_103_175_535;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, e_103_175_535, string2558___dsssl, BINT(((long)3644)));
exit( -1 );}
cdr_105_52_538 = CDR(pair_949);
}
{
bool_t test1271_539;
{
obj_t arg1278_544;
{
obj_t pair_950;
if(test1270_537){
pair_950 = e_103_175_535;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, e_103_175_535, string2558___dsssl, BINT(((long)3644)));
exit( -1 );}
arg1278_544 = CAR(pair_950);
}
test1271_539 = SYMBOLP(arg1278_544);
}
if(test1271_539){
bool_t test1272_540;
test1272_540 = PAIRP(cdr_105_52_538);
if(test1272_540){
bool_t test1273_541;
{
obj_t arg1274_542;
{
obj_t pair_953;
if(test1272_540){
pair_953 = cdr_105_52_538;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, cdr_105_52_538, string2558___dsssl, BINT(((long)3644)));
exit( -1 );}
arg1274_542 = CDR(pair_953);
}
test1273_541 = (arg1274_542==BNIL);
}
if(test1273_541){
{
obj_t dsssl_arg_196_564;
{
obj_t arg1323_583;
arg1323_583 = symbol2561___dsssl;
{
obj_t fun_1298;
{
obj_t aux1643_1292;
aux1643_1292 = gensym___r4_symbols_6_4;
if(PROCEDUREP(aux1643_1292)){
fun_1298 = aux1643_1292;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2562___dsssl, aux1643_1292, string2558___dsssl, BINT(((long)3830)));
exit( -1 );}
}
{
bool_t test1656_1305;
test1656_1305 = PROCEDURE_CORRECT_ARITYP(fun_1298, ((long)1));
if(test1656_1305){
dsssl_arg_196_564 = PROCEDURE_ENTRY(fun_1298)(gensym___r4_symbols_6_4, arg1323_583, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2569___dsssl, fun_1298, string2558___dsssl, BINT(((long)3830)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
{
obj_t arg1301_565;
obj_t arg1302_566;
obj_t arg1303_567;
arg1301_565 = symbol2566___dsssl;
{
obj_t arg1310_573;
{
obj_t arg1315_577;
{
obj_t arg1322_582;
{
obj_t pair_957;
if(PAIRP(as_527)){
pair_957 = as_527;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, as_527, string2558___dsssl, BINT(((long)3880)));
exit( -1 );}
arg1322_582 = CAR(pair_957);
}
{
obj_t pair_958;
if(PAIRP(arg1322_582)){
pair_958 = arg1322_582;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, arg1322_582, string2558___dsssl, BINT(((long)3874)));
exit( -1 );}
arg1315_577 = CAR(pair_958);
}
}
{
obj_t list1317_579;
{
obj_t arg1319_580;
arg1319_580 = MAKE_PAIR(BNIL, BNIL);
list1317_579 = MAKE_PAIR(arg1315_577, arg1319_580);
}
arg1310_573 = cons__138___r4_pairs_and_lists_6_3(dsssl_arg_196_564, list1317_579);
}
}
{
obj_t list1312_575;
list1312_575 = MAKE_PAIR(BNIL, BNIL);
arg1302_566 = cons__138___r4_pairs_and_lists_6_3(arg1310_573, list1312_575);
}
}
{
bool_t test1680_1325;
test1680_1325 = PROCEDURE_CORRECT_ARITYP(next_state_161_525, ((long)2));
if(test1680_1325){
arg1303_567 = PROCEDURE_ENTRY(next_state_161_525)(next_state_161_525, args_524, dsssl_arg_196_564, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2567___dsssl, next_state_161_525, string2558___dsssl, BINT(((long)3895)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
{
obj_t list1305_569;
{
obj_t arg1307_570;
{
obj_t arg1308_571;
arg1308_571 = MAKE_PAIR(BNIL, BNIL);
arg1307_570 = MAKE_PAIR(arg1303_567, arg1308_571);
}
list1305_569 = MAKE_PAIR(arg1302_566, arg1307_570);
}
aux1562_1149 = cons__138___r4_pairs_and_lists_6_3(arg1301_565, list1305_569);
}
}
}
}
 else {
aux1562_1149 = BFALSE;
}
}
 else {
aux1562_1149 = BFALSE;
}
}
 else {
aux1562_1149 = BFALSE;
}
}
}
 else {
aux1562_1149 = BFALSE;
}
}
}
}
}
}
 else {
{
bool_t test1713_1357;
test1713_1357 = PROCEDURE_CORRECT_ARITYP(err_4, ((long)3));
if(test1713_1357){
aux1562_1149 = PROCEDURE_ENTRY(err_4)(err_4, where_1, string2571___dsssl, formals_2, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2572___dsssl, err_4, string2558___dsssl, BINT(((long)3501)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
break;
case ((long)259) : 
{
obj_t arg1334_596;
{
obj_t pair_967;
if(test1330_590){
pair_967 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)3090)));
exit( -1 );}
arg1334_596 = CDR(pair_967);
}
{
obj_t next_state_161_2508;
obj_t args_2507;
args_2507 = arg1334_596;
next_state_161_2508 = rest_state_87_1168;
next_state_161_525 = next_state_161_2508;
args_524 = args_2507;
goto enter_dsssl_state_31_606;
}
}
break;
case ((long)262) : 
{
obj_t arg1337_597;
{
obj_t pair_968;
if(test1330_590){
pair_968 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)3155)));
exit( -1 );}
arg1337_597 = CDR(pair_968);
}
{
obj_t next_state_161_2515;
obj_t args_2514;
args_2514 = arg1337_597;
next_state_161_2515 = no_rest_key_state_212_1167;
next_state_161_525 = next_state_161_2515;
args_524 = args_2514;
goto enter_dsssl_state_31_606;
}
}
break;
default: 
{
bool_t test1768_1401;
test1768_1401 = PROCEDURE_CORRECT_ARITYP(err_4, ((long)3));
if(test1768_1401){
aux1562_1149 = PROCEDURE_ENTRY(err_4)(err_4, where_1, string2571___dsssl, formals_2, BEOA);
}
 else {
error_location_112___error(string2553___dsssl, list2572___dsssl, err_4, string2558___dsssl, BINT(((long)3204)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
{
obj_t arg1339_600;
{
obj_t pair_969;
if(test1330_590){
pair_969 = args_588;
}
 else {
bigloo_type_error_location_103___error(symbol2552___dsssl, string2560___dsssl, args_588, string2558___dsssl, BINT(((long)3319)));
exit( -1 );}
arg1339_600 = CDR(pair_969);
}
{
obj_t args_2529;
args_2529 = arg1339_600;
args_588 = args_2529;
goto scheme_state_248_605;
}
}
}
}
 else {
aux1562_1149 = body_3;
}
}
}
}
POP_TRACE();
return aux1562_1149;
}
}
}
}


/* _make-dsssl-function-prelude1576 */obj_t _make_dsssl_function_prelude1576_158___dsssl(obj_t env_1170, obj_t where_1171, obj_t formals_1172, obj_t body_1173, obj_t err_1174)
{
{
obj_t aux_2531;
if(PROCEDUREP(err_1174)){
aux_2531 = err_1174;
}
 else {
bigloo_type_error_location_103___error(symbol2576___dsssl, string2562___dsssl, err_1174, string2558___dsssl, BINT(((long)2698)));
exit( -1 );}
return make_dsssl_function_prelude_58___dsssl(where_1171, formals_1172, body_1173, aux_2531);
}
}


/* key-state */obj_t key_state_193___dsssl(obj_t body_1178, obj_t formals_1177, obj_t where_1176, obj_t err_1175, obj_t args_234, obj_t dsssl_arg_196_235)
{
if(NULLP(args_234)){
return body_1178;
}
 else {
bool_t test1018_239;
test1018_239 = PAIRP(args_234);
if(test1018_239){
bool_t test1019_240;
{
bool_t test1032_261;
{
obj_t arg1035_264;
{
obj_t pair_821;
if(test1018_239){
pair_821 = args_234;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, args_234, string2558___dsssl, BINT(((long)6744)));
exit( -1 );}
arg1035_264 = CAR(pair_821);
}
test1032_261 = SYMBOLP(arg1035_264);
}
if(test1032_261){
test1019_240 = ((bool_t)0);
}
 else {
bool_t test1033_262;
{
obj_t arg1034_263;
{
obj_t pair_823;
if(test1018_239){
pair_823 = args_234;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, args_234, string2558___dsssl, BINT(((long)6769)));
exit( -1 );}
arg1034_263 = CAR(pair_823);
}
test1033_262 = PAIRP(arg1034_263);
}
if(test1033_262){
test1019_240 = ((bool_t)0);
}
 else {
test1019_240 = ((bool_t)1);
}
}
}
if(test1019_240){
{
obj_t fun_1440;
if(PROCEDUREP(err_1175)){
fun_1440 = err_1175;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2562___dsssl, err_1175, string2558___dsssl, BINT(((long)6785)));
exit( -1 );}
{
bool_t test1816_1447;
test1816_1447 = PROCEDURE_CORRECT_ARITYP(fun_1440, ((long)3));
if(test1816_1447){
return PROCEDURE_ENTRY(fun_1440)(err_1175, where_1176, string2578___dsssl, formals_1177, BEOA);
}
 else {
error_location_112___error(string2579___dsssl, list2580___dsssl, fun_1440, string2558___dsssl, BINT(((long)6785)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
 else {
{
obj_t e_168_255_247;
{
obj_t pair_825;
if(test1018_239){
pair_825 = args_234;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, args_234, string2558___dsssl, BINT(((long)6897)));
exit( -1 );}
e_168_255_247 = CAR(pair_825);
}
{
bool_t test1020_248;
test1020_248 = PAIRP(e_168_255_247);
if(test1020_248){
obj_t car_173_126_249;
obj_t cdr_174_83_250;
{
obj_t pair_827;
if(test1020_248){
pair_827 = e_168_255_247;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, e_168_255_247, string2558___dsssl, BINT(((long)6884)));
exit( -1 );}
car_173_126_249 = CAR(pair_827);
}
{
obj_t pair_828;
if(test1020_248){
pair_828 = e_168_255_247;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, e_168_255_247, string2558___dsssl, BINT(((long)6884)));
exit( -1 );}
cdr_174_83_250 = CDR(pair_828);
}
if(SYMBOLP(car_173_126_249)){
bool_t test1022_252;
test1022_252 = PAIRP(cdr_174_83_250);
if(test1022_252){
bool_t test1023_253;
{
obj_t arg1027_256;
{
obj_t pair_831;
if(test1022_252){
pair_831 = cdr_174_83_250;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, cdr_174_83_250, string2558___dsssl, BINT(((long)6884)));
exit( -1 );}
arg1027_256 = CDR(pair_831);
}
test1023_253 = (arg1027_256==BNIL);
}
if(test1023_253){
obj_t arg1025_254;
{
obj_t pair_834;
if(test1022_252){
pair_834 = cdr_174_83_250;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2560___dsssl, cdr_174_83_250, string2558___dsssl, BINT(((long)6884)));
exit( -1 );}
arg1025_254 = CAR(pair_834);
}
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1178, formals_1177, where_1176, err_1175, car_173_126_249, arg1025_254);
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1178, formals_1177, where_1176, err_1175, e_168_255_247, BFALSE);
}
 else {
obj_t fun_1484;
if(PROCEDUREP(err_1175)){
fun_1484 = err_1175;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2562___dsssl, err_1175, string2558___dsssl, BINT(((long)7068)));
exit( -1 );}
{
bool_t test1866_1491;
test1866_1491 = PROCEDURE_CORRECT_ARITYP(fun_1484, ((long)3));
if(test1866_1491){
return PROCEDURE_ENTRY(fun_1484)(err_1175, where_1176, string2578___dsssl, formals_1177, BEOA);
}
 else {
error_location_112___error(string2579___dsssl, list2580___dsssl, fun_1484, string2558___dsssl, BINT(((long)7068)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1178, formals_1177, where_1176, err_1175, e_168_255_247, BFALSE);
}
 else {
obj_t fun_1498;
if(PROCEDUREP(err_1175)){
fun_1498 = err_1175;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2562___dsssl, err_1175, string2558___dsssl, BINT(((long)7068)));
exit( -1 );}
{
bool_t test1881_1505;
test1881_1505 = PROCEDURE_CORRECT_ARITYP(fun_1498, ((long)3));
if(test1881_1505){
return PROCEDURE_ENTRY(fun_1498)(err_1175, where_1176, string2578___dsssl, formals_1177, BEOA);
}
 else {
error_location_112___error(string2579___dsssl, list2580___dsssl, fun_1498, string2558___dsssl, BINT(((long)7068)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1178, formals_1177, where_1176, err_1175, e_168_255_247, BFALSE);
}
 else {
obj_t fun_1512;
if(PROCEDUREP(err_1175)){
fun_1512 = err_1175;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2562___dsssl, err_1175, string2558___dsssl, BINT(((long)7068)));
exit( -1 );}
{
bool_t test1896_1519;
test1896_1519 = PROCEDURE_CORRECT_ARITYP(fun_1512, ((long)3));
if(test1896_1519){
return PROCEDURE_ENTRY(fun_1512)(err_1175, where_1176, string2578___dsssl, formals_1177, BEOA);
}
 else {
error_location_112___error(string2579___dsssl, list2580___dsssl, fun_1512, string2558___dsssl, BINT(((long)7068)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1178, formals_1177, where_1176, err_1175, e_168_255_247, BFALSE);
}
 else {
obj_t fun_1526;
if(PROCEDUREP(err_1175)){
fun_1526 = err_1175;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2562___dsssl, err_1175, string2558___dsssl, BINT(((long)7068)));
exit( -1 );}
{
bool_t test1911_1533;
test1911_1533 = PROCEDURE_CORRECT_ARITYP(fun_1526, ((long)3));
if(test1911_1533){
return PROCEDURE_ENTRY(fun_1526)(err_1175, where_1176, string2578___dsssl, formals_1177, BEOA);
}
 else {
error_location_112___error(string2579___dsssl, list2580___dsssl, fun_1526, string2558___dsssl, BINT(((long)7068)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
}
}
 else {
{
obj_t fun_1540;
if(PROCEDUREP(err_1175)){
fun_1540 = err_1175;
}
 else {
bigloo_type_error_location_103___error(symbol2577___dsssl, string2562___dsssl, err_1175, string2558___dsssl, BINT(((long)6664)));
exit( -1 );}
{
bool_t test1925_1547;
test1925_1547 = PROCEDURE_CORRECT_ARITYP(fun_1540, ((long)3));
if(test1925_1547){
return PROCEDURE_ENTRY(fun_1540)(err_1175, where_1176, string2578___dsssl, formals_1177, BEOA);
}
 else {
error_location_112___error(string2579___dsssl, list2580___dsssl, fun_1540, string2558___dsssl, BINT(((long)6664)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}


/* one-key-arg */obj_t one_key_arg_10___dsssl(obj_t args_1184, obj_t dsssl_arg_196_1183, obj_t body_1182, obj_t formals_1181, obj_t where_1180, obj_t err_1179, obj_t arg_265, obj_t initializer_266)
{
{
obj_t arg1037_268;
obj_t arg1038_269;
obj_t arg1039_270;
arg1037_268 = symbol2566___dsssl;
{
obj_t arg1045_276;
{
obj_t arg1049_280;
{
obj_t arg1055_285;
obj_t arg1056_286;
arg1055_285 = symbol2581___dsssl;
{
obj_t arg1411_846;
{
obj_t arg1413_847;
{
obj_t symbol_849;
if(SYMBOLP(arg_265)){
symbol_849 = arg_265;
}
 else {
bigloo_type_error_location_103___error(symbol2582___dsssl, string2583___dsssl, arg_265, string2558___dsssl, BINT(((long)12416)));
exit( -1 );}
arg1413_847 = SYMBOL_TO_STRING(symbol_849);
}
arg1411_846 = string_append(arg1413_847, string2584___dsssl);
}
{
char * aux_2682;
aux_2682 = BSTRING_TO_STRING(arg1411_846);
arg1056_286 = string_to_keyword(aux_2682);
}
}
{
obj_t list1058_288;
{
obj_t arg1059_289;
{
obj_t arg1060_290;
{
obj_t arg1061_291;
arg1061_291 = MAKE_PAIR(BNIL, BNIL);
arg1060_290 = MAKE_PAIR(initializer_266, arg1061_291);
}
arg1059_289 = MAKE_PAIR(arg1056_286, arg1060_290);
}
list1058_288 = MAKE_PAIR(dsssl_arg_196_1183, arg1059_289);
}
arg1049_280 = cons__138___r4_pairs_and_lists_6_3(arg1055_285, list1058_288);
}
}
{
obj_t list1051_282;
{
obj_t arg1053_283;
arg1053_283 = MAKE_PAIR(BNIL, BNIL);
list1051_282 = MAKE_PAIR(arg1049_280, arg1053_283);
}
arg1045_276 = cons__138___r4_pairs_and_lists_6_3(arg_265, list1051_282);
}
}
{
obj_t list1047_278;
list1047_278 = MAKE_PAIR(BNIL, BNIL);
arg1038_269 = cons__138___r4_pairs_and_lists_6_3(arg1045_276, list1047_278);
}
}
{
obj_t arg1063_293;
{
obj_t pair_851;
if(PAIRP(args_1184)){
pair_851 = args_1184;
}
 else {
bigloo_type_error_location_103___error(symbol2582___dsssl, string2560___dsssl, args_1184, string2558___dsssl, BINT(((long)6579)));
exit( -1 );}
arg1063_293 = CDR(pair_851);
}
arg1039_270 = key_state_193___dsssl(body_1182, formals_1181, where_1180, err_1179, arg1063_293, dsssl_arg_196_1183);
}
{
obj_t list1041_272;
{
obj_t arg1042_273;
{
obj_t arg1043_274;
arg1043_274 = MAKE_PAIR(BNIL, BNIL);
arg1042_273 = MAKE_PAIR(arg1039_270, arg1043_274);
}
list1041_272 = MAKE_PAIR(arg1038_269, arg1042_273);
}
return cons__138___r4_pairs_and_lists_6_3(arg1037_268, list1041_272);
}
}
}


/* tag-141 */obj_t tag_141_241___dsssl(obj_t args_1190, obj_t dsssl_arg_196_1189, obj_t body_1188, obj_t formals_1187, obj_t where_1186, obj_t err_1185, obj_t id_391)
{
{
obj_t arg1139_396;
obj_t arg1140_397;
obj_t arg1141_398;
arg1139_396 = symbol2566___dsssl;
{
obj_t arg1147_404;
{
obj_t list1152_409;
{
obj_t arg1153_410;
arg1153_410 = MAKE_PAIR(BNIL, BNIL);
list1152_409 = MAKE_PAIR(dsssl_arg_196_1189, arg1153_410);
}
arg1147_404 = cons__138___r4_pairs_and_lists_6_3(id_391, list1152_409);
}
{
obj_t list1149_406;
list1149_406 = MAKE_PAIR(BNIL, BNIL);
arg1140_397 = cons__138___r4_pairs_and_lists_6_3(arg1147_404, list1149_406);
}
}
{
obj_t arg1155_412;
{
obj_t pair_904;
if(PAIRP(args_1190)){
pair_904 = args_1190;
}
 else {
bigloo_type_error_location_103___error(symbol2585___dsssl, string2560___dsssl, args_1190, string2558___dsssl, BINT(((long)5263)));
exit( -1 );}
arg1155_412 = CDR(pair_904);
}
arg1141_398 = exit_rest_state_151___dsssl(body_1188, formals_1187, where_1186, err_1185, arg1155_412, dsssl_arg_196_1189);
}
{
obj_t list1143_400;
{
obj_t arg1144_401;
{
obj_t arg1145_402;
arg1145_402 = MAKE_PAIR(BNIL, BNIL);
arg1144_401 = MAKE_PAIR(arg1141_398, arg1145_402);
}
list1143_400 = MAKE_PAIR(arg1140_397, arg1144_401);
}
return cons__138___r4_pairs_and_lists_6_3(arg1139_396, list1143_400);
}
}
}


/* exit-rest-state */obj_t exit_rest_state_151___dsssl(obj_t body_1194, obj_t formals_1193, obj_t where_1192, obj_t err_1191, obj_t args_379, obj_t dsssl_arg_196_380)
{
if(NULLP(args_379)){
return body_1194;
}
 else {
bool_t test1131_383;
test1131_383 = PAIRP(args_379);
if(test1131_383){
bool_t test1132_384;
{
obj_t arg1134_386;
{
obj_t pair_894;
if(test1131_383){
pair_894 = args_379;
}
 else {
bigloo_type_error_location_103___error(symbol2586___dsssl, string2560___dsssl, args_379, string2558___dsssl, BINT(((long)5549)));
exit( -1 );}
arg1134_386 = CAR(pair_894);
}
test1132_384 = (arg1134_386==BCNST(262));
}
if(test1132_384){
{
obj_t arg1133_385;
{
obj_t pair_897;
if(test1131_383){
pair_897 = args_379;
}
 else {
bigloo_type_error_location_103___error(symbol2586___dsssl, string2560___dsssl, args_379, string2558___dsssl, BINT(((long)5586)));
exit( -1 );}
arg1133_385 = CDR(pair_897);
}
return rest_key_state_46___dsssl(body_1194, formals_1193, where_1192, err_1191, arg1133_385, dsssl_arg_196_380);
}
}
 else {
{
obj_t fun_1584;
if(PROCEDUREP(err_1191)){
fun_1584 = err_1191;
}
 else {
bigloo_type_error_location_103___error(symbol2586___dsssl, string2562___dsssl, err_1191, string2558___dsssl, BINT(((long)5619)));
exit( -1 );}
{
bool_t test1973_1591;
test1973_1591 = PROCEDURE_CORRECT_ARITYP(fun_1584, ((long)3));
if(test1973_1591){
return PROCEDURE_ENTRY(fun_1584)(err_1191, where_1192, string2587___dsssl, formals_1193, BEOA);
}
 else {
error_location_112___error(string2588___dsssl, list2589___dsssl, fun_1584, string2558___dsssl, BINT(((long)5619)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
{
obj_t fun_1598;
if(PROCEDUREP(err_1191)){
fun_1598 = err_1191;
}
 else {
bigloo_type_error_location_103___error(symbol2586___dsssl, string2562___dsssl, err_1191, string2558___dsssl, BINT(((long)5482)));
exit( -1 );}
{
bool_t test1987_1605;
test1987_1605 = PROCEDURE_CORRECT_ARITYP(fun_1598, ((long)3));
if(test1987_1605){
return PROCEDURE_ENTRY(fun_1598)(err_1191, where_1192, string2587___dsssl, formals_1193, BEOA);
}
 else {
error_location_112___error(string2588___dsssl, list2589___dsssl, fun_1598, string2558___dsssl, BINT(((long)5482)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}


/* rest-key-state */obj_t rest_key_state_46___dsssl(obj_t body_1198, obj_t formals_1197, obj_t where_1196, obj_t err_1195, obj_t args_354, obj_t dsssl_arg_196_355)
{
if(NULLP(args_354)){
return body_1198;
}
 else {
{
obj_t arg1108_358;
obj_t arg1109_359;
obj_t arg1110_360;
arg1108_358 = symbol2590___dsssl;
{
obj_t arg1116_366;
obj_t arg1117_367;
arg1116_366 = symbol2591___dsssl;
{
obj_t arg1123_373;
arg1123_373 = symbol2592___dsssl;
{
obj_t list1126_376;
{
obj_t arg1127_377;
arg1127_377 = MAKE_PAIR(BNIL, BNIL);
list1126_376 = MAKE_PAIR(BNIL, arg1127_377);
}
arg1117_367 = cons__138___r4_pairs_and_lists_6_3(arg1123_373, list1126_376);
}
}
{
obj_t list1119_369;
{
obj_t arg1120_370;
{
obj_t arg1121_371;
arg1121_371 = MAKE_PAIR(BNIL, BNIL);
arg1120_370 = MAKE_PAIR(arg1117_367, arg1121_371);
}
list1119_369 = MAKE_PAIR(dsssl_arg_196_355, arg1120_370);
}
arg1109_359 = cons__138___r4_pairs_and_lists_6_3(arg1116_366, list1119_369);
}
}
arg1110_360 = key_state_193___dsssl(body_1198, formals_1197, where_1196, err_1195, args_354, dsssl_arg_196_355);
{
obj_t list1112_362;
{
obj_t arg1113_363;
{
obj_t arg1114_364;
arg1114_364 = MAKE_PAIR(BNIL, BNIL);
arg1113_363 = MAKE_PAIR(arg1110_360, arg1114_364);
}
list1112_362 = MAKE_PAIR(arg1109_359, arg1113_363);
}
return cons__138___r4_pairs_and_lists_6_3(arg1108_358, list1112_362);
}
}
}
}


/* no-rest-key-state */obj_t no_rest_key_state_212___dsssl(obj_t env_1199, obj_t args_1204, obj_t dsssl_arg_196_1205)
{
{
obj_t err_1200;
obj_t where_1201;
obj_t formals_1202;
obj_t body_1203;
err_1200 = PROCEDURE_REF(env_1199, ((long)0));
where_1201 = PROCEDURE_REF(env_1199, ((long)1));
formals_1202 = PROCEDURE_REF(env_1199, ((long)2));
body_1203 = PROCEDURE_REF(env_1199, ((long)3));
{
obj_t args_295;
obj_t dsssl_arg_196_296;
args_295 = args_1204;
dsssl_arg_196_296 = dsssl_arg_196_1205;
{
obj_t args_321;
if(NULLP(args_295)){
return body_1203;
}
 else {
{
obj_t arg1066_300;
obj_t arg1067_301;
obj_t arg1068_302;
arg1066_300 = symbol2590___dsssl;
{
obj_t arg1077_308;
obj_t arg1078_309;
arg1077_308 = symbol2591___dsssl;
{
obj_t arg1084_315;
obj_t arg1085_316;
arg1084_315 = symbol2592___dsssl;
args_321 = args_295;
if(NULLP(args_321)){
arg1085_316 = BNIL;
}
 else {
obj_t head1010_325;
head1010_325 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1008_326;
obj_t tail1011_327;
l1008_326 = args_321;
tail1011_327 = head1010_325;
lname1009_328:
{
bool_t test1092_329;
test1092_329 = PAIRP(l1008_326);
if(test1092_329){
{
obj_t newtail1012_330;
{
obj_t arg1094_332;
{
obj_t arg_334;
{
obj_t pair_857;
if(test1092_329){
pair_857 = l1008_326;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2560___dsssl, l1008_326, string2558___dsssl, BINT(((long)5957)));
exit( -1 );}
arg_334 = CAR(pair_857);
}
if(SYMBOLP(arg_334)){
arg1094_332 = symbol__keyword_174___dsssl(arg_334);
}
 else {
bool_t test1097_342;
test1097_342 = PAIRP(arg_334);
if(test1097_342){
obj_t car_158_189_343;
obj_t cdr_159_157_344;
{
obj_t pair_861;
if(test1097_342){
pair_861 = arg_334;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2560___dsssl, arg_334, string2558___dsssl, BINT(((long)5957)));
exit( -1 );}
car_158_189_343 = CAR(pair_861);
}
{
obj_t pair_862;
if(test1097_342){
pair_862 = arg_334;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2560___dsssl, arg_334, string2558___dsssl, BINT(((long)5957)));
exit( -1 );}
cdr_159_157_344 = CDR(pair_862);
}
if(SYMBOLP(car_158_189_343)){
bool_t test1099_346;
test1099_346 = PAIRP(cdr_159_157_344);
if(test1099_346){
bool_t test1100_347;
{
obj_t arg1101_348;
{
obj_t pair_865;
if(test1099_346){
pair_865 = cdr_159_157_344;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2560___dsssl, cdr_159_157_344, string2558___dsssl, BINT(((long)5957)));
exit( -1 );}
arg1101_348 = CDR(pair_865);
}
test1100_347 = (arg1101_348==BNIL);
}
if(test1100_347){
arg1094_332 = symbol__keyword_174___dsssl(car_158_189_343);
}
 else {
obj_t fun_1636;
if(PROCEDUREP(err_1200)){
fun_1636 = err_1200;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2562___dsssl, err_1200, string2558___dsssl, BINT(((long)6139)));
exit( -1 );}
{
bool_t test2031_1643;
test2031_1643 = PROCEDURE_CORRECT_ARITYP(fun_1636, ((long)3));
if(test2031_1643){
arg1094_332 = PROCEDURE_ENTRY(fun_1636)(err_1200, where_1201, string2578___dsssl, formals_1202, BEOA);
}
 else {
error_location_112___error(string2594___dsssl, list2580___dsssl, fun_1636, string2558___dsssl, BINT(((long)6139)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
 else {
obj_t fun_1650;
if(PROCEDUREP(err_1200)){
fun_1650 = err_1200;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2562___dsssl, err_1200, string2558___dsssl, BINT(((long)6139)));
exit( -1 );}
{
bool_t test2046_1657;
test2046_1657 = PROCEDURE_CORRECT_ARITYP(fun_1650, ((long)3));
if(test2046_1657){
arg1094_332 = PROCEDURE_ENTRY(fun_1650)(err_1200, where_1201, string2578___dsssl, formals_1202, BEOA);
}
 else {
error_location_112___error(string2594___dsssl, list2580___dsssl, fun_1650, string2558___dsssl, BINT(((long)6139)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
 else {
obj_t fun_1664;
if(PROCEDUREP(err_1200)){
fun_1664 = err_1200;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2562___dsssl, err_1200, string2558___dsssl, BINT(((long)6139)));
exit( -1 );}
{
bool_t test2059_1671;
test2059_1671 = PROCEDURE_CORRECT_ARITYP(fun_1664, ((long)3));
if(test2059_1671){
arg1094_332 = PROCEDURE_ENTRY(fun_1664)(err_1200, where_1201, string2578___dsssl, formals_1202, BEOA);
}
 else {
error_location_112___error(string2594___dsssl, list2580___dsssl, fun_1664, string2558___dsssl, BINT(((long)6139)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
 else {
obj_t fun_1678;
if(PROCEDUREP(err_1200)){
fun_1678 = err_1200;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2562___dsssl, err_1200, string2558___dsssl, BINT(((long)6139)));
exit( -1 );}
{
bool_t test2072_1685;
test2072_1685 = PROCEDURE_CORRECT_ARITYP(fun_1678, ((long)3));
if(test2072_1685){
arg1094_332 = PROCEDURE_ENTRY(fun_1678)(err_1200, where_1201, string2578___dsssl, formals_1202, BEOA);
}
 else {
error_location_112___error(string2594___dsssl, list2580___dsssl, fun_1678, string2558___dsssl, BINT(((long)6139)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
newtail1012_330 = MAKE_PAIR(arg1094_332, BNIL);
}
SET_CDR(tail1011_327, newtail1012_330);
{
obj_t arg1093_331;
{
obj_t pair_885;
if(PAIRP(l1008_326)){
pair_885 = l1008_326;
}
 else {
bigloo_type_error_location_103___error(symbol2593___dsssl, string2560___dsssl, l1008_326, string2558___dsssl, BINT(((long)5957)));
exit( -1 );}
arg1093_331 = CDR(pair_885);
}
{
obj_t tail1011_2877;
obj_t l1008_2876;
l1008_2876 = arg1093_331;
tail1011_2877 = newtail1012_330;
tail1011_327 = tail1011_2877;
l1008_326 = l1008_2876;
goto lname1009_328;
}
}
}
}
 else {
if(NULLP(l1008_326)){
arg1085_316 = CDR(head1010_325);
}
 else {
arg1085_316 = debug_error_location_199___error(string2595___dsssl, string2596___dsssl, l1008_326, string2597___dsssl, BINT(((long)7610)));
}
}
}
}
}
{
obj_t list1087_318;
{
obj_t arg1088_319;
arg1088_319 = MAKE_PAIR(BNIL, BNIL);
list1087_318 = MAKE_PAIR(arg1085_316, arg1088_319);
}
arg1078_309 = cons__138___r4_pairs_and_lists_6_3(arg1084_315, list1087_318);
}
}
{
obj_t list1080_311;
{
obj_t arg1081_312;
{
obj_t arg1082_313;
arg1082_313 = MAKE_PAIR(BNIL, BNIL);
arg1081_312 = MAKE_PAIR(arg1078_309, arg1082_313);
}
list1080_311 = MAKE_PAIR(dsssl_arg_196_296, arg1081_312);
}
arg1067_301 = cons__138___r4_pairs_and_lists_6_3(arg1077_308, list1080_311);
}
}
arg1068_302 = key_state_193___dsssl(body_1203, formals_1202, where_1201, err_1200, args_295, dsssl_arg_196_296);
{
obj_t list1070_304;
{
obj_t arg1072_305;
{
obj_t arg1073_306;
arg1073_306 = MAKE_PAIR(BNIL, BNIL);
arg1072_305 = MAKE_PAIR(arg1068_302, arg1073_306);
}
list1070_304 = MAKE_PAIR(arg1067_301, arg1072_305);
}
return cons__138___r4_pairs_and_lists_6_3(arg1066_300, list1070_304);
}
}
}
}
}
}
}


/* rest-state */obj_t rest_state_87___dsssl(obj_t env_1206, obj_t args_1211, obj_t dsssl_arg_196_1212)
{
{
obj_t body_1207;
obj_t err_1208;
obj_t where_1209;
obj_t formals_1210;
body_1207 = PROCEDURE_REF(env_1206, ((long)0));
err_1208 = PROCEDURE_REF(env_1206, ((long)1));
where_1209 = PROCEDURE_REF(env_1206, ((long)2));
formals_1210 = PROCEDURE_REF(env_1206, ((long)3));
{
obj_t args_387;
obj_t dsssl_arg_196_388;
args_387 = args_1211;
dsssl_arg_196_388 = dsssl_arg_196_1212;
{
bool_t test1136_390;
test1136_390 = PAIRP(args_387);
if(test1136_390){
{
obj_t e_143_131_394;
{
obj_t pair_899;
if(test1136_390){
pair_899 = args_387;
}
 else {
bigloo_type_error_location_103___error(symbol2598___dsssl, string2560___dsssl, args_387, string2558___dsssl, BINT(((long)5169)));
exit( -1 );}
e_143_131_394 = CAR(pair_899);
}
if(SYMBOLP(e_143_131_394)){
return tag_141_241___dsssl(args_387, dsssl_arg_196_388, body_1207, formals_1210, where_1209, err_1208, e_143_131_394);
}
 else {
return debug_error_location_199___error(where_1209, string2587___dsssl, formals_1210, string2597___dsssl, BINT(((long)7610)));
}
}
}
 else {
{
obj_t fun_1704;
if(PROCEDUREP(err_1208)){
fun_1704 = err_1208;
}
 else {
bigloo_type_error_location_103___error(symbol2598___dsssl, string2562___dsssl, err_1208, string2558___dsssl, BINT(((long)5087)));
exit( -1 );}
{
bool_t test2097_1711;
test2097_1711 = PROCEDURE_CORRECT_ARITYP(fun_1704, ((long)3));
if(test2097_1711){
return PROCEDURE_ENTRY(fun_1704)(err_1208, where_1209, string2587___dsssl, formals_1210, BEOA);
}
 else {
error_location_112___error(string2599___dsssl, list2589___dsssl, fun_1704, string2558___dsssl, BINT(((long)5087)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
}
}


/* optional-state */obj_t optional_state_215___dsssl(obj_t env_1213, obj_t args_1219, obj_t dsssl_arg_196_1220)
{
return optional_state_1579_63___dsssl(PROCEDURE_REF(env_1213, ((long)4)), PROCEDURE_REF(env_1213, ((long)3)), PROCEDURE_REF(env_1213, ((long)2)), PROCEDURE_REF(env_1213, ((long)1)), PROCEDURE_REF(env_1213, ((long)0)), args_1219, dsssl_arg_196_1220);
}


/* optional-state_1579 */obj_t optional_state_1579_63___dsssl(obj_t body_1237, obj_t rest_state_87_1236, obj_t formals_1235, obj_t where_1234, obj_t err_1233, obj_t args_413, obj_t dsssl_arg_196_414)
{
{
obj_t arg_451;
obj_t initializer_452;
if(NULLP(args_413)){
return body_1237;
}
 else {
bool_t test1158_418;
test1158_418 = PAIRP(args_413);
if(test1158_418){
bool_t test1159_419;
{
bool_t test1175_447;
{
obj_t arg1178_450;
{
obj_t pair_910;
if(test1158_418){
pair_910 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4397)));
exit( -1 );}
arg1178_450 = CAR(pair_910);
}
test1175_447 = SYMBOLP(arg1178_450);
}
if(test1175_447){
test1159_419 = ((bool_t)0);
}
 else {
bool_t test1176_448;
{
obj_t arg1177_449;
{
obj_t pair_912;
if(test1158_418){
pair_912 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4422)));
exit( -1 );}
arg1177_449 = CAR(pair_912);
}
test1176_448 = PAIRP(arg1177_449);
}
if(test1176_448){
test1159_419 = ((bool_t)0);
}
 else {
test1159_419 = ((bool_t)1);
}
}
}
if(test1159_419){
{
long aux1007_421;
{
obj_t aux1005_425;
{
obj_t pair_914;
if(test1158_418){
pair_914 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4500)));
exit( -1 );}
aux1005_425 = CAR(pair_914);
}
if(CNSTP(aux1005_425)){
aux1007_421 = CCNST(aux1005_425);
}
 else {
aux1007_421 = ((long)-1);
}
}
switch (aux1007_421){
case ((long)259) : 
{
obj_t arg1161_423;
{
obj_t pair_916;
if(test1158_418){
pair_916 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4546)));
exit( -1 );}
arg1161_423 = CDR(pair_916);
}
{
obj_t aux_2961;
if(PROCEDUREP(rest_state_87_1236)){
aux_2961 = rest_state_87_1236;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, rest_state_87_1236, string2558___dsssl, BINT(((long)4533)));
exit( -1 );}
return rest_state_87___dsssl(aux_2961, arg1161_423, dsssl_arg_196_414);
}
}
break;
case ((long)262) : 
{
obj_t arg1162_424;
{
obj_t pair_917;
if(test1158_418){
pair_917 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4603)));
exit( -1 );}
arg1162_424 = CDR(pair_917);
}
{
obj_t aux_2973;
if(PROCEDUREP(rest_state_87_1236)){
aux_2973 = rest_state_87_1236;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, rest_state_87_1236, string2558___dsssl, BINT(((long)4590)));
exit( -1 );}
return rest_state_87___dsssl(aux_2973, arg1162_424, dsssl_arg_196_414);
}
}
break;
default: 
{
obj_t fun_1780;
if(PROCEDUREP(err_1233)){
fun_1780 = err_1233;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, err_1233, string2558___dsssl, BINT(((long)4644)));
exit( -1 );}
{
bool_t test2177_1787;
test2177_1787 = PROCEDURE_CORRECT_ARITYP(fun_1780, ((long)3));
if(test2177_1787){
return PROCEDURE_ENTRY(fun_1780)(err_1233, where_1234, string2610___dsssl, formals_1235, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2611___dsssl, fun_1780, string2558___dsssl, BINT(((long)4644)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
 else {
{
obj_t e_111_246_433;
{
obj_t pair_918;
if(test1158_418){
pair_918 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4763)));
exit( -1 );}
e_111_246_433 = CAR(pair_918);
}
{
bool_t test1164_434;
test1164_434 = PAIRP(e_111_246_433);
if(test1164_434){
obj_t car_116_203_435;
obj_t cdr_117_2_436;
{
obj_t pair_920;
if(test1164_434){
pair_920 = e_111_246_433;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, e_111_246_433, string2558___dsssl, BINT(((long)4750)));
exit( -1 );}
car_116_203_435 = CAR(pair_920);
}
{
obj_t pair_921;
if(test1164_434){
pair_921 = e_111_246_433;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, e_111_246_433, string2558___dsssl, BINT(((long)4750)));
exit( -1 );}
cdr_117_2_436 = CDR(pair_921);
}
if(SYMBOLP(car_116_203_435)){
bool_t test1166_438;
test1166_438 = PAIRP(cdr_117_2_436);
if(test1166_438){
bool_t test1167_439;
{
obj_t arg1170_442;
{
obj_t pair_924;
if(test1166_438){
pair_924 = cdr_117_2_436;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, cdr_117_2_436, string2558___dsssl, BINT(((long)4750)));
exit( -1 );}
arg1170_442 = CDR(pair_924);
}
test1167_439 = (arg1170_442==BNIL);
}
if(test1167_439){
obj_t arg1168_440;
{
obj_t pair_927;
if(test1166_438){
pair_927 = cdr_117_2_436;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, cdr_117_2_436, string2558___dsssl, BINT(((long)4750)));
exit( -1 );}
arg1168_440 = CAR(pair_927);
}
arg_451 = car_116_203_435;
initializer_452 = arg1168_440;
one_optional_arg_34_523:
{
obj_t tmp_454;
{
obj_t arg1263_522;
arg1263_522 = symbol2600___dsssl;
{
obj_t fun_1718;
{
obj_t aux2098_1712;
aux2098_1712 = gensym___r4_symbols_6_4;
if(PROCEDUREP(aux2098_1712)){
fun_1718 = aux2098_1712;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, aux2098_1712, string2558___dsssl, BINT(((long)4037)));
exit( -1 );}
}
{
bool_t test2110_1725;
test2110_1725 = PROCEDURE_CORRECT_ARITYP(fun_1718, ((long)1));
if(test2110_1725){
tmp_454 = PROCEDURE_ENTRY(fun_1718)(gensym___r4_symbols_6_4, arg1263_522, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2603___dsssl, fun_1718, string2558___dsssl, BINT(((long)4037)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
{
obj_t arg1180_455;
obj_t arg1181_456;
obj_t arg1182_457;
arg1180_455 = symbol2566___dsssl;
{
obj_t arg1188_463;
{
obj_t arg1192_467;
{
obj_t arg1197_472;
obj_t arg1199_473;
obj_t arg1200_474;
arg1197_472 = symbol2605___dsssl;
{
obj_t arg1207_481;
arg1207_481 = symbol2606___dsssl;
{
obj_t list1210_483;
{
obj_t arg1211_484;
arg1211_484 = MAKE_PAIR(BNIL, BNIL);
list1210_483 = MAKE_PAIR(dsssl_arg_196_414, arg1211_484);
}
arg1199_473 = cons__138___r4_pairs_and_lists_6_3(arg1207_481, list1210_483);
}
}
{
obj_t arg1214_486;
obj_t arg1216_487;
obj_t arg1219_488;
arg1214_486 = symbol2566___dsssl;
{
obj_t arg1228_495;
{
obj_t arg1234_499;
{
obj_t arg1241_504;
arg1241_504 = symbol2607___dsssl;
{
obj_t list1244_506;
{
obj_t arg1245_507;
arg1245_507 = MAKE_PAIR(BNIL, BNIL);
list1244_506 = MAKE_PAIR(dsssl_arg_196_414, arg1245_507);
}
arg1234_499 = cons__138___r4_pairs_and_lists_6_3(arg1241_504, list1244_506);
}
}
{
obj_t list1236_501;
{
obj_t arg1238_502;
arg1238_502 = MAKE_PAIR(BNIL, BNIL);
list1236_501 = MAKE_PAIR(arg1234_499, arg1238_502);
}
arg1228_495 = cons__138___r4_pairs_and_lists_6_3(tmp_454, list1236_501);
}
}
{
obj_t list1232_497;
list1232_497 = MAKE_PAIR(BNIL, BNIL);
arg1216_487 = cons__138___r4_pairs_and_lists_6_3(arg1228_495, list1232_497);
}
}
{
obj_t arg1248_509;
obj_t arg1250_510;
arg1248_509 = symbol2608___dsssl;
{
obj_t arg1256_516;
arg1256_516 = symbol2609___dsssl;
{
obj_t list1258_518;
{
obj_t arg1259_519;
arg1259_519 = MAKE_PAIR(BNIL, BNIL);
list1258_518 = MAKE_PAIR(dsssl_arg_196_414, arg1259_519);
}
arg1250_510 = cons__138___r4_pairs_and_lists_6_3(arg1256_516, list1258_518);
}
}
{
obj_t list1252_512;
{
obj_t arg1253_513;
{
obj_t arg1254_514;
arg1254_514 = MAKE_PAIR(BNIL, BNIL);
arg1253_513 = MAKE_PAIR(arg1250_510, arg1254_514);
}
list1252_512 = MAKE_PAIR(dsssl_arg_196_414, arg1253_513);
}
arg1219_488 = cons__138___r4_pairs_and_lists_6_3(arg1248_509, list1252_512);
}
}
{
obj_t list1221_490;
{
obj_t arg1222_491;
{
obj_t arg1224_492;
{
obj_t arg1225_493;
arg1225_493 = MAKE_PAIR(BNIL, BNIL);
arg1224_492 = MAKE_PAIR(tmp_454, arg1225_493);
}
arg1222_491 = MAKE_PAIR(arg1219_488, arg1224_492);
}
list1221_490 = MAKE_PAIR(arg1216_487, arg1222_491);
}
arg1200_474 = cons__138___r4_pairs_and_lists_6_3(arg1214_486, list1221_490);
}
}
{
obj_t list1202_476;
{
obj_t arg1203_477;
{
obj_t arg1204_478;
{
obj_t arg1205_479;
arg1205_479 = MAKE_PAIR(BNIL, BNIL);
arg1204_478 = MAKE_PAIR(arg1200_474, arg1205_479);
}
arg1203_477 = MAKE_PAIR(initializer_452, arg1204_478);
}
list1202_476 = MAKE_PAIR(arg1199_473, arg1203_477);
}
arg1192_467 = cons__138___r4_pairs_and_lists_6_3(arg1197_472, list1202_476);
}
}
{
obj_t list1194_469;
{
obj_t arg1195_470;
arg1195_470 = MAKE_PAIR(BNIL, BNIL);
list1194_469 = MAKE_PAIR(arg1192_467, arg1195_470);
}
arg1188_463 = cons__138___r4_pairs_and_lists_6_3(arg_451, list1194_469);
}
}
{
obj_t list1190_465;
list1190_465 = MAKE_PAIR(BNIL, BNIL);
arg1181_456 = cons__138___r4_pairs_and_lists_6_3(arg1188_463, list1190_465);
}
}
{
obj_t arg1262_521;
{
obj_t pair_938;
if(PAIRP(args_413)){
pair_938 = args_413;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2560___dsssl, args_413, string2558___dsssl, BINT(((long)4226)));
exit( -1 );}
arg1262_521 = CDR(pair_938);
}
arg1182_457 = optional_state_1579_63___dsssl(body_1237, rest_state_87_1236, formals_1235, where_1234, err_1233, arg1262_521, dsssl_arg_196_414);
}
{
obj_t list1184_459;
{
obj_t arg1185_460;
{
obj_t arg1186_461;
arg1186_461 = MAKE_PAIR(BNIL, BNIL);
arg1185_460 = MAKE_PAIR(arg1182_457, arg1186_461);
}
list1184_459 = MAKE_PAIR(arg1181_456, arg1185_460);
}
return cons__138___r4_pairs_and_lists_6_3(arg1180_455, list1184_459);
}
}
}
}
 else {
if(SYMBOLP(e_111_246_433)){
obj_t initializer_3085;
obj_t arg_3084;
arg_3084 = e_111_246_433;
initializer_3085 = BFALSE;
initializer_452 = initializer_3085;
arg_451 = arg_3084;
goto one_optional_arg_34_523;
}
 else {
obj_t fun_1838;
if(PROCEDUREP(err_1233)){
fun_1838 = err_1233;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, err_1233, string2558___dsssl, BINT(((long)4944)));
exit( -1 );}
{
bool_t test2235_1845;
test2235_1845 = PROCEDURE_CORRECT_ARITYP(fun_1838, ((long)3));
if(test2235_1845){
return PROCEDURE_ENTRY(fun_1838)(err_1233, where_1234, string2610___dsssl, formals_1235, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2611___dsssl, fun_1838, string2558___dsssl, BINT(((long)4944)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
if(SYMBOLP(e_111_246_433)){
obj_t initializer_3101;
obj_t arg_3100;
arg_3100 = e_111_246_433;
initializer_3101 = BFALSE;
initializer_452 = initializer_3101;
arg_451 = arg_3100;
goto one_optional_arg_34_523;
}
 else {
obj_t fun_1852;
if(PROCEDUREP(err_1233)){
fun_1852 = err_1233;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, err_1233, string2558___dsssl, BINT(((long)4944)));
exit( -1 );}
{
bool_t test2249_1859;
test2249_1859 = PROCEDURE_CORRECT_ARITYP(fun_1852, ((long)3));
if(test2249_1859){
return PROCEDURE_ENTRY(fun_1852)(err_1233, where_1234, string2610___dsssl, formals_1235, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2611___dsssl, fun_1852, string2558___dsssl, BINT(((long)4944)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
if(SYMBOLP(e_111_246_433)){
obj_t initializer_3117;
obj_t arg_3116;
arg_3116 = e_111_246_433;
initializer_3117 = BFALSE;
initializer_452 = initializer_3117;
arg_451 = arg_3116;
goto one_optional_arg_34_523;
}
 else {
obj_t fun_1866;
if(PROCEDUREP(err_1233)){
fun_1866 = err_1233;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, err_1233, string2558___dsssl, BINT(((long)4944)));
exit( -1 );}
{
bool_t test2265_1873;
test2265_1873 = PROCEDURE_CORRECT_ARITYP(fun_1866, ((long)3));
if(test2265_1873){
return PROCEDURE_ENTRY(fun_1866)(err_1233, where_1234, string2610___dsssl, formals_1235, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2611___dsssl, fun_1866, string2558___dsssl, BINT(((long)4944)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
 else {
if(SYMBOLP(e_111_246_433)){
obj_t initializer_3133;
obj_t arg_3132;
arg_3132 = e_111_246_433;
initializer_3133 = BFALSE;
initializer_452 = initializer_3133;
arg_451 = arg_3132;
goto one_optional_arg_34_523;
}
 else {
obj_t fun_1880;
if(PROCEDUREP(err_1233)){
fun_1880 = err_1233;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, err_1233, string2558___dsssl, BINT(((long)4944)));
exit( -1 );}
{
bool_t test2278_1887;
test2278_1887 = PROCEDURE_CORRECT_ARITYP(fun_1880, ((long)3));
if(test2278_1887){
return PROCEDURE_ENTRY(fun_1880)(err_1233, where_1234, string2610___dsssl, formals_1235, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2611___dsssl, fun_1880, string2558___dsssl, BINT(((long)4944)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
}
}
 else {
{
obj_t fun_1894;
if(PROCEDUREP(err_1233)){
fun_1894 = err_1233;
}
 else {
bigloo_type_error_location_103___error(symbol2601___dsssl, string2562___dsssl, err_1233, string2558___dsssl, BINT(((long)4312)));
exit( -1 );}
{
bool_t test2292_1901;
test2292_1901 = PROCEDURE_CORRECT_ARITYP(fun_1894, ((long)3));
if(test2292_1901){
return PROCEDURE_ENTRY(fun_1894)(err_1233, where_1234, string2610___dsssl, formals_1235, BEOA);
}
 else {
error_location_112___error(string2602___dsssl, list2611___dsssl, fun_1894, string2558___dsssl, BINT(((long)4312)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
}


/* dsssl-check-key-args! */obj_t dsssl_check_key_args__153___dsssl(obj_t dsssl_args_32_5, obj_t key_list_141_6)
{
{
obj_t symbol1565_1150;
symbol1565_1150 = symbol2591___dsssl;
{
PUSH_TRACE(symbol1565_1150);
BUNSPEC;
{
obj_t aux1564_1151;
if(NULLP(key_list_141_6)){
obj_t args_614;
args_614 = dsssl_args_32_5;
loop_615:
if(NULLP(args_614)){
aux1564_1151 = BTRUE;
}
 else {
bool_t test1346_617;
{
bool_t test1348_619;
test1348_619 = PAIRP(args_614);
if(test1348_619){
bool_t test1349_620;
{
obj_t arg1352_623;
{
obj_t pair_973;
if(test1348_619){
pair_973 = args_614;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_614, string2558___dsssl, BINT(((long)8025)));
exit( -1 );}
arg1352_623 = CDR(pair_973);
}
test1349_620 = NULLP(arg1352_623);
}
if(test1349_620){
test1346_617 = ((bool_t)1);
}
 else {
bool_t test1350_621;
{
obj_t arg1351_622;
{
obj_t pair_975;
if(test1348_619){
pair_975 = args_614;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_614, string2558___dsssl, BINT(((long)8056)));
exit( -1 );}
arg1351_622 = CAR(pair_975);
}
test1350_621 = KEYWORDP(arg1351_622);
}
if(test1350_621){
test1346_617 = ((bool_t)0);
}
 else {
test1346_617 = ((bool_t)1);
}
}
}
 else {
test1346_617 = ((bool_t)1);
}
}
if(test1346_617){
aux1564_1151 = debug_error_location_199___error(string2612___dsssl, string2613___dsssl, dsssl_args_32_5, string2597___dsssl, BINT(((long)7610)));
}
 else {
{
obj_t arg1347_618;
{
obj_t pair_980;
if(PAIRP(args_614)){
pair_980 = args_614;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_614, string2558___dsssl, BINT(((long)8187)));
exit( -1 );}
{
obj_t arg1529_981;
arg1529_981 = CDR(pair_980);
{
obj_t pair_983;
if(PAIRP(arg1529_981)){
pair_983 = arg1529_981;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, arg1529_981, string2614___dsssl, BINT(((long)8533)));
exit( -1 );}
arg1347_618 = CDR(pair_983);
}
}
}
{
obj_t args_3194;
args_3194 = arg1347_618;
args_614 = args_3194;
goto loop_615;
}
}
}
}
}
 else {
obj_t args_624;
args_624 = dsssl_args_32_5;
loop_625:
if(NULLP(args_624)){
aux1564_1151 = BTRUE;
}
 else {
bool_t test1354_627;
{
bool_t test1356_629;
test1356_629 = PAIRP(args_624);
if(test1356_629){
bool_t test1357_630;
{
obj_t arg1364_635;
{
obj_t pair_986;
if(test1356_629){
pair_986 = args_624;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_624, string2558___dsssl, BINT(((long)8321)));
exit( -1 );}
arg1364_635 = CDR(pair_986);
}
test1357_630 = NULLP(arg1364_635);
}
if(test1357_630){
test1354_627 = ((bool_t)1);
}
 else {
bool_t test1358_631;
{
obj_t arg1363_634;
{
obj_t pair_988;
if(test1356_629){
pair_988 = args_624;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_624, string2558___dsssl, BINT(((long)8352)));
exit( -1 );}
arg1363_634 = CAR(pair_988);
}
test1358_631 = KEYWORDP(arg1363_634);
}
if(test1358_631){
bool_t test1359_632;
{
obj_t arg1361_633;
{
obj_t pair_990;
if(test1356_629){
pair_990 = args_624;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_624, string2558___dsssl, BINT(((long)8380)));
exit( -1 );}
arg1361_633 = CAR(pair_990);
}
{
obj_t aux_3218;
aux_3218 = memq___r4_pairs_and_lists_6_3(arg1361_633, key_list_141_6);
test1359_632 = CBOOL(aux_3218);
}
}
if(test1359_632){
test1354_627 = ((bool_t)0);
}
 else {
test1354_627 = ((bool_t)1);
}
}
 else {
test1354_627 = ((bool_t)1);
}
}
}
 else {
test1354_627 = ((bool_t)1);
}
}
if(test1354_627){
aux1564_1151 = debug_error_location_199___error(string2612___dsssl, string2613___dsssl, dsssl_args_32_5, string2597___dsssl, BINT(((long)7610)));
}
 else {
{
obj_t arg1355_628;
{
obj_t pair_994;
if(PAIRP(args_624)){
pair_994 = args_624;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, args_624, string2558___dsssl, BINT(((long)8520)));
exit( -1 );}
{
obj_t arg1529_995;
arg1529_995 = CDR(pair_994);
{
obj_t pair_997;
if(PAIRP(arg1529_995)){
pair_997 = arg1529_995;
}
 else {
bigloo_type_error_location_103___error(symbol2591___dsssl, string2560___dsssl, arg1529_995, string2614___dsssl, BINT(((long)8533)));
exit( -1 );}
arg1355_628 = CDR(pair_997);
}
}
}
{
obj_t args_3237;
args_3237 = arg1355_628;
args_624 = args_3237;
goto loop_625;
}
}
}
}
}
POP_TRACE();
return aux1564_1151;
}
}
}
}


/* _dsssl-check-key-args! */obj_t _dsssl_check_key_args__61___dsssl(obj_t env_1221, obj_t dsssl_args_32_1222, obj_t key_list_141_1223)
{
return dsssl_check_key_args__153___dsssl(dsssl_args_32_1222, key_list_141_1223);
}


/* dsssl-get-key-arg */obj_t dsssl_get_key_arg_157___dsssl(obj_t dsssl_args_32_7, obj_t keyword_8, obj_t initializer_9)
{
{
obj_t symbol1567_1152;
symbol1567_1152 = symbol2581___dsssl;
{
PUSH_TRACE(symbol1567_1152);
BUNSPEC;
{
obj_t aux1566_1153;
{
obj_t args_999;
args_999 = dsssl_args_32_7;
loop_998:
if(NULLP(args_999)){
aux1566_1153 = initializer_9;
}
 else {
bool_t test1366_1001;
{
obj_t arg1368_1002;
{
obj_t pair_1005;
if(PAIRP(args_999)){
pair_1005 = args_999;
}
 else {
bigloo_type_error_location_103___error(symbol2581___dsssl, string2560___dsssl, args_999, string2558___dsssl, BINT(((long)9130)));
exit( -1 );}
arg1368_1002 = CAR(pair_1005);
}
test1366_1001 = (arg1368_1002==keyword_8);
}
if(test1366_1001){
{
obj_t pair_1008;
if(PAIRP(args_999)){
pair_1008 = args_999;
}
 else {
bigloo_type_error_location_103___error(symbol2581___dsssl, string2560___dsssl, args_999, string2558___dsssl, BINT(((long)9153)));
exit( -1 );}
{
obj_t arg1531_1009;
arg1531_1009 = CDR(pair_1008);
{
obj_t pair_1011;
if(PAIRP(arg1531_1009)){
pair_1011 = arg1531_1009;
}
 else {
bigloo_type_error_location_103___error(symbol2581___dsssl, string2560___dsssl, arg1531_1009, string2614___dsssl, BINT(((long)7991)));
exit( -1 );}
aux1566_1153 = CAR(pair_1011);
}
}
}
}
 else {
{
obj_t arg1367_1003;
{
obj_t pair_1012;
if(PAIRP(args_999)){
pair_1012 = args_999;
}
 else {
bigloo_type_error_location_103___error(symbol2581___dsssl, string2560___dsssl, args_999, string2558___dsssl, BINT(((long)9183)));
exit( -1 );}
{
obj_t arg1529_1013;
arg1529_1013 = CDR(pair_1012);
{
obj_t pair_1015;
if(PAIRP(arg1529_1013)){
pair_1015 = arg1529_1013;
}
 else {
bigloo_type_error_location_103___error(symbol2581___dsssl, string2560___dsssl, arg1529_1013, string2614___dsssl, BINT(((long)8533)));
exit( -1 );}
arg1367_1003 = CDR(pair_1015);
}
}
}
{
obj_t args_3275;
args_3275 = arg1367_1003;
args_999 = args_3275;
goto loop_998;
}
}
}
}
}
POP_TRACE();
return aux1566_1153;
}
}
}
}


/* _dsssl-get-key-arg1577 */obj_t _dsssl_get_key_arg1577_91___dsssl(obj_t env_1224, obj_t dsssl_args_32_1225, obj_t keyword_1226, obj_t initializer_1227)
{
{
obj_t aux_3277;
if(KEYWORDP(keyword_1226)){
aux_3277 = keyword_1226;
}
 else {
bigloo_type_error_location_103___error(symbol2615___dsssl, string2616___dsssl, keyword_1226, string2558___dsssl, BINT(((long)8985)));
exit( -1 );}
return dsssl_get_key_arg_157___dsssl(dsssl_args_32_1225, aux_3277, initializer_1227);
}
}


/* id-sans-type */obj_t id_sans_type_130___dsssl(obj_t id_10)
{
{
obj_t symbol1569_1154;
symbol1569_1154 = symbol2617___dsssl;
{
PUSH_TRACE(symbol1569_1154);
BUNSPEC;
{
obj_t aux1568_1155;
{
obj_t string_642;
string_642 = SYMBOL_TO_STRING(id_10);
{
long len_643;
len_643 = STRING_LENGTH(string_642);
{
{
long walker_644;
walker_644 = ((long)0);
loop_645:
if((walker_644==len_643)){
aux1568_1155 = id_10;
}
 else {
bool_t test1370_647;
{
bool_t test1374_650;
{
unsigned char arg1383_655;
{
unsigned char res1559_1028;
{
bool_t test_3289;
{
long aux_3290;
aux_3290 = STRING_LENGTH(string_642);
test_3289 = BOUND_CHECK(walker_644, aux_3290);
}
if(test_3289){
res1559_1028 = STRING_REF(string_642, walker_644);
}
 else {
obj_t aux_3294;
{
obj_t aux2393_1992;
aux2393_1992 = debug_error_location_199___error(string2618___dsssl, string2619___dsssl, BINT(walker_644), string2597___dsssl, BINT(((long)7610)));
if(CHARP(aux2393_1992)){
aux_3294 = aux2393_1992;
}
 else {
bigloo_type_error_location_103___error(symbol2617___dsssl, string2620___dsssl, aux2393_1992, string2597___dsssl, BINT(((long)7610)));
exit( -1 );}
}
res1559_1028 = (unsigned char)CCHAR(aux_3294);
}
}
arg1383_655 = res1559_1028;
}
test1374_650 = (arg1383_655==((unsigned char)':'));
}
if(test1374_650){
bool_t test_3306;
{
long aux_3307;
aux_3307 = (len_643-((long)1));
test_3306 = (walker_644<aux_3307);
}
if(test_3306){
unsigned char arg1378_652;
{
long arg1379_653;
arg1379_653 = (walker_644+((long)1));
{
unsigned char res1560_1045;
{
bool_t test_3311;
{
long aux_3312;
aux_3312 = STRING_LENGTH(string_642);
test_3311 = BOUND_CHECK(arg1379_653, aux_3312);
}
if(test_3311){
res1560_1045 = STRING_REF(string_642, arg1379_653);
}
 else {
obj_t aux_3316;
{
obj_t aux2402_1998;
aux2402_1998 = debug_error_location_199___error(string2618___dsssl, string2619___dsssl, BINT(arg1379_653), string2597___dsssl, BINT(((long)7610)));
if(CHARP(aux2402_1998)){
aux_3316 = aux2402_1998;
}
 else {
bigloo_type_error_location_103___error(symbol2617___dsssl, string2620___dsssl, aux2402_1998, string2597___dsssl, BINT(((long)7610)));
exit( -1 );}
}
res1560_1045 = (unsigned char)CCHAR(aux_3316);
}
}
arg1378_652 = res1560_1045;
}
}
test1370_647 = (arg1378_652==((unsigned char)':'));
}
 else {
test1370_647 = ((bool_t)0);
}
}
 else {
test1370_647 = ((bool_t)0);
}
}
if(test1370_647){
{
obj_t arg1372_648;
{
obj_t res1561_1076;
{
bool_t test_3328;
if((walker_644>=((long)0))){
bool_t test_3331;
{
long aux_3332;
{
long aux_3333;
aux_3333 = STRING_LENGTH(string_642);
aux_3332 = (aux_3333+((long)1));
}
test_3331 = BOUND_CHECK(((long)0), aux_3332);
}
if(test_3331){
long aux_3337;
{
long aux_3338;
aux_3338 = STRING_LENGTH(string_642);
aux_3337 = (aux_3338+((long)1));
}
test_3328 = BOUND_CHECK(walker_644, aux_3337);
}
 else {
test_3328 = ((bool_t)0);
}
}
 else {
test_3328 = ((bool_t)0);
}
if(test_3328){
res1561_1076 = c_substring(string_642, ((long)0), walker_644);
}
 else {
obj_t arg1426_1062;
{
obj_t aux_3345;
obj_t aux_3343;
aux_3345 = BINT(walker_644);
aux_3343 = BINT(((long)0));
arg1426_1062 = MAKE_PAIR(aux_3343, aux_3345);
}
{
obj_t aux2408_2004;
aux2408_2004 = debug_error_location_199___error(string2621___dsssl, string2622___dsssl, arg1426_1062, string2597___dsssl, BINT(((long)7610)));
if(STRINGP(aux2408_2004)){
res1561_1076 = aux2408_2004;
}
 else {
bigloo_type_error_location_103___error(symbol2617___dsssl, string2623___dsssl, aux2408_2004, string2597___dsssl, BINT(((long)7610)));
exit( -1 );}
}
}
}
arg1372_648 = res1561_1076;
}
{
char * aux_3355;
aux_3355 = BSTRING_TO_STRING(arg1372_648);
aux1568_1155 = string_to_symbol(aux_3355);
}
}
}
 else {
{
long walker_3358;
walker_3358 = (walker_644+((long)1));
walker_644 = walker_3358;
goto loop_645;
}
}
}
}
}
}
}
POP_TRACE();
return aux1568_1155;
}
}
}
}


/* dsssl-formals->scheme-formals */obj_t dsssl_formals__scheme_formals_201___dsssl(obj_t formals_11, obj_t err_12)
{
{
obj_t symbol1571_1156;
symbol1571_1156 = symbol2624___dsssl;
{
PUSH_TRACE(symbol1571_1156);
BUNSPEC;
{
obj_t aux1570_1157;
aux1570_1157 = loop___dsssl(formals_11, err_12, formals_11, ((bool_t)0));
POP_TRACE();
return aux1570_1157;
}
}
}
}


/* loop */obj_t loop___dsssl(obj_t formals_1232, obj_t err_1231, obj_t args_659, bool_t dsssl_660)
{
loop___dsssl:
{
obj_t obj_681;
if(NULLP(args_659)){
return BNIL;
}
 else {
bool_t test1385_663;
test1385_663 = PAIRP(args_659);
if(test1385_663){
bool_t test1386_664;
{
obj_t arg1399_677;
{
obj_t pair_1082;
if(test1385_663){
pair_1082 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)11623)));
exit( -1 );}
arg1399_677 = CAR(pair_1082);
}
test1386_664 = SYMBOLP(arg1399_677);
}
if(test1386_664){
if(dsssl_660){
{
obj_t arg1387_665;
{
obj_t pair_1084;
if(test1385_663){
pair_1084 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)12038)));
exit( -1 );}
arg1387_665 = CAR(pair_1084);
}
{
obj_t aux_3381;
if(SYMBOLP(arg1387_665)){
aux_3381 = arg1387_665;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2583___dsssl, arg1387_665, string2558___dsssl, BINT(((long)12023)));
exit( -1 );}
return id_sans_type_130___dsssl(aux_3381);
}
}
}
 else {
{
obj_t arg1388_666;
obj_t arg1389_667;
{
obj_t arg1390_668;
{
obj_t pair_1085;
if(test1385_663){
pair_1085 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)12082)));
exit( -1 );}
arg1390_668 = CAR(pair_1085);
}
{
obj_t aux_3393;
if(SYMBOLP(arg1390_668)){
aux_3393 = arg1390_668;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2583___dsssl, arg1390_668, string2558___dsssl, BINT(((long)12067)));
exit( -1 );}
arg1388_666 = id_sans_type_130___dsssl(aux_3393);
}
}
{
obj_t arg1391_669;
{
obj_t pair_1086;
if(test1385_663){
pair_1086 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)12102)));
exit( -1 );}
arg1391_669 = CDR(pair_1086);
}
arg1389_667 = loop___dsssl(formals_1232, err_1231, arg1391_669, ((bool_t)0));
}
return MAKE_PAIR(arg1388_666, arg1389_667);
}
}
}
 else {
{
bool_t test1392_670;
{
obj_t arg1398_676;
{
obj_t pair_1089;
if(test1385_663){
pair_1089 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)11675)));
exit( -1 );}
arg1398_676 = CAR(pair_1089);
}
{
obj_t aux_3412;
aux_3412 = memq___r4_pairs_and_lists_6_3(arg1398_676, list2626___dsssl);
test1392_670 = CBOOL(aux_3412);
}
}
if(test1392_670){
{
obj_t arg1393_671;
{
obj_t pair_1092;
if(test1385_663){
pair_1092 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)11700)));
exit( -1 );}
arg1393_671 = CDR(pair_1092);
}
{
bool_t dsssl_3422;
obj_t args_3421;
args_3421 = arg1393_671;
dsssl_3422 = ((bool_t)1);
dsssl_660 = dsssl_3422;
args_659 = args_3421;
goto loop___dsssl;
}
}
}
 else {
if(dsssl_660){
bool_t test1394_672;
{
obj_t arg1397_675;
{
obj_t pair_1093;
if(test1385_663){
pair_1093 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)11834)));
exit( -1 );}
arg1397_675 = CAR(pair_1093);
}
obj_681 = arg1397_675;
{
bool_t test1403_686;
test1403_686 = PAIRP(obj_681);
if(test1403_686){
obj_t cdr_202_127_687;
{
obj_t pair_1100;
if(test1403_686){
pair_1100 = obj_681;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, obj_681, string2558___dsssl, BINT(((long)10953)));
exit( -1 );}
cdr_202_127_687 = CDR(pair_1100);
}
{
bool_t test1404_688;
test1404_688 = PAIRP(cdr_202_127_687);
if(test1404_688){
bool_t test1405_689;
{
obj_t arg1407_690;
{
obj_t pair_1102;
if(test1404_688){
pair_1102 = cdr_202_127_687;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, cdr_202_127_687, string2558___dsssl, BINT(((long)10953)));
exit( -1 );}
arg1407_690 = CDR(pair_1102);
}
test1405_689 = (arg1407_690==BNIL);
}
if(test1405_689){
test1394_672 = ((bool_t)1);
}
 else {
test1394_672 = ((bool_t)0);
}
}
 else {
test1394_672 = ((bool_t)0);
}
}
}
 else {
test1394_672 = ((bool_t)0);
}
}
}
if(test1394_672){
{
obj_t arg1395_673;
{
obj_t arg1396_674;
{
obj_t pair_1094;
if(test1385_663){
pair_1094 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, args_659, string2558___dsssl, BINT(((long)11889)));
exit( -1 );}
arg1396_674 = CAR(pair_1094);
}
{
obj_t pair_1096;
if(PAIRP(arg1396_674)){
pair_1096 = arg1396_674;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2560___dsssl, arg1396_674, string2558___dsssl, BINT(((long)11238)));
exit( -1 );}
arg1395_673 = CAR(pair_1096);
}
}
{
obj_t aux_3457;
if(SYMBOLP(arg1395_673)){
aux_3457 = arg1395_673;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2583___dsssl, arg1395_673, string2558___dsssl, BINT(((long)11852)));
exit( -1 );}
return id_sans_type_130___dsssl(aux_3457);
}
}
}
 else {
{
bool_t test2507_2101;
test2507_2101 = PROCEDURE_CORRECT_ARITYP(err_1231, ((long)3));
if(test2507_2101){
return PROCEDURE_ENTRY(err_1231)(err_1231, string2627___dsssl, string2628___dsssl, formals_1232, BEOA);
}
 else {
error_location_112___error(string2629___dsssl, list2630___dsssl, err_1231, string2558___dsssl, BINT(((long)11921)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
 else {
{
bool_t test2516_2109;
test2516_2109 = PROCEDURE_CORRECT_ARITYP(err_1231, ((long)3));
if(test2516_2109){
return PROCEDURE_ENTRY(err_1231)(err_1231, string2627___dsssl, string2631___dsssl, formals_1232, BEOA);
}
 else {
error_location_112___error(string2629___dsssl, list2632___dsssl, err_1231, string2558___dsssl, BINT(((long)11741)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
}
 else {
if(dsssl_660){
{
bool_t test2524_2117;
test2524_2117 = PROCEDURE_CORRECT_ARITYP(err_1231, ((long)3));
if(test2524_2117){
return PROCEDURE_ENTRY(err_1231)(err_1231, string2633___dsssl, string2634___dsssl, formals_1232, BEOA);
}
 else {
error_location_112___error(string2629___dsssl, list2635___dsssl, err_1231, string2558___dsssl, BINT(((long)11386)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
 else {
bool_t test1400_678;
test1400_678 = SYMBOLP(args_659);
if(test1400_678){
{
obj_t aux_3488;
if(test1400_678){
aux_3488 = args_659;
}
 else {
bigloo_type_error_location_103___error(symbol2625___dsssl, string2583___dsssl, args_659, string2558___dsssl, BINT(((long)11583)));
exit( -1 );}
return id_sans_type_130___dsssl(aux_3488);
}
}
 else {
{
bool_t test2537_2131;
test2537_2131 = PROCEDURE_CORRECT_ARITYP(err_1231, ((long)3));
if(test2537_2131){
return PROCEDURE_ENTRY(err_1231)(err_1231, string2627___dsssl, string2631___dsssl, formals_1232, BEOA);
}
 else {
error_location_112___error(string2629___dsssl, list2632___dsssl, err_1231, string2558___dsssl, BINT(((long)11503)));
FAILURE(symbol2559___dsssl,symbol2559___dsssl,symbol2559___dsssl);}
}
}
}
}
}
}
}


/* _dsssl-formals->scheme-formals1578 */obj_t _dsssl_formals__scheme_formals1578_11___dsssl(obj_t env_1228, obj_t formals_1229, obj_t err_1230)
{
{
obj_t aux_3501;
if(PROCEDUREP(err_1230)){
aux_3501 = err_1230;
}
 else {
bigloo_type_error_location_103___error(symbol2636___dsssl, string2562___dsssl, err_1230, string2558___dsssl, BINT(((long)10953)));
exit( -1 );}
return dsssl_formals__scheme_formals_201___dsssl(formals_1229, aux_3501);
}
}


/* symbol->keyword */obj_t symbol__keyword_174___dsssl(obj_t symbol_13)
{
{
obj_t symbol1573_1158;
symbol1573_1158 = symbol2637___dsssl;
{
PUSH_TRACE(symbol1573_1158);
BUNSPEC;
{
obj_t aux1572_1159;
{
obj_t arg1411_1106;
{
obj_t arg1413_1107;
{
obj_t symbol_1109;
if(SYMBOLP(symbol_13)){
symbol_1109 = symbol_13;
}
 else {
bigloo_type_error_location_103___error(symbol2637___dsssl, string2583___dsssl, symbol_13, string2558___dsssl, BINT(((long)12416)));
exit( -1 );}
arg1413_1107 = SYMBOL_TO_STRING(symbol_1109);
}
arg1411_1106 = string_append(arg1413_1107, string2584___dsssl);
}
{
char * aux_3516;
aux_3516 = BSTRING_TO_STRING(arg1411_1106);
aux1572_1159 = string_to_keyword(aux_3516);
}
}
POP_TRACE();
return aux1572_1159;
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___dsssl()
{
{
obj_t symbol1575_1160;
symbol1575_1160 = symbol2638___dsssl;
{
PUSH_TRACE(symbol1575_1160);
BUNSPEC;
{
obj_t aux1574_1161;
aux1574_1161 = module_initialization_70___error(((long)0), "__DSSSL");
POP_TRACE();
return aux1574_1161;
}
}
}
}

