/*===========================================================================*/
/*   (Cfa/app.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_app();
extern approx_t cfa_intern_sfun__162_cfa_iterate(intern_sfun_cinfo_192_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t cfun_cinfo_200_cfa_info;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _app__default2095_167_cfa_app(obj_t, obj_t, obj_t, obj_t);
extern obj_t intern_sfun_cinfo_192_cfa_info;
extern obj_t module_initialization_70_cfa_app(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
static obj_t cfa__app_90_cfa_app(obj_t, obj_t);
static approx_t app__default2095_225_cfa_app(fun_t, var_t, obj_t);
static obj_t _app_2413_237_cfa_app(obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_cfa_app();
extern obj_t extern_sfun_cinfo_6_cfa_info;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cfa_app();
extern approx_t cfa__102_cfa_cfa(node_t);
static obj_t toplevel_init_63_cfa_app();
extern obj_t open_input_string(obj_t);
extern approx_t app__231_cfa_app(fun_t, var_t, obj_t);
static obj_t _cfa_2412_103_cfa_cfa(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_cfa_app = BUNSPEC;
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
static obj_t cnst_init_137_cfa_app();
static obj_t __cnst[1];

DEFINE_STATIC_PROCEDURE(app__default2095_env_118_cfa_app, _app__default2095_167_cfa_app2423, _app__default2095_167_cfa_app, 0L, 3);
DEFINE_STATIC_PROCEDURE(proc2414_cfa_app, cfa__app_90_cfa_app2424, cfa__app_90_cfa_app, 0L, 1);
extern obj_t cfa__env_153_cfa_cfa;
DEFINE_STRING(string2417_cfa_app, string2417_cfa_app2425, "ALL ", 4);
DEFINE_STRING(string2416_cfa_app, string2416_cfa_app2426, "No method for this function", 27);
DEFINE_STRING(string2415_cfa_app, string2415_cfa_app2427, "app!", 4);
DEFINE_EXPORT_GENERIC(app__env_198_cfa_app, _app_2413_237_cfa_app2428, _app_2413_237_cfa_app, 0L, 3);


/* module-initialization */ obj_t 
module_initialization_70_cfa_app(long checksum_3393, char *from_3394)
{
   if (CBOOL(require_initialization_114_cfa_app))
     {
	require_initialization_114_cfa_app = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_app();
	cnst_init_137_cfa_app();
	imported_modules_init_94_cfa_app();
	method_init_76_cfa_app();
	toplevel_init_63_cfa_app();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_app()
{
   module_initialization_70___object(((long) 0), "CFA_APP");
   module_initialization_70___reader(((long) 0), "CFA_APP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_app()
{
   {
      obj_t cnst_port_138_3385;
      cnst_port_138_3385 = open_input_string(string2417_cfa_app);
      {
	 long i_3386;
	 i_3386 = ((long) 0);
       loop_3387:
	 {
	    bool_t test2418_3388;
	    test2418_3388 = (i_3386 == ((long) -1));
	    if (test2418_3388)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2419_3389;
		    {
		       obj_t list2420_3390;
		       {
			  obj_t arg2421_3391;
			  arg2421_3391 = BNIL;
			  list2420_3390 = MAKE_PAIR(cnst_port_138_3385, arg2421_3391);
		       }
		       arg2419_3389 = read___reader(list2420_3390);
		    }
		    CNST_TABLE_SET(i_3386, arg2419_3389);
		 }
		 {
		    int aux_3392;
		    {
		       long aux_3411;
		       aux_3411 = (i_3386 - ((long) 1));
		       aux_3392 = (int) (aux_3411);
		    }
		    {
		       long i_3414;
		       i_3414 = (long) (aux_3392);
		       i_3386 = i_3414;
		       goto loop_3387;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_app()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_cfa_app()
{
   {
      obj_t cfa__app_90_3372;
      cfa__app_90_3372 = proc2414_cfa_app;
      add_method__1___object(cfa__env_153_cfa_cfa, app_ast_node, cfa__app_90_3372);
   }
   add_generic__110___object(app__env_198_cfa_app, app__default2095_env_118_cfa_app);
   add_inlined_method__244___object(app__env_198_cfa_app, intern_sfun_cinfo_192_cfa_info, ((long) 0));
   add_inlined_method__244___object(app__env_198_cfa_app, extern_sfun_cinfo_6_cfa_info, ((long) 1));
   {
      long aux_3420;
      aux_3420 = add_inlined_method__244___object(app__env_198_cfa_app, cfun_cinfo_200_cfa_info, ((long) 2));
      return BINT(aux_3420);
   }
}


/* cfa!-app */ obj_t 
cfa__app_90_cfa_app(obj_t env_3373, obj_t node_3374)
{
   {
      app_t node_2866;
      {
	 approx_t aux_3423;
	 node_2866 = (app_t) (node_3374);
	 {
	    value_t arg2351_2870;
	    var_t arg2352_2871;
	    obj_t arg2353_2872;
	    {
	       variable_t arg2354_2873;
	       {
		  var_t arg2355_2874;
		  arg2355_2874 = (((app_t) CREF(node_2866))->fun);
		  arg2354_2873 = (((var_t) CREF(arg2355_2874))->variable);
	       }
	       arg2351_2870 = (((variable_t) CREF(arg2354_2873))->value);
	    }
	    arg2352_2871 = (((app_t) CREF(node_2866))->fun);
	    {
	       obj_t l2078_2875;
	       l2078_2875 = (((app_t) CREF(node_2866))->args);
	       if (NULLP(l2078_2875))
		 {
		    arg2353_2872 = BNIL;
		 }
	       else
		 {
		    obj_t head2080_2877;
		    {
		       approx_t arg2364_2888;
		       {
			  node_t aux_3431;
			  {
			     obj_t aux_3432;
			     aux_3432 = CAR(l2078_2875);
			     aux_3431 = (node_t) (aux_3432);
			  }
			  arg2364_2888 = cfa__102_cfa_cfa(aux_3431);
		       }
		       {
			  obj_t aux_3436;
			  aux_3436 = (obj_t) (arg2364_2888);
			  head2080_2877 = MAKE_PAIR(aux_3436, BNIL);
		       }
		    }
		    {
		       obj_t l2078_2878;
		       obj_t tail2081_2879;
		       l2078_2878 = CDR(l2078_2875);
		       tail2081_2879 = head2080_2877;
		     lname2079_2880:
		       if (NULLP(l2078_2878))
			 {
			    arg2353_2872 = head2080_2877;
			 }
		       else
			 {
			    obj_t newtail2082_2883;
			    {
			       approx_t arg2360_2885;
			       {
				  node_t aux_3441;
				  {
				     obj_t aux_3442;
				     aux_3442 = CAR(l2078_2878);
				     aux_3441 = (node_t) (aux_3442);
				  }
				  arg2360_2885 = cfa__102_cfa_cfa(aux_3441);
			       }
			       {
				  obj_t aux_3446;
				  aux_3446 = (obj_t) (arg2360_2885);
				  newtail2082_2883 = MAKE_PAIR(aux_3446, BNIL);
			       }
			    }
			    SET_CDR(tail2081_2879, newtail2082_2883);
			    {
			       obj_t tail2081_3452;
			       obj_t l2078_3450;
			       l2078_3450 = CDR(l2078_2878);
			       tail2081_3452 = newtail2082_2883;
			       tail2081_2879 = tail2081_3452;
			       l2078_2878 = l2078_3450;
			       goto lname2079_2880;
			    }
			 }
		    }
		 }
	    }
	    aux_3423 = app__231_cfa_app((fun_t) (arg2351_2870), arg2352_2871, arg2353_2872);
	 }
	 return (obj_t) (aux_3423);
      }
   }
}


/* app! */ approx_t 
app__231_cfa_app(fun_t fun_2, var_t var_3, obj_t args_approx_137_4)
{
   {
      obj_t method2373_2901;
      obj_t class2378_2902;
      {
	 obj_t arg2381_2899;
	 obj_t arg2383_2900;
	 {
	    object_t obj_3319;
	    obj_3319 = (object_t) (fun_2);
	    {
	       obj_t pre_method_105_3320;
	       pre_method_105_3320 = PROCEDURE_REF(app__env_198_cfa_app, ((long) 2));
	       if (INTEGERP(pre_method_105_3320))
		 {
		    PROCEDURE_SET(app__env_198_cfa_app, ((long) 2), BUNSPEC);
		    arg2381_2899 = pre_method_105_3320;
		 }
	       else
		 {
		    long obj_class_num_177_3325;
		    obj_class_num_177_3325 = TYPE(obj_3319);
		    {
		       obj_t arg1177_3326;
		       arg1177_3326 = PROCEDURE_REF(app__env_198_cfa_app, ((long) 1));
		       {
			  long arg1178_3330;
			  {
			     long arg1179_3331;
			     arg1179_3331 = OBJECT_TYPE;
			     arg1178_3330 = (obj_class_num_177_3325 - arg1179_3331);
			  }
			  arg2381_2899 = VECTOR_REF(arg1177_3326, arg1178_3330);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3336;
	    object_3336 = (object_t) (fun_2);
	    {
	       long arg1180_3337;
	       {
		  long arg1181_3338;
		  long arg1182_3339;
		  arg1181_3338 = TYPE(object_3336);
		  arg1182_3339 = OBJECT_TYPE;
		  arg1180_3337 = (arg1181_3338 - arg1182_3339);
	       }
	       {
		  obj_t vector_3343;
		  vector_3343 = _classes__134___object;
		  arg2383_2900 = VECTOR_REF(vector_3343, arg1180_3337);
	       }
	    }
	 }
	 {
	    obj_t aux_3473;
	    method2373_2901 = arg2381_2899;
	    class2378_2902 = arg2383_2900;
	    {
	       if (INTEGERP(method2373_2901))
		 {
		    switch ((long) CINT(method2373_2901))
		      {
		      case ((long) 0):
			 {
			    intern_sfun_cinfo_192_t fun_2908;
			    fun_2908 = (intern_sfun_cinfo_192_t) (fun_2);
			    {
			       obj_t ll2084_2912;
			       obj_t ll2085_2913;
			       {
				  sfun_t obj_3345;
				  obj_3345 = (sfun_t) (fun_2908);
				  ll2084_2912 = (((sfun_t) CREF(obj_3345))->args);
			       }
			       ll2085_2913 = args_approx_137_4;
			     lname2086_2914:
			       if (NULLP(ll2084_2912))
				 {
				    ((bool_t) 1);
				 }
			       else
				 {
				    {
				       approx_t aux_3491;
				       approx_t aux_3479;
				       {
					  obj_t aux_3492;
					  aux_3492 = CAR(ll2085_2913);
					  aux_3491 = (approx_t) (aux_3492);
				       }
				       {
					  svar_cinfo_166_t obj_3350;
					  {
					     value_t aux_3480;
					     {
						local_t obj_3349;
						{
						   obj_t aux_3481;
						   aux_3481 = CAR(ll2084_2912);
						   obj_3349 = (local_t) (aux_3481);
						}
						aux_3480 = (((local_t) CREF(obj_3349))->value);
					     }
					     obj_3350 = (svar_cinfo_166_t) (aux_3480);
					  }
					  {
					     obj_t aux_3486;
					     {
						object_t aux_3487;
						aux_3487 = (object_t) (obj_3350);
						aux_3486 = OBJECT_WIDENING(aux_3487);
					     }
					     aux_3479 = (((svar_cinfo_166_t) CREF(aux_3486))->approx);
					  }
				       }
				       union_approx__241_cfa_approx(aux_3479, aux_3491);
				    }
				    {
				       obj_t ll2085_3498;
				       obj_t ll2084_3496;
				       ll2084_3496 = CDR(ll2084_2912);
				       ll2085_3498 = CDR(ll2085_2913);
				       ll2085_2913 = ll2085_3498;
				       ll2084_2912 = ll2084_3496;
				       goto lname2086_2914;
				    }
				 }
			    }
			    {
			       approx_t aux_3502;
			       {
				  obj_t aux_3503;
				  {
				     variable_t aux_3504;
				     aux_3504 = (((var_t) CREF(var_3))->variable);
				     aux_3503 = (obj_t) (aux_3504);
				  }
				  aux_3502 = cfa_intern_sfun__162_cfa_iterate(fun_2908, aux_3503);
			       }
			       aux_3473 = (obj_t) (aux_3502);
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    extern_sfun_cinfo_6_t fun_2924;
			    fun_2924 = (extern_sfun_cinfo_6_t) (fun_2);
			    {
			       bool_t test_3510;
			       {
				  sfun_t obj_3354;
				  obj_3354 = (sfun_t) (fun_2924);
				  test_3510 = (((sfun_t) CREF(obj_3354))->top__138);
			       }
			       if (test_3510)
				 {
				    obj_t l2088_2929;
				    {
				       bool_t aux_3513;
				       l2088_2929 = args_approx_137_4;
				     lname2089_2930:
				       if (PAIRP(l2088_2929))
					 {
					    {
					       approx_t aux_3516;
					       {
						  obj_t aux_3517;
						  aux_3517 = CAR(l2088_2929);
						  aux_3516 = (approx_t) (aux_3517);
					       }
					       loose__226_cfa_loose(aux_3516, CNST_TABLE_REF(((long) 0)));
					    }
					    {
					       obj_t l2088_3522;
					       l2088_3522 = CDR(l2088_2929);
					       l2088_2929 = l2088_3522;
					       goto lname2089_2930;
					    }
					 }
				       else
					 {
					    aux_3513 = ((bool_t) 1);
					 }
				       BBOOL(aux_3513);
				    }
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       approx_t aux_3525;
			       {
				  obj_t aux_3526;
				  {
				     object_t aux_3527;
				     aux_3527 = (object_t) (fun_2924);
				     aux_3526 = OBJECT_WIDENING(aux_3527);
				  }
				  aux_3525 = (((extern_sfun_cinfo_6_t) CREF(aux_3526))->approx);
			       }
			       aux_3473 = (obj_t) (aux_3525);
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    cfun_cinfo_200_t fun_2935;
			    fun_2935 = (cfun_cinfo_200_t) (fun_2);
			    {
			       bool_t test_3533;
			       {
				  cfun_t obj_3359;
				  obj_3359 = (cfun_t) (fun_2935);
				  test_3533 = (((cfun_t) CREF(obj_3359))->top__138);
			       }
			       if (test_3533)
				 {
				    obj_t l2091_2940;
				    {
				       bool_t aux_3536;
				       l2091_2940 = args_approx_137_4;
				     lname2092_2941:
				       if (PAIRP(l2091_2940))
					 {
					    {
					       approx_t aux_3539;
					       {
						  obj_t aux_3540;
						  aux_3540 = CAR(l2091_2940);
						  aux_3539 = (approx_t) (aux_3540);
					       }
					       loose__226_cfa_loose(aux_3539, CNST_TABLE_REF(((long) 0)));
					    }
					    {
					       obj_t l2091_3545;
					       l2091_3545 = CDR(l2091_2940);
					       l2091_2940 = l2091_3545;
					       goto lname2092_2941;
					    }
					 }
				       else
					 {
					    aux_3536 = ((bool_t) 1);
					 }
				       BBOOL(aux_3536);
				    }
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       approx_t aux_3548;
			       {
				  obj_t aux_3549;
				  {
				     object_t aux_3550;
				     aux_3550 = (object_t) (fun_2935);
				     aux_3549 = OBJECT_WIDENING(aux_3550);
				  }
				  aux_3548 = (((cfun_cinfo_200_t) CREF(aux_3549))->approx);
			       }
			       aux_3473 = (obj_t) (aux_3548);
			    }
			 }
			 break;
		      default:
		       case_else2379_2905:
			 if (PROCEDUREP(method2373_2901))
			   {
			      aux_3473 = PROCEDURE_ENTRY(method2373_2901) (method2373_2901, (obj_t) (fun_2), (obj_t) (var_3), args_approx_137_4, BEOA);
			   }
			 else
			   {
			      obj_t fun2368_2893;
			      fun2368_2893 = PROCEDURE_REF(app__env_198_cfa_app, ((long) 0));
			      aux_3473 = PROCEDURE_ENTRY(fun2368_2893) (fun2368_2893, (obj_t) (fun_2), (obj_t) (var_3), args_approx_137_4, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else2379_2905;
		 }
	    }
	    return (approx_t) (aux_3473);
	 }
      }
   }
}


/* _app!2413 */ obj_t 
_app_2413_237_cfa_app(obj_t env_3377, obj_t fun_3378, obj_t var_3379, obj_t args_approx_137_3380)
{
   {
      approx_t aux_3569;
      aux_3569 = app__231_cfa_app((fun_t) (fun_3378), (var_t) (var_3379), args_approx_137_3380);
      return (obj_t) (aux_3569);
   }
}


/* app!-default2095 */ approx_t 
app__default2095_225_cfa_app(fun_t fun_5, var_t var_6, obj_t args_approx_137_7)
{
   {
      obj_t arg2371_3368;
      {
	 obj_t arg2372_3369;
	 arg2372_3369 = shape_tools_shape((obj_t) (var_6));
	 {
	    obj_t aux_3576;
	    aux_3576 = (obj_t) (fun_5);
	    arg2371_3368 = MAKE_PAIR(aux_3576, arg2372_3369);
	 }
      }
      {
	 obj_t aux_3579;
	 aux_3579 = internal_error_43_tools_error(string2415_cfa_app, string2416_cfa_app, arg2371_3368);
	 return (approx_t) (aux_3579);
      }
   }
}


/* _app!-default2095 */ obj_t 
_app__default2095_167_cfa_app(obj_t env_3381, obj_t fun_3382, obj_t var_3383, obj_t args_approx_137_3384)
{
   {
      approx_t aux_3582;
      aux_3582 = app__default2095_225_cfa_app((fun_t) (fun_3382), (var_t) (var_3383), args_approx_137_3384);
      return (obj_t) (aux_3582);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_app()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_APP");
   module_initialization_70_tools_shape(((long) 0), "CFA_APP");
   module_initialization_70_tools_error(((long) 0), "CFA_APP");
   module_initialization_70_type_type(((long) 0), "CFA_APP");
   module_initialization_70_ast_var(((long) 0), "CFA_APP");
   module_initialization_70_ast_node(((long) 0), "CFA_APP");
   module_initialization_70_cfa_info(((long) 0), "CFA_APP");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_APP");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_APP");
   module_initialization_70_cfa_loose(((long) 0), "CFA_APP");
   return module_initialization_70_cfa_approx(((long) 0), "CFA_APP");
}
