/*===========================================================================*/
/*   (Ieee/fixnum.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _positivefx_1288_189___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t ___fx1286_114___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _gcd___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t _remainder1301___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern obj_t make_elong_201___r4_numbers_6_5_fixnum(long);
static obj_t _fixnum__233___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t _negativefx_1289_227___r4_numbers_6_5_fixnum(obj_t, obj_t);
extern char * integer_to_string(long, long);
extern bool_t negativefx__232___r4_numbers_6_5_fixnum(long);
extern bool_t __fx_254___r4_numbers_6_5_fixnum(long, long);
static obj_t __fx1296_197___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t _negfx1298___r4_numbers_6_5_fixnum(obj_t, obj_t);
extern bool_t _fx_24___r4_numbers_6_5_fixnum(long, long);
static obj_t _modulo1302___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern obj_t string__llong_61___r4_numbers_6_5_fixnum(char *, obj_t);
extern bool_t zerofx__17___r4_numbers_6_5_fixnum(long);
extern bool_t even__46___r4_numbers_6_5_fixnum(long);
extern bool_t _fx_134___r4_numbers_6_5_fixnum(long, long);
extern bool_t _fx_179___r4_numbers_6_5_fixnum(long, long);
extern bool_t positivefx__200___r4_numbers_6_5_fixnum(long);
static obj_t __fx1283_61___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern bool_t fixnum__102___r4_numbers_6_5_fixnum(obj_t);
static obj_t __fx1284_67___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern long maxfx___r4_numbers_6_5_fixnum(long, obj_t);
extern char * integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _absfx1299___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t _integer__27___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t _even_1291_120___r4_numbers_6_5_fixnum(obj_t, obj_t);
extern long negfx___r4_numbers_6_5_fixnum(long);
static obj_t _quotient1300___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _maxfx1292___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern bool_t integer__108___r4_numbers_6_5_fixnum(obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t elong__154___r4_numbers_6_5_fixnum(obj_t);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _string__llong1306_59___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern obj_t string__elong_120___r4_numbers_6_5_fixnum(char *, obj_t);
extern long absfx___r4_numbers_6_5_fixnum(long);
static obj_t _integer__string1303_238___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern long lcm___r4_numbers_6_5_fixnum(obj_t);
static obj_t __fx1294_216___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t __fx1295_84___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern long list_length(obj_t);
extern bool_t llong__230___r4_numbers_6_5_fixnum(obj_t);
static obj_t __fx1297_198___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t _zerofx_1287_127___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t _elong__107___r4_numbers_6_5_fixnum(obj_t, obj_t);
extern long _fx_61___r4_numbers_6_5_fixnum(long, long);
static obj_t symbol1999___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1998___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1997___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1996___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1995___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1994___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1993___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1991___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1989___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1990___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1988___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1987___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1986___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1985___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1984___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1983___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1982___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1981___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1979___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1980___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1978___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1977___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1976___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1975___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1974___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1973___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1972___r4_numbers_6_5_fixnum = BUNSPEC;
extern long string__integer_39___r4_numbers_6_5_fixnum(char *, obj_t);
static obj_t symbol1971___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1968___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1967___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1966___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1965___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol1964___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t __fx1282_241___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t symbol2029___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2030___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2028___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2027___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2026___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2025___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2024___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2023___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2018___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2017___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2016___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2014___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2013___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t _lcm___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t symbol2012___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2011___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2009___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2010___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2008___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2007___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2006___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2005___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2004___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2003___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2002___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2001___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t symbol2000___r4_numbers_6_5_fixnum = BUNSPEC;
extern bool_t odd__202___r4_numbers_6_5_fixnum(long);
static obj_t imported_modules_init_94___r4_numbers_6_5_fixnum();
static obj_t _make_elong1281_145___r4_numbers_6_5_fixnum(obj_t, obj_t);
extern long gcd___r4_numbers_6_5_fixnum(obj_t);
extern long _fx_187___r4_numbers_6_5_fixnum(long, long);
extern long modulo___r4_numbers_6_5_fixnum(long, long);
static obj_t _string__integer1304_123___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t ___fx1285_108___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
extern bool_t __fx_163___r4_numbers_6_5_fixnum(long, long);
extern long minfx___r4_numbers_6_5_fixnum(long, obj_t);
static obj_t _llong__245___r4_numbers_6_5_fixnum(obj_t, obj_t);
static obj_t require_initialization_114___r4_numbers_6_5_fixnum = BUNSPEC;
static obj_t _minfx1293___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t _string__elong1305_12___r4_numbers_6_5_fixnum(obj_t, obj_t, obj_t);
static obj_t _odd_1290_194___r4_numbers_6_5_fixnum(obj_t, obj_t);
static long lcm2___r4_numbers_6_5_fixnum(obj_t, obj_t);
extern long _fx_15___r4_numbers_6_5_fixnum(long, long);
static obj_t cnst_init_137___r4_numbers_6_5_fixnum();
extern long remainder___r4_numbers_6_5_fixnum(long, long);
extern long _fx_145___r4_numbers_6_5_fixnum(long, long);
extern long quotient___r4_numbers_6_5_fixnum(long, long);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( negfx_env_197___r4_numbers_6_5_fixnum, _negfx1298___r4_numbers_6_5_fixnum2032, _negfx1298___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( llong__env_253___r4_numbers_6_5_fixnum, _llong__245___r4_numbers_6_5_fixnum2033, _llong__245___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _fx_env_112___r4_numbers_6_5_fixnum, __fx1283_61___r4_numbers_6_5_fixnum2034, __fx1283_61___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( modulo_env_48___r4_numbers_6_5_fixnum, _modulo1302___r4_numbers_6_5_fixnum2035, _modulo1302___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fx_env_6___r4_numbers_6_5_fixnum, __fx1284_67___r4_numbers_6_5_fixnum2036, __fx1284_67___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( positivefx__env_68___r4_numbers_6_5_fixnum, _positivefx_1288_189___r4_numbers_6_5_fixnum2037, _positivefx_1288_189___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( absfx_env_151___r4_numbers_6_5_fixnum, _absfx1299___r4_numbers_6_5_fixnum2038, _absfx1299___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( even__env_28___r4_numbers_6_5_fixnum, _even_1291_120___r4_numbers_6_5_fixnum2039, _even_1291_120___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( elong__env_58___r4_numbers_6_5_fixnum, _elong__107___r4_numbers_6_5_fixnum2040, _elong__107___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__llong_env_205___r4_numbers_6_5_fixnum, _string__llong1306_59___r4_numbers_6_5_fixnum2041, va_generic_entry, _string__llong1306_59___r4_numbers_6_5_fixnum, -2 );
DEFINE_EXPORT_PROCEDURE( integer__env_26___r4_numbers_6_5_fixnum, _integer__27___r4_numbers_6_5_fixnum2042, _integer__27___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( negativefx__env_96___r4_numbers_6_5_fixnum, _negativefx_1289_227___r4_numbers_6_5_fixnum2043, _negativefx_1289_227___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( gcd_env_113___r4_numbers_6_5_fixnum, _gcd___r4_numbers_6_5_fixnum2044, va_generic_entry, _gcd___r4_numbers_6_5_fixnum, -1 );
DEFINE_EXPORT_PROCEDURE( maxfx_env_127___r4_numbers_6_5_fixnum, _maxfx1292___r4_numbers_6_5_fixnum2045, va_generic_entry, _maxfx1292___r4_numbers_6_5_fixnum, -2 );
DEFINE_EXPORT_PROCEDURE( quotient_env_77___r4_numbers_6_5_fixnum, _quotient1300___r4_numbers_6_5_fixnum2046, _quotient1300___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( zerofx__env_195___r4_numbers_6_5_fixnum, _zerofx_1287_127___r4_numbers_6_5_fixnum2047, _zerofx_1287_127___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( fixnum__env_153___r4_numbers_6_5_fixnum, _fixnum__233___r4_numbers_6_5_fixnum2048, _fixnum__233___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _fx_env_27___r4_numbers_6_5_fixnum, __fx1294_216___r4_numbers_6_5_fixnum2049, __fx1294_216___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fx_env_151___r4_numbers_6_5_fixnum, __fx1295_84___r4_numbers_6_5_fixnum2050, __fx1295_84___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fx_env_205___r4_numbers_6_5_fixnum, __fx1297_198___r4_numbers_6_5_fixnum2051, __fx1297_198___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( remainder_env_228___r4_numbers_6_5_fixnum, _remainder1301___r4_numbers_6_5_fixnum2052, _remainder1301___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( __fx_env_255___r4_numbers_6_5_fixnum, ___fx1285_108___r4_numbers_6_5_fixnum2053, ___fx1285_108___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_STRING( string1992___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum2054, "PAIR", 4 );
DEFINE_EXPORT_PROCEDURE( string__elong_env_192___r4_numbers_6_5_fixnum, _string__elong1305_12___r4_numbers_6_5_fixnum2055, va_generic_entry, _string__elong1305_12___r4_numbers_6_5_fixnum, -2 );
DEFINE_STRING( string1969___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum2056, "LONG", 4 );
DEFINE_STRING( string1970___r4_numbers_6_5_fixnum, string1970___r4_numbers_6_5_fixnum2057, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/fixnum.scm", 59 );
DEFINE_STRING( string2022___r4_numbers_6_5_fixnum, string2022___r4_numbers_6_5_fixnum2058, "STRING", 6 );
DEFINE_STRING( string2021___r4_numbers_6_5_fixnum, string2021___r4_numbers_6_5_fixnum2059, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2019___r4_numbers_6_5_fixnum, string2019___r4_numbers_6_5_fixnum2060, "integer->string", 15 );
DEFINE_STRING( string2020___r4_numbers_6_5_fixnum, string2020___r4_numbers_6_5_fixnum2061, "Illegal radix", 13 );
DEFINE_STRING( string2015___r4_numbers_6_5_fixnum, string2015___r4_numbers_6_5_fixnum2062, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_EXPORT_PROCEDURE( _fx_env_199___r4_numbers_6_5_fixnum, __fx1282_241___r4_numbers_6_5_fixnum2063, __fx1282_241___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( odd__env_69___r4_numbers_6_5_fixnum, _odd_1290_194___r4_numbers_6_5_fixnum2064, _odd_1290_194___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __fx_env_85___r4_numbers_6_5_fixnum, ___fx1286_114___r4_numbers_6_5_fixnum2065, ___fx1286_114___r4_numbers_6_5_fixnum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( integer__string_env_18___r4_numbers_6_5_fixnum, _integer__string1303_238___r4_numbers_6_5_fixnum2066, va_generic_entry, _integer__string1303_238___r4_numbers_6_5_fixnum, -2 );
DEFINE_EXPORT_PROCEDURE( minfx_env_32___r4_numbers_6_5_fixnum, _minfx1293___r4_numbers_6_5_fixnum2067, va_generic_entry, _minfx1293___r4_numbers_6_5_fixnum, -2 );
DEFINE_EXPORT_PROCEDURE( make_elong_env_148___r4_numbers_6_5_fixnum, _make_elong1281_145___r4_numbers_6_5_fixnum2068, _make_elong1281_145___r4_numbers_6_5_fixnum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__integer_env_230___r4_numbers_6_5_fixnum, _string__integer1304_123___r4_numbers_6_5_fixnum2069, va_generic_entry, _string__integer1304_123___r4_numbers_6_5_fixnum, -2 );
DEFINE_EXPORT_PROCEDURE( lcm_env_26___r4_numbers_6_5_fixnum, _lcm___r4_numbers_6_5_fixnum2070, va_generic_entry, _lcm___r4_numbers_6_5_fixnum, -1 );
DEFINE_EXPORT_PROCEDURE( _fx_env_1___r4_numbers_6_5_fixnum, __fx1296_197___r4_numbers_6_5_fixnum2071, __fx1296_197___r4_numbers_6_5_fixnum, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___r4_numbers_6_5_fixnum(long checksum_1560, char * from_1561)
{
if(CBOOL(require_initialization_114___r4_numbers_6_5_fixnum)){
require_initialization_114___r4_numbers_6_5_fixnum = BBOOL(((bool_t)0));
cnst_init_137___r4_numbers_6_5_fixnum();
imported_modules_init_94___r4_numbers_6_5_fixnum();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_numbers_6_5_fixnum()
{
symbol1964___r4_numbers_6_5_fixnum = string_to_symbol("INTEGER?");
symbol1965___r4_numbers_6_5_fixnum = string_to_symbol("ELONG?");
symbol1966___r4_numbers_6_5_fixnum = string_to_symbol("LLONG?");
symbol1967___r4_numbers_6_5_fixnum = string_to_symbol("MAKE-ELONG");
symbol1968___r4_numbers_6_5_fixnum = string_to_symbol("_MAKE-ELONG1281");
symbol1971___r4_numbers_6_5_fixnum = string_to_symbol("=FX");
symbol1972___r4_numbers_6_5_fixnum = string_to_symbol("_=FX1282");
symbol1973___r4_numbers_6_5_fixnum = string_to_symbol("<FX");
symbol1974___r4_numbers_6_5_fixnum = string_to_symbol("_<FX1283");
symbol1975___r4_numbers_6_5_fixnum = string_to_symbol(">FX");
symbol1976___r4_numbers_6_5_fixnum = string_to_symbol("_>FX1284");
symbol1977___r4_numbers_6_5_fixnum = string_to_symbol("<=FX");
symbol1978___r4_numbers_6_5_fixnum = string_to_symbol("_<=FX1285");
symbol1979___r4_numbers_6_5_fixnum = string_to_symbol(">=FX");
symbol1980___r4_numbers_6_5_fixnum = string_to_symbol("_>=FX1286");
symbol1981___r4_numbers_6_5_fixnum = string_to_symbol("ZEROFX?");
symbol1982___r4_numbers_6_5_fixnum = string_to_symbol("_ZEROFX?1287");
symbol1983___r4_numbers_6_5_fixnum = string_to_symbol("POSITIVEFX?");
symbol1984___r4_numbers_6_5_fixnum = string_to_symbol("_POSITIVEFX?1288");
symbol1985___r4_numbers_6_5_fixnum = string_to_symbol("NEGATIVEFX?");
symbol1986___r4_numbers_6_5_fixnum = string_to_symbol("_NEGATIVEFX?1289");
symbol1987___r4_numbers_6_5_fixnum = string_to_symbol("ODD?");
symbol1988___r4_numbers_6_5_fixnum = string_to_symbol("_ODD?1290");
symbol1989___r4_numbers_6_5_fixnum = string_to_symbol("EVEN?");
symbol1990___r4_numbers_6_5_fixnum = string_to_symbol("_EVEN?1291");
symbol1991___r4_numbers_6_5_fixnum = string_to_symbol("MAXFX");
symbol1993___r4_numbers_6_5_fixnum = string_to_symbol("_MAXFX1292");
symbol1994___r4_numbers_6_5_fixnum = string_to_symbol("MINFX");
symbol1995___r4_numbers_6_5_fixnum = string_to_symbol("_MINFX1293");
symbol1996___r4_numbers_6_5_fixnum = string_to_symbol("+FX");
symbol1997___r4_numbers_6_5_fixnum = string_to_symbol("_+FX1294");
symbol1998___r4_numbers_6_5_fixnum = string_to_symbol("-FX");
symbol1999___r4_numbers_6_5_fixnum = string_to_symbol("_-FX1295");
symbol2000___r4_numbers_6_5_fixnum = string_to_symbol("*FX");
symbol2001___r4_numbers_6_5_fixnum = string_to_symbol("_*FX1296");
symbol2002___r4_numbers_6_5_fixnum = string_to_symbol("/FX");
symbol2003___r4_numbers_6_5_fixnum = string_to_symbol("_/FX1297");
symbol2004___r4_numbers_6_5_fixnum = string_to_symbol("NEGFX");
symbol2005___r4_numbers_6_5_fixnum = string_to_symbol("_NEGFX1298");
symbol2006___r4_numbers_6_5_fixnum = string_to_symbol("ABSFX");
symbol2007___r4_numbers_6_5_fixnum = string_to_symbol("_ABSFX1299");
symbol2008___r4_numbers_6_5_fixnum = string_to_symbol("QUOTIENT");
symbol2009___r4_numbers_6_5_fixnum = string_to_symbol("_QUOTIENT1300");
symbol2010___r4_numbers_6_5_fixnum = string_to_symbol("REMAINDER");
symbol2011___r4_numbers_6_5_fixnum = string_to_symbol("_REMAINDER1301");
symbol2012___r4_numbers_6_5_fixnum = string_to_symbol("MODULO");
symbol2013___r4_numbers_6_5_fixnum = string_to_symbol("_MODULO1302");
symbol2014___r4_numbers_6_5_fixnum = string_to_symbol("GCD");
symbol2016___r4_numbers_6_5_fixnum = string_to_symbol("LCM");
symbol2017___r4_numbers_6_5_fixnum = string_to_symbol("LCM2");
symbol2018___r4_numbers_6_5_fixnum = string_to_symbol("INTEGER->STRING");
symbol2023___r4_numbers_6_5_fixnum = string_to_symbol("_INTEGER->STRING1303");
symbol2024___r4_numbers_6_5_fixnum = string_to_symbol("STRING->INTEGER");
symbol2025___r4_numbers_6_5_fixnum = string_to_symbol("_STRING->INTEGER1304");
symbol2026___r4_numbers_6_5_fixnum = string_to_symbol("STRING->ELONG");
symbol2027___r4_numbers_6_5_fixnum = string_to_symbol("_STRING->ELONG1305");
symbol2028___r4_numbers_6_5_fixnum = string_to_symbol("STRING->LLONG");
symbol2029___r4_numbers_6_5_fixnum = string_to_symbol("_STRING->LLONG1306");
return (symbol2030___r4_numbers_6_5_fixnum = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* integer? */bool_t integer__108___r4_numbers_6_5_fixnum(obj_t obj_1)
{
{
obj_t symbol1218_1438;
symbol1218_1438 = symbol1964___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1218_1438);
BUNSPEC;
{
bool_t aux1217_1439;
aux1217_1439 = INTEGERP(obj_1);
POP_TRACE();
return aux1217_1439;
}
}
}
}


/* _integer? */obj_t _integer__27___r4_numbers_6_5_fixnum(obj_t env_804, obj_t obj_805)
{
{
bool_t aux_1629;
{
obj_t obj_1440;
obj_1440 = obj_805;
{
obj_t symbol1218_1441;
symbol1218_1441 = symbol1964___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1218_1441);
BUNSPEC;
{
bool_t aux1217_1442;
aux1217_1442 = INTEGERP(obj_1440);
POP_TRACE();
aux_1629 = aux1217_1442;
}
}
}
}
return BBOOL(aux_1629);
}
}


/* fixnum? */bool_t fixnum__102___r4_numbers_6_5_fixnum(obj_t obj_2)
{
return INTEGERP(obj_2);
}


/* _fixnum? */obj_t _fixnum__233___r4_numbers_6_5_fixnum(obj_t env_806, obj_t obj_807)
{
{
bool_t aux_1635;
{
obj_t obj_1443;
obj_1443 = obj_807;
aux_1635 = INTEGERP(obj_1443);
}
return BBOOL(aux_1635);
}
}


/* elong? */bool_t elong__154___r4_numbers_6_5_fixnum(obj_t obj_3)
{
{
obj_t symbol1220_1444;
symbol1220_1444 = symbol1965___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1220_1444);
BUNSPEC;
{
bool_t aux1219_1445;
aux1219_1445 = ELONGP(obj_3);
POP_TRACE();
return aux1219_1445;
}
}
}
}


/* _elong? */obj_t _elong__107___r4_numbers_6_5_fixnum(obj_t env_808, obj_t obj_809)
{
{
bool_t aux_1641;
{
obj_t obj_1446;
obj_1446 = obj_809;
{
obj_t symbol1220_1447;
symbol1220_1447 = symbol1965___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1220_1447);
BUNSPEC;
{
bool_t aux1219_1448;
aux1219_1448 = ELONGP(obj_1446);
POP_TRACE();
aux_1641 = aux1219_1448;
}
}
}
}
return BBOOL(aux_1641);
}
}


/* llong? */bool_t llong__230___r4_numbers_6_5_fixnum(obj_t obj_4)
{
{
obj_t symbol1222_1449;
symbol1222_1449 = symbol1966___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1222_1449);
BUNSPEC;
{
bool_t aux1221_1450;
aux1221_1450 = LLONGP(obj_4);
POP_TRACE();
return aux1221_1450;
}
}
}
}


/* _llong? */obj_t _llong__245___r4_numbers_6_5_fixnum(obj_t env_810, obj_t obj_811)
{
{
bool_t aux_1649;
{
obj_t obj_1451;
obj_1451 = obj_811;
{
obj_t symbol1222_1452;
symbol1222_1452 = symbol1966___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1222_1452);
BUNSPEC;
{
bool_t aux1221_1453;
aux1221_1453 = LLONGP(obj_1451);
POP_TRACE();
aux_1649 = aux1221_1453;
}
}
}
}
return BBOOL(aux_1649);
}
}


/* make-elong */obj_t make_elong_201___r4_numbers_6_5_fixnum(long long_5)
{
{
obj_t symbol1224_1454;
symbol1224_1454 = symbol1967___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1224_1454);
BUNSPEC;
{
obj_t aux1223_1455;
aux1223_1455 = LONG_TO_BELONG(long_5);
POP_TRACE();
return aux1223_1455;
}
}
}
}


/* _make-elong1281 */obj_t _make_elong1281_145___r4_numbers_6_5_fixnum(obj_t env_812, obj_t long_813)
{
{
long long_57_1456;
{
obj_t aux_1657;
if(INTEGERP(long_813)){
aux_1657 = long_813;
}
 else {
bigloo_type_error_location_103___error(symbol1968___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, long_813, string1970___r4_numbers_6_5_fixnum, BINT(((long)7130)));
exit( -1 );}
long_57_1456 = (long)CINT(aux_1657);
}
{
obj_t symbol1224_1457;
symbol1224_1457 = symbol1967___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1224_1457);
BUNSPEC;
{
obj_t aux1223_1458;
aux1223_1458 = LONG_TO_BELONG(long_57_1456);
POP_TRACE();
return aux1223_1458;
}
}
}
}
}


/* =fx */bool_t _fx_134___r4_numbers_6_5_fixnum(long n1_6, long n2_7)
{
{
obj_t symbol1226_1459;
symbol1226_1459 = symbol1971___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1226_1459);
BUNSPEC;
{
bool_t aux1225_1460;
aux1225_1460 = (n1_6==n2_7);
POP_TRACE();
return aux1225_1460;
}
}
}
}


/* _=fx1282 */obj_t __fx1282_241___r4_numbers_6_5_fixnum(obj_t env_814, obj_t n1_815, obj_t n2_816)
{
{
bool_t aux_1670;
{
long n1_1461;
long n2_1462;
{
obj_t aux_1671;
if(INTEGERP(n1_815)){
aux_1671 = n1_815;
}
 else {
bigloo_type_error_location_103___error(symbol1972___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_815, string1970___r4_numbers_6_5_fixnum, BINT(((long)7410)));
exit( -1 );}
n1_1461 = (long)CINT(aux_1671);
}
{
obj_t aux_1678;
if(INTEGERP(n2_816)){
aux_1678 = n2_816;
}
 else {
bigloo_type_error_location_103___error(symbol1972___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_816, string1970___r4_numbers_6_5_fixnum, BINT(((long)7410)));
exit( -1 );}
n2_1462 = (long)CINT(aux_1678);
}
{
obj_t symbol1226_1463;
symbol1226_1463 = symbol1971___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1226_1463);
BUNSPEC;
{
bool_t aux1225_1464;
aux1225_1464 = (n1_1461==n2_1462);
POP_TRACE();
aux_1670 = aux1225_1464;
}
}
}
}
return BBOOL(aux_1670);
}
}


/* <fx */bool_t _fx_179___r4_numbers_6_5_fixnum(long n1_8, long n2_9)
{
{
obj_t symbol1228_1465;
symbol1228_1465 = symbol1973___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1228_1465);
BUNSPEC;
{
bool_t aux1227_1466;
aux1227_1466 = (n1_8<n2_9);
POP_TRACE();
return aux1227_1466;
}
}
}
}


/* _<fx1283 */obj_t __fx1283_61___r4_numbers_6_5_fixnum(obj_t env_817, obj_t n1_818, obj_t n2_819)
{
{
bool_t aux_1692;
{
long n1_1467;
long n2_1468;
{
obj_t aux_1693;
if(INTEGERP(n1_818)){
aux_1693 = n1_818;
}
 else {
bigloo_type_error_location_103___error(symbol1974___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_818, string1970___r4_numbers_6_5_fixnum, BINT(((long)7678)));
exit( -1 );}
n1_1467 = (long)CINT(aux_1693);
}
{
obj_t aux_1700;
if(INTEGERP(n2_819)){
aux_1700 = n2_819;
}
 else {
bigloo_type_error_location_103___error(symbol1974___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_819, string1970___r4_numbers_6_5_fixnum, BINT(((long)7678)));
exit( -1 );}
n2_1468 = (long)CINT(aux_1700);
}
{
obj_t symbol1228_1469;
symbol1228_1469 = symbol1973___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1228_1469);
BUNSPEC;
{
bool_t aux1227_1470;
aux1227_1470 = (n1_1467<n2_1468);
POP_TRACE();
aux_1692 = aux1227_1470;
}
}
}
}
return BBOOL(aux_1692);
}
}


/* >fx */bool_t _fx_24___r4_numbers_6_5_fixnum(long n1_10, long n2_11)
{
{
obj_t symbol1230_1471;
symbol1230_1471 = symbol1975___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1230_1471);
BUNSPEC;
{
bool_t aux1229_1472;
aux1229_1472 = (n1_10>n2_11);
POP_TRACE();
return aux1229_1472;
}
}
}
}


/* _>fx1284 */obj_t __fx1284_67___r4_numbers_6_5_fixnum(obj_t env_820, obj_t n1_821, obj_t n2_822)
{
{
bool_t aux_1714;
{
long n1_1473;
long n2_1474;
{
obj_t aux_1715;
if(INTEGERP(n1_821)){
aux_1715 = n1_821;
}
 else {
bigloo_type_error_location_103___error(symbol1976___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_821, string1970___r4_numbers_6_5_fixnum, BINT(((long)7946)));
exit( -1 );}
n1_1473 = (long)CINT(aux_1715);
}
{
obj_t aux_1722;
if(INTEGERP(n2_822)){
aux_1722 = n2_822;
}
 else {
bigloo_type_error_location_103___error(symbol1976___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_822, string1970___r4_numbers_6_5_fixnum, BINT(((long)7946)));
exit( -1 );}
n2_1474 = (long)CINT(aux_1722);
}
{
obj_t symbol1230_1475;
symbol1230_1475 = symbol1975___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1230_1475);
BUNSPEC;
{
bool_t aux1229_1476;
aux1229_1476 = (n1_1473>n2_1474);
POP_TRACE();
aux_1714 = aux1229_1476;
}
}
}
}
return BBOOL(aux_1714);
}
}


/* <=fx */bool_t __fx_163___r4_numbers_6_5_fixnum(long n1_12, long n2_13)
{
{
obj_t symbol1232_1477;
symbol1232_1477 = symbol1977___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1232_1477);
BUNSPEC;
{
bool_t aux1231_1478;
aux1231_1478 = (n1_12<=n2_13);
POP_TRACE();
return aux1231_1478;
}
}
}
}


/* _<=fx1285 */obj_t ___fx1285_108___r4_numbers_6_5_fixnum(obj_t env_823, obj_t n1_824, obj_t n2_825)
{
{
bool_t aux_1736;
{
long n1_1479;
long n2_1480;
{
obj_t aux_1737;
if(INTEGERP(n1_824)){
aux_1737 = n1_824;
}
 else {
bigloo_type_error_location_103___error(symbol1978___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_824, string1970___r4_numbers_6_5_fixnum, BINT(((long)8214)));
exit( -1 );}
n1_1479 = (long)CINT(aux_1737);
}
{
obj_t aux_1744;
if(INTEGERP(n2_825)){
aux_1744 = n2_825;
}
 else {
bigloo_type_error_location_103___error(symbol1978___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_825, string1970___r4_numbers_6_5_fixnum, BINT(((long)8214)));
exit( -1 );}
n2_1480 = (long)CINT(aux_1744);
}
{
obj_t symbol1232_1481;
symbol1232_1481 = symbol1977___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1232_1481);
BUNSPEC;
{
bool_t aux1231_1482;
aux1231_1482 = (n1_1479<=n2_1480);
POP_TRACE();
aux_1736 = aux1231_1482;
}
}
}
}
return BBOOL(aux_1736);
}
}


/* >=fx */bool_t __fx_254___r4_numbers_6_5_fixnum(long n1_14, long n2_15)
{
{
obj_t symbol1234_1483;
symbol1234_1483 = symbol1979___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1234_1483);
BUNSPEC;
{
bool_t aux1233_1484;
aux1233_1484 = (n1_14>=n2_15);
POP_TRACE();
return aux1233_1484;
}
}
}
}


/* _>=fx1286 */obj_t ___fx1286_114___r4_numbers_6_5_fixnum(obj_t env_826, obj_t n1_827, obj_t n2_828)
{
{
bool_t aux_1758;
{
long n1_1485;
long n2_1486;
{
obj_t aux_1759;
if(INTEGERP(n1_827)){
aux_1759 = n1_827;
}
 else {
bigloo_type_error_location_103___error(symbol1980___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_827, string1970___r4_numbers_6_5_fixnum, BINT(((long)8484)));
exit( -1 );}
n1_1485 = (long)CINT(aux_1759);
}
{
obj_t aux_1766;
if(INTEGERP(n2_828)){
aux_1766 = n2_828;
}
 else {
bigloo_type_error_location_103___error(symbol1980___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_828, string1970___r4_numbers_6_5_fixnum, BINT(((long)8484)));
exit( -1 );}
n2_1486 = (long)CINT(aux_1766);
}
{
obj_t symbol1234_1487;
symbol1234_1487 = symbol1979___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1234_1487);
BUNSPEC;
{
bool_t aux1233_1488;
aux1233_1488 = (n1_1485>=n2_1486);
POP_TRACE();
aux_1758 = aux1233_1488;
}
}
}
}
return BBOOL(aux_1758);
}
}


/* zerofx? */bool_t zerofx__17___r4_numbers_6_5_fixnum(long n_16)
{
{
obj_t symbol1236_1489;
symbol1236_1489 = symbol1981___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1236_1489);
BUNSPEC;
{
bool_t aux1235_1490;
aux1235_1490 = (n_16==((long)0));
POP_TRACE();
return aux1235_1490;
}
}
}
}


/* _zerofx?1287 */obj_t _zerofx_1287_127___r4_numbers_6_5_fixnum(obj_t env_829, obj_t n_830)
{
{
bool_t aux_1780;
{
long n_1491;
{
obj_t aux_1781;
if(INTEGERP(n_830)){
aux_1781 = n_830;
}
 else {
bigloo_type_error_location_103___error(symbol1982___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n_830, string1970___r4_numbers_6_5_fixnum, BINT(((long)8754)));
exit( -1 );}
n_1491 = (long)CINT(aux_1781);
}
{
obj_t symbol1236_1492;
symbol1236_1492 = symbol1981___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1236_1492);
BUNSPEC;
{
bool_t aux1235_1493;
aux1235_1493 = (n_1491==((long)0));
POP_TRACE();
aux_1780 = aux1235_1493;
}
}
}
}
return BBOOL(aux_1780);
}
}


/* positivefx? */bool_t positivefx__200___r4_numbers_6_5_fixnum(long n_17)
{
{
obj_t symbol1238_1494;
symbol1238_1494 = symbol1983___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1238_1494);
BUNSPEC;
{
bool_t aux1237_1495;
aux1237_1495 = (n_17>((long)0));
POP_TRACE();
return aux1237_1495;
}
}
}
}


/* _positivefx?1288 */obj_t _positivefx_1288_189___r4_numbers_6_5_fixnum(obj_t env_831, obj_t n_832)
{
{
bool_t aux_1795;
{
long n_1496;
{
obj_t aux_1796;
if(INTEGERP(n_832)){
aux_1796 = n_832;
}
 else {
bigloo_type_error_location_103___error(symbol1984___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n_832, string1970___r4_numbers_6_5_fixnum, BINT(((long)9018)));
exit( -1 );}
n_1496 = (long)CINT(aux_1796);
}
{
obj_t symbol1238_1497;
symbol1238_1497 = symbol1983___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1238_1497);
BUNSPEC;
{
bool_t aux1237_1498;
aux1237_1498 = (n_1496>((long)0));
POP_TRACE();
aux_1795 = aux1237_1498;
}
}
}
}
return BBOOL(aux_1795);
}
}


/* negativefx? */bool_t negativefx__232___r4_numbers_6_5_fixnum(long n_18)
{
{
obj_t symbol1240_1499;
symbol1240_1499 = symbol1985___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1240_1499);
BUNSPEC;
{
bool_t aux1239_1500;
aux1239_1500 = (n_18<((long)0));
POP_TRACE();
return aux1239_1500;
}
}
}
}


/* _negativefx?1289 */obj_t _negativefx_1289_227___r4_numbers_6_5_fixnum(obj_t env_833, obj_t n_834)
{
{
bool_t aux_1810;
{
long n_1501;
{
obj_t aux_1811;
if(INTEGERP(n_834)){
aux_1811 = n_834;
}
 else {
bigloo_type_error_location_103___error(symbol1986___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n_834, string1970___r4_numbers_6_5_fixnum, BINT(((long)9286)));
exit( -1 );}
n_1501 = (long)CINT(aux_1811);
}
{
obj_t symbol1240_1502;
symbol1240_1502 = symbol1985___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1240_1502);
BUNSPEC;
{
bool_t aux1239_1503;
aux1239_1503 = (n_1501<((long)0));
POP_TRACE();
aux_1810 = aux1239_1503;
}
}
}
}
return BBOOL(aux_1810);
}
}


/* odd? */bool_t odd__202___r4_numbers_6_5_fixnum(long x_19)
{
{
obj_t symbol1242_1504;
symbol1242_1504 = symbol1987___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1242_1504);
BUNSPEC;
{
bool_t aux1241_1505;
aux1241_1505 = ODDP_FX(x_19);
POP_TRACE();
return aux1241_1505;
}
}
}
}


/* _odd?1290 */obj_t _odd_1290_194___r4_numbers_6_5_fixnum(obj_t env_835, obj_t x_836)
{
{
bool_t aux_1825;
{
long x_1506;
{
obj_t aux_1826;
if(INTEGERP(x_836)){
aux_1826 = x_836;
}
 else {
bigloo_type_error_location_103___error(symbol1988___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, x_836, string1970___r4_numbers_6_5_fixnum, BINT(((long)9554)));
exit( -1 );}
x_1506 = (long)CINT(aux_1826);
}
{
obj_t symbol1242_1507;
symbol1242_1507 = symbol1987___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1242_1507);
BUNSPEC;
{
bool_t aux1241_1508;
aux1241_1508 = ODDP_FX(x_1506);
POP_TRACE();
aux_1825 = aux1241_1508;
}
}
}
}
return BBOOL(aux_1825);
}
}


/* even? */bool_t even__46___r4_numbers_6_5_fixnum(long x_20)
{
{
obj_t symbol1244_1509;
symbol1244_1509 = symbol1989___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1244_1509);
BUNSPEC;
{
bool_t aux1243_1510;
aux1243_1510 = EVENP_FX(x_20);
POP_TRACE();
return aux1243_1510;
}
}
}
}


/* _even?1291 */obj_t _even_1291_120___r4_numbers_6_5_fixnum(obj_t env_837, obj_t x_838)
{
{
bool_t aux_1840;
{
long x_1511;
{
obj_t aux_1841;
if(INTEGERP(x_838)){
aux_1841 = x_838;
}
 else {
bigloo_type_error_location_103___error(symbol1990___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, x_838, string1970___r4_numbers_6_5_fixnum, BINT(((long)9816)));
exit( -1 );}
x_1511 = (long)CINT(aux_1841);
}
{
obj_t symbol1244_1512;
symbol1244_1512 = symbol1989___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1244_1512);
BUNSPEC;
{
bool_t aux1243_1513;
aux1243_1513 = EVENP_FX(x_1511);
POP_TRACE();
aux_1840 = aux1243_1513;
}
}
}
}
return BBOOL(aux_1840);
}
}


/* maxfx */long maxfx___r4_numbers_6_5_fixnum(long n1_21, obj_t nn_22)
{
{
obj_t symbol1246_768;
symbol1246_768 = symbol1991___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1246_768);
BUNSPEC;
{
long aux1245_769;
{
obj_t max_224;
obj_t nn_225;
{
obj_t aux_1853;
{
obj_t aux1475_1018;
max_224 = BINT(n1_21);
nn_225 = nn_22;
loop_226:
if(NULLP(nn_225)){
aux1475_1018 = max_224;
}
 else {
bool_t test1012_228;
{
obj_t arg1016_232;
{
obj_t pair_451;
if(PAIRP(nn_225)){
pair_451 = nn_225;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_225, string1970___r4_numbers_6_5_fixnum, BINT(((long)10185)));
exit( -1 );}
arg1016_232 = CAR(pair_451);
}
{
long n1_452;
long n2_453;
{
obj_t aux_1862;
if(INTEGERP(arg1016_232)){
aux_1862 = arg1016_232;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1016_232, string1970___r4_numbers_6_5_fixnum, BINT(((long)10179)));
exit( -1 );}
n1_452 = (long)CINT(aux_1862);
}
{
obj_t aux_1869;
if(INTEGERP(max_224)){
aux_1869 = max_224;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, max_224, string1970___r4_numbers_6_5_fixnum, BINT(((long)10179)));
exit( -1 );}
n2_453 = (long)CINT(aux_1869);
}
test1012_228 = (n1_452>n2_453);
}
}
if(test1012_228){
obj_t arg1013_229;
obj_t arg1014_230;
{
obj_t pair_454;
if(PAIRP(nn_225)){
pair_454 = nn_225;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_225, string1970___r4_numbers_6_5_fixnum, BINT(((long)10212)));
exit( -1 );}
arg1013_229 = CAR(pair_454);
}
{
obj_t pair_455;
if(PAIRP(nn_225)){
pair_455 = nn_225;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_225, string1970___r4_numbers_6_5_fixnum, BINT(((long)10221)));
exit( -1 );}
arg1014_230 = CDR(pair_455);
}
{
obj_t nn_1891;
obj_t max_1890;
max_1890 = arg1013_229;
nn_1891 = arg1014_230;
nn_225 = nn_1891;
max_224 = max_1890;
goto loop_226;
}
}
 else {
obj_t arg1015_231;
{
obj_t pair_456;
if(PAIRP(nn_225)){
pair_456 = nn_225;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_225, string1970___r4_numbers_6_5_fixnum, BINT(((long)10248)));
exit( -1 );}
arg1015_231 = CDR(pair_456);
}
{
obj_t nn_1898;
nn_1898 = arg1015_231;
nn_225 = nn_1898;
goto loop_226;
}
}
}
if(INTEGERP(aux1475_1018)){
aux_1853 = aux1475_1018;
}
 else {
bigloo_type_error_location_103___error(symbol1991___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1475_1018, string1970___r4_numbers_6_5_fixnum, BINT(((long)10107)));
exit( -1 );}
}
aux1245_769 = (long)CINT(aux_1853);
}
}
POP_TRACE();
return aux1245_769;
}
}
}
}


/* _maxfx1292 */obj_t _maxfx1292___r4_numbers_6_5_fixnum(obj_t env_839, obj_t n1_840, obj_t nn_841)
{
{
long aux_1907;
{
long aux_1908;
{
obj_t aux_1909;
if(INTEGERP(n1_840)){
aux_1909 = n1_840;
}
 else {
bigloo_type_error_location_103___error(symbol1993___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_840, string1970___r4_numbers_6_5_fixnum, BINT(((long)10080)));
exit( -1 );}
aux_1908 = (long)CINT(aux_1909);
}
aux_1907 = maxfx___r4_numbers_6_5_fixnum(aux_1908, nn_841);
}
return BINT(aux_1907);
}
}


/* minfx */long minfx___r4_numbers_6_5_fixnum(long n1_23, obj_t nn_24)
{
{
obj_t symbol1248_770;
symbol1248_770 = symbol1994___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1248_770);
BUNSPEC;
{
long aux1247_771;
{
obj_t min_233;
obj_t nn_234;
{
obj_t aux_1919;
{
obj_t aux1529_1066;
min_233 = BINT(n1_23);
nn_234 = nn_24;
loop_235:
if(NULLP(nn_234)){
aux1529_1066 = min_233;
}
 else {
bool_t test1018_237;
{
obj_t arg1022_241;
{
obj_t pair_458;
if(PAIRP(nn_234)){
pair_458 = nn_234;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_234, string1970___r4_numbers_6_5_fixnum, BINT(((long)10589)));
exit( -1 );}
arg1022_241 = CAR(pair_458);
}
{
long n1_459;
long n2_460;
{
obj_t aux_1928;
if(INTEGERP(arg1022_241)){
aux_1928 = arg1022_241;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1022_241, string1970___r4_numbers_6_5_fixnum, BINT(((long)10583)));
exit( -1 );}
n1_459 = (long)CINT(aux_1928);
}
{
obj_t aux_1935;
if(INTEGERP(min_233)){
aux_1935 = min_233;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, min_233, string1970___r4_numbers_6_5_fixnum, BINT(((long)10583)));
exit( -1 );}
n2_460 = (long)CINT(aux_1935);
}
test1018_237 = (n1_459<n2_460);
}
}
if(test1018_237){
obj_t arg1019_238;
obj_t arg1020_239;
{
obj_t pair_461;
if(PAIRP(nn_234)){
pair_461 = nn_234;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_234, string1970___r4_numbers_6_5_fixnum, BINT(((long)10616)));
exit( -1 );}
arg1019_238 = CAR(pair_461);
}
{
obj_t pair_462;
if(PAIRP(nn_234)){
pair_462 = nn_234;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_234, string1970___r4_numbers_6_5_fixnum, BINT(((long)10625)));
exit( -1 );}
arg1020_239 = CDR(pair_462);
}
{
obj_t nn_1957;
obj_t min_1956;
min_1956 = arg1019_238;
nn_1957 = arg1020_239;
nn_234 = nn_1957;
min_233 = min_1956;
goto loop_235;
}
}
 else {
obj_t arg1021_240;
{
obj_t pair_463;
if(PAIRP(nn_234)){
pair_463 = nn_234;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, nn_234, string1970___r4_numbers_6_5_fixnum, BINT(((long)10652)));
exit( -1 );}
arg1021_240 = CDR(pair_463);
}
{
obj_t nn_1964;
nn_1964 = arg1021_240;
nn_234 = nn_1964;
goto loop_235;
}
}
}
if(INTEGERP(aux1529_1066)){
aux_1919 = aux1529_1066;
}
 else {
bigloo_type_error_location_103___error(symbol1994___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1529_1066, string1970___r4_numbers_6_5_fixnum, BINT(((long)10511)));
exit( -1 );}
}
aux1247_771 = (long)CINT(aux_1919);
}
}
POP_TRACE();
return aux1247_771;
}
}
}
}


/* _minfx1293 */obj_t _minfx1293___r4_numbers_6_5_fixnum(obj_t env_842, obj_t n1_843, obj_t nn_844)
{
{
long aux_1973;
{
long aux_1974;
{
obj_t aux_1975;
if(INTEGERP(n1_843)){
aux_1975 = n1_843;
}
 else {
bigloo_type_error_location_103___error(symbol1995___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_843, string1970___r4_numbers_6_5_fixnum, BINT(((long)10484)));
exit( -1 );}
aux_1974 = (long)CINT(aux_1975);
}
aux_1973 = minfx___r4_numbers_6_5_fixnum(aux_1974, nn_844);
}
return BINT(aux_1973);
}
}


/* +fx */long _fx_15___r4_numbers_6_5_fixnum(long z1_25, long z2_26)
{
{
obj_t symbol1250_1514;
symbol1250_1514 = symbol1996___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1250_1514);
BUNSPEC;
{
long aux1249_1515;
aux1249_1515 = (z1_25+z2_26);
POP_TRACE();
return aux1249_1515;
}
}
}
}


/* _+fx1294 */obj_t __fx1294_216___r4_numbers_6_5_fixnum(obj_t env_845, obj_t z1_846, obj_t z2_847)
{
{
long aux_1987;
{
long z1_1516;
long z2_1517;
{
obj_t aux_1988;
if(INTEGERP(z1_846)){
aux_1988 = z1_846;
}
 else {
bigloo_type_error_location_103___error(symbol1997___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z1_846, string1970___r4_numbers_6_5_fixnum, BINT(((long)10888)));
exit( -1 );}
z1_1516 = (long)CINT(aux_1988);
}
{
obj_t aux_1995;
if(INTEGERP(z2_847)){
aux_1995 = z2_847;
}
 else {
bigloo_type_error_location_103___error(symbol1997___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z2_847, string1970___r4_numbers_6_5_fixnum, BINT(((long)10888)));
exit( -1 );}
z2_1517 = (long)CINT(aux_1995);
}
{
obj_t symbol1250_1518;
symbol1250_1518 = symbol1996___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1250_1518);
BUNSPEC;
{
long aux1249_1519;
aux1249_1519 = (z1_1516+z2_1517);
POP_TRACE();
aux_1987 = aux1249_1519;
}
}
}
}
return BINT(aux_1987);
}
}


/* -fx */long _fx_187___r4_numbers_6_5_fixnum(long z1_27, long z2_28)
{
{
obj_t symbol1252_1520;
symbol1252_1520 = symbol1998___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1252_1520);
BUNSPEC;
{
long aux1251_1521;
aux1251_1521 = (z1_27-z2_28);
POP_TRACE();
return aux1251_1521;
}
}
}
}


/* _-fx1295 */obj_t __fx1295_84___r4_numbers_6_5_fixnum(obj_t env_848, obj_t z1_849, obj_t z2_850)
{
{
long aux_2009;
{
long z1_1522;
long z2_1523;
{
obj_t aux_2010;
if(INTEGERP(z1_849)){
aux_2010 = z1_849;
}
 else {
bigloo_type_error_location_103___error(symbol1999___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z1_849, string1970___r4_numbers_6_5_fixnum, BINT(((long)11156)));
exit( -1 );}
z1_1522 = (long)CINT(aux_2010);
}
{
obj_t aux_2017;
if(INTEGERP(z2_850)){
aux_2017 = z2_850;
}
 else {
bigloo_type_error_location_103___error(symbol1999___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z2_850, string1970___r4_numbers_6_5_fixnum, BINT(((long)11156)));
exit( -1 );}
z2_1523 = (long)CINT(aux_2017);
}
{
obj_t symbol1252_1524;
symbol1252_1524 = symbol1998___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1252_1524);
BUNSPEC;
{
long aux1251_1525;
aux1251_1525 = (z1_1522-z2_1523);
POP_TRACE();
aux_2009 = aux1251_1525;
}
}
}
}
return BINT(aux_2009);
}
}


/* *fx */long _fx_145___r4_numbers_6_5_fixnum(long z1_29, long z2_30)
{
{
obj_t symbol1254_1526;
symbol1254_1526 = symbol2000___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1254_1526);
BUNSPEC;
{
long aux1253_1527;
aux1253_1527 = (z1_29*z2_30);
POP_TRACE();
return aux1253_1527;
}
}
}
}


/* _*fx1296 */obj_t __fx1296_197___r4_numbers_6_5_fixnum(obj_t env_851, obj_t z1_852, obj_t z2_853)
{
{
long aux_2031;
{
long z1_1528;
long z2_1529;
{
obj_t aux_2032;
if(INTEGERP(z1_852)){
aux_2032 = z1_852;
}
 else {
bigloo_type_error_location_103___error(symbol2001___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z1_852, string1970___r4_numbers_6_5_fixnum, BINT(((long)11424)));
exit( -1 );}
z1_1528 = (long)CINT(aux_2032);
}
{
obj_t aux_2039;
if(INTEGERP(z2_853)){
aux_2039 = z2_853;
}
 else {
bigloo_type_error_location_103___error(symbol2001___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z2_853, string1970___r4_numbers_6_5_fixnum, BINT(((long)11424)));
exit( -1 );}
z2_1529 = (long)CINT(aux_2039);
}
{
obj_t symbol1254_1530;
symbol1254_1530 = symbol2000___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1254_1530);
BUNSPEC;
{
long aux1253_1531;
aux1253_1531 = (z1_1528*z2_1529);
POP_TRACE();
aux_2031 = aux1253_1531;
}
}
}
}
return BINT(aux_2031);
}
}


/* /fx */long _fx_61___r4_numbers_6_5_fixnum(long z1_31, long z2_32)
{
{
obj_t symbol1256_1532;
symbol1256_1532 = symbol2002___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1256_1532);
BUNSPEC;
{
long aux1255_1533;
aux1255_1533 = (z1_31/z2_32);
POP_TRACE();
return aux1255_1533;
}
}
}
}


/* _/fx1297 */obj_t __fx1297_198___r4_numbers_6_5_fixnum(obj_t env_854, obj_t z1_855, obj_t z2_856)
{
{
long aux_2053;
{
long z1_1534;
long z2_1535;
{
obj_t aux_2054;
if(INTEGERP(z1_855)){
aux_2054 = z1_855;
}
 else {
bigloo_type_error_location_103___error(symbol2003___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z1_855, string1970___r4_numbers_6_5_fixnum, BINT(((long)11692)));
exit( -1 );}
z1_1534 = (long)CINT(aux_2054);
}
{
obj_t aux_2061;
if(INTEGERP(z2_856)){
aux_2061 = z2_856;
}
 else {
bigloo_type_error_location_103___error(symbol2003___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, z2_856, string1970___r4_numbers_6_5_fixnum, BINT(((long)11692)));
exit( -1 );}
z2_1535 = (long)CINT(aux_2061);
}
{
obj_t symbol1256_1536;
symbol1256_1536 = symbol2002___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1256_1536);
BUNSPEC;
{
long aux1255_1537;
aux1255_1537 = (z1_1534/z2_1535);
POP_TRACE();
aux_2053 = aux1255_1537;
}
}
}
}
return BINT(aux_2053);
}
}


/* negfx */long negfx___r4_numbers_6_5_fixnum(long n1_33)
{
{
obj_t symbol1258_1538;
symbol1258_1538 = symbol2004___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1258_1538);
BUNSPEC;
{
long aux1257_1539;
aux1257_1539 = NEG(n1_33);
POP_TRACE();
return aux1257_1539;
}
}
}
}


/* _negfx1298 */obj_t _negfx1298___r4_numbers_6_5_fixnum(obj_t env_857, obj_t n1_858)
{
{
long aux_2075;
{
long n1_1540;
{
obj_t aux_2076;
if(INTEGERP(n1_858)){
aux_2076 = n1_858;
}
 else {
bigloo_type_error_location_103___error(symbol2005___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_858, string1970___r4_numbers_6_5_fixnum, BINT(((long)11960)));
exit( -1 );}
n1_1540 = (long)CINT(aux_2076);
}
{
obj_t symbol1258_1541;
symbol1258_1541 = symbol2004___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1258_1541);
BUNSPEC;
{
long aux1257_1542;
aux1257_1542 = NEG(n1_1540);
POP_TRACE();
aux_2075 = aux1257_1542;
}
}
}
}
return BINT(aux_2075);
}
}


/* absfx */long absfx___r4_numbers_6_5_fixnum(long n_34)
{
{
obj_t symbol1260_1543;
symbol1260_1543 = symbol2006___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1260_1543);
BUNSPEC;
{
long aux1259_1544;
if((n_34<((long)0))){
aux1259_1544 = NEG(n_34);
}
 else {
aux1259_1544 = n_34;
}
POP_TRACE();
return aux1259_1544;
}
}
}
}


/* _absfx1299 */obj_t _absfx1299___r4_numbers_6_5_fixnum(obj_t env_859, obj_t n_860)
{
{
long aux_2092;
{
long n_1545;
{
obj_t aux_2093;
if(INTEGERP(n_860)){
aux_2093 = n_860;
}
 else {
bigloo_type_error_location_103___error(symbol2007___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n_860, string1970___r4_numbers_6_5_fixnum, BINT(((long)12226)));
exit( -1 );}
n_1545 = (long)CINT(aux_2093);
}
{
obj_t symbol1260_1546;
symbol1260_1546 = symbol2006___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1260_1546);
BUNSPEC;
{
long aux1259_1547;
if((n_1545<((long)0))){
aux1259_1547 = NEG(n_1545);
}
 else {
aux1259_1547 = n_1545;
}
POP_TRACE();
aux_2092 = aux1259_1547;
}
}
}
}
return BINT(aux_2092);
}
}


/* quotient */long quotient___r4_numbers_6_5_fixnum(long n1_35, long n2_36)
{
{
obj_t symbol1262_1548;
symbol1262_1548 = symbol2008___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1262_1548);
BUNSPEC;
{
long aux1261_1549;
aux1261_1549 = (n1_35/n2_36);
POP_TRACE();
return aux1261_1549;
}
}
}
}


/* _quotient1300 */obj_t _quotient1300___r4_numbers_6_5_fixnum(obj_t env_861, obj_t n1_862, obj_t n2_863)
{
{
long aux_2109;
{
long n1_1550;
long n2_1551;
{
obj_t aux_2110;
if(INTEGERP(n1_862)){
aux_2110 = n1_862;
}
 else {
bigloo_type_error_location_103___error(symbol2009___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_862, string1970___r4_numbers_6_5_fixnum, BINT(((long)12519)));
exit( -1 );}
n1_1550 = (long)CINT(aux_2110);
}
{
obj_t aux_2117;
if(INTEGERP(n2_863)){
aux_2117 = n2_863;
}
 else {
bigloo_type_error_location_103___error(symbol2009___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_863, string1970___r4_numbers_6_5_fixnum, BINT(((long)12519)));
exit( -1 );}
n2_1551 = (long)CINT(aux_2117);
}
{
obj_t symbol1262_1552;
symbol1262_1552 = symbol2008___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1262_1552);
BUNSPEC;
{
long aux1261_1553;
aux1261_1553 = (n1_1550/n2_1551);
POP_TRACE();
aux_2109 = aux1261_1553;
}
}
}
}
return BINT(aux_2109);
}
}


/* remainder */long remainder___r4_numbers_6_5_fixnum(long n1_37, long n2_38)
{
{
obj_t symbol1264_1554;
symbol1264_1554 = symbol2010___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1264_1554);
BUNSPEC;
{
long aux1263_1555;
aux1263_1555 = (n1_37%n2_38);
POP_TRACE();
return aux1263_1555;
}
}
}
}


/* _remainder1301 */obj_t _remainder1301___r4_numbers_6_5_fixnum(obj_t env_864, obj_t n1_865, obj_t n2_866)
{
{
long aux_2131;
{
long n1_1556;
long n2_1557;
{
obj_t aux_2132;
if(INTEGERP(n1_865)){
aux_2132 = n1_865;
}
 else {
bigloo_type_error_location_103___error(symbol2011___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n1_865, string1970___r4_numbers_6_5_fixnum, BINT(((long)12797)));
exit( -1 );}
n1_1556 = (long)CINT(aux_2132);
}
{
obj_t aux_2139;
if(INTEGERP(n2_866)){
aux_2139 = n2_866;
}
 else {
bigloo_type_error_location_103___error(symbol2011___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n2_866, string1970___r4_numbers_6_5_fixnum, BINT(((long)12797)));
exit( -1 );}
n2_1557 = (long)CINT(aux_2139);
}
{
obj_t symbol1264_1558;
symbol1264_1558 = symbol2010___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1264_1558);
BUNSPEC;
{
long aux1263_1559;
aux1263_1559 = (n1_1556%n2_1557);
POP_TRACE();
aux_2131 = aux1263_1559;
}
}
}
}
return BINT(aux_2131);
}
}


/* modulo */long modulo___r4_numbers_6_5_fixnum(long x_39, long y_40)
{
{
obj_t symbol1266_788;
symbol1266_788 = symbol2012___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1266_788);
BUNSPEC;
{
long aux1265_789;
{
long r_243;
r_243 = (x_39%y_40);
if((r_243==((long)0))){
aux1265_789 = r_243;
}
 else {
if((y_40>((long)0))){
if((r_243>((long)0))){
aux1265_789 = r_243;
}
 else {
aux1265_789 = (y_40+r_243);
}
}
 else {
if((r_243<((long)0))){
aux1265_789 = r_243;
}
 else {
aux1265_789 = (y_40+r_243);
}
}
}
}
POP_TRACE();
return aux1265_789;
}
}
}
}


/* _modulo1302 */obj_t _modulo1302___r4_numbers_6_5_fixnum(obj_t env_867, obj_t x_868, obj_t y_869)
{
{
long aux_2163;
{
long aux_2172;
long aux_2164;
{
obj_t aux_2173;
if(INTEGERP(y_869)){
aux_2173 = y_869;
}
 else {
bigloo_type_error_location_103___error(symbol2013___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, y_869, string1970___r4_numbers_6_5_fixnum, BINT(((long)13077)));
exit( -1 );}
aux_2172 = (long)CINT(aux_2173);
}
{
obj_t aux_2165;
if(INTEGERP(x_868)){
aux_2165 = x_868;
}
 else {
bigloo_type_error_location_103___error(symbol2013___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, x_868, string1970___r4_numbers_6_5_fixnum, BINT(((long)13077)));
exit( -1 );}
aux_2164 = (long)CINT(aux_2165);
}
aux_2163 = modulo___r4_numbers_6_5_fixnum(aux_2164, aux_2172);
}
return BINT(aux_2163);
}
}


/* gcd */long gcd___r4_numbers_6_5_fixnum(obj_t x_41)
{
{
obj_t symbol1268_790;
symbol1268_790 = symbol2014___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1268_790);
BUNSPEC;
{
long aux1267_791;
{
long m_267;
long n_268;
{
switch (list_length(x_41)){
case ((long)0) : 
aux1267_791 = ((long)0);
break;
case ((long)1) : 
{
obj_t arg1029_252;
{
obj_t pair_486;
if(PAIRP(x_41)){
pair_486 = x_41;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_41, string1970___r4_numbers_6_5_fixnum, BINT(((long)13688)));
exit( -1 );}
arg1029_252 = CAR(pair_486);
}
{
long res1204_492;
{
long n_487;
{
obj_t aux_2189;
if(INTEGERP(arg1029_252)){
aux_2189 = arg1029_252;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1029_252, string1970___r4_numbers_6_5_fixnum, BINT(((long)13680)));
exit( -1 );}
n_487 = (long)CINT(aux_2189);
}
if((n_487<((long)0))){
res1204_492 = NEG(n_487);
}
 else {
res1204_492 = n_487;
}
}
aux1267_791 = res1204_492;
}
}
break;
default: 
{
long arg1030_256;
obj_t arg1031_257;
{
long arg1032_258;
long arg1033_259;
{
obj_t arg1034_260;
{
obj_t pair_493;
if(PAIRP(x_41)){
pair_493 = x_41;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_41, string1970___r4_numbers_6_5_fixnum, BINT(((long)13744)));
exit( -1 );}
arg1034_260 = CAR(pair_493);
}
{
long res1205_499;
{
long n_494;
{
obj_t aux_2205;
if(INTEGERP(arg1034_260)){
aux_2205 = arg1034_260;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1034_260, string1970___r4_numbers_6_5_fixnum, BINT(((long)13736)));
exit( -1 );}
n_494 = (long)CINT(aux_2205);
}
if((n_494<((long)0))){
res1205_499 = NEG(n_494);
}
 else {
res1205_499 = n_494;
}
}
arg1032_258 = res1205_499;
}
}
{
obj_t arg1035_261;
{
obj_t pair_500;
if(PAIRP(x_41)){
pair_500 = x_41;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_41, string1970___r4_numbers_6_5_fixnum, BINT(((long)13760)));
exit( -1 );}
{
obj_t arg1161_501;
arg1161_501 = CDR(pair_500);
{
obj_t pair_503;
if(PAIRP(arg1161_501)){
pair_503 = arg1161_501;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, arg1161_501, string2015___r4_numbers_6_5_fixnum, BINT(((long)7991)));
exit( -1 );}
arg1035_261 = CAR(pair_503);
}
}
}
{
long res1206_509;
{
long n_504;
{
obj_t aux_2227;
if(INTEGERP(arg1035_261)){
aux_2227 = arg1035_261;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1035_261, string1970___r4_numbers_6_5_fixnum, BINT(((long)13752)));
exit( -1 );}
n_504 = (long)CINT(aux_2227);
}
if((n_504<((long)0))){
res1206_509 = NEG(n_504);
}
 else {
res1206_509 = n_504;
}
}
arg1033_259 = res1206_509;
}
}
{
long m_511;
long n_512;
m_511 = arg1032_258;
n_512 = arg1033_259;
gcd2_510:
if((n_512==((long)0))){
arg1030_256 = m_511;
}
 else {
long r_517;
r_517 = (m_511%n_512);
if((r_517==((long)0))){
arg1030_256 = n_512;
}
 else {
long n_2243;
long m_2242;
m_2242 = n_512;
n_2243 = r_517;
n_512 = n_2243;
m_511 = m_2242;
goto gcd2_510;
}
}
}
}
{
obj_t pair_526;
if(PAIRP(x_41)){
pair_526 = x_41;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_41, string1970___r4_numbers_6_5_fixnum, BINT(((long)13781)));
exit( -1 );}
{
obj_t arg1158_527;
arg1158_527 = CDR(pair_526);
{
obj_t pair_529;
if(PAIRP(arg1158_527)){
pair_529 = arg1158_527;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, arg1158_527, string2015___r4_numbers_6_5_fixnum, BINT(((long)8533)));
exit( -1 );}
arg1031_257 = CDR(pair_529);
}
}
}
{
long result_531;
obj_t left_532;
result_531 = arg1030_256;
left_532 = arg1031_257;
loop_530:
{
bool_t test1036_538;
test1036_538 = PAIRP(left_532);
if(test1036_538){
long arg1037_539;
obj_t arg1038_540;
{
long arg1039_541;
{
obj_t arg1040_542;
{
obj_t pair_544;
if(test1036_538){
pair_544 = left_532;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, left_532, string1970___r4_numbers_6_5_fixnum, BINT(((long)13843)));
exit( -1 );}
arg1040_542 = CAR(pair_544);
}
{
long res1207_550;
{
long n_545;
{
obj_t aux_2263;
if(INTEGERP(arg1040_542)){
aux_2263 = arg1040_542;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1040_542, string1970___r4_numbers_6_5_fixnum, BINT(((long)13835)));
exit( -1 );}
n_545 = (long)CINT(aux_2263);
}
if((n_545<((long)0))){
res1207_550 = NEG(n_545);
}
 else {
res1207_550 = n_545;
}
}
arg1039_541 = res1207_550;
}
}
m_267 = result_531;
n_268 = arg1039_541;
gcd2_273:
if((n_268==((long)0))){
arg1037_539 = m_267;
}
 else {
long r_599;
r_599 = (m_267%n_268);
{
bool_t test1043_600;
test1043_600 = (r_599==((long)0));
if(test1043_600){
arg1037_539 = n_268;
}
 else {
if(test1043_600){
arg1037_539 = n_268;
}
 else {
long r_611;
r_611 = (n_268%r_599);
if((r_611==((long)0))){
arg1037_539 = r_599;
}
 else {
long n_2283;
long m_2282;
m_2282 = r_599;
n_2283 = r_611;
n_268 = n_2283;
m_267 = m_2282;
goto gcd2_273;
}
}
}
}
}
}
{
obj_t pair_551;
if(test1036_538){
pair_551 = left_532;
}
 else {
bigloo_type_error_location_103___error(symbol2014___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, left_532, string1970___r4_numbers_6_5_fixnum, BINT(((long)13856)));
exit( -1 );}
arg1038_540 = CDR(pair_551);
}
{
obj_t left_2290;
long result_2289;
result_2289 = arg1037_539;
left_2290 = arg1038_540;
left_532 = left_2290;
result_531 = result_2289;
goto loop_530;
}
}
 else {
aux1267_791 = result_531;
}
}
}
}
}
}
}
POP_TRACE();
return aux1267_791;
}
}
}
}


/* _gcd */obj_t _gcd___r4_numbers_6_5_fixnum(obj_t env_870, obj_t x_871)
{
{
long aux_2294;
aux_2294 = gcd___r4_numbers_6_5_fixnum(x_871);
return BINT(aux_2294);
}
}


/* lcm */long lcm___r4_numbers_6_5_fixnum(obj_t x_42)
{
{
obj_t symbol1270_792;
symbol1270_792 = symbol2016___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1270_792);
BUNSPEC;
{
long aux1269_793;
{
switch (list_length(x_42)){
case ((long)0) : 
aux1269_793 = ((long)1);
break;
case ((long)1) : 
{
obj_t arg1045_278;
{
obj_t pair_620;
if(PAIRP(x_42)){
pair_620 = x_42;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_42, string1970___r4_numbers_6_5_fixnum, BINT(((long)14380)));
exit( -1 );}
arg1045_278 = CAR(pair_620);
}
{
long res1210_626;
{
long n_621;
{
obj_t aux_2304;
if(INTEGERP(arg1045_278)){
aux_2304 = arg1045_278;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, arg1045_278, string1970___r4_numbers_6_5_fixnum, BINT(((long)14372)));
exit( -1 );}
n_621 = (long)CINT(aux_2304);
}
if((n_621<((long)0))){
res1210_626 = NEG(n_621);
}
 else {
res1210_626 = n_621;
}
}
aux1269_793 = res1210_626;
}
}
break;
default: 
{
long arg1046_282;
obj_t arg1047_283;
{
obj_t arg1048_284;
obj_t arg1049_285;
{
obj_t pair_627;
if(PAIRP(x_42)){
pair_627 = x_42;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_42, string1970___r4_numbers_6_5_fixnum, BINT(((long)14427)));
exit( -1 );}
arg1048_284 = CAR(pair_627);
}
{
obj_t pair_628;
if(PAIRP(x_42)){
pair_628 = x_42;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_42, string1970___r4_numbers_6_5_fixnum, BINT(((long)14435)));
exit( -1 );}
{
obj_t arg1161_629;
arg1161_629 = CDR(pair_628);
{
obj_t pair_631;
if(PAIRP(arg1161_629)){
pair_631 = arg1161_629;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, arg1161_629, string2015___r4_numbers_6_5_fixnum, BINT(((long)7991)));
exit( -1 );}
arg1049_285 = CAR(pair_631);
}
}
}
arg1046_282 = lcm2___r4_numbers_6_5_fixnum(arg1048_284, arg1049_285);
}
{
obj_t pair_632;
if(PAIRP(x_42)){
pair_632 = x_42;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, x_42, string1970___r4_numbers_6_5_fixnum, BINT(((long)14452)));
exit( -1 );}
{
obj_t arg1158_633;
arg1158_633 = CDR(pair_632);
{
obj_t pair_635;
if(PAIRP(arg1158_633)){
pair_635 = arg1158_633;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, arg1158_633, string2015___r4_numbers_6_5_fixnum, BINT(((long)8533)));
exit( -1 );}
arg1047_283 = CDR(pair_635);
}
}
}
{
long result_637;
obj_t left_638;
result_637 = arg1046_282;
left_638 = arg1047_283;
loop_636:
{
bool_t test1050_643;
test1050_643 = PAIRP(left_638);
if(test1050_643){
long arg1051_644;
obj_t arg1053_645;
{
obj_t arg1054_646;
{
obj_t pair_648;
if(test1050_643){
pair_648 = left_638;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, left_638, string1970___r4_numbers_6_5_fixnum, BINT(((long)14512)));
exit( -1 );}
arg1054_646 = CAR(pair_648);
}
arg1051_644 = lcm2___r4_numbers_6_5_fixnum(BINT(result_637), arg1054_646);
}
{
obj_t pair_649;
if(test1050_643){
pair_649 = left_638;
}
 else {
bigloo_type_error_location_103___error(symbol2016___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, left_638, string1970___r4_numbers_6_5_fixnum, BINT(((long)14524)));
exit( -1 );}
arg1053_645 = CDR(pair_649);
}
{
obj_t left_2360;
long result_2359;
result_2359 = arg1051_644;
left_2360 = arg1053_645;
left_638 = left_2360;
result_637 = result_2359;
goto loop_636;
}
}
 else {
aux1269_793 = result_637;
}
}
}
}
}
}
POP_TRACE();
return aux1269_793;
}
}
}
}


/* lcm2 */long lcm2___r4_numbers_6_5_fixnum(obj_t m_290, obj_t n_291)
{
{
long m_293;
long n_294;
{
long res1211_671;
{
long n_666;
{
obj_t aux_2364;
if(INTEGERP(m_290)){
aux_2364 = m_290;
}
 else {
bigloo_type_error_location_103___error(symbol2017___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, m_290, string1970___r4_numbers_6_5_fixnum, BINT(((long)14164)));
exit( -1 );}
n_666 = (long)CINT(aux_2364);
}
if((n_666<((long)0))){
res1211_671 = NEG(n_666);
}
 else {
res1211_671 = n_666;
}
}
m_293 = res1211_671;
}
{
long res1212_677;
{
long n_672;
{
obj_t aux_2374;
if(INTEGERP(n_291)){
aux_2374 = n_291;
}
 else {
bigloo_type_error_location_103___error(symbol2017___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, n_291, string1970___r4_numbers_6_5_fixnum, BINT(((long)14178)));
exit( -1 );}
n_672 = (long)CINT(aux_2374);
}
if((n_672<((long)0))){
res1212_677 = NEG(n_672);
}
 else {
res1212_677 = n_672;
}
}
n_294 = res1212_677;
}
if((m_293==n_294)){
return m_293;
}
 else {
bool_t test1057_296;
{
long arg1067_305;
arg1067_305 = (m_293%n_294);
test1057_296 = (arg1067_305==((long)0));
}
if(test1057_296){
return m_293;
}
 else {
bool_t test1058_297;
{
long arg1065_303;
arg1065_303 = (n_294%m_293);
test1058_297 = (arg1065_303==((long)0));
}
if(test1058_297){
return n_294;
}
 else {
{
long arg1059_298;
{
long arg1060_299;
{
obj_t list1061_300;
{
obj_t arg1062_301;
{
obj_t aux_2392;
aux_2392 = BINT(n_294);
arg1062_301 = MAKE_PAIR(aux_2392, BNIL);
}
{
obj_t aux_2395;
aux_2395 = BINT(m_293);
list1061_300 = MAKE_PAIR(aux_2395, arg1062_301);
}
}
arg1060_299 = gcd___r4_numbers_6_5_fixnum(list1061_300);
}
arg1059_298 = (m_293/arg1060_299);
}
return (arg1059_298*n_294);
}
}
}
}
}
}


/* _lcm */obj_t _lcm___r4_numbers_6_5_fixnum(obj_t env_872, obj_t x_873)
{
{
long aux_2401;
aux_2401 = lcm___r4_numbers_6_5_fixnum(x_873);
return BINT(aux_2401);
}
}


/* integer->string */char * integer__string_135___r4_numbers_6_5_fixnum(long x_43, obj_t radix_44)
{
{
obj_t symbol1272_794;
symbol1272_794 = symbol2018___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1272_794);
BUNSPEC;
{
char * aux1271_795;
{
bool_t test1069_308;
{
obj_t obj_692;
obj_692 = radix_44;
test1069_308 = NULLP(obj_692);
}
if(test1069_308){
radix_44 = BINT(((long)10));
}
 else {
obj_t pair_693;
{
obj_t aux1823_1312;
aux1823_1312 = radix_44;
if(PAIRP(aux1823_1312)){
pair_693 = aux1823_1312;
}
 else {
bigloo_type_error_location_103___error(symbol2018___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, aux1823_1312, string1970___r4_numbers_6_5_fixnum, BINT(((long)14875)));
exit( -1 );}
}
radix_44 = CAR(pair_693);
}
}
{
obj_t aux1007_310;
aux1007_310 = radix_44;
{
bool_t test1070_311;
test1070_311 = INTEGERP(aux1007_310);
if(test1070_311){
long aux_2434;
{
obj_t aux_2435;
if(test1070_311){
aux_2435 = aux1007_310;
}
 else {
bigloo_type_error_location_103___error(symbol2018___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1007_310, string1970___r4_numbers_6_5_fixnum, BINT(((long)14891)));
exit( -1 );}
aux_2434 = (long)CINT(aux_2435);
}
switch (aux_2434){
case ((long)2) : 
case ((long)8) : 
case ((long)10) : 
case ((long)16) : 
{
long aux_2416;
{
obj_t aux_2417;
{
obj_t aux1837_1324;
aux1837_1324 = radix_44;
if(INTEGERP(aux1837_1324)){
aux_2417 = aux1837_1324;
}
 else {
bigloo_type_error_location_103___error(symbol2018___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1837_1324, string1970___r4_numbers_6_5_fixnum, BINT(((long)14944)));
exit( -1 );}
}
aux_2416 = (long)CINT(aux_2417);
}
aux1271_795 = integer_to_string(x_43, aux_2416);
}
break;
default: 
{
obj_t object_696;
object_696 = radix_44;
{
obj_t aux_2425;
{
obj_t aux1848_1330;
aux1848_1330 = debug_error_location_199___error(string2019___r4_numbers_6_5_fixnum, string2020___r4_numbers_6_5_fixnum, object_696, string2021___r4_numbers_6_5_fixnum, BINT(((long)7610)));
if(STRINGP(aux1848_1330)){
aux_2425 = aux1848_1330;
}
 else {
bigloo_type_error_location_103___error(symbol2018___r4_numbers_6_5_fixnum, string2022___r4_numbers_6_5_fixnum, aux1848_1330, string2021___r4_numbers_6_5_fixnum, BINT(((long)7610)));
exit( -1 );}
}
aux1271_795 = BSTRING_TO_STRING(aux_2425);
}
}
}
}
 else {
obj_t object_699;
object_699 = radix_44;
{
obj_t aux_2441;
{
obj_t aux1854_1336;
aux1854_1336 = debug_error_location_199___error(string2019___r4_numbers_6_5_fixnum, string2020___r4_numbers_6_5_fixnum, object_699, string2021___r4_numbers_6_5_fixnum, BINT(((long)7610)));
if(STRINGP(aux1854_1336)){
aux_2441 = aux1854_1336;
}
 else {
bigloo_type_error_location_103___error(symbol2018___r4_numbers_6_5_fixnum, string2022___r4_numbers_6_5_fixnum, aux1854_1336, string2021___r4_numbers_6_5_fixnum, BINT(((long)7610)));
exit( -1 );}
}
aux1271_795 = BSTRING_TO_STRING(aux_2441);
}
}
}
}
POP_TRACE();
return aux1271_795;
}
}
}
}


/* _integer->string1303 */obj_t _integer__string1303_238___r4_numbers_6_5_fixnum(obj_t env_874, obj_t x_875, obj_t radix_876)
{
{
char * aux_2451;
{
long aux_2452;
{
obj_t aux_2453;
if(INTEGERP(x_875)){
aux_2453 = x_875;
}
 else {
bigloo_type_error_location_103___error(symbol2023___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, x_875, string1970___r4_numbers_6_5_fixnum, BINT(((long)14775)));
exit( -1 );}
aux_2452 = (long)CINT(aux_2453);
}
aux_2451 = integer__string_135___r4_numbers_6_5_fixnum(aux_2452, radix_876);
}
return string_to_bstring(aux_2451);
}
}


/* string->integer */long string__integer_39___r4_numbers_6_5_fixnum(char * string_45, obj_t radix_46)
{
{
obj_t symbol1274_796;
symbol1274_796 = symbol2024___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1274_796);
BUNSPEC;
{
long aux1273_797;
{
bool_t test1071_703;
{
obj_t obj_704;
obj_704 = radix_46;
test1071_703 = NULLP(obj_704);
}
if(test1071_703){
radix_46 = BINT(((long)10));
}
 else {
obj_t pair_705;
{
obj_t aux1866_1348;
aux1866_1348 = radix_46;
if(PAIRP(aux1866_1348)){
pair_705 = aux1866_1348;
}
 else {
bigloo_type_error_location_103___error(symbol2024___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, aux1866_1348, string1970___r4_numbers_6_5_fixnum, BINT(((long)15352)));
exit( -1 );}
}
radix_46 = CAR(pair_705);
}
}
{
long aux_2472;
{
obj_t aux_2473;
{
obj_t aux1872_1354;
aux1872_1354 = radix_46;
if(INTEGERP(aux1872_1354)){
aux_2473 = aux1872_1354;
}
 else {
bigloo_type_error_location_103___error(symbol2024___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1872_1354, string1970___r4_numbers_6_5_fixnum, BINT(((long)15383)));
exit( -1 );}
}
aux_2472 = (long)CINT(aux_2473);
}
aux1273_797 = strtol(string_45, ((long)0), aux_2472);
}
POP_TRACE();
return aux1273_797;
}
}
}
}


/* _string->integer1304 */obj_t _string__integer1304_123___r4_numbers_6_5_fixnum(obj_t env_877, obj_t string_878, obj_t radix_879)
{
{
long aux_2482;
{
char * aux_2483;
{
obj_t aux_2484;
if(STRINGP(string_878)){
aux_2484 = string_878;
}
 else {
bigloo_type_error_location_103___error(symbol2025___r4_numbers_6_5_fixnum, string2022___r4_numbers_6_5_fixnum, string_878, string1970___r4_numbers_6_5_fixnum, BINT(((long)15247)));
exit( -1 );}
aux_2483 = BSTRING_TO_STRING(aux_2484);
}
aux_2482 = string__integer_39___r4_numbers_6_5_fixnum(aux_2483, radix_879);
}
return BINT(aux_2482);
}
}


/* string->elong */obj_t string__elong_120___r4_numbers_6_5_fixnum(char * string_47, obj_t radix_48)
{
{
obj_t symbol1276_798;
symbol1276_798 = symbol2026___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1276_798);
BUNSPEC;
{
obj_t aux1275_799;
{
bool_t test1072_313;
test1072_313 = PAIRP(radix_48);
if(test1072_313){
long arg1073_314;
{
obj_t arg1076_315;
{
obj_t pair_707;
if(test1072_313){
pair_707 = radix_48;
}
 else {
bigloo_type_error_location_103___error(symbol2026___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, radix_48, string1970___r4_numbers_6_5_fixnum, BINT(((long)15722)));
exit( -1 );}
arg1076_315 = CAR(pair_707);
}
{
obj_t list1077_316;
list1077_316 = MAKE_PAIR(arg1076_315, BNIL);
{
long res1213_713;
{
obj_t radix_709;
radix_709 = list1077_316;
{
bool_t test1071_710;
{
obj_t obj_711;
obj_711 = radix_709;
test1071_710 = NULLP(obj_711);
}
if(test1071_710){
radix_709 = BINT(((long)10));
}
 else {
obj_t pair_712;
{
obj_t aux1893_1372;
aux1893_1372 = radix_709;
if(PAIRP(aux1893_1372)){
pair_712 = aux1893_1372;
}
 else {
bigloo_type_error_location_103___error(symbol2026___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, aux1893_1372, string1970___r4_numbers_6_5_fixnum, BINT(((long)15352)));
exit( -1 );}
}
radix_709 = CAR(pair_712);
}
}
{
long aux_2511;
{
obj_t aux_2512;
{
obj_t aux1899_1378;
aux1899_1378 = radix_709;
if(INTEGERP(aux1899_1378)){
aux_2512 = aux1899_1378;
}
 else {
bigloo_type_error_location_103___error(symbol2026___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1899_1378, string1970___r4_numbers_6_5_fixnum, BINT(((long)15383)));
exit( -1 );}
}
aux_2511 = (long)CINT(aux_2512);
}
res1213_713 = strtol(string_47, ((long)0), aux_2511);
}
}
arg1073_314 = res1213_713;
}
}
}
aux1275_799 = LONG_TO_BELONG(arg1073_314);
}
 else {
long arg1079_318;
{
long res1214_719;
{
obj_t radix_715;
radix_715 = BNIL;
{
bool_t test1071_716;
{
obj_t obj_717;
obj_717 = radix_715;
test1071_716 = NULLP(obj_717);
}
if(test1071_716){
radix_715 = BINT(((long)10));
}
 else {
obj_t pair_718;
{
obj_t aux1906_1384;
aux1906_1384 = radix_715;
if(PAIRP(aux1906_1384)){
pair_718 = aux1906_1384;
}
 else {
bigloo_type_error_location_103___error(symbol2026___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, aux1906_1384, string1970___r4_numbers_6_5_fixnum, BINT(((long)15352)));
exit( -1 );}
}
radix_715 = CAR(pair_718);
}
}
{
long aux_2530;
{
obj_t aux_2531;
{
obj_t aux1913_1390;
aux1913_1390 = radix_715;
if(INTEGERP(aux1913_1390)){
aux_2531 = aux1913_1390;
}
 else {
bigloo_type_error_location_103___error(symbol2026___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1913_1390, string1970___r4_numbers_6_5_fixnum, BINT(((long)15383)));
exit( -1 );}
}
aux_2530 = (long)CINT(aux_2531);
}
res1214_719 = strtol(string_47, ((long)0), aux_2530);
}
}
arg1079_318 = res1214_719;
}
aux1275_799 = LONG_TO_BELONG(arg1079_318);
}
}
POP_TRACE();
return aux1275_799;
}
}
}
}


/* _string->elong1305 */obj_t _string__elong1305_12___r4_numbers_6_5_fixnum(obj_t env_880, obj_t string_881, obj_t radix_882)
{
{
char * aux_2541;
{
obj_t aux_2542;
if(STRINGP(string_881)){
aux_2542 = string_881;
}
 else {
bigloo_type_error_location_103___error(symbol2027___r4_numbers_6_5_fixnum, string2022___r4_numbers_6_5_fixnum, string_881, string1970___r4_numbers_6_5_fixnum, BINT(((long)15616)));
exit( -1 );}
aux_2541 = BSTRING_TO_STRING(aux_2542);
}
return string__elong_120___r4_numbers_6_5_fixnum(aux_2541, radix_882);
}
}


/* string->llong */obj_t string__llong_61___r4_numbers_6_5_fixnum(char * string_49, obj_t radix_50)
{
{
obj_t symbol1278_800;
symbol1278_800 = symbol2028___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1278_800);
BUNSPEC;
{
obj_t aux1277_801;
{
bool_t test1081_320;
test1081_320 = PAIRP(radix_50);
if(test1081_320){
long arg1082_321;
{
obj_t arg1083_322;
{
obj_t pair_721;
if(test1081_320){
pair_721 = radix_50;
}
 else {
bigloo_type_error_location_103___error(symbol2028___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, radix_50, string1970___r4_numbers_6_5_fixnum, BINT(((long)16114)));
exit( -1 );}
arg1083_322 = CAR(pair_721);
}
{
obj_t list1084_323;
list1084_323 = MAKE_PAIR(arg1083_322, BNIL);
{
long res1215_727;
{
obj_t radix_723;
radix_723 = list1084_323;
{
bool_t test1071_724;
{
obj_t obj_725;
obj_725 = radix_723;
test1071_724 = NULLP(obj_725);
}
if(test1071_724){
radix_723 = BINT(((long)10));
}
 else {
obj_t pair_726;
{
obj_t aux1932_1408;
aux1932_1408 = radix_723;
if(PAIRP(aux1932_1408)){
pair_726 = aux1932_1408;
}
 else {
bigloo_type_error_location_103___error(symbol2028___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, aux1932_1408, string1970___r4_numbers_6_5_fixnum, BINT(((long)15352)));
exit( -1 );}
}
radix_723 = CAR(pair_726);
}
}
{
long aux_2568;
{
obj_t aux_2569;
{
obj_t aux1938_1414;
aux1938_1414 = radix_723;
if(INTEGERP(aux1938_1414)){
aux_2569 = aux1938_1414;
}
 else {
bigloo_type_error_location_103___error(symbol2028___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1938_1414, string1970___r4_numbers_6_5_fixnum, BINT(((long)15383)));
exit( -1 );}
}
aux_2568 = (long)CINT(aux_2569);
}
res1215_727 = strtol(string_49, ((long)0), aux_2568);
}
}
arg1082_321 = res1215_727;
}
}
}
aux1277_801 = LLONG_TO_BLLONG(arg1082_321);
}
 else {
long arg1086_325;
{
long res1216_733;
{
obj_t radix_729;
radix_729 = BNIL;
{
bool_t test1071_730;
{
obj_t obj_731;
obj_731 = radix_729;
test1071_730 = NULLP(obj_731);
}
if(test1071_730){
radix_729 = BINT(((long)10));
}
 else {
obj_t pair_732;
{
obj_t aux1944_1420;
aux1944_1420 = radix_729;
if(PAIRP(aux1944_1420)){
pair_732 = aux1944_1420;
}
 else {
bigloo_type_error_location_103___error(symbol2028___r4_numbers_6_5_fixnum, string1992___r4_numbers_6_5_fixnum, aux1944_1420, string1970___r4_numbers_6_5_fixnum, BINT(((long)15352)));
exit( -1 );}
}
radix_729 = CAR(pair_732);
}
}
{
long aux_2587;
{
obj_t aux_2588;
{
obj_t aux1951_1426;
aux1951_1426 = radix_729;
if(INTEGERP(aux1951_1426)){
aux_2588 = aux1951_1426;
}
 else {
bigloo_type_error_location_103___error(symbol2028___r4_numbers_6_5_fixnum, string1969___r4_numbers_6_5_fixnum, aux1951_1426, string1970___r4_numbers_6_5_fixnum, BINT(((long)15383)));
exit( -1 );}
}
aux_2587 = (long)CINT(aux_2588);
}
res1216_733 = strtol(string_49, ((long)0), aux_2587);
}
}
arg1086_325 = res1216_733;
}
aux1277_801 = LLONG_TO_BLLONG(arg1086_325);
}
}
POP_TRACE();
return aux1277_801;
}
}
}
}


/* _string->llong1306 */obj_t _string__llong1306_59___r4_numbers_6_5_fixnum(obj_t env_883, obj_t string_884, obj_t radix_885)
{
{
char * aux_2598;
{
obj_t aux_2599;
if(STRINGP(string_884)){
aux_2599 = string_884;
}
 else {
bigloo_type_error_location_103___error(symbol2029___r4_numbers_6_5_fixnum, string2022___r4_numbers_6_5_fixnum, string_884, string1970___r4_numbers_6_5_fixnum, BINT(((long)16007)));
exit( -1 );}
aux_2598 = BSTRING_TO_STRING(aux_2599);
}
return string__llong_61___r4_numbers_6_5_fixnum(aux_2598, radix_885);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_numbers_6_5_fixnum()
{
{
obj_t symbol1280_802;
symbol1280_802 = symbol2030___r4_numbers_6_5_fixnum;
{
PUSH_TRACE(symbol1280_802);
BUNSPEC;
{
obj_t aux1279_803;
aux1279_803 = module_initialization_70___error(((long)0), "__R4_NUMBERS_6_5_FIXNUM");
POP_TRACE();
return aux1279_803;
}
}
}
}

