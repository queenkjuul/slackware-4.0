/*===========================================================================*/
/*   (R5rs/syntaxrules5.scm)                                                 */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t m_compile_pattern_6___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static bool_t ellipsis_pattern__85___r5_syntax_syntaxrules(obj_t);
static obj_t loop_1598___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t loop_1595___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t m_match_26___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
extern obj_t denotation_of_____90___r5_syntax_syntaxenv;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___r5_syntax_syntaxrules();
extern obj_t macro_rules_111___r5_syntax_syntaxenv(obj_t);
static obj_t _append___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t create_vector(long);
extern obj_t syntactic_alias_206___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
extern obj_t filter1___r5_syntax_misc(obj_t, obj_t);
extern obj_t rename_vars_186___r5_syntax_syntaxenv(obj_t);
static obj_t _cons___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t same_denotation__10___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t denotation_of_____126___r5_syntax_syntaxenv;
extern obj_t m_compile_transformer_spec_209___r5_syntax_syntaxrules(obj_t, obj_t);
extern obj_t m_transcribe_36___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t empty_pattern_variable_environment_234___r5_syntax_syntaxrules = BUNSPEC;
extern obj_t every1__242___r5_syntax_misc(obj_t, obj_t);
static obj_t loop___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t macro_env_86___r5_syntax_syntaxenv(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t m_compile_template_23___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t match___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static bool_t patternvar__77___r5_syntax_syntaxrules(obj_t);
static obj_t pattern_variable_flag_30___r5_syntax_syntaxrules = BUNSPEC;
static obj_t arg1295___r5_syntax_syntaxrules(obj_t, obj_t);
extern obj_t module_initialization_70___r5_syntax_syntaxrules(long, char *);
static obj_t arg1254___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1231___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1225___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static bool_t ellipsis_template__189___r5_syntax_syntaxrules(obj_t);
static obj_t arg1195___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1191___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1201___r5_syntax_syntaxrules(obj_t, obj_t);
static obj_t arg1182___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static obj_t arg1176___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t arg1165___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t m_rewrite_211___r5_syntax_syntaxrules(obj_t, obj_t);
static obj_t arg1162___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t arg1153___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t arg1133___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t ellipsis_template_flag_179___r5_syntax_syntaxrules = BUNSPEC;
static obj_t arg1107___r5_syntax_syntaxrules(obj_t, obj_t);
extern obj_t safe_length_235___r5_syntax_misc(obj_t);
extern obj_t syntactic_lookup_76___r5_syntax_syntaxenv(obj_t, obj_t);
extern long list_length(obj_t);
static obj_t ellipsis_pattern_flag_87___r5_syntax_syntaxrules = BUNSPEC;
extern bool_t _2___235___r4_numbers_6_5(obj_t, obj_t);
extern obj_t m_error_176___r5_syntax_misc(obj_t, obj_t);
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
static obj_t _m_compile_transformer_spec_248___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t make_ellipsis_template_236___r5_syntax_syntaxrules(obj_t, obj_t);
static obj_t pattern_variable_1596_197___r5_syntax_syntaxrules(obj_t, obj_t);
extern bool_t list__240___r4_pairs_and_lists_6_3(obj_t);
extern obj_t denotation_of_syntax_rules_73___r5_syntax_syntaxenv;
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t union2___r5_syntax_misc(obj_t, obj_t);
static obj_t require_initialization_114___r5_syntax_syntaxrules = BUNSPEC;
static obj_t _m_transcribe_224___r5_syntax_syntaxrules(obj_t, obj_t, obj_t, obj_t);
static obj_t rewrite___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t symbol1599___r5_syntax_syntaxrules = BUNSPEC;
static obj_t symbol1604___r5_syntax_syntaxrules = BUNSPEC;
extern bool_t __147___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t symbol1600___r5_syntax_syntaxrules = BUNSPEC;
static obj_t cnst_init_137___r5_syntax_syntaxrules();
static obj_t make_columns_212___r5_syntax_syntaxrules(obj_t, obj_t, obj_t);
static obj_t *__cnst;

extern obj_t cons_env_70___r4_pairs_and_lists_6_3;
DEFINE_EXPORT_PROCEDURE( m_transcribe_env_174___r5_syntax_syntaxrules, _m_transcribe_224___r5_syntax_syntaxrules1612, _m_transcribe_224___r5_syntax_syntaxrules, 0L, 3 );
extern obj_t append_env_23___r4_pairs_and_lists_6_3;
DEFINE_STATIC_PROCEDURE( proc1608___r5_syntax_syntaxrules, arg1295___r5_syntax_syntaxrules1613, arg1295___r5_syntax_syntaxrules, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1606___r5_syntax_syntaxrules, arg1182___r5_syntax_syntaxrules1614, arg1182___r5_syntax_syntaxrules, 0L, 3 );
DEFINE_STATIC_PROCEDURE( proc1602___r5_syntax_syntaxrules, arg1107___r5_syntax_syntaxrules1615, arg1107___r5_syntax_syntaxrules, 0L, 1 );
DEFINE_STRING( string1609___r5_syntax_syntaxrules, string1609___r5_syntax_syntaxrules1616, "Use of macro is not consistent with definition", 46 );
DEFINE_STRING( string1610___r5_syntax_syntaxrules, string1610___r5_syntax_syntaxrules1617, "Use of macro does not match definition", 38 );
DEFINE_STRING( string1607___r5_syntax_syntaxrules, string1607___r5_syntax_syntaxrules1618, "Too few ellipses follow pattern variable in template", 52 );
DEFINE_STRING( string1605___r5_syntax_syntaxrules, string1605___r5_syntax_syntaxrules1619, "Malformed pattern", 17 );
DEFINE_STRING( string1603___r5_syntax_syntaxrules, string1603___r5_syntax_syntaxrules1620, "Malformed syntax-rules", 22 );
DEFINE_STRING( string1601___r5_syntax_syntaxrules, string1601___r5_syntax_syntaxrules1621, "", 0 );
DEFINE_EXPORT_PROCEDURE( m_compile_transformer_spec_env_78___r5_syntax_syntaxrules, _m_compile_transformer_spec_248___r5_syntax_syntaxrules1622, _m_compile_transformer_spec_248___r5_syntax_syntaxrules, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___r5_syntax_syntaxrules(long checksum_1893, char * from_1894)
{
if(CBOOL(require_initialization_114___r5_syntax_syntaxrules)){
require_initialization_114___r5_syntax_syntaxrules = BBOOL(((bool_t)0));
cnst_init_137___r5_syntax_syntaxrules();
toplevel_init_63___r5_syntax_syntaxrules();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r5_syntax_syntaxrules()
{
symbol1599___r5_syntax_syntaxrules = string_to_symbol("V");
symbol1600___r5_syntax_syntaxrules = string_to_symbol("E");
return (symbol1604___r5_syntax_syntaxrules = string_to_symbol("MACRO"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r5_syntax_syntaxrules()
{
{
obj_t list1077_349;
list1077_349 = MAKE_PAIR(symbol1599___r5_syntax_syntaxrules, BNIL);
pattern_variable_flag_30___r5_syntax_syntaxrules = list1077_349;
}
{
obj_t list1080_352;
list1080_352 = MAKE_PAIR(symbol1600___r5_syntax_syntaxrules, BNIL);
ellipsis_pattern_flag_87___r5_syntax_syntaxrules = list1080_352;
}
ellipsis_template_flag_179___r5_syntax_syntaxrules = ellipsis_pattern_flag_87___r5_syntax_syntaxrules;
{
obj_t arg1082_354;
{
obj_t arg1085_357;
{
char * aux_1905;
aux_1905 = BSTRING_TO_STRING(string1601___r5_syntax_syntaxrules);
arg1085_357 = string_to_symbol(aux_1905);
}
{
obj_t v1002_1017;
v1002_1017 = create_vector(((long)3));
{
obj_t aux_1909;
aux_1909 = BINT(((long)0));
VECTOR_SET(v1002_1017, ((long)2), aux_1909);
}
VECTOR_SET(v1002_1017, ((long)1), arg1085_357);
VECTOR_SET(v1002_1017, ((long)0), pattern_variable_flag_30___r5_syntax_syntaxrules);
arg1082_354 = v1002_1017;
}
}
{
obj_t list1083_355;
list1083_355 = MAKE_PAIR(arg1082_354, BNIL);
return (empty_pattern_variable_environment_234___r5_syntax_syntaxrules = list1083_355,
BUNSPEC);
}
}
}


/* make-ellipsis-template */obj_t make_ellipsis_template_236___r5_syntax_syntaxrules(obj_t t_5, obj_t vars_6)
{
{
obj_t v1004_1048;
v1004_1048 = create_vector(((long)3));
VECTOR_SET(v1004_1048, ((long)2), vars_6);
VECTOR_SET(v1004_1048, ((long)1), t_5);
VECTOR_SET(v1004_1048, ((long)0), ellipsis_template_flag_179___r5_syntax_syntaxrules);
return v1004_1048;
}
}


/* patternvar? */bool_t patternvar__77___r5_syntax_syntaxrules(obj_t x_7)
{
if(VECTORP(x_7)){
bool_t test_1921;
{
obj_t aux_1922;
{
long aux_1923;
aux_1923 = VECTOR_LENGTH(x_7);
aux_1922 = BINT(aux_1923);
}
test_1921 = _2__95___r4_numbers_6_5(aux_1922, BINT(((long)3)));
}
if(test_1921){
obj_t aux_1928;
aux_1928 = VECTOR_REF(x_7, ((long)0));
return (aux_1928==pattern_variable_flag_30___r5_syntax_syntaxrules);
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* ellipsis-pattern? */bool_t ellipsis_pattern__85___r5_syntax_syntaxrules(obj_t x_8)
{
if(VECTORP(x_8)){
bool_t test_1933;
{
obj_t aux_1934;
{
long aux_1935;
aux_1935 = VECTOR_LENGTH(x_8);
aux_1934 = BINT(aux_1935);
}
test_1933 = _2__95___r4_numbers_6_5(aux_1934, BINT(((long)3)));
}
if(test_1933){
obj_t aux_1940;
aux_1940 = VECTOR_REF(x_8, ((long)0));
return (aux_1940==ellipsis_pattern_flag_87___r5_syntax_syntaxrules);
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* ellipsis-template? */bool_t ellipsis_template__189___r5_syntax_syntaxrules(obj_t x_9)
{
if(VECTORP(x_9)){
bool_t test_1945;
{
obj_t aux_1946;
{
long aux_1947;
aux_1947 = VECTOR_LENGTH(x_9);
aux_1946 = BINT(aux_1947);
}
test_1945 = _2__95___r4_numbers_6_5(aux_1946, BINT(((long)3)));
}
if(test_1945){
obj_t aux_1952;
aux_1952 = VECTOR_REF(x_9, ((long)0));
return (aux_1952==ellipsis_template_flag_179___r5_syntax_syntaxrules);
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* m-compile-transformer-spec */obj_t m_compile_transformer_spec_209___r5_syntax_syntaxrules(obj_t spec_18, obj_t env_19)
{
{
bool_t test1101_382;
{
bool_t test1127_420;
{
obj_t arg1130_423;
arg1130_423 = safe_length_235___r5_syntax_misc(spec_18);
test1127_420 = _2__206___r4_numbers_6_5(arg1130_423, BINT(((long)1)));
}
if(test1127_420){
obj_t arg1128_421;
arg1128_421 = syntactic_lookup_76___r5_syntax_syntaxenv(env_19, CAR(spec_18));
{
obj_t obj2_1120;
obj2_1120 = denotation_of_syntax_rules_73___r5_syntax_syntaxenv;
test1101_382 = (arg1128_421==obj2_1120);
}
}
 else {
test1101_382 = ((bool_t)0);
}
}
if(test1101_382){
obj_t literals_383;
obj_t rules_384;
{
obj_t aux_1963;
aux_1963 = CDR(spec_18);
literals_383 = CAR(aux_1963);
}
{
obj_t aux_1966;
aux_1966 = CDR(spec_18);
rules_384 = CDR(aux_1966);
}
{
bool_t test1102_385;
if(list__240___r4_pairs_and_lists_6_3(literals_383)){
bool_t test1106_389;
{
obj_t arg1107_1777;
arg1107_1777 = proc1602___r5_syntax_syntaxrules;
{
obj_t aux_1971;
aux_1971 = every1__242___r5_syntax_misc(arg1107_1777, rules_384);
test1106_389 = CBOOL(aux_1971);
}
}
if(test1106_389){
test1102_385 = ((bool_t)0);
}
 else {
test1102_385 = ((bool_t)1);
}
}
 else {
test1102_385 = ((bool_t)1);
}
if(test1102_385){
obj_t list1103_386;
list1103_386 = MAKE_PAIR(spec_18, BNIL);
m_error_176___r5_syntax_misc(string1603___r5_syntax_syntaxrules, list1103_386);
}
 else {
BUNSPEC;
}
}
{
obj_t arg1112_398;
obj_t arg1113_399;
arg1112_398 = symbol1604___r5_syntax_syntaxrules;
if(NULLP(rules_384)){
arg1113_399 = BNIL;
}
 else {
obj_t head1014_406;
head1014_406 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1012_407;
obj_t tail1015_408;
l1012_407 = rules_384;
tail1015_408 = head1014_406;
lname1013_409:
if(NULLP(l1012_407)){
arg1113_399 = CDR(head1014_406);
}
 else {
obj_t newtail1016_411;
{
obj_t arg1121_413;
{
obj_t rule_415;
rule_415 = CAR(l1012_407);
{
obj_t arg1132_1144;
{
obj_t aux_1985;
aux_1985 = CAR(rule_415);
arg1132_1144 = CDR(aux_1985);
}
{
obj_t arg1133_1776;
arg1133_1776 = make_fx_procedure(arg1133___r5_syntax_syntaxrules, ((long)2), ((long)2));
PROCEDURE_SET(arg1133_1776, ((long)0), rule_415);
PROCEDURE_SET(arg1133_1776, ((long)1), env_19);
arg1121_413 = m_compile_pattern_6___r5_syntax_syntaxrules(arg1132_1144, literals_383, env_19, arg1133_1776);
}
}
}
newtail1016_411 = MAKE_PAIR(arg1121_413, BNIL);
}
SET_CDR(tail1015_408, newtail1016_411);
{
obj_t tail1015_1996;
obj_t l1012_1994;
l1012_1994 = CDR(l1012_407);
tail1015_1996 = newtail1016_411;
tail1015_408 = tail1015_1996;
l1012_407 = l1012_1994;
goto lname1013_409;
}
}
}
}
{
obj_t list1114_400;
{
obj_t arg1115_401;
{
obj_t arg1116_402;
arg1116_402 = MAKE_PAIR(env_19, BNIL);
arg1115_401 = MAKE_PAIR(arg1113_399, arg1116_402);
}
list1114_400 = MAKE_PAIR(arg1112_398, arg1115_401);
}
return list1114_400;
}
}
}
 else {
obj_t list1125_418;
list1125_418 = MAKE_PAIR(spec_18, BNIL);
return m_error_176___r5_syntax_misc(string1603___r5_syntax_syntaxrules, list1125_418);
}
}
}


/* _m-compile-transformer-spec */obj_t _m_compile_transformer_spec_248___r5_syntax_syntaxrules(obj_t env_1778, obj_t spec_1779, obj_t env_1780)
{
return m_compile_transformer_spec_209___r5_syntax_syntaxrules(spec_1779, env_1780);
}


/* arg1133 */obj_t arg1133___r5_syntax_syntaxrules(obj_t env_1781, obj_t compiled_rule_132_1784, obj_t patternvars_1785)
{
{
obj_t rule_1782;
obj_t env_1783;
rule_1782 = PROCEDURE_REF(env_1781, ((long)0));
env_1783 = PROCEDURE_REF(env_1781, ((long)1));
{
obj_t compiled_rule_132_1147;
obj_t patternvars_1148;
compiled_rule_132_1147 = compiled_rule_132_1784;
patternvars_1148 = patternvars_1785;
{
obj_t arg1136_1153;
{
obj_t aux_2005;
{
obj_t aux_2006;
aux_2006 = CDR(rule_1782);
aux_2005 = CAR(aux_2006);
}
arg1136_1153 = m_compile_template_23___r5_syntax_syntaxrules(aux_2005, patternvars_1148, env_1783);
}
return MAKE_PAIR(compiled_rule_132_1147, arg1136_1153);
}
}
}
}


/* arg1107 */obj_t arg1107___r5_syntax_syntaxrules(obj_t env_1786, obj_t rule_1787)
{
{
obj_t rule_391;
{
bool_t aux_2011;
rule_391 = rule_1787;
{
bool_t _andtest_1011_1129;
{
obj_t arg1110_1130;
arg1110_1130 = safe_length_235___r5_syntax_misc(rule_391);
_andtest_1011_1129 = _2__95___r4_numbers_6_5(arg1110_1130, BINT(((long)2)));
}
if(_andtest_1011_1129){
obj_t aux_2016;
aux_2016 = CAR(rule_391);
aux_2011 = PAIRP(aux_2016);
}
 else {
aux_2011 = ((bool_t)0);
}
}
return BBOOL(aux_2011);
}
}
}


/* m-compile-pattern */obj_t m_compile_pattern_6___r5_syntax_syntaxrules(obj_t p_23, obj_t literals_24, obj_t env_25, obj_t k_26)
{
return loop___r5_syntax_syntaxrules(literals_24, env_25, p_23, BNIL, BINT(((long)0)), k_26);
}


/* loop */obj_t loop___r5_syntax_syntaxrules(obj_t literals_1794, obj_t env_1793, obj_t p_437, obj_t vars_438, obj_t rank_439, obj_t k_440)
{
loop___r5_syntax_syntaxrules:
if(SYMBOLP(p_437)){
{
bool_t test_2024;
{
obj_t aux_2025;
aux_2025 = memq___r4_pairs_and_lists_6_3(p_437, literals_1794);
test_2024 = CBOOL(aux_2025);
}
if(test_2024){
return PROCEDURE_ENTRY(k_440)(k_440, p_437, vars_438, BEOA);
}
 else {
obj_t var_444;
{
obj_t v1002_1187;
v1002_1187 = create_vector(((long)3));
VECTOR_SET(v1002_1187, ((long)2), rank_439);
VECTOR_SET(v1002_1187, ((long)1), p_437);
VECTOR_SET(v1002_1187, ((long)0), pattern_variable_flag_30___r5_syntax_syntaxrules);
var_444 = v1002_1187;
}
{
obj_t arg1144_445;
arg1144_445 = MAKE_PAIR(var_444, vars_438);
return PROCEDURE_ENTRY(k_440)(k_440, var_444, arg1144_445, BEOA);
}
}
}
}
 else {
if(NULLP(p_437)){
return PROCEDURE_ENTRY(k_440)(k_440, BNIL, vars_438, BEOA);
}
 else {
if(PAIRP(p_437)){
{
bool_t test1148_449;
{
bool_t test_2043;
{
obj_t aux_2044;
aux_2044 = CDR(p_437);
test_2043 = PAIRP(aux_2044);
}
if(test_2043){
bool_t test_2047;
{
obj_t aux_2048;
{
obj_t aux_2049;
aux_2049 = CDR(p_437);
aux_2048 = CAR(aux_2049);
}
test_2047 = SYMBOLP(aux_2048);
}
if(test_2047){
obj_t arg1170_479;
{
obj_t aux_2053;
{
obj_t aux_2054;
aux_2054 = CDR(p_437);
aux_2053 = CAR(aux_2054);
}
arg1170_479 = syntactic_lookup_76___r5_syntax_syntaxenv(env_1793, aux_2053);
}
{
obj_t obj2_1213;
obj2_1213 = denotation_of_____126___r5_syntax_syntaxenv;
test1148_449 = (arg1170_479==obj2_1213);
}
}
 else {
test1148_449 = ((bool_t)0);
}
}
 else {
test1148_449 = ((bool_t)0);
}
}
if(test1148_449){
bool_t test_2060;
{
obj_t aux_2061;
{
obj_t aux_2062;
aux_2062 = CDR(p_437);
aux_2061 = CDR(aux_2062);
}
test_2060 = NULLP(aux_2061);
}
if(test_2060){
obj_t arg1150_451;
obj_t arg1152_453;
arg1150_451 = CAR(p_437);
arg1152_453 = _2__168___r4_numbers_6_5(rank_439, BINT(((long)1)));
{
obj_t arg1153_1788;
arg1153_1788 = make_fx_procedure(arg1153___r5_syntax_syntaxrules, ((long)2), ((long)2));
PROCEDURE_SET(arg1153_1788, ((long)0), vars_438);
PROCEDURE_SET(arg1153_1788, ((long)1), k_440);
{
obj_t k_2075;
obj_t rank_2074;
obj_t vars_2073;
obj_t p_2072;
p_2072 = arg1150_451;
vars_2073 = BNIL;
rank_2074 = arg1152_453;
k_2075 = arg1153_1788;
k_440 = k_2075;
rank_439 = rank_2074;
vars_438 = vars_2073;
p_437 = p_2072;
goto loop___r5_syntax_syntaxrules;
}
}
}
 else {
obj_t list1157_461;
list1157_461 = MAKE_PAIR(p_437, BNIL);
return m_error_176___r5_syntax_misc(string1605___r5_syntax_syntaxrules, list1157_461);
}
}
 else {
obj_t arg1161_464;
arg1161_464 = CAR(p_437);
{
obj_t arg1162_1790;
arg1162_1790 = make_fx_procedure(arg1162___r5_syntax_syntaxrules, ((long)2), ((long)5));
PROCEDURE_SET(arg1162_1790, ((long)0), env_1793);
PROCEDURE_SET(arg1162_1790, ((long)1), literals_1794);
PROCEDURE_SET(arg1162_1790, ((long)2), p_437);
PROCEDURE_SET(arg1162_1790, ((long)3), k_440);
PROCEDURE_SET(arg1162_1790, ((long)4), rank_439);
{
obj_t k_2086;
obj_t p_2085;
p_2085 = arg1161_464;
k_2086 = arg1162_1790;
k_440 = k_2086;
p_437 = p_2085;
goto loop___r5_syntax_syntaxrules;
}
}
}
}
}
 else {
if(VECTORP(p_437)){
{
obj_t arg1175_484;
arg1175_484 = vector__list_155___r4_vectors_6_8(p_437);
{
obj_t arg1176_1791;
arg1176_1791 = make_fx_procedure(arg1176___r5_syntax_syntaxrules, ((long)2), ((long)1));
PROCEDURE_SET(arg1176_1791, ((long)0), k_440);
{
obj_t k_2093;
obj_t p_2092;
p_2092 = arg1175_484;
k_2093 = arg1176_1791;
k_440 = k_2093;
p_437 = p_2092;
goto loop___r5_syntax_syntaxrules;
}
}
}
}
 else {
return PROCEDURE_ENTRY(k_440)(k_440, p_437, vars_438, BEOA);
}
}
}
}
}


/* arg1153 */obj_t arg1153___r5_syntax_syntaxrules(obj_t env_1795, obj_t p_1798, obj_t vars1_1799)
{
{
obj_t vars_1796;
obj_t k_1797;
vars_1796 = PROCEDURE_REF(env_1795, ((long)0));
k_1797 = PROCEDURE_REF(env_1795, ((long)1));
{
obj_t p_455;
obj_t vars1_456;
p_455 = p_1798;
vars1_456 = vars1_1799;
{
obj_t arg1155_1220;
obj_t arg1156_1221;
{
obj_t v1003_1224;
v1003_1224 = create_vector(((long)3));
VECTOR_SET(v1003_1224, ((long)2), vars1_456);
VECTOR_SET(v1003_1224, ((long)1), p_455);
VECTOR_SET(v1003_1224, ((long)0), ellipsis_pattern_flag_87___r5_syntax_syntaxrules);
arg1155_1220 = v1003_1224;
}
arg1156_1221 = union2___r5_syntax_misc(vars1_456, vars_1796);
return PROCEDURE_ENTRY(k_1797)(k_1797, arg1155_1220, arg1156_1221, BEOA);
}
}
}
}


/* arg1162 */obj_t arg1162___r5_syntax_syntaxrules(obj_t env_1800, obj_t p1_1806, obj_t vars_1807)
{
{
obj_t env_1801;
obj_t literals_1802;
obj_t p_1803;
obj_t k_1804;
obj_t rank_1805;
env_1801 = PROCEDURE_REF(env_1800, ((long)0));
literals_1802 = PROCEDURE_REF(env_1800, ((long)1));
p_1803 = PROCEDURE_REF(env_1800, ((long)2));
k_1804 = PROCEDURE_REF(env_1800, ((long)3));
rank_1805 = PROCEDURE_REF(env_1800, ((long)4));
{
obj_t p1_466;
obj_t vars_467;
p1_466 = p1_1806;
vars_467 = vars_1807;
{
obj_t arg1164_1235;
arg1164_1235 = CDR(p_1803);
{
obj_t arg1165_1789;
arg1165_1789 = make_fx_procedure(arg1165___r5_syntax_syntaxrules, ((long)2), ((long)2));
PROCEDURE_SET(arg1165_1789, ((long)0), p1_466);
PROCEDURE_SET(arg1165_1789, ((long)1), k_1804);
return loop___r5_syntax_syntaxrules(literals_1802, env_1801, arg1164_1235, vars_467, rank_1805, arg1165_1789);
}
}
}
}
}


/* arg1165 */obj_t arg1165___r5_syntax_syntaxrules(obj_t env_1808, obj_t p2_1811, obj_t vars_1812)
{
{
obj_t p1_1809;
obj_t k_1810;
p1_1809 = PROCEDURE_REF(env_1808, ((long)0));
k_1810 = PROCEDURE_REF(env_1808, ((long)1));
{
obj_t p2_1237;
obj_t vars_1238;
p2_1237 = p2_1811;
vars_1238 = vars_1812;
{
obj_t arg1167_1241;
arg1167_1241 = MAKE_PAIR(p1_1809, p2_1237);
return PROCEDURE_ENTRY(k_1810)(k_1810, arg1167_1241, vars_1238, BEOA);
}
}
}
}


/* arg1176 */obj_t arg1176___r5_syntax_syntaxrules(obj_t env_1813, obj_t p_1815, obj_t vars_1816)
{
{
obj_t k_1814;
k_1814 = PROCEDURE_REF(env_1813, ((long)0));
{
obj_t p_486;
obj_t vars_487;
p_486 = p_1815;
vars_487 = vars_1816;
{
obj_t arg1178_1245;
{
obj_t v1017_1246;
v1017_1246 = create_vector(((long)1));
VECTOR_SET(v1017_1246, ((long)0), p_486);
arg1178_1245 = v1017_1246;
}
return PROCEDURE_ENTRY(k_1814)(k_1814, arg1178_1245, vars_487, BEOA);
}
}
}
}


/* m-compile-template */obj_t m_compile_template_23___r5_syntax_syntaxrules(obj_t t_27, obj_t vars_28, obj_t env_29)
{
{
obj_t arg1182_1825;
arg1182_1825 = proc1606___r5_syntax_syntaxrules;
return loop_1595___r5_syntax_syntaxrules(vars_28, env_29, t_27, BNIL, BNIL, BINT(((long)0)), BFALSE, arg1182_1825);
}
}


/* loop_1595 */obj_t loop_1595___r5_syntax_syntaxrules(obj_t vars_1827, obj_t env_1826, obj_t t_539, obj_t inserted_540, obj_t referenced_541, obj_t rank_542, obj_t escaped__103_543, obj_t k_544)
{
loop_1595___r5_syntax_syntaxrules:
if(SYMBOLP(t_539)){
{
obj_t x_547;
x_547 = pattern_variable_1596_197___r5_syntax_syntaxrules(t_539, vars_1827);
if(CBOOL(x_547)){
if(_2___235___r4_numbers_6_5(rank_542, VECTOR_REF(x_547, ((long)2)))){
obj_t arg1207_549;
arg1207_549 = MAKE_PAIR(x_547, referenced_541);
return PROCEDURE_ENTRY(k_544)(k_544, x_547, inserted_540, arg1207_549, BEOA);
}
 else {
obj_t list1211_552;
{
obj_t aux_2138;
aux_2138 = VECTOR_REF(x_547, ((long)1));
list1211_552 = MAKE_PAIR(aux_2138, BNIL);
}
return m_error_176___r5_syntax_misc(string1607___r5_syntax_syntaxrules, list1211_552);
}
}
 else {
obj_t arg1216_555;
arg1216_555 = MAKE_PAIR(t_539, inserted_540);
return PROCEDURE_ENTRY(k_544)(k_544, t_539, arg1216_555, referenced_541, BEOA);
}
}
}
 else {
if(NULLP(t_539)){
return PROCEDURE_ENTRY(k_544)(k_544, BNIL, inserted_540, referenced_541, BEOA);
}
 else {
if(PAIRP(t_539)){
{
bool_t test1221_559;
if(CBOOL(escaped__103_543)){
test1221_559 = ((bool_t)0);
}
 else {
bool_t test_2153;
{
obj_t aux_2154;
aux_2154 = CAR(t_539);
test_2153 = SYMBOLP(aux_2154);
}
if(test_2153){
bool_t test1243_584;
{
obj_t arg1248_588;
arg1248_588 = syntactic_lookup_76___r5_syntax_syntaxenv(env_1826, CAR(t_539));
{
obj_t obj2_1335;
obj2_1335 = denotation_of_____90___r5_syntax_syntaxenv;
test1243_584 = (arg1248_588==obj2_1335);
}
}
if(test1243_584){
bool_t test_2161;
{
obj_t aux_2162;
aux_2162 = CDR(t_539);
test_2161 = PAIRP(aux_2162);
}
if(test_2161){
obj_t aux_2165;
{
obj_t aux_2166;
aux_2166 = CDR(t_539);
aux_2165 = CDR(aux_2166);
}
test1221_559 = NULLP(aux_2165);
}
 else {
test1221_559 = ((bool_t)0);
}
}
 else {
test1221_559 = ((bool_t)0);
}
}
 else {
test1221_559 = ((bool_t)0);
}
}
if(test1221_559){
{
obj_t escaped__103_2175;
obj_t t_2171;
{
obj_t aux_2172;
aux_2172 = CDR(t_539);
t_2171 = CAR(aux_2172);
}
escaped__103_2175 = BTRUE;
escaped__103_543 = escaped__103_2175;
t_539 = t_2171;
goto loop_1595___r5_syntax_syntaxrules;
}
}
 else {
bool_t test1223_561;
if(CBOOL(escaped__103_543)){
test1223_561 = ((bool_t)0);
}
 else {
bool_t test_2178;
{
obj_t aux_2179;
aux_2179 = CDR(t_539);
test_2178 = PAIRP(aux_2179);
}
if(test_2178){
bool_t test_2182;
{
obj_t aux_2183;
{
obj_t aux_2184;
aux_2184 = CDR(t_539);
aux_2183 = CAR(aux_2184);
}
test_2182 = SYMBOLP(aux_2183);
}
if(test_2182){
obj_t arg1236_579;
{
obj_t aux_2188;
{
obj_t aux_2189;
aux_2189 = CDR(t_539);
aux_2188 = CAR(aux_2189);
}
arg1236_579 = syntactic_lookup_76___r5_syntax_syntaxenv(env_1826, aux_2188);
}
{
obj_t obj2_1359;
obj2_1359 = denotation_of_____126___r5_syntax_syntaxenv;
test1223_561 = (arg1236_579==obj2_1359);
}
}
 else {
test1223_561 = ((bool_t)0);
}
}
 else {
test1223_561 = ((bool_t)0);
}
}
if(test1223_561){
{
obj_t arg1188_1366;
obj_t arg1190_1368;
arg1188_1366 = CAR(t_539);
arg1190_1368 = _2__168___r4_numbers_6_5(rank_542, BINT(((long)1)));
{
obj_t arg1191_1820;
arg1191_1820 = make_fx_procedure(arg1191___r5_syntax_syntaxrules, ((long)3), ((long)7));
PROCEDURE_SET(arg1191_1820, ((long)0), env_1826);
PROCEDURE_SET(arg1191_1820, ((long)1), vars_1827);
PROCEDURE_SET(arg1191_1820, ((long)2), t_539);
PROCEDURE_SET(arg1191_1820, ((long)3), referenced_541);
PROCEDURE_SET(arg1191_1820, ((long)4), rank_542);
PROCEDURE_SET(arg1191_1820, ((long)5), k_544);
PROCEDURE_SET(arg1191_1820, ((long)6), escaped__103_543);
{
obj_t k_2209;
obj_t rank_2208;
obj_t referenced_2207;
obj_t t_2206;
t_2206 = arg1188_1366;
referenced_2207 = BNIL;
rank_2208 = arg1190_1368;
k_2209 = arg1191_1820;
k_544 = k_2209;
rank_542 = rank_2208;
referenced_541 = referenced_2207;
t_539 = t_2206;
goto loop_1595___r5_syntax_syntaxrules;
}
}
}
}
 else {
{
obj_t arg1224_562;
arg1224_562 = CAR(t_539);
{
obj_t arg1225_1822;
arg1225_1822 = make_fx_procedure(arg1225___r5_syntax_syntaxrules, ((long)3), ((long)6));
PROCEDURE_SET(arg1225_1822, ((long)0), env_1826);
PROCEDURE_SET(arg1225_1822, ((long)1), vars_1827);
PROCEDURE_SET(arg1225_1822, ((long)2), t_539);
PROCEDURE_SET(arg1225_1822, ((long)3), k_544);
PROCEDURE_SET(arg1225_1822, ((long)4), rank_542);
PROCEDURE_SET(arg1225_1822, ((long)5), escaped__103_543);
{
obj_t k_2219;
obj_t t_2218;
t_2218 = arg1224_562;
k_2219 = arg1225_1822;
k_544 = k_2219;
t_539 = t_2218;
goto loop_1595___r5_syntax_syntaxrules;
}
}
}
}
}
}
}
 else {
if(VECTORP(t_539)){
{
obj_t arg1253_592;
arg1253_592 = vector__list_155___r4_vectors_6_8(t_539);
{
obj_t arg1254_1823;
arg1254_1823 = make_fx_procedure(arg1254___r5_syntax_syntaxrules, ((long)3), ((long)1));
PROCEDURE_SET(arg1254_1823, ((long)0), k_544);
{
obj_t k_2226;
obj_t t_2225;
t_2225 = arg1253_592;
k_2226 = arg1254_1823;
k_544 = k_2226;
t_539 = t_2225;
goto loop_1595___r5_syntax_syntaxrules;
}
}
}
}
 else {
return PROCEDURE_ENTRY(k_544)(k_544, t_539, inserted_540, referenced_541, BEOA);
}
}
}
}
}


/* pattern-variable_1596 */obj_t pattern_variable_1596_197___r5_syntax_syntaxrules(obj_t t_1828, obj_t vars_1304)
{
pattern_variable_1596_197___r5_syntax_syntaxrules:
if(NULLP(vars_1304)){
return BFALSE;
}
 else {
bool_t test_2231;
{
obj_t aux_2232;
{
obj_t aux_2233;
aux_2233 = CAR(vars_1304);
aux_2232 = VECTOR_REF(aux_2233, ((long)1));
}
test_2231 = (t_1828==aux_2232);
}
if(test_2231){
return CAR(vars_1304);
}
 else {
{
obj_t vars_2238;
vars_2238 = CDR(vars_1304);
vars_1304 = vars_2238;
goto pattern_variable_1596_197___r5_syntax_syntaxrules;
}
}
}
}


/* arg1182 */obj_t arg1182___r5_syntax_syntaxrules(obj_t env_1829, obj_t t_1830, obj_t inserted_1831, obj_t referenced_1832)
{
{
obj_t t_499;
obj_t inserted_500;
obj_t referenced_501;
t_499 = t_1830;
inserted_500 = inserted_1831;
referenced_501 = referenced_1832;
{
obj_t list1184_1250;
{
obj_t arg1185_1251;
arg1185_1251 = MAKE_PAIR(inserted_500, BNIL);
list1184_1250 = MAKE_PAIR(t_499, arg1185_1251);
}
return list1184_1250;
}
}
}


/* arg1191 */obj_t arg1191___r5_syntax_syntaxrules(obj_t env_1833, obj_t t1_1841, obj_t inserted_1842, obj_t referenced1_1843)
{
{
obj_t env_1834;
obj_t vars_1835;
obj_t t_1836;
obj_t referenced_1837;
obj_t rank_1838;
obj_t k_1839;
obj_t escaped__103_1840;
env_1834 = PROCEDURE_REF(env_1833, ((long)0));
vars_1835 = PROCEDURE_REF(env_1833, ((long)1));
t_1836 = PROCEDURE_REF(env_1833, ((long)2));
referenced_1837 = PROCEDURE_REF(env_1833, ((long)3));
rank_1838 = PROCEDURE_REF(env_1833, ((long)4));
k_1839 = PROCEDURE_REF(env_1833, ((long)5));
escaped__103_1840 = PROCEDURE_REF(env_1833, ((long)6));
{
obj_t t1_1370;
obj_t inserted_1371;
obj_t referenced1_1372;
t1_1370 = t1_1841;
inserted_1371 = inserted_1842;
referenced1_1372 = referenced1_1843;
{
obj_t arg1193_1373;
obj_t arg1194_1374;
{
obj_t aux_2249;
aux_2249 = CDR(t_1836);
arg1193_1373 = CDR(aux_2249);
}
arg1194_1374 = append_2_18___r4_pairs_and_lists_6_3(referenced1_1372, referenced_1837);
{
obj_t arg1195_1819;
arg1195_1819 = make_fx_procedure(arg1195___r5_syntax_syntaxrules, ((long)3), ((long)4));
PROCEDURE_SET(arg1195_1819, ((long)0), rank_1838);
PROCEDURE_SET(arg1195_1819, ((long)1), referenced1_1372);
PROCEDURE_SET(arg1195_1819, ((long)2), t1_1370);
PROCEDURE_SET(arg1195_1819, ((long)3), k_1839);
return loop_1595___r5_syntax_syntaxrules(vars_1835, env_1834, arg1193_1373, inserted_1371, arg1194_1374, rank_1838, escaped__103_1840, arg1195_1819);
}
}
}
}
}


/* arg1195 */obj_t arg1195___r5_syntax_syntaxrules(obj_t env_1844, obj_t t2_1849, obj_t inserted_1850, obj_t referenced_1851)
{
{
obj_t rank_1845;
obj_t referenced1_1846;
obj_t t1_1847;
obj_t k_1848;
rank_1845 = PROCEDURE_REF(env_1844, ((long)0));
referenced1_1846 = PROCEDURE_REF(env_1844, ((long)1));
t1_1847 = PROCEDURE_REF(env_1844, ((long)2));
k_1848 = PROCEDURE_REF(env_1844, ((long)3));
{
obj_t t2_1376;
obj_t inserted_1377;
obj_t referenced_1378;
t2_1376 = t2_1849;
inserted_1377 = inserted_1850;
referenced_1378 = referenced_1851;
{
obj_t arg1197_1390;
{
obj_t arg1199_1391;
{
obj_t arg1200_1392;
{
obj_t arg1201_1818;
arg1201_1818 = make_fx_procedure(arg1201___r5_syntax_syntaxrules, ((long)1), ((long)1));
PROCEDURE_SET(arg1201_1818, ((long)0), rank_1845);
arg1200_1392 = filter1___r5_syntax_misc(arg1201_1818, referenced1_1846);
}
arg1199_1391 = make_ellipsis_template_236___r5_syntax_syntaxrules(t1_1847, arg1200_1392);
}
arg1197_1390 = MAKE_PAIR(arg1199_1391, t2_1376);
}
return PROCEDURE_ENTRY(k_1848)(k_1848, arg1197_1390, inserted_1377, referenced_1378, BEOA);
}
}
}
}


/* arg1201 */obj_t arg1201___r5_syntax_syntaxrules(obj_t env_1852, obj_t var_1854)
{
{
obj_t rank_1853;
rank_1853 = PROCEDURE_REF(env_1852, ((long)0));
{
obj_t var_1394;
{
bool_t aux_2271;
var_1394 = var_1854;
aux_2271 = _2__206___r4_numbers_6_5(VECTOR_REF(var_1394, ((long)2)), rank_1853);
return BBOOL(aux_2271);
}
}
}
}


/* arg1225 */obj_t arg1225___r5_syntax_syntaxrules(obj_t env_1855, obj_t t1_1862, obj_t inserted_1863, obj_t referenced_1864)
{
{
obj_t env_1856;
obj_t vars_1857;
obj_t t_1858;
obj_t k_1859;
obj_t rank_1860;
obj_t escaped__103_1861;
env_1856 = PROCEDURE_REF(env_1855, ((long)0));
vars_1857 = PROCEDURE_REF(env_1855, ((long)1));
t_1858 = PROCEDURE_REF(env_1855, ((long)2));
k_1859 = PROCEDURE_REF(env_1855, ((long)3));
rank_1860 = PROCEDURE_REF(env_1855, ((long)4));
escaped__103_1861 = PROCEDURE_REF(env_1855, ((long)5));
{
obj_t t1_564;
obj_t inserted_565;
obj_t referenced_566;
t1_564 = t1_1862;
inserted_565 = inserted_1863;
referenced_566 = referenced_1864;
{
obj_t arg1228_1403;
arg1228_1403 = CDR(t_1858);
{
obj_t arg1231_1821;
arg1231_1821 = make_fx_procedure(arg1231___r5_syntax_syntaxrules, ((long)3), ((long)2));
PROCEDURE_SET(arg1231_1821, ((long)0), t1_564);
PROCEDURE_SET(arg1231_1821, ((long)1), k_1859);
return loop_1595___r5_syntax_syntaxrules(vars_1857, env_1856, arg1228_1403, inserted_565, referenced_566, rank_1860, escaped__103_1861, arg1231_1821);
}
}
}
}
}


/* arg1231 */obj_t arg1231___r5_syntax_syntaxrules(obj_t env_1865, obj_t t2_1868, obj_t inserted_1869, obj_t referenced_1870)
{
{
obj_t t1_1866;
obj_t k_1867;
t1_1866 = PROCEDURE_REF(env_1865, ((long)0));
k_1867 = PROCEDURE_REF(env_1865, ((long)1));
{
obj_t t2_1405;
obj_t inserted_1406;
obj_t referenced_1407;
t2_1405 = t2_1868;
inserted_1406 = inserted_1869;
referenced_1407 = referenced_1870;
{
obj_t arg1233_1410;
arg1233_1410 = MAKE_PAIR(t1_1866, t2_1405);
return PROCEDURE_ENTRY(k_1867)(k_1867, arg1233_1410, inserted_1406, referenced_1407, BEOA);
}
}
}
}


/* arg1254 */obj_t arg1254___r5_syntax_syntaxrules(obj_t env_1871, obj_t t_1873, obj_t inserted_1874, obj_t referenced_1875)
{
{
obj_t k_1872;
k_1872 = PROCEDURE_REF(env_1871, ((long)0));
{
obj_t t_594;
obj_t inserted_595;
obj_t referenced_596;
t_594 = t_1873;
inserted_595 = inserted_1874;
referenced_596 = referenced_1875;
{
obj_t arg1256_1414;
{
obj_t v1018_1415;
v1018_1415 = create_vector(((long)1));
VECTOR_SET(v1018_1415, ((long)0), t_594);
arg1256_1414 = v1018_1415;
}
return PROCEDURE_ENTRY(k_1872)(k_1872, arg1256_1414, inserted_595, referenced_596, BEOA);
}
}
}
}


/* m-match */obj_t m_match_26___r5_syntax_syntaxrules(obj_t f_30, obj_t p_31, obj_t env_def_34_32, obj_t env_use_213_33)
{
return match___r5_syntax_syntaxrules(env_use_213_33, env_def_34_32, f_30, p_31, empty_pattern_variable_environment_234___r5_syntax_syntaxrules, BINT(((long)0)));
}


/* match */obj_t match___r5_syntax_syntaxrules(obj_t env_use_213_1891, obj_t env_def_34_1890, obj_t f_680, obj_t p_681, obj_t answer_682, obj_t rank_683)
{
match___r5_syntax_syntaxrules:
{
obj_t f_605;
obj_t p_606;
obj_t answer_607;
obj_t rank_608;
if(NULLP(p_681)){
if(NULLP(f_680)){
return answer_682;
}
 else {
return BFALSE;
}
}
 else {
if(PAIRP(p_681)){
if(PAIRP(f_680)){
obj_t answer_689;
answer_689 = match___r5_syntax_syntaxrules(env_use_213_1891, env_def_34_1890, CAR(f_680), CAR(p_681), answer_682, rank_683);
if(CBOOL(answer_689)){
obj_t answer_2315;
obj_t p_2313;
obj_t f_2311;
f_2311 = CDR(f_680);
p_2313 = CDR(p_681);
answer_2315 = answer_689;
answer_682 = answer_2315;
p_681 = p_2313;
f_680 = f_2311;
goto match___r5_syntax_syntaxrules;
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if(SYMBOLP(p_681)){
if(SYMBOLP(f_680)){
obj_t _andtest_1023_697;
{
obj_t arg1313_698;
obj_t arg1315_699;
arg1313_698 = syntactic_lookup_76___r5_syntax_syntaxenv(env_def_34_1890, p_681);
arg1315_699 = syntactic_lookup_76___r5_syntax_syntaxenv(env_use_213_1891, f_680);
_andtest_1023_697 = same_denotation__10___r5_syntax_syntaxenv(arg1313_698, arg1315_699);
}
if(CBOOL(_andtest_1023_697)){
return answer_682;
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if(patternvar__77___r5_syntax_syntaxrules(p_681)){
{
obj_t arg1319_701;
arg1319_701 = MAKE_PAIR(p_681, f_680);
return MAKE_PAIR(arg1319_701, answer_682);
}
}
 else {
if(ellipsis_pattern__85___r5_syntax_syntaxrules(p_681)){
f_605 = f_680;
p_606 = p_681;
answer_607 = answer_682;
rank_608 = _2__168___r4_numbers_6_5(rank_683, BINT(((long)1)));
if(list__240___r4_pairs_and_lists_6_3(f_605)){
bool_t test1259_611;
test1259_611 = NULLP(f_605);
if(test1259_611){
{
obj_t arg1260_612;
{
obj_t l1026_613;
l1026_613 = VECTOR_REF(p_606, ((long)2));
if(NULLP(l1026_613)){
arg1260_612 = BNIL;
}
 else {
obj_t head1028_615;
head1028_615 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1026_616;
obj_t tail1029_617;
l1026_616 = l1026_613;
tail1029_617 = head1028_615;
lname1027_618:
if(NULLP(l1026_616)){
arg1260_612 = CDR(head1028_615);
}
 else {
obj_t newtail1030_620;
{
obj_t arg1265_622;
{
obj_t aux_2342;
aux_2342 = CAR(l1026_616);
arg1265_622 = MAKE_PAIR(aux_2342, BNIL);
}
newtail1030_620 = MAKE_PAIR(arg1265_622, BNIL);
}
SET_CDR(tail1029_617, newtail1030_620);
{
obj_t tail1029_2349;
obj_t l1026_2347;
l1026_2347 = CDR(l1026_616);
tail1029_2349 = newtail1030_620;
tail1029_617 = tail1029_2349;
l1026_616 = l1026_2347;
goto lname1027_618;
}
}
}
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1260_612, answer_607);
}
}
 else {
{
obj_t p1_628;
p1_628 = VECTOR_REF(p_606, ((long)1));
{
obj_t answers_629;
if(test1259_611){
answers_629 = BNIL;
}
 else {
obj_t head1033_668;
head1033_668 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1031_669;
obj_t tail1034_670;
l1031_669 = f_605;
tail1034_670 = head1033_668;
lname1032_671:
if(NULLP(l1031_669)){
answers_629 = CDR(head1033_668);
}
 else {
obj_t newtail1035_673;
{
obj_t arg1300_675;
arg1300_675 = match___r5_syntax_syntaxrules(env_use_213_1891, env_def_34_1890, CAR(l1031_669), p1_628, answer_607, rank_608);
newtail1035_673 = MAKE_PAIR(arg1300_675, BNIL);
}
SET_CDR(tail1034_670, newtail1035_673);
{
obj_t tail1034_2363;
obj_t l1031_2361;
l1031_2361 = CDR(l1031_669);
tail1034_2363 = newtail1035_673;
tail1034_670 = tail1034_2363;
l1031_669 = l1031_2361;
goto lname1032_671;
}
}
}
}
{
{
bool_t test1271_630;
{
obj_t arg1295_1876;
arg1295_1876 = proc1608___r5_syntax_syntaxrules;
{
obj_t aux_2364;
aux_2364 = every1__242___r5_syntax_misc(arg1295_1876, answers_629);
test1271_630 = CBOOL(aux_2364);
}
}
if(test1271_630){
obj_t arg1272_631;
{
obj_t l1036_632;
l1036_632 = VECTOR_REF(p_606, ((long)2));
if(NULLP(l1036_632)){
arg1272_631 = BNIL;
}
 else {
obj_t head1038_634;
head1038_634 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1036_635;
obj_t tail1039_636;
l1036_635 = l1036_632;
tail1039_636 = head1038_634;
lname1037_637:
if(NULLP(l1036_635)){
arg1272_631 = CDR(head1038_634);
}
 else {
obj_t newtail1040_639;
{
obj_t arg1278_641;
{
obj_t var_643;
var_643 = CAR(l1036_635);
{
obj_t arg1282_644;
if(NULLP(answers_629)){
arg1282_644 = BNIL;
}
 else {
obj_t head1043_647;
head1043_647 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1041_648;
obj_t tail1044_649;
l1041_648 = answers_629;
tail1044_649 = head1043_647;
lname1042_650:
if(NULLP(l1041_648)){
arg1282_644 = CDR(head1043_647);
}
 else {
obj_t newtail1045_652;
{
obj_t aux_2382;
{
obj_t aux_2383;
aux_2383 = assq___r4_pairs_and_lists_6_3(var_643, CAR(l1041_648));
aux_2382 = CDR(aux_2383);
}
newtail1045_652 = MAKE_PAIR(aux_2382, BNIL);
}
SET_CDR(tail1044_649, newtail1045_652);
{
obj_t tail1044_2391;
obj_t l1041_2389;
l1041_2389 = CDR(l1041_648);
tail1044_2391 = newtail1045_652;
tail1044_649 = tail1044_2391;
l1041_648 = l1041_2389;
goto lname1042_650;
}
}
}
}
arg1278_641 = MAKE_PAIR(var_643, arg1282_644);
}
}
newtail1040_639 = MAKE_PAIR(arg1278_641, BNIL);
}
SET_CDR(tail1039_636, newtail1040_639);
{
obj_t tail1039_2397;
obj_t l1036_2395;
l1036_2395 = CDR(l1036_635);
tail1039_2397 = newtail1040_639;
tail1039_636 = tail1039_2397;
l1036_635 = l1036_2395;
goto lname1037_637;
}
}
}
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1272_631, answer_607);
}
 else {
return BFALSE;
}
}
}
}
}
}
}
 else {
return BFALSE;
}
}
 else {
if(VECTORP(p_681)){
if(VECTORP(f_680)){
obj_t arg1323_706;
obj_t arg1324_707;
arg1323_706 = vector__list_155___r4_vectors_6_8(f_680);
arg1324_707 = VECTOR_REF(p_681, ((long)0));
{
obj_t p_2408;
obj_t f_2407;
f_2407 = arg1323_706;
p_2408 = arg1324_707;
p_681 = p_2408;
f_680 = f_2407;
goto match___r5_syntax_syntaxrules;
}
}
 else {
return BFALSE;
}
}
 else {
if(equal__25___r4_equivalence_6_2(f_680, p_681)){
return answer_682;
}
 else {
return BFALSE;
}
}
}
}
}
}
}
}
}


/* arg1295 */obj_t arg1295___r5_syntax_syntaxrules(obj_t env_1877, obj_t answer_1878)
{
{
obj_t answer_1892;
answer_1892 = answer_1878;
return answer_1892;
}
}


/* m-rewrite */obj_t m_rewrite_211___r5_syntax_syntaxrules(obj_t t_34, obj_t alist_35)
{
return rewrite___r5_syntax_syntaxrules(t_34, alist_35, BINT(((long)0)));
}


/* loop_1598 */obj_t loop_1598___r5_syntax_syntaxrules(obj_t alist_1889, obj_t vars_1888, obj_t rows_744)
{
{
bool_t test_2413;
{
obj_t aux_2414;
aux_2414 = CAR(rows_744);
test_2413 = NULLP(aux_2414);
}
if(test_2413){
return BNIL;
}
 else {
obj_t arg1352_747;
obj_t arg1353_748;
{
obj_t arg1355_749;
if(NULLP(vars_1888)){
arg1355_749 = BNIL;
}
 else {
obj_t head1058_753;
head1058_753 = MAKE_PAIR(BNIL, BNIL);
{
obj_t ll1056_1563;
obj_t ll1057_1564;
obj_t tail1059_1565;
ll1056_1563 = vars_1888;
ll1057_1564 = rows_744;
tail1059_1565 = head1058_753;
lname1061_1562:
if(NULLP(ll1056_1563)){
arg1355_749 = CDR(head1058_753);
}
 else {
obj_t newtail1060_1576;
{
obj_t arg1364_1577;
{
obj_t aux_2425;
obj_t aux_2423;
{
obj_t aux_2426;
aux_2426 = CAR(ll1057_1564);
aux_2425 = CAR(aux_2426);
}
aux_2423 = CAR(ll1056_1563);
arg1364_1577 = MAKE_PAIR(aux_2423, aux_2425);
}
newtail1060_1576 = MAKE_PAIR(arg1364_1577, BNIL);
}
SET_CDR(tail1059_1565, newtail1060_1576);
{
obj_t tail1059_2436;
obj_t ll1057_2434;
obj_t ll1056_2432;
ll1056_2432 = CDR(ll1056_1563);
ll1057_2434 = CDR(ll1057_1564);
tail1059_2436 = newtail1060_1576;
tail1059_1565 = tail1059_2436;
ll1057_1564 = ll1057_2434;
ll1056_1563 = ll1056_2432;
goto lname1061_1562;
}
}
}
}
arg1352_747 = append_2_18___r4_pairs_and_lists_6_3(arg1355_749, alist_1889);
}
{
obj_t arg1370_769;
if(NULLP(rows_744)){
arg1370_769 = BNIL;
}
 else {
obj_t head1064_772;
{
obj_t aux_2440;
{
obj_t aux_2441;
aux_2441 = CAR(rows_744);
aux_2440 = CDR(aux_2441);
}
head1064_772 = MAKE_PAIR(aux_2440, BNIL);
}
{
obj_t l1062_1651;
obj_t tail1065_1652;
l1062_1651 = CDR(rows_744);
tail1065_1652 = head1064_772;
lname1063_1650:
if(NULLP(l1062_1651)){
arg1370_769 = head1064_772;
}
 else {
obj_t newtail1066_1660;
{
obj_t aux_2447;
{
obj_t aux_2448;
aux_2448 = CAR(l1062_1651);
aux_2447 = CDR(aux_2448);
}
newtail1066_1660 = MAKE_PAIR(aux_2447, BNIL);
}
SET_CDR(tail1065_1652, newtail1066_1660);
{
obj_t tail1065_2455;
obj_t l1062_2453;
l1062_2453 = CDR(l1062_1651);
tail1065_2455 = newtail1066_1660;
tail1065_1652 = tail1065_2455;
l1062_1651 = l1062_2453;
goto lname1063_1650;
}
}
}
}
arg1353_748 = loop_1598___r5_syntax_syntaxrules(alist_1889, vars_1888, arg1370_769);
}
return MAKE_PAIR(arg1352_747, arg1353_748);
}
}
}


/* make-columns */obj_t make_columns_212___r5_syntax_syntaxrules(obj_t vars_714, obj_t rows_715, obj_t alist_716)
{
{
bool_t test1326_719;
{
bool_t test_2459;
{
obj_t aux_2460;
aux_2460 = CDR(rows_715);
test_2459 = NULLP(aux_2460);
}
if(test_2459){
test1326_719 = ((bool_t)1);
}
 else {
obj_t runner1348_742;
if(NULLP(rows_715)){
runner1348_742 = BNIL;
}
 else {
obj_t head1069_726;
{
obj_t aux_2465;
{
long aux_2466;
aux_2466 = list_length(CAR(rows_715));
aux_2465 = BINT(aux_2466);
}
head1069_726 = MAKE_PAIR(aux_2465, BNIL);
}
{
obj_t l1067_1504;
obj_t tail1070_1505;
l1067_1504 = CDR(rows_715);
tail1070_1505 = head1069_726;
lname1068_1503:
if(NULLP(l1067_1504)){
runner1348_742 = head1069_726;
}
 else {
obj_t newtail1071_1513;
{
obj_t aux_2473;
{
long aux_2474;
aux_2474 = list_length(CAR(l1067_1504));
aux_2473 = BINT(aux_2474);
}
newtail1071_1513 = MAKE_PAIR(aux_2473, BNIL);
}
SET_CDR(tail1070_1505, newtail1071_1513);
{
obj_t tail1070_2482;
obj_t l1067_2480;
l1067_2480 = CDR(l1067_1504);
tail1070_2482 = newtail1071_1513;
tail1070_1505 = tail1070_2482;
l1067_1504 = l1067_2480;
goto lname1068_1503;
}
}
}
}
{
obj_t aux1346_740;
{
obj_t pair_1553;
pair_1553 = runner1348_742;
aux1346_740 = CAR(pair_1553);
}
{
obj_t pair_1554;
pair_1554 = runner1348_742;
runner1348_742 = CDR(pair_1554);
}
{
obj_t aux1347_741;
{
obj_t pair_1555;
pair_1555 = runner1348_742;
aux1347_741 = CAR(pair_1555);
}
{
obj_t pair_1556;
pair_1556 = runner1348_742;
runner1348_742 = CDR(pair_1556);
}
test1326_719 = __147___r4_numbers_6_5(aux1346_740, aux1347_741, runner1348_742);
}
}
}
}
if(test1326_719){
return loop_1598___r5_syntax_syntaxrules(alist_716, vars_714, rows_715);
}
 else {
obj_t list1327_720;
{
obj_t arg1328_721;
arg1328_721 = MAKE_PAIR(rows_715, BNIL);
list1327_720 = MAKE_PAIR(vars_714, arg1328_721);
}
return m_error_176___r5_syntax_misc(string1609___r5_syntax_syntaxrules, list1327_720);
}
}
}


/* rewrite */obj_t rewrite___r5_syntax_syntaxrules(obj_t t_824, obj_t alist_825, obj_t rank_826)
{
{
obj_t t_788;
obj_t alist_789;
obj_t rank_790;
if(NULLP(t_824)){
return BNIL;
}
 else {
if(PAIRP(t_824)){
{
obj_t fun1416_832;
if(ellipsis_pattern__85___r5_syntax_syntaxrules(CAR(t_824))){
fun1416_832 = append_env_23___r4_pairs_and_lists_6_3;
}
 else {
fun1416_832 = cons_env_70___r4_pairs_and_lists_6_3;
}
{
obj_t arg1414_833;
obj_t arg1415_834;
arg1414_833 = rewrite___r5_syntax_syntaxrules(CAR(t_824), alist_825, rank_826);
arg1415_834 = rewrite___r5_syntax_syntaxrules(CDR(t_824), alist_825, rank_826);
return PROCEDURE_ENTRY(fun1416_832)(fun1416_832, arg1414_833, arg1415_834, BEOA);
}
}
}
 else {
if(SYMBOLP(t_824)){
{
obj_t aux_2509;
aux_2509 = assq___r4_pairs_and_lists_6_3(t_824, alist_825);
return CDR(aux_2509);
}
}
 else {
if(patternvar__77___r5_syntax_syntaxrules(t_824)){
{
obj_t aux_2514;
aux_2514 = assq___r4_pairs_and_lists_6_3(t_824, alist_825);
return CDR(aux_2514);
}
}
 else {
if(ellipsis_template__189___r5_syntax_syntaxrules(t_824)){
t_788 = t_824;
alist_789 = alist_825;
rank_790 = _2__168___r4_numbers_6_5(rank_826, BINT(((long)1)));
{
obj_t t1_792;
t1_792 = VECTOR_REF(t_788, ((long)1));
{
obj_t vars_793;
vars_793 = VECTOR_REF(t_788, ((long)2));
{
obj_t rows_794;
if(NULLP(vars_793)){
rows_794 = BNIL;
}
 else {
obj_t head1048_811;
head1048_811 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1046_812;
obj_t tail1049_813;
l1046_812 = vars_793;
tail1049_813 = head1048_811;
lname1047_814:
if(NULLP(l1046_812)){
rows_794 = CDR(head1048_811);
}
 else {
obj_t newtail1050_816;
{
obj_t aux_2527;
{
obj_t aux_2528;
aux_2528 = assq___r4_pairs_and_lists_6_3(CAR(l1046_812), alist_789);
aux_2527 = CDR(aux_2528);
}
newtail1050_816 = MAKE_PAIR(aux_2527, BNIL);
}
SET_CDR(tail1049_813, newtail1050_816);
{
obj_t tail1049_2536;
obj_t l1046_2534;
l1046_2534 = CDR(l1046_812);
tail1049_2536 = newtail1050_816;
tail1049_813 = tail1049_2536;
l1046_812 = l1046_2534;
goto lname1047_814;
}
}
}
}
{
{
obj_t l1051_795;
l1051_795 = make_columns_212___r5_syntax_syntaxrules(vars_793, rows_794, alist_789);
if(NULLP(l1051_795)){
return BNIL;
}
 else {
obj_t head1053_797;
head1053_797 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1051_798;
obj_t tail1054_799;
l1051_798 = l1051_795;
tail1054_799 = head1053_797;
lname1052_800:
if(NULLP(l1051_798)){
return CDR(head1053_797);
}
 else {
obj_t newtail1055_802;
{
obj_t arg1392_804;
arg1392_804 = rewrite___r5_syntax_syntaxrules(t1_792, CAR(l1051_798), rank_790);
newtail1055_802 = MAKE_PAIR(arg1392_804, BNIL);
}
SET_CDR(tail1054_799, newtail1055_802);
{
obj_t tail1054_2550;
obj_t l1051_2548;
l1051_2548 = CDR(l1051_798);
tail1054_2550 = newtail1055_802;
tail1054_799 = tail1054_2550;
l1051_798 = l1051_2548;
goto lname1052_800;
}
}
}
}
}
}
}
}
}
}
 else {
if(VECTORP(t_824)){
{
obj_t arg1428_846;
arg1428_846 = rewrite___r5_syntax_syntaxrules(VECTOR_REF(t_824, ((long)0)), alist_825, rank_826);
return list__vector_101___r4_vectors_6_8(arg1428_846);
}
}
 else {
return t_824;
}
}
}
}
}
}
}
}


/* m-transcribe */obj_t m_transcribe_36___r5_syntax_syntaxrules(obj_t exp_36, obj_t env_use_213_37, obj_t k_38)
{
{
obj_t m_851;
m_851 = syntactic_lookup_76___r5_syntax_syntaxenv(env_use_213_37, CAR(exp_36));
{
obj_t rules_852;
rules_852 = macro_rules_111___r5_syntax_syntaxenv(m_851);
{
obj_t env_def_34_853;
env_def_34_853 = macro_env_86___r5_syntax_syntaxenv(m_851);
{
obj_t f_854;
f_854 = CDR(exp_36);
{
{
obj_t rules_856;
rules_856 = rules_852;
loop_871:
if(NULLP(rules_856)){
obj_t list1434_859;
list1434_859 = MAKE_PAIR(exp_36, BNIL);
return m_error_176___r5_syntax_misc(string1610___r5_syntax_syntaxrules, list1434_859);
}
 else {
obj_t rule_861;
rule_861 = CAR(rules_856);
{
obj_t alist_863;
alist_863 = m_match_26___r5_syntax_syntaxrules(f_854, CAR(rule_861), env_def_34_853, env_use_213_37);
{
if(CBOOL(alist_863)){
obj_t template_864;
{
obj_t aux_2572;
aux_2572 = CDR(rule_861);
template_864 = CAR(aux_2572);
}
{
obj_t alist2_866;
{
obj_t aux_2575;
{
obj_t aux_2576;
{
obj_t aux_2577;
aux_2577 = CDR(rule_861);
aux_2576 = CDR(aux_2577);
}
aux_2575 = CAR(aux_2576);
}
alist2_866 = rename_vars_186___r5_syntax_syntaxenv(aux_2575);
}
{
obj_t newexp_867;
newexp_867 = m_rewrite_211___r5_syntax_syntaxrules(template_864, append_2_18___r4_pairs_and_lists_6_3(alist2_866, alist_863));
{
{
obj_t arg1437_868;
arg1437_868 = syntactic_alias_206___r5_syntax_syntaxenv(env_use_213_37, alist2_866, env_def_34_853);
return PROCEDURE_ENTRY(k_38)(k_38, newexp_867, arg1437_868, BEOA);
}
}
}
}
}
 else {
obj_t rules_2587;
rules_2587 = CDR(rules_856);
rules_856 = rules_2587;
goto loop_871;
}
}
}
}
}
}
}
}
}
}
}


/* _m-transcribe */obj_t _m_transcribe_224___r5_syntax_syntaxrules(obj_t env_1884, obj_t exp_1885, obj_t env_use_213_1886, obj_t k_1887)
{
return m_transcribe_36___r5_syntax_syntaxrules(exp_1885, env_use_213_1886, k_1887);
}

