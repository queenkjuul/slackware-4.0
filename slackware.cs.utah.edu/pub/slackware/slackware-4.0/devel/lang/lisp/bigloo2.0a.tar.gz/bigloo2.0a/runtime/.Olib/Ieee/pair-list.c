/*===========================================================================*/
/*   (Ieee/pair-list.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t cer___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
extern obj_t car___r4_pairs_and_lists_6_3(obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _epair__200___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _list_tail1397_176___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t set_car__100___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _list_set_1399_60___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t, obj_t);
extern obj_t cddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t append__79___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t append_list_2___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cddar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _memv___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _memq___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t cddddr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cddaar1389___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdddar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cddddr1393___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caaaar1378___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t assv___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _set_cdr_1395_25___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t caddr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _caaddr1383___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cadar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _reverse___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _pair__14___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdaddr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _append___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caaar1370___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _last_pair_60___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caar1366___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _car1363___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdadar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _list_ref1398_17___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _remq__174___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _caddr1373___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cddr1369___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdadr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t list_ref_194___r4_pairs_and_lists_6_3(obj_t, long);
extern obj_t caar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdaar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cddadr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cddaar___r4_pairs_and_lists_6_3(obj_t);
extern bool_t pair__182___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cons___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t caadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _list___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t remq__51___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cdaadr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cdaaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _remq___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cadadr1385___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caddar1384___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _remove__17___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _null__116___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdadr1376___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _cddar1375___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdaaar1382___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _assoc___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cdaddr1388___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t);
extern obj_t memv___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern bool_t null__121___r4_pairs_and_lists_6_3(obj_t);
static obj_t _econs___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t symbol2779___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2780___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2778___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2777___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2776___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2775___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2774___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2773___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2772___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2771___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2769___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2770___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2768___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2767___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2766___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2765___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2764___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2763___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2762___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2759___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2760___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2758___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2757___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2756___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2755___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2754___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2753___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2752___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2751___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2750___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2748___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2747___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2746___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2745___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2744___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2743___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2742___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2741___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2739___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2740___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2738___r4_pairs_and_lists_6_3 = BUNSPEC;
extern obj_t assoc___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t symbol2737___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2736___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2735___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2734___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2733___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2732___r4_pairs_and_lists_6_3 = BUNSPEC;
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t symbol2731___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2729___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2730___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2728___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2727___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2726___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2725___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2724___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2723___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2722___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2721___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2719___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2720___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2718___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2717___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2716___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2715___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2714___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2713___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2712___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2711___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2699___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2709___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2710___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2698___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2708___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2697___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2707___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2696___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2706___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2695___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2705___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2694___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2704___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2693___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2703___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2692___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2702___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2691___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2701___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2689___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2690___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2700___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2688___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2687___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2683___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2682___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2681___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2678___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2677___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2676___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2675___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t symbol2674___r4_pairs_and_lists_6_3 = BUNSPEC;
extern obj_t list_tail_190___r4_pairs_and_lists_6_3(obj_t, long);
extern obj_t econs___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t remove__21___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cons___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cddadr1390___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t list___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdddar1392___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _set_car_1394_21___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _caaadr1379___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cons__190___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _member___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _caadar1380___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _set_cer_1396_98___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern long list_length(obj_t);
extern obj_t remq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _caadr1371___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cadr1367___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdr1364___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cadar1372___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t remove___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdar1368___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cadddr___r4_pairs_and_lists_6_3(obj_t);
extern obj_t list_set__58___r4_pairs_and_lists_6_3(obj_t, long, obj_t);
extern obj_t caddar___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _list__66___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaddr___r4_pairs_and_lists_6_3(obj_t);
extern bool_t eqv__112___r4_equivalence_6_2(obj_t, obj_t);
static obj_t _assv___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _assq___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t caadar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _reverse__87___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern bool_t epair__249___r4_pairs_and_lists_6_3(obj_t);
extern bool_t list__240___r4_pairs_and_lists_6_3(obj_t);
static obj_t imported_modules_init_94___r4_pairs_and_lists_6_3();
static obj_t _cadaar1381___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t cadadr___r4_pairs_and_lists_6_3(obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t cons_1_212___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cadaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _append__27___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cadddr1386___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cer1365___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _length___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114___r4_pairs_and_lists_6_3 = BUNSPEC;
static obj_t _append_2_70___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
static obj_t _cdaar1374___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t set_cer__213___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _cdddr1377___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _remove___r4_pairs_and_lists_6_3(obj_t, obj_t, obj_t);
extern obj_t caaadr___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdaadr1387___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t caaaar___r4_pairs_and_lists_6_3(obj_t);
static obj_t _cdadar1391___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t set_cdr__56___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t cnst_init_137___r4_pairs_and_lists_6_3();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( cons_env_70___r4_pairs_and_lists_6_3, _cons___r4_pairs_and_lists_6_32782, _cons___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( car_env_2___r4_pairs_and_lists_6_3, _car1363___r4_pairs_and_lists_6_32783, _car1363___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( pair__env_127___r4_pairs_and_lists_6_3, _pair__14___r4_pairs_and_lists_6_32784, _pair__14___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caaar_env_253___r4_pairs_and_lists_6_3, _caaar1370___r4_pairs_and_lists_6_32785, _caaar1370___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( reverse__env_230___r4_pairs_and_lists_6_3, _reverse__87___r4_pairs_and_lists_6_32786, _reverse__87___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caddr_env_228___r4_pairs_and_lists_6_3, _caddr1373___r4_pairs_and_lists_6_32787, _caddr1373___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cddaar_env_237___r4_pairs_and_lists_6_3, _cddaar1389___r4_pairs_and_lists_6_32788, _cddaar1389___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caaaar_env_120___r4_pairs_and_lists_6_3, _caaaar1378___r4_pairs_and_lists_6_32789, _caaaar1378___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cddddr_env_176___r4_pairs_and_lists_6_3, _cddddr1393___r4_pairs_and_lists_6_32790, _cddddr1393___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remove_env_232___r4_pairs_and_lists_6_3, _remove___r4_pairs_and_lists_6_32791, _remove___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( caaddr_env_185___r4_pairs_and_lists_6_3, _caaddr1383___r4_pairs_and_lists_6_32792, _caaddr1383___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( assv_env_68___r4_pairs_and_lists_6_3, _assv___r4_pairs_and_lists_6_32793, _assv___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( assq_env_11___r4_pairs_and_lists_6_3, _assq___r4_pairs_and_lists_6_32794, _assq___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( last_pair_env_209___r4_pairs_and_lists_6_3, _last_pair_60___r4_pairs_and_lists_6_32795, _last_pair_60___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_cdr__env_88___r4_pairs_and_lists_6_3, _set_cdr_1395_25___r4_pairs_and_lists_6_32796, _set_cdr_1395_25___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cdadr_env_187___r4_pairs_and_lists_6_3, _cdadr1376___r4_pairs_and_lists_6_32797, _cdadr1376___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( list_ref_env_246___r4_pairs_and_lists_6_3, _list_ref1398_17___r4_pairs_and_lists_6_32798, _list_ref1398_17___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cddar_env_87___r4_pairs_and_lists_6_3, _cddar1375___r4_pairs_and_lists_6_32799, _cddar1375___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_STRING( string2761___r4_pairs_and_lists_6_3, string2761___r4_pairs_and_lists_6_32800, "LONG", 4 );
DEFINE_EXPORT_PROCEDURE( cadadr_env_215___r4_pairs_and_lists_6_3, _cadadr1385___r4_pairs_and_lists_6_32801, _cadadr1385___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_STRING( string2749___r4_pairs_and_lists_6_3, string2749___r4_pairs_and_lists_6_32802, "set-cer!", 8 );
DEFINE_EXPORT_PROCEDURE( caddar_env_165___r4_pairs_and_lists_6_3, _caddar1384___r4_pairs_and_lists_6_32803, _caddar1384___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_STRING( string2686___r4_pairs_and_lists_6_3, string2686___r4_pairs_and_lists_6_32804, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2685___r4_pairs_and_lists_6_3, string2685___r4_pairs_and_lists_6_32805, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string2684___r4_pairs_and_lists_6_3, string2684___r4_pairs_and_lists_6_32806, "cer", 3 );
DEFINE_STRING( string2679___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_32807, "PAIR", 4 );
DEFINE_STRING( string2680___r4_pairs_and_lists_6_3, string2680___r4_pairs_and_lists_6_32808, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_EXPORT_PROCEDURE( append_env_23___r4_pairs_and_lists_6_3, _append___r4_pairs_and_lists_6_32809, va_generic_entry, _append___r4_pairs_and_lists_6_3, -1 );
DEFINE_EXPORT_PROCEDURE( cdaaar_env_65___r4_pairs_and_lists_6_3, _cdaaar1382___r4_pairs_and_lists_6_32810, _cdaaar1382___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdaddr_env_139___r4_pairs_and_lists_6_3, _cdaddr1388___r4_pairs_and_lists_6_32811, _cdaddr1388___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cadr_env_124___r4_pairs_and_lists_6_3, _cadr1367___r4_pairs_and_lists_6_32812, _cadr1367___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( econs_env_160___r4_pairs_and_lists_6_3, _econs___r4_pairs_and_lists_6_32813, _econs___r4_pairs_and_lists_6_3, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( cdar_env_110___r4_pairs_and_lists_6_3, _cdar1368___r4_pairs_and_lists_6_32814, _cdar1368___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remq__env_181___r4_pairs_and_lists_6_3, _remq__174___r4_pairs_and_lists_6_32815, _remq__174___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cdr_env_184___r4_pairs_and_lists_6_3, _cdr1364___r4_pairs_and_lists_6_32816, _cdr1364___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caadr_env_216___r4_pairs_and_lists_6_3, _caadr1371___r4_pairs_and_lists_6_32817, _caadr1371___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remove__env_123___r4_pairs_and_lists_6_3, _remove__17___r4_pairs_and_lists_6_32818, _remove__17___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cadar_env_80___r4_pairs_and_lists_6_3, _cadar1372___r4_pairs_and_lists_6_32819, _cadar1372___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( list_tail_env_188___r4_pairs_and_lists_6_3, _list_tail1397_176___r4_pairs_and_lists_6_32820, _list_tail1397_176___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cddadr_env_82___r4_pairs_and_lists_6_3, _cddadr1390___r4_pairs_and_lists_6_32821, _cddadr1390___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( assoc_env_175___r4_pairs_and_lists_6_3, _assoc___r4_pairs_and_lists_6_32822, _assoc___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( list__env_95___r4_pairs_and_lists_6_3, _list__66___r4_pairs_and_lists_6_32823, _list__66___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdddar_env_95___r4_pairs_and_lists_6_3, _cdddar1392___r4_pairs_and_lists_6_32824, _cdddar1392___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caaadr_env_84___r4_pairs_and_lists_6_3, _caaadr1379___r4_pairs_and_lists_6_32825, _caaadr1379___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caadar_env_94___r4_pairs_and_lists_6_3, _caadar1380___r4_pairs_and_lists_6_32826, _caadar1380___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( list_set__env_81___r4_pairs_and_lists_6_3, _list_set_1399_60___r4_pairs_and_lists_6_32827, _list_set_1399_60___r4_pairs_and_lists_6_3, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( length_env_176___r4_pairs_and_lists_6_3, _length___r4_pairs_and_lists_6_32828, _length___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remq_env_28___r4_pairs_and_lists_6_3, _remq___r4_pairs_and_lists_6_32829, _remq___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( null__env_100___r4_pairs_and_lists_6_3, _null__116___r4_pairs_and_lists_6_32830, _null__116___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_car__env_189___r4_pairs_and_lists_6_3, _set_car_1394_21___r4_pairs_and_lists_6_32831, _set_car_1394_21___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( list_env_29___r4_pairs_and_lists_6_3, _list___r4_pairs_and_lists_6_32832, va_generic_entry, _list___r4_pairs_and_lists_6_3, -1 );
DEFINE_EXPORT_PROCEDURE( cer_env_92___r4_pairs_and_lists_6_3, _cer1365___r4_pairs_and_lists_6_32833, _cer1365___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_cer__env_36___r4_pairs_and_lists_6_3, _set_cer_1396_98___r4_pairs_and_lists_6_32834, _set_cer_1396_98___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cons__env_67___r4_pairs_and_lists_6_3, _cons__190___r4_pairs_and_lists_6_32835, va_generic_entry, _cons__190___r4_pairs_and_lists_6_3, -2 );
DEFINE_EXPORT_PROCEDURE( reverse_env_76___r4_pairs_and_lists_6_3, _reverse___r4_pairs_and_lists_6_32836, _reverse___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdaar_env_98___r4_pairs_and_lists_6_3, _cdaar1374___r4_pairs_and_lists_6_32837, _cdaar1374___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdddr_env_34___r4_pairs_and_lists_6_3, _cdddr1377___r4_pairs_and_lists_6_32838, _cdddr1377___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append__env_141___r4_pairs_and_lists_6_3, _append__27___r4_pairs_and_lists_6_32839, _append__27___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cadaar_env_111___r4_pairs_and_lists_6_3, _cadaar1381___r4_pairs_and_lists_6_32840, _cadaar1381___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( memv_env_45___r4_pairs_and_lists_6_3, _memv___r4_pairs_and_lists_6_32841, _memv___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cadddr_env_191___r4_pairs_and_lists_6_3, _cadddr1386___r4_pairs_and_lists_6_32842, _cadddr1386___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( memq_env_197___r4_pairs_and_lists_6_3, _memq___r4_pairs_and_lists_6_32843, _memq___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( member_env_128___r4_pairs_and_lists_6_3, _member___r4_pairs_and_lists_6_32844, _member___r4_pairs_and_lists_6_3, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( cdaadr_env_56___r4_pairs_and_lists_6_3, _cdaadr1387___r4_pairs_and_lists_6_32845, _cdaadr1387___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cdadar_env_63___r4_pairs_and_lists_6_3, _cdadar1391___r4_pairs_and_lists_6_32846, _cdadar1391___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( caar_env_69___r4_pairs_and_lists_6_3, _caar1366___r4_pairs_and_lists_6_32847, _caar1366___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( epair__env_215___r4_pairs_and_lists_6_3, _epair__200___r4_pairs_and_lists_6_32848, _epair__200___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cddr_env_173___r4_pairs_and_lists_6_3, _cddr1369___r4_pairs_and_lists_6_32849, _cddr1369___r4_pairs_and_lists_6_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( append_2_env_90___r4_pairs_and_lists_6_3, _append_2_70___r4_pairs_and_lists_6_32850, _append_2_70___r4_pairs_and_lists_6_3, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___r4_pairs_and_lists_6_3(long checksum_2830, char * from_2831)
{
if(CBOOL(require_initialization_114___r4_pairs_and_lists_6_3)){
require_initialization_114___r4_pairs_and_lists_6_3 = BBOOL(((bool_t)0));
cnst_init_137___r4_pairs_and_lists_6_3();
imported_modules_init_94___r4_pairs_and_lists_6_3();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_pairs_and_lists_6_3()
{
symbol2674___r4_pairs_and_lists_6_3 = string_to_symbol("EPAIR?");
symbol2675___r4_pairs_and_lists_6_3 = string_to_symbol("CONS");
symbol2676___r4_pairs_and_lists_6_3 = string_to_symbol("ECONS");
symbol2677___r4_pairs_and_lists_6_3 = string_to_symbol("CAR");
symbol2678___r4_pairs_and_lists_6_3 = string_to_symbol("_CAR1363");
symbol2681___r4_pairs_and_lists_6_3 = string_to_symbol("CDR");
symbol2682___r4_pairs_and_lists_6_3 = string_to_symbol("_CDR1364");
symbol2683___r4_pairs_and_lists_6_3 = string_to_symbol("CER");
symbol2687___r4_pairs_and_lists_6_3 = string_to_symbol("_CER1365");
symbol2688___r4_pairs_and_lists_6_3 = string_to_symbol("CAAR");
symbol2689___r4_pairs_and_lists_6_3 = string_to_symbol("_CAAR1366");
symbol2690___r4_pairs_and_lists_6_3 = string_to_symbol("CADR");
symbol2691___r4_pairs_and_lists_6_3 = string_to_symbol("_CADR1367");
symbol2692___r4_pairs_and_lists_6_3 = string_to_symbol("CDAR");
symbol2693___r4_pairs_and_lists_6_3 = string_to_symbol("_CDAR1368");
symbol2694___r4_pairs_and_lists_6_3 = string_to_symbol("CDDR");
symbol2695___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDR1369");
symbol2696___r4_pairs_and_lists_6_3 = string_to_symbol("CAAAR");
symbol2697___r4_pairs_and_lists_6_3 = string_to_symbol("_CAAAR1370");
symbol2698___r4_pairs_and_lists_6_3 = string_to_symbol("CAADR");
symbol2699___r4_pairs_and_lists_6_3 = string_to_symbol("_CAADR1371");
symbol2700___r4_pairs_and_lists_6_3 = string_to_symbol("CADAR");
symbol2701___r4_pairs_and_lists_6_3 = string_to_symbol("_CADAR1372");
symbol2702___r4_pairs_and_lists_6_3 = string_to_symbol("CADDR");
symbol2703___r4_pairs_and_lists_6_3 = string_to_symbol("_CADDR1373");
symbol2704___r4_pairs_and_lists_6_3 = string_to_symbol("CDAAR");
symbol2705___r4_pairs_and_lists_6_3 = string_to_symbol("_CDAAR1374");
symbol2706___r4_pairs_and_lists_6_3 = string_to_symbol("CDDAR");
symbol2707___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDAR1375");
symbol2708___r4_pairs_and_lists_6_3 = string_to_symbol("CDADR");
symbol2709___r4_pairs_and_lists_6_3 = string_to_symbol("_CDADR1376");
symbol2710___r4_pairs_and_lists_6_3 = string_to_symbol("CDDDR");
symbol2711___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDDR1377");
symbol2712___r4_pairs_and_lists_6_3 = string_to_symbol("CAAAAR");
symbol2713___r4_pairs_and_lists_6_3 = string_to_symbol("_CAAAAR1378");
symbol2714___r4_pairs_and_lists_6_3 = string_to_symbol("CAAADR");
symbol2715___r4_pairs_and_lists_6_3 = string_to_symbol("_CAAADR1379");
symbol2716___r4_pairs_and_lists_6_3 = string_to_symbol("CAADAR");
symbol2717___r4_pairs_and_lists_6_3 = string_to_symbol("_CAADAR1380");
symbol2718___r4_pairs_and_lists_6_3 = string_to_symbol("CADAAR");
symbol2719___r4_pairs_and_lists_6_3 = string_to_symbol("_CADAAR1381");
symbol2720___r4_pairs_and_lists_6_3 = string_to_symbol("CDAAAR");
symbol2721___r4_pairs_and_lists_6_3 = string_to_symbol("_CDAAAR1382");
symbol2722___r4_pairs_and_lists_6_3 = string_to_symbol("CAADDR");
symbol2723___r4_pairs_and_lists_6_3 = string_to_symbol("_CAADDR1383");
symbol2724___r4_pairs_and_lists_6_3 = string_to_symbol("CADDAR");
symbol2725___r4_pairs_and_lists_6_3 = string_to_symbol("_CADDAR1384");
symbol2726___r4_pairs_and_lists_6_3 = string_to_symbol("CADADR");
symbol2727___r4_pairs_and_lists_6_3 = string_to_symbol("_CADADR1385");
symbol2728___r4_pairs_and_lists_6_3 = string_to_symbol("CADDDR");
symbol2729___r4_pairs_and_lists_6_3 = string_to_symbol("_CADDDR1386");
symbol2730___r4_pairs_and_lists_6_3 = string_to_symbol("CDAADR");
symbol2731___r4_pairs_and_lists_6_3 = string_to_symbol("_CDAADR1387");
symbol2732___r4_pairs_and_lists_6_3 = string_to_symbol("CDADDR");
symbol2733___r4_pairs_and_lists_6_3 = string_to_symbol("_CDADDR1388");
symbol2734___r4_pairs_and_lists_6_3 = string_to_symbol("CDDAAR");
symbol2735___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDAAR1389");
symbol2736___r4_pairs_and_lists_6_3 = string_to_symbol("CDDADR");
symbol2737___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDADR1390");
symbol2738___r4_pairs_and_lists_6_3 = string_to_symbol("CDADAR");
symbol2739___r4_pairs_and_lists_6_3 = string_to_symbol("_CDADAR1391");
symbol2740___r4_pairs_and_lists_6_3 = string_to_symbol("CDDDAR");
symbol2741___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDDAR1392");
symbol2742___r4_pairs_and_lists_6_3 = string_to_symbol("CDDDDR");
symbol2743___r4_pairs_and_lists_6_3 = string_to_symbol("_CDDDDR1393");
symbol2744___r4_pairs_and_lists_6_3 = string_to_symbol("SET-CAR!");
symbol2745___r4_pairs_and_lists_6_3 = string_to_symbol("_SET-CAR!1394");
symbol2746___r4_pairs_and_lists_6_3 = string_to_symbol("SET-CDR!");
symbol2747___r4_pairs_and_lists_6_3 = string_to_symbol("_SET-CDR!1395");
symbol2748___r4_pairs_and_lists_6_3 = string_to_symbol("SET-CER!");
symbol2750___r4_pairs_and_lists_6_3 = string_to_symbol("_SET-CER!1396");
symbol2751___r4_pairs_and_lists_6_3 = string_to_symbol("LIST");
symbol2752___r4_pairs_and_lists_6_3 = string_to_symbol("LIST?");
symbol2753___r4_pairs_and_lists_6_3 = string_to_symbol("APPEND-2");
symbol2754___r4_pairs_and_lists_6_3 = string_to_symbol("APPEND");
symbol2755___r4_pairs_and_lists_6_3 = string_to_symbol("APPEND-LIST");
symbol2756___r4_pairs_and_lists_6_3 = string_to_symbol("APPEND!");
symbol2757___r4_pairs_and_lists_6_3 = string_to_symbol("LENGTH");
symbol2758___r4_pairs_and_lists_6_3 = string_to_symbol("REVERSE");
symbol2759___r4_pairs_and_lists_6_3 = string_to_symbol("LIST-TAIL");
symbol2760___r4_pairs_and_lists_6_3 = string_to_symbol("_LIST-TAIL1397");
symbol2762___r4_pairs_and_lists_6_3 = string_to_symbol("LIST-REF");
symbol2763___r4_pairs_and_lists_6_3 = string_to_symbol("_LIST-REF1398");
symbol2764___r4_pairs_and_lists_6_3 = string_to_symbol("LIST-SET!");
symbol2765___r4_pairs_and_lists_6_3 = string_to_symbol("_LIST-SET!1399");
symbol2766___r4_pairs_and_lists_6_3 = string_to_symbol("LAST-PAIR");
symbol2767___r4_pairs_and_lists_6_3 = string_to_symbol("MEMQ");
symbol2768___r4_pairs_and_lists_6_3 = string_to_symbol("MEMV");
symbol2769___r4_pairs_and_lists_6_3 = string_to_symbol("MEMBER");
symbol2770___r4_pairs_and_lists_6_3 = string_to_symbol("ASSQ");
symbol2771___r4_pairs_and_lists_6_3 = string_to_symbol("ASSV");
symbol2772___r4_pairs_and_lists_6_3 = string_to_symbol("ASSOC");
symbol2773___r4_pairs_and_lists_6_3 = string_to_symbol("REMQ");
symbol2774___r4_pairs_and_lists_6_3 = string_to_symbol("REMOVE");
symbol2775___r4_pairs_and_lists_6_3 = string_to_symbol("REMQ!");
symbol2776___r4_pairs_and_lists_6_3 = string_to_symbol("REMOVE!");
symbol2777___r4_pairs_and_lists_6_3 = string_to_symbol("CONS*");
symbol2778___r4_pairs_and_lists_6_3 = string_to_symbol("CONS*1");
symbol2779___r4_pairs_and_lists_6_3 = string_to_symbol("REVERSE!");
return (symbol2780___r4_pairs_and_lists_6_3 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* pair? */bool_t pair__182___r4_pairs_and_lists_6_3(obj_t obj_1)
{
return PAIRP(obj_1);
}


/* _pair? */obj_t _pair__14___r4_pairs_and_lists_6_3(obj_t env_1083, obj_t obj_1084)
{
{
bool_t aux_2938;
{
obj_t obj_2358;
obj_2358 = obj_1084;
aux_2938 = PAIRP(obj_2358);
}
return BBOOL(aux_2938);
}
}


/* epair? */bool_t epair__249___r4_pairs_and_lists_6_3(obj_t obj_2)
{
{
obj_t symbol1242_2359;
symbol1242_2359 = symbol2674___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1242_2359);
BUNSPEC;
{
bool_t aux1241_2360;
aux1241_2360 = EXTENDED_PAIRP(obj_2);
POP_TRACE();
return aux1241_2360;
}
}
}
}


/* _epair? */obj_t _epair__200___r4_pairs_and_lists_6_3(obj_t env_1085, obj_t obj_1086)
{
{
bool_t aux_2944;
{
obj_t obj_2361;
obj_2361 = obj_1086;
{
obj_t symbol1242_2362;
symbol1242_2362 = symbol2674___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1242_2362);
BUNSPEC;
{
bool_t aux1241_2363;
aux1241_2363 = EXTENDED_PAIRP(obj_2361);
POP_TRACE();
aux_2944 = aux1241_2363;
}
}
}
}
return BBOOL(aux_2944);
}
}


/* cons */obj_t cons___r4_pairs_and_lists_6_3(obj_t obj1_3, obj_t obj2_4)
{
{
obj_t symbol1244_2364;
symbol1244_2364 = symbol2675___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1244_2364);
BUNSPEC;
{
obj_t aux1243_2365;
aux1243_2365 = MAKE_PAIR(obj1_3, obj2_4);
POP_TRACE();
return aux1243_2365;
}
}
}
}


/* _cons */obj_t _cons___r4_pairs_and_lists_6_3(obj_t env_1087, obj_t obj1_1088, obj_t obj2_1089)
{
{
obj_t obj1_2366;
obj_t obj2_2367;
obj1_2366 = obj1_1088;
obj2_2367 = obj2_1089;
{
obj_t symbol1244_2368;
symbol1244_2368 = symbol2675___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1244_2368);
BUNSPEC;
{
obj_t aux1243_2369;
aux1243_2369 = MAKE_PAIR(obj1_2366, obj2_2367);
POP_TRACE();
return aux1243_2369;
}
}
}
}
}


/* econs */obj_t econs___r4_pairs_and_lists_6_3(obj_t obj1_5, obj_t obj2_6, obj_t obj3_7)
{
{
obj_t symbol1246_2370;
symbol1246_2370 = symbol2676___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1246_2370);
BUNSPEC;
{
obj_t aux1245_2371;
aux1245_2371 = MAKE_EXTENDED_PAIR(obj1_5, obj2_6, obj3_7);
POP_TRACE();
return aux1245_2371;
}
}
}
}


/* _econs */obj_t _econs___r4_pairs_and_lists_6_3(obj_t env_1090, obj_t obj1_1091, obj_t obj2_1092, obj_t obj3_1093)
{
{
obj_t obj1_2372;
obj_t obj2_2373;
obj_t obj3_2374;
obj1_2372 = obj1_1091;
obj2_2373 = obj2_1092;
obj3_2374 = obj3_1093;
{
obj_t symbol1246_2375;
symbol1246_2375 = symbol2676___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1246_2375);
BUNSPEC;
{
obj_t aux1245_2376;
aux1245_2376 = MAKE_EXTENDED_PAIR(obj1_2372, obj2_2373, obj3_2374);
POP_TRACE();
return aux1245_2376;
}
}
}
}
}


/* car */obj_t car___r4_pairs_and_lists_6_3(obj_t pair_8)
{
{
obj_t symbol1248_2377;
symbol1248_2377 = symbol2677___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1248_2377);
BUNSPEC;
{
obj_t aux1247_2378;
aux1247_2378 = CAR(pair_8);
POP_TRACE();
return aux1247_2378;
}
}
}
}


/* _car1363 */obj_t _car1363___r4_pairs_and_lists_6_3(obj_t env_1094, obj_t pair_1095)
{
{
obj_t pair_2379;
if(PAIRP(pair_1095)){
pair_2379 = pair_1095;
}
 else {
bigloo_type_error_location_103___error(symbol2678___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1095, string2680___r4_pairs_and_lists_6_3, BINT(((long)6797)));
exit( -1 );}
{
obj_t symbol1248_2380;
symbol1248_2380 = symbol2677___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1248_2380);
BUNSPEC;
{
obj_t aux1247_2381;
aux1247_2381 = CAR(pair_2379);
POP_TRACE();
return aux1247_2381;
}
}
}
}
}


/* cdr */obj_t cdr___r4_pairs_and_lists_6_3(obj_t pair_9)
{
{
obj_t symbol1250_2382;
symbol1250_2382 = symbol2681___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1250_2382);
BUNSPEC;
{
obj_t aux1249_2383;
aux1249_2383 = CDR(pair_9);
POP_TRACE();
return aux1249_2383;
}
}
}
}


/* _cdr1364 */obj_t _cdr1364___r4_pairs_and_lists_6_3(obj_t env_1096, obj_t pair_1097)
{
{
obj_t pair_2384;
if(PAIRP(pair_1097)){
pair_2384 = pair_1097;
}
 else {
bigloo_type_error_location_103___error(symbol2682___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1097, string2680___r4_pairs_and_lists_6_3, BINT(((long)7063)));
exit( -1 );}
{
obj_t symbol1250_2385;
symbol1250_2385 = symbol2681___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1250_2385);
BUNSPEC;
{
obj_t aux1249_2386;
aux1249_2386 = CDR(pair_2384);
POP_TRACE();
return aux1249_2386;
}
}
}
}
}


/* cer */obj_t cer___r4_pairs_and_lists_6_3(obj_t obj_10)
{
{
obj_t symbol1252_2387;
symbol1252_2387 = symbol2683___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1252_2387);
BUNSPEC;
{
obj_t aux1251_2388;
{
bool_t test1005_2389;
test1005_2389 = EXTENDED_PAIRP(obj_10);
if(test1005_2389){
aux1251_2388 = CER(obj_10);
}
 else {
aux1251_2388 = debug_error_location_199___error(string2684___r4_pairs_and_lists_6_3, string2685___r4_pairs_and_lists_6_3, obj_10, string2686___r4_pairs_and_lists_6_3, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1251_2388;
}
}
}
}


/* _cer1365 */obj_t _cer1365___r4_pairs_and_lists_6_3(obj_t env_1098, obj_t obj_1099)
{
{
obj_t obj_2390;
if(PAIRP(obj_1099)){
obj_2390 = obj_1099;
}
 else {
bigloo_type_error_location_103___error(symbol2687___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, obj_1099, string2680___r4_pairs_and_lists_6_3, BINT(((long)7329)));
exit( -1 );}
{
obj_t symbol1252_2391;
symbol1252_2391 = symbol2683___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1252_2391);
BUNSPEC;
{
obj_t aux1251_2392;
{
bool_t test1005_2393;
test1005_2393 = EXTENDED_PAIRP(obj_2390);
if(test1005_2393){
aux1251_2392 = CER(obj_2390);
}
 else {
aux1251_2392 = debug_error_location_199___error(string2684___r4_pairs_and_lists_6_3, string2685___r4_pairs_and_lists_6_3, obj_2390, string2686___r4_pairs_and_lists_6_3, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1251_2392;
}
}
}
}
}


/* caar */obj_t caar___r4_pairs_and_lists_6_3(obj_t pair_11)
{
{
obj_t symbol1254_2394;
symbol1254_2394 = symbol2688___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1254_2394);
BUNSPEC;
{
obj_t aux1253_2395;
{
obj_t arg1006_2396;
arg1006_2396 = CAR(pair_11);
{
obj_t pair_2397;
if(PAIRP(arg1006_2396)){
pair_2397 = arg1006_2396;
}
 else {
bigloo_type_error_location_103___error(symbol2688___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1006_2396, string2680___r4_pairs_and_lists_6_3, BINT(((long)7720)));
exit( -1 );}
aux1253_2395 = CAR(pair_2397);
}
}
POP_TRACE();
return aux1253_2395;
}
}
}
}


/* _caar1366 */obj_t _caar1366___r4_pairs_and_lists_6_3(obj_t env_1100, obj_t pair_1101)
{
{
obj_t pair_2398;
if(PAIRP(pair_1101)){
pair_2398 = pair_1101;
}
 else {
bigloo_type_error_location_103___error(symbol2689___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1101, string2680___r4_pairs_and_lists_6_3, BINT(((long)7690)));
exit( -1 );}
{
obj_t symbol1254_2399;
symbol1254_2399 = symbol2688___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1254_2399);
BUNSPEC;
{
obj_t aux1253_2400;
{
obj_t arg1006_2401;
arg1006_2401 = CAR(pair_2398);
{
obj_t pair_2402;
if(PAIRP(arg1006_2401)){
pair_2402 = arg1006_2401;
}
 else {
bigloo_type_error_location_103___error(symbol2688___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1006_2401, string2680___r4_pairs_and_lists_6_3, BINT(((long)7720)));
exit( -1 );}
aux1253_2400 = CAR(pair_2402);
}
}
POP_TRACE();
return aux1253_2400;
}
}
}
}
}


/* cadr */obj_t cadr___r4_pairs_and_lists_6_3(obj_t pair_12)
{
{
obj_t symbol1256_2403;
symbol1256_2403 = symbol2690___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1256_2403);
BUNSPEC;
{
obj_t aux1255_2404;
{
obj_t arg1007_2405;
arg1007_2405 = CDR(pair_12);
{
obj_t pair_2406;
if(PAIRP(arg1007_2405)){
pair_2406 = arg1007_2405;
}
 else {
bigloo_type_error_location_103___error(symbol2690___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1007_2405, string2680___r4_pairs_and_lists_6_3, BINT(((long)7991)));
exit( -1 );}
aux1255_2404 = CAR(pair_2406);
}
}
POP_TRACE();
return aux1255_2404;
}
}
}
}


/* _cadr1367 */obj_t _cadr1367___r4_pairs_and_lists_6_3(obj_t env_1102, obj_t pair_1103)
{
{
obj_t pair_2407;
if(PAIRP(pair_1103)){
pair_2407 = pair_1103;
}
 else {
bigloo_type_error_location_103___error(symbol2691___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1103, string2680___r4_pairs_and_lists_6_3, BINT(((long)7961)));
exit( -1 );}
{
obj_t symbol1256_2408;
symbol1256_2408 = symbol2690___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1256_2408);
BUNSPEC;
{
obj_t aux1255_2409;
{
obj_t arg1007_2410;
arg1007_2410 = CDR(pair_2407);
{
obj_t pair_2411;
if(PAIRP(arg1007_2410)){
pair_2411 = arg1007_2410;
}
 else {
bigloo_type_error_location_103___error(symbol2690___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1007_2410, string2680___r4_pairs_and_lists_6_3, BINT(((long)7991)));
exit( -1 );}
aux1255_2409 = CAR(pair_2411);
}
}
POP_TRACE();
return aux1255_2409;
}
}
}
}
}


/* cdar */obj_t cdar___r4_pairs_and_lists_6_3(obj_t pair_13)
{
{
obj_t symbol1258_2412;
symbol1258_2412 = symbol2692___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1258_2412);
BUNSPEC;
{
obj_t aux1257_2413;
{
obj_t arg1008_2414;
arg1008_2414 = CAR(pair_13);
{
obj_t pair_2415;
if(PAIRP(arg1008_2414)){
pair_2415 = arg1008_2414;
}
 else {
bigloo_type_error_location_103___error(symbol2692___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1008_2414, string2680___r4_pairs_and_lists_6_3, BINT(((long)8262)));
exit( -1 );}
aux1257_2413 = CDR(pair_2415);
}
}
POP_TRACE();
return aux1257_2413;
}
}
}
}


/* _cdar1368 */obj_t _cdar1368___r4_pairs_and_lists_6_3(obj_t env_1104, obj_t pair_1105)
{
{
obj_t pair_2416;
if(PAIRP(pair_1105)){
pair_2416 = pair_1105;
}
 else {
bigloo_type_error_location_103___error(symbol2693___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1105, string2680___r4_pairs_and_lists_6_3, BINT(((long)8232)));
exit( -1 );}
{
obj_t symbol1258_2417;
symbol1258_2417 = symbol2692___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1258_2417);
BUNSPEC;
{
obj_t aux1257_2418;
{
obj_t arg1008_2419;
arg1008_2419 = CAR(pair_2416);
{
obj_t pair_2420;
if(PAIRP(arg1008_2419)){
pair_2420 = arg1008_2419;
}
 else {
bigloo_type_error_location_103___error(symbol2692___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1008_2419, string2680___r4_pairs_and_lists_6_3, BINT(((long)8262)));
exit( -1 );}
aux1257_2418 = CDR(pair_2420);
}
}
POP_TRACE();
return aux1257_2418;
}
}
}
}
}


/* cddr */obj_t cddr___r4_pairs_and_lists_6_3(obj_t pair_14)
{
{
obj_t symbol1260_2421;
symbol1260_2421 = symbol2694___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1260_2421);
BUNSPEC;
{
obj_t aux1259_2422;
{
obj_t arg1009_2423;
arg1009_2423 = CDR(pair_14);
{
obj_t pair_2424;
if(PAIRP(arg1009_2423)){
pair_2424 = arg1009_2423;
}
 else {
bigloo_type_error_location_103___error(symbol2694___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1009_2423, string2680___r4_pairs_and_lists_6_3, BINT(((long)8533)));
exit( -1 );}
aux1259_2422 = CDR(pair_2424);
}
}
POP_TRACE();
return aux1259_2422;
}
}
}
}


/* _cddr1369 */obj_t _cddr1369___r4_pairs_and_lists_6_3(obj_t env_1106, obj_t pair_1107)
{
{
obj_t pair_2425;
if(PAIRP(pair_1107)){
pair_2425 = pair_1107;
}
 else {
bigloo_type_error_location_103___error(symbol2695___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1107, string2680___r4_pairs_and_lists_6_3, BINT(((long)8503)));
exit( -1 );}
{
obj_t symbol1260_2426;
symbol1260_2426 = symbol2694___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1260_2426);
BUNSPEC;
{
obj_t aux1259_2427;
{
obj_t arg1009_2428;
arg1009_2428 = CDR(pair_2425);
{
obj_t pair_2429;
if(PAIRP(arg1009_2428)){
pair_2429 = arg1009_2428;
}
 else {
bigloo_type_error_location_103___error(symbol2694___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1009_2428, string2680___r4_pairs_and_lists_6_3, BINT(((long)8533)));
exit( -1 );}
aux1259_2427 = CDR(pair_2429);
}
}
POP_TRACE();
return aux1259_2427;
}
}
}
}
}


/* caaar */obj_t caaar___r4_pairs_and_lists_6_3(obj_t pair_15)
{
{
obj_t symbol1262_2430;
symbol1262_2430 = symbol2696___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1262_2430);
BUNSPEC;
{
obj_t aux1261_2431;
{
obj_t arg1010_2432;
{
obj_t arg1011_2433;
arg1011_2433 = CAR(pair_15);
{
obj_t pair_2434;
if(PAIRP(arg1011_2433)){
pair_2434 = arg1011_2433;
}
 else {
bigloo_type_error_location_103___error(symbol2696___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1011_2433, string2680___r4_pairs_and_lists_6_3, BINT(((long)8810)));
exit( -1 );}
arg1010_2432 = CAR(pair_2434);
}
}
{
obj_t pair_2435;
if(PAIRP(arg1010_2432)){
pair_2435 = arg1010_2432;
}
 else {
bigloo_type_error_location_103___error(symbol2696___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1010_2432, string2680___r4_pairs_and_lists_6_3, BINT(((long)8805)));
exit( -1 );}
aux1261_2431 = CAR(pair_2435);
}
}
POP_TRACE();
return aux1261_2431;
}
}
}
}


/* _caaar1370 */obj_t _caaar1370___r4_pairs_and_lists_6_3(obj_t env_1108, obj_t pair_1109)
{
{
obj_t pair_2436;
if(PAIRP(pair_1109)){
pair_2436 = pair_1109;
}
 else {
bigloo_type_error_location_103___error(symbol2697___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1109, string2680___r4_pairs_and_lists_6_3, BINT(((long)8774)));
exit( -1 );}
{
obj_t symbol1262_2437;
symbol1262_2437 = symbol2696___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1262_2437);
BUNSPEC;
{
obj_t aux1261_2438;
{
obj_t arg1010_2439;
{
obj_t arg1011_2440;
arg1011_2440 = CAR(pair_2436);
{
obj_t pair_2441;
if(PAIRP(arg1011_2440)){
pair_2441 = arg1011_2440;
}
 else {
bigloo_type_error_location_103___error(symbol2696___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1011_2440, string2680___r4_pairs_and_lists_6_3, BINT(((long)8810)));
exit( -1 );}
arg1010_2439 = CAR(pair_2441);
}
}
{
obj_t pair_2442;
if(PAIRP(arg1010_2439)){
pair_2442 = arg1010_2439;
}
 else {
bigloo_type_error_location_103___error(symbol2696___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1010_2439, string2680___r4_pairs_and_lists_6_3, BINT(((long)8805)));
exit( -1 );}
aux1261_2438 = CAR(pair_2442);
}
}
POP_TRACE();
return aux1261_2438;
}
}
}
}
}


/* caadr */obj_t caadr___r4_pairs_and_lists_6_3(obj_t pair_16)
{
{
obj_t symbol1264_2443;
symbol1264_2443 = symbol2698___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1264_2443);
BUNSPEC;
{
obj_t aux1263_2444;
{
obj_t arg1012_2445;
{
obj_t arg1013_2446;
arg1013_2446 = CDR(pair_16);
{
obj_t pair_2447;
if(PAIRP(arg1013_2446)){
pair_2447 = arg1013_2446;
}
 else {
bigloo_type_error_location_103___error(symbol2698___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1013_2446, string2680___r4_pairs_and_lists_6_3, BINT(((long)9088)));
exit( -1 );}
arg1012_2445 = CAR(pair_2447);
}
}
{
obj_t pair_2448;
if(PAIRP(arg1012_2445)){
pair_2448 = arg1012_2445;
}
 else {
bigloo_type_error_location_103___error(symbol2698___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1012_2445, string2680___r4_pairs_and_lists_6_3, BINT(((long)9083)));
exit( -1 );}
aux1263_2444 = CAR(pair_2448);
}
}
POP_TRACE();
return aux1263_2444;
}
}
}
}


/* _caadr1371 */obj_t _caadr1371___r4_pairs_and_lists_6_3(obj_t env_1110, obj_t pair_1111)
{
{
obj_t pair_2449;
if(PAIRP(pair_1111)){
pair_2449 = pair_1111;
}
 else {
bigloo_type_error_location_103___error(symbol2699___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1111, string2680___r4_pairs_and_lists_6_3, BINT(((long)9052)));
exit( -1 );}
{
obj_t symbol1264_2450;
symbol1264_2450 = symbol2698___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1264_2450);
BUNSPEC;
{
obj_t aux1263_2451;
{
obj_t arg1012_2452;
{
obj_t arg1013_2453;
arg1013_2453 = CDR(pair_2449);
{
obj_t pair_2454;
if(PAIRP(arg1013_2453)){
pair_2454 = arg1013_2453;
}
 else {
bigloo_type_error_location_103___error(symbol2698___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1013_2453, string2680___r4_pairs_and_lists_6_3, BINT(((long)9088)));
exit( -1 );}
arg1012_2452 = CAR(pair_2454);
}
}
{
obj_t pair_2455;
if(PAIRP(arg1012_2452)){
pair_2455 = arg1012_2452;
}
 else {
bigloo_type_error_location_103___error(symbol2698___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1012_2452, string2680___r4_pairs_and_lists_6_3, BINT(((long)9083)));
exit( -1 );}
aux1263_2451 = CAR(pair_2455);
}
}
POP_TRACE();
return aux1263_2451;
}
}
}
}
}


/* cadar */obj_t cadar___r4_pairs_and_lists_6_3(obj_t pair_17)
{
{
obj_t symbol1266_2456;
symbol1266_2456 = symbol2700___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1266_2456);
BUNSPEC;
{
obj_t aux1265_2457;
{
obj_t arg1014_2458;
{
obj_t arg1015_2459;
arg1015_2459 = CAR(pair_17);
{
obj_t pair_2460;
if(PAIRP(arg1015_2459)){
pair_2460 = arg1015_2459;
}
 else {
bigloo_type_error_location_103___error(symbol2700___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1015_2459, string2680___r4_pairs_and_lists_6_3, BINT(((long)9366)));
exit( -1 );}
arg1014_2458 = CDR(pair_2460);
}
}
{
obj_t pair_2461;
if(PAIRP(arg1014_2458)){
pair_2461 = arg1014_2458;
}
 else {
bigloo_type_error_location_103___error(symbol2700___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1014_2458, string2680___r4_pairs_and_lists_6_3, BINT(((long)9361)));
exit( -1 );}
aux1265_2457 = CAR(pair_2461);
}
}
POP_TRACE();
return aux1265_2457;
}
}
}
}


/* _cadar1372 */obj_t _cadar1372___r4_pairs_and_lists_6_3(obj_t env_1112, obj_t pair_1113)
{
{
obj_t pair_2462;
if(PAIRP(pair_1113)){
pair_2462 = pair_1113;
}
 else {
bigloo_type_error_location_103___error(symbol2701___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1113, string2680___r4_pairs_and_lists_6_3, BINT(((long)9330)));
exit( -1 );}
{
obj_t symbol1266_2463;
symbol1266_2463 = symbol2700___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1266_2463);
BUNSPEC;
{
obj_t aux1265_2464;
{
obj_t arg1014_2465;
{
obj_t arg1015_2466;
arg1015_2466 = CAR(pair_2462);
{
obj_t pair_2467;
if(PAIRP(arg1015_2466)){
pair_2467 = arg1015_2466;
}
 else {
bigloo_type_error_location_103___error(symbol2700___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1015_2466, string2680___r4_pairs_and_lists_6_3, BINT(((long)9366)));
exit( -1 );}
arg1014_2465 = CDR(pair_2467);
}
}
{
obj_t pair_2468;
if(PAIRP(arg1014_2465)){
pair_2468 = arg1014_2465;
}
 else {
bigloo_type_error_location_103___error(symbol2700___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1014_2465, string2680___r4_pairs_and_lists_6_3, BINT(((long)9361)));
exit( -1 );}
aux1265_2464 = CAR(pair_2468);
}
}
POP_TRACE();
return aux1265_2464;
}
}
}
}
}


/* caddr */obj_t caddr___r4_pairs_and_lists_6_3(obj_t pair_18)
{
{
obj_t symbol1268_2469;
symbol1268_2469 = symbol2702___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1268_2469);
BUNSPEC;
{
obj_t aux1267_2470;
{
obj_t arg1016_2471;
{
obj_t arg1017_2472;
arg1017_2472 = CDR(pair_18);
{
obj_t pair_2473;
if(PAIRP(arg1017_2472)){
pair_2473 = arg1017_2472;
}
 else {
bigloo_type_error_location_103___error(symbol2702___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1017_2472, string2680___r4_pairs_and_lists_6_3, BINT(((long)9644)));
exit( -1 );}
arg1016_2471 = CDR(pair_2473);
}
}
{
obj_t pair_2474;
if(PAIRP(arg1016_2471)){
pair_2474 = arg1016_2471;
}
 else {
bigloo_type_error_location_103___error(symbol2702___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1016_2471, string2680___r4_pairs_and_lists_6_3, BINT(((long)9639)));
exit( -1 );}
aux1267_2470 = CAR(pair_2474);
}
}
POP_TRACE();
return aux1267_2470;
}
}
}
}


/* _caddr1373 */obj_t _caddr1373___r4_pairs_and_lists_6_3(obj_t env_1114, obj_t pair_1115)
{
{
obj_t pair_2475;
if(PAIRP(pair_1115)){
pair_2475 = pair_1115;
}
 else {
bigloo_type_error_location_103___error(symbol2703___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1115, string2680___r4_pairs_and_lists_6_3, BINT(((long)9608)));
exit( -1 );}
{
obj_t symbol1268_2476;
symbol1268_2476 = symbol2702___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1268_2476);
BUNSPEC;
{
obj_t aux1267_2477;
{
obj_t arg1016_2478;
{
obj_t arg1017_2479;
arg1017_2479 = CDR(pair_2475);
{
obj_t pair_2480;
if(PAIRP(arg1017_2479)){
pair_2480 = arg1017_2479;
}
 else {
bigloo_type_error_location_103___error(symbol2702___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1017_2479, string2680___r4_pairs_and_lists_6_3, BINT(((long)9644)));
exit( -1 );}
arg1016_2478 = CDR(pair_2480);
}
}
{
obj_t pair_2481;
if(PAIRP(arg1016_2478)){
pair_2481 = arg1016_2478;
}
 else {
bigloo_type_error_location_103___error(symbol2702___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1016_2478, string2680___r4_pairs_and_lists_6_3, BINT(((long)9639)));
exit( -1 );}
aux1267_2477 = CAR(pair_2481);
}
}
POP_TRACE();
return aux1267_2477;
}
}
}
}
}


/* cdaar */obj_t cdaar___r4_pairs_and_lists_6_3(obj_t pair_19)
{
{
obj_t symbol1270_2482;
symbol1270_2482 = symbol2704___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1270_2482);
BUNSPEC;
{
obj_t aux1269_2483;
{
obj_t arg1018_2484;
{
obj_t arg1019_2485;
arg1019_2485 = CAR(pair_19);
{
obj_t pair_2486;
if(PAIRP(arg1019_2485)){
pair_2486 = arg1019_2485;
}
 else {
bigloo_type_error_location_103___error(symbol2704___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1019_2485, string2680___r4_pairs_and_lists_6_3, BINT(((long)9922)));
exit( -1 );}
arg1018_2484 = CAR(pair_2486);
}
}
{
obj_t pair_2487;
if(PAIRP(arg1018_2484)){
pair_2487 = arg1018_2484;
}
 else {
bigloo_type_error_location_103___error(symbol2704___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1018_2484, string2680___r4_pairs_and_lists_6_3, BINT(((long)9917)));
exit( -1 );}
aux1269_2483 = CDR(pair_2487);
}
}
POP_TRACE();
return aux1269_2483;
}
}
}
}


/* _cdaar1374 */obj_t _cdaar1374___r4_pairs_and_lists_6_3(obj_t env_1116, obj_t pair_1117)
{
{
obj_t pair_2488;
if(PAIRP(pair_1117)){
pair_2488 = pair_1117;
}
 else {
bigloo_type_error_location_103___error(symbol2705___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1117, string2680___r4_pairs_and_lists_6_3, BINT(((long)9886)));
exit( -1 );}
{
obj_t symbol1270_2489;
symbol1270_2489 = symbol2704___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1270_2489);
BUNSPEC;
{
obj_t aux1269_2490;
{
obj_t arg1018_2491;
{
obj_t arg1019_2492;
arg1019_2492 = CAR(pair_2488);
{
obj_t pair_2493;
if(PAIRP(arg1019_2492)){
pair_2493 = arg1019_2492;
}
 else {
bigloo_type_error_location_103___error(symbol2704___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1019_2492, string2680___r4_pairs_and_lists_6_3, BINT(((long)9922)));
exit( -1 );}
arg1018_2491 = CAR(pair_2493);
}
}
{
obj_t pair_2494;
if(PAIRP(arg1018_2491)){
pair_2494 = arg1018_2491;
}
 else {
bigloo_type_error_location_103___error(symbol2704___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1018_2491, string2680___r4_pairs_and_lists_6_3, BINT(((long)9917)));
exit( -1 );}
aux1269_2490 = CDR(pair_2494);
}
}
POP_TRACE();
return aux1269_2490;
}
}
}
}
}


/* cddar */obj_t cddar___r4_pairs_and_lists_6_3(obj_t pair_20)
{
{
obj_t symbol1272_2495;
symbol1272_2495 = symbol2706___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1272_2495);
BUNSPEC;
{
obj_t aux1271_2496;
{
obj_t arg1020_2497;
{
obj_t arg1021_2498;
arg1021_2498 = CAR(pair_20);
{
obj_t pair_2499;
if(PAIRP(arg1021_2498)){
pair_2499 = arg1021_2498;
}
 else {
bigloo_type_error_location_103___error(symbol2706___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1021_2498, string2680___r4_pairs_and_lists_6_3, BINT(((long)10200)));
exit( -1 );}
arg1020_2497 = CDR(pair_2499);
}
}
{
obj_t pair_2500;
if(PAIRP(arg1020_2497)){
pair_2500 = arg1020_2497;
}
 else {
bigloo_type_error_location_103___error(symbol2706___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1020_2497, string2680___r4_pairs_and_lists_6_3, BINT(((long)10195)));
exit( -1 );}
aux1271_2496 = CDR(pair_2500);
}
}
POP_TRACE();
return aux1271_2496;
}
}
}
}


/* _cddar1375 */obj_t _cddar1375___r4_pairs_and_lists_6_3(obj_t env_1118, obj_t pair_1119)
{
{
obj_t pair_2501;
if(PAIRP(pair_1119)){
pair_2501 = pair_1119;
}
 else {
bigloo_type_error_location_103___error(symbol2707___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1119, string2680___r4_pairs_and_lists_6_3, BINT(((long)10164)));
exit( -1 );}
{
obj_t symbol1272_2502;
symbol1272_2502 = symbol2706___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1272_2502);
BUNSPEC;
{
obj_t aux1271_2503;
{
obj_t arg1020_2504;
{
obj_t arg1021_2505;
arg1021_2505 = CAR(pair_2501);
{
obj_t pair_2506;
if(PAIRP(arg1021_2505)){
pair_2506 = arg1021_2505;
}
 else {
bigloo_type_error_location_103___error(symbol2706___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1021_2505, string2680___r4_pairs_and_lists_6_3, BINT(((long)10200)));
exit( -1 );}
arg1020_2504 = CDR(pair_2506);
}
}
{
obj_t pair_2507;
if(PAIRP(arg1020_2504)){
pair_2507 = arg1020_2504;
}
 else {
bigloo_type_error_location_103___error(symbol2706___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1020_2504, string2680___r4_pairs_and_lists_6_3, BINT(((long)10195)));
exit( -1 );}
aux1271_2503 = CDR(pair_2507);
}
}
POP_TRACE();
return aux1271_2503;
}
}
}
}
}


/* cdadr */obj_t cdadr___r4_pairs_and_lists_6_3(obj_t pair_21)
{
{
obj_t symbol1274_2508;
symbol1274_2508 = symbol2708___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1274_2508);
BUNSPEC;
{
obj_t aux1273_2509;
{
obj_t arg1022_2510;
{
obj_t arg1023_2511;
arg1023_2511 = CDR(pair_21);
{
obj_t pair_2512;
if(PAIRP(arg1023_2511)){
pair_2512 = arg1023_2511;
}
 else {
bigloo_type_error_location_103___error(symbol2708___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1023_2511, string2680___r4_pairs_and_lists_6_3, BINT(((long)10478)));
exit( -1 );}
arg1022_2510 = CAR(pair_2512);
}
}
{
obj_t pair_2513;
if(PAIRP(arg1022_2510)){
pair_2513 = arg1022_2510;
}
 else {
bigloo_type_error_location_103___error(symbol2708___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1022_2510, string2680___r4_pairs_and_lists_6_3, BINT(((long)10473)));
exit( -1 );}
aux1273_2509 = CDR(pair_2513);
}
}
POP_TRACE();
return aux1273_2509;
}
}
}
}


/* _cdadr1376 */obj_t _cdadr1376___r4_pairs_and_lists_6_3(obj_t env_1120, obj_t pair_1121)
{
{
obj_t pair_2514;
if(PAIRP(pair_1121)){
pair_2514 = pair_1121;
}
 else {
bigloo_type_error_location_103___error(symbol2709___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1121, string2680___r4_pairs_and_lists_6_3, BINT(((long)10442)));
exit( -1 );}
{
obj_t symbol1274_2515;
symbol1274_2515 = symbol2708___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1274_2515);
BUNSPEC;
{
obj_t aux1273_2516;
{
obj_t arg1022_2517;
{
obj_t arg1023_2518;
arg1023_2518 = CDR(pair_2514);
{
obj_t pair_2519;
if(PAIRP(arg1023_2518)){
pair_2519 = arg1023_2518;
}
 else {
bigloo_type_error_location_103___error(symbol2708___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1023_2518, string2680___r4_pairs_and_lists_6_3, BINT(((long)10478)));
exit( -1 );}
arg1022_2517 = CAR(pair_2519);
}
}
{
obj_t pair_2520;
if(PAIRP(arg1022_2517)){
pair_2520 = arg1022_2517;
}
 else {
bigloo_type_error_location_103___error(symbol2708___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1022_2517, string2680___r4_pairs_and_lists_6_3, BINT(((long)10473)));
exit( -1 );}
aux1273_2516 = CDR(pair_2520);
}
}
POP_TRACE();
return aux1273_2516;
}
}
}
}
}


/* cdddr */obj_t cdddr___r4_pairs_and_lists_6_3(obj_t pair_22)
{
{
obj_t symbol1276_2521;
symbol1276_2521 = symbol2710___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1276_2521);
BUNSPEC;
{
obj_t aux1275_2522;
{
obj_t arg1025_2523;
{
obj_t arg1026_2524;
arg1026_2524 = CDR(pair_22);
{
obj_t pair_2525;
if(PAIRP(arg1026_2524)){
pair_2525 = arg1026_2524;
}
 else {
bigloo_type_error_location_103___error(symbol2710___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1026_2524, string2680___r4_pairs_and_lists_6_3, BINT(((long)10756)));
exit( -1 );}
arg1025_2523 = CDR(pair_2525);
}
}
{
obj_t pair_2526;
if(PAIRP(arg1025_2523)){
pair_2526 = arg1025_2523;
}
 else {
bigloo_type_error_location_103___error(symbol2710___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1025_2523, string2680___r4_pairs_and_lists_6_3, BINT(((long)10751)));
exit( -1 );}
aux1275_2522 = CDR(pair_2526);
}
}
POP_TRACE();
return aux1275_2522;
}
}
}
}


/* _cdddr1377 */obj_t _cdddr1377___r4_pairs_and_lists_6_3(obj_t env_1122, obj_t pair_1123)
{
{
obj_t pair_2527;
if(PAIRP(pair_1123)){
pair_2527 = pair_1123;
}
 else {
bigloo_type_error_location_103___error(symbol2711___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1123, string2680___r4_pairs_and_lists_6_3, BINT(((long)10720)));
exit( -1 );}
{
obj_t symbol1276_2528;
symbol1276_2528 = symbol2710___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1276_2528);
BUNSPEC;
{
obj_t aux1275_2529;
{
obj_t arg1025_2530;
{
obj_t arg1026_2531;
arg1026_2531 = CDR(pair_2527);
{
obj_t pair_2532;
if(PAIRP(arg1026_2531)){
pair_2532 = arg1026_2531;
}
 else {
bigloo_type_error_location_103___error(symbol2710___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1026_2531, string2680___r4_pairs_and_lists_6_3, BINT(((long)10756)));
exit( -1 );}
arg1025_2530 = CDR(pair_2532);
}
}
{
obj_t pair_2533;
if(PAIRP(arg1025_2530)){
pair_2533 = arg1025_2530;
}
 else {
bigloo_type_error_location_103___error(symbol2710___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1025_2530, string2680___r4_pairs_and_lists_6_3, BINT(((long)10751)));
exit( -1 );}
aux1275_2529 = CDR(pair_2533);
}
}
POP_TRACE();
return aux1275_2529;
}
}
}
}
}


/* caaaar */obj_t caaaar___r4_pairs_and_lists_6_3(obj_t pair_23)
{
{
obj_t symbol1278_2534;
symbol1278_2534 = symbol2712___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1278_2534);
BUNSPEC;
{
obj_t aux1277_2535;
{
obj_t arg1027_2536;
{
obj_t arg1028_2537;
{
obj_t arg1029_2538;
arg1029_2538 = CAR(pair_23);
{
obj_t pair_2539;
if(PAIRP(arg1029_2538)){
pair_2539 = arg1029_2538;
}
 else {
bigloo_type_error_location_103___error(symbol2712___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1029_2538, string2680___r4_pairs_and_lists_6_3, BINT(((long)11040)));
exit( -1 );}
arg1028_2537 = CAR(pair_2539);
}
}
{
obj_t pair_2540;
if(PAIRP(arg1028_2537)){
pair_2540 = arg1028_2537;
}
 else {
bigloo_type_error_location_103___error(symbol2712___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1028_2537, string2680___r4_pairs_and_lists_6_3, BINT(((long)11035)));
exit( -1 );}
arg1027_2536 = CAR(pair_2540);
}
}
{
obj_t pair_2541;
if(PAIRP(arg1027_2536)){
pair_2541 = arg1027_2536;
}
 else {
bigloo_type_error_location_103___error(symbol2712___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1027_2536, string2680___r4_pairs_and_lists_6_3, BINT(((long)11030)));
exit( -1 );}
aux1277_2535 = CAR(pair_2541);
}
}
POP_TRACE();
return aux1277_2535;
}
}
}
}


/* _caaaar1378 */obj_t _caaaar1378___r4_pairs_and_lists_6_3(obj_t env_1124, obj_t pair_1125)
{
{
obj_t pair_2542;
if(PAIRP(pair_1125)){
pair_2542 = pair_1125;
}
 else {
bigloo_type_error_location_103___error(symbol2713___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1125, string2680___r4_pairs_and_lists_6_3, BINT(((long)10998)));
exit( -1 );}
{
obj_t symbol1278_2543;
symbol1278_2543 = symbol2712___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1278_2543);
BUNSPEC;
{
obj_t aux1277_2544;
{
obj_t arg1027_2545;
{
obj_t arg1028_2546;
{
obj_t arg1029_2547;
arg1029_2547 = CAR(pair_2542);
{
obj_t pair_2548;
if(PAIRP(arg1029_2547)){
pair_2548 = arg1029_2547;
}
 else {
bigloo_type_error_location_103___error(symbol2712___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1029_2547, string2680___r4_pairs_and_lists_6_3, BINT(((long)11040)));
exit( -1 );}
arg1028_2546 = CAR(pair_2548);
}
}
{
obj_t pair_2549;
if(PAIRP(arg1028_2546)){
pair_2549 = arg1028_2546;
}
 else {
bigloo_type_error_location_103___error(symbol2712___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1028_2546, string2680___r4_pairs_and_lists_6_3, BINT(((long)11035)));
exit( -1 );}
arg1027_2545 = CAR(pair_2549);
}
}
{
obj_t pair_2550;
if(PAIRP(arg1027_2545)){
pair_2550 = arg1027_2545;
}
 else {
bigloo_type_error_location_103___error(symbol2712___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1027_2545, string2680___r4_pairs_and_lists_6_3, BINT(((long)11030)));
exit( -1 );}
aux1277_2544 = CAR(pair_2550);
}
}
POP_TRACE();
return aux1277_2544;
}
}
}
}
}


/* caaadr */obj_t caaadr___r4_pairs_and_lists_6_3(obj_t pair_24)
{
{
obj_t symbol1280_2551;
symbol1280_2551 = symbol2714___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1280_2551);
BUNSPEC;
{
obj_t aux1279_2552;
{
obj_t arg1030_2553;
{
obj_t arg1031_2554;
{
obj_t arg1032_2555;
arg1032_2555 = CDR(pair_24);
{
obj_t pair_2556;
if(PAIRP(arg1032_2555)){
pair_2556 = arg1032_2555;
}
 else {
bigloo_type_error_location_103___error(symbol2714___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1032_2555, string2680___r4_pairs_and_lists_6_3, BINT(((long)11325)));
exit( -1 );}
arg1031_2554 = CAR(pair_2556);
}
}
{
obj_t pair_2557;
if(PAIRP(arg1031_2554)){
pair_2557 = arg1031_2554;
}
 else {
bigloo_type_error_location_103___error(symbol2714___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1031_2554, string2680___r4_pairs_and_lists_6_3, BINT(((long)11320)));
exit( -1 );}
arg1030_2553 = CAR(pair_2557);
}
}
{
obj_t pair_2558;
if(PAIRP(arg1030_2553)){
pair_2558 = arg1030_2553;
}
 else {
bigloo_type_error_location_103___error(symbol2714___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1030_2553, string2680___r4_pairs_and_lists_6_3, BINT(((long)11315)));
exit( -1 );}
aux1279_2552 = CAR(pair_2558);
}
}
POP_TRACE();
return aux1279_2552;
}
}
}
}


/* _caaadr1379 */obj_t _caaadr1379___r4_pairs_and_lists_6_3(obj_t env_1126, obj_t pair_1127)
{
{
obj_t pair_2559;
if(PAIRP(pair_1127)){
pair_2559 = pair_1127;
}
 else {
bigloo_type_error_location_103___error(symbol2715___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1127, string2680___r4_pairs_and_lists_6_3, BINT(((long)11283)));
exit( -1 );}
{
obj_t symbol1280_2560;
symbol1280_2560 = symbol2714___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1280_2560);
BUNSPEC;
{
obj_t aux1279_2561;
{
obj_t arg1030_2562;
{
obj_t arg1031_2563;
{
obj_t arg1032_2564;
arg1032_2564 = CDR(pair_2559);
{
obj_t pair_2565;
if(PAIRP(arg1032_2564)){
pair_2565 = arg1032_2564;
}
 else {
bigloo_type_error_location_103___error(symbol2714___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1032_2564, string2680___r4_pairs_and_lists_6_3, BINT(((long)11325)));
exit( -1 );}
arg1031_2563 = CAR(pair_2565);
}
}
{
obj_t pair_2566;
if(PAIRP(arg1031_2563)){
pair_2566 = arg1031_2563;
}
 else {
bigloo_type_error_location_103___error(symbol2714___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1031_2563, string2680___r4_pairs_and_lists_6_3, BINT(((long)11320)));
exit( -1 );}
arg1030_2562 = CAR(pair_2566);
}
}
{
obj_t pair_2567;
if(PAIRP(arg1030_2562)){
pair_2567 = arg1030_2562;
}
 else {
bigloo_type_error_location_103___error(symbol2714___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1030_2562, string2680___r4_pairs_and_lists_6_3, BINT(((long)11315)));
exit( -1 );}
aux1279_2561 = CAR(pair_2567);
}
}
POP_TRACE();
return aux1279_2561;
}
}
}
}
}


/* caadar */obj_t caadar___r4_pairs_and_lists_6_3(obj_t pair_25)
{
{
obj_t symbol1282_2568;
symbol1282_2568 = symbol2716___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1282_2568);
BUNSPEC;
{
obj_t aux1281_2569;
{
obj_t arg1033_2570;
{
obj_t arg1034_2571;
{
obj_t arg1035_2572;
arg1035_2572 = CAR(pair_25);
{
obj_t pair_2573;
if(PAIRP(arg1035_2572)){
pair_2573 = arg1035_2572;
}
 else {
bigloo_type_error_location_103___error(symbol2716___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1035_2572, string2680___r4_pairs_and_lists_6_3, BINT(((long)11610)));
exit( -1 );}
arg1034_2571 = CDR(pair_2573);
}
}
{
obj_t pair_2574;
if(PAIRP(arg1034_2571)){
pair_2574 = arg1034_2571;
}
 else {
bigloo_type_error_location_103___error(symbol2716___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1034_2571, string2680___r4_pairs_and_lists_6_3, BINT(((long)11605)));
exit( -1 );}
arg1033_2570 = CAR(pair_2574);
}
}
{
obj_t pair_2575;
if(PAIRP(arg1033_2570)){
pair_2575 = arg1033_2570;
}
 else {
bigloo_type_error_location_103___error(symbol2716___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1033_2570, string2680___r4_pairs_and_lists_6_3, BINT(((long)11600)));
exit( -1 );}
aux1281_2569 = CAR(pair_2575);
}
}
POP_TRACE();
return aux1281_2569;
}
}
}
}


/* _caadar1380 */obj_t _caadar1380___r4_pairs_and_lists_6_3(obj_t env_1128, obj_t pair_1129)
{
{
obj_t pair_2576;
if(PAIRP(pair_1129)){
pair_2576 = pair_1129;
}
 else {
bigloo_type_error_location_103___error(symbol2717___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1129, string2680___r4_pairs_and_lists_6_3, BINT(((long)11568)));
exit( -1 );}
{
obj_t symbol1282_2577;
symbol1282_2577 = symbol2716___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1282_2577);
BUNSPEC;
{
obj_t aux1281_2578;
{
obj_t arg1033_2579;
{
obj_t arg1034_2580;
{
obj_t arg1035_2581;
arg1035_2581 = CAR(pair_2576);
{
obj_t pair_2582;
if(PAIRP(arg1035_2581)){
pair_2582 = arg1035_2581;
}
 else {
bigloo_type_error_location_103___error(symbol2716___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1035_2581, string2680___r4_pairs_and_lists_6_3, BINT(((long)11610)));
exit( -1 );}
arg1034_2580 = CDR(pair_2582);
}
}
{
obj_t pair_2583;
if(PAIRP(arg1034_2580)){
pair_2583 = arg1034_2580;
}
 else {
bigloo_type_error_location_103___error(symbol2716___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1034_2580, string2680___r4_pairs_and_lists_6_3, BINT(((long)11605)));
exit( -1 );}
arg1033_2579 = CAR(pair_2583);
}
}
{
obj_t pair_2584;
if(PAIRP(arg1033_2579)){
pair_2584 = arg1033_2579;
}
 else {
bigloo_type_error_location_103___error(symbol2716___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1033_2579, string2680___r4_pairs_and_lists_6_3, BINT(((long)11600)));
exit( -1 );}
aux1281_2578 = CAR(pair_2584);
}
}
POP_TRACE();
return aux1281_2578;
}
}
}
}
}


/* cadaar */obj_t cadaar___r4_pairs_and_lists_6_3(obj_t pair_26)
{
{
obj_t symbol1284_2585;
symbol1284_2585 = symbol2718___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1284_2585);
BUNSPEC;
{
obj_t aux1283_2586;
{
obj_t arg1037_2587;
{
obj_t arg1038_2588;
{
obj_t arg1039_2589;
arg1039_2589 = CAR(pair_26);
{
obj_t pair_2590;
if(PAIRP(arg1039_2589)){
pair_2590 = arg1039_2589;
}
 else {
bigloo_type_error_location_103___error(symbol2718___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1039_2589, string2680___r4_pairs_and_lists_6_3, BINT(((long)11895)));
exit( -1 );}
arg1038_2588 = CAR(pair_2590);
}
}
{
obj_t pair_2591;
if(PAIRP(arg1038_2588)){
pair_2591 = arg1038_2588;
}
 else {
bigloo_type_error_location_103___error(symbol2718___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1038_2588, string2680___r4_pairs_and_lists_6_3, BINT(((long)11890)));
exit( -1 );}
arg1037_2587 = CDR(pair_2591);
}
}
{
obj_t pair_2592;
if(PAIRP(arg1037_2587)){
pair_2592 = arg1037_2587;
}
 else {
bigloo_type_error_location_103___error(symbol2718___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1037_2587, string2680___r4_pairs_and_lists_6_3, BINT(((long)11885)));
exit( -1 );}
aux1283_2586 = CAR(pair_2592);
}
}
POP_TRACE();
return aux1283_2586;
}
}
}
}


/* _cadaar1381 */obj_t _cadaar1381___r4_pairs_and_lists_6_3(obj_t env_1130, obj_t pair_1131)
{
{
obj_t pair_2593;
if(PAIRP(pair_1131)){
pair_2593 = pair_1131;
}
 else {
bigloo_type_error_location_103___error(symbol2719___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1131, string2680___r4_pairs_and_lists_6_3, BINT(((long)11853)));
exit( -1 );}
{
obj_t symbol1284_2594;
symbol1284_2594 = symbol2718___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1284_2594);
BUNSPEC;
{
obj_t aux1283_2595;
{
obj_t arg1037_2596;
{
obj_t arg1038_2597;
{
obj_t arg1039_2598;
arg1039_2598 = CAR(pair_2593);
{
obj_t pair_2599;
if(PAIRP(arg1039_2598)){
pair_2599 = arg1039_2598;
}
 else {
bigloo_type_error_location_103___error(symbol2718___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1039_2598, string2680___r4_pairs_and_lists_6_3, BINT(((long)11895)));
exit( -1 );}
arg1038_2597 = CAR(pair_2599);
}
}
{
obj_t pair_2600;
if(PAIRP(arg1038_2597)){
pair_2600 = arg1038_2597;
}
 else {
bigloo_type_error_location_103___error(symbol2718___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1038_2597, string2680___r4_pairs_and_lists_6_3, BINT(((long)11890)));
exit( -1 );}
arg1037_2596 = CDR(pair_2600);
}
}
{
obj_t pair_2601;
if(PAIRP(arg1037_2596)){
pair_2601 = arg1037_2596;
}
 else {
bigloo_type_error_location_103___error(symbol2718___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1037_2596, string2680___r4_pairs_and_lists_6_3, BINT(((long)11885)));
exit( -1 );}
aux1283_2595 = CAR(pair_2601);
}
}
POP_TRACE();
return aux1283_2595;
}
}
}
}
}


/* cdaaar */obj_t cdaaar___r4_pairs_and_lists_6_3(obj_t pair_27)
{
{
obj_t symbol1286_2602;
symbol1286_2602 = symbol2720___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1286_2602);
BUNSPEC;
{
obj_t aux1285_2603;
{
obj_t arg1040_2604;
{
obj_t arg1041_2605;
{
obj_t arg1042_2606;
arg1042_2606 = CAR(pair_27);
{
obj_t pair_2607;
if(PAIRP(arg1042_2606)){
pair_2607 = arg1042_2606;
}
 else {
bigloo_type_error_location_103___error(symbol2720___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1042_2606, string2680___r4_pairs_and_lists_6_3, BINT(((long)12180)));
exit( -1 );}
arg1041_2605 = CAR(pair_2607);
}
}
{
obj_t pair_2608;
if(PAIRP(arg1041_2605)){
pair_2608 = arg1041_2605;
}
 else {
bigloo_type_error_location_103___error(symbol2720___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1041_2605, string2680___r4_pairs_and_lists_6_3, BINT(((long)12175)));
exit( -1 );}
arg1040_2604 = CAR(pair_2608);
}
}
{
obj_t pair_2609;
if(PAIRP(arg1040_2604)){
pair_2609 = arg1040_2604;
}
 else {
bigloo_type_error_location_103___error(symbol2720___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1040_2604, string2680___r4_pairs_and_lists_6_3, BINT(((long)12170)));
exit( -1 );}
aux1285_2603 = CDR(pair_2609);
}
}
POP_TRACE();
return aux1285_2603;
}
}
}
}


/* _cdaaar1382 */obj_t _cdaaar1382___r4_pairs_and_lists_6_3(obj_t env_1132, obj_t pair_1133)
{
{
obj_t pair_2610;
if(PAIRP(pair_1133)){
pair_2610 = pair_1133;
}
 else {
bigloo_type_error_location_103___error(symbol2721___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1133, string2680___r4_pairs_and_lists_6_3, BINT(((long)12138)));
exit( -1 );}
{
obj_t symbol1286_2611;
symbol1286_2611 = symbol2720___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1286_2611);
BUNSPEC;
{
obj_t aux1285_2612;
{
obj_t arg1040_2613;
{
obj_t arg1041_2614;
{
obj_t arg1042_2615;
arg1042_2615 = CAR(pair_2610);
{
obj_t pair_2616;
if(PAIRP(arg1042_2615)){
pair_2616 = arg1042_2615;
}
 else {
bigloo_type_error_location_103___error(symbol2720___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1042_2615, string2680___r4_pairs_and_lists_6_3, BINT(((long)12180)));
exit( -1 );}
arg1041_2614 = CAR(pair_2616);
}
}
{
obj_t pair_2617;
if(PAIRP(arg1041_2614)){
pair_2617 = arg1041_2614;
}
 else {
bigloo_type_error_location_103___error(symbol2720___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1041_2614, string2680___r4_pairs_and_lists_6_3, BINT(((long)12175)));
exit( -1 );}
arg1040_2613 = CAR(pair_2617);
}
}
{
obj_t pair_2618;
if(PAIRP(arg1040_2613)){
pair_2618 = arg1040_2613;
}
 else {
bigloo_type_error_location_103___error(symbol2720___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1040_2613, string2680___r4_pairs_and_lists_6_3, BINT(((long)12170)));
exit( -1 );}
aux1285_2612 = CDR(pair_2618);
}
}
POP_TRACE();
return aux1285_2612;
}
}
}
}
}


/* caaddr */obj_t caaddr___r4_pairs_and_lists_6_3(obj_t pair_28)
{
{
obj_t symbol1288_2619;
symbol1288_2619 = symbol2722___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1288_2619);
BUNSPEC;
{
obj_t aux1287_2620;
{
obj_t arg1043_2621;
{
obj_t arg1044_2622;
{
obj_t arg1045_2623;
arg1045_2623 = CDR(pair_28);
{
obj_t pair_2624;
if(PAIRP(arg1045_2623)){
pair_2624 = arg1045_2623;
}
 else {
bigloo_type_error_location_103___error(symbol2722___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1045_2623, string2680___r4_pairs_and_lists_6_3, BINT(((long)12465)));
exit( -1 );}
arg1044_2622 = CDR(pair_2624);
}
}
{
obj_t pair_2625;
if(PAIRP(arg1044_2622)){
pair_2625 = arg1044_2622;
}
 else {
bigloo_type_error_location_103___error(symbol2722___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1044_2622, string2680___r4_pairs_and_lists_6_3, BINT(((long)12460)));
exit( -1 );}
arg1043_2621 = CAR(pair_2625);
}
}
{
obj_t pair_2626;
if(PAIRP(arg1043_2621)){
pair_2626 = arg1043_2621;
}
 else {
bigloo_type_error_location_103___error(symbol2722___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1043_2621, string2680___r4_pairs_and_lists_6_3, BINT(((long)12455)));
exit( -1 );}
aux1287_2620 = CAR(pair_2626);
}
}
POP_TRACE();
return aux1287_2620;
}
}
}
}


/* _caaddr1383 */obj_t _caaddr1383___r4_pairs_and_lists_6_3(obj_t env_1134, obj_t pair_1135)
{
{
obj_t pair_2627;
if(PAIRP(pair_1135)){
pair_2627 = pair_1135;
}
 else {
bigloo_type_error_location_103___error(symbol2723___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1135, string2680___r4_pairs_and_lists_6_3, BINT(((long)12423)));
exit( -1 );}
{
obj_t symbol1288_2628;
symbol1288_2628 = symbol2722___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1288_2628);
BUNSPEC;
{
obj_t aux1287_2629;
{
obj_t arg1043_2630;
{
obj_t arg1044_2631;
{
obj_t arg1045_2632;
arg1045_2632 = CDR(pair_2627);
{
obj_t pair_2633;
if(PAIRP(arg1045_2632)){
pair_2633 = arg1045_2632;
}
 else {
bigloo_type_error_location_103___error(symbol2722___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1045_2632, string2680___r4_pairs_and_lists_6_3, BINT(((long)12465)));
exit( -1 );}
arg1044_2631 = CDR(pair_2633);
}
}
{
obj_t pair_2634;
if(PAIRP(arg1044_2631)){
pair_2634 = arg1044_2631;
}
 else {
bigloo_type_error_location_103___error(symbol2722___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1044_2631, string2680___r4_pairs_and_lists_6_3, BINT(((long)12460)));
exit( -1 );}
arg1043_2630 = CAR(pair_2634);
}
}
{
obj_t pair_2635;
if(PAIRP(arg1043_2630)){
pair_2635 = arg1043_2630;
}
 else {
bigloo_type_error_location_103___error(symbol2722___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1043_2630, string2680___r4_pairs_and_lists_6_3, BINT(((long)12455)));
exit( -1 );}
aux1287_2629 = CAR(pair_2635);
}
}
POP_TRACE();
return aux1287_2629;
}
}
}
}
}


/* caddar */obj_t caddar___r4_pairs_and_lists_6_3(obj_t pair_29)
{
{
obj_t symbol1290_2636;
symbol1290_2636 = symbol2724___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1290_2636);
BUNSPEC;
{
obj_t aux1289_2637;
{
obj_t arg1046_2638;
{
obj_t arg1047_2639;
{
obj_t arg1048_2640;
arg1048_2640 = CAR(pair_29);
{
obj_t pair_2641;
if(PAIRP(arg1048_2640)){
pair_2641 = arg1048_2640;
}
 else {
bigloo_type_error_location_103___error(symbol2724___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1048_2640, string2680___r4_pairs_and_lists_6_3, BINT(((long)12750)));
exit( -1 );}
arg1047_2639 = CDR(pair_2641);
}
}
{
obj_t pair_2642;
if(PAIRP(arg1047_2639)){
pair_2642 = arg1047_2639;
}
 else {
bigloo_type_error_location_103___error(symbol2724___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1047_2639, string2680___r4_pairs_and_lists_6_3, BINT(((long)12745)));
exit( -1 );}
arg1046_2638 = CDR(pair_2642);
}
}
{
obj_t pair_2643;
if(PAIRP(arg1046_2638)){
pair_2643 = arg1046_2638;
}
 else {
bigloo_type_error_location_103___error(symbol2724___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1046_2638, string2680___r4_pairs_and_lists_6_3, BINT(((long)12740)));
exit( -1 );}
aux1289_2637 = CAR(pair_2643);
}
}
POP_TRACE();
return aux1289_2637;
}
}
}
}


/* _caddar1384 */obj_t _caddar1384___r4_pairs_and_lists_6_3(obj_t env_1136, obj_t pair_1137)
{
{
obj_t pair_2644;
if(PAIRP(pair_1137)){
pair_2644 = pair_1137;
}
 else {
bigloo_type_error_location_103___error(symbol2725___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1137, string2680___r4_pairs_and_lists_6_3, BINT(((long)12708)));
exit( -1 );}
{
obj_t symbol1290_2645;
symbol1290_2645 = symbol2724___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1290_2645);
BUNSPEC;
{
obj_t aux1289_2646;
{
obj_t arg1046_2647;
{
obj_t arg1047_2648;
{
obj_t arg1048_2649;
arg1048_2649 = CAR(pair_2644);
{
obj_t pair_2650;
if(PAIRP(arg1048_2649)){
pair_2650 = arg1048_2649;
}
 else {
bigloo_type_error_location_103___error(symbol2724___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1048_2649, string2680___r4_pairs_and_lists_6_3, BINT(((long)12750)));
exit( -1 );}
arg1047_2648 = CDR(pair_2650);
}
}
{
obj_t pair_2651;
if(PAIRP(arg1047_2648)){
pair_2651 = arg1047_2648;
}
 else {
bigloo_type_error_location_103___error(symbol2724___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1047_2648, string2680___r4_pairs_and_lists_6_3, BINT(((long)12745)));
exit( -1 );}
arg1046_2647 = CDR(pair_2651);
}
}
{
obj_t pair_2652;
if(PAIRP(arg1046_2647)){
pair_2652 = arg1046_2647;
}
 else {
bigloo_type_error_location_103___error(symbol2724___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1046_2647, string2680___r4_pairs_and_lists_6_3, BINT(((long)12740)));
exit( -1 );}
aux1289_2646 = CAR(pair_2652);
}
}
POP_TRACE();
return aux1289_2646;
}
}
}
}
}


/* cadadr */obj_t cadadr___r4_pairs_and_lists_6_3(obj_t pair_30)
{
{
obj_t symbol1292_2653;
symbol1292_2653 = symbol2726___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1292_2653);
BUNSPEC;
{
obj_t aux1291_2654;
{
obj_t arg1049_2655;
{
obj_t arg1050_2656;
{
obj_t arg1051_2657;
arg1051_2657 = CDR(pair_30);
{
obj_t pair_2658;
if(PAIRP(arg1051_2657)){
pair_2658 = arg1051_2657;
}
 else {
bigloo_type_error_location_103___error(symbol2726___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1051_2657, string2680___r4_pairs_and_lists_6_3, BINT(((long)13035)));
exit( -1 );}
arg1050_2656 = CAR(pair_2658);
}
}
{
obj_t pair_2659;
if(PAIRP(arg1050_2656)){
pair_2659 = arg1050_2656;
}
 else {
bigloo_type_error_location_103___error(symbol2726___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1050_2656, string2680___r4_pairs_and_lists_6_3, BINT(((long)13030)));
exit( -1 );}
arg1049_2655 = CDR(pair_2659);
}
}
{
obj_t pair_2660;
if(PAIRP(arg1049_2655)){
pair_2660 = arg1049_2655;
}
 else {
bigloo_type_error_location_103___error(symbol2726___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1049_2655, string2680___r4_pairs_and_lists_6_3, BINT(((long)13025)));
exit( -1 );}
aux1291_2654 = CAR(pair_2660);
}
}
POP_TRACE();
return aux1291_2654;
}
}
}
}


/* _cadadr1385 */obj_t _cadadr1385___r4_pairs_and_lists_6_3(obj_t env_1138, obj_t pair_1139)
{
{
obj_t pair_2661;
if(PAIRP(pair_1139)){
pair_2661 = pair_1139;
}
 else {
bigloo_type_error_location_103___error(symbol2727___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1139, string2680___r4_pairs_and_lists_6_3, BINT(((long)12993)));
exit( -1 );}
{
obj_t symbol1292_2662;
symbol1292_2662 = symbol2726___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1292_2662);
BUNSPEC;
{
obj_t aux1291_2663;
{
obj_t arg1049_2664;
{
obj_t arg1050_2665;
{
obj_t arg1051_2666;
arg1051_2666 = CDR(pair_2661);
{
obj_t pair_2667;
if(PAIRP(arg1051_2666)){
pair_2667 = arg1051_2666;
}
 else {
bigloo_type_error_location_103___error(symbol2726___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1051_2666, string2680___r4_pairs_and_lists_6_3, BINT(((long)13035)));
exit( -1 );}
arg1050_2665 = CAR(pair_2667);
}
}
{
obj_t pair_2668;
if(PAIRP(arg1050_2665)){
pair_2668 = arg1050_2665;
}
 else {
bigloo_type_error_location_103___error(symbol2726___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1050_2665, string2680___r4_pairs_and_lists_6_3, BINT(((long)13030)));
exit( -1 );}
arg1049_2664 = CDR(pair_2668);
}
}
{
obj_t pair_2669;
if(PAIRP(arg1049_2664)){
pair_2669 = arg1049_2664;
}
 else {
bigloo_type_error_location_103___error(symbol2726___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1049_2664, string2680___r4_pairs_and_lists_6_3, BINT(((long)13025)));
exit( -1 );}
aux1291_2663 = CAR(pair_2669);
}
}
POP_TRACE();
return aux1291_2663;
}
}
}
}
}


/* cadddr */obj_t cadddr___r4_pairs_and_lists_6_3(obj_t pair_31)
{
{
obj_t symbol1294_2670;
symbol1294_2670 = symbol2728___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1294_2670);
BUNSPEC;
{
obj_t aux1293_2671;
{
obj_t arg1053_2672;
{
obj_t arg1054_2673;
{
obj_t arg1055_2674;
arg1055_2674 = CDR(pair_31);
{
obj_t pair_2675;
if(PAIRP(arg1055_2674)){
pair_2675 = arg1055_2674;
}
 else {
bigloo_type_error_location_103___error(symbol2728___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1055_2674, string2680___r4_pairs_and_lists_6_3, BINT(((long)13320)));
exit( -1 );}
arg1054_2673 = CDR(pair_2675);
}
}
{
obj_t pair_2676;
if(PAIRP(arg1054_2673)){
pair_2676 = arg1054_2673;
}
 else {
bigloo_type_error_location_103___error(symbol2728___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1054_2673, string2680___r4_pairs_and_lists_6_3, BINT(((long)13315)));
exit( -1 );}
arg1053_2672 = CDR(pair_2676);
}
}
{
obj_t pair_2677;
if(PAIRP(arg1053_2672)){
pair_2677 = arg1053_2672;
}
 else {
bigloo_type_error_location_103___error(symbol2728___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1053_2672, string2680___r4_pairs_and_lists_6_3, BINT(((long)13310)));
exit( -1 );}
aux1293_2671 = CAR(pair_2677);
}
}
POP_TRACE();
return aux1293_2671;
}
}
}
}


/* _cadddr1386 */obj_t _cadddr1386___r4_pairs_and_lists_6_3(obj_t env_1140, obj_t pair_1141)
{
{
obj_t pair_2678;
if(PAIRP(pair_1141)){
pair_2678 = pair_1141;
}
 else {
bigloo_type_error_location_103___error(symbol2729___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1141, string2680___r4_pairs_and_lists_6_3, BINT(((long)13278)));
exit( -1 );}
{
obj_t symbol1294_2679;
symbol1294_2679 = symbol2728___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1294_2679);
BUNSPEC;
{
obj_t aux1293_2680;
{
obj_t arg1053_2681;
{
obj_t arg1054_2682;
{
obj_t arg1055_2683;
arg1055_2683 = CDR(pair_2678);
{
obj_t pair_2684;
if(PAIRP(arg1055_2683)){
pair_2684 = arg1055_2683;
}
 else {
bigloo_type_error_location_103___error(symbol2728___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1055_2683, string2680___r4_pairs_and_lists_6_3, BINT(((long)13320)));
exit( -1 );}
arg1054_2682 = CDR(pair_2684);
}
}
{
obj_t pair_2685;
if(PAIRP(arg1054_2682)){
pair_2685 = arg1054_2682;
}
 else {
bigloo_type_error_location_103___error(symbol2728___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1054_2682, string2680___r4_pairs_and_lists_6_3, BINT(((long)13315)));
exit( -1 );}
arg1053_2681 = CDR(pair_2685);
}
}
{
obj_t pair_2686;
if(PAIRP(arg1053_2681)){
pair_2686 = arg1053_2681;
}
 else {
bigloo_type_error_location_103___error(symbol2728___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1053_2681, string2680___r4_pairs_and_lists_6_3, BINT(((long)13310)));
exit( -1 );}
aux1293_2680 = CAR(pair_2686);
}
}
POP_TRACE();
return aux1293_2680;
}
}
}
}
}


/* cdaadr */obj_t cdaadr___r4_pairs_and_lists_6_3(obj_t pair_32)
{
{
obj_t symbol1296_2687;
symbol1296_2687 = symbol2730___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1296_2687);
BUNSPEC;
{
obj_t aux1295_2688;
{
obj_t arg1056_2689;
{
obj_t arg1057_2690;
{
obj_t arg1058_2691;
arg1058_2691 = CDR(pair_32);
{
obj_t pair_2692;
if(PAIRP(arg1058_2691)){
pair_2692 = arg1058_2691;
}
 else {
bigloo_type_error_location_103___error(symbol2730___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1058_2691, string2680___r4_pairs_and_lists_6_3, BINT(((long)13605)));
exit( -1 );}
arg1057_2690 = CAR(pair_2692);
}
}
{
obj_t pair_2693;
if(PAIRP(arg1057_2690)){
pair_2693 = arg1057_2690;
}
 else {
bigloo_type_error_location_103___error(symbol2730___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1057_2690, string2680___r4_pairs_and_lists_6_3, BINT(((long)13600)));
exit( -1 );}
arg1056_2689 = CAR(pair_2693);
}
}
{
obj_t pair_2694;
if(PAIRP(arg1056_2689)){
pair_2694 = arg1056_2689;
}
 else {
bigloo_type_error_location_103___error(symbol2730___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1056_2689, string2680___r4_pairs_and_lists_6_3, BINT(((long)13595)));
exit( -1 );}
aux1295_2688 = CDR(pair_2694);
}
}
POP_TRACE();
return aux1295_2688;
}
}
}
}


/* _cdaadr1387 */obj_t _cdaadr1387___r4_pairs_and_lists_6_3(obj_t env_1142, obj_t pair_1143)
{
{
obj_t pair_2695;
if(PAIRP(pair_1143)){
pair_2695 = pair_1143;
}
 else {
bigloo_type_error_location_103___error(symbol2731___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1143, string2680___r4_pairs_and_lists_6_3, BINT(((long)13563)));
exit( -1 );}
{
obj_t symbol1296_2696;
symbol1296_2696 = symbol2730___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1296_2696);
BUNSPEC;
{
obj_t aux1295_2697;
{
obj_t arg1056_2698;
{
obj_t arg1057_2699;
{
obj_t arg1058_2700;
arg1058_2700 = CDR(pair_2695);
{
obj_t pair_2701;
if(PAIRP(arg1058_2700)){
pair_2701 = arg1058_2700;
}
 else {
bigloo_type_error_location_103___error(symbol2730___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1058_2700, string2680___r4_pairs_and_lists_6_3, BINT(((long)13605)));
exit( -1 );}
arg1057_2699 = CAR(pair_2701);
}
}
{
obj_t pair_2702;
if(PAIRP(arg1057_2699)){
pair_2702 = arg1057_2699;
}
 else {
bigloo_type_error_location_103___error(symbol2730___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1057_2699, string2680___r4_pairs_and_lists_6_3, BINT(((long)13600)));
exit( -1 );}
arg1056_2698 = CAR(pair_2702);
}
}
{
obj_t pair_2703;
if(PAIRP(arg1056_2698)){
pair_2703 = arg1056_2698;
}
 else {
bigloo_type_error_location_103___error(symbol2730___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1056_2698, string2680___r4_pairs_and_lists_6_3, BINT(((long)13595)));
exit( -1 );}
aux1295_2697 = CDR(pair_2703);
}
}
POP_TRACE();
return aux1295_2697;
}
}
}
}
}


/* cdaddr */obj_t cdaddr___r4_pairs_and_lists_6_3(obj_t pair_33)
{
{
obj_t symbol1298_2704;
symbol1298_2704 = symbol2732___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1298_2704);
BUNSPEC;
{
obj_t aux1297_2705;
{
obj_t arg1059_2706;
{
obj_t arg1060_2707;
{
obj_t arg1061_2708;
arg1061_2708 = CDR(pair_33);
{
obj_t pair_2709;
if(PAIRP(arg1061_2708)){
pair_2709 = arg1061_2708;
}
 else {
bigloo_type_error_location_103___error(symbol2732___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1061_2708, string2680___r4_pairs_and_lists_6_3, BINT(((long)13890)));
exit( -1 );}
arg1060_2707 = CDR(pair_2709);
}
}
{
obj_t pair_2710;
if(PAIRP(arg1060_2707)){
pair_2710 = arg1060_2707;
}
 else {
bigloo_type_error_location_103___error(symbol2732___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1060_2707, string2680___r4_pairs_and_lists_6_3, BINT(((long)13885)));
exit( -1 );}
arg1059_2706 = CAR(pair_2710);
}
}
{
obj_t pair_2711;
if(PAIRP(arg1059_2706)){
pair_2711 = arg1059_2706;
}
 else {
bigloo_type_error_location_103___error(symbol2732___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1059_2706, string2680___r4_pairs_and_lists_6_3, BINT(((long)13880)));
exit( -1 );}
aux1297_2705 = CDR(pair_2711);
}
}
POP_TRACE();
return aux1297_2705;
}
}
}
}


/* _cdaddr1388 */obj_t _cdaddr1388___r4_pairs_and_lists_6_3(obj_t env_1144, obj_t pair_1145)
{
{
obj_t pair_2712;
if(PAIRP(pair_1145)){
pair_2712 = pair_1145;
}
 else {
bigloo_type_error_location_103___error(symbol2733___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1145, string2680___r4_pairs_and_lists_6_3, BINT(((long)13848)));
exit( -1 );}
{
obj_t symbol1298_2713;
symbol1298_2713 = symbol2732___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1298_2713);
BUNSPEC;
{
obj_t aux1297_2714;
{
obj_t arg1059_2715;
{
obj_t arg1060_2716;
{
obj_t arg1061_2717;
arg1061_2717 = CDR(pair_2712);
{
obj_t pair_2718;
if(PAIRP(arg1061_2717)){
pair_2718 = arg1061_2717;
}
 else {
bigloo_type_error_location_103___error(symbol2732___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1061_2717, string2680___r4_pairs_and_lists_6_3, BINT(((long)13890)));
exit( -1 );}
arg1060_2716 = CDR(pair_2718);
}
}
{
obj_t pair_2719;
if(PAIRP(arg1060_2716)){
pair_2719 = arg1060_2716;
}
 else {
bigloo_type_error_location_103___error(symbol2732___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1060_2716, string2680___r4_pairs_and_lists_6_3, BINT(((long)13885)));
exit( -1 );}
arg1059_2715 = CAR(pair_2719);
}
}
{
obj_t pair_2720;
if(PAIRP(arg1059_2715)){
pair_2720 = arg1059_2715;
}
 else {
bigloo_type_error_location_103___error(symbol2732___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1059_2715, string2680___r4_pairs_and_lists_6_3, BINT(((long)13880)));
exit( -1 );}
aux1297_2714 = CDR(pair_2720);
}
}
POP_TRACE();
return aux1297_2714;
}
}
}
}
}


/* cddaar */obj_t cddaar___r4_pairs_and_lists_6_3(obj_t pair_34)
{
{
obj_t symbol1300_2721;
symbol1300_2721 = symbol2734___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1300_2721);
BUNSPEC;
{
obj_t aux1299_2722;
{
obj_t arg1062_2723;
{
obj_t arg1063_2724;
{
obj_t arg1065_2725;
arg1065_2725 = CAR(pair_34);
{
obj_t pair_2726;
if(PAIRP(arg1065_2725)){
pair_2726 = arg1065_2725;
}
 else {
bigloo_type_error_location_103___error(symbol2734___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1065_2725, string2680___r4_pairs_and_lists_6_3, BINT(((long)14175)));
exit( -1 );}
arg1063_2724 = CAR(pair_2726);
}
}
{
obj_t pair_2727;
if(PAIRP(arg1063_2724)){
pair_2727 = arg1063_2724;
}
 else {
bigloo_type_error_location_103___error(symbol2734___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1063_2724, string2680___r4_pairs_and_lists_6_3, BINT(((long)14170)));
exit( -1 );}
arg1062_2723 = CDR(pair_2727);
}
}
{
obj_t pair_2728;
if(PAIRP(arg1062_2723)){
pair_2728 = arg1062_2723;
}
 else {
bigloo_type_error_location_103___error(symbol2734___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1062_2723, string2680___r4_pairs_and_lists_6_3, BINT(((long)14165)));
exit( -1 );}
aux1299_2722 = CDR(pair_2728);
}
}
POP_TRACE();
return aux1299_2722;
}
}
}
}


/* _cddaar1389 */obj_t _cddaar1389___r4_pairs_and_lists_6_3(obj_t env_1146, obj_t pair_1147)
{
{
obj_t pair_2729;
if(PAIRP(pair_1147)){
pair_2729 = pair_1147;
}
 else {
bigloo_type_error_location_103___error(symbol2735___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1147, string2680___r4_pairs_and_lists_6_3, BINT(((long)14133)));
exit( -1 );}
{
obj_t symbol1300_2730;
symbol1300_2730 = symbol2734___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1300_2730);
BUNSPEC;
{
obj_t aux1299_2731;
{
obj_t arg1062_2732;
{
obj_t arg1063_2733;
{
obj_t arg1065_2734;
arg1065_2734 = CAR(pair_2729);
{
obj_t pair_2735;
if(PAIRP(arg1065_2734)){
pair_2735 = arg1065_2734;
}
 else {
bigloo_type_error_location_103___error(symbol2734___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1065_2734, string2680___r4_pairs_and_lists_6_3, BINT(((long)14175)));
exit( -1 );}
arg1063_2733 = CAR(pair_2735);
}
}
{
obj_t pair_2736;
if(PAIRP(arg1063_2733)){
pair_2736 = arg1063_2733;
}
 else {
bigloo_type_error_location_103___error(symbol2734___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1063_2733, string2680___r4_pairs_and_lists_6_3, BINT(((long)14170)));
exit( -1 );}
arg1062_2732 = CDR(pair_2736);
}
}
{
obj_t pair_2737;
if(PAIRP(arg1062_2732)){
pair_2737 = arg1062_2732;
}
 else {
bigloo_type_error_location_103___error(symbol2734___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1062_2732, string2680___r4_pairs_and_lists_6_3, BINT(((long)14165)));
exit( -1 );}
aux1299_2731 = CDR(pair_2737);
}
}
POP_TRACE();
return aux1299_2731;
}
}
}
}
}


/* cddadr */obj_t cddadr___r4_pairs_and_lists_6_3(obj_t pair_35)
{
{
obj_t symbol1302_2738;
symbol1302_2738 = symbol2736___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1302_2738);
BUNSPEC;
{
obj_t aux1301_2739;
{
obj_t arg1066_2740;
{
obj_t arg1067_2741;
{
obj_t arg1068_2742;
arg1068_2742 = CDR(pair_35);
{
obj_t pair_2743;
if(PAIRP(arg1068_2742)){
pair_2743 = arg1068_2742;
}
 else {
bigloo_type_error_location_103___error(symbol2736___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1068_2742, string2680___r4_pairs_and_lists_6_3, BINT(((long)14460)));
exit( -1 );}
arg1067_2741 = CAR(pair_2743);
}
}
{
obj_t pair_2744;
if(PAIRP(arg1067_2741)){
pair_2744 = arg1067_2741;
}
 else {
bigloo_type_error_location_103___error(symbol2736___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1067_2741, string2680___r4_pairs_and_lists_6_3, BINT(((long)14455)));
exit( -1 );}
arg1066_2740 = CDR(pair_2744);
}
}
{
obj_t pair_2745;
if(PAIRP(arg1066_2740)){
pair_2745 = arg1066_2740;
}
 else {
bigloo_type_error_location_103___error(symbol2736___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1066_2740, string2680___r4_pairs_and_lists_6_3, BINT(((long)14450)));
exit( -1 );}
aux1301_2739 = CDR(pair_2745);
}
}
POP_TRACE();
return aux1301_2739;
}
}
}
}


/* _cddadr1390 */obj_t _cddadr1390___r4_pairs_and_lists_6_3(obj_t env_1148, obj_t pair_1149)
{
{
obj_t pair_2746;
if(PAIRP(pair_1149)){
pair_2746 = pair_1149;
}
 else {
bigloo_type_error_location_103___error(symbol2737___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1149, string2680___r4_pairs_and_lists_6_3, BINT(((long)14418)));
exit( -1 );}
{
obj_t symbol1302_2747;
symbol1302_2747 = symbol2736___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1302_2747);
BUNSPEC;
{
obj_t aux1301_2748;
{
obj_t arg1066_2749;
{
obj_t arg1067_2750;
{
obj_t arg1068_2751;
arg1068_2751 = CDR(pair_2746);
{
obj_t pair_2752;
if(PAIRP(arg1068_2751)){
pair_2752 = arg1068_2751;
}
 else {
bigloo_type_error_location_103___error(symbol2736___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1068_2751, string2680___r4_pairs_and_lists_6_3, BINT(((long)14460)));
exit( -1 );}
arg1067_2750 = CAR(pair_2752);
}
}
{
obj_t pair_2753;
if(PAIRP(arg1067_2750)){
pair_2753 = arg1067_2750;
}
 else {
bigloo_type_error_location_103___error(symbol2736___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1067_2750, string2680___r4_pairs_and_lists_6_3, BINT(((long)14455)));
exit( -1 );}
arg1066_2749 = CDR(pair_2753);
}
}
{
obj_t pair_2754;
if(PAIRP(arg1066_2749)){
pair_2754 = arg1066_2749;
}
 else {
bigloo_type_error_location_103___error(symbol2736___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1066_2749, string2680___r4_pairs_and_lists_6_3, BINT(((long)14450)));
exit( -1 );}
aux1301_2748 = CDR(pair_2754);
}
}
POP_TRACE();
return aux1301_2748;
}
}
}
}
}


/* cdadar */obj_t cdadar___r4_pairs_and_lists_6_3(obj_t pair_36)
{
{
obj_t symbol1304_2755;
symbol1304_2755 = symbol2738___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1304_2755);
BUNSPEC;
{
obj_t aux1303_2756;
{
obj_t arg1069_2757;
{
obj_t arg1070_2758;
{
obj_t arg1072_2759;
arg1072_2759 = CAR(pair_36);
{
obj_t pair_2760;
if(PAIRP(arg1072_2759)){
pair_2760 = arg1072_2759;
}
 else {
bigloo_type_error_location_103___error(symbol2738___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1072_2759, string2680___r4_pairs_and_lists_6_3, BINT(((long)14745)));
exit( -1 );}
arg1070_2758 = CDR(pair_2760);
}
}
{
obj_t pair_2761;
if(PAIRP(arg1070_2758)){
pair_2761 = arg1070_2758;
}
 else {
bigloo_type_error_location_103___error(symbol2738___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1070_2758, string2680___r4_pairs_and_lists_6_3, BINT(((long)14740)));
exit( -1 );}
arg1069_2757 = CAR(pair_2761);
}
}
{
obj_t pair_2762;
if(PAIRP(arg1069_2757)){
pair_2762 = arg1069_2757;
}
 else {
bigloo_type_error_location_103___error(symbol2738___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1069_2757, string2680___r4_pairs_and_lists_6_3, BINT(((long)14735)));
exit( -1 );}
aux1303_2756 = CDR(pair_2762);
}
}
POP_TRACE();
return aux1303_2756;
}
}
}
}


/* _cdadar1391 */obj_t _cdadar1391___r4_pairs_and_lists_6_3(obj_t env_1150, obj_t pair_1151)
{
{
obj_t pair_2763;
if(PAIRP(pair_1151)){
pair_2763 = pair_1151;
}
 else {
bigloo_type_error_location_103___error(symbol2739___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1151, string2680___r4_pairs_and_lists_6_3, BINT(((long)14703)));
exit( -1 );}
{
obj_t symbol1304_2764;
symbol1304_2764 = symbol2738___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1304_2764);
BUNSPEC;
{
obj_t aux1303_2765;
{
obj_t arg1069_2766;
{
obj_t arg1070_2767;
{
obj_t arg1072_2768;
arg1072_2768 = CAR(pair_2763);
{
obj_t pair_2769;
if(PAIRP(arg1072_2768)){
pair_2769 = arg1072_2768;
}
 else {
bigloo_type_error_location_103___error(symbol2738___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1072_2768, string2680___r4_pairs_and_lists_6_3, BINT(((long)14745)));
exit( -1 );}
arg1070_2767 = CDR(pair_2769);
}
}
{
obj_t pair_2770;
if(PAIRP(arg1070_2767)){
pair_2770 = arg1070_2767;
}
 else {
bigloo_type_error_location_103___error(symbol2738___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1070_2767, string2680___r4_pairs_and_lists_6_3, BINT(((long)14740)));
exit( -1 );}
arg1069_2766 = CAR(pair_2770);
}
}
{
obj_t pair_2771;
if(PAIRP(arg1069_2766)){
pair_2771 = arg1069_2766;
}
 else {
bigloo_type_error_location_103___error(symbol2738___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1069_2766, string2680___r4_pairs_and_lists_6_3, BINT(((long)14735)));
exit( -1 );}
aux1303_2765 = CDR(pair_2771);
}
}
POP_TRACE();
return aux1303_2765;
}
}
}
}
}


/* cdddar */obj_t cdddar___r4_pairs_and_lists_6_3(obj_t pair_37)
{
{
obj_t symbol1306_2772;
symbol1306_2772 = symbol2740___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1306_2772);
BUNSPEC;
{
obj_t aux1305_2773;
{
obj_t arg1073_2774;
{
obj_t arg1076_2775;
{
obj_t arg1077_2776;
arg1077_2776 = CAR(pair_37);
{
obj_t pair_2777;
if(PAIRP(arg1077_2776)){
pair_2777 = arg1077_2776;
}
 else {
bigloo_type_error_location_103___error(symbol2740___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1077_2776, string2680___r4_pairs_and_lists_6_3, BINT(((long)15030)));
exit( -1 );}
arg1076_2775 = CDR(pair_2777);
}
}
{
obj_t pair_2778;
if(PAIRP(arg1076_2775)){
pair_2778 = arg1076_2775;
}
 else {
bigloo_type_error_location_103___error(symbol2740___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1076_2775, string2680___r4_pairs_and_lists_6_3, BINT(((long)15025)));
exit( -1 );}
arg1073_2774 = CDR(pair_2778);
}
}
{
obj_t pair_2779;
if(PAIRP(arg1073_2774)){
pair_2779 = arg1073_2774;
}
 else {
bigloo_type_error_location_103___error(symbol2740___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1073_2774, string2680___r4_pairs_and_lists_6_3, BINT(((long)15020)));
exit( -1 );}
aux1305_2773 = CDR(pair_2779);
}
}
POP_TRACE();
return aux1305_2773;
}
}
}
}


/* _cdddar1392 */obj_t _cdddar1392___r4_pairs_and_lists_6_3(obj_t env_1152, obj_t pair_1153)
{
{
obj_t pair_2780;
if(PAIRP(pair_1153)){
pair_2780 = pair_1153;
}
 else {
bigloo_type_error_location_103___error(symbol2741___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1153, string2680___r4_pairs_and_lists_6_3, BINT(((long)14988)));
exit( -1 );}
{
obj_t symbol1306_2781;
symbol1306_2781 = symbol2740___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1306_2781);
BUNSPEC;
{
obj_t aux1305_2782;
{
obj_t arg1073_2783;
{
obj_t arg1076_2784;
{
obj_t arg1077_2785;
arg1077_2785 = CAR(pair_2780);
{
obj_t pair_2786;
if(PAIRP(arg1077_2785)){
pair_2786 = arg1077_2785;
}
 else {
bigloo_type_error_location_103___error(symbol2740___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1077_2785, string2680___r4_pairs_and_lists_6_3, BINT(((long)15030)));
exit( -1 );}
arg1076_2784 = CDR(pair_2786);
}
}
{
obj_t pair_2787;
if(PAIRP(arg1076_2784)){
pair_2787 = arg1076_2784;
}
 else {
bigloo_type_error_location_103___error(symbol2740___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1076_2784, string2680___r4_pairs_and_lists_6_3, BINT(((long)15025)));
exit( -1 );}
arg1073_2783 = CDR(pair_2787);
}
}
{
obj_t pair_2788;
if(PAIRP(arg1073_2783)){
pair_2788 = arg1073_2783;
}
 else {
bigloo_type_error_location_103___error(symbol2740___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1073_2783, string2680___r4_pairs_and_lists_6_3, BINT(((long)15020)));
exit( -1 );}
aux1305_2782 = CDR(pair_2788);
}
}
POP_TRACE();
return aux1305_2782;
}
}
}
}
}


/* cddddr */obj_t cddddr___r4_pairs_and_lists_6_3(obj_t pair_38)
{
{
obj_t symbol1308_2789;
symbol1308_2789 = symbol2742___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1308_2789);
BUNSPEC;
{
obj_t aux1307_2790;
{
obj_t arg1078_2791;
{
obj_t arg1079_2792;
{
obj_t arg1080_2793;
arg1080_2793 = CDR(pair_38);
{
obj_t pair_2794;
if(PAIRP(arg1080_2793)){
pair_2794 = arg1080_2793;
}
 else {
bigloo_type_error_location_103___error(symbol2742___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1080_2793, string2680___r4_pairs_and_lists_6_3, BINT(((long)15316)));
exit( -1 );}
arg1079_2792 = CDR(pair_2794);
}
}
{
obj_t pair_2795;
if(PAIRP(arg1079_2792)){
pair_2795 = arg1079_2792;
}
 else {
bigloo_type_error_location_103___error(symbol2742___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1079_2792, string2680___r4_pairs_and_lists_6_3, BINT(((long)15311)));
exit( -1 );}
arg1078_2791 = CDR(pair_2795);
}
}
{
obj_t pair_2796;
if(PAIRP(arg1078_2791)){
pair_2796 = arg1078_2791;
}
 else {
bigloo_type_error_location_103___error(symbol2742___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1078_2791, string2680___r4_pairs_and_lists_6_3, BINT(((long)15306)));
exit( -1 );}
aux1307_2790 = CDR(pair_2796);
}
}
POP_TRACE();
return aux1307_2790;
}
}
}
}


/* _cddddr1393 */obj_t _cddddr1393___r4_pairs_and_lists_6_3(obj_t env_1154, obj_t pair_1155)
{
{
obj_t pair_2797;
if(PAIRP(pair_1155)){
pair_2797 = pair_1155;
}
 else {
bigloo_type_error_location_103___error(symbol2743___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1155, string2680___r4_pairs_and_lists_6_3, BINT(((long)15274)));
exit( -1 );}
{
obj_t symbol1308_2798;
symbol1308_2798 = symbol2742___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1308_2798);
BUNSPEC;
{
obj_t aux1307_2799;
{
obj_t arg1078_2800;
{
obj_t arg1079_2801;
{
obj_t arg1080_2802;
arg1080_2802 = CDR(pair_2797);
{
obj_t pair_2803;
if(PAIRP(arg1080_2802)){
pair_2803 = arg1080_2802;
}
 else {
bigloo_type_error_location_103___error(symbol2742___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1080_2802, string2680___r4_pairs_and_lists_6_3, BINT(((long)15316)));
exit( -1 );}
arg1079_2801 = CDR(pair_2803);
}
}
{
obj_t pair_2804;
if(PAIRP(arg1079_2801)){
pair_2804 = arg1079_2801;
}
 else {
bigloo_type_error_location_103___error(symbol2742___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1079_2801, string2680___r4_pairs_and_lists_6_3, BINT(((long)15311)));
exit( -1 );}
arg1078_2800 = CDR(pair_2804);
}
}
{
obj_t pair_2805;
if(PAIRP(arg1078_2800)){
pair_2805 = arg1078_2800;
}
 else {
bigloo_type_error_location_103___error(symbol2742___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1078_2800, string2680___r4_pairs_and_lists_6_3, BINT(((long)15306)));
exit( -1 );}
aux1307_2799 = CDR(pair_2805);
}
}
POP_TRACE();
return aux1307_2799;
}
}
}
}
}


/* set-car! */obj_t set_car__100___r4_pairs_and_lists_6_3(obj_t pair_39, obj_t obj_40)
{
{
obj_t symbol1310_2806;
symbol1310_2806 = symbol2744___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1310_2806);
BUNSPEC;
{
obj_t aux1309_2807;
aux1309_2807 = SET_CAR(pair_39, obj_40);
POP_TRACE();
return aux1309_2807;
}
}
}
}


/* _set-car!1394 */obj_t _set_car_1394_21___r4_pairs_and_lists_6_3(obj_t env_1156, obj_t pair_1157, obj_t obj_1158)
{
{
obj_t pair_2808;
obj_t obj_2809;
if(PAIRP(pair_1157)){
pair_2808 = pair_1157;
}
 else {
bigloo_type_error_location_103___error(symbol2745___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1157, string2680___r4_pairs_and_lists_6_3, BINT(((long)15559)));
exit( -1 );}
obj_2809 = obj_1158;
{
obj_t symbol1310_2810;
symbol1310_2810 = symbol2744___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1310_2810);
BUNSPEC;
{
obj_t aux1309_2811;
aux1309_2811 = SET_CAR(pair_2808, obj_2809);
POP_TRACE();
return aux1309_2811;
}
}
}
}
}


/* set-cdr! */obj_t set_cdr__56___r4_pairs_and_lists_6_3(obj_t pair_41, obj_t obj_42)
{
{
obj_t symbol1312_2812;
symbol1312_2812 = symbol2746___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1312_2812);
BUNSPEC;
{
obj_t aux1311_2813;
aux1311_2813 = SET_CDR(pair_41, obj_42);
POP_TRACE();
return aux1311_2813;
}
}
}
}


/* _set-cdr!1395 */obj_t _set_cdr_1395_25___r4_pairs_and_lists_6_3(obj_t env_1159, obj_t pair_1160, obj_t obj_1161)
{
{
obj_t pair_2814;
obj_t obj_2815;
if(PAIRP(pair_1160)){
pair_2814 = pair_1160;
}
 else {
bigloo_type_error_location_103___error(symbol2747___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, pair_1160, string2680___r4_pairs_and_lists_6_3, BINT(((long)15843)));
exit( -1 );}
obj_2815 = obj_1161;
{
obj_t symbol1312_2816;
symbol1312_2816 = symbol2746___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1312_2816);
BUNSPEC;
{
obj_t aux1311_2817;
aux1311_2817 = SET_CDR(pair_2814, obj_2815);
POP_TRACE();
return aux1311_2817;
}
}
}
}
}


/* set-cer! */obj_t set_cer__213___r4_pairs_and_lists_6_3(obj_t epair_43, obj_t obj_44)
{
{
obj_t symbol1314_2818;
symbol1314_2818 = symbol2748___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1314_2818);
BUNSPEC;
{
obj_t aux1313_2819;
{
bool_t test1081_2820;
test1081_2820 = EXTENDED_PAIRP(epair_43);
if(test1081_2820){
aux1313_2819 = SET_CER(epair_43, obj_44);
}
 else {
aux1313_2819 = debug_error_location_199___error(string2749___r4_pairs_and_lists_6_3, string2685___r4_pairs_and_lists_6_3, epair_43, string2686___r4_pairs_and_lists_6_3, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1313_2819;
}
}
}
}


/* _set-cer!1396 */obj_t _set_cer_1396_98___r4_pairs_and_lists_6_3(obj_t env_1162, obj_t epair_1163, obj_t obj_1164)
{
{
obj_t epair_2821;
obj_t obj_2822;
if(PAIRP(epair_1163)){
epair_2821 = epair_1163;
}
 else {
bigloo_type_error_location_103___error(symbol2750___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, epair_1163, string2680___r4_pairs_and_lists_6_3, BINT(((long)16127)));
exit( -1 );}
obj_2822 = obj_1164;
{
obj_t symbol1314_2823;
symbol1314_2823 = symbol2748___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1314_2823);
BUNSPEC;
{
obj_t aux1313_2824;
{
bool_t test1081_2825;
test1081_2825 = EXTENDED_PAIRP(epair_2821);
if(test1081_2825){
aux1313_2824 = SET_CER(epair_2821, obj_2822);
}
 else {
aux1313_2824 = debug_error_location_199___error(string2749___r4_pairs_and_lists_6_3, string2685___r4_pairs_and_lists_6_3, epair_2821, string2686___r4_pairs_and_lists_6_3, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1313_2824;
}
}
}
}
}


/* null? */bool_t null__121___r4_pairs_and_lists_6_3(obj_t obj_45)
{
return NULLP(obj_45);
}


/* _null? */obj_t _null__116___r4_pairs_and_lists_6_3(obj_t env_1165, obj_t obj_1166)
{
{
bool_t aux_4168;
{
obj_t obj_2826;
obj_2826 = obj_1166;
aux_4168 = NULLP(obj_2826);
}
return BBOOL(aux_4168);
}
}


/* list */obj_t list___r4_pairs_and_lists_6_3(obj_t l_46)
{
{
obj_t symbol1316_2827;
symbol1316_2827 = symbol2751___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1316_2827);
BUNSPEC;
POP_TRACE();
return l_46;
}
}
}


/* _list */obj_t _list___r4_pairs_and_lists_6_3(obj_t env_1167, obj_t l_1168)
{
{
obj_t l_2828;
l_2828 = l_1168;
{
obj_t symbol1316_2829;
symbol1316_2829 = symbol2751___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1316_2829);
BUNSPEC;
POP_TRACE();
return l_2828;
}
}
}
}


/* list? */bool_t list__240___r4_pairs_and_lists_6_3(obj_t x_47)
{
{
obj_t symbol1318_1037;
symbol1318_1037 = symbol2752___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1318_1037);
BUNSPEC;
{
bool_t aux1317_1038;
{
obj_t x_290;
obj_t prev_291;
obj_t x_287;
obj_t prev_288;
if(NULLP(x_47)){
aux1317_1038 = ((bool_t)1);
}
 else {
bool_t test1083_294;
test1083_294 = PAIRP(x_47);
if(test1083_294){
{
obj_t arg1084_295;
{
obj_t pair_660;
if(test1083_294){
pair_660 = x_47;
}
 else {
bigloo_type_error_location_103___error(symbol2752___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_47, string2680___r4_pairs_and_lists_6_3, BINT(((long)17448)));
exit( -1 );}
arg1084_295 = CDR(pair_660);
}
x_287 = arg1084_295;
prev_288 = x_47;
l1_289:
if(NULLP(x_287)){
aux1317_1038 = ((bool_t)1);
}
 else {
bool_t test1086_297;
test1086_297 = PAIRP(x_287);
if(test1086_297){
if((x_287==prev_288)){
aux1317_1038 = ((bool_t)0);
}
 else {
obj_t arg1088_299;
{
obj_t pair_665;
if(test1086_297){
pair_665 = x_287;
}
 else {
bigloo_type_error_location_103___error(symbol2752___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_287, string2680___r4_pairs_and_lists_6_3, BINT(((long)17196)));
exit( -1 );}
arg1088_299 = CDR(pair_665);
}
x_290 = arg1088_299;
prev_291 = prev_288;
if(NULLP(x_290)){
aux1317_1038 = ((bool_t)1);
}
 else {
bool_t test1090_301;
test1090_301 = PAIRP(x_290);
if(test1090_301){
if((x_290==prev_291)){
aux1317_1038 = ((bool_t)0);
}
 else {
obj_t arg1092_303;
obj_t arg1093_304;
{
obj_t pair_670;
if(test1090_301){
pair_670 = x_290;
}
 else {
bigloo_type_error_location_103___error(symbol2752___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_290, string2680___r4_pairs_and_lists_6_3, BINT(((long)17346)));
exit( -1 );}
arg1092_303 = CDR(pair_670);
}
{
obj_t pair_671;
if(PAIRP(prev_291)){
pair_671 = prev_291;
}
 else {
bigloo_type_error_location_103___error(symbol2752___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_291, string2680___r4_pairs_and_lists_6_3, BINT(((long)17354)));
exit( -1 );}
arg1093_304 = CDR(pair_671);
}
{
obj_t prev_4214;
obj_t x_4213;
x_4213 = arg1092_303;
prev_4214 = arg1093_304;
prev_288 = prev_4214;
x_287 = x_4213;
goto l1_289;
}
}
}
 else {
aux1317_1038 = ((bool_t)0);
}
}
}
}
 else {
aux1317_1038 = ((bool_t)0);
}
}
}
}
 else {
aux1317_1038 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1317_1038;
}
}
}
}


/* _list? */obj_t _list__66___r4_pairs_and_lists_6_3(obj_t env_1169, obj_t x_1170)
{
{
bool_t aux_4216;
aux_4216 = list__240___r4_pairs_and_lists_6_3(x_1170);
return BBOOL(aux_4216);
}
}


/* append-2 */obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t l1_48, obj_t l2_49)
{
{
obj_t symbol1320_1039;
symbol1320_1039 = symbol2753___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1320_1039);
BUNSPEC;
{
obj_t aux1319_1040;
{
obj_t head_305;
head_305 = MAKE_PAIR(BNIL, l2_49);
{
obj_t prev_306;
obj_t tail_307;
prev_306 = head_305;
tail_307 = l1_48;
loop_308:
if(NULLP(tail_307)){
BNIL;
}
 else {
obj_t new_prev_45_310;
{
obj_t arg1096_312;
{
obj_t pair_676;
if(PAIRP(tail_307)){
pair_676 = tail_307;
}
 else {
bigloo_type_error_location_103___error(symbol2753___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, tail_307, string2680___r4_pairs_and_lists_6_3, BINT(((long)17854)));
exit( -1 );}
arg1096_312 = CAR(pair_676);
}
new_prev_45_310 = MAKE_PAIR(arg1096_312, l2_49);
}
SET_CDR(prev_306, new_prev_45_310);
{
obj_t arg1095_311;
{
obj_t pair_681;
if(PAIRP(tail_307)){
pair_681 = tail_307;
}
 else {
bigloo_type_error_location_103___error(symbol2753___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, tail_307, string2680___r4_pairs_and_lists_6_3, BINT(((long)17925)));
exit( -1 );}
arg1095_311 = CDR(pair_681);
}
{
obj_t tail_4238;
obj_t prev_4237;
prev_4237 = new_prev_45_310;
tail_4238 = arg1095_311;
tail_307 = tail_4238;
prev_306 = prev_4237;
goto loop_308;
}
}
}
aux1319_1040 = CDR(head_305);
}
}
POP_TRACE();
return aux1319_1040;
}
}
}
}


/* _append-2 */obj_t _append_2_70___r4_pairs_and_lists_6_3(obj_t env_1171, obj_t l1_1172, obj_t l2_1173)
{
return append_2_18___r4_pairs_and_lists_6_3(l1_1172, l2_1173);
}


/* append */obj_t append___r4_pairs_and_lists_6_3(obj_t l_50)
{
{
obj_t symbol1322_1041;
symbol1322_1041 = symbol2754___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1322_1041);
BUNSPEC;
{
obj_t aux1321_1042;
aux1321_1042 = append_list_2___r4_pairs_and_lists_6_3(l_50);
POP_TRACE();
return aux1321_1042;
}
}
}
}


/* append-list */obj_t append_list_2___r4_pairs_and_lists_6_3(obj_t l_314)
{
{
long len_316;
len_316 = list_length(l_314);
{
switch (len_316){
case ((long)0) : 
return BNIL;
break;
case ((long)1) : 
{
obj_t pair_682;
if(PAIRP(l_314)){
pair_682 = l_314;
}
 else {
bigloo_type_error_location_103___error(symbol2755___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_314, string2680___r4_pairs_and_lists_6_3, BINT(((long)18340)));
exit( -1 );}
return CAR(pair_682);
}
break;
case ((long)2) : 
{
obj_t arg1099_320;
obj_t arg1100_321;
{
obj_t pair_683;
if(PAIRP(l_314)){
pair_683 = l_314;
}
 else {
bigloo_type_error_location_103___error(symbol2755___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_314, string2680___r4_pairs_and_lists_6_3, BINT(((long)18388)));
exit( -1 );}
arg1099_320 = CAR(pair_683);
}
{
obj_t arg1101_322;
{
obj_t pair_684;
if(PAIRP(l_314)){
pair_684 = l_314;
}
 else {
bigloo_type_error_location_103___error(symbol2755___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_314, string2680___r4_pairs_and_lists_6_3, BINT(((long)18406)));
exit( -1 );}
arg1101_322 = CDR(pair_684);
}
{
obj_t pair_685;
if(PAIRP(arg1101_322)){
pair_685 = arg1101_322;
}
 else {
bigloo_type_error_location_103___error(symbol2755___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1101_322, string2680___r4_pairs_and_lists_6_3, BINT(((long)18400)));
exit( -1 );}
arg1100_321 = CAR(pair_685);
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1099_320, arg1100_321);
}
break;
default: 
{
obj_t arg1102_323;
obj_t arg1103_324;
{
obj_t pair_686;
if(PAIRP(l_314)){
pair_686 = l_314;
}
 else {
bigloo_type_error_location_103___error(symbol2755___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_314, string2680___r4_pairs_and_lists_6_3, BINT(((long)18435)));
exit( -1 );}
arg1102_323 = CAR(pair_686);
}
{
obj_t arg1104_325;
{
obj_t pair_687;
if(PAIRP(l_314)){
pair_687 = l_314;
}
 else {
bigloo_type_error_location_103___error(symbol2755___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_314, string2680___r4_pairs_and_lists_6_3, BINT(((long)18461)));
exit( -1 );}
arg1104_325 = CDR(pair_687);
}
arg1103_324 = append_list_2___r4_pairs_and_lists_6_3(arg1104_325);
}
return append_2_18___r4_pairs_and_lists_6_3(arg1102_323, arg1103_324);
}
}
}
}
}


/* _append */obj_t _append___r4_pairs_and_lists_6_3(obj_t env_1174, obj_t l_1175)
{
return append___r4_pairs_and_lists_6_3(l_1175);
}


/* append! */obj_t append__79___r4_pairs_and_lists_6_3(obj_t x_51, obj_t y_52)
{
{
obj_t symbol1324_1043;
symbol1324_1043 = symbol2756___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1324_1043);
BUNSPEC;
{
obj_t aux1323_1044;
if(NULLP(x_51)){
aux1323_1044 = y_52;
}
 else {
obj_t arg1106_328;
{
obj_t pair_689;
if(PAIRP(x_51)){
pair_689 = x_51;
}
 else {
bigloo_type_error_location_103___error(symbol2756___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_51, string2680___r4_pairs_and_lists_6_3, BINT(((long)18803)));
exit( -1 );}
arg1106_328 = CDR(pair_689);
}
{
obj_t a_691;
obj_t b_692;
a_691 = x_51;
b_692 = arg1106_328;
do_loop__1004_127_690:
if(NULLP(b_692)){
{
obj_t pair_698;
if(PAIRP(a_691)){
pair_698 = a_691;
}
 else {
bigloo_type_error_location_103___error(symbol2756___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, a_691, string2680___r4_pairs_and_lists_6_3, BINT(((long)18853)));
exit( -1 );}
SET_CDR(pair_698, y_52);
}
aux1323_1044 = x_51;
}
 else {
{
obj_t arg1109_696;
{
obj_t pair_700;
if(PAIRP(b_692)){
pair_700 = b_692;
}
 else {
bigloo_type_error_location_103___error(symbol2756___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, b_692, string2680___r4_pairs_and_lists_6_3, BINT(((long)18811)));
exit( -1 );}
arg1109_696 = CDR(pair_700);
}
{
obj_t b_4311;
obj_t a_4310;
a_4310 = b_692;
b_4311 = arg1109_696;
b_692 = b_4311;
a_691 = a_4310;
goto do_loop__1004_127_690;
}
}
}
}
}
POP_TRACE();
return aux1323_1044;
}
}
}
}


/* _append! */obj_t _append__27___r4_pairs_and_lists_6_3(obj_t env_1176, obj_t x_1177, obj_t y_1178)
{
return append__79___r4_pairs_and_lists_6_3(x_1177, y_1178);
}


/* length */long list_length(obj_t list_53)
{
{
obj_t symbol1326_1045;
symbol1326_1045 = symbol2757___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1326_1045);
BUNSPEC;
{
long aux1325_1046;
{
obj_t l_716;
long res_717;
l_716 = list_53;
res_717 = ((long)0);
loop_715:
if(NULLP(l_716)){
aux1325_1046 = res_717;
}
 else {
{
obj_t arg1111_722;
long arg1112_723;
{
obj_t pair_725;
if(PAIRP(l_716)){
pair_725 = l_716;
}
 else {
bigloo_type_error_location_103___error(symbol2757___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_716, string2680___r4_pairs_and_lists_6_3, BINT(((long)19231)));
exit( -1 );}
arg1111_722 = CDR(pair_725);
}
arg1112_723 = (((long)1)+res_717);
{
long res_4325;
obj_t l_4324;
l_4324 = arg1111_722;
res_4325 = arg1112_723;
res_717 = res_4325;
l_716 = l_4324;
goto loop_715;
}
}
}
}
POP_TRACE();
return aux1325_1046;
}
}
}
}


/* _length */obj_t _length___r4_pairs_and_lists_6_3(obj_t env_1179, obj_t list_1180)
{
{
long aux_4327;
aux_4327 = list_length(list_1180);
return BINT(aux_4327);
}
}


/* reverse */obj_t reverse___r4_pairs_and_lists_6_3(obj_t l_54)
{
{
obj_t symbol1328_1047;
symbol1328_1047 = symbol2758___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1328_1047);
BUNSPEC;
{
obj_t aux1327_1048;
{
obj_t l_745;
obj_t acc_746;
l_745 = l_54;
acc_746 = BNIL;
loop_744:
if(NULLP(l_745)){
aux1327_1048 = acc_746;
}
 else {
obj_t arg1115_752;
obj_t arg1116_753;
{
obj_t pair_756;
if(PAIRP(l_745)){
pair_756 = l_745;
}
 else {
bigloo_type_error_location_103___error(symbol2758___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_745, string2680___r4_pairs_and_lists_6_3, BINT(((long)19576)));
exit( -1 );}
arg1115_752 = CDR(pair_756);
}
{
obj_t arg1117_754;
{
obj_t pair_757;
if(PAIRP(l_745)){
pair_757 = l_745;
}
 else {
bigloo_type_error_location_103___error(symbol2758___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_745, string2680___r4_pairs_and_lists_6_3, BINT(((long)19590)));
exit( -1 );}
arg1117_754 = CAR(pair_757);
}
arg1116_753 = MAKE_PAIR(arg1117_754, acc_746);
}
{
obj_t acc_4347;
obj_t l_4346;
l_4346 = arg1115_752;
acc_4347 = arg1116_753;
acc_746 = acc_4347;
l_745 = l_4346;
goto loop_744;
}
}
}
POP_TRACE();
return aux1327_1048;
}
}
}
}


/* _reverse */obj_t _reverse___r4_pairs_and_lists_6_3(obj_t env_1181, obj_t l_1182)
{
return reverse___r4_pairs_and_lists_6_3(l_1182);
}


/* list-tail */obj_t list_tail_190___r4_pairs_and_lists_6_3(obj_t list_55, long k_56)
{
{
obj_t symbol1330_1049;
symbol1330_1049 = symbol2759___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1330_1049);
BUNSPEC;
{
obj_t aux1329_1050;
if((k_56==((long)0))){
aux1329_1050 = list_55;
}
 else {
obj_t arg1119_781;
long arg1120_782;
{
obj_t pair_786;
if(PAIRP(list_55)){
pair_786 = list_55;
}
 else {
bigloo_type_error_location_103___error(symbol2759___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_55, string2680___r4_pairs_and_lists_6_3, BINT(((long)19906)));
exit( -1 );}
arg1119_781 = CDR(pair_786);
}
arg1120_782 = (k_56-((long)1));
if((arg1120_782==((long)0))){
aux1329_1050 = arg1119_781;
}
 else {
obj_t arg1119_792;
long arg1120_793;
{
obj_t pair_797;
if(PAIRP(arg1119_781)){
pair_797 = arg1119_781;
}
 else {
bigloo_type_error_location_103___error(symbol2759___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1119_781, string2680___r4_pairs_and_lists_6_3, BINT(((long)19906)));
exit( -1 );}
arg1119_792 = CDR(pair_797);
}
arg1120_793 = (arg1120_782-((long)1));
aux1329_1050 = list_tail_190___r4_pairs_and_lists_6_3(arg1119_792, arg1120_793);
}
}
POP_TRACE();
return aux1329_1050;
}
}
}
}


/* _list-tail1397 */obj_t _list_tail1397_176___r4_pairs_and_lists_6_3(obj_t env_1183, obj_t list_1184, obj_t k_1185)
{
{
long aux_4371;
{
obj_t aux_4372;
if(INTEGERP(k_1185)){
aux_4372 = k_1185;
}
 else {
bigloo_type_error_location_103___error(symbol2760___r4_pairs_and_lists_6_3, string2761___r4_pairs_and_lists_6_3, k_1185, string2680___r4_pairs_and_lists_6_3, BINT(((long)19829)));
exit( -1 );}
aux_4371 = (long)CINT(aux_4372);
}
return list_tail_190___r4_pairs_and_lists_6_3(list_1184, aux_4371);
}
}


/* list-ref */obj_t list_ref_194___r4_pairs_and_lists_6_3(obj_t list_57, long k_58)
{
{
obj_t symbol1332_1051;
symbol1332_1051 = symbol2762___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1332_1051);
BUNSPEC;
{
obj_t aux1331_1052;
if((k_58==((long)0))){
obj_t pair_806;
if(PAIRP(list_57)){
pair_806 = list_57;
}
 else {
bigloo_type_error_location_103___error(symbol2762___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_57, string2680___r4_pairs_and_lists_6_3, BINT(((long)20205)));
exit( -1 );}
aux1331_1052 = CAR(pair_806);
}
 else {
obj_t arg1122_801;
long arg1123_802;
{
obj_t pair_807;
if(PAIRP(list_57)){
pair_807 = list_57;
}
 else {
bigloo_type_error_location_103___error(symbol2762___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_57, string2680___r4_pairs_and_lists_6_3, BINT(((long)20233)));
exit( -1 );}
arg1122_801 = CDR(pair_807);
}
arg1123_802 = (k_58-((long)1));
if((arg1123_802==((long)0))){
obj_t pair_818;
if(PAIRP(arg1122_801)){
pair_818 = arg1122_801;
}
 else {
bigloo_type_error_location_103___error(symbol2762___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1122_801, string2680___r4_pairs_and_lists_6_3, BINT(((long)20205)));
exit( -1 );}
aux1331_1052 = CAR(pair_818);
}
 else {
obj_t arg1122_813;
long arg1123_814;
{
obj_t pair_819;
if(PAIRP(arg1122_801)){
pair_819 = arg1122_801;
}
 else {
bigloo_type_error_location_103___error(symbol2762___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1122_801, string2680___r4_pairs_and_lists_6_3, BINT(((long)20233)));
exit( -1 );}
arg1122_813 = CDR(pair_819);
}
arg1123_814 = (arg1123_802-((long)1));
aux1331_1052 = list_ref_194___r4_pairs_and_lists_6_3(arg1122_813, arg1123_814);
}
}
POP_TRACE();
return aux1331_1052;
}
}
}
}


/* _list-ref1398 */obj_t _list_ref1398_17___r4_pairs_and_lists_6_3(obj_t env_1186, obj_t list_1187, obj_t k_1188)
{
{
long aux_4413;
{
obj_t aux_4414;
if(INTEGERP(k_1188)){
aux_4414 = k_1188;
}
 else {
bigloo_type_error_location_103___error(symbol2763___r4_pairs_and_lists_6_3, string2761___r4_pairs_and_lists_6_3, k_1188, string2680___r4_pairs_and_lists_6_3, BINT(((long)20152)));
exit( -1 );}
aux_4413 = (long)CINT(aux_4414);
}
return list_ref_194___r4_pairs_and_lists_6_3(list_1187, aux_4413);
}
}


/* list-set! */obj_t list_set__58___r4_pairs_and_lists_6_3(obj_t list_59, long k_60, obj_t val_61)
{
{
obj_t symbol1334_1053;
symbol1334_1053 = symbol2764___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1334_1053);
BUNSPEC;
{
obj_t aux1333_1054;
if((k_60==((long)0))){
obj_t pair_828;
if(PAIRP(list_59)){
pair_828 = list_59;
}
 else {
bigloo_type_error_location_103___error(symbol2764___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_59, string2680___r4_pairs_and_lists_6_3, BINT(((long)20537)));
exit( -1 );}
aux1333_1054 = SET_CAR(pair_828, val_61);
}
 else {
obj_t arg1125_823;
long arg1126_824;
{
obj_t pair_830;
if(PAIRP(list_59)){
pair_830 = list_59;
}
 else {
bigloo_type_error_location_103___error(symbol2764___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_59, string2680___r4_pairs_and_lists_6_3, BINT(((long)20575)));
exit( -1 );}
arg1125_823 = CDR(pair_830);
}
arg1126_824 = (k_60-((long)1));
if((arg1126_824==((long)0))){
obj_t pair_842;
if(PAIRP(arg1125_823)){
pair_842 = arg1125_823;
}
 else {
bigloo_type_error_location_103___error(symbol2764___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1125_823, string2680___r4_pairs_and_lists_6_3, BINT(((long)20537)));
exit( -1 );}
aux1333_1054 = SET_CAR(pair_842, val_61);
}
 else {
obj_t arg1125_837;
long arg1126_838;
{
obj_t pair_844;
if(PAIRP(arg1125_823)){
pair_844 = arg1125_823;
}
 else {
bigloo_type_error_location_103___error(symbol2764___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1125_823, string2680___r4_pairs_and_lists_6_3, BINT(((long)20575)));
exit( -1 );}
arg1125_837 = CDR(pair_844);
}
arg1126_838 = (arg1126_824-((long)1));
aux1333_1054 = list_set__58___r4_pairs_and_lists_6_3(arg1125_837, arg1126_838, val_61);
}
}
POP_TRACE();
return aux1333_1054;
}
}
}
}


/* _list-set!1399 */obj_t _list_set_1399_60___r4_pairs_and_lists_6_3(obj_t env_1189, obj_t list_1190, obj_t k_1191, obj_t val_1192)
{
{
long aux_4455;
{
obj_t aux_4456;
if(INTEGERP(k_1191)){
aux_4456 = k_1191;
}
 else {
bigloo_type_error_location_103___error(symbol2765___r4_pairs_and_lists_6_3, string2761___r4_pairs_and_lists_6_3, k_1191, string2680___r4_pairs_and_lists_6_3, BINT(((long)20479)));
exit( -1 );}
aux_4455 = (long)CINT(aux_4456);
}
return list_set__58___r4_pairs_and_lists_6_3(list_1190, aux_4455, val_1192);
}
}


/* last-pair */obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t x_62)
{
{
obj_t symbol1336_1055;
symbol1336_1055 = symbol2766___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1336_1055);
BUNSPEC;
{
obj_t aux1335_1056;
{
bool_t test1127_847;
{
obj_t arg1129_848;
{
obj_t pair_850;
if(PAIRP(x_62)){
pair_850 = x_62;
}
 else {
bigloo_type_error_location_103___error(symbol2766___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_62, string2680___r4_pairs_and_lists_6_3, BINT(((long)20862)));
exit( -1 );}
arg1129_848 = CDR(pair_850);
}
test1127_847 = PAIRP(arg1129_848);
}
if(test1127_847){
obj_t arg1128_849;
{
obj_t pair_852;
if(PAIRP(x_62)){
pair_852 = x_62;
}
 else {
bigloo_type_error_location_103___error(symbol2766___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_62, string2680___r4_pairs_and_lists_6_3, BINT(((long)20889)));
exit( -1 );}
arg1128_849 = CDR(pair_852);
}
{
bool_t test1127_854;
{
obj_t arg1129_855;
{
obj_t pair_857;
if(PAIRP(arg1128_849)){
pair_857 = arg1128_849;
}
 else {
bigloo_type_error_location_103___error(symbol2766___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1128_849, string2680___r4_pairs_and_lists_6_3, BINT(((long)20862)));
exit( -1 );}
arg1129_855 = CDR(pair_857);
}
test1127_854 = PAIRP(arg1129_855);
}
if(test1127_854){
obj_t arg1128_856;
{
obj_t pair_859;
if(PAIRP(arg1128_849)){
pair_859 = arg1128_849;
}
 else {
bigloo_type_error_location_103___error(symbol2766___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1128_849, string2680___r4_pairs_and_lists_6_3, BINT(((long)20889)));
exit( -1 );}
arg1128_856 = CDR(pair_859);
}
aux1335_1056 = last_pair_93___r4_pairs_and_lists_6_3(arg1128_856);
}
 else {
aux1335_1056 = arg1128_849;
}
}
}
 else {
aux1335_1056 = x_62;
}
}
POP_TRACE();
return aux1335_1056;
}
}
}
}


/* _last-pair */obj_t _last_pair_60___r4_pairs_and_lists_6_3(obj_t env_1193, obj_t x_1194)
{
return last_pair_93___r4_pairs_and_lists_6_3(x_1194);
}


/* memq */obj_t memq___r4_pairs_and_lists_6_3(obj_t obj_63, obj_t list_64)
{
{
obj_t symbol1338_1057;
symbol1338_1057 = symbol2767___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1338_1057);
BUNSPEC;
{
obj_t aux1337_1058;
{
obj_t list_361;
list_361 = list_64;
loop_362:
{
bool_t test1130_363;
test1130_363 = PAIRP(list_361);
if(test1130_363){
bool_t test1131_364;
{
obj_t arg1133_366;
{
obj_t pair_861;
if(test1130_363){
pair_861 = list_361;
}
 else {
bigloo_type_error_location_103___error(symbol2767___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_361, string2680___r4_pairs_and_lists_6_3, BINT(((long)21218)));
exit( -1 );}
arg1133_366 = CAR(pair_861);
}
test1131_364 = (arg1133_366==obj_63);
}
if(test1131_364){
aux1337_1058 = list_361;
}
 else {
obj_t arg1132_365;
{
obj_t pair_864;
if(test1130_363){
pair_864 = list_361;
}
 else {
bigloo_type_error_location_103___error(symbol2767___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_361, string2680___r4_pairs_and_lists_6_3, BINT(((long)21259)));
exit( -1 );}
arg1132_365 = CDR(pair_864);
}
{
obj_t list_4511;
list_4511 = arg1132_365;
list_361 = list_4511;
goto loop_362;
}
}
}
 else {
aux1337_1058 = BFALSE;
}
}
}
POP_TRACE();
return aux1337_1058;
}
}
}
}


/* _memq */obj_t _memq___r4_pairs_and_lists_6_3(obj_t env_1195, obj_t obj_1196, obj_t list_1197)
{
return memq___r4_pairs_and_lists_6_3(obj_1196, list_1197);
}


/* memv */obj_t memv___r4_pairs_and_lists_6_3(obj_t obj_65, obj_t list_66)
{
{
obj_t symbol1340_1059;
symbol1340_1059 = symbol2768___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1340_1059);
BUNSPEC;
{
obj_t aux1339_1060;
{
obj_t list_367;
list_367 = list_66;
loop_368:
{
bool_t test1134_369;
test1134_369 = PAIRP(list_367);
if(test1134_369){
bool_t test1135_370;
{
obj_t arg1137_372;
{
obj_t pair_866;
if(test1134_369){
pair_866 = list_367;
}
 else {
bigloo_type_error_location_103___error(symbol2768___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_367, string2680___r4_pairs_and_lists_6_3, BINT(((long)21590)));
exit( -1 );}
arg1137_372 = CAR(pair_866);
}
test1135_370 = (arg1137_372==obj_65);
}
if(test1135_370){
aux1339_1060 = list_367;
}
 else {
obj_t arg1136_371;
{
obj_t pair_869;
if(test1134_369){
pair_869 = list_367;
}
 else {
bigloo_type_error_location_103___error(symbol2768___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_367, string2680___r4_pairs_and_lists_6_3, BINT(((long)21631)));
exit( -1 );}
arg1136_371 = CDR(pair_869);
}
{
obj_t list_4529;
list_4529 = arg1136_371;
list_367 = list_4529;
goto loop_368;
}
}
}
 else {
aux1339_1060 = BFALSE;
}
}
}
POP_TRACE();
return aux1339_1060;
}
}
}
}


/* _memv */obj_t _memv___r4_pairs_and_lists_6_3(obj_t env_1198, obj_t obj_1199, obj_t list_1200)
{
return memv___r4_pairs_and_lists_6_3(obj_1199, list_1200);
}


/* member */obj_t member___r4_pairs_and_lists_6_3(obj_t obj_67, obj_t list_68)
{
{
obj_t symbol1342_1061;
symbol1342_1061 = symbol2769___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1342_1061);
BUNSPEC;
{
obj_t aux1341_1062;
{
obj_t list_373;
list_373 = list_68;
loop_374:
if(NULLP(list_373)){
aux1341_1062 = BFALSE;
}
 else {
bool_t test1139_376;
{
obj_t arg1141_378;
{
obj_t pair_871;
if(PAIRP(list_373)){
pair_871 = list_373;
}
 else {
bigloo_type_error_location_103___error(symbol2769___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_373, string2680___r4_pairs_and_lists_6_3, BINT(((long)21976)));
exit( -1 );}
arg1141_378 = CAR(pair_871);
}
test1139_376 = equal__25___r4_equivalence_6_2(obj_67, arg1141_378);
}
if(test1139_376){
aux1341_1062 = list_373;
}
 else {
{
obj_t arg1140_377;
{
obj_t pair_872;
if(PAIRP(list_373)){
pair_872 = list_373;
}
 else {
bigloo_type_error_location_103___error(symbol2769___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, list_373, string2680___r4_pairs_and_lists_6_3, BINT(((long)22008)));
exit( -1 );}
arg1140_377 = CDR(pair_872);
}
{
obj_t list_4549;
list_4549 = arg1140_377;
list_373 = list_4549;
goto loop_374;
}
}
}
}
}
POP_TRACE();
return aux1341_1062;
}
}
}
}


/* _member */obj_t _member___r4_pairs_and_lists_6_3(obj_t env_1201, obj_t obj_1202, obj_t list_1203)
{
return member___r4_pairs_and_lists_6_3(obj_1202, list_1203);
}


/* assq */obj_t assq___r4_pairs_and_lists_6_3(obj_t obj_69, obj_t alist_70)
{
{
obj_t symbol1344_1063;
symbol1344_1063 = symbol2770___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1344_1063);
BUNSPEC;
{
obj_t aux1343_1064;
{
obj_t alist_379;
alist_379 = alist_70;
loop_380:
if(NULLP(alist_379)){
aux1343_1064 = BFALSE;
}
 else {
bool_t test1143_382;
{
obj_t arg1145_384;
{
obj_t arg1146_385;
{
obj_t pair_874;
if(PAIRP(alist_379)){
pair_874 = alist_379;
}
 else {
bigloo_type_error_location_103___error(symbol2770___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_379, string2680___r4_pairs_and_lists_6_3, BINT(((long)22362)));
exit( -1 );}
arg1146_385 = CAR(pair_874);
}
{
obj_t pair_875;
if(PAIRP(arg1146_385)){
pair_875 = arg1146_385;
}
 else {
bigloo_type_error_location_103___error(symbol2770___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1146_385, string2680___r4_pairs_and_lists_6_3, BINT(((long)22356)));
exit( -1 );}
arg1145_384 = CAR(pair_875);
}
}
test1143_382 = (arg1145_384==obj_69);
}
if(test1143_382){
obj_t pair_878;
if(PAIRP(alist_379)){
pair_878 = alist_379;
}
 else {
bigloo_type_error_location_103___error(symbol2770___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_379, string2680___r4_pairs_and_lists_6_3, BINT(((long)22394)));
exit( -1 );}
aux1343_1064 = CAR(pair_878);
}
 else {
obj_t arg1144_383;
{
obj_t pair_879;
if(PAIRP(alist_379)){
pair_879 = alist_379;
}
 else {
bigloo_type_error_location_103___error(symbol2770___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_379, string2680___r4_pairs_and_lists_6_3, BINT(((long)22426)));
exit( -1 );}
arg1144_383 = CDR(pair_879);
}
{
obj_t alist_4581;
alist_4581 = arg1144_383;
alist_379 = alist_4581;
goto loop_380;
}
}
}
}
POP_TRACE();
return aux1343_1064;
}
}
}
}


/* _assq */obj_t _assq___r4_pairs_and_lists_6_3(obj_t env_1204, obj_t obj_1205, obj_t alist_1206)
{
return assq___r4_pairs_and_lists_6_3(obj_1205, alist_1206);
}


/* assv */obj_t assv___r4_pairs_and_lists_6_3(obj_t obj_71, obj_t alist_72)
{
{
obj_t symbol1346_1065;
symbol1346_1065 = symbol2771___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1346_1065);
BUNSPEC;
{
obj_t aux1345_1066;
{
obj_t alist_386;
alist_386 = alist_72;
loop_387:
if(NULLP(alist_386)){
aux1345_1066 = BFALSE;
}
 else {
bool_t test1148_389;
{
obj_t arg1151_391;
{
obj_t arg1152_392;
{
obj_t pair_881;
if(PAIRP(alist_386)){
pair_881 = alist_386;
}
 else {
bigloo_type_error_location_103___error(symbol2771___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_386, string2680___r4_pairs_and_lists_6_3, BINT(((long)22782)));
exit( -1 );}
arg1152_392 = CAR(pair_881);
}
{
obj_t pair_882;
if(PAIRP(arg1152_392)){
pair_882 = arg1152_392;
}
 else {
bigloo_type_error_location_103___error(symbol2771___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1152_392, string2680___r4_pairs_and_lists_6_3, BINT(((long)22776)));
exit( -1 );}
arg1151_391 = CAR(pair_882);
}
}
test1148_389 = eqv__112___r4_equivalence_6_2(arg1151_391, obj_71);
}
if(test1148_389){
obj_t pair_883;
if(PAIRP(alist_386)){
pair_883 = alist_386;
}
 else {
bigloo_type_error_location_103___error(symbol2771___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_386, string2680___r4_pairs_and_lists_6_3, BINT(((long)22814)));
exit( -1 );}
aux1345_1066 = CAR(pair_883);
}
 else {
obj_t arg1150_390;
{
obj_t pair_884;
if(PAIRP(alist_386)){
pair_884 = alist_386;
}
 else {
bigloo_type_error_location_103___error(symbol2771___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_386, string2680___r4_pairs_and_lists_6_3, BINT(((long)22846)));
exit( -1 );}
arg1150_390 = CDR(pair_884);
}
{
obj_t alist_4613;
alist_4613 = arg1150_390;
alist_386 = alist_4613;
goto loop_387;
}
}
}
}
POP_TRACE();
return aux1345_1066;
}
}
}
}


/* _assv */obj_t _assv___r4_pairs_and_lists_6_3(obj_t env_1207, obj_t obj_1208, obj_t alist_1209)
{
return assv___r4_pairs_and_lists_6_3(obj_1208, alist_1209);
}


/* assoc */obj_t assoc___r4_pairs_and_lists_6_3(obj_t obj_73, obj_t alist_74)
{
{
obj_t symbol1348_1067;
symbol1348_1067 = symbol2772___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1348_1067);
BUNSPEC;
{
obj_t aux1347_1068;
if(NULLP(alist_74)){
aux1347_1068 = BFALSE;
}
 else {
obj_t cary_394;
{
obj_t pair_886;
if(PAIRP(alist_74)){
pair_886 = alist_74;
}
 else {
bigloo_type_error_location_103___error(symbol2772___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_74, string2680___r4_pairs_and_lists_6_3, BINT(((long)23160)));
exit( -1 );}
cary_394 = CAR(pair_886);
}
{
bool_t test1154_395;
{
obj_t arg1156_397;
{
obj_t pair_887;
if(PAIRP(cary_394)){
pair_887 = cary_394;
}
 else {
bigloo_type_error_location_103___error(symbol2772___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, cary_394, string2680___r4_pairs_and_lists_6_3, BINT(((long)23201)));
exit( -1 );}
arg1156_397 = CAR(pair_887);
}
test1154_395 = equal__25___r4_equivalence_6_2(obj_73, arg1156_397);
}
if(test1154_395){
aux1347_1068 = cary_394;
}
 else {
obj_t arg1155_396;
{
obj_t pair_888;
if(PAIRP(alist_74)){
pair_888 = alist_74;
}
 else {
bigloo_type_error_location_103___error(symbol2772___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, alist_74, string2680___r4_pairs_and_lists_6_3, BINT(((long)23245)));
exit( -1 );}
arg1155_396 = CDR(pair_888);
}
aux1347_1068 = assoc___r4_pairs_and_lists_6_3(obj_73, arg1155_396);
}
}
}
POP_TRACE();
return aux1347_1068;
}
}
}
}


/* _assoc */obj_t _assoc___r4_pairs_and_lists_6_3(obj_t env_1210, obj_t obj_1211, obj_t alist_1212)
{
return assoc___r4_pairs_and_lists_6_3(obj_1211, alist_1212);
}


/* remq */obj_t remq___r4_pairs_and_lists_6_3(obj_t x_75, obj_t y_76)
{
{
obj_t symbol1350_1069;
symbol1350_1069 = symbol2773___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1350_1069);
BUNSPEC;
{
obj_t aux1349_1070;
if(NULLP(y_76)){
aux1349_1070 = y_76;
}
 else {
bool_t test1158_399;
{
obj_t arg1164_404;
{
obj_t pair_890;
if(PAIRP(y_76)){
pair_890 = y_76;
}
 else {
bigloo_type_error_location_103___error(symbol2773___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_76, string2680___r4_pairs_and_lists_6_3, BINT(((long)23780)));
exit( -1 );}
arg1164_404 = CAR(pair_890);
}
test1158_399 = (x_75==arg1164_404);
}
if(test1158_399){
{
obj_t arg1160_400;
{
obj_t pair_893;
if(PAIRP(y_76)){
pair_893 = y_76;
}
 else {
bigloo_type_error_location_103___error(symbol2773___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_76, string2680___r4_pairs_and_lists_6_3, BINT(((long)23797)));
exit( -1 );}
arg1160_400 = CDR(pair_893);
}
aux1349_1070 = remq___r4_pairs_and_lists_6_3(x_75, arg1160_400);
}
}
 else {
{
obj_t arg1161_401;
obj_t arg1162_402;
{
obj_t pair_894;
if(PAIRP(y_76)){
pair_894 = y_76;
}
 else {
bigloo_type_error_location_103___error(symbol2773___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_76, string2680___r4_pairs_and_lists_6_3, BINT(((long)23825)));
exit( -1 );}
arg1161_401 = CAR(pair_894);
}
{
obj_t arg1163_403;
{
obj_t pair_895;
if(PAIRP(y_76)){
pair_895 = y_76;
}
 else {
bigloo_type_error_location_103___error(symbol2773___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_76, string2680___r4_pairs_and_lists_6_3, BINT(((long)23841)));
exit( -1 );}
arg1163_403 = CDR(pair_895);
}
arg1162_402 = remq___r4_pairs_and_lists_6_3(x_75, arg1163_403);
}
aux1349_1070 = MAKE_PAIR(arg1161_401, arg1162_402);
}
}
}
POP_TRACE();
return aux1349_1070;
}
}
}
}


/* _remq */obj_t _remq___r4_pairs_and_lists_6_3(obj_t env_1213, obj_t x_1214, obj_t y_1215)
{
return remq___r4_pairs_and_lists_6_3(x_1214, y_1215);
}


/* remove */obj_t remove___r4_pairs_and_lists_6_3(obj_t x_77, obj_t y_78)
{
{
obj_t symbol1352_1071;
symbol1352_1071 = symbol2774___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1352_1071);
BUNSPEC;
{
obj_t aux1351_1072;
if(NULLP(y_78)){
aux1351_1072 = y_78;
}
 else {
bool_t test1166_406;
{
obj_t arg1171_411;
{
obj_t pair_899;
if(PAIRP(y_78)){
pair_899 = y_78;
}
 else {
bigloo_type_error_location_103___error(symbol2774___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_78, string2680___r4_pairs_and_lists_6_3, BINT(((long)24144)));
exit( -1 );}
arg1171_411 = CAR(pair_899);
}
test1166_406 = equal__25___r4_equivalence_6_2(x_77, arg1171_411);
}
if(test1166_406){
{
obj_t arg1167_407;
{
obj_t pair_900;
if(PAIRP(y_78)){
pair_900 = y_78;
}
 else {
bigloo_type_error_location_103___error(symbol2774___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_78, string2680___r4_pairs_and_lists_6_3, BINT(((long)24163)));
exit( -1 );}
arg1167_407 = CDR(pair_900);
}
aux1351_1072 = remove___r4_pairs_and_lists_6_3(x_77, arg1167_407);
}
}
 else {
{
obj_t arg1168_408;
obj_t arg1169_409;
{
obj_t pair_901;
if(PAIRP(y_78)){
pair_901 = y_78;
}
 else {
bigloo_type_error_location_103___error(symbol2774___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_78, string2680___r4_pairs_and_lists_6_3, BINT(((long)24191)));
exit( -1 );}
arg1168_408 = CAR(pair_901);
}
{
obj_t arg1170_410;
{
obj_t pair_902;
if(PAIRP(y_78)){
pair_902 = y_78;
}
 else {
bigloo_type_error_location_103___error(symbol2774___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_78, string2680___r4_pairs_and_lists_6_3, BINT(((long)24209)));
exit( -1 );}
arg1170_410 = CDR(pair_902);
}
arg1169_409 = remove___r4_pairs_and_lists_6_3(x_77, arg1170_410);
}
aux1351_1072 = MAKE_PAIR(arg1168_408, arg1169_409);
}
}
}
POP_TRACE();
return aux1351_1072;
}
}
}
}


/* _remove */obj_t _remove___r4_pairs_and_lists_6_3(obj_t env_1216, obj_t x_1217, obj_t y_1218)
{
return remove___r4_pairs_and_lists_6_3(x_1217, y_1218);
}


/* remq! */obj_t remq__51___r4_pairs_and_lists_6_3(obj_t x_79, obj_t y_80)
{
{
obj_t symbol1354_1073;
symbol1354_1073 = symbol2775___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1354_1073);
BUNSPEC;
{
obj_t aux1353_1074;
if(NULLP(y_80)){
aux1353_1074 = y_80;
}
 else {
bool_t test1173_413;
{
obj_t arg1181_423;
{
obj_t pair_906;
if(PAIRP(y_80)){
pair_906 = y_80;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_80, string2680___r4_pairs_and_lists_6_3, BINT(((long)24508)));
exit( -1 );}
arg1181_423 = CAR(pair_906);
}
test1173_413 = (x_79==arg1181_423);
}
if(test1173_413){
{
obj_t arg1174_414;
{
obj_t pair_909;
if(PAIRP(y_80)){
pair_909 = y_80;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_80, string2680___r4_pairs_and_lists_6_3, BINT(((long)24526)));
exit( -1 );}
arg1174_414 = CDR(pair_909);
}
aux1353_1074 = remq__51___r4_pairs_and_lists_6_3(x_79, arg1174_414);
}
}
 else {
{
obj_t prev_415;
prev_415 = y_80;
loop_416:
{
bool_t test1175_417;
{
obj_t arg1180_422;
{
obj_t pair_910;
if(PAIRP(prev_415)){
pair_910 = prev_415;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_415, string2680___r4_pairs_and_lists_6_3, BINT(((long)24598)));
exit( -1 );}
arg1180_422 = CDR(pair_910);
}
test1175_417 = NULLP(arg1180_422);
}
if(test1175_417){
aux1353_1074 = y_80;
}
 else {
bool_t test1176_418;
{
obj_t arg1179_421;
{
obj_t pair_912;
if(PAIRP(prev_415)){
pair_912 = prev_415;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_415, string2680___r4_pairs_and_lists_6_3, BINT(((long)24662)));
exit( -1 );}
{
obj_t arg1007_913;
arg1007_913 = CDR(pair_912);
{
obj_t pair_915;
if(PAIRP(arg1007_913)){
pair_915 = arg1007_913;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1007_913, string2680___r4_pairs_and_lists_6_3, BINT(((long)7991)));
exit( -1 );}
arg1179_421 = CAR(pair_915);
}
}
}
test1176_418 = (arg1179_421==x_79);
}
if(test1176_418){
{
obj_t arg1177_419;
{
obj_t pair_918;
if(PAIRP(prev_415)){
pair_918 = prev_415;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_415, string2680___r4_pairs_and_lists_6_3, BINT(((long)24714)));
exit( -1 );}
{
obj_t arg1009_919;
arg1009_919 = CDR(pair_918);
{
obj_t pair_921;
if(PAIRP(arg1009_919)){
pair_921 = arg1009_919;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1009_919, string2680___r4_pairs_and_lists_6_3, BINT(((long)8533)));
exit( -1 );}
arg1177_419 = CDR(pair_921);
}
}
}
{
obj_t pair_922;
if(PAIRP(prev_415)){
pair_922 = prev_415;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_415, string2680___r4_pairs_and_lists_6_3, BINT(((long)24698)));
exit( -1 );}
SET_CDR(pair_922, arg1177_419);
}
}
{
goto loop_416;
}
}
 else {
{
obj_t arg1178_420;
{
obj_t pair_924;
if(PAIRP(prev_415)){
pair_924 = prev_415;
}
 else {
bigloo_type_error_location_103___error(symbol2775___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_415, string2680___r4_pairs_and_lists_6_3, BINT(((long)24795)));
exit( -1 );}
arg1178_420 = CDR(pair_924);
}
{
obj_t prev_4774;
prev_4774 = arg1178_420;
prev_415 = prev_4774;
goto loop_416;
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1353_1074;
}
}
}
}


/* _remq! */obj_t _remq__174___r4_pairs_and_lists_6_3(obj_t env_1219, obj_t x_1220, obj_t y_1221)
{
return remq__51___r4_pairs_and_lists_6_3(x_1220, y_1221);
}


/* remove! */obj_t remove__21___r4_pairs_and_lists_6_3(obj_t x_81, obj_t y_82)
{
{
obj_t symbol1356_1075;
symbol1356_1075 = symbol2776___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1356_1075);
BUNSPEC;
{
obj_t aux1355_1076;
if(NULLP(y_82)){
aux1355_1076 = y_82;
}
 else {
bool_t test1183_425;
{
obj_t arg1191_435;
{
obj_t pair_926;
if(PAIRP(y_82)){
pair_926 = y_82;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_82, string2680___r4_pairs_and_lists_6_3, BINT(((long)25104)));
exit( -1 );}
arg1191_435 = CAR(pair_926);
}
test1183_425 = equal__25___r4_equivalence_6_2(x_81, arg1191_435);
}
if(test1183_425){
{
obj_t arg1184_426;
{
obj_t pair_927;
if(PAIRP(y_82)){
pair_927 = y_82;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, y_82, string2680___r4_pairs_and_lists_6_3, BINT(((long)25124)));
exit( -1 );}
arg1184_426 = CDR(pair_927);
}
aux1355_1076 = remove__21___r4_pairs_and_lists_6_3(x_81, arg1184_426);
}
}
 else {
{
obj_t prev_427;
prev_427 = y_82;
loop_428:
{
bool_t test1185_429;
{
obj_t arg1190_434;
{
obj_t pair_928;
if(PAIRP(prev_427)){
pair_928 = prev_427;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_427, string2680___r4_pairs_and_lists_6_3, BINT(((long)25196)));
exit( -1 );}
arg1190_434 = CDR(pair_928);
}
test1185_429 = NULLP(arg1190_434);
}
if(test1185_429){
aux1355_1076 = y_82;
}
 else {
bool_t test1186_430;
{
obj_t arg1189_433;
{
obj_t pair_930;
if(PAIRP(prev_427)){
pair_930 = prev_427;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_427, string2680___r4_pairs_and_lists_6_3, BINT(((long)25263)));
exit( -1 );}
{
obj_t arg1007_931;
arg1007_931 = CDR(pair_930);
{
obj_t pair_933;
if(PAIRP(arg1007_931)){
pair_933 = arg1007_931;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1007_931, string2680___r4_pairs_and_lists_6_3, BINT(((long)7991)));
exit( -1 );}
arg1189_433 = CAR(pair_933);
}
}
}
test1186_430 = equal__25___r4_equivalence_6_2(arg1189_433, x_81);
}
if(test1186_430){
{
obj_t arg1187_431;
{
obj_t pair_934;
if(PAIRP(prev_427)){
pair_934 = prev_427;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_427, string2680___r4_pairs_and_lists_6_3, BINT(((long)25315)));
exit( -1 );}
{
obj_t arg1009_935;
arg1009_935 = CDR(pair_934);
{
obj_t pair_937;
if(PAIRP(arg1009_935)){
pair_937 = arg1009_935;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, arg1009_935, string2680___r4_pairs_and_lists_6_3, BINT(((long)8533)));
exit( -1 );}
arg1187_431 = CDR(pair_937);
}
}
}
{
obj_t pair_938;
if(PAIRP(prev_427)){
pair_938 = prev_427;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_427, string2680___r4_pairs_and_lists_6_3, BINT(((long)25299)));
exit( -1 );}
SET_CDR(pair_938, arg1187_431);
}
}
{
goto loop_428;
}
}
 else {
{
obj_t arg1188_432;
{
obj_t pair_940;
if(PAIRP(prev_427)){
pair_940 = prev_427;
}
 else {
bigloo_type_error_location_103___error(symbol2776___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, prev_427, string2680___r4_pairs_and_lists_6_3, BINT(((long)25396)));
exit( -1 );}
arg1188_432 = CDR(pair_940);
}
{
obj_t prev_4841;
prev_4841 = arg1188_432;
prev_427 = prev_4841;
goto loop_428;
}
}
}
}
}
}
}
}
POP_TRACE();
return aux1355_1076;
}
}
}
}


/* _remove! */obj_t _remove__17___r4_pairs_and_lists_6_3(obj_t env_1222, obj_t x_1223, obj_t y_1224)
{
return remove__21___r4_pairs_and_lists_6_3(x_1223, y_1224);
}


/* cons* */obj_t cons__138___r4_pairs_and_lists_6_3(obj_t x_83, obj_t y_84)
{
{
obj_t symbol1358_1077;
symbol1358_1077 = symbol2777___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1358_1077);
BUNSPEC;
{
obj_t aux1357_1078;
if(NULLP(y_84)){
aux1357_1078 = x_83;
}
 else {
obj_t arg1193_439;
arg1193_439 = cons_1_212___r4_pairs_and_lists_6_3(y_84);
aux1357_1078 = MAKE_PAIR(x_83, arg1193_439);
}
POP_TRACE();
return aux1357_1078;
}
}
}
}


/* cons*1 */obj_t cons_1_212___r4_pairs_and_lists_6_3(obj_t x_436)
{
{
bool_t test1194_440;
{
obj_t arg1199_444;
{
obj_t pair_944;
if(PAIRP(x_436)){
pair_944 = x_436;
}
 else {
bigloo_type_error_location_103___error(symbol2778___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_436, string2680___r4_pairs_and_lists_6_3, BINT(((long)25697)));
exit( -1 );}
arg1199_444 = CDR(pair_944);
}
test1194_440 = NULLP(arg1199_444);
}
if(test1194_440){
{
obj_t pair_946;
if(PAIRP(x_436)){
pair_946 = x_436;
}
 else {
bigloo_type_error_location_103___error(symbol2778___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_436, string2680___r4_pairs_and_lists_6_3, BINT(((long)25716)));
exit( -1 );}
return CAR(pair_946);
}
}
 else {
{
obj_t arg1195_441;
obj_t arg1196_442;
{
obj_t pair_947;
if(PAIRP(x_436)){
pair_947 = x_436;
}
 else {
bigloo_type_error_location_103___error(symbol2778___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_436, string2680___r4_pairs_and_lists_6_3, BINT(((long)25756)));
exit( -1 );}
arg1195_441 = CAR(pair_947);
}
{
obj_t arg1197_443;
{
obj_t pair_948;
if(PAIRP(x_436)){
pair_948 = x_436;
}
 else {
bigloo_type_error_location_103___error(symbol2778___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, x_436, string2680___r4_pairs_and_lists_6_3, BINT(((long)25772)));
exit( -1 );}
arg1197_443 = CDR(pair_948);
}
arg1196_442 = cons_1_212___r4_pairs_and_lists_6_3(arg1197_443);
}
return MAKE_PAIR(arg1195_441, arg1196_442);
}
}
}
}


/* _cons* */obj_t _cons__190___r4_pairs_and_lists_6_3(obj_t env_1225, obj_t x_1226, obj_t y_1227)
{
return cons__138___r4_pairs_and_lists_6_3(x_1226, y_1227);
}


/* reverse! */obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t l_85)
{
{
obj_t symbol1360_1079;
symbol1360_1079 = symbol2779___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1360_1079);
BUNSPEC;
{
obj_t aux1359_1080;
if(PAIRP(l_85)){
obj_t l_446;
obj_t r_447;
l_446 = l_85;
r_447 = BNIL;
nr_448:
{
bool_t test1202_450;
{
obj_t arg1204_453;
{
obj_t pair_952;
if(PAIRP(l_446)){
pair_952 = l_446;
}
 else {
bigloo_type_error_location_103___error(symbol2779___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_446, string2680___r4_pairs_and_lists_6_3, BINT(((long)26158)));
exit( -1 );}
arg1204_453 = CDR(pair_952);
}
test1202_450 = NULLP(arg1204_453);
}
if(test1202_450){
{
obj_t pair_954;
if(PAIRP(l_446)){
pair_954 = l_446;
}
 else {
bigloo_type_error_location_103___error(symbol2779___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_446, string2680___r4_pairs_and_lists_6_3, BINT(((long)26205)));
exit( -1 );}
SET_CDR(pair_954, r_447);
}
aux1359_1080 = l_446;
}
 else {
obj_t cdrl_451;
{
obj_t pair_956;
if(PAIRP(l_446)){
pair_956 = l_446;
}
 else {
bigloo_type_error_location_103___error(symbol2779___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_446, string2680___r4_pairs_and_lists_6_3, BINT(((long)26259)));
exit( -1 );}
cdrl_451 = CDR(pair_956);
}
{
obj_t arg1203_452;
{
obj_t pair_957;
if(PAIRP(l_446)){
pair_957 = l_446;
}
 else {
bigloo_type_error_location_103___error(symbol2779___r4_pairs_and_lists_6_3, string2679___r4_pairs_and_lists_6_3, l_446, string2680___r4_pairs_and_lists_6_3, BINT(((long)26295)));
exit( -1 );}
SET_CDR(pair_957, r_447);
}
arg1203_452 = l_446;
{
obj_t r_4909;
obj_t l_4908;
l_4908 = cdrl_451;
r_4909 = arg1203_452;
r_447 = r_4909;
l_446 = l_4908;
goto nr_448;
}
}
}
}
}
 else {
aux1359_1080 = l_85;
}
POP_TRACE();
return aux1359_1080;
}
}
}
}


/* _reverse! */obj_t _reverse__87___r4_pairs_and_lists_6_3(obj_t env_1228, obj_t l_1229)
{
return reverse__39___r4_pairs_and_lists_6_3(l_1229);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_pairs_and_lists_6_3()
{
{
obj_t symbol1362_1081;
symbol1362_1081 = symbol2780___r4_pairs_and_lists_6_3;
{
PUSH_TRACE(symbol1362_1081);
BUNSPEC;
{
obj_t aux1361_1082;
aux1361_1082 = module_initialization_70___error(((long)0), "__R4_PAIRS_AND_LISTS_6_3");
POP_TRACE();
return aux1361_1082;
}
}
}
}

