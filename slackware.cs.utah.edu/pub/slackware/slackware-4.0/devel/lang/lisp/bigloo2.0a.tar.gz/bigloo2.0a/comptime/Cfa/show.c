/*===========================================================================*/
/*   (Cfa/show.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t method_init_76_cfa_show();
extern obj_t string_to_symbol(char *);
extern obj_t cfun_cinfo_200_cfa_info;
extern obj_t get_allocs_52_cfa_collect();
static obj_t _show_cfa_results_182_cfa_show(obj_t, obj_t);
extern obj_t reshaped_global_160_cfa_info;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _shape_tools_shape(obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern obj_t cvar_cinfo_53_cfa_info;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t show_cfa_nb_iterations_231_cfa_show();
extern obj_t intern_sfun_cinfo_192_cfa_info;
extern obj_t show_cfa_results_28_cfa_show(obj_t);
extern obj_t module_initialization_70_cfa_show(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_write_scheme(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_collect(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t shape_reshaped_local_21_cfa_show(obj_t, obj_t);
extern obj_t reshaped_local_224_cfa_info;
static obj_t imported_modules_init_94_cfa_show();
extern obj_t extern_sfun_cinfo_6_cfa_info;
extern obj_t scnst_cinfo_0_cfa_info;
static obj_t shape_reshaped_global_104_cfa_show(obj_t, obj_t);
static obj_t library_modules_init_112_cfa_show();
static obj_t toplevel_init_63_cfa_show();
extern obj_t close_output_port(obj_t);
static obj_t _show_cfa_nb_iterations_163_cfa_show(obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t open_output_string();
static obj_t cfa_variable_shape_84_cfa_show(obj_t, obj_t);
extern obj_t svar_cinfo_166_cfa_info;
extern obj_t _cfa_stamp__16_cfa_iterate;
static obj_t require_initialization_114_cfa_show = BUNSPEC;
static obj_t *__cnst;

DEFINE_STATIC_PROCEDURE(proc2401_cfa_show, shape_reshaped_global_104_cfa_show2403, shape_reshaped_global_104_cfa_show, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2400_cfa_show, shape_reshaped_local_21_cfa_show2404, shape_reshaped_local_21_cfa_show, 0L, 1);
DEFINE_EXPORT_PROCEDURE(show_cfa_nb_iterations_env_198_cfa_show, _show_cfa_nb_iterations_163_cfa_show2405, _show_cfa_nb_iterations_163_cfa_show, 0L, 0);
DEFINE_EXPORT_PROCEDURE(show_cfa_results_env_131_cfa_show, _show_cfa_results_182_cfa_show2406, _show_cfa_results_182_cfa_show, 0L, 1);
DEFINE_STRING(string2399_cfa_show, string2399_cfa_show2407, " ", 1);
DEFINE_STRING(string2398_cfa_show, string2398_cfa_show2408, "      (", 7);
DEFINE_STRING(string2397_cfa_show, string2397_cfa_show2409, " Iterations)", 12);
extern obj_t shape_env_98_tools_shape;


/* module-initialization */ obj_t 
module_initialization_70_cfa_show(long checksum_3317, char *from_3318)
{
   if (CBOOL(require_initialization_114_cfa_show))
     {
	require_initialization_114_cfa_show = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_show();
	imported_modules_init_94_cfa_show();
	method_init_76_cfa_show();
	toplevel_init_63_cfa_show();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_show()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CFA_SHOW");
   module_initialization_70___object(((long) 0), "CFA_SHOW");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_show()
{
   return BUNSPEC;
}


/* show-cfa-nb-iterations */ obj_t 
show_cfa_nb_iterations_231_cfa_show()
{
   {
      long arg2083_2104;
      {
	 long z2_2935;
	 z2_2935 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	 arg2083_2104 = (((long) 1) + z2_2935);
      }
      {
	 obj_t list2085_2106;
	 {
	    obj_t arg2086_2107;
	    {
	       obj_t arg2087_2108;
	       {
		  obj_t arg2088_2109;
		  {
		     obj_t aux_3330;
		     aux_3330 = BCHAR(((unsigned char) '\n'));
		     arg2088_2109 = MAKE_PAIR(aux_3330, BNIL);
		  }
		  arg2087_2108 = MAKE_PAIR(string2397_cfa_show, arg2088_2109);
	       }
	       {
		  obj_t aux_3334;
		  aux_3334 = BINT(arg2083_2104);
		  arg2086_2107 = MAKE_PAIR(aux_3334, arg2087_2108);
	       }
	    }
	    list2085_2106 = MAKE_PAIR(string2398_cfa_show, arg2086_2107);
	 }
	 return verbose_tools_speek(BINT(((long) 2)), list2085_2106);
      }
   }
}


/* _show-cfa-nb-iterations */ obj_t 
_show_cfa_nb_iterations_163_cfa_show(obj_t env_3306)
{
   return show_cfa_nb_iterations_231_cfa_show();
}


/* show-cfa-results */ obj_t 
show_cfa_results_28_cfa_show(obj_t globals_1)
{
   {
      bool_t test2090_2111;
      {
	 obj_t arg2091_2112;
	 arg2091_2112 = get_allocs_52_cfa_collect();
	 test2090_2111 = PAIRP(arg2091_2112);
      }
      if (test2090_2111)
	{
	   BUNSPEC;
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t l2077_2113;
      {
	 obj_t arg2092_2115;
	 arg2092_2115 = get_allocs_52_cfa_collect();
	 l2077_2113 = arg2092_2115;
       lname2078_2114:
	 if (PAIRP(l2077_2113))
	   {
	      {
		 obj_t l2077_3347;
		 l2077_3347 = CDR(l2077_2113);
		 l2077_2113 = l2077_3347;
		 goto lname2078_2114;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   return BUNSPEC;
}


/* _show-cfa-results */ obj_t 
_show_cfa_results_182_cfa_show(obj_t env_3307, obj_t globals_3308)
{
   return show_cfa_results_28_cfa_show(globals_3308);
}


/* cfa-variable-shape */ obj_t 
cfa_variable_shape_84_cfa_show(obj_t variable_4, obj_t port_5)
{
   {
      value_t value_2119;
      {
	 variable_t obj_2940;
	 obj_2940 = (variable_t) (variable_4);
	 value_2119 = (((variable_t) CREF(obj_2940))->value);
      }
      {
	 bool_t test2095_2120;
	 test2095_2120 = is_a__118___object((obj_t) (value_2119), svar_cinfo_166_cfa_info);
	 if (test2095_2120)
	   {
	      {
		 obj_t list2096_2121;
		 list2096_2121 = MAKE_PAIR(port_5, BNIL);
		 display___r4_output_6_10_3(string2399_cfa_show, list2096_2121);
	      }
	      {
		 obj_t arg2098_2123;
		 {
		    obj_t aux_3357;
		    {
		       approx_t aux_3358;
		       {
			  svar_cinfo_166_t obj_2942;
			  obj_2942 = (svar_cinfo_166_t) (value_2119);
			  {
			     obj_t aux_3360;
			     {
				object_t aux_3361;
				aux_3361 = (object_t) (obj_2942);
				aux_3360 = OBJECT_WIDENING(aux_3361);
			     }
			     aux_3358 = (((svar_cinfo_166_t) CREF(aux_3360))->approx);
			  }
		       }
		       aux_3357 = (obj_t) (aux_3358);
		    }
		    arg2098_2123 = shape_tools_shape(aux_3357);
		 }
		 {
		    obj_t list2099_2124;
		    list2099_2124 = MAKE_PAIR(port_5, BNIL);
		    display___r4_output_6_10_3(arg2098_2123, list2099_2124);
		 }
	      }
	   }
	 else
	   {
	      bool_t test2102_2127;
	      test2102_2127 = is_a__118___object((obj_t) (value_2119), cvar_cinfo_53_cfa_info);
	      if (test2102_2127)
		{
		   {
		      obj_t list2103_2128;
		      list2103_2128 = MAKE_PAIR(port_5, BNIL);
		      display___r4_output_6_10_3(string2399_cfa_show, list2103_2128);
		   }
		   {
		      obj_t arg2106_2130;
		      {
			 obj_t aux_3374;
			 {
			    approx_t aux_3375;
			    {
			       cvar_cinfo_53_t obj_2944;
			       obj_2944 = (cvar_cinfo_53_t) (value_2119);
			       {
				  obj_t aux_3377;
				  {
				     object_t aux_3378;
				     aux_3378 = (object_t) (obj_2944);
				     aux_3377 = OBJECT_WIDENING(aux_3378);
				  }
				  aux_3375 = (((cvar_cinfo_53_t) CREF(aux_3377))->approx);
			       }
			    }
			    aux_3374 = (obj_t) (aux_3375);
			 }
			 arg2106_2130 = shape_tools_shape(aux_3374);
		      }
		      {
			 obj_t list2107_2131;
			 list2107_2131 = MAKE_PAIR(port_5, BNIL);
			 display___r4_output_6_10_3(arg2106_2130, list2107_2131);
		      }
		   }
		}
	      else
		{
		   bool_t test2110_2134;
		   test2110_2134 = is_a__118___object((obj_t) (value_2119), scnst_cinfo_0_cfa_info);
		   if (test2110_2134)
		     {
			{
			   obj_t list2111_2135;
			   list2111_2135 = MAKE_PAIR(port_5, BNIL);
			   display___r4_output_6_10_3(string2399_cfa_show, list2111_2135);
			}
			{
			   obj_t arg2113_2137;
			   {
			      obj_t aux_3391;
			      {
				 approx_t aux_3392;
				 {
				    scnst_cinfo_0_t obj_2946;
				    obj_2946 = (scnst_cinfo_0_t) (value_2119);
				    {
				       obj_t aux_3394;
				       {
					  object_t aux_3395;
					  aux_3395 = (object_t) (obj_2946);
					  aux_3394 = OBJECT_WIDENING(aux_3395);
				       }
				       aux_3392 = (((scnst_cinfo_0_t) CREF(aux_3394))->approx);
				    }
				 }
				 aux_3391 = (obj_t) (aux_3392);
			      }
			      arg2113_2137 = shape_tools_shape(aux_3391);
			   }
			   {
			      obj_t list2114_2138;
			      list2114_2138 = MAKE_PAIR(port_5, BNIL);
			      display___r4_output_6_10_3(arg2113_2137, list2114_2138);
			   }
			}
		     }
		   else
		     {
			bool_t test2117_2141;
			test2117_2141 = is_a__118___object((obj_t) (value_2119), intern_sfun_cinfo_192_cfa_info);
			if (test2117_2141)
			  {
			     {
				obj_t list2118_2142;
				list2118_2142 = MAKE_PAIR(port_5, BNIL);
				display___r4_output_6_10_3(string2399_cfa_show, list2118_2142);
			     }
			     {
				obj_t arg2121_2144;
				{
				   obj_t aux_3408;
				   {
				      approx_t aux_3409;
				      {
					 intern_sfun_cinfo_192_t obj_2948;
					 obj_2948 = (intern_sfun_cinfo_192_t) (value_2119);
					 {
					    obj_t aux_3411;
					    {
					       object_t aux_3412;
					       aux_3412 = (object_t) (obj_2948);
					       aux_3411 = OBJECT_WIDENING(aux_3412);
					    }
					    aux_3409 = (((intern_sfun_cinfo_192_t) CREF(aux_3411))->approx);
					 }
				      }
				      aux_3408 = (obj_t) (aux_3409);
				   }
				   arg2121_2144 = shape_tools_shape(aux_3408);
				}
				{
				   obj_t list2122_2145;
				   list2122_2145 = MAKE_PAIR(port_5, BNIL);
				   display___r4_output_6_10_3(arg2121_2144, list2122_2145);
				}
			     }
			  }
			else
			  {
			     bool_t test2125_2148;
			     test2125_2148 = is_a__118___object((obj_t) (value_2119), extern_sfun_cinfo_6_cfa_info);
			     if (test2125_2148)
			       {
				  {
				     obj_t list2126_2149;
				     list2126_2149 = MAKE_PAIR(port_5, BNIL);
				     display___r4_output_6_10_3(string2399_cfa_show, list2126_2149);
				  }
				  {
				     obj_t arg2129_2151;
				     {
					obj_t aux_3425;
					{
					   approx_t aux_3426;
					   {
					      extern_sfun_cinfo_6_t obj_2950;
					      obj_2950 = (extern_sfun_cinfo_6_t) (value_2119);
					      {
						 obj_t aux_3428;
						 {
						    object_t aux_3429;
						    aux_3429 = (object_t) (obj_2950);
						    aux_3428 = OBJECT_WIDENING(aux_3429);
						 }
						 aux_3426 = (((extern_sfun_cinfo_6_t) CREF(aux_3428))->approx);
					      }
					   }
					   aux_3425 = (obj_t) (aux_3426);
					}
					arg2129_2151 = shape_tools_shape(aux_3425);
				     }
				     {
					obj_t list2130_2152;
					list2130_2152 = MAKE_PAIR(port_5, BNIL);
					display___r4_output_6_10_3(arg2129_2151, list2130_2152);
				     }
				  }
			       }
			     else
			       {
				  bool_t test2133_2155;
				  test2133_2155 = is_a__118___object((obj_t) (value_2119), cfun_cinfo_200_cfa_info);
				  if (test2133_2155)
				    {
				       {
					  obj_t list2134_2156;
					  list2134_2156 = MAKE_PAIR(port_5, BNIL);
					  display___r4_output_6_10_3(string2399_cfa_show, list2134_2156);
				       }
				       {
					  obj_t arg2136_2158;
					  {
					     obj_t aux_3442;
					     {
						approx_t aux_3443;
						{
						   cfun_cinfo_200_t obj_2952;
						   obj_2952 = (cfun_cinfo_200_t) (value_2119);
						   {
						      obj_t aux_3445;
						      {
							 object_t aux_3446;
							 aux_3446 = (object_t) (obj_2952);
							 aux_3445 = OBJECT_WIDENING(aux_3446);
						      }
						      aux_3443 = (((cfun_cinfo_200_t) CREF(aux_3445))->approx);
						   }
						}
						aux_3442 = (obj_t) (aux_3443);
					     }
					     arg2136_2158 = shape_tools_shape(aux_3442);
					  }
					  {
					     obj_t list2137_2159;
					     list2137_2159 = MAKE_PAIR(port_5, BNIL);
					     display___r4_output_6_10_3(arg2136_2158, list2137_2159);
					  }
				       }
				    }
				  else
				    {
				       BFALSE;
				    }
			       }
			  }
		     }
		}
	   }
      }
      {
	 obj_t arg2140_2162;
	 arg2140_2162 = close_output_port(port_5);
	 {
	    char *aux_3455;
	    aux_3455 = BSTRING_TO_STRING(arg2140_2162);
	    return string_to_symbol(aux_3455);
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_cfa_show()
{
   {
      obj_t shape_reshaped_local_21_3312;
      shape_reshaped_local_21_3312 = proc2400_cfa_show;
      add_method__1___object(shape_env_98_tools_shape, reshaped_local_224_cfa_info, shape_reshaped_local_21_3312);
   }
   {
      obj_t shape_reshaped_global_104_3309;
      shape_reshaped_global_104_3309 = proc2401_cfa_show;
      return add_method__1___object(shape_env_98_tools_shape, reshaped_global_160_cfa_info, shape_reshaped_global_104_3309);
   }
}


/* shape-reshaped-global */ obj_t 
shape_reshaped_global_104_cfa_show(obj_t env_3313, obj_t global_3314)
{
   {
      reshaped_global_160_t global_2925;
      global_2925 = (reshaped_global_160_t) (global_3314);
      {
	 {
	    obj_t port_2928;
	    port_2928 = open_output_string();
	    {
	       obj_t arg2392_2929;
	       {
		  obj_t next_method2080_190_2932;
		  next_method2080_190_2932 = find_super_class_method_167___object((object_t) (global_2925), shape_env_98_tools_shape, reshaped_global_160_cfa_info);
		  if (PROCEDUREP(next_method2080_190_2932))
		    {
		       arg2392_2929 = PROCEDURE_ENTRY(next_method2080_190_2932) (next_method2080_190_2932, (obj_t) (global_2925), BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(shape_env_98_tools_shape, ((long) 2), next_method2080_190_2932);
		       arg2392_2929 = shape_tools_shape((obj_t) (global_2925));
		    }
	       }
	       {
		  obj_t list2393_2930;
		  list2393_2930 = MAKE_PAIR(port_2928, BNIL);
		  display___r4_output_6_10_3(arg2392_2929, list2393_2930);
	       }
	    }
	    return cfa_variable_shape_84_cfa_show((obj_t) (global_2925), port_2928);
	 }
      }
   }
}


/* shape-reshaped-local */ obj_t 
shape_reshaped_local_21_cfa_show(obj_t env_3315, obj_t local_3316)
{
   {
      reshaped_local_224_t local_2916;
      local_2916 = (reshaped_local_224_t) (local_3316);
      {
	 {
	    obj_t port_2919;
	    port_2919 = open_output_string();
	    {
	       obj_t arg2388_2920;
	       {
		  obj_t next_method2079_165_2923;
		  next_method2079_165_2923 = find_super_class_method_167___object((object_t) (local_2916), shape_env_98_tools_shape, reshaped_local_224_cfa_info);
		  if (PROCEDUREP(next_method2079_165_2923))
		    {
		       arg2388_2920 = PROCEDURE_ENTRY(next_method2079_165_2923) (next_method2079_165_2923, (obj_t) (local_2916), BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(shape_env_98_tools_shape, ((long) 2), next_method2079_165_2923);
		       arg2388_2920 = shape_tools_shape((obj_t) (local_2916));
		    }
	       }
	       {
		  obj_t list2389_2921;
		  list2389_2921 = MAKE_PAIR(port_2919, BNIL);
		  display___r4_output_6_10_3(arg2388_2920, list2389_2921);
	       }
	    }
	    return cfa_variable_shape_84_cfa_show((obj_t) (local_2916), port_2919);
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_show()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_SHOW");
   module_initialization_70_tools_shape(((long) 0), "CFA_SHOW");
   module_initialization_70_tools_speek(((long) 0), "CFA_SHOW");
   module_initialization_70_write_scheme(((long) 0), "CFA_SHOW");
   module_initialization_70_type_type(((long) 0), "CFA_SHOW");
   module_initialization_70_ast_var(((long) 0), "CFA_SHOW");
   module_initialization_70_ast_node(((long) 0), "CFA_SHOW");
   module_initialization_70_cfa_info(((long) 0), "CFA_SHOW");
   module_initialization_70_cfa_approx(((long) 0), "CFA_SHOW");
   module_initialization_70_cfa_collect(((long) 0), "CFA_SHOW");
   return module_initialization_70_cfa_iterate(((long) 0), "CFA_SHOW");
}
