/*===========================================================================*/
/*   (Module/with.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t ccomp_module_module;
static obj_t method_init_76_module_with();
extern obj_t _access_table__91_engine_param;
extern obj_t string_append(obj_t, obj_t);
static obj_t with_parser_118_module_with(obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t import_with_module__247_module_impuse(obj_t);
static obj_t _make_with_compiler_119_module_with(obj_t);
extern obj_t module_initialization_70_module_with(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_read_access(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern long class_num_218___object(obj_t);
static obj_t _with_producer_15_module_with(obj_t, obj_t);
static obj_t imported_modules_init_94_module_with();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t prefix___os(obj_t);
static obj_t library_modules_init_112_module_with();
extern obj_t _with_files__6_engine_param;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t add_access__140_read_access(obj_t, obj_t);
extern obj_t make_with_compiler_235_module_with();
static obj_t arg1025_module_with(obj_t, obj_t, obj_t);
static obj_t arg1020_module_with(obj_t);
static obj_t arg1018_module_with(obj_t, obj_t, obj_t);
static obj_t with_producer_167_module_with(obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_module_with = BUNSPEC;
static obj_t cnst_init_137_module_with();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(proc1219_module_with, arg1020_module_with1233, arg1020_module_with, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1220_module_with, arg1018_module_with1234, arg1018_module_with, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1218_module_with, arg1025_module_with1235, arg1025_module_with, 0L, 2);
DEFINE_STATIC_PROCEDURE(with_producer_env_187_module_with, _with_producer_15_module_with1236, _with_producer_15_module_with, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_with_compiler_env_201_module_with, _make_with_compiler_119_module_with1237, _make_with_compiler_119_module_with, 0L, 0);
DEFINE_STRING(string1225_module_with, string1225_module_with1238, "VOID WITH ", 10);
DEFINE_STRING(string1224_module_with, string1224_module_with1239, "can't access module", 19);
DEFINE_STRING(string1223_module_with, string1223_module_with1240, ".o", 2);
DEFINE_STRING(string1222_module_with, string1222_module_with1241, "Parse error", 11);
DEFINE_STRING(string1221_module_with, string1221_module_with1242, "Illegal `with' clause", 21);


/* module-initialization */ obj_t 
module_initialization_70_module_with(long checksum_193, char *from_194)
{
   if (CBOOL(require_initialization_114_module_with))
     {
	require_initialization_114_module_with = BBOOL(((bool_t) 0));
	library_modules_init_112_module_with();
	cnst_init_137_module_with();
	imported_modules_init_94_module_with();
	method_init_76_module_with();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_with()
{
   module_initialization_70___object(((long) 0), "MODULE_WITH");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_WITH");
   module_initialization_70___os(((long) 0), "MODULE_WITH");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_WITH");
   module_initialization_70___reader(((long) 0), "MODULE_WITH");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_with()
{
   {
      obj_t cnst_port_138_185;
      cnst_port_138_185 = open_input_string(string1225_module_with);
      {
	 long i_186;
	 i_186 = ((long) 1);
       loop_187:
	 {
	    bool_t test1226_188;
	    test1226_188 = (i_186 == ((long) -1));
	    if (test1226_188)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1228_189;
		    {
		       obj_t list1229_190;
		       {
			  obj_t arg1231_191;
			  arg1231_191 = BNIL;
			  list1229_190 = MAKE_PAIR(cnst_port_138_185, arg1231_191);
		       }
		       arg1228_189 = read___reader(list1229_190);
		    }
		    CNST_TABLE_SET(i_186, arg1228_189);
		 }
		 {
		    int aux_192;
		    {
		       long aux_213;
		       aux_213 = (i_186 - ((long) 1));
		       aux_192 = (int) (aux_213);
		    }
		    {
		       long i_216;
		       i_216 = (long) (aux_192);
		       i_186 = i_216;
		       goto loop_187;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-with-compiler */ obj_t 
make_with_compiler_235_module_with()
{
   {
      obj_t arg1014_16;
      arg1014_16 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1025_172;
	 obj_t arg1020_173;
	 obj_t arg1018_174;
	 arg1025_172 = proc1218_module_with;
	 arg1020_173 = proc1219_module_with;
	 arg1018_174 = proc1220_module_with;
	 {
	    ccomp_t res1217_124;
	    {
	       ccomp_t new1002_115;
	       new1002_115 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1216_116;
		  arg1216_116 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_122;
		     obj_122 = (obj_t) (new1002_115);
		     (((obj_t) CREF(obj_122))->header = MAKE_HEADER(arg1216_116, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_223;
		  aux_223 = (object_t) (new1002_115);
		  OBJECT_WIDENING_SET(aux_223, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_115))->id) = ((obj_t) arg1014_16), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_115))->producer) = ((obj_t) with_producer_env_187_module_with), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_115))->consumer) = ((obj_t) arg1018_174), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_115))->finalizer) = ((obj_t) arg1020_173), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_115))->checksummer) = ((obj_t) arg1025_172), BUNSPEC);
	       res1217_124 = new1002_115;
	    }
	    return (obj_t) (res1217_124);
	 }
      }
   }
}


/* _make-with-compiler */ obj_t 
_make_with_compiler_119_module_with(obj_t env_175)
{
   return make_with_compiler_235_module_with();
}


/* arg1025 */ obj_t 
arg1025_module_with(obj_t env_176, obj_t m_177, obj_t c_178)
{
   {
      obj_t m_25;
      obj_t c_26;
      m_25 = m_177;
      c_26 = c_178;
      return c_26;
   }
}


/* arg1020 */ obj_t 
arg1020_module_with(obj_t env_179)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1018 */ obj_t 
arg1018_module_with(obj_t env_180, obj_t m_181, obj_t c_182)
{
   {
      obj_t m_21;
      obj_t c_22;
      m_21 = m_181;
      c_22 = c_182;
      return BNIL;
   }
}


/* with-producer */ obj_t 
with_producer_167_module_with(obj_t clause_1)
{
   {
      obj_t protos_31;
      if (PAIRP(clause_1))
	{
	   bool_t aux_236;
	   protos_31 = CDR(clause_1);
	   {
	      obj_t l1011_37;
	      l1011_37 = protos_31;
	    lname1012_38:
	      if (PAIRP(l1011_37))
		{
		   with_parser_118_module_with(CAR(l1011_37), clause_1);
		   {
		      obj_t l1011_241;
		      l1011_241 = CDR(l1011_37);
		      l1011_37 = l1011_241;
		      goto lname1012_38;
		   }
		}
	      else
		{
		   aux_236 = ((bool_t) 1);
		}
	   }
	   return BBOOL(aux_236);
	}
      else
	{
	   {
	      obj_t arg1039_43;
	      {
		 obj_t list1054_47;
		 list1054_47 = MAKE_PAIR(string1221_module_with, BNIL);
		 arg1039_43 = string_append_106___r4_strings_6_7(list1054_47);
	      }
	      {
		 obj_t list1041_45;
		 list1041_45 = MAKE_PAIR(BNIL, BNIL);
		 return user_error_151_tools_error(string1222_module_with, arg1039_43, clause_1, list1041_45);
	      }
	   }
	}
   }
}


/* _with-producer */ obj_t 
_with_producer_15_module_with(obj_t env_183, obj_t clause_184)
{
   return with_producer_167_module_with(clause_184);
}


/* with-parser */ obj_t 
with_parser_118_module_with(obj_t proto_2, obj_t clause_3)
{
   {
      obj_t name_50;
      obj_t file_51;
      obj_t rest_52;
      if (PAIRP(proto_2))
	{
	   obj_t car_118_222_57;
	   obj_t cdr_119_211_58;
	   car_118_222_57 = CAR(proto_2);
	   cdr_119_211_58 = CDR(proto_2);
	   if (SYMBOLP(car_118_222_57))
	     {
		if (PAIRP(cdr_119_211_58))
		  {
		     obj_t car_124_187_61;
		     car_124_187_61 = CAR(cdr_119_211_58);
		     if (STRINGP(car_124_187_61))
		       {
			  name_50 = car_118_222_57;
			  file_51 = car_124_187_61;
			  rest_52 = CDR(cdr_119_211_58);
			  {
			     obj_t rest_64;
			     obj_t fnames_65;
			     {
				obj_t arg1137_67;
				{
				   obj_t list1138_68;
				   list1138_68 = MAKE_PAIR(file_51, BNIL);
				   arg1137_67 = list1138_68;
				}
				rest_64 = rest_52;
				fnames_65 = arg1137_67;
			      loop_66:
				if (NULLP(rest_64))
				  {
				     {
					obj_t arg1144_71;
					arg1144_71 = reverse__39___r4_pairs_and_lists_6_3(fnames_65);
					add_access__140_read_access(name_50, arg1144_71);
				     }
				  }
				else
				  {
				     bool_t test_266;
				     {
					obj_t aux_267;
					aux_267 = CAR(rest_64);
					test_266 = STRINGP(aux_267);
				     }
				     if (test_266)
				       {
					  {
					     obj_t arg1150_73;
					     obj_t arg1157_74;
					     arg1150_73 = CDR(rest_64);
					     {
						obj_t aux_271;
						aux_271 = CAR(rest_64);
						arg1157_74 = MAKE_PAIR(aux_271, fnames_65);
					     }
					     {
						obj_t fnames_275;
						obj_t rest_274;
						rest_274 = arg1150_73;
						fnames_275 = arg1157_74;
						fnames_65 = fnames_275;
						rest_64 = rest_274;
						goto loop_66;
					     }
					  }
				       }
				     else
				       {
					  {
					     obj_t arg1175_77;
					     {
						obj_t list1188_81;
						list1188_81 = MAKE_PAIR(string1221_module_with, BNIL);
						arg1175_77 = string_append_106___r4_strings_6_7(list1188_81);
					     }
					     {
						obj_t list1177_79;
						list1177_79 = MAKE_PAIR(BNIL, BNIL);
						user_error_151_tools_error(string1222_module_with, arg1175_77, clause_3, list1177_79);
					     }
					  }
				       }
				  }
			     }
			  }
			  {
			     obj_t arg1193_85;
			     {
				obj_t arg1211_147;
				arg1211_147 = prefix___os(file_51);
				arg1193_85 = string_append(arg1211_147, string1223_module_with);
			     }
			     {
				obj_t obj2_150;
				obj2_150 = _with_files__6_engine_param;
				_with_files__6_engine_param = MAKE_PAIR(arg1193_85, obj2_150);
			     }
			  }
			  return import_with_module__247_module_impuse(name_50);
		       }
		     else
		       {
			tag_110_179_54:
			  if (SYMBOLP(proto_2))
			    {
			       obj_t b_87;
			       b_87 = assq___r4_pairs_and_lists_6_3(proto_2, _access_table__91_engine_param);
			       if (CBOOL(b_87))
				 {
				    {
				       obj_t arg1195_88;
				       {
					  obj_t arg1211_157;
					  {
					     obj_t aux_290;
					     {
						obj_t aux_291;
						aux_291 = CDR(b_87);
						aux_290 = CAR(aux_291);
					     }
					     arg1211_157 = prefix___os(aux_290);
					  }
					  arg1195_88 = string_append(arg1211_157, string1223_module_with);
				       }
				       {
					  obj_t obj2_160;
					  obj2_160 = _with_files__6_engine_param;
					  _with_files__6_engine_param = MAKE_PAIR(arg1195_88, obj2_160);
				       }
				    }
				    return import_with_module__247_module_impuse(proto_2);
				 }
			       else
				 {
				    obj_t list1200_92;
				    list1200_92 = MAKE_PAIR(BNIL, BNIL);
				    return user_error_151_tools_error(proto_2, string1224_module_with, clause_3, list1200_92);
				 }
			    }
			  else
			    {
			       obj_t arg1203_95;
			       {
				  obj_t list1207_99;
				  list1207_99 = MAKE_PAIR(string1221_module_with, BNIL);
				  arg1203_95 = string_append_106___r4_strings_6_7(list1207_99);
			       }
			       {
				  obj_t list1205_97;
				  list1205_97 = MAKE_PAIR(BNIL, BNIL);
				  return user_error_151_tools_error(string1222_module_with, arg1203_95, clause_3, list1205_97);
			       }
			    }
		       }
		  }
		else
		  {
		     goto tag_110_179_54;
		  }
	     }
	   else
	     {
		goto tag_110_179_54;
	     }
	}
      else
	{
	   goto tag_110_179_54;
	}
   }
}


/* method-init */ obj_t 
method_init_76_module_with()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_with()
{
   module_initialization_70_module_module(((long) 0), "MODULE_WITH");
   module_initialization_70_engine_param(((long) 0), "MODULE_WITH");
   module_initialization_70_tools_error(((long) 0), "MODULE_WITH");
   module_initialization_70_module_impuse(((long) 0), "MODULE_WITH");
   return module_initialization_70_read_access(((long) 0), "MODULE_WITH");
}
