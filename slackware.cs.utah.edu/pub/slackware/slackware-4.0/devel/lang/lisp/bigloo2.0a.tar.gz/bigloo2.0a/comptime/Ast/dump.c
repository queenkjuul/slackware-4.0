/*===========================================================================*/
/*   (Ast/dump.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern obj_t location_shape_18_tools_location(obj_t, obj_t);
static obj_t method_init_76_ast_dump();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t _type_shape___78_engine_param;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t create_struct(obj_t, long);
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
static obj_t _node__sexp_default1477_253_ast_dump(obj_t, obj_t);
extern obj_t node__sexp_247_ast_dump(node_t);
extern obj_t module_initialization_70_ast_dump(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_ast_dump();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_dump();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_dump();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t _node__sexp2039_178_ast_dump(obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t shape_tools_shape(obj_t);
static obj_t node__sexp_default1477_104_ast_dump(node_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t args_list__args__33_tools_args(obj_t, obj_t);
static obj_t require_initialization_114_ast_dump = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_dump();
static obj_t __cnst[26];

DEFINE_EXPORT_GENERIC(node__sexp_env_62_ast_dump, _node__sexp2039_178_ast_dump2047, _node__sexp2039_178_ast_dump, 0L, 1);
DEFINE_STATIC_PROCEDURE(node__sexp_default1477_env_5_ast_dump, _node__sexp_default1477_253_ast_dump2048, _node__sexp_default1477_253_ast_dump, 0L, 1);
DEFINE_STRING(string2041_ast_dump, string2041_ast_dump2049, "NODE->SEXP-DEFAULT1477 BOX-SET! BOX-REF MAKE-BOX JUMP-EXIT SET-EXIT LET LABELS CASE FAILURE IF SET! CAST FREE-PRAGMA PRAGMA FUNCALL FUNCALL-EL ELIGHT FUNCALL-L LIGHT APPLY BEGIN QUOTE A-TVECTOR FUNCTION (QUOTE ()) ", 214);
DEFINE_STRING(string2040_ast_dump, string2040_ast_dump2050, "No method for this object", 25);


/* module-initialization */ obj_t 
module_initialization_70_ast_dump(long checksum_1774, char *from_1775)
{
   if (CBOOL(require_initialization_114_ast_dump))
     {
	require_initialization_114_ast_dump = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_dump();
	cnst_init_137_ast_dump();
	imported_modules_init_94_ast_dump();
	method_init_76_ast_dump();
	toplevel_init_63_ast_dump();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_dump()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_DUMP");
   module_initialization_70___object(((long) 0), "AST_DUMP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_DUMP");
   module_initialization_70___reader(((long) 0), "AST_DUMP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_dump()
{
   {
      obj_t cnst_port_138_1766;
      cnst_port_138_1766 = open_input_string(string2041_ast_dump);
      {
	 long i_1767;
	 i_1767 = ((long) 25);
       loop_1768:
	 {
	    bool_t test2042_1769;
	    test2042_1769 = (i_1767 == ((long) -1));
	    if (test2042_1769)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2043_1770;
		    {
		       obj_t list2044_1771;
		       {
			  obj_t arg2045_1772;
			  arg2045_1772 = BNIL;
			  list2044_1771 = MAKE_PAIR(cnst_port_138_1766, arg2045_1772);
		       }
		       arg2043_1770 = read___reader(list2044_1771);
		    }
		    CNST_TABLE_SET(i_1767, arg2043_1770);
		 }
		 {
		    int aux_1773;
		    {
		       long aux_1794;
		       aux_1794 = (i_1767 - ((long) 1));
		       aux_1773 = (int) (aux_1794);
		    }
		    {
		       long i_1797;
		       i_1797 = (long) (aux_1773);
		       i_1767 = i_1797;
		       goto loop_1768;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_dump()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_ast_dump()
{
   add_generic__110___object(node__sexp_env_62_ast_dump, node__sexp_default1477_env_5_ast_dump);
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, var_ast_node, ((long) 1));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, closure_ast_node, ((long) 2));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, kwote_ast_node, ((long) 3));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, app_ast_node, ((long) 5));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, select_ast_node, ((long) 13));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(node__sexp_env_62_ast_dump, box_ref_242_ast_node, ((long) 19));
   {
      long aux_1820;
      aux_1820 = add_inlined_method__244___object(node__sexp_env_62_ast_dump, box_set__221_ast_node, ((long) 20));
      return BINT(aux_1820);
   }
}


/* node->sexp */ obj_t 
node__sexp_247_ast_dump(node_t node_11)
{
   {
      obj_t method1621_1073;
      obj_t class1626_1074;
      {
	 obj_t arg1630_1071;
	 obj_t arg1632_1072;
	 {
	    object_t obj_1533;
	    obj_1533 = (object_t) (node_11);
	    {
	       obj_t pre_method_105_1534;
	       pre_method_105_1534 = PROCEDURE_REF(node__sexp_env_62_ast_dump, ((long) 2));
	       if (INTEGERP(pre_method_105_1534))
		 {
		    PROCEDURE_SET(node__sexp_env_62_ast_dump, ((long) 2), BUNSPEC);
		    arg1630_1071 = pre_method_105_1534;
		 }
	       else
		 {
		    long obj_class_num_177_1539;
		    obj_class_num_177_1539 = TYPE(obj_1533);
		    {
		       obj_t arg1177_1540;
		       arg1177_1540 = PROCEDURE_REF(node__sexp_env_62_ast_dump, ((long) 1));
		       {
			  long arg1178_1544;
			  {
			     long arg1179_1545;
			     arg1179_1545 = OBJECT_TYPE;
			     arg1178_1544 = (obj_class_num_177_1539 - arg1179_1545);
			  }
			  arg1630_1071 = VECTOR_REF(arg1177_1540, arg1178_1544);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1550;
	    object_1550 = (object_t) (node_11);
	    {
	       long arg1180_1551;
	       {
		  long arg1181_1552;
		  long arg1182_1553;
		  arg1181_1552 = TYPE(object_1550);
		  arg1182_1553 = OBJECT_TYPE;
		  arg1180_1551 = (arg1181_1552 - arg1182_1553);
	       }
	       {
		  obj_t vector_1557;
		  vector_1557 = _classes__134___object;
		  arg1632_1072 = VECTOR_REF(vector_1557, arg1180_1551);
	       }
	    }
	 }
	 method1621_1073 = arg1630_1071;
	 class1626_1074 = arg1632_1072;
	 {
	    if (INTEGERP(method1621_1073))
	      {
		 switch ((long) CINT(method1621_1073))
		   {
		   case ((long) 0):
		      {
			 atom_t node_1080;
			 node_1080 = (atom_t) (node_11);
			 {
			    bool_t test_1841;
			    {
			       obj_t aux_1842;
			       aux_1842 = (((atom_t) CREF(node_1080))->value);
			       test_1841 = NULLP(aux_1842);
			    }
			    if (test_1841)
			      {
				 return CNST_TABLE_REF(((long) 0));
			      }
			    else
			      {
				 obj_t aux_1846;
				 {
				    node_t obj_1561;
				    obj_1561 = (node_t) (node_1080);
				    aux_1846 = (((node_t) CREF(obj_1561))->loc);
				 }
				 return location_shape_18_tools_location(aux_1846, (((atom_t) CREF(node_1080))->value));
			      }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 var_t node_1085;
			 node_1085 = (var_t) (node_11);
			 {
			    obj_t arg1640_1086;
			    obj_t arg1641_1087;
			    {
			       node_t obj_1563;
			       obj_1563 = (node_t) (node_1085);
			       arg1640_1086 = (((node_t) CREF(obj_1563))->loc);
			    }
			    {
			       obj_t aux_1854;
			       {
				  variable_t aux_1855;
				  aux_1855 = (((var_t) CREF(node_1085))->variable);
				  aux_1854 = (obj_t) (aux_1855);
			       }
			       arg1641_1087 = shape_tools_shape(aux_1854);
			    }
			    return location_shape_18_tools_location(arg1640_1086, arg1641_1087);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 closure_t node_1089;
			 node_1089 = (closure_t) (node_11);
			 {
			    obj_t arg1646_1090;
			    obj_t arg1647_1091;
			    {
			       node_t obj_1565;
			       obj_1565 = (node_t) (node_1089);
			       arg1646_1090 = (((node_t) CREF(obj_1565))->loc);
			    }
			    {
			       obj_t arg1648_1092;
			       obj_t arg1649_1093;
			       arg1648_1092 = CNST_TABLE_REF(((long) 1));
			       {
				  obj_t aux_1864;
				  {
				     variable_t aux_1865;
				     aux_1865 = (((closure_t) CREF(node_1089))->variable);
				     aux_1864 = (obj_t) (aux_1865);
				  }
				  arg1649_1093 = shape_tools_shape(aux_1864);
			       }
			       {
				  obj_t list1651_1095;
				  {
				     obj_t arg1652_1096;
				     arg1652_1096 = MAKE_PAIR(BNIL, BNIL);
				     list1651_1095 = MAKE_PAIR(arg1649_1093, arg1652_1096);
				  }
				  arg1647_1091 = cons__138___r4_pairs_and_lists_6_3(arg1648_1092, list1651_1095);
			       }
			    }
			    return location_shape_18_tools_location(arg1646_1090, arg1647_1091);
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 kwote_t node_1099;
			 node_1099 = (kwote_t) (node_11);
			 {
			    obj_t arg1655_1100;
			    obj_t arg1656_1101;
			    {
			       node_t obj_1567;
			       obj_1567 = (node_t) (node_1099);
			       arg1655_1100 = (((node_t) CREF(obj_1567))->loc);
			    }
			    {
			       obj_t value_1102;
			       value_1102 = (((kwote_t) CREF(node_1099))->value);
			       {
				  bool_t test_1877;
				  if (STRUCTP(value_1102))
				    {
				       obj_t aux_1882;
				       obj_t aux_1880;
				       aux_1882 = CNST_TABLE_REF(((long) 2));
				       aux_1880 = STRUCT_KEY(value_1102);
				       test_1877 = (aux_1880 == aux_1882);
				    }
				  else
				    {
				       test_1877 = ((bool_t) 0);
				    }
				  if (test_1877)
				    {
				       obj_t arg1658_1104;
				       obj_t arg1659_1105;
				       arg1658_1104 = CNST_TABLE_REF(((long) 3));
				       {
					  obj_t arg1666_1110;
					  obj_t arg1667_1111;
					  arg1666_1110 = shape_tools_shape(STRUCT_REF(value_1102, ((long) 0)));
					  arg1667_1111 = STRUCT_REF(value_1102, ((long) 1));
					  {
					     obj_t new_1585;
					     {
						obj_t aux_1889;
						aux_1889 = CNST_TABLE_REF(((long) 2));
						new_1585 = create_struct(aux_1889, ((long) 2));
					     }
					     STRUCT_SET(new_1585, ((long) 1), arg1667_1111);
					     STRUCT_SET(new_1585, ((long) 0), arg1666_1110);
					     arg1659_1105 = new_1585;
					  }
				       }
				       {
					  obj_t list1662_1107;
					  {
					     obj_t arg1663_1108;
					     arg1663_1108 = MAKE_PAIR(BNIL, BNIL);
					     list1662_1107 = MAKE_PAIR(arg1659_1105, arg1663_1108);
					  }
					  arg1656_1101 = cons__138___r4_pairs_and_lists_6_3(arg1658_1104, list1662_1107);
				       }
				    }
				  else
				    {
				       obj_t arg1669_1113;
				       arg1669_1113 = CNST_TABLE_REF(((long) 3));
				       {
					  obj_t list1671_1115;
					  {
					     obj_t arg1672_1116;
					     arg1672_1116 = MAKE_PAIR(BNIL, BNIL);
					     list1671_1115 = MAKE_PAIR(value_1102, arg1672_1116);
					  }
					  arg1656_1101 = cons__138___r4_pairs_and_lists_6_3(arg1669_1113, list1671_1115);
				       }
				    }
			       }
			    }
			    return location_shape_18_tools_location(arg1655_1100, arg1656_1101);
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1118;
			 node_1118 = (sequence_t) (node_11);
			 {
			    obj_t arg1675_1119;
			    obj_t arg1676_1120;
			    {
			       node_t obj_1598;
			       obj_1598 = (node_t) (node_1118);
			       arg1675_1119 = (((node_t) CREF(obj_1598))->loc);
			    }
			    {
			       obj_t arg1677_1121;
			       obj_t arg1678_1122;
			       arg1677_1121 = CNST_TABLE_REF(((long) 4));
			       {
				  obj_t arg1681_1125;
				  obj_t arg1682_1126;
				  {
				     obj_t l1435_1127;
				     l1435_1127 = (((sequence_t) CREF(node_1118))->nodes);
				     if (NULLP(l1435_1127))
				       {
					  arg1681_1125 = BNIL;
				       }
				     else
				       {
					  obj_t head1437_1129;
					  {
					     obj_t arg1692_1140;
					     {
						node_t aux_1909;
						{
						   obj_t aux_1910;
						   aux_1910 = CAR(l1435_1127);
						   aux_1909 = (node_t) (aux_1910);
						}
						arg1692_1140 = node__sexp_247_ast_dump(aux_1909);
					     }
					     head1437_1129 = MAKE_PAIR(arg1692_1140, BNIL);
					  }
					  {
					     obj_t l1435_1130;
					     obj_t tail1438_1131;
					     l1435_1130 = CDR(l1435_1127);
					     tail1438_1131 = head1437_1129;
					   lname1436_1132:
					     if (NULLP(l1435_1130))
					       {
						  arg1681_1125 = head1437_1129;
					       }
					     else
					       {
						  obj_t newtail1439_1135;
						  {
						     obj_t arg1688_1137;
						     {
							node_t aux_1917;
							{
							   obj_t aux_1918;
							   aux_1918 = CAR(l1435_1130);
							   aux_1917 = (node_t) (aux_1918);
							}
							arg1688_1137 = node__sexp_247_ast_dump(aux_1917);
						     }
						     newtail1439_1135 = MAKE_PAIR(arg1688_1137, BNIL);
						  }
						  SET_CDR(tail1438_1131, newtail1439_1135);
						  {
						     obj_t tail1438_1926;
						     obj_t l1435_1924;
						     l1435_1924 = CDR(l1435_1130);
						     tail1438_1926 = newtail1439_1135;
						     tail1438_1131 = tail1438_1926;
						     l1435_1130 = l1435_1924;
						     goto lname1436_1132;
						  }
					       }
					  }
				       }
				  }
				  arg1682_1126 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				  arg1678_1122 = append_2_18___r4_pairs_and_lists_6_3(arg1681_1125, arg1682_1126);
			       }
			       {
				  obj_t list1679_1123;
				  list1679_1123 = MAKE_PAIR(arg1678_1122, BNIL);
				  arg1676_1120 = cons__138___r4_pairs_and_lists_6_3(arg1677_1121, list1679_1123);
			       }
			    }
			    return location_shape_18_tools_location(arg1675_1119, arg1676_1120);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1145;
			 node_1145 = (app_t) (node_11);
			 {
			    obj_t arg1697_1146;
			    obj_t arg1698_1147;
			    {
			       node_t obj_1612;
			       obj_1612 = (node_t) (node_1145);
			       arg1697_1146 = (((node_t) CREF(obj_1612))->loc);
			    }
			    {
			       obj_t arg1699_1148;
			       obj_t arg1700_1149;
			       {
				  node_t aux_1936;
				  {
				     var_t aux_1937;
				     aux_1937 = (((app_t) CREF(node_1145))->fun);
				     aux_1936 = (node_t) (aux_1937);
				  }
				  arg1699_1148 = node__sexp_247_ast_dump(aux_1936);
			       }
			       {
				  obj_t arg1704_1153;
				  obj_t arg1705_1154;
				  {
				     obj_t l1440_1155;
				     l1440_1155 = (((app_t) CREF(node_1145))->args);
				     if (NULLP(l1440_1155))
				       {
					  arg1704_1153 = BNIL;
				       }
				     else
				       {
					  obj_t head1442_1157;
					  {
					     obj_t arg1713_1168;
					     {
						node_t aux_1944;
						{
						   obj_t aux_1945;
						   aux_1945 = CAR(l1440_1155);
						   aux_1944 = (node_t) (aux_1945);
						}
						arg1713_1168 = node__sexp_247_ast_dump(aux_1944);
					     }
					     head1442_1157 = MAKE_PAIR(arg1713_1168, BNIL);
					  }
					  {
					     obj_t l1440_1158;
					     obj_t tail1443_1159;
					     l1440_1158 = CDR(l1440_1155);
					     tail1443_1159 = head1442_1157;
					   lname1441_1160:
					     if (NULLP(l1440_1158))
					       {
						  arg1704_1153 = head1442_1157;
					       }
					     else
					       {
						  obj_t newtail1444_1163;
						  {
						     obj_t arg1710_1165;
						     {
							node_t aux_1952;
							{
							   obj_t aux_1953;
							   aux_1953 = CAR(l1440_1158);
							   aux_1952 = (node_t) (aux_1953);
							}
							arg1710_1165 = node__sexp_247_ast_dump(aux_1952);
						     }
						     newtail1444_1163 = MAKE_PAIR(arg1710_1165, BNIL);
						  }
						  SET_CDR(tail1443_1159, newtail1444_1163);
						  {
						     obj_t tail1443_1961;
						     obj_t l1440_1959;
						     l1440_1959 = CDR(l1440_1158);
						     tail1443_1961 = newtail1444_1163;
						     tail1443_1159 = tail1443_1961;
						     l1440_1158 = l1440_1959;
						     goto lname1441_1160;
						  }
					       }
					  }
				       }
				  }
				  arg1705_1154 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				  arg1700_1149 = append_2_18___r4_pairs_and_lists_6_3(arg1704_1153, arg1705_1154);
			       }
			       {
				  obj_t list1701_1150;
				  list1701_1150 = MAKE_PAIR(arg1700_1149, BNIL);
				  arg1698_1147 = cons__138___r4_pairs_and_lists_6_3(arg1699_1148, list1701_1150);
			       }
			    }
			    return location_shape_18_tools_location(arg1697_1146, arg1698_1147);
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1173;
			 node_1173 = (app_ly_162_t) (node_11);
			 {
			    obj_t arg1720_1174;
			    obj_t arg1721_1175;
			    {
			       node_t obj_1627;
			       obj_1627 = (node_t) (node_1173);
			       arg1720_1174 = (((node_t) CREF(obj_1627))->loc);
			    }
			    {
			       obj_t arg1722_1176;
			       obj_t arg1723_1177;
			       obj_t arg1724_1178;
			       arg1722_1176 = CNST_TABLE_REF(((long) 5));
			       arg1723_1177 = node__sexp_247_ast_dump((((app_ly_162_t) CREF(node_1173))->fun));
			       arg1724_1178 = node__sexp_247_ast_dump((((app_ly_162_t) CREF(node_1173))->arg));
			       {
				  obj_t list1726_1180;
				  {
				     obj_t arg1727_1181;
				     {
					obj_t arg1728_1182;
					arg1728_1182 = MAKE_PAIR(BNIL, BNIL);
					arg1727_1181 = MAKE_PAIR(arg1724_1178, arg1728_1182);
				     }
				     list1726_1180 = MAKE_PAIR(arg1723_1177, arg1727_1181);
				  }
				  arg1721_1175 = cons__138___r4_pairs_and_lists_6_3(arg1722_1176, list1726_1180);
			       }
			    }
			    return location_shape_18_tools_location(arg1720_1174, arg1721_1175);
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1186;
			 node_1186 = (funcall_t) (node_11);
			 {
			    obj_t arg1732_1187;
			    obj_t arg1733_1188;
			    {
			       node_t obj_1630;
			       obj_1630 = (node_t) (node_1186);
			       arg1732_1187 = (((node_t) CREF(obj_1630))->loc);
			    }
			    {
			       obj_t arg1738_1189;
			       obj_t arg1739_1190;
			       obj_t arg1740_1191;
			       {
				  obj_t case_value_58_1195;
				  case_value_58_1195 = (((funcall_t) CREF(node_1186))->strength);
				  {
				     bool_t test_1985;
				     {
					obj_t aux_1986;
					aux_1986 = CNST_TABLE_REF(((long) 6));
					test_1985 = (case_value_58_1195 == aux_1986);
				     }
				     if (test_1985)
				       {
					  arg1738_1189 = CNST_TABLE_REF(((long) 7));
				       }
				     else
				       {
					  bool_t test_1990;
					  {
					     obj_t aux_1991;
					     aux_1991 = CNST_TABLE_REF(((long) 8));
					     test_1990 = (case_value_58_1195 == aux_1991);
					  }
					  if (test_1990)
					    {
					       arg1738_1189 = CNST_TABLE_REF(((long) 9));
					    }
					  else
					    {
					       arg1738_1189 = CNST_TABLE_REF(((long) 10));
					    }
				       }
				  }
			       }
			       arg1739_1190 = node__sexp_247_ast_dump((((funcall_t) CREF(node_1186))->fun));
			       {
				  obj_t arg1753_1201;
				  obj_t arg1755_1202;
				  {
				     obj_t l1445_1203;
				     l1445_1203 = (((funcall_t) CREF(node_1186))->args);
				     if (NULLP(l1445_1203))
				       {
					  arg1753_1201 = BNIL;
				       }
				     else
				       {
					  obj_t head1447_1205;
					  {
					     obj_t arg1766_1216;
					     {
						node_t aux_2001;
						{
						   obj_t aux_2002;
						   aux_2002 = CAR(l1445_1203);
						   aux_2001 = (node_t) (aux_2002);
						}
						arg1766_1216 = node__sexp_247_ast_dump(aux_2001);
					     }
					     head1447_1205 = MAKE_PAIR(arg1766_1216, BNIL);
					  }
					  {
					     obj_t l1445_1206;
					     obj_t tail1448_1207;
					     l1445_1206 = CDR(l1445_1203);
					     tail1448_1207 = head1447_1205;
					   lname1446_1208:
					     if (NULLP(l1445_1206))
					       {
						  arg1753_1201 = head1447_1205;
					       }
					     else
					       {
						  obj_t newtail1449_1211;
						  {
						     obj_t arg1761_1213;
						     {
							node_t aux_2009;
							{
							   obj_t aux_2010;
							   aux_2010 = CAR(l1445_1206);
							   aux_2009 = (node_t) (aux_2010);
							}
							arg1761_1213 = node__sexp_247_ast_dump(aux_2009);
						     }
						     newtail1449_1211 = MAKE_PAIR(arg1761_1213, BNIL);
						  }
						  SET_CDR(tail1448_1207, newtail1449_1211);
						  {
						     obj_t tail1448_2018;
						     obj_t l1445_2016;
						     l1445_2016 = CDR(l1445_1206);
						     tail1448_2018 = newtail1449_1211;
						     tail1448_1207 = tail1448_2018;
						     l1445_1206 = l1445_2016;
						     goto lname1446_1208;
						  }
					       }
					  }
				       }
				  }
				  arg1755_1202 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				  arg1740_1191 = append_2_18___r4_pairs_and_lists_6_3(arg1753_1201, arg1755_1202);
			       }
			       {
				  obj_t list1741_1192;
				  {
				     obj_t arg1743_1193;
				     arg1743_1193 = MAKE_PAIR(arg1740_1191, BNIL);
				     list1741_1192 = MAKE_PAIR(arg1739_1190, arg1743_1193);
				  }
				  arg1733_1188 = cons__138___r4_pairs_and_lists_6_3(arg1738_1189, list1741_1192);
			       }
			    }
			    return location_shape_18_tools_location(arg1732_1187, arg1733_1188);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1221;
			 node_1221 = (pragma_t) (node_11);
			 {
			    obj_t arg1771_1222;
			    obj_t arg1772_1223;
			    {
			       node_t obj_1650;
			       obj_1650 = (node_t) (node_1221);
			       arg1771_1222 = (((node_t) CREF(obj_1650))->loc);
			    }
			    {
			       obj_t p_1224;
			       {
				  bool_t test_2029;
				  {
				     obj_t aux_2030;
				     aux_2030 = (((pragma_t) CREF(node_1221))->side_effect__165);
				     test_2029 = CBOOL(aux_2030);
				  }
				  if (test_2029)
				    {
				       p_1224 = CNST_TABLE_REF(((long) 11));
				    }
				  else
				    {
				       p_1224 = CNST_TABLE_REF(((long) 12));
				    }
			       }
			       {
				  obj_t arg1773_1225;
				  obj_t arg1774_1226;
				  obj_t arg1776_1227;
				  if (CBOOL(_type_shape___78_engine_param))
				    {
				       obj_t list1781_1232;
				       {
					  obj_t arg1783_1233;
					  {
					     obj_t arg1786_1234;
					     {
						obj_t aux_2037;
						{
						   type_t arg1789_1236;
						   {
						      node_t obj_1652;
						      obj_1652 = (node_t) (node_1221);
						      arg1789_1236 = (((node_t) CREF(obj_1652))->type);
						   }
						   aux_2037 = (((type_t) CREF(arg1789_1236))->id);
						}
						arg1786_1234 = MAKE_PAIR(aux_2037, BNIL);
					     }
					     arg1783_1233 = MAKE_PAIR(_4dots_199_tools_misc, arg1786_1234);
					  }
					  list1781_1232 = MAKE_PAIR(p_1224, arg1783_1233);
				       }
				       arg1773_1225 = symbol_append_197___r4_symbols_6_4(list1781_1232);
				    }
				  else
				    {
				       arg1773_1225 = p_1224;
				    }
				  arg1774_1226 = (((pragma_t) CREF(node_1221))->format);
				  {
				     obj_t arg1790_1237;
				     obj_t arg1791_1238;
				     {
					obj_t l1450_1239;
					l1450_1239 = (((pragma_t) CREF(node_1221))->args);
					if (NULLP(l1450_1239))
					  {
					     arg1790_1237 = BNIL;
					  }
					else
					  {
					     obj_t head1452_1241;
					     {
						obj_t arg1800_1252;
						{
						   node_t aux_2049;
						   {
						      obj_t aux_2050;
						      aux_2050 = CAR(l1450_1239);
						      aux_2049 = (node_t) (aux_2050);
						   }
						   arg1800_1252 = node__sexp_247_ast_dump(aux_2049);
						}
						head1452_1241 = MAKE_PAIR(arg1800_1252, BNIL);
					     }
					     {
						obj_t l1450_1242;
						obj_t tail1453_1243;
						l1450_1242 = CDR(l1450_1239);
						tail1453_1243 = head1452_1241;
					      lname1451_1244:
						if (NULLP(l1450_1242))
						  {
						     arg1790_1237 = head1452_1241;
						  }
						else
						  {
						     obj_t newtail1454_1247;
						     {
							obj_t arg1796_1249;
							{
							   node_t aux_2057;
							   {
							      obj_t aux_2058;
							      aux_2058 = CAR(l1450_1242);
							      aux_2057 = (node_t) (aux_2058);
							   }
							   arg1796_1249 = node__sexp_247_ast_dump(aux_2057);
							}
							newtail1454_1247 = MAKE_PAIR(arg1796_1249, BNIL);
						     }
						     SET_CDR(tail1453_1243, newtail1454_1247);
						     {
							obj_t tail1453_2066;
							obj_t l1450_2064;
							l1450_2064 = CDR(l1450_1242);
							tail1453_2066 = newtail1454_1247;
							tail1453_1243 = tail1453_2066;
							l1450_1242 = l1450_2064;
							goto lname1451_1244;
						     }
						  }
					     }
					  }
				     }
				     arg1791_1238 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				     arg1776_1227 = append_2_18___r4_pairs_and_lists_6_3(arg1790_1237, arg1791_1238);
				  }
				  {
				     obj_t list1777_1228;
				     {
					obj_t arg1778_1229;
					arg1778_1229 = MAKE_PAIR(arg1776_1227, BNIL);
					list1777_1228 = MAKE_PAIR(arg1774_1226, arg1778_1229);
				     }
				     arg1772_1223 = cons__138___r4_pairs_and_lists_6_3(arg1773_1225, list1777_1228);
				  }
			       }
			    }
			    return location_shape_18_tools_location(arg1771_1222, arg1772_1223);
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1258;
			 node_1258 = (cast_t) (node_11);
			 {
			    obj_t arg1807_1260;
			    obj_t arg1808_1261;
			    {
			       obj_t arg1813_1266;
			       arg1813_1266 = CNST_TABLE_REF(((long) 13));
			       {
				  obj_t list1815_1268;
				  {
				     obj_t arg1816_1269;
				     {
					obj_t arg1817_1270;
					{
					   obj_t aux_2076;
					   {
					      type_t arg1820_1272;
					      arg1820_1272 = (((cast_t) CREF(node_1258))->type);
					      aux_2076 = (((type_t) CREF(arg1820_1272))->id);
					   }
					   arg1817_1270 = MAKE_PAIR(aux_2076, BNIL);
					}
					arg1816_1269 = MAKE_PAIR(_4dots_199_tools_misc, arg1817_1270);
				     }
				     list1815_1268 = MAKE_PAIR(arg1813_1266, arg1816_1269);
				  }
				  arg1807_1260 = symbol_append_197___r4_symbols_6_4(list1815_1268);
			       }
			    }
			    arg1808_1261 = node__sexp_247_ast_dump((((cast_t) CREF(node_1258))->arg));
			    {
			       obj_t list1810_1263;
			       {
				  obj_t arg1811_1264;
				  arg1811_1264 = MAKE_PAIR(BNIL, BNIL);
				  list1810_1263 = MAKE_PAIR(arg1808_1261, arg1811_1264);
			       }
			       return cons__138___r4_pairs_and_lists_6_3(arg1807_1260, list1810_1263);
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1274;
			 node_1274 = (setq_t) (node_11);
			 {
			    obj_t arg1822_1275;
			    obj_t arg1823_1276;
			    {
			       node_t obj_1671;
			       obj_1671 = (node_t) (node_1274);
			       arg1822_1275 = (((node_t) CREF(obj_1671))->loc);
			    }
			    {
			       obj_t arg1824_1277;
			       obj_t arg1826_1278;
			       obj_t arg1827_1279;
			       arg1824_1277 = CNST_TABLE_REF(((long) 14));
			       {
				  node_t aux_2092;
				  {
				     var_t aux_2093;
				     aux_2093 = (((setq_t) CREF(node_1274))->var);
				     aux_2092 = (node_t) (aux_2093);
				  }
				  arg1826_1278 = node__sexp_247_ast_dump(aux_2092);
			       }
			       arg1827_1279 = node__sexp_247_ast_dump((((setq_t) CREF(node_1274))->value));
			       {
				  obj_t list1830_1281;
				  {
				     obj_t arg1831_1282;
				     {
					obj_t arg1832_1283;
					arg1832_1283 = MAKE_PAIR(BNIL, BNIL);
					arg1831_1282 = MAKE_PAIR(arg1827_1279, arg1832_1283);
				     }
				     list1830_1281 = MAKE_PAIR(arg1826_1278, arg1831_1282);
				  }
				  arg1823_1276 = cons__138___r4_pairs_and_lists_6_3(arg1824_1277, list1830_1281);
			       }
			    }
			    return location_shape_18_tools_location(arg1822_1275, arg1823_1276);
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1287;
			 node_1287 = (conditional_t) (node_11);
			 {
			    obj_t arg1836_1288;
			    obj_t arg1837_1289;
			    {
			       node_t obj_1674;
			       obj_1674 = (node_t) (node_1287);
			       arg1836_1288 = (((node_t) CREF(obj_1674))->loc);
			    }
			    {
			       obj_t arg1838_1290;
			       obj_t arg1839_1291;
			       obj_t arg1842_1292;
			       obj_t arg1843_1293;
			       arg1838_1290 = CNST_TABLE_REF(((long) 15));
			       arg1839_1291 = node__sexp_247_ast_dump((((conditional_t) CREF(node_1287))->test));
			       arg1842_1292 = node__sexp_247_ast_dump((((conditional_t) CREF(node_1287))->true));
			       arg1843_1293 = node__sexp_247_ast_dump((((conditional_t) CREF(node_1287))->false));
			       {
				  obj_t list1848_1295;
				  {
				     obj_t arg1850_1296;
				     {
					obj_t arg1851_1297;
					{
					   obj_t arg1852_1298;
					   arg1852_1298 = MAKE_PAIR(BNIL, BNIL);
					   arg1851_1297 = MAKE_PAIR(arg1843_1293, arg1852_1298);
					}
					arg1850_1296 = MAKE_PAIR(arg1842_1292, arg1851_1297);
				     }
				     list1848_1295 = MAKE_PAIR(arg1839_1291, arg1850_1296);
				  }
				  arg1837_1289 = cons__138___r4_pairs_and_lists_6_3(arg1838_1290, list1848_1295);
			       }
			    }
			    return location_shape_18_tools_location(arg1836_1288, arg1837_1289);
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1303;
			 node_1303 = (fail_t) (node_11);
			 {
			    obj_t arg1859_1304;
			    obj_t arg1860_1305;
			    {
			       node_t obj_1678;
			       obj_1678 = (node_t) (node_1303);
			       arg1859_1304 = (((node_t) CREF(obj_1678))->loc);
			    }
			    {
			       obj_t arg1861_1306;
			       obj_t arg1862_1307;
			       obj_t arg1863_1308;
			       obj_t arg1864_1309;
			       arg1861_1306 = CNST_TABLE_REF(((long) 16));
			       arg1862_1307 = node__sexp_247_ast_dump((((fail_t) CREF(node_1303))->proc));
			       arg1863_1308 = node__sexp_247_ast_dump((((fail_t) CREF(node_1303))->msg));
			       arg1864_1309 = node__sexp_247_ast_dump((((fail_t) CREF(node_1303))->obj));
			       {
				  obj_t list1866_1311;
				  {
				     obj_t arg1867_1312;
				     {
					obj_t arg1868_1313;
					{
					   obj_t arg1869_1314;
					   arg1869_1314 = MAKE_PAIR(BNIL, BNIL);
					   arg1868_1313 = MAKE_PAIR(arg1864_1309, arg1869_1314);
					}
					arg1867_1312 = MAKE_PAIR(arg1863_1308, arg1868_1313);
				     }
				     list1866_1311 = MAKE_PAIR(arg1862_1307, arg1867_1312);
				  }
				  arg1860_1305 = cons__138___r4_pairs_and_lists_6_3(arg1861_1306, list1866_1311);
			       }
			    }
			    return location_shape_18_tools_location(arg1859_1304, arg1860_1305);
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1319;
			 node_1319 = (select_t) (node_11);
			 {
			    obj_t arg1876_1320;
			    obj_t arg1877_1321;
			    {
			       node_t obj_1682;
			       obj_1682 = (node_t) (node_1319);
			       arg1876_1320 = (((node_t) CREF(obj_1682))->loc);
			    }
			    {
			       obj_t arg1878_1322;
			       obj_t arg1879_1323;
			       obj_t arg1880_1324;
			       arg1878_1322 = CNST_TABLE_REF(((long) 17));
			       arg1879_1323 = node__sexp_247_ast_dump((((select_t) CREF(node_1319))->test));
			       {
				  obj_t arg1886_1329;
				  obj_t arg1887_1330;
				  {
				     obj_t l1456_1331;
				     l1456_1331 = (((select_t) CREF(node_1319))->clauses);
				     if (NULLP(l1456_1331))
				       {
					  arg1886_1329 = BNIL;
				       }
				     else
				       {
					  obj_t head1458_1333;
					  head1458_1333 = MAKE_PAIR(BNIL, BNIL);
					  {
					     obj_t l1456_1334;
					     obj_t tail1459_1335;
					     l1456_1334 = l1456_1331;
					     tail1459_1335 = head1458_1333;
					   lname1457_1336:
					     if (NULLP(l1456_1334))
					       {
						  arg1886_1329 = CDR(head1458_1333);
					       }
					     else
					       {
						  obj_t newtail1460_1338;
						  {
						     obj_t arg1892_1340;
						     {
							obj_t clause_1342;
							clause_1342 = CAR(l1456_1334);
							{
							   obj_t arg1894_1343;
							   obj_t arg1895_1344;
							   arg1894_1343 = CAR(clause_1342);
							   {
							      node_t aux_2151;
							      {
								 obj_t aux_2152;
								 aux_2152 = CDR(clause_1342);
								 aux_2151 = (node_t) (aux_2152);
							      }
							      arg1895_1344 = node__sexp_247_ast_dump(aux_2151);
							   }
							   {
							      obj_t list1897_1346;
							      {
								 obj_t arg1898_1347;
								 arg1898_1347 = MAKE_PAIR(BNIL, BNIL);
								 list1897_1346 = MAKE_PAIR(arg1895_1344, arg1898_1347);
							      }
							      arg1892_1340 = cons__138___r4_pairs_and_lists_6_3(arg1894_1343, list1897_1346);
							   }
							}
						     }
						     newtail1460_1338 = MAKE_PAIR(arg1892_1340, BNIL);
						  }
						  SET_CDR(tail1459_1335, newtail1460_1338);
						  {
						     obj_t tail1459_2163;
						     obj_t l1456_2161;
						     l1456_2161 = CDR(l1456_1334);
						     tail1459_2163 = newtail1460_1338;
						     tail1459_1335 = tail1459_2163;
						     l1456_1334 = l1456_2161;
						     goto lname1457_1336;
						  }
					       }
					  }
				       }
				  }
				  arg1887_1330 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				  arg1880_1324 = append_2_18___r4_pairs_and_lists_6_3(arg1886_1329, arg1887_1330);
			       }
			       {
				  obj_t list1881_1325;
				  {
				     obj_t arg1883_1326;
				     arg1883_1326 = MAKE_PAIR(arg1880_1324, BNIL);
				     list1881_1325 = MAKE_PAIR(arg1879_1323, arg1883_1326);
				  }
				  arg1877_1321 = cons__138___r4_pairs_and_lists_6_3(arg1878_1322, list1881_1325);
			       }
			    }
			    return location_shape_18_tools_location(arg1876_1320, arg1877_1321);
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1354;
			 node_1354 = (let_fun_218_t) (node_11);
			 {
			    obj_t arg1905_1355;
			    obj_t arg1906_1356;
			    {
			       node_t obj_1698;
			       obj_1698 = (node_t) (node_1354);
			       arg1905_1355 = (((node_t) CREF(obj_1698))->loc);
			    }
			    {
			       obj_t arg1907_1357;
			       obj_t arg1909_1358;
			       obj_t arg1910_1359;
			       arg1907_1357 = CNST_TABLE_REF(((long) 18));
			       {
				  obj_t l1461_1365;
				  l1461_1365 = (((let_fun_218_t) CREF(node_1354))->locals);
				  if (NULLP(l1461_1365))
				    {
				       arg1909_1358 = BNIL;
				    }
				  else
				    {
				       obj_t head1463_1367;
				       head1463_1367 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1461_1368;
					  obj_t tail1464_1369;
					  l1461_1368 = l1461_1365;
					  tail1464_1369 = head1463_1367;
					lname1462_1370:
					  if (NULLP(l1461_1368))
					    {
					       arg1909_1358 = CDR(head1463_1367);
					    }
					  else
					    {
					       obj_t newtail1465_1372;
					       {
						  obj_t arg1919_1374;
						  {
						     obj_t fun_1376;
						     fun_1376 = CAR(l1461_1368);
						     {
							obj_t arg1921_1377;
							obj_t arg1923_1378;
							obj_t arg1924_1379;
							arg1921_1377 = shape_tools_shape(fun_1376);
							{
							   obj_t arg1930_1385;
							   long arg1931_1386;
							   {
							      obj_t l1466_1387;
							      {
								 sfun_t obj_1707;
								 {
								    value_t aux_2183;
								    {
								       local_t obj_1706;
								       obj_1706 = (local_t) (fun_1376);
								       aux_2183 = (((local_t) CREF(obj_1706))->value);
								    }
								    obj_1707 = (sfun_t) (aux_2183);
								 }
								 l1466_1387 = (((sfun_t) CREF(obj_1707))->args);
							      }
							      if (NULLP(l1466_1387))
								{
								   arg1930_1385 = BNIL;
								}
							      else
								{
								   obj_t head1468_1389;
								   {
								      obj_t arg1939_1400;
								      arg1939_1400 = shape_tools_shape(CAR(l1466_1387));
								      head1468_1389 = MAKE_PAIR(arg1939_1400, BNIL);
								   }
								   {
								      obj_t l1466_1390;
								      obj_t tail1469_1391;
								      l1466_1390 = CDR(l1466_1387);
								      tail1469_1391 = head1468_1389;
								    lname1467_1392:
								      if (NULLP(l1466_1390))
									{
									   arg1930_1385 = head1468_1389;
									}
								      else
									{
									   obj_t newtail1470_1395;
									   {
									      obj_t arg1936_1397;
									      arg1936_1397 = shape_tools_shape(CAR(l1466_1390));
									      newtail1470_1395 = MAKE_PAIR(arg1936_1397, BNIL);
									   }
									   SET_CDR(tail1469_1391, newtail1470_1395);
									   {
									      obj_t tail1469_2201;
									      obj_t l1466_2199;
									      l1466_2199 = CDR(l1466_1390);
									      tail1469_2201 = newtail1470_1395;
									      tail1469_1391 = tail1469_2201;
									      l1466_1390 = l1466_2199;
									      goto lname1467_1392;
									   }
									}
								   }
								}
							   }
							   {
							      sfun_t obj_1721;
							      {
								 value_t aux_2203;
								 {
								    local_t obj_1720;
								    obj_1720 = (local_t) (fun_1376);
								    aux_2203 = (((local_t) CREF(obj_1720))->value);
								 }
								 obj_1721 = (sfun_t) (aux_2203);
							      }
							      arg1931_1386 = (((sfun_t) CREF(obj_1721))->arity);
							   }
							   arg1923_1378 = args_list__args__33_tools_args(arg1930_1385, BINT(arg1931_1386));
							}
							{
							   node_t aux_2210;
							   {
							      obj_t aux_2211;
							      {
								 sfun_t obj_1723;
								 {
								    value_t aux_2212;
								    {
								       local_t obj_1722;
								       obj_1722 = (local_t) (fun_1376);
								       aux_2212 = (((local_t) CREF(obj_1722))->value);
								    }
								    obj_1723 = (sfun_t) (aux_2212);
								 }
								 aux_2211 = (((sfun_t) CREF(obj_1723))->body);
							      }
							      aux_2210 = (node_t) (aux_2211);
							   }
							   arg1924_1379 = node__sexp_247_ast_dump(aux_2210);
							}
							{
							   obj_t list1926_1381;
							   {
							      obj_t arg1927_1382;
							      {
								 obj_t arg1928_1383;
								 arg1928_1383 = MAKE_PAIR(BNIL, BNIL);
								 arg1927_1382 = MAKE_PAIR(arg1924_1379, arg1928_1383);
							      }
							      list1926_1381 = MAKE_PAIR(arg1923_1378, arg1927_1382);
							   }
							   arg1919_1374 = cons__138___r4_pairs_and_lists_6_3(arg1921_1377, list1926_1381);
							}
						     }
						  }
						  newtail1465_1372 = MAKE_PAIR(arg1919_1374, BNIL);
					       }
					       SET_CDR(tail1464_1369, newtail1465_1372);
					       {
						  obj_t tail1464_2227;
						  obj_t l1461_2225;
						  l1461_2225 = CDR(l1461_1368);
						  tail1464_2227 = newtail1465_1372;
						  tail1464_1369 = tail1464_2227;
						  l1461_1368 = l1461_2225;
						  goto lname1462_1370;
					       }
					    }
				       }
				    }
			       }
			       arg1910_1359 = node__sexp_247_ast_dump((((let_fun_218_t) CREF(node_1354))->body));
			       {
				  obj_t list1912_1361;
				  {
				     obj_t arg1913_1362;
				     {
					obj_t arg1914_1363;
					arg1914_1363 = MAKE_PAIR(BNIL, BNIL);
					arg1913_1362 = MAKE_PAIR(arg1910_1359, arg1914_1363);
				     }
				     list1912_1361 = MAKE_PAIR(arg1909_1358, arg1913_1362);
				  }
				  arg1906_1356 = cons__138___r4_pairs_and_lists_6_3(arg1907_1357, list1912_1361);
			       }
			    }
			    return location_shape_18_tools_location(arg1905_1355, arg1906_1356);
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1410;
			 node_1410 = (let_var_6_t) (node_11);
			 {
			    obj_t arg1950_1411;
			    obj_t arg1951_1412;
			    {
			       node_t obj_1730;
			       obj_1730 = (node_t) (node_1410);
			       arg1950_1411 = (((node_t) CREF(obj_1730))->loc);
			    }
			    {
			       obj_t arg1952_1413;
			       obj_t arg1953_1414;
			       obj_t arg1954_1415;
			       arg1952_1413 = CNST_TABLE_REF(((long) 19));
			       {
				  obj_t l1471_1421;
				  l1471_1421 = (((let_var_6_t) CREF(node_1410))->bindings);
				  if (NULLP(l1471_1421))
				    {
				       arg1953_1414 = BNIL;
				    }
				  else
				    {
				       obj_t head1473_1423;
				       head1473_1423 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1471_1424;
					  obj_t tail1474_1425;
					  l1471_1424 = l1471_1421;
					  tail1474_1425 = head1473_1423;
					lname1472_1426:
					  if (NULLP(l1471_1424))
					    {
					       arg1953_1414 = CDR(head1473_1423);
					    }
					  else
					    {
					       obj_t newtail1475_1428;
					       {
						  obj_t arg1964_1430;
						  {
						     obj_t b_1432;
						     b_1432 = CAR(l1471_1424);
						     {
							obj_t arg1967_1433;
							obj_t arg1970_1434;
							arg1967_1433 = shape_tools_shape(CAR(b_1432));
							{
							   node_t aux_2249;
							   {
							      obj_t aux_2250;
							      aux_2250 = CDR(b_1432);
							      aux_2249 = (node_t) (aux_2250);
							   }
							   arg1970_1434 = node__sexp_247_ast_dump(aux_2249);
							}
							{
							   obj_t list1972_1436;
							   {
							      obj_t arg1973_1437;
							      arg1973_1437 = MAKE_PAIR(BNIL, BNIL);
							      list1972_1436 = MAKE_PAIR(arg1970_1434, arg1973_1437);
							   }
							   arg1964_1430 = cons__138___r4_pairs_and_lists_6_3(arg1967_1433, list1972_1436);
							}
						     }
						  }
						  newtail1475_1428 = MAKE_PAIR(arg1964_1430, BNIL);
					       }
					       SET_CDR(tail1474_1425, newtail1475_1428);
					       {
						  obj_t tail1474_2261;
						  obj_t l1471_2259;
						  l1471_2259 = CDR(l1471_1424);
						  tail1474_2261 = newtail1475_1428;
						  tail1474_1425 = tail1474_2261;
						  l1471_1424 = l1471_2259;
						  goto lname1472_1426;
					       }
					    }
				       }
				    }
			       }
			       arg1954_1415 = node__sexp_247_ast_dump((((let_var_6_t) CREF(node_1410))->body));
			       {
				  obj_t list1957_1417;
				  {
				     obj_t arg1958_1418;
				     {
					obj_t arg1959_1419;
					arg1959_1419 = MAKE_PAIR(BNIL, BNIL);
					arg1958_1418 = MAKE_PAIR(arg1954_1415, arg1959_1419);
				     }
				     list1957_1417 = MAKE_PAIR(arg1953_1414, arg1958_1418);
				  }
				  arg1951_1412 = cons__138___r4_pairs_and_lists_6_3(arg1952_1413, list1957_1417);
			       }
			    }
			    return location_shape_18_tools_location(arg1950_1411, arg1951_1412);
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1444;
			 node_1444 = (set_ex_it_116_t) (node_11);
			 {
			    obj_t arg1981_1445;
			    obj_t arg1982_1446;
			    obj_t arg1983_1447;
			    arg1981_1445 = CNST_TABLE_REF(((long) 20));
			    {
			       node_t aux_2271;
			       {
				  var_t aux_2272;
				  aux_2272 = (((set_ex_it_116_t) CREF(node_1444))->var);
				  aux_2271 = (node_t) (aux_2272);
			       }
			       arg1982_1446 = node__sexp_247_ast_dump(aux_2271);
			    }
			    arg1983_1447 = node__sexp_247_ast_dump((((set_ex_it_116_t) CREF(node_1444))->body));
			    {
			       obj_t list1985_1449;
			       {
				  obj_t arg1986_1450;
				  {
				     obj_t arg1987_1451;
				     arg1987_1451 = MAKE_PAIR(BNIL, BNIL);
				     arg1986_1450 = MAKE_PAIR(arg1983_1447, arg1987_1451);
				  }
				  list1985_1449 = MAKE_PAIR(arg1982_1446, arg1986_1450);
			       }
			       return cons__138___r4_pairs_and_lists_6_3(arg1981_1445, list1985_1449);
			    }
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1455;
			 node_1455 = (jump_ex_it_184_t) (node_11);
			 {
			    obj_t arg1991_1456;
			    obj_t arg1992_1457;
			    obj_t arg1993_1458;
			    arg1991_1456 = CNST_TABLE_REF(((long) 21));
			    arg1992_1457 = node__sexp_247_ast_dump((((jump_ex_it_184_t) CREF(node_1455))->exit));
			    arg1993_1458 = node__sexp_247_ast_dump((((jump_ex_it_184_t) CREF(node_1455))->value));
			    {
			       obj_t list1995_1460;
			       {
				  obj_t arg1998_1461;
				  {
				     obj_t arg2000_1462;
				     arg2000_1462 = MAKE_PAIR(BNIL, BNIL);
				     arg1998_1461 = MAKE_PAIR(arg1993_1458, arg2000_1462);
				  }
				  list1995_1460 = MAKE_PAIR(arg1992_1457, arg1998_1461);
			       }
			       return cons__138___r4_pairs_and_lists_6_3(arg1991_1456, list1995_1460);
			    }
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1466;
			 node_1466 = (make_box_202_t) (node_11);
			 {
			    obj_t arg2004_1467;
			    obj_t arg2006_1468;
			    arg2004_1467 = CNST_TABLE_REF(((long) 22));
			    arg2006_1468 = node__sexp_247_ast_dump((((make_box_202_t) CREF(node_1466))->value));
			    {
			       obj_t list2009_1470;
			       {
				  obj_t arg2010_1471;
				  arg2010_1471 = MAKE_PAIR(BNIL, BNIL);
				  list2009_1470 = MAKE_PAIR(arg2006_1468, arg2010_1471);
			       }
			       return cons__138___r4_pairs_and_lists_6_3(arg2004_1467, list2009_1470);
			    }
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_ref_242_t node_1474;
			 node_1474 = (box_ref_242_t) (node_11);
			 {
			    obj_t arg2013_1475;
			    obj_t arg2014_1476;
			    arg2013_1475 = CNST_TABLE_REF(((long) 23));
			    {
			       node_t aux_2301;
			       {
				  var_t aux_2302;
				  aux_2302 = (((box_ref_242_t) CREF(node_1474))->var);
				  aux_2301 = (node_t) (aux_2302);
			       }
			       arg2014_1476 = node__sexp_247_ast_dump(aux_2301);
			    }
			    {
			       obj_t list2016_1478;
			       {
				  obj_t arg2017_1479;
				  arg2017_1479 = MAKE_PAIR(BNIL, BNIL);
				  list2016_1478 = MAKE_PAIR(arg2014_1476, arg2017_1479);
			       }
			       return cons__138___r4_pairs_and_lists_6_3(arg2013_1475, list2016_1478);
			    }
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_set__221_t node_1482;
			 node_1482 = (box_set__221_t) (node_11);
			 {
			    obj_t arg2020_1483;
			    obj_t arg2021_1484;
			    obj_t arg2022_1485;
			    arg2020_1483 = CNST_TABLE_REF(((long) 24));
			    {
			       node_t aux_2311;
			       {
				  var_t aux_2312;
				  aux_2312 = (((box_set__221_t) CREF(node_1482))->var);
				  aux_2311 = (node_t) (aux_2312);
			       }
			       arg2021_1484 = node__sexp_247_ast_dump(aux_2311);
			    }
			    arg2022_1485 = node__sexp_247_ast_dump((((box_set__221_t) CREF(node_1482))->value));
			    {
			       obj_t list2024_1487;
			       {
				  obj_t arg2026_1488;
				  {
				     obj_t arg2027_1489;
				     arg2027_1489 = MAKE_PAIR(BNIL, BNIL);
				     arg2026_1488 = MAKE_PAIR(arg2022_1485, arg2027_1489);
				  }
				  list2024_1487 = MAKE_PAIR(arg2021_1484, arg2026_1488);
			       }
			       return cons__138___r4_pairs_and_lists_6_3(arg2020_1483, list2024_1487);
			    }
			 }
		      }
		      break;
		   default:
		    case_else1627_1077:
		      if (PROCEDUREP(method1621_1073))
			{
			   return PROCEDURE_ENTRY(method1621_1073) (method1621_1073, (obj_t) (node_11), BEOA);
			}
		      else
			{
			   obj_t fun1617_1067;
			   fun1617_1067 = PROCEDURE_REF(node__sexp_env_62_ast_dump, ((long) 0));
			   return PROCEDURE_ENTRY(fun1617_1067) (fun1617_1067, (obj_t) (node_11), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1627_1077;
	      }
	 }
      }
   }
}


/* _node->sexp2039 */ obj_t 
_node__sexp2039_178_ast_dump(obj_t env_1761, obj_t node_1762)
{
   return node__sexp_247_ast_dump((node_t) (node_1762));
}


/* node->sexp-default1477 */ obj_t 
node__sexp_default1477_104_ast_dump(node_t node_12)
{
   FAILURE(CNST_TABLE_REF(((long) 25)), string2040_ast_dump, (obj_t) (node_12));
}


/* _node->sexp-default1477 */ obj_t 
_node__sexp_default1477_253_ast_dump(obj_t env_1763, obj_t node_1764)
{
   return node__sexp_default1477_104_ast_dump((node_t) (node_1764));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_dump()
{
   module_initialization_70_type_type(((long) 0), "AST_DUMP");
   module_initialization_70_ast_var(((long) 0), "AST_DUMP");
   module_initialization_70_ast_node(((long) 0), "AST_DUMP");
   module_initialization_70_tools_shape(((long) 0), "AST_DUMP");
   module_initialization_70_tools_args(((long) 0), "AST_DUMP");
   module_initialization_70_tools_misc(((long) 0), "AST_DUMP");
   module_initialization_70_tools_location(((long) 0), "AST_DUMP");
   return module_initialization_70_engine_param(((long) 0), "AST_DUMP");
}
