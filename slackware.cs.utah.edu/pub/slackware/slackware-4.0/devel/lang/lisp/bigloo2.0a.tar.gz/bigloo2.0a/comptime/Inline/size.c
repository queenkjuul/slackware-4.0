/*===========================================================================*/
/*   (Inline/size.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sized_sequence_48
  {
     long size;
  }
                 *sized_sequence_48_t;

typedef struct sized_app_52
  {
     long size;
  }
            *sized_app_52_t;

typedef struct sized_funcall_46
  {
     long size;
  }
                *sized_funcall_46_t;

typedef struct sized_pragma_213
  {
     long size;
  }
                *sized_pragma_213_t;

typedef struct sized_conditional_152
  {
     long size;
  }
                     *sized_conditional_152_t;

typedef struct sized_fail_63
  {
     long size;
  }
             *sized_fail_63_t;

typedef struct sized_select_166
  {
     long size;
  }
                *sized_select_166_t;

typedef struct sized_let_fun_188
  {
     long size;
  }
                 *sized_let_fun_188_t;

typedef struct sized_let_var_54
  {
     long size;
  }
                *sized_let_var_54_t;


extern long node_size_119_inline_size(node_t);
static obj_t _allocate_sized_select_175_inline_size(obj_t);
static obj_t object__struct_sized_pragma_80_inline_size(obj_t, obj_t);
static obj_t method_init_76_inline_size();
static obj_t struct_object__object_sized_let_fun_64_inline_size(obj_t, obj_t, obj_t);
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static obj_t object__struct_sized_sequence_166_inline_size(obj_t, obj_t);
static obj_t _allocate_sized_sequence_167_inline_size(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _object__struct2142_150___object(obj_t, obj_t);
static long node_size_default1607_123_inline_size(node_t);
extern obj_t fail_ast_node;
static obj_t struct_object__object_sized_app_70_inline_size(obj_t, obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
static obj_t struct_object__object_sized_conditional_125_inline_size(obj_t, obj_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _node_size2143_112_inline_size(obj_t, obj_t);
extern obj_t pragma_ast_node;
static obj_t struct_object__object_sized_fail_89_inline_size(obj_t, obj_t, obj_t);
extern obj_t set_ex_it_116_ast_node;
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
static let_fun_218_t allocate_sized_let_fun_17_inline_size();
static conditional_t allocate_sized_conditional_44_inline_size();
static obj_t sized_select_166_inline_size = BUNSPEC;
static obj_t struct_object__object_sized_select_92_inline_size(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_inline_size(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t object__struct_sized_fail_166_inline_size(obj_t, obj_t);
static obj_t sized_funcall_46_inline_size = BUNSPEC;
static obj_t _allocate_sized_pragma_184_inline_size(obj_t);
static obj_t sized_conditional_152_inline_size = BUNSPEC;
extern long list_length(obj_t);
extern long class_num_218___object(obj_t);
static obj_t _allocate_sized_funcall_28_inline_size(obj_t);
static app_t allocate_sized_app_161_inline_size();
static select_t allocate_sized_select_168_inline_size();
extern obj_t let_fun_218_ast_node;
static obj_t _struct_object__object2140_195___object(obj_t, obj_t, obj_t);
static obj_t sized_let_var_54_inline_size = BUNSPEC;
static obj_t imported_modules_init_94_inline_size();
static obj_t _allocate_sized_let_var_200_inline_size(obj_t);
static obj_t object__struct_sized_funcall_84_inline_size(obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static sequence_t allocate_sized_sequence_56_inline_size();
extern obj_t app_ast_node;
static obj_t library_modules_init_112_inline_size();
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t sized_pragma_213_inline_size = BUNSPEC;
static obj_t object__struct_sized_let_var_36_inline_size(obj_t, obj_t);
static obj_t object__struct_sized_conditional_185_inline_size(obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_inline_size();
static obj_t struct_object__object_sized_pragma_4_inline_size(obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t _allocate_sized_fail_239_inline_size(obj_t);
static obj_t struct_object__object_sized_funcall_26_inline_size(obj_t, obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static obj_t struct_object__object_sized_sequence_143_inline_size(obj_t, obj_t, obj_t);
static obj_t _node_size_default1607_113_inline_size(obj_t, obj_t);
static obj_t object__struct_sized_select_105_inline_size(obj_t, obj_t);
static obj_t sized_let_fun_188_inline_size = BUNSPEC;
static obj_t sized_app_52_inline_size = BUNSPEC;
static pragma_t allocate_sized_pragma_254_inline_size();
static obj_t _allocate_sized_let_fun_213_inline_size(obj_t);
static obj_t struct_object__object_sized_let_var_128_inline_size(obj_t, obj_t, obj_t);
static obj_t object__struct_sized_app_170_inline_size(obj_t, obj_t);
static obj_t sized_sequence_48_inline_size = BUNSPEC;
static obj_t object_init_111_inline_size();
static obj_t object__struct_sized_let_fun_219_inline_size(obj_t, obj_t);
static funcall_t allocate_sized_funcall_74_inline_size();
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static fail_t allocate_sized_fail_135_inline_size();
static obj_t sized_fail_63_inline_size = BUNSPEC;
static obj_t _allocate_sized_app_5_inline_size(obj_t);
extern obj_t object__struct_50___object(object_t);
static obj_t require_initialization_114_inline_size = BUNSPEC;
static let_var_6_t allocate_sized_let_var_152_inline_size();
extern obj_t conditional_ast_node;
static obj_t _allocate_sized_conditional_74_inline_size(obj_t);
static obj_t cnst_init_137_inline_size();
static obj_t __cnst[10];

DEFINE_EXPORT_GENERIC(node_size_env_51_inline_size, _node_size2143_112_inline_size2169, _node_size2143_112_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2161_inline_size, struct_object__object_sized_sequence_143_inline_size2170, struct_object__object_sized_sequence_143_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2159_inline_size, struct_object__object_sized_app_70_inline_size2171, struct_object__object_sized_app_70_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2160_inline_size, object__struct_sized_sequence_166_inline_size2172, object__struct_sized_sequence_166_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2158_inline_size, object__struct_sized_app_170_inline_size2173, object__struct_sized_app_170_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2157_inline_size, struct_object__object_sized_funcall_26_inline_size2174, struct_object__object_sized_funcall_26_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2156_inline_size, object__struct_sized_funcall_84_inline_size2175, object__struct_sized_funcall_84_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2155_inline_size, struct_object__object_sized_pragma_4_inline_size2176, struct_object__object_sized_pragma_4_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2154_inline_size, object__struct_sized_pragma_80_inline_size2177, object__struct_sized_pragma_80_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2153_inline_size, struct_object__object_sized_conditional_125_inline_size2178, struct_object__object_sized_conditional_125_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2152_inline_size, object__struct_sized_conditional_185_inline_size2179, object__struct_sized_conditional_185_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2151_inline_size, struct_object__object_sized_fail_89_inline_size2180, struct_object__object_sized_fail_89_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2149_inline_size, struct_object__object_sized_select_92_inline_size2181, struct_object__object_sized_select_92_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2150_inline_size, object__struct_sized_fail_166_inline_size2182, object__struct_sized_fail_166_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2148_inline_size, object__struct_sized_select_105_inline_size2183, object__struct_sized_select_105_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2147_inline_size, struct_object__object_sized_let_fun_64_inline_size2184, struct_object__object_sized_let_fun_64_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2146_inline_size, object__struct_sized_let_fun_219_inline_size2185, object__struct_sized_let_fun_219_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2145_inline_size, struct_object__object_sized_let_var_128_inline_size2186, struct_object__object_sized_let_var_128_inline_size, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2144_inline_size, object__struct_sized_let_var_36_inline_size2187, object__struct_sized_let_var_36_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(allocate_sized_let_var_env_114_inline_size, _allocate_sized_let_var_200_inline_size2188, _allocate_sized_let_var_200_inline_size, 0L, 0);
DEFINE_STATIC_PROCEDURE(allocate_sized_app_env_53_inline_size, _allocate_sized_app_5_inline_size2189, _allocate_sized_app_5_inline_size, 0L, 0);
DEFINE_STATIC_PROCEDURE(allocate_sized_let_fun_env_195_inline_size, _allocate_sized_let_fun_213_inline_size2190, _allocate_sized_let_fun_213_inline_size, 0L, 0);
extern obj_t struct_object__object_env_209___object;
DEFINE_STATIC_PROCEDURE(node_size_default1607_env_229_inline_size, _node_size_default1607_113_inline_size2191, _node_size_default1607_113_inline_size, 0L, 1);
DEFINE_STATIC_PROCEDURE(allocate_sized_select_env_132_inline_size, _allocate_sized_select_175_inline_size2192, _allocate_sized_select_175_inline_size, 0L, 0);
DEFINE_STATIC_PROCEDURE(allocate_sized_pragma_env_85_inline_size, _allocate_sized_pragma_184_inline_size2193, _allocate_sized_pragma_184_inline_size, 0L, 0);
DEFINE_STATIC_PROCEDURE(allocate_sized_conditional_env_43_inline_size, _allocate_sized_conditional_74_inline_size2194, _allocate_sized_conditional_74_inline_size, 0L, 0);
DEFINE_STRING(string2163_inline_size, string2163_inline_size2195, "NODE-SIZE-DEFAULT1607 SIZED-LET-VAR SIZED-LET-FUN SIZED-SELECT SIZED-FAIL SIZED-CONDITIONAL SIZED-PRAGMA SIZED-FUNCALL SIZED-APP SIZED-SEQUENCE ", 144);
DEFINE_STRING(string2162_inline_size, string2162_inline_size2196, "No method for this object", 25);
DEFINE_STATIC_PROCEDURE(allocate_sized_sequence_env_88_inline_size, _allocate_sized_sequence_167_inline_size2197, _allocate_sized_sequence_167_inline_size, 0L, 0);
extern obj_t object__struct_env_210___object;
DEFINE_STATIC_PROCEDURE(allocate_sized_funcall_env_52_inline_size, _allocate_sized_funcall_28_inline_size2198, _allocate_sized_funcall_28_inline_size, 0L, 0);
DEFINE_STATIC_PROCEDURE(allocate_sized_fail_env_18_inline_size, _allocate_sized_fail_239_inline_size2199, _allocate_sized_fail_239_inline_size, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_inline_size(long checksum_2541, char *from_2542)
{
   if (CBOOL(require_initialization_114_inline_size))
     {
	require_initialization_114_inline_size = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_size();
	cnst_init_137_inline_size();
	imported_modules_init_94_inline_size();
	object_init_111_inline_size();
	method_init_76_inline_size();
	toplevel_init_63_inline_size();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_size()
{
   module_initialization_70___object(((long) 0), "INLINE_SIZE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_SIZE");
   module_initialization_70___reader(((long) 0), "INLINE_SIZE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_size()
{
   {
      obj_t cnst_port_138_2533;
      cnst_port_138_2533 = open_input_string(string2163_inline_size);
      {
	 long i_2534;
	 i_2534 = ((long) 9);
       loop_2535:
	 {
	    bool_t test2164_2536;
	    test2164_2536 = (i_2534 == ((long) -1));
	    if (test2164_2536)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2165_2537;
		    {
		       obj_t list2166_2538;
		       {
			  obj_t arg2167_2539;
			  arg2167_2539 = BNIL;
			  list2166_2538 = MAKE_PAIR(cnst_port_138_2533, arg2167_2539);
		       }
		       arg2165_2537 = read___reader(list2166_2538);
		    }
		    CNST_TABLE_SET(i_2534, arg2165_2537);
		 }
		 {
		    int aux_2540;
		    {
		       long aux_2561;
		       aux_2561 = (i_2534 - ((long) 1));
		       aux_2540 = (int) (aux_2561);
		    }
		    {
		       long i_2564;
		       i_2564 = (long) (aux_2540);
		       i_2534 = i_2564;
		       goto loop_2535;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_inline_size()
{
   return BUNSPEC;
}


/* object-init */ obj_t 
object_init_111_inline_size()
{
   {
      obj_t arg1675_981;
      arg1675_981 = sequence_ast_node;
      sized_sequence_48_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 0)), arg1675_981, allocate_sized_sequence_env_88_inline_size, ((long) 49834), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1679_985;
      arg1679_985 = app_ast_node;
      sized_app_52_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1679_985, allocate_sized_app_env_53_inline_size, ((long) 38290), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1683_989;
      arg1683_989 = funcall_ast_node;
      sized_funcall_46_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1683_989, allocate_sized_funcall_env_52_inline_size, ((long) 47950), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1688_993;
      arg1688_993 = pragma_ast_node;
      sized_pragma_213_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 3)), arg1688_993, allocate_sized_pragma_env_85_inline_size, ((long) 18155), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1693_997;
      arg1693_997 = conditional_ast_node;
      sized_conditional_152_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 4)), arg1693_997, allocate_sized_conditional_env_43_inline_size, ((long) 35687), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1698_1001;
      arg1698_1001 = fail_ast_node;
      sized_fail_63_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 5)), arg1698_1001, allocate_sized_fail_env_18_inline_size, ((long) 24655), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1702_1005;
      arg1702_1005 = select_ast_node;
      sized_select_166_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 6)), arg1702_1005, allocate_sized_select_env_132_inline_size, ((long) 52643), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1706_1009;
      arg1706_1009 = let_fun_218_ast_node;
      sized_let_fun_188_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 7)), arg1706_1009, allocate_sized_let_fun_env_195_inline_size, ((long) 5408), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1710_1013;
      arg1710_1013 = let_var_6_ast_node;
      sized_let_var_54_inline_size = add_class__117___object(CNST_TABLE_REF(((long) 8)), arg1710_1013, allocate_sized_let_var_env_114_inline_size, ((long) 6336), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-sized-let-var */ let_var_6_t 
allocate_sized_let_var_152_inline_size()
{
   {
      let_var_6_t new1589_1016;
      new1589_1016 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
      {
	 long arg1713_1017;
	 arg1713_1017 = class_num_218___object(sized_let_var_54_inline_size);
	 {
	    obj_t obj_1862;
	    obj_1862 = (obj_t) (new1589_1016);
	    (((obj_t) CREF(obj_1862))->header = MAKE_HEADER(arg1713_1017, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2588;
	 aux_2588 = (object_t) (new1589_1016);
	 OBJECT_WIDENING_SET(aux_2588, BFALSE);
      }
      return new1589_1016;
   }
}


/* _allocate-sized-let-var */ obj_t 
_allocate_sized_let_var_200_inline_size(obj_t env_2460)
{
   {
      let_var_6_t aux_2591;
      aux_2591 = allocate_sized_let_var_152_inline_size();
      return (obj_t) (aux_2591);
   }
}


/* allocate-sized-let-fun */ let_fun_218_t 
allocate_sized_let_fun_17_inline_size()
{
   {
      let_fun_218_t new1571_1024;
      new1571_1024 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
      {
	 long arg1717_1025;
	 arg1717_1025 = class_num_218___object(sized_let_fun_188_inline_size);
	 {
	    obj_t obj_1866;
	    obj_1866 = (obj_t) (new1571_1024);
	    (((obj_t) CREF(obj_1866))->header = MAKE_HEADER(arg1717_1025, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2598;
	 aux_2598 = (object_t) (new1571_1024);
	 OBJECT_WIDENING_SET(aux_2598, BFALSE);
      }
      return new1571_1024;
   }
}


/* _allocate-sized-let-fun */ obj_t 
_allocate_sized_let_fun_213_inline_size(obj_t env_2459)
{
   {
      let_fun_218_t aux_2601;
      aux_2601 = allocate_sized_let_fun_17_inline_size();
      return (obj_t) (aux_2601);
   }
}


/* allocate-sized-select */ select_t 
allocate_sized_select_168_inline_size()
{
   {
      select_t new1553_1032;
      new1553_1032 = ((select_t) BREF(GC_MALLOC(sizeof(struct select))));
      {
	 long arg1721_1033;
	 arg1721_1033 = class_num_218___object(sized_select_166_inline_size);
	 {
	    obj_t obj_1870;
	    obj_1870 = (obj_t) (new1553_1032);
	    (((obj_t) CREF(obj_1870))->header = MAKE_HEADER(arg1721_1033, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2608;
	 aux_2608 = (object_t) (new1553_1032);
	 OBJECT_WIDENING_SET(aux_2608, BFALSE);
      }
      return new1553_1032;
   }
}


/* _allocate-sized-select */ obj_t 
_allocate_sized_select_175_inline_size(obj_t env_2458)
{
   {
      select_t aux_2611;
      aux_2611 = allocate_sized_select_168_inline_size();
      return (obj_t) (aux_2611);
   }
}


/* allocate-sized-fail */ fail_t 
allocate_sized_fail_135_inline_size()
{
   {
      fail_t new1537_1040;
      new1537_1040 = ((fail_t) BREF(GC_MALLOC(sizeof(struct fail))));
      {
	 long arg1724_1041;
	 arg1724_1041 = class_num_218___object(sized_fail_63_inline_size);
	 {
	    obj_t obj_1874;
	    obj_1874 = (obj_t) (new1537_1040);
	    (((obj_t) CREF(obj_1874))->header = MAKE_HEADER(arg1724_1041, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2618;
	 aux_2618 = (object_t) (new1537_1040);
	 OBJECT_WIDENING_SET(aux_2618, BFALSE);
      }
      return new1537_1040;
   }
}


/* _allocate-sized-fail */ obj_t 
_allocate_sized_fail_239_inline_size(obj_t env_2457)
{
   {
      fail_t aux_2621;
      aux_2621 = allocate_sized_fail_135_inline_size();
      return (obj_t) (aux_2621);
   }
}


/* allocate-sized-conditional */ conditional_t 
allocate_sized_conditional_44_inline_size()
{
   {
      conditional_t new1521_1048;
      new1521_1048 = ((conditional_t) BREF(GC_MALLOC(sizeof(struct conditional))));
      {
	 long arg1727_1049;
	 arg1727_1049 = class_num_218___object(sized_conditional_152_inline_size);
	 {
	    obj_t obj_1878;
	    obj_1878 = (obj_t) (new1521_1048);
	    (((obj_t) CREF(obj_1878))->header = MAKE_HEADER(arg1727_1049, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2628;
	 aux_2628 = (object_t) (new1521_1048);
	 OBJECT_WIDENING_SET(aux_2628, BFALSE);
      }
      return new1521_1048;
   }
}


/* _allocate-sized-conditional */ obj_t 
_allocate_sized_conditional_74_inline_size(obj_t env_2456)
{
   {
      conditional_t aux_2631;
      aux_2631 = allocate_sized_conditional_44_inline_size();
      return (obj_t) (aux_2631);
   }
}


/* allocate-sized-pragma */ pragma_t 
allocate_sized_pragma_254_inline_size()
{
   {
      pragma_t new1503_1056;
      new1503_1056 = ((pragma_t) BREF(GC_MALLOC(sizeof(struct pragma))));
      {
	 long arg1730_1057;
	 arg1730_1057 = class_num_218___object(sized_pragma_213_inline_size);
	 {
	    obj_t obj_1882;
	    obj_1882 = (obj_t) (new1503_1056);
	    (((obj_t) CREF(obj_1882))->header = MAKE_HEADER(arg1730_1057, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2638;
	 aux_2638 = (object_t) (new1503_1056);
	 OBJECT_WIDENING_SET(aux_2638, BFALSE);
      }
      return new1503_1056;
   }
}


/* _allocate-sized-pragma */ obj_t 
_allocate_sized_pragma_184_inline_size(obj_t env_2455)
{
   {
      pragma_t aux_2641;
      aux_2641 = allocate_sized_pragma_254_inline_size();
      return (obj_t) (aux_2641);
   }
}


/* allocate-sized-funcall */ funcall_t 
allocate_sized_funcall_74_inline_size()
{
   {
      funcall_t new1487_1064;
      new1487_1064 = ((funcall_t) BREF(GC_MALLOC(sizeof(struct funcall))));
      {
	 long arg1733_1065;
	 arg1733_1065 = class_num_218___object(sized_funcall_46_inline_size);
	 {
	    obj_t obj_1886;
	    obj_1886 = (obj_t) (new1487_1064);
	    (((obj_t) CREF(obj_1886))->header = MAKE_HEADER(arg1733_1065, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2648;
	 aux_2648 = (object_t) (new1487_1064);
	 OBJECT_WIDENING_SET(aux_2648, BFALSE);
      }
      return new1487_1064;
   }
}


/* _allocate-sized-funcall */ obj_t 
_allocate_sized_funcall_28_inline_size(obj_t env_2454)
{
   {
      funcall_t aux_2651;
      aux_2651 = allocate_sized_funcall_74_inline_size();
      return (obj_t) (aux_2651);
   }
}


/* allocate-sized-app */ app_t 
allocate_sized_app_161_inline_size()
{
   {
      app_t new1471_1072;
      new1471_1072 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
      {
	 long arg1740_1073;
	 arg1740_1073 = class_num_218___object(sized_app_52_inline_size);
	 {
	    obj_t obj_1890;
	    obj_1890 = (obj_t) (new1471_1072);
	    (((obj_t) CREF(obj_1890))->header = MAKE_HEADER(arg1740_1073, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2658;
	 aux_2658 = (object_t) (new1471_1072);
	 OBJECT_WIDENING_SET(aux_2658, BFALSE);
      }
      return new1471_1072;
   }
}


/* _allocate-sized-app */ obj_t 
_allocate_sized_app_5_inline_size(obj_t env_2453)
{
   {
      app_t aux_2661;
      aux_2661 = allocate_sized_app_161_inline_size();
      return (obj_t) (aux_2661);
   }
}


/* allocate-sized-sequence */ sequence_t 
allocate_sized_sequence_56_inline_size()
{
   {
      sequence_t new1452_1080;
      new1452_1080 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
      {
	 long arg1745_1081;
	 arg1745_1081 = class_num_218___object(sized_sequence_48_inline_size);
	 {
	    obj_t obj_1894;
	    obj_1894 = (obj_t) (new1452_1080);
	    (((obj_t) CREF(obj_1894))->header = MAKE_HEADER(arg1745_1081, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2668;
	 aux_2668 = (object_t) (new1452_1080);
	 OBJECT_WIDENING_SET(aux_2668, BFALSE);
      }
      return new1452_1080;
   }
}


/* _allocate-sized-sequence */ obj_t 
_allocate_sized_sequence_167_inline_size(obj_t env_2452)
{
   {
      sequence_t aux_2671;
      aux_2671 = allocate_sized_sequence_56_inline_size();
      return (obj_t) (aux_2671);
   }
}


/* method-init */ obj_t 
method_init_76_inline_size()
{
   add_generic__110___object(node_size_env_51_inline_size, node_size_default1607_env_229_inline_size);
   add_inlined_method__244___object(node_size_env_51_inline_size, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_size_env_51_inline_size, var_ast_node, ((long) 1));
   add_inlined_method__244___object(node_size_env_51_inline_size, kwote_ast_node, ((long) 2));
   add_inlined_method__244___object(node_size_env_51_inline_size, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_sequence_48_inline_size, ((long) 4));
   add_inlined_method__244___object(node_size_env_51_inline_size, app_ast_node, ((long) 5));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_app_52_inline_size, ((long) 6));
   add_inlined_method__244___object(node_size_env_51_inline_size, app_ly_162_ast_node, ((long) 7));
   add_inlined_method__244___object(node_size_env_51_inline_size, funcall_ast_node, ((long) 8));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_funcall_46_inline_size, ((long) 9));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_pragma_213_inline_size, ((long) 10));
   add_inlined_method__244___object(node_size_env_51_inline_size, cast_ast_node, ((long) 11));
   add_inlined_method__244___object(node_size_env_51_inline_size, pragma_ast_node, ((long) 12));
   add_inlined_method__244___object(node_size_env_51_inline_size, setq_ast_node, ((long) 13));
   add_inlined_method__244___object(node_size_env_51_inline_size, conditional_ast_node, ((long) 14));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_conditional_152_inline_size, ((long) 15));
   add_inlined_method__244___object(node_size_env_51_inline_size, fail_ast_node, ((long) 16));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_fail_63_inline_size, ((long) 17));
   add_inlined_method__244___object(node_size_env_51_inline_size, select_ast_node, ((long) 18));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_select_166_inline_size, ((long) 19));
   add_inlined_method__244___object(node_size_env_51_inline_size, let_fun_218_ast_node, ((long) 20));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_let_fun_188_inline_size, ((long) 21));
   add_inlined_method__244___object(node_size_env_51_inline_size, let_var_6_ast_node, ((long) 22));
   add_inlined_method__244___object(node_size_env_51_inline_size, sized_let_var_54_inline_size, ((long) 23));
   add_inlined_method__244___object(node_size_env_51_inline_size, set_ex_it_116_ast_node, ((long) 24));
   add_inlined_method__244___object(node_size_env_51_inline_size, jump_ex_it_184_ast_node, ((long) 25));
   add_inlined_method__244___object(node_size_env_51_inline_size, make_box_202_ast_node, ((long) 26));
   add_inlined_method__244___object(node_size_env_51_inline_size, box_ref_242_ast_node, ((long) 27));
   add_inlined_method__244___object(node_size_env_51_inline_size, box_set__221_ast_node, ((long) 28));
   {
      obj_t object__struct_sized_let_var_36_2483;
      object__struct_sized_let_var_36_2483 = proc2144_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_let_var_54_inline_size, object__struct_sized_let_var_36_2483);
   }
   {
      obj_t struct_object__object_sized_let_var_128_2482;
      struct_object__object_sized_let_var_128_2482 = proc2145_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_let_var_54_inline_size, struct_object__object_sized_let_var_128_2482);
   }
   {
      obj_t object__struct_sized_let_fun_219_2481;
      object__struct_sized_let_fun_219_2481 = proc2146_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_let_fun_188_inline_size, object__struct_sized_let_fun_219_2481);
   }
   {
      obj_t struct_object__object_sized_let_fun_64_2480;
      struct_object__object_sized_let_fun_64_2480 = proc2147_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_let_fun_188_inline_size, struct_object__object_sized_let_fun_64_2480);
   }
   {
      obj_t object__struct_sized_select_105_2479;
      object__struct_sized_select_105_2479 = proc2148_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_select_166_inline_size, object__struct_sized_select_105_2479);
   }
   {
      obj_t struct_object__object_sized_select_92_2478;
      struct_object__object_sized_select_92_2478 = proc2149_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_select_166_inline_size, struct_object__object_sized_select_92_2478);
   }
   {
      obj_t object__struct_sized_fail_166_2477;
      object__struct_sized_fail_166_2477 = proc2150_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_fail_63_inline_size, object__struct_sized_fail_166_2477);
   }
   {
      obj_t struct_object__object_sized_fail_89_2476;
      struct_object__object_sized_fail_89_2476 = proc2151_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_fail_63_inline_size, struct_object__object_sized_fail_89_2476);
   }
   {
      obj_t object__struct_sized_conditional_185_2475;
      object__struct_sized_conditional_185_2475 = proc2152_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_conditional_152_inline_size, object__struct_sized_conditional_185_2475);
   }
   {
      obj_t struct_object__object_sized_conditional_125_2474;
      struct_object__object_sized_conditional_125_2474 = proc2153_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_conditional_152_inline_size, struct_object__object_sized_conditional_125_2474);
   }
   {
      obj_t object__struct_sized_pragma_80_2473;
      object__struct_sized_pragma_80_2473 = proc2154_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_pragma_213_inline_size, object__struct_sized_pragma_80_2473);
   }
   {
      obj_t struct_object__object_sized_pragma_4_2472;
      struct_object__object_sized_pragma_4_2472 = proc2155_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_pragma_213_inline_size, struct_object__object_sized_pragma_4_2472);
   }
   {
      obj_t object__struct_sized_funcall_84_2471;
      object__struct_sized_funcall_84_2471 = proc2156_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_funcall_46_inline_size, object__struct_sized_funcall_84_2471);
   }
   {
      obj_t struct_object__object_sized_funcall_26_2470;
      struct_object__object_sized_funcall_26_2470 = proc2157_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_funcall_46_inline_size, struct_object__object_sized_funcall_26_2470);
   }
   {
      obj_t object__struct_sized_app_170_2469;
      object__struct_sized_app_170_2469 = proc2158_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_app_52_inline_size, object__struct_sized_app_170_2469);
   }
   {
      obj_t struct_object__object_sized_app_70_2468;
      struct_object__object_sized_app_70_2468 = proc2159_inline_size;
      add_method__1___object(struct_object__object_env_209___object, sized_app_52_inline_size, struct_object__object_sized_app_70_2468);
   }
   {
      obj_t object__struct_sized_sequence_166_2465;
      object__struct_sized_sequence_166_2465 = proc2160_inline_size;
      add_method__1___object(object__struct_env_210___object, sized_sequence_48_inline_size, object__struct_sized_sequence_166_2465);
   }
   {
      obj_t struct_object__object_sized_sequence_143_2461;
      struct_object__object_sized_sequence_143_2461 = proc2161_inline_size;
      return add_method__1___object(struct_object__object_env_209___object, sized_sequence_48_inline_size, struct_object__object_sized_sequence_143_2461);
   }
}


/* struct+object->object-sized-sequence */ obj_t 
struct_object__object_sized_sequence_143_inline_size(obj_t env_2484, obj_t o_2485, obj_t s_2486)
{
   {
      sized_sequence_48_t o_1626;
      obj_t s_1627;
      {
	 sized_sequence_48_t aux_2722;
	 o_1626 = (sized_sequence_48_t) (o_2485);
	 s_1627 = s_2486;
	 {
	    {
	       obj_t old1457_1630;
	       obj_t aux1458_1631;
	       {
		  obj_t next_method1672_43_1636;
		  next_method1672_43_1636 = find_super_class_method_167___object((object_t) (o_1626), struct_object__object_env_209___object, sized_sequence_48_inline_size);
		  if (PROCEDUREP(next_method1672_43_1636))
		    {
		       old1457_1630 = PROCEDURE_ENTRY(next_method1672_43_1636) (next_method1672_43_1636, (obj_t) (o_1626), s_1627, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1672_43_1636);
		       {
			  object_t aux_2731;
			  aux_2731 = struct_object__object_93___object((object_t) (o_1626), s_1627);
			  old1457_1630 = (obj_t) (aux_2731);
		       }
		    }
	       }
	       aux1458_1631 = STRUCT_REF(s_1627, ((long) 0));
	       {
		  sized_sequence_48_t new1459_1632;
		  new1459_1632 = ((sized_sequence_48_t) (old1457_1630));
		  {
		     long arg1945_1633;
		     arg1945_1633 = class_num_218___object(sized_sequence_48_inline_size);
		     {
			obj_t obj_2240;
			obj_2240 = (obj_t) (new1459_1632);
			(((obj_t) CREF(obj_2240))->header = MAKE_HEADER(arg1945_1633, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_sequence_48_t arg1947_1634;
		     {
			sized_sequence_48_t res2127_2247;
			{
			   long size_2244;
			   {
			      obj_t aux_2740;
			      aux_2740 = STRUCT_REF(aux1458_1631, ((long) 0));
			      size_2244 = (long) CINT(aux_2740);
			   }
			   {
			      sized_sequence_48_t new1444_2245;
			      new1444_2245 = ((sized_sequence_48_t) BREF(GC_MALLOC(sizeof(struct sized_sequence_48))));
			      ((((sized_sequence_48_t) CREF(new1444_2245))->size) = ((long) size_2244), BUNSPEC);
			      res2127_2247 = new1444_2245;
			   }
			}
			arg1947_1634 = res2127_2247;
		     }
		     {
			obj_t aux_2747;
			object_t aux_2745;
			aux_2747 = (obj_t) (arg1947_1634);
			aux_2745 = (object_t) (new1459_1632);
			OBJECT_WIDENING_SET(aux_2745, aux_2747);
		     }
		  }
		  aux_2722 = new1459_1632;
	       }
	    }
	 }
	 return (obj_t) (aux_2722);
      }
   }
}


/* object->struct-sized-sequence */ obj_t 
object__struct_sized_sequence_166_inline_size(obj_t env_2487, obj_t obj1454_2488)
{
   {
      sized_sequence_48_t obj1454_1613;
      obj1454_1613 = (sized_sequence_48_t) (obj1454_2488);
      {
	 {
	    obj_t res1455_1616;
	    {
	       obj_t next_method1671_247_1624;
	       next_method1671_247_1624 = find_super_class_method_167___object((object_t) (obj1454_1613), object__struct_env_210___object, sized_sequence_48_inline_size);
	       if (PROCEDUREP(next_method1671_247_1624))
		 {
		    res1455_1616 = PROCEDURE_ENTRY(next_method1671_247_1624) (next_method1671_247_1624, (obj_t) (obj1454_1613), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1671_247_1624);
		    res1455_1616 = object__struct_50___object((object_t) (obj1454_1613));
		 }
	    }
	    {
	       obj_t aux1456_1617;
	       {
		  obj_t aux_2762;
		  aux_2762 = CNST_TABLE_REF(((long) 0));
		  aux1456_1617 = make_struct(aux_2762, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2765;
		  {
		     long aux_2766;
		     {
			obj_t aux_2767;
			{
			   object_t aux_2768;
			   aux_2768 = (object_t) (obj1454_1613);
			   aux_2767 = OBJECT_WIDENING(aux_2768);
			}
			aux_2766 = (((sized_sequence_48_t) CREF(aux_2767))->size);
		     }
		     aux_2765 = BINT(aux_2766);
		  }
		  STRUCT_SET(aux1456_1617, ((long) 0), aux_2765);
	       }
	       STRUCT_SET(res1455_1616, ((long) 0), aux1456_1617);
	       {
		  obj_t aux_2775;
		  aux_2775 = STRUCT_KEY(res1455_1616);
		  STRUCT_KEY_SET(aux1456_1617, aux_2775);
	       }
	       {
		  obj_t aux_2778;
		  aux_2778 = CNST_TABLE_REF(((long) 0));
		  STRUCT_KEY_SET(res1455_1616, aux_2778);
	       }
	       return res1455_1616;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-app */ obj_t 
struct_object__object_sized_app_70_inline_size(obj_t env_2489, obj_t o_2490, obj_t s_2491)
{
   {
      sized_app_52_t o_1601;
      obj_t s_1602;
      {
	 sized_app_52_t aux_2782;
	 o_1601 = (sized_app_52_t) (o_2490);
	 s_1602 = s_2491;
	 {
	    {
	       obj_t old1475_1605;
	       obj_t aux1476_1606;
	       {
		  obj_t next_method1670_204_1611;
		  next_method1670_204_1611 = find_super_class_method_167___object((object_t) (o_1601), struct_object__object_env_209___object, sized_app_52_inline_size);
		  if (PROCEDUREP(next_method1670_204_1611))
		    {
		       old1475_1605 = PROCEDURE_ENTRY(next_method1670_204_1611) (next_method1670_204_1611, (obj_t) (o_1601), s_1602, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1670_204_1611);
		       {
			  object_t aux_2791;
			  aux_2791 = struct_object__object_93___object((object_t) (o_1601), s_1602);
			  old1475_1605 = (obj_t) (aux_2791);
		       }
		    }
	       }
	       aux1476_1606 = STRUCT_REF(s_1602, ((long) 0));
	       {
		  sized_app_52_t new1477_1607;
		  new1477_1607 = ((sized_app_52_t) (old1475_1605));
		  {
		     long arg1934_1608;
		     arg1934_1608 = class_num_218___object(sized_app_52_inline_size);
		     {
			obj_t obj_2211;
			obj_2211 = (obj_t) (new1477_1607);
			(((obj_t) CREF(obj_2211))->header = MAKE_HEADER(arg1934_1608, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_app_52_t arg1935_1609;
		     {
			sized_app_52_t res2126_2218;
			{
			   long size_2215;
			   {
			      obj_t aux_2800;
			      aux_2800 = STRUCT_REF(aux1476_1606, ((long) 0));
			      size_2215 = (long) CINT(aux_2800);
			   }
			   {
			      sized_app_52_t new1460_2216;
			      new1460_2216 = ((sized_app_52_t) BREF(GC_MALLOC(sizeof(struct sized_app_52))));
			      ((((sized_app_52_t) CREF(new1460_2216))->size) = ((long) size_2215), BUNSPEC);
			      res2126_2218 = new1460_2216;
			   }
			}
			arg1935_1609 = res2126_2218;
		     }
		     {
			obj_t aux_2807;
			object_t aux_2805;
			aux_2807 = (obj_t) (arg1935_1609);
			aux_2805 = (object_t) (new1477_1607);
			OBJECT_WIDENING_SET(aux_2805, aux_2807);
		     }
		  }
		  aux_2782 = new1477_1607;
	       }
	    }
	 }
	 return (obj_t) (aux_2782);
      }
   }
}


/* object->struct-sized-app */ obj_t 
object__struct_sized_app_170_inline_size(obj_t env_2492, obj_t obj1472_2493)
{
   {
      sized_app_52_t obj1472_1588;
      obj1472_1588 = (sized_app_52_t) (obj1472_2493);
      {
	 {
	    obj_t res1473_1591;
	    {
	       obj_t next_method1669_93_1599;
	       next_method1669_93_1599 = find_super_class_method_167___object((object_t) (obj1472_1588), object__struct_env_210___object, sized_app_52_inline_size);
	       if (PROCEDUREP(next_method1669_93_1599))
		 {
		    res1473_1591 = PROCEDURE_ENTRY(next_method1669_93_1599) (next_method1669_93_1599, (obj_t) (obj1472_1588), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1669_93_1599);
		    res1473_1591 = object__struct_50___object((object_t) (obj1472_1588));
		 }
	    }
	    {
	       obj_t aux1474_1592;
	       {
		  obj_t aux_2822;
		  aux_2822 = CNST_TABLE_REF(((long) 1));
		  aux1474_1592 = make_struct(aux_2822, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2825;
		  {
		     long aux_2826;
		     {
			obj_t aux_2827;
			{
			   object_t aux_2828;
			   aux_2828 = (object_t) (obj1472_1588);
			   aux_2827 = OBJECT_WIDENING(aux_2828);
			}
			aux_2826 = (((sized_app_52_t) CREF(aux_2827))->size);
		     }
		     aux_2825 = BINT(aux_2826);
		  }
		  STRUCT_SET(aux1474_1592, ((long) 0), aux_2825);
	       }
	       STRUCT_SET(res1473_1591, ((long) 0), aux1474_1592);
	       {
		  obj_t aux_2835;
		  aux_2835 = STRUCT_KEY(res1473_1591);
		  STRUCT_KEY_SET(aux1474_1592, aux_2835);
	       }
	       {
		  obj_t aux_2838;
		  aux_2838 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1473_1591, aux_2838);
	       }
	       return res1473_1591;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-funcall */ obj_t 
struct_object__object_sized_funcall_26_inline_size(obj_t env_2494, obj_t o_2495, obj_t s_2496)
{
   {
      sized_funcall_46_t o_1576;
      obj_t s_1577;
      {
	 sized_funcall_46_t aux_2842;
	 o_1576 = (sized_funcall_46_t) (o_2495);
	 s_1577 = s_2496;
	 {
	    {
	       obj_t old1491_1580;
	       obj_t aux1492_1581;
	       {
		  obj_t next_method1668_159_1586;
		  next_method1668_159_1586 = find_super_class_method_167___object((object_t) (o_1576), struct_object__object_env_209___object, sized_funcall_46_inline_size);
		  if (PROCEDUREP(next_method1668_159_1586))
		    {
		       old1491_1580 = PROCEDURE_ENTRY(next_method1668_159_1586) (next_method1668_159_1586, (obj_t) (o_1576), s_1577, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1668_159_1586);
		       {
			  object_t aux_2851;
			  aux_2851 = struct_object__object_93___object((object_t) (o_1576), s_1577);
			  old1491_1580 = (obj_t) (aux_2851);
		       }
		    }
	       }
	       aux1492_1581 = STRUCT_REF(s_1577, ((long) 0));
	       {
		  sized_funcall_46_t new1493_1582;
		  new1493_1582 = ((sized_funcall_46_t) (old1491_1580));
		  {
		     long arg1923_1583;
		     arg1923_1583 = class_num_218___object(sized_funcall_46_inline_size);
		     {
			obj_t obj_2182;
			obj_2182 = (obj_t) (new1493_1582);
			(((obj_t) CREF(obj_2182))->header = MAKE_HEADER(arg1923_1583, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_funcall_46_t arg1924_1584;
		     {
			sized_funcall_46_t res2125_2189;
			{
			   long size_2186;
			   {
			      obj_t aux_2860;
			      aux_2860 = STRUCT_REF(aux1492_1581, ((long) 0));
			      size_2186 = (long) CINT(aux_2860);
			   }
			   {
			      sized_funcall_46_t new1478_2187;
			      new1478_2187 = ((sized_funcall_46_t) BREF(GC_MALLOC(sizeof(struct sized_funcall_46))));
			      ((((sized_funcall_46_t) CREF(new1478_2187))->size) = ((long) size_2186), BUNSPEC);
			      res2125_2189 = new1478_2187;
			   }
			}
			arg1924_1584 = res2125_2189;
		     }
		     {
			obj_t aux_2867;
			object_t aux_2865;
			aux_2867 = (obj_t) (arg1924_1584);
			aux_2865 = (object_t) (new1493_1582);
			OBJECT_WIDENING_SET(aux_2865, aux_2867);
		     }
		  }
		  aux_2842 = new1493_1582;
	       }
	    }
	 }
	 return (obj_t) (aux_2842);
      }
   }
}


/* object->struct-sized-funcall */ obj_t 
object__struct_sized_funcall_84_inline_size(obj_t env_2497, obj_t obj1488_2498)
{
   {
      sized_funcall_46_t obj1488_1563;
      obj1488_1563 = (sized_funcall_46_t) (obj1488_2498);
      {
	 {
	    obj_t res1489_1566;
	    {
	       obj_t next_method1667_218_1574;
	       next_method1667_218_1574 = find_super_class_method_167___object((object_t) (obj1488_1563), object__struct_env_210___object, sized_funcall_46_inline_size);
	       if (PROCEDUREP(next_method1667_218_1574))
		 {
		    res1489_1566 = PROCEDURE_ENTRY(next_method1667_218_1574) (next_method1667_218_1574, (obj_t) (obj1488_1563), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1667_218_1574);
		    res1489_1566 = object__struct_50___object((object_t) (obj1488_1563));
		 }
	    }
	    {
	       obj_t aux1490_1567;
	       {
		  obj_t aux_2882;
		  aux_2882 = CNST_TABLE_REF(((long) 2));
		  aux1490_1567 = make_struct(aux_2882, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2885;
		  {
		     long aux_2886;
		     {
			obj_t aux_2887;
			{
			   object_t aux_2888;
			   aux_2888 = (object_t) (obj1488_1563);
			   aux_2887 = OBJECT_WIDENING(aux_2888);
			}
			aux_2886 = (((sized_funcall_46_t) CREF(aux_2887))->size);
		     }
		     aux_2885 = BINT(aux_2886);
		  }
		  STRUCT_SET(aux1490_1567, ((long) 0), aux_2885);
	       }
	       STRUCT_SET(res1489_1566, ((long) 0), aux1490_1567);
	       {
		  obj_t aux_2895;
		  aux_2895 = STRUCT_KEY(res1489_1566);
		  STRUCT_KEY_SET(aux1490_1567, aux_2895);
	       }
	       {
		  obj_t aux_2898;
		  aux_2898 = CNST_TABLE_REF(((long) 2));
		  STRUCT_KEY_SET(res1489_1566, aux_2898);
	       }
	       return res1489_1566;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-pragma */ obj_t 
struct_object__object_sized_pragma_4_inline_size(obj_t env_2499, obj_t o_2500, obj_t s_2501)
{
   {
      sized_pragma_213_t o_1551;
      obj_t s_1552;
      {
	 sized_pragma_213_t aux_2902;
	 o_1551 = (sized_pragma_213_t) (o_2500);
	 s_1552 = s_2501;
	 {
	    {
	       obj_t old1507_1555;
	       obj_t aux1508_1556;
	       {
		  obj_t next_method1666_102_1561;
		  next_method1666_102_1561 = find_super_class_method_167___object((object_t) (o_1551), struct_object__object_env_209___object, sized_pragma_213_inline_size);
		  if (PROCEDUREP(next_method1666_102_1561))
		    {
		       old1507_1555 = PROCEDURE_ENTRY(next_method1666_102_1561) (next_method1666_102_1561, (obj_t) (o_1551), s_1552, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1666_102_1561);
		       {
			  object_t aux_2911;
			  aux_2911 = struct_object__object_93___object((object_t) (o_1551), s_1552);
			  old1507_1555 = (obj_t) (aux_2911);
		       }
		    }
	       }
	       aux1508_1556 = STRUCT_REF(s_1552, ((long) 0));
	       {
		  sized_pragma_213_t new1509_1557;
		  new1509_1557 = ((sized_pragma_213_t) (old1507_1555));
		  {
		     long arg1911_1558;
		     arg1911_1558 = class_num_218___object(sized_pragma_213_inline_size);
		     {
			obj_t obj_2153;
			obj_2153 = (obj_t) (new1509_1557);
			(((obj_t) CREF(obj_2153))->header = MAKE_HEADER(arg1911_1558, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_pragma_213_t arg1912_1559;
		     {
			sized_pragma_213_t res2124_2160;
			{
			   long size_2157;
			   {
			      obj_t aux_2920;
			      aux_2920 = STRUCT_REF(aux1508_1556, ((long) 0));
			      size_2157 = (long) CINT(aux_2920);
			   }
			   {
			      sized_pragma_213_t new1494_2158;
			      new1494_2158 = ((sized_pragma_213_t) BREF(GC_MALLOC(sizeof(struct sized_pragma_213))));
			      ((((sized_pragma_213_t) CREF(new1494_2158))->size) = ((long) size_2157), BUNSPEC);
			      res2124_2160 = new1494_2158;
			   }
			}
			arg1912_1559 = res2124_2160;
		     }
		     {
			obj_t aux_2927;
			object_t aux_2925;
			aux_2927 = (obj_t) (arg1912_1559);
			aux_2925 = (object_t) (new1509_1557);
			OBJECT_WIDENING_SET(aux_2925, aux_2927);
		     }
		  }
		  aux_2902 = new1509_1557;
	       }
	    }
	 }
	 return (obj_t) (aux_2902);
      }
   }
}


/* object->struct-sized-pragma */ obj_t 
object__struct_sized_pragma_80_inline_size(obj_t env_2502, obj_t obj1504_2503)
{
   {
      sized_pragma_213_t obj1504_1538;
      obj1504_1538 = (sized_pragma_213_t) (obj1504_2503);
      {
	 {
	    obj_t res1505_1541;
	    {
	       obj_t next_method1665_240_1549;
	       next_method1665_240_1549 = find_super_class_method_167___object((object_t) (obj1504_1538), object__struct_env_210___object, sized_pragma_213_inline_size);
	       if (PROCEDUREP(next_method1665_240_1549))
		 {
		    res1505_1541 = PROCEDURE_ENTRY(next_method1665_240_1549) (next_method1665_240_1549, (obj_t) (obj1504_1538), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1665_240_1549);
		    res1505_1541 = object__struct_50___object((object_t) (obj1504_1538));
		 }
	    }
	    {
	       obj_t aux1506_1542;
	       {
		  obj_t aux_2942;
		  aux_2942 = CNST_TABLE_REF(((long) 3));
		  aux1506_1542 = make_struct(aux_2942, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2945;
		  {
		     long aux_2946;
		     {
			obj_t aux_2947;
			{
			   object_t aux_2948;
			   aux_2948 = (object_t) (obj1504_1538);
			   aux_2947 = OBJECT_WIDENING(aux_2948);
			}
			aux_2946 = (((sized_pragma_213_t) CREF(aux_2947))->size);
		     }
		     aux_2945 = BINT(aux_2946);
		  }
		  STRUCT_SET(aux1506_1542, ((long) 0), aux_2945);
	       }
	       STRUCT_SET(res1505_1541, ((long) 0), aux1506_1542);
	       {
		  obj_t aux_2955;
		  aux_2955 = STRUCT_KEY(res1505_1541);
		  STRUCT_KEY_SET(aux1506_1542, aux_2955);
	       }
	       {
		  obj_t aux_2958;
		  aux_2958 = CNST_TABLE_REF(((long) 3));
		  STRUCT_KEY_SET(res1505_1541, aux_2958);
	       }
	       return res1505_1541;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-conditional */ obj_t 
struct_object__object_sized_conditional_125_inline_size(obj_t env_2504, obj_t o_2505, obj_t s_2506)
{
   {
      sized_conditional_152_t o_1526;
      obj_t s_1527;
      {
	 sized_conditional_152_t aux_2962;
	 o_1526 = (sized_conditional_152_t) (o_2505);
	 s_1527 = s_2506;
	 {
	    {
	       obj_t old1525_1530;
	       obj_t aux1526_1531;
	       {
		  obj_t next_method1664_255_1536;
		  next_method1664_255_1536 = find_super_class_method_167___object((object_t) (o_1526), struct_object__object_env_209___object, sized_conditional_152_inline_size);
		  if (PROCEDUREP(next_method1664_255_1536))
		    {
		       old1525_1530 = PROCEDURE_ENTRY(next_method1664_255_1536) (next_method1664_255_1536, (obj_t) (o_1526), s_1527, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1664_255_1536);
		       {
			  object_t aux_2971;
			  aux_2971 = struct_object__object_93___object((object_t) (o_1526), s_1527);
			  old1525_1530 = (obj_t) (aux_2971);
		       }
		    }
	       }
	       aux1526_1531 = STRUCT_REF(s_1527, ((long) 0));
	       {
		  sized_conditional_152_t new1527_1532;
		  new1527_1532 = ((sized_conditional_152_t) (old1525_1530));
		  {
		     long arg1898_1533;
		     arg1898_1533 = class_num_218___object(sized_conditional_152_inline_size);
		     {
			obj_t obj_2124;
			obj_2124 = (obj_t) (new1527_1532);
			(((obj_t) CREF(obj_2124))->header = MAKE_HEADER(arg1898_1533, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_conditional_152_t arg1899_1534;
		     {
			sized_conditional_152_t res2123_2131;
			{
			   long size_2128;
			   {
			      obj_t aux_2980;
			      aux_2980 = STRUCT_REF(aux1526_1531, ((long) 0));
			      size_2128 = (long) CINT(aux_2980);
			   }
			   {
			      sized_conditional_152_t new1510_2129;
			      new1510_2129 = ((sized_conditional_152_t) BREF(GC_MALLOC(sizeof(struct sized_conditional_152))));
			      ((((sized_conditional_152_t) CREF(new1510_2129))->size) = ((long) size_2128), BUNSPEC);
			      res2123_2131 = new1510_2129;
			   }
			}
			arg1899_1534 = res2123_2131;
		     }
		     {
			obj_t aux_2987;
			object_t aux_2985;
			aux_2987 = (obj_t) (arg1899_1534);
			aux_2985 = (object_t) (new1527_1532);
			OBJECT_WIDENING_SET(aux_2985, aux_2987);
		     }
		  }
		  aux_2962 = new1527_1532;
	       }
	    }
	 }
	 return (obj_t) (aux_2962);
      }
   }
}


/* object->struct-sized-conditional */ obj_t 
object__struct_sized_conditional_185_inline_size(obj_t env_2507, obj_t obj1522_2508)
{
   {
      sized_conditional_152_t obj1522_1513;
      obj1522_1513 = (sized_conditional_152_t) (obj1522_2508);
      {
	 {
	    obj_t res1523_1516;
	    {
	       obj_t next_method1663_106_1524;
	       next_method1663_106_1524 = find_super_class_method_167___object((object_t) (obj1522_1513), object__struct_env_210___object, sized_conditional_152_inline_size);
	       if (PROCEDUREP(next_method1663_106_1524))
		 {
		    res1523_1516 = PROCEDURE_ENTRY(next_method1663_106_1524) (next_method1663_106_1524, (obj_t) (obj1522_1513), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1663_106_1524);
		    res1523_1516 = object__struct_50___object((object_t) (obj1522_1513));
		 }
	    }
	    {
	       obj_t aux1524_1517;
	       {
		  obj_t aux_3002;
		  aux_3002 = CNST_TABLE_REF(((long) 4));
		  aux1524_1517 = make_struct(aux_3002, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_3005;
		  {
		     long aux_3006;
		     {
			obj_t aux_3007;
			{
			   object_t aux_3008;
			   aux_3008 = (object_t) (obj1522_1513);
			   aux_3007 = OBJECT_WIDENING(aux_3008);
			}
			aux_3006 = (((sized_conditional_152_t) CREF(aux_3007))->size);
		     }
		     aux_3005 = BINT(aux_3006);
		  }
		  STRUCT_SET(aux1524_1517, ((long) 0), aux_3005);
	       }
	       STRUCT_SET(res1523_1516, ((long) 0), aux1524_1517);
	       {
		  obj_t aux_3015;
		  aux_3015 = STRUCT_KEY(res1523_1516);
		  STRUCT_KEY_SET(aux1524_1517, aux_3015);
	       }
	       {
		  obj_t aux_3018;
		  aux_3018 = CNST_TABLE_REF(((long) 4));
		  STRUCT_KEY_SET(res1523_1516, aux_3018);
	       }
	       return res1523_1516;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-fail */ obj_t 
struct_object__object_sized_fail_89_inline_size(obj_t env_2509, obj_t o_2510, obj_t s_2511)
{
   {
      sized_fail_63_t o_1501;
      obj_t s_1502;
      {
	 sized_fail_63_t aux_3022;
	 o_1501 = (sized_fail_63_t) (o_2510);
	 s_1502 = s_2511;
	 {
	    {
	       obj_t old1541_1505;
	       obj_t aux1542_1506;
	       {
		  obj_t next_method1644_171_1511;
		  next_method1644_171_1511 = find_super_class_method_167___object((object_t) (o_1501), struct_object__object_env_209___object, sized_fail_63_inline_size);
		  if (PROCEDUREP(next_method1644_171_1511))
		    {
		       old1541_1505 = PROCEDURE_ENTRY(next_method1644_171_1511) (next_method1644_171_1511, (obj_t) (o_1501), s_1502, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1644_171_1511);
		       {
			  object_t aux_3031;
			  aux_3031 = struct_object__object_93___object((object_t) (o_1501), s_1502);
			  old1541_1505 = (obj_t) (aux_3031);
		       }
		    }
	       }
	       aux1542_1506 = STRUCT_REF(s_1502, ((long) 0));
	       {
		  sized_fail_63_t new1543_1507;
		  new1543_1507 = ((sized_fail_63_t) (old1541_1505));
		  {
		     long arg1886_1508;
		     arg1886_1508 = class_num_218___object(sized_fail_63_inline_size);
		     {
			obj_t obj_2095;
			obj_2095 = (obj_t) (new1543_1507);
			(((obj_t) CREF(obj_2095))->header = MAKE_HEADER(arg1886_1508, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_fail_63_t arg1887_1509;
		     {
			sized_fail_63_t res2122_2102;
			{
			   long size_2099;
			   {
			      obj_t aux_3040;
			      aux_3040 = STRUCT_REF(aux1542_1506, ((long) 0));
			      size_2099 = (long) CINT(aux_3040);
			   }
			   {
			      sized_fail_63_t new1528_2100;
			      new1528_2100 = ((sized_fail_63_t) BREF(GC_MALLOC(sizeof(struct sized_fail_63))));
			      ((((sized_fail_63_t) CREF(new1528_2100))->size) = ((long) size_2099), BUNSPEC);
			      res2122_2102 = new1528_2100;
			   }
			}
			arg1887_1509 = res2122_2102;
		     }
		     {
			obj_t aux_3047;
			object_t aux_3045;
			aux_3047 = (obj_t) (arg1887_1509);
			aux_3045 = (object_t) (new1543_1507);
			OBJECT_WIDENING_SET(aux_3045, aux_3047);
		     }
		  }
		  aux_3022 = new1543_1507;
	       }
	    }
	 }
	 return (obj_t) (aux_3022);
      }
   }
}


/* object->struct-sized-fail */ obj_t 
object__struct_sized_fail_166_inline_size(obj_t env_2512, obj_t obj1538_2513)
{
   {
      sized_fail_63_t obj1538_1488;
      obj1538_1488 = (sized_fail_63_t) (obj1538_2513);
      {
	 {
	    obj_t res1539_1491;
	    {
	       obj_t next_method1643_101_1499;
	       next_method1643_101_1499 = find_super_class_method_167___object((object_t) (obj1538_1488), object__struct_env_210___object, sized_fail_63_inline_size);
	       if (PROCEDUREP(next_method1643_101_1499))
		 {
		    res1539_1491 = PROCEDURE_ENTRY(next_method1643_101_1499) (next_method1643_101_1499, (obj_t) (obj1538_1488), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1643_101_1499);
		    res1539_1491 = object__struct_50___object((object_t) (obj1538_1488));
		 }
	    }
	    {
	       obj_t aux1540_1492;
	       {
		  obj_t aux_3062;
		  aux_3062 = CNST_TABLE_REF(((long) 5));
		  aux1540_1492 = make_struct(aux_3062, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_3065;
		  {
		     long aux_3066;
		     {
			obj_t aux_3067;
			{
			   object_t aux_3068;
			   aux_3068 = (object_t) (obj1538_1488);
			   aux_3067 = OBJECT_WIDENING(aux_3068);
			}
			aux_3066 = (((sized_fail_63_t) CREF(aux_3067))->size);
		     }
		     aux_3065 = BINT(aux_3066);
		  }
		  STRUCT_SET(aux1540_1492, ((long) 0), aux_3065);
	       }
	       STRUCT_SET(res1539_1491, ((long) 0), aux1540_1492);
	       {
		  obj_t aux_3075;
		  aux_3075 = STRUCT_KEY(res1539_1491);
		  STRUCT_KEY_SET(aux1540_1492, aux_3075);
	       }
	       {
		  obj_t aux_3078;
		  aux_3078 = CNST_TABLE_REF(((long) 5));
		  STRUCT_KEY_SET(res1539_1491, aux_3078);
	       }
	       return res1539_1491;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-select */ obj_t 
struct_object__object_sized_select_92_inline_size(obj_t env_2514, obj_t o_2515, obj_t s_2516)
{
   {
      sized_select_166_t o_1476;
      obj_t s_1477;
      {
	 sized_select_166_t aux_3082;
	 o_1476 = (sized_select_166_t) (o_2515);
	 s_1477 = s_2516;
	 {
	    {
	       obj_t old1558_1480;
	       obj_t aux1559_1481;
	       {
		  obj_t next_method1642_242_1486;
		  next_method1642_242_1486 = find_super_class_method_167___object((object_t) (o_1476), struct_object__object_env_209___object, sized_select_166_inline_size);
		  if (PROCEDUREP(next_method1642_242_1486))
		    {
		       old1558_1480 = PROCEDURE_ENTRY(next_method1642_242_1486) (next_method1642_242_1486, (obj_t) (o_1476), s_1477, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1642_242_1486);
		       {
			  object_t aux_3091;
			  aux_3091 = struct_object__object_93___object((object_t) (o_1476), s_1477);
			  old1558_1480 = (obj_t) (aux_3091);
		       }
		    }
	       }
	       aux1559_1481 = STRUCT_REF(s_1477, ((long) 0));
	       {
		  sized_select_166_t new1560_1482;
		  new1560_1482 = ((sized_select_166_t) (old1558_1480));
		  {
		     long arg1874_1483;
		     arg1874_1483 = class_num_218___object(sized_select_166_inline_size);
		     {
			obj_t obj_2066;
			obj_2066 = (obj_t) (new1560_1482);
			(((obj_t) CREF(obj_2066))->header = MAKE_HEADER(arg1874_1483, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_select_166_t arg1875_1484;
		     {
			sized_select_166_t res2121_2073;
			{
			   long size_2070;
			   {
			      obj_t aux_3100;
			      aux_3100 = STRUCT_REF(aux1559_1481, ((long) 0));
			      size_2070 = (long) CINT(aux_3100);
			   }
			   {
			      sized_select_166_t new1544_2071;
			      new1544_2071 = ((sized_select_166_t) BREF(GC_MALLOC(sizeof(struct sized_select_166))));
			      ((((sized_select_166_t) CREF(new1544_2071))->size) = ((long) size_2070), BUNSPEC);
			      res2121_2073 = new1544_2071;
			   }
			}
			arg1875_1484 = res2121_2073;
		     }
		     {
			obj_t aux_3107;
			object_t aux_3105;
			aux_3107 = (obj_t) (arg1875_1484);
			aux_3105 = (object_t) (new1560_1482);
			OBJECT_WIDENING_SET(aux_3105, aux_3107);
		     }
		  }
		  aux_3082 = new1560_1482;
	       }
	    }
	 }
	 return (obj_t) (aux_3082);
      }
   }
}


/* object->struct-sized-select */ obj_t 
object__struct_sized_select_105_inline_size(obj_t env_2517, obj_t obj1555_2518)
{
   {
      sized_select_166_t obj1555_1463;
      obj1555_1463 = (sized_select_166_t) (obj1555_2518);
      {
	 {
	    obj_t res1556_1466;
	    {
	       obj_t next_method1641_193_1474;
	       next_method1641_193_1474 = find_super_class_method_167___object((object_t) (obj1555_1463), object__struct_env_210___object, sized_select_166_inline_size);
	       if (PROCEDUREP(next_method1641_193_1474))
		 {
		    res1556_1466 = PROCEDURE_ENTRY(next_method1641_193_1474) (next_method1641_193_1474, (obj_t) (obj1555_1463), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1641_193_1474);
		    res1556_1466 = object__struct_50___object((object_t) (obj1555_1463));
		 }
	    }
	    {
	       obj_t aux1557_1467;
	       {
		  obj_t aux_3122;
		  aux_3122 = CNST_TABLE_REF(((long) 6));
		  aux1557_1467 = make_struct(aux_3122, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_3125;
		  {
		     long aux_3126;
		     {
			obj_t aux_3127;
			{
			   object_t aux_3128;
			   aux_3128 = (object_t) (obj1555_1463);
			   aux_3127 = OBJECT_WIDENING(aux_3128);
			}
			aux_3126 = (((sized_select_166_t) CREF(aux_3127))->size);
		     }
		     aux_3125 = BINT(aux_3126);
		  }
		  STRUCT_SET(aux1557_1467, ((long) 0), aux_3125);
	       }
	       STRUCT_SET(res1556_1466, ((long) 0), aux1557_1467);
	       {
		  obj_t aux_3135;
		  aux_3135 = STRUCT_KEY(res1556_1466);
		  STRUCT_KEY_SET(aux1557_1467, aux_3135);
	       }
	       {
		  obj_t aux_3138;
		  aux_3138 = CNST_TABLE_REF(((long) 6));
		  STRUCT_KEY_SET(res1556_1466, aux_3138);
	       }
	       return res1556_1466;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-let-fun */ obj_t 
struct_object__object_sized_let_fun_64_inline_size(obj_t env_2519, obj_t o_2520, obj_t s_2521)
{
   {
      sized_let_fun_188_t o_1451;
      obj_t s_1452;
      {
	 sized_let_fun_188_t aux_3142;
	 o_1451 = (sized_let_fun_188_t) (o_2520);
	 s_1452 = s_2521;
	 {
	    {
	       obj_t old1575_1455;
	       obj_t aux1576_1456;
	       {
		  obj_t next_method1640_239_1461;
		  next_method1640_239_1461 = find_super_class_method_167___object((object_t) (o_1451), struct_object__object_env_209___object, sized_let_fun_188_inline_size);
		  if (PROCEDUREP(next_method1640_239_1461))
		    {
		       old1575_1455 = PROCEDURE_ENTRY(next_method1640_239_1461) (next_method1640_239_1461, (obj_t) (o_1451), s_1452, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1640_239_1461);
		       {
			  object_t aux_3151;
			  aux_3151 = struct_object__object_93___object((object_t) (o_1451), s_1452);
			  old1575_1455 = (obj_t) (aux_3151);
		       }
		    }
	       }
	       aux1576_1456 = STRUCT_REF(s_1452, ((long) 0));
	       {
		  sized_let_fun_188_t new1577_1457;
		  new1577_1457 = ((sized_let_fun_188_t) (old1575_1455));
		  {
		     long arg1861_1458;
		     arg1861_1458 = class_num_218___object(sized_let_fun_188_inline_size);
		     {
			obj_t obj_2037;
			obj_2037 = (obj_t) (new1577_1457);
			(((obj_t) CREF(obj_2037))->header = MAKE_HEADER(arg1861_1458, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_let_fun_188_t arg1862_1459;
		     {
			sized_let_fun_188_t res2120_2044;
			{
			   long size_2041;
			   {
			      obj_t aux_3160;
			      aux_3160 = STRUCT_REF(aux1576_1456, ((long) 0));
			      size_2041 = (long) CINT(aux_3160);
			   }
			   {
			      sized_let_fun_188_t new1561_2042;
			      new1561_2042 = ((sized_let_fun_188_t) BREF(GC_MALLOC(sizeof(struct sized_let_fun_188))));
			      ((((sized_let_fun_188_t) CREF(new1561_2042))->size) = ((long) size_2041), BUNSPEC);
			      res2120_2044 = new1561_2042;
			   }
			}
			arg1862_1459 = res2120_2044;
		     }
		     {
			obj_t aux_3167;
			object_t aux_3165;
			aux_3167 = (obj_t) (arg1862_1459);
			aux_3165 = (object_t) (new1577_1457);
			OBJECT_WIDENING_SET(aux_3165, aux_3167);
		     }
		  }
		  aux_3142 = new1577_1457;
	       }
	    }
	 }
	 return (obj_t) (aux_3142);
      }
   }
}


/* object->struct-sized-let-fun */ obj_t 
object__struct_sized_let_fun_219_inline_size(obj_t env_2522, obj_t obj1572_2523)
{
   {
      sized_let_fun_188_t obj1572_1438;
      obj1572_1438 = (sized_let_fun_188_t) (obj1572_2523);
      {
	 {
	    obj_t res1573_1441;
	    {
	       obj_t next_method1639_220_1449;
	       next_method1639_220_1449 = find_super_class_method_167___object((object_t) (obj1572_1438), object__struct_env_210___object, sized_let_fun_188_inline_size);
	       if (PROCEDUREP(next_method1639_220_1449))
		 {
		    res1573_1441 = PROCEDURE_ENTRY(next_method1639_220_1449) (next_method1639_220_1449, (obj_t) (obj1572_1438), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1639_220_1449);
		    res1573_1441 = object__struct_50___object((object_t) (obj1572_1438));
		 }
	    }
	    {
	       obj_t aux1574_1442;
	       {
		  obj_t aux_3182;
		  aux_3182 = CNST_TABLE_REF(((long) 7));
		  aux1574_1442 = make_struct(aux_3182, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_3185;
		  {
		     long aux_3186;
		     {
			obj_t aux_3187;
			{
			   object_t aux_3188;
			   aux_3188 = (object_t) (obj1572_1438);
			   aux_3187 = OBJECT_WIDENING(aux_3188);
			}
			aux_3186 = (((sized_let_fun_188_t) CREF(aux_3187))->size);
		     }
		     aux_3185 = BINT(aux_3186);
		  }
		  STRUCT_SET(aux1574_1442, ((long) 0), aux_3185);
	       }
	       STRUCT_SET(res1573_1441, ((long) 0), aux1574_1442);
	       {
		  obj_t aux_3195;
		  aux_3195 = STRUCT_KEY(res1573_1441);
		  STRUCT_KEY_SET(aux1574_1442, aux_3195);
	       }
	       {
		  obj_t aux_3198;
		  aux_3198 = CNST_TABLE_REF(((long) 7));
		  STRUCT_KEY_SET(res1573_1441, aux_3198);
	       }
	       return res1573_1441;
	    }
	 }
      }
   }
}


/* struct+object->object-sized-let-var */ obj_t 
struct_object__object_sized_let_var_128_inline_size(obj_t env_2524, obj_t o_2525, obj_t s_2526)
{
   {
      sized_let_var_54_t o_1426;
      obj_t s_1427;
      {
	 sized_let_var_54_t aux_3202;
	 o_1426 = (sized_let_var_54_t) (o_2525);
	 s_1427 = s_2526;
	 {
	    {
	       obj_t old1593_1430;
	       obj_t aux1594_1431;
	       {
		  obj_t next_method1638_94_1436;
		  next_method1638_94_1436 = find_super_class_method_167___object((object_t) (o_1426), struct_object__object_env_209___object, sized_let_var_54_inline_size);
		  if (PROCEDUREP(next_method1638_94_1436))
		    {
		       old1593_1430 = PROCEDURE_ENTRY(next_method1638_94_1436) (next_method1638_94_1436, (obj_t) (o_1426), s_1427, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1638_94_1436);
		       {
			  object_t aux_3211;
			  aux_3211 = struct_object__object_93___object((object_t) (o_1426), s_1427);
			  old1593_1430 = (obj_t) (aux_3211);
		       }
		    }
	       }
	       aux1594_1431 = STRUCT_REF(s_1427, ((long) 0));
	       {
		  sized_let_var_54_t new1595_1432;
		  new1595_1432 = ((sized_let_var_54_t) (old1593_1430));
		  {
		     long arg1847_1433;
		     arg1847_1433 = class_num_218___object(sized_let_var_54_inline_size);
		     {
			obj_t obj_2008;
			obj_2008 = (obj_t) (new1595_1432);
			(((obj_t) CREF(obj_2008))->header = MAKE_HEADER(arg1847_1433, 0), BUNSPEC);
		     }
		  }
		  {
		     sized_let_var_54_t arg1848_1434;
		     {
			sized_let_var_54_t res2119_2015;
			{
			   long size_2012;
			   {
			      obj_t aux_3220;
			      aux_3220 = STRUCT_REF(aux1594_1431, ((long) 0));
			      size_2012 = (long) CINT(aux_3220);
			   }
			   {
			      sized_let_var_54_t new1578_2013;
			      new1578_2013 = ((sized_let_var_54_t) BREF(GC_MALLOC(sizeof(struct sized_let_var_54))));
			      ((((sized_let_var_54_t) CREF(new1578_2013))->size) = ((long) size_2012), BUNSPEC);
			      res2119_2015 = new1578_2013;
			   }
			}
			arg1848_1434 = res2119_2015;
		     }
		     {
			obj_t aux_3227;
			object_t aux_3225;
			aux_3227 = (obj_t) (arg1848_1434);
			aux_3225 = (object_t) (new1595_1432);
			OBJECT_WIDENING_SET(aux_3225, aux_3227);
		     }
		  }
		  aux_3202 = new1595_1432;
	       }
	    }
	 }
	 return (obj_t) (aux_3202);
      }
   }
}


/* object->struct-sized-let-var */ obj_t 
object__struct_sized_let_var_36_inline_size(obj_t env_2527, obj_t obj1590_2528)
{
   {
      sized_let_var_54_t obj1590_1413;
      obj1590_1413 = (sized_let_var_54_t) (obj1590_2528);
      {
	 {
	    obj_t res1591_1416;
	    {
	       obj_t next_method1637_32_1424;
	       next_method1637_32_1424 = find_super_class_method_167___object((object_t) (obj1590_1413), object__struct_env_210___object, sized_let_var_54_inline_size);
	       if (PROCEDUREP(next_method1637_32_1424))
		 {
		    res1591_1416 = PROCEDURE_ENTRY(next_method1637_32_1424) (next_method1637_32_1424, (obj_t) (obj1590_1413), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1637_32_1424);
		    res1591_1416 = object__struct_50___object((object_t) (obj1590_1413));
		 }
	    }
	    {
	       obj_t aux1592_1417;
	       {
		  obj_t aux_3242;
		  aux_3242 = CNST_TABLE_REF(((long) 8));
		  aux1592_1417 = make_struct(aux_3242, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_3245;
		  {
		     long aux_3246;
		     {
			obj_t aux_3247;
			{
			   object_t aux_3248;
			   aux_3248 = (object_t) (obj1590_1413);
			   aux_3247 = OBJECT_WIDENING(aux_3248);
			}
			aux_3246 = (((sized_let_var_54_t) CREF(aux_3247))->size);
		     }
		     aux_3245 = BINT(aux_3246);
		  }
		  STRUCT_SET(aux1592_1417, ((long) 0), aux_3245);
	       }
	       STRUCT_SET(res1591_1416, ((long) 0), aux1592_1417);
	       {
		  obj_t aux_3255;
		  aux_3255 = STRUCT_KEY(res1591_1416);
		  STRUCT_KEY_SET(aux1592_1417, aux_3255);
	       }
	       {
		  obj_t aux_3258;
		  aux_3258 = CNST_TABLE_REF(((long) 8));
		  STRUCT_KEY_SET(res1591_1416, aux_3258);
	       }
	       return res1591_1416;
	    }
	 }
      }
   }
}


/* node-size */ long 
node_size_119_inline_size(node_t node_1)
{
   {
      obj_t method1953_1644;
      obj_t class1958_1645;
      {
	 obj_t arg1961_1642;
	 obj_t arg1962_1643;
	 {
	    object_t obj_2250;
	    obj_2250 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_2251;
	       pre_method_105_2251 = PROCEDURE_REF(node_size_env_51_inline_size, ((long) 2));
	       if (INTEGERP(pre_method_105_2251))
		 {
		    PROCEDURE_SET(node_size_env_51_inline_size, ((long) 2), BUNSPEC);
		    arg1961_1642 = pre_method_105_2251;
		 }
	       else
		 {
		    long obj_class_num_177_2256;
		    obj_class_num_177_2256 = TYPE(obj_2250);
		    {
		       obj_t arg1177_2257;
		       arg1177_2257 = PROCEDURE_REF(node_size_env_51_inline_size, ((long) 1));
		       {
			  long arg1178_2261;
			  {
			     long arg1179_2262;
			     arg1179_2262 = OBJECT_TYPE;
			     arg1178_2261 = (obj_class_num_177_2256 - arg1179_2262);
			  }
			  arg1961_1642 = VECTOR_REF(arg1177_2257, arg1178_2261);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2267;
	    object_2267 = (object_t) (node_1);
	    {
	       long arg1180_2268;
	       {
		  long arg1181_2269;
		  long arg1182_2270;
		  arg1181_2269 = TYPE(object_2267);
		  arg1182_2270 = OBJECT_TYPE;
		  arg1180_2268 = (arg1181_2269 - arg1182_2270);
	       }
	       {
		  obj_t vector_2274;
		  vector_2274 = _classes__134___object;
		  arg1962_1643 = VECTOR_REF(vector_2274, arg1180_2268);
	       }
	    }
	 }
	 {
	    obj_t aux_3277;
	    method1953_1644 = arg1961_1642;
	    class1958_1645 = arg1962_1643;
	    {
	       if (INTEGERP(method1953_1644))
		 {
		    switch ((long) CINT(method1953_1644))
		      {
		      case ((long) 0):
			 aux_3277 = BINT(((long) 1));
			 break;
		      case ((long) 1):
			 aux_3277 = BINT(((long) 1));
			 break;
		      case ((long) 2):
			 aux_3277 = BINT(((long) 1));
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1654;
			    node_1654 = (sequence_t) (node_1);
			    {
			       obj_t nodes_1655;
			       long size_1656;
			       {
				  long aux_3284;
				  nodes_1655 = (((sequence_t) CREF(node_1654))->nodes);
				  size_1656 = ((long) 0);
				loop_1657:
				  if (NULLP(nodes_1655))
				    {
				       {
					  sized_sequence_48_t obj1596_1661;
					  obj1596_1661 = ((sized_sequence_48_t) (node_1654));
					  {
					     sized_sequence_48_t arg1970_1662;
					     {
						sized_sequence_48_t res2128_2281;
						{
						   sized_sequence_48_t new1444_2279;
						   new1444_2279 = ((sized_sequence_48_t) BREF(GC_MALLOC(sizeof(struct sized_sequence_48))));
						   ((((sized_sequence_48_t) CREF(new1444_2279))->size) = ((long) size_1656), BUNSPEC);
						   res2128_2281 = new1444_2279;
						}
						arg1970_1662 = res2128_2281;
					     }
					     {
						obj_t aux_3292;
						object_t aux_3290;
						aux_3292 = (obj_t) (arg1970_1662);
						aux_3290 = (object_t) (obj1596_1661);
						OBJECT_WIDENING_SET(aux_3290, aux_3292);
					     }
					  }
					  {
					     long arg1972_1664;
					     arg1972_1664 = class_num_218___object(sized_sequence_48_inline_size);
					     {
						obj_t obj_2282;
						obj_2282 = (obj_t) (obj1596_1661);
						(((obj_t) CREF(obj_2282))->header = MAKE_HEADER(arg1972_1664, 0), BUNSPEC);
					     }
					  }
					  obj1596_1661;
				       }
				       aux_3284 = size_1656;
				    }
				  else
				    {
				       obj_t arg1973_1665;
				       long arg1974_1666;
				       arg1973_1665 = CDR(nodes_1655);
				       {
					  long arg1975_1667;
					  {
					     node_t aux_3299;
					     {
						obj_t aux_3300;
						aux_3300 = CAR(nodes_1655);
						aux_3299 = (node_t) (aux_3300);
					     }
					     arg1975_1667 = node_size_119_inline_size(aux_3299);
					  }
					  arg1974_1666 = (size_1656 + arg1975_1667);
				       }
				       {
					  long size_3306;
					  obj_t nodes_3305;
					  nodes_3305 = arg1973_1665;
					  size_3306 = arg1974_1666;
					  size_1656 = size_3306;
					  nodes_1655 = nodes_3305;
					  goto loop_1657;
				       }
				    }
				  aux_3277 = BINT(aux_3284);
			       }
			    }
			 }
			 break;
		      case ((long) 4):
			 {
			    sized_sequence_48_t node_1669;
			    node_1669 = (sized_sequence_48_t) (node_1);
			    {
			       long aux_3310;
			       {
				  obj_t aux_3311;
				  {
				     object_t aux_3312;
				     aux_3312 = (object_t) (node_1669);
				     aux_3311 = OBJECT_WIDENING(aux_3312);
				  }
				  aux_3310 = (((sized_sequence_48_t) CREF(aux_3311))->size);
			       }
			       aux_3277 = BINT(aux_3310);
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    app_t node_1670;
			    node_1670 = (app_t) (node_1);
			    {
			       obj_t args_1671;
			       long size_1672;
			       {
				  obj_t arg1978_1674;
				  long arg1979_1675;
				  arg1978_1674 = (((app_t) CREF(node_1670))->args);
				  {
				     node_t aux_3319;
				     {
					var_t aux_3320;
					aux_3320 = (((app_t) CREF(node_1670))->fun);
					aux_3319 = (node_t) (aux_3320);
				     }
				     arg1979_1675 = node_size_119_inline_size(aux_3319);
				  }
				  {
				     long aux_3324;
				     args_1671 = arg1978_1674;
				     size_1672 = arg1979_1675;
				   loop_1673:
				     if (NULLP(args_1671))
				       {
					  {
					     sized_app_52_t obj1597_1678;
					     obj1597_1678 = ((sized_app_52_t) (node_1670));
					     {
						sized_app_52_t arg1982_1679;
						{
						   sized_app_52_t res2129_2295;
						   {
						      sized_app_52_t new1460_2293;
						      new1460_2293 = ((sized_app_52_t) BREF(GC_MALLOC(sizeof(struct sized_app_52))));
						      ((((sized_app_52_t) CREF(new1460_2293))->size) = ((long) size_1672), BUNSPEC);
						      res2129_2295 = new1460_2293;
						   }
						   arg1982_1679 = res2129_2295;
						}
						{
						   obj_t aux_3332;
						   object_t aux_3330;
						   aux_3332 = (obj_t) (arg1982_1679);
						   aux_3330 = (object_t) (obj1597_1678);
						   OBJECT_WIDENING_SET(aux_3330, aux_3332);
						}
					     }
					     {
						long arg1984_1681;
						arg1984_1681 = class_num_218___object(sized_app_52_inline_size);
						{
						   obj_t obj_2296;
						   obj_2296 = (obj_t) (obj1597_1678);
						   (((obj_t) CREF(obj_2296))->header = MAKE_HEADER(arg1984_1681, 0), BUNSPEC);
						}
					     }
					     obj1597_1678;
					  }
					  aux_3324 = size_1672;
				       }
				     else
				       {
					  obj_t arg1985_1682;
					  long arg1986_1683;
					  arg1985_1682 = CDR(args_1671);
					  {
					     long arg1987_1684;
					     {
						node_t aux_3339;
						{
						   obj_t aux_3340;
						   aux_3340 = CAR(args_1671);
						   aux_3339 = (node_t) (aux_3340);
						}
						arg1987_1684 = node_size_119_inline_size(aux_3339);
					     }
					     arg1986_1683 = (size_1672 + arg1987_1684);
					  }
					  {
					     long size_3346;
					     obj_t args_3345;
					     args_3345 = arg1985_1682;
					     size_3346 = arg1986_1683;
					     size_1672 = size_3346;
					     args_1671 = args_3345;
					     goto loop_1673;
					  }
				       }
				     aux_3277 = BINT(aux_3324);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    sized_app_52_t node_1686;
			    node_1686 = (sized_app_52_t) (node_1);
			    {
			       long aux_3349;
			       {
				  obj_t aux_3350;
				  {
				     object_t aux_3351;
				     aux_3351 = (object_t) (node_1686);
				     aux_3350 = OBJECT_WIDENING(aux_3351);
				  }
				  aux_3349 = (((sized_app_52_t) CREF(aux_3350))->size);
			       }
			       aux_3277 = BINT(aux_3349);
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    app_ly_162_t node_1687;
			    node_1687 = (app_ly_162_t) (node_1);
			    {
			       long arg1990_1689;
			       {
				  long arg1991_1690;
				  long arg1992_1691;
				  arg1991_1690 = node_size_119_inline_size((((app_ly_162_t) CREF(node_1687))->fun));
				  arg1992_1691 = node_size_119_inline_size((((app_ly_162_t) CREF(node_1687))->arg));
				  arg1990_1689 = (arg1991_1690 + arg1992_1691);
			       }
			       {
				  long aux_3362;
				  aux_3362 = (((long) 1) + arg1990_1689);
				  aux_3277 = BINT(aux_3362);
			       }
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    funcall_t node_1694;
			    node_1694 = (funcall_t) (node_1);
			    {
			       obj_t args_1695;
			       long size_1696;
			       {
				  obj_t arg1995_1698;
				  long arg1998_1699;
				  arg1995_1698 = (((funcall_t) CREF(node_1694))->args);
				  arg1998_1699 = node_size_119_inline_size((((funcall_t) CREF(node_1694))->fun));
				  {
				     long aux_3369;
				     args_1695 = arg1995_1698;
				     size_1696 = arg1998_1699;
				   loop_1697:
				     if (NULLP(args_1695))
				       {
					  {
					     sized_funcall_46_t obj1598_1702;
					     obj1598_1702 = ((sized_funcall_46_t) (node_1694));
					     {
						sized_funcall_46_t arg2002_1703;
						{
						   sized_funcall_46_t res2130_2315;
						   {
						      sized_funcall_46_t new1478_2313;
						      new1478_2313 = ((sized_funcall_46_t) BREF(GC_MALLOC(sizeof(struct sized_funcall_46))));
						      ((((sized_funcall_46_t) CREF(new1478_2313))->size) = ((long) size_1696), BUNSPEC);
						      res2130_2315 = new1478_2313;
						   }
						   arg2002_1703 = res2130_2315;
						}
						{
						   obj_t aux_3377;
						   object_t aux_3375;
						   aux_3377 = (obj_t) (arg2002_1703);
						   aux_3375 = (object_t) (obj1598_1702);
						   OBJECT_WIDENING_SET(aux_3375, aux_3377);
						}
					     }
					     {
						long arg2004_1705;
						arg2004_1705 = class_num_218___object(sized_funcall_46_inline_size);
						{
						   obj_t obj_2316;
						   obj_2316 = (obj_t) (obj1598_1702);
						   (((obj_t) CREF(obj_2316))->header = MAKE_HEADER(arg2004_1705, 0), BUNSPEC);
						}
					     }
					     obj1598_1702;
					  }
					  aux_3369 = size_1696;
				       }
				     else
				       {
					  obj_t arg2006_1706;
					  long arg2008_1707;
					  arg2006_1706 = CDR(args_1695);
					  {
					     long arg2010_1708;
					     {
						node_t aux_3384;
						{
						   obj_t aux_3385;
						   aux_3385 = CAR(args_1695);
						   aux_3384 = (node_t) (aux_3385);
						}
						arg2010_1708 = node_size_119_inline_size(aux_3384);
					     }
					     arg2008_1707 = (size_1696 + arg2010_1708);
					  }
					  {
					     long size_3391;
					     obj_t args_3390;
					     args_3390 = arg2006_1706;
					     size_3391 = arg2008_1707;
					     size_1696 = size_3391;
					     args_1695 = args_3390;
					     goto loop_1697;
					  }
				       }
				     aux_3277 = BINT(aux_3369);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 9):
			 {
			    sized_funcall_46_t node_1710;
			    node_1710 = (sized_funcall_46_t) (node_1);
			    {
			       long aux_3394;
			       {
				  obj_t aux_3395;
				  {
				     object_t aux_3396;
				     aux_3396 = (object_t) (node_1710);
				     aux_3395 = OBJECT_WIDENING(aux_3396);
				  }
				  aux_3394 = (((sized_funcall_46_t) CREF(aux_3395))->size);
			       }
			       aux_3277 = BINT(aux_3394);
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    sized_pragma_213_t node_1711;
			    node_1711 = (sized_pragma_213_t) (node_1);
			    {
			       long aux_3402;
			       {
				  obj_t aux_3403;
				  {
				     object_t aux_3404;
				     aux_3404 = (object_t) (node_1711);
				     aux_3403 = OBJECT_WIDENING(aux_3404);
				  }
				  aux_3402 = (((sized_pragma_213_t) CREF(aux_3403))->size);
			       }
			       aux_3277 = BINT(aux_3402);
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    cast_t node_1712;
			    node_1712 = (cast_t) (node_1);
			    {
			       long aux_3410;
			       aux_3410 = node_size_119_inline_size((((cast_t) CREF(node_1712))->arg));
			       aux_3277 = BINT(aux_3410);
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    pragma_t node_1715;
			    node_1715 = (pragma_t) (node_1);
			    {
			       obj_t args_1716;
			       long size_1717;
			       {
				  long aux_3415;
				  args_1716 = (((pragma_t) CREF(node_1715))->args);
				  size_1717 = ((long) 1);
				loop_1718:
				  if (NULLP(args_1716))
				    {
				       {
					  sized_pragma_213_t obj1600_1722;
					  obj1600_1722 = ((sized_pragma_213_t) (node_1715));
					  {
					     sized_pragma_213_t arg2016_1723;
					     {
						sized_pragma_213_t res2131_2330;
						{
						   sized_pragma_213_t new1494_2328;
						   new1494_2328 = ((sized_pragma_213_t) BREF(GC_MALLOC(sizeof(struct sized_pragma_213))));
						   ((((sized_pragma_213_t) CREF(new1494_2328))->size) = ((long) size_1717), BUNSPEC);
						   res2131_2330 = new1494_2328;
						}
						arg2016_1723 = res2131_2330;
					     }
					     {
						obj_t aux_3423;
						object_t aux_3421;
						aux_3423 = (obj_t) (arg2016_1723);
						aux_3421 = (object_t) (obj1600_1722);
						OBJECT_WIDENING_SET(aux_3421, aux_3423);
					     }
					  }
					  {
					     long arg2018_1725;
					     arg2018_1725 = class_num_218___object(sized_pragma_213_inline_size);
					     {
						obj_t obj_2331;
						obj_2331 = (obj_t) (obj1600_1722);
						(((obj_t) CREF(obj_2331))->header = MAKE_HEADER(arg2018_1725, 0), BUNSPEC);
					     }
					  }
					  obj1600_1722;
				       }
				       aux_3415 = size_1717;
				    }
				  else
				    {
				       obj_t arg2019_1726;
				       long arg2020_1727;
				       arg2019_1726 = CDR(args_1716);
				       {
					  long arg2021_1728;
					  {
					     node_t aux_3430;
					     {
						obj_t aux_3431;
						aux_3431 = CAR(args_1716);
						aux_3430 = (node_t) (aux_3431);
					     }
					     arg2021_1728 = node_size_119_inline_size(aux_3430);
					  }
					  arg2020_1727 = (size_1717 + arg2021_1728);
				       }
				       {
					  long size_3437;
					  obj_t args_3436;
					  args_3436 = arg2019_1726;
					  size_3437 = arg2020_1727;
					  size_1717 = size_3437;
					  args_1716 = args_3436;
					  goto loop_1718;
				       }
				    }
				  aux_3277 = BINT(aux_3415);
			       }
			    }
			 }
			 break;
		      case ((long) 13):
			 {
			    setq_t node_1730;
			    node_1730 = (setq_t) (node_1);
			    {
			       long arg2024_1732;
			       arg2024_1732 = node_size_119_inline_size((((setq_t) CREF(node_1730))->value));
			       {
				  long aux_3443;
				  aux_3443 = (((long) 2) + arg2024_1732);
				  aux_3277 = BINT(aux_3443);
			       }
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    conditional_t node_1734;
			    node_1734 = (conditional_t) (node_1);
			    {
			       long test_size_137_1735;
			       test_size_137_1735 = node_size_119_inline_size((((conditional_t) CREF(node_1734))->test));
			       {
				  long true_size_36_1736;
				  true_size_36_1736 = node_size_119_inline_size((((conditional_t) CREF(node_1734))->true));
				  {
				     long false_size_136_1737;
				     false_size_136_1737 = node_size_119_inline_size((((conditional_t) CREF(node_1734))->false));
				     {
					long size_1738;
					{
					   long aux_3453;
					   {
					      long aux_3454;
					      aux_3454 = (true_size_36_1736 + false_size_136_1737);
					      aux_3453 = (test_size_137_1735 + aux_3454);
					   }
					   size_1738 = (((long) 1) + aux_3453);
					}
					{
					   {
					      sized_conditional_152_t obj1601_1739;
					      obj1601_1739 = ((sized_conditional_152_t) (node_1734));
					      {
						 sized_conditional_152_t arg2027_1740;
						 {
						    sized_conditional_152_t res2132_2352;
						    {
						       sized_conditional_152_t new1510_2350;
						       new1510_2350 = ((sized_conditional_152_t) BREF(GC_MALLOC(sizeof(struct sized_conditional_152))));
						       ((((sized_conditional_152_t) CREF(new1510_2350))->size) = ((long) size_1738), BUNSPEC);
						       res2132_2352 = new1510_2350;
						    }
						    arg2027_1740 = res2132_2352;
						 }
						 {
						    obj_t aux_3463;
						    object_t aux_3461;
						    aux_3463 = (obj_t) (arg2027_1740);
						    aux_3461 = (object_t) (obj1601_1739);
						    OBJECT_WIDENING_SET(aux_3461, aux_3463);
						 }
					      }
					      {
						 long arg2029_1742;
						 arg2029_1742 = class_num_218___object(sized_conditional_152_inline_size);
						 {
						    obj_t obj_2353;
						    obj_2353 = (obj_t) (obj1601_1739);
						    (((obj_t) CREF(obj_2353))->header = MAKE_HEADER(arg2029_1742, 0), BUNSPEC);
						 }
					      }
					      obj1601_1739;
					   }
					   aux_3277 = BINT(size_1738);
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 15):
			 {
			    sized_conditional_152_t node_1749;
			    node_1749 = (sized_conditional_152_t) (node_1);
			    {
			       long aux_3471;
			       {
				  obj_t aux_3472;
				  {
				     object_t aux_3473;
				     aux_3473 = (object_t) (node_1749);
				     aux_3472 = OBJECT_WIDENING(aux_3473);
				  }
				  aux_3471 = (((sized_conditional_152_t) CREF(aux_3472))->size);
			       }
			       aux_3277 = BINT(aux_3471);
			    }
			 }
			 break;
		      case ((long) 16):
			 {
			    fail_t node_1750;
			    node_1750 = (fail_t) (node_1);
			    {
			       long proc_size_203_1751;
			       proc_size_203_1751 = node_size_119_inline_size((((fail_t) CREF(node_1750))->proc));
			       {
				  long msg_size_252_1752;
				  msg_size_252_1752 = node_size_119_inline_size((((fail_t) CREF(node_1750))->msg));
				  {
				     long obj_size_35_1753;
				     obj_size_35_1753 = node_size_119_inline_size((((fail_t) CREF(node_1750))->obj));
				     {
					long size_1754;
					{
					   long aux_3485;
					   {
					      long aux_3486;
					      aux_3486 = (msg_size_252_1752 + obj_size_35_1753);
					      aux_3485 = (proc_size_203_1751 + aux_3486);
					   }
					   size_1754 = (((long) 2) + aux_3485);
					}
					{
					   {
					      sized_fail_63_t obj1602_1755;
					      obj1602_1755 = ((sized_fail_63_t) (node_1750));
					      {
						 sized_fail_63_t arg2038_1756;
						 {
						    sized_fail_63_t res2133_2368;
						    {
						       sized_fail_63_t new1528_2366;
						       new1528_2366 = ((sized_fail_63_t) BREF(GC_MALLOC(sizeof(struct sized_fail_63))));
						       ((((sized_fail_63_t) CREF(new1528_2366))->size) = ((long) size_1754), BUNSPEC);
						       res2133_2368 = new1528_2366;
						    }
						    arg2038_1756 = res2133_2368;
						 }
						 {
						    obj_t aux_3495;
						    object_t aux_3493;
						    aux_3495 = (obj_t) (arg2038_1756);
						    aux_3493 = (object_t) (obj1602_1755);
						    OBJECT_WIDENING_SET(aux_3493, aux_3495);
						 }
					      }
					      {
						 long arg2040_1758;
						 arg2040_1758 = class_num_218___object(sized_fail_63_inline_size);
						 {
						    obj_t obj_2369;
						    obj_2369 = (obj_t) (obj1602_1755);
						    (((obj_t) CREF(obj_2369))->header = MAKE_HEADER(arg2040_1758, 0), BUNSPEC);
						 }
					      }
					      obj1602_1755;
					   }
					   aux_3277 = BINT(size_1754);
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 17):
			 {
			    sized_fail_63_t node_1765;
			    node_1765 = (sized_fail_63_t) (node_1);
			    {
			       long aux_3503;
			       {
				  obj_t aux_3504;
				  {
				     object_t aux_3505;
				     aux_3505 = (object_t) (node_1765);
				     aux_3504 = OBJECT_WIDENING(aux_3505);
				  }
				  aux_3503 = (((sized_fail_63_t) CREF(aux_3504))->size);
			       }
			       aux_3277 = BINT(aux_3503);
			    }
			 }
			 break;
		      case ((long) 18):
			 {
			    select_t node_1766;
			    node_1766 = (select_t) (node_1);
			    {
			       obj_t clauses_1767;
			       long size_1768;
			       {
				  obj_t arg2047_1770;
				  long arg2048_1771;
				  arg2047_1770 = (((select_t) CREF(node_1766))->clauses);
				  {
				     long arg2050_1773;
				     arg2050_1773 = node_size_119_inline_size((((select_t) CREF(node_1766))->test));
				     arg2048_1771 = (((long) 1) + arg2050_1773);
				  }
				  {
				     long aux_3515;
				     clauses_1767 = arg2047_1770;
				     size_1768 = arg2048_1771;
				   loop_1769:
				     if (NULLP(clauses_1767))
				       {
					  {
					     sized_select_166_t obj1604_1776;
					     obj1604_1776 = ((sized_select_166_t) (node_1766));
					     {
						sized_select_166_t arg2053_1777;
						{
						   sized_select_166_t res2134_2380;
						   {
						      sized_select_166_t new1544_2378;
						      new1544_2378 = ((sized_select_166_t) BREF(GC_MALLOC(sizeof(struct sized_select_166))));
						      ((((sized_select_166_t) CREF(new1544_2378))->size) = ((long) size_1768), BUNSPEC);
						      res2134_2380 = new1544_2378;
						   }
						   arg2053_1777 = res2134_2380;
						}
						{
						   obj_t aux_3523;
						   object_t aux_3521;
						   aux_3523 = (obj_t) (arg2053_1777);
						   aux_3521 = (object_t) (obj1604_1776);
						   OBJECT_WIDENING_SET(aux_3521, aux_3523);
						}
					     }
					     {
						long arg2055_1779;
						arg2055_1779 = class_num_218___object(sized_select_166_inline_size);
						{
						   obj_t obj_2381;
						   obj_2381 = (obj_t) (obj1604_1776);
						   (((obj_t) CREF(obj_2381))->header = MAKE_HEADER(arg2055_1779, 0), BUNSPEC);
						}
					     }
					     obj1604_1776;
					  }
					  aux_3515 = size_1768;
				       }
				     else
				       {
					  obj_t arg2056_1780;
					  long arg2057_1781;
					  arg2056_1780 = CDR(clauses_1767);
					  {
					     long arg2058_1782;
					     {
						long arg2059_1783;
						long arg2060_1784;
						{
						   bool_t test_3530;
						   {
						      obj_t aux_3531;
						      {
							 obj_t aux_3532;
							 aux_3532 = CAR(clauses_1767);
							 aux_3531 = CAR(aux_3532);
						      }
						      test_3530 = PAIRP(aux_3531);
						   }
						   if (test_3530)
						     {
							obj_t aux_3536;
							{
							   obj_t aux_3537;
							   aux_3537 = CAR(clauses_1767);
							   aux_3536 = CAR(aux_3537);
							}
							arg2059_1783 = list_length(aux_3536);
						     }
						   else
						     {
							arg2059_1783 = ((long) 1);
						     }
						}
						{
						   node_t aux_3541;
						   {
						      obj_t aux_3542;
						      {
							 obj_t aux_3543;
							 aux_3543 = CAR(clauses_1767);
							 aux_3542 = CDR(aux_3543);
						      }
						      aux_3541 = (node_t) (aux_3542);
						   }
						   arg2060_1784 = node_size_119_inline_size(aux_3541);
						}
						arg2058_1782 = (arg2059_1783 + arg2060_1784);
					     }
					     arg2057_1781 = (size_1768 + arg2058_1782);
					  }
					  {
					     long size_3551;
					     obj_t clauses_3550;
					     clauses_3550 = arg2056_1780;
					     size_3551 = arg2057_1781;
					     size_1768 = size_3551;
					     clauses_1767 = clauses_3550;
					     goto loop_1769;
					  }
				       }
				     aux_3277 = BINT(aux_3515);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 19):
			 {
			    sized_select_166_t node_1792;
			    node_1792 = (sized_select_166_t) (node_1);
			    {
			       long aux_3554;
			       {
				  obj_t aux_3555;
				  {
				     object_t aux_3556;
				     aux_3556 = (object_t) (node_1792);
				     aux_3555 = OBJECT_WIDENING(aux_3556);
				  }
				  aux_3554 = (((sized_select_166_t) CREF(aux_3555))->size);
			       }
			       aux_3277 = BINT(aux_3554);
			    }
			 }
			 break;
		      case ((long) 20):
			 {
			    let_fun_218_t node_1793;
			    node_1793 = (let_fun_218_t) (node_1);
			    {
			       obj_t locals_1794;
			       long size_1795;
			       {
				  obj_t arg2069_1797;
				  long arg2070_1798;
				  arg2069_1797 = (((let_fun_218_t) CREF(node_1793))->locals);
				  {
				     long arg2071_1799;
				     long arg2072_1800;
				     arg2071_1799 = list_length((((let_fun_218_t) CREF(node_1793))->locals));
				     arg2072_1800 = node_size_119_inline_size((((let_fun_218_t) CREF(node_1793))->body));
				     arg2070_1798 = (arg2071_1799 + arg2072_1800);
				  }
				  {
				     long aux_3568;
				     locals_1794 = arg2069_1797;
				     size_1795 = arg2070_1798;
				   loop_1796:
				     if (NULLP(locals_1794))
				       {
					  {
					     sized_let_fun_188_t obj1605_1804;
					     obj1605_1804 = ((sized_let_fun_188_t) (node_1793));
					     {
						sized_let_fun_188_t arg2076_1805;
						{
						   sized_let_fun_188_t res2135_2405;
						   {
						      sized_let_fun_188_t new1561_2403;
						      new1561_2403 = ((sized_let_fun_188_t) BREF(GC_MALLOC(sizeof(struct sized_let_fun_188))));
						      ((((sized_let_fun_188_t) CREF(new1561_2403))->size) = ((long) size_1795), BUNSPEC);
						      res2135_2405 = new1561_2403;
						   }
						   arg2076_1805 = res2135_2405;
						}
						{
						   obj_t aux_3576;
						   object_t aux_3574;
						   aux_3576 = (obj_t) (arg2076_1805);
						   aux_3574 = (object_t) (obj1605_1804);
						   OBJECT_WIDENING_SET(aux_3574, aux_3576);
						}
					     }
					     {
						long arg2078_1807;
						arg2078_1807 = class_num_218___object(sized_let_fun_188_inline_size);
						{
						   obj_t obj_2406;
						   obj_2406 = (obj_t) (obj1605_1804);
						   (((obj_t) CREF(obj_2406))->header = MAKE_HEADER(arg2078_1807, 0), BUNSPEC);
						}
					     }
					     obj1605_1804;
					  }
					  aux_3568 = size_1795;
				       }
				     else
				       {
					  obj_t arg2079_1808;
					  long arg2080_1809;
					  arg2079_1808 = CDR(locals_1794);
					  {
					     long arg2081_1810;
					     {
						node_t aux_3583;
						{
						   obj_t aux_3584;
						   {
						      sfun_t obj_2411;
						      {
							 value_t aux_3585;
							 {
							    local_t obj_2410;
							    {
							       obj_t aux_3586;
							       aux_3586 = CAR(locals_1794);
							       obj_2410 = (local_t) (aux_3586);
							    }
							    aux_3585 = (((local_t) CREF(obj_2410))->value);
							 }
							 obj_2411 = (sfun_t) (aux_3585);
						      }
						      aux_3584 = (((sfun_t) CREF(obj_2411))->body);
						   }
						   aux_3583 = (node_t) (aux_3584);
						}
						arg2081_1810 = node_size_119_inline_size(aux_3583);
					     }
					     arg2080_1809 = (size_1795 + arg2081_1810);
					  }
					  {
					     long size_3596;
					     obj_t locals_3595;
					     locals_3595 = arg2079_1808;
					     size_3596 = arg2080_1809;
					     size_1795 = size_3596;
					     locals_1794 = locals_3595;
					     goto loop_1796;
					  }
				       }
				     aux_3277 = BINT(aux_3568);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 21):
			 {
			    sized_let_fun_188_t node_1814;
			    node_1814 = (sized_let_fun_188_t) (node_1);
			    {
			       long aux_3599;
			       {
				  obj_t aux_3600;
				  {
				     object_t aux_3601;
				     aux_3601 = (object_t) (node_1814);
				     aux_3600 = OBJECT_WIDENING(aux_3601);
				  }
				  aux_3599 = (((sized_let_fun_188_t) CREF(aux_3600))->size);
			       }
			       aux_3277 = BINT(aux_3599);
			    }
			 }
			 break;
		      case ((long) 22):
			 {
			    let_var_6_t node_1815;
			    node_1815 = (let_var_6_t) (node_1);
			    {
			       obj_t bindings_1816;
			       long size_1817;
			       {
				  obj_t arg2085_1819;
				  long arg2086_1820;
				  arg2085_1819 = (((let_var_6_t) CREF(node_1815))->bindings);
				  arg2086_1820 = node_size_119_inline_size((((let_var_6_t) CREF(node_1815))->body));
				  {
				     long aux_3610;
				     bindings_1816 = arg2085_1819;
				     size_1817 = arg2086_1820;
				   loop_1818:
				     if (NULLP(bindings_1816))
				       {
					  {
					     sized_let_var_54_t obj1606_1823;
					     obj1606_1823 = ((sized_let_var_54_t) (node_1815));
					     {
						sized_let_var_54_t arg2089_1824;
						{
						   sized_let_var_54_t res2136_2421;
						   {
						      sized_let_var_54_t new1578_2419;
						      new1578_2419 = ((sized_let_var_54_t) BREF(GC_MALLOC(sizeof(struct sized_let_var_54))));
						      ((((sized_let_var_54_t) CREF(new1578_2419))->size) = ((long) size_1817), BUNSPEC);
						      res2136_2421 = new1578_2419;
						   }
						   arg2089_1824 = res2136_2421;
						}
						{
						   obj_t aux_3618;
						   object_t aux_3616;
						   aux_3618 = (obj_t) (arg2089_1824);
						   aux_3616 = (object_t) (obj1606_1823);
						   OBJECT_WIDENING_SET(aux_3616, aux_3618);
						}
					     }
					     {
						long arg2091_1826;
						arg2091_1826 = class_num_218___object(sized_let_var_54_inline_size);
						{
						   obj_t obj_2422;
						   obj_2422 = (obj_t) (obj1606_1823);
						   (((obj_t) CREF(obj_2422))->header = MAKE_HEADER(arg2091_1826, 0), BUNSPEC);
						}
					     }
					     obj1606_1823;
					  }
					  aux_3610 = size_1817;
				       }
				     else
				       {
					  obj_t arg2092_1827;
					  long arg2093_1828;
					  arg2092_1827 = CDR(bindings_1816);
					  {
					     long arg2094_1829;
					     {
						node_t aux_3625;
						{
						   obj_t aux_3626;
						   {
						      obj_t aux_3627;
						      aux_3627 = CAR(bindings_1816);
						      aux_3626 = CDR(aux_3627);
						   }
						   aux_3625 = (node_t) (aux_3626);
						}
						arg2094_1829 = node_size_119_inline_size(aux_3625);
					     }
					     arg2093_1828 = (size_1817 + arg2094_1829);
					  }
					  {
					     long size_3634;
					     obj_t bindings_3633;
					     bindings_3633 = arg2092_1827;
					     size_3634 = arg2093_1828;
					     size_1817 = size_3634;
					     bindings_1816 = bindings_3633;
					     goto loop_1818;
					  }
				       }
				     aux_3277 = BINT(aux_3610);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 23):
			 {
			    sized_let_var_54_t node_1832;
			    node_1832 = (sized_let_var_54_t) (node_1);
			    {
			       long aux_3637;
			       {
				  obj_t aux_3638;
				  {
				     object_t aux_3639;
				     aux_3639 = (object_t) (node_1832);
				     aux_3638 = OBJECT_WIDENING(aux_3639);
				  }
				  aux_3637 = (((sized_let_var_54_t) CREF(aux_3638))->size);
			       }
			       aux_3277 = BINT(aux_3637);
			    }
			 }
			 break;
		      case ((long) 24):
			 {
			    set_ex_it_116_t node_1833;
			    node_1833 = (set_ex_it_116_t) (node_1);
			    {
			       long arg2098_1835;
			       arg2098_1835 = node_size_119_inline_size((((set_ex_it_116_t) CREF(node_1833))->body));
			       {
				  long aux_3647;
				  aux_3647 = (((long) 2) + arg2098_1835);
				  aux_3277 = BINT(aux_3647);
			       }
			    }
			 }
			 break;
		      case ((long) 25):
			 {
			    jump_ex_it_184_t node_1837;
			    node_1837 = (jump_ex_it_184_t) (node_1);
			    {
			       long arg2101_1839;
			       {
				  long arg2102_1840;
				  long arg2103_1841;
				  arg2102_1840 = node_size_119_inline_size((((jump_ex_it_184_t) CREF(node_1837))->exit));
				  arg2103_1841 = node_size_119_inline_size((((jump_ex_it_184_t) CREF(node_1837))->value));
				  arg2101_1839 = (arg2102_1840 + arg2103_1841);
			       }
			       {
				  long aux_3656;
				  aux_3656 = (((long) 1) + arg2101_1839);
				  aux_3277 = BINT(aux_3656);
			       }
			    }
			 }
			 break;
		      case ((long) 26):
			 {
			    make_box_202_t node_1844;
			    node_1844 = (make_box_202_t) (node_1);
			    {
			       long arg2108_1846;
			       arg2108_1846 = node_size_119_inline_size((((make_box_202_t) CREF(node_1844))->value));
			       {
				  long aux_3662;
				  aux_3662 = (((long) 1) + arg2108_1846);
				  aux_3277 = BINT(aux_3662);
			       }
			    }
			 }
			 break;
		      case ((long) 27):
			 aux_3277 = BINT(((long) 2));
			 break;
		      case ((long) 28):
			 {
			    box_set__221_t node_1849;
			    node_1849 = (box_set__221_t) (node_1);
			    {
			       long arg2112_1851;
			       arg2112_1851 = node_size_119_inline_size((((box_set__221_t) CREF(node_1849))->value));
			       {
				  long aux_3669;
				  aux_3669 = (((long) 2) + arg2112_1851);
				  aux_3277 = BINT(aux_3669);
			       }
			    }
			 }
			 break;
		      default:
		       case_else1959_1648:
			 if (PROCEDUREP(method1953_1644))
			   {
			      aux_3277 = PROCEDURE_ENTRY(method1953_1644) (method1953_1644, (obj_t) (node_1), BEOA);
			   }
			 else
			   {
			      obj_t fun1950_1638;
			      fun1950_1638 = PROCEDURE_REF(node_size_env_51_inline_size, ((long) 0));
			      aux_3277 = PROCEDURE_ENTRY(fun1950_1638) (fun1950_1638, (obj_t) (node_1), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1959_1648;
		 }
	    }
	    return (long) CINT(aux_3277);
	 }
      }
   }
}


/* _node-size2143 */ obj_t 
_node_size2143_112_inline_size(obj_t env_2529, obj_t node_2530)
{
   {
      long aux_3684;
      aux_3684 = node_size_119_inline_size((node_t) (node_2530));
      return BINT(aux_3684);
   }
}


/* node-size-default1607 */ long 
node_size_default1607_123_inline_size(node_t node_2)
{
   FAILURE(CNST_TABLE_REF(((long) 9)), string2162_inline_size, (obj_t) (node_2));
}


/* _node-size-default1607 */ obj_t 
_node_size_default1607_113_inline_size(obj_t env_2531, obj_t node_2532)
{
   {
      long aux_3691;
      aux_3691 = node_size_default1607_123_inline_size((node_t) (node_2532));
      return BINT(aux_3691);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_size()
{
   module_initialization_70_type_type(((long) 0), "INLINE_SIZE");
   module_initialization_70_ast_var(((long) 0), "INLINE_SIZE");
   return module_initialization_70_ast_node(((long) 0), "INLINE_SIZE");
}
