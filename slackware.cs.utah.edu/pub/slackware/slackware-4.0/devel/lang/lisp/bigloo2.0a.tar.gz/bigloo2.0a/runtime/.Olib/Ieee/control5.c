/*===========================================================================*/
/*   (Ieee/control5.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern obj_t module_initialization_70___r5_control_features_6_4(long, char *);
extern obj_t module_initialization_70___error(long, char *);
obj_t _res_number__75___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1315___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1313___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1312___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1310___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1298___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1308___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1297___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1296___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1304___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1293___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1303___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1302___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1289___r5_control_features_6_4 = BUNSPEC;
static obj_t symbol1290___r5_control_features_6_4 = BUNSPEC;
static obj_t _values___r5_control_features_6_4(obj_t, obj_t);
static obj_t list1311___r5_control_features_6_4 = BUNSPEC;
static obj_t list1309___r5_control_features_6_4 = BUNSPEC;
static obj_t list1307___r5_control_features_6_4 = BUNSPEC;
static obj_t list1306___r5_control_features_6_4 = BUNSPEC;
static obj_t list1295___r5_control_features_6_4 = BUNSPEC;
static obj_t list1305___r5_control_features_6_4 = BUNSPEC;
static obj_t list1301___r5_control_features_6_4 = BUNSPEC;
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel_init_63___r5_control_features_6_4();
extern long list_length(obj_t);
static obj_t _call_with_values1127_184___r5_control_features_6_4(obj_t, obj_t, obj_t);
obj_t _res3__194___r5_control_features_6_4 = BUNSPEC;
obj_t _res2__167___r5_control_features_6_4 = BUNSPEC;
obj_t _res1__155___r5_control_features_6_4 = BUNSPEC;
extern obj_t call_with_values_2___r5_control_features_6_4(obj_t, obj_t);
static obj_t imported_modules_init_94___r5_control_features_6_4();
static obj_t require_initialization_114___r5_control_features_6_4 = BUNSPEC;
extern obj_t values___r5_control_features_6_4(obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137___r5_control_features_6_4();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( call_with_values_env_146___r5_control_features_6_4, _call_with_values1127_184___r5_control_features_6_41317, _call_with_values1127_184___r5_control_features_6_4, 0L, 2 );
DEFINE_STRING( string1314___r5_control_features_6_4, string1314___r5_control_features_6_41318, "PROCEDURE", 9 );
DEFINE_STRING( string1299___r5_control_features_6_4, string1299___r5_control_features_6_41319, "LONG", 4 );
DEFINE_STRING( string1294___r5_control_features_6_4, string1294___r5_control_features_6_41320, "CALL-WITH-VALUES:Wrong number of arguments", 42 );
DEFINE_STRING( string1292___r5_control_features_6_4, string1292___r5_control_features_6_41321, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/control5.scm", 61 );
DEFINE_STRING( string1291___r5_control_features_6_4, string1291___r5_control_features_6_41322, "PAIR", 4 );
DEFINE_STRING( string1300___r5_control_features_6_4, string1300___r5_control_features_6_41323, "Wrong number of arguments", 25 );
DEFINE_EXPORT_PROCEDURE( values_env_201___r5_control_features_6_4, _values___r5_control_features_6_41324, va_generic_entry, _values___r5_control_features_6_4, -1 );


/* module-initialization */obj_t module_initialization_70___r5_control_features_6_4(long checksum_478, char * from_479)
{
if(CBOOL(require_initialization_114___r5_control_features_6_4)){
require_initialization_114___r5_control_features_6_4 = BBOOL(((bool_t)0));
cnst_init_137___r5_control_features_6_4();
imported_modules_init_94___r5_control_features_6_4();
toplevel_init_63___r5_control_features_6_4();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r5_control_features_6_4()
{
symbol1289___r5_control_features_6_4 = string_to_symbol("TOPLEVEL-INIT");
symbol1290___r5_control_features_6_4 = string_to_symbol("VALUES");
symbol1293___r5_control_features_6_4 = string_to_symbol("CALL-WITH-VALUES");
symbol1296___r5_control_features_6_4 = string_to_symbol("FUNCALL");
symbol1297___r5_control_features_6_4 = string_to_symbol("producer");
{
obj_t aux_491;
{
obj_t aux_492;
aux_492 = MAKE_PAIR(symbol1297___r5_control_features_6_4, BNIL);
aux_491 = MAKE_PAIR(symbol1297___r5_control_features_6_4, aux_492);
}
list1295___r5_control_features_6_4 = MAKE_PAIR(symbol1296___r5_control_features_6_4, aux_491);
}
symbol1298___r5_control_features_6_4 = string_to_symbol("_");
symbol1302___r5_control_features_6_4 = string_to_symbol("APPLY");
symbol1303___r5_control_features_6_4 = string_to_symbol("consumer");
symbol1304___r5_control_features_6_4 = string_to_symbol("res0");
{
obj_t aux_500;
{
obj_t aux_501;
aux_501 = MAKE_PAIR(symbol1304___r5_control_features_6_4, BNIL);
aux_500 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_501);
}
list1301___r5_control_features_6_4 = MAKE_PAIR(symbol1302___r5_control_features_6_4, aux_500);
}
{
obj_t aux_505;
{
obj_t aux_506;
aux_506 = MAKE_PAIR(symbol1303___r5_control_features_6_4, BNIL);
aux_505 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_506);
}
list1305___r5_control_features_6_4 = MAKE_PAIR(symbol1296___r5_control_features_6_4, aux_505);
}
{
obj_t aux_510;
{
obj_t aux_511;
{
obj_t aux_512;
aux_512 = MAKE_PAIR(symbol1304___r5_control_features_6_4, BNIL);
aux_511 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_512);
}
aux_510 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_511);
}
list1306___r5_control_features_6_4 = MAKE_PAIR(symbol1296___r5_control_features_6_4, aux_510);
}
symbol1308___r5_control_features_6_4 = string_to_symbol("*res1*");
{
obj_t aux_518;
{
obj_t aux_519;
{
obj_t aux_520;
{
obj_t aux_521;
aux_521 = MAKE_PAIR(symbol1308___r5_control_features_6_4, BNIL);
aux_520 = MAKE_PAIR(symbol1304___r5_control_features_6_4, aux_521);
}
aux_519 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_520);
}
aux_518 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_519);
}
list1307___r5_control_features_6_4 = MAKE_PAIR(symbol1296___r5_control_features_6_4, aux_518);
}
symbol1310___r5_control_features_6_4 = string_to_symbol("*res2*");
{
obj_t aux_528;
{
obj_t aux_529;
{
obj_t aux_530;
{
obj_t aux_531;
{
obj_t aux_532;
aux_532 = MAKE_PAIR(symbol1310___r5_control_features_6_4, BNIL);
aux_531 = MAKE_PAIR(symbol1308___r5_control_features_6_4, aux_532);
}
aux_530 = MAKE_PAIR(symbol1304___r5_control_features_6_4, aux_531);
}
aux_529 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_530);
}
aux_528 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_529);
}
list1309___r5_control_features_6_4 = MAKE_PAIR(symbol1296___r5_control_features_6_4, aux_528);
}
symbol1312___r5_control_features_6_4 = string_to_symbol("*res3*");
{
obj_t aux_540;
{
obj_t aux_541;
{
obj_t aux_542;
{
obj_t aux_543;
{
obj_t aux_544;
{
obj_t aux_545;
aux_545 = MAKE_PAIR(symbol1312___r5_control_features_6_4, BNIL);
aux_544 = MAKE_PAIR(symbol1310___r5_control_features_6_4, aux_545);
}
aux_543 = MAKE_PAIR(symbol1308___r5_control_features_6_4, aux_544);
}
aux_542 = MAKE_PAIR(symbol1304___r5_control_features_6_4, aux_543);
}
aux_541 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_542);
}
aux_540 = MAKE_PAIR(symbol1303___r5_control_features_6_4, aux_541);
}
list1311___r5_control_features_6_4 = MAKE_PAIR(symbol1296___r5_control_features_6_4, aux_540);
}
symbol1313___r5_control_features_6_4 = string_to_symbol("_CALL-WITH-VALUES1127");
return (symbol1315___r5_control_features_6_4 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r5_control_features_6_4()
{
{
obj_t symbol1120_312;
symbol1120_312 = symbol1289___r5_control_features_6_4;
{
PUSH_TRACE(symbol1120_312);
BUNSPEC;
{
obj_t aux1119_313;
_res_number__75___r5_control_features_6_4 = BINT(((long)1));
_res1__155___r5_control_features_6_4 = BUNSPEC;
_res2__167___r5_control_features_6_4 = BUNSPEC;
aux1119_313 = (_res3__194___r5_control_features_6_4 = BUNSPEC,
BUNSPEC);
POP_TRACE();
return aux1119_313;
}
}
}
}


/* values */obj_t values___r5_control_features_6_4(obj_t args_1)
{
{
obj_t symbol1122_314;
symbol1122_314 = symbol1290___r5_control_features_6_4;
{
PUSH_TRACE(symbol1122_314);
BUNSPEC;
{
obj_t aux1121_315;
{
obj_t all_args_251_184;
all_args_251_184 = args_1;
{
bool_t test1004_185;
{
obj_t obj_297;
obj_297 = args_1;
test1004_185 = NULLP(obj_297);
}
if(test1004_185){
aux1121_315 = (_res_number__75___r5_control_features_6_4 = BINT(((long)0)),
BUNSPEC);
}
 else {
bool_t test1005_186;
{
obj_t arg1010_192;
{
obj_t pair_298;
{
obj_t aux1128_325;
aux1128_325 = args_1;
if(PAIRP(aux1128_325)){
pair_298 = aux1128_325;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1128_325, string1292___r5_control_features_6_4, BINT(((long)2575)));
exit( -1 );}
}
arg1010_192 = CDR(pair_298);
}
test1005_186 = NULLP(arg1010_192);
}
if(test1005_186){
_res_number__75___r5_control_features_6_4 = BINT(((long)1));
{
obj_t pair_300;
{
obj_t aux1134_331;
aux1134_331 = args_1;
if(PAIRP(aux1134_331)){
pair_300 = aux1134_331;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1134_331, string1292___r5_control_features_6_4, BINT(((long)2634)));
exit( -1 );}
}
aux1121_315 = CAR(pair_300);
}
}
 else {
obj_t res0_187;
{
obj_t pair_301;
{
obj_t aux1141_337;
aux1141_337 = args_1;
if(PAIRP(aux1141_337)){
pair_301 = aux1141_337;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1141_337, string1292___r5_control_features_6_4, BINT(((long)2662)));
exit( -1 );}
}
res0_187 = CAR(pair_301);
}
{
obj_t pair_302;
{
obj_t aux1147_343;
aux1147_343 = args_1;
if(PAIRP(aux1147_343)){
pair_302 = aux1147_343;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1147_343, string1292___r5_control_features_6_4, BINT(((long)2693)));
exit( -1 );}
}
args_1 = CDR(pair_302);
}
{
obj_t pair_303;
{
obj_t aux1154_349;
aux1154_349 = args_1;
if(PAIRP(aux1154_349)){
pair_303 = aux1154_349;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1154_349, string1292___r5_control_features_6_4, BINT(((long)2725)));
exit( -1 );}
}
_res1__155___r5_control_features_6_4 = CAR(pair_303);
}
{
obj_t pair_304;
{
obj_t aux1161_355;
aux1161_355 = args_1;
if(PAIRP(aux1161_355)){
pair_304 = aux1161_355;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1161_355, string1292___r5_control_features_6_4, BINT(((long)2755)));
exit( -1 );}
}
args_1 = CDR(pair_304);
}
{
bool_t test1006_188;
{
obj_t obj_305;
obj_305 = args_1;
test1006_188 = PAIRP(obj_305);
}
if(test1006_188){
{
obj_t pair_306;
{
obj_t aux1167_361;
aux1167_361 = args_1;
if(PAIRP(aux1167_361)){
pair_306 = aux1167_361;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1167_361, string1292___r5_control_features_6_4, BINT(((long)2822)));
exit( -1 );}
}
_res2__167___r5_control_features_6_4 = CAR(pair_306);
}
{
obj_t pair_307;
{
obj_t aux1173_367;
aux1173_367 = args_1;
if(PAIRP(aux1173_367)){
pair_307 = aux1173_367;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1173_367, string1292___r5_control_features_6_4, BINT(((long)2852)));
exit( -1 );}
}
args_1 = CDR(pair_307);
}
{
bool_t test1007_189;
{
obj_t obj_308;
obj_308 = args_1;
test1007_189 = PAIRP(obj_308);
}
if(test1007_189){
bool_t test1008_190;
{
obj_t arg1009_191;
{
obj_t pair_309;
{
obj_t aux1179_373;
aux1179_373 = args_1;
if(PAIRP(aux1179_373)){
pair_309 = aux1179_373;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1179_373, string1292___r5_control_features_6_4, BINT(((long)2903)));
exit( -1 );}
}
arg1009_191 = CDR(pair_309);
}
test1008_190 = PAIRP(arg1009_191);
}
if(test1008_190){
_res_number__75___r5_control_features_6_4 = BINT(((long)-1));
aux1121_315 = all_args_251_184;
}
 else {
{
obj_t pair_311;
{
obj_t aux1185_379;
aux1185_379 = args_1;
if(PAIRP(aux1185_379)){
pair_311 = aux1185_379;
}
 else {
bigloo_type_error_location_103___error(symbol1290___r5_control_features_6_4, string1291___r5_control_features_6_4, aux1185_379, string1292___r5_control_features_6_4, BINT(((long)3024)));
exit( -1 );}
}
_res3__194___r5_control_features_6_4 = CAR(pair_311);
}
_res_number__75___r5_control_features_6_4 = BINT(((long)4));
aux1121_315 = res0_187;
}
}
 else {
_res_number__75___r5_control_features_6_4 = BINT(((long)3));
aux1121_315 = res0_187;
}
}
}
 else {
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
aux1121_315 = res0_187;
}
}
}
}
}
}
POP_TRACE();
return aux1121_315;
}
}
}
}


/* _values */obj_t _values___r5_control_features_6_4(obj_t env_320, obj_t args_321)
{
return values___r5_control_features_6_4(args_321);
}


/* call-with-values */obj_t call_with_values_2___r5_control_features_6_4(obj_t producer_2, obj_t consumer_3)
{
{
obj_t symbol1124_316;
symbol1124_316 = symbol1293___r5_control_features_6_4;
{
PUSH_TRACE(symbol1124_316);
BUNSPEC;
{
obj_t aux1123_317;
_res_number__75___r5_control_features_6_4 = BINT(((long)1));
{
obj_t res0_193;
{
bool_t test1197_392;
test1197_392 = PROCEDURE_CORRECT_ARITYP(producer_2, ((long)0));
if(test1197_392){
res0_193 = PROCEDURE_ENTRY(producer_2)(producer_2, BEOA);
}
 else {
error_location_112___error(string1294___r5_control_features_6_4, list1295___r5_control_features_6_4, producer_2, string1292___r5_control_features_6_4, BINT(((long)3515)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
{
obj_t aux1003_195;
aux1003_195 = _res_number__75___r5_control_features_6_4;
{
bool_t test1011_196;
test1011_196 = INTEGERP(aux1003_195);
if(test1011_196){
long aux_701;
{
obj_t aux_702;
if(test1011_196){
aux_702 = aux1003_195;
}
 else {
bigloo_type_error_location_103___error(symbol1293___r5_control_features_6_4, string1299___r5_control_features_6_4, aux1003_195, string1292___r5_control_features_6_4, BINT(((long)3534)));
exit( -1 );}
aux_701 = (long)CINT(aux_702);
}
switch (aux_701){
case ((long)-1) : 
{
bool_t test1211_407;
{
long aux_648;
aux_648 = list_length(res0_193);
test1211_407 = PROCEDURE_CORRECT_ARITYP(consumer_3, aux_648);
}
if(test1211_407){
aux1123_317 = apply(consumer_3, res0_193);
}
 else {
error_location_112___error(symbol1293___r5_control_features_6_4, string1300___r5_control_features_6_4, list1301___r5_control_features_6_4, string1292___r5_control_features_6_4, BINT(((long)3564)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
break;
case ((long)0) : 
{
bool_t test1221_415;
test1221_415 = PROCEDURE_CORRECT_ARITYP(consumer_3, ((long)0));
if(test1221_415){
aux1123_317 = PROCEDURE_ENTRY(consumer_3)(consumer_3, BEOA);
}
 else {
error_location_112___error(string1294___r5_control_features_6_4, list1305___r5_control_features_6_4, consumer_3, string1292___r5_control_features_6_4, BINT(((long)3597)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
break;
case ((long)1) : 
{
bool_t test1232_423;
test1232_423 = PROCEDURE_CORRECT_ARITYP(consumer_3, ((long)1));
if(test1232_423){
aux1123_317 = PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, BEOA);
}
 else {
error_location_112___error(string1294___r5_control_features_6_4, list1306___r5_control_features_6_4, consumer_3, string1292___r5_control_features_6_4, BINT(((long)3619)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
break;
case ((long)2) : 
{
bool_t test1241_431;
test1241_431 = PROCEDURE_CORRECT_ARITYP(consumer_3, ((long)2));
if(test1241_431){
aux1123_317 = PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, _res1__155___r5_control_features_6_4, BEOA);
}
 else {
error_location_112___error(string1294___r5_control_features_6_4, list1307___r5_control_features_6_4, consumer_3, string1292___r5_control_features_6_4, BINT(((long)3646)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
break;
case ((long)3) : 
{
bool_t test1249_439;
test1249_439 = PROCEDURE_CORRECT_ARITYP(consumer_3, ((long)3));
if(test1249_439){
aux1123_317 = PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, _res1__155___r5_control_features_6_4, _res2__167___r5_control_features_6_4, BEOA);
}
 else {
error_location_112___error(string1294___r5_control_features_6_4, list1309___r5_control_features_6_4, consumer_3, string1292___r5_control_features_6_4, BINT(((long)3680)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
break;
case ((long)4) : 
{
bool_t test1256_447;
test1256_447 = PROCEDURE_CORRECT_ARITYP(consumer_3, ((long)4));
if(test1256_447){
aux1123_317 = PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, _res1__155___r5_control_features_6_4, _res2__167___r5_control_features_6_4, _res3__194___r5_control_features_6_4, BEOA);
}
 else {
error_location_112___error(string1294___r5_control_features_6_4, list1311___r5_control_features_6_4, consumer_3, string1292___r5_control_features_6_4, BINT(((long)3721)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
break;
default: 
{
bool_t test1264_456;
{
long aux_692;
aux_692 = list_length(res0_193);
test1264_456 = PROCEDURE_CORRECT_ARITYP(consumer_3, aux_692);
}
if(test1264_456){
aux1123_317 = apply(consumer_3, res0_193);
}
 else {
error_location_112___error(symbol1293___r5_control_features_6_4, string1300___r5_control_features_6_4, list1301___r5_control_features_6_4, string1292___r5_control_features_6_4, BINT(((long)3770)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
}
}
 else {
bool_t test1273_465;
{
long aux_708;
aux_708 = list_length(res0_193);
test1273_465 = PROCEDURE_CORRECT_ARITYP(consumer_3, aux_708);
}
if(test1273_465){
aux1123_317 = apply(consumer_3, res0_193);
}
 else {
error_location_112___error(symbol1293___r5_control_features_6_4, string1300___r5_control_features_6_4, list1301___r5_control_features_6_4, string1292___r5_control_features_6_4, BINT(((long)3770)));
FAILURE(symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4,symbol1298___r5_control_features_6_4);}
}
}
}
}
POP_TRACE();
return aux1123_317;
}
}
}
}


/* _call-with-values1127 */obj_t _call_with_values1127_184___r5_control_features_6_4(obj_t env_322, obj_t producer_323, obj_t consumer_324)
{
{
obj_t aux_724;
obj_t aux_718;
if(PROCEDUREP(consumer_324)){
aux_724 = consumer_324;
}
 else {
bigloo_type_error_location_103___error(symbol1313___r5_control_features_6_4, string1314___r5_control_features_6_4, consumer_324, string1292___r5_control_features_6_4, BINT(((long)3430)));
exit( -1 );}
if(PROCEDUREP(producer_323)){
aux_718 = producer_323;
}
 else {
bigloo_type_error_location_103___error(symbol1313___r5_control_features_6_4, string1314___r5_control_features_6_4, producer_323, string1292___r5_control_features_6_4, BINT(((long)3430)));
exit( -1 );}
return call_with_values_2___r5_control_features_6_4(aux_718, aux_724);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r5_control_features_6_4()
{
{
obj_t symbol1126_318;
symbol1126_318 = symbol1315___r5_control_features_6_4;
{
PUSH_TRACE(symbol1126_318);
BUNSPEC;
{
obj_t aux1125_319;
aux1125_319 = module_initialization_70___error(((long)0), "__R5_CONTROL_FEATURES_6_4");
POP_TRACE();
return aux1125_319;
}
}
}
}

