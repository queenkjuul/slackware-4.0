/*===========================================================================*/
/*   (Tools/shape.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_tools_shape();
extern obj_t string_to_symbol(char *);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t string_append(obj_t, obj_t);
extern obj_t _type_shape___78_engine_param;
extern obj_t type_type_type;
extern obj_t create_struct(obj_t, long);
extern obj_t _access_shape___50_engine_param;
extern obj_t global_ast_var;
static obj_t _shape_tools_shape(obj_t, obj_t);
extern obj_t global_bucket_position_189_ast_env(obj_t, obj_t);
extern obj_t node__sexp_247_ast_dump(node_t);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_dump(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t node_ast_node;
extern obj_t _module_shape___145_engine_param;
static obj_t imported_modules_init_94_tools_shape();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t library_modules_init_112_tools_shape();
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t _key_shape___172_engine_param;
static obj_t _shape_default1438_46_tools_shape(obj_t, obj_t);
static obj_t toplevel_init_63_tools_shape();
extern obj_t open_input_string(obj_t);
static obj_t shape_default1438_53_tools_shape(obj_t);
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t local_ast_var;
static obj_t loop_tools_shape(obj_t);
extern obj_t _case_sensitive__90_engine_param;
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _user_shape___227_engine_param;
static obj_t require_initialization_114_tools_shape = BUNSPEC;
static obj_t cnst_init_137_tools_shape();
extern obj_t make_vector(long, obj_t);
static obj_t __cnst[3];

DEFINE_STATIC_PROCEDURE(shape_default1438_env_92_tools_shape, _shape_default1438_46_tools_shape1727, _shape_default1438_46_tools_shape, 0L, 1);
DEFINE_EXPORT_GENERIC(shape_env_98_tools_shape, _shape_tools_shape1728, _shape_tools_shape, 0L, 1);
DEFINE_STRING(string1721_tools_shape, string1721_tools_shape1729, "A-TVECTOR _ @ ", 14);
DEFINE_STRING(string1719_tools_shape, string1719_tools_shape1730, "global-shape", 12);
DEFINE_STRING(string1720_tools_shape, string1720_tools_shape1731, "Can't find global any more", 26);
DEFINE_STRING(string1718_tools_shape, string1718_tools_shape1732, "@", 1);
DEFINE_STRING(string1717_tools_shape, string1717_tools_shape1733, "{", 1);
DEFINE_STRING(string1716_tools_shape, string1716_tools_shape1734, "}", 1);
DEFINE_STRING(string1715_tools_shape, string1715_tools_shape1735, "", 0);
DEFINE_STRING(string1714_tools_shape, string1714_tools_shape1736, "::", 2);


/* module-initialization */ obj_t 
module_initialization_70_tools_shape(long checksum_1385, char *from_1386)
{
   if (CBOOL(require_initialization_114_tools_shape))
     {
	require_initialization_114_tools_shape = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_shape();
	cnst_init_137_tools_shape();
	imported_modules_init_94_tools_shape();
	method_init_76_tools_shape();
	toplevel_init_63_tools_shape();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_shape()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "TOOLS_SHAPE");
   module_initialization_70___object(((long) 0), "TOOLS_SHAPE");
   module_initialization_70___r4_strings_6_7(((long) 0), "TOOLS_SHAPE");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "TOOLS_SHAPE");
   module_initialization_70___reader(((long) 0), "TOOLS_SHAPE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TOOLS_SHAPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_tools_shape()
{
   {
      obj_t cnst_port_138_1377;
      cnst_port_138_1377 = open_input_string(string1721_tools_shape);
      {
	 long i_1378;
	 i_1378 = ((long) 2);
       loop_1379:
	 {
	    bool_t test1722_1380;
	    test1722_1380 = (i_1378 == ((long) -1));
	    if (test1722_1380)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1723_1381;
		    {
		       obj_t list1724_1382;
		       {
			  obj_t arg1725_1383;
			  arg1725_1383 = BNIL;
			  list1724_1382 = MAKE_PAIR(cnst_port_138_1377, arg1725_1383);
		       }
		       arg1723_1381 = read___reader(list1724_1382);
		    }
		    CNST_TABLE_SET(i_1378, arg1723_1381);
		 }
		 {
		    int aux_1384;
		    {
		       long aux_1407;
		       aux_1407 = (i_1378 - ((long) 1));
		       aux_1384 = (int) (aux_1407);
		    }
		    {
		       long i_1410;
		       i_1410 = (long) (aux_1384);
		       i_1378 = i_1410;
		       goto loop_1379;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_tools_shape()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_tools_shape()
{
   add_generic__110___object(shape_env_98_tools_shape, shape_default1438_env_92_tools_shape);
   add_inlined_method__244___object(shape_env_98_tools_shape, global_ast_var, ((long) 0));
   add_inlined_method__244___object(shape_env_98_tools_shape, local_ast_var, ((long) 1));
   add_inlined_method__244___object(shape_env_98_tools_shape, type_type_type, ((long) 2));
   {
      long aux_1416;
      aux_1416 = add_inlined_method__244___object(shape_env_98_tools_shape, node_ast_node, ((long) 3));
      return BINT(aux_1416);
   }
}


/* shape */ obj_t 
shape_tools_shape(obj_t exp_12)
{
   {
      obj_t method1583_1091;
      obj_t class1588_1092;
      {
	 bool_t test1593_1088;
	 test1593_1088 = (POINTERP(exp_12) && (TYPE(exp_12) >= OBJECT_TYPE));
	 if (test1593_1088)
	   {
	      obj_t arg1594_1089;
	      obj_t arg1595_1090;
	      {
		 object_t obj_1247;
		 obj_1247 = (object_t) (exp_12);
		 {
		    obj_t pre_method_105_1248;
		    pre_method_105_1248 = PROCEDURE_REF(shape_env_98_tools_shape, ((long) 2));
		    if (INTEGERP(pre_method_105_1248))
		      {
			 PROCEDURE_SET(shape_env_98_tools_shape, ((long) 2), BUNSPEC);
			 arg1594_1089 = pre_method_105_1248;
		      }
		    else
		      {
			 long obj_class_num_177_1253;
			 obj_class_num_177_1253 = TYPE(obj_1247);
			 {
			    obj_t arg1177_1254;
			    arg1177_1254 = PROCEDURE_REF(shape_env_98_tools_shape, ((long) 1));
			    {
			       long arg1178_1258;
			       {
				  long arg1179_1259;
				  arg1179_1259 = OBJECT_TYPE;
				  arg1178_1258 = (obj_class_num_177_1253 - arg1179_1259);
			       }
			       arg1594_1089 = VECTOR_REF(arg1177_1254, arg1178_1258);
			    }
			 }
		      }
		 }
	      }
	      {
		 object_t object_1264;
		 object_1264 = (object_t) (exp_12);
		 {
		    long arg1180_1265;
		    {
		       long arg1181_1266;
		       long arg1182_1267;
		       arg1181_1266 = TYPE(object_1264);
		       arg1182_1267 = OBJECT_TYPE;
		       arg1180_1265 = (arg1181_1266 - arg1182_1267);
		    }
		    {
		       obj_t vector_1271;
		       vector_1271 = _classes__134___object;
		       arg1595_1090 = VECTOR_REF(vector_1271, arg1180_1265);
		    }
		 }
	      }
	      method1583_1091 = arg1594_1089;
	      class1588_1092 = arg1595_1090;
	    loop1584_1214:
	      {
		 if (INTEGERP(method1583_1091))
		   {
		      switch ((long) CINT(method1583_1091))
			{
			case ((long) 0):
			   {
			      global_t var_1098;
			      var_1098 = (global_t) (exp_12);
			      {
				 obj_t str_id_3_1099;
				 {
				    obj_t arg1669_1164;
				    {
				       obj_t aux_1439;
				       aux_1439 = (((global_t) CREF(var_1098))->id);
				       arg1669_1164 = SYMBOL_TO_STRING(aux_1439);
				    }
				    if (CBOOL(_case_sensitive__90_engine_param))
				      {
					 str_id_3_1099 = arg1669_1164;
				      }
				    else
				      {
					 str_id_3_1099 = string_downcase_77___r4_strings_6_7(arg1669_1164);
				      }
				 }
				 {
				    obj_t id_1100;
				    {
				       char *aux_1445;
				       aux_1445 = BSTRING_TO_STRING(str_id_3_1099);
				       id_1100 = string_to_symbol(aux_1445);
				    }
				    {
				       obj_t module_1101;
				       {
					  obj_t arg1667_1162;
					  {
					     obj_t aux_1448;
					     aux_1448 = (((global_t) CREF(var_1098))->module);
					     arg1667_1162 = SYMBOL_TO_STRING(aux_1448);
					  }
					  if (CBOOL(_case_sensitive__90_engine_param))
					    {
					       module_1101 = arg1667_1162;
					    }
					  else
					    {
					       module_1101 = string_downcase_77___r4_strings_6_7(arg1667_1162);
					    }
				       }
				       {
					  type_t type_1102;
					  type_1102 = (((global_t) CREF(var_1098))->type);
					  {
					     obj_t tshape_1103;
					     if (CBOOL(_type_shape___78_engine_param))
					       {
						  obj_t arg1666_1161;
						  arg1666_1161 = shape_tools_shape((obj_t) (type_1102));
						  tshape_1103 = string_append(string1714_tools_shape, arg1666_1161);
					       }
					     else
					       {
						  tshape_1103 = string1715_tools_shape;
					       }
					     {
						obj_t ashape_1104;
						if (CBOOL(_access_shape___50_engine_param))
						  {
						     {
							obj_t arg1654_1152;
							{
							   obj_t arg1661_1158;
							   {
							      obj_t aux_1462;
							      aux_1462 = (((global_t) CREF(var_1098))->access);
							      arg1661_1158 = SYMBOL_TO_STRING(aux_1462);
							   }
							   if (CBOOL(_case_sensitive__90_engine_param))
							     {
								arg1654_1152 = arg1661_1158;
							     }
							   else
							     {
								arg1654_1152 = string_downcase_77___r4_strings_6_7(arg1661_1158);
							     }
							}
							{
							   obj_t list1656_1154;
							   {
							      obj_t arg1657_1155;
							      {
								 obj_t arg1658_1156;
								 arg1658_1156 = MAKE_PAIR(string1716_tools_shape, BNIL);
								 arg1657_1155 = MAKE_PAIR(arg1654_1152, arg1658_1156);
							      }
							      list1656_1154 = MAKE_PAIR(string1717_tools_shape, arg1657_1155);
							   }
							   ashape_1104 = string_append_106___r4_strings_6_7(list1656_1154);
							}
						     }
						  }
						else
						  {
						     ashape_1104 = string1715_tools_shape;
						  }
						{
						   if (CBOOL(_module_shape___145_engine_param))
						     {
							{
							   obj_t arg1598_1105;
							   {
							      obj_t list1599_1106;
							      {
								 obj_t arg1600_1107;
								 {
								    obj_t arg1603_1109;
								    {
								       obj_t arg1605_1110;
								       {
									  obj_t arg1606_1111;
									  arg1606_1111 = MAKE_PAIR(ashape_1104, BNIL);
									  arg1605_1110 = MAKE_PAIR(tshape_1103, arg1606_1111);
								       }
								       arg1603_1109 = MAKE_PAIR(module_1101, arg1605_1110);
								    }
								    arg1600_1107 = MAKE_PAIR(string1718_tools_shape, arg1603_1109);
								 }
								 list1599_1106 = MAKE_PAIR(str_id_3_1099, arg1600_1107);
							      }
							      arg1598_1105 = string_append_106___r4_strings_6_7(list1599_1106);
							   }
							   {
							      char *aux_1480;
							      aux_1480 = BSTRING_TO_STRING(arg1598_1105);
							      return string_to_symbol(aux_1480);
							   }
							}
						     }
						   else
						     {
							{
							   {
							      obj_t aux1436_1114;
							      aux1436_1114 = global_bucket_position_189_ast_env((((global_t) CREF(var_1098))->id), (((global_t) CREF(var_1098))->module));
							      {
								 bool_t test1608_1115;
								 test1608_1115 = INTEGERP(aux1436_1114);
								 if (test1608_1115)
								   {
								      if (test1608_1115)
									{
									   switch ((long) CINT(aux1436_1114))
									     {
									     case ((long) -1):
										{
										   obj_t arg1613_1121;
										   {
										      obj_t arg1615_1122;
										      obj_t arg1617_1123;
										      arg1615_1122 = CNST_TABLE_REF(((long) 0));
										      arg1617_1123 = (((global_t) CREF(var_1098))->module);
										      {
											 obj_t list1619_1125;
											 {
											    obj_t arg1620_1126;
											    {
											       obj_t arg1621_1127;
											       arg1621_1127 = MAKE_PAIR(BNIL, BNIL);
											       arg1620_1126 = MAKE_PAIR(arg1617_1123, arg1621_1127);
											    }
											    list1619_1125 = MAKE_PAIR(id_1100, arg1620_1126);
											 }
											 arg1613_1121 = cons__138___r4_pairs_and_lists_6_3(arg1615_1122, list1619_1125);
										      }
										   }
										   return internal_error_43_tools_error(string1719_tools_shape, string1720_tools_shape, arg1613_1121);
										}
										break;
									     case ((long) 0):
										{
										   obj_t arg1623_1129;
										   obj_t arg1624_1130;
										   {
										      char *aux_1496;
										      aux_1496 = BSTRING_TO_STRING(tshape_1103);
										      arg1623_1129 = string_to_symbol(aux_1496);
										   }
										   {
										      char *aux_1499;
										      aux_1499 = BSTRING_TO_STRING(ashape_1104);
										      arg1624_1130 = string_to_symbol(aux_1499);
										   }
										   {
										      obj_t list1625_1131;
										      {
											 obj_t arg1627_1132;
											 {
											    obj_t arg1628_1133;
											    arg1628_1133 = MAKE_PAIR(arg1624_1130, BNIL);
											    arg1627_1132 = MAKE_PAIR(arg1623_1129, arg1628_1133);
											 }
											 list1625_1131 = MAKE_PAIR(id_1100, arg1627_1132);
										      }
										      return symbol_append_197___r4_symbols_6_4(list1625_1131);
										   }
										}
										break;
									     default:
									      case_else1435_1113:
										{
										   obj_t sym_1137;
										   {
										      obj_t arg1646_1145;
										      obj_t arg1647_1146;
										      {
											 char *aux_1506;
											 aux_1506 = BSTRING_TO_STRING(tshape_1103);
											 arg1646_1145 = string_to_symbol(aux_1506);
										      }
										      {
											 char *aux_1509;
											 aux_1509 = BSTRING_TO_STRING(ashape_1104);
											 arg1647_1146 = string_to_symbol(aux_1509);
										      }
										      {
											 obj_t list1648_1147;
											 {
											    obj_t arg1649_1148;
											    {
											       obj_t arg1650_1149;
											       arg1650_1149 = MAKE_PAIR(arg1647_1146, BNIL);
											       arg1649_1148 = MAKE_PAIR(arg1646_1145, arg1650_1149);
											    }
											    list1648_1147 = MAKE_PAIR(id_1100, arg1649_1148);
											 }
											 sym_1137 = symbol_append_197___r4_symbols_6_4(list1648_1147);
										      }
										   }
										   {
										      obj_t arg1634_1138;
										      obj_t arg1636_1139;
										      arg1634_1138 = CNST_TABLE_REF(((long) 0));
										      {
											 char *aux_1517;
											 aux_1517 = BSTRING_TO_STRING(module_1101);
											 arg1636_1139 = string_to_symbol(aux_1517);
										      }
										      {
											 obj_t list1639_1141;
											 {
											    obj_t arg1640_1142;
											    {
											       obj_t arg1641_1143;
											       arg1641_1143 = MAKE_PAIR(BNIL, BNIL);
											       arg1640_1142 = MAKE_PAIR(arg1636_1139, arg1641_1143);
											    }
											    list1639_1141 = MAKE_PAIR(sym_1137, arg1640_1142);
											 }
											 return cons__138___r4_pairs_and_lists_6_3(arg1634_1138, list1639_1141);
										      }
										   }
										}
									     }
									}
								      else
									{
									   goto case_else1435_1113;
									}
								   }
								 else
								   {
								      goto case_else1435_1113;
								   }
							      }
							   }
							}
						     }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			   break;
			case ((long) 1):
			   {
			      local_t var_1166;
			      var_1166 = (local_t) (exp_12);
			      {
				 obj_t sym_1167;
				 if (CBOOL(_key_shape___172_engine_param))
				   {
				      obj_t arg1694_1192;
				      obj_t arg1695_1193;
				      obj_t arg1697_1194;
				      arg1694_1192 = (((local_t) CREF(var_1166))->id);
				      arg1695_1193 = CNST_TABLE_REF(((long) 1));
				      {
					 char *aux_1531;
					 {
					    obj_t aux_1532;
					    {
					       char *aux_1533;
					       aux_1533 = integer__string_135___r4_numbers_6_5_fixnum((((local_t) CREF(var_1166))->key), BNIL);
					       aux_1532 = string_to_bstring(aux_1533);
					    }
					    aux_1531 = BSTRING_TO_STRING(aux_1532);
					 }
					 arg1697_1194 = string_to_symbol(aux_1531);
				      }
				      {
					 obj_t list1698_1195;
					 {
					    obj_t arg1699_1196;
					    {
					       obj_t arg1700_1197;
					       arg1700_1197 = MAKE_PAIR(arg1697_1194, BNIL);
					       arg1699_1196 = MAKE_PAIR(arg1695_1193, arg1700_1197);
					    }
					    list1698_1195 = MAKE_PAIR(arg1694_1192, arg1699_1196);
					 }
					 sym_1167 = symbol_append_197___r4_symbols_6_4(list1698_1195);
				      }
				   }
				 else
				   {
				      sym_1167 = (((local_t) CREF(var_1166))->id);
				   }
				 {
				    obj_t sym_1168;
				    {
				       obj_t arg1693_1191;
				       arg1693_1191 = SYMBOL_TO_STRING(sym_1167);
				       if (CBOOL(_case_sensitive__90_engine_param))
					 {
					    sym_1168 = arg1693_1191;
					 }
				       else
					 {
					    sym_1168 = string_downcase_77___r4_strings_6_7(arg1693_1191);
					 }
				    }
				    {
				       type_t type_1169;
				       type_1169 = (((local_t) CREF(var_1166))->type);
				       {
					  obj_t tshape_1170;
					  if (CBOOL(_type_shape___78_engine_param))
					    {
					       obj_t arg1692_1190;
					       arg1692_1190 = shape_tools_shape((obj_t) (type_1169));
					       tshape_1170 = string_append(string1714_tools_shape, arg1692_1190);
					    }
					  else
					    {
					       tshape_1170 = string1715_tools_shape;
					    }
					  {
					     char *ushape_1171;
					     if (CBOOL(_user_shape___227_engine_param))
					       {
						  if ((((local_t) CREF(var_1166))->user__32))
						    {
						       ushape_1171 = "-<user>";
						    }
						  else
						    {
						       ushape_1171 = "-<no-user>";
						    }
					       }
					     else
					       {
						  ushape_1171 = "";
					       }
					     {
						obj_t ashape_1172;
						if (CBOOL(_access_shape___50_engine_param))
						  {
						     {
							obj_t arg1680_1180;
							{
							   obj_t arg1686_1186;
							   {
							      obj_t aux_1560;
							      aux_1560 = (((local_t) CREF(var_1166))->access);
							      arg1686_1186 = SYMBOL_TO_STRING(aux_1560);
							   }
							   if (CBOOL(_case_sensitive__90_engine_param))
							     {
								arg1680_1180 = arg1686_1186;
							     }
							   else
							     {
								arg1680_1180 = string_downcase_77___r4_strings_6_7(arg1686_1186);
							     }
							}
							{
							   obj_t list1682_1182;
							   {
							      obj_t arg1683_1183;
							      {
								 obj_t arg1684_1184;
								 arg1684_1184 = MAKE_PAIR(string1716_tools_shape, BNIL);
								 arg1683_1183 = MAKE_PAIR(arg1680_1180, arg1684_1184);
							      }
							      list1682_1182 = MAKE_PAIR(string1717_tools_shape, arg1683_1183);
							   }
							   ashape_1172 = string_append_106___r4_strings_6_7(list1682_1182);
							}
						     }
						  }
						else
						  {
						     ashape_1172 = string1715_tools_shape;
						  }
						{
						   {
						      obj_t arg1672_1173;
						      {
							 obj_t list1673_1174;
							 {
							    obj_t arg1675_1175;
							    {
							       obj_t arg1676_1176;
							       {
								  obj_t arg1677_1177;
								  arg1677_1177 = MAKE_PAIR(ashape_1172, BNIL);
								  {
								     obj_t aux_1571;
								     aux_1571 = string_to_bstring(ushape_1171);
								     arg1676_1176 = MAKE_PAIR(aux_1571, arg1677_1177);
								  }
							       }
							       arg1675_1175 = MAKE_PAIR(tshape_1170, arg1676_1176);
							    }
							    list1673_1174 = MAKE_PAIR(sym_1168, arg1675_1175);
							 }
							 arg1672_1173 = string_append_106___r4_strings_6_7(list1673_1174);
						      }
						      {
							 char *aux_1577;
							 aux_1577 = BSTRING_TO_STRING(arg1672_1173);
							 return string_to_symbol(aux_1577);
						      }
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			   break;
			case ((long) 2):
			   {
			      type_t type_1202;
			      type_1202 = (type_t) (exp_12);
			      {
				 obj_t arg1705_1203;
				 {
				    obj_t aux_1581;
				    aux_1581 = (((type_t) CREF(type_1202))->id);
				    arg1705_1203 = SYMBOL_TO_STRING(aux_1581);
				 }
				 if (CBOOL(_case_sensitive__90_engine_param))
				   {
				      return arg1705_1203;
				   }
				 else
				   {
				      return string_downcase_77___r4_strings_6_7(arg1705_1203);
				   }
			      }
			   }
			   break;
			case ((long) 3):
			   return node__sexp_247_ast_dump((node_t) (exp_12));
			   break;
			default:
			 case_else1589_1095:
			   if (PROCEDUREP(method1583_1091))
			     {
				return PROCEDURE_ENTRY(method1583_1091) (method1583_1091, exp_12, BEOA);
			     }
			   else
			     {
				obj_t fun1554_1051;
				fun1554_1051 = PROCEDURE_REF(shape_env_98_tools_shape, ((long) 0));
				return PROCEDURE_ENTRY(fun1554_1051) (fun1554_1051, exp_12, BEOA);
			     }
			}
		   }
		 else
		   {
		      goto case_else1589_1095;
		   }
	      }
	   }
	 else
	   {
	      obj_t class1588_1599;
	      obj_t method1583_1598;
	      method1583_1598 = BFALSE;
	      class1588_1599 = BFALSE;
	      class1588_1092 = class1588_1599;
	      method1583_1091 = method1583_1598;
	      goto loop1584_1214;
	   }
      }
   }
}


/* _shape */ obj_t 
_shape_tools_shape(obj_t env_1372, obj_t exp_1373)
{
   return shape_tools_shape(exp_1373);
}


/* shape-default1438 */ obj_t 
shape_default1438_53_tools_shape(obj_t exp_13)
{
   if (PAIRP(exp_13))
     {
	return loop_tools_shape(exp_13);
     }
   else
     {
	if (VECTORP(exp_13))
	  {
	     {
		long len_1062;
		len_1062 = VECTOR_LENGTH(exp_13);
		{
		   obj_t res_1063;
		   res_1063 = make_vector(len_1062, BNIL);
		   {
		      {
			 long indice_1064;
			 indice_1064 = ((long) 0);
		       loop_1065:
			 if ((indice_1064 == len_1062))
			   {
			      return res_1063;
			   }
			 else
			   {
			      {
				 obj_t arg1564_1067;
				 arg1564_1067 = shape_tools_shape(VECTOR_REF(exp_13, indice_1064));
				 VECTOR_SET(res_1063, indice_1064, arg1564_1067);
			      }
			      {
				 long indice_1613;
				 indice_1613 = (indice_1064 + ((long) 1));
				 indice_1064 = indice_1613;
				 goto loop_1065;
			      }
			   }
		      }
		   }
		}
	     }
	  }
	else
	  {
	     bool_t test_1615;
	     if (STRUCTP(exp_13))
	       {
		  obj_t aux_1620;
		  obj_t aux_1618;
		  aux_1620 = CNST_TABLE_REF(((long) 2));
		  aux_1618 = STRUCT_KEY(exp_13);
		  test_1615 = (aux_1618 == aux_1620);
	       }
	     else
	       {
		  test_1615 = ((bool_t) 0);
	       }
	     if (test_1615)
	       {
		  {
		     obj_t arg1570_1072;
		     obj_t arg1572_1073;
		     arg1570_1072 = shape_tools_shape(STRUCT_REF(exp_13, ((long) 0)));
		     arg1572_1073 = shape_tools_shape(STRUCT_REF(exp_13, ((long) 1)));
		     {
			obj_t new_1344;
			{
			   obj_t aux_1627;
			   aux_1627 = CNST_TABLE_REF(((long) 2));
			   new_1344 = create_struct(aux_1627, ((long) 2));
			}
			STRUCT_SET(new_1344, ((long) 1), arg1572_1073);
			STRUCT_SET(new_1344, ((long) 0), arg1570_1072);
			return new_1344;
		     }
		  }
	       }
	     else
	       {
		  if (STRUCTP(exp_13))
		    {
		       {
			  long len_1078;
			  len_1078 = STRUCT_LENGTH(exp_13);
			  {
			     obj_t res_1079;
			     {
				obj_t aux_1635;
				aux_1635 = STRUCT_KEY(exp_13);
				res_1079 = make_struct(aux_1635, len_1078, BNIL);
			     }
			     {
				{
				   long indice_1080;
				   indice_1080 = ((long) 0);
				 loop_1081:
				   if ((indice_1080 == len_1078))
				     {
					return res_1079;
				     }
				   else
				     {
					{
					   obj_t arg1578_1083;
					   arg1578_1083 = shape_tools_shape(STRUCT_REF(exp_13, indice_1080));
					   STRUCT_SET(res_1079, indice_1080, arg1578_1083);
					}
					{
					   long indice_1643;
					   indice_1643 = (indice_1080 + ((long) 1));
					   indice_1080 = indice_1643;
					   goto loop_1081;
					}
				     }
				}
			     }
			  }
		       }
		    }
		  else
		    {
		       return exp_13;
		    }
	       }
	  }
     }
}


/* loop */ obj_t 
loop_tools_shape(obj_t exp_1053)
{
   if (NULLP(exp_1053))
     {
	return BNIL;
     }
   else
     {
	if (PAIRP(exp_1053))
	  {
	     {
		obj_t arg1558_1057;
		obj_t arg1559_1058;
		arg1558_1057 = shape_tools_shape(CAR(exp_1053));
		arg1559_1058 = loop_tools_shape(CDR(exp_1053));
		return MAKE_PAIR(arg1558_1057, arg1559_1058);
	     }
	  }
	else
	  {
	     return shape_tools_shape(exp_1053);
	  }
     }
}


/* _shape-default1438 */ obj_t 
_shape_default1438_46_tools_shape(obj_t env_1374, obj_t exp_1375)
{
   return shape_default1438_53_tools_shape(exp_1375);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_shape()
{
   module_initialization_70_type_type(((long) 0), "TOOLS_SHAPE");
   module_initialization_70_ast_var(((long) 0), "TOOLS_SHAPE");
   module_initialization_70_ast_node(((long) 0), "TOOLS_SHAPE");
   module_initialization_70_ast_dump(((long) 0), "TOOLS_SHAPE");
   module_initialization_70_ast_env(((long) 0), "TOOLS_SHAPE");
   module_initialization_70_engine_param(((long) 0), "TOOLS_SHAPE");
   return module_initialization_70_tools_error(((long) 0), "TOOLS_SHAPE");
}
