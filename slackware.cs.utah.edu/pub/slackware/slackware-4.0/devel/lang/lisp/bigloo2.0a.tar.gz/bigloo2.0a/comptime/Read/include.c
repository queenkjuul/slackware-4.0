/*===========================================================================*/
/*   (Read/include.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t body1004_read_include(obj_t);
extern obj_t exitd_top;
extern obj_t _load_path__54___eval;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
static obj_t _include_read__106_read_include = BUNSPEC;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t handling_function1036_read_include(obj_t, obj_t, obj_t, obj_t);
extern obj_t assoc___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t module_initialization_70_read_include(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_engine_engine(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t imported_modules_init_94_read_include();
static obj_t handler_read_include(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _read_include1188_199_read_include(obj_t, obj_t);
static obj_t rhandler1003_read_include(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_read_include();
static obj_t toplevel_init_63_read_include();
extern obj_t open_input_string(obj_t);
extern obj_t read_include_201_read_include(obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t close_input_port(obj_t);
static obj_t arg1039_read_include(obj_t);
static obj_t arg1038_read_include(obj_t);
extern obj_t remove_error_handler__102___error();
extern obj_t read___reader(obj_t);
static obj_t escape_read_include(obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_read_include = BUNSPEC;
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
static obj_t cnst_init_137_read_include();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(read_include_env_148_read_include, _read_include1188_199_read_include1201, _read_include1188_199_read_include, 0L, 1);
DEFINE_STRING(string1194_read_include, string1194_read_include1202, "DIRECTIVES ", 11);
DEFINE_STRING(string1193_read_include, string1193_read_include1203, "Can't find include file", 23);
DEFINE_STRING(string1192_read_include, string1192_read_include1204, "Can't open such file", 20);
DEFINE_STRING(string1191_read_include, string1191_read_include1205, "read-include", 12);
DEFINE_STRING(string1189_read_include, string1189_read_include1206, "]", 1);
DEFINE_STRING(string1190_read_include, string1190_read_include1207, "      [reading include file ", 28);


/* module-initialization */ obj_t 
module_initialization_70_read_include(long checksum_159, char *from_160)
{
   if (CBOOL(require_initialization_114_read_include))
     {
	require_initialization_114_read_include = BBOOL(((bool_t) 0));
	library_modules_init_112_read_include();
	cnst_init_137_read_include();
	imported_modules_init_94_read_include();
	toplevel_init_63_read_include();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_read_include()
{
   module_initialization_70___bexit(((long) 0), "READ_INCLUDE");
   module_initialization_70___eval(((long) 0), "READ_INCLUDE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "READ_INCLUDE");
   module_initialization_70___error(((long) 0), "READ_INCLUDE");
   module_initialization_70___r4_control_features_6_9(((long) 0), "READ_INCLUDE");
   module_initialization_70___reader(((long) 0), "READ_INCLUDE");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "READ_INCLUDE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_read_include()
{
   {
      obj_t cnst_port_138_151;
      cnst_port_138_151 = open_input_string(string1194_read_include);
      {
	 long i_152;
	 i_152 = ((long) 0);
       loop_153:
	 {
	    bool_t test1195_154;
	    test1195_154 = (i_152 == ((long) -1));
	    if (test1195_154)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1196_155;
		    {
		       obj_t list1197_156;
		       {
			  obj_t arg1199_157;
			  arg1199_157 = BNIL;
			  list1197_156 = MAKE_PAIR(cnst_port_138_151, arg1199_157);
		       }
		       arg1196_155 = read___reader(list1197_156);
		    }
		    CNST_TABLE_SET(i_152, arg1196_155);
		 }
		 {
		    int aux_158;
		    {
		       long aux_181;
		       aux_181 = (i_152 - ((long) 1));
		       aux_158 = (int) (aux_181);
		    }
		    {
		       long i_184;
		       i_184 = (long) (aux_158);
		       i_152 = i_184;
		       goto loop_153;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_read_include()
{
   return (_include_read__106_read_include = BNIL,
      BUNSPEC);
}


/* read-include */ obj_t 
read_include_201_read_include(obj_t file_1)
{
   {
      obj_t cell_5;
      cell_5 = assoc___r4_pairs_and_lists_6_3(file_1, _include_read__106_read_include);
      if (PAIRP(cell_5))
	{
	   return CDR(cell_5);
	}
      else
	{
	   {
	      obj_t list1011_7;
	      {
		 obj_t arg1016_9;
		 {
		    obj_t arg1018_10;
		    {
		       obj_t arg1025_12;
		       {
			  obj_t aux_190;
			  aux_190 = BCHAR(((unsigned char) '\n'));
			  arg1025_12 = MAKE_PAIR(aux_190, BNIL);
		       }
		       arg1018_10 = MAKE_PAIR(string1189_read_include, arg1025_12);
		    }
		    arg1016_9 = MAKE_PAIR(file_1, arg1018_10);
		 }
		 list1011_7 = MAKE_PAIR(string1190_read_include, arg1016_9);
	      }
	      verbose_tools_speek(BINT(((long) 2)), list1011_7);
	   }
	   {
	      obj_t fname_14;
	      fname_14 = find_file_path_55_tools_file(file_1, _load_path__54___eval);
	      if (STRINGP(fname_14))
		{
		   obj_t port_16;
		   port_16 = open_input_file_61___r4_ports_6_10_1(fname_14, BNIL);
		   if (INPUT_PORTP(port_16))
		     {
			obj_t handler_113;
			handler_113 = make_fx_procedure(handler_read_include, ((long) 4), ((long) 1));
			PROCEDURE_SET(handler_113, ((long) 0), port_16);
			{
			   obj_t armed1005_19;
			   obj_t handler1002_20;
			   armed1005_19 = MAKE_CELL(BUNSPEC);
			   handler1002_20 = MAKE_CELL(BUNSPEC);
			   {
			      obj_t body1004_109;
			      obj_t rhandler1003_111;
			      body1004_109 = make_fx_procedure(body1004_read_include, ((long) 0), ((long) 2));
			      rhandler1003_111 = make_fx_procedure(rhandler1003_read_include, ((long) 4), ((long) 2));
			      PROCEDURE_SET(body1004_109, ((long) 0), port_16);
			      PROCEDURE_SET(body1004_109, ((long) 1), file_1);
			      PROCEDURE_SET(rhandler1003_111, ((long) 0), armed1005_19);
			      PROCEDURE_SET(rhandler1003_111, ((long) 1), handler1002_20);
			      CELL_SET(handler1002_20, handler_113);
			      CELL_SET(armed1005_19, BTRUE);
			      return handling_function1036_read_include(body1004_109, rhandler1003_111, handler1002_20, armed1005_19);
			   }
			}
		     }
		   else
		     {
			return user_error_151_tools_error(string1191_read_include, string1192_read_include, file_1, BNIL);
		     }
		}
	      else
		{
		   return user_error_151_tools_error(string1191_read_include, string1193_read_include, file_1, BNIL);
		}
	   }
	}
   }
}


/* handling_function1036 */ obj_t 
handling_function1036_read_include(obj_t body1004_150, obj_t rhandler1003_149, obj_t handler1002_148, obj_t armed1005_147)
{
   jmp_buf jmpbuf;
   obj_t an_exit1006_24;
   if (SET_EXIT(an_exit1006_24))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1006_24 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1006_24, ((bool_t) 1));
	   {
	      obj_t an_exitd1007_25;
	      an_exitd1007_25 = exitd_top;
	      {
		 obj_t escape_110;
		 escape_110 = make_fx_procedure(escape_read_include, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_110, ((long) 0), an_exitd1007_25);
		 {
		    obj_t res1009_28;
		    {
		       obj_t arg1039_108;
		       obj_t arg1038_112;
		       arg1039_108 = make_fx_procedure(arg1039_read_include, ((long) 0), ((long) 1));
		       arg1038_112 = make_fx_procedure(arg1038_read_include, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1039_108, ((long) 0), armed1005_147);
		       PROCEDURE_SET(arg1038_112, ((long) 0), an_exitd1007_25);
		       PROCEDURE_SET(arg1038_112, ((long) 1), armed1005_147);
		       PROCEDURE_SET(arg1038_112, ((long) 2), handler1002_148);
		       PROCEDURE_SET(arg1038_112, ((long) 3), rhandler1003_149);
		       PROCEDURE_SET(arg1038_112, ((long) 4), escape_110);
		       res1009_28 = dynamic_wind_31___r4_control_features_6_9(arg1038_112, body1004_150, arg1039_108);
		    }
		    POP_EXIT();
		    return res1009_28;
		 }
	      }
	   }
	}
     }
}


/* _read-include1188 */ obj_t 
_read_include1188_199_read_include(obj_t env_114, obj_t file_115)
{
   return read_include_201_read_include(file_115);
}


/* arg1039 */ obj_t 
arg1039_read_include(obj_t env_116)
{
   {
      obj_t armed1005_117;
      armed1005_117 = PROCEDURE_REF(env_116, ((long) 0));
      {
	 {
	    bool_t test_232;
	    {
	       obj_t aux_233;
	       aux_233 = CELL_REF(armed1005_117);
	       test_232 = CBOOL(aux_233);
	    }
	    if (test_232)
	      {
		 CELL_SET(armed1005_117, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1004 */ obj_t 
body1004_read_include(obj_t env_119)
{
   {
      obj_t port_120;
      obj_t file_121;
      port_120 = PROCEDURE_REF(env_119, ((long) 0));
      file_121 = PROCEDURE_REF(env_119, ((long) 1));
      {
	 {
	    obj_t first_41;
	    {
	       obj_t list1164_64;
	       {
		  obj_t arg1175_65;
		  arg1175_65 = MAKE_PAIR(BTRUE, BNIL);
		  list1164_64 = MAKE_PAIR(port_120, arg1175_65);
	       }
	       first_41 = read___reader(list1164_64);
	    }
	    {
	       obj_t direc_42;
	       {
		  bool_t test_241;
		  if (PAIRP(first_41))
		    {
		       obj_t aux_246;
		       obj_t aux_244;
		       aux_246 = CNST_TABLE_REF(((long) 0));
		       aux_244 = CAR(first_41);
		       test_241 = (aux_244 == aux_246);
		    }
		  else
		    {
		       test_241 = ((bool_t) 0);
		    }
		  if (test_241)
		    {
		       direc_42 = first_41;
		    }
		  else
		    {
		       direc_42 = BNIL;
		    }
	       }
	       {
		  {
		     obj_t aux_43;
		     obj_t sexp_44;
		     {
			obj_t arg1053_46;
			if (PAIRP(direc_42))
			  {
			     obj_t list1068_49;
			     {
				obj_t arg1077_50;
				arg1077_50 = MAKE_PAIR(BTRUE, BNIL);
				list1068_49 = MAKE_PAIR(port_120, arg1077_50);
			     }
			     arg1053_46 = read___reader(list1068_49);
			  }
			else
			  {
			     arg1053_46 = first_41;
			  }
			aux_43 = arg1053_46;
			sexp_44 = BNIL;
		      loop_45:
			{
			   bool_t test1139_52;
			   test1139_52 = EOF_OBJECTP(aux_43);
			   if (test1139_52)
			     {
				obj_t r_53;
				{
				   obj_t arg1142_54;
				   arg1142_54 = reverse__39___r4_pairs_and_lists_6_3(sexp_44);
				   r_53 = MAKE_PAIR(direc_42, arg1142_54);
				}
				close_input_port(port_120);
				{
				   obj_t arg1187_95;
				   arg1187_95 = MAKE_PAIR(file_121, r_53);
				   {
				      obj_t obj2_99;
				      obj2_99 = _include_read__106_read_include;
				      _include_read__106_read_include = MAKE_PAIR(arg1187_95, obj2_99);
				   }
				}
				return r_53;
			     }
			   else
			     {
				obj_t arg1144_55;
				obj_t arg1145_56;
				{
				   obj_t list1146_57;
				   {
				      obj_t arg1150_58;
				      arg1150_58 = MAKE_PAIR(BTRUE, BNIL);
				      list1146_57 = MAKE_PAIR(port_120, arg1150_58);
				   }
				   arg1144_55 = read___reader(list1146_57);
				}
				arg1145_56 = MAKE_PAIR(aux_43, sexp_44);
				{
				   obj_t sexp_266;
				   obj_t aux_265;
				   aux_265 = arg1144_55;
				   sexp_266 = arg1145_56;
				   sexp_44 = sexp_266;
				   aux_43 = aux_265;
				   goto loop_45;
				}
			     }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* arg1038 */ obj_t 
arg1038_read_include(obj_t env_122)
{
   {
      obj_t rhandler1003_126;
      obj_t escape_127;
      rhandler1003_126 = PROCEDURE_REF(env_122, ((long) 3));
      escape_127 = PROCEDURE_REF(env_122, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1003_126, escape_127);
      }
   }
}


/* escape */ obj_t 
escape_read_include(obj_t env_128, obj_t val1008_130)
{
   {
      obj_t an_exitd1007_129;
      an_exitd1007_129 = PROCEDURE_REF(env_128, ((long) 0));
      {
	 obj_t val1008_26;
	 val1008_26 = val1008_130;
	 return unwind_until__178___bexit(an_exitd1007_129, val1008_26);
      }
   }
}


/* rhandler1003 */ obj_t 
rhandler1003_read_include(obj_t env_131, obj_t esc_134, obj_t obj_135, obj_t proc_136, obj_t msg_137)
{
   {
      obj_t armed1005_132;
      obj_t handler1002_133;
      armed1005_132 = PROCEDURE_REF(env_131, ((long) 0));
      handler1002_133 = PROCEDURE_REF(env_131, ((long) 1));
      {
	 obj_t esc_35;
	 obj_t obj_36;
	 obj_t proc_37;
	 obj_t msg_38;
	 esc_35 = esc_134;
	 obj_36 = obj_135;
	 proc_37 = proc_136;
	 msg_38 = msg_137;
	 CELL_SET(armed1005_132, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_276;
	    aux_276 = CELL_REF(handler1002_133);
	    return PROCEDURE_ENTRY(aux_276) (CELL_REF(handler1002_133), esc_35, obj_36, proc_37, msg_38, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_read_include(obj_t env_139, obj_t escape_141, obj_t proc_142, obj_t mes_143, obj_t obj_144)
{
   {
      obj_t port_140;
      port_140 = PROCEDURE_REF(env_139, ((long) 0));
      {
	 obj_t escape_69;
	 obj_t proc_70;
	 obj_t mes_71;
	 obj_t obj_72;
	 escape_69 = escape_141;
	 proc_70 = proc_142;
	 mes_71 = mes_143;
	 obj_72 = obj_144;
	 notify_error_43___error(proc_70, mes_71, obj_72);
	 close_input_port(port_140);
	 return exit_bigloo_229_init_main(BINT(((long) -3)));
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_read_include()
{
   module_initialization_70_engine_param(((long) 0), "READ_INCLUDE");
   module_initialization_70_engine_engine(((long) 0), "READ_INCLUDE");
   module_initialization_70_tools_speek(((long) 0), "READ_INCLUDE");
   module_initialization_70_tools_file(((long) 0), "READ_INCLUDE");
   module_initialization_70_tools_error(((long) 0), "READ_INCLUDE");
   return module_initialization_70_init_main(((long) 0), "READ_INCLUDE");
}
