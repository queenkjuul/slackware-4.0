/*===========================================================================*/
/*   (Llib/object.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>


/* Object type definitions */

static obj_t _class_hash_144___object(obj_t, obj_t);
static obj_t symbol1504___object = BUNSPEC;
static obj_t symbol1490___object = BUNSPEC;
extern long object_class_num_83___object(object_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t object_write_132___object(object_t, obj_t);
static obj_t method_init_76___object();
extern obj_t string_to_symbol(char *);
static obj_t _add_generic_1471_11___object(obj_t, obj_t, obj_t);
static obj_t _struct_object__object1480_1___object(obj_t, obj_t, obj_t);
static obj_t _class_field_indexed__52___object(obj_t, obj_t);
static obj_t _method_array_ref1469_58___object(obj_t, obj_t, obj_t);
extern obj_t current_output_port;
static obj_t object_display_default1017_64___object(object_t, obj_t);
extern obj_t find_inline_method_206___object(object_t, obj_t);
extern obj_t generic_pre_method_set__80___object(obj_t, obj_t);
static obj_t add_method_proc_or_num__68___object(obj_t, obj_t, obj_t);
static obj_t _nb_classes__240___object = BUNSPEC;
static obj_t _class__187___object(obj_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _object_display1484_134___object(obj_t, obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _allocate_instance1481_81___object(obj_t, obj_t);
extern bool_t class_fields__63___object(obj_t);
static obj_t toplevel_init_63___object();
extern object_t struct__object_175___object(obj_t);
static obj_t _class_subclasses_86___object(obj_t, obj_t);
static obj_t _object_equal_1483_25___object(obj_t, obj_t, obj_t);
static obj_t extend_vector_160___object(obj_t, bool_t, long);
static obj_t _object__148___object(obj_t, obj_t);
extern obj_t create_vector(long);
static obj_t _object_write_default1018_31___object(obj_t, obj_t, obj_t);
static obj_t _class_fields__244___object(obj_t, obj_t);
extern obj_t class_name_139___object(obj_t);
static obj_t _next_class_num1478_249___object(obj_t, obj_t);
extern long next_class_num_45___object(long);
static obj_t _allocate_object_100___object(obj_t);
static obj_t _class_field_len_accessor_58___object(obj_t, obj_t);
static obj_t _make_object_124___object(obj_t);
static obj_t _generics__29___object = BUNSPEC;
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t class_fields_215___object(obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern long class_hash_237___object(obj_t);
static obj_t _object__struct1486_66___object(obj_t, obj_t);
extern obj_t find_method_204___object(object_t, obj_t);
obj_t object___object = BUNSPEC;
static obj_t _is_a__25___object(obj_t, obj_t, obj_t);
extern obj_t class_subclasses_99___object(obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
static obj_t loop___object(obj_t, obj_t, obj_t, obj_t);
extern bool_t class_field_mutable__211___object(obj_t);
extern bool_t object__44___object(obj_t);
extern obj_t bigloo_type_error_msg_127___error(obj_t, obj_t, obj_t);
static obj_t lambda1074___object(obj_t, obj_t);
static obj_t _class_num_205___object(obj_t, obj_t);
static obj_t _class_depth_246___object(obj_t, obj_t);
extern obj_t class_field_accessor_18___object(obj_t);
static obj_t _class_field_mutator_181___object(obj_t, obj_t);
extern object_t make_object_188___object();
extern bool_t is_a__118___object(obj_t, obj_t);
extern object_t allocate_instance_244___object(obj_t);
static obj_t _wide_object_1482_198___object(obj_t, obj_t);
static obj_t object__struct_default1019_241___object(object_t);
extern obj_t object_display_243___object(object_t, obj_t);
static obj_t _object_class1464_116___object(obj_t, obj_t);
static obj_t _generic_pre_method_set_1468_111___object(obj_t, obj_t, obj_t);
static obj_t _object_display_default1017_129___object(obj_t, obj_t, obj_t);
static obj_t object_write_default1018_79___object(object_t, obj_t);
extern obj_t object_class_242___object(object_t);
extern obj_t module_initialization_70___object(long, char *);
static obj_t _class_constructor_88___object(obj_t, obj_t);
static obj_t double_nb_classes__118___object();
static obj_t _generic_pre_method1467_173___object(obj_t, obj_t);
extern obj_t find_runtime_type_96___error(obj_t);
static obj_t _generic_default1465_115___object(obj_t, obj_t);
extern bool_t class_field_indexed__189___object(obj_t);
static obj_t object_init_111___object();
static obj_t _find_super_class_method1476_137___object(obj_t, obj_t, obj_t, obj_t);
static obj_t _find_method1474_47___object(obj_t, obj_t, obj_t);
static obj_t _add_class_1470_139___object(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _class_field_name_107___object(obj_t, obj_t);
extern long class_depth_60___object(obj_t);
static object_t struct_object__object_default1020_163___object(object_t, obj_t);
extern obj_t class_field_len_accessor_212___object(obj_t);
extern obj_t class_constructor_163___object(obj_t);
static obj_t _struct__object1479_161___object(obj_t, obj_t);
static obj_t _add_inlined_method_1473_211___object(obj_t, obj_t, obj_t, obj_t);
obj_t _classes__134___object = BUNSPEC;
extern long class_num_218___object(obj_t);
static obj_t _find_inline_method1475_164___object(obj_t, obj_t, obj_t);
extern obj_t generic_pre_method_24___object(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _class_super_213___object(obj_t, obj_t);
extern obj_t method_array_ref_188___object(obj_t, long);
static long _nb_generics_max__185___object;
static obj_t _object_class_num1462_140___object(obj_t, obj_t);
static obj_t object_write_display_42___object(object_t, obj_t, bool_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
static long _nb_classes_max__8___object;
static obj_t generics_add_class__12___object(long, long);
extern bool_t wide_object__208___object(object_t);
static obj_t _object_class_num_set_1463_68___object(obj_t, obj_t, obj_t);
extern obj_t find_method_from_44___object(object_t, obj_t, obj_t);
static obj_t _struct_object__object_default1020_71___object(obj_t, obj_t, obj_t);
extern obj_t class_field_name_28___object(obj_t);
static obj_t _object_write1485_174___object(obj_t, obj_t, obj_t);
static long _nb_generics__142___object;
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
static obj_t _add_method_1472_99___object(obj_t, obj_t, obj_t, obj_t);
static obj_t _class_name_50___object(obj_t, obj_t);
extern object_t allocate_object_214___object();
extern obj_t generic_default_171___object(obj_t);
static obj_t require_initialization_114___object = BUNSPEC;
static obj_t _class_field_mutable__51___object(obj_t, obj_t);
static obj_t _find_method_from1477_94___object(obj_t, obj_t, obj_t, obj_t);
static obj_t _class_fields_252___object(obj_t, obj_t);
extern bool_t object_equal__12___object(object_t, object_t);
extern bool_t class__60___object(obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t _class_field_accessor_230___object(obj_t, obj_t);
static obj_t double_nb_generics__239___object();
static obj_t _generic_method_array1466_92___object(obj_t, obj_t);
static obj_t cnst_init_137___object();
static obj_t _object__struct_default1019_206___object(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t generic_method_array_21___object(obj_t);
static obj_t initialize_objects__138___object();
extern obj_t class_field_mutator_255___object(obj_t);
extern obj_t make_vector(long, obj_t);
extern obj_t object_class_num_set__124___object(obj_t, long);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( generic_pre_method_set__env_134___object, _generic_pre_method_set_1468_111___object1510, _generic_pre_method_set_1468_111___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( class_field_indexed__env_214___object, _class_field_indexed__52___object1511, _class_field_indexed__52___object, 0L, 1 );
DEFINE_STATIC_PROCEDURE( object__struct_default1019_env_180___object, _object__struct_default1019_206___object1512, _object__struct_default1019_206___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( find_method_from_env_43___object, _find_method_from1477_94___object1513, _find_method_from1477_94___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( find_super_class_method_env_187___object, _find_super_class_method1476_137___object1514, _find_super_class_method1476_137___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( add_method__env_233___object, _add_method_1472_99___object1515, _add_method_1472_99___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( class__env_46___object, _class__187___object1516, _class__187___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_field_mutable__env_219___object, _class_field_mutable__51___object1517, _class_field_mutable__51___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( generic_pre_method_env_6___object, _generic_pre_method1467_173___object1518, _generic_pre_method1467_173___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_constructor_env_255___object, _class_constructor_88___object1519, _class_constructor_88___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( method_array_ref_env_14___object, _method_array_ref1469_58___object1520, _method_array_ref1469_58___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( object__env_43___object, _object__148___object1521, _object__148___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( add_inlined_method__env_212___object, _add_inlined_method_1473_211___object1522, _add_inlined_method_1473_211___object, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( struct__object_env_176___object, _struct__object1479_161___object1523, _struct__object1479_161___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_hash_env_30___object, _class_hash_144___object1524, _class_hash_144___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_name_env_116___object, _class_name_50___object1525, _class_name_50___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( allocate_object_env_103___object, _allocate_object_100___object1526, _allocate_object_100___object, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( find_inline_method_env_227___object, _find_inline_method1475_164___object1527, _find_inline_method1475_164___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( wide_object__env_54___object, _wide_object_1482_198___object1528, _wide_object_1482_198___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( object_class_env_200___object, _object_class1464_116___object1529, _object_class1464_116___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_super_env_1___object, _class_super_213___object1530, _class_super_213___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( object_class_num_set__env_55___object, _object_class_num_set_1463_68___object1531, _object_class_num_set_1463_68___object, 0L, 2 );
DEFINE_STATIC_PROCEDURE( struct_object__object_default1020_env_255___object, _struct_object__object_default1020_71___object1532, _struct_object__object_default1020_71___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( class_field_accessor_env_90___object, _class_field_accessor_230___object1533, _class_field_accessor_230___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_fields__env_111___object, _class_fields__244___object1534, _class_fields__244___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_depth_env_46___object, _class_depth_246___object1535, _class_depth_246___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( is_a__env_220___object, _is_a__25___object1536, _is_a__25___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( allocate_instance_env_212___object, _allocate_instance1481_81___object1537, _allocate_instance1481_81___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_field_name_env_131___object, _class_field_name_107___object1538, _class_field_name_107___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_num_env_12___object, _class_num_205___object1539, _class_num_205___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( add_class__env_135___object, _add_class_1470_139___object1540, _add_class_1470_139___object, 0L, 6 );
DEFINE_EXPORT_GENERIC( struct_object__object_env_209___object, _struct_object__object1480_1___object1541, _struct_object__object1480_1___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( class_field_len_accessor_env_145___object, _class_field_len_accessor_58___object1542, _class_field_len_accessor_58___object, 0L, 1 );
DEFINE_STATIC_PROCEDURE( object_display_default1017_env_41___object, _object_display_default1017_129___object1543, va_generic_entry, _object_display_default1017_129___object, -2 );
DEFINE_STATIC_PROCEDURE( proc1493___object, lambda1074___object1544, va_generic_entry, lambda1074___object, -1 );
DEFINE_EXPORT_PROCEDURE( class_fields_env_167___object, _class_fields_252___object1545, _class_fields_252___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_object_env_14___object, _make_object_124___object1546, _make_object_124___object, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( generic_default_env_115___object, _generic_default1465_115___object1547, _generic_default1465_115___object, 0L, 1 );
DEFINE_EXPORT_GENERIC( object_write_env_104___object, _object_write1485_174___object1548, va_generic_entry, _object_write1485_174___object, -2 );
DEFINE_EXPORT_GENERIC( object_display_env_20___object, _object_display1484_134___object1549, va_generic_entry, _object_display1484_134___object, -2 );
DEFINE_STRING( string1499___object, string1499___object1550, "allocate-instance", 17 );
DEFINE_STRING( string1498___object, string1498___object1551, "Illegal class", 13 );
DEFINE_STRING( string1508___object, string1508___object1552, "This structure can't be converted", 33 );
DEFINE_STRING( string1497___object, string1497___object1553, "arity mismatch", 14 );
DEFINE_STRING( string1507___object, string1507___object1554, "struct+object->object", 21 );
DEFINE_STRING( string1496___object, string1496___object1555, "add-method!", 11 );
DEFINE_STRING( string1506___object, string1506___object1556, "This object can't be converted", 30 );
DEFINE_STRING( string1495___object, string1495___object1557, "No default behaviour", 20 );
DEFINE_STRING( string1505___object, string1505___object1558, "object->struct", 14 );
DEFINE_STRING( string1494___object, string1494___object1559, "generic", 7 );
DEFINE_STRING( string1503___object, string1503___object1560, "...", 3 );
DEFINE_STRING( string1492___object, string1492___object1561, "Illegal super class for class", 29 );
DEFINE_STRING( string1502___object, string1502___object1562, "#|", 2 );
DEFINE_STRING( string1491___object, string1491___object1563, "add-class!", 10 );
DEFINE_STRING( string1501___object, string1501___object1564, " [", 2 );
DEFINE_STRING( string1489___object, string1489___object1565, "class-fields", 12 );
DEFINE_STRING( string1500___object, string1500___object1566, "Can't find class", 16 );
DEFINE_STRING( string1488___object, string1488___object1567, "Class", 5 );
DEFINE_STRING( string1487___object, string1487___object1568, "runtime type error", 18 );
DEFINE_EXPORT_PROCEDURE( class_subclasses_env_184___object, _class_subclasses_86___object1569, _class_subclasses_86___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( find_method_env_236___object, _find_method1474_47___object1570, _find_method1474_47___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( next_class_num_env_125___object, _next_class_num1478_249___object1571, _next_class_num1478_249___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( add_generic__env_128___object, _add_generic_1471_11___object1572, _add_generic_1471_11___object, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( generic_method_array_env_123___object, _generic_method_array1466_92___object1573, _generic_method_array1466_92___object, 0L, 1 );
DEFINE_STATIC_PROCEDURE( object_write_default1018_env_141___object, _object_write_default1018_31___object1574, va_generic_entry, _object_write_default1018_31___object, -2 );
DEFINE_EXPORT_PROCEDURE( object_equal__env_74___object, _object_equal_1483_25___object1575, _object_equal_1483_25___object, 0L, 2 );
DEFINE_EXPORT_GENERIC( object__struct_env_210___object, _object__struct1486_66___object1576, _object__struct1486_66___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( object_class_num_env_245___object, _object_class_num1462_140___object1577, _object_class_num1462_140___object, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( class_field_mutator_env_194___object, _class_field_mutator_181___object1578, _class_field_mutator_181___object, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___object(long checksum_1983, char * from_1984)
{
if(CBOOL(require_initialization_114___object)){
require_initialization_114___object = BBOOL(((bool_t)0));
cnst_init_137___object();
object_init_111___object();
method_init_76___object();
toplevel_init_63___object();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___object()
{
symbol1490___object = string_to_symbol("DONE");
return (symbol1504___object = string_to_symbol("OBJECT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___object()
{
BUNSPEC;
BUNSPEC;
BUNSPEC;
BUNSPEC;
BUNSPEC;
BUNSPEC;
return BUNSPEC;
}


/* class? */bool_t class__60___object(obj_t obj_11)
{
if(VECTORP(obj_11)){
long aux_1996;
aux_1996 = VECTOR_LENGTH(obj_11);
return (aux_1996==((long)10));
}
 else {
return ((bool_t)0);
}
}


/* _class? */obj_t _class__187___object(obj_t env_1789, obj_t obj_1790)
{
{
bool_t aux_1999;
{
obj_t obj_1920;
obj_1920 = obj_1790;
if(VECTORP(obj_1920)){
long aux_2002;
aux_2002 = VECTOR_LENGTH(obj_1920);
aux_1999 = (aux_2002==((long)10));
}
 else {
aux_1999 = ((bool_t)0);
}
}
return BBOOL(aux_1999);
}
}


/* class-name */obj_t class_name_139___object(obj_t class_12)
{
return VECTOR_REF(class_12, ((long)0));
}


/* _class-name */obj_t _class_name_50___object(obj_t env_1791, obj_t class_1792)
{
return class_name_139___object(class_1792);
}


/* class-num */long class_num_218___object(obj_t class_13)
{
{
obj_t aux_2008;
aux_2008 = VECTOR_REF(class_13, ((long)1));
return (long)CINT(aux_2008);
}
}


/* _class-num */obj_t _class_num_205___object(obj_t env_1793, obj_t class_1794)
{
{
long aux_2011;
aux_2011 = class_num_218___object(class_1794);
return BINT(aux_2011);
}
}


/* class-depth */long class_depth_60___object(obj_t class_14)
{
{
obj_t aux_2014;
aux_2014 = VECTOR_REF(class_14, ((long)2));
return (long)CINT(aux_2014);
}
}


/* _class-depth */obj_t _class_depth_246___object(obj_t env_1795, obj_t class_1796)
{
{
long aux_2017;
aux_2017 = class_depth_60___object(class_1796);
return BINT(aux_2017);
}
}


/* class-fields */obj_t class_fields_215___object(obj_t class_15)
{
{
bool_t test_2020;
if(VECTORP(class_15)){
long aux_2023;
aux_2023 = VECTOR_LENGTH(class_15);
test_2020 = (aux_2023==((long)10));
}
 else {
test_2020 = ((bool_t)0);
}
if(test_2020){
return VECTOR_REF(class_15, ((long)8));
}
 else {
obj_t arg1026_370;
{
obj_t arg1029_373;
arg1029_373 = find_runtime_type_96___error(class_15);
arg1026_370 = bigloo_type_error_msg_127___error(string1487___object, string1488___object, arg1029_373);
}
FAILURE(string1489___object,arg1026_370,class_15);}
}
}


/* _class-fields */obj_t _class_fields_252___object(obj_t env_1797, obj_t class_1798)
{
return class_fields_215___object(class_1798);
}


/* class-fields? */bool_t class_fields__63___object(obj_t fields_16)
{
{
bool_t _ortest_1007_1921;
_ortest_1007_1921 = PAIRP(fields_16);
if(_ortest_1007_1921){
return _ortest_1007_1921;
}
 else {
return NULLP(fields_16);
}
}
}


/* _class-fields? */obj_t _class_fields__244___object(obj_t env_1799, obj_t fields_1800)
{
{
bool_t aux_2034;
{
obj_t fields_1922;
fields_1922 = fields_1800;
{
bool_t _ortest_1007_1923;
_ortest_1007_1923 = PAIRP(fields_1922);
if(_ortest_1007_1923){
aux_2034 = _ortest_1007_1923;
}
 else {
aux_2034 = NULLP(fields_1922);
}
}
}
return BBOOL(aux_2034);
}
}


/* class-field-name */obj_t class_field_name_28___object(obj_t field_17)
{
return VECTOR_REF(field_17, ((long)0));
}


/* _class-field-name */obj_t _class_field_name_107___object(obj_t env_1801, obj_t field_1802)
{
{
obj_t field_1924;
field_1924 = field_1802;
return VECTOR_REF(field_1924, ((long)0));
}
}


/* class-field-indexed? */bool_t class_field_indexed__189___object(obj_t field_18)
{
{
obj_t aux_2041;
aux_2041 = VECTOR_REF(field_18, ((long)3));
return PROCEDUREP(aux_2041);
}
}


/* _class-field-indexed? */obj_t _class_field_indexed__52___object(obj_t env_1803, obj_t field_1804)
{
{
bool_t aux_2044;
{
obj_t field_1925;
field_1925 = field_1804;
{
obj_t aux_2045;
aux_2045 = VECTOR_REF(field_1925, ((long)3));
aux_2044 = PROCEDUREP(aux_2045);
}
}
return BBOOL(aux_2044);
}
}


/* class-field-accessor */obj_t class_field_accessor_18___object(obj_t field_19)
{
return VECTOR_REF(field_19, ((long)1));
}


/* _class-field-accessor */obj_t _class_field_accessor_230___object(obj_t env_1805, obj_t field_1806)
{
{
obj_t field_1926;
field_1926 = field_1806;
return VECTOR_REF(field_1926, ((long)1));
}
}


/* class-field-mutable? */bool_t class_field_mutable__211___object(obj_t field_20)
{
{
obj_t aux_2051;
aux_2051 = VECTOR_REF(field_20, ((long)2));
return PROCEDUREP(aux_2051);
}
}


/* _class-field-mutable? */obj_t _class_field_mutable__51___object(obj_t env_1807, obj_t field_1808)
{
{
bool_t aux_2054;
{
obj_t field_1927;
field_1927 = field_1808;
{
obj_t aux_2055;
aux_2055 = VECTOR_REF(field_1927, ((long)2));
aux_2054 = PROCEDUREP(aux_2055);
}
}
return BBOOL(aux_2054);
}
}


/* class-field-mutator */obj_t class_field_mutator_255___object(obj_t field_21)
{
return VECTOR_REF(field_21, ((long)2));
}


/* _class-field-mutator */obj_t _class_field_mutator_181___object(obj_t env_1809, obj_t field_1810)
{
{
obj_t field_1928;
field_1928 = field_1810;
return VECTOR_REF(field_1928, ((long)2));
}
}


/* class-field-len-accessor */obj_t class_field_len_accessor_212___object(obj_t field_22)
{
return VECTOR_REF(field_22, ((long)3));
}


/* _class-field-len-accessor */obj_t _class_field_len_accessor_58___object(obj_t env_1811, obj_t field_1812)
{
{
obj_t field_1929;
field_1929 = field_1812;
return VECTOR_REF(field_1929, ((long)3));
}
}


/* class-super */obj_t class_super_145___object(obj_t class_23)
{
return VECTOR_REF(class_23, ((long)3));
}


/* _class-super */obj_t _class_super_213___object(obj_t env_1813, obj_t class_1814)
{
return class_super_145___object(class_1814);
}


/* class-subclasses */obj_t class_subclasses_99___object(obj_t class_24)
{
return VECTOR_REF(class_24, ((long)4));
}


/* _class-subclasses */obj_t _class_subclasses_86___object(obj_t env_1815, obj_t class_1816)
{
return class_subclasses_99___object(class_1816);
}


/* class-hash */long class_hash_237___object(obj_t class_29)
{
{
obj_t aux_2067;
aux_2067 = VECTOR_REF(class_29, ((long)7));
return (long)CINT(aux_2067);
}
}


/* _class-hash */obj_t _class_hash_144___object(obj_t env_1817, obj_t class_1818)
{
{
long aux_2070;
aux_2070 = class_hash_237___object(class_1818);
return BINT(aux_2070);
}
}


/* class-constructor */obj_t class_constructor_163___object(obj_t class_30)
{
return VECTOR_REF(class_30, ((long)9));
}


/* _class-constructor */obj_t _class_constructor_88___object(obj_t env_1819, obj_t class_1820)
{
return class_constructor_163___object(class_1820);
}


/* initialize-objects! */obj_t initialize_objects__138___object()
{
{
bool_t test1032_377;
{
obj_t obj_911;
obj_911 = _nb_classes__240___object;
test1032_377 = INTEGERP(obj_911);
}
if(test1032_377){
return symbol1490___object;
}
 else {
_nb_classes__240___object = BINT(((long)0));
_nb_classes_max__8___object = ((long)50);
_classes__134___object = make_vector(_nb_classes_max__8___object, BFALSE);
_nb_generics_max__185___object = ((long)50);
_nb_generics__142___object = ((long)0);
return (_generics__29___object = make_vector(_nb_generics_max__185___object, BFALSE),
BUNSPEC);
}
}
}


/* extend-vector */obj_t extend_vector_160___object(obj_t old_vec_37_31, bool_t fill_32, long extend_33)
{
{
long old_len_227_912;
old_len_227_912 = VECTOR_LENGTH(old_vec_37_31);
{
obj_t new_vec_94_914;
{
obj_t aux_2083;
long aux_2081;
aux_2083 = BBOOL(fill_32);
aux_2081 = (extend_33+old_len_227_912);
new_vec_94_914 = make_vector(aux_2081, aux_2083);
}
{
{
long i_916;
i_916 = ((long)0);
loop_915:
if((i_916==old_len_227_912)){
return new_vec_94_914;
}
 else {
{
obj_t aux_2088;
aux_2088 = VECTOR_REF(old_vec_37_31, i_916);
VECTOR_SET(new_vec_94_914, i_916, aux_2088);
}
{
long i_2091;
i_2091 = (i_916+((long)1));
i_916 = i_2091;
goto loop_915;
}
}
}
}
}
}
}


/* double-nb-classes! */obj_t double_nb_classes__118___object()
{
{
long z2_958;
z2_958 = _nb_classes_max__8___object;
_nb_classes_max__8___object = (((long)2)*z2_958);
}
{
obj_t old_vec_37_959;
old_vec_37_959 = _classes__134___object;
_classes__134___object = extend_vector_160___object(old_vec_37_959, ((bool_t)0), VECTOR_LENGTH(old_vec_37_959));
}
{
long i_387;
i_387 = ((long)0);
loop_388:
{
bool_t test1038_389;
{
long n2_964;
n2_964 = _nb_generics__142___object;
test1038_389 = (i_387==n2_964);
}
if(test1038_389){
return symbol1490___object;
}
 else {
obj_t generic_390;
{
obj_t vector_965;
vector_965 = _generics__29___object;
generic_390 = VECTOR_REF(vector_965, i_387);
}
{
obj_t old_method_array_215_391;
old_method_array_215_391 = PROCEDURE_REF(generic_390, ((long)1));
{
{
obj_t arg1039_392;
arg1039_392 = extend_vector_160___object(old_method_array_215_391, ((bool_t)0), VECTOR_LENGTH(old_method_array_215_391));
PROCEDURE_SET(generic_390, ((long)1), arg1039_392);
}
{
long i_2103;
i_2103 = (i_387+((long)1));
i_387 = i_2103;
goto loop_388;
}
}
}
}
}
}
}


/* double-nb-generics! */obj_t double_nb_generics__239___object()
{
{
long z2_977;
z2_977 = _nb_generics_max__185___object;
_nb_generics_max__185___object = (((long)2)*z2_977);
}
{
obj_t old_vec_37_978;
old_vec_37_978 = _generics__29___object;
return (_generics__29___object = extend_vector_160___object(old_vec_37_978, ((bool_t)0), VECTOR_LENGTH(old_vec_37_978)),
BUNSPEC);
}
}


/* object? */bool_t object__44___object(obj_t obj_36)
{
return (POINTERP( obj_36 ) && (TYPE( obj_36 ) >= OBJECT_TYPE));
}


/* _object? */obj_t _object__148___object(obj_t env_1821, obj_t obj_1822)
{
{
bool_t aux_2109;
{
obj_t obj_1930;
obj_1930 = obj_1822;
aux_2109 = (POINTERP( obj_1930 ) && (TYPE( obj_1930 ) >= OBJECT_TYPE));
}
return BBOOL(aux_2109);
}
}


/* object-class-num */long object_class_num_83___object(object_t obj_37)
{
return TYPE( obj_37 );
}


/* _object-class-num1462 */obj_t _object_class_num1462_140___object(obj_t env_1823, obj_t obj_1824)
{
{
long aux_2113;
{
object_t obj_1931;
obj_1931 = (object_t)(obj_1824);
aux_2113 = TYPE( obj_1931 );
}
return BINT(aux_2113);
}
}


/* object-class-num-set! */obj_t object_class_num_set__124___object(obj_t obj_38, long num_39)
{
return (((obj_t)CREF(obj_38))->header = MAKE_HEADER( num_39, 0 ), BUNSPEC);
}


/* _object-class-num-set!1463 */obj_t _object_class_num_set_1463_68___object(obj_t env_1825, obj_t obj_1826, obj_t num_1827)
{
{
obj_t obj_1932;
long num_1933;
obj_1932 = obj_1826;
num_1933 = (long)CINT(num_1827);
return (((obj_t)CREF(obj_1932))->header = MAKE_HEADER( num_1933, 0 ), BUNSPEC);
}
}


/* object-class */obj_t object_class_242___object(object_t object_40)
{
{
long arg1041_1934;
{
long arg1042_1935;
long arg1043_1936;
arg1042_1935 = TYPE( object_40 );
arg1043_1936 = OBJECT_TYPE;
arg1041_1934 = (arg1042_1935-arg1043_1936);
}
{
obj_t vector_1937;
vector_1937 = _classes__134___object;
return VECTOR_REF(vector_1937, arg1041_1934);
}
}
}


/* _object-class1464 */obj_t _object_class1464_116___object(obj_t env_1828, obj_t object_1829)
{
{
object_t object_1938;
object_1938 = (object_t)(object_1829);
{
long arg1041_1939;
{
long arg1042_1940;
long arg1043_1941;
arg1042_1940 = TYPE( object_1938 );
arg1043_1941 = OBJECT_TYPE;
arg1041_1939 = (arg1042_1940-arg1043_1941);
}
{
obj_t vector_1942;
vector_1942 = _classes__134___object;
return VECTOR_REF(vector_1942, arg1041_1939);
}
}
}
}


/* generic-default */obj_t generic_default_171___object(obj_t generic_41)
{
return PROCEDURE_REF(generic_41, ((long)0));
}


/* _generic-default1465 */obj_t _generic_default1465_115___object(obj_t env_1830, obj_t generic_1831)
{
{
obj_t generic_1943;
generic_1943 = generic_1831;
return PROCEDURE_REF(generic_1943, ((long)0));
}
}


/* generic-method-array */obj_t generic_method_array_21___object(obj_t generic_44)
{
return PROCEDURE_REF(generic_44, ((long)1));
}


/* _generic-method-array1466 */obj_t _generic_method_array1466_92___object(obj_t env_1832, obj_t generic_1833)
{
{
obj_t generic_1944;
generic_1944 = generic_1833;
return PROCEDURE_REF(generic_1944, ((long)1));
}
}


/* generic-pre-method */obj_t generic_pre_method_24___object(obj_t generic_47)
{
return PROCEDURE_REF(generic_47, ((long)2));
}


/* _generic-pre-method1467 */obj_t _generic_pre_method1467_173___object(obj_t env_1834, obj_t generic_1835)
{
{
obj_t generic_1945;
generic_1945 = generic_1835;
return PROCEDURE_REF(generic_1945, ((long)2));
}
}


/* generic-pre-method-set! */obj_t generic_pre_method_set__80___object(obj_t generic_48, obj_t pre_method_105_49)
{
return PROCEDURE_SET(generic_48, ((long)2), pre_method_105_49);
}


/* _generic-pre-method-set!1468 */obj_t _generic_pre_method_set_1468_111___object(obj_t env_1836, obj_t generic_1837, obj_t pre_method_105_1838)
{
{
obj_t generic_1946;
obj_t pre_method_105_1947;
generic_1946 = generic_1837;
pre_method_105_1947 = pre_method_105_1838;
return PROCEDURE_SET(generic_1946, ((long)2), pre_method_105_1947);
}
}


/* method-array-ref */obj_t method_array_ref_188___object(obj_t array_50, long offset_51)
{
{
long arg1044_1948;
{
long arg1045_1949;
arg1045_1949 = OBJECT_TYPE;
arg1044_1948 = (offset_51-arg1045_1949);
}
return VECTOR_REF(array_50, arg1044_1948);
}
}


/* _method-array-ref1469 */obj_t _method_array_ref1469_58___object(obj_t env_1839, obj_t array_1840, obj_t offset_1841)
{
{
obj_t array_1950;
long offset_1951;
array_1950 = array_1840;
offset_1951 = (long)CINT(offset_1841);
{
long arg1044_1952;
{
long arg1045_1953;
arg1045_1953 = OBJECT_TYPE;
arg1044_1952 = (offset_1951-arg1045_1953);
}
return VECTOR_REF(array_1950, arg1044_1952);
}
}
}


/* generics-add-class! */obj_t generics_add_class__12___object(long class_num_218_55, long super_num_34_56)
{
{
long g_401;
g_401 = ((long)0);
loop_402:
{
bool_t test1048_403;
{
long n2_1004;
n2_1004 = _nb_generics__142___object;
test1048_403 = (g_401==n2_1004);
}
if(test1048_403){
return symbol1490___object;
}
 else {
obj_t generic_404;
{
obj_t vector_1005;
vector_1005 = _generics__29___object;
generic_404 = VECTOR_REF(vector_1005, g_401);
}
{
obj_t method_array_88_405;
method_array_88_405 = PROCEDURE_REF(generic_404, ((long)1));
{
{
obj_t arg1049_406;
{
long arg1044_1010;
{
long arg1045_1011;
arg1045_1011 = OBJECT_TYPE;
arg1044_1010 = (super_num_34_56-arg1045_1011);
}
arg1049_406 = VECTOR_REF(method_array_88_405, arg1044_1010);
}
{
long arg1046_1019;
{
long arg1047_1020;
arg1047_1020 = OBJECT_TYPE;
arg1046_1019 = (class_num_218_55-arg1047_1020);
}
VECTOR_SET(method_array_88_405, arg1046_1019, arg1049_406);
}
}
{
long g_2154;
g_2154 = (g_401+((long)1));
g_401 = g_2154;
goto loop_402;
}
}
}
}
}
}
}


/* add-class! */obj_t add_class__117___object(obj_t name_57, obj_t super_58, obj_t allocate_59, long hash_60, obj_t def_61, obj_t constructor_62)
{
initialize_objects__138___object();
{
bool_t test_2157;
if(CBOOL(super_58)){
bool_t test_2160;
if(VECTORP(super_58)){
long aux_2163;
aux_2163 = VECTOR_LENGTH(super_58);
test_2160 = (aux_2163==((long)10));
}
 else {
test_2160 = ((bool_t)0);
}
if(test_2160){
test_2157 = ((bool_t)0);
}
 else {
test_2157 = ((bool_t)1);
}
}
 else {
test_2157 = ((bool_t)0);
}
if(test_2157){
FAILURE(string1491___object,string1492___object,name_57);}
 else {
BUNSPEC;
}
}
{
bool_t test1053_410;
{
long n1_1040;
long n2_1041;
n1_1040 = (long)CINT(_nb_classes__240___object);
n2_1041 = _nb_classes_max__8___object;
test1053_410 = (n1_1040==n2_1041);
}
if(test1053_410){
double_nb_classes__118___object();
}
 else {
BUNSPEC;
}
}
{
long num_411;
{
long arg1067_428;
arg1067_428 = OBJECT_TYPE;
{
long z2_1043;
z2_1043 = (long)CINT(_nb_classes__240___object);
num_411 = (arg1067_428+z2_1043);
}
}
{
long depth_412;
{
bool_t test_2174;
if(VECTORP(super_58)){
long aux_2177;
aux_2177 = VECTOR_LENGTH(super_58);
test_2174 = (aux_2177==((long)10));
}
 else {
test_2174 = ((bool_t)0);
}
if(test_2174){
long aux_2180;
{
obj_t aux_2181;
aux_2181 = VECTOR_REF(super_58, ((long)2));
aux_2180 = (long)CINT(aux_2181);
}
depth_412 = (aux_2180+((long)1));
}
 else {
depth_412 = ((long)1);
}
}
{
obj_t ancestors_413;
{
bool_t test_2185;
if(VECTORP(super_58)){
long aux_2188;
aux_2188 = VECTOR_LENGTH(super_58);
test_2185 = (aux_2188==((long)10));
}
 else {
test_2185 = ((bool_t)0);
}
if(test_2185){
obj_t arg1061_422;
arg1061_422 = VECTOR_REF(super_58, ((long)5));
{
long old_len_227_1074;
old_len_227_1074 = VECTOR_LENGTH(arg1061_422);
{
obj_t new_vec_94_1076;
{
long aux_2193;
aux_2193 = (((long)1)+old_len_227_1074);
new_vec_94_1076 = make_vector(aux_2193, super_58);
}
{
{
long i_1078;
i_1078 = ((long)0);
loop_1077:
if((i_1078==old_len_227_1074)){
ancestors_413 = new_vec_94_1076;
}
 else {
{
obj_t aux_2198;
aux_2198 = VECTOR_REF(arg1061_422, i_1078);
VECTOR_SET(new_vec_94_1076, i_1078, aux_2198);
}
{
long i_2201;
i_2201 = (i_1078+((long)1));
i_1078 = i_2201;
goto loop_1077;
}
}
}
}
}
}
}
 else {
obj_t v1008_424;
v1008_424 = create_vector(((long)1));
VECTOR_SET(v1008_424, ((long)0), super_58);
ancestors_413 = v1008_424;
}
}
{
obj_t class_414;
{
obj_t v1005_1107;
v1005_1107 = create_vector(((long)10));
VECTOR_SET(v1005_1107, ((long)9), constructor_62);
VECTOR_SET(v1005_1107, ((long)8), def_61);
{
obj_t aux_2208;
aux_2208 = BINT(hash_60);
VECTOR_SET(v1005_1107, ((long)7), aux_2208);
}
VECTOR_SET(v1005_1107, ((long)6), allocate_59);
VECTOR_SET(v1005_1107, ((long)5), ancestors_413);
VECTOR_SET(v1005_1107, ((long)4), BNIL);
VECTOR_SET(v1005_1107, ((long)3), super_58);
{
obj_t aux_2215;
aux_2215 = BINT(depth_412);
VECTOR_SET(v1005_1107, ((long)2), aux_2215);
}
{
obj_t aux_2218;
aux_2218 = BINT(num_411);
VECTOR_SET(v1005_1107, ((long)1), aux_2218);
}
VECTOR_SET(v1005_1107, ((long)0), name_57);
class_414 = v1005_1107;
}
{
{
bool_t test_2222;
if(VECTORP(super_58)){
long aux_2225;
aux_2225 = VECTOR_LENGTH(super_58);
test_2222 = (aux_2225==((long)10));
}
 else {
test_2222 = ((bool_t)0);
}
if(test_2222){
obj_t arg1055_416;
{
obj_t aux_2228;
aux_2228 = VECTOR_REF(super_58, ((long)4));
arg1055_416 = MAKE_PAIR(class_414, aux_2228);
}
VECTOR_SET(super_58, ((long)4), arg1055_416);
}
 else {
BUNSPEC;
}
}
{
obj_t vector_1157;
long k_1158;
vector_1157 = _classes__134___object;
k_1158 = (long)CINT(_nb_classes__240___object);
VECTOR_SET(vector_1157, k_1158, class_414);
}
{
long z1_1160;
z1_1160 = (long)CINT(_nb_classes__240___object);
{
long aux_2235;
aux_2235 = (z1_1160+((long)1));
_nb_classes__240___object = BINT(aux_2235);
}
}
{
long aux_2238;
{
bool_t test_2239;
if(VECTORP(super_58)){
long aux_2242;
aux_2242 = VECTOR_LENGTH(super_58);
test_2239 = (aux_2242==((long)10));
}
 else {
test_2239 = ((bool_t)0);
}
if(test_2239){
obj_t aux_2245;
aux_2245 = VECTOR_REF(super_58, ((long)1));
aux_2238 = (long)CINT(aux_2245);
}
 else {
aux_2238 = num_411;
}
}
generics_add_class__12___object(num_411, aux_2238);
}
return class_414;
}
}
}
}
}
}


/* _add-class!1470 */obj_t _add_class_1470_139___object(obj_t env_1842, obj_t name_1843, obj_t super_1844, obj_t allocate_1845, obj_t hash_1846, obj_t def_1847, obj_t constructor_1848)
{
return add_class__117___object(name_1843, super_1844, allocate_1845, (long)CINT(hash_1846), def_1847, constructor_1848);
}


/* add-generic! */obj_t add_generic__110___object(obj_t generic_64, obj_t default_65)
{
{
bool_t test_2251;
{
obj_t aux_2252;
aux_2252 = PROCEDURE_REF(generic_64, ((long)1));
test_2251 = VECTORP(aux_2252);
}
if(test_2251){
if(PROCEDUREP(default_65)){
PROCEDURE_SET(generic_64, ((long)0), default_65);
}
 else {
BUNSPEC;
}
return BUNSPEC;
}
 else {
{
bool_t test1071_432;
{
long n1_1185;
long n2_1186;
n1_1185 = _nb_generics__142___object;
n2_1186 = _nb_generics_max__185___object;
test1071_432 = (n1_1185==n2_1186);
}
if(test1071_432){
double_nb_generics__239___object();
}
 else {
BUNSPEC;
}
}
{
obj_t vector_1187;
long k_1188;
vector_1187 = _generics__29___object;
k_1188 = _nb_generics__142___object;
VECTOR_SET(vector_1187, k_1188, generic_64);
}
{
long z1_1190;
z1_1190 = _nb_generics__142___object;
_nb_generics__142___object = (z1_1190+((long)1));
}
{
obj_t arg1072_433;
if(PROCEDUREP(default_65)){
arg1072_433 = default_65;
}
 else {
obj_t lambda1074_1849;
lambda1074_1849 = proc1493___object;
arg1072_433 = lambda1074_1849;
}
PROCEDURE_SET(generic_64, ((long)0), arg1072_433);
}
{
obj_t arg1076_437;
arg1076_437 = make_vector(_nb_classes_max__8___object, BFALSE);
PROCEDURE_SET(generic_64, ((long)1), arg1076_437);
}
return BUNSPEC;
}
}
}


/* _add-generic!1471 */obj_t _add_generic_1471_11___object(obj_t env_1850, obj_t generic_1851, obj_t default_1852)
{
return add_generic__110___object(generic_1851, default_1852);
}


/* lambda1074 */obj_t lambda1074___object(obj_t env_1853, obj_t l_1854)
{
{
obj_t l_435;
l_435 = l_1854;
FAILURE(string1494___object,string1495___object,l_435);}
}


/* add-method/proc-or-num! */obj_t add_method_proc_or_num__68___object(obj_t generic_66, obj_t class_67, obj_t proc_or_num_128_68)
{
{
bool_t test_2270;
{
obj_t aux_2271;
aux_2271 = PROCEDURE_REF(generic_66, ((long)1));
test_2270 = VECTORP(aux_2271);
}
if(test_2270){
BUNSPEC;
}
 else {
add_generic__110___object(generic_66, BFALSE);
}
}
{
obj_t method_array_88_439;
method_array_88_439 = PROCEDURE_REF(generic_66, ((long)1));
{
obj_t previous_440;
{
long arg1083_452;
{
obj_t aux_2276;
aux_2276 = VECTOR_REF(class_67, ((long)1));
arg1083_452 = (long)CINT(aux_2276);
}
{
long arg1044_1211;
{
long arg1045_1212;
arg1045_1212 = OBJECT_TYPE;
arg1044_1211 = (arg1083_452-arg1045_1212);
}
previous_440 = VECTOR_REF(method_array_88_439, arg1044_1211);
}
}
{
loop___object(proc_or_num_128_68, previous_440, method_array_88_439, class_67);
}
}
}
return proc_or_num_128_68;
}


/* loop */obj_t loop___object(obj_t proc_or_num_128_1917, obj_t previous_1916, obj_t method_array_88_1915, obj_t class_441)
{
{
long cnum_443;
{
obj_t aux_2283;
aux_2283 = VECTOR_REF(class_441, ((long)1));
cnum_443 = (long)CINT(aux_2283);
}
{
obj_t current_444;
{
long arg1044_1223;
{
long arg1045_1224;
arg1045_1224 = OBJECT_TYPE;
arg1044_1223 = (cnum_443-arg1045_1224);
}
current_444 = VECTOR_REF(method_array_88_1915, arg1044_1223);
}
{
{
bool_t test_2289;
if(CBOOL(current_444)){
test_2289 = (current_444==previous_1916);
}
 else {
test_2289 = ((bool_t)1);
}
if(test_2289){
{
long arg1046_1234;
{
long arg1047_1235;
arg1047_1235 = OBJECT_TYPE;
arg1046_1234 = (cnum_443-arg1047_1235);
}
VECTOR_SET(method_array_88_1915, arg1046_1234, proc_or_num_128_1917);
}
{
obj_t l1009_1245;
{
bool_t aux_2296;
l1009_1245 = VECTOR_REF(class_441, ((long)4));
lname1010_1244:
if(PAIRP(l1009_1245)){
loop___object(proc_or_num_128_1917, previous_1916, method_array_88_1915, CAR(l1009_1245));
{
obj_t l1009_2301;
l1009_2301 = CDR(l1009_1245);
l1009_1245 = l1009_2301;
goto lname1010_1244;
}
}
 else {
aux_2296 = ((bool_t)1);
}
return BBOOL(aux_2296);
}
}
}
 else {
return BUNSPEC;
}
}
}
}
}
}


/* add-method! */obj_t add_method__1___object(obj_t generic_69, obj_t class_70, obj_t method_71)
{
{
bool_t test_2305;
if(VECTORP(class_70)){
long aux_2308;
aux_2308 = VECTOR_LENGTH(class_70);
test_2305 = (aux_2308==((long)10));
}
 else {
test_2305 = ((bool_t)0);
}
if(test_2305){
bool_t test1085_1269;
{
long arg1089_1270;
long arg1090_1271;
arg1089_1270 = PROCEDURE_ARITY(generic_69);
arg1090_1271 = PROCEDURE_ARITY(method_71);
test1085_1269 = (arg1089_1270==arg1090_1271);
}
if(test1085_1269){
return add_method_proc_or_num__68___object(generic_69, class_70, method_71);
}
 else {
{
obj_t arg1088_1274;
arg1088_1274 = MAKE_PAIR(generic_69, method_71);
FAILURE(string1496___object,string1497___object,arg1088_1274);}
}
}
 else {
FAILURE(string1496___object,string1498___object,class_70);}
}
}


/* _add-method!1472 */obj_t _add_method_1472_99___object(obj_t env_1855, obj_t generic_1856, obj_t class_1857, obj_t method_1858)
{
return add_method__1___object(generic_1856, class_1857, method_1858);
}


/* add-inlined-method! */long add_inlined_method__244___object(obj_t generic_72, obj_t class_73, long method_num_210_74)
{
{
obj_t aux_2320;
aux_2320 = add_method_proc_or_num__68___object(generic_72, class_73, BINT(method_num_210_74));
return (long)CINT(aux_2320);
}
}


/* _add-inlined-method!1473 */obj_t _add_inlined_method_1473_211___object(obj_t env_1859, obj_t generic_1860, obj_t class_1861, obj_t method_num_210_1862)
{
{
long aux_2324;
aux_2324 = add_inlined_method__244___object(generic_1860, class_1861, (long)CINT(method_num_210_1862));
return BINT(aux_2324);
}
}


/* find-method */obj_t find_method_204___object(object_t obj_75, obj_t generic_76)
{
{
long obj_class_num_177_1954;
obj_class_num_177_1954 = TYPE( obj_75 );
{
obj_t arg1091_1955;
arg1091_1955 = PROCEDURE_REF(generic_76, ((long)1));
{
long arg1044_1956;
{
long arg1045_1957;
arg1045_1957 = OBJECT_TYPE;
arg1044_1956 = (obj_class_num_177_1954-arg1045_1957);
}
return VECTOR_REF(arg1091_1955, arg1044_1956);
}
}
}
}


/* _find-method1474 */obj_t _find_method1474_47___object(obj_t env_1863, obj_t obj_1864, obj_t generic_1865)
{
{
object_t obj_1958;
obj_t generic_1959;
obj_1958 = (object_t)(obj_1864);
generic_1959 = generic_1865;
{
long obj_class_num_177_1960;
obj_class_num_177_1960 = TYPE( obj_1958 );
{
obj_t arg1091_1961;
arg1091_1961 = PROCEDURE_REF(generic_1959, ((long)1));
{
long arg1044_1962;
{
long arg1045_1963;
arg1045_1963 = OBJECT_TYPE;
arg1044_1962 = (obj_class_num_177_1960-arg1045_1963);
}
return VECTOR_REF(arg1091_1961, arg1044_1962);
}
}
}
}
}


/* find-inline-method */obj_t find_inline_method_206___object(object_t obj_77, obj_t generic_78)
{
{
obj_t pre_method_105_1964;
pre_method_105_1964 = PROCEDURE_REF(generic_78, ((long)2));
if(INTEGERP(pre_method_105_1964)){
PROCEDURE_SET(generic_78, ((long)2), BUNSPEC);
return pre_method_105_1964;
}
 else {
long obj_class_num_177_1965;
obj_class_num_177_1965 = TYPE( obj_77 );
{
obj_t arg1091_1966;
arg1091_1966 = PROCEDURE_REF(generic_78, ((long)1));
{
long arg1044_1967;
{
long arg1045_1968;
arg1045_1968 = OBJECT_TYPE;
arg1044_1967 = (obj_class_num_177_1965-arg1045_1968);
}
return VECTOR_REF(arg1091_1966, arg1044_1967);
}
}
}
}
}


/* _find-inline-method1475 */obj_t _find_inline_method1475_164___object(obj_t env_1866, obj_t obj_1867, obj_t generic_1868)
{
{
object_t obj_1969;
obj_t generic_1970;
obj_1969 = (object_t)(obj_1867);
generic_1970 = generic_1868;
{
obj_t pre_method_105_1971;
pre_method_105_1971 = PROCEDURE_REF(generic_1970, ((long)2));
if(INTEGERP(pre_method_105_1971)){
PROCEDURE_SET(generic_1970, ((long)2), BUNSPEC);
return pre_method_105_1971;
}
 else {
long obj_class_num_177_1972;
obj_class_num_177_1972 = TYPE( obj_1969 );
{
obj_t arg1091_1973;
arg1091_1973 = PROCEDURE_REF(generic_1970, ((long)1));
{
long arg1044_1974;
{
long arg1045_1975;
arg1045_1975 = OBJECT_TYPE;
arg1044_1974 = (obj_class_num_177_1972-arg1045_1975);
}
return VECTOR_REF(arg1091_1973, arg1044_1974);
}
}
}
}
}
}


/* find-super-class-method */obj_t find_super_class_method_167___object(object_t obj_79, obj_t generic_80, obj_t class_81)
{
{
obj_t super_1327;
super_1327 = VECTOR_REF(class_81, ((long)3));
loop_1326:
{
bool_t test_2358;
if(VECTORP(super_1327)){
long aux_2361;
aux_2361 = VECTOR_LENGTH(super_1327);
test_2358 = (aux_2361==((long)10));
}
 else {
test_2358 = ((bool_t)0);
}
if(test_2358){
long obj_super_class_num_147_1329;
{
obj_t aux_2364;
aux_2364 = VECTOR_REF(super_1327, ((long)1));
obj_super_class_num_147_1329 = (long)CINT(aux_2364);
}
{
obj_t method_1330;
{
obj_t arg1095_1331;
arg1095_1331 = PROCEDURE_REF(generic_80, ((long)1));
{
long arg1044_1353;
{
long arg1045_1354;
arg1045_1354 = OBJECT_TYPE;
arg1044_1353 = (obj_super_class_num_147_1329-arg1045_1354);
}
method_1330 = VECTOR_REF(arg1095_1331, arg1044_1353);
}
}
if(CBOOL(method_1330)){
return method_1330;
}
 else {
obj_t super_2373;
super_2373 = VECTOR_REF(super_1327, ((long)3));
super_1327 = super_2373;
goto loop_1326;
}
}
}
 else {
return PROCEDURE_REF(generic_80, ((long)0));
}
}
}
}


/* _find-super-class-method1476 */obj_t _find_super_class_method1476_137___object(obj_t env_1869, obj_t obj_1870, obj_t generic_1871, obj_t class_1872)
{
return find_super_class_method_167___object((object_t)(obj_1870), generic_1871, class_1872);
}


/* find-method-from */obj_t find_method_from_44___object(object_t obj_82, obj_t generic_83, obj_t class_84)
{
{
obj_t class_1365;
class_1365 = class_84;
loop_1364:
{
bool_t test_2379;
if(VECTORP(class_1365)){
long aux_2382;
aux_2382 = VECTOR_LENGTH(class_1365);
test_2379 = (aux_2382==((long)10));
}
 else {
test_2379 = ((bool_t)0);
}
if(test_2379){
long obj_super_class_num_147_1367;
{
obj_t aux_2385;
aux_2385 = VECTOR_REF(class_1365, ((long)1));
obj_super_class_num_147_1367 = (long)CINT(aux_2385);
}
{
obj_t method_1368;
{
obj_t arg1098_1369;
arg1098_1369 = PROCEDURE_REF(generic_83, ((long)1));
{
long arg1044_1387;
{
long arg1045_1388;
arg1045_1388 = OBJECT_TYPE;
arg1044_1387 = (obj_super_class_num_147_1367-arg1045_1388);
}
method_1368 = VECTOR_REF(arg1098_1369, arg1044_1387);
}
}
if(CBOOL(method_1368)){
return MAKE_PAIR(class_1365, method_1368);
}
 else {
obj_t class_2395;
class_2395 = VECTOR_REF(class_1365, ((long)3));
class_1365 = class_2395;
goto loop_1364;
}
}
}
 else {
return MAKE_PAIR(BFALSE, BFALSE);
}
}
}
}


/* _find-method-from1477 */obj_t _find_method_from1477_94___object(obj_t env_1873, obj_t obj_1874, obj_t generic_1875, obj_t class_1876)
{
return find_method_from_44___object((object_t)(obj_1874), generic_1875, class_1876);
}


/* next-class-num */long next_class_num_45___object(long num_85)
{
if((num_85<((long)0))){
return ((long)-1);
}
 else {
bool_t test1100_480;
{
long n2_1403;
n2_1403 = (long)CINT(_nb_classes__240___object);
test1100_480 = (num_85>=n2_1403);
}
if(test1100_480){
return ((long)-1);
}
 else {
{
obj_t class_481;
{
obj_t vector_1404;
vector_1404 = _classes__134___object;
class_481 = VECTOR_REF(vector_1404, num_85);
}
{
obj_t aux_2406;
aux_2406 = VECTOR_REF(class_481, ((long)1));
return (long)CINT(aux_2406);
}
}
}
}
}


/* _next-class-num1478 */obj_t _next_class_num1478_249___object(obj_t env_1877, obj_t num_1878)
{
{
long aux_2409;
aux_2409 = next_class_num_45___object((long)CINT(num_1878));
return BINT(aux_2409);
}
}


/* is-a? */bool_t is_a__118___object(obj_t obj_86, obj_t class_87)
{
{
bool_t test1101_482;
test1101_482 = (POINTERP( obj_86 ) && (TYPE( obj_86 ) >= OBJECT_TYPE));
if(test1101_482){
bool_t test1102_483;
{
long arg1106_490;
long arg1107_491;
{
object_t obj_1411;
obj_1411 = (object_t)(obj_86);
arg1106_490 = TYPE( obj_1411 );
}
{
obj_t aux_2417;
aux_2417 = VECTOR_REF(class_87, ((long)1));
arg1107_491 = (long)CINT(aux_2417);
}
test1102_483 = (arg1106_490==arg1107_491);
}
if(test1102_483){
return ((bool_t)1);
}
 else {
obj_t direct_class_91_484;
{
object_t object_1418;
object_1418 = (object_t)(obj_86);
{
long arg1041_1419;
{
long arg1042_1420;
long arg1043_1421;
arg1042_1420 = TYPE( object_1418 );
arg1043_1421 = OBJECT_TYPE;
arg1041_1419 = (arg1042_1420-arg1043_1421);
}
{
obj_t vector_1425;
vector_1425 = _classes__134___object;
direct_class_91_484 = VECTOR_REF(vector_1425, arg1041_1419);
}
}
}
{
long depth_486;
{
obj_t aux_2427;
aux_2427 = VECTOR_REF(class_87, ((long)2));
depth_486 = (long)CINT(aux_2427);
}
{
{
bool_t test_2430;
{
long aux_2431;
{
obj_t aux_2432;
aux_2432 = VECTOR_REF(direct_class_91_484, ((long)2));
aux_2431 = (long)CINT(aux_2432);
}
test_2430 = (depth_486<aux_2431);
}
if(test_2430){
obj_t aux_2436;
{
obj_t aux_2437;
aux_2437 = VECTOR_REF(direct_class_91_484, ((long)5));
aux_2436 = VECTOR_REF(aux_2437, depth_486);
}
return (aux_2436==class_87);
}
 else {
return ((bool_t)0);
}
}
}
}
}
}
 else {
return ((bool_t)0);
}
}
}


/* _is-a? */obj_t _is_a__25___object(obj_t env_1879, obj_t obj_1880, obj_t class_1881)
{
{
bool_t aux_2441;
aux_2441 = is_a__118___object(obj_1880, class_1881);
return BBOOL(aux_2441);
}
}


/* struct->object */object_t struct__object_175___object(obj_t struct_102)
{
{
object_t arg1108_1444;
arg1108_1444 = allocate_instance_244___object(STRUCT_KEY(struct_102));
{
object_t res1439_1486;
{
obj_t method1347_1450;
obj_t class1352_1451;
{
obj_t arg1353_1454;
obj_t arg1355_1455;
{
obj_t pre_method_105_1457;
pre_method_105_1457 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)2));
if(INTEGERP(pre_method_105_1457)){
PROCEDURE_SET(struct_object__object_env_209___object, ((long)2), BUNSPEC);
arg1353_1454 = pre_method_105_1457;
}
 else {
long obj_class_num_177_1462;
obj_class_num_177_1462 = TYPE( arg1108_1444 );
{
obj_t arg1091_1463;
arg1091_1463 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)1));
{
long arg1044_1467;
{
long arg1045_1468;
arg1045_1468 = OBJECT_TYPE;
arg1044_1467 = (obj_class_num_177_1462-arg1045_1468);
}
arg1353_1454 = VECTOR_REF(arg1091_1463, arg1044_1467);
}
}
}
}
{
long arg1041_1474;
{
long arg1042_1475;
long arg1043_1476;
arg1042_1475 = TYPE( arg1108_1444 );
arg1043_1476 = OBJECT_TYPE;
arg1041_1474 = (arg1042_1475-arg1043_1476);
}
{
obj_t vector_1480;
vector_1480 = _classes__134___object;
arg1355_1455 = VECTOR_REF(vector_1480, arg1041_1474);
}
}
{
obj_t aux_2459;
method1347_1450 = arg1353_1454;
class1352_1451 = arg1355_1455;
if(PROCEDUREP(method1347_1450)){
aux_2459 = PROCEDURE_ENTRY(method1347_1450)(method1347_1450, (obj_t)(arg1108_1444), struct_102, BEOA);
}
 else {
obj_t fun1197_1483;
fun1197_1483 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)0));
aux_2459 = PROCEDURE_ENTRY(fun1197_1483)(fun1197_1483, (obj_t)(arg1108_1444), struct_102, BEOA);
}
res1439_1486 = (object_t)(aux_2459);
}
}
}
return res1439_1486;
}
}
}


/* _struct->object1479 */obj_t _struct__object1479_161___object(obj_t env_1882, obj_t struct_1883)
{
{
object_t aux_2470;
aux_2470 = struct__object_175___object(struct_1883);
return (obj_t)(aux_2470);
}
}


/* allocate-instance */object_t allocate_instance_244___object(obj_t cname_103)
{
{
long i_494;
{
obj_t aux_2473;
i_494 = ((long)0);
loop_495:
{
bool_t test1110_496;
{
long n2_1488;
n2_1488 = (long)CINT(_nb_classes__240___object);
test1110_496 = (i_494==n2_1488);
}
if(test1110_496){
FAILURE(string1499___object,string1500___object,cname_103);}
 else {
obj_t class_497;
{
obj_t vector_1492;
vector_1492 = _classes__134___object;
class_497 = VECTOR_REF(vector_1492, i_494);
}
{
bool_t test_2479;
{
obj_t aux_2480;
aux_2480 = VECTOR_REF(class_497, ((long)0));
test_2479 = (aux_2480==cname_103);
}
if(test_2479){
obj_t fun1112_499;
fun1112_499 = VECTOR_REF(class_497, ((long)6));
aux_2473 = PROCEDURE_ENTRY(fun1112_499)(fun1112_499, BEOA);
}
 else {
long i_2486;
i_2486 = (i_494+((long)1));
i_494 = i_2486;
goto loop_495;
}
}
}
}
return (object_t)(aux_2473);
}
}
}


/* _allocate-instance1481 */obj_t _allocate_instance1481_81___object(obj_t env_1887, obj_t cname_1888)
{
{
object_t aux_2489;
aux_2489 = allocate_instance_244___object(cname_1888);
return (obj_t)(aux_2489);
}
}


/* wide-object? */bool_t wide_object__208___object(object_t object_104)
{
{
bool_t test_2492;
{
obj_t aux_2493;
aux_2493 = OBJECT_WIDENING(object_104);
test_2492 = CBOOL(aux_2493);
}
if(test_2492){
return ((bool_t)1);
}
 else {
return ((bool_t)0);
}
}
}


/* _wide-object?1482 */obj_t _wide_object_1482_198___object(obj_t env_1889, obj_t object_1890)
{
{
bool_t aux_2496;
{
object_t object_1976;
object_1976 = (object_t)(object_1890);
{
bool_t test_2498;
{
obj_t aux_2499;
aux_2499 = OBJECT_WIDENING(object_1976);
test_2498 = CBOOL(aux_2499);
}
if(test_2498){
aux_2496 = ((bool_t)1);
}
 else {
aux_2496 = ((bool_t)0);
}
}
}
return BBOOL(aux_2496);
}
}


/* object-write/display */obj_t object_write_display_42___object(object_t obj_105, obj_t port_106, bool_t flag_107)
{
{
obj_t field_529;
{
obj_t class_504;
{
long arg1041_1508;
{
long arg1042_1509;
long arg1043_1510;
arg1042_1509 = TYPE( obj_105 );
arg1043_1510 = OBJECT_TYPE;
arg1041_1508 = (arg1042_1509-arg1043_1510);
}
{
obj_t vector_1514;
vector_1514 = _classes__134___object;
class_504 = VECTOR_REF(vector_1514, arg1041_1508);
}
}
{
obj_t class_name_139_505;
class_name_139_505 = VECTOR_REF(class_504, ((long)0));
{
obj_t fields_506;
fields_506 = class_fields_215___object(class_504);
{
{
obj_t list1116_507;
list1116_507 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(string1502___object, list1116_507);
}
{
obj_t list1118_509;
list1118_509 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(class_name_139_505, list1118_509);
}
{
bool_t test_2513;
{
bool_t _ortest_1007_1521;
_ortest_1007_1521 = PAIRP(fields_506);
if(_ortest_1007_1521){
test_2513 = _ortest_1007_1521;
}
 else {
test_2513 = NULLP(fields_506);
}
}
if(test_2513){
obj_t fields_512;
obj_t class_513;
fields_512 = fields_506;
class_513 = class_504;
loop_514:
if(NULLP(fields_512)){
{
obj_t super_516;
super_516 = VECTOR_REF(class_513, ((long)3));
{
bool_t test_2520;
if(VECTORP(super_516)){
long aux_2523;
aux_2523 = VECTOR_LENGTH(super_516);
test_2520 = (aux_2523==((long)10));
}
 else {
test_2520 = ((bool_t)0);
}
if(test_2520){
obj_t arg1123_518;
arg1123_518 = class_fields_215___object(super_516);
{
obj_t class_2528;
obj_t fields_2527;
fields_2527 = arg1123_518;
class_2528 = super_516;
class_513 = class_2528;
fields_512 = fields_2527;
goto loop_514;
}
}
 else {
obj_t list1124_519;
list1124_519 = MAKE_PAIR(port_106, BNIL);
return display___r4_output_6_10_3(BCHAR(((unsigned char)'|')), list1124_519);
}
}
}
}
 else {
if((fields_512==BUNSPEC)){
{
obj_t list1127_522;
list1127_522 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(string1503___object, list1127_522);
}
{
obj_t fields_2536;
fields_2536 = BNIL;
fields_512 = fields_2536;
goto loop_514;
}
}
 else {
field_529 = CAR(fields_512);
{
obj_t name_531;
name_531 = VECTOR_REF(field_529, ((long)0));
{
obj_t get_value_98_532;
get_value_98_532 = VECTOR_REF(field_529, ((long)1));
{
{
obj_t list1135_533;
list1135_533 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(string1501___object, list1135_533);
}
{
obj_t list1137_535;
list1137_535 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(name_531, list1137_535);
}
{
obj_t list1140_537;
list1140_537 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)':')), list1140_537);
}
{
bool_t test_2546;
{
obj_t aux_2547;
aux_2547 = VECTOR_REF(field_529, ((long)3));
test_2546 = PROCEDUREP(aux_2547);
}
if(test_2546){
obj_t get_len_134_540;
get_len_134_540 = VECTOR_REF(field_529, ((long)3));
{
obj_t len_541;
len_541 = PROCEDURE_ENTRY(get_len_134_540)(get_len_134_540, (obj_t)(obj_105), BEOA);
{
{
long i_542;
i_542 = ((long)0);
loop_543:
{
bool_t test_2554;
{
long aux_2555;
aux_2555 = (long)CINT(len_541);
test_2554 = (i_542==aux_2555);
}
if(test_2554){
obj_t list1144_545;
list1144_545 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)']')), list1144_545);
}
 else {
{
obj_t list1146_547;
list1146_547 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)' ')), list1146_547);
}
if(flag_107){
obj_t arg1148_549;
arg1148_549 = PROCEDURE_ENTRY(get_value_98_532)(get_value_98_532, (obj_t)(obj_105), BINT(i_542), BEOA);
{
obj_t list1149_550;
list1149_550 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(arg1148_549, list1149_550);
}
}
 else {
obj_t arg1151_552;
arg1151_552 = PROCEDURE_ENTRY(get_value_98_532)(get_value_98_532, (obj_t)(obj_105), BINT(i_542), BEOA);
{
obj_t list1152_553;
list1152_553 = MAKE_PAIR(port_106, BNIL);
write___r4_output_6_10_3(arg1151_552, list1152_553);
}
}
{
long i_2577;
i_2577 = (i_542+((long)1));
i_542 = i_2577;
goto loop_543;
}
}
}
}
}
}
}
 else {
{
obj_t list1155_556;
list1155_556 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)' ')), list1155_556);
}
if(flag_107){
obj_t arg1157_558;
arg1157_558 = PROCEDURE_ENTRY(get_value_98_532)(get_value_98_532, (obj_t)(obj_105), BEOA);
{
obj_t list1158_559;
list1158_559 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(arg1157_558, list1158_559);
}
}
 else {
obj_t arg1161_561;
arg1161_561 = PROCEDURE_ENTRY(get_value_98_532)(get_value_98_532, (obj_t)(obj_105), BEOA);
{
obj_t list1162_562;
list1162_562 = MAKE_PAIR(port_106, BNIL);
write___r4_output_6_10_3(arg1161_561, list1162_562);
}
}
{
obj_t list1164_564;
list1164_564 = MAKE_PAIR(port_106, BNIL);
display___r4_output_6_10_3(BCHAR(((unsigned char)']')), list1164_564);
}
}
}
}
}
}
{
obj_t fields_2597;
fields_2597 = CDR(fields_512);
fields_512 = fields_2597;
goto loop_514;
}
}
}
}
 else {
obj_t list1132_527;
list1132_527 = MAKE_PAIR(port_106, BNIL);
return display___r4_output_6_10_3(BCHAR(((unsigned char)'|')), list1132_527);
}
}
}
}
}
}
}
}


/* object-equal? */bool_t object_equal__12___object(object_t obj1_108, object_t obj2_109)
{
{
obj_t field_584;
{
obj_t class1_568;
obj_t class2_569;
{
long arg1041_1565;
{
long arg1042_1566;
long arg1043_1567;
arg1042_1566 = TYPE( obj1_108 );
arg1043_1567 = OBJECT_TYPE;
arg1041_1565 = (arg1042_1566-arg1043_1567);
}
{
obj_t vector_1571;
vector_1571 = _classes__134___object;
class1_568 = VECTOR_REF(vector_1571, arg1041_1565);
}
}
{
long arg1041_1574;
{
long arg1042_1575;
long arg1043_1576;
arg1042_1575 = TYPE( obj2_109 );
arg1043_1576 = OBJECT_TYPE;
arg1041_1574 = (arg1042_1575-arg1043_1576);
}
{
obj_t vector_1580;
vector_1580 = _classes__134___object;
class2_569 = VECTOR_REF(vector_1580, arg1041_1574);
}
}
if((class1_568==class2_569)){
{
obj_t fields_571;
fields_571 = class_fields_215___object(class1_568);
{
bool_t test_2613;
{
bool_t _ortest_1007_1585;
_ortest_1007_1585 = PAIRP(fields_571);
if(_ortest_1007_1585){
test_2613 = _ortest_1007_1585;
}
 else {
test_2613 = NULLP(fields_571);
}
}
if(test_2613){
obj_t fields_573;
obj_t class_574;
fields_573 = fields_571;
class_574 = class1_568;
loop_575:
if(NULLP(fields_573)){
{
obj_t super_577;
super_577 = VECTOR_REF(class_574, ((long)3));
{
bool_t test_2620;
if(VECTORP(super_577)){
long aux_2623;
aux_2623 = VECTOR_LENGTH(super_577);
test_2620 = (aux_2623==((long)10));
}
 else {
test_2620 = ((bool_t)0);
}
if(test_2620){
obj_t fields_579;
fields_579 = class_fields_215___object(super_577);
{
bool_t test_2627;
{
bool_t _ortest_1007_1603;
_ortest_1007_1603 = PAIRP(fields_579);
if(_ortest_1007_1603){
test_2627 = _ortest_1007_1603;
}
 else {
test_2627 = NULLP(fields_579);
}
}
if(test_2627){
obj_t class_2632;
obj_t fields_2631;
fields_2631 = fields_579;
class_2632 = super_577;
class_574 = class_2632;
fields_573 = fields_2631;
goto loop_575;
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)1);
}
}
}
}
 else {
bool_t test1171_581;
field_584 = CAR(fields_573);
{
obj_t get_value_98_586;
get_value_98_586 = VECTOR_REF(field_584, ((long)1));
{
bool_t test_2634;
{
obj_t aux_2635;
aux_2635 = VECTOR_REF(field_584, ((long)3));
test_2634 = PROCEDUREP(aux_2635);
}
if(test_2634){
obj_t get_len_134_588;
get_len_134_588 = VECTOR_REF(field_584, ((long)3));
{
obj_t len1_589;
len1_589 = PROCEDURE_ENTRY(get_len_134_588)(get_len_134_588, (obj_t)(obj1_108), BEOA);
{
obj_t len2_590;
len2_590 = PROCEDURE_ENTRY(get_len_134_588)(get_len_134_588, (obj_t)(obj2_109), BEOA);
{
{
bool_t test_2645;
{
long aux_2648;
long aux_2646;
aux_2648 = (long)CINT(len2_590);
aux_2646 = (long)CINT(len1_589);
test_2645 = (aux_2646==aux_2648);
}
if(test_2645){
long i_592;
i_592 = ((long)0);
loop_593:
{
bool_t test_2651;
{
long aux_2652;
aux_2652 = (long)CINT(len1_589);
test_2651 = (i_592==aux_2652);
}
if(test_2651){
test1171_581 = ((bool_t)1);
}
 else {
bool_t test1177_595;
{
obj_t arg1179_597;
obj_t arg1180_598;
arg1179_597 = PROCEDURE_ENTRY(get_value_98_586)(get_value_98_586, (obj_t)(obj1_108), BINT(i_592), BEOA);
arg1180_598 = PROCEDURE_ENTRY(get_value_98_586)(get_value_98_586, (obj_t)(obj2_109), BINT(i_592), BEOA);
test1177_595 = equal__25___r4_equivalence_6_2(arg1179_597, arg1180_598);
}
if(test1177_595){
{
long i_2665;
i_2665 = (i_592+((long)1));
i_592 = i_2665;
goto loop_593;
}
}
 else {
test1171_581 = ((bool_t)0);
}
}
}
}
 else {
test1171_581 = ((bool_t)0);
}
}
}
}
}
}
 else {
obj_t arg1181_599;
obj_t arg1182_600;
arg1181_599 = PROCEDURE_ENTRY(get_value_98_586)(get_value_98_586, (obj_t)(obj1_108), BEOA);
arg1182_600 = PROCEDURE_ENTRY(get_value_98_586)(get_value_98_586, (obj_t)(obj2_109), BEOA);
test1171_581 = equal__25___r4_equivalence_6_2(arg1181_599, arg1182_600);
}
}
}
if(test1171_581){
{
obj_t fields_2676;
fields_2676 = CDR(fields_573);
fields_573 = fields_2676;
goto loop_575;
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
return ((bool_t)0);
}
}
}
}
 else {
return ((bool_t)0);
}
}
}
}


/* _object-equal?1483 */obj_t _object_equal_1483_25___object(obj_t env_1891, obj_t obj1_1892, obj_t obj2_1893)
{
{
bool_t aux_2678;
aux_2678 = object_equal__12___object((object_t)(obj1_1892), (object_t)(obj2_1893));
return BBOOL(aux_2678);
}
}


/* object-init */obj_t object_init_111___object()
{
return (object___object = add_class__117___object(symbol1504___object, BFALSE, allocate_object_env_103___object, ((long)46311), BNIL, BFALSE),
BUNSPEC);
}


/* allocate-object */object_t allocate_object_214___object()
{
{
object_t new1004_607;
new1004_607 = ((object_t)BREF( GC_MALLOC( sizeof(struct object) )));
{
long arg1188_608;
{
long res1455_1633;
{
obj_t class_1630;
class_1630 = object___object;
{
obj_t aux_2685;
aux_2685 = VECTOR_REF(class_1630, ((long)1));
res1455_1633 = (long)CINT(aux_2685);
}
}
arg1188_608 = res1455_1633;
}
{
obj_t obj_1634;
obj_1634 = (obj_t)(new1004_607);
(((obj_t)CREF(obj_1634))->header = MAKE_HEADER( arg1188_608, 0 ), BUNSPEC);
}
}
OBJECT_WIDENING_SET(new1004_607, BFALSE);
return new1004_607;
}
}


/* _allocate-object */obj_t _allocate_object_100___object(obj_t env_1894)
{
{
object_t aux_2691;
aux_2691 = allocate_object_214___object();
return (obj_t)(aux_2691);
}
}


/* make-object */object_t make_object_188___object()
{
{
object_t new1002_1977;
new1002_1977 = ((object_t)BREF( GC_MALLOC( sizeof(struct object) )));
{
long arg1189_1978;
arg1189_1978 = class_num_218___object(object___object);
{
obj_t obj_1979;
obj_1979 = (obj_t)(new1002_1977);
(((obj_t)CREF(obj_1979))->header = MAKE_HEADER( arg1189_1978, 0 ), BUNSPEC);
}
}
OBJECT_WIDENING_SET(new1002_1977, BFALSE);
{
return new1002_1977;
}
}
}


/* _make-object */obj_t _make_object_124___object(obj_t env_1895)
{
{
object_t aux_2699;
{
object_t new1002_1980;
new1002_1980 = ((object_t)BREF( GC_MALLOC( sizeof(struct object) )));
{
long arg1189_1981;
arg1189_1981 = class_num_218___object(object___object);
{
obj_t obj_1982;
obj_1982 = (obj_t)(new1002_1980);
(((obj_t)CREF(obj_1982))->header = MAKE_HEADER( arg1189_1981, 0 ), BUNSPEC);
}
}
OBJECT_WIDENING_SET(new1002_1980, BFALSE);
{
aux_2699 = new1002_1980;
}
}
return (obj_t)(aux_2699);
}
}


/* method-init */obj_t method_init_76___object()
{
add_generic__110___object(object_display_env_20___object, object_display_default1017_env_41___object);
add_generic__110___object(object_write_env_104___object, object_write_default1018_env_141___object);
add_generic__110___object(object__struct_env_210___object, object__struct_default1019_env_180___object);
return add_generic__110___object(struct_object__object_env_209___object, struct_object__object_default1020_env_255___object);
}


/* object-display */obj_t object_display_243___object(object_t obj_88, obj_t port_89)
{
{
obj_t method1398_801;
obj_t class1403_802;
{
obj_t arg1405_799;
obj_t arg1407_800;
{
obj_t pre_method_105_1641;
pre_method_105_1641 = PROCEDURE_REF(object_display_env_20___object, ((long)2));
if(INTEGERP(pre_method_105_1641)){
PROCEDURE_SET(object_display_env_20___object, ((long)2), BUNSPEC);
arg1405_799 = pre_method_105_1641;
}
 else {
long obj_class_num_177_1646;
obj_class_num_177_1646 = TYPE( obj_88 );
{
obj_t arg1091_1647;
arg1091_1647 = PROCEDURE_REF(object_display_env_20___object, ((long)1));
{
long arg1044_1651;
{
long arg1045_1652;
arg1045_1652 = OBJECT_TYPE;
arg1044_1651 = (obj_class_num_177_1646-arg1045_1652);
}
arg1405_799 = VECTOR_REF(arg1091_1647, arg1044_1651);
}
}
}
}
{
long arg1041_1658;
{
long arg1042_1659;
long arg1043_1660;
arg1042_1659 = TYPE( obj_88 );
arg1043_1660 = OBJECT_TYPE;
arg1041_1658 = (arg1042_1659-arg1043_1660);
}
{
obj_t vector_1664;
vector_1664 = _classes__134___object;
arg1407_800 = VECTOR_REF(vector_1664, arg1041_1658);
}
}
method1398_801 = arg1405_799;
class1403_802 = arg1407_800;
if(PROCEDUREP(method1398_801)){
obj_t aux_2725;
{
obj_t list1410_807;
list1410_807 = MAKE_PAIR(port_89, BNIL);
aux_2725 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_88), list1410_807);
}
return apply(method1398_801, aux_2725);
}
 else {
obj_t aux_2730;
{
obj_t list1190_611;
list1190_611 = MAKE_PAIR(port_89, BNIL);
aux_2730 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_88), list1190_611);
}
return apply(PROCEDURE_REF(object_display_env_20___object, ((long)0)), aux_2730);
}
}
}
}


/* _object-display1484 */obj_t _object_display1484_134___object(obj_t env_1896, obj_t obj_1897, obj_t port_1898)
{
return object_display_243___object((object_t)(obj_1897), port_1898);
}


/* object-display-default1017 */obj_t object_display_default1017_64___object(object_t obj_90, obj_t port_91)
{
{
obj_t aux_2738;
if(PAIRP(port_91)){
aux_2738 = CAR(port_91);
}
 else {
aux_2738 = current_output_port;
}
return object_write_display_42___object(obj_90, aux_2738, ((bool_t)1));
}
}


/* _object-display-default1017 */obj_t _object_display_default1017_129___object(obj_t env_1899, obj_t obj_1900, obj_t port_1901)
{
return object_display_default1017_64___object((object_t)(obj_1900), port_1901);
}


/* object-write */obj_t object_write_132___object(object_t obj_92, obj_t port_93)
{
{
obj_t method1381_781;
obj_t class1386_782;
{
obj_t arg1387_779;
obj_t arg1388_780;
{
obj_t pre_method_105_1673;
pre_method_105_1673 = PROCEDURE_REF(object_write_env_104___object, ((long)2));
if(INTEGERP(pre_method_105_1673)){
PROCEDURE_SET(object_write_env_104___object, ((long)2), BUNSPEC);
arg1387_779 = pre_method_105_1673;
}
 else {
long obj_class_num_177_1678;
obj_class_num_177_1678 = TYPE( obj_92 );
{
obj_t arg1091_1679;
arg1091_1679 = PROCEDURE_REF(object_write_env_104___object, ((long)1));
{
long arg1044_1683;
{
long arg1045_1684;
arg1045_1684 = OBJECT_TYPE;
arg1044_1683 = (obj_class_num_177_1678-arg1045_1684);
}
arg1387_779 = VECTOR_REF(arg1091_1679, arg1044_1683);
}
}
}
}
{
long arg1041_1690;
{
long arg1042_1691;
long arg1043_1692;
arg1042_1691 = TYPE( obj_92 );
arg1043_1692 = OBJECT_TYPE;
arg1041_1690 = (arg1042_1691-arg1043_1692);
}
{
obj_t vector_1696;
vector_1696 = _classes__134___object;
arg1388_780 = VECTOR_REF(vector_1696, arg1041_1690);
}
}
method1381_781 = arg1387_779;
class1386_782 = arg1388_780;
if(PROCEDUREP(method1381_781)){
obj_t aux_2760;
{
obj_t list1391_787;
list1391_787 = MAKE_PAIR(port_93, BNIL);
aux_2760 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_92), list1391_787);
}
return apply(method1381_781, aux_2760);
}
 else {
obj_t aux_2765;
{
obj_t list1193_615;
list1193_615 = MAKE_PAIR(port_93, BNIL);
aux_2765 = cons__138___r4_pairs_and_lists_6_3((obj_t)(obj_92), list1193_615);
}
return apply(PROCEDURE_REF(object_write_env_104___object, ((long)0)), aux_2765);
}
}
}
}


/* _object-write1485 */obj_t _object_write1485_174___object(obj_t env_1902, obj_t obj_1903, obj_t port_1904)
{
return object_write_132___object((object_t)(obj_1903), port_1904);
}


/* object-write-default1018 */obj_t object_write_default1018_79___object(object_t obj_94, obj_t port_95)
{
{
obj_t aux_2773;
if(PAIRP(port_95)){
aux_2773 = CAR(port_95);
}
 else {
aux_2773 = current_output_port;
}
return object_write_display_42___object(obj_94, aux_2773, ((bool_t)0));
}
}


/* _object-write-default1018 */obj_t _object_write_default1018_31___object(obj_t env_1905, obj_t obj_1906, obj_t port_1907)
{
return object_write_default1018_79___object((object_t)(obj_1906), port_1907);
}


/* object->struct */obj_t object__struct_50___object(object_t object_96)
{
{
obj_t arg1372_762;
obj_t arg1373_763;
{
obj_t pre_method_105_1705;
pre_method_105_1705 = PROCEDURE_REF(object__struct_env_210___object, ((long)2));
if(INTEGERP(pre_method_105_1705)){
PROCEDURE_SET(object__struct_env_210___object, ((long)2), BUNSPEC);
arg1372_762 = pre_method_105_1705;
}
 else {
long obj_class_num_177_1710;
obj_class_num_177_1710 = TYPE( object_96 );
{
obj_t arg1091_1711;
arg1091_1711 = PROCEDURE_REF(object__struct_env_210___object, ((long)1));
{
long arg1044_1715;
{
long arg1045_1716;
arg1045_1716 = OBJECT_TYPE;
arg1044_1715 = (obj_class_num_177_1710-arg1045_1716);
}
arg1372_762 = VECTOR_REF(arg1091_1711, arg1044_1715);
}
}
}
}
{
long arg1041_1722;
{
long arg1042_1723;
long arg1043_1724;
arg1042_1723 = TYPE( object_96 );
arg1043_1724 = OBJECT_TYPE;
arg1041_1722 = (arg1042_1723-arg1043_1724);
}
{
obj_t vector_1728;
vector_1728 = _classes__134___object;
arg1373_763 = VECTOR_REF(vector_1728, arg1041_1722);
}
}
if(PROCEDUREP(arg1372_762)){
return PROCEDURE_ENTRY(arg1372_762)(arg1372_762, (obj_t)(object_96), BEOA);
}
 else {
obj_t fun1196_1733;
fun1196_1733 = PROCEDURE_REF(object__struct_env_210___object, ((long)0));
return PROCEDURE_ENTRY(fun1196_1733)(fun1196_1733, (obj_t)(object_96), BEOA);
}
}
}


/* _object->struct1486 */obj_t _object__struct1486_66___object(obj_t env_1908, obj_t object_1909)
{
return object__struct_50___object((object_t)(object_1909));
}


/* object->struct-default1019 */obj_t object__struct_default1019_241___object(object_t object_97)
{
FAILURE(string1505___object,string1506___object,(obj_t)(object_97));}


/* _object->struct-default1019 */obj_t _object__struct_default1019_206___object(obj_t env_1910, obj_t object_1911)
{
return object__struct_default1019_241___object((object_t)(object_1911));
}


/* struct+object->object */object_t struct_object__object_93___object(object_t object_98, obj_t struct_99)
{
{
obj_t arg1353_1748;
obj_t arg1355_1749;
{
obj_t pre_method_105_1751;
pre_method_105_1751 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)2));
if(INTEGERP(pre_method_105_1751)){
PROCEDURE_SET(struct_object__object_env_209___object, ((long)2), BUNSPEC);
arg1353_1748 = pre_method_105_1751;
}
 else {
long obj_class_num_177_1756;
obj_class_num_177_1756 = TYPE( object_98 );
{
obj_t arg1091_1757;
arg1091_1757 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)1));
{
long arg1044_1761;
{
long arg1045_1762;
arg1045_1762 = OBJECT_TYPE;
arg1044_1761 = (obj_class_num_177_1756-arg1045_1762);
}
arg1353_1748 = VECTOR_REF(arg1091_1757, arg1044_1761);
}
}
}
}
{
long arg1041_1768;
{
long arg1042_1769;
long arg1043_1770;
arg1042_1769 = TYPE( object_98 );
arg1043_1770 = OBJECT_TYPE;
arg1041_1768 = (arg1042_1769-arg1043_1770);
}
{
obj_t vector_1774;
vector_1774 = _classes__134___object;
arg1355_1749 = VECTOR_REF(vector_1774, arg1041_1768);
}
}
if(PROCEDUREP(arg1353_1748)){
obj_t aux_2823;
aux_2823 = PROCEDURE_ENTRY(arg1353_1748)(arg1353_1748, (obj_t)(object_98), struct_99, BEOA);
return (object_t)(aux_2823);
}
 else {
obj_t fun1197_1779;
fun1197_1779 = PROCEDURE_REF(struct_object__object_env_209___object, ((long)0));
{
obj_t aux_2829;
aux_2829 = PROCEDURE_ENTRY(fun1197_1779)(fun1197_1779, (obj_t)(object_98), struct_99, BEOA);
return (object_t)(aux_2829);
}
}
}
}


/* _struct+object->object1480 */obj_t _struct_object__object1480_1___object(obj_t env_1884, obj_t object_1885, obj_t struct_1886)
{
{
object_t aux_2834;
aux_2834 = struct_object__object_93___object((object_t)(object_1885), struct_1886);
return (obj_t)(aux_2834);
}
}


/* struct+object->object-default1020 */object_t struct_object__object_default1020_163___object(object_t object_100, obj_t struct_101)
{
FAILURE(string1507___object,string1508___object,struct_101);}


/* _struct+object->object-default1020 */obj_t _struct_object__object_default1020_71___object(obj_t env_1912, obj_t object_1913, obj_t struct_1914)
{
{
object_t aux_2839;
aux_2839 = struct_object__object_default1020_163___object((object_t)(object_1913), struct_1914);
return (obj_t)(aux_2839);
}
}

