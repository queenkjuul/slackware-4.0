/*===========================================================================*/
/*   (Ieee/input.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t the_string_1442_62___r4_input_6_10_2(obj_t);
static obj_t the_string_1441_114___r4_input_6_10_2(obj_t);
static obj_t the_string_1440_246___r4_input_6_10_2(obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t rgc_buffer_substring(obj_t, int, int);
static obj_t _char_ready__35___r4_input_6_10_2(obj_t, obj_t);
static obj_t toplevel_init_63___r4_input_6_10_2();
static obj_t _read_rp1436_167___r4_input_6_10_2(obj_t, obj_t, obj_t);
extern bool_t char_ready__201___r4_input_6_10_2(obj_t);
extern bool_t rgc_fill_buffer(obj_t);
static obj_t _read_line_106___r4_input_6_10_2(obj_t, obj_t);
static obj_t _read_line_grammar__25___r4_input_6_10_2 = BUNSPEC;
extern obj_t current_input_port;
extern obj_t read_of_strings_88___r4_input_6_10_2(obj_t);
extern obj_t read_lalrp_80___r4_input_6_10_2(obj_t, obj_t, obj_t, obj_t);
static obj_t _read_lalrp1437_129___r4_input_6_10_2(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1198___r4_input_6_10_2(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1156___r4_input_6_10_2(obj_t, obj_t);
static obj_t the_string_180___r4_input_6_10_2(obj_t);
static obj_t lambda1087___r4_input_6_10_2(obj_t, obj_t);
extern obj_t read_rp_218___r4_input_6_10_2(obj_t, obj_t);
static obj_t lambda1033___r4_input_6_10_2(obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___error(long, char *);
obj_t _about_to_read__202___r4_input_6_10_2 = BUNSPEC;
extern obj_t read_line_110___r4_input_6_10_2(obj_t);
static obj_t _read_char_89___r4_input_6_10_2(obj_t, obj_t);
static obj_t _read_of_strings_grammar__196___r4_input_6_10_2 = BUNSPEC;
static obj_t _peek_char_199___r4_input_6_10_2(obj_t, obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern int rgc_buffer_unget_char(obj_t, int);
static obj_t symbol2127___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2125___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2123___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2122___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2121___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2119___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2120___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2116___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2115___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2114___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2111___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2099___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2109___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2110___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2098___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2097___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2096___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2106___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2095___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2105___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2104___r4_input_6_10_2 = BUNSPEC;
static obj_t _read_of_strings_6___r4_input_6_10_2(obj_t, obj_t);
static obj_t symbol2092___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2091___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2101___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2086___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2085___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2076___r4_input_6_10_2 = BUNSPEC;
static obj_t symbol2073___r4_input_6_10_2 = BUNSPEC;
static obj_t _eof_object__147___r4_input_6_10_2(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_input_6_10_2();
static obj_t list2108___r4_input_6_10_2 = BUNSPEC;
static obj_t list2094___r4_input_6_10_2 = BUNSPEC;
static obj_t list2103___r4_input_6_10_2 = BUNSPEC;
extern obj_t read_char_74___r4_input_6_10_2(obj_t);
extern obj_t peek_char_171___r4_input_6_10_2(obj_t);
static obj_t require_initialization_114___r4_input_6_10_2 = BUNSPEC;
static obj_t cnst_init_137___r4_input_6_10_2();
extern bool_t eof_object__7___r4_input_6_10_2(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( read_rp_env_12___r4_input_6_10_2, _read_rp1436_167___r4_input_6_10_22129, _read_rp1436_167___r4_input_6_10_2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( peek_char_env_115___r4_input_6_10_2, _peek_char_199___r4_input_6_10_22130, va_generic_entry, _peek_char_199___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_of_strings_env_168___r4_input_6_10_2, _read_of_strings_6___r4_input_6_10_22131, va_generic_entry, _read_of_strings_6___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_line_env_128___r4_input_6_10_2, _read_line_106___r4_input_6_10_22132, va_generic_entry, _read_line_106___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_lalrp_env_134___r4_input_6_10_2, _read_lalrp1437_129___r4_input_6_10_22133, va_generic_entry, _read_lalrp1437_129___r4_input_6_10_2, -4 );
DEFINE_STATIC_PROCEDURE( proc2117___r4_input_6_10_2, lambda1198___r4_input_6_10_22134, lambda1198___r4_input_6_10_2, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc2112___r4_input_6_10_2, lambda1156___r4_input_6_10_22135, lambda1156___r4_input_6_10_2, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc2075___r4_input_6_10_2, lambda1087___r4_input_6_10_22136, lambda1087___r4_input_6_10_2, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc2074___r4_input_6_10_2, lambda1033___r4_input_6_10_22137, lambda1033___r4_input_6_10_2, 0L, 1 );
DEFINE_STRING( string2126___r4_input_6_10_2, string2126___r4_input_6_10_22138, "READ-OF-STRINGS:Wrong number of arguments", 41 );
DEFINE_STRING( string2124___r4_input_6_10_2, string2124___r4_input_6_10_22139, "READ-LINE:Wrong number of arguments", 35 );
DEFINE_STRING( string2118___r4_input_6_10_2, string2118___r4_input_6_10_22140, "PEEK-CHAR:Wrong number of arguments", 35 );
DEFINE_STRING( string2113___r4_input_6_10_2, string2113___r4_input_6_10_22141, "READ-CHAR:Wrong number of arguments", 35 );
DEFINE_STRING( string2107___r4_input_6_10_2, string2107___r4_input_6_10_22142, "PAIR", 4 );
DEFINE_STRING( string2093___r4_input_6_10_2, string2093___r4_input_6_10_22143, "READ/RP:Wrong number of arguments", 33 );
DEFINE_STRING( string2102___r4_input_6_10_2, string2102___r4_input_6_10_22144, "READ/LALRP:Wrong number of arguments", 36 );
DEFINE_STRING( string2089___r4_input_6_10_2, string2089___r4_input_6_10_22145, "BSTRING", 7 );
DEFINE_STRING( string2090___r4_input_6_10_2, string2090___r4_input_6_10_22146, "", 0 );
DEFINE_STRING( string2100___r4_input_6_10_2, string2100___r4_input_6_10_22147, "PROCEDURE", 9 );
DEFINE_STRING( string2088___r4_input_6_10_2, string2088___r4_input_6_10_22148, "Illegal range", 13 );
DEFINE_STRING( string2087___r4_input_6_10_2, string2087___r4_input_6_10_22149, "the-substring", 13 );
DEFINE_STRING( string2084___r4_input_6_10_2, string2084___r4_input_6_10_22150, "Illegal match", 13 );
DEFINE_STRING( string2083___r4_input_6_10_2, string2083___r4_input_6_10_22151, "regular-grammar", 15 );
DEFINE_STRING( string2082___r4_input_6_10_2, string2082___r4_input_6_10_22152, "UCHAR", 5 );
DEFINE_STRING( string2081___r4_input_6_10_2, string2081___r4_input_6_10_22153, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2079___r4_input_6_10_2, string2079___r4_input_6_10_22154, "string-ref", 10 );
DEFINE_STRING( string2080___r4_input_6_10_2, string2080___r4_input_6_10_22155, "index out of range", 18 );
DEFINE_STRING( string2078___r4_input_6_10_2, string2078___r4_input_6_10_22156, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/input.scm", 58 );
DEFINE_STRING( string2077___r4_input_6_10_2, string2077___r4_input_6_10_22157, "INPUT-PORT", 10 );
DEFINE_EXPORT_PROCEDURE( eof_object__env_183___r4_input_6_10_2, _eof_object__147___r4_input_6_10_22158, _eof_object__147___r4_input_6_10_2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ready__env_148___r4_input_6_10_2, _char_ready__35___r4_input_6_10_22159, va_generic_entry, _char_ready__35___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_char_env_52___r4_input_6_10_2, _read_char_89___r4_input_6_10_22160, va_generic_entry, _read_char_89___r4_input_6_10_2, -1 );


/* module-initialization */obj_t module_initialization_70___r4_input_6_10_2(long checksum_1764, char * from_1765)
{
if(CBOOL(require_initialization_114___r4_input_6_10_2)){
require_initialization_114___r4_input_6_10_2 = BBOOL(((bool_t)0));
cnst_init_137___r4_input_6_10_2();
imported_modules_init_94___r4_input_6_10_2();
toplevel_init_63___r4_input_6_10_2();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_input_6_10_2()
{
symbol2073___r4_input_6_10_2 = string_to_symbol("TOPLEVEL-INIT");
symbol2076___r4_input_6_10_2 = string_to_symbol("LAMBDA1087");
symbol2085___r4_input_6_10_2 = string_to_symbol("THE-STRING_1442");
symbol2086___r4_input_6_10_2 = string_to_symbol("LAMBDA1033");
symbol2091___r4_input_6_10_2 = string_to_symbol("THE-STRING_1441");
symbol2092___r4_input_6_10_2 = string_to_symbol("READ/RP");
symbol2095___r4_input_6_10_2 = string_to_symbol("FUNCALL");
symbol2096___r4_input_6_10_2 = string_to_symbol("grammar");
symbol2097___r4_input_6_10_2 = string_to_symbol("port");
{
obj_t aux_1781;
{
obj_t aux_1782;
{
obj_t aux_1783;
aux_1783 = MAKE_PAIR(symbol2097___r4_input_6_10_2, BNIL);
aux_1782 = MAKE_PAIR(symbol2096___r4_input_6_10_2, aux_1783);
}
aux_1781 = MAKE_PAIR(symbol2096___r4_input_6_10_2, aux_1782);
}
list2094___r4_input_6_10_2 = MAKE_PAIR(symbol2095___r4_input_6_10_2, aux_1781);
}
symbol2098___r4_input_6_10_2 = string_to_symbol("_");
symbol2099___r4_input_6_10_2 = string_to_symbol("_READ/RP1436");
symbol2101___r4_input_6_10_2 = string_to_symbol("READ/LALRP");
symbol2104___r4_input_6_10_2 = string_to_symbol("lalr");
symbol2105___r4_input_6_10_2 = string_to_symbol("rgc");
symbol2106___r4_input_6_10_2 = string_to_symbol("eof-object?-env");
{
obj_t aux_1794;
{
obj_t aux_1795;
{
obj_t aux_1796;
{
obj_t aux_1797;
{
obj_t aux_1798;
aux_1798 = MAKE_PAIR(symbol2106___r4_input_6_10_2, BNIL);
aux_1797 = MAKE_PAIR(symbol2097___r4_input_6_10_2, aux_1798);
}
aux_1796 = MAKE_PAIR(symbol2105___r4_input_6_10_2, aux_1797);
}
aux_1795 = MAKE_PAIR(symbol2104___r4_input_6_10_2, aux_1796);
}
aux_1794 = MAKE_PAIR(symbol2104___r4_input_6_10_2, aux_1795);
}
list2103___r4_input_6_10_2 = MAKE_PAIR(symbol2095___r4_input_6_10_2, aux_1794);
}
symbol2109___r4_input_6_10_2 = string_to_symbol("arg1152");
{
obj_t aux_1806;
{
obj_t aux_1807;
{
obj_t aux_1808;
{
obj_t aux_1809;
{
obj_t aux_1810;
aux_1810 = MAKE_PAIR(symbol2109___r4_input_6_10_2, BNIL);
aux_1809 = MAKE_PAIR(symbol2097___r4_input_6_10_2, aux_1810);
}
aux_1808 = MAKE_PAIR(symbol2105___r4_input_6_10_2, aux_1809);
}
aux_1807 = MAKE_PAIR(symbol2104___r4_input_6_10_2, aux_1808);
}
aux_1806 = MAKE_PAIR(symbol2104___r4_input_6_10_2, aux_1807);
}
list2108___r4_input_6_10_2 = MAKE_PAIR(symbol2095___r4_input_6_10_2, aux_1806);
}
symbol2110___r4_input_6_10_2 = string_to_symbol("_READ/LALRP1437");
symbol2111___r4_input_6_10_2 = string_to_symbol("READ-CHAR");
symbol2114___r4_input_6_10_2 = string_to_symbol("LAMBDA1156");
symbol2115___r4_input_6_10_2 = string_to_symbol("THE-STRING_1440");
symbol2116___r4_input_6_10_2 = string_to_symbol("PEEK-CHAR");
symbol2119___r4_input_6_10_2 = string_to_symbol("LAMBDA1198");
symbol2120___r4_input_6_10_2 = string_to_symbol("THE-STRING");
symbol2121___r4_input_6_10_2 = string_to_symbol("EOF-OBJECT?");
symbol2122___r4_input_6_10_2 = string_to_symbol("CHAR-READY?");
symbol2123___r4_input_6_10_2 = string_to_symbol("READ-LINE");
symbol2125___r4_input_6_10_2 = string_to_symbol("READ-OF-STRINGS");
return (symbol2127___r4_input_6_10_2 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r4_input_6_10_2()
{
{
obj_t symbol1416_1131;
symbol1416_1131 = symbol2073___r4_input_6_10_2;
{
PUSH_TRACE(symbol1416_1131);
BUNSPEC;
{
obj_t aux1415_1132;
{
obj_t lambda1033_1152;
lambda1033_1152 = proc2074___r4_input_6_10_2;
_read_line_grammar__25___r4_input_6_10_2 = lambda1033_1152;
}
{
obj_t lambda1087_1151;
lambda1087_1151 = proc2075___r4_input_6_10_2;
_read_of_strings_grammar__196___r4_input_6_10_2 = lambda1087_1151;
}
aux1415_1132 = (_about_to_read__202___r4_input_6_10_2 = BUNSPEC,
BUNSPEC);
POP_TRACE();
return aux1415_1132;
}
}
}
}


/* lambda1087 */obj_t lambda1087___r4_input_6_10_2(obj_t env_1153, obj_t input_port_219_1154)
{
{
obj_t input_port_219_382;
input_port_219_382 = input_port_219_1154;
{
long last_match_133_439;
long last_match_133_448;
long last_match_133_458;
long last_match_133_468;
long last_match_133_477;
ignore_506:
{
obj_t input_port_219_898;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_898 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
RGC_START_MATCH(input_port_219_898);
}
{
int match_404;
{
long aux_1837;
last_match_133_439 = ((long)2);
state_0_1020_174_493:
{
int current_char_37_441;
{
obj_t input_port_219_927;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_927 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
current_char_37_441 = RGC_BUFFER_GET_CHAR(input_port_219_927);
}
{
bool_t test_1844;
{
long aux_1845;
aux_1845 = (long)(current_char_37_441);
test_1844 = (aux_1845==((long)0));
}
if(test_1844){
{
bool_t test1119_443;
{
obj_t input_port_219_930;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_930 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
test1119_443 = RGC_BUFFER_EMPTY(input_port_219_930);
}
if(test1119_443){
bool_t test1120_444;
{
obj_t input_port_219_931;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_931 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
test1120_444 = rgc_fill_buffer(input_port_219_931);
}
if(test1120_444){
goto state_0_1020_174_493;
}
 else {
aux_1837 = last_match_133_439;
}
}
 else {
last_match_133_448 = last_match_133_439;
state_1_1021_68_492:
{
long new_match_93_450;
{
obj_t input_port_219_938;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_938 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_938);
}
new_match_93_450 = ((long)1);
{
int current_char_37_451;
{
obj_t input_port_219_939;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_939 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
current_char_37_451 = RGC_BUFFER_GET_CHAR(input_port_219_939);
}
{
bool_t test_1874;
{
long aux_1875;
aux_1875 = (long)(current_char_37_451);
test_1874 = (aux_1875==((long)0));
}
if(test_1874){
{
bool_t test1126_453;
{
obj_t input_port_219_942;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_942 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
test1126_453 = RGC_BUFFER_EMPTY(input_port_219_942);
}
if(test1126_453){
bool_t test1127_454;
{
obj_t input_port_219_943;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_943 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
test1127_454 = rgc_fill_buffer(input_port_219_943);
}
if(test1127_454){
goto state_1_1021_68_492;
}
 else {
aux_1837 = new_match_93_450;
}
}
 else {
last_match_133_458 = new_match_93_450;
state_5_1025_208_491:
{
long new_match_93_460;
{
obj_t input_port_219_950;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_950 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_950);
}
new_match_93_460 = ((long)1);
{
int current_char_37_461;
{
obj_t input_port_219_951;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_951 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
current_char_37_461 = RGC_BUFFER_GET_CHAR(input_port_219_951);
}
{
bool_t test_1904;
{
long aux_1905;
aux_1905 = (long)(current_char_37_461);
test_1904 = (aux_1905==((long)0));
}
if(test_1904){
{
bool_t test1133_463;
{
obj_t input_port_219_954;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_954 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
test1133_463 = RGC_BUFFER_EMPTY(input_port_219_954);
}
if(test1133_463){
bool_t test1134_464;
{
obj_t input_port_219_955;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_955 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
test1134_464 = rgc_fill_buffer(input_port_219_955);
}
if(test1134_464){
goto state_5_1025_208_491;
}
 else {
aux_1837 = new_match_93_460;
}
}
 else {
long last_match_133_1922;
last_match_133_1922 = new_match_93_460;
last_match_133_458 = last_match_133_1922;
goto state_5_1025_208_491;
}
}
}
 else {
bool_t test_1923;
{
bool_t test_1924;
{
bool_t test_1925;
{
long aux_1926;
aux_1926 = (long)(current_char_37_461);
test_1925 = (aux_1926==((long)10));
}
if(test_1925){
test_1924 = ((bool_t)1);
}
 else {
long aux_1929;
aux_1929 = (long)(current_char_37_461);
test_1924 = (aux_1929==((long)9));
}
}
if(test_1924){
test_1923 = ((bool_t)1);
}
 else {
long aux_1932;
aux_1932 = (long)(current_char_37_461);
test_1923 = (aux_1932==((long)32));
}
}
if(test_1923){
aux_1837 = new_match_93_460;
}
 else {
{
long last_match_133_1935;
last_match_133_1935 = new_match_93_460;
last_match_133_458 = last_match_133_1935;
goto state_5_1025_208_491;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_1936;
{
bool_t test_1937;
{
bool_t test_1938;
{
long aux_1939;
aux_1939 = (long)(current_char_37_451);
test_1938 = (aux_1939==((long)10));
}
if(test_1938){
test_1937 = ((bool_t)1);
}
 else {
long aux_1942;
aux_1942 = (long)(current_char_37_451);
test_1937 = (aux_1942==((long)9));
}
}
if(test_1937){
test_1936 = ((bool_t)1);
}
 else {
long aux_1945;
aux_1945 = (long)(current_char_37_451);
test_1936 = (aux_1945==((long)32));
}
}
if(test_1936){
aux_1837 = new_match_93_450;
}
 else {
{
long last_match_133_1948;
last_match_133_1948 = new_match_93_450;
last_match_133_458 = last_match_133_1948;
goto state_5_1025_208_491;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_1949;
{
bool_t test_1950;
{
bool_t test_1951;
{
long aux_1952;
aux_1952 = (long)(current_char_37_441);
test_1951 = (aux_1952==((long)10));
}
if(test_1951){
test_1950 = ((bool_t)1);
}
 else {
long aux_1955;
aux_1955 = (long)(current_char_37_441);
test_1950 = (aux_1955==((long)9));
}
}
if(test_1950){
test_1949 = ((bool_t)1);
}
 else {
long aux_1958;
aux_1958 = (long)(current_char_37_441);
test_1949 = (aux_1958==((long)32));
}
}
if(test_1949){
last_match_133_468 = last_match_133_439;
state_2_1022_149_490:
{
long new_match_93_470;
{
obj_t input_port_219_962;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_962 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_962);
}
new_match_93_470 = ((long)0);
{
int current_char_37_471;
{
obj_t input_port_219_963;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_963 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
current_char_37_471 = RGC_BUFFER_GET_CHAR(input_port_219_963);
}
{
bool_t test_1973;
{
long aux_1974;
aux_1974 = (long)(current_char_37_471);
test_1973 = (aux_1974==((long)0));
}
if(test_1973){
{
bool_t test1140_473;
{
bool_t res1404_970;
{
obj_t input_port_219_966;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_966 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
{
bool_t _andtest_1031_967;
_andtest_1031_967 = RGC_BUFFER_EMPTY(input_port_219_966);
if(_andtest_1031_967){
res1404_970 = rgc_fill_buffer(input_port_219_966);
}
 else {
res1404_970 = ((bool_t)0);
}
}
}
test1140_473 = res1404_970;
}
if(test1140_473){
goto state_2_1022_149_490;
}
 else {
aux_1837 = new_match_93_470;
}
}
}
 else {
bool_t test_1986;
{
bool_t test_1987;
{
bool_t test_1988;
{
long aux_1989;
aux_1989 = (long)(current_char_37_471);
test_1988 = (aux_1989==((long)10));
}
if(test_1988){
test_1987 = ((bool_t)1);
}
 else {
long aux_1992;
aux_1992 = (long)(current_char_37_471);
test_1987 = (aux_1992==((long)9));
}
}
if(test_1987){
test_1986 = ((bool_t)1);
}
 else {
long aux_1995;
aux_1995 = (long)(current_char_37_471);
test_1986 = (aux_1995==((long)32));
}
}
if(test_1986){
last_match_133_477 = new_match_93_470;
state_3_1023_8_489:
{
long new_match_93_479;
{
obj_t input_port_219_977;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_977 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_977);
}
new_match_93_479 = ((long)0);
{
int current_char_37_480;
{
obj_t input_port_219_978;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_978 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
current_char_37_480 = RGC_BUFFER_GET_CHAR(input_port_219_978);
}
{
bool_t test_2010;
{
long aux_2011;
aux_2011 = (long)(current_char_37_480);
test_2010 = (aux_2011==((long)0));
}
if(test_2010){
{
bool_t test1146_482;
{
bool_t res1405_985;
{
obj_t input_port_219_981;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_981 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
{
bool_t _andtest_1031_982;
_andtest_1031_982 = RGC_BUFFER_EMPTY(input_port_219_981);
if(_andtest_1031_982){
res1405_985 = rgc_fill_buffer(input_port_219_981);
}
 else {
res1405_985 = ((bool_t)0);
}
}
}
test1146_482 = res1405_985;
}
if(test1146_482){
goto state_3_1023_8_489;
}
 else {
aux_1837 = new_match_93_479;
}
}
}
 else {
bool_t test_2023;
{
bool_t test_2024;
{
bool_t test_2025;
{
long aux_2026;
aux_2026 = (long)(current_char_37_480);
test_2025 = (aux_2026==((long)10));
}
if(test_2025){
test_2024 = ((bool_t)1);
}
 else {
long aux_2029;
aux_2029 = (long)(current_char_37_480);
test_2024 = (aux_2029==((long)9));
}
}
if(test_2024){
test_2023 = ((bool_t)1);
}
 else {
long aux_2032;
aux_2032 = (long)(current_char_37_480);
test_2023 = (aux_2032==((long)32));
}
}
if(test_2023){
{
long last_match_133_2035;
last_match_133_2035 = new_match_93_479;
last_match_133_477 = last_match_133_2035;
goto state_3_1023_8_489;
}
}
 else {
aux_1837 = new_match_93_479;
}
}
}
}
}
}
 else {
aux_1837 = new_match_93_470;
}
}
}
}
}
}
 else {
{
long last_match_133_2036;
last_match_133_2036 = last_match_133_439;
last_match_133_448 = last_match_133_2036;
goto state_1_1021_68_492;
}
}
}
}
}
match_404 = (int)(aux_1837);
}
switch ((long)(match_404)){
case ((long)2) : 
{
bool_t test1095_415;
{
int arg1098_418;
{
int res1401_909;
{
obj_t input_port_219_908;
if(INPUT_PORTP(input_port_219_382)){
input_port_219_908 = input_port_219_382;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_382, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
{
long aux_2043;
aux_2043 = RGC_BUFFER_LENGTH(input_port_219_908);
res1401_909 = (int)(aux_2043);
}
}
arg1098_418 = res1401_909;
}
{
long aux_2046;
aux_2046 = (long)(arg1098_418);
test1095_415 = (aux_2046==((long)0));
}
}
if(test1095_415){
return BCNST(256);
}
 else {
obj_t arg1096_416;
arg1096_416 = the_string_1442_62___r4_input_6_10_2(input_port_219_382);
{
unsigned char res1402_920;
{
bool_t test_2051;
{
long aux_2052;
aux_2052 = STRING_LENGTH(arg1096_416);
test_2051 = BOUND_CHECK(((long)0), aux_2052);
}
if(test_2051){
res1402_920 = STRING_REF(arg1096_416, ((long)0));
}
 else {
obj_t aux_2056;
{
obj_t aux1569_1295;
aux1569_1295 = debug_error_location_199___error(string2079___r4_input_6_10_2, string2080___r4_input_6_10_2, BINT(((long)0)), string2081___r4_input_6_10_2, BINT(((long)7610)));
if(CHARP(aux1569_1295)){
aux_2056 = aux1569_1295;
}
 else {
bigloo_type_error_location_103___error(symbol2076___r4_input_6_10_2, string2082___r4_input_6_10_2, aux1569_1295, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
res1402_920 = (unsigned char)CCHAR(aux_2056);
}
}
return BCHAR(res1402_920);
}
}
}
break;
case ((long)1) : 
return the_string_1442_62___r4_input_6_10_2(input_port_219_382);
break;
case ((long)0) : 
goto ignore_506;
break;
default: 
return debug_error_location_199___error(string2083___r4_input_6_10_2, string2084___r4_input_6_10_2, BINT(match_404), string2081___r4_input_6_10_2, BINT(((long)7610)));
}
}
}
}
}


/* the-string_1442 */obj_t the_string_1442_62___r4_input_6_10_2(obj_t input_port_219_1186)
{
{
int arg1115_437;
{
int res1403_923;
{
obj_t input_port_219_922;
if(INPUT_PORTP(input_port_219_1186)){
input_port_219_922 = input_port_219_1186;
}
 else {
bigloo_type_error_location_103___error(symbol2085___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1186, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
{
long aux_2078;
aux_2078 = RGC_BUFFER_LENGTH(input_port_219_922);
res1403_923 = (int)(aux_2078);
}
}
arg1115_437 = res1403_923;
}
{
obj_t input_port_219_924;
int start_925;
if(INPUT_PORTP(input_port_219_1186)){
input_port_219_924 = input_port_219_1186;
}
 else {
bigloo_type_error_location_103___error(symbol2085___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1186, string2078___r4_input_6_10_2, BINT(((long)5604)));
exit( -1 );}
start_925 = (int)(((long)0));
return rgc_buffer_substring(input_port_219_924, start_925, arg1115_437);
}
}
}


/* lambda1033 */obj_t lambda1033___r4_input_6_10_2(obj_t env_1155, obj_t input_port_219_1156)
{
{
obj_t input_port_219_270;
input_port_219_270 = input_port_219_1156;
{
long min_317;
long max_318;
long last_match_133_331;
long last_match_133_338;
long last_match_133_346;
{
obj_t input_port_219_813;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_813 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
RGC_START_MATCH(input_port_219_813);
}
{
int match_292;
{
long aux_2094;
last_match_133_331 = ((long)3);
state_0_1012_101_367:
{
int current_char_37_333;
{
obj_t input_port_219_862;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_862 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
current_char_37_333 = RGC_BUFFER_GET_CHAR(input_port_219_862);
}
{
bool_t test_2101;
{
long aux_2102;
aux_2102 = (long)(current_char_37_333);
test_2101 = (aux_2102==((long)0));
}
if(test_2101){
{
bool_t test1070_335;
{
obj_t input_port_219_865;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_865 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
test1070_335 = RGC_BUFFER_EMPTY(input_port_219_865);
}
if(test1070_335){
bool_t test1071_336;
{
obj_t input_port_219_866;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_866 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
test1071_336 = rgc_fill_buffer(input_port_219_866);
}
if(test1071_336){
goto state_0_1012_101_367;
}
 else {
aux_2094 = last_match_133_331;
}
}
 else {
last_match_133_338 = last_match_133_331;
state_1_1013_67_366:
{
long new_match_93_340;
{
obj_t input_port_219_872;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_872 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_872);
}
new_match_93_340 = ((long)1);
{
int current_char_37_341;
{
obj_t input_port_219_873;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_873 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
current_char_37_341 = RGC_BUFFER_GET_CHAR(input_port_219_873);
}
{
bool_t test_2131;
{
long aux_2132;
aux_2132 = (long)(current_char_37_341);
test_2131 = (aux_2132==((long)0));
}
if(test_2131){
{
bool_t test1075_343;
{
obj_t input_port_219_876;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_876 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
test1075_343 = RGC_BUFFER_EMPTY(input_port_219_876);
}
if(test1075_343){
bool_t test1076_344;
{
obj_t input_port_219_877;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_877 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
test1076_344 = rgc_fill_buffer(input_port_219_877);
}
if(test1076_344){
goto state_1_1013_67_366;
}
 else {
aux_2094 = new_match_93_340;
}
}
 else {
last_match_133_346 = new_match_93_340;
state_4_1016_66_365:
{
long new_match_93_348;
{
obj_t input_port_219_883;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_883 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_883);
}
new_match_93_348 = ((long)1);
{
int current_char_37_349;
{
obj_t input_port_219_884;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_884 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
current_char_37_349 = RGC_BUFFER_GET_CHAR(input_port_219_884);
}
{
bool_t test_2161;
{
long aux_2162;
aux_2162 = (long)(current_char_37_349);
test_2161 = (aux_2162==((long)0));
}
if(test_2161){
{
bool_t test1080_351;
{
obj_t input_port_219_887;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_887 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
test1080_351 = RGC_BUFFER_EMPTY(input_port_219_887);
}
if(test1080_351){
bool_t test1081_352;
{
obj_t input_port_219_888;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_888 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
test1081_352 = rgc_fill_buffer(input_port_219_888);
}
if(test1081_352){
goto state_4_1016_66_365;
}
 else {
aux_2094 = new_match_93_348;
}
}
 else {
long last_match_133_2179;
last_match_133_2179 = new_match_93_348;
last_match_133_346 = last_match_133_2179;
goto state_4_1016_66_365;
}
}
}
 else {
bool_t test_2180;
{
long aux_2181;
aux_2181 = (long)(current_char_37_349);
test_2180 = (aux_2181==((long)10));
}
if(test_2180){
{
long new_match_93_892;
{
obj_t input_port_219_893;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_893 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_893);
}
new_match_93_892 = ((long)0);
aux_2094 = new_match_93_892;
}
}
 else {
{
long last_match_133_2190;
last_match_133_2190 = new_match_93_348;
last_match_133_346 = last_match_133_2190;
goto state_4_1016_66_365;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_2191;
{
long aux_2192;
aux_2192 = (long)(current_char_37_341);
test_2191 = (aux_2192==((long)10));
}
if(test_2191){
{
long new_match_93_881;
{
obj_t input_port_219_882;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_882 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_882);
}
new_match_93_881 = ((long)0);
aux_2094 = new_match_93_881;
}
}
 else {
{
long last_match_133_2201;
last_match_133_2201 = new_match_93_340;
last_match_133_346 = last_match_133_2201;
goto state_4_1016_66_365;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_2202;
{
long aux_2203;
aux_2203 = (long)(current_char_37_333);
test_2202 = (aux_2203==((long)10));
}
if(test_2202){
{
long new_match_93_870;
{
obj_t input_port_219_871;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_871 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_871);
}
new_match_93_870 = ((long)2);
aux_2094 = new_match_93_870;
}
}
 else {
{
long last_match_133_2212;
last_match_133_2212 = last_match_133_331;
last_match_133_338 = last_match_133_2212;
goto state_1_1013_67_366;
}
}
}
}
}
match_292 = (int)(aux_2094);
}
switch ((long)(match_292)){
case ((long)3) : 
{
bool_t test1046_307;
{
int arg1049_310;
{
int res1397_828;
{
obj_t input_port_219_827;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_827 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
{
long aux_2219;
aux_2219 = RGC_BUFFER_LENGTH(input_port_219_827);
res1397_828 = (int)(aux_2219);
}
}
arg1049_310 = res1397_828;
}
{
long aux_2222;
aux_2222 = (long)(arg1049_310);
test1046_307 = (aux_2222==((long)0));
}
}
if(test1046_307){
return BCNST(256);
}
 else {
obj_t arg1047_308;
arg1047_308 = the_string_1441_114___r4_input_6_10_2(input_port_219_270);
{
unsigned char res1398_839;
{
bool_t test_2227;
{
long aux_2228;
aux_2228 = STRING_LENGTH(arg1047_308);
test_2227 = BOUND_CHECK(((long)0), aux_2228);
}
if(test_2227){
res1398_839 = STRING_REF(arg1047_308, ((long)0));
}
 else {
obj_t aux_2232;
{
obj_t aux1727_1427;
aux1727_1427 = debug_error_location_199___error(string2079___r4_input_6_10_2, string2080___r4_input_6_10_2, BINT(((long)0)), string2081___r4_input_6_10_2, BINT(((long)7610)));
if(CHARP(aux1727_1427)){
aux_2232 = aux1727_1427;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2082___r4_input_6_10_2, aux1727_1427, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
res1398_839 = (unsigned char)CCHAR(aux_2232);
}
}
return BCHAR(res1398_839);
}
}
}
break;
case ((long)2) : 
return string2090___r4_input_6_10_2;
break;
case ((long)1) : 
return the_string_1441_114___r4_input_6_10_2(input_port_219_270);
break;
case ((long)0) : 
{
long arg1038_297;
{
int arg1039_298;
{
int res1396_815;
{
obj_t input_port_219_814;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_814 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
{
long aux_2249;
aux_2249 = RGC_BUFFER_LENGTH(input_port_219_814);
res1396_815 = (int)(aux_2249);
}
}
arg1039_298 = res1396_815;
}
{
long aux_2252;
aux_2252 = (long)(arg1039_298);
arg1038_297 = (aux_2252-((long)1));
}
}
min_317 = ((long)0);
max_318 = arg1038_297;
{
bool_t test1057_320;
if((min_317>=((long)0))){
bool_t test1062_325;
{
int arg1063_326;
{
int res1399_844;
{
obj_t input_port_219_843;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_843 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
{
long aux_2262;
aux_2262 = RGC_BUFFER_LENGTH(input_port_219_843);
res1399_844 = (int)(aux_2262);
}
}
arg1063_326 = res1399_844;
}
{
long aux_2265;
aux_2265 = (long)(arg1063_326);
test1062_325 = (max_318<=aux_2265);
}
}
if(test1062_325){
test1057_320 = (max_318>=min_317);
}
 else {
test1057_320 = ((bool_t)0);
}
}
 else {
test1057_320 = ((bool_t)0);
}
if(test1057_320){
obj_t input_port_219_849;
int start_850;
int stop_851;
if(INPUT_PORTP(input_port_219_270)){
input_port_219_849 = input_port_219_270;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_270, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
start_850 = (int)(min_317);
stop_851 = (int)(max_318);
return rgc_buffer_substring(input_port_219_849, start_850, stop_851);
}
 else {
obj_t arg1060_323;
{
obj_t aux_2281;
obj_t aux_2279;
aux_2281 = BINT(max_318);
aux_2279 = BINT(min_317);
arg1060_323 = MAKE_PAIR(aux_2279, aux_2281);
}
{
obj_t aux1714_1415;
aux1714_1415 = debug_error_location_199___error(string2087___r4_input_6_10_2, string2088___r4_input_6_10_2, arg1060_323, string2081___r4_input_6_10_2, BINT(((long)7610)));
if(STRINGP(aux1714_1415)){
return aux1714_1415;
}
 else {
bigloo_type_error_location_103___error(symbol2086___r4_input_6_10_2, string2089___r4_input_6_10_2, aux1714_1415, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
}
}
}
break;
default: 
return debug_error_location_199___error(string2083___r4_input_6_10_2, string2084___r4_input_6_10_2, BINT(match_292), string2081___r4_input_6_10_2, BINT(((long)7610)));
}
}
}
}
}


/* the-string_1441 */obj_t the_string_1441_114___r4_input_6_10_2(obj_t input_port_219_1185)
{
{
int arg1066_329;
{
int res1400_858;
{
obj_t input_port_219_857;
if(INPUT_PORTP(input_port_219_1185)){
input_port_219_857 = input_port_219_1185;
}
 else {
bigloo_type_error_location_103___error(symbol2091___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1185, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
{
long aux_2301;
aux_2301 = RGC_BUFFER_LENGTH(input_port_219_857);
res1400_858 = (int)(aux_2301);
}
}
arg1066_329 = res1400_858;
}
{
obj_t input_port_219_859;
int start_860;
if(INPUT_PORTP(input_port_219_1185)){
input_port_219_859 = input_port_219_1185;
}
 else {
bigloo_type_error_location_103___error(symbol2091___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1185, string2078___r4_input_6_10_2, BINT(((long)4759)));
exit( -1 );}
start_860 = (int)(((long)0));
return rgc_buffer_substring(input_port_219_859, start_860, arg1066_329);
}
}
}


/* read/rp */obj_t read_rp_218___r4_input_6_10_2(obj_t grammar_1, obj_t port_2)
{
{
obj_t symbol1418_1735;
symbol1418_1735 = symbol2092___r4_input_6_10_2;
{
PUSH_TRACE(symbol1418_1735);
BUNSPEC;
{
obj_t aux1417_1736;
{
bool_t test1774_1737;
test1774_1737 = PROCEDURE_CORRECT_ARITYP(grammar_1, ((long)1));
if(test1774_1737){
aux1417_1736 = PROCEDURE_ENTRY(grammar_1)(grammar_1, port_2, BEOA);
}
 else {
error_location_112___error(string2093___r4_input_6_10_2, list2094___r4_input_6_10_2, grammar_1, string2078___r4_input_6_10_2, BINT(((long)2644)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
POP_TRACE();
return aux1417_1736;
}
}
}
}


/* _read/rp1436 */obj_t _read_rp1436_167___r4_input_6_10_2(obj_t env_1157, obj_t grammar_1158, obj_t port_1159)
{
{
obj_t grammar_1738;
obj_t port_1739;
if(PROCEDUREP(grammar_1158)){
grammar_1738 = grammar_1158;
}
 else {
bigloo_type_error_location_103___error(symbol2099___r4_input_6_10_2, string2100___r4_input_6_10_2, grammar_1158, string2078___r4_input_6_10_2, BINT(((long)2603)));
exit( -1 );}
if(INPUT_PORTP(port_1159)){
port_1739 = port_1159;
}
 else {
bigloo_type_error_location_103___error(symbol2099___r4_input_6_10_2, string2077___r4_input_6_10_2, port_1159, string2078___r4_input_6_10_2, BINT(((long)2603)));
exit( -1 );}
{
obj_t symbol1418_1740;
symbol1418_1740 = symbol2092___r4_input_6_10_2;
{
PUSH_TRACE(symbol1418_1740);
BUNSPEC;
{
obj_t aux1417_1741;
{
bool_t test1774_1742;
test1774_1742 = PROCEDURE_CORRECT_ARITYP(grammar_1738, ((long)1));
if(test1774_1742){
aux1417_1741 = PROCEDURE_ENTRY(grammar_1738)(grammar_1738, port_1739, BEOA);
}
 else {
error_location_112___error(string2093___r4_input_6_10_2, list2094___r4_input_6_10_2, grammar_1738, string2078___r4_input_6_10_2, BINT(((long)2644)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
POP_TRACE();
return aux1417_1741;
}
}
}
}
}


/* read/lalrp */obj_t read_lalrp_80___r4_input_6_10_2(obj_t lalr_3, obj_t rgc_4, obj_t port_5, obj_t eof_fun__175_6)
{
{
obj_t symbol1420_1743;
symbol1420_1743 = symbol2101___r4_input_6_10_2;
{
PUSH_TRACE(symbol1420_1743);
BUNSPEC;
{
obj_t aux1419_1744;
if(NULLP(eof_fun__175_6)){
bool_t test1796_1745;
test1796_1745 = PROCEDURE_CORRECT_ARITYP(lalr_3, ((long)3));
if(test1796_1745){
aux1419_1744 = PROCEDURE_ENTRY(lalr_3)(lalr_3, rgc_4, port_5, eof_object__env_183___r4_input_6_10_2, BEOA);
}
 else {
error_location_112___error(string2102___r4_input_6_10_2, list2103___r4_input_6_10_2, lalr_3, string2078___r4_input_6_10_2, BINT(((long)2967)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
 else {
obj_t arg1152_1746;
{
obj_t pair_1747;
if(PAIRP(eof_fun__175_6)){
pair_1747 = eof_fun__175_6;
}
 else {
bigloo_type_error_location_103___error(symbol2101___r4_input_6_10_2, string2107___r4_input_6_10_2, eof_fun__175_6, string2078___r4_input_6_10_2, BINT(((long)3018)));
exit( -1 );}
arg1152_1746 = CAR(pair_1747);
}
{
bool_t test1810_1748;
test1810_1748 = PROCEDURE_CORRECT_ARITYP(lalr_3, ((long)3));
if(test1810_1748){
aux1419_1744 = PROCEDURE_ENTRY(lalr_3)(lalr_3, rgc_4, port_5, arg1152_1746, BEOA);
}
 else {
error_location_112___error(string2102___r4_input_6_10_2, list2108___r4_input_6_10_2, lalr_3, string2078___r4_input_6_10_2, BINT(((long)3002)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
}
POP_TRACE();
return aux1419_1744;
}
}
}
}


/* _read/lalrp1437 */obj_t _read_lalrp1437_129___r4_input_6_10_2(obj_t env_1160, obj_t lalr_1161, obj_t rgc_1162, obj_t port_1163, obj_t eof_fun__175_1164)
{
{
obj_t lalr_1749;
obj_t rgc_1750;
obj_t port_1751;
obj_t eof_fun__175_1752;
if(PROCEDUREP(lalr_1161)){
lalr_1749 = lalr_1161;
}
 else {
bigloo_type_error_location_103___error(symbol2110___r4_input_6_10_2, string2100___r4_input_6_10_2, lalr_1161, string2078___r4_input_6_10_2, BINT(((long)2883)));
exit( -1 );}
if(PROCEDUREP(rgc_1162)){
rgc_1750 = rgc_1162;
}
 else {
bigloo_type_error_location_103___error(symbol2110___r4_input_6_10_2, string2100___r4_input_6_10_2, rgc_1162, string2078___r4_input_6_10_2, BINT(((long)2883)));
exit( -1 );}
if(INPUT_PORTP(port_1163)){
port_1751 = port_1163;
}
 else {
bigloo_type_error_location_103___error(symbol2110___r4_input_6_10_2, string2077___r4_input_6_10_2, port_1163, string2078___r4_input_6_10_2, BINT(((long)2883)));
exit( -1 );}
eof_fun__175_1752 = eof_fun__175_1164;
{
obj_t symbol1420_1753;
symbol1420_1753 = symbol2101___r4_input_6_10_2;
{
PUSH_TRACE(symbol1420_1753);
BUNSPEC;
{
obj_t aux1419_1754;
if(NULLP(eof_fun__175_1752)){
bool_t test1796_1755;
test1796_1755 = PROCEDURE_CORRECT_ARITYP(lalr_1749, ((long)3));
if(test1796_1755){
aux1419_1754 = PROCEDURE_ENTRY(lalr_1749)(lalr_1749, rgc_1750, port_1751, eof_object__env_183___r4_input_6_10_2, BEOA);
}
 else {
error_location_112___error(string2102___r4_input_6_10_2, list2103___r4_input_6_10_2, lalr_1749, string2078___r4_input_6_10_2, BINT(((long)2967)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
 else {
obj_t arg1152_1756;
{
obj_t pair_1757;
if(PAIRP(eof_fun__175_1752)){
pair_1757 = eof_fun__175_1752;
}
 else {
bigloo_type_error_location_103___error(symbol2101___r4_input_6_10_2, string2107___r4_input_6_10_2, eof_fun__175_1752, string2078___r4_input_6_10_2, BINT(((long)3018)));
exit( -1 );}
arg1152_1756 = CAR(pair_1757);
}
{
bool_t test1810_1758;
test1810_1758 = PROCEDURE_CORRECT_ARITYP(lalr_1749, ((long)3));
if(test1810_1758){
aux1419_1754 = PROCEDURE_ENTRY(lalr_1749)(lalr_1749, rgc_1750, port_1751, arg1152_1756, BEOA);
}
 else {
error_location_112___error(string2102___r4_input_6_10_2, list2108___r4_input_6_10_2, lalr_1749, string2078___r4_input_6_10_2, BINT(((long)3002)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
}
POP_TRACE();
return aux1419_1754;
}
}
}
}
}


/* read-char */obj_t read_char_74___r4_input_6_10_2(obj_t ip_7)
{
{
obj_t symbol1423_1137;
symbol1423_1137 = symbol2111___r4_input_6_10_2;
{
PUSH_TRACE(symbol1423_1137);
BUNSPEC;
{
obj_t aux1422_1138;
{
obj_t grammar_509;
{
obj_t lambda1156_1167;
lambda1156_1167 = proc2112___r4_input_6_10_2;
grammar_509 = lambda1156_1167;
}
{
obj_t arg1153_510;
if(NULLP(ip_7)){
arg1153_510 = current_input_port;
}
 else {
obj_t pair_1048;
if(PAIRP(ip_7)){
pair_1048 = ip_7;
}
 else {
bigloo_type_error_location_103___error(symbol2111___r4_input_6_10_2, string2107___r4_input_6_10_2, ip_7, string2078___r4_input_6_10_2, BINT(((long)3448)));
exit( -1 );}
arg1153_510 = CAR(pair_1048);
}
{
obj_t port_1050;
if(INPUT_PORTP(arg1153_510)){
port_1050 = arg1153_510;
}
 else {
bigloo_type_error_location_103___error(symbol2111___r4_input_6_10_2, string2077___r4_input_6_10_2, arg1153_510, string2078___r4_input_6_10_2, BINT(((long)3394)));
exit( -1 );}
{
bool_t test1857_1536;
test1857_1536 = PROCEDURE_CORRECT_ARITYP(grammar_509, ((long)1));
if(test1857_1536){
aux1422_1138 = PROCEDURE_ENTRY(grammar_509)(grammar_509, port_1050, BEOA);
}
 else {
error_location_112___error(string2113___r4_input_6_10_2, list2094___r4_input_6_10_2, grammar_509, string2078___r4_input_6_10_2, BINT(((long)2644)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
}
}
}
POP_TRACE();
return aux1422_1138;
}
}
}
}


/* _read-char */obj_t _read_char_89___r4_input_6_10_2(obj_t env_1168, obj_t ip_1169)
{
return read_char_74___r4_input_6_10_2(ip_1169);
}


/* lambda1156 */obj_t lambda1156___r4_input_6_10_2(obj_t env_1170, obj_t input_port_219_1171)
{
{
obj_t input_port_219_513;
input_port_219_513 = input_port_219_1171;
{
long last_match_133_569;
{
obj_t input_port_219_996;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_996 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
RGC_START_MATCH(input_port_219_996);
}
{
int match_532;
{
long aux_2431;
last_match_133_569 = ((long)1);
state_0_1002_0_582:
{
int current_char_37_571;
{
obj_t input_port_219_1034;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_1034 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
current_char_37_571 = RGC_BUFFER_GET_CHAR(input_port_219_1034);
}
{
bool_t test_2438;
{
long aux_2439;
aux_2439 = (long)(current_char_37_571);
test_2438 = (aux_2439==((long)0));
}
if(test_2438){
{
bool_t test1191_573;
{
obj_t input_port_219_1037;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_1037 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
test1191_573 = RGC_BUFFER_EMPTY(input_port_219_1037);
}
if(test1191_573){
bool_t test1192_574;
{
obj_t input_port_219_1038;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_1038 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
test1192_574 = rgc_fill_buffer(input_port_219_1038);
}
if(test1192_574){
goto state_0_1002_0_582;
}
 else {
aux_2431 = last_match_133_569;
}
}
 else {
long new_match_93_1040;
{
obj_t input_port_219_1041;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_1041 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_1041);
}
new_match_93_1040 = ((long)0);
aux_2431 = new_match_93_1040;
}
}
}
 else {
{
long new_match_93_1043;
{
obj_t input_port_219_1044;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_1044 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_1044);
}
new_match_93_1043 = ((long)0);
aux_2431 = new_match_93_1043;
}
}
}
}
match_532 = (int)(aux_2431);
}
switch ((long)(match_532)){
case ((long)1) : 
{
bool_t test1167_545;
{
int arg1170_548;
{
int res1407_1016;
{
obj_t input_port_219_1015;
if(INPUT_PORTP(input_port_219_513)){
input_port_219_1015 = input_port_219_513;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_513, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
{
long aux_2474;
aux_2474 = RGC_BUFFER_LENGTH(input_port_219_1015);
res1407_1016 = (int)(aux_2474);
}
}
arg1170_548 = res1407_1016;
}
{
long aux_2477;
aux_2477 = (long)(arg1170_548);
test1167_545 = (aux_2477==((long)0));
}
}
if(test1167_545){
return BCNST(256);
}
 else {
obj_t arg1168_546;
arg1168_546 = the_string_1440_246___r4_input_6_10_2(input_port_219_513);
{
unsigned char res1408_1027;
{
bool_t test_2482;
{
long aux_2483;
aux_2483 = STRING_LENGTH(arg1168_546);
test_2482 = BOUND_CHECK(((long)0), aux_2483);
}
if(test_2482){
res1408_1027 = STRING_REF(arg1168_546, ((long)0));
}
 else {
obj_t aux_2487;
{
obj_t aux1899_1573;
aux1899_1573 = debug_error_location_199___error(string2079___r4_input_6_10_2, string2080___r4_input_6_10_2, BINT(((long)0)), string2081___r4_input_6_10_2, BINT(((long)7610)));
if(CHARP(aux1899_1573)){
aux_2487 = aux1899_1573;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2082___r4_input_6_10_2, aux1899_1573, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
res1408_1027 = (unsigned char)CCHAR(aux_2487);
}
}
return BCHAR(res1408_1027);
}
}
}
break;
case ((long)0) : 
{
obj_t arg1160_536;
arg1160_536 = the_string_1440_246___r4_input_6_10_2(input_port_219_513);
{
unsigned char res1406_1005;
{
bool_t test_2499;
{
long aux_2500;
aux_2500 = STRING_LENGTH(arg1160_536);
test_2499 = BOUND_CHECK(((long)0), aux_2500);
}
if(test_2499){
res1406_1005 = STRING_REF(arg1160_536, ((long)0));
}
 else {
obj_t aux_2504;
{
obj_t aux1913_1585;
aux1913_1585 = debug_error_location_199___error(string2079___r4_input_6_10_2, string2080___r4_input_6_10_2, BINT(((long)0)), string2081___r4_input_6_10_2, BINT(((long)7610)));
if(CHARP(aux1913_1585)){
aux_2504 = aux1913_1585;
}
 else {
bigloo_type_error_location_103___error(symbol2114___r4_input_6_10_2, string2082___r4_input_6_10_2, aux1913_1585, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
res1406_1005 = (unsigned char)CCHAR(aux_2504);
}
}
return BCHAR(res1406_1005);
}
}
break;
default: 
return debug_error_location_199___error(string2083___r4_input_6_10_2, string2084___r4_input_6_10_2, BINT(match_532), string2081___r4_input_6_10_2, BINT(((long)7610)));
}
}
}
}
}


/* the-string_1440 */obj_t the_string_1440_246___r4_input_6_10_2(obj_t input_port_219_1184)
{
{
int arg1187_567;
{
int res1409_1030;
{
obj_t input_port_219_1029;
if(INPUT_PORTP(input_port_219_1184)){
input_port_219_1029 = input_port_219_1184;
}
 else {
bigloo_type_error_location_103___error(symbol2115___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1184, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
{
long aux_2525;
aux_2525 = RGC_BUFFER_LENGTH(input_port_219_1029);
res1409_1030 = (int)(aux_2525);
}
}
arg1187_567 = res1409_1030;
}
{
obj_t input_port_219_1031;
int start_1032;
if(INPUT_PORTP(input_port_219_1184)){
input_port_219_1031 = input_port_219_1184;
}
 else {
bigloo_type_error_location_103___error(symbol2115___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1184, string2078___r4_input_6_10_2, BINT(((long)3301)));
exit( -1 );}
start_1032 = (int)(((long)0));
return rgc_buffer_substring(input_port_219_1031, start_1032, arg1187_567);
}
}
}


/* peek-char */obj_t peek_char_171___r4_input_6_10_2(obj_t ip_8)
{
{
obj_t symbol1425_1139;
symbol1425_1139 = symbol2116___r4_input_6_10_2;
{
PUSH_TRACE(symbol1425_1139);
BUNSPEC;
{
obj_t aux1424_1140;
{
obj_t grammar_596;
{
obj_t lambda1198_1172;
lambda1198_1172 = proc2117___r4_input_6_10_2;
grammar_596 = lambda1198_1172;
}
{
obj_t arg1196_597;
if(NULLP(ip_8)){
arg1196_597 = current_input_port;
}
 else {
obj_t pair_1107;
if(PAIRP(ip_8)){
pair_1107 = ip_8;
}
 else {
bigloo_type_error_location_103___error(symbol2116___r4_input_6_10_2, string2107___r4_input_6_10_2, ip_8, string2078___r4_input_6_10_2, BINT(((long)3948)));
exit( -1 );}
arg1196_597 = CAR(pair_1107);
}
{
obj_t port_1109;
if(INPUT_PORTP(arg1196_597)){
port_1109 = arg1196_597;
}
 else {
bigloo_type_error_location_103___error(symbol2116___r4_input_6_10_2, string2077___r4_input_6_10_2, arg1196_597, string2078___r4_input_6_10_2, BINT(((long)3894)));
exit( -1 );}
{
bool_t test1951_1622;
test1951_1622 = PROCEDURE_CORRECT_ARITYP(grammar_596, ((long)1));
if(test1951_1622){
aux1424_1140 = PROCEDURE_ENTRY(grammar_596)(grammar_596, port_1109, BEOA);
}
 else {
error_location_112___error(string2118___r4_input_6_10_2, list2094___r4_input_6_10_2, grammar_596, string2078___r4_input_6_10_2, BINT(((long)2644)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
}
}
}
POP_TRACE();
return aux1424_1140;
}
}
}
}


/* _peek-char */obj_t _peek_char_199___r4_input_6_10_2(obj_t env_1173, obj_t ip_1174)
{
return peek_char_171___r4_input_6_10_2(ip_1174);
}


/* lambda1198 */obj_t lambda1198___r4_input_6_10_2(obj_t env_1175, obj_t input_port_219_1176)
{
{
obj_t input_port_219_600;
input_port_219_600 = input_port_219_1176;
{
long last_match_133_659;
{
obj_t input_port_219_1051;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1051 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
RGC_START_MATCH(input_port_219_1051);
}
{
int match_619;
{
long aux_2564;
last_match_133_659 = ((long)1);
state_0_1007_44_672:
{
int current_char_37_661;
{
obj_t input_port_219_1093;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1093 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
current_char_37_661 = RGC_BUFFER_GET_CHAR(input_port_219_1093);
}
{
bool_t test_2571;
{
long aux_2572;
aux_2572 = (long)(current_char_37_661);
test_2571 = (aux_2572==((long)0));
}
if(test_2571){
{
bool_t test1238_663;
{
obj_t input_port_219_1096;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1096 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
test1238_663 = RGC_BUFFER_EMPTY(input_port_219_1096);
}
if(test1238_663){
bool_t test1239_664;
{
obj_t input_port_219_1097;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1097 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
test1239_664 = rgc_fill_buffer(input_port_219_1097);
}
if(test1239_664){
goto state_0_1007_44_672;
}
 else {
aux_2564 = last_match_133_659;
}
}
 else {
long new_match_93_1099;
{
obj_t input_port_219_1100;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1100 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_1100);
}
new_match_93_1099 = ((long)0);
aux_2564 = new_match_93_1099;
}
}
}
 else {
{
long new_match_93_1102;
{
obj_t input_port_219_1103;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1103 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
RGC_STOP_MATCH(input_port_219_1103);
}
new_match_93_1102 = ((long)0);
aux_2564 = new_match_93_1102;
}
}
}
}
match_619 = (int)(aux_2564);
}
switch ((long)(match_619)){
case ((long)1) : 
{
bool_t test1210_635;
{
int arg1214_638;
{
int res1412_1075;
{
obj_t input_port_219_1074;
if(INPUT_PORTP(input_port_219_600)){
input_port_219_1074 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
{
long aux_2607;
aux_2607 = RGC_BUFFER_LENGTH(input_port_219_1074);
res1412_1075 = (int)(aux_2607);
}
}
arg1214_638 = res1412_1075;
}
{
long aux_2610;
aux_2610 = (long)(arg1214_638);
test1210_635 = (aux_2610==((long)0));
}
}
if(test1210_635){
return BCNST(256);
}
 else {
obj_t arg1211_636;
arg1211_636 = the_string_180___r4_input_6_10_2(input_port_219_600);
{
unsigned char res1413_1086;
{
bool_t test_2615;
{
long aux_2616;
aux_2616 = STRING_LENGTH(arg1211_636);
test_2615 = BOUND_CHECK(((long)0), aux_2616);
}
if(test_2615){
res1413_1086 = STRING_REF(arg1211_636, ((long)0));
}
 else {
obj_t aux_2620;
{
obj_t aux1992_1659;
aux1992_1659 = debug_error_location_199___error(string2079___r4_input_6_10_2, string2080___r4_input_6_10_2, BINT(((long)0)), string2081___r4_input_6_10_2, BINT(((long)7610)));
if(CHARP(aux1992_1659)){
aux_2620 = aux1992_1659;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2082___r4_input_6_10_2, aux1992_1659, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
res1413_1086 = (unsigned char)CCHAR(aux_2620);
}
}
return BCHAR(res1413_1086);
}
}
}
break;
case ((long)0) : 
{
unsigned char c_623;
{
obj_t arg1203_626;
arg1203_626 = the_string_180___r4_input_6_10_2(input_port_219_600);
{
unsigned char res1410_1060;
{
bool_t test_2632;
{
long aux_2633;
aux_2633 = STRING_LENGTH(arg1203_626);
test_2632 = BOUND_CHECK(((long)0), aux_2633);
}
if(test_2632){
res1410_1060 = STRING_REF(arg1203_626, ((long)0));
}
 else {
obj_t aux_2637;
{
obj_t aux2009_1671;
aux2009_1671 = debug_error_location_199___error(string2079___r4_input_6_10_2, string2080___r4_input_6_10_2, BINT(((long)0)), string2081___r4_input_6_10_2, BINT(((long)7610)));
if(CHARP(aux2009_1671)){
aux_2637 = aux2009_1671;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2082___r4_input_6_10_2, aux2009_1671, string2081___r4_input_6_10_2, BINT(((long)7610)));
exit( -1 );}
}
res1410_1060 = (unsigned char)CCHAR(aux_2637);
}
}
c_623 = res1410_1060;
}
}
{
obj_t arg1201_624;
long arg1202_625;
{
obj_t res1411_1061;
if(INPUT_PORTP(input_port_219_600)){
res1411_1061 = input_port_219_600;
}
 else {
bigloo_type_error_location_103___error(symbol2119___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_600, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
arg1201_624 = res1411_1061;
}
arg1202_625 = (c_623);
{
int aux_2653;
aux_2653 = (int)(arg1202_625);
rgc_buffer_unget_char(arg1201_624, aux_2653);
}
}
return BCHAR(c_623);
}
break;
default: 
return debug_error_location_199___error(string2083___r4_input_6_10_2, string2084___r4_input_6_10_2, BINT(match_619), string2081___r4_input_6_10_2, BINT(((long)7610)));
}
}
}
}
}


/* the-string */obj_t the_string_180___r4_input_6_10_2(obj_t input_port_219_1183)
{
{
int arg1234_657;
{
int res1414_1089;
{
obj_t input_port_219_1088;
if(INPUT_PORTP(input_port_219_1183)){
input_port_219_1088 = input_port_219_1183;
}
 else {
bigloo_type_error_location_103___error(symbol2120___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1183, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
{
long aux_2667;
aux_2667 = RGC_BUFFER_LENGTH(input_port_219_1088);
res1414_1089 = (int)(aux_2667);
}
}
arg1234_657 = res1414_1089;
}
{
obj_t input_port_219_1090;
int start_1091;
if(INPUT_PORTP(input_port_219_1183)){
input_port_219_1090 = input_port_219_1183;
}
 else {
bigloo_type_error_location_103___error(symbol2120___r4_input_6_10_2, string2077___r4_input_6_10_2, input_port_219_1183, string2078___r4_input_6_10_2, BINT(((long)3726)));
exit( -1 );}
start_1091 = (int)(((long)0));
return rgc_buffer_substring(input_port_219_1090, start_1091, arg1234_657);
}
}
}


/* eof-object? */bool_t eof_object__7___r4_input_6_10_2(obj_t object_9)
{
{
obj_t symbol1427_1759;
symbol1427_1759 = symbol2121___r4_input_6_10_2;
{
PUSH_TRACE(symbol1427_1759);
BUNSPEC;
{
bool_t aux1426_1760;
aux1426_1760 = EOF_OBJECTP(object_9);
POP_TRACE();
return aux1426_1760;
}
}
}
}


/* _eof-object? */obj_t _eof_object__147___r4_input_6_10_2(obj_t env_1165, obj_t object_1166)
{
{
bool_t aux_2680;
{
obj_t object_1761;
object_1761 = object_1166;
{
obj_t symbol1427_1762;
symbol1427_1762 = symbol2121___r4_input_6_10_2;
{
PUSH_TRACE(symbol1427_1762);
BUNSPEC;
{
bool_t aux1426_1763;
aux1426_1763 = EOF_OBJECTP(object_1761);
POP_TRACE();
aux_2680 = aux1426_1763;
}
}
}
}
return BBOOL(aux_2680);
}
}


/* char-ready? */bool_t char_ready__201___r4_input_6_10_2(obj_t port_10)
{
{
obj_t symbol1429_1143;
symbol1429_1143 = symbol2122___r4_input_6_10_2;
{
PUSH_TRACE(symbol1429_1143);
BUNSPEC;
POP_TRACE();
return ((bool_t)1);
}
}
}


/* _char-ready? */obj_t _char_ready__35___r4_input_6_10_2(obj_t env_1177, obj_t port_1178)
{
{
bool_t aux_2687;
aux_2687 = char_ready__201___r4_input_6_10_2(port_1178);
return BBOOL(aux_2687);
}
}


/* read-line */obj_t read_line_110___r4_input_6_10_2(obj_t input_port_219_11)
{
{
obj_t symbol1431_1145;
symbol1431_1145 = symbol2123___r4_input_6_10_2;
{
PUSH_TRACE(symbol1431_1145);
BUNSPEC;
{
obj_t aux1430_1146;
{
obj_t port_1110;
{
bool_t test1242_1111;
test1242_1111 = PAIRP(input_port_219_11);
if(test1242_1111){
obj_t pair_1113;
if(test1242_1111){
pair_1113 = input_port_219_11;
}
 else {
bigloo_type_error_location_103___error(symbol2123___r4_input_6_10_2, string2107___r4_input_6_10_2, input_port_219_11, string2078___r4_input_6_10_2, BINT(((long)5256)));
exit( -1 );}
port_1110 = CAR(pair_1113);
}
 else {
port_1110 = current_input_port;
}
}
{
obj_t port_1115;
if(INPUT_PORTP(port_1110)){
port_1115 = port_1110;
}
 else {
bigloo_type_error_location_103___error(symbol2123___r4_input_6_10_2, string2077___r4_input_6_10_2, port_1110, string2078___r4_input_6_10_2, BINT(((long)5307)));
exit( -1 );}
{
bool_t test2053_1714;
test2053_1714 = PROCEDURE_CORRECT_ARITYP(_read_line_grammar__25___r4_input_6_10_2, ((long)1));
if(test2053_1714){
aux1430_1146 = PROCEDURE_ENTRY(_read_line_grammar__25___r4_input_6_10_2)(_read_line_grammar__25___r4_input_6_10_2, port_1115, BEOA);
}
 else {
error_location_112___error(string2124___r4_input_6_10_2, list2094___r4_input_6_10_2, _read_line_grammar__25___r4_input_6_10_2, string2078___r4_input_6_10_2, BINT(((long)2644)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
}
}
POP_TRACE();
return aux1430_1146;
}
}
}
}


/* _read-line */obj_t _read_line_106___r4_input_6_10_2(obj_t env_1179, obj_t input_port_219_1180)
{
return read_line_110___r4_input_6_10_2(input_port_219_1180);
}


/* read-of-strings */obj_t read_of_strings_88___r4_input_6_10_2(obj_t input_port_219_12)
{
{
obj_t symbol1433_1147;
symbol1433_1147 = symbol2125___r4_input_6_10_2;
{
PUSH_TRACE(symbol1433_1147);
BUNSPEC;
{
obj_t aux1432_1148;
{
obj_t port_1116;
{
bool_t test1243_1117;
test1243_1117 = PAIRP(input_port_219_12);
if(test1243_1117){
obj_t pair_1119;
if(test1243_1117){
pair_1119 = input_port_219_12;
}
 else {
bigloo_type_error_location_103___error(symbol2125___r4_input_6_10_2, string2107___r4_input_6_10_2, input_port_219_12, string2078___r4_input_6_10_2, BINT(((long)6051)));
exit( -1 );}
port_1116 = CAR(pair_1119);
}
 else {
port_1116 = current_input_port;
}
}
{
obj_t port_1121;
if(INPUT_PORTP(port_1116)){
port_1121 = port_1116;
}
 else {
bigloo_type_error_location_103___error(symbol2125___r4_input_6_10_2, string2077___r4_input_6_10_2, port_1116, string2078___r4_input_6_10_2, BINT(((long)6102)));
exit( -1 );}
{
bool_t test2072_1734;
test2072_1734 = PROCEDURE_CORRECT_ARITYP(_read_of_strings_grammar__196___r4_input_6_10_2, ((long)1));
if(test2072_1734){
aux1432_1148 = PROCEDURE_ENTRY(_read_of_strings_grammar__196___r4_input_6_10_2)(_read_of_strings_grammar__196___r4_input_6_10_2, port_1121, BEOA);
}
 else {
error_location_112___error(string2126___r4_input_6_10_2, list2094___r4_input_6_10_2, _read_of_strings_grammar__196___r4_input_6_10_2, string2078___r4_input_6_10_2, BINT(((long)2644)));
FAILURE(symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2,symbol2098___r4_input_6_10_2);}
}
}
}
POP_TRACE();
return aux1432_1148;
}
}
}
}


/* _read-of-strings */obj_t _read_of_strings_6___r4_input_6_10_2(obj_t env_1181, obj_t input_port_219_1182)
{
return read_of_strings_88___r4_input_6_10_2(input_port_219_1182);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_input_6_10_2()
{
{
obj_t symbol1435_1149;
symbol1435_1149 = symbol2127___r4_input_6_10_2;
{
PUSH_TRACE(symbol1435_1149);
BUNSPEC;
{
obj_t aux1434_1150;
module_initialization_70___error(((long)0), "__R4_INPUT_6_10_2");
aux1434_1150 = module_initialization_70___r4_ports_6_10_1(((long)0), "__R4_INPUT_6_10_2");
POP_TRACE();
return aux1434_1150;
}
}
}
}

