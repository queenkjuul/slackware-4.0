/*===========================================================================*/
/*   (Module/alibrary.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t ccomp_module_module;
static obj_t method_init_76_module_alibrary();
extern obj_t string_append(obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t _additional_bigloo_libraries__50_engine_param;
extern obj_t module_initialization_70_module_alibrary(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_init_setrc(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern long class_num_218___object(obj_t);
extern obj_t make_alibrary_compiler_139_module_alibrary();
static obj_t _alibrary_producer_189_module_alibrary(obj_t, obj_t);
static obj_t imported_modules_init_94_module_alibrary();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
static obj_t alibrary_producer_39_module_alibrary(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_alibrary();
static obj_t toplevel_init_63_module_alibrary();
extern obj_t open_input_string(obj_t);
extern obj_t setup_library_values_14_init_setrc(obj_t);
static obj_t arg1157_module_alibrary(obj_t, obj_t, obj_t);
static obj_t arg1150_module_alibrary(obj_t);
static obj_t arg1145_module_alibrary(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _make_alibrary_compiler_52_module_alibrary(obj_t);
static obj_t _make_library_name_5_module_alibrary(obj_t, obj_t);
static obj_t require_initialization_114_module_alibrary = BUNSPEC;
extern obj_t _additional_heap_names__104_engine_param;
extern obj_t make_library_name_119_module_alibrary(obj_t);
static obj_t cnst_init_137_module_alibrary();
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(alibrary_producer_env_230_module_alibrary, _alibrary_producer_189_module_alibrary1237, _alibrary_producer_189_module_alibrary, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1226_module_alibrary, arg1145_module_alibrary1238, arg1145_module_alibrary, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1225_module_alibrary, arg1150_module_alibrary1239, arg1150_module_alibrary, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1224_module_alibrary, arg1157_module_alibrary1240, arg1157_module_alibrary, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_library_name_env_51_module_alibrary, _make_library_name_5_module_alibrary1241, _make_library_name_5_module_alibrary, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_alibrary_compiler_env_116_module_alibrary, _make_alibrary_compiler_52_module_alibrary1242, _make_alibrary_compiler_52_module_alibrary, 0L, 0);
DEFINE_STRING(string1231_module_alibrary, string1231_module_alibrary1243, "VOID LIBRARY ", 13);
DEFINE_STRING(string1229_module_alibrary, string1229_module_alibrary1244, "Illegal `library' clause", 24);
DEFINE_STRING(string1230_module_alibrary, string1230_module_alibrary1245, "Illegal library", 15);
DEFINE_STRING(string1228_module_alibrary, string1228_module_alibrary1246, "Parse error", 11);
DEFINE_STRING(string1227_module_alibrary, string1227_module_alibrary1247, ".heap", 5);


/* module-initialization */ obj_t 
module_initialization_70_module_alibrary(long checksum_218, char *from_219)
{
   if (CBOOL(require_initialization_114_module_alibrary))
     {
	require_initialization_114_module_alibrary = BBOOL(((bool_t) 0));
	library_modules_init_112_module_alibrary();
	cnst_init_137_module_alibrary();
	imported_modules_init_94_module_alibrary();
	method_init_76_module_alibrary();
	toplevel_init_63_module_alibrary();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_alibrary()
{
   module_initialization_70___object(((long) 0), "MODULE_ALIBRARY");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_ALIBRARY");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_ALIBRARY");
   module_initialization_70___reader(((long) 0), "MODULE_ALIBRARY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_alibrary()
{
   {
      obj_t cnst_port_138_210;
      cnst_port_138_210 = open_input_string(string1231_module_alibrary);
      {
	 long i_211;
	 i_211 = ((long) 1);
       loop_212:
	 {
	    bool_t test1232_213;
	    test1232_213 = (i_211 == ((long) -1));
	    if (test1232_213)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1233_214;
		    {
		       obj_t list1234_215;
		       {
			  obj_t arg1235_216;
			  arg1235_216 = BNIL;
			  list1234_215 = MAKE_PAIR(cnst_port_138_210, arg1235_216);
		       }
		       arg1233_214 = read___reader(list1234_215);
		    }
		    CNST_TABLE_SET(i_211, arg1233_214);
		 }
		 {
		    int aux_217;
		    {
		       long aux_238;
		       aux_238 = (i_211 - ((long) 1));
		       aux_217 = (int) (aux_238);
		    }
		    {
		       long i_241;
		       i_241 = (long) (aux_217);
		       i_211 = i_241;
		       goto loop_212;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_alibrary()
{
   return BUNSPEC;
}


/* make-alibrary-compiler */ obj_t 
make_alibrary_compiler_139_module_alibrary()
{
   {
      obj_t arg1142_49;
      arg1142_49 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1157_194;
	 obj_t arg1150_195;
	 obj_t arg1145_196;
	 arg1157_194 = proc1224_module_alibrary;
	 arg1150_195 = proc1225_module_alibrary;
	 arg1145_196 = proc1226_module_alibrary;
	 {
	    ccomp_t res1223_153;
	    {
	       ccomp_t new1002_144;
	       new1002_144 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1221_145;
		  arg1221_145 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_151;
		     obj_151 = (obj_t) (new1002_144);
		     (((obj_t) CREF(obj_151))->header = MAKE_HEADER(arg1221_145, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_248;
		  aux_248 = (object_t) (new1002_144);
		  OBJECT_WIDENING_SET(aux_248, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_144))->id) = ((obj_t) arg1142_49), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_144))->producer) = ((obj_t) alibrary_producer_env_230_module_alibrary), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_144))->consumer) = ((obj_t) arg1145_196), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_144))->finalizer) = ((obj_t) arg1150_195), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_144))->checksummer) = ((obj_t) arg1157_194), BUNSPEC);
	       res1223_153 = new1002_144;
	    }
	    return (obj_t) (res1223_153);
	 }
      }
   }
}


/* _make-alibrary-compiler */ obj_t 
_make_alibrary_compiler_52_module_alibrary(obj_t env_197)
{
   return make_alibrary_compiler_139_module_alibrary();
}


/* arg1157 */ obj_t 
arg1157_module_alibrary(obj_t env_198, obj_t m_199, obj_t c_200)
{
   {
      obj_t m_58;
      obj_t c_59;
      m_58 = m_199;
      c_59 = c_200;
      return c_59;
   }
}


/* arg1150 */ obj_t 
arg1150_module_alibrary(obj_t env_201)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1145 */ obj_t 
arg1145_module_alibrary(obj_t env_202, obj_t m_203, obj_t c_204)
{
   {
      obj_t m_54;
      obj_t c_55;
      m_54 = m_203;
      c_55 = c_204;
      return BNIL;
   }
}


/* alibrary-producer */ obj_t 
alibrary_producer_39_module_alibrary(obj_t clause_19)
{
   {
      obj_t protos_64;
      if (PAIRP(clause_19))
	{
	   protos_64 = CDR(clause_19);
	   {
	      obj_t lib_names_177_70;
	      if (NULLP(protos_64))
		{
		   lib_names_177_70 = BNIL;
		}
	      else
		{
		   obj_t head1013_93;
		   {
		      obj_t arg1201_104;
		      arg1201_104 = make_library_name_119_module_alibrary(CAR(protos_64));
		      head1013_93 = MAKE_PAIR(arg1201_104, BNIL);
		   }
		   {
		      obj_t l1011_94;
		      obj_t tail1014_95;
		      l1011_94 = CDR(protos_64);
		      tail1014_95 = head1013_93;
		    lname1012_96:
		      if (NULLP(l1011_94))
			{
			   lib_names_177_70 = head1013_93;
			}
		      else
			{
			   obj_t newtail1015_99;
			   {
			      obj_t arg1197_101;
			      arg1197_101 = make_library_name_119_module_alibrary(CAR(l1011_94));
			      newtail1015_99 = MAKE_PAIR(arg1197_101, BNIL);
			   }
			   SET_CDR(tail1014_95, newtail1015_99);
			   {
			      obj_t tail1014_274;
			      obj_t l1011_272;
			      l1011_272 = CDR(l1011_94);
			      tail1014_274 = newtail1015_99;
			      tail1014_95 = tail1014_274;
			      l1011_94 = l1011_272;
			      goto lname1012_96;
			   }
			}
		   }
		}
	      {
		 obj_t heap_names_24_71;
		 if (NULLP(lib_names_177_70))
		   {
		      heap_names_24_71 = BNIL;
		   }
		 else
		   {
		      obj_t head1018_79;
		      head1018_79 = MAKE_PAIR(BNIL, BNIL);
		      {
			 obj_t l1016_80;
			 obj_t tail1019_81;
			 l1016_80 = lib_names_177_70;
			 tail1019_81 = head1018_79;
		       lname1017_82:
			 if (NULLP(l1016_80))
			   {
			      heap_names_24_71 = CDR(head1018_79);
			   }
			 else
			   {
			      obj_t newtail1020_84;
			      {
				 obj_t arg1188_86;
				 {
				    obj_t aux_282;
				    aux_282 = CAR(l1016_80);
				    arg1188_86 = string_append(aux_282, string1227_module_alibrary);
				 }
				 newtail1020_84 = MAKE_PAIR(arg1188_86, BNIL);
			      }
			      SET_CDR(tail1019_81, newtail1020_84);
			      {
				 obj_t tail1019_289;
				 obj_t l1016_287;
				 l1016_287 = CDR(l1016_80);
				 tail1019_289 = newtail1020_84;
				 tail1019_81 = tail1019_289;
				 l1016_80 = l1016_287;
				 goto lname1017_82;
			      }
			   }
		      }
		   }
		 {
		    {
		       obj_t l1021_72;
		       l1021_72 = lib_names_177_70;
		     lname1022_73:
		       if (PAIRP(l1021_72))
			 {
			    setup_library_values_14_init_setrc(CAR(l1021_72));
			    {
			       obj_t l1021_294;
			       l1021_294 = CDR(l1021_72);
			       l1021_72 = l1021_294;
			       goto lname1022_73;
			    }
			 }
		       else
			 {
			    ((bool_t) 1);
			 }
		    }
		    _additional_heap_names__104_engine_param = append_2_18___r4_pairs_and_lists_6_3(heap_names_24_71, _additional_heap_names__104_engine_param);
		    _additional_bigloo_libraries__50_engine_param = append_2_18___r4_pairs_and_lists_6_3(lib_names_177_70, _additional_bigloo_libraries__50_engine_param);
		 }
	      }
	   }
	   return BNIL;
	}
      else
	{
	   {
	      obj_t list1207_110;
	      list1207_110 = MAKE_PAIR(BNIL, BNIL);
	      return user_error_151_tools_error(string1228_module_alibrary, string1229_module_alibrary, clause_19, list1207_110);
	   }
	}
   }
}


/* _alibrary-producer */ obj_t 
_alibrary_producer_189_module_alibrary(obj_t env_205, obj_t clause_206)
{
   return alibrary_producer_39_module_alibrary(clause_206);
}


/* make-library-name */ obj_t 
make_library_name_119_module_alibrary(obj_t libname_20)
{
   if (SYMBOLP(libname_20))
     {
	{
	   obj_t arg1211_113;
	   arg1211_113 = SYMBOL_TO_STRING(libname_20);
	   return string_downcase_77___r4_strings_6_7(arg1211_113);
	}
     }
   else
     {
	if (STRINGP(libname_20))
	  {
	     return string_downcase_77___r4_strings_6_7(libname_20);
	  }
	else
	  {
	     {
		obj_t list1217_118;
		list1217_118 = MAKE_PAIR(BNIL, BNIL);
		return user_error_151_tools_error(string1228_module_alibrary, string1230_module_alibrary, libname_20, list1217_118);
	     }
	  }
     }
}


/* _make-library-name */ obj_t 
_make_library_name_5_module_alibrary(obj_t env_207, obj_t libname_208)
{
   return make_library_name_119_module_alibrary(libname_208);
}


/* method-init */ obj_t 
method_init_76_module_alibrary()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_alibrary()
{
   module_initialization_70_module_module(((long) 0), "MODULE_ALIBRARY");
   module_initialization_70_tools_error(((long) 0), "MODULE_ALIBRARY");
   module_initialization_70_engine_param(((long) 0), "MODULE_ALIBRARY");
   return module_initialization_70_init_setrc(((long) 0), "MODULE_ALIBRARY");
}
