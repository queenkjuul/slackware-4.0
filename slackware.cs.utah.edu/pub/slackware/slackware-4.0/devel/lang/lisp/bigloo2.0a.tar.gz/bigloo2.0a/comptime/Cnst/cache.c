/*===========================================================================*/
/*   (Cnst/cache.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_cnst_cache();
obj_t _vector_tag_set___225_cnst_cache = BUNSPEC;
obj_t _bfalse__69_cnst_cache = BUNSPEC;
obj_t _string__bstring__114_cnst_cache = BUNSPEC;
obj_t _make_fx_procedure__51_cnst_cache = BUNSPEC;
obj_t _btrue__29_cnst_cache = BUNSPEC;
extern obj_t module_initialization_70_cnst_cache(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
obj_t _double__real__21_cnst_cache = BUNSPEC;
obj_t _cons__148_cnst_cache = BUNSPEC;
static obj_t imported_modules_init_94_cnst_cache();
static obj_t _stop_cnst_cache__214_cnst_cache(obj_t);
static obj_t library_modules_init_112_cnst_cache();
obj_t _string__symbol__115_cnst_cache = BUNSPEC;
obj_t _list__vector__161_cnst_cache = BUNSPEC;
static obj_t toplevel_init_63_cnst_cache();
extern obj_t stop_cnst_cache__90_cnst_cache();
static obj_t _start_cnst_cache__252_cnst_cache(obj_t);
extern obj_t open_input_string(obj_t);
obj_t _cnst_table_ref__15_cnst_cache = BUNSPEC;
extern obj_t start_cnst_cache__172_cnst_cache();
obj_t _string__keyword__251_cnst_cache = BUNSPEC;
obj_t _bool__bbool__85_cnst_cache = BUNSPEC;
obj_t _cnst_table_set___16_cnst_cache = BUNSPEC;
obj_t _make_va_procedure__53_cnst_cache = BUNSPEC;
extern obj_t read___reader(obj_t);
static bool_t _cache_started___32_cnst_cache;
static obj_t require_initialization_114_cnst_cache = BUNSPEC;
static obj_t cnst_init_137_cnst_cache();
static obj_t __cnst[15];

DEFINE_EXPORT_PROCEDURE(start_cnst_cache__env_224_cnst_cache, _start_cnst_cache__252_cnst_cache1288, _start_cnst_cache__252_cnst_cache, 0L, 0);
DEFINE_EXPORT_PROCEDURE(stop_cnst_cache__env_237_cnst_cache, _stop_cnst_cache__214_cnst_cache1289, _stop_cnst_cache__214_cnst_cache, 0L, 0);
DEFINE_STRING(string1282_cnst_cache, string1282_cnst_cache1290, "VECTOR-TAG-SET! LIST->VECTOR DOUBLE->REAL MAKE-VA-PROCEDURE MAKE-FX-PROCEDURE BOOL->BBOOL C-STRING->KEYWORD C-STRING->SYMBOL STRING->BSTRING BFALSE BTRUE C-CONS CNST-TABLE-SET! FOREIGN CNST-TABLE-REF ", 200);


/* module-initialization */ obj_t 
module_initialization_70_cnst_cache(long checksum_490, char *from_491)
{
   if (CBOOL(require_initialization_114_cnst_cache))
     {
	require_initialization_114_cnst_cache = BBOOL(((bool_t) 0));
	library_modules_init_112_cnst_cache();
	cnst_init_137_cnst_cache();
	imported_modules_init_94_cnst_cache();
	method_init_76_cnst_cache();
	toplevel_init_63_cnst_cache();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cnst_cache()
{
   module_initialization_70___reader(((long) 0), "CNST_CACHE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cnst_cache()
{
   {
      obj_t cnst_port_138_482;
      cnst_port_138_482 = open_input_string(string1282_cnst_cache);
      {
	 long i_483;
	 i_483 = ((long) 14);
       loop_484:
	 {
	    bool_t test1283_485;
	    test1283_485 = (i_483 == ((long) -1));
	    if (test1283_485)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1284_486;
		    {
		       obj_t list1285_487;
		       {
			  obj_t arg1286_488;
			  arg1286_488 = BNIL;
			  list1285_487 = MAKE_PAIR(cnst_port_138_482, arg1286_488);
		       }
		       arg1284_486 = read___reader(list1285_487);
		    }
		    CNST_TABLE_SET(i_483, arg1284_486);
		 }
		 {
		    int aux_489;
		    {
		       long aux_507;
		       aux_507 = (i_483 - ((long) 1));
		       aux_489 = (int) (aux_507);
		    }
		    {
		       long i_510;
		       i_510 = (long) (aux_489);
		       i_483 = i_510;
		       goto loop_484;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cnst_cache()
{
   _cache_started___32_cnst_cache = ((bool_t) 0);
   _cnst_table_ref__15_cnst_cache = BFALSE;
   _cnst_table_set___16_cnst_cache = BFALSE;
   _cons__148_cnst_cache = BFALSE;
   _btrue__29_cnst_cache = BFALSE;
   _bfalse__69_cnst_cache = BFALSE;
   _string__bstring__114_cnst_cache = BFALSE;
   _string__symbol__115_cnst_cache = BFALSE;
   _string__keyword__251_cnst_cache = BFALSE;
   _bool__bbool__85_cnst_cache = BFALSE;
   _make_fx_procedure__51_cnst_cache = BFALSE;
   _make_va_procedure__53_cnst_cache = BFALSE;
   _double__real__21_cnst_cache = BFALSE;
   _list__vector__161_cnst_cache = BFALSE;
   return (_vector_tag_set___225_cnst_cache = BFALSE,
      BUNSPEC);
}


/* start-cnst-cache! */ obj_t 
start_cnst_cache__172_cnst_cache()
{
   if (_cache_started___32_cnst_cache)
     {
	return BTRUE;
     }
   else
     {
	_cache_started___32_cnst_cache = ((bool_t) 1);
	{
	   obj_t arg1187_301;
	   arg1187_301 = CNST_TABLE_REF(((long) 0));
	   {
	      obj_t list1189_303;
	      {
		 obj_t aux_514;
		 aux_514 = CNST_TABLE_REF(((long) 1));
		 list1189_303 = MAKE_PAIR(aux_514, BNIL);
	      }
	      _cnst_table_ref__15_cnst_cache = find_global_223_ast_env(arg1187_301, list1189_303);
	   }
	}
	{
	   obj_t arg1191_305;
	   arg1191_305 = CNST_TABLE_REF(((long) 2));
	   {
	      obj_t list1193_307;
	      {
		 obj_t aux_519;
		 aux_519 = CNST_TABLE_REF(((long) 1));
		 list1193_307 = MAKE_PAIR(aux_519, BNIL);
	      }
	      _cnst_table_set___16_cnst_cache = find_global_223_ast_env(arg1191_305, list1193_307);
	   }
	}
	{
	   obj_t arg1195_309;
	   arg1195_309 = CNST_TABLE_REF(((long) 3));
	   {
	      obj_t list1197_311;
	      {
		 obj_t aux_524;
		 aux_524 = CNST_TABLE_REF(((long) 1));
		 list1197_311 = MAKE_PAIR(aux_524, BNIL);
	      }
	      _cons__148_cnst_cache = find_global_223_ast_env(arg1195_309, list1197_311);
	   }
	}
	{
	   obj_t arg1200_313;
	   arg1200_313 = CNST_TABLE_REF(((long) 4));
	   {
	      obj_t list1202_315;
	      {
		 obj_t aux_529;
		 aux_529 = CNST_TABLE_REF(((long) 1));
		 list1202_315 = MAKE_PAIR(aux_529, BNIL);
	      }
	      _btrue__29_cnst_cache = find_global_223_ast_env(arg1200_313, list1202_315);
	   }
	}
	{
	   obj_t arg1204_317;
	   arg1204_317 = CNST_TABLE_REF(((long) 5));
	   {
	      obj_t list1206_319;
	      {
		 obj_t aux_534;
		 aux_534 = CNST_TABLE_REF(((long) 1));
		 list1206_319 = MAKE_PAIR(aux_534, BNIL);
	      }
	      _bfalse__69_cnst_cache = find_global_223_ast_env(arg1204_317, list1206_319);
	   }
	}
	{
	   obj_t arg1209_321;
	   arg1209_321 = CNST_TABLE_REF(((long) 6));
	   {
	      obj_t list1211_323;
	      {
		 obj_t aux_539;
		 aux_539 = CNST_TABLE_REF(((long) 1));
		 list1211_323 = MAKE_PAIR(aux_539, BNIL);
	      }
	      _string__bstring__114_cnst_cache = find_global_223_ast_env(arg1209_321, list1211_323);
	   }
	}
	{
	   obj_t arg1214_325;
	   arg1214_325 = CNST_TABLE_REF(((long) 7));
	   {
	      obj_t list1217_327;
	      {
		 obj_t aux_544;
		 aux_544 = CNST_TABLE_REF(((long) 1));
		 list1217_327 = MAKE_PAIR(aux_544, BNIL);
	      }
	      _string__symbol__115_cnst_cache = find_global_223_ast_env(arg1214_325, list1217_327);
	   }
	}
	{
	   obj_t arg1220_329;
	   arg1220_329 = CNST_TABLE_REF(((long) 8));
	   {
	      obj_t list1222_331;
	      {
		 obj_t aux_549;
		 aux_549 = CNST_TABLE_REF(((long) 1));
		 list1222_331 = MAKE_PAIR(aux_549, BNIL);
	      }
	      _string__keyword__251_cnst_cache = find_global_223_ast_env(arg1220_329, list1222_331);
	   }
	}
	{
	   obj_t arg1225_333;
	   arg1225_333 = CNST_TABLE_REF(((long) 9));
	   {
	      obj_t list1227_335;
	      {
		 obj_t aux_554;
		 aux_554 = CNST_TABLE_REF(((long) 1));
		 list1227_335 = MAKE_PAIR(aux_554, BNIL);
	      }
	      _bool__bbool__85_cnst_cache = find_global_223_ast_env(arg1225_333, list1227_335);
	   }
	}
	{
	   obj_t arg1231_337;
	   arg1231_337 = CNST_TABLE_REF(((long) 10));
	   {
	      obj_t list1233_339;
	      {
		 obj_t aux_559;
		 aux_559 = CNST_TABLE_REF(((long) 1));
		 list1233_339 = MAKE_PAIR(aux_559, BNIL);
	      }
	      _make_fx_procedure__51_cnst_cache = find_global_223_ast_env(arg1231_337, list1233_339);
	   }
	}
	{
	   obj_t arg1235_341;
	   arg1235_341 = CNST_TABLE_REF(((long) 11));
	   {
	      obj_t list1237_343;
	      {
		 obj_t aux_564;
		 aux_564 = CNST_TABLE_REF(((long) 1));
		 list1237_343 = MAKE_PAIR(aux_564, BNIL);
	      }
	      _make_va_procedure__53_cnst_cache = find_global_223_ast_env(arg1235_341, list1237_343);
	   }
	}
	{
	   obj_t arg1240_345;
	   arg1240_345 = CNST_TABLE_REF(((long) 12));
	   {
	      obj_t list1242_347;
	      {
		 obj_t aux_569;
		 aux_569 = CNST_TABLE_REF(((long) 1));
		 list1242_347 = MAKE_PAIR(aux_569, BNIL);
	      }
	      _double__real__21_cnst_cache = find_global_223_ast_env(arg1240_345, list1242_347);
	   }
	}
	_list__vector__161_cnst_cache = find_global_223_ast_env(CNST_TABLE_REF(((long) 13)), BNIL);
	_vector_tag_set___225_cnst_cache = find_global_223_ast_env(CNST_TABLE_REF(((long) 14)), BNIL);
	return BTRUE;
     }
}


/* _start-cnst-cache! */ obj_t 
_start_cnst_cache__252_cnst_cache(obj_t env_480)
{
   return start_cnst_cache__172_cnst_cache();
}


/* stop-cnst-cache! */ obj_t 
stop_cnst_cache__90_cnst_cache()
{
   _string__bstring__114_cnst_cache = BFALSE;
   _string__symbol__115_cnst_cache = BFALSE;
   _string__keyword__251_cnst_cache = BFALSE;
   _bool__bbool__85_cnst_cache = BFALSE;
   _make_fx_procedure__51_cnst_cache = BFALSE;
   _make_va_procedure__53_cnst_cache = BFALSE;
   _double__real__21_cnst_cache = BFALSE;
   _cons__148_cnst_cache = BFALSE;
   _btrue__29_cnst_cache = BFALSE;
   _bfalse__69_cnst_cache = BFALSE;
   return BTRUE;
}


/* _stop-cnst-cache! */ obj_t 
_stop_cnst_cache__214_cnst_cache(obj_t env_481)
{
   return stop_cnst_cache__90_cnst_cache();
}


/* method-init */ obj_t 
method_init_76_cnst_cache()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cnst_cache()
{
   module_initialization_70_type_type(((long) 0), "CNST_CACHE");
   module_initialization_70_ast_var(((long) 0), "CNST_CACHE");
   module_initialization_70_ast_env(((long) 0), "CNST_CACHE");
   return module_initialization_70_engine_param(((long) 0), "CNST_CACHE");
}
