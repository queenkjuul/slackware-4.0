/*===========================================================================*/
/*   (Expand/syntax.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t body1006_expand_syntax_case_44(obj_t);
static obj_t _syntax_expand_units_247_expand_syntax_case_44(obj_t, obj_t);
extern obj_t current_error_port;
extern obj_t exitd_top;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t handling_function1176_expand_syntax_case_44(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_expand_syntax_case_44(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___r5_macro_4_3_init(long, char *);
extern obj_t syntax_expand_units_115_expand_syntax_case_44(obj_t);
static obj_t imported_modules_init_94_expand_syntax_case_44();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t handler_expand_syntax_case_44(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1005_expand_syntax_case_44(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_expand_syntax_case_44();
static obj_t toplevel_init_63_expand_syntax_case_44();
extern obj_t expand_syntax_236___r5_macro_4_3_init(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t arg1188_expand_syntax_case_44(obj_t);
static obj_t arg1187_expand_syntax_case_44(obj_t);
extern obj_t remove_error_handler__102___error();
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t escape_expand_syntax_case_44(obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_expand_syntax_case_44 = BUNSPEC;
static obj_t cnst_init_137_expand_syntax_case_44();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[3];

DEFINE_STATIC_PROCEDURE(proc1229_expand_syntax_case_44, handler_expand_syntax_case_441242, handler_expand_syntax_case_44, 0L, 4);
DEFINE_EXPORT_PROCEDURE(syntax_expand_units_env_172_expand_syntax_case_44, _syntax_expand_units_247_expand_syntax_case_441243, _syntax_expand_units_247_expand_syntax_case_44, 0L, 1);
DEFINE_STRING(string1236_expand_syntax_case_44, string1236_expand_syntax_case_441244, "(QUOTE ()) NOTHING PASS-STARTED ", 32);
DEFINE_STRING(string1235_expand_syntax_case_44, string1235_expand_syntax_case_441245, "failure during postlude hook", 28);
DEFINE_STRING(string1234_expand_syntax_case_44, string1234_expand_syntax_case_441246, " error", 6);
DEFINE_STRING(string1233_expand_syntax_case_44, string1233_expand_syntax_case_441247, " occured, ending ...", 20);
DEFINE_STRING(string1232_expand_syntax_case_44, string1232_expand_syntax_case_441248, "failure during prelude hook", 27);
DEFINE_STRING(string1231_expand_syntax_case_44, string1231_expand_syntax_case_441249, "   . ", 5);
DEFINE_STRING(string1230_expand_syntax_case_44, string1230_expand_syntax_case_441250, "Syntax", 6);


/* module-initialization */ obj_t 
module_initialization_70_expand_syntax_case_44(long checksum_241, char *from_242)
{
   if (CBOOL(require_initialization_114_expand_syntax_case_44))
     {
	require_initialization_114_expand_syntax_case_44 = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_syntax_case_44();
	cnst_init_137_expand_syntax_case_44();
	imported_modules_init_94_expand_syntax_case_44();
	toplevel_init_63_expand_syntax_case_44();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_syntax_case_44()
{
   module_initialization_70___bexit(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___r4_output_6_10_3(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___r5_macro_4_3_init(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___r4_control_features_6_9(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___error(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___r4_numbers_6_5(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___reader(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_SYNTAX-CASE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_syntax_case_44()
{
   {
      obj_t cnst_port_138_233;
      cnst_port_138_233 = open_input_string(string1236_expand_syntax_case_44);
      {
	 long i_234;
	 i_234 = ((long) 2);
       loop_235:
	 {
	    bool_t test1237_236;
	    test1237_236 = (i_234 == ((long) -1));
	    if (test1237_236)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1238_237;
		    {
		       obj_t list1239_238;
		       {
			  obj_t arg1240_239;
			  arg1240_239 = BNIL;
			  list1239_238 = MAKE_PAIR(cnst_port_138_233, arg1240_239);
		       }
		       arg1238_237 = read___reader(list1239_238);
		    }
		    CNST_TABLE_SET(i_234, arg1238_237);
		 }
		 {
		    int aux_240;
		    {
		       long aux_264;
		       aux_264 = (i_234 - ((long) 1));
		       aux_240 = (int) (aux_264);
		    }
		    {
		       long i_267;
		       i_267 = (long) (aux_240);
		       i_234 = i_267;
		       goto loop_235;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_syntax_case_44()
{
   return BUNSPEC;
}


/* syntax-expand-units */ obj_t 
syntax_expand_units_115_expand_syntax_case_44(obj_t units_19)
{
   {
      obj_t handler_195;
      handler_195 = proc1229_expand_syntax_case_44;
      {
	 obj_t list1056_38;
	 {
	    obj_t arg1058_40;
	    {
	       obj_t arg1060_42;
	       {
		  obj_t aux_269;
		  aux_269 = BCHAR(((unsigned char) '\n'));
		  arg1060_42 = MAKE_PAIR(aux_269, BNIL);
	       }
	       arg1058_40 = MAKE_PAIR(string1230_expand_syntax_case_44, arg1060_42);
	    }
	    list1056_38 = MAKE_PAIR(string1231_expand_syntax_case_44, arg1058_40);
	 }
	 verbose_tools_speek(BINT(((long) 1)), list1056_38);
      }
      _nb_error_on_pass__70_tools_error = BINT(((long) 0));
      _current_pass__25_engine_pass = string1230_expand_syntax_case_44;
      {
	 obj_t hooks_44;
	 obj_t hnames_45;
	 hooks_44 = BNIL;
	 hnames_45 = BNIL;
       loop_46:
	 if (NULLP(hooks_44))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1068_51;
	      {
		 obj_t fun1146_57;
		 fun1146_57 = CAR(hooks_44);
		 {
		    obj_t aux_281;
		    aux_281 = PROCEDURE_ENTRY(fun1146_57) (fun1146_57, BEOA);
		    test1068_51 = CBOOL(aux_281);
		 }
	      }
	      if (test1068_51)
		{
		   {
		      obj_t hnames_288;
		      obj_t hooks_286;
		      hooks_286 = CDR(hooks_44);
		      hnames_288 = CDR(hnames_45);
		      hnames_45 = hnames_288;
		      hooks_44 = hooks_286;
		      goto loop_46;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1230_expand_syntax_case_44, string1232_expand_syntax_case_44, CAR(hnames_45));
		}
	   }
      }
      {
	 obj_t l1002_58;
	 l1002_58 = units_19;
       lname1003_59:
	 if (PAIRP(l1002_58))
	   {
	      {
		 obj_t unit_61;
		 unit_61 = CAR(l1002_58);
		 {
		    bool_t test_295;
		    {
		       obj_t aux_296;
		       aux_296 = STRUCT_REF(unit_61, ((long) 2));
		       test_295 = PROCEDUREP(aux_296);
		    }
		    if (test_295)
		      {
			 CNST_TABLE_REF(((long) 1));
		      }
		    else
		      {
			 obj_t src_63;
			 obj_t res_64;
			 src_63 = STRUCT_REF(unit_61, ((long) 2));
			 res_64 = BNIL;
		       loop_65:
			 if (NULLP(src_63))
			   {
			      obj_t arg1161_69;
			      arg1161_69 = reverse__39___r4_pairs_and_lists_6_3(res_64);
			      {
				 obj_t x_232;
				 x_232 = STRUCT_SET(unit_61, ((long) 2), arg1161_69);
				 BUNSPEC;
			      }
			   }
			 else
			   {
			      obj_t new_body_215_70;
			      {
				 obj_t armed1007_73;
				 obj_t handler1004_74;
				 armed1007_73 = MAKE_CELL(BUNSPEC);
				 handler1004_74 = MAKE_CELL(BUNSPEC);
				 {
				    obj_t body1006_191;
				    obj_t rhandler1005_193;
				    body1006_191 = make_fx_procedure(body1006_expand_syntax_case_44, ((long) 0), ((long) 1));
				    rhandler1005_193 = make_fx_procedure(rhandler1005_expand_syntax_case_44, ((long) 4), ((long) 2));
				    PROCEDURE_SET(body1006_191, ((long) 0), src_63);
				    PROCEDURE_SET(rhandler1005_193, ((long) 0), armed1007_73);
				    PROCEDURE_SET(rhandler1005_193, ((long) 1), handler1004_74);
				    CELL_SET(handler1004_74, handler_195);
				    CELL_SET(armed1007_73, BTRUE);
				    new_body_215_70 = handling_function1176_expand_syntax_case_44(body1006_191, rhandler1005_193, handler1004_74, armed1007_73);
				 }
			      }
			      {
				 obj_t arg1163_71;
				 obj_t arg1175_72;
				 arg1163_71 = CDR(src_63);
				 arg1175_72 = MAKE_PAIR(new_body_215_70, res_64);
				 {
				    obj_t res_313;
				    obj_t src_312;
				    src_312 = arg1163_71;
				    res_313 = arg1175_72;
				    res_64 = res_313;
				    src_63 = src_312;
				    goto loop_65;
				 }
			      }
			   }
		      }
		 }
	      }
	      {
		 obj_t l1002_315;
		 l1002_315 = CDR(l1002_58);
		 l1002_58 = l1002_315;
		 goto lname1003_59;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      {
	 bool_t test1196_101;
	 {
	    long n1_176;
	    n1_176 = (long) CINT(_nb_error_on_pass__70_tools_error);
	    test1196_101 = (n1_176 > ((long) 0));
	 }
	 if (test1196_101)
	   {
	      {
		 char *arg1200_104;
		 {
		    bool_t test1207_111;
		    {
		       bool_t test1208_112;
		       {
			  obj_t obj_178;
			  obj_178 = _nb_error_on_pass__70_tools_error;
			  test1208_112 = INTEGERP(obj_178);
		       }
		       if (test1208_112)
			 {
			    test1207_111 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			 }
		       else
			 {
			    test1207_111 = ((bool_t) 0);
			 }
		    }
		    if (test1207_111)
		      {
			 arg1200_104 = "s";
		      }
		    else
		      {
			 arg1200_104 = "";
		      }
		 }
		 {
		    obj_t list1202_106;
		    {
		       obj_t arg1203_107;
		       {
			  obj_t arg1204_108;
			  {
			     obj_t arg1205_109;
			     arg1205_109 = MAKE_PAIR(string1233_expand_syntax_case_44, BNIL);
			     {
				obj_t aux_326;
				aux_326 = string_to_bstring(arg1200_104);
				arg1204_108 = MAKE_PAIR(aux_326, arg1205_109);
			     }
			  }
			  arg1203_107 = MAKE_PAIR(string1234_expand_syntax_case_44, arg1204_108);
		       }
		       list1202_106 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1203_107);
		    }
		    fprint___r4_output_6_10_3(current_error_port, list1202_106);
		 }
	      }
	      {
		 obj_t res1228_180;
		 exit(((long) -1));
		 res1228_180 = BINT(((long) -1));
		 return res1228_180;
	      }
	   }
	 else
	   {
	      obj_t hooks_113;
	      obj_t hnames_114;
	      hooks_113 = BNIL;
	      hnames_114 = BNIL;
	    loop_115:
	      if (NULLP(hooks_113))
		{
		   return units_19;
		}
	      else
		{
		   bool_t test1213_120;
		   {
		      obj_t fun1221_125;
		      fun1221_125 = CAR(hooks_113);
		      {
			 obj_t aux_337;
			 aux_337 = PROCEDURE_ENTRY(fun1221_125) (fun1221_125, BEOA);
			 test1213_120 = CBOOL(aux_337);
		      }
		   }
		   if (test1213_120)
		     {
			{
			   obj_t hnames_344;
			   obj_t hooks_342;
			   hooks_342 = CDR(hooks_113);
			   hnames_344 = CDR(hnames_114);
			   hnames_114 = hnames_344;
			   hooks_113 = hooks_342;
			   goto loop_115;
			}
		     }
		   else
		     {
			return internal_error_43_tools_error(_current_pass__25_engine_pass, string1235_expand_syntax_case_44, CAR(hnames_114));
		     }
		}
	   }
      }
   }
}


/* handling_function1176 */ obj_t 
handling_function1176_expand_syntax_case_44(obj_t body1006_230, obj_t rhandler1005_229, obj_t handler1004_228, obj_t armed1007_227)
{
   jmp_buf jmpbuf;
   obj_t an_exit1008_78;
   if (SET_EXIT(an_exit1008_78))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1008_78 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1008_78, ((bool_t) 1));
	   {
	      obj_t an_exitd1009_79;
	      an_exitd1009_79 = exitd_top;
	      {
		 obj_t escape_192;
		 escape_192 = make_fx_procedure(escape_expand_syntax_case_44, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_192, ((long) 0), an_exitd1009_79);
		 {
		    obj_t res1011_82;
		    {
		       obj_t arg1188_190;
		       obj_t arg1187_194;
		       arg1188_190 = make_fx_procedure(arg1188_expand_syntax_case_44, ((long) 0), ((long) 1));
		       arg1187_194 = make_fx_procedure(arg1187_expand_syntax_case_44, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1188_190, ((long) 0), armed1007_227);
		       PROCEDURE_SET(arg1187_194, ((long) 0), an_exitd1009_79);
		       PROCEDURE_SET(arg1187_194, ((long) 1), armed1007_227);
		       PROCEDURE_SET(arg1187_194, ((long) 2), handler1004_228);
		       PROCEDURE_SET(arg1187_194, ((long) 3), rhandler1005_229);
		       PROCEDURE_SET(arg1187_194, ((long) 4), escape_192);
		       res1011_82 = dynamic_wind_31___r4_control_features_6_9(arg1187_194, body1006_230, arg1188_190);
		    }
		    POP_EXIT();
		    return res1011_82;
		 }
	      }
	   }
	}
     }
}


/* _syntax-expand-units */ obj_t 
_syntax_expand_units_247_expand_syntax_case_44(obj_t env_196, obj_t units_197)
{
   return syntax_expand_units_115_expand_syntax_case_44(units_197);
}


/* arg1188 */ obj_t 
arg1188_expand_syntax_case_44(obj_t env_198)
{
   {
      obj_t armed1007_199;
      armed1007_199 = PROCEDURE_REF(env_198, ((long) 0));
      {
	 {
	    bool_t test_365;
	    {
	       obj_t aux_366;
	       aux_366 = CELL_REF(armed1007_199);
	       test_365 = CBOOL(aux_366);
	    }
	    if (test_365)
	      {
		 CELL_SET(armed1007_199, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1006 */ obj_t 
body1006_expand_syntax_case_44(obj_t env_201)
{
   {
      obj_t src_202;
      src_202 = PROCEDURE_REF(env_201, ((long) 0));
      {
	 return expand_syntax_236___r5_macro_4_3_init(CAR(src_202));
      }
   }
}


/* arg1187 */ obj_t 
arg1187_expand_syntax_case_44(obj_t env_203)
{
   {
      obj_t rhandler1005_207;
      obj_t escape_208;
      rhandler1005_207 = PROCEDURE_REF(env_203, ((long) 3));
      escape_208 = PROCEDURE_REF(env_203, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1005_207, escape_208);
      }
   }
}


/* escape */ obj_t 
escape_expand_syntax_case_44(obj_t env_209, obj_t val1010_211)
{
   {
      obj_t an_exitd1009_210;
      an_exitd1009_210 = PROCEDURE_REF(env_209, ((long) 0));
      {
	 obj_t val1010_80;
	 val1010_80 = val1010_211;
	 return unwind_until__178___bexit(an_exitd1009_210, val1010_80);
      }
   }
}


/* rhandler1005 */ obj_t 
rhandler1005_expand_syntax_case_44(obj_t env_212, obj_t esc_215, obj_t obj_216, obj_t proc_217, obj_t msg_218)
{
   {
      obj_t armed1007_213;
      obj_t handler1004_214;
      armed1007_213 = PROCEDURE_REF(env_212, ((long) 0));
      handler1004_214 = PROCEDURE_REF(env_212, ((long) 1));
      {
	 obj_t esc_89;
	 obj_t obj_90;
	 obj_t proc_91;
	 obj_t msg_92;
	 esc_89 = esc_215;
	 obj_90 = obj_216;
	 proc_91 = proc_217;
	 msg_92 = msg_218;
	 CELL_SET(armed1007_213, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_381;
	    aux_381 = CELL_REF(handler1004_214);
	    return PROCEDURE_ENTRY(aux_381) (CELL_REF(handler1004_214), esc_89, obj_90, proc_91, msg_92, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_expand_syntax_case_44(obj_t env_220, obj_t escape_221, obj_t proc_222, obj_t mes_223, obj_t obj_224)
{
   {
      obj_t escape_126;
      obj_t proc_127;
      obj_t mes_128;
      obj_t obj_129;
      escape_126 = escape_221;
      proc_127 = proc_222;
      mes_128 = mes_223;
      obj_129 = obj_224;
      {
	 obj_t list1225_188;
	 {
	    obj_t aux_382;
	    aux_382 = CNST_TABLE_REF(((long) 2));
	    list1225_188 = MAKE_PAIR(aux_382, BNIL);
	 }
	 return user_error_151_tools_error(proc_127, mes_128, obj_129, list1225_188);
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_syntax_case_44()
{
   module_initialization_70_tools_trace(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70_tools_speek(((long) 0), "EXPAND_SYNTAX-CASE");
   module_initialization_70_tools_error(((long) 0), "EXPAND_SYNTAX-CASE");
   return module_initialization_70_engine_pass(((long) 0), "EXPAND_SYNTAX-CASE");
}
