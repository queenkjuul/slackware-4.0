/*===========================================================================*/
/*   (Eval/expd-quote.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t vector_template_162___expander_quote(obj_t, obj_t);
extern obj_t expand_quote_117___expander_quote(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _quasiquotation___expander_quote(obj_t, obj_t, obj_t);
static obj_t symbol1384___expander_quote = BUNSPEC;
static obj_t symbol1383___expander_quote = BUNSPEC;
static obj_t symbol1379___expander_quote = BUNSPEC;
static obj_t symbol1380___expander_quote = BUNSPEC;
static obj_t symbol1378___expander_quote = BUNSPEC;
static obj_t symbol1377___expander_quote = BUNSPEC;
static obj_t symbol1373___expander_quote = BUNSPEC;
static obj_t symbol1370___expander_quote = BUNSPEC;
static obj_t symbol1368___expander_quote = BUNSPEC;
static obj_t template_or_splice_155___expander_quote(obj_t, obj_t);
static obj_t symbol1367___expander_quote = BUNSPEC;
static obj_t list1385___expander_quote = BUNSPEC;
static obj_t list1382___expander_quote = BUNSPEC;
static obj_t list1381___expander_quote = BUNSPEC;
static obj_t list1374___expander_quote = BUNSPEC;
static obj_t list1369___expander_quote = BUNSPEC;
static obj_t template___expander_quote(obj_t, obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
static obj_t template_or_splice_list_106___expander_quote(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t quasiquotation___expander_quote(obj_t, obj_t);
extern obj_t module_initialization_70___expander_quote(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
static obj_t list_template_10___expander_quote(obj_t, obj_t);
static obj_t _expand_quote_104___expander_quote(obj_t, obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_quote();
static obj_t require_initialization_114___expander_quote = BUNSPEC;
static obj_t cnst_init_137___expander_quote();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_quote_env_135___expander_quote, _expand_quote_104___expander_quote1388, _expand_quote_104___expander_quote, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( quasiquotation_env_4___expander_quote, _quasiquotation___expander_quote1389, _quasiquotation___expander_quote, 0L, 2 );
DEFINE_STRING( string1386___expander_quote, string1386___expander_quote1390, "unquote-splicing", 16 );
DEFINE_STRING( string1376___expander_quote, string1376___expander_quote1391, "Type `extended pair' expected for expression", 44 );
DEFINE_STRING( string1375___expander_quote, string1375___expander_quote1392, "cer", 3 );
DEFINE_STRING( string1372___expander_quote, string1372___expander_quote1393, "Illegal form", 12 );
DEFINE_STRING( string1371___expander_quote, string1371___expander_quote1394, "unquote", 7 );
DEFINE_STRING( string1366___expander_quote, string1366___expander_quote1395, "illegal form", 12 );
DEFINE_STRING( string1365___expander_quote, string1365___expander_quote1396, "quasiquotation", 14 );
DEFINE_STRING( string1364___expander_quote, string1364___expander_quote1397, "Illegal `quote' form", 20 );
DEFINE_STRING( string1363___expander_quote, string1363___expander_quote1398, "quote", 5 );


/* module-initialization */obj_t module_initialization_70___expander_quote(long checksum_871, char * from_872)
{
if(CBOOL(require_initialization_114___expander_quote)){
require_initialization_114___expander_quote = BBOOL(((bool_t)0));
cnst_init_137___expander_quote();
imported_modules_init_94___expander_quote();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_quote()
{
symbol1367___expander_quote = string_to_symbol("UNQUOTE");
symbol1368___expander_quote = string_to_symbol("LIST");
symbol1370___expander_quote = string_to_symbol("QUOTE");
{
obj_t aux_881;
aux_881 = MAKE_PAIR(symbol1367___expander_quote, BNIL);
list1369___expander_quote = MAKE_PAIR(symbol1370___expander_quote, aux_881);
}
symbol1373___expander_quote = string_to_symbol("QUASIQUOTE");
{
obj_t aux_885;
aux_885 = MAKE_PAIR(symbol1373___expander_quote, BNIL);
list1374___expander_quote = MAKE_PAIR(symbol1370___expander_quote, aux_885);
}
symbol1377___expander_quote = string_to_symbol("CONS*");
symbol1378___expander_quote = string_to_symbol("LIST->VECTOR");
symbol1379___expander_quote = string_to_symbol("LET");
symbol1380___expander_quote = string_to_symbol("VECTOR-TAG-SET!");
{
obj_t aux_892;
aux_892 = MAKE_PAIR(BNIL, BNIL);
list1382___expander_quote = MAKE_PAIR(symbol1370___expander_quote, aux_892);
}
list1381___expander_quote = MAKE_PAIR(list1382___expander_quote, BNIL);
symbol1383___expander_quote = string_to_symbol("UNQUOTE-SPLICING");
symbol1384___expander_quote = string_to_symbol("APPEND");
{
obj_t aux_898;
aux_898 = MAKE_PAIR(symbol1383___expander_quote, BNIL);
return (list1385___expander_quote = MAKE_PAIR(symbol1370___expander_quote, aux_898),
BUNSPEC);
}
}


/* expand-quote */obj_t expand_quote_117___expander_quote(obj_t x_1, obj_t e_2)
{
if(PAIRP(x_1)){
obj_t cdr_107_0_336;
cdr_107_0_336 = CDR(x_1);
if(PAIRP(cdr_107_0_336)){
bool_t test_906;
{
obj_t aux_907;
aux_907 = CDR(cdr_107_0_336);
test_906 = (aux_907==BNIL);
}
if(test_906){
return x_1;
}
 else {
FAILURE(string1363___expander_quote,string1364___expander_quote,x_1);}
}
 else {
FAILURE(string1363___expander_quote,string1364___expander_quote,x_1);}
}
 else {
FAILURE(string1363___expander_quote,string1364___expander_quote,x_1);}
}


/* _expand-quote */obj_t _expand_quote_104___expander_quote(obj_t env_865, obj_t x_866, obj_t e_867)
{
return expand_quote_117___expander_quote(x_866, e_867);
}


/* quasiquotation */obj_t quasiquotation___expander_quote(obj_t d_3, obj_t exp_4)
{
{
bool_t test_914;
if(PAIRP(exp_4)){
bool_t test_917;
{
obj_t aux_918;
aux_918 = CDR(exp_4);
test_917 = PAIRP(aux_918);
}
if(test_917){
obj_t aux_921;
{
obj_t aux_922;
aux_922 = CDR(exp_4);
aux_921 = CDR(aux_922);
}
test_914 = NULLP(aux_921);
}
 else {
test_914 = ((bool_t)0);
}
}
 else {
test_914 = ((bool_t)0);
}
if(test_914){
obj_t aux_926;
{
obj_t aux_927;
aux_927 = CDR(exp_4);
aux_926 = CAR(aux_927);
}
return template___expander_quote(d_3, aux_926);
}
 else {
FAILURE(string1365___expander_quote,string1366___expander_quote,exp_4);}
}
}


/* _quasiquotation */obj_t _quasiquotation___expander_quote(obj_t env_868, obj_t d_869, obj_t exp_870)
{
return quasiquotation___expander_quote(d_869, exp_870);
}


/* template */obj_t template___expander_quote(obj_t d_5, obj_t exp_6)
{
template___expander_quote:
{
bool_t test_933;
{
long aux_934;
aux_934 = (long)CINT(d_5);
test_933 = (aux_934==((long)0));
}
if(test_933){
return exp_6;
}
 else {
bool_t test_937;
if(PAIRP(exp_6)){
obj_t aux_940;
aux_940 = CAR(exp_6);
test_937 = (aux_940==symbol1367___expander_quote);
}
 else {
test_937 = ((bool_t)0);
}
if(test_937){
{
bool_t test_943;
if(PAIRP(exp_6)){
bool_t test_946;
{
obj_t aux_947;
aux_947 = CDR(exp_6);
test_946 = PAIRP(aux_947);
}
if(test_946){
obj_t aux_950;
{
obj_t aux_951;
aux_951 = CDR(exp_6);
aux_950 = CDR(aux_951);
}
test_943 = NULLP(aux_950);
}
 else {
test_943 = ((bool_t)0);
}
}
 else {
test_943 = ((bool_t)0);
}
if(test_943){
bool_t test_955;
{
obj_t aux_956;
aux_956 = BINT(((long)1));
test_955 = (d_5==aux_956);
}
if(test_955){
obj_t exp_965;
obj_t d_959;
{
long aux_960;
{
long aux_961;
aux_961 = (long)CINT(d_5);
aux_960 = (aux_961-((long)1));
}
d_959 = BINT(aux_960);
}
{
obj_t aux_966;
aux_966 = CDR(exp_6);
exp_965 = CAR(aux_966);
}
exp_6 = exp_965;
d_5 = d_959;
goto template___expander_quote;
}
 else {
obj_t arg1030_360;
obj_t arg1031_361;
obj_t arg1032_362;
arg1030_360 = symbol1368___expander_quote;
arg1031_361 = list1369___expander_quote;
{
obj_t aux_975;
obj_t aux_969;
{
obj_t aux_976;
aux_976 = CDR(exp_6);
aux_975 = CAR(aux_976);
}
{
long aux_970;
{
long aux_971;
aux_971 = (long)CINT(d_5);
aux_970 = (aux_971-((long)1));
}
aux_969 = BINT(aux_970);
}
arg1032_362 = template___expander_quote(aux_969, aux_975);
}
{
obj_t list1033_363;
{
obj_t arg1034_364;
{
obj_t arg1035_365;
arg1035_365 = MAKE_PAIR(arg1032_362, BNIL);
arg1034_364 = MAKE_PAIR(arg1031_361, arg1035_365);
}
list1033_363 = MAKE_PAIR(arg1030_360, arg1034_364);
}
return list1033_363;
}
}
}
 else {
obj_t aux_983;
{
obj_t aux_984;
aux_984 = CDR(exp_6);
aux_983 = CAR(aux_984);
}
FAILURE(string1371___expander_quote,string1372___expander_quote,aux_983);}
}
}
 else {
if(VECTORP(exp_6)){
return vector_template_162___expander_quote(d_5, exp_6);
}
 else {
if(PAIRP(exp_6)){
return list_template_10___expander_quote(d_5, exp_6);
}
 else {
if(NULLP(exp_6)){
{
obj_t arg1050_379;
arg1050_379 = symbol1370___expander_quote;
{
obj_t list1051_380;
{
obj_t arg1053_381;
arg1053_381 = MAKE_PAIR(exp_6, BNIL);
list1051_380 = MAKE_PAIR(arg1050_379, arg1053_381);
}
return list1051_380;
}
}
}
 else {
bool_t test_998;
if(CHARP(exp_6)){
test_998 = ((bool_t)1);
}
 else {
if(INTEGERP(exp_6)){
test_998 = ((bool_t)1);
}
 else {
if(STRINGP(exp_6)){
test_998 = ((bool_t)1);
}
 else {
test_998 = CNSTP(exp_6);
}
}
}
if(test_998){
return exp_6;
}
 else {
{
obj_t arg1056_384;
arg1056_384 = symbol1370___expander_quote;
{
obj_t list1057_385;
{
obj_t arg1058_386;
arg1058_386 = MAKE_PAIR(exp_6, BNIL);
list1057_385 = MAKE_PAIR(arg1056_384, arg1058_386);
}
return list1057_385;
}
}
}
}
}
}
}
}
}
}


/* list-template */obj_t list_template_10___expander_quote(obj_t d_7, obj_t exp_8)
{
{
bool_t test_1008;
{
bool_t test_1009;
if(PAIRP(exp_8)){
bool_t test_1012;
{
obj_t aux_1013;
aux_1013 = CDR(exp_8);
test_1012 = PAIRP(aux_1013);
}
if(test_1012){
obj_t aux_1016;
{
obj_t aux_1017;
aux_1017 = CDR(exp_8);
aux_1016 = CDR(aux_1017);
}
test_1009 = NULLP(aux_1016);
}
 else {
test_1009 = ((bool_t)0);
}
}
 else {
test_1009 = ((bool_t)0);
}
if(test_1009){
bool_t test_1021;
{
obj_t aux_1022;
aux_1022 = CAR(exp_8);
test_1021 = (aux_1022==symbol1370___expander_quote);
}
if(test_1021){
bool_t test_1025;
{
obj_t aux_1026;
{
obj_t aux_1027;
aux_1027 = CDR(exp_8);
aux_1026 = CAR(aux_1027);
}
test_1025 = PAIRP(aux_1026);
}
if(test_1025){
obj_t aux_1031;
{
obj_t aux_1032;
{
obj_t aux_1033;
aux_1033 = CDR(exp_8);
aux_1032 = CAR(aux_1033);
}
aux_1031 = CAR(aux_1032);
}
test_1008 = (aux_1031==symbol1373___expander_quote);
}
 else {
test_1008 = ((bool_t)0);
}
}
 else {
test_1008 = ((bool_t)0);
}
}
 else {
test_1008 = ((bool_t)0);
}
}
if(test_1008){
{
obj_t aux_1038;
{
obj_t aux_1039;
aux_1039 = CDR(exp_8);
aux_1038 = CAR(aux_1039);
}
return quasiquotation___expander_quote(d_7, aux_1038);
}
}
 else {
bool_t test_1043;
{
obj_t aux_1044;
aux_1044 = CAR(exp_8);
test_1043 = (aux_1044==symbol1373___expander_quote);
}
if(test_1043){
{
bool_t test_1047;
{
obj_t aux_1048;
aux_1048 = BINT(((long)0));
test_1047 = (d_7==aux_1048);
}
if(test_1047){
return quasiquotation___expander_quote(_2__168___r4_numbers_6_5(d_7, BINT(((long)1))), exp_8);
}
 else {
obj_t arg1073_399;
obj_t arg1076_400;
obj_t arg1077_401;
arg1073_399 = symbol1368___expander_quote;
arg1076_400 = list1374___expander_quote;
arg1077_401 = quasiquotation___expander_quote(_2__168___r4_numbers_6_5(d_7, BINT(((long)1))), exp_8);
{
obj_t list1078_402;
{
obj_t arg1079_403;
{
obj_t arg1080_404;
arg1080_404 = MAKE_PAIR(arg1077_401, BNIL);
arg1079_403 = MAKE_PAIR(arg1076_400, arg1080_404);
}
list1078_402 = MAKE_PAIR(arg1073_399, arg1079_403);
}
return list1078_402;
}
}
}
}
 else {
{
bool_t test1083_407;
test1083_407 = EXTENDED_PAIRP(exp_8);
if(test1083_407){
obj_t er_408;
{
bool_t test1303_779;
test1303_779 = EXTENDED_PAIRP(exp_8);
if(test1303_779){
er_408 = CER(exp_8);
}
 else {
FAILURE(string1375___expander_quote,string1376___expander_quote,exp_8);}
}
{
obj_t arg1084_409;
obj_t arg1085_410;
arg1084_409 = symbol1377___expander_quote;
arg1085_410 = template_or_splice_list_106___expander_quote(d_7, exp_8);
return MAKE_EXTENDED_PAIR(arg1084_409, arg1085_410, er_408);
}
}
 else {
obj_t arg1086_411;
obj_t arg1087_412;
arg1086_411 = symbol1377___expander_quote;
arg1087_412 = template_or_splice_list_106___expander_quote(d_7, exp_8);
return MAKE_PAIR(arg1086_411, arg1087_412);
}
}
}
}
}
}


/* vector-template */obj_t vector_template_162___expander_quote(obj_t d_9, obj_t exp_10)
{
{
long tag_val_61_428;
obj_t res_val_215_429;
tag_val_61_428 = VECTOR_TAG(exp_10);
{
obj_t arg1127_455;
obj_t arg1128_456;
arg1127_455 = symbol1378___expander_quote;
{
obj_t arg1132_460;
obj_t arg1133_461;
arg1132_460 = symbol1377___expander_quote;
{
obj_t arg1134_462;
arg1134_462 = vector__list_155___r4_vectors_6_8(exp_10);
arg1133_461 = template_or_splice_list_106___expander_quote(d_9, arg1134_462);
}
arg1128_456 = MAKE_PAIR(arg1132_460, arg1133_461);
}
{
obj_t list1129_457;
{
obj_t arg1130_458;
arg1130_458 = MAKE_PAIR(arg1128_456, BNIL);
list1129_457 = MAKE_PAIR(arg1127_455, arg1130_458);
}
res_val_215_429 = list1129_457;
}
}
if((tag_val_61_428==((long)0))){
return res_val_215_429;
}
 else {
obj_t res_var_182_431;
res_var_182_431 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, BEOA);
{
obj_t arg1104_432;
obj_t arg1105_433;
obj_t arg1106_434;
arg1104_432 = symbol1379___expander_quote;
{
obj_t arg1113_441;
{
obj_t list1118_446;
{
obj_t arg1119_447;
arg1119_447 = MAKE_PAIR(BNIL, BNIL);
list1118_446 = MAKE_PAIR(res_val_215_429, arg1119_447);
}
arg1113_441 = cons__138___r4_pairs_and_lists_6_3(res_var_182_431, list1118_446);
}
{
obj_t list1115_443;
list1115_443 = MAKE_PAIR(BNIL, BNIL);
arg1105_433 = cons__138___r4_pairs_and_lists_6_3(arg1113_441, list1115_443);
}
}
{
obj_t arg1121_449;
arg1121_449 = symbol1380___expander_quote;
{
obj_t list1123_451;
{
obj_t arg1124_452;
{
obj_t arg1125_453;
arg1125_453 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1086;
aux_1086 = BINT(tag_val_61_428);
arg1124_452 = MAKE_PAIR(aux_1086, arg1125_453);
}
}
list1123_451 = MAKE_PAIR(res_var_182_431, arg1124_452);
}
arg1106_434 = cons__138___r4_pairs_and_lists_6_3(arg1121_449, list1123_451);
}
}
{
obj_t list1108_436;
{
obj_t arg1109_437;
{
obj_t arg1110_438;
{
obj_t arg1111_439;
arg1111_439 = MAKE_PAIR(BNIL, BNIL);
arg1110_438 = MAKE_PAIR(res_var_182_431, arg1111_439);
}
arg1109_437 = MAKE_PAIR(arg1106_434, arg1110_438);
}
list1108_436 = MAKE_PAIR(arg1105_433, arg1109_437);
}
return cons__138___r4_pairs_and_lists_6_3(arg1104_432, list1108_436);
}
}
}
}
}


/* template-or-splice-list */obj_t template_or_splice_list_106___expander_quote(obj_t d_11, obj_t exp_12)
{
if(NULLP(exp_12)){
return list1381___expander_quote;
}
 else {
if(PAIRP(exp_12)){
{
bool_t test_1100;
{
obj_t aux_1101;
aux_1101 = CAR(exp_12);
test_1100 = (aux_1101==symbol1367___expander_quote);
}
if(test_1100){
{
obj_t arg1139_466;
arg1139_466 = template___expander_quote(d_11, exp_12);
{
obj_t list1140_467;
list1140_467 = MAKE_PAIR(arg1139_466, BNIL);
return list1140_467;
}
}
}
 else {
bool_t test_1106;
{
bool_t test_1107;
{
obj_t aux_1108;
aux_1108 = CAR(exp_12);
test_1107 = PAIRP(aux_1108);
}
if(test_1107){
obj_t aux_1111;
{
obj_t aux_1112;
aux_1112 = CAR(exp_12);
aux_1111 = CAR(aux_1112);
}
test_1106 = (aux_1111==symbol1383___expander_quote);
}
 else {
test_1106 = ((bool_t)0);
}
}
if(test_1106){
{
obj_t arg1143_470;
{
obj_t arg1146_473;
obj_t arg1147_474;
obj_t arg1148_475;
arg1146_473 = symbol1384___expander_quote;
arg1147_474 = template_or_splice_155___expander_quote(d_11, CAR(exp_12));
{
obj_t arg1154_481;
obj_t arg1155_482;
arg1154_481 = symbol1377___expander_quote;
arg1155_482 = template_or_splice_list_106___expander_quote(d_11, CDR(exp_12));
arg1148_475 = MAKE_PAIR(arg1154_481, arg1155_482);
}
{
obj_t list1149_476;
{
obj_t arg1150_477;
{
obj_t arg1151_478;
arg1151_478 = MAKE_PAIR(arg1148_475, BNIL);
arg1150_477 = MAKE_PAIR(arg1147_474, arg1151_478);
}
list1149_476 = MAKE_PAIR(arg1146_473, arg1150_477);
}
arg1143_470 = list1149_476;
}
}
{
obj_t list1144_471;
list1144_471 = MAKE_PAIR(arg1143_470, BNIL);
return list1144_471;
}
}
}
 else {
{
obj_t arg1157_484;
obj_t arg1158_485;
arg1157_484 = template_or_splice_155___expander_quote(d_11, CAR(exp_12));
arg1158_485 = template_or_splice_list_106___expander_quote(d_11, CDR(exp_12));
return MAKE_PAIR(arg1157_484, arg1158_485);
}
}
}
}
}
 else {
{
obj_t arg1169_495;
arg1169_495 = template_or_splice_155___expander_quote(d_11, exp_12);
{
obj_t list1170_496;
list1170_496 = MAKE_PAIR(arg1169_495, BNIL);
return list1170_496;
}
}
}
}
}


/* template-or-splice */obj_t template_or_splice_155___expander_quote(obj_t d_13, obj_t exp_14)
{
{
bool_t test_1132;
if(PAIRP(exp_14)){
obj_t aux_1135;
aux_1135 = CAR(exp_14);
test_1132 = (aux_1135==symbol1383___expander_quote);
}
 else {
test_1132 = ((bool_t)0);
}
if(test_1132){
bool_t test_1138;
if(PAIRP(exp_14)){
bool_t test_1141;
{
obj_t aux_1142;
aux_1142 = CDR(exp_14);
test_1141 = PAIRP(aux_1142);
}
if(test_1141){
obj_t aux_1145;
{
obj_t aux_1146;
aux_1146 = CDR(exp_14);
aux_1145 = CDR(aux_1146);
}
test_1138 = NULLP(aux_1145);
}
 else {
test_1138 = ((bool_t)0);
}
}
 else {
test_1138 = ((bool_t)0);
}
if(test_1138){
bool_t test_1150;
{
obj_t aux_1151;
aux_1151 = BINT(((long)1));
test_1150 = (d_13==aux_1151);
}
if(test_1150){
obj_t aux_1160;
obj_t aux_1154;
{
obj_t aux_1161;
aux_1161 = CDR(exp_14);
aux_1160 = CAR(aux_1161);
}
{
long aux_1155;
{
long aux_1156;
aux_1156 = (long)CINT(d_13);
aux_1155 = (aux_1156-((long)1));
}
aux_1154 = BINT(aux_1155);
}
return template___expander_quote(aux_1154, aux_1160);
}
 else {
obj_t arg1177_503;
obj_t arg1178_504;
arg1177_503 = symbol1368___expander_quote;
{
obj_t arg1182_508;
obj_t arg1183_509;
obj_t arg1184_510;
arg1182_508 = symbol1368___expander_quote;
arg1183_509 = list1385___expander_quote;
{
obj_t aux_1171;
obj_t aux_1165;
{
obj_t aux_1172;
aux_1172 = CDR(exp_14);
aux_1171 = CAR(aux_1172);
}
{
long aux_1166;
{
long aux_1167;
aux_1167 = (long)CINT(d_13);
aux_1166 = (aux_1167-((long)1));
}
aux_1165 = BINT(aux_1166);
}
arg1184_510 = template___expander_quote(aux_1165, aux_1171);
}
{
obj_t list1185_511;
{
obj_t arg1186_512;
{
obj_t arg1187_513;
arg1187_513 = MAKE_PAIR(arg1184_510, BNIL);
arg1186_512 = MAKE_PAIR(arg1183_509, arg1187_513);
}
list1185_511 = MAKE_PAIR(arg1182_508, arg1186_512);
}
arg1178_504 = list1185_511;
}
}
{
obj_t list1179_505;
{
obj_t arg1180_506;
arg1180_506 = MAKE_PAIR(arg1178_504, BNIL);
list1179_505 = MAKE_PAIR(arg1177_503, arg1180_506);
}
return list1179_505;
}
}
}
 else {
FAILURE(string1386___expander_quote,string1372___expander_quote,exp_14);}
}
 else {
return template___expander_quote(d_13, exp_14);
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_quote()
{
module_initialization_70___error(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___bigloo(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___tvector(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___structure(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___bexit(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_QUOTE");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_QUOTE");
return module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_QUOTE");
}

