/*===========================================================================*/
/*   (Rgc/rgc-tree.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _print_node_29___rgc_tree(obj_t, obj_t);
extern obj_t rgcset_add__25___rgc_set(obj_t, int);
extern obj_t string_to_symbol(char *);
static obj_t symbol1344___rgc_tree = BUNSPEC;
static obj_t symbol1342___rgc_tree = BUNSPEC;
static obj_t symbol1339___rgc_tree = BUNSPEC;
static obj_t symbol1337___rgc_tree = BUNSPEC;
static obj_t symbol1335___rgc_tree = BUNSPEC;
static obj_t symbol1332___rgc_tree = BUNSPEC;
static obj_t symbol1330___rgc_tree = BUNSPEC;
static obj_t symbol1328___rgc_tree = BUNSPEC;
static obj_t symbol1326___rgc_tree = BUNSPEC;
static obj_t symbol1324___rgc_tree = BUNSPEC;
static obj_t symbol1321___rgc_tree = BUNSPEC;
static obj_t symbol1319___rgc_tree = BUNSPEC;
static obj_t symbol1318___rgc_tree = BUNSPEC;
static obj_t symbol1316___rgc_tree = BUNSPEC;
static obj_t symbol1313___rgc_tree = BUNSPEC;
static obj_t symbol1299___rgc_tree = BUNSPEC;
static obj_t symbol1305___rgc_tree = BUNSPEC;
static obj_t symbol1304___rgc_tree = BUNSPEC;
static obj_t symbol1303___rgc_tree = BUNSPEC;
static obj_t symbol1302___rgc_tree = BUNSPEC;
static obj_t symbol1301___rgc_tree = BUNSPEC;
static obj_t symbol1300___rgc_tree = BUNSPEC;
static long regular_tree_position_number_114___rgc_tree(obj_t);
static obj_t list1341___rgc_tree = BUNSPEC;
static obj_t list1340___rgc_tree = BUNSPEC;
static obj_t list1338___rgc_tree = BUNSPEC;
static obj_t list1336___rgc_tree = BUNSPEC;
static obj_t list1334___rgc_tree = BUNSPEC;
static obj_t list1331___rgc_tree = BUNSPEC;
static obj_t list1329___rgc_tree = BUNSPEC;
static obj_t list1327___rgc_tree = BUNSPEC;
static obj_t list1325___rgc_tree = BUNSPEC;
static obj_t list1323___rgc_tree = BUNSPEC;
static obj_t list1322___rgc_tree = BUNSPEC;
static obj_t list1320___rgc_tree = BUNSPEC;
static obj_t list1317___rgc_tree = BUNSPEC;
static obj_t list1315___rgc_tree = BUNSPEC;
static obj_t list1314___rgc_tree = BUNSPEC;
static obj_t list1312___rgc_tree = BUNSPEC;
static obj_t toplevel_init_63___rgc_tree();
static obj_t _submatches__49___rgc_tree = BUNSPEC;
static obj_t submatch_stop_add__97___rgc_tree(obj_t, obj_t, obj_t);
static long loop_1298___rgc_tree(obj_t, long);
extern obj_t _res3__194___r5_control_features_6_4;
extern obj_t print___r4_output_6_10_3(obj_t);
extern obj_t _res2__167___r5_control_features_6_4;
extern obj_t _res1__155___r5_control_features_6_4;
static obj_t sequence__node_242___rgc_tree(obj_t);
extern obj_t print_followpos_61___rgc_tree(obj_t);
static obj_t init_positions__173___rgc_tree();
static obj_t sequence2__node_94___rgc_tree(obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t print_node_135___rgc_tree(obj_t);
static obj_t init_followpos__99___rgc_tree();
extern obj_t rgcset_or__64___rgc_set(obj_t, obj_t);
static obj_t _positions__152___rgc_tree = BUNSPEC;
static obj_t loop___rgc_tree(obj_t, obj_t);
static obj_t integer__node_105___rgc_tree(obj_t);
static obj_t _current_position__206___rgc_tree = BUNSPEC;
static obj_t _followpos__147___rgc_tree = BUNSPEC;
static obj_t _position_number__58___rgc_tree = BUNSPEC;
extern obj_t module_initialization_70___rgc_tree(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___rgc_set(long, char *);
extern obj_t module_initialization_70___rgc_config(long, char *);
extern obj_t _res_number__75___r5_control_features_6_4;
static obj_t submatch_start_add__59___rgc_tree(obj_t, obj_t, obj_t, obj_t);
extern obj_t rgcset_or_160___rgc_set(obj_t, obj_t);
static obj_t arg1102___rgc_tree(obj_t, obj_t);
static obj_t arg1089___rgc_tree(obj_t, obj_t);
static obj_t arg1100___rgc_tree(obj_t, obj_t);
static obj_t arg1079___rgc_tree(obj_t, obj_t);
extern obj_t regular_tree__node_150___rgc_tree(obj_t);
static obj_t _print_followpos_153___rgc_tree(obj_t, obj_t);
static obj_t _regular_tree__node_31___rgc_tree(obj_t, obj_t);
static obj_t _reset_tree__102___rgc_tree(obj_t);
extern obj_t for_each_rgcset_171___rgc_set(obj_t, obj_t);
static obj_t or2__node_94___rgc_tree(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___rgc_tree();
static obj_t tree__node_162___rgc_tree(obj_t);
static obj_t require_initialization_114___rgc_tree = BUNSPEC;
extern obj_t make_rgcset_69___rgc_set(int);
extern obj_t reset_tree__130___rgc_tree();
static obj_t cnst_init_137___rgc_tree();
static obj_t submatch__node_185___rgc_tree(obj_t);
extern obj_t make_vector(long, obj_t);
static obj_t ___node_42___rgc_tree(obj_t);
static obj_t or__node_242___rgc_tree(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( print_followpos_env_205___rgc_tree, _print_followpos_153___rgc_tree1346, _print_followpos_153___rgc_tree, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( print_node_env_18___rgc_tree, _print_node_29___rgc_tree1347, _print_node_29___rgc_tree, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( reset_tree__env_120___rgc_tree, _reset_tree__102___rgc_tree1348, _reset_tree__102___rgc_tree, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( regular_tree__node_env_9___rgc_tree, _regular_tree__node_31___rgc_tree1349, _regular_tree__node_31___rgc_tree, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1309___rgc_tree, sequence2__node_94___rgc_tree1350, sequence2__node_94___rgc_tree, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1308___rgc_tree, or2__node_94___rgc_tree1351, or2__node_94___rgc_tree, 0L, 2 );
DEFINE_STRING( string1343___rgc_tree, string1343___rgc_tree1352, "==================================================", 50 );
DEFINE_STRING( string1333___rgc_tree, string1333___rgc_tree1353, ": ", 2 );
DEFINE_STRING( string1311___rgc_tree, string1311___rgc_tree1354, "number of pos: ", 15 );
DEFINE_STRING( string1310___rgc_tree, string1310___rgc_tree1355, "========= FOLLOWPOS ==============================", 50 );
DEFINE_STRING( string1307___rgc_tree, string1307___rgc_tree1356, "RGC:Illegal tree", 16 );
DEFINE_STRING( string1306___rgc_tree, string1306___rgc_tree1357, "RGC:Unknown function", 20 );


/* module-initialization */obj_t module_initialization_70___rgc_tree(long checksum_1149, char * from_1150)
{
if(CBOOL(require_initialization_114___rgc_tree)){
require_initialization_114___rgc_tree = BBOOL(((bool_t)0));
cnst_init_137___rgc_tree();
imported_modules_init_94___rgc_tree();
toplevel_init_63___rgc_tree();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc_tree()
{
symbol1299___rgc_tree = string_to_symbol("EPSILON");
symbol1300___rgc_tree = string_to_symbol("NODE");
symbol1301___rgc_tree = string_to_symbol("OR");
symbol1302___rgc_tree = string_to_symbol("SEQUENCE");
symbol1303___rgc_tree = string_to_symbol("*");
symbol1304___rgc_tree = string_to_symbol("SUBMATCH");
symbol1305___rgc_tree = string_to_symbol("BOL");
symbol1313___rgc_tree = string_to_symbol("LET");
symbol1316___rgc_tree = string_to_symbol("SZ");
symbol1318___rgc_tree = string_to_symbol("VECTOR-LENGTH");
symbol1319___rgc_tree = string_to_symbol("FP");
{
obj_t aux_1168;
aux_1168 = MAKE_PAIR(symbol1319___rgc_tree, BNIL);
list1317___rgc_tree = MAKE_PAIR(symbol1318___rgc_tree, aux_1168);
}
{
obj_t aux_1171;
aux_1171 = MAKE_PAIR(list1317___rgc_tree, BNIL);
list1315___rgc_tree = MAKE_PAIR(symbol1316___rgc_tree, aux_1171);
}
list1314___rgc_tree = MAKE_PAIR(list1315___rgc_tree, BNIL);
symbol1321___rgc_tree = string_to_symbol("LOOP");
symbol1324___rgc_tree = string_to_symbol("I");
{
obj_t aux_1177;
{
obj_t aux_1178;
aux_1178 = BINT(((long)0));
aux_1177 = MAKE_PAIR(aux_1178, BNIL);
}
list1323___rgc_tree = MAKE_PAIR(symbol1324___rgc_tree, aux_1177);
}
list1322___rgc_tree = MAKE_PAIR(list1323___rgc_tree, BNIL);
symbol1326___rgc_tree = string_to_symbol("IF");
symbol1328___rgc_tree = string_to_symbol("<FX");
{
obj_t aux_1185;
{
obj_t aux_1186;
aux_1186 = MAKE_PAIR(symbol1316___rgc_tree, BNIL);
aux_1185 = MAKE_PAIR(symbol1324___rgc_tree, aux_1186);
}
list1327___rgc_tree = MAKE_PAIR(symbol1328___rgc_tree, aux_1185);
}
symbol1330___rgc_tree = string_to_symbol("BEGIN");
symbol1332___rgc_tree = string_to_symbol("PRINT");
symbol1335___rgc_tree = string_to_symbol("REVERSE");
symbol1337___rgc_tree = string_to_symbol("RGCSET->LIST");
symbol1339___rgc_tree = string_to_symbol("VECTOR-REF");
{
obj_t aux_1195;
{
obj_t aux_1196;
aux_1196 = MAKE_PAIR(symbol1324___rgc_tree, BNIL);
aux_1195 = MAKE_PAIR(symbol1319___rgc_tree, aux_1196);
}
list1338___rgc_tree = MAKE_PAIR(symbol1339___rgc_tree, aux_1195);
}
{
obj_t aux_1200;
aux_1200 = MAKE_PAIR(list1338___rgc_tree, BNIL);
list1336___rgc_tree = MAKE_PAIR(symbol1337___rgc_tree, aux_1200);
}
{
obj_t aux_1203;
aux_1203 = MAKE_PAIR(list1336___rgc_tree, BNIL);
list1334___rgc_tree = MAKE_PAIR(symbol1335___rgc_tree, aux_1203);
}
{
obj_t aux_1206;
{
obj_t aux_1207;
{
obj_t aux_1208;
aux_1208 = MAKE_PAIR(list1334___rgc_tree, BNIL);
aux_1207 = MAKE_PAIR(string1333___rgc_tree, aux_1208);
}
aux_1206 = MAKE_PAIR(symbol1324___rgc_tree, aux_1207);
}
list1331___rgc_tree = MAKE_PAIR(symbol1332___rgc_tree, aux_1206);
}
symbol1342___rgc_tree = string_to_symbol("+FX");
{
obj_t aux_1214;
{
obj_t aux_1215;
{
obj_t aux_1216;
aux_1216 = BINT(((long)1));
aux_1215 = MAKE_PAIR(aux_1216, BNIL);
}
aux_1214 = MAKE_PAIR(symbol1324___rgc_tree, aux_1215);
}
list1341___rgc_tree = MAKE_PAIR(symbol1342___rgc_tree, aux_1214);
}
{
obj_t aux_1221;
aux_1221 = MAKE_PAIR(list1341___rgc_tree, BNIL);
list1340___rgc_tree = MAKE_PAIR(symbol1321___rgc_tree, aux_1221);
}
{
obj_t aux_1224;
{
obj_t aux_1225;
aux_1225 = MAKE_PAIR(list1340___rgc_tree, BNIL);
aux_1224 = MAKE_PAIR(list1331___rgc_tree, aux_1225);
}
list1329___rgc_tree = MAKE_PAIR(symbol1330___rgc_tree, aux_1224);
}
{
obj_t aux_1229;
{
obj_t aux_1230;
aux_1230 = MAKE_PAIR(list1329___rgc_tree, BNIL);
aux_1229 = MAKE_PAIR(list1327___rgc_tree, aux_1230);
}
list1325___rgc_tree = MAKE_PAIR(symbol1326___rgc_tree, aux_1229);
}
{
obj_t aux_1234;
{
obj_t aux_1235;
{
obj_t aux_1236;
aux_1236 = MAKE_PAIR(list1325___rgc_tree, BNIL);
aux_1235 = MAKE_PAIR(list1322___rgc_tree, aux_1236);
}
aux_1234 = MAKE_PAIR(symbol1321___rgc_tree, aux_1235);
}
list1320___rgc_tree = MAKE_PAIR(symbol1313___rgc_tree, aux_1234);
}
{
obj_t aux_1241;
{
obj_t aux_1242;
aux_1242 = MAKE_PAIR(list1320___rgc_tree, BNIL);
aux_1241 = MAKE_PAIR(list1314___rgc_tree, aux_1242);
}
list1312___rgc_tree = MAKE_PAIR(symbol1313___rgc_tree, aux_1241);
}
return (symbol1344___rgc_tree = string_to_symbol("BLOP"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___rgc_tree()
{
_position_number__58___rgc_tree = BUNSPEC;
_positions__152___rgc_tree = BUNSPEC;
_submatches__49___rgc_tree = BUNSPEC;
_current_position__206___rgc_tree = BUNSPEC;
return (_followpos__147___rgc_tree = BUNSPEC,
BUNSPEC);
}


/* regular-tree->node */obj_t regular_tree__node_150___rgc_tree(obj_t tree_15)
{
{
long aux_1247;
aux_1247 = regular_tree_position_number_114___rgc_tree(tree_15);
_position_number__58___rgc_tree = BINT(aux_1247);
}
init_positions__173___rgc_tree();
init_followpos__99___rgc_tree();
{
obj_t tree_365;
tree_365 = tree__node_162___rgc_tree(tree_15);
{
obj_t val1_1003_367;
obj_t val2_1004_368;
obj_t val3_1005_369;
val1_1003_367 = _followpos__147___rgc_tree;
val2_1004_368 = _positions__152___rgc_tree;
val3_1005_369 = _submatches__49___rgc_tree;
_res_number__75___r5_control_features_6_4 = BINT(((long)4));
_res1__155___r5_control_features_6_4 = val1_1003_367;
_res2__167___r5_control_features_6_4 = val2_1004_368;
_res3__194___r5_control_features_6_4 = val3_1005_369;
return tree_365;
}
}
}


/* _regular-tree->node */obj_t _regular_tree__node_31___rgc_tree(obj_t env_1107, obj_t tree_1108)
{
return regular_tree__node_150___rgc_tree(tree_1108);
}


/* regular-tree-position-number */long regular_tree_position_number_114___rgc_tree(obj_t tree_16)
{
return loop_1298___rgc_tree(tree_16, ((long)0));
}


/* loop_1298 */long loop_1298___rgc_tree(obj_t tree_370, long num_371)
{
loop_1298___rgc_tree:
if(NULLP(tree_370)){
return num_371;
}
 else {
bool_t test_1258;
{
obj_t aux_1259;
aux_1259 = CAR(tree_370);
test_1258 = PAIRP(aux_1259);
}
if(test_1258){
{
long num_1264;
obj_t tree_1262;
tree_1262 = CDR(tree_370);
num_1264 = loop_1298___rgc_tree(CAR(tree_370), num_371);
num_371 = num_1264;
tree_370 = tree_1262;
goto loop_1298___rgc_tree;
}
}
 else {
bool_t test_1267;
{
obj_t aux_1268;
aux_1268 = CAR(tree_370);
test_1267 = INTEGERP(aux_1268);
}
if(test_1267){
{
long num_1273;
obj_t tree_1271;
tree_1271 = CDR(tree_370);
num_1273 = (num_371+((long)1));
num_371 = num_1273;
tree_370 = tree_1271;
goto loop_1298___rgc_tree;
}
}
 else {
{
obj_t tree_1275;
tree_1275 = CDR(tree_370);
tree_370 = tree_1275;
goto loop_1298___rgc_tree;
}
}
}
}
}


/* init-positions! */obj_t init_positions__173___rgc_tree()
{
_current_position__206___rgc_tree = BINT(((long)-1));
{
obj_t aux_1280;
long aux_1278;
aux_1280 = BINT(((long)-1));
aux_1278 = (long)CINT(_position_number__58___rgc_tree);
_positions__152___rgc_tree = make_vector(aux_1278, aux_1280);
}
{
long aux_1283;
aux_1283 = (long)CINT(_position_number__58___rgc_tree);
return (_submatches__49___rgc_tree = make_vector(aux_1283, BNIL),
BUNSPEC);
}
}


/* tree->node */obj_t tree__node_162___rgc_tree(obj_t tree_18)
{
if(INTEGERP(tree_18)){
return integer__node_105___rgc_tree(tree_18);
}
 else {
if((tree_18==symbol1299___rgc_tree)){
{
obj_t firstpos_734;
obj_t lastpos_735;
firstpos_734 = make_rgcset_69___rgc_set(CINT(_position_number__58___rgc_tree));
lastpos_735 = make_rgcset_69___rgc_set(CINT(_position_number__58___rgc_tree));
{
obj_t new_739;
new_739 = create_struct(symbol1300___rgc_tree, ((long)3));
STRUCT_SET(new_739, ((long)2), BTRUE);
STRUCT_SET(new_739, ((long)1), lastpos_735);
STRUCT_SET(new_739, ((long)0), firstpos_734);
return new_739;
}
}
}
 else {
if(PAIRP(tree_18)){
{
obj_t case_value_58_388;
case_value_58_388 = CAR(tree_18);
if((case_value_58_388==symbol1301___rgc_tree)){
return or__node_242___rgc_tree(CDR(tree_18));
}
 else {
if((case_value_58_388==symbol1302___rgc_tree)){
return sequence__node_242___rgc_tree(CDR(tree_18));
}
 else {
if((case_value_58_388==symbol1303___rgc_tree)){
obj_t aux_1312;
{
obj_t aux_1313;
aux_1313 = CDR(tree_18);
aux_1312 = CAR(aux_1313);
}
return ___node_42___rgc_tree(aux_1312);
}
 else {
if((case_value_58_388==symbol1304___rgc_tree)){
return submatch__node_185___rgc_tree(CDR(tree_18));
}
 else {
if((case_value_58_388==symbol1305___rgc_tree)){
obj_t node_778;
node_778 = tree__node_162___rgc_tree(CDR(tree_18));
{
return PROCEDURE_ENTRY(node_778)(node_778, STRUCT_REF(node_778, ((long)0)), STRUCT_REF(node_778, ((long)1)), BFALSE, BEOA);
}
}
 else {
FAILURE(BFALSE,string1306___rgc_tree,tree_18);}
}
}
}
}
}
}
 else {
FAILURE(BFALSE,string1307___rgc_tree,tree_18);}
}
}
}


/* integer->node */obj_t integer__node_105___rgc_tree(obj_t tree_19)
{
{
obj_t position_405;
obj_t firstpos_406;
obj_t lastpos_407;
{
long z1_794;
z1_794 = (long)CINT(_current_position__206___rgc_tree);
{
long aux_1332;
aux_1332 = (z1_794+((long)1));
_current_position__206___rgc_tree = BINT(aux_1332);
}
}
{
obj_t vector_796;
long k_797;
vector_796 = _positions__152___rgc_tree;
k_797 = (long)CINT(_current_position__206___rgc_tree);
VECTOR_SET(vector_796, k_797, tree_19);
}
position_405 = _current_position__206___rgc_tree;
firstpos_406 = make_rgcset_69___rgc_set(CINT(_position_number__58___rgc_tree));
lastpos_407 = make_rgcset_69___rgc_set(CINT(_position_number__58___rgc_tree));
rgcset_add__25___rgc_set(firstpos_406, CINT(position_405));
rgcset_add__25___rgc_set(lastpos_407, CINT(position_405));
{
obj_t new_802;
new_802 = create_struct(symbol1300___rgc_tree, ((long)3));
STRUCT_SET(new_802, ((long)2), BFALSE);
STRUCT_SET(new_802, ((long)1), lastpos_407);
STRUCT_SET(new_802, ((long)0), firstpos_406);
return new_802;
}
}
}


/* loop */obj_t loop___rgc_tree(obj_t bin_op_165_1141, obj_t ts_410)
{
{
bool_t test_1349;
{
obj_t aux_1350;
aux_1350 = CDR(ts_410);
test_1349 = NULLP(aux_1350);
}
if(test_1349){
return tree__node_162___rgc_tree(CAR(ts_410));
}
 else {
obj_t arg1065_414;
obj_t arg1066_415;
arg1065_414 = tree__node_162___rgc_tree(CAR(ts_410));
arg1066_415 = loop___rgc_tree(bin_op_165_1141, CDR(ts_410));
return PROCEDURE_ENTRY(bin_op_165_1141)(bin_op_165_1141, arg1065_414, arg1066_415, BEOA);
}
}
}


/* or->node */obj_t or__node_242___rgc_tree(obj_t ts_23)
{
{
obj_t or2__node_94_1109;
or2__node_94_1109 = proc1308___rgc_tree;
{
obj_t bin_op_165_1144;
obj_t ts_1145;
bin_op_165_1144 = or2__node_94_1109;
ts_1145 = ts_23;
return loop___rgc_tree(bin_op_165_1144, ts_1145);
}
}
}


/* or2->node */obj_t or2__node_94___rgc_tree(obj_t env_1110, obj_t n1_1111, obj_t n2_1112)
{
{
obj_t n1_420;
obj_t n2_421;
n1_420 = n1_1111;
n2_421 = n2_1112;
{
obj_t firstpos_423;
firstpos_423 = rgcset_or_160___rgc_set(STRUCT_REF(n1_420, ((long)0)), STRUCT_REF(n2_421, ((long)0)));
{
obj_t lastpos_424;
lastpos_424 = rgcset_or_160___rgc_set(STRUCT_REF(n1_420, ((long)1)), STRUCT_REF(n2_421, ((long)1)));
{
obj_t nullable__184_425;
{
obj_t _ortest_1006_426;
_ortest_1006_426 = STRUCT_REF(n1_420, ((long)2));
if(CBOOL(_ortest_1006_426)){
nullable__184_425 = _ortest_1006_426;
}
 else {
nullable__184_425 = STRUCT_REF(n2_421, ((long)2));
}
}
{
{
obj_t new_869;
new_869 = create_struct(symbol1300___rgc_tree, ((long)3));
STRUCT_SET(new_869, ((long)2), nullable__184_425);
STRUCT_SET(new_869, ((long)1), lastpos_424);
STRUCT_SET(new_869, ((long)0), firstpos_423);
return new_869;
}
}
}
}
}
}
}


/* sequence->node */obj_t sequence__node_242___rgc_tree(obj_t ts_24)
{
{
obj_t sequence2__node_94_1114;
sequence2__node_94_1114 = proc1309___rgc_tree;
{
obj_t bin_op_165_1146;
obj_t ts_1147;
bin_op_165_1146 = sequence2__node_94_1114;
ts_1147 = ts_24;
return loop___rgc_tree(bin_op_165_1146, ts_1147);
}
}
}


/* sequence2->node */obj_t sequence2__node_94___rgc_tree(obj_t env_1115, obj_t n1_1116, obj_t n2_1117)
{
{
obj_t n1_433;
obj_t n2_434;
n1_433 = n1_1116;
n2_434 = n2_1117;
{
obj_t firstpos_436;
obj_t lastpos_437;
obj_t nullable__184_438;
{
bool_t test_1377;
{
obj_t aux_1378;
aux_1378 = STRUCT_REF(n1_433, ((long)2));
test_1377 = CBOOL(aux_1378);
}
if(test_1377){
firstpos_436 = rgcset_or_160___rgc_set(STRUCT_REF(n1_433, ((long)0)), STRUCT_REF(n2_434, ((long)0)));
}
 else {
firstpos_436 = STRUCT_REF(n1_433, ((long)0));
}
}
{
bool_t test_1385;
{
obj_t aux_1386;
aux_1386 = STRUCT_REF(n2_434, ((long)2));
test_1385 = CBOOL(aux_1386);
}
if(test_1385){
lastpos_437 = rgcset_or_160___rgc_set(STRUCT_REF(n1_433, ((long)1)), STRUCT_REF(n2_434, ((long)1)));
}
 else {
lastpos_437 = STRUCT_REF(n2_434, ((long)1));
}
}
{
bool_t test_1393;
{
obj_t aux_1394;
aux_1394 = STRUCT_REF(n2_434, ((long)2));
test_1393 = CBOOL(aux_1394);
}
if(test_1393){
nullable__184_438 = STRUCT_REF(n1_433, ((long)2));
}
 else {
nullable__184_438 = BFALSE;
}
}
{
obj_t arg1080_440;
arg1080_440 = STRUCT_REF(n1_433, ((long)1));
{
obj_t arg1079_1113;
arg1079_1113 = make_fx_procedure(arg1079___rgc_tree, ((long)1), ((long)1));
PROCEDURE_SET(arg1079_1113, ((long)0), n2_434);
for_each_rgcset_171___rgc_set(arg1079_1113, arg1080_440);
}
}
{
obj_t new_932;
new_932 = create_struct(symbol1300___rgc_tree, ((long)3));
STRUCT_SET(new_932, ((long)2), nullable__184_438);
STRUCT_SET(new_932, ((long)1), lastpos_437);
STRUCT_SET(new_932, ((long)0), firstpos_436);
return new_932;
}
}
}
}


/* arg1079 */obj_t arg1079___rgc_tree(obj_t env_1118, obj_t i_1120)
{
{
obj_t n2_1119;
n2_1119 = PROCEDURE_REF(env_1118, ((long)0));
{
obj_t i_441;
i_441 = i_1120;
{
obj_t arg1108_926;
{
obj_t vector_927;
vector_927 = _followpos__147___rgc_tree;
{
long aux_1407;
aux_1407 = (long)CINT(i_441);
arg1108_926 = VECTOR_REF(vector_927, aux_1407);
}
}
return rgcset_or__64___rgc_set(arg1108_926, STRUCT_REF(n2_1119, ((long)0)));
}
}
}
}


/* *->node */obj_t ___node_42___rgc_tree(obj_t expr_25)
{
{
obj_t sub_node_101_453;
sub_node_101_453 = tree__node_162___rgc_tree(expr_25);
{
obj_t firstpos_454;
firstpos_454 = STRUCT_REF(sub_node_101_453, ((long)0));
{
obj_t lastpos_455;
lastpos_455 = STRUCT_REF(sub_node_101_453, ((long)1));
{
{
obj_t arg1089_1121;
arg1089_1121 = make_fx_procedure(arg1089___rgc_tree, ((long)1), ((long)1));
PROCEDURE_SET(arg1089_1121, ((long)0), firstpos_454);
for_each_rgcset_171___rgc_set(arg1089_1121, lastpos_455);
}
{
obj_t new_964;
new_964 = create_struct(symbol1300___rgc_tree, ((long)3));
STRUCT_SET(new_964, ((long)2), BTRUE);
STRUCT_SET(new_964, ((long)1), lastpos_455);
STRUCT_SET(new_964, ((long)0), firstpos_454);
return new_964;
}
}
}
}
}
}


/* arg1089 */obj_t arg1089___rgc_tree(obj_t env_1122, obj_t i_1124)
{
{
obj_t firstpos_1123;
firstpos_1123 = PROCEDURE_REF(env_1122, ((long)0));
{
obj_t i_457;
i_457 = i_1124;
{
obj_t arg1108_958;
{
obj_t vector_959;
vector_959 = _followpos__147___rgc_tree;
{
long aux_1423;
aux_1423 = (long)CINT(i_457);
arg1108_958 = VECTOR_REF(vector_959, aux_1423);
}
}
return rgcset_or__64___rgc_set(arg1108_958, firstpos_1123);
}
}
}
}


/* submatch->node */obj_t submatch__node_185___rgc_tree(obj_t expr_26)
{
if(PAIRP(expr_26)){
obj_t cdr_111_186_467;
cdr_111_186_467 = CDR(expr_26);
if(PAIRP(cdr_111_186_467)){
obj_t cdr_116_15_469;
cdr_116_15_469 = CDR(cdr_111_186_467);
if(PAIRP(cdr_116_15_469)){
bool_t test_1435;
{
obj_t aux_1436;
aux_1436 = CDR(cdr_116_15_469);
test_1435 = (aux_1436==BNIL);
}
if(test_1435){
obj_t arg1095_472;
obj_t arg1096_473;
arg1095_472 = CAR(expr_26);
arg1096_473 = CAR(cdr_111_186_467);
{
obj_t node_996;
node_996 = tree__node_162___rgc_tree(CAR(cdr_116_15_469));
{
obj_t firstpos_997;
firstpos_997 = STRUCT_REF(node_996, ((long)0));
{
obj_t lastpos_998;
lastpos_998 = STRUCT_REF(node_996, ((long)1));
{
obj_t nullable__184_999;
nullable__184_999 = STRUCT_REF(node_996, ((long)2));
{
{
obj_t arg1100_1126;
arg1100_1126 = make_fx_procedure(arg1100___rgc_tree, ((long)1), ((long)3));
PROCEDURE_SET(arg1100_1126, ((long)0), nullable__184_999);
PROCEDURE_SET(arg1100_1126, ((long)1), arg1095_472);
PROCEDURE_SET(arg1100_1126, ((long)2), arg1096_473);
for_each_rgcset_171___rgc_set(arg1100_1126, firstpos_997);
}
{
obj_t arg1102_1125;
arg1102_1125 = make_fx_procedure(arg1102___rgc_tree, ((long)1), ((long)2));
PROCEDURE_SET(arg1102_1125, ((long)0), arg1095_472);
PROCEDURE_SET(arg1102_1125, ((long)1), arg1096_473);
for_each_rgcset_171___rgc_set(arg1102_1125, lastpos_998);
}
return node_996;
}
}
}
}
}
}
 else {
FAILURE(BFALSE,string1306___rgc_tree,expr_26);}
}
 else {
FAILURE(BFALSE,string1306___rgc_tree,expr_26);}
}
 else {
FAILURE(BFALSE,string1306___rgc_tree,expr_26);}
}
 else {
FAILURE(BFALSE,string1306___rgc_tree,expr_26);}
}


/* arg1102 */obj_t arg1102___rgc_tree(obj_t env_1127, obj_t i_1130)
{
{
obj_t rule_1128;
obj_t submatch_1129;
rule_1128 = PROCEDURE_REF(env_1127, ((long)0));
submatch_1129 = PROCEDURE_REF(env_1127, ((long)1));
{
obj_t i_1003;
i_1003 = i_1130;
return submatch_stop_add__97___rgc_tree(i_1003, rule_1128, submatch_1129);
}
}
}


/* arg1100 */obj_t arg1100___rgc_tree(obj_t env_1131, obj_t i_1135)
{
{
obj_t nullable__184_1132;
obj_t rule_1133;
obj_t submatch_1134;
nullable__184_1132 = PROCEDURE_REF(env_1131, ((long)0));
rule_1133 = PROCEDURE_REF(env_1131, ((long)1));
submatch_1134 = PROCEDURE_REF(env_1131, ((long)2));
{
obj_t i_1001;
i_1001 = i_1135;
return submatch_start_add__59___rgc_tree(i_1001, nullable__184_1132, rule_1133, submatch_1134);
}
}
}


/* init-followpos! */obj_t init_followpos__99___rgc_tree()
{
{
obj_t followpos_492;
{
long aux_1466;
aux_1466 = (long)CINT(_position_number__58___rgc_tree);
followpos_492 = make_vector(aux_1466, BUNSPEC);
}
{
long i_493;
i_493 = ((long)0);
loop_494:
{
bool_t test1104_495;
{
long n1_1055;
n1_1055 = (long)CINT(_position_number__58___rgc_tree);
test1104_495 = (n1_1055==i_493);
}
if(test1104_495){
return (_followpos__147___rgc_tree = followpos_492,
BUNSPEC);
}
 else {
{
obj_t arg1105_496;
arg1105_496 = make_rgcset_69___rgc_set(CINT(_position_number__58___rgc_tree));
VECTOR_SET(followpos_492, i_493, arg1105_496);
}
{
long i_1475;
i_1475 = (i_493+((long)1));
i_493 = i_1475;
goto loop_494;
}
}
}
}
}
}


/* submatch-start-add! */obj_t submatch_start_add__59___rgc_tree(obj_t position_30, obj_t nullable__184_31, obj_t match_32, obj_t submatch_33)
{
{
obj_t cell_500;
{
obj_t vector_1065;
vector_1065 = _submatches__49___rgc_tree;
{
long aux_1477;
aux_1477 = (long)CINT(position_30);
cell_500 = VECTOR_REF(vector_1065, aux_1477);
}
}
if(PAIRP(cell_500)){
obj_t arg1110_502;
{
obj_t arg1111_503;
obj_t arg1112_504;
{
obj_t list1113_505;
{
obj_t arg1114_506;
{
obj_t arg1115_507;
arg1115_507 = MAKE_PAIR(submatch_33, BNIL);
arg1114_506 = MAKE_PAIR(match_32, arg1115_507);
}
list1113_505 = MAKE_PAIR(nullable__184_31, arg1114_506);
}
arg1111_503 = list1113_505;
}
arg1112_504 = CAR(cell_500);
arg1110_502 = MAKE_PAIR(arg1111_503, arg1112_504);
}
return SET_CAR(cell_500, arg1110_502);
}
 else {
obj_t arg1117_509;
{
obj_t arg1118_510;
{
obj_t arg1120_512;
{
obj_t list1123_515;
{
obj_t arg1124_516;
{
obj_t arg1125_517;
arg1125_517 = MAKE_PAIR(submatch_33, BNIL);
arg1124_516 = MAKE_PAIR(match_32, arg1125_517);
}
list1123_515 = MAKE_PAIR(nullable__184_31, arg1124_516);
}
arg1120_512 = list1123_515;
}
{
obj_t list1121_513;
list1121_513 = MAKE_PAIR(arg1120_512, BNIL);
arg1118_510 = list1121_513;
}
}
arg1117_509 = MAKE_PAIR(arg1118_510, BNIL);
}
{
obj_t vector_1078;
vector_1078 = _submatches__49___rgc_tree;
{
long aux_1493;
aux_1493 = (long)CINT(position_30);
return VECTOR_SET(vector_1078, aux_1493, arg1117_509);
}
}
}
}
}


/* submatch-stop-add! */obj_t submatch_stop_add__97___rgc_tree(obj_t position_34, obj_t match_35, obj_t submatch_36)
{
{
obj_t cell_519;
{
obj_t vector_1081;
vector_1081 = _submatches__49___rgc_tree;
{
long aux_1496;
aux_1496 = (long)CINT(position_34);
cell_519 = VECTOR_REF(vector_1081, aux_1496);
}
}
if(PAIRP(cell_519)){
obj_t arg1128_521;
{
obj_t arg1129_522;
obj_t arg1130_523;
arg1129_522 = MAKE_PAIR(match_35, submatch_36);
arg1130_523 = CDR(cell_519);
arg1128_521 = MAKE_PAIR(arg1129_522, arg1130_523);
}
return SET_CDR(cell_519, arg1128_521);
}
 else {
obj_t arg1131_524;
{
obj_t arg1133_526;
{
obj_t arg1134_527;
arg1134_527 = MAKE_PAIR(match_35, submatch_36);
{
obj_t list1135_528;
list1135_528 = MAKE_PAIR(arg1134_527, BNIL);
arg1133_526 = list1135_528;
}
}
arg1131_524 = MAKE_PAIR(BNIL, arg1133_526);
}
{
obj_t vector_1096;
vector_1096 = _submatches__49___rgc_tree;
{
long aux_1508;
aux_1508 = (long)CINT(position_34);
return VECTOR_SET(vector_1096, aux_1508, arg1131_524);
}
}
}
}
}


/* reset-tree! */obj_t reset_tree__130___rgc_tree()
{
_followpos__147___rgc_tree = BUNSPEC;
_positions__152___rgc_tree = BUNSPEC;
_submatches__49___rgc_tree = BUNSPEC;
return (_position_number__58___rgc_tree = BUNSPEC,
BUNSPEC);
}


/* _reset-tree! */obj_t _reset_tree__102___rgc_tree(obj_t env_1136)
{
return reset_tree__130___rgc_tree();
}


/* print-followpos */obj_t print_followpos_61___rgc_tree(obj_t fp_37)
{
{
obj_t list1137_530;
list1137_530 = MAKE_PAIR(string1310___rgc_tree, BNIL);
print___r4_output_6_10_3(list1137_530);
}
{
obj_t list1143_535;
{
obj_t arg1144_536;
{
obj_t aux_1514;
{
long aux_1515;
aux_1515 = VECTOR_LENGTH(fp_37);
aux_1514 = BINT(aux_1515);
}
arg1144_536 = MAKE_PAIR(aux_1514, BNIL);
}
list1143_535 = MAKE_PAIR(string1311___rgc_tree, arg1144_536);
}
print___r4_output_6_10_3(list1143_535);
}
list1312___rgc_tree;
{
obj_t list1146_538;
list1146_538 = MAKE_PAIR(string1343___rgc_tree, BNIL);
return print___r4_output_6_10_3(list1146_538);
}
}


/* _print-followpos */obj_t _print_followpos_153___rgc_tree(obj_t env_1137, obj_t fp_1138)
{
return print_followpos_61___rgc_tree(fp_1138);
}


/* print-node */obj_t print_node_135___rgc_tree(obj_t node_38)
{
return symbol1344___rgc_tree;
}


/* _print-node */obj_t _print_node_29___rgc_tree(obj_t env_1139, obj_t node_1140)
{
return symbol1344___rgc_tree;
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc_tree()
{
module_initialization_70___rgc_set(((long)0), "__RGC_TREE");
module_initialization_70___rgc_config(((long)0), "__RGC_TREE");
return module_initialization_70___error(((long)0), "__RGC_TREE");
}

