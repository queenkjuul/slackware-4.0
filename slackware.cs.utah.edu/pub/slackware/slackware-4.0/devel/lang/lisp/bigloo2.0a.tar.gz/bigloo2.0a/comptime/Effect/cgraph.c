/*===========================================================================*/
/*   (Effect/cgraph.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct local_from_91
  {
     obj_t from;
  }
             *local_from_91_t;

typedef struct global_from_205
  {
     obj_t from;
  }
               *global_from_205_t;


static obj_t mark_side_effect__61_effect_cgraph(variable_t);
static obj_t _save_call_1888_182_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t local_from_user__set__131_effect_cgraph(local_t, bool_t);
static obj_t _make_local_from1861_153_effect_cgraph(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t local_from_from_set__181_effect_cgraph(local_from_91_t, obj_t);
static obj_t method_init_76_effect_cgraph();
extern obj_t make_box_202_ast_node;
static obj_t _local_from_type_set_1865_100_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t local_from_occurrence_set__59_effect_cgraph(local_t, long);
static obj_t _allocate_local_from_49_effect_cgraph(obj_t);
static obj_t _local_from_value_set_1867_144_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
static obj_t _object__struct1886_128___object(obj_t, obj_t);
extern obj_t global_from_from_set__167_effect_cgraph(global_from_205_t, obj_t);
extern long local_from_occurrence_155_effect_cgraph(local_t);
static obj_t _var_all__30_effect_cgraph = BUNSPEC;
extern obj_t global_from_value_set__85_effect_cgraph(global_t, value_t);
static obj_t _global_from_user_1855_130_effect_cgraph(obj_t, obj_t);
extern obj_t global_from_fast_alpha_93_effect_cgraph(global_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern global_from_205_t widening1003_global_from_212_effect_cgraph(obj_t);
static obj_t _save_call__default1535_53_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _global_from_fast_alpha1842_38_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_from_set_1859_194_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_user_1878_125_effect_cgraph(obj_t, obj_t);
extern obj_t local_from_access_186_effect_cgraph(local_t);
extern obj_t local_from_removable_243_effect_cgraph(local_t);
static obj_t call_graph__default1513_140_effect_cgraph(node_t, variable_t);
extern obj_t global_from_module_199_effect_cgraph(global_t);
static obj_t _local_from_from1881_110_effect_cgraph(obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern local_from_91_t widening1002_local_from_147_effect_cgraph(obj_t);
extern obj_t local_from_type_set__115_effect_cgraph(local_t, type_t);
static obj_t _global_from_library__set_1852_209_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t global_from_removable_194_effect_cgraph(global_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _global_from_evaluable__set_1850_200_effect_cgraph(obj_t, obj_t, obj_t);
static bool_t call_graph___13_effect_cgraph(obj_t, variable_t);
extern obj_t global_from_occurrence_set__12_effect_cgraph(global_t, long);
static obj_t _local_from_user__set_1877_219_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _get_var_all_236_effect_cgraph(obj_t);
extern obj_t module_initialization_70_effect_cgraph(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern bool_t local_from_user__236_effect_cgraph(local_t);
static obj_t _local_from_type1866_245_effect_cgraph(obj_t, obj_t);
extern local_t allocate_local_from_4_effect_cgraph();
extern obj_t global_from_type_set__45_effect_cgraph(global_t, type_t);
extern obj_t local_from_removable_set__109_effect_cgraph(local_t, obj_t);
static obj_t _global_from_import1849_41_effect_cgraph(obj_t, obj_t);
obj_t local_from_91_effect_cgraph = BUNSPEC;
extern obj_t local_from_value_set__238_effect_cgraph(local_t, value_t);
extern obj_t local_from_id_164_effect_cgraph(local_t);
extern obj_t local_from_fast_alpha_88_effect_cgraph(local_t);
static obj_t _var_side_effect__143_effect_cgraph = BUNSPEC;
extern obj_t get_var_all_239_effect_cgraph();
static obj_t _global_from_src_set_1857_203_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t global_from_name_15_effect_cgraph(global_t);
extern long class_num_218___object(obj_t);
static obj_t _allocate_global_from_157_effect_cgraph(obj_t);
extern value_t global_from_value_26_effect_cgraph(global_t);
extern global_from_205_t make_global_from_185_effect_cgraph(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, obj_t, obj_t, bool_t, bool_t, bool_t, obj_t, obj_t, obj_t);
static obj_t _local_from_occurrence1876_6_effect_cgraph(obj_t, obj_t);
static obj_t save_call__133_effect_cgraph(variable_t, variable_t);
extern obj_t local_from_name_set__39_effect_cgraph(local_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t _global_from_name_set_1833_50_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_from_set_1880_86_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _global_from_import_set_1848_45_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_effect_cgraph();
static obj_t _global_from_name1834_205_effect_cgraph(obj_t, obj_t);
extern obj_t global_from_from_91_effect_cgraph(global_from_205_t);
static obj_t object__struct_global_from_23_effect_cgraph(obj_t, obj_t);
static obj_t _struct_object__object1884_129___object(obj_t, obj_t, obj_t);
extern obj_t global_from_id_148_effect_cgraph(global_t);
extern bool_t global_from_library__57_effect_cgraph(global_t);
static obj_t _global_from_access1840_153_effect_cgraph(obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t cfun_ast_var;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t global_from_name_set__93_effect_cgraph(global_t, obj_t);
static obj_t _global_from_value1838_103_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_removable_set_1843_181_effect_cgraph(obj_t, obj_t, obj_t);
extern bool_t global_from__222_effect_cgraph(obj_t);
static obj_t struct_object__object_global_from_226_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t local_from_name_69_effect_cgraph(local_t);
extern local_from_91_t make_local_from_27_effect_cgraph(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, bool_t, long, obj_t);
extern obj_t app_ast_node;
static obj_t _local_from_value1868_234_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_occurrence_set_1845_87_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_key1879_52_effect_cgraph(obj_t, obj_t);
static obj_t library_modules_init_112_effect_cgraph();
extern obj_t global_from_evaluable__set__132_effect_cgraph(global_t, bool_t);
static obj_t _local_from_access_set_1869_42_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_removable_set_1873_126_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t fun_call_graph__231_effect_cgraph(variable_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _global_from_fast_alpha_set_1841_197_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_fast_alpha1872_68_effect_cgraph(obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _global_from_removable1844_59_effect_cgraph(obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_effect_cgraph();
static obj_t call_graph__81_effect_cgraph(node_t, variable_t);
static obj_t _global_from_access_set_1839_203_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t local_from_from_185_effect_cgraph(local_from_91_t);
extern obj_t global_from_import_set__85_effect_cgraph(global_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern global_t allocate_global_from_170_effect_cgraph();
static obj_t save_call__default1535_7_effect_cgraph(variable_t, variable_t);
extern obj_t sfun_ast_var;
static obj_t struct_object__object_local_from_22_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _global_from_value_set_1837_247_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _make_global_from1831_1_effect_cgraph(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t global_from_src_set__208_effect_cgraph(global_t, obj_t);
extern obj_t local_from_fast_alpha_set__165_effect_cgraph(local_t, obj_t);
static obj_t _local_from_name_set_1863_37_effect_cgraph(obj_t, obj_t, obj_t);
extern obj_t box_set__221_ast_node;
extern obj_t global_from_removable_set__176_effect_cgraph(global_t, obj_t);
static obj_t _call_graph__default1513_72_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_id1862_175_effect_cgraph(obj_t, obj_t);
extern obj_t local_ast_var;
static obj_t _get_var_side_effect_19_effect_cgraph(obj_t);
extern obj_t global_from_library__set__21_effect_cgraph(global_t, bool_t);
obj_t global_from_205_effect_cgraph = BUNSPEC;
static obj_t _global_from_pragma1856_196_effect_cgraph(obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t object__struct_local_from_176_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_module1847_32_effect_cgraph(obj_t, obj_t);
extern value_t local_from_value_53_effect_cgraph(local_t);
static obj_t _widening1002_local_from_112_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_type_set_1835_245_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _global_from_evaluable_1851_117_effect_cgraph(obj_t, obj_t);
static obj_t _local_from_name1864_209_effect_cgraph(obj_t, obj_t);
static obj_t _global_from__164_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_library_1853_46_effect_cgraph(obj_t, obj_t);
extern bool_t global_from_evaluable__174_effect_cgraph(global_t);
extern obj_t global_from_user__set__38_effect_cgraph(global_t, bool_t);
static obj_t object_init_111_effect_cgraph();
static obj_t _local_from_access1870_80_effect_cgraph(obj_t, obj_t);
static obj_t _call_graph_1887_168_effect_cgraph(obj_t, obj_t, obj_t);
extern type_t global_from_type_150_effect_cgraph(global_t);
static obj_t _fun_call_graph_1830_191_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_from1860_52_effect_cgraph(obj_t, obj_t);
static obj_t _global_from_user__set_1854_6_effect_cgraph(obj_t, obj_t, obj_t);
static obj_t _local_from_removable1874_56_effect_cgraph(obj_t, obj_t);
extern obj_t global_from_access_80_effect_cgraph(global_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t global_from_fast_alpha_set__42_effect_cgraph(global_t, obj_t);
extern obj_t read___reader(obj_t);
extern long global_from_occurrence_204_effect_cgraph(global_t);
static obj_t _local_from__225_effect_cgraph(obj_t, obj_t);
extern obj_t global_from_src_107_effect_cgraph(global_t);
static obj_t _global_from_src1858_242_effect_cgraph(obj_t, obj_t);
extern obj_t local_from_access_set__145_effect_cgraph(local_t, obj_t);
extern obj_t global_from_access_set__164_effect_cgraph(global_t, obj_t);
extern obj_t global_from_pragma_13_effect_cgraph(global_t);
extern bool_t global_from_user__144_effect_cgraph(global_t);
extern obj_t object__struct_50___object(object_t);
static obj_t require_initialization_114_effect_cgraph = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t _local_from_occurrence_set_1875_33_effect_cgraph(obj_t, obj_t, obj_t);
extern type_t local_from_type_22_effect_cgraph(local_t);
static obj_t _global_from_occurrence1846_8_effect_cgraph(obj_t, obj_t);
extern obj_t get_var_side_effect_0_effect_cgraph();
static obj_t _global_from_type1836_178_effect_cgraph(obj_t, obj_t);
static obj_t _widening1003_global_from_125_effect_cgraph(obj_t, obj_t);
extern bool_t local_from__82_effect_cgraph(obj_t);
static obj_t cnst_init_137_effect_cgraph();
static obj_t _global_from_id1832_220_effect_cgraph(obj_t, obj_t);
static obj_t _local_from_fast_alpha_set_1871_156_effect_cgraph(obj_t, obj_t, obj_t);
extern long local_from_key_203_effect_cgraph(local_t);
extern obj_t global_from_import_26_effect_cgraph(global_t);
static obj_t __cnst[6];

DEFINE_EXPORT_PROCEDURE(global_from_from_set__env_187_effect_cgraph, _global_from_from_set_1859_194_effect_cgraph1900, _global_from_from_set_1859_194_effect_cgraph, 0L, 2);
DEFINE_STATIC_PROCEDURE(call_graph__default1513_env_143_effect_cgraph, _call_graph__default1513_72_effect_cgraph1901, _call_graph__default1513_72_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_occurrence_set__env_74_effect_cgraph, _global_from_occurrence_set_1845_87_effect_cgraph1902, _global_from_occurrence_set_1845_87_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(widening1003_global_from_env_145_effect_cgraph, _widening1003_global_from_125_effect_cgraph1903, _widening1003_global_from_125_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_fast_alpha_set__env_73_effect_cgraph, _global_from_fast_alpha_set_1841_197_effect_cgraph1904, _global_from_fast_alpha_set_1841_197_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_name_env_27_effect_cgraph, _global_from_name1834_205_effect_cgraph1905, _global_from_name1834_205_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_occurrence_set__env_119_effect_cgraph, _local_from_occurrence_set_1875_33_effect_cgraph1906, _local_from_occurrence_set_1875_33_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_user__set__env_91_effect_cgraph, _local_from_user__set_1877_219_effect_cgraph1907, _local_from_user__set_1877_219_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_id_env_208_effect_cgraph, _local_from_id1862_175_effect_cgraph1908, _local_from_id1862_175_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_fast_alpha_set__env_35_effect_cgraph, _local_from_fast_alpha_set_1871_156_effect_cgraph1909, _local_from_fast_alpha_set_1871_156_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_value_env_92_effect_cgraph, _local_from_value1868_234_effect_cgraph1910, _local_from_value1868_234_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_access_set__env_1_effect_cgraph, _local_from_access_set_1869_42_effect_cgraph1911, _local_from_access_set_1869_42_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_import_env_252_effect_cgraph, _global_from_import1849_41_effect_cgraph1912, _global_from_import1849_41_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_name_set__env_230_effect_cgraph, _local_from_name_set_1863_37_effect_cgraph1913, _local_from_name_set_1863_37_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_import_set__env_171_effect_cgraph, _global_from_import_set_1848_45_effect_cgraph1914, _global_from_import_set_1848_45_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_removable_set__env_45_effect_cgraph, _local_from_removable_set_1873_126_effect_cgraph1915, _local_from_removable_set_1873_126_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_occurrence_env_228_effect_cgraph, _local_from_occurrence1876_6_effect_cgraph1916, _local_from_occurrence1876_6_effect_cgraph, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1892_effect_cgraph, struct_object__object_local_from_22_effect_cgraph1917, struct_object__object_local_from_22_effect_cgraph, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1891_effect_cgraph, object__struct_local_from_176_effect_cgraph1918, object__struct_local_from_176_effect_cgraph, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1889_effect_cgraph, object__struct_global_from_23_effect_cgraph1919, object__struct_global_from_23_effect_cgraph, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1890_effect_cgraph, struct_object__object_global_from_226_effect_cgraph1920, struct_object__object_global_from_226_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_name_set__env_209_effect_cgraph, _global_from_name_set_1833_50_effect_cgraph1921, _global_from_name_set_1833_50_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_value_env_252_effect_cgraph, _global_from_value1838_103_effect_cgraph1922, _global_from_value1838_103_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_global_from_env_203_effect_cgraph, _make_global_from1831_1_effect_cgraph1923, _make_global_from1831_1_effect_cgraph, 0L, 16);
DEFINE_EXPORT_PROCEDURE(global_from_value_set__env_171_effect_cgraph, _global_from_value_set_1837_247_effect_cgraph1924, _global_from_value_set_1837_247_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from__env_97_effect_cgraph, _global_from__164_effect_cgraph1925, _global_from__164_effect_cgraph, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(global_from_library__env_240_effect_cgraph, _global_from_library_1853_46_effect_cgraph1926, _global_from_library_1853_46_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_access_env_134_effect_cgraph, _global_from_access1840_153_effect_cgraph1927, _global_from_access1840_153_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_key_env_223_effect_cgraph, _local_from_key1879_52_effect_cgraph1928, _local_from_key1879_52_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_access_set__env_208_effect_cgraph, _global_from_access_set_1839_203_effect_cgraph1929, _global_from_access_set_1839_203_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_removable_env_20_effect_cgraph, _local_from_removable1874_56_effect_cgraph1930, _local_from_removable1874_56_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_name_env_84_effect_cgraph, _local_from_name1864_209_effect_cgraph1931, _local_from_name1864_209_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_evaluable__env_156_effect_cgraph, _global_from_evaluable_1851_117_effect_cgraph1932, _global_from_evaluable_1851_117_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_fast_alpha_env_168_effect_cgraph, _local_from_fast_alpha1872_68_effect_cgraph1933, _local_from_fast_alpha1872_68_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_removable_env_246_effect_cgraph, _global_from_removable1844_59_effect_cgraph1934, _global_from_removable1844_59_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fun_call_graph__env_198_effect_cgraph, _fun_call_graph_1830_191_effect_cgraph1935, _fun_call_graph_1830_191_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from__env_106_effect_cgraph, _local_from__225_effect_cgraph1936, _local_from__225_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_from_env_87_effect_cgraph, _global_from_from1860_52_effect_cgraph1937, _global_from_from1860_52_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_user__set__env_162_effect_cgraph, _global_from_user__set_1854_6_effect_cgraph1938, _global_from_user__set_1854_6_effect_cgraph, 0L, 2);
DEFINE_STATIC_PROCEDURE(save_call__default1535_env_183_effect_cgraph, _save_call__default1535_53_effect_cgraph1939, _save_call__default1535_53_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_src_env_23_effect_cgraph, _global_from_src1858_242_effect_cgraph1940, _global_from_src1858_242_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_access_env_196_effect_cgraph, _local_from_access1870_80_effect_cgraph1941, _local_from_access1870_80_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_type_set__env_172_effect_cgraph, _local_from_type_set_1865_100_effect_cgraph1942, _local_from_type_set_1865_100_effect_cgraph, 0L, 2);
DEFINE_STATIC_GENERIC(save_call__env_248_effect_cgraph, _save_call_1888_182_effect_cgraph1943, _save_call_1888_182_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_occurrence_env_236_effect_cgraph, _global_from_occurrence1846_8_effect_cgraph1944, _global_from_occurrence1846_8_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_type_set__env_125_effect_cgraph, _global_from_type_set_1835_245_effect_cgraph1945, _global_from_type_set_1835_245_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_pragma_env_34_effect_cgraph, _global_from_pragma1856_196_effect_cgraph1946, _global_from_pragma1856_196_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_type_env_9_effect_cgraph, _global_from_type1836_178_effect_cgraph1947, _global_from_type1836_178_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_module_env_206_effect_cgraph, _global_from_module1847_32_effect_cgraph1948, _global_from_module1847_32_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_local_from_env_64_effect_cgraph, _make_local_from1861_153_effect_cgraph1949, _make_local_from1861_153_effect_cgraph, 0L, 11);
DEFINE_EXPORT_PROCEDURE(global_from_removable_set__env_239_effect_cgraph, _global_from_removable_set_1843_181_effect_cgraph1950, _global_from_removable_set_1843_181_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_global_from_env_89_effect_cgraph, _allocate_global_from_157_effect_cgraph1951, _allocate_global_from_157_effect_cgraph, 0L, 0);
DEFINE_EXPORT_PROCEDURE(global_from_evaluable__set__env_104_effect_cgraph, _global_from_evaluable__set_1850_200_effect_cgraph1952, _global_from_evaluable__set_1850_200_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_fast_alpha_env_209_effect_cgraph, _global_from_fast_alpha1842_38_effect_cgraph1953, _global_from_fast_alpha1842_38_effect_cgraph, 0L, 1);
DEFINE_STRING(string1894_effect_cgraph, string1894_effect_cgraph1954, "SAVE-CALL!-DEFAULT1535 IMPORT DONE GLOBAL/FROM LOCAL/FROM NOTHING ", 66);
DEFINE_STRING(string1893_effect_cgraph, string1893_effect_cgraph1955, "No method for this object", 25);
DEFINE_EXPORT_PROCEDURE(local_from_user__env_94_effect_cgraph, _local_from_user_1878_125_effect_cgraph1956, _local_from_user_1878_125_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_from_from_env_203_effect_cgraph, _local_from_from1881_110_effect_cgraph1957, _local_from_from1881_110_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_local_from_env_235_effect_cgraph, _allocate_local_from_49_effect_cgraph1958, _allocate_local_from_49_effect_cgraph, 0L, 0);
DEFINE_EXPORT_PROCEDURE(widening1002_local_from_env_177_effect_cgraph, _widening1002_local_from_112_effect_cgraph1959, _widening1002_local_from_112_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_id_env_82_effect_cgraph, _global_from_id1832_220_effect_cgraph1960, _global_from_id1832_220_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(get_var_all_env_251_effect_cgraph, _get_var_all_236_effect_cgraph1961, _get_var_all_236_effect_cgraph, 0L, 0);
DEFINE_EXPORT_PROCEDURE(global_from_user__env_243_effect_cgraph, _global_from_user_1855_130_effect_cgraph1962, _global_from_user_1855_130_effect_cgraph, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_from_src_set__env_54_effect_cgraph, _global_from_src_set_1857_203_effect_cgraph1963, _global_from_src_set_1857_203_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_from_library__set__env_123_effect_cgraph, _global_from_library__set_1852_209_effect_cgraph1964, _global_from_library__set_1852_209_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_value_set__env_75_effect_cgraph, _local_from_value_set_1867_144_effect_cgraph1965, _local_from_value_set_1867_144_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_from_type_env_98_effect_cgraph, _local_from_type1866_245_effect_cgraph1966, _local_from_type1866_245_effect_cgraph, 0L, 1);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(local_from_from_set__env_60_effect_cgraph, _local_from_from_set_1880_86_effect_cgraph1967, _local_from_from_set_1880_86_effect_cgraph, 0L, 2);
DEFINE_STATIC_GENERIC(call_graph__env_226_effect_cgraph, _call_graph_1887_168_effect_cgraph1968, _call_graph_1887_168_effect_cgraph, 0L, 2);
DEFINE_EXPORT_PROCEDURE(get_var_side_effect_env_93_effect_cgraph, _get_var_side_effect_19_effect_cgraph1969, _get_var_side_effect_19_effect_cgraph, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_effect_cgraph(long checksum_1984, char *from_1985)
{
   if (CBOOL(require_initialization_114_effect_cgraph))
     {
	require_initialization_114_effect_cgraph = BBOOL(((bool_t) 0));
	library_modules_init_112_effect_cgraph();
	cnst_init_137_effect_cgraph();
	imported_modules_init_94_effect_cgraph();
	object_init_111_effect_cgraph();
	method_init_76_effect_cgraph();
	toplevel_init_63_effect_cgraph();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_effect_cgraph()
{
   module_initialization_70___object(((long) 0), "EFFECT_CGRAPH");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EFFECT_CGRAPH");
   module_initialization_70___reader(((long) 0), "EFFECT_CGRAPH");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_effect_cgraph()
{
   {
      obj_t cnst_port_138_1976;
      cnst_port_138_1976 = open_input_string(string1894_effect_cgraph);
      {
	 long i_1977;
	 i_1977 = ((long) 5);
       loop_1978:
	 {
	    bool_t test1895_1979;
	    test1895_1979 = (i_1977 == ((long) -1));
	    if (test1895_1979)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1896_1980;
		    {
		       obj_t list1897_1981;
		       {
			  obj_t arg1898_1982;
			  arg1898_1982 = BNIL;
			  list1897_1981 = MAKE_PAIR(cnst_port_138_1976, arg1898_1982);
		       }
		       arg1896_1980 = read___reader(list1897_1981);
		    }
		    CNST_TABLE_SET(i_1977, arg1896_1980);
		 }
		 {
		    int aux_1983;
		    {
		       long aux_2004;
		       aux_2004 = (i_1977 - ((long) 1));
		       aux_1983 = (int) (aux_2004);
		    }
		    {
		       long i_2007;
		       i_2007 = (long) (aux_1983);
		       i_1977 = i_2007;
		       goto loop_1978;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_effect_cgraph()
{
   _var_side_effect__143_effect_cgraph = BNIL;
   return (_var_all__30_effect_cgraph = BNIL,
      BUNSPEC);
}


/* fun-call-graph! */ obj_t 
fun_call_graph__231_effect_cgraph(variable_t variable_1)
{
   {
      obj_t obj2_1446;
      obj2_1446 = _var_all__30_effect_cgraph;
      {
	 obj_t aux_2009;
	 aux_2009 = (obj_t) (variable_1);
	 _var_all__30_effect_cgraph = MAKE_PAIR(aux_2009, obj2_1446);
      }
   }
   {
      node_t aux_2012;
      {
	 obj_t aux_2013;
	 {
	    sfun_t obj_1448;
	    {
	       value_t aux_2014;
	       aux_2014 = (((variable_t) CREF(variable_1))->value);
	       obj_1448 = (sfun_t) (aux_2014);
	    }
	    aux_2013 = (((sfun_t) CREF(obj_1448))->body);
	 }
	 aux_2012 = (node_t) (aux_2013);
      }
      return call_graph__81_effect_cgraph(aux_2012, variable_1);
   }
}


/* _fun-call-graph!1830 */ obj_t 
_fun_call_graph_1830_191_effect_cgraph(obj_t env_1782, obj_t variable_1783)
{
   return fun_call_graph__231_effect_cgraph((variable_t) (variable_1783));
}


/* call-graph*! */ bool_t 
call_graph___13_effect_cgraph(obj_t node__221_40, variable_t owner_41)
{
   {
      obj_t l1505_856;
      l1505_856 = node__221_40;
    lname1506_857:
      if (PAIRP(l1505_856))
	{
	   {
	      node_t aux_2024;
	      {
		 obj_t aux_2025;
		 aux_2025 = CAR(l1505_856);
		 aux_2024 = (node_t) (aux_2025);
	      }
	      call_graph__81_effect_cgraph(aux_2024, owner_41);
	   }
	   {
	      obj_t l1505_2029;
	      l1505_2029 = CDR(l1505_856);
	      l1505_856 = l1505_2029;
	      goto lname1506_857;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* get-var/side-effect */ obj_t 
get_var_side_effect_0_effect_cgraph()
{
   return _var_side_effect__143_effect_cgraph;
}


/* _get-var/side-effect */ obj_t 
_get_var_side_effect_19_effect_cgraph(obj_t env_1784)
{
   return get_var_side_effect_0_effect_cgraph();
}


/* get-var/all */ obj_t 
get_var_all_239_effect_cgraph()
{
   return _var_all__30_effect_cgraph;
}


/* _get-var/all */ obj_t 
_get_var_all_236_effect_cgraph(obj_t env_1785)
{
   return get_var_all_239_effect_cgraph();
}


/* mark-side-effect! */ obj_t 
mark_side_effect__61_effect_cgraph(variable_t v_54)
{
   {
      value_t fun_861;
      fun_861 = (((variable_t) CREF(v_54))->value);
      {
	 bool_t test_2034;
	 {
	    fun_t obj_1453;
	    obj_1453 = (fun_t) (fun_861);
	    {
	       obj_t aux_2036;
	       aux_2036 = (((fun_t) CREF(obj_1453))->side_effect__165);
	       test_2034 = CBOOL(aux_2036);
	    }
	 }
	 if (test_2034)
	   {
	      bool_t test1554_863;
	      {
		 obj_t aux_2039;
		 aux_2039 = memq___r4_pairs_and_lists_6_3((obj_t) (v_54), _var_side_effect__143_effect_cgraph);
		 test1554_863 = CBOOL(aux_2039);
	      }
	      if (test1554_863)
		{
		   return CNST_TABLE_REF(((long) 0));
		}
	      else
		{
		   {
		      obj_t obj2_1455;
		      obj2_1455 = _var_side_effect__143_effect_cgraph;
		      {
			 obj_t aux_2045;
			 aux_2045 = (obj_t) (v_54);
			 return (_var_side_effect__143_effect_cgraph = MAKE_PAIR(aux_2045, obj2_1455),
			    BUNSPEC);
		      }
		   }
		}
	   }
	 else
	   {
	      {
		 obj_t obj2_1457;
		 obj2_1457 = _var_side_effect__143_effect_cgraph;
		 {
		    obj_t aux_2048;
		    aux_2048 = (obj_t) (v_54);
		    _var_side_effect__143_effect_cgraph = MAKE_PAIR(aux_2048, obj2_1457);
		 }
	      }
	      {
		 fun_t obj_1458;
		 obj_t val1110_1459;
		 obj_1458 = (fun_t) (fun_861);
		 val1110_1459 = BTRUE;
		 return ((((fun_t) CREF(obj_1458))->side_effect__165) = ((obj_t) val1110_1459), BUNSPEC);
	      }
	   }
      }
   }
}


/* object-init */ obj_t 
object_init_111_effect_cgraph()
{
   {
      obj_t arg1556_865;
      arg1556_865 = local_ast_var;
      local_from_91_effect_cgraph = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1556_865, allocate_local_from_env_235_effect_cgraph, ((long) 28402), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1560_869;
      arg1560_869 = global_ast_var;
      global_from_205_effect_cgraph = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1560_869, allocate_global_from_env_89_effect_cgraph, ((long) 53296), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-global/from */ global_t 
allocate_global_from_170_effect_cgraph()
{
   {
      global_t new1478_872;
      new1478_872 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
      {
	 long arg1563_873;
	 arg1563_873 = class_num_218___object(global_from_205_effect_cgraph);
	 {
	    obj_t obj_1460;
	    obj_1460 = (obj_t) (new1478_872);
	    (((obj_t) CREF(obj_1460))->header = MAKE_HEADER(arg1563_873, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2061;
	 aux_2061 = (object_t) (new1478_872);
	 OBJECT_WIDENING_SET(aux_2061, BFALSE);
      }
      return new1478_872;
   }
}


/* _allocate-global/from */ obj_t 
_allocate_global_from_157_effect_cgraph(obj_t env_1787)
{
   {
      global_t aux_2064;
      aux_2064 = allocate_global_from_170_effect_cgraph();
      return (obj_t) (aux_2064);
   }
}


/* global/from? */ bool_t 
global_from__222_effect_cgraph(obj_t obj_58)
{
   return is_a__118___object(obj_58, global_from_205_effect_cgraph);
}


/* _global/from? */ obj_t 
_global_from__164_effect_cgraph(obj_t env_1788, obj_t obj_1789)
{
   {
      bool_t aux_2068;
      aux_2068 = global_from__222_effect_cgraph(obj_1789);
      return BBOOL(aux_2068);
   }
}


/* widening1003-global/from */ global_from_205_t 
widening1003_global_from_212_effect_cgraph(obj_t from_59)
{
   {
      global_from_205_t new1460_1462;
      new1460_1462 = ((global_from_205_t) BREF(GC_MALLOC(sizeof(struct global_from_205))));
      ((((global_from_205_t) CREF(new1460_1462))->from) = ((obj_t) from_59), BUNSPEC);
      return new1460_1462;
   }
}


/* _widening1003-global/from */ obj_t 
_widening1003_global_from_125_effect_cgraph(obj_t env_1790, obj_t from_1791)
{
   {
      global_from_205_t aux_2073;
      aux_2073 = widening1003_global_from_212_effect_cgraph(from_1791);
      return (obj_t) (aux_2073);
   }
}


/* make-global/from */ global_from_205_t 
make_global_from_185_effect_cgraph(obj_t id_60, obj_t name_61, type_t type_62, value_t value_63, obj_t access_64, obj_t fast_alpha_7_65, obj_t removable_66, long occurrence_67, obj_t module_68, obj_t import_69, bool_t evaluable__248_70, bool_t library__255_71, bool_t user__32_72, obj_t pragma_73, obj_t src_74, obj_t from_75)
{
   {
      global_t aux1463_1464;
      {
	 global_t res1820_1502;
	 {
	    global_t new1051_1483;
	    new1051_1483 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
	    {
	       long arg1658_1484;
	       arg1658_1484 = class_num_218___object(global_ast_var);
	       {
		  obj_t obj_1500;
		  obj_1500 = (obj_t) (new1051_1483);
		  (((obj_t) CREF(obj_1500))->header = MAKE_HEADER(arg1658_1484, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2080;
	       aux_2080 = (object_t) (new1051_1483);
	       OBJECT_WIDENING_SET(aux_2080, BFALSE);
	    }
	    ((((global_t) CREF(new1051_1483))->id) = ((obj_t) id_60), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->name) = ((obj_t) name_61), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->type) = ((type_t) type_62), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->value) = ((value_t) value_63), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->access) = ((obj_t) access_64), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->fast_alpha_7) = ((obj_t) fast_alpha_7_65), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->removable) = ((obj_t) removable_66), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->occurrence) = ((long) occurrence_67), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->module) = ((obj_t) module_68), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->import) = ((obj_t) import_69), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->evaluable__248) = ((bool_t) evaluable__248_70), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->library__255) = ((bool_t) library__255_71), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->user__32) = ((bool_t) user__32_72), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->pragma) = ((obj_t) pragma_73), BUNSPEC);
	    ((((global_t) CREF(new1051_1483))->src) = ((obj_t) src_74), BUNSPEC);
	    res1820_1502 = new1051_1483;
	 }
	 aux1463_1464 = res1820_1502;
      }
      {
	 global_from_205_t new1464_1465;
	 new1464_1465 = ((global_from_205_t) (aux1463_1464));
	 {
	    long arg1564_1466;
	    arg1564_1466 = class_num_218___object(global_from_205_effect_cgraph);
	    {
	       obj_t obj_1503;
	       obj_1503 = (obj_t) (new1464_1465);
	       (((obj_t) CREF(obj_1503))->header = MAKE_HEADER(arg1564_1466, 0), BUNSPEC);
	    }
	 }
	 {
	    global_from_205_t arg1565_1467;
	    {
	       global_from_205_t res1821_1508;
	       {
		  global_from_205_t new1460_1506;
		  new1460_1506 = ((global_from_205_t) BREF(GC_MALLOC(sizeof(struct global_from_205))));
		  ((((global_from_205_t) CREF(new1460_1506))->from) = ((obj_t) from_75), BUNSPEC);
		  res1821_1508 = new1460_1506;
	       }
	       arg1565_1467 = res1821_1508;
	    }
	    {
	       obj_t aux_2106;
	       object_t aux_2104;
	       aux_2106 = (obj_t) (arg1565_1467);
	       aux_2104 = (object_t) (new1464_1465);
	       OBJECT_WIDENING_SET(aux_2104, aux_2106);
	    }
	 }
	 return new1464_1465;
      }
   }
}


/* _make-global/from1831 */ obj_t 
_make_global_from1831_1_effect_cgraph(obj_t env_1792, obj_t id_1793, obj_t name_1794, obj_t type_1795, obj_t value_1796, obj_t access_1797, obj_t fast_alpha_7_1798, obj_t removable_1799, obj_t occurrence_1800, obj_t module_1801, obj_t import_1802, obj_t evaluable__248_1803, obj_t library__255_1804, obj_t user__32_1805, obj_t pragma_1806, obj_t src_1807, obj_t from_1808)
{
   {
      global_from_205_t aux_2109;
      aux_2109 = make_global_from_185_effect_cgraph(id_1793, name_1794, (type_t) (type_1795), (value_t) (value_1796), access_1797, fast_alpha_7_1798, removable_1799, (long) CINT(occurrence_1800), module_1801, import_1802, CBOOL(evaluable__248_1803), CBOOL(library__255_1804), CBOOL(user__32_1805), pragma_1806, src_1807, from_1808);
      return (obj_t) (aux_2109);
   }
}


/* global/from-id */ obj_t 
global_from_id_148_effect_cgraph(global_t obj_76)
{
   return (((global_t) CREF(obj_76))->id);
}


/* _global/from-id1832 */ obj_t 
_global_from_id1832_220_effect_cgraph(obj_t env_1809, obj_t obj_1810)
{
   return global_from_id_148_effect_cgraph((global_t) (obj_1810));
}


/* global/from-name-set! */ obj_t 
global_from_name_set__93_effect_cgraph(global_t obj_77, obj_t val1465_78)
{
   return ((((global_t) CREF(obj_77))->name) = ((obj_t) val1465_78), BUNSPEC);
}


/* _global/from-name-set!1833 */ obj_t 
_global_from_name_set_1833_50_effect_cgraph(obj_t env_1811, obj_t obj_1812, obj_t val1465_1813)
{
   return global_from_name_set__93_effect_cgraph((global_t) (obj_1812), val1465_1813);
}


/* global/from-name */ obj_t 
global_from_name_15_effect_cgraph(global_t obj_79)
{
   return (((global_t) CREF(obj_79))->name);
}


/* _global/from-name1834 */ obj_t 
_global_from_name1834_205_effect_cgraph(obj_t env_1814, obj_t obj_1815)
{
   return global_from_name_15_effect_cgraph((global_t) (obj_1815));
}


/* global/from-type-set! */ obj_t 
global_from_type_set__45_effect_cgraph(global_t obj_80, type_t val1466_81)
{
   return ((((global_t) CREF(obj_80))->type) = ((type_t) val1466_81), BUNSPEC);
}


/* _global/from-type-set!1835 */ obj_t 
_global_from_type_set_1835_245_effect_cgraph(obj_t env_1816, obj_t obj_1817, obj_t val1466_1818)
{
   return global_from_type_set__45_effect_cgraph((global_t) (obj_1817), (type_t) (val1466_1818));
}


/* global/from-type */ type_t 
global_from_type_150_effect_cgraph(global_t obj_82)
{
   return (((global_t) CREF(obj_82))->type);
}


/* _global/from-type1836 */ obj_t 
_global_from_type1836_178_effect_cgraph(obj_t env_1819, obj_t obj_1820)
{
   {
      type_t aux_2132;
      aux_2132 = global_from_type_150_effect_cgraph((global_t) (obj_1820));
      return (obj_t) (aux_2132);
   }
}


/* global/from-value-set! */ obj_t 
global_from_value_set__85_effect_cgraph(global_t obj_83, value_t val1467_84)
{
   return ((((global_t) CREF(obj_83))->value) = ((value_t) val1467_84), BUNSPEC);
}


/* _global/from-value-set!1837 */ obj_t 
_global_from_value_set_1837_247_effect_cgraph(obj_t env_1821, obj_t obj_1822, obj_t val1467_1823)
{
   return global_from_value_set__85_effect_cgraph((global_t) (obj_1822), (value_t) (val1467_1823));
}


/* global/from-value */ value_t 
global_from_value_26_effect_cgraph(global_t obj_85)
{
   return (((global_t) CREF(obj_85))->value);
}


/* _global/from-value1838 */ obj_t 
_global_from_value1838_103_effect_cgraph(obj_t env_1824, obj_t obj_1825)
{
   {
      value_t aux_2141;
      aux_2141 = global_from_value_26_effect_cgraph((global_t) (obj_1825));
      return (obj_t) (aux_2141);
   }
}


/* global/from-access-set! */ obj_t 
global_from_access_set__164_effect_cgraph(global_t obj_86, obj_t val1468_87)
{
   return ((((global_t) CREF(obj_86))->access) = ((obj_t) val1468_87), BUNSPEC);
}


/* _global/from-access-set!1839 */ obj_t 
_global_from_access_set_1839_203_effect_cgraph(obj_t env_1826, obj_t obj_1827, obj_t val1468_1828)
{
   return global_from_access_set__164_effect_cgraph((global_t) (obj_1827), val1468_1828);
}


/* global/from-access */ obj_t 
global_from_access_80_effect_cgraph(global_t obj_88)
{
   return (((global_t) CREF(obj_88))->access);
}


/* _global/from-access1840 */ obj_t 
_global_from_access1840_153_effect_cgraph(obj_t env_1829, obj_t obj_1830)
{
   return global_from_access_80_effect_cgraph((global_t) (obj_1830));
}


/* global/from-fast-alpha-set! */ obj_t 
global_from_fast_alpha_set__42_effect_cgraph(global_t obj_89, obj_t val1469_90)
{
   return ((((global_t) CREF(obj_89))->fast_alpha_7) = ((obj_t) val1469_90), BUNSPEC);
}


/* _global/from-fast-alpha-set!1841 */ obj_t 
_global_from_fast_alpha_set_1841_197_effect_cgraph(obj_t env_1831, obj_t obj_1832, obj_t val1469_1833)
{
   return global_from_fast_alpha_set__42_effect_cgraph((global_t) (obj_1832), val1469_1833);
}


/* global/from-fast-alpha */ obj_t 
global_from_fast_alpha_93_effect_cgraph(global_t obj_91)
{
   return (((global_t) CREF(obj_91))->fast_alpha_7);
}


/* _global/from-fast-alpha1842 */ obj_t 
_global_from_fast_alpha1842_38_effect_cgraph(obj_t env_1834, obj_t obj_1835)
{
   return global_from_fast_alpha_93_effect_cgraph((global_t) (obj_1835));
}


/* global/from-removable-set! */ obj_t 
global_from_removable_set__176_effect_cgraph(global_t obj_92, obj_t val1470_93)
{
   return ((((global_t) CREF(obj_92))->removable) = ((obj_t) val1470_93), BUNSPEC);
}


/* _global/from-removable-set!1843 */ obj_t 
_global_from_removable_set_1843_181_effect_cgraph(obj_t env_1836, obj_t obj_1837, obj_t val1470_1838)
{
   return global_from_removable_set__176_effect_cgraph((global_t) (obj_1837), val1470_1838);
}


/* global/from-removable */ obj_t 
global_from_removable_194_effect_cgraph(global_t obj_94)
{
   return (((global_t) CREF(obj_94))->removable);
}


/* _global/from-removable1844 */ obj_t 
_global_from_removable1844_59_effect_cgraph(obj_t env_1839, obj_t obj_1840)
{
   return global_from_removable_194_effect_cgraph((global_t) (obj_1840));
}


/* global/from-occurrence-set! */ obj_t 
global_from_occurrence_set__12_effect_cgraph(global_t obj_95, long val1471_96)
{
   return ((((global_t) CREF(obj_95))->occurrence) = ((long) val1471_96), BUNSPEC);
}


/* _global/from-occurrence-set!1845 */ obj_t 
_global_from_occurrence_set_1845_87_effect_cgraph(obj_t env_1841, obj_t obj_1842, obj_t val1471_1843)
{
   return global_from_occurrence_set__12_effect_cgraph((global_t) (obj_1842), (long) CINT(val1471_1843));
}


/* global/from-occurrence */ long 
global_from_occurrence_204_effect_cgraph(global_t obj_97)
{
   return (((global_t) CREF(obj_97))->occurrence);
}


/* _global/from-occurrence1846 */ obj_t 
_global_from_occurrence1846_8_effect_cgraph(obj_t env_1844, obj_t obj_1845)
{
   {
      long aux_2168;
      aux_2168 = global_from_occurrence_204_effect_cgraph((global_t) (obj_1845));
      return BINT(aux_2168);
   }
}


/* global/from-module */ obj_t 
global_from_module_199_effect_cgraph(global_t obj_98)
{
   return (((global_t) CREF(obj_98))->module);
}


/* _global/from-module1847 */ obj_t 
_global_from_module1847_32_effect_cgraph(obj_t env_1846, obj_t obj_1847)
{
   return global_from_module_199_effect_cgraph((global_t) (obj_1847));
}


/* global/from-import-set! */ obj_t 
global_from_import_set__85_effect_cgraph(global_t obj_99, obj_t val1472_100)
{
   return ((((global_t) CREF(obj_99))->import) = ((obj_t) val1472_100), BUNSPEC);
}


/* _global/from-import-set!1848 */ obj_t 
_global_from_import_set_1848_45_effect_cgraph(obj_t env_1848, obj_t obj_1849, obj_t val1472_1850)
{
   return global_from_import_set__85_effect_cgraph((global_t) (obj_1849), val1472_1850);
}


/* global/from-import */ obj_t 
global_from_import_26_effect_cgraph(global_t obj_101)
{
   return (((global_t) CREF(obj_101))->import);
}


/* _global/from-import1849 */ obj_t 
_global_from_import1849_41_effect_cgraph(obj_t env_1851, obj_t obj_1852)
{
   return global_from_import_26_effect_cgraph((global_t) (obj_1852));
}


/* global/from-evaluable?-set! */ obj_t 
global_from_evaluable__set__132_effect_cgraph(global_t obj_102, bool_t val1473_103)
{
   return ((((global_t) CREF(obj_102))->evaluable__248) = ((bool_t) val1473_103), BUNSPEC);
}


/* _global/from-evaluable?-set!1850 */ obj_t 
_global_from_evaluable__set_1850_200_effect_cgraph(obj_t env_1853, obj_t obj_1854, obj_t val1473_1855)
{
   return global_from_evaluable__set__132_effect_cgraph((global_t) (obj_1854), CBOOL(val1473_1855));
}


/* global/from-evaluable? */ bool_t 
global_from_evaluable__174_effect_cgraph(global_t obj_104)
{
   return (((global_t) CREF(obj_104))->evaluable__248);
}


/* _global/from-evaluable?1851 */ obj_t 
_global_from_evaluable_1851_117_effect_cgraph(obj_t env_1856, obj_t obj_1857)
{
   {
      bool_t aux_2186;
      aux_2186 = global_from_evaluable__174_effect_cgraph((global_t) (obj_1857));
      return BBOOL(aux_2186);
   }
}


/* global/from-library?-set! */ obj_t 
global_from_library__set__21_effect_cgraph(global_t obj_105, bool_t val1474_106)
{
   return ((((global_t) CREF(obj_105))->library__255) = ((bool_t) val1474_106), BUNSPEC);
}


/* _global/from-library?-set!1852 */ obj_t 
_global_from_library__set_1852_209_effect_cgraph(obj_t env_1858, obj_t obj_1859, obj_t val1474_1860)
{
   return global_from_library__set__21_effect_cgraph((global_t) (obj_1859), CBOOL(val1474_1860));
}


/* global/from-library? */ bool_t 
global_from_library__57_effect_cgraph(global_t obj_107)
{
   return (((global_t) CREF(obj_107))->library__255);
}


/* _global/from-library?1853 */ obj_t 
_global_from_library_1853_46_effect_cgraph(obj_t env_1861, obj_t obj_1862)
{
   {
      bool_t aux_2195;
      aux_2195 = global_from_library__57_effect_cgraph((global_t) (obj_1862));
      return BBOOL(aux_2195);
   }
}


/* global/from-user?-set! */ obj_t 
global_from_user__set__38_effect_cgraph(global_t obj_108, bool_t val1475_109)
{
   return ((((global_t) CREF(obj_108))->user__32) = ((bool_t) val1475_109), BUNSPEC);
}


/* _global/from-user?-set!1854 */ obj_t 
_global_from_user__set_1854_6_effect_cgraph(obj_t env_1863, obj_t obj_1864, obj_t val1475_1865)
{
   return global_from_user__set__38_effect_cgraph((global_t) (obj_1864), CBOOL(val1475_1865));
}


/* global/from-user? */ bool_t 
global_from_user__144_effect_cgraph(global_t obj_110)
{
   return (((global_t) CREF(obj_110))->user__32);
}


/* _global/from-user?1855 */ obj_t 
_global_from_user_1855_130_effect_cgraph(obj_t env_1866, obj_t obj_1867)
{
   {
      bool_t aux_2204;
      aux_2204 = global_from_user__144_effect_cgraph((global_t) (obj_1867));
      return BBOOL(aux_2204);
   }
}


/* global/from-pragma */ obj_t 
global_from_pragma_13_effect_cgraph(global_t obj_111)
{
   return (((global_t) CREF(obj_111))->pragma);
}


/* _global/from-pragma1856 */ obj_t 
_global_from_pragma1856_196_effect_cgraph(obj_t env_1868, obj_t obj_1869)
{
   return global_from_pragma_13_effect_cgraph((global_t) (obj_1869));
}


/* global/from-src-set! */ obj_t 
global_from_src_set__208_effect_cgraph(global_t obj_112, obj_t val1476_113)
{
   return ((((global_t) CREF(obj_112))->src) = ((obj_t) val1476_113), BUNSPEC);
}


/* _global/from-src-set!1857 */ obj_t 
_global_from_src_set_1857_203_effect_cgraph(obj_t env_1870, obj_t obj_1871, obj_t val1476_1872)
{
   return global_from_src_set__208_effect_cgraph((global_t) (obj_1871), val1476_1872);
}


/* global/from-src */ obj_t 
global_from_src_107_effect_cgraph(global_t obj_114)
{
   return (((global_t) CREF(obj_114))->src);
}


/* _global/from-src1858 */ obj_t 
_global_from_src1858_242_effect_cgraph(obj_t env_1873, obj_t obj_1874)
{
   return global_from_src_107_effect_cgraph((global_t) (obj_1874));
}


/* global/from-from-set! */ obj_t 
global_from_from_set__167_effect_cgraph(global_from_205_t obj_115, obj_t val1477_116)
{
   {
      obj_t aux_2217;
      {
	 object_t aux_2218;
	 aux_2218 = (object_t) (obj_115);
	 aux_2217 = OBJECT_WIDENING(aux_2218);
      }
      return ((((global_from_205_t) CREF(aux_2217))->from) = ((obj_t) val1477_116), BUNSPEC);
   }
}


/* _global/from-from-set!1859 */ obj_t 
_global_from_from_set_1859_194_effect_cgraph(obj_t env_1875, obj_t obj_1876, obj_t val1477_1877)
{
   return global_from_from_set__167_effect_cgraph((global_from_205_t) (obj_1876), val1477_1877);
}


/* global/from-from */ obj_t 
global_from_from_91_effect_cgraph(global_from_205_t obj_117)
{
   {
      obj_t aux_2224;
      {
	 object_t aux_2225;
	 aux_2225 = (object_t) (obj_117);
	 aux_2224 = OBJECT_WIDENING(aux_2225);
      }
      return (((global_from_205_t) CREF(aux_2224))->from);
   }
}


/* _global/from-from1860 */ obj_t 
_global_from_from1860_52_effect_cgraph(obj_t env_1878, obj_t obj_1879)
{
   return global_from_from_91_effect_cgraph((global_from_205_t) (obj_1879));
}


/* allocate-local/from */ local_t 
allocate_local_from_4_effect_cgraph()
{
   {
      local_t new1451_880;
      new1451_880 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1566_881;
	 arg1566_881 = class_num_218___object(local_from_91_effect_cgraph);
	 {
	    obj_t obj_1509;
	    obj_1509 = (obj_t) (new1451_880);
	    (((obj_t) CREF(obj_1509))->header = MAKE_HEADER(arg1566_881, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2235;
	 aux_2235 = (object_t) (new1451_880);
	 OBJECT_WIDENING_SET(aux_2235, BFALSE);
      }
      return new1451_880;
   }
}


/* _allocate-local/from */ obj_t 
_allocate_local_from_49_effect_cgraph(obj_t env_1786)
{
   {
      local_t aux_2238;
      aux_2238 = allocate_local_from_4_effect_cgraph();
      return (obj_t) (aux_2238);
   }
}


/* local/from? */ bool_t 
local_from__82_effect_cgraph(obj_t obj_121)
{
   return is_a__118___object(obj_121, local_from_91_effect_cgraph);
}


/* _local/from? */ obj_t 
_local_from__225_effect_cgraph(obj_t env_1880, obj_t obj_1881)
{
   {
      bool_t aux_2242;
      aux_2242 = local_from__82_effect_cgraph(obj_1881);
      return BBOOL(aux_2242);
   }
}


/* widening1002-local/from */ local_from_91_t 
widening1002_local_from_147_effect_cgraph(obj_t from_122)
{
   {
      local_from_91_t new1437_1511;
      new1437_1511 = ((local_from_91_t) BREF(GC_MALLOC(sizeof(struct local_from_91))));
      ((((local_from_91_t) CREF(new1437_1511))->from) = ((obj_t) from_122), BUNSPEC);
      return new1437_1511;
   }
}


/* _widening1002-local/from */ obj_t 
_widening1002_local_from_112_effect_cgraph(obj_t env_1882, obj_t from_1883)
{
   {
      local_from_91_t aux_2247;
      aux_2247 = widening1002_local_from_147_effect_cgraph(from_1883);
      return (obj_t) (aux_2247);
   }
}


/* make-local/from */ local_from_91_t 
make_local_from_27_effect_cgraph(obj_t id_123, obj_t name_124, type_t type_125, value_t value_126, obj_t access_127, obj_t fast_alpha_7_128, obj_t removable_129, long occurrence_130, bool_t user__32_131, long key_132, obj_t from_133)
{
   {
      local_t aux1440_1513;
      {
	 local_t res1822_1541;
	 {
	    local_t new1081_1527;
	    new1081_1527 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
	    {
	       long arg1656_1528;
	       arg1656_1528 = class_num_218___object(local_ast_var);
	       {
		  obj_t obj_1539;
		  obj_1539 = (obj_t) (new1081_1527);
		  (((obj_t) CREF(obj_1539))->header = MAKE_HEADER(arg1656_1528, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2254;
	       aux_2254 = (object_t) (new1081_1527);
	       OBJECT_WIDENING_SET(aux_2254, BFALSE);
	    }
	    ((((local_t) CREF(new1081_1527))->id) = ((obj_t) id_123), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->name) = ((obj_t) name_124), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->type) = ((type_t) type_125), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->value) = ((value_t) value_126), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->access) = ((obj_t) access_127), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->fast_alpha_7) = ((obj_t) fast_alpha_7_128), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->removable) = ((obj_t) removable_129), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->occurrence) = ((long) occurrence_130), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->user__32) = ((bool_t) user__32_131), BUNSPEC);
	    ((((local_t) CREF(new1081_1527))->key) = ((long) key_132), BUNSPEC);
	    res1822_1541 = new1081_1527;
	 }
	 aux1440_1513 = res1822_1541;
      }
      {
	 local_from_91_t new1441_1514;
	 new1441_1514 = ((local_from_91_t) (aux1440_1513));
	 {
	    long arg1568_1515;
	    arg1568_1515 = class_num_218___object(local_from_91_effect_cgraph);
	    {
	       obj_t obj_1542;
	       obj_1542 = (obj_t) (new1441_1514);
	       (((obj_t) CREF(obj_1542))->header = MAKE_HEADER(arg1568_1515, 0), BUNSPEC);
	    }
	 }
	 {
	    local_from_91_t arg1569_1516;
	    {
	       local_from_91_t res1823_1547;
	       {
		  local_from_91_t new1437_1545;
		  new1437_1545 = ((local_from_91_t) BREF(GC_MALLOC(sizeof(struct local_from_91))));
		  ((((local_from_91_t) CREF(new1437_1545))->from) = ((obj_t) from_133), BUNSPEC);
		  res1823_1547 = new1437_1545;
	       }
	       arg1569_1516 = res1823_1547;
	    }
	    {
	       obj_t aux_2275;
	       object_t aux_2273;
	       aux_2275 = (obj_t) (arg1569_1516);
	       aux_2273 = (object_t) (new1441_1514);
	       OBJECT_WIDENING_SET(aux_2273, aux_2275);
	    }
	 }
	 return new1441_1514;
      }
   }
}


/* _make-local/from1861 */ obj_t 
_make_local_from1861_153_effect_cgraph(obj_t env_1884, obj_t id_1885, obj_t name_1886, obj_t type_1887, obj_t value_1888, obj_t access_1889, obj_t fast_alpha_7_1890, obj_t removable_1891, obj_t occurrence_1892, obj_t user__32_1893, obj_t key_1894, obj_t from_1895)
{
   {
      local_from_91_t aux_2278;
      aux_2278 = make_local_from_27_effect_cgraph(id_1885, name_1886, (type_t) (type_1887), (value_t) (value_1888), access_1889, fast_alpha_7_1890, removable_1891, (long) CINT(occurrence_1892), CBOOL(user__32_1893), (long) CINT(key_1894), from_1895);
      return (obj_t) (aux_2278);
   }
}


/* local/from-id */ obj_t 
local_from_id_164_effect_cgraph(local_t obj_134)
{
   return (((local_t) CREF(obj_134))->id);
}


/* _local/from-id1862 */ obj_t 
_local_from_id1862_175_effect_cgraph(obj_t env_1896, obj_t obj_1897)
{
   return local_from_id_164_effect_cgraph((local_t) (obj_1897));
}


/* local/from-name-set! */ obj_t 
local_from_name_set__39_effect_cgraph(local_t obj_135, obj_t val1442_136)
{
   return ((((local_t) CREF(obj_135))->name) = ((obj_t) val1442_136), BUNSPEC);
}


/* _local/from-name-set!1863 */ obj_t 
_local_from_name_set_1863_37_effect_cgraph(obj_t env_1898, obj_t obj_1899, obj_t val1442_1900)
{
   return local_from_name_set__39_effect_cgraph((local_t) (obj_1899), val1442_1900);
}


/* local/from-name */ obj_t 
local_from_name_69_effect_cgraph(local_t obj_137)
{
   return (((local_t) CREF(obj_137))->name);
}


/* _local/from-name1864 */ obj_t 
_local_from_name1864_209_effect_cgraph(obj_t env_1901, obj_t obj_1902)
{
   return local_from_name_69_effect_cgraph((local_t) (obj_1902));
}


/* local/from-type-set! */ obj_t 
local_from_type_set__115_effect_cgraph(local_t obj_138, type_t val1443_139)
{
   return ((((local_t) CREF(obj_138))->type) = ((type_t) val1443_139), BUNSPEC);
}


/* _local/from-type-set!1865 */ obj_t 
_local_from_type_set_1865_100_effect_cgraph(obj_t env_1903, obj_t obj_1904, obj_t val1443_1905)
{
   return local_from_type_set__115_effect_cgraph((local_t) (obj_1904), (type_t) (val1443_1905));
}


/* local/from-type */ type_t 
local_from_type_22_effect_cgraph(local_t obj_140)
{
   return (((local_t) CREF(obj_140))->type);
}


/* _local/from-type1866 */ obj_t 
_local_from_type1866_245_effect_cgraph(obj_t env_1906, obj_t obj_1907)
{
   {
      type_t aux_2300;
      aux_2300 = local_from_type_22_effect_cgraph((local_t) (obj_1907));
      return (obj_t) (aux_2300);
   }
}


/* local/from-value-set! */ obj_t 
local_from_value_set__238_effect_cgraph(local_t obj_141, value_t val1444_142)
{
   return ((((local_t) CREF(obj_141))->value) = ((value_t) val1444_142), BUNSPEC);
}


/* _local/from-value-set!1867 */ obj_t 
_local_from_value_set_1867_144_effect_cgraph(obj_t env_1908, obj_t obj_1909, obj_t val1444_1910)
{
   return local_from_value_set__238_effect_cgraph((local_t) (obj_1909), (value_t) (val1444_1910));
}


/* local/from-value */ value_t 
local_from_value_53_effect_cgraph(local_t obj_143)
{
   return (((local_t) CREF(obj_143))->value);
}


/* _local/from-value1868 */ obj_t 
_local_from_value1868_234_effect_cgraph(obj_t env_1911, obj_t obj_1912)
{
   {
      value_t aux_2309;
      aux_2309 = local_from_value_53_effect_cgraph((local_t) (obj_1912));
      return (obj_t) (aux_2309);
   }
}


/* local/from-access-set! */ obj_t 
local_from_access_set__145_effect_cgraph(local_t obj_144, obj_t val1445_145)
{
   return ((((local_t) CREF(obj_144))->access) = ((obj_t) val1445_145), BUNSPEC);
}


/* _local/from-access-set!1869 */ obj_t 
_local_from_access_set_1869_42_effect_cgraph(obj_t env_1913, obj_t obj_1914, obj_t val1445_1915)
{
   return local_from_access_set__145_effect_cgraph((local_t) (obj_1914), val1445_1915);
}


/* local/from-access */ obj_t 
local_from_access_186_effect_cgraph(local_t obj_146)
{
   return (((local_t) CREF(obj_146))->access);
}


/* _local/from-access1870 */ obj_t 
_local_from_access1870_80_effect_cgraph(obj_t env_1916, obj_t obj_1917)
{
   return local_from_access_186_effect_cgraph((local_t) (obj_1917));
}


/* local/from-fast-alpha-set! */ obj_t 
local_from_fast_alpha_set__165_effect_cgraph(local_t obj_147, obj_t val1446_148)
{
   return ((((local_t) CREF(obj_147))->fast_alpha_7) = ((obj_t) val1446_148), BUNSPEC);
}


/* _local/from-fast-alpha-set!1871 */ obj_t 
_local_from_fast_alpha_set_1871_156_effect_cgraph(obj_t env_1918, obj_t obj_1919, obj_t val1446_1920)
{
   return local_from_fast_alpha_set__165_effect_cgraph((local_t) (obj_1919), val1446_1920);
}


/* local/from-fast-alpha */ obj_t 
local_from_fast_alpha_88_effect_cgraph(local_t obj_149)
{
   return (((local_t) CREF(obj_149))->fast_alpha_7);
}


/* _local/from-fast-alpha1872 */ obj_t 
_local_from_fast_alpha1872_68_effect_cgraph(obj_t env_1921, obj_t obj_1922)
{
   return local_from_fast_alpha_88_effect_cgraph((local_t) (obj_1922));
}


/* local/from-removable-set! */ obj_t 
local_from_removable_set__109_effect_cgraph(local_t obj_150, obj_t val1447_151)
{
   return ((((local_t) CREF(obj_150))->removable) = ((obj_t) val1447_151), BUNSPEC);
}


/* _local/from-removable-set!1873 */ obj_t 
_local_from_removable_set_1873_126_effect_cgraph(obj_t env_1923, obj_t obj_1924, obj_t val1447_1925)
{
   return local_from_removable_set__109_effect_cgraph((local_t) (obj_1924), val1447_1925);
}


/* local/from-removable */ obj_t 
local_from_removable_243_effect_cgraph(local_t obj_152)
{
   return (((local_t) CREF(obj_152))->removable);
}


/* _local/from-removable1874 */ obj_t 
_local_from_removable1874_56_effect_cgraph(obj_t env_1926, obj_t obj_1927)
{
   return local_from_removable_243_effect_cgraph((local_t) (obj_1927));
}


/* local/from-occurrence-set! */ obj_t 
local_from_occurrence_set__59_effect_cgraph(local_t obj_153, long val1448_154)
{
   return ((((local_t) CREF(obj_153))->occurrence) = ((long) val1448_154), BUNSPEC);
}


/* _local/from-occurrence-set!1875 */ obj_t 
_local_from_occurrence_set_1875_33_effect_cgraph(obj_t env_1928, obj_t obj_1929, obj_t val1448_1930)
{
   return local_from_occurrence_set__59_effect_cgraph((local_t) (obj_1929), (long) CINT(val1448_1930));
}


/* local/from-occurrence */ long 
local_from_occurrence_155_effect_cgraph(local_t obj_155)
{
   return (((local_t) CREF(obj_155))->occurrence);
}


/* _local/from-occurrence1876 */ obj_t 
_local_from_occurrence1876_6_effect_cgraph(obj_t env_1931, obj_t obj_1932)
{
   {
      long aux_2336;
      aux_2336 = local_from_occurrence_155_effect_cgraph((local_t) (obj_1932));
      return BINT(aux_2336);
   }
}


/* local/from-user?-set! */ obj_t 
local_from_user__set__131_effect_cgraph(local_t obj_156, bool_t val1449_157)
{
   return ((((local_t) CREF(obj_156))->user__32) = ((bool_t) val1449_157), BUNSPEC);
}


/* _local/from-user?-set!1877 */ obj_t 
_local_from_user__set_1877_219_effect_cgraph(obj_t env_1933, obj_t obj_1934, obj_t val1449_1935)
{
   return local_from_user__set__131_effect_cgraph((local_t) (obj_1934), CBOOL(val1449_1935));
}


/* local/from-user? */ bool_t 
local_from_user__236_effect_cgraph(local_t obj_158)
{
   return (((local_t) CREF(obj_158))->user__32);
}


/* _local/from-user?1878 */ obj_t 
_local_from_user_1878_125_effect_cgraph(obj_t env_1936, obj_t obj_1937)
{
   {
      bool_t aux_2345;
      aux_2345 = local_from_user__236_effect_cgraph((local_t) (obj_1937));
      return BBOOL(aux_2345);
   }
}


/* local/from-key */ long 
local_from_key_203_effect_cgraph(local_t obj_159)
{
   return (((local_t) CREF(obj_159))->key);
}


/* _local/from-key1879 */ obj_t 
_local_from_key1879_52_effect_cgraph(obj_t env_1938, obj_t obj_1939)
{
   {
      long aux_2350;
      aux_2350 = local_from_key_203_effect_cgraph((local_t) (obj_1939));
      return BINT(aux_2350);
   }
}


/* local/from-from-set! */ obj_t 
local_from_from_set__181_effect_cgraph(local_from_91_t obj_160, obj_t val1450_161)
{
   {
      obj_t aux_2354;
      {
	 object_t aux_2355;
	 aux_2355 = (object_t) (obj_160);
	 aux_2354 = OBJECT_WIDENING(aux_2355);
      }
      return ((((local_from_91_t) CREF(aux_2354))->from) = ((obj_t) val1450_161), BUNSPEC);
   }
}


/* _local/from-from-set!1880 */ obj_t 
_local_from_from_set_1880_86_effect_cgraph(obj_t env_1940, obj_t obj_1941, obj_t val1450_1942)
{
   return local_from_from_set__181_effect_cgraph((local_from_91_t) (obj_1941), val1450_1942);
}


/* local/from-from */ obj_t 
local_from_from_185_effect_cgraph(local_from_91_t obj_162)
{
   {
      obj_t aux_2361;
      {
	 object_t aux_2362;
	 aux_2362 = (object_t) (obj_162);
	 aux_2361 = OBJECT_WIDENING(aux_2362);
      }
      return (((local_from_91_t) CREF(aux_2361))->from);
   }
}


/* _local/from-from1881 */ obj_t 
_local_from_from1881_110_effect_cgraph(obj_t env_1943, obj_t obj_1944)
{
   return local_from_from_185_effect_cgraph((local_from_91_t) (obj_1944));
}


/* method-init */ obj_t 
method_init_76_effect_cgraph()
{
   add_generic__110___object(call_graph__env_226_effect_cgraph, call_graph__default1513_env_143_effect_cgraph);
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, sequence_ast_node, ((long) 0));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, app_ast_node, ((long) 1));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, app_ly_162_ast_node, ((long) 2));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, funcall_ast_node, ((long) 3));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, pragma_ast_node, ((long) 4));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, cast_ast_node, ((long) 5));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, setq_ast_node, ((long) 6));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, conditional_ast_node, ((long) 7));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, fail_ast_node, ((long) 8));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, select_ast_node, ((long) 9));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, let_fun_218_ast_node, ((long) 10));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, let_var_6_ast_node, ((long) 11));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, set_ex_it_116_ast_node, ((long) 12));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, jump_ex_it_184_ast_node, ((long) 13));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, make_box_202_ast_node, ((long) 14));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, box_ref_242_ast_node, ((long) 15));
   add_inlined_method__244___object(call_graph__env_226_effect_cgraph, box_set__221_ast_node, ((long) 16));
   add_generic__110___object(save_call__env_248_effect_cgraph, save_call__default1535_env_183_effect_cgraph);
   add_inlined_method__244___object(save_call__env_248_effect_cgraph, global_ast_var, ((long) 0));
   add_inlined_method__244___object(save_call__env_248_effect_cgraph, global_from_205_effect_cgraph, ((long) 1));
   add_inlined_method__244___object(save_call__env_248_effect_cgraph, local_ast_var, ((long) 2));
   add_inlined_method__244___object(save_call__env_248_effect_cgraph, local_from_91_effect_cgraph, ((long) 3));
   {
      obj_t object__struct_global_from_23_1953;
      object__struct_global_from_23_1953 = proc1889_effect_cgraph;
      add_method__1___object(object__struct_env_210___object, global_from_205_effect_cgraph, object__struct_global_from_23_1953);
   }
   {
      obj_t struct_object__object_global_from_226_1952;
      struct_object__object_global_from_226_1952 = proc1890_effect_cgraph;
      add_method__1___object(struct_object__object_env_209___object, global_from_205_effect_cgraph, struct_object__object_global_from_226_1952);
   }
   {
      obj_t object__struct_local_from_176_1949;
      object__struct_local_from_176_1949 = proc1891_effect_cgraph;
      add_method__1___object(object__struct_env_210___object, local_from_91_effect_cgraph, object__struct_local_from_176_1949);
   }
   {
      obj_t struct_object__object_local_from_22_1945;
      struct_object__object_local_from_22_1945 = proc1892_effect_cgraph;
      return add_method__1___object(struct_object__object_env_209___object, local_from_91_effect_cgraph, struct_object__object_local_from_22_1945);
   }
}


/* struct+object->object-local/from */ obj_t 
struct_object__object_local_from_22_effect_cgraph(obj_t env_1954, obj_t o_1955, obj_t s_1956)
{
   {
      local_from_91_t o_1251;
      obj_t s_1252;
      {
	 local_from_91_t aux_2395;
	 o_1251 = (local_from_91_t) (o_1955);
	 s_1252 = s_1956;
	 {
	    {
	       obj_t old1457_1255;
	       obj_t aux1458_1256;
	       {
		  obj_t next_method1548_240_1261;
		  next_method1548_240_1261 = find_super_class_method_167___object((object_t) (o_1251), struct_object__object_env_209___object, local_from_91_effect_cgraph);
		  if (PROCEDUREP(next_method1548_240_1261))
		    {
		       old1457_1255 = PROCEDURE_ENTRY(next_method1548_240_1261) (next_method1548_240_1261, (obj_t) (o_1251), s_1252, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1548_240_1261);
		       {
			  object_t aux_2404;
			  aux_2404 = struct_object__object_93___object((object_t) (o_1251), s_1252);
			  old1457_1255 = (obj_t) (aux_2404);
		       }
		    }
	       }
	       aux1458_1256 = STRUCT_REF(s_1252, ((long) 0));
	       {
		  local_from_91_t new1459_1257;
		  new1459_1257 = ((local_from_91_t) (old1457_1255));
		  {
		     long arg1688_1258;
		     arg1688_1258 = class_num_218___object(local_from_91_effect_cgraph);
		     {
			obj_t obj_1629;
			obj_1629 = (obj_t) (new1459_1257);
			(((obj_t) CREF(obj_1629))->header = MAKE_HEADER(arg1688_1258, 0), BUNSPEC);
		     }
		  }
		  {
		     local_from_91_t arg1689_1259;
		     {
			obj_t arg1691_1260;
			arg1691_1260 = STRUCT_REF(aux1458_1256, ((long) 0));
			{
			   local_from_91_t res1825_1636;
			   {
			      local_from_91_t new1437_1634;
			      new1437_1634 = ((local_from_91_t) BREF(GC_MALLOC(sizeof(struct local_from_91))));
			      ((((local_from_91_t) CREF(new1437_1634))->from) = ((obj_t) arg1691_1260), BUNSPEC);
			      res1825_1636 = new1437_1634;
			   }
			   arg1689_1259 = res1825_1636;
			}
		     }
		     {
			obj_t aux_2418;
			object_t aux_2416;
			aux_2418 = (obj_t) (arg1689_1259);
			aux_2416 = (object_t) (new1459_1257);
			OBJECT_WIDENING_SET(aux_2416, aux_2418);
		     }
		  }
		  aux_2395 = new1459_1257;
	       }
	    }
	 }
	 return (obj_t) (aux_2395);
      }
   }
}


/* object->struct-local/from */ obj_t 
object__struct_local_from_176_effect_cgraph(obj_t env_1957, obj_t obj1454_1958)
{
   {
      local_from_91_t obj1454_1238;
      obj1454_1238 = (local_from_91_t) (obj1454_1958);
      {
	 {
	    obj_t res1455_1241;
	    {
	       obj_t next_method1547_42_1249;
	       next_method1547_42_1249 = find_super_class_method_167___object((object_t) (obj1454_1238), object__struct_env_210___object, local_from_91_effect_cgraph);
	       if (PROCEDUREP(next_method1547_42_1249))
		 {
		    res1455_1241 = PROCEDURE_ENTRY(next_method1547_42_1249) (next_method1547_42_1249, (obj_t) (obj1454_1238), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1547_42_1249);
		    res1455_1241 = object__struct_50___object((object_t) (obj1454_1238));
		 }
	    }
	    {
	       obj_t aux1456_1242;
	       {
		  obj_t aux_2433;
		  aux_2433 = CNST_TABLE_REF(((long) 1));
		  aux1456_1242 = make_struct(aux_2433, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2436;
		  {
		     obj_t aux_2437;
		     {
			object_t aux_2438;
			aux_2438 = (object_t) (obj1454_1238);
			aux_2437 = OBJECT_WIDENING(aux_2438);
		     }
		     aux_2436 = (((local_from_91_t) CREF(aux_2437))->from);
		  }
		  STRUCT_SET(aux1456_1242, ((long) 0), aux_2436);
	       }
	       STRUCT_SET(res1455_1241, ((long) 0), aux1456_1242);
	       {
		  obj_t aux_2444;
		  aux_2444 = STRUCT_KEY(res1455_1241);
		  STRUCT_KEY_SET(aux1456_1242, aux_2444);
	       }
	       {
		  obj_t aux_2447;
		  aux_2447 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1455_1241, aux_2447);
	       }
	       return res1455_1241;
	    }
	 }
      }
   }
}


/* struct+object->object-global/from */ obj_t 
struct_object__object_global_from_226_effect_cgraph(obj_t env_1959, obj_t o_1960, obj_t s_1961)
{
   {
      global_from_205_t o_1226;
      obj_t s_1227;
      {
	 global_from_205_t aux_2451;
	 o_1226 = (global_from_205_t) (o_1960);
	 s_1227 = s_1961;
	 {
	    {
	       obj_t old1482_1230;
	       obj_t aux1483_1231;
	       {
		  obj_t next_method1546_155_1236;
		  next_method1546_155_1236 = find_super_class_method_167___object((object_t) (o_1226), struct_object__object_env_209___object, global_from_205_effect_cgraph);
		  if (PROCEDUREP(next_method1546_155_1236))
		    {
		       old1482_1230 = PROCEDURE_ENTRY(next_method1546_155_1236) (next_method1546_155_1236, (obj_t) (o_1226), s_1227, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1546_155_1236);
		       {
			  object_t aux_2460;
			  aux_2460 = struct_object__object_93___object((object_t) (o_1226), s_1227);
			  old1482_1230 = (obj_t) (aux_2460);
		       }
		    }
	       }
	       aux1483_1231 = STRUCT_REF(s_1227, ((long) 0));
	       {
		  global_from_205_t new1484_1232;
		  new1484_1232 = ((global_from_205_t) (old1482_1230));
		  {
		     long arg1677_1233;
		     arg1677_1233 = class_num_218___object(global_from_205_effect_cgraph);
		     {
			obj_t obj_1600;
			obj_1600 = (obj_t) (new1484_1232);
			(((obj_t) CREF(obj_1600))->header = MAKE_HEADER(arg1677_1233, 0), BUNSPEC);
		     }
		  }
		  {
		     global_from_205_t arg1678_1234;
		     {
			obj_t arg1679_1235;
			arg1679_1235 = STRUCT_REF(aux1483_1231, ((long) 0));
			{
			   global_from_205_t res1824_1607;
			   {
			      global_from_205_t new1460_1605;
			      new1460_1605 = ((global_from_205_t) BREF(GC_MALLOC(sizeof(struct global_from_205))));
			      ((((global_from_205_t) CREF(new1460_1605))->from) = ((obj_t) arg1679_1235), BUNSPEC);
			      res1824_1607 = new1460_1605;
			   }
			   arg1678_1234 = res1824_1607;
			}
		     }
		     {
			obj_t aux_2474;
			object_t aux_2472;
			aux_2474 = (obj_t) (arg1678_1234);
			aux_2472 = (object_t) (new1484_1232);
			OBJECT_WIDENING_SET(aux_2472, aux_2474);
		     }
		  }
		  aux_2451 = new1484_1232;
	       }
	    }
	 }
	 return (obj_t) (aux_2451);
      }
   }
}


/* object->struct-global/from */ obj_t 
object__struct_global_from_23_effect_cgraph(obj_t env_1962, obj_t obj1479_1963)
{
   {
      global_from_205_t obj1479_1213;
      obj1479_1213 = (global_from_205_t) (obj1479_1963);
      {
	 {
	    obj_t res1480_1216;
	    {
	       obj_t next_method1545_159_1224;
	       next_method1545_159_1224 = find_super_class_method_167___object((object_t) (obj1479_1213), object__struct_env_210___object, global_from_205_effect_cgraph);
	       if (PROCEDUREP(next_method1545_159_1224))
		 {
		    res1480_1216 = PROCEDURE_ENTRY(next_method1545_159_1224) (next_method1545_159_1224, (obj_t) (obj1479_1213), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1545_159_1224);
		    res1480_1216 = object__struct_50___object((object_t) (obj1479_1213));
		 }
	    }
	    {
	       obj_t aux1481_1217;
	       {
		  obj_t aux_2489;
		  aux_2489 = CNST_TABLE_REF(((long) 2));
		  aux1481_1217 = make_struct(aux_2489, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2492;
		  {
		     obj_t aux_2493;
		     {
			object_t aux_2494;
			aux_2494 = (object_t) (obj1479_1213);
			aux_2493 = OBJECT_WIDENING(aux_2494);
		     }
		     aux_2492 = (((global_from_205_t) CREF(aux_2493))->from);
		  }
		  STRUCT_SET(aux1481_1217, ((long) 0), aux_2492);
	       }
	       STRUCT_SET(res1480_1216, ((long) 0), aux1481_1217);
	       {
		  obj_t aux_2500;
		  aux_2500 = STRUCT_KEY(res1480_1216);
		  STRUCT_KEY_SET(aux1481_1217, aux_2500);
	       }
	       {
		  obj_t aux_2503;
		  aux_2503 = CNST_TABLE_REF(((long) 2));
		  STRUCT_KEY_SET(res1480_1216, aux_2503);
	       }
	       return res1480_1216;
	    }
	 }
      }
   }
}


/* call-graph! */ obj_t 
call_graph__81_effect_cgraph(node_t node_2, variable_t owner_3)
{
 call_graph__81_effect_cgraph:
   {
      obj_t method1741_1324;
      obj_t class1746_1325;
      {
	 obj_t arg1749_1322;
	 obj_t arg1753_1323;
	 {
	    object_t obj_1639;
	    obj_1639 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1640;
	       pre_method_105_1640 = PROCEDURE_REF(call_graph__env_226_effect_cgraph, ((long) 2));
	       if (INTEGERP(pre_method_105_1640))
		 {
		    PROCEDURE_SET(call_graph__env_226_effect_cgraph, ((long) 2), BUNSPEC);
		    arg1749_1322 = pre_method_105_1640;
		 }
	       else
		 {
		    long obj_class_num_177_1645;
		    obj_class_num_177_1645 = TYPE(obj_1639);
		    {
		       obj_t arg1177_1646;
		       arg1177_1646 = PROCEDURE_REF(call_graph__env_226_effect_cgraph, ((long) 1));
		       {
			  long arg1178_1650;
			  {
			     long arg1179_1651;
			     arg1179_1651 = OBJECT_TYPE;
			     arg1178_1650 = (obj_class_num_177_1645 - arg1179_1651);
			  }
			  arg1749_1322 = VECTOR_REF(arg1177_1646, arg1178_1650);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1656;
	    object_1656 = (object_t) (node_2);
	    {
	       long arg1180_1657;
	       {
		  long arg1181_1658;
		  long arg1182_1659;
		  arg1181_1658 = TYPE(object_1656);
		  arg1182_1659 = OBJECT_TYPE;
		  arg1180_1657 = (arg1181_1658 - arg1182_1659);
	       }
	       {
		  obj_t vector_1663;
		  vector_1663 = _classes__134___object;
		  arg1753_1323 = VECTOR_REF(vector_1663, arg1180_1657);
	       }
	    }
	 }
	 method1741_1324 = arg1749_1322;
	 class1746_1325 = arg1753_1323;
	 {
	    if (INTEGERP(method1741_1324))
	      {
		 switch ((long) CINT(method1741_1324))
		   {
		   case ((long) 0):
		      {
			 sequence_t node_1331;
			 node_1331 = (sequence_t) (node_2);
			 {
			    bool_t aux_2525;
			    aux_2525 = call_graph___13_effect_cgraph((((sequence_t) CREF(node_1331))->nodes), owner_3);
			    return BBOOL(aux_2525);
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 app_t node_1334;
			 node_1334 = (app_t) (node_2);
			 {
			    variable_t aux_2530;
			    {
			       var_t arg1760_1338;
			       arg1760_1338 = (((app_t) CREF(node_1334))->fun);
			       aux_2530 = (((var_t) CREF(arg1760_1338))->variable);
			    }
			    save_call__133_effect_cgraph(aux_2530, owner_3);
			 }
			 {
			    bool_t aux_2534;
			    aux_2534 = call_graph___13_effect_cgraph((((app_t) CREF(node_1334))->args), owner_3);
			    return BBOOL(aux_2534);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 app_ly_162_t node_1340;
			 node_1340 = (app_ly_162_t) (node_2);
			 mark_side_effect__61_effect_cgraph(owner_3);
			 call_graph__81_effect_cgraph((((app_ly_162_t) CREF(node_1340))->fun), owner_3);
			 {
			    node_t node_2542;
			    node_2542 = (((app_ly_162_t) CREF(node_1340))->arg);
			    node_2 = node_2542;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 funcall_t node_1345;
			 node_1345 = (funcall_t) (node_2);
			 mark_side_effect__61_effect_cgraph(owner_3);
			 call_graph__81_effect_cgraph((((funcall_t) CREF(node_1345))->fun), owner_3);
			 {
			    bool_t aux_2548;
			    aux_2548 = call_graph___13_effect_cgraph((((funcall_t) CREF(node_1345))->args), owner_3);
			    return BBOOL(aux_2548);
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 pragma_t node_1350;
			 node_1350 = (pragma_t) (node_2);
			 {
			    bool_t test_2553;
			    {
			       obj_t aux_2554;
			       aux_2554 = (((pragma_t) CREF(node_1350))->side_effect__165);
			       test_2553 = CBOOL(aux_2554);
			    }
			    if (test_2553)
			      {
				 mark_side_effect__61_effect_cgraph(owner_3);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
			 {
			    bool_t aux_2558;
			    aux_2558 = call_graph___13_effect_cgraph((((pragma_t) CREF(node_1350))->args), owner_3);
			    return BBOOL(aux_2558);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 cast_t node_1355;
			 node_1355 = (cast_t) (node_2);
			 {
			    node_t node_2563;
			    node_2563 = (((cast_t) CREF(node_1355))->arg);
			    node_2 = node_2563;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 setq_t node_1359;
			 node_1359 = (setq_t) (node_2);
			 {
			    bool_t test1771_1362;
			    {
			       bool_t test1772_1363;
			       test1772_1363 = is_a__118___object((obj_t) (owner_3), local_ast_var);
			       if (test1772_1363)
				 {
				    test1771_1362 = ((bool_t) 1);
				 }
			       else
				 {
				    obj_t aux_2569;
				    {
				       variable_t aux_2570;
				       {
					  var_t arg1774_1365;
					  arg1774_1365 = (((setq_t) CREF(node_1359))->var);
					  aux_2570 = (((var_t) CREF(arg1774_1365))->variable);
				       }
				       aux_2569 = (obj_t) (aux_2570);
				    }
				    test1771_1362 = is_a__118___object(aux_2569, global_ast_var);
				 }
			    }
			    if (test1771_1362)
			      {
				 mark_side_effect__61_effect_cgraph(owner_3);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
			 {
			    node_t aux_2577;
			    {
			       var_t aux_2578;
			       aux_2578 = (((setq_t) CREF(node_1359))->var);
			       aux_2577 = (node_t) (aux_2578);
			    }
			    call_graph__81_effect_cgraph(aux_2577, owner_3);
			 }
			 {
			    node_t node_2582;
			    node_2582 = (((setq_t) CREF(node_1359))->value);
			    node_2 = node_2582;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 conditional_t node_1368;
			 node_1368 = (conditional_t) (node_2);
			 call_graph__81_effect_cgraph((((conditional_t) CREF(node_1368))->test), owner_3);
			 call_graph__81_effect_cgraph((((conditional_t) CREF(node_1368))->true), owner_3);
			 {
			    node_t node_2589;
			    node_2589 = (((conditional_t) CREF(node_1368))->false);
			    node_2 = node_2589;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 fail_t node_1374;
			 node_1374 = (fail_t) (node_2);
			 mark_side_effect__61_effect_cgraph(owner_3);
			 call_graph__81_effect_cgraph((((fail_t) CREF(node_1374))->proc), owner_3);
			 call_graph__81_effect_cgraph((((fail_t) CREF(node_1374))->msg), owner_3);
			 {
			    node_t node_2597;
			    node_2597 = (((fail_t) CREF(node_1374))->obj);
			    node_2 = node_2597;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 select_t node_1380;
			 node_1380 = (select_t) (node_2);
			 call_graph__81_effect_cgraph((((select_t) CREF(node_1380))->test), owner_3);
			 {
			    obj_t l1494_1384;
			    {
			       bool_t aux_2602;
			       l1494_1384 = (((select_t) CREF(node_1380))->clauses);
			     lname1495_1385:
			       if (PAIRP(l1494_1384))
				 {
				    {
				       node_t aux_2605;
				       {
					  obj_t aux_2606;
					  {
					     obj_t aux_2607;
					     aux_2607 = CAR(l1494_1384);
					     aux_2606 = CDR(aux_2607);
					  }
					  aux_2605 = (node_t) (aux_2606);
				       }
				       call_graph__81_effect_cgraph(aux_2605, owner_3);
				    }
				    {
				       obj_t l1494_2612;
				       l1494_2612 = CDR(l1494_1384);
				       l1494_1384 = l1494_2612;
				       goto lname1495_1385;
				    }
				 }
			       else
				 {
				    aux_2602 = ((bool_t) 1);
				 }
			       return BBOOL(aux_2602);
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 let_fun_218_t node_1391;
			 node_1391 = (let_fun_218_t) (node_2);
			 {
			    obj_t l1497_1394;
			    l1497_1394 = (((let_fun_218_t) CREF(node_1391))->locals);
			  lname1498_1395:
			    if (PAIRP(l1497_1394))
			      {
				 {
				    variable_t aux_2619;
				    {
				       obj_t aux_2620;
				       aux_2620 = CAR(l1497_1394);
				       aux_2619 = (variable_t) (aux_2620);
				    }
				    fun_call_graph__231_effect_cgraph(aux_2619);
				 }
				 {
				    obj_t l1497_2624;
				    l1497_2624 = CDR(l1497_1394);
				    l1497_1394 = l1497_2624;
				    goto lname1498_1395;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_2627;
			    node_2627 = (((let_fun_218_t) CREF(node_1391))->body);
			    node_2 = node_2627;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 let_var_6_t node_1401;
			 node_1401 = (let_var_6_t) (node_2);
			 call_graph__81_effect_cgraph((((let_var_6_t) CREF(node_1401))->body), owner_3);
			 {
			    obj_t l1500_1405;
			    {
			       bool_t aux_2632;
			       l1500_1405 = (((let_var_6_t) CREF(node_1401))->bindings);
			     lname1501_1406:
			       if (PAIRP(l1500_1405))
				 {
				    {
				       node_t aux_2635;
				       {
					  obj_t aux_2636;
					  {
					     obj_t aux_2637;
					     aux_2637 = CAR(l1500_1405);
					     aux_2636 = CDR(aux_2637);
					  }
					  aux_2635 = (node_t) (aux_2636);
				       }
				       call_graph__81_effect_cgraph(aux_2635, owner_3);
				    }
				    {
				       obj_t l1500_2642;
				       l1500_2642 = CDR(l1500_1405);
				       l1500_1405 = l1500_2642;
				       goto lname1501_1406;
				    }
				 }
			       else
				 {
				    aux_2632 = ((bool_t) 1);
				 }
			       return BBOOL(aux_2632);
			    }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 set_ex_it_116_t node_1412;
			 node_1412 = (set_ex_it_116_t) (node_2);
			 mark_side_effect__61_effect_cgraph(owner_3);
			 {
			    node_t node_2648;
			    node_2648 = (((set_ex_it_116_t) CREF(node_1412))->body);
			    node_2 = node_2648;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 jump_ex_it_184_t node_1416;
			 node_1416 = (jump_ex_it_184_t) (node_2);
			 mark_side_effect__61_effect_cgraph(owner_3);
			 call_graph__81_effect_cgraph((((jump_ex_it_184_t) CREF(node_1416))->exit), owner_3);
			 {
			    node_t node_2654;
			    node_2654 = (((jump_ex_it_184_t) CREF(node_1416))->value);
			    node_2 = node_2654;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 make_box_202_t node_1421;
			 node_1421 = (make_box_202_t) (node_2);
			 {
			    node_t node_2657;
			    node_2657 = (((make_box_202_t) CREF(node_1421))->value);
			    node_2 = node_2657;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 box_ref_242_t node_1424;
			 node_1424 = (box_ref_242_t) (node_2);
			 {
			    node_t node_2660;
			    {
			       var_t aux_2661;
			       aux_2661 = (((box_ref_242_t) CREF(node_1424))->var);
			       node_2660 = (node_t) (aux_2661);
			    }
			    node_2 = node_2660;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 box_set__221_t node_1427;
			 node_1427 = (box_set__221_t) (node_2);
			 {
			    bool_t test1809_1430;
			    {
			       bool_t test1810_1431;
			       test1810_1431 = is_a__118___object((obj_t) (owner_3), local_ast_var);
			       if (test1810_1431)
				 {
				    test1809_1430 = ((bool_t) 1);
				 }
			       else
				 {
				    obj_t aux_2668;
				    {
				       variable_t aux_2669;
				       {
					  var_t arg1812_1433;
					  arg1812_1433 = (((box_set__221_t) CREF(node_1427))->var);
					  aux_2669 = (((var_t) CREF(arg1812_1433))->variable);
				       }
				       aux_2668 = (obj_t) (aux_2669);
				    }
				    test1809_1430 = is_a__118___object(aux_2668, global_ast_var);
				 }
			    }
			    if (test1809_1430)
			      {
				 mark_side_effect__61_effect_cgraph(owner_3);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
			 {
			    node_t aux_2676;
			    {
			       var_t aux_2677;
			       aux_2677 = (((box_set__221_t) CREF(node_1427))->var);
			       aux_2676 = (node_t) (aux_2677);
			    }
			    call_graph__81_effect_cgraph(aux_2676, owner_3);
			 }
			 {
			    node_t node_2681;
			    node_2681 = (((box_set__221_t) CREF(node_1427))->value);
			    node_2 = node_2681;
			    goto call_graph__81_effect_cgraph;
			 }
		      }
		      break;
		   default:
		    case_else1747_1328:
		      if (PROCEDUREP(method1741_1324))
			{
			   return PROCEDURE_ENTRY(method1741_1324) (method1741_1324, (obj_t) (node_2), (obj_t) (owner_3), BEOA);
			}
		      else
			{
			   obj_t fun1693_1263;
			   fun1693_1263 = PROCEDURE_REF(call_graph__env_226_effect_cgraph, ((long) 0));
			   return PROCEDURE_ENTRY(fun1693_1263) (fun1693_1263, (obj_t) (node_2), (obj_t) (owner_3), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1747_1328;
	      }
	 }
      }
   }
}


/* _call-graph!1887 */ obj_t 
_call_graph_1887_168_effect_cgraph(obj_t env_1964, obj_t node_1965, obj_t owner_1966)
{
   return call_graph__81_effect_cgraph((node_t) (node_1965), (variable_t) (owner_1966));
}


/* call-graph!-default1513 */ obj_t 
call_graph__default1513_140_effect_cgraph(node_t node_4, variable_t owner_5)
{
   return CNST_TABLE_REF(((long) 3));
}


/* _call-graph!-default1513 */ obj_t 
_call_graph__default1513_72_effect_cgraph(obj_t env_1967, obj_t node_1968, obj_t owner_1969)
{
   return call_graph__default1513_140_effect_cgraph((node_t) (node_1968), (variable_t) (owner_1969));
}


/* save-call! */ obj_t 
save_call__133_effect_cgraph(variable_t callee_42, variable_t owner_43)
{
 save_call__133_effect_cgraph:
   {
      obj_t method1698_1270;
      obj_t class1703_1271;
      {
	 obj_t arg1706_1268;
	 obj_t arg1707_1269;
	 {
	    object_t obj_1718;
	    obj_1718 = (object_t) (callee_42);
	    {
	       obj_t pre_method_105_1719;
	       pre_method_105_1719 = PROCEDURE_REF(save_call__env_248_effect_cgraph, ((long) 2));
	       if (INTEGERP(pre_method_105_1719))
		 {
		    PROCEDURE_SET(save_call__env_248_effect_cgraph, ((long) 2), BUNSPEC);
		    arg1706_1268 = pre_method_105_1719;
		 }
	       else
		 {
		    long obj_class_num_177_1724;
		    obj_class_num_177_1724 = TYPE(obj_1718);
		    {
		       obj_t arg1177_1725;
		       arg1177_1725 = PROCEDURE_REF(save_call__env_248_effect_cgraph, ((long) 1));
		       {
			  long arg1178_1729;
			  {
			     long arg1179_1730;
			     arg1179_1730 = OBJECT_TYPE;
			     arg1178_1729 = (obj_class_num_177_1724 - arg1179_1730);
			  }
			  arg1706_1268 = VECTOR_REF(arg1177_1725, arg1178_1729);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1735;
	    object_1735 = (object_t) (callee_42);
	    {
	       long arg1180_1736;
	       {
		  long arg1181_1737;
		  long arg1182_1738;
		  arg1181_1737 = TYPE(object_1735);
		  arg1182_1738 = OBJECT_TYPE;
		  arg1180_1736 = (arg1181_1737 - arg1182_1738);
	       }
	       {
		  obj_t vector_1742;
		  vector_1742 = _classes__134___object;
		  arg1707_1269 = VECTOR_REF(vector_1742, arg1180_1736);
	       }
	    }
	 }
	 method1698_1270 = arg1706_1268;
	 class1703_1271 = arg1707_1269;
	 {
	    if (INTEGERP(method1698_1270))
	      {
		 switch ((long) CINT(method1698_1270))
		   {
		   case ((long) 0):
		      {
			 global_t callee_1277;
			 callee_1277 = (global_t) (callee_42);
			 {
			    value_t fun_1279;
			    fun_1279 = (((global_t) CREF(callee_1277))->value);
			    {
			       bool_t test1710_1280;
			       {
				  bool_t test1717_1287;
				  test1717_1287 = is_a__118___object((obj_t) (fun_1279), cfun_ast_var);
				  if (test1717_1287)
				    {
				       test1710_1280 = ((bool_t) 1);
				    }
				  else
				    {
				       bool_t _andtest_1507_1288;
				       _andtest_1507_1288 = is_a__118___object((obj_t) (fun_1279), sfun_ast_var);
				       if (_andtest_1507_1288)
					 {
					    obj_t aux_2730;
					    obj_t aux_2728;
					    aux_2730 = CNST_TABLE_REF(((long) 4));
					    aux_2728 = (((global_t) CREF(callee_1277))->import);
					    test1710_1280 = (aux_2728 == aux_2730);
					 }
				       else
					 {
					    test1710_1280 = ((bool_t) 0);
					 }
				    }
			       }
			       if (test1710_1280)
				 {
				    bool_t test_2734;
				    {
				       fun_t obj_1750;
				       obj_1750 = (fun_t) (fun_1279);
				       {
					  obj_t aux_2736;
					  aux_2736 = (((fun_t) CREF(obj_1750))->side_effect__165);
					  test_2734 = CBOOL(aux_2736);
				       }
				    }
				    if (test_2734)
				      {
					 return mark_side_effect__61_effect_cgraph(owner_43);
				      }
				    else
				      {
					 return BUNSPEC;
				      }
				 }
			       else
				 {
				    global_from_205_t arg1712_1282;
				    {
				       global_from_205_t obj1508_1283;
				       obj1508_1283 = ((global_from_205_t) (callee_1277));
				       {
					  global_from_205_t arg1713_1284;
					  {
					     global_from_205_t res1827_1754;
					     {
						global_from_205_t new1460_1752;
						new1460_1752 = ((global_from_205_t) BREF(GC_MALLOC(sizeof(struct global_from_205))));
						((((global_from_205_t) CREF(new1460_1752))->from) = ((obj_t) BNIL), BUNSPEC);
						res1827_1754 = new1460_1752;
					     }
					     arg1713_1284 = res1827_1754;
					  }
					  {
					     obj_t aux_2745;
					     object_t aux_2743;
					     aux_2745 = (obj_t) (arg1713_1284);
					     aux_2743 = (object_t) (obj1508_1283);
					     OBJECT_WIDENING_SET(aux_2743, aux_2745);
					  }
				       }
				       {
					  long arg1716_1286;
					  arg1716_1286 = class_num_218___object(global_from_205_effect_cgraph);
					  {
					     obj_t obj_1755;
					     obj_1755 = (obj_t) (obj1508_1283);
					     (((obj_t) CREF(obj_1755))->header = MAKE_HEADER(arg1716_1286, 0), BUNSPEC);
					  }
				       }
				       arg1712_1282 = obj1508_1283;
				    }
				    {
				       variable_t callee_2751;
				       callee_2751 = (variable_t) (arg1712_1282);
				       callee_42 = callee_2751;
				       goto save_call__133_effect_cgraph;
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 global_from_205_t callee_1291;
			 callee_1291 = (global_from_205_t) (callee_42);
			 {
			    bool_t test_2754;
			    {
			       obj_t aux_2755;
			       {
				  obj_t aux_2756;
				  {
				     obj_t aux_2758;
				     {
					object_t aux_2759;
					aux_2759 = (object_t) (callee_1291);
					aux_2758 = OBJECT_WIDENING(aux_2759);
				     }
				     aux_2756 = (((global_from_205_t) CREF(aux_2758))->from);
				  }
				  aux_2755 = memq___r4_pairs_and_lists_6_3((obj_t) (owner_43), aux_2756);
			       }
			       test_2754 = CBOOL(aux_2755);
			    }
			    if (test_2754)
			      {
				 return BUNSPEC;
			      }
			    else
			      {
				 obj_t arg1722_1295;
				 {
				    obj_t aux_2767;
				    obj_t aux_2765;
				    {
				       obj_t aux_2768;
				       {
					  object_t aux_2769;
					  aux_2769 = (object_t) (callee_1291);
					  aux_2768 = OBJECT_WIDENING(aux_2769);
				       }
				       aux_2767 = (((global_from_205_t) CREF(aux_2768))->from);
				    }
				    aux_2765 = (obj_t) (owner_43);
				    arg1722_1295 = MAKE_PAIR(aux_2765, aux_2767);
				 }
				 {
				    obj_t aux_2774;
				    {
				       object_t aux_2775;
				       aux_2775 = (object_t) (callee_1291);
				       aux_2774 = OBJECT_WIDENING(aux_2775);
				    }
				    return ((((global_from_205_t) CREF(aux_2774))->from) = ((obj_t) arg1722_1295), BUNSPEC);
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 local_t callee_1298;
			 callee_1298 = (local_t) (callee_42);
			 {
			    local_from_91_t arg1725_1300;
			    {
			       local_from_91_t obj1510_1301;
			       obj1510_1301 = ((local_from_91_t) (callee_1298));
			       {
				  local_from_91_t arg1726_1302;
				  {
				     local_from_91_t res1828_1766;
				     {
					local_from_91_t new1437_1764;
					new1437_1764 = ((local_from_91_t) BREF(GC_MALLOC(sizeof(struct local_from_91))));
					((((local_from_91_t) CREF(new1437_1764))->from) = ((obj_t) BNIL), BUNSPEC);
					res1828_1766 = new1437_1764;
				     }
				     arg1726_1302 = res1828_1766;
				  }
				  {
				     obj_t aux_2785;
				     object_t aux_2783;
				     aux_2785 = (obj_t) (arg1726_1302);
				     aux_2783 = (object_t) (obj1510_1301);
				     OBJECT_WIDENING_SET(aux_2783, aux_2785);
				  }
			       }
			       {
				  long arg1728_1304;
				  arg1728_1304 = class_num_218___object(local_from_91_effect_cgraph);
				  {
				     obj_t obj_1767;
				     obj_1767 = (obj_t) (obj1510_1301);
				     (((obj_t) CREF(obj_1767))->header = MAKE_HEADER(arg1728_1304, 0), BUNSPEC);
				  }
			       }
			       arg1725_1300 = obj1510_1301;
			    }
			    {
			       variable_t callee_2791;
			       callee_2791 = (variable_t) (arg1725_1300);
			       callee_42 = callee_2791;
			       goto save_call__133_effect_cgraph;
			    }
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 local_from_91_t callee_1305;
			 callee_1305 = (local_from_91_t) (callee_42);
			 {
			    bool_t test_2794;
			    {
			       obj_t aux_2795;
			       {
				  obj_t aux_2796;
				  {
				     obj_t aux_2798;
				     {
					object_t aux_2799;
					aux_2799 = (object_t) (callee_1305);
					aux_2798 = OBJECT_WIDENING(aux_2799);
				     }
				     aux_2796 = (((local_from_91_t) CREF(aux_2798))->from);
				  }
				  aux_2795 = memq___r4_pairs_and_lists_6_3((obj_t) (owner_43), aux_2796);
			       }
			       test_2794 = CBOOL(aux_2795);
			    }
			    if (test_2794)
			      {
				 return BUNSPEC;
			      }
			    else
			      {
				 obj_t arg1730_1309;
				 {
				    obj_t aux_2807;
				    obj_t aux_2805;
				    {
				       obj_t aux_2808;
				       {
					  object_t aux_2809;
					  aux_2809 = (object_t) (callee_1305);
					  aux_2808 = OBJECT_WIDENING(aux_2809);
				       }
				       aux_2807 = (((local_from_91_t) CREF(aux_2808))->from);
				    }
				    aux_2805 = (obj_t) (owner_43);
				    arg1730_1309 = MAKE_PAIR(aux_2805, aux_2807);
				 }
				 {
				    obj_t aux_2814;
				    {
				       object_t aux_2815;
				       aux_2815 = (object_t) (callee_1305);
				       aux_2814 = OBJECT_WIDENING(aux_2815);
				    }
				    return ((((local_from_91_t) CREF(aux_2814))->from) = ((obj_t) arg1730_1309), BUNSPEC);
				 }
			      }
			 }
		      }
		      break;
		   default:
		    case_else1704_1274:
		      if (PROCEDUREP(method1698_1270))
			{
			   return PROCEDURE_ENTRY(method1698_1270) (method1698_1270, (obj_t) (callee_42), (obj_t) (owner_43), BEOA);
			}
		      else
			{
			   obj_t fun1694_1264;
			   fun1694_1264 = PROCEDURE_REF(save_call__env_248_effect_cgraph, ((long) 0));
			   return PROCEDURE_ENTRY(fun1694_1264) (fun1694_1264, (obj_t) (callee_42), (obj_t) (owner_43), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1704_1274;
	      }
	 }
      }
   }
}


/* _save-call!1888 */ obj_t 
_save_call_1888_182_effect_cgraph(obj_t env_1970, obj_t callee_1971, obj_t owner_1972)
{
   return save_call__133_effect_cgraph((variable_t) (callee_1971), (variable_t) (owner_1972));
}


/* save-call!-default1535 */ obj_t 
save_call__default1535_7_effect_cgraph(variable_t callee_44, variable_t owner_45)
{
   FAILURE(CNST_TABLE_REF(((long) 5)), string1893_effect_cgraph, (obj_t) (callee_44));
}


/* _save-call!-default1535 */ obj_t 
_save_call__default1535_53_effect_cgraph(obj_t env_1973, obj_t callee_1974, obj_t owner_1975)
{
   return save_call__default1535_7_effect_cgraph((variable_t) (callee_1974), (variable_t) (owner_1975));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_effect_cgraph()
{
   module_initialization_70_type_type(((long) 0), "EFFECT_CGRAPH");
   module_initialization_70_ast_var(((long) 0), "EFFECT_CGRAPH");
   module_initialization_70_ast_node(((long) 0), "EFFECT_CGRAPH");
   module_initialization_70_tools_trace(((long) 0), "EFFECT_CGRAPH");
   module_initialization_70_tools_shape(((long) 0), "EFFECT_CGRAPH");
   return module_initialization_70_tools_error(((long) 0), "EFFECT_CGRAPH");
}
