/*===========================================================================*/
/*   (Reduce/same.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_reduce_same();
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t pragma_ast_node;
static bool_t same_node___136_reduce_same(obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_same(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern long list_length(obj_t);
static obj_t _same_node_1765_138_reduce_same(obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_reduce_same();
static bool_t same_node__default1478_45_reduce_same(node_t, node_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern bool_t bigloo_strcmp(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_reduce_same();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_reduce_same();
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t _classes__134___object;
static bool_t aliased__149_reduce_same(variable_t, variable_t, obj_t);
extern obj_t read___reader(obj_t);
extern bool_t same_node__38_reduce_same(node_t, node_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t require_initialization_114_reduce_same = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t _same_node__default1478_162_reduce_same(obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137_reduce_same();
static obj_t __cnst[1];

DEFINE_STATIC_PROCEDURE(same_node__default1478_env_125_reduce_same, _same_node__default1478_162_reduce_same1772, _same_node__default1478_162_reduce_same, 0L, 3);
DEFINE_STRING(string1766_reduce_same, string1766_reduce_same1773, "READ ", 5);
DEFINE_EXPORT_GENERIC(same_node__env_162_reduce_same, _same_node_1765_138_reduce_same1774, _same_node_1765_138_reduce_same, 0L, 3);


/* module-initialization */ obj_t 
module_initialization_70_reduce_same(long checksum_1523, char *from_1524)
{
   if (CBOOL(require_initialization_114_reduce_same))
     {
	require_initialization_114_reduce_same = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_same();
	cnst_init_137_reduce_same();
	imported_modules_init_94_reduce_same();
	method_init_76_reduce_same();
	toplevel_init_63_reduce_same();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_same()
{
   module_initialization_70___object(((long) 0), "REDUCE_SAME");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "REDUCE_SAME");
   module_initialization_70___reader(((long) 0), "REDUCE_SAME");
   module_initialization_70___r4_equivalence_6_2(((long) 0), "REDUCE_SAME");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_same()
{
   {
      obj_t cnst_port_138_1515;
      cnst_port_138_1515 = open_input_string(string1766_reduce_same);
      {
	 long i_1516;
	 i_1516 = ((long) 0);
       loop_1517:
	 {
	    bool_t test1767_1518;
	    test1767_1518 = (i_1516 == ((long) -1));
	    if (test1767_1518)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1768_1519;
		    {
		       obj_t list1769_1520;
		       {
			  obj_t arg1770_1521;
			  arg1770_1521 = BNIL;
			  list1769_1520 = MAKE_PAIR(cnst_port_138_1515, arg1770_1521);
		       }
		       arg1768_1519 = read___reader(list1769_1520);
		    }
		    CNST_TABLE_SET(i_1516, arg1768_1519);
		 }
		 {
		    int aux_1522;
		    {
		       long aux_1543;
		       aux_1543 = (i_1516 - ((long) 1));
		       aux_1522 = (int) (aux_1543);
		    }
		    {
		       long i_1546;
		       i_1546 = (long) (aux_1522);
		       i_1516 = i_1546;
		       goto loop_1517;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_reduce_same()
{
   return BUNSPEC;
}


/* same-node*? */ bool_t 
same_node___136_reduce_same(obj_t node1_43, obj_t node2_44, obj_t alias_45)
{
 same_node___136_reduce_same:
   if (NULLP(node1_43))
     {
	return NULLP(node2_44);
     }
   else
     {
	if (NULLP(node2_44))
	  {
	     return ((bool_t) 0);
	  }
	else
	  {
	     bool_t test1493_742;
	     {
		node_t aux_1557;
		node_t aux_1553;
		{
		   obj_t aux_1558;
		   aux_1558 = CAR(node2_44);
		   aux_1557 = (node_t) (aux_1558);
		}
		{
		   obj_t aux_1554;
		   aux_1554 = CAR(node1_43);
		   aux_1553 = (node_t) (aux_1554);
		}
		test1493_742 = same_node__38_reduce_same(aux_1553, aux_1557, alias_45);
	     }
	     if (test1493_742)
	       {
		  {
		     obj_t node2_1565;
		     obj_t node1_1563;
		     node1_1563 = CDR(node1_43);
		     node2_1565 = CDR(node2_44);
		     node2_44 = node2_1565;
		     node1_43 = node1_1563;
		     goto same_node___136_reduce_same;
		  }
	       }
	     else
	       {
		  return ((bool_t) 0);
	       }
	  }
     }
}


/* aliased? */ bool_t 
aliased__149_reduce_same(variable_t var1_46, variable_t var2_47, obj_t alias_48)
{
   {
      obj_t alias_747;
      alias_747 = alias_48;
    loop_748:
      if (NULLP(alias_747))
	{
	   return ((bool_t) 0);
	}
      else
	{
	   bool_t test_1569;
	   {
	      obj_t aux_1574;
	      obj_t aux_1570;
	      aux_1574 = (obj_t) (var1_46);
	      {
		 obj_t aux_1571;
		 aux_1571 = CAR(alias_747);
		 aux_1570 = CAR(aux_1571);
	      }
	      test_1569 = (aux_1570 == aux_1574);
	   }
	   if (test_1569)
	     {
		{
		   bool_t test_1577;
		   {
		      obj_t aux_1582;
		      obj_t aux_1578;
		      aux_1582 = (obj_t) (var2_47);
		      {
			 obj_t aux_1579;
			 aux_1579 = CAR(alias_747);
			 aux_1578 = CDR(aux_1579);
		      }
		      test_1577 = (aux_1578 == aux_1582);
		   }
		   if (test_1577)
		     {
			return ((bool_t) 1);
		     }
		   else
		     {
			obj_t alias_1585;
			alias_1585 = CDR(alias_747);
			alias_747 = alias_1585;
			goto loop_748;
		     }
		}
	     }
	   else
	     {
		bool_t test_1587;
		{
		   obj_t aux_1592;
		   obj_t aux_1588;
		   aux_1592 = (obj_t) (var2_47);
		   {
		      obj_t aux_1589;
		      aux_1589 = CAR(alias_747);
		      aux_1588 = CAR(aux_1589);
		   }
		   test_1587 = (aux_1588 == aux_1592);
		}
		if (test_1587)
		  {
		     {
			bool_t test_1595;
			{
			   obj_t aux_1600;
			   obj_t aux_1596;
			   aux_1600 = (obj_t) (var1_46);
			   {
			      obj_t aux_1597;
			      aux_1597 = CAR(alias_747);
			      aux_1596 = CDR(aux_1597);
			   }
			   test_1595 = (aux_1596 == aux_1600);
			}
			if (test_1595)
			  {
			     return ((bool_t) 1);
			  }
			else
			  {
			     obj_t alias_1603;
			     alias_1603 = CDR(alias_747);
			     alias_747 = alias_1603;
			     goto loop_748;
			  }
		     }
		  }
		else
		  {
		     {
			obj_t alias_1605;
			alias_1605 = CDR(alias_747);
			alias_747 = alias_1605;
			goto loop_748;
		     }
		  }
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_reduce_same()
{
   add_generic__110___object(same_node__env_162_reduce_same, same_node__default1478_env_125_reduce_same);
   add_inlined_method__244___object(same_node__env_162_reduce_same, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(same_node__env_162_reduce_same, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(same_node__env_162_reduce_same, var_ast_node, ((long) 2));
   add_inlined_method__244___object(same_node__env_162_reduce_same, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(same_node__env_162_reduce_same, app_ly_162_ast_node, ((long) 4));
   add_inlined_method__244___object(same_node__env_162_reduce_same, funcall_ast_node, ((long) 5));
   add_inlined_method__244___object(same_node__env_162_reduce_same, app_ast_node, ((long) 6));
   add_inlined_method__244___object(same_node__env_162_reduce_same, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(same_node__env_162_reduce_same, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(same_node__env_162_reduce_same, conditional_ast_node, ((long) 9));
   add_inlined_method__244___object(same_node__env_162_reduce_same, fail_ast_node, ((long) 10));
   {
      long aux_1619;
      aux_1619 = add_inlined_method__244___object(same_node__env_162_reduce_same, let_var_6_ast_node, ((long) 11));
      return BINT(aux_1619);
   }
}


/* same-node? */ bool_t 
same_node__38_reduce_same(node_t node1_1, node_t node2_2, obj_t alias_3)
{
   {
      obj_t method1612_1094;
      obj_t class1617_1095;
      {
	 obj_t arg1620_1092;
	 obj_t arg1621_1093;
	 {
	    object_t obj_1327;
	    obj_1327 = (object_t) (node1_1);
	    {
	       obj_t pre_method_105_1328;
	       pre_method_105_1328 = PROCEDURE_REF(same_node__env_162_reduce_same, ((long) 2));
	       if (INTEGERP(pre_method_105_1328))
		 {
		    PROCEDURE_SET(same_node__env_162_reduce_same, ((long) 2), BUNSPEC);
		    arg1620_1092 = pre_method_105_1328;
		 }
	       else
		 {
		    long obj_class_num_177_1333;
		    obj_class_num_177_1333 = TYPE(obj_1327);
		    {
		       obj_t arg1177_1334;
		       arg1177_1334 = PROCEDURE_REF(same_node__env_162_reduce_same, ((long) 1));
		       {
			  long arg1178_1338;
			  {
			     long arg1179_1339;
			     arg1179_1339 = OBJECT_TYPE;
			     arg1178_1338 = (obj_class_num_177_1333 - arg1179_1339);
			  }
			  arg1620_1092 = VECTOR_REF(arg1177_1334, arg1178_1338);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1344;
	    object_1344 = (object_t) (node1_1);
	    {
	       long arg1180_1345;
	       {
		  long arg1181_1346;
		  long arg1182_1347;
		  arg1181_1346 = TYPE(object_1344);
		  arg1182_1347 = OBJECT_TYPE;
		  arg1180_1345 = (arg1181_1346 - arg1182_1347);
	       }
	       {
		  obj_t vector_1351;
		  vector_1351 = _classes__134___object;
		  arg1621_1093 = VECTOR_REF(vector_1351, arg1180_1345);
	       }
	    }
	 }
	 {
	    obj_t aux_1637;
	    method1612_1094 = arg1620_1092;
	    class1617_1095 = arg1621_1093;
	    {
	       if (INTEGERP(method1612_1094))
		 {
		    switch ((long) CINT(method1612_1094))
		      {
		      case ((long) 0):
			 {
			    atom_t node_1101;
			    node_1101 = (atom_t) (node1_1);
			    {
			       bool_t _andtest_1435_1104;
			       _andtest_1435_1104 = is_a__118___object((obj_t) (node2_2), atom_ast_node);
			       if (_andtest_1435_1104)
				 {
				    bool_t test_1644;
				    {
				       obj_t aux_1650;
				       obj_t aux_1645;
				       {
					  type_t aux_1651;
					  aux_1651 = (((node_t) CREF(node2_2))->type);
					  aux_1650 = (obj_t) (aux_1651);
				       }
				       {
					  type_t aux_1646;
					  {
					     node_t obj_1354;
					     obj_1354 = (node_t) (node_1101);
					     aux_1646 = (((node_t) CREF(obj_1354))->type);
					  }
					  aux_1645 = (obj_t) (aux_1646);
				       }
				       test_1644 = (aux_1645 == aux_1650);
				    }
				    if (test_1644)
				      {
					 bool_t aux_1655;
					 {
					    obj_t aux_1656;
					    {
					       atom_t obj_1359;
					       obj_1359 = (atom_t) (node2_2);
					       aux_1656 = (((atom_t) CREF(obj_1359))->value);
					    }
					    aux_1655 = equal__25___r4_equivalence_6_2((((atom_t) CREF(node_1101))->value), aux_1656);
					 }
					 aux_1637 = BBOOL(aux_1655);
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t node_1110;
			    node_1110 = (kwote_t) (node1_1);
			    {
			       bool_t _andtest_1437_1113;
			       _andtest_1437_1113 = is_a__118___object((obj_t) (node2_2), kwote_ast_node);
			       if (_andtest_1437_1113)
				 {
				    bool_t test_1666;
				    {
				       obj_t aux_1672;
				       obj_t aux_1667;
				       {
					  type_t aux_1673;
					  aux_1673 = (((node_t) CREF(node2_2))->type);
					  aux_1672 = (obj_t) (aux_1673);
				       }
				       {
					  type_t aux_1668;
					  {
					     node_t obj_1361;
					     obj_1361 = (node_t) (node_1110);
					     aux_1668 = (((node_t) CREF(obj_1361))->type);
					  }
					  aux_1667 = (obj_t) (aux_1668);
				       }
				       test_1666 = (aux_1667 == aux_1672);
				    }
				    if (test_1666)
				      {
					 bool_t aux_1677;
					 {
					    obj_t aux_1678;
					    {
					       kwote_t obj_1366;
					       obj_1366 = (kwote_t) (node2_2);
					       aux_1678 = (((kwote_t) CREF(obj_1366))->value);
					    }
					    aux_1677 = equal__25___r4_equivalence_6_2((((kwote_t) CREF(node_1110))->value), aux_1678);
					 }
					 aux_1637 = BBOOL(aux_1677);
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1119;
			    node_1119 = (var_t) (node1_1);
			    {
			       bool_t _andtest_1439_1122;
			       _andtest_1439_1122 = is_a__118___object((obj_t) (node2_2), var_ast_node);
			       if (_andtest_1439_1122)
				 {
				    bool_t test_1688;
				    {
				       obj_t aux_1692;
				       obj_t aux_1689;
				       aux_1692 = CNST_TABLE_REF(((long) 0));
				       {
					  variable_t arg1648_1134;
					  arg1648_1134 = (((var_t) CREF(node_1119))->variable);
					  aux_1689 = (((variable_t) CREF(arg1648_1134))->access);
				       }
				       test_1688 = (aux_1689 == aux_1692);
				    }
				    if (test_1688)
				      {
					 bool_t test_1695;
					 {
					    obj_t aux_1701;
					    obj_t aux_1696;
					    {
					       type_t aux_1702;
					       aux_1702 = (((node_t) CREF(node2_2))->type);
					       aux_1701 = (obj_t) (aux_1702);
					    }
					    {
					       type_t aux_1697;
					       {
						  node_t obj_1372;
						  obj_1372 = (node_t) (node_1119);
						  aux_1697 = (((node_t) CREF(obj_1372))->type);
					       }
					       aux_1696 = (obj_t) (aux_1697);
					    }
					    test_1695 = (aux_1696 == aux_1701);
					 }
					 if (test_1695)
					   {
					      bool_t _ortest_1442_1125;
					      {
						 obj_t aux_1710;
						 obj_t aux_1706;
						 {
						    variable_t aux_1711;
						    {
						       var_t obj_1377;
						       obj_1377 = (var_t) (node2_2);
						       aux_1711 = (((var_t) CREF(obj_1377))->variable);
						    }
						    aux_1710 = (obj_t) (aux_1711);
						 }
						 {
						    variable_t aux_1707;
						    aux_1707 = (((var_t) CREF(node_1119))->variable);
						    aux_1706 = (obj_t) (aux_1707);
						 }
						 _ortest_1442_1125 = (aux_1706 == aux_1710);
					      }
					      if (_ortest_1442_1125)
						{
						   aux_1637 = BBOOL(_ortest_1442_1125);
						}
					      else
						{
						   bool_t aux_1718;
						   {
						      variable_t aux_1719;
						      {
							 var_t obj_1381;
							 obj_1381 = (var_t) (node2_2);
							 aux_1719 = (((var_t) CREF(obj_1381))->variable);
						      }
						      aux_1718 = aliased__149_reduce_same((((var_t) CREF(node_1119))->variable), aux_1719, alias_3);
						   }
						   aux_1637 = BBOOL(aux_1718);
						}
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1135;
			    node_1135 = (sequence_t) (node1_1);
			    {
			       bool_t _andtest_1443_1138;
			       _andtest_1443_1138 = is_a__118___object((obj_t) (node2_2), sequence_ast_node);
			       if (_andtest_1443_1138)
				 {
				    bool_t test_1729;
				    {
				       obj_t aux_1735;
				       obj_t aux_1730;
				       {
					  type_t aux_1736;
					  aux_1736 = (((node_t) CREF(node2_2))->type);
					  aux_1735 = (obj_t) (aux_1736);
				       }
				       {
					  type_t aux_1731;
					  {
					     node_t obj_1383;
					     obj_1383 = (node_t) (node_1135);
					     aux_1731 = (((node_t) CREF(obj_1383))->type);
					  }
					  aux_1730 = (obj_t) (aux_1731);
				       }
				       test_1729 = (aux_1730 == aux_1735);
				    }
				    if (test_1729)
				      {
					 bool_t aux_1740;
					 {
					    obj_t aux_1741;
					    {
					       sequence_t obj_1388;
					       obj_1388 = (sequence_t) (node2_2);
					       aux_1741 = (((sequence_t) CREF(obj_1388))->nodes);
					    }
					    aux_1740 = same_node___136_reduce_same((((sequence_t) CREF(node_1135))->nodes), aux_1741, alias_3);
					 }
					 aux_1637 = BBOOL(aux_1740);
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 4):
			 {
			    app_ly_162_t node_1144;
			    node_1144 = (app_ly_162_t) (node1_1);
			    {
			       bool_t _andtest_1445_1147;
			       _andtest_1445_1147 = is_a__118___object((obj_t) (node2_2), app_ly_162_ast_node);
			       if (_andtest_1445_1147)
				 {
				    bool_t test_1751;
				    {
				       obj_t aux_1757;
				       obj_t aux_1752;
				       {
					  type_t aux_1758;
					  aux_1758 = (((node_t) CREF(node2_2))->type);
					  aux_1757 = (obj_t) (aux_1758);
				       }
				       {
					  type_t aux_1753;
					  {
					     node_t obj_1390;
					     obj_1390 = (node_t) (node_1144);
					     aux_1753 = (((node_t) CREF(obj_1390))->type);
					  }
					  aux_1752 = (obj_t) (aux_1753);
				       }
				       test_1751 = (aux_1752 == aux_1757);
				    }
				    if (test_1751)
				      {
					 bool_t _andtest_1447_1149;
					 {
					    node_t aux_1762;
					    {
					       app_ly_162_t obj_1395;
					       obj_1395 = (app_ly_162_t) (node2_2);
					       aux_1762 = (((app_ly_162_t) CREF(obj_1395))->fun);
					    }
					    _andtest_1447_1149 = same_node__38_reduce_same((((app_ly_162_t) CREF(node_1144))->fun), aux_1762, alias_3);
					 }
					 if (_andtest_1447_1149)
					   {
					      bool_t aux_1768;
					      {
						 node_t aux_1769;
						 {
						    app_ly_162_t obj_1397;
						    obj_1397 = (app_ly_162_t) (node2_2);
						    aux_1769 = (((app_ly_162_t) CREF(obj_1397))->arg);
						 }
						 aux_1768 = same_node__38_reduce_same((((app_ly_162_t) CREF(node_1144))->arg), aux_1769, alias_3);
					      }
					      aux_1637 = BBOOL(aux_1768);
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    funcall_t node_1156;
			    node_1156 = (funcall_t) (node1_1);
			    {
			       bool_t _andtest_1448_1159;
			       _andtest_1448_1159 = is_a__118___object((obj_t) (node2_2), funcall_ast_node);
			       if (_andtest_1448_1159)
				 {
				    bool_t test_1779;
				    {
				       obj_t aux_1785;
				       obj_t aux_1780;
				       {
					  type_t aux_1786;
					  aux_1786 = (((node_t) CREF(node2_2))->type);
					  aux_1785 = (obj_t) (aux_1786);
				       }
				       {
					  type_t aux_1781;
					  {
					     node_t obj_1399;
					     obj_1399 = (node_t) (node_1156);
					     aux_1781 = (((node_t) CREF(obj_1399))->type);
					  }
					  aux_1780 = (obj_t) (aux_1781);
				       }
				       test_1779 = (aux_1780 == aux_1785);
				    }
				    if (test_1779)
				      {
					 bool_t _andtest_1450_1161;
					 {
					    node_t aux_1790;
					    {
					       funcall_t obj_1404;
					       obj_1404 = (funcall_t) (node2_2);
					       aux_1790 = (((funcall_t) CREF(obj_1404))->fun);
					    }
					    _andtest_1450_1161 = same_node__38_reduce_same((((funcall_t) CREF(node_1156))->fun), aux_1790, alias_3);
					 }
					 if (_andtest_1450_1161)
					   {
					      bool_t aux_1796;
					      {
						 obj_t aux_1797;
						 {
						    funcall_t obj_1406;
						    obj_1406 = (funcall_t) (node2_2);
						    aux_1797 = (((funcall_t) CREF(obj_1406))->args);
						 }
						 aux_1796 = same_node___136_reduce_same((((funcall_t) CREF(node_1156))->args), aux_1797, alias_3);
					      }
					      aux_1637 = BBOOL(aux_1796);
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    app_t node_1168;
			    node_1168 = (app_t) (node1_1);
			    {
			       bool_t _andtest_1451_1171;
			       _andtest_1451_1171 = is_a__118___object((obj_t) (node2_2), app_ast_node);
			       if (_andtest_1451_1171)
				 {
				    bool_t test_1807;
				    {
				       obj_t aux_1813;
				       obj_t aux_1808;
				       {
					  type_t aux_1814;
					  aux_1814 = (((node_t) CREF(node2_2))->type);
					  aux_1813 = (obj_t) (aux_1814);
				       }
				       {
					  type_t aux_1809;
					  {
					     node_t obj_1408;
					     obj_1408 = (node_t) (node_1168);
					     aux_1809 = (((node_t) CREF(obj_1408))->type);
					  }
					  aux_1808 = (obj_t) (aux_1809);
				       }
				       test_1807 = (aux_1808 == aux_1813);
				    }
				    if (test_1807)
				      {
					 bool_t _andtest_1453_1173;
					 {
					    node_t aux_1822;
					    node_t aux_1818;
					    {
					       var_t aux_1823;
					       {
						  app_t obj_1413;
						  obj_1413 = (app_t) (node2_2);
						  aux_1823 = (((app_t) CREF(obj_1413))->fun);
					       }
					       aux_1822 = (node_t) (aux_1823);
					    }
					    {
					       var_t aux_1819;
					       aux_1819 = (((app_t) CREF(node_1168))->fun);
					       aux_1818 = (node_t) (aux_1819);
					    }
					    _andtest_1453_1173 = same_node__38_reduce_same(aux_1818, aux_1822, alias_3);
					 }
					 if (_andtest_1453_1173)
					   {
					      bool_t aux_1829;
					      {
						 obj_t aux_1830;
						 {
						    app_t obj_1415;
						    obj_1415 = (app_t) (node2_2);
						    aux_1830 = (((app_t) CREF(obj_1415))->args);
						 }
						 aux_1829 = same_node___136_reduce_same((((app_t) CREF(node_1168))->args), aux_1830, alias_3);
					      }
					      aux_1637 = BBOOL(aux_1829);
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1180;
			    node_1180 = (pragma_t) (node1_1);
			    {
			       bool_t _andtest_1454_1183;
			       _andtest_1454_1183 = is_a__118___object((obj_t) (node2_2), pragma_ast_node);
			       if (_andtest_1454_1183)
				 {
				    bool_t test_1840;
				    {
				       obj_t aux_1846;
				       obj_t aux_1841;
				       {
					  type_t aux_1847;
					  aux_1847 = (((node_t) CREF(node2_2))->type);
					  aux_1846 = (obj_t) (aux_1847);
				       }
				       {
					  type_t aux_1842;
					  {
					     node_t obj_1417;
					     obj_1417 = (node_t) (node_1180);
					     aux_1842 = (((node_t) CREF(obj_1417))->type);
					  }
					  aux_1841 = (obj_t) (aux_1842);
				       }
				       test_1840 = (aux_1841 == aux_1846);
				    }
				    if (test_1840)
				      {
					 bool_t _andtest_1456_1185;
					 {
					    obj_t aux_1853;
					    obj_t aux_1851;
					    {
					       pragma_t obj_1422;
					       obj_1422 = (pragma_t) (node2_2);
					       aux_1853 = (((pragma_t) CREF(obj_1422))->format);
					    }
					    aux_1851 = (((pragma_t) CREF(node_1180))->format);
					    _andtest_1456_1185 = bigloo_strcmp(aux_1851, aux_1853);
					 }
					 if (_andtest_1456_1185)
					   {
					      bool_t aux_1858;
					      {
						 obj_t aux_1859;
						 {
						    pragma_t obj_1426;
						    obj_1426 = (pragma_t) (node2_2);
						    aux_1859 = (((pragma_t) CREF(obj_1426))->args);
						 }
						 aux_1858 = same_node___136_reduce_same((((pragma_t) CREF(node_1180))->args), aux_1859, alias_3);
					      }
					      aux_1637 = BBOOL(aux_1858);
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1192;
			    node_1192 = (cast_t) (node1_1);
			    {
			       bool_t _andtest_1457_1195;
			       _andtest_1457_1195 = is_a__118___object((obj_t) (node2_2), cast_ast_node);
			       if (_andtest_1457_1195)
				 {
				    bool_t test_1869;
				    {
				       obj_t aux_1875;
				       obj_t aux_1870;
				       {
					  type_t aux_1876;
					  aux_1876 = (((node_t) CREF(node2_2))->type);
					  aux_1875 = (obj_t) (aux_1876);
				       }
				       {
					  type_t aux_1871;
					  {
					     node_t obj_1428;
					     obj_1428 = (node_t) (node_1192);
					     aux_1871 = (((node_t) CREF(obj_1428))->type);
					  }
					  aux_1870 = (obj_t) (aux_1871);
				       }
				       test_1869 = (aux_1870 == aux_1875);
				    }
				    if (test_1869)
				      {
					 bool_t aux_1880;
					 {
					    node_t aux_1881;
					    {
					       cast_t obj_1433;
					       obj_1433 = (cast_t) (node2_2);
					       aux_1881 = (((cast_t) CREF(obj_1433))->arg);
					    }
					    aux_1880 = same_node__38_reduce_same((((cast_t) CREF(node_1192))->arg), aux_1881, alias_3);
					 }
					 aux_1637 = BBOOL(aux_1880);
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 9):
			 {
			    conditional_t node_1201;
			    node_1201 = (conditional_t) (node1_1);
			    {
			       bool_t _andtest_1459_1204;
			       _andtest_1459_1204 = is_a__118___object((obj_t) (node2_2), conditional_ast_node);
			       if (_andtest_1459_1204)
				 {
				    bool_t test_1891;
				    {
				       obj_t aux_1897;
				       obj_t aux_1892;
				       {
					  type_t aux_1898;
					  aux_1898 = (((node_t) CREF(node2_2))->type);
					  aux_1897 = (obj_t) (aux_1898);
				       }
				       {
					  type_t aux_1893;
					  {
					     node_t obj_1435;
					     obj_1435 = (node_t) (node_1201);
					     aux_1893 = (((node_t) CREF(obj_1435))->type);
					  }
					  aux_1892 = (obj_t) (aux_1893);
				       }
				       test_1891 = (aux_1892 == aux_1897);
				    }
				    if (test_1891)
				      {
					 bool_t _andtest_1461_1206;
					 {
					    node_t aux_1902;
					    {
					       conditional_t obj_1440;
					       obj_1440 = (conditional_t) (node2_2);
					       aux_1902 = (((conditional_t) CREF(obj_1440))->false);
					    }
					    _andtest_1461_1206 = same_node__38_reduce_same((((conditional_t) CREF(node_1201))->false), aux_1902, alias_3);
					 }
					 if (_andtest_1461_1206)
					   {
					      bool_t _andtest_1462_1207;
					      {
						 node_t aux_1908;
						 {
						    conditional_t obj_1442;
						    obj_1442 = (conditional_t) (node2_2);
						    aux_1908 = (((conditional_t) CREF(obj_1442))->true);
						 }
						 _andtest_1462_1207 = same_node__38_reduce_same((((conditional_t) CREF(node_1201))->true), aux_1908, alias_3);
					      }
					      if (_andtest_1462_1207)
						{
						   bool_t aux_1914;
						   {
						      node_t aux_1915;
						      {
							 conditional_t obj_1444;
							 obj_1444 = (conditional_t) (node2_2);
							 aux_1915 = (((conditional_t) CREF(obj_1444))->test);
						      }
						      aux_1914 = same_node__38_reduce_same((((conditional_t) CREF(node_1201))->test), aux_1915, alias_3);
						   }
						   aux_1637 = BBOOL(aux_1914);
						}
					      else
						{
						   aux_1637 = BFALSE;
						}
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    fail_t node_1216;
			    node_1216 = (fail_t) (node1_1);
			    {
			       bool_t _andtest_1463_1219;
			       _andtest_1463_1219 = is_a__118___object((obj_t) (node2_2), fail_ast_node);
			       if (_andtest_1463_1219)
				 {
				    bool_t test_1925;
				    {
				       obj_t aux_1931;
				       obj_t aux_1926;
				       {
					  type_t aux_1932;
					  aux_1932 = (((node_t) CREF(node2_2))->type);
					  aux_1931 = (obj_t) (aux_1932);
				       }
				       {
					  type_t aux_1927;
					  {
					     node_t obj_1446;
					     obj_1446 = (node_t) (node_1216);
					     aux_1927 = (((node_t) CREF(obj_1446))->type);
					  }
					  aux_1926 = (obj_t) (aux_1927);
				       }
				       test_1925 = (aux_1926 == aux_1931);
				    }
				    if (test_1925)
				      {
					 bool_t _andtest_1465_1221;
					 {
					    node_t aux_1936;
					    {
					       fail_t obj_1451;
					       obj_1451 = (fail_t) (node2_2);
					       aux_1936 = (((fail_t) CREF(obj_1451))->msg);
					    }
					    _andtest_1465_1221 = same_node__38_reduce_same((((fail_t) CREF(node_1216))->msg), aux_1936, alias_3);
					 }
					 if (_andtest_1465_1221)
					   {
					      bool_t _andtest_1466_1222;
					      {
						 node_t aux_1942;
						 {
						    fail_t obj_1453;
						    obj_1453 = (fail_t) (node2_2);
						    aux_1942 = (((fail_t) CREF(obj_1453))->proc);
						 }
						 _andtest_1466_1222 = same_node__38_reduce_same((((fail_t) CREF(node_1216))->proc), aux_1942, alias_3);
					      }
					      if (_andtest_1466_1222)
						{
						   bool_t aux_1948;
						   {
						      node_t aux_1949;
						      {
							 fail_t obj_1455;
							 obj_1455 = (fail_t) (node2_2);
							 aux_1949 = (((fail_t) CREF(obj_1455))->obj);
						      }
						      aux_1948 = same_node__38_reduce_same((((fail_t) CREF(node_1216))->obj), aux_1949, alias_3);
						   }
						   aux_1637 = BBOOL(aux_1948);
						}
					      else
						{
						   aux_1637 = BFALSE;
						}
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    let_var_6_t node_1231;
			    node_1231 = (let_var_6_t) (node1_1);
			    {
			       bool_t _andtest_1467_1234;
			       _andtest_1467_1234 = is_a__118___object((obj_t) (node2_2), let_var_6_ast_node);
			       if (_andtest_1467_1234)
				 {
				    bool_t test_1959;
				    {
				       obj_t aux_1965;
				       obj_t aux_1960;
				       {
					  type_t aux_1966;
					  aux_1966 = (((node_t) CREF(node2_2))->type);
					  aux_1965 = (obj_t) (aux_1966);
				       }
				       {
					  type_t aux_1961;
					  {
					     node_t obj_1457;
					     obj_1457 = (node_t) (node_1231);
					     aux_1961 = (((node_t) CREF(obj_1457))->type);
					  }
					  aux_1960 = (obj_t) (aux_1961);
				       }
				       test_1959 = (aux_1960 == aux_1965);
				    }
				    if (test_1959)
				      {
					 bool_t test_1970;
					 {
					    obj_t aux_1976;
					    obj_t aux_1971;
					    {
					       long aux_1977;
					       {
						  obj_t aux_1978;
						  {
						     let_var_6_t obj_1462;
						     obj_1462 = (let_var_6_t) (node2_2);
						     aux_1978 = (((let_var_6_t) CREF(obj_1462))->bindings);
						  }
						  aux_1977 = list_length(aux_1978);
					       }
					       aux_1976 = BINT(aux_1977);
					    }
					    {
					       long aux_1972;
					       aux_1972 = list_length((((let_var_6_t) CREF(node_1231))->bindings));
					       aux_1971 = BINT(aux_1972);
					    }
					    test_1970 = (aux_1971 == aux_1976);
					 }
					 if (test_1970)
					   {
					      obj_t new_alias_67_1237;
					      {
						 obj_t arg1730_1264;
						 {
						    obj_t ll1470_1265;
						    obj_t ll1471_1266;
						    ll1470_1265 = (((let_var_6_t) CREF(node_1231))->bindings);
						    {
						       let_var_6_t obj_1466;
						       obj_1466 = (let_var_6_t) (node2_2);
						       ll1471_1266 = (((let_var_6_t) CREF(obj_1466))->bindings);
						    }
						    if (NULLP(ll1470_1265))
						      {
							 arg1730_1264 = BNIL;
						      }
						    else
						      {
							 obj_t head1472_1268;
							 head1472_1268 = MAKE_PAIR(BNIL, BNIL);
							 {
							    obj_t ll1470_1269;
							    obj_t ll1471_1270;
							    obj_t tail1473_1271;
							    ll1470_1269 = ll1470_1265;
							    ll1471_1270 = ll1471_1266;
							    tail1473_1271 = head1472_1268;
							  lname1475_1272:
							    if (NULLP(ll1470_1269))
							      {
								 arg1730_1264 = CDR(head1472_1268);
							      }
							    else
							      {
								 obj_t newtail1474_1274;
								 {
								    obj_t arg1739_1277;
								    {
								       obj_t aux_1997;
								       obj_t aux_1993;
								       {
									  obj_t aux_1998;
									  aux_1998 = CAR(ll1471_1270);
									  aux_1997 = CAR(aux_1998);
								       }
								       {
									  obj_t aux_1994;
									  aux_1994 = CAR(ll1470_1269);
									  aux_1993 = CAR(aux_1994);
								       }
								       arg1739_1277 = MAKE_PAIR(aux_1993, aux_1997);
								    }
								    newtail1474_1274 = MAKE_PAIR(arg1739_1277, BNIL);
								 }
								 SET_CDR(tail1473_1271, newtail1474_1274);
								 {
								    obj_t tail1473_2008;
								    obj_t ll1471_2006;
								    obj_t ll1470_2004;
								    ll1470_2004 = CDR(ll1470_1269);
								    ll1471_2006 = CDR(ll1471_1270);
								    tail1473_2008 = newtail1474_1274;
								    tail1473_1271 = tail1473_2008;
								    ll1471_1270 = ll1471_2006;
								    ll1470_1269 = ll1470_2004;
								    goto lname1475_1272;
								 }
							      }
							 }
						      }
						 }
						 new_alias_67_1237 = append_2_18___r4_pairs_and_lists_6_3(alias_3, arg1730_1264);
					      }
					      {
						 bool_t _andtest_1476_1238;
						 {
						    node_t aux_2010;
						    {
						       let_var_6_t obj_1485;
						       obj_1485 = (let_var_6_t) (node2_2);
						       aux_2010 = (((let_var_6_t) CREF(obj_1485))->body);
						    }
						    _andtest_1476_1238 = same_node__38_reduce_same((((let_var_6_t) CREF(node_1231))->body), aux_2010, new_alias_67_1237);
						 }
						 if (_andtest_1476_1238)
						   {
						      obj_t bindings1_1239;
						      obj_t bindings2_1240;
						      {
							 bool_t aux_2016;
							 bindings1_1239 = (((let_var_6_t) CREF(node_1231))->bindings);
							 {
							    let_var_6_t obj_1487;
							    obj_1487 = (let_var_6_t) (node2_2);
							    bindings2_1240 = (((let_var_6_t) CREF(obj_1487))->bindings);
							 }
						       loop_1241:
							 if (NULLP(bindings1_1239))
							   {
							      aux_2016 = ((bool_t) 1);
							   }
							 else
							   {
							      bool_t test_2019;
							      {
								 bool_t test_2020;
								 {
								    obj_t aux_2028;
								    obj_t aux_2021;
								    aux_2028 = CNST_TABLE_REF(((long) 0));
								    {
								       local_t obj_1491;
								       {
									  obj_t aux_2022;
									  {
									     obj_t aux_2023;
									     aux_2023 = CAR(bindings1_1239);
									     aux_2022 = CAR(aux_2023);
									  }
									  obj_1491 = (local_t) (aux_2022);
								       }
								       aux_2021 = (((local_t) CREF(obj_1491))->access);
								    }
								    test_2020 = (aux_2021 == aux_2028);
								 }
								 if (test_2020)
								   {
								      obj_t aux_2038;
								      obj_t aux_2031;
								      aux_2038 = CNST_TABLE_REF(((long) 0));
								      {
									 local_t obj_1496;
									 {
									    obj_t aux_2032;
									    {
									       obj_t aux_2033;
									       aux_2033 = CAR(bindings2_1240);
									       aux_2032 = CAR(aux_2033);
									    }
									    obj_1496 = (local_t) (aux_2032);
									 }
									 aux_2031 = (((local_t) CREF(obj_1496))->access);
								      }
								      test_2019 = (aux_2031 == aux_2038);
								   }
								 else
								   {
								      test_2019 = ((bool_t) 0);
								   }
							      }
							      if (test_2019)
								{
								   bool_t test1710_1246;
								   {
								      node_t aux_2047;
								      node_t aux_2041;
								      {
									 obj_t aux_2048;
									 {
									    obj_t aux_2049;
									    aux_2049 = CAR(bindings2_1240);
									    aux_2048 = CDR(aux_2049);
									 }
									 aux_2047 = (node_t) (aux_2048);
								      }
								      {
									 obj_t aux_2042;
									 {
									    obj_t aux_2043;
									    aux_2043 = CAR(bindings1_1239);
									    aux_2042 = CDR(aux_2043);
									 }
									 aux_2041 = (node_t) (aux_2042);
								      }
								      test1710_1246 = same_node__38_reduce_same(aux_2041, aux_2047, alias_3);
								   }
								   if (test1710_1246)
								     {
									{
									   obj_t bindings2_2057;
									   obj_t bindings1_2055;
									   bindings1_2055 = CDR(bindings1_1239);
									   bindings2_2057 = CDR(bindings2_1240);
									   bindings2_1240 = bindings2_2057;
									   bindings1_1239 = bindings1_2055;
									   goto loop_1241;
									}
								     }
								   else
								     {
									aux_2016 = ((bool_t) 0);
								     }
								}
							      else
								{
								   aux_2016 = ((bool_t) 0);
								}
							   }
							 aux_1637 = BBOOL(aux_2016);
						      }
						   }
						 else
						   {
						      aux_1637 = BFALSE;
						   }
					      }
					   }
					 else
					   {
					      aux_1637 = BFALSE;
					   }
				      }
				    else
				      {
					 aux_1637 = BFALSE;
				      }
				 }
			       else
				 {
				    aux_1637 = BFALSE;
				 }
			    }
			 }
			 break;
		      default:
		       case_else1618_1098:
			 if (PROCEDUREP(method1612_1094))
			   {
			      aux_1637 = PROCEDURE_ENTRY(method1612_1094) (method1612_1094, (obj_t) (node1_1), (obj_t) (node2_2), alias_3, BEOA);
			   }
			 else
			   {
			      obj_t fun1611_1090;
			      fun1611_1090 = PROCEDURE_REF(same_node__env_162_reduce_same, ((long) 0));
			      aux_1637 = PROCEDURE_ENTRY(fun1611_1090) (fun1611_1090, (obj_t) (node1_1), (obj_t) (node2_2), alias_3, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1618_1098;
		 }
	    }
	    return CBOOL(aux_1637);
	 }
      }
   }
}


/* _same-node?1765 */ obj_t 
_same_node_1765_138_reduce_same(obj_t env_1507, obj_t node1_1508, obj_t node2_1509, obj_t alias_1510)
{
   {
      bool_t aux_2077;
      aux_2077 = same_node__38_reduce_same((node_t) (node1_1508), (node_t) (node2_1509), alias_1510);
      return BBOOL(aux_2077);
   }
}


/* same-node?-default1478 */ bool_t 
same_node__default1478_45_reduce_same(node_t node1_4, node_t node2_5, obj_t alias_6)
{
   return ((bool_t) 0);
}


/* _same-node?-default1478 */ obj_t 
_same_node__default1478_162_reduce_same(obj_t env_1511, obj_t node1_1512, obj_t node2_1513, obj_t alias_1514)
{
   {
      bool_t aux_2082;
      aux_2082 = same_node__default1478_45_reduce_same((node_t) (node1_1512), (node_t) (node2_1513), alias_1514);
      return BBOOL(aux_2082);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_same()
{
   module_initialization_70_tools_trace(((long) 0), "REDUCE_SAME");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_SAME");
   module_initialization_70_type_type(((long) 0), "REDUCE_SAME");
   module_initialization_70_ast_var(((long) 0), "REDUCE_SAME");
   return module_initialization_70_ast_node(((long) 0), "REDUCE_SAME");
}
