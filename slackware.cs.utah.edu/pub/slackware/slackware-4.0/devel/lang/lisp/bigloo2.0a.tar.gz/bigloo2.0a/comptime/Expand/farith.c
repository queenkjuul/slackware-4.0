/*===========================================================================*/
/*   (Expand/farith.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_expand_farithmetique();
static obj_t _expand_fmax1340_14_expand_farithmetique(obj_t, obj_t, obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t module_initialization_70_expand_farithmetique(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t expand_fmin_160_expand_farithmetique(obj_t, obj_t);
extern obj_t expand_fmax_202_expand_farithmetique(obj_t, obj_t);
static obj_t imported_modules_init_94_expand_farithmetique();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_farithmetique();
extern obj_t make_real(double);
extern obj_t open_input_string(obj_t);
extern obj_t expand_fatan_244_expand_farithmetique(obj_t, obj_t);
static obj_t _expand_fmin1341_3_expand_farithmetique(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_expand_farithmetique = BUNSPEC;
static obj_t _expand_fatan1342_246_expand_farithmetique(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_expand_farithmetique();
static obj_t __cnst[9];

DEFINE_EXPORT_PROCEDURE(expand_fmax_env_69_expand_farithmetique, _expand_fmax1340_14_expand_farithmetique1351, _expand_fmax1340_14_expand_farithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_fatan_env_212_expand_farithmetique, _expand_fatan1342_246_expand_farithmetique1352, _expand_fatan1342_246_expand_farithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_fmin_env_157_expand_farithmetique, _expand_fmin1341_3_expand_farithmetique1353, _expand_fmin1341_3_expand_farithmetique, 0L, 2);
DEFINE_STRING(string1344_expand_farithmetique, string1344_expand_farithmetique1354, "ATAN-2FL ATAN-1FL MINFL MIN MIN-2FL MAXFL LET MAX MAX-2FL ", 58);
DEFINE_STRING(string1343_expand_farithmetique, string1343_expand_farithmetique1355, "Too many arguments provided", 27);


/* module-initialization */ obj_t 
module_initialization_70_expand_farithmetique(long checksum_351, char *from_352)
{
   if (CBOOL(require_initialization_114_expand_farithmetique))
     {
	require_initialization_114_expand_farithmetique = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_farithmetique();
	cnst_init_137_expand_farithmetique();
	imported_modules_init_94_expand_farithmetique();
	method_init_76_expand_farithmetique();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_farithmetique()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_FARITHMETIQUE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_FARITHMETIQUE");
   module_initialization_70___reader(((long) 0), "EXPAND_FARITHMETIQUE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_farithmetique()
{
   {
      obj_t cnst_port_138_343;
      cnst_port_138_343 = open_input_string(string1344_expand_farithmetique);
      {
	 long i_344;
	 i_344 = ((long) 8);
       loop_345:
	 {
	    bool_t test1345_346;
	    test1345_346 = (i_344 == ((long) -1));
	    if (test1345_346)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1347_347;
		    {
		       obj_t list1348_348;
		       {
			  obj_t arg1349_349;
			  arg1349_349 = BNIL;
			  list1348_348 = MAKE_PAIR(cnst_port_138_343, arg1349_349);
		       }
		       arg1347_347 = read___reader(list1348_348);
		    }
		    CNST_TABLE_SET(i_344, arg1347_347);
		 }
		 {
		    int aux_350;
		    {
		       long aux_369;
		       aux_369 = (i_344 - ((long) 1));
		       aux_350 = (int) (aux_369);
		    }
		    {
		       long i_372;
		       i_372 = (long) (aux_350);
		       i_344 = i_372;
		       goto loop_345;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-fmax */ obj_t 
expand_fmax_202_expand_farithmetique(obj_t x_1, obj_t e_2)
{
   {
      obj_t x_57;
      obj_t y_58;
      obj_t x_54;
      obj_t y_55;
      if (PAIRP(x_1))
	{
	   obj_t cdr_109_69_62;
	   cdr_109_69_62 = CDR(x_1);
	   if (PAIRP(cdr_109_69_62))
	     {
		obj_t cdr_113_28_64;
		cdr_113_28_64 = CDR(cdr_109_69_62);
		if (PAIRP(cdr_113_28_64))
		  {
		     bool_t test_382;
		     {
			obj_t aux_383;
			aux_383 = CDR(cdr_113_28_64);
			test_382 = (aux_383 == BNIL);
		     }
		     if (test_382)
		       {
			  x_54 = CAR(cdr_109_69_62);
			  y_55 = CAR(cdr_113_28_64);
			  {
			     bool_t test_386;
			     {
				bool_t test_387;
				if (INTEGERP(x_54))
				  {
				     test_387 = ((bool_t) 1);
				  }
				else
				  {
				     test_387 = REALP(x_54);
				  }
				if (test_387)
				  {
				     if (INTEGERP(y_55))
				       {
					  test_386 = ((bool_t) 1);
				       }
				     else
				       {
					  test_386 = REALP(y_55);
				       }
				  }
				else
				  {
				     test_386 = ((bool_t) 0);
				  }
			     }
			     if (test_386)
			       {
				  {
				     double aux_394;
				     {
					double r1_268;
					double r2_269;
					r1_268 = REAL_TO_DOUBLE(x_54);
					r2_269 = REAL_TO_DOUBLE(y_55);
					if ((r1_268 > r2_269))
					  {
					     aux_394 = r1_268;
					  }
					else
					  {
					     aux_394 = r2_269;
					  }
				     }
				     return make_real(aux_394);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1077_78;
				     {
					obj_t arg1137_79;
					arg1137_79 = CNST_TABLE_REF(((long) 0));
					{
					   obj_t list1143_81;
					   {
					      obj_t arg1144_82;
					      {
						 obj_t arg1145_83;
						 arg1145_83 = MAKE_PAIR(BNIL, BNIL);
						 arg1144_82 = MAKE_PAIR(y_55, arg1145_83);
					      }
					      list1143_81 = MAKE_PAIR(x_54, arg1144_82);
					   }
					   arg1077_78 = cons__138___r4_pairs_and_lists_6_3(arg1137_79, list1143_81);
					}
				     }
				     return PROCEDURE_ENTRY(e_2) (e_2, arg1077_78, e_2, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_57 = CAR(cdr_109_69_62);
			  y_58 = CDR(cdr_109_69_62);
			tag_102_241_59:
			  {
			     obj_t max_86;
			     {
				obj_t arg1221_120;
				arg1221_120 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
				max_86 = mark_symbol_non_user__17_ast_ident(arg1221_120);
			     }
			     {
				obj_t arg1157_87;
				{
				   obj_t arg1161_88;
				   obj_t arg1163_89;
				   obj_t arg1175_90;
				   arg1161_88 = CNST_TABLE_REF(((long) 2));
				   {
				      obj_t arg1191_96;
				      {
					 obj_t arg1195_100;
					 {
					    obj_t arg1201_105;
					    obj_t arg1202_106;
					    arg1201_105 = CNST_TABLE_REF(((long) 0));
					    arg1202_106 = CAR(y_58);
					    {
					       obj_t list1204_108;
					       {
						  obj_t arg1205_109;
						  {
						     obj_t arg1206_110;
						     arg1206_110 = MAKE_PAIR(BNIL, BNIL);
						     arg1205_109 = MAKE_PAIR(arg1202_106, arg1206_110);
						  }
						  list1204_108 = MAKE_PAIR(x_57, arg1205_109);
					       }
					       arg1195_100 = cons__138___r4_pairs_and_lists_6_3(arg1201_105, list1204_108);
					    }
					 }
					 {
					    obj_t list1197_102;
					    {
					       obj_t arg1199_103;
					       arg1199_103 = MAKE_PAIR(BNIL, BNIL);
					       list1197_102 = MAKE_PAIR(arg1195_100, arg1199_103);
					    }
					    arg1191_96 = cons__138___r4_pairs_and_lists_6_3(max_86, list1197_102);
					 }
				      }
				      {
					 obj_t list1193_98;
					 list1193_98 = MAKE_PAIR(BNIL, BNIL);
					 arg1163_89 = cons__138___r4_pairs_and_lists_6_3(arg1191_96, list1193_98);
				      }
				   }
				   {
				      obj_t arg1209_112;
				      obj_t arg1210_113;
				      arg1209_112 = CNST_TABLE_REF(((long) 3));
				      {
					 obj_t arg1216_117;
					 arg1216_117 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					 arg1210_113 = append_2_18___r4_pairs_and_lists_6_3(y_58, arg1216_117);
				      }
				      {
					 obj_t list1211_114;
					 {
					    obj_t arg1213_115;
					    arg1213_115 = MAKE_PAIR(arg1210_113, BNIL);
					    list1211_114 = MAKE_PAIR(max_86, arg1213_115);
					 }
					 arg1175_90 = cons__138___r4_pairs_and_lists_6_3(arg1209_112, list1211_114);
				      }
				   }
				   {
				      obj_t list1177_92;
				      {
					 obj_t arg1187_93;
					 {
					    obj_t arg1188_94;
					    arg1188_94 = MAKE_PAIR(BNIL, BNIL);
					    arg1187_93 = MAKE_PAIR(arg1175_90, arg1188_94);
					 }
					 list1177_92 = MAKE_PAIR(arg1163_89, arg1187_93);
				      }
				      arg1157_87 = cons__138___r4_pairs_and_lists_6_3(arg1161_88, list1177_92);
				   }
				}
				return PROCEDURE_ENTRY(e_2) (e_2, arg1157_87, e_2, BEOA);
			     }
			  }
		       }
		  }
		else
		  {
		     obj_t y_441;
		     obj_t x_439;
		     x_439 = CAR(cdr_109_69_62);
		     y_441 = CDR(cdr_109_69_62);
		     y_58 = y_441;
		     x_57 = x_439;
		     goto tag_102_241_59;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-fmax1340 */ obj_t 
_expand_fmax1340_14_expand_farithmetique(obj_t env_334, obj_t x_335, obj_t e_336)
{
   return expand_fmax_202_expand_farithmetique(x_335, e_336);
}


/* expand-fmin */ obj_t 
expand_fmin_160_expand_farithmetique(obj_t x_3, obj_t e_4)
{
   {
      obj_t x_125;
      obj_t y_126;
      obj_t x_122;
      obj_t y_123;
      if (PAIRP(x_3))
	{
	   obj_t cdr_165_174_130;
	   cdr_165_174_130 = CDR(x_3);
	   if (PAIRP(cdr_165_174_130))
	     {
		obj_t cdr_169_170_132;
		cdr_169_170_132 = CDR(cdr_165_174_130);
		if (PAIRP(cdr_169_170_132))
		  {
		     bool_t test_452;
		     {
			obj_t aux_453;
			aux_453 = CDR(cdr_169_170_132);
			test_452 = (aux_453 == BNIL);
		     }
		     if (test_452)
		       {
			  x_122 = CAR(cdr_165_174_130);
			  y_123 = CAR(cdr_169_170_132);
			  {
			     bool_t test_456;
			     {
				bool_t test_457;
				if (INTEGERP(x_122))
				  {
				     test_457 = ((bool_t) 1);
				  }
				else
				  {
				     test_457 = REALP(x_122);
				  }
				if (test_457)
				  {
				     if (INTEGERP(y_123))
				       {
					  test_456 = ((bool_t) 1);
				       }
				     else
				       {
					  test_456 = REALP(y_123);
				       }
				  }
				else
				  {
				     test_456 = ((bool_t) 0);
				  }
			     }
			     if (test_456)
			       {
				  {
				     double aux_464;
				     {
					double r1_297;
					double r2_298;
					r1_297 = REAL_TO_DOUBLE(x_122);
					r2_298 = REAL_TO_DOUBLE(y_123);
					if ((r1_297 > r2_298))
					  {
					     aux_464 = r2_298;
					  }
					else
					  {
					     aux_464 = r1_297;
					  }
				     }
				     return make_real(aux_464);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1240_146;
				     {
					obj_t arg1241_147;
					arg1241_147 = CNST_TABLE_REF(((long) 4));
					{
					   obj_t list1244_149;
					   {
					      obj_t arg1245_150;
					      {
						 obj_t arg1247_151;
						 arg1247_151 = MAKE_PAIR(BNIL, BNIL);
						 arg1245_150 = MAKE_PAIR(y_123, arg1247_151);
					      }
					      list1244_149 = MAKE_PAIR(x_122, arg1245_150);
					   }
					   arg1240_146 = cons__138___r4_pairs_and_lists_6_3(arg1241_147, list1244_149);
					}
				     }
				     return PROCEDURE_ENTRY(e_4) (e_4, arg1240_146, e_4, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_125 = CAR(cdr_165_174_130);
			  y_126 = CDR(cdr_165_174_130);
			tag_158_23_127:
			  {
			     obj_t min_154;
			     {
				obj_t arg1290_188;
				arg1290_188 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
				min_154 = mark_symbol_non_user__17_ast_ident(arg1290_188);
			     }
			     {
				obj_t arg1250_155;
				{
				   obj_t arg1251_156;
				   obj_t arg1252_157;
				   obj_t arg1253_158;
				   arg1251_156 = CNST_TABLE_REF(((long) 2));
				   {
				      obj_t arg1259_164;
				      {
					 obj_t arg1263_168;
					 {
					    obj_t arg1269_173;
					    obj_t arg1270_174;
					    arg1269_173 = CNST_TABLE_REF(((long) 4));
					    arg1270_174 = CAR(y_126);
					    {
					       obj_t list1273_176;
					       {
						  obj_t arg1274_177;
						  {
						     obj_t arg1277_178;
						     arg1277_178 = MAKE_PAIR(BNIL, BNIL);
						     arg1274_177 = MAKE_PAIR(arg1270_174, arg1277_178);
						  }
						  list1273_176 = MAKE_PAIR(x_125, arg1274_177);
					       }
					       arg1263_168 = cons__138___r4_pairs_and_lists_6_3(arg1269_173, list1273_176);
					    }
					 }
					 {
					    obj_t list1266_170;
					    {
					       obj_t arg1267_171;
					       arg1267_171 = MAKE_PAIR(BNIL, BNIL);
					       list1266_170 = MAKE_PAIR(arg1263_168, arg1267_171);
					    }
					    arg1259_164 = cons__138___r4_pairs_and_lists_6_3(min_154, list1266_170);
					 }
				      }
				      {
					 obj_t list1261_166;
					 list1261_166 = MAKE_PAIR(BNIL, BNIL);
					 arg1252_157 = cons__138___r4_pairs_and_lists_6_3(arg1259_164, list1261_166);
				      }
				   }
				   {
				      obj_t arg1281_180;
				      obj_t arg1282_181;
				      arg1281_180 = CNST_TABLE_REF(((long) 6));
				      {
					 obj_t arg1286_185;
					 arg1286_185 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					 arg1282_181 = append_2_18___r4_pairs_and_lists_6_3(y_126, arg1286_185);
				      }
				      {
					 obj_t list1283_182;
					 {
					    obj_t arg1284_183;
					    arg1284_183 = MAKE_PAIR(arg1282_181, BNIL);
					    list1283_182 = MAKE_PAIR(min_154, arg1284_183);
					 }
					 arg1253_158 = cons__138___r4_pairs_and_lists_6_3(arg1281_180, list1283_182);
				      }
				   }
				   {
				      obj_t list1255_160;
				      {
					 obj_t arg1256_161;
					 {
					    obj_t arg1257_162;
					    arg1257_162 = MAKE_PAIR(BNIL, BNIL);
					    arg1256_161 = MAKE_PAIR(arg1253_158, arg1257_162);
					 }
					 list1255_160 = MAKE_PAIR(arg1252_157, arg1256_161);
				      }
				      arg1250_155 = cons__138___r4_pairs_and_lists_6_3(arg1251_156, list1255_160);
				   }
				}
				return PROCEDURE_ENTRY(e_4) (e_4, arg1250_155, e_4, BEOA);
			     }
			  }
		       }
		  }
		else
		  {
		     obj_t y_511;
		     obj_t x_509;
		     x_509 = CAR(cdr_165_174_130);
		     y_511 = CDR(cdr_165_174_130);
		     y_126 = y_511;
		     x_125 = x_509;
		     goto tag_158_23_127;
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-fmin1341 */ obj_t 
_expand_fmin1341_3_expand_farithmetique(obj_t env_337, obj_t x_338, obj_t e_339)
{
   return expand_fmin_160_expand_farithmetique(x_338, e_339);
}


/* expand-fatan */ obj_t 
expand_fatan_244_expand_farithmetique(obj_t x_5, obj_t e_6)
{
   {
      obj_t x_192;
      obj_t y_193;
      obj_t x_190;
      if (PAIRP(x_5))
	{
	   obj_t cdr_221_6_198;
	   cdr_221_6_198 = CDR(x_5);
	   if (PAIRP(cdr_221_6_198))
	     {
		bool_t test_519;
		{
		   obj_t aux_520;
		   aux_520 = CDR(cdr_221_6_198);
		   test_519 = (aux_520 == BNIL);
		}
		if (test_519)
		  {
		     x_190 = CAR(cdr_221_6_198);
		     {
			bool_t test_523;
			if (INTEGERP(x_190))
			  {
			     test_523 = ((bool_t) 1);
			  }
			else
			  {
			     test_523 = REALP(x_190);
			  }
			if (test_523)
			  {
			     double aux_527;
			     {
				double aux_528;
				aux_528 = REAL_TO_DOUBLE(x_190);
				aux_527 = atan(aux_528);
			     }
			     return make_real(aux_527);
			  }
			else
			  {
			     obj_t arg1307_213;
			     {
				obj_t arg1308_214;
				arg1308_214 = CNST_TABLE_REF(((long) 7));
				{
				   obj_t list1310_216;
				   {
				      obj_t arg1311_217;
				      arg1311_217 = MAKE_PAIR(BNIL, BNIL);
				      list1310_216 = MAKE_PAIR(x_190, arg1311_217);
				   }
				   arg1307_213 = cons__138___r4_pairs_and_lists_6_3(arg1308_214, list1310_216);
				}
			     }
			     return PROCEDURE_ENTRY(e_6) (e_6, arg1307_213, e_6, BEOA);
			  }
		     }
		  }
		else
		  {
		     obj_t cdr_237_223_203;
		     cdr_237_223_203 = CDR(cdr_221_6_198);
		     if (PAIRP(cdr_237_223_203))
		       {
			  bool_t test_542;
			  {
			     obj_t aux_543;
			     aux_543 = CDR(cdr_237_223_203);
			     test_542 = (aux_543 == BNIL);
			  }
			  if (test_542)
			    {
			       x_192 = CAR(cdr_221_6_198);
			       y_193 = CAR(cdr_237_223_203);
			       {
				  bool_t test_546;
				  {
				     bool_t test_547;
				     if (INTEGERP(x_192))
				       {
					  test_547 = ((bool_t) 1);
				       }
				     else
				       {
					  test_547 = REALP(x_192);
				       }
				     if (test_547)
				       {
					  if (INTEGERP(y_193))
					    {
					       test_546 = ((bool_t) 1);
					    }
					  else
					    {
					       test_546 = REALP(y_193);
					    }
				       }
				     else
				       {
					  test_546 = ((bool_t) 0);
				       }
				  }
				  if (test_546)
				    {
				       double aux_554;
				       {
					  double aux_557;
					  double aux_555;
					  aux_557 = REAL_TO_DOUBLE(y_193);
					  aux_555 = REAL_TO_DOUBLE(x_192);
					  aux_554 = atan2(aux_555, aux_557);
				       }
				       return make_real(aux_554);
				    }
				  else
				    {
				       obj_t arg1315_220;
				       {
					  obj_t arg1316_221;
					  arg1316_221 = CNST_TABLE_REF(((long) 8));
					  {
					     obj_t list1320_223;
					     {
						obj_t arg1321_224;
						{
						   obj_t arg1322_225;
						   arg1322_225 = MAKE_PAIR(BNIL, BNIL);
						   arg1321_224 = MAKE_PAIR(y_193, arg1322_225);
						}
						list1320_223 = MAKE_PAIR(x_192, arg1321_224);
					     }
					     arg1315_220 = cons__138___r4_pairs_and_lists_6_3(arg1316_221, list1320_223);
					  }
				       }
				       return PROCEDURE_ENTRY(e_6) (e_6, arg1315_220, e_6, BEOA);
				    }
			       }
			    }
			  else
			    {
			     tag_215_218_195:
			       FAILURE(BNIL, string1343_expand_farithmetique, x_5);
			    }
		       }
		     else
		       {
			  goto tag_215_218_195;
		       }
		  }
	     }
	   else
	     {
		goto tag_215_218_195;
	     }
	}
      else
	{
	   goto tag_215_218_195;
	}
   }
}


/* _expand-fatan1342 */ obj_t 
_expand_fatan1342_246_expand_farithmetique(obj_t env_340, obj_t x_341, obj_t e_342)
{
   return expand_fatan_244_expand_farithmetique(x_341, e_342);
}


/* method-init */ obj_t 
method_init_76_expand_farithmetique()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_farithmetique()
{
   module_initialization_70_type_type(((long) 0), "EXPAND_FARITHMETIQUE");
   return module_initialization_70_ast_ident(((long) 0), "EXPAND_FARITHMETIQUE");
}
