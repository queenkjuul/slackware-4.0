/*===========================================================================*/
/*   (Pp/pp.scm)                                                             */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern char * number__string_214___r4_numbers_6_5(obj_t, obj_t);
static obj_t pp_case_154___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t read_macro_prefix_111___pp(obj_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t indent___pp(obj_t, obj_t, obj_t);
static obj_t list1578___pp = BUNSPEC;
static obj_t list1573___pp = BUNSPEC;
static obj_t list1570___pp = BUNSPEC;
static obj_t list1565___pp = BUNSPEC;
static obj_t list1561___pp = BUNSPEC;
extern obj_t string_to_symbol(char *);
static obj_t list1551___pp = BUNSPEC;
extern obj_t current_output_port;
static obj_t pp_comment_9___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t pp_if_81___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t pp_do_220___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t pp_expr_defun_108___pp(obj_t, obj_t, obj_t, obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
static obj_t loop_1529___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t loop_1528___pp(long, obj_t, obj_t, obj_t, long);
static obj_t pp_and_5___pp(obj_t, obj_t, obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
static obj_t rev_string_append_254___pp(obj_t, long);
static obj_t pp_expr_list_161___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t toplevel_init_63___pp();
static obj_t pp_begin_191___pp(obj_t, obj_t, obj_t, obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t string_to_bstring(char *);
static obj_t pp_expr_14___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t loop___pp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t wr_lst_108___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t out___pp(obj_t, obj_t, obj_t);
static obj_t pp_cond_71___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t spaces___pp(obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t tail2___pp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, long, obj_t, long);
extern obj_t make_string(long, unsigned char);
extern obj_t module_initialization_70___pp(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_substring(obj_t, long, long);
extern obj_t open_output_string();
static obj_t wr___pp(obj_t, obj_t, obj_t, obj_t);
extern obj_t min___r4_numbers_6_5(obj_t, obj_t);
static obj_t reverse_string_append_127___pp(obj_t);
static obj_t pr___pp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t pp___pp(obj_t, obj_t);
static obj_t arg1165___pp(obj_t, obj_t);
static obj_t pp_general_73___pp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t);
obj_t _pp_width__183___pp = BUNSPEC;
static obj_t arg1015___pp(obj_t, obj_t);
static obj_t pp_lambda_212___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t pp_define_115___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t pp_let_126___pp(obj_t, obj_t, obj_t, obj_t);
extern obj_t _2__79___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
static obj_t generic_write_53___pp(obj_t, obj_t, obj_t, obj_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
static obj_t pp_defun_212___pp(obj_t, obj_t, obj_t, obj_t);
static obj_t _pp___pp(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___pp();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
static obj_t require_initialization_114___pp = BUNSPEC;
static bool_t read_macro__3___pp(obj_t);
obj_t _pp_case__242___pp = BUNSPEC;
extern obj_t string_for_read(obj_t);
static obj_t vector_prefix_31___pp(obj_t);
static obj_t cnst_init_137___pp();
static obj_t symbol1583___pp = BUNSPEC;
static obj_t symbol1582___pp = BUNSPEC;
static obj_t symbol1581___pp = BUNSPEC;
static obj_t symbol1579___pp = BUNSPEC;
static obj_t symbol1580___pp = BUNSPEC;
static obj_t symbol1577___pp = BUNSPEC;
static obj_t symbol1576___pp = BUNSPEC;
static obj_t symbol1575___pp = BUNSPEC;
static obj_t symbol1574___pp = BUNSPEC;
static obj_t symbol1572___pp = BUNSPEC;
static obj_t symbol1571___pp = BUNSPEC;
static obj_t symbol1569___pp = BUNSPEC;
static obj_t symbol1568___pp = BUNSPEC;
static obj_t symbol1567___pp = BUNSPEC;
static obj_t symbol1566___pp = BUNSPEC;
static obj_t symbol1564___pp = BUNSPEC;
static obj_t symbol1563___pp = BUNSPEC;
static obj_t symbol1562___pp = BUNSPEC;
extern obj_t string_upcase_71___r4_strings_6_7(obj_t);
static obj_t symbol1549___pp = BUNSPEC;
static obj_t symbol1547___pp = BUNSPEC;
static obj_t symbol1545___pp = BUNSPEC;
static obj_t symbol1543___pp = BUNSPEC;
static obj_t symbol1537___pp = BUNSPEC;
static obj_t symbol1536___pp = BUNSPEC;
static obj_t symbol1530___pp = BUNSPEC;
static obj_t *__cnst;

DEFINE_STRING( string1584___pp, string1584___pp1586, "\n", 1 );
DEFINE_STRING( string1559___pp, string1559___pp1587, "        ", 8 );
DEFINE_STRING( string1560___pp, string1560___pp1588, "({}", 3 );
DEFINE_STRING( string1558___pp, string1558___pp1589, ".", 1 );
DEFINE_STRING( string1557___pp, string1557___pp1590, " . ", 3 );
DEFINE_STRING( string1556___pp, string1556___pp1591, ")", 1 );
DEFINE_STRING( string1555___pp, string1555___pp1592, " ", 1 );
DEFINE_STRING( string1554___pp, string1554___pp1593, "\"", 1 );
DEFINE_STRING( string1553___pp, string1553___pp1594, "()", 2 );
DEFINE_STRING( string1552___pp, string1552___pp1595, "(", 1 );
DEFINE_STRING( string1550___pp, string1550___pp1596, ",@", 2 );
DEFINE_STRING( string1548___pp, string1548___pp1597, ",", 1 );
DEFINE_STRING( string1546___pp, string1546___pp1598, "`", 1 );
DEFINE_STRING( string1544___pp, string1544___pp1599, "'", 1 );
DEFINE_STRING( string1542___pp, string1542___pp1600, "#[eof-object]", 13 );
DEFINE_STRING( string1541___pp, string1541___pp1601, "#[output-port]", 14 );
DEFINE_STRING( string1539___pp, string1539___pp1602, "#\"", 2 );
DEFINE_STRING( string1540___pp, string1540___pp1603, "#[input-port]", 13 );
DEFINE_STRING( string1538___pp, string1538___pp1604, "#<procedure>", 12 );
DEFINE_STRING( string1535___pp, string1535___pp1605, "#00", 3 );
DEFINE_STRING( string1534___pp, string1534___pp1606, "#0", 2 );
DEFINE_STRING( string1533___pp, string1533___pp1607, "#", 1 );
DEFINE_STRING( string1532___pp, string1532___pp1608, "not an input-port", 17 );
DEFINE_STRING( string1531___pp, string1531___pp1609, "pp", 2 );
DEFINE_EXPORT_PROCEDURE( pp_env_50___pp, _pp___pp1610, va_generic_entry, _pp___pp, -2 );


/* module-initialization */obj_t module_initialization_70___pp(long checksum_2801, char * from_2802)
{
if(CBOOL(require_initialization_114___pp)){
require_initialization_114___pp = BBOOL(((bool_t)0));
cnst_init_137___pp();
imported_modules_init_94___pp();
toplevel_init_63___pp();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___pp()
{
symbol1530___pp = string_to_symbol("RESPECT");
symbol1536___pp = string_to_symbol("COMMENT");
symbol1537___pp = string_to_symbol("UPPER");
symbol1543___pp = string_to_symbol("QUOTE");
symbol1545___pp = string_to_symbol("QUASIQUOTE");
symbol1547___pp = string_to_symbol("UNQUOTE");
symbol1549___pp = string_to_symbol("UNQUOTE-SPLICING");
{
obj_t aux_2816;
{
obj_t aux_2817;
{
obj_t aux_2818;
aux_2818 = MAKE_PAIR(symbol1549___pp, BNIL);
aux_2817 = MAKE_PAIR(symbol1547___pp, aux_2818);
}
aux_2816 = MAKE_PAIR(symbol1545___pp, aux_2817);
}
list1551___pp = MAKE_PAIR(symbol1543___pp, aux_2816);
}
symbol1562___pp = string_to_symbol("LAMBDA");
symbol1563___pp = string_to_symbol("LET*");
symbol1564___pp = string_to_symbol("LETREC");
{
obj_t aux_2826;
{
obj_t aux_2827;
aux_2827 = MAKE_PAIR(symbol1564___pp, BNIL);
aux_2826 = MAKE_PAIR(symbol1563___pp, aux_2827);
}
list1561___pp = MAKE_PAIR(symbol1562___pp, aux_2826);
}
symbol1566___pp = string_to_symbol("DEFINE");
symbol1567___pp = string_to_symbol("DEFINE-INLINE");
symbol1568___pp = string_to_symbol("DEFINE-METHOD");
symbol1569___pp = string_to_symbol("DEFINE-GENERIC");
{
obj_t aux_2835;
{
obj_t aux_2836;
{
obj_t aux_2837;
aux_2837 = MAKE_PAIR(symbol1569___pp, BNIL);
aux_2836 = MAKE_PAIR(symbol1568___pp, aux_2837);
}
aux_2835 = MAKE_PAIR(symbol1567___pp, aux_2836);
}
list1565___pp = MAKE_PAIR(symbol1566___pp, aux_2835);
}
symbol1571___pp = string_to_symbol("DEFUN");
symbol1572___pp = string_to_symbol("DE");
{
obj_t aux_2844;
aux_2844 = MAKE_PAIR(symbol1572___pp, BNIL);
list1570___pp = MAKE_PAIR(symbol1571___pp, aux_2844);
}
symbol1574___pp = string_to_symbol("IF");
symbol1575___pp = string_to_symbol("SET!");
{
obj_t aux_2849;
aux_2849 = MAKE_PAIR(symbol1575___pp, BNIL);
list1573___pp = MAKE_PAIR(symbol1574___pp, aux_2849);
}
symbol1576___pp = string_to_symbol("COND");
symbol1577___pp = string_to_symbol("CASE");
symbol1579___pp = string_to_symbol("AND");
symbol1580___pp = string_to_symbol("OR");
{
obj_t aux_2856;
aux_2856 = MAKE_PAIR(symbol1580___pp, BNIL);
list1578___pp = MAKE_PAIR(symbol1579___pp, aux_2856);
}
symbol1581___pp = string_to_symbol("LET");
symbol1582___pp = string_to_symbol("BEGIN");
return (symbol1583___pp = string_to_symbol("DO"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___pp()
{
_pp_case__242___pp = symbol1530___pp;
return (_pp_width__183___pp = BINT(((long)80)),
BUNSPEC);
}


/* pp */obj_t pp___pp(obj_t exp_1, obj_t port_2)
{
{
obj_t port_330;
if(NULLP(port_2)){
port_330 = current_output_port;
}
 else {
obj_t port_338;
port_338 = CAR(port_2);
if(OUTPUT_PORTP(port_338)){
port_330 = port_338;
}
 else {
FAILURE(string1531___pp,string1532___pp,port_338);}
}
{
obj_t arg1015_2086;
arg1015_2086 = make_fx_procedure(arg1015___pp, ((long)1), ((long)1));
PROCEDURE_SET(arg1015_2086, ((long)0), port_330);
generic_write_53___pp(exp_1, BFALSE, _pp_width__183___pp, arg1015_2086);
}
return BUNSPEC;
}
}


/* _pp */obj_t _pp___pp(obj_t env_2087, obj_t exp_2088, obj_t port_2089)
{
return pp___pp(exp_2088, port_2089);
}


/* arg1015 */obj_t arg1015___pp(obj_t env_2090, obj_t s_2092)
{
{
obj_t port_2091;
port_2091 = PROCEDURE_REF(env_2090, ((long)0));
{
obj_t s_332;
{
bool_t aux_2874;
s_332 = s_2092;
{
obj_t list1017_1063;
list1017_1063 = MAKE_PAIR(port_2091, BNIL);
display___r4_output_6_10_3(s_332, list1017_1063);
}
aux_2874 = ((bool_t)1);
return BBOOL(aux_2874);
}
}
}
}


/* vector-prefix */obj_t vector_prefix_31___pp(obj_t obj_3)
{
{
long tag_340;
tag_340 = VECTOR_TAG(obj_3);
if((tag_340==((long)0))){
return string1533___pp;
}
 else {
if((tag_340>=((long)100))){
obj_t aux_2883;
{
char * aux_2884;
aux_2884 = number__string_214___r4_numbers_6_5(BINT(tag_340), BNIL);
aux_2883 = string_to_bstring(aux_2884);
}
return string_append(string1533___pp, aux_2883);
}
 else {
if((tag_340>=((long)10))){
obj_t aux_2891;
{
char * aux_2892;
aux_2892 = number__string_214___r4_numbers_6_5(BINT(tag_340), BNIL);
aux_2891 = string_to_bstring(aux_2892);
}
return string_append(string1534___pp, aux_2891);
}
 else {
obj_t aux_2897;
{
char * aux_2898;
aux_2898 = number__string_214___r4_numbers_6_5(BINT(tag_340), BNIL);
aux_2897 = string_to_bstring(aux_2898);
}
return string_append(string1535___pp, aux_2897);
}
}
}
}
}


/* generic-write */obj_t generic_write_53___pp(obj_t obj_4, obj_t display__190_5, obj_t width_6, obj_t output_7)
{
{
obj_t obj_363;
long col_364;
if(CBOOL(width_6)){
obj_t arg1034_359;
obj_t arg1035_360;
{
obj_t list1036_361;
{
obj_t aux_2905;
aux_2905 = BCHAR(((unsigned char)'\n'));
list1036_361 = MAKE_PAIR(aux_2905, BNIL);
}
{
obj_t res1520_1078;
{
unsigned char aux_2912;
long aux_2908;
{
obj_t aux_2913;
aux_2913 = CAR(list1036_361);
aux_2912 = (unsigned char)CCHAR(aux_2913);
}
{
int aux_2909;
aux_2909 = (int)(((long)1));
aux_2908 = (long)(aux_2909);
}
res1520_1078 = make_string(aux_2908, aux_2912);
}
arg1034_359 = res1520_1078;
}
}
obj_363 = obj_4;
col_364 = ((long)0);
{
obj_t max_expr_width_222_367;
obj_t max_call_head_width_209_368;
obj_t indent_general_51_369;
max_expr_width_222_367 = MAKE_CELL(BUNSPEC);
max_call_head_width_209_368 = MAKE_CELL(BUNSPEC);
indent_general_51_369 = MAKE_CELL(BUNSPEC);
{
obj_t pp_expr_14_2105;
obj_t pp_expr_list_161_2106;
obj_t pp_expr_defun_108_2114;
obj_t pp_define_115_2116;
obj_t pp_defun_212_2115;
obj_t pp_lambda_212_2117;
obj_t pp_comment_9_2104;
obj_t pp_if_81_2113;
obj_t pp_cond_71_2112;
obj_t pp_case_154_2111;
obj_t pp_and_5_2110;
obj_t pp_let_126_2109;
obj_t pp_begin_191_2108;
obj_t pp_do_220_2107;
pp_expr_14_2105 = make_fx_procedure(pp_expr_14___pp, ((long)3), ((long)19));
pp_expr_list_161_2106 = make_fx_procedure(pp_expr_list_161___pp, ((long)3), ((long)19));
pp_expr_defun_108_2114 = make_fx_procedure(pp_expr_defun_108___pp, ((long)3), ((long)19));
pp_define_115_2116 = make_fx_procedure(pp_define_115___pp, ((long)3), ((long)19));
pp_defun_212_2115 = make_fx_procedure(pp_defun_212___pp, ((long)3), ((long)19));
pp_lambda_212_2117 = make_fx_procedure(pp_lambda_212___pp, ((long)3), ((long)19));
pp_comment_9_2104 = make_fx_procedure(pp_comment_9___pp, ((long)3), ((long)19));
pp_if_81_2113 = make_fx_procedure(pp_if_81___pp, ((long)3), ((long)19));
pp_cond_71_2112 = make_fx_procedure(pp_cond_71___pp, ((long)3), ((long)19));
pp_case_154_2111 = make_fx_procedure(pp_case_154___pp, ((long)3), ((long)19));
pp_and_5_2110 = make_fx_procedure(pp_and_5___pp, ((long)3), ((long)19));
pp_let_126_2109 = make_fx_procedure(pp_let_126___pp, ((long)3), ((long)19));
pp_begin_191_2108 = make_fx_procedure(pp_begin_191___pp, ((long)3), ((long)19));
pp_do_220_2107 = make_fx_procedure(pp_do_220___pp, ((long)3), ((long)19));
PROCEDURE_SET(pp_expr_14_2105, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_expr_14_2105, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_expr_14_2105, ((long)2), width_6);
PROCEDURE_SET(pp_expr_14_2105, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_expr_14_2105, ((long)4), display__190_5);
PROCEDURE_SET(pp_expr_14_2105, ((long)5), pp_expr_list_161_2106);
PROCEDURE_SET(pp_expr_14_2105, ((long)6), pp_comment_9_2104);
PROCEDURE_SET(pp_expr_14_2105, ((long)7), pp_do_220_2107);
PROCEDURE_SET(pp_expr_14_2105, ((long)8), pp_begin_191_2108);
PROCEDURE_SET(pp_expr_14_2105, ((long)9), pp_let_126_2109);
PROCEDURE_SET(pp_expr_14_2105, ((long)10), pp_and_5_2110);
PROCEDURE_SET(pp_expr_14_2105, ((long)11), pp_case_154_2111);
PROCEDURE_SET(pp_expr_14_2105, ((long)12), pp_cond_71_2112);
PROCEDURE_SET(pp_expr_14_2105, ((long)13), pp_if_81_2113);
PROCEDURE_SET(pp_expr_14_2105, ((long)14), pp_defun_212_2115);
PROCEDURE_SET(pp_expr_14_2105, ((long)15), pp_define_115_2116);
PROCEDURE_SET(pp_expr_14_2105, ((long)16), pp_lambda_212_2117);
PROCEDURE_SET(pp_expr_14_2105, ((long)17), max_call_head_width_209_368);
PROCEDURE_SET(pp_expr_14_2105, ((long)18), output_7);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)2), width_6);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)4), display__190_5);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)14), pp_define_115_2116);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)15), pp_lambda_212_2117);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)16), max_call_head_width_209_368);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)17), output_7);
PROCEDURE_SET(pp_expr_list_161_2106, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)0), indent_general_51_369);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)1), width_6);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)2), max_expr_width_222_367);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)3), display__190_5);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)4), pp_expr_list_161_2106);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)14), pp_define_115_2116);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)15), pp_lambda_212_2117);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)16), max_call_head_width_209_368);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)17), output_7);
PROCEDURE_SET(pp_expr_defun_108_2114, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_define_115_2116, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_define_115_2116, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_define_115_2116, ((long)2), width_6);
PROCEDURE_SET(pp_define_115_2116, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_define_115_2116, ((long)4), display__190_5);
PROCEDURE_SET(pp_define_115_2116, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_define_115_2116, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_define_115_2116, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_define_115_2116, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_define_115_2116, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_define_115_2116, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_define_115_2116, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_define_115_2116, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_define_115_2116, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_define_115_2116, ((long)14), pp_lambda_212_2117);
PROCEDURE_SET(pp_define_115_2116, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_define_115_2116, ((long)16), pp_expr_list_161_2106);
PROCEDURE_SET(pp_define_115_2116, ((long)17), pp_expr_14_2105);
PROCEDURE_SET(pp_define_115_2116, ((long)18), output_7);
PROCEDURE_SET(pp_defun_212_2115, ((long)0), indent_general_51_369);
PROCEDURE_SET(pp_defun_212_2115, ((long)1), width_6);
PROCEDURE_SET(pp_defun_212_2115, ((long)2), max_expr_width_222_367);
PROCEDURE_SET(pp_defun_212_2115, ((long)3), display__190_5);
PROCEDURE_SET(pp_defun_212_2115, ((long)4), pp_expr_list_161_2106);
PROCEDURE_SET(pp_defun_212_2115, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_defun_212_2115, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_defun_212_2115, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_defun_212_2115, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_defun_212_2115, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_defun_212_2115, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_defun_212_2115, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_defun_212_2115, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_defun_212_2115, ((long)13), pp_define_115_2116);
PROCEDURE_SET(pp_defun_212_2115, ((long)14), pp_lambda_212_2117);
PROCEDURE_SET(pp_defun_212_2115, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_defun_212_2115, ((long)16), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_defun_212_2115, ((long)17), pp_expr_14_2105);
PROCEDURE_SET(pp_defun_212_2115, ((long)18), output_7);
PROCEDURE_SET(pp_lambda_212_2117, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_lambda_212_2117, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_lambda_212_2117, ((long)2), width_6);
PROCEDURE_SET(pp_lambda_212_2117, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_lambda_212_2117, ((long)4), display__190_5);
PROCEDURE_SET(pp_lambda_212_2117, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_lambda_212_2117, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_lambda_212_2117, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_lambda_212_2117, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_lambda_212_2117, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_lambda_212_2117, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_lambda_212_2117, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_lambda_212_2117, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_lambda_212_2117, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_lambda_212_2117, ((long)14), pp_define_115_2116);
PROCEDURE_SET(pp_lambda_212_2117, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_lambda_212_2117, ((long)16), output_7);
PROCEDURE_SET(pp_lambda_212_2117, ((long)17), pp_expr_list_161_2106);
PROCEDURE_SET(pp_lambda_212_2117, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_comment_9_2104, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_comment_9_2104, ((long)1), pp_expr_list_161_2106);
PROCEDURE_SET(pp_comment_9_2104, ((long)2), pp_do_220_2107);
PROCEDURE_SET(pp_comment_9_2104, ((long)3), pp_begin_191_2108);
PROCEDURE_SET(pp_comment_9_2104, ((long)4), pp_let_126_2109);
PROCEDURE_SET(pp_comment_9_2104, ((long)5), pp_and_5_2110);
PROCEDURE_SET(pp_comment_9_2104, ((long)6), pp_case_154_2111);
PROCEDURE_SET(pp_comment_9_2104, ((long)7), pp_cond_71_2112);
PROCEDURE_SET(pp_comment_9_2104, ((long)8), pp_if_81_2113);
PROCEDURE_SET(pp_comment_9_2104, ((long)9), pp_defun_212_2115);
PROCEDURE_SET(pp_comment_9_2104, ((long)10), pp_define_115_2116);
PROCEDURE_SET(pp_comment_9_2104, ((long)11), pp_lambda_212_2117);
PROCEDURE_SET(pp_comment_9_2104, ((long)12), max_call_head_width_209_368);
PROCEDURE_SET(pp_comment_9_2104, ((long)13), width_6);
PROCEDURE_SET(pp_comment_9_2104, ((long)14), max_expr_width_222_367);
PROCEDURE_SET(pp_comment_9_2104, ((long)15), display__190_5);
PROCEDURE_SET(pp_comment_9_2104, ((long)16), indent_general_51_369);
PROCEDURE_SET(pp_comment_9_2104, ((long)17), pp_expr_14_2105);
PROCEDURE_SET(pp_comment_9_2104, ((long)18), output_7);
PROCEDURE_SET(pp_if_81_2113, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_if_81_2113, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_if_81_2113, ((long)2), width_6);
PROCEDURE_SET(pp_if_81_2113, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_if_81_2113, ((long)4), display__190_5);
PROCEDURE_SET(pp_if_81_2113, ((long)5), pp_expr_list_161_2106);
PROCEDURE_SET(pp_if_81_2113, ((long)6), pp_comment_9_2104);
PROCEDURE_SET(pp_if_81_2113, ((long)7), pp_do_220_2107);
PROCEDURE_SET(pp_if_81_2113, ((long)8), pp_begin_191_2108);
PROCEDURE_SET(pp_if_81_2113, ((long)9), pp_let_126_2109);
PROCEDURE_SET(pp_if_81_2113, ((long)10), pp_and_5_2110);
PROCEDURE_SET(pp_if_81_2113, ((long)11), pp_case_154_2111);
PROCEDURE_SET(pp_if_81_2113, ((long)12), pp_cond_71_2112);
PROCEDURE_SET(pp_if_81_2113, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_if_81_2113, ((long)14), pp_define_115_2116);
PROCEDURE_SET(pp_if_81_2113, ((long)15), pp_lambda_212_2117);
PROCEDURE_SET(pp_if_81_2113, ((long)16), max_call_head_width_209_368);
PROCEDURE_SET(pp_if_81_2113, ((long)17), output_7);
PROCEDURE_SET(pp_if_81_2113, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_cond_71_2112, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_cond_71_2112, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_cond_71_2112, ((long)2), width_6);
PROCEDURE_SET(pp_cond_71_2112, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_cond_71_2112, ((long)4), display__190_5);
PROCEDURE_SET(pp_cond_71_2112, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_cond_71_2112, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_cond_71_2112, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_cond_71_2112, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_cond_71_2112, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_cond_71_2112, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_cond_71_2112, ((long)11), pp_if_81_2113);
PROCEDURE_SET(pp_cond_71_2112, ((long)12), pp_defun_212_2115);
PROCEDURE_SET(pp_cond_71_2112, ((long)13), pp_define_115_2116);
PROCEDURE_SET(pp_cond_71_2112, ((long)14), pp_lambda_212_2117);
PROCEDURE_SET(pp_cond_71_2112, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_cond_71_2112, ((long)16), output_7);
PROCEDURE_SET(pp_cond_71_2112, ((long)17), pp_expr_14_2105);
PROCEDURE_SET(pp_cond_71_2112, ((long)18), pp_expr_list_161_2106);
PROCEDURE_SET(pp_case_154_2111, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_case_154_2111, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_case_154_2111, ((long)2), width_6);
PROCEDURE_SET(pp_case_154_2111, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_case_154_2111, ((long)4), display__190_5);
PROCEDURE_SET(pp_case_154_2111, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_case_154_2111, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_case_154_2111, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_case_154_2111, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_case_154_2111, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_case_154_2111, ((long)10), pp_cond_71_2112);
PROCEDURE_SET(pp_case_154_2111, ((long)11), pp_if_81_2113);
PROCEDURE_SET(pp_case_154_2111, ((long)12), pp_defun_212_2115);
PROCEDURE_SET(pp_case_154_2111, ((long)13), pp_define_115_2116);
PROCEDURE_SET(pp_case_154_2111, ((long)14), pp_lambda_212_2117);
PROCEDURE_SET(pp_case_154_2111, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_case_154_2111, ((long)16), output_7);
PROCEDURE_SET(pp_case_154_2111, ((long)17), pp_expr_14_2105);
PROCEDURE_SET(pp_case_154_2111, ((long)18), pp_expr_list_161_2106);
PROCEDURE_SET(pp_and_5_2110, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_and_5_2110, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_and_5_2110, ((long)2), width_6);
PROCEDURE_SET(pp_and_5_2110, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_and_5_2110, ((long)4), display__190_5);
PROCEDURE_SET(pp_and_5_2110, ((long)5), pp_expr_list_161_2106);
PROCEDURE_SET(pp_and_5_2110, ((long)6), pp_comment_9_2104);
PROCEDURE_SET(pp_and_5_2110, ((long)7), pp_do_220_2107);
PROCEDURE_SET(pp_and_5_2110, ((long)8), pp_begin_191_2108);
PROCEDURE_SET(pp_and_5_2110, ((long)9), pp_let_126_2109);
PROCEDURE_SET(pp_and_5_2110, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_and_5_2110, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_and_5_2110, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_and_5_2110, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_and_5_2110, ((long)14), pp_define_115_2116);
PROCEDURE_SET(pp_and_5_2110, ((long)15), pp_lambda_212_2117);
PROCEDURE_SET(pp_and_5_2110, ((long)16), max_call_head_width_209_368);
PROCEDURE_SET(pp_and_5_2110, ((long)17), output_7);
PROCEDURE_SET(pp_and_5_2110, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_let_126_2109, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_let_126_2109, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_let_126_2109, ((long)2), width_6);
PROCEDURE_SET(pp_let_126_2109, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_let_126_2109, ((long)4), display__190_5);
PROCEDURE_SET(pp_let_126_2109, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_let_126_2109, ((long)6), pp_do_220_2107);
PROCEDURE_SET(pp_let_126_2109, ((long)7), pp_begin_191_2108);
PROCEDURE_SET(pp_let_126_2109, ((long)8), pp_and_5_2110);
PROCEDURE_SET(pp_let_126_2109, ((long)9), pp_case_154_2111);
PROCEDURE_SET(pp_let_126_2109, ((long)10), pp_cond_71_2112);
PROCEDURE_SET(pp_let_126_2109, ((long)11), pp_if_81_2113);
PROCEDURE_SET(pp_let_126_2109, ((long)12), pp_defun_212_2115);
PROCEDURE_SET(pp_let_126_2109, ((long)13), pp_define_115_2116);
PROCEDURE_SET(pp_let_126_2109, ((long)14), pp_lambda_212_2117);
PROCEDURE_SET(pp_let_126_2109, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_let_126_2109, ((long)16), output_7);
PROCEDURE_SET(pp_let_126_2109, ((long)17), pp_expr_list_161_2106);
PROCEDURE_SET(pp_let_126_2109, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_begin_191_2108, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_begin_191_2108, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_begin_191_2108, ((long)2), width_6);
PROCEDURE_SET(pp_begin_191_2108, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_begin_191_2108, ((long)4), display__190_5);
PROCEDURE_SET(pp_begin_191_2108, ((long)5), pp_expr_list_161_2106);
PROCEDURE_SET(pp_begin_191_2108, ((long)6), pp_comment_9_2104);
PROCEDURE_SET(pp_begin_191_2108, ((long)7), pp_do_220_2107);
PROCEDURE_SET(pp_begin_191_2108, ((long)8), pp_let_126_2109);
PROCEDURE_SET(pp_begin_191_2108, ((long)9), pp_and_5_2110);
PROCEDURE_SET(pp_begin_191_2108, ((long)10), pp_case_154_2111);
PROCEDURE_SET(pp_begin_191_2108, ((long)11), pp_cond_71_2112);
PROCEDURE_SET(pp_begin_191_2108, ((long)12), pp_if_81_2113);
PROCEDURE_SET(pp_begin_191_2108, ((long)13), pp_defun_212_2115);
PROCEDURE_SET(pp_begin_191_2108, ((long)14), pp_define_115_2116);
PROCEDURE_SET(pp_begin_191_2108, ((long)15), pp_lambda_212_2117);
PROCEDURE_SET(pp_begin_191_2108, ((long)16), max_call_head_width_209_368);
PROCEDURE_SET(pp_begin_191_2108, ((long)17), output_7);
PROCEDURE_SET(pp_begin_191_2108, ((long)18), pp_expr_14_2105);
PROCEDURE_SET(pp_do_220_2107, ((long)0), pp_expr_defun_108_2114);
PROCEDURE_SET(pp_do_220_2107, ((long)1), indent_general_51_369);
PROCEDURE_SET(pp_do_220_2107, ((long)2), width_6);
PROCEDURE_SET(pp_do_220_2107, ((long)3), max_expr_width_222_367);
PROCEDURE_SET(pp_do_220_2107, ((long)4), display__190_5);
PROCEDURE_SET(pp_do_220_2107, ((long)5), pp_comment_9_2104);
PROCEDURE_SET(pp_do_220_2107, ((long)6), pp_begin_191_2108);
PROCEDURE_SET(pp_do_220_2107, ((long)7), pp_let_126_2109);
PROCEDURE_SET(pp_do_220_2107, ((long)8), pp_and_5_2110);
PROCEDURE_SET(pp_do_220_2107, ((long)9), pp_case_154_2111);
PROCEDURE_SET(pp_do_220_2107, ((long)10), pp_cond_71_2112);
PROCEDURE_SET(pp_do_220_2107, ((long)11), pp_if_81_2113);
PROCEDURE_SET(pp_do_220_2107, ((long)12), pp_defun_212_2115);
PROCEDURE_SET(pp_do_220_2107, ((long)13), pp_define_115_2116);
PROCEDURE_SET(pp_do_220_2107, ((long)14), pp_lambda_212_2117);
PROCEDURE_SET(pp_do_220_2107, ((long)15), max_call_head_width_209_368);
PROCEDURE_SET(pp_do_220_2107, ((long)16), output_7);
PROCEDURE_SET(pp_do_220_2107, ((long)17), pp_expr_list_161_2106);
PROCEDURE_SET(pp_do_220_2107, ((long)18), pp_expr_14_2105);
CELL_SET(indent_general_51_369, BINT(((long)2)));
CELL_SET(max_call_head_width_209_368, BINT(((long)5)));
CELL_SET(max_expr_width_222_367, BINT(((long)50)));
arg1035_360 = pr___pp(pp_expr_14_2105, output_7, display__190_5, max_expr_width_222_367, width_6, max_call_head_width_209_368, pp_lambda_212_2117, pp_define_115_2116, pp_defun_212_2115, pp_if_81_2113, pp_cond_71_2112, pp_case_154_2111, pp_and_5_2110, pp_let_126_2109, pp_begin_191_2108, pp_do_220_2107, pp_comment_9_2104, pp_expr_list_161_2106, indent_general_51_369, pp_expr_defun_108_2114, obj_363, BINT(col_364), BINT(((long)0)), pp_expr_14_2105);
}
}
if(CBOOL(arg1035_360)){
obj_t _andtest_1004_1082;
_andtest_1004_1082 = PROCEDURE_ENTRY(output_7)(output_7, arg1034_359, BEOA);
if(CBOOL(_andtest_1004_1082)){
long aux_3209;
{
long aux_3212;
long aux_3210;
aux_3212 = STRING_LENGTH(arg1034_359);
aux_3210 = (long)CINT(arg1035_360);
aux_3209 = (aux_3210+aux_3212);
}
return BINT(aux_3209);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
return wr___pp(display__190_5, output_7, obj_4, BINT(((long)0)));
}
}
}


/* wr */obj_t wr___pp(obj_t display__190_2143, obj_t output_2142, obj_t obj_703, obj_t col_704)
{
wr___pp:
{
bool_t test_3218;
if(PAIRP(obj_703)){
obj_t cdr_105_52_779;
cdr_105_52_779 = CDR(obj_703);
{
bool_t test_3222;
{
obj_t aux_3223;
aux_3223 = CAR(obj_703);
test_3222 = (aux_3223==symbol1536___pp);
}
if(test_3222){
if(PAIRP(cdr_105_52_779)){
obj_t cdr_107_0_782;
cdr_107_0_782 = CDR(cdr_105_52_779);
{
bool_t test_3229;
{
obj_t aux_3230;
aux_3230 = CAR(cdr_105_52_779);
test_3229 = INTEGERP(aux_3230);
}
if(test_3229){
if(PAIRP(cdr_107_0_782)){
bool_t test_3235;
{
obj_t aux_3236;
aux_3236 = CAR(cdr_107_0_782);
test_3235 = STRINGP(aux_3236);
}
if(test_3235){
bool_t test_3239;
{
obj_t aux_3240;
aux_3240 = CDR(cdr_107_0_782);
test_3239 = (aux_3240==BNIL);
}
if(test_3239){
test_3218 = ((bool_t)1);
}
 else {
test_3218 = ((bool_t)0);
}
}
 else {
test_3218 = ((bool_t)0);
}
}
 else {
test_3218 = ((bool_t)0);
}
}
 else {
test_3218 = ((bool_t)0);
}
}
}
 else {
test_3218 = ((bool_t)0);
}
}
 else {
test_3218 = ((bool_t)0);
}
}
}
 else {
test_3218 = ((bool_t)0);
}
if(test_3218){
{
obj_t add_709;
{
obj_t aux_3243;
{
obj_t aux_3244;
{
long aux_3245;
{
obj_t aux_3246;
{
obj_t aux_3247;
{
obj_t aux_3248;
aux_3248 = CDR(obj_703);
aux_3247 = CDR(aux_3248);
}
aux_3246 = CAR(aux_3247);
}
aux_3245 = STRING_LENGTH(aux_3246);
}
aux_3244 = BINT(aux_3245);
}
aux_3243 = _2__168___r4_numbers_6_5(aux_3244, BINT(((long)3)));
}
add_709 = _2__79___r4_numbers_6_5(_pp_width__183___pp, aux_3243);
}
{
bool_t test_3257;
{
long aux_3258;
aux_3258 = (long)CINT(add_709);
test_3257 = (aux_3258<=((long)0));
}
if(test_3257){
obj_t arg1197_711;
{
obj_t aux_3261;
{
obj_t aux_3262;
aux_3262 = CDR(obj_703);
aux_3261 = CDR(aux_3262);
}
arg1197_711 = CAR(aux_3261);
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1625;
_andtest_1004_1625 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1197_711, BEOA);
if(CBOOL(_andtest_1004_1625)){
long aux_3272;
{
long aux_3275;
long aux_3273;
aux_3275 = STRING_LENGTH(arg1197_711);
aux_3273 = (long)CINT(col_704);
aux_3272 = (aux_3273+aux_3275);
}
return BINT(aux_3272);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
obj_t arg1199_712;
{
obj_t arg1200_713;
obj_t arg1201_714;
{
obj_t aux_3279;
{
obj_t aux_3280;
aux_3280 = CDR(obj_703);
aux_3279 = CDR(aux_3280);
}
arg1200_713 = CAR(aux_3279);
}
{
obj_t list1202_715;
{
obj_t aux_3284;
aux_3284 = BCHAR(((unsigned char)' '));
list1202_715 = MAKE_PAIR(aux_3284, BNIL);
}
{
obj_t res1524_1642;
{
unsigned char aux_3291;
long aux_3287;
{
obj_t aux_3292;
aux_3292 = CAR(list1202_715);
aux_3291 = (unsigned char)CCHAR(aux_3292);
}
{
int aux_3288;
aux_3288 = CINT(add_709);
aux_3287 = (long)(aux_3288);
}
res1524_1642 = make_string(aux_3287, aux_3291);
}
arg1201_714 = res1524_1642;
}
}
arg1199_712 = string_append(arg1200_713, arg1201_714);
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1646;
_andtest_1004_1646 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1199_712, BEOA);
if(CBOOL(_andtest_1004_1646)){
long aux_3303;
{
long aux_3306;
long aux_3304;
aux_3306 = STRING_LENGTH(arg1199_712);
aux_3304 = (long)CINT(col_704);
aux_3303 = (aux_3304+aux_3306);
}
return BINT(aux_3303);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
}
 else {
if(PAIRP(obj_703)){
if(read_macro__3___pp(obj_703)){
obj_t arg1298_1655;
obj_t arg1299_1656;
{
obj_t aux_3314;
aux_3314 = CDR(obj_703);
arg1298_1655 = CAR(aux_3314);
}
arg1299_1656 = out___pp(output_2142, read_macro_prefix_111___pp(obj_703), col_704);
{
obj_t col_3320;
obj_t obj_3319;
obj_3319 = arg1298_1655;
col_3320 = arg1299_1656;
col_704 = col_3320;
obj_703 = obj_3319;
goto wr___pp;
}
}
 else {
return wr_lst_108___pp(output_2142, display__190_2143, obj_703, col_704);
}
}
 else {
if(NULLP(obj_703)){
return wr_lst_108___pp(output_2142, display__190_2143, obj_703, col_704);
}
 else {
if(VECTORP(obj_703)){
{
obj_t arg1211_724;
obj_t arg1213_725;
arg1211_724 = vector__list_155___r4_vectors_6_8(obj_703);
{
obj_t arg1214_726;
arg1214_726 = vector_prefix_31___pp(obj_703);
if(CBOOL(col_704)){
obj_t _andtest_1004_1668;
_andtest_1004_1668 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1214_726, BEOA);
if(CBOOL(_andtest_1004_1668)){
long aux_3335;
{
long aux_3338;
long aux_3336;
aux_3338 = STRING_LENGTH(arg1214_726);
aux_3336 = (long)CINT(col_704);
aux_3335 = (aux_3336+aux_3338);
}
arg1213_725 = BINT(aux_3335);
}
 else {
arg1213_725 = BFALSE;
}
}
 else {
arg1213_725 = BFALSE;
}
}
return wr_lst_108___pp(output_2142, display__190_2143, arg1211_724, arg1213_725);
}
}
 else {
if(BOOLEANP(obj_703)){
{
char * arg1216_728;
if(CBOOL(obj_703)){
arg1216_728 = "#t";
}
 else {
arg1216_728 = "#f";
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1677;
_andtest_1004_1677 = PROCEDURE_ENTRY(output_2142)(output_2142, string_to_bstring(arg1216_728), BEOA);
if(CBOOL(_andtest_1004_1677)){
long aux_3354;
{
long aux_3357;
long aux_3355;
{
obj_t aux_3358;
aux_3358 = string_to_bstring(arg1216_728);
aux_3357 = STRING_LENGTH(aux_3358);
}
aux_3355 = (long)CINT(col_704);
aux_3354 = (aux_3355+aux_3357);
}
return BINT(aux_3354);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
 else {
bool_t test_3363;
if(INTEGERP(obj_703)){
test_3363 = ((bool_t)1);
}
 else {
test_3363 = REALP(obj_703);
}
if(test_3363){
{
char * arg1219_730;
arg1219_730 = number__string_214___r4_numbers_6_5(obj_703, BNIL);
if(CBOOL(col_704)){
obj_t _andtest_1004_1690;
_andtest_1004_1690 = PROCEDURE_ENTRY(output_2142)(output_2142, string_to_bstring(arg1219_730), BEOA);
if(CBOOL(_andtest_1004_1690)){
long aux_3375;
{
long aux_3378;
long aux_3376;
{
obj_t aux_3379;
aux_3379 = string_to_bstring(arg1219_730);
aux_3378 = STRING_LENGTH(aux_3379);
}
aux_3376 = (long)CINT(col_704);
aux_3375 = (aux_3376+aux_3378);
}
return BINT(aux_3375);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
 else {
if(SYMBOLP(obj_703)){
{
obj_t case_value_58_733;
case_value_58_733 = _pp_case__242___pp;
if((case_value_58_733==symbol1530___pp)){
obj_t arg1224_735;
arg1224_735 = SYMBOL_TO_STRING(obj_703);
if(CBOOL(col_704)){
obj_t _andtest_1004_1702;
_andtest_1004_1702 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1224_735, BEOA);
if(CBOOL(_andtest_1004_1702)){
long aux_3395;
{
long aux_3398;
long aux_3396;
aux_3398 = STRING_LENGTH(arg1224_735);
aux_3396 = (long)CINT(col_704);
aux_3395 = (aux_3396+aux_3398);
}
return BINT(aux_3395);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if((case_value_58_733==symbol1537___pp)){
obj_t arg1226_737;
{
obj_t arg1228_738;
arg1228_738 = SYMBOL_TO_STRING(obj_703);
arg1226_737 = string_upcase_71___r4_strings_6_7(arg1228_738);
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1713;
_andtest_1004_1713 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1226_737, BEOA);
if(CBOOL(_andtest_1004_1713)){
long aux_3412;
{
long aux_3415;
long aux_3413;
aux_3415 = STRING_LENGTH(arg1226_737);
aux_3413 = (long)CINT(col_704);
aux_3412 = (aux_3413+aux_3415);
}
return BINT(aux_3412);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
obj_t arg1231_739;
{
obj_t arg1232_740;
arg1232_740 = SYMBOL_TO_STRING(obj_703);
arg1231_739 = string_downcase_77___r4_strings_6_7(arg1232_740);
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1722;
_andtest_1004_1722 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1231_739, BEOA);
if(CBOOL(_andtest_1004_1722)){
long aux_3427;
{
long aux_3430;
long aux_3428;
aux_3430 = STRING_LENGTH(arg1231_739);
aux_3428 = (long)CINT(col_704);
aux_3427 = (aux_3428+aux_3430);
}
return BINT(aux_3427);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
}
 else {
if(PROCEDUREP(obj_703)){
if(CBOOL(col_704)){
obj_t _andtest_1004_1731;
_andtest_1004_1731 = PROCEDURE_ENTRY(output_2142)(output_2142, string1538___pp, BEOA);
if(CBOOL(_andtest_1004_1731)){
long aux_3442;
{
long aux_3445;
long aux_3443;
aux_3445 = STRING_LENGTH(string1538___pp);
aux_3443 = (long)CINT(col_704);
aux_3442 = (aux_3443+aux_3445);
}
return BINT(aux_3442);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if(STRINGP(obj_703)){
{
obj_t obj_745;
obj_745 = string_for_read(obj_703);
if(CBOOL(display__190_2143)){
if(CBOOL(col_704)){
obj_t _andtest_1004_1741;
_andtest_1004_1741 = PROCEDURE_ENTRY(output_2142)(output_2142, obj_745, BEOA);
if(CBOOL(_andtest_1004_1741)){
long aux_3460;
{
long aux_3463;
long aux_3461;
aux_3463 = STRING_LENGTH(obj_745);
aux_3461 = (long)CINT(col_704);
aux_3460 = (aux_3461+aux_3463);
}
return BINT(aux_3460);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
obj_t arg1241_752;
if(CBOOL(col_704)){
obj_t _andtest_1004_1749;
_andtest_1004_1749 = PROCEDURE_ENTRY(output_2142)(output_2142, string1539___pp, BEOA);
if(CBOOL(_andtest_1004_1749)){
long aux_3473;
{
long aux_3476;
long aux_3474;
aux_3476 = STRING_LENGTH(string1539___pp);
aux_3474 = (long)CINT(col_704);
aux_3473 = (aux_3474+aux_3476);
}
arg1241_752 = BINT(aux_3473);
}
 else {
arg1241_752 = BFALSE;
}
}
 else {
arg1241_752 = BFALSE;
}
return loop_1528___pp(((long)0), arg1241_752, obj_745, output_2142, ((long)0));
}
}
}
 else {
if(CHARP(obj_703)){
if(CBOOL(display__190_2143)){
obj_t arg1250_761;
{
obj_t list1251_762;
list1251_762 = MAKE_PAIR(obj_703, BNIL);
{
obj_t res1526_1833;
{
unsigned char aux_3490;
long aux_3486;
{
obj_t aux_3491;
aux_3491 = CAR(list1251_762);
aux_3490 = (unsigned char)CCHAR(aux_3491);
}
{
int aux_3487;
aux_3487 = (int)(((long)1));
aux_3486 = (long)(aux_3487);
}
res1526_1833 = make_string(aux_3486, aux_3490);
}
arg1250_761 = res1526_1833;
}
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1837;
_andtest_1004_1837 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1250_761, BEOA);
if(CBOOL(_andtest_1004_1837)){
long aux_3501;
{
long aux_3504;
long aux_3502;
aux_3504 = STRING_LENGTH(arg1250_761);
aux_3502 = (long)CINT(col_704);
aux_3501 = (aux_3502+aux_3504);
}
return BINT(aux_3501);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
obj_t p_764;
p_764 = open_output_string();
{
obj_t list1253_765;
list1253_765 = MAKE_PAIR(p_764, BNIL);
write___r4_output_6_10_3(obj_703, list1253_765);
}
{
obj_t arg1255_767;
arg1255_767 = close_output_port(p_764);
if(CBOOL(col_704)){
obj_t _andtest_1004_1846;
_andtest_1004_1846 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1255_767, BEOA);
if(CBOOL(_andtest_1004_1846)){
long aux_3518;
{
long aux_3521;
long aux_3519;
aux_3521 = STRING_LENGTH(arg1255_767);
aux_3519 = (long)CINT(col_704);
aux_3518 = (aux_3519+aux_3521);
}
return BINT(aux_3518);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
 else {
if(INPUT_PORTP(obj_703)){
if(CBOOL(col_704)){
obj_t _andtest_1004_1855;
_andtest_1004_1855 = PROCEDURE_ENTRY(output_2142)(output_2142, string1540___pp, BEOA);
if(CBOOL(_andtest_1004_1855)){
long aux_3533;
{
long aux_3536;
long aux_3534;
aux_3536 = STRING_LENGTH(string1540___pp);
aux_3534 = (long)CINT(col_704);
aux_3533 = (aux_3534+aux_3536);
}
return BINT(aux_3533);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if(OUTPUT_PORTP(obj_703)){
if(CBOOL(col_704)){
obj_t _andtest_1004_1864;
_andtest_1004_1864 = PROCEDURE_ENTRY(output_2142)(output_2142, string1541___pp, BEOA);
if(CBOOL(_andtest_1004_1864)){
long aux_3548;
{
long aux_3551;
long aux_3549;
aux_3551 = STRING_LENGTH(string1541___pp);
aux_3549 = (long)CINT(col_704);
aux_3548 = (aux_3549+aux_3551);
}
return BINT(aux_3548);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
bool_t test1258_770;
test1258_770 = EOF_OBJECTP(obj_703);
if(test1258_770){
if(CBOOL(col_704)){
obj_t _andtest_1004_1873;
_andtest_1004_1873 = PROCEDURE_ENTRY(output_2142)(output_2142, string1542___pp, BEOA);
if(CBOOL(_andtest_1004_1873)){
long aux_3563;
{
long aux_3566;
long aux_3564;
aux_3566 = STRING_LENGTH(string1542___pp);
aux_3564 = (long)CINT(col_704);
aux_3563 = (aux_3564+aux_3566);
}
return BINT(aux_3563);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
{
obj_t arg1259_771;
{
obj_t p_772;
p_772 = open_output_string();
{
obj_t list1260_773;
list1260_773 = MAKE_PAIR(p_772, BNIL);
write___r4_output_6_10_3(obj_703, list1260_773);
}
arg1259_771 = close_output_port(p_772);
}
if(CBOOL(col_704)){
obj_t _andtest_1004_1882;
_andtest_1004_1882 = PROCEDURE_ENTRY(output_2142)(output_2142, arg1259_771, BEOA);
if(CBOOL(_andtest_1004_1882)){
long aux_3580;
{
long aux_3583;
long aux_3581;
aux_3583 = STRING_LENGTH(arg1259_771);
aux_3581 = (long)CINT(col_704);
aux_3580 = (aux_3581+aux_3583);
}
return BINT(aux_3580);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}


/* out */obj_t out___pp(obj_t output_2144, obj_t str_823, obj_t col_824)
{
if(CBOOL(col_824)){
obj_t _andtest_1004_1960;
_andtest_1004_1960 = PROCEDURE_ENTRY(output_2144)(output_2144, str_823, BEOA);
if(CBOOL(_andtest_1004_1960)){
long aux_3593;
{
long aux_3596;
long aux_3594;
aux_3596 = STRING_LENGTH(str_823);
aux_3594 = (long)CINT(col_824);
aux_3593 = (aux_3594+aux_3596);
}
return BINT(aux_3593);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}


/* read-macro-prefix */obj_t read_macro_prefix_111___pp(obj_t l_829)
{
{
obj_t head_831;
head_831 = CAR(l_829);
if((head_831==symbol1543___pp)){
return string1544___pp;
}
 else {
if((head_831==symbol1545___pp)){
return string1546___pp;
}
 else {
if((head_831==symbol1547___pp)){
return string1548___pp;
}
 else {
if((head_831==symbol1549___pp)){
return string1550___pp;
}
 else {
return BFALSE;
}
}
}
}
}
}


/* read-macro? */bool_t read_macro__3___pp(obj_t l_844)
{
{
obj_t tail_848;
tail_848 = CDR(l_844);
{
bool_t test_3610;
{
obj_t aux_3611;
aux_3611 = memq___r4_pairs_and_lists_6_3(CAR(l_844), list1551___pp);
test_3610 = CBOOL(aux_3611);
}
if(test_3610){
if(PAIRP(tail_848)){
obj_t aux_3617;
aux_3617 = CDR(tail_848);
return NULLP(aux_3617);
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
}
}


/* wr-lst */obj_t wr_lst_108___pp(obj_t output_2146, obj_t display__190_2145, obj_t l_793, obj_t col_794)
{
if(PAIRP(l_793)){
obj_t arg1281_800;
obj_t arg1282_801;
arg1281_800 = CDR(l_793);
{
obj_t arg1284_803;
if(CBOOL(col_794)){
obj_t _andtest_1004_1893;
_andtest_1004_1893 = PROCEDURE_ENTRY(output_2146)(output_2146, string1552___pp, BEOA);
if(CBOOL(_andtest_1004_1893)){
long aux_3629;
{
long aux_3632;
long aux_3630;
aux_3632 = STRING_LENGTH(string1552___pp);
aux_3630 = (long)CINT(col_794);
aux_3629 = (aux_3630+aux_3632);
}
arg1284_803 = BINT(aux_3629);
}
 else {
arg1284_803 = BFALSE;
}
}
 else {
arg1284_803 = BFALSE;
}
arg1282_801 = wr___pp(display__190_2145, output_2146, CAR(l_793), arg1284_803);
}
return loop_1529___pp(output_2146, display__190_2145, arg1281_800, arg1282_801);
}
 else {
if(CBOOL(col_794)){
obj_t _andtest_1004_1937;
_andtest_1004_1937 = PROCEDURE_ENTRY(output_2146)(output_2146, string1553___pp, BEOA);
if(CBOOL(_andtest_1004_1937)){
long aux_3645;
{
long aux_3648;
long aux_3646;
aux_3648 = STRING_LENGTH(string1553___pp);
aux_3646 = (long)CINT(col_794);
aux_3645 = (aux_3646+aux_3648);
}
return BINT(aux_3645);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}


/* loop_1528 */obj_t loop_1528___pp(long arg1238_2150, obj_t arg1241_2149, obj_t obj_2148, obj_t output_2147, long j_1755)
{
loop_1528___pp:
{
bool_t test_3652;
if(CBOOL(arg1241_2149)){
long aux_3655;
aux_3655 = STRING_LENGTH(obj_2148);
test_3652 = (j_1755<aux_3655);
}
 else {
test_3652 = ((bool_t)0);
}
if(test_3652){
long j_3658;
j_3658 = (j_1755+((long)1));
j_1755 = j_3658;
goto loop_1528___pp;
}
 else {
obj_t arg1245_1761;
{
obj_t arg1247_1762;
arg1247_1762 = c_substring(obj_2148, arg1238_2150, j_1755);
arg1245_1761 = out___pp(output_2147, arg1247_1762, arg1241_2149);
}
return out___pp(output_2147, string1554___pp, arg1245_1761);
}
}
}


/* loop_1529 */obj_t loop_1529___pp(obj_t output_2152, obj_t display__190_2151, obj_t l_797, obj_t col_798)
{
loop_1529___pp:
if(CBOOL(col_798)){
if(PAIRP(l_797)){
{
obj_t arg1286_806;
obj_t arg1287_807;
arg1286_806 = CDR(l_797);
{
obj_t arg1290_809;
if(CBOOL(col_798)){
obj_t _andtest_1004_1904;
_andtest_1004_1904 = PROCEDURE_ENTRY(output_2152)(output_2152, string1555___pp, BEOA);
if(CBOOL(_andtest_1004_1904)){
long aux_3674;
{
long aux_3677;
long aux_3675;
aux_3677 = STRING_LENGTH(string1555___pp);
aux_3675 = (long)CINT(col_798);
aux_3674 = (aux_3675+aux_3677);
}
arg1290_809 = BINT(aux_3674);
}
 else {
arg1290_809 = BFALSE;
}
}
 else {
arg1290_809 = BFALSE;
}
arg1287_807 = wr___pp(display__190_2151, output_2152, CAR(l_797), arg1290_809);
}
{
obj_t col_3684;
obj_t l_3683;
l_3683 = arg1286_806;
col_3684 = arg1287_807;
col_798 = col_3684;
l_797 = l_3683;
goto loop_1529___pp;
}
}
}
 else {
if(NULLP(l_797)){
if(CBOOL(col_798)){
obj_t _andtest_1004_1913;
_andtest_1004_1913 = PROCEDURE_ENTRY(output_2152)(output_2152, string1556___pp, BEOA);
if(CBOOL(_andtest_1004_1913)){
long aux_3693;
{
long aux_3696;
long aux_3694;
aux_3696 = STRING_LENGTH(string1556___pp);
aux_3694 = (long)CINT(col_798);
aux_3693 = (aux_3694+aux_3696);
}
return BINT(aux_3693);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
{
obj_t arg1294_812;
{
obj_t arg1295_813;
if(CBOOL(col_798)){
obj_t _andtest_1004_1921;
_andtest_1004_1921 = PROCEDURE_ENTRY(output_2152)(output_2152, string1557___pp, BEOA);
if(CBOOL(_andtest_1004_1921)){
long aux_3706;
{
long aux_3709;
long aux_3707;
aux_3709 = STRING_LENGTH(string1557___pp);
aux_3707 = (long)CINT(col_798);
aux_3706 = (aux_3707+aux_3709);
}
arg1295_813 = BINT(aux_3706);
}
 else {
arg1295_813 = BFALSE;
}
}
 else {
arg1295_813 = BFALSE;
}
arg1294_812 = wr___pp(display__190_2151, output_2152, l_797, arg1295_813);
}
if(CBOOL(arg1294_812)){
obj_t _andtest_1004_1929;
_andtest_1004_1929 = PROCEDURE_ENTRY(output_2152)(output_2152, string1556___pp, BEOA);
if(CBOOL(_andtest_1004_1929)){
long aux_3720;
{
long aux_3723;
long aux_3721;
aux_3723 = STRING_LENGTH(string1556___pp);
aux_3721 = (long)CINT(arg1294_812);
aux_3720 = (aux_3721+aux_3723);
}
return BINT(aux_3720);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
}
 else {
return BFALSE;
}
}


/* loop */obj_t loop___pp(obj_t pp_item_162_2175, obj_t extra_2174, obj_t output_2173, obj_t col2_2172, obj_t pp_expr_14_2171, obj_t display__190_2170, obj_t max_expr_width_222_2169, obj_t width_2168, obj_t max_call_head_width_209_2167, obj_t pp_lambda_212_2166, obj_t pp_define_115_2165, obj_t pp_defun_212_2164, obj_t pp_if_81_2163, obj_t pp_cond_71_2162, obj_t pp_case_154_2161, obj_t pp_and_5_2160, obj_t pp_let_126_2159, obj_t pp_begin_191_2158, obj_t pp_do_220_2157, obj_t pp_comment_9_2156, obj_t pp_expr_list_161_2155, obj_t indent_general_51_2154, obj_t pp_expr_defun_108_2153, obj_t l_574, obj_t col_575)
{
loop___pp:
if(CBOOL(col_575)){
if(PAIRP(l_574)){
{
obj_t rest_579;
rest_579 = CDR(l_574);
{
long extra_580;
if(NULLP(rest_579)){
long aux_3734;
aux_3734 = (long)CINT(extra_2174);
extra_580 = (aux_3734+((long)1));
}
 else {
extra_580 = ((long)0);
}
{
obj_t arg1130_581;
{
obj_t arg1131_582;
obj_t arg1132_583;
arg1131_582 = CAR(l_574);
arg1132_583 = indent___pp(output_2173, col2_2172, col_575);
arg1130_581 = pr___pp(pp_expr_14_2171, output_2173, display__190_2170, max_expr_width_222_2169, width_2168, max_call_head_width_209_2167, pp_lambda_212_2166, pp_define_115_2165, pp_defun_212_2164, pp_if_81_2163, pp_cond_71_2162, pp_case_154_2161, pp_and_5_2160, pp_let_126_2159, pp_begin_191_2158, pp_do_220_2157, pp_comment_9_2156, pp_expr_list_161_2155, indent_general_51_2154, pp_expr_defun_108_2153, arg1131_582, arg1132_583, BINT(extra_580), pp_item_162_2175);
}
{
obj_t col_3742;
obj_t l_3741;
l_3741 = rest_579;
col_3742 = arg1130_581;
col_575 = col_3742;
l_574 = l_3741;
goto loop___pp;
}
}
}
}
}
 else {
if(NULLP(l_574)){
if(CBOOL(col_575)){
obj_t _andtest_1004_1397;
_andtest_1004_1397 = PROCEDURE_ENTRY(output_2173)(output_2173, string1556___pp, BEOA);
if(CBOOL(_andtest_1004_1397)){
long aux_3751;
{
long aux_3754;
long aux_3752;
aux_3754 = STRING_LENGTH(string1556___pp);
aux_3752 = (long)CINT(col_575);
aux_3751 = (aux_3752+aux_3754);
}
return BINT(aux_3751);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
{
obj_t arg1136_587;
{
obj_t arg1137_588;
long arg1139_589;
{
obj_t arg1140_590;
{
obj_t arg1142_592;
arg1142_592 = indent___pp(output_2173, col2_2172, col_575);
if(CBOOL(arg1142_592)){
obj_t _andtest_1004_1405;
_andtest_1004_1405 = PROCEDURE_ENTRY(output_2173)(output_2173, string1558___pp, BEOA);
if(CBOOL(_andtest_1004_1405)){
long aux_3765;
{
long aux_3768;
long aux_3766;
aux_3768 = STRING_LENGTH(string1558___pp);
aux_3766 = (long)CINT(arg1142_592);
aux_3765 = (aux_3766+aux_3768);
}
arg1140_590 = BINT(aux_3765);
}
 else {
arg1140_590 = BFALSE;
}
}
 else {
arg1140_590 = BFALSE;
}
}
arg1137_588 = indent___pp(output_2173, col2_2172, arg1140_590);
}
{
long aux_3773;
aux_3773 = (long)CINT(extra_2174);
arg1139_589 = (aux_3773+((long)1));
}
arg1136_587 = pr___pp(pp_expr_14_2171, output_2173, display__190_2170, max_expr_width_222_2169, width_2168, max_call_head_width_209_2167, pp_lambda_212_2166, pp_define_115_2165, pp_defun_212_2164, pp_if_81_2163, pp_cond_71_2162, pp_case_154_2161, pp_and_5_2160, pp_let_126_2159, pp_begin_191_2158, pp_do_220_2157, pp_comment_9_2156, pp_expr_list_161_2155, indent_general_51_2154, pp_expr_defun_108_2153, l_574, arg1137_588, BINT(arg1139_589), pp_item_162_2175);
}
if(CBOOL(arg1136_587)){
obj_t _andtest_1004_1415;
_andtest_1004_1415 = PROCEDURE_ENTRY(output_2173)(output_2173, string1556___pp, BEOA);
if(CBOOL(_andtest_1004_1415)){
long aux_3784;
{
long aux_3787;
long aux_3785;
aux_3787 = STRING_LENGTH(string1556___pp);
aux_3785 = (long)CINT(arg1136_587);
aux_3784 = (aux_3785+aux_3787);
}
return BINT(aux_3784);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
}
 else {
return BFALSE;
}
}


/* pr */obj_t pr___pp(obj_t pp_expr_14_2195, obj_t output_2194, obj_t display__190_2193, obj_t max_expr_width_222_2192, obj_t width_2191, obj_t max_call_head_width_209_2190, obj_t pp_lambda_212_2189, obj_t pp_define_115_2188, obj_t pp_defun_212_2187, obj_t pp_if_81_2186, obj_t pp_cond_71_2185, obj_t pp_case_154_2184, obj_t pp_and_5_2183, obj_t pp_let_126_2182, obj_t pp_begin_191_2181, obj_t pp_do_220_2180, obj_t pp_comment_9_2179, obj_t pp_expr_list_161_2178, obj_t indent_general_51_2177, obj_t pp_expr_defun_108_2176, obj_t obj_636, obj_t col_637, obj_t extra_638, obj_t pp_pair_170_639)
{
{
bool_t test_3791;
if(PAIRP(obj_636)){
test_3791 = ((bool_t)1);
}
 else {
test_3791 = VECTORP(obj_636);
}
if(test_3791){
obj_t result_642;
obj_t left_643;
result_642 = MAKE_CELL(BNIL);
{
obj_t cellval_3795;
{
long arg1174_655;
{
long aux_3796;
{
long aux_3803;
long aux_3797;
aux_3803 = (long)CINT(extra_638);
{
long aux_3800;
long aux_3798;
aux_3800 = (long)CINT(col_637);
aux_3798 = (long)CINT(width_2191);
aux_3797 = (aux_3798-aux_3800);
}
aux_3796 = (aux_3797-aux_3803);
}
arg1174_655 = (aux_3796+((long)1));
}
{
obj_t list1175_656;
{
obj_t aux_3807;
aux_3807 = CELL_REF(max_expr_width_222_2192);
list1175_656 = MAKE_PAIR(aux_3807, BNIL);
}
cellval_3795 = min___r4_numbers_6_5(BINT(arg1174_655), list1175_656);
}
}
left_643 = MAKE_CELL(cellval_3795);
}
{
obj_t arg1165_2118;
arg1165_2118 = make_fx_procedure(arg1165___pp, ((long)1), ((long)2));
PROCEDURE_SET(arg1165_2118, ((long)0), result_642);
PROCEDURE_SET(arg1165_2118, ((long)1), left_643);
generic_write_53___pp(obj_636, display__190_2193, BFALSE, arg1165_2118);
}
{
bool_t test1168_649;
{
long n1_1525;
{
obj_t aux_3815;
aux_3815 = CELL_REF(left_643);
n1_1525 = (long)CINT(aux_3815);
}
test1168_649 = (n1_1525>((long)0));
}
if(test1168_649){
obj_t arg1169_650;
arg1169_650 = reverse_string_append_127___pp(CELL_REF(result_642));
if(CBOOL(col_637)){
obj_t _andtest_1004_1530;
_andtest_1004_1530 = PROCEDURE_ENTRY(output_2194)(output_2194, arg1169_650, BEOA);
if(CBOOL(_andtest_1004_1530)){
long aux_3826;
{
long aux_3829;
long aux_3827;
aux_3829 = STRING_LENGTH(arg1169_650);
aux_3827 = (long)CINT(col_637);
aux_3826 = (aux_3827+aux_3829);
}
return BINT(aux_3826);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if(PAIRP(obj_636)){
return PROCEDURE_ENTRY(pp_pair_170_639)(pp_pair_170_639, obj_636, col_637, extra_638, BEOA);
}
 else {
obj_t arg1171_652;
obj_t arg1172_653;
arg1171_652 = vector__list_155___r4_vectors_6_8(obj_636);
{
obj_t arg1173_654;
arg1173_654 = vector_prefix_31___pp(obj_636);
if(CBOOL(col_637)){
obj_t _andtest_1004_1539;
_andtest_1004_1539 = PROCEDURE_ENTRY(output_2194)(output_2194, arg1173_654, BEOA);
if(CBOOL(_andtest_1004_1539)){
long aux_3845;
{
long aux_3848;
long aux_3846;
aux_3848 = STRING_LENGTH(arg1173_654);
aux_3846 = (long)CINT(col_637);
aux_3845 = (aux_3846+aux_3848);
}
arg1172_653 = BINT(aux_3845);
}
 else {
arg1172_653 = BFALSE;
}
}
 else {
arg1172_653 = BFALSE;
}
}
{
obj_t col_1547;
col_1547 = out___pp(output_2194, string1552___pp, arg1172_653);
{
obj_t output_2576;
obj_t pp_expr_14_2577;
obj_t display__190_2578;
obj_t max_expr_width_222_2579;
obj_t width_2580;
obj_t max_call_head_width_209_2581;
obj_t pp_lambda_212_2582;
obj_t pp_define_115_2583;
obj_t pp_defun_212_2584;
obj_t pp_if_81_2585;
obj_t pp_cond_71_2586;
obj_t pp_case_154_2587;
obj_t pp_and_5_2588;
obj_t pp_let_126_2589;
obj_t pp_begin_191_2590;
obj_t pp_do_220_2591;
obj_t pp_comment_9_2592;
obj_t pp_expr_list_161_2593;
obj_t indent_general_51_2594;
obj_t pp_expr_defun_108_2595;
obj_t l_2596;
obj_t col1_2597;
obj_t col2_2598;
obj_t extra_2599;
obj_t pp_item_162_2600;
output_2576 = output_2194;
pp_expr_14_2577 = pp_expr_14_2195;
display__190_2578 = display__190_2193;
max_expr_width_222_2579 = max_expr_width_222_2192;
width_2580 = width_2191;
max_call_head_width_209_2581 = max_call_head_width_209_2190;
pp_lambda_212_2582 = pp_lambda_212_2189;
pp_define_115_2583 = pp_define_115_2188;
pp_defun_212_2584 = pp_defun_212_2187;
pp_if_81_2585 = pp_if_81_2186;
pp_cond_71_2586 = pp_cond_71_2185;
pp_case_154_2587 = pp_case_154_2184;
pp_and_5_2588 = pp_and_5_2183;
pp_let_126_2589 = pp_let_126_2182;
pp_begin_191_2590 = pp_begin_191_2181;
pp_do_220_2591 = pp_do_220_2180;
pp_comment_9_2592 = pp_comment_9_2179;
pp_expr_list_161_2593 = pp_expr_list_161_2178;
indent_general_51_2594 = indent_general_51_2177;
pp_expr_defun_108_2595 = pp_expr_defun_108_2176;
l_2596 = arg1171_652;
col1_2597 = col_1547;
col2_2598 = col_1547;
extra_2599 = extra_638;
pp_item_162_2600 = pp_expr_14_2195;
return loop___pp(pp_item_162_2600, extra_2599, output_2576, col2_2598, pp_expr_14_2577, display__190_2578, max_expr_width_222_2579, width_2580, max_call_head_width_209_2581, pp_lambda_212_2582, pp_define_115_2583, pp_defun_212_2584, pp_if_81_2585, pp_cond_71_2586, pp_case_154_2587, pp_and_5_2588, pp_let_126_2589, pp_begin_191_2590, pp_do_220_2591, pp_comment_9_2592, pp_expr_list_161_2593, indent_general_51_2594, pp_expr_defun_108_2595, l_2596, col1_2597);
}
}
}
}
}
}
 else {
return wr___pp(display__190_2193, output_2194, obj_636, col_637);
}
}
}


/* indent */obj_t indent___pp(obj_t output_2196, obj_t to_662, obj_t col_663)
{
if(CBOOL(col_663)){
bool_t test_3857;
{
long aux_3860;
long aux_3858;
aux_3860 = (long)CINT(col_663);
aux_3858 = (long)CINT(to_662);
test_3857 = (aux_3858<aux_3860);
}
if(test_3857){
obj_t _andtest_1007_667;
{
obj_t arg1183_668;
{
obj_t list1184_669;
{
obj_t aux_3863;
aux_3863 = BCHAR(((unsigned char)'\n'));
list1184_669 = MAKE_PAIR(aux_3863, BNIL);
}
{
obj_t res1523_1556;
{
unsigned char aux_3870;
long aux_3866;
{
obj_t aux_3871;
aux_3871 = CAR(list1184_669);
aux_3870 = (unsigned char)CCHAR(aux_3871);
}
{
int aux_3867;
aux_3867 = (int)(((long)1));
aux_3866 = (long)(aux_3867);
}
res1523_1556 = make_string(aux_3866, aux_3870);
}
arg1183_668 = res1523_1556;
}
}
if(CBOOL(col_663)){
obj_t _andtest_1004_1560;
_andtest_1004_1560 = PROCEDURE_ENTRY(output_2196)(output_2196, arg1183_668, BEOA);
if(CBOOL(_andtest_1004_1560)){
long aux_3881;
{
long aux_3884;
long aux_3882;
aux_3884 = STRING_LENGTH(arg1183_668);
aux_3882 = (long)CINT(col_663);
aux_3881 = (aux_3882+aux_3884);
}
_andtest_1007_667 = BINT(aux_3881);
}
 else {
_andtest_1007_667 = BFALSE;
}
}
 else {
_andtest_1007_667 = BFALSE;
}
}
if(CBOOL(_andtest_1007_667)){
return spaces___pp(output_2196, to_662, BINT(((long)0)));
}
 else {
return BFALSE;
}
}
 else {
obj_t aux_3892;
{
long aux_3893;
{
long aux_3896;
long aux_3894;
aux_3896 = (long)CINT(col_663);
aux_3894 = (long)CINT(to_662);
aux_3893 = (aux_3894-aux_3896);
}
aux_3892 = BINT(aux_3893);
}
return spaces___pp(output_2196, aux_3892, col_663);
}
}
 else {
return BFALSE;
}
}


/* spaces */obj_t spaces___pp(obj_t output_2197, obj_t n_672, obj_t col_673)
{
spaces___pp:
{
bool_t test_3901;
{
long aux_3902;
aux_3902 = (long)CINT(n_672);
test_3901 = (aux_3902>((long)0));
}
if(test_3901){
bool_t test_3905;
{
long aux_3906;
aux_3906 = (long)CINT(n_672);
test_3905 = (aux_3906>((long)7));
}
if(test_3905){
obj_t arg1191_678;
if(CBOOL(col_673)){
obj_t _andtest_1004_1576;
_andtest_1004_1576 = PROCEDURE_ENTRY(output_2197)(output_2197, string1559___pp, BEOA);
if(CBOOL(_andtest_1004_1576)){
long aux_3915;
{
long aux_3918;
long aux_3916;
aux_3918 = STRING_LENGTH(string1559___pp);
aux_3916 = (long)CINT(col_673);
aux_3915 = (aux_3916+aux_3918);
}
arg1191_678 = BINT(aux_3915);
}
 else {
arg1191_678 = BFALSE;
}
}
 else {
arg1191_678 = BFALSE;
}
{
obj_t col_3928;
obj_t n_3922;
{
long aux_3923;
{
long aux_3924;
aux_3924 = (long)CINT(n_672);
aux_3923 = (aux_3924-((long)8));
}
n_3922 = BINT(aux_3923);
}
col_3928 = arg1191_678;
col_673 = col_3928;
n_672 = n_3922;
goto spaces___pp;
}
}
 else {
obj_t arg1192_679;
{
long aux_3929;
aux_3929 = (long)CINT(n_672);
arg1192_679 = c_substring(string1559___pp, ((long)0), aux_3929);
}
if(CBOOL(col_673)){
obj_t _andtest_1004_1587;
_andtest_1004_1587 = PROCEDURE_ENTRY(output_2197)(output_2197, arg1192_679, BEOA);
if(CBOOL(_andtest_1004_1587)){
long aux_3938;
{
long aux_3941;
long aux_3939;
aux_3941 = STRING_LENGTH(arg1192_679);
aux_3939 = (long)CINT(col_673);
aux_3938 = (aux_3939+aux_3941);
}
return BINT(aux_3938);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
 else {
return col_673;
}
}
}


/* pp-general */obj_t pp_general_73___pp(obj_t indent_general_51_2217, obj_t output_2216, obj_t display__190_2215, obj_t pp_expr_14_2214, obj_t max_expr_width_222_2213, obj_t width_2212, obj_t max_call_head_width_209_2211, obj_t pp_lambda_212_2210, obj_t pp_define_115_2209, obj_t pp_defun_212_2208, obj_t pp_if_81_2207, obj_t pp_cond_71_2206, obj_t pp_case_154_2205, obj_t pp_and_5_2204, obj_t pp_let_126_2203, obj_t pp_begin_191_2202, obj_t pp_do_220_2201, obj_t pp_comment_9_2200, obj_t pp_expr_list_161_2199, obj_t pp_expr_defun_108_2198, obj_t expr_513, obj_t col_514, obj_t extra_515, bool_t named__252_516, obj_t pp_1_216_517, obj_t pp_2_0_518, obj_t pp_3_135_519)
{
{
obj_t rest_525;
rest_525 = CDR(expr_513);
{
obj_t col__36_526;
{
obj_t arg1116_536;
if(CBOOL(col_514)){
obj_t _andtest_1004_1251;
_andtest_1004_1251 = PROCEDURE_ENTRY(output_2216)(output_2216, string1552___pp, BEOA);
if(CBOOL(_andtest_1004_1251)){
long aux_3952;
{
long aux_3955;
long aux_3953;
aux_3955 = STRING_LENGTH(string1552___pp);
aux_3953 = (long)CINT(col_514);
aux_3952 = (aux_3953+aux_3955);
}
arg1116_536 = BINT(aux_3952);
}
 else {
arg1116_536 = BFALSE;
}
}
 else {
arg1116_536 = BFALSE;
}
col__36_526 = wr___pp(display__190_2215, output_2216, CAR(expr_513), arg1116_536);
}
{
{
bool_t test_3961;
if(named__252_516){
test_3961 = PAIRP(rest_525);
}
 else {
test_3961 = ((bool_t)0);
}
if(test_3961){
obj_t rest_529;
rest_529 = CDR(rest_525);
{
obj_t col___140_530;
{
obj_t arg1113_533;
if(CBOOL(col__36_526)){
obj_t _andtest_1004_1262;
_andtest_1004_1262 = PROCEDURE_ENTRY(output_2216)(output_2216, string1555___pp, BEOA);
if(CBOOL(_andtest_1004_1262)){
long aux_3971;
{
long aux_3974;
long aux_3972;
aux_3974 = STRING_LENGTH(string1555___pp);
aux_3972 = (long)CINT(col__36_526);
aux_3971 = (aux_3972+aux_3974);
}
arg1113_533 = BINT(aux_3971);
}
 else {
arg1113_533 = BFALSE;
}
}
 else {
arg1113_533 = BFALSE;
}
col___140_530 = wr___pp(display__190_2215, output_2216, CAR(rest_525), arg1113_533);
}
{
{
long arg1111_531;
long arg1112_532;
{
long z1_1267;
long z2_1268;
z1_1267 = (long)CINT(col_514);
{
obj_t aux_3981;
aux_3981 = CELL_REF(indent_general_51_2217);
z2_1268 = (long)CINT(aux_3981);
}
arg1111_531 = (z1_1267+z2_1268);
}
{
long aux_3984;
aux_3984 = (long)CINT(col___140_530);
arg1112_532 = (aux_3984+((long)1));
}
{
bool_t test_3987;
if(CBOOL(pp_1_216_517)){
test_3987 = PAIRP(rest_529);
}
 else {
test_3987 = ((bool_t)0);
}
if(test_3987){
obj_t val1_1276;
val1_1276 = CAR(rest_529);
{
obj_t rest_1277;
rest_1277 = CDR(rest_529);
{
long extra_1278;
if(NULLP(rest_1277)){
long aux_3995;
aux_3995 = (long)CINT(extra_515);
extra_1278 = (aux_3995+((long)1));
}
 else {
extra_1278 = ((long)0);
}
{
{
obj_t arg1125_1280;
{
obj_t arg1126_1281;
arg1126_1281 = indent___pp(output_2216, BINT(arg1112_532), col___140_530);
arg1125_1280 = pr___pp(pp_expr_14_2214, output_2216, display__190_2215, max_expr_width_222_2213, width_2212, max_call_head_width_209_2211, pp_lambda_212_2210, pp_define_115_2209, pp_defun_212_2208, pp_if_81_2207, pp_cond_71_2206, pp_case_154_2205, pp_and_5_2204, pp_let_126_2203, pp_begin_191_2202, pp_do_220_2201, pp_comment_9_2200, pp_expr_list_161_2199, indent_general_51_2217, pp_expr_defun_108_2198, val1_1276, arg1126_1281, BINT(extra_1278), pp_1_216_517);
}
return tail2___pp(pp_3_135_519, extra_515, pp_2_0_518, output_2216, pp_expr_14_2214, display__190_2215, max_expr_width_222_2213, width_2212, max_call_head_width_209_2211, pp_lambda_212_2210, pp_define_115_2209, pp_defun_212_2208, pp_if_81_2207, pp_cond_71_2206, pp_case_154_2205, pp_and_5_2204, pp_let_126_2203, pp_begin_191_2202, pp_do_220_2201, pp_comment_9_2200, pp_expr_list_161_2199, indent_general_51_2217, pp_expr_defun_108_2198, rest_1277, arg1111_531, arg1125_1280, arg1112_532);
}
}
}
}
}
 else {
return tail2___pp(pp_3_135_519, extra_515, pp_2_0_518, output_2216, pp_expr_14_2214, display__190_2215, max_expr_width_222_2213, width_2212, max_call_head_width_209_2211, pp_lambda_212_2210, pp_define_115_2209, pp_defun_212_2208, pp_if_81_2207, pp_cond_71_2206, pp_case_154_2205, pp_and_5_2204, pp_let_126_2203, pp_begin_191_2202, pp_do_220_2201, pp_comment_9_2200, pp_expr_list_161_2199, indent_general_51_2217, pp_expr_defun_108_2198, rest_529, arg1111_531, col___140_530, arg1112_532);
}
}
}
}
}
}
 else {
long arg1114_534;
long arg1115_535;
{
long z1_1288;
long z2_1289;
z1_1288 = (long)CINT(col_514);
{
obj_t aux_4005;
aux_4005 = CELL_REF(indent_general_51_2217);
z2_1289 = (long)CINT(aux_4005);
}
arg1114_534 = (z1_1288+z2_1289);
}
{
long aux_4008;
aux_4008 = (long)CINT(col__36_526);
arg1115_535 = (aux_4008+((long)1));
}
{
bool_t test_4011;
if(CBOOL(pp_1_216_517)){
test_4011 = PAIRP(rest_525);
}
 else {
test_4011 = ((bool_t)0);
}
if(test_4011){
obj_t val1_1297;
val1_1297 = CAR(rest_525);
{
obj_t rest_1298;
rest_1298 = CDR(rest_525);
{
long extra_1299;
if(NULLP(rest_1298)){
long aux_4019;
aux_4019 = (long)CINT(extra_515);
extra_1299 = (aux_4019+((long)1));
}
 else {
extra_1299 = ((long)0);
}
{
{
obj_t arg1125_1301;
{
obj_t arg1126_1302;
arg1126_1302 = indent___pp(output_2216, BINT(arg1115_535), col__36_526);
arg1125_1301 = pr___pp(pp_expr_14_2214, output_2216, display__190_2215, max_expr_width_222_2213, width_2212, max_call_head_width_209_2211, pp_lambda_212_2210, pp_define_115_2209, pp_defun_212_2208, pp_if_81_2207, pp_cond_71_2206, pp_case_154_2205, pp_and_5_2204, pp_let_126_2203, pp_begin_191_2202, pp_do_220_2201, pp_comment_9_2200, pp_expr_list_161_2199, indent_general_51_2217, pp_expr_defun_108_2198, val1_1297, arg1126_1302, BINT(extra_1299), pp_1_216_517);
}
return tail2___pp(pp_3_135_519, extra_515, pp_2_0_518, output_2216, pp_expr_14_2214, display__190_2215, max_expr_width_222_2213, width_2212, max_call_head_width_209_2211, pp_lambda_212_2210, pp_define_115_2209, pp_defun_212_2208, pp_if_81_2207, pp_cond_71_2206, pp_case_154_2205, pp_and_5_2204, pp_let_126_2203, pp_begin_191_2202, pp_do_220_2201, pp_comment_9_2200, pp_expr_list_161_2199, indent_general_51_2217, pp_expr_defun_108_2198, rest_1298, arg1114_534, arg1125_1301, arg1115_535);
}
}
}
}
}
 else {
return tail2___pp(pp_3_135_519, extra_515, pp_2_0_518, output_2216, pp_expr_14_2214, display__190_2215, max_expr_width_222_2213, width_2212, max_call_head_width_209_2211, pp_lambda_212_2210, pp_define_115_2209, pp_defun_212_2208, pp_if_81_2207, pp_cond_71_2206, pp_case_154_2205, pp_and_5_2204, pp_let_126_2203, pp_begin_191_2202, pp_do_220_2201, pp_comment_9_2200, pp_expr_list_161_2199, indent_general_51_2217, pp_expr_defun_108_2198, rest_525, arg1114_534, col__36_526, arg1115_535);
}
}
}
}
}
}
}
}


/* tail2 */obj_t tail2___pp(obj_t pp_3_135_2240, obj_t extra_2239, obj_t pp_2_0_2238, obj_t output_2237, obj_t pp_expr_14_2236, obj_t display__190_2235, obj_t max_expr_width_222_2234, obj_t width_2233, obj_t max_call_head_width_209_2232, obj_t pp_lambda_212_2231, obj_t pp_define_115_2230, obj_t pp_defun_212_2229, obj_t pp_if_81_2228, obj_t pp_cond_71_2227, obj_t pp_case_154_2226, obj_t pp_and_5_2225, obj_t pp_let_126_2224, obj_t pp_begin_191_2223, obj_t pp_do_220_2222, obj_t pp_comment_9_2221, obj_t pp_expr_list_161_2220, obj_t indent_general_51_2219, obj_t pp_expr_defun_108_2218, obj_t rest_541, long col1_542, obj_t col2_543, long col3_544)
{
{
bool_t test_4028;
if(CBOOL(pp_2_0_2238)){
test_4028 = PAIRP(rest_541);
}
 else {
test_4028 = ((bool_t)0);
}
if(test_4028){
obj_t val1_1310;
val1_1310 = CAR(rest_541);
{
obj_t rest_1311;
rest_1311 = CDR(rest_541);
{
long extra_1312;
if(NULLP(rest_1311)){
long aux_4036;
aux_4036 = (long)CINT(extra_2239);
extra_1312 = (aux_4036+((long)1));
}
 else {
extra_1312 = ((long)0);
}
{
{
obj_t arg1120_1314;
{
obj_t arg1121_1315;
arg1121_1315 = indent___pp(output_2237, BINT(col3_544), col2_543);
arg1120_1314 = pr___pp(pp_expr_14_2236, output_2237, display__190_2235, max_expr_width_222_2234, width_2233, max_call_head_width_209_2232, pp_lambda_212_2231, pp_define_115_2230, pp_defun_212_2229, pp_if_81_2228, pp_cond_71_2227, pp_case_154_2226, pp_and_5_2225, pp_let_126_2224, pp_begin_191_2223, pp_do_220_2222, pp_comment_9_2221, pp_expr_list_161_2220, indent_general_51_2219, pp_expr_defun_108_2218, val1_1310, arg1121_1315, BINT(extra_1312), pp_2_0_2238);
}
{
obj_t output_2601;
obj_t pp_expr_14_2602;
obj_t display__190_2603;
obj_t max_expr_width_222_2604;
obj_t width_2605;
obj_t max_call_head_width_209_2606;
obj_t pp_lambda_212_2607;
obj_t pp_define_115_2608;
obj_t pp_defun_212_2609;
obj_t pp_if_81_2610;
obj_t pp_cond_71_2611;
obj_t pp_case_154_2612;
obj_t pp_and_5_2613;
obj_t pp_let_126_2614;
obj_t pp_begin_191_2615;
obj_t pp_do_220_2616;
obj_t pp_comment_9_2617;
obj_t pp_expr_list_161_2618;
obj_t indent_general_51_2619;
obj_t pp_expr_defun_108_2620;
obj_t l_2621;
obj_t col1_2622;
obj_t col2_2623;
obj_t extra_2624;
obj_t pp_item_162_2625;
output_2601 = output_2237;
pp_expr_14_2602 = pp_expr_14_2236;
display__190_2603 = display__190_2235;
max_expr_width_222_2604 = max_expr_width_222_2234;
width_2605 = width_2233;
max_call_head_width_209_2606 = max_call_head_width_209_2232;
pp_lambda_212_2607 = pp_lambda_212_2231;
pp_define_115_2608 = pp_define_115_2230;
pp_defun_212_2609 = pp_defun_212_2229;
pp_if_81_2610 = pp_if_81_2228;
pp_cond_71_2611 = pp_cond_71_2227;
pp_case_154_2612 = pp_case_154_2226;
pp_and_5_2613 = pp_and_5_2225;
pp_let_126_2614 = pp_let_126_2224;
pp_begin_191_2615 = pp_begin_191_2223;
pp_do_220_2616 = pp_do_220_2222;
pp_comment_9_2617 = pp_comment_9_2221;
pp_expr_list_161_2618 = pp_expr_list_161_2220;
indent_general_51_2619 = indent_general_51_2219;
pp_expr_defun_108_2620 = pp_expr_defun_108_2218;
l_2621 = rest_1311;
col1_2622 = arg1120_1314;
col2_2623 = BINT(col1_542);
extra_2624 = extra_2239;
pp_item_162_2625 = pp_3_135_2240;
return loop___pp(pp_item_162_2625, extra_2624, output_2601, col2_2623, pp_expr_14_2602, display__190_2603, max_expr_width_222_2604, width_2605, max_call_head_width_209_2606, pp_lambda_212_2607, pp_define_115_2608, pp_defun_212_2609, pp_if_81_2610, pp_cond_71_2611, pp_case_154_2612, pp_and_5_2613, pp_let_126_2614, pp_begin_191_2615, pp_do_220_2616, pp_comment_9_2617, pp_expr_list_161_2618, indent_general_51_2619, pp_expr_defun_108_2620, l_2621, col1_2622);
}
}
}
}
}
}
 else {
obj_t output_2626;
obj_t pp_expr_14_2627;
obj_t display__190_2628;
obj_t max_expr_width_222_2629;
obj_t width_2630;
obj_t max_call_head_width_209_2631;
obj_t pp_lambda_212_2632;
obj_t pp_define_115_2633;
obj_t pp_defun_212_2634;
obj_t pp_if_81_2635;
obj_t pp_cond_71_2636;
obj_t pp_case_154_2637;
obj_t pp_and_5_2638;
obj_t pp_let_126_2639;
obj_t pp_begin_191_2640;
obj_t pp_do_220_2641;
obj_t pp_comment_9_2642;
obj_t pp_expr_list_161_2643;
obj_t indent_general_51_2644;
obj_t pp_expr_defun_108_2645;
obj_t l_2646;
obj_t col1_2647;
obj_t col2_2648;
obj_t extra_2649;
obj_t pp_item_162_2650;
output_2626 = output_2237;
pp_expr_14_2627 = pp_expr_14_2236;
display__190_2628 = display__190_2235;
max_expr_width_222_2629 = max_expr_width_222_2234;
width_2630 = width_2233;
max_call_head_width_209_2631 = max_call_head_width_209_2232;
pp_lambda_212_2632 = pp_lambda_212_2231;
pp_define_115_2633 = pp_define_115_2230;
pp_defun_212_2634 = pp_defun_212_2229;
pp_if_81_2635 = pp_if_81_2228;
pp_cond_71_2636 = pp_cond_71_2227;
pp_case_154_2637 = pp_case_154_2226;
pp_and_5_2638 = pp_and_5_2225;
pp_let_126_2639 = pp_let_126_2224;
pp_begin_191_2640 = pp_begin_191_2223;
pp_do_220_2641 = pp_do_220_2222;
pp_comment_9_2642 = pp_comment_9_2221;
pp_expr_list_161_2643 = pp_expr_list_161_2220;
indent_general_51_2644 = indent_general_51_2219;
pp_expr_defun_108_2645 = pp_expr_defun_108_2218;
l_2646 = rest_541;
col1_2647 = col2_543;
col2_2648 = BINT(col1_542);
extra_2649 = extra_2239;
pp_item_162_2650 = pp_3_135_2240;
return loop___pp(pp_item_162_2650, extra_2649, output_2626, col2_2648, pp_expr_14_2627, display__190_2628, max_expr_width_222_2629, width_2630, max_call_head_width_209_2631, pp_lambda_212_2632, pp_define_115_2633, pp_defun_212_2634, pp_if_81_2635, pp_cond_71_2636, pp_case_154_2637, pp_and_5_2638, pp_let_126_2639, pp_begin_191_2640, pp_do_220_2641, pp_comment_9_2642, pp_expr_list_161_2643, indent_general_51_2644, pp_expr_defun_108_2645, l_2646, col1_2647);
}
}
}


/* arg1165 */obj_t arg1165___pp(obj_t env_2241, obj_t str_2244)
{
{
obj_t result_2242;
obj_t left_2243;
result_2242 = PROCEDURE_REF(env_2241, ((long)0));
left_2243 = PROCEDURE_REF(env_2241, ((long)1));
{
obj_t str_645;
{
bool_t aux_4049;
str_645 = str_2244;
{
obj_t aux_2245;
{
obj_t obj2_1519;
obj2_1519 = CELL_REF(result_2242);
aux_2245 = MAKE_PAIR(str_645, obj2_1519);
}
CELL_SET(result_2242, aux_2245);
}
{
obj_t aux_2246;
{
long arg1167_1517;
arg1167_1517 = STRING_LENGTH(str_645);
{
long z1_1521;
{
obj_t aux_4052;
aux_4052 = CELL_REF(left_2243);
z1_1521 = (long)CINT(aux_4052);
}
{
long aux_4054;
aux_4054 = (z1_1521-arg1167_1517);
aux_2246 = BINT(aux_4054);
}
}
}
CELL_SET(left_2243, aux_2246);
}
{
long n1_1523;
{
obj_t aux_4057;
aux_4057 = CELL_REF(left_2243);
n1_1523 = (long)CINT(aux_4057);
}
aux_4049 = (n1_1523>((long)0));
}
return BBOOL(aux_4049);
}
}
}
}


/* pp-expr-defun */obj_t pp_expr_defun_108___pp(obj_t env_2247, obj_t l_2267, obj_t col_2268, obj_t extra_2269)
{
{
obj_t indent_general_51_2248;
obj_t width_2249;
obj_t max_expr_width_222_2250;
obj_t display__190_2251;
obj_t pp_expr_list_161_2252;
obj_t pp_comment_9_2253;
obj_t pp_do_220_2254;
obj_t pp_begin_191_2255;
obj_t pp_let_126_2256;
obj_t pp_and_5_2257;
obj_t pp_case_154_2258;
obj_t pp_cond_71_2259;
obj_t pp_if_81_2260;
obj_t pp_defun_212_2261;
obj_t pp_define_115_2262;
obj_t pp_lambda_212_2263;
obj_t max_call_head_width_209_2264;
obj_t output_2265;
obj_t pp_expr_14_2266;
indent_general_51_2248 = PROCEDURE_REF(env_2247, ((long)0));
width_2249 = PROCEDURE_REF(env_2247, ((long)1));
max_expr_width_222_2250 = PROCEDURE_REF(env_2247, ((long)2));
display__190_2251 = PROCEDURE_REF(env_2247, ((long)3));
pp_expr_list_161_2252 = PROCEDURE_REF(env_2247, ((long)4));
pp_comment_9_2253 = PROCEDURE_REF(env_2247, ((long)5));
pp_do_220_2254 = PROCEDURE_REF(env_2247, ((long)6));
pp_begin_191_2255 = PROCEDURE_REF(env_2247, ((long)7));
pp_let_126_2256 = PROCEDURE_REF(env_2247, ((long)8));
pp_and_5_2257 = PROCEDURE_REF(env_2247, ((long)9));
pp_case_154_2258 = PROCEDURE_REF(env_2247, ((long)10));
pp_cond_71_2259 = PROCEDURE_REF(env_2247, ((long)11));
pp_if_81_2260 = PROCEDURE_REF(env_2247, ((long)12));
pp_defun_212_2261 = PROCEDURE_REF(env_2247, ((long)13));
pp_define_115_2262 = PROCEDURE_REF(env_2247, ((long)14));
pp_lambda_212_2263 = PROCEDURE_REF(env_2247, ((long)15));
max_call_head_width_209_2264 = PROCEDURE_REF(env_2247, ((long)16));
output_2265 = PROCEDURE_REF(env_2247, ((long)17));
pp_expr_14_2266 = PROCEDURE_REF(env_2247, ((long)18));
{
obj_t l_505;
obj_t col_506;
obj_t extra_507;
l_505 = l_2267;
col_506 = col_2268;
extra_507 = extra_2269;
{
obj_t col_1224;
col_1224 = out___pp(output_2265, string1560___pp, col_506);
{
obj_t col2_1225;
col2_1225 = wr___pp(display__190_2251, output_2265, CAR(l_505), col_1224);
{
obj_t col3_1227;
{
obj_t aux_4083;
{
obj_t aux_4084;
aux_4084 = CDR(l_505);
aux_4083 = CAR(aux_4084);
}
col3_1227 = wr___pp(display__190_2251, output_2265, aux_4083, col2_1225);
}
{
{
obj_t output_2651;
obj_t pp_expr_14_2652;
obj_t display__190_2653;
obj_t max_expr_width_222_2654;
obj_t width_2655;
obj_t max_call_head_width_209_2656;
obj_t pp_lambda_212_2657;
obj_t pp_define_115_2658;
obj_t pp_defun_212_2659;
obj_t pp_if_81_2660;
obj_t pp_cond_71_2661;
obj_t pp_case_154_2662;
obj_t pp_and_5_2663;
obj_t pp_let_126_2664;
obj_t pp_begin_191_2665;
obj_t pp_do_220_2666;
obj_t pp_comment_9_2667;
obj_t pp_expr_list_161_2668;
obj_t indent_general_51_2669;
obj_t pp_expr_defun_108_2670;
obj_t l_2671;
obj_t col1_2672;
obj_t col2_2673;
obj_t extra_2674;
obj_t pp_item_162_2675;
output_2651 = output_2265;
pp_expr_14_2652 = pp_expr_14_2266;
display__190_2653 = display__190_2251;
max_expr_width_222_2654 = max_expr_width_222_2250;
width_2655 = width_2249;
max_call_head_width_209_2656 = max_call_head_width_209_2264;
pp_lambda_212_2657 = pp_lambda_212_2263;
pp_define_115_2658 = pp_define_115_2262;
pp_defun_212_2659 = pp_defun_212_2261;
pp_if_81_2660 = pp_if_81_2260;
pp_cond_71_2661 = pp_cond_71_2259;
pp_case_154_2662 = pp_case_154_2258;
pp_and_5_2663 = pp_and_5_2257;
pp_let_126_2664 = pp_let_126_2256;
pp_begin_191_2665 = pp_begin_191_2255;
pp_do_220_2666 = pp_do_220_2254;
pp_comment_9_2667 = pp_comment_9_2253;
pp_expr_list_161_2668 = pp_expr_list_161_2252;
indent_general_51_2669 = indent_general_51_2248;
pp_expr_defun_108_2670 = env_2247;
{
obj_t aux_4088;
aux_4088 = CDR(l_505);
l_2671 = CDR(aux_4088);
}
col1_2672 = col3_1227;
{
long aux_4091;
{
long aux_4092;
aux_4092 = (long)CINT(col3_1227);
aux_4091 = (aux_4092+((long)1));
}
col2_2673 = BINT(aux_4091);
}
extra_2674 = extra_507;
pp_item_162_2675 = pp_expr_14_2266;
return loop___pp(pp_item_162_2675, extra_2674, output_2651, col2_2673, pp_expr_14_2652, display__190_2653, max_expr_width_222_2654, width_2655, max_call_head_width_209_2656, pp_lambda_212_2657, pp_define_115_2658, pp_defun_212_2659, pp_if_81_2660, pp_cond_71_2661, pp_case_154_2662, pp_and_5_2663, pp_let_126_2664, pp_begin_191_2665, pp_do_220_2666, pp_comment_9_2667, pp_expr_list_161_2668, indent_general_51_2669, pp_expr_defun_108_2670, l_2671, col1_2672);
}
}
}
}
}
}
}
}


/* pp-expr */obj_t pp_expr_14___pp(obj_t env_2270, obj_t expr_2290, obj_t col_2291, obj_t extra_2292)
{
{
obj_t pp_expr_defun_108_2271;
obj_t indent_general_51_2272;
obj_t width_2273;
obj_t max_expr_width_222_2274;
obj_t display__190_2275;
obj_t pp_expr_list_161_2276;
obj_t pp_comment_9_2277;
obj_t pp_do_220_2278;
obj_t pp_begin_191_2279;
obj_t pp_let_126_2280;
obj_t pp_and_5_2281;
obj_t pp_case_154_2282;
obj_t pp_cond_71_2283;
obj_t pp_if_81_2284;
obj_t pp_defun_212_2285;
obj_t pp_define_115_2286;
obj_t pp_lambda_212_2287;
obj_t max_call_head_width_209_2288;
obj_t output_2289;
pp_expr_defun_108_2271 = PROCEDURE_REF(env_2270, ((long)0));
indent_general_51_2272 = PROCEDURE_REF(env_2270, ((long)1));
width_2273 = PROCEDURE_REF(env_2270, ((long)2));
max_expr_width_222_2274 = PROCEDURE_REF(env_2270, ((long)3));
display__190_2275 = PROCEDURE_REF(env_2270, ((long)4));
pp_expr_list_161_2276 = PROCEDURE_REF(env_2270, ((long)5));
pp_comment_9_2277 = PROCEDURE_REF(env_2270, ((long)6));
pp_do_220_2278 = PROCEDURE_REF(env_2270, ((long)7));
pp_begin_191_2279 = PROCEDURE_REF(env_2270, ((long)8));
pp_let_126_2280 = PROCEDURE_REF(env_2270, ((long)9));
pp_and_5_2281 = PROCEDURE_REF(env_2270, ((long)10));
pp_case_154_2282 = PROCEDURE_REF(env_2270, ((long)11));
pp_cond_71_2283 = PROCEDURE_REF(env_2270, ((long)12));
pp_if_81_2284 = PROCEDURE_REF(env_2270, ((long)13));
pp_defun_212_2285 = PROCEDURE_REF(env_2270, ((long)14));
pp_define_115_2286 = PROCEDURE_REF(env_2270, ((long)15));
pp_lambda_212_2287 = PROCEDURE_REF(env_2270, ((long)16));
max_call_head_width_209_2288 = PROCEDURE_REF(env_2270, ((long)17));
output_2289 = PROCEDURE_REF(env_2270, ((long)18));
{
obj_t expr_622;
obj_t col_623;
obj_t extra_624;
expr_622 = expr_2290;
col_623 = col_2291;
extra_624 = extra_2292;
{
obj_t head_392;
if(read_macro__3___pp(expr_622)){
obj_t arg1157_628;
{
obj_t arg1158_629;
arg1158_629 = read_macro_prefix_111___pp(expr_622);
if(CBOOL(col_623)){
obj_t _andtest_1004_1481;
_andtest_1004_1481 = PROCEDURE_ENTRY(output_2289)(output_2289, arg1158_629, BEOA);
if(CBOOL(_andtest_1004_1481)){
long aux_4125;
{
long aux_4128;
long aux_4126;
aux_4128 = STRING_LENGTH(arg1158_629);
aux_4126 = (long)CINT(col_623);
aux_4125 = (aux_4126+aux_4128);
}
arg1157_628 = BINT(aux_4125);
}
 else {
arg1157_628 = BFALSE;
}
}
 else {
arg1157_628 = BFALSE;
}
}
{
obj_t aux_4132;
{
obj_t aux_4133;
aux_4133 = CDR(expr_622);
aux_4132 = CAR(aux_4133);
}
return pr___pp(env_2270, output_2289, display__190_2275, max_expr_width_222_2274, width_2273, max_call_head_width_209_2288, pp_lambda_212_2287, pp_define_115_2286, pp_defun_212_2285, pp_if_81_2284, pp_cond_71_2283, pp_case_154_2282, pp_and_5_2281, pp_let_126_2280, pp_begin_191_2279, pp_do_220_2278, pp_comment_9_2277, pp_expr_list_161_2276, indent_general_51_2272, pp_expr_defun_108_2271, aux_4132, arg1157_628, extra_624, env_2270);
}
}
 else {
obj_t head_630;
head_630 = CAR(expr_622);
if(SYMBOLP(head_630)){
obj_t proc_632;
head_392 = head_630;
{
obj_t case_value_58_394;
{
bool_t test1063_417;
{
obj_t obj1_1087;
obj1_1087 = _pp_case__242___pp;
test1063_417 = (obj1_1087==symbol1530___pp);
}
if(test1063_417){
obj_t arg1065_418;
{
obj_t arg1066_419;
arg1066_419 = SYMBOL_TO_STRING(head_392);
arg1065_418 = string_upcase_71___r4_strings_6_7(arg1066_419);
}
{
char * aux_4144;
aux_4144 = BSTRING_TO_STRING(arg1065_418);
case_value_58_394 = string_to_symbol(aux_4144);
}
}
 else {
case_value_58_394 = head_392;
}
}
{
bool_t test_4147;
{
obj_t aux_4148;
aux_4148 = memq___r4_pairs_and_lists_6_3(case_value_58_394, list1561___pp);
test_4147 = CBOOL(aux_4148);
}
if(test_4147){
proc_632 = pp_lambda_212_2287;
}
 else {
bool_t test_4151;
{
obj_t aux_4152;
aux_4152 = memq___r4_pairs_and_lists_6_3(case_value_58_394, list1565___pp);
test_4151 = CBOOL(aux_4152);
}
if(test_4151){
proc_632 = pp_define_115_2286;
}
 else {
bool_t test_4155;
{
obj_t aux_4156;
aux_4156 = memq___r4_pairs_and_lists_6_3(case_value_58_394, list1570___pp);
test_4155 = CBOOL(aux_4156);
}
if(test_4155){
proc_632 = pp_defun_212_2285;
}
 else {
bool_t test_4159;
{
obj_t aux_4160;
aux_4160 = memq___r4_pairs_and_lists_6_3(case_value_58_394, list1573___pp);
test_4159 = CBOOL(aux_4160);
}
if(test_4159){
proc_632 = pp_if_81_2284;
}
 else {
if((case_value_58_394==symbol1576___pp)){
proc_632 = pp_cond_71_2283;
}
 else {
if((case_value_58_394==symbol1577___pp)){
proc_632 = pp_case_154_2282;
}
 else {
bool_t test_4167;
{
obj_t aux_4168;
aux_4168 = memq___r4_pairs_and_lists_6_3(case_value_58_394, list1578___pp);
test_4167 = CBOOL(aux_4168);
}
if(test_4167){
proc_632 = pp_and_5_2281;
}
 else {
if((case_value_58_394==symbol1581___pp)){
proc_632 = pp_let_126_2280;
}
 else {
if((case_value_58_394==symbol1582___pp)){
proc_632 = pp_begin_191_2279;
}
 else {
if((case_value_58_394==symbol1583___pp)){
proc_632 = pp_do_220_2278;
}
 else {
if((case_value_58_394==symbol1536___pp)){
proc_632 = pp_comment_9_2277;
}
 else {
proc_632 = BFALSE;
}
}
}
}
}
}
}
}
}
}
}
}
}
if(CBOOL(proc_632)){
return PROCEDURE_ENTRY(proc_632)(proc_632, expr_622, col_623, extra_624, BEOA);
}
 else {
bool_t test1160_633;
{
long arg1161_634;
{
obj_t arg1162_635;
arg1162_635 = SYMBOL_TO_STRING(head_630);
arg1161_634 = STRING_LENGTH(arg1162_635);
}
{
long n2_1491;
{
obj_t aux_4185;
aux_4185 = CELL_REF(max_call_head_width_209_2288);
n2_1491 = (long)CINT(aux_4185);
}
test1160_633 = (arg1161_634>n2_1491);
}
}
if(test1160_633){
return pp_general_73___pp(indent_general_51_2272, output_2289, display__190_2275, env_2270, max_expr_width_222_2274, width_2273, max_call_head_width_209_2288, pp_lambda_212_2287, pp_define_115_2286, pp_defun_212_2285, pp_if_81_2284, pp_cond_71_2283, pp_case_154_2282, pp_and_5_2281, pp_let_126_2280, pp_begin_191_2279, pp_do_220_2278, pp_comment_9_2277, pp_expr_list_161_2276, pp_expr_defun_108_2271, expr_622, col_623, extra_624, ((bool_t)0), BFALSE, BFALSE, env_2270);
}
 else {
obj_t col__36_1495;
{
obj_t arg1153_1497;
arg1153_1497 = out___pp(output_2289, string1552___pp, col_623);
col__36_1495 = wr___pp(display__190_2275, output_2289, head_630, arg1153_1497);
}
if(CBOOL(col_623)){
obj_t output_2676;
obj_t pp_expr_14_2677;
obj_t display__190_2678;
obj_t max_expr_width_222_2679;
obj_t width_2680;
obj_t max_call_head_width_209_2681;
obj_t pp_lambda_212_2682;
obj_t pp_define_115_2683;
obj_t pp_defun_212_2684;
obj_t pp_if_81_2685;
obj_t pp_cond_71_2686;
obj_t pp_case_154_2687;
obj_t pp_and_5_2688;
obj_t pp_let_126_2689;
obj_t pp_begin_191_2690;
obj_t pp_do_220_2691;
obj_t pp_comment_9_2692;
obj_t pp_expr_list_161_2693;
obj_t indent_general_51_2694;
obj_t pp_expr_defun_108_2695;
obj_t l_2696;
obj_t col1_2697;
obj_t col2_2698;
obj_t extra_2699;
obj_t pp_item_162_2700;
output_2676 = output_2289;
pp_expr_14_2677 = env_2270;
display__190_2678 = display__190_2275;
max_expr_width_222_2679 = max_expr_width_222_2274;
width_2680 = width_2273;
max_call_head_width_209_2681 = max_call_head_width_209_2288;
pp_lambda_212_2682 = pp_lambda_212_2287;
pp_define_115_2683 = pp_define_115_2286;
pp_defun_212_2684 = pp_defun_212_2285;
pp_if_81_2685 = pp_if_81_2284;
pp_cond_71_2686 = pp_cond_71_2283;
pp_case_154_2687 = pp_case_154_2282;
pp_and_5_2688 = pp_and_5_2281;
pp_let_126_2689 = pp_let_126_2280;
pp_begin_191_2690 = pp_begin_191_2279;
pp_do_220_2691 = pp_do_220_2278;
pp_comment_9_2692 = pp_comment_9_2277;
pp_expr_list_161_2693 = pp_expr_list_161_2276;
indent_general_51_2694 = indent_general_51_2272;
pp_expr_defun_108_2695 = pp_expr_defun_108_2271;
l_2696 = CDR(expr_622);
col1_2697 = col__36_1495;
{
long aux_4195;
{
long aux_4196;
aux_4196 = (long)CINT(col__36_1495);
aux_4195 = (aux_4196+((long)1));
}
col2_2698 = BINT(aux_4195);
}
extra_2699 = extra_624;
pp_item_162_2700 = env_2270;
return loop___pp(pp_item_162_2700, extra_2699, output_2676, col2_2698, pp_expr_14_2677, display__190_2678, max_expr_width_222_2679, width_2680, max_call_head_width_209_2681, pp_lambda_212_2682, pp_define_115_2683, pp_defun_212_2684, pp_if_81_2685, pp_cond_71_2686, pp_case_154_2687, pp_and_5_2688, pp_let_126_2689, pp_begin_191_2690, pp_do_220_2691, pp_comment_9_2692, pp_expr_list_161_2693, indent_general_51_2694, pp_expr_defun_108_2695, l_2696, col1_2697);
}
 else {
return BFALSE;
}
}
}
}
 else {
obj_t col_1508;
col_1508 = out___pp(output_2289, string1552___pp, col_623);
{
obj_t output_2701;
obj_t pp_expr_14_2702;
obj_t display__190_2703;
obj_t max_expr_width_222_2704;
obj_t width_2705;
obj_t max_call_head_width_209_2706;
obj_t pp_lambda_212_2707;
obj_t pp_define_115_2708;
obj_t pp_defun_212_2709;
obj_t pp_if_81_2710;
obj_t pp_cond_71_2711;
obj_t pp_case_154_2712;
obj_t pp_and_5_2713;
obj_t pp_let_126_2714;
obj_t pp_begin_191_2715;
obj_t pp_do_220_2716;
obj_t pp_comment_9_2717;
obj_t pp_expr_list_161_2718;
obj_t indent_general_51_2719;
obj_t pp_expr_defun_108_2720;
obj_t l_2721;
obj_t col1_2722;
obj_t col2_2723;
obj_t extra_2724;
obj_t pp_item_162_2725;
output_2701 = output_2289;
pp_expr_14_2702 = env_2270;
display__190_2703 = display__190_2275;
max_expr_width_222_2704 = max_expr_width_222_2274;
width_2705 = width_2273;
max_call_head_width_209_2706 = max_call_head_width_209_2288;
pp_lambda_212_2707 = pp_lambda_212_2287;
pp_define_115_2708 = pp_define_115_2286;
pp_defun_212_2709 = pp_defun_212_2285;
pp_if_81_2710 = pp_if_81_2284;
pp_cond_71_2711 = pp_cond_71_2283;
pp_case_154_2712 = pp_case_154_2282;
pp_and_5_2713 = pp_and_5_2281;
pp_let_126_2714 = pp_let_126_2280;
pp_begin_191_2715 = pp_begin_191_2279;
pp_do_220_2716 = pp_do_220_2278;
pp_comment_9_2717 = pp_comment_9_2277;
pp_expr_list_161_2718 = pp_expr_list_161_2276;
indent_general_51_2719 = indent_general_51_2272;
pp_expr_defun_108_2720 = pp_expr_defun_108_2271;
l_2721 = expr_622;
col1_2722 = col_1508;
col2_2723 = col_1508;
extra_2724 = extra_624;
pp_item_162_2725 = env_2270;
return loop___pp(pp_item_162_2725, extra_2724, output_2701, col2_2723, pp_expr_14_2702, display__190_2703, max_expr_width_222_2704, width_2705, max_call_head_width_209_2706, pp_lambda_212_2707, pp_define_115_2708, pp_defun_212_2709, pp_if_81_2710, pp_cond_71_2711, pp_case_154_2712, pp_and_5_2713, pp_let_126_2714, pp_begin_191_2715, pp_do_220_2716, pp_comment_9_2717, pp_expr_list_161_2718, indent_general_51_2719, pp_expr_defun_108_2720, l_2721, col1_2722);
}
}
}
}
}
}
}


/* pp-expr-list */obj_t pp_expr_list_161___pp(obj_t env_2293, obj_t l_2313, obj_t col_2314, obj_t extra_2315)
{
{
obj_t pp_expr_defun_108_2294;
obj_t indent_general_51_2295;
obj_t width_2296;
obj_t max_expr_width_222_2297;
obj_t display__190_2298;
obj_t pp_comment_9_2299;
obj_t pp_do_220_2300;
obj_t pp_begin_191_2301;
obj_t pp_let_126_2302;
obj_t pp_and_5_2303;
obj_t pp_case_154_2304;
obj_t pp_cond_71_2305;
obj_t pp_if_81_2306;
obj_t pp_defun_212_2307;
obj_t pp_define_115_2308;
obj_t pp_lambda_212_2309;
obj_t max_call_head_width_209_2310;
obj_t output_2311;
obj_t pp_expr_14_2312;
pp_expr_defun_108_2294 = PROCEDURE_REF(env_2293, ((long)0));
indent_general_51_2295 = PROCEDURE_REF(env_2293, ((long)1));
width_2296 = PROCEDURE_REF(env_2293, ((long)2));
max_expr_width_222_2297 = PROCEDURE_REF(env_2293, ((long)3));
display__190_2298 = PROCEDURE_REF(env_2293, ((long)4));
pp_comment_9_2299 = PROCEDURE_REF(env_2293, ((long)5));
pp_do_220_2300 = PROCEDURE_REF(env_2293, ((long)6));
pp_begin_191_2301 = PROCEDURE_REF(env_2293, ((long)7));
pp_let_126_2302 = PROCEDURE_REF(env_2293, ((long)8));
pp_and_5_2303 = PROCEDURE_REF(env_2293, ((long)9));
pp_case_154_2304 = PROCEDURE_REF(env_2293, ((long)10));
pp_cond_71_2305 = PROCEDURE_REF(env_2293, ((long)11));
pp_if_81_2306 = PROCEDURE_REF(env_2293, ((long)12));
pp_defun_212_2307 = PROCEDURE_REF(env_2293, ((long)13));
pp_define_115_2308 = PROCEDURE_REF(env_2293, ((long)14));
pp_lambda_212_2309 = PROCEDURE_REF(env_2293, ((long)15));
max_call_head_width_209_2310 = PROCEDURE_REF(env_2293, ((long)16));
output_2311 = PROCEDURE_REF(env_2293, ((long)17));
pp_expr_14_2312 = PROCEDURE_REF(env_2293, ((long)18));
{
obj_t l_509;
obj_t col_510;
obj_t extra_511;
l_509 = l_2313;
col_510 = col_2314;
extra_511 = extra_2315;
{
obj_t col_1245;
col_1245 = out___pp(output_2311, string1552___pp, col_510);
{
obj_t output_2726;
obj_t pp_expr_14_2727;
obj_t display__190_2728;
obj_t max_expr_width_222_2729;
obj_t width_2730;
obj_t max_call_head_width_209_2731;
obj_t pp_lambda_212_2732;
obj_t pp_define_115_2733;
obj_t pp_defun_212_2734;
obj_t pp_if_81_2735;
obj_t pp_cond_71_2736;
obj_t pp_case_154_2737;
obj_t pp_and_5_2738;
obj_t pp_let_126_2739;
obj_t pp_begin_191_2740;
obj_t pp_do_220_2741;
obj_t pp_comment_9_2742;
obj_t pp_expr_list_161_2743;
obj_t indent_general_51_2744;
obj_t pp_expr_defun_108_2745;
obj_t l_2746;
obj_t col1_2747;
obj_t col2_2748;
obj_t extra_2749;
obj_t pp_item_162_2750;
output_2726 = output_2311;
pp_expr_14_2727 = pp_expr_14_2312;
display__190_2728 = display__190_2298;
max_expr_width_222_2729 = max_expr_width_222_2297;
width_2730 = width_2296;
max_call_head_width_209_2731 = max_call_head_width_209_2310;
pp_lambda_212_2732 = pp_lambda_212_2309;
pp_define_115_2733 = pp_define_115_2308;
pp_defun_212_2734 = pp_defun_212_2307;
pp_if_81_2735 = pp_if_81_2306;
pp_cond_71_2736 = pp_cond_71_2305;
pp_case_154_2737 = pp_case_154_2304;
pp_and_5_2738 = pp_and_5_2303;
pp_let_126_2739 = pp_let_126_2302;
pp_begin_191_2740 = pp_begin_191_2301;
pp_do_220_2741 = pp_do_220_2300;
pp_comment_9_2742 = pp_comment_9_2299;
pp_expr_list_161_2743 = env_2293;
indent_general_51_2744 = indent_general_51_2295;
pp_expr_defun_108_2745 = pp_expr_defun_108_2294;
l_2746 = l_509;
col1_2747 = col_1245;
col2_2748 = col_1245;
extra_2749 = extra_511;
pp_item_162_2750 = pp_expr_14_2312;
return loop___pp(pp_item_162_2750, extra_2749, output_2726, col2_2748, pp_expr_14_2727, display__190_2728, max_expr_width_222_2729, width_2730, max_call_head_width_209_2731, pp_lambda_212_2732, pp_define_115_2733, pp_defun_212_2734, pp_if_81_2735, pp_cond_71_2736, pp_case_154_2737, pp_and_5_2738, pp_let_126_2739, pp_begin_191_2740, pp_do_220_2741, pp_comment_9_2742, pp_expr_list_161_2743, indent_general_51_2744, pp_expr_defun_108_2745, l_2746, col1_2747);
}
}
}
}
}


/* pp-lambda */obj_t pp_lambda_212___pp(obj_t env_2316, obj_t expr_2336, obj_t col_2337, obj_t extra_2338)
{
{
obj_t pp_expr_defun_108_2317;
obj_t indent_general_51_2318;
obj_t width_2319;
obj_t max_expr_width_222_2320;
obj_t display__190_2321;
obj_t pp_comment_9_2322;
obj_t pp_do_220_2323;
obj_t pp_begin_191_2324;
obj_t pp_let_126_2325;
obj_t pp_and_5_2326;
obj_t pp_case_154_2327;
obj_t pp_cond_71_2328;
obj_t pp_if_81_2329;
obj_t pp_defun_212_2330;
obj_t pp_define_115_2331;
obj_t max_call_head_width_209_2332;
obj_t output_2333;
obj_t pp_expr_list_161_2334;
obj_t pp_expr_14_2335;
pp_expr_defun_108_2317 = PROCEDURE_REF(env_2316, ((long)0));
indent_general_51_2318 = PROCEDURE_REF(env_2316, ((long)1));
width_2319 = PROCEDURE_REF(env_2316, ((long)2));
max_expr_width_222_2320 = PROCEDURE_REF(env_2316, ((long)3));
display__190_2321 = PROCEDURE_REF(env_2316, ((long)4));
pp_comment_9_2322 = PROCEDURE_REF(env_2316, ((long)5));
pp_do_220_2323 = PROCEDURE_REF(env_2316, ((long)6));
pp_begin_191_2324 = PROCEDURE_REF(env_2316, ((long)7));
pp_let_126_2325 = PROCEDURE_REF(env_2316, ((long)8));
pp_and_5_2326 = PROCEDURE_REF(env_2316, ((long)9));
pp_case_154_2327 = PROCEDURE_REF(env_2316, ((long)10));
pp_cond_71_2328 = PROCEDURE_REF(env_2316, ((long)11));
pp_if_81_2329 = PROCEDURE_REF(env_2316, ((long)12));
pp_defun_212_2330 = PROCEDURE_REF(env_2316, ((long)13));
pp_define_115_2331 = PROCEDURE_REF(env_2316, ((long)14));
max_call_head_width_209_2332 = PROCEDURE_REF(env_2316, ((long)15));
output_2333 = PROCEDURE_REF(env_2316, ((long)16));
pp_expr_list_161_2334 = PROCEDURE_REF(env_2316, ((long)17));
pp_expr_14_2335 = PROCEDURE_REF(env_2316, ((long)18));
{
obj_t expr_493;
obj_t col_494;
obj_t extra_495;
expr_493 = expr_2336;
col_494 = col_2337;
extra_495 = extra_2338;
return pp_general_73___pp(indent_general_51_2318, output_2333, display__190_2321, pp_expr_14_2335, max_expr_width_222_2320, width_2319, max_call_head_width_209_2332, env_2316, pp_define_115_2331, pp_defun_212_2330, pp_if_81_2329, pp_cond_71_2328, pp_case_154_2327, pp_and_5_2326, pp_let_126_2325, pp_begin_191_2324, pp_do_220_2323, pp_comment_9_2322, pp_expr_list_161_2334, pp_expr_defun_108_2317, expr_493, col_494, extra_495, ((bool_t)0), pp_expr_list_161_2334, BFALSE, pp_expr_14_2335);
}
}
}


/* pp-define */obj_t pp_define_115___pp(obj_t env_2339, obj_t expr_2359, obj_t col_2360, obj_t extra_2361)
{
{
obj_t pp_expr_defun_108_2340;
obj_t indent_general_51_2341;
obj_t width_2342;
obj_t max_expr_width_222_2343;
obj_t display__190_2344;
obj_t pp_comment_9_2345;
obj_t pp_do_220_2346;
obj_t pp_begin_191_2347;
obj_t pp_let_126_2348;
obj_t pp_and_5_2349;
obj_t pp_case_154_2350;
obj_t pp_cond_71_2351;
obj_t pp_if_81_2352;
obj_t pp_defun_212_2353;
obj_t pp_lambda_212_2354;
obj_t max_call_head_width_209_2355;
obj_t pp_expr_list_161_2356;
obj_t pp_expr_14_2357;
obj_t output_2358;
pp_expr_defun_108_2340 = PROCEDURE_REF(env_2339, ((long)0));
indent_general_51_2341 = PROCEDURE_REF(env_2339, ((long)1));
width_2342 = PROCEDURE_REF(env_2339, ((long)2));
max_expr_width_222_2343 = PROCEDURE_REF(env_2339, ((long)3));
display__190_2344 = PROCEDURE_REF(env_2339, ((long)4));
pp_comment_9_2345 = PROCEDURE_REF(env_2339, ((long)5));
pp_do_220_2346 = PROCEDURE_REF(env_2339, ((long)6));
pp_begin_191_2347 = PROCEDURE_REF(env_2339, ((long)7));
pp_let_126_2348 = PROCEDURE_REF(env_2339, ((long)8));
pp_and_5_2349 = PROCEDURE_REF(env_2339, ((long)9));
pp_case_154_2350 = PROCEDURE_REF(env_2339, ((long)10));
pp_cond_71_2351 = PROCEDURE_REF(env_2339, ((long)11));
pp_if_81_2352 = PROCEDURE_REF(env_2339, ((long)12));
pp_defun_212_2353 = PROCEDURE_REF(env_2339, ((long)13));
pp_lambda_212_2354 = PROCEDURE_REF(env_2339, ((long)14));
max_call_head_width_209_2355 = PROCEDURE_REF(env_2339, ((long)15));
pp_expr_list_161_2356 = PROCEDURE_REF(env_2339, ((long)16));
pp_expr_14_2357 = PROCEDURE_REF(env_2339, ((long)17));
output_2358 = PROCEDURE_REF(env_2339, ((long)18));
{
obj_t expr_501;
obj_t col_502;
obj_t extra_503;
expr_501 = expr_2359;
col_502 = col_2360;
extra_503 = extra_2361;
pp_general_73___pp(indent_general_51_2341, output_2358, display__190_2344, pp_expr_14_2357, max_expr_width_222_2343, width_2342, max_call_head_width_209_2355, pp_lambda_212_2354, env_2339, pp_defun_212_2353, pp_if_81_2352, pp_cond_71_2351, pp_case_154_2350, pp_and_5_2349, pp_let_126_2348, pp_begin_191_2347, pp_do_220_2346, pp_comment_9_2345, pp_expr_list_161_2356, pp_expr_defun_108_2340, expr_501, col_502, extra_503, ((bool_t)0), pp_expr_list_161_2356, BFALSE, pp_expr_14_2357);
{
obj_t _andtest_1004_1216;
_andtest_1004_1216 = PROCEDURE_ENTRY(output_2358)(output_2358, string1584___pp, BEOA);
if(CBOOL(_andtest_1004_1216)){
long aux_4268;
{
long aux_4269;
aux_4269 = STRING_LENGTH(string1584___pp);
aux_4268 = (((long)0)+aux_4269);
}
return BINT(aux_4268);
}
 else {
return BFALSE;
}
}
}
}
}


/* pp-defun */obj_t pp_defun_212___pp(obj_t env_2362, obj_t expr_2382, obj_t col_2383, obj_t extra_2384)
{
{
obj_t indent_general_51_2363;
obj_t width_2364;
obj_t max_expr_width_222_2365;
obj_t display__190_2366;
obj_t pp_expr_list_161_2367;
obj_t pp_comment_9_2368;
obj_t pp_do_220_2369;
obj_t pp_begin_191_2370;
obj_t pp_let_126_2371;
obj_t pp_and_5_2372;
obj_t pp_case_154_2373;
obj_t pp_cond_71_2374;
obj_t pp_if_81_2375;
obj_t pp_define_115_2376;
obj_t pp_lambda_212_2377;
obj_t max_call_head_width_209_2378;
obj_t pp_expr_defun_108_2379;
obj_t pp_expr_14_2380;
obj_t output_2381;
indent_general_51_2363 = PROCEDURE_REF(env_2362, ((long)0));
width_2364 = PROCEDURE_REF(env_2362, ((long)1));
max_expr_width_222_2365 = PROCEDURE_REF(env_2362, ((long)2));
display__190_2366 = PROCEDURE_REF(env_2362, ((long)3));
pp_expr_list_161_2367 = PROCEDURE_REF(env_2362, ((long)4));
pp_comment_9_2368 = PROCEDURE_REF(env_2362, ((long)5));
pp_do_220_2369 = PROCEDURE_REF(env_2362, ((long)6));
pp_begin_191_2370 = PROCEDURE_REF(env_2362, ((long)7));
pp_let_126_2371 = PROCEDURE_REF(env_2362, ((long)8));
pp_and_5_2372 = PROCEDURE_REF(env_2362, ((long)9));
pp_case_154_2373 = PROCEDURE_REF(env_2362, ((long)10));
pp_cond_71_2374 = PROCEDURE_REF(env_2362, ((long)11));
pp_if_81_2375 = PROCEDURE_REF(env_2362, ((long)12));
pp_define_115_2376 = PROCEDURE_REF(env_2362, ((long)13));
pp_lambda_212_2377 = PROCEDURE_REF(env_2362, ((long)14));
max_call_head_width_209_2378 = PROCEDURE_REF(env_2362, ((long)15));
pp_expr_defun_108_2379 = PROCEDURE_REF(env_2362, ((long)16));
pp_expr_14_2380 = PROCEDURE_REF(env_2362, ((long)17));
output_2381 = PROCEDURE_REF(env_2362, ((long)18));
{
obj_t expr_497;
obj_t col_498;
obj_t extra_499;
expr_497 = expr_2382;
col_498 = col_2383;
extra_499 = extra_2384;
pp_general_73___pp(indent_general_51_2363, output_2381, display__190_2366, pp_expr_14_2380, max_expr_width_222_2365, width_2364, max_call_head_width_209_2378, pp_lambda_212_2377, pp_define_115_2376, env_2362, pp_if_81_2375, pp_cond_71_2374, pp_case_154_2373, pp_and_5_2372, pp_let_126_2371, pp_begin_191_2370, pp_do_220_2369, pp_comment_9_2368, pp_expr_list_161_2367, pp_expr_defun_108_2379, expr_497, col_498, extra_499, ((bool_t)1), pp_expr_defun_108_2379, BFALSE, pp_expr_14_2380);
{
obj_t _andtest_1004_1208;
_andtest_1004_1208 = PROCEDURE_ENTRY(output_2381)(output_2381, string1584___pp, BEOA);
if(CBOOL(_andtest_1004_1208)){
long aux_4297;
{
long aux_4298;
aux_4298 = STRING_LENGTH(string1584___pp);
aux_4297 = (((long)0)+aux_4298);
}
return BINT(aux_4297);
}
 else {
return BFALSE;
}
}
}
}
}


/* pp-if */obj_t pp_if_81___pp(obj_t env_2385, obj_t expr_2405, obj_t col_2406, obj_t extra_2407)
{
{
obj_t pp_expr_defun_108_2386;
obj_t indent_general_51_2387;
obj_t width_2388;
obj_t max_expr_width_222_2389;
obj_t display__190_2390;
obj_t pp_expr_list_161_2391;
obj_t pp_comment_9_2392;
obj_t pp_do_220_2393;
obj_t pp_begin_191_2394;
obj_t pp_let_126_2395;
obj_t pp_and_5_2396;
obj_t pp_case_154_2397;
obj_t pp_cond_71_2398;
obj_t pp_defun_212_2399;
obj_t pp_define_115_2400;
obj_t pp_lambda_212_2401;
obj_t max_call_head_width_209_2402;
obj_t output_2403;
obj_t pp_expr_14_2404;
pp_expr_defun_108_2386 = PROCEDURE_REF(env_2385, ((long)0));
indent_general_51_2387 = PROCEDURE_REF(env_2385, ((long)1));
width_2388 = PROCEDURE_REF(env_2385, ((long)2));
max_expr_width_222_2389 = PROCEDURE_REF(env_2385, ((long)3));
display__190_2390 = PROCEDURE_REF(env_2385, ((long)4));
pp_expr_list_161_2391 = PROCEDURE_REF(env_2385, ((long)5));
pp_comment_9_2392 = PROCEDURE_REF(env_2385, ((long)6));
pp_do_220_2393 = PROCEDURE_REF(env_2385, ((long)7));
pp_begin_191_2394 = PROCEDURE_REF(env_2385, ((long)8));
pp_let_126_2395 = PROCEDURE_REF(env_2385, ((long)9));
pp_and_5_2396 = PROCEDURE_REF(env_2385, ((long)10));
pp_case_154_2397 = PROCEDURE_REF(env_2385, ((long)11));
pp_cond_71_2398 = PROCEDURE_REF(env_2385, ((long)12));
pp_defun_212_2399 = PROCEDURE_REF(env_2385, ((long)13));
pp_define_115_2400 = PROCEDURE_REF(env_2385, ((long)14));
pp_lambda_212_2401 = PROCEDURE_REF(env_2385, ((long)15));
max_call_head_width_209_2402 = PROCEDURE_REF(env_2385, ((long)16));
output_2403 = PROCEDURE_REF(env_2385, ((long)17));
pp_expr_14_2404 = PROCEDURE_REF(env_2385, ((long)18));
{
obj_t expr_449;
obj_t col_450;
obj_t extra_451;
expr_449 = expr_2405;
col_450 = col_2406;
extra_451 = extra_2407;
return pp_general_73___pp(indent_general_51_2387, output_2403, display__190_2390, pp_expr_14_2404, max_expr_width_222_2389, width_2388, max_call_head_width_209_2402, pp_lambda_212_2401, pp_define_115_2400, pp_defun_212_2399, env_2385, pp_cond_71_2398, pp_case_154_2397, pp_and_5_2396, pp_let_126_2395, pp_begin_191_2394, pp_do_220_2393, pp_comment_9_2392, pp_expr_list_161_2391, pp_expr_defun_108_2386, expr_449, col_450, extra_451, ((bool_t)0), pp_expr_14_2404, BFALSE, pp_expr_14_2404);
}
}
}


/* pp-cond */obj_t pp_cond_71___pp(obj_t env_2408, obj_t expr_2428, obj_t col_2429, obj_t extra_2430)
{
{
obj_t pp_expr_defun_108_2409;
obj_t indent_general_51_2410;
obj_t width_2411;
obj_t max_expr_width_222_2412;
obj_t display__190_2413;
obj_t pp_comment_9_2414;
obj_t pp_do_220_2415;
obj_t pp_begin_191_2416;
obj_t pp_let_126_2417;
obj_t pp_and_5_2418;
obj_t pp_case_154_2419;
obj_t pp_if_81_2420;
obj_t pp_defun_212_2421;
obj_t pp_define_115_2422;
obj_t pp_lambda_212_2423;
obj_t max_call_head_width_209_2424;
obj_t output_2425;
obj_t pp_expr_14_2426;
obj_t pp_expr_list_161_2427;
pp_expr_defun_108_2409 = PROCEDURE_REF(env_2408, ((long)0));
indent_general_51_2410 = PROCEDURE_REF(env_2408, ((long)1));
width_2411 = PROCEDURE_REF(env_2408, ((long)2));
max_expr_width_222_2412 = PROCEDURE_REF(env_2408, ((long)3));
display__190_2413 = PROCEDURE_REF(env_2408, ((long)4));
pp_comment_9_2414 = PROCEDURE_REF(env_2408, ((long)5));
pp_do_220_2415 = PROCEDURE_REF(env_2408, ((long)6));
pp_begin_191_2416 = PROCEDURE_REF(env_2408, ((long)7));
pp_let_126_2417 = PROCEDURE_REF(env_2408, ((long)8));
pp_and_5_2418 = PROCEDURE_REF(env_2408, ((long)9));
pp_case_154_2419 = PROCEDURE_REF(env_2408, ((long)10));
pp_if_81_2420 = PROCEDURE_REF(env_2408, ((long)11));
pp_defun_212_2421 = PROCEDURE_REF(env_2408, ((long)12));
pp_define_115_2422 = PROCEDURE_REF(env_2408, ((long)13));
pp_lambda_212_2423 = PROCEDURE_REF(env_2408, ((long)14));
max_call_head_width_209_2424 = PROCEDURE_REF(env_2408, ((long)15));
output_2425 = PROCEDURE_REF(env_2408, ((long)16));
pp_expr_14_2426 = PROCEDURE_REF(env_2408, ((long)17));
pp_expr_list_161_2427 = PROCEDURE_REF(env_2408, ((long)18));
{
obj_t expr_445;
obj_t col_446;
obj_t extra_447;
expr_445 = expr_2428;
col_446 = col_2429;
extra_447 = extra_2430;
{
obj_t col__36_1127;
{
obj_t arg1152_1128;
obj_t arg1153_1129;
arg1152_1128 = CAR(expr_445);
arg1153_1129 = out___pp(output_2425, string1552___pp, col_446);
col__36_1127 = wr___pp(display__190_2413, output_2425, arg1152_1128, arg1153_1129);
}
if(CBOOL(col_446)){
obj_t output_2751;
obj_t pp_expr_14_2752;
obj_t display__190_2753;
obj_t max_expr_width_222_2754;
obj_t width_2755;
obj_t max_call_head_width_209_2756;
obj_t pp_lambda_212_2757;
obj_t pp_define_115_2758;
obj_t pp_defun_212_2759;
obj_t pp_if_81_2760;
obj_t pp_cond_71_2761;
obj_t pp_case_154_2762;
obj_t pp_and_5_2763;
obj_t pp_let_126_2764;
obj_t pp_begin_191_2765;
obj_t pp_do_220_2766;
obj_t pp_comment_9_2767;
obj_t pp_expr_list_161_2768;
obj_t indent_general_51_2769;
obj_t pp_expr_defun_108_2770;
obj_t l_2771;
obj_t col1_2772;
obj_t col2_2773;
obj_t extra_2774;
obj_t pp_item_162_2775;
output_2751 = output_2425;
pp_expr_14_2752 = pp_expr_14_2426;
display__190_2753 = display__190_2413;
max_expr_width_222_2754 = max_expr_width_222_2412;
width_2755 = width_2411;
max_call_head_width_209_2756 = max_call_head_width_209_2424;
pp_lambda_212_2757 = pp_lambda_212_2423;
pp_define_115_2758 = pp_define_115_2422;
pp_defun_212_2759 = pp_defun_212_2421;
pp_if_81_2760 = pp_if_81_2420;
pp_cond_71_2761 = env_2408;
pp_case_154_2762 = pp_case_154_2419;
pp_and_5_2763 = pp_and_5_2418;
pp_let_126_2764 = pp_let_126_2417;
pp_begin_191_2765 = pp_begin_191_2416;
pp_do_220_2766 = pp_do_220_2415;
pp_comment_9_2767 = pp_comment_9_2414;
pp_expr_list_161_2768 = pp_expr_list_161_2427;
indent_general_51_2769 = indent_general_51_2410;
pp_expr_defun_108_2770 = pp_expr_defun_108_2409;
l_2771 = CDR(expr_445);
col1_2772 = col__36_1127;
{
long aux_4347;
{
long aux_4348;
aux_4348 = (long)CINT(col__36_1127);
aux_4347 = (aux_4348+((long)1));
}
col2_2773 = BINT(aux_4347);
}
extra_2774 = extra_447;
pp_item_162_2775 = pp_expr_list_161_2427;
return loop___pp(pp_item_162_2775, extra_2774, output_2751, col2_2773, pp_expr_14_2752, display__190_2753, max_expr_width_222_2754, width_2755, max_call_head_width_209_2756, pp_lambda_212_2757, pp_define_115_2758, pp_defun_212_2759, pp_if_81_2760, pp_cond_71_2761, pp_case_154_2762, pp_and_5_2763, pp_let_126_2764, pp_begin_191_2765, pp_do_220_2766, pp_comment_9_2767, pp_expr_list_161_2768, indent_general_51_2769, pp_expr_defun_108_2770, l_2771, col1_2772);
}
 else {
return BFALSE;
}
}
}
}
}


/* pp-case */obj_t pp_case_154___pp(obj_t env_2431, obj_t expr_2451, obj_t col_2452, obj_t extra_2453)
{
{
obj_t pp_expr_defun_108_2432;
obj_t indent_general_51_2433;
obj_t width_2434;
obj_t max_expr_width_222_2435;
obj_t display__190_2436;
obj_t pp_comment_9_2437;
obj_t pp_do_220_2438;
obj_t pp_begin_191_2439;
obj_t pp_let_126_2440;
obj_t pp_and_5_2441;
obj_t pp_cond_71_2442;
obj_t pp_if_81_2443;
obj_t pp_defun_212_2444;
obj_t pp_define_115_2445;
obj_t pp_lambda_212_2446;
obj_t max_call_head_width_209_2447;
obj_t output_2448;
obj_t pp_expr_14_2449;
obj_t pp_expr_list_161_2450;
pp_expr_defun_108_2432 = PROCEDURE_REF(env_2431, ((long)0));
indent_general_51_2433 = PROCEDURE_REF(env_2431, ((long)1));
width_2434 = PROCEDURE_REF(env_2431, ((long)2));
max_expr_width_222_2435 = PROCEDURE_REF(env_2431, ((long)3));
display__190_2436 = PROCEDURE_REF(env_2431, ((long)4));
pp_comment_9_2437 = PROCEDURE_REF(env_2431, ((long)5));
pp_do_220_2438 = PROCEDURE_REF(env_2431, ((long)6));
pp_begin_191_2439 = PROCEDURE_REF(env_2431, ((long)7));
pp_let_126_2440 = PROCEDURE_REF(env_2431, ((long)8));
pp_and_5_2441 = PROCEDURE_REF(env_2431, ((long)9));
pp_cond_71_2442 = PROCEDURE_REF(env_2431, ((long)10));
pp_if_81_2443 = PROCEDURE_REF(env_2431, ((long)11));
pp_defun_212_2444 = PROCEDURE_REF(env_2431, ((long)12));
pp_define_115_2445 = PROCEDURE_REF(env_2431, ((long)13));
pp_lambda_212_2446 = PROCEDURE_REF(env_2431, ((long)14));
max_call_head_width_209_2447 = PROCEDURE_REF(env_2431, ((long)15));
output_2448 = PROCEDURE_REF(env_2431, ((long)16));
pp_expr_14_2449 = PROCEDURE_REF(env_2431, ((long)17));
pp_expr_list_161_2450 = PROCEDURE_REF(env_2431, ((long)18));
{
obj_t expr_441;
obj_t col_442;
obj_t extra_443;
expr_441 = expr_2451;
col_442 = col_2452;
extra_443 = extra_2453;
return pp_general_73___pp(indent_general_51_2433, output_2448, display__190_2436, pp_expr_14_2449, max_expr_width_222_2435, width_2434, max_call_head_width_209_2447, pp_lambda_212_2446, pp_define_115_2445, pp_defun_212_2444, pp_if_81_2443, pp_cond_71_2442, env_2431, pp_and_5_2441, pp_let_126_2440, pp_begin_191_2439, pp_do_220_2438, pp_comment_9_2437, pp_expr_list_161_2450, pp_expr_defun_108_2432, expr_441, col_442, extra_443, ((bool_t)0), pp_expr_14_2449, BFALSE, pp_expr_list_161_2450);
}
}
}


/* pp-and */obj_t pp_and_5___pp(obj_t env_2454, obj_t expr_2474, obj_t col_2475, obj_t extra_2476)
{
{
obj_t pp_expr_defun_108_2455;
obj_t indent_general_51_2456;
obj_t width_2457;
obj_t max_expr_width_222_2458;
obj_t display__190_2459;
obj_t pp_expr_list_161_2460;
obj_t pp_comment_9_2461;
obj_t pp_do_220_2462;
obj_t pp_begin_191_2463;
obj_t pp_let_126_2464;
obj_t pp_case_154_2465;
obj_t pp_cond_71_2466;
obj_t pp_if_81_2467;
obj_t pp_defun_212_2468;
obj_t pp_define_115_2469;
obj_t pp_lambda_212_2470;
obj_t max_call_head_width_209_2471;
obj_t output_2472;
obj_t pp_expr_14_2473;
pp_expr_defun_108_2455 = PROCEDURE_REF(env_2454, ((long)0));
indent_general_51_2456 = PROCEDURE_REF(env_2454, ((long)1));
width_2457 = PROCEDURE_REF(env_2454, ((long)2));
max_expr_width_222_2458 = PROCEDURE_REF(env_2454, ((long)3));
display__190_2459 = PROCEDURE_REF(env_2454, ((long)4));
pp_expr_list_161_2460 = PROCEDURE_REF(env_2454, ((long)5));
pp_comment_9_2461 = PROCEDURE_REF(env_2454, ((long)6));
pp_do_220_2462 = PROCEDURE_REF(env_2454, ((long)7));
pp_begin_191_2463 = PROCEDURE_REF(env_2454, ((long)8));
pp_let_126_2464 = PROCEDURE_REF(env_2454, ((long)9));
pp_case_154_2465 = PROCEDURE_REF(env_2454, ((long)10));
pp_cond_71_2466 = PROCEDURE_REF(env_2454, ((long)11));
pp_if_81_2467 = PROCEDURE_REF(env_2454, ((long)12));
pp_defun_212_2468 = PROCEDURE_REF(env_2454, ((long)13));
pp_define_115_2469 = PROCEDURE_REF(env_2454, ((long)14));
pp_lambda_212_2470 = PROCEDURE_REF(env_2454, ((long)15));
max_call_head_width_209_2471 = PROCEDURE_REF(env_2454, ((long)16));
output_2472 = PROCEDURE_REF(env_2454, ((long)17));
pp_expr_14_2473 = PROCEDURE_REF(env_2454, ((long)18));
{
obj_t expr_437;
obj_t col_438;
obj_t extra_439;
expr_437 = expr_2474;
col_438 = col_2475;
extra_439 = extra_2476;
{
obj_t col__36_1114;
{
obj_t arg1152_1115;
obj_t arg1153_1116;
arg1152_1115 = CAR(expr_437);
arg1153_1116 = out___pp(output_2472, string1552___pp, col_438);
col__36_1114 = wr___pp(display__190_2459, output_2472, arg1152_1115, arg1153_1116);
}
if(CBOOL(col_438)){
obj_t output_2776;
obj_t pp_expr_14_2777;
obj_t display__190_2778;
obj_t max_expr_width_222_2779;
obj_t width_2780;
obj_t max_call_head_width_209_2781;
obj_t pp_lambda_212_2782;
obj_t pp_define_115_2783;
obj_t pp_defun_212_2784;
obj_t pp_if_81_2785;
obj_t pp_cond_71_2786;
obj_t pp_case_154_2787;
obj_t pp_and_5_2788;
obj_t pp_let_126_2789;
obj_t pp_begin_191_2790;
obj_t pp_do_220_2791;
obj_t pp_comment_9_2792;
obj_t pp_expr_list_161_2793;
obj_t indent_general_51_2794;
obj_t pp_expr_defun_108_2795;
obj_t l_2796;
obj_t col1_2797;
obj_t col2_2798;
obj_t extra_2799;
obj_t pp_item_162_2800;
output_2776 = output_2472;
pp_expr_14_2777 = pp_expr_14_2473;
display__190_2778 = display__190_2459;
max_expr_width_222_2779 = max_expr_width_222_2458;
width_2780 = width_2457;
max_call_head_width_209_2781 = max_call_head_width_209_2471;
pp_lambda_212_2782 = pp_lambda_212_2470;
pp_define_115_2783 = pp_define_115_2469;
pp_defun_212_2784 = pp_defun_212_2468;
pp_if_81_2785 = pp_if_81_2467;
pp_cond_71_2786 = pp_cond_71_2466;
pp_case_154_2787 = pp_case_154_2465;
pp_and_5_2788 = env_2454;
pp_let_126_2789 = pp_let_126_2464;
pp_begin_191_2790 = pp_begin_191_2463;
pp_do_220_2791 = pp_do_220_2462;
pp_comment_9_2792 = pp_comment_9_2461;
pp_expr_list_161_2793 = pp_expr_list_161_2460;
indent_general_51_2794 = indent_general_51_2456;
pp_expr_defun_108_2795 = pp_expr_defun_108_2455;
l_2796 = CDR(expr_437);
col1_2797 = col__36_1114;
{
long aux_4398;
{
long aux_4399;
aux_4399 = (long)CINT(col__36_1114);
aux_4398 = (aux_4399+((long)1));
}
col2_2798 = BINT(aux_4398);
}
extra_2799 = extra_439;
pp_item_162_2800 = pp_expr_14_2473;
return loop___pp(pp_item_162_2800, extra_2799, output_2776, col2_2798, pp_expr_14_2777, display__190_2778, max_expr_width_222_2779, width_2780, max_call_head_width_209_2781, pp_lambda_212_2782, pp_define_115_2783, pp_defun_212_2784, pp_if_81_2785, pp_cond_71_2786, pp_case_154_2787, pp_and_5_2788, pp_let_126_2789, pp_begin_191_2790, pp_do_220_2791, pp_comment_9_2792, pp_expr_list_161_2793, indent_general_51_2794, pp_expr_defun_108_2795, l_2796, col1_2797);
}
 else {
return BFALSE;
}
}
}
}
}


/* pp-let */obj_t pp_let_126___pp(obj_t env_2477, obj_t expr_2497, obj_t col_2498, obj_t extra_2499)
{
{
obj_t pp_expr_defun_108_2478;
obj_t indent_general_51_2479;
obj_t width_2480;
obj_t max_expr_width_222_2481;
obj_t display__190_2482;
obj_t pp_comment_9_2483;
obj_t pp_do_220_2484;
obj_t pp_begin_191_2485;
obj_t pp_and_5_2486;
obj_t pp_case_154_2487;
obj_t pp_cond_71_2488;
obj_t pp_if_81_2489;
obj_t pp_defun_212_2490;
obj_t pp_define_115_2491;
obj_t pp_lambda_212_2492;
obj_t max_call_head_width_209_2493;
obj_t output_2494;
obj_t pp_expr_list_161_2495;
obj_t pp_expr_14_2496;
pp_expr_defun_108_2478 = PROCEDURE_REF(env_2477, ((long)0));
indent_general_51_2479 = PROCEDURE_REF(env_2477, ((long)1));
width_2480 = PROCEDURE_REF(env_2477, ((long)2));
max_expr_width_222_2481 = PROCEDURE_REF(env_2477, ((long)3));
display__190_2482 = PROCEDURE_REF(env_2477, ((long)4));
pp_comment_9_2483 = PROCEDURE_REF(env_2477, ((long)5));
pp_do_220_2484 = PROCEDURE_REF(env_2477, ((long)6));
pp_begin_191_2485 = PROCEDURE_REF(env_2477, ((long)7));
pp_and_5_2486 = PROCEDURE_REF(env_2477, ((long)8));
pp_case_154_2487 = PROCEDURE_REF(env_2477, ((long)9));
pp_cond_71_2488 = PROCEDURE_REF(env_2477, ((long)10));
pp_if_81_2489 = PROCEDURE_REF(env_2477, ((long)11));
pp_defun_212_2490 = PROCEDURE_REF(env_2477, ((long)12));
pp_define_115_2491 = PROCEDURE_REF(env_2477, ((long)13));
pp_lambda_212_2492 = PROCEDURE_REF(env_2477, ((long)14));
max_call_head_width_209_2493 = PROCEDURE_REF(env_2477, ((long)15));
output_2494 = PROCEDURE_REF(env_2477, ((long)16));
pp_expr_list_161_2495 = PROCEDURE_REF(env_2477, ((long)17));
pp_expr_14_2496 = PROCEDURE_REF(env_2477, ((long)18));
{
obj_t expr_429;
obj_t col_430;
obj_t extra_431;
expr_429 = expr_2497;
col_430 = col_2498;
extra_431 = extra_2499;
{
obj_t rest_1103;
rest_1103 = CDR(expr_429);
{
{
bool_t aux_4424;
if(PAIRP(rest_1103)){
obj_t aux_4427;
aux_4427 = CAR(rest_1103);
aux_4424 = SYMBOLP(aux_4427);
}
 else {
aux_4424 = ((bool_t)0);
}
return pp_general_73___pp(indent_general_51_2479, output_2494, display__190_2482, pp_expr_14_2496, max_expr_width_222_2481, width_2480, max_call_head_width_209_2493, pp_lambda_212_2492, pp_define_115_2491, pp_defun_212_2490, pp_if_81_2489, pp_cond_71_2488, pp_case_154_2487, pp_and_5_2486, env_2477, pp_begin_191_2485, pp_do_220_2484, pp_comment_9_2483, pp_expr_list_161_2495, pp_expr_defun_108_2478, expr_429, col_430, extra_431, aux_4424, pp_expr_list_161_2495, BFALSE, pp_expr_14_2496);
}
}
}
}
}
}


/* pp-begin */obj_t pp_begin_191___pp(obj_t env_2500, obj_t expr_2520, obj_t col_2521, obj_t extra_2522)
{
{
obj_t pp_expr_defun_108_2501;
obj_t indent_general_51_2502;
obj_t width_2503;
obj_t max_expr_width_222_2504;
obj_t display__190_2505;
obj_t pp_expr_list_161_2506;
obj_t pp_comment_9_2507;
obj_t pp_do_220_2508;
obj_t pp_let_126_2509;
obj_t pp_and_5_2510;
obj_t pp_case_154_2511;
obj_t pp_cond_71_2512;
obj_t pp_if_81_2513;
obj_t pp_defun_212_2514;
obj_t pp_define_115_2515;
obj_t pp_lambda_212_2516;
obj_t max_call_head_width_209_2517;
obj_t output_2518;
obj_t pp_expr_14_2519;
pp_expr_defun_108_2501 = PROCEDURE_REF(env_2500, ((long)0));
indent_general_51_2502 = PROCEDURE_REF(env_2500, ((long)1));
width_2503 = PROCEDURE_REF(env_2500, ((long)2));
max_expr_width_222_2504 = PROCEDURE_REF(env_2500, ((long)3));
display__190_2505 = PROCEDURE_REF(env_2500, ((long)4));
pp_expr_list_161_2506 = PROCEDURE_REF(env_2500, ((long)5));
pp_comment_9_2507 = PROCEDURE_REF(env_2500, ((long)6));
pp_do_220_2508 = PROCEDURE_REF(env_2500, ((long)7));
pp_let_126_2509 = PROCEDURE_REF(env_2500, ((long)8));
pp_and_5_2510 = PROCEDURE_REF(env_2500, ((long)9));
pp_case_154_2511 = PROCEDURE_REF(env_2500, ((long)10));
pp_cond_71_2512 = PROCEDURE_REF(env_2500, ((long)11));
pp_if_81_2513 = PROCEDURE_REF(env_2500, ((long)12));
pp_defun_212_2514 = PROCEDURE_REF(env_2500, ((long)13));
pp_define_115_2515 = PROCEDURE_REF(env_2500, ((long)14));
pp_lambda_212_2516 = PROCEDURE_REF(env_2500, ((long)15));
max_call_head_width_209_2517 = PROCEDURE_REF(env_2500, ((long)16));
output_2518 = PROCEDURE_REF(env_2500, ((long)17));
pp_expr_14_2519 = PROCEDURE_REF(env_2500, ((long)18));
{
obj_t expr_425;
obj_t col_426;
obj_t extra_427;
expr_425 = expr_2520;
col_426 = col_2521;
extra_427 = extra_2522;
return pp_general_73___pp(indent_general_51_2502, output_2518, display__190_2505, pp_expr_14_2519, max_expr_width_222_2504, width_2503, max_call_head_width_209_2517, pp_lambda_212_2516, pp_define_115_2515, pp_defun_212_2514, pp_if_81_2513, pp_cond_71_2512, pp_case_154_2511, pp_and_5_2510, pp_let_126_2509, env_2500, pp_do_220_2508, pp_comment_9_2507, pp_expr_list_161_2506, pp_expr_defun_108_2501, expr_425, col_426, extra_427, ((bool_t)0), BFALSE, BFALSE, pp_expr_14_2519);
}
}
}


/* pp-do */obj_t pp_do_220___pp(obj_t env_2523, obj_t expr_2543, obj_t col_2544, obj_t extra_2545)
{
{
obj_t pp_expr_defun_108_2524;
obj_t indent_general_51_2525;
obj_t width_2526;
obj_t max_expr_width_222_2527;
obj_t display__190_2528;
obj_t pp_comment_9_2529;
obj_t pp_begin_191_2530;
obj_t pp_let_126_2531;
obj_t pp_and_5_2532;
obj_t pp_case_154_2533;
obj_t pp_cond_71_2534;
obj_t pp_if_81_2535;
obj_t pp_defun_212_2536;
obj_t pp_define_115_2537;
obj_t pp_lambda_212_2538;
obj_t max_call_head_width_209_2539;
obj_t output_2540;
obj_t pp_expr_list_161_2541;
obj_t pp_expr_14_2542;
pp_expr_defun_108_2524 = PROCEDURE_REF(env_2523, ((long)0));
indent_general_51_2525 = PROCEDURE_REF(env_2523, ((long)1));
width_2526 = PROCEDURE_REF(env_2523, ((long)2));
max_expr_width_222_2527 = PROCEDURE_REF(env_2523, ((long)3));
display__190_2528 = PROCEDURE_REF(env_2523, ((long)4));
pp_comment_9_2529 = PROCEDURE_REF(env_2523, ((long)5));
pp_begin_191_2530 = PROCEDURE_REF(env_2523, ((long)6));
pp_let_126_2531 = PROCEDURE_REF(env_2523, ((long)7));
pp_and_5_2532 = PROCEDURE_REF(env_2523, ((long)8));
pp_case_154_2533 = PROCEDURE_REF(env_2523, ((long)9));
pp_cond_71_2534 = PROCEDURE_REF(env_2523, ((long)10));
pp_if_81_2535 = PROCEDURE_REF(env_2523, ((long)11));
pp_defun_212_2536 = PROCEDURE_REF(env_2523, ((long)12));
pp_define_115_2537 = PROCEDURE_REF(env_2523, ((long)13));
pp_lambda_212_2538 = PROCEDURE_REF(env_2523, ((long)14));
max_call_head_width_209_2539 = PROCEDURE_REF(env_2523, ((long)15));
output_2540 = PROCEDURE_REF(env_2523, ((long)16));
pp_expr_list_161_2541 = PROCEDURE_REF(env_2523, ((long)17));
pp_expr_14_2542 = PROCEDURE_REF(env_2523, ((long)18));
{
obj_t expr_421;
obj_t col_422;
obj_t extra_423;
expr_421 = expr_2543;
col_422 = col_2544;
extra_423 = extra_2545;
return pp_general_73___pp(indent_general_51_2525, output_2540, display__190_2528, pp_expr_14_2542, max_expr_width_222_2527, width_2526, max_call_head_width_209_2539, pp_lambda_212_2538, pp_define_115_2537, pp_defun_212_2536, pp_if_81_2535, pp_cond_71_2534, pp_case_154_2533, pp_and_5_2532, pp_let_126_2531, pp_begin_191_2530, env_2523, pp_comment_9_2529, pp_expr_list_161_2541, pp_expr_defun_108_2524, expr_421, col_422, extra_423, ((bool_t)0), pp_expr_list_161_2541, pp_expr_list_161_2541, pp_expr_14_2542);
}
}
}


/* pp-comment */obj_t pp_comment_9___pp(obj_t env_2546, obj_t expr_2566, obj_t col_2567, obj_t extra_2568)
{
{
obj_t pp_expr_defun_108_2547;
obj_t pp_expr_list_161_2548;
obj_t pp_do_220_2549;
obj_t pp_begin_191_2550;
obj_t pp_let_126_2551;
obj_t pp_and_5_2552;
obj_t pp_case_154_2553;
obj_t pp_cond_71_2554;
obj_t pp_if_81_2555;
obj_t pp_defun_212_2556;
obj_t pp_define_115_2557;
obj_t pp_lambda_212_2558;
obj_t max_call_head_width_209_2559;
obj_t width_2560;
obj_t max_expr_width_222_2561;
obj_t display__190_2562;
obj_t indent_general_51_2563;
obj_t pp_expr_14_2564;
obj_t output_2565;
pp_expr_defun_108_2547 = PROCEDURE_REF(env_2546, ((long)0));
pp_expr_list_161_2548 = PROCEDURE_REF(env_2546, ((long)1));
pp_do_220_2549 = PROCEDURE_REF(env_2546, ((long)2));
pp_begin_191_2550 = PROCEDURE_REF(env_2546, ((long)3));
pp_let_126_2551 = PROCEDURE_REF(env_2546, ((long)4));
pp_and_5_2552 = PROCEDURE_REF(env_2546, ((long)5));
pp_case_154_2553 = PROCEDURE_REF(env_2546, ((long)6));
pp_cond_71_2554 = PROCEDURE_REF(env_2546, ((long)7));
pp_if_81_2555 = PROCEDURE_REF(env_2546, ((long)8));
pp_defun_212_2556 = PROCEDURE_REF(env_2546, ((long)9));
pp_define_115_2557 = PROCEDURE_REF(env_2546, ((long)10));
pp_lambda_212_2558 = PROCEDURE_REF(env_2546, ((long)11));
max_call_head_width_209_2559 = PROCEDURE_REF(env_2546, ((long)12));
width_2560 = PROCEDURE_REF(env_2546, ((long)13));
max_expr_width_222_2561 = PROCEDURE_REF(env_2546, ((long)14));
display__190_2562 = PROCEDURE_REF(env_2546, ((long)15));
indent_general_51_2563 = PROCEDURE_REF(env_2546, ((long)16));
pp_expr_14_2564 = PROCEDURE_REF(env_2546, ((long)17));
output_2565 = PROCEDURE_REF(env_2546, ((long)18));
{
obj_t expr_453;
obj_t col_454;
obj_t extra_455;
expr_453 = expr_2566;
col_454 = col_2567;
extra_455 = extra_2568;
{
obj_t column_457;
obj_t string_458;
if(PAIRP(expr_453)){
obj_t cdr_118_57_463;
cdr_118_57_463 = CDR(expr_453);
{
bool_t test_4493;
{
obj_t aux_4494;
aux_4494 = CAR(expr_453);
test_4493 = (aux_4494==symbol1536___pp);
}
if(test_4493){
if(PAIRP(cdr_118_57_463)){
obj_t car_121_84_466;
obj_t cdr_122_80_467;
car_121_84_466 = CAR(cdr_118_57_463);
cdr_122_80_467 = CDR(cdr_118_57_463);
if(INTEGERP(car_121_84_466)){
if(PAIRP(cdr_122_80_467)){
obj_t car_127_13_470;
car_127_13_470 = CAR(cdr_122_80_467);
if(STRINGP(car_127_13_470)){
bool_t test_4508;
{
obj_t aux_4509;
aux_4509 = CDR(cdr_122_80_467);
test_4508 = (aux_4509==BNIL);
}
if(test_4508){
column_457 = car_121_84_466;
string_458 = car_127_13_470;
{
obj_t add_477;
{
obj_t aux_4512;
{
obj_t aux_4513;
{
long aux_4514;
aux_4514 = STRING_LENGTH(string_458);
aux_4513 = BINT(aux_4514);
}
aux_4512 = _2__168___r4_numbers_6_5(aux_4513, BINT(((long)3)));
}
add_477 = _2__79___r4_numbers_6_5(_pp_width__183___pp, aux_4512);
}
{
bool_t test_4520;
{
long aux_4521;
aux_4521 = (long)CINT(column_457);
test_4520 = (aux_4521==((long)0));
}
if(test_4520){
bool_t test_4524;
{
long aux_4525;
aux_4525 = (long)CINT(add_477);
test_4524 = (aux_4525>((long)0));
}
if(test_4524){
obj_t arg1091_480;
{
obj_t arg1093_482;
{
obj_t list1094_483;
{
obj_t aux_4528;
aux_4528 = BCHAR(((unsigned char)' '));
list1094_483 = MAKE_PAIR(aux_4528, BNIL);
}
{
obj_t res1521_1163;
{
unsigned char aux_4535;
long aux_4531;
{
obj_t aux_4536;
aux_4536 = CAR(list1094_483);
aux_4535 = (unsigned char)CCHAR(aux_4536);
}
{
int aux_4532;
aux_4532 = CINT(add_477);
aux_4531 = (long)(aux_4532);
}
res1521_1163 = make_string(aux_4531, aux_4535);
}
arg1093_482 = res1521_1163;
}
}
arg1091_480 = string_append(string_458, arg1093_482);
}
{
obj_t _andtest_1004_1167;
_andtest_1004_1167 = PROCEDURE_ENTRY(output_2565)(output_2565, arg1091_480, BEOA);
if(CBOOL(_andtest_1004_1167)){
long aux_4545;
{
long aux_4546;
aux_4546 = STRING_LENGTH(arg1091_480);
aux_4545 = (((long)0)+aux_4546);
}
return BINT(aux_4545);
}
 else {
return BFALSE;
}
}
}
 else {
obj_t _andtest_1004_1175;
_andtest_1004_1175 = PROCEDURE_ENTRY(output_2565)(output_2565, string_458, BEOA);
if(CBOOL(_andtest_1004_1175)){
long aux_4554;
{
long aux_4555;
aux_4555 = STRING_LENGTH(string_458);
aux_4554 = (((long)0)+aux_4555);
}
return BINT(aux_4554);
}
 else {
return BFALSE;
}
}
}
 else {
bool_t test_4559;
{
long aux_4560;
aux_4560 = (long)CINT(add_477);
test_4559 = (aux_4560>((long)0));
}
if(test_4559){
obj_t arg1097_486;
{
obj_t arg1098_487;
{
obj_t list1099_488;
{
obj_t aux_4563;
aux_4563 = BCHAR(((unsigned char)' '));
list1099_488 = MAKE_PAIR(aux_4563, BNIL);
}
{
obj_t res1522_1188;
{
unsigned char aux_4570;
long aux_4566;
{
obj_t aux_4571;
aux_4571 = CAR(list1099_488);
aux_4570 = (unsigned char)CCHAR(aux_4571);
}
{
int aux_4567;
aux_4567 = CINT(add_477);
aux_4566 = (long)(aux_4567);
}
res1522_1188 = make_string(aux_4566, aux_4570);
}
arg1098_487 = res1522_1188;
}
}
arg1097_486 = string_append(string_458, arg1098_487);
}
if(CBOOL(col_454)){
obj_t _andtest_1004_1192;
_andtest_1004_1192 = PROCEDURE_ENTRY(output_2565)(output_2565, arg1097_486, BEOA);
if(CBOOL(_andtest_1004_1192)){
long aux_4582;
{
long aux_4585;
long aux_4583;
aux_4585 = STRING_LENGTH(arg1097_486);
aux_4583 = (long)CINT(col_454);
aux_4582 = (aux_4583+aux_4585);
}
return BINT(aux_4582);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
if(CBOOL(col_454)){
obj_t _andtest_1004_1200;
_andtest_1004_1200 = PROCEDURE_ENTRY(output_2565)(output_2565, string_458, BEOA);
if(CBOOL(_andtest_1004_1200)){
long aux_4595;
{
long aux_4598;
long aux_4596;
aux_4598 = STRING_LENGTH(string_458);
aux_4596 = (long)CINT(col_454);
aux_4595 = (aux_4596+aux_4598);
}
return BINT(aux_4595);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
}
}
 else {
tag_111_62_460:
return pp_general_73___pp(indent_general_51_2563, output_2565, display__190_2562, pp_expr_14_2564, max_expr_width_222_2561, width_2560, max_call_head_width_209_2559, pp_lambda_212_2558, pp_define_115_2557, pp_defun_212_2556, pp_if_81_2555, pp_cond_71_2554, pp_case_154_2553, pp_and_5_2552, pp_let_126_2551, pp_begin_191_2550, pp_do_220_2549, env_2546, pp_expr_list_161_2548, pp_expr_defun_108_2547, expr_453, col_454, extra_455, ((bool_t)0), pp_expr_14_2564, BFALSE, pp_expr_14_2564);
}
}
 else {
goto tag_111_62_460;
}
}
 else {
goto tag_111_62_460;
}
}
 else {
goto tag_111_62_460;
}
}
 else {
goto tag_111_62_460;
}
}
 else {
goto tag_111_62_460;
}
}
}
 else {
goto tag_111_62_460;
}
}
}
}
}


/* reverse-string-append */obj_t reverse_string_append_127___pp(obj_t l_8)
{
return rev_string_append_254___pp(l_8, ((long)0));
}


/* rev-string-append */obj_t rev_string_append_254___pp(obj_t l_864, long i_865)
{
if(PAIRP(l_864)){
obj_t str_868;
str_868 = CAR(l_864);
{
long len_869;
len_869 = STRING_LENGTH(str_868);
{
obj_t result_870;
result_870 = rev_string_append_254___pp(CDR(l_864), (i_865+len_869));
{
{
long j_2004;
long k_2005;
j_2004 = ((long)0);
{
long aux_4620;
{
long aux_4621;
aux_4621 = STRING_LENGTH(result_870);
aux_4620 = (aux_4621-i_865);
}
k_2005 = (aux_4620-len_869);
}
loop_2003:
if((j_2004<len_869)){
{
unsigned char aux_4613;
aux_4613 = STRING_REF(str_868, j_2004);
STRING_SET(result_870, k_2005, aux_4613);
}
{
long k_4618;
long j_4616;
j_4616 = (j_2004+((long)1));
k_4618 = (k_2005+((long)1));
k_2005 = k_4618;
j_2004 = j_4616;
goto loop_2003;
}
}
 else {
return result_870;
}
}
}
}
}
}
 else {
obj_t res1527_2063;
{
long aux_4625;
{
int aux_4626;
aux_4626 = (int)(i_865);
aux_4625 = (long)(aux_4626);
}
res1527_2063 = make_string(aux_4625, ((unsigned char)' '));
}
return res1527_2063;
}
}


/* imported-modules-init */obj_t imported_modules_init_94___pp()
{
module_initialization_70___error(((long)0), "__PP");
return module_initialization_70___r4_output_6_10_3(((long)0), "__PP");
}

