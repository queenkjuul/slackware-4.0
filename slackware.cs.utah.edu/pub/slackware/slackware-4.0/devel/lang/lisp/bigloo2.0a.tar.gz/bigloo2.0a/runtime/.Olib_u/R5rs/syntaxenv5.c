/*===========================================================================*/
/*   (R5rs/syntaxenv5.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern char * number__string_214___r4_numbers_6_5(obj_t, obj_t);
obj_t denotation_of_if_234___r5_syntax_syntaxenv = BUNSPEC;
static obj_t _macro_rules_225___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t symbol1396___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1392___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1389___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1390___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1387___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1385___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1383___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1381___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1379___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1377___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1375___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1373___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1371___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1369___r5_syntax_syntaxenv = BUNSPEC;
static obj_t symbol1368___r5_syntax_syntaxenv = BUNSPEC;
obj_t denotation_of_letrec_syntax_163___r5_syntax_syntaxenv = BUNSPEC;
static obj_t _same_denotation__131___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
static obj_t list1391___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1388___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1386___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1384___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1382___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1380___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1378___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1376___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1374___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1372___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1370___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1367___r5_syntax_syntaxenv = BUNSPEC;
static obj_t list1366___r5_syntax_syntaxenv = BUNSPEC;
static obj_t _rename_vars_101___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
obj_t denotation_of_____90___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t identifier_name_131___r5_syntax_syntaxenv(obj_t);
extern obj_t string_append(obj_t, obj_t);
static obj_t _syntactic_bind_globally__152___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t syntactic_extend_18___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63___r5_syntax_syntaxenv();
extern obj_t macro__33___r5_syntax_syntaxenv(obj_t);
extern obj_t m_strip_59___r5_syntax_syntaxenv(obj_t);
extern obj_t macro_rules_111___r5_syntax_syntaxenv(obj_t);
static obj_t _macro_env_52___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t syntactic_alias_206___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
static obj_t _rename_formals_208___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
obj_t lambda0___r5_syntax_syntaxenv = BUNSPEC;
obj_t global_syntactic_environment_190___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t m_bug_88___r5_syntax_misc(obj_t, obj_t);
static obj_t _syntactic_rename_43___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
extern obj_t rename_vars_186___r5_syntax_syntaxenv(obj_t);
extern obj_t list__string_78___r4_strings_6_7(obj_t);
extern obj_t same_denotation__10___r5_syntax_syntaxenv(obj_t, obj_t);
obj_t denotation_of_____126___r5_syntax_syntaxenv = BUNSPEC;
static obj_t _make_identifier_denotation_102___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t ident__144___r5_syntax_syntaxenv(obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _macro__195___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t _special__58___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t _syntactic_copy_62___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
static obj_t _syntactic_lookup_38___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
static obj_t lambda1066___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t macro_env_86___r5_syntax_syntaxenv(obj_t);
extern obj_t memv___r4_pairs_and_lists_6_3(obj_t, obj_t);
obj_t denotation_class_62___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t syntactic_bind_globally__231___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t syntactic_rename_48___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t _ident__191___r5_syntax_syntaxenv(obj_t, obj_t);
extern obj_t special__77___r5_syntax_syntaxenv(obj_t);
static obj_t remove_bindings_for_id_146___r5_syntax_syntaxenv(obj_t, obj_t);
obj_t denotation_of_set__245___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t module_initialization_70___r5_syntax_syntaxenv(long, char *);
static obj_t _identifier_name_183___r5_syntax_syntaxenv(obj_t, obj_t);
obj_t denotation_of_define_syntax_255___r5_syntax_syntaxenv = BUNSPEC;
static obj_t _syntactic_assign__152___r5_syntax_syntaxenv(obj_t, obj_t, obj_t, obj_t);
extern obj_t rename_formals_228___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t _syntactic_alias_145___r5_syntax_syntaxenv(obj_t, obj_t, obj_t, obj_t);
obj_t denotation_of_quote_40___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t syntactic_lookup_76___r5_syntax_syntaxenv(obj_t, obj_t);
obj_t denotation_of_let_syntax_71___r5_syntax_syntaxenv = BUNSPEC;
obj_t denotation_of_lambda_93___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t syntactic_assign__111___r5_syntax_syntaxenv(obj_t, obj_t, obj_t);
obj_t denotation_of_define_166___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
obj_t denotation_of_begin_249___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t suffix_character_4___r5_syntax_prefs;
extern obj_t syntactic_copy_24___r5_syntax_syntaxenv(obj_t);
extern obj_t make_identifier_denotation_27___r5_syntax_syntaxenv(obj_t);
obj_t renaming_counter_100___r5_syntax_syntaxenv = BUNSPEC;
obj_t denotation_of_syntax_rules_73___r5_syntax_syntaxenv = BUNSPEC;
static obj_t require_initialization_114___r5_syntax_syntaxenv = BUNSPEC;
extern obj_t string__list_125___r4_strings_6_7(obj_t);
obj_t standard_syntactic_environment_195___r5_syntax_syntaxenv = BUNSPEC;
static obj_t _syntactic_extend_218___r5_syntax_syntaxenv(obj_t, obj_t, obj_t, obj_t);
static obj_t _m_strip_111___r5_syntax_syntaxenv(obj_t, obj_t);
static obj_t cnst_init_137___r5_syntax_syntaxenv();
extern obj_t copy_alist_141___r5_syntax_misc(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( same_denotation__env_71___r5_syntax_syntaxenv, _same_denotation__131___r5_syntax_syntaxenv1400, _same_denotation__131___r5_syntax_syntaxenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( m_strip_env_119___r5_syntax_syntaxenv, _m_strip_111___r5_syntax_syntaxenv1401, _m_strip_111___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( syntactic_alias_env_227___r5_syntax_syntaxenv, _syntactic_alias_145___r5_syntax_syntaxenv1402, _syntactic_alias_145___r5_syntax_syntaxenv, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( syntactic_copy_env_6___r5_syntax_syntaxenv, _syntactic_copy_62___r5_syntax_syntaxenv1403, _syntactic_copy_62___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rename_formals_env_140___r5_syntax_syntaxenv, _rename_formals_208___r5_syntax_syntaxenv1404, _rename_formals_208___r5_syntax_syntaxenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( make_identifier_denotation_env_64___r5_syntax_syntaxenv, _make_identifier_denotation_102___r5_syntax_syntaxenv1405, _make_identifier_denotation_102___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ident__env_243___r5_syntax_syntaxenv, _ident__191___r5_syntax_syntaxenv1406, _ident__191___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( syntactic_lookup_env_22___r5_syntax_syntaxenv, _syntactic_lookup_38___r5_syntax_syntaxenv1407, _syntactic_lookup_38___r5_syntax_syntaxenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( syntactic_extend_env_90___r5_syntax_syntaxenv, _syntactic_extend_218___r5_syntax_syntaxenv1408, _syntactic_extend_218___r5_syntax_syntaxenv, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( macro__env_63___r5_syntax_syntaxenv, _macro__195___r5_syntax_syntaxenv1409, _macro__195___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( syntactic_bind_globally__env_198___r5_syntax_syntaxenv, _syntactic_bind_globally__152___r5_syntax_syntaxenv1410, _syntactic_bind_globally__152___r5_syntax_syntaxenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( macro_rules_env_190___r5_syntax_syntaxenv, _macro_rules_225___r5_syntax_syntaxenv1411, _macro_rules_225___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( special__env_169___r5_syntax_syntaxenv, _special__58___r5_syntax_syntaxenv1412, _special__58___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( syntactic_assign__env_190___r5_syntax_syntaxenv, _syntactic_assign__152___r5_syntax_syntaxenv1413, _syntactic_assign__152___r5_syntax_syntaxenv, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( syntactic_rename_env_164___r5_syntax_syntaxenv, _syntactic_rename_43___r5_syntax_syntaxenv1414, _syntactic_rename_43___r5_syntax_syntaxenv, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1394___r5_syntax_syntaxenv, lambda1066___r5_syntax_syntaxenv1415, lambda1066___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_STRING( string1398___r5_syntax_syntaxenv, string1398___r5_syntax_syntaxenv1416, "Illegal variable", 16 );
DEFINE_STRING( string1397___r5_syntax_syntaxenv, string1397___r5_syntax_syntaxenv1417, "rename-vars", 11 );
DEFINE_STRING( string1395___r5_syntax_syntaxenv, string1395___r5_syntax_syntaxenv1418, "Bug detected in syntactic-assign!", 33 );
DEFINE_STRING( string1393___r5_syntax_syntaxenv, string1393___r5_syntax_syntaxenv1419, " lambda ", 8 );
DEFINE_EXPORT_PROCEDURE( rename_vars_env_196___r5_syntax_syntaxenv, _rename_vars_101___r5_syntax_syntaxenv1420, _rename_vars_101___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( identifier_name_env_91___r5_syntax_syntaxenv, _identifier_name_183___r5_syntax_syntaxenv1421, _identifier_name_183___r5_syntax_syntaxenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( macro_env_env_138___r5_syntax_syntaxenv, _macro_env_52___r5_syntax_syntaxenv1422, _macro_env_52___r5_syntax_syntaxenv, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r5_syntax_syntaxenv(long checksum_1387, char * from_1388)
{
if(CBOOL(require_initialization_114___r5_syntax_syntaxenv)){
require_initialization_114___r5_syntax_syntaxenv = BBOOL(((bool_t)0));
cnst_init_137___r5_syntax_syntaxenv();
toplevel_init_63___r5_syntax_syntaxenv();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r5_syntax_syntaxenv()
{
symbol1368___r5_syntax_syntaxenv = string_to_symbol("QUOTE");
symbol1369___r5_syntax_syntaxenv = string_to_symbol("SPECIAL");
{
obj_t aux_1396;
{
obj_t aux_1397;
aux_1397 = MAKE_PAIR(symbol1368___r5_syntax_syntaxenv, BNIL);
aux_1396 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1397);
}
list1367___r5_syntax_syntaxenv = MAKE_PAIR(symbol1368___r5_syntax_syntaxenv, aux_1396);
}
symbol1371___r5_syntax_syntaxenv = string_to_symbol("LAMBDA");
{
obj_t aux_1402;
{
obj_t aux_1403;
aux_1403 = MAKE_PAIR(symbol1371___r5_syntax_syntaxenv, BNIL);
aux_1402 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1403);
}
list1370___r5_syntax_syntaxenv = MAKE_PAIR(symbol1371___r5_syntax_syntaxenv, aux_1402);
}
symbol1373___r5_syntax_syntaxenv = string_to_symbol("IF");
{
obj_t aux_1408;
{
obj_t aux_1409;
aux_1409 = MAKE_PAIR(symbol1373___r5_syntax_syntaxenv, BNIL);
aux_1408 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1409);
}
list1372___r5_syntax_syntaxenv = MAKE_PAIR(symbol1373___r5_syntax_syntaxenv, aux_1408);
}
symbol1375___r5_syntax_syntaxenv = string_to_symbol("SET!");
{
obj_t aux_1414;
{
obj_t aux_1415;
aux_1415 = MAKE_PAIR(symbol1375___r5_syntax_syntaxenv, BNIL);
aux_1414 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1415);
}
list1374___r5_syntax_syntaxenv = MAKE_PAIR(symbol1375___r5_syntax_syntaxenv, aux_1414);
}
symbol1377___r5_syntax_syntaxenv = string_to_symbol("BEGIN");
{
obj_t aux_1420;
{
obj_t aux_1421;
aux_1421 = MAKE_PAIR(symbol1377___r5_syntax_syntaxenv, BNIL);
aux_1420 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1421);
}
list1376___r5_syntax_syntaxenv = MAKE_PAIR(symbol1377___r5_syntax_syntaxenv, aux_1420);
}
symbol1379___r5_syntax_syntaxenv = string_to_symbol("DEFINE");
{
obj_t aux_1426;
{
obj_t aux_1427;
aux_1427 = MAKE_PAIR(symbol1379___r5_syntax_syntaxenv, BNIL);
aux_1426 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1427);
}
list1378___r5_syntax_syntaxenv = MAKE_PAIR(symbol1379___r5_syntax_syntaxenv, aux_1426);
}
symbol1381___r5_syntax_syntaxenv = string_to_symbol("DEFINE-SYNTAX");
{
obj_t aux_1432;
{
obj_t aux_1433;
aux_1433 = MAKE_PAIR(symbol1381___r5_syntax_syntaxenv, BNIL);
aux_1432 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1433);
}
list1380___r5_syntax_syntaxenv = MAKE_PAIR(symbol1381___r5_syntax_syntaxenv, aux_1432);
}
symbol1383___r5_syntax_syntaxenv = string_to_symbol("LET-SYNTAX");
{
obj_t aux_1438;
{
obj_t aux_1439;
aux_1439 = MAKE_PAIR(symbol1383___r5_syntax_syntaxenv, BNIL);
aux_1438 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1439);
}
list1382___r5_syntax_syntaxenv = MAKE_PAIR(symbol1383___r5_syntax_syntaxenv, aux_1438);
}
symbol1385___r5_syntax_syntaxenv = string_to_symbol("LETREC-SYNTAX");
{
obj_t aux_1444;
{
obj_t aux_1445;
aux_1445 = MAKE_PAIR(symbol1385___r5_syntax_syntaxenv, BNIL);
aux_1444 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1445);
}
list1384___r5_syntax_syntaxenv = MAKE_PAIR(symbol1385___r5_syntax_syntaxenv, aux_1444);
}
symbol1387___r5_syntax_syntaxenv = string_to_symbol("SYNTAX-RULES");
{
obj_t aux_1450;
{
obj_t aux_1451;
aux_1451 = MAKE_PAIR(symbol1387___r5_syntax_syntaxenv, BNIL);
aux_1450 = MAKE_PAIR(symbol1369___r5_syntax_syntaxenv, aux_1451);
}
list1386___r5_syntax_syntaxenv = MAKE_PAIR(symbol1387___r5_syntax_syntaxenv, aux_1450);
}
symbol1389___r5_syntax_syntaxenv = string_to_symbol("...");
symbol1390___r5_syntax_syntaxenv = string_to_symbol("IDENTIFIER");
{
obj_t aux_1457;
{
obj_t aux_1458;
aux_1458 = MAKE_PAIR(symbol1389___r5_syntax_syntaxenv, BNIL);
aux_1457 = MAKE_PAIR(symbol1390___r5_syntax_syntaxenv, aux_1458);
}
list1388___r5_syntax_syntaxenv = MAKE_PAIR(symbol1389___r5_syntax_syntaxenv, aux_1457);
}
symbol1392___r5_syntax_syntaxenv = string_to_symbol("___");
{
obj_t aux_1463;
{
obj_t aux_1464;
aux_1464 = MAKE_PAIR(symbol1392___r5_syntax_syntaxenv, BNIL);
aux_1463 = MAKE_PAIR(symbol1390___r5_syntax_syntaxenv, aux_1464);
}
list1391___r5_syntax_syntaxenv = MAKE_PAIR(symbol1392___r5_syntax_syntaxenv, aux_1463);
}
{
obj_t aux_1468;
{
obj_t aux_1469;
{
obj_t aux_1470;
{
obj_t aux_1471;
{
obj_t aux_1472;
{
obj_t aux_1473;
{
obj_t aux_1474;
{
obj_t aux_1475;
{
obj_t aux_1476;
{
obj_t aux_1477;
{
obj_t aux_1478;
aux_1478 = MAKE_PAIR(list1391___r5_syntax_syntaxenv, BNIL);
aux_1477 = MAKE_PAIR(list1388___r5_syntax_syntaxenv, aux_1478);
}
aux_1476 = MAKE_PAIR(list1386___r5_syntax_syntaxenv, aux_1477);
}
aux_1475 = MAKE_PAIR(list1384___r5_syntax_syntaxenv, aux_1476);
}
aux_1474 = MAKE_PAIR(list1382___r5_syntax_syntaxenv, aux_1475);
}
aux_1473 = MAKE_PAIR(list1380___r5_syntax_syntaxenv, aux_1474);
}
aux_1472 = MAKE_PAIR(list1378___r5_syntax_syntaxenv, aux_1473);
}
aux_1471 = MAKE_PAIR(list1376___r5_syntax_syntaxenv, aux_1472);
}
aux_1470 = MAKE_PAIR(list1374___r5_syntax_syntaxenv, aux_1471);
}
aux_1469 = MAKE_PAIR(list1372___r5_syntax_syntaxenv, aux_1470);
}
aux_1468 = MAKE_PAIR(list1370___r5_syntax_syntaxenv, aux_1469);
}
list1366___r5_syntax_syntaxenv = MAKE_PAIR(list1367___r5_syntax_syntaxenv, aux_1468);
}
return (symbol1396___r5_syntax_syntaxenv = string_to_symbol("MACRO"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r5_syntax_syntaxenv()
{
standard_syntactic_environment_195___r5_syntax_syntaxenv = list1366___r5_syntax_syntaxenv;
{
char * aux_1492;
aux_1492 = BSTRING_TO_STRING(string1393___r5_syntax_syntaxenv);
lambda0___r5_syntax_syntaxenv = string_to_symbol(aux_1492);
}
{
obj_t arg1047_344;
obj_t arg1048_345;
{
obj_t arg1049_346;
{
obj_t arg1050_347;
arg1050_347 = assq___r4_pairs_and_lists_6_3(symbol1371___r5_syntax_syntaxenv, standard_syntactic_environment_195___r5_syntax_syntaxenv);
arg1049_346 = CDR(arg1050_347);
}
{
obj_t obj1_702;
obj1_702 = lambda0___r5_syntax_syntaxenv;
arg1047_344 = MAKE_PAIR(obj1_702, arg1049_346);
}
}
arg1048_345 = copy_alist_141___r5_syntax_misc(standard_syntactic_environment_195___r5_syntax_syntaxenv);
global_syntactic_environment_190___r5_syntax_syntaxenv = MAKE_PAIR(arg1047_344, arg1048_345);
}
{
obj_t arg1053_349;
arg1053_349 = symbol1368___r5_syntax_syntaxenv;
{
obj_t env_706;
env_706 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_708;
{
obj_t entry_711;
entry_711 = assq___r4_pairs_and_lists_6_3(arg1053_349, env_706);
if(CBOOL(entry_711)){
_ortest_1008_708 = CDR(entry_711);
}
 else {
_ortest_1008_708 = BFALSE;
}
}
if(CBOOL(_ortest_1008_708)){
denotation_of_quote_40___r5_syntax_syntaxenv = _ortest_1008_708;
}
 else {
denotation_of_quote_40___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1053_349);
}
}
}
}
{
obj_t arg1054_350;
arg1054_350 = symbol1371___r5_syntax_syntaxenv;
{
obj_t env_713;
env_713 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_715;
{
obj_t entry_718;
entry_718 = assq___r4_pairs_and_lists_6_3(arg1054_350, env_713);
if(CBOOL(entry_718)){
_ortest_1008_715 = CDR(entry_718);
}
 else {
_ortest_1008_715 = BFALSE;
}
}
if(CBOOL(_ortest_1008_715)){
denotation_of_lambda_93___r5_syntax_syntaxenv = _ortest_1008_715;
}
 else {
denotation_of_lambda_93___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1054_350);
}
}
}
}
{
obj_t arg1055_351;
arg1055_351 = symbol1373___r5_syntax_syntaxenv;
{
obj_t env_720;
env_720 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_722;
{
obj_t entry_725;
entry_725 = assq___r4_pairs_and_lists_6_3(arg1055_351, env_720);
if(CBOOL(entry_725)){
_ortest_1008_722 = CDR(entry_725);
}
 else {
_ortest_1008_722 = BFALSE;
}
}
if(CBOOL(_ortest_1008_722)){
denotation_of_if_234___r5_syntax_syntaxenv = _ortest_1008_722;
}
 else {
denotation_of_if_234___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1055_351);
}
}
}
}
{
obj_t arg1056_352;
arg1056_352 = symbol1375___r5_syntax_syntaxenv;
{
obj_t env_727;
env_727 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_729;
{
obj_t entry_732;
entry_732 = assq___r4_pairs_and_lists_6_3(arg1056_352, env_727);
if(CBOOL(entry_732)){
_ortest_1008_729 = CDR(entry_732);
}
 else {
_ortest_1008_729 = BFALSE;
}
}
if(CBOOL(_ortest_1008_729)){
denotation_of_set__245___r5_syntax_syntaxenv = _ortest_1008_729;
}
 else {
denotation_of_set__245___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1056_352);
}
}
}
}
{
obj_t arg1057_353;
arg1057_353 = symbol1377___r5_syntax_syntaxenv;
{
obj_t env_734;
env_734 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_736;
{
obj_t entry_739;
entry_739 = assq___r4_pairs_and_lists_6_3(arg1057_353, env_734);
if(CBOOL(entry_739)){
_ortest_1008_736 = CDR(entry_739);
}
 else {
_ortest_1008_736 = BFALSE;
}
}
if(CBOOL(_ortest_1008_736)){
denotation_of_begin_249___r5_syntax_syntaxenv = _ortest_1008_736;
}
 else {
denotation_of_begin_249___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1057_353);
}
}
}
}
{
obj_t arg1058_354;
arg1058_354 = symbol1379___r5_syntax_syntaxenv;
{
obj_t env_741;
env_741 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_743;
{
obj_t entry_746;
entry_746 = assq___r4_pairs_and_lists_6_3(arg1058_354, env_741);
if(CBOOL(entry_746)){
_ortest_1008_743 = CDR(entry_746);
}
 else {
_ortest_1008_743 = BFALSE;
}
}
if(CBOOL(_ortest_1008_743)){
denotation_of_define_166___r5_syntax_syntaxenv = _ortest_1008_743;
}
 else {
denotation_of_define_166___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1058_354);
}
}
}
}
{
obj_t arg1059_355;
arg1059_355 = symbol1381___r5_syntax_syntaxenv;
{
obj_t env_748;
env_748 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_750;
{
obj_t entry_753;
entry_753 = assq___r4_pairs_and_lists_6_3(arg1059_355, env_748);
if(CBOOL(entry_753)){
_ortest_1008_750 = CDR(entry_753);
}
 else {
_ortest_1008_750 = BFALSE;
}
}
if(CBOOL(_ortest_1008_750)){
denotation_of_define_syntax_255___r5_syntax_syntaxenv = _ortest_1008_750;
}
 else {
denotation_of_define_syntax_255___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1059_355);
}
}
}
}
{
obj_t arg1060_356;
arg1060_356 = symbol1383___r5_syntax_syntaxenv;
{
obj_t env_755;
env_755 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_757;
{
obj_t entry_760;
entry_760 = assq___r4_pairs_and_lists_6_3(arg1060_356, env_755);
if(CBOOL(entry_760)){
_ortest_1008_757 = CDR(entry_760);
}
 else {
_ortest_1008_757 = BFALSE;
}
}
if(CBOOL(_ortest_1008_757)){
denotation_of_let_syntax_71___r5_syntax_syntaxenv = _ortest_1008_757;
}
 else {
denotation_of_let_syntax_71___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1060_356);
}
}
}
}
{
obj_t arg1061_357;
arg1061_357 = symbol1385___r5_syntax_syntaxenv;
{
obj_t env_762;
env_762 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_764;
{
obj_t entry_767;
entry_767 = assq___r4_pairs_and_lists_6_3(arg1061_357, env_762);
if(CBOOL(entry_767)){
_ortest_1008_764 = CDR(entry_767);
}
 else {
_ortest_1008_764 = BFALSE;
}
}
if(CBOOL(_ortest_1008_764)){
denotation_of_letrec_syntax_163___r5_syntax_syntaxenv = _ortest_1008_764;
}
 else {
denotation_of_letrec_syntax_163___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1061_357);
}
}
}
}
{
obj_t arg1062_358;
arg1062_358 = symbol1387___r5_syntax_syntaxenv;
{
obj_t env_769;
env_769 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_771;
{
obj_t entry_774;
entry_774 = assq___r4_pairs_and_lists_6_3(arg1062_358, env_769);
if(CBOOL(entry_774)){
_ortest_1008_771 = CDR(entry_774);
}
 else {
_ortest_1008_771 = BFALSE;
}
}
if(CBOOL(_ortest_1008_771)){
denotation_of_syntax_rules_73___r5_syntax_syntaxenv = _ortest_1008_771;
}
 else {
denotation_of_syntax_rules_73___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1062_358);
}
}
}
}
{
obj_t arg1063_359;
arg1063_359 = symbol1389___r5_syntax_syntaxenv;
{
obj_t env_776;
env_776 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_778;
{
obj_t entry_781;
entry_781 = assq___r4_pairs_and_lists_6_3(arg1063_359, env_776);
if(CBOOL(entry_781)){
_ortest_1008_778 = CDR(entry_781);
}
 else {
_ortest_1008_778 = BFALSE;
}
}
if(CBOOL(_ortest_1008_778)){
denotation_of_____126___r5_syntax_syntaxenv = _ortest_1008_778;
}
 else {
denotation_of_____126___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1063_359);
}
}
}
}
{
obj_t arg1065_360;
arg1065_360 = symbol1392___r5_syntax_syntaxenv;
{
obj_t env_783;
env_783 = standard_syntactic_environment_195___r5_syntax_syntaxenv;
{
obj_t _ortest_1008_785;
{
obj_t entry_788;
entry_788 = assq___r4_pairs_and_lists_6_3(arg1065_360, env_783);
if(CBOOL(entry_788)){
_ortest_1008_785 = CDR(entry_788);
}
 else {
_ortest_1008_785 = BFALSE;
}
}
if(CBOOL(_ortest_1008_785)){
denotation_of_____90___r5_syntax_syntaxenv = _ortest_1008_785;
}
 else {
denotation_of_____90___r5_syntax_syntaxenv = make_identifier_denotation_27___r5_syntax_syntaxenv(arg1065_360);
}
}
}
}
{
obj_t lambda1066_1334;
lambda1066_1334 = proc1394___r5_syntax_syntaxenv;
denotation_class_62___r5_syntax_syntaxenv = lambda1066_1334;
}
return (renaming_counter_100___r5_syntax_syntaxenv = BINT(((long)0)),
BUNSPEC);
}


/* lambda1066 */obj_t lambda1066___r5_syntax_syntaxenv(obj_t env_1335, obj_t a0_1336)
{
{
obj_t a0_1385;
a0_1385 = a0_1336;
return CAR(a0_1385);
}
}


/* syntactic-copy */obj_t syntactic_copy_24___r5_syntax_syntaxenv(obj_t env_2)
{
return copy_alist_141___r5_syntax_misc(env_2);
}


/* _syntactic-copy */obj_t _syntactic_copy_62___r5_syntax_syntaxenv(obj_t env_1337, obj_t env_1338)
{
{
obj_t env_1386;
env_1386 = env_1338;
return copy_alist_141___r5_syntax_misc(env_1386);
}
}


/* syntactic-bind-globally! */obj_t syntactic_bind_globally__231___r5_syntax_syntaxenv(obj_t id_3, obj_t denotation_4)
{
{
bool_t test1067_363;
{
bool_t test1084_381;
{
obj_t arg1109_794;
arg1109_794 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, denotation_4, BEOA);
test1084_381 = (arg1109_794==symbol1390___r5_syntax_syntaxenv);
}
if(test1084_381){
obj_t aux_1592;
{
obj_t aux_1593;
aux_1593 = CDR(denotation_4);
aux_1592 = CAR(aux_1593);
}
test1067_363 = (id_3==aux_1592);
}
 else {
test1067_363 = ((bool_t)0);
}
}
if(test1067_363){
obj_t arg1068_365;
{
obj_t arg1069_366;
{
obj_t pair_805;
pair_805 = global_syntactic_environment_190___r5_syntax_syntaxenv;
arg1069_366 = CDR(pair_805);
}
arg1068_365 = remove_bindings_for_id_146___r5_syntax_syntaxenv(id_3, arg1069_366);
}
{
obj_t pair_807;
pair_807 = global_syntactic_environment_190___r5_syntax_syntaxenv;
return SET_CDR(pair_807, arg1068_365);
}
}
 else {
obj_t x_377;
x_377 = assq___r4_pairs_and_lists_6_3(id_3, global_syntactic_environment_190___r5_syntax_syntaxenv);
if(CBOOL(x_377)){
return SET_CDR(x_377, denotation_4);
}
 else {
obj_t arg1081_378;
{
obj_t arg1082_379;
obj_t arg1083_380;
arg1082_379 = MAKE_PAIR(id_3, denotation_4);
{
obj_t pair_825;
pair_825 = global_syntactic_environment_190___r5_syntax_syntaxenv;
arg1083_380 = CDR(pair_825);
}
arg1081_378 = MAKE_PAIR(arg1082_379, arg1083_380);
}
{
obj_t pair_829;
pair_829 = global_syntactic_environment_190___r5_syntax_syntaxenv;
return SET_CDR(pair_829, arg1081_378);
}
}
}
}
}


/* remove-bindings-for-id */obj_t remove_bindings_for_id_146___r5_syntax_syntaxenv(obj_t id_1384, obj_t bindings_367)
{
remove_bindings_for_id_146___r5_syntax_syntaxenv:
if(NULLP(bindings_367)){
return BNIL;
}
 else {
bool_t test_1611;
{
obj_t aux_1612;
{
obj_t aux_1613;
aux_1613 = CAR(bindings_367);
aux_1612 = CAR(aux_1613);
}
test_1611 = (aux_1612==id_1384);
}
if(test_1611){
{
obj_t bindings_1617;
bindings_1617 = CDR(bindings_367);
bindings_367 = bindings_1617;
goto remove_bindings_for_id_146___r5_syntax_syntaxenv;
}
}
 else {
{
obj_t arg1077_372;
obj_t arg1078_373;
arg1077_372 = CAR(bindings_367);
arg1078_373 = remove_bindings_for_id_146___r5_syntax_syntaxenv(id_1384, CDR(bindings_367));
return MAKE_PAIR(arg1077_372, arg1078_373);
}
}
}
}


/* _syntactic-bind-globally! */obj_t _syntactic_bind_globally__152___r5_syntax_syntaxenv(obj_t env_1339, obj_t id_1340, obj_t denotation_1341)
{
return syntactic_bind_globally__231___r5_syntax_syntaxenv(id_1340, denotation_1341);
}


/* syntactic-extend */obj_t syntactic_extend_18___r5_syntax_syntaxenv(obj_t env_7, obj_t ids_8, obj_t denotations_9)
{
{
obj_t arg1086_383;
if(NULLP(ids_8)){
arg1086_383 = BNIL;
}
 else {
obj_t head1004_387;
{
obj_t arg1097_402;
{
obj_t aux_1628;
obj_t aux_1626;
aux_1628 = CAR(denotations_9);
aux_1626 = CAR(ids_8);
arg1097_402 = MAKE_PAIR(aux_1626, aux_1628);
}
head1004_387 = MAKE_PAIR(arg1097_402, BNIL);
}
{
obj_t ll1002_841;
obj_t ll1003_842;
obj_t tail1005_843;
ll1002_841 = CDR(ids_8);
ll1003_842 = CDR(denotations_9);
tail1005_843 = head1004_387;
lname1007_840:
if(NULLP(ll1002_841)){
arg1086_383 = head1004_387;
}
 else {
obj_t newtail1006_853;
{
obj_t arg1093_854;
{
obj_t aux_1636;
obj_t aux_1634;
aux_1636 = CAR(ll1003_842);
aux_1634 = CAR(ll1002_841);
arg1093_854 = MAKE_PAIR(aux_1634, aux_1636);
}
newtail1006_853 = MAKE_PAIR(arg1093_854, BNIL);
}
SET_CDR(tail1005_843, newtail1006_853);
{
obj_t tail1005_1645;
obj_t ll1003_1643;
obj_t ll1002_1641;
ll1002_1641 = CDR(ll1002_841);
ll1003_1643 = CDR(ll1003_842);
tail1005_1645 = newtail1006_853;
tail1005_843 = tail1005_1645;
ll1003_842 = ll1003_1643;
ll1002_841 = ll1002_1641;
goto lname1007_840;
}
}
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1086_383, env_7);
}
}


/* _syntactic-extend */obj_t _syntactic_extend_218___r5_syntax_syntaxenv(obj_t env_1342, obj_t env_1343, obj_t ids_1344, obj_t denotations_1345)
{
return syntactic_extend_18___r5_syntax_syntaxenv(env_1343, ids_1344, denotations_1345);
}


/* syntactic-lookup */obj_t syntactic_lookup_76___r5_syntax_syntaxenv(obj_t env_12, obj_t id_13)
{
{
obj_t _ortest_1008_916;
{
obj_t entry_919;
entry_919 = assq___r4_pairs_and_lists_6_3(id_13, env_12);
if(CBOOL(entry_919)){
_ortest_1008_916 = CDR(entry_919);
}
 else {
_ortest_1008_916 = BFALSE;
}
}
if(CBOOL(_ortest_1008_916)){
return _ortest_1008_916;
}
 else {
obj_t arg1111_922;
arg1111_922 = symbol1390___r5_syntax_syntaxenv;
{
obj_t list1112_923;
{
obj_t arg1113_924;
arg1113_924 = MAKE_PAIR(id_13, BNIL);
list1112_923 = MAKE_PAIR(arg1111_922, arg1113_924);
}
return list1112_923;
}
}
}
}


/* _syntactic-lookup */obj_t _syntactic_lookup_38___r5_syntax_syntaxenv(obj_t env_1346, obj_t env_1347, obj_t id_1348)
{
return syntactic_lookup_76___r5_syntax_syntaxenv(env_1347, id_1348);
}


/* syntactic-assign! */obj_t syntactic_assign__111___r5_syntax_syntaxenv(obj_t env_14, obj_t id_15, obj_t denotation_16)
{
{
obj_t entry_927;
entry_927 = assq___r4_pairs_and_lists_6_3(id_15, env_14);
if(CBOOL(entry_927)){
return SET_CDR(entry_927, denotation_16);
}
 else {
obj_t list1101_928;
{
obj_t arg1102_929;
{
obj_t arg1103_930;
arg1103_930 = MAKE_PAIR(denotation_16, BNIL);
arg1102_929 = MAKE_PAIR(id_15, arg1103_930);
}
list1101_928 = MAKE_PAIR(env_14, arg1102_929);
}
return m_bug_88___r5_syntax_misc(string1395___r5_syntax_syntaxenv, list1101_928);
}
}
}


/* _syntactic-assign! */obj_t _syntactic_assign__152___r5_syntax_syntaxenv(obj_t env_1349, obj_t env_1350, obj_t id_1351, obj_t denotation_1352)
{
return syntactic_assign__111___r5_syntax_syntaxenv(env_1350, id_1351, denotation_1352);
}


/* special? */obj_t special__77___r5_syntax_syntaxenv(obj_t denotation_17)
{
{
obj_t arg1105_934;
arg1105_934 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, denotation_17, BEOA);
{
bool_t aux_1670;
aux_1670 = (arg1105_934==symbol1369___r5_syntax_syntaxenv);
return BBOOL(aux_1670);
}
}
}


/* _special? */obj_t _special__58___r5_syntax_syntaxenv(obj_t env_1353, obj_t denotation_1354)
{
return special__77___r5_syntax_syntaxenv(denotation_1354);
}


/* macro? */obj_t macro__33___r5_syntax_syntaxenv(obj_t denotation_18)
{
{
obj_t arg1107_938;
arg1107_938 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, denotation_18, BEOA);
{
bool_t aux_1676;
aux_1676 = (arg1107_938==symbol1396___r5_syntax_syntaxenv);
return BBOOL(aux_1676);
}
}
}


/* _macro? */obj_t _macro__195___r5_syntax_syntaxenv(obj_t env_1355, obj_t denotation_1356)
{
return macro__33___r5_syntax_syntaxenv(denotation_1356);
}


/* ident? */obj_t ident__144___r5_syntax_syntaxenv(obj_t denotation_19)
{
{
obj_t arg1109_942;
arg1109_942 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, denotation_19, BEOA);
{
bool_t aux_1682;
aux_1682 = (arg1109_942==symbol1390___r5_syntax_syntaxenv);
return BBOOL(aux_1682);
}
}
}


/* _ident? */obj_t _ident__191___r5_syntax_syntaxenv(obj_t env_1357, obj_t denotation_1358)
{
return ident__144___r5_syntax_syntaxenv(denotation_1358);
}


/* make-identifier-denotation */obj_t make_identifier_denotation_27___r5_syntax_syntaxenv(obj_t id_20)
{
{
obj_t arg1111_946;
arg1111_946 = symbol1390___r5_syntax_syntaxenv;
{
obj_t list1112_947;
{
obj_t arg1113_948;
arg1113_948 = MAKE_PAIR(id_20, BNIL);
list1112_947 = MAKE_PAIR(arg1111_946, arg1113_948);
}
return list1112_947;
}
}
}


/* _make-identifier-denotation */obj_t _make_identifier_denotation_102___r5_syntax_syntaxenv(obj_t env_1359, obj_t id_1360)
{
return make_identifier_denotation_27___r5_syntax_syntaxenv(id_1360);
}


/* macro-rules */obj_t macro_rules_111___r5_syntax_syntaxenv(obj_t x_21)
{
{
obj_t aux_1689;
aux_1689 = CDR(x_21);
return CAR(aux_1689);
}
}


/* _macro-rules */obj_t _macro_rules_225___r5_syntax_syntaxenv(obj_t env_1361, obj_t x_1362)
{
return macro_rules_111___r5_syntax_syntaxenv(x_1362);
}


/* macro-env */obj_t macro_env_86___r5_syntax_syntaxenv(obj_t x_22)
{
{
obj_t aux_1693;
{
obj_t aux_1694;
aux_1694 = CDR(x_22);
aux_1693 = CDR(aux_1694);
}
return CAR(aux_1693);
}
}


/* _macro-env */obj_t _macro_env_52___r5_syntax_syntaxenv(obj_t env_1363, obj_t x_1364)
{
return macro_env_86___r5_syntax_syntaxenv(x_1364);
}


/* identifier-name */obj_t identifier_name_131___r5_syntax_syntaxenv(obj_t x_23)
{
{
obj_t aux_1699;
aux_1699 = CDR(x_23);
return CAR(aux_1699);
}
}


/* _identifier-name */obj_t _identifier_name_183___r5_syntax_syntaxenv(obj_t env_1365, obj_t x_1366)
{
return identifier_name_131___r5_syntax_syntaxenv(x_1366);
}


/* same-denotation? */obj_t same_denotation__10___r5_syntax_syntaxenv(obj_t d1_24, obj_t d2_25)
{
{
bool_t _ortest_1009_965;
_ortest_1009_965 = (d1_24==d2_25);
if(_ortest_1009_965){
return BBOOL(_ortest_1009_965);
}
 else {
bool_t _andtest_1010_966;
{
obj_t arg1109_973;
arg1109_973 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, d1_24, BEOA);
_andtest_1010_966 = (arg1109_973==symbol1390___r5_syntax_syntaxenv);
}
if(_andtest_1010_966){
bool_t _andtest_1011_967;
{
obj_t arg1109_978;
arg1109_978 = PROCEDURE_ENTRY(denotation_class_62___r5_syntax_syntaxenv)(denotation_class_62___r5_syntax_syntaxenv, d2_25, BEOA);
_andtest_1011_967 = (arg1109_978==symbol1390___r5_syntax_syntaxenv);
}
if(_andtest_1011_967){
bool_t aux_1714;
{
obj_t aux_1719;
obj_t aux_1715;
{
obj_t aux_1720;
aux_1720 = CDR(d2_25);
aux_1719 = CAR(aux_1720);
}
{
obj_t aux_1716;
aux_1716 = CDR(d1_24);
aux_1715 = CAR(aux_1716);
}
aux_1714 = (aux_1715==aux_1719);
}
return BBOOL(aux_1714);
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}


/* _same-denotation? */obj_t _same_denotation__131___r5_syntax_syntaxenv(obj_t env_1367, obj_t d1_1368, obj_t d2_1369)
{
return same_denotation__10___r5_syntax_syntaxenv(d1_1368, d2_1369);
}


/* m-strip */obj_t m_strip_59___r5_syntax_syntaxenv(obj_t x_26)
{
if(SYMBOLP(x_26)){
{
obj_t chars_429;
{
obj_t arg1121_433;
{
obj_t arg1122_434;
{
obj_t arg1123_435;
arg1123_435 = SYMBOL_TO_STRING(x_26);
arg1122_434 = string__list_125___r4_strings_6_7(arg1123_435);
}
arg1121_433 = reverse___r4_pairs_and_lists_6_3(arg1122_434);
}
chars_429 = memv___r4_pairs_and_lists_6_3(suffix_character_4___r5_syntax_prefs, arg1121_433);
}
if(CBOOL(chars_429)){
obj_t arg1118_430;
arg1118_430 = list__string_78___r4_strings_6_7(reverse___r4_pairs_and_lists_6_3(CDR(chars_429)));
{
char * aux_1737;
aux_1737 = BSTRING_TO_STRING(arg1118_430);
return string_to_symbol(aux_1737);
}
}
 else {
return x_26;
}
}
}
 else {
if(PAIRP(x_26)){
{
obj_t arg1125_437;
obj_t arg1126_438;
arg1125_437 = m_strip_59___r5_syntax_syntaxenv(CAR(x_26));
arg1126_438 = m_strip_59___r5_syntax_syntaxenv(CDR(x_26));
return MAKE_PAIR(arg1125_437, arg1126_438);
}
}
 else {
if(VECTORP(x_26)){
{
obj_t arg1130_442;
{
obj_t l1012_443;
l1012_443 = vector__list_155___r4_vectors_6_8(x_26);
if(NULLP(l1012_443)){
arg1130_442 = BNIL;
}
 else {
obj_t head1014_445;
{
obj_t arg1139_456;
arg1139_456 = m_strip_59___r5_syntax_syntaxenv(CAR(l1012_443));
head1014_445 = MAKE_PAIR(arg1139_456, BNIL);
}
{
obj_t l1012_1010;
obj_t tail1015_1011;
l1012_1010 = CDR(l1012_443);
tail1015_1011 = head1014_445;
lname1013_1009:
if(NULLP(l1012_1010)){
arg1130_442 = head1014_445;
}
 else {
obj_t newtail1016_1019;
{
obj_t arg1135_1020;
arg1135_1020 = m_strip_59___r5_syntax_syntaxenv(CAR(l1012_1010));
newtail1016_1019 = MAKE_PAIR(arg1135_1020, BNIL);
}
SET_CDR(tail1015_1011, newtail1016_1019);
{
obj_t tail1015_1763;
obj_t l1012_1761;
l1012_1761 = CDR(l1012_1010);
tail1015_1763 = newtail1016_1019;
tail1015_1011 = tail1015_1763;
l1012_1010 = l1012_1761;
goto lname1013_1009;
}
}
}
}
}
return list__vector_101___r4_vectors_6_8(arg1130_442);
}
}
 else {
return x_26;
}
}
}
}


/* _m-strip */obj_t _m_strip_111___r5_syntax_syntaxenv(obj_t env_1370, obj_t x_1371)
{
return m_strip_59___r5_syntax_syntaxenv(x_1371);
}


/* rename-vars */obj_t rename_vars_186___r5_syntax_syntaxenv(obj_t vars_27)
{
renaming_counter_100___r5_syntax_syntaxenv = _2__168___r4_numbers_6_5(renaming_counter_100___r5_syntax_syntaxenv, BINT(((long)1)));
{
obj_t suffix_459;
{
obj_t arg1154_478;
char * arg1155_479;
{
obj_t list1156_480;
list1156_480 = MAKE_PAIR(suffix_character_4___r5_syntax_prefs, BNIL);
arg1154_478 = list__string_78___r4_strings_6_7(list1156_480);
}
arg1155_479 = number__string_214___r4_numbers_6_5(renaming_counter_100___r5_syntax_syntaxenv, BNIL);
{
obj_t aux_1772;
aux_1772 = string_to_bstring(arg1155_479);
suffix_459 = string_append(arg1154_478, aux_1772);
}
}
if(NULLP(vars_27)){
return BNIL;
}
 else {
obj_t head1019_462;
head1019_462 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1017_463;
obj_t tail1020_464;
l1017_463 = vars_27;
tail1020_464 = head1019_462;
lname1018_465:
if(NULLP(l1017_463)){
return CDR(head1019_462);
}
 else {
obj_t newtail1021_467;
{
obj_t arg1145_469;
{
obj_t var_471;
var_471 = CAR(l1017_463);
if(SYMBOLP(var_471)){
obj_t arg1148_473;
{
obj_t arg1150_474;
{
obj_t arg1151_475;
arg1151_475 = SYMBOL_TO_STRING(var_471);
arg1150_474 = string_append(arg1151_475, suffix_459);
}
{
char * aux_1786;
aux_1786 = BSTRING_TO_STRING(arg1150_474);
arg1148_473 = string_to_symbol(aux_1786);
}
}
arg1145_469 = MAKE_PAIR(var_471, arg1148_473);
}
 else {
FAILURE(string1397___r5_syntax_syntaxenv,string1398___r5_syntax_syntaxenv,var_471);}
}
newtail1021_467 = MAKE_PAIR(arg1145_469, BNIL);
}
SET_CDR(tail1020_464, newtail1021_467);
{
obj_t tail1020_1795;
obj_t l1017_1793;
l1017_1793 = CDR(l1017_463);
tail1020_1795 = newtail1021_467;
tail1020_464 = tail1020_1795;
l1017_463 = l1017_1793;
goto lname1018_465;
}
}
}
}
}
}


/* _rename-vars */obj_t _rename_vars_101___r5_syntax_syntaxenv(obj_t env_1372, obj_t vars_1373)
{
return rename_vars_186___r5_syntax_syntaxenv(vars_1373);
}


/* syntactic-alias */obj_t syntactic_alias_206___r5_syntax_syntaxenv(obj_t env_28, obj_t alist_29, obj_t env2_30)
{
{
obj_t arg1160_483;
if(NULLP(alist_29)){
arg1160_483 = BNIL;
}
 else {
obj_t head1024_486;
head1024_486 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1022_487;
obj_t tail1025_488;
l1022_487 = alist_29;
tail1025_488 = head1024_486;
lname1023_489:
if(NULLP(l1022_487)){
arg1160_483 = CDR(head1024_486);
}
 else {
obj_t newtail1026_491;
{
obj_t arg1164_493;
{
obj_t name_pair_100_495;
name_pair_100_495 = CAR(l1022_487);
{
obj_t old_name_219_496;
obj_t new_name_162_497;
old_name_219_496 = CAR(name_pair_100_495);
new_name_162_497 = CDR(name_pair_100_495);
{
obj_t arg1166_498;
{
obj_t _ortest_1008_1089;
{
obj_t entry_1092;
entry_1092 = assq___r4_pairs_and_lists_6_3(old_name_219_496, env2_30);
if(CBOOL(entry_1092)){
_ortest_1008_1089 = CDR(entry_1092);
}
 else {
_ortest_1008_1089 = BFALSE;
}
}
if(CBOOL(_ortest_1008_1089)){
arg1166_498 = _ortest_1008_1089;
}
 else {
arg1166_498 = make_identifier_denotation_27___r5_syntax_syntaxenv(old_name_219_496);
}
}
arg1164_493 = MAKE_PAIR(new_name_162_497, arg1166_498);
}
}
}
newtail1026_491 = MAKE_PAIR(arg1164_493, BNIL);
}
SET_CDR(tail1025_488, newtail1026_491);
{
obj_t tail1025_1818;
obj_t l1022_1816;
l1022_1816 = CDR(l1022_487);
tail1025_1818 = newtail1026_491;
tail1025_488 = tail1025_1818;
l1022_487 = l1022_1816;
goto lname1023_489;
}
}
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1160_483, env_28);
}
}


/* _syntactic-alias */obj_t _syntactic_alias_145___r5_syntax_syntaxenv(obj_t env_1374, obj_t env_1375, obj_t alist_1376, obj_t env2_1377)
{
return syntactic_alias_206___r5_syntax_syntaxenv(env_1375, alist_1376, env2_1377);
}


/* syntactic-rename */obj_t syntactic_rename_48___r5_syntax_syntaxenv(obj_t env_31, obj_t alist_32)
{
{
obj_t arg1169_501;
{
obj_t ll1027_502;
obj_t ll1028_503;
if(NULLP(alist_32)){
ll1027_502 = BNIL;
}
 else {
obj_t head1035_523;
{
obj_t aux_1823;
{
obj_t aux_1824;
aux_1824 = CAR(alist_32);
aux_1823 = CAR(aux_1824);
}
head1035_523 = MAKE_PAIR(aux_1823, BNIL);
}
{
obj_t l1033_1110;
obj_t tail1036_1111;
l1033_1110 = CDR(alist_32);
tail1036_1111 = head1035_523;
lname1034_1109:
if(NULLP(l1033_1110)){
ll1027_502 = head1035_523;
}
 else {
obj_t newtail1037_1119;
{
obj_t aux_1830;
{
obj_t aux_1831;
aux_1831 = CAR(l1033_1110);
aux_1830 = CAR(aux_1831);
}
newtail1037_1119 = MAKE_PAIR(aux_1830, BNIL);
}
SET_CDR(tail1036_1111, newtail1037_1119);
{
obj_t tail1036_1838;
obj_t l1033_1836;
l1033_1836 = CDR(l1033_1110);
tail1036_1838 = newtail1037_1119;
tail1036_1111 = tail1036_1838;
l1033_1110 = l1033_1836;
goto lname1034_1109;
}
}
}
}
if(NULLP(alist_32)){
ll1028_503 = BNIL;
}
 else {
obj_t head1040_539;
{
obj_t aux_1842;
{
obj_t aux_1843;
aux_1843 = CAR(alist_32);
aux_1842 = CDR(aux_1843);
}
head1040_539 = MAKE_PAIR(aux_1842, BNIL);
}
{
obj_t l1038_1169;
obj_t tail1041_1170;
l1038_1169 = CDR(alist_32);
tail1041_1170 = head1040_539;
lname1039_1168:
if(NULLP(l1038_1169)){
ll1028_503 = head1040_539;
}
 else {
obj_t newtail1042_1178;
{
obj_t aux_1849;
{
obj_t aux_1850;
aux_1850 = CAR(l1038_1169);
aux_1849 = CDR(aux_1850);
}
newtail1042_1178 = MAKE_PAIR(aux_1849, BNIL);
}
SET_CDR(tail1041_1170, newtail1042_1178);
{
obj_t tail1041_1857;
obj_t l1038_1855;
l1038_1855 = CDR(l1038_1169);
tail1041_1857 = newtail1042_1178;
tail1041_1170 = tail1041_1857;
l1038_1169 = l1038_1855;
goto lname1039_1168;
}
}
}
}
if(NULLP(ll1027_502)){
arg1169_501 = BNIL;
}
 else {
obj_t head1029_505;
head1029_505 = MAKE_PAIR(BNIL, BNIL);
{
obj_t ll1027_1225;
obj_t ll1028_1226;
obj_t tail1030_1227;
ll1027_1225 = ll1027_502;
ll1028_1226 = ll1028_503;
tail1030_1227 = head1029_505;
lname1032_1224:
if(NULLP(ll1027_1225)){
arg1169_501 = CDR(head1029_505);
}
 else {
obj_t newtail1031_1238;
{
obj_t arg1174_1239;
{
obj_t old_1241;
old_1241 = CAR(ll1027_1225);
{
obj_t arg1176_1243;
arg1176_1243 = make_identifier_denotation_27___r5_syntax_syntaxenv(CAR(ll1028_1226));
arg1174_1239 = MAKE_PAIR(old_1241, arg1176_1243);
}
}
newtail1031_1238 = MAKE_PAIR(arg1174_1239, BNIL);
}
SET_CDR(tail1030_1227, newtail1031_1238);
{
obj_t tail1030_1875;
obj_t ll1028_1873;
obj_t ll1027_1871;
ll1027_1871 = CDR(ll1027_1225);
ll1028_1873 = CDR(ll1028_1226);
tail1030_1875 = newtail1031_1238;
tail1030_1227 = tail1030_1875;
ll1028_1226 = ll1028_1873;
ll1027_1225 = ll1027_1871;
goto lname1032_1224;
}
}
}
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1169_501, env_31);
}
}


/* _syntactic-rename */obj_t _syntactic_rename_43___r5_syntax_syntaxenv(obj_t env_1378, obj_t env_1379, obj_t alist_1380)
{
return syntactic_rename_48___r5_syntax_syntaxenv(env_1379, alist_1380);
}


/* rename-formals */obj_t rename_formals_228___r5_syntax_syntaxenv(obj_t formals_33, obj_t alist_34)
{
if(NULLP(formals_33)){
return BNIL;
}
 else {
if(PAIRP(formals_33)){
{
obj_t arg1202_555;
obj_t arg1203_556;
{
obj_t aux_1882;
aux_1882 = assq___r4_pairs_and_lists_6_3(CAR(formals_33), alist_34);
arg1202_555 = CDR(aux_1882);
}
arg1203_556 = rename_formals_228___r5_syntax_syntaxenv(CDR(formals_33), alist_34);
return MAKE_PAIR(arg1202_555, arg1203_556);
}
}
 else {
{
obj_t aux_1889;
aux_1889 = assq___r4_pairs_and_lists_6_3(formals_33, alist_34);
return CDR(aux_1889);
}
}
}
}


/* _rename-formals */obj_t _rename_formals_208___r5_syntax_syntaxenv(obj_t env_1381, obj_t formals_1382, obj_t alist_1383)
{
return rename_formals_228___r5_syntax_syntaxenv(formals_1382, alist_1383);
}

