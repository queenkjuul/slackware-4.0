/*===========================================================================*/
/*   (Bdb/initialize.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_bdb_initialize();
extern obj_t create_struct(obj_t, long);
extern obj_t module_initialization_70_bdb_initialize(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_build(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_cnst_alloc(long, char *);
extern obj_t module_initialization_70_cnst_node(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t imported_modules_init_94_bdb_initialize();
static obj_t _initialize_ast_73_bdb_initialize(obj_t);
extern node_t coerce__182_coerce_coerce(node_t, type_t);
static obj_t library_modules_init_112_bdb_initialize();
static obj_t toplevel_init_63_bdb_initialize();
extern obj_t build_ast_197_ast_build(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t initialize_ast_128_bdb_initialize();
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_bdb_initialize = BUNSPEC;
static obj_t cnst_init_137_bdb_initialize();
static obj_t __cnst[5];

DEFINE_EXPORT_PROCEDURE(initialize_ast_env_80_bdb_initialize, _initialize_ast_73_bdb_initialize1609, _initialize_ast_73_bdb_initialize, 0L, 0);
DEFINE_STRING(string1603_bdb_initialize, string1603_bdb_initialize1610, "UNIT BDB PRAGMA::OBJ QUOTE BDB-SET-MODULE-INFO! ", 48);
DEFINE_STRING(string1602_bdb_initialize, string1602_bdb_initialize1611, "((obj_t)__bdb_info)", 19);


/* module-initialization */ obj_t 
module_initialization_70_bdb_initialize(long checksum_1191, char *from_1192)
{
   if (CBOOL(require_initialization_114_bdb_initialize))
     {
	require_initialization_114_bdb_initialize = BBOOL(((bool_t) 0));
	library_modules_init_112_bdb_initialize();
	cnst_init_137_bdb_initialize();
	imported_modules_init_94_bdb_initialize();
	method_init_76_bdb_initialize();
	toplevel_init_63_bdb_initialize();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_bdb_initialize()
{
   module_initialization_70___reader(((long) 0), "BDB_INITIALIZE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "BDB_INITIALIZE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_bdb_initialize()
{
   {
      obj_t cnst_port_138_1183;
      cnst_port_138_1183 = open_input_string(string1603_bdb_initialize);
      {
	 long i_1184;
	 i_1184 = ((long) 4);
       loop_1185:
	 {
	    bool_t test1604_1186;
	    test1604_1186 = (i_1184 == ((long) -1));
	    if (test1604_1186)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1605_1187;
		    {
		       obj_t list1606_1188;
		       {
			  obj_t arg1607_1189;
			  arg1607_1189 = BNIL;
			  list1606_1188 = MAKE_PAIR(cnst_port_138_1183, arg1607_1189);
		       }
		       arg1605_1187 = read___reader(list1606_1188);
		    }
		    CNST_TABLE_SET(i_1184, arg1605_1187);
		 }
		 {
		    int aux_1190;
		    {
		       long aux_1209;
		       aux_1209 = (i_1184 - ((long) 1));
		       aux_1190 = (int) (aux_1209);
		    }
		    {
		       long i_1212;
		       i_1212 = (long) (aux_1190);
		       i_1184 = i_1212;
		       goto loop_1185;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_bdb_initialize()
{
   return BUNSPEC;
}


/* initialize-ast */ obj_t 
initialize_ast_128_bdb_initialize()
{
   {
      obj_t body_738;
      {
	 obj_t arg1478_754;
	 {
	    obj_t arg1483_758;
	    obj_t arg1484_759;
	    obj_t arg1485_760;
	    arg1483_758 = CNST_TABLE_REF(((long) 0));
	    {
	       obj_t arg1491_766;
	       arg1491_766 = CNST_TABLE_REF(((long) 1));
	       {
		  obj_t list1495_768;
		  {
		     obj_t arg1496_769;
		     arg1496_769 = MAKE_PAIR(BNIL, BNIL);
		     list1495_768 = MAKE_PAIR(_module__166_module_module, arg1496_769);
		  }
		  arg1484_759 = cons__138___r4_pairs_and_lists_6_3(arg1491_766, list1495_768);
	       }
	    }
	    {
	       obj_t arg1498_771;
	       arg1498_771 = CNST_TABLE_REF(((long) 2));
	       {
		  obj_t list1501_774;
		  {
		     obj_t arg1502_775;
		     arg1502_775 = MAKE_PAIR(BNIL, BNIL);
		     list1501_774 = MAKE_PAIR(string1602_bdb_initialize, arg1502_775);
		  }
		  arg1485_760 = cons__138___r4_pairs_and_lists_6_3(arg1498_771, list1501_774);
	       }
	    }
	    {
	       obj_t list1487_762;
	       {
		  obj_t arg1488_763;
		  {
		     obj_t arg1489_764;
		     arg1489_764 = MAKE_PAIR(BNIL, BNIL);
		     arg1488_763 = MAKE_PAIR(arg1485_760, arg1489_764);
		  }
		  list1487_762 = MAKE_PAIR(arg1484_759, arg1488_763);
	       }
	       arg1478_754 = cons__138___r4_pairs_and_lists_6_3(arg1483_758, list1487_762);
	    }
	 }
	 {
	    obj_t list1480_756;
	    list1480_756 = MAKE_PAIR(BNIL, BNIL);
	    body_738 = cons__138___r4_pairs_and_lists_6_3(arg1478_754, list1480_756);
	 }
      }
      {
	 obj_t unit_739;
	 {
	    obj_t arg1476_752;
	    arg1476_752 = CNST_TABLE_REF(((long) 3));
	    {
	       obj_t new_1151;
	       {
		  obj_t aux_1230;
		  aux_1230 = CNST_TABLE_REF(((long) 4));
		  new_1151 = create_struct(aux_1230, ((long) 4));
	       }
	       STRUCT_SET(new_1151, ((long) 3), BTRUE);
	       STRUCT_SET(new_1151, ((long) 2), body_738);
	       {
		  obj_t aux_1235;
		  aux_1235 = BINT(((long) 9));
		  STRUCT_SET(new_1151, ((long) 1), aux_1235);
	       }
	       STRUCT_SET(new_1151, ((long) 0), arg1476_752);
	       unit_739 = new_1151;
	    }
	 }
	 {
	    obj_t ast_740;
	    {
	       obj_t arg1473_749;
	       {
		  obj_t list1474_750;
		  list1474_750 = MAKE_PAIR(unit_739, BNIL);
		  arg1473_749 = list1474_750;
	       }
	       ast_740 = build_ast_197_ast_build(arg1473_749);
	    }
	    {
	       obj_t l1443_741;
	       l1443_741 = ast_740;
	     lname1444_742:
	       if (PAIRP(l1443_741))
		 {
		    {
		       obj_t global_744;
		       global_744 = CAR(l1443_741);
		       {
			  type_t aux_1252;
			  node_t aux_1244;
			  {
			     global_t obj_1179;
			     obj_1179 = (global_t) (global_744);
			     aux_1252 = (((global_t) CREF(obj_1179))->type);
			  }
			  {
			     obj_t aux_1245;
			     {
				sfun_t obj_1178;
				{
				   value_t aux_1246;
				   {
				      global_t obj_1177;
				      obj_1177 = (global_t) (global_744);
				      aux_1246 = (((global_t) CREF(obj_1177))->value);
				   }
				   obj_1178 = (sfun_t) (aux_1246);
				}
				aux_1245 = (((sfun_t) CREF(obj_1178))->body);
			     }
			     aux_1244 = (node_t) (aux_1245);
			  }
			  coerce__182_coerce_coerce(aux_1244, aux_1252);
		       }
		    }
		    {
		       obj_t l1443_1256;
		       l1443_1256 = CDR(l1443_741);
		       l1443_741 = l1443_1256;
		       goto lname1444_742;
		    }
		 }
	       else
		 {
		    ((bool_t) 1);
		 }
	    }
	    return ast_740;
	 }
      }
   }
}


/* _initialize-ast */ obj_t 
_initialize_ast_73_bdb_initialize(obj_t env_1181)
{
   return initialize_ast_128_bdb_initialize();
}


/* method-init */ obj_t 
method_init_76_bdb_initialize()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_bdb_initialize()
{
   module_initialization_70_tools_trace(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_tools_shape(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_tools_speek(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_tools_error(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_engine_param(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_module_module(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_type_type(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_type_cache(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_ast_var(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_ast_node(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_ast_env(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_ast_build(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_ast_lvtype(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_ast_glo_def_117(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_coerce_coerce(((long) 0), "BDB_INITIALIZE");
   module_initialization_70_cnst_alloc(((long) 0), "BDB_INITIALIZE");
   return module_initialization_70_cnst_node(((long) 0), "BDB_INITIALIZE");
}
