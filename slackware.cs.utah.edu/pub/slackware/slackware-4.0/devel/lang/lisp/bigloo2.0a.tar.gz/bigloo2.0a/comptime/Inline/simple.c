/*===========================================================================*/
/*   (Inline/simple.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;


extern obj_t _inlining_reduce_kfactor__26_engine_param;
static obj_t method_init_76_inline_simple();
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern local_t clone_local_230_ast_local(local_t, value_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t current_function_76_tools_error();
extern obj_t module_initialization_70_inline_simple(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_size(long, char *);
extern obj_t module_initialization_70_ast_alphatize(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_effect_spread(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern bool_t spread_side_effect__136_effect_spread(node_t);
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
static obj_t _inline_app_simple_231_inline_simple(obj_t, obj_t, obj_t, obj_t, obj_t);
extern node_t inline_app_simple_198_inline_simple(node_t, long, obj_t, obj_t);
static obj_t imported_modules_init_94_inline_simple();
static obj_t library_modules_init_112_inline_simple();
extern node_t inline_node_218_inline_inline(node_t, long, obj_t);
extern obj_t open_input_string(obj_t);
extern node_t alphatize_ast_alphatize(obj_t, obj_t, obj_t, node_t);
extern bool_t side_effect__165_effect_effect(node_t);
extern obj_t isfun_inline_inline;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_inline_simple = BUNSPEC;
static obj_t cnst_init_137_inline_simple();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(inline_app_simple_env_207_inline_simple, _inline_app_simple_231_inline_simple1681, _inline_app_simple_231_inline_simple, 0L, 4);
DEFINE_STRING(string1675_inline_simple, string1675_inline_simple1682, "RES (SIFUN SGFUN) READ ", 23);
DEFINE_STRING(string1674_inline_simple, string1674_inline_simple1683, "         ", 9);
DEFINE_STRING(string1673_inline_simple, string1673_inline_simple1684, " --> ", 5);
DEFINE_STRING(string1672_inline_simple, string1672_inline_simple1685, " (", 2);


/* module-initialization */ obj_t 
module_initialization_70_inline_simple(long checksum_1382, char *from_1383)
{
   if (CBOOL(require_initialization_114_inline_simple))
     {
	require_initialization_114_inline_simple = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_simple();
	cnst_init_137_inline_simple();
	imported_modules_init_94_inline_simple();
	method_init_76_inline_simple();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_simple()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "INLINE_SIMPLE");
   module_initialization_70___object(((long) 0), "INLINE_SIMPLE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_SIMPLE");
   module_initialization_70___reader(((long) 0), "INLINE_SIMPLE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_simple()
{
   {
      obj_t cnst_port_138_1374;
      cnst_port_138_1374 = open_input_string(string1675_inline_simple);
      {
	 long i_1375;
	 i_1375 = ((long) 2);
       loop_1376:
	 {
	    bool_t test1676_1377;
	    test1676_1377 = (i_1375 == ((long) -1));
	    if (test1676_1377)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1677_1378;
		    {
		       obj_t list1678_1379;
		       {
			  obj_t arg1679_1380;
			  arg1679_1380 = BNIL;
			  list1678_1379 = MAKE_PAIR(cnst_port_138_1374, arg1679_1380);
		       }
		       arg1677_1378 = read___reader(list1678_1379);
		    }
		    CNST_TABLE_SET(i_1375, arg1677_1378);
		 }
		 {
		    int aux_1381;
		    {
		       long aux_1401;
		       aux_1401 = (i_1375 - ((long) 1));
		       aux_1381 = (int) (aux_1401);
		    }
		    {
		       long i_1404;
		       i_1404 = (long) (aux_1381);
		       i_1375 = i_1404;
		       goto loop_1376;
		    }
		 }
	      }
	 }
      }
   }
}


/* inline-app-simple */ node_t 
inline_app_simple_198_inline_simple(node_t node_1, long kfactor_2, obj_t stack_3, obj_t msg_4)
{
   {
      variable_t callee_751;
      {
	 var_t arg1565_865;
	 {
	    app_t obj_1200;
	    obj_1200 = (app_t) (node_1);
	    arg1565_865 = (((app_t) CREF(obj_1200))->fun);
	 }
	 callee_751 = (((var_t) CREF(arg1565_865))->variable);
      }
      {
	 value_t sfun_752;
	 sfun_752 = (((variable_t) CREF(callee_751))->value);
	 {
	    obj_t formals_753;
	    {
	       sfun_t obj_1203;
	       obj_1203 = (sfun_t) (sfun_752);
	       formals_753 = (((sfun_t) CREF(obj_1203))->args);
	    }
	    {
	       obj_t actuals_754;
	       {
		  app_t obj_1204;
		  obj_1204 = (app_t) (node_1);
		  actuals_754 = (((app_t) CREF(obj_1204))->args);
	       }
	       {
		  obj_t reductors_755;
		  if (NULLP(formals_753))
		    {
		       reductors_755 = BNIL;
		    }
		  else
		    {
		       obj_t head1457_842;
		       head1457_842 = MAKE_PAIR(BNIL, BNIL);
		       {
			  obj_t ll1455_843;
			  obj_t ll1456_844;
			  obj_t tail1458_845;
			  ll1455_843 = formals_753;
			  ll1456_844 = actuals_754;
			  tail1458_845 = head1457_842;
			lname1460_846:
			  if (NULLP(ll1455_843))
			    {
			       reductors_755 = CDR(head1457_842);
			    }
			  else
			    {
			       obj_t newtail1459_848;
			       {
				  obj_t arg1555_851;
				  {
				     obj_t f_853;
				     obj_t a_854;
				     f_853 = CAR(ll1455_843);
				     a_854 = CAR(ll1456_844);
				     {
					bool_t test1557_855;
					{
					   bool_t test1560_860;
					   test1560_860 = is_a__118___object(a_854, closure_ast_node);
					   if (test1560_860)
					     {
						obj_t aux_1427;
						obj_t aux_1424;
						aux_1427 = CNST_TABLE_REF(((long) 0));
						{
						   local_t obj_1213;
						   obj_1213 = (local_t) (f_853);
						   aux_1424 = (((local_t) CREF(obj_1213))->access);
						}
						test1557_855 = (aux_1424 == aux_1427);
					     }
					   else
					     {
						test1557_855 = ((bool_t) 0);
					     }
					}
					if (test1557_855)
					  {
					     closure_t obj_1216;
					     obj_1216 = (closure_t) (a_854);
					     {
						variable_t aux_1432;
						aux_1432 = (((closure_t) CREF(obj_1216))->variable);
						arg1555_851 = (obj_t) (aux_1432);
					     }
					  }
					else
					  {
					     svar_t arg1558_856;
					     {
						svar_t duplicated1461_857;
						{
						   local_t obj_1217;
						   obj_1217 = (local_t) (f_853);
						   {
						      value_t aux_1436;
						      aux_1436 = (((local_t) CREF(obj_1217))->value);
						      duplicated1461_857 = (svar_t) (aux_1436);
						   }
						}
						{
						   svar_t new1462_858;
						   {
						      obj_t arg1559_859;
						      arg1559_859 = (((svar_t) CREF(duplicated1461_857))->loc);
						      {
							 svar_t res1668_1225;
							 {
							    svar_t new1159_1220;
							    new1159_1220 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
							    {
							       long arg1647_1221;
							       arg1647_1221 = class_num_218___object(svar_ast_var);
							       {
								  obj_t obj_1223;
								  obj_1223 = (obj_t) (new1159_1220);
								  (((obj_t) CREF(obj_1223))->header = MAKE_HEADER(arg1647_1221, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_1444;
							       aux_1444 = (object_t) (new1159_1220);
							       OBJECT_WIDENING_SET(aux_1444, BFALSE);
							    }
							    ((((svar_t) CREF(new1159_1220))->loc) = ((obj_t) arg1559_859), BUNSPEC);
							    res1668_1225 = new1159_1220;
							 }
							 new1462_858 = res1668_1225;
						      }
						   }
						   {
						      arg1558_856 = new1462_858;
						   }
						}
					     }
					     {
						local_t aux_1448;
						aux_1448 = clone_local_230_ast_local((local_t) (f_853), (value_t) (arg1558_856));
						arg1555_851 = (obj_t) (aux_1448);
					     }
					  }
				     }
				  }
				  newtail1459_848 = MAKE_PAIR(arg1555_851, BNIL);
			       }
			       SET_CDR(tail1458_845, newtail1459_848);
			       {
				  obj_t tail1458_1459;
				  obj_t ll1456_1457;
				  obj_t ll1455_1455;
				  ll1455_1455 = CDR(ll1455_843);
				  ll1456_1457 = CDR(ll1456_844);
				  tail1458_1459 = newtail1459_848;
				  tail1458_845 = tail1458_1459;
				  ll1456_844 = ll1456_1457;
				  ll1455_843 = ll1455_1455;
				  goto lname1460_846;
			       }
			    }
		       }
		    }
		  {
		     obj_t bindings_756;
		     {
			obj_t reductors_819;
			obj_t actuals_820;
			obj_t res_821;
			reductors_819 = reductors_755;
			actuals_820 = actuals_754;
			res_821 = BNIL;
		      loop_822:
			if (NULLP(actuals_820))
			  {
			     bindings_756 = reverse__39___r4_pairs_and_lists_6_3(res_821);
			  }
			else
			  {
			     bool_t test1532_825;
			     {
				bool_t test1543_834;
				test1543_834 = is_a__118___object(CAR(actuals_820), closure_ast_node);
				if (test1543_834)
				  {
				     obj_t aux_1468;
				     obj_t aux_1466;
				     {
					variable_t aux_1469;
					{
					   closure_t obj_1237;
					   {
					      obj_t aux_1470;
					      aux_1470 = CAR(actuals_820);
					      obj_1237 = (closure_t) (aux_1470);
					   }
					   aux_1469 = (((closure_t) CREF(obj_1237))->variable);
					}
					aux_1468 = (obj_t) (aux_1469);
				     }
				     aux_1466 = CAR(reductors_819);
				     test1532_825 = (aux_1466 == aux_1468);
				  }
				else
				  {
				     test1532_825 = ((bool_t) 0);
				  }
			     }
			     if (test1532_825)
			       {
				  {
				     obj_t actuals_1479;
				     obj_t reductors_1477;
				     reductors_1477 = CDR(reductors_819);
				     actuals_1479 = CDR(actuals_820);
				     actuals_820 = actuals_1479;
				     reductors_819 = reductors_1477;
				     goto loop_822;
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1535_828;
				     obj_t arg1536_829;
				     obj_t arg1537_830;
				     arg1535_828 = CDR(reductors_819);
				     arg1536_829 = CDR(actuals_820);
				     {
					obj_t arg1539_831;
					{
					   obj_t aux_1485;
					   obj_t aux_1483;
					   aux_1485 = CAR(actuals_820);
					   aux_1483 = CAR(reductors_819);
					   arg1539_831 = MAKE_PAIR(aux_1483, aux_1485);
					}
					arg1537_830 = MAKE_PAIR(arg1539_831, res_821);
				     }
				     {
					obj_t res_1491;
					obj_t actuals_1490;
					obj_t reductors_1489;
					reductors_1489 = arg1535_828;
					actuals_1490 = arg1536_829;
					res_1491 = arg1537_830;
					res_821 = res_1491;
					actuals_820 = actuals_1490;
					reductors_819 = reductors_1489;
					goto loop_822;
				     }
				  }
			       }
			  }
		     }
		     {
			obj_t body_757;
			{
			   bool_t test1529_818;
			   test1529_818 = is_a__118___object((obj_t) (sfun_752), isfun_inline_inline);
			   if (test1529_818)
			     {
				isfun_t obj_1251;
				obj_1251 = (isfun_t) (sfun_752);
				{
				   node_t aux_1496;
				   {
				      obj_t aux_1497;
				      {
					 object_t aux_1498;
					 aux_1498 = (object_t) (obj_1251);
					 aux_1497 = OBJECT_WIDENING(aux_1498);
				      }
				      aux_1496 = (((isfun_t) CREF(aux_1497))->original_body_40);
				   }
				   body_757 = (obj_t) (aux_1496);
				}
			     }
			   else
			     {
				sfun_t obj_1252;
				obj_1252 = (sfun_t) (sfun_752);
				body_757 = (((sfun_t) CREF(obj_1252))->body);
			     }
			}
			{
			   obj_t new_kfactor_216_759;
			   new_kfactor_216_759 = PROCEDURE_ENTRY(_inlining_reduce_kfactor__26_engine_param) (_inlining_reduce_kfactor__26_engine_param, BINT(kfactor_2), BEOA);
			   {
			      obj_t loc_760;
			      loc_760 = (((node_t) CREF(node_1))->loc);
			      {
				 type_t type_761;
				 type_761 = (((node_t) CREF(node_1))->type);
				 {
				    {
				       bool_t test_1510;
				       {
					  obj_t aux_1511;
					  {
					     obj_t aux_1512;
					     {
						sfun_t obj_1256;
						obj_1256 = (sfun_t) (sfun_752);
						aux_1512 = (((sfun_t) CREF(obj_1256))->class);
					     }
					     aux_1511 = memq___r4_pairs_and_lists_6_3(aux_1512, CNST_TABLE_REF(((long) 1)));
					  }
					  test_1510 = CBOOL(aux_1511);
				       }
				       if (test_1510)
					 {
					    BUNSPEC;
					 }
				       else
					 {
					    obj_t arg1473_765;
					    obj_t arg1475_767;
					    arg1473_765 = shape_tools_shape((obj_t) (callee_751));
					    arg1475_767 = current_function_76_tools_error();
					    {
					       obj_t list1477_769;
					       {
						  obj_t arg1478_770;
						  {
						     obj_t arg1479_771;
						     {
							obj_t arg1480_772;
							{
							   obj_t arg1481_773;
							   {
							      obj_t arg1483_774;
							      {
								 obj_t arg1484_775;
								 {
								    obj_t arg1485_776;
								    {
								       obj_t aux_1521;
								       aux_1521 = BCHAR(((unsigned char) '\n'));
								       arg1485_776 = MAKE_PAIR(aux_1521, BNIL);
								    }
								    {
								       obj_t aux_1524;
								       aux_1524 = BCHAR(((unsigned char) ')'));
								       arg1484_775 = MAKE_PAIR(aux_1524, arg1485_776);
								    }
								 }
								 arg1483_774 = MAKE_PAIR(msg_4, arg1484_775);
							      }
							      arg1481_773 = MAKE_PAIR(string1672_inline_simple, arg1483_774);
							   }
							   arg1480_772 = MAKE_PAIR(arg1475_767, arg1481_773);
							}
							arg1479_771 = MAKE_PAIR(string1673_inline_simple, arg1480_772);
						     }
						     arg1478_770 = MAKE_PAIR(arg1473_765, arg1479_771);
						  }
						  list1477_769 = MAKE_PAIR(string1674_inline_simple, arg1478_770);
					       }
					       verbose_tools_speek(BINT(((long) 3)), list1477_769);
					    }
					 }
				    }
				    {
				       node_t alpha_body_133_780;
				       alpha_body_133_780 = alphatize_ast_alphatize(formals_753, reductors_755, loc_760, (node_t) (body_757));
				       spread_side_effect__136_effect_spread(alpha_body_133_780);
				       {
					  let_var_6_t inline_body_50_781;
					  {
					     bool_t arg1524_813;
					     node_t arg1527_816;
					     arg1524_813 = side_effect__165_effect_effect(alpha_body_133_780);
					     {
						obj_t arg1528_817;
						{
						   obj_t aux_1539;
						   aux_1539 = (obj_t) (callee_751);
						   arg1528_817 = MAKE_PAIR(aux_1539, stack_3);
						}
						arg1527_816 = inline_node_218_inline_inline(alpha_body_133_780, (long) CINT(new_kfactor_216_759), arg1528_817);
					     }
					     {
						let_var_6_t res1669_1277;
						{
						   obj_t side_effect__165_1261;
						   obj_t key_1262;
						   side_effect__165_1261 = BBOOL(arg1524_813);
						   key_1262 = BINT(((long) -1));
						   {
						      let_var_6_t new1366_1266;
						      new1366_1266 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
						      {
							 long arg1586_1267;
							 arg1586_1267 = class_num_218___object(let_var_6_ast_node);
							 {
							    obj_t obj_1275;
							    obj_1275 = (obj_t) (new1366_1266);
							    (((obj_t) CREF(obj_1275))->header = MAKE_HEADER(arg1586_1267, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_1550;
							 aux_1550 = (object_t) (new1366_1266);
							 OBJECT_WIDENING_SET(aux_1550, BFALSE);
						      }
						      ((((let_var_6_t) CREF(new1366_1266))->loc) = ((obj_t) loc_760), BUNSPEC);
						      ((((let_var_6_t) CREF(new1366_1266))->type) = ((type_t) type_761), BUNSPEC);
						      ((((let_var_6_t) CREF(new1366_1266))->side_effect__165) = ((obj_t) side_effect__165_1261), BUNSPEC);
						      ((((let_var_6_t) CREF(new1366_1266))->key) = ((obj_t) key_1262), BUNSPEC);
						      ((((let_var_6_t) CREF(new1366_1266))->bindings) = ((obj_t) bindings_756), BUNSPEC);
						      ((((let_var_6_t) CREF(new1366_1266))->body) = ((node_t) arg1527_816), BUNSPEC);
						      ((((let_var_6_t) CREF(new1366_1266))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
						      res1669_1277 = new1366_1266;
						   }
						}
						inline_body_50_781 = res1669_1277;
					     }
					  }
					  {
					     obj_t ll1464_782;
					     obj_t ll1465_783;
					     ll1464_782 = bindings_756;
					     ll1465_783 = formals_753;
					   lname1466_784:
					     if (NULLP(ll1464_782))
					       {
						  ((bool_t) 1);
					       }
					     else
					       {
						  {
						     bool_t arg1491_789;
						     {
							local_t obj_1282;
							{
							   obj_t aux_1562;
							   aux_1562 = CAR(ll1465_783);
							   obj_1282 = (local_t) (aux_1562);
							}
							arg1491_789 = (((local_t) CREF(obj_1282))->user__32);
						     }
						     {
							local_t obj_1283;
							{
							   obj_t aux_1566;
							   {
							      obj_t aux_1567;
							      aux_1567 = CAR(ll1464_782);
							      aux_1566 = CAR(aux_1567);
							   }
							   obj_1283 = (local_t) (aux_1566);
							}
							((((local_t) CREF(obj_1283))->user__32) = ((bool_t) arg1491_789), BUNSPEC);
						     }
						  }
						  {
						     obj_t ll1465_1574;
						     obj_t ll1464_1572;
						     ll1464_1572 = CDR(ll1464_782);
						     ll1465_1574 = CDR(ll1465_783);
						     ll1465_783 = ll1465_1574;
						     ll1464_782 = ll1464_1572;
						     goto lname1466_784;
						  }
					       }
					  }
					  {
					     bool_t test1497_792;
					     {
						bool_t test1516_808;
						{
						   obj_t obj2_1288;
						   obj2_1288 = ____74_type_cache;
						   {
						      obj_t aux_1576;
						      aux_1576 = (obj_t) (type_761);
						      test1516_808 = (aux_1576 == obj2_1288);
						   }
						}
						if (test1516_808)
						  {
						     test1497_792 = ((bool_t) 1);
						  }
						else
						  {
						     bool_t test1517_809;
						     {
							obj_t obj2_1290;
							obj2_1290 = _obj__252_type_cache;
							{
							   obj_t aux_1580;
							   aux_1580 = (obj_t) (type_761);
							   test1517_809 = (aux_1580 == obj2_1290);
							}
						     }
						     if (test1517_809)
						       {
							  test1497_792 = ((bool_t) 1);
						       }
						     else
						       {
							  obj_t aux_1586;
							  obj_t aux_1584;
							  {
							     type_t aux_1587;
							     aux_1587 = (((node_t) CREF(alpha_body_133_780))->type);
							     aux_1586 = (obj_t) (aux_1587);
							  }
							  aux_1584 = (obj_t) (type_761);
							  test1497_792 = (aux_1584 == aux_1586);
						       }
						  }
					     }
					     if (test1497_792)
					       {
						  return (node_t) (inline_body_50_781);
					       }
					     else
					       {
						  local_t var_793;
						  {
						     obj_t arg1514_806;
						     arg1514_806 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
						     var_793 = make_local_svar_140_ast_local(arg1514_806, type_761);
						  }
						  {
						     bool_t arg1500_796;
						     obj_t arg1502_798;
						     var_t arg1503_799;
						     arg1500_796 = side_effect__165_effect_effect((node_t) (inline_body_50_781));
						     {
							obj_t arg1504_800;
							{
							   obj_t aux_1601;
							   obj_t aux_1599;
							   aux_1601 = (obj_t) (inline_body_50_781);
							   aux_1599 = (obj_t) (var_793);
							   arg1504_800 = MAKE_PAIR(aux_1599, aux_1601);
							}
							{
							   obj_t list1505_801;
							   list1505_801 = MAKE_PAIR(arg1504_800, BNIL);
							   arg1502_798 = list1505_801;
							}
						     }
						     {
							var_t res1670_1307;
							{
							   variable_t variable_1299;
							   variable_1299 = (variable_t) (var_793);
							   {
							      var_t new1207_1300;
							      new1207_1300 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							      {
								 long arg1625_1301;
								 arg1625_1301 = class_num_218___object(var_ast_node);
								 {
								    obj_t obj_1305;
								    obj_1305 = (obj_t) (new1207_1300);
								    (((obj_t) CREF(obj_1305))->header = MAKE_HEADER(arg1625_1301, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_1610;
								 aux_1610 = (object_t) (new1207_1300);
								 OBJECT_WIDENING_SET(aux_1610, BFALSE);
							      }
							      ((((var_t) CREF(new1207_1300))->loc) = ((obj_t) loc_760), BUNSPEC);
							      ((((var_t) CREF(new1207_1300))->type) = ((type_t) type_761), BUNSPEC);
							      ((((var_t) CREF(new1207_1300))->variable) = ((variable_t) variable_1299), BUNSPEC);
							      res1670_1307 = new1207_1300;
							   }
							}
							arg1503_799 = res1670_1307;
						     }
						     {
							let_var_6_t res1671_1326;
							{
							   obj_t side_effect__165_1310;
							   obj_t key_1311;
							   node_t body_1313;
							   side_effect__165_1310 = BBOOL(arg1500_796);
							   key_1311 = BINT(((long) -1));
							   body_1313 = (node_t) (arg1503_799);
							   {
							      let_var_6_t new1366_1315;
							      new1366_1315 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
							      {
								 long arg1586_1316;
								 arg1586_1316 = class_num_218___object(let_var_6_ast_node);
								 {
								    obj_t obj_1324;
								    obj_1324 = (obj_t) (new1366_1315);
								    (((obj_t) CREF(obj_1324))->header = MAKE_HEADER(arg1586_1316, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_1623;
								 aux_1623 = (object_t) (new1366_1315);
								 OBJECT_WIDENING_SET(aux_1623, BFALSE);
							      }
							      ((((let_var_6_t) CREF(new1366_1315))->loc) = ((obj_t) loc_760), BUNSPEC);
							      ((((let_var_6_t) CREF(new1366_1315))->type) = ((type_t) type_761), BUNSPEC);
							      ((((let_var_6_t) CREF(new1366_1315))->side_effect__165) = ((obj_t) side_effect__165_1310), BUNSPEC);
							      ((((let_var_6_t) CREF(new1366_1315))->key) = ((obj_t) key_1311), BUNSPEC);
							      ((((let_var_6_t) CREF(new1366_1315))->bindings) = ((obj_t) arg1502_798), BUNSPEC);
							      ((((let_var_6_t) CREF(new1366_1315))->body) = ((node_t) body_1313), BUNSPEC);
							      ((((let_var_6_t) CREF(new1366_1315))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
							      res1671_1326 = new1366_1315;
							   }
							}
							return (node_t) (res1671_1326);
						     }
						  }
					       }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _inline-app-simple */ obj_t 
_inline_app_simple_231_inline_simple(obj_t env_1369, obj_t node_1370, obj_t kfactor_1371, obj_t stack_1372, obj_t msg_1373)
{
   {
      node_t aux_1634;
      aux_1634 = inline_app_simple_198_inline_simple((node_t) (node_1370), (long) CINT(kfactor_1371), stack_1372, msg_1373);
      return (obj_t) (aux_1634);
   }
}


/* method-init */ obj_t 
method_init_76_inline_simple()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_simple()
{
   module_initialization_70_tools_trace(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_engine_param(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_type_type(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_type_cache(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_ast_var(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_ast_node(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_ast_local(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_tools_shape(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_tools_speek(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_tools_error(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_inline_inline(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_inline_size(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_ast_alphatize(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_ast_sexp(((long) 0), "INLINE_SIMPLE");
   module_initialization_70_effect_effect(((long) 0), "INLINE_SIMPLE");
   return module_initialization_70_effect_spread(((long) 0), "INLINE_SIMPLE");
}
