/*===========================================================================*/
/*   (Bdb/spread-obj.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t _bdb_spread_obj__220_bdb_spread_obj_171(obj_t, obj_t);
static obj_t method_init_76_bdb_spread_obj_171();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t current_error_port;
extern obj_t fail_ast_node;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t box_ref_242_ast_node;
extern obj_t leave_function_170_tools_error();
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
static node_t spread_obj_node__default1455_132_bdb_spread_obj_171(node_t);
static obj_t spread_obj_node___181_bdb_spread_obj_171(obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t spread_obj_fun__116_bdb_spread_obj_171(obj_t);
extern obj_t module_initialization_70_bdb_spread_obj_171(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _spread_obj_node__default1455_242_bdb_spread_obj_171(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_bdb_spread_obj_171();
extern obj_t app_ly_162_ast_node;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _spread_obj_node_1696_87_bdb_spread_obj_171(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_bdb_spread_obj_171();
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_bdb_spread_obj_171();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t string_to_bstring(char *);
static obj_t spread_obj_node__80_bdb_spread_obj_171(node_t);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t bdb_spread_obj__133_bdb_spread_obj_171(obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_bdb_spread_obj_171 = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_bdb_spread_obj_171();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[2];

DEFINE_STATIC_GENERIC(spread_obj_node__env_134_bdb_spread_obj_171, _spread_obj_node_1696_87_bdb_spread_obj_1711709, _spread_obj_node_1696_87_bdb_spread_obj_171, 0L, 1);
DEFINE_STATIC_PROCEDURE(spread_obj_node__default1455_env_104_bdb_spread_obj_171, _spread_obj_node__default1455_242_bdb_spread_obj_1711710, _spread_obj_node__default1455_242_bdb_spread_obj_171, 0L, 1);
DEFINE_STRING(string1699_bdb_spread_obj_171, string1699_bdb_spread_obj_1711711, "failure during prelude hook", 27);
DEFINE_STRING(string1698_bdb_spread_obj_171, string1698_bdb_spread_obj_1711712, "   . ", 5);
DEFINE_STRING(string1697_bdb_spread_obj_171, string1697_bdb_spread_obj_1711713, "Bdb (obj spreading)", 19);
DEFINE_STRING(string1703_bdb_spread_obj_171, string1703_bdb_spread_obj_1711714, "DONE PASS-STARTED ", 18);
DEFINE_STRING(string1702_bdb_spread_obj_171, string1702_bdb_spread_obj_1711715, "failure during postlude hook", 28);
DEFINE_STRING(string1701_bdb_spread_obj_171, string1701_bdb_spread_obj_1711716, " error", 6);
DEFINE_STRING(string1700_bdb_spread_obj_171, string1700_bdb_spread_obj_1711717, " occured, ending ...", 20);
DEFINE_EXPORT_PROCEDURE(bdb_spread_obj__env_248_bdb_spread_obj_171, _bdb_spread_obj__220_bdb_spread_obj_1711718, _bdb_spread_obj__220_bdb_spread_obj_171, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_bdb_spread_obj_171(long checksum_1332, char *from_1333)
{
   if (CBOOL(require_initialization_114_bdb_spread_obj_171))
     {
	require_initialization_114_bdb_spread_obj_171 = BBOOL(((bool_t) 0));
	library_modules_init_112_bdb_spread_obj_171();
	cnst_init_137_bdb_spread_obj_171();
	imported_modules_init_94_bdb_spread_obj_171();
	method_init_76_bdb_spread_obj_171();
	toplevel_init_63_bdb_spread_obj_171();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_bdb_spread_obj_171()
{
   module_initialization_70___object(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70___r4_output_6_10_3(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70___r4_numbers_6_5(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70___reader(((long) 0), "BDB_SPREAD-OBJ");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_bdb_spread_obj_171()
{
   {
      obj_t cnst_port_138_1324;
      cnst_port_138_1324 = open_input_string(string1703_bdb_spread_obj_171);
      {
	 long i_1325;
	 i_1325 = ((long) 1);
       loop_1326:
	 {
	    bool_t test1704_1327;
	    test1704_1327 = (i_1325 == ((long) -1));
	    if (test1704_1327)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1705_1328;
		    {
		       obj_t list1706_1329;
		       {
			  obj_t arg1707_1330;
			  arg1707_1330 = BNIL;
			  list1706_1329 = MAKE_PAIR(cnst_port_138_1324, arg1707_1330);
		       }
		       arg1705_1328 = read___reader(list1706_1329);
		    }
		    CNST_TABLE_SET(i_1325, arg1705_1328);
		 }
		 {
		    int aux_1331;
		    {
		       long aux_1352;
		       aux_1352 = (i_1325 - ((long) 1));
		       aux_1331 = (int) (aux_1352);
		    }
		    {
		       long i_1355;
		       i_1355 = (long) (aux_1331);
		       i_1325 = i_1355;
		       goto loop_1326;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_bdb_spread_obj_171()
{
   return BUNSPEC;
}


/* bdb-spread-obj! */ obj_t 
bdb_spread_obj__133_bdb_spread_obj_171(obj_t globals_1)
{
   {
      obj_t list1475_714;
      {
	 obj_t arg1477_716;
	 {
	    obj_t arg1479_718;
	    {
	       obj_t aux_1357;
	       aux_1357 = BCHAR(((unsigned char) '\n'));
	       arg1479_718 = MAKE_PAIR(aux_1357, BNIL);
	    }
	    arg1477_716 = MAKE_PAIR(string1697_bdb_spread_obj_171, arg1479_718);
	 }
	 list1475_714 = MAKE_PAIR(string1698_bdb_spread_obj_171, arg1477_716);
      }
      verbose_tools_speek(BINT(((long) 1)), list1475_714);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1697_bdb_spread_obj_171;
   {
      obj_t hooks_720;
      obj_t hnames_721;
      hooks_720 = BNIL;
      hnames_721 = BNIL;
    loop_722:
      if (NULLP(hooks_720))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1486_727;
	   {
	      obj_t fun1492_733;
	      fun1492_733 = CAR(hooks_720);
	      {
		 obj_t aux_1369;
		 aux_1369 = PROCEDURE_ENTRY(fun1492_733) (fun1492_733, BEOA);
		 test1486_727 = CBOOL(aux_1369);
	      }
	   }
	   if (test1486_727)
	     {
		{
		   obj_t hnames_1376;
		   obj_t hooks_1374;
		   hooks_1374 = CDR(hooks_720);
		   hnames_1376 = CDR(hnames_721);
		   hnames_721 = hnames_1376;
		   hooks_720 = hooks_1374;
		   goto loop_722;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1697_bdb_spread_obj_171, string1699_bdb_spread_obj_171, CAR(hnames_721));
	     }
	}
   }
   {
      obj_t l1435_734;
      l1435_734 = globals_1;
    lname1436_735:
      if (PAIRP(l1435_734))
	{
	   spread_obj_fun__116_bdb_spread_obj_171(CAR(l1435_734));
	   {
	      obj_t l1435_1384;
	      l1435_1384 = CDR(l1435_734);
	      l1435_734 = l1435_1384;
	      goto lname1436_735;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      bool_t test1497_740;
      {
	 long n1_1211;
	 n1_1211 = (long) CINT(_nb_error_on_pass__70_tools_error);
	 test1497_740 = (n1_1211 > ((long) 0));
      }
      if (test1497_740)
	{
	   {
	      char *arg1500_743;
	      {
		 bool_t test1508_750;
		 {
		    bool_t test1509_751;
		    {
		       obj_t obj_1213;
		       obj_1213 = _nb_error_on_pass__70_tools_error;
		       test1509_751 = INTEGERP(obj_1213);
		    }
		    if (test1509_751)
		      {
			 test1508_750 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
		      }
		    else
		      {
			 test1508_750 = ((bool_t) 0);
		      }
		 }
		 if (test1508_750)
		   {
		      arg1500_743 = "s";
		   }
		 else
		   {
		      arg1500_743 = "";
		   }
	      }
	      {
		 obj_t list1502_745;
		 {
		    obj_t arg1503_746;
		    {
		       obj_t arg1504_747;
		       {
			  obj_t arg1505_748;
			  arg1505_748 = MAKE_PAIR(string1700_bdb_spread_obj_171, BNIL);
			  {
			     obj_t aux_1395;
			     aux_1395 = string_to_bstring(arg1500_743);
			     arg1504_747 = MAKE_PAIR(aux_1395, arg1505_748);
			  }
		       }
		       arg1503_746 = MAKE_PAIR(string1701_bdb_spread_obj_171, arg1504_747);
		    }
		    list1502_745 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1503_746);
		 }
		 fprint___r4_output_6_10_3(current_error_port, list1502_745);
	      }
	   }
	   {
	      obj_t res1694_1215;
	      exit(((long) -1));
	      res1694_1215 = BINT(((long) -1));
	      return res1694_1215;
	   }
	}
      else
	{
	   obj_t hooks_752;
	   obj_t hnames_753;
	   hooks_752 = BNIL;
	   hnames_753 = BNIL;
	 loop_754:
	   if (NULLP(hooks_752))
	     {
		return globals_1;
	     }
	   else
	     {
		bool_t test1514_759;
		{
		   obj_t fun1519_764;
		   fun1519_764 = CAR(hooks_752);
		   {
		      obj_t aux_1406;
		      aux_1406 = PROCEDURE_ENTRY(fun1519_764) (fun1519_764, BEOA);
		      test1514_759 = CBOOL(aux_1406);
		   }
		}
		if (test1514_759)
		  {
		     {
			obj_t hnames_1413;
			obj_t hooks_1411;
			hooks_1411 = CDR(hooks_752);
			hnames_1413 = CDR(hnames_753);
			hnames_753 = hnames_1413;
			hooks_752 = hooks_1411;
			goto loop_754;
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1702_bdb_spread_obj_171, CAR(hnames_753));
		  }
	     }
	}
   }
}


/* _bdb-spread-obj! */ obj_t 
_bdb_spread_obj__220_bdb_spread_obj_171(obj_t env_1318, obj_t globals_1319)
{
   return bdb_spread_obj__133_bdb_spread_obj_171(globals_1319);
}


/* spread-obj-fun! */ obj_t 
spread_obj_fun__116_bdb_spread_obj_171(obj_t var_2)
{
   {
      obj_t aux_1418;
      {
	 variable_t obj_1222;
	 obj_1222 = (variable_t) (var_2);
	 aux_1418 = (((variable_t) CREF(obj_1222))->id);
      }
      enter_function_81_tools_error(aux_1418);
   }
   {
      value_t fun_766;
      {
	 variable_t obj_1223;
	 obj_1223 = (variable_t) (var_2);
	 fun_766 = (((variable_t) CREF(obj_1223))->value);
      }
      {
	 obj_t body_767;
	 {
	    sfun_t obj_1224;
	    obj_1224 = (sfun_t) (fun_766);
	    body_767 = (((sfun_t) CREF(obj_1224))->body);
	 }
	 {
	    obj_t args_769;
	    {
	       sfun_t obj_1226;
	       obj_1226 = (sfun_t) (fun_766);
	       args_769 = (((sfun_t) CREF(obj_1226))->args);
	    }
	    {
	       {
		  bool_t test1523_770;
		  {
		     obj_t obj2_1228;
		     obj2_1228 = ____74_type_cache;
		     {
			obj_t aux_1428;
			{
			   type_t aux_1429;
			   {
			      variable_t obj_1225;
			      obj_1225 = (variable_t) (var_2);
			      aux_1429 = (((variable_t) CREF(obj_1225))->type);
			   }
			   aux_1428 = (obj_t) (aux_1429);
			}
			test1523_770 = (aux_1428 == obj2_1228);
		     }
		  }
		  if (test1523_770)
		    {
		       variable_t obj_1229;
		       type_t val1042_1230;
		       obj_1229 = (variable_t) (var_2);
		       val1042_1230 = (type_t) (_obj__252_type_cache);
		       ((((variable_t) CREF(obj_1229))->type) = ((type_t) val1042_1230), BUNSPEC);
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       {
		  obj_t l1437_771;
		  l1437_771 = args_769;
		lname1438_772:
		  if (PAIRP(l1437_771))
		    {
		       {
			  obj_t args_774;
			  args_774 = CAR(l1437_771);
			  {
			     bool_t test1525_775;
			     {
				obj_t obj2_1235;
				obj2_1235 = ____74_type_cache;
				{
				   obj_t aux_1441;
				   {
				      type_t aux_1442;
				      {
					 variable_t obj_1233;
					 obj_1233 = (variable_t) (args_774);
					 aux_1442 = (((variable_t) CREF(obj_1233))->type);
				      }
				      aux_1441 = (obj_t) (aux_1442);
				   }
				   test1525_775 = (aux_1441 == obj2_1235);
				}
			     }
			     if (test1525_775)
			       {
				  variable_t obj_1236;
				  type_t val1042_1237;
				  obj_1236 = (variable_t) (args_774);
				  val1042_1237 = (type_t) (_obj__252_type_cache);
				  ((((variable_t) CREF(obj_1236))->type) = ((type_t) val1042_1237), BUNSPEC);
			       }
			     else
			       {
				  BUNSPEC;
			       }
			  }
		       }
		       {
			  obj_t l1437_1451;
			  l1437_1451 = CDR(l1437_771);
			  l1437_771 = l1437_1451;
			  goto lname1438_772;
		       }
		    }
		  else
		    {
		       ((bool_t) 1);
		    }
	       }
	       {
		  bool_t test1528_778;
		  {
		     long n1_1239;
		     n1_1239 = (long) CINT(_bdb_debug__1_engine_param);
		     test1528_778 = (n1_1239 >= ((long) 2));
		  }
		  if (test1528_778)
		    {
		       spread_obj_node__80_bdb_spread_obj_171((node_t) (body_767));
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       return leave_function_170_tools_error();
	    }
	 }
      }
   }
}


/* spread-obj-node*! */ obj_t 
spread_obj_node___181_bdb_spread_obj_171(obj_t node__221_22)
{
 spread_obj_node___181_bdb_spread_obj_171:
   if (NULLP(node__221_22))
     {
	return CNST_TABLE_REF(((long) 1));
     }
   else
     {
	{
	   node_t aux_1462;
	   {
	      obj_t aux_1463;
	      aux_1463 = CAR(node__221_22);
	      aux_1462 = (node_t) (aux_1463);
	   }
	   spread_obj_node__80_bdb_spread_obj_171(aux_1462);
	}
	{
	   obj_t node__221_1467;
	   node__221_1467 = CDR(node__221_22);
	   node__221_22 = node__221_1467;
	   goto spread_obj_node___181_bdb_spread_obj_171;
	}
     }
}


/* method-init */ obj_t 
method_init_76_bdb_spread_obj_171()
{
   add_generic__110___object(spread_obj_node__env_134_bdb_spread_obj_171, spread_obj_node__default1455_env_104_bdb_spread_obj_171);
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, sequence_ast_node, ((long) 0));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, app_ast_node, ((long) 1));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, app_ly_162_ast_node, ((long) 2));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, funcall_ast_node, ((long) 3));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, pragma_ast_node, ((long) 4));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, cast_ast_node, ((long) 5));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, setq_ast_node, ((long) 6));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, conditional_ast_node, ((long) 7));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, fail_ast_node, ((long) 8));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, select_ast_node, ((long) 9));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, let_fun_218_ast_node, ((long) 10));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, let_var_6_ast_node, ((long) 11));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, set_ex_it_116_ast_node, ((long) 12));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, jump_ex_it_184_ast_node, ((long) 13));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, make_box_202_ast_node, ((long) 14));
   add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, box_ref_242_ast_node, ((long) 15));
   {
      long aux_1486;
      aux_1486 = add_inlined_method__244___object(spread_obj_node__env_134_bdb_spread_obj_171, box_set__221_ast_node, ((long) 16));
      return BINT(aux_1486);
   }
}


/* spread-obj-node! */ obj_t 
spread_obj_node__80_bdb_spread_obj_171(node_t node_3)
{
 spread_obj_node__80_bdb_spread_obj_171:
   {
      obj_t method1627_1111;
      obj_t class1632_1112;
      {
	 obj_t arg1636_1109;
	 obj_t arg1638_1110;
	 {
	    object_t obj_1244;
	    obj_1244 = (object_t) (node_3);
	    {
	       obj_t pre_method_105_1245;
	       pre_method_105_1245 = PROCEDURE_REF(spread_obj_node__env_134_bdb_spread_obj_171, ((long) 2));
	       if (INTEGERP(pre_method_105_1245))
		 {
		    PROCEDURE_SET(spread_obj_node__env_134_bdb_spread_obj_171, ((long) 2), BUNSPEC);
		    arg1636_1109 = pre_method_105_1245;
		 }
	       else
		 {
		    long obj_class_num_177_1250;
		    obj_class_num_177_1250 = TYPE(obj_1244);
		    {
		       obj_t arg1177_1251;
		       arg1177_1251 = PROCEDURE_REF(spread_obj_node__env_134_bdb_spread_obj_171, ((long) 1));
		       {
			  long arg1178_1255;
			  {
			     long arg1179_1256;
			     arg1179_1256 = OBJECT_TYPE;
			     arg1178_1255 = (obj_class_num_177_1250 - arg1179_1256);
			  }
			  arg1636_1109 = VECTOR_REF(arg1177_1251, arg1178_1255);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1261;
	    object_1261 = (object_t) (node_3);
	    {
	       long arg1180_1262;
	       {
		  long arg1181_1263;
		  long arg1182_1264;
		  arg1181_1263 = TYPE(object_1261);
		  arg1182_1264 = OBJECT_TYPE;
		  arg1180_1262 = (arg1181_1263 - arg1182_1264);
	       }
	       {
		  obj_t vector_1268;
		  vector_1268 = _classes__134___object;
		  arg1638_1110 = VECTOR_REF(vector_1268, arg1180_1262);
	       }
	    }
	 }
	 method1627_1111 = arg1636_1109;
	 class1632_1112 = arg1638_1110;
	 {
	    if (INTEGERP(method1627_1111))
	      {
		 switch ((long) CINT(method1627_1111))
		   {
		   case ((long) 0):
		      {
			 sequence_t node_1118;
			 node_1118 = (sequence_t) (node_3);
			 return spread_obj_node___181_bdb_spread_obj_171((((sequence_t) CREF(node_1118))->nodes));
		      }
		      break;
		   case ((long) 1):
		      {
			 app_t node_1120;
			 node_1120 = (app_t) (node_3);
			 return spread_obj_node___181_bdb_spread_obj_171((((app_t) CREF(node_1120))->args));
		      }
		      break;
		   case ((long) 2):
		      {
			 app_ly_162_t node_1122;
			 node_1122 = (app_ly_162_t) (node_3);
			 spread_obj_node__80_bdb_spread_obj_171((((app_ly_162_t) CREF(node_1122))->fun));
			 {
			    node_t node_1515;
			    node_1515 = (((app_ly_162_t) CREF(node_1122))->arg);
			    node_3 = node_1515;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 funcall_t node_1126;
			 node_1126 = (funcall_t) (node_3);
			 spread_obj_node__80_bdb_spread_obj_171((((funcall_t) CREF(node_1126))->fun));
			 return spread_obj_node___181_bdb_spread_obj_171((((funcall_t) CREF(node_1126))->args));
		      }
		      break;
		   case ((long) 4):
		      {
			 pragma_t node_1130;
			 node_1130 = (pragma_t) (node_3);
			 return spread_obj_node___181_bdb_spread_obj_171((((pragma_t) CREF(node_1130))->args));
		      }
		      break;
		   case ((long) 5):
		      {
			 cast_t node_1132;
			 node_1132 = (cast_t) (node_3);
			 {
			    node_t node_1526;
			    node_1526 = (((cast_t) CREF(node_1132))->arg);
			    node_3 = node_1526;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 setq_t node_1134;
			 node_1134 = (setq_t) (node_3);
			 {
			    node_t node_1529;
			    node_1529 = (((setq_t) CREF(node_1134))->value);
			    node_3 = node_1529;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 conditional_t node_1136;
			 node_1136 = (conditional_t) (node_3);
			 spread_obj_node__80_bdb_spread_obj_171((((conditional_t) CREF(node_1136))->test));
			 spread_obj_node__80_bdb_spread_obj_171((((conditional_t) CREF(node_1136))->true));
			 {
			    node_t node_1536;
			    node_1536 = (((conditional_t) CREF(node_1136))->false);
			    node_3 = node_1536;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 fail_t node_1141;
			 node_1141 = (fail_t) (node_3);
			 spread_obj_node__80_bdb_spread_obj_171((((fail_t) CREF(node_1141))->proc));
			 spread_obj_node__80_bdb_spread_obj_171((((fail_t) CREF(node_1141))->msg));
			 {
			    node_t node_1543;
			    node_1543 = (((fail_t) CREF(node_1141))->obj);
			    node_3 = node_1543;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 select_t node_1146;
			 node_1146 = (select_t) (node_3);
			 spread_obj_node__80_bdb_spread_obj_171((((select_t) CREF(node_1146))->test));
			 {
			    obj_t l1444_1149;
			    {
			       bool_t aux_1548;
			       l1444_1149 = (((select_t) CREF(node_1146))->clauses);
			     lname1445_1150:
			       if (PAIRP(l1444_1149))
				 {
				    {
				       node_t aux_1551;
				       {
					  obj_t aux_1552;
					  {
					     obj_t aux_1553;
					     aux_1553 = CAR(l1444_1149);
					     aux_1552 = CDR(aux_1553);
					  }
					  aux_1551 = (node_t) (aux_1552);
				       }
				       spread_obj_node__80_bdb_spread_obj_171(aux_1551);
				    }
				    {
				       obj_t l1444_1558;
				       l1444_1558 = CDR(l1444_1149);
				       l1444_1149 = l1444_1558;
				       goto lname1445_1150;
				    }
				 }
			       else
				 {
				    aux_1548 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1548);
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 let_fun_218_t node_1156;
			 node_1156 = (let_fun_218_t) (node_3);
			 {
			    obj_t l1447_1158;
			    l1447_1158 = (((let_fun_218_t) CREF(node_1156))->locals);
			  lname1448_1159:
			    if (PAIRP(l1447_1158))
			      {
				 spread_obj_fun__116_bdb_spread_obj_171(CAR(l1447_1158));
				 {
				    obj_t l1447_1567;
				    l1447_1567 = CDR(l1447_1158);
				    l1447_1158 = l1447_1567;
				    goto lname1448_1159;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1570;
			    node_1570 = (((let_fun_218_t) CREF(node_1156))->body);
			    node_3 = node_1570;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 let_var_6_t node_1165;
			 node_1165 = (let_var_6_t) (node_3);
			 {
			    obj_t l1450_1167;
			    l1450_1167 = (((let_var_6_t) CREF(node_1165))->bindings);
			  lname1451_1168:
			    if (PAIRP(l1450_1167))
			      {
				 {
				    obj_t binding_1171;
				    binding_1171 = CAR(l1450_1167);
				    {
				       obj_t variable_1172;
				       variable_1172 = CAR(binding_1171);
				       {
					  bool_t test1675_1173;
					  {
					     bool_t test1676_1174;
					     {
						obj_t obj2_1302;
						obj2_1302 = ____74_type_cache;
						{
						   obj_t aux_1577;
						   {
						      type_t aux_1578;
						      {
							 variable_t obj_1300;
							 obj_1300 = (variable_t) (variable_1172);
							 aux_1578 = (((variable_t) CREF(obj_1300))->type);
						      }
						      aux_1577 = (obj_t) (aux_1578);
						   }
						   test1676_1174 = (aux_1577 == obj2_1302);
						}
					     }
					     if (test1676_1174)
					       {
						  local_t obj_1303;
						  obj_1303 = (local_t) (variable_1172);
						  test1675_1173 = (((local_t) CREF(obj_1303))->user__32);
					       }
					     else
					       {
						  test1675_1173 = ((bool_t) 0);
					       }
					  }
					  if (test1675_1173)
					    {
					       variable_t obj_1304;
					       type_t val1042_1305;
					       obj_1304 = (variable_t) (variable_1172);
					       val1042_1305 = (type_t) (_obj__252_type_cache);
					       ((((variable_t) CREF(obj_1304))->type) = ((type_t) val1042_1305), BUNSPEC);
					    }
					  else
					    {
					       BUNSPEC;
					    }
				       }
				    }
				    {
				       node_t aux_1590;
				       {
					  obj_t aux_1591;
					  aux_1591 = CDR(binding_1171);
					  aux_1590 = (node_t) (aux_1591);
				       }
				       spread_obj_node__80_bdb_spread_obj_171(aux_1590);
				    }
				 }
				 {
				    obj_t l1450_1595;
				    l1450_1595 = CDR(l1450_1167);
				    l1450_1167 = l1450_1595;
				    goto lname1451_1168;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_1598;
			    node_1598 = (((let_var_6_t) CREF(node_1165))->body);
			    node_3 = node_1598;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 set_ex_it_116_t node_1179;
			 node_1179 = (set_ex_it_116_t) (node_3);
			 {
			    node_t node_1601;
			    node_1601 = (((set_ex_it_116_t) CREF(node_1179))->body);
			    node_3 = node_1601;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 jump_ex_it_184_t node_1181;
			 node_1181 = (jump_ex_it_184_t) (node_3);
			 spread_obj_node__80_bdb_spread_obj_171((((jump_ex_it_184_t) CREF(node_1181))->exit));
			 spread_obj_node__80_bdb_spread_obj_171((((jump_ex_it_184_t) CREF(node_1181))->value));
			 return (obj_t) (node_1181);
		      }
		      break;
		   case ((long) 14):
		      {
			 make_box_202_t node_1185;
			 node_1185 = (make_box_202_t) (node_3);
			 {
			    node_t node_1610;
			    node_1610 = (((make_box_202_t) CREF(node_1185))->value);
			    node_3 = node_1610;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 box_ref_242_t node_1187;
			 node_1187 = (box_ref_242_t) (node_3);
			 {
			    node_t node_1613;
			    {
			       var_t aux_1614;
			       aux_1614 = (((box_ref_242_t) CREF(node_1187))->var);
			       node_1613 = (node_t) (aux_1614);
			    }
			    node_3 = node_1613;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 box_set__221_t node_1189;
			 node_1189 = (box_set__221_t) (node_3);
			 {
			    node_t aux_1618;
			    {
			       var_t aux_1619;
			       aux_1619 = (((box_set__221_t) CREF(node_1189))->var);
			       aux_1618 = (node_t) (aux_1619);
			    }
			    spread_obj_node__80_bdb_spread_obj_171(aux_1618);
			 }
			 {
			    node_t node_1623;
			    node_1623 = (((box_set__221_t) CREF(node_1189))->value);
			    node_3 = node_1623;
			    goto spread_obj_node__80_bdb_spread_obj_171;
			 }
		      }
		      break;
		   default:
		    case_else1633_1115:
		      if (PROCEDUREP(method1627_1111))
			{
			   return PROCEDURE_ENTRY(method1627_1111) (method1627_1111, (obj_t) (node_3), BEOA);
			}
		      else
			{
			   obj_t fun1626_1107;
			   fun1626_1107 = PROCEDURE_REF(spread_obj_node__env_134_bdb_spread_obj_171, ((long) 0));
			   return PROCEDURE_ENTRY(fun1626_1107) (fun1626_1107, (obj_t) (node_3), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1633_1115;
	      }
	 }
      }
   }
}


/* _spread-obj-node!1696 */ obj_t 
_spread_obj_node_1696_87_bdb_spread_obj_171(obj_t env_1320, obj_t node_1321)
{
   return spread_obj_node__80_bdb_spread_obj_171((node_t) (node_1321));
}


/* spread-obj-node!-default1455 */ node_t 
spread_obj_node__default1455_132_bdb_spread_obj_171(node_t node_4)
{
   return node_4;
}


/* _spread-obj-node!-default1455 */ obj_t 
_spread_obj_node__default1455_242_bdb_spread_obj_171(obj_t env_1322, obj_t node_1323)
{
   {
      node_t aux_1638;
      aux_1638 = spread_obj_node__default1455_132_bdb_spread_obj_171((node_t) (node_1323));
      return (obj_t) (aux_1638);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_bdb_spread_obj_171()
{
   module_initialization_70_tools_speek(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_tools_error(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_engine_pass(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_type_type(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_ast_var(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_ast_node(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_tools_shape(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_tools_misc(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_type_env(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_type_cache(((long) 0), "BDB_SPREAD-OBJ");
   module_initialization_70_ast_sexp(((long) 0), "BDB_SPREAD-OBJ");
   return module_initialization_70_engine_param(((long) 0), "BDB_SPREAD-OBJ");
}
