/*===========================================================================*/
/*   (Foreign/cptr.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_foreign_cpointer();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_foreign_cpointer(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _make_ctype_accesses_1781_225_foreign_access(obj_t, obj_t, obj_t);
extern obj_t cptr_foreign_ctype;
static obj_t imported_modules_init_94_foreign_cpointer();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t cstruct_foreign_ctype;
extern obj_t produce_module_clause__172_module_module(obj_t);
static obj_t library_modules_init_112_foreign_cpointer();
static obj_t toplevel_init_63_foreign_cpointer();
extern obj_t open_input_string(obj_t);
static obj_t make_ctype_accesses__cptr_115_foreign_cpointer(obj_t, obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t calias_foreign_ctype;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_foreign_cpointer = BUNSPEC;
static obj_t cnst_init_137_foreign_cpointer();
static obj_t __cnst[33];

DEFINE_STATIC_PROCEDURE(proc1782_foreign_cpointer, make_ctype_accesses__cptr_115_foreign_cpointer1807, make_ctype_accesses__cptr_115_foreign_cpointer, 0L, 2);
DEFINE_STRING(string1799_foreign_cpointer, string1799_foreign_cpointer1808, ")FOREIGN_TO_COBJ", 16);
DEFINE_STRING(string1798_foreign_cpointer, string1798_foreign_cpointer1809, "($1 == $2)", 10);
DEFINE_STRING(string1797_foreign_cpointer, string1797_foreign_cpointer1810, "($1 == (", 8);
extern obj_t make_ctype_accesses__env_11_foreign_access;
DEFINE_STRING(string1796_foreign_cpointer, string1796_foreign_cpointer1811, ")0L)", 4);
DEFINE_STRING(string1795_foreign_cpointer, string1795_foreign_cpointer1812, " )", 2);
DEFINE_STRING(string1794_foreign_cpointer, string1794_foreign_cpointer1813, " * $1 )", 7);
DEFINE_STRING(string1793_foreign_cpointer, string1793_foreign_cpointer1814, "(", 1);
DEFINE_STRING(string1792_foreign_cpointer, string1792_foreign_cpointer1815, ")GC_MALLOC( ", 12);
DEFINE_STRING(string1791_foreign_cpointer, string1791_foreign_cpointer1816, "sizeof( ", 8);
DEFINE_STRING(string1801_foreign_cpointer, string1801_foreign_cpointer1817, "PREDICATE-OF INLINE STATIC FOREIGN SYMBOL MACRO QUOTE FOREIGN-ID EQ? FOREIGN? IF O::OBJ O2 O1 = PRAGMA::BOOL -NULL?::BOOL LEN LEN::LONG MAKE- V ::OBJ I PRAGMA I::LONG O DEFINE-INLINE * -SET! -REF ::BOOL ? -> ", 208);
DEFINE_STRING(string1789_foreign_cpointer, string1789_foreign_cpointer1818, ")($1))[ $2 ] = $3, BUNSPEC)", 27);
DEFINE_STRING(string1790_foreign_cpointer, string1790_foreign_cpointer1819, " ))", 3);
DEFINE_STRING(string1800_foreign_cpointer, string1800_foreign_cpointer1820, "cobj_to_foreign", 15);
DEFINE_STRING(string1788_foreign_cpointer, string1788_foreign_cpointer1821, "(((", 3);
DEFINE_STRING(string1787_foreign_cpointer, string1787_foreign_cpointer1822, ")($1))[ $2 ] = *($3), BUNSPEC)", 30);
DEFINE_STRING(string1786_foreign_cpointer, string1786_foreign_cpointer1823, "((", 2);
DEFINE_STRING(string1785_foreign_cpointer, string1785_foreign_cpointer1824, ")($1))[ $2 ]", 12);
DEFINE_STRING(string1784_foreign_cpointer, string1784_foreign_cpointer1825, "&(((", 4);
DEFINE_STRING(string1783_foreign_cpointer, string1783_foreign_cpointer1826, ")($1))[ $2 ])", 13);


/* module-initialization */ obj_t 
module_initialization_70_foreign_cpointer(long checksum_1041, char *from_1042)
{
   if (CBOOL(require_initialization_114_foreign_cpointer))
     {
	require_initialization_114_foreign_cpointer = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_cpointer();
	cnst_init_137_foreign_cpointer();
	imported_modules_init_94_foreign_cpointer();
	method_init_76_foreign_cpointer();
	toplevel_init_63_foreign_cpointer();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_cpointer()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70___object(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70___r4_strings_6_7(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70___reader(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "FOREIGN_CPOINTER");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_foreign_cpointer()
{
   {
      obj_t cnst_port_138_1033;
      cnst_port_138_1033 = open_input_string(string1801_foreign_cpointer);
      {
	 long i_1034;
	 i_1034 = ((long) 32);
       loop_1035:
	 {
	    bool_t test1802_1036;
	    test1802_1036 = (i_1034 == ((long) -1));
	    if (test1802_1036)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1803_1037;
		    {
		       obj_t list1804_1038;
		       {
			  obj_t arg1805_1039;
			  arg1805_1039 = BNIL;
			  list1804_1038 = MAKE_PAIR(cnst_port_138_1033, arg1805_1039);
		       }
		       arg1803_1037 = read___reader(list1804_1038);
		    }
		    CNST_TABLE_SET(i_1034, arg1803_1037);
		 }
		 {
		    int aux_1040;
		    {
		       long aux_1062;
		       aux_1062 = (i_1034 - ((long) 1));
		       aux_1040 = (int) (aux_1062);
		    }
		    {
		       long i_1065;
		       i_1065 = (long) (aux_1040);
		       i_1034 = i_1065;
		       goto loop_1035;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_foreign_cpointer()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_foreign_cpointer()
{
   {
      obj_t make_ctype_accesses__cptr_115_1026;
      make_ctype_accesses__cptr_115_1026 = proc1782_foreign_cpointer;
      return add_method__1___object(make_ctype_accesses__env_11_foreign_access, cptr_foreign_ctype, make_ctype_accesses__cptr_115_1026);
   }
}


/* make-ctype-accesses!-cptr */ obj_t 
make_ctype_accesses__cptr_115_foreign_cpointer(obj_t env_1027, obj_t what_1028, obj_t who_1029)
{
   {
      cptr_t what_474;
      type_t who_475;
      what_474 = (cptr_t) (what_1028);
      who_475 = (type_t) (who_1029);
      {
	 type_t btype_478;
	 {
	    obj_t aux_1068;
	    {
	       object_t aux_1069;
	       aux_1069 = (object_t) (what_474);
	       aux_1068 = OBJECT_WIDENING(aux_1069);
	    }
	    btype_478 = (((cptr_t) CREF(aux_1068))->btype);
	 }
	 {
	    obj_t id_479;
	    id_479 = (((type_t) CREF(who_475))->id);
	    {
	       obj_t wid_480;
	       {
		  type_t obj_1010;
		  obj_1010 = (type_t) (what_474);
		  wid_480 = (((type_t) CREF(obj_1010))->id);
	       }
	       {
		  obj_t bid_481;
		  bid_481 = (((type_t) CREF(btype_478))->id);
		  {
		     obj_t id__bid_132_482;
		     {
			obj_t arg1772_964;
			arg1772_964 = CNST_TABLE_REF(((long) 0));
			{
			   obj_t list1773_965;
			   {
			      obj_t arg1774_966;
			      {
				 obj_t arg1776_967;
				 arg1776_967 = MAKE_PAIR(bid_481, BNIL);
				 arg1774_966 = MAKE_PAIR(arg1772_964, arg1776_967);
			      }
			      list1773_965 = MAKE_PAIR(id_479, arg1774_966);
			   }
			   id__bid_132_482 = symbol_append_197___r4_symbols_6_4(list1773_965);
			}
		     }
		     {
			obj_t bid__id_105_483;
			{
			   obj_t arg1767_959;
			   arg1767_959 = CNST_TABLE_REF(((long) 0));
			   {
			      obj_t list1768_960;
			      {
				 obj_t arg1769_961;
				 {
				    obj_t arg1770_962;
				    arg1770_962 = MAKE_PAIR(id_479, BNIL);
				    arg1769_961 = MAKE_PAIR(arg1767_959, arg1770_962);
				 }
				 list1768_960 = MAKE_PAIR(bid_481, arg1769_961);
			      }
			      bid__id_105_483 = symbol_append_197___r4_symbols_6_4(list1768_960);
			   }
			}
			{
			   obj_t bid__101_484;
			   {
			      obj_t list1763_956;
			      {
				 obj_t arg1765_957;
				 {
				    obj_t aux_1087;
				    aux_1087 = CNST_TABLE_REF(((long) 1));
				    arg1765_957 = MAKE_PAIR(aux_1087, BNIL);
				 }
				 list1763_956 = MAKE_PAIR(id_479, arg1765_957);
			      }
			      bid__101_484 = symbol_append_197___r4_symbols_6_4(list1763_956);
			   }
			   {
			      obj_t bid__bool_159_485;
			      {
				 obj_t list1759_952;
				 {
				    obj_t arg1760_953;
				    {
				       obj_t aux_1092;
				       aux_1092 = CNST_TABLE_REF(((long) 2));
				       arg1760_953 = MAKE_PAIR(aux_1092, BNIL);
				    }
				    list1759_952 = MAKE_PAIR(bid__101_484, arg1760_953);
				 }
				 bid__bool_159_485 = symbol_append_197___r4_symbols_6_4(list1759_952);
			      }
			      {
				 obj_t name_sans___18_487;
				 name_sans___18_487 = string_sans___40_type_tools((((type_t) CREF(who_475))->name));
				 {
				    type_t point_to_164_488;
				    {
				       obj_t aux_1099;
				       {
					  object_t aux_1100;
					  aux_1100 = (object_t) (what_474);
					  aux_1099 = OBJECT_WIDENING(aux_1100);
				       }
				       point_to_164_488 = (((cptr_t) CREF(aux_1099))->point_to_164);
				    }
				    {
				       obj_t point_to_id_253_489;
				       point_to_id_253_489 = (((type_t) CREF(point_to_164_488))->id);
				       {
					  obj_t point_to_name_sans___111_491;
					  point_to_name_sans___111_491 = string_sans___40_type_tools((((type_t) CREF(point_to_164_488))->name));
					  {
					     {
						{
						   obj_t arg1206_499;
						   {
						      obj_t arg1207_500;
						      obj_t arg1209_501;
						      obj_t arg1210_502;
						      arg1207_500 = CNST_TABLE_REF(((long) 29));
						      {
							 obj_t arg1732_929;
							 obj_t arg1733_930;
							 arg1732_929 = CNST_TABLE_REF(((long) 27));
							 {
							    obj_t arg1748_939;
							    arg1748_939 = CNST_TABLE_REF(((long) 28));
							    {
							       obj_t list1750_941;
							       {
								  obj_t arg1753_942;
								  arg1753_942 = MAKE_PAIR(BNIL, BNIL);
								  list1750_941 = MAKE_PAIR(id_479, arg1753_942);
							       }
							       arg1733_930 = cons__138___r4_pairs_and_lists_6_3(arg1748_939, list1750_941);
							    }
							 }
							 {
							    obj_t list1740_933;
							    {
							       obj_t arg1743_934;
							       {
								  obj_t arg1744_935;
								  {
								     obj_t arg1745_936;
								     {
									obj_t arg1746_937;
									arg1746_937 = MAKE_PAIR(BNIL, BNIL);
									arg1745_936 = MAKE_PAIR(string1800_foreign_cpointer, arg1746_937);
								     }
								     arg1744_935 = MAKE_PAIR(arg1733_930, arg1745_936);
								  }
								  arg1743_934 = MAKE_PAIR(id__bid_132_482, arg1744_935);
							       }
							       list1740_933 = MAKE_PAIR(bid_481, arg1743_934);
							    }
							    arg1209_501 = cons__138___r4_pairs_and_lists_6_3(arg1732_929, list1740_933);
							 }
						      }
						      {
							 obj_t mname_909;
							 {
							    obj_t list1725_922;
							    {
							       obj_t arg1727_924;
							       {
								  obj_t arg1728_925;
								  arg1728_925 = MAKE_PAIR(string1799_foreign_cpointer, BNIL);
								  arg1727_924 = MAKE_PAIR(name_sans___18_487, arg1728_925);
							       }
							       list1725_922 = MAKE_PAIR(string1793_foreign_cpointer, arg1727_924);
							    }
							    mname_909 = string_append_106___r4_strings_6_7(list1725_922);
							 }
							 {
							    obj_t arg1711_910;
							    obj_t arg1712_911;
							    arg1711_910 = CNST_TABLE_REF(((long) 27));
							    {
							       obj_t list1723_920;
							       list1723_920 = MAKE_PAIR(BNIL, BNIL);
							       arg1712_911 = cons__138___r4_pairs_and_lists_6_3(bid_481, list1723_920);
							    }
							    {
							       obj_t list1714_913;
							       {
								  obj_t arg1716_914;
								  {
								     obj_t arg1717_915;
								     {
									obj_t arg1718_916;
									{
									   obj_t arg1720_917;
									   arg1720_917 = MAKE_PAIR(BNIL, BNIL);
									   arg1718_916 = MAKE_PAIR(mname_909, arg1720_917);
									}
									arg1717_915 = MAKE_PAIR(arg1712_911, arg1718_916);
								     }
								     arg1716_914 = MAKE_PAIR(bid__id_105_483, arg1717_915);
								  }
								  list1714_913 = MAKE_PAIR(id_479, arg1716_914);
							       }
							       arg1210_502 = cons__138___r4_pairs_and_lists_6_3(arg1711_910, list1714_913);
							    }
							 }
						      }
						      {
							 obj_t list1212_504;
							 {
							    obj_t arg1213_505;
							    {
							       obj_t arg1214_506;
							       arg1214_506 = MAKE_PAIR(BNIL, BNIL);
							       arg1213_505 = MAKE_PAIR(arg1210_502, arg1214_506);
							    }
							    list1212_504 = MAKE_PAIR(arg1209_501, arg1213_505);
							 }
							 arg1206_499 = cons__138___r4_pairs_and_lists_6_3(arg1207_500, list1212_504);
						      }
						   }
						   produce_module_clause__172_module_module(arg1206_499);
						}
						{
						   obj_t arg1219_508;
						   {
						      obj_t arg1220_509;
						      obj_t arg1221_510;
						      arg1220_509 = CNST_TABLE_REF(((long) 30));
						      {
							 obj_t arg1226_515;
							 obj_t arg1228_516;
							 arg1226_515 = CNST_TABLE_REF(((long) 31));
							 arg1228_516 = CNST_TABLE_REF(((long) 11));
							 {
							    obj_t list1232_518;
							    {
							       obj_t arg1233_519;
							       {
								  obj_t arg1234_520;
								  arg1234_520 = MAKE_PAIR(BNIL, BNIL);
								  arg1233_519 = MAKE_PAIR(arg1228_516, arg1234_520);
							       }
							       list1232_518 = MAKE_PAIR(bid__bool_159_485, arg1233_519);
							    }
							    arg1221_510 = cons__138___r4_pairs_and_lists_6_3(arg1226_515, list1232_518);
							 }
						      }
						      {
							 obj_t list1223_512;
							 {
							    obj_t arg1224_513;
							    arg1224_513 = MAKE_PAIR(BNIL, BNIL);
							    list1223_512 = MAKE_PAIR(arg1221_510, arg1224_513);
							 }
							 arg1219_508 = cons__138___r4_pairs_and_lists_6_3(arg1220_509, list1223_512);
						      }
						   }
						   produce_module_clause__172_module_module(arg1219_508);
						}
						{
						   obj_t arg1236_522;
						   {
						      obj_t arg1238_523;
						      obj_t arg1240_524;
						      arg1238_523 = CNST_TABLE_REF(((long) 9));
						      {
							 obj_t arg1245_529;
							 {
							    obj_t arg1252_534;
							    arg1252_534 = CNST_TABLE_REF(((long) 32));
							    {
							       obj_t list1254_536;
							       {
								  obj_t arg1255_537;
								  arg1255_537 = MAKE_PAIR(BNIL, BNIL);
								  list1254_536 = MAKE_PAIR(wid_480, arg1255_537);
							       }
							       arg1245_529 = cons__138___r4_pairs_and_lists_6_3(arg1252_534, list1254_536);
							    }
							 }
							 {
							    obj_t list1248_531;
							    {
							       obj_t arg1250_532;
							       arg1250_532 = MAKE_PAIR(BNIL, BNIL);
							       list1248_531 = MAKE_PAIR(arg1245_529, arg1250_532);
							    }
							    arg1240_524 = cons__138___r4_pairs_and_lists_6_3(bid__101_484, list1248_531);
							 }
						      }
						      {
							 obj_t list1242_526;
							 {
							    obj_t arg1243_527;
							    arg1243_527 = MAKE_PAIR(BNIL, BNIL);
							    list1242_526 = MAKE_PAIR(arg1240_524, arg1243_527);
							 }
							 arg1236_522 = cons__138___r4_pairs_and_lists_6_3(arg1238_523, list1242_526);
						      }
						   }
						   produce_module_clause__172_module_module(arg1236_522);
						}
						{
						   obj_t arg1257_539;
						   obj_t arg1258_540;
						   obj_t arg1259_541;
						   obj_t arg1260_542;
						   obj_t arg1262_543;
						   {
						      {
							 bool_t test1439_684;
							 {
							    bool_t test_1160;
							    {
							       bool_t test_1161;
							       {
								  obj_t aux_1162;
								  {
								     object_t aux_1163;
								     aux_1163 = (object_t) (what_474);
								     aux_1162 = OBJECT_WIDENING(aux_1163);
								  }
								  test_1161 = (((cptr_t) CREF(aux_1162))->array__248);
							       }
							       if (test_1161)
								 {
								    obj_t aux_1169;
								    obj_t aux_1167;
								    aux_1169 = (obj_t) (what_474);
								    aux_1167 = (obj_t) (who_475);
								    test_1160 = (aux_1167 == aux_1169);
								 }
							       else
								 {
								    test_1160 = ((bool_t) 0);
								 }
							    }
							    if (test_1160)
							      {
								 test1439_684 = ((bool_t) 1);
							      }
							    else
							      {
								 bool_t _andtest_1155_686;
								 _andtest_1155_686 = is_a__118___object((obj_t) (who_475), calias_foreign_ctype);
								 if (_andtest_1155_686)
								   {
								      calias_t obj_1024;
								      obj_1024 = (calias_t) (who_475);
								      {
									 obj_t aux_1176;
									 {
									    object_t aux_1177;
									    aux_1177 = (object_t) (obj_1024);
									    aux_1176 = OBJECT_WIDENING(aux_1177);
									 }
									 test1439_684 = (((calias_t) CREF(aux_1176))->array__248);
								      }
								   }
								 else
								   {
								      test1439_684 = ((bool_t) 0);
								   }
							      }
							 }
							 if (test1439_684)
							   {
							      {
								 obj_t arg1443_689;
								 obj_t arg1444_690;
								 obj_t arg1446_691;
								 arg1443_689 = CNST_TABLE_REF(((long) 6));
								 {
								    obj_t arg1455_697;
								    {
								       obj_t arg1460_701;
								       arg1460_701 = CNST_TABLE_REF(((long) 13));
								       {
									  obj_t list1461_702;
									  {
									     obj_t arg1463_703;
									     {
										obj_t arg1464_704;
										{
										   obj_t arg1465_705;
										   arg1465_705 = MAKE_PAIR(id_479, BNIL);
										   arg1464_704 = MAKE_PAIR(_4dots_199_tools_misc, arg1465_705);
										}
										arg1463_703 = MAKE_PAIR(id_479, arg1464_704);
									     }
									     list1461_702 = MAKE_PAIR(arg1460_701, arg1463_703);
									  }
									  arg1455_697 = symbol_append_197___r4_symbols_6_4(list1461_702);
								       }
								    }
								    {
								       obj_t list1457_699;
								       list1457_699 = MAKE_PAIR(BNIL, BNIL);
								       arg1444_690 = cons__138___r4_pairs_and_lists_6_3(arg1455_697, list1457_699);
								    }
								 }
								 {
								    obj_t arg1467_707;
								    obj_t arg1468_708;
								    {
								       obj_t arg1474_713;
								       arg1474_713 = CNST_TABLE_REF(((long) 9));
								       {
									  obj_t list1475_714;
									  {
									     obj_t arg1476_715;
									     {
										obj_t arg1477_716;
										arg1477_716 = MAKE_PAIR(id_479, BNIL);
										arg1476_715 = MAKE_PAIR(_4dots_199_tools_misc, arg1477_716);
									     }
									     list1475_714 = MAKE_PAIR(arg1474_713, arg1476_715);
									  }
									  arg1467_707 = symbol_append_197___r4_symbols_6_4(list1475_714);
								       }
								    }
								    {
								       obj_t arg1483_721;
								       arg1483_721 = (((type_t) CREF(who_475))->size);
								       {
									  obj_t list1485_723;
									  {
									     obj_t arg1486_724;
									     {
										obj_t arg1487_725;
										{
										   obj_t arg1488_726;
										   {
										      obj_t arg1489_727;
										      {
											 obj_t arg1490_728;
											 arg1490_728 = MAKE_PAIR(string1790_foreign_cpointer, BNIL);
											 arg1489_727 = MAKE_PAIR(arg1483_721, arg1490_728);
										      }
										      arg1488_726 = MAKE_PAIR(string1791_foreign_cpointer, arg1489_727);
										   }
										   arg1487_725 = MAKE_PAIR(string1792_foreign_cpointer, arg1488_726);
										}
										arg1486_724 = MAKE_PAIR(name_sans___18_487, arg1487_725);
									     }
									     list1485_723 = MAKE_PAIR(string1793_foreign_cpointer, arg1486_724);
									  }
									  arg1468_708 = string_append_106___r4_strings_6_7(list1485_723);
								       }
								    }
								    {
								       obj_t list1470_710;
								       {
									  obj_t arg1471_711;
									  arg1471_711 = MAKE_PAIR(BNIL, BNIL);
									  list1470_710 = MAKE_PAIR(arg1468_708, arg1471_711);
								       }
								       arg1446_691 = cons__138___r4_pairs_and_lists_6_3(arg1467_707, list1470_710);
								    }
								 }
								 {
								    obj_t list1449_693;
								    {
								       obj_t arg1450_694;
								       {
									  obj_t arg1453_695;
									  arg1453_695 = MAKE_PAIR(BNIL, BNIL);
									  arg1450_694 = MAKE_PAIR(arg1446_691, arg1453_695);
								       }
								       list1449_693 = MAKE_PAIR(arg1444_690, arg1450_694);
								    }
								    arg1257_539 = cons__138___r4_pairs_and_lists_6_3(arg1443_689, list1449_693);
								 }
							      }
							   }
							 else
							   {
							      {
								 obj_t arg1494_731;
								 obj_t arg1496_732;
								 obj_t arg1497_733;
								 arg1494_731 = CNST_TABLE_REF(((long) 6));
								 {
								    obj_t arg1503_739;
								    obj_t arg1504_740;
								    {
								       obj_t arg1511_745;
								       arg1511_745 = CNST_TABLE_REF(((long) 13));
								       {
									  obj_t list1512_746;
									  {
									     obj_t arg1513_747;
									     {
										obj_t arg1514_748;
										{
										   obj_t arg1515_749;
										   arg1515_749 = MAKE_PAIR(id_479, BNIL);
										   arg1514_748 = MAKE_PAIR(_4dots_199_tools_misc, arg1515_749);
										}
										arg1513_747 = MAKE_PAIR(id_479, arg1514_748);
									     }
									     list1512_746 = MAKE_PAIR(arg1511_745, arg1513_747);
									  }
									  arg1503_739 = symbol_append_197___r4_symbols_6_4(list1512_746);
								       }
								    }
								    arg1504_740 = CNST_TABLE_REF(((long) 14));
								    {
								       obj_t list1506_742;
								       {
									  obj_t arg1507_743;
									  arg1507_743 = MAKE_PAIR(BNIL, BNIL);
									  list1506_742 = MAKE_PAIR(arg1504_740, arg1507_743);
								       }
								       arg1496_732 = cons__138___r4_pairs_and_lists_6_3(arg1503_739, list1506_742);
								    }
								 }
								 {
								    obj_t arg1517_751;
								    obj_t arg1518_752;
								    obj_t arg1519_753;
								    {
								       obj_t arg1527_759;
								       arg1527_759 = CNST_TABLE_REF(((long) 9));
								       {
									  obj_t list1528_760;
									  {
									     obj_t arg1529_761;
									     {
										obj_t arg1530_762;
										arg1530_762 = MAKE_PAIR(id_479, BNIL);
										arg1529_761 = MAKE_PAIR(_4dots_199_tools_misc, arg1530_762);
									     }
									     list1528_760 = MAKE_PAIR(arg1527_759, arg1529_761);
									  }
									  arg1517_751 = symbol_append_197___r4_symbols_6_4(list1528_760);
								       }
								    }
								    {
								       obj_t list1532_764;
								       {
									  obj_t arg1534_766;
									  {
									     obj_t arg1535_767;
									     {
										obj_t arg1537_769;
										{
										   obj_t arg1540_771;
										   {
										      obj_t arg1542_772;
										      {
											 obj_t arg1548_774;
											 arg1548_774 = MAKE_PAIR(string1794_foreign_cpointer, BNIL);
											 arg1542_772 = MAKE_PAIR(string1795_foreign_cpointer, arg1548_774);
										      }
										      arg1540_771 = MAKE_PAIR(point_to_name_sans___111_491, arg1542_772);
										   }
										   arg1537_769 = MAKE_PAIR(string1791_foreign_cpointer, arg1540_771);
										}
										arg1535_767 = MAKE_PAIR(string1792_foreign_cpointer, arg1537_769);
									     }
									     arg1534_766 = MAKE_PAIR(name_sans___18_487, arg1535_767);
									  }
									  list1532_764 = MAKE_PAIR(string1793_foreign_cpointer, arg1534_766);
								       }
								       arg1518_752 = string_append_106___r4_strings_6_7(list1532_764);
								    }
								    arg1519_753 = CNST_TABLE_REF(((long) 15));
								    {
								       obj_t list1523_755;
								       {
									  obj_t arg1524_756;
									  {
									     obj_t arg1525_757;
									     arg1525_757 = MAKE_PAIR(BNIL, BNIL);
									     arg1524_756 = MAKE_PAIR(arg1519_753, arg1525_757);
									  }
									  list1523_755 = MAKE_PAIR(arg1518_752, arg1524_756);
								       }
								       arg1497_733 = cons__138___r4_pairs_and_lists_6_3(arg1517_751, list1523_755);
								    }
								 }
								 {
								    obj_t list1499_735;
								    {
								       obj_t arg1500_736;
								       {
									  obj_t arg1501_737;
									  arg1501_737 = MAKE_PAIR(BNIL, BNIL);
									  arg1500_736 = MAKE_PAIR(arg1497_733, arg1501_737);
								       }
								       list1499_735 = MAKE_PAIR(arg1496_732, arg1500_736);
								    }
								    arg1257_539 = cons__138___r4_pairs_and_lists_6_3(arg1494_731, list1499_735);
								 }
							      }
							   }
						      }
						   }
						   {
						      obj_t arg1598_818;
						      obj_t arg1600_819;
						      obj_t arg1602_820;
						      arg1598_818 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1608_826;
							 obj_t arg1609_827;
							 obj_t arg1610_828;
							 {
							    obj_t arg1620_834;
							    arg1620_834 = CNST_TABLE_REF(((long) 18));
							    {
							       obj_t list1622_836;
							       {
								  obj_t arg1623_837;
								  {
								     obj_t arg1624_838;
								     {
									obj_t aux_1246;
									aux_1246 = CNST_TABLE_REF(((long) 2));
									arg1624_838 = MAKE_PAIR(aux_1246, BNIL);
								     }
								     arg1623_837 = MAKE_PAIR(id_479, arg1624_838);
								  }
								  list1622_836 = MAKE_PAIR(arg1620_834, arg1623_837);
							       }
							       arg1608_826 = symbol_append_197___r4_symbols_6_4(list1622_836);
							    }
							 }
							 {
							    obj_t arg1627_840;
							    arg1627_840 = CNST_TABLE_REF(((long) 19));
							    {
							       obj_t list1628_841;
							       {
								  obj_t arg1630_842;
								  {
								     obj_t arg1632_843;
								     arg1632_843 = MAKE_PAIR(id_479, BNIL);
								     arg1630_842 = MAKE_PAIR(_4dots_199_tools_misc, arg1632_843);
								  }
								  list1628_841 = MAKE_PAIR(arg1627_840, arg1630_842);
							       }
							       arg1609_827 = symbol_append_197___r4_symbols_6_4(list1628_841);
							    }
							 }
							 {
							    obj_t arg1634_845;
							    arg1634_845 = CNST_TABLE_REF(((long) 20));
							    {
							       obj_t list1635_846;
							       {
								  obj_t arg1636_847;
								  {
								     obj_t arg1638_848;
								     arg1638_848 = MAKE_PAIR(id_479, BNIL);
								     arg1636_847 = MAKE_PAIR(_4dots_199_tools_misc, arg1638_848);
								  }
								  list1635_846 = MAKE_PAIR(arg1634_845, arg1636_847);
							       }
							       arg1610_828 = symbol_append_197___r4_symbols_6_4(list1635_846);
							    }
							 }
							 {
							    obj_t list1613_830;
							    {
							       obj_t arg1615_831;
							       {
								  obj_t arg1617_832;
								  arg1617_832 = MAKE_PAIR(BNIL, BNIL);
								  arg1615_831 = MAKE_PAIR(arg1610_828, arg1617_832);
							       }
							       list1613_830 = MAKE_PAIR(arg1609_827, arg1615_831);
							    }
							    arg1600_819 = cons__138___r4_pairs_and_lists_6_3(arg1608_826, list1613_830);
							 }
						      }
						      {
							 obj_t arg1640_850;
							 obj_t arg1645_852;
							 obj_t arg1646_853;
							 arg1640_850 = CNST_TABLE_REF(((long) 17));
							 arg1645_852 = CNST_TABLE_REF(((long) 19));
							 arg1646_853 = CNST_TABLE_REF(((long) 20));
							 {
							    obj_t list1648_855;
							    {
							       obj_t arg1649_856;
							       {
								  obj_t arg1650_857;
								  {
								     obj_t arg1652_858;
								     arg1652_858 = MAKE_PAIR(BNIL, BNIL);
								     arg1650_857 = MAKE_PAIR(arg1646_853, arg1652_858);
								  }
								  arg1649_856 = MAKE_PAIR(arg1645_852, arg1650_857);
							       }
							       list1648_855 = MAKE_PAIR(string1798_foreign_cpointer, arg1649_856);
							    }
							    arg1602_820 = cons__138___r4_pairs_and_lists_6_3(arg1640_850, list1648_855);
							 }
						      }
						      {
							 obj_t list1604_822;
							 {
							    obj_t arg1605_823;
							    {
							       obj_t arg1606_824;
							       arg1606_824 = MAKE_PAIR(BNIL, BNIL);
							       arg1605_823 = MAKE_PAIR(arg1602_820, arg1606_824);
							    }
							    list1604_822 = MAKE_PAIR(arg1600_819, arg1605_823);
							 }
							 arg1258_540 = cons__138___r4_pairs_and_lists_6_3(arg1598_818, list1604_822);
						      }
						   }
						   {
						      obj_t arg1552_780;
						      obj_t arg1553_781;
						      obj_t arg1554_782;
						      arg1552_780 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1560_788;
							 obj_t arg1561_789;
							 {
							    obj_t list1567_795;
							    {
							       obj_t arg1568_796;
							       {
								  obj_t aux_1279;
								  aux_1279 = CNST_TABLE_REF(((long) 16));
								  arg1568_796 = MAKE_PAIR(aux_1279, BNIL);
							       }
							       list1567_795 = MAKE_PAIR(id_479, arg1568_796);
							    }
							    arg1560_788 = symbol_append_197___r4_symbols_6_4(list1567_795);
							 }
							 {
							    obj_t arg1570_798;
							    arg1570_798 = CNST_TABLE_REF(((long) 7));
							    {
							       obj_t list1571_799;
							       {
								  obj_t arg1572_800;
								  {
								     obj_t arg1573_801;
								     arg1573_801 = MAKE_PAIR(id_479, BNIL);
								     arg1572_800 = MAKE_PAIR(_4dots_199_tools_misc, arg1573_801);
								  }
								  list1571_799 = MAKE_PAIR(arg1570_798, arg1572_800);
							       }
							       arg1561_789 = symbol_append_197___r4_symbols_6_4(list1571_799);
							    }
							 }
							 {
							    obj_t list1563_791;
							    {
							       obj_t arg1564_792;
							       arg1564_792 = MAKE_PAIR(BNIL, BNIL);
							       list1563_791 = MAKE_PAIR(arg1561_789, arg1564_792);
							    }
							    arg1553_781 = cons__138___r4_pairs_and_lists_6_3(arg1560_788, list1563_791);
							 }
						      }
						      {
							 obj_t arg1578_803;
							 obj_t arg1580_804;
							 obj_t arg1581_805;
							 arg1578_803 = CNST_TABLE_REF(((long) 17));
							 {
							    obj_t list1587_811;
							    {
							       obj_t arg1589_813;
							       {
								  obj_t arg1592_814;
								  arg1592_814 = MAKE_PAIR(string1796_foreign_cpointer, BNIL);
								  arg1589_813 = MAKE_PAIR(name_sans___18_487, arg1592_814);
							       }
							       list1587_811 = MAKE_PAIR(string1797_foreign_cpointer, arg1589_813);
							    }
							    arg1580_804 = string_append_106___r4_strings_6_7(list1587_811);
							 }
							 arg1581_805 = CNST_TABLE_REF(((long) 7));
							 {
							    obj_t list1583_807;
							    {
							       obj_t arg1584_808;
							       {
								  obj_t arg1585_809;
								  arg1585_809 = MAKE_PAIR(BNIL, BNIL);
								  arg1584_808 = MAKE_PAIR(arg1581_805, arg1585_809);
							       }
							       list1583_807 = MAKE_PAIR(arg1580_804, arg1584_808);
							    }
							    arg1554_782 = cons__138___r4_pairs_and_lists_6_3(arg1578_803, list1583_807);
							 }
						      }
						      {
							 obj_t list1556_784;
							 {
							    obj_t arg1557_785;
							    {
							       obj_t arg1558_786;
							       arg1558_786 = MAKE_PAIR(BNIL, BNIL);
							       arg1557_785 = MAKE_PAIR(arg1554_782, arg1558_786);
							    }
							    list1556_784 = MAKE_PAIR(arg1553_781, arg1557_785);
							 }
							 arg1259_541 = cons__138___r4_pairs_and_lists_6_3(arg1552_780, list1556_784);
						      }
						   }
						   {
						      obj_t arg1655_861;
						      obj_t arg1656_862;
						      obj_t arg1657_863;
						      arg1655_861 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg1666_869;
							 arg1666_869 = CNST_TABLE_REF(((long) 21));
							 {
							    obj_t list1668_871;
							    {
							       obj_t arg1669_872;
							       arg1669_872 = MAKE_PAIR(BNIL, BNIL);
							       list1668_871 = MAKE_PAIR(arg1666_869, arg1669_872);
							    }
							    arg1656_862 = cons__138___r4_pairs_and_lists_6_3(bid__bool_159_485, list1668_871);
							 }
						      }
						      {
							 obj_t arg1672_874;
							 obj_t arg1673_875;
							 obj_t arg1675_876;
							 arg1672_874 = CNST_TABLE_REF(((long) 22));
							 {
							    obj_t arg1682_883;
							    obj_t arg1683_884;
							    arg1682_883 = CNST_TABLE_REF(((long) 23));
							    arg1683_884 = CNST_TABLE_REF(((long) 7));
							    {
							       obj_t list1685_886;
							       {
								  obj_t arg1686_887;
								  arg1686_887 = MAKE_PAIR(BNIL, BNIL);
								  list1685_886 = MAKE_PAIR(arg1683_884, arg1686_887);
							       }
							       arg1673_875 = cons__138___r4_pairs_and_lists_6_3(arg1682_883, list1685_886);
							    }
							 }
							 {
							    obj_t arg1689_889;
							    obj_t arg1691_890;
							    obj_t arg1692_891;
							    arg1689_889 = CNST_TABLE_REF(((long) 24));
							    {
							       obj_t arg1699_897;
							       obj_t arg1700_898;
							       arg1699_897 = CNST_TABLE_REF(((long) 25));
							       arg1700_898 = CNST_TABLE_REF(((long) 7));
							       {
								  obj_t list1702_900;
								  {
								     obj_t arg1703_901;
								     arg1703_901 = MAKE_PAIR(BNIL, BNIL);
								     list1702_900 = MAKE_PAIR(arg1700_898, arg1703_901);
								  }
								  arg1691_890 = cons__138___r4_pairs_and_lists_6_3(arg1699_897, list1702_900);
							       }
							    }
							    {
							       obj_t arg1705_903;
							       arg1705_903 = CNST_TABLE_REF(((long) 26));
							       {
								  obj_t list1707_905;
								  {
								     obj_t arg1708_906;
								     arg1708_906 = MAKE_PAIR(BNIL, BNIL);
								     list1707_905 = MAKE_PAIR(bid_481, arg1708_906);
								  }
								  arg1692_891 = cons__138___r4_pairs_and_lists_6_3(arg1705_903, list1707_905);
							       }
							    }
							    {
							       obj_t list1694_893;
							       {
								  obj_t arg1695_894;
								  {
								     obj_t arg1697_895;
								     arg1697_895 = MAKE_PAIR(BNIL, BNIL);
								     arg1695_894 = MAKE_PAIR(arg1692_891, arg1697_895);
								  }
								  list1694_893 = MAKE_PAIR(arg1691_890, arg1695_894);
							       }
							       arg1675_876 = cons__138___r4_pairs_and_lists_6_3(arg1689_889, list1694_893);
							    }
							 }
							 {
							    obj_t list1677_878;
							    {
							       obj_t arg1678_879;
							       {
								  obj_t arg1679_880;
								  {
								     obj_t arg1680_881;
								     arg1680_881 = MAKE_PAIR(BNIL, BNIL);
								     arg1679_880 = MAKE_PAIR(BFALSE, arg1680_881);
								  }
								  arg1678_879 = MAKE_PAIR(arg1675_876, arg1679_880);
							       }
							       list1677_878 = MAKE_PAIR(arg1673_875, arg1678_879);
							    }
							    arg1657_863 = cons__138___r4_pairs_and_lists_6_3(arg1672_874, list1677_878);
							 }
						      }
						      {
							 obj_t list1659_865;
							 {
							    obj_t arg1661_866;
							    {
							       obj_t arg1663_867;
							       arg1663_867 = MAKE_PAIR(BNIL, BNIL);
							       arg1661_866 = MAKE_PAIR(arg1657_863, arg1663_867);
							    }
							    list1659_865 = MAKE_PAIR(arg1656_862, arg1661_866);
							 }
							 arg1260_542 = cons__138___r4_pairs_and_lists_6_3(arg1655_861, list1659_865);
						      }
						   }
						   {
						      obj_t ref_id_68_550;
						      obj_t set_id_60_551;
						      obj_t ref_type_id_85_552;
						      obj_t ref_fmt_10_553;
						      obj_t set_fmt_103_554;
						      {
							 obj_t list1389_643;
							 {
							    obj_t arg1390_644;
							    {
							       obj_t aux_1340;
							       aux_1340 = CNST_TABLE_REF(((long) 3));
							       arg1390_644 = MAKE_PAIR(aux_1340, BNIL);
							    }
							    list1389_643 = MAKE_PAIR(id_479, arg1390_644);
							 }
							 ref_id_68_550 = symbol_append_197___r4_symbols_6_4(list1389_643);
						      }
						      {
							 obj_t list1393_647;
							 {
							    obj_t arg1395_648;
							    {
							       obj_t aux_1345;
							       aux_1345 = CNST_TABLE_REF(((long) 4));
							       arg1395_648 = MAKE_PAIR(aux_1345, BNIL);
							    }
							    list1393_647 = MAKE_PAIR(id_479, arg1395_648);
							 }
							 set_id_60_551 = symbol_append_197___r4_symbols_6_4(list1393_647);
						      }
						      {
							 bool_t test1397_650;
							 test1397_650 = is_a__118___object((obj_t) (point_to_164_488), cstruct_foreign_ctype);
							 if (test1397_650)
							   {
							      obj_t list1399_652;
							      {
								 obj_t arg1401_653;
								 {
								    obj_t aux_1353;
								    aux_1353 = CNST_TABLE_REF(((long) 5));
								    arg1401_653 = MAKE_PAIR(aux_1353, BNIL);
								 }
								 list1399_652 = MAKE_PAIR(point_to_id_253_489, arg1401_653);
							      }
							      ref_type_id_85_552 = symbol_append_197___r4_symbols_6_4(list1399_652);
							   }
							 else
							   {
							      ref_type_id_85_552 = point_to_id_253_489;
							   }
						      }
						      {
							 bool_t test1403_655;
							 test1403_655 = is_a__118___object((obj_t) (point_to_164_488), cstruct_foreign_ctype);
							 if (test1403_655)
							   {
							      obj_t list1404_656;
							      {
								 obj_t arg1407_658;
								 {
								    obj_t arg1408_659;
								    arg1408_659 = MAKE_PAIR(string1783_foreign_cpointer, BNIL);
								    arg1407_658 = MAKE_PAIR(name_sans___18_487, arg1408_659);
								 }
								 list1404_656 = MAKE_PAIR(string1784_foreign_cpointer, arg1407_658);
							      }
							      ref_fmt_10_553 = string_append_106___r4_strings_6_7(list1404_656);
							   }
							 else
							   {
							      obj_t list1412_662;
							      {
								 obj_t arg1414_664;
								 {
								    obj_t arg1415_665;
								    arg1415_665 = MAKE_PAIR(string1785_foreign_cpointer, BNIL);
								    arg1414_664 = MAKE_PAIR(name_sans___18_487, arg1415_665);
								 }
								 list1412_662 = MAKE_PAIR(string1786_foreign_cpointer, arg1414_664);
							      }
							      ref_fmt_10_553 = string_append_106___r4_strings_6_7(list1412_662);
							   }
						      }
						      {
							 bool_t test1418_668;
							 test1418_668 = is_a__118___object((obj_t) (point_to_164_488), cstruct_foreign_ctype);
							 if (test1418_668)
							   {
							      obj_t list1419_669;
							      {
								 obj_t arg1423_671;
								 {
								    obj_t arg1426_672;
								    arg1426_672 = MAKE_PAIR(string1787_foreign_cpointer, BNIL);
								    arg1423_671 = MAKE_PAIR(name_sans___18_487, arg1426_672);
								 }
								 list1419_669 = MAKE_PAIR(string1788_foreign_cpointer, arg1423_671);
							      }
							      set_fmt_103_554 = string_append_106___r4_strings_6_7(list1419_669);
							   }
							 else
							   {
							      obj_t list1429_675;
							      {
								 obj_t arg1432_677;
								 {
								    obj_t arg1433_678;
								    arg1433_678 = MAKE_PAIR(string1789_foreign_cpointer, BNIL);
								    arg1432_677 = MAKE_PAIR(name_sans___18_487, arg1433_678);
								 }
								 list1429_675 = MAKE_PAIR(string1788_foreign_cpointer, arg1432_677);
							      }
							      set_fmt_103_554 = string_append_106___r4_strings_6_7(list1429_675);
							   }
						      }
						      {
							 obj_t arg1272_555;
							 obj_t arg1273_556;
							 {
							    obj_t arg1281_560;
							    obj_t arg1282_561;
							    obj_t arg1283_562;
							    arg1281_560 = CNST_TABLE_REF(((long) 6));
							    {
							       obj_t arg1290_568;
							       obj_t arg1291_569;
							       obj_t arg1292_570;
							       {
								  obj_t list1299_576;
								  {
								     obj_t arg1300_577;
								     {
									obj_t arg1301_578;
									arg1301_578 = MAKE_PAIR(ref_type_id_85_552, BNIL);
									arg1300_577 = MAKE_PAIR(_4dots_199_tools_misc, arg1301_578);
								     }
								     list1299_576 = MAKE_PAIR(ref_id_68_550, arg1300_577);
								  }
								  arg1290_568 = symbol_append_197___r4_symbols_6_4(list1299_576);
							       }
							       {
								  obj_t arg1303_580;
								  arg1303_580 = CNST_TABLE_REF(((long) 7));
								  {
								     obj_t list1304_581;
								     {
									obj_t arg1307_582;
									{
									   obj_t arg1308_583;
									   arg1308_583 = MAKE_PAIR(id_479, BNIL);
									   arg1307_582 = MAKE_PAIR(_4dots_199_tools_misc, arg1308_583);
									}
									list1304_581 = MAKE_PAIR(arg1303_580, arg1307_582);
								     }
								     arg1291_569 = symbol_append_197___r4_symbols_6_4(list1304_581);
								  }
							       }
							       arg1292_570 = CNST_TABLE_REF(((long) 8));
							       {
								  obj_t list1295_572;
								  {
								     obj_t arg1296_573;
								     {
									obj_t arg1297_574;
									arg1297_574 = MAKE_PAIR(BNIL, BNIL);
									arg1296_573 = MAKE_PAIR(arg1292_570, arg1297_574);
								     }
								     list1295_572 = MAKE_PAIR(arg1291_569, arg1296_573);
								  }
								  arg1282_561 = cons__138___r4_pairs_and_lists_6_3(arg1290_568, list1295_572);
							       }
							    }
							    {
							       obj_t arg1310_585;
							       obj_t arg1311_586;
							       obj_t arg1313_587;
							       {
								  obj_t arg1324_594;
								  arg1324_594 = CNST_TABLE_REF(((long) 9));
								  {
								     obj_t list1325_595;
								     {
									obj_t arg1326_596;
									{
									   obj_t arg1328_597;
									   arg1328_597 = MAKE_PAIR(ref_type_id_85_552, BNIL);
									   arg1326_596 = MAKE_PAIR(_4dots_199_tools_misc, arg1328_597);
									}
									list1325_595 = MAKE_PAIR(arg1324_594, arg1326_596);
								     }
								     arg1310_585 = symbol_append_197___r4_symbols_6_4(list1325_595);
								  }
							       }
							       arg1311_586 = CNST_TABLE_REF(((long) 7));
							       arg1313_587 = CNST_TABLE_REF(((long) 10));
							       {
								  obj_t list1316_589;
								  {
								     obj_t arg1319_590;
								     {
									obj_t arg1321_591;
									{
									   obj_t arg1322_592;
									   arg1322_592 = MAKE_PAIR(BNIL, BNIL);
									   arg1321_591 = MAKE_PAIR(arg1313_587, arg1322_592);
									}
									arg1319_590 = MAKE_PAIR(arg1311_586, arg1321_591);
								     }
								     list1316_589 = MAKE_PAIR(ref_fmt_10_553, arg1319_590);
								  }
								  arg1283_562 = cons__138___r4_pairs_and_lists_6_3(arg1310_585, list1316_589);
							       }
							    }
							    {
							       obj_t list1285_564;
							       {
								  obj_t arg1286_565;
								  {
								     obj_t arg1287_566;
								     arg1287_566 = MAKE_PAIR(BNIL, BNIL);
								     arg1286_565 = MAKE_PAIR(arg1283_562, arg1287_566);
								  }
								  list1285_564 = MAKE_PAIR(arg1282_561, arg1286_565);
							       }
							       arg1272_555 = cons__138___r4_pairs_and_lists_6_3(arg1281_560, list1285_564);
							    }
							 }
							 {
							    obj_t arg1331_599;
							    obj_t arg1332_600;
							    obj_t arg1333_601;
							    arg1331_599 = CNST_TABLE_REF(((long) 6));
							    {
							       obj_t arg1342_607;
							       obj_t arg1343_608;
							       obj_t arg1344_609;
							       obj_t arg1345_610;
							       {
								  obj_t list1354_618;
								  {
								     obj_t arg1355_619;
								     {
									obj_t aux_1412;
									aux_1412 = CNST_TABLE_REF(((long) 11));
									arg1355_619 = MAKE_PAIR(aux_1412, BNIL);
								     }
								     list1354_618 = MAKE_PAIR(set_id_60_551, arg1355_619);
								  }
								  arg1342_607 = symbol_append_197___r4_symbols_6_4(list1354_618);
							       }
							       {
								  obj_t arg1357_621;
								  arg1357_621 = CNST_TABLE_REF(((long) 7));
								  {
								     obj_t list1358_622;
								     {
									obj_t arg1361_623;
									{
									   obj_t arg1363_624;
									   arg1363_624 = MAKE_PAIR(id_479, BNIL);
									   arg1361_623 = MAKE_PAIR(_4dots_199_tools_misc, arg1363_624);
									}
									list1358_622 = MAKE_PAIR(arg1357_621, arg1361_623);
								     }
								     arg1343_608 = symbol_append_197___r4_symbols_6_4(list1358_622);
								  }
							       }
							       arg1344_609 = CNST_TABLE_REF(((long) 8));
							       {
								  obj_t arg1365_626;
								  arg1365_626 = CNST_TABLE_REF(((long) 12));
								  {
								     obj_t list1366_627;
								     {
									obj_t arg1367_628;
									{
									   obj_t arg1368_629;
									   arg1368_629 = MAKE_PAIR(ref_type_id_85_552, BNIL);
									   arg1367_628 = MAKE_PAIR(_4dots_199_tools_misc, arg1368_629);
									}
									list1366_627 = MAKE_PAIR(arg1365_626, arg1367_628);
								     }
								     arg1345_610 = symbol_append_197___r4_symbols_6_4(list1366_627);
								  }
							       }
							       {
								  obj_t list1348_612;
								  {
								     obj_t arg1349_613;
								     {
									obj_t arg1350_614;
									{
									   obj_t arg1351_615;
									   arg1351_615 = MAKE_PAIR(BNIL, BNIL);
									   arg1350_614 = MAKE_PAIR(arg1345_610, arg1351_615);
									}
									arg1349_613 = MAKE_PAIR(arg1344_609, arg1350_614);
								     }
								     list1348_612 = MAKE_PAIR(arg1343_608, arg1349_613);
								  }
								  arg1332_600 = cons__138___r4_pairs_and_lists_6_3(arg1342_607, list1348_612);
							       }
							    }
							    {
							       obj_t arg1370_631;
							       obj_t arg1372_632;
							       obj_t arg1373_633;
							       obj_t arg1375_634;
							       arg1370_631 = CNST_TABLE_REF(((long) 9));
							       arg1372_632 = CNST_TABLE_REF(((long) 7));
							       arg1373_633 = CNST_TABLE_REF(((long) 10));
							       arg1375_634 = CNST_TABLE_REF(((long) 12));
							       {
								  obj_t list1379_636;
								  {
								     obj_t arg1381_637;
								     {
									obj_t arg1383_638;
									{
									   obj_t arg1384_639;
									   {
									      obj_t arg1385_640;
									      arg1385_640 = MAKE_PAIR(BNIL, BNIL);
									      arg1384_639 = MAKE_PAIR(arg1375_634, arg1385_640);
									   }
									   arg1383_638 = MAKE_PAIR(arg1373_633, arg1384_639);
									}
									arg1381_637 = MAKE_PAIR(arg1372_632, arg1383_638);
								     }
								     list1379_636 = MAKE_PAIR(set_fmt_103_554, arg1381_637);
								  }
								  arg1333_601 = cons__138___r4_pairs_and_lists_6_3(arg1370_631, list1379_636);
							       }
							    }
							    {
							       obj_t list1335_603;
							       {
								  obj_t arg1337_604;
								  {
								     obj_t arg1339_605;
								     arg1339_605 = MAKE_PAIR(BNIL, BNIL);
								     arg1337_604 = MAKE_PAIR(arg1333_601, arg1339_605);
								  }
								  list1335_603 = MAKE_PAIR(arg1332_600, arg1337_604);
							       }
							       arg1273_556 = cons__138___r4_pairs_and_lists_6_3(arg1331_599, list1335_603);
							    }
							 }
							 {
							    obj_t list1274_557;
							    {
							       obj_t arg1277_558;
							       arg1277_558 = MAKE_PAIR(arg1273_556, BNIL);
							       list1274_557 = MAKE_PAIR(arg1272_555, arg1277_558);
							    }
							    arg1262_543 = list1274_557;
							 }
						      }
						   }
						   {
						      obj_t list1263_544;
						      {
							 obj_t arg1265_545;
							 {
							    obj_t arg1267_546;
							    {
							       obj_t arg1268_547;
							       arg1268_547 = MAKE_PAIR(arg1262_543, BNIL);
							       arg1267_546 = MAKE_PAIR(arg1260_542, arg1268_547);
							    }
							    arg1265_545 = MAKE_PAIR(arg1259_541, arg1267_546);
							 }
							 list1263_544 = MAKE_PAIR(arg1258_540, arg1265_545);
						      }
						      return cons__138___r4_pairs_and_lists_6_3(arg1257_539, list1263_544);
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_cpointer()
{
   module_initialization_70_tools_trace(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70_type_tools(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70_type_type(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70_tools_shape(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70_tools_misc(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70_foreign_ctype(((long) 0), "FOREIGN_CPOINTER");
   module_initialization_70_foreign_access(((long) 0), "FOREIGN_CPOINTER");
   return module_initialization_70_module_module(((long) 0), "FOREIGN_CPOINTER");
}
