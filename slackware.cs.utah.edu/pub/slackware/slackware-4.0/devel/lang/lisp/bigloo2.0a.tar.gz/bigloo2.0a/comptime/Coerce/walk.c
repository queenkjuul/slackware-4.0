/*===========================================================================*/
/*   (Coerce/walk.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_coerce_walk();
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t leave_function_170_tools_error();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_coerce_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_coerce_pproto(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t coerce_walk__125_coerce_walk(obj_t);
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_coerce_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t library_modules_init_112_coerce_walk();
extern obj_t open_input_string(obj_t);
static obj_t _coerce_walk__98_coerce_walk(obj_t, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t reset_ppmarge__67_coerce_pproto();
extern obj_t for_each_global__88_ast_env(obj_t);
static obj_t arg1464_coerce_walk(obj_t, obj_t);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t pvariable_proto_90_coerce_pproto(long, variable_t);
extern obj_t coerce_function__220_coerce_coerce(variable_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_coerce_walk = BUNSPEC;
static obj_t cnst_init_137_coerce_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[4];

DEFINE_STATIC_PROCEDURE(proc1597_coerce_walk, arg1464_coerce_walk1607, arg1464_coerce_walk, 0L, 1);
DEFINE_EXPORT_PROCEDURE(coerce_walk__env_217_coerce_walk, _coerce_walk__98_coerce_walk1608, _coerce_walk__98_coerce_walk, 0L, 1);
DEFINE_STRING(string1599_coerce_walk, string1599_coerce_walk1609, " error", 6);
DEFINE_STRING(string1598_coerce_walk, string1598_coerce_walk1610, " occured, ending ...", 20);
DEFINE_STRING(string1596_coerce_walk, string1596_coerce_walk1611, "failure during prelude hook", 27);
DEFINE_STRING(string1595_coerce_walk, string1595_coerce_walk1612, "   . ", 5);
DEFINE_STRING(string1594_coerce_walk, string1594_coerce_walk1613, "Coercions & Checks", 18);
DEFINE_STRING(string1601_coerce_walk, string1601_coerce_walk1614, "EXPORT STATIC COERCE PASS-STARTED ", 34);
DEFINE_STRING(string1600_coerce_walk, string1600_coerce_walk1615, "failure during postlude hook", 28);


/* module-initialization */ obj_t 
module_initialization_70_coerce_walk(long checksum_1125, char *from_1126)
{
   if (CBOOL(require_initialization_114_coerce_walk))
     {
	require_initialization_114_coerce_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_walk();
	cnst_init_137_coerce_walk();
	imported_modules_init_94_coerce_walk();
	method_init_76_coerce_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_walk()
{
   module_initialization_70___object(((long) 0), "COERCE_WALK");
   module_initialization_70___r4_output_6_10_3(((long) 0), "COERCE_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "COERCE_WALK");
   module_initialization_70___reader(((long) 0), "COERCE_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_walk()
{
   {
      obj_t cnst_port_138_1117;
      cnst_port_138_1117 = open_input_string(string1601_coerce_walk);
      {
	 long i_1118;
	 i_1118 = ((long) 3);
       loop_1119:
	 {
	    bool_t test1602_1120;
	    test1602_1120 = (i_1118 == ((long) -1));
	    if (test1602_1120)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1603_1121;
		    {
		       obj_t list1604_1122;
		       {
			  obj_t arg1605_1123;
			  arg1605_1123 = BNIL;
			  list1604_1122 = MAKE_PAIR(cnst_port_138_1117, arg1605_1123);
		       }
		       arg1603_1121 = read___reader(list1604_1122);
		    }
		    CNST_TABLE_SET(i_1118, arg1603_1121);
		 }
		 {
		    int aux_1124;
		    {
		       long aux_1144;
		       aux_1144 = (i_1118 - ((long) 1));
		       aux_1124 = (int) (aux_1144);
		    }
		    {
		       long i_1147;
		       i_1147 = (long) (aux_1124);
		       i_1118 = i_1147;
		       goto loop_1119;
		    }
		 }
	      }
	 }
      }
   }
}


/* coerce-walk! */ obj_t 
coerce_walk__125_coerce_walk(obj_t ast_1)
{
   {
      obj_t list1438_693;
      {
	 obj_t arg1441_695;
	 {
	    obj_t arg1444_697;
	    {
	       obj_t aux_1149;
	       aux_1149 = BCHAR(((unsigned char) '\n'));
	       arg1444_697 = MAKE_PAIR(aux_1149, BNIL);
	    }
	    arg1441_695 = MAKE_PAIR(string1594_coerce_walk, arg1444_697);
	 }
	 list1438_693 = MAKE_PAIR(string1595_coerce_walk, arg1441_695);
      }
      verbose_tools_speek(BINT(((long) 1)), list1438_693);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1594_coerce_walk;
   {
      obj_t hooks_699;
      obj_t hnames_700;
      hooks_699 = BNIL;
      hnames_700 = BNIL;
    loop_701:
      if (NULLP(hooks_699))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1452_706;
	   {
	      obj_t fun1459_712;
	      fun1459_712 = CAR(hooks_699);
	      {
		 obj_t aux_1161;
		 aux_1161 = PROCEDURE_ENTRY(fun1459_712) (fun1459_712, BEOA);
		 test1452_706 = CBOOL(aux_1161);
	      }
	   }
	   if (test1452_706)
	     {
		{
		   obj_t hnames_1168;
		   obj_t hooks_1166;
		   hooks_1166 = CDR(hooks_699);
		   hnames_1168 = CDR(hnames_700);
		   hnames_700 = hnames_1168;
		   hooks_699 = hooks_1166;
		   goto loop_701;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1594_coerce_walk, string1596_coerce_walk, CAR(hnames_700));
	     }
	}
   }
   {
      obj_t l1435_713;
      l1435_713 = ast_1;
    lname1436_714:
      if (PAIRP(l1435_713))
	{
	   {
	      obj_t global_716;
	      global_716 = CAR(l1435_713);
	      reset_ppmarge__67_coerce_pproto();
	      {
		 obj_t aux_1176;
		 {
		    global_t obj_1091;
		    obj_1091 = (global_t) (global_716);
		    aux_1176 = (((global_t) CREF(obj_1091))->id);
		 }
		 enter_function_81_tools_error(aux_1176);
	      }
	      coerce_function__220_coerce_coerce((variable_t) (global_716));
	      leave_function_170_tools_error();
	   }
	   {
	      obj_t l1435_1183;
	      l1435_1183 = CDR(l1435_713);
	      l1435_713 = l1435_1183;
	      goto lname1436_714;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   reset_ppmarge__67_coerce_pproto();
   {
      obj_t arg1464_1112;
      arg1464_1112 = proc1597_coerce_walk;
      for_each_global__88_ast_env(arg1464_1112);
   }
   {
      obj_t value_731;
      value_731 = remove_var_123_ast_remove(CNST_TABLE_REF(((long) 1)), ast_1);
      {
	 bool_t test1474_732;
	 {
	    long n1_1101;
	    n1_1101 = (long) CINT(_nb_error_on_pass__70_tools_error);
	    test1474_732 = (n1_1101 > ((long) 0));
	 }
	 if (test1474_732)
	   {
	      {
		 char *arg1477_735;
		 {
		    bool_t test1485_742;
		    {
		       bool_t test1486_743;
		       {
			  obj_t obj_1103;
			  obj_1103 = _nb_error_on_pass__70_tools_error;
			  test1486_743 = INTEGERP(obj_1103);
		       }
		       if (test1486_743)
			 {
			    test1485_742 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			 }
		       else
			 {
			    test1485_742 = ((bool_t) 0);
			 }
		    }
		    if (test1485_742)
		      {
			 arg1477_735 = "s";
		      }
		    else
		      {
			 arg1477_735 = "";
		      }
		 }
		 {
		    obj_t list1479_737;
		    {
		       obj_t arg1480_738;
		       {
			  obj_t arg1481_739;
			  {
			     obj_t arg1483_740;
			     arg1483_740 = MAKE_PAIR(string1598_coerce_walk, BNIL);
			     {
				obj_t aux_1198;
				aux_1198 = string_to_bstring(arg1477_735);
				arg1481_739 = MAKE_PAIR(aux_1198, arg1483_740);
			     }
			  }
			  arg1480_738 = MAKE_PAIR(string1599_coerce_walk, arg1481_739);
		       }
		       list1479_737 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1480_738);
		    }
		    fprint___r4_output_6_10_3(current_error_port, list1479_737);
		 }
	      }
	      {
		 obj_t res1593_1105;
		 exit(((long) -1));
		 res1593_1105 = BINT(((long) -1));
		 return res1593_1105;
	      }
	   }
	 else
	   {
	      obj_t hooks_744;
	      obj_t hnames_745;
	      hooks_744 = BNIL;
	      hnames_745 = BNIL;
	    loop_746:
	      if (NULLP(hooks_744))
		{
		   return value_731;
		}
	      else
		{
		   bool_t test1491_751;
		   {
		      obj_t fun1499_756;
		      fun1499_756 = CAR(hooks_744);
		      {
			 obj_t aux_1209;
			 aux_1209 = PROCEDURE_ENTRY(fun1499_756) (fun1499_756, BEOA);
			 test1491_751 = CBOOL(aux_1209);
		      }
		   }
		   if (test1491_751)
		     {
			{
			   obj_t hnames_1216;
			   obj_t hooks_1214;
			   hooks_1214 = CDR(hooks_744);
			   hnames_1216 = CDR(hnames_745);
			   hnames_745 = hnames_1216;
			   hooks_744 = hooks_1214;
			   goto loop_746;
			}
		     }
		   else
		     {
			return internal_error_43_tools_error(_current_pass__25_engine_pass, string1600_coerce_walk, CAR(hnames_745));
		     }
		}
	   }
      }
   }
}


/* _coerce-walk! */ obj_t 
_coerce_walk__98_coerce_walk(obj_t env_1113, obj_t ast_1114)
{
   return coerce_walk__125_coerce_walk(ast_1114);
}


/* arg1464 */ obj_t 
arg1464_coerce_walk(obj_t env_1115, obj_t global_1116)
{
   {
      obj_t global_720;
      global_720 = global_1116;
      {
	 bool_t test1466_722;
	 {
	    bool_t test1467_723;
	    {
	       obj_t aux_1221;
	       {
		  value_t aux_1222;
		  {
		     global_t obj_1093;
		     obj_1093 = (global_t) (global_720);
		     aux_1222 = (((global_t) CREF(obj_1093))->value);
		  }
		  aux_1221 = (obj_t) (aux_1222);
	       }
	       test1467_723 = is_a__118___object(aux_1221, fun_ast_var);
	    }
	    if (test1467_723)
	      {
		 test1466_722 = ((bool_t) 0);
	      }
	    else
	      {
		 bool_t _ortest_1437_724;
		 {
		    obj_t aux_1231;
		    obj_t aux_1228;
		    aux_1231 = CNST_TABLE_REF(((long) 2));
		    {
		       global_t obj_1095;
		       obj_1095 = (global_t) (global_720);
		       aux_1228 = (((global_t) CREF(obj_1095))->import);
		    }
		    _ortest_1437_724 = (aux_1228 == aux_1231);
		 }
		 if (_ortest_1437_724)
		   {
		      test1466_722 = _ortest_1437_724;
		   }
		 else
		   {
		      obj_t aux_1238;
		      obj_t aux_1235;
		      aux_1238 = CNST_TABLE_REF(((long) 3));
		      {
			 global_t obj_1098;
			 obj_1098 = (global_t) (global_720);
			 aux_1235 = (((global_t) CREF(obj_1098))->import);
		      }
		      test1466_722 = (aux_1235 == aux_1238);
		   }
	      }
	 }
	 if (test1466_722)
	   {
	      return pvariable_proto_90_coerce_pproto(((long) 3), (variable_t) (global_720));
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_coerce_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_walk()
{
   module_initialization_70_tools_speek(((long) 0), "COERCE_WALK");
   module_initialization_70_tools_error(((long) 0), "COERCE_WALK");
   module_initialization_70_engine_pass(((long) 0), "COERCE_WALK");
   module_initialization_70_tools_shape(((long) 0), "COERCE_WALK");
   module_initialization_70_type_type(((long) 0), "COERCE_WALK");
   module_initialization_70_type_cache(((long) 0), "COERCE_WALK");
   module_initialization_70_engine_param(((long) 0), "COERCE_WALK");
   module_initialization_70_ast_var(((long) 0), "COERCE_WALK");
   module_initialization_70_ast_env(((long) 0), "COERCE_WALK");
   module_initialization_70_ast_node(((long) 0), "COERCE_WALK");
   module_initialization_70_ast_remove(((long) 0), "COERCE_WALK");
   module_initialization_70_coerce_pproto(((long) 0), "COERCE_WALK");
   return module_initialization_70_coerce_coerce(((long) 0), "COERCE_WALK");
}
