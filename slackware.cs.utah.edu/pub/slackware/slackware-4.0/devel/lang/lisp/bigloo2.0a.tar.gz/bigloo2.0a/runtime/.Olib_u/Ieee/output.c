/*===========================================================================*/
/*   (Ieee/output.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>


/* Object type definitions */

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t object_write_132___object(object_t, obj_t);
static obj_t method_init_76___r4_output_6_10_3();
static obj_t rhandler1007___r4_output_6_10_3(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t write_display_tvector_50___r4_output_6_10_3(obj_t, obj_t, bool_t);
extern obj_t current_output_port;
extern obj_t display__75___r4_output_6_10_3(obj_t);
static obj_t _set_printer_1360_246___r4_output_6_10_3(obj_t, obj_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t body1009___r4_output_6_10_3(obj_t);
extern obj_t set_printer__238___r4_output_6_10_3(obj_t);
extern obj_t display_fixnum(obj_t, obj_t);
extern obj_t exitd_top;
static obj_t _print___r4_output_6_10_3(obj_t, obj_t);
static obj_t toplevel_init_63___r4_output_6_10_3();
extern obj_t display_ucs2(obj_t, obj_t);
extern obj_t tvector_id_255___tvector(obj_t);
extern obj_t write__14___r4_output_6_10_3(obj_t);
extern obj_t ill_char_rep(unsigned char);
extern obj_t print___r4_output_6_10_3(obj_t);
static obj_t _write_char1357_135___r4_output_6_10_3(obj_t, obj_t, obj_t);
static obj_t native_display_62___r4_output_6_10_3(obj_t, obj_t);
extern obj_t native_printer_249___r4_output_6_10_3();
static obj_t write_display_pair_103___r4_output_6_10_3(obj_t, obj_t, bool_t);
static obj_t _get_write_length_196___r4_output_6_10_3(obj_t);
static obj_t _c_debugging_print_109___r4_output_6_10_3(obj_t, obj_t);
static obj_t _write__154___r4_output_6_10_3(obj_t, obj_t);
static obj_t write_display_159___r4_output_6_10_3(obj_t, obj_t, bool_t);
extern obj_t display_string(obj_t, obj_t);
extern obj_t display_char(obj_t, obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
static long _displayed__5___r4_output_6_10_3;
extern obj_t ucs2_string_to_utf8_string(obj_t);
extern obj_t object_display_243___object(object_t, obj_t);
extern obj_t dprint(obj_t);
extern obj_t display_ucs2string(obj_t, obj_t);
extern obj_t illegal_char_rep_197___r4_output_6_10_3(unsigned char);
static obj_t _fprint1359___r4_output_6_10_3(obj_t, obj_t, obj_t);
static obj_t handling_function1033___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
static obj_t _current_printer__39___r4_output_6_10_3 = BUNSPEC;
extern long get_write_length_193___r4_output_6_10_3();
extern obj_t write_ucs2(obj_t, obj_t);
extern obj_t tvector_ref_208___tvector(obj_t);
static obj_t arg1035___r4_output_6_10_3(obj_t);
static obj_t arg1034___r4_output_6_10_3(obj_t);
extern obj_t remove_error_handler__102___error();
extern obj_t write_utf8string(obj_t, obj_t);
static obj_t _illegal_char_rep1358_34___r4_output_6_10_3(obj_t, obj_t);
static obj_t _set_write_length_1356_70___r4_output_6_10_3(obj_t, obj_t);
extern obj_t write_string(obj_t, obj_t);
static obj_t _write___r4_output_6_10_3(obj_t, obj_t, obj_t);
static obj_t write_display_structure_107___r4_output_6_10_3(obj_t, obj_t, bool_t);
extern obj_t display_flonum(obj_t, obj_t);
extern obj_t write_object(obj_t, obj_t);
static obj_t _display___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t write___r4_output_6_10_3(obj_t, obj_t);
static obj_t escape___r4_output_6_10_3(obj_t, obj_t);
static obj_t _newline___r4_output_6_10_3(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_output_6_10_3();
static obj_t _native_display_199___r4_output_6_10_3(obj_t, obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t _native_printer_193___r4_output_6_10_3(obj_t);
extern obj_t set_write_length__244___r4_output_6_10_3(long);
static obj_t require_initialization_114___r4_output_6_10_3 = BUNSPEC;
static long _max_length_write__149___r4_output_6_10_3;
extern obj_t write_char(obj_t, obj_t);
extern obj_t string_for_read(obj_t);
static obj_t _display__37___r4_output_6_10_3(obj_t, obj_t);
extern obj_t write_char_165___r4_output_6_10_3(unsigned char, obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t write_display_vector_76___r4_output_6_10_3(obj_t, obj_t, bool_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( set_write_length__env_212___r4_output_6_10_3, _set_write_length_1356_70___r4_output_6_10_31369, _set_write_length_1356_70___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( display_env_131___r4_output_6_10_3, _display___r4_output_6_10_31370, va_generic_entry, _display___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( newline_env_143___r4_output_6_10_3, _newline___r4_output_6_10_31371, va_generic_entry, _newline___r4_output_6_10_3, -1 );
DEFINE_STATIC_PROCEDURE( native_display_env_3___r4_output_6_10_3, _native_display_199___r4_output_6_10_31372, va_generic_entry, _native_display_199___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( write_char_env_35___r4_output_6_10_3, _write_char1357_135___r4_output_6_10_31373, va_generic_entry, _write_char1357_135___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( get_write_length_env_149___r4_output_6_10_3, _get_write_length_196___r4_output_6_10_31374, _get_write_length_196___r4_output_6_10_3, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( write_env_37___r4_output_6_10_3, _write___r4_output_6_10_31375, va_generic_entry, _write___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( write__env_225___r4_output_6_10_3, _write__154___r4_output_6_10_31376, va_generic_entry, _write__154___r4_output_6_10_3, -1 );
DEFINE_EXPORT_PROCEDURE( fprint_env_249___r4_output_6_10_3, _fprint1359___r4_output_6_10_31377, va_generic_entry, _fprint1359___r4_output_6_10_3, -2 );
DEFINE_EXPORT_PROCEDURE( native_printer_env_215___r4_output_6_10_3, _native_printer_193___r4_output_6_10_31378, _native_printer_193___r4_output_6_10_3, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( c_debugging_print_env_230___r4_output_6_10_3, _c_debugging_print_109___r4_output_6_10_31379, _c_debugging_print_109___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( print_env_243___r4_output_6_10_3, _print___r4_output_6_10_31380, va_generic_entry, _print___r4_output_6_10_3, -1 );
DEFINE_STRING( string1367___r4_output_6_10_3, string1367___r4_output_6_10_31381, " . ... )", 8 );
DEFINE_EXPORT_PROCEDURE( illegal_char_rep_env_244___r4_output_6_10_3, _illegal_char_rep1358_34___r4_output_6_10_31382, _illegal_char_rep1358_34___r4_output_6_10_3, 0L, 1 );
DEFINE_STRING( string1366___r4_output_6_10_3, string1366___r4_output_6_10_31383, "...)", 4 );
DEFINE_STRING( string1365___r4_output_6_10_3, string1365___r4_output_6_10_31384, "... )", 5 );
DEFINE_STRING( string1364___r4_output_6_10_3, string1364___r4_output_6_10_31385, "... }", 5 );
DEFINE_STRING( string1363___r4_output_6_10_3, string1363___r4_output_6_10_31386, ">", 1 );
DEFINE_STRING( string1362___r4_output_6_10_3, string1362___r4_output_6_10_31387, "#<cell:", 7 );
DEFINE_STRING( string1361___r4_output_6_10_3, string1361___r4_output_6_10_31388, "...", 3 );
DEFINE_EXPORT_PROCEDURE( set_printer__env_75___r4_output_6_10_3, _set_printer_1360_246___r4_output_6_10_31389, _set_printer_1360_246___r4_output_6_10_3, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( display__env_163___r4_output_6_10_3, _display__37___r4_output_6_10_31390, va_generic_entry, _display__37___r4_output_6_10_3, -1 );


/* module-initialization */obj_t module_initialization_70___r4_output_6_10_3(long checksum_1133, char * from_1134)
{
if(CBOOL(require_initialization_114___r4_output_6_10_3)){
require_initialization_114___r4_output_6_10_3 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_output_6_10_3();
method_init_76___r4_output_6_10_3();
toplevel_init_63___r4_output_6_10_3();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___r4_output_6_10_3()
{
_max_length_write__149___r4_output_6_10_3 = ((long)-1);
_displayed__5___r4_output_6_10_3 = ((long)0);
_current_printer__39___r4_output_6_10_3 = BUNSPEC;
return (_current_printer__39___r4_output_6_10_3 = native_display_env_3___r4_output_6_10_3,
BUNSPEC);
}


/* set-write-length! */obj_t set_write_length__244___r4_output_6_10_3(long length_1)
{
return (_max_length_write__149___r4_output_6_10_3 = length_1,
BUNSPEC);
}


/* _set-write-length!1356 */obj_t _set_write_length_1356_70___r4_output_6_10_3(obj_t env_1072, obj_t length_1073)
{
return set_write_length__244___r4_output_6_10_3((long)CINT(length_1073));
}


/* get-write-length */long get_write_length_193___r4_output_6_10_3()
{
{
bool_t test1021_813;
{
obj_t obj_814;
obj_814 = BINT(_max_length_write__149___r4_output_6_10_3);
test1021_813 = INTEGERP(obj_814);
}
if(test1021_813){
return _max_length_write__149___r4_output_6_10_3;
}
 else {
return ((long)-1);
}
}
}


/* _get-write-length */obj_t _get_write_length_196___r4_output_6_10_3(obj_t env_1074)
{
{
long aux_1146;
aux_1146 = get_write_length_193___r4_output_6_10_3();
return BINT(aux_1146);
}
}


/* newline */obj_t newline___r4_output_6_10_3(obj_t port_2)
{
{
unsigned char aux_1149;
{
obj_t aux_1150;
{
bool_t test_1151;
if(PAIRP(port_2)){
bool_t test_1154;
{
obj_t aux_1155;
aux_1155 = CAR(port_2);
test_1154 = OUTPUT_PORTP(aux_1155);
}
if(test_1154){
test_1151 = ((bool_t)0);
}
 else {
test_1151 = ((bool_t)1);
}
}
 else {
test_1151 = ((bool_t)1);
}
if(test_1151){
aux_1150 = current_output_port;
}
 else {
aux_1150 = CAR(port_2);
}
}
aux_1149 = WRITE_CHAR(((unsigned char)'\n'), aux_1150);
}
return BCHAR(aux_1149);
}
}


/* _newline */obj_t _newline___r4_output_6_10_3(obj_t env_1075, obj_t port_1076)
{
return newline___r4_output_6_10_3(port_1076);
}


/* display */obj_t display___r4_output_6_10_3(obj_t obj_3, obj_t port_4)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
bool_t test1027_446;
{
bool_t test1047_488;
{
obj_t obj1_819;
obj1_819 = _current_printer__39___r4_output_6_10_3;
test1047_488 = (obj1_819==native_display_env_3___r4_output_6_10_3);
}
if(test1047_488){
test1027_446 = ((bool_t)1);
}
 else {
bool_t test1048_489;
{
obj_t obj_820;
obj_820 = _current_printer__39___r4_output_6_10_3;
test1048_489 = PROCEDUREP(obj_820);
}
if(test1048_489){
test1027_446 = ((bool_t)0);
}
 else {
test1027_446 = ((bool_t)1);
}
}
}
if(test1027_446){
obj_t aux_1167;
{
bool_t test_1168;
if(PAIRP(port_4)){
bool_t test_1171;
{
obj_t aux_1172;
aux_1172 = CAR(port_4);
test_1171 = OUTPUT_PORTP(aux_1172);
}
if(test_1171){
test_1168 = ((bool_t)0);
}
 else {
test_1168 = ((bool_t)1);
}
}
 else {
test_1168 = ((bool_t)1);
}
if(test_1168){
aux_1167 = current_output_port;
}
 else {
aux_1167 = CAR(port_4);
}
}
return write_display_159___r4_output_6_10_3(obj_3, aux_1167, ((bool_t)1));
}
 else {
obj_t armed1010_452;
armed1010_452 = MAKE_CELL(BUNSPEC);
{
obj_t body1009_1078;
obj_t rhandler1007_1080;
body1009_1078 = make_fx_procedure(body1009___r4_output_6_10_3, ((long)0), ((long)2));
rhandler1007_1080 = make_fx_procedure(rhandler1007___r4_output_6_10_3, ((long)4), ((long)1));
PROCEDURE_SET(body1009_1078, ((long)0), port_4);
PROCEDURE_SET(body1009_1078, ((long)1), obj_3);
PROCEDURE_SET(rhandler1007_1080, ((long)0), armed1010_452);
CELL_SET(armed1010_452, BTRUE);
return handling_function1033___r4_output_6_10_3(body1009_1078, rhandler1007_1080, armed1010_452);
}
}
}
}


/* handling_function1033 */obj_t handling_function1033___r4_output_6_10_3(obj_t body1009_1131, obj_t rhandler1007_1130, obj_t armed1010_1129)
{
jmp_buf jmpbuf;
obj_t an_exit1011_457;
if( SET_EXIT(an_exit1011_457) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1011_457 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1011_457, ((bool_t)1));
{
obj_t an_exitd1012_458;
an_exitd1012_458 = exitd_top;
{
obj_t escape_1079;
escape_1079 = make_fx_procedure(escape___r4_output_6_10_3, ((long)1), ((long)1));
PROCEDURE_SET(escape_1079, ((long)0), an_exitd1012_458);
{
obj_t res1014_461;
{
obj_t arg1035_1077;
obj_t arg1034_1081;
arg1035_1077 = make_fx_procedure(arg1035___r4_output_6_10_3, ((long)0), ((long)1));
arg1034_1081 = make_fx_procedure(arg1034___r4_output_6_10_3, ((long)0), ((long)4));
PROCEDURE_SET(arg1035_1077, ((long)0), armed1010_1129);
PROCEDURE_SET(arg1034_1081, ((long)0), an_exitd1012_458);
PROCEDURE_SET(arg1034_1081, ((long)1), armed1010_1129);
PROCEDURE_SET(arg1034_1081, ((long)2), rhandler1007_1130);
PROCEDURE_SET(arg1034_1081, ((long)3), escape_1079);
res1014_461 = dynamic_wind_31___r4_control_features_6_9(arg1034_1081, body1009_1131, arg1035_1077);
}
POP_EXIT();
return res1014_461;
}
}
}
}
}
}


/* _display */obj_t _display___r4_output_6_10_3(obj_t env_1082, obj_t obj_1083, obj_t port_1084)
{
return display___r4_output_6_10_3(obj_1083, port_1084);
}


/* arg1035 */obj_t arg1035___r4_output_6_10_3(obj_t env_1085)
{
{
obj_t armed1010_1086;
armed1010_1086 = PROCEDURE_REF(env_1085, ((long)0));
{
{
bool_t test_1199;
{
obj_t aux_1200;
aux_1200 = CELL_REF(armed1010_1086);
test_1199 = CBOOL(aux_1200);
}
if(test_1199){
CELL_SET(armed1010_1086, BFALSE);
return remove_error_handler__102___error();
}
 else {
return BUNSPEC;
}
}
}
}
}


/* body1009 */obj_t body1009___r4_output_6_10_3(obj_t env_1088)
{
{
obj_t port_1089;
obj_t obj_1090;
port_1089 = PROCEDURE_REF(env_1088, ((long)0));
obj_1090 = PROCEDURE_REF(env_1088, ((long)1));
{
{
obj_t aux_1205;
{
bool_t test_1206;
if(PAIRP(port_1089)){
bool_t test_1209;
{
obj_t aux_1210;
aux_1210 = CAR(port_1089);
test_1209 = OUTPUT_PORTP(aux_1210);
}
if(test_1209){
test_1206 = ((bool_t)0);
}
 else {
test_1206 = ((bool_t)1);
}
}
 else {
test_1206 = ((bool_t)1);
}
if(test_1206){
aux_1205 = current_output_port;
}
 else {
aux_1205 = CAR(port_1089);
}
}
return PROCEDURE_ENTRY(_current_printer__39___r4_output_6_10_3)(_current_printer__39___r4_output_6_10_3, obj_1090, aux_1205, BEOA);
}
}
}
}


/* arg1034 */obj_t arg1034___r4_output_6_10_3(obj_t env_1091)
{
{
obj_t rhandler1007_1094;
obj_t escape_1095;
rhandler1007_1094 = PROCEDURE_REF(env_1091, ((long)2));
escape_1095 = PROCEDURE_REF(env_1091, ((long)3));
{
return add_error_handler__155___error(rhandler1007_1094, escape_1095);
}
}
}


/* escape */obj_t escape___r4_output_6_10_3(obj_t env_1096, obj_t val1013_1098)
{
{
obj_t an_exitd1012_1097;
an_exitd1012_1097 = PROCEDURE_REF(env_1096, ((long)0));
{
obj_t val1013_459;
val1013_459 = val1013_1098;
return unwind_until__178___bexit(an_exitd1012_1097, val1013_459);
}
}
}


/* rhandler1007 */obj_t rhandler1007___r4_output_6_10_3(obj_t env_1099, obj_t esc_1101, obj_t obj_1102, obj_t proc_1103, obj_t msg_1104)
{
{
obj_t armed1010_1100;
armed1010_1100 = PROCEDURE_REF(env_1099, ((long)0));
{
obj_t esc_474;
obj_t obj_475;
obj_t proc_476;
obj_t msg_477;
esc_474 = esc_1101;
obj_475 = obj_1102;
proc_476 = proc_1103;
msg_477 = msg_1104;
CELL_SET(armed1010_1100, BFALSE);
remove_error_handler__102___error();
_current_printer__39___r4_output_6_10_3 = native_display_env_3___r4_output_6_10_3;
FAILURE(obj_475,proc_476,msg_477);}
}
}


/* native-display */obj_t native_display_62___r4_output_6_10_3(obj_t obj_5, obj_t port_6)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
obj_t aux_1224;
{
bool_t test_1225;
if(PAIRP(port_6)){
bool_t test_1228;
{
obj_t aux_1229;
aux_1229 = CAR(port_6);
test_1228 = OUTPUT_PORTP(aux_1229);
}
if(test_1228){
test_1225 = ((bool_t)0);
}
 else {
test_1225 = ((bool_t)1);
}
}
 else {
test_1225 = ((bool_t)1);
}
if(test_1225){
aux_1224 = current_output_port;
}
 else {
aux_1224 = CAR(port_6);
}
}
return write_display_159___r4_output_6_10_3(obj_5, aux_1224, ((bool_t)1));
}
}


/* _native-display */obj_t _native_display_199___r4_output_6_10_3(obj_t env_1069, obj_t obj_1070, obj_t port_1071)
{
return native_display_62___r4_output_6_10_3(obj_1070, port_1071);
}


/* write */obj_t write___r4_output_6_10_3(obj_t obj_7, obj_t port_8)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
obj_t aux_1235;
{
bool_t test_1236;
if(PAIRP(port_8)){
bool_t test_1239;
{
obj_t aux_1240;
aux_1240 = CAR(port_8);
test_1239 = OUTPUT_PORTP(aux_1240);
}
if(test_1239){
test_1236 = ((bool_t)0);
}
 else {
test_1236 = ((bool_t)1);
}
}
 else {
test_1236 = ((bool_t)1);
}
if(test_1236){
aux_1235 = current_output_port;
}
 else {
aux_1235 = CAR(port_8);
}
}
return write_display_159___r4_output_6_10_3(obj_7, aux_1235, ((bool_t)0));
}
}


/* _write */obj_t _write___r4_output_6_10_3(obj_t env_1107, obj_t obj_1108, obj_t port_1109)
{
return write___r4_output_6_10_3(obj_1108, port_1109);
}


/* write-char */obj_t write_char_165___r4_output_6_10_3(unsigned char char_9, obj_t port_10)
{
{
unsigned char aux_1246;
{
obj_t aux_1247;
{
bool_t test_1248;
if(PAIRP(port_10)){
bool_t test_1251;
{
obj_t aux_1252;
aux_1252 = CAR(port_10);
test_1251 = OUTPUT_PORTP(aux_1252);
}
if(test_1251){
test_1248 = ((bool_t)0);
}
 else {
test_1248 = ((bool_t)1);
}
}
 else {
test_1248 = ((bool_t)1);
}
if(test_1248){
aux_1247 = current_output_port;
}
 else {
aux_1247 = CAR(port_10);
}
}
aux_1246 = WRITE_CHAR(char_9, aux_1247);
}
return BCHAR(aux_1246);
}
}


/* _write-char1357 */obj_t _write_char1357_135___r4_output_6_10_3(obj_t env_1110, obj_t char_1111, obj_t port_1112)
{
return write_char_165___r4_output_6_10_3((unsigned char)CCHAR(char_1111), port_1112);
}


/* illegal-char-rep */obj_t illegal_char_rep_197___r4_output_6_10_3(unsigned char char_11)
{
return ill_char_rep(char_11);
}


/* _illegal-char-rep1358 */obj_t _illegal_char_rep1358_34___r4_output_6_10_3(obj_t env_1113, obj_t char_1114)
{
{
unsigned char char_166_1132;
char_166_1132 = (unsigned char)CCHAR(char_1114);
return ill_char_rep(char_166_1132);
}
}


/* write/display */obj_t write_display_159___r4_output_6_10_3(obj_t obj_12, obj_t port_13, bool_t flag_14)
{
{
long z2_863;
z2_863 = _displayed__5___r4_output_6_10_3;
_displayed__5___r4_output_6_10_3 = (((long)1)+z2_863);
}
{
bool_t test1064_505;
{
bool_t test1080_521;
{
obj_t obj_864;
obj_864 = BINT(_max_length_write__149___r4_output_6_10_3);
test1080_521 = INTEGERP(obj_864);
}
if(test1080_521){
bool_t test1081_522;
{
long n1_865;
n1_865 = _max_length_write__149___r4_output_6_10_3;
test1081_522 = (n1_865>((long)0));
}
if(test1081_522){
long n1_867;
long n2_868;
n1_867 = _displayed__5___r4_output_6_10_3;
n2_868 = _max_length_write__149___r4_output_6_10_3;
test1064_505 = (n1_867>=n2_868);
}
 else {
test1064_505 = ((bool_t)0);
}
}
 else {
test1064_505 = ((bool_t)0);
}
}
if(test1064_505){
display_string(string1361___r4_output_6_10_3, port_13);
}
 else {
if(INTEGERP(obj_12)){
display_fixnum(obj_12, port_13);
}
 else {
if(CHARP(obj_12)){
if(flag_14){
display_char(obj_12, port_13);
}
 else {
write_char(obj_12, port_13);
}
}
 else {
if(UCS2P(obj_12)){
if(flag_14){
display_ucs2(obj_12, port_13);
}
 else {
write_ucs2(obj_12, port_13);
}
}
 else {
if(STRINGP(obj_12)){
if(flag_14){
display_string(obj_12, port_13);
}
 else {
obj_t arg1069_510;
arg1069_510 = string_for_read(obj_12);
write_string(arg1069_510, port_13);
}
}
 else {
if(VECTORP(obj_12)){
write_display_vector_76___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
if(PAIRP(obj_12)){
write_display_pair_103___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
if(REALP(obj_12)){
display_flonum(obj_12, port_13);
}
 else {
if(CELLP(obj_12)){
display_string(string1362___r4_output_6_10_3, port_13);
{
obj_t arg1082_880;
arg1082_880 = CELL_REF(obj_12);
write_display_159___r4_output_6_10_3(arg1082_880, port_13, flag_14);
}
display_string(string1363___r4_output_6_10_3, port_13);
}
 else {
if(STRUCTP(obj_12)){
write_display_structure_107___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
if(TVECTORP(obj_12)){
write_display_tvector_50___r4_output_6_10_3(obj_12, port_13, flag_14);
}
 else {
bool_t test1076_517;
test1076_517 = (POINTERP( obj_12 ) && (TYPE( obj_12 ) >= OBJECT_TYPE));
if(test1076_517){
if(flag_14){
obj_t list1123_887;
list1123_887 = MAKE_PAIR(port_13, BNIL);
object_display_243___object((object_t)(obj_12), list1123_887);
}
 else {
obj_t list1125_889;
list1125_889 = MAKE_PAIR(port_13, BNIL);
object_write_132___object((object_t)(obj_12), list1125_889);
}
}
 else {
if(UCS2_STRINGP(obj_12)){
if(flag_14){
display_ucs2string(obj_12, port_13);
}
 else {
obj_t arg1078_519;
{
obj_t arg1079_520;
arg1079_520 = ucs2_string_to_utf8_string(obj_12);
arg1078_519 = string_for_read(arg1079_520);
}
write_utf8string(arg1078_519, port_13);
}
}
 else {
write_object(obj_12, port_13);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
return BUNSPEC;
}


/* write/display-structure */obj_t write_display_structure_107___r4_output_6_10_3(obj_t obj_18, obj_t port_19, bool_t flag_20)
{
WRITE_CHAR(((unsigned char)'#'), port_19);
WRITE_CHAR(((unsigned char)'{'), port_19);
{
obj_t aux_1331;
aux_1331 = STRUCT_KEY(obj_18);
write_object(aux_1331, port_19);
}
{
bool_t test_1334;
{
long aux_1335;
aux_1335 = STRUCT_LENGTH(obj_18);
test_1334 = (((long)0)==aux_1335);
}
if(test_1334){
unsigned char aux_1338;
aux_1338 = WRITE_CHAR(((unsigned char)'}'), port_19);
return BCHAR(aux_1338);
}
 else {
long len_526;
{
long aux_1341;
aux_1341 = STRUCT_LENGTH(obj_18);
len_526 = (aux_1341-((long)1));
}
WRITE_CHAR(((unsigned char)' '), port_19);
{
long i_527;
i_527 = ((long)0);
loop_528:
{
bool_t test1085_529;
{
bool_t test1090_534;
{
obj_t obj_902;
obj_902 = BINT(_max_length_write__149___r4_output_6_10_3);
test1090_534 = INTEGERP(obj_902);
}
if(test1090_534){
bool_t test1091_535;
{
long n1_903;
n1_903 = _max_length_write__149___r4_output_6_10_3;
test1091_535 = (n1_903>((long)0));
}
if(test1091_535){
long n1_905;
long n2_906;
n1_905 = _displayed__5___r4_output_6_10_3;
n2_906 = _max_length_write__149___r4_output_6_10_3;
test1085_529 = (n1_905>n2_906);
}
 else {
test1085_529 = ((bool_t)0);
}
}
 else {
test1085_529 = ((bool_t)0);
}
}
if(test1085_529){
return write_object(string1364___r4_output_6_10_3, port_19);
}
 else {
if((i_527==len_526)){
write_display_159___r4_output_6_10_3(STRUCT_REF(obj_18, i_527), port_19, flag_20);
{
unsigned char aux_1357;
aux_1357 = WRITE_CHAR(((unsigned char)'}'), port_19);
return BCHAR(aux_1357);
}
}
 else {
write_display_159___r4_output_6_10_3(STRUCT_REF(obj_18, i_527), port_19, flag_20);
WRITE_CHAR(((unsigned char)' '), port_19);
{
long i_1363;
i_1363 = (((long)1)+i_527);
i_527 = i_1363;
goto loop_528;
}
}
}
}
}
}
}
}


/* write/display-vector */obj_t write_display_vector_76___r4_output_6_10_3(obj_t obj_21, obj_t port_22, bool_t flag_23)
{
WRITE_CHAR(((unsigned char)'#'), port_22);
{
long tag_540;
tag_540 = VECTOR_TAG(obj_21);
if((tag_540>((long)0))){
if((tag_540>=((long)100))){
obj_t aux_1371;
aux_1371 = BINT(tag_540);
write_object(aux_1371, port_22);
}
 else {
WRITE_CHAR(((unsigned char)'0'), port_22);
if((tag_540>=((long)10))){
obj_t aux_1377;
aux_1377 = BINT(tag_540);
write_object(aux_1377, port_22);
}
 else {
WRITE_CHAR(((unsigned char)'0'), port_22);
{
obj_t aux_1381;
aux_1381 = BINT(tag_540);
write_object(aux_1381, port_22);
}
}
}
}
 else {
BUNSPEC;
}
}
WRITE_CHAR(((unsigned char)'('), port_22);
{
bool_t test_1385;
{
long aux_1386;
aux_1386 = VECTOR_LENGTH(obj_21);
test_1385 = (((long)0)==aux_1386);
}
if(test_1385){
unsigned char aux_1389;
aux_1389 = WRITE_CHAR(((unsigned char)')'), port_22);
return BCHAR(aux_1389);
}
 else {
long len_545;
{
long aux_1392;
aux_1392 = VECTOR_LENGTH(obj_21);
len_545 = (aux_1392-((long)1));
}
{
long i_546;
i_546 = ((long)0);
loop_547:
{
bool_t test1100_548;
{
bool_t test1105_553;
{
obj_t obj_928;
obj_928 = BINT(_max_length_write__149___r4_output_6_10_3);
test1105_553 = INTEGERP(obj_928);
}
if(test1105_553){
bool_t test1106_554;
{
long n1_929;
n1_929 = _max_length_write__149___r4_output_6_10_3;
test1106_554 = (n1_929>((long)0));
}
if(test1106_554){
long n1_931;
long n2_932;
n1_931 = _displayed__5___r4_output_6_10_3;
n2_932 = _max_length_write__149___r4_output_6_10_3;
test1100_548 = (n1_931>=n2_932);
}
 else {
test1100_548 = ((bool_t)0);
}
}
 else {
test1100_548 = ((bool_t)0);
}
}
if(test1100_548){
return write_object(string1365___r4_output_6_10_3, port_22);
}
 else {
if((i_546==len_545)){
write_display_159___r4_output_6_10_3(VECTOR_REF(obj_21, i_546), port_22, flag_23);
{
unsigned char aux_1407;
aux_1407 = WRITE_CHAR(((unsigned char)')'), port_22);
return BCHAR(aux_1407);
}
}
 else {
write_display_159___r4_output_6_10_3(VECTOR_REF(obj_21, i_546), port_22, flag_23);
WRITE_CHAR(((unsigned char)' '), port_22);
{
long i_1413;
i_1413 = (((long)1)+i_546);
i_546 = i_1413;
goto loop_547;
}
}
}
}
}
}
}
}


/* write/display-tvector */obj_t write_display_tvector_50___r4_output_6_10_3(obj_t tvec_24, obj_t port_25, bool_t flag_26)
{
{
obj_t tvector_ref_208_559;
obj_t id_560;
tvector_ref_208_559 = tvector_ref_208___tvector(tvec_24);
id_560 = tvector_id_255___tvector(tvec_24);
WRITE_CHAR(((unsigned char)'#'), port_25);
write_object(id_560, port_25);
WRITE_CHAR(((unsigned char)'('), port_25);
if(CBOOL(tvector_ref_208_559)){
{
bool_t test_1422;
{
long aux_1423;
aux_1423 = TVECTOR_LENGTH(tvec_24);
test_1422 = (((long)0)==aux_1423);
}
if(test_1422){
unsigned char aux_1426;
aux_1426 = WRITE_CHAR(((unsigned char)')'), port_25);
return BCHAR(aux_1426);
}
 else {
long len_562;
{
long aux_1429;
aux_1429 = TVECTOR_LENGTH(tvec_24);
len_562 = (aux_1429-((long)1));
}
{
long i_563;
i_563 = ((long)0);
loop_564:
{
bool_t test1112_565;
{
bool_t test1117_570;
{
obj_t obj_947;
obj_947 = BINT(_max_length_write__149___r4_output_6_10_3);
test1117_570 = INTEGERP(obj_947);
}
if(test1117_570){
bool_t test1118_571;
{
long n1_948;
n1_948 = _max_length_write__149___r4_output_6_10_3;
test1118_571 = (n1_948>((long)0));
}
if(test1118_571){
long n1_950;
long n2_951;
n1_950 = _displayed__5___r4_output_6_10_3;
n2_951 = _max_length_write__149___r4_output_6_10_3;
test1112_565 = (n1_950>=n2_951);
}
 else {
test1112_565 = ((bool_t)0);
}
}
 else {
test1112_565 = ((bool_t)0);
}
}
if(test1112_565){
return write_object(string1365___r4_output_6_10_3, port_25);
}
 else {
if((i_563==len_562)){
{
obj_t arg1114_567;
arg1114_567 = PROCEDURE_ENTRY(tvector_ref_208_559)(tvector_ref_208_559, tvec_24, BINT(i_563), BEOA);
write_display_159___r4_output_6_10_3(arg1114_567, port_25, flag_26);
}
{
unsigned char aux_1446;
aux_1446 = WRITE_CHAR(((unsigned char)')'), port_25);
return BCHAR(aux_1446);
}
}
 else {
{
obj_t arg1115_568;
arg1115_568 = PROCEDURE_ENTRY(tvector_ref_208_559)(tvector_ref_208_559, tvec_24, BINT(i_563), BEOA);
write_display_159___r4_output_6_10_3(arg1115_568, port_25, flag_26);
}
WRITE_CHAR(((unsigned char)' '), port_25);
{
long i_1454;
i_1454 = (((long)1)+i_563);
i_563 = i_1454;
goto loop_564;
}
}
}
}
}
}
}
}
 else {
write_object(string1366___r4_output_6_10_3, port_25);
return tvec_24;
}
}
}


/* write/display-pair */obj_t write_display_pair_103___r4_output_6_10_3(obj_t obj_30, obj_t port_31, bool_t flag_32)
{
WRITE_CHAR(((unsigned char)'('), port_31);
{
obj_t l_580;
l_580 = obj_30;
loop_581:
{
bool_t test_1458;
{
obj_t aux_1459;
aux_1459 = CDR(l_580);
test_1458 = NULLP(aux_1459);
}
if(test_1458){
write_display_159___r4_output_6_10_3(CAR(l_580), port_31, flag_32);
{
unsigned char aux_1464;
aux_1464 = WRITE_CHAR(((unsigned char)')'), port_31);
return BCHAR(aux_1464);
}
}
 else {
bool_t test1129_584;
{
bool_t test1136_591;
{
obj_t obj_963;
obj_963 = BINT(_max_length_write__149___r4_output_6_10_3);
test1136_591 = INTEGERP(obj_963);
}
if(test1136_591){
bool_t test1137_592;
{
long n1_964;
n1_964 = _max_length_write__149___r4_output_6_10_3;
test1137_592 = (n1_964>((long)0));
}
if(test1137_592){
long n1_966;
long n2_967;
n1_966 = _displayed__5___r4_output_6_10_3;
n2_967 = _max_length_write__149___r4_output_6_10_3;
test1129_584 = (n1_966>=n2_967);
}
 else {
test1129_584 = ((bool_t)0);
}
}
 else {
test1129_584 = ((bool_t)0);
}
}
if(test1129_584){
return write_object(string1367___r4_output_6_10_3, port_31);
}
 else {
bool_t test_1475;
{
obj_t aux_1476;
aux_1476 = CDR(l_580);
test_1475 = PAIRP(aux_1476);
}
if(test_1475){
write_display_159___r4_output_6_10_3(CAR(l_580), port_31, flag_32);
WRITE_CHAR(((unsigned char)' '), port_31);
{
obj_t l_1482;
l_1482 = CDR(l_580);
l_580 = l_1482;
goto loop_581;
}
}
 else {
write_display_159___r4_output_6_10_3(CAR(l_580), port_31, flag_32);
WRITE_CHAR(((unsigned char)' '), port_31);
WRITE_CHAR(((unsigned char)'.'), port_31);
WRITE_CHAR(((unsigned char)' '), port_31);
write_display_159___r4_output_6_10_3(CDR(l_580), port_31, flag_32);
{
unsigned char aux_1491;
aux_1491 = WRITE_CHAR(((unsigned char)')'), port_31);
return BCHAR(aux_1491);
}
}
}
}
}
}
}


/* print */obj_t print___r4_output_6_10_3(obj_t obj_33)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
obj_t l_975;
obj_t res_976;
l_975 = obj_33;
res_976 = BNIL;
loop_974:
if(NULLP(l_975)){
WRITE_CHAR(((unsigned char)'\n'), current_output_port);
return res_976;
}
 else {
obj_t v_981;
v_981 = CAR(l_975);
write_display_159___r4_output_6_10_3(v_981, current_output_port, ((bool_t)1));
{
obj_t res_1501;
obj_t l_1499;
l_1499 = CDR(l_975);
res_1501 = v_981;
res_976 = res_1501;
l_975 = l_1499;
goto loop_974;
}
}
}
}


/* _print */obj_t _print___r4_output_6_10_3(obj_t env_1115, obj_t obj_1116)
{
return print___r4_output_6_10_3(obj_1116);
}


/* display* */obj_t display__75___r4_output_6_10_3(obj_t obj_34)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
obj_t l_603;
l_603 = obj_34;
loop_604:
if(NULLP(l_603)){
return BUNSPEC;
}
 else {
{
obj_t arg1144_607;
arg1144_607 = CAR(l_603);
{
obj_t list1145_608;
list1145_608 = MAKE_PAIR(current_output_port, BNIL);
display___r4_output_6_10_3(arg1144_607, list1145_608);
}
}
{
obj_t l_1508;
l_1508 = CDR(l_603);
l_603 = l_1508;
goto loop_604;
}
}
}
}


/* _display* */obj_t _display__37___r4_output_6_10_3(obj_t env_1117, obj_t obj_1118)
{
return display__75___r4_output_6_10_3(obj_1118);
}


/* write* */obj_t write__14___r4_output_6_10_3(obj_t obj_35)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
obj_t l_612;
l_612 = obj_35;
loop_613:
if(NULLP(l_612)){
return BUNSPEC;
}
 else {
write_display_159___r4_output_6_10_3(CAR(l_612), current_output_port, ((bool_t)0));
{
obj_t l_1515;
l_1515 = CDR(l_612);
l_612 = l_1515;
goto loop_613;
}
}
}
}


/* _write* */obj_t _write__154___r4_output_6_10_3(obj_t env_1119, obj_t obj_1120)
{
return write__14___r4_output_6_10_3(obj_1120);
}


/* fprint */obj_t fprint___r4_output_6_10_3(obj_t port_36, obj_t obj_37)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
{
obj_t l_1009;
obj_t res_1010;
l_1009 = obj_37;
res_1010 = BNIL;
loop_1008:
if(NULLP(l_1009)){
WRITE_CHAR(((unsigned char)'\n'), port_36);
return res_1010;
}
 else {
obj_t v_1016;
v_1016 = CAR(l_1009);
write_display_159___r4_output_6_10_3(v_1016, port_36, ((bool_t)1));
{
obj_t res_1525;
obj_t l_1523;
l_1523 = CDR(l_1009);
res_1525 = v_1016;
res_1010 = res_1525;
l_1009 = l_1523;
goto loop_1008;
}
}
}
}


/* _fprint1359 */obj_t _fprint1359___r4_output_6_10_3(obj_t env_1121, obj_t port_1122, obj_t obj_1123)
{
return fprint___r4_output_6_10_3(port_1122, obj_1123);
}


/* set-printer! */obj_t set_printer__238___r4_output_6_10_3(obj_t f_38)
{
return (_current_printer__39___r4_output_6_10_3 = f_38,
BUNSPEC);
}


/* _set-printer!1360 */obj_t _set_printer_1360_246___r4_output_6_10_3(obj_t env_1124, obj_t f_1125)
{
return set_printer__238___r4_output_6_10_3(f_1125);
}


/* native-printer */obj_t native_printer_249___r4_output_6_10_3()
{
return native_display_env_3___r4_output_6_10_3;
}


/* _native-printer */obj_t _native_printer_193___r4_output_6_10_3(obj_t env_1126)
{
return native_display_env_3___r4_output_6_10_3;
}


/* c-debugging-print */obj_t dprint(obj_t obj_39)
{
_displayed__5___r4_output_6_10_3 = ((long)0);
write_display_159___r4_output_6_10_3(obj_39, current_output_port, ((bool_t)1));
WRITE_CHAR(((unsigned char)'\n'), current_output_port);
return obj_39;
}


/* _c-debugging-print */obj_t _c_debugging_print_109___r4_output_6_10_3(obj_t env_1127, obj_t obj_1128)
{
return dprint(obj_1128);
}


/* method-init */obj_t method_init_76___r4_output_6_10_3()
{
return BUNSPEC;
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_output_6_10_3()
{
module_initialization_70___error(((long)0), "__R4_OUTPUT_6_10_3");
module_initialization_70___bexit(((long)0), "__R4_OUTPUT_6_10_3");
return module_initialization_70___r4_ports_6_10_1(((long)0), "__R4_OUTPUT_6_10_3");
}

