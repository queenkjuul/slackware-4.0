/*===========================================================================*/
/*   (Cfa/type.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;


static obj_t method_init_76_cfa_type();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t tvector_optimization__143_cfa_tvector();
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t type_type_type;
extern obj_t box_ref_242_ast_node;
static obj_t type_variable__default2129_85_cfa_type(value_t, variable_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t tvec_tvector_tvector;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
static bool_t type_node___42_cfa_type(obj_t);
extern obj_t cvar_cinfo_53_cfa_info;
static obj_t _type_node__default2135_215_cfa_type(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t intern_sfun_cinfo_192_cfa_info;
static obj_t type_fun__174_cfa_type(variable_t);
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_cfa_type(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_set(long, char *);
extern obj_t module_initialization_70_cfa_tvector(long, char *);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t type_variable__242_cfa_type(value_t, variable_t);
extern obj_t let_fun_218_ast_node;
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_cfa_type();
extern obj_t scnst_cinfo_0_cfa_info;
extern obj_t app_ly_162_ast_node;
static obj_t _type_node_2549_42_cfa_type(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cfa_type();
extern obj_t get_approx_type_210_cfa_type(approx_t);
extern obj_t make_vector_app_205_cfa_info;
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_cfa_type();
static obj_t _get_approx_type2547_25_cfa_type(obj_t, obj_t);
extern obj_t _unsafe_type__146_engine_param;
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t create_vector_app_150_cfa_info;
static obj_t type_node__default2135_44_cfa_type(node_t);
static obj_t _type_settings__245_cfa_type(obj_t, obj_t);
static obj_t _type_variable_2548_249_cfa_type(obj_t, obj_t, obj_t);
extern obj_t approx_cfa_info;
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t type_node__55_cfa_type(node_t);
static obj_t _type_variable__default2129_218_cfa_type(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern type_t get_vector_item_type_88_cfa_tvector(app_t);
static obj_t set_variable_type__9_cfa_type(variable_t, type_t);
extern obj_t type_settings__207_cfa_type(obj_t);
extern obj_t sexit_cinfo_49_cfa_info;
extern obj_t svar_cinfo_166_cfa_info;
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cfa_type = BUNSPEC;
extern obj_t _vector__240_type_cache;
extern obj_t conditional_ast_node;
extern obj_t set__list_248_cfa_set(obj_t);
static obj_t cnst_init_137_cfa_type();
static obj_t __cnst[4];

DEFINE_STATIC_GENERIC(type_node__env_231_cfa_type, _type_node_2549_42_cfa_type2559, _type_node_2549_42_cfa_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(get_approx_type_env_38_cfa_type, _get_approx_type2547_25_cfa_type2560, _get_approx_type2547_25_cfa_type, 0L, 1);
DEFINE_STATIC_PROCEDURE(type_node__default2135_env_43_cfa_type, _type_node__default2135_215_cfa_type2561, _type_node__default2135_215_cfa_type, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_settings__env_8_cfa_type, _type_settings__245_cfa_type2562, _type_settings__245_cfa_type, 0L, 1);
DEFINE_STRING(string2553_cfa_type, string2553_cfa_type2563, "TYPE-NODE!-DEFAULT2135 STATIC NOTHING BIGLOO ", 45);
DEFINE_STRING(string2552_cfa_type, string2552_cfa_type2564, "No method for this object", 25);
DEFINE_STRING(string2551_cfa_type, string2551_cfa_type2565, "Unexpected closure", 18);
DEFINE_STRING(string2550_cfa_type, string2550_cfa_type2566, "type-node!", 10);
DEFINE_STATIC_GENERIC(type_variable__env_200_cfa_type, _type_variable_2548_249_cfa_type2567, _type_variable_2548_249_cfa_type, 0L, 2);
DEFINE_STATIC_PROCEDURE(type_variable__default2129_env_171_cfa_type, _type_variable__default2129_218_cfa_type2568, _type_variable__default2129_218_cfa_type, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_cfa_type(long checksum_3731, char *from_3732)
{
   if (CBOOL(require_initialization_114_cfa_type))
     {
	require_initialization_114_cfa_type = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_type();
	cnst_init_137_cfa_type();
	imported_modules_init_94_cfa_type();
	method_init_76_cfa_type();
	toplevel_init_63_cfa_type();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_type()
{
   module_initialization_70___object(((long) 0), "CFA_TYPE");
   module_initialization_70___reader(((long) 0), "CFA_TYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_type()
{
   {
      obj_t cnst_port_138_3723;
      cnst_port_138_3723 = open_input_string(string2553_cfa_type);
      {
	 long i_3724;
	 i_3724 = ((long) 3);
       loop_3725:
	 {
	    bool_t test2554_3726;
	    test2554_3726 = (i_3724 == ((long) -1));
	    if (test2554_3726)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2555_3727;
		    {
		       obj_t list2556_3728;
		       {
			  obj_t arg2557_3729;
			  arg2557_3729 = BNIL;
			  list2556_3728 = MAKE_PAIR(cnst_port_138_3723, arg2557_3729);
		       }
		       arg2555_3727 = read___reader(list2556_3728);
		    }
		    CNST_TABLE_SET(i_3724, arg2555_3727);
		 }
		 {
		    int aux_3730;
		    {
		       long aux_3749;
		       aux_3749 = (i_3724 - ((long) 1));
		       aux_3730 = (int) (aux_3749);
		    }
		    {
		       long i_3752;
		       i_3752 = (long) (aux_3730);
		       i_3724 = i_3752;
		       goto loop_3725;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_type()
{
   approx_cfa_info;
   return BUNSPEC;
}


/* type-settings! */ obj_t 
type_settings__207_cfa_type(obj_t globals_1)
{
   {
      obj_t l2095_2187;
      {
	 bool_t aux_3754;
	 l2095_2187 = globals_1;
       lname2096_2188:
	 if (PAIRP(l2095_2187))
	   {
	      {
		 variable_t aux_3757;
		 {
		    obj_t aux_3758;
		    aux_3758 = CAR(l2095_2187);
		    aux_3757 = (variable_t) (aux_3758);
		 }
		 type_fun__174_cfa_type(aux_3757);
	      }
	      {
		 obj_t l2095_3762;
		 l2095_3762 = CDR(l2095_2187);
		 l2095_2187 = l2095_3762;
		 goto lname2096_2188;
	      }
	   }
	 else
	   {
	      aux_3754 = ((bool_t) 1);
	   }
	 return BBOOL(aux_3754);
      }
   }
}


/* _type-settings! */ obj_t 
_type_settings__245_cfa_type(obj_t env_3709, obj_t globals_3710)
{
   return type_settings__207_cfa_type(globals_3710);
}


/* type-fun! */ obj_t 
type_fun__174_cfa_type(variable_t var_2)
{
   {
      value_t fun_2192;
      fun_2192 = (((variable_t) CREF(var_2))->value);
      {
	 bool_t test2160_2193;
	 test2160_2193 = is_a__118___object((obj_t) (fun_2192), intern_sfun_cinfo_192_cfa_info);
	 if (test2160_2193)
	   {
	      {
		 obj_t l2098_2195;
		 {
		    sfun_t obj_3174;
		    obj_3174 = (sfun_t) (fun_2192);
		    l2098_2195 = (((sfun_t) CREF(obj_3174))->args);
		 }
	       lname2099_2196:
		 if (PAIRP(l2098_2195))
		   {
		      {
			 obj_t var_2199;
			 var_2199 = CAR(l2098_2195);
			 {
			    value_t aux_3773;
			    {
			       local_t obj_3177;
			       obj_3177 = (local_t) (var_2199);
			       aux_3773 = (((local_t) CREF(obj_3177))->value);
			    }
			    type_variable__242_cfa_type(aux_3773, (variable_t) (var_2199));
			 }
		      }
		      {
			 obj_t l2098_3778;
			 l2098_3778 = CDR(l2098_2195);
			 l2098_2195 = l2098_3778;
			 goto lname2099_2196;
		      }
		   }
		 else
		   {
		      ((bool_t) 1);
		   }
	      }
	      {
		 node_t aux_3782;
		 {
		    obj_t aux_3783;
		    {
		       sfun_t obj_3179;
		       obj_3179 = (sfun_t) (fun_2192);
		       aux_3783 = (((sfun_t) CREF(obj_3179))->body);
		    }
		    aux_3782 = (node_t) (aux_3783);
		 }
		 type_node__55_cfa_type(aux_3782);
	      }
	      {
		 obj_t arg2166_2203;
		 {
		    approx_t aux_3788;
		    {
		       intern_sfun_cinfo_192_t obj_3180;
		       obj_3180 = (intern_sfun_cinfo_192_t) (fun_2192);
		       {
			  obj_t aux_3790;
			  {
			     object_t aux_3791;
			     aux_3791 = (object_t) (obj_3180);
			     aux_3790 = OBJECT_WIDENING(aux_3791);
			  }
			  aux_3788 = (((intern_sfun_cinfo_192_t) CREF(aux_3790))->approx);
		       }
		    }
		    arg2166_2203 = get_approx_type_210_cfa_type(aux_3788);
		 }
		 return set_variable_type__9_cfa_type(var_2, (type_t) (arg2166_2203));
	      }
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* get-approx-type */ obj_t 
get_approx_type_210_cfa_type(approx_t approx_3)
{
   {
      type_t type_2205;
      obj_t alloc_list_184_2206;
      type_2205 = (((approx_t) CREF(approx_3))->type);
      alloc_list_184_2206 = set__list_248_cfa_set((((approx_t) CREF(approx_3))->allocs));
      if (PAIRP(alloc_list_184_2206))
	{
	   bool_t test2169_2208;
	   {
	      obj_t aux_3803;
	      aux_3803 = tvector_optimization__143_cfa_tvector();
	      test2169_2208 = CBOOL(aux_3803);
	   }
	   if (test2169_2208)
	     {
		bool_t test2170_2209;
		test2170_2209 = is_a__118___object(CAR(alloc_list_184_2206), make_vector_app_205_cfa_info);
		if (test2170_2209)
		  {
		     {
			obj_t app_2210;
			app_2210 = CAR(alloc_list_184_2206);
			{
			   type_t tv_type_111_2211;
			   tv_type_111_2211 = get_vector_item_type_88_cfa_tvector((app_t) (app_2210));
			   {
			      approx_t value_approx_19_2212;
			      {
				 make_vector_app_205_t obj_3187;
				 obj_3187 = (make_vector_app_205_t) (app_2210);
				 {
				    obj_t aux_3814;
				    {
				       object_t aux_3815;
				       aux_3815 = (object_t) (obj_3187);
				       aux_3814 = OBJECT_WIDENING(aux_3815);
				    }
				    value_approx_19_2212 = (((make_vector_app_205_t) CREF(aux_3814))->value_approx_19);
				 }
			      }
			      {
				 type_t item_type_130_2213;
				 item_type_130_2213 = (((approx_t) CREF(value_approx_19_2212))->type);
				 {
				    obj_t tv_2214;
				    tv_2214 = (((type_t) CREF(item_type_130_2213))->tvector);
				    {
				       {
					  bool_t test2171_2215;
					  test2171_2215 = is_a__118___object(tv_2214, type_type_type);
					  if (test2171_2215)
					    {
					       return tv_2214;
					    }
					  else
					    {
					       return (obj_t) (type_2205);
					    }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
		else
		  {
		     bool_t test2172_2216;
		     test2172_2216 = is_a__118___object(CAR(alloc_list_184_2206), create_vector_app_150_cfa_info);
		     if (test2172_2216)
		       {
			  {
			     obj_t app_2217;
			     app_2217 = CAR(alloc_list_184_2206);
			     {
				type_t tv_type_111_2218;
				tv_type_111_2218 = get_vector_item_type_88_cfa_tvector((app_t) (app_2217));
				{
				   approx_t value_approx_19_2219;
				   {
				      create_vector_app_150_t obj_3194;
				      obj_3194 = (create_vector_app_150_t) (app_2217);
				      {
					 obj_t aux_3831;
					 {
					    object_t aux_3832;
					    aux_3832 = (object_t) (obj_3194);
					    aux_3831 = OBJECT_WIDENING(aux_3832);
					 }
					 value_approx_19_2219 = (((create_vector_app_150_t) CREF(aux_3831))->value_approx_19);
				      }
				   }
				   {
				      type_t item_type_130_2220;
				      item_type_130_2220 = (((approx_t) CREF(value_approx_19_2219))->type);
				      {
					 obj_t tv_2221;
					 tv_2221 = (((type_t) CREF(item_type_130_2220))->tvector);
					 {
					    {
					       bool_t test2173_2222;
					       test2173_2222 = is_a__118___object(tv_2221, type_type_type);
					       if (test2173_2222)
						 {
						    return tv_2221;
						 }
					       else
						 {
						    return (obj_t) (type_2205);
						 }
					    }
					 }
				      }
				   }
				}
			     }
			  }
		       }
		     else
		       {
			  return (obj_t) (type_2205);
		       }
		  }
	     }
	   else
	     {
		return (obj_t) (type_2205);
	     }
	}
      else
	{
	   return (obj_t) (type_2205);
	}
   }
}


/* _get-approx-type2547 */ obj_t 
_get_approx_type2547_25_cfa_type(obj_t env_3711, obj_t approx_3712)
{
   return get_approx_type_210_cfa_type((approx_t) (approx_3712));
}


/* set-variable-type! */ obj_t 
set_variable_type__9_cfa_type(variable_t variable_18, type_t type_19)
{
   {
      obj_t ntype_2226;
      type_t otype_2227;
      {
	 bool_t test2187_2238;
	 {
	    obj_t obj2_3199;
	    obj2_3199 = ____74_type_cache;
	    {
	       obj_t aux_3846;
	       aux_3846 = (obj_t) (type_19);
	       test2187_2238 = (aux_3846 == obj2_3199);
	    }
	 }
	 if (test2187_2238)
	   {
	      ntype_2226 = _obj__252_type_cache;
	   }
	 else
	   {
	      ntype_2226 = (obj_t) (type_19);
	   }
      }
      otype_2227 = (((variable_t) CREF(variable_18))->type);
      {
	 bool_t test2177_2228;
	 {
	    obj_t obj2_3202;
	    obj2_3202 = ____74_type_cache;
	    {
	       obj_t aux_3852;
	       aux_3852 = (obj_t) (otype_2227);
	       test2177_2228 = (aux_3852 == obj2_3202);
	    }
	 }
	 if (test2177_2228)
	   {
	      {
		 bool_t test2178_2229;
		 {
		    bool_t test2179_2230;
		    test2179_2230 = is_a__118___object((obj_t) (variable_18), global_ast_var);
		    if (test2179_2230)
		      {
			 bool_t test2180_2231;
			 {
			    obj_t aux_3859;
			    {
			       value_t aux_3860;
			       {
				  global_t obj_3204;
				  obj_3204 = (global_t) (variable_18);
				  aux_3860 = (((global_t) CREF(obj_3204))->value);
			       }
			       aux_3859 = (obj_t) (aux_3860);
			    }
			    test2180_2231 = is_a__118___object(aux_3859, fun_ast_var);
			 }
			 if (test2180_2231)
			   {
			      test2178_2229 = ((bool_t) 0);
			   }
			 else
			   {
			      if (CBOOL(_unsafe_type__146_engine_param))
				{
				   test2178_2229 = ((bool_t) 0);
				}
			      else
				{
				   bool_t test_3868;
				   {
				      obj_t aux_3872;
				      obj_t aux_3869;
				      aux_3872 = CNST_TABLE_REF(((long) 0));
				      {
					 type_t obj_3206;
					 obj_3206 = (type_t) (ntype_2226);
					 aux_3869 = (((type_t) CREF(obj_3206))->class);
				      }
				      test_3868 = (aux_3869 == aux_3872);
				   }
				   if (test_3868)
				     {
					test2178_2229 = ((bool_t) 0);
				     }
				   else
				     {
					test2178_2229 = ((bool_t) 1);
				     }
				}
			   }
		      }
		    else
		      {
			 test2178_2229 = ((bool_t) 0);
		      }
		 }
		 if (test2178_2229)
		   {
		      type_t val1092_3210;
		      val1092_3210 = (type_t) (_obj__252_type_cache);
		      return ((((variable_t) CREF(variable_18))->type) = ((type_t) val1092_3210), BUNSPEC);
		   }
		 else
		   {
		      type_t val1092_3212;
		      val1092_3212 = (type_t) (ntype_2226);
		      return ((((variable_t) CREF(variable_18))->type) = ((type_t) val1092_3212), BUNSPEC);
		   }
	      }
	   }
	 else
	   {
	      bool_t test2185_2236;
	      {
		 bool_t test2186_2237;
		 {
		    obj_t obj2_3214;
		    obj2_3214 = _vector__240_type_cache;
		    {
		       obj_t aux_3880;
		       aux_3880 = (obj_t) (otype_2227);
		       test2186_2237 = (aux_3880 == obj2_3214);
		    }
		 }
		 if (test2186_2237)
		   {
		      test2185_2236 = is_a__118___object(ntype_2226, tvec_tvector_tvector);
		   }
		 else
		   {
		      test2185_2236 = ((bool_t) 0);
		   }
	      }
	      if (test2185_2236)
		{
		   {
		      type_t val1092_3217;
		      val1092_3217 = (type_t) (ntype_2226);
		      return ((((variable_t) CREF(variable_18))->type) = ((type_t) val1092_3217), BUNSPEC);
		   }
		}
	      else
		{
		   return BFALSE;
		}
	   }
      }
   }
}


/* type-node*! */ bool_t 
type_node___42_cfa_type(obj_t node__221_43)
{
   {
      obj_t l2126_2239;
      l2126_2239 = node__221_43;
    lname2127_2240:
      if (PAIRP(l2126_2239))
	{
	   {
	      node_t aux_3890;
	      {
		 obj_t aux_3891;
		 aux_3891 = CAR(l2126_2239);
		 aux_3890 = (node_t) (aux_3891);
	      }
	      type_node__55_cfa_type(aux_3890);
	   }
	   {
	      obj_t l2126_3895;
	      l2126_3895 = CDR(l2126_2239);
	      l2126_2239 = l2126_3895;
	      goto lname2127_2240;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_cfa_type()
{
   add_generic__110___object(type_variable__env_200_cfa_type, type_variable__default2129_env_171_cfa_type);
   add_inlined_method__244___object(type_variable__env_200_cfa_type, svar_cinfo_166_cfa_info, ((long) 0));
   add_inlined_method__244___object(type_variable__env_200_cfa_type, scnst_cinfo_0_cfa_info, ((long) 1));
   add_inlined_method__244___object(type_variable__env_200_cfa_type, cvar_cinfo_53_cfa_info, ((long) 2));
   add_inlined_method__244___object(type_variable__env_200_cfa_type, sexit_cinfo_49_cfa_info, ((long) 3));
   add_inlined_method__244___object(type_variable__env_200_cfa_type, intern_sfun_cinfo_192_cfa_info, ((long) 4));
   add_generic__110___object(type_node__env_231_cfa_type, type_node__default2135_env_43_cfa_type);
   add_inlined_method__244___object(type_node__env_231_cfa_type, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(type_node__env_231_cfa_type, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(type_node__env_231_cfa_type, var_ast_node, ((long) 2));
   add_inlined_method__244___object(type_node__env_231_cfa_type, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(type_node__env_231_cfa_type, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(type_node__env_231_cfa_type, app_ast_node, ((long) 5));
   add_inlined_method__244___object(type_node__env_231_cfa_type, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(type_node__env_231_cfa_type, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(type_node__env_231_cfa_type, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(type_node__env_231_cfa_type, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(type_node__env_231_cfa_type, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(type_node__env_231_cfa_type, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(type_node__env_231_cfa_type, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(type_node__env_231_cfa_type, select_ast_node, ((long) 13));
   add_inlined_method__244___object(type_node__env_231_cfa_type, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(type_node__env_231_cfa_type, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(type_node__env_231_cfa_type, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(type_node__env_231_cfa_type, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(type_node__env_231_cfa_type, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(type_node__env_231_cfa_type, box_set__221_ast_node, ((long) 19));
   {
      long aux_3924;
      aux_3924 = add_inlined_method__244___object(type_node__env_231_cfa_type, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_3924);
   }
}


/* type-variable! */ obj_t 
type_variable__242_cfa_type(value_t value_4, variable_t variable_5)
{
   {
      obj_t method2524_3137;
      obj_t class2529_3138;
      {
	 obj_t arg2532_3135;
	 obj_t arg2533_3136;
	 {
	    object_t obj_3586;
	    obj_3586 = (object_t) (value_4);
	    {
	       obj_t pre_method_105_3587;
	       pre_method_105_3587 = PROCEDURE_REF(type_variable__env_200_cfa_type, ((long) 2));
	       if (INTEGERP(pre_method_105_3587))
		 {
		    PROCEDURE_SET(type_variable__env_200_cfa_type, ((long) 2), BUNSPEC);
		    arg2532_3135 = pre_method_105_3587;
		 }
	       else
		 {
		    long obj_class_num_177_3592;
		    obj_class_num_177_3592 = TYPE(obj_3586);
		    {
		       obj_t arg1177_3593;
		       arg1177_3593 = PROCEDURE_REF(type_variable__env_200_cfa_type, ((long) 1));
		       {
			  long arg1178_3597;
			  {
			     long arg1179_3598;
			     arg1179_3598 = OBJECT_TYPE;
			     arg1178_3597 = (obj_class_num_177_3592 - arg1179_3598);
			  }
			  arg2532_3135 = VECTOR_REF(arg1177_3593, arg1178_3597);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3603;
	    object_3603 = (object_t) (value_4);
	    {
	       long arg1180_3604;
	       {
		  long arg1181_3605;
		  long arg1182_3606;
		  arg1181_3605 = TYPE(object_3603);
		  arg1182_3606 = OBJECT_TYPE;
		  arg1180_3604 = (arg1181_3605 - arg1182_3606);
	       }
	       {
		  obj_t vector_3610;
		  vector_3610 = _classes__134___object;
		  arg2533_3136 = VECTOR_REF(vector_3610, arg1180_3604);
	       }
	    }
	 }
	 method2524_3137 = arg2532_3135;
	 class2529_3138 = arg2533_3136;
	 {
	    if (INTEGERP(method2524_3137))
	      {
		 switch ((long) CINT(method2524_3137))
		   {
		   case ((long) 0):
		      {
			 svar_cinfo_166_t value_3144;
			 value_3144 = (svar_cinfo_166_t) (value_4);
			 {
			    obj_t arg2536_3147;
			    {
			       approx_t aux_3945;
			       {
				  obj_t aux_3946;
				  {
				     object_t aux_3947;
				     aux_3947 = (object_t) (value_3144);
				     aux_3946 = OBJECT_WIDENING(aux_3947);
				  }
				  aux_3945 = (((svar_cinfo_166_t) CREF(aux_3946))->approx);
			       }
			       arg2536_3147 = get_approx_type_210_cfa_type(aux_3945);
			    }
			    return set_variable_type__9_cfa_type(variable_5, (type_t) (arg2536_3147));
			 }
		      }
		      break;
		   case ((long) 1):
		      return CNST_TABLE_REF(((long) 1));
		      break;
		   case ((long) 2):
		      {
			 cvar_cinfo_53_t value_3151;
			 value_3151 = (cvar_cinfo_53_t) (value_4);
			 {
			    obj_t arg2538_3154;
			    {
			       approx_t aux_3956;
			       {
				  obj_t aux_3957;
				  {
				     object_t aux_3958;
				     aux_3958 = (object_t) (value_3151);
				     aux_3957 = OBJECT_WIDENING(aux_3958);
				  }
				  aux_3956 = (((cvar_cinfo_53_t) CREF(aux_3957))->approx);
			       }
			       arg2538_3154 = get_approx_type_210_cfa_type(aux_3956);
			    }
			    return set_variable_type__9_cfa_type(variable_5, (type_t) (arg2538_3154));
			 }
		      }
		      break;
		   case ((long) 3):
		      return CNST_TABLE_REF(((long) 1));
		      break;
		   case ((long) 4):
		      return CNST_TABLE_REF(((long) 1));
		      break;
		   default:
		    case_else2530_3141:
		      if (PROCEDUREP(method2524_3137))
			{
			   return PROCEDURE_ENTRY(method2524_3137) (method2524_3137, (obj_t) (value_4), (obj_t) (variable_5), BEOA);
			}
		      else
			{
			   obj_t fun2442_3005;
			   fun2442_3005 = PROCEDURE_REF(type_variable__env_200_cfa_type, ((long) 0));
			   return PROCEDURE_ENTRY(fun2442_3005) (fun2442_3005, (obj_t) (value_4), (obj_t) (variable_5), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2530_3141;
	      }
	 }
      }
   }
}


/* _type-variable!2548 */ obj_t 
_type_variable_2548_249_cfa_type(obj_t env_3713, obj_t value_3714, obj_t variable_3715)
{
   return type_variable__242_cfa_type((value_t) (value_3714), (variable_t) (variable_3715));
}


/* type-variable!-default2129 */ obj_t 
type_variable__default2129_85_cfa_type(value_t value_6, variable_t variable_7)
{
   {
      bool_t test2443_3617;
      {
	 obj_t aux_3983;
	 {
	    type_t aux_3984;
	    aux_3984 = (((variable_t) CREF(variable_7))->type);
	    aux_3983 = (obj_t) (aux_3984);
	 }
	 test2443_3617 = is_a__118___object(aux_3983, type_type_type);
      }
      if (test2443_3617)
	{
	   return CNST_TABLE_REF(((long) 1));
	}
      else
	{
	   type_t arg2444_3618;
	   arg2444_3618 = get_default_type_181_type_cache();
	   return set_variable_type__9_cfa_type(variable_7, arg2444_3618);
	}
   }
}


/* _type-variable!-default2129 */ obj_t 
_type_variable__default2129_218_cfa_type(obj_t env_3716, obj_t value_3717, obj_t variable_3718)
{
   return type_variable__default2129_85_cfa_type((value_t) (value_3717), (variable_t) (variable_3718));
}


/* type-node! */ obj_t 
type_node__55_cfa_type(node_t node_20)
{
 type_node__55_cfa_type:
   {
      obj_t method2448_3015;
      obj_t class2453_3016;
      {
	 obj_t arg2456_3013;
	 obj_t arg2457_3014;
	 {
	    object_t obj_3621;
	    obj_3621 = (object_t) (node_20);
	    {
	       obj_t pre_method_105_3622;
	       pre_method_105_3622 = PROCEDURE_REF(type_node__env_231_cfa_type, ((long) 2));
	       if (INTEGERP(pre_method_105_3622))
		 {
		    PROCEDURE_SET(type_node__env_231_cfa_type, ((long) 2), BUNSPEC);
		    arg2456_3013 = pre_method_105_3622;
		 }
	       else
		 {
		    long obj_class_num_177_3627;
		    obj_class_num_177_3627 = TYPE(obj_3621);
		    {
		       obj_t arg1177_3628;
		       arg1177_3628 = PROCEDURE_REF(type_node__env_231_cfa_type, ((long) 1));
		       {
			  long arg1178_3632;
			  {
			     long arg1179_3633;
			     arg1179_3633 = OBJECT_TYPE;
			     arg1178_3632 = (obj_class_num_177_3627 - arg1179_3633);
			  }
			  arg2456_3013 = VECTOR_REF(arg1177_3628, arg1178_3632);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3638;
	    object_3638 = (object_t) (node_20);
	    {
	       long arg1180_3639;
	       {
		  long arg1181_3640;
		  long arg1182_3641;
		  arg1181_3640 = TYPE(object_3638);
		  arg1182_3641 = OBJECT_TYPE;
		  arg1180_3639 = (arg1181_3640 - arg1182_3641);
	       }
	       {
		  obj_t vector_3645;
		  vector_3645 = _classes__134___object;
		  arg2457_3014 = VECTOR_REF(vector_3645, arg1180_3639);
	       }
	    }
	 }
	 method2448_3015 = arg2456_3013;
	 class2453_3016 = arg2457_3014;
	 {
	    if (INTEGERP(method2448_3015))
	      {
		 switch ((long) CINT(method2448_3015))
		   {
		   case ((long) 0):
		      return BUNSPEC;
		      break;
		   case ((long) 1):
		      return BUNSPEC;
		      break;
		   case ((long) 2):
		      {
			 var_t node_3024;
			 node_3024 = (var_t) (node_20);
			 {
			    bool_t test2460_3026;
			    {
			       bool_t test2465_3030;
			       {
				  obj_t aux_4013;
				  {
				     variable_t aux_4014;
				     aux_4014 = (((var_t) CREF(node_3024))->variable);
				     aux_4013 = (obj_t) (aux_4014);
				  }
				  test2465_3030 = is_a__118___object(aux_4013, global_ast_var);
			       }
			       if (test2465_3030)
				 {
				    obj_t aux_4024;
				    obj_t aux_4019;
				    aux_4024 = CNST_TABLE_REF(((long) 2));
				    {
				       global_t obj_3650;
				       {
					  variable_t aux_4020;
					  aux_4020 = (((var_t) CREF(node_3024))->variable);
					  obj_3650 = (global_t) (aux_4020);
				       }
				       aux_4019 = (((global_t) CREF(obj_3650))->import);
				    }
				    test2460_3026 = (aux_4019 == aux_4024);
				 }
			       else
				 {
				    test2460_3026 = ((bool_t) 0);
				 }
			    }
			    if (test2460_3026)
			      {
				 value_t aux_4028;
				 {
				    global_t obj_3654;
				    {
				       variable_t aux_4029;
				       aux_4029 = (((var_t) CREF(node_3024))->variable);
				       obj_3654 = (global_t) (aux_4029);
				    }
				    aux_4028 = (((global_t) CREF(obj_3654))->value);
				 }
				 return type_variable__242_cfa_type(aux_4028, (((var_t) CREF(node_3024))->variable));
			      }
			    else
			      {
				 return BUNSPEC;
			      }
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 obj_t arg2472_3038;
			 {
			    obj_t aux_4035;
			    {
			       closure_t aux_4036;
			       aux_4036 = (closure_t) (node_20);
			       aux_4035 = (obj_t) (aux_4036);
			    }
			    arg2472_3038 = shape_tools_shape(aux_4035);
			 }
			 return internal_error_43_tools_error(string2550_cfa_type, string2551_cfa_type, arg2472_3038);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_3039;
			 node_3039 = (sequence_t) (node_20);
			 {
			    bool_t aux_4042;
			    aux_4042 = type_node___42_cfa_type((((sequence_t) CREF(node_3039))->nodes));
			    return BBOOL(aux_4042);
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_3042;
			 node_3042 = (app_t) (node_20);
			 {
			    bool_t aux_4047;
			    aux_4047 = type_node___42_cfa_type((((app_t) CREF(node_3042))->args));
			    return BBOOL(aux_4047);
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_3045;
			 node_3045 = (app_ly_162_t) (node_20);
			 type_node__55_cfa_type((((app_ly_162_t) CREF(node_3045))->fun));
			 {
			    node_t node_4054;
			    node_4054 = (((app_ly_162_t) CREF(node_3045))->arg);
			    node_20 = node_4054;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_3049;
			 node_3049 = (funcall_t) (node_20);
			 type_node__55_cfa_type((((funcall_t) CREF(node_3049))->fun));
			 {
			    bool_t aux_4059;
			    aux_4059 = type_node___42_cfa_type((((funcall_t) CREF(node_3049))->args));
			    return BBOOL(aux_4059);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_3053;
			 node_3053 = (pragma_t) (node_20);
			 {
			    bool_t aux_4064;
			    aux_4064 = type_node___42_cfa_type((((pragma_t) CREF(node_3053))->args));
			    return BBOOL(aux_4064);
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_3056;
			 node_3056 = (cast_t) (node_20);
			 {
			    node_t node_4069;
			    node_4069 = (((cast_t) CREF(node_3056))->arg);
			    node_20 = node_4069;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_3059;
			 node_3059 = (setq_t) (node_20);
			 type_node__55_cfa_type((((setq_t) CREF(node_3059))->value));
			 {
			    node_t node_4074;
			    {
			       var_t aux_4075;
			       aux_4075 = (((setq_t) CREF(node_3059))->var);
			       node_4074 = (node_t) (aux_4075);
			    }
			    node_20 = node_4074;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_3063;
			 node_3063 = (conditional_t) (node_20);
			 type_node__55_cfa_type((((conditional_t) CREF(node_3063))->test));
			 type_node__55_cfa_type((((conditional_t) CREF(node_3063))->true));
			 {
			    node_t node_4083;
			    node_4083 = (((conditional_t) CREF(node_3063))->false);
			    node_20 = node_4083;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_3068;
			 node_3068 = (fail_t) (node_20);
			 type_node__55_cfa_type((((fail_t) CREF(node_3068))->proc));
			 type_node__55_cfa_type((((fail_t) CREF(node_3068))->msg));
			 {
			    node_t node_4090;
			    node_4090 = (((fail_t) CREF(node_3068))->obj);
			    node_20 = node_4090;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_3073;
			 node_3073 = (select_t) (node_20);
			 type_node__55_cfa_type((((select_t) CREF(node_3073))->test));
			 {
			    obj_t l2113_3076;
			    {
			       bool_t aux_4095;
			       l2113_3076 = (((select_t) CREF(node_3073))->clauses);
			     lname2114_3077:
			       if (PAIRP(l2113_3076))
				 {
				    {
				       node_t aux_4098;
				       {
					  obj_t aux_4099;
					  {
					     obj_t aux_4100;
					     aux_4100 = CAR(l2113_3076);
					     aux_4099 = CDR(aux_4100);
					  }
					  aux_4098 = (node_t) (aux_4099);
				       }
				       type_node__55_cfa_type(aux_4098);
				    }
				    {
				       obj_t l2113_4105;
				       l2113_4105 = CDR(l2113_3076);
				       l2113_3076 = l2113_4105;
				       goto lname2114_3077;
				    }
				 }
			       else
				 {
				    aux_4095 = ((bool_t) 1);
				 }
			       return BBOOL(aux_4095);
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_3083;
			 node_3083 = (let_fun_218_t) (node_20);
			 {
			    obj_t l2116_3085;
			    l2116_3085 = (((let_fun_218_t) CREF(node_3083))->locals);
			  lname2117_3086:
			    if (PAIRP(l2116_3085))
			      {
				 {
				    variable_t aux_4112;
				    {
				       obj_t aux_4113;
				       aux_4113 = CAR(l2116_3085);
				       aux_4112 = (variable_t) (aux_4113);
				    }
				    type_fun__174_cfa_type(aux_4112);
				 }
				 {
				    obj_t l2116_4117;
				    l2116_4117 = CDR(l2116_3085);
				    l2116_3085 = l2116_4117;
				    goto lname2117_3086;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_4120;
			    node_4120 = (((let_fun_218_t) CREF(node_3083))->body);
			    node_20 = node_4120;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_3092;
			 node_3092 = (let_var_6_t) (node_20);
			 {
			    obj_t l2119_3094;
			    l2119_3094 = (((let_var_6_t) CREF(node_3092))->bindings);
			  lname2120_3095:
			    if (PAIRP(l2119_3094))
			      {
				 {
				    obj_t binding_3098;
				    binding_3098 = CAR(l2119_3094);
				    {
				       obj_t var_3099;
				       var_3099 = CAR(binding_3098);
				       {
					  node_t aux_4127;
					  {
					     obj_t aux_4128;
					     aux_4128 = CDR(binding_3098);
					     aux_4127 = (node_t) (aux_4128);
					  }
					  type_node__55_cfa_type(aux_4127);
				       }
				       {
					  value_t aux_4132;
					  {
					     local_t obj_3688;
					     obj_3688 = (local_t) (var_3099);
					     aux_4132 = (((local_t) CREF(obj_3688))->value);
					  }
					  type_variable__242_cfa_type(aux_4132, (variable_t) (var_3099));
				       }
				    }
				 }
				 {
				    obj_t l2119_4137;
				    l2119_4137 = CDR(l2119_3094);
				    l2119_3094 = l2119_4137;
				    goto lname2120_3095;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_4140;
			    node_4140 = (((let_var_6_t) CREF(node_3092))->body);
			    node_20 = node_4140;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_3104;
			 node_3104 = (set_ex_it_116_t) (node_20);
			 {
			    variable_t v_3106;
			    {
			       var_t arg2507_3108;
			       arg2507_3108 = (((set_ex_it_116_t) CREF(node_3104))->var);
			       v_3106 = (((var_t) CREF(arg2507_3108))->variable);
			    }
			    {
			       value_t aux_4145;
			       {
				  local_t obj_3693;
				  obj_3693 = (local_t) (v_3106);
				  aux_4145 = (((local_t) CREF(obj_3693))->value);
			       }
			       type_variable__242_cfa_type(aux_4145, v_3106);
			    }
			 }
			 type_node__55_cfa_type((((set_ex_it_116_t) CREF(node_3104))->body));
			 {
			    node_t node_4151;
			    {
			       var_t aux_4152;
			       aux_4152 = (((set_ex_it_116_t) CREF(node_3104))->var);
			       node_4151 = (node_t) (aux_4152);
			    }
			    node_20 = node_4151;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_3111;
			 node_3111 = (jump_ex_it_184_t) (node_20);
			 type_node__55_cfa_type((((jump_ex_it_184_t) CREF(node_3111))->exit));
			 {
			    node_t node_4158;
			    node_4158 = (((jump_ex_it_184_t) CREF(node_3111))->value);
			    node_20 = node_4158;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_3115;
			 node_3115 = (make_box_202_t) (node_20);
			 {
			    node_t node_4161;
			    node_4161 = (((make_box_202_t) CREF(node_3115))->value);
			    node_20 = node_4161;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_3118;
			 node_3118 = (box_set__221_t) (node_20);
			 {
			    node_t aux_4164;
			    {
			       var_t aux_4165;
			       aux_4165 = (((box_set__221_t) CREF(node_3118))->var);
			       aux_4164 = (node_t) (aux_4165);
			    }
			    type_node__55_cfa_type(aux_4164);
			 }
			 {
			    node_t node_4169;
			    node_4169 = (((box_set__221_t) CREF(node_3118))->value);
			    node_20 = node_4169;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_ref_242_t node_3122;
			 node_3122 = (box_ref_242_t) (node_20);
			 {
			    node_t node_4172;
			    {
			       var_t aux_4173;
			       aux_4173 = (((box_ref_242_t) CREF(node_3122))->var);
			       node_4172 = (node_t) (aux_4173);
			    }
			    node_20 = node_4172;
			    goto type_node__55_cfa_type;
			 }
		      }
		      break;
		   default:
		    case_else2454_3019:
		      if (PROCEDUREP(method2448_3015))
			{
			   return PROCEDURE_ENTRY(method2448_3015) (method2448_3015, (obj_t) (node_20), BEOA);
			}
		      else
			{
			   obj_t fun2445_3009;
			   fun2445_3009 = PROCEDURE_REF(type_node__env_231_cfa_type, ((long) 0));
			   return PROCEDURE_ENTRY(fun2445_3009) (fun2445_3009, (obj_t) (node_20), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2454_3019;
	      }
	 }
      }
   }
}


/* _type-node!2549 */ obj_t 
_type_node_2549_42_cfa_type(obj_t env_3719, obj_t node_3720)
{
   return type_node__55_cfa_type((node_t) (node_3720));
}


/* type-node!-default2135 */ obj_t 
type_node__default2135_44_cfa_type(node_t node_21)
{
   FAILURE(CNST_TABLE_REF(((long) 3)), string2552_cfa_type, (obj_t) (node_21));
}


/* _type-node!-default2135 */ obj_t 
_type_node__default2135_215_cfa_type(obj_t env_3721, obj_t node_3722)
{
   return type_node__default2135_44_cfa_type((node_t) (node_3722));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_type()
{
   module_initialization_70_type_type(((long) 0), "CFA_TYPE");
   module_initialization_70_type_cache(((long) 0), "CFA_TYPE");
   module_initialization_70_tools_shape(((long) 0), "CFA_TYPE");
   module_initialization_70_tools_error(((long) 0), "CFA_TYPE");
   module_initialization_70_engine_param(((long) 0), "CFA_TYPE");
   module_initialization_70_ast_var(((long) 0), "CFA_TYPE");
   module_initialization_70_ast_node(((long) 0), "CFA_TYPE");
   module_initialization_70_cfa_info(((long) 0), "CFA_TYPE");
   module_initialization_70_cfa_set(((long) 0), "CFA_TYPE");
   module_initialization_70_cfa_tvector(((long) 0), "CFA_TYPE");
   return module_initialization_70_tvector_tvector(((long) 0), "CFA_TYPE");
}
