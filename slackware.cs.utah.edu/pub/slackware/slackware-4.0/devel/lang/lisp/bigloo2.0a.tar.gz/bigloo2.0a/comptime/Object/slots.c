/*===========================================================================*/
/*   (Object/slots.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


extern obj_t _long__149_type_cache;
static obj_t find_assert_attr_93_object_slots(obj_t);
static obj_t method_init_76_object_slots();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t type_type_type;
static obj_t _make_class_slots_155_object_slots(obj_t, obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t _obj__252_type_cache;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_slots_205_object_slots(obj_t, obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_object_slots(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t imported_modules_init_94_object_slots();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t id__name_228_ast_ident(obj_t);
static obj_t find_virtual_attr_39_object_slots(obj_t);
static obj_t library_modules_init_112_object_slots();
static obj_t find_default_attr_77_object_slots(obj_t);
static obj_t toplevel_init_63_object_slots();
extern obj_t open_input_string(obj_t);
extern obj_t class_object_class;
extern obj_t _case_sensitive__90_engine_param;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t scheme_symbol__c_string_183_object_slots(obj_t);
static obj_t ensure_type_defined__128_object_slots(type_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_object_slots = BUNSPEC;
static obj_t cnst_init_137_object_slots();
static obj_t __cnst[12];

DEFINE_EXPORT_PROCEDURE(make_class_slots_env_76_object_slots, _make_class_slots_155_object_slots1709, _make_class_slots_155_object_slots, 0L, 3);
DEFINE_STRING(string1699_object_slots, string1699_object_slots1710, "illegal virtual slot (missing getter)", 37);
DEFINE_STRING(string1698_object_slots, string1698_object_slots1711, "Unknown class slot type", 23);
DEFINE_STRING(string1697_object_slots, string1697_object_slots1712, "Parse error", 11);
DEFINE_STRING(string1696_object_slots, string1696_object_slots1713, "Can't find type definition", 26);
DEFINE_STRING(string1703_object_slots, string1703_object_slots1714, "SET GET ASSERT LAMBDA (#f . #unspecified) DEFAULT + ID * -LEN READ-ONLY SLOT ", 77);
DEFINE_STRING(string1702_object_slots, string1702_object_slots1715, "virtual slot can't be indexed", 29);
DEFINE_STRING(string1701_object_slots, string1701_object_slots1716, "illegal virtual slot (missing setter)", 37);
DEFINE_STRING(string1700_object_slots, string1700_object_slots1717, "illegal virtual slot (read-only)", 32);


/* module-initialization */ obj_t 
module_initialization_70_object_slots(long checksum_2065, char *from_2066)
{
   if (CBOOL(require_initialization_114_object_slots))
     {
	require_initialization_114_object_slots = BBOOL(((bool_t) 0));
	library_modules_init_112_object_slots();
	cnst_init_137_object_slots();
	imported_modules_init_94_object_slots();
	method_init_76_object_slots();
	toplevel_init_63_object_slots();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_slots()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_SLOTS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_SLOTS");
   module_initialization_70___object(((long) 0), "OBJECT_SLOTS");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_SLOTS");
   module_initialization_70___reader(((long) 0), "OBJECT_SLOTS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_slots()
{
   {
      obj_t cnst_port_138_2057;
      cnst_port_138_2057 = open_input_string(string1703_object_slots);
      {
	 long i_2058;
	 i_2058 = ((long) 11);
       loop_2059:
	 {
	    bool_t test1704_2060;
	    test1704_2060 = (i_2058 == ((long) -1));
	    if (test1704_2060)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1705_2061;
		    {
		       obj_t list1706_2062;
		       {
			  obj_t arg1707_2063;
			  arg1707_2063 = BNIL;
			  list1706_2062 = MAKE_PAIR(cnst_port_138_2057, arg1707_2063);
		       }
		       arg1705_2061 = read___reader(list1706_2062);
		    }
		    CNST_TABLE_SET(i_2058, arg1705_2061);
		 }
		 {
		    int aux_2064;
		    {
		       long aux_2086;
		       aux_2086 = (i_2058 - ((long) 1));
		       aux_2064 = (int) (aux_2086);
		    }
		    {
		       long i_2089;
		       i_2089 = (long) (aux_2064);
		       i_2058 = i_2089;
		       goto loop_2059;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_slots()
{
   return BUNSPEC;
}


/* ensure-type-defined! */ obj_t 
ensure_type_defined__128_object_slots(type_t type_63, obj_t src_64)
{
   if ((((type_t) CREF(type_63))->init__47))
     {
	return BUNSPEC;
     }
   else
     {
	return user_error_151_tools_error(string1696_object_slots, (((type_t) CREF(type_63))->id), src_64, BNIL);
     }
}


/* make-class-slots */ obj_t 
make_class_slots_205_object_slots(obj_t slots_65, obj_t super_66, obj_t src_67)
{
   {
      obj_t slots_803;
      obj_t slot_818;
      obj_t slot_list_182_819;
      {
	 obj_t slots_470;
	 obj_t res_471;
	 {
	    obj_t arg1238_473;
	    {
	       bool_t test1239_474;
	       test1239_474 = is_a__118___object(super_66, type_type_type);
	       if (test1239_474)
		 {
		    bool_t test1240_475;
		    test1240_475 = is_a__118___object(super_66, class_object_class);
		    if (test1240_475)
		      {
			 {
			    obj_t aux_2099;
			    {
			       class_t obj_1209;
			       obj_1209 = (class_t) (super_66);
			       {
				  obj_t aux_2101;
				  {
				     object_t aux_2102;
				     aux_2102 = (object_t) (obj_1209);
				     aux_2101 = OBJECT_WIDENING(aux_2102);
				  }
				  aux_2099 = (((class_t) CREF(aux_2101))->slots);
			       }
			    }
			    arg1238_473 = reverse___r4_pairs_and_lists_6_3(aux_2099);
			 }
		      }
		    else
		      {
			 arg1238_473 = BNIL;
		      }
		 }
	       else
		 {
		    arg1238_473 = BNIL;
		 }
	    }
	    slots_470 = slots_65;
	    res_471 = arg1238_473;
	  loop_472:
	    if (NULLP(slots_470))
	      {
		 slots_803 = res_471;
		 {
		    obj_t slots_805;
		    obj_t res_806;
		    slots_805 = slots_803;
		    res_806 = BNIL;
		  loop_807:
		    if (NULLP(slots_805))
		      {
			 return res_806;
		      }
		    else
		      {
			 bool_t test_2111;
			 {
			    bool_t test_2112;
			    {
			       obj_t aux_2113;
			       {
				  obj_t aux_2114;
				  aux_2114 = CAR(slots_805);
				  aux_2113 = STRUCT_REF(aux_2114, ((long) 11));
			       }
			       test_2112 = CBOOL(aux_2113);
			    }
			    if (test_2112)
			      {
				 slot_818 = CAR(slots_805);
				 slot_list_182_819 = res_806;
				 {
				    obj_t id_821;
				    id_821 = STRUCT_REF(slot_818, ((long) 0));
				    {
				       obj_t slot_list_182_822;
				       slot_list_182_822 = slot_list_182_819;
				     loop_823:
				       if (NULLP(slot_list_182_822))
					 {
					    test_2111 = ((bool_t) 0);
					 }
				       else
					 {
					    bool_t test_2121;
					    {
					       obj_t aux_2122;
					       {
						  obj_t aux_2123;
						  aux_2123 = CAR(slot_list_182_822);
						  aux_2122 = STRUCT_REF(aux_2123, ((long) 0));
					       }
					       test_2121 = (aux_2122 == id_821);
					    }
					    if (test_2121)
					      {
						 test_2111 = ((bool_t) 1);
					      }
					    else
					      {
						 {
						    obj_t slot_list_182_2127;
						    slot_list_182_2127 = CDR(slot_list_182_822);
						    slot_list_182_822 = slot_list_182_2127;
						    goto loop_823;
						 }
					      }
					 }
				    }
				 }
			      }
			    else
			      {
				 test_2111 = ((bool_t) 0);
			      }
			 }
			 if (test_2111)
			   {
			      {
				 obj_t slots_2130;
				 slots_2130 = CDR(slots_805);
				 slots_805 = slots_2130;
				 goto loop_807;
			      }
			   }
			 else
			   {
			      {
				 obj_t arg1563_812;
				 obj_t arg1564_813;
				 arg1563_812 = CDR(slots_805);
				 {
				    obj_t aux_2133;
				    aux_2133 = CAR(slots_805);
				    arg1564_813 = MAKE_PAIR(aux_2133, res_806);
				 }
				 {
				    obj_t res_2137;
				    obj_t slots_2136;
				    slots_2136 = arg1563_812;
				    res_2137 = arg1564_813;
				    res_806 = res_2137;
				    slots_805 = slots_2136;
				    goto loop_807;
				 }
			      }
			   }
		      }
		 }
	      }
	    else
	      {
		 obj_t s_478;
		 s_478 = CAR(slots_470);
		 {
		    obj_t slot_id_111_479;
		    obj_t attr_480;
		    obj_t len_482;
		    obj_t slot_id_111_483;
		    obj_t attr_484;
		    obj_t slot_id_111_486;
		    obj_t attr_487;
		    obj_t slot_id_111_489;
		    if (PAIRP(s_478))
		      {
			 obj_t cdr_178_46_494;
			 cdr_178_46_494 = CDR(s_478);
			 {
			    bool_t test_2142;
			    {
			       obj_t aux_2145;
			       obj_t aux_2143;
			       aux_2145 = CNST_TABLE_REF(((long) 3));
			       aux_2143 = CAR(s_478);
			       test_2142 = (aux_2143 == aux_2145);
			    }
			    if (test_2142)
			      {
				 if (PAIRP(cdr_178_46_494))
				   {
				      obj_t car_181_188_497;
				      car_181_188_497 = CAR(cdr_178_46_494);
				      if (PAIRP(car_181_188_497))
					{
					   obj_t cdr_185_24_499;
					   cdr_185_24_499 = CDR(car_181_188_497);
					   {
					      bool_t test_2154;
					      {
						 obj_t aux_2157;
						 obj_t aux_2155;
						 aux_2157 = CNST_TABLE_REF(((long) 4));
						 aux_2155 = CAR(car_181_188_497);
						 test_2154 = (aux_2155 == aux_2157);
					      }
					      if (test_2154)
						{
						   if (PAIRP(cdr_185_24_499))
						     {
							bool_t test_2162;
							{
							   obj_t aux_2163;
							   aux_2163 = CDR(cdr_185_24_499);
							   test_2162 = (aux_2163 == BNIL);
							}
							if (test_2162)
							  {
							     slot_id_111_479 = CAR(cdr_185_24_499);
							     attr_480 = CDR(cdr_178_46_494);
							     {
								obj_t id_684;
								obj_t default_685;
								obj_t a_exp_20_686;
								obj_t virtual_687;
								obj_t type_688;
								{
								   obj_t arg1465_709;
								   arg1465_709 = CAR(slot_id_111_479);
								   {
								      obj_t list1467_711;
								      {
									 obj_t arg1468_712;
									 {
									    obj_t aux_2167;
									    aux_2167 = CNST_TABLE_REF(((long) 2));
									    arg1468_712 = MAKE_PAIR(aux_2167, BNIL);
									 }
									 list1467_711 = MAKE_PAIR(arg1465_709, arg1468_712);
								      }
								      id_684 = symbol_append_197___r4_symbols_6_4(list1467_711);
								   }
								}
								default_685 = find_default_attr_77_object_slots(attr_480);
								a_exp_20_686 = find_assert_attr_93_object_slots(attr_480);
								virtual_687 = find_virtual_attr_39_object_slots(attr_480);
								{
								   bool_t test1470_714;
								   {
								      obj_t obj2_1406;
								      obj2_1406 = ____74_type_cache;
								      {
									 obj_t aux_2175;
									 aux_2175 = CDR(slot_id_111_479);
									 test1470_714 = (aux_2175 == obj2_1406);
								      }
								   }
								   if (test1470_714)
								     {
									type_688 = _obj__252_type_cache;
								     }
								   else
								     {
									type_688 = CDR(slot_id_111_479);
								     }
								}
								ensure_type_defined__128_object_slots((type_t) (type_688), src_67);
								{
								   bool_t test_2182;
								   {
								      bool_t test_2183;
								      {
									 obj_t aux_2184;
									 aux_2184 = CAR(virtual_687);
									 test_2183 = CBOOL(aux_2184);
								      }
								      if (test_2183)
									{
									   test_2182 = ((bool_t) 1);
									}
								      else
									{
									   obj_t aux_2187;
									   aux_2187 = CDR(virtual_687);
									   test_2182 = CBOOL(aux_2187);
									}
								   }
								   if (test_2182)
								     {
									obj_t list1442_693;
									list1442_693 = MAKE_PAIR(BNIL, BNIL);
									user_error_151_tools_error(string1697_object_slots, string1702_object_slots, s_478, list1442_693);
								     }
								   else
								     {
									BUNSPEC;
								     }
								}
								{
								   obj_t arg1446_696;
								   obj_t arg1448_697;
								   arg1446_696 = CDR(slots_470);
								   {
								      obj_t arg1449_698;
								      obj_t arg1450_699;
								      {
									 obj_t arg1453_700;
									 obj_t arg1454_701;
									 obj_t arg1455_702;
									 obj_t arg1456_703;
									 obj_t arg1458_704;
									 arg1453_700 = CAR(slot_id_111_479);
									 arg1454_701 = scheme_symbol__c_string_183_object_slots(CAR(slot_id_111_479));
									 arg1455_702 = memq___r4_pairs_and_lists_6_3(CNST_TABLE_REF(((long) 1)), attr_480);
									 arg1456_703 = CAR(default_685);
									 arg1458_704 = CDR(default_685);
									 {
									    obj_t new_1430;
									    {
									       obj_t aux_2200;
									       aux_2200 = CNST_TABLE_REF(((long) 0));
									       new_1430 = create_struct(aux_2200, ((long) 15));
									    }
									    STRUCT_SET(new_1430, ((long) 14), s_478);
									    STRUCT_SET(new_1430, ((long) 13), BFALSE);
									    STRUCT_SET(new_1430, ((long) 12), BFALSE);
									    STRUCT_SET(new_1430, ((long) 11), BFALSE);
									    STRUCT_SET(new_1430, ((long) 10), a_exp_20_686);
									    STRUCT_SET(new_1430, ((long) 9), arg1458_704);
									    STRUCT_SET(new_1430, ((long) 8), arg1456_703);
									    STRUCT_SET(new_1430, ((long) 7), arg1455_702);
									    STRUCT_SET(new_1430, ((long) 6), BFALSE);
									    STRUCT_SET(new_1430, ((long) 5), BTRUE);
									    STRUCT_SET(new_1430, ((long) 4), BUNSPEC);
									    STRUCT_SET(new_1430, ((long) 3), BFALSE);
									    STRUCT_SET(new_1430, ((long) 2), type_688);
									    STRUCT_SET(new_1430, ((long) 1), arg1454_701);
									    STRUCT_SET(new_1430, ((long) 0), arg1453_700);
									    arg1449_698 = new_1430;
									 }
								      }
								      {
									 obj_t arg1463_707;
									 {
									    obj_t arg1464_708;
									    arg1464_708 = scheme_symbol__c_string_183_object_slots(id_684);
									    {
									       obj_t type_1510;
									       type_1510 = _long__149_type_cache;
									       {
										  obj_t new_1523;
										  {
										     obj_t aux_2219;
										     aux_2219 = CNST_TABLE_REF(((long) 0));
										     new_1523 = create_struct(aux_2219, ((long) 15));
										  }
										  STRUCT_SET(new_1523, ((long) 14), s_478);
										  STRUCT_SET(new_1523, ((long) 13), BFALSE);
										  STRUCT_SET(new_1523, ((long) 12), BFALSE);
										  STRUCT_SET(new_1523, ((long) 11), BFALSE);
										  STRUCT_SET(new_1523, ((long) 10), BFALSE);
										  STRUCT_SET(new_1523, ((long) 9), BUNSPEC);
										  STRUCT_SET(new_1523, ((long) 8), BFALSE);
										  STRUCT_SET(new_1523, ((long) 7), BTRUE);
										  STRUCT_SET(new_1523, ((long) 6), BTRUE);
										  STRUCT_SET(new_1523, ((long) 5), BFALSE);
										  STRUCT_SET(new_1523, ((long) 4), BUNSPEC);
										  STRUCT_SET(new_1523, ((long) 3), BFALSE);
										  STRUCT_SET(new_1523, ((long) 2), type_1510);
										  STRUCT_SET(new_1523, ((long) 1), arg1464_708);
										  STRUCT_SET(new_1523, ((long) 0), id_684);
										  arg1463_707 = new_1523;
									       }
									    }
									 }
									 arg1450_699 = MAKE_PAIR(arg1463_707, res_471);
								      }
								      arg1448_697 = MAKE_PAIR(arg1449_698, arg1450_699);
								   }
								   {
								      obj_t res_2240;
								      obj_t slots_2239;
								      slots_2239 = arg1446_696;
								      res_2240 = arg1448_697;
								      res_471 = res_2240;
								      slots_470 = slots_2239;
								      goto loop_472;
								   }
								}
							     }
							  }
							else
							  {
							     obj_t car_201_27_505;
							     car_201_27_505 = CAR(s_478);
							     if (PAIRP(car_201_27_505))
							       {
								  obj_t cdr_205_20_507;
								  cdr_205_20_507 = CDR(car_201_27_505);
								  {
								     bool_t test_2247;
								     {
									obj_t aux_2250;
									obj_t aux_2248;
									aux_2250 = CNST_TABLE_REF(((long) 4));
									aux_2248 = CAR(car_201_27_505);
									test_2247 = (aux_2248 == aux_2250);
								     }
								     if (test_2247)
								       {
									  if (PAIRP(cdr_205_20_507))
									    {
									       bool_t test_2255;
									       {
										  obj_t aux_2256;
										  aux_2256 = CDR(cdr_205_20_507);
										  test_2255 = (aux_2256 == BNIL);
									       }
									       if (test_2255)
										 {
										    slot_id_111_486 = CAR(cdr_205_20_507);
										    attr_487 = cdr_178_46_494;
										  tag_168_235_488:
										    {
										       obj_t default_745;
										       obj_t a_exp_20_746;
										       obj_t virtual_747;
										       obj_t reado__215_748;
										       obj_t type_749;
										       default_745 = find_default_attr_77_object_slots(attr_487);
										       a_exp_20_746 = find_assert_attr_93_object_slots(attr_487);
										       virtual_747 = find_virtual_attr_39_object_slots(attr_487);
										       reado__215_748 = memq___r4_pairs_and_lists_6_3(CNST_TABLE_REF(((long) 1)), attr_487);
										       {
											  bool_t test1538_787;
											  {
											     obj_t obj2_1714;
											     obj2_1714 = ____74_type_cache;
											     {
												obj_t aux_2264;
												aux_2264 = CDR(slot_id_111_486);
												test1538_787 = (aux_2264 == obj2_1714);
											     }
											  }
											  if (test1538_787)
											    {
											       type_749 = _obj__252_type_cache;
											    }
											  else
											    {
											       type_749 = CDR(slot_id_111_486);
											    }
										       }
										       {
											  bool_t test_2269;
											  {
											     bool_t test_2270;
											     {
												obj_t aux_2271;
												aux_2271 = CDR(virtual_747);
												test_2270 = CBOOL(aux_2271);
											     }
											     if (test_2270)
											       {
												  bool_t test_2274;
												  {
												     obj_t aux_2275;
												     aux_2275 = CAR(virtual_747);
												     test_2274 = CBOOL(aux_2275);
												  }
												  if (test_2274)
												    {
												       test_2269 = ((bool_t) 0);
												    }
												  else
												    {
												       test_2269 = ((bool_t) 1);
												    }
											       }
											     else
											       {
												  test_2269 = ((bool_t) 0);
											       }
											  }
											  if (test_2269)
											    {
											       {
												  obj_t list1503_754;
												  list1503_754 = MAKE_PAIR(BNIL, BNIL);
												  user_error_151_tools_error(string1697_object_slots, string1699_object_slots, s_478, list1503_754);
											       }
											    }
											  else
											    {
											       bool_t test_2280;
											       {
												  bool_t test_2281;
												  {
												     obj_t aux_2282;
												     aux_2282 = CAR(virtual_747);
												     test_2281 = CBOOL(aux_2282);
												  }
												  if (test_2281)
												    {
												       bool_t test_2285;
												       {
													  obj_t aux_2286;
													  aux_2286 = CDR(virtual_747);
													  test_2285 = CBOOL(aux_2286);
												       }
												       if (test_2285)
													 {
													    test_2280 = CBOOL(reado__215_748);
													 }
												       else
													 {
													    test_2280 = ((bool_t) 0);
													 }
												    }
												  else
												    {
												       test_2280 = ((bool_t) 0);
												    }
											       }
											       if (test_2280)
												 {
												    {
												       obj_t list1512_760;
												       list1512_760 = MAKE_PAIR(BNIL, BNIL);
												       user_error_151_tools_error(string1697_object_slots, string1700_object_slots, s_478, list1512_760);
												    }
												 }
											       else
												 {
												    bool_t test_2292;
												    {
												       bool_t test_2293;
												       {
													  obj_t aux_2294;
													  aux_2294 = CAR(virtual_747);
													  test_2293 = CBOOL(aux_2294);
												       }
												       if (test_2293)
													 {
													    bool_t test_2297;
													    {
													       obj_t aux_2298;
													       aux_2298 = CDR(virtual_747);
													       test_2297 = CBOOL(aux_2298);
													    }
													    if (test_2297)
													      {
														 test_2292 = ((bool_t) 0);
													      }
													    else
													      {
														 if (CBOOL(reado__215_748))
														   {
														      test_2292 = ((bool_t) 0);
														   }
														 else
														   {
														      test_2292 = ((bool_t) 1);
														   }
													      }
													 }
												       else
													 {
													    test_2292 = ((bool_t) 0);
													 }
												    }
												    if (test_2292)
												      {
													 {
													    obj_t list1518_766;
													    list1518_766 = MAKE_PAIR(BNIL, BNIL);
													    user_error_151_tools_error(string1697_object_slots, string1701_object_slots, s_478, list1518_766);
													 }
												      }
												    else
												      {
													 BFALSE;
												      }
												 }
											    }
										       }
										       ensure_type_defined__128_object_slots((type_t) (type_749), src_67);
										       {
											  obj_t arg1526_774;
											  obj_t arg1527_775;
											  arg1526_774 = CDR(slots_470);
											  {
											     obj_t arg1528_776;
											     {
												obj_t arg1529_777;
												obj_t arg1530_778;
												obj_t arg1531_779;
												obj_t arg1532_780;
												obj_t arg1533_781;
												obj_t arg1534_782;
												obj_t arg1535_783;
												arg1529_777 = CAR(slot_id_111_486);
												arg1530_778 = scheme_symbol__c_string_183_object_slots(CAR(slot_id_111_486));
												arg1531_779 = CAR(default_745);
												arg1532_780 = CDR(default_745);
												{
												   obj_t _ortest_1209_785;
												   _ortest_1209_785 = CAR(virtual_747);
												   if (CBOOL(_ortest_1209_785))
												     {
													arg1533_781 = _ortest_1209_785;
												     }
												   else
												     {
													arg1533_781 = CDR(virtual_747);
												     }
												}
												arg1534_782 = CAR(virtual_747);
												arg1535_783 = CDR(virtual_747);
												{
												   obj_t new_1746;
												   {
												      obj_t aux_2319;
												      aux_2319 = CNST_TABLE_REF(((long) 0));
												      new_1746 = create_struct(aux_2319, ((long) 15));
												   }
												   STRUCT_SET(new_1746, ((long) 14), s_478);
												   STRUCT_SET(new_1746, ((long) 13), arg1535_783);
												   STRUCT_SET(new_1746, ((long) 12), arg1534_782);
												   STRUCT_SET(new_1746, ((long) 11), arg1533_781);
												   STRUCT_SET(new_1746, ((long) 10), a_exp_20_746);
												   STRUCT_SET(new_1746, ((long) 9), arg1532_780);
												   STRUCT_SET(new_1746, ((long) 8), arg1531_779);
												   STRUCT_SET(new_1746, ((long) 7), reado__215_748);
												   STRUCT_SET(new_1746, ((long) 6), BFALSE);
												   STRUCT_SET(new_1746, ((long) 5), BFALSE);
												   STRUCT_SET(new_1746, ((long) 4), BUNSPEC);
												   STRUCT_SET(new_1746, ((long) 3), BFALSE);
												   STRUCT_SET(new_1746, ((long) 2), type_749);
												   STRUCT_SET(new_1746, ((long) 1), arg1530_778);
												   STRUCT_SET(new_1746, ((long) 0), arg1529_777);
												   arg1528_776 = new_1746;
												}
											     }
											     arg1527_775 = MAKE_PAIR(arg1528_776, res_471);
											  }
											  {
											     obj_t res_2339;
											     obj_t slots_2338;
											     slots_2338 = arg1526_774;
											     res_2339 = arg1527_775;
											     res_471 = res_2339;
											     slots_470 = slots_2338;
											     goto loop_472;
											  }
										       }
										    }
										 }
									       else
										 {
										  tag_170_4_491:
										    {
										       obj_t list1556_801;
										       list1556_801 = MAKE_PAIR(BNIL, BNIL);
										       return user_error_151_tools_error(string1697_object_slots, string1698_object_slots, s_478, list1556_801);
										    }
										 }
									    }
									  else
									    {
									       goto tag_170_4_491;
									    }
								       }
								     else
								       {
									  goto tag_170_4_491;
								       }
								  }
							       }
							     else
							       {
								  goto tag_170_4_491;
							       }
							  }
						     }
						   else
						     {
							obj_t car_229_102_519;
							car_229_102_519 = CAR(s_478);
							if (PAIRP(car_229_102_519))
							  {
							     obj_t cdr_233_190_521;
							     cdr_233_190_521 = CDR(car_229_102_519);
							     {
								bool_t test_2347;
								{
								   obj_t aux_2350;
								   obj_t aux_2348;
								   aux_2350 = CNST_TABLE_REF(((long) 4));
								   aux_2348 = CAR(car_229_102_519);
								   test_2347 = (aux_2348 == aux_2350);
								}
								if (test_2347)
								  {
								     if (PAIRP(cdr_233_190_521))
								       {
									  bool_t test_2355;
									  {
									     obj_t aux_2356;
									     aux_2356 = CDR(cdr_233_190_521);
									     test_2355 = (aux_2356 == BNIL);
									  }
									  if (test_2355)
									    {
									       obj_t attr_2361;
									       obj_t slot_id_111_2359;
									       slot_id_111_2359 = CAR(cdr_233_190_521);
									       attr_2361 = cdr_178_46_494;
									       attr_487 = attr_2361;
									       slot_id_111_486 = slot_id_111_2359;
									       goto tag_168_235_488;
									    }
									  else
									    {
									       goto tag_170_4_491;
									    }
								       }
								     else
								       {
									  goto tag_170_4_491;
								       }
								  }
								else
								  {
								     goto tag_170_4_491;
								  }
							     }
							  }
							else
							  {
							     goto tag_170_4_491;
							  }
						     }
						}
					      else
						{
						   obj_t car_257_21_531;
						   car_257_21_531 = CAR(s_478);
						   if (PAIRP(car_257_21_531))
						     {
							obj_t cdr_261_29_533;
							cdr_261_29_533 = CDR(car_257_21_531);
							{
							   bool_t test_2366;
							   {
							      obj_t aux_2369;
							      obj_t aux_2367;
							      aux_2369 = CNST_TABLE_REF(((long) 4));
							      aux_2367 = CAR(car_257_21_531);
							      test_2366 = (aux_2367 == aux_2369);
							   }
							   if (test_2366)
							     {
								if (PAIRP(cdr_261_29_533))
								  {
								     bool_t test_2374;
								     {
									obj_t aux_2375;
									aux_2375 = CDR(cdr_261_29_533);
									test_2374 = (aux_2375 == BNIL);
								     }
								     if (test_2374)
								       {
									  obj_t attr_2380;
									  obj_t slot_id_111_2378;
									  slot_id_111_2378 = CAR(cdr_261_29_533);
									  attr_2380 = cdr_178_46_494;
									  attr_487 = attr_2380;
									  slot_id_111_486 = slot_id_111_2378;
									  goto tag_168_235_488;
								       }
								     else
								       {
									  goto tag_170_4_491;
								       }
								  }
								else
								  {
								     goto tag_170_4_491;
								  }
							     }
							   else
							     {
								goto tag_170_4_491;
							     }
							}
						     }
						   else
						     {
							goto tag_170_4_491;
						     }
						}
					   }
					}
				      else
					{
					   obj_t car_285_237_545;
					   car_285_237_545 = CAR(s_478);
					   if (PAIRP(car_285_237_545))
					     {
						obj_t cdr_289_3_547;
						cdr_289_3_547 = CDR(car_285_237_545);
						{
						   bool_t test_2385;
						   {
						      obj_t aux_2388;
						      obj_t aux_2386;
						      aux_2388 = CNST_TABLE_REF(((long) 4));
						      aux_2386 = CAR(car_285_237_545);
						      test_2385 = (aux_2386 == aux_2388);
						   }
						   if (test_2385)
						     {
							if (PAIRP(cdr_289_3_547))
							  {
							     bool_t test_2393;
							     {
								obj_t aux_2394;
								aux_2394 = CDR(cdr_289_3_547);
								test_2393 = (aux_2394 == BNIL);
							     }
							     if (test_2393)
							       {
								  obj_t attr_2399;
								  obj_t slot_id_111_2397;
								  slot_id_111_2397 = CAR(cdr_289_3_547);
								  attr_2399 = cdr_178_46_494;
								  attr_487 = attr_2399;
								  slot_id_111_486 = slot_id_111_2397;
								  goto tag_168_235_488;
							       }
							     else
							       {
								  goto tag_170_4_491;
							       }
							  }
							else
							  {
							     goto tag_170_4_491;
							  }
						     }
						   else
						     {
							goto tag_170_4_491;
						     }
						}
					     }
					   else
					     {
						goto tag_170_4_491;
					     }
					}
				   }
				 else
				   {
				      obj_t car_313_248_557;
				      car_313_248_557 = CAR(s_478);
				      if (PAIRP(car_313_248_557))
					{
					   obj_t cdr_317_116_559;
					   cdr_317_116_559 = CDR(car_313_248_557);
					   {
					      bool_t test_2404;
					      {
						 obj_t aux_2407;
						 obj_t aux_2405;
						 aux_2407 = CNST_TABLE_REF(((long) 4));
						 aux_2405 = CAR(car_313_248_557);
						 test_2404 = (aux_2405 == aux_2407);
					      }
					      if (test_2404)
						{
						   if (PAIRP(cdr_317_116_559))
						     {
							bool_t test_2412;
							{
							   obj_t aux_2413;
							   aux_2413 = CDR(cdr_317_116_559);
							   test_2412 = (aux_2413 == BNIL);
							}
							if (test_2412)
							  {
							     obj_t attr_2418;
							     obj_t slot_id_111_2416;
							     slot_id_111_2416 = CAR(cdr_317_116_559);
							     attr_2418 = cdr_178_46_494;
							     attr_487 = attr_2418;
							     slot_id_111_486 = slot_id_111_2416;
							     goto tag_168_235_488;
							  }
							else
							  {
							     goto tag_170_4_491;
							  }
						     }
						   else
						     {
							goto tag_170_4_491;
						     }
						}
					      else
						{
						   goto tag_170_4_491;
						}
					   }
					}
				      else
					{
					   goto tag_170_4_491;
					}
				   }
			      }
			    else
			      {
				 bool_t test_2419;
				 {
				    obj_t aux_2422;
				    obj_t aux_2420;
				    aux_2422 = CNST_TABLE_REF(((long) 5));
				    aux_2420 = CAR(s_478);
				    test_2419 = (aux_2420 == aux_2422);
				 }
				 if (test_2419)
				   {
				      if (PAIRP(cdr_178_46_494))
					{
					   obj_t cdr_343_138_572;
					   cdr_343_138_572 = CDR(cdr_178_46_494);
					   if (PAIRP(cdr_343_138_572))
					     {
						obj_t car_347_179_574;
						car_347_179_574 = CAR(cdr_343_138_572);
						if (PAIRP(car_347_179_574))
						  {
						     obj_t cdr_351_145_576;
						     cdr_351_145_576 = CDR(car_347_179_574);
						     {
							bool_t test_2434;
							{
							   obj_t aux_2437;
							   obj_t aux_2435;
							   aux_2437 = CNST_TABLE_REF(((long) 4));
							   aux_2435 = CAR(car_347_179_574);
							   test_2434 = (aux_2435 == aux_2437);
							}
							if (test_2434)
							  {
							     if (PAIRP(cdr_351_145_576))
							       {
								  bool_t test_2442;
								  {
								     obj_t aux_2443;
								     aux_2443 = CDR(cdr_351_145_576);
								     test_2442 = (aux_2443 == BNIL);
								  }
								  if (test_2442)
								    {
								       len_482 = CAR(cdr_178_46_494);
								       slot_id_111_483 = CAR(cdr_351_145_576);
								       attr_484 = CDR(cdr_343_138_572);
								       {
									  obj_t id_716;
									  obj_t default_717;
									  obj_t a_exp_20_718;
									  obj_t virtual_719;
									  obj_t type_720;
									  {
									     obj_t arg1490_738;
									     arg1490_738 = CAR(slot_id_111_483);
									     {
										obj_t list1492_740;
										{
										   obj_t arg1494_741;
										   {
										      obj_t aux_2447;
										      aux_2447 = CNST_TABLE_REF(((long) 2));
										      arg1494_741 = MAKE_PAIR(aux_2447, BNIL);
										   }
										   list1492_740 = MAKE_PAIR(arg1490_738, arg1494_741);
										}
										id_716 = symbol_append_197___r4_symbols_6_4(list1492_740);
									     }
									  }
									  default_717 = find_default_attr_77_object_slots(attr_484);
									  a_exp_20_718 = find_assert_attr_93_object_slots(attr_484);
									  virtual_719 = find_virtual_attr_39_object_slots(attr_484);
									  {
									     bool_t test1497_743;
									     {
										obj_t obj2_1608;
										obj2_1608 = ____74_type_cache;
										{
										   obj_t aux_2455;
										   aux_2455 = CDR(slot_id_111_483);
										   test1497_743 = (aux_2455 == obj2_1608);
										}
									     }
									     if (test1497_743)
									       {
										  type_720 = _obj__252_type_cache;
									       }
									     else
									       {
										  type_720 = CDR(slot_id_111_483);
									       }
									  }
									  ensure_type_defined__128_object_slots((type_t) (type_720), src_67);
									  {
									     bool_t test_2462;
									     {
										bool_t test_2463;
										{
										   obj_t aux_2464;
										   aux_2464 = CAR(virtual_719);
										   test_2463 = CBOOL(aux_2464);
										}
										if (test_2463)
										  {
										     test_2462 = ((bool_t) 1);
										  }
										else
										  {
										     obj_t aux_2467;
										     aux_2467 = CDR(virtual_719);
										     test_2462 = CBOOL(aux_2467);
										  }
									     }
									     if (test_2462)
									       {
										  obj_t list1476_725;
										  list1476_725 = MAKE_PAIR(BNIL, BNIL);
										  user_error_151_tools_error(string1697_object_slots, string1702_object_slots, s_478, list1476_725);
									       }
									     else
									       {
										  BUNSPEC;
									       }
									  }
									  {
									     obj_t arg1479_728;
									     obj_t arg1480_729;
									     arg1479_728 = CDR(slots_470);
									     {
										obj_t arg1481_730;
										{
										   obj_t arg1483_731;
										   obj_t arg1484_732;
										   obj_t arg1485_733;
										   obj_t arg1486_734;
										   obj_t arg1487_735;
										   arg1483_731 = CAR(slot_id_111_483);
										   arg1484_732 = scheme_symbol__c_string_183_object_slots(CAR(slot_id_111_483));
										   arg1485_733 = memq___r4_pairs_and_lists_6_3(CNST_TABLE_REF(((long) 1)), attr_484);
										   arg1486_734 = CAR(default_717);
										   arg1487_735 = CDR(default_717);
										   {
										      obj_t new_1632;
										      {
											 obj_t aux_2480;
											 aux_2480 = CNST_TABLE_REF(((long) 0));
											 new_1632 = create_struct(aux_2480, ((long) 15));
										      }
										      STRUCT_SET(new_1632, ((long) 14), s_478);
										      STRUCT_SET(new_1632, ((long) 13), BFALSE);
										      STRUCT_SET(new_1632, ((long) 12), BFALSE);
										      STRUCT_SET(new_1632, ((long) 11), BFALSE);
										      STRUCT_SET(new_1632, ((long) 10), a_exp_20_718);
										      STRUCT_SET(new_1632, ((long) 9), arg1487_735);
										      STRUCT_SET(new_1632, ((long) 8), arg1486_734);
										      STRUCT_SET(new_1632, ((long) 7), arg1485_733);
										      STRUCT_SET(new_1632, ((long) 6), BFALSE);
										      STRUCT_SET(new_1632, ((long) 5), BFALSE);
										      STRUCT_SET(new_1632, ((long) 4), len_482);
										      STRUCT_SET(new_1632, ((long) 3), BTRUE);
										      STRUCT_SET(new_1632, ((long) 2), type_720);
										      STRUCT_SET(new_1632, ((long) 1), arg1484_732);
										      STRUCT_SET(new_1632, ((long) 0), arg1483_731);
										      arg1481_730 = new_1632;
										   }
										}
										arg1480_729 = MAKE_PAIR(arg1481_730, res_471);
									     }
									     {
										obj_t res_2500;
										obj_t slots_2499;
										slots_2499 = arg1479_728;
										res_2500 = arg1480_729;
										res_471 = res_2500;
										slots_470 = slots_2499;
										goto loop_472;
									     }
									  }
								       }
								    }
								  else
								    {
								       obj_t car_361_52_583;
								       car_361_52_583 = CAR(s_478);
								       if (PAIRP(car_361_52_583))
									 {
									    obj_t cdr_365_142_585;
									    cdr_365_142_585 = CDR(car_361_52_583);
									    {
									       bool_t test_2508;
									       {
										  obj_t aux_2511;
										  obj_t aux_2509;
										  aux_2511 = CNST_TABLE_REF(((long) 4));
										  aux_2509 = CAR(car_361_52_583);
										  test_2508 = (aux_2509 == aux_2511);
									       }
									       if (test_2508)
										 {
										    if (PAIRP(cdr_365_142_585))
										      {
											 bool_t test_2516;
											 {
											    obj_t aux_2517;
											    aux_2517 = CDR(cdr_365_142_585);
											    test_2516 = (aux_2517 == BNIL);
											 }
											 if (test_2516)
											   {
											      obj_t attr_2522;
											      obj_t slot_id_111_2520;
											      slot_id_111_2520 = CAR(cdr_365_142_585);
											      attr_2522 = cdr_178_46_494;
											      attr_487 = attr_2522;
											      slot_id_111_486 = slot_id_111_2520;
											      goto tag_168_235_488;
											   }
											 else
											   {
											      goto tag_170_4_491;
											   }
										      }
										    else
										      {
											 goto tag_170_4_491;
										      }
										 }
									       else
										 {
										    goto tag_170_4_491;
										 }
									    }
									 }
								       else
									 {
									    goto tag_170_4_491;
									 }
								    }
							       }
							     else
							       {
								  obj_t car_383_209_597;
								  car_383_209_597 = CAR(s_478);
								  if (PAIRP(car_383_209_597))
								    {
								       obj_t cdr_387_108_599;
								       cdr_387_108_599 = CDR(car_383_209_597);
								       {
									  bool_t test_2527;
									  {
									     obj_t aux_2530;
									     obj_t aux_2528;
									     aux_2530 = CNST_TABLE_REF(((long) 4));
									     aux_2528 = CAR(car_383_209_597);
									     test_2527 = (aux_2528 == aux_2530);
									  }
									  if (test_2527)
									    {
									       if (PAIRP(cdr_387_108_599))
										 {
										    bool_t test_2535;
										    {
										       obj_t aux_2536;
										       aux_2536 = CDR(cdr_387_108_599);
										       test_2535 = (aux_2536 == BNIL);
										    }
										    if (test_2535)
										      {
											 obj_t attr_2541;
											 obj_t slot_id_111_2539;
											 slot_id_111_2539 = CAR(cdr_387_108_599);
											 attr_2541 = cdr_178_46_494;
											 attr_487 = attr_2541;
											 slot_id_111_486 = slot_id_111_2539;
											 goto tag_168_235_488;
										      }
										    else
										      {
											 goto tag_170_4_491;
										      }
										 }
									       else
										 {
										    goto tag_170_4_491;
										 }
									    }
									  else
									    {
									       goto tag_170_4_491;
									    }
								       }
								    }
								  else
								    {
								       goto tag_170_4_491;
								    }
							       }
							  }
							else
							  {
							     obj_t car_405_221_609;
							     car_405_221_609 = CAR(s_478);
							     if (PAIRP(car_405_221_609))
							       {
								  obj_t cdr_409_223_611;
								  cdr_409_223_611 = CDR(car_405_221_609);
								  {
								     bool_t test_2546;
								     {
									obj_t aux_2549;
									obj_t aux_2547;
									aux_2549 = CNST_TABLE_REF(((long) 4));
									aux_2547 = CAR(car_405_221_609);
									test_2546 = (aux_2547 == aux_2549);
								     }
								     if (test_2546)
								       {
									  if (PAIRP(cdr_409_223_611))
									    {
									       bool_t test_2554;
									       {
										  obj_t aux_2555;
										  aux_2555 = CDR(cdr_409_223_611);
										  test_2554 = (aux_2555 == BNIL);
									       }
									       if (test_2554)
										 {
										    obj_t attr_2560;
										    obj_t slot_id_111_2558;
										    slot_id_111_2558 = CAR(cdr_409_223_611);
										    attr_2560 = cdr_178_46_494;
										    attr_487 = attr_2560;
										    slot_id_111_486 = slot_id_111_2558;
										    goto tag_168_235_488;
										 }
									       else
										 {
										    goto tag_170_4_491;
										 }
									    }
									  else
									    {
									       goto tag_170_4_491;
									    }
								       }
								     else
								       {
									  goto tag_170_4_491;
								       }
								  }
							       }
							     else
							       {
								  goto tag_170_4_491;
							       }
							  }
						     }
						  }
						else
						  {
						     obj_t car_427_120_623;
						     car_427_120_623 = CAR(s_478);
						     if (PAIRP(car_427_120_623))
						       {
							  obj_t cdr_431_26_625;
							  cdr_431_26_625 = CDR(car_427_120_623);
							  {
							     bool_t test_2565;
							     {
								obj_t aux_2568;
								obj_t aux_2566;
								aux_2568 = CNST_TABLE_REF(((long) 4));
								aux_2566 = CAR(car_427_120_623);
								test_2565 = (aux_2566 == aux_2568);
							     }
							     if (test_2565)
							       {
								  if (PAIRP(cdr_431_26_625))
								    {
								       bool_t test_2573;
								       {
									  obj_t aux_2574;
									  aux_2574 = CDR(cdr_431_26_625);
									  test_2573 = (aux_2574 == BNIL);
								       }
								       if (test_2573)
									 {
									    obj_t attr_2579;
									    obj_t slot_id_111_2577;
									    slot_id_111_2577 = CAR(cdr_431_26_625);
									    attr_2579 = cdr_178_46_494;
									    attr_487 = attr_2579;
									    slot_id_111_486 = slot_id_111_2577;
									    goto tag_168_235_488;
									 }
								       else
									 {
									    goto tag_170_4_491;
									 }
								    }
								  else
								    {
								       goto tag_170_4_491;
								    }
							       }
							     else
							       {
								  goto tag_170_4_491;
							       }
							  }
						       }
						     else
						       {
							  goto tag_170_4_491;
						       }
						  }
					     }
					   else
					     {
						obj_t car_449_149_635;
						car_449_149_635 = CAR(s_478);
						if (PAIRP(car_449_149_635))
						  {
						     obj_t cdr_453_73_637;
						     cdr_453_73_637 = CDR(car_449_149_635);
						     {
							bool_t test_2584;
							{
							   obj_t aux_2587;
							   obj_t aux_2585;
							   aux_2587 = CNST_TABLE_REF(((long) 4));
							   aux_2585 = CAR(car_449_149_635);
							   test_2584 = (aux_2585 == aux_2587);
							}
							if (test_2584)
							  {
							     if (PAIRP(cdr_453_73_637))
							       {
								  bool_t test_2592;
								  {
								     obj_t aux_2593;
								     aux_2593 = CDR(cdr_453_73_637);
								     test_2592 = (aux_2593 == BNIL);
								  }
								  if (test_2592)
								    {
								       obj_t attr_2598;
								       obj_t slot_id_111_2596;
								       slot_id_111_2596 = CAR(cdr_453_73_637);
								       attr_2598 = cdr_178_46_494;
								       attr_487 = attr_2598;
								       slot_id_111_486 = slot_id_111_2596;
								       goto tag_168_235_488;
								    }
								  else
								    {
								       goto tag_170_4_491;
								    }
							       }
							     else
							       {
								  goto tag_170_4_491;
							       }
							  }
							else
							  {
							     goto tag_170_4_491;
							  }
						     }
						  }
						else
						  {
						     goto tag_170_4_491;
						  }
					     }
					}
				      else
					{
					   obj_t car_471_231_647;
					   car_471_231_647 = CAR(s_478);
					   if (PAIRP(car_471_231_647))
					     {
						obj_t cdr_475_175_649;
						cdr_475_175_649 = CDR(car_471_231_647);
						{
						   bool_t test_2603;
						   {
						      obj_t aux_2606;
						      obj_t aux_2604;
						      aux_2606 = CNST_TABLE_REF(((long) 4));
						      aux_2604 = CAR(car_471_231_647);
						      test_2603 = (aux_2604 == aux_2606);
						   }
						   if (test_2603)
						     {
							if (PAIRP(cdr_475_175_649))
							  {
							     bool_t test_2611;
							     {
								obj_t aux_2612;
								aux_2612 = CDR(cdr_475_175_649);
								test_2611 = (aux_2612 == BNIL);
							     }
							     if (test_2611)
							       {
								  obj_t attr_2617;
								  obj_t slot_id_111_2615;
								  slot_id_111_2615 = CAR(cdr_475_175_649);
								  attr_2617 = cdr_178_46_494;
								  attr_487 = attr_2617;
								  slot_id_111_486 = slot_id_111_2615;
								  goto tag_168_235_488;
							       }
							     else
							       {
								  goto tag_170_4_491;
							       }
							  }
							else
							  {
							     goto tag_170_4_491;
							  }
						     }
						   else
						     {
							goto tag_170_4_491;
						     }
						}
					     }
					   else
					     {
						goto tag_170_4_491;
					     }
					}
				   }
				 else
				   {
				      obj_t car_493_7_659;
				      car_493_7_659 = CAR(s_478);
				      if (PAIRP(car_493_7_659))
					{
					   obj_t cdr_497_222_661;
					   cdr_497_222_661 = CDR(car_493_7_659);
					   {
					      bool_t test_2622;
					      {
						 obj_t aux_2625;
						 obj_t aux_2623;
						 aux_2625 = CNST_TABLE_REF(((long) 4));
						 aux_2623 = CAR(car_493_7_659);
						 test_2622 = (aux_2623 == aux_2625);
					      }
					      if (test_2622)
						{
						   if (PAIRP(cdr_497_222_661))
						     {
							bool_t test_2630;
							{
							   obj_t aux_2631;
							   aux_2631 = CDR(cdr_497_222_661);
							   test_2630 = (aux_2631 == BNIL);
							}
							if (test_2630)
							  {
							     obj_t attr_2636;
							     obj_t slot_id_111_2634;
							     slot_id_111_2634 = CAR(cdr_497_222_661);
							     attr_2636 = cdr_178_46_494;
							     attr_487 = attr_2636;
							     slot_id_111_486 = slot_id_111_2634;
							     goto tag_168_235_488;
							  }
							else
							  {
							     goto tag_170_4_491;
							  }
						     }
						   else
						     {
							goto tag_170_4_491;
						     }
						}
					      else
						{
						   goto tag_170_4_491;
						}
					   }
					}
				      else
					{
					   bool_t test_2637;
					   {
					      obj_t aux_2638;
					      aux_2638 = CNST_TABLE_REF(((long) 4));
					      test_2637 = (car_493_7_659 == aux_2638);
					   }
					   if (test_2637)
					     {
						if (PAIRP(cdr_178_46_494))
						  {
						     bool_t test_2643;
						     {
							obj_t aux_2644;
							aux_2644 = CDR(cdr_178_46_494);
							test_2643 = (aux_2644 == BNIL);
						     }
						     if (test_2643)
						       {
							  slot_id_111_489 = CAR(cdr_178_46_494);
							  {
							     obj_t type_789;
							     {
								bool_t test1551_796;
								{
								   obj_t obj2_1828;
								   obj2_1828 = ____74_type_cache;
								   {
								      obj_t aux_2647;
								      aux_2647 = CDR(slot_id_111_489);
								      test1551_796 = (aux_2647 == obj2_1828);
								   }
								}
								if (test1551_796)
								  {
								     type_789 = _obj__252_type_cache;
								  }
								else
								  {
								     type_789 = CDR(slot_id_111_489);
								  }
							     }
							     ensure_type_defined__128_object_slots((type_t) (type_789), src_67);
							     {
								obj_t arg1540_790;
								obj_t arg1542_791;
								arg1540_790 = CDR(slots_470);
								{
								   obj_t arg1545_792;
								   {
								      obj_t arg1548_793;
								      obj_t arg1549_794;
								      arg1548_793 = CAR(slot_id_111_489);
								      arg1549_794 = scheme_symbol__c_string_183_object_slots(CAR(slot_id_111_489));
								      {
									 obj_t new_1848;
									 {
									    obj_t aux_2658;
									    aux_2658 = CNST_TABLE_REF(((long) 0));
									    new_1848 = create_struct(aux_2658, ((long) 15));
									 }
									 STRUCT_SET(new_1848, ((long) 14), s_478);
									 STRUCT_SET(new_1848, ((long) 13), BFALSE);
									 STRUCT_SET(new_1848, ((long) 12), BFALSE);
									 STRUCT_SET(new_1848, ((long) 11), BFALSE);
									 STRUCT_SET(new_1848, ((long) 10), BFALSE);
									 STRUCT_SET(new_1848, ((long) 9), BUNSPEC);
									 STRUCT_SET(new_1848, ((long) 8), BFALSE);
									 STRUCT_SET(new_1848, ((long) 7), BFALSE);
									 STRUCT_SET(new_1848, ((long) 6), BFALSE);
									 STRUCT_SET(new_1848, ((long) 5), BFALSE);
									 STRUCT_SET(new_1848, ((long) 4), BUNSPEC);
									 STRUCT_SET(new_1848, ((long) 3), BFALSE);
									 STRUCT_SET(new_1848, ((long) 2), type_789);
									 STRUCT_SET(new_1848, ((long) 1), arg1549_794);
									 STRUCT_SET(new_1848, ((long) 0), arg1548_793);
									 arg1545_792 = new_1848;
								      }
								   }
								   arg1542_791 = MAKE_PAIR(arg1545_792, res_471);
								}
								{
								   obj_t res_2678;
								   obj_t slots_2677;
								   slots_2677 = arg1540_790;
								   res_2678 = arg1542_791;
								   res_471 = res_2678;
								   slots_470 = slots_2677;
								   goto loop_472;
								}
							     }
							  }
						       }
						     else
						       {
							  goto tag_170_4_491;
						       }
						  }
						else
						  {
						     goto tag_170_4_491;
						  }
					     }
					   else
					     {
						goto tag_170_4_491;
					     }
					}
				   }
			      }
			 }
		      }
		    else
		      {
			 goto tag_170_4_491;
		      }
		 }
	      }
	 }
      }
   }
}


/* find-default-attr */ obj_t 
find_default_attr_77_object_slots(obj_t attr_911)
{
 find_default_attr_77_object_slots:
   if (PAIRP(attr_911))
     {
	{
	   obj_t e_103_175_917;
	   e_103_175_917 = CAR(attr_911);
	   if (PAIRP(e_103_175_917))
	     {
		obj_t cdr_107_0_919;
		cdr_107_0_919 = CDR(e_103_175_917);
		{
		   bool_t test_2686;
		   {
		      obj_t aux_2689;
		      obj_t aux_2687;
		      aux_2689 = CNST_TABLE_REF(((long) 6));
		      aux_2687 = CAR(e_103_175_917);
		      test_2686 = (aux_2687 == aux_2689);
		   }
		   if (test_2686)
		     {
			if (PAIRP(cdr_107_0_919))
			  {
			     bool_t test_2694;
			     {
				obj_t aux_2695;
				aux_2695 = CDR(cdr_107_0_919);
				test_2694 = (aux_2695 == BNIL);
			     }
			     if (test_2694)
			       {
				  obj_t aux_2698;
				  aux_2698 = CAR(cdr_107_0_919);
				  return MAKE_PAIR(BTRUE, aux_2698);
			       }
			     else
			       {
				tag_102_241_916:
				  {
				     obj_t attr_2701;
				     attr_2701 = CDR(attr_911);
				     attr_911 = attr_2701;
				     goto find_default_attr_77_object_slots;
				  }
			       }
			  }
			else
			  {
			     goto tag_102_241_916;
			  }
		     }
		   else
		     {
			goto tag_102_241_916;
		     }
		}
	     }
	   else
	     {
		goto tag_102_241_916;
	     }
	}
     }
   else
     {
	return CNST_TABLE_REF(((long) 7));
     }
}


/* find-assert-attr */ obj_t 
find_assert_attr_93_object_slots(obj_t attr_882)
{
 find_assert_attr_93_object_slots:
   if (PAIRP(attr_882))
     {
	obj_t value_885;
	{
	   obj_t e_114_227_888;
	   e_114_227_888 = CAR(attr_882);
	   if (PAIRP(e_114_227_888))
	     {
		obj_t cdr_118_57_890;
		cdr_118_57_890 = CDR(e_114_227_888);
		{
		   bool_t test_2710;
		   {
		      obj_t aux_2713;
		      obj_t aux_2711;
		      aux_2713 = CNST_TABLE_REF(((long) 9));
		      aux_2711 = CAR(e_114_227_888);
		      test_2710 = (aux_2711 == aux_2713);
		   }
		   if (test_2710)
		     {
			if (PAIRP(cdr_118_57_890))
			  {
			     obj_t car_120_226_893;
			     obj_t cdr_121_50_894;
			     car_120_226_893 = CAR(cdr_118_57_890);
			     cdr_121_50_894 = CDR(cdr_118_57_890);
			     if (PAIRP(car_120_226_893))
			       {
				  bool_t test_2722;
				  {
				     obj_t aux_2723;
				     aux_2723 = CAR(car_120_226_893);
				     test_2722 = SYMBOLP(aux_2723);
				  }
				  if (test_2722)
				    {
				       bool_t test_2726;
				       {
					  obj_t aux_2727;
					  aux_2727 = CDR(car_120_226_893);
					  test_2726 = (aux_2727 == BNIL);
				       }
				       if (test_2726)
					 {
					    if (PAIRP(cdr_121_50_894))
					      {
						 bool_t test_2732;
						 {
						    obj_t aux_2733;
						    aux_2733 = CDR(cdr_121_50_894);
						    test_2732 = (aux_2733 == BNIL);
						 }
						 if (test_2732)
						   {
						      value_885 = CAR(cdr_121_50_894);
						      {
							 obj_t aux_2738;
							 obj_t aux_2736;
							 aux_2738 = CNST_TABLE_REF(((long) 8));
							 aux_2736 = CAR(attr_882);
							 SET_CAR(aux_2736, aux_2738);
						      }
						      return CAR(attr_882);
						   }
						 else
						   {
						    tag_113_246_887:
						      {
							 obj_t attr_2743;
							 attr_2743 = CDR(attr_882);
							 attr_882 = attr_2743;
							 goto find_assert_attr_93_object_slots;
						      }
						   }
					      }
					    else
					      {
						 goto tag_113_246_887;
					      }
					 }
				       else
					 {
					    goto tag_113_246_887;
					 }
				    }
				  else
				    {
				       goto tag_113_246_887;
				    }
			       }
			     else
			       {
				  goto tag_113_246_887;
			       }
			  }
			else
			  {
			     goto tag_113_246_887;
			  }
		     }
		   else
		     {
			goto tag_113_246_887;
		     }
		}
	     }
	   else
	     {
		goto tag_113_246_887;
	     }
	}
     }
   else
     {
	return BFALSE;
     }
}


/* find-virtual-attr */ obj_t 
find_virtual_attr_39_object_slots(obj_t attr_847)
{
   {
      obj_t attr_849;
      obj_t get_850;
      obj_t set_851;
      attr_849 = attr_847;
      get_850 = BFALSE;
      set_851 = BFALSE;
    loop_852:
      if (PAIRP(attr_849))
	{
	   {
	      obj_t e_131_104_859;
	      e_131_104_859 = CAR(attr_849);
	      if (PAIRP(e_131_104_859))
		{
		   obj_t cdr_136_29_861;
		   cdr_136_29_861 = CDR(e_131_104_859);
		   {
		      bool_t test_2751;
		      {
			 obj_t aux_2754;
			 obj_t aux_2752;
			 aux_2754 = CNST_TABLE_REF(((long) 10));
			 aux_2752 = CAR(e_131_104_859);
			 test_2751 = (aux_2752 == aux_2754);
		      }
		      if (test_2751)
			{
			   if (PAIRP(cdr_136_29_861))
			     {
				bool_t test_2759;
				{
				   obj_t aux_2760;
				   aux_2760 = CDR(cdr_136_29_861);
				   test_2759 = (aux_2760 == BNIL);
				}
				if (test_2759)
				  {
				     obj_t get_2765;
				     obj_t attr_2763;
				     attr_2763 = CDR(attr_849);
				     get_2765 = CAR(cdr_136_29_861);
				     get_850 = get_2765;
				     attr_849 = attr_2763;
				     goto loop_852;
				  }
				else
				  {
				   tag_130_214_858:
				     {
					obj_t attr_2767;
					attr_2767 = CDR(attr_849);
					attr_849 = attr_2767;
					goto loop_852;
				     }
				  }
			     }
			   else
			     {
				goto tag_130_214_858;
			     }
			}
		      else
			{
			   bool_t test_2769;
			   {
			      obj_t aux_2772;
			      obj_t aux_2770;
			      aux_2772 = CNST_TABLE_REF(((long) 11));
			      aux_2770 = CAR(e_131_104_859);
			      test_2769 = (aux_2770 == aux_2772);
			   }
			   if (test_2769)
			     {
				if (PAIRP(cdr_136_29_861))
				  {
				     bool_t test_2777;
				     {
					obj_t aux_2778;
					aux_2778 = CDR(cdr_136_29_861);
					test_2777 = (aux_2778 == BNIL);
				     }
				     if (test_2777)
				       {
					  obj_t set_2783;
					  obj_t attr_2781;
					  attr_2781 = CDR(attr_849);
					  set_2783 = CAR(cdr_136_29_861);
					  set_851 = set_2783;
					  attr_849 = attr_2781;
					  goto loop_852;
				       }
				     else
				       {
					  goto tag_130_214_858;
				       }
				  }
				else
				  {
				     goto tag_130_214_858;
				  }
			     }
			   else
			     {
				goto tag_130_214_858;
			     }
			}
		   }
		}
	      else
		{
		   goto tag_130_214_858;
		}
	   }
	}
      else
	{
	   return MAKE_PAIR(get_850, set_851);
	}
   }
}


/* _make-class-slots */ obj_t 
_make_class_slots_155_object_slots(obj_t env_2052, obj_t slots_2053, obj_t super_2054, obj_t src_2055)
{
   return make_class_slots_205_object_slots(slots_2053, super_2054, src_2055);
}


/* scheme-symbol->c-string */ obj_t 
scheme_symbol__c_string_183_object_slots(obj_t symbol_68)
{
   if (CBOOL(_case_sensitive__90_engine_param))
     {
	return id__name_228_ast_ident(symbol_68);
     }
   else
     {
	obj_t arg1661_935;
	arg1661_935 = id__name_228_ast_ident(symbol_68);
	return string_downcase_77___r4_strings_6_7(arg1661_935);
     }
}


/* method-init */ obj_t 
method_init_76_object_slots()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_slots()
{
   module_initialization_70_tools_error(((long) 0), "OBJECT_SLOTS");
   module_initialization_70_type_type(((long) 0), "OBJECT_SLOTS");
   module_initialization_70_type_cache(((long) 0), "OBJECT_SLOTS");
   module_initialization_70_ast_var(((long) 0), "OBJECT_SLOTS");
   module_initialization_70_ast_ident(((long) 0), "OBJECT_SLOTS");
   module_initialization_70_object_class(((long) 0), "OBJECT_SLOTS");
   return module_initialization_70_engine_param(((long) 0), "OBJECT_SLOTS");
}
