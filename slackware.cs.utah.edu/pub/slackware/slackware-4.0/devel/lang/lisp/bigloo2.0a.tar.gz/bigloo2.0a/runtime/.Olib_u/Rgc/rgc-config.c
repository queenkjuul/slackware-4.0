/*===========================================================================*/
/*   (Rgc/rgc-config.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
extern bool_t rgc_alphabetic__209___rgc_config(obj_t);
static obj_t symbol1234___rgc_config = BUNSPEC;
static obj_t symbol1229___rgc_config = BUNSPEC;
static obj_t symbol1225___rgc_config = BUNSPEC;
static obj_t symbol1221___rgc_config = BUNSPEC;
static obj_t symbol1215___rgc_config = BUNSPEC;
extern bool_t rgc_char__84___rgc_config(obj_t);
static obj_t symbol1199___rgc_config = BUNSPEC;
static obj_t symbol1210___rgc_config = BUNSPEC;
static obj_t symbol1208___rgc_config = BUNSPEC;
static obj_t symbol1194___rgc_config = BUNSPEC;
static obj_t symbol1203___rgc_config = BUNSPEC;
static obj_t symbol1201___rgc_config = BUNSPEC;
static obj_t symbol1190___rgc_config = BUNSPEC;
static obj_t symbol1188___rgc_config = BUNSPEC;
static obj_t symbol1186___rgc_config = BUNSPEC;
static obj_t symbol1184___rgc_config = BUNSPEC;
static obj_t list1228___rgc_config = BUNSPEC;
static obj_t list1226___rgc_config = BUNSPEC;
static obj_t list1224___rgc_config = BUNSPEC;
static obj_t toplevel_init_63___rgc_config();
static obj_t list1222___rgc_config = BUNSPEC;
static obj_t list1220___rgc_config = BUNSPEC;
static obj_t list1218___rgc_config = BUNSPEC;
static obj_t list1217___rgc_config = BUNSPEC;
static obj_t list1216___rgc_config = BUNSPEC;
static obj_t list1214___rgc_config = BUNSPEC;
static obj_t list1212___rgc_config = BUNSPEC;
static obj_t list1211___rgc_config = BUNSPEC;
static obj_t list1209___rgc_config = BUNSPEC;
static obj_t list1198___rgc_config = BUNSPEC;
static obj_t list1207___rgc_config = BUNSPEC;
static obj_t list1196___rgc_config = BUNSPEC;
static obj_t list1195___rgc_config = BUNSPEC;
static obj_t list1205___rgc_config = BUNSPEC;
static obj_t list1204___rgc_config = BUNSPEC;
static obj_t list1193___rgc_config = BUNSPEC;
static obj_t list1202___rgc_config = BUNSPEC;
static obj_t list1191___rgc_config = BUNSPEC;
static obj_t list1189___rgc_config = BUNSPEC;
static obj_t list1200___rgc_config = BUNSPEC;
static obj_t list1187___rgc_config = BUNSPEC;
static obj_t list1185___rgc_config = BUNSPEC;
static obj_t list1183___rgc_config = BUNSPEC;
static obj_t list1182___rgc_config = BUNSPEC;
static obj_t _ascii_config__87___rgc_config = BUNSPEC;
extern obj_t rgc_downcase_36___rgc_config(obj_t);
obj_t _rgc_optim__189___rgc_config = BUNSPEC;
extern obj_t rgc_upcase_160___rgc_config(obj_t);
extern obj_t create_struct(obj_t, long);
static obj_t _rgc_config__122___rgc_config = BUNSPEC;
static obj_t _rgc_max_char_138___rgc_config(obj_t);
static obj_t _rgc_env_126___rgc_config(obj_t);
static obj_t _rgc_alphabetic__243___rgc_config(obj_t, obj_t);
extern obj_t module_initialization_70___rgc_config(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t arg1015___rgc_config(obj_t, obj_t);
static obj_t arg1014___rgc_config(obj_t, obj_t);
static obj_t arg1013___rgc_config(obj_t, obj_t);
static obj_t arg1012___rgc_config(obj_t, obj_t);
extern obj_t rgc_env_91___rgc_config();
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__116___r4_numbers_6_5(obj_t, obj_t);
static obj_t _rgc_downcase_71___rgc_config(obj_t, obj_t);
static obj_t _rgc_char__224___rgc_config(obj_t, obj_t);
static obj_t imported_modules_init_94___rgc_config();
extern obj_t rgc_max_char_237___rgc_config();
static obj_t require_initialization_114___rgc_config = BUNSPEC;
static obj_t _rgc_upcase_243___rgc_config(obj_t, obj_t);
static obj_t cnst_init_137___rgc_config();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( rgc_env_env_87___rgc_config, _rgc_env_126___rgc_config1237, _rgc_env_126___rgc_config, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( rgc_max_char_env_30___rgc_config, _rgc_max_char_138___rgc_config1238, _rgc_max_char_138___rgc_config, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( rgc_downcase_env_174___rgc_config, _rgc_downcase_71___rgc_config1239, _rgc_downcase_71___rgc_config, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_alphabetic__env_78___rgc_config, _rgc_alphabetic__243___rgc_config1240, _rgc_alphabetic__243___rgc_config, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_upcase_env_157___rgc_config, _rgc_upcase_243___rgc_config1241, _rgc_upcase_243___rgc_config, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgc_char__env_72___rgc_config, _rgc_char__224___rgc_config1242, _rgc_char__224___rgc_config, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1233___rgc_config, arg1012___rgc_config1243, arg1012___rgc_config, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1232___rgc_config, arg1013___rgc_config1244, arg1013___rgc_config, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1231___rgc_config, arg1014___rgc_config1245, arg1014___rgc_config, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1230___rgc_config, arg1015___rgc_config1246, arg1015___rgc_config, 0L, 1 );
DEFINE_STRING( string1235___rgc_config, string1235___rgc_config1247, "ascii", 5 );
DEFINE_STRING( string1227___rgc_config, string1227___rgc_config1248, " \t\n", 3 );
DEFINE_STRING( string1223___rgc_config, string1223___rgc_config1249, ".,;!?", 5 );
DEFINE_STRING( string1219___rgc_config, string1219___rgc_config1250, "az09", 4 );
DEFINE_STRING( string1213___rgc_config, string1213___rgc_config1251, "af09", 4 );
DEFINE_STRING( string1197___rgc_config, string1197___rgc_config1252, "AZ", 2 );
DEFINE_STRING( string1206___rgc_config, string1206___rgc_config1253, "09", 2 );
DEFINE_STRING( string1192___rgc_config, string1192___rgc_config1254, "az", 2 );


/* module-initialization */obj_t module_initialization_70___rgc_config(long checksum_716, char * from_717)
{
if(CBOOL(require_initialization_114___rgc_config)){
require_initialization_114___rgc_config = BBOOL(((bool_t)0));
cnst_init_137___rgc_config();
imported_modules_init_94___rgc_config();
toplevel_init_63___rgc_config();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc_config()
{
symbol1184___rgc_config = string_to_symbol("ALL");
symbol1186___rgc_config = string_to_symbol("OUT");
{
obj_t aux_726;
{
obj_t aux_727;
aux_727 = BCHAR(((unsigned char)'\n'));
aux_726 = MAKE_PAIR(aux_727, BNIL);
}
list1185___rgc_config = MAKE_PAIR(symbol1186___rgc_config, aux_726);
}
{
obj_t aux_731;
aux_731 = MAKE_PAIR(list1185___rgc_config, BNIL);
list1183___rgc_config = MAKE_PAIR(symbol1184___rgc_config, aux_731);
}
symbol1188___rgc_config = string_to_symbol("LOWER");
symbol1190___rgc_config = string_to_symbol("IN");
list1191___rgc_config = MAKE_PAIR(string1192___rgc_config, BNIL);
{
obj_t aux_737;
aux_737 = MAKE_PAIR(list1191___rgc_config, BNIL);
list1189___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_737);
}
{
obj_t aux_740;
aux_740 = MAKE_PAIR(list1189___rgc_config, BNIL);
list1187___rgc_config = MAKE_PAIR(symbol1188___rgc_config, aux_740);
}
symbol1194___rgc_config = string_to_symbol("UPPER");
list1196___rgc_config = MAKE_PAIR(string1197___rgc_config, BNIL);
{
obj_t aux_745;
aux_745 = MAKE_PAIR(list1196___rgc_config, BNIL);
list1195___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_745);
}
{
obj_t aux_748;
aux_748 = MAKE_PAIR(list1195___rgc_config, BNIL);
list1193___rgc_config = MAKE_PAIR(symbol1194___rgc_config, aux_748);
}
symbol1199___rgc_config = string_to_symbol("ALPHA");
symbol1201___rgc_config = string_to_symbol("OR");
{
obj_t aux_753;
{
obj_t aux_754;
aux_754 = MAKE_PAIR(symbol1194___rgc_config, BNIL);
aux_753 = MAKE_PAIR(symbol1188___rgc_config, aux_754);
}
list1200___rgc_config = MAKE_PAIR(symbol1201___rgc_config, aux_753);
}
{
obj_t aux_758;
aux_758 = MAKE_PAIR(list1200___rgc_config, BNIL);
list1198___rgc_config = MAKE_PAIR(symbol1199___rgc_config, aux_758);
}
symbol1203___rgc_config = string_to_symbol("DIGIT");
list1205___rgc_config = MAKE_PAIR(string1206___rgc_config, BNIL);
{
obj_t aux_763;
aux_763 = MAKE_PAIR(list1205___rgc_config, BNIL);
list1204___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_763);
}
{
obj_t aux_766;
aux_766 = MAKE_PAIR(list1204___rgc_config, BNIL);
list1202___rgc_config = MAKE_PAIR(symbol1203___rgc_config, aux_766);
}
symbol1208___rgc_config = string_to_symbol("XDIGIT");
symbol1210___rgc_config = string_to_symbol("UNCASE");
list1212___rgc_config = MAKE_PAIR(string1213___rgc_config, BNIL);
{
obj_t aux_772;
aux_772 = MAKE_PAIR(list1212___rgc_config, BNIL);
list1211___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_772);
}
{
obj_t aux_775;
aux_775 = MAKE_PAIR(list1211___rgc_config, BNIL);
list1209___rgc_config = MAKE_PAIR(symbol1210___rgc_config, aux_775);
}
{
obj_t aux_778;
aux_778 = MAKE_PAIR(list1209___rgc_config, BNIL);
list1207___rgc_config = MAKE_PAIR(symbol1208___rgc_config, aux_778);
}
symbol1215___rgc_config = string_to_symbol("ALNUM");
list1218___rgc_config = MAKE_PAIR(string1219___rgc_config, BNIL);
{
obj_t aux_783;
aux_783 = MAKE_PAIR(list1218___rgc_config, BNIL);
list1217___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_783);
}
{
obj_t aux_786;
aux_786 = MAKE_PAIR(list1217___rgc_config, BNIL);
list1216___rgc_config = MAKE_PAIR(symbol1210___rgc_config, aux_786);
}
{
obj_t aux_789;
aux_789 = MAKE_PAIR(list1216___rgc_config, BNIL);
list1214___rgc_config = MAKE_PAIR(symbol1215___rgc_config, aux_789);
}
symbol1221___rgc_config = string_to_symbol("PUNCT");
{
obj_t aux_793;
aux_793 = MAKE_PAIR(string1223___rgc_config, BNIL);
list1222___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_793);
}
{
obj_t aux_796;
aux_796 = MAKE_PAIR(list1222___rgc_config, BNIL);
list1220___rgc_config = MAKE_PAIR(symbol1221___rgc_config, aux_796);
}
symbol1225___rgc_config = string_to_symbol("BLANK");
{
obj_t aux_800;
aux_800 = MAKE_PAIR(string1227___rgc_config, BNIL);
list1226___rgc_config = MAKE_PAIR(symbol1190___rgc_config, aux_800);
}
{
obj_t aux_803;
aux_803 = MAKE_PAIR(list1226___rgc_config, BNIL);
list1224___rgc_config = MAKE_PAIR(symbol1225___rgc_config, aux_803);
}
symbol1229___rgc_config = string_to_symbol("SPACE");
{
obj_t aux_807;
{
obj_t aux_808;
aux_808 = BCHAR(((unsigned char)' '));
aux_807 = MAKE_PAIR(aux_808, BNIL);
}
list1228___rgc_config = MAKE_PAIR(symbol1229___rgc_config, aux_807);
}
{
obj_t aux_812;
{
obj_t aux_813;
{
obj_t aux_814;
{
obj_t aux_815;
{
obj_t aux_816;
{
obj_t aux_817;
{
obj_t aux_818;
{
obj_t aux_819;
{
obj_t aux_820;
aux_820 = MAKE_PAIR(list1228___rgc_config, BNIL);
aux_819 = MAKE_PAIR(list1224___rgc_config, aux_820);
}
aux_818 = MAKE_PAIR(list1220___rgc_config, aux_819);
}
aux_817 = MAKE_PAIR(list1214___rgc_config, aux_818);
}
aux_816 = MAKE_PAIR(list1207___rgc_config, aux_817);
}
aux_815 = MAKE_PAIR(list1202___rgc_config, aux_816);
}
aux_814 = MAKE_PAIR(list1198___rgc_config, aux_815);
}
aux_813 = MAKE_PAIR(list1193___rgc_config, aux_814);
}
aux_812 = MAKE_PAIR(list1187___rgc_config, aux_813);
}
list1182___rgc_config = MAKE_PAIR(list1183___rgc_config, aux_812);
}
return (symbol1234___rgc_config = string_to_symbol("RGC-CONFIG"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___rgc_config()
{
_rgc_optim__189___rgc_config = BFALSE;
{
obj_t arg1016_350;
arg1016_350 = list1182___rgc_config;
{
obj_t arg1015_696;
obj_t arg1014_695;
obj_t arg1013_694;
obj_t arg1012_693;
arg1015_696 = proc1230___rgc_config;
arg1014_695 = proc1231___rgc_config;
arg1013_694 = proc1232___rgc_config;
arg1012_693 = proc1233___rgc_config;
{
obj_t new_536;
new_536 = create_struct(symbol1234___rgc_config, ((long)7));
STRUCT_SET(new_536, ((long)6), arg1016_350);
STRUCT_SET(new_536, ((long)5), arg1015_696);
STRUCT_SET(new_536, ((long)4), arg1014_695);
STRUCT_SET(new_536, ((long)3), arg1013_694);
STRUCT_SET(new_536, ((long)2), arg1012_693);
{
obj_t aux_838;
aux_838 = BINT(((long)256));
STRUCT_SET(new_536, ((long)1), aux_838);
}
STRUCT_SET(new_536, ((long)0), string1235___rgc_config);
_ascii_config__87___rgc_config = new_536;
}
}
}
return (_rgc_config__122___rgc_config = _ascii_config__87___rgc_config,
BUNSPEC);
}


/* arg1012 */obj_t arg1012___rgc_config(obj_t env_697, obj_t x_698)
{
{
obj_t x_351;
{
bool_t aux_842;
x_351 = x_698;
if(_2__206___r4_numbers_6_5(x_351, BINT(((long)0)))){
if(_2__116___r4_numbers_6_5(x_351, BINT(((long)256)))){
aux_842 = CHARP(x_351);
}
 else {
aux_842 = ((bool_t)0);
}
}
 else {
aux_842 = ((bool_t)0);
}
return BBOOL(aux_842);
}
}
}


/* arg1013 */obj_t arg1013___rgc_config(obj_t env_699, obj_t x_700)
{
{
obj_t x_355;
{
bool_t aux_851;
x_355 = x_700;
if(_2__206___r4_numbers_6_5(x_355, BINT(((long)0)))){
if(_2__116___r4_numbers_6_5(x_355, BINT(((long)256)))){
unsigned char c_571;
{
unsigned char aux_858;
{
long aux_859;
aux_859 = (long)CINT(x_355);
aux_858 = (aux_859);
}
c_571 = toupper(aux_858);
}
if((c_571>=((unsigned char)'A'))){
aux_851 = (c_571<=((unsigned char)'Z'));
}
 else {
aux_851 = ((bool_t)0);
}
}
 else {
aux_851 = ((bool_t)0);
}
}
 else {
aux_851 = ((bool_t)0);
}
return BBOOL(aux_851);
}
}
}


/* arg1014 */obj_t arg1014___rgc_config(obj_t env_701, obj_t x_702)
{
{
obj_t x_360;
{
long aux_867;
x_360 = x_702;
{
unsigned char aux_868;
{
unsigned char aux_869;
{
long aux_870;
aux_870 = (long)CINT(x_360);
aux_869 = (aux_870);
}
aux_868 = toupper(aux_869);
}
aux_867 = (aux_868);
}
return BINT(aux_867);
}
}
}


/* arg1015 */obj_t arg1015___rgc_config(obj_t env_703, obj_t x_704)
{
{
obj_t x_364;
{
long aux_876;
x_364 = x_704;
{
unsigned char aux_877;
{
unsigned char aux_878;
{
long aux_879;
aux_879 = (long)CINT(x_364);
aux_878 = (aux_879);
}
aux_877 = tolower(aux_878);
}
aux_876 = (aux_877);
}
return BINT(aux_876);
}
}
}


/* rgc-max-char */obj_t rgc_max_char_237___rgc_config()
{
return STRUCT_REF(_rgc_config__122___rgc_config, ((long)1));
}


/* _rgc-max-char */obj_t _rgc_max_char_138___rgc_config(obj_t env_705)
{
return rgc_max_char_237___rgc_config();
}


/* rgc-char? */bool_t rgc_char__84___rgc_config(obj_t char_31)
{
{
obj_t fun1044_663;
fun1044_663 = STRUCT_REF(_rgc_config__122___rgc_config, ((long)2));
{
obj_t aux_888;
aux_888 = PROCEDURE_ENTRY(fun1044_663)(fun1044_663, char_31, BEOA);
return CBOOL(aux_888);
}
}
}


/* _rgc-char? */obj_t _rgc_char__224___rgc_config(obj_t env_706, obj_t char_707)
{
{
bool_t aux_892;
aux_892 = rgc_char__84___rgc_config(char_707);
return BBOOL(aux_892);
}
}


/* rgc-alphabetic? */bool_t rgc_alphabetic__209___rgc_config(obj_t char_32)
{
{
obj_t fun1045_667;
fun1045_667 = STRUCT_REF(_rgc_config__122___rgc_config, ((long)3));
{
obj_t aux_896;
aux_896 = PROCEDURE_ENTRY(fun1045_667)(fun1045_667, char_32, BEOA);
return CBOOL(aux_896);
}
}
}


/* _rgc-alphabetic? */obj_t _rgc_alphabetic__243___rgc_config(obj_t env_708, obj_t char_709)
{
{
bool_t aux_900;
aux_900 = rgc_alphabetic__209___rgc_config(char_709);
return BBOOL(aux_900);
}
}


/* rgc-upcase */obj_t rgc_upcase_160___rgc_config(obj_t char_33)
{
{
obj_t fun1046_671;
fun1046_671 = STRUCT_REF(_rgc_config__122___rgc_config, ((long)4));
return PROCEDURE_ENTRY(fun1046_671)(fun1046_671, char_33, BEOA);
}
}


/* _rgc-upcase */obj_t _rgc_upcase_243___rgc_config(obj_t env_710, obj_t char_711)
{
return rgc_upcase_160___rgc_config(char_711);
}


/* rgc-downcase */obj_t rgc_downcase_36___rgc_config(obj_t char_34)
{
{
obj_t fun1047_675;
fun1047_675 = STRUCT_REF(_rgc_config__122___rgc_config, ((long)5));
return PROCEDURE_ENTRY(fun1047_675)(fun1047_675, char_34, BEOA);
}
}


/* _rgc-downcase */obj_t _rgc_downcase_71___rgc_config(obj_t env_712, obj_t char_713)
{
return rgc_downcase_36___rgc_config(char_713);
}


/* rgc-env */obj_t rgc_env_91___rgc_config()
{
return STRUCT_REF(_rgc_config__122___rgc_config, ((long)6));
}


/* _rgc-env */obj_t _rgc_env_126___rgc_config(obj_t env_714)
{
return rgc_env_91___rgc_config();
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc_config()
{
return module_initialization_70___error(((long)0), "__RGC_CONFIG");
}

