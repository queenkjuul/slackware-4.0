/*===========================================================================*/
/*   (Engine/interp.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t _src_files__222_engine_param;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t warning___error(obj_t);
extern obj_t interp_engine_interp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _interp_engine_interp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_engine_interp(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t command_line;
static obj_t imported_modules_init_94_engine_interp();
extern bool_t bigloo_strcmp(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_engine_interp();
static obj_t interp_parse_args_247_engine_interp(obj_t);
extern obj_t print___r4_output_6_10_3(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t loadq___eval(obj_t);
extern obj_t repl___eval();
extern obj_t _bigloo_interpreter__95___reader;
static obj_t require_initialization_114_engine_interp = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(interp_env_241_engine_interp, _interp_engine_interp1163, _interp_engine_interp, 0L, 6);
DEFINE_STRING(string1161_engine_interp, string1161_engine_interp1164, "-i", 2);
DEFINE_STRING(string1159_engine_interp, string1159_engine_interp1165, "Can't file startup file -- ", 27);
DEFINE_STRING(string1160_engine_interp, string1160_engine_interp1166, "interp", 6);
DEFINE_STRING(string1158_engine_interp, string1158_engine_interp1167, "Welcome to the interpreter", 26);


/* module-initialization */ obj_t 
module_initialization_70_engine_interp(long checksum_81, char *from_82)
{
   if (CBOOL(require_initialization_114_engine_interp))
     {
	require_initialization_114_engine_interp = BBOOL(((bool_t) 0));
	library_modules_init_112_engine_interp();
	imported_modules_init_94_engine_interp();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_engine_interp()
{
   module_initialization_70___error(((long) 0), "ENGINE_INTERP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "ENGINE_INTERP");
   module_initialization_70___r4_output_6_10_3(((long) 0), "ENGINE_INTERP");
   module_initialization_70___eval(((long) 0), "ENGINE_INTERP");
   module_initialization_70___reader(((long) 0), "ENGINE_INTERP");
   return BUNSPEC;
}


/* interp */ obj_t 
interp_engine_interp(obj_t version_1, obj_t verbose_2, obj_t files_3, obj_t startup_4, obj_t path_5, obj_t args_6)
{
   _bigloo_interpreter__95___reader = BTRUE;
   {
      bool_t test_93;
      {
	 bool_t test_94;
	 {
	    long aux_95;
	    aux_95 = (long) CINT(verbose_2);
	    test_94 = (aux_95 >= ((long) 0));
	 }
	 if (test_94)
	   {
	      if (PAIRP(files_3))
		{
		   test_93 = ((bool_t) 0);
		}
	      else
		{
		   test_93 = ((bool_t) 1);
		}
	   }
	 else
	   {
	      test_93 = ((bool_t) 0);
	   }
      }
      if (test_93)
	{
	   PROCEDURE_ENTRY(version_1) (version_1, BEOA);
	   {
	      obj_t list1005_9;
	      list1005_9 = MAKE_PAIR(string1158_engine_interp, BNIL);
	      print___r4_output_6_10_3(list1005_9);
	   }
	}
      else
	{
	   BUNSPEC;
	}
   }
   command_line = interp_parse_args_247_engine_interp(args_6);
   if (STRINGP(startup_4))
     {
	obj_t path_15;
	{
	   obj_t home_24;
	   {
	      bool_t test1190_54;
	      test1190_54 = (long) getenv("HOME");
	      if (test1190_54)
		{
		   char *aux_109;
		   aux_109 = (char *) getenv("HOME");
		   home_24 = string_to_bstring(aux_109);
		}
	      else
		{
		   home_24 = BFALSE;
		}
	   }
	   if (STRINGP(home_24))
	     {
		path_15 = MAKE_PAIR(home_24, path_5);
	     }
	   else
	     {
		path_15 = path_5;
	     }
	}
	{
	   obj_t fstartup_16;
	   fstartup_16 = find_file_path_55_tools_file(startup_4, path_15);
	   if (CBOOL(fstartup_16))
	     {
		loadq___eval(startup_4);
	     }
	   else
	     {
		obj_t list1013_17;
		{
		   obj_t arg1016_19;
		   {
		      obj_t arg1018_20;
		      {
			 obj_t arg1025_22;
			 arg1025_22 = MAKE_PAIR(startup_4, BNIL);
			 arg1018_20 = MAKE_PAIR(string1159_engine_interp, arg1025_22);
		      }
		      {
			 obj_t aux_121;
			 aux_121 = BCHAR(((unsigned char) '\n'));
			 arg1016_19 = MAKE_PAIR(aux_121, arg1018_20);
		      }
		   }
		   list1013_17 = MAKE_PAIR(string1160_engine_interp, arg1016_19);
		}
		warning___error(list1013_17);
	     }
	}
     }
   else
     {
	BUNSPEC;
     }
   if (PAIRP(files_3))
     {
	obj_t l1002_27;
	{
	   bool_t aux_128;
	   l1002_27 = files_3;
	 lname1003_28:
	   if (PAIRP(l1002_27))
	     {
		loadq___eval(CAR(l1002_27));
		{
		   obj_t l1002_133;
		   l1002_133 = CDR(l1002_27);
		   l1002_27 = l1002_133;
		   goto lname1003_28;
		}
	     }
	   else
	     {
		aux_128 = ((bool_t) 1);
	     }
	   BBOOL(aux_128);
	}
     }
   else
     {
	repl___eval();
     }
   return BINT(((long) 0));
}


/* _interp */ obj_t 
_interp_engine_interp(obj_t env_74, obj_t version_75, obj_t verbose_76, obj_t files_77, obj_t startup_78, obj_t path_79, obj_t args_80)
{
   return interp_engine_interp(version_75, verbose_76, files_77, startup_78, path_79, args_80);
}


/* interp-parse-args */ obj_t 
interp_parse_args_247_engine_interp(obj_t args_7)
{
   {
      obj_t args_32;
      obj_t res_33;
      args_32 = CDR(args_7);
      res_33 = BNIL;
    loop_34:
      if (NULLP(args_32))
	{
	   return append_2_18___r4_pairs_and_lists_6_3(_src_files__222_engine_param, reverse___r4_pairs_and_lists_6_3(res_33));
	}
      else
	{
	   bool_t test1054_39;
	   {
	      obj_t aux_143;
	      aux_143 = CAR(args_32);
	      test1054_39 = bigloo_strcmp(aux_143, string1161_engine_interp);
	   }
	   if (test1054_39)
	     {
		{
		   obj_t args_147;
		   args_147 = CDR(args_32);
		   args_32 = args_147;
		   goto loop_34;
		}
	     }
	   else
	     {
		bool_t test1067_41;
		{
		   obj_t aux_149;
		   aux_149 = member___r4_pairs_and_lists_6_3(CAR(args_32), _src_files__222_engine_param);
		   test1067_41 = CBOOL(aux_149);
		}
		if (test1067_41)
		  {
		     {
			obj_t args_154;
			args_154 = CDR(args_32);
			args_32 = args_154;
			goto loop_34;
		     }
		  }
		else
		  {
		     {
			obj_t arg1137_43;
			obj_t arg1142_44;
			arg1137_43 = CDR(args_32);
			{
			   obj_t aux_157;
			   aux_157 = CAR(args_32);
			   arg1142_44 = MAKE_PAIR(aux_157, res_33);
			}
			{
			   obj_t res_161;
			   obj_t args_160;
			   args_160 = arg1137_43;
			   res_161 = arg1142_44;
			   res_33 = res_161;
			   args_32 = args_160;
			   goto loop_34;
			}
		     }
		  }
	     }
	}
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_engine_interp()
{
   module_initialization_70_engine_param(((long) 0), "ENGINE_INTERP");
   return module_initialization_70_tools_file(((long) 0), "ENGINE_INTERP");
}
