/*===========================================================================*/
/*   (User/user.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t _user_pass__208___eval;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t _user_pass_name__185___eval;
extern obj_t module_initialization_70_user_user(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t user_walk_92_user_user(obj_t);
static obj_t imported_modules_init_94_user_user();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t library_modules_init_112_user_user();
static obj_t toplevel_init_63_user_user();
extern obj_t open_input_string(obj_t);
static obj_t _user_walk_211_user_user(obj_t, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_user_user = BUNSPEC;
extern obj_t get_toplevel_unit_32_module_include();
static obj_t cnst_init_137_user_user();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(user_walk_env_29_user_user, _user_walk_211_user_user1221, _user_walk_211_user_user, 0L, 1);
DEFINE_STRING(string1214_user_user, string1214_user_user1222, "DONE DUMMY NOTHING PASS-STARTED ", 32);
DEFINE_STRING(string1213_user_user, string1213_user_user1223, "failure during postlude hook", 28);
DEFINE_STRING(string1212_user_user, string1212_user_user1224, " error", 6);
DEFINE_STRING(string1211_user_user, string1211_user_user1225, " occured, ending ...", 20);
DEFINE_STRING(string1209_user_user, string1209_user_user1226, "   . ", 5);
DEFINE_STRING(string1210_user_user, string1210_user_user1227, "failure during prelude hook", 27);


/* module-initialization */ obj_t 
module_initialization_70_user_user(long checksum_143, char *from_144)
{
   if (CBOOL(require_initialization_114_user_user))
     {
	require_initialization_114_user_user = BBOOL(((bool_t) 0));
	library_modules_init_112_user_user();
	cnst_init_137_user_user();
	imported_modules_init_94_user_user();
	toplevel_init_63_user_user();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_user_user()
{
   module_initialization_70___eval(((long) 0), "USER_USER");
   module_initialization_70___r4_output_6_10_3(((long) 0), "USER_USER");
   module_initialization_70___r4_numbers_6_5(((long) 0), "USER_USER");
   module_initialization_70___reader(((long) 0), "USER_USER");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_user_user()
{
   {
      obj_t cnst_port_138_135;
      cnst_port_138_135 = open_input_string(string1214_user_user);
      {
	 long i_136;
	 i_136 = ((long) 3);
       loop_137:
	 {
	    bool_t test1215_138;
	    test1215_138 = (i_136 == ((long) -1));
	    if (test1215_138)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1216_139;
		    {
		       obj_t list1217_140;
		       {
			  obj_t arg1219_141;
			  arg1219_141 = BNIL;
			  list1217_140 = MAKE_PAIR(cnst_port_138_135, arg1219_141);
		       }
		       arg1216_139 = read___reader(list1217_140);
		    }
		    CNST_TABLE_SET(i_136, arg1216_139);
		 }
		 {
		    int aux_142;
		    {
		       long aux_162;
		       aux_162 = (i_136 - ((long) 1));
		       aux_142 = (int) (aux_162);
		    }
		    {
		       long i_165;
		       i_165 = (long) (aux_142);
		       i_136 = i_165;
		       goto loop_137;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_user_user()
{
   return BUNSPEC;
}


/* user-walk */ obj_t 
user_walk_92_user_user(obj_t units_19)
{
   {
      bool_t test1033_37;
      {
	 obj_t obj_102;
	 obj_102 = _user_pass__208___eval;
	 test1033_37 = PROCEDUREP(obj_102);
      }
      if (test1033_37)
	{
	   obj_t unit_38;
	   unit_38 = get_toplevel_unit_32_module_include();
	   {
	      obj_t list1034_39;
	      {
		 obj_t arg1039_41;
		 {
		    obj_t arg1040_42;
		    {
		       obj_t aux_170;
		       aux_170 = BCHAR(((unsigned char) '\n'));
		       arg1040_42 = MAKE_PAIR(aux_170, BNIL);
		    }
		    arg1039_41 = MAKE_PAIR(_user_pass_name__185___eval, arg1040_42);
		 }
		 list1034_39 = MAKE_PAIR(string1209_user_user, arg1039_41);
	      }
	      verbose_tools_speek(BINT(((long) 1)), list1034_39);
	   }
	   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
	   _current_pass__25_engine_pass = _user_pass_name__185___eval;
	   {
	      obj_t hooks_44;
	      obj_t hnames_45;
	      hooks_44 = BNIL;
	      hnames_45 = BNIL;
	    loop_46:
	      if (NULLP(hooks_44))
		{
		   CNST_TABLE_REF(((long) 0));
		}
	      else
		{
		   bool_t test1068_51;
		   {
		      obj_t fun1145_56;
		      fun1145_56 = CAR(hooks_44);
		      {
			 obj_t aux_182;
			 aux_182 = PROCEDURE_ENTRY(fun1145_56) (fun1145_56, BEOA);
			 test1068_51 = CBOOL(aux_182);
		      }
		   }
		   if (test1068_51)
		     {
			{
			   obj_t hnames_189;
			   obj_t hooks_187;
			   hooks_187 = CDR(hooks_44);
			   hnames_189 = CDR(hnames_45);
			   hnames_45 = hnames_189;
			   hooks_44 = hooks_187;
			   goto loop_46;
			}
		     }
		   else
		     {
			internal_error_43_tools_error(_user_pass_name__185___eval, string1210_user_user, CAR(hnames_45));
		     }
		}
	   }
	   {
	      bool_t test_193;
	      {
		 obj_t aux_194;
		 aux_194 = STRUCT_REF(unit_38, ((long) 2));
		 test_193 = PROCEDUREP(aux_194);
	      }
	      if (test_193)
		{
		   CNST_TABLE_REF(((long) 1));
		}
	      else
		{
		   obj_t arg1150_58;
		   arg1150_58 = PROCEDURE_ENTRY(_user_pass__208___eval) (_user_pass__208___eval, STRUCT_REF(unit_38, ((long) 2)), BEOA);
		   STRUCT_SET(unit_38, ((long) 2), arg1150_58);
		}
	   }
	   {
	      obj_t value_61;
	      value_61 = CNST_TABLE_REF(((long) 2));
	      {
		 bool_t test1162_62;
		 {
		    long n1_121;
		    n1_121 = (long) CINT(_nb_error_on_pass__70_tools_error);
		    test1162_62 = (n1_121 > ((long) 0));
		 }
		 if (test1162_62)
		   {
		      {
			 char *arg1176_65;
			 {
			    bool_t test1194_72;
			    {
			       bool_t test1195_73;
			       {
				  obj_t obj_123;
				  obj_123 = _nb_error_on_pass__70_tools_error;
				  test1195_73 = INTEGERP(obj_123);
			       }
			       if (test1195_73)
				 {
				    test1194_72 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
				 }
			       else
				 {
				    test1194_72 = ((bool_t) 0);
				 }
			    }
			    if (test1194_72)
			      {
				 arg1176_65 = "s";
			      }
			    else
			      {
				 arg1176_65 = "";
			      }
			 }
			 {
			    obj_t list1188_67;
			    {
			       obj_t arg1190_68;
			       {
				  obj_t arg1191_69;
				  {
				     obj_t arg1192_70;
				     arg1192_70 = MAKE_PAIR(string1211_user_user, BNIL);
				     {
					obj_t aux_212;
					aux_212 = string_to_bstring(arg1176_65);
					arg1191_69 = MAKE_PAIR(aux_212, arg1192_70);
				     }
				  }
				  arg1190_68 = MAKE_PAIR(string1212_user_user, arg1191_69);
			       }
			       list1188_67 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1190_68);
			    }
			    fprint___r4_output_6_10_3(current_error_port, list1188_67);
			 }
		      }
		      {
			 obj_t res1208_125;
			 exit(((long) -1));
			 res1208_125 = BINT(((long) -1));
			 return res1208_125;
		      }
		   }
		 else
		   {
		      obj_t hooks_74;
		      obj_t hnames_75;
		      hooks_74 = BNIL;
		      hnames_75 = BNIL;
		    loop_76:
		      if (NULLP(hooks_74))
			{
			   return value_61;
			}
		      else
			{
			   bool_t test1200_81;
			   {
			      obj_t fun1206_86;
			      fun1206_86 = CAR(hooks_74);
			      {
				 obj_t aux_223;
				 aux_223 = PROCEDURE_ENTRY(fun1206_86) (fun1206_86, BEOA);
				 test1200_81 = CBOOL(aux_223);
			      }
			   }
			   if (test1200_81)
			     {
				{
				   obj_t hnames_230;
				   obj_t hooks_228;
				   hooks_228 = CDR(hooks_74);
				   hnames_230 = CDR(hnames_75);
				   hnames_75 = hnames_230;
				   hooks_74 = hooks_228;
				   goto loop_76;
				}
			     }
			   else
			     {
				return internal_error_43_tools_error(_current_pass__25_engine_pass, string1213_user_user, CAR(hnames_75));
			     }
			}
		   }
	      }
	   }
	}
      else
	{
	   return CNST_TABLE_REF(((long) 3));
	}
   }
}


/* _user-walk */ obj_t 
_user_walk_211_user_user(obj_t env_132, obj_t units_133)
{
   return user_walk_92_user_user(units_133);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_user_user()
{
   module_initialization_70_tools_speek(((long) 0), "USER_USER");
   module_initialization_70_tools_error(((long) 0), "USER_USER");
   module_initialization_70_engine_pass(((long) 0), "USER_USER");
   module_initialization_70_engine_param(((long) 0), "USER_USER");
   return module_initialization_70_module_include(((long) 0), "USER_USER");
}
