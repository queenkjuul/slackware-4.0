/*===========================================================================*/
/*   (R5rs/init5.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t symbol1142___r5_macro_4_3_init = BUNSPEC;
static obj_t symbol1141___r5_macro_4_3_init = BUNSPEC;
static bool_t _hygien_initialized___241___r5_macro_4_3_init;
static obj_t toplevel_init_63___r5_macro_4_3_init();
extern obj_t expand_syntax_236___r5_macro_4_3_init(obj_t);
static obj_t eval_init_57___r5_macro_4_3_init();
static obj_t _expand_syntax_35___r5_macro_4_3_init(obj_t, obj_t);
extern obj_t internal_expand_syntax_49___r5_syntax_expand(obj_t);
extern obj_t module_initialization_70___r5_macro_4_3_init(long, char *);
extern obj_t module_initialization_70___r5_syntax_usual(long, char *);
extern obj_t module_initialization_70___r5_syntax_expand(long, char *);
extern obj_t module_initialization_70___r5_syntax_misc(long, char *);
extern obj_t module_initialization_70___r5_syntax_prefs(long, char *);
extern obj_t module_initialization_70___r5_syntax_syntaxenv(long, char *);
extern obj_t module_initialization_70___r5_syntax_syntaxrules(long, char *);
extern obj_t initialize_usual_syntax__76___r5_syntax_usual();
extern obj_t define_primop__185___evenv(obj_t, obj_t);
extern obj_t define_primop_ref__105___evenv(obj_t, obj_t);
static obj_t imported_modules_init_94___r5_macro_4_3_init();
obj_t _hygien___100___r5_macro_4_3_init = BUNSPEC;
static obj_t require_initialization_114___r5_macro_4_3_init = BUNSPEC;
static obj_t cnst_init_137___r5_macro_4_3_init();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_syntax_env_94___r5_macro_4_3_init, _expand_syntax_35___r5_macro_4_3_init1144, _expand_syntax_35___r5_macro_4_3_init, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r5_macro_4_3_init(long checksum_460, char * from_461)
{
if(CBOOL(require_initialization_114___r5_macro_4_3_init)){
require_initialization_114___r5_macro_4_3_init = BBOOL(((bool_t)0));
cnst_init_137___r5_macro_4_3_init();
imported_modules_init_94___r5_macro_4_3_init();
eval_init_57___r5_macro_4_3_init();
toplevel_init_63___r5_macro_4_3_init();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r5_macro_4_3_init()
{
symbol1141___r5_macro_4_3_init = string_to_symbol("EXPAND-SYNTAX");
return (symbol1142___r5_macro_4_3_init = string_to_symbol("*HYGIEN?*"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r5_macro_4_3_init()
{
_hygien___100___r5_macro_4_3_init = BFALSE;
return (_hygien_initialized___241___r5_macro_4_3_init = ((bool_t)0),
BUNSPEC);
}


/* expand-syntax */obj_t expand_syntax_236___r5_macro_4_3_init(obj_t obj_1)
{
if(_hygien_initialized___241___r5_macro_4_3_init){
BUNSPEC;
}
 else {
_hygien_initialized___241___r5_macro_4_3_init = ((bool_t)1);
initialize_usual_syntax__76___r5_syntax_usual();
}
return internal_expand_syntax_49___r5_syntax_expand(obj_1);
}


/* _expand-syntax */obj_t _expand_syntax_35___r5_macro_4_3_init(obj_t env_458, obj_t obj_459)
{
return expand_syntax_236___r5_macro_4_3_init(obj_459);
}


/* imported-modules-init */obj_t imported_modules_init_94___r5_macro_4_3_init()
{
module_initialization_70___r5_syntax_expand(((long)0), "__R5_MACRO_4_3_INIT");
module_initialization_70___r5_syntax_misc(((long)0), "__R5_MACRO_4_3_INIT");
module_initialization_70___r5_syntax_prefs(((long)0), "__R5_MACRO_4_3_INIT");
module_initialization_70___r5_syntax_syntaxenv(((long)0), "__R5_MACRO_4_3_INIT");
module_initialization_70___r5_syntax_syntaxrules(((long)0), "__R5_MACRO_4_3_INIT");
return module_initialization_70___r5_syntax_usual(((long)0), "__R5_MACRO_4_3_INIT");
}


/* eval-init */obj_t eval_init_57___r5_macro_4_3_init()
{
define_primop__185___evenv(symbol1141___r5_macro_4_3_init, expand_syntax_env_94___r5_macro_4_3_init);
return define_primop_ref__105___evenv(symbol1142___r5_macro_4_3_init, __EVMEANING_ADDRESS(_hygien___100___r5_macro_4_3_init));
}

