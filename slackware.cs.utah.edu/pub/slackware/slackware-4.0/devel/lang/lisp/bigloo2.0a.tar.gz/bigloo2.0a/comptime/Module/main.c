/*===========================================================================*/
/*   (Module/main.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t ccomp_module_module;
extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_module_main();
extern obj_t _pair__244_type_cache;
extern obj_t _bdb_debug__1_engine_param;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t _main_consumer_88_module_main(obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_module_main(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _make_main_compiler_110_module_main(obj_t);
extern long class_num_218___object(obj_t);
static obj_t imported_modules_init_94_module_main();
static obj_t _main_producer_176_module_main(obj_t, obj_t);
static obj_t duplicate_main_error_106_module_main(obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
static obj_t library_modules_init_112_module_main();
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
static bool_t correct_main__10_module_main(global_t);
static obj_t main_consumer_241_module_main(obj_t, obj_t);
static obj_t arg1199_module_main(obj_t, obj_t, obj_t);
static obj_t arg1197_module_main(obj_t);
extern obj_t make_main_compiler_2_module_main();
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t main_producer_37_module_main(obj_t);
static obj_t require_initialization_114_module_main = BUNSPEC;
extern obj_t _main__152_module_module;
static obj_t cnst_init_137_module_main();
static obj_t __cnst[6];

DEFINE_STATIC_PROCEDURE(proc1307_module_main, arg1197_module_main1321, arg1197_module_main, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1306_module_main, arg1199_module_main1322, arg1199_module_main, 0L, 2);
DEFINE_STATIC_PROCEDURE(main_producer_env_121_module_main, _main_producer_176_module_main1323, _main_producer_176_module_main, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_main_compiler_env_146_module_main, _make_main_compiler_110_module_main1324, _make_main_compiler_110_module_main, 0L, 0);
DEFINE_STRING(string1312_module_main, string1312_module_main1325, "ARGV::PAIR ARGV::OBJ EXPORT IMPORTED VOID MAIN ", 47);
DEFINE_STRING(string1311_module_main, string1311_module_main1326, "Duplicated main clause", 22);
DEFINE_STRING(string1309_module_main, string1309_module_main1327, "Parse error", 11);
DEFINE_STRING(string1310_module_main, string1310_module_main1328, "Illegal main clause", 19);
DEFINE_STRING(string1308_module_main, string1308_module_main1329, "Illegal declaration of main function", 36);
DEFINE_STATIC_PROCEDURE(main_consumer_env_180_module_main, _main_consumer_88_module_main1330, _main_consumer_88_module_main, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_module_main(long checksum_605, char *from_606)
{
   if (CBOOL(require_initialization_114_module_main))
     {
	require_initialization_114_module_main = BBOOL(((bool_t) 0));
	library_modules_init_112_module_main();
	cnst_init_137_module_main();
	imported_modules_init_94_module_main();
	method_init_76_module_main();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_main()
{
   module_initialization_70___object(((long) 0), "MODULE_MAIN");
   module_initialization_70___reader(((long) 0), "MODULE_MAIN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_MAIN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_main()
{
   {
      obj_t cnst_port_138_597;
      cnst_port_138_597 = open_input_string(string1312_module_main);
      {
	 long i_598;
	 i_598 = ((long) 5);
       loop_599:
	 {
	    bool_t test1313_600;
	    test1313_600 = (i_598 == ((long) -1));
	    if (test1313_600)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1315_601;
		    {
		       obj_t list1316_602;
		       {
			  obj_t arg1319_603;
			  arg1319_603 = BNIL;
			  list1316_602 = MAKE_PAIR(cnst_port_138_597, arg1319_603);
		       }
		       arg1315_601 = read___reader(list1316_602);
		    }
		    CNST_TABLE_SET(i_598, arg1315_601);
		 }
		 {
		    int aux_604;
		    {
		       long aux_623;
		       aux_623 = (i_598 - ((long) 1));
		       aux_604 = (int) (aux_623);
		    }
		    {
		       long i_626;
		       i_626 = (long) (aux_604);
		       i_598 = i_626;
		       goto loop_599;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-main-compiler */ obj_t 
make_main_compiler_2_module_main()
{
   {
      obj_t arg1194_317;
      arg1194_317 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1199_585;
	 obj_t arg1197_586;
	 arg1199_585 = proc1306_module_main;
	 arg1197_586 = proc1307_module_main;
	 {
	    ccomp_t res1305_547;
	    {
	       ccomp_t new1002_538;
	       new1002_538 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1304_539;
		  arg1304_539 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_545;
		     obj_545 = (obj_t) (new1002_538);
		     (((obj_t) CREF(obj_545))->header = MAKE_HEADER(arg1304_539, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_633;
		  aux_633 = (object_t) (new1002_538);
		  OBJECT_WIDENING_SET(aux_633, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_538))->id) = ((obj_t) arg1194_317), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_538))->producer) = ((obj_t) main_producer_env_121_module_main), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_538))->consumer) = ((obj_t) main_consumer_env_180_module_main), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_538))->finalizer) = ((obj_t) arg1197_586), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_538))->checksummer) = ((obj_t) arg1199_585), BUNSPEC);
	       res1305_547 = new1002_538;
	    }
	    return (obj_t) (res1305_547);
	 }
      }
   }
}


/* _make-main-compiler */ obj_t 
_make_main_compiler_110_module_main(obj_t env_587)
{
   return make_main_compiler_2_module_main();
}


/* arg1199 */ obj_t 
arg1199_module_main(obj_t env_588, obj_t m_589, obj_t c_590)
{
   {
      obj_t m_323;
      obj_t c_324;
      m_323 = m_589;
      c_324 = c_590;
      return c_324;
   }
}


/* arg1197 */ obj_t 
arg1197_module_main(obj_t env_591)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* correct-main? */ bool_t 
correct_main__10_module_main(global_t global_1)
{
   {
      value_t sfun_328;
      sfun_328 = (((global_t) CREF(global_1))->value);
      {
	 bool_t _andtest_1191_329;
	 _andtest_1191_329 = is_a__118___object((obj_t) (sfun_328), sfun_ast_var);
	 if (_andtest_1191_329)
	   {
	      bool_t test_648;
	      {
		 long aux_649;
		 {
		    sfun_t obj_550;
		    obj_550 = (sfun_t) (sfun_328);
		    aux_649 = (((sfun_t) CREF(obj_550))->arity);
		 }
		 test_648 = (aux_649 == ((long) 1));
	      }
	      if (test_648)
		{
		   type_t type_332;
		   {
		      local_t obj_555;
		      {
			 obj_t aux_653;
			 {
			    obj_t aux_654;
			    {
			       sfun_t obj_553;
			       obj_553 = (sfun_t) (sfun_328);
			       aux_654 = (((sfun_t) CREF(obj_553))->args);
			    }
			    aux_653 = CAR(aux_654);
			 }
			 obj_555 = (local_t) (aux_653);
		      }
		      type_332 = (((local_t) CREF(obj_555))->type);
		   }
		   {
		      {
			 bool_t _ortest_1193_333;
			 {
			    obj_t obj2_557;
			    obj2_557 = _obj__252_type_cache;
			    {
			       obj_t aux_660;
			       aux_660 = (obj_t) (type_332);
			       _ortest_1193_333 = (aux_660 == obj2_557);
			    }
			 }
			 if (_ortest_1193_333)
			   {
			      return _ortest_1193_333;
			   }
			 else
			   {
			      obj_t obj2_559;
			      obj2_559 = _pair__244_type_cache;
			      {
				 obj_t aux_664;
				 aux_664 = (obj_t) (type_332);
				 return (aux_664 == obj2_559);
			      }
			   }
		      }
		   }
		}
	      else
		{
		   return ((bool_t) 0);
		}
	   }
	 else
	   {
	      return ((bool_t) 0);
	   }
      }
   }
}


/* main-producer */ obj_t 
main_producer_37_module_main(obj_t clause_2)
{
   {
      bool_t test1205_337;
      {
	 bool_t test1263_391;
	 {
	    obj_t obj1_560;
	    obj1_560 = _main__152_module_module;
	    {
	       obj_t aux_667;
	       aux_667 = CNST_TABLE_REF(((long) 2));
	       test1263_391 = (obj1_560 == aux_667);
	    }
	 }
	 if (test1263_391)
	   {
	      test1205_337 = ((bool_t) 1);
	   }
	 else
	   {
	      obj_t obj_562;
	      obj_562 = _main__152_module_module;
	      test1205_337 = is_a__118___object(obj_562, global_ast_var);
	   }
      }
      if (test1205_337)
	{
	   return duplicate_main_error_106_module_main(clause_2);
	}
      else
	{
	   obj_t main_338;
	   if (PAIRP(clause_2))
	     {
		obj_t cdr_107_0_343;
		cdr_107_0_343 = CDR(clause_2);
		if (PAIRP(cdr_107_0_343))
		  {
		     obj_t car_109_44_345;
		     car_109_44_345 = CAR(cdr_107_0_343);
		     if (SYMBOLP(car_109_44_345))
		       {
			  bool_t test_682;
			  {
			     obj_t aux_683;
			     aux_683 = CDR(cdr_107_0_343);
			     test_682 = (aux_683 == BNIL);
			  }
			  if (test_682)
			    {
			       main_338 = car_109_44_345;
			       {
				  obj_t global_350;
				  {
				     obj_t list1256_384;
				     list1256_384 = MAKE_PAIR(_module__166_module_module, BNIL);
				     global_350 = find_global_223_ast_env(main_338, list1256_384);
				  }
				  {
				     bool_t test1212_351;
				     test1212_351 = is_a__118___object(global_350, global_ast_var);
				     if (test1212_351)
				       {
					  if (correct_main__10_module_main((global_t) (global_350)))
					    {
					       return BUNSPEC;
					    }
					  else
					    {
					       obj_t list1217_355;
					       list1217_355 = MAKE_PAIR(BNIL, BNIL);
					       return user_error_151_tools_error(_module__166_module_module, string1308_module_main, main_338, list1217_355);
					    }
				       }
				     else
				       {
					  {
					     bool_t test1220_357;
					     {
						long n1_572;
						n1_572 = (long) CINT(_bdb_debug__1_engine_param);
						test1220_357 = (n1_572 > ((long) 0));
					     }
					     if (test1220_357)
					       {
						  obj_t arg1221_358;
						  {
						     obj_t arg1222_359;
						     obj_t arg1224_360;
						     arg1222_359 = CNST_TABLE_REF(((long) 3));
						     {
							obj_t arg1232_365;
							arg1232_365 = CNST_TABLE_REF(((long) 4));
							{
							   obj_t list1234_367;
							   {
							      obj_t arg1235_368;
							      arg1235_368 = MAKE_PAIR(BNIL, BNIL);
							      list1234_367 = MAKE_PAIR(arg1232_365, arg1235_368);
							   }
							   arg1224_360 = cons__138___r4_pairs_and_lists_6_3(main_338, list1234_367);
							}
						     }
						     {
							obj_t list1226_362;
							{
							   obj_t arg1228_363;
							   arg1228_363 = MAKE_PAIR(BNIL, BNIL);
							   list1226_362 = MAKE_PAIR(arg1224_360, arg1228_363);
							}
							arg1221_358 = cons__138___r4_pairs_and_lists_6_3(arg1222_359, list1226_362);
						     }
						  }
						  produce_module_clause__172_module_module(arg1221_358);
					       }
					     else
					       {
						  obj_t arg1238_370;
						  {
						     obj_t arg1240_371;
						     obj_t arg1241_372;
						     arg1240_371 = CNST_TABLE_REF(((long) 3));
						     {
							obj_t arg1248_377;
							arg1248_377 = CNST_TABLE_REF(((long) 5));
							{
							   obj_t list1251_379;
							   {
							      obj_t arg1252_380;
							      arg1252_380 = MAKE_PAIR(BNIL, BNIL);
							      list1251_379 = MAKE_PAIR(arg1248_377, arg1252_380);
							   }
							   arg1241_372 = cons__138___r4_pairs_and_lists_6_3(main_338, list1251_379);
							}
						     }
						     {
							obj_t list1244_374;
							{
							   obj_t arg1245_375;
							   arg1245_375 = MAKE_PAIR(BNIL, BNIL);
							   list1244_374 = MAKE_PAIR(arg1241_372, arg1245_375);
							}
							arg1238_370 = cons__138___r4_pairs_and_lists_6_3(arg1240_371, list1244_374);
						     }
						  }
						  produce_module_clause__172_module_module(arg1238_370);
					       }
					  }
					  {
					     obj_t list1254_382;
					     list1254_382 = MAKE_PAIR(_module__166_module_module, BNIL);
					     return (_main__152_module_module = find_global_223_ast_env(main_338, list1254_382),
						BUNSPEC);
					  }
				       }
				  }
			       }
			    }
			  else
			    {
			     tag_102_241_340:
			       {
				  obj_t list1261_389;
				  list1261_389 = MAKE_PAIR(BNIL, BNIL);
				  return user_error_151_tools_error(string1309_module_main, string1310_module_main, clause_2, list1261_389);
			       }
			    }
		       }
		     else
		       {
			  goto tag_102_241_340;
		       }
		  }
		else
		  {
		     goto tag_102_241_340;
		  }
	     }
	   else
	     {
		goto tag_102_241_340;
	     }
	}
   }
}


/* _main-producer */ obj_t 
_main_producer_176_module_main(obj_t env_592, obj_t clause_593)
{
   return main_producer_37_module_main(clause_593);
}


/* main-consumer */ obj_t 
main_consumer_241_module_main(obj_t module_3, obj_t clause_4)
{
   {
      bool_t test1266_574;
      {
	 obj_t obj_575;
	 obj_575 = _main__152_module_module;
	 test1266_574 = is_a__118___object(obj_575, global_ast_var);
      }
      if (test1266_574)
	{
	   duplicate_main_error_106_module_main(clause_4);
	}
      else
	{
	   _main__152_module_module = CNST_TABLE_REF(((long) 2));
	}
   }
   return BNIL;
}


/* _main-consumer */ obj_t 
_main_consumer_88_module_main(obj_t env_594, obj_t module_595, obj_t clause_596)
{
   return main_consumer_241_module_main(module_595, clause_596);
}


/* duplicate-main-error */ obj_t 
duplicate_main_error_106_module_main(obj_t clause_5)
{
   {
      obj_t list1270_397;
      list1270_397 = MAKE_PAIR(BNIL, BNIL);
      return user_error_151_tools_error(string1309_module_main, string1311_module_main, clause_5, list1270_397);
   }
}


/* method-init */ obj_t 
method_init_76_module_main()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_main()
{
   module_initialization_70_module_module(((long) 0), "MODULE_MAIN");
   module_initialization_70_tools_error(((long) 0), "MODULE_MAIN");
   module_initialization_70_type_type(((long) 0), "MODULE_MAIN");
   module_initialization_70_type_cache(((long) 0), "MODULE_MAIN");
   module_initialization_70_ast_var(((long) 0), "MODULE_MAIN");
   module_initialization_70_ast_env(((long) 0), "MODULE_MAIN");
   return module_initialization_70_engine_param(((long) 0), "MODULE_MAIN");
}
