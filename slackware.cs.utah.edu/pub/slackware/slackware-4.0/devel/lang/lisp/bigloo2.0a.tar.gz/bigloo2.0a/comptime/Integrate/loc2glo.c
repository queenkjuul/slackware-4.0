/*===========================================================================*/
/*   (Integrate/loc2glo.scm)                                                 */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_integrate_local__global_163();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _the_global1741_159_integrate_local__global_163(obj_t, obj_t);
static obj_t _local__global1740_110_integrate_local__global_163(obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern local_t clone_local_230_ast_local(local_t, value_t);
extern obj_t globalize__167_integrate_node(node_t, variable_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
extern bool_t integrate_celled__59_integrate_node(local_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_local__global_163(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t svar_iinfo_76_integrate_info;
extern long list_length(obj_t);
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t local__global_40_integrate_local__global_163(local_t);
static obj_t imported_modules_init_94_integrate_local__global_163();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_integrate_local__global_163();
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern obj_t the_global_201_integrate_local__global_163(local_t);
extern obj_t __arity_132_tools_args(obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_integrate_local__global_163 = BUNSPEC;
static obj_t cnst_init_137_integrate_local__global_163();
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(local__global_env_170_integrate_local__global_163, _local__global1740_110_integrate_local__global_1631748, _local__global1740_110_integrate_local__global_163, 0L, 1);
DEFINE_EXPORT_PROCEDURE(the_global_env_148_integrate_local__global_163, _the_global1741_159_integrate_local__global_1631749, _the_global1741_159_integrate_local__global_163, 0L, 1);
DEFINE_STRING(string1742_integrate_local__global_163, string1742_integrate_local__global_1631750, "NOW A-INTEGRATED-BODY SFUN _ ", 29);


/* module-initialization */ obj_t 
module_initialization_70_integrate_local__global_163(long checksum_1611, char *from_1612)
{
   if (CBOOL(require_initialization_114_integrate_local__global_163))
     {
	require_initialization_114_integrate_local__global_163 = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_local__global_163();
	cnst_init_137_integrate_local__global_163();
	imported_modules_init_94_integrate_local__global_163();
	method_init_76_integrate_local__global_163();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_local__global_163()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70___object(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70___reader(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_local__global_163()
{
   {
      obj_t cnst_port_138_1603;
      cnst_port_138_1603 = open_input_string(string1742_integrate_local__global_163);
      {
	 long i_1604;
	 i_1604 = ((long) 3);
       loop_1605:
	 {
	    bool_t test1743_1606;
	    test1743_1606 = (i_1604 == ((long) -1));
	    if (test1743_1606)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1744_1607;
		    {
		       obj_t list1745_1608;
		       {
			  obj_t arg1746_1609;
			  arg1746_1609 = BNIL;
			  list1745_1608 = MAKE_PAIR(cnst_port_138_1603, arg1746_1609);
		       }
		       arg1744_1607 = read___reader(list1745_1608);
		    }
		    CNST_TABLE_SET(i_1604, arg1744_1607);
		 }
		 {
		    int aux_1610;
		    {
		       long aux_1630;
		       aux_1630 = (i_1604 - ((long) 1));
		       aux_1610 = (int) (aux_1630);
		    }
		    {
		       long i_1633;
		       i_1633 = (long) (aux_1610);
		       i_1604 = i_1633;
		       goto loop_1605;
		    }
		 }
	      }
	 }
      }
   }
}


/* local->global */ obj_t 
local__global_40_integrate_local__global_163(local_t local_1)
{
   {
      obj_t global_891;
      global_891 = the_global_201_integrate_local__global_163(local_1);
      {
	 obj_t kaptured_892;
	 {
	    sfun_iinfo_105_t obj_1377;
	    {
	       value_t aux_1636;
	       aux_1636 = (((local_t) CREF(local_1))->value);
	       obj_1377 = (sfun_iinfo_105_t) (aux_1636);
	    }
	    {
	       obj_t aux_1639;
	       {
		  object_t aux_1640;
		  aux_1640 = (object_t) (obj_1377);
		  aux_1639 = OBJECT_WIDENING(aux_1640);
	       }
	       kaptured_892 = (((sfun_iinfo_105_t) CREF(aux_1639))->kaptured);
	    }
	 }
	 {
	    obj_t add_args_4_893;
	    if (NULLP(kaptured_892))
	      {
		 add_args_4_893 = BNIL;
	      }
	    else
	      {
		 obj_t head1527_949;
		 head1527_949 = MAKE_PAIR(BNIL, BNIL);
		 {
		    obj_t l1525_950;
		    obj_t tail1528_951;
		    l1525_950 = kaptured_892;
		    tail1528_951 = head1527_949;
		  lname1526_952:
		    if (NULLP(l1525_950))
		      {
			 add_args_4_893 = CDR(head1527_949);
		      }
		    else
		      {
			 obj_t newtail1529_954;
			 {
			    local_t arg1593_956;
			    {
			       obj_t old_958;
			       old_958 = CAR(l1525_950);
			       {
				  svar_iinfo_76_t arg1595_959;
				  {
				     svar_iinfo_76_t duplicated1530_960;
				     {
					local_t obj_1384;
					obj_1384 = (local_t) (old_958);
					{
					   value_t aux_1652;
					   aux_1652 = (((local_t) CREF(obj_1384))->value);
					   duplicated1530_960 = (svar_iinfo_76_t) (aux_1652);
					}
				     }
				     {
					svar_iinfo_76_t new1531_961;
					{
					   obj_t arg1598_962;
					   obj_t arg1600_963;
					   obj_t arg1602_964;
					   bool_t arg1603_965;
					   bool_t arg1605_966;
					   {
					      svar_t obj_1385;
					      obj_1385 = (svar_t) (duplicated1530_960);
					      arg1598_962 = (((svar_t) CREF(obj_1385))->loc);
					   }
					   {
					      obj_t aux_1657;
					      {
						 object_t aux_1658;
						 aux_1658 = (object_t) (duplicated1530_960);
						 aux_1657 = OBJECT_WIDENING(aux_1658);
					      }
					      arg1600_963 = (((svar_iinfo_76_t) CREF(aux_1657))->f_mark_181);
					   }
					   {
					      obj_t aux_1662;
					      {
						 object_t aux_1663;
						 aux_1663 = (object_t) (duplicated1530_960);
						 aux_1662 = OBJECT_WIDENING(aux_1663);
					      }
					      arg1602_964 = (((svar_iinfo_76_t) CREF(aux_1662))->u_mark_209);
					   }
					   {
					      obj_t aux_1667;
					      {
						 object_t aux_1668;
						 aux_1668 = (object_t) (duplicated1530_960);
						 aux_1667 = OBJECT_WIDENING(aux_1668);
					      }
					      arg1603_965 = (((svar_iinfo_76_t) CREF(aux_1667))->kaptured__204);
					   }
					   {
					      obj_t aux_1672;
					      {
						 object_t aux_1673;
						 aux_1673 = (object_t) (duplicated1530_960);
						 aux_1672 = OBJECT_WIDENING(aux_1673);
					      }
					      arg1605_966 = (((svar_iinfo_76_t) CREF(aux_1672))->celled__113);
					   }
					   {
					      svar_iinfo_76_t res1736_1418;
					      {
						 svar_t aux1452_1395;
						 {
						    svar_t res1734_1405;
						    {
						       svar_t new1169_1400;
						       new1169_1400 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
						       {
							  long arg1713_1401;
							  arg1713_1401 = class_num_218___object(svar_ast_var);
							  {
							     obj_t obj_1403;
							     obj_1403 = (obj_t) (new1169_1400);
							     (((obj_t) CREF(obj_1403))->header = MAKE_HEADER(arg1713_1401, 0), BUNSPEC);
							  }
						       }
						       {
							  object_t aux_1681;
							  aux_1681 = (object_t) (new1169_1400);
							  OBJECT_WIDENING_SET(aux_1681, BFALSE);
						       }
						       ((((svar_t) CREF(new1169_1400))->loc) = ((obj_t) arg1598_962), BUNSPEC);
						       res1734_1405 = new1169_1400;
						    }
						    aux1452_1395 = res1734_1405;
						 }
						 {
						    svar_iinfo_76_t new1453_1396;
						    new1453_1396 = ((svar_iinfo_76_t) (aux1452_1395));
						    {
						       long arg1649_1397;
						       arg1649_1397 = class_num_218___object(svar_iinfo_76_integrate_info);
						       {
							  obj_t obj_1406;
							  obj_1406 = (obj_t) (new1453_1396);
							  (((obj_t) CREF(obj_1406))->header = MAKE_HEADER(arg1649_1397, 0), BUNSPEC);
						       }
						    }
						    {
						       svar_iinfo_76_t arg1650_1398;
						       {
							  svar_iinfo_76_t res1735_1417;
							  {
							     svar_iinfo_76_t new1446_1412;
							     new1446_1412 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
							     ((((svar_iinfo_76_t) CREF(new1446_1412))->f_mark_181) = ((obj_t) arg1600_963), BUNSPEC);
							     ((((svar_iinfo_76_t) CREF(new1446_1412))->u_mark_209) = ((obj_t) arg1602_964), BUNSPEC);
							     ((((svar_iinfo_76_t) CREF(new1446_1412))->kaptured__204) = ((bool_t) arg1603_965), BUNSPEC);
							     ((((svar_iinfo_76_t) CREF(new1446_1412))->celled__113) = ((bool_t) arg1605_966), BUNSPEC);
							     res1735_1417 = new1446_1412;
							  }
							  arg1650_1398 = res1735_1417;
						       }
						       {
							  obj_t aux_1696;
							  object_t aux_1694;
							  aux_1696 = (obj_t) (arg1650_1398);
							  aux_1694 = (object_t) (new1453_1396);
							  OBJECT_WIDENING_SET(aux_1694, aux_1696);
						       }
						    }
						    res1736_1418 = new1453_1396;
						 }
					      }
					      new1531_961 = res1736_1418;
					   }
					}
					{
					   arg1595_959 = new1531_961;
					}
				     }
				  }
				  arg1593_956 = clone_local_230_ast_local((local_t) (old_958), (value_t) (arg1595_959));
			       }
			    }
			    {
			       obj_t aux_1702;
			       aux_1702 = (obj_t) (arg1593_956);
			       newtail1529_954 = MAKE_PAIR(aux_1702, BNIL);
			    }
			 }
			 SET_CDR(tail1528_951, newtail1529_954);
			 {
			    obj_t tail1528_1708;
			    obj_t l1525_1706;
			    l1525_1706 = CDR(l1525_950);
			    tail1528_1708 = newtail1529_954;
			    tail1528_951 = tail1528_1708;
			    l1525_950 = l1525_1706;
			    goto lname1526_952;
			 }
		      }
		 }
	      }
	    {
	       value_t old_fun_147_894;
	       old_fun_147_894 = (((local_t) CREF(local_1))->value);
	       {
		  sfun_t new_fun_115_895;
		  {
		     sfun_t duplicated1532_929;
		     duplicated1532_929 = (sfun_t) (old_fun_147_894);
		     {
			sfun_t new1533_930;
			{
			   obj_t arg1568_931;
			   obj_t arg1569_932;
			   obj_t arg1570_933;
			   obj_t arg1572_934;
			   bool_t arg1573_935;
			   obj_t arg1575_936;
			   obj_t arg1578_937;
			   obj_t arg1580_938;
			   obj_t arg1581_939;
			   obj_t arg1582_940;
			   obj_t arg1583_941;
			   obj_t arg1584_942;
			   {
			      obj_t aux_1715;
			      obj_t aux_1711;
			      {
				 long aux_1716;
				 aux_1716 = list_length(add_args_4_893);
				 aux_1715 = BINT(aux_1716);
			      }
			      {
				 long aux_1712;
				 aux_1712 = (((sfun_t) CREF(duplicated1532_929))->arity);
				 aux_1711 = BINT(aux_1712);
			      }
			      arg1568_931 = __arity_132_tools_args(aux_1711, aux_1715);
			   }
			   arg1569_932 = (((sfun_t) CREF(duplicated1532_929))->side_effect__165);
			   arg1570_933 = (((sfun_t) CREF(duplicated1532_929))->predicate_of_78);
			   arg1572_934 = (((sfun_t) CREF(duplicated1532_929))->stack_allocator_172);
			   arg1573_935 = (((sfun_t) CREF(duplicated1532_929))->top__138);
			   arg1575_936 = (((sfun_t) CREF(duplicated1532_929))->the_closure_238);
			   arg1578_937 = (((sfun_t) CREF(duplicated1532_929))->property);
			   arg1580_938 = append_2_18___r4_pairs_and_lists_6_3(reverse___r4_pairs_and_lists_6_3(add_args_4_893), (((sfun_t) CREF(duplicated1532_929))->args));
			   arg1581_939 = (((sfun_t) CREF(duplicated1532_929))->body);
			   arg1582_940 = (((sfun_t) CREF(duplicated1532_929))->class);
			   arg1583_941 = (((sfun_t) CREF(duplicated1532_929))->dsssl_keywords_243);
			   arg1584_942 = (((sfun_t) CREF(duplicated1532_929))->loc);
			   {
			      sfun_t res1737_1465;
			      {
				 long arity_1437;
				 arity_1437 = (long) CINT(arg1568_931);
				 {
				    sfun_t new1125_1449;
				    new1125_1449 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
				    {
				       long arg1718_1450;
				       arg1718_1450 = class_num_218___object(sfun_ast_var);
				       {
					  obj_t obj_1463;
					  obj_1463 = (obj_t) (new1125_1449);
					  (((obj_t) CREF(obj_1463))->header = MAKE_HEADER(arg1718_1450, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1738;
				       aux_1738 = (object_t) (new1125_1449);
				       OBJECT_WIDENING_SET(aux_1738, BFALSE);
				    }
				    ((((sfun_t) CREF(new1125_1449))->arity) = ((long) arity_1437), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->side_effect__165) = ((obj_t) arg1569_932), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->predicate_of_78) = ((obj_t) arg1570_933), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->stack_allocator_172) = ((obj_t) arg1572_934), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->top__138) = ((bool_t) arg1573_935), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->the_closure_238) = ((obj_t) arg1575_936), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->property) = ((obj_t) arg1578_937), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->args) = ((obj_t) arg1580_938), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->body) = ((obj_t) arg1581_939), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->class) = ((obj_t) arg1582_940), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->dsssl_keywords_243) = ((obj_t) arg1583_941), BUNSPEC);
				    ((((sfun_t) CREF(new1125_1449))->loc) = ((obj_t) arg1584_942), BUNSPEC);
				    res1737_1465 = new1125_1449;
				 }
			      }
			      new1533_930 = res1737_1465;
			   }
			}
			{
			   new_fun_115_895 = new1533_930;
			}
		     }
		  }
		  {
		     {
			type_t arg1542_896;
			arg1542_896 = (((local_t) CREF(local_1))->type);
			{
			   global_t obj_1467;
			   obj_1467 = (global_t) (global_891);
			   ((((global_t) CREF(obj_1467))->type) = ((type_t) arg1542_896), BUNSPEC);
			}
		     }
		     {
			obj_t l1534_897;
			l1534_897 = (((sfun_t) CREF(new_fun_115_895))->args);
		      lname1535_898:
			if (PAIRP(l1534_897))
			  {
			     {
				obj_t l_901;
				l_901 = CAR(l1534_897);
				{
				   bool_t test1547_902;
				   test1547_902 = integrate_celled__59_integrate_node((local_t) (l_901));
				   if (test1547_902)
				     {
					local_t obj_1472;
					type_t val1103_1473;
					obj_1472 = (local_t) (l_901);
					val1103_1473 = (type_t) (_obj__252_type_cache);
					((((local_t) CREF(obj_1472))->type) = ((type_t) val1103_1473), BUNSPEC);
				     }
				   else
				     {
					BUNSPEC;
				     }
				}
			     }
			     {
				obj_t l1534_1765;
				l1534_1765 = CDR(l1534_897);
				l1534_897 = l1534_1765;
				goto lname1535_898;
			     }
			  }
			else
			  {
			     ((bool_t) 1);
			  }
		     }
		     {
			obj_t arg1549_904;
			{
			   obj_t arg1550_905;
			   obj_t arg1552_906;
			   {
			      sfun_t obj_1475;
			      obj_1475 = (sfun_t) (old_fun_147_894);
			      arg1550_905 = (((sfun_t) CREF(obj_1475))->body);
			   }
			   if (NULLP(kaptured_892))
			     {
				arg1552_906 = BNIL;
			     }
			   else
			     {
				obj_t head1538_910;
				{
				   obj_t arg1563_925;
				   {
				      obj_t aux_1774;
				      obj_t aux_1772;
				      aux_1774 = CAR(add_args_4_893);
				      aux_1772 = CAR(kaptured_892);
				      arg1563_925 = MAKE_PAIR(aux_1772, aux_1774);
				   }
				   head1538_910 = MAKE_PAIR(arg1563_925, BNIL);
				}
				{
				   obj_t ll1536_911;
				   obj_t ll1537_912;
				   obj_t tail1539_913;
				   ll1536_911 = CDR(kaptured_892);
				   ll1537_912 = CDR(add_args_4_893);
				   tail1539_913 = head1538_910;
				 lname1541_914:
				   if (NULLP(ll1536_911))
				     {
					arg1552_906 = head1538_910;
				     }
				   else
				     {
					obj_t newtail1540_918;
					{
					   obj_t arg1559_921;
					   {
					      obj_t aux_1782;
					      obj_t aux_1780;
					      aux_1782 = CAR(ll1537_912);
					      aux_1780 = CAR(ll1536_911);
					      arg1559_921 = MAKE_PAIR(aux_1780, aux_1782);
					   }
					   newtail1540_918 = MAKE_PAIR(arg1559_921, BNIL);
					}
					SET_CDR(tail1539_913, newtail1540_918);
					{
					   obj_t tail1539_1791;
					   obj_t ll1537_1789;
					   obj_t ll1536_1787;
					   ll1536_1787 = CDR(ll1536_911);
					   ll1537_1789 = CDR(ll1537_912);
					   tail1539_1791 = newtail1540_918;
					   tail1539_913 = tail1539_1791;
					   ll1537_912 = ll1537_1789;
					   ll1536_911 = ll1536_1787;
					   goto lname1541_914;
					}
				     }
				}
			     }
			   arg1549_904 = globalize__167_integrate_node((node_t) (arg1550_905), (variable_t) (local_1), arg1552_906);
			}
			((((sfun_t) CREF(new_fun_115_895))->body) = ((obj_t) arg1549_904), BUNSPEC);
		     }
		     {
			global_t obj_1498;
			value_t val1079_1499;
			obj_1498 = (global_t) (global_891);
			val1079_1499 = (value_t) (new_fun_115_895);
			((((global_t) CREF(obj_1498))->value) = ((value_t) val1079_1499), BUNSPEC);
		     }
		     return global_891;
		  }
	       }
	    }
	 }
      }
   }
}


/* _local->global1740 */ obj_t 
_local__global1740_110_integrate_local__global_163(obj_t env_1599, obj_t local_1600)
{
   return local__global_40_integrate_local__global_163((local_t) (local_1600));
}


/* the-global */ obj_t 
the_global_201_integrate_local__global_163(local_t local_2)
{
   {
      value_t value_970;
      value_970 = (((local_t) CREF(local_2))->value);
      {
	 bool_t test1609_971;
	 {
	    obj_t aux_1804;
	    {
	       sfun_iinfo_105_t obj_1501;
	       obj_1501 = (sfun_iinfo_105_t) (value_970);
	       {
		  obj_t aux_1806;
		  {
		     object_t aux_1807;
		     aux_1807 = (object_t) (obj_1501);
		     aux_1806 = OBJECT_WIDENING(aux_1807);
		  }
		  aux_1804 = (((sfun_iinfo_105_t) CREF(aux_1806))->global);
	       }
	    }
	    test1609_971 = is_a__118___object(aux_1804, global_ast_var);
	 }
	 if (test1609_971)
	   {
	      sfun_iinfo_105_t obj_1503;
	      obj_1503 = (sfun_iinfo_105_t) (value_970);
	      {
		 obj_t aux_1814;
		 {
		    object_t aux_1815;
		    aux_1815 = (object_t) (obj_1503);
		    aux_1814 = OBJECT_WIDENING(aux_1815);
		 }
		 return (((sfun_iinfo_105_t) CREF(aux_1814))->global);
	      }
	   }
	 else
	   {
	      obj_t id_972;
	      {
		 bool_t test1624_984;
		 {
		    obj_t arg1633_991;
		    {
		       obj_t arg1634_992;
		       arg1634_992 = (((local_t) CREF(local_2))->id);
		       {
			  obj_t list1635_993;
			  list1635_993 = MAKE_PAIR(_module__166_module_module, BNIL);
			  arg1633_991 = find_global_223_ast_env(arg1634_992, list1635_993);
		       }
		    }
		    test1624_984 = is_a__118___object(arg1633_991, global_ast_var);
		 }
		 if (test1624_984)
		   {
		      obj_t arg1625_985;
		      {
			 obj_t arg1627_986;
			 arg1627_986 = (((local_t) CREF(local_2))->id);
			 {
			    obj_t list1629_988;
			    {
			       obj_t arg1630_989;
			       {
				  obj_t aux_1825;
				  aux_1825 = CNST_TABLE_REF(((long) 0));
				  arg1630_989 = MAKE_PAIR(aux_1825, BNIL);
			       }
			       list1629_988 = MAKE_PAIR(arg1627_986, arg1630_989);
			    }
			    arg1625_985 = symbol_append_197___r4_symbols_6_4(list1629_988);
			 }
		      }
		      id_972 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, arg1625_985, BEOA);
		   }
		 else
		   {
		      id_972 = (((local_t) CREF(local_2))->id);
		   }
	      }
	      {
		 global_t global_973;
		 global_973 = def_global_sfun__93_ast_glo_def_117(id_972, BNIL, BNIL, _module__166_module_module, CNST_TABLE_REF(((long) 1)), CNST_TABLE_REF(((long) 2)), CNST_TABLE_REF(((long) 3)), BUNSPEC);
		 {
		    {
		       obj_t arg1612_975;
		       {
			  sfun_t obj_1509;
			  obj_1509 = (sfun_t) (value_970);
			  arg1612_975 = (((sfun_t) CREF(obj_1509))->loc);
		       }
		       {
			  sfun_t obj_1510;
			  {
			     value_t aux_1839;
			     aux_1839 = (((global_t) CREF(global_973))->value);
			     obj_1510 = (sfun_t) (aux_1839);
			  }
			  ((((sfun_t) CREF(obj_1510))->loc) = ((obj_t) arg1612_975), BUNSPEC);
		       }
		    }
		    if ((((local_t) CREF(local_2))->user__32))
		      {
			 BUNSPEC;
		      }
		    else
		      {
			 ((((global_t) CREF(global_973))->user__32) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		    {
		       sfun_iinfo_105_t obj_1515;
		       obj_t val1522_1516;
		       obj_1515 = (sfun_iinfo_105_t) (value_970);
		       val1522_1516 = (obj_t) (global_973);
		       {
			  obj_t aux_1848;
			  {
			     object_t aux_1849;
			     aux_1849 = (object_t) (obj_1515);
			     aux_1848 = OBJECT_WIDENING(aux_1849);
			  }
			  ((((sfun_iinfo_105_t) CREF(aux_1848))->global) = ((obj_t) val1522_1516), BUNSPEC);
		       }
		    }
		    {
		       obj_t arg1617_978;
		       {
			  sfun_t obj_1518;
			  obj_1518 = (sfun_t) (value_970);
			  arg1617_978 = (((sfun_t) CREF(obj_1518))->side_effect__165);
		       }
		       {
			  sfun_t obj_1519;
			  {
			     value_t aux_1855;
			     aux_1855 = (((global_t) CREF(global_973))->value);
			     obj_1519 = (sfun_t) (aux_1855);
			  }
			  ((((sfun_t) CREF(obj_1519))->side_effect__165) = ((obj_t) arg1617_978), BUNSPEC);
		       }
		    }
		    return (obj_t) (global_973);
		 }
	      }
	   }
      }
   }
}


/* _the-global1741 */ obj_t 
_the_global1741_159_integrate_local__global_163(obj_t env_1601, obj_t local_1602)
{
   return the_global_201_integrate_local__global_163((local_t) (local_1602));
}


/* method-init */ obj_t 
method_init_76_integrate_local__global_163()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_local__global_163()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_tools_args(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_module_module(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_type_cache(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_ast_glo_def_117(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_ast_env(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_ast_local(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
   return module_initialization_70_integrate_node(((long) 0), "INTEGRATE_LOCAL->GLOBAL");
}
