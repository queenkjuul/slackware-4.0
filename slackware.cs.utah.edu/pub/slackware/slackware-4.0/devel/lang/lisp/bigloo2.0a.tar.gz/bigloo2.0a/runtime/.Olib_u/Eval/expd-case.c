/*===========================================================================*/
/*   (Eval/expd-case.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t symbol1262___expander_case = BUNSPEC;
static obj_t symbol1261___expander_case = BUNSPEC;
static obj_t symbol1259___expander_case = BUNSPEC;
static obj_t symbol1260___expander_case = BUNSPEC;
static obj_t symbol1258___expander_case = BUNSPEC;
static obj_t symbol1256___expander_case = BUNSPEC;
static obj_t symbol1255___expander_case = BUNSPEC;
static obj_t loop___expander_case(obj_t, obj_t);
static obj_t _expand_eval_case_201___expander_case(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___expander_case(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t expand_eval_case_113___expander_case(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_case();
static obj_t require_initialization_114___expander_case = BUNSPEC;
static obj_t generic_case_158___expander_case(obj_t, obj_t, obj_t, obj_t);
extern obj_t normalize_progn_143___progn(obj_t);
static obj_t cnst_init_137___expander_case();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_eval_case_env_39___expander_case, _expand_eval_case_201___expander_case1264, _expand_eval_case_201___expander_case, 0L, 2 );
DEFINE_STRING( string1257___expander_case, string1257___expander_case1265, "Illegal `case' form", 19 );
DEFINE_STRING( string1254___expander_case, string1254___expander_case1266, "Illegal form", 12 );
DEFINE_STRING( string1253___expander_case, string1253___expander_case1267, "case", 4 );


/* module-initialization */obj_t module_initialization_70___expander_case(long checksum_650, char * from_651)
{
if(CBOOL(require_initialization_114___expander_case)){
require_initialization_114___expander_case = BBOOL(((bool_t)0));
cnst_init_137___expander_case();
imported_modules_init_94___expander_case();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_case()
{
symbol1255___expander_case = string_to_symbol("LET");
symbol1256___expander_case = string_to_symbol("CASE-VALUE");
symbol1258___expander_case = string_to_symbol("IF");
symbol1259___expander_case = string_to_symbol("EQ?");
symbol1260___expander_case = string_to_symbol("QUOTE");
symbol1261___expander_case = string_to_symbol("MEMQ");
return (symbol1262___expander_case = string_to_symbol("ELSE"),
BUNSPEC);
}


/* expand-eval-case */obj_t expand_eval_case_113___expander_case(obj_t x_1, obj_t e_2)
{
if(PAIRP(x_1)){
obj_t cdr_109_69_328;
cdr_109_69_328 = CDR(x_1);
if(PAIRP(cdr_109_69_328)){
return generic_case_158___expander_case(x_1, CAR(cdr_109_69_328), CDR(cdr_109_69_328), e_2);
}
 else {
FAILURE(string1253___expander_case,string1254___expander_case,x_1);}
}
 else {
FAILURE(string1253___expander_case,string1254___expander_case,x_1);}
}


/* _expand-eval-case */obj_t _expand_eval_case_201___expander_case(obj_t env_646, obj_t x_647, obj_t e_648)
{
return expand_eval_case_113___expander_case(x_647, e_648);
}


/* generic-case */obj_t generic_case_158___expander_case(obj_t x_3, obj_t value_4, obj_t clauses_5, obj_t e_6)
{
{
obj_t arg1010_332;
{
obj_t arg1011_333;
obj_t arg1012_334;
obj_t arg1013_335;
arg1011_333 = symbol1255___expander_case;
{
obj_t arg1019_341;
{
obj_t arg1023_345;
arg1023_345 = symbol1256___expander_case;
{
obj_t list1026_347;
{
obj_t arg1027_348;
arg1027_348 = MAKE_PAIR(BNIL, BNIL);
list1026_347 = MAKE_PAIR(value_4, arg1027_348);
}
arg1019_341 = cons__138___r4_pairs_and_lists_6_3(arg1023_345, list1026_347);
}
}
{
obj_t list1021_343;
list1021_343 = MAKE_PAIR(BNIL, BNIL);
arg1012_334 = cons__138___r4_pairs_and_lists_6_3(arg1019_341, list1021_343);
}
}
arg1013_335 = loop___expander_case(x_3, clauses_5);
{
obj_t list1015_337;
{
obj_t arg1016_338;
{
obj_t arg1017_339;
arg1017_339 = MAKE_PAIR(BNIL, BNIL);
arg1016_338 = MAKE_PAIR(arg1013_335, arg1017_339);
}
list1015_337 = MAKE_PAIR(arg1012_334, arg1016_338);
}
arg1010_332 = cons__138___r4_pairs_and_lists_6_3(arg1011_333, list1015_337);
}
}
return PROCEDURE_ENTRY(e_6)(e_6, arg1010_332, e_6, BEOA);
}
}


/* loop */obj_t loop___expander_case(obj_t x_649, obj_t clauses_350)
{
if(NULLP(clauses_350)){
return BFALSE;
}
 else {
obj_t body_354;
obj_t datums_356;
obj_t body_357;
obj_t datums_359;
obj_t body_360;
{
obj_t e_120_171_362;
e_120_171_362 = CAR(clauses_350);
if((e_120_171_362==BNIL)){
return BFALSE;
}
 else {
if(PAIRP(e_120_171_362)){
bool_t test_694;
{
obj_t aux_695;
aux_695 = CAR(e_120_171_362);
test_694 = (aux_695==symbol1262___expander_case);
}
if(test_694){
body_354 = CDR(e_120_171_362);
{
bool_t test_698;
{
bool_t test_699;
{
obj_t aux_700;
aux_700 = CDR(clauses_350);
test_699 = NULLP(aux_700);
}
if(test_699){
test_698 = NULLP(body_354);
}
 else {
test_698 = ((bool_t)1);
}
}
if(test_698){
FAILURE(string1253___expander_case,string1257___expander_case,x_649);}
 else {
return normalize_progn_143___progn(body_354);
}
}
}
 else {
obj_t car_133_3_367;
car_133_3_367 = CAR(e_120_171_362);
if(PAIRP(car_133_3_367)){
bool_t test_710;
{
obj_t aux_711;
aux_711 = CDR(car_133_3_367);
test_710 = PAIRP(aux_711);
}
if(test_710){
datums_356 = car_133_3_367;
body_357 = CDR(e_120_171_362);
if(NULLP(body_357)){
FAILURE(string1253___expander_case,string1257___expander_case,x_649);}
 else {
obj_t arg1058_392;
obj_t arg1059_393;
obj_t arg1060_394;
obj_t arg1061_395;
arg1058_392 = symbol1258___expander_case;
{
obj_t arg1069_402;
obj_t arg1070_403;
obj_t arg1072_404;
arg1069_402 = symbol1261___expander_case;
arg1070_403 = symbol1256___expander_case;
{
obj_t arg1079_410;
arg1079_410 = symbol1260___expander_case;
{
obj_t list1081_412;
{
obj_t arg1082_413;
arg1082_413 = MAKE_PAIR(BNIL, BNIL);
list1081_412 = MAKE_PAIR(datums_356, arg1082_413);
}
arg1072_404 = cons__138___r4_pairs_and_lists_6_3(arg1079_410, list1081_412);
}
}
{
obj_t list1074_406;
{
obj_t arg1076_407;
{
obj_t arg1077_408;
arg1077_408 = MAKE_PAIR(BNIL, BNIL);
arg1076_407 = MAKE_PAIR(arg1072_404, arg1077_408);
}
list1074_406 = MAKE_PAIR(arg1070_403, arg1076_407);
}
arg1059_393 = cons__138___r4_pairs_and_lists_6_3(arg1069_402, list1074_406);
}
}
arg1060_394 = normalize_progn_143___progn(body_357);
arg1061_395 = loop___expander_case(x_649, CDR(clauses_350));
{
obj_t list1063_397;
{
obj_t arg1065_398;
{
obj_t arg1066_399;
{
obj_t arg1067_400;
arg1067_400 = MAKE_PAIR(BNIL, BNIL);
arg1066_399 = MAKE_PAIR(arg1061_395, arg1067_400);
}
arg1065_398 = MAKE_PAIR(arg1060_394, arg1066_399);
}
list1063_397 = MAKE_PAIR(arg1059_393, arg1065_398);
}
return cons__138___r4_pairs_and_lists_6_3(arg1058_392, list1063_397);
}
}
}
 else {
bool_t test_733;
{
obj_t aux_734;
aux_734 = CDR(car_133_3_367);
test_733 = (aux_734==BNIL);
}
if(test_733){
datums_359 = CAR(car_133_3_367);
body_360 = CDR(e_120_171_362);
tag_119_205_361:
if(NULLP(body_360)){
FAILURE(string1253___expander_case,string1257___expander_case,x_649);}
 else {
obj_t arg1086_417;
obj_t arg1087_418;
obj_t arg1088_419;
obj_t arg1089_420;
arg1086_417 = symbol1258___expander_case;
{
obj_t arg1096_427;
obj_t arg1097_428;
obj_t arg1098_429;
arg1096_427 = symbol1259___expander_case;
arg1097_428 = symbol1256___expander_case;
{
obj_t arg1104_435;
arg1104_435 = symbol1260___expander_case;
{
obj_t list1106_437;
{
obj_t arg1107_438;
arg1107_438 = MAKE_PAIR(BNIL, BNIL);
list1106_437 = MAKE_PAIR(datums_359, arg1107_438);
}
arg1098_429 = cons__138___r4_pairs_and_lists_6_3(arg1104_435, list1106_437);
}
}
{
obj_t list1100_431;
{
obj_t arg1101_432;
{
obj_t arg1102_433;
arg1102_433 = MAKE_PAIR(BNIL, BNIL);
arg1101_432 = MAKE_PAIR(arg1098_429, arg1102_433);
}
list1100_431 = MAKE_PAIR(arg1097_428, arg1101_432);
}
arg1087_418 = cons__138___r4_pairs_and_lists_6_3(arg1096_427, list1100_431);
}
}
arg1088_419 = normalize_progn_143___progn(body_360);
arg1089_420 = loop___expander_case(x_649, CDR(clauses_350));
{
obj_t list1091_422;
{
obj_t arg1092_423;
{
obj_t arg1093_424;
{
obj_t arg1094_425;
arg1094_425 = MAKE_PAIR(BNIL, BNIL);
arg1093_424 = MAKE_PAIR(arg1089_420, arg1094_425);
}
arg1092_423 = MAKE_PAIR(arg1088_419, arg1093_424);
}
list1091_422 = MAKE_PAIR(arg1087_418, arg1092_423);
}
return cons__138___r4_pairs_and_lists_6_3(arg1086_417, list1091_422);
}
}
}
 else {
return BFALSE;
}
}
}
 else {
if(PAIRP(car_133_3_367)){
bool_t test_759;
{
obj_t aux_760;
aux_760 = CDR(car_133_3_367);
test_759 = (aux_760==BNIL);
}
if(test_759){
obj_t body_765;
obj_t datums_763;
datums_763 = CAR(car_133_3_367);
body_765 = CDR(e_120_171_362);
body_360 = body_765;
datums_359 = datums_763;
goto tag_119_205_361;
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
}
 else {
return BFALSE;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_case()
{
module_initialization_70___error(((long)0), "__EXPANDER_CASE");
module_initialization_70___bigloo(((long)0), "__EXPANDER_CASE");
module_initialization_70___tvector(((long)0), "__EXPANDER_CASE");
module_initialization_70___structure(((long)0), "__EXPANDER_CASE");
module_initialization_70___bexit(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_CASE");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_CASE");
return module_initialization_70___progn(((long)0), "__EXPANDER_CASE");
}

