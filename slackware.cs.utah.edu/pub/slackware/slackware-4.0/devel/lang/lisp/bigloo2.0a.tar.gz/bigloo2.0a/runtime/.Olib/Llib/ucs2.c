/*===========================================================================*/
/*   (Llib/ucs2.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t symbol1521___ucs2 = BUNSPEC;
static obj_t symbol1520___ucs2 = BUNSPEC;
static obj_t symbol1517___ucs2 = BUNSPEC;
static obj_t symbol1515___ucs2 = BUNSPEC;
static obj_t symbol1514___ucs2 = BUNSPEC;
static obj_t symbol1513___ucs2 = BUNSPEC;
static obj_t symbol1512___ucs2 = BUNSPEC;
static obj_t symbol1499___ucs2 = BUNSPEC;
static obj_t symbol1510___ucs2 = BUNSPEC;
static obj_t symbol1498___ucs2 = BUNSPEC;
static obj_t symbol1497___ucs2 = BUNSPEC;
static obj_t symbol1496___ucs2 = BUNSPEC;
static obj_t symbol1495___ucs2 = BUNSPEC;
static obj_t symbol1505___ucs2 = BUNSPEC;
static obj_t symbol1494___ucs2 = BUNSPEC;
static obj_t symbol1504___ucs2 = BUNSPEC;
static obj_t symbol1493___ucs2 = BUNSPEC;
static obj_t symbol1503___ucs2 = BUNSPEC;
static obj_t symbol1492___ucs2 = BUNSPEC;
static obj_t symbol1502___ucs2 = BUNSPEC;
static obj_t symbol1491___ucs2 = BUNSPEC;
static obj_t symbol1501___ucs2 = BUNSPEC;
static obj_t symbol1489___ucs2 = BUNSPEC;
static obj_t symbol1490___ucs2 = BUNSPEC;
static obj_t symbol1500___ucs2 = BUNSPEC;
static obj_t symbol1488___ucs2 = BUNSPEC;
static obj_t symbol1487___ucs2 = BUNSPEC;
static obj_t symbol1486___ucs2 = BUNSPEC;
static obj_t symbol1485___ucs2 = BUNSPEC;
static obj_t symbol1484___ucs2 = BUNSPEC;
static obj_t symbol1483___ucs2 = BUNSPEC;
static obj_t symbol1482___ucs2 = BUNSPEC;
static obj_t symbol1481___ucs2 = BUNSPEC;
static obj_t symbol1479___ucs2 = BUNSPEC;
static obj_t symbol1480___ucs2 = BUNSPEC;
static obj_t symbol1478___ucs2 = BUNSPEC;
static obj_t symbol1477___ucs2 = BUNSPEC;
static obj_t symbol1476___ucs2 = BUNSPEC;
static obj_t symbol1475___ucs2 = BUNSPEC;
static obj_t symbol1474___ucs2 = BUNSPEC;
static obj_t symbol1473___ucs2 = BUNSPEC;
static obj_t symbol1469___ucs2 = BUNSPEC;
static obj_t symbol1470___ucs2 = BUNSPEC;
static obj_t symbol1468___ucs2 = BUNSPEC;
static obj_t _ucs2__integer1205_230___ucs2(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _ucs2_downcase1203_237___ucs2(obj_t, obj_t);
extern bool_t ucs2_ci____165___ucs2(ucs2_t, ucs2_t);
extern bool_t ucs2_ci___239___ucs2(ucs2_t, ucs2_t);
extern bool_t ucs2_ci___212___ucs2(ucs2_t, ucs2_t);
extern bool_t ucs2_ci___156___ucs2(ucs2_t, ucs2_t);
static obj_t _ucs2_numeric_1198_227___ucs2(obj_t, obj_t);
static obj_t _ucs2_lower_case_1201_250___ucs2(obj_t, obj_t);
static obj_t _ucs2__1188_53___ucs2(obj_t, obj_t, obj_t);
extern bool_t ucs2_ci____166___ucs2(ucs2_t, ucs2_t);
static obj_t _ucs2__5___ucs2(obj_t, obj_t);
static obj_t _integer__ucs21204_111___ucs2(obj_t, obj_t);
extern bool_t ucs2__10___ucs2(obj_t);
extern bool_t ucs2_lower_case__105___ucs2(ucs2_t);
static obj_t _ucs2__1187_227___ucs2(obj_t, obj_t, obj_t);
static obj_t _ucs2_whitespace_1199_130___ucs2(obj_t, obj_t);
extern ucs2_t ucs2_upcase_130___ucs2(ucs2_t);
extern long ucs2__integer_171___ucs2(ucs2_t);
extern ucs2_t integer__ucs2_47___ucs2(long);
static obj_t _ucs2___1190_2___ucs2(obj_t, obj_t, obj_t);
static obj_t _ucs2_ci___1195_8___ucs2(obj_t, obj_t, obj_t);
static obj_t _ucs2___1191_94___ucs2(obj_t, obj_t, obj_t);
static obj_t _ucs2_ci___1196_128___ucs2(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _ucs2__char1207_113___ucs2(obj_t, obj_t);
extern ucs2_t ucs2_downcase_102___ucs2(ucs2_t);
static obj_t _ucs2_alphabetic_1197_250___ucs2(obj_t, obj_t);
extern bool_t ucs2_whitespace__106___ucs2(ucs2_t);
static obj_t _ucs2__1189_233___ucs2(obj_t, obj_t, obj_t);
extern bool_t ucs2_upper_case__41___ucs2(ucs2_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___ucs2(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _ucs2_ci__1193_104___ucs2(obj_t, obj_t, obj_t);
extern bool_t ucs2_numeric__113___ucs2(ucs2_t);
static obj_t _ucs2_ci__1192_66___ucs2(obj_t, obj_t, obj_t);
extern bool_t ucs2___135___ucs2(ucs2_t, ucs2_t);
extern bool_t ucs2___19___ucs2(ucs2_t, ucs2_t);
extern bool_t ucs2___136___ucs2(ucs2_t, ucs2_t);
static obj_t _char__ucs21206_158___ucs2(obj_t, obj_t);
extern char ucs2__char_237___ucs2(ucs2_t);
static obj_t _ucs2_upper_case_1200_27___ucs2(obj_t, obj_t);
static obj_t imported_modules_init_94___ucs2();
static obj_t _ucs2_upcase1202_58___ucs2(obj_t, obj_t);
extern bool_t ucs2_alphabetic__226___ucs2(ucs2_t);
extern bool_t ucs2____52___ucs2(ucs2_t, ucs2_t);
static obj_t require_initialization_114___ucs2 = BUNSPEC;
static obj_t _ucs2_ci__1194_30___ucs2(obj_t, obj_t, obj_t);
extern ucs2_t char__ucs2_17___ucs2(char);
static obj_t cnst_init_137___ucs2();
extern bool_t ucs2____55___ucs2(ucs2_t, ucs2_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( ucs2___env_137___ucs2, _ucs2__1188_53___ucs21523, _ucs2__1188_53___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_ci___env_108___ucs2, _ucs2_ci__1193_104___ucs21524, _ucs2_ci__1193_104___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2____env_231___ucs2, _ucs2___1190_2___ucs21525, _ucs2___1190_2___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2____env_59___ucs2, _ucs2___1191_94___ucs21526, _ucs2___1191_94___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2___env_102___ucs2, _ucs2__1187_227___ucs21527, _ucs2__1187_227___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_lower_case__env_166___ucs2, _ucs2_lower_case_1201_250___ucs21528, _ucs2_lower_case_1201_250___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_ci___env_145___ucs2, _ucs2_ci__1192_66___ucs21529, _ucs2_ci__1192_66___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_ci____env_242___ucs2, _ucs2_ci___1195_8___ucs21530, _ucs2_ci___1195_8___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_ci____env_35___ucs2, _ucs2_ci___1196_128___ucs21531, _ucs2_ci___1196_128___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2__char_env_30___ucs2, _ucs2__char1207_113___ucs21532, _ucs2__char1207_113___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2___env_18___ucs2, _ucs2__1189_233___ucs21533, _ucs2__1189_233___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2__env_71___ucs2, _ucs2__5___ucs21534, _ucs2__5___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_whitespace__env_17___ucs2, _ucs2_whitespace_1199_130___ucs21535, _ucs2_whitespace_1199_130___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_ci___env_251___ucs2, _ucs2_ci__1194_30___ucs21536, _ucs2_ci__1194_30___ucs2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ucs2_alphabetic__env_222___ucs2, _ucs2_alphabetic_1197_250___ucs21537, _ucs2_alphabetic_1197_250___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2__integer_env_115___ucs2, _ucs2__integer1205_230___ucs21538, _ucs2__integer1205_230___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_downcase_env_153___ucs2, _ucs2_downcase1203_237___ucs21539, _ucs2_downcase1203_237___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char__ucs2_env_195___ucs2, _char__ucs21206_158___ucs21540, _char__ucs21206_158___ucs2, 0L, 1 );
DEFINE_STRING( string1519___ucs2, string1519___ucs21541, "UCS-2 character out of ISO-LATIN-1 range", 40 );
DEFINE_STRING( string1518___ucs2, string1518___ucs21542, "ucs2->char", 10 );
DEFINE_STRING( string1516___ucs2, string1516___ucs21543, "CHAR", 4 );
DEFINE_STRING( string1511___ucs2, string1511___ucs21544, "LONG", 4 );
DEFINE_STRING( string1509___ucs2, string1509___ucs21545, "integer out of range or ", 24 );
DEFINE_STRING( string1508___ucs2, string1508___ucs21546, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1507___ucs2, string1507___ucs21547, "Undefined UCS-2 character", 25 );
DEFINE_STRING( string1506___ucs2, string1506___ucs21548, "integer->ucs2", 13 );
DEFINE_EXPORT_PROCEDURE( ucs2_numeric__env_39___ucs2, _ucs2_numeric_1198_227___ucs21549, _ucs2_numeric_1198_227___ucs2, 0L, 1 );
DEFINE_STRING( string1472___ucs2, string1472___ucs21550, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/ucs2.scm", 57 );
DEFINE_STRING( string1471___ucs2, string1471___ucs21551, "UCS2", 4 );
DEFINE_EXPORT_PROCEDURE( ucs2_upper_case__env_66___ucs2, _ucs2_upper_case_1200_27___ucs21552, _ucs2_upper_case_1200_27___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( integer__ucs2_env_61___ucs2, _integer__ucs21204_111___ucs21553, _integer__ucs21204_111___ucs2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ucs2_upcase_env_120___ucs2, _ucs2_upcase1202_58___ucs21554, _ucs2_upcase1202_58___ucs2, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___ucs2(long checksum_856, char * from_857)
{
if(CBOOL(require_initialization_114___ucs2)){
require_initialization_114___ucs2 = BBOOL(((bool_t)0));
cnst_init_137___ucs2();
imported_modules_init_94___ucs2();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___ucs2()
{
symbol1468___ucs2 = string_to_symbol("UCS2?");
symbol1469___ucs2 = string_to_symbol("UCS2=?");
symbol1470___ucs2 = string_to_symbol("_UCS2=?1187");
symbol1473___ucs2 = string_to_symbol("UCS2<?");
symbol1474___ucs2 = string_to_symbol("_UCS2<?1188");
symbol1475___ucs2 = string_to_symbol("UCS2>?");
symbol1476___ucs2 = string_to_symbol("_UCS2>?1189");
symbol1477___ucs2 = string_to_symbol("UCS2<=?");
symbol1478___ucs2 = string_to_symbol("_UCS2<=?1190");
symbol1479___ucs2 = string_to_symbol("UCS2>=?");
symbol1480___ucs2 = string_to_symbol("_UCS2>=?1191");
symbol1481___ucs2 = string_to_symbol("UCS2-CI=?");
symbol1482___ucs2 = string_to_symbol("_UCS2-CI=?1192");
symbol1483___ucs2 = string_to_symbol("UCS2-CI<?");
symbol1484___ucs2 = string_to_symbol("_UCS2-CI<?1193");
symbol1485___ucs2 = string_to_symbol("UCS2-CI>?");
symbol1486___ucs2 = string_to_symbol("_UCS2-CI>?1194");
symbol1487___ucs2 = string_to_symbol("UCS2-CI<=?");
symbol1488___ucs2 = string_to_symbol("_UCS2-CI<=?1195");
symbol1489___ucs2 = string_to_symbol("UCS2-CI>=?");
symbol1490___ucs2 = string_to_symbol("_UCS2-CI>=?1196");
symbol1491___ucs2 = string_to_symbol("UCS2-ALPHABETIC?");
symbol1492___ucs2 = string_to_symbol("_UCS2-ALPHABETIC?1197");
symbol1493___ucs2 = string_to_symbol("UCS2-NUMERIC?");
symbol1494___ucs2 = string_to_symbol("_UCS2-NUMERIC?1198");
symbol1495___ucs2 = string_to_symbol("UCS2-WHITESPACE?");
symbol1496___ucs2 = string_to_symbol("_UCS2-WHITESPACE?1199");
symbol1497___ucs2 = string_to_symbol("UCS2-UPPER-CASE?");
symbol1498___ucs2 = string_to_symbol("_UCS2-UPPER-CASE?1200");
symbol1499___ucs2 = string_to_symbol("UCS2-LOWER-CASE?");
symbol1500___ucs2 = string_to_symbol("_UCS2-LOWER-CASE?1201");
symbol1501___ucs2 = string_to_symbol("UCS2-UPCASE");
symbol1502___ucs2 = string_to_symbol("_UCS2-UPCASE1202");
symbol1503___ucs2 = string_to_symbol("UCS2-DOWNCASE");
symbol1504___ucs2 = string_to_symbol("_UCS2-DOWNCASE1203");
symbol1505___ucs2 = string_to_symbol("INTEGER->UCS2");
symbol1510___ucs2 = string_to_symbol("_INTEGER->UCS21204");
symbol1512___ucs2 = string_to_symbol("UCS2->INTEGER");
symbol1513___ucs2 = string_to_symbol("_UCS2->INTEGER1205");
symbol1514___ucs2 = string_to_symbol("CHAR->UCS2");
symbol1515___ucs2 = string_to_symbol("_CHAR->UCS21206");
symbol1517___ucs2 = string_to_symbol("UCS2->CHAR");
symbol1520___ucs2 = string_to_symbol("_UCS2->CHAR1207");
return (symbol1521___ucs2 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* ucs2? */bool_t ucs2__10___ucs2(obj_t obj_1)
{
{
obj_t symbol1142_726;
symbol1142_726 = symbol1468___ucs2;
{
PUSH_TRACE(symbol1142_726);
BUNSPEC;
{
bool_t aux1141_727;
aux1141_727 = UCS2P(obj_1);
POP_TRACE();
return aux1141_727;
}
}
}
}


/* _ucs2? */obj_t _ucs2__5___ucs2(obj_t env_468, obj_t obj_469)
{
{
bool_t aux_910;
{
obj_t obj_728;
obj_728 = obj_469;
{
obj_t symbol1142_729;
symbol1142_729 = symbol1468___ucs2;
{
PUSH_TRACE(symbol1142_729);
BUNSPEC;
{
bool_t aux1141_730;
aux1141_730 = UCS2P(obj_728);
POP_TRACE();
aux_910 = aux1141_730;
}
}
}
}
return BBOOL(aux_910);
}
}


/* ucs2=? */bool_t ucs2___19___ucs2(ucs2_t ucs2a_2, ucs2_t ucs2b_3)
{
{
obj_t symbol1144_731;
symbol1144_731 = symbol1469___ucs2;
{
PUSH_TRACE(symbol1144_731);
BUNSPEC;
{
bool_t aux1143_732;
aux1143_732 = (ucs2a_2) == (ucs2b_3);
POP_TRACE();
return aux1143_732;
}
}
}
}


/* _ucs2=?1187 */obj_t _ucs2__1187_227___ucs2(obj_t env_470, obj_t ucs2a_471, obj_t ucs2b_472)
{
{
bool_t aux_918;
{
ucs2_t ucs2a_733;
ucs2_t ucs2b_734;
{
obj_t aux_919;
if(UCS2P(ucs2a_471)){
aux_919 = ucs2a_471;
}
 else {
bigloo_type_error_location_103___error(symbol1470___ucs2, string1471___ucs2, ucs2a_471, string1472___ucs2, BINT(((long)4750)));
exit( -1 );}
ucs2a_733 = CUCS2(aux_919);
}
{
obj_t aux_926;
if(UCS2P(ucs2b_472)){
aux_926 = ucs2b_472;
}
 else {
bigloo_type_error_location_103___error(symbol1470___ucs2, string1471___ucs2, ucs2b_472, string1472___ucs2, BINT(((long)4750)));
exit( -1 );}
ucs2b_734 = CUCS2(aux_926);
}
{
obj_t symbol1144_735;
symbol1144_735 = symbol1469___ucs2;
{
PUSH_TRACE(symbol1144_735);
BUNSPEC;
{
bool_t aux1143_736;
aux1143_736 = (ucs2a_733) == (ucs2b_734);
POP_TRACE();
aux_918 = aux1143_736;
}
}
}
}
return BBOOL(aux_918);
}
}


/* ucs2<? */bool_t ucs2___136___ucs2(ucs2_t ucs2a_4, ucs2_t ucs2b_5)
{
{
obj_t symbol1146_737;
symbol1146_737 = symbol1473___ucs2;
{
PUSH_TRACE(symbol1146_737);
BUNSPEC;
{
bool_t aux1145_738;
aux1145_738 = (ucs2a_4) < (ucs2b_5);
POP_TRACE();
return aux1145_738;
}
}
}
}


/* _ucs2<?1188 */obj_t _ucs2__1188_53___ucs2(obj_t env_473, obj_t ucs2a_474, obj_t ucs2b_475)
{
{
bool_t aux_940;
{
ucs2_t ucs2a_739;
ucs2_t ucs2b_740;
{
obj_t aux_941;
if(UCS2P(ucs2a_474)){
aux_941 = ucs2a_474;
}
 else {
bigloo_type_error_location_103___error(symbol1474___ucs2, string1471___ucs2, ucs2a_474, string1472___ucs2, BINT(((long)5055)));
exit( -1 );}
ucs2a_739 = CUCS2(aux_941);
}
{
obj_t aux_948;
if(UCS2P(ucs2b_475)){
aux_948 = ucs2b_475;
}
 else {
bigloo_type_error_location_103___error(symbol1474___ucs2, string1471___ucs2, ucs2b_475, string1472___ucs2, BINT(((long)5055)));
exit( -1 );}
ucs2b_740 = CUCS2(aux_948);
}
{
obj_t symbol1146_741;
symbol1146_741 = symbol1473___ucs2;
{
PUSH_TRACE(symbol1146_741);
BUNSPEC;
{
bool_t aux1145_742;
aux1145_742 = (ucs2a_739) < (ucs2b_740);
POP_TRACE();
aux_940 = aux1145_742;
}
}
}
}
return BBOOL(aux_940);
}
}


/* ucs2>? */bool_t ucs2___135___ucs2(ucs2_t ucs2a_6, ucs2_t ucs2b_7)
{
{
obj_t symbol1148_743;
symbol1148_743 = symbol1475___ucs2;
{
PUSH_TRACE(symbol1148_743);
BUNSPEC;
{
bool_t aux1147_744;
aux1147_744 = (ucs2a_6) > (ucs2b_7);
POP_TRACE();
return aux1147_744;
}
}
}
}


/* _ucs2>?1189 */obj_t _ucs2__1189_233___ucs2(obj_t env_476, obj_t ucs2a_477, obj_t ucs2b_478)
{
{
bool_t aux_962;
{
ucs2_t ucs2a_745;
ucs2_t ucs2b_746;
{
obj_t aux_963;
if(UCS2P(ucs2a_477)){
aux_963 = ucs2a_477;
}
 else {
bigloo_type_error_location_103___error(symbol1476___ucs2, string1471___ucs2, ucs2a_477, string1472___ucs2, BINT(((long)5359)));
exit( -1 );}
ucs2a_745 = CUCS2(aux_963);
}
{
obj_t aux_970;
if(UCS2P(ucs2b_478)){
aux_970 = ucs2b_478;
}
 else {
bigloo_type_error_location_103___error(symbol1476___ucs2, string1471___ucs2, ucs2b_478, string1472___ucs2, BINT(((long)5359)));
exit( -1 );}
ucs2b_746 = CUCS2(aux_970);
}
{
obj_t symbol1148_747;
symbol1148_747 = symbol1475___ucs2;
{
PUSH_TRACE(symbol1148_747);
BUNSPEC;
{
bool_t aux1147_748;
aux1147_748 = (ucs2a_745) > (ucs2b_746);
POP_TRACE();
aux_962 = aux1147_748;
}
}
}
}
return BBOOL(aux_962);
}
}


/* ucs2<=? */bool_t ucs2____55___ucs2(ucs2_t ucs2a_8, ucs2_t ucs2b_9)
{
{
obj_t symbol1150_749;
symbol1150_749 = symbol1477___ucs2;
{
PUSH_TRACE(symbol1150_749);
BUNSPEC;
{
bool_t aux1149_750;
aux1149_750 = (ucs2a_8) <= (ucs2b_9);
POP_TRACE();
return aux1149_750;
}
}
}
}


/* _ucs2<=?1190 */obj_t _ucs2___1190_2___ucs2(obj_t env_479, obj_t ucs2a_480, obj_t ucs2b_481)
{
{
bool_t aux_984;
{
ucs2_t ucs2a_751;
ucs2_t ucs2b_752;
{
obj_t aux_985;
if(UCS2P(ucs2a_480)){
aux_985 = ucs2a_480;
}
 else {
bigloo_type_error_location_103___error(symbol1478___ucs2, string1471___ucs2, ucs2a_480, string1472___ucs2, BINT(((long)5664)));
exit( -1 );}
ucs2a_751 = CUCS2(aux_985);
}
{
obj_t aux_992;
if(UCS2P(ucs2b_481)){
aux_992 = ucs2b_481;
}
 else {
bigloo_type_error_location_103___error(symbol1478___ucs2, string1471___ucs2, ucs2b_481, string1472___ucs2, BINT(((long)5664)));
exit( -1 );}
ucs2b_752 = CUCS2(aux_992);
}
{
obj_t symbol1150_753;
symbol1150_753 = symbol1477___ucs2;
{
PUSH_TRACE(symbol1150_753);
BUNSPEC;
{
bool_t aux1149_754;
aux1149_754 = (ucs2a_751) <= (ucs2b_752);
POP_TRACE();
aux_984 = aux1149_754;
}
}
}
}
return BBOOL(aux_984);
}
}


/* ucs2>=? */bool_t ucs2____52___ucs2(ucs2_t ucs2a_10, ucs2_t ucs2b_11)
{
{
obj_t symbol1152_755;
symbol1152_755 = symbol1479___ucs2;
{
PUSH_TRACE(symbol1152_755);
BUNSPEC;
{
bool_t aux1151_756;
aux1151_756 = (ucs2a_10) >= (ucs2b_11);
POP_TRACE();
return aux1151_756;
}
}
}
}


/* _ucs2>=?1191 */obj_t _ucs2___1191_94___ucs2(obj_t env_482, obj_t ucs2a_483, obj_t ucs2b_484)
{
{
bool_t aux_1006;
{
ucs2_t ucs2a_757;
ucs2_t ucs2b_758;
{
obj_t aux_1007;
if(UCS2P(ucs2a_483)){
aux_1007 = ucs2a_483;
}
 else {
bigloo_type_error_location_103___error(symbol1480___ucs2, string1471___ucs2, ucs2a_483, string1472___ucs2, BINT(((long)5970)));
exit( -1 );}
ucs2a_757 = CUCS2(aux_1007);
}
{
obj_t aux_1014;
if(UCS2P(ucs2b_484)){
aux_1014 = ucs2b_484;
}
 else {
bigloo_type_error_location_103___error(symbol1480___ucs2, string1471___ucs2, ucs2b_484, string1472___ucs2, BINT(((long)5970)));
exit( -1 );}
ucs2b_758 = CUCS2(aux_1014);
}
{
obj_t symbol1152_759;
symbol1152_759 = symbol1479___ucs2;
{
PUSH_TRACE(symbol1152_759);
BUNSPEC;
{
bool_t aux1151_760;
aux1151_760 = (ucs2a_757) >= (ucs2b_758);
POP_TRACE();
aux_1006 = aux1151_760;
}
}
}
}
return BBOOL(aux_1006);
}
}


/* ucs2-ci=? */bool_t ucs2_ci___212___ucs2(ucs2_t ucs2a_12, ucs2_t ucs2b_13)
{
{
obj_t symbol1154_761;
symbol1154_761 = symbol1481___ucs2;
{
PUSH_TRACE(symbol1154_761);
BUNSPEC;
{
bool_t aux1153_762;
{
ucs2_t arg1005_763;
ucs2_t arg1006_764;
arg1005_763 = ucs2_toupper(ucs2a_12);
arg1006_764 = ucs2_toupper(ucs2b_13);
aux1153_762 = (arg1005_763) == (arg1006_764);
}
POP_TRACE();
return aux1153_762;
}
}
}
}


/* _ucs2-ci=?1192 */obj_t _ucs2_ci__1192_66___ucs2(obj_t env_485, obj_t ucs2a_486, obj_t ucs2b_487)
{
{
bool_t aux_1030;
{
ucs2_t ucs2a_765;
ucs2_t ucs2b_766;
{
obj_t aux_1031;
if(UCS2P(ucs2a_486)){
aux_1031 = ucs2a_486;
}
 else {
bigloo_type_error_location_103___error(symbol1482___ucs2, string1471___ucs2, ucs2a_486, string1472___ucs2, BINT(((long)6277)));
exit( -1 );}
ucs2a_765 = CUCS2(aux_1031);
}
{
obj_t aux_1038;
if(UCS2P(ucs2b_487)){
aux_1038 = ucs2b_487;
}
 else {
bigloo_type_error_location_103___error(symbol1482___ucs2, string1471___ucs2, ucs2b_487, string1472___ucs2, BINT(((long)6277)));
exit( -1 );}
ucs2b_766 = CUCS2(aux_1038);
}
{
obj_t symbol1154_767;
symbol1154_767 = symbol1481___ucs2;
{
PUSH_TRACE(symbol1154_767);
BUNSPEC;
{
bool_t aux1153_768;
{
ucs2_t arg1005_769;
ucs2_t arg1006_770;
arg1005_769 = ucs2_toupper(ucs2a_765);
arg1006_770 = ucs2_toupper(ucs2b_766);
aux1153_768 = (arg1005_769) == (arg1006_770);
}
POP_TRACE();
aux_1030 = aux1153_768;
}
}
}
}
return BBOOL(aux_1030);
}
}


/* ucs2-ci<? */bool_t ucs2_ci___156___ucs2(ucs2_t ucs2a_14, ucs2_t ucs2b_15)
{
{
obj_t symbol1156_771;
symbol1156_771 = symbol1483___ucs2;
{
PUSH_TRACE(symbol1156_771);
BUNSPEC;
{
bool_t aux1155_772;
{
ucs2_t arg1007_773;
ucs2_t arg1008_774;
arg1007_773 = ucs2_toupper(ucs2a_14);
arg1008_774 = ucs2_toupper(ucs2b_15);
aux1155_772 = (arg1007_773) < (arg1008_774);
}
POP_TRACE();
return aux1155_772;
}
}
}
}


/* _ucs2-ci<?1193 */obj_t _ucs2_ci__1193_104___ucs2(obj_t env_488, obj_t ucs2a_489, obj_t ucs2b_490)
{
{
bool_t aux_1056;
{
ucs2_t ucs2a_775;
ucs2_t ucs2b_776;
{
obj_t aux_1057;
if(UCS2P(ucs2a_489)){
aux_1057 = ucs2a_489;
}
 else {
bigloo_type_error_location_103___error(symbol1484___ucs2, string1471___ucs2, ucs2a_489, string1472___ucs2, BINT(((long)6592)));
exit( -1 );}
ucs2a_775 = CUCS2(aux_1057);
}
{
obj_t aux_1064;
if(UCS2P(ucs2b_490)){
aux_1064 = ucs2b_490;
}
 else {
bigloo_type_error_location_103___error(symbol1484___ucs2, string1471___ucs2, ucs2b_490, string1472___ucs2, BINT(((long)6592)));
exit( -1 );}
ucs2b_776 = CUCS2(aux_1064);
}
{
obj_t symbol1156_777;
symbol1156_777 = symbol1483___ucs2;
{
PUSH_TRACE(symbol1156_777);
BUNSPEC;
{
bool_t aux1155_778;
{
ucs2_t arg1007_779;
ucs2_t arg1008_780;
arg1007_779 = ucs2_toupper(ucs2a_775);
arg1008_780 = ucs2_toupper(ucs2b_776);
aux1155_778 = (arg1007_779) < (arg1008_780);
}
POP_TRACE();
aux_1056 = aux1155_778;
}
}
}
}
return BBOOL(aux_1056);
}
}


/* ucs2-ci>? */bool_t ucs2_ci___239___ucs2(ucs2_t ucs2a_16, ucs2_t ucs2b_17)
{
{
obj_t symbol1158_781;
symbol1158_781 = symbol1485___ucs2;
{
PUSH_TRACE(symbol1158_781);
BUNSPEC;
{
bool_t aux1157_782;
{
ucs2_t arg1009_783;
ucs2_t arg1010_784;
arg1009_783 = ucs2_toupper(ucs2a_16);
arg1010_784 = ucs2_toupper(ucs2b_17);
aux1157_782 = (arg1009_783) > (arg1010_784);
}
POP_TRACE();
return aux1157_782;
}
}
}
}


/* _ucs2-ci>?1194 */obj_t _ucs2_ci__1194_30___ucs2(obj_t env_491, obj_t ucs2a_492, obj_t ucs2b_493)
{
{
bool_t aux_1082;
{
ucs2_t ucs2a_785;
ucs2_t ucs2b_786;
{
obj_t aux_1083;
if(UCS2P(ucs2a_492)){
aux_1083 = ucs2a_492;
}
 else {
bigloo_type_error_location_103___error(symbol1486___ucs2, string1471___ucs2, ucs2a_492, string1472___ucs2, BINT(((long)6908)));
exit( -1 );}
ucs2a_785 = CUCS2(aux_1083);
}
{
obj_t aux_1090;
if(UCS2P(ucs2b_493)){
aux_1090 = ucs2b_493;
}
 else {
bigloo_type_error_location_103___error(symbol1486___ucs2, string1471___ucs2, ucs2b_493, string1472___ucs2, BINT(((long)6908)));
exit( -1 );}
ucs2b_786 = CUCS2(aux_1090);
}
{
obj_t symbol1158_787;
symbol1158_787 = symbol1485___ucs2;
{
PUSH_TRACE(symbol1158_787);
BUNSPEC;
{
bool_t aux1157_788;
{
ucs2_t arg1009_789;
ucs2_t arg1010_790;
arg1009_789 = ucs2_toupper(ucs2a_785);
arg1010_790 = ucs2_toupper(ucs2b_786);
aux1157_788 = (arg1009_789) > (arg1010_790);
}
POP_TRACE();
aux_1082 = aux1157_788;
}
}
}
}
return BBOOL(aux_1082);
}
}


/* ucs2-ci<=? */bool_t ucs2_ci____166___ucs2(ucs2_t ucs2a_18, ucs2_t ucs2b_19)
{
{
obj_t symbol1160_791;
symbol1160_791 = symbol1487___ucs2;
{
PUSH_TRACE(symbol1160_791);
BUNSPEC;
{
bool_t aux1159_792;
{
ucs2_t arg1011_793;
ucs2_t arg1012_794;
arg1011_793 = ucs2_toupper(ucs2a_18);
arg1012_794 = ucs2_toupper(ucs2b_19);
aux1159_792 = (arg1011_793) <= (arg1012_794);
}
POP_TRACE();
return aux1159_792;
}
}
}
}


/* _ucs2-ci<=?1195 */obj_t _ucs2_ci___1195_8___ucs2(obj_t env_494, obj_t ucs2a_495, obj_t ucs2b_496)
{
{
bool_t aux_1108;
{
ucs2_t ucs2a_795;
ucs2_t ucs2b_796;
{
obj_t aux_1109;
if(UCS2P(ucs2a_495)){
aux_1109 = ucs2a_495;
}
 else {
bigloo_type_error_location_103___error(symbol1488___ucs2, string1471___ucs2, ucs2a_495, string1472___ucs2, BINT(((long)7224)));
exit( -1 );}
ucs2a_795 = CUCS2(aux_1109);
}
{
obj_t aux_1116;
if(UCS2P(ucs2b_496)){
aux_1116 = ucs2b_496;
}
 else {
bigloo_type_error_location_103___error(symbol1488___ucs2, string1471___ucs2, ucs2b_496, string1472___ucs2, BINT(((long)7224)));
exit( -1 );}
ucs2b_796 = CUCS2(aux_1116);
}
{
obj_t symbol1160_797;
symbol1160_797 = symbol1487___ucs2;
{
PUSH_TRACE(symbol1160_797);
BUNSPEC;
{
bool_t aux1159_798;
{
ucs2_t arg1011_799;
ucs2_t arg1012_800;
arg1011_799 = ucs2_toupper(ucs2a_795);
arg1012_800 = ucs2_toupper(ucs2b_796);
aux1159_798 = (arg1011_799) <= (arg1012_800);
}
POP_TRACE();
aux_1108 = aux1159_798;
}
}
}
}
return BBOOL(aux_1108);
}
}


/* ucs2-ci>=? */bool_t ucs2_ci____165___ucs2(ucs2_t ucs2a_20, ucs2_t ucs2b_21)
{
{
obj_t symbol1162_801;
symbol1162_801 = symbol1489___ucs2;
{
PUSH_TRACE(symbol1162_801);
BUNSPEC;
{
bool_t aux1161_802;
{
ucs2_t arg1013_803;
ucs2_t arg1014_804;
arg1013_803 = ucs2_toupper(ucs2a_20);
arg1014_804 = ucs2_toupper(ucs2b_21);
aux1161_802 = (arg1013_803) >= (arg1014_804);
}
POP_TRACE();
return aux1161_802;
}
}
}
}


/* _ucs2-ci>=?1196 */obj_t _ucs2_ci___1196_128___ucs2(obj_t env_497, obj_t ucs2a_498, obj_t ucs2b_499)
{
{
bool_t aux_1134;
{
ucs2_t ucs2a_805;
ucs2_t ucs2b_806;
{
obj_t aux_1135;
if(UCS2P(ucs2a_498)){
aux_1135 = ucs2a_498;
}
 else {
bigloo_type_error_location_103___error(symbol1490___ucs2, string1471___ucs2, ucs2a_498, string1472___ucs2, BINT(((long)7541)));
exit( -1 );}
ucs2a_805 = CUCS2(aux_1135);
}
{
obj_t aux_1142;
if(UCS2P(ucs2b_499)){
aux_1142 = ucs2b_499;
}
 else {
bigloo_type_error_location_103___error(symbol1490___ucs2, string1471___ucs2, ucs2b_499, string1472___ucs2, BINT(((long)7541)));
exit( -1 );}
ucs2b_806 = CUCS2(aux_1142);
}
{
obj_t symbol1162_807;
symbol1162_807 = symbol1489___ucs2;
{
PUSH_TRACE(symbol1162_807);
BUNSPEC;
{
bool_t aux1161_808;
{
ucs2_t arg1013_809;
ucs2_t arg1014_810;
arg1013_809 = ucs2_toupper(ucs2a_805);
arg1014_810 = ucs2_toupper(ucs2b_806);
aux1161_808 = (arg1013_809) >= (arg1014_810);
}
POP_TRACE();
aux_1134 = aux1161_808;
}
}
}
}
return BBOOL(aux_1134);
}
}


/* ucs2-alphabetic? */bool_t ucs2_alphabetic__226___ucs2(ucs2_t ucs2_22)
{
{
obj_t symbol1164_811;
symbol1164_811 = symbol1491___ucs2;
{
PUSH_TRACE(symbol1164_811);
BUNSPEC;
{
bool_t aux1163_812;
aux1163_812 = ucs2_letterp(ucs2_22);
POP_TRACE();
return aux1163_812;
}
}
}
}


/* _ucs2-alphabetic?1197 */obj_t _ucs2_alphabetic_1197_250___ucs2(obj_t env_500, obj_t ucs2_501)
{
{
bool_t aux_1158;
{
ucs2_t ucs2_813;
{
obj_t aux_1159;
if(UCS2P(ucs2_501)){
aux_1159 = ucs2_501;
}
 else {
bigloo_type_error_location_103___error(symbol1492___ucs2, string1471___ucs2, ucs2_501, string1472___ucs2, BINT(((long)7858)));
exit( -1 );}
ucs2_813 = CUCS2(aux_1159);
}
{
obj_t symbol1164_814;
symbol1164_814 = symbol1491___ucs2;
{
PUSH_TRACE(symbol1164_814);
BUNSPEC;
{
bool_t aux1163_815;
aux1163_815 = ucs2_letterp(ucs2_813);
POP_TRACE();
aux_1158 = aux1163_815;
}
}
}
}
return BBOOL(aux_1158);
}
}


/* ucs2-numeric? */bool_t ucs2_numeric__113___ucs2(ucs2_t ucs2_23)
{
{
obj_t symbol1166_816;
symbol1166_816 = symbol1493___ucs2;
{
PUSH_TRACE(symbol1166_816);
BUNSPEC;
{
bool_t aux1165_817;
aux1165_817 = ucs2_digitp(ucs2_23);
POP_TRACE();
return aux1165_817;
}
}
}
}


/* _ucs2-numeric?1198 */obj_t _ucs2_numeric_1198_227___ucs2(obj_t env_502, obj_t ucs2_503)
{
{
bool_t aux_1173;
{
ucs2_t ucs2_818;
{
obj_t aux_1174;
if(UCS2P(ucs2_503)){
aux_1174 = ucs2_503;
}
 else {
bigloo_type_error_location_103___error(symbol1494___ucs2, string1471___ucs2, ucs2_503, string1472___ucs2, BINT(((long)8146)));
exit( -1 );}
ucs2_818 = CUCS2(aux_1174);
}
{
obj_t symbol1166_819;
symbol1166_819 = symbol1493___ucs2;
{
PUSH_TRACE(symbol1166_819);
BUNSPEC;
{
bool_t aux1165_820;
aux1165_820 = ucs2_digitp(ucs2_818);
POP_TRACE();
aux_1173 = aux1165_820;
}
}
}
}
return BBOOL(aux_1173);
}
}


/* ucs2-whitespace? */bool_t ucs2_whitespace__106___ucs2(ucs2_t ucs2_24)
{
{
obj_t symbol1168_821;
symbol1168_821 = symbol1495___ucs2;
{
PUSH_TRACE(symbol1168_821);
BUNSPEC;
{
bool_t aux1167_822;
aux1167_822 = ucs2_whitespacep(ucs2_24);
POP_TRACE();
return aux1167_822;
}
}
}
}


/* _ucs2-whitespace?1199 */obj_t _ucs2_whitespace_1199_130___ucs2(obj_t env_504, obj_t ucs2_505)
{
{
bool_t aux_1188;
{
ucs2_t ucs2_823;
{
obj_t aux_1189;
if(UCS2P(ucs2_505)){
aux_1189 = ucs2_505;
}
 else {
bigloo_type_error_location_103___error(symbol1496___ucs2, string1471___ucs2, ucs2_505, string1472___ucs2, BINT(((long)8430)));
exit( -1 );}
ucs2_823 = CUCS2(aux_1189);
}
{
obj_t symbol1168_824;
symbol1168_824 = symbol1495___ucs2;
{
PUSH_TRACE(symbol1168_824);
BUNSPEC;
{
bool_t aux1167_825;
aux1167_825 = ucs2_whitespacep(ucs2_823);
POP_TRACE();
aux_1188 = aux1167_825;
}
}
}
}
return BBOOL(aux_1188);
}
}


/* ucs2-upper-case? */bool_t ucs2_upper_case__41___ucs2(ucs2_t ucs2_25)
{
{
obj_t symbol1170_826;
symbol1170_826 = symbol1497___ucs2;
{
PUSH_TRACE(symbol1170_826);
BUNSPEC;
{
bool_t aux1169_827;
aux1169_827 = ucs2_upperp(ucs2_25);
POP_TRACE();
return aux1169_827;
}
}
}
}


/* _ucs2-upper-case?1200 */obj_t _ucs2_upper_case_1200_27___ucs2(obj_t env_506, obj_t ucs2_507)
{
{
bool_t aux_1203;
{
ucs2_t ucs2_828;
{
obj_t aux_1204;
if(UCS2P(ucs2_507)){
aux_1204 = ucs2_507;
}
 else {
bigloo_type_error_location_103___error(symbol1498___ucs2, string1471___ucs2, ucs2_507, string1472___ucs2, BINT(((long)8722)));
exit( -1 );}
ucs2_828 = CUCS2(aux_1204);
}
{
obj_t symbol1170_829;
symbol1170_829 = symbol1497___ucs2;
{
PUSH_TRACE(symbol1170_829);
BUNSPEC;
{
bool_t aux1169_830;
aux1169_830 = ucs2_upperp(ucs2_828);
POP_TRACE();
aux_1203 = aux1169_830;
}
}
}
}
return BBOOL(aux_1203);
}
}


/* ucs2-lower-case? */bool_t ucs2_lower_case__105___ucs2(ucs2_t ucs2_26)
{
{
obj_t symbol1172_831;
symbol1172_831 = symbol1499___ucs2;
{
PUSH_TRACE(symbol1172_831);
BUNSPEC;
{
bool_t aux1171_832;
aux1171_832 = ucs2_lowerp(ucs2_26);
POP_TRACE();
return aux1171_832;
}
}
}
}


/* _ucs2-lower-case?1201 */obj_t _ucs2_lower_case_1201_250___ucs2(obj_t env_508, obj_t ucs2_509)
{
{
bool_t aux_1218;
{
ucs2_t ucs2_833;
{
obj_t aux_1219;
if(UCS2P(ucs2_509)){
aux_1219 = ucs2_509;
}
 else {
bigloo_type_error_location_103___error(symbol1500___ucs2, string1471___ucs2, ucs2_509, string1472___ucs2, BINT(((long)9009)));
exit( -1 );}
ucs2_833 = CUCS2(aux_1219);
}
{
obj_t symbol1172_834;
symbol1172_834 = symbol1499___ucs2;
{
PUSH_TRACE(symbol1172_834);
BUNSPEC;
{
bool_t aux1171_835;
aux1171_835 = ucs2_lowerp(ucs2_833);
POP_TRACE();
aux_1218 = aux1171_835;
}
}
}
}
return BBOOL(aux_1218);
}
}


/* ucs2-upcase */ucs2_t ucs2_upcase_130___ucs2(ucs2_t ucs2_27)
{
{
obj_t symbol1174_836;
symbol1174_836 = symbol1501___ucs2;
{
PUSH_TRACE(symbol1174_836);
BUNSPEC;
{
ucs2_t aux1173_837;
aux1173_837 = ucs2_toupper(ucs2_27);
POP_TRACE();
return aux1173_837;
}
}
}
}


/* _ucs2-upcase1202 */obj_t _ucs2_upcase1202_58___ucs2(obj_t env_510, obj_t ucs2_511)
{
{
ucs2_t aux_1233;
{
ucs2_t ucs2_838;
{
obj_t aux_1234;
if(UCS2P(ucs2_511)){
aux_1234 = ucs2_511;
}
 else {
bigloo_type_error_location_103___error(symbol1502___ucs2, string1471___ucs2, ucs2_511, string1472___ucs2, BINT(((long)9296)));
exit( -1 );}
ucs2_838 = CUCS2(aux_1234);
}
{
obj_t symbol1174_839;
symbol1174_839 = symbol1501___ucs2;
{
PUSH_TRACE(symbol1174_839);
BUNSPEC;
{
ucs2_t aux1173_840;
aux1173_840 = ucs2_toupper(ucs2_838);
POP_TRACE();
aux_1233 = aux1173_840;
}
}
}
}
return BUCS2(aux_1233);
}
}


/* ucs2-downcase */ucs2_t ucs2_downcase_102___ucs2(ucs2_t ucs2_28)
{
{
obj_t symbol1176_841;
symbol1176_841 = symbol1503___ucs2;
{
PUSH_TRACE(symbol1176_841);
BUNSPEC;
{
ucs2_t aux1175_842;
aux1175_842 = ucs2_tolower(ucs2_28);
POP_TRACE();
return aux1175_842;
}
}
}
}


/* _ucs2-downcase1203 */obj_t _ucs2_downcase1203_237___ucs2(obj_t env_512, obj_t ucs2_513)
{
{
ucs2_t aux_1248;
{
ucs2_t ucs2_843;
{
obj_t aux_1249;
if(UCS2P(ucs2_513)){
aux_1249 = ucs2_513;
}
 else {
bigloo_type_error_location_103___error(symbol1504___ucs2, string1471___ucs2, ucs2_513, string1472___ucs2, BINT(((long)9578)));
exit( -1 );}
ucs2_843 = CUCS2(aux_1249);
}
{
obj_t symbol1176_844;
symbol1176_844 = symbol1503___ucs2;
{
PUSH_TRACE(symbol1176_844);
BUNSPEC;
{
ucs2_t aux1175_845;
aux1175_845 = ucs2_tolower(ucs2_843);
POP_TRACE();
aux_1248 = aux1175_845;
}
}
}
}
return BUCS2(aux_1248);
}
}


/* integer->ucs2 */ucs2_t integer__ucs2_47___ucs2(long int_29)
{
{
obj_t symbol1178_458;
symbol1178_458 = symbol1505___ucs2;
{
PUSH_TRACE(symbol1178_458);
BUNSPEC;
{
ucs2_t aux1177_459;
{
bool_t test_1261;
if((int_29>((long)0))){
test_1261 = (int_29<((long)65536));
}
 else {
test_1261 = ((bool_t)0);
}
if(test_1261){
bool_t test1016_253;
{
ucs2_t arg1017_254;
arg1017_254 = (ucs2_t)(int_29);
test1016_253 = ucs2_definedp(arg1017_254);
}
if(test1016_253){
aux1177_459 = (ucs2_t)(int_29);
}
 else {
obj_t aux_1269;
{
obj_t aux1411_684;
aux1411_684 = debug_error_location_199___error(string1506___ucs2, string1507___ucs2, BINT(int_29), string1508___ucs2, BINT(((long)7610)));
if(UCS2P(aux1411_684)){
aux_1269 = aux1411_684;
}
 else {
bigloo_type_error_location_103___error(symbol1505___ucs2, string1471___ucs2, aux1411_684, string1508___ucs2, BINT(((long)7610)));
exit( -1 );}
}
aux1177_459 = CUCS2(aux_1269);
}
}
 else {
obj_t aux_1279;
{
obj_t aux1417_690;
aux1417_690 = debug_error_location_199___error(string1506___ucs2, string1509___ucs2, BINT(int_29), string1508___ucs2, BINT(((long)7610)));
if(UCS2P(aux1417_690)){
aux_1279 = aux1417_690;
}
 else {
bigloo_type_error_location_103___error(symbol1505___ucs2, string1471___ucs2, aux1417_690, string1508___ucs2, BINT(((long)7610)));
exit( -1 );}
}
aux1177_459 = CUCS2(aux_1279);
}
}
POP_TRACE();
return aux1177_459;
}
}
}
}


/* _integer->ucs21204 */obj_t _integer__ucs21204_111___ucs2(obj_t env_514, obj_t int_515)
{
{
ucs2_t aux_1290;
{
long aux_1291;
{
obj_t aux_1292;
if(INTEGERP(int_515)){
aux_1292 = int_515;
}
 else {
bigloo_type_error_location_103___error(symbol1510___ucs2, string1511___ucs2, int_515, string1472___ucs2, BINT(((long)9871)));
exit( -1 );}
aux_1291 = (long)CINT(aux_1292);
}
aux_1290 = integer__ucs2_47___ucs2(aux_1291);
}
return BUCS2(aux_1290);
}
}


/* ucs2->integer */long ucs2__integer_171___ucs2(ucs2_t ucs2_30)
{
{
obj_t symbol1180_846;
symbol1180_846 = symbol1512___ucs2;
{
PUSH_TRACE(symbol1180_846);
BUNSPEC;
{
long aux1179_847;
aux1179_847 = (long)(ucs2_30);
POP_TRACE();
return aux1179_847;
}
}
}
}


/* _ucs2->integer1205 */obj_t _ucs2__integer1205_230___ucs2(obj_t env_516, obj_t ucs2_517)
{
{
long aux_1304;
{
ucs2_t ucs2_848;
{
obj_t aux_1305;
if(UCS2P(ucs2_517)){
aux_1305 = ucs2_517;
}
 else {
bigloo_type_error_location_103___error(symbol1513___ucs2, string1471___ucs2, ucs2_517, string1472___ucs2, BINT(((long)10406)));
exit( -1 );}
ucs2_848 = CUCS2(aux_1305);
}
{
obj_t symbol1180_849;
symbol1180_849 = symbol1512___ucs2;
{
PUSH_TRACE(symbol1180_849);
BUNSPEC;
{
long aux1179_850;
aux1179_850 = (long)(ucs2_848);
POP_TRACE();
aux_1304 = aux1179_850;
}
}
}
}
return BINT(aux_1304);
}
}


/* char->ucs2 */ucs2_t char__ucs2_17___ucs2(char char_31)
{
{
obj_t symbol1182_851;
symbol1182_851 = symbol1514___ucs2;
{
PUSH_TRACE(symbol1182_851);
BUNSPEC;
{
ucs2_t aux1181_852;
aux1181_852 = (ucs2_t)(char_31);
POP_TRACE();
return aux1181_852;
}
}
}
}


/* _char->ucs21206 */obj_t _char__ucs21206_158___ucs2(obj_t env_518, obj_t char_519)
{
{
ucs2_t aux_1319;
{
char char_166_853;
{
obj_t aux_1320;
if(CHARP(char_519)){
aux_1320 = char_519;
}
 else {
bigloo_type_error_location_103___error(symbol1515___ucs2, string1516___ucs2, char_519, string1472___ucs2, BINT(((long)10714)));
exit( -1 );}
char_166_853 = CCHAR(aux_1320);
}
{
obj_t symbol1182_854;
symbol1182_854 = symbol1514___ucs2;
{
PUSH_TRACE(symbol1182_854);
BUNSPEC;
{
ucs2_t aux1181_855;
aux1181_855 = (ucs2_t)(char_166_853);
POP_TRACE();
aux_1319 = aux1181_855;
}
}
}
}
return BUCS2(aux_1319);
}
}


/* ucs2->char */char ucs2__char_237___ucs2(ucs2_t ucs2_32)
{
{
obj_t symbol1184_464;
symbol1184_464 = symbol1517___ucs2;
{
PUSH_TRACE(symbol1184_464);
BUNSPEC;
{
char aux1183_465;
{
long int_256;
int_256 = (long)(ucs2_32);
if((int_256<((long)256))){
aux1183_465 = (char)(int_256);
}
 else {
obj_t aux_1336;
{
obj_t aux1454_714;
aux1454_714 = debug_error_location_199___error(string1518___ucs2, string1519___ucs2, BUCS2(ucs2_32), string1508___ucs2, BINT(((long)7610)));
if(CHARP(aux1454_714)){
aux_1336 = aux1454_714;
}
 else {
bigloo_type_error_location_103___error(symbol1517___ucs2, string1516___ucs2, aux1454_714, string1508___ucs2, BINT(((long)7610)));
exit( -1 );}
}
aux1183_465 = CCHAR(aux_1336);
}
}
POP_TRACE();
return aux1183_465;
}
}
}
}


/* _ucs2->char1207 */obj_t _ucs2__char1207_113___ucs2(obj_t env_520, obj_t ucs2_521)
{
{
char aux_1347;
{
ucs2_t aux_1348;
{
obj_t aux_1349;
if(UCS2P(ucs2_521)){
aux_1349 = ucs2_521;
}
 else {
bigloo_type_error_location_103___error(symbol1520___ucs2, string1471___ucs2, ucs2_521, string1472___ucs2, BINT(((long)11021)));
exit( -1 );}
aux_1348 = CUCS2(aux_1349);
}
aux_1347 = ucs2__char_237___ucs2(aux_1348);
}
return BCHAR(aux_1347);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___ucs2()
{
{
obj_t symbol1186_466;
symbol1186_466 = symbol1521___ucs2;
{
PUSH_TRACE(symbol1186_466);
BUNSPEC;
{
obj_t aux1185_467;
aux1185_467 = module_initialization_70___error(((long)0), "__UCS2");
POP_TRACE();
return aux1185_467;
}
}
}
}

