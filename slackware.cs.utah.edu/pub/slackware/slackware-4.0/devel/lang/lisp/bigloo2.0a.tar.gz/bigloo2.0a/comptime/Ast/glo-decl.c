/*===========================================================================*/
/*   (Ast/glo-decl.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern global_t declare_global_scnst__70_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t);
extern global_t declare_global_sfun__255_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_ast_glo_decl_237();
extern global_t bind_global__138_ast_env(obj_t, obj_t, value_t, obj_t, obj_t);
static obj_t _declare_global_sfun_1317_9_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _declare_global_cvar_1321_124_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t _obj__252_type_cache;
extern global_t declare_global_cvar__13_ast_glo_decl_237(obj_t, obj_t, obj_t, bool_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t cvar_ast_var;
extern obj_t args___args_list_50_tools_args(obj_t);
extern type_t type_of_id_183_ast_ident(obj_t);
extern obj_t dsssl_formals_encoding_15_tools_dsssl(obj_t);
extern obj_t module_initialization_70_ast_glo_decl_237(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
extern obj_t scnst_ast_var;
static obj_t _declare_global_cfun_1320_248_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_ast_glo_decl_237();
extern obj_t cfun_ast_var;
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
static obj_t library_modules_init_112_ast_glo_decl_237();
static obj_t _declare_global_scnst_1319_143_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern global_t declare_global_svar__200_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern int arity_tools_args(obj_t);
extern global_t declare_global_cfun__81_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern type_t use_foreign_type__12_type_env(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _declare_global_svar_1318_129_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_glo_decl_237 = BUNSPEC;
static obj_t cnst_init_137_ast_glo_decl_237();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[9];

DEFINE_EXPORT_PROCEDURE(declare_global_scnst__env_79_ast_glo_decl_237, _declare_global_scnst_1319_143_ast_glo_decl_2371330, _declare_global_scnst_1319_143_ast_glo_decl_237, 0L, 5);
DEFINE_EXPORT_PROCEDURE(declare_global_svar__env_68_ast_glo_decl_237, _declare_global_svar_1318_129_ast_glo_decl_2371331, _declare_global_svar_1318_129_ast_glo_decl_237, 0L, 4);
DEFINE_EXPORT_PROCEDURE(declare_global_sfun__env_194_ast_glo_decl_237, _declare_global_sfun_1317_9_ast_glo_decl_2371332, _declare_global_sfun_1317_9_ast_glo_decl_237, 0L, 6);
DEFINE_EXPORT_PROCEDURE(declare_global_cvar__env_34_ast_glo_decl_237, _declare_global_cvar_1321_124_ast_glo_decl_2371333, _declare_global_cvar_1321_124_ast_glo_decl_237, 0L, 5);
DEFINE_EXPORT_PROCEDURE(declare_global_cfun__env_226_ast_glo_decl_237, _declare_global_cfun_1320_248_ast_glo_decl_2371334, _declare_global_cfun_1320_248_ast_glo_decl_237, 0L, 7);
DEFINE_STRING(string1324_ast_glo_decl_237, string1324_ast_glo_decl_2371335, "FOREIGN A-CNST WRITE READ (EXPORT IMPORT) BIGLOO SGFUN EXPORT STATIC ", 69);
DEFINE_STRING(string1323_ast_glo_decl_237, string1323_ast_glo_decl_2371336, "Illegal type for global variable", 32);
DEFINE_STRING(string1322_ast_glo_decl_237, string1322_ast_glo_decl_2371337, "Illegal nary argument type", 26);


/* module-initialization */ obj_t 
module_initialization_70_ast_glo_decl_237(long checksum_836, char *from_837)
{
   if (CBOOL(require_initialization_114_ast_glo_decl_237))
     {
	require_initialization_114_ast_glo_decl_237 = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_glo_decl_237();
	cnst_init_137_ast_glo_decl_237();
	imported_modules_init_94_ast_glo_decl_237();
	method_init_76_ast_glo_decl_237();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_glo_decl_237()
{
   module_initialization_70___object(((long) 0), "AST_GLO-DECL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_GLO-DECL");
   module_initialization_70___reader(((long) 0), "AST_GLO-DECL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_glo_decl_237()
{
   {
      obj_t cnst_port_138_828;
      cnst_port_138_828 = open_input_string(string1324_ast_glo_decl_237);
      {
	 long i_829;
	 i_829 = ((long) 8);
       loop_830:
	 {
	    bool_t test1325_831;
	    test1325_831 = (i_829 == ((long) -1));
	    if (test1325_831)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1326_832;
		    {
		       obj_t list1327_833;
		       {
			  obj_t arg1328_834;
			  arg1328_834 = BNIL;
			  list1327_833 = MAKE_PAIR(cnst_port_138_828, arg1328_834);
		       }
		       arg1326_832 = read___reader(list1327_833);
		    }
		    CNST_TABLE_SET(i_829, arg1326_832);
		 }
		 {
		    int aux_835;
		    {
		       long aux_854;
		       aux_854 = (i_829 - ((long) 1));
		       aux_835 = (int) (aux_854);
		    }
		    {
		       long i_857;
		       i_857 = (long) (aux_835);
		       i_829 = i_857;
		       goto loop_830;
		    }
		 }
	      }
	 }
      }
   }
}


/* declare-global-sfun! */ global_t 
declare_global_sfun__255_ast_glo_decl_237(obj_t id_1, obj_t args_2, obj_t module_3, obj_t import_4, obj_t class_5, obj_t src_exp_176_6)
{
   {
      int arity_328;
      arity_328 = arity_tools_args(args_2);
      {
	 obj_t args_329;
	 args_329 = args___args_list_50_tools_args(args_2);
	 {
	    bool_t export__13_330;
	    {
	       bool_t _ortest_1182_376;
	       {
		  bool_t test_861;
		  {
		     obj_t aux_862;
		     aux_862 = CNST_TABLE_REF(((long) 0));
		     test_861 = (import_4 == aux_862);
		  }
		  if (test_861)
		    {
		       _ortest_1182_376 = ((bool_t) 0);
		    }
		  else
		    {
		       _ortest_1182_376 = ((bool_t) 1);
		    }
	       }
	       if (_ortest_1182_376)
		 {
		    export__13_330 = _ortest_1182_376;
		 }
	       else
		 {
		    long n1_578;
		    n1_578 = (long) CINT(_bdb_debug__1_engine_param);
		    export__13_330 = (n1_578 >= ((long) 2));
		 }
	    }
	    {
	       obj_t import_331;
	       {
		  bool_t test1226_373;
		  {
		     bool_t test_868;
		     {
			obj_t aux_869;
			aux_869 = CNST_TABLE_REF(((long) 0));
			test_868 = (import_4 == aux_869);
		     }
		     if (test_868)
		       {
			  long n1_582;
			  n1_582 = (long) CINT(_bdb_debug__1_engine_param);
			  test1226_373 = (n1_582 >= ((long) 2));
		       }
		     else
		       {
			  test1226_373 = ((bool_t) 0);
		       }
		  }
		  if (test1226_373)
		    {
		       import_331 = CNST_TABLE_REF(((long) 1));
		    }
		  else
		    {
		       import_331 = import_4;
		    }
	       }
	       {
		  obj_t keywords_332;
		  keywords_332 = BNIL;
		  {
		     obj_t args_type_205_333;
		     {
			obj_t args_345;
			obj_t res_346;
			bool_t sgfun__91_347;
			args_345 = args_329;
			res_346 = BNIL;
			{
			   obj_t aux_917;
			   aux_917 = CNST_TABLE_REF(((long) 2));
			   sgfun__91_347 = (class_5 == aux_917);
			}
		      loop_348:
			if (NULLP(args_345))
			  {
			     {
				bool_t test_878;
				{
				   long aux_879;
				   aux_879 = (long) (arity_328);
				   test_878 = (aux_879 >= ((long) 0));
				}
				if (test_878)
				  {
				     args_type_205_333 = reverse__39___r4_pairs_and_lists_6_3(res_346);
				  }
				else
				  {
				     obj_t type_354;
				     type_354 = CAR(res_346);
				     {
					bool_t test1207_355;
					{
					   obj_t obj2_591;
					   obj2_591 = _obj__252_type_cache;
					   test1207_355 = (type_354 == obj2_591);
					}
					if (test1207_355)
					  {
					     args_type_205_333 = reverse__39___r4_pairs_and_lists_6_3(res_346);
					  }
					else
					  {
					     bool_t test1208_356;
					     {
						obj_t obj2_593;
						obj2_593 = ____74_type_cache;
						test1208_356 = (type_354 == obj2_593);
					     }
					     if (test1208_356)
					       {
						  {
						     obj_t arg1209_357;
						     {
							obj_t obj1_595;
							obj1_595 = _obj__252_type_cache;
							{
							   obj_t aux_889;
							   aux_889 = CDR(res_346);
							   arg1209_357 = MAKE_PAIR(obj1_595, aux_889);
							}
						     }
						     args_type_205_333 = reverse__39___r4_pairs_and_lists_6_3(arg1209_357);
						  }
					       }
					     else
					       {
						  {
						     obj_t arg1213_360;
						     arg1213_360 = shape_tools_shape(type_354);
						     args_type_205_333 = user_error_151_tools_error(id_1, string1322_ast_glo_decl_237, arg1213_360, BNIL);
						  }
					       }
					  }
				     }
				  }
			     }
			  }
			else
			  {
			     bool_t test1215_362;
			     {
				obj_t aux_895;
				aux_895 = dsssl_named_constant__188_tools_dsssl(CAR(args_345));
				test1215_362 = CBOOL(aux_895);
			     }
			     if (test1215_362)
			       {
				  keywords_332 = dsssl_formals_encoding_15_tools_dsssl(args_345);
				  {
				     obj_t arg1216_363;
				     {
					obj_t obj1_598;
					obj1_598 = _obj__252_type_cache;
					arg1216_363 = MAKE_PAIR(obj1_598, res_346);
				     }
				     args_type_205_333 = reverse__39___r4_pairs_and_lists_6_3(arg1216_363);
				  }
			       }
			     else
			       {
				  {
				     obj_t type_364;
				     {
					type_t t_367;
					t_367 = type_of_id_183_ast_ident(CAR(args_345));
					{
					   bool_t test1221_368;
					   {
					      bool_t test1222_369;
					      {
						 obj_t obj2_602;
						 obj2_602 = ____74_type_cache;
						 {
						    obj_t aux_905;
						    aux_905 = (obj_t) (t_367);
						    test1222_369 = (aux_905 == obj2_602);
						 }
					      }
					      if (test1222_369)
						{
						   if (export__13_330)
						     {
							test1221_368 = export__13_330;
						     }
						   else
						     {
							test1221_368 = sgfun__91_347;
						     }
						}
					      else
						{
						   test1221_368 = ((bool_t) 0);
						}
					   }
					   if (test1221_368)
					     {
						type_364 = _obj__252_type_cache;
					     }
					   else
					     {
						type_364 = (obj_t) (t_367);
					     }
					}
				     }
				     {
					obj_t arg1219_365;
					obj_t arg1220_366;
					arg1219_365 = CDR(args_345);
					arg1220_366 = MAKE_PAIR(type_364, res_346);
					{
					   bool_t sgfun__91_916;
					   obj_t res_915;
					   obj_t args_914;
					   args_914 = arg1219_365;
					   res_915 = arg1220_366;
					   sgfun__91_916 = ((bool_t) 0);
					   sgfun__91_347 = sgfun__91_916;
					   res_346 = res_915;
					   args_345 = args_914;
					   goto loop_348;
					}
				     }
				  }
			       }
			  }
		     }
		     {
			obj_t id_type_89_334;
			id_type_89_334 = parse_id_241_ast_ident(id_1);
			{
			   obj_t type_res_48_335;
			   type_res_48_335 = CDR(id_type_89_334);
			   {
			      obj_t id_336;
			      id_336 = CAR(id_type_89_334);
			      {
				 sfun_t sfun_337;
				 {
				    obj_t arg1201_344;
				    arg1201_344 = keywords_332;
				    {
				       sfun_t res1312_636;
				       {
					  long arity_608;
					  obj_t predicate_of_78_610;
					  obj_t stack_allocator_172_611;
					  arity_608 = (long) (arity_328);
					  predicate_of_78_610 = BFALSE;
					  stack_allocator_172_611 = BFALSE;
					  {
					     sfun_t new1114_620;
					     new1114_620 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
					     {
						long arg1297_621;
						arg1297_621 = class_num_218___object(sfun_ast_var);
						{
						   obj_t obj_634;
						   obj_634 = (obj_t) (new1114_620);
						   (((obj_t) CREF(obj_634))->header = MAKE_HEADER(arg1297_621, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_928;
						aux_928 = (object_t) (new1114_620);
						OBJECT_WIDENING_SET(aux_928, predicate_of_78_610);
					     }
					     ((((sfun_t) CREF(new1114_620))->arity) = ((long) arity_608), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->predicate_of_78) = ((obj_t) predicate_of_78_610), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->stack_allocator_172) = ((obj_t) stack_allocator_172_611), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->top__138) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->the_closure_238) = ((obj_t) BUNSPEC), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->property) = ((obj_t) BNIL), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->args) = ((obj_t) args_type_205_333), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->body) = ((obj_t) BUNSPEC), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->class) = ((obj_t) class_5), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->dsssl_keywords_243) = ((obj_t) arg1201_344), BUNSPEC);
					     ((((sfun_t) CREF(new1114_620))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
					     res1312_636 = new1114_620;
					  }
				       }
				       sfun_337 = res1312_636;
				    }
				 }
				 {
				    global_t global_338;
				    global_338 = bind_global__138_ast_env(id_336, module_3, (value_t) (sfun_337), import_331, src_exp_176_6);
				    {
				       {
					  bool_t test1195_339;
					  {
					     obj_t obj2_638;
					     obj2_638 = ____74_type_cache;
					     test1195_339 = (type_res_48_335 == obj2_638);
					  }
					  if (test1195_339)
					    {
					       if (export__13_330)
						 {
						    {
						       type_t val1067_640;
						       val1067_640 = (type_t) (_obj__252_type_cache);
						       ((((global_t) CREF(global_338))->type) = ((type_t) val1067_640), BUNSPEC);
						    }
						 }
					       else
						 {
						    {
						       type_t val1067_642;
						       val1067_642 = (type_t) (type_res_48_335);
						       ((((global_t) CREF(global_338))->type) = ((type_t) val1067_642), BUNSPEC);
						    }
						 }
					    }
					  else
					    {
					       {
						  type_t val1067_644;
						  val1067_644 = (type_t) (type_res_48_335);
						  ((((global_t) CREF(global_338))->type) = ((type_t) val1067_644), BUNSPEC);
					       }
					    }
				       }
				       return global_338;
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _declare-global-sfun!1317 */ obj_t 
_declare_global_sfun_1317_9_ast_glo_decl_237(obj_t env_796, obj_t id_797, obj_t args_798, obj_t module_799, obj_t import_800, obj_t class_801, obj_t src_exp_176_802)
{
   {
      global_t aux_954;
      aux_954 = declare_global_sfun__255_ast_glo_decl_237(id_797, args_798, module_799, import_800, class_801, src_exp_176_802);
      return (obj_t) (aux_954);
   }
}


/* declare-global-svar! */ global_t 
declare_global_svar__200_ast_glo_decl_237(obj_t id_7, obj_t module_8, obj_t import_9, obj_t src_exp_176_10)
{
   {
      obj_t id_type_89_379;
      id_type_89_379 = parse_id_241_ast_ident(id_7);
      {
	 obj_t type_380;
	 {
	    obj_t type_391;
	    type_391 = CDR(id_type_89_379);
	    {
	       bool_t test_959;
	       {
		  obj_t aux_963;
		  obj_t aux_960;
		  aux_963 = CNST_TABLE_REF(((long) 3));
		  {
		     type_t obj_646;
		     obj_646 = (type_t) (type_391);
		     aux_960 = (((type_t) CREF(obj_646))->class);
		  }
		  test_959 = (aux_960 == aux_963);
	       }
	       if (test_959)
		 {
		    bool_t test1240_393;
		    {
		       bool_t test1241_394;
		       {
			  obj_t obj2_650;
			  obj2_650 = ____74_type_cache;
			  test1241_394 = (type_391 == obj2_650);
		       }
		       if (test1241_394)
			 {
			    obj_t _ortest_1185_395;
			    _ortest_1185_395 = memq___r4_pairs_and_lists_6_3(import_9, CNST_TABLE_REF(((long) 4)));
			    if (CBOOL(_ortest_1185_395))
			      {
				 test1240_393 = CBOOL(_ortest_1185_395);
			      }
			    else
			      {
				 long n1_651;
				 n1_651 = (long) CINT(_bdb_debug__1_engine_param);
				 test1240_393 = (n1_651 > ((long) 0));
			      }
			 }
		       else
			 {
			    test1240_393 = ((bool_t) 0);
			 }
		    }
		    if (test1240_393)
		      {
			 type_380 = _obj__252_type_cache;
		      }
		    else
		      {
			 type_380 = type_391;
		      }
		 }
	       else
		 {
		    {
		       obj_t arg1245_398;
		       arg1245_398 = shape_tools_shape(type_391);
		       {
			  obj_t list1246_399;
			  list1246_399 = MAKE_PAIR(____74_type_cache, BNIL);
			  type_380 = user_error_151_tools_error(id_7, string1323_ast_glo_decl_237, arg1245_398, list1246_399);
		       }
		    }
		 }
	    }
	 }
	 {
	    obj_t import_381;
	    {
	       bool_t test1235_388;
	       {
		  bool_t test_979;
		  {
		     obj_t aux_980;
		     aux_980 = CNST_TABLE_REF(((long) 0));
		     test_979 = (import_9 == aux_980);
		  }
		  if (test_979)
		    {
		       long n1_655;
		       n1_655 = (long) CINT(_bdb_debug__1_engine_param);
		       test1235_388 = (n1_655 >= ((long) 2));
		    }
		  else
		    {
		       test1235_388 = ((bool_t) 0);
		    }
	       }
	       if (test1235_388)
		 {
		    import_381 = CNST_TABLE_REF(((long) 1));
		 }
	       else
		 {
		    import_381 = import_9;
		 }
	    }
	    {
	       obj_t id_382;
	       id_382 = CAR(id_type_89_379);
	       {
		  svar_t svar_383;
		  {
		     svar_t res1313_664;
		     {
			svar_t new1158_659;
			new1158_659 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
			{
			   long arg1292_660;
			   arg1292_660 = class_num_218___object(svar_ast_var);
			   {
			      obj_t obj_662;
			      obj_662 = (obj_t) (new1158_659);
			      (((obj_t) CREF(obj_662))->header = MAKE_HEADER(arg1292_660, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_992;
			   aux_992 = (object_t) (new1158_659);
			   OBJECT_WIDENING_SET(aux_992, BFALSE);
			}
			((((svar_t) CREF(new1158_659))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
			res1313_664 = new1158_659;
		     }
		     svar_383 = res1313_664;
		  }
		  {
		     global_t global_384;
		     global_384 = bind_global__138_ast_env(id_382, module_8, (value_t) (svar_383), import_381, src_exp_176_10);
		     {
			{
			   type_t val1067_666;
			   val1067_666 = (type_t) (type_380);
			   ((((global_t) CREF(global_384))->type) = ((type_t) val1067_666), BUNSPEC);
			}
			{
			   obj_t arg1232_385;
			   {
			      bool_t test_1000;
			      {
				 obj_t aux_1001;
				 aux_1001 = CNST_TABLE_REF(((long) 0));
				 test_1000 = (import_381 == aux_1001);
			      }
			      if (test_1000)
				{
				   arg1232_385 = CNST_TABLE_REF(((long) 5));
				}
			      else
				{
				   arg1232_385 = CNST_TABLE_REF(((long) 6));
				}
			   }
			   ((((global_t) CREF(global_384))->access) = ((obj_t) arg1232_385), BUNSPEC);
			}
			return global_384;
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _declare-global-svar!1318 */ obj_t 
_declare_global_svar_1318_129_ast_glo_decl_237(obj_t env_803, obj_t id_804, obj_t module_805, obj_t import_806, obj_t src_exp_176_807)
{
   {
      global_t aux_1007;
      aux_1007 = declare_global_svar__200_ast_glo_decl_237(id_804, module_805, import_806, src_exp_176_807);
      return (obj_t) (aux_1007);
   }
}


/* declare-global-scnst! */ global_t 
declare_global_scnst__70_ast_glo_decl_237(obj_t id_11, obj_t module_12, obj_t import_13, obj_t node_14, obj_t class_15)
{
   {
      obj_t id_type_89_403;
      id_type_89_403 = parse_id_241_ast_ident(id_11);
      {
	 obj_t type_404;
	 {
	    obj_t type_412;
	    type_412 = CDR(id_type_89_403);
	    {
	       bool_t test1255_413;
	       {
		  obj_t obj2_673;
		  obj2_673 = ____74_type_cache;
		  test1255_413 = (type_412 == obj2_673);
	       }
	       if (test1255_413)
		 {
		    {
		       obj_t arg1257_415;
		       arg1257_415 = shape_tools_shape(type_412);
		       type_404 = internal_error_43_tools_error(id_11, string1323_ast_glo_decl_237, arg1257_415);
		    }
		 }
	       else
		 {
		    type_404 = type_412;
		 }
	    }
	 }
	 {
	    obj_t id_405;
	    id_405 = CAR(id_type_89_403);
	    {
	       scnst_t scnst_406;
	       {
		  scnst_t res1314_685;
		  {
		     scnst_t new1163_678;
		     new1163_678 = ((scnst_t) BREF(GC_MALLOC(sizeof(struct scnst))));
		     {
			long arg1290_679;
			arg1290_679 = class_num_218___object(scnst_ast_var);
			{
			   obj_t obj_683;
			   obj_683 = (obj_t) (new1163_678);
			   (((obj_t) CREF(obj_683))->header = MAKE_HEADER(arg1290_679, 0), BUNSPEC);
			}
		     }
		     {
			object_t aux_1021;
			aux_1021 = (object_t) (new1163_678);
			OBJECT_WIDENING_SET(aux_1021, BFALSE);
		     }
		     ((((scnst_t) CREF(new1163_678))->node) = ((obj_t) node_14), BUNSPEC);
		     ((((scnst_t) CREF(new1163_678))->class) = ((obj_t) class_15), BUNSPEC);
		     ((((scnst_t) CREF(new1163_678))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
		     res1314_685 = new1163_678;
		  }
		  scnst_406 = res1314_685;
	       }
	       {
		  global_t global_407;
		  global_407 = bind_global__138_ast_env(id_405, module_12, (value_t) (scnst_406), import_13, CNST_TABLE_REF(((long) 7)));
		  {
		     {
			type_t val1067_687;
			val1067_687 = (type_t) (type_404);
			((((global_t) CREF(global_407))->type) = ((type_t) val1067_687), BUNSPEC);
		     }
		     {
			obj_t arg1251_408;
			arg1251_408 = CNST_TABLE_REF(((long) 5));
			((((global_t) CREF(global_407))->access) = ((obj_t) arg1251_408), BUNSPEC);
		     }
		     return global_407;
		  }
	       }
	    }
	 }
      }
   }
}


/* _declare-global-scnst!1319 */ obj_t 
_declare_global_scnst_1319_143_ast_glo_decl_237(obj_t env_808, obj_t id_809, obj_t module_810, obj_t import_811, obj_t node_812, obj_t class_813)
{
   {
      global_t aux_1034;
      aux_1034 = declare_global_scnst__70_ast_glo_decl_237(id_809, module_810, import_811, node_812, class_813);
      return (obj_t) (aux_1034);
   }
}


/* declare-global-cfun! */ global_t 
declare_global_cfun__81_ast_glo_decl_237(obj_t id_16, obj_t name_17, obj_t tres_id_18_18, obj_t targs_id_78_19, bool_t infix__163_20, bool_t macro__33_21, obj_t src_exp_176_22)
{
   {
      int arity_416;
      arity_416 = arity_tools_args(targs_id_78_19);
      {
	 type_t type_res_48_417;
	 type_res_48_417 = use_foreign_type__12_type_env(tres_id_18_18);
	 {
	    obj_t type_args_244_418;
	    {
	       obj_t l1188_427;
	       l1188_427 = args___args_list_50_tools_args(targs_id_78_19);
	       if (NULLP(l1188_427))
		 {
		    type_args_244_418 = BNIL;
		 }
	       else
		 {
		    obj_t head1190_429;
		    {
		       type_t arg1274_440;
		       arg1274_440 = use_foreign_type__12_type_env(CAR(l1188_427));
		       {
			  obj_t aux_1044;
			  aux_1044 = (obj_t) (arg1274_440);
			  head1190_429 = MAKE_PAIR(aux_1044, BNIL);
		       }
		    }
		    {
		       obj_t l1188_430;
		       obj_t tail1191_431;
		       l1188_430 = CDR(l1188_427);
		       tail1191_431 = head1190_429;
		     lname1189_432:
		       if (NULLP(l1188_430))
			 {
			    type_args_244_418 = head1190_429;
			 }
		       else
			 {
			    obj_t newtail1192_435;
			    {
			       type_t arg1270_437;
			       arg1270_437 = use_foreign_type__12_type_env(CAR(l1188_430));
			       {
				  obj_t aux_1051;
				  aux_1051 = (obj_t) (arg1270_437);
				  newtail1192_435 = MAKE_PAIR(aux_1051, BNIL);
			       }
			    }
			    SET_CDR(tail1191_431, newtail1192_435);
			    {
			       obj_t tail1191_1057;
			       obj_t l1188_1055;
			       l1188_1055 = CDR(l1188_430);
			       tail1191_1057 = newtail1192_435;
			       tail1191_431 = tail1191_1057;
			       l1188_430 = l1188_1055;
			       goto lname1189_432;
			    }
			 }
		    }
		 }
	    }
	    {
	       cfun_t cfun_419;
	       {
		  cfun_t res1315_724;
		  {
		     long arity_702;
		     obj_t predicate_of_78_704;
		     obj_t stack_allocator_172_705;
		     arity_702 = (long) (arity_416);
		     predicate_of_78_704 = BFALSE;
		     stack_allocator_172_705 = BFALSE;
		     {
			cfun_t new1140_711;
			new1140_711 = ((cfun_t) BREF(GC_MALLOC(sizeof(struct cfun))));
			{
			   long arg1295_712;
			   arg1295_712 = class_num_218___object(cfun_ast_var);
			   {
			      obj_t obj_722;
			      obj_722 = (obj_t) (new1140_711);
			      (((obj_t) CREF(obj_722))->header = MAKE_HEADER(arg1295_712, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_1064;
			   aux_1064 = (object_t) (new1140_711);
			   OBJECT_WIDENING_SET(aux_1064, predicate_of_78_704);
			}
			((((cfun_t) CREF(new1140_711))->arity) = ((long) arity_702), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->predicate_of_78) = ((obj_t) predicate_of_78_704), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->stack_allocator_172) = ((obj_t) stack_allocator_172_705), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->top__138) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->the_closure_238) = ((obj_t) BUNSPEC), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->args_type_205) = ((obj_t) type_args_244_418), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->macro__33) = ((bool_t) macro__33_21), BUNSPEC);
			((((cfun_t) CREF(new1140_711))->infix__163) = ((bool_t) infix__163_20), BUNSPEC);
			res1315_724 = new1140_711;
		     }
		  }
		  cfun_419 = res1315_724;
	       }
	       {
		  global_t global_420;
		  global_420 = bind_global__138_ast_env(id_16, CNST_TABLE_REF(((long) 8)), (value_t) (cfun_419), CNST_TABLE_REF(((long) 8)), src_exp_176_22);
		  {
		     ((((global_t) CREF(global_420))->name) = ((obj_t) name_17), BUNSPEC);
		     ((((global_t) CREF(global_420))->type) = ((type_t) type_res_48_417), BUNSPEC);
		     ((((global_t) CREF(global_420))->evaluable__248) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		     return global_420;
		  }
	       }
	    }
	 }
      }
   }
}


/* _declare-global-cfun!1320 */ obj_t 
_declare_global_cfun_1320_248_ast_glo_decl_237(obj_t env_814, obj_t id_815, obj_t name_816, obj_t tres_id_18_817, obj_t targs_id_78_818, obj_t infix__163_819, obj_t macro__33_820, obj_t src_exp_176_821)
{
   {
      global_t aux_1083;
      aux_1083 = declare_global_cfun__81_ast_glo_decl_237(id_815, name_816, tres_id_18_817, targs_id_78_818, CBOOL(infix__163_819), CBOOL(macro__33_820), src_exp_176_821);
      return (obj_t) (aux_1083);
   }
}


/* declare-global-cvar! */ global_t 
declare_global_cvar__13_ast_glo_decl_237(obj_t id_23, obj_t name_24, obj_t type_id_229_25, bool_t macro__33_26, obj_t src_exp_176_27)
{
   {
      type_t type_731;
      type_731 = use_foreign_type__12_type_env(type_id_229_25);
      {
	 cvar_t cvar_732;
	 {
	    cvar_t res1316_743;
	    {
	       cvar_t new1171_738;
	       new1171_738 = ((cvar_t) BREF(GC_MALLOC(sizeof(struct cvar))));
	       {
		  long arg1287_739;
		  arg1287_739 = class_num_218___object(cvar_ast_var);
		  {
		     obj_t obj_741;
		     obj_741 = (obj_t) (new1171_738);
		     (((obj_t) CREF(obj_741))->header = MAKE_HEADER(arg1287_739, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_1093;
		  aux_1093 = (object_t) (new1171_738);
		  OBJECT_WIDENING_SET(aux_1093, BFALSE);
	       }
	       ((((cvar_t) CREF(new1171_738))->macro__33) = ((bool_t) macro__33_26), BUNSPEC);
	       res1316_743 = new1171_738;
	    }
	    cvar_732 = res1316_743;
	 }
	 {
	    global_t global_734;
	    global_734 = bind_global__138_ast_env(id_23, CNST_TABLE_REF(((long) 8)), (value_t) (cvar_732), CNST_TABLE_REF(((long) 8)), src_exp_176_27);
	    {
	       ((((global_t) CREF(global_734))->name) = ((obj_t) name_24), BUNSPEC);
	       ((((global_t) CREF(global_734))->type) = ((type_t) type_731), BUNSPEC);
	       ((((global_t) CREF(global_734))->evaluable__248) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	       return global_734;
	    }
	 }
      }
   }
}


/* _declare-global-cvar!1321 */ obj_t 
_declare_global_cvar_1321_124_ast_glo_decl_237(obj_t env_822, obj_t id_823, obj_t name_824, obj_t type_id_229_825, obj_t macro__33_826, obj_t src_exp_176_827)
{
   {
      global_t aux_1104;
      aux_1104 = declare_global_cvar__13_ast_glo_decl_237(id_823, name_824, type_id_229_825, CBOOL(macro__33_826), src_exp_176_827);
      return (obj_t) (aux_1104);
   }
}


/* method-init */ obj_t 
method_init_76_ast_glo_decl_237()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_glo_decl_237()
{
   module_initialization_70_tools_trace(((long) 0), "AST_GLO-DECL");
   module_initialization_70_tools_error(((long) 0), "AST_GLO-DECL");
   module_initialization_70_tools_args(((long) 0), "AST_GLO-DECL");
   module_initialization_70_tools_shape(((long) 0), "AST_GLO-DECL");
   module_initialization_70_tools_dsssl(((long) 0), "AST_GLO-DECL");
   module_initialization_70_engine_param(((long) 0), "AST_GLO-DECL");
   module_initialization_70_type_type(((long) 0), "AST_GLO-DECL");
   module_initialization_70_type_cache(((long) 0), "AST_GLO-DECL");
   module_initialization_70_ast_var(((long) 0), "AST_GLO-DECL");
   module_initialization_70_ast_env(((long) 0), "AST_GLO-DECL");
   module_initialization_70_ast_ident(((long) 0), "AST_GLO-DECL");
   return module_initialization_70_type_env(((long) 0), "AST_GLO-DECL");
}
