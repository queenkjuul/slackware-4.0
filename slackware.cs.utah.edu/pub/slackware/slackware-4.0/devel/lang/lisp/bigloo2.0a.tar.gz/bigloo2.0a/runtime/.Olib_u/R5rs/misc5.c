/*===========================================================================*/
/*   (R5rs/misc5.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _filter1___r5_syntax_misc(obj_t, obj_t, obj_t);
static obj_t _union2___r5_syntax_misc(obj_t, obj_t, obj_t);
static obj_t _make_null_terminated_105___r5_syntax_misc(obj_t, obj_t);
static obj_t _every1__180___r5_syntax_misc(obj_t, obj_t, obj_t);
extern obj_t m_quit_227___r5_syntax_expand;
static obj_t _m_bug_244___r5_syntax_misc(obj_t, obj_t, obj_t);
extern obj_t filter1___r5_syntax_misc(obj_t, obj_t);
extern obj_t m_bug_88___r5_syntax_misc(obj_t, obj_t);
extern obj_t warning___error(obj_t);
extern obj_t every1__242___r5_syntax_misc(obj_t, obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _m_error_137___r5_syntax_misc(obj_t, obj_t, obj_t);
static obj_t _safe_length_243___r5_syntax_misc(obj_t, obj_t);
extern obj_t module_initialization_70___r5_syntax_misc(long, char *);
static obj_t _copy_alist_44___r5_syntax_misc(obj_t, obj_t);
extern obj_t safe_length_235___r5_syntax_misc(obj_t);
extern obj_t make_null_terminated_173___r5_syntax_misc(obj_t);
extern obj_t m_error_176___r5_syntax_misc(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t m_warn_132___r5_syntax_misc(obj_t, obj_t);
extern obj_t union2___r5_syntax_misc(obj_t, obj_t);
static obj_t require_initialization_114___r5_syntax_misc = BUNSPEC;
extern obj_t copy_alist_141___r5_syntax_misc(obj_t);
static obj_t _m_warn_212___r5_syntax_misc(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( safe_length_env_201___r5_syntax_misc, _safe_length_243___r5_syntax_misc1190, _safe_length_243___r5_syntax_misc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( m_error_env_239___r5_syntax_misc, _m_error_137___r5_syntax_misc1191, va_generic_entry, _m_error_137___r5_syntax_misc, -2 );
DEFINE_EXPORT_PROCEDURE( filter1_env_14___r5_syntax_misc, _filter1___r5_syntax_misc1192, _filter1___r5_syntax_misc, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( every1__env_200___r5_syntax_misc, _every1__180___r5_syntax_misc1193, _every1__180___r5_syntax_misc, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( make_null_terminated_env_56___r5_syntax_misc, _make_null_terminated_105___r5_syntax_misc1194, _make_null_terminated_105___r5_syntax_misc, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( m_warn_env_104___r5_syntax_misc, _m_warn_212___r5_syntax_misc1195, va_generic_entry, _m_warn_212___r5_syntax_misc, -2 );
DEFINE_EXPORT_PROCEDURE( union2_env_60___r5_syntax_misc, _union2___r5_syntax_misc1196, _union2___r5_syntax_misc, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( m_bug_env_168___r5_syntax_misc, _m_bug_244___r5_syntax_misc1197, va_generic_entry, _m_bug_244___r5_syntax_misc, -2 );
DEFINE_STRING( string1188___r5_syntax_misc, string1188___r5_syntax_misc1198, "expand-syntax: internal-error", 29 );
DEFINE_STRING( string1187___r5_syntax_misc, string1187___r5_syntax_misc1199, "expand-syntax", 13 );
DEFINE_STRING( string1186___r5_syntax_misc, string1186___r5_syntax_misc1200, " -- ", 4 );
DEFINE_EXPORT_PROCEDURE( copy_alist_env_232___r5_syntax_misc, _copy_alist_44___r5_syntax_misc1201, _copy_alist_44___r5_syntax_misc, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r5_syntax_misc(long checksum_638, char * from_639)
{
if(CBOOL(require_initialization_114___r5_syntax_misc)){
require_initialization_114___r5_syntax_misc = BBOOL(((bool_t)0));
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* m-warn */obj_t m_warn_132___r5_syntax_misc(obj_t msg_1, obj_t more_2)
{
{
obj_t runner1012_516;
{
obj_t arg1011_517;
arg1011_517 = MAKE_PAIR(string1186___r5_syntax_misc, more_2);
runner1012_516 = MAKE_PAIR(msg_1, arg1011_517);
}
return warning___error(runner1012_516);
}
}


/* _m-warn */obj_t _m_warn_212___r5_syntax_misc(obj_t env_614, obj_t msg_615, obj_t more_616)
{
return m_warn_132___r5_syntax_misc(msg_615, more_616);
}


/* m-error */obj_t m_error_176___r5_syntax_misc(obj_t msg_3, obj_t more_4)
{
FAILURE(string1187___r5_syntax_misc,msg_3,more_4);}


/* _m-error */obj_t _m_error_137___r5_syntax_misc(obj_t env_617, obj_t msg_618, obj_t more_619)
{
return m_error_176___r5_syntax_misc(msg_618, more_619);
}


/* m-bug */obj_t m_bug_88___r5_syntax_misc(obj_t msg_5, obj_t more_6)
{
FAILURE(string1188___r5_syntax_misc,msg_5,more_6);}


/* _m-bug */obj_t _m_bug_244___r5_syntax_misc(obj_t env_620, obj_t msg_621, obj_t more_622)
{
return m_bug_88___r5_syntax_misc(msg_621, more_622);
}


/* make-null-terminated */obj_t make_null_terminated_173___r5_syntax_misc(obj_t x_7)
{
if(NULLP(x_7)){
return BNIL;
}
 else {
if(PAIRP(x_7)){
{
obj_t arg1015_329;
obj_t arg1016_330;
arg1015_329 = CAR(x_7);
arg1016_330 = make_null_terminated_173___r5_syntax_misc(CDR(x_7));
return MAKE_PAIR(arg1015_329, arg1016_330);
}
}
 else {
{
obj_t list1018_332;
list1018_332 = MAKE_PAIR(x_7, BNIL);
return list1018_332;
}
}
}
}


/* _make-null-terminated */obj_t _make_null_terminated_105___r5_syntax_misc(obj_t env_623, obj_t x_624)
{
return make_null_terminated_173___r5_syntax_misc(x_624);
}


/* safe-length */obj_t safe_length_235___r5_syntax_misc(obj_t x_8)
{
{
obj_t x_536;
obj_t n_537;
x_536 = x_8;
n_537 = BINT(((long)0));
loop_535:
if(NULLP(x_536)){
return n_537;
}
 else {
if(PAIRP(x_536)){
{
obj_t n_671;
obj_t x_669;
x_669 = CDR(x_536);
n_671 = _2__168___r4_numbers_6_5(n_537, BINT(((long)1)));
n_537 = n_671;
x_536 = x_669;
goto loop_535;
}
}
 else {
return BINT(((long)-1));
}
}
}
}


/* _safe-length */obj_t _safe_length_243___r5_syntax_misc(obj_t env_625, obj_t x_626)
{
return safe_length_235___r5_syntax_misc(x_626);
}


/* filter1 */obj_t filter1___r5_syntax_misc(obj_t p_9, obj_t x_10)
{
filter1___r5_syntax_misc:
if(NULLP(x_10)){
return BNIL;
}
 else {
bool_t test1027_344;
{
obj_t aux_679;
aux_679 = PROCEDURE_ENTRY(p_9)(p_9, CAR(x_10), BEOA);
test1027_344 = CBOOL(aux_679);
}
if(test1027_344){
{
obj_t arg1028_345;
obj_t arg1029_346;
arg1028_345 = CAR(x_10);
arg1029_346 = filter1___r5_syntax_misc(p_9, CDR(x_10));
return MAKE_PAIR(arg1028_345, arg1029_346);
}
}
 else {
{
obj_t x_689;
x_689 = CDR(x_10);
x_10 = x_689;
goto filter1___r5_syntax_misc;
}
}
}
}


/* _filter1 */obj_t _filter1___r5_syntax_misc(obj_t env_627, obj_t p_628, obj_t x_629)
{
return filter1___r5_syntax_misc(p_628, x_629);
}


/* every1? */obj_t every1__242___r5_syntax_misc(obj_t p_11, obj_t x_12)
{
every1__242___r5_syntax_misc:
if(NULLP(x_12)){
return BTRUE;
}
 else {
bool_t test1034_573;
{
obj_t aux_694;
aux_694 = PROCEDURE_ENTRY(p_11)(p_11, CAR(x_12), BEOA);
test1034_573 = CBOOL(aux_694);
}
if(test1034_573){
{
obj_t arg1035_575;
arg1035_575 = CDR(x_12);
if(NULLP(arg1035_575)){
return BTRUE;
}
 else {
bool_t test1034_582;
{
obj_t aux_703;
aux_703 = PROCEDURE_ENTRY(p_11)(p_11, CAR(arg1035_575), BEOA);
test1034_582 = CBOOL(aux_703);
}
if(test1034_582){
{
obj_t x_709;
x_709 = CDR(arg1035_575);
x_12 = x_709;
goto every1__242___r5_syntax_misc;
}
}
 else {
return BFALSE;
}
}
}
}
 else {
return BFALSE;
}
}
}


/* _every1? */obj_t _every1__180___r5_syntax_misc(obj_t env_630, obj_t p_631, obj_t x_632)
{
return every1__242___r5_syntax_misc(p_631, x_632);
}


/* union2 */obj_t union2___r5_syntax_misc(obj_t x_13, obj_t y_14)
{
union2___r5_syntax_misc:
if(NULLP(x_13)){
return y_14;
}
 else {
bool_t test_714;
{
obj_t aux_715;
aux_715 = member___r4_pairs_and_lists_6_3(CAR(x_13), y_14);
test_714 = CBOOL(aux_715);
}
if(test_714){
{
obj_t x_719;
x_719 = CDR(x_13);
x_13 = x_719;
goto union2___r5_syntax_misc;
}
}
 else {
{
obj_t arg1041_357;
obj_t arg1042_358;
arg1041_357 = CDR(x_13);
{
obj_t aux_722;
aux_722 = CAR(x_13);
arg1042_358 = MAKE_PAIR(aux_722, y_14);
}
{
obj_t y_726;
obj_t x_725;
x_725 = arg1041_357;
y_726 = arg1042_358;
y_14 = y_726;
x_13 = x_725;
goto union2___r5_syntax_misc;
}
}
}
}
}


/* _union2 */obj_t _union2___r5_syntax_misc(obj_t env_633, obj_t x_634, obj_t y_635)
{
return union2___r5_syntax_misc(x_634, y_635);
}


/* copy-alist */obj_t copy_alist_141___r5_syntax_misc(obj_t alist_15)
{
if(NULLP(alist_15)){
return BNIL;
}
 else {
obj_t head1004_363;
head1004_363 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_364;
obj_t tail1005_365;
l1002_364 = alist_15;
tail1005_365 = head1004_363;
lname1003_366:
if(NULLP(l1002_364)){
return CDR(head1004_363);
}
 else {
obj_t newtail1006_368;
{
obj_t arg1048_370;
{
obj_t x_372;
x_372 = CAR(l1002_364);
{
obj_t aux_737;
obj_t aux_735;
aux_737 = CDR(x_372);
aux_735 = CAR(x_372);
arg1048_370 = MAKE_PAIR(aux_735, aux_737);
}
}
newtail1006_368 = MAKE_PAIR(arg1048_370, BNIL);
}
SET_CDR(tail1005_365, newtail1006_368);
{
obj_t tail1005_744;
obj_t l1002_742;
l1002_742 = CDR(l1002_364);
tail1005_744 = newtail1006_368;
tail1005_365 = tail1005_744;
l1002_364 = l1002_742;
goto lname1003_366;
}
}
}
}
}


/* _copy-alist */obj_t _copy_alist_44___r5_syntax_misc(obj_t env_636, obj_t alist_637)
{
return copy_alist_141___r5_syntax_misc(alist_637);
}

