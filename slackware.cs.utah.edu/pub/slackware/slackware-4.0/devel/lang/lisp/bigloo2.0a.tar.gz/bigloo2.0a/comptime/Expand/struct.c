/*===========================================================================*/
/*   (Expand/struct.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _expand_struct1839_225_expand_struct(obj_t, obj_t, obj_t);
extern obj_t _unsafe_struct__195_engine_param;
extern obj_t match_define_structure__81___match_normalize(obj_t);
extern obj_t module_initialization_70_expand_struct(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___match_normalize(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern long list_length(obj_t);
static obj_t imported_modules_init_94_expand_struct();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_struct();
extern obj_t open_input_string(obj_t);
static obj_t epairify_expand_struct(obj_t, obj_t);
extern obj_t expand_struct_56_expand_struct(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_expand_struct = BUNSPEC;
static obj_t cnst_init_137_expand_struct();
static obj_t __cnst[31];

DEFINE_EXPORT_PROCEDURE(expand_struct_env_88_expand_struct, _expand_struct1839_225_expand_struct1852, _expand_struct1839_225_expand_struct, 0L, 2);
DEFINE_STRING(string1846_expand_struct, string1846_expand_struct1853, "((UNSPECIFIED)) U-STRUCT-SET! STRUCT-SET! V U-STRUCT-REF STRUCT-REF S STRUCT-KEY EQ? STRUCT? O ? -SET! - C-CREATE-STRUCT NEW LET CAR MAKE-STRUCT QUOTE ERROR CDR NULL? NOT PAIR? IF INIT MAKE- DEFINE-INLINE BEGIN (QUOTE ()) ", 222);
DEFINE_STRING(string1845_expand_struct, string1845_expand_struct1854, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string1844_expand_struct, string1844_expand_struct1855, "cer", 3);
DEFINE_STRING(string1843_expand_struct, string1843_expand_struct1856, "struct-set!:not an instance of", 30);
DEFINE_STRING(string1842_expand_struct, string1842_expand_struct1857, "struct-ref:not an instance of", 29);
DEFINE_STRING(string1841_expand_struct, string1841_expand_struct1858, "Too many argument provided", 26);
DEFINE_STRING(string1840_expand_struct, string1840_expand_struct1859, "Illegal `define-struct' form", 28);


/* module-initialization */ obj_t 
module_initialization_70_expand_struct(long checksum_710, char *from_711)
{
   if (CBOOL(require_initialization_114_expand_struct))
     {
	require_initialization_114_expand_struct = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_struct();
	cnst_init_137_expand_struct();
	imported_modules_init_94_expand_struct();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_struct()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_STRUCT");
   module_initialization_70___match_normalize(((long) 0), "EXPAND_STRUCT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_STRUCT");
   module_initialization_70___reader(((long) 0), "EXPAND_STRUCT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_struct()
{
   {
      obj_t cnst_port_138_702;
      cnst_port_138_702 = open_input_string(string1846_expand_struct);
      {
	 long i_703;
	 i_703 = ((long) 30);
       loop_704:
	 {
	    bool_t test1847_705;
	    test1847_705 = (i_703 == ((long) -1));
	    if (test1847_705)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1848_706;
		    {
		       obj_t list1849_707;
		       {
			  obj_t arg1850_708;
			  arg1850_708 = BNIL;
			  list1849_707 = MAKE_PAIR(cnst_port_138_702, arg1850_708);
		       }
		       arg1848_706 = read___reader(list1849_707);
		    }
		    CNST_TABLE_SET(i_703, arg1848_706);
		 }
		 {
		    int aux_709;
		    {
		       long aux_728;
		       aux_728 = (i_703 - ((long) 1));
		       aux_709 = (int) (aux_728);
		    }
		    {
		       long i_731;
		       i_731 = (long) (aux_709);
		       i_703 = i_731;
		       goto loop_704;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-struct */ obj_t 
expand_struct_56_expand_struct(obj_t x_1, obj_t e_2)
{
   {
      obj_t name_5;
      obj_t slots_6;
      if (PAIRP(x_1))
	{
	   obj_t cdr_109_69_11;
	   cdr_109_69_11 = CDR(x_1);
	   if (PAIRP(cdr_109_69_11))
	     {
		name_5 = CAR(cdr_109_69_11);
		slots_6 = CDR(cdr_109_69_11);
		match_define_structure__81___match_normalize(x_1);
		{
		   long len_15;
		   len_15 = list_length(slots_6);
		   {
		      obj_t slots_name_121_16;
		      if (NULLP(slots_6))
			{
			   slots_name_121_16 = BNIL;
			}
		      else
			{
			   obj_t head1004_568;
			   head1004_568 = MAKE_PAIR(BNIL, BNIL);
			   {
			      obj_t l1002_569;
			      obj_t tail1005_570;
			      l1002_569 = slots_6;
			      tail1005_570 = head1004_568;
			    lname1003_571:
			      if (NULLP(l1002_569))
				{
				   slots_name_121_16 = CDR(head1004_568);
				}
			      else
				{
				   obj_t newtail1006_573;
				   {
				      obj_t arg1821_575;
				      {
					 obj_t s_577;
					 s_577 = CAR(l1002_569);
					 {
					    if (PAIRP(s_577))
					      {
						 obj_t cdr_125_100_585;
						 cdr_125_100_585 = CDR(s_577);
						 if (PAIRP(cdr_125_100_585))
						   {
						      bool_t test_752;
						      {
							 obj_t aux_753;
							 aux_753 = CDR(cdr_125_100_585);
							 test_752 = (aux_753 == BNIL);
						      }
						      if (test_752)
							{
							   arg1821_575 = CAR(s_577);
							}
						      else
							{
							   if (SYMBOLP(s_577))
							     {
								arg1821_575 = s_577;
							     }
							   else
							     {
							      tag_118_180_582:
								FAILURE(BFALSE, string1840_expand_struct, x_1);
							     }
							}
						   }
						 else
						   {
						      if (SYMBOLP(s_577))
							{
							   arg1821_575 = s_577;
							}
						      else
							{
							   goto tag_118_180_582;
							}
						   }
					      }
					    else
					      {
						 if (SYMBOLP(s_577))
						   {
						      arg1821_575 = s_577;
						   }
						 else
						   {
						      goto tag_118_180_582;
						   }
					      }
					 }
				      }
				      newtail1006_573 = MAKE_PAIR(arg1821_575, BNIL);
				   }
				   SET_CDR(tail1005_570, newtail1006_573);
				   {
				      obj_t tail1005_768;
				      obj_t l1002_766;
				      l1002_766 = CDR(l1002_569);
				      tail1005_768 = newtail1006_573;
				      tail1005_570 = tail1005_768;
				      l1002_569 = l1002_766;
				      goto lname1003_571;
				   }
				}
			   }
			}
		      {
			 bool_t slots_val__167_17;
			 slots_val__167_17 = ((bool_t) 0);
			 {
			    obj_t slots_val_6_18;
			    if (NULLP(slots_6))
			      {
				 slots_val_6_18 = BNIL;
			      }
			    else
			      {
				 obj_t head1009_539;
				 head1009_539 = MAKE_PAIR(BNIL, BNIL);
				 {
				    obj_t l1007_540;
				    obj_t tail1010_541;
				    l1007_540 = slots_6;
				    tail1010_541 = head1009_539;
				  lname1008_542:
				    if (NULLP(l1007_540))
				      {
					 slots_val_6_18 = CDR(head1009_539);
				      }
				    else
				      {
					 obj_t newtail1011_544;
					 {
					    obj_t arg1804_546;
					    {
					       obj_t s_548;
					       s_548 = CAR(l1007_540);
					       {
						  if (PAIRP(s_548))
						    {
						       obj_t cdr_138_77_555;
						       cdr_138_77_555 = CDR(s_548);
						       if (PAIRP(cdr_138_77_555))
							 {
							    bool_t test_781;
							    {
							       obj_t aux_782;
							       aux_782 = CDR(cdr_138_77_555);
							       test_781 = (aux_782 == BNIL);
							    }
							    if (test_781)
							      {
								 slots_val__167_17 = ((bool_t) 1);
								 arg1804_546 = CAR(cdr_138_77_555);
							      }
							    else
							      {
								 if (SYMBOLP(s_548))
								   {
								      arg1804_546 = CNST_TABLE_REF(((long) 0));
								   }
								 else
								   {
								    tag_133_84_552:
								      FAILURE(BFALSE, string1840_expand_struct, x_1);
								   }
							      }
							 }
						       else
							 {
							    if (SYMBOLP(s_548))
							      {
								 arg1804_546 = CNST_TABLE_REF(((long) 0));
							      }
							    else
							      {
								 goto tag_133_84_552;
							      }
							 }
						    }
						  else
						    {
						       if (SYMBOLP(s_548))
							 {
							    arg1804_546 = CNST_TABLE_REF(((long) 0));
							 }
						       else
							 {
							    goto tag_133_84_552;
							 }
						    }
					       }
					    }
					    newtail1011_544 = MAKE_PAIR(arg1804_546, BNIL);
					 }
					 SET_CDR(tail1010_541, newtail1011_544);
					 {
					    obj_t tail1010_800;
					    obj_t l1007_798;
					    l1007_798 = CDR(l1007_540);
					    tail1010_800 = newtail1011_544;
					    tail1010_541 = tail1010_800;
					    l1007_540 = l1007_798;
					    goto lname1008_542;
					 }
				      }
				 }
			      }
			    {
			       {
				  obj_t arg1018_19;
				  obj_t arg1020_20;
				  arg1018_19 = CNST_TABLE_REF(((long) 1));
				  {
				     obj_t arg1025_21;
				     obj_t arg1032_22;
				     {
					obj_t arg1034_23;
					{
					   obj_t arg1038_24;
					   {
					      obj_t arg1039_25;
					      obj_t arg1040_26;
					      obj_t arg1041_27;
					      arg1039_25 = CNST_TABLE_REF(((long) 2));
					      {
						 obj_t arg1058_33;
						 obj_t arg1059_34;
						 {
						    obj_t arg1062_37;
						    arg1062_37 = CNST_TABLE_REF(((long) 3));
						    {
						       obj_t list1063_38;
						       {
							  obj_t arg1065_39;
							  arg1065_39 = MAKE_PAIR(name_5, BNIL);
							  list1063_38 = MAKE_PAIR(arg1062_37, arg1065_39);
						       }
						       arg1058_33 = symbol_append_197___r4_symbols_6_4(list1063_38);
						    }
						 }
						 arg1059_34 = CNST_TABLE_REF(((long) 4));
						 {
						    obj_t list1060_35;
						    list1060_35 = MAKE_PAIR(arg1059_34, BNIL);
						    arg1040_26 = cons__138___r4_pairs_and_lists_6_3(arg1058_33, list1060_35);
						 }
					      }
					      if (slots_val__167_17)
						{
						   obj_t arg1077_41;
						   obj_t arg1137_42;
						   obj_t arg1142_43;
						   obj_t arg1144_44;
						   arg1077_41 = CNST_TABLE_REF(((long) 5));
						   {
						      obj_t arg1175_51;
						      obj_t arg1176_52;
						      arg1175_51 = CNST_TABLE_REF(((long) 6));
						      arg1176_52 = CNST_TABLE_REF(((long) 4));
						      {
							 obj_t list1188_54;
							 {
							    obj_t arg1190_55;
							    arg1190_55 = MAKE_PAIR(BNIL, BNIL);
							    list1188_54 = MAKE_PAIR(arg1176_52, arg1190_55);
							 }
							 arg1137_42 = cons__138___r4_pairs_and_lists_6_3(arg1175_51, list1188_54);
						      }
						   }
						   {
						      obj_t arg1192_57;
						      obj_t arg1193_58;
						      obj_t arg1194_59;
						      obj_t arg1195_60;
						      arg1192_57 = CNST_TABLE_REF(((long) 5));
						      {
							 obj_t arg1203_67;
							 obj_t arg1204_68;
							 arg1203_67 = CNST_TABLE_REF(((long) 7));
							 {
							    obj_t arg1210_73;
							    obj_t arg1211_74;
							    arg1210_73 = CNST_TABLE_REF(((long) 8));
							    {
							       obj_t arg1220_79;
							       obj_t arg1221_80;
							       arg1220_79 = CNST_TABLE_REF(((long) 9));
							       arg1221_80 = CNST_TABLE_REF(((long) 4));
							       {
								  obj_t list1223_82;
								  {
								     obj_t arg1224_83;
								     arg1224_83 = MAKE_PAIR(BNIL, BNIL);
								     list1223_82 = MAKE_PAIR(arg1221_80, arg1224_83);
								  }
								  arg1211_74 = cons__138___r4_pairs_and_lists_6_3(arg1220_79, list1223_82);
							       }
							    }
							    {
							       obj_t list1214_76;
							       {
								  obj_t arg1216_77;
								  arg1216_77 = MAKE_PAIR(BNIL, BNIL);
								  list1214_76 = MAKE_PAIR(arg1211_74, arg1216_77);
							       }
							       arg1204_68 = cons__138___r4_pairs_and_lists_6_3(arg1210_73, list1214_76);
							    }
							 }
							 {
							    obj_t list1206_70;
							    {
							       obj_t arg1207_71;
							       arg1207_71 = MAKE_PAIR(BNIL, BNIL);
							       list1206_70 = MAKE_PAIR(arg1204_68, arg1207_71);
							    }
							    arg1193_58 = cons__138___r4_pairs_and_lists_6_3(arg1203_67, list1206_70);
							 }
						      }
						      {
							 obj_t arg1226_85;
							 obj_t arg1228_86;
							 obj_t arg1232_88;
							 arg1226_85 = CNST_TABLE_REF(((long) 10));
							 {
							    obj_t arg1241_95;
							    obj_t arg1243_96;
							    arg1241_95 = CNST_TABLE_REF(((long) 11));
							    {
							       obj_t arg1250_101;
							       arg1250_101 = CNST_TABLE_REF(((long) 3));
							       {
								  obj_t list1251_102;
								  {
								     obj_t arg1252_103;
								     arg1252_103 = MAKE_PAIR(name_5, BNIL);
								     list1251_102 = MAKE_PAIR(arg1250_101, arg1252_103);
								  }
								  arg1243_96 = symbol_append_197___r4_symbols_6_4(list1251_102);
							       }
							    }
							    {
							       obj_t list1245_98;
							       {
								  obj_t arg1247_99;
								  arg1247_99 = MAKE_PAIR(BNIL, BNIL);
								  list1245_98 = MAKE_PAIR(arg1243_96, arg1247_99);
							       }
							       arg1228_86 = cons__138___r4_pairs_and_lists_6_3(arg1241_95, list1245_98);
							    }
							 }
							 arg1232_88 = CNST_TABLE_REF(((long) 4));
							 {
							    obj_t list1234_90;
							    {
							       obj_t arg1235_91;
							       {
								  obj_t arg1236_92;
								  {
								     obj_t arg1238_93;
								     arg1238_93 = MAKE_PAIR(BNIL, BNIL);
								     arg1236_92 = MAKE_PAIR(arg1232_88, arg1238_93);
								  }
								  arg1235_91 = MAKE_PAIR(string1841_expand_struct, arg1236_92);
							       }
							       list1234_90 = MAKE_PAIR(arg1228_86, arg1235_91);
							    }
							    arg1194_59 = cons__138___r4_pairs_and_lists_6_3(arg1226_85, list1234_90);
							 }
						      }
						      {
							 obj_t arg1254_105;
							 obj_t arg1255_106;
							 obj_t arg1256_107;
							 arg1254_105 = CNST_TABLE_REF(((long) 12));
							 {
							    obj_t arg1265_114;
							    arg1265_114 = CNST_TABLE_REF(((long) 11));
							    {
							       obj_t list1268_116;
							       {
								  obj_t arg1269_117;
								  arg1269_117 = MAKE_PAIR(BNIL, BNIL);
								  list1268_116 = MAKE_PAIR(name_5, arg1269_117);
							       }
							       arg1255_106 = cons__138___r4_pairs_and_lists_6_3(arg1265_114, list1268_116);
							    }
							 }
							 {
							    obj_t arg1272_119;
							    obj_t arg1273_120;
							    arg1272_119 = CNST_TABLE_REF(((long) 13));
							    arg1273_120 = CNST_TABLE_REF(((long) 4));
							    {
							       obj_t list1275_122;
							       {
								  obj_t arg1277_123;
								  arg1277_123 = MAKE_PAIR(BNIL, BNIL);
								  list1275_122 = MAKE_PAIR(arg1273_120, arg1277_123);
							       }
							       arg1256_107 = cons__138___r4_pairs_and_lists_6_3(arg1272_119, list1275_122);
							    }
							 }
							 {
							    obj_t list1258_109;
							    {
							       obj_t arg1259_110;
							       {
								  obj_t arg1260_111;
								  {
								     obj_t arg1262_112;
								     arg1262_112 = MAKE_PAIR(BNIL, BNIL);
								     arg1260_111 = MAKE_PAIR(arg1256_107, arg1262_112);
								  }
								  {
								     obj_t aux_858;
								     aux_858 = BINT(len_15);
								     arg1259_110 = MAKE_PAIR(aux_858, arg1260_111);
								  }
							       }
							       list1258_109 = MAKE_PAIR(arg1255_106, arg1259_110);
							    }
							    arg1195_60 = cons__138___r4_pairs_and_lists_6_3(arg1254_105, list1258_109);
							 }
						      }
						      {
							 obj_t list1197_62;
							 {
							    obj_t arg1199_63;
							    {
							       obj_t arg1200_64;
							       {
								  obj_t arg1201_65;
								  arg1201_65 = MAKE_PAIR(BNIL, BNIL);
								  arg1200_64 = MAKE_PAIR(arg1195_60, arg1201_65);
							       }
							       arg1199_63 = MAKE_PAIR(arg1194_59, arg1200_64);
							    }
							    list1197_62 = MAKE_PAIR(arg1193_58, arg1199_63);
							 }
							 arg1142_43 = cons__138___r4_pairs_and_lists_6_3(arg1192_57, list1197_62);
						      }
						   }
						   {
						      obj_t arg1281_125;
						      {
							 obj_t arg1284_128;
							 arg1284_128 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							 arg1281_125 = append_2_18___r4_pairs_and_lists_6_3(slots_val_6_18, arg1284_128);
						      }
						      {
							 obj_t list1282_126;
							 list1282_126 = MAKE_PAIR(arg1281_125, BNIL);
							 arg1144_44 = cons__138___r4_pairs_and_lists_6_3(name_5, list1282_126);
						      }
						   }
						   {
						      obj_t list1146_46;
						      {
							 obj_t arg1150_47;
							 {
							    obj_t arg1157_48;
							    {
							       obj_t arg1161_49;
							       arg1161_49 = MAKE_PAIR(BNIL, BNIL);
							       arg1157_48 = MAKE_PAIR(arg1144_44, arg1161_49);
							    }
							    arg1150_47 = MAKE_PAIR(arg1142_43, arg1157_48);
							 }
							 list1146_46 = MAKE_PAIR(arg1137_42, arg1150_47);
						      }
						      arg1041_27 = cons__138___r4_pairs_and_lists_6_3(arg1077_41, list1146_46);
						   }
						}
					      else
						{
						   obj_t arg1287_131;
						   obj_t arg1288_132;
						   obj_t arg1290_133;
						   obj_t arg1291_134;
						   arg1287_131 = CNST_TABLE_REF(((long) 5));
						   {
						      obj_t arg1298_141;
						      obj_t arg1299_142;
						      arg1298_141 = CNST_TABLE_REF(((long) 6));
						      arg1299_142 = CNST_TABLE_REF(((long) 4));
						      {
							 obj_t list1301_144;
							 {
							    obj_t arg1302_145;
							    arg1302_145 = MAKE_PAIR(BNIL, BNIL);
							    list1301_144 = MAKE_PAIR(arg1299_142, arg1302_145);
							 }
							 arg1288_132 = cons__138___r4_pairs_and_lists_6_3(arg1298_141, list1301_144);
						      }
						   }
						   {
						      obj_t arg1304_147;
						      obj_t arg1307_148;
						      obj_t arg1308_149;
						      obj_t arg1309_150;
						      arg1304_147 = CNST_TABLE_REF(((long) 5));
						      {
							 obj_t arg1321_157;
							 obj_t arg1322_158;
							 arg1321_157 = CNST_TABLE_REF(((long) 7));
							 {
							    obj_t arg1328_163;
							    obj_t arg1330_164;
							    arg1328_163 = CNST_TABLE_REF(((long) 8));
							    {
							       obj_t arg1337_169;
							       obj_t arg1339_170;
							       arg1337_169 = CNST_TABLE_REF(((long) 9));
							       arg1339_170 = CNST_TABLE_REF(((long) 4));
							       {
								  obj_t list1341_172;
								  {
								     obj_t arg1342_173;
								     arg1342_173 = MAKE_PAIR(BNIL, BNIL);
								     list1341_172 = MAKE_PAIR(arg1339_170, arg1342_173);
								  }
								  arg1330_164 = cons__138___r4_pairs_and_lists_6_3(arg1337_169, list1341_172);
							       }
							    }
							    {
							       obj_t list1332_166;
							       {
								  obj_t arg1333_167;
								  arg1333_167 = MAKE_PAIR(BNIL, BNIL);
								  list1332_166 = MAKE_PAIR(arg1330_164, arg1333_167);
							       }
							       arg1322_158 = cons__138___r4_pairs_and_lists_6_3(arg1328_163, list1332_166);
							    }
							 }
							 {
							    obj_t list1324_160;
							    {
							       obj_t arg1325_161;
							       arg1325_161 = MAKE_PAIR(BNIL, BNIL);
							       list1324_160 = MAKE_PAIR(arg1322_158, arg1325_161);
							    }
							    arg1307_148 = cons__138___r4_pairs_and_lists_6_3(arg1321_157, list1324_160);
							 }
						      }
						      {
							 obj_t arg1344_175;
							 obj_t arg1345_176;
							 obj_t arg1349_178;
							 arg1344_175 = CNST_TABLE_REF(((long) 10));
							 {
							    obj_t arg1357_185;
							    obj_t arg1361_186;
							    arg1357_185 = CNST_TABLE_REF(((long) 11));
							    {
							       obj_t arg1368_191;
							       arg1368_191 = CNST_TABLE_REF(((long) 3));
							       {
								  obj_t list1369_192;
								  {
								     obj_t arg1370_193;
								     arg1370_193 = MAKE_PAIR(name_5, BNIL);
								     list1369_192 = MAKE_PAIR(arg1368_191, arg1370_193);
								  }
								  arg1361_186 = symbol_append_197___r4_symbols_6_4(list1369_192);
							       }
							    }
							    {
							       obj_t list1364_188;
							       {
								  obj_t arg1365_189;
								  arg1365_189 = MAKE_PAIR(BNIL, BNIL);
								  list1364_188 = MAKE_PAIR(arg1361_186, arg1365_189);
							       }
							       arg1345_176 = cons__138___r4_pairs_and_lists_6_3(arg1357_185, list1364_188);
							    }
							 }
							 arg1349_178 = CNST_TABLE_REF(((long) 4));
							 {
							    obj_t list1351_180;
							    {
							       obj_t arg1352_181;
							       {
								  obj_t arg1353_182;
								  {
								     obj_t arg1355_183;
								     arg1355_183 = MAKE_PAIR(BNIL, BNIL);
								     arg1353_182 = MAKE_PAIR(arg1349_178, arg1355_183);
								  }
								  arg1352_181 = MAKE_PAIR(string1841_expand_struct, arg1353_182);
							       }
							       list1351_180 = MAKE_PAIR(arg1345_176, arg1352_181);
							    }
							    arg1308_149 = cons__138___r4_pairs_and_lists_6_3(arg1344_175, list1351_180);
							 }
						      }
						      {
							 obj_t arg1373_195;
							 obj_t arg1375_196;
							 obj_t arg1378_197;
							 arg1373_195 = CNST_TABLE_REF(((long) 12));
							 {
							    obj_t arg1387_204;
							    arg1387_204 = CNST_TABLE_REF(((long) 11));
							    {
							       obj_t list1389_206;
							       {
								  obj_t arg1390_207;
								  arg1390_207 = MAKE_PAIR(BNIL, BNIL);
								  list1389_206 = MAKE_PAIR(name_5, arg1390_207);
							       }
							       arg1375_196 = cons__138___r4_pairs_and_lists_6_3(arg1387_204, list1389_206);
							    }
							 }
							 {
							    obj_t arg1392_209;
							    obj_t arg1393_210;
							    arg1392_209 = CNST_TABLE_REF(((long) 13));
							    arg1393_210 = CNST_TABLE_REF(((long) 4));
							    {
							       obj_t list1396_212;
							       {
								  obj_t arg1397_213;
								  arg1397_213 = MAKE_PAIR(BNIL, BNIL);
								  list1396_212 = MAKE_PAIR(arg1393_210, arg1397_213);
							       }
							       arg1378_197 = cons__138___r4_pairs_and_lists_6_3(arg1392_209, list1396_212);
							    }
							 }
							 {
							    obj_t list1380_199;
							    {
							       obj_t arg1381_200;
							       {
								  obj_t arg1383_201;
								  {
								     obj_t arg1384_202;
								     arg1384_202 = MAKE_PAIR(BNIL, BNIL);
								     arg1383_201 = MAKE_PAIR(arg1378_197, arg1384_202);
								  }
								  {
								     obj_t aux_924;
								     aux_924 = BINT(len_15);
								     arg1381_200 = MAKE_PAIR(aux_924, arg1383_201);
								  }
							       }
							       list1380_199 = MAKE_PAIR(arg1375_196, arg1381_200);
							    }
							    arg1309_150 = cons__138___r4_pairs_and_lists_6_3(arg1373_195, list1380_199);
							 }
						      }
						      {
							 obj_t list1311_152;
							 {
							    obj_t arg1313_153;
							    {
							       obj_t arg1315_154;
							       {
								  obj_t arg1316_155;
								  arg1316_155 = MAKE_PAIR(BNIL, BNIL);
								  arg1315_154 = MAKE_PAIR(arg1309_150, arg1316_155);
							       }
							       arg1313_153 = MAKE_PAIR(arg1308_149, arg1315_154);
							    }
							    list1311_152 = MAKE_PAIR(arg1307_148, arg1313_153);
							 }
							 arg1290_133 = cons__138___r4_pairs_and_lists_6_3(arg1304_147, list1311_152);
						      }
						   }
						   {
						      obj_t arg1399_215;
						      obj_t arg1401_216;
						      obj_t arg1402_217;
						      arg1399_215 = CNST_TABLE_REF(((long) 12));
						      {
							 obj_t arg1411_224;
							 arg1411_224 = CNST_TABLE_REF(((long) 11));
							 {
							    obj_t list1414_226;
							    {
							       obj_t arg1415_227;
							       arg1415_227 = MAKE_PAIR(BNIL, BNIL);
							       list1414_226 = MAKE_PAIR(name_5, arg1415_227);
							    }
							    arg1401_216 = cons__138___r4_pairs_and_lists_6_3(arg1411_224, list1414_226);
							 }
						      }
						      {
							 obj_t arg1417_229;
							 arg1417_229 = CNST_TABLE_REF(((long) 11));
							 {
							    obj_t list1420_232;
							    {
							       obj_t arg1421_233;
							       arg1421_233 = MAKE_PAIR(BNIL, BNIL);
							       list1420_232 = MAKE_PAIR(BNIL, arg1421_233);
							    }
							    arg1402_217 = cons__138___r4_pairs_and_lists_6_3(arg1417_229, list1420_232);
							 }
						      }
						      {
							 obj_t list1404_219;
							 {
							    obj_t arg1405_220;
							    {
							       obj_t arg1407_221;
							       {
								  obj_t arg1408_222;
								  arg1408_222 = MAKE_PAIR(BNIL, BNIL);
								  arg1407_221 = MAKE_PAIR(arg1402_217, arg1408_222);
							       }
							       {
								  obj_t aux_945;
								  aux_945 = BINT(len_15);
								  arg1405_220 = MAKE_PAIR(aux_945, arg1407_221);
							       }
							    }
							    list1404_219 = MAKE_PAIR(arg1401_216, arg1405_220);
							 }
							 arg1291_134 = cons__138___r4_pairs_and_lists_6_3(arg1399_215, list1404_219);
						      }
						   }
						   {
						      obj_t list1293_136;
						      {
							 obj_t arg1294_137;
							 {
							    obj_t arg1295_138;
							    {
							       obj_t arg1296_139;
							       arg1296_139 = MAKE_PAIR(BNIL, BNIL);
							       arg1295_138 = MAKE_PAIR(arg1291_134, arg1296_139);
							    }
							    arg1294_137 = MAKE_PAIR(arg1290_133, arg1295_138);
							 }
							 list1293_136 = MAKE_PAIR(arg1288_132, arg1294_137);
						      }
						      arg1041_27 = cons__138___r4_pairs_and_lists_6_3(arg1287_131, list1293_136);
						   }
						}
					      {
						 obj_t list1054_29;
						 {
						    obj_t arg1055_30;
						    {
						       obj_t arg1056_31;
						       arg1056_31 = MAKE_PAIR(BNIL, BNIL);
						       arg1055_30 = MAKE_PAIR(arg1041_27, arg1056_31);
						    }
						    list1054_29 = MAKE_PAIR(arg1040_26, arg1055_30);
						 }
						 arg1038_24 = cons__138___r4_pairs_and_lists_6_3(arg1039_25, list1054_29);
					      }
					   }
					   arg1034_23 = epairify_expand_struct(arg1038_24, x_1);
					}
					arg1025_21 = PROCEDURE_ENTRY(e_2) (e_2, arg1034_23, e_2, BEOA);
				     }
				     {
					obj_t arg1426_235;
					obj_t arg1427_236;
					{
					   obj_t arg1428_237;
					   {
					      obj_t arg1431_238;
					      {
						 obj_t arg1432_239;
						 obj_t arg1433_240;
						 obj_t arg1436_241;
						 arg1432_239 = CNST_TABLE_REF(((long) 2));
						 {
						    obj_t arg1444_247;
						    {
						       obj_t arg1448_250;
						       arg1448_250 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						       arg1444_247 = append_2_18___r4_pairs_and_lists_6_3(slots_name_121_16, arg1448_250);
						    }
						    {
						       obj_t list1445_248;
						       list1445_248 = MAKE_PAIR(arg1444_247, BNIL);
						       arg1433_240 = cons__138___r4_pairs_and_lists_6_3(name_5, list1445_248);
						    }
						 }
						 {
						    obj_t arg1453_253;
						    obj_t arg1454_254;
						    obj_t arg1455_255;
						    arg1453_253 = CNST_TABLE_REF(((long) 14));
						    {
						       obj_t arg1461_259;
						       {
							  obj_t arg1466_263;
							  obj_t arg1467_264;
							  arg1466_263 = CNST_TABLE_REF(((long) 15));
							  {
							     obj_t arg1473_269;
							     obj_t arg1474_270;
							     arg1473_269 = CNST_TABLE_REF(((long) 16));
							     {
								obj_t arg1480_276;
								arg1480_276 = CNST_TABLE_REF(((long) 11));
								{
								   obj_t list1482_278;
								   {
								      obj_t arg1483_279;
								      arg1483_279 = MAKE_PAIR(BNIL, BNIL);
								      list1482_278 = MAKE_PAIR(name_5, arg1483_279);
								   }
								   arg1474_270 = cons__138___r4_pairs_and_lists_6_3(arg1480_276, list1482_278);
								}
							     }
							     {
								obj_t list1476_272;
								{
								   obj_t arg1477_273;
								   {
								      obj_t arg1478_274;
								      arg1478_274 = MAKE_PAIR(BNIL, BNIL);
								      {
									 obj_t aux_975;
									 aux_975 = BINT(len_15);
									 arg1477_273 = MAKE_PAIR(aux_975, arg1478_274);
								      }
								   }
								   list1476_272 = MAKE_PAIR(arg1474_270, arg1477_273);
								}
								arg1467_264 = cons__138___r4_pairs_and_lists_6_3(arg1473_269, list1476_272);
							     }
							  }
							  {
							     obj_t list1469_266;
							     {
								obj_t arg1470_267;
								arg1470_267 = MAKE_PAIR(BNIL, BNIL);
								list1469_266 = MAKE_PAIR(arg1467_264, arg1470_267);
							     }
							     arg1461_259 = cons__138___r4_pairs_and_lists_6_3(arg1466_263, list1469_266);
							  }
						       }
						       {
							  obj_t list1464_261;
							  list1464_261 = MAKE_PAIR(BNIL, BNIL);
							  arg1454_254 = cons__138___r4_pairs_and_lists_6_3(arg1461_259, list1464_261);
						       }
						    }
						    {
						       obj_t arg1485_281;
						       obj_t arg1486_282;
						       {
							  obj_t slots_283;
							  obj_t res_284;
							  slots_283 = slots_name_121_16;
							  res_284 = BNIL;
							loop_285:
							  if (NULLP(slots_283))
							    {
							       arg1485_281 = res_284;
							    }
							  else
							    {
							       obj_t arg1489_288;
							       obj_t arg1490_289;
							       arg1489_288 = CDR(slots_283);
							       {
								  obj_t arg1491_290;
								  {
								     obj_t arg1494_291;
								     obj_t arg1496_292;
								     obj_t arg1497_293;
								     {
									obj_t arg1503_299;
									obj_t arg1504_300;
									arg1503_299 = CNST_TABLE_REF(((long) 17));
									arg1504_300 = CAR(slots_283);
									{
									   obj_t list1506_302;
									   {
									      obj_t arg1507_303;
									      {
										 obj_t arg1510_304;
										 {
										    obj_t arg1511_305;
										    {
										       obj_t aux_990;
										       aux_990 = CNST_TABLE_REF(((long) 18));
										       arg1511_305 = MAKE_PAIR(aux_990, BNIL);
										    }
										    arg1510_304 = MAKE_PAIR(arg1504_300, arg1511_305);
										 }
										 arg1507_303 = MAKE_PAIR(arg1503_299, arg1510_304);
									      }
									      list1506_302 = MAKE_PAIR(name_5, arg1507_303);
									   }
									   arg1494_291 = symbol_append_197___r4_symbols_6_4(list1506_302);
									}
								     }
								     arg1496_292 = CNST_TABLE_REF(((long) 15));
								     arg1497_293 = CAR(slots_283);
								     {
									obj_t list1499_295;
									{
									   obj_t arg1500_296;
									   {
									      obj_t arg1501_297;
									      arg1501_297 = MAKE_PAIR(BNIL, BNIL);
									      arg1500_296 = MAKE_PAIR(arg1497_293, arg1501_297);
									   }
									   list1499_295 = MAKE_PAIR(arg1496_292, arg1500_296);
									}
									arg1491_290 = cons__138___r4_pairs_and_lists_6_3(arg1494_291, list1499_295);
								     }
								  }
								  arg1490_289 = MAKE_PAIR(arg1491_290, res_284);
							       }
							       {
								  obj_t res_1005;
								  obj_t slots_1004;
								  slots_1004 = arg1489_288;
								  res_1005 = arg1490_289;
								  res_284 = res_1005;
								  slots_283 = slots_1004;
								  goto loop_285;
							       }
							    }
						       }
						       {
							  obj_t arg1514_307;
							  arg1514_307 = CNST_TABLE_REF(((long) 15));
							  {
							     obj_t list1516_309;
							     list1516_309 = MAKE_PAIR(BNIL, BNIL);
							     arg1486_282 = cons__138___r4_pairs_and_lists_6_3(arg1514_307, list1516_309);
							  }
						       }
						       arg1455_255 = append_2_18___r4_pairs_and_lists_6_3(arg1485_281, arg1486_282);
						    }
						    {
						       obj_t list1456_256;
						       {
							  obj_t arg1458_257;
							  arg1458_257 = MAKE_PAIR(arg1455_255, BNIL);
							  list1456_256 = MAKE_PAIR(arg1454_254, arg1458_257);
						       }
						       arg1436_241 = cons__138___r4_pairs_and_lists_6_3(arg1453_253, list1456_256);
						    }
						 }
						 {
						    obj_t list1438_243;
						    {
						       obj_t arg1440_244;
						       {
							  obj_t arg1441_245;
							  arg1441_245 = MAKE_PAIR(BNIL, BNIL);
							  arg1440_244 = MAKE_PAIR(arg1436_241, arg1441_245);
						       }
						       list1438_243 = MAKE_PAIR(arg1433_240, arg1440_244);
						    }
						    arg1431_238 = cons__138___r4_pairs_and_lists_6_3(arg1432_239, list1438_243);
						 }
					      }
					      arg1428_237 = epairify_expand_struct(arg1431_238, x_1);
					   }
					   arg1426_235 = PROCEDURE_ENTRY(e_2) (e_2, arg1428_237, e_2, BEOA);
					}
					{
					   obj_t arg1518_311;
					   obj_t arg1519_312;
					   {
					      obj_t arg1522_313;
					      {
						 obj_t arg1524_314;
						 {
						    obj_t arg1525_315;
						    obj_t arg1526_316;
						    obj_t arg1527_317;
						    arg1525_315 = CNST_TABLE_REF(((long) 2));
						    {
						       obj_t arg1533_323;
						       obj_t arg1534_324;
						       {
							  obj_t list1541_330;
							  {
							     obj_t arg1542_331;
							     {
								obj_t aux_1021;
								aux_1021 = CNST_TABLE_REF(((long) 19));
								arg1542_331 = MAKE_PAIR(aux_1021, BNIL);
							     }
							     list1541_330 = MAKE_PAIR(name_5, arg1542_331);
							  }
							  arg1533_323 = symbol_append_197___r4_symbols_6_4(list1541_330);
						       }
						       arg1534_324 = CNST_TABLE_REF(((long) 20));
						       {
							  obj_t list1536_326;
							  {
							     obj_t arg1537_327;
							     arg1537_327 = MAKE_PAIR(BNIL, BNIL);
							     list1536_326 = MAKE_PAIR(arg1534_324, arg1537_327);
							  }
							  arg1526_316 = cons__138___r4_pairs_and_lists_6_3(arg1533_323, list1536_326);
						       }
						    }
						    {
						       obj_t arg1548_333;
						       obj_t arg1549_334;
						       obj_t arg1550_335;
						       arg1548_333 = CNST_TABLE_REF(((long) 5));
						       {
							  obj_t arg1558_342;
							  obj_t arg1559_343;
							  arg1558_342 = CNST_TABLE_REF(((long) 21));
							  arg1559_343 = CNST_TABLE_REF(((long) 20));
							  {
							     obj_t list1561_345;
							     {
								obj_t arg1562_346;
								arg1562_346 = MAKE_PAIR(BNIL, BNIL);
								list1561_345 = MAKE_PAIR(arg1559_343, arg1562_346);
							     }
							     arg1549_334 = cons__138___r4_pairs_and_lists_6_3(arg1558_342, list1561_345);
							  }
						       }
						       {
							  obj_t arg1564_348;
							  obj_t arg1565_349;
							  obj_t arg1566_350;
							  arg1564_348 = CNST_TABLE_REF(((long) 22));
							  {
							     obj_t arg1575_356;
							     obj_t arg1578_357;
							     arg1575_356 = CNST_TABLE_REF(((long) 23));
							     arg1578_357 = CNST_TABLE_REF(((long) 20));
							     {
								obj_t list1581_359;
								{
								   obj_t arg1582_360;
								   arg1582_360 = MAKE_PAIR(BNIL, BNIL);
								   list1581_359 = MAKE_PAIR(arg1578_357, arg1582_360);
								}
								arg1565_349 = cons__138___r4_pairs_and_lists_6_3(arg1575_356, list1581_359);
							     }
							  }
							  {
							     obj_t arg1584_362;
							     arg1584_362 = CNST_TABLE_REF(((long) 11));
							     {
								obj_t list1586_364;
								{
								   obj_t arg1587_365;
								   arg1587_365 = MAKE_PAIR(BNIL, BNIL);
								   list1586_364 = MAKE_PAIR(name_5, arg1587_365);
								}
								arg1566_350 = cons__138___r4_pairs_and_lists_6_3(arg1584_362, list1586_364);
							     }
							  }
							  {
							     obj_t list1569_352;
							     {
								obj_t arg1570_353;
								{
								   obj_t arg1572_354;
								   arg1572_354 = MAKE_PAIR(BNIL, BNIL);
								   arg1570_353 = MAKE_PAIR(arg1566_350, arg1572_354);
								}
								list1569_352 = MAKE_PAIR(arg1565_349, arg1570_353);
							     }
							     arg1550_335 = cons__138___r4_pairs_and_lists_6_3(arg1564_348, list1569_352);
							  }
						       }
						       {
							  obj_t list1553_337;
							  {
							     obj_t arg1554_338;
							     {
								obj_t arg1555_339;
								{
								   obj_t arg1556_340;
								   arg1556_340 = MAKE_PAIR(BNIL, BNIL);
								   arg1555_339 = MAKE_PAIR(BFALSE, arg1556_340);
								}
								arg1554_338 = MAKE_PAIR(arg1550_335, arg1555_339);
							     }
							     list1553_337 = MAKE_PAIR(arg1549_334, arg1554_338);
							  }
							  arg1527_317 = cons__138___r4_pairs_and_lists_6_3(arg1548_333, list1553_337);
						       }
						    }
						    {
						       obj_t list1529_319;
						       {
							  obj_t arg1530_320;
							  {
							     obj_t arg1531_321;
							     arg1531_321 = MAKE_PAIR(BNIL, BNIL);
							     arg1530_320 = MAKE_PAIR(arg1527_317, arg1531_321);
							  }
							  list1529_319 = MAKE_PAIR(arg1526_316, arg1530_320);
						       }
						       arg1524_314 = cons__138___r4_pairs_and_lists_6_3(arg1525_315, list1529_319);
						    }
						 }
						 arg1522_313 = epairify_expand_struct(arg1524_314, x_1);
					      }
					      arg1518_311 = PROCEDURE_ENTRY(e_2) (e_2, arg1522_313, e_2, BEOA);
					   }
					   {
					      long i_367;
					      obj_t slots_368;
					      obj_t res_369;
					      i_367 = ((long) 0);
					      slots_368 = slots_name_121_16;
					      res_369 = CNST_TABLE_REF(((long) 30));
					    loop_370:
					      if ((i_367 == len_15))
						{
						   arg1519_312 = res_369;
						}
					      else
						{
						   obj_t pr_374;
						   pr_374 = CAR(slots_368);
						   {
						      long arg1594_375;
						      obj_t arg1595_376;
						      obj_t arg1598_377;
						      arg1594_375 = (i_367 + ((long) 1));
						      arg1595_376 = CDR(slots_368);
						      {
							 obj_t arg1600_378;
							 obj_t arg1602_379;
							 {
							    obj_t arg1603_380;
							    {
							       obj_t arg1605_381;
							       {
								  obj_t arg1606_382;
								  obj_t arg1607_383;
								  obj_t arg1608_384;
								  arg1606_382 = CNST_TABLE_REF(((long) 2));
								  {
								     obj_t arg1617_390;
								     obj_t arg1618_391;
								     {
									obj_t arg1624_396;
									arg1624_396 = CNST_TABLE_REF(((long) 17));
									{
									   obj_t list1625_397;
									   {
									      obj_t arg1627_398;
									      {
										 obj_t arg1628_399;
										 arg1628_399 = MAKE_PAIR(pr_374, BNIL);
										 arg1627_398 = MAKE_PAIR(arg1624_396, arg1628_399);
									      }
									      list1625_397 = MAKE_PAIR(name_5, arg1627_398);
									   }
									   arg1617_390 = symbol_append_197___r4_symbols_6_4(list1625_397);
									}
								     }
								     arg1618_391 = CNST_TABLE_REF(((long) 24));
								     {
									obj_t list1621_393;
									{
									   obj_t arg1622_394;
									   arg1622_394 = MAKE_PAIR(BNIL, BNIL);
									   list1621_393 = MAKE_PAIR(arg1618_391, arg1622_394);
									}
									arg1607_383 = cons__138___r4_pairs_and_lists_6_3(arg1617_390, list1621_393);
								     }
								  }
								  if (CBOOL(_unsafe_struct__195_engine_param))
								    {
								       obj_t arg1632_401;
								       obj_t arg1633_402;
								       arg1632_401 = CNST_TABLE_REF(((long) 25));
								       arg1633_402 = CNST_TABLE_REF(((long) 24));
								       {
									  obj_t list1635_404;
									  {
									     obj_t arg1636_405;
									     {
										obj_t arg1638_406;
										arg1638_406 = MAKE_PAIR(BNIL, BNIL);
										{
										   obj_t aux_1082;
										   aux_1082 = BINT(i_367);
										   arg1636_405 = MAKE_PAIR(aux_1082, arg1638_406);
										}
									     }
									     list1635_404 = MAKE_PAIR(arg1633_402, arg1636_405);
									  }
									  arg1608_384 = cons__138___r4_pairs_and_lists_6_3(arg1632_401, list1635_404);
								       }
								    }
								  else
								    {
								       obj_t arg1640_408;
								       obj_t arg1641_409;
								       obj_t arg1645_410;
								       obj_t arg1646_411;
								       arg1640_408 = CNST_TABLE_REF(((long) 5));
								       {
									  obj_t arg1654_418;
									  obj_t arg1655_419;
									  obj_t arg1656_420;
									  arg1654_418 = CNST_TABLE_REF(((long) 22));
									  {
									     obj_t arg1665_426;
									     obj_t arg1666_427;
									     arg1665_426 = CNST_TABLE_REF(((long) 23));
									     arg1666_427 = CNST_TABLE_REF(((long) 24));
									     {
										obj_t list1668_429;
										{
										   obj_t arg1669_430;
										   arg1669_430 = MAKE_PAIR(BNIL, BNIL);
										   list1668_429 = MAKE_PAIR(arg1666_427, arg1669_430);
										}
										arg1655_419 = cons__138___r4_pairs_and_lists_6_3(arg1665_426, list1668_429);
									     }
									  }
									  {
									     obj_t arg1672_432;
									     arg1672_432 = CNST_TABLE_REF(((long) 11));
									     {
										obj_t list1674_434;
										{
										   obj_t arg1675_435;
										   arg1675_435 = MAKE_PAIR(BNIL, BNIL);
										   list1674_434 = MAKE_PAIR(name_5, arg1675_435);
										}
										arg1656_420 = cons__138___r4_pairs_and_lists_6_3(arg1672_432, list1674_434);
									     }
									  }
									  {
									     obj_t list1658_422;
									     {
										obj_t arg1659_423;
										{
										   obj_t arg1661_424;
										   arg1661_424 = MAKE_PAIR(BNIL, BNIL);
										   arg1659_423 = MAKE_PAIR(arg1656_420, arg1661_424);
										}
										list1658_422 = MAKE_PAIR(arg1655_419, arg1659_423);
									     }
									     arg1641_409 = cons__138___r4_pairs_and_lists_6_3(arg1654_418, list1658_422);
									  }
								       }
								       {
									  obj_t arg1677_437;
									  obj_t arg1678_438;
									  arg1677_437 = CNST_TABLE_REF(((long) 26));
									  arg1678_438 = CNST_TABLE_REF(((long) 24));
									  {
									     obj_t list1680_440;
									     {
										obj_t arg1681_441;
										{
										   obj_t arg1682_442;
										   arg1682_442 = MAKE_PAIR(BNIL, BNIL);
										   {
										      obj_t aux_1105;
										      aux_1105 = BINT(i_367);
										      arg1681_441 = MAKE_PAIR(aux_1105, arg1682_442);
										   }
										}
										list1680_440 = MAKE_PAIR(arg1678_438, arg1681_441);
									     }
									     arg1645_410 = cons__138___r4_pairs_and_lists_6_3(arg1677_437, list1680_440);
									  }
								       }
								       {
									  obj_t arg1684_444;
									  obj_t arg1686_446;
									  obj_t arg1688_447;
									  arg1684_444 = CNST_TABLE_REF(((long) 10));
									  arg1686_446 = SYMBOL_TO_STRING(name_5);
									  arg1688_447 = CNST_TABLE_REF(((long) 24));
									  {
									     obj_t list1690_449;
									     {
										obj_t arg1691_450;
										{
										   obj_t arg1692_451;
										   {
										      obj_t arg1693_452;
										      arg1693_452 = MAKE_PAIR(BNIL, BNIL);
										      arg1692_451 = MAKE_PAIR(arg1688_447, arg1693_452);
										   }
										   arg1691_450 = MAKE_PAIR(arg1686_446, arg1692_451);
										}
										list1690_449 = MAKE_PAIR(string1842_expand_struct, arg1691_450);
									     }
									     arg1646_411 = cons__138___r4_pairs_and_lists_6_3(arg1684_444, list1690_449);
									  }
								       }
								       {
									  obj_t list1648_413;
									  {
									     obj_t arg1649_414;
									     {
										obj_t arg1650_415;
										{
										   obj_t arg1652_416;
										   arg1652_416 = MAKE_PAIR(BNIL, BNIL);
										   arg1650_415 = MAKE_PAIR(arg1646_411, arg1652_416);
										}
										arg1649_414 = MAKE_PAIR(arg1645_410, arg1650_415);
									     }
									     list1648_413 = MAKE_PAIR(arg1641_409, arg1649_414);
									  }
									  arg1608_384 = cons__138___r4_pairs_and_lists_6_3(arg1640_408, list1648_413);
								       }
								    }
								  {
								     obj_t list1610_386;
								     {
									obj_t arg1612_387;
									{
									   obj_t arg1613_388;
									   arg1613_388 = MAKE_PAIR(BNIL, BNIL);
									   arg1612_387 = MAKE_PAIR(arg1608_384, arg1613_388);
									}
									list1610_386 = MAKE_PAIR(arg1607_383, arg1612_387);
								     }
								     arg1605_381 = cons__138___r4_pairs_and_lists_6_3(arg1606_382, list1610_386);
								  }
							       }
							       arg1603_380 = epairify_expand_struct(arg1605_381, x_1);
							    }
							    arg1600_378 = PROCEDURE_ENTRY(e_2) (e_2, arg1603_380, e_2, BEOA);
							 }
							 {
							    obj_t arg1695_454;
							    {
							       obj_t arg1697_455;
							       {
								  obj_t arg1698_456;
								  {
								     obj_t arg1699_457;
								     obj_t arg1700_458;
								     obj_t arg1701_459;
								     arg1699_457 = CNST_TABLE_REF(((long) 2));
								     {
									obj_t arg1707_465;
									obj_t arg1708_466;
									obj_t arg1709_467;
									{
									   obj_t arg1716_473;
									   arg1716_473 = CNST_TABLE_REF(((long) 17));
									   {
									      obj_t list1718_475;
									      {
										 obj_t arg1720_476;
										 {
										    obj_t arg1721_477;
										    {
										       obj_t arg1722_478;
										       {
											  obj_t aux_1132;
											  aux_1132 = CNST_TABLE_REF(((long) 18));
											  arg1722_478 = MAKE_PAIR(aux_1132, BNIL);
										       }
										       arg1721_477 = MAKE_PAIR(pr_374, arg1722_478);
										    }
										    arg1720_476 = MAKE_PAIR(arg1716_473, arg1721_477);
										 }
										 list1718_475 = MAKE_PAIR(name_5, arg1720_476);
									      }
									      arg1707_465 = symbol_append_197___r4_symbols_6_4(list1718_475);
									   }
									}
									arg1708_466 = CNST_TABLE_REF(((long) 24));
									arg1709_467 = CNST_TABLE_REF(((long) 27));
									{
									   obj_t list1711_469;
									   {
									      obj_t arg1712_470;
									      {
										 obj_t arg1713_471;
										 arg1713_471 = MAKE_PAIR(BNIL, BNIL);
										 arg1712_470 = MAKE_PAIR(arg1709_467, arg1713_471);
									      }
									      list1711_469 = MAKE_PAIR(arg1708_466, arg1712_470);
									   }
									   arg1700_458 = cons__138___r4_pairs_and_lists_6_3(arg1707_465, list1711_469);
									}
								     }
								     if (CBOOL(_unsafe_struct__195_engine_param))
								       {
									  obj_t arg1724_480;
									  obj_t arg1725_481;
									  obj_t arg1726_482;
									  arg1724_480 = CNST_TABLE_REF(((long) 28));
									  arg1725_481 = CNST_TABLE_REF(((long) 24));
									  arg1726_482 = CNST_TABLE_REF(((long) 27));
									  {
									     obj_t list1728_484;
									     {
										obj_t arg1729_485;
										{
										   obj_t arg1730_486;
										   {
										      obj_t arg1731_487;
										      arg1731_487 = MAKE_PAIR(BNIL, BNIL);
										      arg1730_486 = MAKE_PAIR(arg1726_482, arg1731_487);
										   }
										   {
										      obj_t aux_1152;
										      aux_1152 = BINT(i_367);
										      arg1729_485 = MAKE_PAIR(aux_1152, arg1730_486);
										   }
										}
										list1728_484 = MAKE_PAIR(arg1725_481, arg1729_485);
									     }
									     arg1701_459 = cons__138___r4_pairs_and_lists_6_3(arg1724_480, list1728_484);
									  }
								       }
								     else
								       {
									  obj_t arg1733_489;
									  obj_t arg1738_490;
									  obj_t arg1739_491;
									  obj_t arg1740_492;
									  arg1733_489 = CNST_TABLE_REF(((long) 5));
									  {
									     obj_t arg1749_499;
									     obj_t arg1753_500;
									     obj_t arg1755_501;
									     arg1749_499 = CNST_TABLE_REF(((long) 22));
									     {
										obj_t arg1765_507;
										obj_t arg1766_508;
										arg1765_507 = CNST_TABLE_REF(((long) 23));
										arg1766_508 = CNST_TABLE_REF(((long) 24));
										{
										   obj_t list1768_510;
										   {
										      obj_t arg1769_511;
										      arg1769_511 = MAKE_PAIR(BNIL, BNIL);
										      list1768_510 = MAKE_PAIR(arg1766_508, arg1769_511);
										   }
										   arg1753_500 = cons__138___r4_pairs_and_lists_6_3(arg1765_507, list1768_510);
										}
									     }
									     {
										obj_t arg1771_513;
										arg1771_513 = CNST_TABLE_REF(((long) 11));
										{
										   obj_t list1773_515;
										   {
										      obj_t arg1774_516;
										      arg1774_516 = MAKE_PAIR(BNIL, BNIL);
										      list1773_515 = MAKE_PAIR(name_5, arg1774_516);
										   }
										   arg1755_501 = cons__138___r4_pairs_and_lists_6_3(arg1771_513, list1773_515);
										}
									     }
									     {
										obj_t list1759_503;
										{
										   obj_t arg1760_504;
										   {
										      obj_t arg1761_505;
										      arg1761_505 = MAKE_PAIR(BNIL, BNIL);
										      arg1760_504 = MAKE_PAIR(arg1755_501, arg1761_505);
										   }
										   list1759_503 = MAKE_PAIR(arg1753_500, arg1760_504);
										}
										arg1738_490 = cons__138___r4_pairs_and_lists_6_3(arg1749_499, list1759_503);
									     }
									  }
									  {
									     obj_t arg1777_518;
									     obj_t arg1778_519;
									     obj_t arg1779_520;
									     arg1777_518 = CNST_TABLE_REF(((long) 29));
									     arg1778_519 = CNST_TABLE_REF(((long) 24));
									     arg1779_520 = CNST_TABLE_REF(((long) 27));
									     {
										obj_t list1781_522;
										{
										   obj_t arg1783_523;
										   {
										      obj_t arg1786_524;
										      {
											 obj_t arg1788_525;
											 arg1788_525 = MAKE_PAIR(BNIL, BNIL);
											 arg1786_524 = MAKE_PAIR(arg1779_520, arg1788_525);
										      }
										      {
											 obj_t aux_1177;
											 aux_1177 = BINT(i_367);
											 arg1783_523 = MAKE_PAIR(aux_1177, arg1786_524);
										      }
										   }
										   list1781_522 = MAKE_PAIR(arg1778_519, arg1783_523);
										}
										arg1739_491 = cons__138___r4_pairs_and_lists_6_3(arg1777_518, list1781_522);
									     }
									  }
									  {
									     obj_t arg1790_527;
									     obj_t arg1792_529;
									     obj_t arg1793_530;
									     arg1790_527 = CNST_TABLE_REF(((long) 10));
									     arg1792_529 = SYMBOL_TO_STRING(name_5);
									     arg1793_530 = CNST_TABLE_REF(((long) 24));
									     {
										obj_t list1795_532;
										{
										   obj_t arg1796_533;
										   {
										      obj_t arg1797_534;
										      {
											 obj_t arg1799_535;
											 arg1799_535 = MAKE_PAIR(BNIL, BNIL);
											 arg1797_534 = MAKE_PAIR(arg1793_530, arg1799_535);
										      }
										      arg1796_533 = MAKE_PAIR(arg1792_529, arg1797_534);
										   }
										   list1795_532 = MAKE_PAIR(string1843_expand_struct, arg1796_533);
										}
										arg1740_492 = cons__138___r4_pairs_and_lists_6_3(arg1790_527, list1795_532);
									     }
									  }
									  {
									     obj_t list1744_494;
									     {
										obj_t arg1745_495;
										{
										   obj_t arg1746_496;
										   {
										      obj_t arg1747_497;
										      arg1747_497 = MAKE_PAIR(BNIL, BNIL);
										      arg1746_496 = MAKE_PAIR(arg1740_492, arg1747_497);
										   }
										   arg1745_495 = MAKE_PAIR(arg1739_491, arg1746_496);
										}
										list1744_494 = MAKE_PAIR(arg1738_490, arg1745_495);
									     }
									     arg1701_459 = cons__138___r4_pairs_and_lists_6_3(arg1733_489, list1744_494);
									  }
								       }
								     {
									obj_t list1703_461;
									{
									   obj_t arg1704_462;
									   {
									      obj_t arg1705_463;
									      arg1705_463 = MAKE_PAIR(BNIL, BNIL);
									      arg1704_462 = MAKE_PAIR(arg1701_459, arg1705_463);
									   }
									   list1703_461 = MAKE_PAIR(arg1700_458, arg1704_462);
									}
									arg1698_456 = cons__138___r4_pairs_and_lists_6_3(arg1699_457, list1703_461);
								     }
								  }
								  arg1697_455 = epairify_expand_struct(arg1698_456, x_1);
							       }
							       arg1695_454 = PROCEDURE_ENTRY(e_2) (e_2, arg1697_455, e_2, BEOA);
							    }
							    arg1602_379 = MAKE_PAIR(arg1695_454, res_369);
							 }
							 arg1598_377 = MAKE_PAIR(arg1600_378, arg1602_379);
						      }
						      {
							 obj_t res_1206;
							 obj_t slots_1205;
							 long i_1204;
							 i_1204 = arg1594_375;
							 slots_1205 = arg1595_376;
							 res_1206 = arg1598_377;
							 res_369 = res_1206;
							 slots_368 = slots_1205;
							 i_367 = i_1204;
							 goto loop_370;
						      }
						   }
						}
					   }
					   arg1427_236 = MAKE_PAIR(arg1518_311, arg1519_312);
					}
					arg1032_22 = MAKE_PAIR(arg1426_235, arg1427_236);
				     }
				     arg1020_20 = MAKE_PAIR(arg1025_21, arg1032_22);
				  }
				  return MAKE_PAIR(arg1018_19, arg1020_20);
			       }
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
	      tag_102_241_8:
		FAILURE(BFALSE, string1840_expand_struct, x_1);
	     }
	}
      else
	{
	   goto tag_102_241_8;
	}
   }
}


/* _expand-struct1839 */ obj_t 
_expand_struct1839_225_expand_struct(obj_t env_699, obj_t x_700, obj_t e_701)
{
   return expand_struct_56_expand_struct(x_700, e_701);
}


/* epairify */ obj_t 
epairify_expand_struct(obj_t pair_3, obj_t epair_4)
{
   {
      bool_t test1835_597;
      test1835_597 = EXTENDED_PAIRP(epair_4);
      if (test1835_597)
	{
	   obj_t arg1836_598;
	   obj_t arg1837_599;
	   obj_t arg1838_600;
	   arg1836_598 = CAR(pair_3);
	   arg1837_599 = CDR(pair_3);
	   {
	      bool_t test1137_691;
	      test1137_691 = EXTENDED_PAIRP(epair_4);
	      if (test1137_691)
		{
		   arg1838_600 = CER(epair_4);
		}
	      else
		{
		   FAILURE(string1844_expand_struct, string1845_expand_struct, epair_4);
		}
	   }
	   return MAKE_EXTENDED_PAIR(arg1836_598, arg1837_599, arg1838_600);
	}
      else
	{
	   return pair_3;
	}
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_struct()
{
   return module_initialization_70_engine_param(((long) 0), "EXPAND_STRUCT");
}
