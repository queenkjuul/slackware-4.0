/*===========================================================================*/
/*   (Read/load.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t method_init_76_read_load();
extern obj_t _load_path__54___eval;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t handling_function1138_read_load(obj_t, obj_t);
extern obj_t module_initialization_70_read_load(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
static obj_t _load_module1206_212_read_load(obj_t, obj_t, obj_t);
extern obj_t load_module_134_read_load(obj_t, obj_t);
static obj_t imported_modules_init_94_read_load();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t library_modules_init_112_read_load();
extern obj_t open_input_string(obj_t);
extern obj_t loadq___eval(obj_t);
extern obj_t close_input_port(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114_read_load = BUNSPEC;
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
static obj_t cnst_init_137_read_load();
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(load_module_env_199_read_load, _load_module1206_212_read_load1223, _load_module1206_212_read_load, 0L, 2);
DEFINE_STRING(string1215_read_load, string1215_read_load1224, "MODULE ", 7);
DEFINE_STRING(string1214_read_load, string1214_read_load1225, "Illegal module declaration", 26);
DEFINE_STRING(string1213_read_load, string1213_read_load1226, "conflict in module's name: ", 27);
DEFINE_STRING(string1212_read_load, string1212_read_load1227, " vs ", 4);
DEFINE_STRING(string1211_read_load, string1211_read_load1228, "Can't find file", 15);
DEFINE_STRING(string1209_read_load, string1209_read_load1229, "load-module", 11);
DEFINE_STRING(string1210_read_load, string1210_read_load1230, "Can't open such file", 20);
DEFINE_STRING(string1208_read_load, string1208_read_load1231, "      [reading loaded module ", 29);
DEFINE_STRING(string1207_read_load, string1207_read_load1232, "]", 1);


/* module-initialization */ obj_t 
module_initialization_70_read_load(long checksum_154, char *from_155)
{
   if (CBOOL(require_initialization_114_read_load))
     {
	require_initialization_114_read_load = BBOOL(((bool_t) 0));
	library_modules_init_112_read_load();
	cnst_init_137_read_load();
	imported_modules_init_94_read_load();
	method_init_76_read_load();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_read_load()
{
   module_initialization_70___bexit(((long) 0), "READ_LOAD");
   module_initialization_70___eval(((long) 0), "READ_LOAD");
   module_initialization_70___r4_strings_6_7(((long) 0), "READ_LOAD");
   module_initialization_70___reader(((long) 0), "READ_LOAD");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "READ_LOAD");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_read_load()
{
   {
      obj_t cnst_port_138_146;
      cnst_port_138_146 = open_input_string(string1215_read_load);
      {
	 long i_147;
	 i_147 = ((long) 0);
       loop_148:
	 {
	    bool_t test1216_149;
	    test1216_149 = (i_147 == ((long) -1));
	    if (test1216_149)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1219_150;
		    {
		       obj_t list1220_151;
		       {
			  obj_t arg1221_152;
			  arg1221_152 = BNIL;
			  list1220_151 = MAKE_PAIR(cnst_port_138_146, arg1221_152);
		       }
		       arg1219_150 = read___reader(list1220_151);
		    }
		    CNST_TABLE_SET(i_147, arg1219_150);
		 }
		 {
		    int aux_153;
		    {
		       long aux_174;
		       aux_174 = (i_147 - ((long) 1));
		       aux_153 = (int) (aux_174);
		    }
		    {
		       long i_177;
		       i_177 = (long) (aux_153);
		       i_147 = i_177;
		       goto loop_148;
		    }
		 }
	      }
	 }
      }
   }
}


/* load-module */ obj_t 
load_module_134_read_load(obj_t module_1, obj_t fnames_2)
{
   {
      obj_t list1033_50;
      {
	 obj_t arg1038_52;
	 {
	    obj_t arg1039_53;
	    {
	       obj_t arg1041_55;
	       {
		  obj_t aux_179;
		  aux_179 = BCHAR(((unsigned char) '\n'));
		  arg1041_55 = MAKE_PAIR(aux_179, BNIL);
	       }
	       arg1039_53 = MAKE_PAIR(string1207_read_load, arg1041_55);
	    }
	    arg1038_52 = MAKE_PAIR(module_1, arg1039_53);
	 }
	 list1033_50 = MAKE_PAIR(string1208_read_load, arg1038_52);
      }
      verbose_tools_speek(BINT(((long) 1)), list1033_50);
   }
   {
      obj_t file_57;
      file_57 = CAR(fnames_2);
      {
	 obj_t fname_58;
	 fname_58 = find_file_path_55_tools_file(file_57, _load_path__54___eval);
	 {
	    if (STRINGP(fname_58))
	      {
		 obj_t port_60;
		 port_60 = open_input_file_61___r4_ports_6_10_1(fname_58, BNIL);
		 if (INPUT_PORTP(port_60))
		   {
		      obj_t val1028_62;
		      val1028_62 = handling_function1138_read_load(module_1, port_60);
		      close_input_port(port_60);
		      {
			 bool_t test1068_63;
			 {
			    obj_t aux_196;
			    aux_196 = val_from_exit__100___bexit(val1028_62);
			    test1068_63 = CBOOL(aux_196);
			 }
			 if (test1068_63)
			   {
			      unwind_until__178___bexit(CAR(val1028_62), CDR(val1028_62));
			   }
			 else
			   {
			      val1028_62;
			   }
		      }
		   }
		 else
		   {
		      user_error_151_tools_error(string1209_read_load, string1210_read_load, file_57, BNIL);
		   }
	      }
	    else
	      {
		 user_error_151_tools_error(string1209_read_load, string1211_read_load, fname_58, BNIL);
	      }
	 }
      }
   }
   {
      obj_t l1031_95;
      {
	 bool_t aux_205;
	 l1031_95 = fnames_2;
       lname1032_96:
	 if (PAIRP(l1031_95))
	   {
	      loadq___eval(CAR(l1031_95));
	      {
		 obj_t l1031_210;
		 l1031_210 = CDR(l1031_95);
		 l1031_95 = l1031_210;
		 goto lname1032_96;
	      }
	   }
	 else
	   {
	      aux_205 = ((bool_t) 1);
	   }
	 return BBOOL(aux_205);
      }
   }
}


/* handling_function1138 */ obj_t 
handling_function1138_read_load(obj_t module_145, obj_t port_144)
{
   jmp_buf jmpbuf;
   obj_t an_exit1029_67;
   if (SET_EXIT(an_exit1029_67))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1029_67 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1029_67, ((bool_t) 0));
	   {
	      obj_t val1030_68;
	      {
		 obj_t decl_69;
		 {
		    obj_t list1196_90;
		    list1196_90 = MAKE_PAIR(port_144, BNIL);
		    decl_69 = read___reader(list1196_90);
		 }
		 {
		    bool_t test_218;
		    if (PAIRP(decl_69))
		      {
			 obj_t aux_223;
			 obj_t aux_221;
			 aux_223 = CNST_TABLE_REF(((long) 0));
			 aux_221 = CAR(decl_69);
			 test_218 = (aux_221 == aux_223);
		      }
		    else
		      {
			 test_218 = ((bool_t) 0);
		      }
		    if (test_218)
		      {
			 bool_t test_226;
			 {
			    obj_t aux_227;
			    {
			       obj_t aux_228;
			       aux_228 = CDR(decl_69);
			       aux_227 = CAR(aux_228);
			    }
			    test_226 = (aux_227 == module_145);
			 }
			 if (test_226)
			   {
			      val1030_68 = BUNSPEC;
			   }
			 else
			   {
			      obj_t arg1144_73;
			      {
				 obj_t arg1157_76;
				 obj_t arg1163_78;
				 arg1157_76 = SYMBOL_TO_STRING(module_145);
				 {
				    obj_t aux_233;
				    {
				       obj_t aux_234;
				       aux_234 = CDR(decl_69);
				       aux_233 = CAR(aux_234);
				    }
				    arg1163_78 = SYMBOL_TO_STRING(aux_233);
				 }
				 {
				    obj_t list1164_79;
				    {
				       obj_t arg1175_80;
				       {
					  obj_t arg1176_81;
					  {
					     obj_t arg1187_82;
					     arg1187_82 = MAKE_PAIR(arg1163_78, BNIL);
					     arg1176_81 = MAKE_PAIR(string1212_read_load, arg1187_82);
					  }
					  arg1175_80 = MAKE_PAIR(arg1157_76, arg1176_81);
				       }
				       list1164_79 = MAKE_PAIR(string1213_read_load, arg1175_80);
				    }
				    arg1144_73 = string_append_106___r4_strings_6_7(list1164_79);
				 }
			      }
			      val1030_68 = user_error_151_tools_error(string1209_read_load, arg1144_73, decl_69, BNIL);
			   }
		      }
		    else
		      {
			 val1030_68 = user_error_151_tools_error(string1209_read_load, string1214_read_load, decl_69, BNIL);
		      }
		 }
	      }
	      POP_EXIT();
	      return val1030_68;
	   }
	}
     }
}


/* _load-module1206 */ obj_t 
_load_module1206_212_read_load(obj_t env_141, obj_t module_142, obj_t fnames_143)
{
   return load_module_134_read_load(module_142, fnames_143);
}


/* method-init */ obj_t 
method_init_76_read_load()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_read_load()
{
   module_initialization_70_tools_trace(((long) 0), "READ_LOAD");
   module_initialization_70_tools_error(((long) 0), "READ_LOAD");
   module_initialization_70_tools_speek(((long) 0), "READ_LOAD");
   module_initialization_70_tools_file(((long) 0), "READ_LOAD");
   module_initialization_70_type_type(((long) 0), "READ_LOAD");
   return module_initialization_70_ast_ident(((long) 0), "READ_LOAD");
}
