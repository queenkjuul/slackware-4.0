/*===========================================================================*/
/*   (Inline/app.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;


extern long node_size_119_inline_size(node_t);
static obj_t _inline_app1584_213_inline_app(obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_inline_app();
extern obj_t _optim_unroll_loop___80_engine_param;
extern node_t inline_app_recursive_121_inline_recursion(node_t, long, obj_t);
extern obj_t global_ast_var;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_inline_app(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_inline_walk(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_size(long, char *);
extern obj_t module_initialization_70_inline_simple(long, char *);
extern obj_t module_initialization_70_inline_recursion(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern node_t inline_app_72_inline_app(app_t, long, obj_t);
extern long list_length(obj_t);
extern node_t inline_app_simple_198_inline_simple(node_t, long, obj_t, obj_t);
static obj_t imported_modules_init_94_inline_app();
static obj_t _inline_app_1585_132_inline_app(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_inline_app();
extern obj_t _inlining___224_engine_param;
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern obj_t _non_inlined_calls__201_inline_walk;
extern bool_t is_recursive__125_inline_recursion(variable_t);
extern obj_t isfun_inline_inline;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _optim_loop_inlining___30_engine_param;
extern bool_t inline_app__99_inline_app(variable_t, long, long, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t _inlined_calls__118_inline_walk;
static obj_t require_initialization_114_inline_app = BUNSPEC;
static obj_t cnst_init_137_inline_app();
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(inline_app_env_13_inline_app, _inline_app1584_213_inline_app1594, _inline_app1584_213_inline_app, 0L, 3);
DEFINE_EXPORT_PROCEDURE(inline_app__env_184_inline_app, _inline_app_1585_132_inline_app1595, _inline_app_1585_132_inline_app, 0L, 4);
DEFINE_STRING(string1587_inline_app, string1587_inline_app1596, "IMPORT SNIFUN SIFUN ", 20);
DEFINE_STRING(string1586_inline_app, string1586_inline_app1597, "simple", 6);


/* module-initialization */ obj_t 
module_initialization_70_inline_app(long checksum_1198, char *from_1199)
{
   if (CBOOL(require_initialization_114_inline_app))
     {
	require_initialization_114_inline_app = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_app();
	cnst_init_137_inline_app();
	imported_modules_init_94_inline_app();
	method_init_76_inline_app();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_app()
{
   module_initialization_70___object(((long) 0), "INLINE_APP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_APP");
   module_initialization_70___reader(((long) 0), "INLINE_APP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_app()
{
   {
      obj_t cnst_port_138_1190;
      cnst_port_138_1190 = open_input_string(string1587_inline_app);
      {
	 long i_1191;
	 i_1191 = ((long) 2);
       loop_1192:
	 {
	    bool_t test1588_1193;
	    test1588_1193 = (i_1191 == ((long) -1));
	    if (test1588_1193)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1589_1194;
		    {
		       obj_t list1590_1195;
		       {
			  obj_t arg1592_1196;
			  arg1592_1196 = BNIL;
			  list1590_1195 = MAKE_PAIR(cnst_port_138_1190, arg1592_1196);
		       }
		       arg1589_1194 = read___reader(list1590_1195);
		    }
		    CNST_TABLE_SET(i_1191, arg1589_1194);
		 }
		 {
		    int aux_1197;
		    {
		       long aux_1216;
		       aux_1216 = (i_1191 - ((long) 1));
		       aux_1197 = (int) (aux_1216);
		    }
		    {
		       long i_1219;
		       i_1219 = (long) (aux_1197);
		       i_1191 = i_1219;
		       goto loop_1192;
		    }
		 }
	      }
	 }
      }
   }
}


/* inline-app */ node_t 
inline_app_72_inline_app(app_t node_1, long kfactor_2, obj_t stack_3)
{
   {
      var_t callee_754;
      callee_754 = (((app_t) CREF(node_1))->fun);
      {
	 variable_t var_755;
	 var_755 = (((var_t) CREF(callee_754))->variable);
	 {
	    value_t sfun_756;
	    sfun_756 = (((variable_t) CREF(var_755))->value);
	    {
	       {
		  bool_t test1455_759;
		  test1455_759 = is_a__118___object((obj_t) (sfun_756), sfun_ast_var);
		  if (test1455_759)
		    {
		       bool_t test1456_760;
		       {
			  long aux_1227;
			  {
			     long aux_1228;
			     aux_1228 = list_length((((app_t) CREF(node_1))->args));
			     aux_1227 = (((long) 1) + aux_1228);
			  }
			  test1456_760 = inline_app__99_inline_app(var_755, kfactor_2, aux_1227, stack_3);
		       }
		       if (test1456_760)
			 {
			    {
			       bool_t test_1234;
			       {
				  obj_t aux_1238;
				  obj_t aux_1235;
				  aux_1238 = CNST_TABLE_REF(((long) 0));
				  {
				     sfun_t obj_1135;
				     obj_1135 = (sfun_t) (sfun_756);
				     aux_1235 = (((sfun_t) CREF(obj_1135))->class);
				  }
				  test_1234 = (aux_1235 == aux_1238);
			       }
			       if (test_1234)
				 {
				    BUNSPEC;
				 }
			       else
				 {
				    long z1_1138;
				    z1_1138 = (long) CINT(_inlined_calls__118_inline_walk);
				    {
				       long aux_1242;
				       aux_1242 = (z1_1138 + ((long) 1));
				       _inlined_calls__118_inline_walk = BINT(aux_1242);
				    }
				 }
			    }
			    {
			       bool_t test1461_764;
			       if (CBOOL(_optim_loop_inlining___30_engine_param))
				 {
				    test1461_764 = is_recursive__125_inline_recursion(var_755);
				 }
			       else
				 {
				    test1461_764 = ((bool_t) 0);
				 }
			       if (test1461_764)
				 {
				    return inline_app_recursive_121_inline_recursion((node_t) (node_1), kfactor_2, stack_3);
				 }
			       else
				 {
				    return inline_app_simple_198_inline_simple((node_t) (node_1), kfactor_2, stack_3, string1586_inline_app);
				 }
			    }
			 }
		       else
			 {
			    {
			       long z1_1140;
			       z1_1140 = (long) CINT(_non_inlined_calls__201_inline_walk);
			       {
				  long aux_1254;
				  aux_1254 = (z1_1140 + ((long) 1));
				  _non_inlined_calls__201_inline_walk = BINT(aux_1254);
			       }
			    }
			    return (node_t) (node_1);
			 }
		    }
		  else
		    {
		       return (node_t) (node_1);
		    }
	       }
	    }
	 }
      }
   }
}


/* _inline-app1584 */ obj_t 
_inline_app1584_213_inline_app(obj_t env_1181, obj_t node_1182, obj_t kfactor_1183, obj_t stack_1184)
{
   {
      node_t aux_1259;
      aux_1259 = inline_app_72_inline_app((app_t) (node_1182), (long) CINT(kfactor_1183), stack_1184);
      return (obj_t) (aux_1259);
   }
}


/* inline-app? */ bool_t 
inline_app__99_inline_app(variable_t var_4, long kfactor_5, long call_size_65_6, obj_t stack_7)
{
   {
      value_t sfun_769;
      sfun_769 = (((variable_t) CREF(var_4))->value);
      {
	 obj_t body_770;
	 {
	    bool_t test1487_791;
	    test1487_791 = is_a__118___object((obj_t) (sfun_769), isfun_inline_inline);
	    if (test1487_791)
	      {
		 isfun_t obj_1144;
		 obj_1144 = (isfun_t) (sfun_769);
		 {
		    node_t aux_1269;
		    {
		       obj_t aux_1270;
		       {
			  object_t aux_1271;
			  aux_1271 = (object_t) (obj_1144);
			  aux_1270 = OBJECT_WIDENING(aux_1271);
		       }
		       aux_1269 = (((isfun_t) CREF(aux_1270))->original_body_40);
		    }
		    body_770 = (obj_t) (aux_1269);
		 }
	      }
	    else
	      {
		 sfun_t obj_1145;
		 obj_1145 = (sfun_t) (sfun_769);
		 body_770 = (((sfun_t) CREF(obj_1145))->body);
	      }
	 }
	 {
	    if (CBOOL(_inlining___224_engine_param))
	      {
		 bool_t test1467_771;
		 if (CBOOL(_optim_loop_inlining___30_engine_param))
		   {
		      if (CBOOL(_optim_unroll_loop___80_engine_param))
			{
			   test1467_771 = ((bool_t) 0);
			}
		      else
			{
			   obj_t aux_1284;
			   aux_1284 = memq___r4_pairs_and_lists_6_3((obj_t) (var_4), stack_7);
			   test1467_771 = CBOOL(aux_1284);
			}
		   }
		 else
		   {
		      test1467_771 = ((bool_t) 0);
		   }
		 if (test1467_771)
		   {
		      return ((bool_t) 0);
		   }
		 else
		   {
		      bool_t test_1289;
		      {
			 obj_t aux_1293;
			 obj_t aux_1290;
			 aux_1293 = CNST_TABLE_REF(((long) 1));
			 {
			    sfun_t obj_1146;
			    obj_1146 = (sfun_t) (sfun_769);
			    aux_1290 = (((sfun_t) CREF(obj_1146))->class);
			 }
			 test_1289 = (aux_1290 == aux_1293);
		      }
		      if (test_1289)
			{
			   return ((bool_t) 0);
			}
		      else
			{
			   bool_t test_1296;
			   {
			      bool_t test_1297;
			      {
				 obj_t aux_1301;
				 obj_t aux_1298;
				 aux_1301 = CNST_TABLE_REF(((long) 0));
				 {
				    sfun_t obj_1149;
				    obj_1149 = (sfun_t) (sfun_769);
				    aux_1298 = (((sfun_t) CREF(obj_1149))->class);
				 }
				 test_1297 = (aux_1298 == aux_1301);
			      }
			      if (test_1297)
				{
				   bool_t test_1304;
				   {
				      obj_t aux_1305;
				      aux_1305 = memq___r4_pairs_and_lists_6_3((obj_t) (var_4), stack_7);
				      test_1304 = CBOOL(aux_1305);
				   }
				   if (test_1304)
				     {
					test_1296 = ((bool_t) 0);
				     }
				   else
				     {
					test_1296 = ((bool_t) 1);
				     }
				}
			      else
				{
				   test_1296 = ((bool_t) 0);
				}
			   }
			   if (test_1296)
			     {
				return ((bool_t) 1);
			     }
			   else
			     {
				bool_t test1470_774;
				{
				   bool_t test1478_782;
				   test1478_782 = is_a__118___object((obj_t) (var_4), global_ast_var);
				   if (test1478_782)
				     {
					obj_t aux_1315;
					obj_t aux_1312;
					aux_1315 = CNST_TABLE_REF(((long) 2));
					{
					   global_t obj_1153;
					   obj_1153 = (global_t) (var_4);
					   aux_1312 = (((global_t) CREF(obj_1153))->import);
					}
					test1470_774 = (aux_1312 == aux_1315);
				     }
				   else
				     {
					test1470_774 = ((bool_t) 0);
				     }
				}
				if (test1470_774)
				  {
				     return ((bool_t) 0);
				  }
				else
				  {
				     bool_t test1471_775;
				     {
					long arg1476_780;
					long arg1477_781;
					arg1476_780 = node_size_119_inline_size((node_t) (body_770));
					arg1477_781 = (kfactor_5 * call_size_65_6);
					test1471_775 = (arg1476_780 < arg1477_781);
				     }
				     if (test1471_775)
				       {
					  return ((bool_t) 1);
				       }
				     else
				       {
					  bool_t test1472_776;
					  {
					     bool_t test1473_777;
					     {
						long arg1475_779;
						arg1475_779 = node_size_119_inline_size((node_t) (body_770));
						test1473_777 = (arg1475_779 == call_size_65_6);
					     }
					     if (test1473_777)
					       {
						  bool_t test_1328;
						  {
						     obj_t aux_1329;
						     aux_1329 = memq___r4_pairs_and_lists_6_3((obj_t) (var_4), stack_7);
						     test_1328 = CBOOL(aux_1329);
						  }
						  if (test_1328)
						    {
						       test1472_776 = ((bool_t) 0);
						    }
						  else
						    {
						       test1472_776 = ((bool_t) 1);
						    }
					       }
					     else
					       {
						  test1472_776 = ((bool_t) 0);
					       }
					  }
					  if (test1472_776)
					    {
					       return ((bool_t) 1);
					    }
					  else
					    {
					       return ((bool_t) 0);
					    }
				       }
				  }
			     }
			}
		   }
	      }
	    else
	      {
		 return ((bool_t) 0);
	      }
	 }
      }
   }
}


/* _inline-app?1585 */ obj_t 
_inline_app_1585_132_inline_app(obj_t env_1185, obj_t var_1186, obj_t kfactor_1187, obj_t call_size_65_1188, obj_t stack_1189)
{
   {
      bool_t aux_1334;
      aux_1334 = inline_app__99_inline_app((variable_t) (var_1186), (long) CINT(kfactor_1187), (long) CINT(call_size_65_1188), stack_1189);
      return BBOOL(aux_1334);
   }
}


/* method-init */ obj_t 
method_init_76_inline_app()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_app()
{
   module_initialization_70_tools_trace(((long) 0), "INLINE_APP");
   module_initialization_70_engine_param(((long) 0), "INLINE_APP");
   module_initialization_70_tools_shape(((long) 0), "INLINE_APP");
   module_initialization_70_tools_error(((long) 0), "INLINE_APP");
   module_initialization_70_type_type(((long) 0), "INLINE_APP");
   module_initialization_70_ast_var(((long) 0), "INLINE_APP");
   module_initialization_70_ast_node(((long) 0), "INLINE_APP");
   module_initialization_70_inline_walk(((long) 0), "INLINE_APP");
   module_initialization_70_inline_inline(((long) 0), "INLINE_APP");
   module_initialization_70_inline_size(((long) 0), "INLINE_APP");
   module_initialization_70_inline_simple(((long) 0), "INLINE_APP");
   return module_initialization_70_inline_recursion(((long) 0), "INLINE_APP");
}
