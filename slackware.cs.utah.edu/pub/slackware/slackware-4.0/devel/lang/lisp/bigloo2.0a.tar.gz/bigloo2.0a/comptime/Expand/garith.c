/*===========================================================================*/
/*   (Expand/garith.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t _expand_g__1690_151_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_1688_149_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_1685_139_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_1684_127_expand_garithmetique(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_expand_garithmetique(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
static obj_t _expand_g_1687_20_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t _expand_g_1683_184_expand_garithmetique(obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_garithmetique();
extern obj_t make_real(double);
static obj_t _expand_g_1682_249_expand_garithmetique(obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t expand_g___13_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g___77_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__139_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__108_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__191_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__185_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__29_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__105_expand_garithmetique(obj_t, obj_t);
extern obj_t expand_g__134_expand_garithmetique(obj_t, obj_t);
static obj_t _expand_g_1686_205_expand_garithmetique(obj_t, obj_t, obj_t);
extern bool_t _2___235___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2___241___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__116___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__156___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__79___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__198___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_g__1689_153_expand_garithmetique(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_expand_garithmetique = BUNSPEC;
static obj_t cnst_init_137_expand_garithmetique();
static obj_t __cnst[18];

DEFINE_EXPORT_PROCEDURE(expand_g__env_203_expand_garithmetique, _expand_g_1685_139_expand_garithmetique1703, _expand_g_1685_139_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g__env_199_expand_garithmetique, _expand_g_1684_127_expand_garithmetique1704, _expand_g_1684_127_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g__env_2_expand_garithmetique, _expand_g_1687_20_expand_garithmetique1705, _expand_g_1687_20_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g__env_117_expand_garithmetique, _expand_g_1683_184_expand_garithmetique1706, _expand_g_1683_184_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g__env_166_expand_garithmetique, _expand_g_1682_249_expand_garithmetique1707, _expand_g_1682_249_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g___env_169_expand_garithmetique, _expand_g__1689_153_expand_garithmetique1708, _expand_g__1689_153_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g__env_26_expand_garithmetique, _expand_g_1686_205_expand_garithmetique1709, _expand_g_1686_205_expand_garithmetique, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_g___env_34_expand_garithmetique, _expand_g__1690_151_expand_garithmetique1710, _expand_g__1690_151_expand_garithmetique, 0L, 2);
DEFINE_STRING(string1697_expand_garithmetique, string1697_expand_garithmetique1711, ">= 2>= <= 2<= > 2> < 2< = AND 2= 2/ * 2* 2- - + 2+ ", 51);
DEFINE_STRING(string1696_expand_garithmetique, string1696_expand_garithmetique1712, ">=", 2);
DEFINE_STRING(string1695_expand_garithmetique, string1695_expand_garithmetique1713, "<=", 2);
DEFINE_STRING(string1694_expand_garithmetique, string1694_expand_garithmetique1714, ">", 1);
DEFINE_STRING(string1693_expand_garithmetique, string1693_expand_garithmetique1715, "<", 1);
DEFINE_STRING(string1692_expand_garithmetique, string1692_expand_garithmetique1716, "Illegal form", 12);
DEFINE_STRING(string1691_expand_garithmetique, string1691_expand_garithmetique1717, "=", 1);
DEFINE_EXPORT_PROCEDURE(expand_g__env_116_expand_garithmetique, _expand_g_1688_149_expand_garithmetique1718, _expand_g_1688_149_expand_garithmetique, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_expand_garithmetique(long checksum_902, char *from_903)
{
   if (CBOOL(require_initialization_114_expand_garithmetique))
     {
	require_initialization_114_expand_garithmetique = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_garithmetique();
	cnst_init_137_expand_garithmetique();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_garithmetique()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_GARITHMETIQUE");
   module_initialization_70___r4_numbers_6_5(((long) 0), "EXPAND_GARITHMETIQUE");
   module_initialization_70___reader(((long) 0), "EXPAND_GARITHMETIQUE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_garithmetique()
{
   {
      obj_t cnst_port_138_894;
      cnst_port_138_894 = open_input_string(string1697_expand_garithmetique);
      {
	 long i_895;
	 i_895 = ((long) 17);
       loop_896:
	 {
	    bool_t test1698_897;
	    test1698_897 = (i_895 == ((long) -1));
	    if (test1698_897)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1699_898;
		    {
		       obj_t list1700_899;
		       {
			  obj_t arg1701_900;
			  arg1701_900 = BNIL;
			  list1700_899 = MAKE_PAIR(cnst_port_138_894, arg1701_900);
		       }
		       arg1699_898 = read___reader(list1700_899);
		    }
		    CNST_TABLE_SET(i_895, arg1699_898);
		 }
		 {
		    int aux_901;
		    {
		       long aux_918;
		       aux_918 = (i_895 - ((long) 1));
		       aux_901 = (int) (aux_918);
		    }
		    {
		       long i_921;
		       i_921 = (long) (aux_901);
		       i_895 = i_921;
		       goto loop_896;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-g+ */ obj_t 
expand_g__105_expand_garithmetique(obj_t x_1, obj_t e_2)
{
   {
      obj_t x_25;
      obj_t y_26;
      obj_t x_22;
      obj_t y_23;
      if (PAIRP(x_1))
	{
	   bool_t test_925;
	   {
	      obj_t aux_926;
	      aux_926 = CDR(x_1);
	      test_925 = (aux_926 == BNIL);
	   }
	   if (test_925)
	     {
		return BINT(((long) 0));
	     }
	   else
	     {
		obj_t cdr_114_48_31;
		cdr_114_48_31 = CDR(x_1);
		if (PAIRP(cdr_114_48_31))
		  {
		     bool_t test_933;
		     {
			obj_t aux_934;
			aux_934 = CDR(cdr_114_48_31);
			test_933 = (aux_934 == BNIL);
		     }
		     if (test_933)
		       {
			  return PROCEDURE_ENTRY(e_2) (e_2, CAR(cdr_114_48_31), e_2, BEOA);
		       }
		     else
		       {
			  obj_t cdr_130_105_36;
			  cdr_130_105_36 = CDR(cdr_114_48_31);
			  if (PAIRP(cdr_130_105_36))
			    {
			       bool_t test_943;
			       {
				  obj_t aux_944;
				  aux_944 = CDR(cdr_130_105_36);
				  test_943 = (aux_944 == BNIL);
			       }
			       if (test_943)
				 {
				    x_22 = CAR(cdr_114_48_31);
				    y_23 = CAR(cdr_130_105_36);
				    {
				       bool_t test_947;
				       {
					  bool_t test_948;
					  if (INTEGERP(x_22))
					    {
					       test_948 = ((bool_t) 1);
					    }
					  else
					    {
					       test_948 = REALP(x_22);
					    }
					  if (test_948)
					    {
					       if (INTEGERP(y_23))
						 {
						    test_947 = ((bool_t) 1);
						 }
					       else
						 {
						    test_947 = REALP(y_23);
						 }
					    }
					  else
					    {
					       test_947 = ((bool_t) 0);
					    }
				       }
				       if (test_947)
					 {
					    return _2__168___r4_numbers_6_5(x_22, y_23);
					 }
				       else
					 {
					    {
					       obj_t arg1053_54;
					       {
						  obj_t arg1055_55;
						  arg1055_55 = CNST_TABLE_REF(((long) 0));
						  {
						     obj_t list1057_57;
						     {
							obj_t arg1058_58;
							{
							   obj_t arg1059_59;
							   arg1059_59 = MAKE_PAIR(BNIL, BNIL);
							   arg1058_58 = MAKE_PAIR(y_23, arg1059_59);
							}
							list1057_57 = MAKE_PAIR(x_22, arg1058_58);
						     }
						     arg1053_54 = cons__138___r4_pairs_and_lists_6_3(arg1055_55, list1057_57);
						  }
					       }
					       return PROCEDURE_ENTRY(e_2) (e_2, arg1053_54, e_2, BEOA);
					    }
					 }
				    }
				 }
			       else
				 {
				    x_25 = CAR(cdr_114_48_31);
				    y_26 = CDR(cdr_114_48_31);
				  tag_104_254_27:
				    {
				       obj_t arg1077_62;
				       {
					  obj_t arg1137_63;
					  obj_t arg1142_64;
					  arg1137_63 = CNST_TABLE_REF(((long) 0));
					  {
					     obj_t arg1163_70;
					     obj_t arg1175_71;
					     arg1163_70 = CNST_TABLE_REF(((long) 1));
					     {
						obj_t arg1188_74;
						arg1188_74 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg1175_71 = append_2_18___r4_pairs_and_lists_6_3(y_26, arg1188_74);
					     }
					     {
						obj_t list1176_72;
						list1176_72 = MAKE_PAIR(arg1175_71, BNIL);
						arg1142_64 = cons__138___r4_pairs_and_lists_6_3(arg1163_70, list1176_72);
					     }
					  }
					  {
					     obj_t list1145_66;
					     {
						obj_t arg1150_67;
						{
						   obj_t arg1157_68;
						   arg1157_68 = MAKE_PAIR(BNIL, BNIL);
						   arg1150_67 = MAKE_PAIR(arg1142_64, arg1157_68);
						}
						list1145_66 = MAKE_PAIR(x_25, arg1150_67);
					     }
					     arg1077_62 = cons__138___r4_pairs_and_lists_6_3(arg1137_63, list1145_66);
					  }
				       }
				       return PROCEDURE_ENTRY(e_2) (e_2, arg1077_62, e_2, BEOA);
				    }
				 }
			    }
			  else
			    {
			       obj_t y_981;
			       obj_t x_979;
			       x_979 = CAR(cdr_114_48_31);
			       y_981 = CDR(cdr_114_48_31);
			       y_26 = y_981;
			       x_25 = x_979;
			       goto tag_104_254_27;
			    }
		       }
		  }
		else
		  {
		     return BFALSE;
		  }
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g+1682 */ obj_t 
_expand_g_1682_249_expand_garithmetique(obj_t env_867, obj_t x_868, obj_t e_869)
{
   return expand_g__105_expand_garithmetique(x_868, e_869);
}


/* expand-g- */ obj_t 
expand_g__29_expand_garithmetique(obj_t x_3, obj_t e_4)
{
   {
      obj_t x_82;
      obj_t y_83;
      obj_t x_79;
      obj_t y_80;
      obj_t x_77;
      if (PAIRP(x_3))
	{
	   obj_t cdr_194_69_87;
	   cdr_194_69_87 = CDR(x_3);
	   if (PAIRP(cdr_194_69_87))
	     {
		bool_t test_989;
		{
		   obj_t aux_990;
		   aux_990 = CDR(cdr_194_69_87);
		   test_989 = (aux_990 == BNIL);
		}
		if (test_989)
		  {
		     x_77 = CAR(cdr_194_69_87);
		     {
			bool_t test1210_107;
			test1210_107 = INTEGERP(x_77);
			if (test1210_107)
			  {
			     {
				long aux_995;
				{
				   long aux_996;
				   aux_996 = (long) CINT(x_77);
				   aux_995 = NEG(aux_996);
				}
				return BINT(aux_995);
			     }
			  }
			else
			  {
			     bool_t test_1000;
			     if (test1210_107)
			       {
				  test_1000 = ((bool_t) 1);
			       }
			     else
			       {
				  test_1000 = REALP(x_77);
			       }
			     if (test_1000)
			       {
				  {
				     double aux_1003;
				     {
					double aux_1004;
					aux_1004 = REAL_TO_DOUBLE(x_77);
					aux_1003 = NEG(aux_1004);
				     }
				     return make_real(aux_1003);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1213_109;
				     obj_t arg1214_110;
				     arg1213_109 = CNST_TABLE_REF(((long) 2));
				     arg1214_110 = PROCEDURE_ENTRY(e_4) (e_4, x_77, e_4, BEOA);
				     {
					obj_t list1217_112;
					{
					   obj_t arg1219_113;
					   arg1219_113 = MAKE_PAIR(BNIL, BNIL);
					   list1217_112 = MAKE_PAIR(arg1214_110, arg1219_113);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1213_109, list1217_112);
				     }
				  }
			       }
			  }
		     }
		  }
		else
		  {
		     obj_t cdr_210_15_92;
		     cdr_210_15_92 = CDR(cdr_194_69_87);
		     if (PAIRP(cdr_210_15_92))
		       {
			  bool_t test_1018;
			  {
			     obj_t aux_1019;
			     aux_1019 = CDR(cdr_210_15_92);
			     test_1018 = (aux_1019 == BNIL);
			  }
			  if (test_1018)
			    {
			       x_79 = CAR(cdr_194_69_87);
			       y_80 = CAR(cdr_210_15_92);
			       {
				  bool_t test_1022;
				  {
				     bool_t test_1023;
				     if (INTEGERP(x_79))
				       {
					  test_1023 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1023 = REALP(x_79);
				       }
				     if (test_1023)
				       {
					  if (INTEGERP(y_80))
					    {
					       test_1022 = ((bool_t) 1);
					    }
					  else
					    {
					       test_1022 = REALP(y_80);
					    }
				       }
				     else
				       {
					  test_1022 = ((bool_t) 0);
				       }
				  }
				  if (test_1022)
				    {
				       return _2__79___r4_numbers_6_5(x_79, y_80);
				    }
				  else
				    {
				       {
					  obj_t arg1222_116;
					  {
					     obj_t arg1224_117;
					     arg1224_117 = CNST_TABLE_REF(((long) 3));
					     {
						obj_t list1226_119;
						{
						   obj_t arg1228_120;
						   {
						      obj_t arg1231_121;
						      arg1231_121 = MAKE_PAIR(BNIL, BNIL);
						      arg1228_120 = MAKE_PAIR(y_80, arg1231_121);
						   }
						   list1226_119 = MAKE_PAIR(x_79, arg1228_120);
						}
						arg1222_116 = cons__138___r4_pairs_and_lists_6_3(arg1224_117, list1226_119);
					     }
					  }
					  return PROCEDURE_ENTRY(e_4) (e_4, arg1222_116, e_4, BEOA);
				       }
				    }
			       }
			    }
			  else
			    {
			       x_82 = CAR(cdr_194_69_87);
			       y_83 = CDR(cdr_194_69_87);
			     tag_188_216_84:
			       {
				  obj_t arg1234_124;
				  {
				     obj_t arg1235_125;
				     obj_t arg1236_126;
				     arg1235_125 = CNST_TABLE_REF(((long) 3));
				     {
					obj_t arg1244_132;
					obj_t arg1245_133;
					arg1244_132 = CNST_TABLE_REF(((long) 1));
					{
					   obj_t arg1248_136;
					   arg1248_136 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					   arg1245_133 = append_2_18___r4_pairs_and_lists_6_3(y_83, arg1248_136);
					}
					{
					   obj_t list1246_134;
					   list1246_134 = MAKE_PAIR(arg1245_133, BNIL);
					   arg1236_126 = cons__138___r4_pairs_and_lists_6_3(arg1244_132, list1246_134);
					}
				     }
				     {
					obj_t list1239_128;
					{
					   obj_t arg1240_129;
					   {
					      obj_t arg1241_130;
					      arg1241_130 = MAKE_PAIR(BNIL, BNIL);
					      arg1240_129 = MAKE_PAIR(arg1236_126, arg1241_130);
					   }
					   list1239_128 = MAKE_PAIR(x_82, arg1240_129);
					}
					arg1234_124 = cons__138___r4_pairs_and_lists_6_3(arg1235_125, list1239_128);
				     }
				  }
				  return PROCEDURE_ENTRY(e_4) (e_4, arg1234_124, e_4, BEOA);
			       }
			    }
		       }
		     else
		       {
			  obj_t y_1056;
			  obj_t x_1054;
			  x_1054 = CAR(cdr_194_69_87);
			  y_1056 = CDR(cdr_194_69_87);
			  y_83 = y_1056;
			  x_82 = x_1054;
			  goto tag_188_216_84;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g-1683 */ obj_t 
_expand_g_1683_184_expand_garithmetique(obj_t env_870, obj_t x_871, obj_t e_872)
{
   return expand_g__29_expand_garithmetique(x_871, e_872);
}


/* expand-g* */ obj_t 
expand_g__134_expand_garithmetique(obj_t x_5, obj_t e_6)
{
   {
      obj_t x_145;
      obj_t y_146;
      obj_t x_142;
      obj_t y_143;
      if (PAIRP(x_5))
	{
	   bool_t test_1061;
	   {
	      obj_t aux_1062;
	      aux_1062 = CDR(x_5);
	      test_1061 = (aux_1062 == BNIL);
	   }
	   if (test_1061)
	     {
		return BINT(((long) 1));
	     }
	   else
	     {
		obj_t cdr_276_172_151;
		cdr_276_172_151 = CDR(x_5);
		if (PAIRP(cdr_276_172_151))
		  {
		     bool_t test_1069;
		     {
			obj_t aux_1070;
			aux_1070 = CDR(cdr_276_172_151);
			test_1069 = (aux_1070 == BNIL);
		     }
		     if (test_1069)
		       {
			  return PROCEDURE_ENTRY(e_6) (e_6, CAR(cdr_276_172_151), e_6, BEOA);
		       }
		     else
		       {
			  obj_t cdr_292_5_156;
			  cdr_292_5_156 = CDR(cdr_276_172_151);
			  if (PAIRP(cdr_292_5_156))
			    {
			       bool_t test_1079;
			       {
				  obj_t aux_1080;
				  aux_1080 = CDR(cdr_292_5_156);
				  test_1079 = (aux_1080 == BNIL);
			       }
			       if (test_1079)
				 {
				    x_142 = CAR(cdr_276_172_151);
				    y_143 = CAR(cdr_292_5_156);
				    {
				       bool_t test_1083;
				       {
					  bool_t test_1084;
					  if (INTEGERP(x_142))
					    {
					       test_1084 = ((bool_t) 1);
					    }
					  else
					    {
					       test_1084 = REALP(x_142);
					    }
					  if (test_1084)
					    {
					       if (INTEGERP(y_143))
						 {
						    test_1083 = ((bool_t) 1);
						 }
					       else
						 {
						    test_1083 = REALP(y_143);
						 }
					    }
					  else
					    {
					       test_1083 = ((bool_t) 0);
					    }
				       }
				       if (test_1083)
					 {
					    return _2__198___r4_numbers_6_5(x_142, y_143);
					 }
				       else
					 {
					    {
					       obj_t arg1277_174;
					       {
						  obj_t arg1278_175;
						  arg1278_175 = CNST_TABLE_REF(((long) 4));
						  {
						     obj_t list1282_177;
						     {
							obj_t arg1283_178;
							{
							   obj_t arg1284_179;
							   arg1284_179 = MAKE_PAIR(BNIL, BNIL);
							   arg1283_178 = MAKE_PAIR(y_143, arg1284_179);
							}
							list1282_177 = MAKE_PAIR(x_142, arg1283_178);
						     }
						     arg1277_174 = cons__138___r4_pairs_and_lists_6_3(arg1278_175, list1282_177);
						  }
					       }
					       return PROCEDURE_ENTRY(e_6) (e_6, arg1277_174, e_6, BEOA);
					    }
					 }
				    }
				 }
			       else
				 {
				    x_145 = CAR(cdr_276_172_151);
				    y_146 = CDR(cdr_276_172_151);
				  tag_266_56_147:
				    {
				       obj_t arg1287_182;
				       {
					  obj_t arg1288_183;
					  obj_t arg1290_184;
					  arg1288_183 = CNST_TABLE_REF(((long) 4));
					  {
					     obj_t arg1297_190;
					     obj_t arg1298_191;
					     arg1297_190 = CNST_TABLE_REF(((long) 5));
					     {
						obj_t arg1301_194;
						arg1301_194 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg1298_191 = append_2_18___r4_pairs_and_lists_6_3(y_146, arg1301_194);
					     }
					     {
						obj_t list1299_192;
						list1299_192 = MAKE_PAIR(arg1298_191, BNIL);
						arg1290_184 = cons__138___r4_pairs_and_lists_6_3(arg1297_190, list1299_192);
					     }
					  }
					  {
					     obj_t list1292_186;
					     {
						obj_t arg1294_187;
						{
						   obj_t arg1295_188;
						   arg1295_188 = MAKE_PAIR(BNIL, BNIL);
						   arg1294_187 = MAKE_PAIR(arg1290_184, arg1295_188);
						}
						list1292_186 = MAKE_PAIR(x_145, arg1294_187);
					     }
					     arg1287_182 = cons__138___r4_pairs_and_lists_6_3(arg1288_183, list1292_186);
					  }
				       }
				       return PROCEDURE_ENTRY(e_6) (e_6, arg1287_182, e_6, BEOA);
				    }
				 }
			    }
			  else
			    {
			       obj_t y_1117;
			       obj_t x_1115;
			       x_1115 = CAR(cdr_276_172_151);
			       y_1117 = CDR(cdr_276_172_151);
			       y_146 = y_1117;
			       x_145 = x_1115;
			       goto tag_266_56_147;
			    }
		       }
		  }
		else
		  {
		     return BFALSE;
		  }
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g*1684 */ obj_t 
_expand_g_1684_127_expand_garithmetique(obj_t env_873, obj_t x_874, obj_t e_875)
{
   return expand_g__134_expand_garithmetique(x_874, e_875);
}


/* expand-g/ */ obj_t 
expand_g__185_expand_garithmetique(obj_t x_7, obj_t e_8)
{
   {
      obj_t x_202;
      obj_t y_203;
      obj_t x_199;
      obj_t y_200;
      obj_t x_197;
      if (PAIRP(x_7))
	{
	   obj_t cdr_356_4_207;
	   cdr_356_4_207 = CDR(x_7);
	   if (PAIRP(cdr_356_4_207))
	     {
		bool_t test_1125;
		{
		   obj_t aux_1126;
		   aux_1126 = CDR(cdr_356_4_207);
		   test_1125 = (aux_1126 == BNIL);
		}
		if (test_1125)
		  {
		     x_197 = CAR(cdr_356_4_207);
		     {
			obj_t arg1325_227;
			obj_t arg1328_229;
			arg1325_227 = CNST_TABLE_REF(((long) 6));
			arg1328_229 = PROCEDURE_ENTRY(e_8) (e_8, x_197, e_8, BEOA);
			{
			   obj_t list1331_231;
			   {
			      obj_t arg1332_232;
			      {
				 obj_t arg1333_233;
				 arg1333_233 = MAKE_PAIR(BNIL, BNIL);
				 arg1332_232 = MAKE_PAIR(arg1328_229, arg1333_233);
			      }
			      {
				 obj_t aux_1134;
				 aux_1134 = BINT(((long) 1));
				 list1331_231 = MAKE_PAIR(aux_1134, arg1332_232);
			      }
			   }
			   return cons__138___r4_pairs_and_lists_6_3(arg1325_227, list1331_231);
			}
		     }
		  }
		else
		  {
		     obj_t cdr_372_212_212;
		     cdr_372_212_212 = CDR(cdr_356_4_207);
		     if (PAIRP(cdr_372_212_212))
		       {
			  bool_t test_1142;
			  {
			     obj_t aux_1143;
			     aux_1143 = CDR(cdr_372_212_212);
			     test_1142 = (aux_1143 == BNIL);
			  }
			  if (test_1142)
			    {
			       x_199 = CAR(cdr_356_4_207);
			       y_200 = CAR(cdr_372_212_212);
			       {
				  bool_t test_1146;
				  {
				     bool_t test_1147;
				     if (INTEGERP(x_199))
				       {
					  test_1147 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1147 = REALP(x_199);
				       }
				     if (test_1147)
				       {
					  if (INTEGERP(y_200))
					    {
					       test_1146 = ((bool_t) 1);
					    }
					  else
					    {
					       test_1146 = REALP(y_200);
					    }
				       }
				     else
				       {
					  test_1146 = ((bool_t) 0);
				       }
				  }
				  if (test_1146)
				    {
				       return _2__156___r4_numbers_6_5(x_199, y_200);
				    }
				  else
				    {
				       {
					  obj_t arg1337_236;
					  {
					     obj_t arg1339_237;
					     arg1339_237 = CNST_TABLE_REF(((long) 6));
					     {
						obj_t list1341_239;
						{
						   obj_t arg1342_240;
						   {
						      obj_t arg1343_241;
						      arg1343_241 = MAKE_PAIR(BNIL, BNIL);
						      arg1342_240 = MAKE_PAIR(y_200, arg1343_241);
						   }
						   list1341_239 = MAKE_PAIR(x_199, arg1342_240);
						}
						arg1337_236 = cons__138___r4_pairs_and_lists_6_3(arg1339_237, list1341_239);
					     }
					  }
					  return PROCEDURE_ENTRY(e_8) (e_8, arg1337_236, e_8, BEOA);
				       }
				    }
			       }
			    }
			  else
			    {
			       x_202 = CAR(cdr_356_4_207);
			       y_203 = CDR(cdr_356_4_207);
			     tag_350_155_204:
			       {
				  obj_t arg1347_244;
				  {
				     obj_t arg1349_245;
				     obj_t arg1350_246;
				     arg1349_245 = CNST_TABLE_REF(((long) 6));
				     {
					obj_t arg1357_252;
					obj_t arg1361_253;
					arg1357_252 = CNST_TABLE_REF(((long) 5));
					{
					   obj_t arg1364_256;
					   arg1364_256 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					   arg1361_253 = append_2_18___r4_pairs_and_lists_6_3(y_203, arg1364_256);
					}
					{
					   obj_t list1362_254;
					   list1362_254 = MAKE_PAIR(arg1361_253, BNIL);
					   arg1350_246 = cons__138___r4_pairs_and_lists_6_3(arg1357_252, list1362_254);
					}
				     }
				     {
					obj_t list1352_248;
					{
					   obj_t arg1353_249;
					   {
					      obj_t arg1355_250;
					      arg1355_250 = MAKE_PAIR(BNIL, BNIL);
					      arg1353_249 = MAKE_PAIR(arg1350_246, arg1355_250);
					   }
					   list1352_248 = MAKE_PAIR(x_202, arg1353_249);
					}
					arg1347_244 = cons__138___r4_pairs_and_lists_6_3(arg1349_245, list1352_248);
				     }
				  }
				  return PROCEDURE_ENTRY(e_8) (e_8, arg1347_244, e_8, BEOA);
			       }
			    }
		       }
		     else
		       {
			  obj_t y_1180;
			  obj_t x_1178;
			  x_1178 = CAR(cdr_356_4_207);
			  y_1180 = CDR(cdr_356_4_207);
			  y_203 = y_1180;
			  x_202 = x_1178;
			  goto tag_350_155_204;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g/1685 */ obj_t 
_expand_g_1685_139_expand_garithmetique(obj_t env_876, obj_t x_877, obj_t e_878)
{
   return expand_g__185_expand_garithmetique(x_877, e_878);
}


/* expand-g= */ obj_t 
expand_g__108_expand_garithmetique(obj_t x_9, obj_t e_10)
{
   {
      obj_t x_263;
      obj_t y_264;
      obj_t x_259;
      obj_t y_260;
      if (PAIRP(x_9))
	{
	   obj_t cdr_434_33_268;
	   cdr_434_33_268 = CDR(x_9);
	   if (PAIRP(cdr_434_33_268))
	     {
		obj_t cdr_438_80_270;
		cdr_438_80_270 = CDR(cdr_434_33_268);
		if (PAIRP(cdr_438_80_270))
		  {
		     bool_t test_1191;
		     {
			obj_t aux_1192;
			aux_1192 = CDR(cdr_438_80_270);
			test_1191 = (aux_1192 == BNIL);
		     }
		     if (test_1191)
		       {
			  x_259 = CAR(cdr_434_33_268);
			  y_260 = CAR(cdr_438_80_270);
			  {
			     bool_t test_1195;
			     {
				bool_t test_1196;
				if (INTEGERP(x_259))
				  {
				     test_1196 = ((bool_t) 1);
				  }
				else
				  {
				     test_1196 = REALP(x_259);
				  }
				if (test_1196)
				  {
				     if (INTEGERP(y_260))
				       {
					  test_1195 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1195 = REALP(y_260);
				       }
				  }
				else
				  {
				     test_1195 = ((bool_t) 0);
				  }
			     }
			     if (test_1195)
			       {
				  {
				     bool_t aux_1203;
				     aux_1203 = _2__95___r4_numbers_6_5(x_259, y_260);
				     return BBOOL(aux_1203);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1390_288;
				     {
					obj_t arg1391_289;
					arg1391_289 = CNST_TABLE_REF(((long) 7));
					{
					   obj_t list1393_291;
					   {
					      obj_t arg1395_292;
					      {
						 obj_t arg1396_293;
						 arg1396_293 = MAKE_PAIR(BNIL, BNIL);
						 arg1395_292 = MAKE_PAIR(y_260, arg1396_293);
					      }
					      list1393_291 = MAKE_PAIR(x_259, arg1395_292);
					   }
					   arg1390_288 = cons__138___r4_pairs_and_lists_6_3(arg1391_289, list1393_291);
					}
				     }
				     return PROCEDURE_ENTRY(e_10) (e_10, arg1390_288, e_10, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_263 = CAR(cdr_434_33_268);
			  y_264 = CDR(cdr_434_33_268);
			tag_427_208_265:
			  {
			     obj_t arg1399_296;
			     {
				obj_t arg1401_297;
				obj_t arg1402_298;
				obj_t arg1403_299;
				arg1401_297 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1411_305;
				   obj_t arg1413_306;
				   arg1411_305 = CNST_TABLE_REF(((long) 7));
				   arg1413_306 = CAR(y_264);
				   {
				      obj_t list1415_308;
				      {
					 obj_t arg1416_309;
					 {
					    obj_t arg1417_310;
					    arg1417_310 = MAKE_PAIR(BNIL, BNIL);
					    arg1416_309 = MAKE_PAIR(arg1413_306, arg1417_310);
					 }
					 list1415_308 = MAKE_PAIR(x_263, arg1416_309);
				      }
				      arg1402_298 = cons__138___r4_pairs_and_lists_6_3(arg1411_305, list1415_308);
				   }
				}
				{
				   obj_t arg1419_312;
				   obj_t arg1421_313;
				   arg1419_312 = CNST_TABLE_REF(((long) 9));
				   {
				      obj_t arg1426_316;
				      arg1426_316 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1421_313 = append_2_18___r4_pairs_and_lists_6_3(y_264, arg1426_316);
				   }
				   {
				      obj_t list1422_314;
				      list1422_314 = MAKE_PAIR(arg1421_313, BNIL);
				      arg1403_299 = cons__138___r4_pairs_and_lists_6_3(arg1419_312, list1422_314);
				   }
				}
				{
				   obj_t list1406_301;
				   {
				      obj_t arg1407_302;
				      {
					 obj_t arg1408_303;
					 arg1408_303 = MAKE_PAIR(BNIL, BNIL);
					 arg1407_302 = MAKE_PAIR(arg1403_299, arg1408_303);
				      }
				      list1406_301 = MAKE_PAIR(arg1402_298, arg1407_302);
				   }
				   arg1399_296 = cons__138___r4_pairs_and_lists_6_3(arg1401_297, list1406_301);
				}
			     }
			     return PROCEDURE_ENTRY(e_10) (e_10, arg1399_296, e_10, BEOA);
			  }
		       }
		  }
		else
		  {
		     bool_t test_1235;
		     {
			obj_t aux_1236;
			aux_1236 = CDR(cdr_434_33_268);
			test_1235 = (aux_1236 == BNIL);
		     }
		     if (test_1235)
		       {
			  FAILURE(string1691_expand_garithmetique, string1692_expand_garithmetique, x_9);
		       }
		     else
		       {
			  obj_t y_1242;
			  obj_t x_1240;
			  x_1240 = CAR(cdr_434_33_268);
			  y_1242 = CDR(cdr_434_33_268);
			  y_264 = y_1242;
			  x_263 = x_1240;
			  goto tag_427_208_265;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g=1686 */ obj_t 
_expand_g_1686_205_expand_garithmetique(obj_t env_879, obj_t x_880, obj_t e_881)
{
   return expand_g__108_expand_garithmetique(x_880, e_881);
}


/* expand-g< */ obj_t 
expand_g__191_expand_garithmetique(obj_t x_11, obj_t e_12)
{
   {
      obj_t x_323;
      obj_t y_324;
      obj_t x_319;
      obj_t y_320;
      if (PAIRP(x_11))
	{
	   obj_t cdr_503_210_328;
	   cdr_503_210_328 = CDR(x_11);
	   if (PAIRP(cdr_503_210_328))
	     {
		obj_t cdr_507_15_330;
		cdr_507_15_330 = CDR(cdr_503_210_328);
		if (PAIRP(cdr_507_15_330))
		  {
		     bool_t test_1253;
		     {
			obj_t aux_1254;
			aux_1254 = CDR(cdr_507_15_330);
			test_1253 = (aux_1254 == BNIL);
		     }
		     if (test_1253)
		       {
			  x_319 = CAR(cdr_503_210_328);
			  y_320 = CAR(cdr_507_15_330);
			  {
			     bool_t test_1257;
			     {
				bool_t test_1258;
				if (INTEGERP(x_319))
				  {
				     test_1258 = ((bool_t) 1);
				  }
				else
				  {
				     test_1258 = REALP(x_319);
				  }
				if (test_1258)
				  {
				     if (INTEGERP(y_320))
				       {
					  test_1257 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1257 = REALP(y_320);
				       }
				  }
				else
				  {
				     test_1257 = ((bool_t) 0);
				  }
			     }
			     if (test_1257)
			       {
				  {
				     bool_t aux_1265;
				     aux_1265 = _2__116___r4_numbers_6_5(x_319, y_320);
				     return BBOOL(aux_1265);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1453_348;
				     {
					obj_t arg1454_349;
					arg1454_349 = CNST_TABLE_REF(((long) 10));
					{
					   obj_t list1456_351;
					   {
					      obj_t arg1458_352;
					      {
						 obj_t arg1460_353;
						 arg1460_353 = MAKE_PAIR(BNIL, BNIL);
						 arg1458_352 = MAKE_PAIR(y_320, arg1460_353);
					      }
					      list1456_351 = MAKE_PAIR(x_319, arg1458_352);
					   }
					   arg1453_348 = cons__138___r4_pairs_and_lists_6_3(arg1454_349, list1456_351);
					}
				     }
				     return PROCEDURE_ENTRY(e_12) (e_12, arg1453_348, e_12, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_323 = CAR(cdr_503_210_328);
			  y_324 = CDR(cdr_503_210_328);
			tag_496_7_325:
			  {
			     obj_t arg1463_356;
			     {
				obj_t arg1464_357;
				obj_t arg1465_358;
				obj_t arg1466_359;
				arg1464_357 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1473_365;
				   obj_t arg1474_366;
				   arg1473_365 = CNST_TABLE_REF(((long) 10));
				   arg1474_366 = CAR(y_324);
				   {
				      obj_t list1476_368;
				      {
					 obj_t arg1477_369;
					 {
					    obj_t arg1478_370;
					    arg1478_370 = MAKE_PAIR(BNIL, BNIL);
					    arg1477_369 = MAKE_PAIR(arg1474_366, arg1478_370);
					 }
					 list1476_368 = MAKE_PAIR(x_323, arg1477_369);
				      }
				      arg1465_358 = cons__138___r4_pairs_and_lists_6_3(arg1473_365, list1476_368);
				   }
				}
				{
				   obj_t arg1480_372;
				   obj_t arg1481_373;
				   arg1480_372 = CNST_TABLE_REF(((long) 11));
				   {
				      obj_t arg1484_376;
				      arg1484_376 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1481_373 = append_2_18___r4_pairs_and_lists_6_3(y_324, arg1484_376);
				   }
				   {
				      obj_t list1482_374;
				      list1482_374 = MAKE_PAIR(arg1481_373, BNIL);
				      arg1466_359 = cons__138___r4_pairs_and_lists_6_3(arg1480_372, list1482_374);
				   }
				}
				{
				   obj_t list1468_361;
				   {
				      obj_t arg1469_362;
				      {
					 obj_t arg1470_363;
					 arg1470_363 = MAKE_PAIR(BNIL, BNIL);
					 arg1469_362 = MAKE_PAIR(arg1466_359, arg1470_363);
				      }
				      list1468_361 = MAKE_PAIR(arg1465_358, arg1469_362);
				   }
				   arg1463_356 = cons__138___r4_pairs_and_lists_6_3(arg1464_357, list1468_361);
				}
			     }
			     return PROCEDURE_ENTRY(e_12) (e_12, arg1463_356, e_12, BEOA);
			  }
		       }
		  }
		else
		  {
		     bool_t test_1297;
		     {
			obj_t aux_1298;
			aux_1298 = CDR(cdr_503_210_328);
			test_1297 = (aux_1298 == BNIL);
		     }
		     if (test_1297)
		       {
			  FAILURE(string1693_expand_garithmetique, string1692_expand_garithmetique, x_11);
		       }
		     else
		       {
			  obj_t y_1304;
			  obj_t x_1302;
			  x_1302 = CAR(cdr_503_210_328);
			  y_1304 = CDR(cdr_503_210_328);
			  y_324 = y_1304;
			  x_323 = x_1302;
			  goto tag_496_7_325;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g<1687 */ obj_t 
_expand_g_1687_20_expand_garithmetique(obj_t env_882, obj_t x_883, obj_t e_884)
{
   return expand_g__191_expand_garithmetique(x_883, e_884);
}


/* expand-g> */ obj_t 
expand_g__139_expand_garithmetique(obj_t x_13, obj_t e_14)
{
   {
      obj_t x_383;
      obj_t y_384;
      obj_t x_379;
      obj_t y_380;
      if (PAIRP(x_13))
	{
	   obj_t cdr_572_199_388;
	   cdr_572_199_388 = CDR(x_13);
	   if (PAIRP(cdr_572_199_388))
	     {
		obj_t cdr_576_84_390;
		cdr_576_84_390 = CDR(cdr_572_199_388);
		if (PAIRP(cdr_576_84_390))
		  {
		     bool_t test_1315;
		     {
			obj_t aux_1316;
			aux_1316 = CDR(cdr_576_84_390);
			test_1315 = (aux_1316 == BNIL);
		     }
		     if (test_1315)
		       {
			  x_379 = CAR(cdr_572_199_388);
			  y_380 = CAR(cdr_576_84_390);
			  {
			     bool_t test_1319;
			     {
				bool_t test_1320;
				if (INTEGERP(x_379))
				  {
				     test_1320 = ((bool_t) 1);
				  }
				else
				  {
				     test_1320 = REALP(x_379);
				  }
				if (test_1320)
				  {
				     if (INTEGERP(y_380))
				       {
					  test_1319 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1319 = REALP(y_380);
				       }
				  }
				else
				  {
				     test_1319 = ((bool_t) 0);
				  }
			     }
			     if (test_1319)
			       {
				  {
				     bool_t aux_1327;
				     aux_1327 = _2__206___r4_numbers_6_5(x_379, y_380);
				     return BBOOL(aux_1327);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1507_408;
				     {
					obj_t arg1510_409;
					arg1510_409 = CNST_TABLE_REF(((long) 12));
					{
					   obj_t list1512_411;
					   {
					      obj_t arg1513_412;
					      {
						 obj_t arg1514_413;
						 arg1514_413 = MAKE_PAIR(BNIL, BNIL);
						 arg1513_412 = MAKE_PAIR(y_380, arg1514_413);
					      }
					      list1512_411 = MAKE_PAIR(x_379, arg1513_412);
					   }
					   arg1507_408 = cons__138___r4_pairs_and_lists_6_3(arg1510_409, list1512_411);
					}
				     }
				     return PROCEDURE_ENTRY(e_14) (e_14, arg1507_408, e_14, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_383 = CAR(cdr_572_199_388);
			  y_384 = CDR(cdr_572_199_388);
			tag_565_106_385:
			  {
			     obj_t arg1517_416;
			     {
				obj_t arg1518_417;
				obj_t arg1519_418;
				obj_t arg1522_419;
				arg1518_417 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1529_425;
				   obj_t arg1530_426;
				   arg1529_425 = CNST_TABLE_REF(((long) 12));
				   arg1530_426 = CAR(y_384);
				   {
				      obj_t list1532_428;
				      {
					 obj_t arg1533_429;
					 {
					    obj_t arg1534_430;
					    arg1534_430 = MAKE_PAIR(BNIL, BNIL);
					    arg1533_429 = MAKE_PAIR(arg1530_426, arg1534_430);
					 }
					 list1532_428 = MAKE_PAIR(x_383, arg1533_429);
				      }
				      arg1519_418 = cons__138___r4_pairs_and_lists_6_3(arg1529_425, list1532_428);
				   }
				}
				{
				   obj_t arg1536_432;
				   obj_t arg1537_433;
				   arg1536_432 = CNST_TABLE_REF(((long) 13));
				   {
				      obj_t arg1540_436;
				      arg1540_436 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1537_433 = append_2_18___r4_pairs_and_lists_6_3(y_384, arg1540_436);
				   }
				   {
				      obj_t list1538_434;
				      list1538_434 = MAKE_PAIR(arg1537_433, BNIL);
				      arg1522_419 = cons__138___r4_pairs_and_lists_6_3(arg1536_432, list1538_434);
				   }
				}
				{
				   obj_t list1525_421;
				   {
				      obj_t arg1526_422;
				      {
					 obj_t arg1527_423;
					 arg1527_423 = MAKE_PAIR(BNIL, BNIL);
					 arg1526_422 = MAKE_PAIR(arg1522_419, arg1527_423);
				      }
				      list1525_421 = MAKE_PAIR(arg1519_418, arg1526_422);
				   }
				   arg1517_416 = cons__138___r4_pairs_and_lists_6_3(arg1518_417, list1525_421);
				}
			     }
			     return PROCEDURE_ENTRY(e_14) (e_14, arg1517_416, e_14, BEOA);
			  }
		       }
		  }
		else
		  {
		     bool_t test_1359;
		     {
			obj_t aux_1360;
			aux_1360 = CDR(cdr_572_199_388);
			test_1359 = (aux_1360 == BNIL);
		     }
		     if (test_1359)
		       {
			  FAILURE(string1694_expand_garithmetique, string1692_expand_garithmetique, x_13);
		       }
		     else
		       {
			  obj_t y_1366;
			  obj_t x_1364;
			  x_1364 = CAR(cdr_572_199_388);
			  y_1366 = CDR(cdr_572_199_388);
			  y_384 = y_1366;
			  x_383 = x_1364;
			  goto tag_565_106_385;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g>1688 */ obj_t 
_expand_g_1688_149_expand_garithmetique(obj_t env_885, obj_t x_886, obj_t e_887)
{
   return expand_g__139_expand_garithmetique(x_886, e_887);
}


/* expand-g<= */ obj_t 
expand_g___77_expand_garithmetique(obj_t x_15, obj_t e_16)
{
   {
      obj_t x_443;
      obj_t y_444;
      obj_t x_439;
      obj_t y_440;
      if (PAIRP(x_15))
	{
	   obj_t cdr_641_222_448;
	   cdr_641_222_448 = CDR(x_15);
	   if (PAIRP(cdr_641_222_448))
	     {
		obj_t cdr_645_219_450;
		cdr_645_219_450 = CDR(cdr_641_222_448);
		if (PAIRP(cdr_645_219_450))
		  {
		     bool_t test_1377;
		     {
			obj_t aux_1378;
			aux_1378 = CDR(cdr_645_219_450);
			test_1377 = (aux_1378 == BNIL);
		     }
		     if (test_1377)
		       {
			  x_439 = CAR(cdr_641_222_448);
			  y_440 = CAR(cdr_645_219_450);
			  {
			     bool_t test_1381;
			     {
				bool_t test_1382;
				if (INTEGERP(x_439))
				  {
				     test_1382 = ((bool_t) 1);
				  }
				else
				  {
				     test_1382 = REALP(x_439);
				  }
				if (test_1382)
				  {
				     if (INTEGERP(y_440))
				       {
					  test_1381 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1381 = REALP(y_440);
				       }
				  }
				else
				  {
				     test_1381 = ((bool_t) 0);
				  }
			     }
			     if (test_1381)
			       {
				  {
				     bool_t aux_1389;
				     aux_1389 = _2___241___r4_numbers_6_5(x_439, y_440);
				     return BBOOL(aux_1389);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1562_468;
				     {
					obj_t arg1563_469;
					arg1563_469 = CNST_TABLE_REF(((long) 14));
					{
					   obj_t list1565_471;
					   {
					      obj_t arg1566_472;
					      {
						 obj_t arg1568_473;
						 arg1568_473 = MAKE_PAIR(BNIL, BNIL);
						 arg1566_472 = MAKE_PAIR(y_440, arg1568_473);
					      }
					      list1565_471 = MAKE_PAIR(x_439, arg1566_472);
					   }
					   arg1562_468 = cons__138___r4_pairs_and_lists_6_3(arg1563_469, list1565_471);
					}
				     }
				     return PROCEDURE_ENTRY(e_16) (e_16, arg1562_468, e_16, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_443 = CAR(cdr_641_222_448);
			  y_444 = CDR(cdr_641_222_448);
			tag_634_174_445:
			  {
			     obj_t arg1572_476;
			     {
				obj_t arg1573_477;
				obj_t arg1575_478;
				obj_t arg1578_479;
				arg1573_477 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1585_485;
				   obj_t arg1586_486;
				   arg1585_485 = CNST_TABLE_REF(((long) 14));
				   arg1586_486 = CAR(y_444);
				   {
				      obj_t list1588_488;
				      {
					 obj_t arg1589_489;
					 {
					    obj_t arg1592_490;
					    arg1592_490 = MAKE_PAIR(BNIL, BNIL);
					    arg1589_489 = MAKE_PAIR(arg1586_486, arg1592_490);
					 }
					 list1588_488 = MAKE_PAIR(x_443, arg1589_489);
				      }
				      arg1575_478 = cons__138___r4_pairs_and_lists_6_3(arg1585_485, list1588_488);
				   }
				}
				{
				   obj_t arg1594_492;
				   obj_t arg1595_493;
				   arg1594_492 = CNST_TABLE_REF(((long) 15));
				   {
				      obj_t arg1600_496;
				      arg1600_496 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1595_493 = append_2_18___r4_pairs_and_lists_6_3(y_444, arg1600_496);
				   }
				   {
				      obj_t list1596_494;
				      list1596_494 = MAKE_PAIR(arg1595_493, BNIL);
				      arg1578_479 = cons__138___r4_pairs_and_lists_6_3(arg1594_492, list1596_494);
				   }
				}
				{
				   obj_t list1581_481;
				   {
				      obj_t arg1582_482;
				      {
					 obj_t arg1583_483;
					 arg1583_483 = MAKE_PAIR(BNIL, BNIL);
					 arg1582_482 = MAKE_PAIR(arg1578_479, arg1583_483);
				      }
				      list1581_481 = MAKE_PAIR(arg1575_478, arg1582_482);
				   }
				   arg1572_476 = cons__138___r4_pairs_and_lists_6_3(arg1573_477, list1581_481);
				}
			     }
			     return PROCEDURE_ENTRY(e_16) (e_16, arg1572_476, e_16, BEOA);
			  }
		       }
		  }
		else
		  {
		     bool_t test_1421;
		     {
			obj_t aux_1422;
			aux_1422 = CDR(cdr_641_222_448);
			test_1421 = (aux_1422 == BNIL);
		     }
		     if (test_1421)
		       {
			  FAILURE(string1695_expand_garithmetique, string1692_expand_garithmetique, x_15);
		       }
		     else
		       {
			  obj_t y_1428;
			  obj_t x_1426;
			  x_1426 = CAR(cdr_641_222_448);
			  y_1428 = CDR(cdr_641_222_448);
			  y_444 = y_1428;
			  x_443 = x_1426;
			  goto tag_634_174_445;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g<=1689 */ obj_t 
_expand_g__1689_153_expand_garithmetique(obj_t env_888, obj_t x_889, obj_t e_890)
{
   return expand_g___77_expand_garithmetique(x_889, e_890);
}


/* expand-g>= */ obj_t 
expand_g___13_expand_garithmetique(obj_t x_17, obj_t e_18)
{
   {
      obj_t x_503;
      obj_t y_504;
      obj_t x_499;
      obj_t y_500;
      if (PAIRP(x_17))
	{
	   obj_t cdr_710_59_508;
	   cdr_710_59_508 = CDR(x_17);
	   if (PAIRP(cdr_710_59_508))
	     {
		obj_t cdr_714_191_510;
		cdr_714_191_510 = CDR(cdr_710_59_508);
		if (PAIRP(cdr_714_191_510))
		  {
		     bool_t test_1439;
		     {
			obj_t aux_1440;
			aux_1440 = CDR(cdr_714_191_510);
			test_1439 = (aux_1440 == BNIL);
		     }
		     if (test_1439)
		       {
			  x_499 = CAR(cdr_710_59_508);
			  y_500 = CAR(cdr_714_191_510);
			  {
			     bool_t test_1443;
			     {
				bool_t test_1444;
				if (INTEGERP(x_499))
				  {
				     test_1444 = ((bool_t) 1);
				  }
				else
				  {
				     test_1444 = REALP(x_499);
				  }
				if (test_1444)
				  {
				     if (INTEGERP(y_500))
				       {
					  test_1443 = ((bool_t) 1);
				       }
				     else
				       {
					  test_1443 = REALP(y_500);
				       }
				  }
				else
				  {
				     test_1443 = ((bool_t) 0);
				  }
			     }
			     if (test_1443)
			       {
				  {
				     bool_t aux_1451;
				     aux_1451 = _2___235___r4_numbers_6_5(x_499, y_500);
				     return BBOOL(aux_1451);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1624_528;
				     {
					obj_t arg1625_529;
					arg1625_529 = CNST_TABLE_REF(((long) 16));
					{
					   obj_t list1628_531;
					   {
					      obj_t arg1630_532;
					      {
						 obj_t arg1632_533;
						 arg1632_533 = MAKE_PAIR(BNIL, BNIL);
						 arg1630_532 = MAKE_PAIR(y_500, arg1632_533);
					      }
					      list1628_531 = MAKE_PAIR(x_499, arg1630_532);
					   }
					   arg1624_528 = cons__138___r4_pairs_and_lists_6_3(arg1625_529, list1628_531);
					}
				     }
				     return PROCEDURE_ENTRY(e_18) (e_18, arg1624_528, e_18, BEOA);
				  }
			       }
			  }
		       }
		     else
		       {
			  x_503 = CAR(cdr_710_59_508);
			  y_504 = CDR(cdr_710_59_508);
			tag_703_74_505:
			  {
			     obj_t arg1636_536;
			     {
				obj_t arg1638_537;
				obj_t arg1639_538;
				obj_t arg1640_539;
				arg1638_537 = CNST_TABLE_REF(((long) 8));
				{
				   obj_t arg1648_545;
				   obj_t arg1649_546;
				   arg1648_545 = CNST_TABLE_REF(((long) 16));
				   arg1649_546 = CAR(y_504);
				   {
				      obj_t list1651_548;
				      {
					 obj_t arg1652_549;
					 {
					    obj_t arg1653_550;
					    arg1653_550 = MAKE_PAIR(BNIL, BNIL);
					    arg1652_549 = MAKE_PAIR(arg1649_546, arg1653_550);
					 }
					 list1651_548 = MAKE_PAIR(x_503, arg1652_549);
				      }
				      arg1639_538 = cons__138___r4_pairs_and_lists_6_3(arg1648_545, list1651_548);
				   }
				}
				{
				   obj_t arg1655_552;
				   obj_t arg1656_553;
				   arg1655_552 = CNST_TABLE_REF(((long) 17));
				   {
				      obj_t arg1659_556;
				      arg1659_556 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				      arg1656_553 = append_2_18___r4_pairs_and_lists_6_3(y_504, arg1659_556);
				   }
				   {
				      obj_t list1657_554;
				      list1657_554 = MAKE_PAIR(arg1656_553, BNIL);
				      arg1640_539 = cons__138___r4_pairs_and_lists_6_3(arg1655_552, list1657_554);
				   }
				}
				{
				   obj_t list1642_541;
				   {
				      obj_t arg1645_542;
				      {
					 obj_t arg1646_543;
					 arg1646_543 = MAKE_PAIR(BNIL, BNIL);
					 arg1645_542 = MAKE_PAIR(arg1640_539, arg1646_543);
				      }
				      list1642_541 = MAKE_PAIR(arg1639_538, arg1645_542);
				   }
				   arg1636_536 = cons__138___r4_pairs_and_lists_6_3(arg1638_537, list1642_541);
				}
			     }
			     return PROCEDURE_ENTRY(e_18) (e_18, arg1636_536, e_18, BEOA);
			  }
		       }
		  }
		else
		  {
		     bool_t test_1483;
		     {
			obj_t aux_1484;
			aux_1484 = CDR(cdr_710_59_508);
			test_1483 = (aux_1484 == BNIL);
		     }
		     if (test_1483)
		       {
			  FAILURE(string1696_expand_garithmetique, string1692_expand_garithmetique, x_17);
		       }
		     else
		       {
			  obj_t y_1490;
			  obj_t x_1488;
			  x_1488 = CAR(cdr_710_59_508);
			  y_1490 = CDR(cdr_710_59_508);
			  y_504 = y_1490;
			  x_503 = x_1488;
			  goto tag_703_74_505;
		       }
		  }
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _expand-g>=1690 */ obj_t 
_expand_g__1690_151_expand_garithmetique(obj_t env_891, obj_t x_892, obj_t e_893)
{
   return expand_g___13_expand_garithmetique(x_892, e_893);
}
