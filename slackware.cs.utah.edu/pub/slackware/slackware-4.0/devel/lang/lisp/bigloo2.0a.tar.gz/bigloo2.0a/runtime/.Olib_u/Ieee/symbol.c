/*===========================================================================*/
/*   (Ieee/symbol.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_keyword(char *);
extern obj_t string_to_symbol(char *);
static obj_t _symbol__string_243___r4_symbols_6_4(obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _symbol__231___r4_symbols_6_4(obj_t, obj_t);
static obj_t _getprop___r4_symbols_6_4(obj_t, obj_t, obj_t);
static obj_t _string__symbol_199___r4_symbols_6_4(obj_t, obj_t);
static obj_t _keyword__string_5___r4_symbols_6_4(obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
static obj_t _symbol_append_205___r4_symbols_6_4(obj_t, obj_t);
static obj_t toplevel_init_63___r4_symbols_6_4();
static obj_t _remprop__183___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t symbol_plist_62___r4_symbols_6_4(obj_t);
extern obj_t remprop__243___r4_symbols_6_4(obj_t, obj_t);
extern bool_t symbol__177___r4_symbols_6_4(obj_t);
static obj_t _putprop__17___r4_symbols_6_4(obj_t, obj_t, obj_t, obj_t);
extern char * integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
obj_t gensym___r4_symbols_6_4 = BUNSPEC;
extern obj_t string_to_bstring(char *);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
static obj_t loop___r4_symbols_6_4(obj_t);
extern obj_t symbol__string_118___r4_symbols_6_4(obj_t);
static obj_t lambda1005___r4_symbols_6_4(obj_t, obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t string__keyword_147___r4_symbols_6_4(obj_t);
extern obj_t string__symbol_93___r4_symbols_6_4(obj_t);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t keyword__string_162___r4_symbols_6_4(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _keyword__66___r4_symbols_6_4(obj_t, obj_t);
static obj_t _symbol_plist_91___r4_symbols_6_4(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_symbols_6_4();
static obj_t require_initialization_114___r4_symbols_6_4 = BUNSPEC;
extern bool_t keyword__217___r4_symbols_6_4(obj_t);
static obj_t _string__keyword_72___r4_symbols_6_4(obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( symbol__env_7___r4_symbols_6_4, _symbol__231___r4_symbols_6_41186, _symbol__231___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( putprop__env_168___r4_symbols_6_4, _putprop__17___r4_symbols_6_41187, _putprop__17___r4_symbols_6_4, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( symbol_plist_env_3___r4_symbols_6_4, _symbol_plist_91___r4_symbols_6_41188, _symbol_plist_91___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__keyword_env_177___r4_symbols_6_4, _string__keyword_72___r4_symbols_6_41189, _string__keyword_72___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remprop__env_20___r4_symbols_6_4, _remprop__183___r4_symbols_6_41190, _remprop__183___r4_symbols_6_4, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( keyword__string_env_197___r4_symbols_6_4, _keyword__string_5___r4_symbols_6_41191, _keyword__string_5___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( symbol_append_env_244___r4_symbols_6_4, _symbol_append_205___r4_symbols_6_41192, va_generic_entry, _symbol_append_205___r4_symbols_6_4, -1 );
DEFINE_EXPORT_PROCEDURE( getprop_env_136___r4_symbols_6_4, _getprop___r4_symbols_6_41193, _getprop___r4_symbols_6_4, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( symbol__string_env_220___r4_symbols_6_4, _symbol__string_243___r4_symbols_6_41194, _symbol__string_243___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( keyword__env_152___r4_symbols_6_4, _keyword__66___r4_symbols_6_41195, _keyword__66___r4_symbols_6_4, 0L, 1 );
DEFINE_STRING( string1184___r4_symbols_6_4, string1184___r4_symbols_6_41196, "getprop", 7 );
DEFINE_STRING( string1183___r4_symbols_6_4, string1183___r4_symbols_6_41197, "argument is neither a symbol nor a keyword", 42 );
DEFINE_STRING( string1182___r4_symbols_6_4, string1182___r4_symbols_6_41198, "symbol-plist", 12 );
DEFINE_STRING( string1181___r4_symbols_6_4, string1181___r4_symbols_6_41199, "", 0 );
DEFINE_STRING( string1179___r4_symbols_6_4, string1179___r4_symbols_6_41200, "gensym", 6 );
DEFINE_STRING( string1180___r4_symbols_6_4, string1180___r4_symbols_6_41201, "Illegal argument", 16 );
DEFINE_STRING( string1178___r4_symbols_6_4, string1178___r4_symbols_6_41202, "g", 1 );
DEFINE_EXPORT_PROCEDURE( string__symbol_env_209___r4_symbols_6_4, _string__symbol_199___r4_symbols_6_41203, _string__symbol_199___r4_symbols_6_4, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_symbols_6_4(long checksum_572, char * from_573)
{
if(CBOOL(require_initialization_114___r4_symbols_6_4)){
require_initialization_114___r4_symbols_6_4 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_symbols_6_4();
toplevel_init_63___r4_symbols_6_4();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___r4_symbols_6_4()
{
{
obj_t counter_221;
{
obj_t cellval_579;
cellval_579 = BINT(((long)999));
counter_221 = MAKE_CELL(cellval_579);
}
{
obj_t lambda1005_534;
lambda1005_534 = make_va_procedure(lambda1005___r4_symbols_6_4, ((long)-1), ((long)1));
PROCEDURE_SET(lambda1005_534, ((long)0), counter_221);
return (gensym___r4_symbols_6_4 = lambda1005_534,
BUNSPEC);
}
}
}


/* lambda1005 */obj_t lambda1005___r4_symbols_6_4(obj_t env_535, obj_t string_537)
{
{
obj_t counter_536;
counter_536 = PROCEDURE_REF(env_535, ((long)0));
{
obj_t string_222;
string_222 = string_537;
{
obj_t string_224;
if(NULLP(string_222)){
string_224 = string1178___r4_symbols_6_4;
}
 else {
bool_t test_586;
{
obj_t aux_587;
aux_587 = CAR(string_222);
test_586 = SYMBOLP(aux_587);
}
if(test_586){
{
obj_t aux_590;
aux_590 = CAR(string_222);
string_224 = SYMBOL_TO_STRING(aux_590);
}
}
 else {
bool_t test_593;
{
obj_t aux_594;
aux_594 = CAR(string_222);
test_593 = STRINGP(aux_594);
}
if(test_593){
string_224 = CAR(string_222);
}
 else {
FAILURE(string1179___r4_symbols_6_4,string1180___r4_symbols_6_4,CAR(string_222));}
}
}
{
loop_225:
{
obj_t aux_538;
{
long z1_419;
{
obj_t aux_600;
aux_600 = CELL_REF(counter_536);
z1_419 = (long)CINT(aux_600);
}
{
long aux_602;
aux_602 = (z1_419+((long)1));
aux_538 = BINT(aux_602);
}
}
CELL_SET(counter_536, aux_538);
}
{
obj_t name_226;
{
char * arg1007_228;
{
long aux_605;
{
obj_t aux_606;
aux_606 = CELL_REF(counter_536);
aux_605 = (long)CINT(aux_606);
}
arg1007_228 = integer__string_135___r4_numbers_6_5_fixnum(aux_605, BNIL);
}
{
obj_t aux_609;
aux_609 = string_to_bstring(arg1007_228);
name_226 = string_append(string_224, aux_609);
}
}
{
bool_t test1006_227;
{
char * aux_612;
aux_612 = BSTRING_TO_STRING(name_226);
test1006_227 = symbol_exists_p(aux_612);
}
if(test1006_227){
goto loop_225;
}
 else {
char * aux_616;
aux_616 = BSTRING_TO_STRING(name_226);
return string_to_symbol(aux_616);
}
}
}
}
}
}
}
}


/* symbol? */bool_t symbol__177___r4_symbols_6_4(obj_t obj_1)
{
return SYMBOLP(obj_1);
}


/* _symbol? */obj_t _symbol__231___r4_symbols_6_4(obj_t env_539, obj_t obj_540)
{
{
bool_t aux_620;
{
obj_t obj_565;
obj_565 = obj_540;
aux_620 = SYMBOLP(obj_565);
}
return BBOOL(aux_620);
}
}


/* symbol->string */obj_t symbol__string_118___r4_symbols_6_4(obj_t symbol_2)
{
return SYMBOL_TO_STRING(symbol_2);
}


/* _symbol->string */obj_t _symbol__string_243___r4_symbols_6_4(obj_t env_541, obj_t symbol_542)
{
{
obj_t symbol_566;
symbol_566 = symbol_542;
return SYMBOL_TO_STRING(symbol_566);
}
}


/* string->symbol */obj_t string__symbol_93___r4_symbols_6_4(obj_t string_3)
{
{
char * aux_625;
aux_625 = BSTRING_TO_STRING(string_3);
return string_to_symbol(aux_625);
}
}


/* _string->symbol */obj_t _string__symbol_199___r4_symbols_6_4(obj_t env_543, obj_t string_544)
{
{
obj_t string_567;
string_567 = string_544;
{
char * aux_628;
aux_628 = BSTRING_TO_STRING(string_567);
return string_to_symbol(aux_628);
}
}
}


/* symbol-append */obj_t symbol_append_197___r4_symbols_6_4(obj_t list_4)
{
{
obj_t arg1018_239;
if(NULLP(list_4)){
arg1018_239 = string1181___r4_symbols_6_4;
}
 else {
arg1018_239 = loop___r4_symbols_6_4(list_4);
}
{
char * aux_634;
aux_634 = BSTRING_TO_STRING(arg1018_239);
return string_to_symbol(aux_634);
}
}
}


/* loop */obj_t loop___r4_symbols_6_4(obj_t list_241)
{
{
bool_t test_637;
{
obj_t aux_638;
aux_638 = CDR(list_241);
test_637 = NULLP(aux_638);
}
if(test_637){
obj_t aux_641;
aux_641 = CAR(list_241);
return SYMBOL_TO_STRING(aux_641);
}
 else {
obj_t arg1022_245;
obj_t arg1023_246;
{
obj_t aux_644;
aux_644 = CAR(list_241);
arg1022_245 = SYMBOL_TO_STRING(aux_644);
}
arg1023_246 = loop___r4_symbols_6_4(CDR(list_241));
return string_append(arg1022_245, arg1023_246);
}
}
}


/* _symbol-append */obj_t _symbol_append_205___r4_symbols_6_4(obj_t env_545, obj_t list_546)
{
return symbol_append_197___r4_symbols_6_4(list_546);
}


/* symbol-plist */obj_t symbol_plist_62___r4_symbols_6_4(obj_t symbol_5)
{
{
bool_t test_651;
if(SYMBOLP(symbol_5)){
test_651 = ((bool_t)1);
}
 else {
test_651 = KEYWORDP(symbol_5);
}
if(test_651){
return GET_SYMBOL_PLIST(symbol_5);
}
 else {
FAILURE(string1182___r4_symbols_6_4,string1183___r4_symbols_6_4,symbol_5);}
}
}


/* _symbol-plist */obj_t _symbol_plist_91___r4_symbols_6_4(obj_t env_547, obj_t symbol_548)
{
{
obj_t symbol_568;
symbol_568 = symbol_548;
{
bool_t test_657;
if(SYMBOLP(symbol_568)){
test_657 = ((bool_t)1);
}
 else {
test_657 = KEYWORDP(symbol_568);
}
if(test_657){
return GET_SYMBOL_PLIST(symbol_568);
}
 else {
FAILURE(string1182___r4_symbols_6_4,string1183___r4_symbols_6_4,symbol_568);}
}
}
}


/* getprop */obj_t getprop___r4_symbols_6_4(obj_t symbol_6, obj_t key_7)
{
{
bool_t test1030_252;
if(SYMBOLP(symbol_6)){
test1030_252 = ((bool_t)1);
}
 else {
test1030_252 = KEYWORDP(symbol_6);
}
if(test1030_252){
obj_t pl_253;
{
obj_t arg1031_255;
if(test1030_252){
arg1031_255 = GET_SYMBOL_PLIST(symbol_6);
}
 else {
FAILURE(string1182___r4_symbols_6_4,string1183___r4_symbols_6_4,symbol_6);}
pl_253 = arg1031_255;
loop_254:
if(NULLP(pl_253)){
return BFALSE;
}
 else {
bool_t test_672;
{
obj_t aux_673;
aux_673 = CAR(pl_253);
test_672 = (aux_673==key_7);
}
if(test_672){
{
obj_t aux_676;
aux_676 = CDR(pl_253);
return CAR(aux_676);
}
}
 else {
{
obj_t pl_679;
{
obj_t aux_680;
aux_680 = CDR(pl_253);
pl_679 = CDR(aux_680);
}
pl_253 = pl_679;
goto loop_254;
}
}
}
}
}
 else {
FAILURE(string1184___r4_symbols_6_4,string1183___r4_symbols_6_4,key_7);}
}
}


/* _getprop */obj_t _getprop___r4_symbols_6_4(obj_t env_549, obj_t symbol_550, obj_t key_551)
{
return getprop___r4_symbols_6_4(symbol_550, key_551);
}


/* putprop! */obj_t putprop__88___r4_symbols_6_4(obj_t symbol_8, obj_t key_9, obj_t val_10)
{
{
bool_t test1037_261;
if(SYMBOLP(symbol_8)){
test1037_261 = ((bool_t)1);
}
 else {
test1037_261 = KEYWORDP(symbol_8);
}
if(test1037_261){
obj_t pl_262;
{
obj_t arg1038_264;
if(test1037_261){
arg1038_264 = GET_SYMBOL_PLIST(symbol_8);
}
 else {
FAILURE(string1182___r4_symbols_6_4,string1183___r4_symbols_6_4,symbol_8);}
pl_262 = arg1038_264;
loop_263:
if(NULLP(pl_262)){
{
obj_t new_266;
{
obj_t arg1040_267;
{
bool_t test_694;
if(SYMBOLP(symbol_8)){
test_694 = ((bool_t)1);
}
 else {
test_694 = KEYWORDP(symbol_8);
}
if(test_694){
arg1040_267 = GET_SYMBOL_PLIST(symbol_8);
}
 else {
FAILURE(string1182___r4_symbols_6_4,string1183___r4_symbols_6_4,symbol_8);}
}
{
obj_t list1041_268;
{
obj_t arg1042_269;
arg1042_269 = MAKE_PAIR(arg1040_267, BNIL);
list1041_268 = MAKE_PAIR(val_10, arg1042_269);
}
new_266 = cons__138___r4_pairs_and_lists_6_3(key_9, list1041_268);
}
}
SET_SYMBOL_PLIST(symbol_8, new_266);
return new_266;
}
}
 else {
bool_t test_704;
{
obj_t aux_705;
aux_705 = CAR(pl_262);
test_704 = (aux_705==key_9);
}
if(test_704){
{
obj_t aux_708;
aux_708 = CDR(pl_262);
return SET_CAR(aux_708, val_10);
}
}
 else {
{
obj_t pl_711;
{
obj_t aux_712;
aux_712 = CDR(pl_262);
pl_711 = CDR(aux_712);
}
pl_262 = pl_711;
goto loop_263;
}
}
}
}
}
 else {
FAILURE(string1184___r4_symbols_6_4,string1183___r4_symbols_6_4,key_9);}
}
}


/* _putprop! */obj_t _putprop__17___r4_symbols_6_4(obj_t env_552, obj_t symbol_553, obj_t key_554, obj_t val_555)
{
return putprop__88___r4_symbols_6_4(symbol_553, key_554, val_555);
}


/* remprop! */obj_t remprop__243___r4_symbols_6_4(obj_t symbol_11, obj_t key_12)
{
{
bool_t test1049_276;
if(SYMBOLP(symbol_11)){
test1049_276 = ((bool_t)1);
}
 else {
test1049_276 = KEYWORDP(symbol_11);
}
if(test1049_276){
obj_t old_277;
obj_t l_278;
{
obj_t arg1051_281;
if(test1049_276){
arg1051_281 = GET_SYMBOL_PLIST(symbol_11);
}
 else {
FAILURE(string1182___r4_symbols_6_4,string1183___r4_symbols_6_4,symbol_11);}
old_277 = BNIL;
l_278 = arg1051_281;
loop_279:
if(NULLP(l_278)){
return BFALSE;
}
 else {
bool_t test_726;
{
obj_t aux_727;
aux_727 = CAR(l_278);
test_726 = (aux_727==key_12);
}
if(test_726){
if(PAIRP(old_277)){
{
obj_t aux_734;
obj_t aux_732;
{
obj_t aux_735;
aux_735 = CDR(l_278);
aux_734 = CDR(aux_735);
}
aux_732 = CDR(old_277);
return SET_CDR(aux_732, aux_734);
}
}
 else {
{
obj_t aux_739;
{
obj_t aux_740;
aux_740 = CDR(l_278);
aux_739 = CDR(aux_740);
}
return SET_SYMBOL_PLIST(symbol_11, aux_739);
}
}
}
 else {
{
obj_t l_745;
obj_t old_744;
old_744 = l_278;
{
obj_t aux_746;
aux_746 = CDR(l_278);
l_745 = CDR(aux_746);
}
l_278 = l_745;
old_277 = old_744;
goto loop_279;
}
}
}
}
}
 else {
FAILURE(string1184___r4_symbols_6_4,string1183___r4_symbols_6_4,key_12);}
}
}


/* _remprop! */obj_t _remprop__183___r4_symbols_6_4(obj_t env_556, obj_t symbol_557, obj_t key_558)
{
return remprop__243___r4_symbols_6_4(symbol_557, key_558);
}


/* keyword? */bool_t keyword__217___r4_symbols_6_4(obj_t obj_13)
{
return KEYWORDP(obj_13);
}


/* _keyword? */obj_t _keyword__66___r4_symbols_6_4(obj_t env_559, obj_t obj_560)
{
{
bool_t aux_752;
{
obj_t obj_569;
obj_569 = obj_560;
aux_752 = KEYWORDP(obj_569);
}
return BBOOL(aux_752);
}
}


/* keyword->string */obj_t keyword__string_162___r4_symbols_6_4(obj_t keyword_14)
{
return KEYWORD_TO_STRING(keyword_14);
}


/* _keyword->string */obj_t _keyword__string_5___r4_symbols_6_4(obj_t env_561, obj_t keyword_562)
{
{
obj_t keyword_570;
keyword_570 = keyword_562;
return KEYWORD_TO_STRING(keyword_570);
}
}


/* string->keyword */obj_t string__keyword_147___r4_symbols_6_4(obj_t string_15)
{
{
char * aux_757;
aux_757 = BSTRING_TO_STRING(string_15);
return string_to_keyword(aux_757);
}
}


/* _string->keyword */obj_t _string__keyword_72___r4_symbols_6_4(obj_t env_563, obj_t string_564)
{
{
obj_t string_571;
string_571 = string_564;
{
char * aux_760;
aux_760 = BSTRING_TO_STRING(string_571);
return string_to_keyword(aux_760);
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_symbols_6_4()
{
return module_initialization_70___error(((long)0), "__R4_SYMBOLS_6_4");
}

