/*===========================================================================*/
/*   (Ast/exit.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern let_fun_218_t set_exit__node_102_ast_exit(obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_ast_exit();
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t var_ast_node;
static obj_t _jump_exit__node1610_252_ast_exit(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t set_ex_it_116_ast_node;
extern obj_t module_initialization_70_ast_exit(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern jump_ex_it_184_t jump_exit__node_34_ast_exit(obj_t, obj_t, obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t imported_modules_init_94_ast_exit();
extern obj_t normalize_progn_143_tools_progn(obj_t);
static obj_t library_modules_init_112_ast_exit();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t _exit__255_type_cache;
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
extern local_t make_local_sexit_184_ast_local(obj_t, type_t, sexit_t);
static obj_t _set_exit__node1609_188_ast_exit(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t sexit_ast_var;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_exit = BUNSPEC;
static obj_t cnst_init_137_ast_exit();
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(set_exit__node_env_153_ast_exit, _set_exit__node1609_188_ast_exit1619, _set_exit__node1609_188_ast_exit, 0L, 4);
DEFINE_EXPORT_PROCEDURE(jump_exit__node_env_70_ast_exit, _jump_exit__node1610_252_ast_exit1620, _jump_exit__node1610_252_ast_exit, 0L, 4);
DEFINE_STRING(string1613_ast_exit, string1613_ast_exit1621, "SNIFUN VALUE LABELS HANDLING_FUNCTION ", 38);
DEFINE_STRING(string1612_ast_exit, string1612_ast_exit1622, "Illegal `jump-exit' form", 24);
DEFINE_STRING(string1611_ast_exit, string1611_ast_exit1623, "Illegal `set-exit' form", 23);


/* module-initialization */ obj_t 
module_initialization_70_ast_exit(long checksum_1247, char *from_1248)
{
   if (CBOOL(require_initialization_114_ast_exit))
     {
	require_initialization_114_ast_exit = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_exit();
	cnst_init_137_ast_exit();
	imported_modules_init_94_ast_exit();
	method_init_76_ast_exit();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_exit()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_EXIT");
   module_initialization_70___object(((long) 0), "AST_EXIT");
   module_initialization_70___reader(((long) 0), "AST_EXIT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_EXIT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_exit()
{
   {
      obj_t cnst_port_138_1239;
      cnst_port_138_1239 = open_input_string(string1613_ast_exit);
      {
	 long i_1240;
	 i_1240 = ((long) 3);
       loop_1241:
	 {
	    bool_t test1614_1242;
	    test1614_1242 = (i_1240 == ((long) -1));
	    if (test1614_1242)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1615_1243;
		    {
		       obj_t list1616_1244;
		       {
			  obj_t arg1617_1245;
			  arg1617_1245 = BNIL;
			  list1616_1244 = MAKE_PAIR(cnst_port_138_1239, arg1617_1245);
		       }
		       arg1615_1243 = read___reader(list1616_1244);
		    }
		    CNST_TABLE_SET(i_1240, arg1615_1243);
		 }
		 {
		    int aux_1246;
		    {
		       long aux_1266;
		       aux_1266 = (i_1240 - ((long) 1));
		       aux_1246 = (int) (aux_1266);
		    }
		    {
		       long i_1269;
		       i_1269 = (long) (aux_1246);
		       i_1240 = i_1269;
		       goto loop_1241;
		    }
		 }
	      }
	 }
      }
   }
}


/* set-exit->node */ let_fun_218_t 
set_exit__node_102_ast_exit(obj_t exp_1, obj_t stack_2, obj_t loc_3, obj_t site_4)
{
   {
      obj_t loc_701;
      loc_701 = find_location_loc_243_tools_location(exp_1, loc_3);
      {
	 obj_t exit_702;
	 obj_t body_703;
	 if (PAIRP(exp_1))
	   {
	      obj_t cdr_128_145_708;
	      cdr_128_145_708 = CDR(exp_1);
	      if (PAIRP(cdr_128_145_708))
		{
		   obj_t car_131_9_710;
		   car_131_9_710 = CAR(cdr_128_145_708);
		   if (PAIRP(car_131_9_710))
		     {
			bool_t test_1280;
			{
			   obj_t aux_1281;
			   aux_1281 = CDR(car_131_9_710);
			   test_1280 = (aux_1281 == BNIL);
			}
			if (test_1280)
			  {
			     node_t aux_1284;
			     exit_702 = CAR(car_131_9_710);
			     body_703 = CDR(cdr_128_145_708);
			     {
				obj_t hdlg_name_179_717;
				{
				   obj_t arg1489_759;
				   arg1489_759 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
				   hdlg_name_179_717 = mark_symbol_non_user__17_ast_ident(arg1489_759);
				}
				{
				   obj_t hdlg_sexp_42_718;
				   {
				      obj_t arg1468_738;
				      obj_t arg1469_739;
				      obj_t arg1470_740;
				      arg1468_738 = CNST_TABLE_REF(((long) 1));
				      {
					 obj_t arg1476_746;
					 {
					    obj_t list1482_752;
					    {
					       obj_t arg1483_753;
					       {
						  obj_t arg1484_754;
						  arg1484_754 = MAKE_PAIR(BNIL, BNIL);
						  arg1483_753 = MAKE_PAIR(BUNSPEC, arg1484_754);
					       }
					       list1482_752 = MAKE_PAIR(BNIL, arg1483_753);
					    }
					    arg1476_746 = cons__138___r4_pairs_and_lists_6_3(hdlg_name_179_717, list1482_752);
					 }
					 {
					    obj_t list1478_748;
					    list1478_748 = MAKE_PAIR(BNIL, BNIL);
					    arg1469_739 = cons__138___r4_pairs_and_lists_6_3(arg1476_746, list1478_748);
					 }
				      }
				      {
					 obj_t list1487_757;
					 list1487_757 = MAKE_PAIR(BNIL, BNIL);
					 arg1470_740 = cons__138___r4_pairs_and_lists_6_3(hdlg_name_179_717, list1487_757);
				      }
				      {
					 obj_t list1472_742;
					 {
					    obj_t arg1473_743;
					    {
					       obj_t arg1474_744;
					       arg1474_744 = MAKE_PAIR(BNIL, BNIL);
					       arg1473_743 = MAKE_PAIR(arg1470_740, arg1474_744);
					    }
					    list1472_742 = MAKE_PAIR(arg1469_739, arg1473_743);
					 }
					 hdlg_sexp_42_718 = cons__138___r4_pairs_and_lists_6_3(arg1468_738, list1472_742);
				      }
				   }
				   {
				      node_t hdlg_node_132_719;
				      hdlg_node_132_719 = sexp__node_235_ast_sexp(hdlg_sexp_42_718, stack_2, loc_701, site_4);
				      {
					 obj_t hdlg_fun_73_720;
					 {
					    obj_t aux_1303;
					    {
					       let_fun_218_t obj_1122;
					       obj_1122 = (let_fun_218_t) (hdlg_node_132_719);
					       aux_1303 = (((let_fun_218_t) CREF(obj_1122))->locals);
					    }
					    hdlg_fun_73_720 = CAR(aux_1303);
					 }
					 {
					    local_t exit_721;
					    {
					       sexit_t arg1494_1126;
					       {
						  sexit_t res1604_1136;
						  {
						     sexit_t new1175_1130;
						     new1175_1130 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
						     {
							long arg1570_1131;
							arg1570_1131 = class_num_218___object(sexit_ast_var);
							{
							   obj_t obj_1134;
							   obj_1134 = (obj_t) (new1175_1130);
							   (((obj_t) CREF(obj_1134))->header = MAKE_HEADER(arg1570_1131, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_1311;
							aux_1311 = (object_t) (new1175_1130);
							OBJECT_WIDENING_SET(aux_1311, BFALSE);
						     }
						     ((((sexit_t) CREF(new1175_1130))->handler) = ((obj_t) hdlg_fun_73_720), BUNSPEC);
						     ((((sexit_t) CREF(new1175_1130))->detached__120) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						     res1604_1136 = new1175_1130;
						  }
						  arg1494_1126 = res1604_1136;
					       }
					       exit_721 = make_local_sexit_184_ast_local(exit_702, (type_t) (_exit__255_type_cache), arg1494_1126);
					    }
					    {
					       node_t body_722;
					       {
						  obj_t arg1464_734;
						  obj_t arg1465_735;
						  obj_t arg1466_736;
						  arg1464_734 = normalize_progn_143_tools_progn(body_703);
						  {
						     obj_t aux_1319;
						     aux_1319 = (obj_t) (exit_721);
						     arg1465_735 = MAKE_PAIR(aux_1319, stack_2);
						  }
						  arg1466_736 = CNST_TABLE_REF(((long) 2));
						  body_722 = sexp__node_235_ast_sexp(arg1464_734, arg1465_735, loc_701, arg1466_736);
					       }
					       {
						  set_ex_it_116_t exit_body_148_723;
						  {
						     obj_t arg1455_728;
						     var_t arg1456_729;
						     arg1455_728 = ____74_type_cache;
						     {
							obj_t arg1461_732;
							arg1461_732 = _exit__255_type_cache;
							{
							   var_t res1605_1149;
							   {
							      type_t type_1140;
							      variable_t variable_1141;
							      type_1140 = (type_t) (arg1461_732);
							      variable_1141 = (variable_t) (exit_721);
							      {
								 var_t new1206_1142;
								 new1206_1142 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								 {
								    long arg1561_1143;
								    arg1561_1143 = class_num_218___object(var_ast_node);
								    {
								       obj_t obj_1147;
								       obj_1147 = (obj_t) (new1206_1142);
								       (((obj_t) CREF(obj_1147))->header = MAKE_HEADER(arg1561_1143, 0), BUNSPEC);
								    }
								 }
								 {
								    object_t aux_1330;
								    aux_1330 = (object_t) (new1206_1142);
								    OBJECT_WIDENING_SET(aux_1330, BFALSE);
								 }
								 ((((var_t) CREF(new1206_1142))->loc) = ((obj_t) loc_701), BUNSPEC);
								 ((((var_t) CREF(new1206_1142))->type) = ((type_t) type_1140), BUNSPEC);
								 ((((var_t) CREF(new1206_1142))->variable) = ((variable_t) variable_1141), BUNSPEC);
								 res1605_1149 = new1206_1142;
							      }
							   }
							   arg1456_729 = res1605_1149;
							}
						     }
						     {
							set_ex_it_116_t res1606_1162;
							{
							   type_t type_1151;
							   type_1151 = (type_t) (arg1455_728);
							   {
							      set_ex_it_116_t new1381_1154;
							      new1381_1154 = ((set_ex_it_116_t) BREF(GC_MALLOC(sizeof(struct set_ex_it_116))));
							      {
								 long arg1524_1155;
								 arg1524_1155 = class_num_218___object(set_ex_it_116_ast_node);
								 {
								    obj_t obj_1160;
								    obj_1160 = (obj_t) (new1381_1154);
								    (((obj_t) CREF(obj_1160))->header = MAKE_HEADER(arg1524_1155, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_1341;
								 aux_1341 = (object_t) (new1381_1154);
								 OBJECT_WIDENING_SET(aux_1341, BFALSE);
							      }
							      ((((set_ex_it_116_t) CREF(new1381_1154))->loc) = ((obj_t) loc_701), BUNSPEC);
							      ((((set_ex_it_116_t) CREF(new1381_1154))->type) = ((type_t) type_1151), BUNSPEC);
							      ((((set_ex_it_116_t) CREF(new1381_1154))->var) = ((var_t) arg1456_729), BUNSPEC);
							      ((((set_ex_it_116_t) CREF(new1381_1154))->body) = ((node_t) body_722), BUNSPEC);
							      res1606_1162 = new1381_1154;
							   }
							}
							exit_body_148_723 = res1606_1162;
						     }
						  }
						  {
						     {
							local_t obj_1163;
							obj_1163 = (local_t) (hdlg_fun_73_720);
							((((local_t) CREF(obj_1163))->user__32) = ((bool_t) ((bool_t) 1)), BUNSPEC);
						     }
						     {
							obj_t arg1450_725;
							arg1450_725 = CNST_TABLE_REF(((long) 3));
							{
							   sfun_t obj_1166;
							   {
							      value_t aux_1351;
							      {
								 local_t obj_1165;
								 obj_1165 = (local_t) (hdlg_fun_73_720);
								 aux_1351 = (((local_t) CREF(obj_1165))->value);
							      }
							      obj_1166 = (sfun_t) (aux_1351);
							   }
							   ((((sfun_t) CREF(obj_1166))->class) = ((obj_t) arg1450_725), BUNSPEC);
							}
						     }
						     {
							sfun_t obj_1169;
							obj_t val1135_1170;
							{
							   value_t aux_1356;
							   {
							      local_t obj_1168;
							      obj_1168 = (local_t) (hdlg_fun_73_720);
							      aux_1356 = (((local_t) CREF(obj_1168))->value);
							   }
							   obj_1169 = (sfun_t) (aux_1356);
							}
							val1135_1170 = (obj_t) (exit_body_148_723);
							((((sfun_t) CREF(obj_1169))->body) = ((obj_t) val1135_1170), BUNSPEC);
						     }
						     aux_1284 = hdlg_node_132_719;
						  }
					       }
					    }
					 }
				      }
				   }
				}
			     }
			     return (let_fun_218_t) (aux_1284);
			  }
			else
			  {
			     node_t aux_1365;
			   tag_121_151_705:
			     aux_1365 = error_sexp__node_157_ast_sexp(string1611_ast_exit, exp_1, loc_701);
			     return (let_fun_218_t) (aux_1365);
			  }
		     }
		   else
		     {
			node_t aux_1368;
			goto tag_121_151_705;
			return (let_fun_218_t) (aux_1368);
		     }
		}
	      else
		{
		   node_t aux_1370;
		   goto tag_121_151_705;
		   return (let_fun_218_t) (aux_1370);
		}
	   }
	 else
	   {
	      node_t aux_1372;
	      goto tag_121_151_705;
	      return (let_fun_218_t) (aux_1372);
	   }
      }
   }
}


/* _set-exit->node1609 */ obj_t 
_set_exit__node1609_188_ast_exit(obj_t env_1229, obj_t exp_1230, obj_t stack_1231, obj_t loc_1232, obj_t site_1233)
{
   {
      let_fun_218_t aux_1374;
      aux_1374 = set_exit__node_102_ast_exit(exp_1230, stack_1231, loc_1232, site_1233);
      return (obj_t) (aux_1374);
   }
}


/* jump-exit->node */ jump_ex_it_184_t 
jump_exit__node_34_ast_exit(obj_t exp_5, obj_t stack_6, obj_t loc_7, obj_t site_8)
{
   {
      obj_t loc_767;
      loc_767 = find_location_loc_243_tools_location(exp_5, loc_7);
      {
	 obj_t exit_768;
	 obj_t value_769;
	 if (PAIRP(exp_5))
	   {
	      obj_t cdr_146_167_774;
	      cdr_146_167_774 = CDR(exp_5);
	      if (PAIRP(cdr_146_167_774))
		{
		   exit_768 = CAR(cdr_146_167_774);
		   value_769 = CDR(cdr_146_167_774);
		   {
		      node_t value_778;
		      node_t exit_779;
		      {
			 obj_t arg1505_784;
			 obj_t arg1507_785;
			 arg1505_784 = normalize_progn_143_tools_progn(value_769);
			 arg1507_785 = CNST_TABLE_REF(((long) 2));
			 value_778 = sexp__node_235_ast_sexp(arg1505_784, stack_6, loc_767, arg1507_785);
		      }
		      exit_779 = sexp__node_235_ast_sexp(exit_768, stack_6, loc_767, CNST_TABLE_REF(((long) 2)));
		      {
			 obj_t arg1502_781;
			 arg1502_781 = ____74_type_cache;
			 {
			    jump_ex_it_184_t res1608_1199;
			    {
			       type_t type_1188;
			       type_1188 = (type_t) (arg1502_781);
			       {
				  jump_ex_it_184_t new1391_1191;
				  new1391_1191 = ((jump_ex_it_184_t) BREF(GC_MALLOC(sizeof(struct jump_ex_it_184))));
				  {
				     long arg1519_1192;
				     arg1519_1192 = class_num_218___object(jump_ex_it_184_ast_node);
				     {
					obj_t obj_1197;
					obj_1197 = (obj_t) (new1391_1191);
					(((obj_t) CREF(obj_1197))->header = MAKE_HEADER(arg1519_1192, 0), BUNSPEC);
				     }
				  }
				  {
				     object_t aux_1393;
				     aux_1393 = (object_t) (new1391_1191);
				     OBJECT_WIDENING_SET(aux_1393, BFALSE);
				  }
				  ((((jump_ex_it_184_t) CREF(new1391_1191))->loc) = ((obj_t) loc_767), BUNSPEC);
				  ((((jump_ex_it_184_t) CREF(new1391_1191))->type) = ((type_t) type_1188), BUNSPEC);
				  ((((jump_ex_it_184_t) CREF(new1391_1191))->exit) = ((node_t) exit_779), BUNSPEC);
				  ((((jump_ex_it_184_t) CREF(new1391_1191))->value) = ((node_t) value_778), BUNSPEC);
				  res1608_1199 = new1391_1191;
			       }
			    }
			    return res1608_1199;
			 }
		      }
		   }
		}
	      else
		{
		   node_t aux_1402;
		 tag_139_224_771:
		   aux_1402 = error_sexp__node_157_ast_sexp(string1612_ast_exit, exp_5, loc_767);
		   return (jump_ex_it_184_t) (aux_1402);
		}
	   }
	 else
	   {
	      node_t aux_1405;
	      goto tag_139_224_771;
	      return (jump_ex_it_184_t) (aux_1405);
	   }
      }
   }
}


/* _jump-exit->node1610 */ obj_t 
_jump_exit__node1610_252_ast_exit(obj_t env_1234, obj_t exp_1235, obj_t stack_1236, obj_t loc_1237, obj_t site_1238)
{
   {
      jump_ex_it_184_t aux_1407;
      aux_1407 = jump_exit__node_34_ast_exit(exp_1235, stack_1236, loc_1237, site_1238);
      return (obj_t) (aux_1407);
   }
}


/* method-init */ obj_t 
method_init_76_ast_exit()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_exit()
{
   module_initialization_70_type_type(((long) 0), "AST_EXIT");
   module_initialization_70_ast_var(((long) 0), "AST_EXIT");
   module_initialization_70_ast_node(((long) 0), "AST_EXIT");
   module_initialization_70_tools_trace(((long) 0), "AST_EXIT");
   module_initialization_70_ast_sexp(((long) 0), "AST_EXIT");
   module_initialization_70_ast_local(((long) 0), "AST_EXIT");
   module_initialization_70_ast_ident(((long) 0), "AST_EXIT");
   module_initialization_70_type_cache(((long) 0), "AST_EXIT");
   module_initialization_70_tools_progn(((long) 0), "AST_EXIT");
   return module_initialization_70_tools_location(((long) 0), "AST_EXIT");
}
