/*===========================================================================*/
/*   (Ast/sexp.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern let_fun_218_t set_exit__node_102_ast_exit(obj_t, obj_t, obj_t, obj_t);
extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_ast_sexp();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _cache_res__50_ast_sexp = BUNSPEC;
static obj_t lookup_ast_sexp(obj_t, obj_t);
extern obj_t fail_ast_node;
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t dsssl_find_first_formal_237_tools_dsssl(obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t sequence_ast_node;
extern obj_t var_ast_node;
static obj_t _sexp__node2301_129_ast_sexp(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t closure_ast_node;
static obj_t _define_primop__node2305_97_ast_sexp(obj_t, obj_t);
extern node_t application__node_43_ast_app(obj_t, obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
static obj_t sexp___node_160_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern node_t pragma_type__node_160_ast_pragma(bool_t, type_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _magic__144_type_cache;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t current_function_76_tools_error();
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_typeof(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_build(long, char *);
extern obj_t module_initialization_70_ast_pragma(long, char *);
extern obj_t module_initialization_70_ast_labels(long, char *);
extern obj_t module_initialization_70_ast_let(long, char *);
extern obj_t module_initialization_70_ast_exit(long, char *);
extern obj_t module_initialization_70_ast_app(long, char *);
extern obj_t module_initialization_70_ast_apply(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___dsssl(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern node_t applycation__node_122_ast_apply(obj_t, obj_t, obj_t, obj_t);
extern obj_t _bnil__15_type_cache;
extern node_t location__node_25_ast_sexp(global_t);
extern jump_ex_it_184_t jump_exit__node_34_ast_exit(obj_t, obj_t, obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _top_level_sexp__node_248_ast_sexp(obj_t, obj_t, obj_t);
extern obj_t node_ast_node;
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_ast_sexp();
static obj_t _define_primop_ref__node2304_55_ast_sexp(obj_t, obj_t, obj_t);
extern obj_t normalize_progn_143_tools_progn(obj_t);
static obj_t _use_variable_2302_248_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_sexp();
static obj_t _cache_stack__44_ast_sexp = BUNSPEC;
static obj_t _error_sexp__node2303_135_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t atom_ast_node;
static obj_t toplevel_init_63_ast_sexp();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t use_variable__4_ast_sexp(variable_t, obj_t, obj_t);
extern node_t top_level_sexp__node_204_ast_sexp(obj_t, obj_t);
static obj_t arg1958_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern node_t define_primop__node_141_ast_sexp(global_t);
extern obj_t setq_ast_node;
static obj_t _cache_name__178_ast_sexp = BUNSPEC;
static obj_t _sites__81_ast_sexp = BUNSPEC;
extern obj_t parse_id_241_ast_ident(obj_t);
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
extern obj_t local_ast_var;
static obj_t loop_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern node_t let__node_121_ast_let(obj_t, obj_t, obj_t, obj_t);
static obj_t _location__node2306_123_ast_sexp(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern type_t typeof_atom_134_type_typeof(obj_t);
extern obj_t _4dots_199_tools_misc;
static obj_t liip_ast_sexp(obj_t);
extern obj_t select_ast_node;
extern let_fun_218_t labels__node_197_ast_labels(obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern node_t define_primop_ref__node_164_ast_sexp(global_t, node_t);
extern obj_t make_dsssl_function_prelude_58___dsssl(obj_t, obj_t, obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_sexp = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_ast_sexp();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t user_error_location_137_tools_error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t __cnst[32];

DEFINE_EXPORT_PROCEDURE(use_variable__env_235_ast_sexp, _use_variable_2302_248_ast_sexp2330, _use_variable_2302_248_ast_sexp, 0L, 3);
DEFINE_EXPORT_PROCEDURE(define_primop__node_env_232_ast_sexp, _define_primop__node2305_97_ast_sexp2331, _define_primop__node2305_97_ast_sexp, 0L, 1);
DEFINE_EXPORT_PROCEDURE(error_sexp__node_env_24_ast_sexp, _error_sexp__node2303_135_ast_sexp2332, _error_sexp__node2303_135_ast_sexp, 0L, 3);
DEFINE_EXPORT_PROCEDURE(define_primop_ref__node_env_208_ast_sexp, _define_primop_ref__node2304_55_ast_sexp2333, _define_primop_ref__node2304_55_ast_sexp, 0L, 2);
DEFINE_EXPORT_PROCEDURE(top_level_sexp__node_env_236_ast_sexp, _top_level_sexp__node_248_ast_sexp2334, _top_level_sexp__node_248_ast_sexp, 0L, 2);
DEFINE_EXPORT_PROCEDURE(location__node_env_47_ast_sexp, _location__node2306_123_ast_sexp2335, _location__node2306_123_ast_sexp, 0L, 1);
DEFINE_STRING(string2324_ast_sexp, string2324_ast_sexp2336, "(@ __EVMEANING_ADDRESS FOREIGN) DEFINE-PRIMOP! DEFINE-PRIMOP-REF! WRITE CONS (QUOTE ()) APPLY JUMP-EXIT SET-EXIT CASE FAILURE LETREC DEFINE BEGIN QUOTE @ APP EVAL NOT IF ::BOOL TEST LOCATION SET! LET ELSE LABELS LAMBDA FREE-PRAGMA PRAGMA VALUE (VALUE APPLY APP SET!) ", 267);
DEFINE_STRING(string2323_ast_sexp, string2323_ast_sexp2337, "Illegal mutation", 16);
DEFINE_STRING(string2322_ast_sexp, string2322_ast_sexp2338, "Illegal empty sequence", 22);
DEFINE_STRING(string2321_ast_sexp, string2321_ast_sexp2339, "Illegal formal argument", 23);
DEFINE_STRING(string2319_ast_sexp, string2319_ast_sexp2340, "Illegal `()' expression", 23);
DEFINE_STRING(string2320_ast_sexp, string2320_ast_sexp2341, "wrong number of argument", 24);
DEFINE_STRING(string2318_ast_sexp, string2318_ast_sexp2342, "Illegal atom", 12);
DEFINE_STRING(string2317_ast_sexp, string2317_ast_sexp2343, "Unbound variable", 16);
DEFINE_STRING(string2316_ast_sexp, string2316_ast_sexp2344, "Illegal `@' expression", 22);
DEFINE_STRING(string2315_ast_sexp, string2315_ast_sexp2345, "Illegal `quote' expression", 26);
DEFINE_STRING(string2314_ast_sexp, string2314_ast_sexp2346, "Illegal `if' form", 17);
DEFINE_STRING(string2313_ast_sexp, string2313_ast_sexp2347, "illegal `set!' expression", 25);
DEFINE_STRING(string2312_ast_sexp, string2312_ast_sexp2348, "Illegal `set!' form", 19);
DEFINE_STRING(string2311_ast_sexp, string2311_ast_sexp2349, "illegal `define' expression", 27);
DEFINE_STRING(string2309_ast_sexp, string2309_ast_sexp2350, "Illegal `failure' form", 22);
DEFINE_STRING(string2310_ast_sexp, string2310_ast_sexp2351, "Illegal `define' form", 21);
DEFINE_STRING(string2308_ast_sexp, string2308_ast_sexp2352, "Illegal `case' form", 19);
DEFINE_STRING(string2307_ast_sexp, string2307_ast_sexp2353, "Illegal `lambda' form", 21);
DEFINE_EXPORT_PROCEDURE(sexp__node_env_201_ast_sexp, _sexp__node2301_129_ast_sexp2354, _sexp__node2301_129_ast_sexp, 0L, 4);


/* module-initialization */ obj_t 
module_initialization_70_ast_sexp(long checksum_2709, char *from_2710)
{
   if (CBOOL(require_initialization_114_ast_sexp))
     {
	require_initialization_114_ast_sexp = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_sexp();
	cnst_init_137_ast_sexp();
	imported_modules_init_94_ast_sexp();
	method_init_76_ast_sexp();
	toplevel_init_63_ast_sexp();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_sexp()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_SEXP");
   module_initialization_70___object(((long) 0), "AST_SEXP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_SEXP");
   module_initialization_70___reader(((long) 0), "AST_SEXP");
   module_initialization_70___dsssl(((long) 0), "AST_SEXP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_sexp()
{
   {
      obj_t cnst_port_138_2701;
      cnst_port_138_2701 = open_input_string(string2324_ast_sexp);
      {
	 long i_2702;
	 i_2702 = ((long) 31);
       loop_2703:
	 {
	    bool_t test2325_2704;
	    test2325_2704 = (i_2702 == ((long) -1));
	    if (test2325_2704)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2326_2705;
		    {
		       obj_t list2327_2706;
		       {
			  obj_t arg2328_2707;
			  arg2328_2707 = BNIL;
			  list2327_2706 = MAKE_PAIR(cnst_port_138_2701, arg2328_2707);
		       }
		       arg2326_2705 = read___reader(list2327_2706);
		    }
		    CNST_TABLE_SET(i_2702, arg2326_2705);
		 }
		 {
		    int aux_2708;
		    {
		       long aux_2730;
		       aux_2730 = (i_2702 - ((long) 1));
		       aux_2708 = (int) (aux_2730);
		    }
		    {
		       long i_2733;
		       i_2733 = (long) (aux_2708);
		       i_2702 = i_2733;
		       goto loop_2703;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_sexp()
{
   _sites__81_ast_sexp = CNST_TABLE_REF(((long) 0));
   _cache_name__178_ast_sexp = BFALSE;
   _cache_stack__44_ast_sexp = BFALSE;
   return (_cache_res__50_ast_sexp = BFALSE,
      BUNSPEC);
}


/* top-level-sexp->node */ node_t 
top_level_sexp__node_204_ast_sexp(obj_t exp_15, obj_t loc_16)
{
   return sexp__node_235_ast_sexp(exp_15, BNIL, loc_16, CNST_TABLE_REF(((long) 1)));
}


/* _top-level-sexp->node */ obj_t 
_top_level_sexp__node_248_ast_sexp(obj_t env_2669, obj_t exp_2670, obj_t loc_2671)
{
   {
      node_t aux_2738;
      aux_2738 = top_level_sexp__node_204_ast_sexp(exp_2670, loc_2671);
      return (obj_t) (aux_2738);
   }
}


/* sexp->node */ node_t 
sexp__node_235_ast_sexp(obj_t exp_17, obj_t stack_18, obj_t loc_19, obj_t site_20)
{
 sexp__node_235_ast_sexp:
   {
      obj_t atom_749;
      obj_t body_753;
      obj_t body_758;
      obj_t args_759;
      obj_t vars_763;
      obj_t body_764;
      obj_t args_765;
      if ((exp_17 == BNIL))
	{
	   return error_sexp__node_157_ast_sexp(string2319_ast_sexp, exp_17, loc_19);
	}
      else
	{
	   bool_t test1478_778;
	   test1478_778 = is_a__118___object(exp_17, node_ast_node);
	   if (test1478_778)
	     {
		return (node_t) (exp_17);
	     }
	   else
	     {
		if (PAIRP(exp_17))
		  {
		     bool_t test_2749;
		     {
			obj_t aux_2752;
			obj_t aux_2750;
			aux_2752 = CNST_TABLE_REF(((long) 16));
			aux_2750 = CAR(exp_17);
			test_2749 = (aux_2750 == aux_2752);
		     }
		     if (test_2749)
		       {
			  obj_t aux_2755;
			  {
			     obj_t loc_936;
			     loc_936 = find_location_loc_243_tools_location(exp_17, loc_19);
			     {
				obj_t name_937;
				obj_t module_938;
				if (PAIRP(exp_17))
				  {
				     obj_t cdr_352_26_943;
				     cdr_352_26_943 = CDR(exp_17);
				     {
					bool_t test_2760;
					{
					   obj_t aux_2763;
					   obj_t aux_2761;
					   aux_2763 = CNST_TABLE_REF(((long) 16));
					   aux_2761 = CAR(exp_17);
					   test_2760 = (aux_2761 == aux_2763);
					}
					if (test_2760)
					  {
					     if (PAIRP(cdr_352_26_943))
					       {
						  obj_t car_355_218_946;
						  obj_t cdr_356_4_947;
						  car_355_218_946 = CAR(cdr_352_26_943);
						  cdr_356_4_947 = CDR(cdr_352_26_943);
						  if (SYMBOLP(car_355_218_946))
						    {
						       if (PAIRP(cdr_356_4_947))
							 {
							    obj_t car_361_52_950;
							    car_361_52_950 = CAR(cdr_356_4_947);
							    if (SYMBOLP(car_361_52_950))
							      {
								 bool_t test_2777;
								 {
								    obj_t aux_2778;
								    aux_2778 = CDR(cdr_356_4_947);
								    test_2777 = (aux_2778 == BNIL);
								 }
								 if (test_2777)
								   {
								      name_937 = car_355_218_946;
								      module_938 = car_361_52_950;
								      {
									 obj_t global_957;
									 {
									    obj_t list1693_978;
									    list1693_978 = MAKE_PAIR(module_938, BNIL);
									    global_957 = find_global_223_ast_env(name_937, list1693_978);
									 }
									 {
									    bool_t test1669_958;
									    test1669_958 = is_a__118___object(global_957, global_ast_var);
									    if (test1669_958)
									      {
										 bool_t test_2785;
										 {
										    obj_t aux_2789;
										    obj_t aux_2786;
										    aux_2789 = CNST_TABLE_REF(((long) 14));
										    {
										       global_t obj_2123;
										       obj_2123 = (global_t) (global_957);
										       aux_2786 = (((global_t) CREF(obj_2123))->import);
										    }
										    test_2785 = (aux_2786 == aux_2789);
										 }
										 if (test_2785)
										   {
										      {
											 obj_t arg1672_960;
											 {
											    obj_t arg1673_961;
											    arg1673_961 = CNST_TABLE_REF(((long) 14));
											    {
											       obj_t list1676_963;
											       {
												  obj_t arg1677_964;
												  arg1677_964 = MAKE_PAIR(BNIL, BNIL);
												  list1676_963 = MAKE_PAIR(atom_ast_node, arg1677_964);
											       }
											       arg1672_960 = cons__138___r4_pairs_and_lists_6_3(arg1673_961, list1676_963);
											    }
											 }
											 {
											    node_t aux_2796;
											    aux_2796 = sexp__node_235_ast_sexp(arg1672_960, stack_18, loc_936, site_20);
											    aux_2755 = (obj_t) (aux_2796);
											 }
										      }
										   }
										 else
										   {
										      use_variable__4_ast_sexp((variable_t) (global_957), loc_936, site_20);
										      {
											 bool_t test1679_966;
											 {
											    bool_t test_2801;
											    {
											       obj_t aux_2802;
											       aux_2802 = CNST_TABLE_REF(((long) 15));
											       test_2801 = (site_20 == aux_2802);
											    }
											    if (test_2801)
											      {
												 test1679_966 = ((bool_t) 0);
											      }
											    else
											      {
												 obj_t aux_2805;
												 {
												    value_t aux_2806;
												    {
												       global_t obj_2128;
												       obj_2128 = (global_t) (global_957);
												       aux_2806 = (((global_t) CREF(obj_2128))->value);
												    }
												    aux_2805 = (obj_t) (aux_2806);
												 }
												 test1679_966 = is_a__118___object(aux_2805, fun_ast_var);
											      }
											 }
											 if (test1679_966)
											   {
											      type_t arg1681_968;
											      {
												 global_t obj_2130;
												 obj_2130 = (global_t) (global_957);
												 arg1681_968 = (((global_t) CREF(obj_2130))->type);
											      }
											      {
												 closure_t res2287_2141;
												 {
												    variable_t variable_2133;
												    variable_2133 = (variable_t) (global_957);
												    {
												       closure_t new1214_2134;
												       new1214_2134 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
												       {
													  long arg2239_2135;
													  arg2239_2135 = class_num_218___object(closure_ast_node);
													  {
													     obj_t obj_2139;
													     obj_2139 = (obj_t) (new1214_2134);
													     (((obj_t) CREF(obj_2139))->header = MAKE_HEADER(arg2239_2135, 0), BUNSPEC);
													  }
												       }
												       {
													  object_t aux_2819;
													  aux_2819 = (object_t) (new1214_2134);
													  OBJECT_WIDENING_SET(aux_2819, BFALSE);
												       }
												       ((((closure_t) CREF(new1214_2134))->loc) = ((obj_t) loc_936), BUNSPEC);
												       ((((closure_t) CREF(new1214_2134))->type) = ((type_t) arg1681_968), BUNSPEC);
												       ((((closure_t) CREF(new1214_2134))->variable) = ((variable_t) variable_2133), BUNSPEC);
												       res2287_2141 = new1214_2134;
												    }
												 }
												 aux_2755 = (obj_t) (res2287_2141);
											      }
											   }
											 else
											   {
											      type_t arg1684_971;
											      {
												 global_t obj_2142;
												 obj_2142 = (global_t) (global_957);
												 arg1684_971 = (((global_t) CREF(obj_2142))->type);
											      }
											      {
												 var_t res2288_2153;
												 {
												    variable_t variable_2145;
												    variable_2145 = (variable_t) (global_957);
												    {
												       var_t new1206_2146;
												       new1206_2146 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
												       {
													  long arg2241_2147;
													  arg2241_2147 = class_num_218___object(var_ast_node);
													  {
													     obj_t obj_2151;
													     obj_2151 = (obj_t) (new1206_2146);
													     (((obj_t) CREF(obj_2151))->header = MAKE_HEADER(arg2241_2147, 0), BUNSPEC);
													  }
												       }
												       {
													  object_t aux_2833;
													  aux_2833 = (object_t) (new1206_2146);
													  OBJECT_WIDENING_SET(aux_2833, BFALSE);
												       }
												       ((((var_t) CREF(new1206_2146))->loc) = ((obj_t) loc_936), BUNSPEC);
												       ((((var_t) CREF(new1206_2146))->type) = ((type_t) arg1684_971), BUNSPEC);
												       ((((var_t) CREF(new1206_2146))->variable) = ((variable_t) variable_2145), BUNSPEC);
												       res2288_2153 = new1206_2146;
												    }
												 }
												 aux_2755 = (obj_t) (res2288_2153);
											      }
											   }
										      }
										   }
									      }
									    else
									      {
										 {
										    node_t aux_2840;
										    aux_2840 = error_sexp__node_157_ast_sexp(string2317_ast_sexp, exp_17, loc_936);
										    aux_2755 = (obj_t) (aux_2840);
										 }
									      }
									 }
								      }
								   }
								 else
								   {
								      node_t aux_2843;
								    tag_345_225_940:
								      aux_2843 = error_sexp__node_157_ast_sexp(string2316_ast_sexp, exp_17, loc_936);
								      aux_2755 = (obj_t) (aux_2843);
								   }
							      }
							    else
							      {
								 node_t aux_2846;
								 goto tag_345_225_940;
								 aux_2755 = (obj_t) (aux_2846);
							      }
							 }
						       else
							 {
							    node_t aux_2848;
							    goto tag_345_225_940;
							    aux_2755 = (obj_t) (aux_2848);
							 }
						    }
						  else
						    {
						       node_t aux_2850;
						       goto tag_345_225_940;
						       aux_2755 = (obj_t) (aux_2850);
						    }
					       }
					     else
					       {
						  node_t aux_2852;
						  goto tag_345_225_940;
						  aux_2755 = (obj_t) (aux_2852);
					       }
					  }
					else
					  {
					     node_t aux_2854;
					     goto tag_345_225_940;
					     aux_2755 = (obj_t) (aux_2854);
					  }
				     }
				  }
				else
				  {
				     node_t aux_2856;
				     goto tag_345_225_940;
				     aux_2755 = (obj_t) (aux_2856);
				  }
			     }
			  }
			  return (node_t) (aux_2755);
		       }
		     else
		       {
			  bool_t test_2859;
			  {
			     obj_t aux_2862;
			     obj_t aux_2860;
			     aux_2862 = CNST_TABLE_REF(((long) 17));
			     aux_2860 = CAR(exp_17);
			     test_2859 = (aux_2860 == aux_2862);
			  }
			  if (test_2859)
			    {
			       obj_t aux_2865;
			       {
				  obj_t value_980;
				  if (PAIRP(exp_17))
				    {
				       obj_t cdr_372_212_985;
				       cdr_372_212_985 = CDR(exp_17);
				       if (PAIRP(cdr_372_212_985))
					 {
					    bool_t test_2871;
					    {
					       obj_t aux_2872;
					       aux_2872 = CDR(cdr_372_212_985);
					       test_2871 = (aux_2872 == BNIL);
					    }
					    if (test_2871)
					      {
						 value_980 = CAR(cdr_372_212_985);
						 {
						    obj_t loc_991;
						    loc_991 = find_location_loc_243_tools_location(exp_17, loc_19);
						    if (NULLP(value_980))
						      {
							 {
							    obj_t arg1703_994;
							    arg1703_994 = _bnil__15_type_cache;
							    {
							       atom_t res2289_2172;
							       {
								  type_t type_2163;
								  type_2163 = (type_t) (arg1703_994);
								  {
								     atom_t new1198_2165;
								     new1198_2165 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
								     {
									long arg2244_2166;
									arg2244_2166 = class_num_218___object(atom_ast_node);
									{
									   obj_t obj_2170;
									   obj_2170 = (obj_t) (new1198_2165);
									   (((obj_t) CREF(obj_2170))->header = MAKE_HEADER(arg2244_2166, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_2883;
									aux_2883 = (object_t) (new1198_2165);
									OBJECT_WIDENING_SET(aux_2883, BFALSE);
								     }
								     ((((atom_t) CREF(new1198_2165))->loc) = ((obj_t) loc_991), BUNSPEC);
								     ((((atom_t) CREF(new1198_2165))->type) = ((type_t) type_2163), BUNSPEC);
								     ((((atom_t) CREF(new1198_2165))->value) = ((obj_t) BNIL), BUNSPEC);
								     res2289_2172 = new1198_2165;
								  }
							       }
							       aux_2865 = (obj_t) (res2289_2172);
							    }
							 }
						      }
						    else
						      {
							 bool_t test_2890;
							 if (PAIRP(value_980))
							   {
							      test_2890 = ((bool_t) 1);
							   }
							 else
							   {
							      if (VECTORP(value_980))
								{
								   test_2890 = ((bool_t) 1);
								}
							      else
								{
								   if (STRUCTP(value_980))
								     {
									test_2890 = ((bool_t) 1);
								     }
								   else
								     {
									if (SYMBOLP(value_980))
									  {
									     test_2890 = ((bool_t) 1);
									  }
									else
									  {
									     test_2890 = KEYWORDP(value_980);
									  }
								     }
								}
							   }
							 if (test_2890)
							   {
							      {
								 obj_t arg1707_998;
								 arg1707_998 = ____74_type_cache;
								 {
								    kwote_t res2290_2188;
								    {
								       type_t type_2179;
								       type_2179 = (type_t) (arg1707_998);
								       {
									  kwote_t new1222_2181;
									  new1222_2181 = ((kwote_t) BREF(GC_MALLOC(sizeof(struct kwote))));
									  {
									     long arg2237_2182;
									     arg2237_2182 = class_num_218___object(kwote_ast_node);
									     {
										obj_t obj_2186;
										obj_2186 = (obj_t) (new1222_2181);
										(((obj_t) CREF(obj_2186))->header = MAKE_HEADER(arg2237_2182, 0), BUNSPEC);
									     }
									  }
									  {
									     object_t aux_2905;
									     aux_2905 = (object_t) (new1222_2181);
									     OBJECT_WIDENING_SET(aux_2905, BFALSE);
									  }
									  ((((kwote_t) CREF(new1222_2181))->loc) = ((obj_t) loc_991), BUNSPEC);
									  ((((kwote_t) CREF(new1222_2181))->type) = ((type_t) type_2179), BUNSPEC);
									  ((((kwote_t) CREF(new1222_2181))->value) = ((obj_t) value_980), BUNSPEC);
									  res2290_2188 = new1222_2181;
								       }
								    }
								    aux_2865 = (obj_t) (res2290_2188);
								 }
							      }
							   }
							 else
							   {
							      bool_t test_2912;
							      {
								 bool_t test1710_1001;
								 test1710_1001 = INTEGERP(value_980);
								 if (test1710_1001)
								   {
								      test_2912 = ((bool_t) 1);
								   }
								 else
								   {
								      bool_t test_2915;
								      if (test1710_1001)
									{
									   test_2915 = ((bool_t) 1);
									}
								      else
									{
									   test_2915 = REALP(value_980);
									}
								      if (test_2915)
									{
									   test_2912 = ((bool_t) 1);
									}
								      else
									{
									   if (STRINGP(value_980))
									     {
										test_2912 = ((bool_t) 1);
									     }
									   else
									     {
										if (CNSTP(value_980))
										  {
										     test_2912 = ((bool_t) 1);
										  }
										else
										  {
										     if (CHARP(value_980))
										       {
											  test_2912 = ((bool_t) 1);
										       }
										     else
										       {
											  test_2912 = BOOLEANP(value_980);
										       }
										  }
									     }
									}
								   }
							      }
							      if (test_2912)
								{
								   {
								      node_t aux_2925;
								      aux_2925 = sexp__node_235_ast_sexp(value_980, stack_18, loc_991, site_20);
								      aux_2865 = (obj_t) (aux_2925);
								   }
								}
							      else
								{
								   {
								      node_t aux_2928;
								      aux_2928 = error_sexp__node_157_ast_sexp(string2315_ast_sexp, exp_17, loc_991);
								      aux_2865 = (obj_t) (aux_2928);
								   }
								}
							   }
						      }
						 }
					      }
					    else
					      {
						 node_t aux_2932;
					       tag_367_40_982:
						 aux_2932 = error_sexp__node_157_ast_sexp(string2315_ast_sexp, exp_17, loc_19);
						 aux_2865 = (obj_t) (aux_2932);
					      }
					 }
				       else
					 {
					    node_t aux_2935;
					    goto tag_367_40_982;
					    aux_2865 = (obj_t) (aux_2935);
					 }
				    }
				  else
				    {
				       node_t aux_2937;
				       goto tag_367_40_982;
				       aux_2865 = (obj_t) (aux_2937);
				    }
			       }
			       return (node_t) (aux_2865);
			    }
			  else
			    {
			       bool_t test_2940;
			       {
				  obj_t aux_2943;
				  obj_t aux_2941;
				  aux_2943 = CNST_TABLE_REF(((long) 18));
				  aux_2941 = CAR(exp_17);
				  test_2940 = (aux_2941 == aux_2943);
			       }
			       if (test_2940)
				 {
				    sequence_t aux_2946;
				    body_753 = CDR(exp_17);
				    {
				       obj_t body_1010;
				       if (NULLP(body_753))
					 {
					    obj_t list1725_1018;
					    list1725_1018 = MAKE_PAIR(BUNSPEC, BNIL);
					    body_1010 = list1725_1018;
					 }
				       else
					 {
					    body_1010 = body_753;
					 }
				       {
					  obj_t loc_1011;
					  loc_1011 = find_location_loc_243_tools_location(exp_17, loc_19);
					  {
					     obj_t nodes_1012;
					     nodes_1012 = sexp___node_160_ast_sexp(body_1010, stack_18, loc_1011, site_20);
					     {
						{
						   obj_t arg1721_1014;
						   arg1721_1014 = ____74_type_cache;
						   {
						      sequence_t res2292_2213;
						      {
							 type_t type_2200;
							 obj_t key_2202;
							 type_2200 = (type_t) (arg1721_1014);
							 key_2202 = BINT(((long) -1));
							 {
							    sequence_t new1229_2204;
							    new1229_2204 = ((sequence_t) BREF(GC_MALLOC(sizeof(struct sequence))));
							    {
							       long arg2235_2205;
							       arg2235_2205 = class_num_218___object(sequence_ast_node);
							       {
								  obj_t obj_2211;
								  obj_2211 = (obj_t) (new1229_2204);
								  (((obj_t) CREF(obj_2211))->header = MAKE_HEADER(arg2235_2205, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_2958;
							       aux_2958 = (object_t) (new1229_2204);
							       OBJECT_WIDENING_SET(aux_2958, BFALSE);
							    }
							    ((((sequence_t) CREF(new1229_2204))->loc) = ((obj_t) loc_1011), BUNSPEC);
							    ((((sequence_t) CREF(new1229_2204))->type) = ((type_t) type_2200), BUNSPEC);
							    ((((sequence_t) CREF(new1229_2204))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
							    ((((sequence_t) CREF(new1229_2204))->key) = ((obj_t) key_2202), BUNSPEC);
							    ((((sequence_t) CREF(new1229_2204))->nodes) = ((obj_t) nodes_1012), BUNSPEC);
							    res2292_2213 = new1229_2204;
							 }
						      }
						      aux_2946 = res2292_2213;
						   }
						}
					     }
					  }
				       }
				    }
				    return (node_t) (aux_2946);
				 }
			       else
				 {
				    bool_t test_2968;
				    {
				       obj_t aux_2971;
				       obj_t aux_2969;
				       aux_2971 = CNST_TABLE_REF(((long) 12));
				       aux_2969 = CAR(exp_17);
				       test_2968 = (aux_2969 == aux_2971);
				    }
				    if (test_2968)
				      {
					 obj_t aux_2974;
					 {
					    obj_t si_1020;
					    obj_t alors_1021;
					    obj_t sinon_1022;
					    obj_t si_1024;
					    obj_t alors_1025;
					    if (PAIRP(exp_17))
					      {
						 obj_t cdr_388_242_1030;
						 cdr_388_242_1030 = CDR(exp_17);
						 if (PAIRP(cdr_388_242_1030))
						   {
						      obj_t cdr_393_75_1032;
						      cdr_393_75_1032 = CDR(cdr_388_242_1030);
						      if (PAIRP(cdr_393_75_1032))
							{
							   obj_t cdr_398_147_1034;
							   cdr_398_147_1034 = CDR(cdr_393_75_1032);
							   if (PAIRP(cdr_398_147_1034))
							     {
								bool_t test_2986;
								{
								   obj_t aux_2987;
								   aux_2987 = CDR(cdr_398_147_1034);
								   test_2986 = (aux_2987 == BNIL);
								}
								if (test_2986)
								  {
								     si_1020 = CAR(cdr_388_242_1030);
								     alors_1021 = CAR(cdr_393_75_1032);
								     sinon_1022 = CAR(cdr_398_147_1034);
								     {
									obj_t si_1049;
									if (PAIRP(si_1020))
									  {
									     obj_t cdr_453_73_1054;
									     cdr_453_73_1054 = CDR(si_1020);
									     {
										bool_t test_2993;
										{
										   obj_t aux_2996;
										   obj_t aux_2994;
										   aux_2996 = CNST_TABLE_REF(((long) 12));
										   aux_2994 = CAR(si_1020);
										   test_2993 = (aux_2994 == aux_2996);
										}
										if (test_2993)
										  {
										     if (PAIRP(cdr_453_73_1054))
										       {
											  obj_t cdr_456_36_1057;
											  cdr_456_36_1057 = CDR(cdr_453_73_1054);
											  if (PAIRP(cdr_456_36_1057))
											    {
											       obj_t cdr_459_197_1059;
											       cdr_459_197_1059 = CDR(cdr_456_36_1057);
											       {
												  bool_t test_3005;
												  {
												     obj_t aux_3006;
												     aux_3006 = CAR(cdr_456_36_1057);
												     test_3005 = (aux_3006 == BFALSE);
												  }
												  if (test_3005)
												    {
												       if (PAIRP(cdr_459_197_1059))
													 {
													    bool_t test_3011;
													    {
													       obj_t aux_3012;
													       aux_3012 = CAR(cdr_459_197_1059);
													       test_3011 = (aux_3012 == BTRUE);
													    }
													    if (test_3011)
													      {
														 bool_t test_3015;
														 {
														    obj_t aux_3016;
														    aux_3016 = CDR(cdr_459_197_1059);
														    test_3015 = (aux_3016 == BNIL);
														 }
														 if (test_3015)
														   {
														      node_t aux_3019;
														      si_1049 = CAR(cdr_453_73_1054);
														    tag_445_246_1050:
														      {
															 obj_t aux_3020;
															 aux_3020 = CDR(exp_17);
															 SET_CAR(aux_3020, si_1049);
														      }
														      {
															 obj_t aux_3023;
															 {
															    obj_t aux_3024;
															    aux_3024 = CDR(exp_17);
															    aux_3023 = CDR(aux_3024);
															 }
															 SET_CAR(aux_3023, sinon_1022);
														      }
														      {
															 obj_t aux_3028;
															 {
															    obj_t aux_3029;
															    {
															       obj_t aux_3030;
															       aux_3030 = CDR(exp_17);
															       aux_3029 = CDR(aux_3030);
															    }
															    aux_3028 = CDR(aux_3029);
															 }
															 SET_CAR(aux_3028, alors_1021);
														      }
														      aux_3019 = sexp__node_235_ast_sexp(exp_17, stack_18, loc_19, site_20);
														      aux_2974 = (obj_t) (aux_3019);
														   }
														 else
														   {
														    tag_446_179_1051:
														      {
															 bool_t test1780_1085;
															 if (SYMBOLP(si_1020))
															   {
															      test1780_1085 = ((bool_t) 1);
															   }
															 else
															   {
															      test1780_1085 = is_a__118___object(si_1020, atom_ast_node);
															   }
															 if (test1780_1085)
															   {
															      obj_t oloc_1086;
															      oloc_1086 = find_location_loc_243_tools_location(exp_17, loc_19);
															      {
																 obj_t l_si_138_1087;
																 l_si_138_1087 = find_location_loc_243_tools_location(si_1020, oloc_1086);
																 {
																    obj_t l_alors_128_1088;
																    l_alors_128_1088 = find_location_loc_243_tools_location(alors_1021, oloc_1086);
																    {
																       obj_t l_sinon_85_1089;
																       l_sinon_85_1089 = find_location_loc_243_tools_location(sinon_1022, oloc_1086);
																       {
																	  node_t si_1090;
																	  si_1090 = sexp__node_235_ast_sexp(si_1020, stack_18, l_si_138_1087, CNST_TABLE_REF(((long) 1)));
																	  {
																	     node_t alors_1091;
																	     alors_1091 = sexp__node_235_ast_sexp(alors_1021, stack_18, l_alors_128_1088, CNST_TABLE_REF(((long) 1)));
																	     {
																		node_t sinon_1092;
																		sinon_1092 = sexp__node_235_ast_sexp(sinon_1022, stack_18, l_sinon_85_1089, CNST_TABLE_REF(((long) 1)));
																		{
																		   obj_t loc_1093;
																		   {
																		      obj_t loc_1100;
																		      loc_1100 = find_location_loc_243_tools_location(exp_17, (((node_t) CREF(si_1090))->loc));
																		      {
																			 bool_t test_3054;
																			 if (STRUCTP(loc_1100))
																			   {
																			      obj_t aux_3059;
																			      obj_t aux_3057;
																			      aux_3059 = CNST_TABLE_REF(((long) 9));
																			      aux_3057 = STRUCT_KEY(loc_1100);
																			      test_3054 = (aux_3057 == aux_3059);
																			   }
																			 else
																			   {
																			      test_3054 = ((bool_t) 0);
																			   }
																			 if (test_3054)
																			   {
																			      loc_1093 = loc_1100;
																			   }
																			 else
																			   {
																			      loc_1093 = oloc_1086;
																			   }
																		      }
																		   }
																		   {
																		      {
																			 obj_t arg1783_1095;
																			 arg1783_1095 = ____74_type_cache;
																			 {
																			    conditional_t res2293_2309;
																			    {
																			       type_t type_2292;
																			       obj_t key_2294;
																			       type_2292 = (type_t) (arg1783_1095);
																			       key_2294 = BINT(((long) -1));
																			       {
																				  conditional_t new1309_2298;
																				  new1309_2298 = ((conditional_t) BREF(GC_MALLOC(sizeof(struct conditional))));
																				  {
																				     long arg2221_2299;
																				     arg2221_2299 = class_num_218___object(conditional_ast_node);
																				     {
																					obj_t obj_2307;
																					obj_2307 = (obj_t) (new1309_2298);
																					(((obj_t) CREF(obj_2307))->header = MAKE_HEADER(arg2221_2299, 0), BUNSPEC);
																				     }
																				  }
																				  {
																				     object_t aux_3068;
																				     aux_3068 = (object_t) (new1309_2298);
																				     OBJECT_WIDENING_SET(aux_3068, BFALSE);
																				  }
																				  ((((conditional_t) CREF(new1309_2298))->loc) = ((obj_t) loc_1093), BUNSPEC);
																				  ((((conditional_t) CREF(new1309_2298))->type) = ((type_t) type_2292), BUNSPEC);
																				  ((((conditional_t) CREF(new1309_2298))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
																				  ((((conditional_t) CREF(new1309_2298))->key) = ((obj_t) key_2294), BUNSPEC);
																				  ((((conditional_t) CREF(new1309_2298))->test) = ((node_t) si_1090), BUNSPEC);
																				  ((((conditional_t) CREF(new1309_2298))->true) = ((node_t) alors_1091), BUNSPEC);
																				  ((((conditional_t) CREF(new1309_2298))->false) = ((node_t) sinon_1092), BUNSPEC);
																				  res2293_2309 = new1309_2298;
																			       }
																			    }
																			    aux_2974 = (obj_t) (res2293_2309);
																			 }
																		      }
																		   }
																		}
																	     }
																	  }
																       }
																    }
																 }
															      }
															   }
															 else
															   {
															      obj_t test_1106;
															      {
																 obj_t arg1830_1136;
																 arg1830_1136 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 10)), BEOA);
																 test_1106 = mark_symbol_non_user__17_ast_ident(arg1830_1136);
															      }
															      {
																 obj_t arg1796_1107;
																 {
																    obj_t arg1797_1108;
																    obj_t arg1799_1109;
																    obj_t arg1800_1110;
																    arg1797_1108 = CNST_TABLE_REF(((long) 7));
																    {
																       obj_t arg1807_1116;
																       {
																	  obj_t arg1811_1120;
																	  {
																	     obj_t list1817_1126;
																	     {
																		obj_t arg1818_1127;
																		{
																		   obj_t aux_3084;
																		   aux_3084 = CNST_TABLE_REF(((long) 11));
																		   arg1818_1127 = MAKE_PAIR(aux_3084, BNIL);
																		}
																		list1817_1126 = MAKE_PAIR(test_1106, arg1818_1127);
																	     }
																	     arg1811_1120 = symbol_append_197___r4_symbols_6_4(list1817_1126);
																	  }
																	  {
																	     obj_t list1813_1122;
																	     {
																		obj_t arg1814_1123;
																		arg1814_1123 = MAKE_PAIR(BNIL, BNIL);
																		list1813_1122 = MAKE_PAIR(si_1020, arg1814_1123);
																	     }
																	     arg1807_1116 = cons__138___r4_pairs_and_lists_6_3(arg1811_1120, list1813_1122);
																	  }
																       }
																       {
																	  obj_t list1809_1118;
																	  list1809_1118 = MAKE_PAIR(BNIL, BNIL);
																	  arg1799_1109 = cons__138___r4_pairs_and_lists_6_3(arg1807_1116, list1809_1118);
																       }
																    }
																    {
																       obj_t arg1821_1129;
																       arg1821_1129 = CNST_TABLE_REF(((long) 12));
																       {
																	  obj_t list1823_1131;
																	  {
																	     obj_t arg1824_1132;
																	     {
																		obj_t arg1826_1133;
																		{
																		   obj_t arg1827_1134;
																		   arg1827_1134 = MAKE_PAIR(BNIL, BNIL);
																		   arg1826_1133 = MAKE_PAIR(sinon_1022, arg1827_1134);
																		}
																		arg1824_1132 = MAKE_PAIR(alors_1021, arg1826_1133);
																	     }
																	     list1823_1131 = MAKE_PAIR(test_1106, arg1824_1132);
																	  }
																	  arg1800_1110 = cons__138___r4_pairs_and_lists_6_3(arg1821_1129, list1823_1131);
																       }
																    }
																    {
																       obj_t list1803_1112;
																       {
																	  obj_t arg1804_1113;
																	  {
																	     obj_t arg1805_1114;
																	     arg1805_1114 = MAKE_PAIR(BNIL, BNIL);
																	     arg1804_1113 = MAKE_PAIR(arg1800_1110, arg1805_1114);
																	  }
																	  list1803_1112 = MAKE_PAIR(arg1799_1109, arg1804_1113);
																       }
																       arg1796_1107 = cons__138___r4_pairs_and_lists_6_3(arg1797_1108, list1803_1112);
																    }
																 }
																 replace__160_tools_misc(exp_17, arg1796_1107);
															      }
															      {
																 node_t aux_3105;
																 aux_3105 = sexp__node_235_ast_sexp(exp_17, stack_18, loc_19, site_20);
																 aux_2974 = (obj_t) (aux_3105);
															      }
															   }
														      }
														   }
													      }
													    else
													      {
														 goto tag_446_179_1051;
													      }
													 }
												       else
													 {
													    goto tag_446_179_1051;
													 }
												    }
												  else
												    {
												       goto tag_446_179_1051;
												    }
											       }
											    }
											  else
											    {
											       goto tag_446_179_1051;
											    }
										       }
										     else
										       {
											  goto tag_446_179_1051;
										       }
										  }
										else
										  {
										     bool_t test_3108;
										     {
											obj_t aux_3111;
											obj_t aux_3109;
											aux_3111 = CNST_TABLE_REF(((long) 13));
											aux_3109 = CAR(si_1020);
											test_3108 = (aux_3109 == aux_3111);
										     }
										     if (test_3108)
										       {
											  if (PAIRP(cdr_453_73_1054))
											    {
											       bool_t test_3116;
											       {
												  obj_t aux_3117;
												  aux_3117 = CDR(cdr_453_73_1054);
												  test_3116 = (aux_3117 == BNIL);
											       }
											       if (test_3116)
												 {
												    node_t aux_3120;
												    {
												       obj_t si_3121;
												       si_3121 = CAR(cdr_453_73_1054);
												       si_1049 = si_3121;
												       goto tag_445_246_1050;
												    }
												    aux_2974 = (obj_t) (aux_3120);
												 }
											       else
												 {
												    goto tag_446_179_1051;
												 }
											    }
											  else
											    {
											       goto tag_446_179_1051;
											    }
										       }
										     else
										       {
											  goto tag_446_179_1051;
										       }
										  }
									     }
									  }
									else
									  {
									     goto tag_446_179_1051;
									  }
								     }
								  }
								else
								  {
								     node_t aux_3127;
								   tag_379_81_1027:
								     aux_3127 = error_sexp__node_157_ast_sexp(string2314_ast_sexp, exp_17, loc_19);
								     aux_2974 = (obj_t) (aux_3127);
								  }
							     }
							   else
							     {
								obj_t cdr_423_232_1043;
								cdr_423_232_1043 = CDR(cdr_388_242_1030);
								{
								   bool_t test_3131;
								   {
								      obj_t aux_3132;
								      aux_3132 = CDR(cdr_423_232_1043);
								      test_3131 = (aux_3132 == BNIL);
								   }
								   if (test_3131)
								     {
									node_t aux_3135;
									si_1024 = CAR(cdr_388_242_1030);
									alors_1025 = CAR(cdr_423_232_1043);
									{
									   obj_t arg1833_1139;
									   obj_t arg1834_1140;
									   {
									      obj_t aux_3136;
									      aux_3136 = CDR(exp_17);
									      arg1833_1139 = CDR(aux_3136);
									   }
									   {
									      obj_t list1835_1141;
									      list1835_1141 = MAKE_PAIR(BUNSPEC, BNIL);
									      arg1834_1140 = list1835_1141;
									   }
									   SET_CDR(arg1833_1139, arg1834_1140);
									}
									aux_3135 = sexp__node_235_ast_sexp(exp_17, stack_18, loc_19, site_20);
									aux_2974 = (obj_t) (aux_3135);
								     }
								   else
								     {
									node_t aux_3145;
									goto tag_379_81_1027;
									aux_2974 = (obj_t) (aux_3145);
								     }
								}
							     }
							}
						      else
							{
							   node_t aux_3147;
							   goto tag_379_81_1027;
							   aux_2974 = (obj_t) (aux_3147);
							}
						   }
						 else
						   {
						      node_t aux_3149;
						      goto tag_379_81_1027;
						      aux_2974 = (obj_t) (aux_3149);
						   }
					      }
					    else
					      {
						 node_t aux_3151;
						 goto tag_379_81_1027;
						 aux_2974 = (obj_t) (aux_3151);
					      }
					 }
					 return (node_t) (aux_2974);
				      }
				    else
				      {
					 bool_t test_3154;
					 {
					    obj_t aux_3157;
					    obj_t aux_3155;
					    aux_3157 = CNST_TABLE_REF(((long) 8));
					    aux_3155 = CAR(exp_17);
					    test_3154 = (aux_3155 == aux_3157);
					 }
					 if (test_3154)
					   {
					      obj_t aux_3160;
					      {
						 obj_t var_1143;
						 obj_t val_1144;
						 if (PAIRP(exp_17))
						   {
						      obj_t cdr_484_240_1149;
						      cdr_484_240_1149 = CDR(exp_17);
						      if (PAIRP(cdr_484_240_1149))
							{
							   obj_t cdr_488_93_1151;
							   cdr_488_93_1151 = CDR(cdr_484_240_1149);
							   if (PAIRP(cdr_488_93_1151))
							     {
								bool_t test_3169;
								{
								   obj_t aux_3170;
								   aux_3170 = CDR(cdr_488_93_1151);
								   test_3169 = (aux_3170 == BNIL);
								}
								if (test_3169)
								  {
								     var_1143 = CAR(cdr_484_240_1149);
								     val_1144 = CAR(cdr_488_93_1151);
								     {
									obj_t loc_1158;
									loc_1158 = find_location_loc_243_tools_location(exp_17, loc_19);
									{
									   obj_t val_loc_228_1159;
									   val_loc_228_1159 = find_location_loc_243_tools_location(val_1144, loc_1158);
									   {
									      node_t val_1160;
									      val_1160 = sexp__node_235_ast_sexp(val_1144, stack_18, val_loc_228_1159, CNST_TABLE_REF(((long) 1)));
									      {
										 {
										    node_t ast_1161;
										    ast_1161 = sexp__node_235_ast_sexp(var_1143, stack_18, loc_1158, CNST_TABLE_REF(((long) 8)));
										    {
										       bool_t test1849_1162;
										       test1849_1162 = is_a__118___object((obj_t) (ast_1161), var_ast_node);
										       if (test1849_1162)
											 {
											    obj_t arg1851_1164;
											    arg1851_1164 = _unspec__87_type_cache;
											    {
											       setq_t res2294_2340;
											       {
												  type_t type_2329;
												  var_t var_2330;
												  type_2329 = (type_t) (arg1851_1164);
												  var_2330 = (var_t) (ast_1161);
												  {
												     setq_t new1299_2332;
												     new1299_2332 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
												     {
													long arg2223_2333;
													arg2223_2333 = class_num_218___object(setq_ast_node);
													{
													   obj_t obj_2338;
													   obj_2338 = (obj_t) (new1299_2332);
													   (((obj_t) CREF(obj_2338))->header = MAKE_HEADER(arg2223_2333, 0), BUNSPEC);
													}
												     }
												     {
													object_t aux_3188;
													aux_3188 = (object_t) (new1299_2332);
													OBJECT_WIDENING_SET(aux_3188, BFALSE);
												     }
												     ((((setq_t) CREF(new1299_2332))->loc) = ((obj_t) loc_1158), BUNSPEC);
												     ((((setq_t) CREF(new1299_2332))->type) = ((type_t) type_2329), BUNSPEC);
												     ((((setq_t) CREF(new1299_2332))->var) = ((var_t) var_2330), BUNSPEC);
												     ((((setq_t) CREF(new1299_2332))->value) = ((node_t) val_1160), BUNSPEC);
												     res2294_2340 = new1299_2332;
												  }
											       }
											       aux_3160 = (obj_t) (res2294_2340);
											    }
											 }
										       else
											 {
											    node_t aux_3196;
											    aux_3196 = error_sexp__node_157_ast_sexp(string2313_ast_sexp, exp_17, loc_1158);
											    aux_3160 = (obj_t) (aux_3196);
											 }
										    }
										 }
									      }
									   }
									}
								     }
								  }
								else
								  {
								     node_t aux_3201;
								   tag_477_142_1146:
								     {
									obj_t arg1859_1170;
									arg1859_1170 = find_location_loc_243_tools_location(exp_17, loc_19);
									aux_3201 = error_sexp__node_157_ast_sexp(string2312_ast_sexp, exp_17, arg1859_1170);
								     }
								     aux_3160 = (obj_t) (aux_3201);
								  }
							     }
							   else
							     {
								node_t aux_3205;
								goto tag_477_142_1146;
								aux_3160 = (obj_t) (aux_3205);
							     }
							}
						      else
							{
							   node_t aux_3207;
							   goto tag_477_142_1146;
							   aux_3160 = (obj_t) (aux_3207);
							}
						   }
						 else
						   {
						      node_t aux_3209;
						      goto tag_477_142_1146;
						      aux_3160 = (obj_t) (aux_3209);
						   }
					      }
					      return (node_t) (aux_3160);
					   }
					 else
					   {
					      bool_t test_3212;
					      {
						 obj_t aux_3215;
						 obj_t aux_3213;
						 aux_3215 = CNST_TABLE_REF(((long) 19));
						 aux_3213 = CAR(exp_17);
						 test_3212 = (aux_3213 == aux_3215);
					      }
					      if (test_3212)
						{
						   obj_t aux_3218;
						   {
						      obj_t var_1171;
						      obj_t val_1172;
						      if (PAIRP(exp_17))
							{
							   obj_t cdr_502_28_1177;
							   cdr_502_28_1177 = CDR(exp_17);
							   if (PAIRP(cdr_502_28_1177))
							     {
								obj_t cdr_506_2_1179;
								cdr_506_2_1179 = CDR(cdr_502_28_1177);
								if (PAIRP(cdr_506_2_1179))
								  {
								     bool_t test_3227;
								     {
									obj_t aux_3228;
									aux_3228 = CDR(cdr_506_2_1179);
									test_3227 = (aux_3228 == BNIL);
								     }
								     if (test_3227)
								       {
									  var_1171 = CAR(cdr_502_28_1177);
									  val_1172 = CAR(cdr_506_2_1179);
									  {
									     obj_t loc_1186;
									     loc_1186 = find_location_loc_243_tools_location(exp_17, loc_19);
									     {
										obj_t val_loc_228_1187;
										val_loc_228_1187 = find_location_loc_243_tools_location(val_1172, loc_1186);
										{
										   node_t val_1188;
										   val_1188 = sexp__node_235_ast_sexp(val_1172, stack_18, val_loc_228_1187, CNST_TABLE_REF(((long) 1)));
										   {
										      {
											 node_t ast_1189;
											 ast_1189 = sexp__node_235_ast_sexp(var_1171, stack_18, loc_1186, CNST_TABLE_REF(((long) 1)));
											 {
											    bool_t test1868_1190;
											    {
											       bool_t test1876_1196;
											       test1876_1196 = is_a__118___object((obj_t) (ast_1189), var_ast_node);
											       if (test1876_1196)
												 {
												    obj_t aux_3240;
												    {
												       variable_t aux_3241;
												       {
													  var_t obj_2352;
													  obj_2352 = (var_t) (ast_1189);
													  aux_3241 = (((var_t) CREF(obj_2352))->variable);
												       }
												       aux_3240 = (obj_t) (aux_3241);
												    }
												    test1868_1190 = is_a__118___object(aux_3240, global_ast_var);
												 }
											       else
												 {
												    test1868_1190 = ((bool_t) 0);
												 }
											    }
											    if (test1868_1190)
											      {
												 {
												    global_t obj_2355;
												    obj_t val1077_2356;
												    {
												       variable_t aux_3247;
												       {
													  var_t obj_2354;
													  obj_2354 = (var_t) (ast_1189);
													  aux_3247 = (((var_t) CREF(obj_2354))->variable);
												       }
												       obj_2355 = (global_t) (aux_3247);
												    }
												    val1077_2356 = (obj_t) (val_1188);
												    ((((global_t) CREF(obj_2355))->src) = ((obj_t) val1077_2356), BUNSPEC);
												 }
												 {
												    obj_t arg1871_1193;
												    arg1871_1193 = _unspec__87_type_cache;
												    {
												       setq_t res2295_2369;
												       {
													  type_t type_2358;
													  var_t var_2359;
													  type_2358 = (type_t) (arg1871_1193);
													  var_2359 = (var_t) (ast_1189);
													  {
													     setq_t new1299_2361;
													     new1299_2361 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
													     {
														long arg2223_2362;
														arg2223_2362 = class_num_218___object(setq_ast_node);
														{
														   obj_t obj_2367;
														   obj_2367 = (obj_t) (new1299_2361);
														   (((obj_t) CREF(obj_2367))->header = MAKE_HEADER(arg2223_2362, 0), BUNSPEC);
														}
													     }
													     {
														object_t aux_3259;
														aux_3259 = (object_t) (new1299_2361);
														OBJECT_WIDENING_SET(aux_3259, BFALSE);
													     }
													     ((((setq_t) CREF(new1299_2361))->loc) = ((obj_t) loc_1186), BUNSPEC);
													     ((((setq_t) CREF(new1299_2361))->type) = ((type_t) type_2358), BUNSPEC);
													     ((((setq_t) CREF(new1299_2361))->var) = ((var_t) var_2359), BUNSPEC);
													     ((((setq_t) CREF(new1299_2361))->value) = ((node_t) val_1188), BUNSPEC);
													     res2295_2369 = new1299_2361;
													  }
												       }
												       aux_3218 = (obj_t) (res2295_2369);
												    }
												 }
											      }
											    else
											      {
												 node_t aux_3267;
												 aux_3267 = error_sexp__node_157_ast_sexp(string2311_ast_sexp, exp_17, loc_1186);
												 aux_3218 = (obj_t) (aux_3267);
											      }
											 }
										      }
										   }
										}
									     }
									  }
								       }
								     else
								       {
									  node_t aux_3272;
									tag_495_173_1174:
									  {
									     obj_t arg1881_1201;
									     arg1881_1201 = find_location_loc_243_tools_location(exp_17, loc_19);
									     aux_3272 = error_sexp__node_157_ast_sexp(string2310_ast_sexp, exp_17, arg1881_1201);
									  }
									  aux_3218 = (obj_t) (aux_3272);
								       }
								  }
								else
								  {
								     node_t aux_3276;
								     goto tag_495_173_1174;
								     aux_3218 = (obj_t) (aux_3276);
								  }
							     }
							   else
							     {
								node_t aux_3278;
								goto tag_495_173_1174;
								aux_3218 = (obj_t) (aux_3278);
							     }
							}
						      else
							{
							   node_t aux_3280;
							   goto tag_495_173_1174;
							   aux_3218 = (obj_t) (aux_3280);
							}
						   }
						   return (node_t) (aux_3218);
						}
					      else
						{
						   obj_t car_196_45_787;
						   car_196_45_787 = CAR(exp_17);
						   if (PAIRP(car_196_45_787))
						     {
							obj_t car_199_165_789;
							obj_t cdr_200_91_790;
							car_199_165_789 = CAR(car_196_45_787);
							cdr_200_91_790 = CDR(car_196_45_787);
							{
							   {
							      bool_t test_3288;
							      {
								 obj_t aux_3289;
								 aux_3289 = CNST_TABLE_REF(((long) 7));
								 test_3288 = (car_199_165_789 == aux_3289);
							      }
							      if (test_3288)
								{
								 kap_201_205_791:
								   if (PAIRP(cdr_200_91_790))
								     {
									obj_t cdr_204_81_808;
									cdr_204_81_808 = CDR(cdr_200_91_790);
									if (PAIRP(cdr_204_81_808))
									  {
									     bool_t test_3297;
									     {
										obj_t aux_3298;
										aux_3298 = CDR(cdr_204_81_808);
										test_3297 = (aux_3298 == BNIL);
									     }
									     if (test_3297)
									       {
										  body_758 = CAR(cdr_204_81_808);
										  args_759 = CDR(exp_17);
										  {
										     obj_t let_part_60_1202;
										     let_part_60_1202 = CAR(exp_17);
										     {
											obj_t arg1883_1203;
											obj_t arg1884_1204;
											{
											   obj_t aux_3302;
											   aux_3302 = CDR(let_part_60_1202);
											   arg1883_1203 = CDR(aux_3302);
											}
											{
											   obj_t arg1885_1205;
											   {
											      obj_t arg1888_1208;
											      arg1888_1208 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
											      arg1885_1205 = append_2_18___r4_pairs_and_lists_6_3(args_759, arg1888_1208);
											   }
											   {
											      obj_t list1886_1206;
											      list1886_1206 = MAKE_PAIR(arg1885_1205, BNIL);
											      arg1884_1204 = cons__138___r4_pairs_and_lists_6_3(body_758, list1886_1206);
											   }
											}
											SET_CAR(arg1883_1203, arg1884_1204);
										     }
										     {
											obj_t exp_3310;
											exp_3310 = let_part_60_1202;
											exp_17 = exp_3310;
											goto sexp__node_235_ast_sexp;
										     }
										  }
									       }
									     else
									       {
										  obj_t car_225_42_813;
										  car_225_42_813 = CAR(exp_17);
										  {
										     obj_t cdr_230_49_814;
										     cdr_230_49_814 = CDR(car_225_42_813);
										     {
											bool_t test_3315;
											{
											   obj_t aux_3318;
											   obj_t aux_3316;
											   aux_3318 = CNST_TABLE_REF(((long) 4));
											   aux_3316 = CAR(car_225_42_813);
											   test_3315 = (aux_3316 == aux_3318);
											}
											if (test_3315)
											  {
											     vars_763 = CAR(cdr_230_49_814);
											     body_764 = CDR(cdr_230_49_814);
											     args_765 = CDR(exp_17);
											   tag_132_226_766:
											     {
												obj_t loc_1213;
												loc_1213 = find_location_loc_243_tools_location(exp_17, loc_19);
												{
												   obj_t arg1894_1214;
												   {
												      obj_t arg1895_1215;
												      obj_t arg1896_1216;
												      obj_t arg1897_1217;
												      arg1895_1215 = CNST_TABLE_REF(((long) 7));
												      arg1896_1216 = loop_ast_sexp(exp_17, loc_1213, vars_763, args_765);
												      {
													 obj_t arg1956_1277;
													 obj_t arg1957_1278;
													 {
													    obj_t arg1959_1280;
													    arg1959_1280 = current_function_76_tools_error();
													    arg1956_1277 = shape_tools_shape(arg1959_1280);
													 }
													 arg1957_1278 = normalize_progn_143_tools_progn(body_764);
													 {
													    obj_t arg1958_2672;
													    arg1958_2672 = make_fx_procedure(arg1958_ast_sexp, ((long) 3), ((long) 1));
													    PROCEDURE_SET(arg1958_2672, ((long) 0), loc_1213);
													    arg1897_1217 = make_dsssl_function_prelude_58___dsssl(arg1956_1277, vars_763, arg1957_1278, arg1958_2672);
													 }
												      }
												      {
													 obj_t list1899_1219;
													 {
													    obj_t arg1900_1220;
													    {
													       obj_t arg1901_1221;
													       arg1901_1221 = MAKE_PAIR(BNIL, BNIL);
													       arg1900_1220 = MAKE_PAIR(arg1897_1217, arg1901_1221);
													    }
													    list1899_1219 = MAKE_PAIR(arg1896_1216, arg1900_1220);
													 }
													 arg1894_1214 = cons__138___r4_pairs_and_lists_6_3(arg1895_1215, list1899_1219);
												      }
												   }
												   {
												      obj_t loc_3335;
												      obj_t exp_3334;
												      exp_3334 = arg1894_1214;
												      loc_3335 = loc_1213;
												      loc_19 = loc_3335;
												      exp_17 = exp_3334;
												      goto sexp__node_235_ast_sexp;
												   }
												}
											     }
											  }
											else
											  {
											   tag_141_241_775:
											     {
												obj_t caller_1399;
												caller_1399 = CAR(exp_17);
												if (SYMBOLP(caller_1399))
												  {
												     obj_t pid_1401;
												     pid_1401 = parse_id_241_ast_ident(caller_1399);
												     {
													obj_t id_1402;
													id_1402 = CAR(pid_1401);
													{
													   obj_t type_1403;
													   type_1403 = CDR(pid_1401);
													   {
													      {
														 bool_t test_3345;
														 {
														    obj_t aux_3346;
														    aux_3346 = CNST_TABLE_REF(((long) 2));
														    test_3345 = (id_1402 == aux_3346);
														 }
														 if (test_3345)
														   {
														      return pragma_type__node_160_ast_pragma(((bool_t) 0), (type_t) (type_1403), exp_17, stack_18, loc_19, site_20);
														   }
														 else
														   {
														      bool_t test_3351;
														      {
															 obj_t aux_3352;
															 aux_3352 = CNST_TABLE_REF(((long) 3));
															 test_3351 = (id_1402 == aux_3352);
														      }
														      if (test_3351)
															{
															   return pragma_type__node_160_ast_pragma(((bool_t) 1), (type_t) (type_1403), exp_17, stack_18, loc_19, site_20);
															}
														      else
															{
															   bool_t test_3357;
															   {
															      obj_t aux_3358;
															      aux_3358 = CNST_TABLE_REF(((long) 4));
															      test_3357 = (id_1402 == aux_3358);
															   }
															   if (test_3357)
															     {
																obj_t args_1408;
																obj_t body_1409;
																if (PAIRP(exp_17))
																  {
																     obj_t cdr_576_84_1414;
																     cdr_576_84_1414 = CDR(exp_17);
																     if (PAIRP(cdr_576_84_1414))
																       {
																	  args_1408 = CAR(cdr_576_84_1414);
																	  body_1409 = CDR(cdr_576_84_1414);
																	  {
																	     obj_t loc_1418;
																	     loc_1418 = find_location_loc_243_tools_location(exp_17, loc_19);
																	     {
																		obj_t fun_1419;
																		{
																		   obj_t arg2084_1444;
																		   arg2084_1444 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
																		   fun_1419 = mark_symbol_non_user__17_ast_ident(arg2084_1444);
																		}
																		{
																		   obj_t tfun_1420;
																		   {
																		      obj_t list2080_1440;
																		      {
																			 obj_t arg2081_1441;
																			 {
																			    obj_t arg2082_1442;
																			    {
																			       obj_t aux_3371;
																			       {
																				  type_t obj_2484;
																				  obj_2484 = (type_t) (type_1403);
																				  aux_3371 = (((type_t) CREF(obj_2484))->id);
																			       }
																			       arg2082_1442 = MAKE_PAIR(aux_3371, BNIL);
																			    }
																			    arg2081_1441 = MAKE_PAIR(_4dots_199_tools_misc, arg2082_1442);
																			 }
																			 list2080_1440 = MAKE_PAIR(fun_1419, arg2081_1441);
																		      }
																		      tfun_1420 = symbol_append_197___r4_symbols_6_4(list2080_1440);
																		   }
																		   {
																		      {
																			 obj_t arg2060_1421;
																			 {
																			    obj_t arg2061_1422;
																			    obj_t arg2062_1423;
																			    arg2061_1422 = CNST_TABLE_REF(((long) 5));
																			    {
																			       obj_t arg2069_1429;
																			       {
																				  obj_t arg2073_1433;
																				  arg2073_1433 = normalize_progn_143_tools_progn(body_1409);
																				  {
																				     obj_t list2075_1435;
																				     {
																					obj_t arg2076_1436;
																					{
																					   obj_t arg2077_1437;
																					   arg2077_1437 = MAKE_PAIR(BNIL, BNIL);
																					   arg2076_1436 = MAKE_PAIR(arg2073_1433, arg2077_1437);
																					}
																					list2075_1435 = MAKE_PAIR(args_1408, arg2076_1436);
																				     }
																				     arg2069_1429 = cons__138___r4_pairs_and_lists_6_3(tfun_1420, list2075_1435);
																				  }
																			       }
																			       {
																				  obj_t list2071_1431;
																				  list2071_1431 = MAKE_PAIR(BNIL, BNIL);
																				  arg2062_1423 = cons__138___r4_pairs_and_lists_6_3(arg2069_1429, list2071_1431);
																			       }
																			    }
																			    {
																			       obj_t list2064_1425;
																			       {
																				  obj_t arg2065_1426;
																				  {
																				     obj_t arg2067_1427;
																				     arg2067_1427 = MAKE_PAIR(BNIL, BNIL);
																				     arg2065_1426 = MAKE_PAIR(fun_1419, arg2067_1427);
																				  }
																				  list2064_1425 = MAKE_PAIR(arg2062_1423, arg2065_1426);
																			       }
																			       arg2060_1421 = cons__138___r4_pairs_and_lists_6_3(arg2061_1422, list2064_1425);
																			    }
																			 }
																			 {
																			    obj_t loc_3391;
																			    obj_t exp_3390;
																			    exp_3390 = arg2060_1421;
																			    loc_3391 = loc_1418;
																			    loc_19 = loc_3391;
																			    exp_17 = exp_3390;
																			    goto sexp__node_235_ast_sexp;
																			 }
																		      }
																		   }
																		}
																	     }
																	  }
																       }
																     else
																       {
																	tag_569_3_1411:
																	  {
																	     obj_t arg2087_1447;
																	     arg2087_1447 = find_location_loc_243_tools_location(exp_17, loc_19);
																	     return error_sexp__node_157_ast_sexp(string2307_ast_sexp, exp_17, arg2087_1447);
																	  }
																       }
																  }
																else
																  {
																     goto tag_569_3_1411;
																  }
															     }
															   else
															     {
																return application__node_43_ast_app(exp_17, stack_18, loc_19, site_20);
															     }
															}
														   }
													      }
													   }
													}
												     }
												  }
												else
												  {
												     return application__node_43_ast_app(exp_17, stack_18, loc_19, site_20);
												  }
											     }
											  }
										     }
										  }
									       }
									  }
									else
									  {
									     obj_t car_253_251_823;
									     car_253_251_823 = CAR(exp_17);
									     {
										obj_t cdr_258_124_824;
										cdr_258_124_824 = CDR(car_253_251_823);
										{
										   bool_t test_3400;
										   {
										      obj_t aux_3403;
										      obj_t aux_3401;
										      aux_3403 = CNST_TABLE_REF(((long) 4));
										      aux_3401 = CAR(car_253_251_823);
										      test_3400 = (aux_3401 == aux_3403);
										   }
										   if (test_3400)
										     {
											obj_t args_3410;
											obj_t body_3408;
											obj_t vars_3406;
											vars_3406 = CAR(cdr_258_124_824);
											body_3408 = CDR(cdr_258_124_824);
											args_3410 = CDR(exp_17);
											args_765 = args_3410;
											body_764 = body_3408;
											vars_763 = vars_3406;
											goto tag_132_226_766;
										     }
										   else
										     {
											goto tag_141_241_775;
										     }
										}
									     }
									  }
								     }
								   else
								     {
									goto tag_141_241_775;
								     }
								}
							      else
								{
								   bool_t test_3412;
								   {
								      obj_t aux_3413;
								      aux_3413 = CNST_TABLE_REF(((long) 20));
								      test_3412 = (car_199_165_789 == aux_3413);
								   }
								   if (test_3412)
								     {
									goto kap_201_205_791;
								     }
								   else
								     {
									bool_t test_3416;
									{
									   obj_t aux_3417;
									   aux_3417 = CNST_TABLE_REF(((long) 5));
									   test_3416 = (car_199_165_789 == aux_3417);
									}
									if (test_3416)
									  {
									     goto kap_201_205_791;
									  }
									else
									  {
									     obj_t cdr_302_164_796;
									     cdr_302_164_796 = CDR(car_196_45_787);
									     {
										bool_t test_3421;
										{
										   obj_t aux_3424;
										   obj_t aux_3422;
										   aux_3424 = CNST_TABLE_REF(((long) 4));
										   aux_3422 = CAR(car_196_45_787);
										   test_3421 = (aux_3422 == aux_3424);
										}
										if (test_3421)
										  {
										     if (PAIRP(cdr_302_164_796))
										       {
											  obj_t args_3433;
											  obj_t body_3431;
											  obj_t vars_3429;
											  vars_3429 = CAR(cdr_302_164_796);
											  body_3431 = CDR(cdr_302_164_796);
											  args_3433 = CDR(exp_17);
											  args_765 = args_3433;
											  body_764 = body_3431;
											  vars_763 = vars_3429;
											  goto tag_132_226_766;
										       }
										     else
										       {
											  goto tag_141_241_775;
										       }
										  }
										else
										  {
										     goto tag_141_241_775;
										  }
									     }
									  }
								     }
								}
							   }
							}
						     }
						   else
						     {
							bool_t test_3435;
							{
							   obj_t aux_3436;
							   aux_3436 = CNST_TABLE_REF(((long) 7));
							   test_3435 = (car_196_45_787 == aux_3436);
							}
							if (test_3435)
							  {
							   tag_130_214_761:
							     return let__node_121_ast_let(exp_17, stack_18, loc_19, CNST_TABLE_REF(((long) 1)));
							  }
							else
							  {
							     bool_t test_3441;
							     {
								obj_t aux_3442;
								aux_3442 = CNST_TABLE_REF(((long) 20));
								test_3441 = (car_196_45_787 == aux_3442);
							     }
							     if (test_3441)
							       {
								  goto tag_130_214_761;
							       }
							     else
							       {
								  bool_t test_3445;
								  {
								     obj_t aux_3446;
								     aux_3446 = CNST_TABLE_REF(((long) 5));
								     test_3445 = (car_196_45_787 == aux_3446);
								  }
								  if (test_3445)
								    {
								       let_fun_218_t aux_3449;
								       aux_3449 = labels__node_197_ast_labels(exp_17, stack_18, loc_19, CNST_TABLE_REF(((long) 1)));
								       return (node_t) (aux_3449);
								    }
								  else
								    {
								       bool_t test_3453;
								       {
									  obj_t aux_3454;
									  aux_3454 = CNST_TABLE_REF(((long) 4));
									  test_3453 = (car_196_45_787 == aux_3454);
								       }
								       if (test_3453)
									 {
									    {
									       obj_t args_1287;
									       obj_t body_1288;
									       if (PAIRP(exp_17))
										 {
										    obj_t cdr_520_55_1293;
										    cdr_520_55_1293 = CDR(exp_17);
										    if (PAIRP(cdr_520_55_1293))
										      {
											 args_1287 = CAR(cdr_520_55_1293);
											 body_1288 = CDR(cdr_520_55_1293);
											 {
											    obj_t loc_1297;
											    loc_1297 = find_location_loc_243_tools_location(exp_17, loc_19);
											    {
											       obj_t fun_1298;
											       fun_1298 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
											       {
												  {
												     obj_t arg1967_1299;
												     {
													obj_t arg1970_1300;
													obj_t arg1971_1301;
													arg1970_1300 = CNST_TABLE_REF(((long) 5));
													{
													   obj_t arg1978_1307;
													   {
													      obj_t arg1982_1311;
													      arg1982_1311 = normalize_progn_143_tools_progn(body_1288);
													      {
														 obj_t list1984_1313;
														 {
														    obj_t arg1985_1314;
														    {
														       obj_t arg1986_1315;
														       arg1986_1315 = MAKE_PAIR(BNIL, BNIL);
														       arg1985_1314 = MAKE_PAIR(arg1982_1311, arg1986_1315);
														    }
														    list1984_1313 = MAKE_PAIR(args_1287, arg1985_1314);
														 }
														 arg1978_1307 = cons__138___r4_pairs_and_lists_6_3(fun_1298, list1984_1313);
													      }
													   }
													   {
													      obj_t list1980_1309;
													      list1980_1309 = MAKE_PAIR(BNIL, BNIL);
													      arg1971_1301 = cons__138___r4_pairs_and_lists_6_3(arg1978_1307, list1980_1309);
													   }
													}
													{
													   obj_t list1973_1303;
													   {
													      obj_t arg1974_1304;
													      {
														 obj_t arg1975_1305;
														 arg1975_1305 = MAKE_PAIR(BNIL, BNIL);
														 arg1974_1304 = MAKE_PAIR(fun_1298, arg1975_1305);
													      }
													      list1973_1303 = MAKE_PAIR(arg1971_1301, arg1974_1304);
													   }
													   arg1967_1299 = cons__138___r4_pairs_and_lists_6_3(arg1970_1300, list1973_1303);
													}
												     }
												     {
													obj_t loc_3479;
													obj_t exp_3478;
													exp_3478 = arg1967_1299;
													loc_3479 = loc_1297;
													loc_19 = loc_3479;
													exp_17 = exp_3478;
													goto sexp__node_235_ast_sexp;
												     }
												  }
											       }
											    }
											 }
										      }
										    else
										      {
										       tag_513_88_1290:
											 {
											    obj_t arg1990_1319;
											    arg1990_1319 = find_location_loc_243_tools_location(exp_17, loc_19);
											    return error_sexp__node_157_ast_sexp(string2307_ast_sexp, exp_17, arg1990_1319);
											 }
										      }
										 }
									       else
										 {
										    goto tag_513_88_1290;
										 }
									    }
									 }
								       else
									 {
									    bool_t test_3484;
									    {
									       obj_t aux_3485;
									       aux_3485 = CNST_TABLE_REF(((long) 2));
									       test_3484 = (car_196_45_787 == aux_3485);
									    }
									    if (test_3484)
									      {
										 return pragma_type__node_160_ast_pragma(((bool_t) 0), (type_t) (_unspec__87_type_cache), exp_17, stack_18, loc_19, site_20);
									      }
									    else
									      {
										 bool_t test_3490;
										 {
										    obj_t aux_3491;
										    aux_3491 = CNST_TABLE_REF(((long) 3));
										    test_3490 = (car_196_45_787 == aux_3491);
										 }
										 if (test_3490)
										   {
										      return pragma_type__node_160_ast_pragma(((bool_t) 1), (type_t) (_unspec__87_type_cache), exp_17, stack_18, loc_19, site_20);
										   }
										 else
										   {
										      bool_t test_3496;
										      {
											 obj_t aux_3497;
											 aux_3497 = CNST_TABLE_REF(((long) 21));
											 test_3496 = (car_196_45_787 == aux_3497);
										      }
										      if (test_3496)
											{
											   obj_t aux_3500;
											   {
											      obj_t proc_1320;
											      obj_t msg_1321;
											      obj_t obj_1322;
											      if (PAIRP(exp_17))
												{
												   obj_t cdr_537_243_1327;
												   cdr_537_243_1327 = CDR(exp_17);
												   if (PAIRP(cdr_537_243_1327))
												     {
													obj_t cdr_542_204_1329;
													cdr_542_204_1329 = CDR(cdr_537_243_1327);
													if (PAIRP(cdr_542_204_1329))
													  {
													     obj_t cdr_547_94_1331;
													     cdr_547_94_1331 = CDR(cdr_542_204_1329);
													     if (PAIRP(cdr_547_94_1331))
													       {
														  bool_t test_3512;
														  {
														     obj_t aux_3513;
														     aux_3513 = CDR(cdr_547_94_1331);
														     test_3512 = (aux_3513 == BNIL);
														  }
														  if (test_3512)
														    {
														       fail_t aux_3516;
														       proc_1320 = CAR(cdr_537_243_1327);
														       msg_1321 = CAR(cdr_542_204_1329);
														       obj_1322 = CAR(cdr_547_94_1331);
														       {
															  obj_t loc_1339;
															  loc_1339 = find_location_loc_243_tools_location(exp_17, loc_19);
															  {
															     obj_t loc_proc_248_1340;
															     loc_proc_248_1340 = find_location_loc_243_tools_location(proc_1320, loc_1339);
															     {
																obj_t loc_msg_36_1341;
																loc_msg_36_1341 = find_location_loc_243_tools_location(msg_1321, loc_1339);
																{
																   obj_t loc_obj_88_1342;
																   loc_obj_88_1342 = find_location_loc_243_tools_location(obj_1322, loc_1339);
																   {
																      node_t proc_1343;
																      proc_1343 = sexp__node_235_ast_sexp(proc_1320, stack_18, loc_proc_248_1340, CNST_TABLE_REF(((long) 1)));
																      {
																	 node_t msg_1344;
																	 msg_1344 = sexp__node_235_ast_sexp(msg_1321, stack_18, loc_msg_36_1341, CNST_TABLE_REF(((long) 1)));
																	 {
																	    node_t obj_1345;
																	    obj_1345 = sexp__node_235_ast_sexp(obj_1322, stack_18, loc_obj_88_1342, CNST_TABLE_REF(((long) 1)));
																	    {
																	       {
																		  obj_t arg2006_1347;
																		  arg2006_1347 = _magic__144_type_cache;
																		  {
																		     fail_t res2296_2430;
																		     {
																			type_t type_2417;
																			type_2417 = (type_t) (arg2006_1347);
																			{
																			   fail_t new1325_2421;
																			   new1325_2421 = ((fail_t) BREF(GC_MALLOC(sizeof(struct fail))));
																			   {
																			      long arg2219_2422;
																			      arg2219_2422 = class_num_218___object(fail_ast_node);
																			      {
																				 obj_t obj_2428;
																				 obj_2428 = (obj_t) (new1325_2421);
																				 (((obj_t) CREF(obj_2428))->header = MAKE_HEADER(arg2219_2422, 0), BUNSPEC);
																			      }
																			   }
																			   {
																			      object_t aux_3532;
																			      aux_3532 = (object_t) (new1325_2421);
																			      OBJECT_WIDENING_SET(aux_3532, BFALSE);
																			   }
																			   ((((fail_t) CREF(new1325_2421))->loc) = ((obj_t) loc_1339), BUNSPEC);
																			   ((((fail_t) CREF(new1325_2421))->type) = ((type_t) type_2417), BUNSPEC);
																			   ((((fail_t) CREF(new1325_2421))->proc) = ((node_t) proc_1343), BUNSPEC);
																			   ((((fail_t) CREF(new1325_2421))->msg) = ((node_t) msg_1344), BUNSPEC);
																			   ((((fail_t) CREF(new1325_2421))->obj) = ((node_t) obj_1345), BUNSPEC);
																			   res2296_2430 = new1325_2421;
																			}
																		     }
																		     aux_3516 = res2296_2430;
																		  }
																	       }
																	    }
																	 }
																      }
																   }
																}
															     }
															  }
														       }
														       aux_3500 = (obj_t) (aux_3516);
														    }
														  else
														    {
														       node_t aux_3544;
														     tag_528_229_1324:
														       {
															  obj_t arg2016_1355;
															  arg2016_1355 = find_location_loc_243_tools_location(exp_17, loc_19);
															  aux_3544 = error_sexp__node_157_ast_sexp(string2309_ast_sexp, exp_17, arg2016_1355);
														       }
														       aux_3500 = (obj_t) (aux_3544);
														    }
													       }
													     else
													       {
														  node_t aux_3548;
														  goto tag_528_229_1324;
														  aux_3500 = (obj_t) (aux_3548);
													       }
													  }
													else
													  {
													     node_t aux_3550;
													     goto tag_528_229_1324;
													     aux_3500 = (obj_t) (aux_3550);
													  }
												     }
												   else
												     {
													node_t aux_3552;
													goto tag_528_229_1324;
													aux_3500 = (obj_t) (aux_3552);
												     }
												}
											      else
												{
												   node_t aux_3554;
												   goto tag_528_229_1324;
												   aux_3500 = (obj_t) (aux_3554);
												}
											   }
											   return (node_t) (aux_3500);
											}
										      else
											{
											   bool_t test_3557;
											   {
											      obj_t aux_3558;
											      aux_3558 = CNST_TABLE_REF(((long) 22));
											      test_3557 = (car_196_45_787 == aux_3558);
											   }
											   if (test_3557)
											     {
												obj_t aux_3561;
												{
												   obj_t test_1356;
												   obj_t clauses_1357;
												   if (PAIRP(exp_17))
												     {
													obj_t cdr_561_35_1362;
													cdr_561_35_1362 = CDR(exp_17);
													if (PAIRP(cdr_561_35_1362))
													  {
													     test_1356 = CAR(cdr_561_35_1362);
													     clauses_1357 = CDR(cdr_561_35_1362);
													     {
														obj_t loc_1366;
														loc_1366 = find_location_loc_243_tools_location(exp_17, loc_19);
														{
														   node_t test_1367;
														   {
														      obj_t arg2048_1395;
														      obj_t arg2049_1396;
														      arg2048_1395 = find_location_loc_243_tools_location(test_1356, loc_1366);
														      arg2049_1396 = CNST_TABLE_REF(((long) 1));
														      test_1367 = sexp__node_235_ast_sexp(test_1356, stack_18, arg2048_1395, arg2049_1396);
														   }
														   {
														      {
															 obj_t cls_1368;
															 cls_1368 = clauses_1357;
														       loop_1369:
															 if (NULLP(cls_1368))
															   {
															      obj_t arg2023_1372;
															      type_t arg2028_1376;
															      arg2023_1372 = ____74_type_cache;
															      {
																 obj_t aux_3573;
																 {
																    obj_t aux_3574;
																    {
																       obj_t aux_3575;
																       aux_3575 = CAR(clauses_1357);
																       aux_3574 = CAR(aux_3575);
																    }
																    aux_3573 = CAR(aux_3574);
																 }
																 arg2028_1376 = typeof_atom_134_type_typeof(aux_3573);
															      }
															      {
																 select_t res2297_2458;
																 {
																    type_t type_2441;
																    obj_t key_2443;
																    type_2441 = (type_t) (arg2023_1372);
																    key_2443 = BINT(((long) -1));
																    {
																       select_t new1337_2447;
																       new1337_2447 = ((select_t) BREF(GC_MALLOC(sizeof(struct select))));
																       {
																	  long arg2216_2448;
																	  arg2216_2448 = class_num_218___object(select_ast_node);
																	  {
																	     obj_t obj_2456;
																	     obj_2456 = (obj_t) (new1337_2447);
																	     (((obj_t) CREF(obj_2456))->header = MAKE_HEADER(arg2216_2448, 0), BUNSPEC);
																	  }
																       }
																       {
																	  object_t aux_3586;
																	  aux_3586 = (object_t) (new1337_2447);
																	  OBJECT_WIDENING_SET(aux_3586, BFALSE);
																       }
																       ((((select_t) CREF(new1337_2447))->loc) = ((obj_t) loc_1366), BUNSPEC);
																       ((((select_t) CREF(new1337_2447))->type) = ((type_t) type_2441), BUNSPEC);
																       ((((select_t) CREF(new1337_2447))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
																       ((((select_t) CREF(new1337_2447))->key) = ((obj_t) key_2443), BUNSPEC);
																       ((((select_t) CREF(new1337_2447))->test) = ((node_t) test_1367), BUNSPEC);
																       ((((select_t) CREF(new1337_2447))->clauses) = ((obj_t) clauses_1357), BUNSPEC);
																       ((((select_t) CREF(new1337_2447))->item_type_130) = ((type_t) arg2028_1376), BUNSPEC);
																       res2297_2458 = new1337_2447;
																    }
																 }
																 aux_3561 = (obj_t) (res2297_2458);
															      }
															   }
															 else
															   {
															      obj_t clause_1380;
															      clause_1380 = CAR(cls_1368);
															      {
																 node_t arg2032_1381;
																 {
																    obj_t arg2033_1382;
																    obj_t arg2035_1383;
																    obj_t arg2037_1384;
																    arg2033_1382 = normalize_progn_143_tools_progn(CDR(clause_1380));
																    arg2035_1383 = find_location_loc_243_tools_location(clause_1380, loc_1366);
																    arg2037_1384 = CNST_TABLE_REF(((long) 1));
																    arg2032_1381 = sexp__node_235_ast_sexp(arg2033_1382, stack_18, arg2035_1383, arg2037_1384);
																 }
																 {
																    obj_t aux_3603;
																    aux_3603 = (obj_t) (arg2032_1381);
																    SET_CDR(clause_1380, aux_3603);
																 }
															      }
															      {
																 bool_t test_3606;
																 {
																    bool_t test_3607;
																    {
																       obj_t aux_3610;
																       obj_t aux_3608;
																       aux_3610 = CNST_TABLE_REF(((long) 6));
																       aux_3608 = CAR(clause_1380);
																       test_3607 = (aux_3608 == aux_3610);
																    }
																    if (test_3607)
																      {
																	 bool_t test_3613;
																	 {
																	    obj_t aux_3614;
																	    aux_3614 = CDR(cls_1368);
																	    test_3613 = NULLP(aux_3614);
																	 }
																	 if (test_3613)
																	   {
																	      test_3606 = ((bool_t) 0);
																	   }
																	 else
																	   {
																	      test_3606 = ((bool_t) 1);
																	   }
																      }
																    else
																      {
																	 test_3606 = ((bool_t) 0);
																      }
																 }
																 if (test_3606)
																   {
																      obj_t arg2041_1388;
																      arg2041_1388 = find_location_loc_243_tools_location(exp_17, loc_1366);
																      {
																	 node_t aux_3618;
																	 aux_3618 = error_sexp__node_157_ast_sexp(string2308_ast_sexp, arg2041_1388, exp_17);
																	 aux_3561 = (obj_t) (aux_3618);
																      }
																   }
																 else
																   {
																      obj_t cls_3621;
																      cls_3621 = CDR(cls_1368);
																      cls_1368 = cls_3621;
																      goto loop_1369;
																   }
															      }
															   }
														      }
														   }
														}
													     }
													  }
													else
													  {
													     node_t aux_3625;
													   tag_554_132_1359:
													     {
														obj_t arg2051_1398;
														arg2051_1398 = find_location_loc_243_tools_location(exp_17, loc_19);
														aux_3625 = error_sexp__node_157_ast_sexp(string2308_ast_sexp, arg2051_1398, exp_17);
													     }
													     aux_3561 = (obj_t) (aux_3625);
													  }
												     }
												   else
												     {
													node_t aux_3629;
													goto tag_554_132_1359;
													aux_3561 = (obj_t) (aux_3629);
												     }
												}
												return (node_t) (aux_3561);
											     }
											   else
											     {
												bool_t test_3632;
												{
												   obj_t aux_3633;
												   aux_3633 = CNST_TABLE_REF(((long) 23));
												   test_3632 = (car_196_45_787 == aux_3633);
												}
												if (test_3632)
												  {
												     let_fun_218_t aux_3636;
												     aux_3636 = set_exit__node_102_ast_exit(exp_17, stack_18, loc_19, site_20);
												     return (node_t) (aux_3636);
												  }
												else
												  {
												     bool_t test_3639;
												     {
													obj_t aux_3640;
													aux_3640 = CNST_TABLE_REF(((long) 24));
													test_3639 = (car_196_45_787 == aux_3640);
												     }
												     if (test_3639)
												       {
													  jump_ex_it_184_t aux_3643;
													  aux_3643 = jump_exit__node_34_ast_exit(exp_17, stack_18, loc_19, site_20);
													  return (node_t) (aux_3643);
												       }
												     else
												       {
													  bool_t test_3646;
													  {
													     obj_t aux_3647;
													     aux_3647 = CNST_TABLE_REF(((long) 25));
													     test_3646 = (car_196_45_787 == aux_3647);
													  }
													  if (test_3646)
													    {
													       return applycation__node_122_ast_apply(exp_17, stack_18, loc_19, site_20);
													    }
													  else
													    {
													       goto tag_141_241_775;
													    }
												       }
												  }
											     }
											}
										   }
									      }
									 }
								    }
							       }
							  }
						     }
						}
					   }
				      }
				 }
			    }
		       }
		  }
		else
		  {
		     obj_t aux_3651;
		     atom_749 = exp_17;
		     if (SYMBOLP(atom_749))
		       {
			  bool_t test1585_877;
			  {
			     obj_t aux_3654;
			     aux_3654 = lookup_ast_sexp(atom_749, stack_18);
			     test1585_877 = CBOOL(aux_3654);
			  }
			  if (test1585_877)
			    {
			       {
				  obj_t local_878;
				  local_878 = lookup_ast_sexp(atom_749, stack_18);
				  {
				     obj_t var_879;
				     {
					bool_t test1586_880;
					{
					   bool_t test_3659;
					   {
					      obj_t aux_3660;
					      aux_3660 = CNST_TABLE_REF(((long) 15));
					      test_3659 = (site_20 == aux_3660);
					   }
					   if (test_3659)
					     {
						test1586_880 = ((bool_t) 0);
					     }
					   else
					     {
						obj_t aux_3663;
						{
						   value_t aux_3664;
						   {
						      local_t obj_2005;
						      obj_2005 = (local_t) (local_878);
						      aux_3664 = (((local_t) CREF(obj_2005))->value);
						   }
						   aux_3663 = (obj_t) (aux_3664);
						}
						test1586_880 = is_a__118___object(aux_3663, fun_ast_var);
					     }
					}
					if (test1586_880)
					  {
					     type_t arg1588_882;
					     {
						local_t obj_2007;
						obj_2007 = (local_t) (local_878);
						arg1588_882 = (((local_t) CREF(obj_2007))->type);
					     }
					     {
						closure_t res2280_2018;
						{
						   variable_t variable_2010;
						   variable_2010 = (variable_t) (local_878);
						   {
						      closure_t new1214_2011;
						      new1214_2011 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
						      {
							 long arg2239_2012;
							 arg2239_2012 = class_num_218___object(closure_ast_node);
							 {
							    obj_t obj_2016;
							    obj_2016 = (obj_t) (new1214_2011);
							    (((obj_t) CREF(obj_2016))->header = MAKE_HEADER(arg2239_2012, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_3677;
							 aux_3677 = (object_t) (new1214_2011);
							 OBJECT_WIDENING_SET(aux_3677, BFALSE);
						      }
						      ((((closure_t) CREF(new1214_2011))->loc) = ((obj_t) loc_19), BUNSPEC);
						      ((((closure_t) CREF(new1214_2011))->type) = ((type_t) arg1588_882), BUNSPEC);
						      ((((closure_t) CREF(new1214_2011))->variable) = ((variable_t) variable_2010), BUNSPEC);
						      res2280_2018 = new1214_2011;
						   }
						}
						var_879 = (obj_t) (res2280_2018);
					     }
					  }
					else
					  {
					     type_t arg1593_885;
					     {
						local_t obj_2019;
						obj_2019 = (local_t) (local_878);
						arg1593_885 = (((local_t) CREF(obj_2019))->type);
					     }
					     {
						var_t res2281_2030;
						{
						   variable_t variable_2022;
						   variable_2022 = (variable_t) (local_878);
						   {
						      var_t new1206_2023;
						      new1206_2023 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						      {
							 long arg2241_2024;
							 arg2241_2024 = class_num_218___object(var_ast_node);
							 {
							    obj_t obj_2028;
							    obj_2028 = (obj_t) (new1206_2023);
							    (((obj_t) CREF(obj_2028))->header = MAKE_HEADER(arg2241_2024, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_3691;
							 aux_3691 = (object_t) (new1206_2023);
							 OBJECT_WIDENING_SET(aux_3691, BFALSE);
						      }
						      ((((var_t) CREF(new1206_2023))->loc) = ((obj_t) loc_19), BUNSPEC);
						      ((((var_t) CREF(new1206_2023))->type) = ((type_t) arg1593_885), BUNSPEC);
						      ((((var_t) CREF(new1206_2023))->variable) = ((variable_t) variable_2022), BUNSPEC);
						      res2281_2030 = new1206_2023;
						   }
						}
						var_879 = (obj_t) (res2281_2030);
					     }
					  }
				     }
				     {
					use_variable__4_ast_sexp((variable_t) (local_878), loc_19, site_20);
					aux_3651 = var_879;
				     }
				  }
			       }
			    }
			  else
			    {
			       {
				  obj_t global_890;
				  global_890 = find_global_223_ast_env(atom_749, BNIL);
				  {
				     bool_t test1601_891;
				     test1601_891 = is_a__118___object(global_890, global_ast_var);
				     if (test1601_891)
				       {
					  bool_t test_3703;
					  {
					     obj_t aux_3707;
					     obj_t aux_3704;
					     aux_3707 = CNST_TABLE_REF(((long) 14));
					     {
						global_t obj_2032;
						obj_2032 = (global_t) (global_890);
						aux_3704 = (((global_t) CREF(obj_2032))->import);
					     }
					     test_3703 = (aux_3704 == aux_3707);
					  }
					  if (test_3703)
					    {
					       {
						  obj_t arg1603_893;
						  {
						     obj_t arg1605_894;
						     obj_t arg1606_895;
						     arg1605_894 = CNST_TABLE_REF(((long) 14));
						     {
							obj_t arg1612_900;
							arg1612_900 = CNST_TABLE_REF(((long) 17));
							{
							   obj_t list1614_902;
							   {
							      obj_t arg1615_903;
							      arg1615_903 = MAKE_PAIR(BNIL, BNIL);
							      list1614_902 = MAKE_PAIR(atom_749, arg1615_903);
							   }
							   arg1606_895 = cons__138___r4_pairs_and_lists_6_3(arg1612_900, list1614_902);
							}
						     }
						     {
							obj_t list1608_897;
							{
							   obj_t arg1609_898;
							   arg1609_898 = MAKE_PAIR(BNIL, BNIL);
							   list1608_897 = MAKE_PAIR(arg1606_895, arg1609_898);
							}
							arg1603_893 = cons__138___r4_pairs_and_lists_6_3(arg1605_894, list1608_897);
						     }
						  }
						  {
						     node_t aux_3718;
						     aux_3718 = sexp__node_235_ast_sexp(arg1603_893, stack_18, loc_19, site_20);
						     aux_3651 = (obj_t) (aux_3718);
						  }
					       }
					    }
					  else
					    {
					       use_variable__4_ast_sexp((variable_t) (global_890), loc_19, site_20);
					       {
						  bool_t test1618_905;
						  {
						     bool_t test_3723;
						     {
							obj_t aux_3724;
							aux_3724 = CNST_TABLE_REF(((long) 15));
							test_3723 = (site_20 == aux_3724);
						     }
						     if (test_3723)
						       {
							  test1618_905 = ((bool_t) 0);
						       }
						     else
						       {
							  obj_t aux_3727;
							  {
							     value_t aux_3728;
							     {
								global_t obj_2037;
								obj_2037 = (global_t) (global_890);
								aux_3728 = (((global_t) CREF(obj_2037))->value);
							     }
							     aux_3727 = (obj_t) (aux_3728);
							  }
							  test1618_905 = is_a__118___object(aux_3727, fun_ast_var);
						       }
						  }
						  if (test1618_905)
						    {
						       type_t arg1621_907;
						       {
							  global_t obj_2039;
							  obj_2039 = (global_t) (global_890);
							  arg1621_907 = (((global_t) CREF(obj_2039))->type);
						       }
						       {
							  closure_t res2282_2050;
							  {
							     variable_t variable_2042;
							     variable_2042 = (variable_t) (global_890);
							     {
								closure_t new1214_2043;
								new1214_2043 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
								{
								   long arg2239_2044;
								   arg2239_2044 = class_num_218___object(closure_ast_node);
								   {
								      obj_t obj_2048;
								      obj_2048 = (obj_t) (new1214_2043);
								      (((obj_t) CREF(obj_2048))->header = MAKE_HEADER(arg2239_2044, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_3741;
								   aux_3741 = (object_t) (new1214_2043);
								   OBJECT_WIDENING_SET(aux_3741, BFALSE);
								}
								((((closure_t) CREF(new1214_2043))->loc) = ((obj_t) loc_19), BUNSPEC);
								((((closure_t) CREF(new1214_2043))->type) = ((type_t) arg1621_907), BUNSPEC);
								((((closure_t) CREF(new1214_2043))->variable) = ((variable_t) variable_2042), BUNSPEC);
								res2282_2050 = new1214_2043;
							     }
							  }
							  aux_3651 = (obj_t) (res2282_2050);
						       }
						    }
						  else
						    {
						       type_t arg1624_910;
						       {
							  global_t obj_2051;
							  obj_2051 = (global_t) (global_890);
							  arg1624_910 = (((global_t) CREF(obj_2051))->type);
						       }
						       {
							  var_t res2283_2062;
							  {
							     variable_t variable_2054;
							     variable_2054 = (variable_t) (global_890);
							     {
								var_t new1206_2055;
								new1206_2055 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								{
								   long arg2241_2056;
								   arg2241_2056 = class_num_218___object(var_ast_node);
								   {
								      obj_t obj_2060;
								      obj_2060 = (obj_t) (new1206_2055);
								      (((obj_t) CREF(obj_2060))->header = MAKE_HEADER(arg2241_2056, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_3755;
								   aux_3755 = (object_t) (new1206_2055);
								   OBJECT_WIDENING_SET(aux_3755, BFALSE);
								}
								((((var_t) CREF(new1206_2055))->loc) = ((obj_t) loc_19), BUNSPEC);
								((((var_t) CREF(new1206_2055))->type) = ((type_t) arg1624_910), BUNSPEC);
								((((var_t) CREF(new1206_2055))->variable) = ((variable_t) variable_2054), BUNSPEC);
								res2283_2062 = new1206_2055;
							     }
							  }
							  aux_3651 = (obj_t) (res2283_2062);
						       }
						    }
					       }
					    }
				       }
				     else
				       {
					  {
					     node_t aux_3762;
					     aux_3762 = error_sexp__node_157_ast_sexp(string2317_ast_sexp, exp_17, loc_19);
					     aux_3651 = (obj_t) (aux_3762);
					  }
				       }
				  }
			       }
			    }
		       }
		     else
		       {
			  {
			     bool_t test1634_918;
			     {
				bool_t test1656_935;
				test1656_935 = is_a__118___object(atom_749, local_ast_var);
				if (test1656_935)
				  {
				     test1634_918 = ((bool_t) 1);
				  }
				else
				  {
				     test1634_918 = is_a__118___object(atom_749, global_ast_var);
				  }
			     }
			     if (test1634_918)
			       {
				  use_variable__4_ast_sexp((variable_t) (atom_749), loc_19, site_20);
				  {
				     bool_t test1635_919;
				     {
					bool_t test_3771;
					{
					   obj_t aux_3772;
					   aux_3772 = CNST_TABLE_REF(((long) 15));
					   test_3771 = (site_20 == aux_3772);
					}
					if (test_3771)
					  {
					     test1635_919 = ((bool_t) 0);
					  }
					else
					  {
					     obj_t aux_3775;
					     {
						value_t aux_3776;
						{
						   variable_t obj_2067;
						   obj_2067 = (variable_t) (atom_749);
						   aux_3776 = (((variable_t) CREF(obj_2067))->value);
						}
						aux_3775 = (obj_t) (aux_3776);
					     }
					     test1635_919 = is_a__118___object(aux_3775, fun_ast_var);
					  }
				     }
				     if (test1635_919)
				       {
					  type_t arg1638_921;
					  {
					     variable_t obj_2069;
					     obj_2069 = (variable_t) (atom_749);
					     arg1638_921 = (((variable_t) CREF(obj_2069))->type);
					  }
					  {
					     closure_t res2284_2080;
					     {
						variable_t variable_2072;
						variable_2072 = (variable_t) (atom_749);
						{
						   closure_t new1214_2073;
						   new1214_2073 = ((closure_t) BREF(GC_MALLOC(sizeof(struct closure))));
						   {
						      long arg2239_2074;
						      arg2239_2074 = class_num_218___object(closure_ast_node);
						      {
							 obj_t obj_2078;
							 obj_2078 = (obj_t) (new1214_2073);
							 (((obj_t) CREF(obj_2078))->header = MAKE_HEADER(arg2239_2074, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_3789;
						      aux_3789 = (object_t) (new1214_2073);
						      OBJECT_WIDENING_SET(aux_3789, BFALSE);
						   }
						   ((((closure_t) CREF(new1214_2073))->loc) = ((obj_t) loc_19), BUNSPEC);
						   ((((closure_t) CREF(new1214_2073))->type) = ((type_t) arg1638_921), BUNSPEC);
						   ((((closure_t) CREF(new1214_2073))->variable) = ((variable_t) variable_2072), BUNSPEC);
						   res2284_2080 = new1214_2073;
						}
					     }
					     aux_3651 = (obj_t) (res2284_2080);
					  }
				       }
				     else
				       {
					  type_t arg1641_924;
					  {
					     variable_t obj_2081;
					     obj_2081 = (variable_t) (atom_749);
					     arg1641_924 = (((variable_t) CREF(obj_2081))->type);
					  }
					  {
					     var_t res2285_2092;
					     {
						variable_t variable_2084;
						variable_2084 = (variable_t) (atom_749);
						{
						   var_t new1206_2085;
						   new1206_2085 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						   {
						      long arg2241_2086;
						      arg2241_2086 = class_num_218___object(var_ast_node);
						      {
							 obj_t obj_2090;
							 obj_2090 = (obj_t) (new1206_2085);
							 (((obj_t) CREF(obj_2090))->header = MAKE_HEADER(arg2241_2086, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_3803;
						      aux_3803 = (object_t) (new1206_2085);
						      OBJECT_WIDENING_SET(aux_3803, BFALSE);
						   }
						   ((((var_t) CREF(new1206_2085))->loc) = ((obj_t) loc_19), BUNSPEC);
						   ((((var_t) CREF(new1206_2085))->type) = ((type_t) arg1641_924), BUNSPEC);
						   ((((var_t) CREF(new1206_2085))->variable) = ((variable_t) variable_2084), BUNSPEC);
						   res2285_2092 = new1206_2085;
						}
					     }
					     aux_3651 = (obj_t) (res2285_2092);
					  }
				       }
				  }
			       }
			     else
			       {
				  bool_t test1649_929;
				  if (STRUCTP(atom_749))
				    {
				       test1649_929 = ((bool_t) 1);
				    }
				  else
				    {
				       if (VECTORP(atom_749))
					 {
					    test1649_929 = ((bool_t) 1);
					 }
				       else
					 {
					    test1649_929 = (POINTERP(atom_749) && (TYPE(atom_749) >= OBJECT_TYPE));
					 }
				    }
				  if (test1649_929)
				    {
				       {
					  node_t aux_3816;
					  aux_3816 = error_sexp__node_157_ast_sexp(string2318_ast_sexp, exp_17, loc_19);
					  aux_3651 = (obj_t) (aux_3816);
				       }
				    }
				  else
				    {
				       {
					  type_t arg1652_931;
					  arg1652_931 = typeof_atom_134_type_typeof(atom_749);
					  {
					     atom_t res2286_2106;
					     {
						atom_t new1198_2099;
						new1198_2099 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
						{
						   long arg2244_2100;
						   arg2244_2100 = class_num_218___object(atom_ast_node);
						   {
						      obj_t obj_2104;
						      obj_2104 = (obj_t) (new1198_2099);
						      (((obj_t) CREF(obj_2104))->header = MAKE_HEADER(arg2244_2100, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_3824;
						   aux_3824 = (object_t) (new1198_2099);
						   OBJECT_WIDENING_SET(aux_3824, BFALSE);
						}
						((((atom_t) CREF(new1198_2099))->loc) = ((obj_t) loc_19), BUNSPEC);
						((((atom_t) CREF(new1198_2099))->type) = ((type_t) arg1652_931), BUNSPEC);
						((((atom_t) CREF(new1198_2099))->value) = ((obj_t) atom_749), BUNSPEC);
						res2286_2106 = new1198_2099;
					     }
					     aux_3651 = (obj_t) (res2286_2106);
					  }
				       }
				    }
			       }
			  }
		       }
		     return (node_t) (aux_3651);
		  }
	     }
	}
   }
}


/* liip */ obj_t 
liip_ast_sexp(obj_t args_1265)
{
   if (NULLP(args_1265))
     {
	return CNST_TABLE_REF(((long) 26));
     }
   else
     {
	obj_t arg1945_1268;
	obj_t arg1947_1269;
	obj_t arg1948_1270;
	arg1945_1268 = CNST_TABLE_REF(((long) 27));
	arg1947_1269 = CAR(args_1265);
	arg1948_1270 = liip_ast_sexp(CDR(args_1265));
	{
	   obj_t list1950_1272;
	   {
	      obj_t arg1951_1273;
	      {
		 obj_t arg1952_1274;
		 arg1952_1274 = MAKE_PAIR(BNIL, BNIL);
		 arg1951_1273 = MAKE_PAIR(arg1948_1270, arg1952_1274);
	      }
	      list1950_1272 = MAKE_PAIR(arg1947_1269, arg1951_1273);
	   }
	   return cons__138___r4_pairs_and_lists_6_3(arg1945_1268, list1950_1272);
	}
     }
}


/* loop */ obj_t 
loop_ast_sexp(obj_t exp_2699, obj_t loc_2698, obj_t vars_1223, obj_t args_1224)
{
 loop_ast_sexp:
   if (NULLP(vars_1223))
     {
	if (NULLP(args_1224))
	  {
	     return BNIL;
	  }
	else
	  {
	     obj_t arg1905_1228;
	     {
		obj_t arg1909_1231;
		arg1909_1231 = current_function_76_tools_error();
		arg1905_1228 = shape_tools_shape(arg1909_1231);
	     }
	     return user_error_location_137_tools_error(loc_2698, arg1905_1228, string2320_ast_sexp, exp_2699, BNIL);
	  }
     }
   else
     {
	if (PAIRP(vars_1223))
	  {
	     bool_t test1911_1233;
	     {
		obj_t aux_3852;
		aux_3852 = dsssl_named_constant__188_tools_dsssl(CAR(vars_1223));
		test1911_1233 = CBOOL(aux_3852);
	     }
	     if (test1911_1233)
	       {
		  {
		     obj_t arg_1234;
		     arg_1234 = dsssl_find_first_formal_237_tools_dsssl(CDR(vars_1223));
		     if (CBOOL(arg_1234))
		       {
			  obj_t vars_3861;
			  vars_3861 = arg_1234;
			  vars_1223 = vars_3861;
			  goto loop_ast_sexp;
		       }
		     else
		       {
			  obj_t vars_3862;
			  vars_3862 = BNIL;
			  vars_1223 = vars_3862;
			  goto loop_ast_sexp;
		       }
		  }
	       }
	     else
	       {
		  bool_t test_3863;
		  {
		     obj_t aux_3864;
		     aux_3864 = CAR(vars_1223);
		     test_3863 = SYMBOLP(aux_3864);
		  }
		  if (test_3863)
		    {
		       if (NULLP(args_1224))
			 {
			    {
			       obj_t arg1916_1239;
			       {
				  obj_t arg1919_1242;
				  arg1919_1242 = current_function_76_tools_error();
				  arg1916_1239 = shape_tools_shape(arg1919_1242);
			       }
			       return user_error_location_137_tools_error(loc_2698, arg1916_1239, string2320_ast_sexp, exp_2699, BNIL);
			    }
			 }
		       else
			 {
			    {
			       obj_t arg1920_1243;
			       obj_t arg1921_1244;
			       {
				  obj_t arg1923_1245;
				  arg1923_1245 = CAR(vars_1223);
				  {
				     obj_t list1925_1247;
				     {
					obj_t arg1927_1248;
					{
					   obj_t aux_3873;
					   aux_3873 = CAR(args_1224);
					   arg1927_1248 = MAKE_PAIR(aux_3873, BNIL);
					}
					list1925_1247 = MAKE_PAIR(arg1923_1245, arg1927_1248);
				     }
				     arg1920_1243 = list1925_1247;
				  }
			       }
			       arg1921_1244 = loop_ast_sexp(exp_2699, loc_2698, CDR(vars_1223), CDR(args_1224));
			       return MAKE_PAIR(arg1920_1243, arg1921_1244);
			    }
			 }
		    }
		  else
		    {
		       {
			  obj_t arg1931_1252;
			  {
			     obj_t arg1934_1255;
			     arg1934_1255 = current_function_76_tools_error();
			     arg1931_1252 = shape_tools_shape(arg1934_1255);
			  }
			  return user_error_location_137_tools_error(loc_2698, arg1931_1252, string2321_ast_sexp, exp_2699, BNIL);
		       }
		    }
	       }
	  }
	else
	  {
	     {
		obj_t arg1937_1258;
		{
		   obj_t arg1940_1261;
		   arg1940_1261 = liip_ast_sexp(args_1224);
		   {
		      obj_t list1941_1262;
		      {
			 obj_t arg1942_1263;
			 arg1942_1263 = MAKE_PAIR(arg1940_1261, BNIL);
			 list1941_1262 = MAKE_PAIR(vars_1223, arg1942_1263);
		      }
		      arg1937_1258 = list1941_1262;
		   }
		}
		{
		   obj_t list1938_1259;
		   list1938_1259 = MAKE_PAIR(arg1937_1258, BNIL);
		   return list1938_1259;
		}
	     }
	  }
     }
}


/* _sexp->node2301 */ obj_t 
_sexp__node2301_129_ast_sexp(obj_t env_2673, obj_t exp_2674, obj_t stack_2675, obj_t loc_2676, obj_t site_2677)
{
   {
      node_t aux_3888;
      aux_3888 = sexp__node_235_ast_sexp(exp_2674, stack_2675, loc_2676, site_2677);
      return (obj_t) (aux_3888);
   }
}


/* arg1958 */ obj_t 
arg1958_ast_sexp(obj_t env_2678, obj_t obj_2680, obj_t proc_2681, obj_t msg_2682)
{
   {
      obj_t loc_2679;
      loc_2679 = PROCEDURE_REF(env_2678, ((long) 0));
      {
	 obj_t obj_1281;
	 obj_t proc_1282;
	 obj_t msg_1283;
	 obj_1281 = obj_2680;
	 proc_1282 = proc_2681;
	 msg_1283 = msg_2682;
	 return user_error_location_137_tools_error(loc_2679, obj_1281, proc_1282, msg_1283, BNIL);
      }
   }
}


/* sexp*->node */ obj_t 
sexp___node_160_ast_sexp(obj_t exp__153_21, obj_t stack_22, obj_t loc_23, obj_t site_24)
{
   {
      obj_t exps_1451;
      obj_t res_1452;
      obj_t loc_1453;
      exps_1451 = exp__153_21;
      res_1452 = BNIL;
      loc_1453 = loc_23;
    loop_1454:
      if (NULLP(exps_1451))
	{
	   {
	      node_t aux_3895;
	      aux_3895 = error_sexp__node_157_ast_sexp(string2322_ast_sexp, exps_1451, loc_1453);
	      return (obj_t) (aux_3895);
	   }
	}
      else
	{
	   bool_t test_3898;
	   {
	      obj_t aux_3899;
	      aux_3899 = CDR(exps_1451);
	      test_3898 = NULLP(aux_3899);
	   }
	   if (test_3898)
	     {
		{
		   obj_t loc_1458;
		   loc_1458 = find_location_loc_243_tools_location(CAR(exps_1451), loc_1453);
		   {
		      obj_t arg2094_1459;
		      {
			 node_t arg2095_1460;
			 arg2095_1460 = sexp__node_235_ast_sexp(CAR(exps_1451), stack_22, loc_1458, site_24);
			 {
			    obj_t aux_3906;
			    aux_3906 = (obj_t) (arg2095_1460);
			    arg2094_1459 = MAKE_PAIR(aux_3906, res_1452);
			 }
		      }
		      return reverse__39___r4_pairs_and_lists_6_3(arg2094_1459);
		   }
		}
	     }
	   else
	     {
		{
		   obj_t loc_1463;
		   loc_1463 = find_location_loc_243_tools_location(CAR(exps_1451), loc_1453);
		   {
		      obj_t arg2098_1464;
		      obj_t arg2099_1465;
		      arg2098_1464 = CDR(exps_1451);
		      {
			 node_t arg2100_1466;
			 arg2100_1466 = sexp__node_235_ast_sexp(CAR(exps_1451), stack_22, loc_1463, CNST_TABLE_REF(((long) 1)));
			 {
			    obj_t aux_3916;
			    aux_3916 = (obj_t) (arg2100_1466);
			    arg2099_1465 = MAKE_PAIR(aux_3916, res_1452);
			 }
		      }
		      {
			 obj_t loc_3921;
			 obj_t res_3920;
			 obj_t exps_3919;
			 exps_3919 = arg2098_1464;
			 res_3920 = arg2099_1465;
			 loc_3921 = loc_1463;
			 loc_1453 = loc_3921;
			 res_1452 = res_3920;
			 exps_1451 = exps_3919;
			 goto loop_1454;
		      }
		   }
		}
	     }
	}
   }
}


/* lookup */ obj_t 
lookup_ast_sexp(obj_t name_25, obj_t stack_26)
{
   {
      bool_t test2106_1471;
      {
	 bool_t test2113_1479;
	 {
	    obj_t obj2_2498;
	    obj2_2498 = _cache_name__178_ast_sexp;
	    test2113_1479 = (name_25 == obj2_2498);
	 }
	 if (test2113_1479)
	   {
	      obj_t obj2_2500;
	      obj2_2500 = _cache_stack__44_ast_sexp;
	      test2106_1471 = (stack_26 == obj2_2500);
	   }
	 else
	   {
	      test2106_1471 = ((bool_t) 0);
	   }
      }
      if (test2106_1471)
	{
	   return _cache_res__50_ast_sexp;
	}
      else
	{
	   _cache_name__178_ast_sexp = name_25;
	   _cache_stack__44_ast_sexp = stack_26;
	   {
	      obj_t stack_1472;
	      stack_1472 = stack_26;
	    loop_1473:
	      if (NULLP(stack_1472))
		{
		   _cache_res__50_ast_sexp = BFALSE;
		   return BFALSE;
		}
	      else
		{
		   bool_t test_3928;
		   {
		      obj_t aux_3929;
		      {
			 local_t obj_2503;
			 {
			    obj_t aux_3930;
			    aux_3930 = CAR(stack_1472);
			    obj_2503 = (local_t) (aux_3930);
			 }
			 aux_3929 = (((local_t) CREF(obj_2503))->id);
		      }
		      test_3928 = (aux_3929 == name_25);
		   }
		   if (test_3928)
		     {
			_cache_res__50_ast_sexp = CAR(stack_1472);
			return CAR(stack_1472);
		     }
		   else
		     {
			{
			   obj_t stack_3937;
			   stack_3937 = CDR(stack_1472);
			   stack_1472 = stack_3937;
			   goto loop_1473;
			}
		     }
		}
	   }
	}
   }
}


/* use-variable! */ obj_t 
use_variable__4_ast_sexp(variable_t var_27, obj_t loc_28, obj_t site_29)
{
   {
      bool_t test_3939;
      {
	 obj_t aux_3940;
	 aux_3940 = CNST_TABLE_REF(((long) 8));
	 test_3939 = (site_29 == aux_3940);
      }
      if (test_3939)
	{
	   obj_t arg2115_1481;
	   arg2115_1481 = CNST_TABLE_REF(((long) 28));
	   ((((variable_t) CREF(var_27))->access) = ((obj_t) arg2115_1481), BUNSPEC);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      bool_t test2117_1484;
      {
	 bool_t test_3945;
	 {
	    obj_t aux_3946;
	    aux_3946 = CNST_TABLE_REF(((long) 8));
	    test_3945 = (site_29 == aux_3946);
	 }
	 if (test_3945)
	   {
	      obj_t aux_3949;
	      {
		 value_t aux_3950;
		 aux_3950 = (((variable_t) CREF(var_27))->value);
		 aux_3949 = (obj_t) (aux_3950);
	      }
	      test2117_1484 = is_a__118___object(aux_3949, fun_ast_var);
	   }
	 else
	   {
	      test2117_1484 = ((bool_t) 0);
	   }
      }
      if (test2117_1484)
	{
	   obj_t arg2121_1486;
	   arg2121_1486 = shape_tools_shape((obj_t) (var_27));
	   {
	      node_t aux_3957;
	      aux_3957 = error_sexp__node_157_ast_sexp(string2323_ast_sexp, arg2121_1486, loc_28);
	      return (obj_t) (aux_3957);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _use-variable!2302 */ obj_t 
_use_variable_2302_248_ast_sexp(obj_t env_2683, obj_t var_2684, obj_t loc_2685, obj_t site_2686)
{
   return use_variable__4_ast_sexp((variable_t) (var_2684), loc_2685, site_2686);
}


/* error-sexp->node */ node_t 
error_sexp__node_157_ast_sexp(obj_t msg_30, obj_t exp_31, obj_t loc_32)
{
   {
      obj_t arg2124_1489;
      node_t arg2125_1490;
      {
	 obj_t arg2129_1493;
	 arg2129_1493 = current_function_76_tools_error();
	 arg2124_1489 = shape_tools_shape(arg2129_1493);
      }
      arg2125_1490 = sexp__node_235_ast_sexp(CNST_TABLE_REF(((long) 26)), BNIL, loc_32, CNST_TABLE_REF(((long) 1)));
      {
	 obj_t list2126_1491;
	 {
	    obj_t aux_3967;
	    aux_3967 = (obj_t) (arg2125_1490);
	    list2126_1491 = MAKE_PAIR(aux_3967, BNIL);
	 }
	 {
	    obj_t aux_3970;
	    aux_3970 = user_error_location_137_tools_error(loc_32, arg2124_1489, msg_30, exp_31, list2126_1491);
	    return (node_t) (aux_3970);
	 }
      }
   }
}


/* _error-sexp->node2303 */ obj_t 
_error_sexp__node2303_135_ast_sexp(obj_t env_2687, obj_t msg_2688, obj_t exp_2689, obj_t loc_2690)
{
   {
      node_t aux_3973;
      aux_3973 = error_sexp__node_157_ast_sexp(msg_2688, exp_2689, loc_2690);
      return (obj_t) (aux_3973);
   }
}


/* define-primop-ref->node */ node_t 
define_primop_ref__node_164_ast_sexp(global_t global_33, node_t ref_34)
{
   {
      node_t fun_1497;
      fun_1497 = sexp__node_235_ast_sexp(CNST_TABLE_REF(((long) 29)), BNIL, BFALSE, CNST_TABLE_REF(((long) 15)));
      {
	 bool_t test2134_1498;
	 test2134_1498 = is_a__118___object((obj_t) (fun_1497), var_ast_node);
	 if (test2134_1498)
	   {
	      obj_t arg2135_1499;
	      obj_t arg2138_1502;
	      arg2135_1499 = ____74_type_cache;
	      {
		 node_t arg2139_1503;
		 {
		    obj_t arg2144_1507;
		    obj_t arg2146_1509;
		    {
		       obj_t arg2147_1510;
		       obj_t arg2148_1511;
		       arg2147_1510 = CNST_TABLE_REF(((long) 17));
		       arg2148_1511 = (((global_t) CREF(global_33))->id);
		       {
			  obj_t list2150_1513;
			  {
			     obj_t arg2151_1514;
			     arg2151_1514 = MAKE_PAIR(BNIL, BNIL);
			     list2150_1513 = MAKE_PAIR(arg2148_1511, arg2151_1514);
			  }
			  arg2144_1507 = cons__138___r4_pairs_and_lists_6_3(arg2147_1510, list2150_1513);
		       }
		    }
		    arg2146_1509 = CNST_TABLE_REF(((long) 1));
		    arg2139_1503 = sexp__node_235_ast_sexp(arg2144_1507, BNIL, BFALSE, arg2146_1509);
		 }
		 {
		    obj_t list2140_1504;
		    {
		       obj_t arg2141_1505;
		       {
			  obj_t aux_3989;
			  aux_3989 = (obj_t) (ref_34);
			  arg2141_1505 = MAKE_PAIR(aux_3989, BNIL);
		       }
		       {
			  obj_t aux_3992;
			  aux_3992 = (obj_t) (arg2139_1503);
			  list2140_1504 = MAKE_PAIR(aux_3992, arg2141_1505);
		       }
		    }
		    arg2138_1502 = list2140_1504;
		 }
	      }
	      {
		 app_t res2298_2538;
		 {
		    obj_t loc_2520;
		    type_t type_2521;
		    obj_t key_2523;
		    var_t fun_2524;
		    loc_2520 = BFALSE;
		    type_2521 = (type_t) (arg2135_1499);
		    key_2523 = BINT(((long) -1));
		    fun_2524 = (var_t) (fun_1497);
		    {
		       app_t new1240_2527;
		       new1240_2527 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
		       {
			  long arg2233_2528;
			  arg2233_2528 = class_num_218___object(app_ast_node);
			  {
			     obj_t obj_2536;
			     obj_2536 = (obj_t) (new1240_2527);
			     (((obj_t) CREF(obj_2536))->header = MAKE_HEADER(arg2233_2528, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_4002;
			  aux_4002 = (object_t) (new1240_2527);
			  OBJECT_WIDENING_SET(aux_4002, loc_2520);
		       }
		       ((((app_t) CREF(new1240_2527))->loc) = ((obj_t) loc_2520), BUNSPEC);
		       ((((app_t) CREF(new1240_2527))->type) = ((type_t) type_2521), BUNSPEC);
		       ((((app_t) CREF(new1240_2527))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((app_t) CREF(new1240_2527))->key) = ((obj_t) key_2523), BUNSPEC);
		       ((((app_t) CREF(new1240_2527))->fun) = ((var_t) fun_2524), BUNSPEC);
		       ((((app_t) CREF(new1240_2527))->args) = ((obj_t) arg2138_1502), BUNSPEC);
		       ((((app_t) CREF(new1240_2527))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
		       res2298_2538 = new1240_2527;
		    }
		 }
		 return (node_t) (res2298_2538);
	      }
	   }
	 else
	   {
	      return fun_1497;
	   }
      }
   }
}


/* _define-primop-ref->node2304 */ obj_t 
_define_primop_ref__node2304_55_ast_sexp(obj_t env_2691, obj_t global_2692, obj_t ref_2693)
{
   {
      node_t aux_4013;
      aux_4013 = define_primop_ref__node_164_ast_sexp((global_t) (global_2692), (node_t) (ref_2693));
      return (obj_t) (aux_4013);
   }
}


/* define-primop->node */ node_t 
define_primop__node_141_ast_sexp(global_t global_35)
{
   use_variable__4_ast_sexp((variable_t) (global_35), BFALSE, CNST_TABLE_REF(((long) 1)));
   {
      node_t fun_1520;
      fun_1520 = sexp__node_235_ast_sexp(CNST_TABLE_REF(((long) 30)), BNIL, BFALSE, CNST_TABLE_REF(((long) 15)));
      {
	 bool_t test2157_1521;
	 test2157_1521 = is_a__118___object((obj_t) (fun_1520), var_ast_node);
	 if (test2157_1521)
	   {
	      obj_t arg2158_1522;
	      obj_t arg2161_1525;
	      arg2158_1522 = ____74_type_cache;
	      {
		 node_t arg2162_1526;
		 node_t arg2163_1527;
		 {
		    obj_t arg2167_1531;
		    obj_t arg2170_1533;
		    {
		       obj_t arg2172_1534;
		       obj_t arg2173_1535;
		       arg2172_1534 = CNST_TABLE_REF(((long) 17));
		       arg2173_1535 = (((global_t) CREF(global_35))->id);
		       {
			  obj_t list2175_1537;
			  {
			     obj_t arg2176_1538;
			     arg2176_1538 = MAKE_PAIR(BNIL, BNIL);
			     list2175_1537 = MAKE_PAIR(arg2173_1535, arg2176_1538);
			  }
			  arg2167_1531 = cons__138___r4_pairs_and_lists_6_3(arg2172_1534, list2175_1537);
		       }
		    }
		    arg2170_1533 = CNST_TABLE_REF(((long) 1));
		    arg2162_1526 = sexp__node_235_ast_sexp(arg2167_1531, BNIL, BFALSE, arg2170_1533);
		 }
		 arg2163_1527 = sexp__node_235_ast_sexp((obj_t) (global_35), BNIL, BFALSE, CNST_TABLE_REF(((long) 1)));
		 {
		    obj_t list2164_1528;
		    {
		       obj_t arg2165_1529;
		       {
			  obj_t aux_4037;
			  aux_4037 = (obj_t) (arg2163_1527);
			  arg2165_1529 = MAKE_PAIR(aux_4037, BNIL);
		       }
		       {
			  obj_t aux_4040;
			  aux_4040 = (obj_t) (arg2162_1526);
			  list2164_1528 = MAKE_PAIR(aux_4040, arg2165_1529);
		       }
		    }
		    arg2161_1525 = list2164_1528;
		 }
	      }
	      {
		 app_t res2299_2560;
		 {
		    obj_t loc_2542;
		    type_t type_2543;
		    obj_t key_2545;
		    var_t fun_2546;
		    loc_2542 = BFALSE;
		    type_2543 = (type_t) (arg2158_1522);
		    key_2545 = BINT(((long) -1));
		    fun_2546 = (var_t) (fun_1520);
		    {
		       app_t new1240_2549;
		       new1240_2549 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
		       {
			  long arg2233_2550;
			  arg2233_2550 = class_num_218___object(app_ast_node);
			  {
			     obj_t obj_2558;
			     obj_2558 = (obj_t) (new1240_2549);
			     (((obj_t) CREF(obj_2558))->header = MAKE_HEADER(arg2233_2550, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_4050;
			  aux_4050 = (object_t) (new1240_2549);
			  OBJECT_WIDENING_SET(aux_4050, loc_2542);
		       }
		       ((((app_t) CREF(new1240_2549))->loc) = ((obj_t) loc_2542), BUNSPEC);
		       ((((app_t) CREF(new1240_2549))->type) = ((type_t) type_2543), BUNSPEC);
		       ((((app_t) CREF(new1240_2549))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((app_t) CREF(new1240_2549))->key) = ((obj_t) key_2545), BUNSPEC);
		       ((((app_t) CREF(new1240_2549))->fun) = ((var_t) fun_2546), BUNSPEC);
		       ((((app_t) CREF(new1240_2549))->args) = ((obj_t) arg2161_1525), BUNSPEC);
		       ((((app_t) CREF(new1240_2549))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
		       res2299_2560 = new1240_2549;
		    }
		 }
		 return (node_t) (res2299_2560);
	      }
	   }
	 else
	   {
	      return fun_1520;
	   }
      }
   }
}


/* _define-primop->node2305 */ obj_t 
_define_primop__node2305_97_ast_sexp(obj_t env_2694, obj_t global_2695)
{
   {
      node_t aux_4061;
      aux_4061 = define_primop__node_141_ast_sexp((global_t) (global_2695));
      return (obj_t) (aux_4061);
   }
}


/* location->node */ node_t 
location__node_25_ast_sexp(global_t global_36)
{
   use_variable__4_ast_sexp((variable_t) (global_36), BFALSE, CNST_TABLE_REF(((long) 1)));
   {
      node_t fun_1546;
      fun_1546 = sexp__node_235_ast_sexp(CNST_TABLE_REF(((long) 31)), BNIL, BFALSE, CNST_TABLE_REF(((long) 15)));
      {
	 bool_t test2185_1547;
	 test2185_1547 = is_a__118___object((obj_t) (fun_1546), var_ast_node);
	 if (test2185_1547)
	   {
	      obj_t arg2186_1548;
	      obj_t arg2189_1551;
	      arg2186_1548 = ____74_type_cache;
	      {
		 node_t arg2190_1552;
		 arg2190_1552 = sexp__node_235_ast_sexp((obj_t) (global_36), BNIL, BFALSE, CNST_TABLE_REF(((long) 1)));
		 {
		    obj_t list2191_1553;
		    {
		       obj_t aux_4077;
		       aux_4077 = (obj_t) (arg2190_1552);
		       list2191_1553 = MAKE_PAIR(aux_4077, BNIL);
		    }
		    arg2189_1551 = list2191_1553;
		 }
	      }
	      {
		 app_t res2300_2581;
		 {
		    obj_t loc_2563;
		    type_t type_2564;
		    obj_t key_2566;
		    var_t fun_2567;
		    loc_2563 = BFALSE;
		    type_2564 = (type_t) (arg2186_1548);
		    key_2566 = BINT(((long) -1));
		    fun_2567 = (var_t) (fun_1546);
		    {
		       app_t new1240_2570;
		       new1240_2570 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
		       {
			  long arg2233_2571;
			  arg2233_2571 = class_num_218___object(app_ast_node);
			  {
			     obj_t obj_2579;
			     obj_2579 = (obj_t) (new1240_2570);
			     (((obj_t) CREF(obj_2579))->header = MAKE_HEADER(arg2233_2571, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_4087;
			  aux_4087 = (object_t) (new1240_2570);
			  OBJECT_WIDENING_SET(aux_4087, loc_2563);
		       }
		       ((((app_t) CREF(new1240_2570))->loc) = ((obj_t) loc_2563), BUNSPEC);
		       ((((app_t) CREF(new1240_2570))->type) = ((type_t) type_2564), BUNSPEC);
		       ((((app_t) CREF(new1240_2570))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((app_t) CREF(new1240_2570))->key) = ((obj_t) key_2566), BUNSPEC);
		       ((((app_t) CREF(new1240_2570))->fun) = ((var_t) fun_2567), BUNSPEC);
		       ((((app_t) CREF(new1240_2570))->args) = ((obj_t) arg2189_1551), BUNSPEC);
		       ((((app_t) CREF(new1240_2570))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
		       res2300_2581 = new1240_2570;
		    }
		 }
		 return (node_t) (res2300_2581);
	      }
	   }
	 else
	   {
	      return fun_1546;
	   }
      }
   }
}


/* _location->node2306 */ obj_t 
_location__node2306_123_ast_sexp(obj_t env_2696, obj_t global_2697)
{
   {
      node_t aux_4098;
      aux_4098 = location__node_25_ast_sexp((global_t) (global_2697));
      return (obj_t) (aux_4098);
   }
}


/* method-init */ obj_t 
method_init_76_ast_sexp()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_sexp()
{
   module_initialization_70_tools_trace(((long) 0), "AST_SEXP");
   module_initialization_70_tools_error(((long) 0), "AST_SEXP");
   module_initialization_70_tools_shape(((long) 0), "AST_SEXP");
   module_initialization_70_tools_progn(((long) 0), "AST_SEXP");
   module_initialization_70_tools_location(((long) 0), "AST_SEXP");
   module_initialization_70_tools_misc(((long) 0), "AST_SEXP");
   module_initialization_70_tools_dsssl(((long) 0), "AST_SEXP");
   module_initialization_70_type_type(((long) 0), "AST_SEXP");
   module_initialization_70_type_env(((long) 0), "AST_SEXP");
   module_initialization_70_type_cache(((long) 0), "AST_SEXP");
   module_initialization_70_type_typeof(((long) 0), "AST_SEXP");
   module_initialization_70_ast_ident(((long) 0), "AST_SEXP");
   module_initialization_70_ast_env(((long) 0), "AST_SEXP");
   module_initialization_70_ast_var(((long) 0), "AST_SEXP");
   module_initialization_70_ast_node(((long) 0), "AST_SEXP");
   module_initialization_70_ast_build(((long) 0), "AST_SEXP");
   module_initialization_70_ast_pragma(((long) 0), "AST_SEXP");
   module_initialization_70_ast_labels(((long) 0), "AST_SEXP");
   module_initialization_70_ast_let(((long) 0), "AST_SEXP");
   module_initialization_70_ast_exit(((long) 0), "AST_SEXP");
   module_initialization_70_ast_app(((long) 0), "AST_SEXP");
   return module_initialization_70_ast_apply(((long) 0), "AST_SEXP");
}
