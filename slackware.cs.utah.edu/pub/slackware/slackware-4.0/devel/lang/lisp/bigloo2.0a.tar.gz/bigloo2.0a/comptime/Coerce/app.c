/*===========================================================================*/
/*   (Coerce/app.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_coerce_app();
static obj_t coerce__app_245_coerce_app(obj_t, obj_t, obj_t);
static node_t coerce_bigloo_app__198_coerce_app(variable_t, app_t, obj_t);
extern obj_t type_type_type;
static node_t coerce_foreign_va_app__44_coerce_app(value_t, variable_t, app_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_coerce_app(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_coerce_convert(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t imported_modules_init_94_coerce_app();
static node_t coerce_foreign_fx_app__114_coerce_app(value_t, variable_t, app_t, obj_t);
extern obj_t cfun_ast_var;
extern node_t coerce__182_coerce_coerce(node_t, type_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_coerce_app();
static obj_t _coerce_1602_69_coerce_coerce(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_coerce_app();
extern obj_t open_input_string(obj_t);
extern node_t convert__122_coerce_convert(node_t, type_t, type_t);
extern obj_t shape_tools_shape(obj_t);
static node_t coerce_bigloo_intern_app__35_coerce_app(variable_t, app_t, obj_t);
static node_t coerce_foreign_app__190_coerce_app(variable_t, app_t, obj_t);
extern obj_t read___reader(obj_t);
static node_t coerce_bigloo_extern_app__81_coerce_app(variable_t, app_t, obj_t);
static obj_t require_initialization_114_coerce_app = BUNSPEC;
static obj_t cnst_init_137_coerce_app();
static obj_t __cnst[1];

DEFINE_STATIC_PROCEDURE(proc1603_coerce_app, coerce__app_245_coerce_app1610, coerce__app_245_coerce_app, 0L, 2);
DEFINE_STRING(string1604_coerce_app, string1604_coerce_app1611, "IMPORT ", 7);
extern obj_t coerce__env_127_coerce_coerce;


/* module-initialization */ obj_t 
module_initialization_70_coerce_app(long checksum_1218, char *from_1219)
{
   if (CBOOL(require_initialization_114_coerce_app))
     {
	require_initialization_114_coerce_app = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_app();
	cnst_init_137_coerce_app();
	imported_modules_init_94_coerce_app();
	method_init_76_coerce_app();
	toplevel_init_63_coerce_app();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_app()
{
   module_initialization_70___object(((long) 0), "COERCE_APP");
   module_initialization_70___reader(((long) 0), "COERCE_APP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_app()
{
   {
      obj_t cnst_port_138_1210;
      cnst_port_138_1210 = open_input_string(string1604_coerce_app);
      {
	 long i_1211;
	 i_1211 = ((long) 0);
       loop_1212:
	 {
	    bool_t test1605_1213;
	    test1605_1213 = (i_1211 == ((long) -1));
	    if (test1605_1213)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1606_1214;
		    {
		       obj_t list1607_1215;
		       {
			  obj_t arg1608_1216;
			  arg1608_1216 = BNIL;
			  list1607_1215 = MAKE_PAIR(cnst_port_138_1210, arg1608_1216);
		       }
		       arg1606_1214 = read___reader(list1607_1215);
		    }
		    CNST_TABLE_SET(i_1211, arg1606_1214);
		 }
		 {
		    int aux_1217;
		    {
		       long aux_1236;
		       aux_1236 = (i_1211 - ((long) 1));
		       aux_1217 = (int) (aux_1236);
		    }
		    {
		       long i_1239;
		       i_1239 = (long) (aux_1217);
		       i_1211 = i_1239;
		       goto loop_1212;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_app()
{
   return BUNSPEC;
}


/* coerce-foreign-app! */ node_t 
coerce_foreign_app__190_coerce_app(variable_t callee_3, app_t node_4, obj_t to_5)
{
   {
      value_t ffun_714;
      ffun_714 = (((variable_t) CREF(callee_3))->value);
      {
	 {
	    bool_t test_1242;
	    {
	       long aux_1243;
	       {
		  fun_t obj_1129;
		  obj_1129 = (fun_t) (ffun_714);
		  aux_1243 = (((fun_t) CREF(obj_1129))->arity);
	       }
	       test_1242 = (aux_1243 >= ((long) 0));
	    }
	    if (test_1242)
	      {
		 return coerce_foreign_fx_app__114_coerce_app(ffun_714, callee_3, node_4, to_5);
	      }
	    else
	      {
		 return coerce_foreign_va_app__44_coerce_app(ffun_714, callee_3, node_4, to_5);
	      }
	 }
      }
   }
}


/* coerce-foreign-fx-app! */ node_t 
coerce_foreign_fx_app__114_coerce_app(value_t fun_6, variable_t callee_7, app_t node_8, obj_t to_9)
{
   {
      obj_t actuals_717;
      obj_t types_718;
      actuals_717 = (((app_t) CREF(node_8))->args);
      {
	 cfun_t obj_1133;
	 obj_1133 = (cfun_t) (fun_6);
	 types_718 = (((cfun_t) CREF(obj_1133))->args_type_205);
      }
    loop_719:
      if (NULLP(actuals_717))
	{
	   return convert__122_coerce_convert((node_t) (node_8), (((variable_t) CREF(callee_7))->type), (type_t) (to_9));
	}
      else
	{
	   {
	      node_t arg1441_724;
	      {
		 type_t aux_1259;
		 node_t aux_1255;
		 {
		    obj_t aux_1260;
		    aux_1260 = CAR(types_718);
		    aux_1259 = (type_t) (aux_1260);
		 }
		 {
		    obj_t aux_1256;
		    aux_1256 = CAR(actuals_717);
		    aux_1255 = (node_t) (aux_1256);
		 }
		 arg1441_724 = coerce__182_coerce_coerce(aux_1255, aux_1259);
	      }
	      {
		 obj_t aux_1264;
		 aux_1264 = (obj_t) (arg1441_724);
		 SET_CAR(actuals_717, aux_1264);
	      }
	   }
	   {
	      obj_t types_1269;
	      obj_t actuals_1267;
	      actuals_1267 = CDR(actuals_717);
	      types_1269 = CDR(types_718);
	      types_718 = types_1269;
	      actuals_717 = actuals_1267;
	      goto loop_719;
	   }
	}
   }
}


/* coerce-foreign-va-app! */ node_t 
coerce_foreign_va_app__44_coerce_app(value_t fun_10, variable_t callee_11, app_t node_12, obj_t to_13)
{
   {
      obj_t actuals_729;
      obj_t types_730;
      long counter_731;
      actuals_729 = (((app_t) CREF(node_12))->args);
      {
	 cfun_t obj_1143;
	 obj_1143 = (cfun_t) (fun_10);
	 types_730 = (((cfun_t) CREF(obj_1143))->args_type_205);
      }
      {
	 fun_t obj_1144;
	 obj_1144 = (fun_t) (fun_10);
	 counter_731 = (((fun_t) CREF(obj_1144))->arity);
      }
    loop_732:
      if ((counter_731 == ((long) -1)))
	{
	   obj_t actuals_737;
	   actuals_737 = actuals_729;
	 loop_738:
	   if (NULLP(actuals_737))
	     {
		return convert__122_coerce_convert((node_t) (node_12), (((variable_t) CREF(callee_11))->type), (type_t) (to_13));
	     }
	   else
	     {
		{
		   node_t arg1458_741;
		   {
		      type_t aux_1286;
		      node_t aux_1282;
		      {
			 obj_t aux_1287;
			 aux_1287 = CAR(types_730);
			 aux_1286 = (type_t) (aux_1287);
		      }
		      {
			 obj_t aux_1283;
			 aux_1283 = CAR(actuals_737);
			 aux_1282 = (node_t) (aux_1283);
		      }
		      arg1458_741 = coerce__182_coerce_coerce(aux_1282, aux_1286);
		   }
		   {
		      obj_t aux_1291;
		      aux_1291 = (obj_t) (arg1458_741);
		      SET_CAR(actuals_737, aux_1291);
		   }
		}
		{
		   obj_t actuals_1294;
		   actuals_1294 = CDR(actuals_737);
		   actuals_737 = actuals_1294;
		   goto loop_738;
		}
	     }
	}
      else
	{
	   {
	      node_t arg1464_745;
	      {
		 type_t aux_1300;
		 node_t aux_1296;
		 {
		    obj_t aux_1301;
		    aux_1301 = CAR(types_730);
		    aux_1300 = (type_t) (aux_1301);
		 }
		 {
		    obj_t aux_1297;
		    aux_1297 = CAR(actuals_729);
		    aux_1296 = (node_t) (aux_1297);
		 }
		 arg1464_745 = coerce__182_coerce_coerce(aux_1296, aux_1300);
	      }
	      {
		 obj_t aux_1305;
		 aux_1305 = (obj_t) (arg1464_745);
		 SET_CAR(actuals_729, aux_1305);
	      }
	   }
	   {
	      long counter_1312;
	      obj_t types_1310;
	      obj_t actuals_1308;
	      actuals_1308 = CDR(actuals_729);
	      types_1310 = CDR(types_730);
	      counter_1312 = (counter_731 + ((long) 1));
	      counter_731 = counter_1312;
	      types_730 = types_1310;
	      actuals_729 = actuals_1308;
	      goto loop_732;
	   }
	}
   }
}


/* coerce-bigloo-app! */ node_t 
coerce_bigloo_app__198_coerce_app(variable_t callee_14, app_t node_15, obj_t to_16)
{
   {
      bool_t test1470_751;
      {
	 bool_t test1471_752;
	 test1471_752 = is_a__118___object((obj_t) (callee_14), global_ast_var);
	 if (test1471_752)
	   {
	      bool_t test_1322;
	      {
		 obj_t aux_1326;
		 obj_t aux_1323;
		 aux_1326 = CNST_TABLE_REF(((long) 0));
		 {
		    global_t obj_1163;
		    obj_1163 = (global_t) (callee_14);
		    aux_1323 = (((global_t) CREF(obj_1163))->import);
		 }
		 test_1322 = (aux_1323 == aux_1326);
	      }
	      if (test_1322)
		{
		   bool_t test_1329;
		   {
		      obj_t aux_1330;
		      {
			 sfun_t obj_1167;
			 {
			    value_t aux_1331;
			    aux_1331 = (((variable_t) CREF(callee_14))->value);
			    obj_1167 = (sfun_t) (aux_1331);
			 }
			 aux_1330 = (((sfun_t) CREF(obj_1167))->args);
		      }
		      test_1329 = PAIRP(aux_1330);
		   }
		   if (test_1329)
		     {
			obj_t aux_1336;
			{
			   obj_t aux_1337;
			   {
			      sfun_t obj_1170;
			      {
				 value_t aux_1338;
				 aux_1338 = (((variable_t) CREF(callee_14))->value);
				 obj_1170 = (sfun_t) (aux_1338);
			      }
			      aux_1337 = (((sfun_t) CREF(obj_1170))->args);
			   }
			   aux_1336 = CAR(aux_1337);
			}
			test1470_751 = is_a__118___object(aux_1336, type_type_type);
		     }
		   else
		     {
			test1470_751 = ((bool_t) 0);
		     }
		}
	      else
		{
		   test1470_751 = ((bool_t) 0);
		}
	   }
	 else
	   {
	      test1470_751 = ((bool_t) 0);
	   }
      }
      if (test1470_751)
	{
	   return coerce_bigloo_extern_app__81_coerce_app(callee_14, node_15, to_16);
	}
      else
	{
	   return coerce_bigloo_intern_app__35_coerce_app(callee_14, node_15, to_16);
	}
   }
}


/* coerce-bigloo-intern-app! */ node_t 
coerce_bigloo_intern_app__35_coerce_app(variable_t callee_17, app_t node_18, obj_t to_19)
{
   {
      value_t fun_762;
      fun_762 = (((variable_t) CREF(callee_17))->value);
      {
	 obj_t sh_764;
	 sh_764 = shape_tools_shape((obj_t) (callee_17));
	 {
	    {
	       obj_t actuals_765;
	       obj_t formals_766;
	       actuals_765 = (((app_t) CREF(node_18))->args);
	       {
		  sfun_t obj_1176;
		  obj_1176 = (sfun_t) (fun_762);
		  formals_766 = (((sfun_t) CREF(obj_1176))->args);
	       }
	     loop_767:
	       if (NULLP(actuals_765))
		 {
		    return convert__122_coerce_convert((node_t) (node_18), (((variable_t) CREF(callee_17))->type), (type_t) (to_19));
		 }
	       else
		 {
		    {
		       node_t arg1486_773;
		       {
			  type_t aux_1360;
			  node_t aux_1356;
			  {
			     local_t obj_1180;
			     {
				obj_t aux_1361;
				aux_1361 = CAR(formals_766);
				obj_1180 = (local_t) (aux_1361);
			     }
			     aux_1360 = (((local_t) CREF(obj_1180))->type);
			  }
			  {
			     obj_t aux_1357;
			     aux_1357 = CAR(actuals_765);
			     aux_1356 = (node_t) (aux_1357);
			  }
			  arg1486_773 = coerce__182_coerce_coerce(aux_1356, aux_1360);
		       }
		       {
			  obj_t aux_1366;
			  aux_1366 = (obj_t) (arg1486_773);
			  SET_CAR(actuals_765, aux_1366);
		       }
		    }
		    {
		       obj_t formals_1371;
		       obj_t actuals_1369;
		       actuals_1369 = CDR(actuals_765);
		       formals_1371 = CDR(formals_766);
		       formals_766 = formals_1371;
		       actuals_765 = actuals_1369;
		       goto loop_767;
		    }
		 }
	    }
	 }
      }
   }
}


/* coerce-bigloo-extern-app! */ node_t 
coerce_bigloo_extern_app__81_coerce_app(variable_t callee_20, app_t node_21, obj_t to_22)
{
   {
      {
	 obj_t actuals_780;
	 obj_t formals_781;
	 actuals_780 = (((app_t) CREF(node_21))->args);
	 {
	    sfun_t obj_1189;
	    {
	       value_t aux_1399;
	       aux_1399 = (((variable_t) CREF(callee_20))->value);
	       obj_1189 = (sfun_t) (aux_1399);
	    }
	    formals_781 = (((sfun_t) CREF(obj_1189))->args);
	 }
       loop_782:
	 if (NULLP(actuals_780))
	   {
	      return convert__122_coerce_convert((node_t) (node_21), (((variable_t) CREF(callee_20))->type), (type_t) (to_22));
	   }
	 else
	   {
	      {
		 node_t arg1497_788;
		 {
		    type_t aux_1386;
		    node_t aux_1382;
		    {
		       obj_t aux_1387;
		       aux_1387 = CAR(formals_781);
		       aux_1386 = (type_t) (aux_1387);
		    }
		    {
		       obj_t aux_1383;
		       aux_1383 = CAR(actuals_780);
		       aux_1382 = (node_t) (aux_1383);
		    }
		    arg1497_788 = coerce__182_coerce_coerce(aux_1382, aux_1386);
		 }
		 {
		    obj_t aux_1391;
		    aux_1391 = (obj_t) (arg1497_788);
		    SET_CAR(actuals_780, aux_1391);
		 }
	      }
	      {
		 obj_t formals_1396;
		 obj_t actuals_1394;
		 actuals_1394 = CDR(actuals_780);
		 formals_1396 = CDR(formals_781);
		 formals_781 = formals_1396;
		 actuals_780 = actuals_1394;
		 goto loop_782;
	      }
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_coerce_app()
{
   {
      obj_t coerce__app_245_1203;
      coerce__app_245_1203 = proc1603_coerce_app;
      return add_method__1___object(coerce__env_127_coerce_coerce, app_ast_node, coerce__app_245_1203);
   }
}


/* coerce!-app */ obj_t 
coerce__app_245_coerce_app(obj_t env_1204, obj_t node_1205, obj_t to_1206)
{
   {
      app_t node_1117;
      obj_t to_1118;
      {
	 node_t aux_1404;
	 node_1117 = (app_t) (node_1205);
	 to_1118 = to_1206;
	 {
	    variable_t fun_1121;
	    {
	       var_t arg1598_1125;
	       arg1598_1125 = (((app_t) CREF(node_1117))->fun);
	       fun_1121 = (((var_t) CREF(arg1598_1125))->variable);
	    }
	    {
	       bool_t test1593_1122;
	       {
		  bool_t test1594_1123;
		  test1594_1123 = is_a__118___object((obj_t) (fun_1121), global_ast_var);
		  if (test1594_1123)
		    {
		       obj_t aux_1410;
		       {
			  value_t aux_1411;
			  aux_1411 = (((variable_t) CREF(fun_1121))->value);
			  aux_1410 = (obj_t) (aux_1411);
		       }
		       test1593_1122 = is_a__118___object(aux_1410, cfun_ast_var);
		    }
		  else
		    {
		       test1593_1122 = ((bool_t) 0);
		    }
	       }
	       if (test1593_1122)
		 {
		    aux_1404 = coerce_foreign_app__190_coerce_app(fun_1121, node_1117, to_1118);
		 }
	       else
		 {
		    aux_1404 = coerce_bigloo_app__198_coerce_app(fun_1121, node_1117, to_1118);
		 }
	    }
	 }
	 return (obj_t) (aux_1404);
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_app()
{
   module_initialization_70_tools_trace(((long) 0), "COERCE_APP");
   module_initialization_70_engine_param(((long) 0), "COERCE_APP");
   module_initialization_70_tools_shape(((long) 0), "COERCE_APP");
   module_initialization_70_type_type(((long) 0), "COERCE_APP");
   module_initialization_70_type_cache(((long) 0), "COERCE_APP");
   module_initialization_70_ast_var(((long) 0), "COERCE_APP");
   module_initialization_70_ast_node(((long) 0), "COERCE_APP");
   module_initialization_70_coerce_coerce(((long) 0), "COERCE_APP");
   return module_initialization_70_coerce_convert(((long) 0), "COERCE_APP");
}
