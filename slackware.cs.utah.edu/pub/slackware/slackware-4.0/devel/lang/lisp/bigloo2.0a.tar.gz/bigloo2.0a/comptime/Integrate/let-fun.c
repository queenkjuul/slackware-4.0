/*===========================================================================*/
/*   (Integrate/let-fun.scm)                                                 */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_let_fun_158();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static obj_t _displace_let_fun_node__default1539_115_integrate_let_fun_158(obj_t, obj_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t _displace_let_fun_node_1801_129_integrate_let_fun_158(obj_t, obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
static obj_t displace_let_fun_node__default1539_188_integrate_let_fun_158(node_t, variable_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
static long _stamp__29_integrate_let_fun_158;
extern obj_t module_initialization_70_integrate_let_fun_158(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t displace_let_fun_node__83_integrate_let_fun_158(node_t, variable_t);
static obj_t _displace_let_fun__244_integrate_let_fun_158(obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t displace_let_fun__199_integrate_let_fun_158(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_integrate_let_fun_158();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_integrate_let_fun_158();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_integrate_let_fun_158();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t bind_fun__68_integrate_let_fun_158(obj_t);
static bool_t free_fun__183_integrate_let_fun_158(obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_integrate_let_fun_158 = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_integrate_let_fun_158();
static obj_t __cnst[1];

DEFINE_STATIC_GENERIC(displace_let_fun_node__env_245_integrate_let_fun_158, _displace_let_fun_node_1801_129_integrate_let_fun_1581811, _displace_let_fun_node_1801_129_integrate_let_fun_158, 0L, 2);
DEFINE_STATIC_PROCEDURE(displace_let_fun_node__default1539_env_14_integrate_let_fun_158, _displace_let_fun_node__default1539_115_integrate_let_fun_1581812, _displace_let_fun_node__default1539_115_integrate_let_fun_158, 0L, 2);
DEFINE_STRING(string1805_integrate_let_fun_158, string1805_integrate_let_fun_1581813, "DISPLACE-LET-FUN-NODE!-DEFAULT1539 ", 35);
DEFINE_STRING(string1804_integrate_let_fun_158, string1804_integrate_let_fun_1581814, "No method for this object", 25);
DEFINE_STRING(string1803_integrate_let_fun_158, string1803_integrate_let_fun_1581815, "Unexpected closure", 18);
DEFINE_STRING(string1802_integrate_let_fun_158, string1802_integrate_let_fun_1581816, "displace-let-fun-node", 21);
DEFINE_EXPORT_PROCEDURE(displace_let_fun__env_206_integrate_let_fun_158, _displace_let_fun__244_integrate_let_fun_1581817, _displace_let_fun__244_integrate_let_fun_158, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_integrate_let_fun_158(long checksum_1717, char *from_1718)
{
   if (CBOOL(require_initialization_114_integrate_let_fun_158))
     {
	require_initialization_114_integrate_let_fun_158 = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_let_fun_158();
	cnst_init_137_integrate_let_fun_158();
	imported_modules_init_94_integrate_let_fun_158();
	method_init_76_integrate_let_fun_158();
	toplevel_init_63_integrate_let_fun_158();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_let_fun_158()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70___reader(((long) 0), "INTEGRATE_LET-FUN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_let_fun_158()
{
   {
      obj_t cnst_port_138_1709;
      cnst_port_138_1709 = open_input_string(string1805_integrate_let_fun_158);
      {
	 long i_1710;
	 i_1710 = ((long) 0);
       loop_1711:
	 {
	    bool_t test1806_1712;
	    test1806_1712 = (i_1710 == ((long) -1));
	    if (test1806_1712)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1807_1713;
		    {
		       obj_t list1808_1714;
		       {
			  obj_t arg1809_1715;
			  arg1809_1715 = BNIL;
			  list1808_1714 = MAKE_PAIR(cnst_port_138_1709, arg1809_1715);
		       }
		       arg1807_1713 = read___reader(list1808_1714);
		    }
		    CNST_TABLE_SET(i_1710, arg1807_1713);
		 }
		 {
		    int aux_1716;
		    {
		       long aux_1735;
		       aux_1735 = (i_1710 - ((long) 1));
		       aux_1716 = (int) (aux_1735);
		    }
		    {
		       long i_1738;
		       i_1738 = (long) (aux_1716);
		       i_1710 = i_1738;
		       goto loop_1711;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_let_fun_158()
{
   _stamp__29_integrate_let_fun_158 = ((long) 0);
   return BUNSPEC;
}


/* bind-fun! */ obj_t 
bind_fun__68_integrate_let_fun_158(obj_t var_1)
{
   {
      bool_t test1564_927;
      test1564_927 = is_a__118___object(var_1, local_ast_var);
      if (test1564_927)
	{
	   sfun_iinfo_105_t obj_1493;
	   obj_t val1513_1494;
	   {
	      value_t aux_1742;
	      {
		 local_t obj_1492;
		 obj_1492 = (local_t) (var_1);
		 aux_1742 = (((local_t) CREF(obj_1492))->value);
	      }
	      obj_1493 = (sfun_iinfo_105_t) (aux_1742);
	   }
	   val1513_1494 = BINT(_stamp__29_integrate_let_fun_158);
	   {
	      obj_t aux_1747;
	      {
		 object_t aux_1748;
		 aux_1748 = (object_t) (obj_1493);
		 aux_1747 = OBJECT_WIDENING(aux_1748);
	      }
	      return ((((sfun_iinfo_105_t) CREF(aux_1747))->istamp) = ((obj_t) val1513_1494), BUNSPEC);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* free-fun? */ bool_t 
free_fun__183_integrate_let_fun_158(obj_t local_2)
{
   {
      bool_t test1566_929;
      {
	 obj_t arg1568_930;
	 {
	    sfun_iinfo_105_t obj_1496;
	    {
	       value_t aux_1752;
	       {
		  local_t obj_1495;
		  obj_1495 = (local_t) (local_2);
		  aux_1752 = (((local_t) CREF(obj_1495))->value);
	       }
	       obj_1496 = (sfun_iinfo_105_t) (aux_1752);
	    }
	    {
	       obj_t aux_1756;
	       {
		  object_t aux_1757;
		  aux_1757 = (object_t) (obj_1496);
		  aux_1756 = OBJECT_WIDENING(aux_1757);
	       }
	       arg1568_930 = (((sfun_iinfo_105_t) CREF(aux_1756))->istamp);
	    }
	 }
	 {
	    obj_t obj2_1498;
	    obj2_1498 = BINT(_stamp__29_integrate_let_fun_158);
	    test1566_929 = (arg1568_930 == obj2_1498);
	 }
      }
      if (test1566_929)
	{
	   return ((bool_t) 0);
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* displace-let-fun! */ obj_t 
displace_let_fun__199_integrate_let_fun_158(obj_t var_3)
{
   {
      long z2_1500;
      z2_1500 = _stamp__29_integrate_let_fun_158;
      _stamp__29_integrate_let_fun_158 = (((long) 1) + z2_1500);
   }
   {
      node_t aux_1765;
      {
	 obj_t aux_1766;
	 {
	    sfun_t obj_1502;
	    {
	       value_t aux_1767;
	       {
		  variable_t obj_1501;
		  obj_1501 = (variable_t) (var_3);
		  aux_1767 = (((variable_t) CREF(obj_1501))->value);
	       }
	       obj_1502 = (sfun_t) (aux_1767);
	    }
	    aux_1766 = (((sfun_t) CREF(obj_1502))->body);
	 }
	 aux_1765 = (node_t) (aux_1766);
      }
      displace_let_fun_node__83_integrate_let_fun_158(aux_1765, (variable_t) (var_3));
   }
   {
      obj_t led_934;
      {
	 sfun_iinfo_105_t obj_1504;
	 {
	    value_t aux_1775;
	    {
	       variable_t obj_1503;
	       obj_1503 = (variable_t) (var_3);
	       aux_1775 = (((variable_t) CREF(obj_1503))->value);
	    }
	    obj_1504 = (sfun_iinfo_105_t) (aux_1775);
	 }
	 {
	    obj_t aux_1779;
	    {
	       object_t aux_1780;
	       aux_1780 = (object_t) (obj_1504);
	       aux_1779 = OBJECT_WIDENING(aux_1780);
	    }
	    led_934 = (((sfun_iinfo_105_t) CREF(aux_1779))->led);
	 }
      }
      {
	 obj_t l1517_935;
	 l1517_935 = led_934;
       lname1518_936:
	 if (PAIRP(l1517_935))
	   {
	      {
		 obj_t l_938;
		 l_938 = CAR(l1517_935);
		 if (free_fun__183_integrate_let_fun_158(l_938))
		   {
		      node_t aux_1789;
		      {
			 obj_t aux_1790;
			 {
			    sfun_t obj_1508;
			    {
			       value_t aux_1791;
			       {
				  variable_t obj_1507;
				  obj_1507 = (variable_t) (l_938);
				  aux_1791 = (((variable_t) CREF(obj_1507))->value);
			       }
			       obj_1508 = (sfun_t) (aux_1791);
			    }
			    aux_1790 = (((sfun_t) CREF(obj_1508))->body);
			 }
			 aux_1789 = (node_t) (aux_1790);
		      }
		      displace_let_fun_node__83_integrate_let_fun_158(aux_1789, (variable_t) (var_3));
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	      {
		 obj_t l1517_1799;
		 l1517_1799 = CDR(l1517_935);
		 l1517_935 = l1517_1799;
		 goto lname1518_936;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      {
	 obj_t led_943;
	 obj_t added_944;
	 led_943 = led_934;
	 added_944 = BNIL;
       loop_945:
	 if (NULLP(led_943))
	   {
	      if (PAIRP(added_944))
		{
		   obj_t old_body_129_949;
		   {
		      sfun_t obj_1513;
		      {
			 value_t aux_1805;
			 {
			    variable_t obj_1512;
			    obj_1512 = (variable_t) (var_3);
			    aux_1805 = (((variable_t) CREF(obj_1512))->value);
			 }
			 obj_1513 = (sfun_t) (aux_1805);
		      }
		      old_body_129_949 = (((sfun_t) CREF(obj_1513))->body);
		   }
		   {
		      let_fun_218_t new_body_215_950;
		      {
			 obj_t arg1585_952;
			 obj_t arg1586_953;
			 {
			    node_t obj_1514;
			    obj_1514 = (node_t) (old_body_129_949);
			    arg1585_952 = (((node_t) CREF(obj_1514))->loc);
			 }
			 arg1586_953 = ____74_type_cache;
			 {
			    let_fun_218_t res1799_1531;
			    {
			       type_t type_1516;
			       obj_t key_1518;
			       node_t body_1520;
			       type_1516 = (type_t) (arg1586_953);
			       key_1518 = BINT(((long) -1));
			       body_1520 = (node_t) (old_body_129_949);
			       {
				  let_fun_218_t new1354_1521;
				  new1354_1521 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
				  {
				     long arg1634_1522;
				     arg1634_1522 = class_num_218___object(let_fun_218_ast_node);
				     {
					obj_t obj_1529;
					obj_1529 = (obj_t) (new1354_1521);
					(((obj_t) CREF(obj_1529))->header = MAKE_HEADER(arg1634_1522, 0), BUNSPEC);
				     }
				  }
				  {
				     object_t aux_1819;
				     aux_1819 = (object_t) (new1354_1521);
				     OBJECT_WIDENING_SET(aux_1819, BFALSE);
				  }
				  ((((let_fun_218_t) CREF(new1354_1521))->loc) = ((obj_t) arg1585_952), BUNSPEC);
				  ((((let_fun_218_t) CREF(new1354_1521))->type) = ((type_t) type_1516), BUNSPEC);
				  ((((let_fun_218_t) CREF(new1354_1521))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
				  ((((let_fun_218_t) CREF(new1354_1521))->key) = ((obj_t) key_1518), BUNSPEC);
				  ((((let_fun_218_t) CREF(new1354_1521))->locals) = ((obj_t) added_944), BUNSPEC);
				  ((((let_fun_218_t) CREF(new1354_1521))->body) = ((node_t) body_1520), BUNSPEC);
				  res1799_1531 = new1354_1521;
			       }
			    }
			    new_body_215_950 = res1799_1531;
			 }
		      }
		      {
			 {
			    sfun_t obj_1533;
			    obj_t val1138_1534;
			    {
			       value_t aux_1828;
			       {
				  variable_t obj_1532;
				  obj_1532 = (variable_t) (var_3);
				  aux_1828 = (((variable_t) CREF(obj_1532))->value);
			       }
			       obj_1533 = (sfun_t) (aux_1828);
			    }
			    val1138_1534 = (obj_t) (new_body_215_950);
			    ((((sfun_t) CREF(obj_1533))->body) = ((obj_t) val1138_1534), BUNSPEC);
			 }
			 return (obj_t) (new_body_215_950);
		      }
		   }
		}
	      else
		{
		   return BUNSPEC;
		}
	   }
	 else
	   {
	      if (free_fun__183_integrate_let_fun_158(CAR(led_943)))
		{
		   {
		      obj_t arg1594_959;
		      obj_t arg1595_960;
		      arg1594_959 = CDR(led_943);
		      {
			 obj_t aux_1839;
			 aux_1839 = CAR(led_943);
			 arg1595_960 = MAKE_PAIR(aux_1839, added_944);
		      }
		      {
			 obj_t added_1843;
			 obj_t led_1842;
			 led_1842 = arg1594_959;
			 added_1843 = arg1595_960;
			 added_944 = added_1843;
			 led_943 = led_1842;
			 goto loop_945;
		      }
		   }
		}
	      else
		{
		   {
		      obj_t led_1844;
		      led_1844 = CDR(led_943);
		      led_943 = led_1844;
		      goto loop_945;
		   }
		}
	   }
      }
   }
}


/* _displace-let-fun! */ obj_t 
_displace_let_fun__244_integrate_let_fun_158(obj_t env_1701, obj_t var_1702)
{
   return displace_let_fun__199_integrate_let_fun_158(var_1702);
}


/* method-init */ obj_t 
method_init_76_integrate_let_fun_158()
{
   add_generic__110___object(displace_let_fun_node__env_245_integrate_let_fun_158, displace_let_fun_node__default1539_env_14_integrate_let_fun_158);
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, var_ast_node, ((long) 2));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, app_ast_node, ((long) 5));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, select_ast_node, ((long) 13));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, box_set__221_ast_node, ((long) 19));
   {
      long aux_1868;
      aux_1868 = add_inlined_method__244___object(displace_let_fun_node__env_245_integrate_let_fun_158, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_1868);
   }
}


/* displace-let-fun-node! */ obj_t 
displace_let_fun_node__83_integrate_let_fun_158(node_t node_4, variable_t variable_5)
{
 displace_let_fun_node__83_integrate_let_fun_158:
   {
      obj_t method1708_1342;
      obj_t class1713_1343;
      {
	 obj_t arg1716_1340;
	 obj_t arg1717_1341;
	 {
	    object_t obj_1606;
	    obj_1606 = (object_t) (node_4);
	    {
	       obj_t pre_method_105_1607;
	       pre_method_105_1607 = PROCEDURE_REF(displace_let_fun_node__env_245_integrate_let_fun_158, ((long) 2));
	       if (INTEGERP(pre_method_105_1607))
		 {
		    PROCEDURE_SET(displace_let_fun_node__env_245_integrate_let_fun_158, ((long) 2), BUNSPEC);
		    arg1716_1340 = pre_method_105_1607;
		 }
	       else
		 {
		    long obj_class_num_177_1612;
		    obj_class_num_177_1612 = TYPE(obj_1606);
		    {
		       obj_t arg1177_1613;
		       arg1177_1613 = PROCEDURE_REF(displace_let_fun_node__env_245_integrate_let_fun_158, ((long) 1));
		       {
			  long arg1178_1617;
			  {
			     long arg1179_1618;
			     arg1179_1618 = OBJECT_TYPE;
			     arg1178_1617 = (obj_class_num_177_1612 - arg1179_1618);
			  }
			  arg1716_1340 = VECTOR_REF(arg1177_1613, arg1178_1617);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1623;
	    object_1623 = (object_t) (node_4);
	    {
	       long arg1180_1624;
	       {
		  long arg1181_1625;
		  long arg1182_1626;
		  arg1181_1625 = TYPE(object_1623);
		  arg1182_1626 = OBJECT_TYPE;
		  arg1180_1624 = (arg1181_1625 - arg1182_1626);
	       }
	       {
		  obj_t vector_1630;
		  vector_1630 = _classes__134___object;
		  arg1717_1341 = VECTOR_REF(vector_1630, arg1180_1624);
	       }
	    }
	 }
	 method1708_1342 = arg1716_1340;
	 class1713_1343 = arg1717_1341;
	 {
	    if (INTEGERP(method1708_1342))
	      {
		 switch ((long) CINT(method1708_1342))
		   {
		   case ((long) 0):
		      return BUNSPEC;
		      break;
		   case ((long) 1):
		      return BUNSPEC;
		      break;
		   case ((long) 2):
		      return BUNSPEC;
		      break;
		   case ((long) 3):
		      {
			 obj_t arg1722_1359;
			 {
			    obj_t aux_1888;
			    {
			       closure_t aux_1889;
			       aux_1889 = (closure_t) (node_4);
			       aux_1888 = (obj_t) (aux_1889);
			    }
			    arg1722_1359 = shape_tools_shape(aux_1888);
			 }
			 return internal_error_43_tools_error(string1802_integrate_let_fun_158, string1803_integrate_let_fun_158, arg1722_1359);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1360;
			 node_1360 = (sequence_t) (node_4);
			 {
			    obj_t l1521_1363;
			    {
			       bool_t aux_1895;
			       l1521_1363 = (((sequence_t) CREF(node_1360))->nodes);
			     lname1522_1364:
			       if (PAIRP(l1521_1363))
				 {
				    {
				       node_t aux_1898;
				       {
					  obj_t aux_1899;
					  aux_1899 = CAR(l1521_1363);
					  aux_1898 = (node_t) (aux_1899);
				       }
				       displace_let_fun_node__83_integrate_let_fun_158(aux_1898, variable_5);
				    }
				    {
				       obj_t l1521_1903;
				       l1521_1903 = CDR(l1521_1363);
				       l1521_1363 = l1521_1903;
				       goto lname1522_1364;
				    }
				 }
			       else
				 {
				    aux_1895 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1895);
			    }
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1369;
			 node_1369 = (app_t) (node_4);
			 {
			    obj_t args_1371;
			    args_1371 = (((app_t) CREF(node_1369))->args);
			  liip_1372:
			    if (NULLP(args_1371))
			      {
				 return BUNSPEC;
			      }
			    else
			      {
				 {
				    node_t aux_1910;
				    {
				       obj_t aux_1911;
				       aux_1911 = CAR(args_1371);
				       aux_1910 = (node_t) (aux_1911);
				    }
				    displace_let_fun_node__83_integrate_let_fun_158(aux_1910, variable_5);
				 }
				 {
				    obj_t args_1915;
				    args_1915 = CDR(args_1371);
				    args_1371 = args_1915;
				    goto liip_1372;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1377;
			 node_1377 = (app_ly_162_t) (node_4);
			 displace_let_fun_node__83_integrate_let_fun_158((((app_ly_162_t) CREF(node_1377))->fun), variable_5);
			 {
			    node_t node_1921;
			    node_1921 = (((app_ly_162_t) CREF(node_1377))->arg);
			    node_4 = node_1921;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1382;
			 node_1382 = (funcall_t) (node_4);
			 {
			    obj_t asts_1385;
			    asts_1385 = (((funcall_t) CREF(node_1382))->args);
			  liip_1386:
			    if (NULLP(asts_1385))
			      {
				 node_t node_1926;
				 node_1926 = (((funcall_t) CREF(node_1382))->fun);
				 node_4 = node_1926;
				 goto displace_let_fun_node__83_integrate_let_fun_158;
			      }
			    else
			      {
				 {
				    node_t aux_1928;
				    {
				       obj_t aux_1929;
				       aux_1929 = CAR(asts_1385);
				       aux_1928 = (node_t) (aux_1929);
				    }
				    displace_let_fun_node__83_integrate_let_fun_158(aux_1928, variable_5);
				 }
				 {
				    obj_t asts_1933;
				    asts_1933 = CDR(asts_1385);
				    asts_1385 = asts_1933;
				    goto liip_1386;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1392;
			 node_1392 = (pragma_t) (node_4);
			 {
			    obj_t l1526_1395;
			    {
			       bool_t aux_1937;
			       l1526_1395 = (((pragma_t) CREF(node_1392))->args);
			     lname1527_1396:
			       if (PAIRP(l1526_1395))
				 {
				    {
				       node_t aux_1940;
				       {
					  obj_t aux_1941;
					  aux_1941 = CAR(l1526_1395);
					  aux_1940 = (node_t) (aux_1941);
				       }
				       displace_let_fun_node__83_integrate_let_fun_158(aux_1940, variable_5);
				    }
				    {
				       obj_t l1526_1945;
				       l1526_1945 = CDR(l1526_1395);
				       l1526_1395 = l1526_1945;
				       goto lname1527_1396;
				    }
				 }
			       else
				 {
				    aux_1937 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1937);
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1401;
			 node_1401 = (cast_t) (node_4);
			 {
			    node_t node_1950;
			    node_1950 = (((cast_t) CREF(node_1401))->arg);
			    node_4 = node_1950;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1405;
			 node_1405 = (setq_t) (node_4);
			 {
			    node_t node_1953;
			    node_1953 = (((setq_t) CREF(node_1405))->value);
			    node_4 = node_1953;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1409;
			 node_1409 = (conditional_t) (node_4);
			 displace_let_fun_node__83_integrate_let_fun_158((((conditional_t) CREF(node_1409))->test), variable_5);
			 displace_let_fun_node__83_integrate_let_fun_158((((conditional_t) CREF(node_1409))->true), variable_5);
			 {
			    node_t node_1960;
			    node_1960 = (((conditional_t) CREF(node_1409))->false);
			    node_4 = node_1960;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1415;
			 node_1415 = (fail_t) (node_4);
			 displace_let_fun_node__83_integrate_let_fun_158((((fail_t) CREF(node_1415))->proc), variable_5);
			 displace_let_fun_node__83_integrate_let_fun_158((((fail_t) CREF(node_1415))->msg), variable_5);
			 {
			    node_t node_1967;
			    node_1967 = (((fail_t) CREF(node_1415))->obj);
			    node_4 = node_1967;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1421;
			 node_1421 = (select_t) (node_4);
			 {
			    obj_t clauses_1424;
			    clauses_1424 = (((select_t) CREF(node_1421))->clauses);
			  liip_1425:
			    if (NULLP(clauses_1424))
			      {
				 node_t node_1972;
				 node_1972 = (((select_t) CREF(node_1421))->test);
				 node_4 = node_1972;
				 goto displace_let_fun_node__83_integrate_let_fun_158;
			      }
			    else
			      {
				 {
				    node_t aux_1974;
				    {
				       obj_t aux_1975;
				       {
					  obj_t aux_1976;
					  aux_1976 = CAR(clauses_1424);
					  aux_1975 = CDR(aux_1976);
				       }
				       aux_1974 = (node_t) (aux_1975);
				    }
				    displace_let_fun_node__83_integrate_let_fun_158(aux_1974, variable_5);
				 }
				 {
				    obj_t clauses_1981;
				    clauses_1981 = CDR(clauses_1424);
				    clauses_1424 = clauses_1981;
				    goto liip_1425;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1432;
			 node_1432 = (let_fun_218_t) (node_4);
			 {
			    obj_t old_1435;
			    obj_t new_1436;
			    old_1435 = (((let_fun_218_t) CREF(node_1432))->locals);
			    new_1436 = BNIL;
			  liip_1437:
			    if (NULLP(old_1435))
			      {
				 ((((let_fun_218_t) CREF(node_1432))->locals) = ((obj_t) new_1436), BUNSPEC);
				 {
				    node_t node_1988;
				    node_1988 = (((let_fun_218_t) CREF(node_1432))->body);
				    node_4 = node_1988;
				    goto displace_let_fun_node__83_integrate_let_fun_158;
				 }
			      }
			    else
			      {
				 bool_t test_1990;
				 {
				    obj_t aux_2003;
				    obj_t aux_1991;
				    aux_2003 = (obj_t) (variable_5);
				    {
				       sfun_iinfo_105_t obj_1673;
				       {
					  value_t aux_1992;
					  {
					     local_t obj_1672;
					     {
						obj_t aux_1993;
						aux_1993 = CAR(old_1435);
						obj_1672 = (local_t) (aux_1993);
					     }
					     aux_1992 = (((local_t) CREF(obj_1672))->value);
					  }
					  obj_1673 = (sfun_iinfo_105_t) (aux_1992);
				       }
				       {
					  obj_t aux_1998;
					  {
					     object_t aux_1999;
					     aux_1999 = (object_t) (obj_1673);
					     aux_1998 = OBJECT_WIDENING(aux_1999);
					  }
					  aux_1991 = (((sfun_iinfo_105_t) CREF(aux_1998))->l);
				       }
				    }
				    test_1990 = (aux_1991 == aux_2003);
				 }
				 if (test_1990)
				   {
				      {
					 obj_t l_1444;
					 l_1444 = CAR(old_1435);
					 bind_fun__68_integrate_let_fun_158(l_1444);
					 {
					    node_t aux_2008;
					    {
					       obj_t aux_2009;
					       {
						  sfun_t obj_1678;
						  {
						     value_t aux_2010;
						     {
							local_t obj_1677;
							obj_1677 = (local_t) (l_1444);
							aux_2010 = (((local_t) CREF(obj_1677))->value);
						     }
						     obj_1678 = (sfun_t) (aux_2010);
						  }
						  aux_2009 = (((sfun_t) CREF(obj_1678))->body);
					       }
					       aux_2008 = (node_t) (aux_2009);
					    }
					    displace_let_fun_node__83_integrate_let_fun_158(aux_2008, variable_5);
					 }
					 {
					    obj_t arg1777_1447;
					    obj_t arg1778_1448;
					    arg1777_1447 = CDR(old_1435);
					    arg1778_1448 = MAKE_PAIR(l_1444, new_1436);
					    {
					       obj_t new_2020;
					       obj_t old_2019;
					       old_2019 = arg1777_1447;
					       new_2020 = arg1778_1448;
					       new_1436 = new_2020;
					       old_1435 = old_2019;
					       goto liip_1437;
					    }
					 }
				      }
				   }
				 else
				   {
				      {
					 obj_t old_2021;
					 old_2021 = CDR(old_1435);
					 old_1435 = old_2021;
					 goto liip_1437;
				      }
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1453;
			 node_1453 = (let_var_6_t) (node_4);
			 {
			    obj_t bindings_1456;
			    bindings_1456 = (((let_var_6_t) CREF(node_1453))->bindings);
			  liip_1457:
			    if (NULLP(bindings_1456))
			      {
				 node_t node_2027;
				 node_2027 = (((let_var_6_t) CREF(node_1453))->body);
				 node_4 = node_2027;
				 goto displace_let_fun_node__83_integrate_let_fun_158;
			      }
			    else
			      {
				 {
				    node_t aux_2029;
				    {
				       obj_t aux_2030;
				       {
					  obj_t aux_2031;
					  aux_2031 = CAR(bindings_1456);
					  aux_2030 = CDR(aux_2031);
				       }
				       aux_2029 = (node_t) (aux_2030);
				    }
				    displace_let_fun_node__83_integrate_let_fun_158(aux_2029, variable_5);
				 }
				 {
				    obj_t bindings_2036;
				    bindings_2036 = CDR(bindings_1456);
				    bindings_1456 = bindings_2036;
				    goto liip_1457;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1465;
			 node_1465 = (set_ex_it_116_t) (node_4);
			 {
			    node_t node_2040;
			    node_2040 = (((set_ex_it_116_t) CREF(node_1465))->body);
			    node_4 = node_2040;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1469;
			 node_1469 = (jump_ex_it_184_t) (node_4);
			 displace_let_fun_node__83_integrate_let_fun_158((((jump_ex_it_184_t) CREF(node_1469))->exit), variable_5);
			 {
			    node_t node_2045;
			    node_2045 = (((jump_ex_it_184_t) CREF(node_1469))->value);
			    node_4 = node_2045;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1474;
			 node_1474 = (make_box_202_t) (node_4);
			 {
			    node_t node_2048;
			    node_2048 = (((make_box_202_t) CREF(node_1474))->value);
			    node_4 = node_2048;
			    goto displace_let_fun_node__83_integrate_let_fun_158;
			 }
		      }
		      break;
		   case ((long) 19):
		      return BUNSPEC;
		      break;
		   case ((long) 20):
		      return BUNSPEC;
		      break;
		   default:
		    case_else1714_1346:
		      if (PROCEDUREP(method1708_1342))
			{
			   return PROCEDURE_ENTRY(method1708_1342) (method1708_1342, (obj_t) (node_4), (obj_t) (variable_5), BEOA);
			}
		      else
			{
			   obj_t fun1705_1336;
			   fun1705_1336 = PROCEDURE_REF(displace_let_fun_node__env_245_integrate_let_fun_158, ((long) 0));
			   return PROCEDURE_ENTRY(fun1705_1336) (fun1705_1336, (obj_t) (node_4), (obj_t) (variable_5), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1714_1346;
	      }
	 }
      }
   }
}


/* _displace-let-fun-node!1801 */ obj_t 
_displace_let_fun_node_1801_129_integrate_let_fun_158(obj_t env_1703, obj_t node_1704, obj_t variable_1705)
{
   return displace_let_fun_node__83_integrate_let_fun_158((node_t) (node_1704), (variable_t) (variable_1705));
}


/* displace-let-fun-node!-default1539 */ obj_t 
displace_let_fun_node__default1539_188_integrate_let_fun_158(node_t node_6, variable_t variable_7)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1804_integrate_let_fun_158, (obj_t) (node_6));
}


/* _displace-let-fun-node!-default1539 */ obj_t 
_displace_let_fun_node__default1539_115_integrate_let_fun_158(obj_t env_1706, obj_t node_1707, obj_t variable_1708)
{
   return displace_let_fun_node__default1539_188_integrate_let_fun_158((node_t) (node_1707), (variable_t) (variable_1708));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_let_fun_158()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70_tools_error(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70_type_cache(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_LET-FUN");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_LET-FUN");
   return module_initialization_70_integrate_info(((long) 0), "INTEGRATE_LET-FUN");
}
