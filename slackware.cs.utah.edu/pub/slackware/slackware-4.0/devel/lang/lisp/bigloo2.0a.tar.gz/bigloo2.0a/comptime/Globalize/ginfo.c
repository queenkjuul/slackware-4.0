/*===========================================================================*/
/*   (Globalize/ginfo.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t global_ginfo_pragma_81_globalize_ginfo(global_t);
extern obj_t sfun_ginfo_the_closure_142_globalize_ginfo(sfun_t);
extern long svar_ginfo_mark_222_globalize_ginfo(svar_ginfo_131_t);
static obj_t _sexit_ginfo_free_mark_set_1975_136_globalize_ginfo(obj_t, obj_t, obj_t);
obj_t local_ginfo_108_globalize_ginfo = BUNSPEC;
static obj_t _global_ginfo_evaluable_1932_56_globalize_ginfo(obj_t, obj_t);
static obj_t _local_ginfo_removable_set_1956_187_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t method_init_76_globalize_ginfo();
static obj_t _local_ginfo_user__set_1960_217_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_cfunction2027_40_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_property2005_186_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_body2009_182_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_integrator_0_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _sfun_ginfo_integrated2031_50_globalize_ginfo(obj_t, obj_t);
static obj_t _svar_ginfo_loc1982_28_globalize_ginfo(obj_t, obj_t);
static obj_t _widening1004_sexit_ginfo1965_122_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_the_global_234_globalize_ginfo(sfun_ginfo_98_t);
extern obj_t sfun_ginfo_cfunction_set__96_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _svar_ginfo_mark_set_1987_218_globalize_ginfo(obj_t, obj_t, obj_t);
extern value_t global_ginfo_value_89_globalize_ginfo(global_t);
extern bool_t local_ginfo__237_globalize_ginfo(obj_t);
static obj_t _sfun_ginfo_bound2051_125_globalize_ginfo(obj_t, obj_t);
static obj_t _svar_ginfo_free_mark1986_33_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_src_234_globalize_ginfo(global_t);
extern obj_t sfun_ginfo_integrated_166_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _svar_ginfo_loc_set_1981_1_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t svar_ginfo_loc_set__72_globalize_ginfo(svar_t, obj_t);
static obj_t _local_ginfo_access1953_31_globalize_ginfo(obj_t, obj_t);
static obj_t _sexit_ginfo_detached_1970_21_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_dsssl_keywords_set__63_globalize_ginfo(sfun_t, obj_t);
static obj_t _svar_ginfo_kaptured_1984_32_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_import_118_globalize_ginfo(global_t);
static obj_t _global_ginfo_user__set_1935_222_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_the_closure_set__229_globalize_ginfo(sfun_t, obj_t);
extern obj_t svar_ginfo_mark_set__188_globalize_ginfo(svar_ginfo_131_t, long);
static obj_t _object__struct2056_162___object(obj_t, obj_t);
static obj_t _sfun_ginfo_mark_set_2034_116_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t global_ginfo_removable_set__202_globalize_ginfo(global_t, obj_t);
extern obj_t global_ginfo_library__set__196_globalize_ginfo(global_t, bool_t);
static obj_t _local_ginfo_value1951_216_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_free_mark2037_104_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_the_closure_set_2002_174_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_key1962_209_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_body_set_2008_75_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_access1921_118_globalize_ginfo(obj_t, obj_t);
extern obj_t local_ginfo_name_set__6_globalize_ginfo(local_t, obj_t);
static obj_t _global_ginfo_name1915_88_globalize_ginfo(obj_t, obj_t);
extern obj_t local_ginfo_name_216_globalize_ginfo(local_t);
static obj_t _sfun_ginfo_predicate_of_set_1996_93_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_umark_set__215_globalize_ginfo(sfun_ginfo_98_t, long);
static obj_t _local_ginfo_occurrence1959_202_globalize_ginfo(obj_t, obj_t);
static obj_t _global_ginfo_removable1925_131_globalize_ginfo(obj_t, obj_t);
static obj_t _widening1005_local_ginfo_143_globalize_ginfo(obj_t, obj_t);
static obj_t _local_ginfo_name1947_28_globalize_ginfo(obj_t, obj_t);
extern obj_t local_ginfo_occurrence_set__71_globalize_ginfo(local_t, long);
extern obj_t global_ginfo_global_closure_set__44_globalize_ginfo(global_ginfo_75_t, obj_t);
extern obj_t local_ginfo_id_0_globalize_ginfo(local_t);
static obj_t _widening1003_svar_ginfo1979_241_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _allocate_sexit_ginfo_207_globalize_ginfo(obj_t);
static obj_t _allocate_sfun_ginfo_166_globalize_ginfo(obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
static obj_t _sfun_ginfo_arity1993_184_globalize_ginfo(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_escape__set_1940_204_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_escape__set_1963_222_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
static obj_t _sfun_ginfo_the_global_set_2038_246_globalize_ginfo(obj_t, obj_t, obj_t);
extern sexit_ginfo_81_t make_sexit_ginfo_64_globalize_ginfo(obj_t, bool_t, bool_t, bool_t, long, long);
static obj_t _sfun_ginfo_mark2035_225_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_g__set__43_globalize_ginfo(sfun_ginfo_98_t, bool_t);
static obj_t _sfun_ginfo_stack_allocator1999_228_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_import_set__11_globalize_ginfo(global_t, obj_t);
static obj_t _global_ginfo_occurrence1927_163_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_new_body_94_globalize_ginfo(sfun_ginfo_98_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern type_t global_ginfo_type_26_globalize_ginfo(global_t);
static obj_t _sexit_ginfo_mark_set_1977_141_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sexit_ginfo_free_mark1976_202_globalize_ginfo(obj_t, obj_t);
static obj_t _global_ginfo_evaluable__set_1931_107_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_cto__set__57_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t object__struct_sexit_ginfo_51_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_evaluable__set__37_globalize_ginfo(global_t, bool_t);
extern obj_t global_ginfo_module_155_globalize_ginfo(global_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _sexit_ginfo_kaptured_1974_188_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_plugged_in_96_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _sfun_ginfo_free_set_2048_178_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _svar_ginfo_kaptured__set_1983_89_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_plugged_in_set__154_globalize_ginfo(sfun_ginfo_98_t, obj_t);
extern obj_t global_ginfo_id_159_globalize_ginfo(global_t);
extern obj_t sfun_ginfo_cto__157_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _svar_ginfo_celled__set_1989_101_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _allocate_svar_ginfo_235_globalize_ginfo(obj_t);
static obj_t _global_ginfo__15_globalize_ginfo(obj_t, obj_t);
extern global_ginfo_75_t widening1006_global_ginfo_171_globalize_ginfo(bool_t, obj_t);
static obj_t _global_ginfo_id1913_181_globalize_ginfo(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern bool_t sexit_ginfo_detached__158_globalize_ginfo(sexit_t);
static obj_t _sfun_ginfo_stack_allocator_set_1998_90_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_cto_2025_13_globalize_ginfo(obj_t, obj_t);
extern bool_t global_ginfo_library__79_globalize_ginfo(global_t);
static obj_t struct_object__object_sexit_ginfo_170_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _allocate_global_ginfo_49_globalize_ginfo(obj_t);
extern obj_t sfun_ginfo_loc_36_globalize_ginfo(sfun_t);
extern obj_t global_ginfo_global_closure_105_globalize_ginfo(global_ginfo_75_t);
extern local_ginfo_108_t widening1005_local_ginfo_114_globalize_ginfo(bool_t);
extern obj_t sfun_ginfo_cfunction_167_globalize_ginfo(sfun_ginfo_98_t);
extern sfun_ginfo_98_t widening1002_sfun_ginfo_193_globalize_ginfo(bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, long, obj_t, obj_t, obj_t, obj_t, long, long, obj_t, obj_t);
extern bool_t sfun_ginfo_top__136_globalize_ginfo(sfun_t);
extern obj_t sfun_ginfo_bound_set__10_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _sfun_ginfo_plugged_in_set_2032_201_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_fast_alpha1955_194_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_integrator_set_2028_220_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_type_set_1916_135_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_escape_1964_248_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_bmark_set_2044_58_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_free_mark_set_2036_53_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_the_global2039_172_globalize_ginfo(obj_t, obj_t);
static obj_t _make_sfun_ginfo1992_161_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _local_ginfo__39_globalize_ginfo(obj_t, obj_t);
static obj_t _global_ginfo_library__set_1933_31_globalize_ginfo(obj_t, obj_t, obj_t);
extern long sfun_ginfo_bmark_99_globalize_ginfo(sfun_ginfo_98_t);
extern obj_t sfun_ginfo_kaptured_55_globalize_ginfo(sfun_ginfo_98_t);
extern obj_t sfun_ginfo_mark_set__52_globalize_ginfo(sfun_ginfo_98_t, long);
static obj_t _widening1002_sfun_ginfo1991_162_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_kaptured2041_71_globalize_ginfo(obj_t, obj_t);
extern obj_t sexit_ginfo_detached__set__219_globalize_ginfo(sexit_t, bool_t);
extern value_t local_ginfo_value_118_globalize_ginfo(local_t);
extern long class_num_218___object(obj_t);
extern obj_t sfun_ginfo_side_effect__set__170_globalize_ginfo(sfun_t, obj_t);
static obj_t _svar_ginfo_free_mark_set_1985_110_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t svar_ast_var;
static obj_t _global_ginfo_pragma1937_98_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_cto_set__23_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _global_ginfo_fast_alpha1923_122_globalize_ginfo(obj_t, obj_t);
extern sexit_ginfo_81_t widening1004_sexit_ginfo_15_globalize_ginfo(bool_t, bool_t, long, long);
extern bool_t sfun_ginfo_g__97_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _global_ginfo_module1928_42_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_cto_set_2022_194_globalize_ginfo(obj_t, obj_t, obj_t);
extern long local_ginfo_key_185_globalize_ginfo(local_t);
static obj_t _global_ginfo_global_closure1943_205_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_kaptured_set_2040_243_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_user_1936_195_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_plugged_in2033_157_globalize_ginfo(obj_t, obj_t);
static obj_t _local_ginfo_occurrence_set_1958_113_globalize_ginfo(obj_t, obj_t, obj_t);
extern bool_t global_ginfo_evaluable__184_globalize_ginfo(global_t);
extern long svar_ginfo_free_mark_225_globalize_ginfo(svar_ginfo_131_t);
static obj_t _local_ginfo_name_set_1946_240_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t local_ginfo_user__set__80_globalize_ginfo(local_t, bool_t);
extern obj_t sfun_ginfo_stack_allocator_set__224_globalize_ginfo(sfun_t, obj_t);
extern obj_t global_ginfo_user__set__96_globalize_ginfo(global_t, bool_t);
static obj_t _sfun_ginfo_loc_set_2014_18_globalize_ginfo(obj_t, obj_t, obj_t);
extern sfun_t allocate_sfun_ginfo_135_globalize_ginfo();
static obj_t imported_modules_init_94_globalize_ginfo();
extern sexit_t allocate_sexit_ginfo_150_globalize_ginfo();
static obj_t _struct_object__object2054_67___object(obj_t, obj_t, obj_t);
obj_t sfun_ginfo_98_globalize_ginfo = BUNSPEC;
static obj_t _sfun_ginfo_umark_set_2046_23_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_fast_alpha_set_1954_173_globalize_ginfo(obj_t, obj_t, obj_t);
extern bool_t sexit_ginfo_kaptured__46_globalize_ginfo(sexit_ginfo_81_t);
static obj_t _local_ginfo_access_set_1952_60_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_integrator2029_44_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_loc2015_63_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_args_set_2006_216_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_cto_17_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _sfun_ginfo_cfrom2019_6_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_src_set__129_globalize_ginfo(global_t, obj_t);
static obj_t _sexit_ginfo_g__set_1971_227_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_args_set__144_globalize_ginfo(sfun_t, obj_t);
extern obj_t svar_ginfo_free_mark_set__224_globalize_ginfo(svar_ginfo_131_t, long);
extern obj_t svar_ginfo_celled__set__234_globalize_ginfo(svar_ginfo_131_t, bool_t);
static obj_t _global_ginfo_occurrence_set_1926_26_globalize_ginfo(obj_t, obj_t, obj_t);
extern global_ginfo_75_t make_global_ginfo_116_globalize_ginfo(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, obj_t, obj_t, bool_t, bool_t, bool_t, obj_t, obj_t, bool_t, obj_t);
extern long local_ginfo_occurrence_196_globalize_ginfo(local_t);
extern long global_ginfo_occurrence_12_globalize_ginfo(global_t);
static obj_t _global_ginfo_src_set_1938_192_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t local_ginfo_access_set__117_globalize_ginfo(local_t, obj_t);
obj_t sexit_ginfo_81_globalize_ginfo = BUNSPEC;
extern obj_t global_ginfo_access_set__63_globalize_ginfo(global_t, obj_t);
extern svar_t allocate_svar_ginfo_12_globalize_ginfo();
static obj_t library_modules_init_112_globalize_ginfo();
obj_t global_ginfo_75_globalize_ginfo = BUNSPEC;
static obj_t _make_global_ginfo1912_17_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _global_ginfo_fast_alpha_set_1922_222_globalize_ginfo(obj_t, obj_t, obj_t);
obj_t svar_ginfo_131_globalize_ginfo = BUNSPEC;
static obj_t _sfun_ginfo_class_set_2010_243_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_free_set__132_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _sfun_ginfo_top__set_2000_198_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_cfunction_set_2026_162_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_free2049_252_globalize_ginfo(obj_t, obj_t);
static obj_t _sexit_ginfo_g_1972_232_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_bmark2045_226_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_body_35_globalize_ginfo(sfun_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _sfun_ginfo_bound_set_2050_128_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t local_ginfo_escape__set__30_globalize_ginfo(local_ginfo_108_t, bool_t);
static obj_t struct_object__object_global_ginfo_231_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _local_ginfo_removable1957_202_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_fast_alpha_set__195_globalize_ginfo(global_t, obj_t);
extern obj_t sexit_ginfo_g__set__228_globalize_ginfo(sexit_ginfo_81_t, bool_t);
extern type_t local_ginfo_type_222_globalize_ginfo(local_t);
static obj_t _sfun_ginfo_class2011_170_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_predicate_of_20_globalize_ginfo(sfun_t);
static obj_t toplevel_init_63_globalize_ginfo();
static obj_t _global_ginfo_removable_set_1924_222_globalize_ginfo(obj_t, obj_t, obj_t);
extern bool_t global_ginfo_escape__39_globalize_ginfo(global_ginfo_75_t);
static obj_t _svar_ginfo_mark1988_222_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_the_closure2003_217_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_escape__set__142_globalize_ginfo(global_ginfo_75_t, bool_t);
extern bool_t global_ginfo_user__167_globalize_ginfo(global_t);
extern long sexit_ginfo_mark_71_globalize_ginfo(sexit_ginfo_81_t);
extern obj_t sfun_ginfo_bound_35_globalize_ginfo(sfun_ginfo_98_t);
extern obj_t open_input_string(obj_t);
extern sfun_ginfo_98_t make_sfun_ginfo_212_globalize_ginfo(long, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, long, obj_t, obj_t, obj_t, obj_t, long, long, obj_t, obj_t);
static obj_t _svar_ginfo_celled_1990_10_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_top__set__155_globalize_ginfo(sfun_t, bool_t);
static obj_t _sfun_ginfo_cfrom_set_2018_248_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_src1939_79_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ast_var;
static obj_t _global_ginfo_escape_1941_218_globalize_ginfo(obj_t, obj_t);
extern obj_t svar_ginfo_kaptured__set__85_globalize_ginfo(svar_ginfo_131_t, bool_t);
extern obj_t local_ginfo_access_122_globalize_ginfo(local_t);
extern obj_t global_ginfo_removable_27_globalize_ginfo(global_t);
static obj_t _sexit_ginfo_mark1978_67_globalize_ginfo(obj_t, obj_t);
static obj_t _allocate_local_ginfo_111_globalize_ginfo(obj_t);
extern obj_t sfun_ginfo_cfrom__set__37_globalize_ginfo(sfun_ginfo_98_t, obj_t);
extern obj_t sfun_ginfo_loc_set__94_globalize_ginfo(sfun_t, obj_t);
static obj_t _global_ginfo_type1917_181_globalize_ginfo(obj_t, obj_t);
extern obj_t sexit_ginfo_mark_set__228_globalize_ginfo(sexit_ginfo_81_t, long);
extern obj_t svar_ginfo_loc_12_globalize_ginfo(svar_t);
extern obj_t sfun_ginfo_args_248_globalize_ginfo(sfun_t);
extern obj_t sfun_ginfo_cfrom_197_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _sfun_ginfo_dsssl_keywords2013_44_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_the_global_set__129_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _sfun_ginfo_side_effect__set_1994_222_globalize_ginfo(obj_t, obj_t, obj_t);
extern local_ginfo_108_t make_local_ginfo_207_globalize_ginfo(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, bool_t, long, bool_t);
extern obj_t sfun_ginfo_bmark_set__251_globalize_ginfo(sfun_ginfo_98_t, long);
static obj_t _sfun_ginfo_side_effect_1995_189_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_free_mark_233_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _sfun_ginfo_integrated_set_2030_140_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_type1949_237_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_side_effect__156_globalize_ginfo(sfun_t);
static obj_t _sexit_ginfo_detached__set_1969_156_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_integrator_set__91_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _make_svar_ginfo1980_37_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t sexit_ginfo__159_globalize_ginfo(obj_t);
extern global_t allocate_global_ginfo_174_globalize_ginfo();
extern obj_t sexit_ginfo_handler_183_globalize_ginfo(sexit_t);
extern bool_t sexit_ginfo_g__71_globalize_ginfo(sexit_ginfo_81_t);
extern obj_t sfun_ginfo_free_mark_set__121_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _sfun_ginfo_new_body2043_142_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_property_59_globalize_ginfo(sfun_t);
extern obj_t local_ast_var;
extern svar_ginfo_131_t make_svar_ginfo_120_globalize_ginfo(obj_t, bool_t, long, long, bool_t);
static obj_t _global_ginfo_import_set_1929_239_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _local_ginfo_user_1961_153_globalize_ginfo(obj_t, obj_t);
extern obj_t global_ginfo_type_set__85_globalize_ginfo(global_t, type_t);
static obj_t _svar_ginfo__189_globalize_ginfo(obj_t, obj_t);
static obj_t object__struct_local_ginfo_71_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_new_body_set_2042_21_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_property_set__8_globalize_ginfo(sfun_t, obj_t);
static obj_t _make_sexit_ginfo1966_234_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_dsssl_keywords_set_2012_227_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t local_ginfo_value_set__11_globalize_ginfo(local_t, value_t);
extern obj_t global_ginfo_value_set__149_globalize_ginfo(global_t, value_t);
extern bool_t global_ginfo__175_globalize_ginfo(obj_t);
static obj_t struct_object__object_sfun_ginfo_84_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t local_ginfo_fast_alpha_set__62_globalize_ginfo(local_t, obj_t);
extern obj_t local_ginfo_fast_alpha_16_globalize_ginfo(local_t);
extern obj_t global_ginfo_fast_alpha_123_globalize_ginfo(global_t);
static obj_t _local_ginfo_id1945_127_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_stack_allocator_225_globalize_ginfo(sfun_t);
extern obj_t sfun_ginfo_kaptured_set__247_globalize_ginfo(sfun_ginfo_98_t, obj_t);
static obj_t _sfun_ginfo_cfrom_2021_90_globalize_ginfo(obj_t, obj_t);
static obj_t _local_ginfo_type_set_1948_38_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t global_ginfo_name_179_globalize_ginfo(global_t);
static obj_t _global_ginfo_value1919_17_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_predicate_of_set__49_globalize_ginfo(sfun_t, obj_t);
extern obj_t sfun_ginfo_free_174_globalize_ginfo(sfun_ginfo_98_t);
extern obj_t sexit_ginfo_free_mark_set__210_globalize_ginfo(sexit_ginfo_81_t, long);
static obj_t _sfun_ginfo_top_2001_123_globalize_ginfo(obj_t, obj_t);
static obj_t struct_object__object_local_ginfo_129_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t object_init_111_globalize_ginfo();
static obj_t _widening1006_global_ginfo_21_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_g__set_2016_77_globalize_ginfo(obj_t, obj_t, obj_t);
extern bool_t svar_ginfo__247_globalize_ginfo(obj_t);
static obj_t _sfun_ginfo__175_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_g_2017_38_globalize_ginfo(obj_t, obj_t);
static obj_t _local_ginfo_value_set_1950_236_globalize_ginfo(obj_t, obj_t, obj_t);
extern long sfun_ginfo_mark_177_globalize_ginfo(sfun_ginfo_98_t);
static obj_t struct_object__object_svar_ginfo_79_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t object__struct_sfun_ginfo_180_globalize_ginfo(obj_t, obj_t);
extern obj_t sexit_ast_var;
static obj_t _sfun_ginfo_cto__set_2024_109_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sexit_ginfo_handler_set_1967_150_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t sfun_ginfo_dsssl_keywords_77_globalize_ginfo(sfun_t);
static obj_t _sfun_ginfo_cto2023_156_globalize_ginfo(obj_t, obj_t);
extern bool_t svar_ginfo_kaptured__26_globalize_ginfo(svar_ginfo_131_t);
extern obj_t local_ginfo_removable_170_globalize_ginfo(local_t);
static obj_t _sfun_ginfo_args2007_38_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_property_set_2004_201_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _global_ginfo_value_set_1918_98_globalize_ginfo(obj_t, obj_t, obj_t);
extern obj_t local_ginfo_removable_set__201_globalize_ginfo(local_t, obj_t);
extern bool_t sfun_ginfo__192_globalize_ginfo(obj_t);
extern obj_t global_ginfo_name_set__78_globalize_ginfo(global_t, obj_t);
extern long sfun_ginfo_arity_67_globalize_ginfo(sfun_t);
static obj_t _sexit_ginfo_kaptured__set_1973_234_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_access_set_1920_170_globalize_ginfo(obj_t, obj_t, obj_t);
extern bool_t local_ginfo_user__24_globalize_ginfo(local_t);
extern bool_t svar_ginfo_celled__246_globalize_ginfo(svar_ginfo_131_t);
extern obj_t sfun_ginfo_new_body_set__157_globalize_ginfo(sfun_ginfo_98_t, obj_t);
extern svar_ginfo_131_t widening1003_svar_ginfo_186_globalize_ginfo(bool_t, long, long, bool_t);
extern long sfun_ginfo_umark_66_globalize_ginfo(sfun_ginfo_98_t);
extern bool_t local_ginfo_escape__169_globalize_ginfo(local_ginfo_108_t);
extern local_t allocate_local_ginfo_201_globalize_ginfo();
extern obj_t sfun_ginfo_class_109_globalize_ginfo(sfun_t);
extern obj_t sexit_ginfo_handler_set__242_globalize_ginfo(sexit_t, obj_t);
extern obj_t sfun_ginfo_body_set__10_globalize_ginfo(sfun_t, obj_t);
static obj_t _sexit_ginfo_handler1968_234_globalize_ginfo(obj_t, obj_t);
extern obj_t sexit_ginfo_kaptured__set__207_globalize_ginfo(sexit_ginfo_81_t, bool_t);
static obj_t _make_local_ginfo1944_153_globalize_ginfo(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sfun_ginfo_umark2047_231_globalize_ginfo(obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
extern obj_t global_ginfo_access_77_globalize_ginfo(global_t);
static obj_t _global_ginfo_library_1934_9_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_predicate_of1997_37_globalize_ginfo(obj_t, obj_t);
extern obj_t local_ginfo_type_set__188_globalize_ginfo(local_t, type_t);
static obj_t object__struct_svar_ginfo_152_globalize_ginfo(obj_t, obj_t);
static obj_t require_initialization_114_globalize_ginfo = BUNSPEC;
extern obj_t sfun_ginfo_cfrom__184_globalize_ginfo(sfun_ginfo_98_t);
static obj_t _global_ginfo_import1930_103_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_class_set__182_globalize_ginfo(sfun_t, obj_t);
static obj_t _global_ginfo_name_set_1914_244_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _sexit_ginfo__121_globalize_ginfo(obj_t, obj_t);
extern obj_t sfun_ginfo_integrated_set__252_globalize_ginfo(sfun_ginfo_98_t, obj_t);
extern obj_t sfun_ginfo_cfrom_set__112_globalize_ginfo(sfun_ginfo_98_t, obj_t);
extern obj_t global_ginfo_occurrence_set__72_globalize_ginfo(global_t, long);
extern long sexit_ginfo_free_mark_205_globalize_ginfo(sexit_ginfo_81_t);
static obj_t cnst_init_137_globalize_ginfo();
static obj_t object__struct_global_ginfo_101_globalize_ginfo(obj_t, obj_t);
static obj_t _sfun_ginfo_cfrom__set_2020_255_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t _global_ginfo_global_closure_set_1942_202_globalize_ginfo(obj_t, obj_t, obj_t);
static obj_t __cnst[5];

DEFINE_EXPORT_PROCEDURE(global_ginfo_type_set__env_171_globalize_ginfo, _global_ginfo_type_set_1916_135_globalize_ginfo2073, _global_ginfo_type_set_1916_135_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(widening1003_svar_ginfo_env_196_globalize_ginfo, _widening1003_svar_ginfo1979_241_globalize_ginfo2074, _widening1003_svar_ginfo1979_241_globalize_ginfo, 0L, 4);
DEFINE_EXPORT_PROCEDURE(local_ginfo_fast_alpha_env_165_globalize_ginfo, _local_ginfo_fast_alpha1955_194_globalize_ginfo2075, _local_ginfo_fast_alpha1955_194_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_sfun_ginfo_env_145_globalize_ginfo, _make_sfun_ginfo1992_161_globalize_ginfo2076, _make_sfun_ginfo1992_161_globalize_ginfo, 0L, 30);
DEFINE_EXPORT_PROCEDURE(allocate_local_ginfo_env_148_globalize_ginfo, _allocate_local_ginfo_111_globalize_ginfo2077, _allocate_local_ginfo_111_globalize_ginfo, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_args_set__env_243_globalize_ginfo, _sfun_ginfo_args_set_2006_216_globalize_ginfo2078, _sfun_ginfo_args_set_2006_216_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_occurrence_env_74_globalize_ginfo, _global_ginfo_occurrence1927_163_globalize_ginfo2079, _global_ginfo_occurrence1927_163_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_free_mark_set__env_100_globalize_ginfo, _sfun_ginfo_free_mark_set_2036_53_globalize_ginfo2080, _sfun_ginfo_free_mark_set_2036_53_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_handler_set__env_200_globalize_ginfo, _sexit_ginfo_handler_set_1967_150_globalize_ginfo2081, _sexit_ginfo_handler_set_1967_150_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo__env_30_globalize_ginfo, _local_ginfo__39_globalize_ginfo2082, _local_ginfo__39_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_free_mark_set__env_33_globalize_ginfo, _svar_ginfo_free_mark_set_1985_110_globalize_ginfo2083, _svar_ginfo_free_mark_set_1985_110_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_property_set__env_130_globalize_ginfo, _sfun_ginfo_property_set_2004_201_globalize_ginfo2084, _sfun_ginfo_property_set_2004_201_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_top__set__env_228_globalize_ginfo, _sfun_ginfo_top__set_2000_198_globalize_ginfo2085, _sfun_ginfo_top__set_2000_198_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_kaptured__set__env_8_globalize_ginfo, _sexit_ginfo_kaptured__set_1973_234_globalize_ginfo2086, _sexit_ginfo_kaptured__set_1973_234_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_celled__set__env_144_globalize_ginfo, _svar_ginfo_celled__set_1989_101_globalize_ginfo2087, _svar_ginfo_celled__set_1989_101_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_occurrence_set__env_13_globalize_ginfo, _global_ginfo_occurrence_set_1926_26_globalize_ginfo2088, _global_ginfo_occurrence_set_1926_26_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_access_set__env_111_globalize_ginfo, _global_ginfo_access_set_1920_170_globalize_ginfo2089, _global_ginfo_access_set_1920_170_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_mark_set__env_140_globalize_ginfo, _sexit_ginfo_mark_set_1977_141_globalize_ginfo2090, _sexit_ginfo_mark_set_1977_141_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_free_mark_env_76_globalize_ginfo, _sexit_ginfo_free_mark1976_202_globalize_ginfo2091, _sexit_ginfo_free_mark1976_202_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_removable_set__env_69_globalize_ginfo, _global_ginfo_removable_set_1924_222_globalize_ginfo2092, _global_ginfo_removable_set_1924_222_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_kaptured__env_28_globalize_ginfo, _sexit_ginfo_kaptured_1974_188_globalize_ginfo2093, _sexit_ginfo_kaptured_1974_188_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cfrom_env_244_globalize_ginfo, _sfun_ginfo_cfrom2019_6_globalize_ginfo2094, _sfun_ginfo_cfrom2019_6_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_fast_alpha_set__env_57_globalize_ginfo, _global_ginfo_fast_alpha_set_1922_222_globalize_ginfo2095, _global_ginfo_fast_alpha_set_1922_222_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_sfun_ginfo_env_18_globalize_ginfo, _allocate_sfun_ginfo_166_globalize_ginfo2096, _allocate_sfun_ginfo_166_globalize_ginfo, 0L, 0);
DEFINE_EXPORT_PROCEDURE(widening1002_sfun_ginfo_env_149_globalize_ginfo, _widening1002_sfun_ginfo1991_162_globalize_ginfo2097, _widening1002_sfun_ginfo1991_162_globalize_ginfo, 0L, 18);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_free_env_156_globalize_ginfo, _sfun_ginfo_free2049_252_globalize_ginfo2098, _sfun_ginfo_free2049_252_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_dsssl_keywords_set__env_111_globalize_ginfo, _sfun_ginfo_dsssl_keywords_set_2012_227_globalize_ginfo2099, _sfun_ginfo_dsssl_keywords_set_2012_227_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_escape__env_182_globalize_ginfo, _local_ginfo_escape_1964_248_globalize_ginfo2100, _local_ginfo_escape_1964_248_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_fast_alpha_env_229_globalize_ginfo, _global_ginfo_fast_alpha1923_122_globalize_ginfo2101, _global_ginfo_fast_alpha1923_122_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_escape__env_230_globalize_ginfo, _global_ginfo_escape_1941_218_globalize_ginfo2102, _global_ginfo_escape_1941_218_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_free_mark_set__env_38_globalize_ginfo, _sexit_ginfo_free_mark_set_1975_136_globalize_ginfo2103, _sexit_ginfo_free_mark_set_1975_136_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_bmark_set__env_173_globalize_ginfo, _sfun_ginfo_bmark_set_2044_58_globalize_ginfo2104, _sfun_ginfo_bmark_set_2044_58_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_the_global_env_144_globalize_ginfo, _sfun_ginfo_the_global2039_172_globalize_ginfo2105, _sfun_ginfo_the_global2039_172_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_bmark_env_184_globalize_ginfo, _sfun_ginfo_bmark2045_226_globalize_ginfo2106, _sfun_ginfo_bmark2045_226_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_removable_set__env_148_globalize_ginfo, _local_ginfo_removable_set_1956_187_globalize_ginfo2107, _local_ginfo_removable_set_1956_187_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_kaptured_env_231_globalize_ginfo, _sfun_ginfo_kaptured2041_71_globalize_ginfo2108, _sfun_ginfo_kaptured2041_71_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_pragma_env_226_globalize_ginfo, _global_ginfo_pragma1937_98_globalize_ginfo2109, _global_ginfo_pragma1937_98_globalize_ginfo, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2066_globalize_ginfo, struct_object__object_sfun_ginfo_84_globalize_ginfo2110, struct_object__object_sfun_ginfo_84_globalize_ginfo, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2065_globalize_ginfo, object__struct_sfun_ginfo_180_globalize_ginfo2111, object__struct_sfun_ginfo_180_globalize_ginfo, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2064_globalize_ginfo, struct_object__object_svar_ginfo_79_globalize_ginfo2112, struct_object__object_svar_ginfo_79_globalize_ginfo, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2063_globalize_ginfo, object__struct_svar_ginfo_152_globalize_ginfo2113, object__struct_svar_ginfo_152_globalize_ginfo, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2062_globalize_ginfo, struct_object__object_sexit_ginfo_170_globalize_ginfo2114, struct_object__object_sexit_ginfo_170_globalize_ginfo, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2061_globalize_ginfo, object__struct_sexit_ginfo_51_globalize_ginfo2115, object__struct_sexit_ginfo_51_globalize_ginfo, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2059_globalize_ginfo, object__struct_local_ginfo_71_globalize_ginfo2116, object__struct_local_ginfo_71_globalize_ginfo, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2060_globalize_ginfo, struct_object__object_local_ginfo_129_globalize_ginfo2117, struct_object__object_local_ginfo_129_globalize_ginfo, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2058_globalize_ginfo, struct_object__object_global_ginfo_231_globalize_ginfo2118, struct_object__object_global_ginfo_231_globalize_ginfo, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2057_globalize_ginfo, object__struct_global_ginfo_101_globalize_ginfo2119, object__struct_global_ginfo_101_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_class_env_45_globalize_ginfo, _sfun_ginfo_class2011_170_globalize_ginfo2120, _sfun_ginfo_class2011_170_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cfunction_set__env_158_globalize_ginfo, _sfun_ginfo_cfunction_set_2026_162_globalize_ginfo2121, _sfun_ginfo_cfunction_set_2026_162_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_module_env_228_globalize_ginfo, _global_ginfo_module1928_42_globalize_ginfo2122, _global_ginfo_module1928_42_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cto_set__env_241_globalize_ginfo, _sfun_ginfo_cto_set_2022_194_globalize_ginfo2123, _sfun_ginfo_cto_set_2022_194_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_mark_env_97_globalize_ginfo, _svar_ginfo_mark1988_222_globalize_ginfo2124, _svar_ginfo_mark1988_222_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_the_closure_env_160_globalize_ginfo, _sfun_ginfo_the_closure2003_217_globalize_ginfo2125, _sfun_ginfo_the_closure2003_217_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1004_sexit_ginfo_env_27_globalize_ginfo, _widening1004_sexit_ginfo1965_122_globalize_ginfo2126, _widening1004_sexit_ginfo1965_122_globalize_ginfo, 0L, 4);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_g__env_247_globalize_ginfo, _sfun_ginfo_g_2017_38_globalize_ginfo2127, _sfun_ginfo_g_2017_38_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_access_set__env_135_globalize_ginfo, _local_ginfo_access_set_1952_60_globalize_ginfo2128, _local_ginfo_access_set_1952_60_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_loc_set__env_0_globalize_ginfo, _sfun_ginfo_loc_set_2014_18_globalize_ginfo2129, _sfun_ginfo_loc_set_2014_18_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_plugged_in_env_158_globalize_ginfo, _sfun_ginfo_plugged_in2033_157_globalize_ginfo2130, _sfun_ginfo_plugged_in2033_157_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_name_set__env_15_globalize_ginfo, _local_ginfo_name_set_1946_240_globalize_ginfo2131, _local_ginfo_name_set_1946_240_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_side_effect__set__env_89_globalize_ginfo, _sfun_ginfo_side_effect__set_1994_222_globalize_ginfo2132, _sfun_ginfo_side_effect__set_1994_222_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_user__env_187_globalize_ginfo, _global_ginfo_user_1936_195_globalize_ginfo2133, _global_ginfo_user_1936_195_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_stack_allocator_set__env_33_globalize_ginfo, _sfun_ginfo_stack_allocator_set_1998_90_globalize_ginfo2134, _sfun_ginfo_stack_allocator_set_1998_90_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_src_env_144_globalize_ginfo, _global_ginfo_src1939_79_globalize_ginfo2135, _global_ginfo_src1939_79_globalize_ginfo, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(make_global_ginfo_env_159_globalize_ginfo, _make_global_ginfo1912_17_globalize_ginfo2136, _make_global_ginfo1912_17_globalize_ginfo, 0L, 17);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_umark_set__env_167_globalize_ginfo, _sfun_ginfo_umark_set_2046_23_globalize_ginfo2137, _sfun_ginfo_umark_set_2046_23_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_loc_env_174_globalize_ginfo, _sfun_ginfo_loc2015_63_globalize_ginfo2138, _sfun_ginfo_loc2015_63_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_mark_env_136_globalize_ginfo, _sexit_ginfo_mark1978_67_globalize_ginfo2139, _sexit_ginfo_mark1978_67_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_integrator_env_93_globalize_ginfo, _sfun_ginfo_integrator2029_44_globalize_ginfo2140, _sfun_ginfo_integrator2029_44_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_type_env_97_globalize_ginfo, _local_ginfo_type1949_237_globalize_ginfo2141, _local_ginfo_type1949_237_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_g__set__env_140_globalize_ginfo, _sexit_ginfo_g__set_1971_227_globalize_ginfo2142, _sexit_ginfo_g__set_1971_227_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_svar_ginfo_env_192_globalize_ginfo, _make_svar_ginfo1980_37_globalize_ginfo2143, _make_svar_ginfo1980_37_globalize_ginfo, 0L, 5);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_dsssl_keywords_env_169_globalize_ginfo, _sfun_ginfo_dsssl_keywords2013_44_globalize_ginfo2144, _sfun_ginfo_dsssl_keywords2013_44_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_the_global_set__env_10_globalize_ginfo, _sfun_ginfo_the_global_set_2038_246_globalize_ginfo2145, _sfun_ginfo_the_global_set_2038_246_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo__env_139_globalize_ginfo, _sexit_ginfo__121_globalize_ginfo2146, _sexit_ginfo__121_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_src_set__env_10_globalize_ginfo, _global_ginfo_src_set_1938_192_globalize_ginfo2147, _global_ginfo_src_set_1938_192_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_escape__set__env_193_globalize_ginfo, _local_ginfo_escape__set_1963_222_globalize_ginfo2148, _local_ginfo_escape__set_1963_222_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_class_set__env_127_globalize_ginfo, _sfun_ginfo_class_set_2010_243_globalize_ginfo2149, _sfun_ginfo_class_set_2010_243_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_stack_allocator_env_118_globalize_ginfo, _sfun_ginfo_stack_allocator1999_228_globalize_ginfo2150, _sfun_ginfo_stack_allocator1999_228_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cto__set__env_240_globalize_ginfo, _sfun_ginfo_cto__set_2024_109_globalize_ginfo2151, _sfun_ginfo_cto__set_2024_109_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_sexit_ginfo_env_41_globalize_ginfo, _make_sexit_ginfo1966_234_globalize_ginfo2152, _make_sexit_ginfo1966_234_globalize_ginfo, 0L, 6);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_g__env_136_globalize_ginfo, _sexit_ginfo_g_1972_232_globalize_ginfo2153, _sexit_ginfo_g_1972_232_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_top__env_137_globalize_ginfo, _sfun_ginfo_top_2001_123_globalize_ginfo2154, _sfun_ginfo_top_2001_123_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_bound_set__env_71_globalize_ginfo, _sfun_ginfo_bound_set_2050_128_globalize_ginfo2155, _sfun_ginfo_bound_set_2050_128_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_type_env_252_globalize_ginfo, _global_ginfo_type1917_181_globalize_ginfo2156, _global_ginfo_type1917_181_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_removable_env_89_globalize_ginfo, _local_ginfo_removable1957_202_globalize_ginfo2157, _local_ginfo_removable1957_202_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_value_set__env_186_globalize_ginfo, _local_ginfo_value_set_1950_236_globalize_ginfo2158, _local_ginfo_value_set_1950_236_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cfrom_set__env_202_globalize_ginfo, _sfun_ginfo_cfrom_set_2018_248_globalize_ginfo2159, _sfun_ginfo_cfrom_set_2018_248_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_side_effect__env_108_globalize_ginfo, _sfun_ginfo_side_effect_1995_189_globalize_ginfo2160, _sfun_ginfo_side_effect_1995_189_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_svar_ginfo_env_74_globalize_ginfo, _allocate_svar_ginfo_235_globalize_ginfo2161, _allocate_svar_ginfo_235_globalize_ginfo, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_plugged_in_set__env_58_globalize_ginfo, _sfun_ginfo_plugged_in_set_2032_201_globalize_ginfo2162, _sfun_ginfo_plugged_in_set_2032_201_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_user__env_6_globalize_ginfo, _local_ginfo_user_1961_153_globalize_ginfo2163, _local_ginfo_user_1961_153_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_integrator_set__env_87_globalize_ginfo, _sfun_ginfo_integrator_set_2028_220_globalize_ginfo2164, _sfun_ginfo_integrator_set_2028_220_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_args_env_124_globalize_ginfo, _sfun_ginfo_args2007_38_globalize_ginfo2165, _sfun_ginfo_args2007_38_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_celled__env_50_globalize_ginfo, _svar_ginfo_celled_1990_10_globalize_ginfo2166, _svar_ginfo_celled_1990_10_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_library__set__env_105_globalize_ginfo, _global_ginfo_library__set_1933_31_globalize_ginfo2167, _global_ginfo_library__set_1933_31_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(widening1005_local_ginfo_env_16_globalize_ginfo, _widening1005_local_ginfo_143_globalize_ginfo2168, _widening1005_local_ginfo_143_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cfrom__env_161_globalize_ginfo, _sfun_ginfo_cfrom_2021_90_globalize_ginfo2169, _sfun_ginfo_cfrom_2021_90_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_new_body_env_0_globalize_ginfo, _sfun_ginfo_new_body2043_142_globalize_ginfo2170, _sfun_ginfo_new_body2043_142_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cfunction_env_187_globalize_ginfo, _sfun_ginfo_cfunction2027_40_globalize_ginfo2171, _sfun_ginfo_cfunction2027_40_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_local_ginfo_env_8_globalize_ginfo, _make_local_ginfo1944_153_globalize_ginfo2172, _make_local_ginfo1944_153_globalize_ginfo, 0L, 11);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_umark_env_86_globalize_ginfo, _sfun_ginfo_umark2047_231_globalize_ginfo2173, _sfun_ginfo_umark2047_231_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_kaptured_set__env_62_globalize_ginfo, _sfun_ginfo_kaptured_set_2040_243_globalize_ginfo2174, _sfun_ginfo_kaptured_set_2040_243_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo__env_142_globalize_ginfo, _sfun_ginfo__175_globalize_ginfo2175, _sfun_ginfo__175_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_id_env_93_globalize_ginfo, _local_ginfo_id1945_127_globalize_ginfo2176, _local_ginfo_id1945_127_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_mark_set__env_14_globalize_ginfo, _svar_ginfo_mark_set_1987_218_globalize_ginfo2177, _svar_ginfo_mark_set_1987_218_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_the_closure_set__env_218_globalize_ginfo, _sfun_ginfo_the_closure_set_2002_174_globalize_ginfo2178, _sfun_ginfo_the_closure_set_2002_174_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_free_mark_env_118_globalize_ginfo, _svar_ginfo_free_mark1986_33_globalize_ginfo2179, _svar_ginfo_free_mark1986_33_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_type_set__env_14_globalize_ginfo, _local_ginfo_type_set_1948_38_globalize_ginfo2180, _local_ginfo_type_set_1948_38_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_name_set__env_249_globalize_ginfo, _global_ginfo_name_set_1914_244_globalize_ginfo2181, _global_ginfo_name_set_1914_244_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_kaptured__env_252_globalize_ginfo, _svar_ginfo_kaptured_1984_32_globalize_ginfo2182, _svar_ginfo_kaptured_1984_32_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_mark_set__env_59_globalize_ginfo, _sfun_ginfo_mark_set_2034_116_globalize_ginfo2183, _sfun_ginfo_mark_set_2034_116_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cfrom__set__env_121_globalize_ginfo, _sfun_ginfo_cfrom__set_2020_255_globalize_ginfo2184, _sfun_ginfo_cfrom__set_2020_255_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_free_mark_env_40_globalize_ginfo, _sfun_ginfo_free_mark2037_104_globalize_ginfo2185, _sfun_ginfo_free_mark2037_104_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_value_env_133_globalize_ginfo, _global_ginfo_value1919_17_globalize_ginfo2186, _global_ginfo_value1919_17_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1006_global_ginfo_env_115_globalize_ginfo, _widening1006_global_ginfo_21_globalize_ginfo2187, _widening1006_global_ginfo_21_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_body_set__env_71_globalize_ginfo, _sfun_ginfo_body_set_2008_75_globalize_ginfo2188, _sfun_ginfo_body_set_2008_75_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_body_env_44_globalize_ginfo, _sfun_ginfo_body2009_182_globalize_ginfo2189, _sfun_ginfo_body2009_182_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_g__set__env_37_globalize_ginfo, _sfun_ginfo_g__set_2016_77_globalize_ginfo2190, _sfun_ginfo_g__set_2016_77_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_user__set__env_134_globalize_ginfo, _local_ginfo_user__set_1960_217_globalize_ginfo2191, _local_ginfo_user__set_1960_217_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_value_set__env_191_globalize_ginfo, _global_ginfo_value_set_1918_98_globalize_ginfo2192, _global_ginfo_value_set_1918_98_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo__env_176_globalize_ginfo, _global_ginfo__15_globalize_ginfo2193, _global_ginfo__15_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_bound_env_44_globalize_ginfo, _sfun_ginfo_bound2051_125_globalize_ginfo2194, _sfun_ginfo_bound2051_125_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cto_env_195_globalize_ginfo, _sfun_ginfo_cto2023_156_globalize_ginfo2195, _sfun_ginfo_cto2023_156_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_global_closure_set__env_43_globalize_ginfo, _global_ginfo_global_closure_set_1942_202_globalize_ginfo2196, _global_ginfo_global_closure_set_1942_202_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_predicate_of_set__env_110_globalize_ginfo, _sfun_ginfo_predicate_of_set_1996_93_globalize_ginfo2197, _sfun_ginfo_predicate_of_set_1996_93_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_key_env_203_globalize_ginfo, _local_ginfo_key1962_209_globalize_ginfo2198, _local_ginfo_key1962_209_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_predicate_of_env_49_globalize_ginfo, _sfun_ginfo_predicate_of1997_37_globalize_ginfo2199, _sfun_ginfo_predicate_of1997_37_globalize_ginfo, 0L, 1);
DEFINE_STRING(string2067_globalize_ginfo, string2067_globalize_ginfo2200, "GLOBAL/GINFO LOCAL/GINFO SEXIT/GINFO SVAR/GINFO SFUN/GINFO ", 59);
DEFINE_EXPORT_PROCEDURE(svar_ginfo__env_62_globalize_ginfo, _svar_ginfo__189_globalize_ginfo2201, _svar_ginfo__189_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_handler_env_122_globalize_ginfo, _sexit_ginfo_handler1968_234_globalize_ginfo2202, _sexit_ginfo_handler1968_234_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_removable_env_64_globalize_ginfo, _global_ginfo_removable1925_131_globalize_ginfo2203, _global_ginfo_removable1925_131_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_library__env_141_globalize_ginfo, _global_ginfo_library_1934_9_globalize_ginfo2204, _global_ginfo_library_1934_9_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_free_set__env_104_globalize_ginfo, _sfun_ginfo_free_set_2048_178_globalize_ginfo2205, _sfun_ginfo_free_set_2048_178_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_name_env_213_globalize_ginfo, _local_ginfo_name1947_28_globalize_ginfo2206, _local_ginfo_name1947_28_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_sexit_ginfo_env_9_globalize_ginfo, _allocate_sexit_ginfo_207_globalize_ginfo2207, _allocate_sexit_ginfo_207_globalize_ginfo, 0L, 0);
DEFINE_EXPORT_PROCEDURE(local_ginfo_occurrence_env_105_globalize_ginfo, _local_ginfo_occurrence1959_202_globalize_ginfo2208, _local_ginfo_occurrence1959_202_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_import_env_220_globalize_ginfo, _global_ginfo_import1930_103_globalize_ginfo2209, _global_ginfo_import1930_103_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_evaluable__env_161_globalize_ginfo, _global_ginfo_evaluable_1932_56_globalize_ginfo2210, _global_ginfo_evaluable_1932_56_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_evaluable__set__env_121_globalize_ginfo, _global_ginfo_evaluable__set_1931_107_globalize_ginfo2211, _global_ginfo_evaluable__set_1931_107_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_mark_env_7_globalize_ginfo, _sfun_ginfo_mark2035_225_globalize_ginfo2212, _sfun_ginfo_mark2035_225_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_arity_env_109_globalize_ginfo, _sfun_ginfo_arity1993_184_globalize_ginfo2213, _sfun_ginfo_arity1993_184_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_integrated_set__env_175_globalize_ginfo, _sfun_ginfo_integrated_set_2030_140_globalize_ginfo2214, _sfun_ginfo_integrated_set_2030_140_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_property_env_119_globalize_ginfo, _sfun_ginfo_property2005_186_globalize_ginfo2215, _sfun_ginfo_property2005_186_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_value_env_220_globalize_ginfo, _local_ginfo_value1951_216_globalize_ginfo2216, _local_ginfo_value1951_216_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_detached__set__env_11_globalize_ginfo, _sexit_ginfo_detached__set_1969_156_globalize_ginfo2217, _sexit_ginfo_detached__set_1969_156_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_escape__set__env_160_globalize_ginfo, _global_ginfo_escape__set_1940_204_globalize_ginfo2218, _global_ginfo_escape__set_1940_204_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_name_env_112_globalize_ginfo, _global_ginfo_name1915_88_globalize_ginfo2219, _global_ginfo_name1915_88_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_user__set__env_158_globalize_ginfo, _global_ginfo_user__set_1935_222_globalize_ginfo2220, _global_ginfo_user__set_1935_222_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_integrated_env_242_globalize_ginfo, _sfun_ginfo_integrated2031_50_globalize_ginfo2221, _sfun_ginfo_integrated2031_50_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_loc_env_74_globalize_ginfo, _svar_ginfo_loc1982_28_globalize_ginfo2222, _svar_ginfo_loc1982_28_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_id_env_139_globalize_ginfo, _global_ginfo_id1913_181_globalize_ginfo2223, _global_ginfo_id1913_181_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_global_closure_env_166_globalize_ginfo, _global_ginfo_global_closure1943_205_globalize_ginfo2224, _global_ginfo_global_closure1943_205_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_ginfo_import_set__env_186_globalize_ginfo, _global_ginfo_import_set_1929_239_globalize_ginfo2225, _global_ginfo_import_set_1929_239_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_loc_set__env_13_globalize_ginfo, _svar_ginfo_loc_set_1981_1_globalize_ginfo2226, _svar_ginfo_loc_set_1981_1_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_cto__env_24_globalize_ginfo, _sfun_ginfo_cto_2025_13_globalize_ginfo2227, _sfun_ginfo_cto_2025_13_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_ginfo_new_body_set__env_24_globalize_ginfo, _sfun_ginfo_new_body_set_2042_21_globalize_ginfo2228, _sfun_ginfo_new_body_set_2042_21_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_ginfo_occurrence_set__env_136_globalize_ginfo, _local_ginfo_occurrence_set_1958_113_globalize_ginfo2229, _local_ginfo_occurrence_set_1958_113_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_ginfo_detached__env_48_globalize_ginfo, _sexit_ginfo_detached_1970_21_globalize_ginfo2230, _sexit_ginfo_detached_1970_21_globalize_ginfo, 0L, 1);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(local_ginfo_access_env_238_globalize_ginfo, _local_ginfo_access1953_31_globalize_ginfo2231, _local_ginfo_access1953_31_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_ginfo_kaptured__set__env_171_globalize_ginfo, _svar_ginfo_kaptured__set_1983_89_globalize_ginfo2232, _svar_ginfo_kaptured__set_1983_89_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_ginfo_access_env_169_globalize_ginfo, _global_ginfo_access1921_118_globalize_ginfo2233, _global_ginfo_access1921_118_globalize_ginfo, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_ginfo_fast_alpha_set__env_3_globalize_ginfo, _local_ginfo_fast_alpha_set_1954_173_globalize_ginfo2234, _local_ginfo_fast_alpha_set_1954_173_globalize_ginfo, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_global_ginfo_env_156_globalize_ginfo, _allocate_global_ginfo_49_globalize_ginfo2235, _allocate_global_ginfo_49_globalize_ginfo, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_globalize_ginfo(long checksum_2753, char *from_2754)
{
   if (CBOOL(require_initialization_114_globalize_ginfo))
     {
	require_initialization_114_globalize_ginfo = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_ginfo();
	cnst_init_137_globalize_ginfo();
	imported_modules_init_94_globalize_ginfo();
	object_init_111_globalize_ginfo();
	method_init_76_globalize_ginfo();
	toplevel_init_63_globalize_ginfo();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_ginfo()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_GINFO");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_GINFO");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_ginfo()
{
   {
      obj_t cnst_port_138_2745;
      cnst_port_138_2745 = open_input_string(string2067_globalize_ginfo);
      {
	 long i_2746;
	 i_2746 = ((long) 4);
       loop_2747:
	 {
	    bool_t test2068_2748;
	    test2068_2748 = (i_2746 == ((long) -1));
	    if (test2068_2748)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2069_2749;
		    {
		       obj_t list2070_2750;
		       {
			  obj_t arg2071_2751;
			  arg2071_2751 = BNIL;
			  list2070_2750 = MAKE_PAIR(cnst_port_138_2745, arg2071_2751);
		       }
		       arg2069_2749 = read___reader(list2070_2750);
		    }
		    CNST_TABLE_SET(i_2746, arg2069_2749);
		 }
		 {
		    int aux_2752;
		    {
		       long aux_2772;
		       aux_2772 = (i_2746 - ((long) 1));
		       aux_2752 = (int) (aux_2772);
		    }
		    {
		       long i_2775;
		       i_2775 = (long) (aux_2752);
		       i_2746 = i_2775;
		       goto loop_2747;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_ginfo()
{
   return BUNSPEC;
}


/* object-init */ obj_t 
object_init_111_globalize_ginfo()
{
   {
      obj_t arg1608_1006;
      arg1608_1006 = sfun_ast_var;
      sfun_ginfo_98_globalize_ginfo = add_class__117___object(CNST_TABLE_REF(((long) 0)), arg1608_1006, allocate_sfun_ginfo_env_18_globalize_ginfo, ((long) 34613), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1613_1010;
      arg1613_1010 = svar_ast_var;
      svar_ginfo_131_globalize_ginfo = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1613_1010, allocate_svar_ginfo_env_74_globalize_ginfo, ((long) 63184), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1620_1014;
      arg1620_1014 = sexit_ast_var;
      sexit_ginfo_81_globalize_ginfo = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1620_1014, allocate_sexit_ginfo_env_9_globalize_ginfo, ((long) 40351), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1624_1018;
      arg1624_1018 = local_ast_var;
      local_ginfo_108_globalize_ginfo = add_class__117___object(CNST_TABLE_REF(((long) 3)), arg1624_1018, allocate_local_ginfo_env_148_globalize_ginfo, ((long) 60317), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1630_1022;
      arg1630_1022 = global_ast_var;
      global_ginfo_75_globalize_ginfo = add_class__117___object(CNST_TABLE_REF(((long) 4)), arg1630_1022, allocate_global_ginfo_env_156_globalize_ginfo, ((long) 8248), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-global/ginfo */ global_t 
allocate_global_ginfo_174_globalize_ginfo()
{
   {
      global_t new1581_1025;
      new1581_1025 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
      {
	 long arg1634_1026;
	 arg1634_1026 = class_num_218___object(global_ginfo_75_globalize_ginfo);
	 {
	    obj_t obj_1611;
	    obj_1611 = (obj_t) (new1581_1025);
	    (((obj_t) CREF(obj_1611))->header = MAKE_HEADER(arg1634_1026, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2791;
	 aux_2791 = (object_t) (new1581_1025);
	 OBJECT_WIDENING_SET(aux_2791, BFALSE);
      }
      return new1581_1025;
   }
}


/* _allocate-global/ginfo */ obj_t 
_allocate_global_ginfo_49_globalize_ginfo(obj_t env_2259)
{
   {
      global_t aux_2794;
      aux_2794 = allocate_global_ginfo_174_globalize_ginfo();
      return (obj_t) (aux_2794);
   }
}


/* global/ginfo? */ bool_t 
global_ginfo__175_globalize_ginfo(obj_t obj_4)
{
   return is_a__118___object(obj_4, global_ginfo_75_globalize_ginfo);
}


/* _global/ginfo? */ obj_t 
_global_ginfo__15_globalize_ginfo(obj_t env_2260, obj_t obj_2261)
{
   {
      bool_t aux_2798;
      aux_2798 = global_ginfo__175_globalize_ginfo(obj_2261);
      return BBOOL(aux_2798);
   }
}


/* widening1006-global/ginfo */ global_ginfo_75_t 
widening1006_global_ginfo_171_globalize_ginfo(bool_t escape__117_5, obj_t global_closure_229_6)
{
   {
      global_ginfo_75_t new1561_1613;
      new1561_1613 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
      ((((global_ginfo_75_t) CREF(new1561_1613))->escape__117) = ((bool_t) escape__117_5), BUNSPEC);
      ((((global_ginfo_75_t) CREF(new1561_1613))->global_closure_229) = ((obj_t) global_closure_229_6), BUNSPEC);
      return new1561_1613;
   }
}


/* _widening1006-global/ginfo */ obj_t 
_widening1006_global_ginfo_21_globalize_ginfo(obj_t env_2262, obj_t escape__117_2263, obj_t global_closure_229_2264)
{
   {
      global_ginfo_75_t aux_2804;
      aux_2804 = widening1006_global_ginfo_171_globalize_ginfo(CBOOL(escape__117_2263), global_closure_229_2264);
      return (obj_t) (aux_2804);
   }
}


/* make-global/ginfo */ global_ginfo_75_t 
make_global_ginfo_116_globalize_ginfo(obj_t id_7, obj_t name_8, type_t type_9, value_t value_10, obj_t access_11, obj_t fast_alpha_7_12, obj_t removable_13, long occurrence_14, obj_t module_15, obj_t import_16, bool_t evaluable__248_17, bool_t library__255_18, bool_t user__32_19, obj_t pragma_20, obj_t src_21, bool_t escape__117_22, obj_t global_closure_229_23)
{
   {
      global_t aux1565_1616;
      {
	 global_t res1897_1654;
	 {
	    global_t new1054_1635;
	    new1054_1635 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
	    {
	       long arg1728_1636;
	       arg1728_1636 = class_num_218___object(global_ast_var);
	       {
		  obj_t obj_1652;
		  obj_1652 = (obj_t) (new1054_1635);
		  (((obj_t) CREF(obj_1652))->header = MAKE_HEADER(arg1728_1636, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2812;
	       aux_2812 = (object_t) (new1054_1635);
	       OBJECT_WIDENING_SET(aux_2812, BFALSE);
	    }
	    ((((global_t) CREF(new1054_1635))->id) = ((obj_t) id_7), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->name) = ((obj_t) name_8), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->type) = ((type_t) type_9), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->value) = ((value_t) value_10), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->access) = ((obj_t) access_11), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->fast_alpha_7) = ((obj_t) fast_alpha_7_12), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->removable) = ((obj_t) removable_13), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->occurrence) = ((long) occurrence_14), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->module) = ((obj_t) module_15), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->import) = ((obj_t) import_16), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->evaluable__248) = ((bool_t) evaluable__248_17), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->library__255) = ((bool_t) library__255_18), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->user__32) = ((bool_t) user__32_19), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->pragma) = ((obj_t) pragma_20), BUNSPEC);
	    ((((global_t) CREF(new1054_1635))->src) = ((obj_t) src_21), BUNSPEC);
	    res1897_1654 = new1054_1635;
	 }
	 aux1565_1616 = res1897_1654;
      }
      {
	 global_ginfo_75_t new1566_1617;
	 new1566_1617 = ((global_ginfo_75_t) (aux1565_1616));
	 {
	    long arg1636_1618;
	    arg1636_1618 = class_num_218___object(global_ginfo_75_globalize_ginfo);
	    {
	       obj_t obj_1655;
	       obj_1655 = (obj_t) (new1566_1617);
	       (((obj_t) CREF(obj_1655))->header = MAKE_HEADER(arg1636_1618, 0), BUNSPEC);
	    }
	 }
	 {
	    global_ginfo_75_t arg1638_1619;
	    {
	       global_ginfo_75_t res1898_1662;
	       {
		  global_ginfo_75_t new1561_1659;
		  new1561_1659 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
		  ((((global_ginfo_75_t) CREF(new1561_1659))->escape__117) = ((bool_t) escape__117_22), BUNSPEC);
		  ((((global_ginfo_75_t) CREF(new1561_1659))->global_closure_229) = ((obj_t) global_closure_229_23), BUNSPEC);
		  res1898_1662 = new1561_1659;
	       }
	       arg1638_1619 = res1898_1662;
	    }
	    {
	       obj_t aux_2839;
	       object_t aux_2837;
	       aux_2839 = (obj_t) (arg1638_1619);
	       aux_2837 = (object_t) (new1566_1617);
	       OBJECT_WIDENING_SET(aux_2837, aux_2839);
	    }
	 }
	 return new1566_1617;
      }
   }
}


/* _make-global/ginfo1912 */ obj_t 
_make_global_ginfo1912_17_globalize_ginfo(obj_t env_2265, obj_t id_2266, obj_t name_2267, obj_t type_2268, obj_t value_2269, obj_t access_2270, obj_t fast_alpha_7_2271, obj_t removable_2272, obj_t occurrence_2273, obj_t module_2274, obj_t import_2275, obj_t evaluable__248_2276, obj_t library__255_2277, obj_t user__32_2278, obj_t pragma_2279, obj_t src_2280, obj_t escape__117_2281, obj_t global_closure_229_2282)
{
   {
      global_ginfo_75_t aux_2842;
      aux_2842 = make_global_ginfo_116_globalize_ginfo(id_2266, name_2267, (type_t) (type_2268), (value_t) (value_2269), access_2270, fast_alpha_7_2271, removable_2272, (long) CINT(occurrence_2273), module_2274, import_2275, CBOOL(evaluable__248_2276), CBOOL(library__255_2277), CBOOL(user__32_2278), pragma_2279, src_2280, CBOOL(escape__117_2281), global_closure_229_2282);
      return (obj_t) (aux_2842);
   }
}


/* global/ginfo-id */ obj_t 
global_ginfo_id_159_globalize_ginfo(global_t obj_24)
{
   return (((global_t) CREF(obj_24))->id);
}


/* _global/ginfo-id1913 */ obj_t 
_global_ginfo_id1913_181_globalize_ginfo(obj_t env_2283, obj_t obj_2284)
{
   return global_ginfo_id_159_globalize_ginfo((global_t) (obj_2284));
}


/* global/ginfo-name-set! */ obj_t 
global_ginfo_name_set__78_globalize_ginfo(global_t obj_25, obj_t val1567_26)
{
   return ((((global_t) CREF(obj_25))->name) = ((obj_t) val1567_26), BUNSPEC);
}


/* _global/ginfo-name-set!1914 */ obj_t 
_global_ginfo_name_set_1914_244_globalize_ginfo(obj_t env_2285, obj_t obj_2286, obj_t val1567_2287)
{
   return global_ginfo_name_set__78_globalize_ginfo((global_t) (obj_2286), val1567_2287);
}


/* global/ginfo-name */ obj_t 
global_ginfo_name_179_globalize_ginfo(global_t obj_27)
{
   return (((global_t) CREF(obj_27))->name);
}


/* _global/ginfo-name1915 */ obj_t 
_global_ginfo_name1915_88_globalize_ginfo(obj_t env_2288, obj_t obj_2289)
{
   return global_ginfo_name_179_globalize_ginfo((global_t) (obj_2289));
}


/* global/ginfo-type-set! */ obj_t 
global_ginfo_type_set__85_globalize_ginfo(global_t obj_28, type_t val1568_29)
{
   return ((((global_t) CREF(obj_28))->type) = ((type_t) val1568_29), BUNSPEC);
}


/* _global/ginfo-type-set!1916 */ obj_t 
_global_ginfo_type_set_1916_135_globalize_ginfo(obj_t env_2290, obj_t obj_2291, obj_t val1568_2292)
{
   return global_ginfo_type_set__85_globalize_ginfo((global_t) (obj_2291), (type_t) (val1568_2292));
}


/* global/ginfo-type */ type_t 
global_ginfo_type_26_globalize_ginfo(global_t obj_30)
{
   return (((global_t) CREF(obj_30))->type);
}


/* _global/ginfo-type1917 */ obj_t 
_global_ginfo_type1917_181_globalize_ginfo(obj_t env_2293, obj_t obj_2294)
{
   {
      type_t aux_2866;
      aux_2866 = global_ginfo_type_26_globalize_ginfo((global_t) (obj_2294));
      return (obj_t) (aux_2866);
   }
}


/* global/ginfo-value-set! */ obj_t 
global_ginfo_value_set__149_globalize_ginfo(global_t obj_31, value_t val1569_32)
{
   return ((((global_t) CREF(obj_31))->value) = ((value_t) val1569_32), BUNSPEC);
}


/* _global/ginfo-value-set!1918 */ obj_t 
_global_ginfo_value_set_1918_98_globalize_ginfo(obj_t env_2295, obj_t obj_2296, obj_t val1569_2297)
{
   return global_ginfo_value_set__149_globalize_ginfo((global_t) (obj_2296), (value_t) (val1569_2297));
}


/* global/ginfo-value */ value_t 
global_ginfo_value_89_globalize_ginfo(global_t obj_33)
{
   return (((global_t) CREF(obj_33))->value);
}


/* _global/ginfo-value1919 */ obj_t 
_global_ginfo_value1919_17_globalize_ginfo(obj_t env_2298, obj_t obj_2299)
{
   {
      value_t aux_2875;
      aux_2875 = global_ginfo_value_89_globalize_ginfo((global_t) (obj_2299));
      return (obj_t) (aux_2875);
   }
}


/* global/ginfo-access-set! */ obj_t 
global_ginfo_access_set__63_globalize_ginfo(global_t obj_34, obj_t val1570_35)
{
   return ((((global_t) CREF(obj_34))->access) = ((obj_t) val1570_35), BUNSPEC);
}


/* _global/ginfo-access-set!1920 */ obj_t 
_global_ginfo_access_set_1920_170_globalize_ginfo(obj_t env_2300, obj_t obj_2301, obj_t val1570_2302)
{
   return global_ginfo_access_set__63_globalize_ginfo((global_t) (obj_2301), val1570_2302);
}


/* global/ginfo-access */ obj_t 
global_ginfo_access_77_globalize_ginfo(global_t obj_36)
{
   return (((global_t) CREF(obj_36))->access);
}


/* _global/ginfo-access1921 */ obj_t 
_global_ginfo_access1921_118_globalize_ginfo(obj_t env_2303, obj_t obj_2304)
{
   return global_ginfo_access_77_globalize_ginfo((global_t) (obj_2304));
}


/* global/ginfo-fast-alpha-set! */ obj_t 
global_ginfo_fast_alpha_set__195_globalize_ginfo(global_t obj_37, obj_t val1571_38)
{
   return ((((global_t) CREF(obj_37))->fast_alpha_7) = ((obj_t) val1571_38), BUNSPEC);
}


/* _global/ginfo-fast-alpha-set!1922 */ obj_t 
_global_ginfo_fast_alpha_set_1922_222_globalize_ginfo(obj_t env_2305, obj_t obj_2306, obj_t val1571_2307)
{
   return global_ginfo_fast_alpha_set__195_globalize_ginfo((global_t) (obj_2306), val1571_2307);
}


/* global/ginfo-fast-alpha */ obj_t 
global_ginfo_fast_alpha_123_globalize_ginfo(global_t obj_39)
{
   return (((global_t) CREF(obj_39))->fast_alpha_7);
}


/* _global/ginfo-fast-alpha1923 */ obj_t 
_global_ginfo_fast_alpha1923_122_globalize_ginfo(obj_t env_2308, obj_t obj_2309)
{
   return global_ginfo_fast_alpha_123_globalize_ginfo((global_t) (obj_2309));
}


/* global/ginfo-removable-set! */ obj_t 
global_ginfo_removable_set__202_globalize_ginfo(global_t obj_40, obj_t val1572_41)
{
   return ((((global_t) CREF(obj_40))->removable) = ((obj_t) val1572_41), BUNSPEC);
}


/* _global/ginfo-removable-set!1924 */ obj_t 
_global_ginfo_removable_set_1924_222_globalize_ginfo(obj_t env_2310, obj_t obj_2311, obj_t val1572_2312)
{
   return global_ginfo_removable_set__202_globalize_ginfo((global_t) (obj_2311), val1572_2312);
}


/* global/ginfo-removable */ obj_t 
global_ginfo_removable_27_globalize_ginfo(global_t obj_42)
{
   return (((global_t) CREF(obj_42))->removable);
}


/* _global/ginfo-removable1925 */ obj_t 
_global_ginfo_removable1925_131_globalize_ginfo(obj_t env_2313, obj_t obj_2314)
{
   return global_ginfo_removable_27_globalize_ginfo((global_t) (obj_2314));
}


/* global/ginfo-occurrence-set! */ obj_t 
global_ginfo_occurrence_set__72_globalize_ginfo(global_t obj_43, long val1573_44)
{
   return ((((global_t) CREF(obj_43))->occurrence) = ((long) val1573_44), BUNSPEC);
}


/* _global/ginfo-occurrence-set!1926 */ obj_t 
_global_ginfo_occurrence_set_1926_26_globalize_ginfo(obj_t env_2315, obj_t obj_2316, obj_t val1573_2317)
{
   return global_ginfo_occurrence_set__72_globalize_ginfo((global_t) (obj_2316), (long) CINT(val1573_2317));
}


/* global/ginfo-occurrence */ long 
global_ginfo_occurrence_12_globalize_ginfo(global_t obj_45)
{
   return (((global_t) CREF(obj_45))->occurrence);
}


/* _global/ginfo-occurrence1927 */ obj_t 
_global_ginfo_occurrence1927_163_globalize_ginfo(obj_t env_2318, obj_t obj_2319)
{
   {
      long aux_2902;
      aux_2902 = global_ginfo_occurrence_12_globalize_ginfo((global_t) (obj_2319));
      return BINT(aux_2902);
   }
}


/* global/ginfo-module */ obj_t 
global_ginfo_module_155_globalize_ginfo(global_t obj_46)
{
   return (((global_t) CREF(obj_46))->module);
}


/* _global/ginfo-module1928 */ obj_t 
_global_ginfo_module1928_42_globalize_ginfo(obj_t env_2320, obj_t obj_2321)
{
   return global_ginfo_module_155_globalize_ginfo((global_t) (obj_2321));
}


/* global/ginfo-import-set! */ obj_t 
global_ginfo_import_set__11_globalize_ginfo(global_t obj_47, obj_t val1574_48)
{
   return ((((global_t) CREF(obj_47))->import) = ((obj_t) val1574_48), BUNSPEC);
}


/* _global/ginfo-import-set!1929 */ obj_t 
_global_ginfo_import_set_1929_239_globalize_ginfo(obj_t env_2322, obj_t obj_2323, obj_t val1574_2324)
{
   return global_ginfo_import_set__11_globalize_ginfo((global_t) (obj_2323), val1574_2324);
}


/* global/ginfo-import */ obj_t 
global_ginfo_import_118_globalize_ginfo(global_t obj_49)
{
   return (((global_t) CREF(obj_49))->import);
}


/* _global/ginfo-import1930 */ obj_t 
_global_ginfo_import1930_103_globalize_ginfo(obj_t env_2325, obj_t obj_2326)
{
   return global_ginfo_import_118_globalize_ginfo((global_t) (obj_2326));
}


/* global/ginfo-evaluable?-set! */ obj_t 
global_ginfo_evaluable__set__37_globalize_ginfo(global_t obj_50, bool_t val1575_51)
{
   return ((((global_t) CREF(obj_50))->evaluable__248) = ((bool_t) val1575_51), BUNSPEC);
}


/* _global/ginfo-evaluable?-set!1931 */ obj_t 
_global_ginfo_evaluable__set_1931_107_globalize_ginfo(obj_t env_2327, obj_t obj_2328, obj_t val1575_2329)
{
   return global_ginfo_evaluable__set__37_globalize_ginfo((global_t) (obj_2328), CBOOL(val1575_2329));
}


/* global/ginfo-evaluable? */ bool_t 
global_ginfo_evaluable__184_globalize_ginfo(global_t obj_52)
{
   return (((global_t) CREF(obj_52))->evaluable__248);
}


/* _global/ginfo-evaluable?1932 */ obj_t 
_global_ginfo_evaluable_1932_56_globalize_ginfo(obj_t env_2330, obj_t obj_2331)
{
   {
      bool_t aux_2920;
      aux_2920 = global_ginfo_evaluable__184_globalize_ginfo((global_t) (obj_2331));
      return BBOOL(aux_2920);
   }
}


/* global/ginfo-library?-set! */ obj_t 
global_ginfo_library__set__196_globalize_ginfo(global_t obj_53, bool_t val1576_54)
{
   return ((((global_t) CREF(obj_53))->library__255) = ((bool_t) val1576_54), BUNSPEC);
}


/* _global/ginfo-library?-set!1933 */ obj_t 
_global_ginfo_library__set_1933_31_globalize_ginfo(obj_t env_2332, obj_t obj_2333, obj_t val1576_2334)
{
   return global_ginfo_library__set__196_globalize_ginfo((global_t) (obj_2333), CBOOL(val1576_2334));
}


/* global/ginfo-library? */ bool_t 
global_ginfo_library__79_globalize_ginfo(global_t obj_55)
{
   return (((global_t) CREF(obj_55))->library__255);
}


/* _global/ginfo-library?1934 */ obj_t 
_global_ginfo_library_1934_9_globalize_ginfo(obj_t env_2335, obj_t obj_2336)
{
   {
      bool_t aux_2929;
      aux_2929 = global_ginfo_library__79_globalize_ginfo((global_t) (obj_2336));
      return BBOOL(aux_2929);
   }
}


/* global/ginfo-user?-set! */ obj_t 
global_ginfo_user__set__96_globalize_ginfo(global_t obj_56, bool_t val1577_57)
{
   return ((((global_t) CREF(obj_56))->user__32) = ((bool_t) val1577_57), BUNSPEC);
}


/* _global/ginfo-user?-set!1935 */ obj_t 
_global_ginfo_user__set_1935_222_globalize_ginfo(obj_t env_2337, obj_t obj_2338, obj_t val1577_2339)
{
   return global_ginfo_user__set__96_globalize_ginfo((global_t) (obj_2338), CBOOL(val1577_2339));
}


/* global/ginfo-user? */ bool_t 
global_ginfo_user__167_globalize_ginfo(global_t obj_58)
{
   return (((global_t) CREF(obj_58))->user__32);
}


/* _global/ginfo-user?1936 */ obj_t 
_global_ginfo_user_1936_195_globalize_ginfo(obj_t env_2340, obj_t obj_2341)
{
   {
      bool_t aux_2938;
      aux_2938 = global_ginfo_user__167_globalize_ginfo((global_t) (obj_2341));
      return BBOOL(aux_2938);
   }
}


/* global/ginfo-pragma */ obj_t 
global_ginfo_pragma_81_globalize_ginfo(global_t obj_59)
{
   return (((global_t) CREF(obj_59))->pragma);
}


/* _global/ginfo-pragma1937 */ obj_t 
_global_ginfo_pragma1937_98_globalize_ginfo(obj_t env_2342, obj_t obj_2343)
{
   return global_ginfo_pragma_81_globalize_ginfo((global_t) (obj_2343));
}


/* global/ginfo-src-set! */ obj_t 
global_ginfo_src_set__129_globalize_ginfo(global_t obj_60, obj_t val1578_61)
{
   return ((((global_t) CREF(obj_60))->src) = ((obj_t) val1578_61), BUNSPEC);
}


/* _global/ginfo-src-set!1938 */ obj_t 
_global_ginfo_src_set_1938_192_globalize_ginfo(obj_t env_2344, obj_t obj_2345, obj_t val1578_2346)
{
   return global_ginfo_src_set__129_globalize_ginfo((global_t) (obj_2345), val1578_2346);
}


/* global/ginfo-src */ obj_t 
global_ginfo_src_234_globalize_ginfo(global_t obj_62)
{
   return (((global_t) CREF(obj_62))->src);
}


/* _global/ginfo-src1939 */ obj_t 
_global_ginfo_src1939_79_globalize_ginfo(obj_t env_2347, obj_t obj_2348)
{
   return global_ginfo_src_234_globalize_ginfo((global_t) (obj_2348));
}


/* global/ginfo-escape?-set! */ obj_t 
global_ginfo_escape__set__142_globalize_ginfo(global_ginfo_75_t obj_63, bool_t val1579_64)
{
   {
      obj_t aux_2951;
      {
	 object_t aux_2952;
	 aux_2952 = (object_t) (obj_63);
	 aux_2951 = OBJECT_WIDENING(aux_2952);
      }
      return ((((global_ginfo_75_t) CREF(aux_2951))->escape__117) = ((bool_t) val1579_64), BUNSPEC);
   }
}


/* _global/ginfo-escape?-set!1940 */ obj_t 
_global_ginfo_escape__set_1940_204_globalize_ginfo(obj_t env_2349, obj_t obj_2350, obj_t val1579_2351)
{
   return global_ginfo_escape__set__142_globalize_ginfo((global_ginfo_75_t) (obj_2350), CBOOL(val1579_2351));
}


/* global/ginfo-escape? */ bool_t 
global_ginfo_escape__39_globalize_ginfo(global_ginfo_75_t obj_65)
{
   {
      obj_t aux_2959;
      {
	 object_t aux_2960;
	 aux_2960 = (object_t) (obj_65);
	 aux_2959 = OBJECT_WIDENING(aux_2960);
      }
      return (((global_ginfo_75_t) CREF(aux_2959))->escape__117);
   }
}


/* _global/ginfo-escape?1941 */ obj_t 
_global_ginfo_escape_1941_218_globalize_ginfo(obj_t env_2352, obj_t obj_2353)
{
   {
      bool_t aux_2964;
      aux_2964 = global_ginfo_escape__39_globalize_ginfo((global_ginfo_75_t) (obj_2353));
      return BBOOL(aux_2964);
   }
}


/* global/ginfo-global-closure-set! */ obj_t 
global_ginfo_global_closure_set__44_globalize_ginfo(global_ginfo_75_t obj_66, obj_t val1580_67)
{
   {
      obj_t aux_2968;
      {
	 object_t aux_2969;
	 aux_2969 = (object_t) (obj_66);
	 aux_2968 = OBJECT_WIDENING(aux_2969);
      }
      return ((((global_ginfo_75_t) CREF(aux_2968))->global_closure_229) = ((obj_t) val1580_67), BUNSPEC);
   }
}


/* _global/ginfo-global-closure-set!1942 */ obj_t 
_global_ginfo_global_closure_set_1942_202_globalize_ginfo(obj_t env_2354, obj_t obj_2355, obj_t val1580_2356)
{
   return global_ginfo_global_closure_set__44_globalize_ginfo((global_ginfo_75_t) (obj_2355), val1580_2356);
}


/* global/ginfo-global-closure */ obj_t 
global_ginfo_global_closure_105_globalize_ginfo(global_ginfo_75_t obj_68)
{
   {
      obj_t aux_2975;
      {
	 object_t aux_2976;
	 aux_2976 = (object_t) (obj_68);
	 aux_2975 = OBJECT_WIDENING(aux_2976);
      }
      return (((global_ginfo_75_t) CREF(aux_2975))->global_closure_229);
   }
}


/* _global/ginfo-global-closure1943 */ obj_t 
_global_ginfo_global_closure1943_205_globalize_ginfo(obj_t env_2357, obj_t obj_2358)
{
   return global_ginfo_global_closure_105_globalize_ginfo((global_ginfo_75_t) (obj_2358));
}


/* allocate-local/ginfo */ local_t 
allocate_local_ginfo_201_globalize_ginfo()
{
   {
      local_t new1554_1034;
      new1554_1034 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1639_1035;
	 arg1639_1035 = class_num_218___object(local_ginfo_108_globalize_ginfo);
	 {
	    obj_t obj_1663;
	    obj_1663 = (obj_t) (new1554_1034);
	    (((obj_t) CREF(obj_1663))->header = MAKE_HEADER(arg1639_1035, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2986;
	 aux_2986 = (object_t) (new1554_1034);
	 OBJECT_WIDENING_SET(aux_2986, BFALSE);
      }
      return new1554_1034;
   }
}


/* _allocate-local/ginfo */ obj_t 
_allocate_local_ginfo_111_globalize_ginfo(obj_t env_2258)
{
   {
      local_t aux_2989;
      aux_2989 = allocate_local_ginfo_201_globalize_ginfo();
      return (obj_t) (aux_2989);
   }
}


/* local/ginfo? */ bool_t 
local_ginfo__237_globalize_ginfo(obj_t obj_72)
{
   return is_a__118___object(obj_72, local_ginfo_108_globalize_ginfo);
}


/* _local/ginfo? */ obj_t 
_local_ginfo__39_globalize_ginfo(obj_t env_2359, obj_t obj_2360)
{
   {
      bool_t aux_2993;
      aux_2993 = local_ginfo__237_globalize_ginfo(obj_2360);
      return BBOOL(aux_2993);
   }
}


/* widening1005-local/ginfo */ local_ginfo_108_t 
widening1005_local_ginfo_114_globalize_ginfo(bool_t escape__117_73)
{
   {
      local_ginfo_108_t new1540_1665;
      new1540_1665 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
      ((((local_ginfo_108_t) CREF(new1540_1665))->escape__117) = ((bool_t) escape__117_73), BUNSPEC);
      return new1540_1665;
   }
}


/* _widening1005-local/ginfo */ obj_t 
_widening1005_local_ginfo_143_globalize_ginfo(obj_t env_2361, obj_t escape__117_2362)
{
   {
      local_ginfo_108_t aux_2998;
      aux_2998 = widening1005_local_ginfo_114_globalize_ginfo(CBOOL(escape__117_2362));
      return (obj_t) (aux_2998);
   }
}


/* make-local/ginfo */ local_ginfo_108_t 
make_local_ginfo_207_globalize_ginfo(obj_t id_74, obj_t name_75, type_t type_76, value_t value_77, obj_t access_78, obj_t fast_alpha_7_79, obj_t removable_80, long occurrence_81, bool_t user__32_82, long key_83, bool_t escape__117_84)
{
   {
      local_t aux1543_1667;
      {
	 local_t res1899_1695;
	 {
	    local_t new1084_1681;
	    new1084_1681 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
	    {
	       long arg1726_1682;
	       arg1726_1682 = class_num_218___object(local_ast_var);
	       {
		  obj_t obj_1693;
		  obj_1693 = (obj_t) (new1084_1681);
		  (((obj_t) CREF(obj_1693))->header = MAKE_HEADER(arg1726_1682, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3006;
	       aux_3006 = (object_t) (new1084_1681);
	       OBJECT_WIDENING_SET(aux_3006, BFALSE);
	    }
	    ((((local_t) CREF(new1084_1681))->id) = ((obj_t) id_74), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->name) = ((obj_t) name_75), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->type) = ((type_t) type_76), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->value) = ((value_t) value_77), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->access) = ((obj_t) access_78), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->fast_alpha_7) = ((obj_t) fast_alpha_7_79), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->removable) = ((obj_t) removable_80), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->occurrence) = ((long) occurrence_81), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->user__32) = ((bool_t) user__32_82), BUNSPEC);
	    ((((local_t) CREF(new1084_1681))->key) = ((long) key_83), BUNSPEC);
	    res1899_1695 = new1084_1681;
	 }
	 aux1543_1667 = res1899_1695;
      }
      {
	 local_ginfo_108_t new1544_1668;
	 new1544_1668 = ((local_ginfo_108_t) (aux1543_1667));
	 {
	    long arg1640_1669;
	    arg1640_1669 = class_num_218___object(local_ginfo_108_globalize_ginfo);
	    {
	       obj_t obj_1696;
	       obj_1696 = (obj_t) (new1544_1668);
	       (((obj_t) CREF(obj_1696))->header = MAKE_HEADER(arg1640_1669, 0), BUNSPEC);
	    }
	 }
	 {
	    local_ginfo_108_t arg1641_1670;
	    {
	       local_ginfo_108_t res1900_1701;
	       {
		  local_ginfo_108_t new1540_1699;
		  new1540_1699 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
		  ((((local_ginfo_108_t) CREF(new1540_1699))->escape__117) = ((bool_t) escape__117_84), BUNSPEC);
		  res1900_1701 = new1540_1699;
	       }
	       arg1641_1670 = res1900_1701;
	    }
	    {
	       obj_t aux_3027;
	       object_t aux_3025;
	       aux_3027 = (obj_t) (arg1641_1670);
	       aux_3025 = (object_t) (new1544_1668);
	       OBJECT_WIDENING_SET(aux_3025, aux_3027);
	    }
	 }
	 return new1544_1668;
      }
   }
}


/* _make-local/ginfo1944 */ obj_t 
_make_local_ginfo1944_153_globalize_ginfo(obj_t env_2363, obj_t id_2364, obj_t name_2365, obj_t type_2366, obj_t value_2367, obj_t access_2368, obj_t fast_alpha_7_2369, obj_t removable_2370, obj_t occurrence_2371, obj_t user__32_2372, obj_t key_2373, obj_t escape__117_2374)
{
   {
      local_ginfo_108_t aux_3030;
      aux_3030 = make_local_ginfo_207_globalize_ginfo(id_2364, name_2365, (type_t) (type_2366), (value_t) (value_2367), access_2368, fast_alpha_7_2369, removable_2370, (long) CINT(occurrence_2371), CBOOL(user__32_2372), (long) CINT(key_2373), CBOOL(escape__117_2374));
      return (obj_t) (aux_3030);
   }
}


/* local/ginfo-id */ obj_t 
local_ginfo_id_0_globalize_ginfo(local_t obj_85)
{
   return (((local_t) CREF(obj_85))->id);
}


/* _local/ginfo-id1945 */ obj_t 
_local_ginfo_id1945_127_globalize_ginfo(obj_t env_2375, obj_t obj_2376)
{
   return local_ginfo_id_0_globalize_ginfo((local_t) (obj_2376));
}


/* local/ginfo-name-set! */ obj_t 
local_ginfo_name_set__6_globalize_ginfo(local_t obj_86, obj_t val1545_87)
{
   return ((((local_t) CREF(obj_86))->name) = ((obj_t) val1545_87), BUNSPEC);
}


/* _local/ginfo-name-set!1946 */ obj_t 
_local_ginfo_name_set_1946_240_globalize_ginfo(obj_t env_2377, obj_t obj_2378, obj_t val1545_2379)
{
   return local_ginfo_name_set__6_globalize_ginfo((local_t) (obj_2378), val1545_2379);
}


/* local/ginfo-name */ obj_t 
local_ginfo_name_216_globalize_ginfo(local_t obj_88)
{
   return (((local_t) CREF(obj_88))->name);
}


/* _local/ginfo-name1947 */ obj_t 
_local_ginfo_name1947_28_globalize_ginfo(obj_t env_2380, obj_t obj_2381)
{
   return local_ginfo_name_216_globalize_ginfo((local_t) (obj_2381));
}


/* local/ginfo-type-set! */ obj_t 
local_ginfo_type_set__188_globalize_ginfo(local_t obj_89, type_t val1546_90)
{
   return ((((local_t) CREF(obj_89))->type) = ((type_t) val1546_90), BUNSPEC);
}


/* _local/ginfo-type-set!1948 */ obj_t 
_local_ginfo_type_set_1948_38_globalize_ginfo(obj_t env_2382, obj_t obj_2383, obj_t val1546_2384)
{
   return local_ginfo_type_set__188_globalize_ginfo((local_t) (obj_2383), (type_t) (val1546_2384));
}


/* local/ginfo-type */ type_t 
local_ginfo_type_222_globalize_ginfo(local_t obj_91)
{
   return (((local_t) CREF(obj_91))->type);
}


/* _local/ginfo-type1949 */ obj_t 
_local_ginfo_type1949_237_globalize_ginfo(obj_t env_2385, obj_t obj_2386)
{
   {
      type_t aux_3053;
      aux_3053 = local_ginfo_type_222_globalize_ginfo((local_t) (obj_2386));
      return (obj_t) (aux_3053);
   }
}


/* local/ginfo-value-set! */ obj_t 
local_ginfo_value_set__11_globalize_ginfo(local_t obj_92, value_t val1547_93)
{
   return ((((local_t) CREF(obj_92))->value) = ((value_t) val1547_93), BUNSPEC);
}


/* _local/ginfo-value-set!1950 */ obj_t 
_local_ginfo_value_set_1950_236_globalize_ginfo(obj_t env_2387, obj_t obj_2388, obj_t val1547_2389)
{
   return local_ginfo_value_set__11_globalize_ginfo((local_t) (obj_2388), (value_t) (val1547_2389));
}


/* local/ginfo-value */ value_t 
local_ginfo_value_118_globalize_ginfo(local_t obj_94)
{
   return (((local_t) CREF(obj_94))->value);
}


/* _local/ginfo-value1951 */ obj_t 
_local_ginfo_value1951_216_globalize_ginfo(obj_t env_2390, obj_t obj_2391)
{
   {
      value_t aux_3062;
      aux_3062 = local_ginfo_value_118_globalize_ginfo((local_t) (obj_2391));
      return (obj_t) (aux_3062);
   }
}


/* local/ginfo-access-set! */ obj_t 
local_ginfo_access_set__117_globalize_ginfo(local_t obj_95, obj_t val1548_96)
{
   return ((((local_t) CREF(obj_95))->access) = ((obj_t) val1548_96), BUNSPEC);
}


/* _local/ginfo-access-set!1952 */ obj_t 
_local_ginfo_access_set_1952_60_globalize_ginfo(obj_t env_2392, obj_t obj_2393, obj_t val1548_2394)
{
   return local_ginfo_access_set__117_globalize_ginfo((local_t) (obj_2393), val1548_2394);
}


/* local/ginfo-access */ obj_t 
local_ginfo_access_122_globalize_ginfo(local_t obj_97)
{
   return (((local_t) CREF(obj_97))->access);
}


/* _local/ginfo-access1953 */ obj_t 
_local_ginfo_access1953_31_globalize_ginfo(obj_t env_2395, obj_t obj_2396)
{
   return local_ginfo_access_122_globalize_ginfo((local_t) (obj_2396));
}


/* local/ginfo-fast-alpha-set! */ obj_t 
local_ginfo_fast_alpha_set__62_globalize_ginfo(local_t obj_98, obj_t val1549_99)
{
   return ((((local_t) CREF(obj_98))->fast_alpha_7) = ((obj_t) val1549_99), BUNSPEC);
}


/* _local/ginfo-fast-alpha-set!1954 */ obj_t 
_local_ginfo_fast_alpha_set_1954_173_globalize_ginfo(obj_t env_2397, obj_t obj_2398, obj_t val1549_2399)
{
   return local_ginfo_fast_alpha_set__62_globalize_ginfo((local_t) (obj_2398), val1549_2399);
}


/* local/ginfo-fast-alpha */ obj_t 
local_ginfo_fast_alpha_16_globalize_ginfo(local_t obj_100)
{
   return (((local_t) CREF(obj_100))->fast_alpha_7);
}


/* _local/ginfo-fast-alpha1955 */ obj_t 
_local_ginfo_fast_alpha1955_194_globalize_ginfo(obj_t env_2400, obj_t obj_2401)
{
   return local_ginfo_fast_alpha_16_globalize_ginfo((local_t) (obj_2401));
}


/* local/ginfo-removable-set! */ obj_t 
local_ginfo_removable_set__201_globalize_ginfo(local_t obj_101, obj_t val1550_102)
{
   return ((((local_t) CREF(obj_101))->removable) = ((obj_t) val1550_102), BUNSPEC);
}


/* _local/ginfo-removable-set!1956 */ obj_t 
_local_ginfo_removable_set_1956_187_globalize_ginfo(obj_t env_2402, obj_t obj_2403, obj_t val1550_2404)
{
   return local_ginfo_removable_set__201_globalize_ginfo((local_t) (obj_2403), val1550_2404);
}


/* local/ginfo-removable */ obj_t 
local_ginfo_removable_170_globalize_ginfo(local_t obj_103)
{
   return (((local_t) CREF(obj_103))->removable);
}


/* _local/ginfo-removable1957 */ obj_t 
_local_ginfo_removable1957_202_globalize_ginfo(obj_t env_2405, obj_t obj_2406)
{
   return local_ginfo_removable_170_globalize_ginfo((local_t) (obj_2406));
}


/* local/ginfo-occurrence-set! */ obj_t 
local_ginfo_occurrence_set__71_globalize_ginfo(local_t obj_104, long val1551_105)
{
   return ((((local_t) CREF(obj_104))->occurrence) = ((long) val1551_105), BUNSPEC);
}


/* _local/ginfo-occurrence-set!1958 */ obj_t 
_local_ginfo_occurrence_set_1958_113_globalize_ginfo(obj_t env_2407, obj_t obj_2408, obj_t val1551_2409)
{
   return local_ginfo_occurrence_set__71_globalize_ginfo((local_t) (obj_2408), (long) CINT(val1551_2409));
}


/* local/ginfo-occurrence */ long 
local_ginfo_occurrence_196_globalize_ginfo(local_t obj_106)
{
   return (((local_t) CREF(obj_106))->occurrence);
}


/* _local/ginfo-occurrence1959 */ obj_t 
_local_ginfo_occurrence1959_202_globalize_ginfo(obj_t env_2410, obj_t obj_2411)
{
   {
      long aux_3089;
      aux_3089 = local_ginfo_occurrence_196_globalize_ginfo((local_t) (obj_2411));
      return BINT(aux_3089);
   }
}


/* local/ginfo-user?-set! */ obj_t 
local_ginfo_user__set__80_globalize_ginfo(local_t obj_107, bool_t val1552_108)
{
   return ((((local_t) CREF(obj_107))->user__32) = ((bool_t) val1552_108), BUNSPEC);
}


/* _local/ginfo-user?-set!1960 */ obj_t 
_local_ginfo_user__set_1960_217_globalize_ginfo(obj_t env_2412, obj_t obj_2413, obj_t val1552_2414)
{
   return local_ginfo_user__set__80_globalize_ginfo((local_t) (obj_2413), CBOOL(val1552_2414));
}


/* local/ginfo-user? */ bool_t 
local_ginfo_user__24_globalize_ginfo(local_t obj_109)
{
   return (((local_t) CREF(obj_109))->user__32);
}


/* _local/ginfo-user?1961 */ obj_t 
_local_ginfo_user_1961_153_globalize_ginfo(obj_t env_2415, obj_t obj_2416)
{
   {
      bool_t aux_3098;
      aux_3098 = local_ginfo_user__24_globalize_ginfo((local_t) (obj_2416));
      return BBOOL(aux_3098);
   }
}


/* local/ginfo-key */ long 
local_ginfo_key_185_globalize_ginfo(local_t obj_110)
{
   return (((local_t) CREF(obj_110))->key);
}


/* _local/ginfo-key1962 */ obj_t 
_local_ginfo_key1962_209_globalize_ginfo(obj_t env_2417, obj_t obj_2418)
{
   {
      long aux_3103;
      aux_3103 = local_ginfo_key_185_globalize_ginfo((local_t) (obj_2418));
      return BINT(aux_3103);
   }
}


/* local/ginfo-escape?-set! */ obj_t 
local_ginfo_escape__set__30_globalize_ginfo(local_ginfo_108_t obj_111, bool_t val1553_112)
{
   {
      obj_t aux_3107;
      {
	 object_t aux_3108;
	 aux_3108 = (object_t) (obj_111);
	 aux_3107 = OBJECT_WIDENING(aux_3108);
      }
      return ((((local_ginfo_108_t) CREF(aux_3107))->escape__117) = ((bool_t) val1553_112), BUNSPEC);
   }
}


/* _local/ginfo-escape?-set!1963 */ obj_t 
_local_ginfo_escape__set_1963_222_globalize_ginfo(obj_t env_2419, obj_t obj_2420, obj_t val1553_2421)
{
   return local_ginfo_escape__set__30_globalize_ginfo((local_ginfo_108_t) (obj_2420), CBOOL(val1553_2421));
}


/* local/ginfo-escape? */ bool_t 
local_ginfo_escape__169_globalize_ginfo(local_ginfo_108_t obj_113)
{
   {
      obj_t aux_3115;
      {
	 object_t aux_3116;
	 aux_3116 = (object_t) (obj_113);
	 aux_3115 = OBJECT_WIDENING(aux_3116);
      }
      return (((local_ginfo_108_t) CREF(aux_3115))->escape__117);
   }
}


/* _local/ginfo-escape?1964 */ obj_t 
_local_ginfo_escape_1964_248_globalize_ginfo(obj_t env_2422, obj_t obj_2423)
{
   {
      bool_t aux_3120;
      aux_3120 = local_ginfo_escape__169_globalize_ginfo((local_ginfo_108_t) (obj_2423));
      return BBOOL(aux_3120);
   }
}


/* allocate-sexit/ginfo */ sexit_t 
allocate_sexit_ginfo_150_globalize_ginfo()
{
   {
      sexit_t new1533_1042;
      new1533_1042 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
      {
	 long arg1645_1043;
	 arg1645_1043 = class_num_218___object(sexit_ginfo_81_globalize_ginfo);
	 {
	    obj_t obj_1702;
	    obj_1702 = (obj_t) (new1533_1042);
	    (((obj_t) CREF(obj_1702))->header = MAKE_HEADER(arg1645_1043, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3128;
	 aux_3128 = (object_t) (new1533_1042);
	 OBJECT_WIDENING_SET(aux_3128, BFALSE);
      }
      return new1533_1042;
   }
}


/* _allocate-sexit/ginfo */ obj_t 
_allocate_sexit_ginfo_207_globalize_ginfo(obj_t env_2257)
{
   {
      sexit_t aux_3131;
      aux_3131 = allocate_sexit_ginfo_150_globalize_ginfo();
      return (obj_t) (aux_3131);
   }
}


/* sexit/ginfo? */ bool_t 
sexit_ginfo__159_globalize_ginfo(obj_t obj_117)
{
   return is_a__118___object(obj_117, sexit_ginfo_81_globalize_ginfo);
}


/* _sexit/ginfo? */ obj_t 
_sexit_ginfo__121_globalize_ginfo(obj_t env_2424, obj_t obj_2425)
{
   {
      bool_t aux_3135;
      aux_3135 = sexit_ginfo__159_globalize_ginfo(obj_2425);
      return BBOOL(aux_3135);
   }
}


/* widening1004-sexit/ginfo */ sexit_ginfo_81_t 
widening1004_sexit_ginfo_15_globalize_ginfo(bool_t g__219_118, bool_t kaptured__204_119, long free_mark_81_120, long mark_121)
{
   {
      sexit_ginfo_81_t new1519_1704;
      new1519_1704 = ((sexit_ginfo_81_t) BREF(GC_MALLOC(sizeof(struct sexit_ginfo_81))));
      ((((sexit_ginfo_81_t) CREF(new1519_1704))->g__219) = ((bool_t) g__219_118), BUNSPEC);
      ((((sexit_ginfo_81_t) CREF(new1519_1704))->kaptured__204) = ((bool_t) kaptured__204_119), BUNSPEC);
      ((((sexit_ginfo_81_t) CREF(new1519_1704))->free_mark_81) = ((long) free_mark_81_120), BUNSPEC);
      ((((sexit_ginfo_81_t) CREF(new1519_1704))->mark) = ((long) mark_121), BUNSPEC);
      return new1519_1704;
   }
}


/* _widening1004-sexit/ginfo1965 */ obj_t 
_widening1004_sexit_ginfo1965_122_globalize_ginfo(obj_t env_2426, obj_t g__219_2427, obj_t kaptured__204_2428, obj_t free_mark_81_2429, obj_t mark_2430)
{
   {
      sexit_ginfo_81_t aux_3143;
      aux_3143 = widening1004_sexit_ginfo_15_globalize_ginfo(CBOOL(g__219_2427), CBOOL(kaptured__204_2428), (long) CINT(free_mark_81_2429), (long) CINT(mark_2430));
      return (obj_t) (aux_3143);
   }
}


/* make-sexit/ginfo */ sexit_ginfo_81_t 
make_sexit_ginfo_64_globalize_ginfo(obj_t handler_122, bool_t detached__120_123, bool_t g__219_124, bool_t kaptured__204_125, long free_mark_81_126, long mark_127)
{
   {
      sexit_t aux1525_1709;
      {
	 sexit_t res1901_1721;
	 {
	    sexit_t new1180_1715;
	    new1180_1715 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
	    {
	       long arg1710_1716;
	       arg1710_1716 = class_num_218___object(sexit_ast_var);
	       {
		  obj_t obj_1719;
		  obj_1719 = (obj_t) (new1180_1715);
		  (((obj_t) CREF(obj_1719))->header = MAKE_HEADER(arg1710_1716, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3154;
	       aux_3154 = (object_t) (new1180_1715);
	       OBJECT_WIDENING_SET(aux_3154, BFALSE);
	    }
	    ((((sexit_t) CREF(new1180_1715))->handler) = ((obj_t) handler_122), BUNSPEC);
	    ((((sexit_t) CREF(new1180_1715))->detached__120) = ((bool_t) detached__120_123), BUNSPEC);
	    res1901_1721 = new1180_1715;
	 }
	 aux1525_1709 = res1901_1721;
      }
      {
	 sexit_ginfo_81_t new1526_1710;
	 new1526_1710 = ((sexit_ginfo_81_t) (aux1525_1709));
	 {
	    long arg1646_1711;
	    arg1646_1711 = class_num_218___object(sexit_ginfo_81_globalize_ginfo);
	    {
	       obj_t obj_1722;
	       obj_1722 = (obj_t) (new1526_1710);
	       (((obj_t) CREF(obj_1722))->header = MAKE_HEADER(arg1646_1711, 0), BUNSPEC);
	    }
	 }
	 {
	    sexit_ginfo_81_t arg1647_1712;
	    {
	       sexit_ginfo_81_t res1902_1733;
	       {
		  sexit_ginfo_81_t new1519_1728;
		  new1519_1728 = ((sexit_ginfo_81_t) BREF(GC_MALLOC(sizeof(struct sexit_ginfo_81))));
		  ((((sexit_ginfo_81_t) CREF(new1519_1728))->g__219) = ((bool_t) g__219_124), BUNSPEC);
		  ((((sexit_ginfo_81_t) CREF(new1519_1728))->kaptured__204) = ((bool_t) kaptured__204_125), BUNSPEC);
		  ((((sexit_ginfo_81_t) CREF(new1519_1728))->free_mark_81) = ((long) free_mark_81_126), BUNSPEC);
		  ((((sexit_ginfo_81_t) CREF(new1519_1728))->mark) = ((long) mark_127), BUNSPEC);
		  res1902_1733 = new1519_1728;
	       }
	       arg1647_1712 = res1902_1733;
	    }
	    {
	       obj_t aux_3170;
	       object_t aux_3168;
	       aux_3170 = (obj_t) (arg1647_1712);
	       aux_3168 = (object_t) (new1526_1710);
	       OBJECT_WIDENING_SET(aux_3168, aux_3170);
	    }
	 }
	 return new1526_1710;
      }
   }
}


/* _make-sexit/ginfo1966 */ obj_t 
_make_sexit_ginfo1966_234_globalize_ginfo(obj_t env_2431, obj_t handler_2432, obj_t detached__120_2433, obj_t g__219_2434, obj_t kaptured__204_2435, obj_t free_mark_81_2436, obj_t mark_2437)
{
   {
      sexit_ginfo_81_t aux_3173;
      aux_3173 = make_sexit_ginfo_64_globalize_ginfo(handler_2432, CBOOL(detached__120_2433), CBOOL(g__219_2434), CBOOL(kaptured__204_2435), (long) CINT(free_mark_81_2436), (long) CINT(mark_2437));
      return (obj_t) (aux_3173);
   }
}


/* sexit/ginfo-handler-set! */ obj_t 
sexit_ginfo_handler_set__242_globalize_ginfo(sexit_t obj_128, obj_t val1527_129)
{
   return ((((sexit_t) CREF(obj_128))->handler) = ((obj_t) val1527_129), BUNSPEC);
}


/* _sexit/ginfo-handler-set!1967 */ obj_t 
_sexit_ginfo_handler_set_1967_150_globalize_ginfo(obj_t env_2438, obj_t obj_2439, obj_t val1527_2440)
{
   return sexit_ginfo_handler_set__242_globalize_ginfo((sexit_t) (obj_2439), val1527_2440);
}


/* sexit/ginfo-handler */ obj_t 
sexit_ginfo_handler_183_globalize_ginfo(sexit_t obj_130)
{
   return (((sexit_t) CREF(obj_130))->handler);
}


/* _sexit/ginfo-handler1968 */ obj_t 
_sexit_ginfo_handler1968_234_globalize_ginfo(obj_t env_2441, obj_t obj_2442)
{
   return sexit_ginfo_handler_183_globalize_ginfo((sexit_t) (obj_2442));
}


/* sexit/ginfo-detached?-set! */ obj_t 
sexit_ginfo_detached__set__219_globalize_ginfo(sexit_t obj_131, bool_t val1528_132)
{
   return ((((sexit_t) CREF(obj_131))->detached__120) = ((bool_t) val1528_132), BUNSPEC);
}


/* _sexit/ginfo-detached?-set!1969 */ obj_t 
_sexit_ginfo_detached__set_1969_156_globalize_ginfo(obj_t env_2443, obj_t obj_2444, obj_t val1528_2445)
{
   return sexit_ginfo_detached__set__219_globalize_ginfo((sexit_t) (obj_2444), CBOOL(val1528_2445));
}


/* sexit/ginfo-detached? */ bool_t 
sexit_ginfo_detached__158_globalize_ginfo(sexit_t obj_133)
{
   return (((sexit_t) CREF(obj_133))->detached__120);
}


/* _sexit/ginfo-detached?1970 */ obj_t 
_sexit_ginfo_detached_1970_21_globalize_ginfo(obj_t env_2446, obj_t obj_2447)
{
   {
      bool_t aux_3192;
      aux_3192 = sexit_ginfo_detached__158_globalize_ginfo((sexit_t) (obj_2447));
      return BBOOL(aux_3192);
   }
}


/* sexit/ginfo-g?-set! */ obj_t 
sexit_ginfo_g__set__228_globalize_ginfo(sexit_ginfo_81_t obj_134, bool_t val1529_135)
{
   {
      obj_t aux_3196;
      {
	 object_t aux_3197;
	 aux_3197 = (object_t) (obj_134);
	 aux_3196 = OBJECT_WIDENING(aux_3197);
      }
      return ((((sexit_ginfo_81_t) CREF(aux_3196))->g__219) = ((bool_t) val1529_135), BUNSPEC);
   }
}


/* _sexit/ginfo-g?-set!1971 */ obj_t 
_sexit_ginfo_g__set_1971_227_globalize_ginfo(obj_t env_2448, obj_t obj_2449, obj_t val1529_2450)
{
   return sexit_ginfo_g__set__228_globalize_ginfo((sexit_ginfo_81_t) (obj_2449), CBOOL(val1529_2450));
}


/* sexit/ginfo-g? */ bool_t 
sexit_ginfo_g__71_globalize_ginfo(sexit_ginfo_81_t obj_136)
{
   {
      obj_t aux_3204;
      {
	 object_t aux_3205;
	 aux_3205 = (object_t) (obj_136);
	 aux_3204 = OBJECT_WIDENING(aux_3205);
      }
      return (((sexit_ginfo_81_t) CREF(aux_3204))->g__219);
   }
}


/* _sexit/ginfo-g?1972 */ obj_t 
_sexit_ginfo_g_1972_232_globalize_ginfo(obj_t env_2451, obj_t obj_2452)
{
   {
      bool_t aux_3209;
      aux_3209 = sexit_ginfo_g__71_globalize_ginfo((sexit_ginfo_81_t) (obj_2452));
      return BBOOL(aux_3209);
   }
}


/* sexit/ginfo-kaptured?-set! */ obj_t 
sexit_ginfo_kaptured__set__207_globalize_ginfo(sexit_ginfo_81_t obj_137, bool_t val1530_138)
{
   {
      obj_t aux_3213;
      {
	 object_t aux_3214;
	 aux_3214 = (object_t) (obj_137);
	 aux_3213 = OBJECT_WIDENING(aux_3214);
      }
      return ((((sexit_ginfo_81_t) CREF(aux_3213))->kaptured__204) = ((bool_t) val1530_138), BUNSPEC);
   }
}


/* _sexit/ginfo-kaptured?-set!1973 */ obj_t 
_sexit_ginfo_kaptured__set_1973_234_globalize_ginfo(obj_t env_2453, obj_t obj_2454, obj_t val1530_2455)
{
   return sexit_ginfo_kaptured__set__207_globalize_ginfo((sexit_ginfo_81_t) (obj_2454), CBOOL(val1530_2455));
}


/* sexit/ginfo-kaptured? */ bool_t 
sexit_ginfo_kaptured__46_globalize_ginfo(sexit_ginfo_81_t obj_139)
{
   {
      obj_t aux_3221;
      {
	 object_t aux_3222;
	 aux_3222 = (object_t) (obj_139);
	 aux_3221 = OBJECT_WIDENING(aux_3222);
      }
      return (((sexit_ginfo_81_t) CREF(aux_3221))->kaptured__204);
   }
}


/* _sexit/ginfo-kaptured?1974 */ obj_t 
_sexit_ginfo_kaptured_1974_188_globalize_ginfo(obj_t env_2456, obj_t obj_2457)
{
   {
      bool_t aux_3226;
      aux_3226 = sexit_ginfo_kaptured__46_globalize_ginfo((sexit_ginfo_81_t) (obj_2457));
      return BBOOL(aux_3226);
   }
}


/* sexit/ginfo-free-mark-set! */ obj_t 
sexit_ginfo_free_mark_set__210_globalize_ginfo(sexit_ginfo_81_t obj_140, long val1531_141)
{
   {
      obj_t aux_3230;
      {
	 object_t aux_3231;
	 aux_3231 = (object_t) (obj_140);
	 aux_3230 = OBJECT_WIDENING(aux_3231);
      }
      return ((((sexit_ginfo_81_t) CREF(aux_3230))->free_mark_81) = ((long) val1531_141), BUNSPEC);
   }
}


/* _sexit/ginfo-free-mark-set!1975 */ obj_t 
_sexit_ginfo_free_mark_set_1975_136_globalize_ginfo(obj_t env_2458, obj_t obj_2459, obj_t val1531_2460)
{
   return sexit_ginfo_free_mark_set__210_globalize_ginfo((sexit_ginfo_81_t) (obj_2459), (long) CINT(val1531_2460));
}


/* sexit/ginfo-free-mark */ long 
sexit_ginfo_free_mark_205_globalize_ginfo(sexit_ginfo_81_t obj_142)
{
   {
      obj_t aux_3238;
      {
	 object_t aux_3239;
	 aux_3239 = (object_t) (obj_142);
	 aux_3238 = OBJECT_WIDENING(aux_3239);
      }
      return (((sexit_ginfo_81_t) CREF(aux_3238))->free_mark_81);
   }
}


/* _sexit/ginfo-free-mark1976 */ obj_t 
_sexit_ginfo_free_mark1976_202_globalize_ginfo(obj_t env_2461, obj_t obj_2462)
{
   {
      long aux_3243;
      aux_3243 = sexit_ginfo_free_mark_205_globalize_ginfo((sexit_ginfo_81_t) (obj_2462));
      return BINT(aux_3243);
   }
}


/* sexit/ginfo-mark-set! */ obj_t 
sexit_ginfo_mark_set__228_globalize_ginfo(sexit_ginfo_81_t obj_143, long val1532_144)
{
   {
      obj_t aux_3247;
      {
	 object_t aux_3248;
	 aux_3248 = (object_t) (obj_143);
	 aux_3247 = OBJECT_WIDENING(aux_3248);
      }
      return ((((sexit_ginfo_81_t) CREF(aux_3247))->mark) = ((long) val1532_144), BUNSPEC);
   }
}


/* _sexit/ginfo-mark-set!1977 */ obj_t 
_sexit_ginfo_mark_set_1977_141_globalize_ginfo(obj_t env_2463, obj_t obj_2464, obj_t val1532_2465)
{
   return sexit_ginfo_mark_set__228_globalize_ginfo((sexit_ginfo_81_t) (obj_2464), (long) CINT(val1532_2465));
}


/* sexit/ginfo-mark */ long 
sexit_ginfo_mark_71_globalize_ginfo(sexit_ginfo_81_t obj_145)
{
   {
      obj_t aux_3255;
      {
	 object_t aux_3256;
	 aux_3256 = (object_t) (obj_145);
	 aux_3255 = OBJECT_WIDENING(aux_3256);
      }
      return (((sexit_ginfo_81_t) CREF(aux_3255))->mark);
   }
}


/* _sexit/ginfo-mark1978 */ obj_t 
_sexit_ginfo_mark1978_67_globalize_ginfo(obj_t env_2466, obj_t obj_2467)
{
   {
      long aux_3260;
      aux_3260 = sexit_ginfo_mark_71_globalize_ginfo((sexit_ginfo_81_t) (obj_2467));
      return BINT(aux_3260);
   }
}


/* allocate-svar/ginfo */ svar_t 
allocate_svar_ginfo_12_globalize_ginfo()
{
   {
      svar_t new1512_1053;
      new1512_1053 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
      {
	 long arg1648_1054;
	 arg1648_1054 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
	 {
	    obj_t obj_1734;
	    obj_1734 = (obj_t) (new1512_1053);
	    (((obj_t) CREF(obj_1734))->header = MAKE_HEADER(arg1648_1054, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3268;
	 aux_3268 = (object_t) (new1512_1053);
	 OBJECT_WIDENING_SET(aux_3268, BFALSE);
      }
      return new1512_1053;
   }
}


/* _allocate-svar/ginfo */ obj_t 
_allocate_svar_ginfo_235_globalize_ginfo(obj_t env_2256)
{
   {
      svar_t aux_3271;
      aux_3271 = allocate_svar_ginfo_12_globalize_ginfo();
      return (obj_t) (aux_3271);
   }
}


/* svar/ginfo? */ bool_t 
svar_ginfo__247_globalize_ginfo(obj_t obj_149)
{
   return is_a__118___object(obj_149, svar_ginfo_131_globalize_ginfo);
}


/* _svar/ginfo? */ obj_t 
_svar_ginfo__189_globalize_ginfo(obj_t env_2468, obj_t obj_2469)
{
   {
      bool_t aux_3275;
      aux_3275 = svar_ginfo__247_globalize_ginfo(obj_2469);
      return BBOOL(aux_3275);
   }
}


/* widening1003-svar/ginfo */ svar_ginfo_131_t 
widening1003_svar_ginfo_186_globalize_ginfo(bool_t kaptured__204_150, long free_mark_81_151, long mark_152, bool_t celled__113_153)
{
   {
      svar_ginfo_131_t new1499_1736;
      new1499_1736 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
      ((((svar_ginfo_131_t) CREF(new1499_1736))->kaptured__204) = ((bool_t) kaptured__204_150), BUNSPEC);
      ((((svar_ginfo_131_t) CREF(new1499_1736))->free_mark_81) = ((long) free_mark_81_151), BUNSPEC);
      ((((svar_ginfo_131_t) CREF(new1499_1736))->mark) = ((long) mark_152), BUNSPEC);
      ((((svar_ginfo_131_t) CREF(new1499_1736))->celled__113) = ((bool_t) celled__113_153), BUNSPEC);
      return new1499_1736;
   }
}


/* _widening1003-svar/ginfo1979 */ obj_t 
_widening1003_svar_ginfo1979_241_globalize_ginfo(obj_t env_2470, obj_t kaptured__204_2471, obj_t free_mark_81_2472, obj_t mark_2473, obj_t celled__113_2474)
{
   {
      svar_ginfo_131_t aux_3283;
      aux_3283 = widening1003_svar_ginfo_186_globalize_ginfo(CBOOL(kaptured__204_2471), (long) CINT(free_mark_81_2472), (long) CINT(mark_2473), CBOOL(celled__113_2474));
      return (obj_t) (aux_3283);
   }
}


/* make-svar/ginfo */ svar_ginfo_131_t 
make_svar_ginfo_120_globalize_ginfo(obj_t loc_154, bool_t kaptured__204_155, long free_mark_81_156, long mark_157, bool_t celled__113_158)
{
   {
      svar_t aux1505_1741;
      {
	 svar_t res1903_1751;
	 {
	    svar_t new1163_1746;
	    new1163_1746 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
	    {
	       long arg1717_1747;
	       arg1717_1747 = class_num_218___object(svar_ast_var);
	       {
		  obj_t obj_1749;
		  obj_1749 = (obj_t) (new1163_1746);
		  (((obj_t) CREF(obj_1749))->header = MAKE_HEADER(arg1717_1747, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3294;
	       aux_3294 = (object_t) (new1163_1746);
	       OBJECT_WIDENING_SET(aux_3294, BFALSE);
	    }
	    ((((svar_t) CREF(new1163_1746))->loc) = ((obj_t) loc_154), BUNSPEC);
	    res1903_1751 = new1163_1746;
	 }
	 aux1505_1741 = res1903_1751;
      }
      {
	 svar_ginfo_131_t new1506_1742;
	 new1506_1742 = ((svar_ginfo_131_t) (aux1505_1741));
	 {
	    long arg1649_1743;
	    arg1649_1743 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
	    {
	       obj_t obj_1752;
	       obj_1752 = (obj_t) (new1506_1742);
	       (((obj_t) CREF(obj_1752))->header = MAKE_HEADER(arg1649_1743, 0), BUNSPEC);
	    }
	 }
	 {
	    svar_ginfo_131_t arg1650_1744;
	    {
	       svar_ginfo_131_t res1904_1763;
	       {
		  svar_ginfo_131_t new1499_1758;
		  new1499_1758 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
		  ((((svar_ginfo_131_t) CREF(new1499_1758))->kaptured__204) = ((bool_t) kaptured__204_155), BUNSPEC);
		  ((((svar_ginfo_131_t) CREF(new1499_1758))->free_mark_81) = ((long) free_mark_81_156), BUNSPEC);
		  ((((svar_ginfo_131_t) CREF(new1499_1758))->mark) = ((long) mark_157), BUNSPEC);
		  ((((svar_ginfo_131_t) CREF(new1499_1758))->celled__113) = ((bool_t) celled__113_158), BUNSPEC);
		  res1904_1763 = new1499_1758;
	       }
	       arg1650_1744 = res1904_1763;
	    }
	    {
	       obj_t aux_3309;
	       object_t aux_3307;
	       aux_3309 = (obj_t) (arg1650_1744);
	       aux_3307 = (object_t) (new1506_1742);
	       OBJECT_WIDENING_SET(aux_3307, aux_3309);
	    }
	 }
	 return new1506_1742;
      }
   }
}


/* _make-svar/ginfo1980 */ obj_t 
_make_svar_ginfo1980_37_globalize_ginfo(obj_t env_2475, obj_t loc_2476, obj_t kaptured__204_2477, obj_t free_mark_81_2478, obj_t mark_2479, obj_t celled__113_2480)
{
   {
      svar_ginfo_131_t aux_3312;
      aux_3312 = make_svar_ginfo_120_globalize_ginfo(loc_2476, CBOOL(kaptured__204_2477), (long) CINT(free_mark_81_2478), (long) CINT(mark_2479), CBOOL(celled__113_2480));
      return (obj_t) (aux_3312);
   }
}


/* svar/ginfo-loc-set! */ obj_t 
svar_ginfo_loc_set__72_globalize_ginfo(svar_t obj_159, obj_t val1507_160)
{
   return ((((svar_t) CREF(obj_159))->loc) = ((obj_t) val1507_160), BUNSPEC);
}


/* _svar/ginfo-loc-set!1981 */ obj_t 
_svar_ginfo_loc_set_1981_1_globalize_ginfo(obj_t env_2481, obj_t obj_2482, obj_t val1507_2483)
{
   return svar_ginfo_loc_set__72_globalize_ginfo((svar_t) (obj_2482), val1507_2483);
}


/* svar/ginfo-loc */ obj_t 
svar_ginfo_loc_12_globalize_ginfo(svar_t obj_161)
{
   return (((svar_t) CREF(obj_161))->loc);
}


/* _svar/ginfo-loc1982 */ obj_t 
_svar_ginfo_loc1982_28_globalize_ginfo(obj_t env_2484, obj_t obj_2485)
{
   return svar_ginfo_loc_12_globalize_ginfo((svar_t) (obj_2485));
}


/* svar/ginfo-kaptured?-set! */ obj_t 
svar_ginfo_kaptured__set__85_globalize_ginfo(svar_ginfo_131_t obj_162, bool_t val1508_163)
{
   {
      obj_t aux_3325;
      {
	 object_t aux_3326;
	 aux_3326 = (object_t) (obj_162);
	 aux_3325 = OBJECT_WIDENING(aux_3326);
      }
      return ((((svar_ginfo_131_t) CREF(aux_3325))->kaptured__204) = ((bool_t) val1508_163), BUNSPEC);
   }
}


/* _svar/ginfo-kaptured?-set!1983 */ obj_t 
_svar_ginfo_kaptured__set_1983_89_globalize_ginfo(obj_t env_2486, obj_t obj_2487, obj_t val1508_2488)
{
   return svar_ginfo_kaptured__set__85_globalize_ginfo((svar_ginfo_131_t) (obj_2487), CBOOL(val1508_2488));
}


/* svar/ginfo-kaptured? */ bool_t 
svar_ginfo_kaptured__26_globalize_ginfo(svar_ginfo_131_t obj_164)
{
   {
      obj_t aux_3333;
      {
	 object_t aux_3334;
	 aux_3334 = (object_t) (obj_164);
	 aux_3333 = OBJECT_WIDENING(aux_3334);
      }
      return (((svar_ginfo_131_t) CREF(aux_3333))->kaptured__204);
   }
}


/* _svar/ginfo-kaptured?1984 */ obj_t 
_svar_ginfo_kaptured_1984_32_globalize_ginfo(obj_t env_2489, obj_t obj_2490)
{
   {
      bool_t aux_3338;
      aux_3338 = svar_ginfo_kaptured__26_globalize_ginfo((svar_ginfo_131_t) (obj_2490));
      return BBOOL(aux_3338);
   }
}


/* svar/ginfo-free-mark-set! */ obj_t 
svar_ginfo_free_mark_set__224_globalize_ginfo(svar_ginfo_131_t obj_165, long val1509_166)
{
   {
      obj_t aux_3342;
      {
	 object_t aux_3343;
	 aux_3343 = (object_t) (obj_165);
	 aux_3342 = OBJECT_WIDENING(aux_3343);
      }
      return ((((svar_ginfo_131_t) CREF(aux_3342))->free_mark_81) = ((long) val1509_166), BUNSPEC);
   }
}


/* _svar/ginfo-free-mark-set!1985 */ obj_t 
_svar_ginfo_free_mark_set_1985_110_globalize_ginfo(obj_t env_2491, obj_t obj_2492, obj_t val1509_2493)
{
   return svar_ginfo_free_mark_set__224_globalize_ginfo((svar_ginfo_131_t) (obj_2492), (long) CINT(val1509_2493));
}


/* svar/ginfo-free-mark */ long 
svar_ginfo_free_mark_225_globalize_ginfo(svar_ginfo_131_t obj_167)
{
   {
      obj_t aux_3350;
      {
	 object_t aux_3351;
	 aux_3351 = (object_t) (obj_167);
	 aux_3350 = OBJECT_WIDENING(aux_3351);
      }
      return (((svar_ginfo_131_t) CREF(aux_3350))->free_mark_81);
   }
}


/* _svar/ginfo-free-mark1986 */ obj_t 
_svar_ginfo_free_mark1986_33_globalize_ginfo(obj_t env_2494, obj_t obj_2495)
{
   {
      long aux_3355;
      aux_3355 = svar_ginfo_free_mark_225_globalize_ginfo((svar_ginfo_131_t) (obj_2495));
      return BINT(aux_3355);
   }
}


/* svar/ginfo-mark-set! */ obj_t 
svar_ginfo_mark_set__188_globalize_ginfo(svar_ginfo_131_t obj_168, long val1510_169)
{
   {
      obj_t aux_3359;
      {
	 object_t aux_3360;
	 aux_3360 = (object_t) (obj_168);
	 aux_3359 = OBJECT_WIDENING(aux_3360);
      }
      return ((((svar_ginfo_131_t) CREF(aux_3359))->mark) = ((long) val1510_169), BUNSPEC);
   }
}


/* _svar/ginfo-mark-set!1987 */ obj_t 
_svar_ginfo_mark_set_1987_218_globalize_ginfo(obj_t env_2496, obj_t obj_2497, obj_t val1510_2498)
{
   return svar_ginfo_mark_set__188_globalize_ginfo((svar_ginfo_131_t) (obj_2497), (long) CINT(val1510_2498));
}


/* svar/ginfo-mark */ long 
svar_ginfo_mark_222_globalize_ginfo(svar_ginfo_131_t obj_170)
{
   {
      obj_t aux_3367;
      {
	 object_t aux_3368;
	 aux_3368 = (object_t) (obj_170);
	 aux_3367 = OBJECT_WIDENING(aux_3368);
      }
      return (((svar_ginfo_131_t) CREF(aux_3367))->mark);
   }
}


/* _svar/ginfo-mark1988 */ obj_t 
_svar_ginfo_mark1988_222_globalize_ginfo(obj_t env_2499, obj_t obj_2500)
{
   {
      long aux_3372;
      aux_3372 = svar_ginfo_mark_222_globalize_ginfo((svar_ginfo_131_t) (obj_2500));
      return BINT(aux_3372);
   }
}


/* svar/ginfo-celled?-set! */ obj_t 
svar_ginfo_celled__set__234_globalize_ginfo(svar_ginfo_131_t obj_171, bool_t val1511_172)
{
   {
      obj_t aux_3376;
      {
	 object_t aux_3377;
	 aux_3377 = (object_t) (obj_171);
	 aux_3376 = OBJECT_WIDENING(aux_3377);
      }
      return ((((svar_ginfo_131_t) CREF(aux_3376))->celled__113) = ((bool_t) val1511_172), BUNSPEC);
   }
}


/* _svar/ginfo-celled?-set!1989 */ obj_t 
_svar_ginfo_celled__set_1989_101_globalize_ginfo(obj_t env_2501, obj_t obj_2502, obj_t val1511_2503)
{
   return svar_ginfo_celled__set__234_globalize_ginfo((svar_ginfo_131_t) (obj_2502), CBOOL(val1511_2503));
}


/* svar/ginfo-celled? */ bool_t 
svar_ginfo_celled__246_globalize_ginfo(svar_ginfo_131_t obj_173)
{
   {
      obj_t aux_3384;
      {
	 object_t aux_3385;
	 aux_3385 = (object_t) (obj_173);
	 aux_3384 = OBJECT_WIDENING(aux_3385);
      }
      return (((svar_ginfo_131_t) CREF(aux_3384))->celled__113);
   }
}


/* _svar/ginfo-celled?1990 */ obj_t 
_svar_ginfo_celled_1990_10_globalize_ginfo(obj_t env_2504, obj_t obj_2505)
{
   {
      bool_t aux_3389;
      aux_3389 = svar_ginfo_celled__246_globalize_ginfo((svar_ginfo_131_t) (obj_2505));
      return BBOOL(aux_3389);
   }
}


/* allocate-sfun/ginfo */ sfun_t 
allocate_sfun_ginfo_135_globalize_ginfo()
{
   {
      sfun_t new1491_1064;
      new1491_1064 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
      {
	 long arg1652_1065;
	 arg1652_1065 = class_num_218___object(sfun_ginfo_98_globalize_ginfo);
	 {
	    obj_t obj_1764;
	    obj_1764 = (obj_t) (new1491_1064);
	    (((obj_t) CREF(obj_1764))->header = MAKE_HEADER(arg1652_1065, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_3397;
	 aux_3397 = (object_t) (new1491_1064);
	 OBJECT_WIDENING_SET(aux_3397, BFALSE);
      }
      return new1491_1064;
   }
}


/* _allocate-sfun/ginfo */ obj_t 
_allocate_sfun_ginfo_166_globalize_ginfo(obj_t env_2255)
{
   {
      sfun_t aux_3400;
      aux_3400 = allocate_sfun_ginfo_135_globalize_ginfo();
      return (obj_t) (aux_3400);
   }
}


/* sfun/ginfo? */ bool_t 
sfun_ginfo__192_globalize_ginfo(obj_t obj_177)
{
   return is_a__118___object(obj_177, sfun_ginfo_98_globalize_ginfo);
}


/* _sfun/ginfo? */ obj_t 
_sfun_ginfo__175_globalize_ginfo(obj_t env_2506, obj_t obj_2507)
{
   {
      bool_t aux_3404;
      aux_3404 = sfun_ginfo__192_globalize_ginfo(obj_2507);
      return BBOOL(aux_3404);
   }
}


/* widening1002-sfun/ginfo */ sfun_ginfo_98_t 
widening1002_sfun_ginfo_193_globalize_ginfo(bool_t g__219_178, obj_t cfrom_179, obj_t cfrom__119_180, obj_t cto_181, obj_t cto__14_182, obj_t cfunction_183, obj_t integrator_184, obj_t integrated_185, obj_t plugged_in_15_186, long mark_187, obj_t free_mark_81_188, obj_t the_global_201_189, obj_t kaptured_190, obj_t new_body_215_191, long bmark_192, long umark_193, obj_t free_194, obj_t bound_195)
{
   {
      sfun_ginfo_98_t new1440_1766;
      new1440_1766 = ((sfun_ginfo_98_t) BREF(GC_MALLOC(sizeof(struct sfun_ginfo_98))));
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->g__219) = ((bool_t) g__219_178), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->cfrom) = ((obj_t) cfrom_179), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->cfrom__119) = ((obj_t) cfrom__119_180), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->cto) = ((obj_t) cto_181), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->cto__14) = ((obj_t) cto__14_182), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->cfunction) = ((obj_t) cfunction_183), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->integrator) = ((obj_t) integrator_184), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->integrated) = ((obj_t) integrated_185), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->plugged_in_15) = ((obj_t) plugged_in_15_186), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->mark) = ((long) mark_187), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->free_mark_81) = ((obj_t) free_mark_81_188), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->the_global_201) = ((obj_t) the_global_201_189), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->kaptured) = ((obj_t) kaptured_190), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->new_body_215) = ((obj_t) new_body_215_191), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->bmark) = ((long) bmark_192), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->umark) = ((long) umark_193), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->free) = ((obj_t) free_194), BUNSPEC);
      ((((sfun_ginfo_98_t) CREF(new1440_1766))->bound) = ((obj_t) bound_195), BUNSPEC);
      return new1440_1766;
   }
}


/* _widening1002-sfun/ginfo1991 */ obj_t 
_widening1002_sfun_ginfo1991_162_globalize_ginfo(obj_t env_2508, obj_t g__219_2509, obj_t cfrom_2510, obj_t cfrom__119_2511, obj_t cto_2512, obj_t cto__14_2513, obj_t cfunction_2514, obj_t integrator_2515, obj_t integrated_2516, obj_t plugged_in_15_2517, obj_t mark_2518, obj_t free_mark_81_2519, obj_t the_global_201_2520, obj_t kaptured_2521, obj_t new_body_215_2522, obj_t bmark_2523, obj_t umark_2524, obj_t free_2525, obj_t bound_2526)
{
   {
      sfun_ginfo_98_t aux_3426;
      aux_3426 = widening1002_sfun_ginfo_193_globalize_ginfo(CBOOL(g__219_2509), cfrom_2510, cfrom__119_2511, cto_2512, cto__14_2513, cfunction_2514, integrator_2515, integrated_2516, plugged_in_15_2517, (long) CINT(mark_2518), free_mark_81_2519, the_global_201_2520, kaptured_2521, new_body_215_2522, (long) CINT(bmark_2523), (long) CINT(umark_2524), free_2525, bound_2526);
      return (obj_t) (aux_3426);
   }
}


/* make-sfun/ginfo */ sfun_ginfo_98_t 
make_sfun_ginfo_212_globalize_ginfo(long arity_196, obj_t side_effect__165_197, obj_t predicate_of_78_198, obj_t stack_allocator_172_199, bool_t top__138_200, obj_t the_closure_238_201, obj_t property_202, obj_t args_203, obj_t body_204, obj_t class_205, obj_t dsssl_keywords_243_206, obj_t loc_207, bool_t g__219_208, obj_t cfrom_209, obj_t cfrom__119_210, obj_t cto_211, obj_t cto__14_212, obj_t cfunction_213, obj_t integrator_214, obj_t integrated_215, obj_t plugged_in_15_216, long mark_217, obj_t free_mark_81_218, obj_t the_global_201_219, obj_t kaptured_220, obj_t new_body_215_221, long bmark_222, long umark_223, obj_t free_224, obj_t bound_225)
{
   {
      sfun_t aux1460_1785;
      {
	 sfun_t res1905_1817;
	 {
	    sfun_t new1119_1801;
	    new1119_1801 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
	    {
	       long arg1722_1802;
	       arg1722_1802 = class_num_218___object(sfun_ast_var);
	       {
		  obj_t obj_1815;
		  obj_1815 = (obj_t) (new1119_1801);
		  (((obj_t) CREF(obj_1815))->header = MAKE_HEADER(arg1722_1802, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_3437;
	       aux_3437 = (object_t) (new1119_1801);
	       OBJECT_WIDENING_SET(aux_3437, BFALSE);
	    }
	    ((((sfun_t) CREF(new1119_1801))->arity) = ((long) arity_196), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->side_effect__165) = ((obj_t) side_effect__165_197), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->predicate_of_78) = ((obj_t) predicate_of_78_198), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->stack_allocator_172) = ((obj_t) stack_allocator_172_199), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->top__138) = ((bool_t) top__138_200), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->the_closure_238) = ((obj_t) the_closure_238_201), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->property) = ((obj_t) property_202), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->args) = ((obj_t) args_203), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->body) = ((obj_t) body_204), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->class) = ((obj_t) class_205), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->dsssl_keywords_243) = ((obj_t) dsssl_keywords_243_206), BUNSPEC);
	    ((((sfun_t) CREF(new1119_1801))->loc) = ((obj_t) loc_207), BUNSPEC);
	    res1905_1817 = new1119_1801;
	 }
	 aux1460_1785 = res1905_1817;
      }
      {
	 sfun_ginfo_98_t new1461_1786;
	 new1461_1786 = ((sfun_ginfo_98_t) (aux1460_1785));
	 {
	    long arg1653_1787;
	    arg1653_1787 = class_num_218___object(sfun_ginfo_98_globalize_ginfo);
	    {
	       obj_t obj_1818;
	       obj_1818 = (obj_t) (new1461_1786);
	       (((obj_t) CREF(obj_1818))->header = MAKE_HEADER(arg1653_1787, 0), BUNSPEC);
	    }
	 }
	 {
	    sfun_ginfo_98_t arg1654_1788;
	    {
	       sfun_ginfo_98_t res1906_1857;
	       {
		  sfun_ginfo_98_t new1440_1838;
		  new1440_1838 = ((sfun_ginfo_98_t) BREF(GC_MALLOC(sizeof(struct sfun_ginfo_98))));
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->g__219) = ((bool_t) g__219_208), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->cfrom) = ((obj_t) cfrom_209), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->cfrom__119) = ((obj_t) cfrom__119_210), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->cto) = ((obj_t) cto_211), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->cto__14) = ((obj_t) cto__14_212), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->cfunction) = ((obj_t) cfunction_213), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->integrator) = ((obj_t) integrator_214), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->integrated) = ((obj_t) integrated_215), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->plugged_in_15) = ((obj_t) plugged_in_15_216), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->mark) = ((long) mark_217), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->free_mark_81) = ((obj_t) free_mark_81_218), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->the_global_201) = ((obj_t) the_global_201_219), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->kaptured) = ((obj_t) kaptured_220), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->new_body_215) = ((obj_t) new_body_215_221), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->bmark) = ((long) bmark_222), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->umark) = ((long) umark_223), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->free) = ((obj_t) free_224), BUNSPEC);
		  ((((sfun_ginfo_98_t) CREF(new1440_1838))->bound) = ((obj_t) bound_225), BUNSPEC);
		  res1906_1857 = new1440_1838;
	       }
	       arg1654_1788 = res1906_1857;
	    }
	    {
	       obj_t aux_3477;
	       object_t aux_3475;
	       aux_3477 = (obj_t) (arg1654_1788);
	       aux_3475 = (object_t) (new1461_1786);
	       OBJECT_WIDENING_SET(aux_3475, aux_3477);
	    }
	 }
	 return new1461_1786;
      }
   }
}


/* _make-sfun/ginfo1992 */ obj_t 
_make_sfun_ginfo1992_161_globalize_ginfo(obj_t env_2527, obj_t arity_2528, obj_t side_effect__165_2529, obj_t predicate_of_78_2530, obj_t stack_allocator_172_2531, obj_t top__138_2532, obj_t the_closure_238_2533, obj_t property_2534, obj_t args_2535, obj_t body_2536, obj_t class_2537, obj_t dsssl_keywords_243_2538, obj_t loc_2539, obj_t g__219_2540, obj_t cfrom_2541, obj_t cfrom__119_2542, obj_t cto_2543, obj_t cto__14_2544, obj_t cfunction_2545, obj_t integrator_2546, obj_t integrated_2547, obj_t plugged_in_15_2548, obj_t mark_2549, obj_t free_mark_81_2550, obj_t the_global_201_2551, obj_t kaptured_2552, obj_t new_body_215_2553, obj_t bmark_2554, obj_t umark_2555, obj_t free_2556, obj_t bound_2557)
{
   {
      sfun_ginfo_98_t aux_3480;
      aux_3480 = make_sfun_ginfo_212_globalize_ginfo((long) CINT(arity_2528), side_effect__165_2529, predicate_of_78_2530, stack_allocator_172_2531, CBOOL(top__138_2532), the_closure_238_2533, property_2534, args_2535, body_2536, class_2537, dsssl_keywords_243_2538, loc_2539, CBOOL(g__219_2540), cfrom_2541, cfrom__119_2542, cto_2543, cto__14_2544, cfunction_2545, integrator_2546, integrated_2547, plugged_in_15_2548, (long) CINT(mark_2549), free_mark_81_2550, the_global_201_2551, kaptured_2552, new_body_215_2553, (long) CINT(bmark_2554), (long) CINT(umark_2555), free_2556, bound_2557);
      return (obj_t) (aux_3480);
   }
}


/* sfun/ginfo-arity */ long 
sfun_ginfo_arity_67_globalize_ginfo(sfun_t obj_226)
{
   return (((sfun_t) CREF(obj_226))->arity);
}


/* _sfun/ginfo-arity1993 */ obj_t 
_sfun_ginfo_arity1993_184_globalize_ginfo(obj_t env_2558, obj_t obj_2559)
{
   {
      long aux_3490;
      aux_3490 = sfun_ginfo_arity_67_globalize_ginfo((sfun_t) (obj_2559));
      return BINT(aux_3490);
   }
}


/* sfun/ginfo-side-effect?-set! */ obj_t 
sfun_ginfo_side_effect__set__170_globalize_ginfo(sfun_t obj_227, obj_t val1462_228)
{
   return ((((sfun_t) CREF(obj_227))->side_effect__165) = ((obj_t) val1462_228), BUNSPEC);
}


/* _sfun/ginfo-side-effect?-set!1994 */ obj_t 
_sfun_ginfo_side_effect__set_1994_222_globalize_ginfo(obj_t env_2560, obj_t obj_2561, obj_t val1462_2562)
{
   return sfun_ginfo_side_effect__set__170_globalize_ginfo((sfun_t) (obj_2561), val1462_2562);
}


/* sfun/ginfo-side-effect? */ obj_t 
sfun_ginfo_side_effect__156_globalize_ginfo(sfun_t obj_229)
{
   return (((sfun_t) CREF(obj_229))->side_effect__165);
}


/* _sfun/ginfo-side-effect?1995 */ obj_t 
_sfun_ginfo_side_effect_1995_189_globalize_ginfo(obj_t env_2563, obj_t obj_2564)
{
   return sfun_ginfo_side_effect__156_globalize_ginfo((sfun_t) (obj_2564));
}


/* sfun/ginfo-predicate-of-set! */ obj_t 
sfun_ginfo_predicate_of_set__49_globalize_ginfo(sfun_t obj_230, obj_t val1463_231)
{
   return ((((sfun_t) CREF(obj_230))->predicate_of_78) = ((obj_t) val1463_231), BUNSPEC);
}


/* _sfun/ginfo-predicate-of-set!1996 */ obj_t 
_sfun_ginfo_predicate_of_set_1996_93_globalize_ginfo(obj_t env_2565, obj_t obj_2566, obj_t val1463_2567)
{
   return sfun_ginfo_predicate_of_set__49_globalize_ginfo((sfun_t) (obj_2566), val1463_2567);
}


/* sfun/ginfo-predicate-of */ obj_t 
sfun_ginfo_predicate_of_20_globalize_ginfo(sfun_t obj_232)
{
   return (((sfun_t) CREF(obj_232))->predicate_of_78);
}


/* _sfun/ginfo-predicate-of1997 */ obj_t 
_sfun_ginfo_predicate_of1997_37_globalize_ginfo(obj_t env_2568, obj_t obj_2569)
{
   return sfun_ginfo_predicate_of_20_globalize_ginfo((sfun_t) (obj_2569));
}


/* sfun/ginfo-stack-allocator-set! */ obj_t 
sfun_ginfo_stack_allocator_set__224_globalize_ginfo(sfun_t obj_233, obj_t val1464_234)
{
   return ((((sfun_t) CREF(obj_233))->stack_allocator_172) = ((obj_t) val1464_234), BUNSPEC);
}


/* _sfun/ginfo-stack-allocator-set!1998 */ obj_t 
_sfun_ginfo_stack_allocator_set_1998_90_globalize_ginfo(obj_t env_2570, obj_t obj_2571, obj_t val1464_2572)
{
   return sfun_ginfo_stack_allocator_set__224_globalize_ginfo((sfun_t) (obj_2571), val1464_2572);
}


/* sfun/ginfo-stack-allocator */ obj_t 
sfun_ginfo_stack_allocator_225_globalize_ginfo(sfun_t obj_235)
{
   return (((sfun_t) CREF(obj_235))->stack_allocator_172);
}


/* _sfun/ginfo-stack-allocator1999 */ obj_t 
_sfun_ginfo_stack_allocator1999_228_globalize_ginfo(obj_t env_2573, obj_t obj_2574)
{
   return sfun_ginfo_stack_allocator_225_globalize_ginfo((sfun_t) (obj_2574));
}


/* sfun/ginfo-top?-set! */ obj_t 
sfun_ginfo_top__set__155_globalize_ginfo(sfun_t obj_236, bool_t val1465_237)
{
   return ((((sfun_t) CREF(obj_236))->top__138) = ((bool_t) val1465_237), BUNSPEC);
}


/* _sfun/ginfo-top?-set!2000 */ obj_t 
_sfun_ginfo_top__set_2000_198_globalize_ginfo(obj_t env_2575, obj_t obj_2576, obj_t val1465_2577)
{
   return sfun_ginfo_top__set__155_globalize_ginfo((sfun_t) (obj_2576), CBOOL(val1465_2577));
}


/* sfun/ginfo-top? */ bool_t 
sfun_ginfo_top__136_globalize_ginfo(sfun_t obj_238)
{
   return (((sfun_t) CREF(obj_238))->top__138);
}


/* _sfun/ginfo-top?2001 */ obj_t 
_sfun_ginfo_top_2001_123_globalize_ginfo(obj_t env_2578, obj_t obj_2579)
{
   {
      bool_t aux_3517;
      aux_3517 = sfun_ginfo_top__136_globalize_ginfo((sfun_t) (obj_2579));
      return BBOOL(aux_3517);
   }
}


/* sfun/ginfo-the-closure-set! */ obj_t 
sfun_ginfo_the_closure_set__229_globalize_ginfo(sfun_t obj_239, obj_t val1466_240)
{
   return ((((sfun_t) CREF(obj_239))->the_closure_238) = ((obj_t) val1466_240), BUNSPEC);
}


/* _sfun/ginfo-the-closure-set!2002 */ obj_t 
_sfun_ginfo_the_closure_set_2002_174_globalize_ginfo(obj_t env_2580, obj_t obj_2581, obj_t val1466_2582)
{
   return sfun_ginfo_the_closure_set__229_globalize_ginfo((sfun_t) (obj_2581), val1466_2582);
}


/* sfun/ginfo-the-closure */ obj_t 
sfun_ginfo_the_closure_142_globalize_ginfo(sfun_t obj_241)
{
   return (((sfun_t) CREF(obj_241))->the_closure_238);
}


/* _sfun/ginfo-the-closure2003 */ obj_t 
_sfun_ginfo_the_closure2003_217_globalize_ginfo(obj_t env_2583, obj_t obj_2584)
{
   return sfun_ginfo_the_closure_142_globalize_ginfo((sfun_t) (obj_2584));
}


/* sfun/ginfo-property-set! */ obj_t 
sfun_ginfo_property_set__8_globalize_ginfo(sfun_t obj_242, obj_t val1467_243)
{
   return ((((sfun_t) CREF(obj_242))->property) = ((obj_t) val1467_243), BUNSPEC);
}


/* _sfun/ginfo-property-set!2004 */ obj_t 
_sfun_ginfo_property_set_2004_201_globalize_ginfo(obj_t env_2585, obj_t obj_2586, obj_t val1467_2587)
{
   return sfun_ginfo_property_set__8_globalize_ginfo((sfun_t) (obj_2586), val1467_2587);
}


/* sfun/ginfo-property */ obj_t 
sfun_ginfo_property_59_globalize_ginfo(sfun_t obj_244)
{
   return (((sfun_t) CREF(obj_244))->property);
}


/* _sfun/ginfo-property2005 */ obj_t 
_sfun_ginfo_property2005_186_globalize_ginfo(obj_t env_2588, obj_t obj_2589)
{
   return sfun_ginfo_property_59_globalize_ginfo((sfun_t) (obj_2589));
}


/* sfun/ginfo-args-set! */ obj_t 
sfun_ginfo_args_set__144_globalize_ginfo(sfun_t obj_245, obj_t val1468_246)
{
   return ((((sfun_t) CREF(obj_245))->args) = ((obj_t) val1468_246), BUNSPEC);
}


/* _sfun/ginfo-args-set!2006 */ obj_t 
_sfun_ginfo_args_set_2006_216_globalize_ginfo(obj_t env_2590, obj_t obj_2591, obj_t val1468_2592)
{
   return sfun_ginfo_args_set__144_globalize_ginfo((sfun_t) (obj_2591), val1468_2592);
}


/* sfun/ginfo-args */ obj_t 
sfun_ginfo_args_248_globalize_ginfo(sfun_t obj_247)
{
   return (((sfun_t) CREF(obj_247))->args);
}


/* _sfun/ginfo-args2007 */ obj_t 
_sfun_ginfo_args2007_38_globalize_ginfo(obj_t env_2593, obj_t obj_2594)
{
   return sfun_ginfo_args_248_globalize_ginfo((sfun_t) (obj_2594));
}


/* sfun/ginfo-body-set! */ obj_t 
sfun_ginfo_body_set__10_globalize_ginfo(sfun_t obj_248, obj_t val1469_249)
{
   return ((((sfun_t) CREF(obj_248))->body) = ((obj_t) val1469_249), BUNSPEC);
}


/* _sfun/ginfo-body-set!2008 */ obj_t 
_sfun_ginfo_body_set_2008_75_globalize_ginfo(obj_t env_2595, obj_t obj_2596, obj_t val1469_2597)
{
   return sfun_ginfo_body_set__10_globalize_ginfo((sfun_t) (obj_2596), val1469_2597);
}


/* sfun/ginfo-body */ obj_t 
sfun_ginfo_body_35_globalize_ginfo(sfun_t obj_250)
{
   return (((sfun_t) CREF(obj_250))->body);
}


/* _sfun/ginfo-body2009 */ obj_t 
_sfun_ginfo_body2009_182_globalize_ginfo(obj_t env_2598, obj_t obj_2599)
{
   return sfun_ginfo_body_35_globalize_ginfo((sfun_t) (obj_2599));
}


/* sfun/ginfo-class-set! */ obj_t 
sfun_ginfo_class_set__182_globalize_ginfo(sfun_t obj_251, obj_t val1470_252)
{
   return ((((sfun_t) CREF(obj_251))->class) = ((obj_t) val1470_252), BUNSPEC);
}


/* _sfun/ginfo-class-set!2010 */ obj_t 
_sfun_ginfo_class_set_2010_243_globalize_ginfo(obj_t env_2600, obj_t obj_2601, obj_t val1470_2602)
{
   return sfun_ginfo_class_set__182_globalize_ginfo((sfun_t) (obj_2601), val1470_2602);
}


/* sfun/ginfo-class */ obj_t 
sfun_ginfo_class_109_globalize_ginfo(sfun_t obj_253)
{
   return (((sfun_t) CREF(obj_253))->class);
}


/* _sfun/ginfo-class2011 */ obj_t 
_sfun_ginfo_class2011_170_globalize_ginfo(obj_t env_2603, obj_t obj_2604)
{
   return sfun_ginfo_class_109_globalize_ginfo((sfun_t) (obj_2604));
}


/* sfun/ginfo-dsssl-keywords-set! */ obj_t 
sfun_ginfo_dsssl_keywords_set__63_globalize_ginfo(sfun_t obj_254, obj_t val1471_255)
{
   return ((((sfun_t) CREF(obj_254))->dsssl_keywords_243) = ((obj_t) val1471_255), BUNSPEC);
}


/* _sfun/ginfo-dsssl-keywords-set!2012 */ obj_t 
_sfun_ginfo_dsssl_keywords_set_2012_227_globalize_ginfo(obj_t env_2605, obj_t obj_2606, obj_t val1471_2607)
{
   return sfun_ginfo_dsssl_keywords_set__63_globalize_ginfo((sfun_t) (obj_2606), val1471_2607);
}


/* sfun/ginfo-dsssl-keywords */ obj_t 
sfun_ginfo_dsssl_keywords_77_globalize_ginfo(sfun_t obj_256)
{
   return (((sfun_t) CREF(obj_256))->dsssl_keywords_243);
}


/* _sfun/ginfo-dsssl-keywords2013 */ obj_t 
_sfun_ginfo_dsssl_keywords2013_44_globalize_ginfo(obj_t env_2608, obj_t obj_2609)
{
   return sfun_ginfo_dsssl_keywords_77_globalize_ginfo((sfun_t) (obj_2609));
}


/* sfun/ginfo-loc-set! */ obj_t 
sfun_ginfo_loc_set__94_globalize_ginfo(sfun_t obj_257, obj_t val1472_258)
{
   return ((((sfun_t) CREF(obj_257))->loc) = ((obj_t) val1472_258), BUNSPEC);
}


/* _sfun/ginfo-loc-set!2014 */ obj_t 
_sfun_ginfo_loc_set_2014_18_globalize_ginfo(obj_t env_2610, obj_t obj_2611, obj_t val1472_2612)
{
   return sfun_ginfo_loc_set__94_globalize_ginfo((sfun_t) (obj_2611), val1472_2612);
}


/* sfun/ginfo-loc */ obj_t 
sfun_ginfo_loc_36_globalize_ginfo(sfun_t obj_259)
{
   return (((sfun_t) CREF(obj_259))->loc);
}


/* _sfun/ginfo-loc2015 */ obj_t 
_sfun_ginfo_loc2015_63_globalize_ginfo(obj_t env_2613, obj_t obj_2614)
{
   return sfun_ginfo_loc_36_globalize_ginfo((sfun_t) (obj_2614));
}


/* sfun/ginfo-g?-set! */ obj_t 
sfun_ginfo_g__set__43_globalize_ginfo(sfun_ginfo_98_t obj_260, bool_t val1473_261)
{
   {
      obj_t aux_3563;
      {
	 object_t aux_3564;
	 aux_3564 = (object_t) (obj_260);
	 aux_3563 = OBJECT_WIDENING(aux_3564);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3563))->g__219) = ((bool_t) val1473_261), BUNSPEC);
   }
}


/* _sfun/ginfo-g?-set!2016 */ obj_t 
_sfun_ginfo_g__set_2016_77_globalize_ginfo(obj_t env_2615, obj_t obj_2616, obj_t val1473_2617)
{
   return sfun_ginfo_g__set__43_globalize_ginfo((sfun_ginfo_98_t) (obj_2616), CBOOL(val1473_2617));
}


/* sfun/ginfo-g? */ bool_t 
sfun_ginfo_g__97_globalize_ginfo(sfun_ginfo_98_t obj_262)
{
   {
      obj_t aux_3571;
      {
	 object_t aux_3572;
	 aux_3572 = (object_t) (obj_262);
	 aux_3571 = OBJECT_WIDENING(aux_3572);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3571))->g__219);
   }
}


/* _sfun/ginfo-g?2017 */ obj_t 
_sfun_ginfo_g_2017_38_globalize_ginfo(obj_t env_2618, obj_t obj_2619)
{
   {
      bool_t aux_3576;
      aux_3576 = sfun_ginfo_g__97_globalize_ginfo((sfun_ginfo_98_t) (obj_2619));
      return BBOOL(aux_3576);
   }
}


/* sfun/ginfo-cfrom-set! */ obj_t 
sfun_ginfo_cfrom_set__112_globalize_ginfo(sfun_ginfo_98_t obj_263, obj_t val1474_264)
{
   {
      obj_t aux_3580;
      {
	 object_t aux_3581;
	 aux_3581 = (object_t) (obj_263);
	 aux_3580 = OBJECT_WIDENING(aux_3581);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3580))->cfrom) = ((obj_t) val1474_264), BUNSPEC);
   }
}


/* _sfun/ginfo-cfrom-set!2018 */ obj_t 
_sfun_ginfo_cfrom_set_2018_248_globalize_ginfo(obj_t env_2620, obj_t obj_2621, obj_t val1474_2622)
{
   return sfun_ginfo_cfrom_set__112_globalize_ginfo((sfun_ginfo_98_t) (obj_2621), val1474_2622);
}


/* sfun/ginfo-cfrom */ obj_t 
sfun_ginfo_cfrom_197_globalize_ginfo(sfun_ginfo_98_t obj_265)
{
   {
      obj_t aux_3587;
      {
	 object_t aux_3588;
	 aux_3588 = (object_t) (obj_265);
	 aux_3587 = OBJECT_WIDENING(aux_3588);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3587))->cfrom);
   }
}


/* _sfun/ginfo-cfrom2019 */ obj_t 
_sfun_ginfo_cfrom2019_6_globalize_ginfo(obj_t env_2623, obj_t obj_2624)
{
   return sfun_ginfo_cfrom_197_globalize_ginfo((sfun_ginfo_98_t) (obj_2624));
}


/* sfun/ginfo-cfrom*-set! */ obj_t 
sfun_ginfo_cfrom__set__37_globalize_ginfo(sfun_ginfo_98_t obj_266, obj_t val1475_267)
{
   {
      obj_t aux_3594;
      {
	 object_t aux_3595;
	 aux_3595 = (object_t) (obj_266);
	 aux_3594 = OBJECT_WIDENING(aux_3595);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3594))->cfrom__119) = ((obj_t) val1475_267), BUNSPEC);
   }
}


/* _sfun/ginfo-cfrom*-set!2020 */ obj_t 
_sfun_ginfo_cfrom__set_2020_255_globalize_ginfo(obj_t env_2625, obj_t obj_2626, obj_t val1475_2627)
{
   return sfun_ginfo_cfrom__set__37_globalize_ginfo((sfun_ginfo_98_t) (obj_2626), val1475_2627);
}


/* sfun/ginfo-cfrom* */ obj_t 
sfun_ginfo_cfrom__184_globalize_ginfo(sfun_ginfo_98_t obj_268)
{
   {
      obj_t aux_3601;
      {
	 object_t aux_3602;
	 aux_3602 = (object_t) (obj_268);
	 aux_3601 = OBJECT_WIDENING(aux_3602);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3601))->cfrom__119);
   }
}


/* _sfun/ginfo-cfrom*2021 */ obj_t 
_sfun_ginfo_cfrom_2021_90_globalize_ginfo(obj_t env_2628, obj_t obj_2629)
{
   return sfun_ginfo_cfrom__184_globalize_ginfo((sfun_ginfo_98_t) (obj_2629));
}


/* sfun/ginfo-cto-set! */ obj_t 
sfun_ginfo_cto_set__23_globalize_ginfo(sfun_ginfo_98_t obj_269, obj_t val1476_270)
{
   {
      obj_t aux_3608;
      {
	 object_t aux_3609;
	 aux_3609 = (object_t) (obj_269);
	 aux_3608 = OBJECT_WIDENING(aux_3609);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3608))->cto) = ((obj_t) val1476_270), BUNSPEC);
   }
}


/* _sfun/ginfo-cto-set!2022 */ obj_t 
_sfun_ginfo_cto_set_2022_194_globalize_ginfo(obj_t env_2630, obj_t obj_2631, obj_t val1476_2632)
{
   return sfun_ginfo_cto_set__23_globalize_ginfo((sfun_ginfo_98_t) (obj_2631), val1476_2632);
}


/* sfun/ginfo-cto */ obj_t 
sfun_ginfo_cto_17_globalize_ginfo(sfun_ginfo_98_t obj_271)
{
   {
      obj_t aux_3615;
      {
	 object_t aux_3616;
	 aux_3616 = (object_t) (obj_271);
	 aux_3615 = OBJECT_WIDENING(aux_3616);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3615))->cto);
   }
}


/* _sfun/ginfo-cto2023 */ obj_t 
_sfun_ginfo_cto2023_156_globalize_ginfo(obj_t env_2633, obj_t obj_2634)
{
   return sfun_ginfo_cto_17_globalize_ginfo((sfun_ginfo_98_t) (obj_2634));
}


/* sfun/ginfo-cto*-set! */ obj_t 
sfun_ginfo_cto__set__57_globalize_ginfo(sfun_ginfo_98_t obj_272, obj_t val1477_273)
{
   {
      obj_t aux_3622;
      {
	 object_t aux_3623;
	 aux_3623 = (object_t) (obj_272);
	 aux_3622 = OBJECT_WIDENING(aux_3623);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3622))->cto__14) = ((obj_t) val1477_273), BUNSPEC);
   }
}


/* _sfun/ginfo-cto*-set!2024 */ obj_t 
_sfun_ginfo_cto__set_2024_109_globalize_ginfo(obj_t env_2635, obj_t obj_2636, obj_t val1477_2637)
{
   return sfun_ginfo_cto__set__57_globalize_ginfo((sfun_ginfo_98_t) (obj_2636), val1477_2637);
}


/* sfun/ginfo-cto* */ obj_t 
sfun_ginfo_cto__157_globalize_ginfo(sfun_ginfo_98_t obj_274)
{
   {
      obj_t aux_3629;
      {
	 object_t aux_3630;
	 aux_3630 = (object_t) (obj_274);
	 aux_3629 = OBJECT_WIDENING(aux_3630);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3629))->cto__14);
   }
}


/* _sfun/ginfo-cto*2025 */ obj_t 
_sfun_ginfo_cto_2025_13_globalize_ginfo(obj_t env_2638, obj_t obj_2639)
{
   return sfun_ginfo_cto__157_globalize_ginfo((sfun_ginfo_98_t) (obj_2639));
}


/* sfun/ginfo-cfunction-set! */ obj_t 
sfun_ginfo_cfunction_set__96_globalize_ginfo(sfun_ginfo_98_t obj_275, obj_t val1478_276)
{
   {
      obj_t aux_3636;
      {
	 object_t aux_3637;
	 aux_3637 = (object_t) (obj_275);
	 aux_3636 = OBJECT_WIDENING(aux_3637);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3636))->cfunction) = ((obj_t) val1478_276), BUNSPEC);
   }
}


/* _sfun/ginfo-cfunction-set!2026 */ obj_t 
_sfun_ginfo_cfunction_set_2026_162_globalize_ginfo(obj_t env_2640, obj_t obj_2641, obj_t val1478_2642)
{
   return sfun_ginfo_cfunction_set__96_globalize_ginfo((sfun_ginfo_98_t) (obj_2641), val1478_2642);
}


/* sfun/ginfo-cfunction */ obj_t 
sfun_ginfo_cfunction_167_globalize_ginfo(sfun_ginfo_98_t obj_277)
{
   {
      obj_t aux_3643;
      {
	 object_t aux_3644;
	 aux_3644 = (object_t) (obj_277);
	 aux_3643 = OBJECT_WIDENING(aux_3644);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3643))->cfunction);
   }
}


/* _sfun/ginfo-cfunction2027 */ obj_t 
_sfun_ginfo_cfunction2027_40_globalize_ginfo(obj_t env_2643, obj_t obj_2644)
{
   return sfun_ginfo_cfunction_167_globalize_ginfo((sfun_ginfo_98_t) (obj_2644));
}


/* sfun/ginfo-integrator-set! */ obj_t 
sfun_ginfo_integrator_set__91_globalize_ginfo(sfun_ginfo_98_t obj_278, obj_t val1479_279)
{
   {
      obj_t aux_3650;
      {
	 object_t aux_3651;
	 aux_3651 = (object_t) (obj_278);
	 aux_3650 = OBJECT_WIDENING(aux_3651);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3650))->integrator) = ((obj_t) val1479_279), BUNSPEC);
   }
}


/* _sfun/ginfo-integrator-set!2028 */ obj_t 
_sfun_ginfo_integrator_set_2028_220_globalize_ginfo(obj_t env_2645, obj_t obj_2646, obj_t val1479_2647)
{
   return sfun_ginfo_integrator_set__91_globalize_ginfo((sfun_ginfo_98_t) (obj_2646), val1479_2647);
}


/* sfun/ginfo-integrator */ obj_t 
sfun_ginfo_integrator_0_globalize_ginfo(sfun_ginfo_98_t obj_280)
{
   {
      obj_t aux_3657;
      {
	 object_t aux_3658;
	 aux_3658 = (object_t) (obj_280);
	 aux_3657 = OBJECT_WIDENING(aux_3658);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3657))->integrator);
   }
}


/* _sfun/ginfo-integrator2029 */ obj_t 
_sfun_ginfo_integrator2029_44_globalize_ginfo(obj_t env_2648, obj_t obj_2649)
{
   return sfun_ginfo_integrator_0_globalize_ginfo((sfun_ginfo_98_t) (obj_2649));
}


/* sfun/ginfo-integrated-set! */ obj_t 
sfun_ginfo_integrated_set__252_globalize_ginfo(sfun_ginfo_98_t obj_281, obj_t val1480_282)
{
   {
      obj_t aux_3664;
      {
	 object_t aux_3665;
	 aux_3665 = (object_t) (obj_281);
	 aux_3664 = OBJECT_WIDENING(aux_3665);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3664))->integrated) = ((obj_t) val1480_282), BUNSPEC);
   }
}


/* _sfun/ginfo-integrated-set!2030 */ obj_t 
_sfun_ginfo_integrated_set_2030_140_globalize_ginfo(obj_t env_2650, obj_t obj_2651, obj_t val1480_2652)
{
   return sfun_ginfo_integrated_set__252_globalize_ginfo((sfun_ginfo_98_t) (obj_2651), val1480_2652);
}


/* sfun/ginfo-integrated */ obj_t 
sfun_ginfo_integrated_166_globalize_ginfo(sfun_ginfo_98_t obj_283)
{
   {
      obj_t aux_3671;
      {
	 object_t aux_3672;
	 aux_3672 = (object_t) (obj_283);
	 aux_3671 = OBJECT_WIDENING(aux_3672);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3671))->integrated);
   }
}


/* _sfun/ginfo-integrated2031 */ obj_t 
_sfun_ginfo_integrated2031_50_globalize_ginfo(obj_t env_2653, obj_t obj_2654)
{
   return sfun_ginfo_integrated_166_globalize_ginfo((sfun_ginfo_98_t) (obj_2654));
}


/* sfun/ginfo-plugged-in-set! */ obj_t 
sfun_ginfo_plugged_in_set__154_globalize_ginfo(sfun_ginfo_98_t obj_284, obj_t val1481_285)
{
   {
      obj_t aux_3678;
      {
	 object_t aux_3679;
	 aux_3679 = (object_t) (obj_284);
	 aux_3678 = OBJECT_WIDENING(aux_3679);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3678))->plugged_in_15) = ((obj_t) val1481_285), BUNSPEC);
   }
}


/* _sfun/ginfo-plugged-in-set!2032 */ obj_t 
_sfun_ginfo_plugged_in_set_2032_201_globalize_ginfo(obj_t env_2655, obj_t obj_2656, obj_t val1481_2657)
{
   return sfun_ginfo_plugged_in_set__154_globalize_ginfo((sfun_ginfo_98_t) (obj_2656), val1481_2657);
}


/* sfun/ginfo-plugged-in */ obj_t 
sfun_ginfo_plugged_in_96_globalize_ginfo(sfun_ginfo_98_t obj_286)
{
   {
      obj_t aux_3685;
      {
	 object_t aux_3686;
	 aux_3686 = (object_t) (obj_286);
	 aux_3685 = OBJECT_WIDENING(aux_3686);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3685))->plugged_in_15);
   }
}


/* _sfun/ginfo-plugged-in2033 */ obj_t 
_sfun_ginfo_plugged_in2033_157_globalize_ginfo(obj_t env_2658, obj_t obj_2659)
{
   return sfun_ginfo_plugged_in_96_globalize_ginfo((sfun_ginfo_98_t) (obj_2659));
}


/* sfun/ginfo-mark-set! */ obj_t 
sfun_ginfo_mark_set__52_globalize_ginfo(sfun_ginfo_98_t obj_287, long val1482_288)
{
   {
      obj_t aux_3692;
      {
	 object_t aux_3693;
	 aux_3693 = (object_t) (obj_287);
	 aux_3692 = OBJECT_WIDENING(aux_3693);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3692))->mark) = ((long) val1482_288), BUNSPEC);
   }
}


/* _sfun/ginfo-mark-set!2034 */ obj_t 
_sfun_ginfo_mark_set_2034_116_globalize_ginfo(obj_t env_2660, obj_t obj_2661, obj_t val1482_2662)
{
   return sfun_ginfo_mark_set__52_globalize_ginfo((sfun_ginfo_98_t) (obj_2661), (long) CINT(val1482_2662));
}


/* sfun/ginfo-mark */ long 
sfun_ginfo_mark_177_globalize_ginfo(sfun_ginfo_98_t obj_289)
{
   {
      obj_t aux_3700;
      {
	 object_t aux_3701;
	 aux_3701 = (object_t) (obj_289);
	 aux_3700 = OBJECT_WIDENING(aux_3701);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3700))->mark);
   }
}


/* _sfun/ginfo-mark2035 */ obj_t 
_sfun_ginfo_mark2035_225_globalize_ginfo(obj_t env_2663, obj_t obj_2664)
{
   {
      long aux_3705;
      aux_3705 = sfun_ginfo_mark_177_globalize_ginfo((sfun_ginfo_98_t) (obj_2664));
      return BINT(aux_3705);
   }
}


/* sfun/ginfo-free-mark-set! */ obj_t 
sfun_ginfo_free_mark_set__121_globalize_ginfo(sfun_ginfo_98_t obj_290, obj_t val1483_291)
{
   {
      obj_t aux_3709;
      {
	 object_t aux_3710;
	 aux_3710 = (object_t) (obj_290);
	 aux_3709 = OBJECT_WIDENING(aux_3710);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3709))->free_mark_81) = ((obj_t) val1483_291), BUNSPEC);
   }
}


/* _sfun/ginfo-free-mark-set!2036 */ obj_t 
_sfun_ginfo_free_mark_set_2036_53_globalize_ginfo(obj_t env_2665, obj_t obj_2666, obj_t val1483_2667)
{
   return sfun_ginfo_free_mark_set__121_globalize_ginfo((sfun_ginfo_98_t) (obj_2666), val1483_2667);
}


/* sfun/ginfo-free-mark */ obj_t 
sfun_ginfo_free_mark_233_globalize_ginfo(sfun_ginfo_98_t obj_292)
{
   {
      obj_t aux_3716;
      {
	 object_t aux_3717;
	 aux_3717 = (object_t) (obj_292);
	 aux_3716 = OBJECT_WIDENING(aux_3717);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3716))->free_mark_81);
   }
}


/* _sfun/ginfo-free-mark2037 */ obj_t 
_sfun_ginfo_free_mark2037_104_globalize_ginfo(obj_t env_2668, obj_t obj_2669)
{
   return sfun_ginfo_free_mark_233_globalize_ginfo((sfun_ginfo_98_t) (obj_2669));
}


/* sfun/ginfo-the-global-set! */ obj_t 
sfun_ginfo_the_global_set__129_globalize_ginfo(sfun_ginfo_98_t obj_293, obj_t val1484_294)
{
   {
      obj_t aux_3723;
      {
	 object_t aux_3724;
	 aux_3724 = (object_t) (obj_293);
	 aux_3723 = OBJECT_WIDENING(aux_3724);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3723))->the_global_201) = ((obj_t) val1484_294), BUNSPEC);
   }
}


/* _sfun/ginfo-the-global-set!2038 */ obj_t 
_sfun_ginfo_the_global_set_2038_246_globalize_ginfo(obj_t env_2670, obj_t obj_2671, obj_t val1484_2672)
{
   return sfun_ginfo_the_global_set__129_globalize_ginfo((sfun_ginfo_98_t) (obj_2671), val1484_2672);
}


/* sfun/ginfo-the-global */ obj_t 
sfun_ginfo_the_global_234_globalize_ginfo(sfun_ginfo_98_t obj_295)
{
   {
      obj_t aux_3730;
      {
	 object_t aux_3731;
	 aux_3731 = (object_t) (obj_295);
	 aux_3730 = OBJECT_WIDENING(aux_3731);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3730))->the_global_201);
   }
}


/* _sfun/ginfo-the-global2039 */ obj_t 
_sfun_ginfo_the_global2039_172_globalize_ginfo(obj_t env_2673, obj_t obj_2674)
{
   return sfun_ginfo_the_global_234_globalize_ginfo((sfun_ginfo_98_t) (obj_2674));
}


/* sfun/ginfo-kaptured-set! */ obj_t 
sfun_ginfo_kaptured_set__247_globalize_ginfo(sfun_ginfo_98_t obj_296, obj_t val1485_297)
{
   {
      obj_t aux_3737;
      {
	 object_t aux_3738;
	 aux_3738 = (object_t) (obj_296);
	 aux_3737 = OBJECT_WIDENING(aux_3738);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3737))->kaptured) = ((obj_t) val1485_297), BUNSPEC);
   }
}


/* _sfun/ginfo-kaptured-set!2040 */ obj_t 
_sfun_ginfo_kaptured_set_2040_243_globalize_ginfo(obj_t env_2675, obj_t obj_2676, obj_t val1485_2677)
{
   return sfun_ginfo_kaptured_set__247_globalize_ginfo((sfun_ginfo_98_t) (obj_2676), val1485_2677);
}


/* sfun/ginfo-kaptured */ obj_t 
sfun_ginfo_kaptured_55_globalize_ginfo(sfun_ginfo_98_t obj_298)
{
   {
      obj_t aux_3744;
      {
	 object_t aux_3745;
	 aux_3745 = (object_t) (obj_298);
	 aux_3744 = OBJECT_WIDENING(aux_3745);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3744))->kaptured);
   }
}


/* _sfun/ginfo-kaptured2041 */ obj_t 
_sfun_ginfo_kaptured2041_71_globalize_ginfo(obj_t env_2678, obj_t obj_2679)
{
   return sfun_ginfo_kaptured_55_globalize_ginfo((sfun_ginfo_98_t) (obj_2679));
}


/* sfun/ginfo-new-body-set! */ obj_t 
sfun_ginfo_new_body_set__157_globalize_ginfo(sfun_ginfo_98_t obj_299, obj_t val1486_300)
{
   {
      obj_t aux_3751;
      {
	 object_t aux_3752;
	 aux_3752 = (object_t) (obj_299);
	 aux_3751 = OBJECT_WIDENING(aux_3752);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3751))->new_body_215) = ((obj_t) val1486_300), BUNSPEC);
   }
}


/* _sfun/ginfo-new-body-set!2042 */ obj_t 
_sfun_ginfo_new_body_set_2042_21_globalize_ginfo(obj_t env_2680, obj_t obj_2681, obj_t val1486_2682)
{
   return sfun_ginfo_new_body_set__157_globalize_ginfo((sfun_ginfo_98_t) (obj_2681), val1486_2682);
}


/* sfun/ginfo-new-body */ obj_t 
sfun_ginfo_new_body_94_globalize_ginfo(sfun_ginfo_98_t obj_301)
{
   {
      obj_t aux_3758;
      {
	 object_t aux_3759;
	 aux_3759 = (object_t) (obj_301);
	 aux_3758 = OBJECT_WIDENING(aux_3759);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3758))->new_body_215);
   }
}


/* _sfun/ginfo-new-body2043 */ obj_t 
_sfun_ginfo_new_body2043_142_globalize_ginfo(obj_t env_2683, obj_t obj_2684)
{
   return sfun_ginfo_new_body_94_globalize_ginfo((sfun_ginfo_98_t) (obj_2684));
}


/* sfun/ginfo-bmark-set! */ obj_t 
sfun_ginfo_bmark_set__251_globalize_ginfo(sfun_ginfo_98_t obj_302, long val1487_303)
{
   {
      obj_t aux_3765;
      {
	 object_t aux_3766;
	 aux_3766 = (object_t) (obj_302);
	 aux_3765 = OBJECT_WIDENING(aux_3766);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3765))->bmark) = ((long) val1487_303), BUNSPEC);
   }
}


/* _sfun/ginfo-bmark-set!2044 */ obj_t 
_sfun_ginfo_bmark_set_2044_58_globalize_ginfo(obj_t env_2685, obj_t obj_2686, obj_t val1487_2687)
{
   return sfun_ginfo_bmark_set__251_globalize_ginfo((sfun_ginfo_98_t) (obj_2686), (long) CINT(val1487_2687));
}


/* sfun/ginfo-bmark */ long 
sfun_ginfo_bmark_99_globalize_ginfo(sfun_ginfo_98_t obj_304)
{
   {
      obj_t aux_3773;
      {
	 object_t aux_3774;
	 aux_3774 = (object_t) (obj_304);
	 aux_3773 = OBJECT_WIDENING(aux_3774);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3773))->bmark);
   }
}


/* _sfun/ginfo-bmark2045 */ obj_t 
_sfun_ginfo_bmark2045_226_globalize_ginfo(obj_t env_2688, obj_t obj_2689)
{
   {
      long aux_3778;
      aux_3778 = sfun_ginfo_bmark_99_globalize_ginfo((sfun_ginfo_98_t) (obj_2689));
      return BINT(aux_3778);
   }
}


/* sfun/ginfo-umark-set! */ obj_t 
sfun_ginfo_umark_set__215_globalize_ginfo(sfun_ginfo_98_t obj_305, long val1488_306)
{
   {
      obj_t aux_3782;
      {
	 object_t aux_3783;
	 aux_3783 = (object_t) (obj_305);
	 aux_3782 = OBJECT_WIDENING(aux_3783);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3782))->umark) = ((long) val1488_306), BUNSPEC);
   }
}


/* _sfun/ginfo-umark-set!2046 */ obj_t 
_sfun_ginfo_umark_set_2046_23_globalize_ginfo(obj_t env_2690, obj_t obj_2691, obj_t val1488_2692)
{
   return sfun_ginfo_umark_set__215_globalize_ginfo((sfun_ginfo_98_t) (obj_2691), (long) CINT(val1488_2692));
}


/* sfun/ginfo-umark */ long 
sfun_ginfo_umark_66_globalize_ginfo(sfun_ginfo_98_t obj_307)
{
   {
      obj_t aux_3790;
      {
	 object_t aux_3791;
	 aux_3791 = (object_t) (obj_307);
	 aux_3790 = OBJECT_WIDENING(aux_3791);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3790))->umark);
   }
}


/* _sfun/ginfo-umark2047 */ obj_t 
_sfun_ginfo_umark2047_231_globalize_ginfo(obj_t env_2693, obj_t obj_2694)
{
   {
      long aux_3795;
      aux_3795 = sfun_ginfo_umark_66_globalize_ginfo((sfun_ginfo_98_t) (obj_2694));
      return BINT(aux_3795);
   }
}


/* sfun/ginfo-free-set! */ obj_t 
sfun_ginfo_free_set__132_globalize_ginfo(sfun_ginfo_98_t obj_308, obj_t val1489_309)
{
   {
      obj_t aux_3799;
      {
	 object_t aux_3800;
	 aux_3800 = (object_t) (obj_308);
	 aux_3799 = OBJECT_WIDENING(aux_3800);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3799))->free) = ((obj_t) val1489_309), BUNSPEC);
   }
}


/* _sfun/ginfo-free-set!2048 */ obj_t 
_sfun_ginfo_free_set_2048_178_globalize_ginfo(obj_t env_2695, obj_t obj_2696, obj_t val1489_2697)
{
   return sfun_ginfo_free_set__132_globalize_ginfo((sfun_ginfo_98_t) (obj_2696), val1489_2697);
}


/* sfun/ginfo-free */ obj_t 
sfun_ginfo_free_174_globalize_ginfo(sfun_ginfo_98_t obj_310)
{
   {
      obj_t aux_3806;
      {
	 object_t aux_3807;
	 aux_3807 = (object_t) (obj_310);
	 aux_3806 = OBJECT_WIDENING(aux_3807);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3806))->free);
   }
}


/* _sfun/ginfo-free2049 */ obj_t 
_sfun_ginfo_free2049_252_globalize_ginfo(obj_t env_2698, obj_t obj_2699)
{
   return sfun_ginfo_free_174_globalize_ginfo((sfun_ginfo_98_t) (obj_2699));
}


/* sfun/ginfo-bound-set! */ obj_t 
sfun_ginfo_bound_set__10_globalize_ginfo(sfun_ginfo_98_t obj_311, obj_t val1490_312)
{
   {
      obj_t aux_3813;
      {
	 object_t aux_3814;
	 aux_3814 = (object_t) (obj_311);
	 aux_3813 = OBJECT_WIDENING(aux_3814);
      }
      return ((((sfun_ginfo_98_t) CREF(aux_3813))->bound) = ((obj_t) val1490_312), BUNSPEC);
   }
}


/* _sfun/ginfo-bound-set!2050 */ obj_t 
_sfun_ginfo_bound_set_2050_128_globalize_ginfo(obj_t env_2700, obj_t obj_2701, obj_t val1490_2702)
{
   return sfun_ginfo_bound_set__10_globalize_ginfo((sfun_ginfo_98_t) (obj_2701), val1490_2702);
}


/* sfun/ginfo-bound */ obj_t 
sfun_ginfo_bound_35_globalize_ginfo(sfun_ginfo_98_t obj_313)
{
   {
      obj_t aux_3820;
      {
	 object_t aux_3821;
	 aux_3821 = (object_t) (obj_313);
	 aux_3820 = OBJECT_WIDENING(aux_3821);
      }
      return (((sfun_ginfo_98_t) CREF(aux_3820))->bound);
   }
}


/* _sfun/ginfo-bound2051 */ obj_t 
_sfun_ginfo_bound2051_125_globalize_ginfo(obj_t env_2703, obj_t obj_2704)
{
   return sfun_ginfo_bound_35_globalize_ginfo((sfun_ginfo_98_t) (obj_2704));
}


/* method-init */ obj_t 
method_init_76_globalize_ginfo()
{
   {
      obj_t object__struct_global_ginfo_101_2719;
      object__struct_global_ginfo_101_2719 = proc2057_globalize_ginfo;
      add_method__1___object(object__struct_env_210___object, global_ginfo_75_globalize_ginfo, object__struct_global_ginfo_101_2719);
   }
   {
      obj_t struct_object__object_global_ginfo_231_2718;
      struct_object__object_global_ginfo_231_2718 = proc2058_globalize_ginfo;
      add_method__1___object(struct_object__object_env_209___object, global_ginfo_75_globalize_ginfo, struct_object__object_global_ginfo_231_2718);
   }
   {
      obj_t object__struct_local_ginfo_71_2717;
      object__struct_local_ginfo_71_2717 = proc2059_globalize_ginfo;
      add_method__1___object(object__struct_env_210___object, local_ginfo_108_globalize_ginfo, object__struct_local_ginfo_71_2717);
   }
   {
      obj_t struct_object__object_local_ginfo_129_2716;
      struct_object__object_local_ginfo_129_2716 = proc2060_globalize_ginfo;
      add_method__1___object(struct_object__object_env_209___object, local_ginfo_108_globalize_ginfo, struct_object__object_local_ginfo_129_2716);
   }
   {
      obj_t object__struct_sexit_ginfo_51_2715;
      object__struct_sexit_ginfo_51_2715 = proc2061_globalize_ginfo;
      add_method__1___object(object__struct_env_210___object, sexit_ginfo_81_globalize_ginfo, object__struct_sexit_ginfo_51_2715);
   }
   {
      obj_t struct_object__object_sexit_ginfo_170_2714;
      struct_object__object_sexit_ginfo_170_2714 = proc2062_globalize_ginfo;
      add_method__1___object(struct_object__object_env_209___object, sexit_ginfo_81_globalize_ginfo, struct_object__object_sexit_ginfo_170_2714);
   }
   {
      obj_t object__struct_svar_ginfo_152_2713;
      object__struct_svar_ginfo_152_2713 = proc2063_globalize_ginfo;
      add_method__1___object(object__struct_env_210___object, svar_ginfo_131_globalize_ginfo, object__struct_svar_ginfo_152_2713);
   }
   {
      obj_t struct_object__object_svar_ginfo_79_2712;
      struct_object__object_svar_ginfo_79_2712 = proc2064_globalize_ginfo;
      add_method__1___object(struct_object__object_env_209___object, svar_ginfo_131_globalize_ginfo, struct_object__object_svar_ginfo_79_2712);
   }
   {
      obj_t object__struct_sfun_ginfo_180_2709;
      object__struct_sfun_ginfo_180_2709 = proc2065_globalize_ginfo;
      add_method__1___object(object__struct_env_210___object, sfun_ginfo_98_globalize_ginfo, object__struct_sfun_ginfo_180_2709);
   }
   {
      obj_t struct_object__object_sfun_ginfo_84_2705;
      struct_object__object_sfun_ginfo_84_2705 = proc2066_globalize_ginfo;
      return add_method__1___object(struct_object__object_env_209___object, sfun_ginfo_98_globalize_ginfo, struct_object__object_sfun_ginfo_84_2705);
   }
}


/* struct+object->object-sfun/ginfo */ obj_t 
struct_object__object_sfun_ginfo_84_globalize_ginfo(obj_t env_2720, obj_t o_2721, obj_t s_2722)
{
   {
      sfun_ginfo_98_t o_1582;
      obj_t s_1583;
      {
	 sfun_ginfo_98_t aux_3837;
	 o_1582 = (sfun_ginfo_98_t) (o_2721);
	 s_1583 = s_2722;
	 {
	    {
	       obj_t old1496_1586;
	       obj_t aux1497_1587;
	       {
		  obj_t next_method1606_175_1609;
		  next_method1606_175_1609 = find_super_class_method_167___object((object_t) (o_1582), struct_object__object_env_209___object, sfun_ginfo_98_globalize_ginfo);
		  if (PROCEDUREP(next_method1606_175_1609))
		    {
		       old1496_1586 = PROCEDURE_ENTRY(next_method1606_175_1609) (next_method1606_175_1609, (obj_t) (o_1582), s_1583, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1606_175_1609);
		       {
			  object_t aux_3846;
			  aux_3846 = struct_object__object_93___object((object_t) (o_1582), s_1583);
			  old1496_1586 = (obj_t) (aux_3846);
		       }
		    }
	       }
	       aux1497_1587 = STRUCT_REF(s_1583, ((long) 0));
	       {
		  sfun_ginfo_98_t new1498_1588;
		  new1498_1588 = ((sfun_ginfo_98_t) (old1496_1586));
		  {
		     long arg1871_1589;
		     arg1871_1589 = class_num_218___object(sfun_ginfo_98_globalize_ginfo);
		     {
			obj_t obj_2177;
			obj_2177 = (obj_t) (new1498_1588);
			(((obj_t) CREF(obj_2177))->header = MAKE_HEADER(arg1871_1589, 0), BUNSPEC);
		     }
		  }
		  {
		     sfun_ginfo_98_t arg1874_1590;
		     {
			obj_t arg1876_1592;
			obj_t arg1877_1593;
			obj_t arg1878_1594;
			obj_t arg1879_1595;
			obj_t arg1880_1596;
			obj_t arg1881_1597;
			obj_t arg1883_1598;
			obj_t arg1884_1599;
			obj_t arg1886_1601;
			obj_t arg1887_1602;
			obj_t arg1888_1603;
			obj_t arg1890_1604;
			obj_t arg1894_1607;
			obj_t arg1895_1608;
			arg1876_1592 = STRUCT_REF(aux1497_1587, ((long) 1));
			arg1877_1593 = STRUCT_REF(aux1497_1587, ((long) 2));
			arg1878_1594 = STRUCT_REF(aux1497_1587, ((long) 3));
			arg1879_1595 = STRUCT_REF(aux1497_1587, ((long) 4));
			arg1880_1596 = STRUCT_REF(aux1497_1587, ((long) 5));
			arg1881_1597 = STRUCT_REF(aux1497_1587, ((long) 6));
			arg1883_1598 = STRUCT_REF(aux1497_1587, ((long) 7));
			arg1884_1599 = STRUCT_REF(aux1497_1587, ((long) 8));
			arg1886_1601 = STRUCT_REF(aux1497_1587, ((long) 10));
			arg1887_1602 = STRUCT_REF(aux1497_1587, ((long) 11));
			arg1888_1603 = STRUCT_REF(aux1497_1587, ((long) 12));
			arg1890_1604 = STRUCT_REF(aux1497_1587, ((long) 13));
			arg1894_1607 = STRUCT_REF(aux1497_1587, ((long) 16));
			arg1895_1608 = STRUCT_REF(aux1497_1587, ((long) 17));
			{
			   sfun_ginfo_98_t res1911_2252;
			   {
			      bool_t g__219_2215;
			      long mark_2224;
			      long bmark_2229;
			      long umark_2230;
			      {
				 obj_t aux_3869;
				 aux_3869 = STRUCT_REF(aux1497_1587, ((long) 0));
				 g__219_2215 = CBOOL(aux_3869);
			      }
			      {
				 obj_t aux_3872;
				 aux_3872 = STRUCT_REF(aux1497_1587, ((long) 9));
				 mark_2224 = (long) CINT(aux_3872);
			      }
			      {
				 obj_t aux_3875;
				 aux_3875 = STRUCT_REF(aux1497_1587, ((long) 14));
				 bmark_2229 = (long) CINT(aux_3875);
			      }
			      {
				 obj_t aux_3878;
				 aux_3878 = STRUCT_REF(aux1497_1587, ((long) 15));
				 umark_2230 = (long) CINT(aux_3878);
			      }
			      {
				 sfun_ginfo_98_t new1440_2233;
				 new1440_2233 = ((sfun_ginfo_98_t) BREF(GC_MALLOC(sizeof(struct sfun_ginfo_98))));
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->g__219) = ((bool_t) g__219_2215), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->cfrom) = ((obj_t) arg1876_1592), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->cfrom__119) = ((obj_t) arg1877_1593), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->cto) = ((obj_t) arg1878_1594), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->cto__14) = ((obj_t) arg1879_1595), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->cfunction) = ((obj_t) arg1880_1596), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->integrator) = ((obj_t) arg1881_1597), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->integrated) = ((obj_t) arg1883_1598), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->plugged_in_15) = ((obj_t) arg1884_1599), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->mark) = ((long) mark_2224), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->free_mark_81) = ((obj_t) arg1886_1601), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->the_global_201) = ((obj_t) arg1887_1602), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->kaptured) = ((obj_t) arg1888_1603), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->new_body_215) = ((obj_t) arg1890_1604), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->bmark) = ((long) bmark_2229), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->umark) = ((long) umark_2230), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->free) = ((obj_t) arg1894_1607), BUNSPEC);
				 ((((sfun_ginfo_98_t) CREF(new1440_2233))->bound) = ((obj_t) arg1895_1608), BUNSPEC);
				 res1911_2252 = new1440_2233;
			      }
			   }
			   arg1874_1590 = res1911_2252;
			}
		     }
		     {
			obj_t aux_3902;
			object_t aux_3900;
			aux_3902 = (obj_t) (arg1874_1590);
			aux_3900 = (object_t) (new1498_1588);
			OBJECT_WIDENING_SET(aux_3900, aux_3902);
		     }
		  }
		  aux_3837 = new1498_1588;
	       }
	    }
	 }
	 return (obj_t) (aux_3837);
      }
   }
}


/* object->struct-sfun/ginfo */ obj_t 
object__struct_sfun_ginfo_180_globalize_ginfo(obj_t env_2723, obj_t obj1493_2724)
{
   {
      sfun_ginfo_98_t obj1493_1535;
      obj1493_1535 = (sfun_ginfo_98_t) (obj1493_2724);
      {
	 {
	    obj_t res1494_1538;
	    {
	       obj_t next_method1605_99_1580;
	       next_method1605_99_1580 = find_super_class_method_167___object((object_t) (obj1493_1535), object__struct_env_210___object, sfun_ginfo_98_globalize_ginfo);
	       if (PROCEDUREP(next_method1605_99_1580))
		 {
		    res1494_1538 = PROCEDURE_ENTRY(next_method1605_99_1580) (next_method1605_99_1580, (obj_t) (obj1493_1535), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1605_99_1580);
		    res1494_1538 = object__struct_50___object((object_t) (obj1493_1535));
		 }
	    }
	    {
	       obj_t aux1495_1539;
	       {
		  obj_t aux_3917;
		  aux_3917 = CNST_TABLE_REF(((long) 0));
		  aux1495_1539 = make_struct(aux_3917, ((long) 18), BUNSPEC);
	       }
	       {
		  obj_t aux_3920;
		  {
		     bool_t aux_3921;
		     {
			obj_t aux_3922;
			{
			   object_t aux_3923;
			   aux_3923 = (object_t) (obj1493_1535);
			   aux_3922 = OBJECT_WIDENING(aux_3923);
			}
			aux_3921 = (((sfun_ginfo_98_t) CREF(aux_3922))->g__219);
		     }
		     aux_3920 = BBOOL(aux_3921);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 0), aux_3920);
	       }
	       {
		  obj_t aux_3929;
		  {
		     obj_t aux_3930;
		     {
			object_t aux_3931;
			aux_3931 = (object_t) (obj1493_1535);
			aux_3930 = OBJECT_WIDENING(aux_3931);
		     }
		     aux_3929 = (((sfun_ginfo_98_t) CREF(aux_3930))->cfrom);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 1), aux_3929);
	       }
	       {
		  obj_t aux_3936;
		  {
		     obj_t aux_3937;
		     {
			object_t aux_3938;
			aux_3938 = (object_t) (obj1493_1535);
			aux_3937 = OBJECT_WIDENING(aux_3938);
		     }
		     aux_3936 = (((sfun_ginfo_98_t) CREF(aux_3937))->cfrom__119);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 2), aux_3936);
	       }
	       {
		  obj_t aux_3943;
		  {
		     obj_t aux_3944;
		     {
			object_t aux_3945;
			aux_3945 = (object_t) (obj1493_1535);
			aux_3944 = OBJECT_WIDENING(aux_3945);
		     }
		     aux_3943 = (((sfun_ginfo_98_t) CREF(aux_3944))->cto);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 3), aux_3943);
	       }
	       {
		  obj_t aux_3950;
		  {
		     obj_t aux_3951;
		     {
			object_t aux_3952;
			aux_3952 = (object_t) (obj1493_1535);
			aux_3951 = OBJECT_WIDENING(aux_3952);
		     }
		     aux_3950 = (((sfun_ginfo_98_t) CREF(aux_3951))->cto__14);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 4), aux_3950);
	       }
	       {
		  obj_t aux_3957;
		  {
		     obj_t aux_3958;
		     {
			object_t aux_3959;
			aux_3959 = (object_t) (obj1493_1535);
			aux_3958 = OBJECT_WIDENING(aux_3959);
		     }
		     aux_3957 = (((sfun_ginfo_98_t) CREF(aux_3958))->cfunction);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 5), aux_3957);
	       }
	       {
		  obj_t aux_3964;
		  {
		     obj_t aux_3965;
		     {
			object_t aux_3966;
			aux_3966 = (object_t) (obj1493_1535);
			aux_3965 = OBJECT_WIDENING(aux_3966);
		     }
		     aux_3964 = (((sfun_ginfo_98_t) CREF(aux_3965))->integrator);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 6), aux_3964);
	       }
	       {
		  obj_t aux_3971;
		  {
		     obj_t aux_3972;
		     {
			object_t aux_3973;
			aux_3973 = (object_t) (obj1493_1535);
			aux_3972 = OBJECT_WIDENING(aux_3973);
		     }
		     aux_3971 = (((sfun_ginfo_98_t) CREF(aux_3972))->integrated);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 7), aux_3971);
	       }
	       {
		  obj_t aux_3978;
		  {
		     obj_t aux_3979;
		     {
			object_t aux_3980;
			aux_3980 = (object_t) (obj1493_1535);
			aux_3979 = OBJECT_WIDENING(aux_3980);
		     }
		     aux_3978 = (((sfun_ginfo_98_t) CREF(aux_3979))->plugged_in_15);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 8), aux_3978);
	       }
	       {
		  obj_t aux_3985;
		  {
		     long aux_3986;
		     {
			obj_t aux_3987;
			{
			   object_t aux_3988;
			   aux_3988 = (object_t) (obj1493_1535);
			   aux_3987 = OBJECT_WIDENING(aux_3988);
			}
			aux_3986 = (((sfun_ginfo_98_t) CREF(aux_3987))->mark);
		     }
		     aux_3985 = BINT(aux_3986);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 9), aux_3985);
	       }
	       {
		  obj_t aux_3994;
		  {
		     obj_t aux_3995;
		     {
			object_t aux_3996;
			aux_3996 = (object_t) (obj1493_1535);
			aux_3995 = OBJECT_WIDENING(aux_3996);
		     }
		     aux_3994 = (((sfun_ginfo_98_t) CREF(aux_3995))->free_mark_81);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 10), aux_3994);
	       }
	       {
		  obj_t aux_4001;
		  {
		     obj_t aux_4002;
		     {
			object_t aux_4003;
			aux_4003 = (object_t) (obj1493_1535);
			aux_4002 = OBJECT_WIDENING(aux_4003);
		     }
		     aux_4001 = (((sfun_ginfo_98_t) CREF(aux_4002))->the_global_201);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 11), aux_4001);
	       }
	       {
		  obj_t aux_4008;
		  {
		     obj_t aux_4009;
		     {
			object_t aux_4010;
			aux_4010 = (object_t) (obj1493_1535);
			aux_4009 = OBJECT_WIDENING(aux_4010);
		     }
		     aux_4008 = (((sfun_ginfo_98_t) CREF(aux_4009))->kaptured);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 12), aux_4008);
	       }
	       {
		  obj_t aux_4015;
		  {
		     obj_t aux_4016;
		     {
			object_t aux_4017;
			aux_4017 = (object_t) (obj1493_1535);
			aux_4016 = OBJECT_WIDENING(aux_4017);
		     }
		     aux_4015 = (((sfun_ginfo_98_t) CREF(aux_4016))->new_body_215);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 13), aux_4015);
	       }
	       {
		  obj_t aux_4022;
		  {
		     long aux_4023;
		     {
			obj_t aux_4024;
			{
			   object_t aux_4025;
			   aux_4025 = (object_t) (obj1493_1535);
			   aux_4024 = OBJECT_WIDENING(aux_4025);
			}
			aux_4023 = (((sfun_ginfo_98_t) CREF(aux_4024))->bmark);
		     }
		     aux_4022 = BINT(aux_4023);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 14), aux_4022);
	       }
	       {
		  obj_t aux_4031;
		  {
		     long aux_4032;
		     {
			obj_t aux_4033;
			{
			   object_t aux_4034;
			   aux_4034 = (object_t) (obj1493_1535);
			   aux_4033 = OBJECT_WIDENING(aux_4034);
			}
			aux_4032 = (((sfun_ginfo_98_t) CREF(aux_4033))->umark);
		     }
		     aux_4031 = BINT(aux_4032);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 15), aux_4031);
	       }
	       {
		  obj_t aux_4040;
		  {
		     obj_t aux_4041;
		     {
			object_t aux_4042;
			aux_4042 = (object_t) (obj1493_1535);
			aux_4041 = OBJECT_WIDENING(aux_4042);
		     }
		     aux_4040 = (((sfun_ginfo_98_t) CREF(aux_4041))->free);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 16), aux_4040);
	       }
	       {
		  obj_t aux_4047;
		  {
		     obj_t aux_4048;
		     {
			object_t aux_4049;
			aux_4049 = (object_t) (obj1493_1535);
			aux_4048 = OBJECT_WIDENING(aux_4049);
		     }
		     aux_4047 = (((sfun_ginfo_98_t) CREF(aux_4048))->bound);
		  }
		  STRUCT_SET(aux1495_1539, ((long) 17), aux_4047);
	       }
	       STRUCT_SET(res1494_1538, ((long) 0), aux1495_1539);
	       {
		  obj_t aux_4055;
		  aux_4055 = STRUCT_KEY(res1494_1538);
		  STRUCT_KEY_SET(aux1495_1539, aux_4055);
	       }
	       {
		  obj_t aux_4058;
		  aux_4058 = CNST_TABLE_REF(((long) 0));
		  STRUCT_KEY_SET(res1494_1538, aux_4058);
	       }
	       return res1494_1538;
	    }
	 }
      }
   }
}


/* struct+object->object-svar/ginfo */ obj_t 
struct_object__object_svar_ginfo_79_globalize_ginfo(obj_t env_2725, obj_t o_2726, obj_t s_2727)
{
   {
      svar_ginfo_131_t o_1520;
      obj_t s_1521;
      {
	 svar_ginfo_131_t aux_4062;
	 o_1520 = (svar_ginfo_131_t) (o_2726);
	 s_1521 = s_2727;
	 {
	    {
	       obj_t old1516_1524;
	       obj_t aux1517_1525;
	       {
		  obj_t next_method1604_100_1533;
		  next_method1604_100_1533 = find_super_class_method_167___object((object_t) (o_1520), struct_object__object_env_209___object, svar_ginfo_131_globalize_ginfo);
		  if (PROCEDUREP(next_method1604_100_1533))
		    {
		       old1516_1524 = PROCEDURE_ENTRY(next_method1604_100_1533) (next_method1604_100_1533, (obj_t) (o_1520), s_1521, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1604_100_1533);
		       {
			  object_t aux_4071;
			  aux_4071 = struct_object__object_93___object((object_t) (o_1520), s_1521);
			  old1516_1524 = (obj_t) (aux_4071);
		       }
		    }
	       }
	       aux1517_1525 = STRUCT_REF(s_1521, ((long) 0));
	       {
		  svar_ginfo_131_t new1518_1526;
		  new1518_1526 = ((svar_ginfo_131_t) (old1516_1524));
		  {
		     long arg1813_1527;
		     arg1813_1527 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
		     {
			obj_t obj_2068;
			obj_2068 = (obj_t) (new1518_1526);
			(((obj_t) CREF(obj_2068))->header = MAKE_HEADER(arg1813_1527, 0), BUNSPEC);
		     }
		  }
		  {
		     svar_ginfo_131_t arg1814_1528;
		     {
			svar_ginfo_131_t res1910_2087;
			{
			   bool_t kaptured__204_2078;
			   long free_mark_81_2079;
			   long mark_2080;
			   bool_t celled__113_2081;
			   {
			      obj_t aux_4080;
			      aux_4080 = STRUCT_REF(aux1517_1525, ((long) 0));
			      kaptured__204_2078 = CBOOL(aux_4080);
			   }
			   {
			      obj_t aux_4083;
			      aux_4083 = STRUCT_REF(aux1517_1525, ((long) 1));
			      free_mark_81_2079 = (long) CINT(aux_4083);
			   }
			   {
			      obj_t aux_4086;
			      aux_4086 = STRUCT_REF(aux1517_1525, ((long) 2));
			      mark_2080 = (long) CINT(aux_4086);
			   }
			   {
			      obj_t aux_4089;
			      aux_4089 = STRUCT_REF(aux1517_1525, ((long) 3));
			      celled__113_2081 = CBOOL(aux_4089);
			   }
			   {
			      svar_ginfo_131_t new1499_2082;
			      new1499_2082 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
			      ((((svar_ginfo_131_t) CREF(new1499_2082))->kaptured__204) = ((bool_t) kaptured__204_2078), BUNSPEC);
			      ((((svar_ginfo_131_t) CREF(new1499_2082))->free_mark_81) = ((long) free_mark_81_2079), BUNSPEC);
			      ((((svar_ginfo_131_t) CREF(new1499_2082))->mark) = ((long) mark_2080), BUNSPEC);
			      ((((svar_ginfo_131_t) CREF(new1499_2082))->celled__113) = ((bool_t) celled__113_2081), BUNSPEC);
			      res1910_2087 = new1499_2082;
			   }
			}
			arg1814_1528 = res1910_2087;
		     }
		     {
			obj_t aux_4099;
			object_t aux_4097;
			aux_4099 = (obj_t) (arg1814_1528);
			aux_4097 = (object_t) (new1518_1526);
			OBJECT_WIDENING_SET(aux_4097, aux_4099);
		     }
		  }
		  aux_4062 = new1518_1526;
	       }
	    }
	 }
	 return (obj_t) (aux_4062);
      }
   }
}


/* object->struct-svar/ginfo */ obj_t 
object__struct_svar_ginfo_152_globalize_ginfo(obj_t env_2728, obj_t obj1513_2729)
{
   {
      svar_ginfo_131_t obj1513_1501;
      obj1513_1501 = (svar_ginfo_131_t) (obj1513_2729);
      {
	 {
	    obj_t res1514_1504;
	    {
	       obj_t next_method1603_80_1518;
	       next_method1603_80_1518 = find_super_class_method_167___object((object_t) (obj1513_1501), object__struct_env_210___object, svar_ginfo_131_globalize_ginfo);
	       if (PROCEDUREP(next_method1603_80_1518))
		 {
		    res1514_1504 = PROCEDURE_ENTRY(next_method1603_80_1518) (next_method1603_80_1518, (obj_t) (obj1513_1501), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1603_80_1518);
		    res1514_1504 = object__struct_50___object((object_t) (obj1513_1501));
		 }
	    }
	    {
	       obj_t aux1515_1505;
	       {
		  obj_t aux_4114;
		  aux_4114 = CNST_TABLE_REF(((long) 1));
		  aux1515_1505 = make_struct(aux_4114, ((long) 4), BUNSPEC);
	       }
	       {
		  obj_t aux_4117;
		  {
		     bool_t aux_4118;
		     {
			obj_t aux_4119;
			{
			   object_t aux_4120;
			   aux_4120 = (object_t) (obj1513_1501);
			   aux_4119 = OBJECT_WIDENING(aux_4120);
			}
			aux_4118 = (((svar_ginfo_131_t) CREF(aux_4119))->kaptured__204);
		     }
		     aux_4117 = BBOOL(aux_4118);
		  }
		  STRUCT_SET(aux1515_1505, ((long) 0), aux_4117);
	       }
	       {
		  obj_t aux_4126;
		  {
		     long aux_4127;
		     {
			obj_t aux_4128;
			{
			   object_t aux_4129;
			   aux_4129 = (object_t) (obj1513_1501);
			   aux_4128 = OBJECT_WIDENING(aux_4129);
			}
			aux_4127 = (((svar_ginfo_131_t) CREF(aux_4128))->free_mark_81);
		     }
		     aux_4126 = BINT(aux_4127);
		  }
		  STRUCT_SET(aux1515_1505, ((long) 1), aux_4126);
	       }
	       {
		  obj_t aux_4135;
		  {
		     long aux_4136;
		     {
			obj_t aux_4137;
			{
			   object_t aux_4138;
			   aux_4138 = (object_t) (obj1513_1501);
			   aux_4137 = OBJECT_WIDENING(aux_4138);
			}
			aux_4136 = (((svar_ginfo_131_t) CREF(aux_4137))->mark);
		     }
		     aux_4135 = BINT(aux_4136);
		  }
		  STRUCT_SET(aux1515_1505, ((long) 2), aux_4135);
	       }
	       {
		  obj_t aux_4144;
		  {
		     bool_t aux_4145;
		     {
			obj_t aux_4146;
			{
			   object_t aux_4147;
			   aux_4147 = (object_t) (obj1513_1501);
			   aux_4146 = OBJECT_WIDENING(aux_4147);
			}
			aux_4145 = (((svar_ginfo_131_t) CREF(aux_4146))->celled__113);
		     }
		     aux_4144 = BBOOL(aux_4145);
		  }
		  STRUCT_SET(aux1515_1505, ((long) 3), aux_4144);
	       }
	       STRUCT_SET(res1514_1504, ((long) 0), aux1515_1505);
	       {
		  obj_t aux_4154;
		  aux_4154 = STRUCT_KEY(res1514_1504);
		  STRUCT_KEY_SET(aux1515_1505, aux_4154);
	       }
	       {
		  obj_t aux_4157;
		  aux_4157 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1514_1504, aux_4157);
	       }
	       return res1514_1504;
	    }
	 }
      }
   }
}


/* struct+object->object-sexit/ginfo */ obj_t 
struct_object__object_sexit_ginfo_170_globalize_ginfo(obj_t env_2730, obj_t o_2731, obj_t s_2732)
{
   {
      sexit_ginfo_81_t o_1486;
      obj_t s_1487;
      {
	 sexit_ginfo_81_t aux_4161;
	 o_1486 = (sexit_ginfo_81_t) (o_2731);
	 s_1487 = s_2732;
	 {
	    {
	       obj_t old1537_1490;
	       obj_t aux1538_1491;
	       {
		  obj_t next_method1602_166_1499;
		  next_method1602_166_1499 = find_super_class_method_167___object((object_t) (o_1486), struct_object__object_env_209___object, sexit_ginfo_81_globalize_ginfo);
		  if (PROCEDUREP(next_method1602_166_1499))
		    {
		       old1537_1490 = PROCEDURE_ENTRY(next_method1602_166_1499) (next_method1602_166_1499, (obj_t) (o_1486), s_1487, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1602_166_1499);
		       {
			  object_t aux_4170;
			  aux_4170 = struct_object__object_93___object((object_t) (o_1486), s_1487);
			  old1537_1490 = (obj_t) (aux_4170);
		       }
		    }
	       }
	       aux1538_1491 = STRUCT_REF(s_1487, ((long) 0));
	       {
		  sexit_ginfo_81_t new1539_1492;
		  new1539_1492 = ((sexit_ginfo_81_t) (old1537_1490));
		  {
		     long arg1792_1493;
		     arg1792_1493 = class_num_218___object(sexit_ginfo_81_globalize_ginfo);
		     {
			obj_t obj_2015;
			obj_2015 = (obj_t) (new1539_1492);
			(((obj_t) CREF(obj_2015))->header = MAKE_HEADER(arg1792_1493, 0), BUNSPEC);
		     }
		  }
		  {
		     sexit_ginfo_81_t arg1793_1494;
		     {
			sexit_ginfo_81_t res1909_2034;
			{
			   bool_t g__219_2025;
			   bool_t kaptured__204_2026;
			   long free_mark_81_2027;
			   long mark_2028;
			   {
			      obj_t aux_4179;
			      aux_4179 = STRUCT_REF(aux1538_1491, ((long) 0));
			      g__219_2025 = CBOOL(aux_4179);
			   }
			   {
			      obj_t aux_4182;
			      aux_4182 = STRUCT_REF(aux1538_1491, ((long) 1));
			      kaptured__204_2026 = CBOOL(aux_4182);
			   }
			   {
			      obj_t aux_4185;
			      aux_4185 = STRUCT_REF(aux1538_1491, ((long) 2));
			      free_mark_81_2027 = (long) CINT(aux_4185);
			   }
			   {
			      obj_t aux_4188;
			      aux_4188 = STRUCT_REF(aux1538_1491, ((long) 3));
			      mark_2028 = (long) CINT(aux_4188);
			   }
			   {
			      sexit_ginfo_81_t new1519_2029;
			      new1519_2029 = ((sexit_ginfo_81_t) BREF(GC_MALLOC(sizeof(struct sexit_ginfo_81))));
			      ((((sexit_ginfo_81_t) CREF(new1519_2029))->g__219) = ((bool_t) g__219_2025), BUNSPEC);
			      ((((sexit_ginfo_81_t) CREF(new1519_2029))->kaptured__204) = ((bool_t) kaptured__204_2026), BUNSPEC);
			      ((((sexit_ginfo_81_t) CREF(new1519_2029))->free_mark_81) = ((long) free_mark_81_2027), BUNSPEC);
			      ((((sexit_ginfo_81_t) CREF(new1519_2029))->mark) = ((long) mark_2028), BUNSPEC);
			      res1909_2034 = new1519_2029;
			   }
			}
			arg1793_1494 = res1909_2034;
		     }
		     {
			obj_t aux_4198;
			object_t aux_4196;
			aux_4198 = (obj_t) (arg1793_1494);
			aux_4196 = (object_t) (new1539_1492);
			OBJECT_WIDENING_SET(aux_4196, aux_4198);
		     }
		  }
		  aux_4161 = new1539_1492;
	       }
	    }
	 }
	 return (obj_t) (aux_4161);
      }
   }
}


/* object->struct-sexit/ginfo */ obj_t 
object__struct_sexit_ginfo_51_globalize_ginfo(obj_t env_2733, obj_t obj1534_2734)
{
   {
      sexit_ginfo_81_t obj1534_1467;
      obj1534_1467 = (sexit_ginfo_81_t) (obj1534_2734);
      {
	 {
	    obj_t res1535_1470;
	    {
	       obj_t next_method1601_34_1484;
	       next_method1601_34_1484 = find_super_class_method_167___object((object_t) (obj1534_1467), object__struct_env_210___object, sexit_ginfo_81_globalize_ginfo);
	       if (PROCEDUREP(next_method1601_34_1484))
		 {
		    res1535_1470 = PROCEDURE_ENTRY(next_method1601_34_1484) (next_method1601_34_1484, (obj_t) (obj1534_1467), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1601_34_1484);
		    res1535_1470 = object__struct_50___object((object_t) (obj1534_1467));
		 }
	    }
	    {
	       obj_t aux1536_1471;
	       {
		  obj_t aux_4213;
		  aux_4213 = CNST_TABLE_REF(((long) 2));
		  aux1536_1471 = make_struct(aux_4213, ((long) 4), BUNSPEC);
	       }
	       {
		  obj_t aux_4216;
		  {
		     bool_t aux_4217;
		     {
			obj_t aux_4218;
			{
			   object_t aux_4219;
			   aux_4219 = (object_t) (obj1534_1467);
			   aux_4218 = OBJECT_WIDENING(aux_4219);
			}
			aux_4217 = (((sexit_ginfo_81_t) CREF(aux_4218))->g__219);
		     }
		     aux_4216 = BBOOL(aux_4217);
		  }
		  STRUCT_SET(aux1536_1471, ((long) 0), aux_4216);
	       }
	       {
		  obj_t aux_4225;
		  {
		     bool_t aux_4226;
		     {
			obj_t aux_4227;
			{
			   object_t aux_4228;
			   aux_4228 = (object_t) (obj1534_1467);
			   aux_4227 = OBJECT_WIDENING(aux_4228);
			}
			aux_4226 = (((sexit_ginfo_81_t) CREF(aux_4227))->kaptured__204);
		     }
		     aux_4225 = BBOOL(aux_4226);
		  }
		  STRUCT_SET(aux1536_1471, ((long) 1), aux_4225);
	       }
	       {
		  obj_t aux_4234;
		  {
		     long aux_4235;
		     {
			obj_t aux_4236;
			{
			   object_t aux_4237;
			   aux_4237 = (object_t) (obj1534_1467);
			   aux_4236 = OBJECT_WIDENING(aux_4237);
			}
			aux_4235 = (((sexit_ginfo_81_t) CREF(aux_4236))->free_mark_81);
		     }
		     aux_4234 = BINT(aux_4235);
		  }
		  STRUCT_SET(aux1536_1471, ((long) 2), aux_4234);
	       }
	       {
		  obj_t aux_4243;
		  {
		     long aux_4244;
		     {
			obj_t aux_4245;
			{
			   object_t aux_4246;
			   aux_4246 = (object_t) (obj1534_1467);
			   aux_4245 = OBJECT_WIDENING(aux_4246);
			}
			aux_4244 = (((sexit_ginfo_81_t) CREF(aux_4245))->mark);
		     }
		     aux_4243 = BINT(aux_4244);
		  }
		  STRUCT_SET(aux1536_1471, ((long) 3), aux_4243);
	       }
	       STRUCT_SET(res1535_1470, ((long) 0), aux1536_1471);
	       {
		  obj_t aux_4253;
		  aux_4253 = STRUCT_KEY(res1535_1470);
		  STRUCT_KEY_SET(aux1536_1471, aux_4253);
	       }
	       {
		  obj_t aux_4256;
		  aux_4256 = CNST_TABLE_REF(((long) 2));
		  STRUCT_KEY_SET(res1535_1470, aux_4256);
	       }
	       return res1535_1470;
	    }
	 }
      }
   }
}


/* struct+object->object-local/ginfo */ obj_t 
struct_object__object_local_ginfo_129_globalize_ginfo(obj_t env_2735, obj_t o_2736, obj_t s_2737)
{
   {
      local_ginfo_108_t o_1455;
      obj_t s_1456;
      {
	 local_ginfo_108_t aux_4260;
	 o_1455 = (local_ginfo_108_t) (o_2736);
	 s_1456 = s_2737;
	 {
	    {
	       obj_t old1558_1459;
	       obj_t aux1559_1460;
	       {
		  obj_t next_method1600_50_1465;
		  next_method1600_50_1465 = find_super_class_method_167___object((object_t) (o_1455), struct_object__object_env_209___object, local_ginfo_108_globalize_ginfo);
		  if (PROCEDUREP(next_method1600_50_1465))
		    {
		       old1558_1459 = PROCEDURE_ENTRY(next_method1600_50_1465) (next_method1600_50_1465, (obj_t) (o_1455), s_1456, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1600_50_1465);
		       {
			  object_t aux_4269;
			  aux_4269 = struct_object__object_93___object((object_t) (o_1455), s_1456);
			  old1558_1459 = (obj_t) (aux_4269);
		       }
		    }
	       }
	       aux1559_1460 = STRUCT_REF(s_1456, ((long) 0));
	       {
		  local_ginfo_108_t new1560_1461;
		  new1560_1461 = ((local_ginfo_108_t) (old1558_1459));
		  {
		     long arg1770_1462;
		     arg1770_1462 = class_num_218___object(local_ginfo_108_globalize_ginfo);
		     {
			obj_t obj_1974;
			obj_1974 = (obj_t) (new1560_1461);
			(((obj_t) CREF(obj_1974))->header = MAKE_HEADER(arg1770_1462, 0), BUNSPEC);
		     }
		  }
		  {
		     local_ginfo_108_t arg1771_1463;
		     {
			local_ginfo_108_t res1908_1981;
			{
			   bool_t escape__117_1978;
			   {
			      obj_t aux_4278;
			      aux_4278 = STRUCT_REF(aux1559_1460, ((long) 0));
			      escape__117_1978 = CBOOL(aux_4278);
			   }
			   {
			      local_ginfo_108_t new1540_1979;
			      new1540_1979 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
			      ((((local_ginfo_108_t) CREF(new1540_1979))->escape__117) = ((bool_t) escape__117_1978), BUNSPEC);
			      res1908_1981 = new1540_1979;
			   }
			}
			arg1771_1463 = res1908_1981;
		     }
		     {
			obj_t aux_4285;
			object_t aux_4283;
			aux_4285 = (obj_t) (arg1771_1463);
			aux_4283 = (object_t) (new1560_1461);
			OBJECT_WIDENING_SET(aux_4283, aux_4285);
		     }
		  }
		  aux_4260 = new1560_1461;
	       }
	    }
	 }
	 return (obj_t) (aux_4260);
      }
   }
}


/* object->struct-local/ginfo */ obj_t 
object__struct_local_ginfo_71_globalize_ginfo(obj_t env_2738, obj_t obj1555_2739)
{
   {
      local_ginfo_108_t obj1555_1442;
      obj1555_1442 = (local_ginfo_108_t) (obj1555_2739);
      {
	 {
	    obj_t res1556_1445;
	    {
	       obj_t next_method1599_219_1453;
	       next_method1599_219_1453 = find_super_class_method_167___object((object_t) (obj1555_1442), object__struct_env_210___object, local_ginfo_108_globalize_ginfo);
	       if (PROCEDUREP(next_method1599_219_1453))
		 {
		    res1556_1445 = PROCEDURE_ENTRY(next_method1599_219_1453) (next_method1599_219_1453, (obj_t) (obj1555_1442), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1599_219_1453);
		    res1556_1445 = object__struct_50___object((object_t) (obj1555_1442));
		 }
	    }
	    {
	       obj_t aux1557_1446;
	       {
		  obj_t aux_4300;
		  aux_4300 = CNST_TABLE_REF(((long) 3));
		  aux1557_1446 = make_struct(aux_4300, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_4303;
		  {
		     bool_t aux_4304;
		     {
			obj_t aux_4305;
			{
			   object_t aux_4306;
			   aux_4306 = (object_t) (obj1555_1442);
			   aux_4305 = OBJECT_WIDENING(aux_4306);
			}
			aux_4304 = (((local_ginfo_108_t) CREF(aux_4305))->escape__117);
		     }
		     aux_4303 = BBOOL(aux_4304);
		  }
		  STRUCT_SET(aux1557_1446, ((long) 0), aux_4303);
	       }
	       STRUCT_SET(res1556_1445, ((long) 0), aux1557_1446);
	       {
		  obj_t aux_4313;
		  aux_4313 = STRUCT_KEY(res1556_1445);
		  STRUCT_KEY_SET(aux1557_1446, aux_4313);
	       }
	       {
		  obj_t aux_4316;
		  aux_4316 = CNST_TABLE_REF(((long) 3));
		  STRUCT_KEY_SET(res1556_1445, aux_4316);
	       }
	       return res1556_1445;
	    }
	 }
      }
   }
}


/* struct+object->object-global/ginfo */ obj_t 
struct_object__object_global_ginfo_231_globalize_ginfo(obj_t env_2740, obj_t o_2741, obj_t s_2742)
{
   {
      global_ginfo_75_t o_1429;
      obj_t s_1430;
      {
	 global_ginfo_75_t aux_4320;
	 o_1429 = (global_ginfo_75_t) (o_2741);
	 s_1430 = s_2742;
	 {
	    {
	       obj_t old1585_1433;
	       obj_t aux1586_1434;
	       {
		  obj_t next_method1598_10_1440;
		  next_method1598_10_1440 = find_super_class_method_167___object((object_t) (o_1429), struct_object__object_env_209___object, global_ginfo_75_globalize_ginfo);
		  if (PROCEDUREP(next_method1598_10_1440))
		    {
		       old1585_1433 = PROCEDURE_ENTRY(next_method1598_10_1440) (next_method1598_10_1440, (obj_t) (o_1429), s_1430, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1598_10_1440);
		       {
			  object_t aux_4329;
			  aux_4329 = struct_object__object_93___object((object_t) (o_1429), s_1430);
			  old1585_1433 = (obj_t) (aux_4329);
		       }
		    }
	       }
	       aux1586_1434 = STRUCT_REF(s_1430, ((long) 0));
	       {
		  global_ginfo_75_t new1587_1435;
		  new1587_1435 = ((global_ginfo_75_t) (old1585_1433));
		  {
		     long arg1753_1436;
		     arg1753_1436 = class_num_218___object(global_ginfo_75_globalize_ginfo);
		     {
			obj_t obj_1941;
			obj_1941 = (obj_t) (new1587_1435);
			(((obj_t) CREF(obj_1941))->header = MAKE_HEADER(arg1753_1436, 0), BUNSPEC);
		     }
		  }
		  {
		     global_ginfo_75_t arg1755_1437;
		     {
			obj_t arg1759_1439;
			arg1759_1439 = STRUCT_REF(aux1586_1434, ((long) 1));
			{
			   global_ginfo_75_t res1907_1952;
			   {
			      bool_t escape__117_1947;
			      {
				 obj_t aux_4339;
				 aux_4339 = STRUCT_REF(aux1586_1434, ((long) 0));
				 escape__117_1947 = CBOOL(aux_4339);
			      }
			      {
				 global_ginfo_75_t new1561_1949;
				 new1561_1949 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
				 ((((global_ginfo_75_t) CREF(new1561_1949))->escape__117) = ((bool_t) escape__117_1947), BUNSPEC);
				 ((((global_ginfo_75_t) CREF(new1561_1949))->global_closure_229) = ((obj_t) arg1759_1439), BUNSPEC);
				 res1907_1952 = new1561_1949;
			      }
			   }
			   arg1755_1437 = res1907_1952;
			}
		     }
		     {
			obj_t aux_4347;
			object_t aux_4345;
			aux_4347 = (obj_t) (arg1755_1437);
			aux_4345 = (object_t) (new1587_1435);
			OBJECT_WIDENING_SET(aux_4345, aux_4347);
		     }
		  }
		  aux_4320 = new1587_1435;
	       }
	    }
	 }
	 return (obj_t) (aux_4320);
      }
   }
}


/* object->struct-global/ginfo */ obj_t 
object__struct_global_ginfo_101_globalize_ginfo(obj_t env_2743, obj_t obj1582_2744)
{
   {
      global_ginfo_75_t obj1582_1414;
      obj1582_1414 = (global_ginfo_75_t) (obj1582_2744);
      {
	 {
	    obj_t res1583_1417;
	    {
	       obj_t next_method1597_152_1427;
	       next_method1597_152_1427 = find_super_class_method_167___object((object_t) (obj1582_1414), object__struct_env_210___object, global_ginfo_75_globalize_ginfo);
	       if (PROCEDUREP(next_method1597_152_1427))
		 {
		    res1583_1417 = PROCEDURE_ENTRY(next_method1597_152_1427) (next_method1597_152_1427, (obj_t) (obj1582_1414), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1597_152_1427);
		    res1583_1417 = object__struct_50___object((object_t) (obj1582_1414));
		 }
	    }
	    {
	       obj_t aux1584_1418;
	       {
		  obj_t aux_4362;
		  aux_4362 = CNST_TABLE_REF(((long) 4));
		  aux1584_1418 = make_struct(aux_4362, ((long) 2), BUNSPEC);
	       }
	       {
		  obj_t aux_4365;
		  {
		     bool_t aux_4366;
		     {
			obj_t aux_4367;
			{
			   object_t aux_4368;
			   aux_4368 = (object_t) (obj1582_1414);
			   aux_4367 = OBJECT_WIDENING(aux_4368);
			}
			aux_4366 = (((global_ginfo_75_t) CREF(aux_4367))->escape__117);
		     }
		     aux_4365 = BBOOL(aux_4366);
		  }
		  STRUCT_SET(aux1584_1418, ((long) 0), aux_4365);
	       }
	       {
		  obj_t aux_4374;
		  {
		     obj_t aux_4375;
		     {
			object_t aux_4376;
			aux_4376 = (object_t) (obj1582_1414);
			aux_4375 = OBJECT_WIDENING(aux_4376);
		     }
		     aux_4374 = (((global_ginfo_75_t) CREF(aux_4375))->global_closure_229);
		  }
		  STRUCT_SET(aux1584_1418, ((long) 1), aux_4374);
	       }
	       STRUCT_SET(res1583_1417, ((long) 0), aux1584_1418);
	       {
		  obj_t aux_4382;
		  aux_4382 = STRUCT_KEY(res1583_1417);
		  STRUCT_KEY_SET(aux1584_1418, aux_4382);
	       }
	       {
		  obj_t aux_4385;
		  aux_4385 = CNST_TABLE_REF(((long) 4));
		  STRUCT_KEY_SET(res1583_1417, aux_4385);
	       }
	       return res1583_1417;
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_ginfo()
{
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_GINFO");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_GINFO");
   return module_initialization_70_ast_node(((long) 0), "GLOBALIZE_GINFO");
}
