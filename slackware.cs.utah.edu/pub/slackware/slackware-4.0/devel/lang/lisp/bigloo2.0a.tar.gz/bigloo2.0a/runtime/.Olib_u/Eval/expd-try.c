/*===========================================================================*/
/*   (Eval/expd-try.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t symbol1518___expander_try = BUNSPEC;
static obj_t symbol1517___expander_try = BUNSPEC;
static obj_t symbol1516___expander_try = BUNSPEC;
static obj_t symbol1515___expander_try = BUNSPEC;
static obj_t symbol1514___expander_try = BUNSPEC;
static obj_t symbol1513___expander_try = BUNSPEC;
static obj_t symbol1512___expander_try = BUNSPEC;
static obj_t symbol1511___expander_try = BUNSPEC;
static obj_t symbol1509___expander_try = BUNSPEC;
static obj_t symbol1510___expander_try = BUNSPEC;
static obj_t symbol1508___expander_try = BUNSPEC;
static obj_t symbol1507___expander_try = BUNSPEC;
static obj_t symbol1506___expander_try = BUNSPEC;
static obj_t symbol1505___expander_try = BUNSPEC;
static obj_t symbol1504___expander_try = BUNSPEC;
static obj_t symbol1503___expander_try = BUNSPEC;
static obj_t symbol1502___expander_try = BUNSPEC;
static obj_t symbol1501___expander_try = BUNSPEC;
extern obj_t string_to_symbol(char *);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _expand_try_125___expander_try(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___expander_try(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t expand_try_212___expander_try(obj_t, obj_t);
static obj_t imported_modules_init_94___expander_try();
static obj_t require_initialization_114___expander_try = BUNSPEC;
static obj_t cnst_init_137___expander_try();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_try_env_145___expander_try, _expand_try_125___expander_try1522, _expand_try_125___expander_try, 0L, 2 );
DEFINE_STRING( string1519___expander_try, string1519___expander_try1523, "try", 3 );
DEFINE_STRING( string1520___expander_try, string1520___expander_try1524, "Illegal form", 12 );


/* module-initialization */obj_t module_initialization_70___expander_try(long checksum_809, char * from_810)
{
if(CBOOL(require_initialization_114___expander_try)){
require_initialization_114___expander_try = BBOOL(((bool_t)0));
cnst_init_137___expander_try();
imported_modules_init_94___expander_try();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expander_try()
{
symbol1501___expander_try = string_to_symbol("HANDLER");
symbol1502___expander_try = string_to_symbol("RHANDLER");
symbol1503___expander_try = string_to_symbol("BODY");
symbol1504___expander_try = string_to_symbol("ARMED");
symbol1505___expander_try = string_to_symbol("LETREC");
symbol1506___expander_try = string_to_symbol("LAMBDA");
symbol1507___expander_try = string_to_symbol("ESC");
symbol1508___expander_try = string_to_symbol("OBJ");
symbol1509___expander_try = string_to_symbol("PROC");
symbol1510___expander_try = string_to_symbol("MSG");
symbol1511___expander_try = string_to_symbol("SET!");
symbol1512___expander_try = string_to_symbol("REMOVE-ERROR-HANDLER!");
symbol1513___expander_try = string_to_symbol("BIND-EXIT");
symbol1514___expander_try = string_to_symbol("ESCAPE");
symbol1515___expander_try = string_to_symbol("DYNAMIC-WIND");
symbol1516___expander_try = string_to_symbol("ADD-ERROR-HANDLER!");
symbol1517___expander_try = string_to_symbol("IF");
return (symbol1518___expander_try = string_to_symbol("BEGIN"),
BUNSPEC);
}


/* expand-try */obj_t expand_try_212___expander_try(obj_t x_1, obj_t e_2)
{
{
obj_t body_320;
obj_t handler_321;
if(PAIRP(x_1)){
obj_t cdr_109_69_326;
cdr_109_69_326 = CDR(x_1);
if(PAIRP(cdr_109_69_326)){
obj_t car_112_152_328;
obj_t cdr_113_28_329;
car_112_152_328 = CAR(cdr_109_69_326);
cdr_113_28_329 = CDR(cdr_109_69_326);
if((car_112_152_328==BNIL)){
FAILURE(string1519___expander_try,string1520___expander_try,x_1);}
 else {
if(PAIRP(cdr_113_28_329)){
bool_t test_846;
{
obj_t aux_847;
aux_847 = CDR(cdr_113_28_329);
test_846 = (aux_847==BNIL);
}
if(test_846){
body_320 = car_112_152_328;
handler_321 = CAR(cdr_113_28_329);
{
obj_t nhandler_337;
obj_t rhandler_338;
obj_t nbody_339;
obj_t armed_340;
nhandler_337 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1501___expander_try, BEOA);
rhandler_338 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1502___expander_try, BEOA);
nbody_339 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1503___expander_try, BEOA);
armed_340 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1504___expander_try, BEOA);
{
obj_t arg1015_341;
{
obj_t arg1016_342;
obj_t arg1017_343;
obj_t arg1018_344;
arg1016_342 = symbol1505___expander_try;
{
obj_t arg1025_350;
obj_t arg1026_351;
obj_t arg1027_352;
obj_t arg1028_353;
{
obj_t list1036_361;
{
obj_t arg1037_362;
arg1037_362 = MAKE_PAIR(BNIL, BNIL);
list1036_361 = MAKE_PAIR(BTRUE, arg1037_362);
}
arg1025_350 = cons__138___r4_pairs_and_lists_6_3(armed_340, list1036_361);
}
{
obj_t list1040_365;
{
obj_t arg1041_366;
arg1041_366 = MAKE_PAIR(BNIL, BNIL);
list1040_365 = MAKE_PAIR(handler_321, arg1041_366);
}
arg1026_351 = cons__138___r4_pairs_and_lists_6_3(nhandler_337, list1040_365);
}
{
obj_t arg1043_368;
{
obj_t arg1048_373;
obj_t arg1049_374;
obj_t arg1050_375;
obj_t arg1051_376;
obj_t arg1053_377;
arg1048_373 = symbol1506___expander_try;
{
obj_t arg1061_385;
obj_t arg1062_386;
obj_t arg1063_387;
obj_t arg1065_388;
arg1061_385 = symbol1507___expander_try;
arg1062_386 = symbol1508___expander_try;
arg1063_387 = symbol1509___expander_try;
arg1065_388 = symbol1510___expander_try;
{
obj_t list1067_390;
{
obj_t arg1068_391;
{
obj_t arg1069_392;
{
obj_t arg1070_393;
arg1070_393 = MAKE_PAIR(BNIL, BNIL);
arg1069_392 = MAKE_PAIR(arg1065_388, arg1070_393);
}
arg1068_391 = MAKE_PAIR(arg1063_387, arg1069_392);
}
list1067_390 = MAKE_PAIR(arg1062_386, arg1068_391);
}
arg1049_374 = cons__138___r4_pairs_and_lists_6_3(arg1061_385, list1067_390);
}
}
{
obj_t arg1073_395;
arg1073_395 = symbol1511___expander_try;
{
obj_t list1077_397;
{
obj_t arg1078_398;
{
obj_t arg1079_399;
arg1079_399 = MAKE_PAIR(BNIL, BNIL);
arg1078_398 = MAKE_PAIR(BFALSE, arg1079_399);
}
list1077_397 = MAKE_PAIR(armed_340, arg1078_398);
}
arg1050_375 = cons__138___r4_pairs_and_lists_6_3(arg1073_395, list1077_397);
}
}
{
obj_t arg1081_401;
arg1081_401 = symbol1512___expander_try;
{
obj_t list1083_403;
list1083_403 = MAKE_PAIR(BNIL, BNIL);
arg1051_376 = cons__138___r4_pairs_and_lists_6_3(arg1081_401, list1083_403);
}
}
{
obj_t arg1085_405;
obj_t arg1086_406;
obj_t arg1087_407;
obj_t arg1088_408;
arg1085_405 = symbol1507___expander_try;
arg1086_406 = symbol1508___expander_try;
arg1087_407 = symbol1509___expander_try;
arg1088_408 = symbol1510___expander_try;
{
obj_t list1090_410;
{
obj_t arg1091_411;
{
obj_t arg1092_412;
{
obj_t arg1093_413;
{
obj_t arg1094_414;
arg1094_414 = MAKE_PAIR(BNIL, BNIL);
arg1093_413 = MAKE_PAIR(arg1088_408, arg1094_414);
}
arg1092_412 = MAKE_PAIR(arg1087_407, arg1093_413);
}
arg1091_411 = MAKE_PAIR(arg1086_406, arg1092_412);
}
list1090_410 = MAKE_PAIR(arg1085_405, arg1091_411);
}
arg1053_377 = cons__138___r4_pairs_and_lists_6_3(nhandler_337, list1090_410);
}
}
{
obj_t list1055_379;
{
obj_t arg1056_380;
{
obj_t arg1057_381;
{
obj_t arg1058_382;
{
obj_t arg1059_383;
arg1059_383 = MAKE_PAIR(BNIL, BNIL);
arg1058_382 = MAKE_PAIR(arg1053_377, arg1059_383);
}
arg1057_381 = MAKE_PAIR(arg1051_376, arg1058_382);
}
arg1056_380 = MAKE_PAIR(arg1050_375, arg1057_381);
}
list1055_379 = MAKE_PAIR(arg1049_374, arg1056_380);
}
arg1043_368 = cons__138___r4_pairs_and_lists_6_3(arg1048_373, list1055_379);
}
}
{
obj_t list1045_370;
{
obj_t arg1046_371;
arg1046_371 = MAKE_PAIR(BNIL, BNIL);
list1045_370 = MAKE_PAIR(arg1043_368, arg1046_371);
}
arg1027_352 = cons__138___r4_pairs_and_lists_6_3(rhandler_338, list1045_370);
}
}
{
obj_t arg1096_416;
{
obj_t arg1101_421;
arg1101_421 = symbol1506___expander_try;
{
obj_t list1104_424;
{
obj_t arg1105_425;
{
obj_t arg1106_426;
arg1106_426 = MAKE_PAIR(BNIL, BNIL);
arg1105_425 = MAKE_PAIR(body_320, arg1106_426);
}
list1104_424 = MAKE_PAIR(BNIL, arg1105_425);
}
arg1096_416 = cons__138___r4_pairs_and_lists_6_3(arg1101_421, list1104_424);
}
}
{
obj_t list1098_418;
{
obj_t arg1099_419;
arg1099_419 = MAKE_PAIR(BNIL, BNIL);
list1098_418 = MAKE_PAIR(arg1096_416, arg1099_419);
}
arg1028_353 = cons__138___r4_pairs_and_lists_6_3(nbody_339, list1098_418);
}
}
{
obj_t list1030_355;
{
obj_t arg1031_356;
{
obj_t arg1032_357;
{
obj_t arg1033_358;
arg1033_358 = MAKE_PAIR(BNIL, BNIL);
arg1032_357 = MAKE_PAIR(arg1028_353, arg1033_358);
}
arg1031_356 = MAKE_PAIR(arg1027_352, arg1032_357);
}
list1030_355 = MAKE_PAIR(arg1026_351, arg1031_356);
}
arg1017_343 = cons__138___r4_pairs_and_lists_6_3(arg1025_350, list1030_355);
}
}
{
obj_t arg1108_428;
obj_t arg1109_429;
obj_t arg1110_430;
arg1108_428 = symbol1513___expander_try;
{
obj_t arg1116_436;
arg1116_436 = symbol1514___expander_try;
{
obj_t list1118_438;
list1118_438 = MAKE_PAIR(BNIL, BNIL);
arg1109_429 = cons__138___r4_pairs_and_lists_6_3(arg1116_436, list1118_438);
}
}
{
obj_t arg1120_440;
obj_t arg1121_441;
obj_t arg1122_442;
arg1120_440 = symbol1515___expander_try;
{
obj_t arg1129_449;
obj_t arg1131_451;
arg1129_449 = symbol1506___expander_try;
{
obj_t arg1137_457;
obj_t arg1139_458;
arg1137_457 = symbol1516___expander_try;
arg1139_458 = symbol1514___expander_try;
{
obj_t list1141_460;
{
obj_t arg1142_461;
{
obj_t arg1143_462;
arg1143_462 = MAKE_PAIR(BNIL, BNIL);
arg1142_461 = MAKE_PAIR(arg1139_458, arg1143_462);
}
list1141_460 = MAKE_PAIR(rhandler_338, arg1142_461);
}
arg1131_451 = cons__138___r4_pairs_and_lists_6_3(arg1137_457, list1141_460);
}
}
{
obj_t list1133_453;
{
obj_t arg1134_454;
{
obj_t arg1135_455;
arg1135_455 = MAKE_PAIR(BNIL, BNIL);
arg1134_454 = MAKE_PAIR(arg1131_451, arg1135_455);
}
list1133_453 = MAKE_PAIR(BNIL, arg1134_454);
}
arg1121_441 = cons__138___r4_pairs_and_lists_6_3(arg1129_449, list1133_453);
}
}
{
obj_t arg1145_464;
obj_t arg1147_466;
arg1145_464 = symbol1506___expander_try;
{
obj_t arg1153_472;
obj_t arg1154_473;
arg1153_472 = symbol1517___expander_try;
{
obj_t arg1161_479;
obj_t arg1162_480;
obj_t arg1163_481;
arg1161_479 = symbol1518___expander_try;
{
obj_t arg1169_487;
arg1169_487 = symbol1511___expander_try;
{
obj_t list1171_489;
{
obj_t arg1172_490;
{
obj_t arg1173_491;
arg1173_491 = MAKE_PAIR(BNIL, BNIL);
arg1172_490 = MAKE_PAIR(BFALSE, arg1173_491);
}
list1171_489 = MAKE_PAIR(armed_340, arg1172_490);
}
arg1162_480 = cons__138___r4_pairs_and_lists_6_3(arg1169_487, list1171_489);
}
}
{
obj_t arg1175_493;
arg1175_493 = symbol1512___expander_try;
{
obj_t list1177_495;
list1177_495 = MAKE_PAIR(BNIL, BNIL);
arg1163_481 = cons__138___r4_pairs_and_lists_6_3(arg1175_493, list1177_495);
}
}
{
obj_t list1165_483;
{
obj_t arg1166_484;
{
obj_t arg1167_485;
arg1167_485 = MAKE_PAIR(BNIL, BNIL);
arg1166_484 = MAKE_PAIR(arg1163_481, arg1167_485);
}
list1165_483 = MAKE_PAIR(arg1162_480, arg1166_484);
}
arg1154_473 = cons__138___r4_pairs_and_lists_6_3(arg1161_479, list1165_483);
}
}
{
obj_t list1156_475;
{
obj_t arg1157_476;
{
obj_t arg1158_477;
arg1158_477 = MAKE_PAIR(BNIL, BNIL);
arg1157_476 = MAKE_PAIR(arg1154_473, arg1158_477);
}
list1156_475 = MAKE_PAIR(armed_340, arg1157_476);
}
arg1147_466 = cons__138___r4_pairs_and_lists_6_3(arg1153_472, list1156_475);
}
}
{
obj_t list1149_468;
{
obj_t arg1150_469;
{
obj_t arg1151_470;
arg1151_470 = MAKE_PAIR(BNIL, BNIL);
arg1150_469 = MAKE_PAIR(arg1147_466, arg1151_470);
}
list1149_468 = MAKE_PAIR(BNIL, arg1150_469);
}
arg1122_442 = cons__138___r4_pairs_and_lists_6_3(arg1145_464, list1149_468);
}
}
{
obj_t list1124_444;
{
obj_t arg1125_445;
{
obj_t arg1126_446;
{
obj_t arg1127_447;
arg1127_447 = MAKE_PAIR(BNIL, BNIL);
arg1126_446 = MAKE_PAIR(arg1122_442, arg1127_447);
}
arg1125_445 = MAKE_PAIR(nbody_339, arg1126_446);
}
list1124_444 = MAKE_PAIR(arg1121_441, arg1125_445);
}
arg1110_430 = cons__138___r4_pairs_and_lists_6_3(arg1120_440, list1124_444);
}
}
{
obj_t list1112_432;
{
obj_t arg1113_433;
{
obj_t arg1114_434;
arg1114_434 = MAKE_PAIR(BNIL, BNIL);
arg1113_433 = MAKE_PAIR(arg1110_430, arg1114_434);
}
list1112_432 = MAKE_PAIR(arg1109_429, arg1113_433);
}
arg1018_344 = cons__138___r4_pairs_and_lists_6_3(arg1108_428, list1112_432);
}
}
{
obj_t list1020_346;
{
obj_t arg1021_347;
{
obj_t arg1022_348;
arg1022_348 = MAKE_PAIR(BNIL, BNIL);
arg1021_347 = MAKE_PAIR(arg1018_344, arg1022_348);
}
list1020_346 = MAKE_PAIR(arg1017_343, arg1021_347);
}
arg1015_341 = cons__138___r4_pairs_and_lists_6_3(arg1016_342, list1020_346);
}
}
return PROCEDURE_ENTRY(e_2)(e_2, arg1015_341, e_2, BEOA);
}
}
}
 else {
FAILURE(string1519___expander_try,string1520___expander_try,x_1);}
}
 else {
FAILURE(string1519___expander_try,string1520___expander_try,x_1);}
}
}
 else {
FAILURE(string1519___expander_try,string1520___expander_try,x_1);}
}
 else {
FAILURE(string1519___expander_try,string1520___expander_try,x_1);}
}
}


/* _expand-try */obj_t _expand_try_125___expander_try(obj_t env_806, obj_t x_807, obj_t e_808)
{
return expand_try_212___expander_try(x_807, e_808);
}


/* imported-modules-init */obj_t imported_modules_init_94___expander_try()
{
module_initialization_70___error(((long)0), "__EXPANDER_TRY");
module_initialization_70___bigloo(((long)0), "__EXPANDER_TRY");
module_initialization_70___tvector(((long)0), "__EXPANDER_TRY");
module_initialization_70___structure(((long)0), "__EXPANDER_TRY");
module_initialization_70___bexit(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPANDER_TRY");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPANDER_TRY");
return module_initialization_70___progn(((long)0), "__EXPANDER_TRY");
}

