/*===========================================================================*/
/*   (Tools/date.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t _bigloo_date_59_tools_date(obj_t);
extern obj_t bigloo_date_110_tools_date();
extern obj_t module_initialization_70_tools_date(long, char *);
static obj_t require_initialization_114_tools_date = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(bigloo_date_env_128_tools_date, _bigloo_date_59_tools_date1004, _bigloo_date_59_tools_date, 0L, 0);
DEFINE_STRING(string1002_tools_date, string1002_tools_date1005, " Thu Feb 11 22:46:22 CET 1999 ", 30);


/* module-initialization */ obj_t 
module_initialization_70_tools_date(long checksum_2, char *from_3)
{
   if (CBOOL(require_initialization_114_tools_date))
     {
	require_initialization_114_tools_date = BBOOL(((bool_t) 0));
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* bigloo-date */ obj_t 
bigloo_date_110_tools_date()
{
   return string1002_tools_date;
}


/* _bigloo-date */ obj_t 
_bigloo_date_59_tools_date(obj_t env_1)
{
   return bigloo_date_110_tools_date();
}
