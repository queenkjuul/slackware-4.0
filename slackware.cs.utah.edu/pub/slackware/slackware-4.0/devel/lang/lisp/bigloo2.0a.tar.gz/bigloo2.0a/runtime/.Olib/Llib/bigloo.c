/*===========================================================================*/
/*   (Llib/bigloo.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern bool_t bigloo_strcmp(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t symbol1278___bigloo = BUNSPEC;
static obj_t symbol1277___bigloo = BUNSPEC;
static obj_t symbol1276___bigloo = BUNSPEC;
static obj_t symbol1274___bigloo = BUNSPEC;
static obj_t symbol1273___bigloo = BUNSPEC;
static obj_t symbol1271___bigloo = BUNSPEC;
static obj_t symbol1259___bigloo = BUNSPEC;
static obj_t symbol1258___bigloo = BUNSPEC;
extern obj_t string_append(obj_t, obj_t);
static obj_t toplevel_init_63___bigloo();
static obj_t _release__212___bigloo = BUNSPEC;
static obj_t _level__58___bigloo = BUNSPEC;
extern long closure_arity_107___bigloo(obj_t);
extern obj_t check_version__107___bigloo(obj_t, char *, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _modules__206___bigloo = BUNSPEC;
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
obj_t bprof_port = BUNSPEC;
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_substring(obj_t, long, long);
static obj_t _check_version_1166_78___bigloo(obj_t, obj_t, obj_t, obj_t);
static obj_t _unspecified___bigloo(obj_t);
extern obj_t unspecified___bigloo();
static obj_t _cnst__123___bigloo(obj_t, obj_t);
static obj_t imported_modules_init_94___bigloo();
extern long minfx___r4_numbers_6_5_fixnum(long, obj_t);
static obj_t require_initialization_114___bigloo = BUNSPEC;
extern bool_t cnst__120___bigloo(obj_t);
static obj_t _closure_arity1167_177___bigloo(obj_t, obj_t);
static obj_t cnst_init_137___bigloo();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( check_version__env_23___bigloo, _check_version_1166_78___bigloo1280, _check_version_1166_78___bigloo, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( closure_arity_env_23___bigloo, _closure_arity1167_177___bigloo1281, _closure_arity1167_177___bigloo, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cnst__env_192___bigloo, _cnst__123___bigloo1282, _cnst__123___bigloo, 0L, 1 );
DEFINE_STRING( string1275___bigloo, string1275___bigloo1283, "PROCEDURE", 9 );
DEFINE_STRING( string1272___bigloo, string1272___bigloo1284, "STRING", 6 );
DEFINE_STRING( string1269___bigloo, string1269___bigloo1285, "Some modules have been compiled by: ", 36 );
DEFINE_STRING( string1270___bigloo, string1270___bigloo1286, "and other by: ", 14 );
DEFINE_STRING( string1268___bigloo, string1268___bigloo1287, "index out of range", 18 );
DEFINE_STRING( string1267___bigloo, string1267___bigloo1288, "string-set!", 11 );
DEFINE_STRING( string1266___bigloo, string1266___bigloo1289, " (level 0)", 10 );
DEFINE_STRING( string1265___bigloo, string1265___bigloo1290, "UCHAR", 5 );
DEFINE_STRING( string1264___bigloo, string1264___bigloo1291, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1263___bigloo, string1263___bigloo1292, "Illegal index", 13 );
DEFINE_STRING( string1262___bigloo, string1262___bigloo1293, "substring", 9 );
DEFINE_STRING( string1261___bigloo, string1261___bigloo1294, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/bigloo.scm", 59 );
DEFINE_STRING( string1260___bigloo, string1260___bigloo1295, "BSTRING", 7 );
DEFINE_EXPORT_PROCEDURE( unspecified_env_163___bigloo, _unspecified___bigloo1296, _unspecified___bigloo, 0L, 0 );


/* module-initialization */obj_t module_initialization_70___bigloo(long checksum_629, char * from_630)
{
if(CBOOL(require_initialization_114___bigloo)){
require_initialization_114___bigloo = BBOOL(((bool_t)0));
cnst_init_137___bigloo();
imported_modules_init_94___bigloo();
toplevel_init_63___bigloo();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___bigloo()
{
symbol1258___bigloo = string_to_symbol("TOPLEVEL-INIT");
symbol1259___bigloo = string_to_symbol("CHECK-VERSION!");
symbol1271___bigloo = string_to_symbol("_CHECK-VERSION!1166");
symbol1273___bigloo = string_to_symbol("CLOSURE-ARITY");
symbol1274___bigloo = string_to_symbol("_CLOSURE-ARITY1167");
symbol1276___bigloo = string_to_symbol("UNSPECIFIED");
symbol1277___bigloo = string_to_symbol("CNST?");
return (symbol1278___bigloo = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___bigloo()
{
{
obj_t symbol1155_517;
symbol1155_517 = symbol1258___bigloo;
{
PUSH_TRACE(symbol1155_517);
BUNSPEC;
{
obj_t aux1154_518;
_release__212___bigloo = BFALSE;
_level__58___bigloo = BFALSE;
_modules__206___bigloo = BNIL;
aux1154_518 = (bprof_port = BUNSPEC,
BUNSPEC);
POP_TRACE();
return aux1154_518;
}
}
}
}


/* check-version! */obj_t check_version__107___bigloo(obj_t module_1, char * release_2, obj_t level_3)
{
{
obj_t symbol1157_519;
symbol1157_519 = symbol1259___bigloo;
{
PUSH_TRACE(symbol1157_519);
BUNSPEC;
{
obj_t aux1156_520;
{
bool_t test1007_216;
{
obj_t obj_366;
obj_366 = _release__212___bigloo;
test1007_216 = STRINGP(obj_366);
}
if(test1007_216){
bool_t test1008_217;
{
bool_t test1018_232;
{
long min_236;
{
long arg1023_240;
{
long arg1026_242;
long arg1027_243;
{
obj_t aux_650;
aux_650 = string_to_bstring(release_2);
arg1026_242 = STRING_LENGTH(aux_650);
}
{
obj_t string_368;
{
obj_t aux1168_538;
aux1168_538 = _release__212___bigloo;
if(STRINGP(aux1168_538)){
string_368 = aux1168_538;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, aux1168_538, string1261___bigloo, BINT(((long)6023)));
exit( -1 );}
}
arg1027_243 = STRING_LENGTH(string_368);
}
{
obj_t list1028_244;
{
obj_t aux_659;
aux_659 = BINT(arg1027_243);
list1028_244 = MAKE_PAIR(aux_659, BNIL);
}
arg1023_240 = minfx___r4_numbers_6_5_fixnum(arg1026_242, list1028_244);
}
}
min_236 = (arg1023_240-((long)1));
}
{
bool_t test1020_237;
{
obj_t arg1021_238;
obj_t arg1022_239;
{
obj_t res1152_399;
{
obj_t string_371;
string_371 = string_to_bstring(release_2);
{
bool_t test_665;
if((min_236>=((long)0))){
bool_t test_668;
{
long aux_669;
{
long aux_670;
aux_670 = STRING_LENGTH(string_371);
aux_669 = (aux_670+((long)1));
}
test_668 = BOUND_CHECK(((long)0), aux_669);
}
if(test_668){
long aux_674;
{
long aux_675;
aux_675 = STRING_LENGTH(string_371);
aux_674 = (aux_675+((long)1));
}
test_665 = BOUND_CHECK(min_236, aux_674);
}
 else {
test_665 = ((bool_t)0);
}
}
 else {
test_665 = ((bool_t)0);
}
if(test_665){
res1152_399 = c_substring(string_371, ((long)0), min_236);
}
 else {
obj_t arg1039_385;
{
obj_t aux_682;
obj_t aux_680;
aux_682 = BINT(min_236);
aux_680 = BINT(((long)0));
arg1039_385 = MAKE_PAIR(aux_680, aux_682);
}
{
obj_t aux1174_544;
aux1174_544 = debug_error_location_199___error(string1262___bigloo, string1263___bigloo, arg1039_385, string1264___bigloo, BINT(((long)7610)));
if(STRINGP(aux1174_544)){
res1152_399 = aux1174_544;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, aux1174_544, string1264___bigloo, BINT(((long)7610)));
exit( -1 );}
}
}
}
}
arg1021_238 = res1152_399;
}
{
obj_t res1153_428;
{
obj_t string_400;
{
obj_t aux1180_550;
aux1180_550 = _release__212___bigloo;
if(STRINGP(aux1180_550)){
string_400 = aux1180_550;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, aux1180_550, string1261___bigloo, BINT(((long)6117)));
exit( -1 );}
}
{
bool_t test_697;
if((min_236>=((long)0))){
bool_t test_700;
{
long aux_701;
{
long aux_702;
aux_702 = STRING_LENGTH(string_400);
aux_701 = (aux_702+((long)1));
}
test_700 = BOUND_CHECK(((long)0), aux_701);
}
if(test_700){
long aux_706;
{
long aux_707;
aux_707 = STRING_LENGTH(string_400);
aux_706 = (aux_707+((long)1));
}
test_697 = BOUND_CHECK(min_236, aux_706);
}
 else {
test_697 = ((bool_t)0);
}
}
 else {
test_697 = ((bool_t)0);
}
if(test_697){
res1153_428 = c_substring(string_400, ((long)0), min_236);
}
 else {
obj_t arg1039_414;
{
obj_t aux_714;
obj_t aux_712;
aux_714 = BINT(min_236);
aux_712 = BINT(((long)0));
arg1039_414 = MAKE_PAIR(aux_712, aux_714);
}
{
obj_t aux1186_556;
aux1186_556 = debug_error_location_199___error(string1262___bigloo, string1263___bigloo, arg1039_414, string1264___bigloo, BINT(((long)7610)));
if(STRINGP(aux1186_556)){
res1153_428 = aux1186_556;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, aux1186_556, string1264___bigloo, BINT(((long)7610)));
exit( -1 );}
}
}
}
}
arg1022_239 = res1153_428;
}
test1020_237 = bigloo_strcmp(arg1021_238, arg1022_239);
}
if(test1020_237){
test1018_232 = ((bool_t)0);
}
 else {
test1018_232 = ((bool_t)1);
}
}
}
if(test1018_232){
test1008_217 = ((bool_t)1);
}
 else {
bool_t _andtest_1002_233;
_andtest_1002_233 = CHARP(level_3);
if(_andtest_1002_233){
bool_t _andtest_1003_234;
{
obj_t obj_432;
obj_432 = _level__58___bigloo;
_andtest_1003_234 = CHARP(obj_432);
}
if(_andtest_1003_234){
bool_t test1019_235;
{
unsigned char char1_433;
unsigned char char2_434;
{
obj_t aux_731;
{
obj_t aux1192_562;
aux1192_562 = _level__58___bigloo;
if(CHARP(aux1192_562)){
aux_731 = aux1192_562;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1265___bigloo, aux1192_562, string1261___bigloo, BINT(((long)6193)));
exit( -1 );}
}
char1_433 = (unsigned char)CCHAR(aux_731);
}
{
obj_t aux_738;
if(_andtest_1002_233){
aux_738 = level_3;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1265___bigloo, level_3, string1261___bigloo, BINT(((long)6200)));
exit( -1 );}
char2_434 = (unsigned char)CCHAR(aux_738);
}
test1019_235 = (char1_433==char2_434);
}
if(test1019_235){
test1008_217 = ((bool_t)0);
}
 else {
test1008_217 = ((bool_t)1);
}
}
 else {
test1008_217 = ((bool_t)0);
}
}
 else {
test1008_217 = ((bool_t)0);
}
}
}
if(test1008_217){
{
obj_t arg1009_219;
obj_t arg1010_220;
obj_t arg1011_221;
{
obj_t arg1013_223;
{
obj_t release_435;
obj_t level_436;
release_435 = _release__212___bigloo;
level_436 = _level__58___bigloo;
{
bool_t test1017_437;
test1017_437 = CHARP(level_436);
if(test1017_437){
obj_t s_438;
{
char * aux_749;
aux_749 = BSTRING_TO_STRING(string1266___bigloo);
s_438 = string_to_bstring(aux_749);
}
{
unsigned char char_166_443;
{
obj_t aux_752;
if(test1017_437){
aux_752 = level_436;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1265___bigloo, level_436, string1261___bigloo, BINT(((long)6331)));
exit( -1 );}
char_166_443 = (unsigned char)CCHAR(aux_752);
}
{
bool_t test_758;
{
long aux_759;
aux_759 = STRING_LENGTH(s_438);
test_758 = BOUND_CHECK(((long)8), aux_759);
}
if(test_758){
STRING_SET(s_438, ((long)8), char_166_443);
}
 else {
debug_error_location_199___error(string1267___bigloo, string1268___bigloo, BINT(((long)8)), string1264___bigloo, BINT(((long)7610)));
}
}
}
{
obj_t aux_766;
if(STRINGP(release_435)){
aux_766 = release_435;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, release_435, string1261___bigloo, BINT(((long)6358)));
exit( -1 );}
arg1013_223 = string_append(aux_766, s_438);
}
}
 else {
arg1013_223 = release_435;
}
}
}
{
obj_t aux_773;
if(STRINGP(arg1013_223)){
aux_773 = arg1013_223;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, arg1013_223, string1261___bigloo, BINT(((long)6416)));
exit( -1 );}
arg1009_219 = string_append(string1269___bigloo, aux_773);
}
}
{
obj_t arg1015_225;
{
bool_t test1017_452;
test1017_452 = CHARP(level_3);
if(test1017_452){
obj_t s_453;
{
char * aux_782;
aux_782 = BSTRING_TO_STRING(string1266___bigloo);
s_453 = string_to_bstring(aux_782);
}
{
unsigned char char_166_458;
{
obj_t aux_785;
if(test1017_452){
aux_785 = level_3;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1265___bigloo, level_3, string1261___bigloo, BINT(((long)6331)));
exit( -1 );}
char_166_458 = (unsigned char)CCHAR(aux_785);
}
{
bool_t test_791;
{
long aux_792;
aux_792 = STRING_LENGTH(s_453);
test_791 = BOUND_CHECK(((long)8), aux_792);
}
if(test_791){
STRING_SET(s_453, ((long)8), char_166_458);
}
 else {
debug_error_location_199___error(string1267___bigloo, string1268___bigloo, BINT(((long)8)), string1264___bigloo, BINT(((long)7610)));
}
}
}
{
obj_t aux_799;
aux_799 = string_to_bstring(release_2);
arg1015_225 = string_append(aux_799, s_453);
}
}
 else {
arg1015_225 = string_to_bstring(release_2);
}
}
{
obj_t aux_803;
if(STRINGP(arg1015_225)){
aux_803 = arg1015_225;
}
 else {
bigloo_type_error_location_103___error(symbol1259___bigloo, string1260___bigloo, arg1015_225, string1261___bigloo, BINT(((long)6519)));
exit( -1 );}
arg1010_220 = string_append(string1270___bigloo, aux_803);
}
}
{
obj_t obj2_466;
obj2_466 = _modules__206___bigloo;
arg1011_221 = MAKE_PAIR(module_1, obj2_466);
}
aux1156_520 = debug_error_location_199___error(arg1009_219, arg1010_220, arg1011_221, string1264___bigloo, BINT(((long)7610)));
}
}
 else {
{
obj_t obj2_484;
obj2_484 = _modules__206___bigloo;
aux1156_520 = (_modules__206___bigloo = MAKE_PAIR(module_1, obj2_484),
BUNSPEC);
}
}
}
 else {
{
obj_t list1030_246;
list1030_246 = MAKE_PAIR(module_1, BNIL);
_modules__206___bigloo = list1030_246;
}
_release__212___bigloo = string_to_bstring(release_2);
aux1156_520 = (_level__58___bigloo = level_3,
BUNSPEC);
}
}
POP_TRACE();
return aux1156_520;
}
}
}
}


/* _check-version!1166 */obj_t _check_version_1166_78___bigloo(obj_t env_529, obj_t module_530, obj_t release_531, obj_t level_532)
{
{
char * aux_817;
{
obj_t aux_818;
if(STRINGP(release_531)){
aux_818 = release_531;
}
 else {
bigloo_type_error_location_103___error(symbol1271___bigloo, string1272___bigloo, release_531, string1261___bigloo, BINT(((long)5770)));
exit( -1 );}
aux_817 = BSTRING_TO_STRING(aux_818);
}
return check_version__107___bigloo(module_530, aux_817, level_532);
}
}


/* closure-arity */long closure_arity_107___bigloo(obj_t proc_4)
{
{
obj_t symbol1159_617;
symbol1159_617 = symbol1273___bigloo;
{
PUSH_TRACE(symbol1159_617);
BUNSPEC;
{
long aux1158_618;
aux1158_618 = PROCEDURE_ARITY(proc_4);
POP_TRACE();
return aux1158_618;
}
}
}
}


/* _closure-arity1167 */obj_t _closure_arity1167_177___bigloo(obj_t env_533, obj_t proc_534)
{
{
long aux_829;
{
obj_t proc_619;
if(PROCEDUREP(proc_534)){
proc_619 = proc_534;
}
 else {
bigloo_type_error_location_103___error(symbol1274___bigloo, string1275___bigloo, proc_534, string1261___bigloo, BINT(((long)7201)));
exit( -1 );}
{
obj_t symbol1159_620;
symbol1159_620 = symbol1273___bigloo;
{
PUSH_TRACE(symbol1159_620);
BUNSPEC;
{
long aux1158_621;
aux1158_621 = PROCEDURE_ARITY(proc_619);
POP_TRACE();
aux_829 = aux1158_621;
}
}
}
}
return BINT(aux_829);
}
}


/* unspecified */obj_t unspecified___bigloo()
{
{
obj_t symbol1161_622;
symbol1161_622 = symbol1276___bigloo;
{
PUSH_TRACE(symbol1161_622);
BUNSPEC;
POP_TRACE();
return BUNSPEC;
}
}
}


/* _unspecified */obj_t _unspecified___bigloo(obj_t env_535)
{
{
obj_t symbol1161_623;
symbol1161_623 = symbol1276___bigloo;
{
PUSH_TRACE(symbol1161_623);
BUNSPEC;
POP_TRACE();
return BUNSPEC;
}
}
}


/* cnst? */bool_t cnst__120___bigloo(obj_t obj_5)
{
{
obj_t symbol1163_624;
symbol1163_624 = symbol1277___bigloo;
{
PUSH_TRACE(symbol1163_624);
BUNSPEC;
{
bool_t aux1162_625;
aux1162_625 = CNSTP(obj_5);
POP_TRACE();
return aux1162_625;
}
}
}
}


/* _cnst? */obj_t _cnst__123___bigloo(obj_t env_536, obj_t obj_537)
{
{
bool_t aux_846;
{
obj_t obj_626;
obj_626 = obj_537;
{
obj_t symbol1163_627;
symbol1163_627 = symbol1277___bigloo;
{
PUSH_TRACE(symbol1163_627);
BUNSPEC;
{
bool_t aux1162_628;
aux1162_628 = CNSTP(obj_626);
POP_TRACE();
aux_846 = aux1162_628;
}
}
}
}
return BBOOL(aux_846);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___bigloo()
{
{
obj_t symbol1165_527;
symbol1165_527 = symbol1278___bigloo;
{
PUSH_TRACE(symbol1165_527);
BUNSPEC;
{
obj_t aux1164_528;
aux1164_528 = module_initialization_70___error(((long)0), "__BIGLOO");
POP_TRACE();
return aux1164_528;
}
}
}
}

