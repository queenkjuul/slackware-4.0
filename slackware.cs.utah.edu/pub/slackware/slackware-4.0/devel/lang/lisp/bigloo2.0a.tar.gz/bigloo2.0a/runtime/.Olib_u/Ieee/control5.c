/*===========================================================================*/
/*   (Ieee/control5.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t module_initialization_70___r5_control_features_6_4(long, char *);
extern obj_t module_initialization_70___error(long, char *);
obj_t _res_number__75___r5_control_features_6_4 = BUNSPEC;
static obj_t _values___r5_control_features_6_4(obj_t, obj_t);
static obj_t toplevel_init_63___r5_control_features_6_4();
static obj_t _call_with_values1119_167___r5_control_features_6_4(obj_t, obj_t, obj_t);
obj_t _res3__194___r5_control_features_6_4 = BUNSPEC;
obj_t _res2__167___r5_control_features_6_4 = BUNSPEC;
obj_t _res1__155___r5_control_features_6_4 = BUNSPEC;
extern obj_t call_with_values_2___r5_control_features_6_4(obj_t, obj_t);
static obj_t imported_modules_init_94___r5_control_features_6_4();
static obj_t require_initialization_114___r5_control_features_6_4 = BUNSPEC;
extern obj_t values___r5_control_features_6_4(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( call_with_values_env_146___r5_control_features_6_4, _call_with_values1119_167___r5_control_features_6_41121, _call_with_values1119_167___r5_control_features_6_4, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( values_env_201___r5_control_features_6_4, _values___r5_control_features_6_41122, va_generic_entry, _values___r5_control_features_6_4, -1 );


/* module-initialization */obj_t module_initialization_70___r5_control_features_6_4(long checksum_317, char * from_318)
{
if(CBOOL(require_initialization_114___r5_control_features_6_4)){
require_initialization_114___r5_control_features_6_4 = BBOOL(((bool_t)0));
imported_modules_init_94___r5_control_features_6_4();
toplevel_init_63___r5_control_features_6_4();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___r5_control_features_6_4()
{
_res_number__75___r5_control_features_6_4 = BINT(((long)1));
_res1__155___r5_control_features_6_4 = BUNSPEC;
_res2__167___r5_control_features_6_4 = BUNSPEC;
return (_res3__194___r5_control_features_6_4 = BUNSPEC,
BUNSPEC);
}


/* values */obj_t values___r5_control_features_6_4(obj_t args_1)
{
{
obj_t all_args_251_184;
all_args_251_184 = args_1;
{
bool_t test1004_185;
{
obj_t obj_297;
obj_297 = args_1;
test1004_185 = NULLP(obj_297);
}
if(test1004_185){
return (_res_number__75___r5_control_features_6_4 = BINT(((long)0)),
BUNSPEC);
}
 else {
bool_t test1005_186;
{
obj_t arg1010_192;
{
obj_t pair_298;
pair_298 = args_1;
arg1010_192 = CDR(pair_298);
}
test1005_186 = NULLP(arg1010_192);
}
if(test1005_186){
_res_number__75___r5_control_features_6_4 = BINT(((long)1));
{
obj_t pair_300;
pair_300 = args_1;
return CAR(pair_300);
}
}
 else {
obj_t res0_187;
{
obj_t pair_301;
pair_301 = args_1;
res0_187 = CAR(pair_301);
}
{
obj_t pair_302;
pair_302 = args_1;
args_1 = CDR(pair_302);
}
{
obj_t pair_303;
pair_303 = args_1;
_res1__155___r5_control_features_6_4 = CAR(pair_303);
}
{
obj_t pair_304;
pair_304 = args_1;
args_1 = CDR(pair_304);
}
{
bool_t test1006_188;
{
obj_t obj_305;
obj_305 = args_1;
test1006_188 = PAIRP(obj_305);
}
if(test1006_188){
{
obj_t pair_306;
pair_306 = args_1;
_res2__167___r5_control_features_6_4 = CAR(pair_306);
}
{
obj_t pair_307;
pair_307 = args_1;
args_1 = CDR(pair_307);
}
{
bool_t test1007_189;
{
obj_t obj_308;
obj_308 = args_1;
test1007_189 = PAIRP(obj_308);
}
if(test1007_189){
bool_t test1008_190;
{
obj_t arg1009_191;
{
obj_t pair_309;
pair_309 = args_1;
arg1009_191 = CDR(pair_309);
}
test1008_190 = PAIRP(arg1009_191);
}
if(test1008_190){
_res_number__75___r5_control_features_6_4 = BINT(((long)-1));
return all_args_251_184;
}
 else {
{
obj_t pair_311;
pair_311 = args_1;
_res3__194___r5_control_features_6_4 = CAR(pair_311);
}
_res_number__75___r5_control_features_6_4 = BINT(((long)4));
return res0_187;
}
}
 else {
_res_number__75___r5_control_features_6_4 = BINT(((long)3));
return res0_187;
}
}
}
 else {
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
return res0_187;
}
}
}
}
}
}
}


/* _values */obj_t _values___r5_control_features_6_4(obj_t env_312, obj_t args_313)
{
return values___r5_control_features_6_4(args_313);
}


/* call-with-values */obj_t call_with_values_2___r5_control_features_6_4(obj_t producer_2, obj_t consumer_3)
{
_res_number__75___r5_control_features_6_4 = BINT(((long)1));
{
obj_t res0_193;
res0_193 = PROCEDURE_ENTRY(producer_2)(producer_2, BEOA);
{
obj_t aux1003_195;
aux1003_195 = _res_number__75___r5_control_features_6_4;
if(INTEGERP(aux1003_195)){
switch ((long)CINT(aux1003_195)){
case ((long)-1) : 
return apply(consumer_3, res0_193);
break;
case ((long)0) : 
return PROCEDURE_ENTRY(consumer_3)(consumer_3, BEOA);
break;
case ((long)1) : 
return PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, BEOA);
break;
case ((long)2) : 
return PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, _res1__155___r5_control_features_6_4, BEOA);
break;
case ((long)3) : 
return PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, _res1__155___r5_control_features_6_4, _res2__167___r5_control_features_6_4, BEOA);
break;
case ((long)4) : 
return PROCEDURE_ENTRY(consumer_3)(consumer_3, res0_193, _res1__155___r5_control_features_6_4, _res2__167___r5_control_features_6_4, _res3__194___r5_control_features_6_4, BEOA);
break;
default: 
return apply(consumer_3, res0_193);
}
}
 else {
return apply(consumer_3, res0_193);
}
}
}
}


/* _call-with-values1119 */obj_t _call_with_values1119_167___r5_control_features_6_4(obj_t env_314, obj_t producer_315, obj_t consumer_316)
{
return call_with_values_2___r5_control_features_6_4(producer_315, consumer_316);
}


/* imported-modules-init */obj_t imported_modules_init_94___r5_control_features_6_4()
{
return module_initialization_70___error(((long)0), "__R5_CONTROL_FEATURES_6_4");
}

