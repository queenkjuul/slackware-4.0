/*===========================================================================*/
/*   (Llib/type.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t symbol1165___type = BUNSPEC;
static obj_t toplevel_init_63___type();
extern obj_t module_initialization_70___type(long, char *);
static obj_t require_initialization_114___type = BUNSPEC;
static obj_t cnst_init_137___type();
static obj_t *__cnst;



/* module-initialization */obj_t module_initialization_70___type(long checksum_499, char * from_500)
{
if(CBOOL(require_initialization_114___type)){
require_initialization_114___type = BBOOL(((bool_t)0));
cnst_init_137___type();
toplevel_init_63___type();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___type()
{
return (symbol1165___type = string_to_symbol("TOPLEVEL-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___type()
{
{
obj_t symbol1164_497;
symbol1164_497 = symbol1165___type;
{
PUSH_TRACE(symbol1164_497);
BUNSPEC;
POP_TRACE();
return BUNSPEC;
}
}
}

