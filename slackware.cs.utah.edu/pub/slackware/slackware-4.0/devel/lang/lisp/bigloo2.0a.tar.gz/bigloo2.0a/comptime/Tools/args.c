/*===========================================================================*/
/*   (Tools/args.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t make_n_proto_123_tools_args(obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t string_append(obj_t, obj_t);
extern bool_t sound_arity__135_tools_args(obj_t, obj_t);
static obj_t _arity_tools_args(obj_t, obj_t);
static obj_t _args___args_list_23_tools_args(obj_t, obj_t);
static obj_t make_fx_proto_153_tools_args(obj_t, long);
extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
static obj_t _make_n_proto_246_tools_args(obj_t, obj_t);
extern long list_length(obj_t);
static obj_t _sound_arity__157_tools_args(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_tools_args();
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
static obj_t library_modules_init_112_tools_args();
static obj_t loop_1198_tools_args(obj_t, obj_t);
extern int arity_tools_args(obj_t);
static obj_t _make_args_list_181_tools_args(obj_t, obj_t, obj_t, obj_t);
static obj_t make_args_name_104_tools_args(long);
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t ___arity_57_tools_args(obj_t, obj_t, obj_t);
static obj_t loop_tools_args(obj_t, obj_t, obj_t);
static obj_t _args_list__args__46_tools_args(obj_t, obj_t, obj_t);
static obj_t make_va_proto_225_tools_args(obj_t, long);
extern obj_t __arity_132_tools_args(obj_t, obj_t);
extern obj_t make_args_list_220_tools_args(obj_t, obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t args_list__args__33_tools_args(obj_t, obj_t);
static obj_t require_initialization_114_tools_args = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(sound_arity__env_18_tools_args, _sound_arity__157_tools_args1201, _sound_arity__157_tools_args, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_args_list_env_155_tools_args, _make_args_list_181_tools_args1202, _make_args_list_181_tools_args, 0L, 3);
DEFINE_EXPORT_PROCEDURE(arity_env_62_tools_args, _arity_tools_args1203, _arity_tools_args, 0L, 1);
DEFINE_EXPORT_PROCEDURE(args_list__args__env_63_tools_args, _args_list__args__46_tools_args1204, _args_list__args__46_tools_args, 0L, 2);
DEFINE_EXPORT_PROCEDURE(__arity_env_104_tools_args, ___arity_57_tools_args1205, ___arity_57_tools_args, 0L, 2);
DEFINE_EXPORT_PROCEDURE(args___args_list_env_210_tools_args, _args___args_list_23_tools_args1206, _args___args_list_23_tools_args, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_n_proto_env_229_tools_args, _make_n_proto_246_tools_args1207, _make_n_proto_246_tools_args, 0L, 1);
DEFINE_STRING(string1199_tools_args, string1199_tools_args1208, "A", 1);


/* module-initialization */ obj_t 
module_initialization_70_tools_args(long checksum_178, char *from_179)
{
   if (CBOOL(require_initialization_114_tools_args))
     {
	require_initialization_114_tools_args = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_args();
	imported_modules_init_94_tools_args();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_args()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TOOLS_ARGS");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "TOOLS_ARGS");
   return BUNSPEC;
}


/* arity */ int 
arity_tools_args(obj_t args_1)
{
   {
      long i_13;
      obj_t args_14;
      {
	 long aux_187;
	 i_13 = ((long) 0);
	 args_14 = args_1;
       loop_15:
	 if (NULLP(args_14))
	   {
	      aux_187 = i_13;
	   }
	 else
	   {
	      if (PAIRP(args_14))
		{
		   {
		      bool_t test1004_18;
		      {
			 obj_t aux_192;
			 aux_192 = dsssl_named_constant__188_tools_dsssl(CAR(args_14));
			 test1004_18 = CBOOL(aux_192);
		      }
		      if (test1004_18)
			{
			   long aux_197;
			   aux_197 = (i_13 + ((long) 1));
			   aux_187 = NEG(aux_197);
			}
		      else
			{
			   obj_t args_202;
			   long i_200;
			   i_200 = (i_13 + ((long) 1));
			   args_202 = CDR(args_14);
			   args_14 = args_202;
			   i_13 = i_200;
			   goto loop_15;
			}
		   }
		}
	      else
		{
		   {
		      long aux_204;
		      aux_204 = (i_13 + ((long) 1));
		      aux_187 = NEG(aux_204);
		   }
		}
	   }
	 return (int) (aux_187);
      }
   }
}


/* _arity */ obj_t 
_arity_tools_args(obj_t env_157, obj_t args_158)
{
   {
      int aux_208;
      aux_208 = arity_tools_args(args_158);
      return BINT(aux_208);
   }
}


/* args*->args-list */ obj_t 
args___args_list_50_tools_args(obj_t exp_2)
{
   if (NULLP(exp_2))
     {
	return BNIL;
     }
   else
     {
	if (PAIRP(exp_2))
	  {
	     {
		obj_t arg1014_26;
		obj_t arg1016_27;
		arg1014_26 = CAR(exp_2);
		arg1016_27 = args___args_list_50_tools_args(CDR(exp_2));
		return MAKE_PAIR(arg1014_26, arg1016_27);
	     }
	  }
	else
	  {
	     {
		obj_t list1019_29;
		list1019_29 = MAKE_PAIR(exp_2, BNIL);
		return list1019_29;
	     }
	  }
     }
}


/* _args*->args-list */ obj_t 
_args___args_list_23_tools_args(obj_t env_159, obj_t exp_160)
{
   return args___args_list_50_tools_args(exp_160);
}


/* args-list->args* */ obj_t 
args_list__args__33_tools_args(obj_t list_3, obj_t arity_4)
{
   {
      bool_t test_221;
      {
	 long aux_222;
	 aux_222 = (long) CINT(arity_4);
	 test_221 = (aux_222 >= ((long) 0));
      }
      if (test_221)
	{
	   return list_3;
	}
      else
	{
	   bool_t test_225;
	   {
	      long aux_226;
	      aux_226 = (long) CINT(arity_4);
	      test_225 = (aux_226 == ((long) -1));
	   }
	   if (test_225)
	     {
		return CAR(list_3);
	     }
	   else
	     {
		return loop_1198_tools_args(list_3, arity_4);
	     }
	}
   }
}


/* loop_1198 */ obj_t 
loop_1198_tools_args(obj_t list_33, obj_t arity_34)
{
   {
      bool_t test_231;
      {
	 long aux_232;
	 aux_232 = (long) CINT(arity_34);
	 test_231 = (aux_232 == ((long) -1));
      }
      if (test_231)
	{
	   return CAR(list_33);
	}
      else
	{
	   obj_t arg1025_37;
	   obj_t arg1032_38;
	   arg1025_37 = CAR(list_33);
	   {
	      obj_t aux_237;
	      {
		 long aux_239;
		 {
		    long aux_240;
		    aux_240 = (long) CINT(arity_34);
		    aux_239 = (aux_240 + ((long) 1));
		 }
		 aux_237 = BINT(aux_239);
	      }
	      arg1032_38 = loop_1198_tools_args(CDR(list_33), aux_237);
	   }
	   return MAKE_PAIR(arg1025_37, arg1032_38);
	}
   }
}


/* _args-list->args* */ obj_t 
_args_list__args__46_tools_args(obj_t env_161, obj_t list_162, obj_t arity_163)
{
   return args_list__args__33_tools_args(list_162, arity_163);
}


/* sound-arity? */ bool_t 
sound_arity__135_tools_args(obj_t arity_5, obj_t args_6)
{
   {
      long len_41;
      len_41 = list_length(args_6);
      {
	 bool_t test_248;
	 {
	    long aux_249;
	    aux_249 = (long) CINT(arity_5);
	    test_248 = (aux_249 >= ((long) 0));
	 }
	 if (test_248)
	   {
	      long aux_252;
	      aux_252 = (long) CINT(arity_5);
	      return (aux_252 == len_41);
	   }
	 else
	   {
	      long aux_259;
	      long aux_255;
	      aux_259 = (len_41 + ((long) 1));
	      {
		 long aux_256;
		 aux_256 = (long) CINT(arity_5);
		 aux_255 = NEG(aux_256);
	      }
	      return (aux_255 <= aux_259);
	   }
      }
   }
}


/* _sound-arity? */ obj_t 
_sound_arity__157_tools_args(obj_t env_164, obj_t arity_165, obj_t args_166)
{
   {
      bool_t aux_262;
      aux_262 = sound_arity__135_tools_args(arity_165, args_166);
      return BBOOL(aux_262);
   }
}


/* make-args-list */ obj_t 
make_args_list_220_tools_args(obj_t args_7, obj_t nil_8, obj_t cons_9)
{
   return loop_tools_args(nil_8, cons_9, args_7);
}


/* loop */ obj_t 
loop_tools_args(obj_t nil_177, obj_t cons_176, obj_t args_45)
{
   if (NULLP(args_45))
     {
	return nil_177;
     }
   else
     {
	obj_t arg1077_48;
	obj_t arg1137_49;
	arg1077_48 = CAR(args_45);
	arg1137_49 = loop_tools_args(nil_177, cons_176, CDR(args_45));
	{
	   obj_t list1143_51;
	   {
	      obj_t arg1144_52;
	      {
		 obj_t arg1145_53;
		 arg1145_53 = MAKE_PAIR(BNIL, BNIL);
		 arg1144_52 = MAKE_PAIR(arg1137_49, arg1145_53);
	      }
	      list1143_51 = MAKE_PAIR(arg1077_48, arg1144_52);
	   }
	   return cons__138___r4_pairs_and_lists_6_3(cons_176, list1143_51);
	}
     }
}


/* _make-args-list */ obj_t 
_make_args_list_181_tools_args(obj_t env_167, obj_t args_168, obj_t nil_169, obj_t cons_170)
{
   return make_args_list_220_tools_args(args_168, nil_169, cons_170);
}


/* make-n-proto */ obj_t 
make_n_proto_123_tools_args(obj_t n_10)
{
   {
      bool_t test_276;
      {
	 long aux_277;
	 aux_277 = (long) CINT(n_10);
	 test_276 = (aux_277 < ((long) 0));
      }
      if (test_276)
	{
	   return make_va_proto_225_tools_args(n_10, ((long) 0));
	}
      else
	{
	   return make_fx_proto_153_tools_args(n_10, ((long) 0));
	}
   }
}


/* make-fx-proto */ obj_t 
make_fx_proto_153_tools_args(obj_t n_60, long count_61)
{
   {
      bool_t test_282;
      {
	 long aux_283;
	 aux_283 = (long) CINT(n_60);
	 test_282 = (aux_283 == ((long) 0));
      }
      if (test_282)
	{
	   return BNIL;
	}
      else
	{
	   obj_t arg1161_64;
	   obj_t arg1163_65;
	   arg1161_64 = make_args_name_104_tools_args(count_61);
	   {
	      obj_t aux_287;
	      {
		 long aux_288;
		 {
		    long aux_289;
		    aux_289 = (long) CINT(n_60);
		    aux_288 = (aux_289 - ((long) 1));
		 }
		 aux_287 = BINT(aux_288);
	      }
	      arg1163_65 = make_fx_proto_153_tools_args(aux_287, (count_61 + ((long) 1)));
	   }
	   return MAKE_PAIR(arg1161_64, arg1163_65);
	}
   }
}


/* make-args-name */ obj_t 
make_args_name_104_tools_args(long n_76)
{
   {
      obj_t arg1193_78;
      {
	 obj_t aux_296;
	 {
	    char *aux_297;
	    aux_297 = integer__string_135___r4_numbers_6_5_fixnum(n_76, BNIL);
	    aux_296 = string_to_bstring(aux_297);
	 }
	 arg1193_78 = string_append(string1199_tools_args, aux_296);
      }
      {
	 char *aux_301;
	 aux_301 = BSTRING_TO_STRING(arg1193_78);
	 return string_to_symbol(aux_301);
      }
   }
}


/* make-va-proto */ obj_t 
make_va_proto_225_tools_args(obj_t n_68, long count_69)
{
   {
      bool_t test_304;
      {
	 long aux_305;
	 aux_305 = (long) CINT(n_68);
	 test_304 = (aux_305 == ((long) -1));
      }
      if (test_304)
	{
	   return make_args_name_104_tools_args(count_69);
	}
      else
	{
	   obj_t arg1187_72;
	   obj_t arg1188_73;
	   arg1187_72 = make_args_name_104_tools_args(count_69);
	   {
	      obj_t aux_310;
	      {
		 long aux_311;
		 {
		    long aux_312;
		    aux_312 = (long) CINT(n_68);
		    aux_311 = (aux_312 + ((long) 1));
		 }
		 aux_310 = BINT(aux_311);
	      }
	      arg1188_73 = make_va_proto_225_tools_args(aux_310, (count_69 + ((long) 1)));
	   }
	   return MAKE_PAIR(arg1187_72, arg1188_73);
	}
   }
}


/* _make-n-proto */ obj_t 
_make_n_proto_246_tools_args(obj_t env_171, obj_t n_172)
{
   return make_n_proto_123_tools_args(n_172);
}


/* +-arity */ obj_t 
__arity_132_tools_args(obj_t arity_11, obj_t add_12)
{
   {
      bool_t test_320;
      {
	 long aux_321;
	 aux_321 = (long) CINT(arity_11);
	 test_320 = (aux_321 >= ((long) 0));
      }
      if (test_320)
	{
	   long aux_324;
	   {
	      long aux_327;
	      long aux_325;
	      aux_327 = (long) CINT(arity_11);
	      aux_325 = (long) CINT(add_12);
	      aux_324 = (aux_325 + aux_327);
	   }
	   return BINT(aux_324);
	}
      else
	{
	   long aux_331;
	   {
	      long aux_334;
	      long aux_332;
	      aux_334 = (long) CINT(add_12);
	      aux_332 = (long) CINT(arity_11);
	      aux_331 = (aux_332 - aux_334);
	   }
	   return BINT(aux_331);
	}
   }
}


/* _+-arity */ obj_t 
___arity_57_tools_args(obj_t env_173, obj_t arity_174, obj_t add_175)
{
   return __arity_132_tools_args(arity_174, add_175);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_args()
{
   return module_initialization_70_tools_dsssl(((long) 0), "TOOLS_ARGS");
}
