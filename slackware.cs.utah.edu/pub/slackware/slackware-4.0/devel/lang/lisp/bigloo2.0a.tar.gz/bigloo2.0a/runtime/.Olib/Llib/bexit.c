/*===========================================================================*/
/*   (Llib/bexit.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _unwind_until__238___bexit(obj_t, obj_t, obj_t);
extern obj_t unwind_stack_until(obj_t, obj_t, obj_t, obj_t);
static obj_t symbol1233___bexit = BUNSPEC;
static obj_t symbol1228___bexit = BUNSPEC;
static obj_t symbol1227___bexit = BUNSPEC;
static obj_t symbol1226___bexit = BUNSPEC;
static obj_t symbol1225___bexit = BUNSPEC;
static obj_t _protected_val__170___bexit = BUNSPEC;
static obj_t symbol1221___bexit = BUNSPEC;
static obj_t symbol1218___bexit = BUNSPEC;
static obj_t symbol1217___bexit = BUNSPEC;
static obj_t symbol1216___bexit = BUNSPEC;
static obj_t symbol1215___bexit = BUNSPEC;
obj_t exitd_top = BUNSPEC;
static obj_t list1224___bexit = BUNSPEC;
static obj_t toplevel_init_63___bexit();
extern bool_t unwind_stack_value_p(obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _val_from_exit__167___bexit(obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _unwind_stack_until__173___bexit(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _unwind_stack_value__112___bexit(obj_t, obj_t);
static obj_t imported_modules_init_94___bexit();
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114___bexit = BUNSPEC;
static obj_t cnst_init_137___bexit();
obj_t exitd_stamp = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( unwind_until__env_204___bexit, _unwind_until__238___bexit1235, _unwind_until__238___bexit, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( val_from_exit__env_189___bexit, _val_from_exit__167___bexit1236, _val_from_exit__167___bexit, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unwind_stack_value__env_181___bexit, _unwind_stack_value__112___bexit1237, _unwind_stack_value__112___bexit, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unwind_stack_until__env_164___bexit, _unwind_stack_until__173___bexit1238, _unwind_stack_until__173___bexit, 0L, 4 );
DEFINE_STRING( string1232___bexit, string1232___bexit1239, "LONG", 4 );
DEFINE_STRING( string1231___bexit, string1231___bexit1240, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1229___bexit, string1229___bexit1241, "unwind-until!", 13 );
DEFINE_STRING( string1230___bexit, string1230___bexit1242, "exit out of dynamic scope", 25 );
DEFINE_STRING( string1223___bexit, string1223___bexit1243, "UNWIND-STACK-UNTIL!:Wrong number of arguments", 45 );
DEFINE_STRING( string1222___bexit, string1222___bexit1244, "PROCEDURE", 9 );
DEFINE_STRING( string1219___bexit, string1219___bexit1245, "PAIR", 4 );
DEFINE_STRING( string1220___bexit, string1220___bexit1246, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/bexit.scm", 58 );


/* module-initialization */obj_t module_initialization_70___bexit(long checksum_457, char * from_458)
{
if(CBOOL(require_initialization_114___bexit)){
require_initialization_114___bexit = BBOOL(((bool_t)0));
cnst_init_137___bexit();
imported_modules_init_94___bexit();
toplevel_init_63___bexit();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___bexit()
{
symbol1215___bexit = string_to_symbol("TOPLEVEL-INIT");
symbol1216___bexit = string_to_symbol("VAL-FROM-EXIT?");
symbol1217___bexit = string_to_symbol("UNWIND-STACK-VALUE?");
symbol1218___bexit = string_to_symbol("UNWIND-UNTIL!");
symbol1221___bexit = string_to_symbol("UNWIND-STACK-UNTIL!");
symbol1225___bexit = string_to_symbol("FUNCALL");
symbol1226___bexit = string_to_symbol("proc");
symbol1227___bexit = string_to_symbol("val");
{
obj_t aux_473;
{
obj_t aux_474;
{
obj_t aux_475;
aux_475 = MAKE_PAIR(symbol1227___bexit, BNIL);
aux_474 = MAKE_PAIR(symbol1226___bexit, aux_475);
}
aux_473 = MAKE_PAIR(symbol1226___bexit, aux_474);
}
list1224___bexit = MAKE_PAIR(symbol1225___bexit, aux_473);
}
symbol1228___bexit = string_to_symbol("_");
return (symbol1233___bexit = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___bexit()
{
{
obj_t symbol1171_401;
symbol1171_401 = symbol1215___bexit;
{
PUSH_TRACE(symbol1171_401);
BUNSPEC;
{
obj_t aux1170_402;
exitd_top = BFALSE;
exitd_stamp = BINT(((long)0));
aux1170_402 = (_protected_val__170___bexit = MAKE_PAIR(BUNSPEC, BUNSPEC),
BUNSPEC);
POP_TRACE();
return aux1170_402;
}
}
}
}


/* val-from-exit? */obj_t val_from_exit__100___bexit(obj_t val_1)
{
{
obj_t symbol1173_403;
symbol1173_403 = symbol1216___bexit;
{
PUSH_TRACE(symbol1173_403);
BUNSPEC;
{
obj_t aux1172_404;
{
bool_t aux_487;
aux_487 = (val_1==_protected_val__170___bexit);
aux1172_404 = BBOOL(aux_487);
}
POP_TRACE();
return aux1172_404;
}
}
}
}


/* _val-from-exit? */obj_t _val_from_exit__167___bexit(obj_t env_413, obj_t val_414)
{
return val_from_exit__100___bexit(val_414);
}


/* unwind-stack-value? */bool_t unwind_stack_value_p(obj_t val_2)
{
{
obj_t symbol1175_405;
symbol1175_405 = symbol1217___bexit;
{
PUSH_TRACE(symbol1175_405);
BUNSPEC;
{
bool_t aux1174_406;
aux1174_406 = (val_2==_protected_val__170___bexit);
POP_TRACE();
return aux1174_406;
}
}
}
}


/* _unwind-stack-value? */obj_t _unwind_stack_value__112___bexit(obj_t env_415, obj_t val_416)
{
{
bool_t aux_495;
aux_495 = unwind_stack_value_p(val_416);
return BBOOL(aux_495);
}
}


/* unwind-until! */obj_t unwind_until__178___bexit(obj_t exitd_3, obj_t val_4)
{
{
obj_t symbol1177_407;
symbol1177_407 = symbol1218___bexit;
{
PUSH_TRACE(symbol1177_407);
BUNSPEC;
{
obj_t aux1176_408;
{
bool_t test1004_211;
test1004_211 = PAIRP(exitd_3);
if(test1004_211){
obj_t arg1005_212;
obj_t arg1006_213;
{
obj_t pair_382;
if(test1004_211){
pair_382 = exitd_3;
}
 else {
bigloo_type_error_location_103___error(symbol1218___bexit, string1219___bexit, exitd_3, string1220___bexit, BINT(((long)4726)));
exit( -1 );}
arg1005_212 = CAR(pair_382);
}
{
obj_t pair_383;
if(test1004_211){
pair_383 = exitd_3;
}
 else {
bigloo_type_error_location_103___error(symbol1218___bexit, string1219___bexit, exitd_3, string1220___bexit, BINT(((long)4745)));
exit( -1 );}
arg1006_213 = CDR(pair_383);
}
aux1176_408 = unwind_stack_until(arg1005_212, BFALSE, val_4, arg1006_213);
}
 else {
aux1176_408 = unwind_stack_until(exitd_3, BFALSE, val_4, BFALSE);
}
}
POP_TRACE();
return aux1176_408;
}
}
}
}


/* _unwind-until! */obj_t _unwind_until__238___bexit(obj_t env_417, obj_t exitd_418, obj_t val_419)
{
return unwind_until__178___bexit(exitd_418, val_419);
}


/* unwind-stack-until! */obj_t unwind_stack_until(obj_t exitd_5, obj_t estamp_6, obj_t val_7, obj_t proc_8)
{
{
obj_t symbol1179_409;
symbol1179_409 = symbol1221___bexit;
{
PUSH_TRACE(symbol1179_409);
BUNSPEC;
{
obj_t aux1178_410;
{
loop_214:
{
bool_t test1007_215;
{
obj_t obj1_384;
obj1_384 = exitd_top;
test1007_215 = (obj1_384==BFALSE);
}
if(test1007_215){
bool_t test1008_216;
test1008_216 = PROCEDUREP(proc_8);
if(test1008_216){
obj_t fun_443;
if(test1008_216){
fun_443 = proc_8;
}
 else {
bigloo_type_error_location_103___error(symbol1221___bexit, string1222___bexit, proc_8, string1220___bexit, BINT(((long)5528)));
exit( -1 );}
{
bool_t test1207_450;
test1207_450 = PROCEDURE_CORRECT_ARITYP(fun_443, ((long)1));
if(test1207_450){
aux1178_410 = PROCEDURE_ENTRY(fun_443)(proc_8, val_7, BEOA);
}
 else {
error_location_112___error(string1223___bexit, list1224___bexit, fun_443, string1220___bexit, BINT(((long)5528)));
FAILURE(symbol1228___bexit,symbol1228___bexit,symbol1228___bexit);}
}
}
 else {
aux1178_410 = debug_error_location_199___error(string1229___bexit, string1230___bexit, BUNSPEC, string1231___bexit, BINT(((long)7610)));
}
}
 else {
obj_t exit_top_38_217;
exit_top_38_217 = exitd_top;
POP_EXIT();
{
bool_t test1009_218;
if((exit_top_38_217==exitd_5)){
bool_t _ortest_1002_222;
if(INTEGERP(estamp_6)){
_ortest_1002_222 = ((bool_t)0);
}
 else {
_ortest_1002_222 = ((bool_t)1);
}
if(_ortest_1002_222){
test1009_218 = _ortest_1002_222;
}
 else {
obj_t arg1013_223;
arg1013_223 = EXITD_STAMP(exit_top_38_217);
{
long n1_393;
long n2_394;
n1_393 = (long)CINT(arg1013_223);
{
obj_t aux_541;
if(INTEGERP(estamp_6)){
aux_541 = estamp_6;
}
 else {
bigloo_type_error_location_103___error(symbol1221___bexit, string1232___bexit, estamp_6, string1220___bexit, BINT(((long)5761)));
exit( -1 );}
n2_394 = (long)CINT(aux_541);
}
test1009_218 = (n1_393==n2_394);
}
}
}
 else {
test1009_218 = ((bool_t)0);
}
if(test1009_218){
JUMP_EXIT( EXITD_TO_EXIT(exit_top_38_217),val_7);
}
 else {
bool_t test1010_219;
test1010_219 = EXITD_USERP(exit_top_38_217);
if(test1010_219){
goto loop_214;
}
 else {
{
obj_t arg1011_220;
arg1011_220 = MAKE_PAIR(exitd_5, proc_8);
SET_CAR(_protected_val__170___bexit, arg1011_220);
}
SET_CDR(_protected_val__170___bexit, val_7);
JUMP_EXIT( EXITD_TO_EXIT(exit_top_38_217),_protected_val__170___bexit);
}
}
}
}
}
}
POP_TRACE();
return aux1178_410;
}
}
}
}


/* _unwind-stack-until! */obj_t _unwind_stack_until__173___bexit(obj_t env_420, obj_t exitd_421, obj_t estamp_422, obj_t val_423, obj_t proc_424)
{
return unwind_stack_until(exitd_421, estamp_422, val_423, proc_424);
}


/* imported-modules-init */obj_t imported_modules_init_94___bexit()
{
{
obj_t symbol1181_411;
symbol1181_411 = symbol1233___bexit;
{
PUSH_TRACE(symbol1181_411);
BUNSPEC;
{
obj_t aux1180_412;
aux1180_412 = module_initialization_70___error(((long)0), "__BEXIT");
POP_TRACE();
return aux1180_412;
}
}
}
}

