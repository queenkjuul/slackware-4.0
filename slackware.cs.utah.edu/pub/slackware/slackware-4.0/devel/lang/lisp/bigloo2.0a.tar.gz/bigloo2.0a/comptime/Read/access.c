/*===========================================================================*/
/*   (Read/access.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t _access_table__91_engine_param;
static obj_t body1004_read_access(obj_t);
extern obj_t exitd_top;
extern obj_t warning___error(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1046_read_access(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_read_access(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_engine_engine(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern bool_t fexists(char *);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t imported_modules_init_94_read_access();
static obj_t do_read_access_file_118_read_access(obj_t);
static obj_t handler_read_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1003_read_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_read_access();
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t add_access__140_read_access(obj_t, obj_t);
static obj_t _read_access_file_50_read_access(obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t _access_file__194_engine_param;
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t read_access_file_42_read_access();
extern obj_t close_input_port(obj_t);
static obj_t arg1055_read_access(obj_t);
static obj_t arg1053_read_access(obj_t);
extern obj_t remove_error_handler__102___error();
extern obj_t read___reader(obj_t);
static obj_t escape_read_access(obj_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_read_access = BUNSPEC;
static obj_t _add_access_1201_153_read_access(obj_t, obj_t, obj_t);
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
static obj_t cnst_init_137_read_access();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(add_access__env_143_read_access, _add_access_1201_153_read_access1215, _add_access_1201_153_read_access, 0L, 2);
DEFINE_EXPORT_PROCEDURE(read_access_file_env_73_read_access, _read_access_file_50_read_access1216, _read_access_file_50_read_access, 0L, 0);
DEFINE_STRING(string1208_read_access, string1208_read_access1217, "DONE ", 5);
DEFINE_STRING(string1207_read_access, string1207_read_access1218, "Illegal access file format", 26);
DEFINE_STRING(string1206_read_access, string1206_read_access1219, "Can't find access file", 22);
DEFINE_STRING(string1205_read_access, string1205_read_access1220, "Can't open access file", 22);
DEFINE_STRING(string1204_read_access, string1204_read_access1221, "read-access-file", 16);
DEFINE_STRING(string1203_read_access, string1203_read_access1222, "add-access!", 11);
DEFINE_STRING(string1202_read_access, string1202_read_access1223, "access redefinition -- ", 23);


/* module-initialization */ obj_t 
module_initialization_70_read_access(long checksum_182, char *from_183)
{
   if (CBOOL(require_initialization_114_read_access))
     {
	require_initialization_114_read_access = BBOOL(((bool_t) 0));
	library_modules_init_112_read_access();
	cnst_init_137_read_access();
	imported_modules_init_94_read_access();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_read_access()
{
   module_initialization_70___bexit(((long) 0), "READ_ACCESS");
   module_initialization_70___error(((long) 0), "READ_ACCESS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "READ_ACCESS");
   module_initialization_70___r4_control_features_6_9(((long) 0), "READ_ACCESS");
   module_initialization_70___reader(((long) 0), "READ_ACCESS");
   module_initialization_70___r4_equivalence_6_2(((long) 0), "READ_ACCESS");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "READ_ACCESS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_read_access()
{
   {
      obj_t cnst_port_138_174;
      cnst_port_138_174 = open_input_string(string1208_read_access);
      {
	 long i_175;
	 i_175 = ((long) 0);
       loop_176:
	 {
	    bool_t test1209_177;
	    test1209_177 = (i_175 == ((long) -1));
	    if (test1209_177)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1210_178;
		    {
		       obj_t list1211_179;
		       {
			  obj_t arg1213_180;
			  arg1213_180 = BNIL;
			  list1211_179 = MAKE_PAIR(cnst_port_138_174, arg1213_180);
		       }
		       arg1210_178 = read___reader(list1211_179);
		    }
		    CNST_TABLE_SET(i_175, arg1210_178);
		 }
		 {
		    int aux_181;
		    {
		       long aux_203;
		       aux_203 = (i_175 - ((long) 1));
		       aux_181 = (int) (aux_203);
		    }
		    {
		       long i_206;
		       i_206 = (long) (aux_181);
		       i_175 = i_206;
		       goto loop_176;
		    }
		 }
	      }
	 }
      }
   }
}


/* add-access! */ obj_t 
add_access__140_read_access(obj_t module_1, obj_t files_2)
{
   {
      obj_t b_4;
      b_4 = assq___r4_pairs_and_lists_6_3(module_1, _access_table__91_engine_param);
      if (CBOOL(b_4))
	{
	   if (equal__25___r4_equivalence_6_2(CDR(b_4), files_2))
	     {
		return CNST_TABLE_REF(((long) 0));
	     }
	   else
	     {
		obj_t list1011_6;
		{
		   obj_t arg1016_8;
		   {
		      obj_t arg1020_10;
		      arg1020_10 = MAKE_PAIR(module_1, BNIL);
		      arg1016_8 = MAKE_PAIR(string1202_read_access, arg1020_10);
		   }
		   list1011_6 = MAKE_PAIR(string1203_read_access, arg1016_8);
		}
		return warning___error(list1011_6);
	     }
	}
      else
	{
	   obj_t arg1034_13;
	   arg1034_13 = MAKE_PAIR(module_1, files_2);
	   {
	      obj_t obj2_102;
	      obj2_102 = _access_table__91_engine_param;
	      return (_access_table__91_engine_param = MAKE_PAIR(arg1034_13, obj2_102),
		 BUNSPEC);
	   }
	}
   }
}


/* _add-access!1201 */ obj_t 
_add_access_1201_153_read_access(obj_t env_130, obj_t module_131, obj_t files_132)
{
   return add_access__140_read_access(module_131, files_132);
}


/* read-access-file */ obj_t 
read_access_file_42_read_access()
{
   {
      bool_t test1035_14;
      {
	 obj_t obj_103;
	 obj_103 = _access_file__194_engine_param;
	 test1035_14 = STRINGP(obj_103);
      }
      if (test1035_14)
	{
	   bool_t test1037_15;
	   {
	      char *name_104;
	      name_104 = BSTRING_TO_STRING(_access_file__194_engine_param);
	      test1037_15 = fexists(name_104);
	   }
	   if (test1037_15)
	     {
		{
		   obj_t port_16;
		   port_16 = open_input_file_61___r4_ports_6_10_1(_access_file__194_engine_param, BNIL);
		   if (INPUT_PORTP(port_16))
		     {
			do_read_access_file_118_read_access(port_16);
			return close_input_port(port_16);
		     }
		   else
		     {
			return user_error_151_tools_error(string1204_read_access, string1205_read_access, _access_file__194_engine_param, BNIL);
		     }
		}
	     }
	   else
	     {
		return user_error_151_tools_error(string1204_read_access, string1206_read_access, _access_file__194_engine_param, BNIL);
	     }
	}
      else
	{
	   return CNST_TABLE_REF(((long) 0));
	}
   }
}


/* _read-access-file */ obj_t 
_read_access_file_50_read_access(obj_t env_133)
{
   return read_access_file_42_read_access();
}


/* do-read-access-file */ obj_t 
do_read_access_file_118_read_access(obj_t port_3)
{
   {
      obj_t handler_139;
      handler_139 = make_fx_procedure(handler_read_access, ((long) 4), ((long) 1));
      PROCEDURE_SET(handler_139, ((long) 0), port_3);
      {
	 obj_t armed1005_26;
	 obj_t handler1002_27;
	 armed1005_26 = MAKE_CELL(BUNSPEC);
	 handler1002_27 = MAKE_CELL(BUNSPEC);
	 {
	    obj_t body1004_135;
	    obj_t rhandler1003_137;
	    body1004_135 = make_fx_procedure(body1004_read_access, ((long) 0), ((long) 1));
	    rhandler1003_137 = make_fx_procedure(rhandler1003_read_access, ((long) 4), ((long) 2));
	    PROCEDURE_SET(body1004_135, ((long) 0), port_3);
	    PROCEDURE_SET(rhandler1003_137, ((long) 0), armed1005_26);
	    PROCEDURE_SET(rhandler1003_137, ((long) 1), handler1002_27);
	    CELL_SET(handler1002_27, handler_139);
	    CELL_SET(armed1005_26, BTRUE);
	    return handling_function1046_read_access(body1004_135, rhandler1003_137, handler1002_27, armed1005_26);
	 }
      }
   }
}


/* handling_function1046 */ obj_t 
handling_function1046_read_access(obj_t body1004_173, obj_t rhandler1003_172, obj_t handler1002_171, obj_t armed1005_170)
{
   jmp_buf jmpbuf;
   obj_t an_exit1006_31;
   if (SET_EXIT(an_exit1006_31))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1006_31 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1006_31, ((bool_t) 1));
	   {
	      obj_t an_exitd1007_32;
	      an_exitd1007_32 = exitd_top;
	      {
		 obj_t escape_136;
		 escape_136 = make_fx_procedure(escape_read_access, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_136, ((long) 0), an_exitd1007_32);
		 {
		    obj_t res1009_35;
		    {
		       obj_t arg1055_134;
		       obj_t arg1053_138;
		       arg1055_134 = make_fx_procedure(arg1055_read_access, ((long) 0), ((long) 1));
		       arg1053_138 = make_fx_procedure(arg1053_read_access, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1055_134, ((long) 0), armed1005_170);
		       PROCEDURE_SET(arg1053_138, ((long) 0), an_exitd1007_32);
		       PROCEDURE_SET(arg1053_138, ((long) 1), armed1005_170);
		       PROCEDURE_SET(arg1053_138, ((long) 2), handler1002_171);
		       PROCEDURE_SET(arg1053_138, ((long) 3), rhandler1003_172);
		       PROCEDURE_SET(arg1053_138, ((long) 4), escape_136);
		       res1009_35 = dynamic_wind_31___r4_control_features_6_9(arg1053_138, body1004_173, arg1055_134);
		    }
		    POP_EXIT();
		    return res1009_35;
		 }
	      }
	   }
	}
     }
}


/* arg1055 */ obj_t 
arg1055_read_access(obj_t env_140)
{
   {
      obj_t armed1005_141;
      armed1005_141 = PROCEDURE_REF(env_140, ((long) 0));
      {
	 {
	    bool_t test_260;
	    {
	       obj_t aux_261;
	       aux_261 = CELL_REF(armed1005_141);
	       test_260 = CBOOL(aux_261);
	    }
	    if (test_260)
	      {
		 CELL_SET(armed1005_141, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1004 */ obj_t 
body1004_read_access(obj_t env_143)
{
   {
      obj_t port_144;
      port_144 = PROCEDURE_REF(env_143, ((long) 0));
      {
	 {
	    obj_t obj_48;
	    {
	       obj_t list1197_93;
	       {
		  obj_t arg1199_94;
		  arg1199_94 = MAKE_PAIR(BTRUE, BNIL);
		  list1197_93 = MAKE_PAIR(port_144, arg1199_94);
	       }
	       obj_48 = read___reader(list1197_93);
	    }
	    {
	       obj_t eof_49;
	       {
		  obj_t list1195_91;
		  list1195_91 = MAKE_PAIR(port_144, BNIL);
		  eof_49 = read___reader(list1195_91);
	       }
	       {
		  {
		     bool_t test1067_50;
		     test1067_50 = EOF_OBJECTP(eof_49);
		     if (test1067_50)
		       {
			  obj_t obj_51;
			  obj_51 = obj_48;
			loop_52:
			  if (NULLP(obj_51))
			    {
			       return CNST_TABLE_REF(((long) 0));
			    }
			  else
			    {
			       obj_t m_54;
			       obj_t f_55;
			       obj_t fs_56;
			       {
				  obj_t e_103_175_59;
				  e_103_175_59 = CAR(obj_51);
				  if (PAIRP(e_103_175_59))
				    {
				       obj_t car_110_123_61;
				       obj_t cdr_111_186_62;
				       car_110_123_61 = CAR(e_103_175_59);
				       cdr_111_186_62 = CDR(e_103_175_59);
				       if (SYMBOLP(car_110_123_61))
					 {
					    if (PAIRP(cdr_111_186_62))
					      {
						 obj_t car_117_76_65;
						 car_117_76_65 = CAR(cdr_111_186_62);
						 if (STRINGP(car_117_76_65))
						   {
						      m_54 = car_110_123_61;
						      f_55 = car_117_76_65;
						      fs_56 = CDR(cdr_111_186_62);
						      {
							 obj_t fs_68;
							 obj_t fnames_69;
							 {
							    obj_t arg1137_71;
							    {
							       obj_t list1138_72;
							       list1138_72 = MAKE_PAIR(f_55, BNIL);
							       arg1137_71 = list1138_72;
							    }
							    fs_68 = fs_56;
							    fnames_69 = arg1137_71;
							  loop_70:
							    if (NULLP(fs_68))
							      {
								 {
								    obj_t arg1144_75;
								    arg1144_75 = reverse__39___r4_pairs_and_lists_6_3(fnames_69);
								    add_access__140_read_access(m_54, arg1144_75);
								 }
							      }
							    else
							      {
								 bool_t test_292;
								 {
								    obj_t aux_293;
								    aux_293 = CAR(fs_68);
								    test_292 = STRINGP(aux_293);
								 }
								 if (test_292)
								   {
								      {
									 obj_t arg1150_77;
									 obj_t arg1157_78;
									 arg1150_77 = CDR(fs_68);
									 {
									    obj_t aux_297;
									    aux_297 = CAR(fs_68);
									    arg1157_78 = MAKE_PAIR(aux_297, fnames_69);
									 }
									 {
									    obj_t fnames_301;
									    obj_t fs_300;
									    fs_300 = arg1150_77;
									    fnames_301 = arg1157_78;
									    fnames_69 = fnames_301;
									    fs_68 = fs_300;
									    goto loop_70;
									 }
								      }
								   }
								 else
								   {
								      user_error_151_tools_error(string1204_read_access, string1207_read_access, CAR(obj_51), BNIL);
								   }
							      }
							 }
						      }
						      {
							 obj_t obj_304;
							 obj_304 = CDR(obj_51);
							 obj_51 = obj_304;
							 goto loop_52;
						      }
						   }
						 else
						   {
						    tag_102_241_58:
						      return user_error_151_tools_error(string1204_read_access, string1207_read_access, CAR(obj_51), BNIL);
						   }
					      }
					    else
					      {
						 goto tag_102_241_58;
					      }
					 }
				       else
					 {
					    goto tag_102_241_58;
					 }
				    }
				  else
				    {
				       goto tag_102_241_58;
				    }
			       }
			    }
		       }
		     else
		       {
			  return user_error_151_tools_error(string1204_read_access, string1207_read_access, eof_49, BNIL);
		       }
		  }
	       }
	    }
	 }
      }
   }
}


/* arg1053 */ obj_t 
arg1053_read_access(obj_t env_145)
{
   {
      obj_t rhandler1003_149;
      obj_t escape_150;
      rhandler1003_149 = PROCEDURE_REF(env_145, ((long) 3));
      escape_150 = PROCEDURE_REF(env_145, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1003_149, escape_150);
      }
   }
}


/* escape */ obj_t 
escape_read_access(obj_t env_151, obj_t val1008_153)
{
   {
      obj_t an_exitd1007_152;
      an_exitd1007_152 = PROCEDURE_REF(env_151, ((long) 0));
      {
	 obj_t val1008_33;
	 val1008_33 = val1008_153;
	 return unwind_until__178___bexit(an_exitd1007_152, val1008_33);
      }
   }
}


/* rhandler1003 */ obj_t 
rhandler1003_read_access(obj_t env_154, obj_t esc_157, obj_t obj_158, obj_t proc_159, obj_t msg_160)
{
   {
      obj_t armed1005_155;
      obj_t handler1002_156;
      armed1005_155 = PROCEDURE_REF(env_154, ((long) 0));
      handler1002_156 = PROCEDURE_REF(env_154, ((long) 1));
      {
	 obj_t esc_42;
	 obj_t obj_43;
	 obj_t proc_44;
	 obj_t msg_45;
	 esc_42 = esc_157;
	 obj_43 = obj_158;
	 proc_44 = proc_159;
	 msg_45 = msg_160;
	 CELL_SET(armed1005_155, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_319;
	    aux_319 = CELL_REF(handler1002_156);
	    return PROCEDURE_ENTRY(aux_319) (CELL_REF(handler1002_156), esc_42, obj_43, proc_44, msg_45, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_read_access(obj_t env_162, obj_t escape_164, obj_t proc_165, obj_t mes_166, obj_t obj_167)
{
   {
      obj_t port_163;
      port_163 = PROCEDURE_REF(env_162, ((long) 0));
      {
	 obj_t escape_21;
	 obj_t proc_22;
	 obj_t mes_23;
	 obj_t obj_24;
	 escape_21 = escape_164;
	 proc_22 = proc_165;
	 mes_23 = mes_166;
	 obj_24 = obj_167;
	 notify_error_43___error(proc_22, mes_23, obj_24);
	 close_output_port(port_163);
	 return exit_bigloo_229_init_main(BINT(((long) -2)));
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_read_access()
{
   module_initialization_70_engine_param(((long) 0), "READ_ACCESS");
   module_initialization_70_engine_engine(((long) 0), "READ_ACCESS");
   module_initialization_70_tools_error(((long) 0), "READ_ACCESS");
   return module_initialization_70_init_main(((long) 0), "READ_ACCESS");
}
