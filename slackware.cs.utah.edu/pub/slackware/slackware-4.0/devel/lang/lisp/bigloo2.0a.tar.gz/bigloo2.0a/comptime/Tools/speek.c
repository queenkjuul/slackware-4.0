/*===========================================================================*/
/*   (Tools/speek.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t current_output_port;
extern obj_t _verbose__1_engine_param;
static obj_t _verbose_tools_speek(obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t speek_tools_speek(obj_t, bool_t, obj_t);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t imported_modules_init_94_tools_speek();
static obj_t library_modules_init_112_tools_speek();
extern bool_t _2___241___r4_numbers_6_5(obj_t, obj_t);
static obj_t require_initialization_114_tools_speek = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(verbose_env_222_tools_speek, _verbose_tools_speek1011, va_generic_entry, _verbose_tools_speek, -2);


/* module-initialization */ obj_t 
module_initialization_70_tools_speek(long checksum_24, char *from_25)
{
   if (CBOOL(require_initialization_114_tools_speek))
     {
	require_initialization_114_tools_speek = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_speek();
	imported_modules_init_94_tools_speek();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_speek()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "TOOLS_SPEEK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "TOOLS_SPEEK");
   return BUNSPEC;
}


/* speek */ obj_t 
speek_tools_speek(obj_t port_1, bool_t flag_2, obj_t args_3)
{
   if (flag_2)
     {
	{
	   obj_t l1002_6;
	   l1002_6 = args_3;
	 lname1003_7:
	   if (PAIRP(l1002_6))
	     {
		{
		   obj_t v_9;
		   v_9 = CAR(l1002_6);
		   {
		      obj_t list1005_10;
		      list1005_10 = MAKE_PAIR(port_1, BNIL);
		      display___r4_output_6_10_3(v_9, list1005_10);
		   }
		}
		{
		   obj_t l1002_39;
		   l1002_39 = CDR(l1002_6);
		   l1002_6 = l1002_39;
		   goto lname1003_7;
		}
	     }
	   else
	     {
		((bool_t) 1);
	     }
	}
	return FLUSH_OUTPUT_PORT(port_1);
     }
   else
     {
	return BUNSPEC;
     }
}


/* verbose */ obj_t 
verbose_tools_speek(obj_t level_4, obj_t args_5)
{
   {
      bool_t arg1009_20;
      arg1009_20 = _2___241___r4_numbers_6_5(level_4, _verbose__1_engine_param);
      return speek_tools_speek(current_output_port, arg1009_20, args_5);
   }
}


/* _verbose */ obj_t 
_verbose_tools_speek(obj_t env_21, obj_t level_22, obj_t args_23)
{
   return verbose_tools_speek(level_22, args_23);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_speek()
{
   return module_initialization_70_engine_param(((long) 0), "TOOLS_SPEEK");
}
