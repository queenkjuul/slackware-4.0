/*===========================================================================*/
/*   (Module/module.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


obj_t ccomp_module_module = BUNSPEC;
extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
static obj_t _produce_module_clause__98_module_module(obj_t, obj_t);
static obj_t _produce_module__35_module_module(obj_t, obj_t);
extern obj_t _src_files__222_engine_param;
extern bool_t ccomp__61_module_module(obj_t);
static obj_t _checksum_module_151_module_module(obj_t, obj_t);
static obj_t method_init_76_module_module();
obj_t _module_checksum__252_module_module = BUNSPEC;
static obj_t unknown_clause_consumer_25_module_module(obj_t, obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
static obj_t _clause_compilers__7_module_module = BUNSPEC;
static obj_t _allocate_ccomp_156_module_module(obj_t);
static obj_t _ccomp__233_module_module(obj_t, obj_t);
static obj_t find_clause_checksummer_175_module_module(obj_t, obj_t);
static obj_t install_clauses_compiler__226_module_module();
extern obj_t make_use_compiler_106_module_impuse();
static obj_t _object__struct1565_111___object(obj_t, obj_t);
extern obj_t make_foreign_compiler_237_module_foreign();
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _module_initialization_id_24_module_module(obj_t, obj_t);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_heap_restore(long, char *);
extern obj_t module_initialization_70_module_main(long, char *);
extern obj_t module_initialization_70_module_statexp(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_module_with(long, char *);
extern obj_t module_initialization_70_module_type(long, char *);
extern obj_t module_initialization_70_module_foreign(long, char *);
extern obj_t module_initialization_70_module_eval(long, char *);
extern obj_t module_initialization_70_module_load(long, char *);
extern obj_t module_initialization_70_module_pragma(long, char *);
extern obj_t module_initialization_70_module_checksum(long, char *);
extern obj_t module_initialization_70_module_option(long, char *);
extern obj_t module_initialization_70_module_alibrary(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _ccomp_consumer_134_module_module(obj_t, obj_t);
static obj_t _module_checksum_object_225_module_module(obj_t);
extern obj_t consume_module__183_module_module(obj_t, obj_t);
static obj_t unknown_clause_producer_208_module_module(obj_t, obj_t);
static obj_t produce_library_clauses_159_module_module(obj_t);
extern ccomp_t allocate_ccomp_51_module_module();
static obj_t _ccomp_checksummer_188_module_module(obj_t, obj_t);
extern bool_t fexists(char *);
extern obj_t make_include_compiler_73_module_include();
extern ccomp_t make_ccomp_97_module_module(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_option_compiler_205_module_option();
static obj_t checksum_module_clause_152_module_module(obj_t, long);
extern obj_t _unsafe_version__81_engine_param;
static obj_t _ccomp_id_250_module_module(obj_t, obj_t);
static obj_t _consume_module_clause__224_module_module(obj_t, obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t ccomp_checksummer_97_module_module(ccomp_t);
static obj_t unknown_clause_checksummer_233_module_module(obj_t, obj_t, obj_t);
extern obj_t make_alibrary_compiler_139_module_alibrary();
extern obj_t make_export_compiler_49_module_statexp();
extern obj_t ccomp_id_222_module_module(ccomp_t);
extern obj_t module_initialization_id_110_module_module(obj_t);
extern obj_t make_type_compiler_68_module_type();
static obj_t imported_modules_init_94_module_module();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static bool_t legal_module_name__202_module_module(obj_t);
extern obj_t make_pragma_compiler_150_module_pragma();
extern obj_t ccomp_finalizer_154_module_module(ccomp_t);
extern obj_t _dest__217_engine_param;
extern obj_t ccomp_consumer_18_module_module(ccomp_t);
extern long initial_checksum_14_module_checksum(obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
static obj_t _consume_module__76_module_module(obj_t, obj_t, obj_t);
extern obj_t prefix___os(obj_t);
static obj_t find_clause_consumer_137_module_module(obj_t, obj_t);
static obj_t _struct_object__object1568_82___object(obj_t, obj_t, obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
obj_t _module_clause__117_module_module = BUNSPEC;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_module();
static obj_t _ccomp_producer_86_module_module(obj_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t make_eval_compiler_154_module_eval();
extern obj_t make_import_compiler_148_module_impuse();
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t toplevel_init_63_module_module();
extern obj_t open_input_string(obj_t);
static obj_t finalize_clause_compilations_33_module_module();
extern obj_t print___r4_output_6_10_3(obj_t);
static obj_t _make_ccomp_11_module_module(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _ccomp_finalizer_215_module_module(obj_t, obj_t);
extern obj_t object___object;
extern obj_t ccomp_producer_45_module_module(ccomp_t);
extern obj_t make_with_compiler_235_module_with();
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t make_extern_compiler_102_module_foreign();
static obj_t find_clause_producer_171_module_module(obj_t, obj_t);
extern obj_t close_input_port(obj_t);
extern obj_t make_static_compiler_70_module_statexp();
extern obj_t module_checksum_object_250_module_module();
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t object_init_111_module_module();
extern obj_t make_main_compiler_2_module_main();
extern obj_t produce_module__65_module_module(obj_t);
extern obj_t checksum_module_8_module_module(obj_t);
obj_t _module__166_module_module = BUNSPEC;
extern obj_t make_from_compiler_140_module_impuse();
extern obj_t restore_additional_heaps_23_heap_restore();
extern obj_t make_load_compiler_92_module_load();
extern obj_t consume_module_clause__236_module_module(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t struct_object__object_ccomp_100_module_module(obj_t, obj_t, obj_t);
extern obj_t open_output_file(obj_t);
static obj_t require_initialization_114_module_module = BUNSPEC;
static obj_t object__struct_ccomp_115_module_module(obj_t, obj_t);
extern obj_t _pass__125_engine_param;
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
obj_t _main__152_module_module = BUNSPEC;
static obj_t cnst_init_137_module_module();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[9];

DEFINE_EXPORT_PROCEDURE(produce_module_clause__env_224_module_module, _produce_module_clause__98_module_module1596, _produce_module_clause__98_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccomp_checksummer_env_247_module_module, _ccomp_checksummer_188_module_module1597, _ccomp_checksummer_188_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(consume_module_clause__env_94_module_module, _consume_module_clause__224_module_module1598, _consume_module_clause__224_module_module, 0L, 2);
DEFINE_EXPORT_PROCEDURE(produce_module__env_32_module_module, _produce_module__35_module_module1599, _produce_module__35_module_module, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_STATIC_PROCEDURE(proc1589_module_module, struct_object__object_ccomp_100_module_module1600, struct_object__object_ccomp_100_module_module, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1588_module_module, object__struct_ccomp_115_module_module1601, object__struct_ccomp_115_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccomp__env_205_module_module, _ccomp__233_module_module1602, _ccomp__233_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(module_initialization_id_env_128_module_module, _module_initialization_id_24_module_module1603, _module_initialization_id_24_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccomp_producer_env_125_module_module, _ccomp_producer_86_module_module1604, _ccomp_producer_86_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_ccomp_env_181_module_module, _allocate_ccomp_156_module_module1605, _allocate_ccomp_156_module_module, 0L, 0);
DEFINE_EXPORT_PROCEDURE(ccomp_finalizer_env_58_module_module, _ccomp_finalizer_215_module_module1606, _ccomp_finalizer_215_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(ccomp_id_env_97_module_module, _ccomp_id_250_module_module1607, _ccomp_id_250_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(checksum_module_env_130_module_module, _checksum_module_151_module_module1608, _checksum_module_151_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(module_checksum_object_env_150_module_module, _module_checksum_object_225_module_module1609, _module_checksum_object_225_module_module, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_ccomp_env_247_module_module, _make_ccomp_11_module_module1610, _make_ccomp_11_module_module, 0L, 5);
DEFINE_STRING(string1590_module_module, string1590_module_module1611, "CCOMP MCO (EVAL FOREIGN) MODULE-INITIALIZATION (LIBRARY _) LIBRARY MODULE MAIN PASS-STARTED ", 92);
DEFINE_STRING(string1587_module_module, string1587_module_module1612, "Can't open file for input", 25);
DEFINE_STRING(string1586_module_module, string1586_module_module1613, "Can't open file for output", 26);
DEFINE_STRING(string1585_module_module, string1585_module_module1614, "module checksum", 15);
DEFINE_STRING(string1584_module_module, string1584_module_module1615, ".mco", 4);
DEFINE_STRING(string1583_module_module, string1583_module_module1616, "Module checksum object", 22);
DEFINE_STRING(string1582_module_module, string1582_module_module1617, "Module declaration", 18);
DEFINE_STRING(string1581_module_module, string1581_module_module1618, "conflict in module's name: ", 27);
DEFINE_STRING(string1579_module_module, string1579_module_module1619, "Unknown module clause", 21);
DEFINE_STRING(string1580_module_module, string1580_module_module1620, " vs ", 4);
DEFINE_STRING(string1578_module_module, string1578_module_module1621, "Illegal module clause", 21);
DEFINE_STRING(string1577_module_module, string1577_module_module1622, "Illegal module declaration", 26);
DEFINE_STRING(string1576_module_module, string1576_module_module1623, "Illegal module name", 19);
DEFINE_STRING(string1575_module_module, string1575_module_module1624, "Parse error", 11);
DEFINE_STRING(string1574_module_module, string1574_module_module1625, "failure during postlude hook", 28);
DEFINE_STRING(string1573_module_module, string1573_module_module1626, " error", 6);
DEFINE_STRING(string1572_module_module, string1572_module_module1627, " occured, ending ...", 20);
DEFINE_STRING(string1571_module_module, string1571_module_module1628, "failure during prelude hook", 27);
DEFINE_STRING(string1569_module_module, string1569_module_module1629, "Module", 6);
DEFINE_STRING(string1570_module_module, string1570_module_module1630, "   . ", 5);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(ccomp_consumer_env_90_module_module, _ccomp_consumer_134_module_module1631, _ccomp_consumer_134_module_module, 0L, 1);
DEFINE_EXPORT_PROCEDURE(consume_module__env_122_module_module, _consume_module__76_module_module1632, _consume_module__76_module_module, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_module_module(long checksum_811, char *from_812)
{
   if (CBOOL(require_initialization_114_module_module))
     {
	require_initialization_114_module_module = BBOOL(((bool_t) 0));
	library_modules_init_112_module_module();
	cnst_init_137_module_module();
	imported_modules_init_94_module_module();
	object_init_111_module_module();
	method_init_76_module_module();
	toplevel_init_63_module_module();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_module()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_MODULE");
   module_initialization_70___object(((long) 0), "MODULE_MODULE");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_MODULE");
   module_initialization_70___r4_output_6_10_3(((long) 0), "MODULE_MODULE");
   module_initialization_70___os(((long) 0), "MODULE_MODULE");
   module_initialization_70___r4_numbers_6_5(((long) 0), "MODULE_MODULE");
   module_initialization_70___reader(((long) 0), "MODULE_MODULE");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "MODULE_MODULE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_module()
{
   {
      obj_t cnst_port_138_803;
      cnst_port_138_803 = open_input_string(string1590_module_module);
      {
	 long i_804;
	 i_804 = ((long) 8);
       loop_805:
	 {
	    bool_t test1591_806;
	    test1591_806 = (i_804 == ((long) -1));
	    if (test1591_806)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1592_807;
		    {
		       obj_t list1593_808;
		       {
			  obj_t arg1594_809;
			  arg1594_809 = BNIL;
			  list1593_808 = MAKE_PAIR(cnst_port_138_803, arg1594_809);
		       }
		       arg1592_807 = read___reader(list1593_808);
		    }
		    CNST_TABLE_SET(i_804, arg1592_807);
		 }
		 {
		    int aux_810;
		    {
		       long aux_836;
		       aux_836 = (i_804 - ((long) 1));
		       aux_810 = (int) (aux_836);
		    }
		    {
		       long i_839;
		       i_839 = (long) (aux_810);
		       i_804 = i_839;
		       goto loop_805;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_module()
{
   _module__166_module_module = BFALSE;
   _module_clause__117_module_module = BFALSE;
   _main__152_module_module = BFALSE;
   _module_checksum__252_module_module = BFALSE;
   return (_clause_compilers__7_module_module = BNIL,
      BUNSPEC);
}


/* produce-module! */ obj_t 
produce_module__65_module_module(obj_t mclause_19)
{
   {
      obj_t list1138_68;
      {
	 obj_t arg1144_70;
	 {
	    obj_t arg1150_72;
	    {
	       obj_t aux_841;
	       aux_841 = BCHAR(((unsigned char) '\n'));
	       arg1150_72 = MAKE_PAIR(aux_841, BNIL);
	    }
	    arg1144_70 = MAKE_PAIR(string1569_module_module, arg1150_72);
	 }
	 list1138_68 = MAKE_PAIR(string1570_module_module, arg1144_70);
      }
      verbose_tools_speek(BINT(((long) 1)), list1138_68);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1569_module_module;
   {
      obj_t hooks_74;
      obj_t hnames_75;
      hooks_74 = BNIL;
      hnames_75 = BNIL;
    loop_76:
      if (NULLP(hooks_74))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1166_81;
	   {
	      obj_t fun1191_87;
	      fun1191_87 = CAR(hooks_74);
	      {
		 obj_t aux_853;
		 aux_853 = PROCEDURE_ENTRY(fun1191_87) (fun1191_87, BEOA);
		 test1166_81 = CBOOL(aux_853);
	      }
	   }
	   if (test1166_81)
	     {
		{
		   obj_t hnames_860;
		   obj_t hooks_858;
		   hooks_858 = CDR(hooks_74);
		   hnames_860 = CDR(hnames_75);
		   hnames_75 = hnames_860;
		   hooks_74 = hooks_858;
		   goto loop_76;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1569_module_module, string1571_module_module, CAR(hnames_75));
	     }
	}
   }
   {
      obj_t name_88;
      obj_t clauses_89;
      if (PAIRP(mclause_19))
	{
	   obj_t cdr_109_69_94;
	   cdr_109_69_94 = CDR(mclause_19);
	   {
	      bool_t test_867;
	      {
		 obj_t aux_870;
		 obj_t aux_868;
		 aux_870 = CNST_TABLE_REF(((long) 2));
		 aux_868 = CAR(mclause_19);
		 test_867 = (aux_868 == aux_870);
	      }
	      if (test_867)
		{
		   if (PAIRP(cdr_109_69_94))
		     {
			obj_t car_112_152_97;
			car_112_152_97 = CAR(cdr_109_69_94);
			if (SYMBOLP(car_112_152_97))
			  {
			     name_88 = car_112_152_97;
			     clauses_89 = CDR(cdr_109_69_94);
			     {
				obj_t clauses_102;
				{
				   bool_t test1231_137;
				   {
				      obj_t obj_542;
				      obj_542 = _main__152_module_module;
				      test1231_137 = SYMBOLP(obj_542);
				   }
				   if (test1231_137)
				     {
					obj_t arg1232_138;
					{
					   obj_t arg1233_139;
					   arg1233_139 = CNST_TABLE_REF(((long) 1));
					   {
					      obj_t list1235_141;
					      {
						 obj_t arg1236_142;
						 arg1236_142 = MAKE_PAIR(BNIL, BNIL);
						 list1235_141 = MAKE_PAIR(_main__152_module_module, arg1236_142);
					      }
					      arg1232_138 = cons__138___r4_pairs_and_lists_6_3(arg1233_139, list1235_141);
					   }
					}
					clauses_102 = MAKE_PAIR(arg1232_138, clauses_89);
				     }
				   else
				     {
					clauses_102 = clauses_89;
				     }
				}
				if (legal_module_name__202_module_module(name_88))
				  {
				     _module__166_module_module = name_88;
				     _module_clause__117_module_module = mclause_19;
				     install_clauses_compiler__226_module_module();
				     {
					obj_t clauses_104;
					clauses_104 = produce_library_clauses_159_module_module(clauses_102);
					restore_additional_heaps_23_heap_restore();
					{
					   obj_t l1032_105;
					   l1032_105 = clauses_104;
					 lname1033_106:
					   if (PAIRP(l1032_105))
					     {
						produce_module_clause__172_module_module(CAR(l1032_105));
						{
						   obj_t l1032_894;
						   l1032_894 = CDR(l1032_105);
						   l1032_105 = l1032_894;
						   goto lname1033_106;
						}
					     }
					   else
					     {
						((bool_t) 1);
					     }
					}
					_module_checksum__252_module_module = checksum_module_8_module_module(mclause_19);
					{
					   obj_t value_110;
					   value_110 = finalize_clause_compilations_33_module_module();
					   {
					      bool_t test1204_111;
					      {
						 long n1_548;
						 n1_548 = (long) CINT(_nb_error_on_pass__70_tools_error);
						 test1204_111 = (n1_548 > ((long) 0));
					      }
					      if (test1204_111)
						{
						   {
						      char *arg1207_114;
						      {
							 bool_t test1217_121;
							 {
							    bool_t test1218_122;
							    {
							       obj_t obj_550;
							       obj_550 = _nb_error_on_pass__70_tools_error;
							       test1218_122 = INTEGERP(obj_550);
							    }
							    if (test1218_122)
							      {
								 test1217_121 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
							      }
							    else
							      {
								 test1217_121 = ((bool_t) 0);
							      }
							 }
							 if (test1217_121)
							   {
							      arg1207_114 = "s";
							   }
							 else
							   {
							      arg1207_114 = "";
							   }
						      }
						      {
							 obj_t list1210_116;
							 {
							    obj_t arg1211_117;
							    {
							       obj_t arg1213_118;
							       {
								  obj_t arg1214_119;
								  arg1214_119 = MAKE_PAIR(string1572_module_module, BNIL);
								  {
								     obj_t aux_907;
								     aux_907 = string_to_bstring(arg1207_114);
								     arg1213_118 = MAKE_PAIR(aux_907, arg1214_119);
								  }
							       }
							       arg1211_117 = MAKE_PAIR(string1573_module_module, arg1213_118);
							    }
							    list1210_116 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1211_117);
							 }
							 fprint___r4_output_6_10_3(current_error_port, list1210_116);
						      }
						   }
						   {
						      obj_t res1562_552;
						      exit(((long) -1));
						      res1562_552 = BINT(((long) -1));
						      return res1562_552;
						   }
						}
					      else
						{
						   obj_t hooks_123;
						   obj_t hnames_124;
						   hooks_123 = BNIL;
						   hnames_124 = BNIL;
						 loop_125:
						   if (NULLP(hooks_123))
						     {
							return value_110;
						     }
						   else
						     {
							bool_t test1223_130;
							{
							   obj_t fun1229_135;
							   fun1229_135 = CAR(hooks_123);
							   {
							      obj_t aux_918;
							      aux_918 = PROCEDURE_ENTRY(fun1229_135) (fun1229_135, BEOA);
							      test1223_130 = CBOOL(aux_918);
							   }
							}
							if (test1223_130)
							  {
							     {
								obj_t hnames_925;
								obj_t hooks_923;
								hooks_923 = CDR(hooks_123);
								hnames_925 = CDR(hnames_124);
								hnames_124 = hnames_925;
								hooks_123 = hooks_923;
								goto loop_125;
							     }
							  }
							else
							  {
							     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1574_module_module, CAR(hnames_124));
							  }
						     }
						}
					   }
					}
				     }
				  }
				else
				  {
				     return user_error_151_tools_error(string1575_module_module, string1576_module_module, mclause_19, BNIL);
				  }
			     }
			  }
			else
			  {
			   tag_102_241_91:
			     return user_error_151_tools_error(string1575_module_module, string1577_module_module, mclause_19, BNIL);
			  }
		     }
		   else
		     {
			goto tag_102_241_91;
		     }
		}
	      else
		{
		   goto tag_102_241_91;
		}
	   }
	}
      else
	{
	   goto tag_102_241_91;
	}
   }
}


/* _produce-module! */ obj_t 
_produce_module__35_module_module(obj_t env_742, obj_t mclause_743)
{
   return produce_module__65_module_module(mclause_743);
}


/* produce-library-clauses */ obj_t 
produce_library_clauses_159_module_module(obj_t clauses_20)
{
   {
      obj_t producer_145;
      producer_145 = find_clause_producer_171_module_module(CNST_TABLE_REF(((long) 3)), CNST_TABLE_REF(((long) 4)));
      {
	 obj_t clauses_146;
	 obj_t res_147;
	 clauses_146 = clauses_20;
	 res_147 = BNIL;
       loop_148:
	 if (NULLP(clauses_146))
	   {
	      return reverse__39___r4_pairs_and_lists_6_3(res_147);
	   }
	 else
	   {
	      {
		 obj_t clause_151;
		 clause_151 = CAR(clauses_146);
		 {
		    if (PAIRP(clause_151))
		      {
			 bool_t test_942;
			 {
			    obj_t aux_945;
			    obj_t aux_943;
			    aux_945 = CNST_TABLE_REF(((long) 3));
			    aux_943 = CAR(clause_151);
			    test_942 = (aux_943 == aux_945);
			 }
			 if (test_942)
			   {
			      PROCEDURE_ENTRY(producer_145) (producer_145, clause_151, BEOA);
			      {
				 obj_t clauses_950;
				 clauses_950 = CDR(clauses_146);
				 clauses_146 = clauses_950;
				 goto loop_148;
			      }
			   }
			 else
			   {
			    tag_119_205_153:
			      {
				 obj_t arg1248_160;
				 obj_t arg1250_161;
				 arg1248_160 = CDR(clauses_146);
				 arg1250_161 = MAKE_PAIR(clause_151, res_147);
				 {
				    obj_t res_955;
				    obj_t clauses_954;
				    clauses_954 = arg1248_160;
				    res_955 = arg1250_161;
				    res_147 = res_955;
				    clauses_146 = clauses_954;
				    goto loop_148;
				 }
			      }
			   }
		      }
		    else
		      {
			 goto tag_119_205_153;
		      }
		 }
	      }
	   }
      }
   }
}


/* finalize-clause-compilations */ obj_t 
finalize_clause_compilations_33_module_module()
{
   {
      obj_t cc_164;
      obj_t units_165;
      cc_164 = _clause_compilers__7_module_module;
      units_165 = BNIL;
    loop_166:
      if (NULLP(cc_164))
	{
	   return units_165;
	}
      else
	{
	   obj_t finalizer_169;
	   {
	      ccomp_t obj_571;
	      {
		 obj_t aux_958;
		 aux_958 = CAR(cc_164);
		 obj_571 = (ccomp_t) (aux_958);
	      }
	      finalizer_169 = (((ccomp_t) CREF(obj_571))->finalizer);
	   }
	   {
	      obj_t finalres_170;
	      finalres_170 = PROCEDURE_ENTRY(finalizer_169) (finalizer_169, BEOA);
	      {
		 {
		    obj_t units_966;
		    obj_t cc_964;
		    cc_964 = CDR(cc_164);
		    if (PAIRP(finalres_170))
		      {
			 units_966 = append_2_18___r4_pairs_and_lists_6_3(finalres_170, units_165);
		      }
		    else
		      {
			 units_966 = units_165;
		      }
		    units_165 = units_966;
		    cc_164 = cc_964;
		    goto loop_166;
		 }
	      }
	   }
	}
   }
}


/* produce-module-clause! */ obj_t 
produce_module_clause__172_module_module(obj_t clause_21)
{
   {
      if (PAIRP(clause_21))
	{
	   obj_t car_128_220_180;
	   car_128_220_180 = CAR(clause_21);
	   if (SYMBOLP(car_128_220_180))
	     {
		obj_t fun1261_578;
		fun1261_578 = find_clause_producer_171_module_module(car_128_220_180, clause_21);
		return PROCEDURE_ENTRY(fun1261_578) (fun1261_578, clause_21, BEOA);
	     }
	   else
	     {
	      tag_124_21_177:
		{
		   obj_t list1266_186;
		   list1266_186 = MAKE_PAIR(BNIL, BNIL);
		   return user_error_151_tools_error(string1575_module_module, string1578_module_module, clause_21, list1266_186);
		}
	     }
	}
      else
	{
	   goto tag_124_21_177;
	}
   }
}


/* _produce-module-clause! */ obj_t 
_produce_module_clause__98_module_module(obj_t env_744, obj_t clause_745)
{
   return produce_module_clause__172_module_module(clause_745);
}


/* install-clauses-compiler! */ obj_t 
install_clauses_compiler__226_module_module()
{
   {
      obj_t arg1268_188;
      obj_t arg1269_189;
      obj_t arg1270_190;
      obj_t arg1272_191;
      obj_t arg1273_192;
      obj_t arg1274_193;
      obj_t arg1277_194;
      obj_t arg1278_195;
      obj_t arg1281_196;
      obj_t arg1282_197;
      obj_t arg1283_198;
      obj_t arg1284_199;
      obj_t arg1285_200;
      obj_t arg1286_201;
      obj_t arg1287_202;
      obj_t arg1288_203;
      arg1268_188 = make_eval_compiler_154_module_eval();
      arg1269_189 = make_main_compiler_2_module_main();
      arg1270_190 = make_load_compiler_92_module_load();
      arg1272_191 = make_use_compiler_106_module_impuse();
      arg1273_192 = make_import_compiler_148_module_impuse();
      arg1274_193 = make_from_compiler_140_module_impuse();
      arg1277_194 = make_static_compiler_70_module_statexp();
      arg1278_195 = make_export_compiler_49_module_statexp();
      arg1281_196 = make_include_compiler_73_module_include();
      arg1282_197 = make_with_compiler_235_module_with();
      arg1283_198 = make_foreign_compiler_237_module_foreign();
      arg1284_199 = make_extern_compiler_102_module_foreign();
      arg1285_200 = make_type_compiler_68_module_type();
      arg1286_201 = make_pragma_compiler_150_module_pragma();
      arg1287_202 = make_option_compiler_205_module_option();
      arg1288_203 = make_alibrary_compiler_139_module_alibrary();
      {
	 obj_t list1289_204;
	 {
	    obj_t arg1290_205;
	    {
	       obj_t arg1291_206;
	       {
		  obj_t arg1292_207;
		  {
		     obj_t arg1294_208;
		     {
			obj_t arg1295_209;
			{
			   obj_t arg1296_210;
			   {
			      obj_t arg1297_211;
			      {
				 obj_t arg1298_212;
				 {
				    obj_t arg1299_213;
				    {
				       obj_t arg1300_214;
				       {
					  obj_t arg1301_215;
					  {
					     obj_t arg1302_216;
					     {
						obj_t arg1303_217;
						{
						   obj_t arg1304_218;
						   {
						      obj_t arg1307_219;
						      arg1307_219 = MAKE_PAIR(arg1288_203, BNIL);
						      arg1304_218 = MAKE_PAIR(arg1287_202, arg1307_219);
						   }
						   arg1303_217 = MAKE_PAIR(arg1286_201, arg1304_218);
						}
						arg1302_216 = MAKE_PAIR(arg1285_200, arg1303_217);
					     }
					     arg1301_215 = MAKE_PAIR(arg1284_199, arg1302_216);
					  }
					  arg1300_214 = MAKE_PAIR(arg1283_198, arg1301_215);
				       }
				       arg1299_213 = MAKE_PAIR(arg1282_197, arg1300_214);
				    }
				    arg1298_212 = MAKE_PAIR(arg1281_196, arg1299_213);
				 }
				 arg1297_211 = MAKE_PAIR(arg1278_195, arg1298_212);
			      }
			      arg1296_210 = MAKE_PAIR(arg1277_194, arg1297_211);
			   }
			   arg1295_209 = MAKE_PAIR(arg1274_193, arg1296_210);
			}
			arg1294_208 = MAKE_PAIR(arg1273_192, arg1295_209);
		     }
		     arg1292_207 = MAKE_PAIR(arg1272_191, arg1294_208);
		  }
		  arg1291_206 = MAKE_PAIR(arg1270_190, arg1292_207);
	       }
	       arg1290_205 = MAKE_PAIR(arg1269_189, arg1291_206);
	    }
	    list1289_204 = MAKE_PAIR(arg1268_188, arg1290_205);
	 }
	 return (_clause_compilers__7_module_module = list1289_204,
	    BUNSPEC);
      }
   }
}


/* find-clause-producer */ obj_t 
find_clause_producer_171_module_module(obj_t keyword_22, obj_t clause_23)
{
   {
      obj_t unknown_clause_producer_208_746;
      unknown_clause_producer_208_746 = make_fx_procedure(unknown_clause_producer_208_module_module, ((long) 1), ((long) 1));
      PROCEDURE_SET(unknown_clause_producer_208_746, ((long) 0), clause_23);
      {
	 obj_t cc_222;
	 cc_222 = _clause_compilers__7_module_module;
       loop_223:
	 if (NULLP(cc_222))
	   {
	      return unknown_clause_producer_208_746;
	   }
	 else
	   {
	      bool_t test_1017;
	      {
		 obj_t aux_1018;
		 {
		    ccomp_t obj_583;
		    {
		       obj_t aux_1019;
		       aux_1019 = CAR(cc_222);
		       obj_583 = (ccomp_t) (aux_1019);
		    }
		    aux_1018 = (((ccomp_t) CREF(obj_583))->id);
		 }
		 test_1017 = (aux_1018 == keyword_22);
	      }
	      if (test_1017)
		{
		   {
		      ccomp_t obj_587;
		      {
			 obj_t aux_1024;
			 aux_1024 = CAR(cc_222);
			 obj_587 = (ccomp_t) (aux_1024);
		      }
		      return (((ccomp_t) CREF(obj_587))->producer);
		   }
		}
	      else
		{
		   {
		      obj_t cc_1028;
		      cc_1028 = CDR(cc_222);
		      cc_222 = cc_1028;
		      goto loop_223;
		   }
		}
	   }
      }
   }
}


/* unknown-clause-producer */ obj_t 
unknown_clause_producer_208_module_module(obj_t env_747, obj_t values_749)
{
   {
      obj_t clause_748;
      clause_748 = PROCEDURE_REF(env_747, ((long) 0));
      {
	 obj_t values_230;
	 values_230 = values_749;
	 {
	    obj_t list1323_235;
	    list1323_235 = MAKE_PAIR(BNIL, BNIL);
	    return user_error_151_tools_error(string1575_module_module, string1579_module_module, clause_748, list1323_235);
	 }
      }
   }
}


/* module-initialization-id */ obj_t 
module_initialization_id_110_module_module(obj_t id_24)
{
   return CNST_TABLE_REF(((long) 5));
}


/* _module-initialization-id */ obj_t 
_module_initialization_id_24_module_module(obj_t env_750, obj_t id_751)
{
   return module_initialization_id_110_module_module(id_751);
}


/* consume-module! */ obj_t 
consume_module__183_module_module(obj_t pname_25, obj_t mclause_26)
{
   {
      obj_t name_238;
      obj_t clauses_239;
      if (PAIRP(mclause_26))
	{
	   obj_t cdr_141_172_244;
	   cdr_141_172_244 = CDR(mclause_26);
	   {
	      bool_t test_1038;
	      {
		 obj_t aux_1041;
		 obj_t aux_1039;
		 aux_1041 = CNST_TABLE_REF(((long) 2));
		 aux_1039 = CAR(mclause_26);
		 test_1038 = (aux_1039 == aux_1041);
	      }
	      if (test_1038)
		{
		   if (PAIRP(cdr_141_172_244))
		     {
			obj_t car_144_227_247;
			car_144_227_247 = CAR(cdr_141_172_244);
			if (SYMBOLP(car_144_227_247))
			  {
			     name_238 = car_144_227_247;
			     clauses_239 = CDR(cdr_141_172_244);
			     if (legal_module_name__202_module_module(name_238))
			       {
				  if ((pname_25 == name_238))
				    {
				       {
					  obj_t runner1344_268;
					  if (NULLP(clauses_239))
					    {
					       runner1344_268 = BNIL;
					    }
					  else
					    {
					       obj_t head1036_256;
					       head1036_256 = MAKE_PAIR(BNIL, BNIL);
					       {
						  obj_t l1034_257;
						  obj_t tail1037_258;
						  l1034_257 = clauses_239;
						  tail1037_258 = head1036_256;
						lname1035_259:
						  if (NULLP(l1034_257))
						    {
						       runner1344_268 = CDR(head1036_256);
						    }
						  else
						    {
						       obj_t newtail1038_261;
						       {
							  obj_t arg1339_263;
							  arg1339_263 = consume_module_clause__236_module_module(name_238, CAR(l1034_257));
							  newtail1038_261 = MAKE_PAIR(arg1339_263, BNIL);
						       }
						       SET_CDR(tail1037_258, newtail1038_261);
						       {
							  obj_t tail1037_1065;
							  obj_t l1034_1063;
							  l1034_1063 = CDR(l1034_257);
							  tail1037_1065 = newtail1038_261;
							  tail1037_258 = tail1037_1065;
							  l1034_257 = l1034_1063;
							  goto lname1035_259;
						       }
						    }
					       }
					    }
					  return append___r4_pairs_and_lists_6_3(runner1344_268);
				       }
				    }
				  else
				    {
				       {
					  obj_t arg1347_270;
					  {
					     obj_t arg1353_275;
					     obj_t arg1356_277;
					     arg1353_275 = SYMBOL_TO_STRING(name_238);
					     arg1356_277 = SYMBOL_TO_STRING(pname_25);
					     {
						obj_t list1357_278;
						{
						   obj_t arg1361_279;
						   {
						      obj_t arg1363_280;
						      {
							 obj_t arg1364_281;
							 arg1364_281 = MAKE_PAIR(arg1356_277, BNIL);
							 arg1363_280 = MAKE_PAIR(string1580_module_module, arg1364_281);
						      }
						      arg1361_279 = MAKE_PAIR(arg1353_275, arg1363_280);
						   }
						   list1357_278 = MAKE_PAIR(string1581_module_module, arg1361_279);
						}
						arg1347_270 = string_append_106___r4_strings_6_7(list1357_278);
					     }
					  }
					  {
					     obj_t list1350_272;
					     list1350_272 = MAKE_PAIR(BNIL, BNIL);
					     return user_error_151_tools_error(string1582_module_module, arg1347_270, mclause_26, list1350_272);
					  }
				       }
				    }
			       }
			     else
			       {
				  {
				     obj_t list1370_286;
				     list1370_286 = MAKE_PAIR(BNIL, BNIL);
				     return user_error_151_tools_error(string1575_module_module, string1576_module_module, mclause_26, list1370_286);
				  }
			       }
			  }
			else
			  {
			   tag_134_32_241:
			     {
				obj_t list1379_291;
				list1379_291 = MAKE_PAIR(BNIL, BNIL);
				return user_error_151_tools_error(string1575_module_module, string1577_module_module, mclause_26, list1379_291);
			     }
			  }
		     }
		   else
		     {
			goto tag_134_32_241;
		     }
		}
	      else
		{
		   goto tag_134_32_241;
		}
	   }
	}
      else
	{
	   goto tag_134_32_241;
	}
   }
}


/* _consume-module! */ obj_t 
_consume_module__76_module_module(obj_t env_752, obj_t pname_753, obj_t mclause_754)
{
   return consume_module__183_module_module(pname_753, mclause_754);
}


/* consume-module-clause! */ obj_t 
consume_module_clause__236_module_module(obj_t module_27, obj_t clause_28)
{
   {
      if (PAIRP(clause_28))
	{
	   obj_t car_157_166_299;
	   car_157_166_299 = CAR(clause_28);
	   if (SYMBOLP(car_157_166_299))
	     {
		obj_t fun1385_619;
		fun1385_619 = find_clause_consumer_137_module_module(car_157_166_299, clause_28);
		return PROCEDURE_ENTRY(fun1385_619) (fun1385_619, module_27, clause_28, BEOA);
	     }
	   else
	     {
	      tag_151_44_296:
		{
		   obj_t list1390_306;
		   list1390_306 = MAKE_PAIR(BNIL, BNIL);
		   return user_error_151_tools_error(string1575_module_module, string1578_module_module, clause_28, list1390_306);
		}
	     }
	}
      else
	{
	   goto tag_151_44_296;
	}
   }
}


/* _consume-module-clause! */ obj_t 
_consume_module_clause__224_module_module(obj_t env_755, obj_t module_756, obj_t clause_757)
{
   return consume_module_clause__236_module_module(module_756, clause_757);
}


/* find-clause-consumer */ obj_t 
find_clause_consumer_137_module_module(obj_t keyword_29, obj_t clause_30)
{
   {
      obj_t unknown_clause_consumer_25_758;
      unknown_clause_consumer_25_758 = make_fx_procedure(unknown_clause_consumer_25_module_module, ((long) 2), ((long) 1));
      PROCEDURE_SET(unknown_clause_consumer_25_758, ((long) 0), clause_30);
      {
	 obj_t cc_309;
	 cc_309 = _clause_compilers__7_module_module;
       loop_310:
	 if (NULLP(cc_309))
	   {
	      return unknown_clause_consumer_25_758;
	   }
	 else
	   {
	      bool_t test_1097;
	      {
		 obj_t aux_1098;
		 {
		    ccomp_t obj_623;
		    {
		       obj_t aux_1099;
		       aux_1099 = CAR(cc_309);
		       obj_623 = (ccomp_t) (aux_1099);
		    }
		    aux_1098 = (((ccomp_t) CREF(obj_623))->id);
		 }
		 test_1097 = (aux_1098 == keyword_29);
	      }
	      if (test_1097)
		{
		   {
		      ccomp_t obj_627;
		      {
			 obj_t aux_1104;
			 aux_1104 = CAR(cc_309);
			 obj_627 = (ccomp_t) (aux_1104);
		      }
		      return (((ccomp_t) CREF(obj_627))->consumer);
		   }
		}
	      else
		{
		   {
		      obj_t cc_1108;
		      cc_1108 = CDR(cc_309);
		      cc_309 = cc_1108;
		      goto loop_310;
		   }
		}
	   }
      }
   }
}


/* unknown-clause-consumer */ obj_t 
unknown_clause_consumer_25_module_module(obj_t env_759, obj_t module_761, obj_t values_762)
{
   {
      obj_t clause_760;
      clause_760 = PROCEDURE_REF(env_759, ((long) 0));
      {
	 obj_t module_317;
	 obj_t values_318;
	 module_317 = module_761;
	 values_318 = values_762;
	 {
	    obj_t list1404_323;
	    list1404_323 = MAKE_PAIR(BNIL, BNIL);
	    return user_error_151_tools_error(string1575_module_module, string1579_module_module, clause_760, list1404_323);
	 }
      }
   }
}


/* legal-module-name? */ bool_t 
legal_module_name__202_module_module(obj_t name_31)
{
   {
      bool_t test_1113;
      {
	 obj_t aux_1114;
	 aux_1114 = memq___r4_pairs_and_lists_6_3(name_31, CNST_TABLE_REF(((long) 6)));
	 test_1113 = CBOOL(aux_1114);
      }
      if (test_1113)
	{
	   return ((bool_t) 0);
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* checksum-module */ obj_t 
checksum_module_8_module_module(obj_t mclause_32)
{
   if (CBOOL(_unsafe_version__81_engine_param))
     {
	return BINT(((long) 0));
     }
   else
     {
	obj_t name_328;
	obj_t clauses_329;
	if (PAIRP(mclause_32))
	  {
	     obj_t cdr_171_141_334;
	     cdr_171_141_334 = CDR(mclause_32);
	     {
		bool_t test_1124;
		{
		   obj_t aux_1127;
		   obj_t aux_1125;
		   aux_1127 = CNST_TABLE_REF(((long) 2));
		   aux_1125 = CAR(mclause_32);
		   test_1124 = (aux_1125 == aux_1127);
		}
		if (test_1124)
		  {
		     if (PAIRP(cdr_171_141_334))
		       {
			  obj_t car_174_239_337;
			  car_174_239_337 = CAR(cdr_171_141_334);
			  if (SYMBOLP(car_174_239_337))
			    {
			       name_328 = car_174_239_337;
			       clauses_329 = CDR(cdr_171_141_334);
			       if (legal_module_name__202_module_module(name_328))
				 {
				    {
				       obj_t clauses_343;
				       obj_t checksum_344;
				       {
					  long arg1417_346;
					  arg1417_346 = initial_checksum_14_module_checksum(name_328);
					  clauses_343 = clauses_329;
					  checksum_344 = BINT(arg1417_346);
					loop_345:
					  if (NULLP(clauses_343))
					    {
					       return checksum_344;
					    }
					  else
					    {
					       obj_t arg1419_348;
					       obj_t arg1421_349;
					       arg1419_348 = CDR(clauses_343);
					       arg1421_349 = checksum_module_clause_152_module_module(CAR(clauses_343), (long) CINT(checksum_344));
					       {
						  obj_t checksum_1145;
						  obj_t clauses_1144;
						  clauses_1144 = arg1419_348;
						  checksum_1145 = arg1421_349;
						  checksum_344 = checksum_1145;
						  clauses_343 = clauses_1144;
						  goto loop_345;
					       }
					    }
				       }
				    }
				 }
			       else
				 {
				    {
				       obj_t list1429_354;
				       list1429_354 = MAKE_PAIR(BNIL, BNIL);
				       return user_error_151_tools_error(string1575_module_module, string1576_module_module, mclause_32, list1429_354);
				    }
				 }
			    }
			  else
			    {
			     tag_164_209_331:
			       {
				  obj_t list1437_359;
				  list1437_359 = MAKE_PAIR(BNIL, BNIL);
				  return user_error_151_tools_error(string1575_module_module, string1577_module_module, mclause_32, list1437_359);
			       }
			    }
		       }
		     else
		       {
			  goto tag_164_209_331;
		       }
		  }
		else
		  {
		     goto tag_164_209_331;
		  }
	     }
	  }
	else
	  {
	     goto tag_164_209_331;
	  }
     }
}


/* _checksum-module */ obj_t 
_checksum_module_151_module_module(obj_t env_763, obj_t mclause_764)
{
   return checksum_module_8_module_module(mclause_764);
}


/* checksum-module-clause */ obj_t 
checksum_module_clause_152_module_module(obj_t clause_33, long checksum_34)
{
   {
      if (PAIRP(clause_33))
	{
	   obj_t car_185_30_366;
	   car_185_30_366 = CAR(clause_33);
	   if (SYMBOLP(car_185_30_366))
	     {
		obj_t fun1441_645;
		fun1441_645 = find_clause_checksummer_175_module_module(car_185_30_366, clause_33);
		return PROCEDURE_ENTRY(fun1441_645) (fun1441_645, clause_33, BINT(checksum_34), BEOA);
	     }
	   else
	     {
	      tag_181_184_363:
		{
		   obj_t list1447_372;
		   list1447_372 = MAKE_PAIR(BNIL, BNIL);
		   return user_error_151_tools_error(string1575_module_module, string1578_module_module, clause_33, list1447_372);
		}
	     }
	}
      else
	{
	   goto tag_181_184_363;
	}
   }
}


/* find-clause-checksummer */ obj_t 
find_clause_checksummer_175_module_module(obj_t keyword_35, obj_t clause_36)
{
   {
      obj_t unknown_clause_checksummer_233_765;
      unknown_clause_checksummer_233_765 = make_fx_procedure(unknown_clause_checksummer_233_module_module, ((long) 2), ((long) 1));
      PROCEDURE_SET(unknown_clause_checksummer_233_765, ((long) 0), clause_36);
      {
	 obj_t cc_375;
	 cc_375 = _clause_compilers__7_module_module;
       loop_376:
	 if (NULLP(cc_375))
	   {
	      return unknown_clause_checksummer_233_765;
	   }
	 else
	   {
	      bool_t test_1168;
	      {
		 obj_t aux_1169;
		 {
		    ccomp_t obj_649;
		    {
		       obj_t aux_1170;
		       aux_1170 = CAR(cc_375);
		       obj_649 = (ccomp_t) (aux_1170);
		    }
		    aux_1169 = (((ccomp_t) CREF(obj_649))->id);
		 }
		 test_1168 = (aux_1169 == keyword_35);
	      }
	      if (test_1168)
		{
		   {
		      ccomp_t obj_653;
		      {
			 obj_t aux_1175;
			 aux_1175 = CAR(cc_375);
			 obj_653 = (ccomp_t) (aux_1175);
		      }
		      return (((ccomp_t) CREF(obj_653))->checksummer);
		   }
		}
	      else
		{
		   {
		      obj_t cc_1179;
		      cc_1179 = CDR(cc_375);
		      cc_375 = cc_1179;
		      goto loop_376;
		   }
		}
	   }
      }
   }
}


/* unknown-clause-checksummer */ obj_t 
unknown_clause_checksummer_233_module_module(obj_t env_766, obj_t module_768, obj_t values_769)
{
   {
      obj_t clause_767;
      clause_767 = PROCEDURE_REF(env_766, ((long) 0));
      {
	 obj_t module_383;
	 obj_t values_384;
	 module_383 = module_768;
	 values_384 = values_769;
	 {
	    obj_t list1462_389;
	    list1462_389 = MAKE_PAIR(BNIL, BNIL);
	    return user_error_151_tools_error(string1575_module_module, string1579_module_module, clause_767, list1462_389);
	 }
      }
   }
}


/* module-checksum-object */ obj_t 
module_checksum_object_250_module_module()
{
   {
      obj_t list1464_392;
      {
	 obj_t arg1466_394;
	 {
	    obj_t arg1468_396;
	    {
	       obj_t aux_1184;
	       aux_1184 = BCHAR(((unsigned char) '\n'));
	       arg1468_396 = MAKE_PAIR(aux_1184, BNIL);
	    }
	    arg1466_394 = MAKE_PAIR(string1583_module_module, arg1468_396);
	 }
	 list1464_392 = MAKE_PAIR(string1570_module_module, arg1466_394);
      }
      verbose_tools_speek(BINT(((long) 1)), list1464_392);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1583_module_module;
   {
      obj_t hooks_398;
      obj_t hnames_399;
      hooks_398 = BNIL;
      hnames_399 = BNIL;
    loop_400:
      if (NULLP(hooks_398))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1474_405;
	   {
	      obj_t fun1480_411;
	      fun1480_411 = CAR(hooks_398);
	      {
		 obj_t aux_1196;
		 aux_1196 = PROCEDURE_ENTRY(fun1480_411) (fun1480_411, BEOA);
		 test1474_405 = CBOOL(aux_1196);
	      }
	   }
	   if (test1474_405)
	     {
		{
		   obj_t hnames_1203;
		   obj_t hooks_1201;
		   hooks_1201 = CDR(hooks_398);
		   hnames_1203 = CDR(hnames_399);
		   hnames_399 = hnames_1203;
		   hooks_398 = hooks_1201;
		   goto loop_400;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1583_module_module, string1571_module_module, CAR(hnames_399));
	     }
	}
   }
   {
      obj_t checksum_412;
      obj_t dest_413;
      checksum_412 = _module_checksum__252_module_module;
      {
	 bool_t test1497_434;
	 {
	    obj_t obj_661;
	    obj_661 = _dest__217_engine_param;
	    test1497_434 = STRINGP(obj_661);
	 }
	 if (test1497_434)
	   {
	      bool_t test1498_435;
	      {
		 obj_t obj1_662;
		 obj1_662 = _pass__125_engine_param;
		 {
		    obj_t aux_1209;
		    aux_1209 = CNST_TABLE_REF(((long) 7));
		    test1498_435 = (obj1_662 == aux_1209);
		 }
	      }
	      if (test1498_435)
		{
		   dest_413 = _dest__217_engine_param;
		}
	      else
		{
		   obj_t arg1499_436;
		   arg1499_436 = prefix___os(_dest__217_engine_param);
		   dest_413 = string_append(arg1499_436, string1584_module_module);
		}
	   }
	 else
	   {
	      bool_t test1502_439;
	      {
		 bool_t test1506_443;
		 {
		    obj_t obj_664;
		    obj_664 = _src_files__222_engine_param;
		    test1506_443 = PAIRP(obj_664);
		 }
		 if (test1506_443)
		   {
		      obj_t arg1507_444;
		      {
			 obj_t pair_665;
			 pair_665 = _src_files__222_engine_param;
			 arg1507_444 = CAR(pair_665);
		      }
		      test1502_439 = STRINGP(arg1507_444);
		   }
		 else
		   {
		      test1502_439 = ((bool_t) 0);
		   }
	      }
	      if (test1502_439)
		{
		   obj_t arg1503_440;
		   {
		      obj_t arg1505_442;
		      {
			 obj_t pair_667;
			 pair_667 = _src_files__222_engine_param;
			 arg1505_442 = CAR(pair_667);
		      }
		      arg1503_440 = prefix___os(arg1505_442);
		   }
		   dest_413 = string_append(arg1503_440, string1584_module_module);
		}
	      else
		{
		   dest_413 = BFALSE;
		}
	   }
      }
      {
	 {
	    bool_t test1481_415;
	    if (STRINGP(dest_413))
	      {
		 char *aux_1225;
		 aux_1225 = BSTRING_TO_STRING(dest_413);
		 test1481_415 = fexists(aux_1225);
	      }
	    else
	      {
		 test1481_415 = ((bool_t) 0);
	      }
	    if (test1481_415)
	      {
		 obj_t iport_416;
		 iport_416 = open_input_file_61___r4_ports_6_10_1(dest_413, BNIL);
		 if (INPUT_PORTP(iport_416))
		   {
		      obj_t cs_418;
		      {
			 obj_t list1484_420;
			 list1484_420 = MAKE_PAIR(iport_416, BNIL);
			 cs_418 = read___reader(list1484_420);
		      }
		      close_input_port(iport_416);
		      {
			 bool_t test_1235;
			 {
			    long aux_1238;
			    long aux_1236;
			    aux_1238 = (long) CINT(checksum_412);
			    aux_1236 = (long) CINT(cs_418);
			    test_1235 = (aux_1236 == aux_1238);
			 }
			 if (test_1235)
			   {
			      BUNSPEC;
			   }
			 else
			   {
			      {
				 char *aux_1241;
				 aux_1241 = BSTRING_TO_STRING(dest_413);
				 unlink(aux_1241);
			      }
			    generate_mco_82_433:
			      if (STRINGP(dest_413))
				{
				   obj_t oport_427;
				   oport_427 = open_output_file(dest_413);
				   if (OUTPUT_PORTP(oport_427))
				     {
					{
					   obj_t list1492_429;
					   list1492_429 = MAKE_PAIR(checksum_412, BNIL);
					   fprint___r4_output_6_10_3(oport_427, list1492_429);
					}
					close_output_port(oport_427);
				     }
				   else
				     {
					FAILURE(string1585_module_module, string1586_module_module, dest_413);
				     }
				}
			      else
				{
				   obj_t list1495_431;
				   list1495_431 = MAKE_PAIR(checksum_412, BNIL);
				   print___r4_output_6_10_3(list1495_431);
				}
			   }
		      }
		   }
		 else
		   {
		      user_error_151_tools_error(string1585_module_module, string1587_module_module, dest_413, BNIL);
		   }
	      }
	    else
	      {
		 goto generate_mco_82_433;
	      }
	 }
      }
   }
   {
      bool_t test1508_446;
      {
	 long n1_682;
	 n1_682 = (long) CINT(_nb_error_on_pass__70_tools_error);
	 test1508_446 = (n1_682 > ((long) 0));
      }
      if (test1508_446)
	{
	   {
	      char *arg1513_449;
	      {
		 bool_t test1520_456;
		 {
		    bool_t test1521_457;
		    {
		       obj_t obj_684;
		       obj_684 = _nb_error_on_pass__70_tools_error;
		       test1521_457 = INTEGERP(obj_684);
		    }
		    if (test1521_457)
		      {
			 test1520_456 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
		      }
		    else
		      {
			 test1520_456 = ((bool_t) 0);
		      }
		 }
		 if (test1520_456)
		   {
		      arg1513_449 = "s";
		   }
		 else
		   {
		      arg1513_449 = "";
		   }
	      }
	      {
		 obj_t list1515_451;
		 {
		    obj_t arg1516_452;
		    {
		       obj_t arg1517_453;
		       {
			  obj_t arg1518_454;
			  arg1518_454 = MAKE_PAIR(string1572_module_module, BNIL);
			  {
			     obj_t aux_1265;
			     aux_1265 = string_to_bstring(arg1513_449);
			     arg1517_453 = MAKE_PAIR(aux_1265, arg1518_454);
			  }
		       }
		       arg1516_452 = MAKE_PAIR(string1573_module_module, arg1517_453);
		    }
		    list1515_451 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1516_452);
		 }
		 fprint___r4_output_6_10_3(current_error_port, list1515_451);
	      }
	   }
	   {
	      obj_t res1563_686;
	      exit(((long) -1));
	      res1563_686 = BINT(((long) -1));
	      return res1563_686;
	   }
	}
      else
	{
	   obj_t hooks_458;
	   obj_t hnames_459;
	   hooks_458 = BNIL;
	   hnames_459 = BNIL;
	 loop_460:
	   if (NULLP(hooks_458))
	     {
		return BTRUE;
	     }
	   else
	     {
		bool_t test1527_465;
		{
		   obj_t fun1532_470;
		   fun1532_470 = CAR(hooks_458);
		   {
		      obj_t aux_1276;
		      aux_1276 = PROCEDURE_ENTRY(fun1532_470) (fun1532_470, BEOA);
		      test1527_465 = CBOOL(aux_1276);
		   }
		}
		if (test1527_465)
		  {
		     {
			obj_t hnames_1283;
			obj_t hooks_1281;
			hooks_1281 = CDR(hooks_458);
			hnames_1283 = CDR(hnames_459);
			hnames_459 = hnames_1283;
			hooks_458 = hooks_1281;
			goto loop_460;
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1574_module_module, CAR(hnames_459));
		  }
	     }
	}
   }
}


/* _module-checksum-object */ obj_t 
_module_checksum_object_225_module_module(obj_t env_770)
{
   return module_checksum_object_250_module_module();
}


/* object-init */ obj_t 
object_init_111_module_module()
{
   {
      obj_t arg1534_472;
      arg1534_472 = object___object;
      ccomp_module_module = add_class__117___object(CNST_TABLE_REF(((long) 8)), arg1534_472, allocate_ccomp_env_181_module_module, ((long) 60416), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-ccomp */ ccomp_t 
allocate_ccomp_51_module_module()
{
   {
      ccomp_t new1009_475;
      new1009_475 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
      {
	 long arg1537_476;
	 arg1537_476 = class_num_218___object(ccomp_module_module);
	 {
	    obj_t obj_693;
	    obj_693 = (obj_t) (new1009_475);
	    (((obj_t) CREF(obj_693))->header = MAKE_HEADER(arg1537_476, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_1294;
	 aux_1294 = (object_t) (new1009_475);
	 OBJECT_WIDENING_SET(aux_1294, BFALSE);
      }
      return new1009_475;
   }
}


/* _allocate-ccomp */ obj_t 
_allocate_ccomp_156_module_module(obj_t env_771)
{
   {
      ccomp_t aux_1297;
      aux_1297 = allocate_ccomp_51_module_module();
      return (obj_t) (aux_1297);
   }
}


/* ccomp? */ bool_t 
ccomp__61_module_module(obj_t obj_40)
{
   return is_a__118___object(obj_40, ccomp_module_module);
}


/* _ccomp? */ obj_t 
_ccomp__233_module_module(obj_t env_772, obj_t obj_773)
{
   {
      bool_t aux_1301;
      aux_1301 = ccomp__61_module_module(obj_773);
      return BBOOL(aux_1301);
   }
}


/* make-ccomp */ ccomp_t 
make_ccomp_97_module_module(obj_t id_41, obj_t producer_42, obj_t consumer_43, obj_t finalizer_44, obj_t checksummer_45)
{
   {
      ccomp_t new1002_695;
      new1002_695 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
      {
	 long arg1539_696;
	 arg1539_696 = class_num_218___object(ccomp_module_module);
	 {
	    obj_t obj_702;
	    obj_702 = (obj_t) (new1002_695);
	    (((obj_t) CREF(obj_702))->header = MAKE_HEADER(arg1539_696, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_1308;
	 aux_1308 = (object_t) (new1002_695);
	 OBJECT_WIDENING_SET(aux_1308, BFALSE);
      }
      ((((ccomp_t) CREF(new1002_695))->id) = ((obj_t) id_41), BUNSPEC);
      ((((ccomp_t) CREF(new1002_695))->producer) = ((obj_t) producer_42), BUNSPEC);
      ((((ccomp_t) CREF(new1002_695))->consumer) = ((obj_t) consumer_43), BUNSPEC);
      ((((ccomp_t) CREF(new1002_695))->finalizer) = ((obj_t) finalizer_44), BUNSPEC);
      ((((ccomp_t) CREF(new1002_695))->checksummer) = ((obj_t) checksummer_45), BUNSPEC);
      return new1002_695;
   }
}


/* _make-ccomp */ obj_t 
_make_ccomp_11_module_module(obj_t env_774, obj_t id_775, obj_t producer_776, obj_t consumer_777, obj_t finalizer_778, obj_t checksummer_779)
{
   {
      ccomp_t aux_1316;
      aux_1316 = make_ccomp_97_module_module(id_775, producer_776, consumer_777, finalizer_778, checksummer_779);
      return (obj_t) (aux_1316);
   }
}


/* ccomp-id */ obj_t 
ccomp_id_222_module_module(ccomp_t obj_46)
{
   return (((ccomp_t) CREF(obj_46))->id);
}


/* _ccomp-id */ obj_t 
_ccomp_id_250_module_module(obj_t env_780, obj_t obj_781)
{
   return ccomp_id_222_module_module((ccomp_t) (obj_781));
}


/* ccomp-producer */ obj_t 
ccomp_producer_45_module_module(ccomp_t obj_47)
{
   return (((ccomp_t) CREF(obj_47))->producer);
}


/* _ccomp-producer */ obj_t 
_ccomp_producer_86_module_module(obj_t env_782, obj_t obj_783)
{
   return ccomp_producer_45_module_module((ccomp_t) (obj_783));
}


/* ccomp-consumer */ obj_t 
ccomp_consumer_18_module_module(ccomp_t obj_48)
{
   return (((ccomp_t) CREF(obj_48))->consumer);
}


/* _ccomp-consumer */ obj_t 
_ccomp_consumer_134_module_module(obj_t env_784, obj_t obj_785)
{
   return ccomp_consumer_18_module_module((ccomp_t) (obj_785));
}


/* ccomp-finalizer */ obj_t 
ccomp_finalizer_154_module_module(ccomp_t obj_49)
{
   return (((ccomp_t) CREF(obj_49))->finalizer);
}


/* _ccomp-finalizer */ obj_t 
_ccomp_finalizer_215_module_module(obj_t env_786, obj_t obj_787)
{
   return ccomp_finalizer_154_module_module((ccomp_t) (obj_787));
}


/* ccomp-checksummer */ obj_t 
ccomp_checksummer_97_module_module(ccomp_t obj_50)
{
   return (((ccomp_t) CREF(obj_50))->checksummer);
}


/* _ccomp-checksummer */ obj_t 
_ccomp_checksummer_188_module_module(obj_t env_788, obj_t obj_789)
{
   return ccomp_checksummer_97_module_module((ccomp_t) (obj_789));
}


/* method-init */ obj_t 
method_init_76_module_module()
{
   {
      obj_t object__struct_ccomp_115_791;
      object__struct_ccomp_115_791 = proc1588_module_module;
      add_method__1___object(object__struct_env_210___object, ccomp_module_module, object__struct_ccomp_115_791);
   }
   {
      obj_t struct_object__object_ccomp_100_790;
      struct_object__object_ccomp_100_790 = proc1589_module_module;
      return add_method__1___object(struct_object__object_env_209___object, ccomp_module_module, struct_object__object_ccomp_100_790);
   }
}


/* struct+object->object-ccomp */ obj_t 
struct_object__object_ccomp_100_module_module(obj_t env_792, obj_t o_793, obj_t s_794)
{
   {
      ccomp_t o_502;
      obj_t s_503;
      {
	 ccomp_t aux_1336;
	 o_502 = (ccomp_t) (o_793);
	 s_503 = s_794;
	 {
	    obj_t aux_1339;
	    object_t aux_1337;
	    aux_1339 = STRUCT_REF(s_503, ((long) 0));
	    aux_1337 = (object_t) (o_502);
	    OBJECT_WIDENING_SET(aux_1337, aux_1339);
	 }
	 {
	    obj_t v1014_507;
	    v1014_507 = STRUCT_REF(s_503, ((long) 1));
	    ((((ccomp_t) CREF(o_502))->id) = ((obj_t) v1014_507), BUNSPEC);
	 }
	 {
	    obj_t v1018_508;
	    v1018_508 = STRUCT_REF(s_503, ((long) 2));
	    ((((ccomp_t) CREF(o_502))->producer) = ((obj_t) v1018_508), BUNSPEC);
	 }
	 {
	    obj_t v1022_509;
	    v1022_509 = STRUCT_REF(s_503, ((long) 3));
	    ((((ccomp_t) CREF(o_502))->consumer) = ((obj_t) v1022_509), BUNSPEC);
	 }
	 {
	    obj_t v1026_510;
	    v1026_510 = STRUCT_REF(s_503, ((long) 4));
	    ((((ccomp_t) CREF(o_502))->finalizer) = ((obj_t) v1026_510), BUNSPEC);
	 }
	 {
	    obj_t v1030_511;
	    v1030_511 = STRUCT_REF(s_503, ((long) 5));
	    ((((ccomp_t) CREF(o_502))->checksummer) = ((obj_t) v1030_511), BUNSPEC);
	 }
	 aux_1336 = o_502;
	 return (obj_t) (aux_1336);
      }
   }
}


/* object->struct-ccomp */ obj_t 
object__struct_ccomp_115_module_module(obj_t env_795, obj_t obj1010_796)
{
   {
      ccomp_t obj1010_484;
      obj1010_484 = (ccomp_t) (obj1010_796);
      {
	 obj_t res1011_487;
	 {
	    obj_t aux_1354;
	    aux_1354 = CNST_TABLE_REF(((long) 8));
	    res1011_487 = make_struct(aux_1354, ((long) 6), BUNSPEC);
	 }
	 STRUCT_SET(res1011_487, ((long) 0), BFALSE);
	 {
	    obj_t aux_1358;
	    aux_1358 = (((ccomp_t) CREF(obj1010_484))->id);
	    STRUCT_SET(res1011_487, ((long) 1), aux_1358);
	 }
	 {
	    obj_t aux_1361;
	    aux_1361 = (((ccomp_t) CREF(obj1010_484))->producer);
	    STRUCT_SET(res1011_487, ((long) 2), aux_1361);
	 }
	 {
	    obj_t aux_1364;
	    aux_1364 = (((ccomp_t) CREF(obj1010_484))->consumer);
	    STRUCT_SET(res1011_487, ((long) 3), aux_1364);
	 }
	 {
	    obj_t aux_1367;
	    aux_1367 = (((ccomp_t) CREF(obj1010_484))->finalizer);
	    STRUCT_SET(res1011_487, ((long) 4), aux_1367);
	 }
	 {
	    obj_t aux_1370;
	    aux_1370 = (((ccomp_t) CREF(obj1010_484))->checksummer);
	    STRUCT_SET(res1011_487, ((long) 5), aux_1370);
	 }
	 return res1011_487;
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_module()
{
   module_initialization_70_tools_speek(((long) 0), "MODULE_MODULE");
   module_initialization_70_tools_error(((long) 0), "MODULE_MODULE");
   module_initialization_70_engine_pass(((long) 0), "MODULE_MODULE");
   module_initialization_70_engine_param(((long) 0), "MODULE_MODULE");
   module_initialization_70_heap_restore(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_main(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_statexp(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_impuse(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_include(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_with(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_type(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_foreign(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_eval(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_load(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_pragma(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_checksum(((long) 0), "MODULE_MODULE");
   module_initialization_70_module_option(((long) 0), "MODULE_MODULE");
   return module_initialization_70_module_alibrary(((long) 0), "MODULE_MODULE");
}
