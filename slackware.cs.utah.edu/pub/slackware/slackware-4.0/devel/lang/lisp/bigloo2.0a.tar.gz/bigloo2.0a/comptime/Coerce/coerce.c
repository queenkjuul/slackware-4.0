/*===========================================================================*/
/*   (Coerce/coerce.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_coerce_coerce();
extern obj_t make_box_202_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t _magic__144_type_cache;
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_coercion(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_coerce_pproto(long, char *);
extern obj_t module_initialization_70_coerce_convert(long, char *);
extern obj_t module_initialization_70_coerce_app(long, char *);
extern obj_t module_initialization_70_coerce_apply(long, char *);
extern obj_t module_initialization_70_coerce_funcall(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t runtime_type_error_216_coerce_convert(obj_t, obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
extern obj_t pfunction_proto_197_coerce_pproto(long, variable_t);
static obj_t imported_modules_init_94_coerce_coerce();
extern obj_t inc_ppmarge__59_coerce_pproto();
extern obj_t add_generic__110___object(obj_t, obj_t);
extern node_t coerce__182_coerce_coerce(node_t, type_t);
extern obj_t dec_ppmarge__31_coerce_pproto();
static obj_t library_modules_init_112_coerce_coerce();
static obj_t _coerce_1708_53_coerce_coerce(obj_t, obj_t, obj_t);
static obj_t _coerce__default1457_64_coerce_coerce(obj_t, obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_coerce_coerce();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern node_t convert__122_coerce_convert(node_t, type_t, type_t);
extern type_t typeof_coerce_typeof(node_t);
extern obj_t _exit__255_type_cache;
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t pvariable_proto_90_coerce_pproto(long, variable_t);
static node_t coerce__default1457_179_coerce_coerce(node_t, type_t);
static obj_t _coerce_function_1707_181_coerce_coerce(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t coerce_function__220_coerce_coerce(variable_t);
extern obj_t read___reader(obj_t);
extern bool_t coercer_exists__27_type_coercion(type_t, type_t);
static obj_t require_initialization_114_coerce_coerce = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_coerce_coerce();
extern obj_t _bool__149_type_cache;
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(coerce_function__env_155_coerce_coerce, _coerce_function_1707_181_coerce_coerce1718, _coerce_function_1707_181_coerce_coerce, 0L, 1);
DEFINE_STRING(string1712_coerce_coerce, string1712_coerce_coerce1719, "COERCE!-DEFAULT1457 ", 20);
DEFINE_STRING(string1711_coerce_coerce, string1711_coerce_coerce1720, "No method for this object", 25);
DEFINE_STRING(string1709_coerce_coerce, string1709_coerce_coerce1721, "coerce!", 7);
DEFINE_STRING(string1710_coerce_coerce, string1710_coerce_coerce1722, "Unexepected `closure' node", 26);
DEFINE_STATIC_PROCEDURE(coerce__default1457_env_112_coerce_coerce, _coerce__default1457_64_coerce_coerce1723, _coerce__default1457_64_coerce_coerce, 0L, 2);
DEFINE_EXPORT_GENERIC(coerce__env_127_coerce_coerce, _coerce_1708_53_coerce_coerce1724, _coerce_1708_53_coerce_coerce, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_coerce_coerce(long checksum_1402, char *from_1403)
{
   if (CBOOL(require_initialization_114_coerce_coerce))
     {
	require_initialization_114_coerce_coerce = BBOOL(((bool_t) 0));
	library_modules_init_112_coerce_coerce();
	cnst_init_137_coerce_coerce();
	imported_modules_init_94_coerce_coerce();
	method_init_76_coerce_coerce();
	toplevel_init_63_coerce_coerce();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_coerce_coerce()
{
   module_initialization_70___object(((long) 0), "COERCE_COERCE");
   module_initialization_70___reader(((long) 0), "COERCE_COERCE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_coerce_coerce()
{
   {
      obj_t cnst_port_138_1394;
      cnst_port_138_1394 = open_input_string(string1712_coerce_coerce);
      {
	 long i_1395;
	 i_1395 = ((long) 0);
       loop_1396:
	 {
	    bool_t test1713_1397;
	    test1713_1397 = (i_1395 == ((long) -1));
	    if (test1713_1397)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1714_1398;
		    {
		       obj_t list1715_1399;
		       {
			  obj_t arg1716_1400;
			  arg1716_1400 = BNIL;
			  list1715_1399 = MAKE_PAIR(cnst_port_138_1394, arg1716_1400);
		       }
		       arg1714_1398 = read___reader(list1715_1399);
		    }
		    CNST_TABLE_SET(i_1395, arg1714_1398);
		 }
		 {
		    int aux_1401;
		    {
		       long aux_1420;
		       aux_1420 = (i_1395 - ((long) 1));
		       aux_1401 = (int) (aux_1420);
		    }
		    {
		       long i_1423;
		       i_1423 = (long) (aux_1401);
		       i_1395 = i_1423;
		       goto loop_1396;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_coerce_coerce()
{
   return BUNSPEC;
}


/* coerce-function! */ obj_t 
coerce_function__220_coerce_coerce(variable_t variable_1)
{
   {
      value_t fun_733;
      fun_733 = (((variable_t) CREF(variable_1))->value);
      {
	 obj_t body_734;
	 {
	    sfun_t obj_1243;
	    obj_1243 = (sfun_t) (fun_733);
	    body_734 = (((sfun_t) CREF(obj_1243))->body);
	 }
	 {
	    type_t tres_735;
	    tres_735 = (((variable_t) CREF(variable_1))->type);
	    {
	       pfunction_proto_197_coerce_pproto(((long) 3), variable_1);
	       {
		  node_t arg1478_736;
		  arg1478_736 = coerce__182_coerce_coerce((node_t) (body_734), tres_735);
		  {
		     sfun_t obj_1245;
		     obj_t val1135_1246;
		     obj_1245 = (sfun_t) (fun_733);
		     val1135_1246 = (obj_t) (arg1478_736);
		     return ((((sfun_t) CREF(obj_1245))->body) = ((obj_t) val1135_1246), BUNSPEC);
		  }
	       }
	    }
	 }
      }
   }
}


/* _coerce-function!1707 */ obj_t 
_coerce_function_1707_181_coerce_coerce(obj_t env_1386, obj_t variable_1387)
{
   return coerce_function__220_coerce_coerce((variable_t) (variable_1387));
}


/* method-init */ obj_t 
method_init_76_coerce_coerce()
{
   add_generic__110___object(coerce__env_127_coerce_coerce, coerce__default1457_env_112_coerce_coerce);
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, var_ast_node, ((long) 2));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, pragma_ast_node, ((long) 5));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, cast_ast_node, ((long) 6));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, setq_ast_node, ((long) 7));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, conditional_ast_node, ((long) 8));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, fail_ast_node, ((long) 9));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, select_ast_node, ((long) 10));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, let_fun_218_ast_node, ((long) 11));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, let_var_6_ast_node, ((long) 12));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, set_ex_it_116_ast_node, ((long) 13));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, jump_ex_it_184_ast_node, ((long) 14));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, make_box_202_ast_node, ((long) 15));
   add_inlined_method__244___object(coerce__env_127_coerce_coerce, box_ref_242_ast_node, ((long) 16));
   {
      long aux_1455;
      aux_1455 = add_inlined_method__244___object(coerce__env_127_coerce_coerce, box_set__221_ast_node, ((long) 17));
      return BINT(aux_1455);
   }
}


/* coerce! */ node_t 
coerce__182_coerce_coerce(node_t node_2, type_t to_3)
{
   {
      obj_t method1570_1068;
      obj_t class1575_1069;
      {
	 obj_t arg1578_1066;
	 obj_t arg1580_1067;
	 {
	    object_t obj_1247;
	    obj_1247 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1248;
	       pre_method_105_1248 = PROCEDURE_REF(coerce__env_127_coerce_coerce, ((long) 2));
	       if (INTEGERP(pre_method_105_1248))
		 {
		    PROCEDURE_SET(coerce__env_127_coerce_coerce, ((long) 2), BUNSPEC);
		    arg1578_1066 = pre_method_105_1248;
		 }
	       else
		 {
		    long obj_class_num_177_1253;
		    obj_class_num_177_1253 = TYPE(obj_1247);
		    {
		       obj_t arg1177_1254;
		       arg1177_1254 = PROCEDURE_REF(coerce__env_127_coerce_coerce, ((long) 1));
		       {
			  long arg1178_1258;
			  {
			     long arg1179_1259;
			     arg1179_1259 = OBJECT_TYPE;
			     arg1178_1258 = (obj_class_num_177_1253 - arg1179_1259);
			  }
			  arg1578_1066 = VECTOR_REF(arg1177_1254, arg1178_1258);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1264;
	    object_1264 = (object_t) (node_2);
	    {
	       long arg1180_1265;
	       {
		  long arg1181_1266;
		  long arg1182_1267;
		  arg1181_1266 = TYPE(object_1264);
		  arg1182_1267 = OBJECT_TYPE;
		  arg1180_1265 = (arg1181_1266 - arg1182_1267);
	       }
	       {
		  obj_t vector_1271;
		  vector_1271 = _classes__134___object;
		  arg1580_1067 = VECTOR_REF(vector_1271, arg1180_1265);
	       }
	    }
	 }
	 {
	    obj_t aux_1473;
	    method1570_1068 = arg1578_1066;
	    class1575_1069 = arg1580_1067;
	    {
	       if (INTEGERP(method1570_1068))
		 {
		    switch ((long) CINT(method1570_1068))
		      {
		      case ((long) 0):
			 {
			    atom_t node_1075;
			    node_1075 = (atom_t) (node_2);
			    {
			       type_t arg1583_1077;
			       arg1583_1077 = typeof_coerce_typeof((node_t) (node_1075));
			       {
				  node_t aux_1479;
				  aux_1479 = convert__122_coerce_convert((node_t) (node_1075), arg1583_1077, to_3);
				  aux_1473 = (obj_t) (aux_1479);
			       }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t node_1078;
			    node_1078 = (kwote_t) (node_2);
			    {
			       type_t arg1584_1080;
			       arg1584_1080 = typeof_coerce_typeof((node_t) (node_1078));
			       {
				  node_t aux_1486;
				  aux_1486 = convert__122_coerce_convert((node_t) (node_1078), arg1584_1080, to_3);
				  aux_1473 = (obj_t) (aux_1486);
			       }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1081;
			    node_1081 = (var_t) (node_2);
			    {
			       type_t type_1084;
			       type_1084 = typeof_coerce_typeof((node_t) (node_1081));
			       {
				  node_t aux_1493;
				  aux_1493 = convert__122_coerce_convert((node_t) (node_1081), type_1084, to_3);
				  aux_1473 = (obj_t) (aux_1493);
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    obj_t arg1587_1089;
			    {
			       obj_t aux_1497;
			       {
				  closure_t aux_1498;
				  aux_1498 = (closure_t) (node_2);
				  aux_1497 = (obj_t) (aux_1498);
			       }
			       arg1587_1089 = shape_tools_shape(aux_1497);
			    }
			    aux_1473 = internal_error_43_tools_error(string1709_coerce_coerce, string1710_coerce_coerce, arg1587_1089);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1090;
			    node_1090 = (sequence_t) (node_2);
			    {
			       obj_t hook_1093;
			       {
				  sequence_t aux_1504;
				  hook_1093 = (((sequence_t) CREF(node_1090))->nodes);
				loop_1094:
				  {
				     bool_t test_1505;
				     {
					obj_t aux_1506;
					aux_1506 = CDR(hook_1093);
					test_1505 = NULLP(aux_1506);
				     }
				     if (test_1505)
				       {
					  {
					     node_t arg1592_1097;
					     {
						node_t aux_1509;
						{
						   obj_t aux_1510;
						   aux_1510 = CAR(hook_1093);
						   aux_1509 = (node_t) (aux_1510);
						}
						arg1592_1097 = coerce__182_coerce_coerce(aux_1509, to_3);
					     }
					     {
						obj_t aux_1514;
						aux_1514 = (obj_t) (arg1592_1097);
						SET_CAR(hook_1093, aux_1514);
					     }
					  }
					  aux_1504 = node_1090;
				       }
				     else
				       {
					  {
					     node_t arg1594_1099;
					     {
						obj_t arg1595_1100;
						type_t arg1598_1101;
						arg1595_1100 = CAR(hook_1093);
						{
						   node_t aux_1518;
						   {
						      obj_t aux_1519;
						      aux_1519 = CAR(hook_1093);
						      aux_1518 = (node_t) (aux_1519);
						   }
						   arg1598_1101 = typeof_coerce_typeof(aux_1518);
						}
						arg1594_1099 = coerce__182_coerce_coerce((node_t) (arg1595_1100), arg1598_1101);
					     }
					     {
						obj_t aux_1525;
						aux_1525 = (obj_t) (arg1594_1099);
						SET_CAR(hook_1093, aux_1525);
					     }
					  }
					  {
					     obj_t hook_1528;
					     hook_1528 = CDR(hook_1093);
					     hook_1093 = hook_1528;
					     goto loop_1094;
					  }
				       }
				  }
				  aux_1473 = (obj_t) (aux_1504);
			       }
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    pragma_t node_1105;
			    node_1105 = (pragma_t) (node_2);
			    {
			       obj_t values_1108;
			       {
				  node_t aux_1533;
				  values_1108 = (((pragma_t) CREF(node_1105))->args);
				loop_1109:
				  if (NULLP(values_1108))
				    {
				       type_t arg1607_1112;
				       arg1607_1112 = typeof_coerce_typeof((node_t) (node_1105));
				       aux_1533 = convert__122_coerce_convert((node_t) (node_1105), arg1607_1112, to_3);
				    }
				  else
				    {
				       {
					  node_t arg1608_1113;
					  {
					     obj_t arg1609_1114;
					     type_t arg1610_1115;
					     arg1609_1114 = CAR(values_1108);
					     {
						node_t aux_1541;
						{
						   obj_t aux_1542;
						   aux_1542 = CAR(values_1108);
						   aux_1541 = (node_t) (aux_1542);
						}
						arg1610_1115 = typeof_coerce_typeof(aux_1541);
					     }
					     arg1608_1113 = coerce__182_coerce_coerce((node_t) (arg1609_1114), arg1610_1115);
					  }
					  {
					     obj_t aux_1548;
					     aux_1548 = (obj_t) (arg1608_1113);
					     SET_CAR(values_1108, aux_1548);
					  }
				       }
				       {
					  obj_t values_1551;
					  values_1551 = CDR(values_1108);
					  values_1108 = values_1551;
					  goto loop_1109;
				       }
				    }
				  aux_1473 = (obj_t) (aux_1533);
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    cast_t node_1118;
			    node_1118 = (cast_t) (node_2);
			    {
			       node_t arg1615_1121;
			       {
				  node_t arg1617_1122;
				  type_t arg1618_1123;
				  arg1617_1122 = (((cast_t) CREF(node_1118))->arg);
				  arg1618_1123 = typeof_coerce_typeof((((cast_t) CREF(node_1118))->arg));
				  arg1615_1121 = coerce__182_coerce_coerce(arg1617_1122, arg1618_1123);
			       }
			       ((((cast_t) CREF(node_1118))->arg) = ((node_t) arg1615_1121), BUNSPEC);
			    }
			    {
			       node_t aux_1561;
			       aux_1561 = convert__122_coerce_convert((node_t) (node_1118), (((cast_t) CREF(node_1118))->type), to_3);
			       aux_1473 = (obj_t) (aux_1561);
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    setq_t node_1126;
			    node_1126 = (setq_t) (node_2);
			    {
			       node_t arg1622_1129;
			       {
				  type_t aux_1567;
				  {
				     variable_t arg1625_1132;
				     {
					var_t arg1627_1133;
					arg1627_1133 = (((setq_t) CREF(node_1126))->var);
					arg1625_1132 = (((var_t) CREF(arg1627_1133))->variable);
				     }
				     aux_1567 = (((variable_t) CREF(arg1625_1132))->type);
				  }
				  arg1622_1129 = coerce__182_coerce_coerce((((setq_t) CREF(node_1126))->value), aux_1567);
			       }
			       ((((setq_t) CREF(node_1126))->value) = ((node_t) arg1622_1129), BUNSPEC);
			    }
			    {
			       node_t aux_1574;
			       aux_1574 = convert__122_coerce_convert((node_t) (node_1126), (type_t) (_unspec__87_type_cache), to_3);
			       aux_1473 = (obj_t) (aux_1574);
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    conditional_t node_1134;
			    node_1134 = (conditional_t) (node_2);
			    {
			       node_t arg1628_1137;
			       arg1628_1137 = coerce__182_coerce_coerce((((conditional_t) CREF(node_1134))->test), (type_t) (_bool__149_type_cache));
			       ((((conditional_t) CREF(node_1134))->test) = ((node_t) arg1628_1137), BUNSPEC);
			    }
			    {
			       node_t arg1632_1139;
			       arg1632_1139 = coerce__182_coerce_coerce((((conditional_t) CREF(node_1134))->true), to_3);
			       ((((conditional_t) CREF(node_1134))->true) = ((node_t) arg1632_1139), BUNSPEC);
			    }
			    {
			       node_t arg1634_1141;
			       arg1634_1141 = coerce__182_coerce_coerce((((conditional_t) CREF(node_1134))->false), to_3);
			       ((((conditional_t) CREF(node_1134))->false) = ((node_t) arg1634_1141), BUNSPEC);
			    }
			    aux_1473 = (obj_t) (node_1134);
			 }
			 break;
		      case ((long) 9):
			 {
			    fail_t node_1143;
			    node_1143 = (fail_t) (node_2);
			    {
			       node_t arg1638_1146;
			       arg1638_1146 = coerce__182_coerce_coerce((((fail_t) CREF(node_1143))->proc), (type_t) (_obj__252_type_cache));
			       ((((fail_t) CREF(node_1143))->proc) = ((node_t) arg1638_1146), BUNSPEC);
			    }
			    {
			       node_t arg1640_1148;
			       arg1640_1148 = coerce__182_coerce_coerce((((fail_t) CREF(node_1143))->msg), (type_t) (_obj__252_type_cache));
			       ((((fail_t) CREF(node_1143))->msg) = ((node_t) arg1640_1148), BUNSPEC);
			    }
			    {
			       node_t arg1645_1150;
			       arg1645_1150 = coerce__182_coerce_coerce((((fail_t) CREF(node_1143))->obj), (type_t) (_obj__252_type_cache));
			       ((((fail_t) CREF(node_1143))->obj) = ((node_t) arg1645_1150), BUNSPEC);
			    }
			    {
			       node_t aux_1604;
			       aux_1604 = convert__122_coerce_convert((node_t) (node_1143), (type_t) (_magic__144_type_cache), to_3);
			       aux_1473 = (obj_t) (aux_1604);
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    select_t node_1152;
			    node_1152 = (select_t) (node_2);
			    {
			       obj_t clauses_1155;
			       type_t test_type_84_1156;
			       type_t test_node_type_36_1157;
			       clauses_1155 = (((select_t) CREF(node_1152))->clauses);
			       test_type_84_1156 = (((select_t) CREF(node_1152))->item_type_130);
			       test_node_type_36_1157 = typeof_coerce_typeof((((select_t) CREF(node_1152))->test));
			       {
				  bool_t test1647_1158;
				  test1647_1158 = coercer_exists__27_type_coercion(test_node_type_36_1157, test_type_84_1156);
				  if (test1647_1158)
				    {
				       {
					  node_t arg1648_1159;
					  arg1648_1159 = coerce__182_coerce_coerce((((select_t) CREF(node_1152))->test), test_type_84_1156);
					  ((((select_t) CREF(node_1152))->test) = ((node_t) arg1648_1159), BUNSPEC);
				       }
				       {
					  obj_t l1443_1161;
					  l1443_1161 = clauses_1155;
					lname1444_1162:
					  if (PAIRP(l1443_1161))
					    {
					       {
						  obj_t clause_1164;
						  clause_1164 = CAR(l1443_1161);
						  {
						     node_t arg1652_1165;
						     {
							node_t aux_1622;
							{
							   obj_t aux_1623;
							   aux_1623 = CDR(clause_1164);
							   aux_1622 = (node_t) (aux_1623);
							}
							arg1652_1165 = coerce__182_coerce_coerce(aux_1622, to_3);
						     }
						     {
							obj_t aux_1627;
							aux_1627 = (obj_t) (arg1652_1165);
							SET_CDR(clause_1164, aux_1627);
						     }
						  }
					       }
					       {
						  obj_t l1443_1630;
						  l1443_1630 = CDR(l1443_1161);
						  l1443_1161 = l1443_1630;
						  goto lname1444_1162;
					       }
					    }
					  else
					    {
					       ((bool_t) 1);
					    }
				       }
				       aux_1473 = (obj_t) (node_1152);
				    }
				  else
				    {
				       obj_t arg1655_1168;
				       {
					  obj_t aux_1633;
					  {
					     node_t aux_1636;
					     aux_1636 = (((select_t) CREF(node_1152))->test);
					     aux_1633 = (obj_t) (aux_1636);
					  }
					  arg1655_1168 = runtime_type_error_216_coerce_convert((((select_t) CREF(node_1152))->loc), (((type_t) CREF(test_type_84_1156))->id), aux_1633);
				       }
				       {
					  node_t aux_1640;
					  aux_1640 = coerce__182_coerce_coerce((node_t) (arg1655_1168), to_3);
					  aux_1473 = (obj_t) (aux_1640);
				       }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    let_fun_218_t node_1173;
			    node_1173 = (let_fun_218_t) (node_2);
			    inc_ppmarge__59_coerce_pproto();
			    {
			       obj_t l1446_1176;
			       l1446_1176 = (((let_fun_218_t) CREF(node_1173))->locals);
			     lname1447_1177:
			       if (PAIRP(l1446_1176))
				 {
				    {
				       variable_t aux_1648;
				       {
					  obj_t aux_1649;
					  aux_1649 = CAR(l1446_1176);
					  aux_1648 = (variable_t) (aux_1649);
				       }
				       coerce_function__220_coerce_coerce(aux_1648);
				    }
				    {
				       obj_t l1446_1653;
				       l1446_1653 = CDR(l1446_1176);
				       l1446_1176 = l1446_1653;
				       goto lname1447_1177;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1666_1182;
			       arg1666_1182 = coerce__182_coerce_coerce((((let_fun_218_t) CREF(node_1173))->body), to_3);
			       ((((let_fun_218_t) CREF(node_1173))->body) = ((node_t) arg1666_1182), BUNSPEC);
			    }
			    dec_ppmarge__31_coerce_pproto();
			    aux_1473 = (obj_t) (node_1173);
			 }
			 break;
		      case ((long) 12):
			 {
			    let_var_6_t node_1184;
			    node_1184 = (let_var_6_t) (node_2);
			    inc_ppmarge__59_coerce_pproto();
			    {
			       obj_t l1449_1187;
			       l1449_1187 = (((let_var_6_t) CREF(node_1184))->bindings);
			     lname1450_1188:
			       if (PAIRP(l1449_1187))
				 {
				    {
				       obj_t binding_1191;
				       binding_1191 = CAR(l1449_1187);
				       {
					  variable_t aux_1666;
					  {
					     obj_t aux_1667;
					     aux_1667 = CAR(binding_1191);
					     aux_1666 = (variable_t) (aux_1667);
					  }
					  pvariable_proto_90_coerce_pproto(((long) 3), aux_1666);
				       }
				       {
					  node_t arg1673_1194;
					  {
					     type_t aux_1675;
					     node_t aux_1671;
					     {
						local_t obj_1348;
						{
						   obj_t aux_1676;
						   aux_1676 = CAR(binding_1191);
						   obj_1348 = (local_t) (aux_1676);
						}
						aux_1675 = (((local_t) CREF(obj_1348))->type);
					     }
					     {
						obj_t aux_1672;
						aux_1672 = CDR(binding_1191);
						aux_1671 = (node_t) (aux_1672);
					     }
					     arg1673_1194 = coerce__182_coerce_coerce(aux_1671, aux_1675);
					  }
					  {
					     obj_t aux_1681;
					     aux_1681 = (obj_t) (arg1673_1194);
					     SET_CDR(binding_1191, aux_1681);
					  }
				       }
				    }
				    {
				       obj_t l1449_1684;
				       l1449_1684 = CDR(l1449_1187);
				       l1449_1187 = l1449_1684;
				       goto lname1450_1188;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1679_1199;
			       arg1679_1199 = coerce__182_coerce_coerce((((let_var_6_t) CREF(node_1184))->body), to_3);
			       ((((let_var_6_t) CREF(node_1184))->body) = ((node_t) arg1679_1199), BUNSPEC);
			    }
			    dec_ppmarge__31_coerce_pproto();
			    aux_1473 = (obj_t) (node_1184);
			 }
			 break;
		      case ((long) 13):
			 {
			    set_ex_it_116_t node_1201;
			    node_1201 = (set_ex_it_116_t) (node_2);
			    {
			       node_t arg1681_1204;
			       {
				  node_t aux_1693;
				  {
				     var_t aux_1694;
				     aux_1694 = (((set_ex_it_116_t) CREF(node_1201))->var);
				     aux_1693 = (node_t) (aux_1694);
				  }
				  arg1681_1204 = coerce__182_coerce_coerce(aux_1693, (type_t) (_exit__255_type_cache));
			       }
			       {
				  var_t val1388_1357;
				  val1388_1357 = (var_t) (arg1681_1204);
				  ((((set_ex_it_116_t) CREF(node_1201))->var) = ((var_t) val1388_1357), BUNSPEC);
			       }
			    }
			    {
			       variable_t aux_1701;
			       {
				  var_t arg1685_1208;
				  arg1685_1208 = (((set_ex_it_116_t) CREF(node_1201))->var);
				  aux_1701 = (((var_t) CREF(arg1685_1208))->variable);
			       }
			       pvariable_proto_90_coerce_pproto(((long) 3), aux_1701);
			    }
			    {
			       node_t arg1686_1209;
			       arg1686_1209 = coerce__182_coerce_coerce((((set_ex_it_116_t) CREF(node_1201))->body), to_3);
			       ((((set_ex_it_116_t) CREF(node_1201))->body) = ((node_t) arg1686_1209), BUNSPEC);
			    }
			    aux_1473 = (obj_t) (node_1201);
			 }
			 break;
		      case ((long) 14):
			 {
			    jump_ex_it_184_t node_1211;
			    node_1211 = (jump_ex_it_184_t) (node_2);
			    {
			       node_t arg1689_1214;
			       arg1689_1214 = coerce__182_coerce_coerce((((jump_ex_it_184_t) CREF(node_1211))->exit), (type_t) (_exit__255_type_cache));
			       ((((jump_ex_it_184_t) CREF(node_1211))->exit) = ((node_t) arg1689_1214), BUNSPEC);
			    }
			    {
			       node_t arg1692_1216;
			       arg1692_1216 = coerce__182_coerce_coerce((((jump_ex_it_184_t) CREF(node_1211))->value), to_3);
			       ((((jump_ex_it_184_t) CREF(node_1211))->value) = ((node_t) arg1692_1216), BUNSPEC);
			    }
			    aux_1473 = (obj_t) (node_1211);
			 }
			 break;
		      case ((long) 15):
			 {
			    make_box_202_t node_1218;
			    node_1218 = (make_box_202_t) (node_2);
			    {
			       node_t arg1694_1221;
			       arg1694_1221 = coerce__182_coerce_coerce((((make_box_202_t) CREF(node_1218))->value), (type_t) (_obj__252_type_cache));
			       ((((make_box_202_t) CREF(node_1218))->value) = ((node_t) arg1694_1221), BUNSPEC);
			    }
			    aux_1473 = (obj_t) (node_1218);
			 }
			 break;
		      case ((long) 16):
			 {
			    node_t aux_1724;
			    {
			       node_t aux_1725;
			       {
				  box_ref_242_t aux_1726;
				  aux_1726 = (box_ref_242_t) (node_2);
				  aux_1725 = (node_t) (aux_1726);
			       }
			       aux_1724 = convert__122_coerce_convert(aux_1725, (type_t) (_obj__252_type_cache), to_3);
			    }
			    aux_1473 = (obj_t) (aux_1724);
			 }
			 break;
		      case ((long) 17):
			 {
			    box_set__221_t node_1226;
			    node_1226 = (box_set__221_t) (node_2);
			    {
			       local_t obj_1374;
			       type_t val1092_1375;
			       {
				  variable_t aux_1733;
				  {
				     var_t arg1698_1230;
				     arg1698_1230 = (((box_set__221_t) CREF(node_1226))->var);
				     aux_1733 = (((var_t) CREF(arg1698_1230))->variable);
				  }
				  obj_1374 = (local_t) (aux_1733);
			       }
			       val1092_1375 = (type_t) (_obj__252_type_cache);
			       ((((local_t) CREF(obj_1374))->type) = ((type_t) val1092_1375), BUNSPEC);
			    }
			    {
			       node_t arg1699_1231;
			       arg1699_1231 = coerce__182_coerce_coerce((((box_set__221_t) CREF(node_1226))->value), (type_t) (_obj__252_type_cache));
			       ((((box_set__221_t) CREF(node_1226))->value) = ((node_t) arg1699_1231), BUNSPEC);
			    }
			    {
			       node_t aux_1743;
			       aux_1743 = convert__122_coerce_convert((node_t) (node_1226), (type_t) (_unspec__87_type_cache), to_3);
			       aux_1473 = (obj_t) (aux_1743);
			    }
			 }
			 break;
		      default:
		       case_else1576_1072:
			 if (PROCEDUREP(method1570_1068))
			   {
			      aux_1473 = PROCEDURE_ENTRY(method1570_1068) (method1570_1068, (obj_t) (node_2), (obj_t) (to_3), BEOA);
			   }
			 else
			   {
			      obj_t fun1567_1062;
			      fun1567_1062 = PROCEDURE_REF(coerce__env_127_coerce_coerce, ((long) 0));
			      aux_1473 = PROCEDURE_ENTRY(fun1567_1062) (fun1567_1062, (obj_t) (node_2), (obj_t) (to_3), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1576_1072;
		 }
	    }
	    return (node_t) (aux_1473);
	 }
      }
   }
}


/* _coerce!1708 */ obj_t 
_coerce_1708_53_coerce_coerce(obj_t env_1388, obj_t node_1389, obj_t to_1390)
{
   {
      node_t aux_1762;
      aux_1762 = coerce__182_coerce_coerce((node_t) (node_1389), (type_t) (to_1390));
      return (obj_t) (aux_1762);
   }
}


/* coerce!-default1457 */ node_t 
coerce__default1457_179_coerce_coerce(node_t node_4, type_t to_5)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1711_coerce_coerce, (obj_t) (node_4));
}


/* _coerce!-default1457 */ obj_t 
_coerce__default1457_64_coerce_coerce(obj_t env_1391, obj_t node_1392, obj_t to_1393)
{
   {
      node_t aux_1770;
      aux_1770 = coerce__default1457_179_coerce_coerce((node_t) (node_1392), (type_t) (to_1393));
      return (obj_t) (aux_1770);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_coerce_coerce()
{
   module_initialization_70_tools_trace(((long) 0), "COERCE_COERCE");
   module_initialization_70_engine_param(((long) 0), "COERCE_COERCE");
   module_initialization_70_tools_shape(((long) 0), "COERCE_COERCE");
   module_initialization_70_tools_error(((long) 0), "COERCE_COERCE");
   module_initialization_70_type_type(((long) 0), "COERCE_COERCE");
   module_initialization_70_type_cache(((long) 0), "COERCE_COERCE");
   module_initialization_70_type_coercion(((long) 0), "COERCE_COERCE");
   module_initialization_70_ast_var(((long) 0), "COERCE_COERCE");
   module_initialization_70_ast_node(((long) 0), "COERCE_COERCE");
   module_initialization_70_coerce_pproto(((long) 0), "COERCE_COERCE");
   module_initialization_70_coerce_convert(((long) 0), "COERCE_COERCE");
   module_initialization_70_coerce_app(((long) 0), "COERCE_COERCE");
   module_initialization_70_coerce_apply(((long) 0), "COERCE_COERCE");
   module_initialization_70_coerce_funcall(((long) 0), "COERCE_COERCE");
   return module_initialization_70_coerce_typeof(((long) 0), "COERCE_COERCE");
}
