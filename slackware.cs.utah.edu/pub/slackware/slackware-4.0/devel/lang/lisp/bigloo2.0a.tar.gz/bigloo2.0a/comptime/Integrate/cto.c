/*===========================================================================*/
/*   (Integrate/cto.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_cto();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t set_cto__5_integrate_cto(node_t, local_t);
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_cto(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_integrate_cto();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _set_cto__default1539_81_integrate_cto(obj_t, obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_integrate_cto();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_integrate_cto();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t set_cto__default1539_137_integrate_cto(node_t, local_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _set_cto_1780_78_integrate_cto(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_integrate_cto = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_integrate_cto();
static obj_t __cnst[1];

DEFINE_STATIC_PROCEDURE(set_cto__default1539_env_77_integrate_cto, _set_cto__default1539_81_integrate_cto1790, _set_cto__default1539_81_integrate_cto, 0L, 2);
DEFINE_STRING(string1784_integrate_cto, string1784_integrate_cto1791, "SET-CTO!-DEFAULT1539 ", 21);
DEFINE_STRING(string1783_integrate_cto, string1783_integrate_cto1792, "No method for this object", 25);
DEFINE_STRING(string1782_integrate_cto, string1782_integrate_cto1793, "Unexpected closure", 18);
DEFINE_STRING(string1781_integrate_cto, string1781_integrate_cto1794, "set-cto!", 8);
DEFINE_EXPORT_GENERIC(set_cto__env_185_integrate_cto, _set_cto_1780_78_integrate_cto1795, _set_cto_1780_78_integrate_cto, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_integrate_cto(long checksum_1641, char *from_1642)
{
   if (CBOOL(require_initialization_114_integrate_cto))
     {
	require_initialization_114_integrate_cto = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_cto();
	cnst_init_137_integrate_cto();
	imported_modules_init_94_integrate_cto();
	method_init_76_integrate_cto();
	toplevel_init_63_integrate_cto();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_cto()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_CTO");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_CTO");
   module_initialization_70___reader(((long) 0), "INTEGRATE_CTO");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_cto()
{
   {
      obj_t cnst_port_138_1633;
      cnst_port_138_1633 = open_input_string(string1784_integrate_cto);
      {
	 long i_1634;
	 i_1634 = ((long) 0);
       loop_1635:
	 {
	    bool_t test1785_1636;
	    test1785_1636 = (i_1634 == ((long) -1));
	    if (test1785_1636)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1786_1637;
		    {
		       obj_t list1787_1638;
		       {
			  obj_t arg1788_1639;
			  arg1788_1639 = BNIL;
			  list1787_1638 = MAKE_PAIR(cnst_port_138_1633, arg1788_1639);
		       }
		       arg1786_1637 = read___reader(list1787_1638);
		    }
		    CNST_TABLE_SET(i_1634, arg1786_1637);
		 }
		 {
		    int aux_1640;
		    {
		       long aux_1660;
		       aux_1660 = (i_1634 - ((long) 1));
		       aux_1640 = (int) (aux_1660);
		    }
		    {
		       long i_1663;
		       i_1663 = (long) (aux_1640);
		       i_1634 = i_1663;
		       goto loop_1635;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_cto()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_integrate_cto()
{
   add_generic__110___object(set_cto__env_185_integrate_cto, set_cto__default1539_env_77_integrate_cto);
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, var_ast_node, ((long) 2));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, app_ast_node, ((long) 5));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, select_ast_node, ((long) 13));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(set_cto__env_185_integrate_cto, box_set__221_ast_node, ((long) 19));
   {
      long aux_1686;
      aux_1686 = add_inlined_method__244___object(set_cto__env_185_integrate_cto, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_1686);
   }
}


/* set-cto! */ obj_t 
set_cto__5_integrate_cto(node_t node_1, local_t local_2)
{
 set_cto__5_integrate_cto:
   {
      obj_t method1677_1301;
      obj_t class1682_1302;
      {
	 obj_t arg1685_1299;
	 obj_t arg1686_1300;
	 {
	    object_t obj_1520;
	    obj_1520 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_1521;
	       pre_method_105_1521 = PROCEDURE_REF(set_cto__env_185_integrate_cto, ((long) 2));
	       if (INTEGERP(pre_method_105_1521))
		 {
		    PROCEDURE_SET(set_cto__env_185_integrate_cto, ((long) 2), BUNSPEC);
		    arg1685_1299 = pre_method_105_1521;
		 }
	       else
		 {
		    long obj_class_num_177_1526;
		    obj_class_num_177_1526 = TYPE(obj_1520);
		    {
		       obj_t arg1177_1527;
		       arg1177_1527 = PROCEDURE_REF(set_cto__env_185_integrate_cto, ((long) 1));
		       {
			  long arg1178_1531;
			  {
			     long arg1179_1532;
			     arg1179_1532 = OBJECT_TYPE;
			     arg1178_1531 = (obj_class_num_177_1526 - arg1179_1532);
			  }
			  arg1685_1299 = VECTOR_REF(arg1177_1527, arg1178_1531);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1537;
	    object_1537 = (object_t) (node_1);
	    {
	       long arg1180_1538;
	       {
		  long arg1181_1539;
		  long arg1182_1540;
		  arg1181_1539 = TYPE(object_1537);
		  arg1182_1540 = OBJECT_TYPE;
		  arg1180_1538 = (arg1181_1539 - arg1182_1540);
	       }
	       {
		  obj_t vector_1544;
		  vector_1544 = _classes__134___object;
		  arg1686_1300 = VECTOR_REF(vector_1544, arg1180_1538);
	       }
	    }
	 }
	 method1677_1301 = arg1685_1299;
	 class1682_1302 = arg1686_1300;
	 {
	    if (INTEGERP(method1677_1301))
	      {
		 switch ((long) CINT(method1677_1301))
		   {
		   case ((long) 0):
		      return BUNSPEC;
		      break;
		   case ((long) 1):
		      return BUNSPEC;
		      break;
		   case ((long) 2):
		      return BUNSPEC;
		      break;
		   case ((long) 3):
		      {
			 obj_t arg1692_1318;
			 {
			    obj_t aux_1706;
			    {
			       closure_t aux_1707;
			       aux_1707 = (closure_t) (node_1);
			       aux_1706 = (obj_t) (aux_1707);
			    }
			    arg1692_1318 = shape_tools_shape(aux_1706);
			 }
			 return internal_error_43_tools_error(string1781_integrate_cto, string1782_integrate_cto, arg1692_1318);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1319;
			 node_1319 = (sequence_t) (node_1);
			 {
			    obj_t l1518_1322;
			    {
			       bool_t aux_1713;
			       l1518_1322 = (((sequence_t) CREF(node_1319))->nodes);
			     lname1519_1323:
			       if (PAIRP(l1518_1322))
				 {
				    {
				       node_t aux_1716;
				       {
					  obj_t aux_1717;
					  aux_1717 = CAR(l1518_1322);
					  aux_1716 = (node_t) (aux_1717);
				       }
				       set_cto__5_integrate_cto(aux_1716, local_2);
				    }
				    {
				       obj_t l1518_1721;
				       l1518_1721 = CDR(l1518_1322);
				       l1518_1322 = l1518_1721;
				       goto lname1519_1323;
				    }
				 }
			       else
				 {
				    aux_1713 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1713);
			    }
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1328;
			 node_1328 = (app_t) (node_1);
			 {
			    variable_t fun_1331;
			    {
			       var_t arg1711_1347;
			       arg1711_1347 = (((app_t) CREF(node_1328))->fun);
			       fun_1331 = (((var_t) CREF(arg1711_1347))->variable);
			    }
			    {
			       bool_t test1696_1332;
			       {
				  bool_t test1697_1333;
				  test1697_1333 = is_a__118___object((obj_t) (fun_1331), local_ast_var);
				  if (test1697_1333)
				    {
				       bool_t test_1731;
				       {
					  obj_t aux_1734;
					  obj_t aux_1732;
					  aux_1734 = (obj_t) (fun_1331);
					  aux_1732 = (obj_t) (local_2);
					  test_1731 = (aux_1732 == aux_1734);
				       }
				       if (test_1731)
					 {
					    test1696_1332 = ((bool_t) 0);
					 }
				       else
					 {
					    test1696_1332 = ((bool_t) 1);
					 }
				    }
				  else
				    {
				       test1696_1332 = ((bool_t) 0);
				    }
			       }
			       if (test1696_1332)
				 {
				    BUNSPEC;
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       bool_t test1699_1335;
			       {
				  bool_t test1704_1340;
				  test1704_1340 = is_a__118___object((obj_t) (fun_1331), local_ast_var);
				  if (test1704_1340)
				    {
				       bool_t test_1741;
				       {
					  sfun_iinfo_105_t obj_1557;
					  {
					     value_t aux_1742;
					     {
						local_t obj_1556;
						obj_1556 = (local_t) (fun_1331);
						aux_1742 = (((local_t) CREF(obj_1556))->value);
					     }
					     obj_1557 = (sfun_iinfo_105_t) (aux_1742);
					  }
					  {
					     obj_t aux_1746;
					     {
						object_t aux_1747;
						aux_1747 = (object_t) (obj_1557);
						aux_1746 = OBJECT_WIDENING(aux_1747);
					     }
					     test_1741 = (((sfun_iinfo_105_t) CREF(aux_1746))->g__219);
					  }
				       }
				       if (test_1741)
					 {
					    bool_t test_1751;
					    {
					       obj_t aux_1754;
					       obj_t aux_1752;
					       aux_1754 = (obj_t) (fun_1331);
					       aux_1752 = (obj_t) (local_2);
					       test_1751 = (aux_1752 == aux_1754);
					    }
					    if (test_1751)
					      {
						 test1699_1335 = ((bool_t) 0);
					      }
					    else
					      {
						 bool_t test_1757;
						 {
						    obj_t aux_1758;
						    {
						       obj_t aux_1759;
						       {
							  sfun_iinfo_105_t obj_1561;
							  {
							     value_t aux_1761;
							     aux_1761 = (((local_t) CREF(local_2))->value);
							     obj_1561 = (sfun_iinfo_105_t) (aux_1761);
							  }
							  {
							     obj_t aux_1764;
							     {
								object_t aux_1765;
								aux_1765 = (object_t) (obj_1561);
								aux_1764 = OBJECT_WIDENING(aux_1765);
							     }
							     aux_1759 = (((sfun_iinfo_105_t) CREF(aux_1764))->cto);
							  }
						       }
						       aux_1758 = memq___r4_pairs_and_lists_6_3((obj_t) (fun_1331), aux_1759);
						    }
						    test_1757 = CBOOL(aux_1758);
						 }
						 if (test_1757)
						   {
						      test1699_1335 = ((bool_t) 0);
						   }
						 else
						   {
						      test1699_1335 = ((bool_t) 1);
						   }
					      }
					 }
				       else
					 {
					    test1699_1335 = ((bool_t) 0);
					 }
				    }
				  else
				    {
				       test1699_1335 = ((bool_t) 0);
				    }
			       }
			       if (test1699_1335)
				 {
				    value_t arg1700_1336;
				    obj_t arg1701_1337;
				    arg1700_1336 = (((local_t) CREF(local_2))->value);
				    {
				       obj_t aux_1775;
				       obj_t aux_1773;
				       {
					  sfun_iinfo_105_t obj_1564;
					  {
					     value_t aux_1776;
					     aux_1776 = (((local_t) CREF(local_2))->value);
					     obj_1564 = (sfun_iinfo_105_t) (aux_1776);
					  }
					  {
					     obj_t aux_1779;
					     {
						object_t aux_1780;
						aux_1780 = (object_t) (obj_1564);
						aux_1779 = OBJECT_WIDENING(aux_1780);
					     }
					     aux_1775 = (((sfun_iinfo_105_t) CREF(aux_1779))->cto);
					  }
				       }
				       aux_1773 = (obj_t) (fun_1331);
				       arg1701_1337 = MAKE_PAIR(aux_1773, aux_1775);
				    }
				    {
				       sfun_iinfo_105_t obj_1567;
				       obj_1567 = (sfun_iinfo_105_t) (arg1700_1336);
				       {
					  obj_t aux_1786;
					  {
					     object_t aux_1787;
					     aux_1787 = (object_t) (obj_1567);
					     aux_1786 = OBJECT_WIDENING(aux_1787);
					  }
					  ((((sfun_iinfo_105_t) CREF(aux_1786))->cto) = ((obj_t) arg1701_1337), BUNSPEC);
				       }
				    }
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			 }
			 {
			    obj_t asts_1348;
			    asts_1348 = (((app_t) CREF(node_1328))->args);
			  liip_1349:
			    if (NULLP(asts_1348))
			      {
				 return BUNSPEC;
			      }
			    else
			      {
				 {
				    node_t aux_1793;
				    {
				       obj_t aux_1794;
				       aux_1794 = CAR(asts_1348);
				       aux_1793 = (node_t) (aux_1794);
				    }
				    set_cto__5_integrate_cto(aux_1793, local_2);
				 }
				 {
				    obj_t asts_1798;
				    asts_1798 = CDR(asts_1348);
				    asts_1348 = asts_1798;
				    goto liip_1349;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1354;
			 node_1354 = (app_ly_162_t) (node_1);
			 set_cto__5_integrate_cto((((app_ly_162_t) CREF(node_1354))->fun), local_2);
			 {
			    node_t node_1804;
			    node_1804 = (((app_ly_162_t) CREF(node_1354))->arg);
			    node_1 = node_1804;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1359;
			 node_1359 = (funcall_t) (node_1);
			 {
			    obj_t asts_1362;
			    asts_1362 = (((funcall_t) CREF(node_1359))->args);
			  liip_1363:
			    if (NULLP(asts_1362))
			      {
				 node_t node_1809;
				 node_1809 = (((funcall_t) CREF(node_1359))->fun);
				 node_1 = node_1809;
				 goto set_cto__5_integrate_cto;
			      }
			    else
			      {
				 {
				    node_t aux_1811;
				    {
				       obj_t aux_1812;
				       aux_1812 = CAR(asts_1362);
				       aux_1811 = (node_t) (aux_1812);
				    }
				    set_cto__5_integrate_cto(aux_1811, local_2);
				 }
				 {
				    obj_t asts_1816;
				    asts_1816 = CDR(asts_1362);
				    asts_1362 = asts_1816;
				    goto liip_1363;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1369;
			 node_1369 = (pragma_t) (node_1);
			 {
			    obj_t l1524_1372;
			    {
			       bool_t aux_1820;
			       l1524_1372 = (((pragma_t) CREF(node_1369))->args);
			     lname1525_1373:
			       if (PAIRP(l1524_1372))
				 {
				    {
				       node_t aux_1823;
				       {
					  obj_t aux_1824;
					  aux_1824 = CAR(l1524_1372);
					  aux_1823 = (node_t) (aux_1824);
				       }
				       set_cto__5_integrate_cto(aux_1823, local_2);
				    }
				    {
				       obj_t l1524_1828;
				       l1524_1828 = CDR(l1524_1372);
				       l1524_1372 = l1524_1828;
				       goto lname1525_1373;
				    }
				 }
			       else
				 {
				    aux_1820 = ((bool_t) 1);
				 }
			       return BBOOL(aux_1820);
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1378;
			 node_1378 = (cast_t) (node_1);
			 {
			    node_t node_1833;
			    node_1833 = (((cast_t) CREF(node_1378))->arg);
			    node_1 = node_1833;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1382;
			 node_1382 = (setq_t) (node_1);
			 {
			    node_t aux_1836;
			    {
			       var_t aux_1837;
			       aux_1837 = (((setq_t) CREF(node_1382))->var);
			       aux_1836 = (node_t) (aux_1837);
			    }
			    set_cto__5_integrate_cto(aux_1836, local_2);
			 }
			 {
			    node_t node_1841;
			    node_1841 = (((setq_t) CREF(node_1382))->value);
			    node_1 = node_1841;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1387;
			 node_1387 = (conditional_t) (node_1);
			 set_cto__5_integrate_cto((((conditional_t) CREF(node_1387))->test), local_2);
			 set_cto__5_integrate_cto((((conditional_t) CREF(node_1387))->true), local_2);
			 {
			    node_t node_1848;
			    node_1848 = (((conditional_t) CREF(node_1387))->false);
			    node_1 = node_1848;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1393;
			 node_1393 = (fail_t) (node_1);
			 set_cto__5_integrate_cto((((fail_t) CREF(node_1393))->proc), local_2);
			 set_cto__5_integrate_cto((((fail_t) CREF(node_1393))->msg), local_2);
			 {
			    node_t node_1855;
			    node_1855 = (((fail_t) CREF(node_1393))->obj);
			    node_1 = node_1855;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1399;
			 node_1399 = (select_t) (node_1);
			 {
			    obj_t clauses_1402;
			    clauses_1402 = (((select_t) CREF(node_1399))->clauses);
			  liip_1403:
			    if (NULLP(clauses_1402))
			      {
				 node_t node_1860;
				 node_1860 = (((select_t) CREF(node_1399))->test);
				 node_1 = node_1860;
				 goto set_cto__5_integrate_cto;
			      }
			    else
			      {
				 {
				    node_t aux_1862;
				    {
				       obj_t aux_1863;
				       {
					  obj_t aux_1864;
					  aux_1864 = CAR(clauses_1402);
					  aux_1863 = CDR(aux_1864);
				       }
				       aux_1862 = (node_t) (aux_1863);
				    }
				    set_cto__5_integrate_cto(aux_1862, local_2);
				 }
				 {
				    obj_t clauses_1869;
				    clauses_1869 = CDR(clauses_1402);
				    clauses_1402 = clauses_1869;
				    goto liip_1403;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1410;
			 node_1410 = (let_fun_218_t) (node_1);
			 {
			    obj_t locals_1413;
			    locals_1413 = (((let_fun_218_t) CREF(node_1410))->locals);
			  liip_1414:
			    if (NULLP(locals_1413))
			      {
				 node_t node_1875;
				 node_1875 = (((let_fun_218_t) CREF(node_1410))->body);
				 node_1 = node_1875;
				 goto set_cto__5_integrate_cto;
			      }
			    else
			      {
				 {
				    node_t aux_1877;
				    {
				       obj_t aux_1878;
				       {
					  sfun_t obj_1605;
					  {
					     value_t aux_1879;
					     {
						local_t obj_1603;
						{
						   obj_t aux_1880;
						   aux_1880 = CAR(locals_1413);
						   obj_1603 = (local_t) (aux_1880);
						}
						aux_1879 = (((local_t) CREF(obj_1603))->value);
					     }
					     obj_1605 = (sfun_t) (aux_1879);
					  }
					  aux_1878 = (((sfun_t) CREF(obj_1605))->body);
				       }
				       aux_1877 = (node_t) (aux_1878);
				    }
				    set_cto__5_integrate_cto(aux_1877, local_2);
				 }
				 {
				    obj_t locals_1888;
				    locals_1888 = CDR(locals_1413);
				    locals_1413 = locals_1888;
				    goto liip_1414;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1423;
			 node_1423 = (let_var_6_t) (node_1);
			 {
			    obj_t bindings_1426;
			    bindings_1426 = (((let_var_6_t) CREF(node_1423))->bindings);
			  liip_1427:
			    if (NULLP(bindings_1426))
			      {
				 node_t node_1894;
				 node_1894 = (((let_var_6_t) CREF(node_1423))->body);
				 node_1 = node_1894;
				 goto set_cto__5_integrate_cto;
			      }
			    else
			      {
				 {
				    node_t aux_1896;
				    {
				       obj_t aux_1897;
				       {
					  obj_t aux_1898;
					  aux_1898 = CAR(bindings_1426);
					  aux_1897 = CDR(aux_1898);
				       }
				       aux_1896 = (node_t) (aux_1897);
				    }
				    set_cto__5_integrate_cto(aux_1896, local_2);
				 }
				 {
				    obj_t bindings_1903;
				    bindings_1903 = CDR(bindings_1426);
				    bindings_1426 = bindings_1903;
				    goto liip_1427;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1434;
			 node_1434 = (set_ex_it_116_t) (node_1);
			 {
			    node_t node_1907;
			    node_1907 = (((set_ex_it_116_t) CREF(node_1434))->body);
			    node_1 = node_1907;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1438;
			 node_1438 = (jump_ex_it_184_t) (node_1);
			 set_cto__5_integrate_cto((((jump_ex_it_184_t) CREF(node_1438))->exit), local_2);
			 {
			    node_t node_1912;
			    node_1912 = (((jump_ex_it_184_t) CREF(node_1438))->value);
			    node_1 = node_1912;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1443;
			 node_1443 = (make_box_202_t) (node_1);
			 {
			    node_t node_1915;
			    node_1915 = (((make_box_202_t) CREF(node_1443))->value);
			    node_1 = node_1915;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_1447;
			 node_1447 = (box_set__221_t) (node_1);
			 {
			    node_t aux_1918;
			    {
			       var_t aux_1919;
			       aux_1919 = (((box_set__221_t) CREF(node_1447))->var);
			       aux_1918 = (node_t) (aux_1919);
			    }
			    set_cto__5_integrate_cto(aux_1918, local_2);
			 }
			 {
			    node_t node_1923;
			    node_1923 = (((box_set__221_t) CREF(node_1447))->value);
			    node_1 = node_1923;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 box_ref_242_t node_1452;
			 node_1452 = (box_ref_242_t) (node_1);
			 {
			    node_t node_1926;
			    {
			       var_t aux_1927;
			       aux_1927 = (((box_ref_242_t) CREF(node_1452))->var);
			       node_1926 = (node_t) (aux_1927);
			    }
			    node_1 = node_1926;
			    goto set_cto__5_integrate_cto;
			 }
		      }
		      break;
		   default:
		    case_else1683_1305:
		      if (PROCEDUREP(method1677_1301))
			{
			   return PROCEDURE_ENTRY(method1677_1301) (method1677_1301, (obj_t) (node_1), (obj_t) (local_2), BEOA);
			}
		      else
			{
			   obj_t fun1674_1295;
			   fun1674_1295 = PROCEDURE_REF(set_cto__env_185_integrate_cto, ((long) 0));
			   return PROCEDURE_ENTRY(fun1674_1295) (fun1674_1295, (obj_t) (node_1), (obj_t) (local_2), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1683_1305;
	      }
	 }
      }
   }
}


/* _set-cto!1780 */ obj_t 
_set_cto_1780_78_integrate_cto(obj_t env_1627, obj_t node_1628, obj_t local_1629)
{
   return set_cto__5_integrate_cto((node_t) (node_1628), (local_t) (local_1629));
}


/* set-cto!-default1539 */ obj_t 
set_cto__default1539_137_integrate_cto(node_t node_3, local_t local_4)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1783_integrate_cto, (obj_t) (node_3));
}


/* _set-cto!-default1539 */ obj_t 
_set_cto__default1539_81_integrate_cto(obj_t env_1630, obj_t node_1631, obj_t local_1632)
{
   return set_cto__default1539_137_integrate_cto((node_t) (node_1631), (local_t) (local_1632));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_cto()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_CTO");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_CTO");
   module_initialization_70_tools_error(((long) 0), "INTEGRATE_CTO");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_CTO");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_CTO");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_CTO");
   return module_initialization_70_integrate_info(((long) 0), "INTEGRATE_CTO");
}
