/*===========================================================================*/
/*   (Globalize/kapture.scm)                                                 */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


static obj_t method_init_76_globalize_kapture();
extern obj_t set_kaptured__104_globalize_kapture(obj_t);
extern obj_t cto_transitive_closure__123_globalize_clocto(local_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t set_one_kaptured__205_globalize_kapture(local_t, obj_t);
extern obj_t module_initialization_70_globalize_kapture(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70_globalize_free(long, char *);
extern obj_t module_initialization_70_globalize_clocto(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t union_3_globalize_kapture(obj_t);
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_globalize_kapture();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_globalize_kapture();
static long _union_round__11_globalize_kapture;
static obj_t toplevel_init_63_globalize_kapture();
extern obj_t create_vector(long);
static obj_t _set_kaptured__95_globalize_kapture(obj_t, obj_t);
extern obj_t get_free_vars_244_globalize_free(node_t, local_t);
extern obj_t local_ast_var;
static obj_t _union_globalize_kapture(obj_t, obj_t);
extern obj_t free_from_222_globalize_free(obj_t, local_t);
static obj_t require_initialization_114_globalize_kapture = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(union_env_221_globalize_kapture, _union_globalize_kapture1751, _union_globalize_kapture, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_kaptured__env_5_globalize_kapture, _set_kaptured__95_globalize_kapture1752, _set_kaptured__95_globalize_kapture, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_globalize_kapture(long checksum_1692, char *from_1693)
{
   if (CBOOL(require_initialization_114_globalize_kapture))
     {
	require_initialization_114_globalize_kapture = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_kapture();
	imported_modules_init_94_globalize_kapture();
	method_init_76_globalize_kapture();
	toplevel_init_63_globalize_kapture();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_kapture()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_KAPTURE");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_kapture()
{
   return (_union_round__11_globalize_kapture = ((long) 0),
      BUNSPEC);
}


/* set-kaptured! */ obj_t 
set_kaptured__104_globalize_kapture(obj_t local__0_1)
{
   {
      obj_t l1557_994;
      l1557_994 = local__0_1;
    lname1558_995:
      if (PAIRP(l1557_994))
	{
	   {
	      local_t aux_1705;
	      {
		 obj_t aux_1706;
		 aux_1706 = CAR(l1557_994);
		 aux_1705 = (local_t) (aux_1706);
	      }
	      cto_transitive_closure__123_globalize_clocto(aux_1705);
	   }
	   {
	      obj_t l1557_1710;
	      l1557_1710 = CDR(l1557_994);
	      l1557_994 = l1557_1710;
	      goto lname1558_995;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t l1559_999;
      {
	 bool_t aux_1712;
	 l1559_999 = local__0_1;
       lname1560_1000:
	 if (PAIRP(l1559_999))
	   {
	      {
		 obj_t local_1002;
		 local_1002 = CAR(l1559_999);
		 set_one_kaptured__205_globalize_kapture((local_t) (local_1002), local_1002);
	      }
	      {
		 obj_t l1559_1718;
		 l1559_1718 = CDR(l1559_999);
		 l1559_999 = l1559_1718;
		 goto lname1560_1000;
	      }
	   }
	 else
	   {
	      aux_1712 = ((bool_t) 1);
	   }
	 return BBOOL(aux_1712);
      }
   }
}


/* _set-kaptured! */ obj_t 
_set_kaptured__95_globalize_kapture(obj_t env_1688, obj_t local__0_1689)
{
   return set_kaptured__104_globalize_kapture(local__0_1689);
}


/* set-one-kaptured! */ obj_t 
set_one_kaptured__205_globalize_kapture(local_t local_2, obj_t locking_3)
{
   {
      value_t info_1004;
      info_1004 = (((local_t) CREF(local_2))->value);
      {
	 obj_t kaptured_1005;
	 {
	    sfun_ginfo_98_t obj_1483;
	    obj_1483 = (sfun_ginfo_98_t) (info_1004);
	    {
	       obj_t aux_1724;
	       {
		  object_t aux_1725;
		  aux_1725 = (object_t) (obj_1483);
		  aux_1724 = OBJECT_WIDENING(aux_1725);
	       }
	       kaptured_1005 = (((sfun_ginfo_98_t) CREF(aux_1724))->kaptured);
	    }
	 }
	 {
	    {
	       bool_t test_1729;
	       if (PAIRP(kaptured_1005))
		 {
		    test_1729 = ((bool_t) 1);
		 }
	       else
		 {
		    test_1729 = NULLP(kaptured_1005);
		 }
	       if (test_1729)
		 {
		    {
		       obj_t v1561_1007;
		       v1561_1007 = create_vector(((long) 3));
		       VECTOR_SET(v1561_1007, ((long) 2), kaptured_1005);
		       VECTOR_SET(v1561_1007, ((long) 1), locking_3);
		       VECTOR_SET(v1561_1007, ((long) 0), BTRUE);
		       return v1561_1007;
		    }
		 }
	       else
		 {
		    bool_t test1572_1008;
		    test1572_1008 = is_a__118___object(kaptured_1005, local_ast_var);
		    if (test1572_1008)
		      {
			 {
			    obj_t v1562_1009;
			    v1562_1009 = create_vector(((long) 3));
			    VECTOR_SET(v1562_1009, ((long) 2), BNIL);
			    VECTOR_SET(v1562_1009, ((long) 1), locking_3);
			    VECTOR_SET(v1562_1009, ((long) 0), BFALSE);
			    return v1562_1009;
			 }
		      }
		    else
		      {
			 {
			    obj_t new_body_215_1012;
			    {
			       sfun_ginfo_98_t obj_1505;
			       obj_1505 = (sfun_ginfo_98_t) (info_1004);
			       {
				  obj_t aux_1744;
				  {
				     object_t aux_1745;
				     aux_1745 = (object_t) (obj_1505);
				     aux_1744 = OBJECT_WIDENING(aux_1745);
				  }
				  new_body_215_1012 = (((sfun_ginfo_98_t) CREF(aux_1744))->new_body_215);
			       }
			    }
			    {
			       sfun_ginfo_98_t obj_1506;
			       obj_t val1485_1507;
			       obj_1506 = (sfun_ginfo_98_t) (info_1004);
			       val1485_1507 = (obj_t) (local_2);
			       {
				  obj_t aux_1751;
				  {
				     object_t aux_1752;
				     aux_1752 = (object_t) (obj_1506);
				     aux_1751 = OBJECT_WIDENING(aux_1752);
				  }
				  ((((sfun_ginfo_98_t) CREF(aux_1751))->kaptured) = ((obj_t) val1485_1507), BUNSPEC);
			       }
			    }
			    {
			       obj_t kaptured_1013;
			       obj_t cto_1014;
			       bool_t setter__165_1015;
			       kaptured_1013 = BNIL;
			       {
				  obj_t aux_1856;
				  obj_t aux_1849;
				  {
				     sfun_ginfo_98_t obj_1509;
				     obj_1509 = (sfun_ginfo_98_t) (info_1004);
				     {
					obj_t aux_1858;
					{
					   object_t aux_1859;
					   aux_1859 = (object_t) (obj_1509);
					   aux_1858 = OBJECT_WIDENING(aux_1859);
					}
					aux_1856 = (((sfun_ginfo_98_t) CREF(aux_1858))->cfunction);
				     }
				  }
				  {
				     sfun_ginfo_98_t obj_1508;
				     obj_1508 = (sfun_ginfo_98_t) (info_1004);
				     {
					obj_t aux_1851;
					{
					   object_t aux_1852;
					   aux_1852 = (object_t) (obj_1508);
					   aux_1851 = OBJECT_WIDENING(aux_1852);
					}
					aux_1849 = (((sfun_ginfo_98_t) CREF(aux_1851))->cto__14);
				     }
				  }
				  cto_1014 = append_2_18___r4_pairs_and_lists_6_3(aux_1849, aux_1856);
			       }
			       setter__165_1015 = ((bool_t) 1);
			     loop_1016:
			       if (NULLP(cto_1014))
				 {
				    {
				       obj_t free_1022;
				       free_1022 = get_free_vars_244_globalize_free((node_t) (new_body_215_1012), local_2);
				       {
					  obj_t fkaptured_1023;
					  fkaptured_1023 = free_from_222_globalize_free(kaptured_1013, local_2);
					  {
					     obj_t kaptured_1024;
					     {
						obj_t arg1587_1032;
						arg1587_1032 = MAKE_PAIR(free_1022, fkaptured_1023);
						kaptured_1024 = union_3_globalize_kapture(arg1587_1032);
					     }
					     {
						if (setter__165_1015)
						  {
						     {
							sfun_ginfo_98_t obj_1513;
							obj_1513 = (sfun_ginfo_98_t) (info_1004);
							{
							   obj_t aux_1765;
							   {
							      object_t aux_1766;
							      aux_1766 = (object_t) (obj_1513);
							      aux_1765 = OBJECT_WIDENING(aux_1766);
							   }
							   ((((sfun_ginfo_98_t) CREF(aux_1765))->kaptured) = ((obj_t) kaptured_1024), BUNSPEC);
							}
						     }
						     {
							obj_t l1563_1025;
							{
							   bool_t aux_1770;
							   l1563_1025 = kaptured_1024;
							 lname1564_1026:
							   if (PAIRP(l1563_1025))
							     {
								{
								   svar_ginfo_131_t obj_1518;
								   {
								      value_t aux_1773;
								      {
									 local_t obj_1517;
									 {
									    obj_t aux_1774;
									    aux_1774 = CAR(l1563_1025);
									    obj_1517 = (local_t) (aux_1774);
									 }
									 aux_1773 = (((local_t) CREF(obj_1517))->value);
								      }
								      obj_1518 = (svar_ginfo_131_t) (aux_1773);
								   }
								   {
								      obj_t aux_1779;
								      {
									 object_t aux_1780;
									 aux_1780 = (object_t) (obj_1518);
									 aux_1779 = OBJECT_WIDENING(aux_1780);
								      }
								      ((((svar_ginfo_131_t) CREF(aux_1779))->kaptured__204) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								   }
								}
								{
								   obj_t l1563_1784;
								   l1563_1784 = CDR(l1563_1025);
								   l1563_1025 = l1563_1784;
								   goto lname1564_1026;
								}
							     }
							   else
							     {
								aux_1770 = ((bool_t) 1);
							     }
							   BBOOL(aux_1770);
							}
						     }
						  }
						else
						  {
						     sfun_ginfo_98_t obj_1521;
						     obj_t val1485_1522;
						     obj_1521 = (sfun_ginfo_98_t) (info_1004);
						     val1485_1522 = BFALSE;
						     {
							obj_t aux_1788;
							{
							   object_t aux_1789;
							   aux_1789 = (object_t) (obj_1521);
							   aux_1788 = OBJECT_WIDENING(aux_1789);
							}
							((((sfun_ginfo_98_t) CREF(aux_1788))->kaptured) = ((obj_t) val1485_1522), BUNSPEC);
						     }
						  }
						{
						   obj_t v1565_1031;
						   v1565_1031 = create_vector(((long) 3));
						   VECTOR_SET(v1565_1031, ((long) 2), kaptured_1024);
						   VECTOR_SET(v1565_1031, ((long) 1), locking_3);
						   {
						      obj_t aux_1796;
						      aux_1796 = BBOOL(setter__165_1015);
						      VECTOR_SET(v1565_1031, ((long) 0), aux_1796);
						   }
						   return v1565_1031;
						}
					     }
					  }
				       }
				    }
				 }
			       else
				 {
				    bool_t test_1799;
				    {
				       obj_t aux_1802;
				       obj_t aux_1800;
				       aux_1802 = (obj_t) (local_2);
				       aux_1800 = CAR(cto_1014);
				       test_1799 = (aux_1800 == aux_1802);
				    }
				    if (test_1799)
				      {
					 {
					    obj_t cto_1805;
					    cto_1805 = CDR(cto_1014);
					    cto_1014 = cto_1805;
					    goto loop_1016;
					 }
				      }
				    else
				      {
					 bool_t test_1807;
					 {
					    sfun_ginfo_98_t obj_1538;
					    {
					       value_t aux_1808;
					       {
						  local_t obj_1537;
						  {
						     obj_t aux_1809;
						     aux_1809 = CAR(cto_1014);
						     obj_1537 = (local_t) (aux_1809);
						  }
						  aux_1808 = (((local_t) CREF(obj_1537))->value);
					       }
					       obj_1538 = (sfun_ginfo_98_t) (aux_1808);
					    }
					    {
					       obj_t aux_1814;
					       {
						  object_t aux_1815;
						  aux_1815 = (object_t) (obj_1538);
						  aux_1814 = OBJECT_WIDENING(aux_1815);
					       }
					       test_1807 = (((sfun_ginfo_98_t) CREF(aux_1814))->g__219);
					    }
					 }
					 if (test_1807)
					   {
					      {
						 obj_t other_kaptured_142_1036;
						 {
						    local_t aux_1819;
						    {
						       obj_t aux_1820;
						       aux_1820 = CAR(cto_1014);
						       aux_1819 = (local_t) (aux_1820);
						    }
						    other_kaptured_142_1036 = set_one_kaptured__205_globalize_kapture(aux_1819, locking_3);
						 }
						 {
						    bool_t test_1824;
						    {
						       obj_t aux_1825;
						       aux_1825 = VECTOR_REF(other_kaptured_142_1036, ((long) 0));
						       test_1824 = CBOOL(aux_1825);
						    }
						    if (test_1824)
						      {
							 obj_t arg1592_1038;
							 obj_t arg1593_1039;
							 {
							    obj_t aux_1828;
							    aux_1828 = VECTOR_REF(other_kaptured_142_1036, ((long) 2));
							    arg1592_1038 = MAKE_PAIR(aux_1828, kaptured_1013);
							 }
							 arg1593_1039 = CDR(cto_1014);
							 {
							    obj_t cto_1833;
							    obj_t kaptured_1832;
							    kaptured_1832 = arg1592_1038;
							    cto_1833 = arg1593_1039;
							    cto_1014 = cto_1833;
							    kaptured_1013 = kaptured_1832;
							    goto loop_1016;
							 }
						      }
						    else
						      {
							 obj_t arg1595_1041;
							 obj_t arg1598_1042;
							 bool_t arg1600_1043;
							 {
							    obj_t aux_1834;
							    aux_1834 = VECTOR_REF(other_kaptured_142_1036, ((long) 2));
							    arg1595_1041 = MAKE_PAIR(aux_1834, kaptured_1013);
							 }
							 arg1598_1042 = CDR(cto_1014);
							 if (setter__165_1015)
							   {
							      obj_t aux_1841;
							      obj_t aux_1839;
							      aux_1841 = (obj_t) (local_2);
							      aux_1839 = VECTOR_REF(other_kaptured_142_1036, ((long) 1));
							      arg1600_1043 = (aux_1839 == aux_1841);
							   }
							 else
							   {
							      arg1600_1043 = ((bool_t) 0);
							   }
							 {
							    bool_t setter__165_1846;
							    obj_t cto_1845;
							    obj_t kaptured_1844;
							    kaptured_1844 = arg1595_1041;
							    cto_1845 = arg1598_1042;
							    setter__165_1846 = arg1600_1043;
							    setter__165_1015 = setter__165_1846;
							    cto_1014 = cto_1845;
							    kaptured_1013 = kaptured_1844;
							    goto loop_1016;
							 }
						      }
						 }
					      }
					   }
					 else
					   {
					      {
						 obj_t cto_1847;
						 cto_1847 = CDR(cto_1014);
						 cto_1014 = cto_1847;
						 goto loop_1016;
					      }
					   }
				      }
				 }
			    }
			 }
		      }
		 }
	    }
	 }
      }
   }
}


/* union */ obj_t 
union_3_globalize_kapture(obj_t sets_4)
{
   {
      long z2_1558;
      z2_1558 = _union_round__11_globalize_kapture;
      _union_round__11_globalize_kapture = (((long) 1) + z2_1558);
   }
   {
      obj_t sets_1053;
      obj_t union_1054;
      sets_1053 = sets_4;
      union_1054 = BNIL;
    loop_1055:
      if (NULLP(sets_1053))
	{
	   return union_1054;
	}
      else
	{
	   obj_t set_1058;
	   obj_t union_1059;
	   set_1058 = CAR(sets_1053);
	   union_1059 = union_1054;
	 liip_1060:
	   if (NULLP(set_1058))
	     {
		{
		   obj_t union_1871;
		   obj_t sets_1869;
		   sets_1869 = CDR(sets_1053);
		   union_1871 = union_1059;
		   union_1054 = union_1871;
		   sets_1053 = sets_1869;
		   goto loop_1055;
		}
	     }
	   else
	     {
		bool_t test1618_1064;
		{
		   obj_t aux_1872;
		   {
		      value_t aux_1873;
		      {
			 local_t obj_1564;
			 {
			    obj_t aux_1874;
			    aux_1874 = CAR(set_1058);
			    obj_1564 = (local_t) (aux_1874);
			 }
			 aux_1873 = (((local_t) CREF(obj_1564))->value);
		      }
		      aux_1872 = (obj_t) (aux_1873);
		   }
		   test1618_1064 = is_a__118___object(aux_1872, fun_ast_var);
		}
		if (test1618_1064)
		  {
		     {
			bool_t test1619_1065;
			{
			   obj_t obj1_1569;
			   obj_t obj2_1570;
			   {
			      long aux_1881;
			      {
				 sfun_ginfo_98_t obj_1568;
				 {
				    value_t aux_1882;
				    {
				       local_t obj_1567;
				       {
					  obj_t aux_1883;
					  aux_1883 = CAR(set_1058);
					  obj_1567 = (local_t) (aux_1883);
				       }
				       aux_1882 = (((local_t) CREF(obj_1567))->value);
				    }
				    obj_1568 = (sfun_ginfo_98_t) (aux_1882);
				 }
				 {
				    obj_t aux_1888;
				    {
				       object_t aux_1889;
				       aux_1889 = (object_t) (obj_1568);
				       aux_1888 = OBJECT_WIDENING(aux_1889);
				    }
				    aux_1881 = (((sfun_ginfo_98_t) CREF(aux_1888))->umark);
				 }
			      }
			      obj1_1569 = BINT(aux_1881);
			   }
			   obj2_1570 = BINT(_union_round__11_globalize_kapture);
			   test1619_1065 = (obj1_1569 == obj2_1570);
			}
			if (test1619_1065)
			  {
			     obj_t set_1897;
			     set_1897 = CDR(set_1058);
			     set_1058 = set_1897;
			     goto liip_1060;
			  }
			else
			  {
			     {
				sfun_ginfo_98_t obj_1574;
				long val1488_1575;
				{
				   value_t aux_1899;
				   {
				      local_t obj_1573;
				      {
					 obj_t aux_1900;
					 aux_1900 = CAR(set_1058);
					 obj_1573 = (local_t) (aux_1900);
				      }
				      aux_1899 = (((local_t) CREF(obj_1573))->value);
				   }
				   obj_1574 = (sfun_ginfo_98_t) (aux_1899);
				}
				val1488_1575 = _union_round__11_globalize_kapture;
				{
				   obj_t aux_1905;
				   {
				      object_t aux_1906;
				      aux_1906 = (object_t) (obj_1574);
				      aux_1905 = OBJECT_WIDENING(aux_1906);
				   }
				   ((((sfun_ginfo_98_t) CREF(aux_1905))->umark) = ((long) val1488_1575), BUNSPEC);
				}
			     }
			     {
				obj_t arg1623_1069;
				obj_t arg1624_1070;
				arg1623_1069 = CDR(set_1058);
				{
				   obj_t aux_1911;
				   aux_1911 = CAR(set_1058);
				   arg1624_1070 = MAKE_PAIR(aux_1911, union_1059);
				}
				{
				   obj_t union_1915;
				   obj_t set_1914;
				   set_1914 = arg1623_1069;
				   union_1915 = arg1624_1070;
				   union_1059 = union_1915;
				   set_1058 = set_1914;
				   goto liip_1060;
				}
			     }
			  }
		     }
		  }
		else
		  {
		     bool_t test1631_1075;
		     {
			obj_t obj1_1583;
			obj_t obj2_1584;
			{
			   long aux_1916;
			   {
			      svar_ginfo_131_t obj_1582;
			      {
				 value_t aux_1917;
				 {
				    local_t obj_1581;
				    {
				       obj_t aux_1918;
				       aux_1918 = CAR(set_1058);
				       obj_1581 = (local_t) (aux_1918);
				    }
				    aux_1917 = (((local_t) CREF(obj_1581))->value);
				 }
				 obj_1582 = (svar_ginfo_131_t) (aux_1917);
			      }
			      {
				 obj_t aux_1923;
				 {
				    object_t aux_1924;
				    aux_1924 = (object_t) (obj_1582);
				    aux_1923 = OBJECT_WIDENING(aux_1924);
				 }
				 aux_1916 = (((svar_ginfo_131_t) CREF(aux_1923))->mark);
			      }
			   }
			   obj1_1583 = BINT(aux_1916);
			}
			obj2_1584 = BINT(_union_round__11_globalize_kapture);
			test1631_1075 = (obj1_1583 == obj2_1584);
		     }
		     if (test1631_1075)
		       {
			  {
			     obj_t set_1932;
			     set_1932 = CDR(set_1058);
			     set_1058 = set_1932;
			     goto liip_1060;
			  }
		       }
		     else
		       {
			  {
			     svar_ginfo_131_t obj_1588;
			     long val1503_1589;
			     {
				value_t aux_1934;
				{
				   local_t obj_1587;
				   {
				      obj_t aux_1935;
				      aux_1935 = CAR(set_1058);
				      obj_1587 = (local_t) (aux_1935);
				   }
				   aux_1934 = (((local_t) CREF(obj_1587))->value);
				}
				obj_1588 = (svar_ginfo_131_t) (aux_1934);
			     }
			     val1503_1589 = _union_round__11_globalize_kapture;
			     {
				obj_t aux_1940;
				{
				   object_t aux_1941;
				   aux_1941 = (object_t) (obj_1588);
				   aux_1940 = OBJECT_WIDENING(aux_1941);
				}
				((((svar_ginfo_131_t) CREF(aux_1940))->mark) = ((long) val1503_1589), BUNSPEC);
			     }
			  }
			  {
			     obj_t arg1636_1079;
			     obj_t arg1638_1080;
			     arg1636_1079 = CDR(set_1058);
			     {
				obj_t aux_1946;
				aux_1946 = CAR(set_1058);
				arg1638_1080 = MAKE_PAIR(aux_1946, union_1059);
			     }
			     {
				obj_t union_1950;
				obj_t set_1949;
				set_1949 = arg1636_1079;
				union_1950 = arg1638_1080;
				union_1059 = union_1950;
				set_1058 = set_1949;
				goto liip_1060;
			     }
			  }
		       }
		  }
	     }
	}
   }
}


/* _union */ obj_t 
_union_globalize_kapture(obj_t env_1690, obj_t sets_1691)
{
   return union_3_globalize_kapture(sets_1691);
}


/* method-init */ obj_t 
method_init_76_globalize_kapture()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_kapture()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_tools_speek(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_tools_args(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_type_cache(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_ast_sexp(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_ast_local(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_globalize_node(((long) 0), "GLOBALIZE_KAPTURE");
   module_initialization_70_globalize_free(((long) 0), "GLOBALIZE_KAPTURE");
   return module_initialization_70_globalize_clocto(((long) 0), "GLOBALIZE_KAPTURE");
}
