/*===========================================================================*/
/*   (Integrate/free.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t internal_get_free_vars__185_integrate_free(node_t, local_t);
static obj_t method_init_76_integrate_free();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t _get_free_vars1832_199_integrate_free(obj_t, obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
static obj_t _node_free_default1547_48_integrate_free(obj_t, obj_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static long _round__57_integrate_free;
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
static obj_t node_free_158_integrate_free(node_t, obj_t);
extern obj_t pragma_ast_node;
static obj_t _integrator__235_integrate_free = BUNSPEC;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_free(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_node(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
static obj_t mark_variable__104_integrate_free(local_t);
extern obj_t sexit_iinfo_190_integrate_info;
extern obj_t svar_iinfo_76_integrate_info;
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_integrate_free();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t node_free_default1547_161_integrate_free(node_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_integrate_free();
static obj_t _node_free1834_202_integrate_free(obj_t, obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_integrate_free();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static obj_t node_free__199_integrate_free(obj_t, obj_t);
extern obj_t get_free_vars_244_integrate_free(node_t, local_t);
static obj_t free_variable__181_integrate_free(obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _free_from1833_40_integrate_free(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t free_from_222_integrate_free(obj_t, local_t);
static obj_t bind_variable__14_integrate_free(local_t, local_t);
static obj_t require_initialization_114_integrate_free = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t *__cnst;

DEFINE_STATIC_GENERIC(node_free_env_48_integrate_free, _node_free1834_202_integrate_free1840, _node_free1834_202_integrate_free, 0L, 2);
DEFINE_EXPORT_PROCEDURE(get_free_vars_env_212_integrate_free, _get_free_vars1832_199_integrate_free1841, _get_free_vars1832_199_integrate_free, 0L, 2);
DEFINE_EXPORT_PROCEDURE(free_from_env_97_integrate_free, _free_from1833_40_integrate_free1842, _free_from1833_40_integrate_free, 0L, 2);
DEFINE_STRING(string1838_integrate_free, string1838_integrate_free1843, "Unexepected `closure' node", 26);
DEFINE_STRING(string1837_integrate_free, string1837_integrate_free1844, "node-free", 9);
DEFINE_STRING(string1836_integrate_free, string1836_integrate_free1845, "Unknown variable type", 21);
DEFINE_STRING(string1835_integrate_free, string1835_integrate_free1846, "free-variable?", 14);
DEFINE_STATIC_PROCEDURE(node_free_default1547_env_53_integrate_free, _node_free_default1547_48_integrate_free1847, _node_free_default1547_48_integrate_free, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_integrate_free(long checksum_1752, char *from_1753)
{
   if (CBOOL(require_initialization_114_integrate_free))
     {
	require_initialization_114_integrate_free = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_free();
	imported_modules_init_94_integrate_free();
	method_init_76_integrate_free();
	toplevel_init_63_integrate_free();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_free()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_FREE");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_free()
{
   _round__57_integrate_free = ((long) 0);
   _integrator__235_integrate_free = BUNSPEC;
   return BUNSPEC;
}


/* mark-variable! */ obj_t 
mark_variable__104_integrate_free(local_t local_1)
{
   {
      value_t info_932;
      info_932 = (((local_t) CREF(local_1))->value);
      {
	 bool_t test1569_933;
	 test1569_933 = is_a__118___object((obj_t) (info_932), svar_iinfo_76_integrate_info);
	 if (test1569_933)
	   {
	      {
		 svar_iinfo_76_t obj_1533;
		 obj_t val1447_1534;
		 obj_1533 = (svar_iinfo_76_t) (info_932);
		 val1447_1534 = BINT(_round__57_integrate_free);
		 {
		    obj_t aux_1768;
		    {
		       object_t aux_1769;
		       aux_1769 = (object_t) (obj_1533);
		       aux_1768 = OBJECT_WIDENING(aux_1769);
		    }
		    return ((((svar_iinfo_76_t) CREF(aux_1768))->f_mark_181) = ((obj_t) val1447_1534), BUNSPEC);
		 }
	      }
	   }
	 else
	   {
	      bool_t test1570_934;
	      test1570_934 = is_a__118___object((obj_t) (info_932), sexit_iinfo_190_integrate_info);
	      if (test1570_934)
		{
		   {
		      sexit_iinfo_190_t obj_1536;
		      obj_t val1462_1537;
		      obj_1536 = (sexit_iinfo_190_t) (info_932);
		      val1462_1537 = BINT(_round__57_integrate_free);
		      {
			 obj_t aux_1778;
			 {
			    object_t aux_1779;
			    aux_1779 = (object_t) (obj_1536);
			    aux_1778 = OBJECT_WIDENING(aux_1779);
			 }
			 return ((((sexit_iinfo_190_t) CREF(aux_1778))->f_mark_181) = ((obj_t) val1462_1537), BUNSPEC);
		      }
		   }
		}
	      else
		{
		   return BFALSE;
		}
	   }
      }
   }
}


/* bind-variable! */ obj_t 
bind_variable__14_integrate_free(local_t local_2, local_t integrator_3)
{
   {
      value_t finfo_935;
      finfo_935 = (((local_t) CREF(integrator_3))->value);
      {
	 obj_t arg1572_936;
	 {
	    obj_t aux_1786;
	    obj_t aux_1784;
	    {
	       sfun_iinfo_105_t obj_1539;
	       obj_1539 = (sfun_iinfo_105_t) (finfo_935);
	       {
		  obj_t aux_1788;
		  {
		     object_t aux_1789;
		     aux_1789 = (object_t) (obj_1539);
		     aux_1788 = OBJECT_WIDENING(aux_1789);
		  }
		  aux_1786 = (((sfun_iinfo_105_t) CREF(aux_1788))->bound);
	       }
	    }
	    aux_1784 = (obj_t) (local_2);
	    arg1572_936 = MAKE_PAIR(aux_1784, aux_1786);
	 }
	 {
	    sfun_iinfo_105_t obj_1542;
	    obj_1542 = (sfun_iinfo_105_t) (finfo_935);
	    {
	       obj_t aux_1795;
	       {
		  object_t aux_1796;
		  aux_1796 = (object_t) (obj_1542);
		  aux_1795 = OBJECT_WIDENING(aux_1796);
	       }
	       ((((sfun_iinfo_105_t) CREF(aux_1795))->bound) = ((obj_t) arg1572_936), BUNSPEC);
	    }
	 }
      }
      return mark_variable__104_integrate_free(local_2);
   }
}


/* free-variable? */ obj_t 
free_variable__181_integrate_free(obj_t local_4)
{
   {
      value_t info_938;
      {
	 local_t obj_1544;
	 obj_1544 = (local_t) (local_4);
	 info_938 = (((local_t) CREF(obj_1544))->value);
      }
      {
	 bool_t test1574_939;
	 test1574_939 = is_a__118___object((obj_t) (info_938), svar_iinfo_76_integrate_info);
	 if (test1574_939)
	   {
	      {
		 bool_t test1575_940;
		 {
		    obj_t arg1578_941;
		    {
		       svar_iinfo_76_t obj_1546;
		       obj_1546 = (svar_iinfo_76_t) (info_938);
		       {
			  obj_t aux_1807;
			  {
			     object_t aux_1808;
			     aux_1808 = (object_t) (obj_1546);
			     aux_1807 = OBJECT_WIDENING(aux_1808);
			  }
			  arg1578_941 = (((svar_iinfo_76_t) CREF(aux_1807))->f_mark_181);
		       }
		    }
		    {
		       obj_t obj2_1548;
		       obj2_1548 = BINT(_round__57_integrate_free);
		       test1575_940 = (arg1578_941 == obj2_1548);
		    }
		 }
		 if (test1575_940)
		   {
		      return BFALSE;
		   }
		 else
		   {
		      return BTRUE;
		   }
	      }
	   }
	 else
	   {
	      bool_t test1579_942;
	      test1579_942 = is_a__118___object((obj_t) (info_938), sexit_iinfo_190_integrate_info);
	      if (test1579_942)
		{
		   {
		      bool_t test1580_943;
		      {
			 obj_t arg1581_944;
			 {
			    sexit_iinfo_190_t obj_1550;
			    obj_1550 = (sexit_iinfo_190_t) (info_938);
			    {
			       obj_t aux_1819;
			       {
				  object_t aux_1820;
				  aux_1820 = (object_t) (obj_1550);
				  aux_1819 = OBJECT_WIDENING(aux_1820);
			       }
			       arg1581_944 = (((sexit_iinfo_190_t) CREF(aux_1819))->f_mark_181);
			    }
			 }
			 {
			    obj_t obj2_1552;
			    obj2_1552 = BINT(_round__57_integrate_free);
			    test1580_943 = (arg1581_944 == obj2_1552);
			 }
		      }
		      if (test1580_943)
			{
			   return BFALSE;
			}
		      else
			{
			   return BTRUE;
			}
		   }
		}
	      else
		{
		   {
		      obj_t arg1584_947;
		      {
			 obj_t arg1585_948;
			 arg1585_948 = shape_tools_shape(local_4);
			 arg1584_947 = MAKE_PAIR(local_4, arg1585_948);
		      }
		      FAILURE(string1835_integrate_free, string1836_integrate_free, arg1584_947);
		   }
		}
	   }
      }
   }
}


/* get-free-vars */ obj_t 
get_free_vars_244_integrate_free(node_t node_5, local_t integrator_6)
{
   {
      obj_t free_949;
      {
	 sfun_iinfo_105_t obj_1559;
	 {
	    value_t aux_1830;
	    aux_1830 = (((local_t) CREF(integrator_6))->value);
	    obj_1559 = (sfun_iinfo_105_t) (aux_1830);
	 }
	 {
	    obj_t aux_1833;
	    {
	       object_t aux_1834;
	       aux_1834 = (object_t) (obj_1559);
	       aux_1833 = OBJECT_WIDENING(aux_1834);
	    }
	    free_949 = (((sfun_iinfo_105_t) CREF(aux_1833))->free);
	 }
      }
      {
	 bool_t test_1838;
	 if (NULLP(free_949))
	   {
	      test_1838 = ((bool_t) 1);
	   }
	 else
	   {
	      test_1838 = PAIRP(free_949);
	   }
	 if (test_1838)
	   {
	      return free_949;
	   }
	 else
	   {
	      obj_t free_951;
	      free_951 = internal_get_free_vars__185_integrate_free(node_5, integrator_6);
	      {
		 sfun_iinfo_105_t obj_1563;
		 {
		    value_t aux_1843;
		    aux_1843 = (((local_t) CREF(integrator_6))->value);
		    obj_1563 = (sfun_iinfo_105_t) (aux_1843);
		 }
		 {
		    obj_t aux_1846;
		    {
		       object_t aux_1847;
		       aux_1847 = (object_t) (obj_1563);
		       aux_1846 = OBJECT_WIDENING(aux_1847);
		    }
		    ((((sfun_iinfo_105_t) CREF(aux_1846))->free) = ((obj_t) free_951), BUNSPEC);
		 }
	      }
	      return free_951;
	   }
      }
   }
}


/* _get-free-vars1832 */ obj_t 
_get_free_vars1832_199_integrate_free(obj_t env_1740, obj_t node_1741, obj_t integrator_1742)
{
   return get_free_vars_244_integrate_free((node_t) (node_1741), (local_t) (integrator_1742));
}


/* internal-get-free-vars! */ obj_t 
internal_get_free_vars__185_integrate_free(node_t node_7, local_t integrator_8)
{
   {
      long z1_1565;
      z1_1565 = _round__57_integrate_free;
      _round__57_integrate_free = (z1_1565 + ((long) 1));
   }
   _integrator__235_integrate_free = (obj_t) (integrator_8);
   {
      obj_t l1517_955;
      {
	 sfun_t obj_1568;
	 {
	    value_t aux_1865;
	    aux_1865 = (((local_t) CREF(integrator_8))->value);
	    obj_1568 = (sfun_t) (aux_1865);
	 }
	 l1517_955 = (((sfun_t) CREF(obj_1568))->args);
      }
    lname1518_956:
      if (PAIRP(l1517_955))
	{
	   {
	      local_t aux_1858;
	      {
		 obj_t aux_1859;
		 aux_1859 = CAR(l1517_955);
		 aux_1858 = (local_t) (aux_1859);
	      }
	      bind_variable__14_integrate_free(aux_1858, integrator_8);
	   }
	   {
	      obj_t l1517_1863;
	      l1517_1863 = CDR(l1517_955);
	      l1517_955 = l1517_1863;
	      goto lname1518_956;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   return node_free_158_integrate_free(node_7, BNIL);
}


/* node-free* */ obj_t 
node_free__199_integrate_free(obj_t node__221_51, obj_t free_52)
{
   {
      obj_t node__221_963;
      obj_t free_964;
      node__221_963 = node__221_51;
      free_964 = free_52;
    loop_965:
      if (NULLP(node__221_963))
	{
	   return free_964;
	}
      else
	{
	   obj_t arg1600_967;
	   obj_t arg1602_968;
	   arg1600_967 = CDR(node__221_963);
	   {
	      node_t aux_1873;
	      {
		 obj_t aux_1874;
		 aux_1874 = CAR(node__221_963);
		 aux_1873 = (node_t) (aux_1874);
	      }
	      arg1602_968 = node_free_158_integrate_free(aux_1873, free_964);
	   }
	   {
	      obj_t free_1879;
	      obj_t node__221_1878;
	      node__221_1878 = arg1600_967;
	      free_1879 = arg1602_968;
	      free_964 = free_1879;
	      node__221_963 = node__221_1878;
	      goto loop_965;
	   }
	}
   }
}


/* free-from */ obj_t 
free_from_222_integrate_free(obj_t sets_53, local_t integrator_54)
{
   {
      long z1_1575;
      z1_1575 = _round__57_integrate_free;
      _round__57_integrate_free = (z1_1575 + ((long) 1));
   }
   {
      obj_t l1539_971;
      {
	 sfun_iinfo_105_t obj_1578;
	 {
	    value_t aux_1890;
	    aux_1890 = (((local_t) CREF(integrator_54))->value);
	    obj_1578 = (sfun_iinfo_105_t) (aux_1890);
	 }
	 {
	    obj_t aux_1893;
	    {
	       object_t aux_1894;
	       aux_1894 = (object_t) (obj_1578);
	       aux_1893 = OBJECT_WIDENING(aux_1894);
	    }
	    l1539_971 = (((sfun_iinfo_105_t) CREF(aux_1893))->bound);
	 }
      }
    lname1540_972:
      if (PAIRP(l1539_971))
	{
	   {
	      local_t aux_1883;
	      {
		 obj_t aux_1884;
		 aux_1884 = CAR(l1539_971);
		 aux_1883 = (local_t) (aux_1884);
	      }
	      mark_variable__104_integrate_free(aux_1883);
	   }
	   {
	      obj_t l1539_1888;
	      l1539_1888 = CDR(l1539_971);
	      l1539_971 = l1539_1888;
	      goto lname1540_972;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   if (NULLP(sets_53))
     {
	return BNIL;
     }
   else
     {
	obj_t head1543_979;
	head1543_979 = MAKE_PAIR(BNIL, BNIL);
	{
	   obj_t l1541_980;
	   obj_t tail1544_981;
	   l1541_980 = sets_53;
	   tail1544_981 = head1543_979;
	 lname1542_982:
	   if (NULLP(l1541_980))
	     {
		return CDR(head1543_979);
	     }
	   else
	     {
		obj_t newtail1545_984;
		{
		   obj_t arg1613_986;
		   {
		      obj_t set_989;
		      obj_t res_990;
		      set_989 = CAR(l1541_980);
		      res_990 = BNIL;
		    loop_991:
		      if (NULLP(set_989))
			{
			   arg1613_986 = res_990;
			}
		      else
			{
			   bool_t test1619_994;
			   {
			      obj_t aux_1906;
			      aux_1906 = free_variable__181_integrate_free(CAR(set_989));
			      test1619_994 = CBOOL(aux_1906);
			   }
			   if (test1619_994)
			     {
				{
				   obj_t arg1620_995;
				   obj_t arg1621_996;
				   arg1620_995 = CDR(set_989);
				   {
				      obj_t aux_1912;
				      aux_1912 = CAR(set_989);
				      arg1621_996 = MAKE_PAIR(aux_1912, res_990);
				   }
				   {
				      obj_t res_1916;
				      obj_t set_1915;
				      set_1915 = arg1620_995;
				      res_1916 = arg1621_996;
				      res_990 = res_1916;
				      set_989 = set_1915;
				      goto loop_991;
				   }
				}
			     }
			   else
			     {
				{
				   obj_t set_1917;
				   set_1917 = CDR(set_989);
				   set_989 = set_1917;
				   goto loop_991;
				}
			     }
			}
		   }
		   newtail1545_984 = MAKE_PAIR(arg1613_986, BNIL);
		}
		SET_CDR(tail1544_981, newtail1545_984);
		{
		   obj_t tail1544_1924;
		   obj_t l1541_1922;
		   l1541_1922 = CDR(l1541_980);
		   tail1544_1924 = newtail1545_984;
		   tail1544_981 = tail1544_1924;
		   l1541_980 = l1541_1922;
		   goto lname1542_982;
		}
	     }
	}
     }
}


/* _free-from1833 */ obj_t 
_free_from1833_40_integrate_free(obj_t env_1743, obj_t sets_1744, obj_t integrator_1745)
{
   return free_from_222_integrate_free(sets_1744, (local_t) (integrator_1745));
}


/* method-init */ obj_t 
method_init_76_integrate_free()
{
   add_generic__110___object(node_free_env_48_integrate_free, node_free_default1547_env_53_integrate_free);
   add_inlined_method__244___object(node_free_env_48_integrate_free, var_ast_node, ((long) 0));
   add_inlined_method__244___object(node_free_env_48_integrate_free, closure_ast_node, ((long) 1));
   add_inlined_method__244___object(node_free_env_48_integrate_free, sequence_ast_node, ((long) 2));
   add_inlined_method__244___object(node_free_env_48_integrate_free, app_ast_node, ((long) 3));
   add_inlined_method__244___object(node_free_env_48_integrate_free, app_ly_162_ast_node, ((long) 4));
   add_inlined_method__244___object(node_free_env_48_integrate_free, funcall_ast_node, ((long) 5));
   add_inlined_method__244___object(node_free_env_48_integrate_free, pragma_ast_node, ((long) 6));
   add_inlined_method__244___object(node_free_env_48_integrate_free, cast_ast_node, ((long) 7));
   add_inlined_method__244___object(node_free_env_48_integrate_free, setq_ast_node, ((long) 8));
   add_inlined_method__244___object(node_free_env_48_integrate_free, conditional_ast_node, ((long) 9));
   add_inlined_method__244___object(node_free_env_48_integrate_free, fail_ast_node, ((long) 10));
   add_inlined_method__244___object(node_free_env_48_integrate_free, select_ast_node, ((long) 11));
   add_inlined_method__244___object(node_free_env_48_integrate_free, let_fun_218_ast_node, ((long) 12));
   add_inlined_method__244___object(node_free_env_48_integrate_free, let_var_6_ast_node, ((long) 13));
   add_inlined_method__244___object(node_free_env_48_integrate_free, set_ex_it_116_ast_node, ((long) 14));
   add_inlined_method__244___object(node_free_env_48_integrate_free, jump_ex_it_184_ast_node, ((long) 15));
   add_inlined_method__244___object(node_free_env_48_integrate_free, make_box_202_ast_node, ((long) 16));
   add_inlined_method__244___object(node_free_env_48_integrate_free, box_ref_242_ast_node, ((long) 17));
   {
      long aux_1946;
      aux_1946 = add_inlined_method__244___object(node_free_env_48_integrate_free, box_set__221_ast_node, ((long) 18));
      return BINT(aux_1946);
   }
}


/* node-free */ obj_t 
node_free_158_integrate_free(node_t node_9, obj_t free_10)
{
 node_free_158_integrate_free:
   {
      obj_t method1726_1377;
      obj_t class1731_1378;
      {
	 obj_t arg1738_1375;
	 obj_t arg1739_1376;
	 {
	    object_t obj_1655;
	    obj_1655 = (object_t) (node_9);
	    {
	       obj_t pre_method_105_1656;
	       pre_method_105_1656 = PROCEDURE_REF(node_free_env_48_integrate_free, ((long) 2));
	       if (INTEGERP(pre_method_105_1656))
		 {
		    PROCEDURE_SET(node_free_env_48_integrate_free, ((long) 2), BUNSPEC);
		    arg1738_1375 = pre_method_105_1656;
		 }
	       else
		 {
		    long obj_class_num_177_1661;
		    obj_class_num_177_1661 = TYPE(obj_1655);
		    {
		       obj_t arg1177_1662;
		       arg1177_1662 = PROCEDURE_REF(node_free_env_48_integrate_free, ((long) 1));
		       {
			  long arg1178_1666;
			  {
			     long arg1179_1667;
			     arg1179_1667 = OBJECT_TYPE;
			     arg1178_1666 = (obj_class_num_177_1661 - arg1179_1667);
			  }
			  arg1738_1375 = VECTOR_REF(arg1177_1662, arg1178_1666);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1672;
	    object_1672 = (object_t) (node_9);
	    {
	       long arg1180_1673;
	       {
		  long arg1181_1674;
		  long arg1182_1675;
		  arg1181_1674 = TYPE(object_1672);
		  arg1182_1675 = OBJECT_TYPE;
		  arg1180_1673 = (arg1181_1674 - arg1182_1675);
	       }
	       {
		  obj_t vector_1679;
		  vector_1679 = _classes__134___object;
		  arg1739_1376 = VECTOR_REF(vector_1679, arg1180_1673);
	       }
	    }
	 }
	 method1726_1377 = arg1738_1375;
	 class1731_1378 = arg1739_1376;
	 {
	    if (INTEGERP(method1726_1377))
	      {
		 switch ((long) CINT(method1726_1377))
		   {
		   case ((long) 0):
		      {
			 var_t node_1384;
			 node_1384 = (var_t) (node_9);
			 {
			    bool_t test1742_1387;
			    {
			       obj_t aux_1967;
			       {
				  variable_t aux_1968;
				  aux_1968 = (((var_t) CREF(node_1384))->variable);
				  aux_1967 = (obj_t) (aux_1968);
			       }
			       test1742_1387 = is_a__118___object(aux_1967, global_ast_var);
			    }
			    if (test1742_1387)
			      {
				 return free_10;
			      }
			    else
			      {
				 bool_t test1743_1388;
				 {
				    obj_t aux_1973;
				    {
				       obj_t aux_1974;
				       {
					  variable_t aux_1975;
					  aux_1975 = (((var_t) CREF(node_1384))->variable);
					  aux_1974 = (obj_t) (aux_1975);
				       }
				       aux_1973 = free_variable__181_integrate_free(aux_1974);
				    }
				    test1743_1388 = CBOOL(aux_1973);
				 }
				 if (test1743_1388)
				   {
				      {
					 local_t aux_1981;
					 {
					    variable_t aux_1982;
					    aux_1982 = (((var_t) CREF(node_1384))->variable);
					    aux_1981 = (local_t) (aux_1982);
					 }
					 mark_variable__104_integrate_free(aux_1981);
				      }
				      {
					 obj_t aux_1986;
					 {
					    variable_t aux_1987;
					    aux_1987 = (((var_t) CREF(node_1384))->variable);
					    aux_1986 = (obj_t) (aux_1987);
					 }
					 return MAKE_PAIR(aux_1986, free_10);
				      }
				   }
				 else
				   {
				      return free_10;
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 obj_t arg1753_1397;
			 {
			    obj_t aux_1991;
			    {
			       closure_t aux_1992;
			       aux_1992 = (closure_t) (node_9);
			       aux_1991 = (obj_t) (aux_1992);
			    }
			    arg1753_1397 = shape_tools_shape(aux_1991);
			 }
			 return internal_error_43_tools_error(string1837_integrate_free, string1838_integrate_free, arg1753_1397);
		      }
		      break;
		   case ((long) 2):
		      {
			 sequence_t node_1398;
			 node_1398 = (sequence_t) (node_9);
			 return node_free__199_integrate_free((((sequence_t) CREF(node_1398))->nodes), free_10);
		      }
		      break;
		   case ((long) 3):
		      {
			 app_t node_1402;
			 node_1402 = (app_t) (node_9);
			 return node_free__199_integrate_free((((app_t) CREF(node_1402))->args), free_10);
		      }
		      break;
		   case ((long) 4):
		      {
			 app_ly_162_t node_1406;
			 node_1406 = (app_ly_162_t) (node_9);
			 {
			    node_t arg1759_1409;
			    obj_t arg1760_1410;
			    arg1759_1409 = (((app_ly_162_t) CREF(node_1406))->fun);
			    arg1760_1410 = node_free_158_integrate_free((((app_ly_162_t) CREF(node_1406))->arg), free_10);
			    {
			       obj_t free_2008;
			       node_t node_2007;
			       node_2007 = arg1759_1409;
			       free_2008 = arg1760_1410;
			       free_10 = free_2008;
			       node_9 = node_2007;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 funcall_t node_1412;
			 node_1412 = (funcall_t) (node_9);
			 {
			    node_t arg1762_1415;
			    obj_t arg1765_1416;
			    arg1762_1415 = (((funcall_t) CREF(node_1412))->fun);
			    arg1765_1416 = node_free__199_integrate_free((((funcall_t) CREF(node_1412))->args), free_10);
			    {
			       obj_t free_2014;
			       node_t node_2013;
			       node_2013 = arg1762_1415;
			       free_2014 = arg1765_1416;
			       free_10 = free_2014;
			       node_9 = node_2013;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 pragma_t node_1418;
			 node_1418 = (pragma_t) (node_9);
			 return node_free__199_integrate_free((((pragma_t) CREF(node_1418))->args), free_10);
		      }
		      break;
		   case ((long) 7):
		      {
			 cast_t node_1422;
			 node_1422 = (cast_t) (node_9);
			 {
			    node_t node_2019;
			    node_2019 = (((cast_t) CREF(node_1422))->arg);
			    node_9 = node_2019;
			    goto node_free_158_integrate_free;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 setq_t node_1426;
			 node_1426 = (setq_t) (node_9);
			 {
			    var_t arg1769_1429;
			    obj_t arg1770_1430;
			    arg1769_1429 = (((setq_t) CREF(node_1426))->var);
			    arg1770_1430 = node_free_158_integrate_free((((setq_t) CREF(node_1426))->value), free_10);
			    {
			       obj_t free_2027;
			       node_t node_2025;
			       node_2025 = (node_t) (arg1769_1429);
			       free_2027 = arg1770_1430;
			       free_10 = free_2027;
			       node_9 = node_2025;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 conditional_t node_1432;
			 node_1432 = (conditional_t) (node_9);
			 {
			    node_t arg1772_1435;
			    obj_t arg1773_1436;
			    arg1772_1435 = (((conditional_t) CREF(node_1432))->test);
			    {
			       node_t arg1774_1437;
			       obj_t arg1776_1438;
			       arg1774_1437 = (((conditional_t) CREF(node_1432))->true);
			       arg1776_1438 = node_free_158_integrate_free((((conditional_t) CREF(node_1432))->false), free_10);
			       arg1773_1436 = node_free_158_integrate_free(arg1774_1437, arg1776_1438);
			    }
			    {
			       obj_t free_2035;
			       node_t node_2034;
			       node_2034 = arg1772_1435;
			       free_2035 = arg1773_1436;
			       free_10 = free_2035;
			       node_9 = node_2034;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 fail_t node_1440;
			 node_1440 = (fail_t) (node_9);
			 {
			    node_t arg1778_1443;
			    obj_t arg1779_1444;
			    arg1778_1443 = (((fail_t) CREF(node_1440))->proc);
			    {
			       node_t arg1780_1445;
			       obj_t arg1781_1446;
			       arg1780_1445 = (((fail_t) CREF(node_1440))->msg);
			       arg1781_1446 = node_free_158_integrate_free((((fail_t) CREF(node_1440))->obj), free_10);
			       arg1779_1444 = node_free_158_integrate_free(arg1780_1445, arg1781_1446);
			    }
			    {
			       obj_t free_2043;
			       node_t node_2042;
			       node_2042 = arg1778_1443;
			       free_2043 = arg1779_1444;
			       free_10 = free_2043;
			       node_9 = node_2042;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 select_t node_1448;
			 node_1448 = (select_t) (node_9);
			 {
			    obj_t clauses_1451;
			    obj_t free_1452;
			    clauses_1451 = (((select_t) CREF(node_1448))->clauses);
			    free_1452 = free_10;
			  loop_1453:
			    if (NULLP(clauses_1451))
			      {
				 obj_t free_2049;
				 node_t node_2047;
				 node_2047 = (((select_t) CREF(node_1448))->test);
				 free_2049 = free_1452;
				 free_10 = free_2049;
				 node_9 = node_2047;
				 goto node_free_158_integrate_free;
			      }
			    else
			      {
				 obj_t arg1789_1457;
				 obj_t arg1790_1458;
				 arg1789_1457 = CDR(clauses_1451);
				 {
				    node_t aux_2051;
				    {
				       obj_t aux_2052;
				       {
					  obj_t aux_2053;
					  aux_2053 = CAR(clauses_1451);
					  aux_2052 = CDR(aux_2053);
				       }
				       aux_2051 = (node_t) (aux_2052);
				    }
				    arg1790_1458 = node_free_158_integrate_free(aux_2051, free_1452);
				 }
				 {
				    obj_t free_2059;
				    obj_t clauses_2058;
				    clauses_2058 = arg1789_1457;
				    free_2059 = arg1790_1458;
				    free_1452 = free_2059;
				    clauses_1451 = clauses_2058;
				    goto loop_1453;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 let_fun_218_t node_1461;
			 node_1461 = (let_fun_218_t) (node_9);
			 {
			    obj_t locals_1464;
			    obj_t free_1465;
			    locals_1464 = (((let_fun_218_t) CREF(node_1461))->locals);
			    free_1465 = free_10;
			  liip_1466:
			    if (NULLP(locals_1464))
			      {
				 obj_t free_2066;
				 node_t node_2064;
				 node_2064 = (((let_fun_218_t) CREF(node_1461))->body);
				 free_2066 = free_1465;
				 free_10 = free_2066;
				 node_9 = node_2064;
				 goto node_free_158_integrate_free;
			      }
			    else
			      {
				 value_t fun_1471;
				 {
				    local_t obj_1714;
				    {
				       obj_t aux_2067;
				       aux_2067 = CAR(locals_1464);
				       obj_1714 = (local_t) (aux_2067);
				    }
				    fun_1471 = (((local_t) CREF(obj_1714))->value);
				 }
				 {
				    {
				       obj_t l1531_1472;
				       {
					  sfun_t obj_1715;
					  obj_1715 = (sfun_t) (fun_1471);
					  l1531_1472 = (((sfun_t) CREF(obj_1715))->args);
				       }
				     lname1532_1473:
				       if (PAIRP(l1531_1472))
					 {
					    {
					       local_t aux_2073;
					       {
						  obj_t aux_2074;
						  aux_2074 = CAR(l1531_1472);
						  aux_2073 = (local_t) (aux_2074);
					       }
					       bind_variable__14_integrate_free(aux_2073, (local_t) (_integrator__235_integrate_free));
					    }
					    {
					       obj_t l1531_2079;
					       l1531_2079 = CDR(l1531_1472);
					       l1531_1472 = l1531_2079;
					       goto lname1532_1473;
					    }
					 }
				       else
					 {
					    ((bool_t) 1);
					 }
				    }
				    {
				       obj_t arg1800_1478;
				       obj_t arg1802_1479;
				       arg1800_1478 = CDR(locals_1464);
				       {
					  node_t aux_2084;
					  {
					     obj_t aux_2085;
					     {
						sfun_t obj_1720;
						obj_1720 = (sfun_t) (fun_1471);
						aux_2085 = (((sfun_t) CREF(obj_1720))->body);
					     }
					     aux_2084 = (node_t) (aux_2085);
					  }
					  arg1802_1479 = node_free_158_integrate_free(aux_2084, free_1465);
				       }
				       {
					  obj_t free_2091;
					  obj_t locals_2090;
					  locals_2090 = arg1800_1478;
					  free_2091 = arg1802_1479;
					  free_1465 = free_2091;
					  locals_1464 = locals_2090;
					  goto liip_1466;
				       }
				    }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 let_var_6_t node_1481;
			 node_1481 = (let_var_6_t) (node_9);
			 {
			    obj_t bindings_1484;
			    obj_t free_1485;
			    bindings_1484 = (((let_var_6_t) CREF(node_1481))->bindings);
			    free_1485 = free_10;
			  loop_1486:
			    if (NULLP(bindings_1484))
			      {
				 obj_t free_2098;
				 node_t node_2096;
				 node_2096 = (((let_var_6_t) CREF(node_1481))->body);
				 free_2098 = free_1485;
				 free_10 = free_2098;
				 node_9 = node_2096;
				 goto node_free_158_integrate_free;
			      }
			    else
			      {
				 {
				    local_t aux_2099;
				    {
				       obj_t aux_2100;
				       {
					  obj_t aux_2101;
					  aux_2101 = CAR(bindings_1484);
					  aux_2100 = CAR(aux_2101);
				       }
				       aux_2099 = (local_t) (aux_2100);
				    }
				    bind_variable__14_integrate_free(aux_2099, (local_t) (_integrator__235_integrate_free));
				 }
				 {
				    obj_t arg1809_1492;
				    obj_t arg1810_1493;
				    arg1809_1492 = CDR(bindings_1484);
				    {
				       node_t aux_2108;
				       {
					  obj_t aux_2109;
					  {
					     obj_t aux_2110;
					     aux_2110 = CAR(bindings_1484);
					     aux_2109 = CDR(aux_2110);
					  }
					  aux_2108 = (node_t) (aux_2109);
				       }
				       arg1810_1493 = node_free_158_integrate_free(aux_2108, free_1485);
				    }
				    {
				       obj_t free_2116;
				       obj_t bindings_2115;
				       bindings_2115 = arg1809_1492;
				       free_2116 = arg1810_1493;
				       free_1485 = free_2116;
				       bindings_1484 = bindings_2115;
				       goto loop_1486;
				    }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 set_ex_it_116_t node_1496;
			 node_1496 = (set_ex_it_116_t) (node_9);
			 {
			    local_t aux_2119;
			    {
			       variable_t aux_2120;
			       {
				  var_t arg1814_1500;
				  arg1814_1500 = (((set_ex_it_116_t) CREF(node_1496))->var);
				  aux_2120 = (((var_t) CREF(arg1814_1500))->variable);
			       }
			       aux_2119 = (local_t) (aux_2120);
			    }
			    bind_variable__14_integrate_free(aux_2119, (local_t) (_integrator__235_integrate_free));
			 }
			 {
			    node_t node_2126;
			    node_2126 = (((set_ex_it_116_t) CREF(node_1496))->body);
			    node_9 = node_2126;
			    goto node_free_158_integrate_free;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 jump_ex_it_184_t node_1502;
			 node_1502 = (jump_ex_it_184_t) (node_9);
			 {
			    node_t arg1816_1505;
			    obj_t arg1817_1506;
			    arg1816_1505 = (((jump_ex_it_184_t) CREF(node_1502))->exit);
			    arg1817_1506 = node_free_158_integrate_free((((jump_ex_it_184_t) CREF(node_1502))->value), free_10);
			    {
			       obj_t free_2133;
			       node_t node_2132;
			       node_2132 = arg1816_1505;
			       free_2133 = arg1817_1506;
			       free_10 = free_2133;
			       node_9 = node_2132;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 make_box_202_t node_1508;
			 node_1508 = (make_box_202_t) (node_9);
			 {
			    node_t node_2135;
			    node_2135 = (((make_box_202_t) CREF(node_1508))->value);
			    node_9 = node_2135;
			    goto node_free_158_integrate_free;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 box_ref_242_t node_1512;
			 node_1512 = (box_ref_242_t) (node_9);
			 {
			    node_t node_2138;
			    {
			       var_t aux_2139;
			       aux_2139 = (((box_ref_242_t) CREF(node_1512))->var);
			       node_2138 = (node_t) (aux_2139);
			    }
			    node_9 = node_2138;
			    goto node_free_158_integrate_free;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 box_set__221_t node_1516;
			 node_1516 = (box_set__221_t) (node_9);
			 {
			    var_t arg1822_1519;
			    obj_t arg1823_1520;
			    arg1822_1519 = (((box_set__221_t) CREF(node_1516))->var);
			    arg1823_1520 = node_free_158_integrate_free((((box_set__221_t) CREF(node_1516))->value), free_10);
			    {
			       obj_t free_2148;
			       node_t node_2146;
			       node_2146 = (node_t) (arg1822_1519);
			       free_2148 = arg1823_1520;
			       free_10 = free_2148;
			       node_9 = node_2146;
			       goto node_free_158_integrate_free;
			    }
			 }
		      }
		      break;
		   default:
		    case_else1732_1381:
		      if (PROCEDUREP(method1726_1377))
			{
			   return PROCEDURE_ENTRY(method1726_1377) (method1726_1377, (obj_t) (node_9), free_10, BEOA);
			}
		      else
			{
			   obj_t fun1725_1373;
			   fun1725_1373 = PROCEDURE_REF(node_free_env_48_integrate_free, ((long) 0));
			   return PROCEDURE_ENTRY(fun1725_1373) (fun1725_1373, (obj_t) (node_9), free_10, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1732_1381;
	      }
	 }
      }
   }
}


/* _node-free1834 */ obj_t 
_node_free1834_202_integrate_free(obj_t env_1746, obj_t node_1747, obj_t free_1748)
{
   return node_free_158_integrate_free((node_t) (node_1747), free_1748);
}


/* node-free-default1547 */ obj_t 
node_free_default1547_161_integrate_free(node_t node_11, obj_t free_12)
{
   return free_12;
}


/* _node-free-default1547 */ obj_t 
_node_free_default1547_48_integrate_free(obj_t env_1749, obj_t node_1750, obj_t free_1751)
{
   return node_free_default1547_161_integrate_free((node_t) (node_1750), free_1751);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_free()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_tools_speek(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_tools_error(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_type_cache(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_ast_local(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_ast_sexp(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_ast_glo_def_117(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_FREE");
   module_initialization_70_integrate_node(((long) 0), "INTEGRATE_FREE");
   return module_initialization_70_engine_param(((long) 0), "INTEGRATE_FREE");
}
