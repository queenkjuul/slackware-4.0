/*===========================================================================*/
/*   (Integrate/a.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static bool_t initialize_fun__49_integrate_a(variable_t, variable_t);
static obj_t method_init_76_integrate_a();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
static obj_t _node_a1886_235_integrate_a(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
static obj_t get_new_kont_177_integrate_a();
extern obj_t sfun_iinfo_105_integrate_info;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_a(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t node_a_default1542_31_integrate_a(node_t, variable_t, obj_t, obj_t);
extern obj_t sexit_iinfo_190_integrate_info;
extern obj_t svar_iinfo_76_integrate_info;
extern long class_num_218___object(obj_t);
static obj_t _a1885_integrate_a(obj_t, obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t node_a_141_integrate_a(node_t, variable_t, obj_t, obj_t);
static obj_t imported_modules_init_94_integrate_a();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_integrate_a();
extern obj_t atom_ast_node;
static obj_t _kont__191_integrate_a = BUNSPEC;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_integrate_a();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t local_ast_var;
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _node_a_default1542_255_integrate_a(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
obj_t _phi__105_integrate_a = BUNSPEC;
static obj_t require_initialization_114_integrate_a = BUNSPEC;
extern obj_t conditional_ast_node;
extern obj_t a_integrate_a(global_t, node_t);
static obj_t cnst_init_137_integrate_a();
static obj_t __cnst[2];

DEFINE_STATIC_GENERIC(node_a_env_232_integrate_a, _node_a1886_235_integrate_a1896, _node_a1886_235_integrate_a, 0L, 4);
DEFINE_EXPORT_PROCEDURE(a_env_12_integrate_a, _a1885_integrate_a1897, _a1885_integrate_a, 0L, 2);
DEFINE_STRING(string1889_integrate_a, string1889_integrate_a1898, "No method for this object", 25);
DEFINE_STRING(string1890_integrate_a, string1890_integrate_a1899, "NODE-A-DEFAULT1542 TAIL ", 24);
DEFINE_STRING(string1888_integrate_a, string1888_integrate_a1900, "Unexpected closure", 18);
DEFINE_STRING(string1887_integrate_a, string1887_integrate_a1901, "node-A", 6);
DEFINE_STATIC_PROCEDURE(node_a_default1542_env_99_integrate_a, _node_a_default1542_255_integrate_a1902, _node_a_default1542_255_integrate_a, 0L, 4);


/* module-initialization */ obj_t 
module_initialization_70_integrate_a(long checksum_1932, char *from_1933)
{
   if (CBOOL(require_initialization_114_integrate_a))
     {
	require_initialization_114_integrate_a = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_a();
	cnst_init_137_integrate_a();
	imported_modules_init_94_integrate_a();
	method_init_76_integrate_a();
	toplevel_init_63_integrate_a();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_a()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_A");
   module_initialization_70___reader(((long) 0), "INTEGRATE_A");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_A");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_a()
{
   {
      obj_t cnst_port_138_1924;
      cnst_port_138_1924 = open_input_string(string1890_integrate_a);
      {
	 long i_1925;
	 i_1925 = ((long) 1);
       loop_1926:
	 {
	    bool_t test1891_1927;
	    test1891_1927 = (i_1925 == ((long) -1));
	    if (test1891_1927)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1892_1928;
		    {
		       obj_t list1893_1929;
		       {
			  obj_t arg1894_1930;
			  arg1894_1930 = BNIL;
			  list1893_1929 = MAKE_PAIR(cnst_port_138_1924, arg1894_1930);
		       }
		       arg1892_1928 = read___reader(list1893_1929);
		    }
		    CNST_TABLE_SET(i_1925, arg1892_1928);
		 }
		 {
		    int aux_1931;
		    {
		       long aux_1951;
		       aux_1951 = (i_1925 - ((long) 1));
		       aux_1931 = (int) (aux_1951);
		    }
		    {
		       long i_1954;
		       i_1954 = (long) (aux_1931);
		       i_1925 = i_1954;
		       goto loop_1926;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_a()
{
   _phi__105_integrate_a = BUNSPEC;
   _kont__191_integrate_a = BUNSPEC;
   return BUNSPEC;
}


/* a */ obj_t 
a_integrate_a(global_t global_1, node_t node_2)
{
   {
      obj_t list1566_975;
      {
	 obj_t aux_1956;
	 aux_1956 = (obj_t) (global_1);
	 list1566_975 = MAKE_PAIR(aux_1956, BNIL);
      }
      _phi__105_integrate_a = list1566_975;
   }
   _kont__191_integrate_a = BINT(((long) 0));
   initialize_fun__49_integrate_a((variable_t) (global_1), (variable_t) (global_1));
   {
      obj_t a_977;
      a_977 = node_a_141_integrate_a(node_2, (variable_t) (global_1), CNST_TABLE_REF(((long) 0)), BNIL);
      return a_977;
   }
}


/* _a1885 */ obj_t 
_a1885_integrate_a(obj_t env_1911, obj_t global_1912, obj_t node_1913)
{
   return a_integrate_a((global_t) (global_1912), (node_t) (node_1913));
}


/* initialize-fun! */ bool_t 
initialize_fun__49_integrate_a(variable_t fun_3, variable_t owner_4)
{
   {
      sfun_iinfo_105_t obj1517_980;
      obj1517_980 = ((sfun_iinfo_105_t) ((((variable_t) CREF(fun_3))->value)));
      {
	 sfun_iinfo_105_t arg1572_981;
	 {
	    bool_t arg1586_991;
	    arg1586_991 = is_a__118___object((obj_t) (fun_3), global_ast_var);
	    {
	       sfun_iinfo_105_t res1880_1696;
	       {
		  obj_t owner_1661;
		  owner_1661 = (obj_t) (owner_4);
		  {
		     sfun_iinfo_105_t new1467_1678;
		     new1467_1678 = ((sfun_iinfo_105_t) BREF(GC_MALLOC(sizeof(struct sfun_iinfo_105))));
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->owner) = ((obj_t) owner_1661), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->free) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->bound) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->cfrom) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->cto) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->k) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->k__190) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->u) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->cn) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->ct) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->kont) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->g__219) = ((bool_t) arg1586_991), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->l) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->led) = ((obj_t) BNIL), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->istamp) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->global) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((sfun_iinfo_105_t) CREF(new1467_1678))->kaptured) = ((obj_t) BUNSPEC), BUNSPEC);
		     res1880_1696 = new1467_1678;
		  }
	       }
	       arg1572_981 = res1880_1696;
	    }
	 }
	 {
	    obj_t aux_1994;
	    object_t aux_1992;
	    aux_1994 = (obj_t) (arg1572_981);
	    aux_1992 = (object_t) (obj1517_980);
	    OBJECT_WIDENING_SET(aux_1992, aux_1994);
	 }
      }
      {
	 long arg1588_993;
	 arg1588_993 = class_num_218___object(sfun_iinfo_105_integrate_info);
	 {
	    obj_t obj_1697;
	    obj_1697 = (obj_t) (obj1517_980);
	    (((obj_t) CREF(obj_1697))->header = MAKE_HEADER(arg1588_993, 0), BUNSPEC);
	 }
      }
      obj1517_980;
   }
   {
      obj_t l1518_994;
      {
	 sfun_t obj_1700;
	 {
	    value_t aux_2022;
	    aux_2022 = (((variable_t) CREF(fun_3))->value);
	    obj_1700 = (sfun_t) (aux_2022);
	 }
	 l1518_994 = (((sfun_t) CREF(obj_1700))->args);
      }
    lname1519_995:
      if (PAIRP(l1518_994))
	{
	   {
	      obj_t x_999;
	      x_999 = CAR(l1518_994);
	      {
		 svar_iinfo_76_t obj1520_1000;
		 {
		    value_t aux_2003;
		    {
		       local_t obj_1703;
		       obj_1703 = (local_t) (x_999);
		       aux_2003 = (((local_t) CREF(obj_1703))->value);
		    }
		    obj1520_1000 = ((svar_iinfo_76_t) (aux_2003));
		 }
		 {
		    svar_iinfo_76_t arg1594_1001;
		    {
		       svar_iinfo_76_t res1881_1713;
		       {
			  svar_iinfo_76_t new1438_1708;
			  new1438_1708 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
			  ((((svar_iinfo_76_t) CREF(new1438_1708))->f_mark_181) = ((obj_t) BUNSPEC), BUNSPEC);
			  ((((svar_iinfo_76_t) CREF(new1438_1708))->u_mark_209) = ((obj_t) BUNSPEC), BUNSPEC);
			  ((((svar_iinfo_76_t) CREF(new1438_1708))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  ((((svar_iinfo_76_t) CREF(new1438_1708))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  res1881_1713 = new1438_1708;
		       }
		       arg1594_1001 = res1881_1713;
		    }
		    {
		       obj_t aux_2014;
		       object_t aux_2012;
		       aux_2014 = (obj_t) (arg1594_1001);
		       aux_2012 = (object_t) (obj1520_1000);
		       OBJECT_WIDENING_SET(aux_2012, aux_2014);
		    }
		 }
		 {
		    long arg1595_1002;
		    arg1595_1002 = class_num_218___object(svar_iinfo_76_integrate_info);
		    {
		       obj_t obj_1714;
		       obj_1714 = (obj_t) (obj1520_1000);
		       (((obj_t) CREF(obj_1714))->header = MAKE_HEADER(arg1595_1002, 0), BUNSPEC);
		    }
		 }
		 obj1520_1000;
	      }
	   }
	   {
	      obj_t l1518_2020;
	      l1518_2020 = CDR(l1518_994);
	      l1518_994 = l1518_2020;
	      goto lname1519_995;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* get-new-kont */ obj_t 
get_new_kont_177_integrate_a()
{
   {
      long z2_1718;
      z2_1718 = (long) CINT(_kont__191_integrate_a);
      {
	 long aux_2027;
	 aux_2027 = (((long) 1) + z2_1718);
	 _kont__191_integrate_a = BINT(aux_2027);
      }
   }
   return _kont__191_integrate_a;
}


/* method-init */ obj_t 
method_init_76_integrate_a()
{
   add_generic__110___object(node_a_env_232_integrate_a, node_a_default1542_env_99_integrate_a);
   add_inlined_method__244___object(node_a_env_232_integrate_a, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_a_env_232_integrate_a, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_a_env_232_integrate_a, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node_a_env_232_integrate_a, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node_a_env_232_integrate_a, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node_a_env_232_integrate_a, app_ast_node, ((long) 5));
   add_inlined_method__244___object(node_a_env_232_integrate_a, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(node_a_env_232_integrate_a, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(node_a_env_232_integrate_a, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(node_a_env_232_integrate_a, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(node_a_env_232_integrate_a, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(node_a_env_232_integrate_a, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(node_a_env_232_integrate_a, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(node_a_env_232_integrate_a, select_ast_node, ((long) 13));
   add_inlined_method__244___object(node_a_env_232_integrate_a, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(node_a_env_232_integrate_a, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(node_a_env_232_integrate_a, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(node_a_env_232_integrate_a, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(node_a_env_232_integrate_a, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(node_a_env_232_integrate_a, box_set__221_ast_node, ((long) 19));
   {
      long aux_2051;
      aux_2051 = add_inlined_method__244___object(node_a_env_232_integrate_a, box_ref_242_ast_node, ((long) 20));
      return BINT(aux_2051);
   }
}


/* node-a */ obj_t 
node_a_141_integrate_a(node_t node_6, variable_t host_7, obj_t k_8, obj_t a_9)
{
 node_a_141_integrate_a:
   {
      obj_t method1705_1381;
      obj_t class1710_1382;
      {
	 obj_t arg1713_1379;
	 obj_t arg1714_1380;
	 {
	    object_t obj_1774;
	    obj_1774 = (object_t) (node_6);
	    {
	       obj_t pre_method_105_1775;
	       pre_method_105_1775 = PROCEDURE_REF(node_a_env_232_integrate_a, ((long) 2));
	       if (INTEGERP(pre_method_105_1775))
		 {
		    PROCEDURE_SET(node_a_env_232_integrate_a, ((long) 2), BUNSPEC);
		    arg1713_1379 = pre_method_105_1775;
		 }
	       else
		 {
		    long obj_class_num_177_1780;
		    obj_class_num_177_1780 = TYPE(obj_1774);
		    {
		       obj_t arg1177_1781;
		       arg1177_1781 = PROCEDURE_REF(node_a_env_232_integrate_a, ((long) 1));
		       {
			  long arg1178_1785;
			  {
			     long arg1179_1786;
			     arg1179_1786 = OBJECT_TYPE;
			     arg1178_1785 = (obj_class_num_177_1780 - arg1179_1786);
			  }
			  arg1713_1379 = VECTOR_REF(arg1177_1781, arg1178_1785);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1791;
	    object_1791 = (object_t) (node_6);
	    {
	       long arg1180_1792;
	       {
		  long arg1181_1793;
		  long arg1182_1794;
		  arg1181_1793 = TYPE(object_1791);
		  arg1182_1794 = OBJECT_TYPE;
		  arg1180_1792 = (arg1181_1793 - arg1182_1794);
	       }
	       {
		  obj_t vector_1798;
		  vector_1798 = _classes__134___object;
		  arg1714_1380 = VECTOR_REF(vector_1798, arg1180_1792);
	       }
	    }
	 }
	 method1705_1381 = arg1713_1379;
	 class1710_1382 = arg1714_1380;
	 {
	    if (INTEGERP(method1705_1381))
	      {
		 switch ((long) CINT(method1705_1381))
		   {
		   case ((long) 0):
		      return a_9;
		      break;
		   case ((long) 1):
		      return a_9;
		      break;
		   case ((long) 2):
		      return a_9;
		      break;
		   case ((long) 3):
		      {
			 obj_t arg1720_1406;
			 {
			    obj_t aux_2071;
			    {
			       closure_t aux_2072;
			       aux_2072 = (closure_t) (node_6);
			       aux_2071 = (obj_t) (aux_2072);
			    }
			    arg1720_1406 = shape_tools_shape(aux_2071);
			 }
			 return internal_error_43_tools_error(string1887_integrate_a, string1888_integrate_a, arg1720_1406);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1407;
			 node_1407 = (sequence_t) (node_6);
			 {
			    bool_t test_2078;
			    {
			       obj_t aux_2079;
			       aux_2079 = (((sequence_t) CREF(node_1407))->nodes);
			       test_2078 = NULLP(aux_2079);
			    }
			    if (test_2078)
			      {
				 return a_9;
			      }
			    else
			      {
				 obj_t nds_1413;
				 obj_t a_1414;
				 nds_1413 = (((sequence_t) CREF(node_1407))->nodes);
				 a_1414 = a_9;
			       liip_1415:
				 {
				    bool_t test_2082;
				    {
				       obj_t aux_2083;
				       aux_2083 = CDR(nds_1413);
				       test_2082 = NULLP(aux_2083);
				    }
				    if (test_2082)
				      {
					 obj_t a_2090;
					 node_t node_2086;
					 {
					    obj_t aux_2087;
					    aux_2087 = CAR(nds_1413);
					    node_2086 = (node_t) (aux_2087);
					 }
					 a_2090 = a_1414;
					 a_9 = a_2090;
					 node_6 = node_2086;
					 goto node_a_141_integrate_a;
				      }
				    else
				      {
					 obj_t arg1725_1419;
					 obj_t arg1726_1420;
					 arg1725_1419 = CDR(nds_1413);
					 {
					    obj_t arg1727_1421;
					    obj_t arg1728_1422;
					    arg1727_1421 = CAR(nds_1413);
					    arg1728_1422 = get_new_kont_177_integrate_a();
					    arg1726_1420 = node_a_141_integrate_a((node_t) (arg1727_1421), host_7, arg1728_1422, a_1414);
					 }
					 {
					    obj_t a_2097;
					    obj_t nds_2096;
					    nds_2096 = arg1725_1419;
					    a_2097 = arg1726_1420;
					    a_1414 = a_2097;
					    nds_1413 = nds_2096;
					    goto liip_1415;
					 }
				      }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_t node_1425;
			 node_1425 = (app_t) (node_6);
			 {
			    variable_t callee_1430;
			    {
			       var_t arg1753_1447;
			       arg1753_1447 = (((app_t) CREF(node_1425))->fun);
			       callee_1430 = (((var_t) CREF(arg1753_1447))->variable);
			    }
			    {
			       obj_t args_1431;
			       obj_t a_1432;
			       args_1431 = (((app_t) CREF(node_1425))->args);
			       a_1432 = a_9;
			     liip_1433:
			       if (NULLP(args_1431))
				 {
				    bool_t test1733_1436;
				    test1733_1436 = is_a__118___object((obj_t) (callee_1430), local_ast_var);
				    if (test1733_1436)
				      {
					 {
					    obj_t arg1738_1437;
					    {
					       obj_t list1740_1439;
					       {
						  obj_t arg1743_1440;
						  {
						     obj_t arg1744_1441;
						     arg1744_1441 = MAKE_PAIR(BNIL, BNIL);
						     arg1743_1440 = MAKE_PAIR(k_8, arg1744_1441);
						  }
						  {
						     obj_t aux_2109;
						     aux_2109 = (obj_t) (callee_1430);
						     list1740_1439 = MAKE_PAIR(aux_2109, arg1743_1440);
						  }
					       }
					       arg1738_1437 = cons__138___r4_pairs_and_lists_6_3((obj_t) (host_7), list1740_1439);
					    }
					    return MAKE_PAIR(arg1738_1437, a_1432);
					 }
				      }
				    else
				      {
					 return a_1432;
				      }
				 }
			       else
				 {
				    obj_t arg1746_1443;
				    obj_t arg1747_1444;
				    arg1746_1443 = CDR(args_1431);
				    {
				       obj_t arg1748_1445;
				       obj_t arg1749_1446;
				       arg1748_1445 = CAR(args_1431);
				       arg1749_1446 = get_new_kont_177_integrate_a();
				       arg1747_1444 = node_a_141_integrate_a((node_t) (arg1748_1445), host_7, arg1749_1446, a_1432);
				    }
				    {
				       obj_t a_2121;
				       obj_t args_2120;
				       args_2120 = arg1746_1443;
				       a_2121 = arg1747_1444;
				       a_1432 = a_2121;
				       args_1431 = args_2120;
				       goto liip_1433;
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 app_ly_162_t node_1448;
			 node_1448 = (app_ly_162_t) (node_6);
			 {
			    node_t arg1755_1453;
			    obj_t arg1758_1454;
			    obj_t arg1759_1455;
			    arg1755_1453 = (((app_ly_162_t) CREF(node_1448))->fun);
			    arg1758_1454 = get_new_kont_177_integrate_a();
			    {
			       node_t arg1760_1456;
			       obj_t arg1761_1457;
			       arg1760_1456 = (((app_ly_162_t) CREF(node_1448))->arg);
			       arg1761_1457 = get_new_kont_177_integrate_a();
			       arg1759_1455 = node_a_141_integrate_a(arg1760_1456, host_7, arg1761_1457, a_9);
			    }
			    {
			       obj_t a_2131;
			       obj_t k_2130;
			       node_t node_2129;
			       node_2129 = arg1755_1453;
			       k_2130 = arg1758_1454;
			       a_2131 = arg1759_1455;
			       a_9 = a_2131;
			       k_8 = k_2130;
			       node_6 = node_2129;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 funcall_t node_1458;
			 node_1458 = (funcall_t) (node_6);
			 {
			    node_t arg1762_1463;
			    obj_t arg1765_1464;
			    obj_t arg1766_1465;
			    arg1762_1463 = (((funcall_t) CREF(node_1458))->fun);
			    arg1765_1464 = get_new_kont_177_integrate_a();
			    {
			       obj_t args_1466;
			       obj_t a_1467;
			       args_1466 = (((funcall_t) CREF(node_1458))->args);
			       a_1467 = a_9;
			     liip_1468:
			       if (NULLP(args_1466))
				 {
				    arg1766_1465 = a_1467;
				 }
			       else
				 {
				    obj_t arg1769_1471;
				    obj_t arg1770_1472;
				    arg1769_1471 = CDR(args_1466);
				    {
				       obj_t arg1771_1473;
				       obj_t arg1772_1474;
				       arg1771_1473 = CAR(args_1466);
				       arg1772_1474 = get_new_kont_177_integrate_a();
				       arg1770_1472 = node_a_141_integrate_a((node_t) (arg1771_1473), host_7, arg1772_1474, a_1467);
				    }
				    {
				       obj_t a_2143;
				       obj_t args_2142;
				       args_2142 = arg1769_1471;
				       a_2143 = arg1770_1472;
				       a_1467 = a_2143;
				       args_1466 = args_2142;
				       goto liip_1468;
				    }
				 }
			    }
			    {
			       obj_t a_2147;
			       obj_t k_2146;
			       node_t node_2145;
			       node_2145 = arg1762_1463;
			       k_2146 = arg1765_1464;
			       a_2147 = arg1766_1465;
			       a_9 = a_2147;
			       k_8 = k_2146;
			       node_6 = node_2145;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 pragma_t node_1475;
			 node_1475 = (pragma_t) (node_6);
			 {
			    obj_t asts_1480;
			    obj_t a_1481;
			    asts_1480 = (((pragma_t) CREF(node_1475))->args);
			    a_1481 = a_9;
			  liip_1482:
			    if (NULLP(asts_1480))
			      {
				 return a_1481;
			      }
			    else
			      {
				 obj_t arg1776_1485;
				 obj_t arg1777_1486;
				 arg1776_1485 = CDR(asts_1480);
				 {
				    obj_t arg1778_1487;
				    obj_t arg1779_1488;
				    arg1778_1487 = CAR(asts_1480);
				    arg1779_1488 = get_new_kont_177_integrate_a();
				    arg1777_1486 = node_a_141_integrate_a((node_t) (arg1778_1487), host_7, arg1779_1488, a_1481);
				 }
				 {
				    obj_t a_2157;
				    obj_t asts_2156;
				    asts_2156 = arg1776_1485;
				    a_2157 = arg1777_1486;
				    a_1481 = a_2157;
				    asts_1480 = asts_2156;
				    goto liip_1482;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 cast_t node_1489;
			 node_1489 = (cast_t) (node_6);
			 {
			    node_t arg1780_1494;
			    obj_t arg1781_1495;
			    arg1780_1494 = (((cast_t) CREF(node_1489))->arg);
			    arg1781_1495 = get_new_kont_177_integrate_a();
			    {
			       obj_t k_2163;
			       node_t node_2162;
			       node_2162 = arg1780_1494;
			       k_2163 = arg1781_1495;
			       k_8 = k_2163;
			       node_6 = node_2162;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 setq_t node_1496;
			 node_1496 = (setq_t) (node_6);
			 {
			    node_t arg1783_1501;
			    obj_t arg1786_1502;
			    arg1783_1501 = (((setq_t) CREF(node_1496))->value);
			    arg1786_1502 = get_new_kont_177_integrate_a();
			    {
			       obj_t k_2168;
			       node_t node_2167;
			       node_2167 = arg1783_1501;
			       k_2168 = arg1786_1502;
			       k_8 = k_2168;
			       node_6 = node_2167;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 conditional_t node_1503;
			 node_1503 = (conditional_t) (node_6);
			 {
			    obj_t a_1508;
			    {
			       node_t arg1791_1512;
			       obj_t arg1792_1513;
			       arg1791_1512 = (((conditional_t) CREF(node_1503))->test);
			       arg1792_1513 = get_new_kont_177_integrate_a();
			       a_1508 = node_a_141_integrate_a(arg1791_1512, host_7, arg1792_1513, a_9);
			    }
			    {
			       node_t arg1788_1509;
			       obj_t arg1789_1510;
			       arg1788_1509 = (((conditional_t) CREF(node_1503))->true);
			       arg1789_1510 = node_a_141_integrate_a((((conditional_t) CREF(node_1503))->false), host_7, k_8, a_1508);
			       {
				  obj_t a_2177;
				  node_t node_2176;
				  node_2176 = arg1788_1509;
				  a_2177 = arg1789_1510;
				  a_9 = a_2177;
				  node_6 = node_2176;
				  goto node_a_141_integrate_a;
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 fail_t node_1514;
			 node_1514 = (fail_t) (node_6);
			 {
			    node_t arg1793_1519;
			    obj_t arg1794_1520;
			    obj_t arg1795_1521;
			    arg1793_1519 = (((fail_t) CREF(node_1514))->proc);
			    arg1794_1520 = get_new_kont_177_integrate_a();
			    {
			       node_t arg1796_1522;
			       obj_t arg1797_1523;
			       obj_t arg1799_1524;
			       arg1796_1522 = (((fail_t) CREF(node_1514))->msg);
			       arg1797_1523 = get_new_kont_177_integrate_a();
			       {
				  node_t arg1800_1525;
				  obj_t arg1802_1526;
				  arg1800_1525 = (((fail_t) CREF(node_1514))->obj);
				  arg1802_1526 = get_new_kont_177_integrate_a();
				  arg1799_1524 = node_a_141_integrate_a(arg1800_1525, host_7, arg1802_1526, a_9);
			       }
			       arg1795_1521 = node_a_141_integrate_a(arg1796_1522, host_7, arg1797_1523, arg1799_1524);
			    }
			    {
			       obj_t a_2189;
			       obj_t k_2188;
			       node_t node_2187;
			       node_2187 = arg1793_1519;
			       k_2188 = arg1794_1520;
			       a_2189 = arg1795_1521;
			       a_9 = a_2189;
			       k_8 = k_2188;
			       node_6 = node_2187;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 select_t node_1527;
			 node_1527 = (select_t) (node_6);
			 {
			    obj_t clauses_1532;
			    obj_t a_1533;
			    {
			       obj_t arg1803_1535;
			       obj_t arg1804_1536;
			       arg1803_1535 = (((select_t) CREF(node_1527))->clauses);
			       {
				  node_t arg1805_1537;
				  obj_t arg1806_1538;
				  arg1805_1537 = (((select_t) CREF(node_1527))->test);
				  arg1806_1538 = get_new_kont_177_integrate_a();
				  arg1804_1536 = node_a_141_integrate_a(arg1805_1537, host_7, arg1806_1538, a_9);
			       }
			       clauses_1532 = arg1803_1535;
			       a_1533 = arg1804_1536;
			     liip_1534:
			       if (NULLP(clauses_1532))
				 {
				    return a_1533;
				 }
			       else
				 {
				    obj_t arg1808_1540;
				    obj_t arg1809_1541;
				    arg1808_1540 = CDR(clauses_1532);
				    {
				       node_t aux_2198;
				       {
					  obj_t aux_2199;
					  {
					     obj_t aux_2200;
					     aux_2200 = CAR(clauses_1532);
					     aux_2199 = CDR(aux_2200);
					  }
					  aux_2198 = (node_t) (aux_2199);
				       }
				       arg1809_1541 = node_a_141_integrate_a(aux_2198, host_7, k_8, a_1533);
				    }
				    {
				       obj_t a_2206;
				       obj_t clauses_2205;
				       clauses_2205 = arg1808_1540;
				       a_2206 = arg1809_1541;
				       a_1533 = a_2206;
				       clauses_1532 = clauses_2205;
				       goto liip_1534;
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 let_fun_218_t node_1544;
			 node_1544 = (let_fun_218_t) (node_6);
			 {
			    obj_t l1532_1549;
			    l1532_1549 = (((let_fun_218_t) CREF(node_1544))->locals);
			  lname1533_1550:
			    if (PAIRP(l1532_1549))
			      {
				 {
				    obj_t f_1553;
				    f_1553 = CAR(l1532_1549);
				    initialize_fun__49_integrate_a((variable_t) (f_1553), host_7);
				    {
				       obj_t obj2_1846;
				       obj2_1846 = _phi__105_integrate_a;
				       _phi__105_integrate_a = MAKE_PAIR(f_1553, obj2_1846);
				    }
				 }
				 {
				    obj_t l1532_2214;
				    l1532_2214 = CDR(l1532_1549);
				    l1532_1549 = l1532_2214;
				    goto lname1533_1550;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t locals_1555;
			    obj_t a_1556;
			    locals_1555 = (((let_fun_218_t) CREF(node_1544))->locals);
			    a_1556 = a_9;
			  liip_1557:
			    if (NULLP(locals_1555))
			      {
				 obj_t a_2221;
				 node_t node_2219;
				 node_2219 = (((let_fun_218_t) CREF(node_1544))->body);
				 a_2221 = a_1556;
				 a_9 = a_2221;
				 node_6 = node_2219;
				 goto node_a_141_integrate_a;
			      }
			    else
			      {
				 obj_t arg1818_1561;
				 obj_t arg1820_1562;
				 arg1818_1561 = CDR(locals_1555);
				 {
				    variable_t aux_2233;
				    node_t aux_2223;
				    {
				       obj_t aux_2234;
				       aux_2234 = CAR(locals_1555);
				       aux_2233 = (variable_t) (aux_2234);
				    }
				    {
				       obj_t aux_2224;
				       {
					  sfun_t obj_1854;
					  {
					     value_t aux_2225;
					     {
						local_t obj_1853;
						{
						   obj_t aux_2226;
						   aux_2226 = CAR(locals_1555);
						   obj_1853 = (local_t) (aux_2226);
						}
						aux_2225 = (((local_t) CREF(obj_1853))->value);
					     }
					     obj_1854 = (sfun_t) (aux_2225);
					  }
					  aux_2224 = (((sfun_t) CREF(obj_1854))->body);
				       }
				       aux_2223 = (node_t) (aux_2224);
				    }
				    arg1820_1562 = node_a_141_integrate_a(aux_2223, aux_2233, CNST_TABLE_REF(((long) 0)), a_1556);
				 }
				 {
				    obj_t a_2240;
				    obj_t locals_2239;
				    locals_2239 = arg1818_1561;
				    a_2240 = arg1820_1562;
				    a_1556 = a_2240;
				    locals_1555 = locals_2239;
				    goto liip_1557;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_var_6_t node_1568;
			 node_1568 = (let_var_6_t) (node_6);
			 {
			    obj_t bindings_1573;
			    obj_t a_1574;
			    bindings_1573 = (((let_var_6_t) CREF(node_1568))->bindings);
			    a_1574 = a_9;
			  liip_1575:
			    if (NULLP(bindings_1573))
			      {
				 obj_t a_2247;
				 node_t node_2245;
				 node_2245 = (((let_var_6_t) CREF(node_1568))->body);
				 a_2247 = a_1574;
				 a_9 = a_2247;
				 node_6 = node_2245;
				 goto node_a_141_integrate_a;
			      }
			    else
			      {
				 obj_t binding_1579;
				 binding_1579 = CAR(bindings_1573);
				 {
				    obj_t var_1580;
				    var_1580 = CAR(binding_1579);
				    {
				       obj_t val_1581;
				       val_1581 = CDR(binding_1579);
				       {
					  {
					     svar_iinfo_76_t obj1535_1582;
					     {
						value_t aux_2251;
						{
						   local_t obj_1862;
						   obj_1862 = (local_t) (var_1580);
						   aux_2251 = (((local_t) CREF(obj_1862))->value);
						}
						obj1535_1582 = ((svar_iinfo_76_t) (aux_2251));
					     }
					     {
						svar_iinfo_76_t arg1830_1583;
						{
						   svar_iinfo_76_t res1882_1872;
						   {
						      svar_iinfo_76_t new1438_1867;
						      new1438_1867 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
						      ((((svar_iinfo_76_t) CREF(new1438_1867))->f_mark_181) = ((obj_t) BUNSPEC), BUNSPEC);
						      ((((svar_iinfo_76_t) CREF(new1438_1867))->u_mark_209) = ((obj_t) BUNSPEC), BUNSPEC);
						      ((((svar_iinfo_76_t) CREF(new1438_1867))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						      ((((svar_iinfo_76_t) CREF(new1438_1867))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						      res1882_1872 = new1438_1867;
						   }
						   arg1830_1583 = res1882_1872;
						}
						{
						   obj_t aux_2262;
						   object_t aux_2260;
						   aux_2262 = (obj_t) (arg1830_1583);
						   aux_2260 = (object_t) (obj1535_1582);
						   OBJECT_WIDENING_SET(aux_2260, aux_2262);
						}
					     }
					     {
						long arg1831_1584;
						arg1831_1584 = class_num_218___object(svar_iinfo_76_integrate_info);
						{
						   obj_t obj_1873;
						   obj_1873 = (obj_t) (obj1535_1582);
						   (((obj_t) CREF(obj_1873))->header = MAKE_HEADER(arg1831_1584, 0), BUNSPEC);
						}
					     }
					     obj1535_1582;
					  }
					  {
					     obj_t arg1832_1585;
					     obj_t arg1833_1586;
					     arg1832_1585 = CDR(bindings_1573);
					     {
						obj_t arg1834_1587;
						arg1834_1587 = get_new_kont_177_integrate_a();
						arg1833_1586 = node_a_141_integrate_a((node_t) (val_1581), host_7, arg1834_1587, a_1574);
					     }
					     {
						obj_t a_2273;
						obj_t bindings_2272;
						bindings_2272 = arg1832_1585;
						a_2273 = arg1833_1586;
						a_1574 = a_2273;
						bindings_1573 = bindings_2272;
						goto liip_1575;
					     }
					  }
				       }
				    }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 set_ex_it_116_t node_1588;
			 node_1588 = (set_ex_it_116_t) (node_6);
			 {
			    variable_t exit_1593;
			    {
			       var_t arg1863_1619;
			       arg1863_1619 = (((set_ex_it_116_t) CREF(node_1588))->var);
			       exit_1593 = (((var_t) CREF(arg1863_1619))->variable);
			    }
			    {
			       obj_t hdlg_1594;
			       {
				  sexit_t obj_1879;
				  {
				     value_t aux_2278;
				     {
					local_t obj_1878;
					obj_1878 = (local_t) (exit_1593);
					aux_2278 = (((local_t) CREF(obj_1878))->value);
				     }
				     obj_1879 = (sexit_t) (aux_2278);
				  }
				  hdlg_1594 = (((sexit_t) CREF(obj_1879))->handler);
			       }
			       {
				  {
				     sexit_iinfo_190_t obj1538_1595;
				     {
					value_t aux_2283;
					{
					   local_t obj_1880;
					   obj_1880 = (local_t) (exit_1593);
					   aux_2283 = (((local_t) CREF(obj_1880))->value);
					}
					obj1538_1595 = ((sexit_iinfo_190_t) (aux_2283));
				     }
				     {
					sexit_iinfo_190_t arg1835_1596;
					{
					   sexit_iinfo_190_t res1883_1890;
					   {
					      sexit_iinfo_190_t new1452_1885;
					      new1452_1885 = ((sexit_iinfo_190_t) BREF(GC_MALLOC(sizeof(struct sexit_iinfo_190))));
					      ((((sexit_iinfo_190_t) CREF(new1452_1885))->f_mark_181) = ((obj_t) BUNSPEC), BUNSPEC);
					      ((((sexit_iinfo_190_t) CREF(new1452_1885))->u_mark_209) = ((obj_t) BUNSPEC), BUNSPEC);
					      ((((sexit_iinfo_190_t) CREF(new1452_1885))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					      ((((sexit_iinfo_190_t) CREF(new1452_1885))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					      res1883_1890 = new1452_1885;
					   }
					   arg1835_1596 = res1883_1890;
					}
					{
					   obj_t aux_2294;
					   object_t aux_2292;
					   aux_2294 = (obj_t) (arg1835_1596);
					   aux_2292 = (object_t) (obj1538_1595);
					   OBJECT_WIDENING_SET(aux_2292, aux_2294);
					}
				     }
				     {
					long arg1836_1597;
					arg1836_1597 = class_num_218___object(sexit_iinfo_190_integrate_info);
					{
					   obj_t obj_1891;
					   obj_1891 = (obj_t) (obj1538_1595);
					   (((obj_t) CREF(obj_1891))->header = MAKE_HEADER(arg1836_1597, 0), BUNSPEC);
					}
				     }
				     obj1538_1595;
				  }
				  {
				     bool_t test_2300;
				     {
					sexit_t obj_1894;
					{
					   value_t aux_2301;
					   {
					      local_t obj_1893;
					      obj_1893 = (local_t) (exit_1593);
					      aux_2301 = (((local_t) CREF(obj_1893))->value);
					   }
					   obj_1894 = (sexit_t) (aux_2301);
					}
					test_2300 = (((sexit_t) CREF(obj_1894))->detached__120);
				     }
				     if (test_2300)
				       {
					  return a_9;
				       }
				     else
				       {
					  obj_t call_1_215_1599;
					  obj_t call_2_162_1600;
					  {
					     obj_t arg1847_1605;
					     arg1847_1605 = get_new_kont_177_integrate_a();
					     {
						obj_t list1849_1607;
						{
						   obj_t arg1850_1608;
						   {
						      obj_t arg1851_1609;
						      arg1851_1609 = MAKE_PAIR(BNIL, BNIL);
						      arg1850_1608 = MAKE_PAIR(arg1847_1605, arg1851_1609);
						   }
						   list1849_1607 = MAKE_PAIR(hdlg_1594, arg1850_1608);
						}
						call_1_215_1599 = cons__138___r4_pairs_and_lists_6_3(hdlg_1594, list1849_1607);
					     }
					  }
					  {
					     obj_t arg1853_1611;
					     arg1853_1611 = get_new_kont_177_integrate_a();
					     {
						obj_t list1857_1613;
						{
						   obj_t arg1858_1614;
						   {
						      obj_t arg1859_1615;
						      arg1859_1615 = MAKE_PAIR(BNIL, BNIL);
						      arg1858_1614 = MAKE_PAIR(arg1853_1611, arg1859_1615);
						   }
						   list1857_1613 = MAKE_PAIR(hdlg_1594, arg1858_1614);
						}
						call_2_162_1600 = cons__138___r4_pairs_and_lists_6_3(hdlg_1594, list1857_1613);
					     }
					  }
					  {
					     node_t arg1838_1601;
					     obj_t arg1839_1602;
					     obj_t arg1842_1603;
					     arg1838_1601 = (((set_ex_it_116_t) CREF(node_1588))->body);
					     arg1839_1602 = get_new_kont_177_integrate_a();
					     {
						obj_t arg1843_1604;
						arg1843_1604 = MAKE_PAIR(call_2_162_1600, a_9);
						arg1842_1603 = MAKE_PAIR(call_1_215_1599, arg1843_1604);
					     }
					     {
						obj_t a_2322;
						obj_t k_2321;
						node_t node_2320;
						node_2320 = arg1838_1601;
						k_2321 = arg1839_1602;
						a_2322 = arg1842_1603;
						a_9 = a_2322;
						k_8 = k_2321;
						node_6 = node_2320;
						goto node_a_141_integrate_a;
					     }
					  }
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 jump_ex_it_184_t node_1620;
			 node_1620 = (jump_ex_it_184_t) (node_6);
			 {
			    node_t arg1864_1625;
			    obj_t arg1865_1626;
			    obj_t arg1866_1627;
			    arg1864_1625 = (((jump_ex_it_184_t) CREF(node_1620))->exit);
			    arg1865_1626 = get_new_kont_177_integrate_a();
			    {
			       node_t arg1867_1628;
			       obj_t arg1868_1629;
			       arg1867_1628 = (((jump_ex_it_184_t) CREF(node_1620))->value);
			       arg1868_1629 = get_new_kont_177_integrate_a();
			       arg1866_1627 = node_a_141_integrate_a(arg1867_1628, host_7, arg1868_1629, a_9);
			    }
			    {
			       obj_t a_2331;
			       obj_t k_2330;
			       node_t node_2329;
			       node_2329 = arg1864_1625;
			       k_2330 = arg1865_1626;
			       a_2331 = arg1866_1627;
			       a_9 = a_2331;
			       k_8 = k_2330;
			       node_6 = node_2329;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 make_box_202_t node_1630;
			 node_1630 = (make_box_202_t) (node_6);
			 {
			    node_t arg1869_1635;
			    obj_t arg1870_1636;
			    arg1869_1635 = (((make_box_202_t) CREF(node_1630))->value);
			    arg1870_1636 = get_new_kont_177_integrate_a();
			    {
			       obj_t k_2336;
			       node_t node_2335;
			       node_2335 = arg1869_1635;
			       k_2336 = arg1870_1636;
			       k_8 = k_2336;
			       node_6 = node_2335;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 19):
		      {
			 box_set__221_t node_1637;
			 node_1637 = (box_set__221_t) (node_6);
			 {
			    node_t arg1871_1642;
			    obj_t arg1874_1643;
			    arg1871_1642 = (((box_set__221_t) CREF(node_1637))->value);
			    arg1874_1643 = get_new_kont_177_integrate_a();
			    {
			       obj_t k_2341;
			       node_t node_2340;
			       node_2340 = arg1871_1642;
			       k_2341 = arg1874_1643;
			       k_8 = k_2341;
			       node_6 = node_2340;
			       goto node_a_141_integrate_a;
			    }
			 }
		      }
		      break;
		   case ((long) 20):
		      return a_9;
		      break;
		   default:
		    case_else1711_1385:
		      if (PROCEDUREP(method1705_1381))
			{
			   return PROCEDURE_ENTRY(method1705_1381) (method1705_1381, (obj_t) (node_6), (obj_t) (host_7), k_8, a_9, BEOA);
			}
		      else
			{
			   obj_t fun1702_1375;
			   fun1702_1375 = PROCEDURE_REF(node_a_env_232_integrate_a, ((long) 0));
			   return PROCEDURE_ENTRY(fun1702_1375) (fun1702_1375, (obj_t) (node_6), (obj_t) (host_7), k_8, a_9, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1711_1385;
	      }
	 }
      }
   }
}


/* _node-a1886 */ obj_t 
_node_a1886_235_integrate_a(obj_t env_1914, obj_t node_1915, obj_t host_1916, obj_t k_1917, obj_t a_1918)
{
   return node_a_141_integrate_a((node_t) (node_1915), (variable_t) (host_1916), k_1917, a_1918);
}


/* node-a-default1542 */ obj_t 
node_a_default1542_31_integrate_a(node_t node_10, variable_t host_11, obj_t k_12, obj_t a_13)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1889_integrate_a, (obj_t) (node_10));
}


/* _node-a-default1542 */ obj_t 
_node_a_default1542_255_integrate_a(obj_t env_1919, obj_t node_1920, obj_t host_1921, obj_t k_1922, obj_t a_1923)
{
   return node_a_default1542_31_integrate_a((node_t) (node_1920), (variable_t) (host_1921), k_1922, a_1923);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_a()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_A");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_A");
   module_initialization_70_tools_error(((long) 0), "INTEGRATE_A");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_A");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_A");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_A");
   return module_initialization_70_integrate_info(((long) 0), "INTEGRATE_A");
}
