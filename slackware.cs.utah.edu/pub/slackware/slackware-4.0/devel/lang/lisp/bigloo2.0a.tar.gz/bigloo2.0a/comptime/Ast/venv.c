/*===========================================================================*/
/*   (Ast/venv.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_ast_env();
extern obj_t for_each_hash_105___hash(obj_t, obj_t);
static obj_t restore_value_types__default1442_162_ast_env(value_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _unbind_global__69_ast_env(obj_t, obj_t, obj_t);
extern obj_t hrtype_node__16_ast_hrtype(node_t);
extern global_t bind_global__138_ast_env(obj_t, obj_t, value_t, obj_t, obj_t);
static obj_t _set_genv__185_ast_env(obj_t, obj_t);
extern obj_t type_type_type;
extern obj_t user_warning_209_tools_error(obj_t, obj_t, obj_t);
static obj_t _initialize_genv__83_ast_env(obj_t);
extern obj_t global_ast_var;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t get_hash_29___hash(obj_t, obj_t);
extern obj_t global_bucket_position_189_ast_env(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_hrtype(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___hash(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t unbind_global__45_ast_env(obj_t, obj_t);
static obj_t _get_genv_78_ast_env(obj_t);
extern obj_t _warning__61___error;
extern obj_t initialize_genv__97_ast_env();
extern long get_hash_power_number(char *, long);
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
extern obj_t get_genv_41_ast_env();
extern long class_num_218___object(obj_t);
static obj_t _bind_global__219_ast_env(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t node_ast_node;
extern type_t find_type_26_type_env(obj_t);
static obj_t imported_modules_init_94_ast_env();
extern obj_t cfun_ast_var;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t library_modules_init_112_ast_env();
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern obj_t add_genv__67_ast_env(obj_t);
static obj_t _car1714___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_ast_env();
static obj_t _restore_value_types__78_ast_env(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _for_each_global__131_ast_env(obj_t, obj_t);
extern obj_t sfun_ast_var;
extern obj_t put_hash__129___hash(obj_t, obj_t);
static long get_hash_number_100_ast_env(obj_t);
extern obj_t local_ast_var;
extern obj_t set_genv__34_ast_env(obj_t);
static obj_t arg1553_ast_env(obj_t, obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
static obj_t arg1449_ast_env(obj_t, obj_t);
static obj_t _global_bucket_position_151_ast_env(obj_t, obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t _genv__8_ast_env = BUNSPEC;
extern obj_t _module__166_module_module;
static obj_t _restore_value_types__default1442_251_ast_env(obj_t, obj_t);
static obj_t restore_value_types__114_ast_env(value_t);
extern obj_t _classes__134___object;
static obj_t _get_hash_number_209_ast_env(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _add_genv__137_ast_env(obj_t, obj_t);
static obj_t _find_global_16_ast_env(obj_t, obj_t, obj_t);
extern obj_t _lib_mode__85_engine_param;
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_env = BUNSPEC;
static obj_t cnst_init_137_ast_env();
static obj_t __cnst[8];

extern obj_t car_env_2___r4_pairs_and_lists_6_3;
DEFINE_STATIC_PROCEDURE(get_hash_number_env_189_ast_env, _get_hash_number_209_ast_env1730, _get_hash_number_209_ast_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_bucket_position_env_214_ast_env, _global_bucket_position_151_ast_env1731, _global_bucket_position_151_ast_env, 0L, 2);
DEFINE_EXPORT_PROCEDURE(find_global_env_126_ast_env, _find_global_16_ast_env1732, va_generic_entry, _find_global_16_ast_env, -2);
DEFINE_STATIC_PROCEDURE(proc1715_ast_env, arg1449_ast_env1733, arg1449_ast_env, 0L, 1);
extern obj_t eq__env_189___r4_equivalence_6_2;
DEFINE_EXPORT_PROCEDURE(unbind_global__env_125_ast_env, _unbind_global__69_ast_env1734, _unbind_global__69_ast_env, 0L, 2);
DEFINE_EXPORT_PROCEDURE(for_each_global__env_168_ast_env, _for_each_global__131_ast_env1735, _for_each_global__131_ast_env, 0L, 1);
DEFINE_STATIC_PROCEDURE(restore_value_types__default1442_env_197_ast_env, _restore_value_types__default1442_251_ast_env1736, _restore_value_types__default1442_251_ast_env, 0L, 1);
DEFINE_STATIC_GENERIC(restore_value_types__env_16_ast_env, _restore_value_types__78_ast_env1737, _restore_value_types__78_ast_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(initialize_genv__env_247_ast_env, _initialize_genv__83_ast_env1738, _initialize_genv__83_ast_env, 0L, 0);
DEFINE_EXPORT_PROCEDURE(bind_global__env_67_ast_env, _bind_global__219_ast_env1739, _bind_global__219_ast_env, 0L, 5);
DEFINE_EXPORT_PROCEDURE(set_genv__env_70_ast_env, _set_genv__185_ast_env1740, _set_genv__185_ast_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(add_genv__env_109_ast_env, _add_genv__137_ast_env1741, _add_genv__137_ast_env, 0L, 1);
DEFINE_EXPORT_PROCEDURE(get_genv_env_66_ast_env, _get_genv_78_ast_env1742, _get_genv_78_ast_env, 0L, 0);
DEFINE_STRING(string1724_ast_env, string1724_ast_env1743, "@ NOW READ FOREIGN EQ? CAR GET-HASH-NUMBER THE-GLOBAL-ENVIRONMENT ", 66);
DEFINE_STRING(string1723_ast_env, string1723_ast_env1744, "Illegal non pair argument", 25);
DEFINE_STRING(string1722_ast_env, string1722_ast_env1745, "restore-value-types", 19);
DEFINE_STRING(string1721_ast_env, string1721_ast_env1746, "Illegal argument", 16);
DEFINE_STRING(string1719_ast_env, string1719_ast_env1747, "Can't find global", 17);
DEFINE_STRING(string1720_ast_env, string1720_ast_env1748, "restore-value-types(sfun)", 25);
DEFINE_STRING(string1718_ast_env, string1718_ast_env1749, "unbind-global!", 14);
DEFINE_STRING(string1717_ast_env, string1717_ast_env1750, "Illegal global redefinition", 27);
DEFINE_STRING(string1716_ast_env, string1716_ast_env1751, "Scheme declaration overrides foreign declaration", 48);


/* module-initialization */ obj_t 
module_initialization_70_ast_env(long checksum_1509, char *from_1510)
{
   if (CBOOL(require_initialization_114_ast_env))
     {
	require_initialization_114_ast_env = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_env();
	cnst_init_137_ast_env();
	imported_modules_init_94_ast_env();
	method_init_76_ast_env();
	toplevel_init_63_ast_env();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_env()
{
   module_initialization_70___hash(((long) 0), "AST_ENV");
   module_initialization_70___object(((long) 0), "AST_ENV");
   module_initialization_70___error(((long) 0), "AST_ENV");
   module_initialization_70___reader(((long) 0), "AST_ENV");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_ENV");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_env()
{
   {
      obj_t cnst_port_138_1501;
      cnst_port_138_1501 = open_input_string(string1724_ast_env);
      {
	 long i_1502;
	 i_1502 = ((long) 7);
       loop_1503:
	 {
	    bool_t test1725_1504;
	    test1725_1504 = (i_1502 == ((long) -1));
	    if (test1725_1504)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1726_1505;
		    {
		       obj_t list1727_1506;
		       {
			  obj_t arg1728_1507;
			  arg1728_1507 = BNIL;
			  list1727_1506 = MAKE_PAIR(cnst_port_138_1501, arg1728_1507);
		       }
		       arg1726_1505 = read___reader(list1727_1506);
		    }
		    CNST_TABLE_SET(i_1502, arg1726_1505);
		 }
		 {
		    int aux_1508;
		    {
		       long aux_1530;
		       aux_1530 = (i_1502 - ((long) 1));
		       aux_1508 = (int) (aux_1530);
		    }
		    {
		       long i_1533;
		       i_1533 = (long) (aux_1508);
		       i_1502 = i_1533;
		       goto loop_1503;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_env()
{
   _genv__8_ast_env = CNST_TABLE_REF(((long) 0));
   return BUNSPEC;
}


/* get-hash-number */ long 
get_hash_number_100_ast_env(obj_t o_1)
{
   {
      obj_t arg1446_1227;
      arg1446_1227 = SYMBOL_TO_STRING(o_1);
      {
	 char *aux_1537;
	 aux_1537 = BSTRING_TO_STRING(arg1446_1227);
	 return get_hash_power_number(aux_1537, ((long) 12));
      }
   }
}


/* _get-hash-number */ obj_t 
_get_hash_number_209_ast_env(obj_t env_1460, obj_t o_1461)
{
   {
      long aux_1540;
      aux_1540 = get_hash_number_100_ast_env(o_1461);
      return BINT(aux_1540);
   }
}


/* set-genv! */ obj_t 
set_genv__34_ast_env(obj_t genv_2)
{
   _genv__8_ast_env = genv_2;
   {
      obj_t s_1232;
      s_1232 = _genv__8_ast_env;
      STRUCT_SET(s_1232, ((long) 2), get_hash_number_env_189_ast_env);
   }
   {
      obj_t s_1234;
      s_1234 = _genv__8_ast_env;
      STRUCT_SET(s_1234, ((long) 3), car_env_2___r4_pairs_and_lists_6_3);
   }
   {
      obj_t s_1236;
      s_1236 = _genv__8_ast_env;
      return STRUCT_SET(s_1236, ((long) 5), eq__env_189___r4_equivalence_6_2);
   }
}


/* _set-genv! */ obj_t 
_set_genv__185_ast_env(obj_t env_1462, obj_t genv_1463)
{
   return set_genv__34_ast_env(genv_1463);
}


/* add-genv! */ obj_t 
add_genv__67_ast_env(obj_t genv_3)
{
   {
      obj_t arg1449_1469;
      arg1449_1469 = proc1715_ast_env;
      return for_each_hash_105___hash(arg1449_1469, genv_3);
   }
}


/* _add-genv! */ obj_t 
_add_genv__137_ast_env(obj_t env_1470, obj_t genv_1471)
{
   return add_genv__67_ast_env(genv_1471);
}


/* arg1449 */ obj_t 
arg1449_ast_env(obj_t env_1472, obj_t bucket_1473)
{
   {
      obj_t bucket_714;
      {
	 bool_t aux_1549;
	 bucket_714 = bucket_1473;
	 {
	    obj_t l1435_716;
	    l1435_716 = CDR(bucket_714);
	  lname1436_717:
	    if (PAIRP(l1435_716))
	      {
		 {
		    obj_t new_720;
		    new_720 = CAR(l1435_716);
		    {
		       obj_t id_721;
		       {
			  global_t obj_1241;
			  obj_1241 = (global_t) (new_720);
			  id_721 = (((global_t) CREF(obj_1241))->id);
		       }
		       {
			  obj_t module_722;
			  {
			     global_t obj_1242;
			     obj_1242 = (global_t) (new_720);
			     module_722 = (((global_t) CREF(obj_1242))->module);
			  }
			  {
			     type_t type_723;
			     {
				global_t obj_1243;
				obj_1243 = (global_t) (new_720);
				type_723 = (((global_t) CREF(obj_1243))->type);
			     }
			     {
				value_t value_724;
				{
				   global_t obj_1244;
				   obj_1244 = (global_t) (new_720);
				   value_724 = (((global_t) CREF(obj_1244))->value);
				}
				{
				   obj_t bucket_725;
				   bucket_725 = get_hash_29___hash(id_721, _genv__8_ast_env);
				   {
				      obj_t type_id_229_726;
				      type_id_229_726 = (((type_t) CREF(type_723))->id);
				      {
					 {
					    global_t obj_1246;
					    obj_1246 = (global_t) (new_720);
					    ((((global_t) CREF(obj_1246))->library__255) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					 }
					 {
					    type_t arg1455_727;
					    arg1455_727 = find_type_26_type_env(type_id_229_726);
					    {
					       global_t obj_1248;
					       obj_1248 = (global_t) (new_720);
					       ((((global_t) CREF(obj_1248))->type) = ((type_t) arg1455_727), BUNSPEC);
					    }
					 }
					 restore_value_types__114_ast_env(value_724);
					 if (PAIRP(bucket_725))
					   {
					      bool_t test1457_729;
					      {
						 obj_t obj2_1252;
						 obj2_1252 = _module__166_module_module;
						 test1457_729 = (module_722 == obj2_1252);
					      }
					      if (test1457_729)
						{
						   {
						      obj_t new_bucket_15_730;
						      {
							 obj_t aux_1573;
							 aux_1573 = CDR(bucket_725);
							 new_bucket_15_730 = MAKE_PAIR(new_720, aux_1573);
						      }
						      SET_CDR(bucket_725, new_bucket_15_730);
						   }
						}
					      else
						{
						   {
						      obj_t arg1460_732;
						      obj_t arg1461_733;
						      arg1460_732 = CDR(bucket_725);
						      {
							 obj_t aux_1578;
							 {
							    obj_t aux_1579;
							    aux_1579 = CDR(bucket_725);
							    aux_1578 = CDR(aux_1579);
							 }
							 arg1461_733 = MAKE_PAIR(new_720, aux_1578);
						      }
						      SET_CDR(arg1460_732, arg1461_733);
						   }
						}
					   }
					 else
					   {
					      {
						 obj_t arg1464_735;
						 {
						    obj_t list1465_736;
						    {
						       obj_t arg1466_737;
						       arg1466_737 = MAKE_PAIR(new_720, BNIL);
						       list1465_736 = MAKE_PAIR(id_721, arg1466_737);
						    }
						    arg1464_735 = list1465_736;
						 }
						 put_hash__129___hash(arg1464_735, _genv__8_ast_env);
					      }
					   }
				      }
				   }
				}
			     }
			  }
		       }
		    }
		 }
		 {
		    obj_t l1435_1587;
		    l1435_1587 = CDR(l1435_716);
		    l1435_716 = l1435_1587;
		    goto lname1436_717;
		 }
	      }
	    else
	      {
		 aux_1549 = ((bool_t) 1);
	      }
	 }
	 return BBOOL(aux_1549);
      }
   }
}


/* get-genv */ obj_t 
get_genv_41_ast_env()
{
   {
      obj_t s_1269;
      s_1269 = _genv__8_ast_env;
      {
	 obj_t aux_1591;
	 aux_1591 = CNST_TABLE_REF(((long) 1));
	 STRUCT_SET(s_1269, ((long) 2), aux_1591);
      }
   }
   {
      obj_t s_1272;
      s_1272 = _genv__8_ast_env;
      {
	 obj_t aux_1594;
	 aux_1594 = CNST_TABLE_REF(((long) 2));
	 STRUCT_SET(s_1272, ((long) 3), aux_1594);
      }
   }
   {
      obj_t s_1275;
      s_1275 = _genv__8_ast_env;
      {
	 obj_t aux_1597;
	 aux_1597 = CNST_TABLE_REF(((long) 3));
	 STRUCT_SET(s_1275, ((long) 5), aux_1597);
      }
   }
   return _genv__8_ast_env;
}


/* _get-genv */ obj_t 
_get_genv_78_ast_env(obj_t env_1474)
{
   return get_genv_41_ast_env();
}


/* initialize-genv! */ obj_t 
initialize_genv__97_ast_env()
{
   {
      obj_t list1476_747;
      {
	 obj_t aux_1601;
	 aux_1601 = BINT(((long) 1024));
	 list1476_747 = MAKE_PAIR(aux_1601, BNIL);
      }
      return (_genv__8_ast_env = make_hash_table_174___hash(((long) 4096), get_hash_number_env_189_ast_env, car_env_2___r4_pairs_and_lists_6_3, eq__env_189___r4_equivalence_6_2, list1476_747),
	 BUNSPEC);
   }
}


/* _initialize-genv! */ obj_t 
_initialize_genv__83_ast_env(obj_t env_1475)
{
   return initialize_genv__97_ast_env();
}


/* find-global */ obj_t 
find_global_223_ast_env(obj_t id_8, obj_t module_9)
{
   {
      obj_t bucket_750;
      obj_t module_751;
      bucket_750 = get_hash_29___hash(id_8, _genv__8_ast_env);
      if (NULLP(module_9))
	{
	   module_751 = BNIL;
	}
      else
	{
	   module_751 = CAR(module_9);
	}
      if (PAIRP(bucket_750))
	{
	   bool_t test_1612;
	   {
	      obj_t aux_1613;
	      aux_1613 = CDR(bucket_750);
	      test_1612 = NULLP(aux_1613);
	   }
	   if (test_1612)
	     {
		return BFALSE;
	     }
	   else
	     {
		if (NULLP(module_751))
		  {
		     {
			obj_t aux_1618;
			aux_1618 = CDR(bucket_750);
			return CAR(aux_1618);
		     }
		  }
		else
		  {
		     {
			obj_t globals_755;
			globals_755 = CDR(bucket_750);
		      loop_756:
			if (NULLP(globals_755))
			  {
			     return BFALSE;
			  }
			else
			  {
			     bool_t test_1623;
			     {
				obj_t aux_1624;
				{
				   global_t obj_1291;
				   {
				      obj_t aux_1625;
				      aux_1625 = CAR(globals_755);
				      obj_1291 = (global_t) (aux_1625);
				   }
				   aux_1624 = (((global_t) CREF(obj_1291))->module);
				}
				test_1623 = (aux_1624 == module_751);
			     }
			     if (test_1623)
			       {
				  return CAR(globals_755);
			       }
			     else
			       {
				  {
				     obj_t globals_1631;
				     globals_1631 = CDR(globals_755);
				     globals_755 = globals_1631;
				     goto loop_756;
				  }
			       }
			  }
		     }
		  }
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* _find-global */ obj_t 
_find_global_16_ast_env(obj_t env_1476, obj_t id_1477, obj_t module_1478)
{
   return find_global_223_ast_env(id_1477, module_1478);
}


/* bind-global! */ global_t 
bind_global__138_ast_env(obj_t id_10, obj_t module_11, value_t value_12, obj_t import_13, obj_t src_14)
{
   {
      obj_t global_765;
      {
	 obj_t list1527_799;
	 list1527_799 = MAKE_PAIR(module_11, BNIL);
	 global_765 = find_global_223_ast_env(id_10, list1527_799);
      }
      {
	 bool_t test_1637;
	 {
	    obj_t aux_1638;
	    aux_1638 = CNST_TABLE_REF(((long) 4));
	    test_1637 = (module_11 == aux_1638);
	 }
	 if (test_1637)
	   {
	      BUNSPEC;
	   }
	 else
	   {
	      obj_t old_foreign_244_767;
	      {
		 obj_t list1497_772;
		 {
		    obj_t aux_1641;
		    aux_1641 = CNST_TABLE_REF(((long) 4));
		    list1497_772 = MAKE_PAIR(aux_1641, BNIL);
		 }
		 old_foreign_244_767 = find_global_223_ast_env(id_10, list1497_772);
	      }
	      {
		 bool_t test1492_768;
		 test1492_768 = is_a__118___object(old_foreign_244_767, global_ast_var);
		 if (test1492_768)
		   {
		      bool_t test1493_769;
		      {
			 bool_t test1494_770;
			 {
			    bool_t res1711_1303;
			    {
			       obj_t obj_1299;
			       obj_1299 = _warning__61___error;
			       if (INTEGERP(obj_1299))
				 {
				    res1711_1303 = ((bool_t) 1);
				 }
			       else
				 {
				    res1711_1303 = REALP(obj_1299);
				 }
			    }
			    test1494_770 = res1711_1303;
			 }
			 if (test1494_770)
			   {
			      long n1_1304;
			      n1_1304 = (long) CINT(_warning__61___error);
			      test1493_769 = (n1_1304 >= ((long) 2));
			   }
			 else
			   {
			      test1493_769 = ((bool_t) 0);
			   }
		      }
		      if (test1493_769)
			{
			   user_warning_209_tools_error(id_10, string1716_ast_env, src_14);
			}
		      else
			{
			   BUNSPEC;
			}
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
      }
      {
	 bool_t test1500_775;
	 test1500_775 = is_a__118___object(global_765, global_ast_var);
	 if (test1500_775)
	   {
	      if (CBOOL(_lib_mode__85_engine_param))
		{
		   return (global_t) (global_765);
		}
	      else
		{
		   obj_t aux_1660;
		   aux_1660 = user_error_151_tools_error(id_10, string1717_ast_env, src_14, BNIL);
		   return (global_t) (aux_1660);
		}
	   }
	 else
	   {
	      global_t new_777;
	      obj_t bucket_778;
	      {
		 obj_t arg1517_792;
		 obj_t arg1518_793;
		 arg1517_792 = CNST_TABLE_REF(((long) 5));
		 arg1518_793 = CNST_TABLE_REF(((long) 6));
		 {
		    global_t res1712_1341;
		    {
		       obj_t name_1308;
		       type_t type_1309;
		       bool_t library__255_1318;
		       name_1308 = BFALSE;
		       type_1309 = (type_t) (____74_type_cache);
		       library__255_1318 = CBOOL(_lib_mode__85_engine_param);
		       {
			  global_t new1049_1322;
			  new1049_1322 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
			  {
			     long arg1657_1323;
			     arg1657_1323 = class_num_218___object(global_ast_var);
			     {
				obj_t obj_1339;
				obj_1339 = (obj_t) (new1049_1322);
				(((obj_t) CREF(obj_1339))->header = MAKE_HEADER(arg1657_1323, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_1671;
			     aux_1671 = (object_t) (new1049_1322);
			     OBJECT_WIDENING_SET(aux_1671, name_1308);
			  }
			  ((((global_t) CREF(new1049_1322))->id) = ((obj_t) id_10), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->name) = ((obj_t) name_1308), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->type) = ((type_t) type_1309), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->value) = ((value_t) value_12), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->access) = ((obj_t) arg1517_792), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->removable) = ((obj_t) arg1518_793), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->occurrence) = ((long) ((long) 0)), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->module) = ((obj_t) module_11), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->import) = ((obj_t) import_13), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->evaluable__248) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->library__255) = ((bool_t) library__255_1318), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->user__32) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->pragma) = ((obj_t) BNIL), BUNSPEC);
			  ((((global_t) CREF(new1049_1322))->src) = ((obj_t) src_14), BUNSPEC);
			  res1712_1341 = new1049_1322;
		       }
		    }
		    new_777 = res1712_1341;
		 }
	      }
	      bucket_778 = get_hash_29___hash(id_10, _genv__8_ast_env);
	      if (PAIRP(bucket_778))
		{
		   bool_t test1503_780;
		   {
		      obj_t obj2_1344;
		      obj2_1344 = _module__166_module_module;
		      test1503_780 = (module_11 == obj2_1344);
		   }
		   if (test1503_780)
		     {
			{
			   obj_t new_bucket_15_781;
			   {
			      obj_t aux_1696;
			      obj_t aux_1694;
			      aux_1696 = CDR(bucket_778);
			      aux_1694 = (obj_t) (new_777);
			      new_bucket_15_781 = MAKE_PAIR(aux_1694, aux_1696);
			   }
			   SET_CDR(bucket_778, new_bucket_15_781);
			}
		     }
		   else
		     {
			{
			   obj_t arg1505_783;
			   obj_t arg1507_784;
			   arg1505_783 = CDR(bucket_778);
			   {
			      obj_t aux_1703;
			      obj_t aux_1701;
			      {
				 obj_t aux_1704;
				 aux_1704 = CDR(bucket_778);
				 aux_1703 = CDR(aux_1704);
			      }
			      aux_1701 = (obj_t) (new_777);
			      arg1507_784 = MAKE_PAIR(aux_1701, aux_1703);
			   }
			   SET_CDR(arg1505_783, arg1507_784);
			}
		     }
		}
	      else
		{
		   {
		      obj_t arg1511_786;
		      {
			 obj_t list1512_787;
			 {
			    obj_t arg1513_788;
			    {
			       obj_t aux_1709;
			       aux_1709 = (obj_t) (new_777);
			       arg1513_788 = MAKE_PAIR(aux_1709, BNIL);
			    }
			    list1512_787 = MAKE_PAIR(id_10, arg1513_788);
			 }
			 arg1511_786 = list1512_787;
		      }
		      put_hash__129___hash(arg1511_786, _genv__8_ast_env);
		   }
		}
	      return new_777;
	   }
      }
   }
}


/* _bind-global! */ obj_t 
_bind_global__219_ast_env(obj_t env_1479, obj_t id_1480, obj_t module_1481, obj_t value_1482, obj_t import_1483, obj_t src_1484)
{
   {
      global_t aux_1714;
      aux_1714 = bind_global__138_ast_env(id_1480, module_1481, (value_t) (value_1482), import_1483, src_1484);
      return (obj_t) (aux_1714);
   }
}


/* unbind-global! */ obj_t 
unbind_global__45_ast_env(obj_t id_15, obj_t module_16)
{
   {
      obj_t global_801;
      {
	 obj_t list1551_823;
	 list1551_823 = MAKE_PAIR(module_16, BNIL);
	 global_801 = find_global_223_ast_env(id_15, list1551_823);
      }
      {
	 bool_t test1529_802;
	 test1529_802 = is_a__118___object(global_801, global_ast_var);
	 if (test1529_802)
	   {
	      obj_t bucket_803;
	      bucket_803 = get_hash_29___hash(id_15, _genv__8_ast_env);
	      {
		 obj_t cur_804;
		 obj_t prev_805;
		 cur_804 = CDR(bucket_803);
		 prev_805 = bucket_803;
	       loop_806:
		 {
		    bool_t test_1723;
		    {
		       obj_t aux_1724;
		       aux_1724 = CAR(cur_804);
		       test_1723 = (aux_1724 == global_801);
		    }
		    if (test_1723)
		      {
			 obj_t aux_1727;
			 aux_1727 = CDR(cur_804);
			 return SET_CDR(prev_805, aux_1727);
		      }
		    else
		      {
			 obj_t prev_1732;
			 obj_t cur_1730;
			 cur_1730 = CDR(cur_804);
			 prev_1732 = CDR(prev_805);
			 prev_805 = prev_1732;
			 cur_804 = cur_1730;
			 goto loop_806;
		      }
		 }
	      }
	   }
	 else
	   {
	      obj_t arg1539_815;
	      {
		 obj_t arg1542_817;
		 arg1542_817 = CNST_TABLE_REF(((long) 7));
		 {
		    obj_t list1546_819;
		    {
		       obj_t arg1548_820;
		       {
			  obj_t arg1549_821;
			  arg1549_821 = MAKE_PAIR(BNIL, BNIL);
			  arg1548_820 = MAKE_PAIR(module_16, arg1549_821);
		       }
		       list1546_819 = MAKE_PAIR(id_15, arg1548_820);
		    }
		    arg1539_815 = cons__138___r4_pairs_and_lists_6_3(arg1542_817, list1546_819);
		 }
	      }
	      return user_error_151_tools_error(string1718_ast_env, string1719_ast_env, arg1539_815, BNIL);
	   }
      }
   }
}


/* _unbind-global! */ obj_t 
_unbind_global__69_ast_env(obj_t env_1485, obj_t id_1486, obj_t module_1487)
{
   return unbind_global__45_ast_env(id_1486, module_1487);
}


/* for-each-global! */ obj_t 
for_each_global__88_ast_env(obj_t proc_17)
{
   {
      obj_t arg1553_1488;
      arg1553_1488 = make_fx_procedure(arg1553_ast_env, ((long) 1), ((long) 1));
      PROCEDURE_SET(arg1553_1488, ((long) 0), proc_17);
      return for_each_hash_105___hash(arg1553_1488, _genv__8_ast_env);
   }
}


/* _for-each-global! */ obj_t 
_for_each_global__131_ast_env(obj_t env_1489, obj_t proc_1490)
{
   return for_each_global__88_ast_env(proc_1490);
}


/* arg1553 */ obj_t 
arg1553_ast_env(obj_t env_1491, obj_t bucket_1493)
{
   {
      obj_t proc_1492;
      proc_1492 = PROCEDURE_REF(env_1491, ((long) 0));
      {
	 obj_t bucket_826;
	 {
	    bool_t aux_1747;
	    bucket_826 = bucket_1493;
	    {
	       obj_t l1440_828;
	       l1440_828 = CDR(bucket_826);
	     lname1441_829:
	       if (PAIRP(l1440_828))
		 {
		    PROCEDURE_ENTRY(proc_1492) (proc_1492, CAR(l1440_828), BEOA);
		    {
		       obj_t l1440_1753;
		       l1440_1753 = CDR(l1440_828);
		       l1440_828 = l1440_1753;
		       goto lname1441_829;
		    }
		 }
	       else
		 {
		    aux_1747 = ((bool_t) 1);
		 }
	    }
	    return BBOOL(aux_1747);
	 }
      }
   }
}


/* global-bucket-position */ obj_t 
global_bucket_position_189_ast_env(obj_t id_18, obj_t module_19)
{
   {
      obj_t bucket_835;
      bucket_835 = get_hash_29___hash(id_18, _genv__8_ast_env);
      if (PAIRP(bucket_835))
	{
	   obj_t globals_837;
	   long pos_838;
	   {
	      long aux_1760;
	      globals_837 = CDR(bucket_835);
	      pos_838 = ((long) 0);
	    loop_839:
	      if (NULLP(globals_837))
		{
		   aux_1760 = ((long) -1);
		}
	      else
		{
		   bool_t test_1763;
		   {
		      obj_t aux_1764;
		      {
			 global_t obj_1378;
			 {
			    obj_t aux_1765;
			    aux_1765 = CAR(globals_837);
			    obj_1378 = (global_t) (aux_1765);
			 }
			 aux_1764 = (((global_t) CREF(obj_1378))->module);
		      }
		      test_1763 = (aux_1764 == module_19);
		   }
		   if (test_1763)
		     {
			aux_1760 = pos_838;
		     }
		   else
		     {
			{
			   long pos_1772;
			   obj_t globals_1770;
			   globals_1770 = CDR(globals_837);
			   pos_1772 = (pos_838 + ((long) 1));
			   pos_838 = pos_1772;
			   globals_837 = globals_1770;
			   goto loop_839;
			}
		     }
		}
	      return BINT(aux_1760);
	   }
	}
      else
	{
	   return BINT(((long) -1));
	}
   }
}


/* _global-bucket-position */ obj_t 
_global_bucket_position_151_ast_env(obj_t env_1494, obj_t id_1495, obj_t module_1496)
{
   return global_bucket_position_189_ast_env(id_1495, module_1496);
}


/* method-init */ obj_t 
method_init_76_ast_env()
{
   add_generic__110___object(restore_value_types__env_16_ast_env, restore_value_types__default1442_env_197_ast_env);
   add_inlined_method__244___object(restore_value_types__env_16_ast_env, sfun_ast_var, ((long) 0));
   {
      long aux_1780;
      aux_1780 = add_inlined_method__244___object(restore_value_types__env_16_ast_env, cfun_ast_var, ((long) 1));
      return BINT(aux_1780);
   }
}


/* restore-value-types! */ obj_t 
restore_value_types__114_ast_env(value_t value_4)
{
   {
      obj_t method1668_1177;
      obj_t class1673_1178;
      {
	 obj_t arg1676_1175;
	 obj_t arg1677_1176;
	 {
	    object_t obj_1403;
	    obj_1403 = (object_t) (value_4);
	    {
	       obj_t pre_method_105_1404;
	       pre_method_105_1404 = PROCEDURE_REF(restore_value_types__env_16_ast_env, ((long) 2));
	       if (INTEGERP(pre_method_105_1404))
		 {
		    PROCEDURE_SET(restore_value_types__env_16_ast_env, ((long) 2), BUNSPEC);
		    arg1676_1175 = pre_method_105_1404;
		 }
	       else
		 {
		    long obj_class_num_177_1409;
		    obj_class_num_177_1409 = TYPE(obj_1403);
		    {
		       obj_t arg1177_1410;
		       arg1177_1410 = PROCEDURE_REF(restore_value_types__env_16_ast_env, ((long) 1));
		       {
			  long arg1178_1414;
			  {
			     long arg1179_1415;
			     arg1179_1415 = OBJECT_TYPE;
			     arg1178_1414 = (obj_class_num_177_1409 - arg1179_1415);
			  }
			  arg1676_1175 = VECTOR_REF(arg1177_1410, arg1178_1414);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1420;
	    object_1420 = (object_t) (value_4);
	    {
	       long arg1180_1421;
	       {
		  long arg1181_1422;
		  long arg1182_1423;
		  arg1181_1422 = TYPE(object_1420);
		  arg1182_1423 = OBJECT_TYPE;
		  arg1180_1421 = (arg1181_1422 - arg1182_1423);
	       }
	       {
		  obj_t vector_1427;
		  vector_1427 = _classes__134___object;
		  arg1677_1176 = VECTOR_REF(vector_1427, arg1180_1421);
	       }
	    }
	 }
	 method1668_1177 = arg1676_1175;
	 class1673_1178 = arg1677_1176;
	 {
	    if (INTEGERP(method1668_1177))
	      {
		 switch ((long) CINT(method1668_1177))
		   {
		   case ((long) 0):
		      {
			 sfun_t value_1184;
			 value_1184 = (sfun_t) (value_4);
			 {
			    obj_t args_1186;
			    args_1186 = (((sfun_t) CREF(value_1184))->args);
			  loop_1187:
			    if (PAIRP(args_1186))
			      {
				 {
				    obj_t arg_1190;
				    arg_1190 = CAR(args_1186);
				    {
				       bool_t test1682_1191;
				       test1682_1191 = is_a__118___object(arg_1190, type_type_type);
				       if (test1682_1191)
					 {
					    {
					       type_t arg1683_1192;
					       {
						  obj_t aux_1806;
						  {
						     type_t obj_1433;
						     obj_1433 = (type_t) (arg_1190);
						     aux_1806 = (((type_t) CREF(obj_1433))->id);
						  }
						  arg1683_1192 = find_type_26_type_env(aux_1806);
					       }
					       {
						  obj_t aux_1810;
						  aux_1810 = (obj_t) (arg1683_1192);
						  SET_CAR(args_1186, aux_1810);
					       }
					    }
					 }
				       else
					 {
					    bool_t test1685_1194;
					    test1685_1194 = is_a__118___object(arg_1190, local_ast_var);
					    if (test1685_1194)
					      {
						 {
						    type_t new_type_21_1195;
						    {
						       obj_t aux_1815;
						       {
							  type_t arg1688_1197;
							  {
							     local_t obj_1437;
							     obj_1437 = (local_t) (arg_1190);
							     arg1688_1197 = (((local_t) CREF(obj_1437))->type);
							  }
							  aux_1815 = (((type_t) CREF(arg1688_1197))->id);
						       }
						       new_type_21_1195 = find_type_26_type_env(aux_1815);
						    }
						    {
						       local_t obj_1439;
						       obj_1439 = (local_t) (arg_1190);
						       ((((local_t) CREF(obj_1439))->type) = ((type_t) new_type_21_1195), BUNSPEC);
						    }
						 }
					      }
					    else
					      {
						 {
						    obj_t arg1692_1200;
						    arg1692_1200 = shape_tools_shape(arg_1190);
						    FAILURE(string1720_ast_env, string1721_ast_env, arg1692_1200);
						 }
					      }
					 }
				    }
				    {
				       obj_t args_1824;
				       args_1824 = CDR(args_1186);
				       args_1186 = args_1824;
				       goto loop_1187;
				    }
				 }
			      }
			    else
			      {
				 if (NULLP(args_1186))
				   {
				      {
					 obj_t body_1203;
					 body_1203 = (((sfun_t) CREF(value_1184))->body);
					 {
					    bool_t test1695_1204;
					    test1695_1204 = is_a__118___object(body_1203, node_ast_node);
					    if (test1695_1204)
					      {
						 return hrtype_node__16_ast_hrtype((node_t) (body_1203));
					      }
					    else
					      {
						 return BUNSPEC;
					      }
					 }
				      }
				   }
				 else
				   {
				      {
					 obj_t arg1699_1207;
					 arg1699_1207 = shape_tools_shape(args_1186);
					 FAILURE(string1722_ast_env, string1723_ast_env, arg1699_1207);
				      }
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 cfun_t value_1208;
			 value_1208 = (cfun_t) (value_4);
			 {
			    obj_t args_1210;
			    args_1210 = (((cfun_t) CREF(value_1208))->args_type_205);
			  loop_1211:
			    if (PAIRP(args_1210))
			      {
				 {
				    type_t arg1702_1214;
				    {
				       obj_t aux_1839;
				       {
					  type_t obj_1454;
					  {
					     obj_t aux_1840;
					     aux_1840 = CAR(args_1210);
					     obj_1454 = (type_t) (aux_1840);
					  }
					  aux_1839 = (((type_t) CREF(obj_1454))->id);
				       }
				       arg1702_1214 = find_type_26_type_env(aux_1839);
				    }
				    {
				       obj_t aux_1845;
				       aux_1845 = (obj_t) (arg1702_1214);
				       SET_CAR(args_1210, aux_1845);
				    }
				 }
				 {
				    obj_t args_1848;
				    args_1848 = CDR(args_1210);
				    args_1210 = args_1848;
				    goto loop_1211;
				 }
			      }
			    else
			      {
				 return BUNSPEC;
			      }
			 }
		      }
		      break;
		   default:
		    case_else1674_1181:
		      if (PROCEDUREP(method1668_1177))
			{
			   return PROCEDURE_ENTRY(method1668_1177) (method1668_1177, (obj_t) (value_4), BEOA);
			}
		      else
			{
			   obj_t fun1667_1173;
			   fun1667_1173 = PROCEDURE_REF(restore_value_types__env_16_ast_env, ((long) 0));
			   return PROCEDURE_ENTRY(fun1667_1173) (fun1667_1173, (obj_t) (value_4), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1674_1181;
	      }
	 }
      }
   }
}


/* _restore-value-types! */ obj_t 
_restore_value_types__78_ast_env(obj_t env_1497, obj_t value_1498)
{
   return restore_value_types__114_ast_env((value_t) (value_1498));
}


/* restore-value-types!-default1442 */ obj_t 
restore_value_types__default1442_162_ast_env(value_t value_5)
{
   return BUNSPEC;
}


/* _restore-value-types!-default1442 */ obj_t 
_restore_value_types__default1442_251_ast_env(obj_t env_1499, obj_t value_1500)
{
   return restore_value_types__default1442_162_ast_env((value_t) (value_1500));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_env()
{
   module_initialization_70_tools_shape(((long) 0), "AST_ENV");
   module_initialization_70_engine_param(((long) 0), "AST_ENV");
   module_initialization_70_tools_error(((long) 0), "AST_ENV");
   module_initialization_70_type_type(((long) 0), "AST_ENV");
   module_initialization_70_type_cache(((long) 0), "AST_ENV");
   module_initialization_70_type_env(((long) 0), "AST_ENV");
   module_initialization_70_ast_var(((long) 0), "AST_ENV");
   module_initialization_70_ast_node(((long) 0), "AST_ENV");
   module_initialization_70_ast_hrtype(((long) 0), "AST_ENV");
   return module_initialization_70_module_module(((long) 0), "AST_ENV");
}
