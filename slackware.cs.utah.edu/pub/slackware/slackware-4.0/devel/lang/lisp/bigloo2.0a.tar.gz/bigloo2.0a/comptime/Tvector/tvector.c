/*===========================================================================*/
/*   (Tvector/tvector.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;


static obj_t method_init_76_tvector_tvector();
static obj_t _tvec_alias_set_1327_158_tvector_tvector(obj_t, obj_t, obj_t);
extern bool_t tvec_magic__235_tvector_tvector(type_t);
static obj_t struct_object__object_tvec_20_tvector_tvector(obj_t, obj_t, obj_t);
extern obj_t tvec___set__72_tvector_tvector(type_t, obj_t);
static obj_t _tvec__174_tvector_tvector(obj_t, obj_t);
static obj_t _tvec_class_set_1315_179_tvector_tvector(obj_t, obj_t, obj_t);
extern obj_t type_type_type;
extern obj_t tvec_init__set__63_tvector_tvector(type_t, bool_t);
static obj_t _tvec_tvector1332_167_tvector_tvector(obj_t, obj_t);
static obj_t _tvec_magic__set_1323_235_tvector_tvector(obj_t, obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
obj_t tvec_tvector_tvector = BUNSPEC;
static obj_t _tvec_parents1320_22_tvector_tvector(obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t tvec_name_set__198_tvector_tvector(type_t, obj_t);
extern obj_t tvec_coerce_to_set__84_tvector_tvector(type_t, obj_t);
static obj_t _object__struct1338_136___object(obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
static obj_t _tvec_id1310_235_tvector_tvector(obj_t, obj_t);
extern tvec_t declare_tvector_type__101_tvector_tvector(obj_t, obj_t, obj_t);
static obj_t _tvec___set_1325_22_tvector_tvector(obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _tvec_alias1328_160_tvector_tvector(obj_t, obj_t);
static obj_t _tvec_parents_set_1319_5_tvector_tvector(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _emit_tvector_types1307_89_tvector_tvector(obj_t, obj_t);
extern obj_t tvec_tvector_69_tvector_tvector(type_t);
static obj_t _tvec_init_1322_26_tvector_tvector(obj_t, obj_t);
extern obj_t tvec_size_218_tvector_tvector(type_t);
extern long class_num_218___object(obj_t);
extern obj_t tvec_pointed_to_by_set__49_tvector_tvector(type_t, obj_t);
static obj_t _allocate_tvec_199_tvector_tvector(obj_t);
extern type_t find_type_26_type_env(obj_t);
extern obj_t tvec_name_219_tvector_tvector(type_t);
extern obj_t tvec_coerce_to_9_tvector_tvector(type_t);
static obj_t imported_modules_init_94_tvector_tvector();
static obj_t _make_tvec1309_16_tvector_tvector(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t make_coercion_clause_209_tvector_tvector(obj_t);
static obj_t _tvec_item_type1333_92_tvector_tvector(obj_t, obj_t);
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t tvec_size_set__225_tvector_tvector(type_t, obj_t);
extern obj_t tvec_alias_set__17_tvector_tvector(type_t, obj_t);
static obj_t _tvec_magic_1324_106_tvector_tvector(obj_t, obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
static obj_t _exp___r4_numbers_6_5(obj_t, obj_t);
static obj_t _tvec_pointed_to_by1330_27_tvector_tvector(obj_t, obj_t);
extern obj_t tvec_tvector_set__39_tvector_tvector(type_t, obj_t);
static obj_t library_modules_init_112_tvector_tvector();
static obj_t _widening1002_tvec1308_243_tvector_tvector(obj_t, obj_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _struct_object__object1336_122___object(obj_t, obj_t, obj_t);
extern obj_t tvec___12_tvector_tvector(type_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _tvec_size_set_1313_136_tvector_tvector(obj_t, obj_t, obj_t);
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_tvector_tvector();
extern bool_t tvec_init__77_tvector_tvector(type_t);
extern obj_t open_input_string(obj_t);
extern bool_t tvec__226_tvector_tvector(obj_t);
extern obj_t tvec_pointed_to_by_20_tvector_tvector(type_t);
extern obj_t tvec_class_set__119_tvector_tvector(type_t, obj_t);
extern tvec_t widening1002_tvec_226_tvector_tvector(type_t);
extern obj_t tvec_class_217_tvector_tvector(type_t);
extern obj_t emit_tvector_types_117_tvector_tvector(obj_t);
static obj_t object_init_111_tvector_tvector();
extern obj_t tvec_alias_117_tvector_tvector(type_t);
static obj_t _tvec_name_set_1311_190_tvector_tvector(obj_t, obj_t, obj_t);
static obj_t _tvec_coerce_to_set_1317_57_tvector_tvector(obj_t, obj_t, obj_t);
static obj_t _tvec_init__set_1321_225_tvector_tvector(obj_t, obj_t, obj_t);
static obj_t _tvec_class1316_164_tvector_tvector(obj_t, obj_t);
static obj_t _tvec_tvector_set_1331_65_tvector_tvector(obj_t, obj_t, obj_t);
static obj_t _tvec_coerce_to1318_225_tvector_tvector(obj_t, obj_t);
static obj_t _tvec__1326_207_tvector_tvector(obj_t, obj_t);
static obj_t _tvec_name1312_85_tvector_tvector(obj_t, obj_t);
static obj_t _tvec_pointed_to_by_set_1329_83_tvector_tvector(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern type_t allocate_tvec_255_tvector_tvector();
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern tvec_t make_tvec_253_tvector_tvector(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, bool_t, obj_t, obj_t, obj_t, obj_t, type_t);
static obj_t _tvec_size1314_39_tvector_tvector(obj_t, obj_t);
extern type_t tvec_item_type_215_tvector_tvector(tvec_t);
extern obj_t tvec_magic__set__41_tvector_tvector(type_t, bool_t);
static obj_t _declare_tvector_type_1305_73_tvector_tvector(obj_t, obj_t, obj_t, obj_t);
extern obj_t tvec_parents_set__71_tvector_tvector(type_t, obj_t);
extern obj_t object__struct_50___object(object_t);
extern type_t declare_subtype__66_type_env(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_tvector_tvector = BUNSPEC;
static obj_t object__struct_tvec_153_tvector_tvector(obj_t, obj_t);
static obj_t _tvector_type_list__188_tvector_tvector = BUNSPEC;
static obj_t cnst_init_137_tvector_tvector();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t tvec_id_66_tvector_tvector(type_t);
extern obj_t tvec_parents_196_tvector_tvector(type_t);
static obj_t __cnst[6];

DEFINE_EXPORT_PROCEDURE(emit_tvector_types_env_135_tvector_tvector, _emit_tvector_types1307_89_tvector_tvector1359, _emit_tvector_types1307_89_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_tvec_env_194_tvector_tvector, _allocate_tvec_199_tvector_tvector1360, _allocate_tvec_199_tvector_tvector, 0L, 0);
extern obj_t exp_env_94___r4_numbers_6_5;
DEFINE_EXPORT_PROCEDURE(make_tvec_env_31_tvector_tvector, _make_tvec1309_16_tvector_tvector1361, _make_tvec1309_16_tvector_tvector, 0L, 13);
DEFINE_EXPORT_PROCEDURE(widening1002_tvec_env_222_tvector_tvector, _widening1002_tvec1308_243_tvector_tvector1362, _widening1002_tvec1308_243_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_item_type_env_167_tvector_tvector, _tvec_item_type1333_92_tvector_tvector1363, _tvec_item_type1333_92_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_pointed_to_by_env_49_tvector_tvector, _tvec_pointed_to_by1330_27_tvector_tvector1364, _tvec_pointed_to_by1330_27_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec___set__env_13_tvector_tvector, _tvec___set_1325_22_tvector_tvector1365, _tvec___set_1325_22_tvector_tvector, 0L, 2);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(tvec_class_env_152_tvector_tvector, _tvec_class1316_164_tvector_tvector1366, _tvec_class1316_164_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_size_set__env_118_tvector_tvector, _tvec_size_set_1313_136_tvector_tvector1367, _tvec_size_set_1313_136_tvector_tvector, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1352_tvector_tvector, struct_object__object_tvec_20_tvector_tvector1368, struct_object__object_tvec_20_tvector_tvector, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1351_tvector_tvector, object__struct_tvec_153_tvector_tvector1369, object__struct_tvec_153_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_init__set__env_111_tvector_tvector, _tvec_init__set_1321_225_tvector_tvector1370, _tvec_init__set_1321_225_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec__env_222_tvector_tvector, _tvec__174_tvector_tvector1371, _tvec__174_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_tvector_set__env_230_tvector_tvector, _tvec_tvector_set_1331_65_tvector_tvector1372, _tvec_tvector_set_1331_65_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_tvector_env_84_tvector_tvector, _tvec_tvector1332_167_tvector_tvector1373, _tvec_tvector1332_167_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_name_set__env_207_tvector_tvector, _tvec_name_set_1311_190_tvector_tvector1374, _tvec_name_set_1311_190_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_coerce_to_set__env_72_tvector_tvector, _tvec_coerce_to_set_1317_57_tvector_tvector1375, _tvec_coerce_to_set_1317_57_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_alias_set__env_195_tvector_tvector, _tvec_alias_set_1327_158_tvector_tvector1376, _tvec_alias_set_1327_158_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_magic__env_201_tvector_tvector, _tvec_magic_1324_106_tvector_tvector1377, _tvec_magic_1324_106_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_id_env_86_tvector_tvector, _tvec_id1310_235_tvector_tvector1378, _tvec_id1310_235_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_parents_env_105_tvector_tvector, _tvec_parents1320_22_tvector_tvector1379, _tvec_parents1320_22_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_pointed_to_by_set__env_110_tvector_tvector, _tvec_pointed_to_by_set_1329_83_tvector_tvector1380, _tvec_pointed_to_by_set_1329_83_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_name_env_11_tvector_tvector, _tvec_name1312_85_tvector_tvector1381, _tvec_name1312_85_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_coerce_to_env_107_tvector_tvector, _tvec_coerce_to1318_225_tvector_tvector1382, _tvec_coerce_to1318_225_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_class_set__env_51_tvector_tvector, _tvec_class_set_1315_179_tvector_tvector1383, _tvec_class_set_1315_179_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_size_env_12_tvector_tvector, _tvec_size1314_39_tvector_tvector1384, _tvec_size1314_39_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(declare_tvector_type__env_25_tvector_tvector, _declare_tvector_type_1305_73_tvector_tvector1385, _declare_tvector_type_1305_73_tvector_tvector, 0L, 3);
DEFINE_EXPORT_PROCEDURE(tvec_magic__set__env_66_tvector_tvector, _tvec_magic__set_1323_235_tvector_tvector1386, _tvec_magic__set_1323_235_tvector_tvector, 0L, 2);
DEFINE_EXPORT_PROCEDURE(tvec_alias_env_135_tvector_tvector, _tvec_alias1328_160_tvector_tvector1387, _tvec_alias1328_160_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec___env_74_tvector_tvector, _tvec__1326_207_tvector_tvector1388, _tvec__1326_207_tvector_tvector, 0L, 1);
DEFINE_EXPORT_PROCEDURE(tvec_init__env_169_tvector_tvector, _tvec_init_1322_26_tvector_tvector1389, _tvec_init_1322_26_tvector_tvector, 0L, 1);
DEFINE_STRING(string1353_tvector_tvector, string1353_tvector_tvector1390, "TVEC TVECTOR COERCE TYPE BIGLOO OBJ ", 36);
DEFINE_STRING(string1349_tvector_tvector, string1349_tvector_tvector1391, ";\n", 2);
DEFINE_STRING(string1350_tvector_tvector, string1350_tvector_tvector1392, "} * ", 4);
DEFINE_STRING(string1348_tvector_tvector, string1348_tvector_tvector1393, "   ", 3);
DEFINE_STRING(string1347_tvector_tvector, string1347_tvector_tvector1394, " el0;", 5);
DEFINE_STRING(string1346_tvector_tvector, string1346_tvector_tvector1395, "   obj_t    descr;", 18);
DEFINE_STRING(string1345_tvector_tvector, string1345_tvector_tvector1396, "   long     length;", 19);
DEFINE_STRING(string1344_tvector_tvector, string1344_tvector_tvector1397, "   header_t header;", 19);
DEFINE_STRING(string1343_tvector_tvector, string1343_tvector_tvector1398, "typedef ", 8);
DEFINE_STRING(string1342_tvector_tvector, string1342_tvector_tvector1399, " {", 2);
DEFINE_STRING(string1341_tvector_tvector, string1341_tvector_tvector1400, "/* Tvector type definitions */", 30);
DEFINE_STRING(string1339_tvector_tvector, string1339_tvector_tvector1401, "declare-tvector-type!", 21);
DEFINE_STRING(string1340_tvector_tvector, string1340_tvector_tvector1402, "Unable to find `obj' type", 25);
DEFINE_EXPORT_PROCEDURE(tvec_parents_set__env_136_tvector_tvector, _tvec_parents_set_1319_5_tvector_tvector1403, _tvec_parents_set_1319_5_tvector_tvector, 0L, 2);
extern obj_t object__struct_env_210___object;


/* module-initialization */ obj_t 
module_initialization_70_tvector_tvector(long checksum_485, char *from_486)
{
   if (CBOOL(require_initialization_114_tvector_tvector))
     {
	require_initialization_114_tvector_tvector = BBOOL(((bool_t) 0));
	library_modules_init_112_tvector_tvector();
	cnst_init_137_tvector_tvector();
	imported_modules_init_94_tvector_tvector();
	object_init_111_tvector_tvector();
	method_init_76_tvector_tvector();
	toplevel_init_63_tvector_tvector();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tvector_tvector()
{
   module_initialization_70___object(((long) 0), "TVECTOR_TVECTOR");
   module_initialization_70___r4_output_6_10_3(((long) 0), "TVECTOR_TVECTOR");
   module_initialization_70___reader(((long) 0), "TVECTOR_TVECTOR");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TVECTOR_TVECTOR");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_tvector_tvector()
{
   {
      obj_t cnst_port_138_477;
      cnst_port_138_477 = open_input_string(string1353_tvector_tvector);
      {
	 long i_478;
	 i_478 = ((long) 5);
       loop_479:
	 {
	    bool_t test1354_480;
	    test1354_480 = (i_478 == ((long) -1));
	    if (test1354_480)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1355_481;
		    {
		       obj_t list1356_482;
		       {
			  obj_t arg1357_483;
			  arg1357_483 = BNIL;
			  list1356_482 = MAKE_PAIR(cnst_port_138_477, arg1357_483);
		       }
		       arg1355_481 = read___reader(list1356_482);
		    }
		    CNST_TABLE_SET(i_478, arg1355_481);
		 }
		 {
		    int aux_484;
		    {
		       long aux_506;
		       aux_506 = (i_478 - ((long) 1));
		       aux_484 = (int) (aux_506);
		    }
		    {
		       long i_509;
		       i_509 = (long) (aux_484);
		       i_478 = i_509;
		       goto loop_479;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_tvector_tvector()
{
   return (_tvector_type_list__188_tvector_tvector = BNIL,
      BUNSPEC);
}


/* declare-tvector-type! */ tvec_t 
declare_tvector_type__101_tvector_tvector(obj_t tvect_id_86_1, obj_t item_id_36_2, obj_t src_3)
{
   {
      type_t obj_117;
      obj_117 = find_type_26_type_env(CNST_TABLE_REF(((long) 0)));
      {
	 bool_t test1068_118;
	 test1068_118 = is_a__118___object((obj_t) (obj_117), type_type_type);
	 if (test1068_118)
	   {
	      type_t type_119;
	      type_t item_type_130_120;
	      {
		 obj_t arg1145_126;
		 obj_t arg1150_127;
		 obj_t arg1157_128;
		 arg1145_126 = (((type_t) CREF(obj_117))->name);
		 {
		    obj_t list1162_130;
		    {
		       obj_t aux_517;
		       aux_517 = CNST_TABLE_REF(((long) 0));
		       list1162_130 = MAKE_PAIR(aux_517, BNIL);
		    }
		    arg1150_127 = list1162_130;
		 }
		 arg1157_128 = CNST_TABLE_REF(((long) 1));
		 type_119 = declare_subtype__66_type_env(tvect_id_86_1, arg1145_126, arg1150_127, arg1157_128);
	      }
	      item_type_130_120 = use_type__231_type_env(item_id_36_2);
	      {
		 tvec_t obj1061_121;
		 obj1061_121 = ((tvec_t) (type_119));
		 {
		    tvec_t arg1077_122;
		    {
		       tvec_t res1301_276;
		       {
			  tvec_t new1037_274;
			  new1037_274 = ((tvec_t) BREF(GC_MALLOC(sizeof(struct tvec))));
			  ((((tvec_t) CREF(new1037_274))->item_type_130) = ((type_t) item_type_130_120), BUNSPEC);
			  res1301_276 = new1037_274;
		       }
		       arg1077_122 = res1301_276;
		    }
		    {
		       obj_t aux_528;
		       object_t aux_526;
		       aux_528 = (obj_t) (arg1077_122);
		       aux_526 = (object_t) (obj1061_121);
		       OBJECT_WIDENING_SET(aux_526, aux_528);
		    }
		 }
		 {
		    long arg1142_124;
		    arg1142_124 = class_num_218___object(tvec_tvector_tvector);
		    {
		       obj_t obj_277;
		       obj_277 = (obj_t) (obj1061_121);
		       (((obj_t) CREF(obj_277))->header = MAKE_HEADER(arg1142_124, 0), BUNSPEC);
		    }
		 }
		 obj1061_121;
	      }
	      {
		 obj_t arg1144_125;
		 arg1144_125 = make_coercion_clause_209_tvector_tvector(tvect_id_86_1);
		 produce_module_clause__172_module_module(arg1144_125);
	      }
	      {
		 obj_t obj2_280;
		 obj2_280 = _tvector_type_list__188_tvector_tvector;
		 {
		    obj_t aux_536;
		    aux_536 = (obj_t) (type_119);
		    _tvector_type_list__188_tvector_tvector = MAKE_PAIR(aux_536, obj2_280);
		 }
	      }
	      {
		 obj_t val1027_282;
		 val1027_282 = (obj_t) (type_119);
		 ((((type_t) CREF(item_type_130_120))->tvector) = ((obj_t) val1027_282), BUNSPEC);
	      }
	      return (tvec_t) (type_119);
	   }
	 else
	   {
	      obj_t aux_542;
	      aux_542 = user_error_151_tools_error(string1339_tvector_tvector, string1340_tvector_tvector, exp_env_94___r4_numbers_6_5, BNIL);
	      return (tvec_t) (aux_542);
	   }
      }
   }
}


/* _declare-tvector-type!1305 */ obj_t 
_declare_tvector_type_1305_73_tvector_tvector(obj_t env_379, obj_t tvect_id_86_380, obj_t item_id_36_381, obj_t src_382)
{
   {
      tvec_t aux_545;
      aux_545 = declare_tvector_type__101_tvector_tvector(tvect_id_86_380, item_id_36_381, src_382);
      return (obj_t) (aux_545);
   }
}


/* emit-tvector-types */ obj_t 
emit_tvector_types_117_tvector_tvector(obj_t oport_4)
{
   {
      bool_t test1177_134;
      {
	 obj_t obj_283;
	 obj_283 = _tvector_type_list__188_tvector_tvector;
	 test1177_134 = PAIRP(obj_283);
      }
      if (test1177_134)
	{
	   obj_t list1178_135;
	   {
	      obj_t arg1187_136;
	      arg1187_136 = MAKE_PAIR(string1341_tvector_tvector, BNIL);
	      {
		 obj_t aux_551;
		 aux_551 = BCHAR(((unsigned char) '\n'));
		 list1178_135 = MAKE_PAIR(aux_551, arg1187_136);
	      }
	   }
	   fprint___r4_output_6_10_3(oport_4, list1178_135);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t l1062_139;
      {
	 obj_t arg1191_141;
	 arg1191_141 = reverse__39___r4_pairs_and_lists_6_3(_tvector_type_list__188_tvector_tvector);
	 l1062_139 = arg1191_141;
       lname1063_140:
	 if (PAIRP(l1062_139))
	   {
	      {
		 obj_t tvector_143;
		 tvector_143 = CAR(l1062_139);
		 {
		    obj_t item_type_name_150_144;
		    {
		       type_t arg1232_174;
		       {
			  tvec_t obj_286;
			  obj_286 = (tvec_t) (tvector_143);
			  {
			     obj_t aux_560;
			     {
				object_t aux_561;
				aux_561 = (object_t) (obj_286);
				aux_560 = OBJECT_WIDENING(aux_561);
			     }
			     arg1232_174 = (((tvec_t) CREF(aux_560))->item_type_130);
			  }
		       }
		       item_type_name_150_144 = (((type_t) CREF(arg1232_174))->name);
		    }
		    {
		       obj_t arg1194_146;
		       {
			  type_t obj_288;
			  obj_288 = (type_t) (tvector_143);
			  arg1194_146 = (((type_t) CREF(obj_288))->size);
		       }
		       {
			  obj_t list1196_148;
			  {
			     obj_t arg1197_149;
			     {
				obj_t arg1199_150;
				arg1199_150 = MAKE_PAIR(string1342_tvector_tvector, BNIL);
				arg1197_149 = MAKE_PAIR(arg1194_146, arg1199_150);
			     }
			     list1196_148 = MAKE_PAIR(string1343_tvector_tvector, arg1197_149);
			  }
			  fprint___r4_output_6_10_3(oport_4, list1196_148);
		       }
		    }
		    {
		       obj_t list1201_152;
		       list1201_152 = MAKE_PAIR(string1344_tvector_tvector, BNIL);
		       fprint___r4_output_6_10_3(oport_4, list1201_152);
		    }
		    {
		       obj_t list1204_155;
		       list1204_155 = MAKE_PAIR(string1345_tvector_tvector, BNIL);
		       fprint___r4_output_6_10_3(oport_4, list1204_155);
		    }
		    {
		       obj_t list1207_158;
		       list1207_158 = MAKE_PAIR(string1346_tvector_tvector, BNIL);
		       fprint___r4_output_6_10_3(oport_4, list1207_158);
		    }
		    {
		       obj_t list1211_161;
		       {
			  obj_t arg1214_163;
			  {
			     obj_t arg1216_164;
			     arg1216_164 = MAKE_PAIR(string1347_tvector_tvector, BNIL);
			     arg1214_163 = MAKE_PAIR(item_type_name_150_144, arg1216_164);
			  }
			  list1211_161 = MAKE_PAIR(string1348_tvector_tvector, arg1214_163);
		       }
		       fprint___r4_output_6_10_3(oport_4, list1211_161);
		    }
		    {
		       obj_t arg1222_168;
		       {
			  type_t obj_289;
			  obj_289 = (type_t) (type_type_type);
			  arg1222_168 = (((type_t) CREF(obj_289))->name);
		       }
		       {
			  obj_t list1225_170;
			  {
			     obj_t arg1226_171;
			     {
				obj_t arg1228_172;
				arg1228_172 = MAKE_PAIR(string1349_tvector_tvector, BNIL);
				arg1226_171 = MAKE_PAIR(arg1222_168, arg1228_172);
			     }
			     list1225_170 = MAKE_PAIR(string1350_tvector_tvector, arg1226_171);
			  }
			  fprint___r4_output_6_10_3(oport_4, list1225_170);
		       }
		    }
		 }
	      }
	      {
		 obj_t l1062_588;
		 l1062_588 = CDR(l1062_139);
		 l1062_139 = l1062_588;
		 goto lname1063_140;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
   }
   {
      obj_t list1234_176;
      list1234_176 = MAKE_PAIR(oport_4, BNIL);
      return newline___r4_output_6_10_3(list1234_176);
   }
}


/* _emit-tvector-types1307 */ obj_t 
_emit_tvector_types1307_89_tvector_tvector(obj_t env_385, obj_t oport_386)
{
   return emit_tvector_types_117_tvector_tvector(oport_386);
}


/* make-coercion-clause */ obj_t 
make_coercion_clause_209_tvector_tvector(obj_t tvect_id_86_5)
{
   {
      obj_t arg1236_178;
      obj_t arg1238_179;
      obj_t arg1240_180;
      arg1236_178 = CNST_TABLE_REF(((long) 2));
      {
	 obj_t arg1247_186;
	 obj_t arg1248_187;
	 arg1247_186 = CNST_TABLE_REF(((long) 3));
	 arg1248_187 = CNST_TABLE_REF(((long) 4));
	 {
	    obj_t list1253_191;
	    {
	       obj_t arg1254_192;
	       {
		  obj_t arg1255_193;
		  {
		     obj_t arg1256_194;
		     {
			obj_t arg1257_195;
			arg1257_195 = MAKE_PAIR(BNIL, BNIL);
			arg1256_194 = MAKE_PAIR(BNIL, arg1257_195);
		     }
		     arg1255_193 = MAKE_PAIR(BNIL, arg1256_194);
		  }
		  arg1254_192 = MAKE_PAIR(arg1248_187, arg1255_193);
	       }
	       list1253_191 = MAKE_PAIR(tvect_id_86_5, arg1254_192);
	    }
	    arg1238_179 = cons__138___r4_pairs_and_lists_6_3(arg1247_186, list1253_191);
	 }
      }
      {
	 obj_t arg1259_197;
	 obj_t arg1260_198;
	 arg1259_197 = CNST_TABLE_REF(((long) 3));
	 arg1260_198 = CNST_TABLE_REF(((long) 4));
	 {
	    obj_t list1266_202;
	    {
	       obj_t arg1267_203;
	       {
		  obj_t arg1268_204;
		  {
		     obj_t arg1269_205;
		     {
			obj_t arg1270_206;
			arg1270_206 = MAKE_PAIR(BNIL, BNIL);
			arg1269_205 = MAKE_PAIR(BNIL, arg1270_206);
		     }
		     arg1268_204 = MAKE_PAIR(BNIL, arg1269_205);
		  }
		  arg1267_203 = MAKE_PAIR(tvect_id_86_5, arg1268_204);
	       }
	       list1266_202 = MAKE_PAIR(arg1260_198, arg1267_203);
	    }
	    arg1240_180 = cons__138___r4_pairs_and_lists_6_3(arg1259_197, list1266_202);
	 }
      }
      {
	 obj_t list1242_182;
	 {
	    obj_t arg1243_183;
	    {
	       obj_t arg1244_184;
	       arg1244_184 = MAKE_PAIR(BNIL, BNIL);
	       arg1243_183 = MAKE_PAIR(arg1240_180, arg1244_184);
	    }
	    list1242_182 = MAKE_PAIR(arg1238_179, arg1243_183);
	 }
	 return cons__138___r4_pairs_and_lists_6_3(arg1236_178, list1242_182);
      }
   }
}


/* object-init */ obj_t 
object_init_111_tvector_tvector()
{
   {
      obj_t arg1274_209;
      arg1274_209 = type_type_type;
      tvec_tvector_tvector = add_class__117___object(CNST_TABLE_REF(((long) 5)), arg1274_209, allocate_tvec_env_194_tvector_tvector, ((long) 17798), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-tvec */ type_t 
allocate_tvec_255_tvector_tvector()
{
   {
      type_t new1053_212;
      new1053_212 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
      {
	 long arg1281_213;
	 arg1281_213 = class_num_218___object(tvec_tvector_tvector);
	 {
	    obj_t obj_291;
	    obj_291 = (obj_t) (new1053_212);
	    (((obj_t) CREF(obj_291))->header = MAKE_HEADER(arg1281_213, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_620;
	 aux_620 = (object_t) (new1053_212);
	 OBJECT_WIDENING_SET(aux_620, BFALSE);
      }
      return new1053_212;
   }
}


/* _allocate-tvec */ obj_t 
_allocate_tvec_199_tvector_tvector(obj_t env_387)
{
   {
      type_t aux_623;
      aux_623 = allocate_tvec_255_tvector_tvector();
      return (obj_t) (aux_623);
   }
}


/* tvec? */ bool_t 
tvec__226_tvector_tvector(obj_t obj_9)
{
   return is_a__118___object(obj_9, tvec_tvector_tvector);
}


/* _tvec? */ obj_t 
_tvec__174_tvector_tvector(obj_t env_388, obj_t obj_389)
{
   {
      bool_t aux_627;
      aux_627 = tvec__226_tvector_tvector(obj_389);
      return BBOOL(aux_627);
   }
}


/* widening1002-tvec */ tvec_t 
widening1002_tvec_226_tvector_tvector(type_t item_type_130_10)
{
   {
      tvec_t new1037_293;
      new1037_293 = ((tvec_t) BREF(GC_MALLOC(sizeof(struct tvec))));
      ((((tvec_t) CREF(new1037_293))->item_type_130) = ((type_t) item_type_130_10), BUNSPEC);
      return new1037_293;
   }
}


/* _widening1002-tvec1308 */ obj_t 
_widening1002_tvec1308_243_tvector_tvector(obj_t env_390, obj_t item_type_130_391)
{
   {
      tvec_t aux_632;
      aux_632 = widening1002_tvec_226_tvector_tvector((type_t) (item_type_130_391));
      return (obj_t) (aux_632);
   }
}


/* make-tvec */ tvec_t 
make_tvec_253_tvector_tvector(obj_t id_11, obj_t name_12, obj_t size_13, obj_t class_14, obj_t coerce_to_204_15, obj_t parents_16, bool_t init__47_17, bool_t magic__53_18, obj_t __57_19, obj_t alias_20, obj_t pointed_to_by_76_21, obj_t tvector_22, type_t item_type_130_23)
{
   {
      type_t aux1040_295;
      {
	 type_t res1302_327;
	 {
	    type_t new1003_311;
	    new1003_311 = ((type_t) BREF(GC_MALLOC(sizeof(struct type))));
	    {
	       long arg1287_312;
	       arg1287_312 = class_num_218___object(type_type_type);
	       {
		  obj_t obj_325;
		  obj_325 = (obj_t) (new1003_311);
		  (((obj_t) CREF(obj_325))->header = MAKE_HEADER(arg1287_312, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_640;
	       aux_640 = (object_t) (new1003_311);
	       OBJECT_WIDENING_SET(aux_640, BFALSE);
	    }
	    ((((type_t) CREF(new1003_311))->id) = ((obj_t) id_11), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->name) = ((obj_t) name_12), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->size) = ((obj_t) size_13), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->class) = ((obj_t) class_14), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->coerce_to_204) = ((obj_t) coerce_to_204_15), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->parents) = ((obj_t) parents_16), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->init__47) = ((bool_t) init__47_17), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->magic__53) = ((bool_t) magic__53_18), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->__57) = ((obj_t) __57_19), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->alias) = ((obj_t) alias_20), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->pointed_to_by_76) = ((obj_t) pointed_to_by_76_21), BUNSPEC);
	    ((((type_t) CREF(new1003_311))->tvector) = ((obj_t) tvector_22), BUNSPEC);
	    res1302_327 = new1003_311;
	 }
	 aux1040_295 = res1302_327;
      }
      {
	 tvec_t new1041_296;
	 new1041_296 = ((tvec_t) (aux1040_295));
	 {
	    long arg1282_297;
	    arg1282_297 = class_num_218___object(tvec_tvector_tvector);
	    {
	       obj_t obj_328;
	       obj_328 = (obj_t) (new1041_296);
	       (((obj_t) CREF(obj_328))->header = MAKE_HEADER(arg1282_297, 0), BUNSPEC);
	    }
	 }
	 {
	    tvec_t arg1283_298;
	    {
	       tvec_t res1303_333;
	       {
		  tvec_t new1037_331;
		  new1037_331 = ((tvec_t) BREF(GC_MALLOC(sizeof(struct tvec))));
		  ((((tvec_t) CREF(new1037_331))->item_type_130) = ((type_t) item_type_130_23), BUNSPEC);
		  res1303_333 = new1037_331;
	       }
	       arg1283_298 = res1303_333;
	    }
	    {
	       obj_t aux_663;
	       object_t aux_661;
	       aux_663 = (obj_t) (arg1283_298);
	       aux_661 = (object_t) (new1041_296);
	       OBJECT_WIDENING_SET(aux_661, aux_663);
	    }
	 }
	 return new1041_296;
      }
   }
}


/* _make-tvec1309 */ obj_t 
_make_tvec1309_16_tvector_tvector(obj_t env_392, obj_t id_393, obj_t name_394, obj_t size_395, obj_t class_396, obj_t coerce_to_204_397, obj_t parents_398, obj_t init__47_399, obj_t magic__53_400, obj_t __57_401, obj_t alias_402, obj_t pointed_to_by_76_403, obj_t tvector_404, obj_t item_type_130_405)
{
   {
      tvec_t aux_666;
      aux_666 = make_tvec_253_tvector_tvector(id_393, name_394, size_395, class_396, coerce_to_204_397, parents_398, CBOOL(init__47_399), CBOOL(magic__53_400), __57_401, alias_402, pointed_to_by_76_403, tvector_404, (type_t) (item_type_130_405));
      return (obj_t) (aux_666);
   }
}


/* tvec-id */ obj_t 
tvec_id_66_tvector_tvector(type_t obj_24)
{
   return (((type_t) CREF(obj_24))->id);
}


/* _tvec-id1310 */ obj_t 
_tvec_id1310_235_tvector_tvector(obj_t env_406, obj_t obj_407)
{
   return tvec_id_66_tvector_tvector((type_t) (obj_407));
}


/* tvec-name-set! */ obj_t 
tvec_name_set__198_tvector_tvector(type_t obj_25, obj_t val1042_26)
{
   return ((((type_t) CREF(obj_25))->name) = ((obj_t) val1042_26), BUNSPEC);
}


/* _tvec-name-set!1311 */ obj_t 
_tvec_name_set_1311_190_tvector_tvector(obj_t env_408, obj_t obj_409, obj_t val1042_410)
{
   return tvec_name_set__198_tvector_tvector((type_t) (obj_409), val1042_410);
}


/* tvec-name */ obj_t 
tvec_name_219_tvector_tvector(type_t obj_27)
{
   return (((type_t) CREF(obj_27))->name);
}


/* _tvec-name1312 */ obj_t 
_tvec_name1312_85_tvector_tvector(obj_t env_411, obj_t obj_412)
{
   return tvec_name_219_tvector_tvector((type_t) (obj_412));
}


/* tvec-size-set! */ obj_t 
tvec_size_set__225_tvector_tvector(type_t obj_28, obj_t val1043_29)
{
   return ((((type_t) CREF(obj_28))->size) = ((obj_t) val1043_29), BUNSPEC);
}


/* _tvec-size-set!1313 */ obj_t 
_tvec_size_set_1313_136_tvector_tvector(obj_t env_413, obj_t obj_414, obj_t val1043_415)
{
   return tvec_size_set__225_tvector_tvector((type_t) (obj_414), val1043_415);
}


/* tvec-size */ obj_t 
tvec_size_218_tvector_tvector(type_t obj_30)
{
   return (((type_t) CREF(obj_30))->size);
}


/* _tvec-size1314 */ obj_t 
_tvec_size1314_39_tvector_tvector(obj_t env_416, obj_t obj_417)
{
   return tvec_size_218_tvector_tvector((type_t) (obj_417));
}


/* tvec-class-set! */ obj_t 
tvec_class_set__119_tvector_tvector(type_t obj_31, obj_t val1044_32)
{
   return ((((type_t) CREF(obj_31))->class) = ((obj_t) val1044_32), BUNSPEC);
}


/* _tvec-class-set!1315 */ obj_t 
_tvec_class_set_1315_179_tvector_tvector(obj_t env_418, obj_t obj_419, obj_t val1044_420)
{
   return tvec_class_set__119_tvector_tvector((type_t) (obj_419), val1044_420);
}


/* tvec-class */ obj_t 
tvec_class_217_tvector_tvector(type_t obj_33)
{
   return (((type_t) CREF(obj_33))->class);
}


/* _tvec-class1316 */ obj_t 
_tvec_class1316_164_tvector_tvector(obj_t env_421, obj_t obj_422)
{
   return tvec_class_217_tvector_tvector((type_t) (obj_422));
}


/* tvec-coerce-to-set! */ obj_t 
tvec_coerce_to_set__84_tvector_tvector(type_t obj_34, obj_t val1045_35)
{
   return ((((type_t) CREF(obj_34))->coerce_to_204) = ((obj_t) val1045_35), BUNSPEC);
}


/* _tvec-coerce-to-set!1317 */ obj_t 
_tvec_coerce_to_set_1317_57_tvector_tvector(obj_t env_423, obj_t obj_424, obj_t val1045_425)
{
   return tvec_coerce_to_set__84_tvector_tvector((type_t) (obj_424), val1045_425);
}


/* tvec-coerce-to */ obj_t 
tvec_coerce_to_9_tvector_tvector(type_t obj_36)
{
   return (((type_t) CREF(obj_36))->coerce_to_204);
}


/* _tvec-coerce-to1318 */ obj_t 
_tvec_coerce_to1318_225_tvector_tvector(obj_t env_426, obj_t obj_427)
{
   return tvec_coerce_to_9_tvector_tvector((type_t) (obj_427));
}


/* tvec-parents-set! */ obj_t 
tvec_parents_set__71_tvector_tvector(type_t obj_37, obj_t val1046_38)
{
   return ((((type_t) CREF(obj_37))->parents) = ((obj_t) val1046_38), BUNSPEC);
}


/* _tvec-parents-set!1319 */ obj_t 
_tvec_parents_set_1319_5_tvector_tvector(obj_t env_428, obj_t obj_429, obj_t val1046_430)
{
   return tvec_parents_set__71_tvector_tvector((type_t) (obj_429), val1046_430);
}


/* tvec-parents */ obj_t 
tvec_parents_196_tvector_tvector(type_t obj_39)
{
   return (((type_t) CREF(obj_39))->parents);
}


/* _tvec-parents1320 */ obj_t 
_tvec_parents1320_22_tvector_tvector(obj_t env_431, obj_t obj_432)
{
   return tvec_parents_196_tvector_tvector((type_t) (obj_432));
}


/* tvec-init?-set! */ obj_t 
tvec_init__set__63_tvector_tvector(type_t obj_40, bool_t val1047_41)
{
   return ((((type_t) CREF(obj_40))->init__47) = ((bool_t) val1047_41), BUNSPEC);
}


/* _tvec-init?-set!1321 */ obj_t 
_tvec_init__set_1321_225_tvector_tvector(obj_t env_433, obj_t obj_434, obj_t val1047_435)
{
   return tvec_init__set__63_tvector_tvector((type_t) (obj_434), CBOOL(val1047_435));
}


/* tvec-init? */ bool_t 
tvec_init__77_tvector_tvector(type_t obj_42)
{
   return (((type_t) CREF(obj_42))->init__47);
}


/* _tvec-init?1322 */ obj_t 
_tvec_init_1322_26_tvector_tvector(obj_t env_436, obj_t obj_437)
{
   {
      bool_t aux_710;
      aux_710 = tvec_init__77_tvector_tvector((type_t) (obj_437));
      return BBOOL(aux_710);
   }
}


/* tvec-magic?-set! */ obj_t 
tvec_magic__set__41_tvector_tvector(type_t obj_43, bool_t val1048_44)
{
   return ((((type_t) CREF(obj_43))->magic__53) = ((bool_t) val1048_44), BUNSPEC);
}


/* _tvec-magic?-set!1323 */ obj_t 
_tvec_magic__set_1323_235_tvector_tvector(obj_t env_438, obj_t obj_439, obj_t val1048_440)
{
   return tvec_magic__set__41_tvector_tvector((type_t) (obj_439), CBOOL(val1048_440));
}


/* tvec-magic? */ bool_t 
tvec_magic__235_tvector_tvector(type_t obj_45)
{
   return (((type_t) CREF(obj_45))->magic__53);
}


/* _tvec-magic?1324 */ obj_t 
_tvec_magic_1324_106_tvector_tvector(obj_t env_441, obj_t obj_442)
{
   {
      bool_t aux_719;
      aux_719 = tvec_magic__235_tvector_tvector((type_t) (obj_442));
      return BBOOL(aux_719);
   }
}


/* tvec-$-set! */ obj_t 
tvec___set__72_tvector_tvector(type_t obj_46, obj_t val1049_47)
{
   return ((((type_t) CREF(obj_46))->__57) = ((obj_t) val1049_47), BUNSPEC);
}


/* _tvec-$-set!1325 */ obj_t 
_tvec___set_1325_22_tvector_tvector(obj_t env_443, obj_t obj_444, obj_t val1049_445)
{
   return tvec___set__72_tvector_tvector((type_t) (obj_444), val1049_445);
}


/* tvec-$ */ obj_t 
tvec___12_tvector_tvector(type_t obj_48)
{
   return (((type_t) CREF(obj_48))->__57);
}


/* _tvec-$1326 */ obj_t 
_tvec__1326_207_tvector_tvector(obj_t env_446, obj_t obj_447)
{
   return tvec___12_tvector_tvector((type_t) (obj_447));
}


/* tvec-alias-set! */ obj_t 
tvec_alias_set__17_tvector_tvector(type_t obj_49, obj_t val1050_50)
{
   return ((((type_t) CREF(obj_49))->alias) = ((obj_t) val1050_50), BUNSPEC);
}


/* _tvec-alias-set!1327 */ obj_t 
_tvec_alias_set_1327_158_tvector_tvector(obj_t env_448, obj_t obj_449, obj_t val1050_450)
{
   return tvec_alias_set__17_tvector_tvector((type_t) (obj_449), val1050_450);
}


/* tvec-alias */ obj_t 
tvec_alias_117_tvector_tvector(type_t obj_51)
{
   return (((type_t) CREF(obj_51))->alias);
}


/* _tvec-alias1328 */ obj_t 
_tvec_alias1328_160_tvector_tvector(obj_t env_451, obj_t obj_452)
{
   return tvec_alias_117_tvector_tvector((type_t) (obj_452));
}


/* tvec-pointed-to-by-set! */ obj_t 
tvec_pointed_to_by_set__49_tvector_tvector(type_t obj_52, obj_t val1051_53)
{
   return ((((type_t) CREF(obj_52))->pointed_to_by_76) = ((obj_t) val1051_53), BUNSPEC);
}


/* _tvec-pointed-to-by-set!1329 */ obj_t 
_tvec_pointed_to_by_set_1329_83_tvector_tvector(obj_t env_453, obj_t obj_454, obj_t val1051_455)
{
   return tvec_pointed_to_by_set__49_tvector_tvector((type_t) (obj_454), val1051_455);
}


/* tvec-pointed-to-by */ obj_t 
tvec_pointed_to_by_20_tvector_tvector(type_t obj_54)
{
   return (((type_t) CREF(obj_54))->pointed_to_by_76);
}


/* _tvec-pointed-to-by1330 */ obj_t 
_tvec_pointed_to_by1330_27_tvector_tvector(obj_t env_456, obj_t obj_457)
{
   return tvec_pointed_to_by_20_tvector_tvector((type_t) (obj_457));
}


/* tvec-tvector-set! */ obj_t 
tvec_tvector_set__39_tvector_tvector(type_t obj_55, obj_t val1052_56)
{
   return ((((type_t) CREF(obj_55))->tvector) = ((obj_t) val1052_56), BUNSPEC);
}


/* _tvec-tvector-set!1331 */ obj_t 
_tvec_tvector_set_1331_65_tvector_tvector(obj_t env_458, obj_t obj_459, obj_t val1052_460)
{
   return tvec_tvector_set__39_tvector_tvector((type_t) (obj_459), val1052_460);
}


/* tvec-tvector */ obj_t 
tvec_tvector_69_tvector_tvector(type_t obj_57)
{
   return (((type_t) CREF(obj_57))->tvector);
}


/* _tvec-tvector1332 */ obj_t 
_tvec_tvector1332_167_tvector_tvector(obj_t env_461, obj_t obj_462)
{
   return tvec_tvector_69_tvector_tvector((type_t) (obj_462));
}


/* tvec-item-type */ type_t 
tvec_item_type_215_tvector_tvector(tvec_t obj_58)
{
   {
      obj_t aux_747;
      {
	 object_t aux_748;
	 aux_748 = (object_t) (obj_58);
	 aux_747 = OBJECT_WIDENING(aux_748);
      }
      return (((tvec_t) CREF(aux_747))->item_type_130);
   }
}


/* _tvec-item-type1333 */ obj_t 
_tvec_item_type1333_92_tvector_tvector(obj_t env_463, obj_t obj_464)
{
   {
      type_t aux_752;
      aux_752 = tvec_item_type_215_tvector_tvector((tvec_t) (obj_464));
      return (obj_t) (aux_752);
   }
}


/* method-init */ obj_t 
method_init_76_tvector_tvector()
{
   {
      obj_t object__struct_tvec_153_469;
      object__struct_tvec_153_469 = proc1351_tvector_tvector;
      add_method__1___object(object__struct_env_210___object, tvec_tvector_tvector, object__struct_tvec_153_469);
   }
   {
      obj_t struct_object__object_tvec_20_465;
      struct_object__object_tvec_20_465 = proc1352_tvector_tvector;
      return add_method__1___object(struct_object__object_env_209___object, tvec_tvector_tvector, struct_object__object_tvec_20_465);
   }
}


/* struct+object->object-tvec */ obj_t 
struct_object__object_tvec_20_tvector_tvector(obj_t env_472, obj_t o_473, obj_t s_474)
{
   {
      tvec_t o_258;
      obj_t s_259;
      {
	 tvec_t aux_758;
	 o_258 = (tvec_t) (o_473);
	 s_259 = s_474;
	 {
	    {
	       obj_t old1058_262;
	       obj_t aux1059_263;
	       {
		  obj_t next_method1067_169_268;
		  next_method1067_169_268 = find_super_class_method_167___object((object_t) (o_258), struct_object__object_env_209___object, tvec_tvector_tvector);
		  if (PROCEDUREP(next_method1067_169_268))
		    {
		       old1058_262 = PROCEDURE_ENTRY(next_method1067_169_268) (next_method1067_169_268, (obj_t) (o_258), s_259, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1067_169_268);
		       {
			  object_t aux_767;
			  aux_767 = struct_object__object_93___object((object_t) (o_258), s_259);
			  old1058_262 = (obj_t) (aux_767);
		       }
		    }
	       }
	       aux1059_263 = STRUCT_REF(s_259, ((long) 0));
	       {
		  tvec_t new1060_264;
		  new1060_264 = ((tvec_t) (old1058_262));
		  {
		     long arg1297_265;
		     arg1297_265 = class_num_218___object(tvec_tvector_tvector);
		     {
			obj_t obj_369;
			obj_369 = (obj_t) (new1060_264);
			(((obj_t) CREF(obj_369))->header = MAKE_HEADER(arg1297_265, 0), BUNSPEC);
		     }
		  }
		  {
		     tvec_t arg1298_266;
		     {
			tvec_t res1304_376;
			{
			   type_t item_type_130_373;
			   {
			      obj_t aux_776;
			      aux_776 = STRUCT_REF(aux1059_263, ((long) 0));
			      item_type_130_373 = (type_t) (aux_776);
			   }
			   {
			      tvec_t new1037_374;
			      new1037_374 = ((tvec_t) BREF(GC_MALLOC(sizeof(struct tvec))));
			      ((((tvec_t) CREF(new1037_374))->item_type_130) = ((type_t) item_type_130_373), BUNSPEC);
			      res1304_376 = new1037_374;
			   }
			}
			arg1298_266 = res1304_376;
		     }
		     {
			obj_t aux_783;
			object_t aux_781;
			aux_783 = (obj_t) (arg1298_266);
			aux_781 = (object_t) (new1060_264);
			OBJECT_WIDENING_SET(aux_781, aux_783);
		     }
		  }
		  aux_758 = new1060_264;
	       }
	    }
	 }
	 return (obj_t) (aux_758);
      }
   }
}


/* object->struct-tvec */ obj_t 
object__struct_tvec_153_tvector_tvector(obj_t env_475, obj_t obj1055_476)
{
   {
      tvec_t obj1055_245;
      obj1055_245 = (tvec_t) (obj1055_476);
      {
	 {
	    obj_t res1056_248;
	    {
	       obj_t next_method1066_234_256;
	       next_method1066_234_256 = find_super_class_method_167___object((object_t) (obj1055_245), object__struct_env_210___object, tvec_tvector_tvector);
	       if (PROCEDUREP(next_method1066_234_256))
		 {
		    res1056_248 = PROCEDURE_ENTRY(next_method1066_234_256) (next_method1066_234_256, (obj_t) (obj1055_245), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1066_234_256);
		    res1056_248 = object__struct_50___object((object_t) (obj1055_245));
		 }
	    }
	    {
	       obj_t aux1057_249;
	       {
		  obj_t aux_798;
		  aux_798 = CNST_TABLE_REF(((long) 5));
		  aux1057_249 = make_struct(aux_798, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_801;
		  {
		     type_t aux_802;
		     {
			obj_t aux_803;
			{
			   object_t aux_804;
			   aux_804 = (object_t) (obj1055_245);
			   aux_803 = OBJECT_WIDENING(aux_804);
			}
			aux_802 = (((tvec_t) CREF(aux_803))->item_type_130);
		     }
		     aux_801 = (obj_t) (aux_802);
		  }
		  STRUCT_SET(aux1057_249, ((long) 0), aux_801);
	       }
	       STRUCT_SET(res1056_248, ((long) 0), aux1057_249);
	       {
		  obj_t aux_811;
		  aux_811 = STRUCT_KEY(res1056_248);
		  STRUCT_KEY_SET(aux1057_249, aux_811);
	       }
	       {
		  obj_t aux_814;
		  aux_814 = CNST_TABLE_REF(((long) 5));
		  STRUCT_KEY_SET(res1056_248, aux_814);
	       }
	       return res1056_248;
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tvector_tvector()
{
   module_initialization_70_type_type(((long) 0), "TVECTOR_TVECTOR");
   module_initialization_70_type_env(((long) 0), "TVECTOR_TVECTOR");
   module_initialization_70_tools_error(((long) 0), "TVECTOR_TVECTOR");
   return module_initialization_70_module_module(((long) 0), "TVECTOR_TVECTOR");
}
