/*===========================================================================*/
/*   (Globalize/integration.scm)                                             */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t _g1__181_globalize_globalize;
extern obj_t _e__34_globalize_globalize;
static obj_t method_init_76_globalize_integration();
extern obj_t global_ast_var;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_integration(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_globalize(long, char *);
extern obj_t module_initialization_70_globalize_kapture(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t union_3_globalize_kapture(obj_t);
static obj_t imported_modules_init_94_globalize_integration();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_globalize_integration();
extern obj_t open_input_string(obj_t);
static obj_t get_new_tg_254_globalize_integration(obj_t, obj_t, long);
static obj_t get_new_fg_250_globalize_integration(obj_t, long);
extern obj_t local_ast_var;
static obj_t get_integrator_6_globalize_integration(obj_t);
static obj_t set_integrators__120_globalize_integration(obj_t, obj_t, long);
static obj_t _set_integration__157_globalize_integration(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t set_integration__52_globalize_integration();
static obj_t set_cfrom___159_globalize_integration(local_t);
static obj_t require_initialization_114_globalize_integration = BUNSPEC;
static obj_t cnst_init_137_globalize_integration();
static obj_t __cnst[1];

DEFINE_STRING(string1795_globalize_integration, string1795_globalize_integration1801, "DONE ", 5);
DEFINE_EXPORT_PROCEDURE(set_integration__env_59_globalize_integration, _set_integration__157_globalize_integration1802, _set_integration__157_globalize_integration, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_globalize_integration(long checksum_1769, char *from_1770)
{
   if (CBOOL(require_initialization_114_globalize_integration))
     {
	require_initialization_114_globalize_integration = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_integration();
	cnst_init_137_globalize_integration();
	imported_modules_init_94_globalize_integration();
	method_init_76_globalize_integration();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_integration()
{
   module_initialization_70___object(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_INTEGRATION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_integration()
{
   {
      obj_t cnst_port_138_1761;
      cnst_port_138_1761 = open_input_string(string1795_globalize_integration);
      {
	 long i_1762;
	 i_1762 = ((long) 0);
       loop_1763:
	 {
	    bool_t test1796_1764;
	    test1796_1764 = (i_1762 == ((long) -1));
	    if (test1796_1764)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1797_1765;
		    {
		       obj_t list1798_1766;
		       {
			  obj_t arg1799_1767;
			  arg1799_1767 = BNIL;
			  list1798_1766 = MAKE_PAIR(cnst_port_138_1761, arg1799_1767);
		       }
		       arg1797_1765 = read___reader(list1798_1766);
		    }
		    CNST_TABLE_SET(i_1762, arg1797_1765);
		 }
		 {
		    int aux_1768;
		    {
		       long aux_1787;
		       aux_1787 = (i_1762 - ((long) 1));
		       aux_1768 = (int) (aux_1787);
		    }
		    {
		       long i_1790;
		       i_1790 = (long) (aux_1768);
		       i_1762 = i_1790;
		       goto loop_1763;
		    }
		 }
	      }
	 }
      }
   }
}


/* set-integration! */ obj_t 
set_integration__52_globalize_integration()
{
   {
      obj_t l1557_1000;
      l1557_1000 = _e__34_globalize_globalize;
    lname1558_1001:
      if (PAIRP(l1557_1000))
	{
	   {
	      local_t aux_1794;
	      {
		 obj_t aux_1795;
		 aux_1795 = CAR(l1557_1000);
		 aux_1794 = (local_t) (aux_1795);
	      }
	      set_cfrom___159_globalize_integration(aux_1794);
	   }
	   {
	      obj_t l1557_1799;
	      l1557_1799 = CDR(l1557_1000);
	      l1557_1000 = l1557_1799;
	      goto lname1558_1001;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t l1559_1005;
      l1559_1005 = _g1__181_globalize_globalize;
    lname1560_1006:
      if (PAIRP(l1559_1005))
	{
	   {
	      local_t aux_1803;
	      {
		 obj_t aux_1804;
		 aux_1804 = CAR(l1559_1005);
		 aux_1803 = (local_t) (aux_1804);
	      }
	      set_cfrom___159_globalize_integration(aux_1803);
	   }
	   {
	      obj_t l1559_1808;
	      l1559_1808 = CDR(l1559_1005);
	      l1559_1005 = l1559_1808;
	      goto lname1560_1006;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t tg_1010;
      obj_t fg_1011;
      long round_1012;
      tg_1010 = _e__34_globalize_globalize;
      fg_1011 = _g1__181_globalize_globalize;
      round_1012 = ((long) 0);
    loop_1013:
      {
	 obj_t l1561_1014;
	 l1561_1014 = tg_1010;
       lname1562_1015:
	 if (PAIRP(l1561_1014))
	   {
	      {
		 sfun_ginfo_98_t obj_1541;
		 {
		    value_t aux_1812;
		    {
		       local_t obj_1540;
		       {
			  obj_t aux_1813;
			  aux_1813 = CAR(l1561_1014);
			  obj_1540 = (local_t) (aux_1813);
		       }
		       aux_1812 = (((local_t) CREF(obj_1540))->value);
		    }
		    obj_1541 = (sfun_ginfo_98_t) (aux_1812);
		 }
		 {
		    obj_t aux_1818;
		    {
		       object_t aux_1819;
		       aux_1819 = (object_t) (obj_1541);
		       aux_1818 = OBJECT_WIDENING(aux_1819);
		    }
		    ((((sfun_ginfo_98_t) CREF(aux_1818))->mark) = ((long) round_1012), BUNSPEC);
		 }
	      }
	      {
		 obj_t l1561_1823;
		 l1561_1823 = CDR(l1561_1014);
		 l1561_1014 = l1561_1823;
		 goto lname1562_1015;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      {
	 obj_t new_tg_10_1020;
	 new_tg_10_1020 = get_new_tg_254_globalize_integration(tg_1010, fg_1011, round_1012);
	 if (NULLP(new_tg_10_1020))
	   {
	      return set_integrators__120_globalize_integration(tg_1010, fg_1011, round_1012);
	   }
	 else
	   {
	      obj_t new_fg_180_1022;
	      new_fg_180_1022 = get_new_fg_250_globalize_integration(fg_1011, round_1012);
	      {
		 long round_1833;
		 obj_t fg_1832;
		 obj_t tg_1830;
		 tg_1830 = append_2_18___r4_pairs_and_lists_6_3(new_tg_10_1020, tg_1010);
		 fg_1832 = new_fg_180_1022;
		 round_1833 = (round_1012 + ((long) 1));
		 round_1012 = round_1833;
		 fg_1011 = fg_1832;
		 tg_1010 = tg_1830;
		 goto loop_1013;
	      }
	   }
      }
   }
}


/* _set-integration! */ obj_t 
_set_integration__157_globalize_integration(obj_t env_1760)
{
   return set_integration__52_globalize_integration();
}


/* set-cfrom*! */ obj_t 
set_cfrom___159_globalize_integration(local_t local_1)
{
   {
      value_t info_1025;
      info_1025 = (((local_t) CREF(local_1))->value);
      {
	 bool_t test_1837;
	 {
	    bool_t test_1838;
	    {
	       obj_t aux_1839;
	       {
		  sfun_ginfo_98_t obj_1548;
		  obj_1548 = (sfun_ginfo_98_t) (info_1025);
		  {
		     obj_t aux_1841;
		     {
			object_t aux_1842;
			aux_1842 = (object_t) (obj_1548);
			aux_1841 = OBJECT_WIDENING(aux_1842);
		     }
		     aux_1839 = (((sfun_ginfo_98_t) CREF(aux_1841))->cfrom__119);
		  }
	       }
	       test_1838 = PAIRP(aux_1839);
	    }
	    if (test_1838)
	      {
		 test_1837 = ((bool_t) 1);
	      }
	    else
	      {
		 obj_t aux_1847;
		 {
		    sfun_ginfo_98_t obj_1550;
		    obj_1550 = (sfun_ginfo_98_t) (info_1025);
		    {
		       obj_t aux_1849;
		       {
			  object_t aux_1850;
			  aux_1850 = (object_t) (obj_1550);
			  aux_1849 = OBJECT_WIDENING(aux_1850);
		       }
		       aux_1847 = (((sfun_ginfo_98_t) CREF(aux_1849))->cfrom__119);
		    }
		 }
		 test_1837 = NULLP(aux_1847);
	      }
	 }
	 if (test_1837)
	   {
	      sfun_ginfo_98_t obj_1552;
	      obj_1552 = (sfun_ginfo_98_t) (info_1025);
	      {
		 obj_t aux_1856;
		 {
		    object_t aux_1857;
		    aux_1857 = (object_t) (obj_1552);
		    aux_1856 = OBJECT_WIDENING(aux_1857);
		 }
		 return (((sfun_ginfo_98_t) CREF(aux_1856))->cfrom__119);
	      }
	   }
	 else
	   {
	      {
		 sfun_ginfo_98_t obj_1553;
		 obj_1553 = (sfun_ginfo_98_t) (info_1025);
		 {
		    obj_t aux_1862;
		    {
		       object_t aux_1863;
		       aux_1863 = (object_t) (obj_1553);
		       aux_1862 = OBJECT_WIDENING(aux_1863);
		    }
		    ((((sfun_ginfo_98_t) CREF(aux_1862))->cfrom__119) = ((obj_t) BNIL), BUNSPEC);
		 }
	      }
	      {
		 obj_t cfrom_1028;
		 obj_t cfrom__set_44_1029;
		 obj_t global_1030;
		 {
		    sfun_ginfo_98_t obj_1555;
		    obj_1555 = (sfun_ginfo_98_t) (info_1025);
		    {
		       obj_t aux_1915;
		       {
			  object_t aux_1916;
			  aux_1916 = (object_t) (obj_1555);
			  aux_1915 = OBJECT_WIDENING(aux_1916);
		       }
		       cfrom_1028 = (((sfun_ginfo_98_t) CREF(aux_1915))->cfrom);
		    }
		 }
		 cfrom__set_44_1029 = BNIL;
		 global_1030 = BFALSE;
	       loop_1031:
		 if (NULLP(cfrom_1028))
		   {
		      {
			 obj_t res_1035;
			 {
			    obj_t u_1036;
			    u_1036 = union_3_globalize_kapture(cfrom__set_44_1029);
			    {
			       bool_t test1584_1037;
			       test1584_1037 = is_a__118___object(global_1030, global_ast_var);
			       if (test1584_1037)
				 {
				    res_1035 = MAKE_PAIR(global_1030, u_1036);
				 }
			       else
				 {
				    res_1035 = u_1036;
				 }
			    }
			 }
			 {
			    sfun_ginfo_98_t obj_1560;
			    obj_1560 = (sfun_ginfo_98_t) (info_1025);
			    {
			       obj_t aux_1874;
			       {
				  object_t aux_1875;
				  aux_1875 = (object_t) (obj_1560);
				  aux_1874 = OBJECT_WIDENING(aux_1875);
			       }
			       ((((sfun_ginfo_98_t) CREF(aux_1874))->cfrom__119) = ((obj_t) res_1035), BUNSPEC);
			    }
			 }
			 return res_1035;
		      }
		   }
		 else
		   {
		      bool_t test1585_1038;
		      test1585_1038 = is_a__118___object(CAR(cfrom_1028), global_ast_var);
		      if (test1585_1038)
			{
			   {
			      obj_t global_1884;
			      obj_t cfrom_1882;
			      cfrom_1882 = CDR(cfrom_1028);
			      global_1884 = CAR(cfrom_1028);
			      global_1030 = global_1884;
			      cfrom_1028 = cfrom_1882;
			      goto loop_1031;
			   }
			}
		      else
			{
			   {
			      obj_t cfrom__119_1041;
			      {
				 local_t aux_1886;
				 {
				    obj_t aux_1887;
				    aux_1887 = CAR(cfrom_1028);
				    aux_1886 = (local_t) (aux_1887);
				 }
				 cfrom__119_1041 = set_cfrom___159_globalize_integration(aux_1886);
			      }
			      {
				 bool_t test1588_1042;
				 if (PAIRP(cfrom__119_1041))
				   {
				      test1588_1042 = is_a__118___object(CAR(cfrom__119_1041), global_ast_var);
				   }
				 else
				   {
				      test1588_1042 = ((bool_t) 0);
				   }
				 if (test1588_1042)
				   {
				      obj_t arg1589_1043;
				      obj_t arg1592_1044;
				      obj_t arg1593_1045;
				      arg1589_1043 = CDR(cfrom_1028);
				      {
					 obj_t arg1594_1046;
					 {
					    obj_t aux_1899;
					    obj_t aux_1897;
					    aux_1899 = CDR(cfrom__119_1041);
					    aux_1897 = CAR(cfrom_1028);
					    arg1594_1046 = MAKE_PAIR(aux_1897, aux_1899);
					 }
					 arg1592_1044 = MAKE_PAIR(arg1594_1046, cfrom__set_44_1029);
				      }
				      arg1593_1045 = CAR(cfrom__119_1041);
				      {
					 obj_t global_1906;
					 obj_t cfrom__set_44_1905;
					 obj_t cfrom_1904;
					 cfrom_1904 = arg1589_1043;
					 cfrom__set_44_1905 = arg1592_1044;
					 global_1906 = arg1593_1045;
					 global_1030 = global_1906;
					 cfrom__set_44_1029 = cfrom__set_44_1905;
					 cfrom_1028 = cfrom_1904;
					 goto loop_1031;
				      }
				   }
				 else
				   {
				      obj_t arg1600_1049;
				      obj_t arg1602_1050;
				      arg1600_1049 = CDR(cfrom_1028);
				      {
					 obj_t arg1603_1051;
					 {
					    obj_t aux_1908;
					    aux_1908 = CAR(cfrom_1028);
					    arg1603_1051 = MAKE_PAIR(aux_1908, cfrom__119_1041);
					 }
					 arg1602_1050 = MAKE_PAIR(arg1603_1051, cfrom__set_44_1029);
				      }
				      {
					 obj_t cfrom__set_44_1913;
					 obj_t cfrom_1912;
					 cfrom_1912 = arg1600_1049;
					 cfrom__set_44_1913 = arg1602_1050;
					 cfrom__set_44_1029 = cfrom__set_44_1913;
					 cfrom_1028 = cfrom_1912;
					 goto loop_1031;
				      }
				   }
			      }
			   }
			}
		   }
	      }
	   }
      }
   }
}


/* get-new-tg */ obj_t 
get_new_tg_254_globalize_integration(obj_t tg_2, obj_t fg_3, long round_4)
{
   {
      obj_t new_tg_10_1060;
      obj_t fg_1061;
      new_tg_10_1060 = BNIL;
      fg_1061 = fg_3;
    loop_1062:
      if (NULLP(fg_1061))
	{
	   return new_tg_10_1060;
	}
      else
	{
	   obj_t local_1065;
	   local_1065 = CAR(fg_1061);
	   {
	      obj_t cfrom_1066;
	      long new_1067;
	      {
		 sfun_ginfo_98_t obj_1587;
		 {
		    value_t aux_1982;
		    {
		       local_t obj_1586;
		       obj_1586 = (local_t) (local_1065);
		       aux_1982 = (((local_t) CREF(obj_1586))->value);
		    }
		    obj_1587 = (sfun_ginfo_98_t) (aux_1982);
		 }
		 {
		    obj_t aux_1986;
		    {
		       object_t aux_1987;
		       aux_1987 = (object_t) (obj_1587);
		       aux_1986 = OBJECT_WIDENING(aux_1987);
		    }
		    cfrom_1066 = (((sfun_ginfo_98_t) CREF(aux_1986))->cfrom__119);
		 }
	      }
	      new_1067 = ((long) 0);
	    liip_1068:
	      if (NULLP(cfrom_1066))
		{
		   if ((new_1067 < ((long) 2)))
		     {
			obj_t fg_1927;
			fg_1927 = CDR(fg_1061);
			fg_1061 = fg_1927;
			goto loop_1062;
		     }
		   else
		     {
			{
			   long arg1625_1076;
			   arg1625_1076 = (round_4 - ((long) 1));
			   {
			      sfun_ginfo_98_t obj_1595;
			      {
				 value_t aux_1930;
				 {
				    local_t obj_1592;
				    obj_1592 = (local_t) (local_1065);
				    aux_1930 = (((local_t) CREF(obj_1592))->value);
				 }
				 obj_1595 = (sfun_ginfo_98_t) (aux_1930);
			      }
			      {
				 obj_t aux_1934;
				 {
				    object_t aux_1935;
				    aux_1935 = (object_t) (obj_1595);
				    aux_1934 = OBJECT_WIDENING(aux_1935);
				 }
				 ((((sfun_ginfo_98_t) CREF(aux_1934))->mark) = ((long) arg1625_1076), BUNSPEC);
			      }
			   }
			}
			{
			   obj_t arg1627_1077;
			   obj_t arg1628_1078;
			   arg1627_1077 = MAKE_PAIR(local_1065, new_tg_10_1060);
			   arg1628_1078 = CDR(fg_1061);
			   {
			      obj_t fg_1942;
			      obj_t new_tg_10_1941;
			      new_tg_10_1941 = arg1627_1077;
			      fg_1942 = arg1628_1078;
			      fg_1061 = fg_1942;
			      new_tg_10_1060 = new_tg_10_1941;
			      goto loop_1062;
			   }
			}
		     }
		}
	      else
		{
		   bool_t test1629_1079;
		   test1629_1079 = is_a__118___object(CAR(cfrom_1066), global_ast_var);
		   if (test1629_1079)
		     {
			{
			   long new_1948;
			   obj_t cfrom_1946;
			   cfrom_1946 = CDR(cfrom_1066);
			   new_1948 = (new_1067 + ((long) 1));
			   new_1067 = new_1948;
			   cfrom_1066 = cfrom_1946;
			   goto liip_1068;
			}
		     }
		   else
		     {
			bool_t test_1950;
			{
			   bool_t test_1951;
			   {
			      sfun_ginfo_98_t obj_1607;
			      {
				 value_t aux_1952;
				 {
				    local_t obj_1606;
				    {
				       obj_t aux_1953;
				       aux_1953 = CAR(cfrom_1066);
				       obj_1606 = (local_t) (aux_1953);
				    }
				    aux_1952 = (((local_t) CREF(obj_1606))->value);
				 }
				 obj_1607 = (sfun_ginfo_98_t) (aux_1952);
			      }
			      {
				 obj_t aux_1958;
				 {
				    object_t aux_1959;
				    aux_1959 = (object_t) (obj_1607);
				    aux_1958 = OBJECT_WIDENING(aux_1959);
				 }
				 test_1951 = (((sfun_ginfo_98_t) CREF(aux_1958))->g__219);
			      }
			   }
			   if (test_1951)
			     {
				long aux_1963;
				{
				   sfun_ginfo_98_t obj_1610;
				   {
				      value_t aux_1964;
				      {
					 local_t obj_1609;
					 {
					    obj_t aux_1965;
					    aux_1965 = CAR(cfrom_1066);
					    obj_1609 = (local_t) (aux_1965);
					 }
					 aux_1964 = (((local_t) CREF(obj_1609))->value);
				      }
				      obj_1610 = (sfun_ginfo_98_t) (aux_1964);
				   }
				   {
				      obj_t aux_1970;
				      {
					 object_t aux_1971;
					 aux_1971 = (object_t) (obj_1610);
					 aux_1970 = OBJECT_WIDENING(aux_1971);
				      }
				      aux_1963 = (((sfun_ginfo_98_t) CREF(aux_1970))->mark);
				   }
				}
				test_1950 = (aux_1963 < round_4);
			     }
			   else
			     {
				test_1950 = ((bool_t) 1);
			     }
			}
			if (test_1950)
			  {
			     {
				obj_t cfrom_1976;
				cfrom_1976 = CDR(cfrom_1066);
				cfrom_1066 = cfrom_1976;
				goto liip_1068;
			     }
			  }
			else
			  {
			     {
				long new_1980;
				obj_t cfrom_1978;
				cfrom_1978 = CDR(cfrom_1066);
				new_1980 = (new_1067 + ((long) 1));
				new_1067 = new_1980;
				cfrom_1066 = cfrom_1978;
				goto liip_1068;
			     }
			  }
		     }
		}
	   }
	}
   }
}


/* get-new-fg */ obj_t 
get_new_fg_250_globalize_integration(obj_t fg_5, long round_6)
{
   {
      obj_t old_fg_154_1093;
      obj_t new_fg_180_1094;
      old_fg_154_1093 = fg_5;
      new_fg_180_1094 = BNIL;
    loop_1095:
      if (NULLP(old_fg_154_1093))
	{
	   return new_fg_180_1094;
	}
      else
	{
	   bool_t test_1993;
	   {
	      long aux_2006;
	      long aux_1994;
	      aux_2006 = (round_6 - ((long) 1));
	      {
		 sfun_ginfo_98_t obj_1620;
		 {
		    value_t aux_1995;
		    {
		       local_t obj_1619;
		       {
			  obj_t aux_1996;
			  aux_1996 = CAR(old_fg_154_1093);
			  obj_1619 = (local_t) (aux_1996);
		       }
		       aux_1995 = (((local_t) CREF(obj_1619))->value);
		    }
		    obj_1620 = (sfun_ginfo_98_t) (aux_1995);
		 }
		 {
		    obj_t aux_2001;
		    {
		       object_t aux_2002;
		       aux_2002 = (object_t) (obj_1620);
		       aux_2001 = OBJECT_WIDENING(aux_2002);
		    }
		    aux_1994 = (((sfun_ginfo_98_t) CREF(aux_2001))->mark);
		 }
	      }
	      test_1993 = (aux_1994 == aux_2006);
	   }
	   if (test_1993)
	     {
		{
		   obj_t old_fg_154_2009;
		   old_fg_154_2009 = CDR(old_fg_154_1093);
		   old_fg_154_1093 = old_fg_154_2009;
		   goto loop_1095;
		}
	     }
	   else
	     {
		{
		   obj_t arg1653_1100;
		   obj_t arg1654_1101;
		   arg1653_1100 = CDR(old_fg_154_1093);
		   {
		      obj_t aux_2012;
		      aux_2012 = CAR(old_fg_154_1093);
		      arg1654_1101 = MAKE_PAIR(aux_2012, new_fg_180_1094);
		   }
		   {
		      obj_t new_fg_180_2016;
		      obj_t old_fg_154_2015;
		      old_fg_154_2015 = arg1653_1100;
		      new_fg_180_2016 = arg1654_1101;
		      new_fg_180_1094 = new_fg_180_2016;
		      old_fg_154_1093 = old_fg_154_2015;
		      goto loop_1095;
		   }
		}
	     }
	}
   }
}


/* set-integrators! */ obj_t 
set_integrators__120_globalize_integration(obj_t tg_7, obj_t fg_8, long round_9)
{
   {
      obj_t roots_1107;
      roots_1107 = tg_7;
    loop_1108:
      if (NULLP(roots_1107))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   obj_t roots_1110;
	   obj_t new_roots_207_1111;
	   roots_1110 = roots_1107;
	   new_roots_207_1111 = BNIL;
	 liip_1112:
	   if (NULLP(roots_1110))
	     {
		obj_t roots_2022;
		roots_2022 = new_roots_207_1111;
		roots_1107 = roots_2022;
		goto loop_1108;
	     }
	   else
	     {
		obj_t root_1115;
		root_1115 = CAR(roots_1110);
		{
		   obj_t cto_1116;
		   obj_t new_1117;
		   {
		      sfun_ginfo_98_t obj_1634;
		      {
			 value_t aux_2099;
			 {
			    local_t obj_1633;
			    obj_1633 = (local_t) (root_1115);
			    aux_2099 = (((local_t) CREF(obj_1633))->value);
			 }
			 obj_1634 = (sfun_ginfo_98_t) (aux_2099);
		      }
		      {
			 obj_t aux_2103;
			 {
			    object_t aux_2104;
			    aux_2104 = (object_t) (obj_1634);
			    aux_2103 = OBJECT_WIDENING(aux_2104);
			 }
			 cto_1116 = (((sfun_ginfo_98_t) CREF(aux_2103))->cto);
		      }
		   }
		   new_1117 = new_roots_207_1111;
		 laap_1118:
		   if (NULLP(cto_1116))
		     {
			obj_t new_roots_207_2028;
			obj_t roots_2026;
			roots_2026 = CDR(roots_1110);
			new_roots_207_2028 = new_1117;
			new_roots_207_1111 = new_roots_207_2028;
			roots_1110 = roots_2026;
			goto liip_1112;
		     }
		   else
		     {
			obj_t to_1123;
			to_1123 = CAR(cto_1116);
			{
			   value_t info_1124;
			   {
			      local_t obj_1638;
			      obj_1638 = (local_t) (to_1123);
			      info_1124 = (((local_t) CREF(obj_1638))->value);
			   }
			   {
			      {
				 bool_t test_2032;
				 {
				    sfun_ginfo_98_t obj_1639;
				    obj_1639 = (sfun_ginfo_98_t) (info_1124);
				    {
				       obj_t aux_2034;
				       {
					  object_t aux_2035;
					  aux_2035 = (object_t) (obj_1639);
					  aux_2034 = OBJECT_WIDENING(aux_2035);
				       }
				       test_2032 = (((sfun_ginfo_98_t) CREF(aux_2034))->g__219);
				    }
				 }
				 if (test_2032)
				   {
				      bool_t test_2039;
				      {
					 long aux_2040;
					 {
					    sfun_ginfo_98_t obj_1640;
					    obj_1640 = (sfun_ginfo_98_t) (info_1124);
					    {
					       obj_t aux_2042;
					       {
						  object_t aux_2043;
						  aux_2043 = (object_t) (obj_1640);
						  aux_2042 = OBJECT_WIDENING(aux_2043);
					       }
					       aux_2040 = (((sfun_ginfo_98_t) CREF(aux_2042))->mark);
					    }
					 }
					 test_2039 = (aux_2040 == round_9);
				      }
				      if (test_2039)
					{
					   {
					      obj_t cto_2048;
					      cto_2048 = CDR(cto_1116);
					      cto_1116 = cto_2048;
					      goto laap_1118;
					   }
					}
				      else
					{
					   bool_t test1671_1128;
					   {
					      obj_t aux_2050;
					      {
						 sfun_ginfo_98_t obj_1644;
						 obj_1644 = (sfun_ginfo_98_t) (info_1124);
						 {
						    obj_t aux_2052;
						    {
						       object_t aux_2053;
						       aux_2053 = (object_t) (obj_1644);
						       aux_2052 = OBJECT_WIDENING(aux_2053);
						    }
						    aux_2050 = (((sfun_ginfo_98_t) CREF(aux_2052))->integrator);
						 }
					      }
					      test1671_1128 = is_a__118___object(aux_2050, local_ast_var);
					   }
					   if (test1671_1128)
					     {
						{
						   obj_t cto_2059;
						   cto_2059 = CDR(cto_1116);
						   cto_1116 = cto_2059;
						   goto laap_1118;
						}
					     }
					   else
					     {
						{
						   sfun_ginfo_98_t obj_1647;
						   obj_1647 = (sfun_ginfo_98_t) (info_1124);
						   {
						      obj_t aux_2062;
						      {
							 object_t aux_2063;
							 aux_2063 = (object_t) (obj_1647);
							 aux_2062 = OBJECT_WIDENING(aux_2063);
						      }
						      ((((sfun_ginfo_98_t) CREF(aux_2062))->g__219) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						   }
						}
						{
						   obj_t integrator_1130;
						   integrator_1130 = get_integrator_6_globalize_integration(root_1115);
						   {
						      sfun_ginfo_98_t obj_1649;
						      obj_1649 = (sfun_ginfo_98_t) (info_1124);
						      {
							 obj_t aux_2069;
							 {
							    object_t aux_2070;
							    aux_2070 = (object_t) (obj_1649);
							    aux_2069 = OBJECT_WIDENING(aux_2070);
							 }
							 ((((sfun_ginfo_98_t) CREF(aux_2069))->integrator) = ((obj_t) integrator_1130), BUNSPEC);
						      }
						   }
						   {
						      value_t arg1673_1131;
						      obj_t arg1675_1132;
						      {
							 local_t obj_1651;
							 obj_1651 = (local_t) (integrator_1130);
							 arg1673_1131 = (((local_t) CREF(obj_1651))->value);
						      }
						      {
							 obj_t aux_2076;
							 {
							    sfun_ginfo_98_t obj_1653;
							    {
							       value_t aux_2077;
							       {
								  local_t obj_1652;
								  obj_1652 = (local_t) (integrator_1130);
								  aux_2077 = (((local_t) CREF(obj_1652))->value);
							       }
							       obj_1653 = (sfun_ginfo_98_t) (aux_2077);
							    }
							    {
							       obj_t aux_2081;
							       {
								  object_t aux_2082;
								  aux_2082 = (object_t) (obj_1653);
								  aux_2081 = OBJECT_WIDENING(aux_2082);
							       }
							       aux_2076 = (((sfun_ginfo_98_t) CREF(aux_2081))->integrated);
							    }
							 }
							 arg1675_1132 = MAKE_PAIR(to_1123, aux_2076);
						      }
						      {
							 sfun_ginfo_98_t obj_1656;
							 obj_1656 = (sfun_ginfo_98_t) (arg1673_1131);
							 {
							    obj_t aux_2088;
							    {
							       object_t aux_2089;
							       aux_2089 = (object_t) (obj_1656);
							       aux_2088 = OBJECT_WIDENING(aux_2089);
							    }
							    ((((sfun_ginfo_98_t) CREF(aux_2088))->integrated) = ((obj_t) arg1675_1132), BUNSPEC);
							 }
						      }
						   }
						}
						{
						   obj_t arg1678_1135;
						   obj_t arg1679_1136;
						   arg1678_1135 = CDR(cto_1116);
						   arg1679_1136 = MAKE_PAIR(to_1123, new_1117);
						   {
						      obj_t new_2096;
						      obj_t cto_2095;
						      cto_2095 = arg1678_1135;
						      new_2096 = arg1679_1136;
						      new_1117 = new_2096;
						      cto_1116 = cto_2095;
						      goto laap_1118;
						   }
						}
					     }
					}
				   }
				 else
				   {
				      {
					 obj_t cto_2097;
					 cto_2097 = CDR(cto_1116);
					 cto_1116 = cto_2097;
					 goto laap_1118;
				      }
				   }
			      }
			   }
			}
		     }
		}
	     }
	}
   }
}


/* get-integrator */ obj_t 
get_integrator_6_globalize_integration(obj_t local_10)
{
   {
      bool_t test_2108;
      {
	 sfun_ginfo_98_t obj_1663;
	 {
	    value_t aux_2109;
	    {
	       local_t obj_1662;
	       obj_1662 = (local_t) (local_10);
	       aux_2109 = (((local_t) CREF(obj_1662))->value);
	    }
	    obj_1663 = (sfun_ginfo_98_t) (aux_2109);
	 }
	 {
	    obj_t aux_2113;
	    {
	       object_t aux_2114;
	       aux_2114 = (object_t) (obj_1663);
	       aux_2113 = OBJECT_WIDENING(aux_2114);
	    }
	    test_2108 = (((sfun_ginfo_98_t) CREF(aux_2113))->g__219);
	 }
      }
      if (test_2108)
	{
	   return local_10;
	}
      else
	{
	   sfun_ginfo_98_t obj_1665;
	   {
	      value_t aux_2118;
	      {
		 local_t obj_1664;
		 obj_1664 = (local_t) (local_10);
		 aux_2118 = (((local_t) CREF(obj_1664))->value);
	      }
	      obj_1665 = (sfun_ginfo_98_t) (aux_2118);
	   }
	   {
	      obj_t aux_2122;
	      {
		 object_t aux_2123;
		 aux_2123 = (object_t) (obj_1665);
		 aux_2122 = OBJECT_WIDENING(aux_2123);
	      }
	      return (((sfun_ginfo_98_t) CREF(aux_2122))->integrator);
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_globalize_integration()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_integration()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_INTEGRATION");
   module_initialization_70_globalize_globalize(((long) 0), "GLOBALIZE_INTEGRATION");
   return module_initialization_70_globalize_kapture(((long) 0), "GLOBALIZE_INTEGRATION");
}
