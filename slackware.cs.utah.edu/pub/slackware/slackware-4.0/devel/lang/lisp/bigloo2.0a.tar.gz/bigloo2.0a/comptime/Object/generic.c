/*===========================================================================*/
/*   (Object/generic.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_object_generic();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t type_type_type;
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
static obj_t make_generic_non_inlined_body_250_object_generic(obj_t, obj_t, obj_t, obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t make_generic_inlined_body_246_object_generic(obj_t, obj_t, obj_t, obj_t);
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_object_generic(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_inline(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern bool_t method_inlining_enabled__91_object_inline();
static obj_t imported_modules_init_94_object_generic();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_object_generic();
extern obj_t open_input_string(obj_t);
extern int arity_tools_args(obj_t);
extern obj_t class_object_class;
extern obj_t parse_id_241_ast_ident(obj_t);
extern obj_t _module__166_module_module;
static obj_t _make_generic_body_173_object_generic(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_generic_body_233_object_generic(obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_object_generic = BUNSPEC;
static obj_t cnst_init_137_object_generic();
static obj_t __cnst[14];

DEFINE_EXPORT_PROCEDURE(make_generic_body_env_40_object_generic, _make_generic_body_173_object_generic1597, _make_generic_body_173_object_generic, 0L, 4);
DEFINE_STRING(string1591_object_generic, string1591_object_generic1598, "OBJECT? LAMBDA (QUOTE GENERIC-DEFINITION-ERROR) PROCEDURE? IF FIND-METHOD LET -DEFAULT METHOD __R4_PAIRS_AND_LISTS_6_3 CONS* APPLY @ GENERIC-DEFAULT ", 149);
DEFINE_STRING(string1589_object_generic, string1589_object_generic1599, "Illegal generic definition (no formal arguments provided)", 57);
DEFINE_STRING(string1590_object_generic, string1590_object_generic1600, "generic function has a non-class dispatching type arg", 53);


/* module-initialization */ obj_t 
module_initialization_70_object_generic(long checksum_918, char *from_919)
{
   if (CBOOL(require_initialization_114_object_generic))
     {
	require_initialization_114_object_generic = BBOOL(((bool_t) 0));
	library_modules_init_112_object_generic();
	cnst_init_137_object_generic();
	imported_modules_init_94_object_generic();
	method_init_76_object_generic();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_generic()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_GENERIC");
   module_initialization_70___object(((long) 0), "OBJECT_GENERIC");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_GENERIC");
   module_initialization_70___reader(((long) 0), "OBJECT_GENERIC");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_generic()
{
   {
      obj_t cnst_port_138_910;
      cnst_port_138_910 = open_input_string(string1591_object_generic);
      {
	 long i_911;
	 i_911 = ((long) 13);
       loop_912:
	 {
	    bool_t test1592_913;
	    test1592_913 = (i_911 == ((long) -1));
	    if (test1592_913)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1593_914;
		    {
		       obj_t list1594_915;
		       {
			  obj_t arg1595_916;
			  arg1595_916 = BNIL;
			  list1594_915 = MAKE_PAIR(cnst_port_138_910, arg1595_916);
		       }
		       arg1593_914 = read___reader(list1594_915);
		    }
		    CNST_TABLE_SET(i_911, arg1593_914);
		 }
		 {
		    int aux_917;
		    {
		       long aux_937;
		       aux_937 = (i_911 - ((long) 1));
		       aux_917 = (int) (aux_937);
		    }
		    {
		       long i_940;
		       i_940 = (long) (aux_917);
		       i_911 = i_940;
		       goto loop_912;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-generic-body */ obj_t 
make_generic_body_233_object_generic(obj_t id_1, obj_t locals_2, obj_t args_3, obj_t src_4)
{
   {
      bool_t test1227_833;
      test1227_833 = method_inlining_enabled__91_object_inline();
      if (test1227_833)
	{
	   return make_generic_inlined_body_246_object_generic(id_1, locals_2, args_3, src_4);
	}
      else
	{
	   return make_generic_non_inlined_body_250_object_generic(id_1, locals_2, args_3, src_4);
	}
   }
}


/* _make-generic-body */ obj_t 
_make_generic_body_173_object_generic(obj_t env_905, obj_t id_906, obj_t locals_907, obj_t args_908, obj_t src_909)
{
   return make_generic_body_233_object_generic(id_906, locals_907, args_908, src_909);
}


/* make-generic-non-inlined-body */ obj_t 
make_generic_non_inlined_body_250_object_generic(obj_t id_5, obj_t locals_6, obj_t args_7, obj_t src_8)
{
   if (NULLP(args_7))
     {
	obj_t list1233_402;
	list1233_402 = MAKE_PAIR(BNIL, BNIL);
	return user_error_151_tools_error(id_5, string1589_object_generic, src_8, list1233_402);
     }
   else
     {
	obj_t pid_404;
	pid_404 = parse_id_241_ast_ident(id_5);
	{
	   obj_t id_405;
	   id_405 = CAR(pid_404);
	   {
	      int arity_406;
	      arity_406 = arity_tools_args(args_7);
	      {
		 obj_t args_id_103_407;
		 if (NULLP(locals_6))
		   {
		      args_id_103_407 = BNIL;
		   }
		 else
		   {
		      obj_t head1219_601;
		      {
			 obj_t aux_956;
			 {
			    local_t obj_838;
			    {
			       obj_t aux_957;
			       aux_957 = CAR(locals_6);
			       obj_838 = (local_t) (aux_957);
			    }
			    aux_956 = (((local_t) CREF(obj_838))->id);
			 }
			 head1219_601 = MAKE_PAIR(aux_956, BNIL);
		      }
		      {
			 obj_t l1217_602;
			 obj_t tail1220_603;
			 l1217_602 = CDR(locals_6);
			 tail1220_603 = head1219_601;
		       lname1218_604:
			 if (NULLP(l1217_602))
			   {
			      args_id_103_407 = head1219_601;
			   }
			 else
			   {
			      obj_t newtail1221_607;
			      {
				 obj_t aux_964;
				 {
				    local_t obj_844;
				    {
				       obj_t aux_965;
				       aux_965 = CAR(l1217_602);
				       obj_844 = (local_t) (aux_965);
				    }
				    aux_964 = (((local_t) CREF(obj_844))->id);
				 }
				 newtail1221_607 = MAKE_PAIR(aux_964, BNIL);
			      }
			      SET_CDR(tail1220_603, newtail1221_607);
			      {
				 obj_t tail1220_973;
				 obj_t l1217_971;
				 l1217_971 = CDR(l1217_602);
				 tail1220_973 = newtail1221_607;
				 tail1220_603 = tail1220_973;
				 l1217_602 = l1217_971;
				 goto lname1218_604;
			      }
			   }
		      }
		   }
		 {
		    obj_t default_body_201_408;
		    {
		       bool_t test_975;
		       {
			  long aux_976;
			  aux_976 = (long) (arity_406);
			  test_975 = (aux_976 >= ((long) 0));
		       }
		       if (test_975)
			 {
			    obj_t arg1399_545;
			    obj_t arg1401_546;
			    {
			       obj_t arg1405_549;
			       obj_t arg1407_550;
			       arg1405_549 = CNST_TABLE_REF(((long) 0));
			       {
				  obj_t arg1413_555;
				  arg1413_555 = CNST_TABLE_REF(((long) 1));
				  {
				     obj_t list1415_557;
				     {
					obj_t arg1416_558;
					{
					   obj_t arg1417_559;
					   arg1417_559 = MAKE_PAIR(BNIL, BNIL);
					   arg1416_558 = MAKE_PAIR(_module__166_module_module, arg1417_559);
					}
					list1415_557 = MAKE_PAIR(id_405, arg1416_558);
				     }
				     arg1407_550 = cons__138___r4_pairs_and_lists_6_3(arg1413_555, list1415_557);
				  }
			       }
			       {
				  obj_t list1409_552;
				  {
				     obj_t arg1410_553;
				     arg1410_553 = MAKE_PAIR(BNIL, BNIL);
				     list1409_552 = MAKE_PAIR(arg1407_550, arg1410_553);
				  }
				  arg1399_545 = cons__138___r4_pairs_and_lists_6_3(arg1405_549, list1409_552);
			       }
			    }
			    {
			       obj_t arg1419_561;
			       arg1419_561 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			       arg1401_546 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_407, arg1419_561);
			    }
			    {
			       obj_t list1402_547;
			       list1402_547 = MAKE_PAIR(arg1401_546, BNIL);
			       default_body_201_408 = cons__138___r4_pairs_and_lists_6_3(arg1399_545, list1402_547);
			    }
			 }
		       else
			 {
			    obj_t arg1423_564;
			    obj_t arg1426_565;
			    obj_t arg1427_566;
			    arg1423_564 = CNST_TABLE_REF(((long) 2));
			    {
			       obj_t arg1436_572;
			       obj_t arg1437_573;
			       arg1436_572 = CNST_TABLE_REF(((long) 0));
			       {
				  obj_t arg1443_578;
				  arg1443_578 = CNST_TABLE_REF(((long) 1));
				  {
				     obj_t list1445_580;
				     {
					obj_t arg1446_581;
					{
					   obj_t arg1448_582;
					   arg1448_582 = MAKE_PAIR(BNIL, BNIL);
					   arg1446_581 = MAKE_PAIR(_module__166_module_module, arg1448_582);
					}
					list1445_580 = MAKE_PAIR(id_405, arg1446_581);
				     }
				     arg1437_573 = cons__138___r4_pairs_and_lists_6_3(arg1443_578, list1445_580);
				  }
			       }
			       {
				  obj_t list1439_575;
				  {
				     obj_t arg1440_576;
				     arg1440_576 = MAKE_PAIR(BNIL, BNIL);
				     list1439_575 = MAKE_PAIR(arg1437_573, arg1440_576);
				  }
				  arg1426_565 = cons__138___r4_pairs_and_lists_6_3(arg1436_572, list1439_575);
			       }
			    }
			    {
			       obj_t arg1450_584;
			       obj_t arg1453_585;
			       {
				  obj_t arg1456_588;
				  obj_t arg1458_589;
				  obj_t arg1460_590;
				  arg1456_588 = CNST_TABLE_REF(((long) 1));
				  arg1458_589 = CNST_TABLE_REF(((long) 3));
				  arg1460_590 = CNST_TABLE_REF(((long) 4));
				  {
				     obj_t list1462_592;
				     {
					obj_t arg1463_593;
					{
					   obj_t arg1464_594;
					   arg1464_594 = MAKE_PAIR(BNIL, BNIL);
					   arg1463_593 = MAKE_PAIR(arg1460_590, arg1464_594);
					}
					list1462_592 = MAKE_PAIR(arg1458_589, arg1463_593);
				     }
				     arg1450_584 = cons__138___r4_pairs_and_lists_6_3(arg1456_588, list1462_592);
				  }
			       }
			       {
				  obj_t arg1466_596;
				  arg1466_596 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				  arg1453_585 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_407, arg1466_596);
			       }
			       {
				  obj_t list1454_586;
				  list1454_586 = MAKE_PAIR(arg1453_585, BNIL);
				  arg1427_566 = cons__138___r4_pairs_and_lists_6_3(arg1450_584, list1454_586);
			       }
			    }
			    {
			       obj_t list1429_568;
			       {
				  obj_t arg1431_569;
				  {
				     obj_t arg1432_570;
				     arg1432_570 = MAKE_PAIR(BNIL, BNIL);
				     arg1431_569 = MAKE_PAIR(arg1427_566, arg1432_570);
				  }
				  list1429_568 = MAKE_PAIR(arg1426_565, arg1431_569);
			       }
			       default_body_201_408 = cons__138___r4_pairs_and_lists_6_3(arg1423_564, list1429_568);
			    }
			 }
		    }
		    {
		       obj_t method_arg_150_409;
		       method_arg_150_409 = CAR(locals_6);
		       {
			  obj_t method_arg_id_251_410;
			  {
			     local_t obj_853;
			     obj_853 = (local_t) (method_arg_150_409);
			     method_arg_id_251_410 = (((local_t) CREF(obj_853))->id);
			  }
			  {
			     type_t method_arg_type_249_411;
			     {
				local_t obj_854;
				obj_854 = (local_t) (method_arg_150_409);
				method_arg_type_249_411 = (((local_t) CREF(obj_854))->type);
			     }
			     {
				obj_t method_412;
				method_412 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
				{
				   obj_t default_name_11_413;
				   {
				      obj_t arg1391_538;
				      {
					 obj_t list1393_540;
					 {
					    obj_t arg1395_541;
					    {
					       obj_t aux_1025;
					       aux_1025 = CNST_TABLE_REF(((long) 6));
					       arg1395_541 = MAKE_PAIR(aux_1025, BNIL);
					    }
					    list1393_540 = MAKE_PAIR(id_405, arg1395_541);
					 }
					 arg1391_538 = symbol_append_197___r4_symbols_6_4(list1393_540);
				      }
				      default_name_11_413 = mark_symbol_non_user__17_ast_ident(arg1391_538);
				   }
				   {
				      obj_t method_name_182_414;
				      method_name_182_414 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
				      {
					 obj_t app_ly_method_58_415;
					 {
					    obj_t arg1296_468;
					    obj_t arg1297_469;
					    obj_t arg1298_470;
					    arg1296_468 = CNST_TABLE_REF(((long) 7));
					    {
					       obj_t arg1304_476;
					       {
						  obj_t arg1310_480;
						  {
						     obj_t arg1316_485;
						     obj_t arg1319_486;
						     arg1316_485 = CNST_TABLE_REF(((long) 8));
						     {
							obj_t arg1326_492;
							arg1326_492 = CNST_TABLE_REF(((long) 1));
							{
							   obj_t list1329_494;
							   {
							      obj_t arg1330_495;
							      {
								 obj_t arg1331_496;
								 arg1331_496 = MAKE_PAIR(BNIL, BNIL);
								 arg1330_495 = MAKE_PAIR(_module__166_module_module, arg1331_496);
							      }
							      list1329_494 = MAKE_PAIR(id_405, arg1330_495);
							   }
							   arg1319_486 = cons__138___r4_pairs_and_lists_6_3(arg1326_492, list1329_494);
							}
						     }
						     {
							obj_t list1322_488;
							{
							   obj_t arg1323_489;
							   {
							      obj_t arg1324_490;
							      arg1324_490 = MAKE_PAIR(BNIL, BNIL);
							      arg1323_489 = MAKE_PAIR(arg1319_486, arg1324_490);
							   }
							   list1322_488 = MAKE_PAIR(method_arg_id_251_410, arg1323_489);
							}
							arg1310_480 = cons__138___r4_pairs_and_lists_6_3(arg1316_485, list1322_488);
						     }
						  }
						  {
						     obj_t list1312_482;
						     {
							obj_t arg1313_483;
							arg1313_483 = MAKE_PAIR(BNIL, BNIL);
							list1312_482 = MAKE_PAIR(arg1310_480, arg1313_483);
						     }
						     arg1304_476 = cons__138___r4_pairs_and_lists_6_3(method_412, list1312_482);
						  }
					       }
					       {
						  obj_t list1308_478;
						  list1308_478 = MAKE_PAIR(BNIL, BNIL);
						  arg1297_469 = cons__138___r4_pairs_and_lists_6_3(arg1304_476, list1308_478);
					       }
					    }
					    {
					       obj_t arg1333_498;
					       obj_t arg1334_499;
					       obj_t arg1337_500;
					       obj_t arg1339_501;
					       arg1333_498 = CNST_TABLE_REF(((long) 9));
					       {
						  obj_t arg1347_508;
						  arg1347_508 = CNST_TABLE_REF(((long) 10));
						  {
						     obj_t list1350_510;
						     {
							obj_t arg1351_511;
							arg1351_511 = MAKE_PAIR(BNIL, BNIL);
							list1350_510 = MAKE_PAIR(method_412, arg1351_511);
						     }
						     arg1334_499 = cons__138___r4_pairs_and_lists_6_3(arg1347_508, list1350_510);
						  }
					       }
					       {
						  bool_t test_1055;
						  {
						     long aux_1056;
						     aux_1056 = (long) (arity_406);
						     test_1055 = (aux_1056 >= ((long) 0));
						  }
						  if (test_1055)
						    {
						       obj_t arg1355_514;
						       {
							  obj_t arg1361_517;
							  arg1361_517 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							  arg1355_514 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_407, arg1361_517);
						       }
						       {
							  obj_t list1356_515;
							  list1356_515 = MAKE_PAIR(arg1355_514, BNIL);
							  arg1337_500 = cons__138___r4_pairs_and_lists_6_3(method_412, list1356_515);
						       }
						    }
						  else
						    {
						       obj_t arg1365_520;
						       obj_t arg1367_521;
						       arg1365_520 = CNST_TABLE_REF(((long) 2));
						       {
							  obj_t arg1375_527;
							  obj_t arg1378_528;
							  arg1375_527 = CNST_TABLE_REF(((long) 3));
							  {
							     obj_t arg1383_531;
							     arg1383_531 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							     arg1378_528 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_407, arg1383_531);
							  }
							  {
							     obj_t list1379_529;
							     list1379_529 = MAKE_PAIR(arg1378_528, BNIL);
							     arg1367_521 = cons__138___r4_pairs_and_lists_6_3(arg1375_527, list1379_529);
							  }
						       }
						       {
							  obj_t list1369_523;
							  {
							     obj_t arg1370_524;
							     {
								obj_t arg1372_525;
								arg1372_525 = MAKE_PAIR(BNIL, BNIL);
								arg1370_524 = MAKE_PAIR(arg1367_521, arg1372_525);
							     }
							     list1369_523 = MAKE_PAIR(method_412, arg1370_524);
							  }
							  arg1337_500 = cons__138___r4_pairs_and_lists_6_3(arg1365_520, list1369_523);
						       }
						    }
					       }
					       {
						  obj_t list1388_535;
						  list1388_535 = MAKE_PAIR(BNIL, BNIL);
						  arg1339_501 = cons__138___r4_pairs_and_lists_6_3(default_name_11_413, list1388_535);
					       }
					       {
						  obj_t list1341_503;
						  {
						     obj_t arg1342_504;
						     {
							obj_t arg1343_505;
							{
							   obj_t arg1344_506;
							   arg1344_506 = MAKE_PAIR(BNIL, BNIL);
							   arg1343_505 = MAKE_PAIR(arg1339_501, arg1344_506);
							}
							arg1342_504 = MAKE_PAIR(arg1337_500, arg1343_505);
						     }
						     list1341_503 = MAKE_PAIR(arg1334_499, arg1342_504);
						  }
						  arg1298_470 = cons__138___r4_pairs_and_lists_6_3(arg1333_498, list1341_503);
					       }
					    }
					    {
					       obj_t list1300_472;
					       {
						  obj_t arg1301_473;
						  {
						     obj_t arg1302_474;
						     arg1302_474 = MAKE_PAIR(BNIL, BNIL);
						     arg1301_473 = MAKE_PAIR(arg1298_470, arg1302_474);
						  }
						  list1300_472 = MAKE_PAIR(arg1297_469, arg1301_473);
					       }
					       app_ly_method_58_415 = cons__138___r4_pairs_and_lists_6_3(arg1296_468, list1300_472);
					    }
					 }
					 {
					    {
					       bool_t test1235_416;
					       {
						  bool_t test1291_463;
						  test1291_463 = is_a__118___object((obj_t) (method_arg_type_249_411), type_type_type);
						  if (test1291_463)
						    {
						       bool_t test1292_464;
						       {
							  obj_t obj2_859;
							  obj2_859 = _obj__252_type_cache;
							  {
							     obj_t aux_1087;
							     aux_1087 = (obj_t) (method_arg_type_249_411);
							     test1292_464 = (aux_1087 == obj2_859);
							  }
						       }
						       if (test1292_464)
							 {
							    test1235_416 = ((bool_t) 0);
							 }
						       else
							 {
							    bool_t test1293_465;
							    {
							       type_t arg1295_467;
							       arg1295_467 = get_default_type_181_type_cache();
							       {
								  obj_t aux_1094;
								  obj_t aux_1092;
								  aux_1094 = (obj_t) (arg1295_467);
								  aux_1092 = (obj_t) (method_arg_type_249_411);
								  test1293_465 = (aux_1092 == aux_1094);
							       }
							    }
							    if (test1293_465)
							      {
								 test1235_416 = ((bool_t) 0);
							      }
							    else
							      {
								 bool_t test1294_466;
								 test1294_466 = is_a__118___object((obj_t) (method_arg_type_249_411), class_object_class);
								 if (test1294_466)
								   {
								      test1235_416 = ((bool_t) 0);
								   }
								 else
								   {
								      test1235_416 = ((bool_t) 1);
								   }
							      }
							 }
						    }
						  else
						    {
						       test1235_416 = ((bool_t) 0);
						    }
					       }
					       if (test1235_416)
						 {
						    obj_t list1239_419;
						    {
						       obj_t aux_1102;
						       aux_1102 = CNST_TABLE_REF(((long) 11));
						       list1239_419 = MAKE_PAIR(aux_1102, BNIL);
						    }
						    return user_error_151_tools_error(id_405, string1590_object_generic, src_8, list1239_419);
						 }
					       else
						 {
						    obj_t arg1241_421;
						    obj_t arg1243_422;
						    obj_t arg1244_423;
						    arg1241_421 = CNST_TABLE_REF(((long) 7));
						    {
						       obj_t arg1251_429;
						       {
							  obj_t arg1255_433;
							  {
							     obj_t arg1260_438;
							     arg1260_438 = CNST_TABLE_REF(((long) 12));
							     {
								obj_t list1264_441;
								{
								   obj_t arg1265_442;
								   {
								      obj_t arg1267_443;
								      arg1267_443 = MAKE_PAIR(BNIL, BNIL);
								      arg1265_442 = MAKE_PAIR(default_body_201_408, arg1267_443);
								   }
								   list1264_441 = MAKE_PAIR(BNIL, arg1265_442);
								}
								arg1255_433 = cons__138___r4_pairs_and_lists_6_3(arg1260_438, list1264_441);
							     }
							  }
							  {
							     obj_t list1257_435;
							     {
								obj_t arg1258_436;
								arg1258_436 = MAKE_PAIR(BNIL, BNIL);
								list1257_435 = MAKE_PAIR(arg1255_433, arg1258_436);
							     }
							     arg1251_429 = cons__138___r4_pairs_and_lists_6_3(default_name_11_413, list1257_435);
							  }
						       }
						       {
							  obj_t list1253_431;
							  list1253_431 = MAKE_PAIR(BNIL, BNIL);
							  arg1243_422 = cons__138___r4_pairs_and_lists_6_3(arg1251_429, list1253_431);
						       }
						    }
						    {
						       bool_t test1269_445;
						       test1269_445 = is_a__118___object((obj_t) (method_arg_type_249_411), class_object_class);
						       if (test1269_445)
							 {
							    arg1244_423 = app_ly_method_58_415;
							 }
						       else
							 {
							    obj_t arg1270_446;
							    obj_t arg1272_447;
							    obj_t arg1273_448;
							    arg1270_446 = CNST_TABLE_REF(((long) 9));
							    {
							       obj_t arg1283_455;
							       arg1283_455 = CNST_TABLE_REF(((long) 13));
							       {
								  obj_t list1285_457;
								  {
								     obj_t arg1286_458;
								     arg1286_458 = MAKE_PAIR(BNIL, BNIL);
								     list1285_457 = MAKE_PAIR(method_arg_id_251_410, arg1286_458);
								  }
								  arg1272_447 = cons__138___r4_pairs_and_lists_6_3(arg1283_455, list1285_457);
							       }
							    }
							    {
							       obj_t list1289_461;
							       list1289_461 = MAKE_PAIR(BNIL, BNIL);
							       arg1273_448 = cons__138___r4_pairs_and_lists_6_3(default_name_11_413, list1289_461);
							    }
							    {
							       obj_t list1275_450;
							       {
								  obj_t arg1277_451;
								  {
								     obj_t arg1278_452;
								     {
									obj_t arg1281_453;
									arg1281_453 = MAKE_PAIR(BNIL, BNIL);
									arg1278_452 = MAKE_PAIR(arg1273_448, arg1281_453);
								     }
								     arg1277_451 = MAKE_PAIR(app_ly_method_58_415, arg1278_452);
								  }
								  list1275_450 = MAKE_PAIR(arg1272_447, arg1277_451);
							       }
							       arg1244_423 = cons__138___r4_pairs_and_lists_6_3(arg1270_446, list1275_450);
							    }
							 }
						    }
						    {
						       obj_t list1246_425;
						       {
							  obj_t arg1247_426;
							  {
							     obj_t arg1248_427;
							     arg1248_427 = MAKE_PAIR(BNIL, BNIL);
							     arg1247_426 = MAKE_PAIR(arg1244_423, arg1248_427);
							  }
							  list1246_425 = MAKE_PAIR(arg1243_422, arg1247_426);
						       }
						       return cons__138___r4_pairs_and_lists_6_3(arg1241_421, list1246_425);
						    }
						 }
					    }
					 }
				      }
				   }
				}
			     }
			  }
		       }
		    }
		 }
	      }
	   }
	}
     }
}


/* make-generic-inlined-body */ obj_t 
make_generic_inlined_body_246_object_generic(obj_t id_9, obj_t locals_10, obj_t args_11, obj_t src_12)
{
   {
      obj_t pid_615;
      pid_615 = parse_id_241_ast_ident(id_9);
      {
	 obj_t id_616;
	 id_616 = CAR(pid_615);
	 {
	    int arity_617;
	    arity_617 = arity_tools_args(args_11);
	    {
	       obj_t args_id_103_618;
	       if (NULLP(locals_10))
		 {
		    args_id_103_618 = BNIL;
		 }
	       else
		 {
		    obj_t head1224_669;
		    {
		       obj_t aux_1141;
		       {
			  local_t obj_867;
			  {
			     obj_t aux_1142;
			     aux_1142 = CAR(locals_10);
			     obj_867 = (local_t) (aux_1142);
			  }
			  aux_1141 = (((local_t) CREF(obj_867))->id);
		       }
		       head1224_669 = MAKE_PAIR(aux_1141, BNIL);
		    }
		    {
		       obj_t l1222_670;
		       obj_t tail1225_671;
		       l1222_670 = CDR(locals_10);
		       tail1225_671 = head1224_669;
		     lname1223_672:
		       if (NULLP(l1222_670))
			 {
			    args_id_103_618 = head1224_669;
			 }
		       else
			 {
			    obj_t newtail1226_675;
			    {
			       obj_t aux_1149;
			       {
				  local_t obj_873;
				  {
				     obj_t aux_1150;
				     aux_1150 = CAR(l1222_670);
				     obj_873 = (local_t) (aux_1150);
				  }
				  aux_1149 = (((local_t) CREF(obj_873))->id);
			       }
			       newtail1226_675 = MAKE_PAIR(aux_1149, BNIL);
			    }
			    SET_CDR(tail1225_671, newtail1226_675);
			    {
			       obj_t tail1225_1158;
			       obj_t l1222_1156;
			       l1222_1156 = CDR(l1222_670);
			       tail1225_1158 = newtail1226_675;
			       tail1225_671 = tail1225_1158;
			       l1222_670 = l1222_1156;
			       goto lname1223_672;
			    }
			 }
		    }
		 }
	       {
		  obj_t body_619;
		  {
		     bool_t test_1160;
		     {
			long aux_1161;
			aux_1161 = (long) (arity_617);
			test_1160 = (aux_1161 >= ((long) 0));
		     }
		     if (test_1160)
		       {
			  obj_t arg1481_621;
			  obj_t arg1483_622;
			  {
			     obj_t arg1486_625;
			     obj_t arg1487_626;
			     arg1486_625 = CNST_TABLE_REF(((long) 0));
			     {
				obj_t arg1494_631;
				arg1494_631 = CNST_TABLE_REF(((long) 1));
				{
				   obj_t list1497_633;
				   {
				      obj_t arg1498_634;
				      {
					 obj_t arg1499_635;
					 arg1499_635 = MAKE_PAIR(BNIL, BNIL);
					 arg1498_634 = MAKE_PAIR(_module__166_module_module, arg1499_635);
				      }
				      list1497_633 = MAKE_PAIR(id_616, arg1498_634);
				   }
				   arg1487_626 = cons__138___r4_pairs_and_lists_6_3(arg1494_631, list1497_633);
				}
			     }
			     {
				obj_t list1489_628;
				{
				   obj_t arg1490_629;
				   arg1490_629 = MAKE_PAIR(BNIL, BNIL);
				   list1489_628 = MAKE_PAIR(arg1487_626, arg1490_629);
				}
				arg1481_621 = cons__138___r4_pairs_and_lists_6_3(arg1486_625, list1489_628);
			     }
			  }
			  {
			     obj_t arg1501_637;
			     arg1501_637 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			     arg1483_622 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_618, arg1501_637);
			  }
			  {
			     obj_t list1484_623;
			     list1484_623 = MAKE_PAIR(arg1483_622, BNIL);
			     body_619 = cons__138___r4_pairs_and_lists_6_3(arg1481_621, list1484_623);
			  }
		       }
		     else
		       {
			  obj_t arg1504_640;
			  obj_t arg1505_641;
			  obj_t arg1507_642;
			  arg1504_640 = CNST_TABLE_REF(((long) 2));
			  {
			     obj_t arg1516_648;
			     obj_t arg1517_649;
			     arg1516_648 = CNST_TABLE_REF(((long) 0));
			     {
				obj_t arg1525_654;
				arg1525_654 = CNST_TABLE_REF(((long) 1));
				{
				   obj_t list1527_656;
				   {
				      obj_t arg1528_657;
				      {
					 obj_t arg1529_658;
					 arg1529_658 = MAKE_PAIR(BNIL, BNIL);
					 arg1528_657 = MAKE_PAIR(_module__166_module_module, arg1529_658);
				      }
				      list1527_656 = MAKE_PAIR(id_616, arg1528_657);
				   }
				   arg1517_649 = cons__138___r4_pairs_and_lists_6_3(arg1525_654, list1527_656);
				}
			     }
			     {
				obj_t list1519_651;
				{
				   obj_t arg1522_652;
				   arg1522_652 = MAKE_PAIR(BNIL, BNIL);
				   list1519_651 = MAKE_PAIR(arg1517_649, arg1522_652);
				}
				arg1505_641 = cons__138___r4_pairs_and_lists_6_3(arg1516_648, list1519_651);
			     }
			  }
			  {
			     obj_t arg1531_660;
			     obj_t arg1532_661;
			     arg1531_660 = CNST_TABLE_REF(((long) 3));
			     {
				obj_t arg1535_664;
				arg1535_664 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				arg1532_661 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_618, arg1535_664);
			     }
			     {
				obj_t list1533_662;
				list1533_662 = MAKE_PAIR(arg1532_661, BNIL);
				arg1507_642 = cons__138___r4_pairs_and_lists_6_3(arg1531_660, list1533_662);
			     }
			  }
			  {
			     obj_t list1511_644;
			     {
				obj_t arg1513_645;
				{
				   obj_t arg1514_646;
				   arg1514_646 = MAKE_PAIR(BNIL, BNIL);
				   arg1513_645 = MAKE_PAIR(arg1507_642, arg1514_646);
				}
				list1511_644 = MAKE_PAIR(arg1505_641, arg1513_645);
			     }
			     body_619 = cons__138___r4_pairs_and_lists_6_3(arg1504_640, list1511_644);
			  }
		       }
		  }
		  {
		     return body_619;
		  }
	       }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_object_generic()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_generic()
{
   module_initialization_70_engine_param(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_tools_args(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_tools_error(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_type_type(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_type_cache(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_ast_var(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_ast_ident(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_object_class(((long) 0), "OBJECT_GENERIC");
   module_initialization_70_object_inline(((long) 0), "OBJECT_GENERIC");
   return module_initialization_70_module_module(((long) 0), "OBJECT_GENERIC");
}
