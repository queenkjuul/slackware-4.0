/*===========================================================================*/
/*   (Ast/find-gdefs.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t find_global_defs_64_ast_find_gdefs_13(obj_t);
static obj_t method_init_76_ast_find_gdefs_13();
static obj_t _gdef_key__233_ast_find_gdefs_13 = BUNSPEC;
extern obj_t id_of_id_112_ast_ident(obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t remprop__243___r4_symbols_6_4(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t dsssl_defaulted_formal__174_tools_dsssl(obj_t);
extern obj_t check_to_be_define_14_ast_find_gdefs_13();
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t bind_global_def__22_ast_find_gdefs_13(obj_t, obj_t);
static obj_t _gdefs_list__201_ast_find_gdefs_13 = BUNSPEC;
extern obj_t module_initialization_70_ast_find_gdefs_13(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t push_args_50_ast_find_gdefs_13(obj_t, obj_t);
static obj_t imported_modules_init_94_ast_find_gdefs_13();
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
static obj_t library_modules_init_112_ast_find_gdefs_13();
static bool_t find_mutations__75_ast_find_gdefs_13(obj_t, obj_t);
static obj_t toplevel_init_63_ast_find_gdefs_13();
extern obj_t open_input_string(obj_t);
static obj_t _all_defined_id__238_ast_find_gdefs_13 = BUNSPEC;
static obj_t find_1_mutations__59_ast_find_gdefs_13(obj_t, obj_t);
static obj_t define_global_125_ast_find_gdefs_13(obj_t, obj_t, obj_t);
extern int arity_tools_args(obj_t);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
static obj_t loop_ast_find_gdefs_13(obj_t, obj_t, obj_t);
static obj_t _check_to_be_define_117_ast_find_gdefs_13(obj_t);
extern obj_t to_be_define__131_ast_find_gdefs_13(global_t);
static obj_t arg1511_ast_find_gdefs_13(obj_t, obj_t, obj_t);
static obj_t arg1510_ast_find_gdefs_13(obj_t, obj_t, obj_t);
static obj_t arg1507_ast_find_gdefs_13(obj_t, obj_t, obj_t);
static obj_t scan_ast_find_gdefs_13(obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t _to_be_define_1958_219_ast_find_gdefs_13(obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t read___reader(obj_t);
static obj_t _find_global_defs_146_ast_find_gdefs_13(obj_t, obj_t);
static obj_t defs__list_164_ast_find_gdefs_13();
static obj_t require_initialization_114_ast_find_gdefs_13 = BUNSPEC;
static obj_t _to_be_define__145_ast_find_gdefs_13 = BUNSPEC;
extern obj_t dsssl_default_formal_243_tools_dsssl(obj_t);
static obj_t cnst_init_137_ast_find_gdefs_13();
static obj_t __cnst[25];

DEFINE_EXPORT_PROCEDURE(to_be_define__env_91_ast_find_gdefs_13, _to_be_define_1958_219_ast_find_gdefs_131979, _to_be_define_1958_219_ast_find_gdefs_13, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1962_ast_find_gdefs_13, arg1510_ast_find_gdefs_131980, arg1510_ast_find_gdefs_13, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1961_ast_find_gdefs_13, arg1511_ast_find_gdefs_131981, arg1511_ast_find_gdefs_13, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1960_ast_find_gdefs_13, arg1507_ast_find_gdefs_131982, arg1507_ast_find_gdefs_13, 0L, 2);
DEFINE_EXPORT_PROCEDURE(find_global_defs_env_41_ast_find_gdefs_13, _find_global_defs_146_ast_find_gdefs_131983, _find_global_defs_146_ast_find_gdefs_13, 0L, 1);
DEFINE_EXPORT_PROCEDURE(check_to_be_define_env_225_ast_find_gdefs_13, _check_to_be_define_117_ast_find_gdefs_131984, _check_to_be_define_117_ast_find_gdefs_13, 0L, 0);
DEFINE_STRING(string1973_ast_find_gdefs_13, string1973_ast_find_gdefs_131985, "IF CASE APPLY BIND-EXIT LABELS LETREC LET SET! ASSERT QUOTE LAMBDA FREE-PRAGMA PRAGMA WRITE @ NOTHING DONE DEFINE-METHOD DEFINE-GENERIC DEFINE-INLINE DEFINE BEGIN READ DEF FIND-GDEFS ", 183);
DEFINE_STRING(string1972_ast_find_gdefs_13, string1972_ast_find_gdefs_131986, "and `.' notation", 16);
DEFINE_STRING(string1971_ast_find_gdefs_13, string1971_ast_find_gdefs_131987, "Can't use both DSSSL named constant", 35);
DEFINE_STRING(string1969_ast_find_gdefs_13, string1969_ast_find_gdefs_131988, "symbol or named constant expected", 33);
DEFINE_STRING(string1970_ast_find_gdefs_13, string1970_ast_find_gdefs_131989, "symbol expected", 15);
DEFINE_STRING(string1968_ast_find_gdefs_13, string1968_ast_find_gdefs_131990, "Illegal formal parameter", 24);
DEFINE_STRING(string1967_ast_find_gdefs_13, string1967_ast_find_gdefs_131991, "Illegal `define-generic' form", 29);
DEFINE_STRING(string1966_ast_find_gdefs_13, string1966_ast_find_gdefs_131992, "Illegal `define-inline' form", 28);
DEFINE_STRING(string1965_ast_find_gdefs_13, string1965_ast_find_gdefs_131993, "Illegal `lambda' form", 21);
DEFINE_STRING(string1964_ast_find_gdefs_13, string1964_ast_find_gdefs_131994, "lambda", 6);
DEFINE_STRING(string1963_ast_find_gdefs_13, string1963_ast_find_gdefs_131995, "Illegal duplicated definition", 29);
DEFINE_STRING(string1959_ast_find_gdefs_13, string1959_ast_find_gdefs_131996, "Can't find global definition", 28);


/* module-initialization */ obj_t 
module_initialization_70_ast_find_gdefs_13(long checksum_2200, char *from_2201)
{
   if (CBOOL(require_initialization_114_ast_find_gdefs_13))
     {
	require_initialization_114_ast_find_gdefs_13 = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_find_gdefs_13();
	cnst_init_137_ast_find_gdefs_13();
	imported_modules_init_94_ast_find_gdefs_13();
	method_init_76_ast_find_gdefs_13();
	toplevel_init_63_ast_find_gdefs_13();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_find_gdefs_13()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70___reader(((long) 0), "AST_FIND-GDEFS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_find_gdefs_13()
{
   {
      obj_t cnst_port_138_2192;
      cnst_port_138_2192 = open_input_string(string1973_ast_find_gdefs_13);
      {
	 long i_2193;
	 i_2193 = ((long) 24);
       loop_2194:
	 {
	    bool_t test1974_2195;
	    test1974_2195 = (i_2193 == ((long) -1));
	    if (test1974_2195)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1975_2196;
		    {
		       obj_t list1976_2197;
		       {
			  obj_t arg1977_2198;
			  arg1977_2198 = BNIL;
			  list1976_2197 = MAKE_PAIR(cnst_port_138_2192, arg1977_2198);
		       }
		       arg1975_2196 = read___reader(list1976_2197);
		    }
		    CNST_TABLE_SET(i_2193, arg1975_2196);
		 }
		 {
		    int aux_2199;
		    {
		       long aux_2219;
		       aux_2219 = (i_2193 - ((long) 1));
		       aux_2199 = (int) (aux_2219);
		    }
		    {
		       long i_2222;
		       i_2222 = (long) (aux_2199);
		       i_2193 = i_2222;
		       goto loop_2194;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_find_gdefs_13()
{
   _to_be_define__145_ast_find_gdefs_13 = BNIL;
   _gdef_key__233_ast_find_gdefs_13 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
   _gdefs_list__201_ast_find_gdefs_13 = BNIL;
   return (_all_defined_id__238_ast_find_gdefs_13 = BNIL,
      BUNSPEC);
}


/* to-be-define! */ obj_t 
to_be_define__131_ast_find_gdefs_13(global_t global_15)
{
   {
      obj_t obj2_1655;
      obj2_1655 = _to_be_define__145_ast_find_gdefs_13;
      {
	 obj_t aux_2227;
	 aux_2227 = (obj_t) (global_15);
	 return (_to_be_define__145_ast_find_gdefs_13 = MAKE_PAIR(aux_2227, obj2_1655),
	    BUNSPEC);
      }
   }
}


/* _to-be-define!1958 */ obj_t 
_to_be_define_1958_219_ast_find_gdefs_13(obj_t env_2165, obj_t global_2166)
{
   return to_be_define__131_ast_find_gdefs_13((global_t) (global_2166));
}


/* check-to-be-define */ obj_t 
check_to_be_define_14_ast_find_gdefs_13()
{
   {
      obj_t l1443_746;
      l1443_746 = _to_be_define__145_ast_find_gdefs_13;
    lname1444_747:
      if (PAIRP(l1443_746))
	{
	   {
	      obj_t global_749;
	      global_749 = CAR(l1443_746);
	      {
		 obj_t def_750;
		 {
		    obj_t aux_2235;
		    {
		       global_t obj_1658;
		       obj_1658 = (global_t) (global_749);
		       aux_2235 = (((global_t) CREF(obj_1658))->id);
		    }
		    def_750 = getprop___r4_symbols_6_4(aux_2235, _gdef_key__233_ast_find_gdefs_13);
		 }
		 {
		    bool_t test_2239;
		    if (STRUCTP(def_750))
		      {
			 obj_t aux_2244;
			 obj_t aux_2242;
			 aux_2244 = CNST_TABLE_REF(((long) 1));
			 aux_2242 = STRUCT_KEY(def_750);
			 test_2239 = (aux_2242 == aux_2244);
		      }
		    else
		      {
			 test_2239 = ((bool_t) 0);
		      }
		    if (test_2239)
		      {
			 BUNSPEC;
		      }
		    else
		      {
			 obj_t arg1483_752;
			 obj_t arg1485_754;
			 arg1483_752 = shape_tools_shape(global_749);
			 {
			    obj_t aux_2248;
			    {
			       global_t obj_1667;
			       obj_1667 = (global_t) (global_749);
			       aux_2248 = (((global_t) CREF(obj_1667))->src);
			    }
			    arg1485_754 = shape_tools_shape(aux_2248);
			 }
			 {
			    obj_t list1487_756;
			    list1487_756 = MAKE_PAIR(BNIL, BNIL);
			    user_error_151_tools_error(arg1483_752, string1959_ast_find_gdefs_13, arg1485_754, list1487_756);
			 }
		      }
		 }
	      }
	   }
	   {
	      obj_t l1443_2254;
	      l1443_2254 = CDR(l1443_746);
	      l1443_746 = l1443_2254;
	      goto lname1444_747;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t l1445_761;
      l1445_761 = _all_defined_id__238_ast_find_gdefs_13;
    lname1446_762:
      if (PAIRP(l1445_761))
	{
	   remprop__243___r4_symbols_6_4(CAR(l1445_761), _gdef_key__233_ast_find_gdefs_13);
	   {
	      obj_t l1445_2260;
	      l1445_2260 = CDR(l1445_761);
	      l1445_761 = l1445_2260;
	      goto lname1446_762;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   _all_defined_id__238_ast_find_gdefs_13 = BNIL;
   return (_to_be_define__145_ast_find_gdefs_13 = BNIL,
      BUNSPEC);
}


/* _check-to-be-define */ obj_t 
_check_to_be_define_117_ast_find_gdefs_13(obj_t env_2167)
{
   return check_to_be_define_14_ast_find_gdefs_13();
}


/* bind-global-def! */ obj_t 
bind_global_def__22_ast_find_gdefs_13(obj_t id_17, obj_t arity_18)
{
   {
      obj_t def_766;
      {
	 obj_t arg1496_767;
	 arg1496_767 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t new_1675;
	    {
	       obj_t aux_2264;
	       aux_2264 = CNST_TABLE_REF(((long) 1));
	       new_1675 = create_struct(aux_2264, ((long) 3));
	    }
	    STRUCT_SET(new_1675, ((long) 2), arity_18);
	    STRUCT_SET(new_1675, ((long) 1), arg1496_767);
	    STRUCT_SET(new_1675, ((long) 0), id_17);
	    def_766 = new_1675;
	 }
      }
      {
	 obj_t obj2_1694;
	 obj2_1694 = _gdefs_list__201_ast_find_gdefs_13;
	 _gdefs_list__201_ast_find_gdefs_13 = MAKE_PAIR(def_766, obj2_1694);
      }
      {
	 obj_t obj2_1696;
	 obj2_1696 = _all_defined_id__238_ast_find_gdefs_13;
	 _all_defined_id__238_ast_find_gdefs_13 = MAKE_PAIR(id_17, obj2_1696);
      }
      return putprop__88___r4_symbols_6_4(id_17, _gdef_key__233_ast_find_gdefs_13, def_766);
   }
}


/* defs->list */ obj_t 
defs__list_164_ast_find_gdefs_13()
{
   {
      obj_t defs_768;
      obj_t res_769;
      defs_768 = _gdefs_list__201_ast_find_gdefs_13;
      res_769 = BNIL;
    loop_770:
      if (NULLP(defs_768))
	{
	   _gdefs_list__201_ast_find_gdefs_13 = BNIL;
	   return res_769;
	}
      else
	{
	   obj_t def_773;
	   def_773 = CAR(defs_768);
	   {
	      obj_t arg1499_774;
	      obj_t arg1500_775;
	      arg1499_774 = CDR(defs_768);
	      {
		 obj_t arg1501_776;
		 {
		    obj_t arg1502_777;
		    obj_t arg1503_778;
		    arg1502_777 = STRUCT_REF(def_773, ((long) 0));
		    {
		       obj_t aux_2280;
		       obj_t aux_2278;
		       aux_2280 = STRUCT_REF(def_773, ((long) 2));
		       aux_2278 = STRUCT_REF(def_773, ((long) 1));
		       arg1503_778 = MAKE_PAIR(aux_2278, aux_2280);
		    }
		    arg1501_776 = MAKE_PAIR(arg1502_777, arg1503_778);
		 }
		 arg1500_775 = MAKE_PAIR(arg1501_776, res_769);
	      }
	      {
		 obj_t res_2286;
		 obj_t defs_2285;
		 defs_2285 = arg1499_774;
		 res_2286 = arg1500_775;
		 res_769 = res_2286;
		 defs_768 = defs_2285;
		 goto loop_770;
	      }
	   }
	}
   }
}


/* find-global-defs */ obj_t 
find_global_defs_64_ast_find_gdefs_13(obj_t sexp__30_19)
{
   {
      obj_t define_global_125_2171;
      define_global_125_2171 = make_fx_procedure(define_global_125_ast_find_gdefs_13, ((long) 2), ((long) 1));
      PROCEDURE_SET(define_global_125_2171, ((long) 0), sexp__30_19);
      _gdefs_list__201_ast_find_gdefs_13 = BNIL;
      {
	 obj_t arg1507_2170;
	 arg1507_2170 = proc1960_ast_find_gdefs_13;
	 scan_ast_find_gdefs_13(sexp__30_19, define_global_125_2171, arg1507_2170);
      }
      {
	 obj_t arg1511_2168;
	 obj_t arg1510_2169;
	 arg1511_2168 = proc1961_ast_find_gdefs_13;
	 arg1510_2169 = proc1962_ast_find_gdefs_13;
	 scan_ast_find_gdefs_13(sexp__30_19, arg1510_2169, arg1511_2168);
      }
      return defs__list_164_ast_find_gdefs_13();
   }
}


/* loop */ obj_t 
loop_ast_find_gdefs_13(obj_t action_define_41_2188, obj_t action_body_250_2187, obj_t sexp__30_804)
{
 loop_ast_find_gdefs_13:
   if (PAIRP(sexp__30_804))
     {
	obj_t sexp_807;
	sexp_807 = CAR(sexp__30_804);
	{
	   obj_t var_818;
	   obj_t exp_819;
	   if (PAIRP(sexp_807))
	     {
		bool_t test_2297;
		{
		   obj_t aux_2300;
		   obj_t aux_2298;
		   aux_2300 = CNST_TABLE_REF(((long) 3));
		   aux_2298 = CAR(sexp_807);
		   test_2297 = (aux_2298 == aux_2300);
		}
		if (test_2297)
		  {
		     loop_ast_find_gdefs_13(action_define_41_2188, action_body_250_2187, CDR(sexp_807));
		     {
			obj_t sexp__30_2305;
			sexp__30_2305 = CDR(sexp__30_804);
			sexp__30_804 = sexp__30_2305;
			goto loop_ast_find_gdefs_13;
		     }
		  }
		else
		  {
		     obj_t cdr_146_167_826;
		     cdr_146_167_826 = CDR(sexp_807);
		     {
			bool_t test_2308;
			{
			   obj_t aux_2311;
			   obj_t aux_2309;
			   aux_2311 = CNST_TABLE_REF(((long) 4));
			   aux_2309 = CAR(sexp_807);
			   test_2308 = (aux_2309 == aux_2311);
			}
			if (test_2308)
			  {
			     if (PAIRP(cdr_146_167_826))
			       {
				  obj_t car_150_99_829;
				  car_150_99_829 = CAR(cdr_146_167_826);
				  if (PAIRP(car_150_99_829))
				    {
				       obj_t arg1526_831;
				       obj_t arg1527_832;
				       obj_t arg1528_833;
				       arg1526_831 = CAR(car_150_99_829);
				       arg1527_832 = CDR(car_150_99_829);
				       arg1528_833 = CDR(cdr_146_167_826);
				       {
					  int arg1564_1740;
					  arg1564_1740 = arity_tools_args(arg1527_832);
					  PROCEDURE_ENTRY(action_define_41_2188) (action_define_41_2188, arg1526_831, BINT(arg1564_1740), BEOA);
				       }
				       PROCEDURE_ENTRY(action_body_250_2187) (action_body_250_2187, arg1527_832, arg1528_833, BEOA);
				       {
					  obj_t sexp__30_2328;
					  sexp__30_2328 = CDR(sexp__30_804);
					  sexp__30_804 = sexp__30_2328;
					  goto loop_ast_find_gdefs_13;
				       }
				    }
				  else
				    {
				       var_818 = CAR(cdr_146_167_826);
				       exp_819 = CDR(cdr_146_167_826);
				       PROCEDURE_ENTRY(action_define_41_2188) (action_define_41_2188, var_818, BFALSE, BEOA);
				       PROCEDURE_ENTRY(action_body_250_2187) (action_body_250_2187, BNIL, exp_819, BEOA);
				       {
					  obj_t sexp__30_2334;
					  sexp__30_2334 = CDR(sexp__30_804);
					  sexp__30_804 = sexp__30_2334;
					  goto loop_ast_find_gdefs_13;
				       }
				    }
			       }
			     else
			       {
				tag_125_98_821:
				  {
				     obj_t arg1572_878;
				     {
					obj_t list1573_879;
					list1573_879 = MAKE_PAIR(sexp_807, BNIL);
					arg1572_878 = list1573_879;
				     }
				     PROCEDURE_ENTRY(action_body_250_2187) (action_body_250_2187, BNIL, arg1572_878, BEOA);
				  }
				  {
				     obj_t sexp__30_2341;
				     sexp__30_2341 = CDR(sexp__30_804);
				     sexp__30_804 = sexp__30_2341;
				     goto loop_ast_find_gdefs_13;
				  }
			       }
			  }
			else
			  {
			     bool_t test_2343;
			     {
				obj_t aux_2346;
				obj_t aux_2344;
				aux_2346 = CNST_TABLE_REF(((long) 5));
				aux_2344 = CAR(sexp_807);
				test_2343 = (aux_2344 == aux_2346);
			     }
			     if (test_2343)
			       {
				  if (PAIRP(cdr_146_167_826))
				    {
				       obj_t car_219_238_840;
				       car_219_238_840 = CAR(cdr_146_167_826);
				       if (PAIRP(car_219_238_840))
					 {
					    obj_t arg1534_842;
					    obj_t arg1535_843;
					    obj_t arg1536_844;
					    arg1534_842 = CAR(car_219_238_840);
					    arg1535_843 = CDR(car_219_238_840);
					    arg1536_844 = CDR(cdr_146_167_826);
					    {
					       int arg1564_1759;
					       arg1564_1759 = arity_tools_args(arg1535_843);
					       PROCEDURE_ENTRY(action_define_41_2188) (action_define_41_2188, arg1534_842, BINT(arg1564_1759), BEOA);
					    }
					    PROCEDURE_ENTRY(action_body_250_2187) (action_body_250_2187, arg1535_843, arg1536_844, BEOA);
					    {
					       obj_t sexp__30_2363;
					       sexp__30_2363 = CDR(sexp__30_804);
					       sexp__30_804 = sexp__30_2363;
					       goto loop_ast_find_gdefs_13;
					    }
					 }
				       else
					 {
					    goto tag_125_98_821;
					 }
				    }
				  else
				    {
				       goto tag_125_98_821;
				    }
			       }
			     else
			       {
				  bool_t test_2365;
				  {
				     obj_t aux_2368;
				     obj_t aux_2366;
				     aux_2368 = CNST_TABLE_REF(((long) 6));
				     aux_2366 = CAR(sexp_807);
				     test_2365 = (aux_2366 == aux_2368);
				  }
				  if (test_2365)
				    {
				       if (PAIRP(cdr_146_167_826))
					 {
					    obj_t car_262_98_848;
					    car_262_98_848 = CAR(cdr_146_167_826);
					    if (PAIRP(car_262_98_848))
					      {
						 obj_t arg1540_850;
						 obj_t arg1542_851;
						 obj_t arg1545_852;
						 arg1540_850 = CAR(car_262_98_848);
						 arg1542_851 = CDR(car_262_98_848);
						 arg1545_852 = CDR(cdr_146_167_826);
						 {
						    int arg1564_1775;
						    arg1564_1775 = arity_tools_args(arg1542_851);
						    PROCEDURE_ENTRY(action_define_41_2188) (action_define_41_2188, arg1540_850, BINT(arg1564_1775), BEOA);
						 }
						 PROCEDURE_ENTRY(action_body_250_2187) (action_body_250_2187, arg1542_851, arg1545_852, BEOA);
						 {
						    obj_t sexp__30_2385;
						    sexp__30_2385 = CDR(sexp__30_804);
						    sexp__30_804 = sexp__30_2385;
						    goto loop_ast_find_gdefs_13;
						 }
					      }
					    else
					      {
						 goto tag_125_98_821;
					      }
					 }
				       else
					 {
					    goto tag_125_98_821;
					 }
				    }
				  else
				    {
				       bool_t test_2387;
				       {
					  obj_t aux_2390;
					  obj_t aux_2388;
					  aux_2390 = CNST_TABLE_REF(((long) 7));
					  aux_2388 = CAR(sexp_807);
					  test_2387 = (aux_2388 == aux_2390);
				       }
				       if (test_2387)
					 {
					    if (PAIRP(cdr_146_167_826))
					      {
						 obj_t car_302_55_856;
						 car_302_55_856 = CAR(cdr_146_167_826);
						 if (PAIRP(car_302_55_856))
						   {
						      PROCEDURE_ENTRY(action_body_250_2187) (action_body_250_2187, CDR(car_302_55_856), CDR(cdr_146_167_826), BEOA);
						      {
							 obj_t sexp__30_2402;
							 sexp__30_2402 = CDR(sexp__30_804);
							 sexp__30_804 = sexp__30_2402;
							 goto loop_ast_find_gdefs_13;
						      }
						   }
						 else
						   {
						      goto tag_125_98_821;
						   }
					      }
					    else
					      {
						 goto tag_125_98_821;
					      }
					 }
				       else
					 {
					    goto tag_125_98_821;
					 }
				    }
			       }
			  }
		     }
		  }
	     }
	   else
	     {
		goto tag_125_98_821;
	     }
	}
     }
   else
     {
	return CNST_TABLE_REF(((long) 8));
     }
}


/* scan */ obj_t 
scan_ast_find_gdefs_13(obj_t sexp__30_800, obj_t action_define_41_801, obj_t action_body_250_802)
{
   return loop_ast_find_gdefs_13(action_define_41_801, action_body_250_802, sexp__30_800);
}


/* _find-global-defs */ obj_t 
_find_global_defs_146_ast_find_gdefs_13(obj_t env_2172, obj_t sexp__30_2173)
{
   return find_global_defs_64_ast_find_gdefs_13(sexp__30_2173);
}


/* arg1511 */ obj_t 
arg1511_ast_find_gdefs_13(obj_t env_2174, obj_t args_2175, obj_t exp_2176)
{
   {
      obj_t args_793;
      obj_t exp_794;
      {
	 bool_t aux_2407;
	 args_793 = args_2175;
	 exp_794 = exp_2176;
	 {
	    obj_t arg1514_1715;
	    arg1514_1715 = push_args_50_ast_find_gdefs_13(args_793, BNIL);
	    aux_2407 = find_mutations__75_ast_find_gdefs_13(exp_794, arg1514_1715);
	 }
	 return BBOOL(aux_2407);
      }
   }
}


/* arg1510 */ obj_t 
arg1510_ast_find_gdefs_13(obj_t env_2177, obj_t x_2178, obj_t y_2179)
{
   {
      obj_t x_790;
      obj_t y_791;
      x_790 = x_2178;
      y_791 = y_2179;
      return CNST_TABLE_REF(((long) 9));
   }
}


/* arg1507 */ obj_t 
arg1507_ast_find_gdefs_13(obj_t env_2180, obj_t args_2181, obj_t exp_2182)
{
   {
      obj_t args_784;
      obj_t exp_785;
      args_784 = args_2181;
      exp_785 = exp_2182;
      return CNST_TABLE_REF(((long) 9));
   }
}


/* define-global */ obj_t 
define_global_125_ast_find_gdefs_13(obj_t env_2183, obj_t var_2185, obj_t arity_2186)
{
   {
      obj_t sexp__30_2184;
      sexp__30_2184 = PROCEDURE_REF(env_2183, ((long) 0));
      {
	 obj_t var_882;
	 obj_t arity_883;
	 var_882 = var_2185;
	 arity_883 = arity_2186;
	 {
	    obj_t pre_id_183_885;
	    if (PAIRP(var_882))
	      {
		 obj_t cdr_109_69_890;
		 cdr_109_69_890 = CDR(var_882);
		 {
		    bool_t test_2417;
		    {
		       obj_t aux_2420;
		       obj_t aux_2418;
		       aux_2420 = CNST_TABLE_REF(((long) 10));
		       aux_2418 = CAR(var_882);
		       test_2417 = (aux_2418 == aux_2420);
		    }
		    if (test_2417)
		      {
			 if (PAIRP(cdr_109_69_890))
			   {
			      obj_t cdr_112_210_893;
			      cdr_112_210_893 = CDR(cdr_109_69_890);
			      if (PAIRP(cdr_112_210_893))
				{
				   bool_t test_2428;
				   {
				      obj_t aux_2429;
				      aux_2429 = CDR(cdr_112_210_893);
				      test_2428 = (aux_2429 == BNIL);
				   }
				   if (test_2428)
				     {
					pre_id_183_885 = CAR(cdr_109_69_890);
				      tag_101_79_886:
					{
					   obj_t id_901;
					   id_901 = id_of_id_112_ast_ident(pre_id_183_885);
					   {
					      obj_t old_def_101_902;
					      old_def_101_902 = getprop___r4_symbols_6_4(id_901, _gdef_key__233_ast_find_gdefs_13);
					      {
						 {
						    bool_t test_2434;
						    if (STRUCTP(old_def_101_902))
						      {
							 obj_t aux_2439;
							 obj_t aux_2437;
							 aux_2439 = CNST_TABLE_REF(((long) 1));
							 aux_2437 = STRUCT_KEY(old_def_101_902);
							 test_2434 = (aux_2437 == aux_2439);
						      }
						    else
						      {
							 test_2434 = ((bool_t) 0);
						      }
						    if (test_2434)
						      {
							 obj_t list1594_906;
							 list1594_906 = MAKE_PAIR(BNIL, BNIL);
							 return user_error_151_tools_error(var_882, string1963_ast_find_gdefs_13, sexp__30_2184, list1594_906);
						      }
						    else
						      {
							 return bind_global_def__22_ast_find_gdefs_13(id_901, arity_883);
						      }
						 }
					      }
					   }
					}
				     }
				   else
				     {
					obj_t pre_id_183_2446;
					pre_id_183_2446 = var_882;
					pre_id_183_885 = pre_id_183_2446;
					goto tag_101_79_886;
				     }
				}
			      else
				{
				   obj_t pre_id_183_2447;
				   pre_id_183_2447 = var_882;
				   pre_id_183_885 = pre_id_183_2447;
				   goto tag_101_79_886;
				}
			   }
			 else
			   {
			      obj_t pre_id_183_2448;
			      pre_id_183_2448 = var_882;
			      pre_id_183_885 = pre_id_183_2448;
			      goto tag_101_79_886;
			   }
		      }
		    else
		      {
			 obj_t pre_id_183_2449;
			 pre_id_183_2449 = var_882;
			 pre_id_183_885 = pre_id_183_2449;
			 goto tag_101_79_886;
		      }
		 }
	      }
	    else
	      {
		 obj_t pre_id_183_2450;
		 pre_id_183_2450 = var_882;
		 pre_id_183_885 = pre_id_183_2450;
		 goto tag_101_79_886;
	      }
	 }
      }
   }
}


/* find-mutations! */ bool_t 
find_mutations__75_ast_find_gdefs_13(obj_t exp__153_20, obj_t stack_21)
{
   {
      obj_t l1447_910;
      l1447_910 = exp__153_20;
    lname1448_911:
      if (PAIRP(l1447_910))
	{
	   find_1_mutations__59_ast_find_gdefs_13(CAR(l1447_910), stack_21);
	   {
	      obj_t l1447_2455;
	      l1447_2455 = CDR(l1447_910);
	      l1447_910 = l1447_2455;
	      goto lname1448_911;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* find-1-mutations! */ obj_t 
find_1_mutations__59_ast_find_gdefs_13(obj_t exp_22, obj_t stack_23)
{
 find_1_mutations__59_ast_find_gdefs_13:
   {
      obj_t val_950;
      obj_t clauses_951;
      obj_t bindings_938;
      obj_t exp_939;
      obj_t bindings_935;
      obj_t exp_936;
      obj_t bindings_932;
      obj_t exp_933;
      obj_t id_928;
      obj_t module_929;
      obj_t val_930;
      obj_t id_925;
      obj_t val_926;
      if (PAIRP(exp_22))
	{
	   obj_t cdr_407_115_970;
	   cdr_407_115_970 = CDR(exp_22);
	   {
	      bool_t test_2460;
	      {
		 obj_t aux_2463;
		 obj_t aux_2461;
		 aux_2463 = CNST_TABLE_REF(((long) 15));
		 aux_2461 = CAR(exp_22);
		 test_2460 = (aux_2461 == aux_2463);
	      }
	      if (test_2460)
		{
		   if (PAIRP(cdr_407_115_970))
		     {
			bool_t test_2468;
			{
			   obj_t aux_2469;
			   aux_2469 = CDR(cdr_407_115_970);
			   test_2468 = (aux_2469 == BNIL);
			}
			if (test_2468)
			  {
			     return CNST_TABLE_REF(((long) 8));
			  }
			else
			  {
			   tag_373_251_967:
			     {
				obj_t caller_1223;
				caller_1223 = CAR(exp_22);
				if (SYMBOLP(caller_1223))
				  {
				     obj_t pid_1225;
				     pid_1225 = parse_id_241_ast_ident(caller_1223);
				     {
					obj_t id_1226;
					id_1226 = CAR(pid_1225);
					{
					   {
					      bool_t test_2478;
					      {
						 obj_t aux_2479;
						 aux_2479 = CNST_TABLE_REF(((long) 12));
						 test_2478 = (id_1226 == aux_2479);
					      }
					      if (test_2478)
						{
						   return CNST_TABLE_REF(((long) 8));
						}
					      else
						{
						   bool_t test_2483;
						   {
						      obj_t aux_2484;
						      aux_2484 = CNST_TABLE_REF(((long) 13));
						      test_2483 = (id_1226 == aux_2484);
						   }
						   if (test_2483)
						     {
							return CNST_TABLE_REF(((long) 8));
						     }
						   else
						     {
							bool_t test_2488;
							{
							   obj_t aux_2489;
							   aux_2489 = CNST_TABLE_REF(((long) 14));
							   test_2488 = (id_1226 == aux_2489);
							}
							if (test_2488)
							  {
							     if (PAIRP(exp_22))
							       {
								  obj_t cdr_3499_88_1238;
								  cdr_3499_88_1238 = CDR(exp_22);
								  if (PAIRP(cdr_3499_88_1238))
								    {
								       obj_t arg1835_1241;
								       arg1835_1241 = CDR(cdr_3499_88_1238);
								       {
									  obj_t arg1836_2145;
									  arg1836_2145 = push_args_50_ast_find_gdefs_13(CAR(cdr_3499_88_1238), stack_23);
									  {
									     bool_t aux_2500;
									     aux_2500 = find_mutations__75_ast_find_gdefs_13(arg1835_1241, arg1836_2145);
									     return BBOOL(aux_2500);
									  }
								       }
								    }
								  else
								    {
								     tag_3492_3_1235:
								       {
									  obj_t list1840_1246;
									  list1840_1246 = MAKE_PAIR(BNIL, BNIL);
									  return user_error_151_tools_error(string1964_ast_find_gdefs_13, string1965_ast_find_gdefs_13, exp_22, list1840_1246);
								       }
								    }
							       }
							     else
							       {
								  goto tag_3492_3_1235;
							       }
							  }
							else
							  {
							     bool_t aux_2505;
							     aux_2505 = find_mutations__75_ast_find_gdefs_13(exp_22, stack_23);
							     return BBOOL(aux_2505);
							  }
						     }
						}
					   }
					}
				     }
				  }
				else
				  {
				     bool_t aux_2508;
				     aux_2508 = find_mutations__75_ast_find_gdefs_13(exp_22, stack_23);
				     return BBOOL(aux_2508);
				  }
			     }
			  }
		     }
		   else
		     {
			goto tag_373_251_967;
		     }
		}
	      else
		{
		   bool_t test_2511;
		   {
		      obj_t aux_2514;
		      obj_t aux_2512;
		      aux_2514 = CNST_TABLE_REF(((long) 12));
		      aux_2512 = CAR(exp_22);
		      test_2511 = (aux_2512 == aux_2514);
		   }
		   if (test_2511)
		     {
			if (PAIRP(cdr_407_115_970))
			  {
			     bool_t test_2519;
			     {
				obj_t aux_2520;
				aux_2520 = CDR(cdr_407_115_970);
				test_2519 = (aux_2520 == BNIL);
			     }
			     if (test_2519)
			       {
				  return CNST_TABLE_REF(((long) 8));
			       }
			     else
			       {
				  goto tag_373_251_967;
			       }
			  }
			else
			  {
			     goto tag_373_251_967;
			  }
		     }
		   else
		     {
			bool_t test_2524;
			{
			   obj_t aux_2527;
			   obj_t aux_2525;
			   aux_2527 = CNST_TABLE_REF(((long) 13));
			   aux_2525 = CAR(exp_22);
			   test_2524 = (aux_2525 == aux_2527);
			}
			if (test_2524)
			  {
			     if (PAIRP(cdr_407_115_970))
			       {
				  bool_t test_2532;
				  {
				     obj_t aux_2533;
				     aux_2533 = CDR(cdr_407_115_970);
				     test_2532 = (aux_2533 == BNIL);
				  }
				  if (test_2532)
				    {
				       return CNST_TABLE_REF(((long) 8));
				    }
				  else
				    {
				       goto tag_373_251_967;
				    }
			       }
			     else
			       {
				  goto tag_373_251_967;
			       }
			  }
			else
			  {
			     bool_t test_2537;
			     {
				obj_t aux_2540;
				obj_t aux_2538;
				aux_2540 = CNST_TABLE_REF(((long) 16));
				aux_2538 = CAR(exp_22);
				test_2537 = (aux_2538 == aux_2540);
			     }
			     if (test_2537)
			       {
				  if (PAIRP(cdr_407_115_970))
				    {
				       obj_t cdr_1502_154_991;
				       cdr_1502_154_991 = CDR(cdr_407_115_970);
				       if (PAIRP(cdr_1502_154_991))
					 {
					    bool_t aux_2548;
					    aux_2548 = find_mutations__75_ast_find_gdefs_13(CDR(cdr_1502_154_991), stack_23);
					    return BBOOL(aux_2548);
					 }
				       else
					 {
					    goto tag_373_251_967;
					 }
				    }
				  else
				    {
				       goto tag_373_251_967;
				    }
			       }
			     else
			       {
				  bool_t test_2552;
				  {
				     obj_t aux_2555;
				     obj_t aux_2553;
				     aux_2555 = CNST_TABLE_REF(((long) 3));
				     aux_2553 = CAR(exp_22);
				     test_2552 = (aux_2553 == aux_2555);
				  }
				  if (test_2552)
				    {
				       bool_t aux_2558;
				       aux_2558 = find_mutations__75_ast_find_gdefs_13(cdr_407_115_970, stack_23);
				       return BBOOL(aux_2558);
				    }
				  else
				    {
				       bool_t test_2561;
				       {
					  obj_t aux_2564;
					  obj_t aux_2562;
					  aux_2564 = CNST_TABLE_REF(((long) 17));
					  aux_2562 = CAR(exp_22);
					  test_2561 = (aux_2562 == aux_2564);
				       }
				       if (test_2561)
					 {
					    if (PAIRP(cdr_407_115_970))
					      {
						 obj_t car_1833_68_1000;
						 car_1833_68_1000 = CAR(cdr_407_115_970);
						 if (SYMBOLP(car_1833_68_1000))
						   {
						      id_925 = car_1833_68_1000;
						      val_926 = CDR(cdr_407_115_970);
						      find_mutations__75_ast_find_gdefs_13(val_926, stack_23);
						      {
							 bool_t test_2573;
							 {
							    obj_t aux_2574;
							    aux_2574 = memq___r4_pairs_and_lists_6_3(id_925, stack_23);
							    test_2573 = CBOOL(aux_2574);
							 }
							 if (test_2573)
							   {
							      return BUNSPEC;
							   }
							 else
							   {
							      obj_t def_1127;
							      def_1127 = getprop___r4_symbols_6_4(id_925, _gdef_key__233_ast_find_gdefs_13);
							      {
								 bool_t test_2578;
								 if (STRUCTP(def_1127))
								   {
								      obj_t aux_2583;
								      obj_t aux_2581;
								      aux_2583 = CNST_TABLE_REF(((long) 1));
								      aux_2581 = STRUCT_KEY(def_1127);
								      test_2578 = (aux_2581 == aux_2583);
								   }
								 else
								   {
								      test_2578 = ((bool_t) 0);
								   }
								 if (test_2578)
								   {
								      obj_t x_2190;
								      {
									 obj_t aux_2586;
									 aux_2586 = CNST_TABLE_REF(((long) 11));
									 x_2190 = STRUCT_SET(def_1127, ((long) 1), aux_2586);
								      }
								      return BUNSPEC;
								   }
								 else
								   {
								      return BUNSPEC;
								   }
							      }
							   }
						      }
						   }
						 else
						   {
						      obj_t car_1859_223_1004;
						      car_1859_223_1004 = CAR(cdr_407_115_970);
						      if (PAIRP(car_1859_223_1004))
							{
							   obj_t cdr_1864_106_1006;
							   cdr_1864_106_1006 = CDR(car_1859_223_1004);
							   {
							      bool_t test_2594;
							      {
								 obj_t aux_2597;
								 obj_t aux_2595;
								 aux_2597 = CNST_TABLE_REF(((long) 10));
								 aux_2595 = CAR(car_1859_223_1004);
								 test_2594 = (aux_2595 == aux_2597);
							      }
							      if (test_2594)
								{
								   if (PAIRP(cdr_1864_106_1006))
								     {
									obj_t car_1867_8_1009;
									obj_t cdr_1868_3_1010;
									car_1867_8_1009 = CAR(cdr_1864_106_1006);
									cdr_1868_3_1010 = CDR(cdr_1864_106_1006);
									if (SYMBOLP(car_1867_8_1009))
									  {
									     if (PAIRP(cdr_1868_3_1010))
									       {
										  obj_t car_1873_232_1013;
										  car_1873_232_1013 = CAR(cdr_1868_3_1010);
										  if (SYMBOLP(car_1873_232_1013))
										    {
										       bool_t test_2611;
										       {
											  obj_t aux_2612;
											  aux_2612 = CDR(cdr_1868_3_1010);
											  test_2611 = (aux_2612 == BNIL);
										       }
										       if (test_2611)
											 {
											    id_928 = car_1867_8_1009;
											    module_929 = car_1873_232_1013;
											    val_930 = CDR(cdr_407_115_970);
											    find_mutations__75_ast_find_gdefs_13(val_930, stack_23);
											    {
											       bool_t test1748_1130;
											       {
												  obj_t obj2_2035;
												  obj2_2035 = _module__166_module_module;
												  test1748_1130 = (module_929 == obj2_2035);
											       }
											       if (test1748_1130)
												 {
												    obj_t def_1131;
												    def_1131 = getprop___r4_symbols_6_4(id_928, _gdef_key__233_ast_find_gdefs_13);
												    {
												       bool_t test_2619;
												       if (STRUCTP(def_1131))
													 {
													    obj_t aux_2624;
													    obj_t aux_2622;
													    aux_2624 = CNST_TABLE_REF(((long) 1));
													    aux_2622 = STRUCT_KEY(def_1131);
													    test_2619 = (aux_2622 == aux_2624);
													 }
												       else
													 {
													    test_2619 = ((bool_t) 0);
													 }
												       if (test_2619)
													 {
													    obj_t x_2191;
													    {
													       obj_t aux_2627;
													       aux_2627 = CNST_TABLE_REF(((long) 11));
													       x_2191 = STRUCT_SET(def_1131, ((long) 1), aux_2627);
													    }
													    return BUNSPEC;
													 }
												       else
													 {
													    return BUNSPEC;
													 }
												    }
												 }
											       else
												 {
												    return BUNSPEC;
												 }
											    }
											 }
										       else
											 {
											    goto tag_373_251_967;
											 }
										    }
										  else
										    {
										       goto tag_373_251_967;
										    }
									       }
									     else
									       {
										  goto tag_373_251_967;
									       }
									  }
									else
									  {
									     goto tag_373_251_967;
									  }
								     }
								   else
								     {
									goto tag_373_251_967;
								     }
								}
							      else
								{
								   goto tag_373_251_967;
								}
							   }
							}
						      else
							{
							   goto tag_373_251_967;
							}
						   }
					      }
					    else
					      {
						 goto tag_373_251_967;
					      }
					 }
				       else
					 {
					    bool_t test_2631;
					    {
					       obj_t aux_2634;
					       obj_t aux_2632;
					       aux_2634 = CNST_TABLE_REF(((long) 18));
					       aux_2632 = CAR(exp_22);
					       test_2631 = (aux_2632 == aux_2634);
					    }
					    if (test_2631)
					      {
						 if (PAIRP(cdr_407_115_970))
						   {
						      bool_t aux_2639;
						      bindings_932 = CAR(cdr_407_115_970);
						      exp_933 = CDR(cdr_407_115_970);
						      {
							 obj_t new_stack_37_1134;
							 {
							    obj_t stack_1141;
							    obj_t bindings_1142;
							    stack_1141 = stack_23;
							    bindings_1142 = bindings_932;
							  loop_1143:
							    if (NULLP(bindings_1142))
							      {
								 new_stack_37_1134 = stack_1141;
							      }
							    else
							      {
								 bool_t test_2642;
								 {
								    obj_t aux_2643;
								    aux_2643 = CAR(bindings_1142);
								    test_2642 = PAIRP(aux_2643);
								 }
								 if (test_2642)
								   {
								      {
									 obj_t arg1761_1146;
									 obj_t arg1762_1147;
									 {
									    obj_t arg1765_1148;
									    {
									       obj_t aux_2646;
									       {
										  obj_t aux_2647;
										  aux_2647 = CAR(bindings_1142);
										  aux_2646 = CAR(aux_2647);
									       }
									       arg1765_1148 = id_of_id_112_ast_ident(aux_2646);
									    }
									    arg1761_1146 = MAKE_PAIR(arg1765_1148, stack_1141);
									 }
									 arg1762_1147 = CDR(bindings_1142);
									 {
									    obj_t bindings_2654;
									    obj_t stack_2653;
									    stack_2653 = arg1761_1146;
									    bindings_2654 = arg1762_1147;
									    bindings_1142 = bindings_2654;
									    stack_1141 = stack_2653;
									    goto loop_1143;
									 }
								      }
								   }
								 else
								   {
								      {
									 obj_t arg1768_1151;
									 obj_t arg1769_1152;
									 {
									    obj_t arg1770_1153;
									    arg1770_1153 = id_of_id_112_ast_ident(CAR(bindings_1142));
									    arg1768_1151 = MAKE_PAIR(arg1770_1153, stack_1141);
									 }
									 arg1769_1152 = CDR(bindings_1142);
									 {
									    obj_t bindings_2660;
									    obj_t stack_2659;
									    stack_2659 = arg1768_1151;
									    bindings_2660 = arg1769_1152;
									    bindings_1142 = bindings_2660;
									    stack_1141 = stack_2659;
									    goto loop_1143;
									 }
								      }
								   }
							      }
							 }
							 find_mutations__75_ast_find_gdefs_13(exp_933, new_stack_37_1134);
							 {
							    obj_t l1449_1135;
							    l1449_1135 = bindings_932;
							  lname1450_1136:
							    if (PAIRP(l1449_1135))
							      {
								 {
								    obj_t aux_2664;
								    {
								       obj_t aux_2665;
								       aux_2665 = CAR(l1449_1135);
								       aux_2664 = CDR(aux_2665);
								    }
								    find_mutations__75_ast_find_gdefs_13(aux_2664, stack_23);
								 }
								 {
								    obj_t l1449_2669;
								    l1449_2669 = CDR(l1449_1135);
								    l1449_1135 = l1449_2669;
								    goto lname1450_1136;
								 }
							      }
							    else
							      {
								 aux_2639 = ((bool_t) 1);
							      }
							 }
						      }
						      return BBOOL(aux_2639);
						   }
						 else
						   {
						      goto tag_373_251_967;
						   }
					      }
					    else
					      {
						 bool_t test_2674;
						 {
						    obj_t aux_2677;
						    obj_t aux_2675;
						    aux_2677 = CNST_TABLE_REF(((long) 19));
						    aux_2675 = CAR(exp_22);
						    test_2674 = (aux_2675 == aux_2677);
						 }
						 if (test_2674)
						   {
						      if (PAIRP(cdr_407_115_970))
							{
							   bool_t aux_2682;
							   bindings_935 = CAR(cdr_407_115_970);
							   exp_936 = CDR(cdr_407_115_970);
							   {
							      obj_t new_stack_37_1156;
							      {
								 obj_t stack_1163;
								 obj_t bindings_1164;
								 stack_1163 = stack_23;
								 bindings_1164 = bindings_935;
							       loop_1165:
								 if (NULLP(bindings_1164))
								   {
								      new_stack_37_1156 = stack_1163;
								   }
								 else
								   {
								      bool_t test_2685;
								      {
									 obj_t aux_2686;
									 aux_2686 = CAR(bindings_1164);
									 test_2685 = PAIRP(aux_2686);
								      }
								      if (test_2685)
									{
									   {
									      obj_t arg1779_1168;
									      obj_t arg1780_1169;
									      {
										 obj_t arg1781_1170;
										 {
										    obj_t aux_2689;
										    {
										       obj_t aux_2690;
										       aux_2690 = CAR(bindings_1164);
										       aux_2689 = CAR(aux_2690);
										    }
										    arg1781_1170 = id_of_id_112_ast_ident(aux_2689);
										 }
										 arg1779_1168 = MAKE_PAIR(arg1781_1170, stack_1163);
									      }
									      arg1780_1169 = CDR(bindings_1164);
									      {
										 obj_t bindings_2697;
										 obj_t stack_2696;
										 stack_2696 = arg1779_1168;
										 bindings_2697 = arg1780_1169;
										 bindings_1164 = bindings_2697;
										 stack_1163 = stack_2696;
										 goto loop_1165;
									      }
									   }
									}
								      else
									{
									   {
									      obj_t arg1788_1173;
									      obj_t arg1789_1174;
									      {
										 obj_t arg1790_1175;
										 arg1790_1175 = id_of_id_112_ast_ident(CAR(bindings_1164));
										 arg1788_1173 = MAKE_PAIR(arg1790_1175, stack_1163);
									      }
									      arg1789_1174 = CDR(bindings_1164);
									      {
										 obj_t bindings_2703;
										 obj_t stack_2702;
										 stack_2702 = arg1788_1173;
										 bindings_2703 = arg1789_1174;
										 bindings_1164 = bindings_2703;
										 stack_1163 = stack_2702;
										 goto loop_1165;
									      }
									   }
									}
								   }
							      }
							      find_mutations__75_ast_find_gdefs_13(exp_936, new_stack_37_1156);
							      {
								 obj_t l1451_1157;
								 l1451_1157 = bindings_935;
							       lname1452_1158:
								 if (PAIRP(l1451_1157))
								   {
								      {
									 obj_t aux_2707;
									 {
									    obj_t aux_2708;
									    aux_2708 = CAR(l1451_1157);
									    aux_2707 = CDR(aux_2708);
									 }
									 find_mutations__75_ast_find_gdefs_13(aux_2707, new_stack_37_1156);
								      }
								      {
									 obj_t l1451_2712;
									 l1451_2712 = CDR(l1451_1157);
									 l1451_1157 = l1451_2712;
									 goto lname1452_1158;
								      }
								   }
								 else
								   {
								      aux_2682 = ((bool_t) 1);
								   }
							      }
							   }
							   return BBOOL(aux_2682);
							}
						      else
							{
							   goto tag_373_251_967;
							}
						   }
						 else
						   {
						      bool_t test_2717;
						      {
							 obj_t aux_2720;
							 obj_t aux_2718;
							 aux_2720 = CNST_TABLE_REF(((long) 20));
							 aux_2718 = CAR(exp_22);
							 test_2717 = (aux_2718 == aux_2720);
						      }
						      if (test_2717)
							{
							   if (PAIRP(cdr_407_115_970))
							     {
								bool_t aux_2725;
								bindings_938 = CAR(cdr_407_115_970);
								exp_939 = CDR(cdr_407_115_970);
								{
								   obj_t new_stack_37_1178;
								   {
								      obj_t arg1799_1187;
								      if (NULLP(bindings_938))
									{
									   arg1799_1187 = BNIL;
									}
								      else
									{
									   obj_t head1455_1190;
									   {
									      obj_t aux_2728;
									      {
										 obj_t aux_2729;
										 aux_2729 = CAR(bindings_938);
										 aux_2728 = CAR(aux_2729);
									      }
									      head1455_1190 = MAKE_PAIR(aux_2728, BNIL);
									   }
									   {
									      obj_t l1453_1191;
									      obj_t tail1456_1192;
									      l1453_1191 = CDR(bindings_938);
									      tail1456_1192 = head1455_1190;
									    lname1454_1193:
									      if (NULLP(l1453_1191))
										{
										   arg1799_1187 = head1455_1190;
										}
									      else
										{
										   obj_t newtail1457_1196;
										   {
										      obj_t aux_2735;
										      {
											 obj_t aux_2736;
											 aux_2736 = CAR(l1453_1191);
											 aux_2735 = CAR(aux_2736);
										      }
										      newtail1457_1196 = MAKE_PAIR(aux_2735, BNIL);
										   }
										   SET_CDR(tail1456_1192, newtail1457_1196);
										   {
										      obj_t tail1456_2743;
										      obj_t l1453_2741;
										      l1453_2741 = CDR(l1453_1191);
										      tail1456_2743 = newtail1457_1196;
										      tail1456_1192 = tail1456_2743;
										      l1453_1191 = l1453_2741;
										      goto lname1454_1193;
										   }
										}
									   }
									}
								      new_stack_37_1178 = push_args_50_ast_find_gdefs_13(arg1799_1187, stack_23);
								   }
								   find_mutations__75_ast_find_gdefs_13(exp_939, new_stack_37_1178);
								   {
								      obj_t l1458_1179;
								      l1458_1179 = bindings_938;
								    lname1459_1180:
								      if (PAIRP(l1458_1179))
									{
									   {
									      obj_t b_1182;
									      b_1182 = CAR(l1458_1179);
									      {
										 obj_t arg1794_1183;
										 obj_t arg1795_1184;
										 {
										    obj_t aux_2750;
										    aux_2750 = CDR(b_1182);
										    arg1794_1183 = CDR(aux_2750);
										 }
										 {
										    obj_t aux_2753;
										    {
										       obj_t aux_2754;
										       aux_2754 = CDR(b_1182);
										       aux_2753 = CAR(aux_2754);
										    }
										    arg1795_1184 = push_args_50_ast_find_gdefs_13(aux_2753, new_stack_37_1178);
										 }
										 find_mutations__75_ast_find_gdefs_13(arg1794_1183, arg1795_1184);
									      }
									   }
									   {
									      obj_t l1458_2759;
									      l1458_2759 = CDR(l1458_1179);
									      l1458_1179 = l1458_2759;
									      goto lname1459_1180;
									   }
									}
								      else
									{
									   aux_2725 = ((bool_t) 1);
									}
								   }
								}
								return BBOOL(aux_2725);
							     }
							   else
							     {
								goto tag_373_251_967;
							     }
							}
						      else
							{
							   bool_t test_2764;
							   {
							      obj_t aux_2767;
							      obj_t aux_2765;
							      aux_2767 = CNST_TABLE_REF(((long) 14));
							      aux_2765 = CAR(exp_22);
							      test_2764 = (aux_2765 == aux_2767);
							   }
							   if (test_2764)
							     {
								if (PAIRP(cdr_407_115_970))
								  {
								     obj_t arg1658_1040;
								     arg1658_1040 = CDR(cdr_407_115_970);
								     {
									obj_t arg1811_1924;
									arg1811_1924 = push_args_50_ast_find_gdefs_13(CAR(cdr_407_115_970), stack_23);
									{
									   bool_t aux_2775;
									   aux_2775 = find_mutations__75_ast_find_gdefs_13(arg1658_1040, arg1811_1924);
									   return BBOOL(aux_2775);
									}
								     }
								  }
								else
								  {
								     goto tag_373_251_967;
								  }
							     }
							   else
							     {
								bool_t test_2778;
								{
								   obj_t aux_2781;
								   obj_t aux_2779;
								   aux_2781 = CNST_TABLE_REF(((long) 21));
								   aux_2779 = CAR(exp_22);
								   test_2778 = (aux_2779 == aux_2781);
								}
								if (test_2778)
								  {
								     if (PAIRP(cdr_407_115_970))
								       {
									  obj_t arg1663_1045;
									  arg1663_1045 = CDR(cdr_407_115_970);
									  {
									     obj_t arg1812_1934;
									     {
										obj_t arg1813_1935;
										arg1813_1935 = id_of_id_112_ast_ident(CAR(cdr_407_115_970));
										arg1812_1934 = MAKE_PAIR(arg1813_1935, stack_23);
									     }
									     {
										bool_t aux_2790;
										aux_2790 = find_mutations__75_ast_find_gdefs_13(arg1663_1045, arg1812_1934);
										return BBOOL(aux_2790);
									     }
									  }
								       }
								     else
								       {
									  goto tag_373_251_967;
								       }
								  }
								else
								  {
								     bool_t test_2793;
								     {
									obj_t aux_2796;
									obj_t aux_2794;
									aux_2796 = CNST_TABLE_REF(((long) 22));
									aux_2794 = CAR(exp_22);
									test_2793 = (aux_2794 == aux_2796);
								     }
								     if (test_2793)
								       {
									  if (PAIRP(cdr_407_115_970))
									    {
									       obj_t cdr_3184_231_1049;
									       cdr_3184_231_1049 = CDR(cdr_407_115_970);
									       if (PAIRP(cdr_3184_231_1049))
										 {
										    bool_t test_2804;
										    {
										       obj_t aux_2805;
										       aux_2805 = CDR(cdr_3184_231_1049);
										       test_2804 = (aux_2805 == BNIL);
										    }
										    if (test_2804)
										      {
											 obj_t arg1669_1053;
											 arg1669_1053 = CAR(cdr_3184_231_1049);
											 find_1_mutations__59_ast_find_gdefs_13(CAR(cdr_407_115_970), stack_23);
											 {
											    obj_t exp_2811;
											    exp_2811 = arg1669_1053;
											    exp_22 = exp_2811;
											    goto find_1_mutations__59_ast_find_gdefs_13;
											 }
										      }
										    else
										      {
											 goto tag_373_251_967;
										      }
										 }
									       else
										 {
										    goto tag_373_251_967;
										 }
									    }
									  else
									    {
									       goto tag_373_251_967;
									    }
								       }
								     else
								       {
									  bool_t test_2812;
									  {
									     obj_t aux_2815;
									     obj_t aux_2813;
									     aux_2815 = CNST_TABLE_REF(((long) 23));
									     aux_2813 = CAR(exp_22);
									     test_2812 = (aux_2813 == aux_2815);
									  }
									  if (test_2812)
									    {
									       if (PAIRP(cdr_407_115_970))
										 {
										    obj_t cdr_3308_137_1059;
										    cdr_3308_137_1059 = CDR(cdr_407_115_970);
										    if (PAIRP(cdr_3308_137_1059))
										      {
											 bool_t test_2823;
											 {
											    obj_t aux_2824;
											    aux_2824 = CDR(cdr_3308_137_1059);
											    test_2823 = (aux_2824 == BNIL);
											 }
											 if (test_2823)
											   {
											      bool_t aux_2827;
											      val_950 = CAR(cdr_407_115_970);
											      clauses_951 = CAR(cdr_3308_137_1059);
											      find_mutations__75_ast_find_gdefs_13(val_950, stack_23);
											      {
												 obj_t l1460_1207;
												 l1460_1207 = clauses_951;
											       lname1461_1208:
												 if (PAIRP(l1460_1207))
												   {
												      {
													 obj_t aux_2831;
													 {
													    obj_t aux_2832;
													    aux_2832 = CAR(l1460_1207);
													    aux_2831 = CDR(aux_2832);
													 }
													 find_mutations__75_ast_find_gdefs_13(aux_2831, stack_23);
												      }
												      {
													 obj_t l1460_2836;
													 l1460_2836 = CDR(l1460_1207);
													 l1460_1207 = l1460_2836;
													 goto lname1461_1208;
												      }
												   }
												 else
												   {
												      aux_2827 = ((bool_t) 1);
												   }
											      }
											      return BBOOL(aux_2827);
											   }
											 else
											   {
											      goto tag_373_251_967;
											   }
										      }
										    else
										      {
											 goto tag_373_251_967;
										      }
										 }
									       else
										 {
										    goto tag_373_251_967;
										 }
									    }
									  else
									    {
									       bool_t test_2841;
									       {
										  obj_t aux_2844;
										  obj_t aux_2842;
										  aux_2844 = CNST_TABLE_REF(((long) 24));
										  aux_2842 = CAR(exp_22);
										  test_2841 = (aux_2842 == aux_2844);
									       }
									       if (test_2841)
										 {
										    bool_t aux_2847;
										    aux_2847 = find_mutations__75_ast_find_gdefs_13(cdr_407_115_970, stack_23);
										    return BBOOL(aux_2847);
										 }
									       else
										 {
										    bool_t test_2850;
										    {
										       obj_t aux_2853;
										       obj_t aux_2851;
										       aux_2853 = CNST_TABLE_REF(((long) 4));
										       aux_2851 = CAR(exp_22);
										       test_2850 = (aux_2851 == aux_2853);
										    }
										    if (test_2850)
										      {
											 if (PAIRP(cdr_407_115_970))
											   {
											      obj_t arg1686_1072;
											      arg1686_1072 = CDR(cdr_407_115_970);
											      {
												 obj_t arg1817_1978;
												 {
												    obj_t aux_2859;
												    aux_2859 = CAR(cdr_407_115_970);
												    arg1817_1978 = MAKE_PAIR(aux_2859, stack_23);
												 }
												 {
												    bool_t aux_2862;
												    aux_2862 = find_mutations__75_ast_find_gdefs_13(arg1686_1072, arg1817_1978);
												    return BBOOL(aux_2862);
												 }
											      }
											   }
											 else
											   {
											      goto tag_373_251_967;
											   }
										      }
										    else
										      {
											 bool_t test_2865;
											 {
											    obj_t aux_2868;
											    obj_t aux_2866;
											    aux_2868 = CNST_TABLE_REF(((long) 5));
											    aux_2866 = CAR(exp_22);
											    test_2865 = (aux_2866 == aux_2868);
											 }
											 if (test_2865)
											   {
											      if (PAIRP(cdr_407_115_970))
												{
												   obj_t arg1689_1076;
												   arg1689_1076 = CAR(cdr_407_115_970);
												   {
												      obj_t list1821_1992;
												      list1821_1992 = MAKE_PAIR(BNIL, BNIL);
												      return user_error_151_tools_error(arg1689_1076, string1966_ast_find_gdefs_13, exp_22, list1821_1992);
												   }
												}
											      else
												{
												   goto tag_373_251_967;
												}
											   }
											 else
											   {
											      bool_t test_2876;
											      {
												 obj_t aux_2879;
												 obj_t aux_2877;
												 aux_2879 = CNST_TABLE_REF(((long) 6));
												 aux_2877 = CAR(exp_22);
												 test_2876 = (aux_2877 == aux_2879);
											      }
											      if (test_2876)
												{
												   if (PAIRP(cdr_407_115_970))
												     {
													obj_t arg1694_1081;
													arg1694_1081 = CAR(cdr_407_115_970);
													{
													   obj_t list1825_2005;
													   list1825_2005 = MAKE_PAIR(BNIL, BNIL);
													   return user_error_151_tools_error(arg1694_1081, string1967_ast_find_gdefs_13, exp_22, list1825_2005);
													}
												     }
												   else
												     {
													goto tag_373_251_967;
												     }
												}
											      else
												{
												   bool_t test_2887;
												   {
												      obj_t aux_2890;
												      obj_t aux_2888;
												      aux_2890 = CNST_TABLE_REF(((long) 7));
												      aux_2888 = CAR(exp_22);
												      test_2887 = (aux_2888 == aux_2890);
												   }
												   if (test_2887)
												     {
													if (PAIRP(cdr_407_115_970))
													  {
													     obj_t car_3483_242_1086;
													     car_3483_242_1086 = CAR(cdr_407_115_970);
													     if (PAIRP(car_3483_242_1086))
													       {
														  obj_t arg1700_1089;
														  arg1700_1089 = CDR(cdr_407_115_970);
														  {
														     obj_t arg1827_2018;
														     arg1827_2018 = push_args_50_ast_find_gdefs_13(CDR(car_3483_242_1086), stack_23);
														     {
															bool_t aux_2901;
															aux_2901 = find_mutations__75_ast_find_gdefs_13(arg1700_1089, arg1827_2018);
															return BBOOL(aux_2901);
														     }
														  }
													       }
													     else
													       {
														  goto tag_373_251_967;
													       }
													  }
													else
													  {
													     goto tag_373_251_967;
													  }
												     }
												   else
												     {
													goto tag_373_251_967;
												     }
												}
											   }
										      }
										 }
									    }
								       }
								  }
							     }
							}
						   }
					      }
					 }
				    }
			       }
			  }
		     }
		}
	   }
	}
      else
	{
	   return CNST_TABLE_REF(((long) 8));
	}
   }
}


/* push-args */ obj_t 
push_args_50_ast_find_gdefs_13(obj_t expr_24, obj_t list_25)
{
   {
      obj_t expr_1251;
      obj_t list_1252;
      bool_t dsssl_1253;
      expr_1251 = expr_24;
      list_1252 = list_25;
      dsssl_1253 = ((bool_t) 0);
    loop_1254:
      if (NULLP(expr_1251))
	{
	   return list_1252;
	}
      else
	{
	   if (PAIRP(expr_1251))
	     {
		bool_t test_2909;
		{
		   obj_t aux_2910;
		   aux_2910 = CAR(expr_1251);
		   test_2909 = SYMBOLP(aux_2910);
		}
		if (test_2909)
		  {
		     {
			obj_t arg1852_1258;
			obj_t arg1853_1259;
			arg1852_1258 = CDR(expr_1251);
			{
			   obj_t arg1856_1260;
			   arg1856_1260 = id_of_id_112_ast_ident(CAR(expr_1251));
			   arg1853_1259 = MAKE_PAIR(arg1856_1260, list_1252);
			}
			{
			   obj_t list_2918;
			   obj_t expr_2917;
			   expr_2917 = arg1852_1258;
			   list_2918 = arg1853_1259;
			   list_1252 = list_2918;
			   expr_1251 = expr_2917;
			   goto loop_1254;
			}
		     }
		  }
		else
		  {
		     {
			bool_t test1858_1262;
			{
			   obj_t aux_2919;
			   aux_2919 = dsssl_named_constant__188_tools_dsssl(CAR(expr_1251));
			   test1858_1262 = CBOOL(aux_2919);
			}
			if (test1858_1262)
			  {
			     {
				bool_t dsssl_2926;
				obj_t expr_2924;
				expr_2924 = CDR(expr_1251);
				dsssl_2926 = ((bool_t) 1);
				dsssl_1253 = dsssl_2926;
				expr_1251 = expr_2924;
				goto loop_1254;
			     }
			  }
			else
			  {
			     if (dsssl_1253)
			       {
				  bool_t test1860_1264;
				  {
				     obj_t aux_2928;
				     aux_2928 = dsssl_defaulted_formal__174_tools_dsssl(CAR(expr_1251));
				     test1860_1264 = CBOOL(aux_2928);
				  }
				  if (test1860_1264)
				    {
				       {
					  obj_t arg1861_1265;
					  obj_t arg1862_1266;
					  arg1861_1265 = CDR(expr_1251);
					  {
					     obj_t arg1863_1267;
					     {
						obj_t arg1864_1268;
						arg1864_1268 = dsssl_default_formal_243_tools_dsssl(CAR(expr_1251));
						arg1863_1267 = id_of_id_112_ast_ident(arg1864_1268);
					     }
					     arg1862_1266 = MAKE_PAIR(arg1863_1267, list_1252);
					  }
					  {
					     bool_t dsssl_2940;
					     obj_t list_2939;
					     obj_t expr_2938;
					     expr_2938 = arg1861_1265;
					     list_2939 = arg1862_1266;
					     dsssl_2940 = ((bool_t) 1);
					     dsssl_1253 = dsssl_2940;
					     list_1252 = list_2939;
					     expr_1251 = expr_2938;
					     goto loop_1254;
					  }
				       }
				    }
				  else
				    {
				       return user_error_151_tools_error(expr_1251, string1968_ast_find_gdefs_13, string1969_ast_find_gdefs_13, BNIL);
				    }
			       }
			     else
			       {
				  return user_error_151_tools_error(expr_1251, string1968_ast_find_gdefs_13, string1970_ast_find_gdefs_13, BNIL);
			       }
			  }
		     }
		  }
	     }
	   else
	     {
		if (dsssl_1253)
		  {
		     return user_error_151_tools_error(expr_1251, string1971_ast_find_gdefs_13, string1972_ast_find_gdefs_13, BNIL);
		  }
		else
		  {
		     if (SYMBOLP(expr_1251))
		       {
			  {
			     obj_t arg1874_1277;
			     arg1874_1277 = id_of_id_112_ast_ident(expr_1251);
			     return MAKE_PAIR(arg1874_1277, list_1252);
			  }
		       }
		     else
		       {
			  return user_error_151_tools_error(expr_1251, string1968_ast_find_gdefs_13, string1970_ast_find_gdefs_13, BNIL);
		       }
		  }
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_ast_find_gdefs_13()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_find_gdefs_13()
{
   module_initialization_70_type_type(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_ast_var(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_ast_node(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_ast_ident(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_tools_shape(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_tools_error(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_tools_dsssl(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_tools_args(((long) 0), "AST_FIND-GDEFS");
   module_initialization_70_engine_param(((long) 0), "AST_FIND-GDEFS");
   return module_initialization_70_module_module(((long) 0), "AST_FIND-GDEFS");
}
