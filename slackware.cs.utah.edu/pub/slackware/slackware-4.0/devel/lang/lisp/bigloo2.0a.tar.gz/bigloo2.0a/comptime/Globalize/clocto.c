/*===========================================================================*/
/*   (Globalize/clocto.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


static obj_t method_init_76_globalize_clocto();
extern obj_t cto_transitive_closure__123_globalize_clocto(local_t);
extern obj_t module_initialization_70_globalize_clocto(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_kapture(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t union_3_globalize_kapture(obj_t);
static obj_t _cto_transitive_closure_1705_30_globalize_clocto(obj_t, obj_t);
static obj_t imported_modules_init_94_globalize_clocto();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_globalize_clocto();
extern obj_t local_ast_var;
static obj_t require_initialization_114_globalize_clocto = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(cto_transitive_closure__env_229_globalize_clocto, _cto_transitive_closure_1705_30_globalize_clocto1707, _cto_transitive_closure_1705_30_globalize_clocto, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_globalize_clocto(long checksum_1547, char *from_1548)
{
   if (CBOOL(require_initialization_114_globalize_clocto))
     {
	require_initialization_114_globalize_clocto = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_clocto();
	imported_modules_init_94_globalize_clocto();
	method_init_76_globalize_clocto();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_clocto()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_CLOCTO");
   return BUNSPEC;
}


/* cto-transitive-closure! */ obj_t 
cto_transitive_closure__123_globalize_clocto(local_t host_1)
{
   {
      value_t info_991;
      info_991 = (((local_t) CREF(host_1))->value);
      {
	 obj_t cto_992;
	 {
	    obj_t aux_1564;
	    obj_t aux_1557;
	    {
	       sfun_ginfo_98_t obj_1418;
	       obj_1418 = (sfun_ginfo_98_t) (info_991);
	       {
		  obj_t aux_1566;
		  {
		     object_t aux_1567;
		     aux_1567 = (object_t) (obj_1418);
		     aux_1566 = OBJECT_WIDENING(aux_1567);
		  }
		  aux_1564 = (((sfun_ginfo_98_t) CREF(aux_1566))->cfunction);
	       }
	    }
	    {
	       sfun_ginfo_98_t obj_1417;
	       obj_1417 = (sfun_ginfo_98_t) (info_991);
	       {
		  obj_t aux_1559;
		  {
		     object_t aux_1560;
		     aux_1560 = (object_t) (obj_1417);
		     aux_1559 = OBJECT_WIDENING(aux_1560);
		  }
		  aux_1557 = (((sfun_ginfo_98_t) CREF(aux_1559))->cto);
	       }
	    }
	    cto_992 = append_2_18___r4_pairs_and_lists_6_3(aux_1557, aux_1564);
	 }
	 {
	    obj_t cto__orig_75_993;
	    {
	       obj_t list1588_1023;
	       list1588_1023 = MAKE_PAIR(cto_992, BNIL);
	       cto__orig_75_993 = list1588_1023;
	    }
	    {
	       {
		  obj_t cto_994;
		  obj_t cto__14_995;
		  cto_994 = cto_992;
		  cto__14_995 = cto__orig_75_993;
		loop_996:
		  if (NULLP(cto_994))
		    {
		       {
			  obj_t arg1558_998;
			  if ((cto__14_995 == cto__orig_75_993))
			    {
			       arg1558_998 = CAR(cto__orig_75_993);
			    }
			  else
			    {
			       arg1558_998 = union_3_globalize_kapture(cto__14_995);
			    }
			  {
			     sfun_ginfo_98_t obj_1424;
			     obj_1424 = (sfun_ginfo_98_t) (info_991);
			     {
				obj_t aux_1580;
				{
				   object_t aux_1581;
				   aux_1581 = (object_t) (obj_1424);
				   aux_1580 = OBJECT_WIDENING(aux_1581);
				}
				return ((((sfun_ginfo_98_t) CREF(aux_1580))->cto__14) = ((obj_t) arg1558_998), BUNSPEC);
			     }
			  }
		       }
		    }
		  else
		    {
		       bool_t test1560_1000;
		       {
			  obj_t obj2_1428;
			  obj2_1428 = local_ast_var;
			  {
			     obj_t aux_1585;
			     aux_1585 = CAR(cto_994);
			     test1560_1000 = (aux_1585 == obj2_1428);
			  }
		       }
		       if (test1560_1000)
			 {
			    {
			       obj_t cto_1589;
			       cto_1589 = CDR(cto_994);
			       cto_994 = cto_1589;
			       goto loop_996;
			    }
			 }
		       else
			 {
			    bool_t test_1591;
			    {
			       sfun_ginfo_98_t obj_1432;
			       {
				  value_t aux_1592;
				  {
				     local_t obj_1431;
				     {
					obj_t aux_1593;
					aux_1593 = CAR(cto_994);
					obj_1431 = (local_t) (aux_1593);
				     }
				     aux_1592 = (((local_t) CREF(obj_1431))->value);
				  }
				  obj_1432 = (sfun_ginfo_98_t) (aux_1592);
			       }
			       {
				  obj_t aux_1598;
				  {
				     object_t aux_1599;
				     aux_1599 = (object_t) (obj_1432);
				     aux_1598 = OBJECT_WIDENING(aux_1599);
				  }
				  test_1591 = (((sfun_ginfo_98_t) CREF(aux_1598))->g__219);
			       }
			    }
			    if (test_1591)
			      {
				 {
				    obj_t cto_1603;
				    cto_1603 = CDR(cto_994);
				    cto_994 = cto_1603;
				    goto loop_996;
				 }
			      }
			    else
			      {
				 bool_t test_1605;
				 {
				    sfun_ginfo_98_t obj_1436;
				    {
				       value_t aux_1606;
				       {
					  local_t obj_1435;
					  {
					     obj_t aux_1607;
					     aux_1607 = CAR(cto_994);
					     obj_1435 = (local_t) (aux_1607);
					  }
					  aux_1606 = (((local_t) CREF(obj_1435))->value);
				       }
				       obj_1436 = (sfun_ginfo_98_t) (aux_1606);
				    }
				    {
				       obj_t aux_1612;
				       {
					  obj_t aux_1613;
					  {
					     object_t aux_1614;
					     aux_1614 = (object_t) (obj_1436);
					     aux_1613 = OBJECT_WIDENING(aux_1614);
					  }
					  aux_1612 = (((sfun_ginfo_98_t) CREF(aux_1613))->cto__14);
				       }
				       test_1605 = CBOOL(aux_1612);
				    }
				 }
				 if (test_1605)
				   {
				      {
					 obj_t cto_1619;
					 cto_1619 = CDR(cto_994);
					 cto_994 = cto_1619;
					 goto loop_996;
				      }
				   }
				 else
				   {
				      {
					 obj_t callee_1006;
					 {
					    obj_t aux_1633;
					    obj_t aux_1621;
					    {
					       sfun_ginfo_98_t obj_1443;
					       {
						  value_t aux_1634;
						  {
						     local_t obj_1442;
						     {
							obj_t aux_1635;
							aux_1635 = CAR(cto_994);
							obj_1442 = (local_t) (aux_1635);
						     }
						     aux_1634 = (((local_t) CREF(obj_1442))->value);
						  }
						  obj_1443 = (sfun_ginfo_98_t) (aux_1634);
					       }
					       {
						  obj_t aux_1640;
						  {
						     object_t aux_1641;
						     aux_1641 = (object_t) (obj_1443);
						     aux_1640 = OBJECT_WIDENING(aux_1641);
						  }
						  aux_1633 = (((sfun_ginfo_98_t) CREF(aux_1640))->cfunction);
					       }
					    }
					    {
					       sfun_ginfo_98_t obj_1440;
					       {
						  value_t aux_1622;
						  {
						     local_t obj_1439;
						     {
							obj_t aux_1623;
							aux_1623 = CAR(cto_994);
							obj_1439 = (local_t) (aux_1623);
						     }
						     aux_1622 = (((local_t) CREF(obj_1439))->value);
						  }
						  obj_1440 = (sfun_ginfo_98_t) (aux_1622);
					       }
					       {
						  obj_t aux_1628;
						  {
						     object_t aux_1629;
						     aux_1629 = (object_t) (obj_1440);
						     aux_1628 = OBJECT_WIDENING(aux_1629);
						  }
						  aux_1621 = (((sfun_ginfo_98_t) CREF(aux_1628))->cto);
					       }
					    }
					    callee_1006 = append_2_18___r4_pairs_and_lists_6_3(aux_1621, aux_1633);
					 }
					 {
					    sfun_ginfo_98_t obj_1446;
					    obj_t val1477_1447;
					    {
					       value_t aux_1646;
					       {
						  local_t obj_1445;
						  {
						     obj_t aux_1647;
						     aux_1647 = CAR(cto_994);
						     obj_1445 = (local_t) (aux_1647);
						  }
						  aux_1646 = (((local_t) CREF(obj_1445))->value);
					       }
					       obj_1446 = (sfun_ginfo_98_t) (aux_1646);
					    }
					    val1477_1447 = BTRUE;
					    {
					       obj_t aux_1652;
					       {
						  object_t aux_1653;
						  aux_1653 = (object_t) (obj_1446);
						  aux_1652 = OBJECT_WIDENING(aux_1653);
					       }
					       ((((sfun_ginfo_98_t) CREF(aux_1652))->cto__14) = ((obj_t) val1477_1447), BUNSPEC);
					    }
					 }
					 {
					    obj_t arg1569_1009;
					    obj_t arg1570_1010;
					    arg1569_1009 = append_2_18___r4_pairs_and_lists_6_3(CDR(cto_994), callee_1006);
					    arg1570_1010 = MAKE_PAIR(callee_1006, cto__14_995);
					    {
					       obj_t cto__14_1661;
					       obj_t cto_1660;
					       cto_1660 = arg1569_1009;
					       cto__14_1661 = arg1570_1010;
					       cto__14_995 = cto__14_1661;
					       cto_994 = cto_1660;
					       goto loop_996;
					    }
					 }
				      }
				   }
			      }
			 }
		    }
	       }
	    }
	 }
      }
   }
}


/* _cto-transitive-closure!1705 */ obj_t 
_cto_transitive_closure_1705_30_globalize_clocto(obj_t env_1545, obj_t host_1546)
{
   return cto_transitive_closure__123_globalize_clocto((local_t) (host_1546));
}


/* method-init */ obj_t 
method_init_76_globalize_clocto()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_clocto()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_CLOCTO");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_CLOCTO");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_CLOCTO");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_CLOCTO");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_CLOCTO");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_CLOCTO");
   return module_initialization_70_globalize_kapture(((long) 0), "GLOBALIZE_CLOCTO");
}
