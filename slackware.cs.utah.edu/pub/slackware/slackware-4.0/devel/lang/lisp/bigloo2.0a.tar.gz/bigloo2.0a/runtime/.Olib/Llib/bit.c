/*===========================================================================*/
/*   (Llib/bit.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t _bit_not1144_232___bit(obj_t, obj_t);
static obj_t symbol1252___bit = BUNSPEC;
static obj_t symbol1251___bit = BUNSPEC;
static obj_t symbol1250___bit = BUNSPEC;
static obj_t symbol1248___bit = BUNSPEC;
static obj_t symbol1247___bit = BUNSPEC;
static obj_t symbol1246___bit = BUNSPEC;
static obj_t symbol1245___bit = BUNSPEC;
static obj_t symbol1244___bit = BUNSPEC;
static obj_t symbol1243___bit = BUNSPEC;
static obj_t symbol1242___bit = BUNSPEC;
static obj_t symbol1241___bit = BUNSPEC;
static obj_t symbol1239___bit = BUNSPEC;
static obj_t symbol1240___bit = BUNSPEC;
static obj_t symbol1236___bit = BUNSPEC;
static obj_t symbol1235___bit = BUNSPEC;
extern long bit_not_211___bit(long);
extern long bit_or_153___bit(long, long);
static obj_t _bit_or1141_55___bit(obj_t, obj_t, obj_t);
static obj_t _bit_lsh1147_247___bit(obj_t, obj_t, obj_t);
extern long bit_lsh_5___bit(long, long);
static obj_t _bit_rsh1145_208___bit(obj_t, obj_t, obj_t);
static obj_t _bit_ursh1146_227___bit(obj_t, obj_t, obj_t);
extern unsigned long bit_ursh_31___bit(unsigned long, unsigned long);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _bit_xor1143_106___bit(obj_t, obj_t, obj_t);
static obj_t _bit_and1142_73___bit(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___bit(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern long bit_and_249___bit(long, long);
extern long bit_xor_189___bit(long, long);
static obj_t imported_modules_init_94___bit();
static obj_t require_initialization_114___bit = BUNSPEC;
extern long bit_rsh_14___bit(long, long);
static obj_t cnst_init_137___bit();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( bit_ursh_env_99___bit, _bit_ursh1146_227___bit1254, _bit_ursh1146_227___bit, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( bit_xor_env_214___bit, _bit_xor1143_106___bit1255, _bit_xor1143_106___bit, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( bit_and_env_215___bit, _bit_and1142_73___bit1256, _bit_and1142_73___bit, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( bit_not_env_219___bit, _bit_not1144_232___bit1257, _bit_not1144_232___bit, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( bit_lsh_env_185___bit, _bit_lsh1147_247___bit1258, _bit_lsh1147_247___bit, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( bit_rsh_env_225___bit, _bit_rsh1145_208___bit1259, _bit_rsh1145_208___bit, 0L, 2 );
DEFINE_STRING( string1249___bit, string1249___bit1260, "ULONG", 5 );
DEFINE_STRING( string1238___bit, string1238___bit1261, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/bit.scm", 56 );
DEFINE_STRING( string1237___bit, string1237___bit1262, "LONG", 4 );
DEFINE_EXPORT_PROCEDURE( bit_or_env_216___bit, _bit_or1141_55___bit1263, _bit_or1141_55___bit, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___bit(long checksum_496, char * from_497)
{
if(CBOOL(require_initialization_114___bit)){
require_initialization_114___bit = BBOOL(((bool_t)0));
cnst_init_137___bit();
imported_modules_init_94___bit();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___bit()
{
symbol1235___bit = string_to_symbol("BIT-OR");
symbol1236___bit = string_to_symbol("_BIT-OR1141");
symbol1239___bit = string_to_symbol("BIT-AND");
symbol1240___bit = string_to_symbol("_BIT-AND1142");
symbol1241___bit = string_to_symbol("BIT-XOR");
symbol1242___bit = string_to_symbol("_BIT-XOR1143");
symbol1243___bit = string_to_symbol("BIT-NOT");
symbol1244___bit = string_to_symbol("_BIT-NOT1144");
symbol1245___bit = string_to_symbol("BIT-RSH");
symbol1246___bit = string_to_symbol("_BIT-RSH1145");
symbol1247___bit = string_to_symbol("BIT-URSH");
symbol1248___bit = string_to_symbol("_BIT-URSH1146");
symbol1250___bit = string_to_symbol("BIT-LSH");
symbol1251___bit = string_to_symbol("_BIT-LSH1147");
return (symbol1252___bit = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* bit-or */long bit_or_153___bit(long x_1, long y_2)
{
{
obj_t symbol1126_455;
symbol1126_455 = symbol1235___bit;
{
PUSH_TRACE(symbol1126_455);
BUNSPEC;
{
long aux1125_456;
aux1125_456 = (x_1 | y_2);
POP_TRACE();
return aux1125_456;
}
}
}
}


/* _bit-or1141 */obj_t _bit_or1141_55___bit(obj_t env_357, obj_t x_358, obj_t y_359)
{
{
long aux_521;
{
long x_457;
long y_458;
{
obj_t aux_522;
if(INTEGERP(x_358)){
aux_522 = x_358;
}
 else {
bigloo_type_error_location_103___error(symbol1236___bit, string1237___bit, x_358, string1238___bit, BINT(((long)3141)));
exit( -1 );}
x_457 = (long)CINT(aux_522);
}
{
obj_t aux_529;
if(INTEGERP(y_359)){
aux_529 = y_359;
}
 else {
bigloo_type_error_location_103___error(symbol1236___bit, string1237___bit, y_359, string1238___bit, BINT(((long)3141)));
exit( -1 );}
y_458 = (long)CINT(aux_529);
}
{
obj_t symbol1126_459;
symbol1126_459 = symbol1235___bit;
{
PUSH_TRACE(symbol1126_459);
BUNSPEC;
{
long aux1125_460;
aux1125_460 = (x_457 | y_458);
POP_TRACE();
aux_521 = aux1125_460;
}
}
}
}
return BINT(aux_521);
}
}


/* bit-and */long bit_and_249___bit(long x_3, long y_4)
{
{
obj_t symbol1128_461;
symbol1128_461 = symbol1239___bit;
{
PUSH_TRACE(symbol1128_461);
BUNSPEC;
{
long aux1127_462;
aux1127_462 = (x_3 & y_4);
POP_TRACE();
return aux1127_462;
}
}
}
}


/* _bit-and1142 */obj_t _bit_and1142_73___bit(obj_t env_360, obj_t x_361, obj_t y_362)
{
{
long aux_543;
{
long x_463;
long y_464;
{
obj_t aux_544;
if(INTEGERP(x_361)){
aux_544 = x_361;
}
 else {
bigloo_type_error_location_103___error(symbol1240___bit, string1237___bit, x_361, string1238___bit, BINT(((long)3410)));
exit( -1 );}
x_463 = (long)CINT(aux_544);
}
{
obj_t aux_551;
if(INTEGERP(y_362)){
aux_551 = y_362;
}
 else {
bigloo_type_error_location_103___error(symbol1240___bit, string1237___bit, y_362, string1238___bit, BINT(((long)3410)));
exit( -1 );}
y_464 = (long)CINT(aux_551);
}
{
obj_t symbol1128_465;
symbol1128_465 = symbol1239___bit;
{
PUSH_TRACE(symbol1128_465);
BUNSPEC;
{
long aux1127_466;
aux1127_466 = (x_463 & y_464);
POP_TRACE();
aux_543 = aux1127_466;
}
}
}
}
return BINT(aux_543);
}
}


/* bit-xor */long bit_xor_189___bit(long x_5, long y_6)
{
{
obj_t symbol1130_467;
symbol1130_467 = symbol1241___bit;
{
PUSH_TRACE(symbol1130_467);
BUNSPEC;
{
long aux1129_468;
aux1129_468 = (x_5 ^ y_6);
POP_TRACE();
return aux1129_468;
}
}
}
}


/* _bit-xor1143 */obj_t _bit_xor1143_106___bit(obj_t env_363, obj_t x_364, obj_t y_365)
{
{
long aux_565;
{
long x_469;
long y_470;
{
obj_t aux_566;
if(INTEGERP(x_364)){
aux_566 = x_364;
}
 else {
bigloo_type_error_location_103___error(symbol1242___bit, string1237___bit, x_364, string1238___bit, BINT(((long)3681)));
exit( -1 );}
x_469 = (long)CINT(aux_566);
}
{
obj_t aux_573;
if(INTEGERP(y_365)){
aux_573 = y_365;
}
 else {
bigloo_type_error_location_103___error(symbol1242___bit, string1237___bit, y_365, string1238___bit, BINT(((long)3681)));
exit( -1 );}
y_470 = (long)CINT(aux_573);
}
{
obj_t symbol1130_471;
symbol1130_471 = symbol1241___bit;
{
PUSH_TRACE(symbol1130_471);
BUNSPEC;
{
long aux1129_472;
aux1129_472 = (x_469 ^ y_470);
POP_TRACE();
aux_565 = aux1129_472;
}
}
}
}
return BINT(aux_565);
}
}


/* bit-not */long bit_not_211___bit(long x_7)
{
{
obj_t symbol1132_473;
symbol1132_473 = symbol1243___bit;
{
PUSH_TRACE(symbol1132_473);
BUNSPEC;
{
long aux1131_474;
aux1131_474 = ~(x_7);
POP_TRACE();
return aux1131_474;
}
}
}
}


/* _bit-not1144 */obj_t _bit_not1144_232___bit(obj_t env_366, obj_t x_367)
{
{
long aux_587;
{
long x_475;
{
obj_t aux_588;
if(INTEGERP(x_367)){
aux_588 = x_367;
}
 else {
bigloo_type_error_location_103___error(symbol1244___bit, string1237___bit, x_367, string1238___bit, BINT(((long)3952)));
exit( -1 );}
x_475 = (long)CINT(aux_588);
}
{
obj_t symbol1132_476;
symbol1132_476 = symbol1243___bit;
{
PUSH_TRACE(symbol1132_476);
BUNSPEC;
{
long aux1131_477;
aux1131_477 = ~(x_475);
POP_TRACE();
aux_587 = aux1131_477;
}
}
}
}
return BINT(aux_587);
}
}


/* bit-rsh */long bit_rsh_14___bit(long x_8, long y_9)
{
{
obj_t symbol1134_478;
symbol1134_478 = symbol1245___bit;
{
PUSH_TRACE(symbol1134_478);
BUNSPEC;
{
long aux1133_479;
aux1133_479 = (x_8 >> y_9);
POP_TRACE();
return aux1133_479;
}
}
}
}


/* _bit-rsh1145 */obj_t _bit_rsh1145_208___bit(obj_t env_368, obj_t x_369, obj_t y_370)
{
{
long aux_602;
{
long x_480;
long y_481;
{
obj_t aux_603;
if(INTEGERP(x_369)){
aux_603 = x_369;
}
 else {
bigloo_type_error_location_103___error(symbol1246___bit, string1237___bit, x_369, string1238___bit, BINT(((long)4222)));
exit( -1 );}
x_480 = (long)CINT(aux_603);
}
{
obj_t aux_610;
if(INTEGERP(y_370)){
aux_610 = y_370;
}
 else {
bigloo_type_error_location_103___error(symbol1246___bit, string1237___bit, y_370, string1238___bit, BINT(((long)4222)));
exit( -1 );}
y_481 = (long)CINT(aux_610);
}
{
obj_t symbol1134_482;
symbol1134_482 = symbol1245___bit;
{
PUSH_TRACE(symbol1134_482);
BUNSPEC;
{
long aux1133_483;
aux1133_483 = (x_480 >> y_481);
POP_TRACE();
aux_602 = aux1133_483;
}
}
}
}
return BINT(aux_602);
}
}


/* bit-ursh */unsigned long bit_ursh_31___bit(unsigned long x_10, unsigned long y_11)
{
{
obj_t symbol1136_484;
symbol1136_484 = symbol1247___bit;
{
PUSH_TRACE(symbol1136_484);
BUNSPEC;
{
unsigned long aux1135_485;
aux1135_485 = (x_10 >> y_11);
POP_TRACE();
return aux1135_485;
}
}
}
}


/* _bit-ursh1146 */obj_t _bit_ursh1146_227___bit(obj_t env_371, obj_t x_372, obj_t y_373)
{
{
unsigned long aux_624;
{
unsigned long x_486;
unsigned long y_487;
{
obj_t aux_625;
if(INTEGERP(x_372)){
aux_625 = x_372;
}
 else {
bigloo_type_error_location_103___error(symbol1248___bit, string1249___bit, x_372, string1238___bit, BINT(((long)4500)));
exit( -1 );}
x_486 = (unsigned long)CINT(aux_625);
}
{
obj_t aux_632;
if(INTEGERP(y_373)){
aux_632 = y_373;
}
 else {
bigloo_type_error_location_103___error(symbol1248___bit, string1249___bit, y_373, string1238___bit, BINT(((long)4500)));
exit( -1 );}
y_487 = (unsigned long)CINT(aux_632);
}
{
obj_t symbol1136_488;
symbol1136_488 = symbol1247___bit;
{
PUSH_TRACE(symbol1136_488);
BUNSPEC;
{
unsigned long aux1135_489;
aux1135_489 = (x_486 >> y_487);
POP_TRACE();
aux_624 = aux1135_489;
}
}
}
}
return BINT(aux_624);
}
}


/* bit-lsh */long bit_lsh_5___bit(long x_12, long y_13)
{
{
obj_t symbol1138_490;
symbol1138_490 = symbol1250___bit;
{
PUSH_TRACE(symbol1138_490);
BUNSPEC;
{
long aux1137_491;
aux1137_491 = (x_12 << y_13);
POP_TRACE();
return aux1137_491;
}
}
}
}


/* _bit-lsh1147 */obj_t _bit_lsh1147_247___bit(obj_t env_374, obj_t x_375, obj_t y_376)
{
{
long aux_646;
{
long x_492;
long y_493;
{
obj_t aux_647;
if(INTEGERP(x_375)){
aux_647 = x_375;
}
 else {
bigloo_type_error_location_103___error(symbol1251___bit, string1237___bit, x_375, string1238___bit, BINT(((long)4780)));
exit( -1 );}
x_492 = (long)CINT(aux_647);
}
{
obj_t aux_654;
if(INTEGERP(y_376)){
aux_654 = y_376;
}
 else {
bigloo_type_error_location_103___error(symbol1251___bit, string1237___bit, y_376, string1238___bit, BINT(((long)4780)));
exit( -1 );}
y_493 = (long)CINT(aux_654);
}
{
obj_t symbol1138_494;
symbol1138_494 = symbol1250___bit;
{
PUSH_TRACE(symbol1138_494);
BUNSPEC;
{
long aux1137_495;
aux1137_495 = (x_492 << y_493);
POP_TRACE();
aux_646 = aux1137_495;
}
}
}
}
return BINT(aux_646);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___bit()
{
{
obj_t symbol1140_355;
symbol1140_355 = symbol1252___bit;
{
PUSH_TRACE(symbol1140_355);
BUNSPEC;
{
obj_t aux1139_356;
aux1139_356 = module_initialization_70___error(((long)0), "__BIT");
POP_TRACE();
return aux1139_356;
}
}
}
}

