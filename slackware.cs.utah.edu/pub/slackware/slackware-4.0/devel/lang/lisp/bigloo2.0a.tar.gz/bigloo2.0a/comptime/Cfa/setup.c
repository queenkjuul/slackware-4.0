/*===========================================================================*/
/*   (Cfa/setup.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_setup();
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t node_setup__default2150_196_cfa_setup(node_t);
extern obj_t funcall_cinfo_75_cfa_info;
extern obj_t conditional_cinfo_212_cfa_info;
extern obj_t set_initial_approx__92_cfa_setup(obj_t);
static obj_t _fun_setup_2756_40_cfa_setup(obj_t, obj_t, obj_t);
extern obj_t cfun_cinfo_200_cfa_info;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t _variable_value_setup_2755_247_cfa_setup(obj_t, obj_t, obj_t);
extern obj_t closure_ast_node;
extern obj_t reshaped_global_160_cfa_info;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern approx_t make_type_approx_184_cfa_approx(type_t);
extern obj_t cvar_ast_var;
extern obj_t set_ex_it_116_ast_node;
extern obj_t set_ex_it_cinfo_168_cfa_info;
extern approx_t make_empty_approx_131_cfa_approx();
extern obj_t cvar_cinfo_53_cfa_info;
extern obj_t jump_ex_it_cinfo_139_cfa_info;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t fail_cinfo_75_cfa_info;
extern obj_t intern_sfun_cinfo_192_cfa_info;
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_cfa_setup(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_typeof(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t pre_clo_env_191_cfa_info;
extern obj_t _warning__61___error;
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
extern obj_t node_setup___185_cfa_setup(obj_t);
extern obj_t scnst_ast_var;
extern obj_t reshaped_local_224_cfa_info;
extern obj_t select_cinfo_150_cfa_info;
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_cfa_setup();
extern type_t typeof_kwote_49_type_typeof(obj_t);
static obj_t fun_setup__186_cfa_setup(fun_t, obj_t);
extern obj_t extern_sfun_cinfo_6_cfa_info;
static obj_t loop2506_cfa_setup(variable_t, value_t, obj_t, obj_t);
static obj_t call_next_method_114_cfa_setup(value_t, obj_t, variable_t);
extern obj_t scnst_cinfo_0_cfa_info;
extern obj_t app_ly_162_ast_node;
extern obj_t cfun_ast_var;
extern obj_t node_setup__189_cfa_setup(node_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _fun_setup__default2166_20_cfa_setup(obj_t, obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
extern obj_t pragma_cinfo_220_cfa_info;
static obj_t _node_setup_2754_217_cfa_setup(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t pre_make_procedure_app_60_cfa_info;
static obj_t library_modules_init_112_cfa_setup();
extern obj_t kwote_node_102_cfa_info;
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_cfa_setup();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t _node_setup__default2150_49_cfa_setup(obj_t, obj_t);
extern obj_t sfun_ast_var;
static obj_t _node_setup___39_cfa_setup(obj_t, obj_t);
extern obj_t kwote_cinfo_48_cfa_info;
extern obj_t setq_ast_node;
extern obj_t local_ast_var;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t setq_cinfo_191_cfa_info;
extern type_t typeof_atom_134_type_typeof(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t _procedure__226_type_cache;
static obj_t variable_value_setup__80_cfa_setup(value_t, variable_t);
extern obj_t sexit_ast_var;
static obj_t _set_initial_approx__130_cfa_setup(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
static obj_t variable_value_setup__default2155_228_cfa_setup(value_t, variable_t);
extern obj_t read___reader(obj_t);
static obj_t case_else2511_cfa_setup(variable_t, value_t, obj_t);
extern obj_t find_method_from_44___object(object_t, obj_t, obj_t);
static bool_t alloc_type__187_cfa_setup(type_t);
extern obj_t sexit_cinfo_49_cfa_info;
extern obj_t app_ly_cinfo_234_cfa_info;
extern obj_t svar_cinfo_166_cfa_info;
static obj_t require_initialization_114_cfa_setup = BUNSPEC;
extern obj_t _vector__240_type_cache;
extern obj_t conditional_ast_node;
extern obj_t class_super_145___object(obj_t);
extern obj_t _struct__183_type_cache;
static obj_t _variable_value_setup__default2155_55_cfa_setup(obj_t, obj_t, obj_t);
static obj_t cnst_init_137_cfa_setup();
extern obj_t atom_cinfo_155_cfa_info;
static obj_t fun_setup__default2166_177_cfa_setup(fun_t, obj_t);
static obj_t __cnst[7];

DEFINE_STATIC_GENERIC(variable_value_setup__env_134_cfa_setup, _variable_value_setup_2755_247_cfa_setup2766, _variable_value_setup_2755_247_cfa_setup, 0L, 2);
DEFINE_STATIC_PROCEDURE(fun_setup__default2166_env_7_cfa_setup, _fun_setup__default2166_20_cfa_setup2767, _fun_setup__default2166_20_cfa_setup, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_setup___env_203_cfa_setup, _node_setup___39_cfa_setup2768, _node_setup___39_cfa_setup, 0L, 1);
DEFINE_STRING(string2759_cfa_setup, string2759_cfa_setup2769, "No method for this object", 25);
DEFINE_STRING(string2760_cfa_setup, string2760_cfa_setup2770, "IMPORT VARIABLE-VALUE-SETUP!-DEFAULT2155 (SFUN SGFUN) ALREADY-DONE STATIC NODE-SETUP!-DEFAULT2150 READ ", 103);
DEFINE_STRING(string2758_cfa_setup, string2758_cfa_setup2771, "Unexpected closure", 18);
DEFINE_STRING(string2757_cfa_setup, string2757_cfa_setup2772, "node-setup!", 11);
DEFINE_STATIC_PROCEDURE(node_setup__default2150_env_105_cfa_setup, _node_setup__default2150_49_cfa_setup2773, _node_setup__default2150_49_cfa_setup, 0L, 1);
DEFINE_EXPORT_PROCEDURE(set_initial_approx__env_29_cfa_setup, _set_initial_approx__130_cfa_setup2774, _set_initial_approx__130_cfa_setup, 0L, 1);
DEFINE_EXPORT_GENERIC(node_setup__env_214_cfa_setup, _node_setup_2754_217_cfa_setup2775, _node_setup_2754_217_cfa_setup, 0L, 1);
DEFINE_STATIC_GENERIC(fun_setup__env_196_cfa_setup, _fun_setup_2756_40_cfa_setup2776, _fun_setup_2756_40_cfa_setup, 0L, 2);
DEFINE_STATIC_PROCEDURE(variable_value_setup__default2155_env_140_cfa_setup, _variable_value_setup__default2155_55_cfa_setup2777, _variable_value_setup__default2155_55_cfa_setup, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_cfa_setup(long checksum_4131, char *from_4132)
{
   if (CBOOL(require_initialization_114_cfa_setup))
     {
	require_initialization_114_cfa_setup = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_setup();
	cnst_init_137_cfa_setup();
	imported_modules_init_94_cfa_setup();
	method_init_76_cfa_setup();
	toplevel_init_63_cfa_setup();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_setup()
{
   module_initialization_70___object(((long) 0), "CFA_SETUP");
   module_initialization_70___error(((long) 0), "CFA_SETUP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_SETUP");
   module_initialization_70___reader(((long) 0), "CFA_SETUP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_setup()
{
   {
      obj_t cnst_port_138_4123;
      cnst_port_138_4123 = open_input_string(string2760_cfa_setup);
      {
	 long i_4124;
	 i_4124 = ((long) 6);
       loop_4125:
	 {
	    bool_t test2761_4126;
	    test2761_4126 = (i_4124 == ((long) -1));
	    if (test2761_4126)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2762_4127;
		    {
		       obj_t list2763_4128;
		       {
			  obj_t arg2764_4129;
			  arg2764_4129 = BNIL;
			  list2763_4128 = MAKE_PAIR(cnst_port_138_4123, arg2764_4129);
		       }
		       arg2762_4127 = read___reader(list2763_4128);
		    }
		    CNST_TABLE_SET(i_4124, arg2762_4127);
		 }
		 {
		    int aux_4130;
		    {
		       long aux_4151;
		       aux_4151 = (i_4124 - ((long) 1));
		       aux_4130 = (int) (aux_4151);
		    }
		    {
		       long i_4154;
		       i_4154 = (long) (aux_4130);
		       i_4124 = i_4154;
		       goto loop_4125;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_setup()
{
   return BUNSPEC;
}


/* set-initial-approx! */ obj_t 
set_initial_approx__92_cfa_setup(obj_t globals_1)
{
   {
      obj_t l2085_2158;
      {
	 bool_t aux_4156;
	 l2085_2158 = globals_1;
       lname2086_2159:
	 if (PAIRP(l2085_2158))
	   {
	      {
		 obj_t global_2161;
		 global_2161 = CAR(l2085_2158);
		 {
		    value_t fun_2162;
		    {
		       global_t obj_3318;
		       obj_3318 = (global_t) (global_2161);
		       fun_2162 = (((global_t) CREF(obj_3318))->value);
		    }
		    fun_setup__186_cfa_setup((fun_t) (fun_2162), global_2161);
		    {
		       obj_t l2087_2163;
		       {
			  sfun_t obj_3319;
			  obj_3319 = (sfun_t) (fun_2162);
			  l2087_2163 = (((sfun_t) CREF(obj_3319))->args);
		       }
		     lname2088_2164:
		       if (PAIRP(l2087_2163))
			 {
			    {
			       obj_t local_2167;
			       local_2167 = CAR(l2087_2163);
			       {
				  reshaped_local_224_t obj2089_2168;
				  obj2089_2168 = ((reshaped_local_224_t) (local_2167));
				  {
				     reshaped_local_224_t arg2184_2169;
				     {
					reshaped_local_224_t res2719_3325;
					{
					   obj_t binding_value_3_3322;
					   binding_value_3_3322 = BFALSE;
					   {
					      reshaped_local_224_t new1588_3323;
					      new1588_3323 = ((reshaped_local_224_t) BREF(GC_MALLOC(sizeof(struct reshaped_local_224))));
					      ((((reshaped_local_224_t) CREF(new1588_3323))->binding_value_3) = ((obj_t) binding_value_3_3322), BUNSPEC);
					      res2719_3325 = new1588_3323;
					   }
					}
					arg2184_2169 = res2719_3325;
				     }
				     {
					obj_t aux_4172;
					object_t aux_4170;
					aux_4172 = (obj_t) (arg2184_2169);
					aux_4170 = (object_t) (obj2089_2168);
					OBJECT_WIDENING_SET(aux_4170, aux_4172);
				     }
				  }
				  {
				     long arg2185_2170;
				     arg2185_2170 = class_num_218___object(reshaped_local_224_cfa_info);
				     {
					obj_t obj_3326;
					obj_3326 = (obj_t) (obj2089_2168);
					(((obj_t) CREF(obj_3326))->header = MAKE_HEADER(arg2185_2170, 0), BUNSPEC);
				     }
				  }
				  obj2089_2168;
			       }
			       {
				  value_t aux_4178;
				  {
				     local_t obj_3328;
				     obj_3328 = (local_t) (local_2167);
				     aux_4178 = (((local_t) CREF(obj_3328))->value);
				  }
				  variable_value_setup__80_cfa_setup(aux_4178, (variable_t) (local_2167));
			       }
			    }
			    {
			       obj_t l2087_4183;
			       l2087_4183 = CDR(l2087_2163);
			       l2087_2163 = l2087_4183;
			       goto lname2088_2164;
			    }
			 }
		       else
			 {
			    ((bool_t) 1);
			 }
		    }
		 }
		 {
		    node_t aux_4187;
		    {
		       obj_t aux_4188;
		       {
			  sfun_t obj_3331;
			  {
			     value_t aux_4189;
			     {
				global_t obj_3330;
				obj_3330 = (global_t) (global_2161);
				aux_4189 = (((global_t) CREF(obj_3330))->value);
			     }
			     obj_3331 = (sfun_t) (aux_4189);
			  }
			  aux_4188 = (((sfun_t) CREF(obj_3331))->body);
		       }
		       aux_4187 = (node_t) (aux_4188);
		    }
		    node_setup__189_cfa_setup(aux_4187);
		 }
	      }
	      {
		 obj_t l2085_4196;
		 l2085_4196 = CDR(l2085_2158);
		 l2085_2158 = l2085_4196;
		 goto lname2086_2159;
	      }
	   }
	 else
	   {
	      aux_4156 = ((bool_t) 1);
	   }
	 return BBOOL(aux_4156);
      }
   }
}


/* _set-initial-approx! */ obj_t 
_set_initial_approx__130_cfa_setup(obj_t env_4095, obj_t globals_4096)
{
   return set_initial_approx__92_cfa_setup(globals_4096);
}


/* alloc-type? */ bool_t 
alloc_type__187_cfa_setup(type_t type_8)
{
   {
      bool_t test2191_2176;
      {
	 obj_t obj2_3334;
	 obj2_3334 = _vector__240_type_cache;
	 {
	    obj_t aux_4200;
	    aux_4200 = (obj_t) (type_8);
	    test2191_2176 = (aux_4200 == obj2_3334);
	 }
      }
      if (test2191_2176)
	{
	   return ((bool_t) 1);
	}
      else
	{
	   bool_t test2192_2177;
	   {
	      obj_t obj2_3336;
	      obj2_3336 = _procedure__226_type_cache;
	      {
		 obj_t aux_4204;
		 aux_4204 = (obj_t) (type_8);
		 test2192_2177 = (aux_4204 == obj2_3336);
	      }
	   }
	   if (test2192_2177)
	     {
		return ((bool_t) 1);
	     }
	   else
	     {
		bool_t test2193_2178;
		{
		   obj_t obj2_3338;
		   obj2_3338 = _struct__183_type_cache;
		   {
		      obj_t aux_4208;
		      aux_4208 = (obj_t) (type_8);
		      test2193_2178 = (aux_4208 == obj2_3338);
		   }
		}
		if (test2193_2178)
		  {
		     return ((bool_t) 1);
		  }
		else
		  {
		     return ((bool_t) 0);
		  }
	     }
	}
   }
}


/* node-setup*! */ obj_t 
node_setup___185_cfa_setup(obj_t node__221_50)
{
   {
      obj_t l2148_2179;
      {
	 bool_t aux_4212;
	 l2148_2179 = node__221_50;
       lname2149_2180:
	 if (PAIRP(l2148_2179))
	   {
	      {
		 node_t aux_4215;
		 {
		    obj_t aux_4216;
		    aux_4216 = CAR(l2148_2179);
		    aux_4215 = (node_t) (aux_4216);
		 }
		 node_setup__189_cfa_setup(aux_4215);
	      }
	      {
		 obj_t l2148_4220;
		 l2148_4220 = CDR(l2148_2179);
		 l2148_2179 = l2148_4220;
		 goto lname2149_2180;
	      }
	   }
	 else
	   {
	      aux_4212 = ((bool_t) 1);
	   }
	 return BBOOL(aux_4212);
      }
   }
}


/* _node-setup*! */ obj_t 
_node_setup___39_cfa_setup(obj_t env_4097, obj_t node__221_4098)
{
   return node_setup___185_cfa_setup(node__221_4098);
}


/* method-init */ obj_t 
method_init_76_cfa_setup()
{
   add_generic__110___object(node_setup__env_214_cfa_setup, node_setup__default2150_env_105_cfa_setup);
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, kwote_node_102_cfa_info, ((long) 2));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, var_ast_node, ((long) 3));
   add_generic__110___object(variable_value_setup__env_134_cfa_setup, variable_value_setup__default2155_env_140_cfa_setup);
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, sfun_ast_var, ((long) 0));
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, svar_ast_var, ((long) 1));
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, pre_clo_env_191_cfa_info, ((long) 2));
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, sexit_ast_var, ((long) 3));
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, scnst_cinfo_0_cfa_info, ((long) 4));
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, scnst_ast_var, ((long) 5));
   add_inlined_method__244___object(variable_value_setup__env_134_cfa_setup, cvar_ast_var, ((long) 6));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, closure_ast_node, ((long) 4));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, sequence_ast_node, ((long) 5));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, app_ast_node, ((long) 6));
   add_generic__110___object(fun_setup__env_196_cfa_setup, fun_setup__default2166_env_7_cfa_setup);
   add_inlined_method__244___object(fun_setup__env_196_cfa_setup, sfun_ast_var, ((long) 0));
   add_inlined_method__244___object(fun_setup__env_196_cfa_setup, cfun_ast_var, ((long) 1));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, app_ly_162_ast_node, ((long) 7));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, funcall_ast_node, ((long) 8));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, pragma_ast_node, ((long) 9));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, cast_ast_node, ((long) 10));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, setq_ast_node, ((long) 11));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, conditional_ast_node, ((long) 12));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, fail_ast_node, ((long) 13));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, select_ast_node, ((long) 14));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, let_fun_218_ast_node, ((long) 15));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, let_var_6_ast_node, ((long) 16));
   add_inlined_method__244___object(node_setup__env_214_cfa_setup, set_ex_it_116_ast_node, ((long) 17));
   {
      long aux_4254;
      aux_4254 = add_inlined_method__244___object(node_setup__env_214_cfa_setup, jump_ex_it_184_ast_node, ((long) 18));
      return BINT(aux_4254);
   }
}


/* node-setup! */ obj_t 
node_setup__189_cfa_setup(node_t node_2)
{
 node_setup__189_cfa_setup:
   {
      obj_t method2575_3109;
      obj_t class2580_3110;
      {
	 obj_t arg2583_3107;
	 obj_t arg2584_3108;
	 {
	    object_t obj_3689;
	    obj_3689 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_3690;
	       pre_method_105_3690 = PROCEDURE_REF(node_setup__env_214_cfa_setup, ((long) 2));
	       if (INTEGERP(pre_method_105_3690))
		 {
		    PROCEDURE_SET(node_setup__env_214_cfa_setup, ((long) 2), BUNSPEC);
		    arg2583_3107 = pre_method_105_3690;
		 }
	       else
		 {
		    long obj_class_num_177_3695;
		    obj_class_num_177_3695 = TYPE(obj_3689);
		    {
		       obj_t arg1177_3696;
		       arg1177_3696 = PROCEDURE_REF(node_setup__env_214_cfa_setup, ((long) 1));
		       {
			  long arg1178_3700;
			  {
			     long arg1179_3701;
			     arg1179_3701 = OBJECT_TYPE;
			     arg1178_3700 = (obj_class_num_177_3695 - arg1179_3701);
			  }
			  arg2583_3107 = VECTOR_REF(arg1177_3696, arg1178_3700);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3706;
	    object_3706 = (object_t) (node_2);
	    {
	       long arg1180_3707;
	       {
		  long arg1181_3708;
		  long arg1182_3709;
		  arg1181_3708 = TYPE(object_3706);
		  arg1182_3709 = OBJECT_TYPE;
		  arg1180_3707 = (arg1181_3708 - arg1182_3709);
	       }
	       {
		  obj_t vector_3713;
		  vector_3713 = _classes__134___object;
		  arg2584_3108 = VECTOR_REF(vector_3713, arg1180_3707);
	       }
	    }
	 }
	 method2575_3109 = arg2583_3107;
	 class2580_3110 = arg2584_3108;
	 {
	    if (INTEGERP(method2575_3109))
	      {
		 switch ((long) CINT(method2575_3109))
		   {
		   case ((long) 0):
		      {
			 atom_t node_3116;
			 node_3116 = (atom_t) (node_2);
			 {
			    atom_cinfo_155_t obj2091_3118;
			    obj2091_3118 = ((atom_cinfo_155_t) (node_3116));
			    {
			       atom_cinfo_155_t arg2587_3119;
			       {
				  approx_t arg2588_3120;
				  {
				     type_t arg2590_3121;
				     arg2590_3121 = typeof_atom_134_type_typeof((((atom_t) CREF(node_3116))->value));
				     arg2588_3120 = make_type_approx_184_cfa_approx(arg2590_3121);
				  }
				  {
				     atom_cinfo_155_t res2720_3719;
				     {
					atom_cinfo_155_t new1619_3717;
					new1619_3717 = ((atom_cinfo_155_t) BREF(GC_MALLOC(sizeof(struct atom_cinfo_155))));
					((((atom_cinfo_155_t) CREF(new1619_3717))->approx) = ((approx_t) arg2588_3120), BUNSPEC);
					res2720_3719 = new1619_3717;
				     }
				     arg2587_3119 = res2720_3719;
				  }
			       }
			       {
				  obj_t aux_4283;
				  object_t aux_4281;
				  aux_4283 = (obj_t) (arg2587_3119);
				  aux_4281 = (object_t) (obj2091_3118);
				  OBJECT_WIDENING_SET(aux_4281, aux_4283);
			       }
			    }
			    {
			       long arg2592_3123;
			       arg2592_3123 = class_num_218___object(atom_cinfo_155_cfa_info);
			       {
				  obj_t obj_3720;
				  obj_3720 = (obj_t) (obj2091_3118);
				  (((obj_t) CREF(obj_3720))->header = MAKE_HEADER(arg2592_3123, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj2091_3118);
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 kwote_t node_3124;
			 node_3124 = (kwote_t) (node_2);
			 {
			    kwote_cinfo_48_t obj2093_3126;
			    obj2093_3126 = ((kwote_cinfo_48_t) (node_3124));
			    {
			       kwote_cinfo_48_t arg2593_3127;
			       {
				  approx_t arg2594_3128;
				  {
				     type_t arg2595_3129;
				     arg2595_3129 = typeof_kwote_49_type_typeof((((kwote_t) CREF(node_3124))->value));
				     arg2594_3128 = make_type_approx_184_cfa_approx(arg2595_3129);
				  }
				  {
				     kwote_cinfo_48_t res2721_3726;
				     {
					kwote_cinfo_48_t new1634_3724;
					new1634_3724 = ((kwote_cinfo_48_t) BREF(GC_MALLOC(sizeof(struct kwote_cinfo_48))));
					((((kwote_cinfo_48_t) CREF(new1634_3724))->approx) = ((approx_t) arg2594_3128), BUNSPEC);
					res2721_3726 = new1634_3724;
				     }
				     arg2593_3127 = res2721_3726;
				  }
			       }
			       {
				  obj_t aux_4299;
				  object_t aux_4297;
				  aux_4299 = (obj_t) (arg2593_3127);
				  aux_4297 = (object_t) (obj2093_3126);
				  OBJECT_WIDENING_SET(aux_4297, aux_4299);
			       }
			    }
			    {
			       long arg2597_3131;
			       arg2597_3131 = class_num_218___object(kwote_cinfo_48_cfa_info);
			       {
				  obj_t obj_3727;
				  obj_3727 = (obj_t) (obj2093_3126);
				  (((obj_t) CREF(obj_3727))->header = MAKE_HEADER(arg2597_3131, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj2093_3126);
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 kwote_node_102_t kwote_3132;
			 kwote_3132 = (kwote_node_102_t) (node_2);
			 {
			    node_t node_4307;
			    {
			       obj_t aux_4308;
			       {
				  object_t aux_4309;
				  aux_4309 = (object_t) (kwote_3132);
				  aux_4308 = OBJECT_WIDENING(aux_4309);
			       }
			       node_4307 = (((kwote_node_102_t) CREF(aux_4308))->node);
			    }
			    node_2 = node_4307;
			    goto node_setup__189_cfa_setup;
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 var_t node_3135;
			 node_3135 = (var_t) (node_2);
			 {
			    value_t aux_4314;
			    {
			       variable_t arg2601_3139;
			       arg2601_3139 = (((var_t) CREF(node_3135))->variable);
			       aux_4314 = (((variable_t) CREF(arg2601_3139))->value);
			    }
			    variable_value_setup__80_cfa_setup(aux_4314, (((var_t) CREF(node_3135))->variable));
			 }
			 {
			    bool_t test2602_3140;
			    {
			       bool_t test2613_3152;
			       {
				  obj_t aux_4319;
				  {
				     variable_t aux_4320;
				     aux_4320 = (((var_t) CREF(node_3135))->variable);
				     aux_4319 = (obj_t) (aux_4320);
				  }
				  test2613_3152 = is_a__118___object(aux_4319, local_ast_var);
			       }
			       if (test2613_3152)
				 {
				    bool_t test2614_3153;
				    {
				       obj_t aux_4325;
				       {
					  variable_t aux_4326;
					  aux_4326 = (((var_t) CREF(node_3135))->variable);
					  aux_4325 = (obj_t) (aux_4326);
				       }
				       test2614_3153 = is_a__118___object(aux_4325, reshaped_local_224_cfa_info);
				    }
				    if (test2614_3153)
				      {
					 test2602_3140 = ((bool_t) 0);
				      }
				    else
				      {
					 test2602_3140 = ((bool_t) 1);
				      }
				 }
			       else
				 {
				    test2602_3140 = ((bool_t) 0);
				 }
			    }
			    if (test2602_3140)
			      {
				 {
				    reshaped_local_224_t obj2096_3141;
				    obj2096_3141 = ((reshaped_local_224_t) ((((var_t) CREF(node_3135))->variable)));
				    {
				       reshaped_local_224_t arg2603_3142;
				       {
					  reshaped_local_224_t res2722_3741;
					  {
					     obj_t binding_value_3_3738;
					     binding_value_3_3738 = BFALSE;
					     {
						reshaped_local_224_t new1588_3739;
						new1588_3739 = ((reshaped_local_224_t) BREF(GC_MALLOC(sizeof(struct reshaped_local_224))));
						((((reshaped_local_224_t) CREF(new1588_3739))->binding_value_3) = ((obj_t) binding_value_3_3738), BUNSPEC);
						res2722_3741 = new1588_3739;
					     }
					  }
					  arg2603_3142 = res2722_3741;
				       }
				       {
					  obj_t aux_4338;
					  object_t aux_4336;
					  aux_4338 = (obj_t) (arg2603_3142);
					  aux_4336 = (object_t) (obj2096_3141);
					  OBJECT_WIDENING_SET(aux_4336, aux_4338);
				       }
				    }
				    {
				       long arg2605_3143;
				       arg2605_3143 = class_num_218___object(reshaped_local_224_cfa_info);
				       {
					  obj_t obj_3742;
					  obj_3742 = (obj_t) (obj2096_3141);
					  (((obj_t) CREF(obj_3742))->header = MAKE_HEADER(arg2605_3143, 0), BUNSPEC);
				       }
				    }
				    return (obj_t) (obj2096_3141);
				 }
			      }
			    else
			      {
				 bool_t test2606_3144;
				 {
				    bool_t test2609_3148;
				    {
				       obj_t aux_4345;
				       {
					  variable_t aux_4346;
					  aux_4346 = (((var_t) CREF(node_3135))->variable);
					  aux_4345 = (obj_t) (aux_4346);
				       }
				       test2609_3148 = is_a__118___object(aux_4345, global_ast_var);
				    }
				    if (test2609_3148)
				      {
					 bool_t test2610_3149;
					 {
					    obj_t aux_4351;
					    {
					       variable_t aux_4352;
					       aux_4352 = (((var_t) CREF(node_3135))->variable);
					       aux_4351 = (obj_t) (aux_4352);
					    }
					    test2610_3149 = is_a__118___object(aux_4351, reshaped_global_160_cfa_info);
					 }
					 if (test2610_3149)
					   {
					      test2606_3144 = ((bool_t) 0);
					   }
					 else
					   {
					      test2606_3144 = ((bool_t) 1);
					   }
				      }
				    else
				      {
					 test2606_3144 = ((bool_t) 0);
				      }
				 }
				 if (test2606_3144)
				   {
				      {
					 reshaped_global_160_t obj2097_3145;
					 obj2097_3145 = ((reshaped_global_160_t) ((((var_t) CREF(node_3135))->variable)));
					 {
					    obj_t aux_4362;
					    object_t aux_4360;
					    {
					       reshaped_global_160_t aux_4363;
					       {
						  aux_4363 = ((reshaped_global_160_t) BREF(GC_MALLOC(sizeof(struct reshaped_global_160))));
					       }
					       aux_4362 = (obj_t) (aux_4363);
					    }
					    aux_4360 = (object_t) (obj2097_3145);
					    OBJECT_WIDENING_SET(aux_4360, aux_4362);
					 }
					 {
					    long arg2608_3147;
					    arg2608_3147 = class_num_218___object(reshaped_global_160_cfa_info);
					    {
					       obj_t obj_3751;
					       obj_3751 = (obj_t) (obj2097_3145);
					       (((obj_t) CREF(obj_3751))->header = MAKE_HEADER(arg2608_3147, 0), BUNSPEC);
					    }
					 }
					 return (obj_t) (obj2097_3145);
				      }
				   }
				 else
				   {
				      return BFALSE;
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 obj_t arg2619_3159;
			 {
			    obj_t aux_4371;
			    {
			       closure_t aux_4372;
			       aux_4372 = (closure_t) (node_2);
			       aux_4371 = (obj_t) (aux_4372);
			    }
			    arg2619_3159 = shape_tools_shape(aux_4371);
			 }
			 return internal_error_43_tools_error(string2757_cfa_setup, string2758_cfa_setup, arg2619_3159);
		      }
		      break;
		   case ((long) 5):
		      {
			 sequence_t node_3160;
			 node_3160 = (sequence_t) (node_2);
			 return node_setup___185_cfa_setup((((sequence_t) CREF(node_3160))->nodes));
		      }
		      break;
		   case ((long) 6):
		      {
			 app_t node_3163;
			 node_3163 = (app_t) (node_2);
			 node_setup___185_cfa_setup((((app_t) CREF(node_3163))->args));
			 {
			    variable_t variable_3166;
			    {
			       var_t arg2623_3168;
			       arg2623_3168 = (((app_t) CREF(node_3163))->fun);
			       variable_3166 = (((var_t) CREF(arg2623_3168))->variable);
			    }
			    {
			       fun_t aux_4385;
			       {
				  value_t aux_4386;
				  aux_4386 = (((variable_t) CREF(variable_3166))->value);
				  aux_4385 = (fun_t) (aux_4386);
			       }
			       return fun_setup__186_cfa_setup(aux_4385, (obj_t) (variable_3166));
			    }
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 app_ly_162_t node_3169;
			 node_3169 = (app_ly_162_t) (node_2);
			 node_setup__189_cfa_setup((((app_ly_162_t) CREF(node_3169))->fun));
			 node_setup__189_cfa_setup((((app_ly_162_t) CREF(node_3169))->arg));
			 {
			    app_ly_cinfo_234_t obj2115_3173;
			    obj2115_3173 = ((app_ly_cinfo_234_t) (node_3169));
			    {
			       app_ly_cinfo_234_t arg2626_3174;
			       {
				  approx_t arg2627_3175;
				  arg2627_3175 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
				  {
				     app_ly_cinfo_234_t res2724_3763;
				     {
					app_ly_cinfo_234_t new1641_3761;
					new1641_3761 = ((app_ly_cinfo_234_t) BREF(GC_MALLOC(sizeof(struct app_ly_cinfo_234))));
					((((app_ly_cinfo_234_t) CREF(new1641_3761))->approx) = ((approx_t) arg2627_3175), BUNSPEC);
					res2724_3763 = new1641_3761;
				     }
				     arg2626_3174 = res2724_3763;
				  }
			       }
			       {
				  obj_t aux_4403;
				  object_t aux_4401;
				  aux_4403 = (obj_t) (arg2626_3174);
				  aux_4401 = (object_t) (obj2115_3173);
				  OBJECT_WIDENING_SET(aux_4401, aux_4403);
			       }
			    }
			    {
			       long arg2628_3176;
			       arg2628_3176 = class_num_218___object(app_ly_cinfo_234_cfa_info);
			       {
				  obj_t obj_3764;
				  obj_3764 = (obj_t) (obj2115_3173);
				  (((obj_t) CREF(obj_3764))->header = MAKE_HEADER(arg2628_3176, 0), BUNSPEC);
			       }
			    }
			    obj2115_3173;
			 }
			 {
			    approx_t aux_4409;
			    {
			       app_ly_cinfo_234_t obj_3766;
			       obj_3766 = (app_ly_cinfo_234_t) (node_3169);
			       {
				  obj_t aux_4411;
				  {
				     object_t aux_4412;
				     aux_4412 = (object_t) (obj_3766);
				     aux_4411 = OBJECT_WIDENING(aux_4412);
				  }
				  aux_4409 = (((app_ly_cinfo_234_t) CREF(aux_4411))->approx);
			       }
			    }
			    return approx_set_top__187_cfa_approx(aux_4409);
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 funcall_t node_3178;
			 node_3178 = (funcall_t) (node_2);
			 node_setup__189_cfa_setup((((funcall_t) CREF(node_3178))->fun));
			 node_setup___185_cfa_setup((((funcall_t) CREF(node_3178))->args));
			 {
			    funcall_cinfo_75_t obj2117_3182;
			    obj2117_3182 = ((funcall_cinfo_75_t) (node_3178));
			    {
			       funcall_cinfo_75_t arg2632_3183;
			       {
				  approx_t arg2633_3184;
				  approx_t arg2634_3185;
				  bool_t arg2636_3186;
				  bool_t arg2637_3187;
				  arg2633_3184 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
				  arg2634_3185 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
				  if (CBOOL(_warning__61___error))
				    {
				       arg2636_3186 = ((bool_t) 0);
				    }
				  else
				    {
				       arg2636_3186 = ((bool_t) 1);
				    }
				  if (CBOOL(_warning__61___error))
				    {
				       arg2637_3187 = ((bool_t) 0);
				    }
				  else
				    {
				       arg2637_3187 = ((bool_t) 1);
				    }
				  {
				     funcall_cinfo_75_t res2725_3778;
				     {
					funcall_cinfo_75_t new1650_3773;
					new1650_3773 = ((funcall_cinfo_75_t) BREF(GC_MALLOC(sizeof(struct funcall_cinfo_75))));
					((((funcall_cinfo_75_t) CREF(new1650_3773))->approx) = ((approx_t) arg2633_3184), BUNSPEC);
					((((funcall_cinfo_75_t) CREF(new1650_3773))->va_approx_63) = ((approx_t) arg2634_3185), BUNSPEC);
					((((funcall_cinfo_75_t) CREF(new1650_3773))->arity_error_noticed__118) = ((bool_t) arg2636_3186), BUNSPEC);
					((((funcall_cinfo_75_t) CREF(new1650_3773))->type_error_noticed__36) = ((bool_t) arg2637_3187), BUNSPEC);
					res2725_3778 = new1650_3773;
				     }
				     arg2632_3183 = res2725_3778;
				  }
			       }
			       {
				  obj_t aux_4438;
				  object_t aux_4436;
				  aux_4438 = (obj_t) (arg2632_3183);
				  aux_4436 = (object_t) (obj2117_3182);
				  OBJECT_WIDENING_SET(aux_4436, aux_4438);
			       }
			    }
			    {
			       long arg2638_3188;
			       arg2638_3188 = class_num_218___object(funcall_cinfo_75_cfa_info);
			       {
				  obj_t obj_3779;
				  obj_3779 = (obj_t) (obj2117_3182);
				  (((obj_t) CREF(obj_3779))->header = MAKE_HEADER(arg2638_3188, 0), BUNSPEC);
			       }
			    }
			    obj2117_3182;
			 }
			 {
			    approx_t aux_4444;
			    {
			       funcall_cinfo_75_t obj_3781;
			       obj_3781 = (funcall_cinfo_75_t) (node_3178);
			       {
				  obj_t aux_4446;
				  {
				     object_t aux_4447;
				     aux_4447 = (object_t) (obj_3781);
				     aux_4446 = OBJECT_WIDENING(aux_4447);
				  }
				  aux_4444 = (((funcall_cinfo_75_t) CREF(aux_4446))->va_approx_63);
			       }
			    }
			    return approx_set_top__187_cfa_approx(aux_4444);
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 pragma_t node_3190;
			 node_3190 = (pragma_t) (node_2);
			 node_setup___185_cfa_setup((((pragma_t) CREF(node_3190))->args));
			 {
			    pragma_cinfo_220_t obj2119_3193;
			    obj2119_3193 = ((pragma_cinfo_220_t) (node_3190));
			    {
			       pragma_cinfo_220_t arg2642_3194;
			       {
				  approx_t arg2643_3195;
				  arg2643_3195 = make_type_approx_184_cfa_approx((((pragma_t) CREF(node_3190))->type));
				  {
				     pragma_cinfo_220_t res2726_3787;
				     {
					pragma_cinfo_220_t new1665_3785;
					new1665_3785 = ((pragma_cinfo_220_t) BREF(GC_MALLOC(sizeof(struct pragma_cinfo_220))));
					((((pragma_cinfo_220_t) CREF(new1665_3785))->approx) = ((approx_t) arg2643_3195), BUNSPEC);
					res2726_3787 = new1665_3785;
				     }
				     arg2642_3194 = res2726_3787;
				  }
			       }
			       {
				  obj_t aux_4462;
				  object_t aux_4460;
				  aux_4462 = (obj_t) (arg2642_3194);
				  aux_4460 = (object_t) (obj2119_3193);
				  OBJECT_WIDENING_SET(aux_4460, aux_4462);
			       }
			    }
			    {
			       long arg2645_3197;
			       arg2645_3197 = class_num_218___object(pragma_cinfo_220_cfa_info);
			       {
				  obj_t obj_3788;
				  obj_3788 = (obj_t) (obj2119_3193);
				  (((obj_t) CREF(obj_3788))->header = MAKE_HEADER(arg2645_3197, 0), BUNSPEC);
			       }
			    }
			    obj2119_3193;
			 }
			 {
			    approx_t aux_4468;
			    {
			       pragma_cinfo_220_t obj_3790;
			       obj_3790 = (pragma_cinfo_220_t) (node_3190);
			       {
				  obj_t aux_4470;
				  {
				     object_t aux_4471;
				     aux_4471 = (object_t) (obj_3790);
				     aux_4470 = OBJECT_WIDENING(aux_4471);
				  }
				  aux_4468 = (((pragma_cinfo_220_t) CREF(aux_4470))->approx);
			       }
			    }
			    return approx_set_top__187_cfa_approx(aux_4468);
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 cast_t node_3199;
			 node_3199 = (cast_t) (node_2);
			 {
			    node_t node_4477;
			    node_4477 = (((cast_t) CREF(node_3199))->arg);
			    node_2 = node_4477;
			    goto node_setup__189_cfa_setup;
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 setq_t node_3202;
			 node_3202 = (setq_t) (node_2);
			 node_setup__189_cfa_setup((((setq_t) CREF(node_3202))->value));
			 {
			    node_t aux_4482;
			    {
			       var_t aux_4483;
			       aux_4483 = (((setq_t) CREF(node_3202))->var);
			       aux_4482 = (node_t) (aux_4483);
			    }
			    node_setup__189_cfa_setup(aux_4482);
			 }
			 {
			    setq_cinfo_191_t obj2122_3206;
			    obj2122_3206 = ((setq_cinfo_191_t) (node_3202));
			    {
			       setq_cinfo_191_t arg2650_3207;
			       {
				  approx_t arg2651_3208;
				  arg2651_3208 = make_type_approx_184_cfa_approx((type_t) (_unspec__87_type_cache));
				  {
				     setq_cinfo_191_t res2727_3797;
				     {
					setq_cinfo_191_t new1675_3795;
					new1675_3795 = ((setq_cinfo_191_t) BREF(GC_MALLOC(sizeof(struct setq_cinfo_191))));
					((((setq_cinfo_191_t) CREF(new1675_3795))->approx) = ((approx_t) arg2651_3208), BUNSPEC);
					res2727_3797 = new1675_3795;
				     }
				     arg2650_3207 = res2727_3797;
				  }
			       }
			       {
				  obj_t aux_4494;
				  object_t aux_4492;
				  aux_4494 = (obj_t) (arg2650_3207);
				  aux_4492 = (object_t) (obj2122_3206);
				  OBJECT_WIDENING_SET(aux_4492, aux_4494);
			       }
			    }
			    {
			       long arg2652_3209;
			       arg2652_3209 = class_num_218___object(setq_cinfo_191_cfa_info);
			       {
				  obj_t obj_3798;
				  obj_3798 = (obj_t) (obj2122_3206);
				  (((obj_t) CREF(obj_3798))->header = MAKE_HEADER(arg2652_3209, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj2122_3206);
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 conditional_t node_3210;
			 node_3210 = (conditional_t) (node_2);
			 node_setup__189_cfa_setup((((conditional_t) CREF(node_3210))->test));
			 node_setup__189_cfa_setup((((conditional_t) CREF(node_3210))->true));
			 node_setup__189_cfa_setup((((conditional_t) CREF(node_3210))->false));
			 {
			    conditional_cinfo_212_t obj2124_3215;
			    obj2124_3215 = ((conditional_cinfo_212_t) (node_3210));
			    {
			       conditional_cinfo_212_t arg2656_3216;
			       {
				  approx_t arg2657_3217;
				  arg2657_3217 = make_empty_approx_131_cfa_approx();
				  {
				     conditional_cinfo_212_t res2728_3806;
				     {
					conditional_cinfo_212_t new1684_3804;
					new1684_3804 = ((conditional_cinfo_212_t) BREF(GC_MALLOC(sizeof(struct conditional_cinfo_212))));
					((((conditional_cinfo_212_t) CREF(new1684_3804))->approx) = ((approx_t) arg2657_3217), BUNSPEC);
					res2728_3806 = new1684_3804;
				     }
				     arg2656_3216 = res2728_3806;
				  }
			       }
			       {
				  obj_t aux_4514;
				  object_t aux_4512;
				  aux_4514 = (obj_t) (arg2656_3216);
				  aux_4512 = (object_t) (obj2124_3215);
				  OBJECT_WIDENING_SET(aux_4512, aux_4514);
			       }
			    }
			    {
			       long arg2658_3218;
			       arg2658_3218 = class_num_218___object(conditional_cinfo_212_cfa_info);
			       {
				  obj_t obj_3807;
				  obj_3807 = (obj_t) (obj2124_3215);
				  (((obj_t) CREF(obj_3807))->header = MAKE_HEADER(arg2658_3218, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj2124_3215);
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 fail_t node_3219;
			 node_3219 = (fail_t) (node_2);
			 node_setup__189_cfa_setup((((fail_t) CREF(node_3219))->proc));
			 node_setup__189_cfa_setup((((fail_t) CREF(node_3219))->msg));
			 node_setup__189_cfa_setup((((fail_t) CREF(node_3219))->obj));
			 {
			    fail_cinfo_75_t obj2126_3224;
			    obj2126_3224 = ((fail_cinfo_75_t) (node_3219));
			    {
			       fail_cinfo_75_t arg2662_3225;
			       {
				  approx_t arg2663_3226;
				  arg2663_3226 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
				  {
				     fail_cinfo_75_t res2729_3815;
				     {
					fail_cinfo_75_t new1696_3813;
					new1696_3813 = ((fail_cinfo_75_t) BREF(GC_MALLOC(sizeof(struct fail_cinfo_75))));
					((((fail_cinfo_75_t) CREF(new1696_3813))->approx) = ((approx_t) arg2663_3226), BUNSPEC);
					res2729_3815 = new1696_3813;
				     }
				     arg2662_3225 = res2729_3815;
				  }
			       }
			       {
				  obj_t aux_4535;
				  object_t aux_4533;
				  aux_4535 = (obj_t) (arg2662_3225);
				  aux_4533 = (object_t) (obj2126_3224);
				  OBJECT_WIDENING_SET(aux_4533, aux_4535);
			       }
			    }
			    {
			       long arg2664_3227;
			       arg2664_3227 = class_num_218___object(fail_cinfo_75_cfa_info);
			       {
				  obj_t obj_3816;
				  obj_3816 = (obj_t) (obj2126_3224);
				  (((obj_t) CREF(obj_3816))->header = MAKE_HEADER(arg2664_3227, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj2126_3224);
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 select_t node_3228;
			 node_3228 = (select_t) (node_2);
			 node_setup__189_cfa_setup((((select_t) CREF(node_3228))->test));
			 {
			    obj_t l2128_3231;
			    l2128_3231 = (((select_t) CREF(node_3228))->clauses);
			  lname2129_3232:
			    if (PAIRP(l2128_3231))
			      {
				 {
				    node_t aux_4547;
				    {
				       obj_t aux_4548;
				       {
					  obj_t aux_4549;
					  aux_4549 = CAR(l2128_3231);
					  aux_4548 = CDR(aux_4549);
				       }
				       aux_4547 = (node_t) (aux_4548);
				    }
				    node_setup__189_cfa_setup(aux_4547);
				 }
				 {
				    obj_t l2128_4554;
				    l2128_4554 = CDR(l2128_3231);
				    l2128_3231 = l2128_4554;
				    goto lname2129_3232;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    select_cinfo_150_t obj2131_3238;
			    obj2131_3238 = ((select_cinfo_150_t) (node_3228));
			    {
			       select_cinfo_150_t arg2670_3239;
			       {
				  approx_t arg2671_3240;
				  arg2671_3240 = make_empty_approx_131_cfa_approx();
				  {
				     select_cinfo_150_t res2730_3827;
				     {
					select_cinfo_150_t new1706_3825;
					new1706_3825 = ((select_cinfo_150_t) BREF(GC_MALLOC(sizeof(struct select_cinfo_150))));
					((((select_cinfo_150_t) CREF(new1706_3825))->approx) = ((approx_t) arg2671_3240), BUNSPEC);
					res2730_3827 = new1706_3825;
				     }
				     arg2670_3239 = res2730_3827;
				  }
			       }
			       {
				  obj_t aux_4563;
				  object_t aux_4561;
				  aux_4563 = (obj_t) (arg2670_3239);
				  aux_4561 = (object_t) (obj2131_3238);
				  OBJECT_WIDENING_SET(aux_4561, aux_4563);
			       }
			    }
			    {
			       long arg2672_3241;
			       arg2672_3241 = class_num_218___object(select_cinfo_150_cfa_info);
			       {
				  obj_t obj_3828;
				  obj_3828 = (obj_t) (obj2131_3238);
				  (((obj_t) CREF(obj_3828))->header = MAKE_HEADER(arg2672_3241, 0), BUNSPEC);
			       }
			    }
			    return (obj_t) (obj2131_3238);
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 let_fun_218_t node_3242;
			 node_3242 = (let_fun_218_t) (node_2);
			 {
			    obj_t l2133_3244;
			    l2133_3244 = (((let_fun_218_t) CREF(node_3242))->locals);
			  lname2134_3245:
			    if (PAIRP(l2133_3244))
			      {
				 {
				    obj_t l_3248;
				    l_3248 = CAR(l2133_3244);
				    {
				       reshaped_local_224_t obj2135_3249;
				       obj2135_3249 = ((reshaped_local_224_t) (l_3248));
				       {
					  reshaped_local_224_t arg2675_3250;
					  {
					     reshaped_local_224_t res2731_3836;
					     {
						obj_t binding_value_3_3833;
						binding_value_3_3833 = BFALSE;
						{
						   reshaped_local_224_t new1588_3834;
						   new1588_3834 = ((reshaped_local_224_t) BREF(GC_MALLOC(sizeof(struct reshaped_local_224))));
						   ((((reshaped_local_224_t) CREF(new1588_3834))->binding_value_3) = ((obj_t) binding_value_3_3833), BUNSPEC);
						   res2731_3836 = new1588_3834;
						}
					     }
					     arg2675_3250 = res2731_3836;
					  }
					  {
					     obj_t aux_4579;
					     object_t aux_4577;
					     aux_4579 = (obj_t) (arg2675_3250);
					     aux_4577 = (object_t) (obj2135_3249);
					     OBJECT_WIDENING_SET(aux_4577, aux_4579);
					  }
				       }
				       {
					  long arg2676_3251;
					  arg2676_3251 = class_num_218___object(reshaped_local_224_cfa_info);
					  {
					     obj_t obj_3837;
					     obj_3837 = (obj_t) (obj2135_3249);
					     (((obj_t) CREF(obj_3837))->header = MAKE_HEADER(arg2676_3251, 0), BUNSPEC);
					  }
				       }
				       obj2135_3249;
				    }
				    {
				       value_t fun_3252;
				       {
					  local_t obj_3839;
					  obj_3839 = (local_t) (l_3248);
					  fun_3252 = (((local_t) CREF(obj_3839))->value);
				       }
				       {
					  obj_t l2136_3253;
					  {
					     sfun_t obj_3840;
					     obj_3840 = (sfun_t) (fun_3252);
					     l2136_3253 = (((sfun_t) CREF(obj_3840))->args);
					  }
					lname2137_3254:
					  if (PAIRP(l2136_3253))
					    {
					       {
						  obj_t local_3257;
						  local_3257 = CAR(l2136_3253);
						  {
						     reshaped_local_224_t obj2138_3258;
						     obj2138_3258 = ((reshaped_local_224_t) (local_3257));
						     {
							reshaped_local_224_t arg2679_3259;
							{
							   reshaped_local_224_t res2732_3846;
							   {
							      obj_t binding_value_3_3843;
							      binding_value_3_3843 = BFALSE;
							      {
								 reshaped_local_224_t new1588_3844;
								 new1588_3844 = ((reshaped_local_224_t) BREF(GC_MALLOC(sizeof(struct reshaped_local_224))));
								 ((((reshaped_local_224_t) CREF(new1588_3844))->binding_value_3) = ((obj_t) binding_value_3_3843), BUNSPEC);
								 res2732_3846 = new1588_3844;
							      }
							   }
							   arg2679_3259 = res2732_3846;
							}
							{
							   obj_t aux_4595;
							   object_t aux_4593;
							   aux_4595 = (obj_t) (arg2679_3259);
							   aux_4593 = (object_t) (obj2138_3258);
							   OBJECT_WIDENING_SET(aux_4593, aux_4595);
							}
						     }
						     {
							long arg2680_3260;
							arg2680_3260 = class_num_218___object(reshaped_local_224_cfa_info);
							{
							   obj_t obj_3847;
							   obj_3847 = (obj_t) (obj2138_3258);
							   (((obj_t) CREF(obj_3847))->header = MAKE_HEADER(arg2680_3260, 0), BUNSPEC);
							}
						     }
						     obj2138_3258;
						  }
						  {
						     value_t aux_4601;
						     {
							local_t obj_3849;
							obj_3849 = (local_t) (local_3257);
							aux_4601 = (((local_t) CREF(obj_3849))->value);
						     }
						     variable_value_setup__80_cfa_setup(aux_4601, (variable_t) (local_3257));
						  }
					       }
					       {
						  obj_t l2136_4606;
						  l2136_4606 = CDR(l2136_3253);
						  l2136_3253 = l2136_4606;
						  goto lname2137_3254;
					       }
					    }
					  else
					    {
					       ((bool_t) 1);
					    }
				       }
				       {
					  node_t aux_4610;
					  {
					     obj_t aux_4611;
					     {
						sfun_t obj_3851;
						obj_3851 = (sfun_t) (fun_3252);
						aux_4611 = (((sfun_t) CREF(obj_3851))->body);
					     }
					     aux_4610 = (node_t) (aux_4611);
					  }
					  node_setup__189_cfa_setup(aux_4610);
				       }
				    }
				 }
				 {
				    obj_t l2133_4616;
				    l2133_4616 = CDR(l2133_3244);
				    l2133_3244 = l2133_4616;
				    goto lname2134_3245;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_4619;
			    node_4619 = (((let_fun_218_t) CREF(node_3242))->body);
			    node_2 = node_4619;
			    goto node_setup__189_cfa_setup;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 let_var_6_t node_3266;
			 node_3266 = (let_var_6_t) (node_2);
			 {
			    obj_t l2140_3268;
			    l2140_3268 = (((let_var_6_t) CREF(node_3266))->bindings);
			  lname2141_3269:
			    if (PAIRP(l2140_3268))
			      {
				 {
				    obj_t binding_3272;
				    binding_3272 = CAR(l2140_3268);
				    {
				       obj_t var_3273;
				       obj_t val_3274;
				       var_3273 = CAR(binding_3272);
				       val_3274 = CDR(binding_3272);
				       {
					  value_t aux_4627;
					  {
					     local_t obj_3859;
					     obj_3859 = (local_t) (var_3273);
					     aux_4627 = (((local_t) CREF(obj_3859))->value);
					  }
					  variable_value_setup__80_cfa_setup(aux_4627, (variable_t) (var_3273));
				       }
				       {
					  reshaped_local_224_t obj2142_3276;
					  obj2142_3276 = ((reshaped_local_224_t) (var_3273));
					  {
					     reshaped_local_224_t arg2691_3277;
					     {
						obj_t arg2692_3278;
						{
						   bool_t test_4633;
						   {
						      obj_t aux_4637;
						      obj_t aux_4634;
						      aux_4637 = CNST_TABLE_REF(((long) 0));
						      {
							 local_t obj_3860;
							 obj_3860 = (local_t) (var_3273);
							 aux_4634 = (((local_t) CREF(obj_3860))->access);
						      }
						      test_4633 = (aux_4634 == aux_4637);
						   }
						   if (test_4633)
						     {
							arg2692_3278 = val_3274;
						     }
						   else
						     {
							arg2692_3278 = BFALSE;
						     }
						}
						{
						   reshaped_local_224_t res2733_3866;
						   {
						      reshaped_local_224_t new1588_3864;
						      new1588_3864 = ((reshaped_local_224_t) BREF(GC_MALLOC(sizeof(struct reshaped_local_224))));
						      ((((reshaped_local_224_t) CREF(new1588_3864))->binding_value_3) = ((obj_t) arg2692_3278), BUNSPEC);
						      res2733_3866 = new1588_3864;
						   }
						   arg2691_3277 = res2733_3866;
						}
					     }
					     {
						obj_t aux_4644;
						object_t aux_4642;
						aux_4644 = (obj_t) (arg2691_3277);
						aux_4642 = (object_t) (obj2142_3276);
						OBJECT_WIDENING_SET(aux_4642, aux_4644);
					     }
					  }
					  {
					     long arg2696_3282;
					     arg2696_3282 = class_num_218___object(reshaped_local_224_cfa_info);
					     {
						obj_t obj_3867;
						obj_3867 = (obj_t) (obj2142_3276);
						(((obj_t) CREF(obj_3867))->header = MAKE_HEADER(arg2696_3282, 0), BUNSPEC);
					     }
					  }
					  obj2142_3276;
				       }
				       node_setup__189_cfa_setup((node_t) (val_3274));
				       BUNSPEC;
				    }
				 }
				 {
				    obj_t l2140_4652;
				    l2140_4652 = CDR(l2140_3268);
				    l2140_3268 = l2140_4652;
				    goto lname2141_3269;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    node_t node_4655;
			    node_4655 = (((let_var_6_t) CREF(node_3266))->body);
			    node_2 = node_4655;
			    goto node_setup__189_cfa_setup;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 set_ex_it_116_t node_3285;
			 node_3285 = (set_ex_it_116_t) (node_2);
			 node_setup__189_cfa_setup((((set_ex_it_116_t) CREF(node_3285))->body));
			 {
			    node_t aux_4660;
			    {
			       var_t aux_4661;
			       aux_4661 = (((set_ex_it_116_t) CREF(node_3285))->var);
			       aux_4660 = (node_t) (aux_4661);
			    }
			    node_setup__189_cfa_setup(aux_4660);
			 }
			 {
			    reshaped_local_224_t obj2144_3289;
			    {
			       variable_t aux_4665;
			       {
				  var_t arg2703_3292;
				  arg2703_3292 = (((set_ex_it_116_t) CREF(node_3285))->var);
				  aux_4665 = (((var_t) CREF(arg2703_3292))->variable);
			       }
			       obj2144_3289 = ((reshaped_local_224_t) (aux_4665));
			    }
			    {
			       reshaped_local_224_t arg2701_3290;
			       {
				  reshaped_local_224_t res2734_3878;
				  {
				     obj_t binding_value_3_3875;
				     binding_value_3_3875 = BFALSE;
				     {
					reshaped_local_224_t new1588_3876;
					new1588_3876 = ((reshaped_local_224_t) BREF(GC_MALLOC(sizeof(struct reshaped_local_224))));
					((((reshaped_local_224_t) CREF(new1588_3876))->binding_value_3) = ((obj_t) binding_value_3_3875), BUNSPEC);
					res2734_3878 = new1588_3876;
				     }
				  }
				  arg2701_3290 = res2734_3878;
			       }
			       {
				  obj_t aux_4673;
				  object_t aux_4671;
				  aux_4673 = (obj_t) (arg2701_3290);
				  aux_4671 = (object_t) (obj2144_3289);
				  OBJECT_WIDENING_SET(aux_4671, aux_4673);
			       }
			    }
			    {
			       long arg2702_3291;
			       arg2702_3291 = class_num_218___object(reshaped_local_224_cfa_info);
			       {
				  obj_t obj_3879;
				  obj_3879 = (obj_t) (obj2144_3289);
				  (((obj_t) CREF(obj_3879))->header = MAKE_HEADER(arg2702_3291, 0), BUNSPEC);
			       }
			    }
			    obj2144_3289;
			 }
			 {
			    set_ex_it_cinfo_168_t obj2145_3293;
			    obj2145_3293 = ((set_ex_it_cinfo_168_t) (node_3285));
			    {
			       set_ex_it_cinfo_168_t arg2704_3294;
			       {
				  approx_t arg2705_3295;
				  arg2705_3295 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
				  {
				     set_ex_it_cinfo_168_t res2735_3884;
				     {
					set_ex_it_cinfo_168_t new1716_3882;
					new1716_3882 = ((set_ex_it_cinfo_168_t) BREF(GC_MALLOC(sizeof(struct set_ex_it_cinfo_168))));
					((((set_ex_it_cinfo_168_t) CREF(new1716_3882))->approx) = ((approx_t) arg2705_3295), BUNSPEC);
					res2735_3884 = new1716_3882;
				     }
				     arg2704_3294 = res2735_3884;
				  }
			       }
			       {
				  obj_t aux_4686;
				  object_t aux_4684;
				  aux_4686 = (obj_t) (arg2704_3294);
				  aux_4684 = (object_t) (obj2145_3293);
				  OBJECT_WIDENING_SET(aux_4684, aux_4686);
			       }
			    }
			    {
			       long arg2706_3296;
			       arg2706_3296 = class_num_218___object(set_ex_it_cinfo_168_cfa_info);
			       {
				  obj_t obj_3885;
				  obj_3885 = (obj_t) (obj2145_3293);
				  (((obj_t) CREF(obj_3885))->header = MAKE_HEADER(arg2706_3296, 0), BUNSPEC);
			       }
			    }
			    obj2145_3293;
			 }
			 {
			    approx_t aux_4692;
			    {
			       set_ex_it_cinfo_168_t obj_3887;
			       obj_3887 = (set_ex_it_cinfo_168_t) (node_3285);
			       {
				  obj_t aux_4694;
				  {
				     object_t aux_4695;
				     aux_4695 = (object_t) (obj_3887);
				     aux_4694 = OBJECT_WIDENING(aux_4695);
				  }
				  aux_4692 = (((set_ex_it_cinfo_168_t) CREF(aux_4694))->approx);
			       }
			    }
			    return approx_set_top__187_cfa_approx(aux_4692);
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 jump_ex_it_184_t node_3298;
			 node_3298 = (jump_ex_it_184_t) (node_2);
			 node_setup__189_cfa_setup((((jump_ex_it_184_t) CREF(node_3298))->exit));
			 node_setup__189_cfa_setup((((jump_ex_it_184_t) CREF(node_3298))->value));
			 {
			    jump_ex_it_cinfo_139_t obj2147_3302;
			    obj2147_3302 = ((jump_ex_it_cinfo_139_t) (node_3298));
			    {
			       jump_ex_it_cinfo_139_t arg2710_3303;
			       {
				  approx_t arg2711_3304;
				  arg2711_3304 = make_type_approx_184_cfa_approx((type_t) (_obj__252_type_cache));
				  {
				     jump_ex_it_cinfo_139_t res2736_3893;
				     {
					jump_ex_it_cinfo_139_t new1725_3891;
					new1725_3891 = ((jump_ex_it_cinfo_139_t) BREF(GC_MALLOC(sizeof(struct jump_ex_it_cinfo_139))));
					((((jump_ex_it_cinfo_139_t) CREF(new1725_3891))->approx) = ((approx_t) arg2711_3304), BUNSPEC);
					res2736_3893 = new1725_3891;
				     }
				     arg2710_3303 = res2736_3893;
				  }
			       }
			       {
				  obj_t aux_4712;
				  object_t aux_4710;
				  aux_4712 = (obj_t) (arg2710_3303);
				  aux_4710 = (object_t) (obj2147_3302);
				  OBJECT_WIDENING_SET(aux_4710, aux_4712);
			       }
			    }
			    {
			       long arg2712_3305;
			       arg2712_3305 = class_num_218___object(jump_ex_it_cinfo_139_cfa_info);
			       {
				  obj_t obj_3894;
				  obj_3894 = (obj_t) (obj2147_3302);
				  (((obj_t) CREF(obj_3894))->header = MAKE_HEADER(arg2712_3305, 0), BUNSPEC);
			       }
			    }
			    obj2147_3302;
			 }
			 {
			    approx_t aux_4718;
			    {
			       jump_ex_it_cinfo_139_t obj_3896;
			       obj_3896 = (jump_ex_it_cinfo_139_t) (node_3298);
			       {
				  obj_t aux_4720;
				  {
				     object_t aux_4721;
				     aux_4721 = (object_t) (obj_3896);
				     aux_4720 = OBJECT_WIDENING(aux_4721);
				  }
				  aux_4718 = (((jump_ex_it_cinfo_139_t) CREF(aux_4720))->approx);
			       }
			    }
			    return approx_set_top__187_cfa_approx(aux_4718);
			 }
		      }
		      break;
		   default:
		    case_else2581_3113:
		      if (PROCEDUREP(method2575_3109))
			{
			   return PROCEDURE_ENTRY(method2575_3109) (method2575_3109, (obj_t) (node_2), BEOA);
			}
		      else
			{
			   obj_t fun2447_2946;
			   fun2447_2946 = PROCEDURE_REF(node_setup__env_214_cfa_setup, ((long) 0));
			   return PROCEDURE_ENTRY(fun2447_2946) (fun2447_2946, (obj_t) (node_2), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2581_3113;
	      }
	 }
      }
   }
}


/* _node-setup!2754 */ obj_t 
_node_setup_2754_217_cfa_setup(obj_t env_4099, obj_t node_4100)
{
   return node_setup__189_cfa_setup((node_t) (node_4100));
}


/* node-setup!-default2150 */ obj_t 
node_setup__default2150_196_cfa_setup(node_t node_3)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string2759_cfa_setup, (obj_t) (node_3));
}


/* _node-setup!-default2150 */ obj_t 
_node_setup__default2150_49_cfa_setup(obj_t env_4101, obj_t node_4102)
{
   return node_setup__default2150_196_cfa_setup((node_t) (node_4102));
}


/* variable-value-setup! */ obj_t 
variable_value_setup__80_cfa_setup(value_t value_9, variable_t variable_10)
{
   {
      obj_t arg2514_3017;
      obj_t arg2515_3018;
      {
	 object_t obj_3904;
	 obj_3904 = (object_t) (value_9);
	 {
	    obj_t pre_method_105_3905;
	    pre_method_105_3905 = PROCEDURE_REF(variable_value_setup__env_134_cfa_setup, ((long) 2));
	    if (INTEGERP(pre_method_105_3905))
	      {
		 PROCEDURE_SET(variable_value_setup__env_134_cfa_setup, ((long) 2), BUNSPEC);
		 arg2514_3017 = pre_method_105_3905;
	      }
	    else
	      {
		 long obj_class_num_177_3910;
		 obj_class_num_177_3910 = TYPE(obj_3904);
		 {
		    obj_t arg1177_3911;
		    arg1177_3911 = PROCEDURE_REF(variable_value_setup__env_134_cfa_setup, ((long) 1));
		    {
		       long arg1178_3915;
		       {
			  long arg1179_3916;
			  arg1179_3916 = OBJECT_TYPE;
			  arg1178_3915 = (obj_class_num_177_3910 - arg1179_3916);
		       }
		       arg2514_3017 = VECTOR_REF(arg1177_3911, arg1178_3915);
		    }
		 }
	      }
	 }
      }
      {
	 object_t object_3921;
	 object_3921 = (object_t) (value_9);
	 {
	    long arg1180_3922;
	    {
	       long arg1181_3923;
	       long arg1182_3924;
	       arg1181_3923 = TYPE(object_3921);
	       arg1182_3924 = OBJECT_TYPE;
	       arg1180_3922 = (arg1181_3923 - arg1182_3924);
	    }
	    {
	       obj_t vector_3928;
	       vector_3928 = _classes__134___object;
	       arg2515_3018 = VECTOR_REF(vector_3928, arg1180_3922);
	    }
	 }
      }
      return loop2506_cfa_setup(variable_10, value_9, arg2514_3017, arg2515_3018);
   }
}


/* case_else2511 */ obj_t 
case_else2511_cfa_setup(variable_t variable_4117, value_t value_4116, obj_t method2505_4115)
{
   if (PROCEDUREP(method2505_4115))
     {
	return PROCEDURE_ENTRY(method2505_4115) (method2505_4115, (obj_t) (value_4116), (obj_t) (variable_4117), BEOA);
     }
   else
     {
	obj_t fun2450_2949;
	fun2450_2949 = PROCEDURE_REF(variable_value_setup__env_134_cfa_setup, ((long) 0));
	return PROCEDURE_ENTRY(fun2450_2949) (fun2450_2949, (obj_t) (value_4116), (obj_t) (variable_4117), BEOA);
     }
}


/* loop2506 */ obj_t 
loop2506_cfa_setup(variable_t variable_4119, value_t value_4118, obj_t method2505_3019, obj_t class2510_3020)
{
   if (INTEGERP(method2505_3019))
     {
	switch ((long) CINT(method2505_3019))
	  {
	  case ((long) 0):
	     return BUNSPEC;
	     break;
	  case ((long) 1):
	     {
		svar_t value_3028;
		value_3028 = (svar_t) (value_4118);
		{
		   bool_t test2518_3030;
		   test2518_3030 = is_a__118___object((obj_t) (variable_4119), global_ast_var);
		   if (test2518_3030)
		     {
			svar_cinfo_166_t value_3031;
			{
			   svar_cinfo_166_t obj2098_3038;
			   obj2098_3038 = ((svar_cinfo_166_t) (value_3028));
			   {
			      svar_cinfo_166_t arg2525_3039;
			      {
				 approx_t arg2526_3040;
				 arg2526_3040 = make_type_approx_184_cfa_approx((((variable_t) CREF(variable_4119))->type));
				 {
				    svar_cinfo_166_t res2738_3937;
				    {
				       svar_cinfo_166_t new1565_3934;
				       new1565_3934 = ((svar_cinfo_166_t) BREF(GC_MALLOC(sizeof(struct svar_cinfo_166))));
				       ((((svar_cinfo_166_t) CREF(new1565_3934))->approx) = ((approx_t) arg2526_3040), BUNSPEC);
				       ((((svar_cinfo_166_t) CREF(new1565_3934))->clo_env__87) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				       res2738_3937 = new1565_3934;
				    }
				    arg2525_3039 = res2738_3937;
				 }
			      }
			      {
				 obj_t aux_4785;
				 object_t aux_4783;
				 aux_4785 = (obj_t) (arg2525_3039);
				 aux_4783 = (object_t) (obj2098_3038);
				 OBJECT_WIDENING_SET(aux_4783, aux_4785);
			      }
			   }
			   {
			      long arg2528_3042;
			      arg2528_3042 = class_num_218___object(svar_cinfo_166_cfa_info);
			      {
				 obj_t obj_3938;
				 obj_3938 = (obj_t) (obj2098_3038);
				 (((obj_t) CREF(obj_3938))->header = MAKE_HEADER(arg2528_3042, 0), BUNSPEC);
			      }
			   }
			   value_3031 = obj2098_3038;
			}
			{
			   bool_t test_4791;
			   {
			      bool_t test_4792;
			      {
				 obj_t aux_4796;
				 obj_t aux_4793;
				 aux_4796 = CNST_TABLE_REF(((long) 2));
				 {
				    global_t obj_3940;
				    obj_3940 = (global_t) (variable_4119);
				    aux_4793 = (((global_t) CREF(obj_3940))->import);
				 }
				 test_4792 = (aux_4793 == aux_4796);
			      }
			      if (test_4792)
				{
				   test_4791 = ((bool_t) 0);
				}
			      else
				{
				   test_4791 = alloc_type__187_cfa_setup((((variable_t) CREF(variable_4119))->type));
				}
			   }
			   if (test_4791)
			     {
				approx_t aux_4801;
				{
				   obj_t aux_4802;
				   {
				      object_t aux_4803;
				      aux_4803 = (object_t) (value_3031);
				      aux_4802 = OBJECT_WIDENING(aux_4803);
				   }
				   aux_4801 = (((svar_cinfo_166_t) CREF(aux_4802))->approx);
				}
				return approx_set_top__187_cfa_approx(aux_4801);
			     }
			   else
			     {
				return BUNSPEC;
			     }
			}
		     }
		   else
		     {
			svar_cinfo_166_t obj2099_3043;
			obj2099_3043 = ((svar_cinfo_166_t) (value_3028));
			{
			   svar_cinfo_166_t arg2529_3044;
			   {
			      approx_t arg2530_3045;
			      arg2530_3045 = make_type_approx_184_cfa_approx((((variable_t) CREF(variable_4119))->type));
			      {
				 svar_cinfo_166_t res2739_3951;
				 {
				    svar_cinfo_166_t new1565_3948;
				    new1565_3948 = ((svar_cinfo_166_t) BREF(GC_MALLOC(sizeof(struct svar_cinfo_166))));
				    ((((svar_cinfo_166_t) CREF(new1565_3948))->approx) = ((approx_t) arg2530_3045), BUNSPEC);
				    ((((svar_cinfo_166_t) CREF(new1565_3948))->clo_env__87) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				    res2739_3951 = new1565_3948;
				 }
				 arg2529_3044 = res2739_3951;
			      }
			   }
			   {
			      obj_t aux_4816;
			      object_t aux_4814;
			      aux_4816 = (obj_t) (arg2529_3044);
			      aux_4814 = (object_t) (obj2099_3043);
			      OBJECT_WIDENING_SET(aux_4814, aux_4816);
			   }
			}
			{
			   long arg2532_3047;
			   arg2532_3047 = class_num_218___object(svar_cinfo_166_cfa_info);
			   {
			      obj_t obj_3952;
			      obj_3952 = (obj_t) (obj2099_3043);
			      (((obj_t) CREF(obj_3952))->header = MAKE_HEADER(arg2532_3047, 0), BUNSPEC);
			   }
			}
			return (obj_t) (obj2099_3043);
		     }
		}
	     }
	     break;
	  case ((long) 2):
	     call_next_method_114_cfa_setup(value_4118, class2510_3020, variable_4119);
	     {
		svar_cinfo_166_t obj_3955;
		{
		   value_t aux_4824;
		   {
		      local_t obj_3954;
		      obj_3954 = (local_t) (variable_4119);
		      aux_4824 = (((local_t) CREF(obj_3954))->value);
		   }
		   obj_3955 = (svar_cinfo_166_t) (aux_4824);
		}
		{
		   obj_t aux_4828;
		   {
		      object_t aux_4829;
		      aux_4829 = (object_t) (obj_3955);
		      aux_4828 = OBJECT_WIDENING(aux_4829);
		   }
		   return ((((svar_cinfo_166_t) CREF(aux_4828))->clo_env__87) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		}
	     }
	     break;
	  case ((long) 3):
	     {
		sexit_t value_3051;
		value_3051 = (sexit_t) (value_4118);
		{
		   sexit_cinfo_49_t obj2100_3053;
		   obj2100_3053 = ((sexit_cinfo_49_t) (value_3051));
		   {
		      sexit_cinfo_49_t arg2534_3054;
		      {
			 approx_t arg2535_3055;
			 arg2535_3055 = make_type_approx_184_cfa_approx((((variable_t) CREF(variable_4119))->type));
			 {
			    sexit_cinfo_49_t res2740_3961;
			    {
			       sexit_cinfo_49_t new1580_3959;
			       new1580_3959 = ((sexit_cinfo_49_t) BREF(GC_MALLOC(sizeof(struct sexit_cinfo_49))));
			       ((((sexit_cinfo_49_t) CREF(new1580_3959))->approx) = ((approx_t) arg2535_3055), BUNSPEC);
			       res2740_3961 = new1580_3959;
			    }
			    arg2534_3054 = res2740_3961;
			 }
		      }
		      {
			 obj_t aux_4841;
			 object_t aux_4839;
			 aux_4841 = (obj_t) (arg2534_3054);
			 aux_4839 = (object_t) (obj2100_3053);
			 OBJECT_WIDENING_SET(aux_4839, aux_4841);
		      }
		   }
		   {
		      long arg2537_3057;
		      arg2537_3057 = class_num_218___object(sexit_cinfo_49_cfa_info);
		      {
			 obj_t obj_3962;
			 obj_3962 = (obj_t) (obj2100_3053);
			 (((obj_t) CREF(obj_3962))->header = MAKE_HEADER(arg2537_3057, 0), BUNSPEC);
		      }
		   }
		   return (obj_t) (obj2100_3053);
		}
	     }
	     break;
	  case ((long) 4):
	     return CNST_TABLE_REF(((long) 3));
	     break;
	  case ((long) 5):
	     {
		scnst_t value_3060;
		value_3060 = (scnst_t) (value_4118);
		{
		   bool_t test2538_3062;
		   test2538_3062 = is_a__118___object((obj_t) (variable_4119), global_ast_var);
		   if (test2538_3062)
		     {
			bool_t test2539_3063;
			{
			   bool_t test2548_3076;
			   {
			      obj_t obj2_3967;
			      obj2_3967 = _module__166_module_module;
			      {
				 obj_t aux_4853;
				 {
				    global_t obj_3965;
				    obj_3965 = (global_t) (variable_4119);
				    aux_4853 = (((global_t) CREF(obj_3965))->module);
				 }
				 test2548_3076 = (aux_4853 == obj2_3967);
			      }
			   }
			   if (test2548_3076)
			     {
				bool_t test_4858;
				{
				   obj_t aux_4859;
				   aux_4859 = memq___r4_pairs_and_lists_6_3((((scnst_t) CREF(value_3060))->class), CNST_TABLE_REF(((long) 4)));
				   test_4858 = CBOOL(aux_4859);
				}
				if (test_4858)
				  {
				     test2539_3063 = is_a__118___object((((scnst_t) CREF(value_3060))->node), pre_make_procedure_app_60_cfa_info);
				  }
				else
				  {
				     test2539_3063 = ((bool_t) 0);
				  }
			     }
			   else
			     {
				test2539_3063 = ((bool_t) 0);
			     }
			}
			if (test2539_3063)
			  {
			     obj_t node_3064;
			     node_3064 = (((scnst_t) CREF(value_3060))->node);
			     node_setup__189_cfa_setup((node_t) (node_3064));
			     {
				scnst_cinfo_0_t obj2101_3065;
				obj2101_3065 = ((scnst_cinfo_0_t) (value_3060));
				{
				   scnst_cinfo_0_t arg2540_3066;
				   {
				      approx_t arg2541_3067;
				      {
					 make_procedure_app_48_t obj_3972;
					 obj_3972 = (make_procedure_app_48_t) (node_3064);
					 {
					    obj_t aux_4872;
					    {
					       object_t aux_4873;
					       aux_4873 = (object_t) (obj_3972);
					       aux_4872 = OBJECT_WIDENING(aux_4873);
					    }
					    arg2541_3067 = (((make_procedure_app_48_t) CREF(aux_4872))->approx);
					 }
				      }
				      {
					 scnst_cinfo_0_t res2741_3976;
					 {
					    scnst_cinfo_0_t new1551_3974;
					    new1551_3974 = ((scnst_cinfo_0_t) BREF(GC_MALLOC(sizeof(struct scnst_cinfo_0))));
					    ((((scnst_cinfo_0_t) CREF(new1551_3974))->approx) = ((approx_t) arg2541_3067), BUNSPEC);
					    res2741_3976 = new1551_3974;
					 }
					 arg2540_3066 = res2741_3976;
				      }
				   }
				   {
				      obj_t aux_4881;
				      object_t aux_4879;
				      aux_4881 = (obj_t) (arg2540_3066);
				      aux_4879 = (object_t) (obj2101_3065);
				      OBJECT_WIDENING_SET(aux_4879, aux_4881);
				   }
				}
				{
				   long arg2542_3068;
				   arg2542_3068 = class_num_218___object(scnst_cinfo_0_cfa_info);
				   {
				      obj_t obj_3977;
				      obj_3977 = (obj_t) (obj2101_3065);
				      (((obj_t) CREF(obj_3977))->header = MAKE_HEADER(arg2542_3068, 0), BUNSPEC);
				   }
				}
				return (obj_t) (obj2101_3065);
			     }
			  }
			else
			  {
			     scnst_cinfo_0_t value_3069;
			     {
				scnst_cinfo_0_t obj2102_3071;
				obj2102_3071 = ((scnst_cinfo_0_t) (value_3060));
				{
				   scnst_cinfo_0_t arg2544_3072;
				   {
				      approx_t arg2545_3073;
				      arg2545_3073 = make_type_approx_184_cfa_approx((((variable_t) CREF(variable_4119))->type));
				      {
					 scnst_cinfo_0_t res2742_3983;
					 {
					    scnst_cinfo_0_t new1551_3981;
					    new1551_3981 = ((scnst_cinfo_0_t) BREF(GC_MALLOC(sizeof(struct scnst_cinfo_0))));
					    ((((scnst_cinfo_0_t) CREF(new1551_3981))->approx) = ((approx_t) arg2545_3073), BUNSPEC);
					    res2742_3983 = new1551_3981;
					 }
					 arg2544_3072 = res2742_3983;
				      }
				   }
				   {
				      obj_t aux_4895;
				      object_t aux_4893;
				      aux_4895 = (obj_t) (arg2544_3072);
				      aux_4893 = (object_t) (obj2102_3071);
				      OBJECT_WIDENING_SET(aux_4893, aux_4895);
				   }
				}
				{
				   long arg2547_3075;
				   arg2547_3075 = class_num_218___object(scnst_cinfo_0_cfa_info);
				   {
				      obj_t obj_3984;
				      obj_3984 = (obj_t) (obj2102_3071);
				      (((obj_t) CREF(obj_3984))->header = MAKE_HEADER(arg2547_3075, 0), BUNSPEC);
				   }
				}
				value_3069 = obj2102_3071;
			     }
			     {
				approx_t aux_4901;
				{
				   obj_t aux_4902;
				   {
				      object_t aux_4903;
				      aux_4903 = (object_t) (value_3069);
				      aux_4902 = OBJECT_WIDENING(aux_4903);
				   }
				   aux_4901 = (((scnst_cinfo_0_t) CREF(aux_4902))->approx);
				}
				return approx_set_top__187_cfa_approx(aux_4901);
			     }
			  }
		     }
		   else
		     {
			scnst_cinfo_0_t obj2103_3082;
			obj2103_3082 = ((scnst_cinfo_0_t) (value_3060));
			{
			   scnst_cinfo_0_t arg2555_3083;
			   {
			      approx_t arg2556_3084;
			      arg2556_3084 = make_type_approx_184_cfa_approx((((variable_t) CREF(variable_4119))->type));
			      {
				 scnst_cinfo_0_t res2743_3991;
				 {
				    scnst_cinfo_0_t new1551_3989;
				    new1551_3989 = ((scnst_cinfo_0_t) BREF(GC_MALLOC(sizeof(struct scnst_cinfo_0))));
				    ((((scnst_cinfo_0_t) CREF(new1551_3989))->approx) = ((approx_t) arg2556_3084), BUNSPEC);
				    res2743_3991 = new1551_3989;
				 }
				 arg2555_3083 = res2743_3991;
			      }
			   }
			   {
			      obj_t aux_4915;
			      object_t aux_4913;
			      aux_4915 = (obj_t) (arg2555_3083);
			      aux_4913 = (object_t) (obj2103_3082);
			      OBJECT_WIDENING_SET(aux_4913, aux_4915);
			   }
			}
			{
			   long arg2558_3086;
			   arg2558_3086 = class_num_218___object(scnst_cinfo_0_cfa_info);
			   {
			      obj_t obj_3992;
			      obj_3992 = (obj_t) (obj2103_3082);
			      (((obj_t) CREF(obj_3992))->header = MAKE_HEADER(arg2558_3086, 0), BUNSPEC);
			   }
			}
			return (obj_t) (obj2103_3082);
		     }
		}
	     }
	     break;
	  case ((long) 6):
	     {
		cvar_t value_3087;
		value_3087 = (cvar_t) (value_4118);
		{
		   cvar_cinfo_53_t obj2104_3089;
		   obj2104_3089 = ((cvar_cinfo_53_t) (value_3087));
		   {
		      cvar_cinfo_53_t arg2559_3090;
		      {
			 approx_t arg2560_3091;
			 arg2560_3091 = make_type_approx_184_cfa_approx((((variable_t) CREF(variable_4119))->type));
			 {
			    cvar_cinfo_53_t res2744_3998;
			    {
			       cvar_cinfo_53_t new1574_3996;
			       new1574_3996 = ((cvar_cinfo_53_t) BREF(GC_MALLOC(sizeof(struct cvar_cinfo_53))));
			       ((((cvar_cinfo_53_t) CREF(new1574_3996))->approx) = ((approx_t) arg2560_3091), BUNSPEC);
			       res2744_3998 = new1574_3996;
			    }
			    arg2559_3090 = res2744_3998;
			 }
		      }
		      {
			 obj_t aux_4930;
			 object_t aux_4928;
			 aux_4930 = (obj_t) (arg2559_3090);
			 aux_4928 = (object_t) (obj2104_3089);
			 OBJECT_WIDENING_SET(aux_4928, aux_4930);
		      }
		   }
		   {
		      long arg2562_3093;
		      arg2562_3093 = class_num_218___object(cvar_cinfo_53_cfa_info);
		      {
			 obj_t obj_3999;
			 obj_3999 = (obj_t) (obj2104_3089);
			 (((obj_t) CREF(obj_3999))->header = MAKE_HEADER(arg2562_3093, 0), BUNSPEC);
		      }
		   }
		   obj2104_3089;
		}
		if (alloc_type__187_cfa_setup((((variable_t) CREF(variable_4119))->type)))
		  {
		     approx_t aux_4939;
		     {
			cvar_cinfo_53_t obj_4002;
			obj_4002 = (cvar_cinfo_53_t) (value_3087);
			{
			   obj_t aux_4941;
			   {
			      object_t aux_4942;
			      aux_4942 = (object_t) (obj_4002);
			      aux_4941 = OBJECT_WIDENING(aux_4942);
			   }
			   aux_4939 = (((cvar_cinfo_53_t) CREF(aux_4941))->approx);
			}
		     }
		     return approx_set_top__187_cfa_approx(aux_4939);
		  }
		else
		  {
		     return BUNSPEC;
		  }
	     }
	     break;
	  default:
	     return case_else2511_cfa_setup(variable_4119, value_4118, method2505_3019);
	  }
     }
   else
     {
	return case_else2511_cfa_setup(variable_4119, value_4118, method2505_3019);
     }
}


/* call-next-method */ obj_t 
call_next_method_114_cfa_setup(value_t value_4122, obj_t class2510_4121, variable_t variable_4120)
{
   {
      obj_t aux2508_3100;
      {
	 obj_t aux_4951;
	 {
	    bool_t test_4953;
	    if (VECTORP(class2510_4121))
	      {
		 long aux_4956;
		 aux_4956 = VECTOR_LENGTH(class2510_4121);
		 test_4953 = (aux_4956 == ((long) 10));
	      }
	    else
	      {
		 test_4953 = ((bool_t) 0);
	      }
	    if (test_4953)
	      {
		 aux_4951 = class_super_145___object(class2510_4121);
	      }
	    else
	      {
		 aux_4951 = BFALSE;
	      }
	 }
	 aux2508_3100 = find_method_from_44___object((object_t) (value_4122), variable_value_setup__env_134_cfa_setup, aux_4951);
      }
      {
	 return loop2506_cfa_setup(variable_4120, value_4122, CDR(aux2508_3100), CAR(aux2508_3100));
      }
   }
}


/* _variable-value-setup!2755 */ obj_t 
_variable_value_setup_2755_247_cfa_setup(obj_t env_4103, obj_t value_4104, obj_t variable_4105)
{
   return variable_value_setup__80_cfa_setup((value_t) (value_4104), (variable_t) (variable_4105));
}


/* variable-value-setup!-default2155 */ obj_t 
variable_value_setup__default2155_228_cfa_setup(value_t value_11, variable_t variable_12)
{
   FAILURE(CNST_TABLE_REF(((long) 5)), string2759_cfa_setup, (obj_t) (value_11));
}


/* _variable-value-setup!-default2155 */ obj_t 
_variable_value_setup__default2155_55_cfa_setup(obj_t env_4106, obj_t value_4107, obj_t variable_4108)
{
   return variable_value_setup__default2155_228_cfa_setup((value_t) (value_4107), (variable_t) (variable_4108));
}


/* fun-setup! */ obj_t 
fun_setup__186_cfa_setup(fun_t fun_30, obj_t var_31)
{
   {
      obj_t method2459_2962;
      obj_t class2464_2963;
      {
	 obj_t arg2467_2960;
	 obj_t arg2468_2961;
	 {
	    object_t obj_4021;
	    obj_4021 = (object_t) (fun_30);
	    {
	       obj_t pre_method_105_4022;
	       pre_method_105_4022 = PROCEDURE_REF(fun_setup__env_196_cfa_setup, ((long) 2));
	       if (INTEGERP(pre_method_105_4022))
		 {
		    PROCEDURE_SET(fun_setup__env_196_cfa_setup, ((long) 2), BUNSPEC);
		    arg2467_2960 = pre_method_105_4022;
		 }
	       else
		 {
		    long obj_class_num_177_4027;
		    obj_class_num_177_4027 = TYPE(obj_4021);
		    {
		       obj_t arg1177_4028;
		       arg1177_4028 = PROCEDURE_REF(fun_setup__env_196_cfa_setup, ((long) 1));
		       {
			  long arg1178_4032;
			  {
			     long arg1179_4033;
			     arg1179_4033 = OBJECT_TYPE;
			     arg1178_4032 = (obj_class_num_177_4027 - arg1179_4033);
			  }
			  arg2467_2960 = VECTOR_REF(arg1177_4028, arg1178_4032);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_4038;
	    object_4038 = (object_t) (fun_30);
	    {
	       long arg1180_4039;
	       {
		  long arg1181_4040;
		  long arg1182_4041;
		  arg1181_4040 = TYPE(object_4038);
		  arg1182_4041 = OBJECT_TYPE;
		  arg1180_4039 = (arg1181_4040 - arg1182_4041);
	       }
	       {
		  obj_t vector_4045;
		  vector_4045 = _classes__134___object;
		  arg2468_2961 = VECTOR_REF(vector_4045, arg1180_4039);
	       }
	    }
	 }
	 method2459_2962 = arg2467_2960;
	 class2464_2963 = arg2468_2961;
	 {
	    if (INTEGERP(method2459_2962))
	      {
		 switch ((long) CINT(method2459_2962))
		   {
		   case ((long) 0):
		      {
			 sfun_t fun_2969;
			 fun_2969 = (sfun_t) (fun_30);
			 {
			    bool_t test2471_2971;
			    {
			       bool_t test2474_2975;
			       test2474_2975 = is_a__118___object(var_31, global_ast_var);
			       if (test2474_2975)
				 {
				    bool_t test2475_2976;
				    test2475_2976 = is_a__118___object(var_31, reshaped_global_160_cfa_info);
				    if (test2475_2976)
				      {
					 test2471_2971 = ((bool_t) 0);
				      }
				    else
				      {
					 test2471_2971 = ((bool_t) 1);
				      }
				 }
			       else
				 {
				    test2471_2971 = ((bool_t) 0);
				 }
			    }
			    if (test2471_2971)
			      {
				 reshaped_global_160_t obj2108_2972;
				 obj2108_2972 = ((reshaped_global_160_t) (var_31));
				 {
				    obj_t aux_4999;
				    object_t aux_4997;
				    {
				       reshaped_global_160_t aux_5000;
				       {
					  aux_5000 = ((reshaped_global_160_t) BREF(GC_MALLOC(sizeof(struct reshaped_global_160))));
				       }
				       aux_4999 = (obj_t) (aux_5000);
				    }
				    aux_4997 = (object_t) (obj2108_2972);
				    OBJECT_WIDENING_SET(aux_4997, aux_4999);
				 }
				 {
				    long arg2473_2974;
				    arg2473_2974 = class_num_218___object(reshaped_global_160_cfa_info);
				    {
				       obj_t obj_4051;
				       obj_4051 = (obj_t) (obj2108_2972);
				       (((obj_t) CREF(obj_4051))->header = MAKE_HEADER(arg2473_2974, 0), BUNSPEC);
				    }
				 }
				 (obj_t) (obj2108_2972);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			 }
			 {
			    bool_t test2476_2977;
			    {
			       bool_t test2488_2991;
			       test2488_2991 = is_a__118___object(var_31, global_ast_var);
			       if (test2488_2991)
				 {
				    obj_t aux_5013;
				    obj_t aux_5010;
				    aux_5013 = CNST_TABLE_REF(((long) 6));
				    {
				       global_t obj_4054;
				       obj_4054 = (global_t) (var_31);
				       aux_5010 = (((global_t) CREF(obj_4054))->import);
				    }
				    test2476_2977 = (aux_5010 == aux_5013);
				 }
			       else
				 {
				    test2476_2977 = ((bool_t) 0);
				 }
			    }
			    if (test2476_2977)
			      {
				 approx_t approx_2978;
				 {
				    type_t aux_5017;
				    {
				       global_t obj_4057;
				       obj_4057 = (global_t) (var_31);
				       aux_5017 = (((global_t) CREF(obj_4057))->type);
				    }
				    approx_2978 = make_type_approx_184_cfa_approx(aux_5017);
				 }
				 if ((((sfun_t) CREF(fun_2969))->top__138))
				   {
				      approx_set_top__187_cfa_approx(approx_2978);
				   }
				 else
				   {
				      BUNSPEC;
				   }
				 {
				    extern_sfun_cinfo_6_t obj2109_2980;
				    obj2109_2980 = ((extern_sfun_cinfo_6_t) (fun_2969));
				    {
				       extern_sfun_cinfo_6_t arg2478_2981;
				       {
					  extern_sfun_cinfo_6_t res2748_4062;
					  {
					     extern_sfun_cinfo_6_t new1515_4060;
					     new1515_4060 = ((extern_sfun_cinfo_6_t) BREF(GC_MALLOC(sizeof(struct extern_sfun_cinfo_6))));
					     ((((extern_sfun_cinfo_6_t) CREF(new1515_4060))->approx) = ((approx_t) approx_2978), BUNSPEC);
					     res2748_4062 = new1515_4060;
					  }
					  arg2478_2981 = res2748_4062;
				       }
				       {
					  obj_t aux_5029;
					  object_t aux_5027;
					  aux_5029 = (obj_t) (arg2478_2981);
					  aux_5027 = (object_t) (obj2109_2980);
					  OBJECT_WIDENING_SET(aux_5027, aux_5029);
				       }
				    }
				    {
				       long arg2480_2983;
				       arg2480_2983 = class_num_218___object(extern_sfun_cinfo_6_cfa_info);
				       {
					  obj_t obj_4063;
					  obj_4063 = (obj_t) (obj2109_2980);
					  (((obj_t) CREF(obj_4063))->header = MAKE_HEADER(arg2480_2983, 0), BUNSPEC);
				       }
				    }
				    return (obj_t) (obj2109_2980);
				 }
			      }
			    else
			      {
				 intern_sfun_cinfo_192_t obj2110_2985;
				 obj2110_2985 = ((intern_sfun_cinfo_192_t) (fun_2969));
				 {
				    intern_sfun_cinfo_192_t arg2482_2986;
				    {
				       approx_t arg2484_2987;
				       {
					  type_t aux_5037;
					  {
					     variable_t obj_4065;
					     obj_4065 = (variable_t) (var_31);
					     aux_5037 = (((variable_t) CREF(obj_4065))->type);
					  }
					  arg2484_2987 = make_type_approx_184_cfa_approx(aux_5037);
				       }
				       {
					  intern_sfun_cinfo_192_t res2749_4071;
					  {
					     intern_sfun_cinfo_192_t new1532_4068;
					     new1532_4068 = ((intern_sfun_cinfo_192_t) BREF(GC_MALLOC(sizeof(struct intern_sfun_cinfo_192))));
					     ((((intern_sfun_cinfo_192_t) CREF(new1532_4068))->approx) = ((approx_t) arg2484_2987), BUNSPEC);
					     ((((intern_sfun_cinfo_192_t) CREF(new1532_4068))->stamp) = ((long) ((long) -1)), BUNSPEC);
					     res2749_4071 = new1532_4068;
					  }
					  arg2482_2986 = res2749_4071;
				       }
				    }
				    {
				       obj_t aux_5046;
				       object_t aux_5044;
				       aux_5046 = (obj_t) (arg2482_2986);
				       aux_5044 = (object_t) (obj2110_2985);
				       OBJECT_WIDENING_SET(aux_5044, aux_5046);
				    }
				 }
				 {
				    long arg2487_2990;
				    arg2487_2990 = class_num_218___object(intern_sfun_cinfo_192_cfa_info);
				    {
				       obj_t obj_4072;
				       obj_4072 = (obj_t) (obj2110_2985);
				       (((obj_t) CREF(obj_4072))->header = MAKE_HEADER(arg2487_2990, 0), BUNSPEC);
				    }
				 }
				 return (obj_t) (obj2110_2985);
			      }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 cfun_t fun_2994;
			 fun_2994 = (cfun_t) (fun_30);
			 {
			    bool_t test2491_2996;
			    test2491_2996 = is_a__118___object(var_31, reshaped_global_160_cfa_info);
			    if (test2491_2996)
			      {
				 BUNSPEC;
			      }
			    else
			      {
				 reshaped_global_160_t obj2111_2997;
				 obj2111_2997 = ((reshaped_global_160_t) (var_31));
				 {
				    obj_t aux_5059;
				    object_t aux_5057;
				    {
				       reshaped_global_160_t aux_5060;
				       {
					  aux_5060 = ((reshaped_global_160_t) BREF(GC_MALLOC(sizeof(struct reshaped_global_160))));
				       }
				       aux_5059 = (obj_t) (aux_5060);
				    }
				    aux_5057 = (object_t) (obj2111_2997);
				    OBJECT_WIDENING_SET(aux_5057, aux_5059);
				 }
				 {
				    long arg2494_2999;
				    arg2494_2999 = class_num_218___object(reshaped_global_160_cfa_info);
				    {
				       obj_t obj_4077;
				       obj_4077 = (obj_t) (obj2111_2997);
				       (((obj_t) CREF(obj_4077))->header = MAKE_HEADER(arg2494_2999, 0), BUNSPEC);
				    }
				 }
				 (obj_t) (obj2111_2997);
			      }
			 }
			 {
			    approx_t approx_3000;
			    {
			       type_t aux_5068;
			       {
				  global_t obj_4079;
				  obj_4079 = (global_t) (var_31);
				  aux_5068 = (((global_t) CREF(obj_4079))->type);
			       }
			       approx_3000 = make_type_approx_184_cfa_approx(aux_5068);
			    }
			    if ((((cfun_t) CREF(fun_2994))->top__138))
			      {
				 approx_set_top__187_cfa_approx(approx_3000);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			    {
			       cfun_cinfo_200_t obj2113_3002;
			       obj2113_3002 = ((cfun_cinfo_200_t) (fun_2994));
			       {
				  cfun_cinfo_200_t arg2496_3003;
				  {
				     cfun_cinfo_200_t res2751_4084;
				     {
					cfun_cinfo_200_t new1503_4082;
					new1503_4082 = ((cfun_cinfo_200_t) BREF(GC_MALLOC(sizeof(struct cfun_cinfo_200))));
					((((cfun_cinfo_200_t) CREF(new1503_4082))->approx) = ((approx_t) approx_3000), BUNSPEC);
					res2751_4084 = new1503_4082;
				     }
				     arg2496_3003 = res2751_4084;
				  }
				  {
				     obj_t aux_5080;
				     object_t aux_5078;
				     aux_5080 = (obj_t) (arg2496_3003);
				     aux_5078 = (object_t) (obj2113_3002);
				     OBJECT_WIDENING_SET(aux_5078, aux_5080);
				  }
			       }
			       {
				  long arg2498_3005;
				  arg2498_3005 = class_num_218___object(cfun_cinfo_200_cfa_info);
				  {
				     obj_t obj_4085;
				     obj_4085 = (obj_t) (obj2113_3002);
				     (((obj_t) CREF(obj_4085))->header = MAKE_HEADER(arg2498_3005, 0), BUNSPEC);
				  }
			       }
			       return (obj_t) (obj2113_3002);
			    }
			 }
		      }
		      break;
		   default:
		    case_else2465_2966:
		      if (PROCEDUREP(method2459_2962))
			{
			   return PROCEDURE_ENTRY(method2459_2962) (method2459_2962, (obj_t) (fun_30), var_31, BEOA);
			}
		      else
			{
			   obj_t fun2453_2952;
			   fun2453_2952 = PROCEDURE_REF(fun_setup__env_196_cfa_setup, ((long) 0));
			   return PROCEDURE_ENTRY(fun2453_2952) (fun2453_2952, (obj_t) (fun_30), var_31, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2465_2966;
	      }
	 }
      }
   }
}


/* _fun-setup!2756 */ obj_t 
_fun_setup_2756_40_cfa_setup(obj_t env_4109, obj_t fun_4110, obj_t var_4111)
{
   return fun_setup__186_cfa_setup((fun_t) (fun_4110), var_4111);
}


/* fun-setup!-default2166 */ obj_t 
fun_setup__default2166_177_cfa_setup(fun_t fun_32, obj_t var_33)
{
   {
      bool_t test2454_2953;
      {
	 bool_t test2457_2957;
	 test2457_2957 = is_a__118___object(var_33, global_ast_var);
	 if (test2457_2957)
	   {
	      bool_t test2458_2958;
	      test2458_2958 = is_a__118___object(var_33, reshaped_global_160_cfa_info);
	      if (test2458_2958)
		{
		   test2454_2953 = ((bool_t) 0);
		}
	      else
		{
		   test2454_2953 = ((bool_t) 1);
		}
	   }
	 else
	   {
	      test2454_2953 = ((bool_t) 0);
	   }
      }
      if (test2454_2953)
	{
	   reshaped_global_160_t obj2107_2954;
	   obj2107_2954 = ((reshaped_global_160_t) (var_33));
	   {
	      obj_t aux_5108;
	      object_t aux_5106;
	      {
		 reshaped_global_160_t aux_5109;
		 {
		    aux_5109 = ((reshaped_global_160_t) BREF(GC_MALLOC(sizeof(struct reshaped_global_160))));
		 }
		 aux_5108 = (obj_t) (aux_5109);
	      }
	      aux_5106 = (object_t) (obj2107_2954);
	      OBJECT_WIDENING_SET(aux_5106, aux_5108);
	   }
	   {
	      long arg2456_2956;
	      arg2456_2956 = class_num_218___object(reshaped_global_160_cfa_info);
	      {
		 obj_t obj_4093;
		 obj_4093 = (obj_t) (obj2107_2954);
		 (((obj_t) CREF(obj_4093))->header = MAKE_HEADER(arg2456_2956, 0), BUNSPEC);
	      }
	   }
	   (obj_t) (obj2107_2954);
	}
      else
	{
	   BUNSPEC;
	}
   }
   return BUNSPEC;
}


/* _fun-setup!-default2166 */ obj_t 
_fun_setup__default2166_20_cfa_setup(obj_t env_4112, obj_t fun_4113, obj_t var_4114)
{
   return fun_setup__default2166_177_cfa_setup((fun_t) (fun_4113), var_4114);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_setup()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_SETUP");
   module_initialization_70_type_type(((long) 0), "CFA_SETUP");
   module_initialization_70_type_cache(((long) 0), "CFA_SETUP");
   module_initialization_70_type_typeof(((long) 0), "CFA_SETUP");
   module_initialization_70_module_module(((long) 0), "CFA_SETUP");
   module_initialization_70_tools_shape(((long) 0), "CFA_SETUP");
   module_initialization_70_tools_error(((long) 0), "CFA_SETUP");
   module_initialization_70_ast_var(((long) 0), "CFA_SETUP");
   module_initialization_70_ast_node(((long) 0), "CFA_SETUP");
   module_initialization_70_cfa_info(((long) 0), "CFA_SETUP");
   return module_initialization_70_cfa_approx(((long) 0), "CFA_SETUP");
}
