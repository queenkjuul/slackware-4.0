/*===========================================================================*/
/*   (Integrate/kk.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_kk();
static obj_t _k_1694_68_integrate_kk(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_integrate_kk(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_a(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t k___139_integrate_kk(obj_t);
static obj_t imported_modules_init_94_integrate_kk();
static obj_t _k___120_integrate_kk(obj_t, obj_t);
static obj_t library_modules_init_112_integrate_kk();
extern obj_t open_input_string(obj_t);
static obj_t k_2__250_integrate_kk(obj_t, obj_t);
static obj_t k_1__214_integrate_kk(obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t k__48_integrate_kk(obj_t, global_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_integrate_kk = BUNSPEC;
static obj_t cnst_init_137_integrate_kk();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(k___env_116_integrate_kk, _k___120_integrate_kk1701, _k___120_integrate_kk, 0L, 1);
DEFINE_EXPORT_PROCEDURE(k__env_164_integrate_kk, _k_1694_68_integrate_kk1702, _k_1694_68_integrate_kk, 0L, 2);
DEFINE_STRING(string1695_integrate_kk, string1695_integrate_kk1703, "TAIL BOTTOM ", 12);


/* module-initialization */ obj_t 
module_initialization_70_integrate_kk(long checksum_1508, char *from_1509)
{
   if (CBOOL(require_initialization_114_integrate_kk))
     {
	require_initialization_114_integrate_kk = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_kk();
	cnst_init_137_integrate_kk();
	imported_modules_init_94_integrate_kk();
	method_init_76_integrate_kk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_kk()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_KK");
   module_initialization_70___reader(((long) 0), "INTEGRATE_KK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_kk()
{
   {
      obj_t cnst_port_138_1500;
      cnst_port_138_1500 = open_input_string(string1695_integrate_kk);
      {
	 long i_1501;
	 i_1501 = ((long) 1);
       loop_1502:
	 {
	    bool_t test1696_1503;
	    test1696_1503 = (i_1501 == ((long) -1));
	    if (test1696_1503)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1697_1504;
		    {
		       obj_t list1698_1505;
		       {
			  obj_t arg1699_1506;
			  arg1699_1506 = BNIL;
			  list1698_1505 = MAKE_PAIR(cnst_port_138_1500, arg1699_1506);
		       }
		       arg1697_1504 = read___reader(list1698_1505);
		    }
		    CNST_TABLE_SET(i_1501, arg1697_1504);
		 }
		 {
		    int aux_1507;
		    {
		       long aux_1525;
		       aux_1525 = (i_1501 - ((long) 1));
		       aux_1507 = (int) (aux_1525);
		    }
		    {
		       long i_1528;
		       i_1528 = (long) (aux_1507);
		       i_1501 = i_1528;
		       goto loop_1502;
		    }
		 }
	      }
	 }
      }
   }
}


/* k! */ obj_t 
k__48_integrate_kk(obj_t a_1, global_t var_2)
{
   {
      value_t ifun_885;
      ifun_885 = (((global_t) CREF(var_2))->value);
      {
	 obj_t arg1517_886;
	 {
	    obj_t list1519_888;
	    {
	       obj_t aux_1531;
	       aux_1531 = CNST_TABLE_REF(((long) 0));
	       list1519_888 = MAKE_PAIR(aux_1531, BNIL);
	    }
	    arg1517_886 = list1519_888;
	 }
	 {
	    sfun_iinfo_105_t obj_1346;
	    obj_1346 = (sfun_iinfo_105_t) (ifun_885);
	    {
	       obj_t aux_1535;
	       {
		  object_t aux_1536;
		  aux_1536 = (object_t) (obj_1346);
		  aux_1535 = OBJECT_WIDENING(aux_1536);
	       }
	       ((((sfun_iinfo_105_t) CREF(aux_1535))->k) = ((obj_t) arg1517_886), BUNSPEC);
	    }
	 }
      }
      {
	 obj_t arg1524_890;
	 {
	    obj_t list1526_892;
	    {
	       obj_t aux_1540;
	       aux_1540 = CNST_TABLE_REF(((long) 0));
	       list1526_892 = MAKE_PAIR(aux_1540, BNIL);
	    }
	    arg1524_890 = list1526_892;
	 }
	 {
	    sfun_iinfo_105_t obj_1349;
	    obj_1349 = (sfun_iinfo_105_t) (ifun_885);
	    {
	       obj_t aux_1544;
	       {
		  object_t aux_1545;
		  aux_1545 = (object_t) (obj_1349);
		  aux_1544 = OBJECT_WIDENING(aux_1545);
	       }
	       ((((sfun_iinfo_105_t) CREF(aux_1544))->k__190) = ((obj_t) arg1524_890), BUNSPEC);
	    }
	 }
      }
      {
	 obj_t arg1528_894;
	 arg1528_894 = k_1__214_integrate_kk(a_1, BNIL);
	 return k_2__250_integrate_kk(a_1, arg1528_894);
      }
   }
}


/* _k!1694 */ obj_t 
_k_1694_68_integrate_kk(obj_t env_1495, obj_t a_1496, obj_t var_1497)
{
   return k__48_integrate_kk(a_1496, (global_t) (var_1497));
}


/* k.1! */ obj_t 
k_1__214_integrate_kk(obj_t a_3, obj_t a_tail_58_4)
{
 k_1__214_integrate_kk:
   if (NULLP(a_3))
     {
	return a_tail_58_4;
     }
   else
     {
	obj_t pr_897;
	pr_897 = CAR(a_3);
	{
	   obj_t g_899;
	   {
	      obj_t aux_1556;
	      aux_1556 = CDR(pr_897);
	      g_899 = CAR(aux_1556);
	   }
	   {
	      obj_t k_900;
	      {
		 obj_t aux_1559;
		 {
		    obj_t aux_1560;
		    aux_1560 = CDR(pr_897);
		    aux_1559 = CDR(aux_1560);
		 }
		 k_900 = CAR(aux_1559);
	      }
	      {
		 {
		    bool_t test_1564;
		    {
		       obj_t aux_1565;
		       aux_1565 = CNST_TABLE_REF(((long) 1));
		       test_1564 = (k_900 == aux_1565);
		    }
		    if (test_1564)
		      {
			 {
			    bool_t test_1568;
			    {
			       obj_t aux_1569;
			       aux_1569 = CAR(pr_897);
			       test_1568 = (aux_1569 == g_899);
			    }
			    if (test_1568)
			      {
				 obj_t a_1572;
				 a_1572 = CDR(a_3);
				 a_3 = a_1572;
				 goto k_1__214_integrate_kk;
			      }
			    else
			      {
				 obj_t arg1534_904;
				 obj_t arg1535_905;
				 arg1534_904 = CDR(a_3);
				 arg1535_905 = MAKE_PAIR(pr_897, a_tail_58_4);
				 {
				    obj_t a_tail_58_1577;
				    obj_t a_1576;
				    a_1576 = arg1534_904;
				    a_tail_58_1577 = arg1535_905;
				    a_tail_58_4 = a_tail_58_1577;
				    a_3 = a_1576;
				    goto k_1__214_integrate_kk;
				 }
			      }
			 }
		      }
		    else
		      {
			 {
			    value_t ifun_906;
			    {
			       variable_t obj_1372;
			       obj_1372 = (variable_t) (g_899);
			       ifun_906 = (((variable_t) CREF(obj_1372))->value);
			    }
			    {
			       bool_t test_1580;
			       {
				  obj_t aux_1581;
				  {
				     obj_t aux_1582;
				     {
					sfun_iinfo_105_t obj_1373;
					obj_1373 = (sfun_iinfo_105_t) (ifun_906);
					{
					   obj_t aux_1584;
					   {
					      object_t aux_1585;
					      aux_1585 = (object_t) (obj_1373);
					      aux_1584 = OBJECT_WIDENING(aux_1585);
					   }
					   aux_1582 = (((sfun_iinfo_105_t) CREF(aux_1584))->k);
					}
				     }
				     aux_1581 = memq___r4_pairs_and_lists_6_3(k_900, aux_1582);
				  }
				  test_1580 = CBOOL(aux_1581);
			       }
			       if (test_1580)
				 {
				    obj_t a_1591;
				    a_1591 = CDR(a_3);
				    a_3 = a_1591;
				    goto k_1__214_integrate_kk;
				 }
			       else
				 {
				    {
				       obj_t arg1539_909;
				       {
					  obj_t aux_1593;
					  {
					     sfun_iinfo_105_t obj_1375;
					     obj_1375 = (sfun_iinfo_105_t) (ifun_906);
					     {
						obj_t aux_1595;
						{
						   object_t aux_1596;
						   aux_1596 = (object_t) (obj_1375);
						   aux_1595 = OBJECT_WIDENING(aux_1596);
						}
						aux_1593 = (((sfun_iinfo_105_t) CREF(aux_1595))->k);
					     }
					  }
					  arg1539_909 = MAKE_PAIR(k_900, aux_1593);
				       }
				       {
					  sfun_iinfo_105_t obj_1378;
					  obj_1378 = (sfun_iinfo_105_t) (ifun_906);
					  {
					     obj_t aux_1602;
					     {
						object_t aux_1603;
						aux_1603 = (object_t) (obj_1378);
						aux_1602 = OBJECT_WIDENING(aux_1603);
					     }
					     ((((sfun_iinfo_105_t) CREF(aux_1602))->k) = ((obj_t) arg1539_909), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t arg1542_911;
				       {
					  obj_t aux_1607;
					  {
					     sfun_iinfo_105_t obj_1380;
					     obj_1380 = (sfun_iinfo_105_t) (ifun_906);
					     {
						obj_t aux_1609;
						{
						   object_t aux_1610;
						   aux_1610 = (object_t) (obj_1380);
						   aux_1609 = OBJECT_WIDENING(aux_1610);
						}
						aux_1607 = (((sfun_iinfo_105_t) CREF(aux_1609))->k__190);
					     }
					  }
					  arg1542_911 = MAKE_PAIR(k_900, aux_1607);
				       }
				       {
					  sfun_iinfo_105_t obj_1383;
					  obj_1383 = (sfun_iinfo_105_t) (ifun_906);
					  {
					     obj_t aux_1616;
					     {
						object_t aux_1617;
						aux_1617 = (object_t) (obj_1383);
						aux_1616 = OBJECT_WIDENING(aux_1617);
					     }
					     ((((sfun_iinfo_105_t) CREF(aux_1616))->k__190) = ((obj_t) arg1542_911), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t a_1621;
				       a_1621 = CDR(a_3);
				       a_3 = a_1621;
				       goto k_1__214_integrate_kk;
				    }
				 }
			    }
			 }
		      }
		 }
	      }
	   }
	}
     }
}


/* k.2! */ obj_t 
k_2__250_integrate_kk(obj_t a_5, obj_t a_tail_58_6)
{
   {
      bool_t continue_916;
      continue_916 = ((bool_t) 1);
    loop_917:
      if (continue_916)
	{
	   obj_t at_918;
	   bool_t continue_919;
	   at_918 = a_tail_58_6;
	   continue_919 = ((bool_t) 0);
	 liip_920:
	   if (NULLP(at_918))
	     {
		bool_t continue_1626;
		continue_1626 = continue_919;
		continue_916 = continue_1626;
		goto loop_917;
	     }
	   else
	     {
		value_t ifun_922;
		{
		   variable_t obj_1389;
		   {
		      obj_t aux_1627;
		      {
			 obj_t aux_1628;
			 aux_1628 = CAR(at_918);
			 aux_1627 = CAR(aux_1628);
		      }
		      obj_1389 = (variable_t) (aux_1627);
		   }
		   ifun_922 = (((variable_t) CREF(obj_1389))->value);
		}
		{
		   bool_t test_1633;
		   {
		      obj_t aux_1634;
		      {
			 sfun_iinfo_105_t obj_1390;
			 obj_1390 = (sfun_iinfo_105_t) (ifun_922);
			 {
			    obj_t aux_1636;
			    {
			       object_t aux_1637;
			       aux_1637 = (object_t) (obj_1390);
			       aux_1636 = OBJECT_WIDENING(aux_1637);
			    }
			    aux_1634 = (((sfun_iinfo_105_t) CREF(aux_1636))->k);
			 }
		      }
		      test_1633 = NULLP(aux_1634);
		   }
		   if (test_1633)
		     {
			obj_t at_1642;
			at_1642 = CDR(at_918);
			at_918 = at_1642;
			goto liip_920;
		     }
		   else
		     {
			value_t gifun_926;
			{
			   variable_t obj_1398;
			   {
			      obj_t aux_1644;
			      {
				 obj_t aux_1645;
				 {
				    obj_t aux_1646;
				    aux_1646 = CAR(at_918);
				    aux_1645 = CDR(aux_1646);
				 }
				 aux_1644 = CAR(aux_1645);
			      }
			      obj_1398 = (variable_t) (aux_1644);
			   }
			   gifun_926 = (((variable_t) CREF(obj_1398))->value);
			}
			{
			   {
			      obj_t ks_927;
			      bool_t continue_928;
			      {
				 sfun_iinfo_105_t obj_1399;
				 obj_1399 = (sfun_iinfo_105_t) (ifun_922);
				 {
				    obj_t aux_1703;
				    {
				       object_t aux_1704;
				       aux_1704 = (object_t) (obj_1399);
				       aux_1703 = OBJECT_WIDENING(aux_1704);
				    }
				    ks_927 = (((sfun_iinfo_105_t) CREF(aux_1703))->k);
				 }
			      }
			      continue_928 = continue_919;
			    laap_929:
			      if (NULLP(ks_927))
				{
				   bool_t continue_1656;
				   obj_t at_1654;
				   at_1654 = CDR(at_918);
				   continue_1656 = continue_928;
				   continue_919 = continue_1656;
				   at_918 = at_1654;
				   goto liip_920;
				}
			      else
				{
				   obj_t k_933;
				   k_933 = CAR(ks_927);
				   {
				      bool_t test_1658;
				      {
					 obj_t aux_1659;
					 {
					    obj_t aux_1660;
					    {
					       sfun_iinfo_105_t obj_1403;
					       obj_1403 = (sfun_iinfo_105_t) (gifun_926);
					       {
						  obj_t aux_1662;
						  {
						     object_t aux_1663;
						     aux_1663 = (object_t) (obj_1403);
						     aux_1662 = OBJECT_WIDENING(aux_1663);
						  }
						  aux_1660 = (((sfun_iinfo_105_t) CREF(aux_1662))->k);
					       }
					    }
					    aux_1659 = memq___r4_pairs_and_lists_6_3(k_933, aux_1660);
					 }
					 test_1658 = CBOOL(aux_1659);
				      }
				      if (test_1658)
					{
					   obj_t ks_1669;
					   ks_1669 = CDR(ks_927);
					   ks_927 = ks_1669;
					   goto laap_929;
					}
				      else
					{
					   {
					      obj_t arg1559_936;
					      {
						 obj_t aux_1671;
						 {
						    sfun_iinfo_105_t obj_1405;
						    obj_1405 = (sfun_iinfo_105_t) (gifun_926);
						    {
						       obj_t aux_1673;
						       {
							  object_t aux_1674;
							  aux_1674 = (object_t) (obj_1405);
							  aux_1673 = OBJECT_WIDENING(aux_1674);
						       }
						       aux_1671 = (((sfun_iinfo_105_t) CREF(aux_1673))->k);
						    }
						 }
						 arg1559_936 = MAKE_PAIR(k_933, aux_1671);
					      }
					      {
						 sfun_iinfo_105_t obj_1408;
						 obj_1408 = (sfun_iinfo_105_t) (gifun_926);
						 {
						    obj_t aux_1680;
						    {
						       object_t aux_1681;
						       aux_1681 = (object_t) (obj_1408);
						       aux_1680 = OBJECT_WIDENING(aux_1681);
						    }
						    ((((sfun_iinfo_105_t) CREF(aux_1680))->k) = ((obj_t) arg1559_936), BUNSPEC);
						 }
					      }
					   }
					   {
					      obj_t arg1561_938;
					      {
						 obj_t aux_1685;
						 {
						    sfun_iinfo_105_t obj_1410;
						    obj_1410 = (sfun_iinfo_105_t) (gifun_926);
						    {
						       obj_t aux_1687;
						       {
							  object_t aux_1688;
							  aux_1688 = (object_t) (obj_1410);
							  aux_1687 = OBJECT_WIDENING(aux_1688);
						       }
						       aux_1685 = (((sfun_iinfo_105_t) CREF(aux_1687))->k__190);
						    }
						 }
						 arg1561_938 = MAKE_PAIR(k_933, aux_1685);
					      }
					      {
						 sfun_iinfo_105_t obj_1413;
						 obj_1413 = (sfun_iinfo_105_t) (gifun_926);
						 {
						    obj_t aux_1694;
						    {
						       object_t aux_1695;
						       aux_1695 = (object_t) (obj_1413);
						       aux_1694 = OBJECT_WIDENING(aux_1695);
						    }
						    ((((sfun_iinfo_105_t) CREF(aux_1694))->k__190) = ((obj_t) arg1561_938), BUNSPEC);
						 }
					      }
					   }
					   {
					      bool_t continue_1701;
					      obj_t ks_1699;
					      ks_1699 = CDR(ks_927);
					      continue_1701 = ((bool_t) 1);
					      continue_928 = continue_1701;
					      ks_927 = ks_1699;
					      goto laap_929;
					   }
					}
				   }
				}
			   }
			}
		     }
		}
	     }
	}
      else
	{
	   return a_tail_58_6;
	}
   }
}


/* k*! */ obj_t 
k___139_integrate_kk(obj_t a_tail_58_7)
{
   {
      bool_t continue_946;
      continue_946 = ((bool_t) 1);
    loop_947:
      if (continue_946)
	{
	   obj_t at_948;
	   bool_t continue_949;
	   at_948 = a_tail_58_7;
	   continue_949 = ((bool_t) 0);
	 liip_950:
	   if (NULLP(at_948))
	     {
		bool_t continue_1711;
		continue_1711 = continue_949;
		continue_946 = continue_1711;
		goto loop_947;
	     }
	   else
	     {
		value_t ifun_952;
		{
		   variable_t obj_1422;
		   {
		      obj_t aux_1712;
		      {
			 obj_t aux_1713;
			 {
			    obj_t aux_1714;
			    aux_1714 = CAR(at_948);
			    aux_1713 = CDR(aux_1714);
			 }
			 aux_1712 = CAR(aux_1713);
		      }
		      obj_1422 = (variable_t) (aux_1712);
		   }
		   ifun_952 = (((variable_t) CREF(obj_1422))->value);
		}
		{
		   bool_t test_1720;
		   {
		      obj_t aux_1721;
		      {
			 sfun_iinfo_105_t obj_1423;
			 obj_1423 = (sfun_iinfo_105_t) (ifun_952);
			 {
			    obj_t aux_1723;
			    {
			       object_t aux_1724;
			       aux_1724 = (object_t) (obj_1423);
			       aux_1723 = OBJECT_WIDENING(aux_1724);
			    }
			    aux_1721 = (((sfun_iinfo_105_t) CREF(aux_1723))->k__190);
			 }
		      }
		      test_1720 = NULLP(aux_1721);
		   }
		   if (test_1720)
		     {
			bool_t continue_1729;
			continue_1729 = continue_949;
			continue_946 = continue_1729;
			goto loop_947;
		     }
		   else
		     {
			obj_t ks_954;
			bool_t continue_955;
			{
			   sfun_iinfo_105_t obj_1425;
			   obj_1425 = (sfun_iinfo_105_t) (ifun_952);
			   {
			      obj_t aux_1773;
			      {
				 object_t aux_1774;
				 aux_1774 = (object_t) (obj_1425);
				 aux_1773 = OBJECT_WIDENING(aux_1774);
			      }
			      ks_954 = (((sfun_iinfo_105_t) CREF(aux_1773))->k__190);
			   }
			}
			continue_955 = continue_949;
		      laap_956:
			if (NULLP(ks_954))
			  {
			     bool_t continue_1734;
			     obj_t at_1732;
			     at_1732 = CDR(at_948);
			     continue_1734 = continue_955;
			     continue_949 = continue_1734;
			     at_948 = at_1732;
			     goto liip_950;
			  }
			else
			  {
			     value_t fifun_961;
			     {
				variable_t obj_1430;
				{
				   obj_t aux_1735;
				   {
				      obj_t aux_1736;
				      aux_1736 = CAR(at_948);
				      aux_1735 = CAR(aux_1736);
				   }
				   obj_1430 = (variable_t) (aux_1735);
				}
				fifun_961 = (((variable_t) CREF(obj_1430))->value);
			     }
			     {
				obj_t k_962;
				k_962 = CAR(ks_954);
				{
				   {
				      bool_t test_1742;
				      {
					 obj_t aux_1743;
					 {
					    obj_t aux_1744;
					    {
					       sfun_iinfo_105_t obj_1432;
					       obj_1432 = (sfun_iinfo_105_t) (fifun_961);
					       {
						  obj_t aux_1746;
						  {
						     object_t aux_1747;
						     aux_1747 = (object_t) (obj_1432);
						     aux_1746 = OBJECT_WIDENING(aux_1747);
						  }
						  aux_1744 = (((sfun_iinfo_105_t) CREF(aux_1746))->k__190);
					       }
					    }
					    aux_1743 = memq___r4_pairs_and_lists_6_3(k_962, aux_1744);
					 }
					 test_1742 = CBOOL(aux_1743);
				      }
				      if (test_1742)
					{
					   obj_t ks_1753;
					   ks_1753 = CDR(ks_954);
					   ks_954 = ks_1753;
					   goto laap_956;
					}
				      else
					{
					   {
					      obj_t arg1580_965;
					      {
						 obj_t aux_1755;
						 {
						    sfun_iinfo_105_t obj_1434;
						    obj_1434 = (sfun_iinfo_105_t) (fifun_961);
						    {
						       obj_t aux_1757;
						       {
							  object_t aux_1758;
							  aux_1758 = (object_t) (obj_1434);
							  aux_1757 = OBJECT_WIDENING(aux_1758);
						       }
						       aux_1755 = (((sfun_iinfo_105_t) CREF(aux_1757))->k__190);
						    }
						 }
						 arg1580_965 = MAKE_PAIR(k_962, aux_1755);
					      }
					      {
						 sfun_iinfo_105_t obj_1437;
						 obj_1437 = (sfun_iinfo_105_t) (fifun_961);
						 {
						    obj_t aux_1764;
						    {
						       object_t aux_1765;
						       aux_1765 = (object_t) (obj_1437);
						       aux_1764 = OBJECT_WIDENING(aux_1765);
						    }
						    ((((sfun_iinfo_105_t) CREF(aux_1764))->k__190) = ((obj_t) arg1580_965), BUNSPEC);
						 }
					      }
					   }
					   {
					      bool_t continue_1771;
					      obj_t ks_1769;
					      ks_1769 = CDR(ks_954);
					      continue_1771 = ((bool_t) 1);
					      continue_955 = continue_1771;
					      ks_954 = ks_1769;
					      goto laap_956;
					   }
					}
				   }
				}
			     }
			  }
		     }
		}
	     }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _k*! */ obj_t 
_k___120_integrate_kk(obj_t env_1498, obj_t a_tail_58_1499)
{
   return k___139_integrate_kk(a_tail_58_1499);
}


/* method-init */ obj_t 
method_init_76_integrate_kk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_kk()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_KK");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_KK");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_KK");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_KK");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_KK");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_KK");
   return module_initialization_70_integrate_a(((long) 0), "INTEGRATE_KK");
}
