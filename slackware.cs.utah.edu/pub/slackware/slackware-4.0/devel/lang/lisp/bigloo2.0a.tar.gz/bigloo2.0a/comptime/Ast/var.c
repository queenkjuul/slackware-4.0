/*===========================================================================*/
/*   (Ast/var.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


static obj_t _local_name1885_77_ast_var(obj_t, obj_t);
extern obj_t sfun_side_effect__85_ast_var(sfun_t);
static obj_t _variable_value_set_1935_216_ast_var(obj_t, obj_t, obj_t);
static obj_t _cfun_the_closure_set_1840_178_ast_var(obj_t, obj_t, obj_t);
extern long fun_arity_132_ast_var(fun_t);
static obj_t _global_import_set_1918_247_ast_var(obj_t, obj_t, obj_t);
extern obj_t fun_stack_allocator_124_ast_var(fun_t);
static obj_t _global_src1928_118_ast_var(obj_t, obj_t);
static obj_t _global_occurrence1916_151_ast_var(obj_t, obj_t);
static obj_t _sfun_args_set_1860_227_ast_var(obj_t, obj_t, obj_t);
extern type_t variable_type_237_ast_var(variable_t);
static obj_t _cfun_side_effect_1833_17_ast_var(obj_t, obj_t);
static obj_t _global_removable1914_19_ast_var(obj_t, obj_t);
extern obj_t variable_id_167_ast_var(variable_t);
static obj_t method_init_76_ast_var();
extern local_t allocate_local_177_ast_var();
static obj_t _global_fast_alpha_set_1911_201_ast_var(obj_t, obj_t, obj_t);
extern obj_t variable_fast_alpha_set__48_ast_var(variable_t, obj_t);
static obj_t _global_type1906_73_ast_var(obj_t, obj_t);
static obj_t _variable_occurrence_set_1943_127_ast_var(obj_t, obj_t, obj_t);
static obj_t _make_scnst_248_ast_var(obj_t, obj_t, obj_t, obj_t);
static obj_t _local_occurrence1897_134_ast_var(obj_t, obj_t);
extern local_t make_local_130_ast_var(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, bool_t, long);
extern obj_t sfun_class_set__158_ast_var(sfun_t, obj_t);
extern obj_t global_value_set__118_ast_var(global_t, value_t);
extern obj_t fun_top__set__55_ast_var(fun_t, bool_t);
extern svar_t allocate_svar_218_ast_var();
extern obj_t fun_the_closure_217_ast_var(fun_t);
extern svar_t make_svar_231_ast_var(obj_t);
extern obj_t global_fast_alpha_242_ast_var(global_t);
static obj_t _allocate_value_13_ast_var(obj_t);
static obj_t _variable_fast_alpha_set_1939_234_ast_var(obj_t, obj_t, obj_t);
extern bool_t global_library__62_ast_var(global_t);
extern obj_t sfun_predicate_of_set__36_ast_var(sfun_t, obj_t);
extern obj_t local_name_set__155_ast_var(local_t, obj_t);
static obj_t _cfun_arity1831_223_ast_var(obj_t, obj_t);
extern obj_t global_import_set__22_ast_var(global_t, obj_t);
static obj_t struct_object__object_cvar_183_ast_var(obj_t, obj_t, obj_t);
static obj_t _object__struct1946_80___object(obj_t, obj_t);
static obj_t _variable_removable_set_1941_231_ast_var(obj_t, obj_t, obj_t);
static obj_t _sfun_top__set_1854_44_ast_var(obj_t, obj_t, obj_t);
static obj_t _variable_access1938_157_ast_var(obj_t, obj_t);
extern obj_t local_user__set__89_ast_var(local_t, bool_t);
static obj_t _global_pragma1926_131_ast_var(obj_t, obj_t);
static obj_t _sexit_detached_1821_101_ast_var(obj_t, obj_t);
extern bool_t fun_top__228_ast_var(fun_t);
extern obj_t cfun_stack_allocator_58_ast_var(cfun_t);
extern obj_t scnst_class_set__87_ast_var(scnst_t, obj_t);
static obj_t _global_module1917_19_ast_var(obj_t, obj_t);
static obj_t object__struct_svar_233_ast_var(obj_t, obj_t);
extern obj_t fun_predicate_of_193_ast_var(fun_t);
static obj_t _allocate_global_232_ast_var(obj_t);
static obj_t _global_library_1923_164_ast_var(obj_t, obj_t);
static obj_t _local_access1891_206_ast_var(obj_t, obj_t);
static obj_t _sfun_predicate_of1851_65_ast_var(obj_t, obj_t);
extern sexit_t allocate_sexit_47_ast_var();
static obj_t _sfun_loc_set_1868_144_ast_var(obj_t, obj_t, obj_t);
static obj_t _cfun_predicate_of_set_1834_95_ast_var(obj_t, obj_t, obj_t);
static obj_t _cfun_macro_1843_180_ast_var(obj_t, obj_t);
static obj_t _global_library__set_1922_202_ast_var(obj_t, obj_t, obj_t);
static obj_t _sfun_arity1847_91_ast_var(obj_t, obj_t);
extern obj_t global_id_179_ast_var(global_t);
extern obj_t local_occurrence_set__128_ast_var(local_t, long);
static obj_t _fun_side_effect_1873_86_ast_var(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _sfun__63_ast_var(obj_t, obj_t);
obj_t global_ast_var = BUNSPEC;
static obj_t _global_access_set_1909_136_ast_var(obj_t, obj_t, obj_t);
extern obj_t fun_side_effect__set__185_ast_var(fun_t, obj_t);
static obj_t _make_cfun1830_194_ast_var(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _local_name_set_1884_228_ast_var(obj_t, obj_t, obj_t);
extern cfun_t allocate_cfun_23_ast_var();
extern sexit_t make_sexit_79_ast_var(obj_t, bool_t);
extern cfun_t make_cfun_58_ast_var(long, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, bool_t, bool_t);
static obj_t _global_value1908_139_ast_var(obj_t, obj_t);
extern obj_t svar_loc_189_ast_var(svar_t);
static obj_t _global_fast_alpha1912_51_ast_var(obj_t, obj_t);
extern long local_occurrence_5_ast_var(local_t);
static obj_t _global_type_set_1905_127_ast_var(obj_t, obj_t, obj_t);
extern obj_t global_evaluable__set__201_ast_var(global_t, bool_t);
obj_t cvar_ast_var = BUNSPEC;
extern obj_t sfun_loc_13_ast_var(sfun_t);
static obj_t _make_fun1870_204_ast_var(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t sfun_the_closure_set__227_ast_var(sfun_t, obj_t);
static obj_t _local_fast_alpha1893_30_ast_var(obj_t, obj_t);
extern global_t make_global_89_ast_var(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, obj_t, obj_t, bool_t, bool_t, bool_t, obj_t, obj_t);
extern obj_t cfun_predicate_of_set__65_ast_var(cfun_t, obj_t);
extern value_t variable_value_212_ast_var(variable_t);
extern obj_t fun_side_effect__244_ast_var(fun_t);
static obj_t struct_object__object_svar_1_ast_var(obj_t, obj_t, obj_t);
extern value_t local_value_65_ast_var(local_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _sfun_the_closure_set_1856_212_ast_var(obj_t, obj_t, obj_t);
static obj_t _local_removable_set_1894_80_ast_var(obj_t, obj_t, obj_t);
extern obj_t variable_removable_set__218_ast_var(variable_t, obj_t);
static obj_t _fun_stack_allocator1877_93_ast_var(obj_t, obj_t);
static obj_t object__struct_cfun_117_ast_var(obj_t, obj_t);
extern bool_t svar__161_ast_var(obj_t);
extern obj_t global_src_set__223_ast_var(global_t, obj_t);
static obj_t _sfun_dsssl_keywords1867_41_ast_var(obj_t, obj_t);
extern value_t allocate_value_190_ast_var();
static obj_t _scnst_class_set_1824_123_ast_var(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern bool_t variable__18_ast_var(obj_t);
static obj_t _scnst_loc1827_66_ast_var(obj_t, obj_t);
static obj_t struct_object__object_fun_34_ast_var(obj_t, obj_t, obj_t);
static obj_t _make_cvar_142_ast_var(obj_t, obj_t);
static obj_t _cfun_predicate_of1835_148_ast_var(obj_t, obj_t);
extern long variable_occurrence_246_ast_var(variable_t);
static obj_t _cfun_stack_allocator_set_1836_163_ast_var(obj_t, obj_t, obj_t);
static obj_t struct_object__object_scnst_43_ast_var(obj_t, obj_t, obj_t);
extern obj_t global_src_229_ast_var(global_t);
static obj_t _variable_type1934_235_ast_var(obj_t, obj_t);
extern type_t global_type_243_ast_var(global_t);
static obj_t _local_user_1899_231_ast_var(obj_t, obj_t);
extern obj_t global_access_222_ast_var(global_t);
extern value_t make_value_52_ast_var();
extern obj_t scnst_loc_19_ast_var(scnst_t);
extern bool_t global_user__208_ast_var(global_t);
static obj_t _scnst_class1825_34_ast_var(obj_t, obj_t);
static obj_t _variable_name_set_1931_62_ast_var(obj_t, obj_t, obj_t);
static obj_t _variable_occurrence1944_66_ast_var(obj_t, obj_t);
static obj_t _fun_side_effect__set_1872_254_ast_var(obj_t, obj_t, obj_t);
static obj_t _sfun_loc1869_33_ast_var(obj_t, obj_t);
static obj_t object__struct_scnst_111_ast_var(obj_t, obj_t);
static obj_t _cvar_macro_1822_142_ast_var(obj_t, obj_t);
extern sfun_t allocate_sfun_135_ast_var();
extern long sfun_arity_53_ast_var(sfun_t);
extern sfun_t make_sfun_19_ast_var(long, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _cvar__164_ast_var(obj_t, obj_t);
extern bool_t cfun__213_ast_var(obj_t);
extern obj_t cfun_the_closure_set__43_ast_var(cfun_t, obj_t);
static obj_t _local_removable1895_184_ast_var(obj_t, obj_t);
extern long class_num_218___object(obj_t);
obj_t svar_ast_var = BUNSPEC;
static obj_t struct_object__object_cfun_108_ast_var(obj_t, obj_t, obj_t);
extern obj_t sfun_class_145_ast_var(sfun_t);
extern obj_t global_pragma_105_ast_var(global_t);
static obj_t _sfun_predicate_of_set_1850_4_ast_var(obj_t, obj_t, obj_t);
static obj_t _fun_top_1879_211_ast_var(obj_t, obj_t);
obj_t scnst_ast_var = BUNSPEC;
static obj_t _variable_id1930_132_ast_var(obj_t, obj_t);
extern obj_t sfun_args_set__132_ast_var(sfun_t, obj_t);
extern obj_t fun_the_closure_set__119_ast_var(fun_t, obj_t);
extern obj_t variable_removable_74_ast_var(variable_t);
static obj_t _fun_the_closure_set_1880_102_ast_var(obj_t, obj_t, obj_t);
extern bool_t scnst__249_ast_var(obj_t);
static obj_t struct_object__object_variable_106_ast_var(obj_t, obj_t, obj_t);
extern obj_t cfun_predicate_of_23_ast_var(cfun_t);
obj_t fun_ast_var = BUNSPEC;
static obj_t object__struct_sfun_209_ast_var(obj_t, obj_t);
static obj_t _cfun_infix_1845_83_ast_var(obj_t, obj_t);
extern obj_t global_access_set__188_ast_var(global_t, obj_t);
static obj_t struct_object__object_global_249_ast_var(obj_t, obj_t, obj_t);
extern obj_t scnst_node_98_ast_var(scnst_t);
static obj_t _local_occurrence_set_1896_125_ast_var(obj_t, obj_t, obj_t);
static obj_t _sexit_handler1819_47_ast_var(obj_t, obj_t);
extern obj_t local_value_set__243_ast_var(local_t, value_t);
extern bool_t local__163_ast_var(obj_t);
extern obj_t sexit_detached__set__116_ast_var(sexit_t, bool_t);
static obj_t imported_modules_init_94_ast_var();
static obj_t _fun_arity1871_184_ast_var(obj_t, obj_t);
extern long local_key_6_ast_var(local_t);
static obj_t _struct_object__object1949_218___object(obj_t, obj_t, obj_t);
static obj_t _global_id1902_142_ast_var(obj_t, obj_t);
static obj_t _sfun_class_set_1864_162_ast_var(obj_t, obj_t, obj_t);
extern obj_t variable_occurrence_set__234_ast_var(variable_t, long);
static obj_t _make_svar_17_ast_var(obj_t, obj_t);
extern obj_t cfun_top__set__230_ast_var(cfun_t, bool_t);
static obj_t _fun_predicate_of1875_19_ast_var(obj_t, obj_t);
extern obj_t local_fast_alpha_65_ast_var(local_t);
static obj_t _allocate_cvar_101_ast_var(obj_t);
extern obj_t global_import_37_ast_var(global_t);
static obj_t _cfun_top_1839_213_ast_var(obj_t, obj_t);
static obj_t _svar_loc_set_1828_105_ast_var(obj_t, obj_t, obj_t);
extern bool_t cfun_infix__133_ast_var(cfun_t);
extern obj_t local_name_136_ast_var(local_t);
extern obj_t sexit_handler_set__47_ast_var(sexit_t, obj_t);
static obj_t _local_fast_alpha_set_1892_179_ast_var(obj_t, obj_t, obj_t);
extern obj_t variable_type_set__4_ast_var(variable_t, type_t);
obj_t cfun_ast_var = BUNSPEC;
extern bool_t sfun_top__45_ast_var(sfun_t);
static obj_t _allocate_scnst_4_ast_var(obj_t);
static obj_t _variable_removable1942_189_ast_var(obj_t, obj_t);
static obj_t _global__76_ast_var(obj_t, obj_t);
static obj_t _variable_fast_alpha1940_254_ast_var(obj_t, obj_t);
static obj_t _fun__116_ast_var(obj_t, obj_t);
static obj_t _global_name1904_201_ast_var(obj_t, obj_t);
static obj_t _scnst__164_ast_var(obj_t, obj_t);
static obj_t _local_id1883_127_ast_var(obj_t, obj_t);
extern obj_t cfun_side_effect__250_ast_var(cfun_t);
static obj_t _sfun_property_set_1858_127_ast_var(obj_t, obj_t, obj_t);
static obj_t _make_sexit_67_ast_var(obj_t, obj_t, obj_t);
static obj_t _local_access_set_1890_135_ast_var(obj_t, obj_t, obj_t);
static obj_t struct_object__object_sfun_10_ast_var(obj_t, obj_t, obj_t);
extern obj_t variable_value_set__250_ast_var(variable_t, value_t);
extern obj_t sfun_dsssl_keywords_40_ast_var(sfun_t);
static obj_t _local__113_ast_var(obj_t, obj_t);
static obj_t library_modules_init_112_ast_var();
extern obj_t sfun_top__set__255_ast_var(sfun_t, bool_t);
extern obj_t variable_access_set__102_ast_var(variable_t, obj_t);
extern obj_t variable_fast_alpha_132_ast_var(variable_t);
static obj_t _local_type1887_8_ast_var(obj_t, obj_t);
extern obj_t cfun_the_closure_97_ast_var(cfun_t);
static obj_t _local_type_set_1886_229_ast_var(obj_t, obj_t, obj_t);
static obj_t _variable_value1936_49_ast_var(obj_t, obj_t);
extern obj_t global_fast_alpha_set__101_ast_var(global_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _cfun_stack_allocator1837_253_ast_var(obj_t, obj_t);
static obj_t _sfun_class1865_218_ast_var(obj_t, obj_t);
static obj_t _svar_loc1829_27_ast_var(obj_t, obj_t);
extern obj_t variable_name_105_ast_var(variable_t);
static obj_t _sfun_top_1855_92_ast_var(obj_t, obj_t);
static obj_t _make_global1901_192_ast_var(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _sfun_stack_allocator1853_71_ast_var(obj_t, obj_t);
extern obj_t variable_access_211_ast_var(variable_t);
static obj_t toplevel_init_63_ast_var();
extern obj_t sfun_property_set__95_ast_var(sfun_t, obj_t);
static obj_t _allocate_svar_73_ast_var(obj_t);
extern obj_t fun_predicate_of_set__163_ast_var(fun_t, obj_t);
extern fun_t allocate_fun_149_ast_var();
extern obj_t global_module_203_ast_var(global_t);
extern obj_t open_input_string(obj_t);
extern bool_t global__63_ast_var(obj_t);
extern bool_t sexit__36_ast_var(obj_t);
static obj_t _sfun_the_closure1857_195_ast_var(obj_t, obj_t);
extern obj_t local_access_176_ast_var(local_t);
extern long cfun_arity_68_ast_var(cfun_t);
static obj_t struct_object__object_local_234_ast_var(obj_t, obj_t, obj_t);
static obj_t _cfun_top__set_1838_41_ast_var(obj_t, obj_t, obj_t);
static obj_t _make_value_202_ast_var(obj_t);
obj_t sfun_ast_var = BUNSPEC;
extern obj_t cfun_stack_allocator_set__66_ast_var(cfun_t, obj_t);
extern obj_t sfun_loc_set__51_ast_var(sfun_t, obj_t);
extern obj_t variable_name_set__44_ast_var(variable_t, obj_t);
static obj_t _variable__238_ast_var(obj_t, obj_t);
static obj_t _fun_top__set_1878_45_ast_var(obj_t, obj_t, obj_t);
static obj_t _sfun_args1861_246_ast_var(obj_t, obj_t);
extern obj_t sfun_side_effect__set__97_ast_var(sfun_t, obj_t);
static obj_t _sfun_body_set_1862_31_ast_var(obj_t, obj_t, obj_t);
static obj_t _scnst_loc_set_1826_74_ast_var(obj_t, obj_t, obj_t);
static obj_t object__struct_local_56_ast_var(obj_t, obj_t);
static obj_t _local_value1889_74_ast_var(obj_t, obj_t);
extern bool_t fun__147_ast_var(obj_t);
static obj_t _variable_type_set_1933_207_ast_var(obj_t, obj_t, obj_t);
extern obj_t sexit_handler_210_ast_var(sexit_t);
static obj_t _fun_stack_allocator_set_1876_28_ast_var(obj_t, obj_t, obj_t);
extern obj_t global_removable_57_ast_var(global_t);
extern obj_t svar_loc_set__106_ast_var(svar_t, obj_t);
extern scnst_t allocate_scnst_81_ast_var();
static obj_t _cfun_side_effect__set_1832_159_ast_var(obj_t, obj_t, obj_t);
extern obj_t object___object;
static obj_t _global_value_set_1907_238_ast_var(obj_t, obj_t, obj_t);
obj_t variable_ast_var = BUNSPEC;
extern obj_t sfun_property_40_ast_var(sfun_t);
static obj_t _global_import1919_10_ast_var(obj_t, obj_t);
static obj_t _make_sfun1846_247_ast_var(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t sfun_body_150_ast_var(sfun_t);
extern bool_t value__43_ast_var(obj_t);
extern obj_t local_access_set__100_ast_var(local_t, obj_t);
obj_t local_ast_var = BUNSPEC;
static obj_t _sexit__255_ast_var(obj_t, obj_t);
static obj_t _svar__166_ast_var(obj_t, obj_t);
extern scnst_t make_scnst_115_ast_var(obj_t, obj_t, obj_t);
static obj_t _allocate_cfun_27_ast_var(obj_t);
extern obj_t cfun_args_type_30_ast_var(cfun_t);
static obj_t _global_evaluable__set_1920_157_ast_var(obj_t, obj_t, obj_t);
static obj_t _make_variable1929_49_ast_var(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t sfun__199_ast_var(obj_t);
extern bool_t global_evaluable__170_ast_var(global_t);
static obj_t _global_src_set_1927_160_ast_var(obj_t, obj_t, obj_t);
static obj_t _local_value_set_1888_45_ast_var(obj_t, obj_t, obj_t);
extern obj_t global_user__set__116_ast_var(global_t, bool_t);
extern obj_t fun_stack_allocator_set__246_ast_var(fun_t, obj_t);
extern bool_t cfun_top__60_ast_var(cfun_t);
extern bool_t sexit_detached__208_ast_var(sexit_t);
static obj_t object__struct_global_193_ast_var(obj_t, obj_t);
static obj_t _variable_name1932_100_ast_var(obj_t, obj_t);
extern obj_t global_type_set__109_ast_var(global_t, type_t);
static obj_t struct_object__object_sexit_101_ast_var(obj_t, obj_t, obj_t);
static obj_t _sfun_property1859_159_ast_var(obj_t, obj_t);
extern value_t global_value_241_ast_var(global_t);
extern obj_t sfun_stack_allocator_39_ast_var(sfun_t);
extern obj_t local_fast_alpha_set__243_ast_var(local_t, obj_t);
static obj_t _local_key1900_156_ast_var(obj_t, obj_t);
static obj_t _cfun_infix__set_1844_216_ast_var(obj_t, obj_t, obj_t);
extern obj_t local_removable_set__151_ast_var(local_t, obj_t);
static obj_t _scnst_node1823_67_ast_var(obj_t, obj_t);
extern bool_t local_user__147_ast_var(local_t);
static obj_t _fun_predicate_of_set_1874_48_ast_var(obj_t, obj_t, obj_t);
extern obj_t sfun_dsssl_keywords_set__95_ast_var(sfun_t, obj_t);
static obj_t object_init_111_ast_var();
static obj_t object__struct_sexit_213_ast_var(obj_t, obj_t);
static obj_t _value__210_ast_var(obj_t, obj_t);
static obj_t _cfun__201_ast_var(obj_t, obj_t);
static obj_t object__struct_variable_84_ast_var(obj_t, obj_t);
extern obj_t sfun_the_closure_253_ast_var(sfun_t);
static obj_t _global_user_1925_58_ast_var(obj_t, obj_t);
static obj_t _global_evaluable_1921_23_ast_var(obj_t, obj_t);
static obj_t _sfun_body1863_190_ast_var(obj_t, obj_t);
extern obj_t sfun_args_174_ast_var(sfun_t);
static obj_t _allocate_local_35_ast_var(obj_t);
extern obj_t sfun_body_set__45_ast_var(sfun_t, obj_t);
extern obj_t cfun_side_effect__set__1_ast_var(cfun_t, obj_t);
static obj_t _allocate_variable_137_ast_var(obj_t);
extern long global_occurrence_96_ast_var(global_t);
extern obj_t local_removable_34_ast_var(local_t);
static obj_t _make_local1882_116_ast_var(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t global_name_141_ast_var(global_t);
static obj_t _global_name_set_1903_31_ast_var(obj_t, obj_t, obj_t);
obj_t sexit_ast_var = BUNSPEC;
static obj_t _global_access1910_248_ast_var(obj_t, obj_t);
extern obj_t global_removable_set__21_ast_var(global_t, obj_t);
static obj_t _sexit_detached__set_1820_99_ast_var(obj_t, obj_t, obj_t);
static obj_t _allocate_sfun_141_ast_var(obj_t);
static obj_t _fun_the_closure1881_113_ast_var(obj_t, obj_t);
static obj_t _allocate_fun_230_ast_var(obj_t);
extern obj_t read___reader(obj_t);
static obj_t struct_object__object_value_20_ast_var(obj_t, obj_t, obj_t);
extern variable_t allocate_variable_244_ast_var();
static obj_t _sfun_side_effect_1849_38_ast_var(obj_t, obj_t);
extern obj_t sfun_stack_allocator_set__142_ast_var(sfun_t, obj_t);
extern bool_t cvar__118_ast_var(obj_t);
static obj_t _global_user__set_1924_213_ast_var(obj_t, obj_t, obj_t);
static obj_t _sfun_side_effect__set_1848_147_ast_var(obj_t, obj_t, obj_t);
extern bool_t cvar_macro__32_ast_var(cvar_t);
extern obj_t scnst_loc_set__206_ast_var(scnst_t, obj_t);
extern obj_t sfun_predicate_of_63_ast_var(sfun_t);
extern type_t local_type_242_ast_var(local_t);
static obj_t _sfun_stack_allocator_set_1852_160_ast_var(obj_t, obj_t, obj_t);
static obj_t _cfun_args_type1842_81_ast_var(obj_t, obj_t);
extern variable_t make_variable_6_ast_var(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long);
extern cvar_t allocate_cvar_254_ast_var();
extern obj_t local_type_set__101_ast_var(local_t, type_t);
extern cvar_t make_cvar_132_ast_var(bool_t);
static obj_t object__struct_value_130_ast_var(obj_t, obj_t);
static obj_t _sfun_dsssl_keywords_set_1866_218_ast_var(obj_t, obj_t, obj_t);
extern obj_t global_name_set__147_ast_var(global_t, obj_t);
extern fun_t make_fun_37_ast_var(long, obj_t, obj_t, obj_t, bool_t, obj_t);
static obj_t _sexit_handler_set_1818_167_ast_var(obj_t, obj_t, obj_t);
static obj_t _local_user__set_1898_41_ast_var(obj_t, obj_t, obj_t);
extern global_t allocate_global_222_ast_var();
static obj_t object__struct_fun_194_ast_var(obj_t, obj_t);
extern obj_t local_id_1_ast_var(local_t);
extern obj_t global_occurrence_set__154_ast_var(global_t, long);
static obj_t require_initialization_114_ast_var = BUNSPEC;
static obj_t _allocate_sexit_130_ast_var(obj_t);
extern obj_t global_library__set__213_ast_var(global_t, bool_t);
obj_t value_ast_var = BUNSPEC;
static obj_t _cfun_the_closure1841_181_ast_var(obj_t, obj_t);
static obj_t _global_removable_set_1913_117_ast_var(obj_t, obj_t, obj_t);
extern obj_t scnst_class_73_ast_var(scnst_t);
static obj_t _global_occurrence_set_1915_159_ast_var(obj_t, obj_t, obj_t);
static obj_t object__struct_cvar_12_ast_var(obj_t, obj_t);
static obj_t cnst_init_137_ast_var();
extern bool_t cfun_macro__119_ast_var(cfun_t);
static obj_t _variable_access_set_1937_226_ast_var(obj_t, obj_t, obj_t);
extern obj_t cfun_infix__set__175_ast_var(cfun_t, bool_t);
static obj_t __cnst[11];

DEFINE_EXPORT_PROCEDURE(allocate_cfun_env_241_ast_var, _allocate_cfun_27_ast_var1979, _allocate_cfun_27_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(local_removable_env_70_ast_var, _local_removable1895_184_ast_var1980, _local_removable1895_184_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_cvar_env_104_ast_var, _make_cvar_142_ast_var1981, _make_cvar_142_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit__env_174_ast_var, _sexit__255_ast_var1982, _sexit__255_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_predicate_of_set__env_174_ast_var, _sfun_predicate_of_set_1850_4_ast_var1983, _sfun_predicate_of_set_1850_4_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_cfun_env_81_ast_var, _make_cfun1830_194_ast_var1984, _make_cfun1830_194_ast_var, 0L, 9);
DEFINE_EXPORT_PROCEDURE(cfun__env_36_ast_var, _cfun__201_ast_var1985, _cfun__201_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_predicate_of_env_241_ast_var, _cfun_predicate_of1835_148_ast_var1986, _cfun_predicate_of1835_148_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_access_set__env_14_ast_var, _global_access_set_1909_136_ast_var1987, _global_access_set_1909_136_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_class_set__env_48_ast_var, _sfun_class_set_1864_162_ast_var1988, _sfun_class_set_1864_162_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fun_predicate_of_env_149_ast_var, _fun_predicate_of1875_19_ast_var1989, _fun_predicate_of1875_19_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_stack_allocator_env_81_ast_var, _cfun_stack_allocator1837_253_ast_var1990, _cfun_stack_allocator1837_253_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fun_top__set__env_231_ast_var, _fun_top__set_1878_45_ast_var1991, _fun_top__set_1878_45_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_scnst_env_226_ast_var, _allocate_scnst_4_ast_var1992, _allocate_scnst_4_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_the_closure_set__env_129_ast_var, _sfun_the_closure_set_1856_212_ast_var1993, _sfun_the_closure_set_1856_212_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fun_stack_allocator_env_55_ast_var, _fun_stack_allocator1877_93_ast_var1994, _fun_stack_allocator1877_93_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_value_env_59_ast_var, _make_value_202_ast_var1995, _make_value_202_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_dsssl_keywords_env_170_ast_var, _sfun_dsssl_keywords1867_41_ast_var1996, _sfun_dsssl_keywords1867_41_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_dsssl_keywords_set__env_147_ast_var, _sfun_dsssl_keywords_set_1866_218_ast_var1997, _sfun_dsssl_keywords_set_1866_218_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_stack_allocator_env_230_ast_var, _sfun_stack_allocator1853_71_ast_var1998, _sfun_stack_allocator1853_71_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(scnst_loc_env_102_ast_var, _scnst_loc1827_66_ast_var1999, _scnst_loc1827_66_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_type_env_200_ast_var, _local_type1887_8_ast_var2000, _local_type1887_8_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_class_env_1_ast_var, _sfun_class1865_218_ast_var2001, _sfun_class1865_218_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_import_env_121_ast_var, _global_import1919_10_ast_var2002, _global_import1919_10_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_variable_env_15_ast_var, _make_variable1929_49_ast_var2003, _make_variable1929_49_ast_var, 0L, 8);
DEFINE_EXPORT_PROCEDURE(local_type_set__env_25_ast_var, _local_type_set_1886_229_ast_var2004, _local_type_set_1886_229_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(variable_occurrence_env_50_ast_var, _variable_occurrence1944_66_ast_var2005, _variable_occurrence1944_66_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fun_side_effect__set__env_203_ast_var, _fun_side_effect__set_1872_254_ast_var2006, _fun_side_effect__set_1872_254_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_local_env_7_ast_var, _allocate_local_35_ast_var2007, _allocate_local_35_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_property_env_170_ast_var, _sfun_property1859_159_ast_var2008, _sfun_property1859_159_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_name_env_166_ast_var, _variable_name1932_100_ast_var2009, _variable_name1932_100_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_name_set__env_43_ast_var, _variable_name_set_1931_62_ast_var2010, _variable_name_set_1931_62_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_type_env_20_ast_var, _global_type1906_73_ast_var2011, _global_type1906_73_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1971_ast_var, struct_object__object_value_20_ast_var2012, struct_object__object_value_20_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1969_ast_var, struct_object__object_variable_106_ast_var2013, struct_object__object_variable_106_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1970_ast_var, object__struct_value_130_ast_var2014, object__struct_value_130_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1968_ast_var, object__struct_variable_84_ast_var2015, object__struct_variable_84_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1967_ast_var, struct_object__object_global_249_ast_var2016, struct_object__object_global_249_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1966_ast_var, object__struct_global_193_ast_var2017, object__struct_global_193_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1965_ast_var, struct_object__object_local_234_ast_var2018, struct_object__object_local_234_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1964_ast_var, object__struct_local_56_ast_var2019, object__struct_local_56_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1963_ast_var, struct_object__object_fun_34_ast_var2020, struct_object__object_fun_34_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1962_ast_var, object__struct_fun_194_ast_var2021, object__struct_fun_194_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1961_ast_var, struct_object__object_sfun_10_ast_var2022, struct_object__object_sfun_10_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1959_ast_var, struct_object__object_cfun_108_ast_var2023, struct_object__object_cfun_108_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1960_ast_var, object__struct_sfun_209_ast_var2024, object__struct_sfun_209_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1958_ast_var, object__struct_cfun_117_ast_var2025, object__struct_cfun_117_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1957_ast_var, struct_object__object_svar_1_ast_var2026, struct_object__object_svar_1_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1956_ast_var, object__struct_svar_233_ast_var2027, object__struct_svar_233_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1955_ast_var, struct_object__object_scnst_43_ast_var2028, struct_object__object_scnst_43_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1954_ast_var, object__struct_scnst_111_ast_var2029, object__struct_scnst_111_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1953_ast_var, struct_object__object_cvar_183_ast_var2030, struct_object__object_cvar_183_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1952_ast_var, object__struct_cvar_12_ast_var2031, object__struct_cvar_12_ast_var, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1951_ast_var, struct_object__object_sexit_101_ast_var2032, struct_object__object_sexit_101_ast_var, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1950_ast_var, object__struct_sexit_213_ast_var2033, object__struct_sexit_213_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_occurrence_set__env_144_ast_var, _variable_occurrence_set_1943_127_ast_var2034, _variable_occurrence_set_1943_127_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_the_closure_env_31_ast_var, _sfun_the_closure1857_195_ast_var2035, _sfun_the_closure1857_195_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fun_arity_env_104_ast_var, _fun_arity1871_184_ast_var2036, _fun_arity1871_184_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_fast_alpha_set__env_164_ast_var, _variable_fast_alpha_set_1939_234_ast_var2037, _variable_fast_alpha_set_1939_234_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_occurrence_set__env_80_ast_var, _local_occurrence_set_1896_125_ast_var2038, _local_occurrence_set_1896_125_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_id_env_112_ast_var, _global_id1902_142_ast_var2039, _global_id1902_142_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_access_set__env_189_ast_var, _local_access_set_1890_135_ast_var2040, _local_access_set_1890_135_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_access_env_97_ast_var, _global_access1910_248_ast_var2041, _global_access1910_248_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_top__env_46_ast_var, _cfun_top_1839_213_ast_var2042, _cfun_top_1839_213_ast_var, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(make_fun_env_121_ast_var, _make_fun1870_204_ast_var2043, _make_fun1870_204_ast_var, 0L, 6);
DEFINE_EXPORT_PROCEDURE(local_fast_alpha_set__env_20_ast_var, _local_fast_alpha_set_1892_179_ast_var2044, _local_fast_alpha_set_1892_179_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_user__env_54_ast_var, _global_user_1925_58_ast_var2045, _global_user_1925_58_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_macro__env_51_ast_var, _cfun_macro_1843_180_ast_var2046, _cfun_macro_1843_180_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_side_effect__set__env_233_ast_var, _cfun_side_effect__set_1832_159_ast_var2047, _cfun_side_effect__set_1832_159_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_scnst_env_172_ast_var, _make_scnst_248_ast_var2048, _make_scnst_248_ast_var, 0L, 3);
DEFINE_EXPORT_PROCEDURE(variable_fast_alpha_env_104_ast_var, _variable_fast_alpha1940_254_ast_var2049, _variable_fast_alpha1940_254_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(scnst_node_env_65_ast_var, _scnst_node1823_67_ast_var2050, _scnst_node1823_67_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_sexit_env_61_ast_var, _allocate_sexit_130_ast_var2051, _allocate_sexit_130_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(allocate_variable_env_212_ast_var, _allocate_variable_137_ast_var2052, _allocate_variable_137_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(global_src_set__env_126_ast_var, _global_src_set_1927_160_ast_var2053, _global_src_set_1927_160_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_evaluable__set__env_148_ast_var, _global_evaluable__set_1920_157_ast_var2054, _global_evaluable__set_1920_157_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(variable_removable_env_52_ast_var, _variable_removable1942_189_ast_var2055, _variable_removable1942_189_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_property_set__env_147_ast_var, _sfun_property_set_1858_127_ast_var2056, _sfun_property_set_1858_127_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_value_set__env_20_ast_var, _local_value_set_1888_45_ast_var2057, _local_value_set_1888_45_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local__env_255_ast_var, _local__113_ast_var2058, _local__113_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_detached__set__env_159_ast_var, _sexit_detached__set_1820_99_ast_var2059, _sexit_detached__set_1820_99_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fun__env_177_ast_var, _fun__116_ast_var2060, _fun__116_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_value_env_145_ast_var, _variable_value1936_49_ast_var2061, _variable_value1936_49_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_top__env_125_ast_var, _sfun_top_1855_92_ast_var2062, _sfun_top_1855_92_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_infix__set__env_176_ast_var, _cfun_infix__set_1844_216_ast_var2063, _cfun_infix__set_1844_216_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_loc_env_34_ast_var, _sfun_loc1869_33_ast_var2064, _sfun_loc1869_33_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_local_env_120_ast_var, _make_local1882_116_ast_var2065, _make_local1882_116_ast_var, 0L, 10);
DEFINE_EXPORT_PROCEDURE(fun_top__env_140_ast_var, _fun_top_1879_211_ast_var2066, _fun_top_1879_211_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_value_set__env_220_ast_var, _global_value_set_1907_238_ast_var2067, _global_value_set_1907_238_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(value__env_37_ast_var, _value__210_ast_var2068, _value__210_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_user__env_177_ast_var, _local_user_1899_231_ast_var2069, _local_user_1899_231_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_top__set__env_253_ast_var, _cfun_top__set_1838_41_ast_var2070, _cfun_top__set_1838_41_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(scnst_class_env_83_ast_var, _scnst_class1825_34_ast_var2071, _scnst_class1825_34_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cvar_macro__env_250_ast_var, _cvar_macro_1822_142_ast_var2072, _cvar_macro_1822_142_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_name_set__env_177_ast_var, _global_name_set_1903_31_ast_var2073, _global_name_set_1903_31_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_svar_env_12_ast_var, _allocate_svar_73_ast_var2074, _allocate_svar_73_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(variable__env_90_ast_var, _variable__238_ast_var2075, _variable__238_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_args_env_156_ast_var, _sfun_args1861_246_ast_var2076, _sfun_args1861_246_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fun_the_closure_env_152_ast_var, _fun_the_closure1881_113_ast_var2077, _fun_the_closure1881_113_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(scnst_loc_set__env_227_ast_var, _scnst_loc_set_1826_74_ast_var2078, _scnst_loc_set_1826_74_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_body_set__env_125_ast_var, _sfun_body_set_1862_31_ast_var2079, _sfun_body_set_1862_31_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_sfun_env_18_ast_var, _allocate_sfun_141_ast_var2080, _allocate_sfun_141_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_svar_env_198_ast_var, _make_svar_17_ast_var2081, _make_svar_17_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_side_effect__set__env_247_ast_var, _sfun_side_effect__set_1848_147_ast_var2082, _sfun_side_effect__set_1848_147_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_sfun_env_102_ast_var, _make_sfun1846_247_ast_var2083, _make_sfun1846_247_ast_var, 0L, 12);
DEFINE_EXPORT_PROCEDURE(allocate_global_env_97_ast_var, _allocate_global_232_ast_var2084, _allocate_global_232_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(variable_access_set__env_153_ast_var, _variable_access_set_1937_226_ast_var2085, _variable_access_set_1937_226_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_pragma_env_166_ast_var, _global_pragma1926_131_ast_var2086, _global_pragma1926_131_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_type_set__env_235_ast_var, _variable_type_set_1933_207_ast_var2087, _variable_type_set_1933_207_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(variable_id_env_187_ast_var, _variable_id1930_132_ast_var2088, _variable_id1930_132_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_module_env_223_ast_var, _global_module1917_19_ast_var2089, _global_module1917_19_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar__env_53_ast_var, _svar__166_ast_var2090, _svar__166_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_infix__env_248_ast_var, _cfun_infix_1845_83_ast_var2091, _cfun_infix_1845_83_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_name_env_137_ast_var, _local_name1885_77_ast_var2092, _local_name1885_77_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_user__set__env_133_ast_var, _local_user__set_1898_41_ast_var2093, _local_user__set_1898_41_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_loc_set__env_181_ast_var, _sfun_loc_set_1868_144_ast_var2094, _sfun_loc_set_1868_144_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_stack_allocator_set__env_160_ast_var, _sfun_stack_allocator_set_1852_160_ast_var2095, _sfun_stack_allocator_set_1852_160_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_evaluable__env_89_ast_var, _global_evaluable_1921_23_ast_var2096, _global_evaluable_1921_23_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_src_env_218_ast_var, _global_src1928_118_ast_var2097, _global_src1928_118_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_id_env_233_ast_var, _local_id1883_127_ast_var2098, _local_id1883_127_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_sexit_env_141_ast_var, _make_sexit_67_ast_var2099, _make_sexit_67_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfun_the_closure_env_247_ast_var, _cfun_the_closure1841_181_ast_var2100, _cfun_the_closure1841_181_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(scnst__env_215_ast_var, _scnst__164_ast_var2101, _scnst__164_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_key_env_15_ast_var, _local_key1900_156_ast_var2102, _local_key1900_156_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_occurrence_set__env_58_ast_var, _global_occurrence_set_1915_159_ast_var2103, _global_occurrence_set_1915_159_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_side_effect__env_171_ast_var, _sfun_side_effect_1849_38_ast_var2104, _sfun_side_effect_1849_38_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_fun_env_191_ast_var, _allocate_fun_230_ast_var2105, _allocate_fun_230_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(fun_predicate_of_set__env_255_ast_var, _fun_predicate_of_set_1874_48_ast_var2106, _fun_predicate_of_set_1874_48_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_loc_env_214_ast_var, _svar_loc1829_27_ast_var2107, _svar_loc1829_27_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cfun_arity_env_179_ast_var, _cfun_arity1831_223_ast_var2108, _cfun_arity1831_223_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_access_env_239_ast_var, _local_access1891_206_ast_var2109, _local_access1891_206_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_body_env_9_ast_var, _sfun_body1863_190_ast_var2110, _sfun_body1863_190_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_user__set__env_159_ast_var, _global_user__set_1924_213_ast_var2111, _global_user__set_1924_213_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_removable_env_240_ast_var, _global_removable1914_19_ast_var2112, _global_removable1914_19_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_fast_alpha_set__env_25_ast_var, _global_fast_alpha_set_1911_201_ast_var2113, _global_fast_alpha_set_1911_201_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_name_env_232_ast_var, _global_name1904_201_ast_var2114, _global_name1904_201_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_value_env_180_ast_var, _global_value1908_139_ast_var2115, _global_value1908_139_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_occurrence_env_185_ast_var, _local_occurrence1897_134_ast_var2116, _local_occurrence1897_134_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_library__set__env_36_ast_var, _global_library__set_1922_202_ast_var2117, _global_library__set_1922_202_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_detached__env_54_ast_var, _sexit_detached_1821_101_ast_var2118, _sexit_detached_1821_101_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_type_env_30_ast_var, _variable_type1934_235_ast_var2119, _variable_type1934_235_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_arity_env_92_ast_var, _sfun_arity1847_91_ast_var2120, _sfun_arity1847_91_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(variable_access_env_219_ast_var, _variable_access1938_157_ast_var2121, _variable_access1938_157_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_global_env_133_ast_var, _make_global1901_192_ast_var2122, _make_global1901_192_ast_var, 0L, 15);
DEFINE_EXPORT_PROCEDURE(cfun_args_type_env_193_ast_var, _cfun_args_type1842_81_ast_var2123, _cfun_args_type1842_81_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun__env_206_ast_var, _sfun__63_ast_var2124, _sfun__63_ast_var, 0L, 1);
DEFINE_STRING(string1972_ast_var, string1972_ast_var2125, "SEXIT CVAR SCNST SVAR CFUN SFUN FUN LOCAL GLOBAL VARIABLE VALUE ", 64);
DEFINE_EXPORT_PROCEDURE(cfun_side_effect__env_150_ast_var, _cfun_side_effect_1833_17_ast_var2126, _cfun_side_effect_1833_17_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global__env_111_ast_var, _global__76_ast_var2127, _global__76_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_occurrence_env_158_ast_var, _global_occurrence1916_151_ast_var2128, _global_occurrence1916_151_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_library__env_3_ast_var, _global_library_1923_164_ast_var2129, _global_library_1923_164_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_handler_set__env_61_ast_var, _sexit_handler_set_1818_167_ast_var2130, _sexit_handler_set_1818_167_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfun_predicate_of_set__env_32_ast_var, _cfun_predicate_of_set_1834_95_ast_var2131, _cfun_predicate_of_set_1834_95_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_removable_set__env_101_ast_var, _local_removable_set_1894_80_ast_var2132, _local_removable_set_1894_80_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fun_side_effect__env_212_ast_var, _fun_side_effect_1873_86_ast_var2133, _fun_side_effect_1873_86_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(cvar__env_220_ast_var, _cvar__164_ast_var2134, _cvar__164_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_name_set__env_228_ast_var, _local_name_set_1884_228_ast_var2135, _local_name_set_1884_228_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(global_removable_set__env_123_ast_var, _global_removable_set_1913_117_ast_var2136, _global_removable_set_1913_117_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_value_env_32_ast_var, _local_value1889_74_ast_var2137, _local_value1889_74_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_handler_env_38_ast_var, _sexit_handler1819_47_ast_var2138, _sexit_handler1819_47_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_type_set__env_45_ast_var, _global_type_set_1905_127_ast_var2139, _global_type_set_1905_127_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfun_the_closure_set__env_37_ast_var, _cfun_the_closure_set_1840_178_ast_var2140, _cfun_the_closure_set_1840_178_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_value_env_188_ast_var, _allocate_value_13_ast_var2141, _allocate_value_13_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(variable_value_set__env_150_ast_var, _variable_value_set_1935_216_ast_var2142, _variable_value_set_1935_216_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_args_set__env_104_ast_var, _sfun_args_set_1860_227_ast_var2143, _sfun_args_set_1860_227_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fun_stack_allocator_set__env_50_ast_var, _fun_stack_allocator_set_1876_28_ast_var2144, _fun_stack_allocator_set_1876_28_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_loc_set__env_17_ast_var, _svar_loc_set_1828_105_ast_var2145, _svar_loc_set_1828_105_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_fast_alpha_env_32_ast_var, _local_fast_alpha1893_30_ast_var2146, _local_fast_alpha1893_30_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(global_import_set__env_98_ast_var, _global_import_set_1918_247_ast_var2147, _global_import_set_1918_247_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(variable_removable_set__env_12_ast_var, _variable_removable_set_1941_231_ast_var2148, _variable_removable_set_1941_231_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(scnst_class_set__env_234_ast_var, _scnst_class_set_1824_123_ast_var2149, _scnst_class_set_1824_123_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_predicate_of_env_111_ast_var, _sfun_predicate_of1851_65_ast_var2150, _sfun_predicate_of1851_65_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_top__set__env_194_ast_var, _sfun_top__set_1854_44_ast_var2151, _sfun_top__set_1854_44_ast_var, 0L, 2);
DEFINE_EXPORT_PROCEDURE(fun_the_closure_set__env_51_ast_var, _fun_the_closure_set_1880_102_ast_var2152, _fun_the_closure_set_1880_102_ast_var, 0L, 2);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(global_fast_alpha_env_200_ast_var, _global_fast_alpha1912_51_ast_var2153, _global_fast_alpha1912_51_ast_var, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_cvar_env_85_ast_var, _allocate_cvar_101_ast_var2154, _allocate_cvar_101_ast_var, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cfun_stack_allocator_set__env_86_ast_var, _cfun_stack_allocator_set_1836_163_ast_var2155, _cfun_stack_allocator_set_1836_163_ast_var, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_ast_var(long checksum_1992, char *from_1993)
{
   if (CBOOL(require_initialization_114_ast_var))
     {
	require_initialization_114_ast_var = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_var();
	cnst_init_137_ast_var();
	imported_modules_init_94_ast_var();
	object_init_111_ast_var();
	method_init_76_ast_var();
	toplevel_init_63_ast_var();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_var()
{
   module_initialization_70___object(((long) 0), "AST_VAR");
   module_initialization_70___reader(((long) 0), "AST_VAR");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_var()
{
   {
      obj_t cnst_port_138_1984;
      cnst_port_138_1984 = open_input_string(string1972_ast_var);
      {
	 long i_1985;
	 i_1985 = ((long) 10);
       loop_1986:
	 {
	    bool_t test1973_1987;
	    test1973_1987 = (i_1985 == ((long) -1));
	    if (test1973_1987)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1974_1988;
		    {
		       obj_t list1975_1989;
		       {
			  obj_t arg1977_1990;
			  arg1977_1990 = BNIL;
			  list1975_1989 = MAKE_PAIR(cnst_port_138_1984, arg1977_1990);
		       }
		       arg1974_1988 = read___reader(list1975_1989);
		    }
		    CNST_TABLE_SET(i_1985, arg1974_1988);
		 }
		 {
		    int aux_1991;
		    {
		       long aux_2011;
		       aux_2011 = (i_1985 - ((long) 1));
		       aux_1991 = (int) (aux_2011);
		    }
		    {
		       long i_2014;
		       i_2014 = (long) (aux_1991);
		       i_1985 = i_2014;
		       goto loop_1986;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_var()
{
   return BUNSPEC;
}


/* object-init */ obj_t 
object_init_111_ast_var()
{
   {
      obj_t arg1497_335;
      arg1497_335 = object___object;
      value_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 0)), arg1497_335, allocate_value_env_188_ast_var, ((long) 28797), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1501_339;
      arg1501_339 = object___object;
      variable_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1501_339, allocate_variable_env_212_ast_var, ((long) 63181), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1505_343;
      arg1505_343 = variable_ast_var;
      global_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1505_343, allocate_global_env_97_ast_var, ((long) 56592), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1513_347;
      arg1513_347 = variable_ast_var;
      local_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 3)), arg1513_347, allocate_local_env_7_ast_var, ((long) 39680), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1517_351;
      arg1517_351 = value_ast_var;
      fun_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 4)), arg1517_351, allocate_fun_env_191_ast_var, ((long) 36716), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1524_355;
      arg1524_355 = fun_ast_var;
      sfun_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 5)), arg1524_355, allocate_sfun_env_18_ast_var, ((long) 16709), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1528_359;
      arg1528_359 = fun_ast_var;
      cfun_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 6)), arg1528_359, allocate_cfun_env_241_ast_var, ((long) 5204), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1532_363;
      arg1532_363 = value_ast_var;
      svar_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 7)), arg1532_363, allocate_svar_env_12_ast_var, ((long) 4410), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1536_367;
      arg1536_367 = value_ast_var;
      scnst_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 8)), arg1536_367, allocate_scnst_env_226_ast_var, ((long) 28261), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1542_371;
      arg1542_371 = value_ast_var;
      cvar_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 9)), arg1542_371, allocate_cvar_env_85_ast_var, ((long) 10029), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1550_375;
      arg1550_375 = value_ast_var;
      sexit_ast_var = add_class__117___object(CNST_TABLE_REF(((long) 10)), arg1550_375, allocate_sexit_env_61_ast_var, ((long) 29641), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-sexit */ sexit_t 
allocate_sexit_47_ast_var()
{
   {
      sexit_t new1462_378;
      new1462_378 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
      {
	 long arg1554_379;
	 arg1554_379 = class_num_218___object(sexit_ast_var);
	 {
	    obj_t obj_871;
	    obj_871 = (obj_t) (new1462_378);
	    (((obj_t) CREF(obj_871))->header = MAKE_HEADER(arg1554_379, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2042;
	 aux_2042 = (object_t) (new1462_378);
	 OBJECT_WIDENING_SET(aux_2042, BFALSE);
      }
      return new1462_378;
   }
}


/* _allocate-sexit */ obj_t 
_allocate_sexit_130_ast_var(obj_t env_1505)
{
   {
      sexit_t aux_2045;
      aux_2045 = allocate_sexit_47_ast_var();
      return (obj_t) (aux_2045);
   }
}


/* sexit? */ bool_t 
sexit__36_ast_var(obj_t obj_4)
{
   return is_a__118___object(obj_4, sexit_ast_var);
}


/* _sexit? */ obj_t 
_sexit__255_ast_var(obj_t env_1506, obj_t obj_1507)
{
   {
      bool_t aux_2049;
      aux_2049 = sexit__36_ast_var(obj_1507);
      return BBOOL(aux_2049);
   }
}


/* make-sexit */ sexit_t 
make_sexit_79_ast_var(obj_t handler_5, bool_t detached__120_6)
{
   {
      sexit_t new1456_873;
      new1456_873 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
      {
	 long arg1555_874;
	 arg1555_874 = class_num_218___object(sexit_ast_var);
	 {
	    obj_t obj_877;
	    obj_877 = (obj_t) (new1456_873);
	    (((obj_t) CREF(obj_877))->header = MAKE_HEADER(arg1555_874, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2056;
	 aux_2056 = (object_t) (new1456_873);
	 OBJECT_WIDENING_SET(aux_2056, BFALSE);
      }
      ((((sexit_t) CREF(new1456_873))->handler) = ((obj_t) handler_5), BUNSPEC);
      ((((sexit_t) CREF(new1456_873))->detached__120) = ((bool_t) detached__120_6), BUNSPEC);
      return new1456_873;
   }
}


/* _make-sexit */ obj_t 
_make_sexit_67_ast_var(obj_t env_1508, obj_t handler_1509, obj_t detached__120_1510)
{
   {
      sexit_t aux_2061;
      aux_2061 = make_sexit_79_ast_var(handler_1509, CBOOL(detached__120_1510));
      return (obj_t) (aux_2061);
   }
}


/* sexit-handler-set! */ obj_t 
sexit_handler_set__47_ast_var(sexit_t obj_7, obj_t val1460_8)
{
   return ((((sexit_t) CREF(obj_7))->handler) = ((obj_t) val1460_8), BUNSPEC);
}


/* _sexit-handler-set!1818 */ obj_t 
_sexit_handler_set_1818_167_ast_var(obj_t env_1511, obj_t obj_1512, obj_t val1460_1513)
{
   return sexit_handler_set__47_ast_var((sexit_t) (obj_1512), val1460_1513);
}


/* sexit-handler */ obj_t 
sexit_handler_210_ast_var(sexit_t obj_9)
{
   return (((sexit_t) CREF(obj_9))->handler);
}


/* _sexit-handler1819 */ obj_t 
_sexit_handler1819_47_ast_var(obj_t env_1514, obj_t obj_1515)
{
   return sexit_handler_210_ast_var((sexit_t) (obj_1515));
}


/* sexit-detached?-set! */ obj_t 
sexit_detached__set__116_ast_var(sexit_t obj_10, bool_t val1461_11)
{
   return ((((sexit_t) CREF(obj_10))->detached__120) = ((bool_t) val1461_11), BUNSPEC);
}


/* _sexit-detached?-set!1820 */ obj_t 
_sexit_detached__set_1820_99_ast_var(obj_t env_1516, obj_t obj_1517, obj_t val1461_1518)
{
   return sexit_detached__set__116_ast_var((sexit_t) (obj_1517), CBOOL(val1461_1518));
}


/* sexit-detached? */ bool_t 
sexit_detached__208_ast_var(sexit_t obj_12)
{
   return (((sexit_t) CREF(obj_12))->detached__120);
}


/* _sexit-detached?1821 */ obj_t 
_sexit_detached_1821_101_ast_var(obj_t env_1519, obj_t obj_1520)
{
   {
      bool_t aux_2076;
      aux_2076 = sexit_detached__208_ast_var((sexit_t) (obj_1520));
      return BBOOL(aux_2076);
   }
}


/* allocate-cvar */ cvar_t 
allocate_cvar_254_ast_var()
{
   {
      cvar_t new1448_384;
      new1448_384 = ((cvar_t) BREF(GC_MALLOC(sizeof(struct cvar))));
      {
	 long arg1556_385;
	 arg1556_385 = class_num_218___object(cvar_ast_var);
	 {
	    obj_t obj_879;
	    obj_879 = (obj_t) (new1448_384);
	    (((obj_t) CREF(obj_879))->header = MAKE_HEADER(arg1556_385, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2084;
	 aux_2084 = (object_t) (new1448_384);
	 OBJECT_WIDENING_SET(aux_2084, BFALSE);
      }
      return new1448_384;
   }
}


/* _allocate-cvar */ obj_t 
_allocate_cvar_101_ast_var(obj_t env_1504)
{
   {
      cvar_t aux_2087;
      aux_2087 = allocate_cvar_254_ast_var();
      return (obj_t) (aux_2087);
   }
}


/* cvar? */ bool_t 
cvar__118_ast_var(obj_t obj_16)
{
   return is_a__118___object(obj_16, cvar_ast_var);
}


/* _cvar? */ obj_t 
_cvar__164_ast_var(obj_t env_1521, obj_t obj_1522)
{
   {
      bool_t aux_2091;
      aux_2091 = cvar__118_ast_var(obj_1522);
      return BBOOL(aux_2091);
   }
}


/* make-cvar */ cvar_t 
make_cvar_132_ast_var(bool_t macro__33_17)
{
   {
      cvar_t new1445_881;
      new1445_881 = ((cvar_t) BREF(GC_MALLOC(sizeof(struct cvar))));
      {
	 long arg1557_882;
	 arg1557_882 = class_num_218___object(cvar_ast_var);
	 {
	    obj_t obj_884;
	    obj_884 = (obj_t) (new1445_881);
	    (((obj_t) CREF(obj_884))->header = MAKE_HEADER(arg1557_882, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2098;
	 aux_2098 = (object_t) (new1445_881);
	 OBJECT_WIDENING_SET(aux_2098, BFALSE);
      }
      ((((cvar_t) CREF(new1445_881))->macro__33) = ((bool_t) macro__33_17), BUNSPEC);
      return new1445_881;
   }
}


/* _make-cvar */ obj_t 
_make_cvar_142_ast_var(obj_t env_1523, obj_t macro__33_1524)
{
   {
      cvar_t aux_2102;
      aux_2102 = make_cvar_132_ast_var(CBOOL(macro__33_1524));
      return (obj_t) (aux_2102);
   }
}


/* cvar-macro? */ bool_t 
cvar_macro__32_ast_var(cvar_t obj_18)
{
   return (((cvar_t) CREF(obj_18))->macro__33);
}


/* _cvar-macro?1822 */ obj_t 
_cvar_macro_1822_142_ast_var(obj_t env_1525, obj_t obj_1526)
{
   {
      bool_t aux_2107;
      aux_2107 = cvar_macro__32_ast_var((cvar_t) (obj_1526));
      return BBOOL(aux_2107);
   }
}


/* allocate-scnst */ scnst_t 
allocate_scnst_81_ast_var()
{
   {
      scnst_t new1430_389;
      new1430_389 = ((scnst_t) BREF(GC_MALLOC(sizeof(struct scnst))));
      {
	 long arg1558_390;
	 arg1558_390 = class_num_218___object(scnst_ast_var);
	 {
	    obj_t obj_886;
	    obj_886 = (obj_t) (new1430_389);
	    (((obj_t) CREF(obj_886))->header = MAKE_HEADER(arg1558_390, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2115;
	 aux_2115 = (object_t) (new1430_389);
	 OBJECT_WIDENING_SET(aux_2115, BFALSE);
      }
      return new1430_389;
   }
}


/* _allocate-scnst */ obj_t 
_allocate_scnst_4_ast_var(obj_t env_1503)
{
   {
      scnst_t aux_2118;
      aux_2118 = allocate_scnst_81_ast_var();
      return (obj_t) (aux_2118);
   }
}


/* scnst? */ bool_t 
scnst__249_ast_var(obj_t obj_22)
{
   return is_a__118___object(obj_22, scnst_ast_var);
}


/* _scnst? */ obj_t 
_scnst__164_ast_var(obj_t env_1527, obj_t obj_1528)
{
   {
      bool_t aux_2122;
      aux_2122 = scnst__249_ast_var(obj_1528);
      return BBOOL(aux_2122);
   }
}


/* make-scnst */ scnst_t 
make_scnst_115_ast_var(obj_t node_23, obj_t class_24, obj_t loc_25)
{
   {
      scnst_t new1423_888;
      new1423_888 = ((scnst_t) BREF(GC_MALLOC(sizeof(struct scnst))));
      {
	 long arg1559_889;
	 arg1559_889 = class_num_218___object(scnst_ast_var);
	 {
	    obj_t obj_893;
	    obj_893 = (obj_t) (new1423_888);
	    (((obj_t) CREF(obj_893))->header = MAKE_HEADER(arg1559_889, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2129;
	 aux_2129 = (object_t) (new1423_888);
	 OBJECT_WIDENING_SET(aux_2129, BFALSE);
      }
      ((((scnst_t) CREF(new1423_888))->node) = ((obj_t) node_23), BUNSPEC);
      ((((scnst_t) CREF(new1423_888))->class) = ((obj_t) class_24), BUNSPEC);
      ((((scnst_t) CREF(new1423_888))->loc) = ((obj_t) loc_25), BUNSPEC);
      return new1423_888;
   }
}


/* _make-scnst */ obj_t 
_make_scnst_248_ast_var(obj_t env_1529, obj_t node_1530, obj_t class_1531, obj_t loc_1532)
{
   {
      scnst_t aux_2135;
      aux_2135 = make_scnst_115_ast_var(node_1530, class_1531, loc_1532);
      return (obj_t) (aux_2135);
   }
}


/* scnst-node */ obj_t 
scnst_node_98_ast_var(scnst_t obj_26)
{
   return (((scnst_t) CREF(obj_26))->node);
}


/* _scnst-node1823 */ obj_t 
_scnst_node1823_67_ast_var(obj_t env_1533, obj_t obj_1534)
{
   return scnst_node_98_ast_var((scnst_t) (obj_1534));
}


/* scnst-class-set! */ obj_t 
scnst_class_set__87_ast_var(scnst_t obj_27, obj_t val1428_28)
{
   return ((((scnst_t) CREF(obj_27))->class) = ((obj_t) val1428_28), BUNSPEC);
}


/* _scnst-class-set!1824 */ obj_t 
_scnst_class_set_1824_123_ast_var(obj_t env_1535, obj_t obj_1536, obj_t val1428_1537)
{
   return scnst_class_set__87_ast_var((scnst_t) (obj_1536), val1428_1537);
}


/* scnst-class */ obj_t 
scnst_class_73_ast_var(scnst_t obj_29)
{
   return (((scnst_t) CREF(obj_29))->class);
}


/* _scnst-class1825 */ obj_t 
_scnst_class1825_34_ast_var(obj_t env_1538, obj_t obj_1539)
{
   return scnst_class_73_ast_var((scnst_t) (obj_1539));
}


/* scnst-loc-set! */ obj_t 
scnst_loc_set__206_ast_var(scnst_t obj_30, obj_t val1429_31)
{
   return ((((scnst_t) CREF(obj_30))->loc) = ((obj_t) val1429_31), BUNSPEC);
}


/* _scnst-loc-set!1826 */ obj_t 
_scnst_loc_set_1826_74_ast_var(obj_t env_1540, obj_t obj_1541, obj_t val1429_1542)
{
   return scnst_loc_set__206_ast_var((scnst_t) (obj_1541), val1429_1542);
}


/* scnst-loc */ obj_t 
scnst_loc_19_ast_var(scnst_t obj_32)
{
   return (((scnst_t) CREF(obj_32))->loc);
}


/* _scnst-loc1827 */ obj_t 
_scnst_loc1827_66_ast_var(obj_t env_1543, obj_t obj_1544)
{
   return scnst_loc_19_ast_var((scnst_t) (obj_1544));
}


/* allocate-svar */ svar_t 
allocate_svar_218_ast_var()
{
   {
      svar_t new1416_396;
      new1416_396 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
      {
	 long arg1560_397;
	 arg1560_397 = class_num_218___object(svar_ast_var);
	 {
	    obj_t obj_895;
	    obj_895 = (obj_t) (new1416_396);
	    (((obj_t) CREF(obj_895))->header = MAKE_HEADER(arg1560_397, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2157;
	 aux_2157 = (object_t) (new1416_396);
	 OBJECT_WIDENING_SET(aux_2157, BFALSE);
      }
      return new1416_396;
   }
}


/* _allocate-svar */ obj_t 
_allocate_svar_73_ast_var(obj_t env_1502)
{
   {
      svar_t aux_2160;
      aux_2160 = allocate_svar_218_ast_var();
      return (obj_t) (aux_2160);
   }
}


/* svar? */ bool_t 
svar__161_ast_var(obj_t obj_36)
{
   return is_a__118___object(obj_36, svar_ast_var);
}


/* _svar? */ obj_t 
_svar__166_ast_var(obj_t env_1545, obj_t obj_1546)
{
   {
      bool_t aux_2164;
      aux_2164 = svar__161_ast_var(obj_1546);
      return BBOOL(aux_2164);
   }
}


/* make-svar */ svar_t 
make_svar_231_ast_var(obj_t loc_37)
{
   {
      svar_t new1412_897;
      new1412_897 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
      {
	 long arg1561_898;
	 arg1561_898 = class_num_218___object(svar_ast_var);
	 {
	    obj_t obj_900;
	    obj_900 = (obj_t) (new1412_897);
	    (((obj_t) CREF(obj_900))->header = MAKE_HEADER(arg1561_898, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2171;
	 aux_2171 = (object_t) (new1412_897);
	 OBJECT_WIDENING_SET(aux_2171, BFALSE);
      }
      ((((svar_t) CREF(new1412_897))->loc) = ((obj_t) loc_37), BUNSPEC);
      return new1412_897;
   }
}


/* _make-svar */ obj_t 
_make_svar_17_ast_var(obj_t env_1547, obj_t loc_1548)
{
   {
      svar_t aux_2175;
      aux_2175 = make_svar_231_ast_var(loc_1548);
      return (obj_t) (aux_2175);
   }
}


/* svar-loc-set! */ obj_t 
svar_loc_set__106_ast_var(svar_t obj_38, obj_t val1415_39)
{
   return ((((svar_t) CREF(obj_38))->loc) = ((obj_t) val1415_39), BUNSPEC);
}


/* _svar-loc-set!1828 */ obj_t 
_svar_loc_set_1828_105_ast_var(obj_t env_1549, obj_t obj_1550, obj_t val1415_1551)
{
   return svar_loc_set__106_ast_var((svar_t) (obj_1550), val1415_1551);
}


/* svar-loc */ obj_t 
svar_loc_189_ast_var(svar_t obj_40)
{
   return (((svar_t) CREF(obj_40))->loc);
}


/* _svar-loc1829 */ obj_t 
_svar_loc1829_27_ast_var(obj_t env_1552, obj_t obj_1553)
{
   return svar_loc_189_ast_var((svar_t) (obj_1553));
}


/* allocate-cfun */ cfun_t 
allocate_cfun_23_ast_var()
{
   {
      cfun_t new1373_401;
      new1373_401 = ((cfun_t) BREF(GC_MALLOC(sizeof(struct cfun))));
      {
	 long arg1562_402;
	 arg1562_402 = class_num_218___object(cfun_ast_var);
	 {
	    obj_t obj_902;
	    obj_902 = (obj_t) (new1373_401);
	    (((obj_t) CREF(obj_902))->header = MAKE_HEADER(arg1562_402, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2188;
	 aux_2188 = (object_t) (new1373_401);
	 OBJECT_WIDENING_SET(aux_2188, BFALSE);
      }
      return new1373_401;
   }
}


/* _allocate-cfun */ obj_t 
_allocate_cfun_27_ast_var(obj_t env_1501)
{
   {
      cfun_t aux_2191;
      aux_2191 = allocate_cfun_23_ast_var();
      return (obj_t) (aux_2191);
   }
}


/* cfun? */ bool_t 
cfun__213_ast_var(obj_t obj_44)
{
   return is_a__118___object(obj_44, cfun_ast_var);
}


/* _cfun? */ obj_t 
_cfun__201_ast_var(obj_t env_1554, obj_t obj_1555)
{
   {
      bool_t aux_2195;
      aux_2195 = cfun__213_ast_var(obj_1555);
      return BBOOL(aux_2195);
   }
}


/* make-cfun */ cfun_t 
make_cfun_58_ast_var(long arity_45, obj_t side_effect__165_46, obj_t predicate_of_78_47, obj_t stack_allocator_172_48, bool_t top__138_49, obj_t the_closure_238_50, obj_t args_type_205_51, bool_t macro__33_52, bool_t infix__163_53)
{
   {
      cfun_t new1356_904;
      new1356_904 = ((cfun_t) BREF(GC_MALLOC(sizeof(struct cfun))));
      {
	 long arg1563_905;
	 arg1563_905 = class_num_218___object(cfun_ast_var);
	 {
	    obj_t obj_915;
	    obj_915 = (obj_t) (new1356_904);
	    (((obj_t) CREF(obj_915))->header = MAKE_HEADER(arg1563_905, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2202;
	 aux_2202 = (object_t) (new1356_904);
	 OBJECT_WIDENING_SET(aux_2202, BFALSE);
      }
      ((((cfun_t) CREF(new1356_904))->arity) = ((long) arity_45), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->side_effect__165) = ((obj_t) side_effect__165_46), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->predicate_of_78) = ((obj_t) predicate_of_78_47), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->stack_allocator_172) = ((obj_t) stack_allocator_172_48), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->top__138) = ((bool_t) top__138_49), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->the_closure_238) = ((obj_t) the_closure_238_50), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->args_type_205) = ((obj_t) args_type_205_51), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->macro__33) = ((bool_t) macro__33_52), BUNSPEC);
      ((((cfun_t) CREF(new1356_904))->infix__163) = ((bool_t) infix__163_53), BUNSPEC);
      return new1356_904;
   }
}


/* _make-cfun1830 */ obj_t 
_make_cfun1830_194_ast_var(obj_t env_1556, obj_t arity_1557, obj_t side_effect__165_1558, obj_t predicate_of_78_1559, obj_t stack_allocator_172_1560, obj_t top__138_1561, obj_t the_closure_238_1562, obj_t args_type_205_1563, obj_t macro__33_1564, obj_t infix__163_1565)
{
   {
      cfun_t aux_2214;
      aux_2214 = make_cfun_58_ast_var((long) CINT(arity_1557), side_effect__165_1558, predicate_of_78_1559, stack_allocator_172_1560, CBOOL(top__138_1561), the_closure_238_1562, args_type_205_1563, CBOOL(macro__33_1564), CBOOL(infix__163_1565));
      return (obj_t) (aux_2214);
   }
}


/* cfun-arity */ long 
cfun_arity_68_ast_var(cfun_t obj_54)
{
   return (((cfun_t) CREF(obj_54))->arity);
}


/* _cfun-arity1831 */ obj_t 
_cfun_arity1831_223_ast_var(obj_t env_1566, obj_t obj_1567)
{
   {
      long aux_2222;
      aux_2222 = cfun_arity_68_ast_var((cfun_t) (obj_1567));
      return BINT(aux_2222);
   }
}


/* cfun-side-effect?-set! */ obj_t 
cfun_side_effect__set__1_ast_var(cfun_t obj_55, obj_t val1367_56)
{
   return ((((cfun_t) CREF(obj_55))->side_effect__165) = ((obj_t) val1367_56), BUNSPEC);
}


/* _cfun-side-effect?-set!1832 */ obj_t 
_cfun_side_effect__set_1832_159_ast_var(obj_t env_1568, obj_t obj_1569, obj_t val1367_1570)
{
   return cfun_side_effect__set__1_ast_var((cfun_t) (obj_1569), val1367_1570);
}


/* cfun-side-effect? */ obj_t 
cfun_side_effect__250_ast_var(cfun_t obj_57)
{
   return (((cfun_t) CREF(obj_57))->side_effect__165);
}


/* _cfun-side-effect?1833 */ obj_t 
_cfun_side_effect_1833_17_ast_var(obj_t env_1571, obj_t obj_1572)
{
   return cfun_side_effect__250_ast_var((cfun_t) (obj_1572));
}


/* cfun-predicate-of-set! */ obj_t 
cfun_predicate_of_set__65_ast_var(cfun_t obj_58, obj_t val1368_59)
{
   return ((((cfun_t) CREF(obj_58))->predicate_of_78) = ((obj_t) val1368_59), BUNSPEC);
}


/* _cfun-predicate-of-set!1834 */ obj_t 
_cfun_predicate_of_set_1834_95_ast_var(obj_t env_1573, obj_t obj_1574, obj_t val1368_1575)
{
   return cfun_predicate_of_set__65_ast_var((cfun_t) (obj_1574), val1368_1575);
}


/* cfun-predicate-of */ obj_t 
cfun_predicate_of_23_ast_var(cfun_t obj_60)
{
   return (((cfun_t) CREF(obj_60))->predicate_of_78);
}


/* _cfun-predicate-of1835 */ obj_t 
_cfun_predicate_of1835_148_ast_var(obj_t env_1576, obj_t obj_1577)
{
   return cfun_predicate_of_23_ast_var((cfun_t) (obj_1577));
}


/* cfun-stack-allocator-set! */ obj_t 
cfun_stack_allocator_set__66_ast_var(cfun_t obj_61, obj_t val1369_62)
{
   return ((((cfun_t) CREF(obj_61))->stack_allocator_172) = ((obj_t) val1369_62), BUNSPEC);
}


/* _cfun-stack-allocator-set!1836 */ obj_t 
_cfun_stack_allocator_set_1836_163_ast_var(obj_t env_1578, obj_t obj_1579, obj_t val1369_1580)
{
   return cfun_stack_allocator_set__66_ast_var((cfun_t) (obj_1579), val1369_1580);
}


/* cfun-stack-allocator */ obj_t 
cfun_stack_allocator_58_ast_var(cfun_t obj_63)
{
   return (((cfun_t) CREF(obj_63))->stack_allocator_172);
}


/* _cfun-stack-allocator1837 */ obj_t 
_cfun_stack_allocator1837_253_ast_var(obj_t env_1581, obj_t obj_1582)
{
   return cfun_stack_allocator_58_ast_var((cfun_t) (obj_1582));
}


/* cfun-top?-set! */ obj_t 
cfun_top__set__230_ast_var(cfun_t obj_64, bool_t val1370_65)
{
   return ((((cfun_t) CREF(obj_64))->top__138) = ((bool_t) val1370_65), BUNSPEC);
}


/* _cfun-top?-set!1838 */ obj_t 
_cfun_top__set_1838_41_ast_var(obj_t env_1583, obj_t obj_1584, obj_t val1370_1585)
{
   return cfun_top__set__230_ast_var((cfun_t) (obj_1584), CBOOL(val1370_1585));
}


/* cfun-top? */ bool_t 
cfun_top__60_ast_var(cfun_t obj_66)
{
   return (((cfun_t) CREF(obj_66))->top__138);
}


/* _cfun-top?1839 */ obj_t 
_cfun_top_1839_213_ast_var(obj_t env_1586, obj_t obj_1587)
{
   {
      bool_t aux_2249;
      aux_2249 = cfun_top__60_ast_var((cfun_t) (obj_1587));
      return BBOOL(aux_2249);
   }
}


/* cfun-the-closure-set! */ obj_t 
cfun_the_closure_set__43_ast_var(cfun_t obj_67, obj_t val1371_68)
{
   return ((((cfun_t) CREF(obj_67))->the_closure_238) = ((obj_t) val1371_68), BUNSPEC);
}


/* _cfun-the-closure-set!1840 */ obj_t 
_cfun_the_closure_set_1840_178_ast_var(obj_t env_1588, obj_t obj_1589, obj_t val1371_1590)
{
   return cfun_the_closure_set__43_ast_var((cfun_t) (obj_1589), val1371_1590);
}


/* cfun-the-closure */ obj_t 
cfun_the_closure_97_ast_var(cfun_t obj_69)
{
   return (((cfun_t) CREF(obj_69))->the_closure_238);
}


/* _cfun-the-closure1841 */ obj_t 
_cfun_the_closure1841_181_ast_var(obj_t env_1591, obj_t obj_1592)
{
   return cfun_the_closure_97_ast_var((cfun_t) (obj_1592));
}


/* cfun-args-type */ obj_t 
cfun_args_type_30_ast_var(cfun_t obj_70)
{
   return (((cfun_t) CREF(obj_70))->args_type_205);
}


/* _cfun-args-type1842 */ obj_t 
_cfun_args_type1842_81_ast_var(obj_t env_1593, obj_t obj_1594)
{
   return cfun_args_type_30_ast_var((cfun_t) (obj_1594));
}


/* cfun-macro? */ bool_t 
cfun_macro__119_ast_var(cfun_t obj_71)
{
   return (((cfun_t) CREF(obj_71))->macro__33);
}


/* _cfun-macro?1843 */ obj_t 
_cfun_macro_1843_180_ast_var(obj_t env_1595, obj_t obj_1596)
{
   {
      bool_t aux_2263;
      aux_2263 = cfun_macro__119_ast_var((cfun_t) (obj_1596));
      return BBOOL(aux_2263);
   }
}


/* cfun-infix?-set! */ obj_t 
cfun_infix__set__175_ast_var(cfun_t obj_72, bool_t val1372_73)
{
   return ((((cfun_t) CREF(obj_72))->infix__163) = ((bool_t) val1372_73), BUNSPEC);
}


/* _cfun-infix?-set!1844 */ obj_t 
_cfun_infix__set_1844_216_ast_var(obj_t env_1597, obj_t obj_1598, obj_t val1372_1599)
{
   return cfun_infix__set__175_ast_var((cfun_t) (obj_1598), CBOOL(val1372_1599));
}


/* cfun-infix? */ bool_t 
cfun_infix__133_ast_var(cfun_t obj_74)
{
   return (((cfun_t) CREF(obj_74))->infix__163);
}


/* _cfun-infix?1845 */ obj_t 
_cfun_infix_1845_83_ast_var(obj_t env_1600, obj_t obj_1601)
{
   {
      bool_t aux_2272;
      aux_2272 = cfun_infix__133_ast_var((cfun_t) (obj_1601));
      return BBOOL(aux_2272);
   }
}


/* allocate-sfun */ sfun_t 
allocate_sfun_135_ast_var()
{
   {
      sfun_t new1305_414;
      new1305_414 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
      {
	 long arg1564_415;
	 arg1564_415 = class_num_218___object(sfun_ast_var);
	 {
	    obj_t obj_917;
	    obj_917 = (obj_t) (new1305_414);
	    (((obj_t) CREF(obj_917))->header = MAKE_HEADER(arg1564_415, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2280;
	 aux_2280 = (object_t) (new1305_414);
	 OBJECT_WIDENING_SET(aux_2280, BFALSE);
      }
      return new1305_414;
   }
}


/* _allocate-sfun */ obj_t 
_allocate_sfun_141_ast_var(obj_t env_1500)
{
   {
      sfun_t aux_2283;
      aux_2283 = allocate_sfun_135_ast_var();
      return (obj_t) (aux_2283);
   }
}


/* sfun? */ bool_t 
sfun__199_ast_var(obj_t obj_78)
{
   return is_a__118___object(obj_78, sfun_ast_var);
}


/* _sfun? */ obj_t 
_sfun__63_ast_var(obj_t env_1602, obj_t obj_1603)
{
   {
      bool_t aux_2287;
      aux_2287 = sfun__199_ast_var(obj_1603);
      return BBOOL(aux_2287);
   }
}


/* make-sfun */ sfun_t 
make_sfun_19_ast_var(long arity_79, obj_t side_effect__165_80, obj_t predicate_of_78_81, obj_t stack_allocator_172_82, bool_t top__138_83, obj_t the_closure_238_84, obj_t property_85, obj_t args_86, obj_t body_87, obj_t class_88, obj_t dsssl_keywords_243_89, obj_t loc_90)
{
   {
      sfun_t new1280_919;
      new1280_919 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
      {
	 long arg1565_920;
	 arg1565_920 = class_num_218___object(sfun_ast_var);
	 {
	    obj_t obj_933;
	    obj_933 = (obj_t) (new1280_919);
	    (((obj_t) CREF(obj_933))->header = MAKE_HEADER(arg1565_920, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2294;
	 aux_2294 = (object_t) (new1280_919);
	 OBJECT_WIDENING_SET(aux_2294, BFALSE);
      }
      ((((sfun_t) CREF(new1280_919))->arity) = ((long) arity_79), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->side_effect__165) = ((obj_t) side_effect__165_80), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->predicate_of_78) = ((obj_t) predicate_of_78_81), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->stack_allocator_172) = ((obj_t) stack_allocator_172_82), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->top__138) = ((bool_t) top__138_83), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->the_closure_238) = ((obj_t) the_closure_238_84), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->property) = ((obj_t) property_85), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->args) = ((obj_t) args_86), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->body) = ((obj_t) body_87), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->class) = ((obj_t) class_88), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->dsssl_keywords_243) = ((obj_t) dsssl_keywords_243_89), BUNSPEC);
      ((((sfun_t) CREF(new1280_919))->loc) = ((obj_t) loc_90), BUNSPEC);
      return new1280_919;
   }
}


/* _make-sfun1846 */ obj_t 
_make_sfun1846_247_ast_var(obj_t env_1604, obj_t arity_1605, obj_t side_effect__165_1606, obj_t predicate_of_78_1607, obj_t stack_allocator_172_1608, obj_t top__138_1609, obj_t the_closure_238_1610, obj_t property_1611, obj_t args_1612, obj_t body_1613, obj_t class_1614, obj_t dsssl_keywords_243_1615, obj_t loc_1616)
{
   {
      sfun_t aux_2309;
      aux_2309 = make_sfun_19_ast_var((long) CINT(arity_1605), side_effect__165_1606, predicate_of_78_1607, stack_allocator_172_1608, CBOOL(top__138_1609), the_closure_238_1610, property_1611, args_1612, body_1613, class_1614, dsssl_keywords_243_1615, loc_1616);
      return (obj_t) (aux_2309);
   }
}


/* sfun-arity */ long 
sfun_arity_53_ast_var(sfun_t obj_91)
{
   return (((sfun_t) CREF(obj_91))->arity);
}


/* _sfun-arity1847 */ obj_t 
_sfun_arity1847_91_ast_var(obj_t env_1617, obj_t obj_1618)
{
   {
      long aux_2315;
      aux_2315 = sfun_arity_53_ast_var((sfun_t) (obj_1618));
      return BINT(aux_2315);
   }
}


/* sfun-side-effect?-set! */ obj_t 
sfun_side_effect__set__97_ast_var(sfun_t obj_92, obj_t val1294_93)
{
   return ((((sfun_t) CREF(obj_92))->side_effect__165) = ((obj_t) val1294_93), BUNSPEC);
}


/* _sfun-side-effect?-set!1848 */ obj_t 
_sfun_side_effect__set_1848_147_ast_var(obj_t env_1619, obj_t obj_1620, obj_t val1294_1621)
{
   return sfun_side_effect__set__97_ast_var((sfun_t) (obj_1620), val1294_1621);
}


/* sfun-side-effect? */ obj_t 
sfun_side_effect__85_ast_var(sfun_t obj_94)
{
   return (((sfun_t) CREF(obj_94))->side_effect__165);
}


/* _sfun-side-effect?1849 */ obj_t 
_sfun_side_effect_1849_38_ast_var(obj_t env_1622, obj_t obj_1623)
{
   return sfun_side_effect__85_ast_var((sfun_t) (obj_1623));
}


/* sfun-predicate-of-set! */ obj_t 
sfun_predicate_of_set__36_ast_var(sfun_t obj_95, obj_t val1295_96)
{
   return ((((sfun_t) CREF(obj_95))->predicate_of_78) = ((obj_t) val1295_96), BUNSPEC);
}


/* _sfun-predicate-of-set!1850 */ obj_t 
_sfun_predicate_of_set_1850_4_ast_var(obj_t env_1624, obj_t obj_1625, obj_t val1295_1626)
{
   return sfun_predicate_of_set__36_ast_var((sfun_t) (obj_1625), val1295_1626);
}


/* sfun-predicate-of */ obj_t 
sfun_predicate_of_63_ast_var(sfun_t obj_97)
{
   return (((sfun_t) CREF(obj_97))->predicate_of_78);
}


/* _sfun-predicate-of1851 */ obj_t 
_sfun_predicate_of1851_65_ast_var(obj_t env_1627, obj_t obj_1628)
{
   return sfun_predicate_of_63_ast_var((sfun_t) (obj_1628));
}


/* sfun-stack-allocator-set! */ obj_t 
sfun_stack_allocator_set__142_ast_var(sfun_t obj_98, obj_t val1296_99)
{
   return ((((sfun_t) CREF(obj_98))->stack_allocator_172) = ((obj_t) val1296_99), BUNSPEC);
}


/* _sfun-stack-allocator-set!1852 */ obj_t 
_sfun_stack_allocator_set_1852_160_ast_var(obj_t env_1629, obj_t obj_1630, obj_t val1296_1631)
{
   return sfun_stack_allocator_set__142_ast_var((sfun_t) (obj_1630), val1296_1631);
}


/* sfun-stack-allocator */ obj_t 
sfun_stack_allocator_39_ast_var(sfun_t obj_100)
{
   return (((sfun_t) CREF(obj_100))->stack_allocator_172);
}


/* _sfun-stack-allocator1853 */ obj_t 
_sfun_stack_allocator1853_71_ast_var(obj_t env_1632, obj_t obj_1633)
{
   return sfun_stack_allocator_39_ast_var((sfun_t) (obj_1633));
}


/* sfun-top?-set! */ obj_t 
sfun_top__set__255_ast_var(sfun_t obj_101, bool_t val1297_102)
{
   return ((((sfun_t) CREF(obj_101))->top__138) = ((bool_t) val1297_102), BUNSPEC);
}


/* _sfun-top?-set!1854 */ obj_t 
_sfun_top__set_1854_44_ast_var(obj_t env_1634, obj_t obj_1635, obj_t val1297_1636)
{
   return sfun_top__set__255_ast_var((sfun_t) (obj_1635), CBOOL(val1297_1636));
}


/* sfun-top? */ bool_t 
sfun_top__45_ast_var(sfun_t obj_103)
{
   return (((sfun_t) CREF(obj_103))->top__138);
}


/* _sfun-top?1855 */ obj_t 
_sfun_top_1855_92_ast_var(obj_t env_1637, obj_t obj_1638)
{
   {
      bool_t aux_2342;
      aux_2342 = sfun_top__45_ast_var((sfun_t) (obj_1638));
      return BBOOL(aux_2342);
   }
}


/* sfun-the-closure-set! */ obj_t 
sfun_the_closure_set__227_ast_var(sfun_t obj_104, obj_t val1298_105)
{
   return ((((sfun_t) CREF(obj_104))->the_closure_238) = ((obj_t) val1298_105), BUNSPEC);
}


/* _sfun-the-closure-set!1856 */ obj_t 
_sfun_the_closure_set_1856_212_ast_var(obj_t env_1639, obj_t obj_1640, obj_t val1298_1641)
{
   return sfun_the_closure_set__227_ast_var((sfun_t) (obj_1640), val1298_1641);
}


/* sfun-the-closure */ obj_t 
sfun_the_closure_253_ast_var(sfun_t obj_106)
{
   return (((sfun_t) CREF(obj_106))->the_closure_238);
}


/* _sfun-the-closure1857 */ obj_t 
_sfun_the_closure1857_195_ast_var(obj_t env_1642, obj_t obj_1643)
{
   return sfun_the_closure_253_ast_var((sfun_t) (obj_1643));
}


/* sfun-property-set! */ obj_t 
sfun_property_set__95_ast_var(sfun_t obj_107, obj_t val1299_108)
{
   return ((((sfun_t) CREF(obj_107))->property) = ((obj_t) val1299_108), BUNSPEC);
}


/* _sfun-property-set!1858 */ obj_t 
_sfun_property_set_1858_127_ast_var(obj_t env_1644, obj_t obj_1645, obj_t val1299_1646)
{
   return sfun_property_set__95_ast_var((sfun_t) (obj_1645), val1299_1646);
}


/* sfun-property */ obj_t 
sfun_property_40_ast_var(sfun_t obj_109)
{
   return (((sfun_t) CREF(obj_109))->property);
}


/* _sfun-property1859 */ obj_t 
_sfun_property1859_159_ast_var(obj_t env_1647, obj_t obj_1648)
{
   return sfun_property_40_ast_var((sfun_t) (obj_1648));
}


/* sfun-args-set! */ obj_t 
sfun_args_set__132_ast_var(sfun_t obj_110, obj_t val1300_111)
{
   return ((((sfun_t) CREF(obj_110))->args) = ((obj_t) val1300_111), BUNSPEC);
}


/* _sfun-args-set!1860 */ obj_t 
_sfun_args_set_1860_227_ast_var(obj_t env_1649, obj_t obj_1650, obj_t val1300_1651)
{
   return sfun_args_set__132_ast_var((sfun_t) (obj_1650), val1300_1651);
}


/* sfun-args */ obj_t 
sfun_args_174_ast_var(sfun_t obj_112)
{
   return (((sfun_t) CREF(obj_112))->args);
}


/* _sfun-args1861 */ obj_t 
_sfun_args1861_246_ast_var(obj_t env_1652, obj_t obj_1653)
{
   return sfun_args_174_ast_var((sfun_t) (obj_1653));
}


/* sfun-body-set! */ obj_t 
sfun_body_set__45_ast_var(sfun_t obj_113, obj_t val1301_114)
{
   return ((((sfun_t) CREF(obj_113))->body) = ((obj_t) val1301_114), BUNSPEC);
}


/* _sfun-body-set!1862 */ obj_t 
_sfun_body_set_1862_31_ast_var(obj_t env_1654, obj_t obj_1655, obj_t val1301_1656)
{
   return sfun_body_set__45_ast_var((sfun_t) (obj_1655), val1301_1656);
}


/* sfun-body */ obj_t 
sfun_body_150_ast_var(sfun_t obj_115)
{
   return (((sfun_t) CREF(obj_115))->body);
}


/* _sfun-body1863 */ obj_t 
_sfun_body1863_190_ast_var(obj_t env_1657, obj_t obj_1658)
{
   return sfun_body_150_ast_var((sfun_t) (obj_1658));
}


/* sfun-class-set! */ obj_t 
sfun_class_set__158_ast_var(sfun_t obj_116, obj_t val1302_117)
{
   return ((((sfun_t) CREF(obj_116))->class) = ((obj_t) val1302_117), BUNSPEC);
}


/* _sfun-class-set!1864 */ obj_t 
_sfun_class_set_1864_162_ast_var(obj_t env_1659, obj_t obj_1660, obj_t val1302_1661)
{
   return sfun_class_set__158_ast_var((sfun_t) (obj_1660), val1302_1661);
}


/* sfun-class */ obj_t 
sfun_class_145_ast_var(sfun_t obj_118)
{
   return (((sfun_t) CREF(obj_118))->class);
}


/* _sfun-class1865 */ obj_t 
_sfun_class1865_218_ast_var(obj_t env_1662, obj_t obj_1663)
{
   return sfun_class_145_ast_var((sfun_t) (obj_1663));
}


/* sfun-dsssl-keywords-set! */ obj_t 
sfun_dsssl_keywords_set__95_ast_var(sfun_t obj_119, obj_t val1303_120)
{
   return ((((sfun_t) CREF(obj_119))->dsssl_keywords_243) = ((obj_t) val1303_120), BUNSPEC);
}


/* _sfun-dsssl-keywords-set!1866 */ obj_t 
_sfun_dsssl_keywords_set_1866_218_ast_var(obj_t env_1664, obj_t obj_1665, obj_t val1303_1666)
{
   return sfun_dsssl_keywords_set__95_ast_var((sfun_t) (obj_1665), val1303_1666);
}


/* sfun-dsssl-keywords */ obj_t 
sfun_dsssl_keywords_40_ast_var(sfun_t obj_121)
{
   return (((sfun_t) CREF(obj_121))->dsssl_keywords_243);
}


/* _sfun-dsssl-keywords1867 */ obj_t 
_sfun_dsssl_keywords1867_41_ast_var(obj_t env_1667, obj_t obj_1668)
{
   return sfun_dsssl_keywords_40_ast_var((sfun_t) (obj_1668));
}


/* sfun-loc-set! */ obj_t 
sfun_loc_set__51_ast_var(sfun_t obj_122, obj_t val1304_123)
{
   return ((((sfun_t) CREF(obj_122))->loc) = ((obj_t) val1304_123), BUNSPEC);
}


/* _sfun-loc-set!1868 */ obj_t 
_sfun_loc_set_1868_144_ast_var(obj_t env_1669, obj_t obj_1670, obj_t val1304_1671)
{
   return sfun_loc_set__51_ast_var((sfun_t) (obj_1670), val1304_1671);
}


/* sfun-loc */ obj_t 
sfun_loc_13_ast_var(sfun_t obj_124)
{
   return (((sfun_t) CREF(obj_124))->loc);
}


/* _sfun-loc1869 */ obj_t 
_sfun_loc1869_33_ast_var(obj_t env_1672, obj_t obj_1673)
{
   return sfun_loc_13_ast_var((sfun_t) (obj_1673));
}


/* allocate-fun */ fun_t 
allocate_fun_149_ast_var()
{
   {
      fun_t new1253_430;
      new1253_430 = ((fun_t) BREF(GC_MALLOC(sizeof(struct fun))));
      {
	 long arg1566_431;
	 arg1566_431 = class_num_218___object(fun_ast_var);
	 {
	    obj_t obj_935;
	    obj_935 = (obj_t) (new1253_430);
	    (((obj_t) CREF(obj_935))->header = MAKE_HEADER(arg1566_431, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2392;
	 aux_2392 = (object_t) (new1253_430);
	 OBJECT_WIDENING_SET(aux_2392, BFALSE);
      }
      return new1253_430;
   }
}


/* _allocate-fun */ obj_t 
_allocate_fun_230_ast_var(obj_t env_1499)
{
   {
      fun_t aux_2395;
      aux_2395 = allocate_fun_149_ast_var();
      return (obj_t) (aux_2395);
   }
}


/* fun? */ bool_t 
fun__147_ast_var(obj_t obj_128)
{
   return is_a__118___object(obj_128, fun_ast_var);
}


/* _fun? */ obj_t 
_fun__116_ast_var(obj_t env_1674, obj_t obj_1675)
{
   {
      bool_t aux_2399;
      aux_2399 = fun__147_ast_var(obj_1675);
      return BBOOL(aux_2399);
   }
}


/* make-fun */ fun_t 
make_fun_37_ast_var(long arity_129, obj_t side_effect__165_130, obj_t predicate_of_78_131, obj_t stack_allocator_172_132, bool_t top__138_133, obj_t the_closure_238_134)
{
   {
      fun_t new1240_937;
      new1240_937 = ((fun_t) BREF(GC_MALLOC(sizeof(struct fun))));
      {
	 long arg1568_938;
	 arg1568_938 = class_num_218___object(fun_ast_var);
	 {
	    obj_t obj_945;
	    obj_945 = (obj_t) (new1240_937);
	    (((obj_t) CREF(obj_945))->header = MAKE_HEADER(arg1568_938, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2406;
	 aux_2406 = (object_t) (new1240_937);
	 OBJECT_WIDENING_SET(aux_2406, BFALSE);
      }
      ((((fun_t) CREF(new1240_937))->arity) = ((long) arity_129), BUNSPEC);
      ((((fun_t) CREF(new1240_937))->side_effect__165) = ((obj_t) side_effect__165_130), BUNSPEC);
      ((((fun_t) CREF(new1240_937))->predicate_of_78) = ((obj_t) predicate_of_78_131), BUNSPEC);
      ((((fun_t) CREF(new1240_937))->stack_allocator_172) = ((obj_t) stack_allocator_172_132), BUNSPEC);
      ((((fun_t) CREF(new1240_937))->top__138) = ((bool_t) top__138_133), BUNSPEC);
      ((((fun_t) CREF(new1240_937))->the_closure_238) = ((obj_t) the_closure_238_134), BUNSPEC);
      return new1240_937;
   }
}


/* _make-fun1870 */ obj_t 
_make_fun1870_204_ast_var(obj_t env_1676, obj_t arity_1677, obj_t side_effect__165_1678, obj_t predicate_of_78_1679, obj_t stack_allocator_172_1680, obj_t top__138_1681, obj_t the_closure_238_1682)
{
   {
      fun_t aux_2415;
      aux_2415 = make_fun_37_ast_var((long) CINT(arity_1677), side_effect__165_1678, predicate_of_78_1679, stack_allocator_172_1680, CBOOL(top__138_1681), the_closure_238_1682);
      return (obj_t) (aux_2415);
   }
}


/* fun-arity */ long 
fun_arity_132_ast_var(fun_t obj_135)
{
   return (((fun_t) CREF(obj_135))->arity);
}


/* _fun-arity1871 */ obj_t 
_fun_arity1871_184_ast_var(obj_t env_1683, obj_t obj_1684)
{
   {
      long aux_2421;
      aux_2421 = fun_arity_132_ast_var((fun_t) (obj_1684));
      return BINT(aux_2421);
   }
}


/* fun-side-effect?-set! */ obj_t 
fun_side_effect__set__185_ast_var(fun_t obj_136, obj_t val1248_137)
{
   return ((((fun_t) CREF(obj_136))->side_effect__165) = ((obj_t) val1248_137), BUNSPEC);
}


/* _fun-side-effect?-set!1872 */ obj_t 
_fun_side_effect__set_1872_254_ast_var(obj_t env_1685, obj_t obj_1686, obj_t val1248_1687)
{
   return fun_side_effect__set__185_ast_var((fun_t) (obj_1686), val1248_1687);
}


/* fun-side-effect? */ obj_t 
fun_side_effect__244_ast_var(fun_t obj_138)
{
   return (((fun_t) CREF(obj_138))->side_effect__165);
}


/* _fun-side-effect?1873 */ obj_t 
_fun_side_effect_1873_86_ast_var(obj_t env_1688, obj_t obj_1689)
{
   return fun_side_effect__244_ast_var((fun_t) (obj_1689));
}


/* fun-predicate-of-set! */ obj_t 
fun_predicate_of_set__163_ast_var(fun_t obj_139, obj_t val1249_140)
{
   return ((((fun_t) CREF(obj_139))->predicate_of_78) = ((obj_t) val1249_140), BUNSPEC);
}


/* _fun-predicate-of-set!1874 */ obj_t 
_fun_predicate_of_set_1874_48_ast_var(obj_t env_1690, obj_t obj_1691, obj_t val1249_1692)
{
   return fun_predicate_of_set__163_ast_var((fun_t) (obj_1691), val1249_1692);
}


/* fun-predicate-of */ obj_t 
fun_predicate_of_193_ast_var(fun_t obj_141)
{
   return (((fun_t) CREF(obj_141))->predicate_of_78);
}


/* _fun-predicate-of1875 */ obj_t 
_fun_predicate_of1875_19_ast_var(obj_t env_1693, obj_t obj_1694)
{
   return fun_predicate_of_193_ast_var((fun_t) (obj_1694));
}


/* fun-stack-allocator-set! */ obj_t 
fun_stack_allocator_set__246_ast_var(fun_t obj_142, obj_t val1250_143)
{
   return ((((fun_t) CREF(obj_142))->stack_allocator_172) = ((obj_t) val1250_143), BUNSPEC);
}


/* _fun-stack-allocator-set!1876 */ obj_t 
_fun_stack_allocator_set_1876_28_ast_var(obj_t env_1695, obj_t obj_1696, obj_t val1250_1697)
{
   return fun_stack_allocator_set__246_ast_var((fun_t) (obj_1696), val1250_1697);
}


/* fun-stack-allocator */ obj_t 
fun_stack_allocator_124_ast_var(fun_t obj_144)
{
   return (((fun_t) CREF(obj_144))->stack_allocator_172);
}


/* _fun-stack-allocator1877 */ obj_t 
_fun_stack_allocator1877_93_ast_var(obj_t env_1698, obj_t obj_1699)
{
   return fun_stack_allocator_124_ast_var((fun_t) (obj_1699));
}


/* fun-top?-set! */ obj_t 
fun_top__set__55_ast_var(fun_t obj_145, bool_t val1251_146)
{
   return ((((fun_t) CREF(obj_145))->top__138) = ((bool_t) val1251_146), BUNSPEC);
}


/* _fun-top?-set!1878 */ obj_t 
_fun_top__set_1878_45_ast_var(obj_t env_1700, obj_t obj_1701, obj_t val1251_1702)
{
   return fun_top__set__55_ast_var((fun_t) (obj_1701), CBOOL(val1251_1702));
}


/* fun-top? */ bool_t 
fun_top__228_ast_var(fun_t obj_147)
{
   return (((fun_t) CREF(obj_147))->top__138);
}


/* _fun-top?1879 */ obj_t 
_fun_top_1879_211_ast_var(obj_t env_1703, obj_t obj_1704)
{
   {
      bool_t aux_2448;
      aux_2448 = fun_top__228_ast_var((fun_t) (obj_1704));
      return BBOOL(aux_2448);
   }
}


/* fun-the-closure-set! */ obj_t 
fun_the_closure_set__119_ast_var(fun_t obj_148, obj_t val1252_149)
{
   return ((((fun_t) CREF(obj_148))->the_closure_238) = ((obj_t) val1252_149), BUNSPEC);
}


/* _fun-the-closure-set!1880 */ obj_t 
_fun_the_closure_set_1880_102_ast_var(obj_t env_1705, obj_t obj_1706, obj_t val1252_1707)
{
   return fun_the_closure_set__119_ast_var((fun_t) (obj_1706), val1252_1707);
}


/* fun-the-closure */ obj_t 
fun_the_closure_217_ast_var(fun_t obj_150)
{
   return (((fun_t) CREF(obj_150))->the_closure_238);
}


/* _fun-the-closure1881 */ obj_t 
_fun_the_closure1881_113_ast_var(obj_t env_1708, obj_t obj_1709)
{
   return fun_the_closure_217_ast_var((fun_t) (obj_1709));
}


/* allocate-local */ local_t 
allocate_local_177_ast_var()
{
   {
      local_t new1197_440;
      new1197_440 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1569_441;
	 arg1569_441 = class_num_218___object(local_ast_var);
	 {
	    obj_t obj_947;
	    obj_947 = (obj_t) (new1197_440);
	    (((obj_t) CREF(obj_947))->header = MAKE_HEADER(arg1569_441, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2462;
	 aux_2462 = (object_t) (new1197_440);
	 OBJECT_WIDENING_SET(aux_2462, BFALSE);
      }
      return new1197_440;
   }
}


/* _allocate-local */ obj_t 
_allocate_local_35_ast_var(obj_t env_1498)
{
   {
      local_t aux_2465;
      aux_2465 = allocate_local_177_ast_var();
      return (obj_t) (aux_2465);
   }
}


/* local? */ bool_t 
local__163_ast_var(obj_t obj_154)
{
   return is_a__118___object(obj_154, local_ast_var);
}


/* _local? */ obj_t 
_local__113_ast_var(obj_t env_1710, obj_t obj_1711)
{
   {
      bool_t aux_2469;
      aux_2469 = local__163_ast_var(obj_1711);
      return BBOOL(aux_2469);
   }
}


/* make-local */ local_t 
make_local_130_ast_var(obj_t id_155, obj_t name_156, type_t type_157, value_t value_158, obj_t access_159, obj_t fast_alpha_7_160, obj_t removable_161, long occurrence_162, bool_t user__32_163, long key_164)
{
   {
      local_t new1177_949;
      new1177_949 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1570_950;
	 arg1570_950 = class_num_218___object(local_ast_var);
	 {
	    obj_t obj_961;
	    obj_961 = (obj_t) (new1177_949);
	    (((obj_t) CREF(obj_961))->header = MAKE_HEADER(arg1570_950, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2476;
	 aux_2476 = (object_t) (new1177_949);
	 OBJECT_WIDENING_SET(aux_2476, BFALSE);
      }
      ((((local_t) CREF(new1177_949))->id) = ((obj_t) id_155), BUNSPEC);
      ((((local_t) CREF(new1177_949))->name) = ((obj_t) name_156), BUNSPEC);
      ((((local_t) CREF(new1177_949))->type) = ((type_t) type_157), BUNSPEC);
      ((((local_t) CREF(new1177_949))->value) = ((value_t) value_158), BUNSPEC);
      ((((local_t) CREF(new1177_949))->access) = ((obj_t) access_159), BUNSPEC);
      ((((local_t) CREF(new1177_949))->fast_alpha_7) = ((obj_t) fast_alpha_7_160), BUNSPEC);
      ((((local_t) CREF(new1177_949))->removable) = ((obj_t) removable_161), BUNSPEC);
      ((((local_t) CREF(new1177_949))->occurrence) = ((long) occurrence_162), BUNSPEC);
      ((((local_t) CREF(new1177_949))->user__32) = ((bool_t) user__32_163), BUNSPEC);
      ((((local_t) CREF(new1177_949))->key) = ((long) key_164), BUNSPEC);
      return new1177_949;
   }
}


/* _make-local1882 */ obj_t 
_make_local1882_116_ast_var(obj_t env_1712, obj_t id_1713, obj_t name_1714, obj_t type_1715, obj_t value_1716, obj_t access_1717, obj_t fast_alpha_7_1718, obj_t removable_1719, obj_t occurrence_1720, obj_t user__32_1721, obj_t key_1722)
{
   {
      local_t aux_2489;
      aux_2489 = make_local_130_ast_var(id_1713, name_1714, (type_t) (type_1715), (value_t) (value_1716), access_1717, fast_alpha_7_1718, removable_1719, (long) CINT(occurrence_1720), CBOOL(user__32_1721), (long) CINT(key_1722));
      return (obj_t) (aux_2489);
   }
}


/* local-id */ obj_t 
local_id_1_ast_var(local_t obj_165)
{
   return (((local_t) CREF(obj_165))->id);
}


/* _local-id1883 */ obj_t 
_local_id1883_127_ast_var(obj_t env_1723, obj_t obj_1724)
{
   return local_id_1_ast_var((local_t) (obj_1724));
}


/* local-name-set! */ obj_t 
local_name_set__155_ast_var(local_t obj_166, obj_t val1189_167)
{
   return ((((local_t) CREF(obj_166))->name) = ((obj_t) val1189_167), BUNSPEC);
}


/* _local-name-set!1884 */ obj_t 
_local_name_set_1884_228_ast_var(obj_t env_1725, obj_t obj_1726, obj_t val1189_1727)
{
   return local_name_set__155_ast_var((local_t) (obj_1726), val1189_1727);
}


/* local-name */ obj_t 
local_name_136_ast_var(local_t obj_168)
{
   return (((local_t) CREF(obj_168))->name);
}


/* _local-name1885 */ obj_t 
_local_name1885_77_ast_var(obj_t env_1728, obj_t obj_1729)
{
   return local_name_136_ast_var((local_t) (obj_1729));
}


/* local-type-set! */ obj_t 
local_type_set__101_ast_var(local_t obj_169, type_t val1190_170)
{
   return ((((local_t) CREF(obj_169))->type) = ((type_t) val1190_170), BUNSPEC);
}


/* _local-type-set!1886 */ obj_t 
_local_type_set_1886_229_ast_var(obj_t env_1730, obj_t obj_1731, obj_t val1190_1732)
{
   return local_type_set__101_ast_var((local_t) (obj_1731), (type_t) (val1190_1732));
}


/* local-type */ type_t 
local_type_242_ast_var(local_t obj_171)
{
   return (((local_t) CREF(obj_171))->type);
}


/* _local-type1887 */ obj_t 
_local_type1887_8_ast_var(obj_t env_1733, obj_t obj_1734)
{
   {
      type_t aux_2511;
      aux_2511 = local_type_242_ast_var((local_t) (obj_1734));
      return (obj_t) (aux_2511);
   }
}


/* local-value-set! */ obj_t 
local_value_set__243_ast_var(local_t obj_172, value_t val1191_173)
{
   return ((((local_t) CREF(obj_172))->value) = ((value_t) val1191_173), BUNSPEC);
}


/* _local-value-set!1888 */ obj_t 
_local_value_set_1888_45_ast_var(obj_t env_1735, obj_t obj_1736, obj_t val1191_1737)
{
   return local_value_set__243_ast_var((local_t) (obj_1736), (value_t) (val1191_1737));
}


/* local-value */ value_t 
local_value_65_ast_var(local_t obj_174)
{
   return (((local_t) CREF(obj_174))->value);
}


/* _local-value1889 */ obj_t 
_local_value1889_74_ast_var(obj_t env_1738, obj_t obj_1739)
{
   {
      value_t aux_2520;
      aux_2520 = local_value_65_ast_var((local_t) (obj_1739));
      return (obj_t) (aux_2520);
   }
}


/* local-access-set! */ obj_t 
local_access_set__100_ast_var(local_t obj_175, obj_t val1192_176)
{
   return ((((local_t) CREF(obj_175))->access) = ((obj_t) val1192_176), BUNSPEC);
}


/* _local-access-set!1890 */ obj_t 
_local_access_set_1890_135_ast_var(obj_t env_1740, obj_t obj_1741, obj_t val1192_1742)
{
   return local_access_set__100_ast_var((local_t) (obj_1741), val1192_1742);
}


/* local-access */ obj_t 
local_access_176_ast_var(local_t obj_177)
{
   return (((local_t) CREF(obj_177))->access);
}


/* _local-access1891 */ obj_t 
_local_access1891_206_ast_var(obj_t env_1743, obj_t obj_1744)
{
   return local_access_176_ast_var((local_t) (obj_1744));
}


/* local-fast-alpha-set! */ obj_t 
local_fast_alpha_set__243_ast_var(local_t obj_178, obj_t val1193_179)
{
   return ((((local_t) CREF(obj_178))->fast_alpha_7) = ((obj_t) val1193_179), BUNSPEC);
}


/* _local-fast-alpha-set!1892 */ obj_t 
_local_fast_alpha_set_1892_179_ast_var(obj_t env_1745, obj_t obj_1746, obj_t val1193_1747)
{
   return local_fast_alpha_set__243_ast_var((local_t) (obj_1746), val1193_1747);
}


/* local-fast-alpha */ obj_t 
local_fast_alpha_65_ast_var(local_t obj_180)
{
   return (((local_t) CREF(obj_180))->fast_alpha_7);
}


/* _local-fast-alpha1893 */ obj_t 
_local_fast_alpha1893_30_ast_var(obj_t env_1748, obj_t obj_1749)
{
   return local_fast_alpha_65_ast_var((local_t) (obj_1749));
}


/* local-removable-set! */ obj_t 
local_removable_set__151_ast_var(local_t obj_181, obj_t val1194_182)
{
   return ((((local_t) CREF(obj_181))->removable) = ((obj_t) val1194_182), BUNSPEC);
}


/* _local-removable-set!1894 */ obj_t 
_local_removable_set_1894_80_ast_var(obj_t env_1750, obj_t obj_1751, obj_t val1194_1752)
{
   return local_removable_set__151_ast_var((local_t) (obj_1751), val1194_1752);
}


/* local-removable */ obj_t 
local_removable_34_ast_var(local_t obj_183)
{
   return (((local_t) CREF(obj_183))->removable);
}


/* _local-removable1895 */ obj_t 
_local_removable1895_184_ast_var(obj_t env_1753, obj_t obj_1754)
{
   return local_removable_34_ast_var((local_t) (obj_1754));
}


/* local-occurrence-set! */ obj_t 
local_occurrence_set__128_ast_var(local_t obj_184, long val1195_185)
{
   return ((((local_t) CREF(obj_184))->occurrence) = ((long) val1195_185), BUNSPEC);
}


/* _local-occurrence-set!1896 */ obj_t 
_local_occurrence_set_1896_125_ast_var(obj_t env_1755, obj_t obj_1756, obj_t val1195_1757)
{
   return local_occurrence_set__128_ast_var((local_t) (obj_1756), (long) CINT(val1195_1757));
}


/* local-occurrence */ long 
local_occurrence_5_ast_var(local_t obj_186)
{
   return (((local_t) CREF(obj_186))->occurrence);
}


/* _local-occurrence1897 */ obj_t 
_local_occurrence1897_134_ast_var(obj_t env_1758, obj_t obj_1759)
{
   {
      long aux_2547;
      aux_2547 = local_occurrence_5_ast_var((local_t) (obj_1759));
      return BINT(aux_2547);
   }
}


/* local-user?-set! */ obj_t 
local_user__set__89_ast_var(local_t obj_187, bool_t val1196_188)
{
   return ((((local_t) CREF(obj_187))->user__32) = ((bool_t) val1196_188), BUNSPEC);
}


/* _local-user?-set!1898 */ obj_t 
_local_user__set_1898_41_ast_var(obj_t env_1760, obj_t obj_1761, obj_t val1196_1762)
{
   return local_user__set__89_ast_var((local_t) (obj_1761), CBOOL(val1196_1762));
}


/* local-user? */ bool_t 
local_user__147_ast_var(local_t obj_189)
{
   return (((local_t) CREF(obj_189))->user__32);
}


/* _local-user?1899 */ obj_t 
_local_user_1899_231_ast_var(obj_t env_1763, obj_t obj_1764)
{
   {
      bool_t aux_2556;
      aux_2556 = local_user__147_ast_var((local_t) (obj_1764));
      return BBOOL(aux_2556);
   }
}


/* local-key */ long 
local_key_6_ast_var(local_t obj_190)
{
   return (((local_t) CREF(obj_190))->key);
}


/* _local-key1900 */ obj_t 
_local_key1900_156_ast_var(obj_t env_1765, obj_t obj_1766)
{
   {
      long aux_2561;
      aux_2561 = local_key_6_ast_var((local_t) (obj_1766));
      return BINT(aux_2561);
   }
}


/* allocate-global */ global_t 
allocate_global_222_ast_var()
{
   {
      global_t new1114_454;
      new1114_454 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
      {
	 long arg1572_455;
	 arg1572_455 = class_num_218___object(global_ast_var);
	 {
	    obj_t obj_963;
	    obj_963 = (obj_t) (new1114_454);
	    (((obj_t) CREF(obj_963))->header = MAKE_HEADER(arg1572_455, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2569;
	 aux_2569 = (object_t) (new1114_454);
	 OBJECT_WIDENING_SET(aux_2569, BFALSE);
      }
      return new1114_454;
   }
}


/* _allocate-global */ obj_t 
_allocate_global_232_ast_var(obj_t env_1497)
{
   {
      global_t aux_2572;
      aux_2572 = allocate_global_222_ast_var();
      return (obj_t) (aux_2572);
   }
}


/* global? */ bool_t 
global__63_ast_var(obj_t obj_194)
{
   return is_a__118___object(obj_194, global_ast_var);
}


/* _global? */ obj_t 
_global__76_ast_var(obj_t env_1767, obj_t obj_1768)
{
   {
      bool_t aux_2576;
      aux_2576 = global__63_ast_var(obj_1768);
      return BBOOL(aux_2576);
   }
}


/* make-global */ global_t 
make_global_89_ast_var(obj_t id_195, obj_t name_196, type_t type_197, value_t value_198, obj_t access_199, obj_t fast_alpha_7_200, obj_t removable_201, long occurrence_202, obj_t module_203, obj_t import_204, bool_t evaluable__248_205, bool_t library__255_206, bool_t user__32_207, obj_t pragma_208, obj_t src_209)
{
   {
      global_t new1085_965;
      new1085_965 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
      {
	 long arg1573_966;
	 arg1573_966 = class_num_218___object(global_ast_var);
	 {
	    obj_t obj_982;
	    obj_982 = (obj_t) (new1085_965);
	    (((obj_t) CREF(obj_982))->header = MAKE_HEADER(arg1573_966, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2583;
	 aux_2583 = (object_t) (new1085_965);
	 OBJECT_WIDENING_SET(aux_2583, BFALSE);
      }
      ((((global_t) CREF(new1085_965))->id) = ((obj_t) id_195), BUNSPEC);
      ((((global_t) CREF(new1085_965))->name) = ((obj_t) name_196), BUNSPEC);
      ((((global_t) CREF(new1085_965))->type) = ((type_t) type_197), BUNSPEC);
      ((((global_t) CREF(new1085_965))->value) = ((value_t) value_198), BUNSPEC);
      ((((global_t) CREF(new1085_965))->access) = ((obj_t) access_199), BUNSPEC);
      ((((global_t) CREF(new1085_965))->fast_alpha_7) = ((obj_t) fast_alpha_7_200), BUNSPEC);
      ((((global_t) CREF(new1085_965))->removable) = ((obj_t) removable_201), BUNSPEC);
      ((((global_t) CREF(new1085_965))->occurrence) = ((long) occurrence_202), BUNSPEC);
      ((((global_t) CREF(new1085_965))->module) = ((obj_t) module_203), BUNSPEC);
      ((((global_t) CREF(new1085_965))->import) = ((obj_t) import_204), BUNSPEC);
      ((((global_t) CREF(new1085_965))->evaluable__248) = ((bool_t) evaluable__248_205), BUNSPEC);
      ((((global_t) CREF(new1085_965))->library__255) = ((bool_t) library__255_206), BUNSPEC);
      ((((global_t) CREF(new1085_965))->user__32) = ((bool_t) user__32_207), BUNSPEC);
      ((((global_t) CREF(new1085_965))->pragma) = ((obj_t) pragma_208), BUNSPEC);
      ((((global_t) CREF(new1085_965))->src) = ((obj_t) src_209), BUNSPEC);
      return new1085_965;
   }
}


/* _make-global1901 */ obj_t 
_make_global1901_192_ast_var(obj_t env_1769, obj_t id_1770, obj_t name_1771, obj_t type_1772, obj_t value_1773, obj_t access_1774, obj_t fast_alpha_7_1775, obj_t removable_1776, obj_t occurrence_1777, obj_t module_1778, obj_t import_1779, obj_t evaluable__248_1780, obj_t library__255_1781, obj_t user__32_1782, obj_t pragma_1783, obj_t src_1784)
{
   {
      global_t aux_2601;
      aux_2601 = make_global_89_ast_var(id_1770, name_1771, (type_t) (type_1772), (value_t) (value_1773), access_1774, fast_alpha_7_1775, removable_1776, (long) CINT(occurrence_1777), module_1778, import_1779, CBOOL(evaluable__248_1780), CBOOL(library__255_1781), CBOOL(user__32_1782), pragma_1783, src_1784);
      return (obj_t) (aux_2601);
   }
}


/* global-id */ obj_t 
global_id_179_ast_var(global_t obj_210)
{
   return (((global_t) CREF(obj_210))->id);
}


/* _global-id1902 */ obj_t 
_global_id1902_142_ast_var(obj_t env_1785, obj_t obj_1786)
{
   return global_id_179_ast_var((global_t) (obj_1786));
}


/* global-name-set! */ obj_t 
global_name_set__147_ast_var(global_t obj_211, obj_t val1102_212)
{
   return ((((global_t) CREF(obj_211))->name) = ((obj_t) val1102_212), BUNSPEC);
}


/* _global-name-set!1903 */ obj_t 
_global_name_set_1903_31_ast_var(obj_t env_1787, obj_t obj_1788, obj_t val1102_1789)
{
   return global_name_set__147_ast_var((global_t) (obj_1788), val1102_1789);
}


/* global-name */ obj_t 
global_name_141_ast_var(global_t obj_213)
{
   return (((global_t) CREF(obj_213))->name);
}


/* _global-name1904 */ obj_t 
_global_name1904_201_ast_var(obj_t env_1790, obj_t obj_1791)
{
   return global_name_141_ast_var((global_t) (obj_1791));
}


/* global-type-set! */ obj_t 
global_type_set__109_ast_var(global_t obj_214, type_t val1103_215)
{
   return ((((global_t) CREF(obj_214))->type) = ((type_t) val1103_215), BUNSPEC);
}


/* _global-type-set!1905 */ obj_t 
_global_type_set_1905_127_ast_var(obj_t env_1792, obj_t obj_1793, obj_t val1103_1794)
{
   return global_type_set__109_ast_var((global_t) (obj_1793), (type_t) (val1103_1794));
}


/* global-type */ type_t 
global_type_243_ast_var(global_t obj_216)
{
   return (((global_t) CREF(obj_216))->type);
}


/* _global-type1906 */ obj_t 
_global_type1906_73_ast_var(obj_t env_1795, obj_t obj_1796)
{
   {
      type_t aux_2624;
      aux_2624 = global_type_243_ast_var((global_t) (obj_1796));
      return (obj_t) (aux_2624);
   }
}


/* global-value-set! */ obj_t 
global_value_set__118_ast_var(global_t obj_217, value_t val1104_218)
{
   return ((((global_t) CREF(obj_217))->value) = ((value_t) val1104_218), BUNSPEC);
}


/* _global-value-set!1907 */ obj_t 
_global_value_set_1907_238_ast_var(obj_t env_1797, obj_t obj_1798, obj_t val1104_1799)
{
   return global_value_set__118_ast_var((global_t) (obj_1798), (value_t) (val1104_1799));
}


/* global-value */ value_t 
global_value_241_ast_var(global_t obj_219)
{
   return (((global_t) CREF(obj_219))->value);
}


/* _global-value1908 */ obj_t 
_global_value1908_139_ast_var(obj_t env_1800, obj_t obj_1801)
{
   {
      value_t aux_2633;
      aux_2633 = global_value_241_ast_var((global_t) (obj_1801));
      return (obj_t) (aux_2633);
   }
}


/* global-access-set! */ obj_t 
global_access_set__188_ast_var(global_t obj_220, obj_t val1105_221)
{
   return ((((global_t) CREF(obj_220))->access) = ((obj_t) val1105_221), BUNSPEC);
}


/* _global-access-set!1909 */ obj_t 
_global_access_set_1909_136_ast_var(obj_t env_1802, obj_t obj_1803, obj_t val1105_1804)
{
   return global_access_set__188_ast_var((global_t) (obj_1803), val1105_1804);
}


/* global-access */ obj_t 
global_access_222_ast_var(global_t obj_222)
{
   return (((global_t) CREF(obj_222))->access);
}


/* _global-access1910 */ obj_t 
_global_access1910_248_ast_var(obj_t env_1805, obj_t obj_1806)
{
   return global_access_222_ast_var((global_t) (obj_1806));
}


/* global-fast-alpha-set! */ obj_t 
global_fast_alpha_set__101_ast_var(global_t obj_223, obj_t val1106_224)
{
   return ((((global_t) CREF(obj_223))->fast_alpha_7) = ((obj_t) val1106_224), BUNSPEC);
}


/* _global-fast-alpha-set!1911 */ obj_t 
_global_fast_alpha_set_1911_201_ast_var(obj_t env_1807, obj_t obj_1808, obj_t val1106_1809)
{
   return global_fast_alpha_set__101_ast_var((global_t) (obj_1808), val1106_1809);
}


/* global-fast-alpha */ obj_t 
global_fast_alpha_242_ast_var(global_t obj_225)
{
   return (((global_t) CREF(obj_225))->fast_alpha_7);
}


/* _global-fast-alpha1912 */ obj_t 
_global_fast_alpha1912_51_ast_var(obj_t env_1810, obj_t obj_1811)
{
   return global_fast_alpha_242_ast_var((global_t) (obj_1811));
}


/* global-removable-set! */ obj_t 
global_removable_set__21_ast_var(global_t obj_226, obj_t val1107_227)
{
   return ((((global_t) CREF(obj_226))->removable) = ((obj_t) val1107_227), BUNSPEC);
}


/* _global-removable-set!1913 */ obj_t 
_global_removable_set_1913_117_ast_var(obj_t env_1812, obj_t obj_1813, obj_t val1107_1814)
{
   return global_removable_set__21_ast_var((global_t) (obj_1813), val1107_1814);
}


/* global-removable */ obj_t 
global_removable_57_ast_var(global_t obj_228)
{
   return (((global_t) CREF(obj_228))->removable);
}


/* _global-removable1914 */ obj_t 
_global_removable1914_19_ast_var(obj_t env_1815, obj_t obj_1816)
{
   return global_removable_57_ast_var((global_t) (obj_1816));
}


/* global-occurrence-set! */ obj_t 
global_occurrence_set__154_ast_var(global_t obj_229, long val1108_230)
{
   return ((((global_t) CREF(obj_229))->occurrence) = ((long) val1108_230), BUNSPEC);
}


/* _global-occurrence-set!1915 */ obj_t 
_global_occurrence_set_1915_159_ast_var(obj_t env_1817, obj_t obj_1818, obj_t val1108_1819)
{
   return global_occurrence_set__154_ast_var((global_t) (obj_1818), (long) CINT(val1108_1819));
}


/* global-occurrence */ long 
global_occurrence_96_ast_var(global_t obj_231)
{
   return (((global_t) CREF(obj_231))->occurrence);
}


/* _global-occurrence1916 */ obj_t 
_global_occurrence1916_151_ast_var(obj_t env_1820, obj_t obj_1821)
{
   {
      long aux_2660;
      aux_2660 = global_occurrence_96_ast_var((global_t) (obj_1821));
      return BINT(aux_2660);
   }
}


/* global-module */ obj_t 
global_module_203_ast_var(global_t obj_232)
{
   return (((global_t) CREF(obj_232))->module);
}


/* _global-module1917 */ obj_t 
_global_module1917_19_ast_var(obj_t env_1822, obj_t obj_1823)
{
   return global_module_203_ast_var((global_t) (obj_1823));
}


/* global-import-set! */ obj_t 
global_import_set__22_ast_var(global_t obj_233, obj_t val1109_234)
{
   return ((((global_t) CREF(obj_233))->import) = ((obj_t) val1109_234), BUNSPEC);
}


/* _global-import-set!1918 */ obj_t 
_global_import_set_1918_247_ast_var(obj_t env_1824, obj_t obj_1825, obj_t val1109_1826)
{
   return global_import_set__22_ast_var((global_t) (obj_1825), val1109_1826);
}


/* global-import */ obj_t 
global_import_37_ast_var(global_t obj_235)
{
   return (((global_t) CREF(obj_235))->import);
}


/* _global-import1919 */ obj_t 
_global_import1919_10_ast_var(obj_t env_1827, obj_t obj_1828)
{
   return global_import_37_ast_var((global_t) (obj_1828));
}


/* global-evaluable?-set! */ obj_t 
global_evaluable__set__201_ast_var(global_t obj_236, bool_t val1110_237)
{
   return ((((global_t) CREF(obj_236))->evaluable__248) = ((bool_t) val1110_237), BUNSPEC);
}


/* _global-evaluable?-set!1920 */ obj_t 
_global_evaluable__set_1920_157_ast_var(obj_t env_1829, obj_t obj_1830, obj_t val1110_1831)
{
   return global_evaluable__set__201_ast_var((global_t) (obj_1830), CBOOL(val1110_1831));
}


/* global-evaluable? */ bool_t 
global_evaluable__170_ast_var(global_t obj_238)
{
   return (((global_t) CREF(obj_238))->evaluable__248);
}


/* _global-evaluable?1921 */ obj_t 
_global_evaluable_1921_23_ast_var(obj_t env_1832, obj_t obj_1833)
{
   {
      bool_t aux_2678;
      aux_2678 = global_evaluable__170_ast_var((global_t) (obj_1833));
      return BBOOL(aux_2678);
   }
}


/* global-library?-set! */ obj_t 
global_library__set__213_ast_var(global_t obj_239, bool_t val1111_240)
{
   return ((((global_t) CREF(obj_239))->library__255) = ((bool_t) val1111_240), BUNSPEC);
}


/* _global-library?-set!1922 */ obj_t 
_global_library__set_1922_202_ast_var(obj_t env_1834, obj_t obj_1835, obj_t val1111_1836)
{
   return global_library__set__213_ast_var((global_t) (obj_1835), CBOOL(val1111_1836));
}


/* global-library? */ bool_t 
global_library__62_ast_var(global_t obj_241)
{
   return (((global_t) CREF(obj_241))->library__255);
}


/* _global-library?1923 */ obj_t 
_global_library_1923_164_ast_var(obj_t env_1837, obj_t obj_1838)
{
   {
      bool_t aux_2687;
      aux_2687 = global_library__62_ast_var((global_t) (obj_1838));
      return BBOOL(aux_2687);
   }
}


/* global-user?-set! */ obj_t 
global_user__set__116_ast_var(global_t obj_242, bool_t val1112_243)
{
   return ((((global_t) CREF(obj_242))->user__32) = ((bool_t) val1112_243), BUNSPEC);
}


/* _global-user?-set!1924 */ obj_t 
_global_user__set_1924_213_ast_var(obj_t env_1839, obj_t obj_1840, obj_t val1112_1841)
{
   return global_user__set__116_ast_var((global_t) (obj_1840), CBOOL(val1112_1841));
}


/* global-user? */ bool_t 
global_user__208_ast_var(global_t obj_244)
{
   return (((global_t) CREF(obj_244))->user__32);
}


/* _global-user?1925 */ obj_t 
_global_user_1925_58_ast_var(obj_t env_1842, obj_t obj_1843)
{
   {
      bool_t aux_2696;
      aux_2696 = global_user__208_ast_var((global_t) (obj_1843));
      return BBOOL(aux_2696);
   }
}


/* global-pragma */ obj_t 
global_pragma_105_ast_var(global_t obj_245)
{
   return (((global_t) CREF(obj_245))->pragma);
}


/* _global-pragma1926 */ obj_t 
_global_pragma1926_131_ast_var(obj_t env_1844, obj_t obj_1845)
{
   return global_pragma_105_ast_var((global_t) (obj_1845));
}


/* global-src-set! */ obj_t 
global_src_set__223_ast_var(global_t obj_246, obj_t val1113_247)
{
   return ((((global_t) CREF(obj_246))->src) = ((obj_t) val1113_247), BUNSPEC);
}


/* _global-src-set!1927 */ obj_t 
_global_src_set_1927_160_ast_var(obj_t env_1846, obj_t obj_1847, obj_t val1113_1848)
{
   return global_src_set__223_ast_var((global_t) (obj_1847), val1113_1848);
}


/* global-src */ obj_t 
global_src_229_ast_var(global_t obj_248)
{
   return (((global_t) CREF(obj_248))->src);
}


/* _global-src1928 */ obj_t 
_global_src1928_118_ast_var(obj_t env_1849, obj_t obj_1850)
{
   return global_src_229_ast_var((global_t) (obj_1850));
}


/* allocate-variable */ variable_t 
allocate_variable_244_ast_var()
{
   {
      variable_t new1050_473;
      new1050_473 = ((variable_t) BREF(GC_MALLOC(sizeof(struct variable))));
      {
	 long arg1575_474;
	 arg1575_474 = class_num_218___object(variable_ast_var);
	 {
	    obj_t obj_984;
	    obj_984 = (obj_t) (new1050_473);
	    (((obj_t) CREF(obj_984))->header = MAKE_HEADER(arg1575_474, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2713;
	 aux_2713 = (object_t) (new1050_473);
	 OBJECT_WIDENING_SET(aux_2713, BFALSE);
      }
      return new1050_473;
   }
}


/* _allocate-variable */ obj_t 
_allocate_variable_137_ast_var(obj_t env_1496)
{
   {
      variable_t aux_2716;
      aux_2716 = allocate_variable_244_ast_var();
      return (obj_t) (aux_2716);
   }
}


/* variable? */ bool_t 
variable__18_ast_var(obj_t obj_252)
{
   return is_a__118___object(obj_252, variable_ast_var);
}


/* _variable? */ obj_t 
_variable__238_ast_var(obj_t env_1851, obj_t obj_1852)
{
   {
      bool_t aux_2720;
      aux_2720 = variable__18_ast_var(obj_1852);
      return BBOOL(aux_2720);
   }
}


/* make-variable */ variable_t 
make_variable_6_ast_var(obj_t id_253, obj_t name_254, type_t type_255, value_t value_256, obj_t access_257, obj_t fast_alpha_7_258, obj_t removable_259, long occurrence_260)
{
   {
      variable_t new1033_986;
      new1033_986 = ((variable_t) BREF(GC_MALLOC(sizeof(struct variable))));
      {
	 long arg1578_987;
	 arg1578_987 = class_num_218___object(variable_ast_var);
	 {
	    obj_t obj_996;
	    obj_996 = (obj_t) (new1033_986);
	    (((obj_t) CREF(obj_996))->header = MAKE_HEADER(arg1578_987, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2727;
	 aux_2727 = (object_t) (new1033_986);
	 OBJECT_WIDENING_SET(aux_2727, BFALSE);
      }
      ((((variable_t) CREF(new1033_986))->id) = ((obj_t) id_253), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->name) = ((obj_t) name_254), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->type) = ((type_t) type_255), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->value) = ((value_t) value_256), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->access) = ((obj_t) access_257), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->fast_alpha_7) = ((obj_t) fast_alpha_7_258), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->removable) = ((obj_t) removable_259), BUNSPEC);
      ((((variable_t) CREF(new1033_986))->occurrence) = ((long) occurrence_260), BUNSPEC);
      return new1033_986;
   }
}


/* _make-variable1929 */ obj_t 
_make_variable1929_49_ast_var(obj_t env_1853, obj_t id_1854, obj_t name_1855, obj_t type_1856, obj_t value_1857, obj_t access_1858, obj_t fast_alpha_7_1859, obj_t removable_1860, obj_t occurrence_1861)
{
   {
      variable_t aux_2738;
      aux_2738 = make_variable_6_ast_var(id_1854, name_1855, (type_t) (type_1856), (value_t) (value_1857), access_1858, fast_alpha_7_1859, removable_1860, (long) CINT(occurrence_1861));
      return (obj_t) (aux_2738);
   }
}


/* variable-id */ obj_t 
variable_id_167_ast_var(variable_t obj_261)
{
   return (((variable_t) CREF(obj_261))->id);
}


/* _variable-id1930 */ obj_t 
_variable_id1930_132_ast_var(obj_t env_1862, obj_t obj_1863)
{
   return variable_id_167_ast_var((variable_t) (obj_1863));
}


/* variable-name-set! */ obj_t 
variable_name_set__44_ast_var(variable_t obj_262, obj_t val1043_263)
{
   return ((((variable_t) CREF(obj_262))->name) = ((obj_t) val1043_263), BUNSPEC);
}


/* _variable-name-set!1931 */ obj_t 
_variable_name_set_1931_62_ast_var(obj_t env_1864, obj_t obj_1865, obj_t val1043_1866)
{
   return variable_name_set__44_ast_var((variable_t) (obj_1865), val1043_1866);
}


/* variable-name */ obj_t 
variable_name_105_ast_var(variable_t obj_264)
{
   return (((variable_t) CREF(obj_264))->name);
}


/* _variable-name1932 */ obj_t 
_variable_name1932_100_ast_var(obj_t env_1867, obj_t obj_1868)
{
   return variable_name_105_ast_var((variable_t) (obj_1868));
}


/* variable-type-set! */ obj_t 
variable_type_set__4_ast_var(variable_t obj_265, type_t val1044_266)
{
   return ((((variable_t) CREF(obj_265))->type) = ((type_t) val1044_266), BUNSPEC);
}


/* _variable-type-set!1933 */ obj_t 
_variable_type_set_1933_207_ast_var(obj_t env_1869, obj_t obj_1870, obj_t val1044_1871)
{
   return variable_type_set__4_ast_var((variable_t) (obj_1870), (type_t) (val1044_1871));
}


/* variable-type */ type_t 
variable_type_237_ast_var(variable_t obj_267)
{
   return (((variable_t) CREF(obj_267))->type);
}


/* _variable-type1934 */ obj_t 
_variable_type1934_235_ast_var(obj_t env_1872, obj_t obj_1873)
{
   {
      type_t aux_2758;
      aux_2758 = variable_type_237_ast_var((variable_t) (obj_1873));
      return (obj_t) (aux_2758);
   }
}


/* variable-value-set! */ obj_t 
variable_value_set__250_ast_var(variable_t obj_268, value_t val1045_269)
{
   return ((((variable_t) CREF(obj_268))->value) = ((value_t) val1045_269), BUNSPEC);
}


/* _variable-value-set!1935 */ obj_t 
_variable_value_set_1935_216_ast_var(obj_t env_1874, obj_t obj_1875, obj_t val1045_1876)
{
   return variable_value_set__250_ast_var((variable_t) (obj_1875), (value_t) (val1045_1876));
}


/* variable-value */ value_t 
variable_value_212_ast_var(variable_t obj_270)
{
   return (((variable_t) CREF(obj_270))->value);
}


/* _variable-value1936 */ obj_t 
_variable_value1936_49_ast_var(obj_t env_1877, obj_t obj_1878)
{
   {
      value_t aux_2767;
      aux_2767 = variable_value_212_ast_var((variable_t) (obj_1878));
      return (obj_t) (aux_2767);
   }
}


/* variable-access-set! */ obj_t 
variable_access_set__102_ast_var(variable_t obj_271, obj_t val1046_272)
{
   return ((((variable_t) CREF(obj_271))->access) = ((obj_t) val1046_272), BUNSPEC);
}


/* _variable-access-set!1937 */ obj_t 
_variable_access_set_1937_226_ast_var(obj_t env_1879, obj_t obj_1880, obj_t val1046_1881)
{
   return variable_access_set__102_ast_var((variable_t) (obj_1880), val1046_1881);
}


/* variable-access */ obj_t 
variable_access_211_ast_var(variable_t obj_273)
{
   return (((variable_t) CREF(obj_273))->access);
}


/* _variable-access1938 */ obj_t 
_variable_access1938_157_ast_var(obj_t env_1882, obj_t obj_1883)
{
   return variable_access_211_ast_var((variable_t) (obj_1883));
}


/* variable-fast-alpha-set! */ obj_t 
variable_fast_alpha_set__48_ast_var(variable_t obj_274, obj_t val1047_275)
{
   return ((((variable_t) CREF(obj_274))->fast_alpha_7) = ((obj_t) val1047_275), BUNSPEC);
}


/* _variable-fast-alpha-set!1939 */ obj_t 
_variable_fast_alpha_set_1939_234_ast_var(obj_t env_1884, obj_t obj_1885, obj_t val1047_1886)
{
   return variable_fast_alpha_set__48_ast_var((variable_t) (obj_1885), val1047_1886);
}


/* variable-fast-alpha */ obj_t 
variable_fast_alpha_132_ast_var(variable_t obj_276)
{
   return (((variable_t) CREF(obj_276))->fast_alpha_7);
}


/* _variable-fast-alpha1940 */ obj_t 
_variable_fast_alpha1940_254_ast_var(obj_t env_1887, obj_t obj_1888)
{
   return variable_fast_alpha_132_ast_var((variable_t) (obj_1888));
}


/* variable-removable-set! */ obj_t 
variable_removable_set__218_ast_var(variable_t obj_277, obj_t val1048_278)
{
   return ((((variable_t) CREF(obj_277))->removable) = ((obj_t) val1048_278), BUNSPEC);
}


/* _variable-removable-set!1941 */ obj_t 
_variable_removable_set_1941_231_ast_var(obj_t env_1889, obj_t obj_1890, obj_t val1048_1891)
{
   return variable_removable_set__218_ast_var((variable_t) (obj_1890), val1048_1891);
}


/* variable-removable */ obj_t 
variable_removable_74_ast_var(variable_t obj_279)
{
   return (((variable_t) CREF(obj_279))->removable);
}


/* _variable-removable1942 */ obj_t 
_variable_removable1942_189_ast_var(obj_t env_1892, obj_t obj_1893)
{
   return variable_removable_74_ast_var((variable_t) (obj_1893));
}


/* variable-occurrence-set! */ obj_t 
variable_occurrence_set__234_ast_var(variable_t obj_280, long val1049_281)
{
   return ((((variable_t) CREF(obj_280))->occurrence) = ((long) val1049_281), BUNSPEC);
}


/* _variable-occurrence-set!1943 */ obj_t 
_variable_occurrence_set_1943_127_ast_var(obj_t env_1894, obj_t obj_1895, obj_t val1049_1896)
{
   return variable_occurrence_set__234_ast_var((variable_t) (obj_1895), (long) CINT(val1049_1896));
}


/* variable-occurrence */ long 
variable_occurrence_246_ast_var(variable_t obj_282)
{
   return (((variable_t) CREF(obj_282))->occurrence);
}


/* _variable-occurrence1944 */ obj_t 
_variable_occurrence1944_66_ast_var(obj_t env_1897, obj_t obj_1898)
{
   {
      long aux_2794;
      aux_2794 = variable_occurrence_246_ast_var((variable_t) (obj_1898));
      return BINT(aux_2794);
   }
}


/* allocate-value */ value_t 
allocate_value_190_ast_var()
{
   {
      value_t new1030_485;
      new1030_485 = ((value_t) BREF(GC_MALLOC(sizeof(struct value))));
      {
	 long arg1580_486;
	 arg1580_486 = class_num_218___object(value_ast_var);
	 {
	    obj_t obj_998;
	    obj_998 = (obj_t) (new1030_485);
	    (((obj_t) CREF(obj_998))->header = MAKE_HEADER(arg1580_486, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2802;
	 aux_2802 = (object_t) (new1030_485);
	 OBJECT_WIDENING_SET(aux_2802, BFALSE);
      }
      return new1030_485;
   }
}


/* _allocate-value */ obj_t 
_allocate_value_13_ast_var(obj_t env_1495)
{
   {
      value_t aux_2805;
      aux_2805 = allocate_value_190_ast_var();
      return (obj_t) (aux_2805);
   }
}


/* value? */ bool_t 
value__43_ast_var(obj_t obj_286)
{
   return is_a__118___object(obj_286, value_ast_var);
}


/* _value? */ obj_t 
_value__210_ast_var(obj_t env_1899, obj_t obj_1900)
{
   {
      bool_t aux_2809;
      aux_2809 = value__43_ast_var(obj_1900);
      return BBOOL(aux_2809);
   }
}


/* make-value */ value_t 
make_value_52_ast_var()
{
   {
      value_t new1028_1000;
      new1028_1000 = ((value_t) BREF(GC_MALLOC(sizeof(struct value))));
      {
	 long arg1581_1001;
	 arg1581_1001 = class_num_218___object(value_ast_var);
	 {
	    obj_t obj_1002;
	    obj_1002 = (obj_t) (new1028_1000);
	    (((obj_t) CREF(obj_1002))->header = MAKE_HEADER(arg1581_1001, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2816;
	 aux_2816 = (object_t) (new1028_1000);
	 OBJECT_WIDENING_SET(aux_2816, BFALSE);
      }
      {
	 return new1028_1000;
      }
   }
}


/* _make-value */ obj_t 
_make_value_202_ast_var(obj_t env_1901)
{
   {
      value_t aux_2819;
      aux_2819 = make_value_52_ast_var();
      return (obj_t) (aux_2819);
   }
}


/* method-init */ obj_t 
method_init_76_ast_var()
{
   {
      obj_t object__struct_sexit_213_1923;
      object__struct_sexit_213_1923 = proc1950_ast_var;
      add_method__1___object(object__struct_env_210___object, sexit_ast_var, object__struct_sexit_213_1923);
   }
   {
      obj_t struct_object__object_sexit_101_1922;
      struct_object__object_sexit_101_1922 = proc1951_ast_var;
      add_method__1___object(struct_object__object_env_209___object, sexit_ast_var, struct_object__object_sexit_101_1922);
   }
   {
      obj_t object__struct_cvar_12_1921;
      object__struct_cvar_12_1921 = proc1952_ast_var;
      add_method__1___object(object__struct_env_210___object, cvar_ast_var, object__struct_cvar_12_1921);
   }
   {
      obj_t struct_object__object_cvar_183_1920;
      struct_object__object_cvar_183_1920 = proc1953_ast_var;
      add_method__1___object(struct_object__object_env_209___object, cvar_ast_var, struct_object__object_cvar_183_1920);
   }
   {
      obj_t object__struct_scnst_111_1919;
      object__struct_scnst_111_1919 = proc1954_ast_var;
      add_method__1___object(object__struct_env_210___object, scnst_ast_var, object__struct_scnst_111_1919);
   }
   {
      obj_t struct_object__object_scnst_43_1918;
      struct_object__object_scnst_43_1918 = proc1955_ast_var;
      add_method__1___object(struct_object__object_env_209___object, scnst_ast_var, struct_object__object_scnst_43_1918);
   }
   {
      obj_t object__struct_svar_233_1917;
      object__struct_svar_233_1917 = proc1956_ast_var;
      add_method__1___object(object__struct_env_210___object, svar_ast_var, object__struct_svar_233_1917);
   }
   {
      obj_t struct_object__object_svar_1_1916;
      struct_object__object_svar_1_1916 = proc1957_ast_var;
      add_method__1___object(struct_object__object_env_209___object, svar_ast_var, struct_object__object_svar_1_1916);
   }
   {
      obj_t object__struct_cfun_117_1915;
      object__struct_cfun_117_1915 = proc1958_ast_var;
      add_method__1___object(object__struct_env_210___object, cfun_ast_var, object__struct_cfun_117_1915);
   }
   {
      obj_t struct_object__object_cfun_108_1914;
      struct_object__object_cfun_108_1914 = proc1959_ast_var;
      add_method__1___object(struct_object__object_env_209___object, cfun_ast_var, struct_object__object_cfun_108_1914);
   }
   {
      obj_t object__struct_sfun_209_1913;
      object__struct_sfun_209_1913 = proc1960_ast_var;
      add_method__1___object(object__struct_env_210___object, sfun_ast_var, object__struct_sfun_209_1913);
   }
   {
      obj_t struct_object__object_sfun_10_1912;
      struct_object__object_sfun_10_1912 = proc1961_ast_var;
      add_method__1___object(struct_object__object_env_209___object, sfun_ast_var, struct_object__object_sfun_10_1912);
   }
   {
      obj_t object__struct_fun_194_1911;
      object__struct_fun_194_1911 = proc1962_ast_var;
      add_method__1___object(object__struct_env_210___object, fun_ast_var, object__struct_fun_194_1911);
   }
   {
      obj_t struct_object__object_fun_34_1910;
      struct_object__object_fun_34_1910 = proc1963_ast_var;
      add_method__1___object(struct_object__object_env_209___object, fun_ast_var, struct_object__object_fun_34_1910);
   }
   {
      obj_t object__struct_local_56_1909;
      object__struct_local_56_1909 = proc1964_ast_var;
      add_method__1___object(object__struct_env_210___object, local_ast_var, object__struct_local_56_1909);
   }
   {
      obj_t struct_object__object_local_234_1908;
      struct_object__object_local_234_1908 = proc1965_ast_var;
      add_method__1___object(struct_object__object_env_209___object, local_ast_var, struct_object__object_local_234_1908);
   }
   {
      obj_t object__struct_global_193_1907;
      object__struct_global_193_1907 = proc1966_ast_var;
      add_method__1___object(object__struct_env_210___object, global_ast_var, object__struct_global_193_1907);
   }
   {
      obj_t struct_object__object_global_249_1906;
      struct_object__object_global_249_1906 = proc1967_ast_var;
      add_method__1___object(struct_object__object_env_209___object, global_ast_var, struct_object__object_global_249_1906);
   }
   {
      obj_t object__struct_variable_84_1905;
      object__struct_variable_84_1905 = proc1968_ast_var;
      add_method__1___object(object__struct_env_210___object, variable_ast_var, object__struct_variable_84_1905);
   }
   {
      obj_t struct_object__object_variable_106_1904;
      struct_object__object_variable_106_1904 = proc1969_ast_var;
      add_method__1___object(struct_object__object_env_209___object, variable_ast_var, struct_object__object_variable_106_1904);
   }
   {
      obj_t object__struct_value_130_1903;
      object__struct_value_130_1903 = proc1970_ast_var;
      add_method__1___object(object__struct_env_210___object, value_ast_var, object__struct_value_130_1903);
   }
   {
      obj_t struct_object__object_value_20_1902;
      struct_object__object_value_20_1902 = proc1971_ast_var;
      return add_method__1___object(struct_object__object_env_209___object, value_ast_var, struct_object__object_value_20_1902);
   }
}


/* struct+object->object-value */ obj_t 
struct_object__object_value_20_ast_var(obj_t env_1924, obj_t o_1925, obj_t s_1926)
{
   {
      value_t o_864;
      obj_t s_865;
      {
	 value_t aux_2844;
	 o_864 = (value_t) (o_1925);
	 s_865 = s_1926;
	 {
	    obj_t aux_2847;
	    object_t aux_2845;
	    aux_2847 = STRUCT_REF(s_865, ((long) 0));
	    aux_2845 = (object_t) (o_864);
	    OBJECT_WIDENING_SET(aux_2845, aux_2847);
	 }
	 aux_2844 = o_864;
	 return (obj_t) (aux_2844);
      }
   }
}


/* object->struct-value */ obj_t 
object__struct_value_130_ast_var(obj_t env_1927, obj_t obj1031_1928)
{
   {
      value_t obj1031_856;
      obj1031_856 = (value_t) (obj1031_1928);
      {
	 obj_t res1032_859;
	 {
	    obj_t aux_2852;
	    aux_2852 = CNST_TABLE_REF(((long) 0));
	    res1032_859 = make_struct(aux_2852, ((long) 1), BUNSPEC);
	 }
	 STRUCT_SET(res1032_859, ((long) 0), BFALSE);
	 return res1032_859;
      }
   }
}


/* struct+object->object-variable */ obj_t 
struct_object__object_variable_106_ast_var(obj_t env_1929, obj_t o_1930, obj_t s_1931)
{
   {
      variable_t o_841;
      obj_t s_842;
      {
	 variable_t aux_2857;
	 o_841 = (variable_t) (o_1930);
	 s_842 = s_1931;
	 {
	    obj_t aux_2860;
	    object_t aux_2858;
	    aux_2860 = STRUCT_REF(s_842, ((long) 0));
	    aux_2858 = (object_t) (o_841);
	    OBJECT_WIDENING_SET(aux_2858, aux_2860);
	 }
	 {
	    obj_t v1055_846;
	    v1055_846 = STRUCT_REF(s_842, ((long) 1));
	    ((((variable_t) CREF(o_841))->id) = ((obj_t) v1055_846), BUNSPEC);
	 }
	 {
	    obj_t v1059_847;
	    v1059_847 = STRUCT_REF(s_842, ((long) 2));
	    ((((variable_t) CREF(o_841))->name) = ((obj_t) v1059_847), BUNSPEC);
	 }
	 {
	    type_t v1063_848;
	    {
	       obj_t aux_2867;
	       aux_2867 = STRUCT_REF(s_842, ((long) 3));
	       v1063_848 = (type_t) (aux_2867);
	    }
	    ((((variable_t) CREF(o_841))->type) = ((type_t) v1063_848), BUNSPEC);
	 }
	 {
	    value_t v1067_849;
	    {
	       obj_t aux_2871;
	       aux_2871 = STRUCT_REF(s_842, ((long) 4));
	       v1067_849 = (value_t) (aux_2871);
	    }
	    ((((variable_t) CREF(o_841))->value) = ((value_t) v1067_849), BUNSPEC);
	 }
	 {
	    obj_t v1071_850;
	    v1071_850 = STRUCT_REF(s_842, ((long) 5));
	    ((((variable_t) CREF(o_841))->access) = ((obj_t) v1071_850), BUNSPEC);
	 }
	 {
	    obj_t v1075_851;
	    v1075_851 = STRUCT_REF(s_842, ((long) 6));
	    ((((variable_t) CREF(o_841))->fast_alpha_7) = ((obj_t) v1075_851), BUNSPEC);
	 }
	 {
	    obj_t v1079_852;
	    v1079_852 = STRUCT_REF(s_842, ((long) 7));
	    ((((variable_t) CREF(o_841))->removable) = ((obj_t) v1079_852), BUNSPEC);
	 }
	 {
	    long v1083_853;
	    {
	       obj_t aux_2881;
	       aux_2881 = STRUCT_REF(s_842, ((long) 8));
	       v1083_853 = (long) CINT(aux_2881);
	    }
	    ((((variable_t) CREF(o_841))->occurrence) = ((long) v1083_853), BUNSPEC);
	 }
	 aux_2857 = o_841;
	 return (obj_t) (aux_2857);
      }
   }
}


/* object->struct-variable */ obj_t 
object__struct_variable_84_ast_var(obj_t env_1932, obj_t obj1051_1933)
{
   {
      variable_t obj1051_817;
      obj1051_817 = (variable_t) (obj1051_1933);
      {
	 obj_t res1052_820;
	 {
	    obj_t aux_2887;
	    aux_2887 = CNST_TABLE_REF(((long) 1));
	    res1052_820 = make_struct(aux_2887, ((long) 9), BUNSPEC);
	 }
	 STRUCT_SET(res1052_820, ((long) 0), BFALSE);
	 {
	    obj_t aux_2891;
	    aux_2891 = (((variable_t) CREF(obj1051_817))->id);
	    STRUCT_SET(res1052_820, ((long) 1), aux_2891);
	 }
	 {
	    obj_t aux_2894;
	    aux_2894 = (((variable_t) CREF(obj1051_817))->name);
	    STRUCT_SET(res1052_820, ((long) 2), aux_2894);
	 }
	 {
	    obj_t aux_2897;
	    {
	       type_t aux_2898;
	       aux_2898 = (((variable_t) CREF(obj1051_817))->type);
	       aux_2897 = (obj_t) (aux_2898);
	    }
	    STRUCT_SET(res1052_820, ((long) 3), aux_2897);
	 }
	 {
	    obj_t aux_2902;
	    {
	       value_t aux_2903;
	       aux_2903 = (((variable_t) CREF(obj1051_817))->value);
	       aux_2902 = (obj_t) (aux_2903);
	    }
	    STRUCT_SET(res1052_820, ((long) 4), aux_2902);
	 }
	 {
	    obj_t aux_2907;
	    aux_2907 = (((variable_t) CREF(obj1051_817))->access);
	    STRUCT_SET(res1052_820, ((long) 5), aux_2907);
	 }
	 {
	    obj_t aux_2910;
	    aux_2910 = (((variable_t) CREF(obj1051_817))->fast_alpha_7);
	    STRUCT_SET(res1052_820, ((long) 6), aux_2910);
	 }
	 {
	    obj_t aux_2913;
	    aux_2913 = (((variable_t) CREF(obj1051_817))->removable);
	    STRUCT_SET(res1052_820, ((long) 7), aux_2913);
	 }
	 {
	    obj_t aux_2916;
	    {
	       long aux_2917;
	       aux_2917 = (((variable_t) CREF(obj1051_817))->occurrence);
	       aux_2916 = BINT(aux_2917);
	    }
	    STRUCT_SET(res1052_820, ((long) 8), aux_2916);
	 }
	 return res1052_820;
      }
   }
}


/* struct+object->object-global */ obj_t 
struct_object__object_global_249_ast_var(obj_t env_1934, obj_t o_1935, obj_t s_1936)
{
   {
      global_t o_795;
      obj_t s_796;
      {
	 global_t aux_2922;
	 o_795 = (global_t) (o_1935);
	 s_796 = s_1936;
	 {
	    obj_t aux_2925;
	    object_t aux_2923;
	    aux_2925 = STRUCT_REF(s_796, ((long) 0));
	    aux_2923 = (object_t) (o_795);
	    OBJECT_WIDENING_SET(aux_2923, aux_2925);
	 }
	 {
	    obj_t v1119_800;
	    v1119_800 = STRUCT_REF(s_796, ((long) 1));
	    ((((global_t) CREF(o_795))->id) = ((obj_t) v1119_800), BUNSPEC);
	 }
	 {
	    obj_t v1123_801;
	    v1123_801 = STRUCT_REF(s_796, ((long) 2));
	    ((((global_t) CREF(o_795))->name) = ((obj_t) v1123_801), BUNSPEC);
	 }
	 {
	    type_t v1127_802;
	    {
	       obj_t aux_2932;
	       aux_2932 = STRUCT_REF(s_796, ((long) 3));
	       v1127_802 = (type_t) (aux_2932);
	    }
	    ((((global_t) CREF(o_795))->type) = ((type_t) v1127_802), BUNSPEC);
	 }
	 {
	    value_t v1131_803;
	    {
	       obj_t aux_2936;
	       aux_2936 = STRUCT_REF(s_796, ((long) 4));
	       v1131_803 = (value_t) (aux_2936);
	    }
	    ((((global_t) CREF(o_795))->value) = ((value_t) v1131_803), BUNSPEC);
	 }
	 {
	    obj_t v1135_804;
	    v1135_804 = STRUCT_REF(s_796, ((long) 5));
	    ((((global_t) CREF(o_795))->access) = ((obj_t) v1135_804), BUNSPEC);
	 }
	 {
	    obj_t v1139_805;
	    v1139_805 = STRUCT_REF(s_796, ((long) 6));
	    ((((global_t) CREF(o_795))->fast_alpha_7) = ((obj_t) v1139_805), BUNSPEC);
	 }
	 {
	    obj_t v1143_806;
	    v1143_806 = STRUCT_REF(s_796, ((long) 7));
	    ((((global_t) CREF(o_795))->removable) = ((obj_t) v1143_806), BUNSPEC);
	 }
	 {
	    long v1147_807;
	    {
	       obj_t aux_2946;
	       aux_2946 = STRUCT_REF(s_796, ((long) 8));
	       v1147_807 = (long) CINT(aux_2946);
	    }
	    ((((global_t) CREF(o_795))->occurrence) = ((long) v1147_807), BUNSPEC);
	 }
	 {
	    obj_t v1151_808;
	    v1151_808 = STRUCT_REF(s_796, ((long) 9));
	    ((((global_t) CREF(o_795))->module) = ((obj_t) v1151_808), BUNSPEC);
	 }
	 {
	    obj_t v1155_809;
	    v1155_809 = STRUCT_REF(s_796, ((long) 10));
	    ((((global_t) CREF(o_795))->import) = ((obj_t) v1155_809), BUNSPEC);
	 }
	 {
	    bool_t v1159_810;
	    {
	       obj_t aux_2954;
	       aux_2954 = STRUCT_REF(s_796, ((long) 11));
	       v1159_810 = CBOOL(aux_2954);
	    }
	    ((((global_t) CREF(o_795))->evaluable__248) = ((bool_t) v1159_810), BUNSPEC);
	 }
	 {
	    bool_t v1163_811;
	    {
	       obj_t aux_2958;
	       aux_2958 = STRUCT_REF(s_796, ((long) 12));
	       v1163_811 = CBOOL(aux_2958);
	    }
	    ((((global_t) CREF(o_795))->library__255) = ((bool_t) v1163_811), BUNSPEC);
	 }
	 {
	    bool_t v1167_812;
	    {
	       obj_t aux_2962;
	       aux_2962 = STRUCT_REF(s_796, ((long) 13));
	       v1167_812 = CBOOL(aux_2962);
	    }
	    ((((global_t) CREF(o_795))->user__32) = ((bool_t) v1167_812), BUNSPEC);
	 }
	 {
	    obj_t v1171_813;
	    v1171_813 = STRUCT_REF(s_796, ((long) 14));
	    ((((global_t) CREF(o_795))->pragma) = ((obj_t) v1171_813), BUNSPEC);
	 }
	 {
	    obj_t v1175_814;
	    v1175_814 = STRUCT_REF(s_796, ((long) 15));
	    ((((global_t) CREF(o_795))->src) = ((obj_t) v1175_814), BUNSPEC);
	 }
	 aux_2922 = o_795;
	 return (obj_t) (aux_2922);
      }
   }
}


/* object->struct-global */ obj_t 
object__struct_global_193_ast_var(obj_t env_1937, obj_t obj1115_1938)
{
   {
      global_t obj1115_757;
      obj1115_757 = (global_t) (obj1115_1938);
      {
	 obj_t res1116_760;
	 {
	    obj_t aux_2972;
	    aux_2972 = CNST_TABLE_REF(((long) 2));
	    res1116_760 = make_struct(aux_2972, ((long) 16), BUNSPEC);
	 }
	 STRUCT_SET(res1116_760, ((long) 0), BFALSE);
	 {
	    obj_t aux_2976;
	    aux_2976 = (((global_t) CREF(obj1115_757))->id);
	    STRUCT_SET(res1116_760, ((long) 1), aux_2976);
	 }
	 {
	    obj_t aux_2979;
	    aux_2979 = (((global_t) CREF(obj1115_757))->name);
	    STRUCT_SET(res1116_760, ((long) 2), aux_2979);
	 }
	 {
	    obj_t aux_2982;
	    {
	       type_t aux_2983;
	       aux_2983 = (((global_t) CREF(obj1115_757))->type);
	       aux_2982 = (obj_t) (aux_2983);
	    }
	    STRUCT_SET(res1116_760, ((long) 3), aux_2982);
	 }
	 {
	    obj_t aux_2987;
	    {
	       value_t aux_2988;
	       aux_2988 = (((global_t) CREF(obj1115_757))->value);
	       aux_2987 = (obj_t) (aux_2988);
	    }
	    STRUCT_SET(res1116_760, ((long) 4), aux_2987);
	 }
	 {
	    obj_t aux_2992;
	    aux_2992 = (((global_t) CREF(obj1115_757))->access);
	    STRUCT_SET(res1116_760, ((long) 5), aux_2992);
	 }
	 {
	    obj_t aux_2995;
	    aux_2995 = (((global_t) CREF(obj1115_757))->fast_alpha_7);
	    STRUCT_SET(res1116_760, ((long) 6), aux_2995);
	 }
	 {
	    obj_t aux_2998;
	    aux_2998 = (((global_t) CREF(obj1115_757))->removable);
	    STRUCT_SET(res1116_760, ((long) 7), aux_2998);
	 }
	 {
	    obj_t aux_3001;
	    {
	       long aux_3002;
	       aux_3002 = (((global_t) CREF(obj1115_757))->occurrence);
	       aux_3001 = BINT(aux_3002);
	    }
	    STRUCT_SET(res1116_760, ((long) 8), aux_3001);
	 }
	 {
	    obj_t aux_3006;
	    aux_3006 = (((global_t) CREF(obj1115_757))->module);
	    STRUCT_SET(res1116_760, ((long) 9), aux_3006);
	 }
	 {
	    obj_t aux_3009;
	    aux_3009 = (((global_t) CREF(obj1115_757))->import);
	    STRUCT_SET(res1116_760, ((long) 10), aux_3009);
	 }
	 {
	    obj_t aux_3012;
	    {
	       bool_t aux_3013;
	       aux_3013 = (((global_t) CREF(obj1115_757))->evaluable__248);
	       aux_3012 = BBOOL(aux_3013);
	    }
	    STRUCT_SET(res1116_760, ((long) 11), aux_3012);
	 }
	 {
	    obj_t aux_3017;
	    {
	       bool_t aux_3018;
	       aux_3018 = (((global_t) CREF(obj1115_757))->library__255);
	       aux_3017 = BBOOL(aux_3018);
	    }
	    STRUCT_SET(res1116_760, ((long) 12), aux_3017);
	 }
	 {
	    obj_t aux_3022;
	    {
	       bool_t aux_3023;
	       aux_3023 = (((global_t) CREF(obj1115_757))->user__32);
	       aux_3022 = BBOOL(aux_3023);
	    }
	    STRUCT_SET(res1116_760, ((long) 13), aux_3022);
	 }
	 {
	    obj_t aux_3027;
	    aux_3027 = (((global_t) CREF(obj1115_757))->pragma);
	    STRUCT_SET(res1116_760, ((long) 14), aux_3027);
	 }
	 {
	    obj_t aux_3030;
	    aux_3030 = (((global_t) CREF(obj1115_757))->src);
	    STRUCT_SET(res1116_760, ((long) 15), aux_3030);
	 }
	 return res1116_760;
      }
   }
}


/* struct+object->object-local */ obj_t 
struct_object__object_local_234_ast_var(obj_t env_1939, obj_t o_1940, obj_t s_1941)
{
   {
      local_t o_740;
      obj_t s_741;
      {
	 local_t aux_3034;
	 o_740 = (local_t) (o_1940);
	 s_741 = s_1941;
	 {
	    obj_t aux_3037;
	    object_t aux_3035;
	    aux_3037 = STRUCT_REF(s_741, ((long) 0));
	    aux_3035 = (object_t) (o_740);
	    OBJECT_WIDENING_SET(aux_3035, aux_3037);
	 }
	 {
	    obj_t v1202_745;
	    v1202_745 = STRUCT_REF(s_741, ((long) 1));
	    ((((local_t) CREF(o_740))->id) = ((obj_t) v1202_745), BUNSPEC);
	 }
	 {
	    obj_t v1206_746;
	    v1206_746 = STRUCT_REF(s_741, ((long) 2));
	    ((((local_t) CREF(o_740))->name) = ((obj_t) v1206_746), BUNSPEC);
	 }
	 {
	    type_t v1210_747;
	    {
	       obj_t aux_3044;
	       aux_3044 = STRUCT_REF(s_741, ((long) 3));
	       v1210_747 = (type_t) (aux_3044);
	    }
	    ((((local_t) CREF(o_740))->type) = ((type_t) v1210_747), BUNSPEC);
	 }
	 {
	    value_t v1214_748;
	    {
	       obj_t aux_3048;
	       aux_3048 = STRUCT_REF(s_741, ((long) 4));
	       v1214_748 = (value_t) (aux_3048);
	    }
	    ((((local_t) CREF(o_740))->value) = ((value_t) v1214_748), BUNSPEC);
	 }
	 {
	    obj_t v1218_749;
	    v1218_749 = STRUCT_REF(s_741, ((long) 5));
	    ((((local_t) CREF(o_740))->access) = ((obj_t) v1218_749), BUNSPEC);
	 }
	 {
	    obj_t v1222_750;
	    v1222_750 = STRUCT_REF(s_741, ((long) 6));
	    ((((local_t) CREF(o_740))->fast_alpha_7) = ((obj_t) v1222_750), BUNSPEC);
	 }
	 {
	    obj_t v1226_751;
	    v1226_751 = STRUCT_REF(s_741, ((long) 7));
	    ((((local_t) CREF(o_740))->removable) = ((obj_t) v1226_751), BUNSPEC);
	 }
	 {
	    long v1230_752;
	    {
	       obj_t aux_3058;
	       aux_3058 = STRUCT_REF(s_741, ((long) 8));
	       v1230_752 = (long) CINT(aux_3058);
	    }
	    ((((local_t) CREF(o_740))->occurrence) = ((long) v1230_752), BUNSPEC);
	 }
	 {
	    bool_t v1234_753;
	    {
	       obj_t aux_3062;
	       aux_3062 = STRUCT_REF(s_741, ((long) 9));
	       v1234_753 = CBOOL(aux_3062);
	    }
	    ((((local_t) CREF(o_740))->user__32) = ((bool_t) v1234_753), BUNSPEC);
	 }
	 {
	    long v1238_754;
	    {
	       obj_t aux_3066;
	       aux_3066 = STRUCT_REF(s_741, ((long) 10));
	       v1238_754 = (long) CINT(aux_3066);
	    }
	    ((((local_t) CREF(o_740))->key) = ((long) v1238_754), BUNSPEC);
	 }
	 aux_3034 = o_740;
	 return (obj_t) (aux_3034);
      }
   }
}


/* object->struct-local */ obj_t 
object__struct_local_56_ast_var(obj_t env_1942, obj_t obj1198_1943)
{
   {
      local_t obj1198_712;
      obj1198_712 = (local_t) (obj1198_1943);
      {
	 obj_t res1199_715;
	 {
	    obj_t aux_3072;
	    aux_3072 = CNST_TABLE_REF(((long) 3));
	    res1199_715 = make_struct(aux_3072, ((long) 11), BUNSPEC);
	 }
	 STRUCT_SET(res1199_715, ((long) 0), BFALSE);
	 {
	    obj_t aux_3076;
	    aux_3076 = (((local_t) CREF(obj1198_712))->id);
	    STRUCT_SET(res1199_715, ((long) 1), aux_3076);
	 }
	 {
	    obj_t aux_3079;
	    aux_3079 = (((local_t) CREF(obj1198_712))->name);
	    STRUCT_SET(res1199_715, ((long) 2), aux_3079);
	 }
	 {
	    obj_t aux_3082;
	    {
	       type_t aux_3083;
	       aux_3083 = (((local_t) CREF(obj1198_712))->type);
	       aux_3082 = (obj_t) (aux_3083);
	    }
	    STRUCT_SET(res1199_715, ((long) 3), aux_3082);
	 }
	 {
	    obj_t aux_3087;
	    {
	       value_t aux_3088;
	       aux_3088 = (((local_t) CREF(obj1198_712))->value);
	       aux_3087 = (obj_t) (aux_3088);
	    }
	    STRUCT_SET(res1199_715, ((long) 4), aux_3087);
	 }
	 {
	    obj_t aux_3092;
	    aux_3092 = (((local_t) CREF(obj1198_712))->access);
	    STRUCT_SET(res1199_715, ((long) 5), aux_3092);
	 }
	 {
	    obj_t aux_3095;
	    aux_3095 = (((local_t) CREF(obj1198_712))->fast_alpha_7);
	    STRUCT_SET(res1199_715, ((long) 6), aux_3095);
	 }
	 {
	    obj_t aux_3098;
	    aux_3098 = (((local_t) CREF(obj1198_712))->removable);
	    STRUCT_SET(res1199_715, ((long) 7), aux_3098);
	 }
	 {
	    obj_t aux_3101;
	    {
	       long aux_3102;
	       aux_3102 = (((local_t) CREF(obj1198_712))->occurrence);
	       aux_3101 = BINT(aux_3102);
	    }
	    STRUCT_SET(res1199_715, ((long) 8), aux_3101);
	 }
	 {
	    obj_t aux_3106;
	    {
	       bool_t aux_3107;
	       aux_3107 = (((local_t) CREF(obj1198_712))->user__32);
	       aux_3106 = BBOOL(aux_3107);
	    }
	    STRUCT_SET(res1199_715, ((long) 9), aux_3106);
	 }
	 {
	    obj_t aux_3111;
	    {
	       long aux_3112;
	       aux_3112 = (((local_t) CREF(obj1198_712))->key);
	       aux_3111 = BINT(aux_3112);
	    }
	    STRUCT_SET(res1199_715, ((long) 10), aux_3111);
	 }
	 return res1199_715;
      }
   }
}


/* struct+object->object-fun */ obj_t 
struct_object__object_fun_34_ast_var(obj_t env_1944, obj_t o_1945, obj_t s_1946)
{
   {
      fun_t o_699;
      obj_t s_700;
      {
	 fun_t aux_3117;
	 o_699 = (fun_t) (o_1945);
	 s_700 = s_1946;
	 {
	    obj_t aux_3120;
	    object_t aux_3118;
	    aux_3120 = STRUCT_REF(s_700, ((long) 0));
	    aux_3118 = (object_t) (o_699);
	    OBJECT_WIDENING_SET(aux_3118, aux_3120);
	 }
	 {
	    long v1258_704;
	    {
	       obj_t aux_3123;
	       aux_3123 = STRUCT_REF(s_700, ((long) 1));
	       v1258_704 = (long) CINT(aux_3123);
	    }
	    ((((fun_t) CREF(o_699))->arity) = ((long) v1258_704), BUNSPEC);
	 }
	 {
	    obj_t v1262_705;
	    v1262_705 = STRUCT_REF(s_700, ((long) 2));
	    ((((fun_t) CREF(o_699))->side_effect__165) = ((obj_t) v1262_705), BUNSPEC);
	 }
	 {
	    obj_t v1266_706;
	    v1266_706 = STRUCT_REF(s_700, ((long) 3));
	    ((((fun_t) CREF(o_699))->predicate_of_78) = ((obj_t) v1266_706), BUNSPEC);
	 }
	 {
	    obj_t v1270_707;
	    v1270_707 = STRUCT_REF(s_700, ((long) 4));
	    ((((fun_t) CREF(o_699))->stack_allocator_172) = ((obj_t) v1270_707), BUNSPEC);
	 }
	 {
	    bool_t v1274_708;
	    {
	       obj_t aux_3133;
	       aux_3133 = STRUCT_REF(s_700, ((long) 5));
	       v1274_708 = CBOOL(aux_3133);
	    }
	    ((((fun_t) CREF(o_699))->top__138) = ((bool_t) v1274_708), BUNSPEC);
	 }
	 {
	    obj_t v1278_709;
	    v1278_709 = STRUCT_REF(s_700, ((long) 6));
	    ((((fun_t) CREF(o_699))->the_closure_238) = ((obj_t) v1278_709), BUNSPEC);
	 }
	 aux_3117 = o_699;
	 return (obj_t) (aux_3117);
      }
   }
}


/* object->struct-fun */ obj_t 
object__struct_fun_194_ast_var(obj_t env_1947, obj_t obj1254_1948)
{
   {
      fun_t obj1254_679;
      obj1254_679 = (fun_t) (obj1254_1948);
      {
	 obj_t res1255_682;
	 {
	    obj_t aux_3141;
	    aux_3141 = CNST_TABLE_REF(((long) 4));
	    res1255_682 = make_struct(aux_3141, ((long) 7), BUNSPEC);
	 }
	 STRUCT_SET(res1255_682, ((long) 0), BFALSE);
	 {
	    obj_t aux_3145;
	    {
	       long aux_3146;
	       aux_3146 = (((fun_t) CREF(obj1254_679))->arity);
	       aux_3145 = BINT(aux_3146);
	    }
	    STRUCT_SET(res1255_682, ((long) 1), aux_3145);
	 }
	 {
	    obj_t aux_3150;
	    aux_3150 = (((fun_t) CREF(obj1254_679))->side_effect__165);
	    STRUCT_SET(res1255_682, ((long) 2), aux_3150);
	 }
	 {
	    obj_t aux_3153;
	    aux_3153 = (((fun_t) CREF(obj1254_679))->predicate_of_78);
	    STRUCT_SET(res1255_682, ((long) 3), aux_3153);
	 }
	 {
	    obj_t aux_3156;
	    aux_3156 = (((fun_t) CREF(obj1254_679))->stack_allocator_172);
	    STRUCT_SET(res1255_682, ((long) 4), aux_3156);
	 }
	 {
	    obj_t aux_3159;
	    {
	       bool_t aux_3160;
	       aux_3160 = (((fun_t) CREF(obj1254_679))->top__138);
	       aux_3159 = BBOOL(aux_3160);
	    }
	    STRUCT_SET(res1255_682, ((long) 5), aux_3159);
	 }
	 {
	    obj_t aux_3164;
	    aux_3164 = (((fun_t) CREF(obj1254_679))->the_closure_238);
	    STRUCT_SET(res1255_682, ((long) 6), aux_3164);
	 }
	 return res1255_682;
      }
   }
}


/* struct+object->object-sfun */ obj_t 
struct_object__object_sfun_10_ast_var(obj_t env_1949, obj_t o_1950, obj_t s_1951)
{
   {
      sfun_t o_660;
      obj_t s_661;
      {
	 sfun_t aux_3168;
	 o_660 = (sfun_t) (o_1950);
	 s_661 = s_1951;
	 {
	    obj_t aux_3171;
	    object_t aux_3169;
	    aux_3171 = STRUCT_REF(s_661, ((long) 0));
	    aux_3169 = (object_t) (o_660);
	    OBJECT_WIDENING_SET(aux_3169, aux_3171);
	 }
	 {
	    long v1310_665;
	    {
	       obj_t aux_3174;
	       aux_3174 = STRUCT_REF(s_661, ((long) 1));
	       v1310_665 = (long) CINT(aux_3174);
	    }
	    ((((sfun_t) CREF(o_660))->arity) = ((long) v1310_665), BUNSPEC);
	 }
	 {
	    obj_t v1314_666;
	    v1314_666 = STRUCT_REF(s_661, ((long) 2));
	    ((((sfun_t) CREF(o_660))->side_effect__165) = ((obj_t) v1314_666), BUNSPEC);
	 }
	 {
	    obj_t v1318_667;
	    v1318_667 = STRUCT_REF(s_661, ((long) 3));
	    ((((sfun_t) CREF(o_660))->predicate_of_78) = ((obj_t) v1318_667), BUNSPEC);
	 }
	 {
	    obj_t v1322_668;
	    v1322_668 = STRUCT_REF(s_661, ((long) 4));
	    ((((sfun_t) CREF(o_660))->stack_allocator_172) = ((obj_t) v1322_668), BUNSPEC);
	 }
	 {
	    bool_t v1326_669;
	    {
	       obj_t aux_3184;
	       aux_3184 = STRUCT_REF(s_661, ((long) 5));
	       v1326_669 = CBOOL(aux_3184);
	    }
	    ((((sfun_t) CREF(o_660))->top__138) = ((bool_t) v1326_669), BUNSPEC);
	 }
	 {
	    obj_t v1330_670;
	    v1330_670 = STRUCT_REF(s_661, ((long) 6));
	    ((((sfun_t) CREF(o_660))->the_closure_238) = ((obj_t) v1330_670), BUNSPEC);
	 }
	 {
	    obj_t v1334_671;
	    v1334_671 = STRUCT_REF(s_661, ((long) 7));
	    ((((sfun_t) CREF(o_660))->property) = ((obj_t) v1334_671), BUNSPEC);
	 }
	 {
	    obj_t v1338_672;
	    v1338_672 = STRUCT_REF(s_661, ((long) 8));
	    ((((sfun_t) CREF(o_660))->args) = ((obj_t) v1338_672), BUNSPEC);
	 }
	 {
	    obj_t v1342_673;
	    v1342_673 = STRUCT_REF(s_661, ((long) 9));
	    ((((sfun_t) CREF(o_660))->body) = ((obj_t) v1342_673), BUNSPEC);
	 }
	 {
	    obj_t v1346_674;
	    v1346_674 = STRUCT_REF(s_661, ((long) 10));
	    ((((sfun_t) CREF(o_660))->class) = ((obj_t) v1346_674), BUNSPEC);
	 }
	 {
	    obj_t v1350_675;
	    v1350_675 = STRUCT_REF(s_661, ((long) 11));
	    ((((sfun_t) CREF(o_660))->dsssl_keywords_243) = ((obj_t) v1350_675), BUNSPEC);
	 }
	 {
	    obj_t v1354_676;
	    v1354_676 = STRUCT_REF(s_661, ((long) 12));
	    ((((sfun_t) CREF(o_660))->loc) = ((obj_t) v1354_676), BUNSPEC);
	 }
	 aux_3168 = o_660;
	 return (obj_t) (aux_3168);
      }
   }
}


/* object->struct-sfun */ obj_t 
object__struct_sfun_209_ast_var(obj_t env_1952, obj_t obj1306_1953)
{
   {
      sfun_t obj1306_628;
      obj1306_628 = (sfun_t) (obj1306_1953);
      {
	 obj_t res1307_631;
	 {
	    obj_t aux_3204;
	    aux_3204 = CNST_TABLE_REF(((long) 5));
	    res1307_631 = make_struct(aux_3204, ((long) 13), BUNSPEC);
	 }
	 STRUCT_SET(res1307_631, ((long) 0), BFALSE);
	 {
	    obj_t aux_3208;
	    {
	       long aux_3209;
	       aux_3209 = (((sfun_t) CREF(obj1306_628))->arity);
	       aux_3208 = BINT(aux_3209);
	    }
	    STRUCT_SET(res1307_631, ((long) 1), aux_3208);
	 }
	 {
	    obj_t aux_3213;
	    aux_3213 = (((sfun_t) CREF(obj1306_628))->side_effect__165);
	    STRUCT_SET(res1307_631, ((long) 2), aux_3213);
	 }
	 {
	    obj_t aux_3216;
	    aux_3216 = (((sfun_t) CREF(obj1306_628))->predicate_of_78);
	    STRUCT_SET(res1307_631, ((long) 3), aux_3216);
	 }
	 {
	    obj_t aux_3219;
	    aux_3219 = (((sfun_t) CREF(obj1306_628))->stack_allocator_172);
	    STRUCT_SET(res1307_631, ((long) 4), aux_3219);
	 }
	 {
	    obj_t aux_3222;
	    {
	       bool_t aux_3223;
	       aux_3223 = (((sfun_t) CREF(obj1306_628))->top__138);
	       aux_3222 = BBOOL(aux_3223);
	    }
	    STRUCT_SET(res1307_631, ((long) 5), aux_3222);
	 }
	 {
	    obj_t aux_3227;
	    aux_3227 = (((sfun_t) CREF(obj1306_628))->the_closure_238);
	    STRUCT_SET(res1307_631, ((long) 6), aux_3227);
	 }
	 {
	    obj_t aux_3230;
	    aux_3230 = (((sfun_t) CREF(obj1306_628))->property);
	    STRUCT_SET(res1307_631, ((long) 7), aux_3230);
	 }
	 {
	    obj_t aux_3233;
	    aux_3233 = (((sfun_t) CREF(obj1306_628))->args);
	    STRUCT_SET(res1307_631, ((long) 8), aux_3233);
	 }
	 {
	    obj_t aux_3236;
	    aux_3236 = (((sfun_t) CREF(obj1306_628))->body);
	    STRUCT_SET(res1307_631, ((long) 9), aux_3236);
	 }
	 {
	    obj_t aux_3239;
	    aux_3239 = (((sfun_t) CREF(obj1306_628))->class);
	    STRUCT_SET(res1307_631, ((long) 10), aux_3239);
	 }
	 {
	    obj_t aux_3242;
	    aux_3242 = (((sfun_t) CREF(obj1306_628))->dsssl_keywords_243);
	    STRUCT_SET(res1307_631, ((long) 11), aux_3242);
	 }
	 {
	    obj_t aux_3245;
	    aux_3245 = (((sfun_t) CREF(obj1306_628))->loc);
	    STRUCT_SET(res1307_631, ((long) 12), aux_3245);
	 }
	 return res1307_631;
      }
   }
}


/* struct+object->object-cfun */ obj_t 
struct_object__object_cfun_108_ast_var(obj_t env_1954, obj_t o_1955, obj_t s_1956)
{
   {
      cfun_t o_612;
      obj_t s_613;
      {
	 cfun_t aux_3249;
	 o_612 = (cfun_t) (o_1955);
	 s_613 = s_1956;
	 {
	    obj_t aux_3252;
	    object_t aux_3250;
	    aux_3252 = STRUCT_REF(s_613, ((long) 0));
	    aux_3250 = (object_t) (o_612);
	    OBJECT_WIDENING_SET(aux_3250, aux_3252);
	 }
	 {
	    long v1378_617;
	    {
	       obj_t aux_3255;
	       aux_3255 = STRUCT_REF(s_613, ((long) 1));
	       v1378_617 = (long) CINT(aux_3255);
	    }
	    ((((cfun_t) CREF(o_612))->arity) = ((long) v1378_617), BUNSPEC);
	 }
	 {
	    obj_t v1382_618;
	    v1382_618 = STRUCT_REF(s_613, ((long) 2));
	    ((((cfun_t) CREF(o_612))->side_effect__165) = ((obj_t) v1382_618), BUNSPEC);
	 }
	 {
	    obj_t v1386_619;
	    v1386_619 = STRUCT_REF(s_613, ((long) 3));
	    ((((cfun_t) CREF(o_612))->predicate_of_78) = ((obj_t) v1386_619), BUNSPEC);
	 }
	 {
	    obj_t v1390_620;
	    v1390_620 = STRUCT_REF(s_613, ((long) 4));
	    ((((cfun_t) CREF(o_612))->stack_allocator_172) = ((obj_t) v1390_620), BUNSPEC);
	 }
	 {
	    bool_t v1394_621;
	    {
	       obj_t aux_3265;
	       aux_3265 = STRUCT_REF(s_613, ((long) 5));
	       v1394_621 = CBOOL(aux_3265);
	    }
	    ((((cfun_t) CREF(o_612))->top__138) = ((bool_t) v1394_621), BUNSPEC);
	 }
	 {
	    obj_t v1398_622;
	    v1398_622 = STRUCT_REF(s_613, ((long) 6));
	    ((((cfun_t) CREF(o_612))->the_closure_238) = ((obj_t) v1398_622), BUNSPEC);
	 }
	 {
	    obj_t v1402_623;
	    v1402_623 = STRUCT_REF(s_613, ((long) 7));
	    ((((cfun_t) CREF(o_612))->args_type_205) = ((obj_t) v1402_623), BUNSPEC);
	 }
	 {
	    bool_t v1406_624;
	    {
	       obj_t aux_3273;
	       aux_3273 = STRUCT_REF(s_613, ((long) 8));
	       v1406_624 = CBOOL(aux_3273);
	    }
	    ((((cfun_t) CREF(o_612))->macro__33) = ((bool_t) v1406_624), BUNSPEC);
	 }
	 {
	    bool_t v1410_625;
	    {
	       obj_t aux_3277;
	       aux_3277 = STRUCT_REF(s_613, ((long) 9));
	       v1410_625 = CBOOL(aux_3277);
	    }
	    ((((cfun_t) CREF(o_612))->infix__163) = ((bool_t) v1410_625), BUNSPEC);
	 }
	 aux_3249 = o_612;
	 return (obj_t) (aux_3249);
      }
   }
}


/* object->struct-cfun */ obj_t 
object__struct_cfun_117_ast_var(obj_t env_1957, obj_t obj1374_1958)
{
   {
      cfun_t obj1374_586;
      obj1374_586 = (cfun_t) (obj1374_1958);
      {
	 obj_t res1375_589;
	 {
	    obj_t aux_3283;
	    aux_3283 = CNST_TABLE_REF(((long) 6));
	    res1375_589 = make_struct(aux_3283, ((long) 10), BUNSPEC);
	 }
	 STRUCT_SET(res1375_589, ((long) 0), BFALSE);
	 {
	    obj_t aux_3287;
	    {
	       long aux_3288;
	       aux_3288 = (((cfun_t) CREF(obj1374_586))->arity);
	       aux_3287 = BINT(aux_3288);
	    }
	    STRUCT_SET(res1375_589, ((long) 1), aux_3287);
	 }
	 {
	    obj_t aux_3292;
	    aux_3292 = (((cfun_t) CREF(obj1374_586))->side_effect__165);
	    STRUCT_SET(res1375_589, ((long) 2), aux_3292);
	 }
	 {
	    obj_t aux_3295;
	    aux_3295 = (((cfun_t) CREF(obj1374_586))->predicate_of_78);
	    STRUCT_SET(res1375_589, ((long) 3), aux_3295);
	 }
	 {
	    obj_t aux_3298;
	    aux_3298 = (((cfun_t) CREF(obj1374_586))->stack_allocator_172);
	    STRUCT_SET(res1375_589, ((long) 4), aux_3298);
	 }
	 {
	    obj_t aux_3301;
	    {
	       bool_t aux_3302;
	       aux_3302 = (((cfun_t) CREF(obj1374_586))->top__138);
	       aux_3301 = BBOOL(aux_3302);
	    }
	    STRUCT_SET(res1375_589, ((long) 5), aux_3301);
	 }
	 {
	    obj_t aux_3306;
	    aux_3306 = (((cfun_t) CREF(obj1374_586))->the_closure_238);
	    STRUCT_SET(res1375_589, ((long) 6), aux_3306);
	 }
	 {
	    obj_t aux_3309;
	    aux_3309 = (((cfun_t) CREF(obj1374_586))->args_type_205);
	    STRUCT_SET(res1375_589, ((long) 7), aux_3309);
	 }
	 {
	    obj_t aux_3312;
	    {
	       bool_t aux_3313;
	       aux_3313 = (((cfun_t) CREF(obj1374_586))->macro__33);
	       aux_3312 = BBOOL(aux_3313);
	    }
	    STRUCT_SET(res1375_589, ((long) 8), aux_3312);
	 }
	 {
	    obj_t aux_3317;
	    {
	       bool_t aux_3318;
	       aux_3318 = (((cfun_t) CREF(obj1374_586))->infix__163);
	       aux_3317 = BBOOL(aux_3318);
	    }
	    STRUCT_SET(res1375_589, ((long) 9), aux_3317);
	 }
	 return res1375_589;
      }
   }
}


/* struct+object->object-svar */ obj_t 
struct_object__object_svar_1_ast_var(obj_t env_1959, obj_t o_1960, obj_t s_1961)
{
   {
      svar_t o_578;
      obj_t s_579;
      {
	 svar_t aux_3323;
	 o_578 = (svar_t) (o_1960);
	 s_579 = s_1961;
	 {
	    obj_t aux_3326;
	    object_t aux_3324;
	    aux_3326 = STRUCT_REF(s_579, ((long) 0));
	    aux_3324 = (object_t) (o_578);
	    OBJECT_WIDENING_SET(aux_3324, aux_3326);
	 }
	 {
	    obj_t v1421_583;
	    v1421_583 = STRUCT_REF(s_579, ((long) 1));
	    ((((svar_t) CREF(o_578))->loc) = ((obj_t) v1421_583), BUNSPEC);
	 }
	 aux_3323 = o_578;
	 return (obj_t) (aux_3323);
      }
   }
}


/* object->struct-svar */ obj_t 
object__struct_svar_233_ast_var(obj_t env_1962, obj_t obj1417_1963)
{
   {
      svar_t obj1417_568;
      obj1417_568 = (svar_t) (obj1417_1963);
      {
	 obj_t res1418_571;
	 {
	    obj_t aux_3333;
	    aux_3333 = CNST_TABLE_REF(((long) 7));
	    res1418_571 = make_struct(aux_3333, ((long) 2), BUNSPEC);
	 }
	 STRUCT_SET(res1418_571, ((long) 0), BFALSE);
	 {
	    obj_t aux_3337;
	    aux_3337 = (((svar_t) CREF(obj1417_568))->loc);
	    STRUCT_SET(res1418_571, ((long) 1), aux_3337);
	 }
	 return res1418_571;
      }
   }
}


/* struct+object->object-scnst */ obj_t 
struct_object__object_scnst_43_ast_var(obj_t env_1964, obj_t o_1965, obj_t s_1966)
{
   {
      scnst_t o_558;
      obj_t s_559;
      {
	 scnst_t aux_3341;
	 o_558 = (scnst_t) (o_1965);
	 s_559 = s_1966;
	 {
	    obj_t aux_3344;
	    object_t aux_3342;
	    aux_3344 = STRUCT_REF(s_559, ((long) 0));
	    aux_3342 = (object_t) (o_558);
	    OBJECT_WIDENING_SET(aux_3342, aux_3344);
	 }
	 {
	    obj_t v1435_563;
	    v1435_563 = STRUCT_REF(s_559, ((long) 1));
	    ((((scnst_t) CREF(o_558))->node) = ((obj_t) v1435_563), BUNSPEC);
	 }
	 {
	    obj_t v1439_564;
	    v1439_564 = STRUCT_REF(s_559, ((long) 2));
	    ((((scnst_t) CREF(o_558))->class) = ((obj_t) v1439_564), BUNSPEC);
	 }
	 {
	    obj_t v1443_565;
	    v1443_565 = STRUCT_REF(s_559, ((long) 3));
	    ((((scnst_t) CREF(o_558))->loc) = ((obj_t) v1443_565), BUNSPEC);
	 }
	 aux_3341 = o_558;
	 return (obj_t) (aux_3341);
      }
   }
}


/* object->struct-scnst */ obj_t 
object__struct_scnst_111_ast_var(obj_t env_1967, obj_t obj1431_1968)
{
   {
      scnst_t obj1431_544;
      obj1431_544 = (scnst_t) (obj1431_1968);
      {
	 obj_t res1432_547;
	 {
	    obj_t aux_3355;
	    aux_3355 = CNST_TABLE_REF(((long) 8));
	    res1432_547 = make_struct(aux_3355, ((long) 4), BUNSPEC);
	 }
	 STRUCT_SET(res1432_547, ((long) 0), BFALSE);
	 {
	    obj_t aux_3359;
	    aux_3359 = (((scnst_t) CREF(obj1431_544))->node);
	    STRUCT_SET(res1432_547, ((long) 1), aux_3359);
	 }
	 {
	    obj_t aux_3362;
	    aux_3362 = (((scnst_t) CREF(obj1431_544))->class);
	    STRUCT_SET(res1432_547, ((long) 2), aux_3362);
	 }
	 {
	    obj_t aux_3365;
	    aux_3365 = (((scnst_t) CREF(obj1431_544))->loc);
	    STRUCT_SET(res1432_547, ((long) 3), aux_3365);
	 }
	 return res1432_547;
      }
   }
}


/* struct+object->object-cvar */ obj_t 
struct_object__object_cvar_183_ast_var(obj_t env_1969, obj_t o_1970, obj_t s_1971)
{
   {
      cvar_t o_536;
      obj_t s_537;
      {
	 cvar_t aux_3369;
	 o_536 = (cvar_t) (o_1970);
	 s_537 = s_1971;
	 {
	    obj_t aux_3372;
	    object_t aux_3370;
	    aux_3372 = STRUCT_REF(s_537, ((long) 0));
	    aux_3370 = (object_t) (o_536);
	    OBJECT_WIDENING_SET(aux_3370, aux_3372);
	 }
	 {
	    bool_t v1454_541;
	    {
	       obj_t aux_3375;
	       aux_3375 = STRUCT_REF(s_537, ((long) 1));
	       v1454_541 = CBOOL(aux_3375);
	    }
	    ((((cvar_t) CREF(o_536))->macro__33) = ((bool_t) v1454_541), BUNSPEC);
	 }
	 aux_3369 = o_536;
	 return (obj_t) (aux_3369);
      }
   }
}


/* object->struct-cvar */ obj_t 
object__struct_cvar_12_ast_var(obj_t env_1972, obj_t obj1450_1973)
{
   {
      cvar_t obj1450_526;
      obj1450_526 = (cvar_t) (obj1450_1973);
      {
	 obj_t res1451_529;
	 {
	    obj_t aux_3381;
	    aux_3381 = CNST_TABLE_REF(((long) 9));
	    res1451_529 = make_struct(aux_3381, ((long) 2), BUNSPEC);
	 }
	 STRUCT_SET(res1451_529, ((long) 0), BFALSE);
	 {
	    obj_t aux_3385;
	    {
	       bool_t aux_3386;
	       aux_3386 = (((cvar_t) CREF(obj1450_526))->macro__33);
	       aux_3385 = BBOOL(aux_3386);
	    }
	    STRUCT_SET(res1451_529, ((long) 1), aux_3385);
	 }
	 return res1451_529;
      }
   }
}


/* struct+object->object-sexit */ obj_t 
struct_object__object_sexit_101_ast_var(obj_t env_1974, obj_t o_1975, obj_t s_1976)
{
   {
      sexit_t o_517;
      obj_t s_518;
      {
	 sexit_t aux_3391;
	 o_517 = (sexit_t) (o_1975);
	 s_518 = s_1976;
	 {
	    obj_t aux_3394;
	    object_t aux_3392;
	    aux_3394 = STRUCT_REF(s_518, ((long) 0));
	    aux_3392 = (object_t) (o_517);
	    OBJECT_WIDENING_SET(aux_3392, aux_3394);
	 }
	 {
	    obj_t v1467_522;
	    v1467_522 = STRUCT_REF(s_518, ((long) 1));
	    ((((sexit_t) CREF(o_517))->handler) = ((obj_t) v1467_522), BUNSPEC);
	 }
	 {
	    bool_t v1471_523;
	    {
	       obj_t aux_3399;
	       aux_3399 = STRUCT_REF(s_518, ((long) 2));
	       v1471_523 = CBOOL(aux_3399);
	    }
	    ((((sexit_t) CREF(o_517))->detached__120) = ((bool_t) v1471_523), BUNSPEC);
	 }
	 aux_3391 = o_517;
	 return (obj_t) (aux_3391);
      }
   }
}


/* object->struct-sexit */ obj_t 
object__struct_sexit_213_ast_var(obj_t env_1977, obj_t obj1463_1978)
{
   {
      sexit_t obj1463_505;
      obj1463_505 = (sexit_t) (obj1463_1978);
      {
	 obj_t res1464_508;
	 {
	    obj_t aux_3405;
	    aux_3405 = CNST_TABLE_REF(((long) 10));
	    res1464_508 = make_struct(aux_3405, ((long) 3), BUNSPEC);
	 }
	 STRUCT_SET(res1464_508, ((long) 0), BFALSE);
	 {
	    obj_t aux_3409;
	    aux_3409 = (((sexit_t) CREF(obj1463_505))->handler);
	    STRUCT_SET(res1464_508, ((long) 1), aux_3409);
	 }
	 {
	    obj_t aux_3412;
	    {
	       bool_t aux_3413;
	       aux_3413 = (((sexit_t) CREF(obj1463_505))->detached__120);
	       aux_3412 = BBOOL(aux_3413);
	    }
	    STRUCT_SET(res1464_508, ((long) 2), aux_3412);
	 }
	 return res1464_508;
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_var()
{
   module_initialization_70_engine_param(((long) 0), "AST_VAR");
   return module_initialization_70_type_type(((long) 0), "AST_VAR");
}
