/*===========================================================================*/
/*   (Globalize/gloclo.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t local_ginfo_108_globalize_ginfo;
extern obj_t make_n_proto_123_tools_args(obj_t);
static obj_t method_init_76_globalize_global_closure_246();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t var_ast_node;
static obj_t gloclo_globalize_global_closure_246(global_t, local_t, obj_t);
static obj_t _global_closure1818_227_globalize_global_closure_246(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
static obj_t _foreign_closures__211_globalize_global_closure_246 = BUNSPEC;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_global_closure_246(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70_globalize_free(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern global_t make_global_closure_44_globalize_global_closure_246(global_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
static obj_t _make_global_closure1819_11_globalize_global_closure_246(obj_t, obj_t);
extern global_t def_global_sfun__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _foreign_closures_249_globalize_global_closure_246(obj_t);
static obj_t imported_modules_init_94_globalize_global_closure_246();
extern obj_t cfun_ast_var;
extern obj_t app_ast_node;
static obj_t library_modules_init_112_globalize_global_closure_246();
extern obj_t global_ginfo_75_globalize_ginfo;
extern obj_t svar_ginfo_131_globalize_ginfo;
extern obj_t foreign_closures_19_globalize_global_closure_246();
static obj_t toplevel_init_63_globalize_global_closure_246();
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern obj_t local_ast_var;
extern global_t global_closure_229_globalize_global_closure_246(global_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t __arity_132_tools_args(obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t _procedure__226_type_cache;
extern obj_t the_global_closure_233_globalize_free(global_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_globalize_global_closure_246 = BUNSPEC;
static obj_t cnst_init_137_globalize_global_closure_246();
static obj_t __cnst[8];

DEFINE_EXPORT_PROCEDURE(global_closure_env_218_globalize_global_closure_246, _global_closure1818_227_globalize_global_closure_2461831, _global_closure1818_227_globalize_global_closure_246, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_global_closure_env_43_globalize_global_closure_246, _make_global_closure1819_11_globalize_global_closure_2461832, _make_global_closure1819_11_globalize_global_closure_246, 0L, 1);
DEFINE_EXPORT_PROCEDURE(foreign_closures_env_102_globalize_global_closure_246, _foreign_closures_249_globalize_global_closure_2461833, _foreign_closures_249_globalize_global_closure_246, 0L, 0);
DEFINE_STRING(string1825_globalize_global_closure_246, string1825_globalize_global_closure_2461834, "STATIC NEVER NOW SFUN FOREIGN ::OBJ _ ENV ", 42);
DEFINE_STRING(string1824_globalize_global_closure_246, string1824_globalize_global_closure_2461835, "Can't allocate global closure", 29);
DEFINE_STRING(string1823_globalize_global_closure_246, string1823_globalize_global_closure_2461836, "global-closure", 14);
DEFINE_STRING(string1822_globalize_global_closure_246, string1822_globalize_global_closure_2461837, "_", 1);
DEFINE_STRING(string1821_globalize_global_closure_246, string1821_globalize_global_closure_2461838, "Unexpected value", 16);
DEFINE_STRING(string1820_globalize_global_closure_246, string1820_globalize_global_closure_2461839, "make-global-closure", 19);


/* module-initialization */ obj_t 
module_initialization_70_globalize_global_closure_246(long checksum_1825, char *from_1826)
{
   if (CBOOL(require_initialization_114_globalize_global_closure_246))
     {
	require_initialization_114_globalize_global_closure_246 = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_global_closure_246();
	cnst_init_137_globalize_global_closure_246();
	imported_modules_init_94_globalize_global_closure_246();
	method_init_76_globalize_global_closure_246();
	toplevel_init_63_globalize_global_closure_246();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_global_closure_246()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70___object(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_global_closure_246()
{
   {
      obj_t cnst_port_138_1817;
      cnst_port_138_1817 = open_input_string(string1825_globalize_global_closure_246);
      {
	 long i_1818;
	 i_1818 = ((long) 7);
       loop_1819:
	 {
	    bool_t test1826_1820;
	    test1826_1820 = (i_1818 == ((long) -1));
	    if (test1826_1820)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1827_1821;
		    {
		       obj_t list1828_1822;
		       {
			  obj_t arg1829_1823;
			  arg1829_1823 = BNIL;
			  list1828_1822 = MAKE_PAIR(cnst_port_138_1817, arg1829_1823);
		       }
		       arg1827_1821 = read___reader(list1828_1822);
		    }
		    CNST_TABLE_SET(i_1818, arg1827_1821);
		 }
		 {
		    int aux_1824;
		    {
		       long aux_1844;
		       aux_1844 = (i_1818 - ((long) 1));
		       aux_1824 = (int) (aux_1844);
		    }
		    {
		       long i_1847;
		       i_1847 = (long) (aux_1824);
		       i_1818 = i_1847;
		       goto loop_1819;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_global_closure_246()
{
   return (_foreign_closures__211_globalize_global_closure_246 = BNIL,
      BUNSPEC);
}


/* global-closure */ global_t 
global_closure_229_globalize_global_closure_246(global_t global_1, obj_t loc_2)
{
   the_global_closure_233_globalize_free(global_1, loc_2);
   return make_global_closure_44_globalize_global_closure_246(global_1);
}


/* _global-closure1818 */ obj_t 
_global_closure1818_227_globalize_global_closure_246(obj_t env_1811, obj_t global_1812, obj_t loc_1813)
{
   {
      global_t aux_1851;
      aux_1851 = global_closure_229_globalize_global_closure_246((global_t) (global_1812), loc_1813);
      return (obj_t) (aux_1851);
   }
}


/* make-global-closure */ global_t 
make_global_closure_44_globalize_global_closure_246(global_t global_3)
{
   {
      obj_t glo_1007;
      {
	 global_ginfo_75_t obj_1531;
	 obj_1531 = (global_ginfo_75_t) (global_3);
	 {
	    obj_t aux_1856;
	    {
	       object_t aux_1857;
	       aux_1857 = (object_t) (obj_1531);
	       aux_1856 = OBJECT_WIDENING(aux_1857);
	    }
	    glo_1007 = (((global_ginfo_75_t) CREF(aux_1856))->global_closure_229);
	 }
      }
      {
	 bool_t test1583_1008;
	 test1583_1008 = is_a__118___object(glo_1007, global_ast_var);
	 if (test1583_1008)
	   {
	      return (global_t) (glo_1007);
	   }
	 else
	   {
	      value_t old_fun_147_1009;
	      old_fun_147_1009 = (((global_t) CREF(global_3))->value);
	      {
		 local_t env_1010;
		 {
		    local_t var_1076;
		    var_1076 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 0)), (type_t) (_procedure__226_type_cache));
		    {
		       local_ginfo_108_t obj1565_1077;
		       obj1565_1077 = ((local_ginfo_108_t) (var_1076));
		       {
			  local_ginfo_108_t arg1639_1078;
			  {
			     local_ginfo_108_t res1810_1537;
			     {
				local_ginfo_108_t new1529_1535;
				new1529_1535 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
				((((local_ginfo_108_t) CREF(new1529_1535))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				res1810_1537 = new1529_1535;
			     }
			     arg1639_1078 = res1810_1537;
			  }
			  {
			     obj_t aux_1873;
			     object_t aux_1871;
			     aux_1873 = (obj_t) (arg1639_1078);
			     aux_1871 = (object_t) (obj1565_1077);
			     OBJECT_WIDENING_SET(aux_1871, aux_1873);
			  }
		       }
		       {
			  long arg1640_1079;
			  arg1640_1079 = class_num_218___object(local_ginfo_108_globalize_ginfo);
			  {
			     obj_t obj_1538;
			     obj_1538 = (obj_t) (obj1565_1077);
			     (((obj_t) CREF(obj_1538))->header = MAKE_HEADER(arg1640_1079, 0), BUNSPEC);
			  }
		       }
		       obj1565_1077;
		    }
		    env_1010 = var_1076;
		 }
		 {
		    obj_t new_args_235_1011;
		    {
		       obj_t l1566_1049;
		       {
			  bool_t test1637_1074;
			  test1637_1074 = is_a__118___object((obj_t) (old_fun_147_1009), sfun_ast_var);
			  if (test1637_1074)
			    {
			       sfun_t obj_1541;
			       obj_1541 = (sfun_t) (old_fun_147_1009);
			       l1566_1049 = (((sfun_t) CREF(obj_1541))->args);
			    }
			  else
			    {
			       bool_t test1638_1075;
			       test1638_1075 = is_a__118___object((obj_t) (old_fun_147_1009), cfun_ast_var);
			       if (test1638_1075)
				 {
				    cfun_t obj_1543;
				    obj_1543 = (cfun_t) (old_fun_147_1009);
				    l1566_1049 = (((cfun_t) CREF(obj_1543))->args_type_205);
				 }
			       else
				 {
				    l1566_1049 = internal_error_43_tools_error(string1820_globalize_global_closure_246, string1821_globalize_global_closure_246, (obj_t) (old_fun_147_1009));
				 }
			    }
		       }
		       if (NULLP(l1566_1049))
			 {
			    new_args_235_1011 = BNIL;
			 }
		       else
			 {
			    obj_t head1568_1051;
			    head1568_1051 = MAKE_PAIR(BNIL, BNIL);
			    {
			       obj_t l1566_1052;
			       obj_t tail1569_1053;
			       l1566_1052 = l1566_1049;
			       tail1569_1053 = head1568_1051;
			     lname1567_1054:
			       if (NULLP(l1566_1052))
				 {
				    new_args_235_1011 = CDR(head1568_1051);
				 }
			       else
				 {
				    obj_t newtail1570_1056;
				    {
				       local_t arg1621_1058;
				       {
					  obj_t old_1060;
					  old_1060 = CAR(l1566_1052);
					  {
					     local_t new_1061;
					     {
						obj_t arg1632_1070;
						{
						   bool_t test1633_1071;
						   test1633_1071 = is_a__118___object(old_1060, local_ast_var);
						   if (test1633_1071)
						     {
							local_t obj_1551;
							obj_1551 = (local_t) (old_1060);
							arg1632_1070 = (((local_t) CREF(obj_1551))->id);
						     }
						   else
						     {
							arg1632_1070 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, BEOA);
						     }
						}
						new_1061 = make_local_svar_140_ast_local(arg1632_1070, (type_t) (_obj__252_type_cache));
					     }
					     {
						bool_t test1623_1062;
						test1623_1062 = is_a__118___object(old_1060, local_ast_var);
						if (test1623_1062)
						  {
						     bool_t arg1624_1063;
						     {
							local_t obj_1553;
							obj_1553 = (local_t) (old_1060);
							arg1624_1063 = (((local_t) CREF(obj_1553))->user__32);
						     }
						     ((((local_t) CREF(new_1061))->user__32) = ((bool_t) arg1624_1063), BUNSPEC);
						  }
						else
						  {
						     BUNSPEC;
						  }
					     }
					     {
						svar_ginfo_131_t obj1571_1064;
						obj1571_1064 = ((svar_ginfo_131_t) ((((local_t) CREF(new_1061))->value)));
						{
						   svar_ginfo_131_t arg1625_1065;
						   {
						      svar_ginfo_131_t res1811_1566;
						      {
							 svar_ginfo_131_t new1500_1561;
							 new1500_1561 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
							 ((((svar_ginfo_131_t) CREF(new1500_1561))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							 ((((svar_ginfo_131_t) CREF(new1500_1561))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
							 ((((svar_ginfo_131_t) CREF(new1500_1561))->mark) = ((long) ((long) -10)), BUNSPEC);
							 ((((svar_ginfo_131_t) CREF(new1500_1561))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							 res1811_1566 = new1500_1561;
						      }
						      arg1625_1065 = res1811_1566;
						   }
						   {
						      obj_t aux_1920;
						      object_t aux_1918;
						      aux_1920 = (obj_t) (arg1625_1065);
						      aux_1918 = (object_t) (obj1571_1064);
						      OBJECT_WIDENING_SET(aux_1918, aux_1920);
						   }
						}
						{
						   long arg1627_1066;
						   arg1627_1066 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
						   {
						      obj_t obj_1567;
						      obj_1567 = (obj_t) (obj1571_1064);
						      (((obj_t) CREF(obj_1567))->header = MAKE_HEADER(arg1627_1066, 0), BUNSPEC);
						   }
						}
						obj1571_1064;
					     }
					     {
						local_ginfo_108_t obj1572_1067;
						obj1572_1067 = ((local_ginfo_108_t) (new_1061));
						{
						   local_ginfo_108_t arg1628_1068;
						   {
						      local_ginfo_108_t res1812_1572;
						      {
							 local_ginfo_108_t new1529_1570;
							 new1529_1570 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
							 ((((local_ginfo_108_t) CREF(new1529_1570))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							 res1812_1572 = new1529_1570;
						      }
						      arg1628_1068 = res1812_1572;
						   }
						   {
						      obj_t aux_1931;
						      object_t aux_1929;
						      aux_1931 = (obj_t) (arg1628_1068);
						      aux_1929 = (object_t) (obj1572_1067);
						      OBJECT_WIDENING_SET(aux_1929, aux_1931);
						   }
						}
						{
						   long arg1630_1069;
						   arg1630_1069 = class_num_218___object(local_ginfo_108_globalize_ginfo);
						   {
						      obj_t obj_1573;
						      obj_1573 = (obj_t) (obj1572_1067);
						      (((obj_t) CREF(obj_1573))->header = MAKE_HEADER(arg1630_1069, 0), BUNSPEC);
						   }
						}
						obj1572_1067;
					     }
					     arg1621_1058 = new_1061;
					  }
				       }
				       {
					  obj_t aux_1937;
					  aux_1937 = (obj_t) (arg1621_1058);
					  newtail1570_1056 = MAKE_PAIR(aux_1937, BNIL);
				       }
				    }
				    SET_CDR(tail1569_1053, newtail1570_1056);
				    {
				       obj_t tail1569_1943;
				       obj_t l1566_1941;
				       l1566_1941 = CDR(l1566_1052);
				       tail1569_1943 = newtail1570_1056;
				       tail1569_1053 = tail1569_1943;
				       l1566_1052 = l1566_1941;
				       goto lname1567_1054;
				    }
				 }
			    }
			 }
		    }
		    {
		       obj_t loc_1012;
		       {
			  bool_t test1616_1048;
			  test1616_1048 = is_a__118___object((obj_t) (old_fun_147_1009), sfun_ast_var);
			  if (test1616_1048)
			    {
			       sfun_t obj_1581;
			       obj_1581 = (sfun_t) (old_fun_147_1009);
			       loc_1012 = (((sfun_t) CREF(obj_1581))->loc);
			    }
			  else
			    {
			       loc_1012 = BUNSPEC;
			    }
		       }
		       {
			  obj_t gloclo_1013;
			  gloclo_1013 = gloclo_globalize_global_closure_246(global_3, env_1010, new_args_235_1011);
			  {
			     value_t new_fun_115_1014;
			     {
				global_t obj_1582;
				obj_1582 = (global_t) (gloclo_1013);
				new_fun_115_1014 = (((global_t) CREF(obj_1582))->value);
			     }
			     {
				{
				   svar_ginfo_131_t obj1573_1015;
				   obj1573_1015 = ((svar_ginfo_131_t) ((((local_t) CREF(env_1010))->value)));
				   {
				      svar_ginfo_131_t arg1584_1016;
				      {
					 svar_ginfo_131_t res1813_1593;
					 {
					    svar_ginfo_131_t new1500_1588;
					    new1500_1588 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
					    ((((svar_ginfo_131_t) CREF(new1500_1588))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					    ((((svar_ginfo_131_t) CREF(new1500_1588))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
					    ((((svar_ginfo_131_t) CREF(new1500_1588))->mark) = ((long) ((long) -10)), BUNSPEC);
					    ((((svar_ginfo_131_t) CREF(new1500_1588))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					    res1813_1593 = new1500_1588;
					 }
					 arg1584_1016 = res1813_1593;
				      }
				      {
					 obj_t aux_1961;
					 object_t aux_1959;
					 aux_1961 = (obj_t) (arg1584_1016);
					 aux_1959 = (object_t) (obj1573_1015);
					 OBJECT_WIDENING_SET(aux_1959, aux_1961);
				      }
				   }
				   {
				      long arg1585_1017;
				      arg1585_1017 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
				      {
					 obj_t obj_1594;
					 obj_1594 = (obj_t) (obj1573_1015);
					 (((obj_t) CREF(obj_1594))->header = MAKE_HEADER(arg1585_1017, 0), BUNSPEC);
				      }
				   }
				   obj1573_1015;
				}
				{
				   global_ginfo_75_t obj1574_1018;
				   obj1574_1018 = ((global_ginfo_75_t) (gloclo_1013));
				   {
				      global_ginfo_75_t arg1586_1019;
				      {
					 global_ginfo_75_t res1814_1601;
					 {
					    obj_t global_closure_229_1597;
					    global_closure_229_1597 = BFALSE;
					    {
					       global_ginfo_75_t new1544_1598;
					       new1544_1598 = ((global_ginfo_75_t) BREF(GC_MALLOC(sizeof(struct global_ginfo_75))));
					       ((((global_ginfo_75_t) CREF(new1544_1598))->escape__117) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					       ((((global_ginfo_75_t) CREF(new1544_1598))->global_closure_229) = ((obj_t) global_closure_229_1597), BUNSPEC);
					       res1814_1601 = new1544_1598;
					    }
					 }
					 arg1586_1019 = res1814_1601;
				      }
				      {
					 obj_t aux_1973;
					 object_t aux_1971;
					 aux_1973 = (obj_t) (arg1586_1019);
					 aux_1971 = (object_t) (obj1574_1018);
					 OBJECT_WIDENING_SET(aux_1971, aux_1973);
				      }
				   }
				   {
				      long arg1588_1021;
				      arg1588_1021 = class_num_218___object(global_ginfo_75_globalize_ginfo);
				      {
					 obj_t obj_1602;
					 obj_1602 = (obj_t) (obj1574_1018);
					 (((obj_t) CREF(obj_1602))->header = MAKE_HEADER(arg1588_1021, 0), BUNSPEC);
				      }
				   }
				   obj1574_1018;
				}
				{
				   app_t arg1589_1022;
				   {
				      obj_t arg1593_1024;
				      var_t arg1595_1026;
				      obj_t arg1598_1027;
				      arg1593_1024 = _obj__252_type_cache;
				      {
					 obj_t arg1602_1029;
					 arg1602_1029 = ____74_type_cache;
					 {
					    var_t res1815_1614;
					    {
					       type_t type_1605;
					       variable_t variable_1606;
					       type_1605 = (type_t) (arg1602_1029);
					       variable_1606 = (variable_t) (global_3);
					       {
						  var_t new1211_1607;
						  new1211_1607 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						  {
						     long arg1772_1608;
						     arg1772_1608 = class_num_218___object(var_ast_node);
						     {
							obj_t obj_1612;
							obj_1612 = (obj_t) (new1211_1607);
							(((obj_t) CREF(obj_1612))->header = MAKE_HEADER(arg1772_1608, 0), BUNSPEC);
						     }
						  }
						  {
						     object_t aux_1985;
						     aux_1985 = (object_t) (new1211_1607);
						     OBJECT_WIDENING_SET(aux_1985, BFALSE);
						  }
						  ((((var_t) CREF(new1211_1607))->loc) = ((obj_t) loc_1012), BUNSPEC);
						  ((((var_t) CREF(new1211_1607))->type) = ((type_t) type_1605), BUNSPEC);
						  ((((var_t) CREF(new1211_1607))->variable) = ((variable_t) variable_1606), BUNSPEC);
						  res1815_1614 = new1211_1607;
					       }
					    }
					    arg1595_1026 = res1815_1614;
					 }
				      }
				      if (NULLP(new_args_235_1011))
					{
					   arg1598_1027 = BNIL;
					}
				      else
					{
					   obj_t head1579_1033;
					   head1579_1033 = MAKE_PAIR(BNIL, BNIL);
					   {
					      obj_t l1577_1034;
					      obj_t tail1580_1035;
					      l1577_1034 = new_args_235_1011;
					      tail1580_1035 = head1579_1033;
					    lname1578_1036:
					      if (NULLP(l1577_1034))
						{
						   arg1598_1027 = CDR(head1579_1033);
						}
					      else
						{
						   obj_t newtail1581_1038;
						   {
						      var_t arg1607_1040;
						      {
							 obj_t arg1610_1044;
							 arg1610_1044 = _obj__252_type_cache;
							 {
							    var_t res1816_1631;
							    {
							       type_t type_1622;
							       variable_t variable_1623;
							       type_1622 = (type_t) (arg1610_1044);
							       {
								  obj_t aux_1998;
								  aux_1998 = CAR(l1577_1034);
								  variable_1623 = (variable_t) (aux_1998);
							       }
							       {
								  var_t new1211_1624;
								  new1211_1624 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								  {
								     long arg1772_1625;
								     arg1772_1625 = class_num_218___object(var_ast_node);
								     {
									obj_t obj_1629;
									obj_1629 = (obj_t) (new1211_1624);
									(((obj_t) CREF(obj_1629))->header = MAKE_HEADER(arg1772_1625, 0), BUNSPEC);
								     }
								  }
								  {
								     object_t aux_2005;
								     aux_2005 = (object_t) (new1211_1624);
								     OBJECT_WIDENING_SET(aux_2005, BFALSE);
								  }
								  ((((var_t) CREF(new1211_1624))->loc) = ((obj_t) loc_1012), BUNSPEC);
								  ((((var_t) CREF(new1211_1624))->type) = ((type_t) type_1622), BUNSPEC);
								  ((((var_t) CREF(new1211_1624))->variable) = ((variable_t) variable_1623), BUNSPEC);
								  res1816_1631 = new1211_1624;
							       }
							    }
							    arg1607_1040 = res1816_1631;
							 }
						      }
						      {
							 obj_t aux_2011;
							 aux_2011 = (obj_t) (arg1607_1040);
							 newtail1581_1038 = MAKE_PAIR(aux_2011, BNIL);
						      }
						   }
						   SET_CDR(tail1580_1035, newtail1581_1038);
						   {
						      obj_t tail1580_2017;
						      obj_t l1577_2015;
						      l1577_2015 = CDR(l1577_1034);
						      tail1580_2017 = newtail1581_1038;
						      tail1580_1035 = tail1580_2017;
						      l1577_1034 = l1577_2015;
						      goto lname1578_1036;
						   }
						}
					   }
					}
				      {
					 app_t res1817_1655;
					 {
					    type_t type_1638;
					    obj_t key_1640;
					    type_1638 = (type_t) (arg1593_1024);
					    key_1640 = BINT(((long) -1));
					    {
					       app_t new1245_1644;
					       new1245_1644 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
					       {
						  long arg1762_1645;
						  arg1762_1645 = class_num_218___object(app_ast_node);
						  {
						     obj_t obj_1653;
						     obj_1653 = (obj_t) (new1245_1644);
						     (((obj_t) CREF(obj_1653))->header = MAKE_HEADER(arg1762_1645, 0), BUNSPEC);
						  }
					       }
					       {
						  object_t aux_2024;
						  aux_2024 = (object_t) (new1245_1644);
						  OBJECT_WIDENING_SET(aux_2024, BFALSE);
					       }
					       ((((app_t) CREF(new1245_1644))->loc) = ((obj_t) loc_1012), BUNSPEC);
					       ((((app_t) CREF(new1245_1644))->type) = ((type_t) type_1638), BUNSPEC);
					       ((((app_t) CREF(new1245_1644))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
					       ((((app_t) CREF(new1245_1644))->key) = ((obj_t) key_1640), BUNSPEC);
					       ((((app_t) CREF(new1245_1644))->fun) = ((var_t) arg1595_1026), BUNSPEC);
					       ((((app_t) CREF(new1245_1644))->args) = ((obj_t) arg1598_1027), BUNSPEC);
					       ((((app_t) CREF(new1245_1644))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
					       res1817_1655 = new1245_1644;
					    }
					 }
					 arg1589_1022 = res1817_1655;
				      }
				   }
				   {
				      sfun_t obj_1656;
				      obj_t val1140_1657;
				      obj_1656 = (sfun_t) (new_fun_115_1014);
				      val1140_1657 = (obj_t) (arg1589_1022);
				      ((((sfun_t) CREF(obj_1656))->body) = ((obj_t) val1140_1657), BUNSPEC);
				   }
				}
				return (global_t) (gloclo_1013);
			     }
			  }
		       }
		    }
		 }
	      }
	   }
      }
   }
}


/* _make-global-closure1819 */ obj_t 
_make_global_closure1819_11_globalize_global_closure_246(obj_t env_1814, obj_t global_1815)
{
   {
      global_t aux_2038;
      aux_2038 = make_global_closure_44_globalize_global_closure_246((global_t) (global_1815));
      return (obj_t) (aux_2038);
   }
}


/* foreign-closures */ obj_t 
foreign_closures_19_globalize_global_closure_246()
{
   {
      obj_t res_1081;
      res_1081 = _foreign_closures__211_globalize_global_closure_246;
      _foreign_closures__211_globalize_global_closure_246 = BNIL;
      return res_1081;
   }
}


/* _foreign-closures */ obj_t 
_foreign_closures_249_globalize_global_closure_246(obj_t env_1816)
{
   return foreign_closures_19_globalize_global_closure_246();
}


/* gloclo */ obj_t 
gloclo_globalize_global_closure_246(global_t global_4, local_t env_5, obj_t args_6)
{
   {
      long arity_1082;
      {
	 fun_t obj_1659;
	 {
	    value_t aux_2043;
	    aux_2043 = (((global_t) CREF(global_4))->value);
	    obj_1659 = (fun_t) (aux_2043);
	 }
	 arity_1082 = (((fun_t) CREF(obj_1659))->arity);
      }
      {
	 obj_t id_1083;
	 {
	    obj_t str_1116;
	    {
	       obj_t arg1697_1130;
	       {
		  obj_t aux_2047;
		  aux_2047 = (((global_t) CREF(global_4))->id);
		  arg1697_1130 = SYMBOL_TO_STRING(aux_2047);
	       }
	       str_1116 = string_append(string1822_globalize_global_closure_246, arg1697_1130);
	    }
	    {
	       bool_t test1681_1117;
	       {
		  char *aux_2051;
		  aux_2051 = BSTRING_TO_STRING(str_1116);
		  test1681_1117 = symbol_exists_p(aux_2051);
	       }
	       if (test1681_1117)
		 {
		    obj_t arg1682_1118;
		    {
		       obj_t arg1683_1119;
		       arg1683_1119 = CNST_TABLE_REF(((long) 1));
		       {
			  obj_t list1685_1121;
			  {
			     obj_t arg1686_1122;
			     {
				obj_t aux_2056;
				aux_2056 = (((global_t) CREF(global_4))->id);
				arg1686_1122 = MAKE_PAIR(aux_2056, BNIL);
			     }
			     list1685_1121 = MAKE_PAIR(arg1683_1119, arg1686_1122);
			  }
			  arg1682_1118 = symbol_append_197___r4_symbols_6_4(list1685_1121);
		       }
		    }
		    id_1083 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, arg1682_1118, BEOA);
		 }
	       else
		 {
		    obj_t arg1689_1124;
		    arg1689_1124 = CNST_TABLE_REF(((long) 1));
		    {
		       obj_t list1692_1126;
		       {
			  obj_t arg1693_1127;
			  {
			     obj_t aux_2064;
			     aux_2064 = (((global_t) CREF(global_4))->id);
			     arg1693_1127 = MAKE_PAIR(aux_2064, BNIL);
			  }
			  list1692_1126 = MAKE_PAIR(arg1689_1124, arg1693_1127);
		       }
		       id_1083 = symbol_append_197___r4_symbols_6_4(list1692_1126);
		    }
		 }
	    }
	 }
	 {
	    global_t gloclo_1084;
	    {
	       obj_t arg1663_1101;
	       obj_t arg1665_1102;
	       obj_t arg1666_1103;
	       obj_t arg1667_1104;
	       obj_t arg1668_1105;
	       obj_t arg1669_1106;
	       obj_t arg1670_1107;
	       {
		  obj_t list1673_1109;
		  {
		     obj_t arg1675_1110;
		     {
			obj_t aux_2069;
			aux_2069 = CNST_TABLE_REF(((long) 2));
			arg1675_1110 = MAKE_PAIR(aux_2069, BNIL);
		     }
		     list1673_1109 = MAKE_PAIR(id_1083, arg1675_1110);
		  }
		  arg1663_1101 = symbol_append_197___r4_symbols_6_4(list1673_1109);
	       }
	       {
		  obj_t arg1677_1112;
		  arg1677_1112 = __arity_132_tools_args(BINT(arity_1082), BINT(((long) 1)));
		  arg1665_1102 = make_n_proto_123_tools_args(arg1677_1112);
	       }
	       {
		  obj_t aux_2078;
		  aux_2078 = (obj_t) (env_5);
		  arg1666_1103 = MAKE_PAIR(aux_2078, args_6);
	       }
	       {
		  bool_t test_2081;
		  {
		     obj_t aux_2084;
		     obj_t aux_2082;
		     aux_2084 = CNST_TABLE_REF(((long) 3));
		     aux_2082 = (((global_t) CREF(global_4))->import);
		     test_2081 = (aux_2082 == aux_2084);
		  }
		  if (test_2081)
		    {
		       arg1667_1104 = _module__166_module_module;
		    }
		  else
		    {
		       arg1667_1104 = (((global_t) CREF(global_4))->module);
		    }
	       }
	       arg1668_1105 = (((global_t) CREF(global_4))->import);
	       arg1669_1106 = CNST_TABLE_REF(((long) 4));
	       arg1670_1107 = CNST_TABLE_REF(((long) 5));
	       gloclo_1084 = def_global_sfun__93_ast_glo_def_117(arg1663_1101, arg1665_1102, arg1666_1103, arg1667_1104, arg1668_1105, arg1669_1106, arg1670_1107, BUNSPEC);
	    }
	    {
	       {
		  global_ginfo_75_t obj_1671;
		  obj_t val1563_1672;
		  obj_1671 = (global_ginfo_75_t) (global_4);
		  val1563_1672 = (obj_t) (gloclo_1084);
		  {
		     obj_t aux_2094;
		     {
			object_t aux_2095;
			aux_2095 = (object_t) (obj_1671);
			aux_2094 = OBJECT_WIDENING(aux_2095);
		     }
		     ((((global_ginfo_75_t) CREF(aux_2094))->global_closure_229) = ((obj_t) val1563_1672), BUNSPEC);
		  }
	       }
	       {
		  sfun_t obj_1675;
		  obj_t val1143_1676;
		  {
		     value_t aux_2099;
		     aux_2099 = (((global_t) CREF(gloclo_1084))->value);
		     obj_1675 = (sfun_t) (aux_2099);
		  }
		  {
		     value_t aux_2102;
		     aux_2102 = (((global_t) CREF(global_4))->value);
		     val1143_1676 = (obj_t) (aux_2102);
		  }
		  ((((sfun_t) CREF(obj_1675))->loc) = ((obj_t) val1143_1676), BUNSPEC);
	       }
	       {
		  bool_t test_2106;
		  {
		     obj_t aux_2109;
		     obj_t aux_2107;
		     aux_2109 = CNST_TABLE_REF(((long) 3));
		     aux_2107 = (((global_t) CREF(global_4))->import);
		     test_2106 = (aux_2107 == aux_2109);
		  }
		  if (test_2106)
		    {
		       {
			  obj_t obj2_1681;
			  obj2_1681 = _foreign_closures__211_globalize_global_closure_246;
			  {
			     obj_t aux_2112;
			     aux_2112 = (obj_t) (gloclo_1084);
			     _foreign_closures__211_globalize_global_closure_246 = MAKE_PAIR(aux_2112, obj2_1681);
			  }
		       }
		       {
			  obj_t arg1648_1088;
			  arg1648_1088 = CNST_TABLE_REF(((long) 6));
			  ((((global_t) CREF(gloclo_1084))->removable) = ((obj_t) arg1648_1088), BUNSPEC);
		       }
		       {
			  obj_t arg1649_1089;
			  arg1649_1089 = CNST_TABLE_REF(((long) 7));
			  ((((global_t) CREF(gloclo_1084))->import) = ((obj_t) arg1649_1089), BUNSPEC);
		       }
		    }
		  else
		    {
		       {
			  bool_t test_2119;
			  {
			     obj_t aux_2122;
			     obj_t aux_2120;
			     aux_2122 = CNST_TABLE_REF(((long) 7));
			     aux_2120 = (((global_t) CREF(global_4))->import);
			     test_2119 = (aux_2120 == aux_2122);
			  }
			  if (test_2119)
			    {
			       BUNSPEC;
			    }
			  else
			    {
			       obj_t arg1652_1091;
			       arg1652_1091 = CNST_TABLE_REF(((long) 6));
			       ((((global_t) CREF(gloclo_1084))->removable) = ((obj_t) arg1652_1091), BUNSPEC);
			    }
		       }
		       {
			  obj_t arg1655_1094;
			  arg1655_1094 = CNST_TABLE_REF(((long) 7));
			  ((((global_t) CREF(gloclo_1084))->import) = ((obj_t) arg1655_1094), BUNSPEC);
		       }
		    }
	       }
	       {
		  obj_t arg1659_1098;
		  {
		     fun_t obj_1695;
		     {
			value_t aux_2129;
			aux_2129 = (((global_t) CREF(global_4))->value);
			obj_1695 = (fun_t) (aux_2129);
		     }
		     arg1659_1098 = (((fun_t) CREF(obj_1695))->side_effect__165);
		  }
		  {
		     fun_t obj_1696;
		     {
			value_t aux_2133;
			aux_2133 = (((global_t) CREF(gloclo_1084))->value);
			obj_1696 = (fun_t) (aux_2133);
		     }
		     ((((fun_t) CREF(obj_1696))->side_effect__165) = ((obj_t) arg1659_1098), BUNSPEC);
		  }
	       }
	       {
		  bool_t test1662_1100;
		  test1662_1100 = is_a__118___object((obj_t) (gloclo_1084), global_ast_var);
		  if (test1662_1100)
		    {
		       return (obj_t) (gloclo_1084);
		    }
		  else
		    {
		       return internal_error_43_tools_error(string1823_globalize_global_closure_246, string1824_globalize_global_closure_246, (obj_t) (gloclo_1084));
		    }
	       }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_globalize_global_closure_246()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_global_closure_246()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_tools_args(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_tools_error(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_engine_param(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_type_cache(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_ast_sexp(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_ast_local(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_ast_glo_def_117(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_module_module(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   module_initialization_70_globalize_node(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
   return module_initialization_70_globalize_free(((long) 0), "GLOBALIZE_GLOBAL-CLOSURE");
}
