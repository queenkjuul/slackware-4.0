/*===========================================================================*/
/*   (Integrate/ctn.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_ctn();
extern obj_t global_ast_var;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_ctn(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_a(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t imported_modules_init_94_integrate_ctn();
static obj_t library_modules_init_112_integrate_ctn();
extern obj_t open_input_string(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cn_ct__54_integrate_ctn(obj_t);
static obj_t require_initialization_114_integrate_ctn = BUNSPEC;
static obj_t cnst_init_137_integrate_ctn();
static obj_t _cn_ct__5_integrate_ctn(obj_t, obj_t);
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(cn_ct__env_19_integrate_ctn, _cn_ct__5_integrate_ctn1677, _cn_ct__5_integrate_ctn, 0L, 1);
DEFINE_STRING(string1669_integrate_ctn, string1669_integrate_ctn1678, "ESCAPE TAIL ", 12);


/* module-initialization */ obj_t 
module_initialization_70_integrate_ctn(long checksum_1427, char *from_1428)
{
   if (CBOOL(require_initialization_114_integrate_ctn))
     {
	require_initialization_114_integrate_ctn = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_ctn();
	cnst_init_137_integrate_ctn();
	imported_modules_init_94_integrate_ctn();
	method_init_76_integrate_ctn();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_ctn()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_CTN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_CTN");
   module_initialization_70___reader(((long) 0), "INTEGRATE_CTN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_ctn()
{
   {
      obj_t cnst_port_138_1419;
      cnst_port_138_1419 = open_input_string(string1669_integrate_ctn);
      {
	 long i_1420;
	 i_1420 = ((long) 1);
       loop_1421:
	 {
	    bool_t test1670_1422;
	    test1670_1422 = (i_1420 == ((long) -1));
	    if (test1670_1422)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1672_1423;
		    {
		       obj_t list1673_1424;
		       {
			  obj_t arg1675_1425;
			  arg1675_1425 = BNIL;
			  list1673_1424 = MAKE_PAIR(cnst_port_138_1419, arg1675_1425);
		       }
		       arg1672_1423 = read___reader(list1673_1424);
		    }
		    CNST_TABLE_SET(i_1420, arg1672_1423);
		 }
		 {
		    int aux_1426;
		    {
		       long aux_1445;
		       aux_1445 = (i_1420 - ((long) 1));
		       aux_1426 = (int) (aux_1445);
		    }
		    {
		       long i_1448;
		       i_1448 = (long) (aux_1426);
		       i_1420 = i_1448;
		       goto loop_1421;
		    }
		 }
	      }
	 }
      }
   }
}


/* cn&ct! */ obj_t 
cn_ct__54_integrate_ctn(obj_t a_1)
{
   {
      obj_t as_879;
      obj_t g_cn_224_880;
      as_879 = a_1;
      g_cn_224_880 = BNIL;
    loop_881:
      if (NULLP(as_879))
	{
	   return g_cn_224_880;
	}
      else
	{
	   obj_t a_884;
	   a_884 = CAR(as_879);
	   {
	      obj_t f_885;
	      f_885 = CAR(a_884);
	      {
		 obj_t g_886;
		 {
		    obj_t aux_1454;
		    aux_1454 = CDR(a_884);
		    g_886 = CAR(aux_1454);
		 }
		 {
		    obj_t k_887;
		    {
		       obj_t aux_1457;
		       {
			  obj_t aux_1458;
			  aux_1458 = CDR(a_884);
			  aux_1457 = CDR(aux_1458);
		       }
		       k_887 = CAR(aux_1457);
		    }
		    {
		       value_t fi_888;
		       {
			  variable_t obj_1308;
			  obj_1308 = (variable_t) (f_885);
			  fi_888 = (((variable_t) CREF(obj_1308))->value);
		       }
		       {
			  value_t gi_889;
			  {
			     variable_t obj_1309;
			     obj_1309 = (variable_t) (g_886);
			     gi_889 = (((variable_t) CREF(obj_1309))->value);
			  }
			  {
			     {
				bool_t test1519_890;
				test1519_890 = is_a__118___object(g_886, global_ast_var);
				if (test1519_890)
				  {
				     {
					obj_t as_1468;
					as_1468 = CDR(as_879);
					as_879 = as_1468;
					goto loop_881;
				     }
				  }
				else
				  {
				     bool_t test_1470;
				     {
					obj_t aux_1471;
					aux_1471 = CNST_TABLE_REF(((long) 0));
					test_1470 = (k_887 == aux_1471);
				     }
				     if (test_1470)
				       {
					  {
					     obj_t arg1524_893;
					     {
						obj_t aux_1474;
						{
						   sfun_iinfo_105_t obj_1314;
						   obj_1314 = (sfun_iinfo_105_t) (fi_888);
						   {
						      obj_t aux_1476;
						      {
							 object_t aux_1477;
							 aux_1477 = (object_t) (obj_1314);
							 aux_1476 = OBJECT_WIDENING(aux_1477);
						      }
						      aux_1474 = (((sfun_iinfo_105_t) CREF(aux_1476))->ct);
						   }
						}
						arg1524_893 = MAKE_PAIR(g_886, aux_1474);
					     }
					     {
						sfun_iinfo_105_t obj_1317;
						obj_1317 = (sfun_iinfo_105_t) (fi_888);
						{
						   obj_t aux_1483;
						   {
						      object_t aux_1484;
						      aux_1484 = (object_t) (obj_1317);
						      aux_1483 = OBJECT_WIDENING(aux_1484);
						   }
						   ((((sfun_iinfo_105_t) CREF(aux_1483))->ct) = ((obj_t) arg1524_893), BUNSPEC);
						}
					     }
					  }
					  {
					     bool_t test_1488;
					     if ((f_885 == g_886))
					       {
						  test_1488 = ((bool_t) 0);
					       }
					     else
					       {
						  bool_t test_1491;
						  {
						     obj_t aux_1492;
						     {
							obj_t aux_1493;
							{
							   sfun_iinfo_105_t obj_1321;
							   obj_1321 = (sfun_iinfo_105_t) (fi_888);
							   {
							      obj_t aux_1495;
							      {
								 object_t aux_1496;
								 aux_1496 = (object_t) (obj_1321);
								 aux_1495 = OBJECT_WIDENING(aux_1496);
							      }
							      aux_1493 = (((sfun_iinfo_105_t) CREF(aux_1495))->kont);
							   }
							}
							aux_1492 = memq___r4_pairs_and_lists_6_3(g_886, aux_1493);
						     }
						     test_1491 = CBOOL(aux_1492);
						  }
						  if (test_1491)
						    {
						       test_1488 = ((bool_t) 0);
						    }
						  else
						    {
						       test_1488 = ((bool_t) 1);
						    }
					       }
					     if (test_1488)
					       {
						  obj_t arg1527_896;
						  {
						     obj_t aux_1502;
						     {
							sfun_iinfo_105_t obj_1322;
							obj_1322 = (sfun_iinfo_105_t) (fi_888);
							{
							   obj_t aux_1504;
							   {
							      object_t aux_1505;
							      aux_1505 = (object_t) (obj_1322);
							      aux_1504 = OBJECT_WIDENING(aux_1505);
							   }
							   aux_1502 = (((sfun_iinfo_105_t) CREF(aux_1504))->kont);
							}
						     }
						     arg1527_896 = MAKE_PAIR(g_886, aux_1502);
						  }
						  {
						     sfun_iinfo_105_t obj_1325;
						     obj_1325 = (sfun_iinfo_105_t) (fi_888);
						     {
							obj_t aux_1511;
							{
							   object_t aux_1512;
							   aux_1512 = (object_t) (obj_1325);
							   aux_1511 = OBJECT_WIDENING(aux_1512);
							}
							((((sfun_iinfo_105_t) CREF(aux_1511))->kont) = ((obj_t) arg1527_896), BUNSPEC);
						     }
						  }
					       }
					     else
					       {
						  BUNSPEC;
					       }
					  }
					  {
					     obj_t as_1516;
					     as_1516 = CDR(as_879);
					     as_879 = as_1516;
					     goto loop_881;
					  }
				       }
				     else
				       {
					  bool_t test_1518;
					  {
					     obj_t aux_1519;
					     aux_1519 = CNST_TABLE_REF(((long) 1));
					     test_1518 = (k_887 == aux_1519);
					  }
					  if (test_1518)
					    {
					       {
						  bool_t test_1522;
						  {
						     obj_t aux_1523;
						     {
							obj_t aux_1524;
							{
							   sfun_iinfo_105_t obj_1330;
							   obj_1330 = (sfun_iinfo_105_t) (fi_888);
							   {
							      obj_t aux_1526;
							      {
								 object_t aux_1527;
								 aux_1527 = (object_t) (obj_1330);
								 aux_1526 = OBJECT_WIDENING(aux_1527);
							      }
							      aux_1524 = (((sfun_iinfo_105_t) CREF(aux_1526))->kont);
							   }
							}
							aux_1523 = memq___r4_pairs_and_lists_6_3(g_886, aux_1524);
						     }
						     test_1522 = CBOOL(aux_1523);
						  }
						  if (test_1522)
						    {
						       BUNSPEC;
						    }
						  else
						    {
						       obj_t arg1535_904;
						       {
							  obj_t aux_1533;
							  {
							     sfun_iinfo_105_t obj_1331;
							     obj_1331 = (sfun_iinfo_105_t) (fi_888);
							     {
								obj_t aux_1535;
								{
								   object_t aux_1536;
								   aux_1536 = (object_t) (obj_1331);
								   aux_1535 = OBJECT_WIDENING(aux_1536);
								}
								aux_1533 = (((sfun_iinfo_105_t) CREF(aux_1535))->kont);
							     }
							  }
							  arg1535_904 = MAKE_PAIR(g_886, aux_1533);
						       }
						       {
							  sfun_iinfo_105_t obj_1334;
							  obj_1334 = (sfun_iinfo_105_t) (fi_888);
							  {
							     obj_t aux_1542;
							     {
								object_t aux_1543;
								aux_1543 = (object_t) (obj_1334);
								aux_1542 = OBJECT_WIDENING(aux_1543);
							     }
							     ((((sfun_iinfo_105_t) CREF(aux_1542))->kont) = ((obj_t) arg1535_904), BUNSPEC);
							  }
						       }
						    }
					       }
					       {
						  obj_t as_1547;
						  as_1547 = CDR(as_879);
						  as_879 = as_1547;
						  goto loop_881;
					       }
					    }
					  else
					    {
					       bool_t test_1549;
					       {
						  sfun_iinfo_105_t obj_1337;
						  obj_1337 = (sfun_iinfo_105_t) (gi_889);
						  {
						     obj_t aux_1551;
						     {
							obj_t aux_1552;
							{
							   object_t aux_1553;
							   aux_1553 = (object_t) (obj_1337);
							   aux_1552 = OBJECT_WIDENING(aux_1553);
							}
							aux_1551 = (((sfun_iinfo_105_t) CREF(aux_1552))->u);
						     }
						     test_1549 = CBOOL(aux_1551);
						  }
					       }
					       if (test_1549)
						 {
						    {
						       obj_t arg1542_909;
						       {
							  obj_t aux_1558;
							  {
							     sfun_iinfo_105_t obj_1338;
							     obj_1338 = (sfun_iinfo_105_t) (fi_888);
							     {
								obj_t aux_1560;
								{
								   object_t aux_1561;
								   aux_1561 = (object_t) (obj_1338);
								   aux_1560 = OBJECT_WIDENING(aux_1561);
								}
								aux_1558 = (((sfun_iinfo_105_t) CREF(aux_1560))->ct);
							     }
							  }
							  arg1542_909 = MAKE_PAIR(g_886, aux_1558);
						       }
						       {
							  sfun_iinfo_105_t obj_1341;
							  obj_1341 = (sfun_iinfo_105_t) (fi_888);
							  {
							     obj_t aux_1567;
							     {
								object_t aux_1568;
								aux_1568 = (object_t) (obj_1341);
								aux_1567 = OBJECT_WIDENING(aux_1568);
							     }
							     ((((sfun_iinfo_105_t) CREF(aux_1567))->ct) = ((obj_t) arg1542_909), BUNSPEC);
							  }
						       }
						    }
						    {
						       bool_t test_1572;
						       {
							  obj_t aux_1573;
							  {
							     obj_t aux_1574;
							     {
								sfun_iinfo_105_t obj_1343;
								obj_1343 = (sfun_iinfo_105_t) (fi_888);
								{
								   obj_t aux_1576;
								   {
								      object_t aux_1577;
								      aux_1577 = (object_t) (obj_1343);
								      aux_1576 = OBJECT_WIDENING(aux_1577);
								   }
								   aux_1574 = (((sfun_iinfo_105_t) CREF(aux_1576))->kont);
								}
							     }
							     aux_1573 = memq___r4_pairs_and_lists_6_3(g_886, aux_1574);
							  }
							  test_1572 = CBOOL(aux_1573);
						       }
						       if (test_1572)
							 {
							    BUNSPEC;
							 }
						       else
							 {
							    obj_t arg1548_912;
							    {
							       obj_t aux_1583;
							       {
								  sfun_iinfo_105_t obj_1344;
								  obj_1344 = (sfun_iinfo_105_t) (fi_888);
								  {
								     obj_t aux_1585;
								     {
									object_t aux_1586;
									aux_1586 = (object_t) (obj_1344);
									aux_1585 = OBJECT_WIDENING(aux_1586);
								     }
								     aux_1583 = (((sfun_iinfo_105_t) CREF(aux_1585))->kont);
								  }
							       }
							       arg1548_912 = MAKE_PAIR(g_886, aux_1583);
							    }
							    {
							       sfun_iinfo_105_t obj_1347;
							       obj_1347 = (sfun_iinfo_105_t) (fi_888);
							       {
								  obj_t aux_1592;
								  {
								     object_t aux_1593;
								     aux_1593 = (object_t) (obj_1347);
								     aux_1592 = OBJECT_WIDENING(aux_1593);
								  }
								  ((((sfun_iinfo_105_t) CREF(aux_1592))->kont) = ((obj_t) arg1548_912), BUNSPEC);
							       }
							    }
							 }
						    }
						    {
						       obj_t as_1597;
						       as_1597 = CDR(as_879);
						       as_879 = as_1597;
						       goto loop_881;
						    }
						 }
					       else
						 {
						    {
						       obj_t arg1553_916;
						       {
							  obj_t aux_1599;
							  {
							     sfun_iinfo_105_t obj_1350;
							     obj_1350 = (sfun_iinfo_105_t) (fi_888);
							     {
								obj_t aux_1601;
								{
								   object_t aux_1602;
								   aux_1602 = (object_t) (obj_1350);
								   aux_1601 = OBJECT_WIDENING(aux_1602);
								}
								aux_1599 = (((sfun_iinfo_105_t) CREF(aux_1601))->cn);
							     }
							  }
							  arg1553_916 = MAKE_PAIR(g_886, aux_1599);
						       }
						       {
							  sfun_iinfo_105_t obj_1353;
							  obj_1353 = (sfun_iinfo_105_t) (fi_888);
							  {
							     obj_t aux_1608;
							     {
								object_t aux_1609;
								aux_1609 = (object_t) (obj_1353);
								aux_1608 = OBJECT_WIDENING(aux_1609);
							     }
							     ((((sfun_iinfo_105_t) CREF(aux_1608))->cn) = ((obj_t) arg1553_916), BUNSPEC);
							  }
						       }
						    }
						    {
						       bool_t test_1613;
						       {
							  sfun_iinfo_105_t obj_1355;
							  obj_1355 = (sfun_iinfo_105_t) (gi_889);
							  {
							     obj_t aux_1615;
							     {
								object_t aux_1616;
								aux_1616 = (object_t) (obj_1355);
								aux_1615 = OBJECT_WIDENING(aux_1616);
							     }
							     test_1613 = (((sfun_iinfo_105_t) CREF(aux_1615))->g__219);
							  }
						       }
						       if (test_1613)
							 {
							    obj_t as_1620;
							    as_1620 = CDR(as_879);
							    as_879 = as_1620;
							    goto loop_881;
							 }
						       else
							 {
							    {
							       sfun_iinfo_105_t obj_1357;
							       obj_1357 = (sfun_iinfo_105_t) (gi_889);
							       {
								  obj_t aux_1623;
								  {
								     object_t aux_1624;
								     aux_1624 = (object_t) (obj_1357);
								     aux_1623 = OBJECT_WIDENING(aux_1624);
								  }
								  ((((sfun_iinfo_105_t) CREF(aux_1623))->g__219) = ((bool_t) ((bool_t) 1)), BUNSPEC);
							       }
							    }
							    {
							       obj_t arg1557_920;
							       obj_t arg1558_921;
							       arg1557_920 = CDR(as_879);
							       arg1558_921 = MAKE_PAIR(g_886, g_cn_224_880);
							       {
								  obj_t g_cn_224_1631;
								  obj_t as_1630;
								  as_1630 = arg1557_920;
								  g_cn_224_1631 = arg1558_921;
								  g_cn_224_880 = g_cn_224_1631;
								  as_879 = as_1630;
								  goto loop_881;
							       }
							    }
							 }
						    }
						 }
					    }
				       }
				  }
			     }
			  }
		       }
		    }
		 }
	      }
	   }
	}
   }
}


/* _cn&ct! */ obj_t 
_cn_ct__5_integrate_ctn(obj_t env_1417, obj_t a_1418)
{
   return cn_ct__54_integrate_ctn(a_1418);
}


/* method-init */ obj_t 
method_init_76_integrate_ctn()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_ctn()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_CTN");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_CTN");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_CTN");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_CTN");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_CTN");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_CTN");
   return module_initialization_70_integrate_a(((long) 0), "INTEGRATE_CTN");
}
