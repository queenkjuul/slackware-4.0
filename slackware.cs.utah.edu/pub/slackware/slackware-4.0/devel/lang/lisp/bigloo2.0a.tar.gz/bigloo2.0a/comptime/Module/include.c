/*===========================================================================*/
/*   (Module/include.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t ccomp_module_module;
static obj_t include_finalizer_204_module_include();
static obj_t method_init_76_module_include();
static obj_t _get_include_consumed_code_144_module_include(obj_t);
static obj_t _reset_include_consumed_directive__158_module_include(obj_t);
static obj_t _include_producer_224_module_include(obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
static obj_t _toplevel_unit__184_module_include = BUNSPEC;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t include_producer_46_module_include(obj_t);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_read_include(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _consumed_directive__109_module_include = BUNSPEC;
extern obj_t make_include_compiler_73_module_include();
extern long class_num_218___object(obj_t);
static obj_t _include_consumer1227_131_module_include(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_module_include();
extern obj_t reset_include_consumed_code__8_module_include();
extern obj_t get_include_consumed_code_244_module_include();
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_include();
static obj_t toplevel_init_63_module_include();
static obj_t _consumed_code__204_module_include = BUNSPEC;
extern obj_t open_input_string(obj_t);
static obj_t _reset_include_consumed_code__66_module_include(obj_t);
extern obj_t get_include_consumed_directive_80_module_include();
extern obj_t read_include_201_read_include(obj_t);
static obj_t _get_toplevel_unit_weight_116_module_include(obj_t);
static obj_t arg1157_module_include(obj_t, obj_t, obj_t);
static obj_t _get_include_consumed_directive_114_module_include(obj_t);
extern obj_t consume_module_clause__236_module_module(obj_t, obj_t);
static obj_t _produced_code__154_module_include = BUNSPEC;
extern obj_t read___reader(obj_t);
static obj_t _get_toplevel_unit_130_module_include(obj_t);
extern obj_t get_toplevel_unit_weight_75_module_include();
static obj_t _make_include_compiler_160_module_include(obj_t);
static obj_t require_initialization_114_module_include = BUNSPEC;
static obj_t _include_finalizer_245_module_include(obj_t);
extern obj_t get_toplevel_unit_32_module_include();
extern obj_t reset_include_consumed_directive__234_module_include();
static obj_t include_consumer_10_module_include(obj_t, obj_t);
static obj_t cnst_init_137_module_include();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(get_include_consumed_directive_env_134_module_include, _get_include_consumed_directive_114_module_include1237, _get_include_consumed_directive_114_module_include, 0L, 0);
DEFINE_EXPORT_PROCEDURE(get_include_consumed_code_env_212_module_include, _get_include_consumed_code_144_module_include1238, _get_include_consumed_code_144_module_include, 0L, 0);
DEFINE_STATIC_PROCEDURE(include_producer_env_28_module_include, _include_producer_224_module_include1239, _include_producer_224_module_include, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1228_module_include, arg1157_module_include1240, arg1157_module_include, 0L, 2);
DEFINE_EXPORT_PROCEDURE(get_toplevel_unit_weight_env_163_module_include, _get_toplevel_unit_weight_116_module_include1241, _get_toplevel_unit_weight_116_module_include, 0L, 0);
DEFINE_EXPORT_PROCEDURE(reset_include_consumed_directive__env_144_module_include, _reset_include_consumed_directive__158_module_include1242, _reset_include_consumed_directive__158_module_include, 0L, 0);
DEFINE_EXPORT_PROCEDURE(get_toplevel_unit_env_250_module_include, _get_toplevel_unit_130_module_include1243, _get_toplevel_unit_130_module_include, 0L, 0);
DEFINE_STATIC_PROCEDURE(include_finalizer_env_236_module_include, _include_finalizer_245_module_include1244, _include_finalizer_245_module_include, 0L, 0);
DEFINE_EXPORT_PROCEDURE(reset_include_consumed_code__env_130_module_include, _reset_include_consumed_code__66_module_include1245, _reset_include_consumed_code__66_module_include, 0L, 0);
DEFINE_STATIC_PROCEDURE(include_consumer_env_71_module_include, _include_consumer1227_131_module_include1246, _include_consumer1227_131_module_include, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_include_compiler_env_83_module_include, _make_include_compiler_160_module_include1247, _make_include_compiler_160_module_include, 0L, 0);
DEFINE_STRING(string1231_module_include, string1231_module_include1248, "UNIT TOPLEVEL INCLUDE ", 22);
DEFINE_STRING(string1229_module_include, string1229_module_include1249, "Parse error", 11);
DEFINE_STRING(string1230_module_include, string1230_module_include1250, "Illegal `include' clause", 24);


/* module-initialization */ obj_t 
module_initialization_70_module_include(long checksum_264, char *from_265)
{
   if (CBOOL(require_initialization_114_module_include))
     {
	require_initialization_114_module_include = BBOOL(((bool_t) 0));
	library_modules_init_112_module_include();
	cnst_init_137_module_include();
	imported_modules_init_94_module_include();
	method_init_76_module_include();
	toplevel_init_63_module_include();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_include()
{
   module_initialization_70___object(((long) 0), "MODULE_INCLUDE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_INCLUDE");
   module_initialization_70___reader(((long) 0), "MODULE_INCLUDE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_include()
{
   {
      obj_t cnst_port_138_256;
      cnst_port_138_256 = open_input_string(string1231_module_include);
      {
	 long i_257;
	 i_257 = ((long) 2);
       loop_258:
	 {
	    bool_t test1232_259;
	    test1232_259 = (i_257 == ((long) -1));
	    if (test1232_259)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1233_260;
		    {
		       obj_t list1234_261;
		       {
			  obj_t arg1235_262;
			  arg1235_262 = BNIL;
			  list1234_261 = MAKE_PAIR(cnst_port_138_256, arg1235_262);
		       }
		       arg1233_260 = read___reader(list1234_261);
		    }
		    CNST_TABLE_SET(i_257, arg1233_260);
		 }
		 {
		    int aux_263;
		    {
		       long aux_283;
		       aux_283 = (i_257 - ((long) 1));
		       aux_263 = (int) (aux_283);
		    }
		    {
		       long i_286;
		       i_286 = (long) (aux_263);
		       i_257 = i_286;
		       goto loop_258;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_include()
{
   _produced_code__154_module_include = BNIL;
   _consumed_directive__109_module_include = BNIL;
   _consumed_code__204_module_include = BNIL;
   return (_toplevel_unit__184_module_include = BFALSE,
      BUNSPEC);
}


/* make-include-compiler */ obj_t 
make_include_compiler_73_module_include()
{
   {
      obj_t arg1142_50;
      arg1142_50 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1157_238;
	 arg1157_238 = proc1228_module_include;
	 {
	    ccomp_t res1226_175;
	    {
	       ccomp_t new1002_166;
	       new1002_166 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1224_167;
		  arg1224_167 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_173;
		     obj_173 = (obj_t) (new1002_166);
		     (((obj_t) CREF(obj_173))->header = MAKE_HEADER(arg1224_167, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_293;
		  aux_293 = (object_t) (new1002_166);
		  OBJECT_WIDENING_SET(aux_293, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_166))->id) = ((obj_t) arg1142_50), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_166))->producer) = ((obj_t) include_producer_env_28_module_include), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_166))->consumer) = ((obj_t) include_consumer_env_71_module_include), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_166))->finalizer) = ((obj_t) include_finalizer_env_236_module_include), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_166))->checksummer) = ((obj_t) arg1157_238), BUNSPEC);
	       res1226_175 = new1002_166;
	    }
	    return (obj_t) (res1226_175);
	 }
      }
   }
}


/* _make-include-compiler */ obj_t 
_make_include_compiler_160_module_include(obj_t env_239)
{
   return make_include_compiler_73_module_include();
}


/* arg1157 */ obj_t 
arg1157_module_include(obj_t env_240, obj_t m_241, obj_t c_242)
{
   {
      obj_t m_55;
      obj_t c_56;
      m_55 = m_241;
      c_56 = c_242;
      return c_56;
   }
}


/* include-producer */ obj_t 
include_producer_46_module_include(obj_t clause_19)
{
   {
      {
	 obj_t files_60;
	 files_60 = CDR(clause_19);
       loop_61:
	 if (NULLP(files_60))
	   {
	      return BNIL;
	   }
	 else
	   {
	      if (PAIRP(files_60))
		{
		   {
		      obj_t file_65;
		      file_65 = CAR(files_60);
		      if (STRINGP(file_65))
			{
			   obj_t src_67;
			   src_67 = read_include_201_read_include(file_65);
			   {
			      obj_t directive_68;
			      directive_68 = CAR(src_67);
			      {
				 obj_t src_code_162_69;
				 src_code_162_69 = reverse__39___r4_pairs_and_lists_6_3(CDR(src_67));
				 {
				    if (PAIRP(directive_68))
				      {
					 obj_t l1011_71;
					 {
					    bool_t aux_316;
					    l1011_71 = CDR(directive_68);
					  lname1012_72:
					    if (PAIRP(l1011_71))
					      {
						 produce_module_clause__172_module_module(CAR(l1011_71));
						 {
						    obj_t l1011_321;
						    l1011_321 = CDR(l1011_71);
						    l1011_71 = l1011_321;
						    goto lname1012_72;
						 }
					      }
					    else
					      {
						 aux_316 = ((bool_t) 1);
					      }
					    BBOOL(aux_316);
					 }
				      }
				    else
				      {
					 BUNSPEC;
				      }
				    _produced_code__154_module_include = append_2_18___r4_pairs_and_lists_6_3(src_code_162_69, _produced_code__154_module_include);
				    {
				       obj_t files_326;
				       files_326 = CDR(files_60);
				       files_60 = files_326;
				       goto loop_61;
				    }
				 }
			      }
			   }
			}
		      else
			{
			 include_error_8_85:
			   {
			      obj_t list1196_83;
			      list1196_83 = MAKE_PAIR(BNIL, BNIL);
			      return user_error_151_tools_error(string1229_module_include, string1230_module_include, clause_19, list1196_83);
			   }
			}
		   }
		}
	      else
		{
		   goto include_error_8_85;
		}
	   }
      }
   }
}


/* _include-producer */ obj_t 
_include_producer_224_module_include(obj_t env_243, obj_t clause_244)
{
   return include_producer_46_module_include(clause_244);
}


/* get-include-consumed-directive */ obj_t 
get_include_consumed_directive_80_module_include()
{
   return _consumed_directive__109_module_include;
}


/* _get-include-consumed-directive */ obj_t 
_get_include_consumed_directive_114_module_include(obj_t env_249)
{
   return get_include_consumed_directive_80_module_include();
}


/* reset-include-consumed-directive! */ obj_t 
reset_include_consumed_directive__234_module_include()
{
   return (_consumed_directive__109_module_include = BNIL,
      BUNSPEC);
}


/* _reset-include-consumed-directive! */ obj_t 
_reset_include_consumed_directive__158_module_include(obj_t env_250)
{
   return reset_include_consumed_directive__234_module_include();
}


/* get-include-consumed-code */ obj_t 
get_include_consumed_code_244_module_include()
{
   return _consumed_code__204_module_include;
}


/* _get-include-consumed-code */ obj_t 
_get_include_consumed_code_144_module_include(obj_t env_251)
{
   return get_include_consumed_code_244_module_include();
}


/* reset-include-consumed-code! */ obj_t 
reset_include_consumed_code__8_module_include()
{
   return (_consumed_code__204_module_include = BNIL,
      BUNSPEC);
}


/* _reset-include-consumed-code! */ obj_t 
_reset_include_consumed_code__66_module_include(obj_t env_252)
{
   return reset_include_consumed_code__8_module_include();
}


/* include-consumer */ obj_t 
include_consumer_10_module_include(obj_t module_20, obj_t clause_21)
{
   {
      {
	 obj_t files_87;
	 files_87 = CDR(clause_21);
	 if (NULLP(files_87))
	   {
	      return BNIL;
	   }
	 else
	   {
	      if (PAIRP(files_87))
		{
		   {
		      obj_t file_92;
		      file_92 = CAR(files_87);
		      if (STRINGP(file_92))
			{
			   obj_t src_94;
			   src_94 = read_include_201_read_include(file_92);
			   {
			      obj_t directive_95;
			      directive_95 = CAR(src_94);
			      {
				 obj_t src_code_162_96;
				 src_code_162_96 = CDR(src_94);
				 {
				    if (PAIRP(directive_95))
				      {
					 obj_t l1013_98;
					 {
					    bool_t aux_348;
					    l1013_98 = CDR(directive_95);
					  lname1014_99:
					    if (PAIRP(l1013_98))
					      {
						 {
						    obj_t arg1206_103;
						    arg1206_103 = consume_module_clause__236_module_module(module_20, CAR(l1013_98));
						    _consumed_directive__109_module_include = append_2_18___r4_pairs_and_lists_6_3(arg1206_103, _consumed_directive__109_module_include);
						 }
						 {
						    obj_t l1013_354;
						    l1013_354 = CDR(l1013_98);
						    l1013_98 = l1013_354;
						    goto lname1014_99;
						 }
					      }
					    else
					      {
						 aux_348 = ((bool_t) 1);
					      }
					    BBOOL(aux_348);
					 }
				      }
				    else
				      {
					 BUNSPEC;
				      }
				    _consumed_code__204_module_include = append_2_18___r4_pairs_and_lists_6_3(src_code_162_96, _consumed_code__204_module_include);
				    return BNIL;
				 }
			      }
			   }
			}
		      else
			{
			 include_error_8_111:
			   {
			      obj_t list1212_109;
			      list1212_109 = MAKE_PAIR(BNIL, BNIL);
			      return user_error_151_tools_error(string1229_module_include, string1230_module_include, clause_21, list1212_109);
			   }
			}
		   }
		}
	      else
		{
		   goto include_error_8_111;
		}
	   }
      }
   }
}


/* _include-consumer1227 */ obj_t 
_include_consumer1227_131_module_include(obj_t env_245, obj_t module_246, obj_t clause_247)
{
   return include_consumer_10_module_include(module_246, clause_247);
}


/* get-toplevel-unit */ obj_t 
get_toplevel_unit_32_module_include()
{
   return _toplevel_unit__184_module_include;
}


/* _get-toplevel-unit */ obj_t 
_get_toplevel_unit_130_module_include(obj_t env_253)
{
   return get_toplevel_unit_32_module_include();
}


/* get-toplevel-unit-weight */ obj_t 
get_toplevel_unit_weight_75_module_include()
{
   return BINT(((long) 100));
}


/* _get-toplevel-unit-weight */ obj_t 
_get_toplevel_unit_weight_116_module_include(obj_t env_254)
{
   return get_toplevel_unit_weight_75_module_include();
}


/* include-finalizer */ obj_t 
include_finalizer_204_module_include()
{
   {
      obj_t arg1214_112;
      obj_t arg1219_114;
      arg1214_112 = CNST_TABLE_REF(((long) 1));
      arg1219_114 = reverse__39___r4_pairs_and_lists_6_3(_produced_code__154_module_include);
      {
	 obj_t new_205;
	 {
	    obj_t aux_368;
	    aux_368 = CNST_TABLE_REF(((long) 2));
	    new_205 = create_struct(aux_368, ((long) 4));
	 }
	 STRUCT_SET(new_205, ((long) 3), BTRUE);
	 STRUCT_SET(new_205, ((long) 2), arg1219_114);
	 {
	    obj_t aux_373;
	    aux_373 = BINT(((long) 100));
	    STRUCT_SET(new_205, ((long) 1), aux_373);
	 }
	 STRUCT_SET(new_205, ((long) 0), arg1214_112);
	 _toplevel_unit__184_module_include = new_205;
      }
   }
   {
      obj_t list1220_115;
      list1220_115 = MAKE_PAIR(_toplevel_unit__184_module_include, BNIL);
      return list1220_115;
   }
}


/* _include-finalizer */ obj_t 
_include_finalizer_245_module_include(obj_t env_248)
{
   return include_finalizer_204_module_include();
}


/* method-init */ obj_t 
method_init_76_module_include()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_include()
{
   module_initialization_70_module_module(((long) 0), "MODULE_INCLUDE");
   module_initialization_70_tools_error(((long) 0), "MODULE_INCLUDE");
   return module_initialization_70_read_include(((long) 0), "MODULE_INCLUDE");
}
