/*===========================================================================*/
/*   (Engine/engine.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t _src_files__222_engine_param;
extern obj_t engine_engine_engine();
extern obj_t string_append(obj_t, obj_t);
extern obj_t _verbose__1_engine_param;
extern obj_t compiler_engine_compiler();
extern obj_t interp_engine_interp(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _engine_engine_engine(obj_t);
static obj_t _version_write_version(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_engine_engine(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_write_version(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_engine_compiler(long, char *);
extern obj_t module_initialization_70_engine_interp(long, char *);
extern obj_t module_initialization_70_engine_link(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t imported_modules_init_94_engine_engine();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _hello_world_188_engine_engine(obj_t);
static obj_t library_modules_init_112_engine_engine();
extern obj_t hello_world_248_engine_engine();
extern obj_t _o_files__27_engine_param;
extern obj_t _interpreter__140_engine_param;
extern obj_t _lib_dir__34_engine_param;
extern obj_t _bigloo_args__103_engine_param;
extern obj_t _startup_file__78_engine_param;
extern obj_t link_engine_link();
extern obj_t _hello__249_engine_param;
static obj_t require_initialization_114_engine_engine = BUNSPEC;
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(engine_env_109_engine_engine, _engine_engine_engine1058, _engine_engine_engine, 0L, 0);
DEFINE_EXPORT_PROCEDURE(hello_world_env_124_engine_engine, _hello_world_188_engine_engine1059, _hello_world_188_engine_engine, 0L, 0);
extern obj_t version_env_45_write_version;
DEFINE_STRING(string1056_engine_engine, string1056_engine_engine1060, "", 0);
DEFINE_STRING(string1055_engine_engine, string1055_engine_engine1061, " ", 1);
DEFINE_STRING(string1054_engine_engine, string1054_engine_engine1062, "/scheme-files", 13);


/* module-initialization */ obj_t 
module_initialization_70_engine_engine(long checksum_42, char *from_43)
{
   if (CBOOL(require_initialization_114_engine_engine))
     {
	require_initialization_114_engine_engine = BBOOL(((bool_t) 0));
	library_modules_init_112_engine_engine();
	imported_modules_init_94_engine_engine();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_engine_engine()
{
   module_initialization_70___r4_strings_6_7(((long) 0), "ENGINE_ENGINE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "ENGINE_ENGINE");
   return BUNSPEC;
}


/* engine */ obj_t 
engine_engine_engine()
{
   {
      bool_t test1002_1;
      {
	 bool_t test1007_6;
	 {
	    obj_t obj_27;
	    obj_27 = _src_files__222_engine_param;
	    test1007_6 = PAIRP(obj_27);
	 }
	 if (test1007_6)
	   {
	      if (CBOOL(_interpreter__140_engine_param))
		{
		   test1002_1 = ((bool_t) 0);
		}
	      else
		{
		   test1002_1 = ((bool_t) 1);
		}
	   }
	 else
	   {
	      test1002_1 = ((bool_t) 0);
	   }
      }
      if (test1002_1)
	{
	   return compiler_engine_compiler();
	}
      else
	{
	   bool_t test1003_2;
	   {
	      obj_t obj_28;
	      obj_28 = _o_files__27_engine_param;
	      test1003_2 = NULLP(obj_28);
	   }
	   if (test1003_2)
	     {
		{
		   obj_t arg1004_3;
		   {
		      obj_t arg1005_4;
		      {
			 obj_t pair_29;
			 pair_29 = _lib_dir__34_engine_param;
			 arg1005_4 = CAR(pair_29);
		      }
		      arg1004_3 = string_append(arg1005_4, string1054_engine_engine);
		   }
		   return interp_engine_interp(version_env_45_write_version, _verbose__1_engine_param, _src_files__222_engine_param, _startup_file__78_engine_param, arg1004_3, _bigloo_args__103_engine_param);
		}
	     }
	   else
	     {
		return link_engine_link();
	     }
	}
   }
}


/* _engine */ obj_t 
_engine_engine_engine(obj_t env_39)
{
   return engine_engine_engine();
}


/* hello-world */ obj_t 
hello_world_248_engine_engine()
{
   if (CBOOL(_hello__249_engine_param))
     {
	obj_t src_7;
	obj_t str_8;
	{
	   obj_t arg1008_10;
	   arg1008_10 = reverse__39___r4_pairs_and_lists_6_3(_src_files__222_engine_param);
	   src_7 = arg1008_10;
	   str_8 = string1056_engine_engine;
	 loop_9:
	   if (NULLP(src_7))
	     {
		{
		   long aux_69;
		   {
		      long aux_70;
		      aux_70 = STRING_LENGTH(str_8);
		      aux_69 = (aux_70 - ((long) 1));
		   }
		   STRING_SET(str_8, aux_69, ((unsigned char) ':'));
		}
		{
		   obj_t list1017_16;
		   {
		      obj_t arg1018_17;
		      {
			 obj_t aux_74;
			 aux_74 = BCHAR(((unsigned char) '\n'));
			 arg1018_17 = MAKE_PAIR(aux_74, BNIL);
		      }
		      list1017_16 = MAKE_PAIR(str_8, arg1018_17);
		   }
		   return verbose_tools_speek(BINT(((long) 0)), list1017_16);
		}
	     }
	   else
	     {
		obj_t arg1025_19;
		obj_t arg1032_20;
		arg1025_19 = CDR(src_7);
		{
		   obj_t arg1034_21;
		   arg1034_21 = CAR(src_7);
		   {
		      obj_t list1039_23;
		      {
			 obj_t arg1040_24;
			 {
			    obj_t arg1041_25;
			    arg1041_25 = MAKE_PAIR(str_8, BNIL);
			    arg1040_24 = MAKE_PAIR(string1055_engine_engine, arg1041_25);
			 }
			 list1039_23 = MAKE_PAIR(arg1034_21, arg1040_24);
		      }
		      arg1032_20 = string_append_106___r4_strings_6_7(list1039_23);
		   }
		}
		{
		   obj_t str_87;
		   obj_t src_86;
		   src_86 = arg1025_19;
		   str_87 = arg1032_20;
		   str_8 = str_87;
		   src_7 = src_86;
		   goto loop_9;
		}
	     }
	}
     }
   else
     {
	return BUNSPEC;
     }
}


/* _hello-world */ obj_t 
_hello_world_188_engine_engine(obj_t env_41)
{
   return hello_world_248_engine_engine();
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_engine_engine()
{
   module_initialization_70_tools_speek(((long) 0), "ENGINE_ENGINE");
   module_initialization_70_tools_trace(((long) 0), "ENGINE_ENGINE");
   module_initialization_70_write_version(((long) 0), "ENGINE_ENGINE");
   module_initialization_70_engine_param(((long) 0), "ENGINE_ENGINE");
   module_initialization_70_engine_compiler(((long) 0), "ENGINE_ENGINE");
   module_initialization_70_engine_interp(((long) 0), "ENGINE_ENGINE");
   return module_initialization_70_engine_link(((long) 0), "ENGINE_ENGINE");
}
