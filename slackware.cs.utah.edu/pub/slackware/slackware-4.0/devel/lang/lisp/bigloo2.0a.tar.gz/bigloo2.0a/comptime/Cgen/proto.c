/*===========================================================================*/
/*   (Cgen/proto.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct tvec
  {
     struct type *item_type_130;
  }
    *tvec_t;

typedef struct cop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *cop_t;

typedef struct clabel
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t name;
     bool_t used__226;
     obj_t body;
  }
      *clabel_t;

typedef struct cgoto
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct clabel *label;
  }
     *cgoto_t;

typedef struct block
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
     *block_t;

typedef struct creturn
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
       *creturn_t;

typedef struct cvoid
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
     *cvoid_t;

typedef struct catom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t value;
  }
     *catom_t;

typedef struct varc
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct variable *variable;
  }
    *varc_t;

typedef struct cpragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t format;
     obj_t args;
  }
       *cpragma_t;

typedef struct ccast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct cop *arg;
  }
     *ccast_t;

typedef struct csequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     bool_t c_exp__163;
     obj_t cops;
  }
         *csequence_t;

typedef struct nop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *nop_t;

typedef struct stop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
    *stop_t;

typedef struct csetq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct varc *var;
     struct cop *value;
  }
     *csetq_t;

typedef struct cif
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     struct cop *true;
     struct cop *false;
  }
   *cif_t;

typedef struct local_var_164
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t vars;
  }
             *local_var_164_t;

typedef struct cfuncall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
     obj_t strength;
  }
        *cfuncall_t;

typedef struct capply
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     struct cop *arg;
  }
      *capply_t;

typedef struct capp
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
  }
    *capp_t;

typedef struct cfail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *proc;
     struct cop *msg;
     struct cop *obj;
  }
     *cfail_t;

typedef struct cswitch
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     obj_t clauses;
  }
       *cswitch_t;

typedef struct cmake_box_177
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
             *cmake_box_177_t;

typedef struct cbox_ref_44
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
  }
           *cbox_ref_44_t;

typedef struct cbox_set__132
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
     struct cop *value;
  }
             *cbox_set__132_t;

typedef struct cset_ex_it_123
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *jump_value_221;
     struct cop *body;
  }
              *cset_ex_it_123_t;

typedef struct cjump_ex_it_131
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *value;
  }
               *cjump_ex_it_131_t;

typedef struct sfun_c_188
  {
     struct clabel *label;
     bool_t integrated;
  }
          *sfun_c_188_t;

typedef struct bdb_block_21
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
            *bdb_block_21_t;


extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t method_init_76_cgen_prototype();
static obj_t emit_prototype_default1674_51_cgen_prototype(value_t, variable_t);
static obj_t _emit_cnsts_87_cgen_prototype(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t type_type_type;
extern obj_t _c_port__188_cgen_emit;
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t make_typed_declaration_180_type_tools(type_t, obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern obj_t untrigraph_cgen_emit_cop_239(obj_t);
extern obj_t cvar_ast_var;
extern obj_t type_name_sans___47_type_tools(type_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _get_c_scope2364_29_cgen_prototype(obj_t, obj_t);
extern obj_t qualified_name_205_cgen_prototype(obj_t, obj_t);
extern obj_t module_initialization_70_cgen_prototype(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_tvector_tvector(long, char *);
extern obj_t module_initialization_70_tvector_cnst(long, char *);
extern obj_t module_initialization_70_cnst_alloc(long, char *);
extern obj_t module_initialization_70_cgen_cop(long, char *);
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70_cgen_emit_cop_239(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static bool_t emit_prototype_formal_types_237_cgen_prototype(obj_t);
extern bool_t sub_type__174_type_env(type_t, type_t);
static obj_t emit_cnst_44_cgen_prototype(scnst_t, global_t);
static obj_t _get_c_scope_default1680_185_cgen_prototype(obj_t, obj_t);
extern obj_t _max_c_token_length__129_engine_param;
extern obj_t svar_ast_var;
extern obj_t scnst_ast_var;
static obj_t _set_variable_name__28_cgen_prototype(obj_t, obj_t);
extern obj_t emit_prototypes_82_cgen_prototype();
static obj_t _emit_prototype2363_113_cgen_prototype(obj_t, obj_t, obj_t);
static obj_t get_c_scope_184_cgen_prototype(variable_t);
static obj_t imported_modules_init_94_cgen_prototype();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static bool_t emit_prototype_formals_182_cgen_prototype(obj_t);
extern obj_t cfun_ast_var;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t tvector__c_vector_165_tvector_cnst(obj_t);
extern obj_t id__name_228_ast_ident(obj_t);
static obj_t library_modules_init_112_cgen_prototype();
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t toplevel_init_63_cgen_prototype();
static obj_t _emit_prototypes_68_cgen_prototype(obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t arg1723_cgen_prototype(obj_t, obj_t);
static obj_t arg1702_cgen_prototype(obj_t, obj_t);
extern obj_t local_ast_var;
extern obj_t emit_cnsts_221_cgen_prototype();
extern obj_t for_each_global__88_ast_env(obj_t);
static obj_t emit_prototype_svar_scnst_27_cgen_prototype(obj_t, variable_t);
static obj_t _emit_prototype_default1674_111_cgen_prototype(obj_t, obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t get_cnst_table_42_cnst_alloc();
extern obj_t c_substring(obj_t, long, long);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t get_c_scope_default1680_145_cgen_prototype(variable_t);
static obj_t emit_cnst_sfun_sgfun_176_cgen_prototype(obj_t, global_t, char *);
extern obj_t _module__166_module_module;
static obj_t emit_cnst_string_104_cgen_prototype(obj_t, global_t);
static bool_t fprin_cgen_prototype(obj_t, obj_t);
static obj_t emit_cnst_stvector_253_cgen_prototype(obj_t, global_t);
extern obj_t _classes__134___object;
extern obj_t set_variable_name__102_cgen_prototype(obj_t);
static obj_t _qualified_name2362_177_cgen_prototype(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t emit_prototype_23_cgen_prototype(value_t, variable_t);
static obj_t require_initialization_114_cgen_prototype = BUNSPEC;
static obj_t emit_cnst_real_94_cgen_prototype(obj_t, global_t);
extern obj_t string_for_read(obj_t);
static obj_t cnst_init_137_cgen_prototype();
static obj_t __cnst[11];

DEFINE_STATIC_PROCEDURE(proc2366_cgen_prototype, arg1723_cgen_prototype2405, arg1723_cgen_prototype, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2365_cgen_prototype, arg1702_cgen_prototype2406, arg1702_cgen_prototype, 0L, 1);
DEFINE_STATIC_PROCEDURE(get_c_scope_default1680_env_1_cgen_prototype, _get_c_scope_default1680_185_cgen_prototype2407, _get_c_scope_default1680_185_cgen_prototype, 0L, 1);
DEFINE_STATIC_GENERIC(emit_prototype_env_241_cgen_prototype, _emit_prototype2363_113_cgen_prototype2408, _emit_prototype2363_113_cgen_prototype, 0L, 2);
DEFINE_STATIC_GENERIC(get_c_scope_env_161_cgen_prototype, _get_c_scope2364_29_cgen_prototype2409, _get_c_scope2364_29_cgen_prototype, 0L, 1);
DEFINE_STATIC_PROCEDURE(emit_prototype_default1674_env_181_cgen_prototype, _emit_prototype_default1674_111_cgen_prototype2410, _emit_prototype_default1674_111_cgen_prototype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(emit_cnsts_env_4_cgen_prototype, _emit_cnsts_87_cgen_prototype2411, _emit_cnsts_87_cgen_prototype, 0L, 0);
DEFINE_STRING(string2399_cgen_prototype, string2399_cgen_prototype2412, "GET-C-SCOPE-DEFAULT1680 EMIT-PROTOTYPE-DEFAULT1674 IMPORT STVECTOR SGFUN SFUN SREAL SSTRING STATIC NEVER EXPORT ", 112);
DEFINE_STRING(string2398_cgen_prototype, string2398_cgen_prototype2413, "Unknown importation", 19);
DEFINE_STRING(string2397_cgen_prototype, string2397_cgen_prototype2414, "get-c-scope", 11);
DEFINE_STRING(string2396_cgen_prototype, string2396_cgen_prototype2415, "extern", 6);
DEFINE_STRING(string2395_cgen_prototype, string2395_cgen_prototype2416, "No method for this object", 25);
DEFINE_STRING(string2394_cgen_prototype, string2394_cgen_prototype2417, "...)", 4);
DEFINE_STRING(string2393_cgen_prototype, string2393_cgen_prototype2418, ", ...)", 6);
DEFINE_STRING(string2392_cgen_prototype, string2392_cgen_prototype2419, "extern ", 7);
DEFINE_STRING(string2391_cgen_prototype, string2391_cgen_prototype2420, "Unknown variable sort", 21);
DEFINE_STRING(string2389_cgen_prototype, string2389_cgen_prototype2421, "_", 1);
DEFINE_STRING(string2390_cgen_prototype, string2390_cgen_prototype2422, "set-variable-name!", 18);
DEFINE_STRING(string2388_cgen_prototype, string2388_cgen_prototype2423, "DEFINE_TVECTOR_START( ", 22);
DEFINE_STRING(string2387_cgen_prototype, string2387_cgen_prototype2424, " ) ", 3);
DEFINE_STRING(string2386_cgen_prototype, string2386_cgen_prototype2425, " DEFINE_TVECTOR_STOP( ", 22);
DEFINE_STRING(string2385_cgen_prototype, string2385_cgen_prototype2426, ", va_generic_entry", 18);
DEFINE_STRING(string2384_cgen_prototype, string2384_cgen_prototype2427, ", 0L, ", 6);
DEFINE_STRING(string2383_cgen_prototype, string2383_cgen_prototype2428, "DEFINE_EXPORT_", 14);
DEFINE_STRING(string2382_cgen_prototype, string2382_cgen_prototype2429, "DEFINE_STATIC_", 14);
DEFINE_STRING(string2381_cgen_prototype, string2381_cgen_prototype2430, "( ", 2);
DEFINE_STRING(string2379_cgen_prototype, string2379_cgen_prototype2431, "\"\n\"", 3);
DEFINE_STRING(string2380_cgen_prototype, string2380_cgen_prototype2432, "DEFINE_REAL( ", 13);
DEFINE_STRING(string2378_cgen_prototype, string2378_cgen_prototype2433, "Can't emit string", 17);
DEFINE_STRING(string2377_cgen_prototype, string2377_cgen_prototype2434, "emit-cnst-string", 16);
DEFINE_STRING(string2376_cgen_prototype, string2376_cgen_prototype2435, "\", ", 3);
DEFINE_STRING(string2375_cgen_prototype, string2375_cgen_prototype2436, " );", 3);
DEFINE_STRING(string2374_cgen_prototype, string2374_cgen_prototype2437, "DEFINE_STRING( ", 15);
DEFINE_STRING(string2373_cgen_prototype, string2373_cgen_prototype2438, ", \"", 3);
DEFINE_STRING(string2372_cgen_prototype, string2372_cgen_prototype2439, "Unknown cnst class", 18);
DEFINE_STRING(string2371_cgen_prototype, string2371_cgen_prototype2440, "emit-cnst", 9);
DEFINE_STRING(string2369_cgen_prototype, string2369_cgen_prototype2441, "()", 2);
DEFINE_STRING(string2370_cgen_prototype, string2370_cgen_prototype2442, ", ", 2);
DEFINE_STRING(string2368_cgen_prototype, string2368_cgen_prototype2443, "static", 6);
DEFINE_STRING(string2367_cgen_prototype, string2367_cgen_prototype2444, " = BUNSPEC;", 11);
DEFINE_EXPORT_PROCEDURE(emit_prototypes_env_106_cgen_prototype, _emit_prototypes_68_cgen_prototype2445, _emit_prototypes_68_cgen_prototype, 0L, 0);
DEFINE_EXPORT_PROCEDURE(qualified_name_env_76_cgen_prototype, _qualified_name2362_177_cgen_prototype2446, _qualified_name2362_177_cgen_prototype, 0L, 2);
DEFINE_EXPORT_PROCEDURE(set_variable_name__env_153_cgen_prototype, _set_variable_name__28_cgen_prototype2447, _set_variable_name__28_cgen_prototype, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_cgen_prototype(long checksum_2525, char *from_2526)
{
   if (CBOOL(require_initialization_114_cgen_prototype))
     {
	require_initialization_114_cgen_prototype = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_prototype();
	cnst_init_137_cgen_prototype();
	imported_modules_init_94_cgen_prototype();
	method_init_76_cgen_prototype();
	toplevel_init_63_cgen_prototype();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_prototype()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70___object(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70___r4_symbols_6_4(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70___r4_strings_6_7(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70___reader(((long) 0), "CGEN_PROTOTYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_prototype()
{
   {
      obj_t cnst_port_138_2517;
      cnst_port_138_2517 = open_input_string(string2399_cgen_prototype);
      {
	 long i_2518;
	 i_2518 = ((long) 10);
       loop_2519:
	 {
	    bool_t test2400_2520;
	    test2400_2520 = (i_2518 == ((long) -1));
	    if (test2400_2520)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2401_2521;
		    {
		       obj_t list2402_2522;
		       {
			  obj_t arg2403_2523;
			  arg2403_2523 = BNIL;
			  list2402_2522 = MAKE_PAIR(cnst_port_138_2517, arg2403_2523);
		       }
		       arg2401_2521 = read___reader(list2402_2522);
		    }
		    CNST_TABLE_SET(i_2518, arg2401_2521);
		 }
		 {
		    int aux_2524;
		    {
		       long aux_2547;
		       aux_2547 = (i_2518 - ((long) 1));
		       aux_2524 = (int) (aux_2547);
		    }
		    {
		       long i_2550;
		       i_2550 = (long) (aux_2524);
		       i_2518 = i_2550;
		       goto loop_2519;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_prototype()
{
   return BUNSPEC;
}


/* emit-prototypes */ obj_t 
emit_prototypes_82_cgen_prototype()
{
   {
      obj_t arg1702_2493;
      arg1702_2493 = proc2365_cgen_prototype;
      for_each_global__88_ast_env(arg1702_2493);
   }
   {
      obj_t cnst_init_137_1123;
      cnst_init_137_1123 = get_cnst_table_42_cnst_alloc();
      {
	 value_t aux_2554;
	 {
	    global_t obj_2167;
	    obj_2167 = (global_t) (cnst_init_137_1123);
	    aux_2554 = (((global_t) CREF(obj_2167))->value);
	 }
	 emit_prototype_23_cgen_prototype(aux_2554, (variable_t) (cnst_init_137_1123));
      }
   }
   {
      obj_t list1721_1125;
      list1721_1125 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
      return newline___r4_output_6_10_3(list1721_1125);
   }
}


/* _emit-prototypes */ obj_t 
_emit_prototypes_68_cgen_prototype(obj_t env_2494)
{
   return emit_prototypes_82_cgen_prototype();
}


/* arg1702 */ obj_t 
arg1702_cgen_prototype(obj_t env_2495, obj_t global_2496)
{
   {
      obj_t global_1105;
      global_1105 = global_2496;
      {
	 bool_t test1704_1107;
	 {
	    bool_t test1706_1109;
	    {
	       bool_t test1709_1112;
	       {
		  bool_t test1715_1118;
		  {
		     obj_t obj2_2154;
		     obj2_2154 = _module__166_module_module;
		     {
			obj_t aux_2562;
			{
			   global_t obj_2152;
			   obj_2152 = (global_t) (global_1105);
			   aux_2562 = (((global_t) CREF(obj_2152))->module);
			}
			test1715_1118 = (aux_2562 == obj2_2154);
		     }
		  }
		  if (test1715_1118)
		    {
		       obj_t aux_2570;
		       obj_t aux_2567;
		       aux_2570 = CNST_TABLE_REF(((long) 0));
		       {
			  global_t obj_2155;
			  obj_2155 = (global_t) (global_1105);
			  aux_2567 = (((global_t) CREF(obj_2155))->import);
		       }
		       test1709_1112 = (aux_2567 == aux_2570);
		    }
		  else
		    {
		       test1709_1112 = ((bool_t) 0);
		    }
	       }
	       if (test1709_1112)
		 {
		    test1706_1109 = ((bool_t) 1);
		 }
	       else
		 {
		    bool_t test_2574;
		    {
		       long aux_2575;
		       {
			  global_t obj_2158;
			  obj_2158 = (global_t) (global_1105);
			  aux_2575 = (((global_t) CREF(obj_2158))->occurrence);
		       }
		       test_2574 = (aux_2575 > ((long) 0));
		    }
		    if (test_2574)
		      {
			 test1706_1109 = ((bool_t) 1);
		      }
		    else
		      {
			 obj_t aux_2582;
			 obj_t aux_2579;
			 aux_2582 = CNST_TABLE_REF(((long) 1));
			 {
			    global_t obj_2161;
			    obj_2161 = (global_t) (global_1105);
			    aux_2579 = (((global_t) CREF(obj_2161))->removable);
			 }
			 test1706_1109 = (aux_2579 == aux_2582);
		      }
		 }
	    }
	    if (test1706_1109)
	      {
		 bool_t test1707_1110;
		 {
		    obj_t aux_2586;
		    {
		       value_t aux_2587;
		       {
			  global_t obj_2164;
			  obj_2164 = (global_t) (global_1105);
			  aux_2587 = (((global_t) CREF(obj_2164))->value);
		       }
		       aux_2586 = (obj_t) (aux_2587);
		    }
		    test1707_1110 = is_a__118___object(aux_2586, scnst_ast_var);
		 }
		 if (test1707_1110)
		   {
		      test1704_1107 = ((bool_t) 0);
		   }
		 else
		   {
		      test1704_1107 = ((bool_t) 1);
		   }
	      }
	    else
	      {
		 test1704_1107 = ((bool_t) 0);
	      }
	 }
	 if (test1704_1107)
	   {
	      value_t aux_2594;
	      {
		 global_t obj_2166;
		 obj_2166 = (global_t) (global_1105);
		 aux_2594 = (((global_t) CREF(obj_2166))->value);
	      }
	      return emit_prototype_23_cgen_prototype(aux_2594, (variable_t) (global_1105));
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* emit-cnsts */ obj_t 
emit_cnsts_221_cgen_prototype()
{
   {
      obj_t arg1723_2497;
      arg1723_2497 = proc2366_cgen_prototype;
      for_each_global__88_ast_env(arg1723_2497);
   }
   {
      obj_t list1740_1142;
      list1740_1142 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
      return newline___r4_output_6_10_3(list1740_1142);
   }
}


/* _emit-cnsts */ obj_t 
_emit_cnsts_87_cgen_prototype(obj_t env_2498)
{
   return emit_cnsts_221_cgen_prototype();
}


/* arg1723 */ obj_t 
arg1723_cgen_prototype(obj_t env_2499, obj_t global_2500)
{
   {
      obj_t global_1128;
      global_1128 = global_2500;
      {
	 bool_t test1725_1130;
	 {
	    bool_t test1727_1132;
	    {
	       bool_t test1729_1134;
	       {
		  bool_t test1732_1137;
		  {
		     obj_t obj2_2170;
		     obj2_2170 = _module__166_module_module;
		     {
			obj_t aux_2603;
			{
			   global_t obj_2168;
			   obj_2168 = (global_t) (global_1128);
			   aux_2603 = (((global_t) CREF(obj_2168))->module);
			}
			test1732_1137 = (aux_2603 == obj2_2170);
		     }
		  }
		  if (test1732_1137)
		    {
		       obj_t aux_2611;
		       obj_t aux_2608;
		       aux_2611 = CNST_TABLE_REF(((long) 0));
		       {
			  global_t obj_2171;
			  obj_2171 = (global_t) (global_1128);
			  aux_2608 = (((global_t) CREF(obj_2171))->import);
		       }
		       test1729_1134 = (aux_2608 == aux_2611);
		    }
		  else
		    {
		       test1729_1134 = ((bool_t) 0);
		    }
	       }
	       if (test1729_1134)
		 {
		    test1727_1132 = ((bool_t) 1);
		 }
	       else
		 {
		    long aux_2615;
		    {
		       global_t obj_2174;
		       obj_2174 = (global_t) (global_1128);
		       aux_2615 = (((global_t) CREF(obj_2174))->occurrence);
		    }
		    test1727_1132 = (aux_2615 > ((long) 0));
		 }
	    }
	    if (test1727_1132)
	      {
		 obj_t aux_2620;
		 {
		    value_t aux_2621;
		    {
		       global_t obj_2177;
		       obj_2177 = (global_t) (global_1128);
		       aux_2621 = (((global_t) CREF(obj_2177))->value);
		    }
		    aux_2620 = (obj_t) (aux_2621);
		 }
		 test1725_1130 = is_a__118___object(aux_2620, scnst_ast_var);
	      }
	    else
	      {
		 test1725_1130 = ((bool_t) 0);
	      }
	 }
	 if (test1725_1130)
	   {
	      scnst_t aux_2627;
	      {
		 value_t aux_2628;
		 {
		    global_t obj_2179;
		    obj_2179 = (global_t) (global_1128);
		    aux_2628 = (((global_t) CREF(obj_2179))->value);
		 }
		 aux_2627 = (scnst_t) (aux_2628);
	      }
	      return emit_cnst_44_cgen_prototype(aux_2627, (global_t) (global_1128));
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* emit-prototype/svar/scnst */ obj_t 
emit_prototype_svar_scnst_27_cgen_prototype(obj_t value_19, variable_t variable_20)
{
   set_variable_name__102_cgen_prototype((obj_t) (variable_20));
   {
      bool_t test_2636;
      {
	 obj_t aux_2640;
	 obj_t aux_2637;
	 aux_2640 = CNST_TABLE_REF(((long) 2));
	 {
	    global_t obj_2180;
	    obj_2180 = (global_t) (variable_20);
	    aux_2637 = (((global_t) CREF(obj_2180))->import);
	 }
	 test_2636 = (aux_2637 == aux_2640);
      }
      if (test_2636)
	{
	   {
	      obj_t arg1746_1147;
	      obj_t arg1747_1148;
	      arg1746_1147 = make_typed_declaration_180_type_tools((((variable_t) CREF(variable_20))->type), (((variable_t) CREF(variable_20))->name));
	      {
		 bool_t test1761_1156;
		 test1761_1156 = sub_type__174_type_env((((variable_t) CREF(variable_20))->type), (type_t) (_obj__252_type_cache));
		 if (test1761_1156)
		   {
		      arg1747_1148 = string2367_cgen_prototype;
		   }
		 else
		   {
		      arg1747_1148 = BCHAR(((unsigned char) ';'));
		   }
	      }
	      {
		 obj_t list1748_1149;
		 {
		    obj_t arg1749_1150;
		    {
		       obj_t arg1753_1151;
		       {
			  obj_t arg1755_1152;
			  arg1755_1152 = MAKE_PAIR(arg1747_1148, BNIL);
			  arg1753_1151 = MAKE_PAIR(arg1746_1147, arg1755_1152);
		       }
		       {
			  obj_t aux_2653;
			  aux_2653 = BCHAR(((unsigned char) ' '));
			  arg1749_1150 = MAKE_PAIR(aux_2653, arg1753_1151);
		       }
		    }
		    list1748_1149 = MAKE_PAIR(string2368_cgen_prototype, arg1749_1150);
		 }
		 return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1748_1149);
	      }
	   }
	}
      else
	{
	   bool_t test_2658;
	   {
	      obj_t aux_2662;
	      obj_t aux_2659;
	      aux_2662 = CNST_TABLE_REF(((long) 0));
	      {
		 global_t obj_2186;
		 obj_2186 = (global_t) (variable_20);
		 aux_2659 = (((global_t) CREF(obj_2186))->import);
	      }
	      test_2658 = (aux_2659 == aux_2662);
	   }
	   if (test_2658)
	     {
		{
		   obj_t arg1765_1159;
		   obj_t arg1766_1160;
		   arg1765_1159 = make_typed_declaration_180_type_tools((((variable_t) CREF(variable_20))->type), (((variable_t) CREF(variable_20))->name));
		   {
		      bool_t test1772_1166;
		      test1772_1166 = sub_type__174_type_env((((variable_t) CREF(variable_20))->type), (type_t) (_obj__252_type_cache));
		      if (test1772_1166)
			{
			   arg1766_1160 = string2367_cgen_prototype;
			}
		      else
			{
			   arg1766_1160 = BCHAR(((unsigned char) ';'));
			}
		   }
		   {
		      obj_t list1767_1161;
		      {
			 obj_t arg1768_1162;
			 arg1768_1162 = MAKE_PAIR(arg1766_1160, BNIL);
			 list1767_1161 = MAKE_PAIR(arg1765_1159, arg1768_1162);
		      }
		      return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1767_1161);
		   }
		}
	     }
	   else
	     {
		{
		   obj_t arg1774_1168;
		   obj_t arg1776_1169;
		   arg1774_1168 = get_c_scope_184_cgen_prototype(variable_20);
		   arg1776_1169 = make_typed_declaration_180_type_tools((((variable_t) CREF(variable_20))->type), (((variable_t) CREF(variable_20))->name));
		   {
		      obj_t list1777_1170;
		      {
			 obj_t arg1778_1171;
			 {
			    obj_t arg1779_1172;
			    {
			       obj_t arg1780_1173;
			       {
				  obj_t aux_2680;
				  aux_2680 = BCHAR(((unsigned char) ';'));
				  arg1780_1173 = MAKE_PAIR(aux_2680, BNIL);
			       }
			       arg1779_1172 = MAKE_PAIR(arg1776_1169, arg1780_1173);
			    }
			    {
			       obj_t aux_2684;
			       aux_2684 = BCHAR(((unsigned char) ' '));
			       arg1778_1171 = MAKE_PAIR(aux_2684, arg1779_1172);
			    }
			 }
			 list1777_1170 = MAKE_PAIR(arg1774_1168, arg1778_1171);
		      }
		      return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1777_1170);
		   }
		}
	     }
	}
   }
}


/* emit-prototype-formal-types */ bool_t 
emit_prototype_formal_types_237_cgen_prototype(obj_t types_23)
{
   if (NULLP(types_23))
     {
	obj_t list1793_1182;
	list1793_1182 = MAKE_PAIR(string2369_cgen_prototype, BNIL);
	return fprin_cgen_prototype(_c_port__188_cgen_emit, list1793_1182);
     }
   else
     {
	{
	   obj_t list1796_1185;
	   list1796_1185 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	   display___r4_output_6_10_3(BCHAR(((unsigned char) '(')), list1796_1185);
	}
	{
	   obj_t types_1187;
	   types_1187 = types_23;
	 loop_1188:
	   {
	      bool_t test_2696;
	      {
		 obj_t aux_2697;
		 aux_2697 = CDR(types_1187);
		 test_2696 = NULLP(aux_2697);
	      }
	      if (test_2696)
		{
		   obj_t arg1799_1190;
		   {
		      type_t aux_2700;
		      {
			 obj_t aux_2701;
			 aux_2701 = CAR(types_1187);
			 aux_2700 = (type_t) (aux_2701);
		      }
		      arg1799_1190 = type_name_sans___47_type_tools(aux_2700);
		   }
		   {
		      obj_t list1800_1191;
		      {
			 obj_t arg1802_1192;
			 {
			    obj_t aux_2705;
			    aux_2705 = BCHAR(((unsigned char) ')'));
			    arg1802_1192 = MAKE_PAIR(aux_2705, BNIL);
			 }
			 list1800_1191 = MAKE_PAIR(arg1799_1190, arg1802_1192);
		      }
		      return fprin_cgen_prototype(_c_port__188_cgen_emit, list1800_1191);
		   }
		}
	      else
		{
		   {
		      obj_t arg1805_1195;
		      {
			 type_t aux_2710;
			 {
			    obj_t aux_2711;
			    aux_2711 = CAR(types_1187);
			    aux_2710 = (type_t) (aux_2711);
			 }
			 arg1805_1195 = type_name_sans___47_type_tools(aux_2710);
		      }
		      {
			 obj_t list1807_1197;
			 {
			    obj_t arg1808_1198;
			    arg1808_1198 = MAKE_PAIR(string2370_cgen_prototype, BNIL);
			    list1807_1197 = MAKE_PAIR(arg1805_1195, arg1808_1198);
			 }
			 fprin_cgen_prototype(_c_port__188_cgen_emit, list1807_1197);
		      }
		   }
		   {
		      obj_t types_2718;
		      types_2718 = CDR(types_1187);
		      types_1187 = types_2718;
		      goto loop_1188;
		   }
		}
	   }
	}
     }
}


/* emit-prototype-formals */ bool_t 
emit_prototype_formals_182_cgen_prototype(obj_t args_24)
{
   if (NULLP(args_24))
     {
	obj_t list1814_1204;
	list1814_1204 = MAKE_PAIR(string2369_cgen_prototype, BNIL);
	return fprin_cgen_prototype(_c_port__188_cgen_emit, list1814_1204);
     }
   else
     {
	{
	   obj_t list1817_1207;
	   list1817_1207 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	   display___r4_output_6_10_3(BCHAR(((unsigned char) '(')), list1817_1207);
	}
	{
	   obj_t args_1209;
	   args_1209 = args_24;
	 loop_1210:
	   {
	      bool_t test_2727;
	      {
		 obj_t aux_2728;
		 aux_2728 = CDR(args_1209);
		 test_2727 = NULLP(aux_2728);
	      }
	      if (test_2727)
		{
		   obj_t arg1820_1213;
		   {
		      type_t aux_2731;
		      {
			 local_t obj_2204;
			 {
			    obj_t aux_2732;
			    aux_2732 = CAR(args_1209);
			    obj_2204 = (local_t) (aux_2732);
			 }
			 aux_2731 = (((local_t) CREF(obj_2204))->type);
		      }
		      arg1820_1213 = type_name_sans___47_type_tools(aux_2731);
		   }
		   {
		      obj_t list1821_1214;
		      {
			 obj_t arg1822_1215;
			 {
			    obj_t aux_2737;
			    aux_2737 = BCHAR(((unsigned char) ')'));
			    arg1822_1215 = MAKE_PAIR(aux_2737, BNIL);
			 }
			 list1821_1214 = MAKE_PAIR(arg1820_1213, arg1822_1215);
		      }
		      return fprin_cgen_prototype(_c_port__188_cgen_emit, list1821_1214);
		   }
		}
	      else
		{
		   {
		      obj_t arg1826_1219;
		      {
			 type_t aux_2742;
			 {
			    local_t obj_2206;
			    {
			       obj_t aux_2743;
			       aux_2743 = CAR(args_1209);
			       obj_2206 = (local_t) (aux_2743);
			    }
			    aux_2742 = (((local_t) CREF(obj_2206))->type);
			 }
			 arg1826_1219 = type_name_sans___47_type_tools(aux_2742);
		      }
		      {
			 obj_t list1828_1221;
			 {
			    obj_t arg1829_1222;
			    arg1829_1222 = MAKE_PAIR(string2370_cgen_prototype, BNIL);
			    list1828_1221 = MAKE_PAIR(arg1826_1219, arg1829_1222);
			 }
			 fprin_cgen_prototype(_c_port__188_cgen_emit, list1828_1221);
		      }
		   }
		   {
		      obj_t args_2751;
		      args_2751 = CDR(args_1209);
		      args_1209 = args_2751;
		      goto loop_1210;
		   }
		}
	   }
	}
     }
}


/* emit-cnst */ obj_t 
emit_cnst_44_cgen_prototype(scnst_t value_29, global_t variable_30)
{
   {
      obj_t case_value_58_1228;
      case_value_58_1228 = (((scnst_t) CREF(value_29))->class);
      {
	 bool_t test_2754;
	 {
	    obj_t aux_2755;
	    aux_2755 = CNST_TABLE_REF(((long) 3));
	    test_2754 = (case_value_58_1228 == aux_2755);
	 }
	 if (test_2754)
	   {
	      return emit_cnst_string_104_cgen_prototype((((scnst_t) CREF(value_29))->node), variable_30);
	   }
	 else
	   {
	      bool_t test_2760;
	      {
		 obj_t aux_2761;
		 aux_2761 = CNST_TABLE_REF(((long) 4));
		 test_2760 = (case_value_58_1228 == aux_2761);
	      }
	      if (test_2760)
		{
		   return emit_cnst_real_94_cgen_prototype((((scnst_t) CREF(value_29))->node), variable_30);
		}
	      else
		{
		   bool_t test_2766;
		   {
		      obj_t aux_2767;
		      aux_2767 = CNST_TABLE_REF(((long) 5));
		      test_2766 = (case_value_58_1228 == aux_2767);
		   }
		   if (test_2766)
		     {
			return emit_cnst_sfun_sgfun_176_cgen_prototype((((scnst_t) CREF(value_29))->node), variable_30, "PROCEDURE");
		     }
		   else
		     {
			bool_t test_2772;
			{
			   obj_t aux_2773;
			   aux_2773 = CNST_TABLE_REF(((long) 6));
			   test_2772 = (case_value_58_1228 == aux_2773);
			}
			if (test_2772)
			  {
			     return emit_cnst_sfun_sgfun_176_cgen_prototype((((scnst_t) CREF(value_29))->node), variable_30, "GENERIC");
			  }
			else
			  {
			     bool_t test_2778;
			     {
				obj_t aux_2779;
				aux_2779 = CNST_TABLE_REF(((long) 7));
				test_2778 = (case_value_58_1228 == aux_2779);
			     }
			     if (test_2778)
			       {
				  return emit_cnst_stvector_253_cgen_prototype((((scnst_t) CREF(value_29))->node), variable_30);
			       }
			     else
			       {
				  return internal_error_43_tools_error(string2371_cgen_prototype, string2372_cgen_prototype, (((scnst_t) CREF(value_29))->class));
			       }
			  }
		     }
		}
	   }
      }
   }
}


/* emit-cnst-string */ obj_t 
emit_cnst_string_104_cgen_prototype(obj_t ostr_31, global_t global_32)
{
   set_variable_name__102_cgen_prototype((obj_t) (global_32));
   {
      obj_t str_1247;
      str_1247 = string_for_read(ostr_31);
      {
	 obj_t arg1860_1249;
	 obj_t arg1862_1251;
	 arg1860_1249 = (((global_t) CREF(global_32))->name);
	 {
	    obj_t arg1870_1259;
	    arg1870_1259 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, (((global_t) CREF(global_32))->name), BEOA);
	    arg1862_1251 = id__name_228_ast_ident(arg1870_1259);
	 }
	 {
	    obj_t list1864_1253;
	    {
	       obj_t arg1865_1254;
	       {
		  obj_t arg1866_1255;
		  {
		     obj_t arg1867_1256;
		     {
			obj_t arg1868_1257;
			arg1868_1257 = MAKE_PAIR(string2373_cgen_prototype, BNIL);
			arg1867_1256 = MAKE_PAIR(arg1862_1251, arg1868_1257);
		     }
		     arg1866_1255 = MAKE_PAIR(string2370_cgen_prototype, arg1867_1256);
		  }
		  arg1865_1254 = MAKE_PAIR(arg1860_1249, arg1866_1255);
	       }
	       list1864_1253 = MAKE_PAIR(string2374_cgen_prototype, arg1865_1254);
	    }
	    fprin_cgen_prototype(_c_port__188_cgen_emit, list1864_1253);
	 }
      }
      {
	 long read_1261;
	 long rlen_1262;
	 read_1261 = ((long) 0);
	 rlen_1262 = STRING_LENGTH(str_1247);
       loop_1263:
	 {
	    bool_t test1876_1266;
	    {
	       long n2_2234;
	       n2_2234 = (long) CINT(_max_c_token_length__129_engine_param);
	       test1876_1266 = (rlen_1262 <= n2_2234);
	    }
	    if (test1876_1266)
	      {
		 {
		    obj_t arg1877_1267;
		    {
		       obj_t arg1880_1270;
		       {
			  long aux_2803;
			  aux_2803 = (read_1261 + rlen_1262);
			  arg1880_1270 = c_substring(str_1247, read_1261, aux_2803);
		       }
		       arg1877_1267 = untrigraph_cgen_emit_cop_239(arg1880_1270);
		    }
		    {
		       obj_t list1878_1268;
		       list1878_1268 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		       display___r4_output_6_10_3(arg1877_1267, list1878_1268);
		    }
		 }
		 {
		    long arg1884_1273;
		    arg1884_1273 = STRING_LENGTH(ostr_31);
		    {
		       obj_t list1886_1275;
		       {
			  obj_t arg1887_1276;
			  {
			     obj_t arg1888_1277;
			     arg1888_1277 = MAKE_PAIR(string2375_cgen_prototype, BNIL);
			     {
				obj_t aux_2811;
				aux_2811 = BINT(arg1884_1273);
				arg1887_1276 = MAKE_PAIR(aux_2811, arg1888_1277);
			     }
			  }
			  list1886_1275 = MAKE_PAIR(string2376_cgen_prototype, arg1887_1276);
		       }
		       return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1886_1275);
		    }
		 }
	      }
	    else
	      {
		 {
		    long offset_1279;
		    {
		       long arg1892_1281;
		       {
			  long z2_2242;
			  z2_2242 = (long) CINT(_max_c_token_length__129_engine_param);
			  arg1892_1281 = (read_1261 + z2_2242);
		       }
		       offset_1279 = arg1892_1281;
		     laap_1280:
		       {
			  bool_t test_2818;
			  {
			     long aux_2819;
			     aux_2819 = (read_1261 + ((long) 3));
			     test_2818 = (aux_2819 >= offset_1279);
			  }
			  if (test_2818)
			    {
			       return internal_error_43_tools_error(string2377_cgen_prototype, string2378_cgen_prototype, ostr_31);
			    }
			  else
			    {
			       bool_t test_2823;
			       {
				  unsigned char aux_2824;
				  {
				     long aux_2825;
				     aux_2825 = (offset_1279 - ((long) 1));
				     aux_2824 = STRING_REF(str_1247, aux_2825);
				  }
				  test_2823 = (aux_2824 == ((unsigned char) '\\'));
			       }
			       if (test_2823)
				 {
				    {
				       long offset_2829;
				       offset_2829 = (offset_1279 - ((long) 1));
				       offset_1279 = offset_2829;
				       goto laap_1280;
				    }
				 }
			       else
				 {
				    bool_t test_2831;
				    {
				       bool_t test_2832;
				       {
					  unsigned char aux_2833;
					  {
					     long aux_2834;
					     aux_2834 = (offset_1279 - ((long) 2));
					     aux_2833 = STRING_REF(str_1247, aux_2834);
					  }
					  test_2832 = (aux_2833 == ((unsigned char) '\\'));
				       }
				       if (test_2832)
					 {
					    unsigned char arg1917_1305;
					    {
					       long aux_2838;
					       aux_2838 = (offset_1279 - ((long) 1));
					       arg1917_1305 = STRING_REF(str_1247, aux_2838);
					    }
					    if ((arg1917_1305 >= ((unsigned char) '0')))
					      {
						 test_2831 = (arg1917_1305 <= ((unsigned char) '9'));
					      }
					    else
					      {
						 test_2831 = ((bool_t) 0);
					      }
					 }
				       else
					 {
					    test_2831 = ((bool_t) 0);
					 }
				    }
				    if (test_2831)
				      {
					 {
					    long offset_2844;
					    offset_2844 = (offset_1279 - ((long) 2));
					    offset_1279 = offset_2844;
					    goto laap_1280;
					 }
				      }
				    else
				      {
					 bool_t test_2846;
					 {
					    bool_t test_2847;
					    {
					       unsigned char aux_2848;
					       {
						  long aux_2849;
						  aux_2849 = (offset_1279 - ((long) 3));
						  aux_2848 = STRING_REF(str_1247, aux_2849);
					       }
					       test_2847 = (aux_2848 == ((unsigned char) '\\'));
					    }
					    if (test_2847)
					      {
						 bool_t test_2853;
						 {
						    unsigned char arg1912_1300;
						    {
						       long aux_2854;
						       aux_2854 = (offset_1279 - ((long) 2));
						       arg1912_1300 = STRING_REF(str_1247, aux_2854);
						    }
						    if ((arg1912_1300 >= ((unsigned char) '0')))
						      {
							 test_2853 = (arg1912_1300 <= ((unsigned char) '9'));
						      }
						    else
						      {
							 test_2853 = ((bool_t) 0);
						      }
						 }
						 if (test_2853)
						   {
						      unsigned char arg1910_1298;
						      {
							 long aux_2860;
							 aux_2860 = (offset_1279 - ((long) 1));
							 arg1910_1298 = STRING_REF(str_1247, aux_2860);
						      }
						      if ((arg1910_1298 >= ((unsigned char) '0')))
							{
							   test_2846 = (arg1910_1298 <= ((unsigned char) '9'));
							}
						      else
							{
							   test_2846 = ((bool_t) 0);
							}
						   }
						 else
						   {
						      test_2846 = ((bool_t) 0);
						   }
					      }
					    else
					      {
						 test_2846 = ((bool_t) 0);
					      }
					 }
					 if (test_2846)
					   {
					      {
						 long offset_2866;
						 offset_2866 = (offset_1279 - ((long) 3));
						 offset_1279 = offset_2866;
						 goto laap_1280;
					      }
					   }
					 else
					   {
					      {
						 obj_t arg1900_1289;
						 arg1900_1289 = c_substring(str_1247, read_1261, offset_1279);
						 {
						    obj_t list1902_1291;
						    {
						       obj_t arg1903_1292;
						       arg1903_1292 = MAKE_PAIR(string2379_cgen_prototype, BNIL);
						       list1902_1291 = MAKE_PAIR(arg1900_1289, arg1903_1292);
						    }
						    fprin_cgen_prototype(_c_port__188_cgen_emit, list1902_1291);
						 }
					      }
					      {
						 long rlen_2873;
						 long read_2872;
						 read_2872 = offset_1279;
						 {
						    long aux_2874;
						    aux_2874 = (offset_1279 - read_1261);
						    rlen_2873 = (rlen_1262 - aux_2874);
						 }
						 rlen_1262 = rlen_2873;
						 read_1261 = read_2872;
						 goto loop_1263;
					      }
					   }
				      }
				 }
			    }
		       }
		    }
		 }
	      }
	 }
      }
   }
}


/* emit-cnst-real */ obj_t 
emit_cnst_real_94_cgen_prototype(obj_t real_33, global_t global_34)
{
   set_variable_name__102_cgen_prototype((obj_t) (global_34));
   {
      obj_t arg1927_1313;
      obj_t arg1929_1315;
      arg1927_1313 = (((global_t) CREF(global_34))->name);
      {
	 obj_t arg1940_1326;
	 arg1940_1326 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, (((global_t) CREF(global_34))->name), BEOA);
	 arg1929_1315 = id__name_228_ast_ident(arg1940_1326);
      }
      {
	 obj_t list1932_1318;
	 {
	    obj_t arg1933_1319;
	    {
	       obj_t arg1934_1320;
	       {
		  obj_t arg1935_1321;
		  {
		     obj_t arg1936_1322;
		     {
			obj_t arg1937_1323;
			{
			   obj_t arg1938_1324;
			   arg1938_1324 = MAKE_PAIR(string2375_cgen_prototype, BNIL);
			   arg1937_1323 = MAKE_PAIR(real_33, arg1938_1324);
			}
			arg1936_1322 = MAKE_PAIR(string2370_cgen_prototype, arg1937_1323);
		     }
		     arg1935_1321 = MAKE_PAIR(arg1929_1315, arg1936_1322);
		  }
		  arg1934_1320 = MAKE_PAIR(string2370_cgen_prototype, arg1935_1321);
	       }
	       arg1933_1319 = MAKE_PAIR(arg1927_1313, arg1934_1320);
	    }
	    list1932_1318 = MAKE_PAIR(string2380_cgen_prototype, arg1933_1319);
	 }
	 return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1932_1318);
      }
   }
}


/* emit-cnst-sfun/sgfun */ obj_t 
emit_cnst_sfun_sgfun_176_cgen_prototype(obj_t fun_39, global_t global_40, char *kind_41)
{
   {
      bool_t test_2893;
      {
	 obj_t aux_2896;
	 obj_t aux_2894;
	 aux_2896 = CNST_TABLE_REF(((long) 8));
	 aux_2894 = (((global_t) CREF(global_40))->import);
	 test_2893 = (aux_2894 == aux_2896);
      }
      if (test_2893)
	{
	   return emit_prototype_23_cgen_prototype((((global_t) CREF(global_40))->value), (variable_t) (global_40));
	}
      else
	{
	   obj_t actuals_1330;
	   {
	      app_t obj_2317;
	      obj_2317 = (app_t) (fun_39);
	      actuals_1330 = (((app_t) CREF(obj_2317))->args);
	   }
	   {
	      obj_t entry_1331;
	      entry_1331 = CAR(actuals_1330);
	      {
		 obj_t arity_1332;
		 {
		    atom_t obj_2323;
		    {
		       obj_t aux_2905;
		       {
			  obj_t aux_2906;
			  aux_2906 = CDR(actuals_1330);
			  aux_2905 = CAR(aux_2906);
		       }
		       obj_2323 = (atom_t) (aux_2905);
		    }
		    arity_1332 = (((atom_t) CREF(obj_2323))->value);
		 }
		 {
		    obj_t vname_1333;
		    vname_1333 = set_variable_name__102_cgen_prototype((obj_t) (global_40));
		    {
		       obj_t name_1334;
		       {
			  obj_t aux_2913;
			  {
			     variable_t aux_2914;
			     {
				var_t obj_2324;
				obj_2324 = (var_t) (entry_1331);
				aux_2914 = (((var_t) CREF(obj_2324))->variable);
			     }
			     aux_2913 = (obj_t) (aux_2914);
			  }
			  name_1334 = set_variable_name__102_cgen_prototype(aux_2913);
		       }
		       {
			  {
			     bool_t test_2919;
			     {
				long aux_2920;
				aux_2920 = (long) CINT(arity_1332);
				test_2919 = (aux_2920 >= ((long) 0));
			     }
			     if (test_2919)
			       {
				  obj_t arg1945_1336;
				  obj_t arg1948_1338;
				  {
				     bool_t test_2923;
				     {
					obj_t aux_2926;
					obj_t aux_2924;
					aux_2926 = CNST_TABLE_REF(((long) 2));
					aux_2924 = (((global_t) CREF(global_40))->import);
					test_2923 = (aux_2924 == aux_2926);
				     }
				     if (test_2923)
				       {
					  obj_t list1964_1353;
					  {
					     obj_t arg1967_1355;
					     {
						obj_t arg1970_1356;
						arg1970_1356 = MAKE_PAIR(string2381_cgen_prototype, BNIL);
						{
						   obj_t aux_2930;
						   aux_2930 = string_to_bstring(kind_41);
						   arg1967_1355 = MAKE_PAIR(aux_2930, arg1970_1356);
						}
					     }
					     list1964_1353 = MAKE_PAIR(string2382_cgen_prototype, arg1967_1355);
					  }
					  arg1945_1336 = string_append_106___r4_strings_6_7(list1964_1353);
				       }
				     else
				       {
					  obj_t list1973_1359;
					  {
					     obj_t arg1975_1361;
					     {
						obj_t arg1977_1362;
						arg1977_1362 = MAKE_PAIR(string2381_cgen_prototype, BNIL);
						{
						   obj_t aux_2936;
						   aux_2936 = string_to_bstring(kind_41);
						   arg1975_1361 = MAKE_PAIR(aux_2936, arg1977_1362);
						}
					     }
					     list1973_1359 = MAKE_PAIR(string2383_cgen_prototype, arg1975_1361);
					  }
					  arg1945_1336 = string_append_106___r4_strings_6_7(list1973_1359);
				       }
				  }
				  {
				     obj_t arg1982_1367;
				     arg1982_1367 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, name_1334, BEOA);
				     arg1948_1338 = id__name_228_ast_ident(arg1982_1367);
				  }
				  {
				     obj_t list1952_1342;
				     {
					obj_t arg1953_1343;
					{
					   obj_t arg1954_1344;
					   {
					      obj_t arg1956_1345;
					      {
						 obj_t arg1957_1346;
						 {
						    obj_t arg1958_1347;
						    {
						       obj_t arg1959_1348;
						       {
							  obj_t arg1960_1349;
							  {
							     obj_t arg1961_1350;
							     arg1961_1350 = MAKE_PAIR(string2375_cgen_prototype, BNIL);
							     arg1960_1349 = MAKE_PAIR(arity_1332, arg1961_1350);
							  }
							  arg1959_1348 = MAKE_PAIR(string2384_cgen_prototype, arg1960_1349);
						       }
						       arg1958_1347 = MAKE_PAIR(name_1334, arg1959_1348);
						    }
						    arg1957_1346 = MAKE_PAIR(string2370_cgen_prototype, arg1958_1347);
						 }
						 arg1956_1345 = MAKE_PAIR(arg1948_1338, arg1957_1346);
					      }
					      arg1954_1344 = MAKE_PAIR(string2370_cgen_prototype, arg1956_1345);
					   }
					   arg1953_1343 = MAKE_PAIR(vname_1333, arg1954_1344);
					}
					list1952_1342 = MAKE_PAIR(arg1945_1336, arg1953_1343);
				     }
				     return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1952_1342);
				  }
			       }
			     else
			       {
				  obj_t arg1983_1368;
				  obj_t arg1985_1370;
				  {
				     bool_t test_2954;
				     {
					obj_t aux_2957;
					obj_t aux_2955;
					aux_2957 = CNST_TABLE_REF(((long) 2));
					aux_2955 = (((global_t) CREF(global_40))->import);
					test_2954 = (aux_2955 == aux_2957);
				     }
				     if (test_2954)
				       {
					  obj_t list2005_1387;
					  {
					     obj_t arg2008_1389;
					     {
						obj_t arg2010_1390;
						arg2010_1390 = MAKE_PAIR(string2381_cgen_prototype, BNIL);
						{
						   obj_t aux_2961;
						   aux_2961 = string_to_bstring(kind_41);
						   arg2008_1389 = MAKE_PAIR(aux_2961, arg2010_1390);
						}
					     }
					     list2005_1387 = MAKE_PAIR(string2382_cgen_prototype, arg2008_1389);
					  }
					  arg1983_1368 = string_append_106___r4_strings_6_7(list2005_1387);
				       }
				     else
				       {
					  obj_t list2013_1393;
					  {
					     obj_t arg2015_1395;
					     {
						obj_t arg2016_1396;
						arg2016_1396 = MAKE_PAIR(string2381_cgen_prototype, BNIL);
						{
						   obj_t aux_2967;
						   aux_2967 = string_to_bstring(kind_41);
						   arg2015_1395 = MAKE_PAIR(aux_2967, arg2016_1396);
						}
					     }
					     list2013_1393 = MAKE_PAIR(string2383_cgen_prototype, arg2015_1395);
					  }
					  arg1983_1368 = string_append_106___r4_strings_6_7(list2013_1393);
				       }
				  }
				  {
				     obj_t arg2021_1401;
				     arg2021_1401 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, name_1334, BEOA);
				     arg1985_1370 = id__name_228_ast_ident(arg2021_1401);
				  }
				  {
				     obj_t list1990_1375;
				     {
					obj_t arg1991_1376;
					{
					   obj_t arg1992_1377;
					   {
					      obj_t arg1993_1378;
					      {
						 obj_t arg1994_1379;
						 {
						    obj_t arg1995_1380;
						    {
						       obj_t arg1998_1381;
						       {
							  obj_t arg2000_1382;
							  {
							     obj_t arg2001_1383;
							     {
								obj_t arg2002_1384;
								arg2002_1384 = MAKE_PAIR(string2375_cgen_prototype, BNIL);
								arg2001_1383 = MAKE_PAIR(arity_1332, arg2002_1384);
							     }
							     arg2000_1382 = MAKE_PAIR(string2370_cgen_prototype, arg2001_1383);
							  }
							  arg1998_1381 = MAKE_PAIR(name_1334, arg2000_1382);
						       }
						       arg1995_1380 = MAKE_PAIR(string2370_cgen_prototype, arg1998_1381);
						    }
						    arg1994_1379 = MAKE_PAIR(string2385_cgen_prototype, arg1995_1380);
						 }
						 arg1993_1378 = MAKE_PAIR(arg1985_1370, arg1994_1379);
					      }
					      arg1992_1377 = MAKE_PAIR(string2370_cgen_prototype, arg1993_1378);
					   }
					   arg1991_1376 = MAKE_PAIR(vname_1333, arg1992_1377);
					}
					list1990_1375 = MAKE_PAIR(arg1983_1368, arg1991_1376);
				     }
				     return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1990_1375);
				  }
			       }
			  }
		       }
		    }
		 }
	      }
	   }
	}
   }
}


/* emit-cnst-stvector */ obj_t 
emit_cnst_stvector_253_cgen_prototype(obj_t tvec_42, global_t global_43)
{
   {
      obj_t vec_1406;
      vec_1406 = STRUCT_REF(tvec_42, ((long) 1));
      {
	 type_t itype_1407;
	 {
	    tvec_t obj_2339;
	    {
	       obj_t aux_2987;
	       aux_2987 = STRUCT_REF(tvec_42, ((long) 0));
	       obj_2339 = (tvec_t) (aux_2987);
	    }
	    {
	       obj_t aux_2990;
	       {
		  object_t aux_2991;
		  aux_2991 = (object_t) (obj_2339);
		  aux_2990 = OBJECT_WIDENING(aux_2991);
	       }
	       itype_1407 = (((tvec_t) CREF(aux_2990))->item_type_130);
	    }
	 }
	 {
	    obj_t c_vec_209_1408;
	    c_vec_209_1408 = tvector__c_vector_165_tvector_cnst(tvec_42);
	    {
	       set_variable_name__102_cgen_prototype((obj_t) (global_43));
	       {
		  obj_t aux_1409;
		  {
		     obj_t arg2054_1435;
		     arg2054_1435 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, (((global_t) CREF(global_43))->name), BEOA);
		     aux_1409 = id__name_228_ast_ident(arg2054_1435);
		  }
		  {
		     long arg2029_1412;
		     obj_t arg2031_1414;
		     obj_t arg2035_1417;
		     arg2029_1412 = VECTOR_LENGTH(vec_1406);
		     arg2031_1414 = string_sans___40_type_tools((((type_t) CREF(itype_1407))->name));
		     arg2035_1417 = (((global_t) CREF(global_43))->name);
		     {
			obj_t list2039_1420;
			{
			   obj_t arg2040_1421;
			   {
			      obj_t arg2041_1422;
			      {
				 obj_t arg2042_1423;
				 {
				    obj_t arg2043_1424;
				    {
				       obj_t arg2044_1425;
				       {
					  obj_t arg2045_1426;
					  {
					     obj_t arg2046_1427;
					     {
						obj_t arg2047_1428;
						{
						   obj_t arg2048_1429;
						   {
						      obj_t arg2049_1430;
						      {
							 obj_t arg2050_1431;
							 {
							    obj_t arg2051_1432;
							    arg2051_1432 = MAKE_PAIR(string2375_cgen_prototype, BNIL);
							    arg2050_1431 = MAKE_PAIR(aux_1409, arg2051_1432);
							 }
							 arg2049_1430 = MAKE_PAIR(string2370_cgen_prototype, arg2050_1431);
						      }
						      arg2048_1429 = MAKE_PAIR(arg2035_1417, arg2049_1430);
						   }
						   arg2047_1428 = MAKE_PAIR(string2386_cgen_prototype, arg2048_1429);
						}
						arg2046_1427 = MAKE_PAIR(c_vec_209_1408, arg2047_1428);
					     }
					     arg2045_1426 = MAKE_PAIR(string2387_cgen_prototype, arg2046_1427);
					  }
					  arg2044_1425 = MAKE_PAIR(arg2031_1414, arg2045_1426);
				       }
				       arg2043_1424 = MAKE_PAIR(string2370_cgen_prototype, arg2044_1425);
				    }
				    {
				       obj_t aux_3015;
				       aux_3015 = BINT(arg2029_1412);
				       arg2042_1423 = MAKE_PAIR(aux_3015, arg2043_1424);
				    }
				 }
				 arg2041_1422 = MAKE_PAIR(string2370_cgen_prototype, arg2042_1423);
			      }
			      arg2040_1421 = MAKE_PAIR(aux_1409, arg2041_1422);
			   }
			   list2039_1420 = MAKE_PAIR(string2388_cgen_prototype, arg2040_1421);
			}
			return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list2039_1420);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* set-variable-name! */ obj_t 
set_variable_name__102_cgen_prototype(obj_t variable_48)
{
   {
      bool_t test_3022;
      {
	 obj_t aux_3023;
	 {
	    variable_t obj_2344;
	    obj_2344 = (variable_t) (variable_48);
	    aux_3023 = (((variable_t) CREF(obj_2344))->name);
	 }
	 test_3022 = STRINGP(aux_3023);
      }
      if (test_3022)
	{
	   variable_t obj_2346;
	   obj_2346 = (variable_t) (variable_48);
	   return (((variable_t) CREF(obj_2346))->name);
	}
      else
	{
	   obj_t n_1440;
	   {
	      obj_t name_1441;
	      {
		 obj_t aux_3029;
		 {
		    variable_t obj_2347;
		    obj_2347 = (variable_t) (variable_48);
		    aux_3029 = (((variable_t) CREF(obj_2347))->id);
		 }
		 name_1441 = id__name_228_ast_ident(aux_3029);
	      }
	      {
		 bool_t test2058_1442;
		 test2058_1442 = is_a__118___object(variable_48, global_ast_var);
		 if (test2058_1442)
		   {
		      {
			 obj_t aux_3035;
			 {
			    global_t obj_2349;
			    obj_2349 = (global_t) (variable_48);
			    aux_3035 = (((global_t) CREF(obj_2349))->module);
			 }
			 n_1440 = qualified_name_205_cgen_prototype(name_1441, aux_3035);
		      }
		   }
		 else
		   {
		      bool_t test2059_1444;
		      test2059_1444 = is_a__118___object(variable_48, local_ast_var);
		      if (test2059_1444)
			{
			   {
			      obj_t list2062_1447;
			      {
				 obj_t arg2063_1448;
				 {
				    obj_t arg2064_1449;
				    {
				       obj_t aux_3041;
				       {
					  char *aux_3042;
					  {
					     long aux_3043;
					     {
						local_t obj_2351;
						obj_2351 = (local_t) (variable_48);
						aux_3043 = (((local_t) CREF(obj_2351))->key);
					     }
					     aux_3042 = integer__string_135___r4_numbers_6_5_fixnum(aux_3043, BNIL);
					  }
					  aux_3041 = string_to_bstring(aux_3042);
				       }
				       arg2064_1449 = MAKE_PAIR(aux_3041, BNIL);
				    }
				    arg2063_1448 = MAKE_PAIR(string2389_cgen_prototype, arg2064_1449);
				 }
				 list2062_1447 = MAKE_PAIR(name_1441, arg2063_1448);
			      }
			      n_1440 = string_append_106___r4_strings_6_7(list2062_1447);
			   }
			}
		      else
			{
			   {
			      obj_t arg2071_1455;
			      arg2071_1455 = shape_tools_shape(variable_48);
			      n_1440 = internal_error_43_tools_error(string2390_cgen_prototype, string2391_cgen_prototype, arg2071_1455);
			   }
			}
		   }
	      }
	   }
	   {
	      variable_t obj_2352;
	      obj_2352 = (variable_t) (variable_48);
	      ((((variable_t) CREF(obj_2352))->name) = ((obj_t) n_1440), BUNSPEC);
	   }
	   return n_1440;
	}
   }
}


/* _set-variable-name! */ obj_t 
_set_variable_name__28_cgen_prototype(obj_t env_2501, obj_t variable_2502)
{
   return set_variable_name__102_cgen_prototype(variable_2502);
}


/* qualified-name */ obj_t 
qualified_name_205_cgen_prototype(obj_t name_49, obj_t module_id_176_50)
{
   {
      obj_t arg2075_1459;
      arg2075_1459 = id__name_228_ast_ident(module_id_176_50);
      {
	 obj_t list2076_1460;
	 {
	    obj_t arg2077_1461;
	    {
	       obj_t arg2078_1462;
	       arg2078_1462 = MAKE_PAIR(arg2075_1459, BNIL);
	       arg2077_1461 = MAKE_PAIR(string2389_cgen_prototype, arg2078_1462);
	    }
	    list2076_1460 = MAKE_PAIR(name_49, arg2077_1461);
	 }
	 return string_append_106___r4_strings_6_7(list2076_1460);
      }
   }
}


/* _qualified-name2362 */ obj_t 
_qualified_name2362_177_cgen_prototype(obj_t env_2503, obj_t name_2504, obj_t module_id_176_2505)
{
   return qualified_name_205_cgen_prototype(name_2504, module_id_176_2505);
}


/* fprin */ bool_t 
fprin_cgen_prototype(obj_t port_51, obj_t obj_52)
{
   {
      obj_t l1671_1464;
      l1671_1464 = obj_52;
    lname1672_1465:
      if (PAIRP(l1671_1464))
	{
	   {
	      obj_t o_1467;
	      o_1467 = CAR(l1671_1464);
	      {
		 obj_t list2081_1468;
		 list2081_1468 = MAKE_PAIR(port_51, BNIL);
		 display___r4_output_6_10_3(o_1467, list2081_1468);
	      }
	   }
	   {
	      obj_t l1671_3068;
	      l1671_3068 = CDR(l1671_1464);
	      l1671_1464 = l1671_3068;
	      goto lname1672_1465;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_cgen_prototype()
{
   add_generic__110___object(emit_prototype_env_241_cgen_prototype, emit_prototype_default1674_env_181_cgen_prototype);
   add_inlined_method__244___object(emit_prototype_env_241_cgen_prototype, svar_ast_var, ((long) 0));
   add_inlined_method__244___object(emit_prototype_env_241_cgen_prototype, scnst_ast_var, ((long) 1));
   add_inlined_method__244___object(emit_prototype_env_241_cgen_prototype, sfun_ast_var, ((long) 2));
   add_inlined_method__244___object(emit_prototype_env_241_cgen_prototype, cfun_ast_var, ((long) 3));
   add_inlined_method__244___object(emit_prototype_env_241_cgen_prototype, cvar_ast_var, ((long) 4));
   add_generic__110___object(get_c_scope_env_161_cgen_prototype, get_c_scope_default1680_env_1_cgen_prototype);
   add_inlined_method__244___object(get_c_scope_env_161_cgen_prototype, global_ast_var, ((long) 0));
   {
      long aux_3078;
      aux_3078 = add_inlined_method__244___object(get_c_scope_env_161_cgen_prototype, local_ast_var, ((long) 1));
      return BINT(aux_3078);
   }
}


/* emit-prototype */ obj_t 
emit_prototype_23_cgen_prototype(value_t value_11, variable_t variable_12)
{
   {
      obj_t method2266_2042;
      obj_t class2271_2043;
      {
	 obj_t arg2274_2040;
	 obj_t arg2275_2041;
	 {
	    object_t obj_2394;
	    obj_2394 = (object_t) (value_11);
	    {
	       obj_t pre_method_105_2395;
	       pre_method_105_2395 = PROCEDURE_REF(emit_prototype_env_241_cgen_prototype, ((long) 2));
	       if (INTEGERP(pre_method_105_2395))
		 {
		    PROCEDURE_SET(emit_prototype_env_241_cgen_prototype, ((long) 2), BUNSPEC);
		    arg2274_2040 = pre_method_105_2395;
		 }
	       else
		 {
		    long obj_class_num_177_2400;
		    obj_class_num_177_2400 = TYPE(obj_2394);
		    {
		       obj_t arg1177_2401;
		       arg1177_2401 = PROCEDURE_REF(emit_prototype_env_241_cgen_prototype, ((long) 1));
		       {
			  long arg1178_2405;
			  {
			     long arg1179_2406;
			     arg1179_2406 = OBJECT_TYPE;
			     arg1178_2405 = (obj_class_num_177_2400 - arg1179_2406);
			  }
			  arg2274_2040 = VECTOR_REF(arg1177_2401, arg1178_2405);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2411;
	    object_2411 = (object_t) (value_11);
	    {
	       long arg1180_2412;
	       {
		  long arg1181_2413;
		  long arg1182_2414;
		  arg1181_2413 = TYPE(object_2411);
		  arg1182_2414 = OBJECT_TYPE;
		  arg1180_2412 = (arg1181_2413 - arg1182_2414);
	       }
	       {
		  obj_t vector_2418;
		  vector_2418 = _classes__134___object;
		  arg2275_2041 = VECTOR_REF(vector_2418, arg1180_2412);
	       }
	    }
	 }
	 method2266_2042 = arg2274_2040;
	 class2271_2043 = arg2275_2041;
	 {
	    if (INTEGERP(method2266_2042))
	      {
		 switch ((long) CINT(method2266_2042))
		   {
		   case ((long) 0):
		      {
			 obj_t aux_3098;
			 {
			    svar_t aux_3099;
			    aux_3099 = (svar_t) (value_11);
			    aux_3098 = (obj_t) (aux_3099);
			 }
			 return emit_prototype_svar_scnst_27_cgen_prototype(aux_3098, variable_12);
		      }
		      break;
		   case ((long) 1):
		      {
			 obj_t aux_3103;
			 {
			    scnst_t aux_3104;
			    aux_3104 = (scnst_t) (value_11);
			    aux_3103 = (obj_t) (aux_3104);
			 }
			 return emit_prototype_svar_scnst_27_cgen_prototype(aux_3103, variable_12);
		      }
		      break;
		   case ((long) 2):
		      {
			 sfun_t value_2053;
			 value_2053 = (sfun_t) (value_11);
			 set_variable_name__102_cgen_prototype((obj_t) (variable_12));
			 {
			    obj_t arg2278_2056;
			    arg2278_2056 = get_c_scope_184_cgen_prototype(variable_12);
			    {
			       obj_t list2279_2057;
			       {
				  obj_t arg2280_2058;
				  {
				     obj_t aux_3112;
				     aux_3112 = BCHAR(((unsigned char) ' '));
				     arg2280_2058 = MAKE_PAIR(aux_3112, BNIL);
				  }
				  list2279_2057 = MAKE_PAIR(arg2278_2056, arg2280_2058);
			       }
			       fprin_cgen_prototype(_c_port__188_cgen_emit, list2279_2057);
			    }
			 }
			 {
			    obj_t arg2282_2060;
			    arg2282_2060 = make_typed_declaration_180_type_tools((((variable_t) CREF(variable_12))->type), (((variable_t) CREF(variable_12))->name));
			    {
			       obj_t list2283_2061;
			       list2283_2061 = MAKE_PAIR(arg2282_2060, BNIL);
			       fprin_cgen_prototype(_c_port__188_cgen_emit, list2283_2061);
			    }
			 }
			 {
			    obj_t args_2065;
			    args_2065 = (((sfun_t) CREF(value_2053))->args);
			    {
			       bool_t test2288_2066;
			       if (PAIRP(args_2065))
				 {
				    test2288_2066 = is_a__118___object(CAR(args_2065), type_type_type);
				 }
			       else
				 {
				    test2288_2066 = ((bool_t) 0);
				 }
			       if (test2288_2066)
				 {
				    emit_prototype_formal_types_237_cgen_prototype(args_2065);
				 }
			       else
				 {
				    emit_prototype_formals_182_cgen_prototype(args_2065);
				 }
			    }
			 }
			 {
			    obj_t list2292_2069;
			    {
			       obj_t aux_3130;
			       aux_3130 = BCHAR(((unsigned char) ';'));
			       list2292_2069 = MAKE_PAIR(aux_3130, BNIL);
			    }
			    return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list2292_2069);
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 cfun_t value_2071;
			 value_2071 = (cfun_t) (value_11);
			 if ((((cfun_t) CREF(value_2071))->macro__33))
			   {
			      return BUNSPEC;
			   }
			 else
			   {
			      {
				 obj_t list2295_2075;
				 list2295_2075 = MAKE_PAIR(string2392_cgen_prototype, BNIL);
				 fprin_cgen_prototype(_c_port__188_cgen_emit, list2295_2075);
			      }
			      {
				 long arity_2078;
				 arity_2078 = (((cfun_t) CREF(value_2071))->arity);
				 {
				    obj_t targs_2079;
				    targs_2079 = (((cfun_t) CREF(value_2071))->args_type_205);
				    {
				       {
					  obj_t arg2299_2080;
					  {
					     obj_t aux_3144;
					     type_t aux_3141;
					     {
						global_t obj_2430;
						obj_2430 = (global_t) (variable_12);
						aux_3144 = (((global_t) CREF(obj_2430))->name);
					     }
					     {
						global_t obj_2429;
						obj_2429 = (global_t) (variable_12);
						aux_3141 = (((global_t) CREF(obj_2429))->type);
					     }
					     arg2299_2080 = make_typed_declaration_180_type_tools(aux_3141, aux_3144);
					  }
					  {
					     obj_t list2300_2081;
					     {
						obj_t arg2301_2082;
						{
						   obj_t aux_3148;
						   aux_3148 = BCHAR(((unsigned char) '('));
						   arg2301_2082 = MAKE_PAIR(aux_3148, BNIL);
						}
						list2300_2081 = MAKE_PAIR(arg2299_2080, arg2301_2082);
					     }
					     fprin_cgen_prototype(_c_port__188_cgen_emit, list2300_2081);
					  }
				       }
				       if (NULLP(targs_2079))
					 {
					    {
					       obj_t list2306_2087;
					       list2306_2087 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					       display___r4_output_6_10_3(BCHAR(((unsigned char) ')')), list2306_2087);
					    }
					 }
				       else
					 {
					    if ((arity_2078 <= ((long) -1)))
					      {
						 {
						    obj_t arg2309_2090;
						    {
						       type_t aux_3160;
						       {
							  obj_t aux_3161;
							  aux_3161 = CAR(targs_2079);
							  aux_3160 = (type_t) (aux_3161);
						       }
						       arg2309_2090 = type_name_sans___47_type_tools(aux_3160);
						    }
						    {
						       obj_t list2311_2092;
						       {
							  obj_t arg2312_2093;
							  arg2312_2093 = MAKE_PAIR(string2393_cgen_prototype, BNIL);
							  list2311_2092 = MAKE_PAIR(arg2309_2090, arg2312_2093);
						       }
						       {
							  bool_t aux_3167;
							  aux_3167 = fprin_cgen_prototype(_c_port__188_cgen_emit, list2311_2092);
							  BBOOL(aux_3167);
						       }
						    }
						 }
					      }
					    else
					      {
						 {
						    obj_t targs_2096;
						    {
						       bool_t aux_3170;
						       targs_2096 = targs_2079;
						     loop_2097:
						       {
							  bool_t test_3171;
							  {
							     obj_t aux_3172;
							     aux_3172 = CDR(targs_2096);
							     test_3171 = NULLP(aux_3172);
							  }
							  if (test_3171)
							    {
							       if ((arity_2078 < ((long) 0)))
								 {
								    obj_t list2322_2100;
								    list2322_2100 = MAKE_PAIR(string2394_cgen_prototype, BNIL);
								    aux_3170 = fprin_cgen_prototype(_c_port__188_cgen_emit, list2322_2100);
								 }
							       else
								 {
								    obj_t arg2325_2103;
								    {
								       type_t aux_3179;
								       {
									  obj_t aux_3180;
									  aux_3180 = CAR(targs_2096);
									  aux_3179 = (type_t) (aux_3180);
								       }
								       arg2325_2103 = type_name_sans___47_type_tools(aux_3179);
								    }
								    {
								       obj_t list2326_2104;
								       {
									  obj_t arg2327_2105;
									  {
									     obj_t aux_3184;
									     aux_3184 = BCHAR(((unsigned char) ')'));
									     arg2327_2105 = MAKE_PAIR(aux_3184, BNIL);
									  }
									  list2326_2104 = MAKE_PAIR(arg2325_2103, arg2327_2105);
								       }
								       aux_3170 = fprin_cgen_prototype(_c_port__188_cgen_emit, list2326_2104);
								    }
								 }
							    }
							  else
							    {
							       {
								  obj_t arg2330_2108;
								  {
								     type_t aux_3189;
								     {
									obj_t aux_3190;
									aux_3190 = CAR(targs_2096);
									aux_3189 = (type_t) (aux_3190);
								     }
								     arg2330_2108 = type_name_sans___47_type_tools(aux_3189);
								  }
								  {
								     obj_t list2332_2110;
								     {
									obj_t arg2333_2111;
									arg2333_2111 = MAKE_PAIR(string2370_cgen_prototype, BNIL);
									list2332_2110 = MAKE_PAIR(arg2330_2108, arg2333_2111);
								     }
								     fprin_cgen_prototype(_c_port__188_cgen_emit, list2332_2110);
								  }
							       }
							       {
								  obj_t targs_3197;
								  targs_3197 = CDR(targs_2096);
								  targs_2096 = targs_3197;
								  goto loop_2097;
							       }
							    }
						       }
						       BBOOL(aux_3170);
						    }
						 }
					      }
					 }
				       {
					  obj_t list2338_2116;
					  list2338_2116 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					  display___r4_output_6_10_3(BCHAR(((unsigned char) ';')), list2338_2116);
				       }
				       {
					  obj_t list2340_2118;
					  list2340_2118 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					  return newline___r4_output_6_10_3(list2340_2118);
				       }
				    }
				 }
			      }
			   }
		      }
		      break;
		   case ((long) 4):
		      {
			 cvar_t value_2120;
			 value_2120 = (cvar_t) (value_11);
			 if ((((cvar_t) CREF(value_2120))->macro__33))
			   {
			      return BUNSPEC;
			   }
			 else
			   {
			      obj_t arg2344_2125;
			      {
				 obj_t aux_3211;
				 type_t aux_3208;
				 {
				    global_t obj_2444;
				    obj_2444 = (global_t) (variable_12);
				    aux_3211 = (((global_t) CREF(obj_2444))->name);
				 }
				 {
				    global_t obj_2443;
				    obj_2443 = (global_t) (variable_12);
				    aux_3208 = (((global_t) CREF(obj_2443))->type);
				 }
				 arg2344_2125 = make_typed_declaration_180_type_tools(aux_3208, aux_3211);
			      }
			      {
				 obj_t list2345_2126;
				 {
				    obj_t arg2346_2127;
				    {
				       obj_t arg2347_2128;
				       {
					  obj_t aux_3215;
					  aux_3215 = BCHAR(((unsigned char) ';'));
					  arg2347_2128 = MAKE_PAIR(aux_3215, BNIL);
				       }
				       arg2346_2127 = MAKE_PAIR(arg2344_2125, arg2347_2128);
				    }
				    list2345_2126 = MAKE_PAIR(string2392_cgen_prototype, arg2346_2127);
				 }
				 return fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list2345_2126);
			      }
			   }
		      }
		      break;
		   default:
		    case_else2272_2046:
		      if (PROCEDUREP(method2266_2042))
			{
			   return PROCEDURE_ENTRY(method2266_2042) (method2266_2042, (obj_t) (value_11), (obj_t) (variable_12), BEOA);
			}
		      else
			{
			   obj_t fun2231_2001;
			   fun2231_2001 = PROCEDURE_REF(emit_prototype_env_241_cgen_prototype, ((long) 0));
			   return PROCEDURE_ENTRY(fun2231_2001) (fun2231_2001, (obj_t) (value_11), (obj_t) (variable_12), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2272_2046;
	      }
	 }
      }
   }
}


/* _emit-prototype2363 */ obj_t 
_emit_prototype2363_113_cgen_prototype(obj_t env_2506, obj_t value_2507, obj_t variable_2508)
{
   return emit_prototype_23_cgen_prototype((value_t) (value_2507), (variable_t) (variable_2508));
}


/* emit-prototype-default1674 */ obj_t 
emit_prototype_default1674_51_cgen_prototype(value_t value_13, variable_t variable_14)
{
   FAILURE(CNST_TABLE_REF(((long) 9)), string2395_cgen_prototype, (obj_t) (value_13));
}


/* _emit-prototype-default1674 */ obj_t 
_emit_prototype_default1674_111_cgen_prototype(obj_t env_2509, obj_t value_2510, obj_t variable_2511)
{
   return emit_prototype_default1674_51_cgen_prototype((value_t) (value_2510), (variable_t) (variable_2511));
}


/* get-c-scope */ obj_t 
get_c_scope_184_cgen_prototype(variable_t variable_44)
{
   {
      obj_t method2237_2010;
      obj_t class2242_2011;
      {
	 obj_t arg2246_2008;
	 obj_t arg2247_2009;
	 {
	    object_t obj_2452;
	    obj_2452 = (object_t) (variable_44);
	    {
	       obj_t pre_method_105_2453;
	       pre_method_105_2453 = PROCEDURE_REF(get_c_scope_env_161_cgen_prototype, ((long) 2));
	       if (INTEGERP(pre_method_105_2453))
		 {
		    PROCEDURE_SET(get_c_scope_env_161_cgen_prototype, ((long) 2), BUNSPEC);
		    arg2246_2008 = pre_method_105_2453;
		 }
	       else
		 {
		    long obj_class_num_177_2458;
		    obj_class_num_177_2458 = TYPE(obj_2452);
		    {
		       obj_t arg1177_2459;
		       arg1177_2459 = PROCEDURE_REF(get_c_scope_env_161_cgen_prototype, ((long) 1));
		       {
			  long arg1178_2463;
			  {
			     long arg1179_2464;
			     arg1179_2464 = OBJECT_TYPE;
			     arg1178_2463 = (obj_class_num_177_2458 - arg1179_2464);
			  }
			  arg2246_2008 = VECTOR_REF(arg1177_2459, arg1178_2463);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2469;
	    object_2469 = (object_t) (variable_44);
	    {
	       long arg1180_2470;
	       {
		  long arg1181_2471;
		  long arg1182_2472;
		  arg1181_2471 = TYPE(object_2469);
		  arg1182_2472 = OBJECT_TYPE;
		  arg1180_2470 = (arg1181_2471 - arg1182_2472);
	       }
	       {
		  obj_t vector_2476;
		  vector_2476 = _classes__134___object;
		  arg2247_2009 = VECTOR_REF(vector_2476, arg1180_2470);
	       }
	    }
	 }
	 method2237_2010 = arg2246_2008;
	 class2242_2011 = arg2247_2009;
	 {
	    if (INTEGERP(method2237_2010))
	      {
		 switch ((long) CINT(method2237_2010))
		   {
		   case ((long) 0):
		      {
			 global_t variable_2017;
			 variable_2017 = (global_t) (variable_44);
			 {
			    obj_t case_value_58_2019;
			    case_value_58_2019 = (((global_t) CREF(variable_2017))->import);
			    {
			       bool_t test_3262;
			       {
				  obj_t aux_3263;
				  aux_3263 = CNST_TABLE_REF(((long) 2));
				  test_3262 = (case_value_58_2019 == aux_3263);
			       }
			       if (test_3262)
				 {
				    return string2368_cgen_prototype;
				 }
			       else
				 {
				    bool_t test_3266;
				    {
				       obj_t aux_3267;
				       aux_3267 = CNST_TABLE_REF(((long) 8));
				       test_3266 = (case_value_58_2019 == aux_3267);
				    }
				    if (test_3266)
				      {
					 return string2396_cgen_prototype;
				      }
				    else
				      {
					 bool_t test_3270;
					 {
					    obj_t aux_3271;
					    aux_3271 = CNST_TABLE_REF(((long) 0));
					    test_3270 = (case_value_58_2019 == aux_3271);
					 }
					 if (test_3270)
					   {
					      return string2396_cgen_prototype;
					   }
					 else
					   {
					      return internal_error_43_tools_error(string2397_cgen_prototype, string2398_cgen_prototype, (((global_t) CREF(variable_2017))->import));
					   }
				      }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 1):
		      return string2368_cgen_prototype;
		      break;
		   default:
		    case_else2243_2014:
		      if (PROCEDUREP(method2237_2010))
			{
			   return PROCEDURE_ENTRY(method2237_2010) (method2237_2010, (obj_t) (variable_44), BEOA);
			}
		      else
			{
			   obj_t fun2234_2004;
			   fun2234_2004 = PROCEDURE_REF(get_c_scope_env_161_cgen_prototype, ((long) 0));
			   return PROCEDURE_ENTRY(fun2234_2004) (fun2234_2004, (obj_t) (variable_44), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2243_2014;
	      }
	 }
      }
   }
}


/* _get-c-scope2364 */ obj_t 
_get_c_scope2364_29_cgen_prototype(obj_t env_2512, obj_t variable_2513)
{
   return get_c_scope_184_cgen_prototype((variable_t) (variable_2513));
}


/* get-c-scope-default1680 */ obj_t 
get_c_scope_default1680_145_cgen_prototype(variable_t variable_45)
{
   FAILURE(CNST_TABLE_REF(((long) 10)), string2395_cgen_prototype, (obj_t) (variable_45));
}


/* _get-c-scope-default1680 */ obj_t 
_get_c_scope_default1680_185_cgen_prototype(obj_t env_2514, obj_t variable_2515)
{
   return get_c_scope_default1680_145_cgen_prototype((variable_t) (variable_2515));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_prototype()
{
   module_initialization_70_tools_error(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_tools_shape(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_engine_param(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_module_module(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_type_type(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_type_cache(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_type_tools(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_type_env(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_ast_var(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_ast_node(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_ast_env(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_ast_ident(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_tvector_tvector(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_tvector_cnst(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_cnst_alloc(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_cgen_cop(((long) 0), "CGEN_PROTOTYPE");
   module_initialization_70_cgen_emit(((long) 0), "CGEN_PROTOTYPE");
   return module_initialization_70_cgen_emit_cop_239(((long) 0), "CGEN_PROTOTYPE");
}
