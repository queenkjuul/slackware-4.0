/*===========================================================================*/
/*   (Integrate/node.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_node();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t glo___241_integrate_node(obj_t, variable_t);
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
extern obj_t globalize__167_integrate_node(node_t, variable_t, obj_t);
extern obj_t set_ex_it_116_ast_node;
extern bool_t integrate_celled__59_integrate_node(local_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_local__global_163(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t svar_iinfo_76_integrate_info;
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_integrate_node();
static obj_t celled_bindings_3_integrate_node(obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_integrate_node();
static obj_t _glo_1964_71_integrate_node(obj_t, obj_t, obj_t);
extern obj_t atom_ast_node;
static obj_t _globalize_1962_208_integrate_node(obj_t, obj_t, obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_integrate_node();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static make_box_202_t a_make_cell_117_integrate_node(node_t, variable_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static node_t glo__115_integrate_node(node_t, variable_t);
extern obj_t local_ast_var;
static obj_t cell_formals_12_integrate_node(obj_t, node_t);
extern obj_t the_global_201_integrate_local__global_163(local_t);
static obj_t _integrate_celled_1963_168_integrate_node(obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _glo__default1569_98_integrate_node(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static node_t glo__default1569_91_integrate_node(node_t, variable_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_integrate_node = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t globalize_local_fun__50_integrate_node(local_t, variable_t);
static obj_t cnst_init_137_integrate_node();
static obj_t __cnst[5];

DEFINE_STATIC_GENERIC(glo__env_172_integrate_node, _glo_1964_71_integrate_node1974, _glo_1964_71_integrate_node, 0L, 2);
DEFINE_EXPORT_PROCEDURE(globalize__env_187_integrate_node, _globalize_1962_208_integrate_node1975, _globalize_1962_208_integrate_node, 0L, 3);
DEFINE_EXPORT_PROCEDURE(integrate_celled__env_119_integrate_node, _integrate_celled_1963_168_integrate_node1976, _integrate_celled_1963_168_integrate_node, 0L, 1);
DEFINE_STRING(string1968_integrate_node, string1968_integrate_node1977, "GLO!-DEFAULT1569 AUX DONE (WRITE CELL-INTEGRATE) CELL-INTEGRATE ", 64);
DEFINE_STRING(string1967_integrate_node, string1967_integrate_node1978, "No method for this object", 25);
DEFINE_STRING(string1966_integrate_node, string1966_integrate_node1979, "Unexepected `closure' node", 26);
DEFINE_STRING(string1965_integrate_node, string1965_integrate_node1980, "node-free", 9);
DEFINE_STATIC_PROCEDURE(glo__default1569_env_87_integrate_node, _glo__default1569_98_integrate_node1981, _glo__default1569_98_integrate_node, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_integrate_node(long checksum_2189, char *from_2190)
{
   if (CBOOL(require_initialization_114_integrate_node))
     {
	require_initialization_114_integrate_node = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_node();
	cnst_init_137_integrate_node();
	imported_modules_init_94_integrate_node();
	method_init_76_integrate_node();
	toplevel_init_63_integrate_node();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_node()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_NODE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_NODE");
   module_initialization_70___reader(((long) 0), "INTEGRATE_NODE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_node()
{
   {
      obj_t cnst_port_138_2181;
      cnst_port_138_2181 = open_input_string(string1968_integrate_node);
      {
	 long i_2182;
	 i_2182 = ((long) 4);
       loop_2183:
	 {
	    bool_t test1969_2184;
	    test1969_2184 = (i_2182 == ((long) -1));
	    if (test1969_2184)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1970_2185;
		    {
		       obj_t list1971_2186;
		       {
			  obj_t arg1972_2187;
			  arg1972_2187 = BNIL;
			  list1971_2186 = MAKE_PAIR(cnst_port_138_2181, arg1972_2187);
		       }
		       arg1970_2185 = read___reader(list1971_2186);
		    }
		    CNST_TABLE_SET(i_2182, arg1970_2185);
		 }
		 {
		    int aux_2188;
		    {
		       long aux_2208;
		       aux_2208 = (i_2182 - ((long) 1));
		       aux_2188 = (int) (aux_2208);
		    }
		    {
		       long i_2211;
		       i_2211 = (long) (aux_2188);
		       i_2182 = i_2211;
		       goto loop_2183;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_node()
{
   return BUNSPEC;
}


/* globalize! */ obj_t 
globalize__167_integrate_node(node_t ast_1, variable_t integrator_2, obj_t what_by__117_3)
{
   {
      obj_t celled_938;
      {
	 obj_t aux_2213;
	 {
	    sfun_t obj_1655;
	    {
	       value_t aux_2214;
	       aux_2214 = (((variable_t) CREF(integrator_2))->value);
	       obj_1655 = (sfun_t) (aux_2214);
	    }
	    aux_2213 = (((sfun_t) CREF(obj_1655))->args);
	 }
	 celled_938 = celled_bindings_3_integrate_node(aux_2213);
      }
      {
	 obj_t what_by__117_939;
	 what_by__117_939 = append_2_18___r4_pairs_and_lists_6_3(celled_938, what_by__117_3);
	 {
	    {
	       obj_t l1517_940;
	       l1517_940 = what_by__117_939;
	     lname1518_941:
	       if (PAIRP(l1517_940))
		 {
		    {
		       obj_t w_b_127_943;
		       w_b_127_943 = CAR(l1517_940);
		       {
			  obj_t arg1603_945;
			  arg1603_945 = CDR(w_b_127_943);
			  {
			     local_t obj_1660;
			     {
				obj_t aux_2224;
				aux_2224 = CAR(w_b_127_943);
				obj_1660 = (local_t) (aux_2224);
			     }
			     ((((local_t) CREF(obj_1660))->fast_alpha_7) = ((obj_t) arg1603_945), BUNSPEC);
			  }
		       }
		    }
		    {
		       obj_t l1517_2228;
		       l1517_2228 = CDR(l1517_940);
		       l1517_940 = l1517_2228;
		       goto lname1518_941;
		    }
		 }
	       else
		 {
		    ((bool_t) 1);
		 }
	    }
	    {
	       obj_t res_947;
	       {
		  node_t arg1609_954;
		  arg1609_954 = glo__115_integrate_node(ast_1, integrator_2);
		  res_947 = cell_formals_12_integrate_node(celled_938, arg1609_954);
	       }
	       {
		  obj_t l1519_948;
		  l1519_948 = what_by__117_939;
		lname1520_949:
		  if (PAIRP(l1519_948))
		    {
		       {
			  local_t obj_1666;
			  {
			     obj_t aux_2234;
			     {
				obj_t aux_2235;
				aux_2235 = CAR(l1519_948);
				aux_2234 = CAR(aux_2235);
			     }
			     obj_1666 = (local_t) (aux_2234);
			  }
			  ((((local_t) CREF(obj_1666))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
		       }
		       {
			  obj_t l1519_2240;
			  l1519_2240 = CDR(l1519_948);
			  l1519_948 = l1519_2240;
			  goto lname1520_949;
		       }
		    }
		  else
		    {
		       ((bool_t) 1);
		    }
	       }
	       return res_947;
	    }
	 }
      }
   }
}


/* _globalize!1962 */ obj_t 
_globalize_1962_208_integrate_node(obj_t env_2169, obj_t ast_2170, obj_t integrator_2171, obj_t what_by__117_2172)
{
   return globalize__167_integrate_node((node_t) (ast_2170), (variable_t) (integrator_2171), what_by__117_2172);
}


/* celled-bindings */ obj_t 
celled_bindings_3_integrate_node(obj_t formals_4)
{
   {
      obj_t celled_956;
      obj_t formals_957;
      celled_956 = BNIL;
      formals_957 = formals_4;
    loop_958:
      if (NULLP(formals_957))
	{
	   return celled_956;
	}
      else
	{
	   bool_t test_2247;
	   {
	      local_t aux_2248;
	      {
		 obj_t aux_2249;
		 aux_2249 = CAR(formals_957);
		 aux_2248 = (local_t) (aux_2249);
	      }
	      test_2247 = integrate_celled__59_integrate_node(aux_2248);
	   }
	   if (test_2247)
	     {
		{
		   local_t var_962;
		   {
		      obj_t aux_2253;
		      {
			 local_t obj_1672;
			 {
			    obj_t aux_2254;
			    aux_2254 = CAR(formals_957);
			    obj_1672 = (local_t) (aux_2254);
			 }
			 aux_2253 = (((local_t) CREF(obj_1672))->id);
		      }
		      var_962 = make_local_svar_140_ast_local(aux_2253, (type_t) (_obj__252_type_cache));
		   }
		   {
		      obj_t o_n_168_963;
		      {
			 obj_t aux_2262;
			 obj_t aux_2260;
			 aux_2262 = (obj_t) (var_962);
			 aux_2260 = CAR(formals_957);
			 o_n_168_963 = MAKE_PAIR(aux_2260, aux_2262);
		      }
		      {
			 {
			    obj_t arg1615_964;
			    arg1615_964 = CNST_TABLE_REF(((long) 0));
			    ((((local_t) CREF(var_962))->access) = ((obj_t) arg1615_964), BUNSPEC);
			 }
			 {
			    svar_iinfo_76_t obj1522_965;
			    obj1522_965 = ((svar_iinfo_76_t) ((((local_t) CREF(var_962))->value)));
			    {
			       svar_iinfo_76_t arg1617_966;
			       {
				  svar_iinfo_76_t res1950_1688;
				  {
				     svar_iinfo_76_t new1438_1683;
				     new1438_1683 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
				     ((((svar_iinfo_76_t) CREF(new1438_1683))->f_mark_181) = ((obj_t) BUNSPEC), BUNSPEC);
				     ((((svar_iinfo_76_t) CREF(new1438_1683))->u_mark_209) = ((obj_t) BUNSPEC), BUNSPEC);
				     ((((svar_iinfo_76_t) CREF(new1438_1683))->kaptured__204) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				     ((((svar_iinfo_76_t) CREF(new1438_1683))->celled__113) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				     res1950_1688 = new1438_1683;
				  }
				  arg1617_966 = res1950_1688;
			       }
			       {
				  obj_t aux_2276;
				  object_t aux_2274;
				  aux_2276 = (obj_t) (arg1617_966);
				  aux_2274 = (object_t) (obj1522_965);
				  OBJECT_WIDENING_SET(aux_2274, aux_2276);
			       }
			    }
			    {
			       long arg1621_969;
			       arg1621_969 = class_num_218___object(svar_iinfo_76_integrate_info);
			       {
				  obj_t obj_1689;
				  obj_1689 = (obj_t) (obj1522_965);
				  (((obj_t) CREF(obj_1689))->header = MAKE_HEADER(arg1621_969, 0), BUNSPEC);
			       }
			    }
			    obj1522_965;
			 }
			 {
			    obj_t arg1622_970;
			    obj_t arg1623_971;
			    arg1622_970 = MAKE_PAIR(o_n_168_963, celled_956);
			    arg1623_971 = CDR(formals_957);
			    {
			       obj_t formals_2285;
			       obj_t celled_2284;
			       celled_2284 = arg1622_970;
			       formals_2285 = arg1623_971;
			       formals_957 = formals_2285;
			       celled_956 = celled_2284;
			       goto loop_958;
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
		{
		   obj_t formals_2286;
		   formals_2286 = CDR(formals_957);
		   formals_957 = formals_2286;
		   goto loop_958;
		}
	     }
	}
   }
}


/* cell-formals */ obj_t 
cell_formals_12_integrate_node(obj_t celled_5, node_t body_6)
{
   {
      bool_t test1631_977;
      test1631_977 = NULLP(celled_5);
      if (test1631_977)
	{
	   return (obj_t) (body_6);
	}
      else
	{
	   obj_t loc_978;
	   loc_978 = (((node_t) CREF(body_6))->loc);
	   {
	      obj_t arg1633_980;
	      obj_t arg1636_982;
	      arg1633_980 = ____74_type_cache;
	      if (test1631_977)
		{
		   arg1636_982 = BNIL;
		}
	      else
		{
		   obj_t head1526_986;
		   head1526_986 = MAKE_PAIR(BNIL, BNIL);
		   {
		      obj_t l1524_987;
		      obj_t tail1527_988;
		      l1524_987 = celled_5;
		      tail1527_988 = head1526_986;
		    lname1525_989:
		      if (NULLP(l1524_987))
			{
			   arg1636_982 = CDR(head1526_986);
			}
		      else
			{
			   obj_t newtail1528_991;
			   {
			      obj_t arg1645_993;
			      {
				 obj_t o_n_168_995;
				 o_n_168_995 = CAR(l1524_987);
				 {
				    obj_t arg1647_996;
				    make_box_202_t arg1648_997;
				    arg1647_996 = CDR(o_n_168_995);
				    {
				       var_t arg1649_998;
				       obj_t arg1650_999;
				       {
					  obj_t arg1653_1001;
					  arg1653_1001 = ____74_type_cache;
					  {
					     var_t res1951_1715;
					     {
						type_t type_1706;
						variable_t variable_1707;
						type_1706 = (type_t) (arg1653_1001);
						{
						   obj_t aux_2300;
						   aux_2300 = CAR(o_n_168_995);
						   variable_1707 = (variable_t) (aux_2300);
						}
						{
						   var_t new1209_1708;
						   new1209_1708 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						   {
						      long arg1745_1709;
						      arg1745_1709 = class_num_218___object(var_ast_node);
						      {
							 obj_t obj_1713;
							 obj_1713 = (obj_t) (new1209_1708);
							 (((obj_t) CREF(obj_1713))->header = MAKE_HEADER(arg1745_1709, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_2307;
						      aux_2307 = (object_t) (new1209_1708);
						      OBJECT_WIDENING_SET(aux_2307, BFALSE);
						   }
						   ((((var_t) CREF(new1209_1708))->loc) = ((obj_t) loc_978), BUNSPEC);
						   ((((var_t) CREF(new1209_1708))->type) = ((type_t) type_1706), BUNSPEC);
						   ((((var_t) CREF(new1209_1708))->variable) = ((variable_t) variable_1707), BUNSPEC);
						   res1951_1715 = new1209_1708;
						}
					     }
					     arg1649_998 = res1951_1715;
					  }
				       }
				       arg1650_999 = CAR(o_n_168_995);
				       arg1648_997 = a_make_cell_117_integrate_node((node_t) (arg1649_998), (variable_t) (arg1650_999));
				    }
				    {
				       obj_t aux_2317;
				       aux_2317 = (obj_t) (arg1648_997);
				       arg1645_993 = MAKE_PAIR(arg1647_996, aux_2317);
				    }
				 }
			      }
			      newtail1528_991 = MAKE_PAIR(arg1645_993, BNIL);
			   }
			   SET_CDR(tail1527_988, newtail1528_991);
			   {
			      obj_t tail1527_2324;
			      obj_t l1524_2322;
			      l1524_2322 = CDR(l1524_987);
			      tail1527_2324 = newtail1528_991;
			      tail1527_988 = tail1527_2324;
			      l1524_987 = l1524_2322;
			      goto lname1525_989;
			   }
			}
		   }
		}
	      {
		 let_var_6_t res1952_1742;
		 {
		    type_t type_1725;
		    obj_t key_1727;
		    type_1725 = (type_t) (arg1633_980);
		    key_1727 = BINT(((long) -1));
		    {
		       let_var_6_t new1368_1731;
		       new1368_1731 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		       {
			  long arg1709_1732;
			  arg1709_1732 = class_num_218___object(let_var_6_ast_node);
			  {
			     obj_t obj_1740;
			     obj_1740 = (obj_t) (new1368_1731);
			     (((obj_t) CREF(obj_1740))->header = MAKE_HEADER(arg1709_1732, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_2331;
			  aux_2331 = (object_t) (new1368_1731);
			  OBJECT_WIDENING_SET(aux_2331, BFALSE);
		       }
		       ((((let_var_6_t) CREF(new1368_1731))->loc) = ((obj_t) loc_978), BUNSPEC);
		       ((((let_var_6_t) CREF(new1368_1731))->type) = ((type_t) type_1725), BUNSPEC);
		       ((((let_var_6_t) CREF(new1368_1731))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((let_var_6_t) CREF(new1368_1731))->key) = ((obj_t) key_1727), BUNSPEC);
		       ((((let_var_6_t) CREF(new1368_1731))->bindings) = ((obj_t) arg1636_982), BUNSPEC);
		       ((((let_var_6_t) CREF(new1368_1731))->body) = ((node_t) body_6), BUNSPEC);
		       ((((let_var_6_t) CREF(new1368_1731))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		       res1952_1742 = new1368_1731;
		    }
		 }
		 return (obj_t) (res1952_1742);
	      }
	   }
	}
   }
}


/* a-make-cell */ make_box_202_t 
a_make_cell_117_integrate_node(node_t node_7, variable_t variable_8)
{
   {
      obj_t arg1657_1006;
      arg1657_1006 = CNST_TABLE_REF(((long) 0));
      {
	 local_t obj_1743;
	 obj_1743 = (local_t) (variable_8);
	 ((((local_t) CREF(obj_1743))->access) = ((obj_t) arg1657_1006), BUNSPEC);
      }
   }
   {
      svar_iinfo_76_t obj_1746;
      {
	 value_t aux_2345;
	 aux_2345 = (((variable_t) CREF(variable_8))->value);
	 obj_1746 = (svar_iinfo_76_t) (aux_2345);
      }
      {
	 obj_t aux_2348;
	 {
	    object_t aux_2349;
	    aux_2349 = (object_t) (obj_1746);
	    aux_2348 = OBJECT_WIDENING(aux_2349);
	 }
	 ((((svar_iinfo_76_t) CREF(aux_2348))->celled__113) = ((bool_t) ((bool_t) 1)), BUNSPEC);
      }
   }
   {
      obj_t arg1659_1008;
      obj_t arg1661_1009;
      arg1659_1008 = (((node_t) CREF(node_7))->loc);
      arg1661_1009 = ____74_type_cache;
      {
	 make_box_202_t res1953_1763;
	 {
	    type_t type_1750;
	    obj_t key_1752;
	    type_1750 = (type_t) (arg1661_1009);
	    key_1752 = BINT(((long) -1));
	    {
	       make_box_202_t new1404_1754;
	       new1404_1754 = ((make_box_202_t) BREF(GC_MALLOC(sizeof(struct make_box_202))));
	       {
		  long arg1703_1755;
		  arg1703_1755 = class_num_218___object(make_box_202_ast_node);
		  {
		     obj_t obj_1761;
		     obj_1761 = (obj_t) (new1404_1754);
		     (((obj_t) CREF(obj_1761))->header = MAKE_HEADER(arg1703_1755, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_2360;
		  aux_2360 = (object_t) (new1404_1754);
		  OBJECT_WIDENING_SET(aux_2360, BFALSE);
	       }
	       ((((make_box_202_t) CREF(new1404_1754))->loc) = ((obj_t) arg1659_1008), BUNSPEC);
	       ((((make_box_202_t) CREF(new1404_1754))->type) = ((type_t) type_1750), BUNSPEC);
	       ((((make_box_202_t) CREF(new1404_1754))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
	       ((((make_box_202_t) CREF(new1404_1754))->key) = ((obj_t) key_1752), BUNSPEC);
	       ((((make_box_202_t) CREF(new1404_1754))->value) = ((node_t) node_7), BUNSPEC);
	       res1953_1763 = new1404_1754;
	    }
	 }
	 return res1953_1763;
      }
   }
}


/* integrate-celled? */ bool_t 
integrate_celled__59_integrate_node(local_t variable_9)
{
   {
      bool_t _andtest_1532_1012;
      {
	 obj_t aux_2368;
	 {
	    value_t aux_2369;
	    {
	       variable_t obj_1764;
	       obj_1764 = (variable_t) (variable_9);
	       aux_2369 = (((variable_t) CREF(obj_1764))->value);
	    }
	    aux_2368 = (obj_t) (aux_2369);
	 }
	 _andtest_1532_1012 = is_a__118___object(aux_2368, svar_iinfo_76_integrate_info);
      }
      if (_andtest_1532_1012)
	{
	   bool_t _ortest_1533_1013;
	   {
	      svar_iinfo_76_t obj_1767;
	      {
		 value_t aux_2375;
		 {
		    variable_t obj_1766;
		    obj_1766 = (variable_t) (variable_9);
		    aux_2375 = (((variable_t) CREF(obj_1766))->value);
		 }
		 obj_1767 = (svar_iinfo_76_t) (aux_2375);
	      }
	      {
		 obj_t aux_2379;
		 {
		    object_t aux_2380;
		    aux_2380 = (object_t) (obj_1767);
		    aux_2379 = OBJECT_WIDENING(aux_2380);
		 }
		 _ortest_1533_1013 = (((svar_iinfo_76_t) CREF(aux_2379))->celled__113);
	      }
	   }
	   if (_ortest_1533_1013)
	     {
		return _ortest_1533_1013;
	     }
	   else
	     {
		bool_t test_2385;
		{
		   obj_t aux_2386;
		   {
		      obj_t aux_2387;
		      {
			 variable_t obj_1768;
			 obj_1768 = (variable_t) (variable_9);
			 aux_2387 = (((variable_t) CREF(obj_1768))->access);
		      }
		      aux_2386 = memq___r4_pairs_and_lists_6_3(aux_2387, CNST_TABLE_REF(((long) 1)));
		   }
		   test_2385 = CBOOL(aux_2386);
		}
		if (test_2385)
		  {
		     svar_iinfo_76_t obj_1770;
		     {
			value_t aux_2393;
			{
			   variable_t obj_1769;
			   obj_1769 = (variable_t) (variable_9);
			   aux_2393 = (((variable_t) CREF(obj_1769))->value);
			}
			obj_1770 = (svar_iinfo_76_t) (aux_2393);
		     }
		     {
			obj_t aux_2397;
			{
			   object_t aux_2398;
			   aux_2398 = (object_t) (obj_1770);
			   aux_2397 = OBJECT_WIDENING(aux_2398);
			}
			return (((svar_iinfo_76_t) CREF(aux_2397))->kaptured__204);
		     }
		  }
		else
		  {
		     return ((bool_t) 0);
		  }
	     }
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* _integrate-celled?1963 */ obj_t 
_integrate_celled_1963_168_integrate_node(obj_t env_2173, obj_t variable_2174)
{
   {
      bool_t aux_2402;
      aux_2402 = integrate_celled__59_integrate_node((local_t) (variable_2174));
      return BBOOL(aux_2402);
   }
}


/* glo*! */ obj_t 
glo___241_integrate_node(obj_t node__221_56, variable_t integrator_57)
{
   {
      obj_t node__221_1020;
      node__221_1020 = node__221_56;
    loop_1021:
      if (NULLP(node__221_1020))
	{
	   return CNST_TABLE_REF(((long) 2));
	}
      else
	{
	   {
	      node_t arg1672_1023;
	      {
		 node_t aux_2409;
		 {
		    obj_t aux_2410;
		    aux_2410 = CAR(node__221_1020);
		    aux_2409 = (node_t) (aux_2410);
		 }
		 arg1672_1023 = glo__115_integrate_node(aux_2409, integrator_57);
	      }
	      {
		 obj_t aux_2414;
		 aux_2414 = (obj_t) (arg1672_1023);
		 SET_CAR(node__221_1020, aux_2414);
	      }
	   }
	   {
	      obj_t node__221_2417;
	      node__221_2417 = CDR(node__221_1020);
	      node__221_1020 = node__221_2417;
	      goto loop_1021;
	   }
	}
   }
}


/* globalize-local-fun! */ obj_t 
globalize_local_fun__50_integrate_node(local_t local_58, variable_t integrator_59)
{
   {
      value_t fun_1026;
      fun_1026 = (((local_t) CREF(local_58))->value);
      {
	 obj_t obody_1027;
	 {
	    sfun_t obj_1777;
	    obj_1777 = (sfun_t) (fun_1026);
	    obody_1027 = (((sfun_t) CREF(obj_1777))->body);
	 }
	 {
	    {
	       bool_t test_2422;
	       {
		  obj_t aux_2425;
		  obj_t aux_2423;
		  aux_2425 = (obj_t) (integrator_59);
		  aux_2423 = (obj_t) (local_58);
		  test_2422 = (aux_2423 == aux_2425);
	       }
	       if (test_2422)
		 {
		    node_t arg1677_1029;
		    arg1677_1029 = glo__115_integrate_node((node_t) (obody_1027), integrator_59);
		    {
		       sfun_t obj_1780;
		       obj_t val1138_1781;
		       obj_1780 = (sfun_t) (fun_1026);
		       val1138_1781 = (obj_t) (arg1677_1029);
		       return ((((sfun_t) CREF(obj_1780))->body) = ((obj_t) val1138_1781), BUNSPEC);
		    }
		 }
	       else
		 {
		    obj_t celled_1030;
		    {
		       obj_t aux_2433;
		       {
			  sfun_t obj_1782;
			  obj_1782 = (sfun_t) (fun_1026);
			  aux_2433 = (((sfun_t) CREF(obj_1782))->args);
		       }
		       celled_1030 = celled_bindings_3_integrate_node(aux_2433);
		    }
		    {
		       obj_t l1565_1031;
		       l1565_1031 = celled_1030;
		     lname1566_1032:
		       if (PAIRP(l1565_1031))
			 {
			    {
			       obj_t w_b_127_1034;
			       w_b_127_1034 = CAR(l1565_1031);
			       {
				  obj_t arg1680_1036;
				  arg1680_1036 = CDR(w_b_127_1034);
				  {
				     variable_t obj_1787;
				     {
					obj_t aux_2441;
					aux_2441 = CAR(w_b_127_1034);
					obj_1787 = (variable_t) (aux_2441);
				     }
				     ((((variable_t) CREF(obj_1787))->fast_alpha_7) = ((obj_t) arg1680_1036), BUNSPEC);
				  }
			       }
			    }
			    {
			       obj_t l1565_2445;
			       l1565_2445 = CDR(l1565_1031);
			       l1565_1031 = l1565_2445;
			       goto lname1566_1032;
			    }
			 }
		       else
			 {
			    ((bool_t) 1);
			 }
		    }
		    {
		       node_t nbody1_1038;
		       nbody1_1038 = glo__115_integrate_node((node_t) (obody_1027), integrator_59);
		       {
			  obj_t nbody2_1039;
			  nbody2_1039 = cell_formals_12_integrate_node(celled_1030, nbody1_1038);
			  {
			     {
				obj_t l1567_1040;
				l1567_1040 = celled_1030;
			      lname1568_1041:
				if (PAIRP(l1567_1040))
				  {
				     {
					variable_t obj_1793;
					{
					   obj_t aux_2452;
					   {
					      obj_t aux_2453;
					      aux_2453 = CAR(l1567_1040);
					      aux_2452 = CAR(aux_2453);
					   }
					   obj_1793 = (variable_t) (aux_2452);
					}
					((((variable_t) CREF(obj_1793))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
				     }
				     {
					obj_t l1567_2458;
					l1567_2458 = CDR(l1567_1040);
					l1567_1040 = l1567_2458;
					goto lname1568_1041;
				     }
				  }
				else
				  {
				     ((bool_t) 1);
				  }
			     }
			     {
				sfun_t obj_1796;
				obj_1796 = (sfun_t) (fun_1026);
				return ((((sfun_t) CREF(obj_1796))->body) = ((obj_t) nbody2_1039), BUNSPEC);
			     }
			  }
		       }
		    }
		 }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_integrate_node()
{
   add_generic__110___object(glo__env_172_integrate_node, glo__default1569_env_87_integrate_node);
   add_inlined_method__244___object(glo__env_172_integrate_node, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(glo__env_172_integrate_node, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(glo__env_172_integrate_node, var_ast_node, ((long) 2));
   add_inlined_method__244___object(glo__env_172_integrate_node, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(glo__env_172_integrate_node, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(glo__env_172_integrate_node, app_ast_node, ((long) 5));
   add_inlined_method__244___object(glo__env_172_integrate_node, app_ly_162_ast_node, ((long) 6));
   add_inlined_method__244___object(glo__env_172_integrate_node, funcall_ast_node, ((long) 7));
   add_inlined_method__244___object(glo__env_172_integrate_node, pragma_ast_node, ((long) 8));
   add_inlined_method__244___object(glo__env_172_integrate_node, cast_ast_node, ((long) 9));
   add_inlined_method__244___object(glo__env_172_integrate_node, setq_ast_node, ((long) 10));
   add_inlined_method__244___object(glo__env_172_integrate_node, conditional_ast_node, ((long) 11));
   add_inlined_method__244___object(glo__env_172_integrate_node, fail_ast_node, ((long) 12));
   add_inlined_method__244___object(glo__env_172_integrate_node, select_ast_node, ((long) 13));
   add_inlined_method__244___object(glo__env_172_integrate_node, let_fun_218_ast_node, ((long) 14));
   add_inlined_method__244___object(glo__env_172_integrate_node, let_var_6_ast_node, ((long) 15));
   add_inlined_method__244___object(glo__env_172_integrate_node, set_ex_it_116_ast_node, ((long) 16));
   add_inlined_method__244___object(glo__env_172_integrate_node, jump_ex_it_184_ast_node, ((long) 17));
   add_inlined_method__244___object(glo__env_172_integrate_node, make_box_202_ast_node, ((long) 18));
   add_inlined_method__244___object(glo__env_172_integrate_node, box_ref_242_ast_node, ((long) 19));
   {
      long aux_2483;
      aux_2483 = add_inlined_method__244___object(glo__env_172_integrate_node, box_set__221_ast_node, ((long) 20));
      return BINT(aux_2483);
   }
}


/* glo! */ node_t 
glo__115_integrate_node(node_t node_10, variable_t integrator_11)
{
   {
      obj_t method1792_1424;
      obj_t class1797_1425;
      {
	 obj_t arg1800_1422;
	 obj_t arg1802_1423;
	 {
	    object_t obj_1897;
	    obj_1897 = (object_t) (node_10);
	    {
	       obj_t pre_method_105_1898;
	       pre_method_105_1898 = PROCEDURE_REF(glo__env_172_integrate_node, ((long) 2));
	       if (INTEGERP(pre_method_105_1898))
		 {
		    PROCEDURE_SET(glo__env_172_integrate_node, ((long) 2), BUNSPEC);
		    arg1800_1422 = pre_method_105_1898;
		 }
	       else
		 {
		    long obj_class_num_177_1903;
		    obj_class_num_177_1903 = TYPE(obj_1897);
		    {
		       obj_t arg1177_1904;
		       arg1177_1904 = PROCEDURE_REF(glo__env_172_integrate_node, ((long) 1));
		       {
			  long arg1178_1908;
			  {
			     long arg1179_1909;
			     arg1179_1909 = OBJECT_TYPE;
			     arg1178_1908 = (obj_class_num_177_1903 - arg1179_1909);
			  }
			  arg1800_1422 = VECTOR_REF(arg1177_1904, arg1178_1908);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1914;
	    object_1914 = (object_t) (node_10);
	    {
	       long arg1180_1915;
	       {
		  long arg1181_1916;
		  long arg1182_1917;
		  arg1181_1916 = TYPE(object_1914);
		  arg1182_1917 = OBJECT_TYPE;
		  arg1180_1915 = (arg1181_1916 - arg1182_1917);
	       }
	       {
		  obj_t vector_1921;
		  vector_1921 = _classes__134___object;
		  arg1802_1423 = VECTOR_REF(vector_1921, arg1180_1915);
	       }
	    }
	 }
	 {
	    obj_t aux_2501;
	    method1792_1424 = arg1800_1422;
	    class1797_1425 = arg1802_1423;
	    {
	       if (INTEGERP(method1792_1424))
		 {
		    switch ((long) CINT(method1792_1424))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_2504;
			    aux_2504 = (atom_t) (node_10);
			    aux_2501 = (obj_t) (aux_2504);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_2507;
			    aux_2507 = (kwote_t) (node_10);
			    aux_2501 = (obj_t) (aux_2507);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1435;
			    node_1435 = (var_t) (node_10);
			    {
			       variable_t var_1437;
			       var_1437 = (((var_t) CREF(node_1435))->variable);
			       {
				  obj_t alpha_1438;
				  alpha_1438 = (((variable_t) CREF(var_1437))->fast_alpha_7);
				  {
				     {
					bool_t test1805_1439;
					test1805_1439 = is_a__118___object(alpha_1438, local_ast_var);
					if (test1805_1439)
					  {
					     {
						variable_t val1215_1927;
						val1215_1927 = (variable_t) (alpha_1438);
						((((var_t) CREF(node_1435))->variable) = ((variable_t) val1215_1927), BUNSPEC);
					     }
					     {
						node_t aux_2517;
						aux_2517 = glo__115_integrate_node((node_t) (node_1435), integrator_11);
						aux_2501 = (obj_t) (aux_2517);
					     }
					  }
					else
					  {
					     bool_t test1806_1440;
					     test1806_1440 = is_a__118___object((obj_t) (var_1437), global_ast_var);
					     if (test1806_1440)
					       {
						  aux_2501 = (obj_t) (node_1435);
					       }
					     else
					       {
						  if (integrate_celled__59_integrate_node((local_t) (var_1437)))
						    {
						       {
							  obj_t arg1808_1442;
							  arg1808_1442 = CNST_TABLE_REF(((long) 0));
							  {
							     local_t obj_1929;
							     obj_1929 = (local_t) (var_1437);
							     ((((local_t) CREF(obj_1929))->access) = ((obj_t) arg1808_1442), BUNSPEC);
							  }
						       }
						       {
							  obj_t arg1809_1443;
							  type_t arg1810_1444;
							  {
							     node_t obj_1931;
							     obj_1931 = (node_t) (node_1435);
							     arg1809_1443 = (((node_t) CREF(obj_1931))->loc);
							  }
							  {
							     node_t obj_1932;
							     obj_1932 = (node_t) (node_1435);
							     arg1810_1444 = (((node_t) CREF(obj_1932))->type);
							  }
							  {
							     box_ref_242_t res1954_1947;
							     {
								obj_t key_1936;
								key_1936 = BINT(((long) -1));
								{
								   box_ref_242_t new1416_1938;
								   new1416_1938 = ((box_ref_242_t) BREF(GC_MALLOC(sizeof(struct box_ref_242))));
								   {
								      long arg1701_1939;
								      arg1701_1939 = class_num_218___object(box_ref_242_ast_node);
								      {
									 obj_t obj_1945;
									 obj_1945 = (obj_t) (new1416_1938);
									 (((obj_t) CREF(obj_1945))->header = MAKE_HEADER(arg1701_1939, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_2540;
								      aux_2540 = (object_t) (new1416_1938);
								      OBJECT_WIDENING_SET(aux_2540, BFALSE);
								   }
								   ((((box_ref_242_t) CREF(new1416_1938))->loc) = ((obj_t) arg1809_1443), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1416_1938))->type) = ((type_t) arg1810_1444), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1416_1938))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1416_1938))->key) = ((obj_t) key_1936), BUNSPEC);
								   ((((box_ref_242_t) CREF(new1416_1938))->var) = ((var_t) node_1435), BUNSPEC);
								   res1954_1947 = new1416_1938;
								}
							     }
							     aux_2501 = (obj_t) (res1954_1947);
							  }
						       }
						    }
						  else
						    {
						       aux_2501 = (obj_t) (node_1435);
						    }
					       }
					  }
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    obj_t arg1815_1451;
			    {
			       obj_t aux_2550;
			       {
				  closure_t aux_2551;
				  aux_2551 = (closure_t) (node_10);
				  aux_2550 = (obj_t) (aux_2551);
			       }
			       arg1815_1451 = shape_tools_shape(aux_2550);
			    }
			    aux_2501 = internal_error_43_tools_error(string1965_integrate_node, string1966_integrate_node, arg1815_1451);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1452;
			    node_1452 = (sequence_t) (node_10);
			    glo___241_integrate_node((((sequence_t) CREF(node_1452))->nodes), integrator_11);
			    aux_2501 = (obj_t) (node_1452);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_t node_1456;
			    node_1456 = (app_t) (node_10);
			    {
			       variable_t fun_1459;
			       {
				  var_t arg1843_1493;
				  arg1843_1493 = (((app_t) CREF(node_1456))->fun);
				  fun_1459 = (((var_t) CREF(arg1843_1493))->variable);
			       }
			       {
				  value_t info_1460;
				  info_1460 = (((variable_t) CREF(fun_1459))->value);
				  {
				     {
					bool_t test1817_1461;
					{
					   bool_t test1823_1466;
					   test1823_1466 = is_a__118___object((obj_t) (fun_1459), local_ast_var);
					   if (test1823_1466)
					     {
						sfun_iinfo_105_t obj_1953;
						obj_1953 = (sfun_iinfo_105_t) (info_1460);
						{
						   obj_t aux_2568;
						   {
						      object_t aux_2569;
						      aux_2569 = (object_t) (obj_1953);
						      aux_2568 = OBJECT_WIDENING(aux_2569);
						   }
						   test1817_1461 = (((sfun_iinfo_105_t) CREF(aux_2568))->g__219);
						}
					     }
					   else
					     {
						test1817_1461 = ((bool_t) 0);
					     }
					}
					if (test1817_1461)
					  {
					     var_t arg1818_1462;
					     {
						obj_t arg1820_1463;
						type_t arg1821_1464;
						obj_t arg1822_1465;
						arg1820_1463 = (((app_t) CREF(node_1456))->loc);
						arg1821_1464 = (((app_t) CREF(node_1456))->type);
						arg1822_1465 = the_global_201_integrate_local__global_163((local_t) (fun_1459));
						{
						   var_t res1955_1966;
						   {
						      variable_t variable_1958;
						      variable_1958 = (variable_t) (arg1822_1465);
						      {
							 var_t new1209_1959;
							 new1209_1959 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							 {
							    long arg1745_1960;
							    arg1745_1960 = class_num_218___object(var_ast_node);
							    {
							       obj_t obj_1964;
							       obj_1964 = (obj_t) (new1209_1959);
							       (((obj_t) CREF(obj_1964))->header = MAKE_HEADER(arg1745_1960, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_2583;
							    aux_2583 = (object_t) (new1209_1959);
							    OBJECT_WIDENING_SET(aux_2583, BFALSE);
							 }
							 ((((var_t) CREF(new1209_1959))->loc) = ((obj_t) arg1820_1463), BUNSPEC);
							 ((((var_t) CREF(new1209_1959))->type) = ((type_t) arg1821_1464), BUNSPEC);
							 ((((var_t) CREF(new1209_1959))->variable) = ((variable_t) variable_1958), BUNSPEC);
							 res1955_1966 = new1209_1959;
						      }
						   }
						   arg1818_1462 = res1955_1966;
						}
					     }
					     ((((app_t) CREF(node_1456))->fun) = ((var_t) arg1818_1462), BUNSPEC);
					  }
					else
					  {
					     BUNSPEC;
					  }
				     }
				     {
					obj_t nodes_1467;
					nodes_1467 = (((app_t) CREF(node_1456))->args);
				      liip_1468:
					if (NULLP(nodes_1467))
					  {
					     CNST_TABLE_REF(((long) 2));
					  }
					else
					  {
					     {
						node_t arg1826_1471;
						{
						   node_t aux_2593;
						   {
						      obj_t aux_2594;
						      aux_2594 = CAR(nodes_1467);
						      aux_2593 = (node_t) (aux_2594);
						   }
						   arg1826_1471 = glo__115_integrate_node(aux_2593, integrator_11);
						}
						{
						   obj_t aux_2598;
						   aux_2598 = (obj_t) (arg1826_1471);
						   SET_CAR(nodes_1467, aux_2598);
						}
					     }
					     {
						obj_t nodes_2601;
						nodes_2601 = CDR(nodes_1467);
						nodes_1467 = nodes_2601;
						goto liip_1468;
					     }
					  }
				     }
				     {
					bool_t test1830_1474;
					{
					   bool_t test1841_1491;
					   test1841_1491 = is_a__118___object((obj_t) (fun_1459), global_ast_var);
					   if (test1841_1491)
					     {
						test1830_1474 = ((bool_t) 1);
					     }
					   else
					     {
						bool_t test_2607;
						{
						   sfun_iinfo_105_t obj_1976;
						   obj_1976 = (sfun_iinfo_105_t) (info_1460);
						   {
						      obj_t aux_2609;
						      {
							 object_t aux_2610;
							 aux_2610 = (object_t) (obj_1976);
							 aux_2609 = OBJECT_WIDENING(aux_2610);
						      }
						      test_2607 = (((sfun_iinfo_105_t) CREF(aux_2609))->g__219);
						   }
						}
						if (test_2607)
						  {
						     test1830_1474 = ((bool_t) 0);
						  }
						else
						  {
						     test1830_1474 = ((bool_t) 1);
						  }
					     }
					}
					if (test1830_1474)
					  {
					     CNST_TABLE_REF(((long) 2));
					  }
					else
					  {
					     {
						obj_t new_actuals_73_1475;
						obj_t kaptured_1476;
						new_actuals_73_1475 = (((app_t) CREF(node_1456))->args);
						{
						   sfun_iinfo_105_t obj_1978;
						   obj_1978 = (sfun_iinfo_105_t) (info_1460);
						   {
						      obj_t aux_2645;
						      {
							 object_t aux_2646;
							 aux_2646 = (object_t) (obj_1978);
							 aux_2645 = OBJECT_WIDENING(aux_2646);
						      }
						      kaptured_1476 = (((sfun_iinfo_105_t) CREF(aux_2645))->kaptured);
						   }
						}
					      loop_1477:
						if (NULLP(kaptured_1476))
						  {
						     ((((app_t) CREF(node_1456))->args) = ((obj_t) new_actuals_73_1475), BUNSPEC);
						  }
						else
						  {
						     obj_t kap_1481;
						     kap_1481 = CAR(kaptured_1476);
						     {
							obj_t alpha_1482;
							{
							   local_t obj_1983;
							   obj_1983 = (local_t) (kap_1481);
							   alpha_1482 = (((local_t) CREF(obj_1983))->fast_alpha_7);
							}
							{
							   obj_t var_1483;
							   {
							      bool_t test1840_1490;
							      test1840_1490 = is_a__118___object(alpha_1482, local_ast_var);
							      if (test1840_1490)
								{
								   var_1483 = alpha_1482;
								}
							      else
								{
								   var_1483 = kap_1481;
								}
							   }
							   {
							      {
								 obj_t arg1834_1484;
								 obj_t arg1835_1485;
								 {
								    var_t arg1836_1486;
								    {
								       obj_t arg1837_1487;
								       obj_t arg1838_1488;
								       arg1837_1487 = (((app_t) CREF(node_1456))->loc);
								       arg1838_1488 = ____74_type_cache;
								       {
									  var_t res1956_1996;
									  {
									     type_t type_1987;
									     variable_t variable_1988;
									     type_1987 = (type_t) (arg1838_1488);
									     variable_1988 = (variable_t) (var_1483);
									     {
										var_t new1209_1989;
										new1209_1989 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
										{
										   long arg1745_1990;
										   arg1745_1990 = class_num_218___object(var_ast_node);
										   {
										      obj_t obj_1994;
										      obj_1994 = (obj_t) (new1209_1989);
										      (((obj_t) CREF(obj_1994))->header = MAKE_HEADER(arg1745_1990, 0), BUNSPEC);
										   }
										}
										{
										   object_t aux_2631;
										   aux_2631 = (object_t) (new1209_1989);
										   OBJECT_WIDENING_SET(aux_2631, BFALSE);
										}
										((((var_t) CREF(new1209_1989))->loc) = ((obj_t) arg1837_1487), BUNSPEC);
										((((var_t) CREF(new1209_1989))->type) = ((type_t) type_1987), BUNSPEC);
										((((var_t) CREF(new1209_1989))->variable) = ((variable_t) variable_1988), BUNSPEC);
										res1956_1996 = new1209_1989;
									     }
									  }
									  arg1836_1486 = res1956_1996;
								       }
								    }
								    {
								       obj_t aux_2637;
								       aux_2637 = (obj_t) (arg1836_1486);
								       arg1834_1484 = MAKE_PAIR(aux_2637, new_actuals_73_1475);
								    }
								 }
								 arg1835_1485 = CDR(kaptured_1476);
								 {
								    obj_t kaptured_2642;
								    obj_t new_actuals_73_2641;
								    new_actuals_73_2641 = arg1834_1484;
								    kaptured_2642 = arg1835_1485;
								    kaptured_1476 = kaptured_2642;
								    new_actuals_73_1475 = new_actuals_73_2641;
								    goto loop_1477;
								 }
							      }
							   }
							}
						     }
						  }
					     }
					  }
				     }
				     aux_2501 = (obj_t) (node_1456);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    app_ly_162_t node_1494;
			    node_1494 = (app_ly_162_t) (node_10);
			    {
			       node_t arg1847_1497;
			       arg1847_1497 = glo__115_integrate_node((((app_ly_162_t) CREF(node_1494))->fun), integrator_11);
			       ((((app_ly_162_t) CREF(node_1494))->fun) = ((node_t) arg1847_1497), BUNSPEC);
			    }
			    {
			       node_t arg1850_1499;
			       arg1850_1499 = glo__115_integrate_node((((app_ly_162_t) CREF(node_1494))->arg), integrator_11);
			       ((((app_ly_162_t) CREF(node_1494))->arg) = ((node_t) arg1850_1499), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1494);
			 }
			 break;
		      case ((long) 7):
			 {
			    funcall_t node_1501;
			    node_1501 = (funcall_t) (node_10);
			    {
			       node_t arg1852_1504;
			       arg1852_1504 = glo__115_integrate_node((((funcall_t) CREF(node_1501))->fun), integrator_11);
			       ((((funcall_t) CREF(node_1501))->fun) = ((node_t) arg1852_1504), BUNSPEC);
			    }
			    glo___241_integrate_node((((funcall_t) CREF(node_1501))->args), integrator_11);
			    aux_2501 = (obj_t) (node_1501);
			 }
			 break;
		      case ((long) 8):
			 {
			    pragma_t node_1507;
			    node_1507 = (pragma_t) (node_10);
			    glo___241_integrate_node((((pragma_t) CREF(node_1507))->args), integrator_11);
			    aux_2501 = (obj_t) (node_1507);
			 }
			 break;
		      case ((long) 9):
			 {
			    cast_t node_1511;
			    node_1511 = (cast_t) (node_10);
			    glo__115_integrate_node((((cast_t) CREF(node_1511))->arg), integrator_11);
			    aux_2501 = (obj_t) (node_1511);
			 }
			 break;
		      case ((long) 10):
			 {
			    setq_t node_1515;
			    node_1515 = (setq_t) (node_10);
			    {
			       node_t arg1859_1518;
			       arg1859_1518 = glo__115_integrate_node((((setq_t) CREF(node_1515))->value), integrator_11);
			       ((((setq_t) CREF(node_1515))->value) = ((node_t) arg1859_1518), BUNSPEC);
			    }
			    {
			       variable_t var_1520;
			       {
				  var_t arg1893_1556;
				  arg1893_1556 = (((setq_t) CREF(node_1515))->var);
				  var_1520 = (((var_t) CREF(arg1893_1556))->variable);
			       }
			       {
				  obj_t var_1521;
				  obj_t alpha_1522;
				  var_1521 = (obj_t) (var_1520);
				  alpha_1522 = (((variable_t) CREF(var_1520))->fast_alpha_7);
				loop_1523:
				  {
				     bool_t test1862_1525;
				     test1862_1525 = is_a__118___object(alpha_1522, local_ast_var);
				     if (test1862_1525)
				       {
					  {
					     var_t arg1863_1526;
					     arg1863_1526 = (((setq_t) CREF(node_1515))->var);
					     {
						variable_t val1215_2021;
						val1215_2021 = (variable_t) (alpha_1522);
						((((var_t) CREF(arg1863_1526))->variable) = ((variable_t) val1215_2021), BUNSPEC);
					     }
					  }
					  {
					     obj_t alpha_2686;
					     obj_t var_2685;
					     var_2685 = alpha_1522;
					     {
						variable_t obj_2022;
						obj_2022 = (variable_t) (alpha_1522);
						alpha_2686 = (((variable_t) CREF(obj_2022))->fast_alpha_7);
					     }
					     alpha_1522 = alpha_2686;
					     var_1521 = var_2685;
					     goto loop_1523;
					  }
				       }
				     else
				       {
					  variable_t var_1528;
					  {
					     var_t arg1892_1555;
					     arg1892_1555 = (((setq_t) CREF(node_1515))->var);
					     var_1528 = (((var_t) CREF(arg1892_1555))->variable);
					  }
					  {
					     bool_t test1865_1529;
					     {
						bool_t test1891_1554;
						test1891_1554 = is_a__118___object((obj_t) (var_1528), local_ast_var);
						if (test1891_1554)
						  {
						     test1865_1529 = integrate_celled__59_integrate_node((local_t) (var_1528));
						  }
						else
						  {
						     test1865_1529 = ((bool_t) 0);
						  }
					     }
					     if (test1865_1529)
					       {
						  local_t a_var_30_1530;
						  obj_t loc_1531;
						  a_var_30_1530 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 3)), (type_t) (_obj__252_type_cache));
						  {
						     node_t obj_2026;
						     obj_2026 = (node_t) (node_1515);
						     loc_1531 = (((node_t) CREF(obj_2026))->loc);
						  }
						  {
						     obj_t arg1866_1532;
						     arg1866_1532 = CNST_TABLE_REF(((long) 0));
						     {
							local_t obj_2027;
							obj_2027 = (local_t) (var_1528);
							((((local_t) CREF(obj_2027))->access) = ((obj_t) arg1866_1532), BUNSPEC);
						     }
						  }
						  {
						     svar_iinfo_76_t obj1545_1533;
						     obj1545_1533 = ((svar_iinfo_76_t) ((((local_t) CREF(a_var_30_1530))->value)));
						     {
							svar_iinfo_76_t arg1867_1534;
							{
							   svar_iinfo_76_t res1957_2039;
							   {
							      svar_iinfo_76_t new1438_2034;
							      new1438_2034 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
							      ((((svar_iinfo_76_t) CREF(new1438_2034))->f_mark_181) = ((obj_t) BUNSPEC), BUNSPEC);
							      ((((svar_iinfo_76_t) CREF(new1438_2034))->u_mark_209) = ((obj_t) BUNSPEC), BUNSPEC);
							      ((((svar_iinfo_76_t) CREF(new1438_2034))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							      ((((svar_iinfo_76_t) CREF(new1438_2034))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							      res1957_2039 = new1438_2034;
							   }
							   arg1867_1534 = res1957_2039;
							}
							{
							   obj_t aux_2714;
							   object_t aux_2712;
							   aux_2714 = (obj_t) (arg1867_1534);
							   aux_2712 = (object_t) (obj1545_1533);
							   OBJECT_WIDENING_SET(aux_2712, aux_2714);
							}
						     }
						     {
							long arg1869_1536;
							arg1869_1536 = class_num_218___object(svar_iinfo_76_integrate_info);
							{
							   obj_t obj_2040;
							   obj_2040 = (obj_t) (obj1545_1533);
							   (((obj_t) CREF(obj_2040))->header = MAKE_HEADER(arg1869_1536, 0), BUNSPEC);
							}
						     }
						     obj1545_1533;
						  }
						  {
						     obj_t arg1871_1538;
						     obj_t arg1875_1540;
						     box_set__221_t arg1876_1541;
						     arg1871_1538 = ____74_type_cache;
						     {
							obj_t arg1877_1542;
							{
							   obj_t aux_2722;
							   obj_t aux_2720;
							   {
							      node_t aux_2723;
							      aux_2723 = (((setq_t) CREF(node_1515))->value);
							      aux_2722 = (obj_t) (aux_2723);
							   }
							   aux_2720 = (obj_t) (a_var_30_1530);
							   arg1877_1542 = MAKE_PAIR(aux_2720, aux_2722);
							}
							{
							   obj_t list1878_1543;
							   list1878_1543 = MAKE_PAIR(arg1877_1542, BNIL);
							   arg1875_1540 = list1878_1543;
							}
						     }
						     {
							obj_t arg1883_1547;
							var_t arg1884_1548;
							var_t arg1885_1549;
							arg1883_1547 = ____74_type_cache;
							arg1884_1548 = (((setq_t) CREF(node_1515))->var);
							{
							   obj_t arg1887_1551;
							   arg1887_1551 = ____74_type_cache;
							   {
							      var_t res1958_2057;
							      {
								 type_t type_2048;
								 variable_t variable_2049;
								 type_2048 = (type_t) (arg1887_1551);
								 variable_2049 = (variable_t) (a_var_30_1530);
								 {
								    var_t new1209_2050;
								    new1209_2050 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
								    {
								       long arg1745_2051;
								       arg1745_2051 = class_num_218___object(var_ast_node);
								       {
									  obj_t obj_2055;
									  obj_2055 = (obj_t) (new1209_2050);
									  (((obj_t) CREF(obj_2055))->header = MAKE_HEADER(arg1745_2051, 0), BUNSPEC);
								       }
								    }
								    {
								       object_t aux_2735;
								       aux_2735 = (object_t) (new1209_2050);
								       OBJECT_WIDENING_SET(aux_2735, BFALSE);
								    }
								    ((((var_t) CREF(new1209_2050))->loc) = ((obj_t) loc_1531), BUNSPEC);
								    ((((var_t) CREF(new1209_2050))->type) = ((type_t) type_2048), BUNSPEC);
								    ((((var_t) CREF(new1209_2050))->variable) = ((variable_t) variable_2049), BUNSPEC);
								    res1958_2057 = new1209_2050;
								 }
							      }
							      arg1885_1549 = res1958_2057;
							   }
							}
							{
							   box_set__221_t res1959_2070;
							   {
							      type_t type_2059;
							      node_t value_2061;
							      type_2059 = (type_t) (arg1883_1547);
							      value_2061 = (node_t) (arg1885_1549);
							      {
								 box_set__221_t new1428_2062;
								 new1428_2062 = ((box_set__221_t) BREF(GC_MALLOC(sizeof(struct box_set__221))));
								 {
								    long arg1699_2063;
								    arg1699_2063 = class_num_218___object(box_set__221_ast_node);
								    {
								       obj_t obj_2068;
								       obj_2068 = (obj_t) (new1428_2062);
								       (((obj_t) CREF(obj_2068))->header = MAKE_HEADER(arg1699_2063, 0), BUNSPEC);
								    }
								 }
								 {
								    object_t aux_2747;
								    aux_2747 = (object_t) (new1428_2062);
								    OBJECT_WIDENING_SET(aux_2747, BFALSE);
								 }
								 ((((box_set__221_t) CREF(new1428_2062))->loc) = ((obj_t) loc_1531), BUNSPEC);
								 ((((box_set__221_t) CREF(new1428_2062))->type) = ((type_t) type_2059), BUNSPEC);
								 ((((box_set__221_t) CREF(new1428_2062))->var) = ((var_t) arg1884_1548), BUNSPEC);
								 ((((box_set__221_t) CREF(new1428_2062))->value) = ((node_t) value_2061), BUNSPEC);
								 res1959_2070 = new1428_2062;
							      }
							   }
							   arg1876_1541 = res1959_2070;
							}
						     }
						     {
							let_var_6_t res1960_2089;
							{
							   type_t type_2072;
							   obj_t key_2074;
							   node_t body_2076;
							   type_2072 = (type_t) (arg1871_1538);
							   key_2074 = BINT(((long) -1));
							   body_2076 = (node_t) (arg1876_1541);
							   {
							      let_var_6_t new1368_2078;
							      new1368_2078 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
							      {
								 long arg1709_2079;
								 arg1709_2079 = class_num_218___object(let_var_6_ast_node);
								 {
								    obj_t obj_2087;
								    obj_2087 = (obj_t) (new1368_2078);
								    (((obj_t) CREF(obj_2087))->header = MAKE_HEADER(arg1709_2079, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_2761;
								 aux_2761 = (object_t) (new1368_2078);
								 OBJECT_WIDENING_SET(aux_2761, BFALSE);
							      }
							      ((((let_var_6_t) CREF(new1368_2078))->loc) = ((obj_t) loc_1531), BUNSPEC);
							      ((((let_var_6_t) CREF(new1368_2078))->type) = ((type_t) type_2072), BUNSPEC);
							      ((((let_var_6_t) CREF(new1368_2078))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
							      ((((let_var_6_t) CREF(new1368_2078))->key) = ((obj_t) key_2074), BUNSPEC);
							      ((((let_var_6_t) CREF(new1368_2078))->bindings) = ((obj_t) arg1875_1540), BUNSPEC);
							      ((((let_var_6_t) CREF(new1368_2078))->body) = ((node_t) body_2076), BUNSPEC);
							      ((((let_var_6_t) CREF(new1368_2078))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
							      res1960_2089 = new1368_2078;
							   }
							}
							aux_2501 = (obj_t) (res1960_2089);
						     }
						  }
					       }
					     else
					       {
						  aux_2501 = (obj_t) (node_1515);
					       }
					  }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    conditional_t node_1557;
			    node_1557 = (conditional_t) (node_10);
			    {
			       node_t arg1894_1560;
			       arg1894_1560 = glo__115_integrate_node((((conditional_t) CREF(node_1557))->test), integrator_11);
			       ((((conditional_t) CREF(node_1557))->test) = ((node_t) arg1894_1560), BUNSPEC);
			    }
			    {
			       node_t arg1896_1562;
			       arg1896_1562 = glo__115_integrate_node((((conditional_t) CREF(node_1557))->true), integrator_11);
			       ((((conditional_t) CREF(node_1557))->true) = ((node_t) arg1896_1562), BUNSPEC);
			    }
			    {
			       node_t arg1898_1564;
			       arg1898_1564 = glo__115_integrate_node((((conditional_t) CREF(node_1557))->false), integrator_11);
			       ((((conditional_t) CREF(node_1557))->false) = ((node_t) arg1898_1564), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1557);
			 }
			 break;
		      case ((long) 12):
			 {
			    fail_t node_1566;
			    node_1566 = (fail_t) (node_10);
			    {
			       node_t arg1900_1569;
			       arg1900_1569 = glo__115_integrate_node((((fail_t) CREF(node_1566))->proc), integrator_11);
			       ((((fail_t) CREF(node_1566))->proc) = ((node_t) arg1900_1569), BUNSPEC);
			    }
			    {
			       node_t arg1902_1571;
			       arg1902_1571 = glo__115_integrate_node((((fail_t) CREF(node_1566))->msg), integrator_11);
			       ((((fail_t) CREF(node_1566))->msg) = ((node_t) arg1902_1571), BUNSPEC);
			    }
			    {
			       node_t arg1905_1573;
			       arg1905_1573 = glo__115_integrate_node((((fail_t) CREF(node_1566))->obj), integrator_11);
			       ((((fail_t) CREF(node_1566))->obj) = ((node_t) arg1905_1573), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1566);
			 }
			 break;
		      case ((long) 13):
			 {
			    select_t node_1575;
			    node_1575 = (select_t) (node_10);
			    {
			       node_t arg1907_1578;
			       arg1907_1578 = glo__115_integrate_node((((select_t) CREF(node_1575))->test), integrator_11);
			       ((((select_t) CREF(node_1575))->test) = ((node_t) arg1907_1578), BUNSPEC);
			    }
			    {
			       obj_t l1552_1580;
			       l1552_1580 = (((select_t) CREF(node_1575))->clauses);
			     lname1553_1581:
			       if (PAIRP(l1552_1580))
				 {
				    {
				       obj_t clause_1584;
				       clause_1584 = CAR(l1552_1580);
				       {
					  node_t arg1912_1585;
					  {
					     node_t aux_2804;
					     {
						obj_t aux_2805;
						aux_2805 = CDR(clause_1584);
						aux_2804 = (node_t) (aux_2805);
					     }
					     arg1912_1585 = glo__115_integrate_node(aux_2804, integrator_11);
					  }
					  {
					     obj_t aux_2809;
					     aux_2809 = (obj_t) (arg1912_1585);
					     SET_CDR(clause_1584, aux_2809);
					  }
				       }
				    }
				    {
				       obj_t l1552_2812;
				       l1552_2812 = CDR(l1552_1580);
				       l1552_1580 = l1552_2812;
				       goto lname1553_1581;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2501 = (obj_t) (node_1575);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_fun_218_t node_1588;
			    node_1588 = (let_fun_218_t) (node_10);
			    {
			       node_t arg1915_1591;
			       arg1915_1591 = glo__115_integrate_node((((let_fun_218_t) CREF(node_1588))->body), integrator_11);
			       ((((let_fun_218_t) CREF(node_1588))->body) = ((node_t) arg1915_1591), BUNSPEC);
			    }
			    {
			       obj_t l1555_1593;
			       l1555_1593 = (((let_fun_218_t) CREF(node_1588))->locals);
			     lname1556_1594:
			       if (PAIRP(l1555_1593))
				 {
				    {
				       local_t aux_2822;
				       {
					  obj_t aux_2823;
					  aux_2823 = CAR(l1555_1593);
					  aux_2822 = (local_t) (aux_2823);
				       }
				       globalize_local_fun__50_integrate_node(aux_2822, integrator_11);
				    }
				    {
				       obj_t l1555_2827;
				       l1555_2827 = CDR(l1555_1593);
				       l1555_1593 = l1555_2827;
				       goto lname1556_1594;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2501 = (obj_t) (node_1588);
			 }
			 break;
		      case ((long) 15):
			 {
			    let_var_6_t node_1599;
			    node_1599 = (let_var_6_t) (node_10);
			    {
			       obj_t l1558_1602;
			       l1558_1602 = (((let_var_6_t) CREF(node_1599))->bindings);
			     lname1559_1603:
			       if (PAIRP(l1558_1602))
				 {
				    {
				       obj_t binding_1606;
				       binding_1606 = CAR(l1558_1602);
				       {
					  obj_t var_1607;
					  var_1607 = CAR(binding_1606);
					  {
					     node_t arg1923_1609;
					     {
						node_t aux_2836;
						{
						   obj_t aux_2837;
						   aux_2837 = CDR(binding_1606);
						   aux_2836 = (node_t) (aux_2837);
						}
						arg1923_1609 = glo__115_integrate_node(aux_2836, integrator_11);
					     }
					     {
						obj_t aux_2841;
						aux_2841 = (obj_t) (arg1923_1609);
						SET_CDR(binding_1606, aux_2841);
					     }
					  }
					  if (integrate_celled__59_integrate_node((local_t) (var_1607)))
					    {
					       {
						  local_t obj_2132;
						  type_t val1095_2133;
						  obj_2132 = (local_t) (var_1607);
						  val1095_2133 = (type_t) (_obj__252_type_cache);
						  ((((local_t) CREF(obj_2132))->type) = ((type_t) val1095_2133), BUNSPEC);
					       }
					       {
						  make_box_202_t arg1925_1611;
						  {
						     node_t aux_2850;
						     {
							obj_t aux_2851;
							aux_2851 = CDR(binding_1606);
							aux_2850 = (node_t) (aux_2851);
						     }
						     arg1925_1611 = a_make_cell_117_integrate_node(aux_2850, (variable_t) (var_1607));
						  }
						  {
						     obj_t aux_2856;
						     aux_2856 = (obj_t) (arg1925_1611);
						     SET_CDR(binding_1606, aux_2856);
						  }
					       }
					    }
					  else
					    {
					       BUNSPEC;
					    }
				       }
				    }
				    {
				       obj_t l1558_2859;
				       l1558_2859 = CDR(l1558_1602);
				       l1558_1602 = l1558_2859;
				       goto lname1559_1603;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1929_1614;
			       arg1929_1614 = glo__115_integrate_node((((let_var_6_t) CREF(node_1599))->body), integrator_11);
			       ((((let_var_6_t) CREF(node_1599))->body) = ((node_t) arg1929_1614), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1599);
			 }
			 break;
		      case ((long) 16):
			 {
			    set_ex_it_116_t node_1616;
			    node_1616 = (set_ex_it_116_t) (node_10);
			    {
			       node_t arg1931_1619;
			       arg1931_1619 = glo__115_integrate_node((((set_ex_it_116_t) CREF(node_1616))->body), integrator_11);
			       ((((set_ex_it_116_t) CREF(node_1616))->body) = ((node_t) arg1931_1619), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1616);
			 }
			 break;
		      case ((long) 17):
			 {
			    jump_ex_it_184_t node_1621;
			    node_1621 = (jump_ex_it_184_t) (node_10);
			    {
			       node_t arg1933_1624;
			       arg1933_1624 = glo__115_integrate_node((((jump_ex_it_184_t) CREF(node_1621))->exit), integrator_11);
			       ((((jump_ex_it_184_t) CREF(node_1621))->exit) = ((node_t) arg1933_1624), BUNSPEC);
			    }
			    {
			       node_t arg1935_1626;
			       arg1935_1626 = glo__115_integrate_node((((jump_ex_it_184_t) CREF(node_1621))->value), integrator_11);
			       ((((jump_ex_it_184_t) CREF(node_1621))->value) = ((node_t) arg1935_1626), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1621);
			 }
			 break;
		      case ((long) 18):
			 {
			    make_box_202_t node_1628;
			    node_1628 = (make_box_202_t) (node_10);
			    {
			       node_t arg1937_1631;
			       arg1937_1631 = glo__115_integrate_node((((make_box_202_t) CREF(node_1628))->value), integrator_11);
			       ((((make_box_202_t) CREF(node_1628))->value) = ((node_t) arg1937_1631), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1628);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_ref_242_t node_1633;
			    node_1633 = (box_ref_242_t) (node_10);
			    {
			       node_t arg1939_1636;
			       {
				  node_t aux_2885;
				  {
				     var_t aux_2886;
				     aux_2886 = (((box_ref_242_t) CREF(node_1633))->var);
				     aux_2885 = (node_t) (aux_2886);
				  }
				  arg1939_1636 = glo__115_integrate_node(aux_2885, integrator_11);
			       }
			       {
				  var_t val1426_2155;
				  val1426_2155 = (var_t) (arg1939_1636);
				  ((((box_ref_242_t) CREF(node_1633))->var) = ((var_t) val1426_2155), BUNSPEC);
			       }
			    }
			    aux_2501 = (obj_t) (node_1633);
			 }
			 break;
		      case ((long) 20):
			 {
			    box_set__221_t node_1638;
			    node_1638 = (box_set__221_t) (node_10);
			    {
			       node_t arg1941_1641;
			       {
				  node_t aux_2894;
				  {
				     var_t aux_2895;
				     aux_2895 = (((box_set__221_t) CREF(node_1638))->var);
				     aux_2894 = (node_t) (aux_2895);
				  }
				  arg1941_1641 = glo__115_integrate_node(aux_2894, integrator_11);
			       }
			       {
				  var_t val1435_2158;
				  val1435_2158 = (var_t) (arg1941_1641);
				  ((((box_set__221_t) CREF(node_1638))->var) = ((var_t) val1435_2158), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1943_1643;
			       arg1943_1643 = glo__115_integrate_node((((box_set__221_t) CREF(node_1638))->value), integrator_11);
			       ((((box_set__221_t) CREF(node_1638))->value) = ((node_t) arg1943_1643), BUNSPEC);
			    }
			    aux_2501 = (obj_t) (node_1638);
			 }
			 break;
		      default:
		       case_else1798_1428:
			 if (PROCEDUREP(method1792_1424))
			   {
			      aux_2501 = PROCEDURE_ENTRY(method1792_1424) (method1792_1424, (obj_t) (node_10), (obj_t) (integrator_11), BEOA);
			   }
			 else
			   {
			      obj_t fun1789_1418;
			      fun1789_1418 = PROCEDURE_REF(glo__env_172_integrate_node, ((long) 0));
			      aux_2501 = PROCEDURE_ENTRY(fun1789_1418) (fun1789_1418, (obj_t) (node_10), (obj_t) (integrator_11), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1798_1428;
		 }
	    }
	    return (node_t) (aux_2501);
	 }
      }
   }
}


/* _glo!1964 */ obj_t 
_glo_1964_71_integrate_node(obj_t env_2175, obj_t node_2176, obj_t integrator_2177)
{
   {
      node_t aux_2919;
      aux_2919 = glo__115_integrate_node((node_t) (node_2176), (variable_t) (integrator_2177));
      return (obj_t) (aux_2919);
   }
}


/* glo!-default1569 */ node_t 
glo__default1569_91_integrate_node(node_t node_12, variable_t integrator_13)
{
   FAILURE(CNST_TABLE_REF(((long) 4)), string1967_integrate_node, (obj_t) (node_12));
}


/* _glo!-default1569 */ obj_t 
_glo__default1569_98_integrate_node(obj_t env_2178, obj_t node_2179, obj_t integrator_2180)
{
   {
      node_t aux_2927;
      aux_2927 = glo__default1569_91_integrate_node((node_t) (node_2179), (variable_t) (integrator_2180));
      return (obj_t) (aux_2927);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_node()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_tools_error(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_type_cache(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_ast_local(((long) 0), "INTEGRATE_NODE");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_NODE");
   return module_initialization_70_integrate_local__global_163(((long) 0), "INTEGRATE_NODE");
}
