/*===========================================================================*/
/*   (Cgen/walk.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;

typedef struct cop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *cop_t;

typedef struct clabel
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t name;
     bool_t used__226;
     obj_t body;
  }
      *clabel_t;

typedef struct cgoto
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct clabel *label;
  }
     *cgoto_t;

typedef struct block
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
     *block_t;

typedef struct creturn
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
       *creturn_t;

typedef struct cvoid
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
     *cvoid_t;

typedef struct catom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t value;
  }
     *catom_t;

typedef struct varc
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct variable *variable;
  }
    *varc_t;

typedef struct cpragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t format;
     obj_t args;
  }
       *cpragma_t;

typedef struct ccast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct cop *arg;
  }
     *ccast_t;

typedef struct csequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     bool_t c_exp__163;
     obj_t cops;
  }
         *csequence_t;

typedef struct nop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *nop_t;

typedef struct stop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
    *stop_t;

typedef struct csetq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct varc *var;
     struct cop *value;
  }
     *csetq_t;

typedef struct cif
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     struct cop *true;
     struct cop *false;
  }
   *cif_t;

typedef struct local_var_164
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t vars;
  }
             *local_var_164_t;

typedef struct cfuncall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
     obj_t strength;
  }
        *cfuncall_t;

typedef struct capply
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     struct cop *arg;
  }
      *capply_t;

typedef struct capp
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
  }
    *capp_t;

typedef struct cfail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *proc;
     struct cop *msg;
     struct cop *obj;
  }
     *cfail_t;

typedef struct cswitch
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     obj_t clauses;
  }
       *cswitch_t;

typedef struct cmake_box_177
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
             *cmake_box_177_t;

typedef struct cbox_ref_44
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
  }
           *cbox_ref_44_t;

typedef struct cbox_set__132
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
     struct cop *value;
  }
             *cbox_set__132_t;

typedef struct cset_ex_it_123
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *jump_value_221;
     struct cop *body;
  }
              *cset_ex_it_123_t;

typedef struct cjump_ex_it_131
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *value;
  }
               *cjump_ex_it_131_t;

typedef struct sfun_c_188
  {
     struct clabel *label;
     bool_t integrated;
  }
          *sfun_c_188_t;

typedef struct bdb_block_21
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
            *bdb_block_21_t;


static obj_t method_init_76_cgen_walk();
extern obj_t _nb_error_on_pass__70_tools_error;
static obj_t _cgen_walk_165_cgen_walk(obj_t, obj_t);
extern obj_t _c_port__188_cgen_emit;
extern obj_t _bdb_debug__1_engine_param;
extern obj_t stop_emission__231_cgen_emit();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_cgen_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_library(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_occur(long, char *);
extern obj_t module_initialization_70_ast_build(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_bdb_emit(long, char *);
extern obj_t module_initialization_70_prof_emit(long, char *);
extern obj_t module_initialization_70_cgen_cop(long, char *);
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70_cgen_prototype(long, char *);
extern obj_t module_initialization_70_cgen_main(long, char *);
extern obj_t module_initialization_70_cgen_init(long, char *);
extern obj_t module_initialization_70_cgen_cgen(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t make_bigloo_main_85_cgen_main();
extern obj_t emit_garbage_collector_selection_89_cgen_emit();
extern obj_t emit_prototypes_82_cgen_prototype();
extern obj_t emit_prof_info_80_prof_emit(obj_t, obj_t);
static obj_t imported_modules_init_94_cgen_walk();
extern obj_t emit_header_99_cgen_emit();
extern obj_t emit_bdb_info_67_bdb_emit(obj_t, obj_t);
extern obj_t cgen_cgen_cgen(global_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cgen_walk();
extern obj_t start_emission__101_cgen_emit(obj_t);
extern obj_t library_finalizer_97_module_library();
extern obj_t emit_include_217_cgen_emit();
extern obj_t occur_node_in__115_ast_occur(node_t, global_t);
static obj_t toplevel_init_63_cgen_walk();
extern obj_t open_input_string(obj_t);
extern obj_t make_module_init_70_cgen_init();
static obj_t arg1702_cgen_walk(obj_t);
extern obj_t cgen_walk_174_cgen_walk(obj_t);
extern obj_t emit_cnsts_221_cgen_prototype();
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t build_ast_sans_remove_93_ast_build(obj_t);
extern obj_t emit_main_179_cgen_emit();
extern obj_t emit_debug_activation_148_cgen_emit();
extern obj_t read___reader(obj_t);
extern obj_t _profile_mode__105_engine_param;
extern obj_t _c_debug__136_engine_param;
extern obj_t emit_class_types_26_object_class(obj_t);
static obj_t require_initialization_114_cgen_walk = BUNSPEC;
extern obj_t _pass__125_engine_param;
extern obj_t _main__152_module_module;
static obj_t cnst_init_137_cgen_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[5];

DEFINE_EXPORT_PROCEDURE(cgen_walk_env_156_cgen_walk, _cgen_walk_165_cgen_walk1927, _cgen_walk_165_cgen_walk, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1918_cgen_walk, arg1702_cgen_walk1928, arg1702_cgen_walk, 0L, 0);
DEFINE_STRING(string1919_cgen_walk, string1919_cgen_walk1929, ".c", 2);
DEFINE_STRING(string1920_cgen_walk, string1920_cgen_walk1930, "IMPORTED (LD DISTRIB) UNIT ((LAMBDA () (START-EMISSION! \".c\"))) PASS-STARTED ", 77);
DEFINE_STRING(string1917_cgen_walk, string1917_cgen_walk1931, "failure during prelude hook", 27);
DEFINE_STRING(string1916_cgen_walk, string1916_cgen_walk1932, "   . ", 5);
DEFINE_STRING(string1915_cgen_walk, string1915_cgen_walk1933, "C generation", 12);


/* module-initialization */ obj_t 
module_initialization_70_cgen_walk(long checksum_1806, char *from_1807)
{
   if (CBOOL(require_initialization_114_cgen_walk))
     {
	require_initialization_114_cgen_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_walk();
	cnst_init_137_cgen_walk();
	imported_modules_init_94_cgen_walk();
	method_init_76_cgen_walk();
	toplevel_init_63_cgen_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_walk()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CGEN_WALK");
   module_initialization_70___reader(((long) 0), "CGEN_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_walk()
{
   {
      obj_t cnst_port_138_1798;
      cnst_port_138_1798 = open_input_string(string1920_cgen_walk);
      {
	 long i_1799;
	 i_1799 = ((long) 4);
       loop_1800:
	 {
	    bool_t test1921_1801;
	    test1921_1801 = (i_1799 == ((long) -1));
	    if (test1921_1801)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1923_1802;
		    {
		       obj_t list1924_1803;
		       {
			  obj_t arg1925_1804;
			  arg1925_1804 = BNIL;
			  list1924_1803 = MAKE_PAIR(cnst_port_138_1798, arg1925_1804);
		       }
		       arg1923_1802 = read___reader(list1924_1803);
		    }
		    CNST_TABLE_SET(i_1799, arg1923_1802);
		 }
		 {
		    int aux_1805;
		    {
		       long aux_1824;
		       aux_1824 = (i_1799 - ((long) 1));
		       aux_1805 = (int) (aux_1824);
		    }
		    {
		       long i_1827;
		       i_1827 = (long) (aux_1805);
		       i_1799 = i_1827;
		       goto loop_1800;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_walk()
{
   return BUNSPEC;
}


/* cgen-walk */ obj_t 
cgen_walk_174_cgen_walk(obj_t globals_19)
{
   {
      obj_t list1693_1095;
      {
	 obj_t arg1695_1097;
	 {
	    obj_t arg1698_1099;
	    {
	       obj_t aux_1829;
	       aux_1829 = BCHAR(((unsigned char) '\n'));
	       arg1698_1099 = MAKE_PAIR(aux_1829, BNIL);
	    }
	    arg1695_1097 = MAKE_PAIR(string1915_cgen_walk, arg1698_1099);
	 }
	 list1693_1095 = MAKE_PAIR(string1916_cgen_walk, arg1695_1097);
      }
      verbose_tools_speek(BINT(((long) 1)), list1693_1095);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1915_cgen_walk;
   {
      obj_t hooks_1101;
      obj_t hnames_1102;
      {
	 obj_t arg1700_1104;
	 obj_t arg1701_1105;
	 {
	    obj_t arg1702_1793;
	    arg1702_1793 = proc1918_cgen_walk;
	    {
	       obj_t list1703_1107;
	       list1703_1107 = MAKE_PAIR(arg1702_1793, BNIL);
	       arg1700_1104 = list1703_1107;
	    }
	 }
	 arg1701_1105 = CNST_TABLE_REF(((long) 1));
	 hooks_1101 = arg1700_1104;
	 hnames_1102 = arg1701_1105;
       loop_1103:
	 if (NULLP(hooks_1101))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1707_1112;
	      {
		 obj_t fun1713_1118;
		 fun1713_1118 = CAR(hooks_1101);
		 {
		    obj_t aux_1843;
		    aux_1843 = PROCEDURE_ENTRY(fun1713_1118) (fun1713_1118, BEOA);
		    test1707_1112 = CBOOL(aux_1843);
		 }
	      }
	      if (test1707_1112)
		{
		   {
		      obj_t hnames_1850;
		      obj_t hooks_1848;
		      hooks_1848 = CDR(hooks_1101);
		      hnames_1850 = CDR(hnames_1102);
		      hnames_1102 = hnames_1850;
		      hooks_1101 = hooks_1848;
		      goto loop_1103;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1915_cgen_walk, string1917_cgen_walk, CAR(hnames_1102));
		}
	   }
      }
   }
   {
      obj_t lib_unit_138_1119;
      lib_unit_138_1119 = library_finalizer_97_module_library();
      {
	 obj_t lib_init_12_1120;
	 {
	    bool_t test_1855;
	    if (STRUCTP(lib_unit_138_1119))
	      {
		 obj_t aux_1860;
		 obj_t aux_1858;
		 aux_1860 = CNST_TABLE_REF(((long) 2));
		 aux_1858 = STRUCT_KEY(lib_unit_138_1119);
		 test_1855 = (aux_1858 == aux_1860);
	      }
	    else
	      {
		 test_1855 = ((bool_t) 0);
	      }
	    if (test_1855)
	      {
		 obj_t vars_1146;
		 {
		    obj_t arg1746_1154;
		    {
		       obj_t list1747_1155;
		       list1747_1155 = MAKE_PAIR(lib_unit_138_1119, BNIL);
		       arg1746_1154 = list1747_1155;
		    }
		    vars_1146 = build_ast_sans_remove_93_ast_build(arg1746_1154);
		 }
		 {
		    obj_t l1671_1147;
		    l1671_1147 = vars_1146;
		  lname1672_1148:
		    if (PAIRP(l1671_1147))
		      {
			 {
			    obj_t g_1150;
			    g_1150 = CAR(l1671_1147);
			    {
			       node_t aux_1868;
			       {
				  obj_t aux_1869;
				  {
				     sfun_t obj_1731;
				     {
					value_t aux_1870;
					{
					   global_t obj_1730;
					   obj_1730 = (global_t) (g_1150);
					   aux_1870 = (((global_t) CREF(obj_1730))->value);
					}
					obj_1731 = (sfun_t) (aux_1870);
				     }
				     aux_1869 = (((sfun_t) CREF(obj_1731))->body);
				  }
				  aux_1868 = (node_t) (aux_1869);
			       }
			       occur_node_in__115_ast_occur(aux_1868, (global_t) (g_1150));
			    }
			 }
			 {
			    obj_t l1671_1878;
			    l1671_1878 = CDR(l1671_1147);
			    l1671_1147 = l1671_1878;
			    goto lname1672_1148;
			 }
		      }
		    else
		      {
			 ((bool_t) 1);
		      }
		 }
		 lib_init_12_1120 = vars_1146;
	      }
	    else
	      {
		 lib_init_12_1120 = BNIL;
	      }
	 }
	 {
	    obj_t globals_1121;
	    {
	       obj_t arg1726_1136;
	       obj_t arg1727_1137;
	       arg1726_1136 = make_module_init_70_cgen_init();
	       {
		  bool_t test1728_1138;
		  {
		     bool_t test1731_1141;
		     if (CBOOL(_main__152_module_module))
		       {
			  test1731_1141 = ((bool_t) 1);
		       }
		     else
		       {
			  obj_t aux_1883;
			  aux_1883 = memq___r4_pairs_and_lists_6_3(_pass__125_engine_param, CNST_TABLE_REF(((long) 3)));
			  test1731_1141 = CBOOL(aux_1883);
		       }
		     if (test1731_1141)
		       {
			  bool_t test1732_1142;
			  {
			     obj_t obj1_1733;
			     obj1_1733 = _main__152_module_module;
			     {
				obj_t aux_1888;
				aux_1888 = CNST_TABLE_REF(((long) 4));
				test1732_1142 = (obj1_1733 == aux_1888);
			     }
			  }
			  if (test1732_1142)
			    {
			       test1728_1138 = ((bool_t) 0);
			    }
			  else
			    {
			       test1728_1138 = ((bool_t) 1);
			    }
		       }
		     else
		       {
			  test1728_1138 = ((bool_t) 0);
		       }
		  }
		  if (test1728_1138)
		    {
		       obj_t arg1729_1139;
		       obj_t arg1730_1140;
		       arg1729_1139 = make_bigloo_main_85_cgen_main();
		       arg1730_1140 = append_2_18___r4_pairs_and_lists_6_3(lib_init_12_1120, globals_19);
		       arg1727_1137 = MAKE_PAIR(arg1729_1139, arg1730_1140);
		    }
		  else
		    {
		       arg1727_1137 = append_2_18___r4_pairs_and_lists_6_3(lib_init_12_1120, globals_19);
		    }
	       }
	       globals_1121 = MAKE_PAIR(arg1726_1136, arg1727_1137);
	    }
	    {
	       emit_header_99_cgen_emit();
	       emit_garbage_collector_selection_89_cgen_emit();
	       {
		  bool_t test1714_1122;
		  {
		     bool_t test1715_1123;
		     {
			long n1_1739;
			n1_1739 = (long) CINT(_compiler_debug__134_engine_param);
			test1715_1123 = (n1_1739 > ((long) 0));
		     }
		     if (test1715_1123)
		       {
			  test1714_1122 = ((bool_t) 1);
		       }
		     else
		       {
			  test1714_1122 = CBOOL(_c_debug__136_engine_param);
		       }
		  }
		  if (test1714_1122)
		    {
		       emit_debug_activation_148_cgen_emit();
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       emit_include_217_cgen_emit();
	       emit_class_types_26_object_class(_c_port__188_cgen_emit);
	       emit_prototypes_82_cgen_prototype();
	       emit_cnsts_221_cgen_prototype();
	       {
		  bool_t test1716_1124;
		  {
		     long n1_1741;
		     n1_1741 = (long) CINT(_bdb_debug__1_engine_param);
		     test1716_1124 = (n1_1741 > ((long) 0));
		  }
		  if (test1716_1124)
		    {
		       emit_bdb_info_67_bdb_emit(globals_1121, _c_port__188_cgen_emit);
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       {
		  bool_t test1717_1125;
		  {
		     long n1_1743;
		     n1_1743 = (long) CINT(_profile_mode__105_engine_param);
		     test1717_1125 = (n1_1743 > ((long) 0));
		  }
		  if (test1717_1125)
		    {
		       emit_prof_info_80_prof_emit(globals_1121, _c_port__188_cgen_emit);
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       {
		  bool_t test1718_1126;
		  {
		     bool_t test1719_1127;
		     if (CBOOL(_main__152_module_module))
		       {
			  test1719_1127 = ((bool_t) 1);
		       }
		     else
		       {
			  obj_t aux_1920;
			  aux_1920 = memq___r4_pairs_and_lists_6_3(_pass__125_engine_param, CNST_TABLE_REF(((long) 3)));
			  test1719_1127 = CBOOL(aux_1920);
		       }
		     if (test1719_1127)
		       {
			  bool_t test1720_1128;
			  {
			     obj_t obj1_1745;
			     obj1_1745 = _main__152_module_module;
			     {
				obj_t aux_1925;
				aux_1925 = CNST_TABLE_REF(((long) 4));
				test1720_1128 = (obj1_1745 == aux_1925);
			     }
			  }
			  if (test1720_1128)
			    {
			       test1718_1126 = ((bool_t) 0);
			    }
			  else
			    {
			       test1718_1126 = ((bool_t) 1);
			    }
		       }
		     else
		       {
			  test1718_1126 = ((bool_t) 0);
		       }
		  }
		  if (test1718_1126)
		    {
		       emit_main_179_cgen_emit();
		    }
		  else
		    {
		       BUNSPEC;
		    }
	       }
	       {
		  obj_t l1673_1131;
		  l1673_1131 = globals_1121;
		lname1674_1132:
		  if (PAIRP(l1673_1131))
		    {
		       {
			  global_t aux_1933;
			  {
			     obj_t aux_1934;
			     aux_1934 = CAR(l1673_1131);
			     aux_1933 = (global_t) (aux_1934);
			  }
			  cgen_cgen_cgen(aux_1933);
		       }
		       {
			  obj_t l1673_1938;
			  l1673_1938 = CDR(l1673_1131);
			  l1673_1131 = l1673_1938;
			  goto lname1674_1132;
		       }
		    }
		  else
		    {
		       ((bool_t) 1);
		    }
	       }
	       return stop_emission__231_cgen_emit();
	    }
	 }
      }
   }
}


/* _cgen-walk */ obj_t 
_cgen_walk_165_cgen_walk(obj_t env_1794, obj_t globals_1795)
{
   return cgen_walk_174_cgen_walk(globals_1795);
}


/* arg1702 */ obj_t 
arg1702_cgen_walk(obj_t env_1796)
{
   {
      return start_emission__101_cgen_emit(string1919_cgen_walk);
   }
}


/* method-init */ obj_t 
method_init_76_cgen_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_walk()
{
   module_initialization_70_tools_speek(((long) 0), "CGEN_WALK");
   module_initialization_70_tools_error(((long) 0), "CGEN_WALK");
   module_initialization_70_engine_pass(((long) 0), "CGEN_WALK");
   module_initialization_70_tools_trace(((long) 0), "CGEN_WALK");
   module_initialization_70_tools_shape(((long) 0), "CGEN_WALK");
   module_initialization_70_engine_param(((long) 0), "CGEN_WALK");
   module_initialization_70_module_module(((long) 0), "CGEN_WALK");
   module_initialization_70_module_library(((long) 0), "CGEN_WALK");
   module_initialization_70_type_type(((long) 0), "CGEN_WALK");
   module_initialization_70_ast_var(((long) 0), "CGEN_WALK");
   module_initialization_70_ast_node(((long) 0), "CGEN_WALK");
   module_initialization_70_ast_occur(((long) 0), "CGEN_WALK");
   module_initialization_70_ast_build(((long) 0), "CGEN_WALK");
   module_initialization_70_object_class(((long) 0), "CGEN_WALK");
   module_initialization_70_bdb_emit(((long) 0), "CGEN_WALK");
   module_initialization_70_prof_emit(((long) 0), "CGEN_WALK");
   module_initialization_70_cgen_cop(((long) 0), "CGEN_WALK");
   module_initialization_70_cgen_emit(((long) 0), "CGEN_WALK");
   module_initialization_70_cgen_prototype(((long) 0), "CGEN_WALK");
   module_initialization_70_cgen_main(((long) 0), "CGEN_WALK");
   module_initialization_70_cgen_init(((long) 0), "CGEN_WALK");
   return module_initialization_70_cgen_cgen(((long) 0), "CGEN_WALK");
}
