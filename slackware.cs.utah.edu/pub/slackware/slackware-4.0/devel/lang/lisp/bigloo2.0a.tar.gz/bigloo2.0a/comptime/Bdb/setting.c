/*===========================================================================*/
/*   (Bdb/setting.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t _rm_c_files__192_engine_param;
extern obj_t module_initialization_70_bdb_setting(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
obj_t _bdb_module__96_bdb_setting = BUNSPEC;
extern obj_t _strip__173_engine_param;
static obj_t imported_modules_init_94_bdb_setting();
extern obj_t bdb_setting__207_bdb_setting();
static obj_t library_modules_init_112_bdb_setting();
static obj_t toplevel_init_63_bdb_setting();
extern obj_t _inlining___224_engine_param;
extern obj_t open_input_string(obj_t);
extern obj_t _compiler_debug__134_engine_param;
static obj_t _bdb_setting__255_bdb_setting(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t _c_debug__136_engine_param;
static obj_t require_initialization_114_bdb_setting = BUNSPEC;
static obj_t cnst_init_137_bdb_setting();
extern obj_t _indent__220_engine_param;
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(bdb_setting__env_8_bdb_setting, _bdb_setting__255_bdb_setting1008, _bdb_setting__255_bdb_setting, 0L, 0);
DEFINE_STRING(string1002_bdb_setting, string1002_bdb_setting1009, "__BDB ", 6);


/* module-initialization */ obj_t 
module_initialization_70_bdb_setting(long checksum_10, char *from_11)
{
   if (CBOOL(require_initialization_114_bdb_setting))
     {
	require_initialization_114_bdb_setting = BBOOL(((bool_t) 0));
	library_modules_init_112_bdb_setting();
	cnst_init_137_bdb_setting();
	imported_modules_init_94_bdb_setting();
	toplevel_init_63_bdb_setting();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_bdb_setting()
{
   module_initialization_70___reader(((long) 0), "BDB_SETTING");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_bdb_setting()
{
   {
      obj_t cnst_port_138_2;
      cnst_port_138_2 = open_input_string(string1002_bdb_setting);
      {
	 long i_3;
	 i_3 = ((long) 0);
       loop_4:
	 {
	    bool_t test1003_5;
	    test1003_5 = (i_3 == ((long) -1));
	    if (test1003_5)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1004_6;
		    {
		       obj_t list1005_7;
		       {
			  obj_t arg1006_8;
			  arg1006_8 = BNIL;
			  list1005_7 = MAKE_PAIR(cnst_port_138_2, arg1006_8);
		       }
		       arg1004_6 = read___reader(list1005_7);
		    }
		    CNST_TABLE_SET(i_3, arg1004_6);
		 }
		 {
		    int aux_9;
		    {
		       long aux_26;
		       aux_26 = (i_3 - ((long) 1));
		       aux_9 = (int) (aux_26);
		    }
		    {
		       long i_29;
		       i_29 = (long) (aux_9);
		       i_3 = i_29;
		       goto loop_4;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_bdb_setting()
{
   return (_bdb_module__96_bdb_setting = CNST_TABLE_REF(((long) 0)),
      BUNSPEC);
}


/* bdb-setting! */ obj_t 
bdb_setting__207_bdb_setting()
{
   _compiler_debug__134_engine_param = BINT(((long) 0));
   _rm_c_files__192_engine_param = BFALSE;
   _c_debug__136_engine_param = BTRUE;
   _strip__173_engine_param = BFALSE;
   _indent__220_engine_param = BFALSE;
   return (_inlining___224_engine_param = BFALSE,
      BUNSPEC);
}


/* _bdb-setting! */ obj_t 
_bdb_setting__255_bdb_setting(obj_t env_1)
{
   return bdb_setting__207_bdb_setting();
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_bdb_setting()
{
   module_initialization_70_engine_param(((long) 0), "BDB_SETTING");
   module_initialization_70_tools_shape(((long) 0), "BDB_SETTING");
   module_initialization_70_tools_error(((long) 0), "BDB_SETTING");
   return module_initialization_70_tools_misc(((long) 0), "BDB_SETTING");
}
