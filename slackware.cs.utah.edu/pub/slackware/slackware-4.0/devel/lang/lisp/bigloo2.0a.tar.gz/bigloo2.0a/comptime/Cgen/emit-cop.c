/*===========================================================================*/
/*   (Cgen/emit-cop.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct cop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *cop_t;

typedef struct clabel
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t name;
     bool_t used__226;
     obj_t body;
  }
      *clabel_t;

typedef struct cgoto
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct clabel *label;
  }
     *cgoto_t;

typedef struct block
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
     *block_t;

typedef struct creturn
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
       *creturn_t;

typedef struct cvoid
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
     *cvoid_t;

typedef struct catom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t value;
  }
     *catom_t;

typedef struct varc
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct variable *variable;
  }
    *varc_t;

typedef struct cpragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t format;
     obj_t args;
  }
       *cpragma_t;

typedef struct ccast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct cop *arg;
  }
     *ccast_t;

typedef struct csequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     bool_t c_exp__163;
     obj_t cops;
  }
         *csequence_t;

typedef struct nop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *nop_t;

typedef struct stop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
    *stop_t;

typedef struct csetq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct varc *var;
     struct cop *value;
  }
     *csetq_t;

typedef struct cif
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     struct cop *true;
     struct cop *false;
  }
   *cif_t;

typedef struct local_var_164
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t vars;
  }
             *local_var_164_t;

typedef struct cfuncall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
     obj_t strength;
  }
        *cfuncall_t;

typedef struct capply
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     struct cop *arg;
  }
      *capply_t;

typedef struct capp
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
  }
    *capp_t;

typedef struct cfail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *proc;
     struct cop *msg;
     struct cop *obj;
  }
     *cfail_t;

typedef struct cswitch
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     obj_t clauses;
  }
       *cswitch_t;

typedef struct cmake_box_177
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
             *cmake_box_177_t;

typedef struct cbox_ref_44
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
  }
           *cbox_ref_44_t;

typedef struct cbox_set__132
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
     struct cop *value;
  }
             *cbox_set__132_t;

typedef struct cset_ex_it_123
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *jump_value_221;
     struct cop *body;
  }
              *cset_ex_it_123_t;

typedef struct cjump_ex_it_131
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *value;
  }
               *cjump_ex_it_131_t;

typedef struct sfun_c_188
  {
     struct clabel *label;
     bool_t integrated;
  }
          *sfun_c_188_t;

typedef struct bdb_block_21
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
            *bdb_block_21_t;


extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
extern obj_t find_global_223_ast_env(obj_t, obj_t);
extern obj_t _long__149_type_cache;
static obj_t method_init_76_cgen_emit_cop_239();
extern obj_t block_cgen_cop;
static obj_t _emit_newline_88_cgen_emit_cop_239(obj_t, obj_t);
static bool_t emit_regular_cfuncall_eoa_48_cgen_emit_cop_239(cfuncall_t);
static obj_t _bfalse__69_cgen_emit_cop_239 = BUNSPEC;
extern obj_t cbox_ref_44_cgen_cop;
static obj_t _reset_bdb_loc__118_cgen_emit_cop_239(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _bdb_loc__137_cgen_emit_cop_239 = BUNSPEC;
extern obj_t _stdc__25_engine_param;
static obj_t _untrigraph2617_cgen_emit_cop_239(obj_t, obj_t);
extern obj_t _c_port__188_cgen_emit;
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t make_typed_declaration_180_type_tools(type_t, obj_t);
extern bool_t rgc_fill_buffer(obj_t);
extern obj_t _bdb_debug__1_engine_param;
extern obj_t cjump_ex_it_131_cgen_cop;
static obj_t emit_atom_value_68_cgen_emit_cop_239(obj_t);
extern obj_t cpragma_cgen_cop;
extern obj_t untrigraph_cgen_emit_cop_239(obj_t);
static obj_t _emit_cop_default1677_176_cgen_emit_cop_239(obj_t, obj_t);
extern obj_t varc_cgen_cop;
extern obj_t emit_bdb_loc_8_cgen_emit_cop_239(obj_t);
static obj_t the_string_180_cgen_emit_cop_239(obj_t);
extern obj_t local_var_164_cgen_cop;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t catom_cgen_cop;
extern obj_t reset_bdb_loc__217_cgen_emit_cop_239();
extern obj_t nop_cgen_cop;
extern obj_t ccast_cgen_cop;
extern obj_t cswitch_cgen_cop;
extern obj_t cgoto_cgen_cop;
extern obj_t module_initialization_70_cgen_emit_cop_239(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70_cgen_cop(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t cbox_set__132_cgen_cop;
extern obj_t clabel_cgen_cop;
extern obj_t csetq_cgen_cop;
extern obj_t bdb_block_21_cgen_cop;
static obj_t _emit_cop2618_201_cgen_emit_cop_239(obj_t, obj_t);
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern obj_t stop_cgen_cop;
extern obj_t _real__144_type_cache;
static obj_t imported_modules_init_94_cgen_emit_cop_239();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static bool_t emit_cop_default1677_86_cgen_emit_cop_239(cop_t);
extern obj_t write_char_165___r4_output_6_10_3(unsigned char, obj_t);
extern obj_t cfun_ast_var;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t cif_cgen_cop;
static obj_t _emit_bdb_loc_198_cgen_emit_cop_239(obj_t, obj_t);
extern obj_t creturn_cgen_cop;
extern bool_t bigloo_strcmp(obj_t, obj_t);
static obj_t library_modules_init_112_cgen_emit_cop_239();
static obj_t lambda2167_cgen_emit_cop_239(obj_t, obj_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
extern obj_t rgc_buffer_substring(obj_t, int, int);
static obj_t toplevel_init_63_cgen_emit_cop_239();
extern bool_t emit_cop_45_cgen_emit_cop_239(cop_t);
extern obj_t capp_cgen_cop;
extern obj_t open_input_string(obj_t);
extern obj_t cvoid_cgen_cop;
extern obj_t cmake_box_177_cgen_cop;
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t emit_newline_191_cgen_emit_cop_239(obj_t);
extern obj_t csequence_cgen_cop;
extern obj_t cfail_cgen_cop;
extern obj_t make_string(long, unsigned char);
extern obj_t string__number_104___r4_numbers_6_5(obj_t, obj_t);
extern obj_t c_substring(obj_t, long, long);
extern obj_t cset_ex_it_123_cgen_cop;
static bool_t fprin_cgen_emit_cop_239(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t _char__84_type_cache;
static obj_t require_initialization_114_cgen_emit_cop_239 = BUNSPEC;
extern obj_t string_for_read(obj_t);
extern obj_t capply_cgen_cop;
static obj_t cnst_init_137_cgen_emit_cop_239();
extern obj_t cfuncall_cgen_cop;
extern obj_t _bool__149_type_cache;
static obj_t __cnst[8];

DEFINE_EXPORT_PROCEDURE(reset_bdb_loc__env_152_cgen_emit_cop_239, _reset_bdb_loc__118_cgen_emit_cop_2392672, _reset_bdb_loc__118_cgen_emit_cop_239, 0L, 0);
DEFINE_EXPORT_PROCEDURE(emit_newline_env_2_cgen_emit_cop_239, _emit_newline_88_cgen_emit_cop_2392673, va_generic_entry, _emit_newline_88_cgen_emit_cop_239, -1);
DEFINE_EXPORT_PROCEDURE(emit_bdb_loc_env_130_cgen_emit_cop_239, _emit_bdb_loc_198_cgen_emit_cop_2392674, _emit_bdb_loc_198_cgen_emit_cop_239, 0L, 1);
DEFINE_EXPORT_GENERIC(emit_cop_env_125_cgen_emit_cop_239, _emit_cop2618_201_cgen_emit_cop_2392675, _emit_cop2618_201_cgen_emit_cop_239, 0L, 1);
DEFINE_STRING(string2666_cgen_emit_cop_239, string2666_cgen_emit_cop_2392676, "EMIT-COP-DEFAULT1677 ELSE FOREIGN BFALSE LIGHT ELIGHT BIGLOO LOCATION ", 70);
DEFINE_STRING(string2665_cgen_emit_cop_239, string2665_cgen_emit_cop_2392677, "No method for this object", 25);
DEFINE_STRING(string2664_cgen_emit_cop_239, string2664_cgen_emit_cop_2392678, "Illegal match", 13);
DEFINE_STRING(string2663_cgen_emit_cop_239, string2663_cgen_emit_cop_2392679, "regular-grammar", 15);
DEFINE_STRING(string2662_cgen_emit_cop_239, string2662_cgen_emit_cop_2392680, "JUMP_EXIT( ", 11);
DEFINE_STRING(string2661_cgen_emit_cop_239, string2661_cgen_emit_cop_2392681, "} else {", 8);
DEFINE_STRING(string2659_cgen_emit_cop_239, string2659_cgen_emit_cop_2392682, ") ) {", 5);
DEFINE_STRING(string2660_cgen_emit_cop_239, string2660_cgen_emit_cop_2392683, "RESTORE_TRACE(); ", 17);
DEFINE_STRING(string2658_cgen_emit_cop_239, string2658_cgen_emit_cop_2392684, "if( SET_EXIT(", 13);
DEFINE_STRING(string2657_cgen_emit_cop_239, string2657_cgen_emit_cop_2392685, "CELL_SET(", 9);
DEFINE_STRING(string2656_cgen_emit_cop_239, string2656_cgen_emit_cop_2392686, "CELL_REF(", 9);
DEFINE_STRING(string2655_cgen_emit_cop_239, string2655_cgen_emit_cop_2392687, "MAKE_CELL(", 10);
DEFINE_STRING(string2654_cgen_emit_cop_239, string2654_cgen_emit_cop_2392688, "break;", 6);
DEFINE_STRING(string2653_cgen_emit_cop_239, string2653_cgen_emit_cop_2392689, "case ", 5);
DEFINE_STRING(string2652_cgen_emit_cop_239, string2652_cgen_emit_cop_2392690, "default: ", 9);
DEFINE_STRING(string2651_cgen_emit_cop_239, string2651_cgen_emit_cop_2392691, "switch ", 7);
DEFINE_STRING(string2649_cgen_emit_cop_239, string2649_cgen_emit_cop_2392692, "the_failure(", 12);
DEFINE_STRING(string2650_cgen_emit_cop_239, string2650_cgen_emit_cop_2392693, "), exit( -1 );", 14);
DEFINE_STRING(string2648_cgen_emit_cop_239, string2648_cgen_emit_cop_2392694, ");", 2);
DEFINE_STRING(string2647_cgen_emit_cop_239, string2647_cgen_emit_cop_2392695, "FAILURE(", 8);
DEFINE_STRING(string2646_cgen_emit_cop_239, string2646_cgen_emit_cop_2392696, "exit( -1 );", 11);
DEFINE_STRING(string2645_cgen_emit_cop_239, string2645_cgen_emit_cop_2392697, "apply(", 6);
DEFINE_STRING(string2644_cgen_emit_cop_239, string2644_cgen_emit_cop_2392698, "PROCEDURE_L_ENTRY(", 18);
DEFINE_STRING(string2643_cgen_emit_cop_239, string2643_cgen_emit_cop_2392699, ", ", 2);
DEFINE_STRING(string2642_cgen_emit_cop_239, string2642_cgen_emit_cop_2392700, ")(", 2);
DEFINE_STRING(string2641_cgen_emit_cop_239, string2641_cgen_emit_cop_2392701, "PROCEDURE_ENTRY(", 16);
DEFINE_STRING(string2639_cgen_emit_cop_239, string2639_cgen_emit_cop_2392702, " : ", 3);
DEFINE_STRING(string2640_cgen_emit_cop_239, string2640_cgen_emit_cop_2392703, " )", 2);
DEFINE_STRING(string2638_cgen_emit_cop_239, string2638_cgen_emit_cop_2392704, " ) ? ", 5);
DEFINE_STRING(string2637_cgen_emit_cop_239, string2637_cgen_emit_cop_2392705, "(VA_PROCUDUREP( ", 16);
DEFINE_STRING(string2636_cgen_emit_cop_239, string2636_cgen_emit_cop_2392706, "int bigloo_dummy_bdb; bigloo_dummy_bdb = 0; {", 45);
DEFINE_STRING(string2635_cgen_emit_cop_239, string2635_cgen_emit_cop_2392707, " = ((", 5);
DEFINE_STRING(string2634_cgen_emit_cop_239, string2634_cgen_emit_cop_2392708, ")BUNSPEC)", 9);
DEFINE_STRING(string2633_cgen_emit_cop_239, string2633_cgen_emit_cop_2392709, "", 0);
DEFINE_STRING(string2632_cgen_emit_cop_239, string2632_cgen_emit_cop_2392710, " else ", 6);
DEFINE_STRING(string2631_cgen_emit_cop_239, string2631_cgen_emit_cop_2392711, "if(", 3);
DEFINE_STRING(string2629_cgen_emit_cop_239, string2629_cgen_emit_cop_2392712, "return ", 7);
DEFINE_STRING(string2630_cgen_emit_cop_239, string2630_cgen_emit_cop_2392713, " = ", 3);
DEFINE_STRING(string2628_cgen_emit_cop_239, string2628_cgen_emit_cop_2392714, "goto ", 5);
DEFINE_STRING(string2627_cgen_emit_cop_239, string2627_cgen_emit_cop_2392715, "\n# ", 3);
DEFINE_STRING(string2626_cgen_emit_cop_239, string2626_cgen_emit_cop_2392716, " \"", 2);
DEFINE_STRING(string2625_cgen_emit_cop_239, string2625_cgen_emit_cop_2392717, "BCNST(", 6);
DEFINE_STRING(string2624_cgen_emit_cop_239, string2624_cgen_emit_cop_2392718, "BUNSPEC", 7);
DEFINE_STRING(string2623_cgen_emit_cop_239, string2623_cgen_emit_cop_2392719, "\\''", 3);
DEFINE_STRING(string2622_cgen_emit_cop_239, string2622_cgen_emit_cop_2392720, "'\\000'", 6);
DEFINE_STRING(string2621_cgen_emit_cop_239, string2621_cgen_emit_cop_2392721, ")", 1);
DEFINE_STRING(string2619_cgen_emit_cop_239, string2619_cgen_emit_cop_2392722, "((", 2);
DEFINE_STRING(string2620_cgen_emit_cop_239, string2620_cgen_emit_cop_2392723, "BNIL", 4);
DEFINE_STATIC_PROCEDURE(emit_cop_default1677_env_138_cgen_emit_cop_239, _emit_cop_default1677_176_cgen_emit_cop_2392724, _emit_cop_default1677_176_cgen_emit_cop_239, 0L, 1);
DEFINE_EXPORT_PROCEDURE(untrigraph_env_176_cgen_emit_cop_239, _untrigraph2617_cgen_emit_cop_2392725, _untrigraph2617_cgen_emit_cop_239, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_cgen_emit_cop_239(long checksum_3035, char *from_3036)
{
   if (CBOOL(require_initialization_114_cgen_emit_cop_239))
     {
	require_initialization_114_cgen_emit_cop_239 = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_emit_cop_239();
	cnst_init_137_cgen_emit_cop_239();
	imported_modules_init_94_cgen_emit_cop_239();
	method_init_76_cgen_emit_cop_239();
	toplevel_init_63_cgen_emit_cop_239();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_emit_cop_239()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70___object(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70___r4_vectors_6_8(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70___r4_strings_6_7(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70___r4_numbers_6_5(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70___reader(((long) 0), "CGEN_EMIT-COP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_emit_cop_239()
{
   {
      obj_t cnst_port_138_3027;
      cnst_port_138_3027 = open_input_string(string2666_cgen_emit_cop_239);
      {
	 long i_3028;
	 i_3028 = ((long) 7);
       loop_3029:
	 {
	    bool_t test2667_3030;
	    test2667_3030 = (i_3028 == ((long) -1));
	    if (test2667_3030)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2668_3031;
		    {
		       obj_t list2669_3032;
		       {
			  obj_t arg2670_3033;
			  arg2670_3033 = BNIL;
			  list2669_3032 = MAKE_PAIR(cnst_port_138_3027, arg2670_3033);
		       }
		       arg2668_3031 = read___reader(list2669_3032);
		    }
		    CNST_TABLE_SET(i_3028, arg2668_3031);
		 }
		 {
		    int aux_3034;
		    {
		       long aux_3058;
		       aux_3058 = (i_3028 - ((long) 1));
		       aux_3034 = (int) (aux_3058);
		    }
		    {
		       long i_3061;
		       i_3061 = (long) (aux_3034);
		       i_3028 = i_3061;
		       goto loop_3029;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_emit_cop_239()
{
   _bfalse__69_cgen_emit_cop_239 = BFALSE;
   return (_bdb_loc__137_cgen_emit_cop_239 = BUNSPEC,
      BUNSPEC);
}


/* emit-atom-value */ obj_t 
emit_atom_value_68_cgen_emit_cop_239(obj_t value_43)
{
   if (BOOLEANP(value_43))
     {
	{
	   obj_t list1723_1040;
	   list1723_1040 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	   display___r4_output_6_10_3(string2619_cgen_emit_cop_239, list1723_1040);
	}
	{
	   obj_t arg1725_1042;
	   {
	      obj_t arg1728_1045;
	      {
		 type_t obj_2440;
		 obj_2440 = (type_t) (_bool__149_type_cache);
		 arg1728_1045 = (((type_t) CREF(obj_2440))->name);
	      }
	      arg1725_1042 = string_sans___40_type_tools(arg1728_1045);
	   }
	   {
	      obj_t list1726_1043;
	      list1726_1043 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	      display___r4_output_6_10_3(arg1725_1042, list1726_1043);
	   }
	}
	{
	   obj_t list1729_1046;
	   list1729_1046 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	   display___r4_output_6_10_3(BCHAR(((unsigned char) ')')), list1729_1046);
	}
	{
	   long arg1731_1048;
	   if (CBOOL(value_43))
	     {
		arg1731_1048 = ((long) 1);
	     }
	   else
	     {
		arg1731_1048 = ((long) 0);
	     }
	   {
	      obj_t list1732_1049;
	      list1732_1049 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	      display___r4_output_6_10_3(BINT(arg1731_1048), list1732_1049);
	   }
	}
	{
	   obj_t list1734_1051;
	   list1734_1051 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	   return display___r4_output_6_10_3(BCHAR(((unsigned char) ')')), list1734_1051);
	}
     }
   else
     {
	if (NULLP(value_43))
	  {
	     {
		obj_t list1740_1054;
		list1740_1054 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		return display___r4_output_6_10_3(string2620_cgen_emit_cop_239, list1740_1054);
	     }
	  }
	else
	  {
	     if (CHARP(value_43))
	       {
		  {
		     obj_t list1745_1057;
		     list1745_1057 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		     display___r4_output_6_10_3(string2619_cgen_emit_cop_239, list1745_1057);
		  }
		  {
		     obj_t arg1747_1059;
		     {
			obj_t arg1753_1062;
			{
			   type_t obj_2443;
			   obj_2443 = (type_t) (_char__84_type_cache);
			   arg1753_1062 = (((type_t) CREF(obj_2443))->name);
			}
			arg1747_1059 = string_sans___40_type_tools(arg1753_1062);
		     }
		     {
			obj_t list1748_1060;
			list1748_1060 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			display___r4_output_6_10_3(arg1747_1059, list1748_1060);
		     }
		  }
		  {
		     obj_t list1754_1063;
		     list1754_1063 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		     display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list1754_1063);
		  }
		  {
		     bool_t test_3098;
		     {
			long aux_3099;
			{
			   unsigned char aux_3100;
			   aux_3100 = (unsigned char) CCHAR(value_43);
			   aux_3099 = (aux_3100);
			}
			test_3098 = (aux_3099 == ((long) 0));
		     }
		     if (test_3098)
		       {
			  obj_t list1757_1066;
			  list1757_1066 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			  display___r4_output_6_10_3(string2622_cgen_emit_cop_239, list1757_1066);
		       }
		     else
		       {
			  {
			     obj_t list1759_1068;
			     list1759_1068 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			     write_char_165___r4_output_6_10_3(((unsigned char) '\''), list1759_1068);
			  }
			  {
			     bool_t test_3108;
			     {
				long aux_3109;
				{
				   unsigned char aux_3110;
				   aux_3110 = (unsigned char) CCHAR(value_43);
				   aux_3109 = (aux_3110);
				}
				test_3108 = (aux_3109 == ((long) 39));
			     }
			     if (test_3108)
			       {
				  obj_t list1762_1071;
				  list1762_1071 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				  display___r4_output_6_10_3(string2623_cgen_emit_cop_239, list1762_1071);
			       }
			     else
			       {
				  {
				     if (CHARP(value_43))
				       {
					  switch ((unsigned char) CCHAR(value_43))
					    {
					    case ((unsigned char) '\r'):
					       {
						  obj_t list1767_1076;
						  list1767_1076 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) '\\'), list1767_1076);
					       }
					       {
						  obj_t list1769_1078;
						  list1769_1078 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) 'r'), list1769_1078);
					       }
					       break;
					    case ((unsigned char) '\t'):
					       {
						  obj_t list1771_1080;
						  list1771_1080 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) '\\'), list1771_1080);
					       }
					       {
						  obj_t list1773_1082;
						  list1773_1082 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) 't'), list1773_1082);
					       }
					       break;
					    case ((unsigned char) '\n'):
					       {
						  obj_t list1775_1084;
						  list1775_1084 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) '\\'), list1775_1084);
					       }
					       {
						  obj_t list1777_1086;
						  list1777_1086 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) 'n'), list1777_1086);
					       }
					       break;
					    case ((unsigned char) '\\'):
					       {
						  obj_t list1779_1088;
						  list1779_1088 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) '\\'), list1779_1088);
					       }
					       {
						  obj_t list1781_1090;
						  list1781_1090 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3(((unsigned char) '\\'), list1781_1090);
					       }
					       break;
					    default:
					     case_else1671_1073:
					       {
						  obj_t list1784_1092;
						  list1784_1092 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						  write_char_165___r4_output_6_10_3((unsigned char) CCHAR(value_43), list1784_1092);
					       }
					    }
				       }
				     else
				       {
					  goto case_else1671_1073;
				       }
				  }
				  {
				     obj_t list1787_1094;
				     list1787_1094 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				     write_char_165___r4_output_6_10_3(((unsigned char) '\''), list1787_1094);
				  }
			       }
			  }
		       }
		  }
		  {
		     obj_t list1793_1100;
		     list1793_1100 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		     return write_char_165___r4_output_6_10_3(((unsigned char) ')'), list1793_1100);
		  }
	       }
	     else
	       {
		  if ((value_43 == BUNSPEC))
		    {
		       {
			  obj_t list1796_1103;
			  list1796_1103 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			  return display___r4_output_6_10_3(string2624_cgen_emit_cop_239, list1796_1103);
		       }
		    }
		  else
		    {
		       if (CNSTP(value_43))
			 {
			    {
			       obj_t list1799_1106;
			       list1799_1106 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2625_cgen_emit_cop_239, list1799_1106);
			    }
			    {
			       long arg1802_1108;
			       arg1802_1108 = CCNST(value_43);
			       {
				  obj_t list1803_1109;
				  list1803_1109 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				  display___r4_output_6_10_3(BINT(arg1802_1108), list1803_1109);
			       }
			    }
			    {
			       obj_t list1805_1111;
			       list1805_1111 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       return display___r4_output_6_10_3(BCHAR(((unsigned char) ')')), list1805_1111);
			    }
			 }
		       else
			 {
			    if (STRINGP(value_43))
			      {
				 {
				    obj_t list1808_1114;
				    list1808_1114 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				    display___r4_output_6_10_3(BCHAR(((unsigned char) '"')), list1808_1114);
				 }
				 {
				    obj_t arg1810_1116;
				    {
				       obj_t arg1813_1119;
				       arg1813_1119 = string_for_read(value_43);
				       arg1810_1116 = untrigraph_cgen_emit_cop_239(arg1813_1119);
				    }
				    {
				       obj_t list1811_1117;
				       list1811_1117 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       display___r4_output_6_10_3(arg1810_1116, list1811_1117);
				    }
				 }
				 {
				    obj_t list1814_1120;
				    list1814_1120 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				    return display___r4_output_6_10_3(BCHAR(((unsigned char) '"')), list1814_1120);
				 }
			      }
			    else
			      {
				 if (INTEGERP(value_43))
				   {
				      {
					 obj_t list1817_1123;
					 list1817_1123 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					 display___r4_output_6_10_3(string2619_cgen_emit_cop_239, list1817_1123);
				      }
				      {
					 obj_t arg1820_1125;
					 {
					    obj_t arg1823_1128;
					    {
					       type_t obj_2456;
					       obj_2456 = (type_t) (_long__149_type_cache);
					       arg1823_1128 = (((type_t) CREF(obj_2456))->name);
					    }
					    arg1820_1125 = string_sans___40_type_tools(arg1823_1128);
					 }
					 {
					    obj_t list1821_1126;
					    list1821_1126 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    display___r4_output_6_10_3(arg1820_1125, list1821_1126);
					 }
				      }
				      {
					 obj_t list1824_1129;
					 list1824_1129 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					 display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list1824_1129);
				      }
				      {
					 obj_t list1827_1131;
					 list1827_1131 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					 display___r4_output_6_10_3(value_43, list1827_1131);
				      }
				      {
					 obj_t list1830_1133;
					 list1830_1133 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					 return display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list1830_1133);
				      }
				   }
				 else
				   {
				      if (REALP(value_43))
					{
					   {
					      obj_t list1833_1136;
					      list1833_1136 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					      display___r4_output_6_10_3(string2619_cgen_emit_cop_239, list1833_1136);
					   }
					   {
					      obj_t arg1835_1138;
					      {
						 obj_t arg1838_1141;
						 {
						    type_t obj_2458;
						    obj_2458 = (type_t) (_real__144_type_cache);
						    arg1838_1141 = (((type_t) CREF(obj_2458))->name);
						 }
						 arg1835_1138 = string_sans___40_type_tools(arg1838_1141);
					      }
					      {
						 obj_t list1836_1139;
						 list1836_1139 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						 display___r4_output_6_10_3(arg1835_1138, list1836_1139);
					      }
					   }
					   {
					      obj_t list1839_1142;
					      list1839_1142 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					      display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list1839_1142);
					   }
					   {
					      obj_t list1843_1144;
					      list1843_1144 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					      display___r4_output_6_10_3(value_43, list1843_1144);
					   }
					   {
					      obj_t list1848_1146;
					      list1848_1146 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					      return display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list1848_1146);
					   }
					}
				      else
					{
					   {
					      obj_t list1851_1148;
					      list1851_1148 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					      return display___r4_output_6_10_3(value_43, list1851_1148);
					   }
					}
				   }
			      }
			 }
		    }
	       }
	  }
     }
}


/* untrigraph */ obj_t 
untrigraph_cgen_emit_cop_239(obj_t from_44)
{
   {
      long len_1150;
      len_1150 = STRING_LENGTH(from_44);
      {
	 long len_3_234_1151;
	 len_3_234_1151 = (len_1150 - ((long) 3));
	 {
	    {
	       long nb_col_224_1152;
	       {
		  long i_1210;
		  long nb_col_224_1211;
		  i_1210 = ((long) 0);
		  nb_col_224_1211 = ((long) 0);
		loop_1212:
		  if ((i_1210 > len_3_234_1151))
		    {
		       nb_col_224_1152 = nb_col_224_1211;
		    }
		  else
		    {
		       bool_t test_3206;
		       {
			  unsigned char aux_3207;
			  aux_3207 = STRING_REF(from_44, i_1210);
			  test_3206 = (aux_3207 == ((unsigned char) '?'));
		       }
		       if (test_3206)
			 {
			    bool_t test_3210;
			    {
			       unsigned char aux_3211;
			       {
				  long aux_3212;
				  aux_3212 = (i_1210 + ((long) 1));
				  aux_3211 = STRING_REF(from_44, aux_3212);
			       }
			       test_3210 = (aux_3211 == ((unsigned char) '?'));
			    }
			    if (test_3210)
			      {
				 {
				    long nb_col_224_3218;
				    long i_3216;
				    i_3216 = (i_1210 + ((long) 3));
				    nb_col_224_3218 = (nb_col_224_1211 + ((long) 1));
				    nb_col_224_1211 = nb_col_224_3218;
				    i_1210 = i_3216;
				    goto loop_1212;
				 }
			      }
			    else
			      {
				 {
				    long i_3220;
				    i_3220 = (i_1210 + ((long) 2));
				    i_1210 = i_3220;
				    goto loop_1212;
				 }
			      }
			 }
		       else
			 {
			    {
			       long i_3222;
			       i_3222 = (i_1210 + ((long) 1));
			       i_1210 = i_3222;
			       goto loop_1212;
			    }
			 }
		    }
	       }
	       if ((nb_col_224_1152 == ((long) 0)))
		 {
		    return from_44;
		 }
	       else
		 {
		    obj_t res_1154;
		    {
		       obj_t res2610_2496;
		       {
			  long aux_3226;
			  {
			     int aux_3227;
			     {
				long aux_3228;
				{
				   long aux_3229;
				   {
				      long aux_3230;
				      aux_3230 = (nb_col_224_1152 * ((long) 3));
				      aux_3229 = (((long) 3) * aux_3230);
				   }
				   aux_3228 = (len_1150 + aux_3229);
				}
				aux_3227 = (int) (aux_3228);
			     }
			     aux_3226 = (long) (aux_3227);
			  }
			  res2610_2496 = make_string(aux_3226, ((unsigned char) ' '));
		       }
		       res_1154 = res2610_2496;
		    }
		    {
		       long r_1156;
		       long w_1157;
		       r_1156 = ((long) 0);
		       w_1157 = ((long) 0);
		     loop_1158:
		       if ((r_1156 == len_1150))
			 {
			    return res_1154;
			 }
		       else
			 {
			    bool_t test_3239;
			    {
			       bool_t test_3240;
			       {
				  unsigned char aux_3241;
				  aux_3241 = STRING_REF(from_44, r_1156);
				  test_3240 = (aux_3241 == ((unsigned char) '?'));
			       }
			       if (test_3240)
				 {
				    test_3239 = (r_1156 > len_3_234_1151);
				 }
			       else
				 {
				    test_3239 = ((bool_t) 1);
				 }
			    }
			    if (test_3239)
			      {
				 {
				    unsigned char aux_3245;
				    aux_3245 = STRING_REF(from_44, r_1156);
				    STRING_SET(res_1154, w_1157, aux_3245);
				 }
				 {
				    long w_3250;
				    long r_3248;
				    r_3248 = (r_1156 + ((long) 1));
				    w_3250 = (w_1157 + ((long) 1));
				    w_1157 = w_3250;
				    r_1156 = r_3248;
				    goto loop_1158;
				 }
			      }
			    else
			      {
				 bool_t test_3252;
				 {
				    unsigned char aux_3253;
				    {
				       long aux_3254;
				       aux_3254 = (r_1156 + ((long) 1));
				       aux_3253 = STRING_REF(from_44, aux_3254);
				    }
				    test_3252 = (aux_3253 == ((unsigned char) '?'));
				 }
				 if (test_3252)
				   {
				      STRING_SET(res_1154, w_1157, ((unsigned char) '\\'));
				      {
					 long aux_3259;
					 aux_3259 = (w_1157 + ((long) 1));
					 STRING_SET(res_1154, aux_3259, ((unsigned char) '0'));
				      }
				      {
					 long aux_3262;
					 aux_3262 = (w_1157 + ((long) 2));
					 STRING_SET(res_1154, aux_3262, ((unsigned char) '7'));
				      }
				      {
					 long aux_3265;
					 aux_3265 = (w_1157 + ((long) 3));
					 STRING_SET(res_1154, aux_3265, ((unsigned char) '7'));
				      }
				      {
					 long aux_3268;
					 aux_3268 = (w_1157 + ((long) 4));
					 STRING_SET(res_1154, aux_3268, ((unsigned char) '\\'));
				      }
				      {
					 long aux_3271;
					 aux_3271 = (w_1157 + ((long) 5));
					 STRING_SET(res_1154, aux_3271, ((unsigned char) '0'));
				      }
				      {
					 long aux_3274;
					 aux_3274 = (w_1157 + ((long) 6));
					 STRING_SET(res_1154, aux_3274, ((unsigned char) '7'));
				      }
				      {
					 long aux_3277;
					 aux_3277 = (w_1157 + ((long) 7));
					 STRING_SET(res_1154, aux_3277, ((unsigned char) '7'));
				      }
				      {
					 long aux_3280;
					 aux_3280 = (w_1157 + ((long) 8));
					 STRING_SET(res_1154, aux_3280, ((unsigned char) '\\'));
				      }
				      {
					 char *code_1173;
					 {
					    long arg1885_1188;
					    {
					       unsigned char aux_3283;
					       {
						  long aux_3284;
						  aux_3284 = (r_1156 + ((long) 2));
						  aux_3283 = STRING_REF(from_44, aux_3284);
					       }
					       arg1885_1188 = (aux_3283);
					    }
					    {
					       obj_t list1887_1190;
					       {
						  obj_t aux_3288;
						  aux_3288 = BINT(((long) 8));
						  list1887_1190 = MAKE_PAIR(aux_3288, BNIL);
					       }
					       code_1173 = integer__string_135___r4_numbers_6_5_fixnum(arg1885_1188, list1887_1190);
					    }
					 }
					 {
					    bool_t test_3292;
					    {
					       long aux_3293;
					       {
						  obj_t aux_3294;
						  aux_3294 = string_to_bstring(code_1173);
						  aux_3293 = STRING_LENGTH(aux_3294);
					       }
					       test_3292 = (aux_3293 == ((long) 4));
					    }
					    if (test_3292)
					      {
						 {
						    long aux_3298;
						    aux_3298 = (w_1157 + ((long) 9));
						    STRING_SET(res_1154, aux_3298, ((unsigned char) '0'));
						 }
						 {
						    unsigned char aux_3303;
						    long aux_3301;
						    {
						       obj_t aux_3304;
						       aux_3304 = string_to_bstring(code_1173);
						       aux_3303 = STRING_REF(aux_3304, ((long) 2));
						    }
						    aux_3301 = (w_1157 + ((long) 10));
						    STRING_SET(res_1154, aux_3301, aux_3303);
						 }
						 {
						    unsigned char aux_3310;
						    long aux_3308;
						    {
						       obj_t aux_3311;
						       aux_3311 = string_to_bstring(code_1173);
						       aux_3310 = STRING_REF(aux_3311, ((long) 3));
						    }
						    aux_3308 = (w_1157 + ((long) 11));
						    STRING_SET(res_1154, aux_3308, aux_3310);
						 }
					      }
					    else
					      {
						 {
						    unsigned char aux_3317;
						    long aux_3315;
						    {
						       obj_t aux_3318;
						       aux_3318 = string_to_bstring(code_1173);
						       aux_3317 = STRING_REF(aux_3318, ((long) 2));
						    }
						    aux_3315 = (w_1157 + ((long) 9));
						    STRING_SET(res_1154, aux_3315, aux_3317);
						 }
						 {
						    unsigned char aux_3324;
						    long aux_3322;
						    {
						       obj_t aux_3325;
						       aux_3325 = string_to_bstring(code_1173);
						       aux_3324 = STRING_REF(aux_3325, ((long) 3));
						    }
						    aux_3322 = (w_1157 + ((long) 10));
						    STRING_SET(res_1154, aux_3322, aux_3324);
						 }
						 {
						    unsigned char aux_3331;
						    long aux_3329;
						    {
						       obj_t aux_3332;
						       aux_3332 = string_to_bstring(code_1173);
						       aux_3331 = STRING_REF(aux_3332, ((long) 4));
						    }
						    aux_3329 = (w_1157 + ((long) 11));
						    STRING_SET(res_1154, aux_3329, aux_3331);
						 }
					      }
					 }
				      }
				      {
					 long w_3338;
					 long r_3336;
					 r_3336 = (r_1156 + ((long) 3));
					 w_3338 = (w_1157 + ((long) 12));
					 w_1157 = w_3338;
					 r_1156 = r_3336;
					 goto loop_1158;
				      }
				   }
				 else
				   {
				      STRING_SET(res_1154, w_1157, ((unsigned char) '?'));
				      {
					 unsigned char aux_3343;
					 long aux_3341;
					 {
					    long aux_3344;
					    aux_3344 = (r_1156 + ((long) 1));
					    aux_3343 = STRING_REF(from_44, aux_3344);
					 }
					 aux_3341 = (w_1157 + ((long) 1));
					 STRING_SET(res_1154, aux_3341, aux_3343);
				      }
				      {
					 long w_3350;
					 long r_3348;
					 r_3348 = (r_1156 + ((long) 2));
					 w_3350 = (w_1157 + ((long) 2));
					 w_1157 = w_3350;
					 r_1156 = r_3348;
					 goto loop_1158;
				      }
				   }
			      }
			 }
		    }
		 }
	    }
	 }
      }
   }
}


/* _untrigraph2617 */ obj_t 
_untrigraph2617_cgen_emit_cop_239(obj_t env_3010, obj_t from_3011)
{
   return untrigraph_cgen_emit_cop_239(from_3011);
}


/* reset-bdb-loc! */ obj_t 
reset_bdb_loc__217_cgen_emit_cop_239()
{
   return (_bdb_loc__137_cgen_emit_cop_239 = BUNSPEC,
      BUNSPEC);
}


/* _reset-bdb-loc! */ obj_t 
_reset_bdb_loc__118_cgen_emit_cop_239(obj_t env_3012)
{
   return reset_bdb_loc__217_cgen_emit_cop_239();
}


/* emit-bdb-loc */ obj_t 
emit_bdb_loc_8_cgen_emit_cop_239(obj_t cur_loc_243_45)
{
 emit_bdb_loc_8_cgen_emit_cop_239:
   {
      bool_t test1921_1223;
      {
	 long n1_2633;
	 n1_2633 = (long) CINT(_bdb_debug__1_engine_param);
	 test1921_1223 = (n1_2633 <= ((long) 0));
      }
      if (test1921_1223)
	{
	   return BUNSPEC;
	}
      else
	{
	   bool_t test_3357;
	   if (STRUCTP(cur_loc_243_45))
	     {
		obj_t aux_3362;
		obj_t aux_3360;
		aux_3362 = CNST_TABLE_REF(((long) 0));
		aux_3360 = STRUCT_KEY(cur_loc_243_45);
		test_3357 = (aux_3360 == aux_3362);
	     }
	   else
	     {
		test_3357 = ((bool_t) 0);
	     }
	   if (test_3357)
	     {
		{
		   obj_t cur_fname_227_1225;
		   obj_t cur_line_130_1226;
		   obj_t prev_loc_190_1227;
		   cur_fname_227_1225 = STRUCT_REF(cur_loc_243_45, ((long) 0));
		   cur_line_130_1226 = STRUCT_REF(cur_loc_243_45, ((long) 2));
		   prev_loc_190_1227 = _bdb_loc__137_cgen_emit_cop_239;
		   {
		      bool_t test1923_1228;
		      {
			 bool_t test_3367;
			 if (STRUCTP(prev_loc_190_1227))
			   {
			      obj_t aux_3372;
			      obj_t aux_3370;
			      aux_3372 = CNST_TABLE_REF(((long) 0));
			      aux_3370 = STRUCT_KEY(prev_loc_190_1227);
			      test_3367 = (aux_3370 == aux_3372);
			   }
			 else
			   {
			      test_3367 = ((bool_t) 0);
			   }
			 if (test_3367)
			   {
			      obj_t prev_fname_193_1238;
			      prev_fname_193_1238 = STRUCT_REF(prev_loc_190_1227, ((long) 0));
			      {
				 bool_t _ortest_1673_1239;
				 _ortest_1673_1239 = (cur_fname_227_1225 == prev_fname_193_1238);
				 if (_ortest_1673_1239)
				   {
				      test1923_1228 = _ortest_1673_1239;
				   }
				 else
				   {
				      test1923_1228 = bigloo_strcmp(cur_fname_227_1225, prev_fname_193_1238);
				   }
			      }
			   }
			 else
			   {
			      test1923_1228 = ((bool_t) 1);
			   }
		      }
		      if (test1923_1228)
			{
			   {
			      obj_t list1924_1229;
			      {
				 obj_t arg1927_1231;
				 {
				    obj_t arg1928_1232;
				    {
				       obj_t arg1930_1234;
				       {
					  obj_t arg1931_1235;
					  {
					     obj_t aux_3380;
					     aux_3380 = BCHAR(((unsigned char) '"'));
					     arg1931_1235 = MAKE_PAIR(aux_3380, BNIL);
					  }
					  arg1930_1234 = MAKE_PAIR(cur_fname_227_1225, arg1931_1235);
				       }
				       arg1928_1232 = MAKE_PAIR(string2626_cgen_emit_cop_239, arg1930_1234);
				    }
				    arg1927_1231 = MAKE_PAIR(cur_line_130_1226, arg1928_1232);
				 }
				 list1924_1229 = MAKE_PAIR(string2627_cgen_emit_cop_239, arg1927_1231);
			      }
			      fprint___r4_output_6_10_3(_c_port__188_cgen_emit, list1924_1229);
			   }
			   return (_bdb_loc__137_cgen_emit_cop_239 = cur_loc_243_45,
			      BUNSPEC);
			}
		      else
			{
			   return BUNSPEC;
			}
		   }
		}
	     }
	   else
	     {
		{
		   bool_t test1934_1240;
		   {
		      obj_t o_2664;
		      o_2664 = _bdb_loc__137_cgen_emit_cop_239;
		      if (STRUCTP(o_2664))
			{
			   obj_t aux_3392;
			   obj_t aux_3390;
			   aux_3392 = CNST_TABLE_REF(((long) 0));
			   aux_3390 = STRUCT_KEY(o_2664);
			   test1934_1240 = (aux_3390 == aux_3392);
			}
		      else
			{
			   test1934_1240 = ((bool_t) 0);
			}
		   }
		   if (test1934_1240)
		     {
			obj_t cur_loc_243_3396;
			cur_loc_243_3396 = _bdb_loc__137_cgen_emit_cop_239;
			cur_loc_243_45 = cur_loc_243_3396;
			goto emit_bdb_loc_8_cgen_emit_cop_239;
		     }
		   else
		     {
			return BUNSPEC;
		     }
		}
	     }
	}
   }
}


/* _emit-bdb-loc */ obj_t 
_emit_bdb_loc_198_cgen_emit_cop_239(obj_t env_3013, obj_t cur_loc_243_3014)
{
   return emit_bdb_loc_8_cgen_emit_cop_239(cur_loc_243_3014);
}


/* emit-newline */ obj_t 
emit_newline_191_cgen_emit_cop_239(obj_t mandatory_46)
{
   {
      bool_t test1935_1241;
      {
	 long n1_2672;
	 n1_2672 = (long) CINT(_bdb_debug__1_engine_param);
	 test1935_1241 = (n1_2672 <= ((long) 0));
      }
      if (test1935_1241)
	{
	   {
	      obj_t list1936_1242;
	      list1936_1242 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	      return newline___r4_output_6_10_3(list1936_1242);
	   }
	}
      else
	{
	   if (PAIRP(mandatory_46))
	     {
		{
		   bool_t test1939_1245;
		   {
		      obj_t o_2675;
		      o_2675 = _bdb_loc__137_cgen_emit_cop_239;
		      if (STRUCTP(o_2675))
			{
			   obj_t aux_3409;
			   obj_t aux_3407;
			   aux_3409 = CNST_TABLE_REF(((long) 0));
			   aux_3407 = STRUCT_KEY(o_2675);
			   test1939_1245 = (aux_3407 == aux_3409);
			}
		      else
			{
			   test1939_1245 = ((bool_t) 0);
			}
		   }
		   if (test1939_1245)
		     {
			return emit_bdb_loc_8_cgen_emit_cop_239(_bdb_loc__137_cgen_emit_cop_239);
		     }
		   else
		     {
			obj_t list1940_1246;
			list1940_1246 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			return newline___r4_output_6_10_3(list1940_1246);
		     }
		}
	     }
	   else
	     {
		{
		   obj_t list1942_1248;
		   list1942_1248 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		   return write_char_165___r4_output_6_10_3(((unsigned char) ' '), list1942_1248);
		}
	     }
	}
   }
}


/* _emit-newline */ obj_t 
_emit_newline_88_cgen_emit_cop_239(obj_t env_3015, obj_t mandatory_3016)
{
   return emit_newline_191_cgen_emit_cop_239(mandatory_3016);
}


/* fprin */ bool_t 
fprin_cgen_emit_cop_239(obj_t port_47, obj_t values_48)
{
   {
      obj_t l1674_1250;
      l1674_1250 = values_48;
    lname1675_1251:
      if (PAIRP(l1674_1250))
	{
	   {
	      obj_t value_1253;
	      value_1253 = CAR(l1674_1250);
	      {
		 obj_t list1945_1254;
		 list1945_1254 = MAKE_PAIR(port_47, BNIL);
		 display___r4_output_6_10_3(value_1253, list1945_1254);
	      }
	   }
	   {
	      obj_t l1674_3424;
	      l1674_3424 = CDR(l1674_1250);
	      l1674_1250 = l1674_3424;
	      goto lname1675_1251;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_cgen_emit_cop_239()
{
   add_generic__110___object(emit_cop_env_125_cgen_emit_cop_239, emit_cop_default1677_env_138_cgen_emit_cop_239);
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, clabel_cgen_cop, ((long) 0));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cgoto_cgen_cop, ((long) 1));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, block_cgen_cop, ((long) 2));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, creturn_cgen_cop, ((long) 3));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, catom_cgen_cop, ((long) 4));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cvoid_cgen_cop, ((long) 5));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, varc_cgen_cop, ((long) 6));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cpragma_cgen_cop, ((long) 7));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, ccast_cgen_cop, ((long) 8));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, csequence_cgen_cop, ((long) 9));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, nop_cgen_cop, ((long) 10));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, stop_cgen_cop, ((long) 11));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, csetq_cgen_cop, ((long) 12));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cif_cgen_cop, ((long) 13));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, local_var_164_cgen_cop, ((long) 14));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, bdb_block_21_cgen_cop, ((long) 15));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cfuncall_cgen_cop, ((long) 16));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, capply_cgen_cop, ((long) 17));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, capp_cgen_cop, ((long) 18));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cfail_cgen_cop, ((long) 19));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cswitch_cgen_cop, ((long) 20));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cmake_box_177_cgen_cop, ((long) 21));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cbox_ref_44_cgen_cop, ((long) 22));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cbox_set__132_cgen_cop, ((long) 23));
   add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cset_ex_it_123_cgen_cop, ((long) 24));
   {
      long aux_3452;
      aux_3452 = add_inlined_method__244___object(emit_cop_env_125_cgen_emit_cop_239, cjump_ex_it_131_cgen_cop, ((long) 25));
      return BINT(aux_3452);
   }
}


/* emit-cop */ bool_t 
emit_cop_45_cgen_emit_cop_239(cop_t cop_15)
{
   {
      obj_t method2094_1776;
      obj_t class2099_1777;
      {
	 obj_t arg2105_1774;
	 obj_t arg2106_1775;
	 {
	    object_t obj_2705;
	    obj_2705 = (object_t) (cop_15);
	    {
	       obj_t pre_method_105_2706;
	       pre_method_105_2706 = PROCEDURE_REF(emit_cop_env_125_cgen_emit_cop_239, ((long) 2));
	       if (INTEGERP(pre_method_105_2706))
		 {
		    PROCEDURE_SET(emit_cop_env_125_cgen_emit_cop_239, ((long) 2), BUNSPEC);
		    arg2105_1774 = pre_method_105_2706;
		 }
	       else
		 {
		    long obj_class_num_177_2711;
		    obj_class_num_177_2711 = TYPE(obj_2705);
		    {
		       obj_t arg1177_2712;
		       arg1177_2712 = PROCEDURE_REF(emit_cop_env_125_cgen_emit_cop_239, ((long) 1));
		       {
			  long arg1178_2716;
			  {
			     long arg1179_2717;
			     arg1179_2717 = OBJECT_TYPE;
			     arg1178_2716 = (obj_class_num_177_2711 - arg1179_2717);
			  }
			  arg2105_1774 = VECTOR_REF(arg1177_2712, arg1178_2716);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2722;
	    object_2722 = (object_t) (cop_15);
	    {
	       long arg1180_2723;
	       {
		  long arg1181_2724;
		  long arg1182_2725;
		  arg1181_2724 = TYPE(object_2722);
		  arg1182_2725 = OBJECT_TYPE;
		  arg1180_2723 = (arg1181_2724 - arg1182_2725);
	       }
	       {
		  obj_t vector_2729;
		  vector_2729 = _classes__134___object;
		  arg2106_1775 = VECTOR_REF(vector_2729, arg1180_2723);
	       }
	    }
	 }
	 {
	    obj_t aux_3470;
	    method2094_1776 = arg2105_1774;
	    class2099_1777 = arg2106_1775;
	    {
	       if (INTEGERP(method2094_1776))
		 {
		    switch ((long) CINT(method2094_1776))
		      {
		      case ((long) 0):
			 {
			    clabel_t cop_1783;
			    cop_1783 = (clabel_t) (cop_15);
			    if ((((clabel_t) CREF(cop_1783))->used__226))
			      {
				 emit_bdb_loc_8_cgen_emit_cop_239((((clabel_t) CREF(cop_1783))->loc));
				 {
				    obj_t arg2112_1787;
				    arg2112_1787 = (((clabel_t) CREF(cop_1783))->name);
				    {
				       obj_t list2113_1788;
				       list2113_1788 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       display___r4_output_6_10_3(arg2112_1787, list2113_1788);
				    }
				 }
				 {
				    obj_t list2115_1790;
				    list2115_1790 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				    write_char_165___r4_output_6_10_3(((unsigned char) ':'), list2115_1790);
				 }
				 emit_newline_191_cgen_emit_cop_239(BNIL);
			      }
			    else
			      {
				 BUNSPEC;
			      }
			    {
			       bool_t aux_3484;
			       {
				  cop_t aux_3485;
				  {
				     obj_t aux_3486;
				     aux_3486 = (((clabel_t) CREF(cop_1783))->body);
				     aux_3485 = (cop_t) (aux_3486);
				  }
				  aux_3484 = emit_cop_45_cgen_emit_cop_239(aux_3485);
			       }
			       aux_3470 = BBOOL(aux_3484);
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    cgoto_t cop_1794;
			    cop_1794 = (cgoto_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cgoto_t) CREF(cop_1794))->loc));
			    {
			       obj_t arg2123_1798;
			       {
				  clabel_t arg2131_1803;
				  arg2131_1803 = (((cgoto_t) CREF(cop_1794))->label);
				  arg2123_1798 = (((clabel_t) CREF(arg2131_1803))->name);
			       }
			       {
				  obj_t list2124_1799;
				  {
				     obj_t arg2125_1800;
				     {
					obj_t arg2127_1801;
					{
					   obj_t aux_3496;
					   aux_3496 = BCHAR(((unsigned char) ';'));
					   arg2127_1801 = MAKE_PAIR(aux_3496, BNIL);
					}
					arg2125_1800 = MAKE_PAIR(arg2123_1798, arg2127_1801);
				     }
				     list2124_1799 = MAKE_PAIR(string2628_cgen_emit_cop_239, arg2125_1800);
				  }
				  fprin_cgen_emit_cop_239(_c_port__188_cgen_emit, list2124_1799);
			       }
			    }
			    emit_newline_191_cgen_emit_cop_239(BNIL);
			    aux_3470 = BFALSE;
			 }
			 break;
		      case ((long) 2):
			 {
			    block_t cop_1805;
			    cop_1805 = (block_t) (cop_15);
			    {
			       bool_t test2133_1807;
			       {
				  obj_t aux_3504;
				  {
				     cop_t aux_3505;
				     aux_3505 = (((block_t) CREF(cop_1805))->body);
				     aux_3504 = (obj_t) (aux_3505);
				  }
				  test2133_1807 = is_a__118___object(aux_3504, block_cgen_cop);
			       }
			       if (test2133_1807)
				 {
				    bool_t aux_3510;
				    aux_3510 = emit_cop_45_cgen_emit_cop_239((((block_t) CREF(cop_1805))->body));
				    aux_3470 = BBOOL(aux_3510);
				 }
			       else
				 {
				    emit_bdb_loc_8_cgen_emit_cop_239((((block_t) CREF(cop_1805))->loc));
				    {
				       obj_t list2136_1810;
				       list2136_1810 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       write_char_165___r4_output_6_10_3(((unsigned char) '{'), list2136_1810);
				    }
				    emit_newline_191_cgen_emit_cop_239(BNIL);
				    {
				       bool_t test2139_1813;
				       test2139_1813 = emit_cop_45_cgen_emit_cop_239((((block_t) CREF(cop_1805))->body));
				       if (test2139_1813)
					 {
					    {
					       obj_t list2140_1814;
					       list2140_1814 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					       write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2140_1814);
					    }
					    emit_newline_191_cgen_emit_cop_239(BNIL);
					 }
				       else
					 {
					    BUNSPEC;
					 }
				    }
				    {
				       obj_t list2144_1818;
				       list2144_1818 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       write_char_165___r4_output_6_10_3(((unsigned char) '}'), list2144_1818);
				    }
				    emit_newline_191_cgen_emit_cop_239(BNIL);
				    aux_3470 = BFALSE;
				 }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    creturn_t cop_1822;
			    cop_1822 = (creturn_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((creturn_t) CREF(cop_1822))->loc));
			    {
			       obj_t list2149_1825;
			       list2149_1825 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2629_cgen_emit_cop_239, list2149_1825);
			    }
			    {
			       bool_t test2151_1827;
			       test2151_1827 = emit_cop_45_cgen_emit_cop_239((((creturn_t) CREF(cop_1822))->value));
			       if (test2151_1827)
				 {
				    {
				       obj_t list2152_1828;
				       list2152_1828 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2152_1828);
				    }
				    emit_newline_191_cgen_emit_cop_239(BNIL);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    aux_3470 = BFALSE;
			 }
			 break;
		      case ((long) 4):
			 {
			    catom_t cop_1832;
			    cop_1832 = (catom_t) (cop_15);
			    emit_atom_value_68_cgen_emit_cop_239((((catom_t) CREF(cop_1832))->value));
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 5):
			 {
			    cvoid_t cop_1835;
			    cop_1835 = (cvoid_t) (cop_15);
			    {
			       bool_t aux_3543;
			       aux_3543 = emit_cop_45_cgen_emit_cop_239((((cvoid_t) CREF(cop_1835))->value));
			       aux_3470 = BBOOL(aux_3543);
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    varc_t cop_1838;
			    cop_1838 = (varc_t) (cop_15);
			    {
			       obj_t arg2158_1840;
			       {
				  variable_t arg2161_1843;
				  arg2161_1843 = (((varc_t) CREF(cop_1838))->variable);
				  arg2158_1840 = (((variable_t) CREF(arg2161_1843))->name);
			       }
			       {
				  obj_t list2159_1841;
				  list2159_1841 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				  display___r4_output_6_10_3(arg2158_1840, list2159_1841);
			       }
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 7):
			 {
			    cpragma_t cop_1844;
			    cop_1844 = (cpragma_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cpragma_t) CREF(cop_1844))->loc));
			    {
			       bool_t test_3555;
			       {
				  obj_t aux_3556;
				  aux_3556 = (((cpragma_t) CREF(cop_1844))->args);
				  test_3555 = NULLP(aux_3556);
			       }
			       if (test_3555)
				 {
				    obj_t arg2164_1848;
				    arg2164_1848 = (((cpragma_t) CREF(cop_1844))->format);
				    {
				       obj_t list2165_1849;
				       list2165_1849 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       aux_3470 = display___r4_output_6_10_3(arg2164_1848, list2165_1849);
				    }
				 }
			       else
				 {
				    obj_t sport_1851;
				    {
				       obj_t aux_3562;
				       aux_3562 = (((cpragma_t) CREF(cop_1844))->format);
				       sport_1851 = open_input_string(aux_3562);
				    }
				    {
				       obj_t args_1852;
				       args_1852 = list__vector_101___r4_vectors_6_8((((cpragma_t) CREF(cop_1844))->args));
				       {
					  obj_t parser_1853;
					  {
					     obj_t lambda2167_3021;
					     lambda2167_3021 = MAKE_EL_PROCEDURE_1(((long) 1));
					     PROCEDURE_1_EL_SET(lambda2167_3021, ((long) 0), args_1852);
					     parser_1853 = lambda2167_3021;
					  }
					  {
					     lambda2167_cgen_emit_cop_239(parser_1853, sport_1851);
					     aux_3470 = BTRUE;
					  }
				       }
				    }
				 }
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    ccast_t cop_1988;
			    cop_1988 = (ccast_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((ccast_t) CREF(cop_1988))->loc));
			    {
			       obj_t list2237_1991;
			       list2237_1991 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2619_cgen_emit_cop_239, list2237_1991);
			    }
			    {
			       obj_t arg2239_1993;
			       {
				  type_t arg2243_1996;
				  arg2243_1996 = (((ccast_t) CREF(cop_1988))->type);
				  arg2239_1993 = (((type_t) CREF(arg2243_1996))->name);
			       }
			       {
				  obj_t list2240_1994;
				  list2240_1994 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				  display___r4_output_6_10_3(arg2239_1993, list2240_1994);
			       }
			    }
			    {
			       obj_t list2244_1997;
			       list2244_1997 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2244_1997);
			    }
			    emit_cop_45_cgen_emit_cop_239((((ccast_t) CREF(cop_1988))->arg));
			    {
			       obj_t list2248_2000;
			       list2248_2000 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2248_2000);
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 9):
			 {
			    csequence_t cop_2002;
			    cop_2002 = (csequence_t) (cop_15);
			    if ((((csequence_t) CREF(cop_2002))->c_exp__163))
			      {
				 {
				    bool_t test_3589;
				    {
				       obj_t aux_3590;
				       aux_3590 = (((csequence_t) CREF(cop_2002))->cops);
				       test_3589 = NULLP(aux_3590);
				    }
				    if (test_3589)
				      {
					 aux_3470 = emit_atom_value_68_cgen_emit_cop_239(BUNSPEC);
				      }
				    else
				      {
					 {
					    obj_t list2253_2006;
					    list2253_2006 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    write_char_165___r4_output_6_10_3(((unsigned char) '('), list2253_2006);
					 }
					 {
					    obj_t exp_2008;
					    {
					       bool_t aux_3596;
					       exp_2008 = (((csequence_t) CREF(cop_2002))->cops);
					     liip_2009:
					       {
						  bool_t test_3597;
						  {
						     obj_t aux_3598;
						     aux_3598 = CDR(exp_2008);
						     test_3597 = NULLP(aux_3598);
						  }
						  if (test_3597)
						    {
						       {
							  cop_t aux_3601;
							  {
							     obj_t aux_3602;
							     aux_3602 = CAR(exp_2008);
							     aux_3601 = (cop_t) (aux_3602);
							  }
							  emit_cop_45_cgen_emit_cop_239(aux_3601);
						       }
						       {
							  obj_t list2259_2013;
							  list2259_2013 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							  write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2259_2013);
						       }
						       aux_3596 = ((bool_t) 1);
						    }
						  else
						    {
						       {
							  cop_t aux_3608;
							  {
							     obj_t aux_3609;
							     aux_3609 = CAR(exp_2008);
							     aux_3608 = (cop_t) (aux_3609);
							  }
							  emit_cop_45_cgen_emit_cop_239(aux_3608);
						       }
						       {
							  bool_t test2262_2016;
							  test2262_2016 = is_a__118___object(CAR(exp_2008), cfail_cgen_cop);
							  if (test2262_2016)
							    {
							       {
								  obj_t list2263_2017;
								  list2263_2017 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
								  write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2263_2017);
							       }
							       aux_3596 = ((bool_t) 1);
							    }
							  else
							    {
							       {
								  obj_t list2265_2019;
								  list2265_2019 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
								  write_char_165___r4_output_6_10_3(((unsigned char) ','), list2265_2019);
							       }
							       emit_newline_191_cgen_emit_cop_239(BNIL);
							       {
								  obj_t exp_3621;
								  exp_3621 = CDR(exp_2008);
								  exp_2008 = exp_3621;
								  goto liip_2009;
							       }
							    }
						       }
						    }
					       }
					       aux_3470 = BBOOL(aux_3596);
					    }
					 }
				      }
				 }
			      }
			    else
			      {
				 obj_t exp_2026;
				 {
				    bool_t aux_3625;
				    exp_2026 = (((csequence_t) CREF(cop_2002))->cops);
				  liip_2027:
				    if (NULLP(exp_2026))
				      {
					 aux_3625 = ((bool_t) 0);
				      }
				    else
				      {
					 obj_t e_2030;
					 e_2030 = CAR(exp_2026);
					 {
					    bool_t test2274_2031;
					    test2274_2031 = emit_cop_45_cgen_emit_cop_239((cop_t) (e_2030));
					    if (test2274_2031)
					      {
						 {
						    obj_t list2275_2032;
						    list2275_2032 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						    write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2275_2032);
						 }
						 emit_newline_191_cgen_emit_cop_239(BNIL);
					      }
					    else
					      {
						 BUNSPEC;
					      }
					 }
					 {
					    bool_t test2278_2035;
					    test2278_2035 = is_a__118___object(e_2030, cfail_cgen_cop);
					    if (test2278_2035)
					      {
						 obj_t exp_3637;
						 exp_3637 = BNIL;
						 exp_2026 = exp_3637;
						 goto liip_2027;
					      }
					    else
					      {
						 obj_t exp_3638;
						 exp_3638 = CDR(exp_2026);
						 exp_2026 = exp_3638;
						 goto liip_2027;
					      }
					 }
				      }
				    aux_3470 = BBOOL(aux_3625);
				 }
			      }
			 }
			 break;
		      case ((long) 10):
			 {
			    obj_t list2281_2039;
			    list2281_2039 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			    write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2281_2039);
			 }
			 emit_newline_191_cgen_emit_cop_239(BNIL);
			 aux_3470 = BFALSE;
			 break;
		      case ((long) 11):
			 {
			    stop_t cop_2042;
			    cop_2042 = (stop_t) (cop_15);
			    {
			       bool_t test2284_2044;
			       test2284_2044 = emit_cop_45_cgen_emit_cop_239((((stop_t) CREF(cop_2042))->value));
			       if (test2284_2044)
				 {
				    {
				       obj_t list2285_2045;
				       list2285_2045 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2285_2045);
				    }
				    emit_newline_191_cgen_emit_cop_239(BNIL);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    aux_3470 = BFALSE;
			 }
			 break;
		      case ((long) 12):
			 {
			    csetq_t cop_2049;
			    cop_2049 = (csetq_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((csetq_t) CREF(cop_2049))->loc));
			    {
			       cop_t aux_3655;
			       {
				  varc_t aux_3656;
				  aux_3656 = (((csetq_t) CREF(cop_2049))->var);
				  aux_3655 = (cop_t) (aux_3656);
			       }
			       emit_cop_45_cgen_emit_cop_239(aux_3655);
			    }
			    {
			       obj_t list2292_2053;
			       list2292_2053 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2630_cgen_emit_cop_239, list2292_2053);
			    }
			    emit_cop_45_cgen_emit_cop_239((((csetq_t) CREF(cop_2049))->value));
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 13):
			 {
			    cif_t cop_2056;
			    cop_2056 = (cif_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cif_t) CREF(cop_2056))->loc));
			    {
			       obj_t list2296_2059;
			       list2296_2059 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2631_cgen_emit_cop_239, list2296_2059);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cif_t) CREF(cop_2056))->test));
			    {
			       obj_t list2299_2062;
			       list2299_2062 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2299_2062);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cif_t) CREF(cop_2056))->true));
			    {
			       obj_t list2302_2065;
			       list2302_2065 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2632_cgen_emit_cop_239, list2302_2065);
			    }
			    {
			       bool_t aux_3677;
			       aux_3677 = emit_cop_45_cgen_emit_cop_239((((cif_t) CREF(cop_2056))->false));
			       aux_3470 = BBOOL(aux_3677);
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    local_var_164_t cop_2068;
			    cop_2068 = (local_var_164_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((local_var_164_t) CREF(cop_2068))->loc));
			    {
			       obj_t l1658_2071;
			       l1658_2071 = (((local_var_164_t) CREF(cop_2068))->vars);
			     lname1659_2072:
			       if (PAIRP(l1658_2071))
				 {
				    {
				       obj_t local_2075;
				       local_2075 = CAR(l1658_2071);
				       {
					  obj_t arg2308_2076;
					  obj_t arg2309_2077;
					  {
					     obj_t aux_3690;
					     type_t aux_3687;
					     {
						local_t obj_2865;
						obj_2865 = (local_t) (local_2075);
						aux_3690 = (((local_t) CREF(obj_2865))->name);
					     }
					     {
						local_t obj_2864;
						obj_2864 = (local_t) (local_2075);
						aux_3687 = (((local_t) CREF(obj_2864))->type);
					     }
					     arg2308_2076 = make_typed_declaration_180_type_tools(aux_3687, aux_3690);
					  }
					  {
					     bool_t test2321_2084;
					     {
						bool_t test2331_2094;
						{
						   long n1_2866;
						   n1_2866 = (long) CINT(_bdb_debug__1_engine_param);
						   test2331_2094 = (n1_2866 > ((long) 0));
						}
						if (test2331_2094)
						  {
						     obj_t aux_3701;
						     obj_t aux_3697;
						     aux_3701 = CNST_TABLE_REF(((long) 1));
						     {
							type_t arg2334_2097;
							{
							   local_t obj_2868;
							   obj_2868 = (local_t) (local_2075);
							   arg2334_2097 = (((local_t) CREF(obj_2868))->type);
							}
							aux_3697 = (((type_t) CREF(arg2334_2097))->class);
						     }
						     test2321_2084 = (aux_3697 == aux_3701);
						  }
						else
						  {
						     test2321_2084 = ((bool_t) 0);
						  }
					     }
					     if (test2321_2084)
					       {
						  obj_t arg2323_2086;
						  {
						     type_t aux_3705;
						     {
							local_t obj_2872;
							obj_2872 = (local_t) (local_2075);
							aux_3705 = (((local_t) CREF(obj_2872))->type);
						     }
						     arg2323_2086 = make_typed_declaration_180_type_tools(aux_3705, string2633_cgen_emit_cop_239);
						  }
						  {
						     obj_t list2325_2088;
						     {
							obj_t arg2326_2089;
							{
							   obj_t arg2327_2090;
							   arg2327_2090 = MAKE_PAIR(string2634_cgen_emit_cop_239, BNIL);
							   arg2326_2089 = MAKE_PAIR(arg2323_2086, arg2327_2090);
							}
							list2325_2088 = MAKE_PAIR(string2635_cgen_emit_cop_239, arg2326_2089);
						     }
						     arg2309_2077 = string_append_106___r4_strings_6_7(list2325_2088);
						  }
					       }
					     else
					       {
						  arg2309_2077 = string2633_cgen_emit_cop_239;
					       }
					  }
					  {
					     obj_t list2310_2078;
					     {
						obj_t arg2311_2079;
						{
						   obj_t arg2312_2080;
						   {
						      obj_t aux_3713;
						      aux_3713 = BCHAR(((unsigned char) ';'));
						      arg2312_2080 = MAKE_PAIR(aux_3713, BNIL);
						   }
						   arg2311_2079 = MAKE_PAIR(arg2309_2077, arg2312_2080);
						}
						list2310_2078 = MAKE_PAIR(arg2308_2076, arg2311_2079);
					     }
					     fprin_cgen_emit_cop_239(_c_port__188_cgen_emit, list2310_2078);
					  }
				       }
				       emit_newline_191_cgen_emit_cop_239(BNIL);
				    }
				    {
				       obj_t l1658_3720;
				       l1658_3720 = CDR(l1658_2071);
				       l1658_2071 = l1658_3720;
				       goto lname1659_2072;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_3470 = BFALSE;
			 }
			 break;
		      case ((long) 15):
			 {
			    bdb_block_21_t cop_2100;
			    cop_2100 = (bdb_block_21_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((bdb_block_21_t) CREF(cop_2100))->loc));
			    {
			       obj_t list2338_2103;
			       list2338_2103 = MAKE_PAIR(string2636_cgen_emit_cop_239, BNIL);
			       fprin_cgen_emit_cop_239(_c_port__188_cgen_emit, list2338_2103);
			    }
			    emit_bdb_loc_8_cgen_emit_cop_239((((bdb_block_21_t) CREF(cop_2100))->loc));
			    emit_cop_45_cgen_emit_cop_239((((bdb_block_21_t) CREF(cop_2100))->body));
			    {
			       obj_t list2343_2108;
			       list2343_2108 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) '}'), list2343_2108);
			    }
			    aux_3470 = emit_newline_191_cgen_emit_cop_239(BNIL);
			 }
			 break;
		      case ((long) 16):
			 {
			    cfuncall_t cop_2111;
			    cop_2111 = (cfuncall_t) (cop_15);
			    {
			       cfuncall_t cop_2112;
			       cfuncall_t cop_2114;
			       cfuncall_t cop_2118;
			       cfuncall_t cop_2120;
			       {
				  obj_t aux_3736;
				  {
				     cop_t obj_2877;
				     obj_2877 = (cop_t) (cop_2111);
				     aux_3736 = (((cop_t) CREF(obj_2877))->loc);
				  }
				  emit_bdb_loc_8_cgen_emit_cop_239(aux_3736);
			       }
			       {
				  obj_t case_value_58_2123;
				  case_value_58_2123 = (((cfuncall_t) CREF(cop_2111))->strength);
				  {
				     bool_t test_3741;
				     {
					obj_t aux_3742;
					aux_3742 = CNST_TABLE_REF(((long) 2));
					test_3741 = (case_value_58_2123 == aux_3742);
				     }
				     if (test_3741)
				       {
					  bool_t aux_3745;
					  cop_2112 = cop_2111;
					  {
					     obj_t actuals_2128;
					     actuals_2128 = (((cfuncall_t) CREF(cop_2112))->args);
					     emit_cop_45_cgen_emit_cop_239((((cfuncall_t) CREF(cop_2112))->fun));
					     {
						obj_t list2352_2130;
						list2352_2130 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						write_char_165___r4_output_6_10_3(((unsigned char) '('), list2352_2130);
					     }
					     {
						obj_t actuals_2132;
						actuals_2132 = actuals_2128;
					      loop_2133:
						{
						   bool_t test_3751;
						   {
						      obj_t aux_3752;
						      {
							 obj_t aux_3753;
							 aux_3753 = CDR(actuals_2132);
							 aux_3752 = CDR(aux_3753);
						      }
						      test_3751 = NULLP(aux_3752);
						   }
						   if (test_3751)
						     {
							{
							   cop_t aux_3757;
							   {
							      obj_t aux_3758;
							      aux_3758 = CAR(actuals_2132);
							      aux_3757 = (cop_t) (aux_3758);
							   }
							   emit_cop_45_cgen_emit_cop_239(aux_3757);
							}
							{
							   obj_t list2356_2136;
							   list2356_2136 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							   write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2356_2136);
							}
							aux_3745 = ((bool_t) 1);
						     }
						   else
						     {
							{
							   cop_t aux_3764;
							   {
							      obj_t aux_3765;
							      aux_3765 = CAR(actuals_2132);
							      aux_3764 = (cop_t) (aux_3765);
							   }
							   emit_cop_45_cgen_emit_cop_239(aux_3764);
							}
							{
							   obj_t list2359_2139;
							   list2359_2139 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							   display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2359_2139);
							}
							{
							   obj_t actuals_3771;
							   actuals_3771 = CDR(actuals_2132);
							   actuals_2132 = actuals_3771;
							   goto loop_2133;
							}
						     }
						}
					     }
					  }
					  aux_3470 = BBOOL(aux_3745);
				       }
				     else
				       {
					  bool_t test_3774;
					  {
					     obj_t aux_3775;
					     aux_3775 = CNST_TABLE_REF(((long) 3));
					     test_3774 = (case_value_58_2123 == aux_3775);
					  }
					  if (test_3774)
					    {
					       bool_t aux_3778;
					       cop_2114 = cop_2111;
					       {
						  obj_t actuals_2143;
						  actuals_2143 = (((cfuncall_t) CREF(cop_2114))->args);
						  {
						     obj_t list2364_2144;
						     list2364_2144 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						     display___r4_output_6_10_3(string2644_cgen_emit_cop_239, list2364_2144);
						  }
						  emit_cop_45_cgen_emit_cop_239((((cfuncall_t) CREF(cop_2114))->fun));
						  {
						     obj_t list2367_2147;
						     list2367_2147 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						     display___r4_output_6_10_3(string2642_cgen_emit_cop_239, list2367_2147);
						  }
						  {
						     obj_t actuals_2149;
						     actuals_2149 = actuals_2143;
						   loop_2150:
						     {
							bool_t test_3786;
							{
							   obj_t aux_3787;
							   {
							      obj_t aux_3788;
							      aux_3788 = CDR(actuals_2149);
							      aux_3787 = CDR(aux_3788);
							   }
							   test_3786 = NULLP(aux_3787);
							}
							if (test_3786)
							  {
							     {
								cop_t aux_3792;
								{
								   obj_t aux_3793;
								   aux_3793 = CAR(actuals_2149);
								   aux_3792 = (cop_t) (aux_3793);
								}
								emit_cop_45_cgen_emit_cop_239(aux_3792);
							     }
							     {
								obj_t list2371_2153;
								list2371_2153 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
								display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list2371_2153);
							     }
							     aux_3778 = ((bool_t) 1);
							  }
							else
							  {
							     {
								cop_t aux_3799;
								{
								   obj_t aux_3800;
								   aux_3800 = CAR(actuals_2149);
								   aux_3799 = (cop_t) (aux_3800);
								}
								emit_cop_45_cgen_emit_cop_239(aux_3799);
							     }
							     {
								obj_t list2374_2156;
								list2374_2156 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
								display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2374_2156);
							     }
							     {
								obj_t actuals_3806;
								actuals_3806 = CDR(actuals_2149);
								actuals_2149 = actuals_3806;
								goto loop_2150;
							     }
							  }
						     }
						  }
					       }
					       aux_3470 = BBOOL(aux_3778);
					    }
					  else
					    {
					       if (CBOOL(_stdc__25_engine_param))
						 {
						    bool_t aux_3811;
						    cop_2120 = cop_2111;
						    {
						       obj_t list2411_2194;
						       list2411_2194 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						       display___r4_output_6_10_3(string2637_cgen_emit_cop_239, list2411_2194);
						    }
						    emit_cop_45_cgen_emit_cop_239((((cfuncall_t) CREF(cop_2120))->fun));
						    {
						       obj_t list2414_2197;
						       list2414_2197 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						       display___r4_output_6_10_3(string2638_cgen_emit_cop_239, list2414_2197);
						    }
						    emit_regular_cfuncall_eoa_48_cgen_emit_cop_239(cop_2120);
						    {
						       obj_t list2416_2199;
						       list2416_2199 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						       display___r4_output_6_10_3(string2639_cgen_emit_cop_239, list2416_2199);
						    }
						    cop_2118 = cop_2120;
						    {
						       obj_t actuals_2177;
						       actuals_2177 = (((cfuncall_t) CREF(cop_2118))->args);
						       {
							  obj_t list2395_2178;
							  list2395_2178 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							  display___r4_output_6_10_3(string2641_cgen_emit_cop_239, list2395_2178);
						       }
						       emit_cop_45_cgen_emit_cop_239((((cfuncall_t) CREF(cop_2118))->fun));
						       {
							  obj_t list2400_2181;
							  list2400_2181 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							  display___r4_output_6_10_3(string2642_cgen_emit_cop_239, list2400_2181);
						       }
						       {
							  obj_t actuals_2183;
							  actuals_2183 = actuals_2177;
							loop_2184:
							  {
							     bool_t test_3828;
							     {
								obj_t aux_3829;
								{
								   obj_t aux_3830;
								   aux_3830 = CDR(actuals_2183);
								   aux_3829 = CDR(aux_3830);
								}
								test_3828 = NULLP(aux_3829);
							     }
							     if (test_3828)
							       {
								  {
								     cop_t aux_3834;
								     {
									obj_t aux_3835;
									aux_3835 = CAR(actuals_2183);
									aux_3834 = (cop_t) (aux_3835);
								     }
								     emit_cop_45_cgen_emit_cop_239(aux_3834);
								  }
								  {
								     obj_t list2404_2187;
								     list2404_2187 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
								     display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list2404_2187);
								  }
								  ((bool_t) 1);
							       }
							     else
							       {
								  {
								     cop_t aux_3841;
								     {
									obj_t aux_3842;
									aux_3842 = CAR(actuals_2183);
									aux_3841 = (cop_t) (aux_3842);
								     }
								     emit_cop_45_cgen_emit_cop_239(aux_3841);
								  }
								  {
								     obj_t list2407_2190;
								     list2407_2190 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
								     display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2407_2190);
								  }
								  {
								     obj_t actuals_3848;
								     actuals_3848 = CDR(actuals_2183);
								     actuals_2183 = actuals_3848;
								     goto loop_2184;
								  }
							       }
							  }
						       }
						    }
						    {
						       obj_t list2418_2201;
						       list2418_2201 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						       display___r4_output_6_10_3(string2640_cgen_emit_cop_239, list2418_2201);
						    }
						    aux_3811 = ((bool_t) 1);
						    aux_3470 = BBOOL(aux_3811);
						 }
					       else
						 {
						    bool_t aux_3853;
						    aux_3853 = emit_regular_cfuncall_eoa_48_cgen_emit_cop_239(cop_2111);
						    aux_3470 = BBOOL(aux_3853);
						 }
					    }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 17):
			 {
			    capply_t cop_2203;
			    cop_2203 = (capply_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((capply_t) CREF(cop_2203))->loc));
			    {
			       obj_t list2421_2206;
			       list2421_2206 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2645_cgen_emit_cop_239, list2421_2206);
			    }
			    emit_cop_45_cgen_emit_cop_239((((capply_t) CREF(cop_2203))->fun));
			    {
			       obj_t list2424_2209;
			       list2424_2209 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2424_2209);
			    }
			    emit_cop_45_cgen_emit_cop_239((((capply_t) CREF(cop_2203))->arg));
			    {
			       obj_t list2427_2212;
			       list2427_2212 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2427_2212);
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 18):
			 {
			    capp_t cop_2214;
			    cop_2214 = (capp_t) (cop_15);
			    {
			       {
				  variable_t fun_2217;
				  {
				     varc_t obj_2925;
				     {
					cop_t aux_3870;
					aux_3870 = (((capp_t) CREF(cop_2214))->fun);
					obj_2925 = (varc_t) (aux_3870);
				     }
				     fun_2217 = (((varc_t) CREF(obj_2925))->variable);
				  }
				  emit_bdb_loc_8_cgen_emit_cop_239((((capp_t) CREF(cop_2214))->loc));
				  {
				     bool_t test2429_2219;
				     {
					bool_t test2430_2220;
					{
					   obj_t aux_3876;
					   {
					      value_t aux_3877;
					      {
						 global_t obj_2927;
						 obj_2927 = (global_t) (fun_2217);
						 aux_3877 = (((global_t) CREF(obj_2927))->value);
					      }
					      aux_3876 = (obj_t) (aux_3877);
					   }
					   test2430_2220 = is_a__118___object(aux_3876, cfun_ast_var);
					}
					if (test2430_2220)
					  {
					     cfun_t obj_2930;
					     {
						value_t aux_3883;
						{
						   global_t obj_2929;
						   obj_2929 = (global_t) (fun_2217);
						   aux_3883 = (((global_t) CREF(obj_2929))->value);
						}
						obj_2930 = (cfun_t) (aux_3883);
					     }
					     test2429_2219 = (((cfun_t) CREF(obj_2930))->infix__163);
					  }
					else
					  {
					     test2429_2219 = ((bool_t) 0);
					  }
				     }
				     if (test2429_2219)
				       {
					  bool_t aux_3889;
					  {
					     obj_t actuals_2244;
					     actuals_2244 = (((capp_t) CREF(cop_2214))->args);
					     {
						obj_t list2451_2245;
						list2451_2245 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						write_char_165___r4_output_6_10_3(((unsigned char) '('), list2451_2245);
					     }
					     {
						cop_t aux_3893;
						{
						   obj_t aux_3894;
						   aux_3894 = CAR(actuals_2244);
						   aux_3893 = (cop_t) (aux_3894);
						}
						emit_cop_45_cgen_emit_cop_239(aux_3893);
					     }
					     emit_cop_45_cgen_emit_cop_239((((capp_t) CREF(cop_2214))->fun));
					     {
						cop_t aux_3900;
						{
						   obj_t aux_3901;
						   {
						      obj_t aux_3902;
						      aux_3902 = CDR(actuals_2244);
						      aux_3901 = CAR(aux_3902);
						   }
						   aux_3900 = (cop_t) (aux_3901);
						}
						emit_cop_45_cgen_emit_cop_239(aux_3900);
					     }
					     {
						obj_t list2456_2250;
						list2456_2250 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2456_2250);
					     }
					     aux_3889 = ((bool_t) 1);
					  }
					  aux_3470 = BBOOL(aux_3889);
				       }
				     else
				       {
					  bool_t aux_3910;
					  {
					     obj_t actuals_2225;
					     actuals_2225 = (((capp_t) CREF(cop_2214))->args);
					     emit_cop_45_cgen_emit_cop_239((((capp_t) CREF(cop_2214))->fun));
					     {
						obj_t list2436_2227;
						list2436_2227 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						write_char_165___r4_output_6_10_3(((unsigned char) '('), list2436_2227);
					     }
					     if (NULLP(actuals_2225))
					       {
						  {
						     obj_t list2439_2230;
						     list2439_2230 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						     write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2439_2230);
						  }
						  aux_3910 = ((bool_t) 1);
					       }
					     else
					       {
						  obj_t actuals_2232;
						  actuals_2232 = actuals_2225;
						loop_2233:
						  {
						     bool_t test_3920;
						     {
							obj_t aux_3921;
							aux_3921 = CDR(actuals_2232);
							test_3920 = NULLP(aux_3921);
						     }
						     if (test_3920)
						       {
							  {
							     cop_t aux_3924;
							     {
								obj_t aux_3925;
								aux_3925 = CAR(actuals_2232);
								aux_3924 = (cop_t) (aux_3925);
							     }
							     emit_cop_45_cgen_emit_cop_239(aux_3924);
							  }
							  {
							     obj_t list2443_2236;
							     list2443_2236 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							     write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2443_2236);
							  }
							  aux_3910 = ((bool_t) 1);
						       }
						     else
						       {
							  {
							     cop_t aux_3931;
							     {
								obj_t aux_3932;
								aux_3932 = CAR(actuals_2232);
								aux_3931 = (cop_t) (aux_3932);
							     }
							     emit_cop_45_cgen_emit_cop_239(aux_3931);
							  }
							  {
							     obj_t list2446_2239;
							     list2446_2239 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							     display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2446_2239);
							  }
							  {
							     obj_t actuals_3938;
							     actuals_3938 = CDR(actuals_2232);
							     actuals_2232 = actuals_3938;
							     goto loop_2233;
							  }
						       }
						  }
					       }
					  }
					  aux_3470 = BBOOL(aux_3910);
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 19):
			 {
			    cfail_t cop_2254;
			    cop_2254 = (cfail_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->loc));
			    if (CBOOL(_bfalse__69_cgen_emit_cop_239))
			      {
				 BUNSPEC;
			      }
			    else
			      {
				 obj_t arg2459_2257;
				 arg2459_2257 = CNST_TABLE_REF(((long) 4));
				 {
				    obj_t list2461_2259;
				    {
				       obj_t aux_3947;
				       aux_3947 = CNST_TABLE_REF(((long) 5));
				       list2461_2259 = MAKE_PAIR(aux_3947, BNIL);
				    }
				    _bfalse__69_cgen_emit_cop_239 = find_global_223_ast_env(arg2459_2257, list2461_2259);
				 }
			      }
			    {
			       bool_t test2464_2261;
			       {
				  bool_t test2491_2287;
				  {
				     obj_t aux_3951;
				     {
					cop_t aux_3952;
					aux_3952 = (((cfail_t) CREF(cop_2254))->proc);
					aux_3951 = (obj_t) (aux_3952);
				     }
				     test2491_2287 = is_a__118___object(aux_3951, varc_cgen_cop);
				  }
				  if (test2491_2287)
				    {
				       bool_t test2492_2288;
				       {
					  obj_t obj2_2952;
					  obj2_2952 = _bfalse__69_cgen_emit_cop_239;
					  {
					     obj_t aux_3957;
					     {
						variable_t aux_3958;
						{
						   varc_t obj_2950;
						   {
						      cop_t aux_3959;
						      aux_3959 = (((cfail_t) CREF(cop_2254))->proc);
						      obj_2950 = (varc_t) (aux_3959);
						   }
						   aux_3958 = (((varc_t) CREF(obj_2950))->variable);
						}
						aux_3957 = (obj_t) (aux_3958);
					     }
					     test2492_2288 = (aux_3957 == obj2_2952);
					  }
				       }
				       if (test2492_2288)
					 {
					    bool_t test2493_2289;
					    {
					       obj_t aux_3966;
					       {
						  cop_t aux_3967;
						  aux_3967 = (((cfail_t) CREF(cop_2254))->msg);
						  aux_3966 = (obj_t) (aux_3967);
					       }
					       test2493_2289 = is_a__118___object(aux_3966, varc_cgen_cop);
					    }
					    if (test2493_2289)
					      {
						 bool_t test2494_2290;
						 {
						    obj_t obj2_2958;
						    obj2_2958 = _bfalse__69_cgen_emit_cop_239;
						    {
						       obj_t aux_3972;
						       {
							  variable_t aux_3973;
							  {
							     varc_t obj_2956;
							     {
								cop_t aux_3974;
								aux_3974 = (((cfail_t) CREF(cop_2254))->msg);
								obj_2956 = (varc_t) (aux_3974);
							     }
							     aux_3973 = (((varc_t) CREF(obj_2956))->variable);
							  }
							  aux_3972 = (obj_t) (aux_3973);
						       }
						       test2494_2290 = (aux_3972 == obj2_2958);
						    }
						 }
						 if (test2494_2290)
						   {
						      bool_t test2495_2291;
						      {
							 obj_t aux_3981;
							 {
							    cop_t aux_3982;
							    aux_3982 = (((cfail_t) CREF(cop_2254))->obj);
							    aux_3981 = (obj_t) (aux_3982);
							 }
							 test2495_2291 = is_a__118___object(aux_3981, varc_cgen_cop);
						      }
						      if (test2495_2291)
							{
							   obj_t obj2_2964;
							   obj2_2964 = _bfalse__69_cgen_emit_cop_239;
							   {
							      obj_t aux_3987;
							      {
								 variable_t aux_3988;
								 {
								    varc_t obj_2962;
								    {
								       cop_t aux_3989;
								       aux_3989 = (((cfail_t) CREF(cop_2254))->obj);
								       obj_2962 = (varc_t) (aux_3989);
								    }
								    aux_3988 = (((varc_t) CREF(obj_2962))->variable);
								 }
								 aux_3987 = (obj_t) (aux_3988);
							      }
							      test2464_2261 = (aux_3987 == obj2_2964);
							   }
							}
						      else
							{
							   test2464_2261 = ((bool_t) 0);
							}
						   }
						 else
						   {
						      test2464_2261 = ((bool_t) 0);
						   }
					      }
					    else
					      {
						 test2464_2261 = ((bool_t) 0);
					      }
					 }
				       else
					 {
					    test2464_2261 = ((bool_t) 0);
					 }
				    }
				  else
				    {
				       test2464_2261 = ((bool_t) 0);
				    }
			       }
			       if (test2464_2261)
				 {
				    {
				       obj_t list2465_2262;
				       list2465_2262 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
				       display___r4_output_6_10_3(string2646_cgen_emit_cop_239, list2465_2262);
				    }
				 }
			       else
				 {
				    bool_t test2467_2264;
				    {
				       long n1_2965;
				       n1_2965 = (long) CINT(_bdb_debug__1_engine_param);
				       test2467_2264 = (n1_2965 <= ((long) 0));
				    }
				    if (test2467_2264)
				      {
					 {
					    obj_t list2468_2265;
					    list2468_2265 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    display___r4_output_6_10_3(string2647_cgen_emit_cop_239, list2468_2265);
					 }
					 emit_cop_45_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->proc));
					 {
					    obj_t list2471_2268;
					    list2471_2268 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    write_char_165___r4_output_6_10_3(((unsigned char) ','), list2471_2268);
					 }
					 emit_cop_45_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->msg));
					 {
					    obj_t list2474_2271;
					    list2474_2271 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    write_char_165___r4_output_6_10_3(((unsigned char) ','), list2474_2271);
					 }
					 emit_cop_45_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->obj));
					 {
					    obj_t list2477_2274;
					    list2477_2274 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    display___r4_output_6_10_3(string2648_cgen_emit_cop_239, list2477_2274);
					 }
				      }
				    else
				      {
					 {
					    obj_t list2479_2276;
					    list2479_2276 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    display___r4_output_6_10_3(string2649_cgen_emit_cop_239, list2479_2276);
					 }
					 emit_cop_45_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->proc));
					 {
					    obj_t list2482_2279;
					    list2482_2279 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    write_char_165___r4_output_6_10_3(((unsigned char) ','), list2482_2279);
					 }
					 emit_cop_45_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->msg));
					 {
					    obj_t list2486_2282;
					    list2486_2282 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    write_char_165___r4_output_6_10_3(((unsigned char) ','), list2486_2282);
					 }
					 emit_cop_45_cgen_emit_cop_239((((cfail_t) CREF(cop_2254))->obj));
					 {
					    obj_t list2489_2285;
					    list2489_2285 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
					    display___r4_output_6_10_3(string2650_cgen_emit_cop_239, list2489_2285);
					 }
				      }
				 }
			    }
			    aux_3470 = BFALSE;
			 }
			 break;
		      case ((long) 20):
			 {
			    cswitch_t cop_2301;
			    cop_2301 = (cswitch_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cswitch_t) CREF(cop_2301))->loc));
			    {
			       obj_t list2507_2304;
			       list2507_2304 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2651_cgen_emit_cop_239, list2507_2304);
			    }
			    {
			       obj_t list2509_2306;
			       list2509_2306 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) '('), list2509_2306);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cswitch_t) CREF(cop_2301))->test));
			    {
			       obj_t list2513_2309;
			       list2513_2309 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2513_2309);
			    }
			    {
			       obj_t list2515_2311;
			       list2515_2311 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) '{'), list2515_2311);
			    }
			    emit_newline_191_cgen_emit_cop_239(BNIL);
			    {
			       obj_t clauses_2314;
			       {
				  bool_t aux_4043;
				  clauses_2314 = (((cswitch_t) CREF(cop_2301))->clauses);
				loop_2315:
				  {
				     obj_t clause_2317;
				     clause_2317 = CAR(clauses_2314);
				     {
					bool_t test_4045;
					{
					   obj_t aux_4048;
					   obj_t aux_4046;
					   aux_4048 = CNST_TABLE_REF(((long) 6));
					   aux_4046 = CAR(clause_2317);
					   test_4045 = (aux_4046 == aux_4048);
					}
					if (test_4045)
					  {
					     {
						obj_t list2520_2319;
						list2520_2319 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						display___r4_output_6_10_3(string2652_cgen_emit_cop_239, list2520_2319);
					     }
					     emit_newline_191_cgen_emit_cop_239(BNIL);
					     {
						bool_t test2524_2322;
						{
						   cop_t aux_4054;
						   {
						      obj_t aux_4055;
						      aux_4055 = CDR(clause_2317);
						      aux_4054 = (cop_t) (aux_4055);
						   }
						   test2524_2322 = emit_cop_45_cgen_emit_cop_239(aux_4054);
						}
						if (test2524_2322)
						  {
						     {
							obj_t list2525_2323;
							list2525_2323 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2525_2323);
						     }
						     emit_newline_191_cgen_emit_cop_239(BNIL);
						  }
						else
						  {
						     BUNSPEC;
						  }
					     }
					     {
						obj_t list2529_2327;
						list2529_2327 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						write_char_165___r4_output_6_10_3(((unsigned char) '}'), list2529_2327);
					     }
					     emit_newline_191_cgen_emit_cop_239(BNIL);
					     aux_4043 = ((bool_t) 0);
					  }
					else
					  {
					     {
						obj_t l1664_2330;
						l1664_2330 = CAR(clause_2317);
					      lname1665_2331:
						if (PAIRP(l1664_2330))
						  {
						     {
							obj_t t_2334;
							t_2334 = CAR(l1664_2330);
							{
							   obj_t list2534_2335;
							   list2534_2335 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							   display___r4_output_6_10_3(string2653_cgen_emit_cop_239, list2534_2335);
							}
							emit_atom_value_68_cgen_emit_cop_239(t_2334);
							{
							   obj_t list2536_2337;
							   list2536_2337 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							   display___r4_output_6_10_3(string2639_cgen_emit_cop_239, list2536_2337);
							}
							emit_newline_191_cgen_emit_cop_239(BNIL);
						     }
						     {
							obj_t l1664_4075;
							l1664_4075 = CDR(l1664_2330);
							l1664_2330 = l1664_4075;
							goto lname1665_2331;
						     }
						  }
						else
						  {
						     ((bool_t) 1);
						  }
					     }
					     {
						bool_t test2540_2341;
						{
						   cop_t aux_4078;
						   {
						      obj_t aux_4079;
						      aux_4079 = CDR(clause_2317);
						      aux_4078 = (cop_t) (aux_4079);
						   }
						   test2540_2341 = emit_cop_45_cgen_emit_cop_239(aux_4078);
						}
						if (test2540_2341)
						  {
						     {
							obj_t list2541_2342;
							list2541_2342 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
							write_char_165___r4_output_6_10_3(((unsigned char) ';'), list2541_2342);
						     }
						     emit_newline_191_cgen_emit_cop_239(BNIL);
						  }
						else
						  {
						     BUNSPEC;
						  }
					     }
					     {
						obj_t list2545_2346;
						list2545_2346 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
						display___r4_output_6_10_3(string2654_cgen_emit_cop_239, list2545_2346);
					     }
					     emit_newline_191_cgen_emit_cop_239(BNIL);
					     {
						obj_t clauses_4090;
						clauses_4090 = CDR(clauses_2314);
						clauses_2314 = clauses_4090;
						goto loop_2315;
					     }
					  }
				     }
				  }
				  aux_3470 = BBOOL(aux_4043);
			       }
			    }
			 }
			 break;
		      case ((long) 21):
			 {
			    cmake_box_177_t cop_2352;
			    cop_2352 = (cmake_box_177_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cmake_box_177_t) CREF(cop_2352))->loc));
			    {
			       obj_t list2553_2355;
			       list2553_2355 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2655_cgen_emit_cop_239, list2553_2355);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cmake_box_177_t) CREF(cop_2352))->value));
			    {
			       obj_t list2557_2358;
			       list2557_2358 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2557_2358);
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 22):
			 {
			    cbox_ref_44_t cop_2360;
			    cop_2360 = (cbox_ref_44_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cbox_ref_44_t) CREF(cop_2360))->loc));
			    {
			       obj_t list2560_2363;
			       list2560_2363 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2656_cgen_emit_cop_239, list2560_2363);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cbox_ref_44_t) CREF(cop_2360))->var));
			    {
			       obj_t list2563_2366;
			       list2563_2366 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2563_2366);
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 23):
			 {
			    cbox_set__132_t cop_2368;
			    cop_2368 = (cbox_set__132_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cbox_set__132_t) CREF(cop_2368))->loc));
			    {
			       obj_t list2568_2371;
			       list2568_2371 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2657_cgen_emit_cop_239, list2568_2371);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cbox_set__132_t) CREF(cop_2368))->var));
			    {
			       obj_t list2571_2374;
			       list2571_2374 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2571_2374);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cbox_set__132_t) CREF(cop_2368))->value));
			    {
			       obj_t list2575_2377;
			       list2575_2377 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2575_2377);
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      case ((long) 24):
			 {
			    cset_ex_it_123_t cop_2379;
			    cop_2379 = (cset_ex_it_123_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cset_ex_it_123_t) CREF(cop_2379))->loc));
			    {
			       obj_t list2578_2382;
			       list2578_2382 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2658_cgen_emit_cop_239, list2578_2382);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cset_ex_it_123_t) CREF(cop_2379))->exit));
			    {
			       obj_t list2581_2385;
			       list2581_2385 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2659_cgen_emit_cop_239, list2581_2385);
			    }
			    {
			       obj_t list2583_2387;
			       list2583_2387 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2660_cgen_emit_cop_239, list2583_2387);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cset_ex_it_123_t) CREF(cop_2379))->jump_value_221));
			    emit_bdb_loc_8_cgen_emit_cop_239((((cset_ex_it_123_t) CREF(cop_2379))->loc));
			    {
			       obj_t list2587_2391;
			       list2587_2391 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2661_cgen_emit_cop_239, list2587_2391);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cset_ex_it_123_t) CREF(cop_2379))->body));
			    emit_bdb_loc_8_cgen_emit_cop_239((((cset_ex_it_123_t) CREF(cop_2379))->loc));
			    {
			       obj_t list2592_2395;
			       list2592_2395 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) '}'), list2592_2395);
			    }
			    emit_newline_191_cgen_emit_cop_239(BNIL);
			    aux_3470 = BFALSE;
			 }
			 break;
		      case ((long) 25):
			 {
			    cjump_ex_it_131_t cop_2398;
			    cop_2398 = (cjump_ex_it_131_t) (cop_15);
			    emit_bdb_loc_8_cgen_emit_cop_239((((cjump_ex_it_131_t) CREF(cop_2398))->loc));
			    {
			       obj_t list2596_2401;
			       list2596_2401 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       display___r4_output_6_10_3(string2662_cgen_emit_cop_239, list2596_2401);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cjump_ex_it_131_t) CREF(cop_2398))->exit));
			    {
			       obj_t list2599_2404;
			       list2599_2404 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ','), list2599_2404);
			    }
			    emit_cop_45_cgen_emit_cop_239((((cjump_ex_it_131_t) CREF(cop_2398))->value));
			    {
			       obj_t list2602_2407;
			       list2602_2407 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			       write_char_165___r4_output_6_10_3(((unsigned char) ')'), list2602_2407);
			    }
			    aux_3470 = BTRUE;
			 }
			 break;
		      default:
		       case_else2100_1780:
			 if (PROCEDUREP(method2094_1776))
			   {
			      aux_3470 = PROCEDURE_ENTRY(method2094_1776) (method2094_1776, (obj_t) (cop_15), BEOA);
			   }
			 else
			   {
			      obj_t fun2091_1770;
			      fun2091_1770 = PROCEDURE_REF(emit_cop_env_125_cgen_emit_cop_239, ((long) 0));
			      aux_3470 = PROCEDURE_ENTRY(fun2091_1770) (fun2091_1770, (obj_t) (cop_15), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else2100_1780;
		 }
	    }
	    return CBOOL(aux_3470);
	 }
      }
   }
}


/* emit-regular-cfuncall/eoa */ bool_t 
emit_regular_cfuncall_eoa_48_cgen_emit_cop_239(cfuncall_t cop_2116)
{
   {
      obj_t actuals_2160;
      actuals_2160 = (((cfuncall_t) CREF(cop_2116))->args);
      {
	 obj_t list2378_2161;
	 list2378_2161 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	 display___r4_output_6_10_3(string2641_cgen_emit_cop_239, list2378_2161);
      }
      emit_cop_45_cgen_emit_cop_239((((cfuncall_t) CREF(cop_2116))->fun));
      {
	 obj_t list2381_2164;
	 list2381_2164 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	 display___r4_output_6_10_3(string2642_cgen_emit_cop_239, list2381_2164);
      }
      {
	 obj_t actuals_2166;
	 actuals_2166 = actuals_2160;
       loop_2167:
	 {
	    bool_t test_4181;
	    {
	       obj_t aux_4182;
	       aux_4182 = CDR(actuals_2166);
	       test_4181 = NULLP(aux_4182);
	    }
	    if (test_4181)
	      {
		 {
		    cop_t aux_4185;
		    {
		       obj_t aux_4186;
		       aux_4186 = CAR(actuals_2166);
		       aux_4185 = (cop_t) (aux_4186);
		    }
		    emit_cop_45_cgen_emit_cop_239(aux_4185);
		 }
		 {
		    obj_t list2386_2170;
		    list2386_2170 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		    display___r4_output_6_10_3(string2621_cgen_emit_cop_239, list2386_2170);
		 }
		 return ((bool_t) 1);
	      }
	    else
	      {
		 {
		    cop_t aux_4192;
		    {
		       obj_t aux_4193;
		       aux_4193 = CAR(actuals_2166);
		       aux_4192 = (cop_t) (aux_4193);
		    }
		    emit_cop_45_cgen_emit_cop_239(aux_4192);
		 }
		 {
		    obj_t list2389_2173;
		    list2389_2173 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		    display___r4_output_6_10_3(string2643_cgen_emit_cop_239, list2389_2173);
		 }
		 {
		    obj_t actuals_4199;
		    actuals_4199 = CDR(actuals_2166);
		    actuals_2166 = actuals_4199;
		    goto loop_2167;
		 }
	      }
	 }
      }
   }
}


/* _emit-cop2618 */ obj_t 
_emit_cop2618_201_cgen_emit_cop_239(obj_t env_3017, obj_t cop_3018)
{
   {
      bool_t aux_4201;
      aux_4201 = emit_cop_45_cgen_emit_cop_239((cop_t) (cop_3018));
      return BBOOL(aux_4201);
   }
}


/* lambda2167 */ obj_t 
lambda2167_cgen_emit_cop_239(obj_t env_3022, obj_t input_port_219_3024)
{
   {
      obj_t args_3023;
      args_3023 = PROCEDURE_1_EL_REF(env_3022, ((long) 0));
      {
	 obj_t input_port_219_1855;
	 input_port_219_1855 = input_port_219_3024;
	 {
	    long last_match_133_1925;
	    long last_match_133_1933;
	    long last_match_133_1940;
	    long last_match_133_1948;
	    long last_match_133_1956;
	  ignore_1984:
	    RGC_START_MATCH(input_port_219_1855);
	    {
	       int match_1877;
	       {
		  long aux_4207;
		  last_match_133_1933 = ((long) 2);
		state_0_1644_247_1970:
		  {
		     int current_char_37_1935;
		     current_char_37_1935 = RGC_BUFFER_GET_CHAR(input_port_219_1855);
		     {
			bool_t test_4209;
			{
			   long aux_4210;
			   aux_4210 = (long) (current_char_37_1935);
			   test_4209 = (aux_4210 == ((long) 0));
			}
			if (test_4209)
			  {
			     {
				bool_t test2214_1937;
				test2214_1937 = RGC_BUFFER_EMPTY(input_port_219_1855);
				if (test2214_1937)
				  {
				     bool_t test2215_1938;
				     test2215_1938 = rgc_fill_buffer(input_port_219_1855);
				     if (test2215_1938)
				       {
					  goto state_0_1644_247_1970;
				       }
				     else
				       {
					  aux_4207 = last_match_133_1933;
				       }
				  }
				else
				  {
				     last_match_133_1940 = last_match_133_1933;
				   state_1_1645_252_1969:
				     {
					long new_match_93_1942;
					RGC_STOP_MATCH(input_port_219_1855);
					new_match_93_1942 = ((long) 1);
					{
					   int current_char_37_1943;
					   current_char_37_1943 = RGC_BUFFER_GET_CHAR(input_port_219_1855);
					   {
					      bool_t test_4219;
					      {
						 long aux_4220;
						 aux_4220 = (long) (current_char_37_1943);
						 test_4219 = (aux_4220 == ((long) 0));
					      }
					      if (test_4219)
						{
						   {
						      bool_t test2219_1945;
						      test2219_1945 = RGC_BUFFER_EMPTY(input_port_219_1855);
						      if (test2219_1945)
							{
							   bool_t test2220_1946;
							   test2220_1946 = rgc_fill_buffer(input_port_219_1855);
							   if (test2220_1946)
							     {
								goto state_1_1645_252_1969;
							     }
							   else
							     {
								aux_4207 = new_match_93_1942;
							     }
							}
						      else
							{
							   last_match_133_1948 = new_match_93_1942;
							 state_5_1649_71_1968:
							   {
							      long new_match_93_1950;
							      RGC_STOP_MATCH(input_port_219_1855);
							      new_match_93_1950 = ((long) 1);
							      {
								 int current_char_37_1951;
								 current_char_37_1951 = RGC_BUFFER_GET_CHAR(input_port_219_1855);
								 {
								    bool_t test_4229;
								    {
								       long aux_4230;
								       aux_4230 = (long) (current_char_37_1951);
								       test_4229 = (aux_4230 == ((long) 0));
								    }
								    if (test_4229)
								      {
									 {
									    bool_t test2224_1953;
									    test2224_1953 = RGC_BUFFER_EMPTY(input_port_219_1855);
									    if (test2224_1953)
									      {
										 bool_t test2225_1954;
										 test2225_1954 = rgc_fill_buffer(input_port_219_1855);
										 if (test2225_1954)
										   {
										      goto state_5_1649_71_1968;
										   }
										 else
										   {
										      aux_4207 = new_match_93_1950;
										   }
									      }
									    else
									      {
										 long last_match_133_4237;
										 last_match_133_4237 = new_match_93_1950;
										 last_match_133_1948 = last_match_133_4237;
										 goto state_5_1649_71_1968;
									      }
									 }
								      }
								    else
								      {
									 bool_t test_4238;
									 {
									    long aux_4239;
									    aux_4239 = (long) (current_char_37_1951);
									    test_4238 = (aux_4239 == ((long) 36));
									 }
									 if (test_4238)
									   {
									      aux_4207 = new_match_93_1950;
									   }
									 else
									   {
									      {
										 long last_match_133_4242;
										 last_match_133_4242 = new_match_93_1950;
										 last_match_133_1948 = last_match_133_4242;
										 goto state_5_1649_71_1968;
									      }
									   }
								      }
								 }
							      }
							   }
							}
						   }
						}
					      else
						{
						   bool_t test_4243;
						   {
						      long aux_4244;
						      aux_4244 = (long) (current_char_37_1943);
						      test_4243 = (aux_4244 == ((long) 36));
						   }
						   if (test_4243)
						     {
							aux_4207 = new_match_93_1942;
						     }
						   else
						     {
							{
							   long last_match_133_4247;
							   last_match_133_4247 = new_match_93_1942;
							   last_match_133_1948 = last_match_133_4247;
							   goto state_5_1649_71_1968;
							}
						     }
						}
					   }
					}
				     }
				  }
			     }
			  }
			else
			  {
			     bool_t test_4248;
			     {
				long aux_4249;
				aux_4249 = (long) (current_char_37_1935);
				test_4248 = (aux_4249 == ((long) 36));
			     }
			     if (test_4248)
			       {
				  last_match_133_1956 = last_match_133_1933;
				state_2_1646_70_1967:
				  {
				     long new_match_93_1958;
				     RGC_STOP_MATCH(input_port_219_1855);
				     new_match_93_1958 = ((long) 2);
				     {
					int current_char_37_1959;
					current_char_37_1959 = RGC_BUFFER_GET_CHAR(input_port_219_1855);
					{
					   bool_t test_4254;
					   {
					      long aux_4255;
					      aux_4255 = (long) (current_char_37_1959);
					      test_4254 = (aux_4255 == ((long) 0));
					   }
					   if (test_4254)
					     {
						{
						   bool_t test2229_1961;
						   {
						      bool_t res2615_2825;
						      {
							 bool_t _andtest_1006_2822;
							 _andtest_1006_2822 = RGC_BUFFER_EMPTY(input_port_219_1855);
							 if (_andtest_1006_2822)
							   {
							      res2615_2825 = rgc_fill_buffer(input_port_219_1855);
							   }
							 else
							   {
							      res2615_2825 = ((bool_t) 0);
							   }
						      }
						      test2229_1961 = res2615_2825;
						   }
						   if (test2229_1961)
						     {
							goto state_2_1646_70_1967;
						     }
						   else
						     {
							aux_4207 = new_match_93_1958;
						     }
						}
					     }
					   else
					     {
						bool_t test_4262;
						{
						   bool_t test_4263;
						   {
						      long aux_4264;
						      aux_4264 = (long) (current_char_37_1959);
						      test_4263 = (aux_4264 >= ((long) 48));
						   }
						   if (test_4263)
						     {
							long aux_4267;
							aux_4267 = (long) (current_char_37_1959);
							test_4262 = (aux_4267 < ((long) 58));
						     }
						   else
						     {
							test_4262 = ((bool_t) 0);
						     }
						}
						if (test_4262)
						  {
						     last_match_133_1925 = new_match_93_1958;
						   state_3_1647_163_1971:
						     {
							long new_match_93_1927;
							RGC_STOP_MATCH(input_port_219_1855);
							new_match_93_1927 = ((long) 0);
							{
							   int current_char_37_1928;
							   current_char_37_1928 = RGC_BUFFER_GET_CHAR(input_port_219_1855);
							   {
							      bool_t test_4272;
							      {
								 long aux_4273;
								 aux_4273 = (long) (current_char_37_1928);
								 test_4272 = (aux_4273 == ((long) 0));
							      }
							      if (test_4272)
								{
								   {
								      bool_t test2209_1930;
								      {
									 bool_t res2614_2789;
									 {
									    bool_t _andtest_1006_2786;
									    _andtest_1006_2786 = RGC_BUFFER_EMPTY(input_port_219_1855);
									    if (_andtest_1006_2786)
									      {
										 res2614_2789 = rgc_fill_buffer(input_port_219_1855);
									      }
									    else
									      {
										 res2614_2789 = ((bool_t) 0);
									      }
									 }
									 test2209_1930 = res2614_2789;
								      }
								      if (test2209_1930)
									{
									   goto state_3_1647_163_1971;
									}
								      else
									{
									   aux_4207 = new_match_93_1927;
									}
								   }
								}
							      else
								{
								   bool_t test_4280;
								   {
								      bool_t test_4281;
								      {
									 long aux_4282;
									 aux_4282 = (long) (current_char_37_1928);
									 test_4281 = (aux_4282 >= ((long) 48));
								      }
								      if (test_4281)
									{
									   long aux_4285;
									   aux_4285 = (long) (current_char_37_1928);
									   test_4280 = (aux_4285 < ((long) 58));
									}
								      else
									{
									   test_4280 = ((bool_t) 0);
									}
								   }
								   if (test_4280)
								     {
									{
									   long last_match_133_4288;
									   last_match_133_4288 = new_match_93_1927;
									   last_match_133_1925 = last_match_133_4288;
									   goto state_3_1647_163_1971;
									}
								     }
								   else
								     {
									aux_4207 = new_match_93_1927;
								     }
								}
							   }
							}
						     }
						  }
						else
						  {
						     aux_4207 = new_match_93_1958;
						  }
					     }
					}
				     }
				  }
			       }
			     else
			       {
				  {
				     long last_match_133_4289;
				     last_match_133_4289 = last_match_133_1933;
				     last_match_133_1940 = last_match_133_4289;
				     goto state_1_1645_252_1969;
				  }
			       }
			  }
		     }
		  }
		  match_1877 = (int) (aux_4207);
	       }
	       {
		  switch ((long) (match_1877))
		    {
		    case ((long) 2):
		       {
			  bool_t test2185_1901;
			  {
			     int arg2188_1904;
			     {
				int res2612_2770;
				{
				   long aux_4291;
				   aux_4291 = RGC_BUFFER_LENGTH(input_port_219_1855);
				   res2612_2770 = (int) (aux_4291);
				}
				arg2188_1904 = res2612_2770;
			     }
			     {
				long aux_4294;
				aux_4294 = (long) (arg2188_1904);
				test2185_1901 = (aux_4294 == ((long) 0));
			     }
			  }
			  if (test2185_1901)
			    {
			       return BCNST(256);
			    }
			  else
			    {
			       obj_t arg2186_1902;
			       arg2186_1902 = the_string_180_cgen_emit_cop_239(input_port_219_1855);
			       {
				  unsigned char aux_4299;
				  aux_4299 = STRING_REF(arg2186_1902, ((long) 0));
				  return BCHAR(aux_4299);
			       }
			    }
		       }
		       break;
		    case ((long) 1):
		       {
			  obj_t arg2172_1884;
			  arg2172_1884 = the_string_180_cgen_emit_cop_239(input_port_219_1855);
			  {
			     obj_t list2173_1885;
			     list2173_1885 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			     display___r4_output_6_10_3(arg2172_1884, list2173_1885);
			  }
		       }
		       goto ignore_1984;
		       break;
		    case ((long) 0):
		       {
			  obj_t str_1887;
			  str_1887 = the_string_180_cgen_emit_cop_239(input_port_219_1855);
			  {
			     int len_1888;
			     {
				int res2611_2758;
				{
				   long aux_4306;
				   aux_4306 = RGC_BUFFER_LENGTH(input_port_219_1855);
				   res2611_2758 = (int) (aux_4306);
				}
				len_1888 = res2611_2758;
			     }
			     {
				obj_t index_1889;
				{
				   obj_t arg2178_1892;
				   {
				      long aux_4309;
				      aux_4309 = (long) (len_1888);
				      arg2178_1892 = c_substring(str_1887, ((long) 1), aux_4309);
				   }
				   index_1889 = string__number_104___r4_numbers_6_5(arg2178_1892, BNIL);
				}
				{
				   {
				      cop_t aux_4313;
				      {
					 obj_t aux_4314;
					 {
					    long aux_4315;
					    {
					       long aux_4316;
					       aux_4316 = (long) CINT(index_1889);
					       aux_4315 = (aux_4316 - ((long) 1));
					    }
					    aux_4314 = VECTOR_REF(args_3023, aux_4315);
					 }
					 aux_4313 = (cop_t) (aux_4314);
				      }
				      emit_cop_45_cgen_emit_cop_239(aux_4313);
				   }
				   goto ignore_1984;
				}
			     }
			  }
		       }
		       break;
		    default:
		       FAILURE(string2663_cgen_emit_cop_239, string2664_cgen_emit_cop_239, BINT(match_1877));
		    }
	       }
	    }
	 }
      }
   }
}


/* the-string */ obj_t 
the_string_180_cgen_emit_cop_239(obj_t input_port_219_3025)
{
   {
      int arg2205_1923;
      {
	 int res2613_2777;
	 {
	    long aux_4326;
	    aux_4326 = RGC_BUFFER_LENGTH(input_port_219_3025);
	    res2613_2777 = (int) (aux_4326);
	 }
	 arg2205_1923 = res2613_2777;
      }
      {
	 int aux_4329;
	 aux_4329 = (int) (((long) 0));
	 return rgc_buffer_substring(input_port_219_3025, aux_4329, arg2205_1923);
      }
   }
}


/* emit-cop-default1677 */ bool_t 
emit_cop_default1677_86_cgen_emit_cop_239(cop_t cop_16)
{
   FAILURE(CNST_TABLE_REF(((long) 7)), string2665_cgen_emit_cop_239, (obj_t) (cop_16));
}


/* _emit-cop-default1677 */ obj_t 
_emit_cop_default1677_176_cgen_emit_cop_239(obj_t env_3019, obj_t cop_3020)
{
   {
      bool_t aux_4335;
      aux_4335 = emit_cop_default1677_86_cgen_emit_cop_239((cop_t) (cop_3020));
      return BBOOL(aux_4335);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_emit_cop_239()
{
   module_initialization_70_type_type(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_type_tools(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_type_cache(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_engine_param(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_ast_var(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_ast_node(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_ast_env(((long) 0), "CGEN_EMIT-COP");
   module_initialization_70_cgen_emit(((long) 0), "CGEN_EMIT-COP");
   return module_initialization_70_cgen_cop(((long) 0), "CGEN_EMIT-COP");
}
