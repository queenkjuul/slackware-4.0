/*===========================================================================*/
/*   (Llib/struct.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t make_struct_168___structure(obj_t, long, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _poke_1147_251___structure(obj_t, obj_t, obj_t, obj_t);
extern bool_t struct__46___structure(obj_t);
static obj_t _struct_ref1151_205___structure(obj_t, obj_t, obj_t);
static obj_t _struct_set_1152_178___structure(obj_t, obj_t, obj_t, obj_t);
extern obj_t struct_update__184___structure(obj_t, obj_t);
static obj_t _make_struct1145_91___structure(obj_t, obj_t, obj_t, obj_t);
extern obj_t poke__136___structure(obj_t, long, obj_t);
extern obj_t peek___structure(obj_t, long);
extern obj_t struct_set__199___structure(obj_t, long, obj_t);
static obj_t _struct_key_set_1149_164___structure(obj_t, obj_t, obj_t);
extern obj_t struct_ref_25___structure(obj_t, long);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t struct_key_set__234___structure(obj_t, obj_t);
static obj_t _struct_length1150_82___structure(obj_t, obj_t);
static obj_t _peek1146___structure(obj_t, obj_t, obj_t);
static obj_t _struct_key1148_229___structure(obj_t, obj_t);
extern obj_t struct_key_246___structure(obj_t);
static obj_t _struct_update_1153_182___structure(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___structure();
static obj_t require_initialization_114___structure = BUNSPEC;
static obj_t _struct__118___structure(obj_t, obj_t);
extern long struct_length_222___structure(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( struct_ref_env_47___structure, _struct_ref1151_205___structure1157, _struct_ref1151_205___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_update__env_161___structure, _struct_update_1153_182___structure1158, _struct_update_1153_182___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_set__env_206___structure, _struct_set_1152_178___structure1159, _struct_set_1152_178___structure, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( struct__env_28___structure, _struct__118___structure1160, _struct__118___structure, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_struct_env_132___structure, _make_struct1145_91___structure1161, _make_struct1145_91___structure, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( struct_length_env_97___structure, _struct_length1150_82___structure1162, _struct_length1150_82___structure, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( peek_env_54___structure, _peek1146___structure1163, _peek1146___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_key_set__env_144___structure, _struct_key_set_1149_164___structure1164, _struct_key_set_1149_164___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_key_env_50___structure, _struct_key1148_229___structure1165, _struct_key1148_229___structure, 0L, 1 );
DEFINE_STRING( string1155___structure, string1155___structure1166, "Incompatible structures", 23 );
DEFINE_STRING( string1154___structure, string1154___structure1167, "struct-update!", 14 );
DEFINE_EXPORT_PROCEDURE( poke__env_137___structure, _poke_1147_251___structure1168, _poke_1147_251___structure, 0L, 3 );


/* module-initialization */obj_t module_initialization_70___structure(long checksum_440, char * from_441)
{
if(CBOOL(require_initialization_114___structure)){
require_initialization_114___structure = BBOOL(((bool_t)0));
imported_modules_init_94___structure();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* make-struct */obj_t make_struct_168___structure(obj_t key_1, long len_2, obj_t init_3)
{
return make_struct(key_1, len_2, init_3);
}


/* _make-struct1145 */obj_t _make_struct1145_91___structure(obj_t env_392, obj_t key_393, obj_t len_394, obj_t init_395)
{
{
obj_t key_422;
long len_423;
obj_t init_424;
key_422 = key_393;
len_423 = (long)CINT(len_394);
init_424 = init_395;
return make_struct(key_422, len_423, init_424);
}
}


/* peek */obj_t peek___structure(obj_t struct_4, long offset_5)
{
return PEEK(struct_4, offset_5);
}


/* _peek1146 */obj_t _peek1146___structure(obj_t env_396, obj_t struct_397, obj_t offset_398)
{
{
obj_t struct_116_425;
long offset_426;
struct_116_425 = struct_397;
offset_426 = (long)CINT(offset_398);
return PEEK(struct_116_425, offset_426);
}
}


/* poke! */obj_t poke__136___structure(obj_t struct_6, long offset_7, obj_t value_8)
{
return POKE(struct_6, offset_7, value_8);
}


/* _poke!1147 */obj_t _poke_1147_251___structure(obj_t env_399, obj_t struct_400, obj_t offset_401, obj_t value_402)
{
{
obj_t struct_116_427;
long offset_428;
obj_t value_429;
struct_116_427 = struct_400;
offset_428 = (long)CINT(offset_401);
value_429 = value_402;
return POKE(struct_116_427, offset_428, value_429);
}
}


/* struct? */bool_t struct__46___structure(obj_t o_9)
{
return STRUCTP(o_9);
}


/* _struct? */obj_t _struct__118___structure(obj_t env_403, obj_t o_404)
{
{
bool_t aux_456;
{
obj_t o_430;
o_430 = o_404;
aux_456 = STRUCTP(o_430);
}
return BBOOL(aux_456);
}
}


/* struct-key */obj_t struct_key_246___structure(obj_t s_10)
{
return STRUCT_KEY(s_10);
}


/* _struct-key1148 */obj_t _struct_key1148_229___structure(obj_t env_405, obj_t s_406)
{
{
obj_t s_431;
s_431 = s_406;
return STRUCT_KEY(s_431);
}
}


/* struct-key-set! */obj_t struct_key_set__234___structure(obj_t s_11, obj_t k_12)
{
return STRUCT_KEY_SET(s_11, k_12);
}


/* _struct-key-set!1149 */obj_t _struct_key_set_1149_164___structure(obj_t env_407, obj_t s_408, obj_t k_409)
{
{
obj_t s_432;
obj_t k_433;
s_432 = s_408;
k_433 = k_409;
return STRUCT_KEY_SET(s_432, k_433);
}
}


/* struct-length */long struct_length_222___structure(obj_t s_13)
{
return STRUCT_LENGTH(s_13);
}


/* _struct-length1150 */obj_t _struct_length1150_82___structure(obj_t env_410, obj_t s_411)
{
{
long aux_464;
{
obj_t s_434;
s_434 = s_411;
aux_464 = STRUCT_LENGTH(s_434);
}
return BINT(aux_464);
}
}


/* struct-ref */obj_t struct_ref_25___structure(obj_t s_14, long k_15)
{
return STRUCT_REF(s_14, k_15);
}


/* _struct-ref1151 */obj_t _struct_ref1151_205___structure(obj_t env_412, obj_t s_413, obj_t k_414)
{
{
obj_t s_435;
long k_436;
s_435 = s_413;
k_436 = (long)CINT(k_414);
return STRUCT_REF(s_435, k_436);
}
}


/* struct-set! */obj_t struct_set__199___structure(obj_t s_16, long k_17, obj_t o_18)
{
return STRUCT_SET(s_16, k_17, o_18);
}


/* _struct-set!1152 */obj_t _struct_set_1152_178___structure(obj_t env_415, obj_t s_416, obj_t k_417, obj_t o_418)
{
{
obj_t s_437;
long k_438;
obj_t o_439;
s_437 = s_416;
k_438 = (long)CINT(k_417);
o_439 = o_418;
return STRUCT_SET(s_437, k_438, o_439);
}
}


/* struct-update! */obj_t struct_update__184___structure(obj_t dst_19, obj_t src_20)
{
{
bool_t test_473;
{
bool_t test_474;
{
obj_t aux_477;
obj_t aux_475;
aux_477 = STRUCT_KEY(src_20);
aux_475 = STRUCT_KEY(dst_19);
test_474 = (aux_475==aux_477);
}
if(test_474){
long aux_482;
long aux_480;
aux_482 = STRUCT_LENGTH(src_20);
aux_480 = STRUCT_LENGTH(dst_19);
test_473 = (aux_480==aux_482);
}
 else {
test_473 = ((bool_t)0);
}
}
if(test_473){
long i_231;
{
long aux_492;
aux_492 = STRUCT_LENGTH(dst_19);
i_231 = (aux_492-((long)1));
}
loop_232:
if((i_231==((long)-1))){
return dst_19;
}
 else {
{
obj_t aux_487;
aux_487 = STRUCT_REF(src_20, i_231);
STRUCT_SET(dst_19, i_231, aux_487);
}
{
long i_490;
i_490 = (i_231-((long)1));
i_231 = i_490;
goto loop_232;
}
}
}
 else {
obj_t arg1014_241;
{
obj_t list1015_242;
{
obj_t arg1016_243;
arg1016_243 = MAKE_PAIR(src_20, BNIL);
list1015_242 = MAKE_PAIR(dst_19, arg1016_243);
}
arg1014_241 = list1015_242;
}
FAILURE(string1154___structure,string1155___structure,arg1014_241);}
}
}


/* _struct-update!1153 */obj_t _struct_update_1153_182___structure(obj_t env_419, obj_t dst_420, obj_t src_421)
{
return struct_update__184___structure(dst_420, src_421);
}


/* imported-modules-init */obj_t imported_modules_init_94___structure()
{
return module_initialization_70___error(((long)0), "__STRUCTURE");
}

