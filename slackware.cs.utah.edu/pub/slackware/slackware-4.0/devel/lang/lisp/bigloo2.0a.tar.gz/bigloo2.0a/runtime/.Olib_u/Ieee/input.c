/*===========================================================================*/
/*   (Ieee/input.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t rgc_buffer_substring(obj_t, int, int);
static obj_t _char_ready__35___r4_input_6_10_2(obj_t, obj_t);
static obj_t toplevel_init_63___r4_input_6_10_2();
static obj_t _read_rp1425_78___r4_input_6_10_2(obj_t, obj_t, obj_t);
extern bool_t char_ready__201___r4_input_6_10_2(obj_t);
extern bool_t rgc_fill_buffer(obj_t);
static obj_t _read_line_106___r4_input_6_10_2(obj_t, obj_t);
static obj_t _read_line_grammar__25___r4_input_6_10_2 = BUNSPEC;
extern obj_t current_input_port;
extern obj_t read_of_strings_88___r4_input_6_10_2(obj_t);
extern obj_t read_lalrp_80___r4_input_6_10_2(obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1198___r4_input_6_10_2(obj_t, obj_t);
static obj_t _read_lalrp1426_153___r4_input_6_10_2(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1156___r4_input_6_10_2(obj_t, obj_t);
static obj_t lambda1087___r4_input_6_10_2(obj_t, obj_t);
extern obj_t read_rp_218___r4_input_6_10_2(obj_t, obj_t);
static obj_t lambda1033___r4_input_6_10_2(obj_t, obj_t);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___error(long, char *);
obj_t _about_to_read__202___r4_input_6_10_2 = BUNSPEC;
extern obj_t read_line_110___r4_input_6_10_2(obj_t);
static obj_t _read_char_89___r4_input_6_10_2(obj_t, obj_t);
static obj_t _read_of_strings_grammar__196___r4_input_6_10_2 = BUNSPEC;
static obj_t _peek_char_199___r4_input_6_10_2(obj_t, obj_t);
extern int rgc_buffer_unget_char(obj_t, int);
static obj_t _read_of_strings_6___r4_input_6_10_2(obj_t, obj_t);
static obj_t _eof_object__147___r4_input_6_10_2(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_input_6_10_2();
extern obj_t read_char_74___r4_input_6_10_2(obj_t);
extern obj_t peek_char_171___r4_input_6_10_2(obj_t);
static obj_t require_initialization_114___r4_input_6_10_2 = BUNSPEC;
extern bool_t eof_object__7___r4_input_6_10_2(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( read_rp_env_12___r4_input_6_10_2, _read_rp1425_78___r4_input_6_10_21437, _read_rp1425_78___r4_input_6_10_2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( peek_char_env_115___r4_input_6_10_2, _peek_char_199___r4_input_6_10_21438, va_generic_entry, _peek_char_199___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_of_strings_env_168___r4_input_6_10_2, _read_of_strings_6___r4_input_6_10_21439, va_generic_entry, _read_of_strings_6___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_line_env_128___r4_input_6_10_2, _read_line_106___r4_input_6_10_21440, va_generic_entry, _read_line_106___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_lalrp_env_134___r4_input_6_10_2, _read_lalrp1426_153___r4_input_6_10_21441, va_generic_entry, _read_lalrp1426_153___r4_input_6_10_2, -4 );
DEFINE_STATIC_PROCEDURE( proc1435___r4_input_6_10_2, lambda1198___r4_input_6_10_21442, lambda1198___r4_input_6_10_2, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1434___r4_input_6_10_2, lambda1156___r4_input_6_10_21443, lambda1156___r4_input_6_10_2, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1428___r4_input_6_10_2, lambda1087___r4_input_6_10_21444, lambda1087___r4_input_6_10_2, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1427___r4_input_6_10_2, lambda1033___r4_input_6_10_21445, lambda1033___r4_input_6_10_2, 0L, 1 );
DEFINE_STRING( string1433___r4_input_6_10_2, string1433___r4_input_6_10_21446, "Illegal range", 13 );
DEFINE_STRING( string1432___r4_input_6_10_2, string1432___r4_input_6_10_21447, "the-substring", 13 );
DEFINE_STRING( string1431___r4_input_6_10_2, string1431___r4_input_6_10_21448, "", 0 );
DEFINE_STRING( string1429___r4_input_6_10_2, string1429___r4_input_6_10_21449, "regular-grammar", 15 );
DEFINE_STRING( string1430___r4_input_6_10_2, string1430___r4_input_6_10_21450, "Illegal match", 13 );
DEFINE_EXPORT_PROCEDURE( eof_object__env_183___r4_input_6_10_2, _eof_object__147___r4_input_6_10_21451, _eof_object__147___r4_input_6_10_2, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ready__env_148___r4_input_6_10_2, _char_ready__35___r4_input_6_10_21452, va_generic_entry, _char_ready__35___r4_input_6_10_2, -1 );
DEFINE_EXPORT_PROCEDURE( read_char_env_52___r4_input_6_10_2, _read_char_89___r4_input_6_10_21453, va_generic_entry, _read_char_89___r4_input_6_10_2, -1 );


/* module-initialization */obj_t module_initialization_70___r4_input_6_10_2(long checksum_1195, char * from_1196)
{
if(CBOOL(require_initialization_114___r4_input_6_10_2)){
require_initialization_114___r4_input_6_10_2 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_input_6_10_2();
toplevel_init_63___r4_input_6_10_2();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___r4_input_6_10_2()
{
{
obj_t lambda1033_1156;
lambda1033_1156 = proc1427___r4_input_6_10_2;
_read_line_grammar__25___r4_input_6_10_2 = lambda1033_1156;
}
{
obj_t lambda1087_1155;
lambda1087_1155 = proc1428___r4_input_6_10_2;
_read_of_strings_grammar__196___r4_input_6_10_2 = lambda1087_1155;
}
return (_about_to_read__202___r4_input_6_10_2 = BUNSPEC,
BUNSPEC);
}


/* lambda1087 */obj_t lambda1087___r4_input_6_10_2(obj_t env_1157, obj_t input_port_219_1158)
{
{
obj_t input_port_219_382;
input_port_219_382 = input_port_219_1158;
{
long last_match_133_477;
long last_match_133_468;
long last_match_133_458;
long last_match_133_448;
long last_match_133_439;
ignore_506:
RGC_START_MATCH(input_port_219_382);
{
int match_404;
{
long aux_1203;
last_match_133_439 = ((long)2);
state_0_1020_174_493:
{
int current_char_37_441;
current_char_37_441 = RGC_BUFFER_GET_CHAR(input_port_219_382);
{
bool_t test_1205;
{
long aux_1206;
aux_1206 = (long)(current_char_37_441);
test_1205 = (aux_1206==((long)0));
}
if(test_1205){
{
bool_t test1119_443;
test1119_443 = RGC_BUFFER_EMPTY(input_port_219_382);
if(test1119_443){
bool_t test1120_444;
test1120_444 = rgc_fill_buffer(input_port_219_382);
if(test1120_444){
goto state_0_1020_174_493;
}
 else {
aux_1203 = last_match_133_439;
}
}
 else {
last_match_133_448 = last_match_133_439;
state_1_1021_68_492:
{
long new_match_93_450;
RGC_STOP_MATCH(input_port_219_382);
new_match_93_450 = ((long)1);
{
int current_char_37_451;
current_char_37_451 = RGC_BUFFER_GET_CHAR(input_port_219_382);
{
bool_t test_1215;
{
long aux_1216;
aux_1216 = (long)(current_char_37_451);
test_1215 = (aux_1216==((long)0));
}
if(test_1215){
{
bool_t test1126_453;
test1126_453 = RGC_BUFFER_EMPTY(input_port_219_382);
if(test1126_453){
bool_t test1127_454;
test1127_454 = rgc_fill_buffer(input_port_219_382);
if(test1127_454){
goto state_1_1021_68_492;
}
 else {
aux_1203 = new_match_93_450;
}
}
 else {
last_match_133_458 = new_match_93_450;
state_5_1025_208_491:
{
long new_match_93_460;
RGC_STOP_MATCH(input_port_219_382);
new_match_93_460 = ((long)1);
{
int current_char_37_461;
current_char_37_461 = RGC_BUFFER_GET_CHAR(input_port_219_382);
{
bool_t test_1225;
{
long aux_1226;
aux_1226 = (long)(current_char_37_461);
test_1225 = (aux_1226==((long)0));
}
if(test_1225){
{
bool_t test1133_463;
test1133_463 = RGC_BUFFER_EMPTY(input_port_219_382);
if(test1133_463){
bool_t test1134_464;
test1134_464 = rgc_fill_buffer(input_port_219_382);
if(test1134_464){
goto state_5_1025_208_491;
}
 else {
aux_1203 = new_match_93_460;
}
}
 else {
long last_match_133_1233;
last_match_133_1233 = new_match_93_460;
last_match_133_458 = last_match_133_1233;
goto state_5_1025_208_491;
}
}
}
 else {
bool_t test_1234;
{
bool_t test_1235;
{
bool_t test_1236;
{
long aux_1237;
aux_1237 = (long)(current_char_37_461);
test_1236 = (aux_1237==((long)10));
}
if(test_1236){
test_1235 = ((bool_t)1);
}
 else {
long aux_1240;
aux_1240 = (long)(current_char_37_461);
test_1235 = (aux_1240==((long)9));
}
}
if(test_1235){
test_1234 = ((bool_t)1);
}
 else {
long aux_1243;
aux_1243 = (long)(current_char_37_461);
test_1234 = (aux_1243==((long)32));
}
}
if(test_1234){
aux_1203 = new_match_93_460;
}
 else {
{
long last_match_133_1246;
last_match_133_1246 = new_match_93_460;
last_match_133_458 = last_match_133_1246;
goto state_5_1025_208_491;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_1247;
{
bool_t test_1248;
{
bool_t test_1249;
{
long aux_1250;
aux_1250 = (long)(current_char_37_451);
test_1249 = (aux_1250==((long)10));
}
if(test_1249){
test_1248 = ((bool_t)1);
}
 else {
long aux_1253;
aux_1253 = (long)(current_char_37_451);
test_1248 = (aux_1253==((long)9));
}
}
if(test_1248){
test_1247 = ((bool_t)1);
}
 else {
long aux_1256;
aux_1256 = (long)(current_char_37_451);
test_1247 = (aux_1256==((long)32));
}
}
if(test_1247){
aux_1203 = new_match_93_450;
}
 else {
{
long last_match_133_1259;
last_match_133_1259 = new_match_93_450;
last_match_133_458 = last_match_133_1259;
goto state_5_1025_208_491;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_1260;
{
bool_t test_1261;
{
bool_t test_1262;
{
long aux_1263;
aux_1263 = (long)(current_char_37_441);
test_1262 = (aux_1263==((long)10));
}
if(test_1262){
test_1261 = ((bool_t)1);
}
 else {
long aux_1266;
aux_1266 = (long)(current_char_37_441);
test_1261 = (aux_1266==((long)9));
}
}
if(test_1261){
test_1260 = ((bool_t)1);
}
 else {
long aux_1269;
aux_1269 = (long)(current_char_37_441);
test_1260 = (aux_1269==((long)32));
}
}
if(test_1260){
last_match_133_468 = last_match_133_439;
state_2_1022_149_490:
{
long new_match_93_470;
RGC_STOP_MATCH(input_port_219_382);
new_match_93_470 = ((long)0);
{
int current_char_37_471;
current_char_37_471 = RGC_BUFFER_GET_CHAR(input_port_219_382);
{
bool_t test_1274;
{
long aux_1275;
aux_1275 = (long)(current_char_37_471);
test_1274 = (aux_1275==((long)0));
}
if(test_1274){
{
bool_t test1140_473;
{
bool_t res1410_992;
{
bool_t _andtest_1031_989;
_andtest_1031_989 = RGC_BUFFER_EMPTY(input_port_219_382);
if(_andtest_1031_989){
res1410_992 = rgc_fill_buffer(input_port_219_382);
}
 else {
res1410_992 = ((bool_t)0);
}
}
test1140_473 = res1410_992;
}
if(test1140_473){
goto state_2_1022_149_490;
}
 else {
aux_1203 = new_match_93_470;
}
}
}
 else {
bool_t test_1282;
{
bool_t test_1283;
{
bool_t test_1284;
{
long aux_1285;
aux_1285 = (long)(current_char_37_471);
test_1284 = (aux_1285==((long)10));
}
if(test_1284){
test_1283 = ((bool_t)1);
}
 else {
long aux_1288;
aux_1288 = (long)(current_char_37_471);
test_1283 = (aux_1288==((long)9));
}
}
if(test_1283){
test_1282 = ((bool_t)1);
}
 else {
long aux_1291;
aux_1291 = (long)(current_char_37_471);
test_1282 = (aux_1291==((long)32));
}
}
if(test_1282){
last_match_133_477 = new_match_93_470;
state_3_1023_8_489:
{
long new_match_93_479;
RGC_STOP_MATCH(input_port_219_382);
new_match_93_479 = ((long)0);
{
int current_char_37_480;
current_char_37_480 = RGC_BUFFER_GET_CHAR(input_port_219_382);
{
bool_t test_1296;
{
long aux_1297;
aux_1297 = (long)(current_char_37_480);
test_1296 = (aux_1297==((long)0));
}
if(test_1296){
{
bool_t test1146_482;
{
bool_t res1411_1007;
{
bool_t _andtest_1031_1004;
_andtest_1031_1004 = RGC_BUFFER_EMPTY(input_port_219_382);
if(_andtest_1031_1004){
res1411_1007 = rgc_fill_buffer(input_port_219_382);
}
 else {
res1411_1007 = ((bool_t)0);
}
}
test1146_482 = res1411_1007;
}
if(test1146_482){
goto state_3_1023_8_489;
}
 else {
aux_1203 = new_match_93_479;
}
}
}
 else {
bool_t test_1304;
{
bool_t test_1305;
{
bool_t test_1306;
{
long aux_1307;
aux_1307 = (long)(current_char_37_480);
test_1306 = (aux_1307==((long)10));
}
if(test_1306){
test_1305 = ((bool_t)1);
}
 else {
long aux_1310;
aux_1310 = (long)(current_char_37_480);
test_1305 = (aux_1310==((long)9));
}
}
if(test_1305){
test_1304 = ((bool_t)1);
}
 else {
long aux_1313;
aux_1313 = (long)(current_char_37_480);
test_1304 = (aux_1313==((long)32));
}
}
if(test_1304){
{
long last_match_133_1316;
last_match_133_1316 = new_match_93_479;
last_match_133_477 = last_match_133_1316;
goto state_3_1023_8_489;
}
}
 else {
aux_1203 = new_match_93_479;
}
}
}
}
}
}
 else {
aux_1203 = new_match_93_470;
}
}
}
}
}
}
 else {
{
long last_match_133_1317;
last_match_133_1317 = last_match_133_439;
last_match_133_448 = last_match_133_1317;
goto state_1_1021_68_492;
}
}
}
}
}
match_404 = (int)(aux_1203);
}
switch ((long)(match_404)){
case ((long)2) : 
{
bool_t test1095_415;
{
int arg1098_418;
{
int res1406_928;
{
long aux_1319;
aux_1319 = RGC_BUFFER_LENGTH(input_port_219_382);
res1406_928 = (int)(aux_1319);
}
arg1098_418 = res1406_928;
}
{
long aux_1322;
aux_1322 = (long)(arg1098_418);
test1095_415 = (aux_1322==((long)0));
}
}
if(test1095_415){
return BCNST(256);
}
 else {
obj_t arg1096_416;
{
obj_t res1408_938;
{
int arg1115_932;
{
int res1407_934;
{
long aux_1326;
aux_1326 = RGC_BUFFER_LENGTH(input_port_219_382);
res1407_934 = (int)(aux_1326);
}
arg1115_932 = res1407_934;
}
{
int aux_1329;
aux_1329 = (int)(((long)0));
res1408_938 = rgc_buffer_substring(input_port_219_382, aux_1329, arg1115_932);
}
}
arg1096_416 = res1408_938;
}
{
unsigned char aux_1332;
aux_1332 = STRING_REF(arg1096_416, ((long)0));
return BCHAR(aux_1332);
}
}
}
break;
case ((long)1) : 
{
obj_t res1405_917;
{
int arg1115_911;
{
int res1404_913;
{
long aux_1335;
aux_1335 = RGC_BUFFER_LENGTH(input_port_219_382);
res1404_913 = (int)(aux_1335);
}
arg1115_911 = res1404_913;
}
{
int aux_1338;
aux_1338 = (int)(((long)0));
res1405_917 = rgc_buffer_substring(input_port_219_382, aux_1338, arg1115_911);
}
}
return res1405_917;
}
break;
case ((long)0) : 
goto ignore_506;
break;
default: 
FAILURE(string1429___r4_input_6_10_2,string1430___r4_input_6_10_2,BINT(match_404));}
}
}
}
}


/* lambda1033 */obj_t lambda1033___r4_input_6_10_2(obj_t env_1159, obj_t input_port_219_1160)
{
{
obj_t input_port_219_270;
input_port_219_270 = input_port_219_1160;
{
long last_match_133_346;
long last_match_133_338;
long last_match_133_331;
long min_317;
long max_318;
RGC_START_MATCH(input_port_219_270);
{
int match_292;
{
long aux_1346;
last_match_133_331 = ((long)3);
state_0_1012_101_367:
{
int current_char_37_333;
current_char_37_333 = RGC_BUFFER_GET_CHAR(input_port_219_270);
{
bool_t test_1348;
{
long aux_1349;
aux_1349 = (long)(current_char_37_333);
test_1348 = (aux_1349==((long)0));
}
if(test_1348){
{
bool_t test1070_335;
test1070_335 = RGC_BUFFER_EMPTY(input_port_219_270);
if(test1070_335){
bool_t test1071_336;
test1071_336 = rgc_fill_buffer(input_port_219_270);
if(test1071_336){
goto state_0_1012_101_367;
}
 else {
aux_1346 = last_match_133_331;
}
}
 else {
last_match_133_338 = last_match_133_331;
state_1_1013_67_366:
{
long new_match_93_340;
RGC_STOP_MATCH(input_port_219_270);
new_match_93_340 = ((long)1);
{
int current_char_37_341;
current_char_37_341 = RGC_BUFFER_GET_CHAR(input_port_219_270);
{
bool_t test_1358;
{
long aux_1359;
aux_1359 = (long)(current_char_37_341);
test_1358 = (aux_1359==((long)0));
}
if(test_1358){
{
bool_t test1075_343;
test1075_343 = RGC_BUFFER_EMPTY(input_port_219_270);
if(test1075_343){
bool_t test1076_344;
test1076_344 = rgc_fill_buffer(input_port_219_270);
if(test1076_344){
goto state_1_1013_67_366;
}
 else {
aux_1346 = new_match_93_340;
}
}
 else {
last_match_133_346 = new_match_93_340;
state_4_1016_66_365:
{
long new_match_93_348;
RGC_STOP_MATCH(input_port_219_270);
new_match_93_348 = ((long)1);
{
int current_char_37_349;
current_char_37_349 = RGC_BUFFER_GET_CHAR(input_port_219_270);
{
bool_t test_1368;
{
long aux_1369;
aux_1369 = (long)(current_char_37_349);
test_1368 = (aux_1369==((long)0));
}
if(test_1368){
{
bool_t test1080_351;
test1080_351 = RGC_BUFFER_EMPTY(input_port_219_270);
if(test1080_351){
bool_t test1081_352;
test1081_352 = rgc_fill_buffer(input_port_219_270);
if(test1081_352){
goto state_4_1016_66_365;
}
 else {
aux_1346 = new_match_93_348;
}
}
 else {
long last_match_133_1376;
last_match_133_1376 = new_match_93_348;
last_match_133_346 = last_match_133_1376;
goto state_4_1016_66_365;
}
}
}
 else {
bool_t test_1377;
{
long aux_1378;
aux_1378 = (long)(current_char_37_349);
test_1377 = (aux_1378==((long)10));
}
if(test_1377){
{
long new_match_93_903;
RGC_STOP_MATCH(input_port_219_270);
new_match_93_903 = ((long)0);
aux_1346 = new_match_93_903;
}
}
 else {
{
long last_match_133_1382;
last_match_133_1382 = new_match_93_348;
last_match_133_346 = last_match_133_1382;
goto state_4_1016_66_365;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_1383;
{
long aux_1384;
aux_1384 = (long)(current_char_37_341);
test_1383 = (aux_1384==((long)10));
}
if(test_1383){
{
long new_match_93_892;
RGC_STOP_MATCH(input_port_219_270);
new_match_93_892 = ((long)0);
aux_1346 = new_match_93_892;
}
}
 else {
{
long last_match_133_1388;
last_match_133_1388 = new_match_93_340;
last_match_133_346 = last_match_133_1388;
goto state_4_1016_66_365;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_1389;
{
long aux_1390;
aux_1390 = (long)(current_char_37_333);
test_1389 = (aux_1390==((long)10));
}
if(test_1389){
{
long new_match_93_881;
RGC_STOP_MATCH(input_port_219_270);
new_match_93_881 = ((long)2);
aux_1346 = new_match_93_881;
}
}
 else {
{
long last_match_133_1394;
last_match_133_1394 = last_match_133_331;
last_match_133_338 = last_match_133_1394;
goto state_1_1013_67_366;
}
}
}
}
}
match_292 = (int)(aux_1346);
}
switch ((long)(match_292)){
case ((long)3) : 
{
bool_t test1046_307;
{
int arg1049_310;
{
int res1399_836;
{
long aux_1396;
aux_1396 = RGC_BUFFER_LENGTH(input_port_219_270);
res1399_836 = (int)(aux_1396);
}
arg1049_310 = res1399_836;
}
{
long aux_1399;
aux_1399 = (long)(arg1049_310);
test1046_307 = (aux_1399==((long)0));
}
}
if(test1046_307){
return BCNST(256);
}
 else {
obj_t arg1047_308;
{
obj_t res1401_846;
{
int arg1066_840;
{
int res1400_842;
{
long aux_1403;
aux_1403 = RGC_BUFFER_LENGTH(input_port_219_270);
res1400_842 = (int)(aux_1403);
}
arg1066_840 = res1400_842;
}
{
int aux_1406;
aux_1406 = (int)(((long)0));
res1401_846 = rgc_buffer_substring(input_port_219_270, aux_1406, arg1066_840);
}
}
arg1047_308 = res1401_846;
}
{
unsigned char aux_1409;
aux_1409 = STRING_REF(arg1047_308, ((long)0));
return BCHAR(aux_1409);
}
}
}
break;
case ((long)2) : 
return string1431___r4_input_6_10_2;
break;
case ((long)1) : 
{
obj_t res1397_821;
{
int arg1066_815;
{
int res1396_817;
{
long aux_1412;
aux_1412 = RGC_BUFFER_LENGTH(input_port_219_270);
res1396_817 = (int)(aux_1412);
}
arg1066_815 = res1396_817;
}
{
int aux_1415;
aux_1415 = (int)(((long)0));
res1397_821 = rgc_buffer_substring(input_port_219_270, aux_1415, arg1066_815);
}
}
return res1397_821;
}
break;
case ((long)0) : 
{
long arg1038_297;
{
int arg1039_298;
{
int res1398_823;
{
long aux_1418;
aux_1418 = RGC_BUFFER_LENGTH(input_port_219_270);
res1398_823 = (int)(aux_1418);
}
arg1039_298 = res1398_823;
}
{
long aux_1421;
aux_1421 = (long)(arg1039_298);
arg1038_297 = (aux_1421-((long)1));
}
}
min_317 = ((long)0);
max_318 = arg1038_297;
{
bool_t test1057_320;
if((min_317>=((long)0))){
bool_t test1062_325;
{
int arg1063_326;
{
int res1402_853;
{
long aux_1426;
aux_1426 = RGC_BUFFER_LENGTH(input_port_219_270);
res1402_853 = (int)(aux_1426);
}
arg1063_326 = res1402_853;
}
{
long aux_1429;
aux_1429 = (long)(arg1063_326);
test1062_325 = (max_318<=aux_1429);
}
}
if(test1062_325){
test1057_320 = (max_318>=min_317);
}
 else {
test1057_320 = ((bool_t)0);
}
}
 else {
test1057_320 = ((bool_t)0);
}
if(test1057_320){
int aux_1437;
int aux_1435;
aux_1437 = (int)(max_318);
aux_1435 = (int)(min_317);
return rgc_buffer_substring(input_port_219_270, aux_1435, aux_1437);
}
 else {
obj_t arg1060_323;
{
obj_t aux_1442;
obj_t aux_1440;
aux_1442 = BINT(max_318);
aux_1440 = BINT(min_317);
arg1060_323 = MAKE_PAIR(aux_1440, aux_1442);
}
FAILURE(string1432___r4_input_6_10_2,string1433___r4_input_6_10_2,arg1060_323);}
}
}
break;
default: 
FAILURE(string1429___r4_input_6_10_2,string1430___r4_input_6_10_2,BINT(match_292));}
}
}
}
}


/* read/rp */obj_t read_rp_218___r4_input_6_10_2(obj_t grammar_1, obj_t port_2)
{
return PROCEDURE_ENTRY(grammar_1)(grammar_1, port_2, BEOA);
}


/* _read/rp1425 */obj_t _read_rp1425_78___r4_input_6_10_2(obj_t env_1161, obj_t grammar_1162, obj_t port_1163)
{
{
obj_t grammar_1187;
obj_t port_1188;
grammar_1187 = grammar_1162;
port_1188 = port_1163;
return PROCEDURE_ENTRY(grammar_1187)(grammar_1187, port_1188, BEOA);
}
}


/* read/lalrp */obj_t read_lalrp_80___r4_input_6_10_2(obj_t lalr_3, obj_t rgc_4, obj_t port_5, obj_t eof_fun__175_6)
{
if(NULLP(eof_fun__175_6)){
return PROCEDURE_ENTRY(lalr_3)(lalr_3, rgc_4, port_5, eof_object__env_183___r4_input_6_10_2, BEOA);
}
 else {
return PROCEDURE_ENTRY(lalr_3)(lalr_3, rgc_4, port_5, CAR(eof_fun__175_6), BEOA);
}
}


/* _read/lalrp1426 */obj_t _read_lalrp1426_153___r4_input_6_10_2(obj_t env_1164, obj_t lalr_1165, obj_t rgc_1166, obj_t port_1167, obj_t eof_fun__175_1168)
{
{
obj_t lalr_1189;
obj_t rgc_1190;
obj_t port_1191;
obj_t eof_fun__175_1192;
lalr_1189 = lalr_1165;
rgc_1190 = rgc_1166;
port_1191 = port_1167;
eof_fun__175_1192 = eof_fun__175_1168;
if(NULLP(eof_fun__175_1192)){
return PROCEDURE_ENTRY(lalr_1189)(lalr_1189, rgc_1190, port_1191, eof_object__env_183___r4_input_6_10_2, BEOA);
}
 else {
return PROCEDURE_ENTRY(lalr_1189)(lalr_1189, rgc_1190, port_1191, CAR(eof_fun__175_1192), BEOA);
}
}
}


/* read-char */obj_t read_char_74___r4_input_6_10_2(obj_t ip_7)
{
{
obj_t grammar_509;
{
obj_t lambda1156_1171;
lambda1156_1171 = proc1434___r4_input_6_10_2;
grammar_509 = lambda1156_1171;
}
{
obj_t aux_1468;
if(NULLP(ip_7)){
aux_1468 = current_input_port;
}
 else {
aux_1468 = CAR(ip_7);
}
return PROCEDURE_ENTRY(grammar_509)(grammar_509, aux_1468, BEOA);
}
}
}


/* _read-char */obj_t _read_char_89___r4_input_6_10_2(obj_t env_1172, obj_t ip_1173)
{
return read_char_74___r4_input_6_10_2(ip_1173);
}


/* lambda1156 */obj_t lambda1156___r4_input_6_10_2(obj_t env_1174, obj_t input_port_219_1175)
{
{
obj_t input_port_219_513;
input_port_219_513 = input_port_219_1175;
{
long last_match_133_569;
RGC_START_MATCH(input_port_219_513);
{
int match_532;
{
long aux_1476;
last_match_133_569 = ((long)1);
state_0_1002_0_582:
{
int current_char_37_571;
current_char_37_571 = RGC_BUFFER_GET_CHAR(input_port_219_513);
{
bool_t test_1478;
{
long aux_1479;
aux_1479 = (long)(current_char_37_571);
test_1478 = (aux_1479==((long)0));
}
if(test_1478){
{
bool_t test1191_573;
test1191_573 = RGC_BUFFER_EMPTY(input_port_219_513);
if(test1191_573){
bool_t test1192_574;
test1192_574 = rgc_fill_buffer(input_port_219_513);
if(test1192_574){
goto state_0_1002_0_582;
}
 else {
aux_1476 = last_match_133_569;
}
}
 else {
long new_match_93_1066;
RGC_STOP_MATCH(input_port_219_513);
new_match_93_1066 = ((long)0);
aux_1476 = new_match_93_1066;
}
}
}
 else {
{
long new_match_93_1069;
RGC_STOP_MATCH(input_port_219_513);
new_match_93_1069 = ((long)0);
aux_1476 = new_match_93_1069;
}
}
}
}
match_532 = (int)(aux_1476);
}
switch ((long)(match_532)){
case ((long)1) : 
{
bool_t test1167_545;
{
int arg1170_548;
{
int res1414_1039;
{
long aux_1489;
aux_1489 = RGC_BUFFER_LENGTH(input_port_219_513);
res1414_1039 = (int)(aux_1489);
}
arg1170_548 = res1414_1039;
}
{
long aux_1492;
aux_1492 = (long)(arg1170_548);
test1167_545 = (aux_1492==((long)0));
}
}
if(test1167_545){
return BCNST(256);
}
 else {
obj_t arg1168_546;
{
obj_t res1416_1049;
{
int arg1187_1043;
{
int res1415_1045;
{
long aux_1496;
aux_1496 = RGC_BUFFER_LENGTH(input_port_219_513);
res1415_1045 = (int)(aux_1496);
}
arg1187_1043 = res1415_1045;
}
{
int aux_1499;
aux_1499 = (int)(((long)0));
res1416_1049 = rgc_buffer_substring(input_port_219_513, aux_1499, arg1187_1043);
}
}
arg1168_546 = res1416_1049;
}
{
unsigned char aux_1502;
aux_1502 = STRING_REF(arg1168_546, ((long)0));
return BCHAR(aux_1502);
}
}
}
break;
case ((long)0) : 
{
obj_t arg1160_536;
{
obj_t res1413_1026;
{
int arg1187_1020;
{
int res1412_1022;
{
long aux_1505;
aux_1505 = RGC_BUFFER_LENGTH(input_port_219_513);
res1412_1022 = (int)(aux_1505);
}
arg1187_1020 = res1412_1022;
}
{
int aux_1508;
aux_1508 = (int)(((long)0));
res1413_1026 = rgc_buffer_substring(input_port_219_513, aux_1508, arg1187_1020);
}
}
arg1160_536 = res1413_1026;
}
{
unsigned char aux_1511;
aux_1511 = STRING_REF(arg1160_536, ((long)0));
return BCHAR(aux_1511);
}
}
break;
default: 
FAILURE(string1429___r4_input_6_10_2,string1430___r4_input_6_10_2,BINT(match_532));}
}
}
}
}


/* peek-char */obj_t peek_char_171___r4_input_6_10_2(obj_t ip_8)
{
{
obj_t grammar_596;
{
obj_t lambda1198_1176;
lambda1198_1176 = proc1435___r4_input_6_10_2;
grammar_596 = lambda1198_1176;
}
{
obj_t aux_1518;
if(NULLP(ip_8)){
aux_1518 = current_input_port;
}
 else {
aux_1518 = CAR(ip_8);
}
return PROCEDURE_ENTRY(grammar_596)(grammar_596, aux_1518, BEOA);
}
}
}


/* _peek-char */obj_t _peek_char_199___r4_input_6_10_2(obj_t env_1177, obj_t ip_1178)
{
return peek_char_171___r4_input_6_10_2(ip_1178);
}


/* lambda1198 */obj_t lambda1198___r4_input_6_10_2(obj_t env_1179, obj_t input_port_219_1180)
{
{
obj_t input_port_219_600;
input_port_219_600 = input_port_219_1180;
{
long last_match_133_659;
RGC_START_MATCH(input_port_219_600);
{
int match_619;
{
long aux_1526;
last_match_133_659 = ((long)1);
state_0_1007_44_672:
{
int current_char_37_661;
current_char_37_661 = RGC_BUFFER_GET_CHAR(input_port_219_600);
{
bool_t test_1528;
{
long aux_1529;
aux_1529 = (long)(current_char_37_661);
test_1528 = (aux_1529==((long)0));
}
if(test_1528){
{
bool_t test1238_663;
test1238_663 = RGC_BUFFER_EMPTY(input_port_219_600);
if(test1238_663){
bool_t test1239_664;
test1239_664 = rgc_fill_buffer(input_port_219_600);
if(test1239_664){
goto state_0_1007_44_672;
}
 else {
aux_1526 = last_match_133_659;
}
}
 else {
long new_match_93_1129;
RGC_STOP_MATCH(input_port_219_600);
new_match_93_1129 = ((long)0);
aux_1526 = new_match_93_1129;
}
}
}
 else {
{
long new_match_93_1132;
RGC_STOP_MATCH(input_port_219_600);
new_match_93_1132 = ((long)0);
aux_1526 = new_match_93_1132;
}
}
}
}
match_619 = (int)(aux_1526);
}
switch ((long)(match_619)){
case ((long)1) : 
{
bool_t test1210_635;
{
int arg1214_638;
{
int res1421_1102;
{
long aux_1539;
aux_1539 = RGC_BUFFER_LENGTH(input_port_219_600);
res1421_1102 = (int)(aux_1539);
}
arg1214_638 = res1421_1102;
}
{
long aux_1542;
aux_1542 = (long)(arg1214_638);
test1210_635 = (aux_1542==((long)0));
}
}
if(test1210_635){
return BCNST(256);
}
 else {
obj_t arg1211_636;
{
obj_t res1423_1112;
{
int arg1234_1106;
{
int res1422_1108;
{
long aux_1546;
aux_1546 = RGC_BUFFER_LENGTH(input_port_219_600);
res1422_1108 = (int)(aux_1546);
}
arg1234_1106 = res1422_1108;
}
{
int aux_1549;
aux_1549 = (int)(((long)0));
res1423_1112 = rgc_buffer_substring(input_port_219_600, aux_1549, arg1234_1106);
}
}
arg1211_636 = res1423_1112;
}
{
unsigned char aux_1552;
aux_1552 = STRING_REF(arg1211_636, ((long)0));
return BCHAR(aux_1552);
}
}
}
break;
case ((long)0) : 
{
unsigned char c_623;
{
obj_t arg1203_626;
{
obj_t res1419_1085;
{
int arg1234_1079;
{
int res1418_1081;
{
long aux_1555;
aux_1555 = RGC_BUFFER_LENGTH(input_port_219_600);
res1418_1081 = (int)(aux_1555);
}
arg1234_1079 = res1418_1081;
}
{
int aux_1558;
aux_1558 = (int)(((long)0));
res1419_1085 = rgc_buffer_substring(input_port_219_600, aux_1558, arg1234_1079);
}
}
arg1203_626 = res1419_1085;
}
c_623 = STRING_REF(arg1203_626, ((long)0));
}
{
int aux_1562;
{
long aux_1563;
aux_1563 = (c_623);
aux_1562 = (int)(aux_1563);
}
rgc_buffer_unget_char(input_port_219_600, aux_1562);
}
return BCHAR(c_623);
}
break;
default: 
FAILURE(string1429___r4_input_6_10_2,string1430___r4_input_6_10_2,BINT(match_619));}
}
}
}
}


/* eof-object? */bool_t eof_object__7___r4_input_6_10_2(obj_t object_9)
{
return EOF_OBJECTP(object_9);
}


/* _eof-object? */obj_t _eof_object__147___r4_input_6_10_2(obj_t env_1169, obj_t object_1170)
{
{
bool_t aux_1573;
{
obj_t object_1193;
object_1193 = object_1170;
aux_1573 = EOF_OBJECTP(object_1193);
}
return BBOOL(aux_1573);
}
}


/* char-ready? */bool_t char_ready__201___r4_input_6_10_2(obj_t port_10)
{
return ((bool_t)1);
}


/* _char-ready? */obj_t _char_ready__35___r4_input_6_10_2(obj_t env_1181, obj_t port_1182)
{
return BBOOL(((bool_t)1));
}


/* read-line */obj_t read_line_110___r4_input_6_10_2(obj_t input_port_219_11)
{
{
obj_t aux_1577;
if(PAIRP(input_port_219_11)){
aux_1577 = CAR(input_port_219_11);
}
 else {
aux_1577 = current_input_port;
}
return PROCEDURE_ENTRY(_read_line_grammar__25___r4_input_6_10_2)(_read_line_grammar__25___r4_input_6_10_2, aux_1577, BEOA);
}
}


/* _read-line */obj_t _read_line_106___r4_input_6_10_2(obj_t env_1183, obj_t input_port_219_1184)
{
return read_line_110___r4_input_6_10_2(input_port_219_1184);
}


/* read-of-strings */obj_t read_of_strings_88___r4_input_6_10_2(obj_t input_port_219_12)
{
{
obj_t aux_1584;
if(PAIRP(input_port_219_12)){
aux_1584 = CAR(input_port_219_12);
}
 else {
aux_1584 = current_input_port;
}
return PROCEDURE_ENTRY(_read_of_strings_grammar__196___r4_input_6_10_2)(_read_of_strings_grammar__196___r4_input_6_10_2, aux_1584, BEOA);
}
}


/* _read-of-strings */obj_t _read_of_strings_6___r4_input_6_10_2(obj_t env_1185, obj_t input_port_219_1186)
{
return read_of_strings_88___r4_input_6_10_2(input_port_219_1186);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_input_6_10_2()
{
module_initialization_70___error(((long)0), "__R4_INPUT_6_10_2");
return module_initialization_70___r4_ports_6_10_1(((long)0), "__R4_INPUT_6_10_2");
}

