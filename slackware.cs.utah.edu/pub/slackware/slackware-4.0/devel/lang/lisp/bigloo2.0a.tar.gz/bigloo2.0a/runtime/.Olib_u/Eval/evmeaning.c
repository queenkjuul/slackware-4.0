/*===========================================================================*/
/*   (Eval/evmeaning.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t evmeaning_notify_error_24___evmeaning(obj_t, obj_t, obj_t);
static obj_t _evmeaning_notify_error_221___evmeaning(obj_t, obj_t, obj_t, obj_t);
extern obj_t exitd_top;
static obj_t toplevel_init_63___evmeaning();
static obj_t _evmeaning___evmeaning(obj_t, obj_t, obj_t);
extern obj_t create_vector(long);
extern obj_t init_the_global_environment__144___evenv();
extern obj_t warning_location_135___error(obj_t, obj_t, obj_t);
static obj_t __dummy_____evmeaning(obj_t, obj_t);
extern obj_t warning___error(obj_t);
static obj_t lambda1398___evmeaning(obj_t, obj_t);
static obj_t lambda1388___evmeaning(obj_t, obj_t);
static obj_t lambda1380___evmeaning(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1370___evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1365___evmeaning(obj_t, obj_t, obj_t);
static obj_t lambda1362___evmeaning(obj_t, obj_t);
static obj_t lambda1354___evmeaning(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1350___evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1345___evmeaning(obj_t, obj_t, obj_t);
static obj_t lambda1343___evmeaning(obj_t, obj_t);
extern obj_t evmeaning_reset_error__111___evmeaning();
static obj_t lambda1333___evmeaning(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1327___evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1323___evmeaning(obj_t, obj_t, obj_t);
static obj_t _evmeaning_reset_error__115___evmeaning(obj_t);
static obj_t lambda1320___evmeaning(obj_t, obj_t);
static obj_t lambda1316___evmeaning(obj_t);
static obj_t lambda1309___evmeaning(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1298___evmeaning(obj_t, obj_t);
static obj_t lambda1297___evmeaning(obj_t);
static obj_t lambda1303___evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t lambda1300___evmeaning(obj_t, obj_t, obj_t);
extern obj_t evmeaning___evmeaning(obj_t, obj_t);
extern obj_t eval_lookup_172___evenv(obj_t);
static obj_t handling_function1135___evmeaning(obj_t, obj_t);
static obj_t handling_function1128___evmeaning(obj_t, obj_t);
extern obj_t eval_apply(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___evmeaning(long, char *);
extern obj_t module_initialization_70___evcompile(long, char *);
extern obj_t module_initialization_70___type(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___progn(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t error_location_file_107___error(obj_t, obj_t);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern obj_t bind_eval_global__246___evenv(obj_t, obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t evmeaning_error_137___evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t _loop____evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t _loop__1639___evmeaning(obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___evmeaning();
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114___evmeaning = BUNSPEC;
extern obj_t eval_funcall_4(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t eval_funcall_3(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t eval_funcall_2(obj_t, obj_t, obj_t, obj_t);
extern obj_t eval_funcall_1(obj_t, obj_t, obj_t);
extern obj_t eval_funcall_0(obj_t, obj_t);
static obj_t evmeaning_warning_75___evmeaning(obj_t, obj_t);
static obj_t _current_bcode__25___evmeaning = BUNSPEC;
static obj_t symbol1647___evmeaning = BUNSPEC;
static obj_t cnst_init_137___evmeaning();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( evmeaning_env_72___evmeaning, _evmeaning___evmeaning1649, _evmeaning___evmeaning, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( evmeaning_reset_error__env_190___evmeaning, _evmeaning_reset_error__115___evmeaning1650, _evmeaning_reset_error__115___evmeaning, 0L, 0 );
DEFINE_STRING( string1646___evmeaning, string1646___evmeaning1651, "Too few arguments provided", 26 );
DEFINE_STRING( string1645___evmeaning, string1645___evmeaning1652, "Too many arguments provided", 27 );
DEFINE_STRING( string1644___evmeaning, string1644___evmeaning1653, "unknown byte-code", 17 );
DEFINE_STRING( string1643___evmeaning, string1643___evmeaning1654, "evmeaning (internal error)", 26 );
DEFINE_STRING( string1642___evmeaning, string1642___evmeaning1655, "redefinition of variable -- ", 28 );
DEFINE_STRING( string1641___evmeaning, string1641___evmeaning1656, "Unbound variable", 16 );
DEFINE_STRING( string1640___evmeaning, string1640___evmeaning1657, "eval", 4 );
DEFINE_EXPORT_PROCEDURE( evmeaning_notify_error_env_6___evmeaning, _evmeaning_notify_error_221___evmeaning1658, _evmeaning_notify_error_221___evmeaning, 0L, 3 );


/* module-initialization */obj_t module_initialization_70___evmeaning(long checksum_2483, char * from_2484)
{
if(CBOOL(require_initialization_114___evmeaning)){
require_initialization_114___evmeaning = BBOOL(((bool_t)0));
cnst_init_137___evmeaning();
imported_modules_init_94___evmeaning();
toplevel_init_63___evmeaning();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___evmeaning()
{
return (symbol1647___evmeaning = string_to_symbol("AT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___evmeaning()
{
_current_bcode__25___evmeaning = BFALSE;
return init_the_global_environment__144___evenv();
}


/* evmeaning */obj_t evmeaning___evmeaning(obj_t exp_1, obj_t stack_2)
{
evmeaning___evmeaning:
if(VECTORP(exp_1)){
_current_bcode__25___evmeaning = exp_1;
{
obj_t aux1010_334;
aux1010_334 = VECTOR_REF(exp_1, ((long)0));
if(INTEGERP(aux1010_334)){
switch ((long)CINT(aux1010_334)){
case ((long)-2) : 
{
obj_t aux_2508;
obj_t aux_2502;
obj_t aux_2498;
{
obj_t aux_2509;
{
obj_t aux_2510;
{
obj_t aux_2511;
aux_2511 = VECTOR_REF(exp_1, ((long)2));
aux_2510 = CDR(aux_2511);
}
aux_2509 = CDR(aux_2510);
}
aux_2508 = CAR(aux_2509);
}
{
obj_t aux_2503;
{
obj_t aux_2504;
aux_2504 = VECTOR_REF(exp_1, ((long)2));
aux_2503 = CDR(aux_2504);
}
aux_2502 = CAR(aux_2503);
}
{
obj_t aux_2499;
aux_2499 = VECTOR_REF(exp_1, ((long)2));
aux_2498 = CAR(aux_2499);
}
return evmeaning_error_137___evmeaning(exp_1, aux_2498, aux_2502, aux_2508);
}
break;
case ((long)-1) : 
return VECTOR_REF(exp_1, ((long)2));
break;
case ((long)0) : 
return CAR(stack_2);
break;
case ((long)1) : 
{
obj_t aux_2519;
aux_2519 = CDR(stack_2);
return CAR(aux_2519);
}
break;
case ((long)2) : 
{
obj_t aux_2522;
{
obj_t aux_2523;
aux_2523 = CDR(stack_2);
aux_2522 = CDR(aux_2523);
}
return CAR(aux_2522);
}
break;
case ((long)3) : 
{
obj_t aux_2527;
{
obj_t aux_2528;
{
obj_t aux_2529;
aux_2529 = CDR(stack_2);
aux_2528 = CDR(aux_2529);
}
aux_2527 = CDR(aux_2528);
}
return CAR(aux_2527);
}
break;
case ((long)4) : 
{
obj_t offset_342;
offset_342 = VECTOR_REF(exp_1, ((long)2));
{
long i_1153;
obj_t env_1154;
i_1153 = ((long)4);
{
obj_t aux_2544;
{
obj_t aux_2545;
{
obj_t aux_2546;
aux_2546 = CDR(stack_2);
aux_2545 = CDR(aux_2546);
}
aux_2544 = CDR(aux_2545);
}
env_1154 = CDR(aux_2544);
}
do_loop__1011_191_1152:
{
bool_t test_2535;
{
long aux_2536;
aux_2536 = (long)CINT(offset_342);
test_2535 = (i_1153==aux_2536);
}
if(test_2535){
return CAR(env_1154);
}
 else {
{
obj_t env_2542;
long i_2540;
i_2540 = (i_1153+((long)1));
env_2542 = CDR(env_1154);
env_1154 = env_2542;
i_1153 = i_2540;
goto do_loop__1011_191_1152;
}
}
}
}
}
break;
case ((long)5) : 
{
obj_t aux_2551;
{
obj_t aux_2552;
aux_2552 = VECTOR_REF(exp_1, ((long)2));
aux_2551 = VECTOR_REF(aux_2552, ((long)2));
}
return __EVMEANING_ADDRESS_REF(aux_2551);
}
break;
case ((long)6) : 
{
obj_t aux_2556;
aux_2556 = VECTOR_REF(exp_1, ((long)2));
return VECTOR_REF(aux_2556, ((long)2));
}
break;
case ((long)7) : 
{
obj_t name_356;
name_356 = VECTOR_REF(exp_1, ((long)2));
{
obj_t global_357;
global_357 = eval_lookup_172___evenv(name_356);
{
{
bool_t test_2561;
if(VECTORP(global_357)){
long aux_2564;
aux_2564 = VECTOR_LENGTH(global_357);
test_2561 = (aux_2564==((long)3));
}
 else {
test_2561 = ((bool_t)0);
}
if(test_2561){
{
obj_t aux_2567;
aux_2567 = BINT(((long)6));
VECTOR_SET(exp_1, ((long)0), aux_2567);
}
VECTOR_SET(exp_1, ((long)2), global_357);
return VECTOR_REF(global_357, ((long)2));
}
 else {
return evmeaning_error_137___evmeaning(exp_1, string1640___evmeaning, string1641___evmeaning, name_356);
}
}
}
}
}
break;
case ((long)8) : 
{
obj_t var_359;
obj_t val_360;
{
obj_t aux_2573;
aux_2573 = VECTOR_REF(exp_1, ((long)2));
var_359 = CAR(aux_2573);
}
{
obj_t aux_2576;
{
obj_t aux_2577;
aux_2577 = VECTOR_REF(exp_1, ((long)2));
aux_2576 = CDR(aux_2577);
}
val_360 = evmeaning___evmeaning(aux_2576, stack_2);
}
{
bool_t test_2581;
{
obj_t aux_2584;
obj_t aux_2582;
aux_2584 = BINT(((long)1));
aux_2582 = VECTOR_REF(var_359, ((long)0));
test_2581 = (aux_2582==aux_2584);
}
if(test_2581){
obj_t aux_2587;
aux_2587 = VECTOR_REF(var_359, ((long)2));
__EVMEANING_ADDRESS_SET(aux_2587, val_360);
}
 else {
VECTOR_SET(var_359, ((long)2), val_360);
}
}
VECTOR_REF(var_359, ((long)1));
return BUNSPEC;
}
break;
case ((long)9) : 
{
obj_t name_364;
{
obj_t aux_2592;
aux_2592 = VECTOR_REF(exp_1, ((long)2));
name_364 = CAR(aux_2592);
}
{
obj_t value_365;
{
obj_t aux_2595;
aux_2595 = VECTOR_REF(exp_1, ((long)2));
value_365 = CDR(aux_2595);
}
{
obj_t global_366;
global_366 = eval_lookup_172___evenv(name_364);
{
{
bool_t test_2599;
if(VECTORP(global_366)){
long aux_2602;
aux_2602 = VECTOR_LENGTH(global_366);
test_2599 = (aux_2602==((long)3));
}
 else {
test_2599 = ((bool_t)0);
}
if(test_2599){
{
obj_t aux_2605;
aux_2605 = BINT(((long)8));
VECTOR_SET(exp_1, ((long)0), aux_2605);
}
{
obj_t arg1060_369;
arg1060_369 = MAKE_PAIR(global_366, value_365);
VECTOR_SET(exp_1, ((long)2), arg1060_369);
}
{
goto evmeaning___evmeaning;
}
}
 else {
return evmeaning_error_137___evmeaning(exp_1, string1640___evmeaning, string1641___evmeaning, name_364);
}
}
}
}
}
}
break;
case ((long)10) : 
{
obj_t arg1063_372;
arg1063_372 = evmeaning___evmeaning(VECTOR_REF(exp_1, ((long)2)), stack_2);
SET_CAR(stack_2, arg1063_372);
}
return BUNSPEC;
break;
case ((long)11) : 
{
obj_t arg1066_374;
obj_t arg1067_375;
arg1066_374 = CDR(stack_2);
arg1067_375 = evmeaning___evmeaning(VECTOR_REF(exp_1, ((long)2)), stack_2);
SET_CAR(arg1066_374, arg1067_375);
}
return BUNSPEC;
break;
case ((long)12) : 
{
obj_t arg1069_377;
obj_t arg1070_378;
{
obj_t aux_2618;
aux_2618 = CDR(stack_2);
arg1069_377 = CDR(aux_2618);
}
arg1070_378 = evmeaning___evmeaning(VECTOR_REF(exp_1, ((long)2)), stack_2);
SET_CAR(arg1069_377, arg1070_378);
}
return BUNSPEC;
break;
case ((long)13) : 
{
obj_t arg1073_380;
obj_t arg1076_381;
{
obj_t aux_2624;
{
obj_t aux_2625;
aux_2625 = CDR(stack_2);
aux_2624 = CDR(aux_2625);
}
arg1073_380 = CDR(aux_2624);
}
arg1076_381 = evmeaning___evmeaning(VECTOR_REF(exp_1, ((long)2)), stack_2);
SET_CAR(arg1073_380, arg1076_381);
}
return BUNSPEC;
break;
case ((long)14) : 
{
obj_t offset_383;
obj_t value_384;
{
obj_t aux_2632;
aux_2632 = VECTOR_REF(exp_1, ((long)2));
offset_383 = CAR(aux_2632);
}
{
obj_t aux_2635;
{
obj_t aux_2636;
aux_2636 = VECTOR_REF(exp_1, ((long)2));
aux_2635 = CDR(aux_2636);
}
value_384 = evmeaning___evmeaning(aux_2635, stack_2);
}
{
long i_1313;
obj_t env_1314;
i_1313 = ((long)4);
{
obj_t aux_2649;
{
obj_t aux_2650;
{
obj_t aux_2651;
aux_2651 = CDR(stack_2);
aux_2650 = CDR(aux_2651);
}
aux_2649 = CDR(aux_2650);
}
env_1314 = CDR(aux_2649);
}
do_loop__1012_232_1312:
{
bool_t test_2640;
{
long aux_2641;
aux_2641 = (long)CINT(offset_383);
test_2640 = (i_1313==aux_2641);
}
if(test_2640){
SET_CAR(env_1314, value_384);
}
 else {
{
obj_t env_2647;
long i_2645;
i_2645 = (i_1313+((long)1));
env_2647 = CDR(env_1314);
env_1314 = env_2647;
i_1313 = i_2645;
goto do_loop__1012_232_1312;
}
}
}
}
return BUNSPEC;
}
break;
case ((long)15) : 
{
obj_t value_398;
value_398 = VECTOR_REF(exp_1, ((long)2));
{
bool_t test1087_399;
{
obj_t aux_2657;
aux_2657 = evmeaning___evmeaning(VECTOR_REF(value_398, ((long)0)), stack_2);
test1087_399 = CBOOL(aux_2657);
}
if(test1087_399){
obj_t exp_2662;
exp_2662 = VECTOR_REF(value_398, ((long)1));
exp_1 = exp_2662;
goto evmeaning___evmeaning;
}
 else {
obj_t exp_2664;
exp_2664 = VECTOR_REF(value_398, ((long)2));
exp_1 = exp_2664;
goto evmeaning___evmeaning;
}
}
}
break;
case ((long)16) : 
{
obj_t exps_403;
exps_403 = VECTOR_REF(exp_1, ((long)2));
{
long len_404;
{
long aux_2667;
aux_2667 = VECTOR_LENGTH(exps_403);
len_404 = (aux_2667-((long)1));
}
{
if((len_404==((long)0))){
return BUNSPEC;
}
 else {
long i_406;
i_406 = ((long)0);
loop_407:
if((i_406==len_404)){
obj_t exp_2674;
exp_2674 = VECTOR_REF(exps_403, i_406);
exp_1 = exp_2674;
goto evmeaning___evmeaning;
}
 else {
evmeaning___evmeaning(VECTOR_REF(exps_403, i_406), stack_2);
{
long i_2678;
i_2678 = (i_406+((long)1));
i_406 = i_2678;
goto loop_407;
}
}
}
}
}
}
break;
case ((long)17) : 
{
obj_t var_414;
obj_t val_415;
{
obj_t aux_2680;
aux_2680 = VECTOR_REF(exp_1, ((long)2));
var_414 = CAR(aux_2680);
}
{
obj_t aux_2683;
aux_2683 = VECTOR_REF(exp_1, ((long)2));
val_415 = CDR(aux_2683);
}
{
obj_t cell_416;
cell_416 = eval_lookup_172___evenv(var_414);
{
bool_t test_2687;
if(VECTORP(cell_416)){
long aux_2690;
aux_2690 = VECTOR_LENGTH(cell_416);
test_2687 = (aux_2690==((long)3));
}
 else {
test_2687 = ((bool_t)0);
}
if(test_2687){
{
obj_t list1099_418;
{
obj_t arg1101_420;
{
obj_t arg1102_421;
{
obj_t arg1104_423;
arg1104_423 = MAKE_PAIR(var_414, BNIL);
arg1102_421 = MAKE_PAIR(string1642___evmeaning, arg1104_423);
}
{
obj_t aux_2695;
aux_2695 = BCHAR(((unsigned char)'\n'));
arg1101_420 = MAKE_PAIR(aux_2695, arg1102_421);
}
}
list1099_418 = MAKE_PAIR(string1640___evmeaning, arg1101_420);
}
evmeaning_warning_75___evmeaning(exp_1, list1099_418);
}
{
obj_t arg1106_425;
{
obj_t arg1107_426;
arg1107_426 = PROCEDURE_ENTRY(val_415)(val_415, BEOA);
arg1106_425 = evmeaning___evmeaning(arg1107_426, BNIL);
}
{
bool_t test_2703;
{
obj_t aux_2706;
obj_t aux_2704;
aux_2706 = BINT(((long)1));
aux_2704 = VECTOR_REF(cell_416, ((long)0));
test_2703 = (aux_2704==aux_2706);
}
if(test_2703){
obj_t aux_2709;
aux_2709 = VECTOR_REF(cell_416, ((long)2));
__EVMEANING_ADDRESS_SET(aux_2709, arg1106_425);
}
 else {
VECTOR_SET(cell_416, ((long)2), arg1106_425);
}
}
VECTOR_REF(cell_416, ((long)1));
}
}
 else {
obj_t cell_428;
{
obj_t v1013_432;
v1013_432 = create_vector(((long)3));
VECTOR_SET(v1013_432, ((long)2), BUNSPEC);
VECTOR_SET(v1013_432, ((long)1), var_414);
{
obj_t aux_2717;
aux_2717 = BINT(((long)0));
VECTOR_SET(v1013_432, ((long)0), aux_2717);
}
cell_428 = v1013_432;
}
bind_eval_global__246___evenv(var_414, cell_428);
{
obj_t value_429;
{
obj_t arg1109_430;
arg1109_430 = PROCEDURE_ENTRY(val_415)(val_415, BEOA);
value_429 = evmeaning___evmeaning(arg1109_430, BNIL);
}
VECTOR_SET(cell_428, ((long)2), value_429);
}
}
}
return var_414;
}
}
break;
case ((long)63) : 
{
obj_t var_437;
{
obj_t aux_2725;
aux_2725 = VECTOR_REF(exp_1, ((long)2));
var_437 = CAR(aux_2725);
}
{
obj_t value_439;
{
obj_t aux_2728;
{
obj_t aux_2729;
aux_2729 = VECTOR_REF(exp_1, ((long)2));
aux_2728 = CDR(aux_2729);
}
value_439 = evmeaning___evmeaning(aux_2728, BNIL);
}
{
{
obj_t cell_440;
cell_440 = eval_lookup_172___evenv(var_437);
{
bool_t test_2734;
if(VECTORP(cell_440)){
long aux_2737;
aux_2737 = VECTOR_LENGTH(cell_440);
test_2734 = (aux_2737==((long)3));
}
 else {
test_2734 = ((bool_t)0);
}
if(test_2734){
{
obj_t list1116_442;
{
obj_t arg1118_444;
{
obj_t arg1119_445;
{
obj_t arg1121_447;
arg1121_447 = MAKE_PAIR(var_437, BNIL);
arg1119_445 = MAKE_PAIR(string1642___evmeaning, arg1121_447);
}
{
obj_t aux_2742;
aux_2742 = BCHAR(((unsigned char)'\n'));
arg1118_444 = MAKE_PAIR(aux_2742, arg1119_445);
}
}
list1116_442 = MAKE_PAIR(string1640___evmeaning, arg1118_444);
}
evmeaning_warning_75___evmeaning(exp_1, list1116_442);
}
{
bool_t test_2747;
{
obj_t aux_2750;
obj_t aux_2748;
aux_2750 = BINT(((long)1));
aux_2748 = VECTOR_REF(cell_440, ((long)0));
test_2747 = (aux_2748==aux_2750);
}
if(test_2747){
obj_t aux_2753;
aux_2753 = VECTOR_REF(cell_440, ((long)2));
__EVMEANING_ADDRESS_SET(aux_2753, value_439);
}
 else {
VECTOR_SET(cell_440, ((long)2), value_439);
}
}
VECTOR_REF(cell_440, ((long)1));
}
 else {
obj_t cell_449;
{
obj_t v1014_450;
v1014_450 = create_vector(((long)3));
VECTOR_SET(v1014_450, ((long)2), BUNSPEC);
VECTOR_SET(v1014_450, ((long)1), var_437);
{
obj_t aux_2761;
aux_2761 = BINT(((long)0));
VECTOR_SET(v1014_450, ((long)0), aux_2761);
}
cell_449 = v1014_450;
}
bind_eval_global__246___evenv(var_437, cell_449);
VECTOR_SET(cell_449, ((long)2), value_439);
}
}
return var_437;
}
}
}
}
break;
case ((long)18) : 
return handling_function1128___evmeaning(stack_2, exp_1);
break;
case ((long)64) : 
{
obj_t protect_466;
{
obj_t aux_2767;
aux_2767 = VECTOR_REF(exp_1, ((long)2));
protect_466 = CDR(aux_2767);
}
{
obj_t val1019_467;
{
obj_t aux_2770;
{
obj_t aux_2771;
aux_2771 = VECTOR_REF(exp_1, ((long)2));
aux_2770 = CAR(aux_2771);
}
val1019_467 = handling_function1135___evmeaning(stack_2, aux_2770);
}
evmeaning___evmeaning(protect_466, stack_2);
{
bool_t test1132_468;
{
obj_t aux_2776;
aux_2776 = val_from_exit__100___bexit(val1019_467);
test1132_468 = CBOOL(aux_2776);
}
if(test1132_468){
return unwind_until__178___bexit(CAR(val1019_467), CDR(val1019_467));
}
 else {
return val1019_467;
}
}
}
}
break;
case ((long)19) : 
{
obj_t value_476;
value_476 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_477;
name_477 = VECTOR_REF(value_476, ((long)0));
{
obj_t fun_478;
{
obj_t aux_2785;
{
obj_t aux_2786;
aux_2786 = VECTOR_REF(value_476, ((long)1));
aux_2785 = VECTOR_REF(aux_2786, ((long)2));
}
fun_478 = __EVMEANING_ADDRESS_REF(aux_2785);
}
{
return eval_funcall_0(name_477, fun_478);
}
}
}
}
break;
case ((long)57) : 
{
obj_t value_481;
value_481 = VECTOR_REF(exp_1, ((long)2));
{
{
obj_t aux_2794;
obj_t aux_2792;
{
obj_t aux_2795;
aux_2795 = VECTOR_REF(value_481, ((long)1));
aux_2794 = VECTOR_REF(aux_2795, ((long)2));
}
aux_2792 = VECTOR_REF(value_481, ((long)0));
return eval_funcall_0(aux_2792, aux_2794);
}
}
}
break;
case ((long)20) : 
{
obj_t value_485;
value_485 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_486;
name_486 = VECTOR_REF(value_485, ((long)0));
{
obj_t fun_487;
{
obj_t aux_2801;
{
obj_t aux_2802;
aux_2802 = VECTOR_REF(value_485, ((long)1));
aux_2801 = VECTOR_REF(aux_2802, ((long)2));
}
fun_487 = __EVMEANING_ADDRESS_REF(aux_2801);
}
{
{
obj_t arg1142_488;
arg1142_488 = evmeaning___evmeaning(VECTOR_REF(value_485, ((long)2)), stack_2);
return eval_funcall_1(name_486, fun_487, arg1142_488);
}
}
}
}
}
break;
case ((long)58) : 
{
obj_t value_492;
value_492 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_493;
name_493 = VECTOR_REF(value_492, ((long)0));
{
obj_t fun_494;
{
obj_t aux_2811;
aux_2811 = VECTOR_REF(value_492, ((long)1));
fun_494 = VECTOR_REF(aux_2811, ((long)2));
}
{
{
obj_t arg1146_495;
arg1146_495 = evmeaning___evmeaning(VECTOR_REF(value_492, ((long)2)), stack_2);
return eval_funcall_1(name_493, fun_494, arg1146_495);
}
}
}
}
}
break;
case ((long)21) : 
{
obj_t value_498;
value_498 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_499;
name_499 = VECTOR_REF(value_498, ((long)0));
{
obj_t fun_500;
{
obj_t aux_2819;
{
obj_t aux_2820;
aux_2820 = VECTOR_REF(value_498, ((long)1));
aux_2819 = VECTOR_REF(aux_2820, ((long)2));
}
fun_500 = __EVMEANING_ADDRESS_REF(aux_2819);
}
{
{
obj_t arg1150_501;
obj_t arg1151_502;
arg1150_501 = evmeaning___evmeaning(VECTOR_REF(value_498, ((long)2)), stack_2);
arg1151_502 = evmeaning___evmeaning(VECTOR_REF(value_498, ((long)3)), stack_2);
return eval_funcall_2(name_499, fun_500, arg1150_501, arg1151_502);
}
}
}
}
}
break;
case ((long)59) : 
{
obj_t value_507;
value_507 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_508;
name_508 = VECTOR_REF(value_507, ((long)0));
{
obj_t fun_509;
{
obj_t aux_2831;
aux_2831 = VECTOR_REF(value_507, ((long)1));
fun_509 = VECTOR_REF(aux_2831, ((long)2));
}
{
{
obj_t arg1156_510;
obj_t arg1157_511;
arg1156_510 = evmeaning___evmeaning(VECTOR_REF(value_507, ((long)2)), stack_2);
arg1157_511 = evmeaning___evmeaning(VECTOR_REF(value_507, ((long)3)), stack_2);
return eval_funcall_2(name_508, fun_509, arg1156_510, arg1157_511);
}
}
}
}
}
break;
case ((long)22) : 
{
obj_t value_515;
value_515 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_516;
name_516 = VECTOR_REF(value_515, ((long)0));
{
obj_t fun_517;
{
obj_t aux_2841;
{
obj_t aux_2842;
aux_2842 = VECTOR_REF(value_515, ((long)1));
aux_2841 = VECTOR_REF(aux_2842, ((long)2));
}
fun_517 = __EVMEANING_ADDRESS_REF(aux_2841);
}
{
{
obj_t arg1162_518;
obj_t arg1163_519;
obj_t arg1164_520;
arg1162_518 = evmeaning___evmeaning(VECTOR_REF(value_515, ((long)2)), stack_2);
arg1163_519 = evmeaning___evmeaning(VECTOR_REF(value_515, ((long)3)), stack_2);
arg1164_520 = evmeaning___evmeaning(VECTOR_REF(value_515, ((long)4)), stack_2);
return eval_funcall_3(name_516, fun_517, arg1162_518, arg1163_519, arg1164_520);
}
}
}
}
}
break;
case ((long)60) : 
{
obj_t value_526;
value_526 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_527;
name_527 = VECTOR_REF(value_526, ((long)0));
{
obj_t fun_528;
{
obj_t aux_2855;
aux_2855 = VECTOR_REF(value_526, ((long)1));
fun_528 = VECTOR_REF(aux_2855, ((long)2));
}
{
{
obj_t arg1170_529;
obj_t arg1171_530;
obj_t arg1172_531;
arg1170_529 = evmeaning___evmeaning(VECTOR_REF(value_526, ((long)2)), stack_2);
arg1171_530 = evmeaning___evmeaning(VECTOR_REF(value_526, ((long)3)), stack_2);
arg1172_531 = evmeaning___evmeaning(VECTOR_REF(value_526, ((long)4)), stack_2);
return eval_funcall_3(name_527, fun_528, arg1170_529, arg1171_530, arg1172_531);
}
}
}
}
}
break;
case ((long)23) : 
{
obj_t value_536;
value_536 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_537;
name_537 = VECTOR_REF(value_536, ((long)0));
{
obj_t fun_538;
{
obj_t aux_2867;
{
obj_t aux_2868;
aux_2868 = VECTOR_REF(value_536, ((long)1));
aux_2867 = VECTOR_REF(aux_2868, ((long)2));
}
fun_538 = __EVMEANING_ADDRESS_REF(aux_2867);
}
{
{
obj_t arg1177_539;
obj_t arg1178_540;
obj_t arg1179_541;
obj_t arg1180_542;
arg1177_539 = evmeaning___evmeaning(VECTOR_REF(value_536, ((long)2)), stack_2);
arg1178_540 = evmeaning___evmeaning(VECTOR_REF(value_536, ((long)3)), stack_2);
arg1179_541 = evmeaning___evmeaning(VECTOR_REF(value_536, ((long)4)), stack_2);
arg1180_542 = evmeaning___evmeaning(VECTOR_REF(value_536, ((long)5)), stack_2);
return eval_funcall_4(name_537, fun_538, arg1177_539, arg1178_540, arg1179_541, arg1180_542);
}
}
}
}
}
break;
case ((long)61) : 
{
obj_t value_549;
value_549 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_550;
name_550 = VECTOR_REF(value_549, ((long)0));
{
obj_t fun_551;
{
obj_t aux_2883;
aux_2883 = VECTOR_REF(value_549, ((long)1));
fun_551 = VECTOR_REF(aux_2883, ((long)2));
}
{
{
obj_t arg1187_552;
obj_t arg1188_553;
obj_t arg1189_554;
obj_t arg1190_555;
arg1187_552 = evmeaning___evmeaning(VECTOR_REF(value_549, ((long)2)), stack_2);
arg1188_553 = evmeaning___evmeaning(VECTOR_REF(value_549, ((long)3)), stack_2);
arg1189_554 = evmeaning___evmeaning(VECTOR_REF(value_549, ((long)4)), stack_2);
arg1190_555 = evmeaning___evmeaning(VECTOR_REF(value_549, ((long)5)), stack_2);
return eval_funcall_4(name_550, fun_551, arg1187_552, arg1188_553, arg1189_554, arg1190_555);
}
}
}
}
}
break;
case ((long)24) : 
{
obj_t value_561;
value_561 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_562;
name_562 = VECTOR_REF(value_561, ((long)0));
{
obj_t fun_563;
{
obj_t aux_2897;
{
obj_t aux_2898;
aux_2898 = VECTOR_REF(value_561, ((long)1));
aux_2897 = VECTOR_REF(aux_2898, ((long)2));
}
fun_563 = __EVMEANING_ADDRESS_REF(aux_2897);
}
{
{
obj_t arg1196_565;
{
obj_t args_1630;
obj_t res_1631;
args_1630 = VECTOR_REF(value_561, ((long)2));
res_1631 = BNIL;
loop_1629:
if(NULLP(args_1630)){
arg1196_565 = reverse__39___r4_pairs_and_lists_6_3(res_1631);
}
 else {
obj_t arg1199_1638;
obj_t arg1200_1639;
arg1199_1638 = CDR(args_1630);
{
obj_t arg1201_1640;
arg1201_1640 = evmeaning___evmeaning(CAR(args_1630), stack_2);
arg1200_1639 = MAKE_PAIR(arg1201_1640, res_1631);
}
{
obj_t res_2910;
obj_t args_2909;
args_2909 = arg1199_1638;
res_2910 = arg1200_1639;
res_1631 = res_2910;
args_1630 = args_2909;
goto loop_1629;
}
}
}
return eval_apply(name_562, fun_563, arg1196_565);
}
}
}
}
}
break;
case ((long)62) : 
{
obj_t value_577;
value_577 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_578;
name_578 = VECTOR_REF(value_577, ((long)0));
{
obj_t fun_579;
{
obj_t aux_2915;
aux_2915 = VECTOR_REF(value_577, ((long)1));
fun_579 = VECTOR_REF(aux_2915, ((long)2));
}
{
{
obj_t arg1205_581;
{
obj_t args_1681;
obj_t res_1682;
args_1681 = VECTOR_REF(value_577, ((long)2));
res_1682 = BNIL;
loop_1680:
if(NULLP(args_1681)){
arg1205_581 = reverse__39___r4_pairs_and_lists_6_3(res_1682);
}
 else {
obj_t arg1209_1689;
obj_t arg1210_1690;
arg1209_1689 = CDR(args_1681);
{
obj_t arg1211_1691;
arg1211_1691 = evmeaning___evmeaning(CAR(args_1681), stack_2);
arg1210_1690 = MAKE_PAIR(arg1211_1691, res_1682);
}
{
obj_t res_2926;
obj_t args_2925;
args_2925 = arg1209_1689;
res_2926 = arg1210_1690;
res_1682 = res_2926;
args_1681 = args_2925;
goto loop_1680;
}
}
}
return eval_apply(name_578, fun_579, arg1205_581);
}
}
}
}
}
break;
case ((long)25) : 
{
obj_t fun1215_592;
fun1215_592 = VECTOR_REF(exp_1, ((long)2));
return PROCEDURE_ENTRY(fun1215_592)(fun1215_592, BEOA);
}
break;
case ((long)26) : 
{
obj_t value_593;
value_593 = VECTOR_REF(exp_1, ((long)2));
{
obj_t fun_594;
fun_594 = VECTOR_REF(value_593, ((long)0));
{
{
obj_t arg1216_595;
arg1216_595 = evmeaning___evmeaning(VECTOR_REF(value_593, ((long)1)), stack_2);
return PROCEDURE_ENTRY(fun_594)(fun_594, arg1216_595, BEOA);
}
}
}
}
break;
case ((long)27) : 
{
obj_t value_597;
value_597 = VECTOR_REF(exp_1, ((long)2));
{
obj_t fun_598;
fun_598 = VECTOR_REF(value_597, ((long)0));
{
{
obj_t arg1220_599;
obj_t arg1221_600;
arg1220_599 = evmeaning___evmeaning(VECTOR_REF(value_597, ((long)1)), stack_2);
arg1221_600 = evmeaning___evmeaning(VECTOR_REF(value_597, ((long)2)), stack_2);
return PROCEDURE_ENTRY(fun_598)(fun_598, arg1220_599, arg1221_600, BEOA);
}
}
}
}
break;
case ((long)28) : 
{
obj_t value_603;
value_603 = VECTOR_REF(exp_1, ((long)2));
{
obj_t fun_604;
fun_604 = VECTOR_REF(value_603, ((long)0));
{
{
obj_t arg1225_605;
obj_t arg1226_606;
obj_t arg1228_607;
arg1225_605 = evmeaning___evmeaning(VECTOR_REF(value_603, ((long)1)), stack_2);
arg1226_606 = evmeaning___evmeaning(VECTOR_REF(value_603, ((long)2)), stack_2);
arg1228_607 = evmeaning___evmeaning(VECTOR_REF(value_603, ((long)3)), stack_2);
return PROCEDURE_ENTRY(fun_604)(fun_604, arg1225_605, arg1226_606, arg1228_607, BEOA);
}
}
}
}
break;
case ((long)29) : 
{
obj_t value_611;
value_611 = VECTOR_REF(exp_1, ((long)2));
{
obj_t fun_612;
fun_612 = VECTOR_REF(value_611, ((long)0));
{
{
obj_t arg1234_613;
obj_t arg1235_614;
obj_t arg1236_615;
obj_t arg1238_616;
arg1234_613 = evmeaning___evmeaning(VECTOR_REF(value_611, ((long)1)), stack_2);
arg1235_614 = evmeaning___evmeaning(VECTOR_REF(value_611, ((long)2)), stack_2);
arg1236_615 = evmeaning___evmeaning(VECTOR_REF(value_611, ((long)3)), stack_2);
arg1238_616 = evmeaning___evmeaning(VECTOR_REF(value_611, ((long)4)), stack_2);
return PROCEDURE_ENTRY(fun_612)(fun_612, arg1234_613, arg1235_614, arg1236_615, arg1238_616, BEOA);
}
}
}
}
break;
case ((long)30) : 
{
obj_t value_621;
value_621 = VECTOR_REF(exp_1, ((long)2));
{
obj_t aux_2969;
{
obj_t l1022_622;
l1022_622 = CDR(value_621);
if(NULLP(l1022_622)){
aux_2969 = BNIL;
}
 else {
obj_t head1024_624;
head1024_624 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1022_1766;
obj_t tail1025_1767;
l1022_1766 = l1022_622;
tail1025_1767 = head1024_624;
lname1023_1765:
if(NULLP(l1022_1766)){
aux_2969 = CDR(head1024_624);
}
 else {
obj_t newtail1026_1775;
{
obj_t arg1248_1776;
arg1248_1776 = evmeaning___evmeaning(CAR(l1022_1766), stack_2);
newtail1026_1775 = MAKE_PAIR(arg1248_1776, BNIL);
}
SET_CDR(tail1025_1767, newtail1026_1775);
{
obj_t tail1025_2983;
obj_t l1022_2981;
l1022_2981 = CDR(l1022_1766);
tail1025_2983 = newtail1026_1775;
tail1025_1767 = tail1025_2983;
l1022_1766 = l1022_2981;
goto lname1023_1765;
}
}
}
}
}
return apply(CAR(value_621), aux_2969);
}
}
break;
case ((long)31) : 
{
obj_t value_636;
value_636 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_637;
name_637 = CAR(value_636);
{
obj_t fun_638;
fun_638 = evmeaning___evmeaning(CDR(value_636), stack_2);
{
return eval_funcall_0(name_637, fun_638);
}
}
}
}
break;
case ((long)32) : 
{
obj_t value_640;
value_640 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_641;
name_641 = VECTOR_REF(value_640, ((long)0));
{
obj_t fun_642;
fun_642 = evmeaning___evmeaning(VECTOR_REF(value_640, ((long)1)), stack_2);
{
{
obj_t arg1254_643;
arg1254_643 = evmeaning___evmeaning(VECTOR_REF(value_640, ((long)2)), stack_2);
return eval_funcall_1(name_641, fun_642, arg1254_643);
}
}
}
}
}
break;
case ((long)33) : 
{
obj_t value_646;
value_646 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_647;
name_647 = VECTOR_REF(value_646, ((long)0));
{
obj_t fun_648;
fun_648 = evmeaning___evmeaning(VECTOR_REF(value_646, ((long)1)), stack_2);
{
{
obj_t arg1257_649;
obj_t arg1258_650;
arg1257_649 = evmeaning___evmeaning(VECTOR_REF(value_646, ((long)2)), stack_2);
arg1258_650 = evmeaning___evmeaning(VECTOR_REF(value_646, ((long)3)), stack_2);
return eval_funcall_2(name_647, fun_648, arg1257_649, arg1258_650);
}
}
}
}
}
break;
case ((long)34) : 
{
obj_t value_654;
value_654 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_655;
name_655 = VECTOR_REF(value_654, ((long)0));
{
obj_t fun_656;
fun_656 = evmeaning___evmeaning(VECTOR_REF(value_654, ((long)1)), stack_2);
{
{
obj_t arg1263_657;
obj_t arg1265_658;
obj_t arg1267_659;
arg1263_657 = evmeaning___evmeaning(VECTOR_REF(value_654, ((long)2)), stack_2);
arg1265_658 = evmeaning___evmeaning(VECTOR_REF(value_654, ((long)3)), stack_2);
arg1267_659 = evmeaning___evmeaning(VECTOR_REF(value_654, ((long)4)), stack_2);
return eval_funcall_3(name_655, fun_656, arg1263_657, arg1265_658, arg1267_659);
}
}
}
}
}
break;
case ((long)35) : 
{
obj_t value_664;
value_664 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_665;
name_665 = VECTOR_REF(value_664, ((long)0));
{
obj_t fun_666;
fun_666 = evmeaning___evmeaning(VECTOR_REF(value_664, ((long)1)), stack_2);
{
{
obj_t arg1273_667;
obj_t arg1274_668;
obj_t arg1277_669;
obj_t arg1278_670;
arg1273_667 = evmeaning___evmeaning(VECTOR_REF(value_664, ((long)2)), stack_2);
arg1274_668 = evmeaning___evmeaning(VECTOR_REF(value_664, ((long)3)), stack_2);
arg1277_669 = evmeaning___evmeaning(VECTOR_REF(value_664, ((long)4)), stack_2);
arg1278_670 = evmeaning___evmeaning(VECTOR_REF(value_664, ((long)5)), stack_2);
return eval_funcall_4(name_665, fun_666, arg1273_667, arg1274_668, arg1277_669, arg1278_670);
}
}
}
}
}
break;
case ((long)36) : 
{
obj_t value_676;
value_676 = VECTOR_REF(exp_1, ((long)2));
{
obj_t name_677;
name_677 = VECTOR_REF(value_676, ((long)0));
{
obj_t fun_678;
fun_678 = evmeaning___evmeaning(VECTOR_REF(value_676, ((long)1)), stack_2);
{
{
obj_t arg1286_679;
{
obj_t l1027_680;
l1027_680 = VECTOR_REF(value_676, ((long)2));
if(NULLP(l1027_680)){
arg1286_679 = BNIL;
}
 else {
obj_t head1029_682;
head1029_682 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1027_1878;
obj_t tail1030_1879;
l1027_1878 = l1027_680;
tail1030_1879 = head1029_682;
lname1028_1877:
if(NULLP(l1027_1878)){
arg1286_679 = CDR(head1029_682);
}
 else {
obj_t newtail1031_1887;
{
obj_t arg1291_1888;
arg1291_1888 = evmeaning___evmeaning(CAR(l1027_1878), stack_2);
newtail1031_1887 = MAKE_PAIR(arg1291_1888, BNIL);
}
SET_CDR(tail1030_1879, newtail1031_1887);
{
obj_t tail1030_3048;
obj_t l1027_3046;
l1027_3046 = CDR(l1027_1878);
tail1030_3048 = newtail1031_1887;
tail1030_1879 = tail1030_3048;
l1027_1878 = l1027_3046;
goto lname1028_1877;
}
}
}
}
}
return eval_apply(name_677, fun_678, arg1286_679);
}
}
}
}
}
break;
case ((long)37) : 
{
obj_t value_695;
value_695 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_696;
where_696 = CAR(value_695);
{
obj_t body_697;
body_697 = CDR(value_695);
{
{
obj_t lambda1297_2337;
lambda1297_2337 = make_fx_procedure(lambda1297___evmeaning, ((long)0), ((long)3));
PROCEDURE_SET(lambda1297_2337, ((long)0), where_696);
PROCEDURE_SET(lambda1297_2337, ((long)1), body_697);
PROCEDURE_SET(lambda1297_2337, ((long)2), stack_2);
return lambda1297_2337;
}
}
}
}
}
break;
case ((long)38) : 
{
obj_t value_701;
value_701 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_702;
where_702 = CAR(value_701);
{
obj_t body_703;
body_703 = CDR(value_701);
{
{
obj_t lambda1298_2336;
lambda1298_2336 = make_fx_procedure(lambda1298___evmeaning, ((long)1), ((long)3));
PROCEDURE_SET(lambda1298_2336, ((long)0), where_702);
PROCEDURE_SET(lambda1298_2336, ((long)1), stack_2);
PROCEDURE_SET(lambda1298_2336, ((long)2), body_703);
return lambda1298_2336;
}
}
}
}
}
break;
case ((long)39) : 
{
obj_t value_709;
value_709 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_710;
where_710 = CAR(value_709);
{
obj_t body_711;
body_711 = CDR(value_709);
{
{
obj_t lambda1300_2335;
lambda1300_2335 = make_fx_procedure(lambda1300___evmeaning, ((long)2), ((long)3));
PROCEDURE_SET(lambda1300_2335, ((long)0), where_710);
PROCEDURE_SET(lambda1300_2335, ((long)1), stack_2);
PROCEDURE_SET(lambda1300_2335, ((long)2), body_711);
return lambda1300_2335;
}
}
}
}
}
break;
case ((long)40) : 
{
obj_t value_719;
value_719 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_720;
where_720 = CAR(value_719);
{
obj_t body_721;
body_721 = CDR(value_719);
{
{
obj_t lambda1303_2334;
lambda1303_2334 = make_fx_procedure(lambda1303___evmeaning, ((long)3), ((long)3));
PROCEDURE_SET(lambda1303_2334, ((long)0), where_720);
PROCEDURE_SET(lambda1303_2334, ((long)1), stack_2);
PROCEDURE_SET(lambda1303_2334, ((long)2), body_721);
return lambda1303_2334;
}
}
}
}
}
break;
case ((long)41) : 
{
obj_t value_731;
value_731 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_732;
where_732 = CAR(value_731);
{
obj_t body_733;
body_733 = CDR(value_731);
{
{
obj_t lambda1309_2333;
lambda1309_2333 = make_fx_procedure(lambda1309___evmeaning, ((long)4), ((long)3));
PROCEDURE_SET(lambda1309_2333, ((long)0), where_732);
PROCEDURE_SET(lambda1309_2333, ((long)1), stack_2);
PROCEDURE_SET(lambda1309_2333, ((long)2), body_733);
return lambda1309_2333;
}
}
}
}
}
break;
case ((long)42) : 
{
obj_t lambda1316_2332;
lambda1316_2332 = make_fx_procedure(lambda1316___evmeaning, ((long)0), ((long)2));
PROCEDURE_SET(lambda1316_2332, ((long)0), exp_1);
PROCEDURE_SET(lambda1316_2332, ((long)1), stack_2);
return lambda1316_2332;
}
break;
case ((long)43) : 
{
obj_t lambda1320_2331;
lambda1320_2331 = make_fx_procedure(lambda1320___evmeaning, ((long)1), ((long)2));
PROCEDURE_SET(lambda1320_2331, ((long)0), exp_1);
PROCEDURE_SET(lambda1320_2331, ((long)1), stack_2);
return lambda1320_2331;
}
break;
case ((long)44) : 
{
obj_t lambda1323_2330;
lambda1323_2330 = make_fx_procedure(lambda1323___evmeaning, ((long)2), ((long)2));
PROCEDURE_SET(lambda1323_2330, ((long)0), exp_1);
PROCEDURE_SET(lambda1323_2330, ((long)1), stack_2);
return lambda1323_2330;
}
break;
case ((long)45) : 
{
obj_t lambda1327_2329;
lambda1327_2329 = make_fx_procedure(lambda1327___evmeaning, ((long)3), ((long)2));
PROCEDURE_SET(lambda1327_2329, ((long)0), exp_1);
PROCEDURE_SET(lambda1327_2329, ((long)1), stack_2);
return lambda1327_2329;
}
break;
case ((long)46) : 
{
obj_t lambda1333_2328;
lambda1333_2328 = make_fx_procedure(lambda1333___evmeaning, ((long)4), ((long)2));
PROCEDURE_SET(lambda1333_2328, ((long)0), exp_1);
PROCEDURE_SET(lambda1333_2328, ((long)1), stack_2);
return lambda1333_2328;
}
break;
case ((long)47) : 
{
obj_t value_775;
value_775 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_776;
where_776 = CAR(value_775);
{
obj_t body_777;
body_777 = CDR(value_775);
{
{
obj_t lambda1343_2327;
lambda1343_2327 = make_va_procedure(lambda1343___evmeaning, ((long)-1), ((long)3));
PROCEDURE_SET(lambda1343_2327, ((long)0), where_776);
PROCEDURE_SET(lambda1343_2327, ((long)1), stack_2);
PROCEDURE_SET(lambda1343_2327, ((long)2), body_777);
return lambda1343_2327;
}
}
}
}
}
break;
case ((long)48) : 
{
obj_t value_783;
value_783 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_784;
where_784 = CAR(value_783);
{
obj_t body_785;
body_785 = CDR(value_783);
{
{
obj_t lambda1345_2326;
lambda1345_2326 = make_va_procedure(lambda1345___evmeaning, ((long)-2), ((long)3));
PROCEDURE_SET(lambda1345_2326, ((long)0), where_784);
PROCEDURE_SET(lambda1345_2326, ((long)1), stack_2);
PROCEDURE_SET(lambda1345_2326, ((long)2), body_785);
return lambda1345_2326;
}
}
}
}
}
break;
case ((long)49) : 
{
obj_t value_793;
value_793 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_794;
where_794 = CAR(value_793);
{
obj_t body_795;
body_795 = CDR(value_793);
{
{
obj_t lambda1350_2325;
lambda1350_2325 = make_va_procedure(lambda1350___evmeaning, ((long)-3), ((long)3));
PROCEDURE_SET(lambda1350_2325, ((long)0), where_794);
PROCEDURE_SET(lambda1350_2325, ((long)1), stack_2);
PROCEDURE_SET(lambda1350_2325, ((long)2), body_795);
return lambda1350_2325;
}
}
}
}
}
break;
case ((long)50) : 
{
obj_t value_805;
value_805 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_806;
where_806 = CAR(value_805);
{
obj_t body_807;
body_807 = CDR(value_805);
{
{
obj_t lambda1354_2324;
lambda1354_2324 = make_va_procedure(lambda1354___evmeaning, ((long)-4), ((long)3));
PROCEDURE_SET(lambda1354_2324, ((long)0), where_806);
PROCEDURE_SET(lambda1354_2324, ((long)1), stack_2);
PROCEDURE_SET(lambda1354_2324, ((long)2), body_807);
return lambda1354_2324;
}
}
}
}
}
break;
case ((long)51) : 
{
obj_t lambda1362_2323;
lambda1362_2323 = make_va_procedure(lambda1362___evmeaning, ((long)-1), ((long)2));
PROCEDURE_SET(lambda1362_2323, ((long)0), exp_1);
PROCEDURE_SET(lambda1362_2323, ((long)1), stack_2);
return lambda1362_2323;
}
break;
case ((long)52) : 
{
obj_t lambda1365_2322;
lambda1365_2322 = make_va_procedure(lambda1365___evmeaning, ((long)-2), ((long)2));
PROCEDURE_SET(lambda1365_2322, ((long)0), exp_1);
PROCEDURE_SET(lambda1365_2322, ((long)1), stack_2);
return lambda1365_2322;
}
break;
case ((long)53) : 
{
obj_t lambda1370_2321;
lambda1370_2321 = make_va_procedure(lambda1370___evmeaning, ((long)-3), ((long)2));
PROCEDURE_SET(lambda1370_2321, ((long)0), exp_1);
PROCEDURE_SET(lambda1370_2321, ((long)1), stack_2);
return lambda1370_2321;
}
break;
case ((long)54) : 
{
obj_t lambda1380_2320;
lambda1380_2320 = make_va_procedure(lambda1380___evmeaning, ((long)-4), ((long)2));
PROCEDURE_SET(lambda1380_2320, ((long)0), exp_1);
PROCEDURE_SET(lambda1380_2320, ((long)1), stack_2);
return lambda1380_2320;
}
break;
case ((long)55) : 
{
obj_t value_847;
value_847 = VECTOR_REF(exp_1, ((long)2));
{
obj_t where_848;
where_848 = VECTOR_REF(value_847, ((long)0));
{
obj_t body_849;
body_849 = VECTOR_REF(value_847, ((long)1));
{
obj_t formals_850;
formals_850 = VECTOR_REF(value_847, ((long)2));
{
{
obj_t lambda1388_2319;
lambda1388_2319 = make_va_procedure(lambda1388___evmeaning, ((long)-1), ((long)5));
PROCEDURE_SET(lambda1388_2319, ((long)0), where_848);
PROCEDURE_SET(lambda1388_2319, ((long)1), stack_2);
PROCEDURE_SET(lambda1388_2319, ((long)2), exp_1);
PROCEDURE_SET(lambda1388_2319, ((long)3), formals_850);
PROCEDURE_SET(lambda1388_2319, ((long)4), body_849);
return lambda1388_2319;
}
}
}
}
}
}
break;
case ((long)56) : 
{
obj_t value_867;
value_867 = VECTOR_REF(exp_1, ((long)2));
{
obj_t body_868;
body_868 = CAR(value_867);
{
obj_t formals_869;
formals_869 = CDR(value_867);
{
{
obj_t lambda1398_2318;
lambda1398_2318 = make_va_procedure(lambda1398___evmeaning, ((long)-1), ((long)4));
PROCEDURE_SET(lambda1398_2318, ((long)0), stack_2);
PROCEDURE_SET(lambda1398_2318, ((long)1), exp_1);
PROCEDURE_SET(lambda1398_2318, ((long)2), formals_869);
PROCEDURE_SET(lambda1398_2318, ((long)3), body_868);
return lambda1398_2318;
}
}
}
}
}
break;
default: 
return evmeaning_error_137___evmeaning(exp_1, string1643___evmeaning, string1644___evmeaning, exp_1);
}
}
 else {
return evmeaning_error_137___evmeaning(exp_1, string1643___evmeaning, string1644___evmeaning, exp_1);
}
}
}
 else {
return exp_1;
}
}


/* handling_function1128 */obj_t handling_function1128___evmeaning(obj_t stack_2471, obj_t exp_2470)
{
jmp_buf jmpbuf;
obj_t an_exit1015_457;
if( SET_EXIT(an_exit1015_457) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1015_457 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1015_457, ((bool_t)1));
{
obj_t an_exitd1016_458;
an_exitd1016_458 = exitd_top;
{
obj_t __dummy___2338;
__dummy___2338 = make_fx_procedure(__dummy_____evmeaning, ((long)1), ((long)1));
PROCEDURE_SET(__dummy___2338, ((long)0), an_exitd1016_458);
{
obj_t res1018_461;
{
obj_t fun1130_463;
fun1130_463 = evmeaning___evmeaning(VECTOR_REF(exp_2470, ((long)2)), stack_2471);
res1018_461 = PROCEDURE_ENTRY(fun1130_463)(fun1130_463, __dummy___2338, BEOA);
}
POP_EXIT();
return res1018_461;
}
}
}
}
}
}


/* handling_function1135 */obj_t handling_function1135___evmeaning(obj_t stack_2473, obj_t body_2472)
{
jmp_buf jmpbuf;
obj_t an_exit1020_472;
if( SET_EXIT(an_exit1020_472) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1020_472 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1020_472, ((bool_t)0));
{
obj_t val1021_473;
val1021_473 = evmeaning___evmeaning(body_2472, stack_2473);
POP_EXIT();
return val1021_473;
}
}
}
}


/* _evmeaning */obj_t _evmeaning___evmeaning(obj_t env_2339, obj_t exp_2340, obj_t stack_2341)
{
return evmeaning___evmeaning(exp_2340, stack_2341);
}


/* lambda1398 */obj_t lambda1398___evmeaning(obj_t env_2342, obj_t x_2347)
{
{
obj_t stack_2343;
obj_t exp_2344;
obj_t formals_2345;
obj_t body_2346;
stack_2343 = PROCEDURE_REF(env_2342, ((long)0));
exp_2344 = PROCEDURE_REF(env_2342, ((long)1));
formals_2345 = PROCEDURE_REF(env_2342, ((long)2));
body_2346 = PROCEDURE_REF(env_2342, ((long)3));
{
obj_t x_870;
x_870 = x_2347;
{
obj_t new_env_64_872;
new_env_64_872 = _loop__1639___evmeaning(exp_2344, stack_2343, x_870, formals_2345);
return evmeaning___evmeaning(body_2346, new_env_64_872);
}
}
}
}


/* _loop__1639 */obj_t _loop__1639___evmeaning(obj_t exp_2469, obj_t stack_2468, obj_t actuals_873, obj_t formals_874)
{
if(NULLP(formals_874)){
if(NULLP(actuals_873)){
return stack_2468;
}
 else {
return evmeaning_error_137___evmeaning(exp_2469, string1640___evmeaning, string1645___evmeaning, actuals_873);
}
}
 else {
if(PAIRP(formals_874)){
if(NULLP(actuals_873)){
return evmeaning_error_137___evmeaning(exp_2469, string1640___evmeaning, string1646___evmeaning, formals_874);
}
 else {
{
obj_t arg1403_880;
obj_t arg1405_881;
arg1403_880 = CAR(actuals_873);
arg1405_881 = _loop__1639___evmeaning(exp_2469, stack_2468, CDR(actuals_873), CDR(formals_874));
return MAKE_PAIR(arg1403_880, arg1405_881);
}
}
}
 else {
return MAKE_PAIR(actuals_873, stack_2468);
}
}
}


/* lambda1388 */obj_t lambda1388___evmeaning(obj_t env_2348, obj_t x_2354)
{
{
obj_t where_2349;
obj_t stack_2350;
obj_t exp_2351;
obj_t formals_2352;
obj_t body_2353;
where_2349 = PROCEDURE_REF(env_2348, ((long)0));
stack_2350 = PROCEDURE_REF(env_2348, ((long)1));
exp_2351 = PROCEDURE_REF(env_2348, ((long)2));
formals_2352 = PROCEDURE_REF(env_2348, ((long)3));
body_2353 = PROCEDURE_REF(env_2348, ((long)4));
{
obj_t x_851;
x_851 = x_2354;
{
obj_t where_853;
where_853 = where_2349;
{
PUSH_TRACE(where_853);
BUNSPEC;
{
obj_t new_env_64_854;
new_env_64_854 = _loop____evmeaning(exp_2351, stack_2350, x_851, formals_2352);
{
obj_t res_855;
res_855 = evmeaning___evmeaning(body_2353, new_env_64_854);
POP_TRACE();
return res_855;
}
}
}
}
}
}
}


/* _loop_ */obj_t _loop____evmeaning(obj_t exp_2467, obj_t stack_2466, obj_t actuals_856, obj_t formals_857)
{
if(NULLP(formals_857)){
if(NULLP(actuals_856)){
return stack_2466;
}
 else {
return evmeaning_error_137___evmeaning(exp_2467, string1640___evmeaning, string1645___evmeaning, actuals_856);
}
}
 else {
if(PAIRP(formals_857)){
if(NULLP(actuals_856)){
return evmeaning_error_137___evmeaning(exp_2467, string1640___evmeaning, string1646___evmeaning, formals_857);
}
 else {
{
obj_t arg1393_863;
obj_t arg1395_864;
arg1393_863 = CAR(actuals_856);
arg1395_864 = _loop____evmeaning(exp_2467, stack_2466, CDR(actuals_856), CDR(formals_857));
return MAKE_PAIR(arg1393_863, arg1395_864);
}
}
}
 else {
return MAKE_PAIR(actuals_856, stack_2466);
}
}
}


/* lambda1380 */obj_t lambda1380___evmeaning(obj_t env_2355, obj_t x_2358, obj_t y_2359, obj_t z_2360, obj_t t_2361)
{
{
obj_t exp_2356;
obj_t stack_2357;
exp_2356 = PROCEDURE_REF(env_2355, ((long)0));
stack_2357 = PROCEDURE_REF(env_2355, ((long)1));
{
obj_t x_837;
obj_t y_838;
obj_t z_839;
obj_t t_840;
x_837 = x_2358;
y_838 = y_2359;
z_839 = z_2360;
t_840 = t_2361;
{
obj_t arg1381_2114;
obj_t arg1383_2115;
arg1381_2114 = VECTOR_REF(exp_2356, ((long)2));
{
obj_t arg1384_2116;
{
obj_t arg1385_2117;
{
obj_t arg1387_2118;
arg1387_2118 = MAKE_PAIR(t_840, stack_2357);
arg1385_2117 = MAKE_PAIR(z_839, arg1387_2118);
}
arg1384_2116 = MAKE_PAIR(y_838, arg1385_2117);
}
arg1383_2115 = MAKE_PAIR(x_837, arg1384_2116);
}
return evmeaning___evmeaning(arg1381_2114, arg1383_2115);
}
}
}
}


/* lambda1370 */obj_t lambda1370___evmeaning(obj_t env_2362, obj_t x_2365, obj_t y_2366, obj_t z_2367)
{
{
obj_t exp_2363;
obj_t stack_2364;
exp_2363 = PROCEDURE_REF(env_2362, ((long)0));
stack_2364 = PROCEDURE_REF(env_2362, ((long)1));
{
obj_t x_829;
obj_t y_830;
obj_t z_831;
x_829 = x_2365;
y_830 = y_2366;
z_831 = z_2367;
{
obj_t arg1372_2102;
obj_t arg1373_2103;
arg1372_2102 = VECTOR_REF(exp_2363, ((long)2));
{
obj_t arg1375_2104;
{
obj_t arg1378_2105;
arg1378_2105 = MAKE_PAIR(z_831, stack_2364);
arg1375_2104 = MAKE_PAIR(y_830, arg1378_2105);
}
arg1373_2103 = MAKE_PAIR(x_829, arg1375_2104);
}
return evmeaning___evmeaning(arg1372_2102, arg1373_2103);
}
}
}
}


/* lambda1365 */obj_t lambda1365___evmeaning(obj_t env_2368, obj_t x_2371, obj_t y_2372)
{
{
obj_t exp_2369;
obj_t stack_2370;
exp_2369 = PROCEDURE_REF(env_2368, ((long)0));
stack_2370 = PROCEDURE_REF(env_2368, ((long)1));
{
obj_t x_823;
obj_t y_824;
x_823 = x_2371;
y_824 = y_2372;
{
obj_t arg1367_2093;
obj_t arg1368_2094;
arg1367_2093 = VECTOR_REF(exp_2369, ((long)2));
{
obj_t arg1369_2095;
arg1369_2095 = MAKE_PAIR(y_824, stack_2370);
arg1368_2094 = MAKE_PAIR(x_823, arg1369_2095);
}
return evmeaning___evmeaning(arg1367_2093, arg1368_2094);
}
}
}
}


/* lambda1362 */obj_t lambda1362___evmeaning(obj_t env_2373, obj_t x_2376)
{
{
obj_t exp_2374;
obj_t stack_2375;
exp_2374 = PROCEDURE_REF(env_2373, ((long)0));
stack_2375 = PROCEDURE_REF(env_2373, ((long)1));
{
obj_t x_819;
x_819 = x_2376;
{
obj_t arg1363_2087;
obj_t arg1364_2088;
arg1363_2087 = VECTOR_REF(exp_2374, ((long)2));
arg1364_2088 = MAKE_PAIR(x_819, stack_2375);
return evmeaning___evmeaning(arg1363_2087, arg1364_2088);
}
}
}
}


/* lambda1354 */obj_t lambda1354___evmeaning(obj_t env_2377, obj_t x_2381, obj_t y_2382, obj_t z_2383, obj_t t_2384)
{
{
obj_t where_2378;
obj_t stack_2379;
obj_t body_2380;
where_2378 = PROCEDURE_REF(env_2377, ((long)0));
stack_2379 = PROCEDURE_REF(env_2377, ((long)1));
body_2380 = PROCEDURE_REF(env_2377, ((long)2));
{
obj_t x_808;
obj_t y_809;
obj_t z_810;
obj_t t_811;
x_808 = x_2381;
y_809 = y_2382;
z_810 = z_2383;
t_811 = t_2384;
{
obj_t where_2073;
where_2073 = where_2378;
{
PUSH_TRACE(where_2073);
BUNSPEC;
{
obj_t res_2074;
{
obj_t arg1355_2075;
{
obj_t arg1356_2076;
{
obj_t arg1357_2077;
{
obj_t arg1361_2078;
arg1361_2078 = MAKE_PAIR(t_811, stack_2379);
arg1357_2077 = MAKE_PAIR(z_810, arg1361_2078);
}
arg1356_2076 = MAKE_PAIR(y_809, arg1357_2077);
}
arg1355_2075 = MAKE_PAIR(x_808, arg1356_2076);
}
res_2074 = evmeaning___evmeaning(body_2380, arg1355_2075);
}
POP_TRACE();
return res_2074;
}
}
}
}
}
}


/* lambda1350 */obj_t lambda1350___evmeaning(obj_t env_2385, obj_t x_2389, obj_t y_2390, obj_t z_2391)
{
{
obj_t where_2386;
obj_t stack_2387;
obj_t body_2388;
where_2386 = PROCEDURE_REF(env_2385, ((long)0));
stack_2387 = PROCEDURE_REF(env_2385, ((long)1));
body_2388 = PROCEDURE_REF(env_2385, ((long)2));
{
obj_t x_796;
obj_t y_797;
obj_t z_798;
x_796 = x_2389;
y_797 = y_2390;
z_798 = z_2391;
{
obj_t where_2058;
where_2058 = where_2386;
{
PUSH_TRACE(where_2058);
BUNSPEC;
{
obj_t res_2059;
{
obj_t arg1351_2060;
{
obj_t arg1352_2061;
{
obj_t arg1353_2062;
arg1353_2062 = MAKE_PAIR(z_798, stack_2387);
arg1352_2061 = MAKE_PAIR(y_797, arg1353_2062);
}
arg1351_2060 = MAKE_PAIR(x_796, arg1352_2061);
}
res_2059 = evmeaning___evmeaning(body_2388, arg1351_2060);
}
POP_TRACE();
return res_2059;
}
}
}
}
}
}


/* lambda1345 */obj_t lambda1345___evmeaning(obj_t env_2392, obj_t x_2396, obj_t y_2397)
{
{
obj_t where_2393;
obj_t stack_2394;
obj_t body_2395;
where_2393 = PROCEDURE_REF(env_2392, ((long)0));
stack_2394 = PROCEDURE_REF(env_2392, ((long)1));
body_2395 = PROCEDURE_REF(env_2392, ((long)2));
{
obj_t x_786;
obj_t y_787;
x_786 = x_2396;
y_787 = y_2397;
{
obj_t where_2046;
where_2046 = where_2393;
{
PUSH_TRACE(where_2046);
BUNSPEC;
{
obj_t res_2047;
{
obj_t arg1347_2048;
{
obj_t arg1349_2049;
arg1349_2049 = MAKE_PAIR(y_787, stack_2394);
arg1347_2048 = MAKE_PAIR(x_786, arg1349_2049);
}
res_2047 = evmeaning___evmeaning(body_2395, arg1347_2048);
}
POP_TRACE();
return res_2047;
}
}
}
}
}
}


/* lambda1343 */obj_t lambda1343___evmeaning(obj_t env_2398, obj_t x_2402)
{
{
obj_t where_2399;
obj_t stack_2400;
obj_t body_2401;
where_2399 = PROCEDURE_REF(env_2398, ((long)0));
stack_2400 = PROCEDURE_REF(env_2398, ((long)1));
body_2401 = PROCEDURE_REF(env_2398, ((long)2));
{
obj_t x_778;
x_778 = x_2402;
{
obj_t where_2037;
where_2037 = where_2399;
{
PUSH_TRACE(where_2037);
BUNSPEC;
{
obj_t res_2038;
{
obj_t arg1344_2039;
arg1344_2039 = MAKE_PAIR(x_778, stack_2400);
res_2038 = evmeaning___evmeaning(body_2401, arg1344_2039);
}
POP_TRACE();
return res_2038;
}
}
}
}
}
}


/* lambda1333 */obj_t lambda1333___evmeaning(obj_t env_2403, obj_t x_2406, obj_t y_2407, obj_t z_2408, obj_t t_2409)
{
{
obj_t exp_2404;
obj_t stack_2405;
exp_2404 = PROCEDURE_REF(env_2403, ((long)0));
stack_2405 = PROCEDURE_REF(env_2403, ((long)1));
{
obj_t x_765;
obj_t y_766;
obj_t z_767;
obj_t t_768;
x_765 = x_2406;
y_766 = y_2407;
z_767 = z_2408;
t_768 = t_2409;
{
obj_t arg1334_2018;
obj_t arg1337_2019;
arg1334_2018 = VECTOR_REF(exp_2404, ((long)2));
{
obj_t arg1339_2020;
{
obj_t arg1340_2021;
{
obj_t arg1342_2022;
arg1342_2022 = MAKE_PAIR(t_768, stack_2405);
arg1340_2021 = MAKE_PAIR(z_767, arg1342_2022);
}
arg1339_2020 = MAKE_PAIR(y_766, arg1340_2021);
}
arg1337_2019 = MAKE_PAIR(x_765, arg1339_2020);
}
return evmeaning___evmeaning(arg1334_2018, arg1337_2019);
}
}
}
}


/* lambda1327 */obj_t lambda1327___evmeaning(obj_t env_2410, obj_t x_2413, obj_t y_2414, obj_t z_2415)
{
{
obj_t exp_2411;
obj_t stack_2412;
exp_2411 = PROCEDURE_REF(env_2410, ((long)0));
stack_2412 = PROCEDURE_REF(env_2410, ((long)1));
{
obj_t x_757;
obj_t y_758;
obj_t z_759;
x_757 = x_2413;
y_758 = y_2414;
z_759 = z_2415;
{
obj_t arg1328_2006;
obj_t arg1330_2007;
arg1328_2006 = VECTOR_REF(exp_2411, ((long)2));
{
obj_t arg1331_2008;
{
obj_t arg1332_2009;
arg1332_2009 = MAKE_PAIR(z_759, stack_2412);
arg1331_2008 = MAKE_PAIR(y_758, arg1332_2009);
}
arg1330_2007 = MAKE_PAIR(x_757, arg1331_2008);
}
return evmeaning___evmeaning(arg1328_2006, arg1330_2007);
}
}
}
}


/* lambda1323 */obj_t lambda1323___evmeaning(obj_t env_2416, obj_t x_2419, obj_t y_2420)
{
{
obj_t exp_2417;
obj_t stack_2418;
exp_2417 = PROCEDURE_REF(env_2416, ((long)0));
stack_2418 = PROCEDURE_REF(env_2416, ((long)1));
{
obj_t x_751;
obj_t y_752;
x_751 = x_2419;
y_752 = y_2420;
{
obj_t arg1324_1997;
obj_t arg1325_1998;
arg1324_1997 = VECTOR_REF(exp_2417, ((long)2));
{
obj_t arg1326_1999;
arg1326_1999 = MAKE_PAIR(y_752, stack_2418);
arg1325_1998 = MAKE_PAIR(x_751, arg1326_1999);
}
return evmeaning___evmeaning(arg1324_1997, arg1325_1998);
}
}
}
}


/* lambda1320 */obj_t lambda1320___evmeaning(obj_t env_2421, obj_t x_2424)
{
{
obj_t exp_2422;
obj_t stack_2423;
exp_2422 = PROCEDURE_REF(env_2421, ((long)0));
stack_2423 = PROCEDURE_REF(env_2421, ((long)1));
{
obj_t x_747;
x_747 = x_2424;
{
obj_t arg1321_1991;
obj_t arg1322_1992;
arg1321_1991 = VECTOR_REF(exp_2422, ((long)2));
arg1322_1992 = MAKE_PAIR(x_747, stack_2423);
return evmeaning___evmeaning(arg1321_1991, arg1322_1992);
}
}
}
}


/* lambda1316 */obj_t lambda1316___evmeaning(obj_t env_2425)
{
{
obj_t exp_2426;
obj_t stack_2427;
exp_2426 = PROCEDURE_REF(env_2425, ((long)0));
stack_2427 = PROCEDURE_REF(env_2425, ((long)1));
{
return evmeaning___evmeaning(VECTOR_REF(exp_2426, ((long)2)), stack_2427);
}
}
}


/* lambda1309 */obj_t lambda1309___evmeaning(obj_t env_2428, obj_t x_2432, obj_t y_2433, obj_t z_2434, obj_t t_2435)
{
{
obj_t where_2429;
obj_t stack_2430;
obj_t body_2431;
where_2429 = PROCEDURE_REF(env_2428, ((long)0));
stack_2430 = PROCEDURE_REF(env_2428, ((long)1));
body_2431 = PROCEDURE_REF(env_2428, ((long)2));
{
obj_t x_734;
obj_t y_735;
obj_t z_736;
obj_t t_737;
x_734 = x_2432;
y_735 = y_2433;
z_736 = z_2434;
t_737 = t_2435;
{
obj_t where_1974;
where_1974 = where_2429;
{
PUSH_TRACE(where_1974);
BUNSPEC;
{
obj_t res_1975;
{
obj_t arg1310_1976;
{
obj_t arg1311_1977;
{
obj_t arg1313_1978;
{
obj_t arg1315_1979;
arg1315_1979 = MAKE_PAIR(t_737, stack_2430);
arg1313_1978 = MAKE_PAIR(z_736, arg1315_1979);
}
arg1311_1977 = MAKE_PAIR(y_735, arg1313_1978);
}
arg1310_1976 = MAKE_PAIR(x_734, arg1311_1977);
}
res_1975 = evmeaning___evmeaning(body_2431, arg1310_1976);
}
POP_TRACE();
return res_1975;
}
}
}
}
}
}


/* lambda1303 */obj_t lambda1303___evmeaning(obj_t env_2436, obj_t x_2440, obj_t y_2441, obj_t z_2442)
{
{
obj_t where_2437;
obj_t stack_2438;
obj_t body_2439;
where_2437 = PROCEDURE_REF(env_2436, ((long)0));
stack_2438 = PROCEDURE_REF(env_2436, ((long)1));
body_2439 = PROCEDURE_REF(env_2436, ((long)2));
{
obj_t x_722;
obj_t y_723;
obj_t z_724;
x_722 = x_2440;
y_723 = y_2441;
z_724 = z_2442;
{
obj_t where_1959;
where_1959 = where_2437;
{
PUSH_TRACE(where_1959);
BUNSPEC;
{
obj_t res_1960;
{
obj_t arg1304_1961;
{
obj_t arg1307_1962;
{
obj_t arg1308_1963;
arg1308_1963 = MAKE_PAIR(z_724, stack_2438);
arg1307_1962 = MAKE_PAIR(y_723, arg1308_1963);
}
arg1304_1961 = MAKE_PAIR(x_722, arg1307_1962);
}
res_1960 = evmeaning___evmeaning(body_2439, arg1304_1961);
}
POP_TRACE();
return res_1960;
}
}
}
}
}
}


/* lambda1300 */obj_t lambda1300___evmeaning(obj_t env_2443, obj_t x_2447, obj_t y_2448)
{
{
obj_t where_2444;
obj_t stack_2445;
obj_t body_2446;
where_2444 = PROCEDURE_REF(env_2443, ((long)0));
stack_2445 = PROCEDURE_REF(env_2443, ((long)1));
body_2446 = PROCEDURE_REF(env_2443, ((long)2));
{
obj_t x_712;
obj_t y_713;
x_712 = x_2447;
y_713 = y_2448;
{
obj_t where_1947;
where_1947 = where_2444;
{
PUSH_TRACE(where_1947);
BUNSPEC;
{
obj_t res_1948;
{
obj_t arg1301_1949;
{
obj_t arg1302_1950;
arg1302_1950 = MAKE_PAIR(y_713, stack_2445);
arg1301_1949 = MAKE_PAIR(x_712, arg1302_1950);
}
res_1948 = evmeaning___evmeaning(body_2446, arg1301_1949);
}
POP_TRACE();
return res_1948;
}
}
}
}
}
}


/* lambda1298 */obj_t lambda1298___evmeaning(obj_t env_2449, obj_t x_2453)
{
{
obj_t where_2450;
obj_t stack_2451;
obj_t body_2452;
where_2450 = PROCEDURE_REF(env_2449, ((long)0));
stack_2451 = PROCEDURE_REF(env_2449, ((long)1));
body_2452 = PROCEDURE_REF(env_2449, ((long)2));
{
obj_t x_704;
x_704 = x_2453;
{
obj_t where_1938;
where_1938 = where_2450;
{
PUSH_TRACE(where_1938);
BUNSPEC;
{
obj_t res_1939;
{
obj_t arg1299_1940;
arg1299_1940 = MAKE_PAIR(x_704, stack_2451);
res_1939 = evmeaning___evmeaning(body_2452, arg1299_1940);
}
POP_TRACE();
return res_1939;
}
}
}
}
}
}


/* lambda1297 */obj_t lambda1297___evmeaning(obj_t env_2454)
{
{
obj_t where_2455;
obj_t body_2456;
obj_t stack_2457;
where_2455 = PROCEDURE_REF(env_2454, ((long)0));
body_2456 = PROCEDURE_REF(env_2454, ((long)1));
stack_2457 = PROCEDURE_REF(env_2454, ((long)2));
{
{
obj_t where_699;
where_699 = where_2455;
{
PUSH_TRACE(where_699);
BUNSPEC;
{
obj_t res_700;
res_700 = evmeaning___evmeaning(body_2456, stack_2457);
POP_TRACE();
return res_700;
}
}
}
}
}
}


/* __dummy__ */obj_t __dummy_____evmeaning(obj_t env_2458, obj_t val1017_2460)
{
{
obj_t an_exitd1016_2459;
an_exitd1016_2459 = PROCEDURE_REF(env_2458, ((long)0));
{
obj_t val1017_459;
val1017_459 = val1017_2460;
return unwind_until__178___bexit(an_exitd1016_2459, val1017_459);
}
}
}


/* evmeaning-error */obj_t evmeaning_error_137___evmeaning(obj_t bcode_3, obj_t proc_4, obj_t mes_5, obj_t obj_6)
{
if(VECTORP(bcode_3)){
obj_t e_103_175_889;
e_103_175_889 = VECTOR_REF(bcode_3, ((long)1));
if(PAIRP(e_103_175_889)){
obj_t cdr_109_69_891;
cdr_109_69_891 = CDR(e_103_175_889);
{
bool_t test_3363;
{
obj_t aux_3364;
aux_3364 = CAR(e_103_175_889);
test_3363 = (aux_3364==symbol1647___evmeaning);
}
if(test_3363){
if(PAIRP(cdr_109_69_891)){
obj_t cdr_113_28_894;
cdr_113_28_894 = CDR(cdr_109_69_891);
if(PAIRP(cdr_113_28_894)){
bool_t test_3372;
{
obj_t aux_3373;
aux_3373 = CDR(cdr_113_28_894);
test_3372 = (aux_3373==BNIL);
}
if(test_3372){
return error_location_112___error(proc_4, mes_5, obj_6, CAR(cdr_109_69_891), CAR(cdr_113_28_894));
}
 else {
FAILURE(proc_4,mes_5,obj_6);}
}
 else {
FAILURE(proc_4,mes_5,obj_6);}
}
 else {
FAILURE(proc_4,mes_5,obj_6);}
}
 else {
FAILURE(proc_4,mes_5,obj_6);}
}
}
 else {
FAILURE(proc_4,mes_5,obj_6);}
}
 else {
FAILURE(proc_4,mes_5,obj_6);}
}


/* evmeaning-warning */obj_t evmeaning_warning_75___evmeaning(obj_t bcode_7, obj_t args_8)
{
if(VECTORP(bcode_7)){
obj_t fname_904;
obj_t loc_905;
{
obj_t e_121_5_908;
e_121_5_908 = VECTOR_REF(bcode_7, ((long)1));
if(PAIRP(e_121_5_908)){
obj_t cdr_127_175_910;
cdr_127_175_910 = CDR(e_121_5_908);
{
bool_t test_3391;
{
obj_t aux_3392;
aux_3392 = CAR(e_121_5_908);
test_3391 = (aux_3392==symbol1647___evmeaning);
}
if(test_3391){
if(PAIRP(cdr_127_175_910)){
obj_t cdr_131_134_913;
cdr_131_134_913 = CDR(cdr_127_175_910);
if(PAIRP(cdr_131_134_913)){
bool_t test_3400;
{
obj_t aux_3401;
aux_3401 = CDR(cdr_131_134_913);
test_3400 = (aux_3401==BNIL);
}
if(test_3400){
fname_904 = CAR(cdr_127_175_910);
loc_905 = CAR(cdr_131_134_913);
{
obj_t runner1448_931;
{
obj_t arg1438_922;
{
obj_t arg1443_926;
arg1443_926 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1438_922 = append_2_18___r4_pairs_and_lists_6_3(args_8, arg1443_926);
}
{
obj_t list1439_923;
{
obj_t arg1440_924;
arg1440_924 = MAKE_PAIR(arg1438_922, BNIL);
list1439_923 = MAKE_PAIR(loc_905, arg1440_924);
}
runner1448_931 = cons__138___r4_pairs_and_lists_6_3(fname_904, list1439_923);
}
}
{
obj_t aux1446_929;
{
obj_t pair_2223;
pair_2223 = runner1448_931;
aux1446_929 = CAR(pair_2223);
}
{
obj_t pair_2224;
pair_2224 = runner1448_931;
runner1448_931 = CDR(pair_2224);
}
{
obj_t aux1447_930;
{
obj_t pair_2225;
pair_2225 = runner1448_931;
aux1447_930 = CAR(pair_2225);
}
{
obj_t pair_2226;
pair_2226 = runner1448_931;
runner1448_931 = CDR(pair_2226);
}
return warning_location_135___error(aux1446_929, aux1447_930, runner1448_931);
}
}
}
}
 else {
return warning___error(args_8);
}
}
 else {
return warning___error(args_8);
}
}
 else {
return warning___error(args_8);
}
}
 else {
return warning___error(args_8);
}
}
}
 else {
return warning___error(args_8);
}
}
}
 else {
return warning___error(args_8);
}
}


/* evmeaning-notify-error */obj_t evmeaning_notify_error_24___evmeaning(obj_t proc_9, obj_t mes_10, obj_t obj_11)
{
{
bool_t test1451_934;
{
obj_t obj_2228;
obj_2228 = _current_bcode__25___evmeaning;
test1451_934 = VECTORP(obj_2228);
}
if(test1451_934){
obj_t e_139_15_939;
{
obj_t vector_2229;
vector_2229 = _current_bcode__25___evmeaning;
e_139_15_939 = VECTOR_REF(vector_2229, ((long)1));
}
if(PAIRP(e_139_15_939)){
obj_t cdr_145_238_941;
cdr_145_238_941 = CDR(e_139_15_939);
{
bool_t test_3428;
{
obj_t aux_3429;
aux_3429 = CAR(e_139_15_939);
test_3428 = (aux_3429==symbol1647___evmeaning);
}
if(test_3428){
if(PAIRP(cdr_145_238_941)){
obj_t cdr_149_75_944;
cdr_149_75_944 = CDR(cdr_145_238_941);
if(PAIRP(cdr_149_75_944)){
bool_t test_3437;
{
obj_t aux_3438;
aux_3438 = CDR(cdr_149_75_944);
test_3437 = (aux_3438==BNIL);
}
if(test_3437){
_current_bcode__25___evmeaning = BFALSE;
{
obj_t fun1466_2246;
fun1466_2246 = error_location_file_107___error(CAR(cdr_145_238_941), CAR(cdr_149_75_944));
return PROCEDURE_ENTRY(fun1466_2246)(fun1466_2246, proc_9, mes_10, obj_11, BEOA);
}
}
 else {
return notify_error_43___error(proc_9, mes_10, obj_11);
}
}
 else {
return notify_error_43___error(proc_9, mes_10, obj_11);
}
}
 else {
return notify_error_43___error(proc_9, mes_10, obj_11);
}
}
 else {
return notify_error_43___error(proc_9, mes_10, obj_11);
}
}
}
 else {
return notify_error_43___error(proc_9, mes_10, obj_11);
}
}
 else {
return notify_error_43___error(proc_9, mes_10, obj_11);
}
}
}


/* _evmeaning-notify-error */obj_t _evmeaning_notify_error_221___evmeaning(obj_t env_2461, obj_t proc_2462, obj_t mes_2463, obj_t obj_2464)
{
return evmeaning_notify_error_24___evmeaning(proc_2462, mes_2463, obj_2464);
}


/* evmeaning-reset-error! */obj_t evmeaning_reset_error__111___evmeaning()
{
return (_current_bcode__25___evmeaning = BFALSE,
BUNSPEC);
}


/* _evmeaning-reset-error! */obj_t _evmeaning_reset_error__115___evmeaning(obj_t env_2465)
{
return evmeaning_reset_error__111___evmeaning();
}


/* imported-modules-init */obj_t imported_modules_init_94___evmeaning()
{
module_initialization_70___type(((long)0), "__EVMEANING");
module_initialization_70___error(((long)0), "__EVMEANING");
module_initialization_70___bigloo(((long)0), "__EVMEANING");
module_initialization_70___tvector(((long)0), "__EVMEANING");
module_initialization_70___structure(((long)0), "__EVMEANING");
module_initialization_70___bexit(((long)0), "__EVMEANING");
module_initialization_70___os(((long)0), "__EVMEANING");
module_initialization_70___r4_numbers_6_5(((long)0), "__EVMEANING");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EVMEANING");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EVMEANING");
module_initialization_70___r4_characters_6_6(((long)0), "__EVMEANING");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EVMEANING");
module_initialization_70___r4_booleans_6_1(((long)0), "__EVMEANING");
module_initialization_70___r4_symbols_6_4(((long)0), "__EVMEANING");
module_initialization_70___r4_strings_6_7(((long)0), "__EVMEANING");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EVMEANING");
module_initialization_70___r4_input_6_10_2(((long)0), "__EVMEANING");
module_initialization_70___r4_control_features_6_9(((long)0), "__EVMEANING");
module_initialization_70___r4_vectors_6_8(((long)0), "__EVMEANING");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EVMEANING");
module_initialization_70___r4_output_6_10_3(((long)0), "__EVMEANING");
module_initialization_70___progn(((long)0), "__EVMEANING");
module_initialization_70___evenv(((long)0), "__EVMEANING");
return module_initialization_70___evcompile(((long)0), "__EVMEANING");
}

