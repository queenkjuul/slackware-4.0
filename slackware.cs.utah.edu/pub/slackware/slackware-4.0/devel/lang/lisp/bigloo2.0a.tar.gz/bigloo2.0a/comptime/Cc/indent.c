/*===========================================================================*/
/*   (Cc/indent.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t indent_cc_indent(obj_t);
extern obj_t string_append(obj_t, obj_t);
static obj_t _indent_cc_indent(obj_t, obj_t);
extern obj_t warning___error(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_cc_indent(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern bool_t fexists(char *);
static obj_t imported_modules_init_94_cc_indent();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t library_modules_init_112_cc_indent();
extern obj_t basename___os(obj_t);
static obj_t require_initialization_114_cc_indent = BUNSPEC;
extern obj_t _indent__220_engine_param;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(indent_env_191_cc_indent, _indent_cc_indent1173, _indent_cc_indent, 0L, 1);
DEFINE_STRING(string1171_cc_indent, string1171_cc_indent1174, "        mv ", 11);
DEFINE_STRING(string1169_cc_indent, string1169_cc_indent1175, ".cc", 3);
DEFINE_STRING(string1170_cc_indent, string1170_cc_indent1176, ".c", 2);
DEFINE_STRING(string1168_cc_indent, string1168_cc_indent1177, "Non nul value returned -- ", 26);
DEFINE_STRING(string1167_cc_indent, string1167_cc_indent1178, "      [", 7);
DEFINE_STRING(string1166_cc_indent, string1166_cc_indent1179, " ", 1);
DEFINE_STRING(string1165_cc_indent, string1165_cc_indent1180, ".c > ", 5);
DEFINE_STRING(string1164_cc_indent, string1164_cc_indent1181, ".cc ", 4);
DEFINE_STRING(string1163_cc_indent, string1163_cc_indent1182, "   . indent (", 13);
DEFINE_STRING(string1162_cc_indent, string1162_cc_indent1183, ")", 1);


/* module-initialization */ obj_t 
module_initialization_70_cc_indent(long checksum_70, char *from_71)
{
   if (CBOOL(require_initialization_114_cc_indent))
     {
	require_initialization_114_cc_indent = BBOOL(((bool_t) 0));
	library_modules_init_112_cc_indent();
	imported_modules_init_94_cc_indent();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cc_indent()
{
   module_initialization_70___error(((long) 0), "CC_INDENT");
   module_initialization_70___r4_strings_6_7(((long) 0), "CC_INDENT");
   module_initialization_70___os(((long) 0), "CC_INDENT");
   return BUNSPEC;
}


/* indent */ obj_t 
indent_cc_indent(obj_t name_1)
{
   {
      bool_t test1002_2;
      if (STRINGP(name_1))
	{
	   bool_t test1152_49;
	   {
	      obj_t obj_53;
	      obj_53 = _indent__220_engine_param;
	      test1152_49 = STRINGP(obj_53);
	   }
	   if (test1152_49)
	     {
		long arg1157_50;
		{
		   obj_t string_54;
		   string_54 = _indent__220_engine_param;
		   arg1157_50 = STRING_LENGTH(string_54);
		}
		test1002_2 = (arg1157_50 > ((long) 0));
	     }
	   else
	     {
		test1002_2 = ((bool_t) 0);
	     }
	}
      else
	{
	   test1002_2 = ((bool_t) 0);
	}
      if (test1002_2)
	{
	   {
	      obj_t arg1005_5;
	      arg1005_5 = basename___os(_indent__220_engine_param);
	      {
		 obj_t list1007_7;
		 {
		    obj_t arg1008_8;
		    {
		       obj_t arg1009_9;
		       {
			  obj_t arg1011_10;
			  {
			     obj_t aux_88;
			     aux_88 = BCHAR(((unsigned char) '\n'));
			     arg1011_10 = MAKE_PAIR(aux_88, BNIL);
			  }
			  arg1009_9 = MAKE_PAIR(string1162_cc_indent, arg1011_10);
		       }
		       arg1008_8 = MAKE_PAIR(arg1005_5, arg1009_9);
		    }
		    list1007_7 = MAKE_PAIR(string1163_cc_indent, arg1008_8);
		 }
		 verbose_tools_speek(BINT(((long) 1)), list1007_7);
	      }
	   }
	   {
	      obj_t cmd_12;
	      {
		 obj_t list1062_38;
		 {
		    obj_t arg1063_39;
		    {
		       obj_t arg1066_41;
		       {
			  obj_t arg1077_42;
			  {
			     obj_t arg1142_44;
			     {
				obj_t arg1144_45;
				arg1144_45 = MAKE_PAIR(string1164_cc_indent, BNIL);
				arg1142_44 = MAKE_PAIR(name_1, arg1144_45);
			     }
			     arg1077_42 = MAKE_PAIR(string1165_cc_indent, arg1142_44);
			  }
			  arg1066_41 = MAKE_PAIR(name_1, arg1077_42);
		       }
		       arg1063_39 = MAKE_PAIR(string1166_cc_indent, arg1066_41);
		    }
		    list1062_38 = MAKE_PAIR(_indent__220_engine_param, arg1063_39);
		 }
		 cmd_12 = string_append_106___r4_strings_6_7(list1062_38);
	      }
	      {
		 obj_t list1015_13;
		 {
		    obj_t arg1018_15;
		    {
		       obj_t arg1020_16;
		       {
			  obj_t arg1025_17;
			  {
			     obj_t aux_103;
			     aux_103 = BCHAR(((unsigned char) '\n'));
			     arg1025_17 = MAKE_PAIR(aux_103, BNIL);
			  }
			  {
			     obj_t aux_106;
			     aux_106 = BCHAR(((unsigned char) ']'));
			     arg1020_16 = MAKE_PAIR(aux_106, arg1025_17);
			  }
		       }
		       arg1018_15 = MAKE_PAIR(cmd_12, arg1020_16);
		    }
		    list1015_13 = MAKE_PAIR(string1167_cc_indent, arg1018_15);
		 }
		 verbose_tools_speek(BINT(((long) 2)), list1015_13);
	      }
	      {
		 int res_19;
		 {
		    char *aux_113;
		    aux_113 = BSTRING_TO_STRING(cmd_12);
		    res_19 = system(aux_113);
		 }
		 {
		    bool_t test_116;
		    {
		       long aux_117;
		       aux_117 = (long) (res_19);
		       test_116 = (aux_117 == ((long) 0));
		    }
		    if (test_116)
		      {
			 BUNSPEC;
		      }
		    else
		      {
			 obj_t list1034_21;
			 {
			    obj_t arg1038_22;
			    {
			       obj_t arg1040_24;
			       {
				  obj_t aux_120;
				  aux_120 = BINT(res_19);
				  arg1040_24 = MAKE_PAIR(aux_120, BNIL);
			       }
			       arg1038_22 = MAKE_PAIR(string1168_cc_indent, arg1040_24);
			    }
			    list1034_21 = MAKE_PAIR(_indent__220_engine_param, arg1038_22);
			 }
			 warning___error(list1034_21);
		      }
		 }
	      }
	      {
		 bool_t test1042_26;
		 {
		    obj_t arg1061_37;
		    arg1061_37 = string_append(name_1, string1169_cc_indent);
		    {
		       char *aux_127;
		       aux_127 = BSTRING_TO_STRING(arg1061_37);
		       test1042_26 = fexists(aux_127);
		    }
		 }
		 if (test1042_26)
		   {
		      obj_t sname_27;
		      obj_t dname_28;
		      sname_27 = string_append(name_1, string1169_cc_indent);
		      dname_28 = string_append(name_1, string1170_cc_indent);
		      {
			 obj_t list1043_29;
			 {
			    obj_t arg1055_31;
			    {
			       obj_t arg1056_32;
			       {
				  obj_t arg1058_34;
				  {
				     obj_t arg1059_35;
				     {
					obj_t aux_133;
					aux_133 = BCHAR(((unsigned char) '\n'));
					arg1059_35 = MAKE_PAIR(aux_133, BNIL);
				     }
				     arg1058_34 = MAKE_PAIR(dname_28, arg1059_35);
				  }
				  arg1056_32 = MAKE_PAIR(string1166_cc_indent, arg1058_34);
			       }
			       arg1055_31 = MAKE_PAIR(sname_27, arg1056_32);
			    }
			    list1043_29 = MAKE_PAIR(string1171_cc_indent, arg1055_31);
			 }
			 verbose_tools_speek(BINT(((long) 2)), list1043_29);
		      }
		      {
			 bool_t test1011_63;
			 {
			    int arg1012_64;
			    {
			       char *aux_144;
			       char *aux_142;
			       aux_144 = BSTRING_TO_STRING(dname_28);
			       aux_142 = BSTRING_TO_STRING(sname_27);
			       arg1012_64 = rename(aux_142, aux_144);
			    }
			    {
			       obj_t aux_149;
			       obj_t aux_147;
			       aux_149 = BINT(((long) 0));
			       aux_147 = BINT(arg1012_64);
			       test1011_63 = (aux_147 == aux_149);
			    }
			 }
			 if (test1011_63)
			   {
			      return BTRUE;
			   }
			 else
			   {
			      return BFALSE;
			   }
		      }
		   }
		 else
		   {
		      return BUNSPEC;
		   }
	      }
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _indent */ obj_t 
_indent_cc_indent(obj_t env_68, obj_t name_69)
{
   return indent_cc_indent(name_69);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cc_indent()
{
   module_initialization_70_tools_speek(((long) 0), "CC_INDENT");
   return module_initialization_70_engine_param(((long) 0), "CC_INDENT");
}
