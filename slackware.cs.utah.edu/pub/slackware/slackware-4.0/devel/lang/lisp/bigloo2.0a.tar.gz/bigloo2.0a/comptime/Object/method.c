/*===========================================================================*/
/*   (Object/method.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_object_method();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern long add_generic_method__111_object_inline(global_t, type_t, obj_t, obj_t);
extern obj_t id_of_id_112_ast_ident(obj_t);
extern obj_t global_ast_var;
extern obj_t gensym___r4_symbols_6_4;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_object_method(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_inline(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern bool_t method_inlining_enabled__91_object_inline();
static obj_t imported_modules_init_94_object_method();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_object_method();
extern obj_t open_input_string(obj_t);
extern int arity_tools_args(obj_t);
extern obj_t class_object_class;
extern obj_t string_to_bstring(char *);
static obj_t method_error_85_object_method(obj_t, char *, obj_t);
extern obj_t add_generic_for_method_inlining__147_object_inline(obj_t);
static obj_t _make_method_body_16_object_method(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t make_method_body_103_object_method(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_object_method = BUNSPEC;
static obj_t cnst_init_137_object_method();
static obj_t __cnst[17];

DEFINE_EXPORT_PROCEDURE(make_method_body_env_21_object_method, _make_method_body_16_object_method1531, _make_method_body_16_object_method, 0L, 5);
DEFINE_STRING(string1525_object_method, string1525_object_method1532, "(QUOTE METHOD-DEFINITION-ERROR) ADD-INLINED-METHOD! ADD-METHOD! GENERIC-PRE-METHOD-SET! BEGIN CONS* APPLY PROCEDURE? IF @ FIND-SUPER-CLASS-METHOD LET CALL-NEXT-METHOD LABELS IMPORT - NEXT-METHOD ", 195);
DEFINE_STRING(string1524_object_method, string1524_object_method1533, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string1523_object_method, string1523_object_method1534, "cer", 3);


/* module-initialization */ obj_t 
module_initialization_70_object_method(long checksum_855, char *from_856)
{
   if (CBOOL(require_initialization_114_object_method))
     {
	require_initialization_114_object_method = BBOOL(((bool_t) 0));
	library_modules_init_112_object_method();
	cnst_init_137_object_method();
	imported_modules_init_94_object_method();
	method_init_76_object_method();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_method()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_METHOD");
   module_initialization_70___object(((long) 0), "OBJECT_METHOD");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_METHOD");
   module_initialization_70___reader(((long) 0), "OBJECT_METHOD");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_method()
{
   {
      obj_t cnst_port_138_847;
      cnst_port_138_847 = open_input_string(string1525_object_method);
      {
	 long i_848;
	 i_848 = ((long) 16);
       loop_849:
	 {
	    bool_t test1526_850;
	    test1526_850 = (i_848 == ((long) -1));
	    if (test1526_850)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1527_851;
		    {
		       obj_t list1528_852;
		       {
			  obj_t arg1529_853;
			  arg1529_853 = BNIL;
			  list1528_852 = MAKE_PAIR(cnst_port_138_847, arg1529_853);
		       }
		       arg1527_851 = read___reader(list1528_852);
		    }
		    CNST_TABLE_SET(i_848, arg1527_851);
		 }
		 {
		    int aux_854;
		    {
		       long aux_874;
		       aux_874 = (i_848 - ((long) 1));
		       aux_854 = (int) (aux_874);
		    }
		    {
		       long i_877;
		       i_877 = (long) (aux_854);
		       i_848 = i_877;
		       goto loop_849;
		    }
		 }
	      }
	 }
      }
   }
}


/* make-method-body */ obj_t 
make_method_body_103_object_method(obj_t id_1, obj_t args_2, obj_t locals_3, obj_t body_4, obj_t src_5)
{
   {
      obj_t id_383;
      id_383 = id_of_id_112_ast_ident(id_1);
      {
	 obj_t method_384;
	 method_384 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
	 {
	    int arity_385;
	    arity_385 = arity_tools_args(args_2);
	    {
	       obj_t args_id_103_386;
	       if (NULLP(locals_3))
		 {
		    args_id_103_386 = BNIL;
		 }
	       else
		 {
		    obj_t head1211_596;
		    {
		       obj_t aux_886;
		       {
			  local_t obj_760;
			  {
			     obj_t aux_887;
			     aux_887 = CAR(locals_3);
			     obj_760 = (local_t) (aux_887);
			  }
			  aux_886 = (((local_t) CREF(obj_760))->id);
		       }
		       head1211_596 = MAKE_PAIR(aux_886, BNIL);
		    }
		    {
		       obj_t l1209_597;
		       obj_t tail1212_598;
		       l1209_597 = CDR(locals_3);
		       tail1212_598 = head1211_596;
		     lname1210_599:
		       if (NULLP(l1209_597))
			 {
			    args_id_103_386 = head1211_596;
			 }
		       else
			 {
			    obj_t newtail1213_602;
			    {
			       obj_t aux_894;
			       {
				  local_t obj_766;
				  {
				     obj_t aux_895;
				     aux_895 = CAR(l1209_597);
				     obj_766 = (local_t) (aux_895);
				  }
				  aux_894 = (((local_t) CREF(obj_766))->id);
			       }
			       newtail1213_602 = MAKE_PAIR(aux_894, BNIL);
			    }
			    SET_CDR(tail1212_598, newtail1213_602);
			    {
			       obj_t tail1212_903;
			       obj_t l1209_901;
			       l1209_901 = CDR(l1209_597);
			       tail1212_903 = newtail1213_602;
			       tail1212_598 = tail1212_903;
			       l1209_597 = l1209_901;
			       goto lname1210_599;
			    }
			 }
		    }
		 }
	       {
		  type_t type_387;
		  {
		     local_t obj_773;
		     {
			obj_t aux_905;
			aux_905 = CAR(locals_3);
			obj_773 = (local_t) (aux_905);
		     }
		     type_387 = (((local_t) CREF(obj_773))->type);
		  }
		  {
		     obj_t m_id_75_388;
		     {
			obj_t arg1463_587;
			arg1463_587 = CNST_TABLE_REF(((long) 1));
			{
			   obj_t list1465_589;
			   {
			      obj_t arg1466_590;
			      {
				 obj_t arg1467_591;
				 {
				    obj_t aux_910;
				    aux_910 = (((type_t) CREF(type_387))->id);
				    arg1467_591 = MAKE_PAIR(aux_910, BNIL);
				 }
				 arg1466_590 = MAKE_PAIR(arg1463_587, arg1467_591);
			      }
			      list1465_589 = MAKE_PAIR(id_383, arg1466_590);
			   }
			   m_id_75_388 = symbol_append_197___r4_symbols_6_4(list1465_589);
			}
		     }
		     {
			{
			   bool_t test1214_389;
			   test1214_389 = is_a__118___object((obj_t) (type_387), class_object_class);
			   if (test1214_389)
			     {
				global_t holder_390;
				{
				   class_t obj_776;
				   obj_776 = (class_t) (type_387);
				   {
				      obj_t aux_920;
				      {
					 object_t aux_921;
					 aux_921 = (object_t) (obj_776);
					 aux_920 = OBJECT_WIDENING(aux_921);
				      }
				      holder_390 = (((class_t) CREF(aux_920))->holder);
				   }
				}
				{
				   obj_t module_391;
				   module_391 = (((global_t) CREF(holder_390))->module);
				   {
				      obj_t generic_392;
				      generic_392 = find_global_223_ast_env(id_383, BNIL);
				      {
					 {
					    bool_t test1215_393;
					    test1215_393 = is_a__118___object(generic_392, global_ast_var);
					    if (test1215_393)
					      {
						 bool_t test1216_394;
						 {
						    bool_t test1456_583;
						    test1456_583 = method_inlining_enabled__91_object_inline();
						    if (test1456_583)
						      {
							 obj_t aux_934;
							 obj_t aux_931;
							 aux_934 = CNST_TABLE_REF(((long) 2));
							 {
							    global_t obj_779;
							    obj_779 = (global_t) (generic_392);
							    aux_931 = (((global_t) CREF(obj_779))->import);
							 }
							 test1216_394 = (aux_931 == aux_934);
						      }
						    else
						      {
							 test1216_394 = ((bool_t) 1);
						      }
						 }
						 if (test1216_394)
						   {
						      {
							 obj_t body_395;
							 {
							    obj_t arg1270_441;
							    obj_t arg1272_442;
							    arg1270_441 = CNST_TABLE_REF(((long) 3));
							    {
							       obj_t arg1282_448;
							       {
								  obj_t arg1286_452;
								  obj_t arg1288_454;
								  arg1286_452 = CNST_TABLE_REF(((long) 4));
								  {
								     obj_t arg1296_460;
								     obj_t arg1297_461;
								     obj_t arg1298_462;
								     arg1296_460 = CNST_TABLE_REF(((long) 5));
								     {
									obj_t arg1304_468;
									{
									   obj_t arg1310_472;
									   {
									      obj_t arg1316_477;
									      obj_t arg1319_478;
									      obj_t arg1321_479;
									      arg1316_477 = CNST_TABLE_REF(((long) 6));
									      arg1319_478 = CAR(args_id_103_386);
									      {
										 obj_t arg1330_486;
										 obj_t arg1331_487;
										 arg1330_486 = CNST_TABLE_REF(((long) 7));
										 arg1331_487 = (((global_t) CREF(holder_390))->id);
										 {
										    obj_t list1333_489;
										    {
										       obj_t arg1334_490;
										       {
											  obj_t arg1337_491;
											  arg1337_491 = MAKE_PAIR(BNIL, BNIL);
											  arg1334_490 = MAKE_PAIR(module_391, arg1337_491);
										       }
										       list1333_489 = MAKE_PAIR(arg1331_487, arg1334_490);
										    }
										    arg1321_479 = cons__138___r4_pairs_and_lists_6_3(arg1330_486, list1333_489);
										 }
									      }
									      {
										 obj_t list1323_481;
										 {
										    obj_t arg1324_482;
										    {
										       obj_t arg1325_483;
										       {
											  obj_t arg1326_484;
											  arg1326_484 = MAKE_PAIR(BNIL, BNIL);
											  arg1325_483 = MAKE_PAIR(arg1321_479, arg1326_484);
										       }
										       arg1324_482 = MAKE_PAIR(id_383, arg1325_483);
										    }
										    list1323_481 = MAKE_PAIR(arg1319_478, arg1324_482);
										 }
										 arg1310_472 = cons__138___r4_pairs_and_lists_6_3(arg1316_477, list1323_481);
									      }
									   }
									   {
									      obj_t list1312_474;
									      {
										 obj_t arg1313_475;
										 arg1313_475 = MAKE_PAIR(BNIL, BNIL);
										 list1312_474 = MAKE_PAIR(arg1310_472, arg1313_475);
									      }
									      arg1304_468 = cons__138___r4_pairs_and_lists_6_3(method_384, list1312_474);
									   }
									}
									{
									   obj_t list1308_470;
									   list1308_470 = MAKE_PAIR(BNIL, BNIL);
									   arg1297_461 = cons__138___r4_pairs_and_lists_6_3(arg1304_468, list1308_470);
									}
								     }
								     {
									obj_t arg1340_493;
									obj_t arg1342_494;
									obj_t arg1343_495;
									obj_t arg1344_496;
									arg1340_493 = CNST_TABLE_REF(((long) 8));
									{
									   obj_t arg1352_503;
									   arg1352_503 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1354_505;
									      {
										 obj_t arg1355_506;
										 arg1355_506 = MAKE_PAIR(BNIL, BNIL);
										 list1354_505 = MAKE_PAIR(method_384, arg1355_506);
									      }
									      arg1342_494 = cons__138___r4_pairs_and_lists_6_3(arg1352_503, list1354_505);
									   }
									}
									{
									   bool_t test_964;
									   {
									      long aux_965;
									      aux_965 = (long) (arity_385);
									      test_964 = (aux_965 >= ((long) 0));
									   }
									   if (test_964)
									     {
										obj_t arg1361_509;
										{
										   obj_t arg1364_512;
										   arg1364_512 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
										   arg1361_509 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_386, arg1364_512);
										}
										{
										   obj_t list1362_510;
										   list1362_510 = MAKE_PAIR(arg1361_509, BNIL);
										   arg1343_495 = cons__138___r4_pairs_and_lists_6_3(method_384, list1362_510);
										}
									     }
									   else
									     {
										obj_t arg1367_515;
										obj_t arg1368_516;
										arg1367_515 = CNST_TABLE_REF(((long) 10));
										{
										   obj_t arg1378_522;
										   obj_t arg1379_523;
										   arg1378_522 = CNST_TABLE_REF(((long) 11));
										   {
										      obj_t arg1383_526;
										      arg1383_526 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
										      arg1379_523 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_386, arg1383_526);
										   }
										   {
										      obj_t list1380_524;
										      list1380_524 = MAKE_PAIR(arg1379_523, BNIL);
										      arg1368_516 = cons__138___r4_pairs_and_lists_6_3(arg1378_522, list1380_524);
										   }
										}
										{
										   obj_t list1370_518;
										   {
										      obj_t arg1372_519;
										      {
											 obj_t arg1373_520;
											 arg1373_520 = MAKE_PAIR(BNIL, BNIL);
											 arg1372_519 = MAKE_PAIR(arg1368_516, arg1373_520);
										      }
										      list1370_518 = MAKE_PAIR(method_384, arg1372_519);
										   }
										   arg1343_495 = cons__138___r4_pairs_and_lists_6_3(arg1367_515, list1370_518);
										}
									     }
									}
									{
									   obj_t arg1387_529;
									   obj_t arg1388_530;
									   obj_t arg1389_531;
									   arg1387_529 = CNST_TABLE_REF(((long) 12));
									   {
									      obj_t arg1396_537;
									      arg1396_537 = CNST_TABLE_REF(((long) 13));
									      {
										 obj_t list1398_539;
										 {
										    obj_t arg1399_540;
										    {
										       obj_t arg1401_541;
										       arg1401_541 = MAKE_PAIR(BNIL, BNIL);
										       arg1399_540 = MAKE_PAIR(method_384, arg1401_541);
										    }
										    list1398_539 = MAKE_PAIR(id_383, arg1399_540);
										 }
										 arg1388_530 = cons__138___r4_pairs_and_lists_6_3(arg1396_537, list1398_539);
									      }
									   }
									   {
									      bool_t test_988;
									      {
										 long aux_989;
										 aux_989 = (long) (arity_385);
										 test_988 = (aux_989 >= ((long) 0));
									      }
									      if (test_988)
										{
										   obj_t arg1405_544;
										   {
										      obj_t arg1408_547;
										      arg1408_547 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
										      arg1405_544 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_386, arg1408_547);
										   }
										   {
										      obj_t list1406_545;
										      list1406_545 = MAKE_PAIR(arg1405_544, BNIL);
										      arg1389_531 = cons__138___r4_pairs_and_lists_6_3(id_383, list1406_545);
										   }
										}
									      else
										{
										   obj_t arg1413_550;
										   obj_t arg1414_551;
										   arg1413_550 = CNST_TABLE_REF(((long) 10));
										   {
										      obj_t arg1421_557;
										      obj_t arg1423_558;
										      arg1421_557 = CNST_TABLE_REF(((long) 11));
										      {
											 obj_t arg1427_561;
											 arg1427_561 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
											 arg1423_558 = append_2_18___r4_pairs_and_lists_6_3(args_id_103_386, arg1427_561);
										      }
										      {
											 obj_t list1424_559;
											 list1424_559 = MAKE_PAIR(arg1423_558, BNIL);
											 arg1414_551 = cons__138___r4_pairs_and_lists_6_3(arg1421_557, list1424_559);
										      }
										   }
										   {
										      obj_t list1416_553;
										      {
											 obj_t arg1417_554;
											 {
											    obj_t arg1418_555;
											    arg1418_555 = MAKE_PAIR(BNIL, BNIL);
											    arg1417_554 = MAKE_PAIR(arg1414_551, arg1418_555);
											 }
											 list1416_553 = MAKE_PAIR(id_383, arg1417_554);
										      }
										      arg1389_531 = cons__138___r4_pairs_and_lists_6_3(arg1413_550, list1416_553);
										   }
										}
									   }
									   {
									      obj_t list1391_533;
									      {
										 obj_t arg1392_534;
										 {
										    obj_t arg1393_535;
										    arg1393_535 = MAKE_PAIR(BNIL, BNIL);
										    arg1392_534 = MAKE_PAIR(arg1389_531, arg1393_535);
										 }
										 list1391_533 = MAKE_PAIR(arg1388_530, arg1392_534);
									      }
									      arg1344_496 = cons__138___r4_pairs_and_lists_6_3(arg1387_529, list1391_533);
									   }
									}
									{
									   obj_t list1346_498;
									   {
									      obj_t arg1347_499;
									      {
										 obj_t arg1349_500;
										 {
										    obj_t arg1350_501;
										    arg1350_501 = MAKE_PAIR(BNIL, BNIL);
										    arg1349_500 = MAKE_PAIR(arg1344_496, arg1350_501);
										 }
										 arg1347_499 = MAKE_PAIR(arg1343_495, arg1349_500);
									      }
									      list1346_498 = MAKE_PAIR(arg1342_494, arg1347_499);
									   }
									   arg1298_462 = cons__138___r4_pairs_and_lists_6_3(arg1340_493, list1346_498);
									}
								     }
								     {
									obj_t list1300_464;
									{
									   obj_t arg1301_465;
									   {
									      obj_t arg1302_466;
									      arg1302_466 = MAKE_PAIR(BNIL, BNIL);
									      arg1301_465 = MAKE_PAIR(arg1298_462, arg1302_466);
									   }
									   list1300_464 = MAKE_PAIR(arg1297_461, arg1301_465);
									}
									arg1288_454 = cons__138___r4_pairs_and_lists_6_3(arg1296_460, list1300_464);
								     }
								  }
								  {
								     obj_t list1291_456;
								     {
									obj_t arg1292_457;
									{
									   obj_t arg1294_458;
									   arg1294_458 = MAKE_PAIR(BNIL, BNIL);
									   arg1292_457 = MAKE_PAIR(arg1288_454, arg1294_458);
									}
									list1291_456 = MAKE_PAIR(BNIL, arg1292_457);
								     }
								     arg1282_448 = cons__138___r4_pairs_and_lists_6_3(arg1286_452, list1291_456);
								  }
							       }
							       {
								  obj_t list1284_450;
								  list1284_450 = MAKE_PAIR(BNIL, BNIL);
								  arg1272_442 = cons__138___r4_pairs_and_lists_6_3(arg1282_448, list1284_450);
							       }
							    }
							    {
							       obj_t list1274_444;
							       {
								  obj_t arg1277_445;
								  {
								     obj_t arg1278_446;
								     arg1278_446 = MAKE_PAIR(BNIL, BNIL);
								     arg1277_445 = MAKE_PAIR(body_4, arg1278_446);
								  }
								  list1274_444 = MAKE_PAIR(arg1272_442, arg1277_445);
							       }
							       body_395 = cons__138___r4_pairs_and_lists_6_3(arg1270_441, list1274_444);
							    }
							 }
							 {
							    obj_t ebody_396;
							    {
							       bool_t test1266_437;
							       test1266_437 = EXTENDED_PAIRP(src_5);
							       if (test1266_437)
								 {
								    obj_t arg1267_438;
								    obj_t arg1268_439;
								    obj_t arg1269_440;
								    arg1267_438 = CAR(body_395);
								    arg1268_439 = CDR(body_395);
								    {
								       bool_t test1137_792;
								       test1137_792 = EXTENDED_PAIRP(src_5);
								       if (test1137_792)
									 {
									    arg1269_440 = CER(src_5);
									 }
								       else
									 {
									    FAILURE(string1523_object_method, string1524_object_method, src_5);
									 }
								    }
								    ebody_396 = MAKE_EXTENDED_PAIR(arg1267_438, arg1268_439, arg1269_440);
								 }
							       else
								 {
								    ebody_396 = body_395;
								 }
							    }
							    {
							       obj_t bdg_397;
							       {
								  obj_t list1261_433;
								  {
								     obj_t arg1262_434;
								     {
									obj_t arg1263_435;
									arg1263_435 = MAKE_PAIR(BNIL, BNIL);
									arg1262_434 = MAKE_PAIR(ebody_396, arg1263_435);
								     }
								     list1261_433 = MAKE_PAIR(args_2, arg1262_434);
								  }
								  bdg_397 = cons__138___r4_pairs_and_lists_6_3(m_id_75_388, list1261_433);
							       }
							       {
								  obj_t ebdg_398;
								  {
								     bool_t test1256_428;
								     test1256_428 = EXTENDED_PAIRP(src_5);
								     if (test1256_428)
								       {
									  obj_t arg1257_429;
									  obj_t arg1258_430;
									  obj_t arg1259_431;
									  arg1257_429 = CAR(bdg_397);
									  arg1258_430 = CDR(bdg_397);
									  {
									     bool_t test1137_804;
									     test1137_804 = EXTENDED_PAIRP(src_5);
									     if (test1137_804)
									       {
										  arg1259_431 = CER(src_5);
									       }
									     else
									       {
										  FAILURE(string1523_object_method, string1524_object_method, src_5);
									       }
									  }
									  ebdg_398 = MAKE_EXTENDED_PAIR(arg1257_429, arg1258_430, arg1259_431);
								       }
								     else
								       {
									  ebdg_398 = bdg_397;
								       }
								  }
								  {
								     {
									obj_t arg1219_399;
									{
									   obj_t arg1222_402;
									   obj_t arg1224_403;
									   obj_t arg1225_404;
									   arg1222_402 = CNST_TABLE_REF(((long) 3));
									   {
									      obj_t list1234_411;
									      list1234_411 = MAKE_PAIR(BNIL, BNIL);
									      arg1224_403 = cons__138___r4_pairs_and_lists_6_3(ebdg_398, list1234_411);
									   }
									   {
									      obj_t arg1236_413;
									      obj_t arg1238_414;
									      arg1236_413 = CNST_TABLE_REF(((long) 14));
									      {
										 obj_t arg1248_421;
										 obj_t arg1250_422;
										 arg1248_421 = CNST_TABLE_REF(((long) 7));
										 arg1250_422 = (((global_t) CREF(holder_390))->id);
										 {
										    obj_t list1252_424;
										    {
										       obj_t arg1253_425;
										       {
											  obj_t arg1254_426;
											  arg1254_426 = MAKE_PAIR(BNIL, BNIL);
											  arg1253_425 = MAKE_PAIR(module_391, arg1254_426);
										       }
										       list1252_424 = MAKE_PAIR(arg1250_422, arg1253_425);
										    }
										    arg1238_414 = cons__138___r4_pairs_and_lists_6_3(arg1248_421, list1252_424);
										 }
									      }
									      {
										 obj_t list1241_416;
										 {
										    obj_t arg1243_417;
										    {
										       obj_t arg1244_418;
										       {
											  obj_t arg1245_419;
											  arg1245_419 = MAKE_PAIR(BNIL, BNIL);
											  arg1244_418 = MAKE_PAIR(m_id_75_388, arg1245_419);
										       }
										       arg1243_417 = MAKE_PAIR(arg1238_414, arg1244_418);
										    }
										    list1241_416 = MAKE_PAIR(id_383, arg1243_417);
										 }
										 arg1225_404 = cons__138___r4_pairs_and_lists_6_3(arg1236_413, list1241_416);
									      }
									   }
									   {
									      obj_t list1227_406;
									      {
										 obj_t arg1228_407;
										 {
										    obj_t arg1231_408;
										    arg1231_408 = MAKE_PAIR(BNIL, BNIL);
										    arg1228_407 = MAKE_PAIR(arg1225_404, arg1231_408);
										 }
										 list1227_406 = MAKE_PAIR(arg1224_403, arg1228_407);
									      }
									      arg1219_399 = cons__138___r4_pairs_and_lists_6_3(arg1222_402, list1227_406);
									   }
									}
									{
									   obj_t list1220_400;
									   list1220_400 = MAKE_PAIR(arg1219_399, BNIL);
									   return list1220_400;
									}
								     }
								  }
							       }
							    }
							 }
						      }
						   }
						 else
						   {
						      add_generic_for_method_inlining__147_object_inline(generic_392);
						      {
							 long num_564;
							 num_564 = add_generic_method__111_object_inline((global_t) (generic_392), type_387, args_2, body_4);
							 {
							    obj_t arg1431_565;
							    {
							       obj_t arg1436_568;
							       obj_t arg1437_569;
							       arg1436_568 = CNST_TABLE_REF(((long) 15));
							       {
								  obj_t arg1446_576;
								  obj_t arg1448_577;
								  arg1446_576 = CNST_TABLE_REF(((long) 7));
								  arg1448_577 = (((global_t) CREF(holder_390))->id);
								  {
								     obj_t list1450_579;
								     {
									obj_t arg1453_580;
									{
									   obj_t arg1454_581;
									   arg1454_581 = MAKE_PAIR(BNIL, BNIL);
									   arg1453_580 = MAKE_PAIR(module_391, arg1454_581);
									}
									list1450_579 = MAKE_PAIR(arg1448_577, arg1453_580);
								     }
								     arg1437_569 = cons__138___r4_pairs_and_lists_6_3(arg1446_576, list1450_579);
								  }
							       }
							       {
								  obj_t list1439_571;
								  {
								     obj_t arg1440_572;
								     {
									obj_t arg1441_573;
									{
									   obj_t arg1443_574;
									   arg1443_574 = MAKE_PAIR(BNIL, BNIL);
									   {
									      obj_t aux_1082;
									      aux_1082 = BINT(num_564);
									      arg1441_573 = MAKE_PAIR(aux_1082, arg1443_574);
									   }
									}
									arg1440_572 = MAKE_PAIR(arg1437_569, arg1441_573);
								     }
								     list1439_571 = MAKE_PAIR(id_383, arg1440_572);
								  }
								  arg1431_565 = cons__138___r4_pairs_and_lists_6_3(arg1436_568, list1439_571);
							       }
							    }
							    {
							       obj_t list1432_566;
							       list1432_566 = MAKE_PAIR(arg1431_565, BNIL);
							       return list1432_566;
							    }
							 }
						      }
						   }
					      }
					    else
					      {
						 return method_error_85_object_method(id_383, "Can't find generic for method", src_5);
					      }
					 }
				      }
				   }
				}
			     }
			   else
			     {
				return method_error_85_object_method(id_383, "method has a non-class dispatching type arg", src_5);
			     }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* _make-method-body */ obj_t 
_make_method_body_16_object_method(obj_t env_841, obj_t id_842, obj_t args_843, obj_t locals_844, obj_t body_845, obj_t src_846)
{
   return make_method_body_103_object_method(id_842, args_843, locals_844, body_845, src_846);
}


/* method-error */ obj_t 
method_error_85_object_method(obj_t id_6, char *msg_7, obj_t src_8)
{
   {
      obj_t arg1481_611;
      {
	 obj_t list1485_615;
	 {
	    obj_t aux_1092;
	    aux_1092 = CNST_TABLE_REF(((long) 16));
	    list1485_615 = MAKE_PAIR(aux_1092, BNIL);
	 }
	 arg1481_611 = list1485_615;
      }
      {
	 obj_t list1482_612;
	 list1482_612 = MAKE_PAIR(arg1481_611, BNIL);
	 return user_error_151_tools_error(id_6, string_to_bstring(msg_7), src_8, list1482_612);
      }
   }
}


/* method-init */ obj_t 
method_init_76_object_method()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_method()
{
   module_initialization_70_tools_args(((long) 0), "OBJECT_METHOD");
   module_initialization_70_tools_error(((long) 0), "OBJECT_METHOD");
   module_initialization_70_tools_misc(((long) 0), "OBJECT_METHOD");
   module_initialization_70_type_type(((long) 0), "OBJECT_METHOD");
   module_initialization_70_ast_var(((long) 0), "OBJECT_METHOD");
   module_initialization_70_ast_ident(((long) 0), "OBJECT_METHOD");
   module_initialization_70_ast_env(((long) 0), "OBJECT_METHOD");
   module_initialization_70_object_class(((long) 0), "OBJECT_METHOD");
   return module_initialization_70_object_inline(((long) 0), "OBJECT_METHOD");
}
