/*===========================================================================*/
/*   (Fail/walk.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_fail_walk();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t current_error_port;
extern obj_t fail_ast_node;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t box_ref_242_ast_node;
extern obj_t leave_function_170_tools_error();
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t fail_fun__97_fail_walk(obj_t);
extern obj_t location_full_fname_231_tools_location(obj_t);
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
static obj_t _error__173_fail_walk = BUNSPEC;
extern obj_t module_initialization_70_fail_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _fail_node_1771_96_fail_walk(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t _fail_node__default1454_76_fail_walk(obj_t, obj_t);
static obj_t fail_node___231_fail_walk(obj_t);
static obj_t imported_modules_init_94_fail_walk();
extern obj_t app_ly_162_ast_node;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t fail_walk__172_fail_walk(obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_fail_walk();
extern obj_t atom_ast_node;
static obj_t toplevel_init_63_fail_walk();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
static node_t fail_node__137_fail_walk(node_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t string_to_bstring(char *);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t _fail_walk__150_fail_walk(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static node_t fail_node__default1454_236_fail_walk(node_t);
static obj_t require_initialization_114_fail_walk = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_fail_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[6];

DEFINE_STATIC_PROCEDURE(fail_node__default1454_env_94_fail_walk, _fail_node__default1454_76_fail_walk1785, _fail_node__default1454_76_fail_walk, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fail_walk__env_224_fail_walk, _fail_walk__150_fail_walk1786, _fail_walk__150_fail_walk, 0L, 1);
DEFINE_STRING(string1779_fail_walk, string1779_fail_walk1787, "FAIL-NODE!-DEFAULT1454 VALUE DEBUG-ERROR/LOCATION LOCATION DONE PASS-STARTED ", 77);
DEFINE_STRING(string1778_fail_walk, string1778_fail_walk1788, "No method for this object", 25);
DEFINE_STRING(string1777_fail_walk, string1777_fail_walk1789, "failure during postlude hook", 28);
DEFINE_STRING(string1776_fail_walk, string1776_fail_walk1790, " error", 6);
DEFINE_STRING(string1775_fail_walk, string1775_fail_walk1791, " occured, ending ...", 20);
DEFINE_STRING(string1774_fail_walk, string1774_fail_walk1792, "failure during prelude hook", 27);
DEFINE_STRING(string1773_fail_walk, string1773_fail_walk1793, "   . ", 5);
DEFINE_STRING(string1772_fail_walk, string1772_fail_walk1794, "Fail", 4);
DEFINE_STATIC_GENERIC(fail_node__env_77_fail_walk, _fail_node_1771_96_fail_walk1795, _fail_node_1771_96_fail_walk, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_fail_walk(long checksum_1459, char *from_1460)
{
   if (CBOOL(require_initialization_114_fail_walk))
     {
	require_initialization_114_fail_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_fail_walk();
	cnst_init_137_fail_walk();
	imported_modules_init_94_fail_walk();
	method_init_76_fail_walk();
	toplevel_init_63_fail_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_fail_walk()
{
   module_initialization_70___object(((long) 0), "FAIL_WALK");
   module_initialization_70___r4_output_6_10_3(((long) 0), "FAIL_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "FAIL_WALK");
   module_initialization_70___reader(((long) 0), "FAIL_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "FAIL_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_fail_walk()
{
   {
      obj_t cnst_port_138_1451;
      cnst_port_138_1451 = open_input_string(string1779_fail_walk);
      {
	 long i_1452;
	 i_1452 = ((long) 5);
       loop_1453:
	 {
	    bool_t test1780_1454;
	    test1780_1454 = (i_1452 == ((long) -1));
	    if (test1780_1454)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1781_1455;
		    {
		       obj_t list1782_1456;
		       {
			  obj_t arg1783_1457;
			  arg1783_1457 = BNIL;
			  list1782_1456 = MAKE_PAIR(cnst_port_138_1451, arg1783_1457);
		       }
		       arg1781_1455 = read___reader(list1782_1456);
		    }
		    CNST_TABLE_SET(i_1452, arg1781_1455);
		 }
		 {
		    int aux_1458;
		    {
		       long aux_1480;
		       aux_1480 = (i_1452 - ((long) 1));
		       aux_1458 = (int) (aux_1480);
		    }
		    {
		       long i_1483;
		       i_1483 = (long) (aux_1458);
		       i_1452 = i_1483;
		       goto loop_1453;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_fail_walk()
{
   _error__173_fail_walk = BUNSPEC;
   return BUNSPEC;
}


/* fail-walk! */ obj_t 
fail_walk__172_fail_walk(obj_t globals_15)
{
   {
      obj_t list1495_747;
      {
	 obj_t arg1497_749;
	 {
	    obj_t arg1499_751;
	    {
	       obj_t aux_1485;
	       aux_1485 = BCHAR(((unsigned char) '\n'));
	       arg1499_751 = MAKE_PAIR(aux_1485, BNIL);
	    }
	    arg1497_749 = MAKE_PAIR(string1772_fail_walk, arg1499_751);
	 }
	 list1495_747 = MAKE_PAIR(string1773_fail_walk, arg1497_749);
      }
      verbose_tools_speek(BINT(((long) 1)), list1495_747);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1772_fail_walk;
   {
      obj_t hooks_753;
      obj_t hnames_754;
      hooks_753 = BNIL;
      hnames_754 = BNIL;
    loop_755:
      if (NULLP(hooks_753))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1505_760;
	   {
	      obj_t fun1515_766;
	      fun1515_766 = CAR(hooks_753);
	      {
		 obj_t aux_1497;
		 aux_1497 = PROCEDURE_ENTRY(fun1515_766) (fun1515_766, BEOA);
		 test1505_760 = CBOOL(aux_1497);
	      }
	   }
	   if (test1505_760)
	     {
		{
		   obj_t hnames_1504;
		   obj_t hooks_1502;
		   hooks_1502 = CDR(hooks_753);
		   hnames_1504 = CDR(hnames_754);
		   hnames_754 = hnames_1504;
		   hooks_753 = hooks_1502;
		   goto loop_755;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1772_fail_walk, string1774_fail_walk, CAR(hnames_754));
	     }
	}
   }
   {
      obj_t l1435_767;
      l1435_767 = globals_15;
    lname1436_768:
      if (PAIRP(l1435_767))
	{
	   fail_fun__97_fail_walk(CAR(l1435_767));
	   {
	      obj_t l1435_1512;
	      l1435_1512 = CDR(l1435_767);
	      l1435_767 = l1435_1512;
	      goto lname1436_768;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      bool_t test1519_773;
      {
	 long n1_1295;
	 n1_1295 = (long) CINT(_nb_error_on_pass__70_tools_error);
	 test1519_773 = (n1_1295 > ((long) 0));
      }
      if (test1519_773)
	{
	   {
	      char *arg1525_776;
	      {
		 bool_t test1532_783;
		 {
		    bool_t test1533_784;
		    {
		       obj_t obj_1297;
		       obj_1297 = _nb_error_on_pass__70_tools_error;
		       test1533_784 = INTEGERP(obj_1297);
		    }
		    if (test1533_784)
		      {
			 test1532_783 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
		      }
		    else
		      {
			 test1532_783 = ((bool_t) 0);
		      }
		 }
		 if (test1532_783)
		   {
		      arg1525_776 = "s";
		   }
		 else
		   {
		      arg1525_776 = "";
		   }
	      }
	      {
		 obj_t list1527_778;
		 {
		    obj_t arg1528_779;
		    {
		       obj_t arg1529_780;
		       {
			  obj_t arg1530_781;
			  arg1530_781 = MAKE_PAIR(string1775_fail_walk, BNIL);
			  {
			     obj_t aux_1523;
			     aux_1523 = string_to_bstring(arg1525_776);
			     arg1529_780 = MAKE_PAIR(aux_1523, arg1530_781);
			  }
		       }
		       arg1528_779 = MAKE_PAIR(string1776_fail_walk, arg1529_780);
		    }
		    list1527_778 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1528_779);
		 }
		 fprint___r4_output_6_10_3(current_error_port, list1527_778);
	      }
	   }
	   {
	      obj_t res1769_1299;
	      exit(((long) -1));
	      res1769_1299 = BINT(((long) -1));
	      return res1769_1299;
	   }
	}
      else
	{
	   obj_t hooks_785;
	   obj_t hnames_786;
	   hooks_785 = BNIL;
	   hnames_786 = BNIL;
	 loop_787:
	   if (NULLP(hooks_785))
	     {
		return globals_15;
	     }
	   else
	     {
		bool_t test1538_792;
		{
		   obj_t fun1546_797;
		   fun1546_797 = CAR(hooks_785);
		   {
		      obj_t aux_1534;
		      aux_1534 = PROCEDURE_ENTRY(fun1546_797) (fun1546_797, BEOA);
		      test1538_792 = CBOOL(aux_1534);
		   }
		}
		if (test1538_792)
		  {
		     {
			obj_t hnames_1541;
			obj_t hooks_1539;
			hooks_1539 = CDR(hooks_785);
			hnames_1541 = CDR(hnames_786);
			hnames_786 = hnames_1541;
			hooks_785 = hooks_1539;
			goto loop_787;
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1777_fail_walk, CAR(hnames_786));
		  }
	     }
	}
   }
}


/* _fail-walk! */ obj_t 
_fail_walk__150_fail_walk(obj_t env_1444, obj_t globals_1445)
{
   return fail_walk__172_fail_walk(globals_1445);
}


/* fail-fun! */ obj_t 
fail_fun__97_fail_walk(obj_t var_16)
{
   {
      value_t fun_798;
      {
	 variable_t obj_1306;
	 obj_1306 = (variable_t) (var_16);
	 fun_798 = (((variable_t) CREF(obj_1306))->value);
      }
      {
	 obj_t body_799;
	 {
	    sfun_t obj_1307;
	    obj_1307 = (sfun_t) (fun_798);
	    body_799 = (((sfun_t) CREF(obj_1307))->body);
	 }
	 {
	    {
	       obj_t aux_1550;
	       {
		  variable_t obj_1309;
		  obj_1309 = (variable_t) (var_16);
		  aux_1550 = (((variable_t) CREF(obj_1309))->id);
	       }
	       enter_function_81_tools_error(aux_1550);
	    }
	    {
	       node_t arg1549_802;
	       arg1549_802 = fail_node__137_fail_walk((node_t) (body_799));
	       {
		  sfun_t obj_1310;
		  obj_t val1135_1311;
		  obj_1310 = (sfun_t) (fun_798);
		  val1135_1311 = (obj_t) (arg1549_802);
		  ((((sfun_t) CREF(obj_1310))->body) = ((obj_t) val1135_1311), BUNSPEC);
	       }
	    }
	    return leave_function_170_tools_error();
	 }
      }
   }
}


/* fail-node*! */ obj_t 
fail_node___231_fail_walk(obj_t node__221_38)
{
 fail_node___231_fail_walk:
   if (NULLP(node__221_38))
     {
	return CNST_TABLE_REF(((long) 1));
     }
   else
     {
	{
	   node_t arg1552_804;
	   {
	      node_t aux_1563;
	      {
		 obj_t aux_1564;
		 aux_1564 = CAR(node__221_38);
		 aux_1563 = (node_t) (aux_1564);
	      }
	      arg1552_804 = fail_node__137_fail_walk(aux_1563);
	   }
	   {
	      obj_t aux_1568;
	      aux_1568 = (obj_t) (arg1552_804);
	      SET_CAR(node__221_38, aux_1568);
	   }
	}
	{
	   obj_t node__221_1571;
	   node__221_1571 = CDR(node__221_38);
	   node__221_38 = node__221_1571;
	   goto fail_node___231_fail_walk;
	}
     }
}


/* method-init */ obj_t 
method_init_76_fail_walk()
{
   add_generic__110___object(fail_node__env_77_fail_walk, fail_node__default1454_env_94_fail_walk);
   add_inlined_method__244___object(fail_node__env_77_fail_walk, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, var_ast_node, ((long) 2));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, app_ast_node, ((long) 4));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, setq_ast_node, ((long) 8));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, conditional_ast_node, ((long) 9));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, fail_ast_node, ((long) 10));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, select_ast_node, ((long) 11));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, let_fun_218_ast_node, ((long) 12));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, let_var_6_ast_node, ((long) 13));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, set_ex_it_116_ast_node, ((long) 14));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, jump_ex_it_184_ast_node, ((long) 15));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, make_box_202_ast_node, ((long) 16));
   add_inlined_method__244___object(fail_node__env_77_fail_walk, box_ref_242_ast_node, ((long) 17));
   {
      long aux_1592;
      aux_1592 = add_inlined_method__244___object(fail_node__env_77_fail_walk, box_set__221_ast_node, ((long) 18));
      return BINT(aux_1592);
   }
}


/* fail-node! */ node_t 
fail_node__137_fail_walk(node_t node_17)
{
   {
      obj_t method1655_1138;
      obj_t class1660_1139;
      {
	 obj_t arg1663_1136;
	 obj_t arg1665_1137;
	 {
	    object_t obj_1317;
	    obj_1317 = (object_t) (node_17);
	    {
	       obj_t pre_method_105_1318;
	       pre_method_105_1318 = PROCEDURE_REF(fail_node__env_77_fail_walk, ((long) 2));
	       if (INTEGERP(pre_method_105_1318))
		 {
		    PROCEDURE_SET(fail_node__env_77_fail_walk, ((long) 2), BUNSPEC);
		    arg1663_1136 = pre_method_105_1318;
		 }
	       else
		 {
		    long obj_class_num_177_1323;
		    obj_class_num_177_1323 = TYPE(obj_1317);
		    {
		       obj_t arg1177_1324;
		       arg1177_1324 = PROCEDURE_REF(fail_node__env_77_fail_walk, ((long) 1));
		       {
			  long arg1178_1328;
			  {
			     long arg1179_1329;
			     arg1179_1329 = OBJECT_TYPE;
			     arg1178_1328 = (obj_class_num_177_1323 - arg1179_1329);
			  }
			  arg1663_1136 = VECTOR_REF(arg1177_1324, arg1178_1328);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1334;
	    object_1334 = (object_t) (node_17);
	    {
	       long arg1180_1335;
	       {
		  long arg1181_1336;
		  long arg1182_1337;
		  arg1181_1336 = TYPE(object_1334);
		  arg1182_1337 = OBJECT_TYPE;
		  arg1180_1335 = (arg1181_1336 - arg1182_1337);
	       }
	       {
		  obj_t vector_1341;
		  vector_1341 = _classes__134___object;
		  arg1665_1137 = VECTOR_REF(vector_1341, arg1180_1335);
	       }
	    }
	 }
	 {
	    obj_t aux_1610;
	    method1655_1138 = arg1663_1136;
	    class1660_1139 = arg1665_1137;
	    {
	       if (INTEGERP(method1655_1138))
		 {
		    switch ((long) CINT(method1655_1138))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_1613;
			    aux_1613 = (atom_t) (node_17);
			    aux_1610 = (obj_t) (aux_1613);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_1616;
			    aux_1616 = (kwote_t) (node_17);
			    aux_1610 = (obj_t) (aux_1616);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_1619;
			    aux_1619 = (var_t) (node_17);
			    aux_1610 = (obj_t) (aux_1619);
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1148;
			    node_1148 = (sequence_t) (node_17);
			    fail_node___231_fail_walk((((sequence_t) CREF(node_1148))->nodes));
			    aux_1610 = (obj_t) (node_1148);
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1150;
			    node_1150 = (app_t) (node_17);
			    fail_node___231_fail_walk((((app_t) CREF(node_1150))->args));
			    aux_1610 = (obj_t) (node_1150);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1153;
			    node_1153 = (app_ly_162_t) (node_17);
			    {
			       node_t arg1670_1155;
			       arg1670_1155 = fail_node__137_fail_walk((((app_ly_162_t) CREF(node_1153))->fun));
			       ((((app_ly_162_t) CREF(node_1153))->fun) = ((node_t) arg1670_1155), BUNSPEC);
			    }
			    {
			       node_t arg1673_1157;
			       arg1673_1157 = fail_node__137_fail_walk((((app_ly_162_t) CREF(node_1153))->arg));
			       ((((app_ly_162_t) CREF(node_1153))->arg) = ((node_t) arg1673_1157), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1153);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1159;
			    node_1159 = (funcall_t) (node_17);
			    {
			       node_t arg1676_1161;
			       arg1676_1161 = fail_node__137_fail_walk((((funcall_t) CREF(node_1159))->fun));
			       ((((funcall_t) CREF(node_1159))->fun) = ((node_t) arg1676_1161), BUNSPEC);
			    }
			    fail_node___231_fail_walk((((funcall_t) CREF(node_1159))->args));
			    aux_1610 = (obj_t) (node_1159);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1164;
			    node_1164 = (pragma_t) (node_17);
			    fail_node___231_fail_walk((((pragma_t) CREF(node_1164))->args));
			    aux_1610 = (obj_t) (node_1164);
			 }
			 break;
		      case ((long) 8):
			 {
			    setq_t node_1166;
			    node_1166 = (setq_t) (node_17);
			    {
			       node_t arg1680_1167;
			       arg1680_1167 = fail_node__137_fail_walk((((setq_t) CREF(node_1166))->value));
			       ((((setq_t) CREF(node_1166))->value) = ((node_t) arg1680_1167), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1166);
			 }
			 break;
		      case ((long) 9):
			 {
			    conditional_t node_1169;
			    node_1169 = (conditional_t) (node_17);
			    {
			       node_t arg1682_1171;
			       arg1682_1171 = fail_node__137_fail_walk((((conditional_t) CREF(node_1169))->test));
			       ((((conditional_t) CREF(node_1169))->test) = ((node_t) arg1682_1171), BUNSPEC);
			    }
			    {
			       node_t arg1684_1173;
			       arg1684_1173 = fail_node__137_fail_walk((((conditional_t) CREF(node_1169))->true));
			       ((((conditional_t) CREF(node_1169))->true) = ((node_t) arg1684_1173), BUNSPEC);
			    }
			    {
			       node_t arg1686_1175;
			       arg1686_1175 = fail_node__137_fail_walk((((conditional_t) CREF(node_1169))->false));
			       ((((conditional_t) CREF(node_1169))->false) = ((node_t) arg1686_1175), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1169);
			 }
			 break;
		      case ((long) 10):
			 {
			    fail_t node_1177;
			    node_1177 = (fail_t) (node_17);
			    {
			       node_t arg1689_1179;
			       arg1689_1179 = fail_node__137_fail_walk((((fail_t) CREF(node_1177))->proc));
			       ((((fail_t) CREF(node_1177))->proc) = ((node_t) arg1689_1179), BUNSPEC);
			    }
			    {
			       node_t arg1692_1181;
			       arg1692_1181 = fail_node__137_fail_walk((((fail_t) CREF(node_1177))->msg));
			       ((((fail_t) CREF(node_1177))->msg) = ((node_t) arg1692_1181), BUNSPEC);
			    }
			    {
			       node_t arg1694_1183;
			       arg1694_1183 = fail_node__137_fail_walk((((fail_t) CREF(node_1177))->obj));
			       ((((fail_t) CREF(node_1177))->obj) = ((node_t) arg1694_1183), BUNSPEC);
			    }
			    {
			       bool_t test_1675;
			       {
				  obj_t arg1718_1206;
				  arg1718_1206 = (((fail_t) CREF(node_1177))->loc);
				  if (STRUCTP(arg1718_1206))
				    {
				       obj_t aux_1681;
				       obj_t aux_1679;
				       aux_1681 = CNST_TABLE_REF(((long) 2));
				       aux_1679 = STRUCT_KEY(arg1718_1206);
				       test_1675 = (aux_1679 == aux_1681);
				    }
				  else
				    {
				       test_1675 = ((bool_t) 0);
				    }
			       }
			       if (test_1675)
				 {
				    obj_t arg1697_1186;
				    obj_t arg1699_1188;
				    obj_t arg1700_1189;
				    {
				       obj_t arg1701_1190;
				       node_t arg1702_1191;
				       node_t arg1703_1192;
				       node_t arg1704_1193;
				       obj_t arg1705_1194;
				       obj_t arg1706_1195;
				       arg1701_1190 = CNST_TABLE_REF(((long) 3));
				       arg1702_1191 = (((fail_t) CREF(node_1177))->proc);
				       arg1703_1192 = (((fail_t) CREF(node_1177))->msg);
				       arg1704_1193 = (((fail_t) CREF(node_1177))->obj);
				       arg1705_1194 = location_full_fname_231_tools_location((((fail_t) CREF(node_1177))->loc));
				       {
					  obj_t aux_1690;
					  aux_1690 = (((fail_t) CREF(node_1177))->loc);
					  arg1706_1195 = STRUCT_REF(aux_1690, ((long) 1));
				       }
				       {
					  obj_t list1708_1197;
					  {
					     obj_t arg1709_1198;
					     {
						obj_t arg1710_1199;
						{
						   obj_t arg1711_1200;
						   {
						      obj_t arg1712_1201;
						      {
							 obj_t arg1713_1202;
							 arg1713_1202 = MAKE_PAIR(BNIL, BNIL);
							 arg1712_1201 = MAKE_PAIR(arg1706_1195, arg1713_1202);
						      }
						      arg1711_1200 = MAKE_PAIR(arg1705_1194, arg1712_1201);
						   }
						   {
						      obj_t aux_1696;
						      aux_1696 = (obj_t) (arg1704_1193);
						      arg1710_1199 = MAKE_PAIR(aux_1696, arg1711_1200);
						   }
						}
						{
						   obj_t aux_1699;
						   aux_1699 = (obj_t) (arg1703_1192);
						   arg1709_1198 = MAKE_PAIR(aux_1699, arg1710_1199);
						}
					     }
					     {
						obj_t aux_1702;
						aux_1702 = (obj_t) (arg1702_1191);
						list1708_1197 = MAKE_PAIR(aux_1702, arg1709_1198);
					     }
					  }
					  arg1697_1186 = cons__138___r4_pairs_and_lists_6_3(arg1701_1190, list1708_1197);
				       }
				    }
				    arg1699_1188 = (((fail_t) CREF(node_1177))->loc);
				    arg1700_1189 = CNST_TABLE_REF(((long) 4));
				    {
				       node_t aux_1708;
				       aux_1708 = sexp__node_235_ast_sexp(arg1697_1186, BNIL, arg1699_1188, arg1700_1189);
				       aux_1610 = (obj_t) (aux_1708);
				    }
				 }
			       else
				 {
				    aux_1610 = (obj_t) (node_1177);
				 }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    select_t node_1207;
			    node_1207 = (select_t) (node_17);
			    {
			       node_t arg1720_1209;
			       arg1720_1209 = fail_node__137_fail_walk((((select_t) CREF(node_1207))->test));
			       ((((select_t) CREF(node_1207))->test) = ((node_t) arg1720_1209), BUNSPEC);
			    }
			    {
			       obj_t l1443_1211;
			       l1443_1211 = (((select_t) CREF(node_1207))->clauses);
			     lname1444_1212:
			       if (PAIRP(l1443_1211))
				 {
				    {
				       obj_t clause_1215;
				       clause_1215 = CAR(l1443_1211);
				       {
					  node_t arg1724_1216;
					  {
					     node_t aux_1719;
					     {
						obj_t aux_1720;
						aux_1720 = CDR(clause_1215);
						aux_1719 = (node_t) (aux_1720);
					     }
					     arg1724_1216 = fail_node__137_fail_walk(aux_1719);
					  }
					  {
					     obj_t aux_1724;
					     aux_1724 = (obj_t) (arg1724_1216);
					     SET_CDR(clause_1215, aux_1724);
					  }
				       }
				    }
				    {
				       obj_t l1443_1727;
				       l1443_1727 = CDR(l1443_1211);
				       l1443_1211 = l1443_1727;
				       goto lname1444_1212;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1610 = (obj_t) (node_1207);
			 }
			 break;
		      case ((long) 12):
			 {
			    let_fun_218_t node_1219;
			    node_1219 = (let_fun_218_t) (node_17);
			    {
			       obj_t l1446_1221;
			       l1446_1221 = (((let_fun_218_t) CREF(node_1219))->locals);
			     lname1447_1222:
			       if (PAIRP(l1446_1221))
				 {
				    fail_fun__97_fail_walk(CAR(l1446_1221));
				    {
				       obj_t l1446_1736;
				       l1446_1736 = CDR(l1446_1221);
				       l1446_1221 = l1446_1736;
				       goto lname1447_1222;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1731_1227;
			       arg1731_1227 = fail_node__137_fail_walk((((let_fun_218_t) CREF(node_1219))->body));
			       ((((let_fun_218_t) CREF(node_1219))->body) = ((node_t) arg1731_1227), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1219);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_var_6_t node_1229;
			    node_1229 = (let_var_6_t) (node_17);
			    {
			       obj_t l1449_1231;
			       l1449_1231 = (((let_var_6_t) CREF(node_1229))->bindings);
			     lname1450_1232:
			       if (PAIRP(l1449_1231))
				 {
				    {
				       obj_t binding_1235;
				       binding_1235 = CAR(l1449_1231);
				       {
					  node_t arg1738_1236;
					  {
					     node_t aux_1747;
					     {
						obj_t aux_1748;
						aux_1748 = CDR(binding_1235);
						aux_1747 = (node_t) (aux_1748);
					     }
					     arg1738_1236 = fail_node__137_fail_walk(aux_1747);
					  }
					  {
					     obj_t aux_1752;
					     aux_1752 = (obj_t) (arg1738_1236);
					     SET_CDR(binding_1235, aux_1752);
					  }
				       }
				    }
				    {
				       obj_t l1449_1755;
				       l1449_1755 = CDR(l1449_1231);
				       l1449_1231 = l1449_1755;
				       goto lname1450_1232;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1743_1239;
			       arg1743_1239 = fail_node__137_fail_walk((((let_var_6_t) CREF(node_1229))->body));
			       ((((let_var_6_t) CREF(node_1229))->body) = ((node_t) arg1743_1239), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1229);
			 }
			 break;
		      case ((long) 14):
			 {
			    set_ex_it_116_t node_1241;
			    node_1241 = (set_ex_it_116_t) (node_17);
			    {
			       node_t arg1745_1242;
			       arg1745_1242 = fail_node__137_fail_walk((((set_ex_it_116_t) CREF(node_1241))->body));
			       ((((set_ex_it_116_t) CREF(node_1241))->body) = ((node_t) arg1745_1242), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1241);
			 }
			 break;
		      case ((long) 15):
			 {
			    jump_ex_it_184_t node_1244;
			    node_1244 = (jump_ex_it_184_t) (node_17);
			    {
			       node_t arg1747_1246;
			       arg1747_1246 = fail_node__137_fail_walk((((jump_ex_it_184_t) CREF(node_1244))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1244))->exit) = ((node_t) arg1747_1246), BUNSPEC);
			    }
			    {
			       node_t arg1749_1248;
			       arg1749_1248 = fail_node__137_fail_walk((((jump_ex_it_184_t) CREF(node_1244))->value));
			       ((((jump_ex_it_184_t) CREF(node_1244))->value) = ((node_t) arg1749_1248), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1244);
			 }
			 break;
		      case ((long) 16):
			 {
			    make_box_202_t node_1250;
			    node_1250 = (make_box_202_t) (node_17);
			    {
			       node_t arg1755_1251;
			       arg1755_1251 = fail_node__137_fail_walk((((make_box_202_t) CREF(node_1250))->value));
			       ((((make_box_202_t) CREF(node_1250))->value) = ((node_t) arg1755_1251), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1250);
			 }
			 break;
		      case ((long) 17):
			 {
			    box_ref_242_t aux_1780;
			    aux_1780 = (box_ref_242_t) (node_17);
			    aux_1610 = (obj_t) (aux_1780);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_set__221_t node_1254;
			    node_1254 = (box_set__221_t) (node_17);
			    {
			       node_t arg1759_1256;
			       arg1759_1256 = fail_node__137_fail_walk((((box_set__221_t) CREF(node_1254))->value));
			       ((((box_set__221_t) CREF(node_1254))->value) = ((node_t) arg1759_1256), BUNSPEC);
			    }
			    aux_1610 = (obj_t) (node_1254);
			 }
			 break;
		      default:
		       case_else1661_1142:
			 if (PROCEDUREP(method1655_1138))
			   {
			      aux_1610 = PROCEDURE_ENTRY(method1655_1138) (method1655_1138, (obj_t) (node_17), BEOA);
			   }
			 else
			   {
			      obj_t fun1650_1132;
			      fun1650_1132 = PROCEDURE_REF(fail_node__env_77_fail_walk, ((long) 0));
			      aux_1610 = PROCEDURE_ENTRY(fun1650_1132) (fun1650_1132, (obj_t) (node_17), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1661_1142;
		 }
	    }
	    return (node_t) (aux_1610);
	 }
      }
   }
}


/* _fail-node!1771 */ obj_t 
_fail_node_1771_96_fail_walk(obj_t env_1446, obj_t node_1447)
{
   {
      node_t aux_1800;
      aux_1800 = fail_node__137_fail_walk((node_t) (node_1447));
      return (obj_t) (aux_1800);
   }
}


/* fail-node!-default1454 */ node_t 
fail_node__default1454_236_fail_walk(node_t node_18)
{
   FAILURE(CNST_TABLE_REF(((long) 5)), string1778_fail_walk, (obj_t) (node_18));
}


/* _fail-node!-default1454 */ obj_t 
_fail_node__default1454_76_fail_walk(obj_t env_1448, obj_t node_1449)
{
   {
      node_t aux_1807;
      aux_1807 = fail_node__default1454_236_fail_walk((node_t) (node_1449));
      return (obj_t) (aux_1807);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_fail_walk()
{
   module_initialization_70_tools_speek(((long) 0), "FAIL_WALK");
   module_initialization_70_tools_error(((long) 0), "FAIL_WALK");
   module_initialization_70_engine_pass(((long) 0), "FAIL_WALK");
   module_initialization_70_type_type(((long) 0), "FAIL_WALK");
   module_initialization_70_ast_var(((long) 0), "FAIL_WALK");
   module_initialization_70_ast_node(((long) 0), "FAIL_WALK");
   module_initialization_70_tools_shape(((long) 0), "FAIL_WALK");
   module_initialization_70_tools_location(((long) 0), "FAIL_WALK");
   return module_initialization_70_ast_sexp(((long) 0), "FAIL_WALK");
}
