/*===========================================================================*/
/*   (Cgen/cgen.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct cop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *cop_t;

typedef struct clabel
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t name;
     bool_t used__226;
     obj_t body;
  }
      *clabel_t;

typedef struct cgoto
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct clabel *label;
  }
     *cgoto_t;

typedef struct block
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
     *block_t;

typedef struct creturn
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
       *creturn_t;

typedef struct cvoid
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
     *cvoid_t;

typedef struct catom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t value;
  }
     *catom_t;

typedef struct varc
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct variable *variable;
  }
    *varc_t;

typedef struct cpragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t format;
     obj_t args;
  }
       *cpragma_t;

typedef struct ccast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct cop *arg;
  }
     *ccast_t;

typedef struct csequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     bool_t c_exp__163;
     obj_t cops;
  }
         *csequence_t;

typedef struct nop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *nop_t;

typedef struct stop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
    *stop_t;

typedef struct csetq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct varc *var;
     struct cop *value;
  }
     *csetq_t;

typedef struct cif
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     struct cop *true;
     struct cop *false;
  }
   *cif_t;

typedef struct local_var_164
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t vars;
  }
             *local_var_164_t;

typedef struct cfuncall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
     obj_t strength;
  }
        *cfuncall_t;

typedef struct capply
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     struct cop *arg;
  }
      *capply_t;

typedef struct capp
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
  }
    *capp_t;

typedef struct cfail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *proc;
     struct cop *msg;
     struct cop *obj;
  }
     *cfail_t;

typedef struct cswitch
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     obj_t clauses;
  }
       *cswitch_t;

typedef struct cmake_box_177
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
             *cmake_box_177_t;

typedef struct cbox_ref_44
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
  }
           *cbox_ref_44_t;

typedef struct cbox_set__132
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
     struct cop *value;
  }
             *cbox_set__132_t;

typedef struct cset_ex_it_123
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *jump_value_221;
     struct cop *body;
  }
              *cset_ex_it_123_t;

typedef struct cjump_ex_it_131
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *value;
  }
               *cjump_ex_it_131_t;

typedef struct sfun_c_188
  {
     struct clabel *label;
     bool_t integrated;
  }
          *sfun_c_188_t;

typedef struct bdb_block_21
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
            *bdb_block_21_t;


extern obj_t display___r4_output_6_10_3(obj_t, obj_t);
static obj_t method_init_76_cgen_cgen();
extern obj_t make_box_202_ast_node;
static cop_t node__cop_default1765_254_cgen_cgen(node_t, obj_t);
extern obj_t block_cgen_cop;
extern obj_t cbox_ref_44_cgen_cop;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t __void_kont__176_cgen_cgen(obj_t, obj_t);
extern obj_t fail_ast_node;
extern setq_t node_setq_243_cgen_cgen(variable_t, node_t);
extern obj_t _void__134_type_cache;
extern obj_t box_ref_242_ast_node;
extern obj_t leave_function_170_tools_error();
extern obj_t _c_port__188_cgen_emit;
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t make_typed_declaration_180_type_tools(type_t, obj_t);
extern obj_t var_ast_node;
static cvoid_t _void_kont__34_cgen_cgen(obj_t);
extern obj_t closure_ast_node;
extern obj_t _bdb_debug__1_engine_param;
extern obj_t cjump_ex_it_131_cgen_cop;
extern local_t make_local_svar_name_219_cgen_cgen(obj_t, type_t);
extern obj_t _obj__252_type_cache;
extern obj_t block_kont_197_cgen_cgen(obj_t, obj_t);
extern obj_t cpragma_cgen_cop;
extern obj_t pragma_ast_node;
obj_t _id_kont__126_cgen_cgen = BUNSPEC;
static obj_t make_setq_kont_65_cgen_cgen(variable_t, obj_t, obj_t);
extern obj_t varc_cgen_cop;
extern obj_t set_ex_it_116_ast_node;
extern obj_t emit_bdb_loc_8_cgen_emit_cop_239(obj_t);
extern obj_t local_var_164_cgen_cop;
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _node__cop_12_cgen_cgen(obj_t, obj_t, obj_t);
extern obj_t catom_cgen_cop;
extern obj_t reset_bdb_loc__217_cgen_emit_cop_239();
extern obj_t nop_cgen_cop;
extern obj_t ccast_cgen_cop;
extern obj_t _unspec__87_type_cache;
extern obj_t cswitch_cgen_cop;
extern obj_t module_initialization_70_cgen_cgen(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70_cgen_cop(long, char *);
extern obj_t module_initialization_70_cgen_emit_cop_239(long, char *);
extern obj_t module_initialization_70_cgen_prototype(long, char *);
extern obj_t module_initialization_70_cgen_capp(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t cbox_set__132_cgen_cop;
obj_t _the_global__73_cgen_cgen = BUNSPEC;
static obj_t _cgen_cgen_cgen(obj_t, obj_t);
extern obj_t clabel_cgen_cop;
extern obj_t csetq_cgen_cop;
obj_t _return_kont__110_cgen_cgen = BUNSPEC;
extern obj_t bdb_block_21_cgen_cop;
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t stop_cgen_cop;
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_cgen_cgen();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _node_setq_175_cgen_cgen(obj_t, obj_t, obj_t);
extern obj_t write_char_165___r4_output_6_10_3(unsigned char, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t cif_cgen_cop;
extern obj_t cgen_cgen_cgen(global_t);
extern obj_t creturn_cgen_cop;
static obj_t _block_kont_170_cgen_cgen(obj_t, obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cgen_cgen();
extern obj_t sfun_c_188_cgen_cop;
static obj_t arg2618_cgen_cgen(obj_t, obj_t);
static obj_t arg2613_cgen_cgen(obj_t, obj_t);
static obj_t arg2578_cgen_cgen(obj_t, obj_t);
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t lambda1900_cgen_cgen(obj_t, obj_t);
extern obj_t atom_ast_node;
static obj_t lambda1798_cgen_cgen(obj_t, obj_t);
static obj_t lambda1797_cgen_cgen(obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t lambda1784_cgen_cgen(obj_t, obj_t);
static obj_t toplevel_init_63_cgen_cgen();
extern bool_t emit_cop_45_cgen_emit_cop_239(cop_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t cvoid_cgen_cop;
static obj_t _node__cop_default1765_105_cgen_cgen(obj_t, obj_t, obj_t);
extern bool_t side_effect__165_effect_effect(node_t);
extern obj_t cmake_box_177_cgen_cop;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern type_t typeof_coerce_typeof(node_t);
static obj_t _bdb_let_var_134_cgen_cgen(obj_t, obj_t, obj_t);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t emit_newline_191_cgen_emit_cop_239(obj_t);
extern obj_t csequence_cgen_cop;
extern obj_t cfail_cgen_cop;
extern obj_t shape_tools_shape(obj_t);
extern cop_t bdb_let_var_254_cgen_cgen(cop_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t cset_ex_it_123_cgen_cop;
static obj_t sfun__c_170_cgen_cgen(sfun_c_188_t, global_t);
extern obj_t _classes__134___object;
extern obj_t set_variable_name__102_cgen_prototype(obj_t);
extern obj_t select_ast_node;
obj_t _stop_kont__121_cgen_cgen = BUNSPEC;
extern obj_t read___reader(obj_t);
extern cop_t node__cop_142_cgen_cgen(node_t, obj_t);
static obj_t _make_local_svar_name_175_cgen_cgen(obj_t, obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cgen_cgen = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_cgen_cgen();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _bool__149_type_cache;
static obj_t __cnst[6];

DEFINE_EXPORT_PROCEDURE(block_kont_env_244_cgen_cgen, _block_kont_170_cgen_cgen2757, _block_kont_170_cgen_cgen, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2736_cgen_cgen, lambda1798_cgen_cgen2758, lambda1798_cgen_cgen, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2735_cgen_cgen, lambda1797_cgen_cgen2759, lambda1797_cgen_cgen, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2734_cgen_cgen, lambda1784_cgen_cgen2760, lambda1784_cgen_cgen, 0L, 1);
DEFINE_STATIC_PROCEDURE(node__cop_default1765_env_85_cgen_cgen, _node__cop_default1765_105_cgen_cgen2761, _node__cop_default1765_105_cgen_cgen, 0L, 2);
DEFINE_EXPORT_PROCEDURE(bdb_let_var_env_85_cgen_cgen, _bdb_let_var_134_cgen_cgen2762, _bdb_let_var_134_cgen_cgen, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_setq_env_20_cgen_cgen, _node_setq_175_cgen_cgen2763, _node_setq_175_cgen_cgen, 0L, 2);
DEFINE_STATIC_PROCEDURE(_void_kont__env_70_cgen_cgen, __void_kont__176_cgen_cgen2764, __void_kont__176_cgen_cgen, 0L, 1);
DEFINE_EXPORT_GENERIC(node__cop_env_160_cgen_cgen, _node__cop_12_cgen_cgen2765, _node__cop_12_cgen_cgen, 0L, 2);
DEFINE_STRING(string2751_cgen_cgen, string2751_cgen_cgen2766, "NODE->COP-DEFAULT1765 CELLVAL EXIT TEST AUX LOCATION ", 53);
DEFINE_STRING(string2749_cgen_cgen, string2749_cgen_cgen2767, "(", 1);
DEFINE_STRING(string2750_cgen_cgen, string2750_cgen_cgen2768, "No method for this object", 25);
DEFINE_STRING(string2748_cgen_cgen, string2748_cgen_cgen2769, ")jmpbuf", 7);
DEFINE_STRING(string2747_cgen_cgen, string2747_cgen_cgen2770, "_exit_value_", 12);
DEFINE_STRING(string2746_cgen_cgen, string2746_cgen_cgen2771, "jmp_buf jmpbuf", 14);
DEFINE_STRING(string2745_cgen_cgen, string2745_cgen_cgen2772, "Unexpected `closure' node", 25);
DEFINE_STRING(string2744_cgen_cgen, string2744_cgen_cgen2773, "Unexpected `kwote' node", 23);
DEFINE_STRING(string2743_cgen_cgen, string2743_cgen_cgen2774, "node->cop", 9);
DEFINE_STRING(string2742_cgen_cgen, string2742_cgen_cgen2775, "Illegal local name", 18);
DEFINE_STRING(string2741_cgen_cgen, string2741_cgen_cgen2776, "make-local-svar/name", 20);
DEFINE_STRING(string2739_cgen_cgen, string2739_cgen_cgen2777, "()", 2);
DEFINE_STRING(string2740_cgen_cgen, string2740_cgen_cgen2778, ", ", 2);
DEFINE_STRING(string2738_cgen_cgen, string2738_cgen_cgen2779, " */", 3);
DEFINE_STRING(string2737_cgen_cgen, string2737_cgen_cgen2780, "/* ", 3);
DEFINE_EXPORT_PROCEDURE(cgen_env_68_cgen_cgen, _cgen_cgen_cgen2781, _cgen_cgen_cgen, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_local_svar_name_env_11_cgen_cgen, _make_local_svar_name_175_cgen_cgen2782, _make_local_svar_name_175_cgen_cgen, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_cgen_cgen(long checksum_4097, char *from_4098)
{
   if (CBOOL(require_initialization_114_cgen_cgen))
     {
	require_initialization_114_cgen_cgen = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_cgen();
	cnst_init_137_cgen_cgen();
	imported_modules_init_94_cgen_cgen();
	method_init_76_cgen_cgen();
	toplevel_init_63_cgen_cgen();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_cgen()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CGEN_CGEN");
   module_initialization_70___object(((long) 0), "CGEN_CGEN");
   module_initialization_70___r4_strings_6_7(((long) 0), "CGEN_CGEN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CGEN_CGEN");
   module_initialization_70___reader(((long) 0), "CGEN_CGEN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_cgen()
{
   {
      obj_t cnst_port_138_4089;
      cnst_port_138_4089 = open_input_string(string2751_cgen_cgen);
      {
	 long i_4090;
	 i_4090 = ((long) 5);
       loop_4091:
	 {
	    bool_t test2752_4092;
	    test2752_4092 = (i_4090 == ((long) -1));
	    if (test2752_4092)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2753_4093;
		    {
		       obj_t list2754_4094;
		       {
			  obj_t arg2755_4095;
			  arg2755_4095 = BNIL;
			  list2754_4094 = MAKE_PAIR(cnst_port_138_4089, arg2755_4095);
		       }
		       arg2753_4093 = read___reader(list2754_4094);
		    }
		    CNST_TABLE_SET(i_4090, arg2753_4093);
		 }
		 {
		    int aux_4096;
		    {
		       long aux_4118;
		       aux_4118 = (i_4090 - ((long) 1));
		       aux_4096 = (int) (aux_4118);
		    }
		    {
		       long i_4121;
		       i_4121 = (long) (aux_4096);
		       i_4090 = i_4121;
		       goto loop_4091;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_cgen()
{
   _the_global__73_cgen_cgen = BUNSPEC;
   {
      obj_t lambda1784_4038;
      lambda1784_4038 = proc2734_cgen_cgen;
      _return_kont__110_cgen_cgen = lambda1784_4038;
   }
   {
      obj_t lambda1797_4037;
      lambda1797_4037 = proc2735_cgen_cgen;
      _id_kont__126_cgen_cgen = lambda1797_4037;
   }
   {
      obj_t lambda1798_4036;
      lambda1798_4036 = proc2736_cgen_cgen;
      _stop_kont__121_cgen_cgen = lambda1798_4036;
   }
   return BUNSPEC;
}


/* lambda1798 */ obj_t 
lambda1798_cgen_cgen(obj_t env_4039, obj_t cop_4040)
{
   {
      obj_t cop_1059;
      {
	 stop_t aux_4123;
	 cop_1059 = cop_4040;
	 {
	    stop_t res2636_2387;
	    {
	       obj_t loc_2379;
	       cop_t value_2380;
	       loc_2379 = BFALSE;
	       value_2380 = (cop_t) (cop_1059);
	       {
		  stop_t new1513_2381;
		  new1513_2381 = ((stop_t) BREF(GC_MALLOC(sizeof(struct stop))));
		  {
		     long arg1965_2382;
		     arg1965_2382 = class_num_218___object(stop_cgen_cop);
		     {
			obj_t obj_2385;
			obj_2385 = (obj_t) (new1513_2381);
			(((obj_t) CREF(obj_2385))->header = MAKE_HEADER(arg1965_2382, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_4129;
		     aux_4129 = (object_t) (new1513_2381);
		     OBJECT_WIDENING_SET(aux_4129, loc_2379);
		  }
		  ((((stop_t) CREF(new1513_2381))->loc) = ((obj_t) loc_2379), BUNSPEC);
		  ((((stop_t) CREF(new1513_2381))->value) = ((cop_t) value_2380), BUNSPEC);
		  res2636_2387 = new1513_2381;
	       }
	    }
	    aux_4123 = res2636_2387;
	 }
	 return (obj_t) (aux_4123);
      }
   }
}


/* lambda1797 */ obj_t 
lambda1797_cgen_cgen(obj_t env_4041, obj_t cop_4042)
{
   {
      obj_t cop_1057;
      cop_1057 = cop_4042;
      return cop_1057;
   }
}


/* lambda1784 */ obj_t 
lambda1784_cgen_cgen(obj_t env_4043, obj_t cop_4044)
{
   {
      obj_t cop_1045;
      {
	 creturn_t aux_4135;
	 cop_1045 = cop_4044;
	 {
	    obj_t arg1786_1047;
	    obj_t arg1788_1048;
	    {
	       cop_t obj_2346;
	       obj_2346 = (cop_t) (cop_1045);
	       arg1786_1047 = (((cop_t) CREF(obj_2346))->loc);
	    }
	    {
	       bool_t test1789_1049;
	       test1789_1049 = is_a__118___object(cop_1045, csetq_cgen_cop);
	       if (test1789_1049)
		 {
		    {
		       obj_t arg1791_1051;
		       {
			  catom_t arg1792_1052;
			  {
			     catom_t res2633_2356;
			     {
				obj_t loc_2348;
				loc_2348 = BFALSE;
				{
				   catom_t new1475_2350;
				   new1475_2350 = ((catom_t) BREF(GC_MALLOC(sizeof(struct catom))));
				   {
				      long arg1981_2351;
				      arg1981_2351 = class_num_218___object(catom_cgen_cop);
				      {
					 obj_t obj_2354;
					 obj_2354 = (obj_t) (new1475_2350);
					 (((obj_t) CREF(obj_2354))->header = MAKE_HEADER(arg1981_2351, 0), BUNSPEC);
				      }
				   }
				   {
				      object_t aux_4144;
				      aux_4144 = (object_t) (new1475_2350);
				      OBJECT_WIDENING_SET(aux_4144, loc_2348);
				   }
				   ((((catom_t) CREF(new1475_2350))->loc) = ((obj_t) loc_2348), BUNSPEC);
				   ((((catom_t) CREF(new1475_2350))->value) = ((obj_t) BUNSPEC), BUNSPEC);
				   res2633_2356 = new1475_2350;
				}
			     }
			     arg1792_1052 = res2633_2356;
			  }
			  {
			     obj_t list1793_1053;
			     {
				obj_t arg1794_1054;
				{
				   obj_t aux_4149;
				   aux_4149 = (obj_t) (arg1792_1052);
				   arg1794_1054 = MAKE_PAIR(aux_4149, BNIL);
				}
				list1793_1053 = MAKE_PAIR(cop_1045, arg1794_1054);
			     }
			     arg1791_1051 = list1793_1053;
			  }
		       }
		       {
			  csequence_t res2634_2368;
			  {
			     obj_t loc_2358;
			     loc_2358 = BFALSE;
			     {
				csequence_t new1501_2361;
				new1501_2361 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
				{
				   long arg1972_2362;
				   arg1972_2362 = class_num_218___object(csequence_cgen_cop);
				   {
				      obj_t obj_2366;
				      obj_2366 = (obj_t) (new1501_2361);
				      (((obj_t) CREF(obj_2366))->header = MAKE_HEADER(arg1972_2362, 0), BUNSPEC);
				   }
				}
				{
				   object_t aux_4157;
				   aux_4157 = (object_t) (new1501_2361);
				   OBJECT_WIDENING_SET(aux_4157, loc_2358);
				}
				((((csequence_t) CREF(new1501_2361))->loc) = ((obj_t) loc_2358), BUNSPEC);
				((((csequence_t) CREF(new1501_2361))->c_exp__163) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				((((csequence_t) CREF(new1501_2361))->cops) = ((obj_t) arg1791_1051), BUNSPEC);
				res2634_2368 = new1501_2361;
			     }
			  }
			  arg1788_1048 = (obj_t) (res2634_2368);
		       }
		    }
		 }
	       else
		 {
		    arg1788_1048 = cop_1045;
		 }
	    }
	    {
	       creturn_t res2635_2377;
	       {
		  cop_t value_2370;
		  value_2370 = (cop_t) (arg1788_1048);
		  {
		     creturn_t new1463_2371;
		     new1463_2371 = ((creturn_t) BREF(GC_MALLOC(sizeof(struct creturn))));
		     {
			long arg1985_2372;
			arg1985_2372 = class_num_218___object(creturn_cgen_cop);
			{
			   obj_t obj_2375;
			   obj_2375 = (obj_t) (new1463_2371);
			   (((obj_t) CREF(obj_2375))->header = MAKE_HEADER(arg1985_2372, 0), BUNSPEC);
			}
		     }
		     {
			object_t aux_4169;
			aux_4169 = (object_t) (new1463_2371);
			OBJECT_WIDENING_SET(aux_4169, BFALSE);
		     }
		     ((((creturn_t) CREF(new1463_2371))->loc) = ((obj_t) arg1786_1047), BUNSPEC);
		     ((((creturn_t) CREF(new1463_2371))->value) = ((cop_t) value_2370), BUNSPEC);
		     res2635_2377 = new1463_2371;
		  }
	       }
	       aux_4135 = res2635_2377;
	    }
	 }
	 return (obj_t) (aux_4135);
      }
   }
}


/* cgen */ obj_t 
cgen_cgen_cgen(global_t global_15)
{
   enter_function_81_tools_error((((global_t) CREF(global_15))->id));
   _the_global__73_cgen_cgen = (obj_t) (global_15);
   {
      obj_t sh_1080;
      sh_1080 = shape_tools_shape((obj_t) (global_15));
      BUNSPEC;
   }
   {
      sfun_c_188_t sfun_1081;
      {
	 sfun_c_188_t obj1636_1122;
	 obj1636_1122 = ((sfun_c_188_t) ((((global_t) CREF(global_15))->value)));
	 {
	    sfun_c_188_t arg1857_1123;
	    {
	       clabel_t arg1858_1124;
	       {
		  obj_t arg1860_1126;
		  arg1860_1126 = (((global_t) CREF(global_15))->name);
		  {
		     clabel_t res2637_2419;
		     {
			obj_t loc_2407;
			loc_2407 = BFALSE;
			{
			   clabel_t new1441_2411;
			   new1441_2411 = ((clabel_t) BREF(GC_MALLOC(sizeof(struct clabel))));
			   {
			      long arg1991_2412;
			      arg1991_2412 = class_num_218___object(clabel_cgen_cop);
			      {
				 obj_t obj_2417;
				 obj_2417 = (obj_t) (new1441_2411);
				 (((obj_t) CREF(obj_2417))->header = MAKE_HEADER(arg1991_2412, 0), BUNSPEC);
			      }
			   }
			   {
			      object_t aux_4187;
			      aux_4187 = (object_t) (new1441_2411);
			      OBJECT_WIDENING_SET(aux_4187, loc_2407);
			   }
			   ((((clabel_t) CREF(new1441_2411))->loc) = ((obj_t) loc_2407), BUNSPEC);
			   ((((clabel_t) CREF(new1441_2411))->name) = ((obj_t) arg1860_1126), BUNSPEC);
			   ((((clabel_t) CREF(new1441_2411))->used__226) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			   ((((clabel_t) CREF(new1441_2411))->body) = ((obj_t) BUNSPEC), BUNSPEC);
			   res2637_2419 = new1441_2411;
			}
		     }
		     arg1858_1124 = res2637_2419;
		  }
	       }
	       {
		  sfun_c_188_t res2638_2425;
		  {
		     sfun_c_188_t new1611_2422;
		     new1611_2422 = ((sfun_c_188_t) BREF(GC_MALLOC(sizeof(struct sfun_c_188))));
		     ((((sfun_c_188_t) CREF(new1611_2422))->label) = ((clabel_t) arg1858_1124), BUNSPEC);
		     ((((sfun_c_188_t) CREF(new1611_2422))->integrated) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		     res2638_2425 = new1611_2422;
		  }
		  arg1857_1123 = res2638_2425;
	       }
	    }
	    {
	       obj_t aux_4199;
	       object_t aux_4197;
	       aux_4199 = (obj_t) (arg1857_1123);
	       aux_4197 = (object_t) (obj1636_1122);
	       OBJECT_WIDENING_SET(aux_4197, aux_4199);
	    }
	 }
	 {
	    long arg1861_1127;
	    arg1861_1127 = class_num_218___object(sfun_c_188_cgen_cop);
	    {
	       obj_t obj_2426;
	       obj_2426 = (obj_t) (obj1636_1122);
	       (((obj_t) CREF(obj_2426))->header = MAKE_HEADER(arg1861_1127, 0), BUNSPEC);
	    }
	 }
	 sfun_1081 = obj1636_1122;
      }
      {
	 obj_t loc_1082;
	 {
	    sfun_t obj_2428;
	    obj_2428 = (sfun_t) (sfun_1081);
	    loc_1082 = (((sfun_t) CREF(obj_2428))->loc);
	 }
	 {
	    cop_t cop_1083;
	    {
	       obj_t arg1852_1119;
	       {
		  bool_t test1853_1120;
		  {
		     obj_t obj2_2432;
		     obj2_2432 = _void__134_type_cache;
		     {
			obj_t aux_4207;
			{
			   type_t aux_4208;
			   aux_4208 = (((global_t) CREF(global_15))->type);
			   aux_4207 = (obj_t) (aux_4208);
			}
			test1853_1120 = (aux_4207 == obj2_2432);
		     }
		  }
		  if (test1853_1120)
		    {
		       arg1852_1119 = _void_kont__env_70_cgen_cgen;
		    }
		  else
		    {
		       arg1852_1119 = _return_kont__110_cgen_cgen;
		    }
	       }
	       {
		  node_t aux_4213;
		  {
		     obj_t aux_4214;
		     {
			sfun_t obj_2429;
			obj_2429 = (sfun_t) (sfun_1081);
			aux_4214 = (((sfun_t) CREF(obj_2429))->body);
		     }
		     aux_4213 = (node_t) (aux_4214);
		  }
		  cop_1083 = node__cop_142_cgen_cgen(aux_4213, arg1852_1119);
	       }
	    }
	    {
	       reset_bdb_loc__217_cgen_emit_cop_239();
	       {
		  obj_t list1817_1084;
		  list1817_1084 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		  newline___r4_output_6_10_3(list1817_1084);
	       }
	       {
		  obj_t list1819_1086;
		  list1819_1086 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		  display___r4_output_6_10_3(string2737_cgen_cgen, list1819_1086);
	       }
	       {
		  obj_t arg1821_1088;
		  arg1821_1088 = shape_tools_shape((obj_t) (global_15));
		  {
		     obj_t list1822_1089;
		     list1822_1089 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		     display___r4_output_6_10_3(arg1821_1088, list1822_1089);
		  }
	       }
	       {
		  obj_t list1824_1091;
		  list1824_1091 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		  display___r4_output_6_10_3(string2738_cgen_cgen, list1824_1091);
	       }
	       {
		  obj_t aux_4230;
		  {
		     bool_t test_4231;
		     if (STRUCTP(loc_1082))
		       {
			  obj_t aux_4236;
			  obj_t aux_4234;
			  aux_4236 = CNST_TABLE_REF(((long) 0));
			  aux_4234 = STRUCT_KEY(loc_1082);
			  test_4231 = (aux_4234 == aux_4236);
		       }
		     else
		       {
			  test_4231 = ((bool_t) 0);
		       }
		     if (test_4231)
		       {
			  aux_4230 = loc_1082;
		       }
		     else
		       {
			  aux_4230 = (((cop_t) CREF(cop_1083))->loc);
		       }
		  }
		  emit_bdb_loc_8_cgen_emit_cop_239(aux_4230);
	       }
	       reset_bdb_loc__217_cgen_emit_cop_239();
	       {
		  clabel_t arg1829_1095;
		  {
		     obj_t aux_4242;
		     {
			object_t aux_4243;
			aux_4243 = (object_t) (sfun_1081);
			aux_4242 = OBJECT_WIDENING(aux_4243);
		     }
		     arg1829_1095 = (((sfun_c_188_t) CREF(aux_4242))->label);
		  }
		  {
		     obj_t val1449_2444;
		     val1449_2444 = (obj_t) (cop_1083);
		     ((((clabel_t) CREF(arg1829_1095))->body) = ((obj_t) val1449_2444), BUNSPEC);
		  }
	       }
	       sfun__c_170_cgen_cgen(sfun_1081, global_15);
	       {
		  obj_t cop_1096;
		  {
		     obj_t cop_2446;
		     {
			clabel_t aux_4250;
			{
			   obj_t aux_4251;
			   {
			      object_t aux_4252;
			      aux_4252 = (object_t) (sfun_1081);
			      aux_4251 = OBJECT_WIDENING(aux_4252);
			   }
			   aux_4250 = (((sfun_c_188_t) CREF(aux_4251))->label);
			}
			cop_2446 = (obj_t) (aux_4250);
		     }
		     {
			bool_t test1897_2448;
			test1897_2448 = is_a__118___object(cop_2446, block_cgen_cop);
			if (test1897_2448)
			  {
			     cop_1096 = cop_2446;
			  }
			else
			  {
			     {
				block_t res2639_2460;
				{
				   cop_t body_2453;
				   body_2453 = (cop_t) (cop_2446);
				   {
				      block_t new1457_2454;
				      new1457_2454 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
				      {
					 long arg1987_2455;
					 arg1987_2455 = class_num_218___object(block_cgen_cop);
					 {
					    obj_t obj_2458;
					    obj_2458 = (obj_t) (new1457_2454);
					    (((obj_t) CREF(obj_2458))->header = MAKE_HEADER(arg1987_2455, 0), BUNSPEC);
					 }
				      }
				      {
					 object_t aux_4264;
					 aux_4264 = (object_t) (new1457_2454);
					 OBJECT_WIDENING_SET(aux_4264, BFALSE);
				      }
				      ((((block_t) CREF(new1457_2454))->loc) = ((obj_t) loc_1082), BUNSPEC);
				      ((((block_t) CREF(new1457_2454))->body) = ((cop_t) body_2453), BUNSPEC);
				      res2639_2460 = new1457_2454;
				   }
				}
				cop_1096 = (obj_t) (res2639_2460);
			     }
			  }
		     }
		  }
		  {
		     bool_t test1830_1097;
		     {
			long n1_2461;
			n1_2461 = (long) CINT(_bdb_debug__1_engine_param);
			test1830_1097 = (n1_2461 > ((long) 0));
		     }
		     if (test1830_1097)
		       {
			  obj_t cop_1098;
			  cop_1098 = cop_1096;
			loop_1099:
			  {
			     bool_t test1831_1100;
			     test1831_1100 = is_a__118___object(cop_1098, block_cgen_cop);
			     if (test1831_1100)
			       {
				  {
				     cop_t obj_2464;
				     obj_2464 = (cop_t) (cop_1098);
				     ((((cop_t) CREF(obj_2464))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
				  }
				  {
				     obj_t cop_4277;
				     {
					cop_t aux_4278;
					{
					   block_t obj_2466;
					   obj_2466 = (block_t) (cop_1098);
					   aux_4278 = (((block_t) CREF(obj_2466))->body);
					}
					cop_4277 = (obj_t) (aux_4278);
				     }
				     cop_1098 = cop_4277;
				     goto loop_1099;
				  }
			       }
			     else
			       {
				  bool_t test1833_1102;
				  test1833_1102 = is_a__118___object(cop_1098, csequence_cgen_cop);
				  if (test1833_1102)
				    {
				       {
					  bool_t test_4284;
					  {
					     bool_t test_4285;
					     {
						csequence_t obj_2468;
						obj_2468 = (csequence_t) (cop_1098);
						test_4285 = (((csequence_t) CREF(obj_2468))->c_exp__163);
					     }
					     if (test_4285)
					       {
						  test_4284 = ((bool_t) 0);
					       }
					     else
					       {
						  obj_t aux_4288;
						  {
						     csequence_t obj_2469;
						     obj_2469 = (csequence_t) (cop_1098);
						     aux_4288 = (((csequence_t) CREF(obj_2469))->cops);
						  }
						  test_4284 = PAIRP(aux_4288);
					       }
					  }
					  if (test_4284)
					    {
					       {
						  cop_t obj_2473;
						  {
						     obj_t aux_4292;
						     {
							obj_t aux_4293;
							{
							   csequence_t obj_2471;
							   obj_2471 = (csequence_t) (cop_1098);
							   aux_4293 = (((csequence_t) CREF(obj_2471))->cops);
							}
							aux_4292 = CAR(aux_4293);
						     }
						     obj_2473 = (cop_t) (aux_4292);
						  }
						  ((((cop_t) CREF(obj_2473))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
					       }
					       {
						  obj_t cop_4299;
						  {
						     obj_t aux_4300;
						     {
							csequence_t obj_2475;
							obj_2475 = (csequence_t) (cop_1098);
							aux_4300 = (((csequence_t) CREF(obj_2475))->cops);
						     }
						     cop_4299 = CAR(aux_4300);
						  }
						  cop_1098 = cop_4299;
						  goto loop_1099;
					       }
					    }
					  else
					    {
					       BUNSPEC;
					    }
				       }
				    }
				  else
				    {
				       bool_t test1843_1111;
				       test1843_1111 = is_a__118___object(cop_1098, clabel_cgen_cop);
				       if (test1843_1111)
					 {
					    {
					       bool_t test_4306;
					       {
						  clabel_t obj_2478;
						  obj_2478 = (clabel_t) (cop_1098);
						  test_4306 = (((clabel_t) CREF(obj_2478))->used__226);
					       }
					       if (test_4306)
						 {
						    BUNSPEC;
						 }
					       else
						 {
						    {
						       clabel_t obj_2479;
						       obj_2479 = (clabel_t) (cop_1098);
						       ((((clabel_t) CREF(obj_2479))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
						    }
						    {
						       obj_t cop_4311;
						       {
							  clabel_t obj_2481;
							  obj_2481 = (clabel_t) (cop_1098);
							  cop_4311 = (((clabel_t) CREF(obj_2481))->body);
						       }
						       cop_1098 = cop_4311;
						       goto loop_1099;
						    }
						 }
					    }
					 }
				       else
					 {
					    BFALSE;
					 }
				    }
			       }
			  }
		       }
		     else
		       {
			  BUNSPEC;
		       }
		  }
		  emit_cop_45_cgen_emit_cop_239((cop_t) (cop_1096));
	       }
	       {
		  obj_t list1849_1116;
		  list1849_1116 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
		  newline___r4_output_6_10_3(list1849_1116);
	       }
	       return leave_function_170_tools_error();
	    }
	 }
      }
   }
}


/* _cgen */ obj_t 
_cgen_cgen_cgen(obj_t env_4045, obj_t global_4046)
{
   return cgen_cgen_cgen((global_t) (global_4046));
}


/* sfun->c */ obj_t 
sfun__c_170_cgen_cgen(sfun_c_188_t sfun_16, global_t variable_17)
{
   {
      obj_t arg1862_1129;
      {
	 obj_t aux_4324;
	 type_t aux_4321;
	 {
	    variable_t obj_2483;
	    obj_2483 = (variable_t) (variable_17);
	    aux_4324 = (((variable_t) CREF(obj_2483))->name);
	 }
	 {
	    variable_t obj_2482;
	    obj_2482 = (variable_t) (variable_17);
	    aux_4321 = (((variable_t) CREF(obj_2482))->type);
	 }
	 arg1862_1129 = make_typed_declaration_180_type_tools(aux_4321, aux_4324);
      }
      {
	 obj_t list1863_1130;
	 list1863_1130 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	 display___r4_output_6_10_3(arg1862_1129, list1863_1130);
      }
   }
   {
      bool_t test_4330;
      {
	 obj_t aux_4331;
	 {
	    sfun_t obj_2484;
	    obj_2484 = (sfun_t) (sfun_16);
	    aux_4331 = (((sfun_t) CREF(obj_2484))->args);
	 }
	 test_4330 = NULLP(aux_4331);
      }
      if (test_4330)
	{
	   {
	      obj_t list1868_1135;
	      list1868_1135 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	      display___r4_output_6_10_3(string2739_cgen_cgen, list1868_1135);
	   }
	   return emit_newline_191_cgen_emit_cop_239(BNIL);
	}
      else
	{
	   {
	      obj_t list1871_1138;
	      list1871_1138 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
	      display___r4_output_6_10_3(BCHAR(((unsigned char) '(')), list1871_1138);
	   }
	   {
	      obj_t args_1140;
	      {
		 sfun_t obj_2486;
		 obj_2486 = (sfun_t) (sfun_16);
		 args_1140 = (((sfun_t) CREF(obj_2486))->args);
	      }
	    loop_1141:
	      {
		 bool_t test_4341;
		 {
		    obj_t aux_4342;
		    aux_4342 = CDR(args_1140);
		    test_4341 = NULLP(aux_4342);
		 }
		 if (test_4341)
		   {
		      obj_t instance1641_1144;
		      instance1641_1144 = CAR(args_1140);
		      {
			 obj_t arg1877_1145;
			 {
			    obj_t aux_4349;
			    type_t aux_4346;
			    {
			       local_t obj_2491;
			       obj_2491 = (local_t) (instance1641_1144);
			       aux_4349 = (((local_t) CREF(obj_2491))->name);
			    }
			    {
			       local_t obj_2490;
			       obj_2490 = (local_t) (instance1641_1144);
			       aux_4346 = (((local_t) CREF(obj_2490))->type);
			    }
			    arg1877_1145 = make_typed_declaration_180_type_tools(aux_4346, aux_4349);
			 }
			 {
			    obj_t list1878_1146;
			    list1878_1146 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			    display___r4_output_6_10_3(arg1877_1145, list1878_1146);
			 }
		      }
		      {
			 obj_t list1882_1150;
			 list1882_1150 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			 write_char_165___r4_output_6_10_3(((unsigned char) ')'), list1882_1150);
		      }
		      return emit_newline_191_cgen_emit_cop_239(BNIL);
		   }
		 else
		   {
		      obj_t instance1642_1153;
		      instance1642_1153 = CAR(args_1140);
		      {
			 obj_t arg1885_1154;
			 {
			    obj_t aux_4362;
			    type_t aux_4359;
			    {
			       local_t obj_2494;
			       obj_2494 = (local_t) (instance1642_1153);
			       aux_4362 = (((local_t) CREF(obj_2494))->name);
			    }
			    {
			       local_t obj_2493;
			       obj_2493 = (local_t) (instance1642_1153);
			       aux_4359 = (((local_t) CREF(obj_2493))->type);
			    }
			    arg1885_1154 = make_typed_declaration_180_type_tools(aux_4359, aux_4362);
			 }
			 {
			    obj_t list1886_1155;
			    list1886_1155 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			    display___r4_output_6_10_3(arg1885_1154, list1886_1155);
			 }
		      }
		      {
			 obj_t list1891_1159;
			 list1891_1159 = MAKE_PAIR(_c_port__188_cgen_emit, BNIL);
			 display___r4_output_6_10_3(string2740_cgen_cgen, list1891_1159);
		      }
		      {
			 obj_t args_4370;
			 args_4370 = CDR(args_1140);
			 args_1140 = args_4370;
			 goto loop_1141;
		      }
		   }
	      }
	   }
	}
   }
}


/* *void-kont* */ cvoid_t 
_void_kont__34_cgen_cgen(obj_t cop_18)
{
   {
      cvoid_t res2640_2505;
      {
	 obj_t loc_2497;
	 cop_t value_2498;
	 loc_2497 = BFALSE;
	 value_2498 = (cop_t) (cop_18);
	 {
	    cvoid_t new1469_2499;
	    new1469_2499 = ((cvoid_t) BREF(GC_MALLOC(sizeof(struct cvoid))));
	    {
	       long arg1983_2500;
	       arg1983_2500 = class_num_218___object(cvoid_cgen_cop);
	       {
		  obj_t obj_2503;
		  obj_2503 = (obj_t) (new1469_2499);
		  (((obj_t) CREF(obj_2503))->header = MAKE_HEADER(arg1983_2500, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4379;
	       aux_4379 = (object_t) (new1469_2499);
	       OBJECT_WIDENING_SET(aux_4379, loc_2497);
	    }
	    ((((cvoid_t) CREF(new1469_2499))->loc) = ((obj_t) loc_2497), BUNSPEC);
	    ((((cvoid_t) CREF(new1469_2499))->value) = ((cop_t) value_2498), BUNSPEC);
	    res2640_2505 = new1469_2499;
	 }
      }
      return res2640_2505;
   }
}


/* _*void-kont* */ obj_t 
__void_kont__176_cgen_cgen(obj_t env_4047, obj_t cop_4048)
{
   {
      cvoid_t aux_4384;
      aux_4384 = _void_kont__34_cgen_cgen(cop_4048);
      return (obj_t) (aux_4384);
   }
}


/* block-kont */ obj_t 
block_kont_197_cgen_cgen(obj_t cop_19, obj_t loc_20)
{
   {
      bool_t test1897_2506;
      test1897_2506 = is_a__118___object(cop_19, block_cgen_cop);
      if (test1897_2506)
	{
	   return cop_19;
	}
      else
	{
	   {
	      block_t res2641_2518;
	      {
		 cop_t body_2511;
		 body_2511 = (cop_t) (cop_19);
		 {
		    block_t new1457_2512;
		    new1457_2512 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
		    {
		       long arg1987_2513;
		       arg1987_2513 = class_num_218___object(block_cgen_cop);
		       {
			  obj_t obj_2516;
			  obj_2516 = (obj_t) (new1457_2512);
			  (((obj_t) CREF(obj_2516))->header = MAKE_HEADER(arg1987_2513, 0), BUNSPEC);
		       }
		    }
		    {
		       object_t aux_4394;
		       aux_4394 = (object_t) (new1457_2512);
		       OBJECT_WIDENING_SET(aux_4394, BFALSE);
		    }
		    ((((block_t) CREF(new1457_2512))->loc) = ((obj_t) loc_20), BUNSPEC);
		    ((((block_t) CREF(new1457_2512))->body) = ((cop_t) body_2511), BUNSPEC);
		    res2641_2518 = new1457_2512;
		 }
	      }
	      return (obj_t) (res2641_2518);
	   }
	}
   }
}


/* _block-kont */ obj_t 
_block_kont_170_cgen_cgen(obj_t env_4049, obj_t cop_4050, obj_t loc_4051)
{
   return block_kont_197_cgen_cgen(cop_4050, loc_4051);
}


/* make-setq-kont */ obj_t 
make_setq_kont_65_cgen_cgen(variable_t var_23, obj_t loc_24, obj_t kont_25)
{
   {
      obj_t lambda1900_4052;
      lambda1900_4052 = make_fx_procedure(lambda1900_cgen_cgen, ((long) 1), ((long) 3));
      PROCEDURE_SET(lambda1900_4052, ((long) 0), loc_24);
      {
	 obj_t aux_4403;
	 aux_4403 = (obj_t) (var_23);
	 PROCEDURE_SET(lambda1900_4052, ((long) 1), aux_4403);
      }
      PROCEDURE_SET(lambda1900_4052, ((long) 2), kont_25);
      return lambda1900_4052;
   }
}


/* lambda1900 */ obj_t 
lambda1900_cgen_cgen(obj_t env_4053, obj_t cop_4057)
{
   {
      obj_t loc_4054;
      obj_t var_4055;
      obj_t kont_4056;
      loc_4054 = PROCEDURE_REF(env_4053, ((long) 0));
      var_4055 = PROCEDURE_REF(env_4053, ((long) 1));
      kont_4056 = PROCEDURE_REF(env_4053, ((long) 2));
      {
	 obj_t cop_1168;
	 cop_1168 = cop_4057;
	 {
	    bool_t test1901_1170;
	    test1901_1170 = is_a__118___object(cop_1168, cfail_cgen_cop);
	    if (test1901_1170)
	      {
		 return cop_1168;
	      }
	    else
	      {
		 csetq_t arg1902_1171;
		 {
		    varc_t arg1905_1173;
		    obj_t arg1906_1174;
		    {
		       varc_t res2642_2528;
		       {
			  obj_t loc_2520;
			  variable_t variable_2521;
			  loc_2520 = BFALSE;
			  variable_2521 = (variable_t) (var_4055);
			  {
			     varc_t new1481_2522;
			     new1481_2522 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
			     {
				long arg1979_2523;
				arg1979_2523 = class_num_218___object(varc_cgen_cop);
				{
				   obj_t obj_2526;
				   obj_2526 = (obj_t) (new1481_2522);
				   (((obj_t) CREF(obj_2526))->header = MAKE_HEADER(arg1979_2523, 0), BUNSPEC);
				}
			     }
			     {
				object_t aux_4417;
				aux_4417 = (object_t) (new1481_2522);
				OBJECT_WIDENING_SET(aux_4417, loc_2520);
			     }
			     ((((varc_t) CREF(new1481_2522))->loc) = ((obj_t) loc_2520), BUNSPEC);
			     ((((varc_t) CREF(new1481_2522))->variable) = ((variable_t) variable_2521), BUNSPEC);
			     res2642_2528 = new1481_2522;
			  }
		       }
		       arg1905_1173 = res2642_2528;
		    }
		    {
		       bool_t test1908_1176;
		       test1908_1176 = is_a__118___object(cop_1168, csetq_cgen_cop);
		       if (test1908_1176)
			 {
			    {
			       obj_t arg1910_1178;
			       {
				  catom_t arg1911_1179;
				  {
				     catom_t res2643_2538;
				     {
					obj_t loc_2530;
					loc_2530 = BFALSE;
					{
					   catom_t new1475_2532;
					   new1475_2532 = ((catom_t) BREF(GC_MALLOC(sizeof(struct catom))));
					   {
					      long arg1981_2533;
					      arg1981_2533 = class_num_218___object(catom_cgen_cop);
					      {
						 obj_t obj_2536;
						 obj_2536 = (obj_t) (new1475_2532);
						 (((obj_t) CREF(obj_2536))->header = MAKE_HEADER(arg1981_2533, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_4428;
					      aux_4428 = (object_t) (new1475_2532);
					      OBJECT_WIDENING_SET(aux_4428, loc_2530);
					   }
					   ((((catom_t) CREF(new1475_2532))->loc) = ((obj_t) loc_2530), BUNSPEC);
					   ((((catom_t) CREF(new1475_2532))->value) = ((obj_t) BUNSPEC), BUNSPEC);
					   res2643_2538 = new1475_2532;
					}
				     }
				     arg1911_1179 = res2643_2538;
				  }
				  {
				     obj_t list1912_1180;
				     {
					obj_t arg1913_1181;
					{
					   obj_t aux_4433;
					   aux_4433 = (obj_t) (arg1911_1179);
					   arg1913_1181 = MAKE_PAIR(aux_4433, BNIL);
					}
					list1912_1180 = MAKE_PAIR(cop_1168, arg1913_1181);
				     }
				     arg1910_1178 = list1912_1180;
				  }
			       }
			       {
				  csequence_t res2644_2550;
				  {
				     obj_t loc_2540;
				     loc_2540 = BFALSE;
				     {
					csequence_t new1501_2543;
					new1501_2543 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					{
					   long arg1972_2544;
					   arg1972_2544 = class_num_218___object(csequence_cgen_cop);
					   {
					      obj_t obj_2548;
					      obj_2548 = (obj_t) (new1501_2543);
					      (((obj_t) CREF(obj_2548))->header = MAKE_HEADER(arg1972_2544, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_4441;
					   aux_4441 = (object_t) (new1501_2543);
					   OBJECT_WIDENING_SET(aux_4441, loc_2540);
					}
					((((csequence_t) CREF(new1501_2543))->loc) = ((obj_t) loc_2540), BUNSPEC);
					((((csequence_t) CREF(new1501_2543))->c_exp__163) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					((((csequence_t) CREF(new1501_2543))->cops) = ((obj_t) arg1910_1178), BUNSPEC);
					res2644_2550 = new1501_2543;
				     }
				  }
				  arg1906_1174 = (obj_t) (res2644_2550);
			       }
			    }
			 }
		       else
			 {
			    arg1906_1174 = cop_1168;
			 }
		    }
		    {
		       csetq_t res2645_2561;
		       {
			  cop_t value_2553;
			  value_2553 = (cop_t) (arg1906_1174);
			  {
			     csetq_t new1519_2554;
			     new1519_2554 = ((csetq_t) BREF(GC_MALLOC(sizeof(struct csetq))));
			     {
				long arg1963_2555;
				arg1963_2555 = class_num_218___object(csetq_cgen_cop);
				{
				   obj_t obj_2559;
				   obj_2559 = (obj_t) (new1519_2554);
				   (((obj_t) CREF(obj_2559))->header = MAKE_HEADER(arg1963_2555, 0), BUNSPEC);
				}
			     }
			     {
				object_t aux_4453;
				aux_4453 = (object_t) (new1519_2554);
				OBJECT_WIDENING_SET(aux_4453, BFALSE);
			     }
			     ((((csetq_t) CREF(new1519_2554))->loc) = ((obj_t) loc_4054), BUNSPEC);
			     ((((csetq_t) CREF(new1519_2554))->var) = ((varc_t) arg1905_1173), BUNSPEC);
			     ((((csetq_t) CREF(new1519_2554))->value) = ((cop_t) value_2553), BUNSPEC);
			     res2645_2561 = new1519_2554;
			  }
		       }
		       arg1902_1171 = res2645_2561;
		    }
		 }
		 return PROCEDURE_ENTRY(kont_4056) (kont_4056, (obj_t) (arg1902_1171), BEOA);
	      }
	 }
      }
   }
}


/* bdb-let-var */ cop_t 
bdb_let_var_254_cgen_cgen(cop_t cop_56, obj_t loc_57)
{
   {
      bool_t test1916_1184;
      {
	 bool_t test1919_1187;
	 {
	    long n1_2562;
	    n1_2562 = (long) CINT(_bdb_debug__1_engine_param);
	    test1919_1187 = (n1_2562 > ((long) 0));
	 }
	 if (test1919_1187)
	   {
	      if (STRUCTP(loc_57))
		{
		   obj_t aux_4469;
		   obj_t aux_4467;
		   aux_4469 = CNST_TABLE_REF(((long) 0));
		   aux_4467 = STRUCT_KEY(loc_57);
		   test1916_1184 = (aux_4467 == aux_4469);
		}
	      else
		{
		   test1916_1184 = ((bool_t) 0);
		}
	   }
	 else
	   {
	      test1916_1184 = ((bool_t) 0);
	   }
      }
      if (test1916_1184)
	{
	   bdb_block_21_t res2646_2580;
	   {
	      bdb_block_21_t new1630_2574;
	      new1630_2574 = ((bdb_block_21_t) BREF(GC_MALLOC(sizeof(struct bdb_block_21))));
	      {
		 long arg1932_2575;
		 arg1932_2575 = class_num_218___object(bdb_block_21_cgen_cop);
		 {
		    obj_t obj_2578;
		    obj_2578 = (obj_t) (new1630_2574);
		    (((obj_t) CREF(obj_2578))->header = MAKE_HEADER(arg1932_2575, 0), BUNSPEC);
		 }
	      }
	      {
		 object_t aux_4477;
		 aux_4477 = (object_t) (new1630_2574);
		 OBJECT_WIDENING_SET(aux_4477, BFALSE);
	      }
	      ((((bdb_block_21_t) CREF(new1630_2574))->loc) = ((obj_t) loc_57), BUNSPEC);
	      ((((bdb_block_21_t) CREF(new1630_2574))->body) = ((cop_t) cop_56), BUNSPEC);
	      res2646_2580 = new1630_2574;
	   }
	   return (cop_t) (res2646_2580);
	}
      else
	{
	   return cop_56;
	}
   }
}


/* _bdb-let-var */ obj_t 
_bdb_let_var_134_cgen_cgen(obj_t env_4058, obj_t cop_4059, obj_t loc_4060)
{
   {
      cop_t aux_4483;
      aux_4483 = bdb_let_var_254_cgen_cgen((cop_t) (cop_4059), loc_4060);
      return (obj_t) (aux_4483);
   }
}


/* node-setq */ setq_t 
node_setq_243_cgen_cgen(variable_t variable_68, node_t value_69)
{
   {
      obj_t arg1920_1188;
      obj_t arg1921_1189;
      var_t arg1923_1190;
      arg1920_1188 = (((node_t) CREF(value_69))->loc);
      arg1921_1189 = _unspec__87_type_cache;
      {
	 type_t arg1927_1193;
	 arg1927_1193 = (((variable_t) CREF(variable_68))->type);
	 {
	    var_t res2647_2593;
	    {
	       obj_t loc_2583;
	       loc_2583 = BFALSE;
	       {
		  var_t new1207_2586;
		  new1207_2586 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
		  {
		     long arg2042_2587;
		     arg2042_2587 = class_num_218___object(var_ast_node);
		     {
			obj_t obj_2591;
			obj_2591 = (obj_t) (new1207_2586);
			(((obj_t) CREF(obj_2591))->header = MAKE_HEADER(arg2042_2587, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_4493;
		     aux_4493 = (object_t) (new1207_2586);
		     OBJECT_WIDENING_SET(aux_4493, loc_2583);
		  }
		  ((((var_t) CREF(new1207_2586))->loc) = ((obj_t) loc_2583), BUNSPEC);
		  ((((var_t) CREF(new1207_2586))->type) = ((type_t) arg1927_1193), BUNSPEC);
		  ((((var_t) CREF(new1207_2586))->variable) = ((variable_t) variable_68), BUNSPEC);
		  res2647_2593 = new1207_2586;
	       }
	    }
	    arg1923_1190 = res2647_2593;
	 }
      }
      {
	 setq_t res2648_2606;
	 {
	    type_t type_2595;
	    type_2595 = (type_t) (arg1921_1189);
	    {
	       setq_t new1300_2598;
	       new1300_2598 = ((setq_t) BREF(GC_MALLOC(sizeof(struct setq))));
	       {
		  long arg2021_2599;
		  arg2021_2599 = class_num_218___object(setq_ast_node);
		  {
		     obj_t obj_2604;
		     obj_2604 = (obj_t) (new1300_2598);
		     (((obj_t) CREF(obj_2604))->header = MAKE_HEADER(arg2021_2599, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_4504;
		  aux_4504 = (object_t) (new1300_2598);
		  OBJECT_WIDENING_SET(aux_4504, BFALSE);
	       }
	       ((((setq_t) CREF(new1300_2598))->loc) = ((obj_t) arg1920_1188), BUNSPEC);
	       ((((setq_t) CREF(new1300_2598))->type) = ((type_t) type_2595), BUNSPEC);
	       ((((setq_t) CREF(new1300_2598))->var) = ((var_t) arg1923_1190), BUNSPEC);
	       ((((setq_t) CREF(new1300_2598))->value) = ((node_t) value_69), BUNSPEC);
	       res2648_2606 = new1300_2598;
	    }
	 }
	 return res2648_2606;
      }
   }
}


/* _node-setq */ obj_t 
_node_setq_175_cgen_cgen(obj_t env_4061, obj_t variable_4062, obj_t value_4063)
{
   {
      setq_t aux_4511;
      aux_4511 = node_setq_243_cgen_cgen((variable_t) (variable_4062), (node_t) (value_4063));
      return (obj_t) (aux_4511);
   }
}


/* make-local-svar/name */ local_t 
make_local_svar_name_219_cgen_cgen(obj_t id_70, type_t type_71)
{
   {
      local_t local_1195;
      local_1195 = make_local_svar_140_ast_local(id_70, type_71);
      {
	 bool_t test_4517;
	 {
	    obj_t aux_4518;
	    aux_4518 = (((local_t) CREF(local_1195))->name);
	    test_4517 = STRINGP(aux_4518);
	 }
	 if (test_4517)
	   {
	      BUNSPEC;
	   }
	 else
	   {
	      FAILURE(string2741_cgen_cgen, string2742_cgen_cgen, (obj_t) (local_1195));
	   }
      }
      return local_1195;
   }
}


/* _make-local-svar/name */ obj_t 
_make_local_svar_name_175_cgen_cgen(obj_t env_4064, obj_t id_4065, obj_t type_4066)
{
   {
      local_t aux_4523;
      aux_4523 = make_local_svar_name_219_cgen_cgen(id_4065, (type_t) (type_4066));
      return (obj_t) (aux_4523);
   }
}


/* method-init */ obj_t 
method_init_76_cgen_cgen()
{
   add_generic__110___object(node__cop_env_160_cgen_cgen, node__cop_default1765_env_85_cgen_cgen);
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, pragma_ast_node, ((long) 5));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, cast_ast_node, ((long) 6));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, setq_ast_node, ((long) 7));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, conditional_ast_node, ((long) 8));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, fail_ast_node, ((long) 9));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, select_ast_node, ((long) 10));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, let_fun_218_ast_node, ((long) 11));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, let_var_6_ast_node, ((long) 12));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, set_ex_it_116_ast_node, ((long) 13));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, jump_ex_it_184_ast_node, ((long) 14));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, make_box_202_ast_node, ((long) 15));
   add_inlined_method__244___object(node__cop_env_160_cgen_cgen, box_ref_242_ast_node, ((long) 16));
   {
      long aux_4545;
      aux_4545 = add_inlined_method__244___object(node__cop_env_160_cgen_cgen, box_set__221_ast_node, ((long) 17));
      return BINT(aux_4545);
   }
}


/* node->cop */ cop_t 
node__cop_142_cgen_cgen(node_t node_26, obj_t kont_27)
{
   {
      obj_t method2077_1717;
      obj_t class2082_1718;
      {
	 obj_t arg2085_1715;
	 obj_t arg2086_1716;
	 {
	    object_t obj_2802;
	    obj_2802 = (object_t) (node_26);
	    {
	       obj_t pre_method_105_2803;
	       pre_method_105_2803 = PROCEDURE_REF(node__cop_env_160_cgen_cgen, ((long) 2));
	       if (INTEGERP(pre_method_105_2803))
		 {
		    PROCEDURE_SET(node__cop_env_160_cgen_cgen, ((long) 2), BUNSPEC);
		    arg2085_1715 = pre_method_105_2803;
		 }
	       else
		 {
		    long obj_class_num_177_2808;
		    obj_class_num_177_2808 = TYPE(obj_2802);
		    {
		       obj_t arg1177_2809;
		       arg1177_2809 = PROCEDURE_REF(node__cop_env_160_cgen_cgen, ((long) 1));
		       {
			  long arg1178_2813;
			  {
			     long arg1179_2814;
			     arg1179_2814 = OBJECT_TYPE;
			     arg1178_2813 = (obj_class_num_177_2808 - arg1179_2814);
			  }
			  arg2085_1715 = VECTOR_REF(arg1177_2809, arg1178_2813);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2819;
	    object_2819 = (object_t) (node_26);
	    {
	       long arg1180_2820;
	       {
		  long arg1181_2821;
		  long arg1182_2822;
		  arg1181_2821 = TYPE(object_2819);
		  arg1182_2822 = OBJECT_TYPE;
		  arg1180_2820 = (arg1181_2821 - arg1182_2822);
	       }
	       {
		  obj_t vector_2826;
		  vector_2826 = _classes__134___object;
		  arg2086_1716 = VECTOR_REF(vector_2826, arg1180_2820);
	       }
	    }
	 }
	 {
	    obj_t aux_4563;
	    method2077_1717 = arg2085_1715;
	    class2082_1718 = arg2086_1716;
	    {
	       if (INTEGERP(method2077_1717))
		 {
		    switch ((long) CINT(method2077_1717))
		      {
		      case ((long) 0):
			 {
			    atom_t node_1724;
			    node_1724 = (atom_t) (node_26);
			    {
			       catom_t arg2089_1727;
			       {
				  obj_t arg2090_1728;
				  obj_t arg2091_1729;
				  arg2090_1728 = (((atom_t) CREF(node_1724))->loc);
				  arg2091_1729 = (((atom_t) CREF(node_1724))->value);
				  {
				     catom_t res2649_2838;
				     {
					catom_t new1475_2832;
					new1475_2832 = ((catom_t) BREF(GC_MALLOC(sizeof(struct catom))));
					{
					   long arg1981_2833;
					   arg1981_2833 = class_num_218___object(catom_cgen_cop);
					   {
					      obj_t obj_2836;
					      obj_2836 = (obj_t) (new1475_2832);
					      (((obj_t) CREF(obj_2836))->header = MAKE_HEADER(arg1981_2833, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_4573;
					   aux_4573 = (object_t) (new1475_2832);
					   OBJECT_WIDENING_SET(aux_4573, BFALSE);
					}
					((((catom_t) CREF(new1475_2832))->loc) = ((obj_t) arg2090_1728), BUNSPEC);
					((((catom_t) CREF(new1475_2832))->value) = ((obj_t) arg2091_1729), BUNSPEC);
					res2649_2838 = new1475_2832;
				     }
				     arg2089_1727 = res2649_2838;
				  }
			       }
			       aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2089_1727), BEOA);
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    obj_t arg2094_1734;
			    {
			       obj_t aux_4581;
			       {
				  kwote_t aux_4582;
				  aux_4582 = (kwote_t) (node_26);
				  aux_4581 = (obj_t) (aux_4582);
			       }
			       arg2094_1734 = shape_tools_shape(aux_4581);
			    }
			    aux_4563 = internal_error_43_tools_error(string2743_cgen_cgen, string2744_cgen_cgen, arg2094_1734);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1735;
			    node_1735 = (var_t) (node_26);
			    {
			       varc_t arg2095_1738;
			       {
				  obj_t arg2096_1739;
				  variable_t arg2097_1740;
				  arg2096_1739 = (((var_t) CREF(node_1735))->loc);
				  arg2097_1740 = (((var_t) CREF(node_1735))->variable);
				  {
				     varc_t res2650_2849;
				     {
					varc_t new1481_2843;
					new1481_2843 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
					{
					   long arg1979_2844;
					   arg1979_2844 = class_num_218___object(varc_cgen_cop);
					   {
					      obj_t obj_2847;
					      obj_2847 = (obj_t) (new1481_2843);
					      (((obj_t) CREF(obj_2847))->header = MAKE_HEADER(arg1979_2844, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_4594;
					   aux_4594 = (object_t) (new1481_2843);
					   OBJECT_WIDENING_SET(aux_4594, BFALSE);
					}
					((((varc_t) CREF(new1481_2843))->loc) = ((obj_t) arg2096_1739), BUNSPEC);
					((((varc_t) CREF(new1481_2843))->variable) = ((variable_t) arg2097_1740), BUNSPEC);
					res2650_2849 = new1481_2843;
				     }
				     arg2095_1738 = res2650_2849;
				  }
			       }
			       aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2095_1738), BEOA);
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    obj_t arg2100_1745;
			    {
			       obj_t aux_4602;
			       {
				  closure_t aux_4603;
				  aux_4603 = (closure_t) (node_26);
				  aux_4602 = (obj_t) (aux_4603);
			       }
			       arg2100_1745 = shape_tools_shape(aux_4602);
			    }
			    aux_4563 = internal_error_43_tools_error(string2743_cgen_cgen, string2745_cgen_cgen, arg2100_1745);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1746;
			    node_1746 = (sequence_t) (node_26);
			    {
			       obj_t exp_1749;
			       exp_1749 = (((sequence_t) CREF(node_1746))->nodes);
			       if (NULLP(exp_1749))
				 {
				    {
				       nop_t arg2102_1751;
				       {
					  nop_t res2651_2858;
					  {
					     obj_t loc_2852;
					     loc_2852 = BFALSE;
					     {
						nop_t new1508_2853;
						new1508_2853 = ((nop_t) BREF(GC_MALLOC(sizeof(struct nop))));
						{
						   long arg1970_2854;
						   arg1970_2854 = class_num_218___object(nop_cgen_cop);
						   {
						      obj_t obj_2856;
						      obj_2856 = (obj_t) (new1508_2853);
						      (((obj_t) CREF(obj_2856))->header = MAKE_HEADER(arg1970_2854, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_4616;
						   aux_4616 = (object_t) (new1508_2853);
						   OBJECT_WIDENING_SET(aux_4616, loc_2852);
						}
						((((nop_t) CREF(new1508_2853))->loc) = ((obj_t) loc_2852), BUNSPEC);
						res2651_2858 = new1508_2853;
					     }
					  }
					  arg2102_1751 = res2651_2858;
				       }
				       aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2102_1751), BEOA);
				    }
				 }
			       else
				 {
				    bool_t test_4623;
				    {
				       obj_t aux_4624;
				       aux_4624 = CDR(exp_1749);
				       test_4623 = NULLP(aux_4624);
				    }
				    if (test_4623)
				      {
					 {
					    cop_t cop_1753;
					    {
					       node_t aux_4627;
					       {
						  obj_t aux_4628;
						  aux_4628 = CAR(exp_1749);
						  aux_4627 = (node_t) (aux_4628);
					       }
					       cop_1753 = node__cop_142_cgen_cgen(aux_4627, kont_27);
					    }
					    {
					       stop_t res2652_2870;
					       {
						  obj_t loc_2862;
						  loc_2862 = BFALSE;
						  {
						     stop_t new1513_2864;
						     new1513_2864 = ((stop_t) BREF(GC_MALLOC(sizeof(struct stop))));
						     {
							long arg1965_2865;
							arg1965_2865 = class_num_218___object(stop_cgen_cop);
							{
							   obj_t obj_2868;
							   obj_2868 = (obj_t) (new1513_2864);
							   (((obj_t) CREF(obj_2868))->header = MAKE_HEADER(arg1965_2865, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_4636;
							aux_4636 = (object_t) (new1513_2864);
							OBJECT_WIDENING_SET(aux_4636, loc_2862);
						     }
						     ((((stop_t) CREF(new1513_2864))->loc) = ((obj_t) loc_2862), BUNSPEC);
						     ((((stop_t) CREF(new1513_2864))->value) = ((cop_t) cop_1753), BUNSPEC);
						     res2652_2870 = new1513_2864;
						  }
					       }
					       aux_4563 = (obj_t) (res2652_2870);
					    }
					 }
				      }
				    else
				      {
					 {
					    obj_t exp_1756;
					    obj_t new_1757;
					    {
					       csequence_t aux_4642;
					       exp_1756 = exp_1749;
					       new_1757 = BNIL;
					     loop_1758:
					       {
						  bool_t test_4643;
						  {
						     obj_t aux_4644;
						     aux_4644 = CDR(exp_1756);
						     test_4643 = NULLP(aux_4644);
						  }
						  if (test_4643)
						    {
						       obj_t arg2109_1761;
						       {
							  obj_t arg2111_1762;
							  {
							     cop_t arg2112_1763;
							     {
								node_t aux_4647;
								{
								   obj_t aux_4648;
								   aux_4648 = CAR(exp_1756);
								   aux_4647 = (node_t) (aux_4648);
								}
								arg2112_1763 = node__cop_142_cgen_cgen(aux_4647, kont_27);
							     }
							     {
								obj_t aux_4652;
								aux_4652 = (obj_t) (arg2112_1763);
								arg2111_1762 = MAKE_PAIR(aux_4652, new_1757);
							     }
							  }
							  arg2109_1761 = reverse__39___r4_pairs_and_lists_6_3(arg2111_1762);
						       }
						       {
							  csequence_t res2653_2886;
							  {
							     obj_t loc_2876;
							     loc_2876 = BFALSE;
							     {
								csequence_t new1501_2879;
								new1501_2879 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
								{
								   long arg1972_2880;
								   arg1972_2880 = class_num_218___object(csequence_cgen_cop);
								   {
								      obj_t obj_2884;
								      obj_2884 = (obj_t) (new1501_2879);
								      (((obj_t) CREF(obj_2884))->header = MAKE_HEADER(arg1972_2880, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_4660;
								   aux_4660 = (object_t) (new1501_2879);
								   OBJECT_WIDENING_SET(aux_4660, loc_2876);
								}
								((((csequence_t) CREF(new1501_2879))->loc) = ((obj_t) loc_2876), BUNSPEC);
								((((csequence_t) CREF(new1501_2879))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
								((((csequence_t) CREF(new1501_2879))->cops) = ((obj_t) arg2109_1761), BUNSPEC);
								res2653_2886 = new1501_2879;
							     }
							  }
							  aux_4642 = res2653_2886;
						       }
						    }
						  else
						    {
						       {
							  bool_t test2114_1765;
							  {
							     node_t aux_4666;
							     {
								obj_t aux_4667;
								aux_4667 = CAR(exp_1756);
								aux_4666 = (node_t) (aux_4667);
							     }
							     test2114_1765 = side_effect__165_effect_effect(aux_4666);
							  }
							  if (test2114_1765)
							    {
							       obj_t arg2115_1766;
							       obj_t arg2116_1767;
							       arg2115_1766 = CDR(exp_1756);
							       {
								  cop_t arg2117_1768;
								  {
								     node_t aux_4673;
								     {
									obj_t aux_4674;
									aux_4674 = CAR(exp_1756);
									aux_4673 = (node_t) (aux_4674);
								     }
								     arg2117_1768 = node__cop_142_cgen_cgen(aux_4673, _stop_kont__121_cgen_cgen);
								  }
								  {
								     obj_t aux_4678;
								     aux_4678 = (obj_t) (arg2117_1768);
								     arg2116_1767 = MAKE_PAIR(aux_4678, new_1757);
								  }
							       }
							       {
								  obj_t new_4682;
								  obj_t exp_4681;
								  exp_4681 = arg2115_1766;
								  new_4682 = arg2116_1767;
								  new_1757 = new_4682;
								  exp_1756 = exp_4681;
								  goto loop_1758;
							       }
							    }
							  else
							    {
							       obj_t exp_4683;
							       exp_4683 = CDR(exp_1756);
							       exp_1756 = exp_4683;
							       goto loop_1758;
							    }
						       }
						    }
					       }
					       aux_4563 = (obj_t) (aux_4642);
					    }
					 }
				      }
				 }
			    }
			 }
			 break;
		      case ((long) 5):
			 {
			    pragma_t node_1774;
			    node_1774 = (pragma_t) (node_26);
			    {
			       obj_t old_actuals_174_1777;
			       obj_t new_actuals_73_1778;
			       local_t aux_1779;
			       obj_t auxs_1780;
			       obj_t exps_1781;
			       {
				  obj_t arg2125_1783;
				  local_t arg2129_1785;
				  arg2125_1783 = (((pragma_t) CREF(node_1774))->args);
				  arg2129_1785 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (type_t) (_obj__252_type_cache));
				  old_actuals_174_1777 = arg2125_1783;
				  new_actuals_73_1778 = BNIL;
				  aux_1779 = arg2129_1785;
				  auxs_1780 = BNIL;
				  exps_1781 = BNIL;
				loop_1782:
				  if (NULLP(old_actuals_174_1777))
				    {
				       if (NULLP(auxs_1780))
					 {
					    cpragma_t arg2136_1791;
					    {
					       obj_t arg2137_1792;
					       obj_t arg2138_1793;
					       obj_t arg2139_1794;
					       arg2137_1792 = (((pragma_t) CREF(node_1774))->loc);
					       arg2138_1793 = (((pragma_t) CREF(node_1774))->format);
					       arg2139_1794 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1778);
					       {
						  cpragma_t res2654_2908;
						  {
						     cpragma_t new1487_2901;
						     new1487_2901 = ((cpragma_t) BREF(GC_MALLOC(sizeof(struct cpragma))));
						     {
							long arg1977_2902;
							arg1977_2902 = class_num_218___object(cpragma_cgen_cop);
							{
							   obj_t obj_2906;
							   obj_2906 = (obj_t) (new1487_2901);
							   (((obj_t) CREF(obj_2906))->header = MAKE_HEADER(arg1977_2902, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_4702;
							aux_4702 = (object_t) (new1487_2901);
							OBJECT_WIDENING_SET(aux_4702, BFALSE);
						     }
						     ((((cpragma_t) CREF(new1487_2901))->loc) = ((obj_t) arg2137_1792), BUNSPEC);
						     ((((cpragma_t) CREF(new1487_2901))->format) = ((obj_t) arg2138_1793), BUNSPEC);
						     ((((cpragma_t) CREF(new1487_2901))->args) = ((obj_t) arg2139_1794), BUNSPEC);
						     res2654_2908 = new1487_2901;
						  }
						  arg2136_1791 = res2654_2908;
					       }
					    }
					    aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2136_1791), BEOA);
					 }
				       else
					 {
					    csequence_t arg2140_1795;
					    {
					       obj_t arg2141_1796;
					       {
						  local_var_164_t arg2143_1797;
						  csequence_t arg2144_1798;
						  obj_t arg2145_1799;
						  {
						     obj_t arg2150_1804;
						     arg2150_1804 = (((pragma_t) CREF(node_1774))->loc);
						     {
							local_var_164_t res2655_2918;
							{
							   local_var_164_t new1534_2912;
							   new1534_2912 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							   {
							      long arg1959_2913;
							      arg1959_2913 = class_num_218___object(local_var_164_cgen_cop);
							      {
								 obj_t obj_2916;
								 obj_2916 = (obj_t) (new1534_2912);
								 (((obj_t) CREF(obj_2916))->header = MAKE_HEADER(arg1959_2913, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_4716;
							      aux_4716 = (object_t) (new1534_2912);
							      OBJECT_WIDENING_SET(aux_4716, BFALSE);
							   }
							   ((((local_var_164_t) CREF(new1534_2912))->loc) = ((obj_t) arg2150_1804), BUNSPEC);
							   ((((local_var_164_t) CREF(new1534_2912))->vars) = ((obj_t) auxs_1780), BUNSPEC);
							   res2655_2918 = new1534_2912;
							}
							arg2143_1797 = res2655_2918;
						     }
						  }
						  {
						     csequence_t res2656_2929;
						     {
							obj_t loc_2919;
							loc_2919 = BFALSE;
							{
							   csequence_t new1501_2922;
							   new1501_2922 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							   {
							      long arg1972_2923;
							      arg1972_2923 = class_num_218___object(csequence_cgen_cop);
							      {
								 obj_t obj_2927;
								 obj_2927 = (obj_t) (new1501_2922);
								 (((obj_t) CREF(obj_2927))->header = MAKE_HEADER(arg1972_2923, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_4725;
							      aux_4725 = (object_t) (new1501_2922);
							      OBJECT_WIDENING_SET(aux_4725, loc_2919);
							   }
							   ((((csequence_t) CREF(new1501_2922))->loc) = ((obj_t) loc_2919), BUNSPEC);
							   ((((csequence_t) CREF(new1501_2922))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							   ((((csequence_t) CREF(new1501_2922))->cops) = ((obj_t) exps_1781), BUNSPEC);
							   res2656_2929 = new1501_2922;
							}
						     }
						     arg2144_1798 = res2656_2929;
						  }
						  {
						     cpragma_t arg2153_1807;
						     {
							obj_t arg2154_1808;
							obj_t arg2155_1809;
							obj_t arg2156_1810;
							arg2154_1808 = (((pragma_t) CREF(node_1774))->loc);
							arg2155_1809 = (((pragma_t) CREF(node_1774))->format);
							arg2156_1810 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1778);
							{
							   cpragma_t res2657_2942;
							   {
							      cpragma_t new1487_2935;
							      new1487_2935 = ((cpragma_t) BREF(GC_MALLOC(sizeof(struct cpragma))));
							      {
								 long arg1977_2936;
								 arg1977_2936 = class_num_218___object(cpragma_cgen_cop);
								 {
								    obj_t obj_2940;
								    obj_2940 = (obj_t) (new1487_2935);
								    (((obj_t) CREF(obj_2940))->header = MAKE_HEADER(arg1977_2936, 0), BUNSPEC);
								 }
							      }
							      {
								 object_t aux_4738;
								 aux_4738 = (object_t) (new1487_2935);
								 OBJECT_WIDENING_SET(aux_4738, BFALSE);
							      }
							      ((((cpragma_t) CREF(new1487_2935))->loc) = ((obj_t) arg2154_1808), BUNSPEC);
							      ((((cpragma_t) CREF(new1487_2935))->format) = ((obj_t) arg2155_1809), BUNSPEC);
							      ((((cpragma_t) CREF(new1487_2935))->args) = ((obj_t) arg2156_1810), BUNSPEC);
							      res2657_2942 = new1487_2935;
							   }
							   arg2153_1807 = res2657_2942;
							}
						     }
						     arg2145_1799 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2153_1807), BEOA);
						  }
						  {
						     obj_t list2146_1800;
						     {
							obj_t arg2147_1801;
							{
							   obj_t arg2148_1802;
							   arg2148_1802 = MAKE_PAIR(arg2145_1799, BNIL);
							   {
							      obj_t aux_4748;
							      aux_4748 = (obj_t) (arg2144_1798);
							      arg2147_1801 = MAKE_PAIR(aux_4748, arg2148_1802);
							   }
							}
							{
							   obj_t aux_4751;
							   aux_4751 = (obj_t) (arg2143_1797);
							   list2146_1800 = MAKE_PAIR(aux_4751, arg2147_1801);
							}
						     }
						     arg2141_1796 = list2146_1800;
						  }
					       }
					       {
						  csequence_t res2658_2954;
						  {
						     obj_t loc_2944;
						     loc_2944 = BFALSE;
						     {
							csequence_t new1501_2947;
							new1501_2947 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							{
							   long arg1972_2948;
							   arg1972_2948 = class_num_218___object(csequence_cgen_cop);
							   {
							      obj_t obj_2952;
							      obj_2952 = (obj_t) (new1501_2947);
							      (((obj_t) CREF(obj_2952))->header = MAKE_HEADER(arg1972_2948, 0), BUNSPEC);
							   }
							}
							{
							   object_t aux_4758;
							   aux_4758 = (object_t) (new1501_2947);
							   OBJECT_WIDENING_SET(aux_4758, loc_2944);
							}
							((((csequence_t) CREF(new1501_2947))->loc) = ((obj_t) loc_2944), BUNSPEC);
							((((csequence_t) CREF(new1501_2947))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							((((csequence_t) CREF(new1501_2947))->cops) = ((obj_t) arg2141_1796), BUNSPEC);
							res2658_2954 = new1501_2947;
						     }
						  }
						  arg2140_1795 = res2658_2954;
					       }
					    }
					    {
					       block_t res2659_2963;
					       {
						  obj_t loc_2955;
						  cop_t body_2956;
						  loc_2955 = BFALSE;
						  body_2956 = (cop_t) (arg2140_1795);
						  {
						     block_t new1457_2957;
						     new1457_2957 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						     {
							long arg1987_2958;
							arg1987_2958 = class_num_218___object(block_cgen_cop);
							{
							   obj_t obj_2961;
							   obj_2961 = (obj_t) (new1457_2957);
							   (((obj_t) CREF(obj_2961))->header = MAKE_HEADER(arg1987_2958, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_4769;
							aux_4769 = (object_t) (new1457_2957);
							OBJECT_WIDENING_SET(aux_4769, loc_2955);
						     }
						     ((((block_t) CREF(new1457_2957))->loc) = ((obj_t) loc_2955), BUNSPEC);
						     ((((block_t) CREF(new1457_2957))->body) = ((cop_t) body_2956), BUNSPEC);
						     res2659_2963 = new1457_2957;
						  }
					       }
					       aux_4563 = (obj_t) (res2659_2963);
					    }
					 }
				    }
				  else
				    {
				       cop_t cop_1811;
				       {
					  setq_t arg2182_1836;
					  {
					     node_t aux_4775;
					     {
						obj_t aux_4777;
						aux_4777 = CAR(old_actuals_174_1777);
						aux_4775 = (node_t) (aux_4777);
					     }
					     arg2182_1836 = node_setq_243_cgen_cgen((variable_t) (aux_1779), aux_4775);
					  }
					  cop_1811 = node__cop_142_cgen_cgen((node_t) (arg2182_1836), _id_kont__126_cgen_cgen);
				       }
				       {
					  bool_t test2157_1812;
					  {
					     bool_t test2174_1827;
					     test2174_1827 = is_a__118___object((obj_t) (cop_1811), csetq_cgen_cop);
					     if (test2174_1827)
					       {
						  bool_t test_4786;
						  {
						     obj_t aux_4793;
						     obj_t aux_4787;
						     aux_4793 = (obj_t) (aux_1779);
						     {
							variable_t aux_4788;
							{
							   varc_t arg2181_1835;
							   {
							      csetq_t obj_2966;
							      obj_2966 = (csetq_t) (cop_1811);
							      arg2181_1835 = (((csetq_t) CREF(obj_2966))->var);
							   }
							   aux_4788 = (((varc_t) CREF(arg2181_1835))->variable);
							}
							aux_4787 = (obj_t) (aux_4788);
						     }
						     test_4786 = (aux_4787 == aux_4793);
						  }
						  if (test_4786)
						    {
						       bool_t _ortest_1668_1829;
						       {
							  obj_t aux_4796;
							  {
							     cop_t aux_4797;
							     {
								csetq_t obj_2970;
								obj_2970 = (csetq_t) (cop_1811);
								aux_4797 = (((csetq_t) CREF(obj_2970))->value);
							     }
							     aux_4796 = (obj_t) (aux_4797);
							  }
							  _ortest_1668_1829 = is_a__118___object(aux_4796, catom_cgen_cop);
						       }
						       if (_ortest_1668_1829)
							 {
							    test2157_1812 = _ortest_1668_1829;
							 }
						       else
							 {
							    bool_t _ortest_1669_1830;
							    {
							       obj_t aux_4803;
							       {
								  cop_t aux_4804;
								  {
								     csetq_t obj_2972;
								     obj_2972 = (csetq_t) (cop_1811);
								     aux_4804 = (((csetq_t) CREF(obj_2972))->value);
								  }
								  aux_4803 = (obj_t) (aux_4804);
							       }
							       _ortest_1669_1830 = is_a__118___object(aux_4803, varc_cgen_cop);
							    }
							    if (_ortest_1669_1830)
							      {
								 test2157_1812 = _ortest_1669_1830;
							      }
							    else
							      {
								 obj_t aux_4810;
								 {
								    cop_t aux_4811;
								    {
								       csetq_t obj_2974;
								       obj_2974 = (csetq_t) (cop_1811);
								       aux_4811 = (((csetq_t) CREF(obj_2974))->value);
								    }
								    aux_4810 = (obj_t) (aux_4811);
								 }
								 test2157_1812 = is_a__118___object(aux_4810, cpragma_cgen_cop);
							      }
							 }
						    }
						  else
						    {
						       test2157_1812 = ((bool_t) 0);
						    }
					       }
					     else
					       {
						  test2157_1812 = ((bool_t) 0);
					       }
					  }
					  if (test2157_1812)
					    {
					       obj_t arg2158_1813;
					       obj_t arg2159_1814;
					       arg2158_1813 = CDR(old_actuals_174_1777);
					       {
						  obj_t aux_4818;
						  {
						     cop_t aux_4819;
						     {
							csetq_t obj_2977;
							obj_2977 = (csetq_t) (cop_1811);
							aux_4819 = (((csetq_t) CREF(obj_2977))->value);
						     }
						     aux_4818 = (obj_t) (aux_4819);
						  }
						  arg2159_1814 = MAKE_PAIR(aux_4818, new_actuals_73_1778);
					       }
					       {
						  obj_t new_actuals_73_4825;
						  obj_t old_actuals_174_4824;
						  old_actuals_174_4824 = arg2158_1813;
						  new_actuals_73_4825 = arg2159_1814;
						  new_actuals_73_1778 = new_actuals_73_4825;
						  old_actuals_174_1777 = old_actuals_174_4824;
						  goto loop_1782;
					       }
					    }
					  else
					    {
					       {
						  type_t arg2161_1816;
						  {
						     node_t aux_4826;
						     {
							obj_t aux_4827;
							aux_4827 = CAR(old_actuals_174_1777);
							aux_4826 = (node_t) (aux_4827);
						     }
						     arg2161_1816 = typeof_coerce_typeof(aux_4826);
						  }
						  ((((local_t) CREF(aux_1779))->type) = ((type_t) arg2161_1816), BUNSPEC);
					       }
					       {
						  obj_t arg2163_1818;
						  obj_t arg2164_1819;
						  local_t arg2165_1820;
						  obj_t arg2166_1821;
						  obj_t arg2167_1822;
						  arg2163_1818 = CDR(old_actuals_174_1777);
						  {
						     varc_t arg2169_1823;
						     {
							obj_t arg2170_1824;
							arg2170_1824 = (((pragma_t) CREF(node_1774))->loc);
							{
							   varc_t res2660_2993;
							   {
							      variable_t variable_2986;
							      variable_2986 = (variable_t) (aux_1779);
							      {
								 varc_t new1481_2987;
								 new1481_2987 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								 {
								    long arg1979_2988;
								    arg1979_2988 = class_num_218___object(varc_cgen_cop);
								    {
								       obj_t obj_2991;
								       obj_2991 = (obj_t) (new1481_2987);
								       (((obj_t) CREF(obj_2991))->header = MAKE_HEADER(arg1979_2988, 0), BUNSPEC);
								    }
								 }
								 {
								    object_t aux_4839;
								    aux_4839 = (object_t) (new1481_2987);
								    OBJECT_WIDENING_SET(aux_4839, BFALSE);
								 }
								 ((((varc_t) CREF(new1481_2987))->loc) = ((obj_t) arg2170_1824), BUNSPEC);
								 ((((varc_t) CREF(new1481_2987))->variable) = ((variable_t) variable_2986), BUNSPEC);
								 res2660_2993 = new1481_2987;
							      }
							   }
							   arg2169_1823 = res2660_2993;
							}
						     }
						     {
							obj_t aux_4844;
							aux_4844 = (obj_t) (arg2169_1823);
							arg2164_1819 = MAKE_PAIR(aux_4844, new_actuals_73_1778);
						     }
						  }
						  arg2165_1820 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (type_t) (_obj__252_type_cache));
						  {
						     obj_t aux_4850;
						     aux_4850 = (obj_t) (aux_1779);
						     arg2166_1821 = MAKE_PAIR(aux_4850, auxs_1780);
						  }
						  {
						     obj_t aux_4853;
						     aux_4853 = (obj_t) (cop_1811);
						     arg2167_1822 = MAKE_PAIR(aux_4853, exps_1781);
						  }
						  {
						     obj_t exps_4860;
						     obj_t auxs_4859;
						     local_t aux_4858;
						     obj_t new_actuals_73_4857;
						     obj_t old_actuals_174_4856;
						     old_actuals_174_4856 = arg2163_1818;
						     new_actuals_73_4857 = arg2164_1819;
						     aux_4858 = arg2165_1820;
						     auxs_4859 = arg2166_1821;
						     exps_4860 = arg2167_1822;
						     exps_1781 = exps_4860;
						     auxs_1780 = auxs_4859;
						     aux_1779 = aux_4858;
						     new_actuals_73_1778 = new_actuals_73_4857;
						     old_actuals_174_1777 = old_actuals_174_4856;
						     goto loop_1782;
						  }
					       }
					    }
				       }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 6):
			 {
			    cast_t node_1838;
			    node_1838 = (cast_t) (node_26);
			    {
			       ccast_t arg2184_1841;
			       {
				  obj_t arg2185_1842;
				  type_t arg2186_1843;
				  cop_t arg2187_1844;
				  arg2185_1842 = (((cast_t) CREF(node_1838))->loc);
				  arg2186_1843 = (((cast_t) CREF(node_1838))->type);
				  arg2187_1844 = node__cop_142_cgen_cgen((((cast_t) CREF(node_1838))->arg), _id_kont__126_cgen_cgen);
				  {
				     ccast_t res2661_3013;
				     {
					ccast_t new1494_3006;
					new1494_3006 = ((ccast_t) BREF(GC_MALLOC(sizeof(struct ccast))));
					{
					   long arg1974_3007;
					   arg1974_3007 = class_num_218___object(ccast_cgen_cop);
					   {
					      obj_t obj_3011;
					      obj_3011 = (obj_t) (new1494_3006);
					      (((obj_t) CREF(obj_3011))->header = MAKE_HEADER(arg1974_3007, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_4870;
					   aux_4870 = (object_t) (new1494_3006);
					   OBJECT_WIDENING_SET(aux_4870, BFALSE);
					}
					((((ccast_t) CREF(new1494_3006))->loc) = ((obj_t) arg2185_1842), BUNSPEC);
					((((ccast_t) CREF(new1494_3006))->type) = ((type_t) arg2186_1843), BUNSPEC);
					((((ccast_t) CREF(new1494_3006))->arg) = ((cop_t) arg2187_1844), BUNSPEC);
					res2661_3013 = new1494_3006;
				     }
				     arg2184_1841 = res2661_3013;
				  }
			       }
			       aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2184_1841), BEOA);
			    }
			 }
			 break;
		      case ((long) 7):
			 {
			    setq_t node_1846;
			    node_1846 = (setq_t) (node_26);
			    {
			       variable_t var_1849;
			       {
				  var_t arg2202_1862;
				  arg2202_1862 = (((setq_t) CREF(node_1846))->var);
				  var_1849 = (((var_t) CREF(arg2202_1862))->variable);
			       }
			       {
				  bool_t test2189_1850;
				  {
				     bool_t test2198_1858;
				     {
					obj_t aux_4882;
					{
					   node_t aux_4883;
					   aux_4883 = (((setq_t) CREF(node_1846))->value);
					   aux_4882 = (obj_t) (aux_4883);
					}
					test2198_1858 = is_a__118___object(aux_4882, var_ast_node);
				     }
				     if (test2198_1858)
				       {
					  obj_t aux_4890;
					  obj_t aux_4888;
					  {
					     variable_t aux_4891;
					     {
						var_t obj_3019;
						{
						   node_t aux_4892;
						   aux_4892 = (((setq_t) CREF(node_1846))->value);
						   obj_3019 = (var_t) (aux_4892);
						}
						aux_4891 = (((var_t) CREF(obj_3019))->variable);
					     }
					     aux_4890 = (obj_t) (aux_4891);
					  }
					  aux_4888 = (obj_t) (var_1849);
					  test2189_1850 = (aux_4888 == aux_4890);
				       }
				     else
				       {
					  test2189_1850 = ((bool_t) 0);
				       }
				  }
				  if (test2189_1850)
				    {
				       cvoid_t arg2190_1851;
				       {
					  catom_t arg2191_1852;
					  {
					     obj_t arg2192_1853;
					     arg2192_1853 = (((setq_t) CREF(node_1846))->loc);
					     {
						catom_t res2662_3031;
						{
						   catom_t new1475_3025;
						   new1475_3025 = ((catom_t) BREF(GC_MALLOC(sizeof(struct catom))));
						   {
						      long arg1981_3026;
						      arg1981_3026 = class_num_218___object(catom_cgen_cop);
						      {
							 obj_t obj_3029;
							 obj_3029 = (obj_t) (new1475_3025);
							 (((obj_t) CREF(obj_3029))->header = MAKE_HEADER(arg1981_3026, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_4904;
						      aux_4904 = (object_t) (new1475_3025);
						      OBJECT_WIDENING_SET(aux_4904, BFALSE);
						   }
						   ((((catom_t) CREF(new1475_3025))->loc) = ((obj_t) arg2192_1853), BUNSPEC);
						   ((((catom_t) CREF(new1475_3025))->value) = ((obj_t) BUNSPEC), BUNSPEC);
						   res2662_3031 = new1475_3025;
						}
						arg2191_1852 = res2662_3031;
					     }
					  }
					  {
					     cvoid_t res2663_3042;
					     {
						obj_t loc_3034;
						cop_t value_3035;
						loc_3034 = BFALSE;
						value_3035 = (cop_t) (arg2191_1852);
						{
						   cvoid_t new1469_3036;
						   new1469_3036 = ((cvoid_t) BREF(GC_MALLOC(sizeof(struct cvoid))));
						   {
						      long arg1983_3037;
						      arg1983_3037 = class_num_218___object(cvoid_cgen_cop);
						      {
							 obj_t obj_3040;
							 obj_3040 = (obj_t) (new1469_3036);
							 (((obj_t) CREF(obj_3040))->header = MAKE_HEADER(arg1983_3037, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_4914;
						      aux_4914 = (object_t) (new1469_3036);
						      OBJECT_WIDENING_SET(aux_4914, loc_3034);
						   }
						   ((((cvoid_t) CREF(new1469_3036))->loc) = ((obj_t) loc_3034), BUNSPEC);
						   ((((cvoid_t) CREF(new1469_3036))->value) = ((cop_t) value_3035), BUNSPEC);
						   res2663_3042 = new1469_3036;
						}
					     }
					     arg2190_1851 = res2663_3042;
					  }
				       }
				       aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2190_1851), BEOA);
				    }
				  else
				    {
				       node_t arg2194_1855;
				       obj_t arg2196_1856;
				       arg2194_1855 = (((setq_t) CREF(node_1846))->value);
				       arg2196_1856 = make_setq_kont_65_cgen_cgen(var_1849, (((setq_t) CREF(node_1846))->loc), kont_27);
				       {
					  cop_t aux_4925;
					  aux_4925 = node__cop_142_cgen_cgen(arg2194_1855, arg2196_1856);
					  aux_4563 = (obj_t) (aux_4925);
				       }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 8):
			 {
			    conditional_t node_1863;
			    node_1863 = (conditional_t) (node_26);
			    {
			       local_t aux_1866;
			       aux_1866 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 2)), (type_t) (_bool__149_type_cache));
			       {
				  cop_t ctest_1867;
				  {
				     setq_t arg2244_1906;
				     arg2244_1906 = node_setq_243_cgen_cgen((variable_t) (aux_1866), (((conditional_t) CREF(node_1863))->test));
				     ctest_1867 = node__cop_142_cgen_cgen((node_t) (arg2244_1906), _id_kont__126_cgen_cgen);
				  }
				  {
				     {
					bool_t test2203_1868;
					{
					   bool_t test2240_1903;
					   test2240_1903 = is_a__118___object((obj_t) (ctest_1867), csetq_cgen_cop);
					   if (test2240_1903)
					     {
						obj_t aux_4946;
						obj_t aux_4940;
						aux_4946 = (obj_t) (aux_1866);
						{
						   variable_t aux_4941;
						   {
						      varc_t arg2243_1905;
						      {
							 csetq_t obj_3047;
							 obj_3047 = (csetq_t) (ctest_1867);
							 arg2243_1905 = (((csetq_t) CREF(obj_3047))->var);
						      }
						      aux_4941 = (((varc_t) CREF(arg2243_1905))->variable);
						   }
						   aux_4940 = (obj_t) (aux_4941);
						}
						test2203_1868 = (aux_4940 == aux_4946);
					     }
					   else
					     {
						test2203_1868 = ((bool_t) 0);
					     }
					}
					if (test2203_1868)
					  {
					     obj_t arg2204_1869;
					     cop_t arg2205_1870;
					     obj_t arg2206_1871;
					     obj_t arg2207_1872;
					     arg2204_1869 = (((conditional_t) CREF(node_1863))->loc);
					     {
						csetq_t obj_3052;
						obj_3052 = (csetq_t) (ctest_1867);
						arg2205_1870 = (((csetq_t) CREF(obj_3052))->value);
					     }
					     {
						cop_t arg2208_1873;
						obj_t arg2209_1874;
						arg2208_1873 = node__cop_142_cgen_cgen((((conditional_t) CREF(node_1863))->true), kont_27);
						arg2209_1874 = (((conditional_t) CREF(node_1863))->loc);
						{
						   obj_t cop_3055;
						   cop_3055 = (obj_t) (arg2208_1873);
						   {
						      bool_t test1897_3057;
						      test1897_3057 = is_a__118___object(cop_3055, block_cgen_cop);
						      if (test1897_3057)
							{
							   arg2206_1871 = cop_3055;
							}
						      else
							{
							   {
							      block_t res2664_3069;
							      {
								 cop_t body_3062;
								 body_3062 = (cop_t) (cop_3055);
								 {
								    block_t new1457_3063;
								    new1457_3063 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
								    {
								       long arg1987_3064;
								       arg1987_3064 = class_num_218___object(block_cgen_cop);
								       {
									  obj_t obj_3067;
									  obj_3067 = (obj_t) (new1457_3063);
									  (((obj_t) CREF(obj_3067))->header = MAKE_HEADER(arg1987_3064, 0), BUNSPEC);
								       }
								    }
								    {
								       object_t aux_4964;
								       aux_4964 = (object_t) (new1457_3063);
								       OBJECT_WIDENING_SET(aux_4964, BFALSE);
								    }
								    ((((block_t) CREF(new1457_3063))->loc) = ((obj_t) arg2209_1874), BUNSPEC);
								    ((((block_t) CREF(new1457_3063))->body) = ((cop_t) body_3062), BUNSPEC);
								    res2664_3069 = new1457_3063;
								 }
							      }
							      arg2206_1871 = (obj_t) (res2664_3069);
							   }
							}
						   }
						}
					     }
					     {
						cop_t arg2211_1876;
						obj_t arg2213_1877;
						arg2211_1876 = node__cop_142_cgen_cgen((((conditional_t) CREF(node_1863))->false), kont_27);
						arg2213_1877 = (((conditional_t) CREF(node_1863))->loc);
						{
						   obj_t cop_3072;
						   cop_3072 = (obj_t) (arg2211_1876);
						   {
						      bool_t test1897_3074;
						      test1897_3074 = is_a__118___object(cop_3072, block_cgen_cop);
						      if (test1897_3074)
							{
							   arg2207_1872 = cop_3072;
							}
						      else
							{
							   {
							      block_t res2665_3086;
							      {
								 cop_t body_3079;
								 body_3079 = (cop_t) (cop_3072);
								 {
								    block_t new1457_3080;
								    new1457_3080 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
								    {
								       long arg1987_3081;
								       arg1987_3081 = class_num_218___object(block_cgen_cop);
								       {
									  obj_t obj_3084;
									  obj_3084 = (obj_t) (new1457_3080);
									  (((obj_t) CREF(obj_3084))->header = MAKE_HEADER(arg1987_3081, 0), BUNSPEC);
								       }
								    }
								    {
								       object_t aux_4981;
								       aux_4981 = (object_t) (new1457_3080);
								       OBJECT_WIDENING_SET(aux_4981, BFALSE);
								    }
								    ((((block_t) CREF(new1457_3080))->loc) = ((obj_t) arg2213_1877), BUNSPEC);
								    ((((block_t) CREF(new1457_3080))->body) = ((cop_t) body_3079), BUNSPEC);
								    res2665_3086 = new1457_3080;
								 }
							      }
							      arg2207_1872 = (obj_t) (res2665_3086);
							   }
							}
						   }
						}
					     }
					     {
						cif_t res2666_3099;
						{
						   cop_t true_3089;
						   cop_t false_3090;
						   true_3089 = (cop_t) (arg2206_1871);
						   false_3090 = (cop_t) (arg2207_1872);
						   {
						      cif_t new1526_3091;
						      new1526_3091 = ((cif_t) BREF(GC_MALLOC(sizeof(struct cif))));
						      {
							 long arg1961_3092;
							 arg1961_3092 = class_num_218___object(cif_cgen_cop);
							 {
							    obj_t obj_3097;
							    obj_3097 = (obj_t) (new1526_3091);
							    (((obj_t) CREF(obj_3097))->header = MAKE_HEADER(arg1961_3092, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_4993;
							 aux_4993 = (object_t) (new1526_3091);
							 OBJECT_WIDENING_SET(aux_4993, BFALSE);
						      }
						      ((((cif_t) CREF(new1526_3091))->loc) = ((obj_t) arg2204_1869), BUNSPEC);
						      ((((cif_t) CREF(new1526_3091))->test) = ((cop_t) arg2205_1870), BUNSPEC);
						      ((((cif_t) CREF(new1526_3091))->true) = ((cop_t) true_3089), BUNSPEC);
						      ((((cif_t) CREF(new1526_3091))->false) = ((cop_t) false_3090), BUNSPEC);
						      res2666_3099 = new1526_3091;
						   }
						}
						aux_4563 = (obj_t) (res2666_3099);
					     }
					  }
					else
					  {
					     obj_t arg2215_1879;
					     csequence_t arg2216_1880;
					     arg2215_1879 = (((conditional_t) CREF(node_1863))->loc);
					     {
						obj_t arg2217_1881;
						{
						   local_var_164_t arg2219_1882;
						   cif_t arg2220_1883;
						   {
						      obj_t arg2225_1888;
						      obj_t arg2226_1889;
						      arg2225_1888 = (((conditional_t) CREF(node_1863))->loc);
						      {
							 obj_t list2227_1890;
							 {
							    obj_t aux_5003;
							    aux_5003 = (obj_t) (aux_1866);
							    list2227_1890 = MAKE_PAIR(aux_5003, BNIL);
							 }
							 arg2226_1889 = list2227_1890;
						      }
						      {
							 local_var_164_t res2667_3111;
							 {
							    local_var_164_t new1534_3105;
							    new1534_3105 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							    {
							       long arg1959_3106;
							       arg1959_3106 = class_num_218___object(local_var_164_cgen_cop);
							       {
								  obj_t obj_3109;
								  obj_3109 = (obj_t) (new1534_3105);
								  (((obj_t) CREF(obj_3109))->header = MAKE_HEADER(arg1959_3106, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_5010;
							       aux_5010 = (object_t) (new1534_3105);
							       OBJECT_WIDENING_SET(aux_5010, BFALSE);
							    }
							    ((((local_var_164_t) CREF(new1534_3105))->loc) = ((obj_t) arg2225_1888), BUNSPEC);
							    ((((local_var_164_t) CREF(new1534_3105))->vars) = ((obj_t) arg2226_1889), BUNSPEC);
							    res2667_3111 = new1534_3105;
							 }
							 arg2219_1882 = res2667_3111;
						      }
						   }
						   {
						      obj_t arg2229_1892;
						      varc_t arg2230_1893;
						      obj_t arg2231_1894;
						      obj_t arg2232_1895;
						      arg2229_1892 = (((conditional_t) CREF(node_1863))->loc);
						      {
							 varc_t res2668_3121;
							 {
							    obj_t loc_3113;
							    variable_t variable_3114;
							    loc_3113 = BFALSE;
							    variable_3114 = (variable_t) (aux_1866);
							    {
							       varc_t new1481_3115;
							       new1481_3115 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
							       {
								  long arg1979_3116;
								  arg1979_3116 = class_num_218___object(varc_cgen_cop);
								  {
								     obj_t obj_3119;
								     obj_3119 = (obj_t) (new1481_3115);
								     (((obj_t) CREF(obj_3119))->header = MAKE_HEADER(arg1979_3116, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_5021;
								  aux_5021 = (object_t) (new1481_3115);
								  OBJECT_WIDENING_SET(aux_5021, loc_3113);
							       }
							       ((((varc_t) CREF(new1481_3115))->loc) = ((obj_t) loc_3113), BUNSPEC);
							       ((((varc_t) CREF(new1481_3115))->variable) = ((variable_t) variable_3114), BUNSPEC);
							       res2668_3121 = new1481_3115;
							    }
							 }
							 arg2230_1893 = res2668_3121;
						      }
						      {
							 cop_t arg2234_1897;
							 obj_t arg2235_1898;
							 arg2234_1897 = node__cop_142_cgen_cgen((((conditional_t) CREF(node_1863))->true), kont_27);
							 arg2235_1898 = (((conditional_t) CREF(node_1863))->loc);
							 {
							    obj_t cop_3124;
							    cop_3124 = (obj_t) (arg2234_1897);
							    {
							       bool_t test1897_3126;
							       test1897_3126 = is_a__118___object(cop_3124, block_cgen_cop);
							       if (test1897_3126)
								 {
								    arg2231_1894 = cop_3124;
								 }
							       else
								 {
								    {
								       block_t res2669_3138;
								       {
									  cop_t body_3131;
									  body_3131 = (cop_t) (cop_3124);
									  {
									     block_t new1457_3132;
									     new1457_3132 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
									     {
										long arg1987_3133;
										arg1987_3133 = class_num_218___object(block_cgen_cop);
										{
										   obj_t obj_3136;
										   obj_3136 = (obj_t) (new1457_3132);
										   (((obj_t) CREF(obj_3136))->header = MAKE_HEADER(arg1987_3133, 0), BUNSPEC);
										}
									     }
									     {
										object_t aux_5037;
										aux_5037 = (object_t) (new1457_3132);
										OBJECT_WIDENING_SET(aux_5037, BFALSE);
									     }
									     ((((block_t) CREF(new1457_3132))->loc) = ((obj_t) arg2235_1898), BUNSPEC);
									     ((((block_t) CREF(new1457_3132))->body) = ((cop_t) body_3131), BUNSPEC);
									     res2669_3138 = new1457_3132;
									  }
								       }
								       arg2231_1894 = (obj_t) (res2669_3138);
								    }
								 }
							    }
							 }
						      }
						      {
							 cop_t arg2237_1900;
							 obj_t arg2238_1901;
							 arg2237_1900 = node__cop_142_cgen_cgen((((conditional_t) CREF(node_1863))->false), kont_27);
							 arg2238_1901 = (((conditional_t) CREF(node_1863))->loc);
							 {
							    obj_t cop_3141;
							    cop_3141 = (obj_t) (arg2237_1900);
							    {
							       bool_t test1897_3143;
							       test1897_3143 = is_a__118___object(cop_3141, block_cgen_cop);
							       if (test1897_3143)
								 {
								    arg2232_1895 = cop_3141;
								 }
							       else
								 {
								    {
								       block_t res2670_3155;
								       {
									  cop_t body_3148;
									  body_3148 = (cop_t) (cop_3141);
									  {
									     block_t new1457_3149;
									     new1457_3149 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
									     {
										long arg1987_3150;
										arg1987_3150 = class_num_218___object(block_cgen_cop);
										{
										   obj_t obj_3153;
										   obj_3153 = (obj_t) (new1457_3149);
										   (((obj_t) CREF(obj_3153))->header = MAKE_HEADER(arg1987_3150, 0), BUNSPEC);
										}
									     }
									     {
										object_t aux_5054;
										aux_5054 = (object_t) (new1457_3149);
										OBJECT_WIDENING_SET(aux_5054, BFALSE);
									     }
									     ((((block_t) CREF(new1457_3149))->loc) = ((obj_t) arg2238_1901), BUNSPEC);
									     ((((block_t) CREF(new1457_3149))->body) = ((cop_t) body_3148), BUNSPEC);
									     res2670_3155 = new1457_3149;
									  }
								       }
								       arg2232_1895 = (obj_t) (res2670_3155);
								    }
								 }
							    }
							 }
						      }
						      {
							 cif_t res2671_3168;
							 {
							    cop_t test_3157;
							    cop_t true_3158;
							    cop_t false_3159;
							    test_3157 = (cop_t) (arg2230_1893);
							    true_3158 = (cop_t) (arg2231_1894);
							    false_3159 = (cop_t) (arg2232_1895);
							    {
							       cif_t new1526_3160;
							       new1526_3160 = ((cif_t) BREF(GC_MALLOC(sizeof(struct cif))));
							       {
								  long arg1961_3161;
								  arg1961_3161 = class_num_218___object(cif_cgen_cop);
								  {
								     obj_t obj_3166;
								     obj_3166 = (obj_t) (new1526_3160);
								     (((obj_t) CREF(obj_3166))->header = MAKE_HEADER(arg1961_3161, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_5067;
								  aux_5067 = (object_t) (new1526_3160);
								  OBJECT_WIDENING_SET(aux_5067, BFALSE);
							       }
							       ((((cif_t) CREF(new1526_3160))->loc) = ((obj_t) arg2229_1892), BUNSPEC);
							       ((((cif_t) CREF(new1526_3160))->test) = ((cop_t) test_3157), BUNSPEC);
							       ((((cif_t) CREF(new1526_3160))->true) = ((cop_t) true_3158), BUNSPEC);
							       ((((cif_t) CREF(new1526_3160))->false) = ((cop_t) false_3159), BUNSPEC);
							       res2671_3168 = new1526_3160;
							    }
							 }
							 arg2220_1883 = res2671_3168;
						      }
						   }
						   {
						      obj_t list2221_1884;
						      {
							 obj_t arg2222_1885;
							 {
							    obj_t arg2223_1886;
							    {
							       obj_t aux_5074;
							       aux_5074 = (obj_t) (arg2220_1883);
							       arg2223_1886 = MAKE_PAIR(aux_5074, BNIL);
							    }
							    {
							       obj_t aux_5077;
							       aux_5077 = (obj_t) (ctest_1867);
							       arg2222_1885 = MAKE_PAIR(aux_5077, arg2223_1886);
							    }
							 }
							 {
							    obj_t aux_5080;
							    aux_5080 = (obj_t) (arg2219_1882);
							    list2221_1884 = MAKE_PAIR(aux_5080, arg2222_1885);
							 }
						      }
						      arg2217_1881 = list2221_1884;
						   }
						}
						{
						   csequence_t res2672_3180;
						   {
						      obj_t loc_3170;
						      loc_3170 = BFALSE;
						      {
							 csequence_t new1501_3173;
							 new1501_3173 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							 {
							    long arg1972_3174;
							    arg1972_3174 = class_num_218___object(csequence_cgen_cop);
							    {
							       obj_t obj_3178;
							       obj_3178 = (obj_t) (new1501_3173);
							       (((obj_t) CREF(obj_3178))->header = MAKE_HEADER(arg1972_3174, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_5087;
							    aux_5087 = (object_t) (new1501_3173);
							    OBJECT_WIDENING_SET(aux_5087, loc_3170);
							 }
							 ((((csequence_t) CREF(new1501_3173))->loc) = ((obj_t) loc_3170), BUNSPEC);
							 ((((csequence_t) CREF(new1501_3173))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							 ((((csequence_t) CREF(new1501_3173))->cops) = ((obj_t) arg2217_1881), BUNSPEC);
							 res2672_3180 = new1501_3173;
						      }
						   }
						   arg2216_1880 = res2672_3180;
						}
					     }
					     {
						block_t res2673_3189;
						{
						   cop_t body_3182;
						   body_3182 = (cop_t) (arg2216_1880);
						   {
						      block_t new1457_3183;
						      new1457_3183 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						      {
							 long arg1987_3184;
							 arg1987_3184 = class_num_218___object(block_cgen_cop);
							 {
							    obj_t obj_3187;
							    obj_3187 = (obj_t) (new1457_3183);
							    (((obj_t) CREF(obj_3187))->header = MAKE_HEADER(arg1987_3184, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_5098;
							 aux_5098 = (object_t) (new1457_3183);
							 OBJECT_WIDENING_SET(aux_5098, BFALSE);
						      }
						      ((((block_t) CREF(new1457_3183))->loc) = ((obj_t) arg2215_1879), BUNSPEC);
						      ((((block_t) CREF(new1457_3183))->body) = ((cop_t) body_3182), BUNSPEC);
						      res2673_3189 = new1457_3183;
						   }
						}
						aux_4563 = (obj_t) (res2673_3189);
					     }
					  }
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 9):
			 {
			    fail_t node_1909;
			    node_1909 = (fail_t) (node_26);
			    {
			       obj_t old_actuals_174_1912;
			       obj_t new_actuals_73_1913;
			       local_t aux_1914;
			       obj_t auxs_1915;
			       obj_t exps_1916;
			       {
				  obj_t arg2248_1918;
				  local_t arg2252_1920;
				  {
				     node_t arg2257_1923;
				     node_t arg2258_1924;
				     arg2257_1923 = (((fail_t) CREF(node_1909))->proc);
				     arg2258_1924 = (((fail_t) CREF(node_1909))->msg);
				     {
					obj_t list2260_1926;
					{
					   obj_t arg2261_1927;
					   {
					      obj_t arg2263_1928;
					      {
						 obj_t aux_5107;
						 {
						    node_t aux_5108;
						    aux_5108 = (((fail_t) CREF(node_1909))->obj);
						    aux_5107 = (obj_t) (aux_5108);
						 }
						 arg2263_1928 = MAKE_PAIR(aux_5107, BNIL);
					      }
					      {
						 obj_t aux_5112;
						 aux_5112 = (obj_t) (arg2258_1924);
						 arg2261_1927 = MAKE_PAIR(aux_5112, arg2263_1928);
					      }
					   }
					   {
					      obj_t aux_5115;
					      aux_5115 = (obj_t) (arg2257_1923);
					      list2260_1926 = MAKE_PAIR(aux_5115, arg2261_1927);
					   }
					}
					arg2248_1918 = list2260_1926;
				     }
				  }
				  arg2252_1920 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (type_t) (_obj__252_type_cache));
				  old_actuals_174_1912 = arg2248_1918;
				  new_actuals_73_1913 = BNIL;
				  aux_1914 = arg2252_1920;
				  auxs_1915 = BNIL;
				  exps_1916 = BNIL;
				loop_1917:
				  if (NULLP(old_actuals_174_1912))
				    {
				       if (NULLP(auxs_1915))
					 {
					    cfail_t arg2268_1933;
					    {
					       obj_t arg2269_1934;
					       arg2269_1934 = (((fail_t) CREF(node_1909))->loc);
					       {
						  cfail_t res2674_3220;
						  {
						     cop_t proc_3209;
						     cop_t msg_3210;
						     cop_t obj_3211;
						     {
							obj_t aux_5126;
							{
							   obj_t aux_5127;
							   {
							      obj_t aux_5128;
							      aux_5128 = CDR(new_actuals_73_1913);
							      aux_5127 = CDR(aux_5128);
							   }
							   aux_5126 = CAR(aux_5127);
							}
							proc_3209 = (cop_t) (aux_5126);
						     }
						     {
							obj_t aux_5133;
							{
							   obj_t aux_5134;
							   aux_5134 = CDR(new_actuals_73_1913);
							   aux_5133 = CAR(aux_5134);
							}
							msg_3210 = (cop_t) (aux_5133);
						     }
						     {
							obj_t aux_5138;
							aux_5138 = CAR(new_actuals_73_1913);
							obj_3211 = (cop_t) (aux_5138);
						     }
						     {
							cfail_t new1562_3212;
							new1562_3212 = ((cfail_t) BREF(GC_MALLOC(sizeof(struct cfail))));
							{
							   long arg1950_3213;
							   arg1950_3213 = class_num_218___object(cfail_cgen_cop);
							   {
							      obj_t obj_3218;
							      obj_3218 = (obj_t) (new1562_3212);
							      (((obj_t) CREF(obj_3218))->header = MAKE_HEADER(arg1950_3213, 0), BUNSPEC);
							   }
							}
							{
							   object_t aux_5145;
							   aux_5145 = (object_t) (new1562_3212);
							   OBJECT_WIDENING_SET(aux_5145, BFALSE);
							}
							((((cfail_t) CREF(new1562_3212))->loc) = ((obj_t) arg2269_1934), BUNSPEC);
							((((cfail_t) CREF(new1562_3212))->proc) = ((cop_t) proc_3209), BUNSPEC);
							((((cfail_t) CREF(new1562_3212))->msg) = ((cop_t) msg_3210), BUNSPEC);
							((((cfail_t) CREF(new1562_3212))->obj) = ((cop_t) obj_3211), BUNSPEC);
							res2674_3220 = new1562_3212;
						     }
						  }
						  arg2268_1933 = res2674_3220;
					       }
					    }
					    aux_4563 = (obj_t) (arg2268_1933);
					 }
				       else
					 {
					    obj_t arg2273_1938;
					    csequence_t arg2274_1939;
					    arg2273_1938 = (((fail_t) CREF(node_1909))->loc);
					    {
					       obj_t arg2275_1940;
					       {
						  local_var_164_t arg2276_1941;
						  csequence_t arg2277_1942;
						  cfail_t arg2278_1943;
						  {
						     obj_t arg2283_1948;
						     arg2283_1948 = (((fail_t) CREF(node_1909))->loc);
						     {
							local_var_164_t res2675_3232;
							{
							   local_var_164_t new1534_3226;
							   new1534_3226 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							   {
							      long arg1959_3227;
							      arg1959_3227 = class_num_218___object(local_var_164_cgen_cop);
							      {
								 obj_t obj_3230;
								 obj_3230 = (obj_t) (new1534_3226);
								 (((obj_t) CREF(obj_3230))->header = MAKE_HEADER(arg1959_3227, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_5159;
							      aux_5159 = (object_t) (new1534_3226);
							      OBJECT_WIDENING_SET(aux_5159, BFALSE);
							   }
							   ((((local_var_164_t) CREF(new1534_3226))->loc) = ((obj_t) arg2283_1948), BUNSPEC);
							   ((((local_var_164_t) CREF(new1534_3226))->vars) = ((obj_t) auxs_1915), BUNSPEC);
							   res2675_3232 = new1534_3226;
							}
							arg2276_1941 = res2675_3232;
						     }
						  }
						  {
						     csequence_t res2676_3243;
						     {
							obj_t loc_3233;
							loc_3233 = BFALSE;
							{
							   csequence_t new1501_3236;
							   new1501_3236 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							   {
							      long arg1972_3237;
							      arg1972_3237 = class_num_218___object(csequence_cgen_cop);
							      {
								 obj_t obj_3241;
								 obj_3241 = (obj_t) (new1501_3236);
								 (((obj_t) CREF(obj_3241))->header = MAKE_HEADER(arg1972_3237, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_5168;
							      aux_5168 = (object_t) (new1501_3236);
							      OBJECT_WIDENING_SET(aux_5168, loc_3233);
							   }
							   ((((csequence_t) CREF(new1501_3236))->loc) = ((obj_t) loc_3233), BUNSPEC);
							   ((((csequence_t) CREF(new1501_3236))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							   ((((csequence_t) CREF(new1501_3236))->cops) = ((obj_t) exps_1916), BUNSPEC);
							   res2676_3243 = new1501_3236;
							}
						     }
						     arg2277_1942 = res2676_3243;
						  }
						  {
						     cfail_t arg2287_1951;
						     {
							obj_t arg2288_1952;
							arg2288_1952 = (((fail_t) CREF(node_1909))->loc);
							{
							   cfail_t res2677_3268;
							   {
							      cop_t proc_3257;
							      cop_t msg_3258;
							      cop_t obj_3259;
							      {
								 obj_t aux_5175;
								 {
								    obj_t aux_5176;
								    {
								       obj_t aux_5177;
								       aux_5177 = CDR(new_actuals_73_1913);
								       aux_5176 = CDR(aux_5177);
								    }
								    aux_5175 = CAR(aux_5176);
								 }
								 proc_3257 = (cop_t) (aux_5175);
							      }
							      {
								 obj_t aux_5182;
								 {
								    obj_t aux_5183;
								    aux_5183 = CDR(new_actuals_73_1913);
								    aux_5182 = CAR(aux_5183);
								 }
								 msg_3258 = (cop_t) (aux_5182);
							      }
							      {
								 obj_t aux_5187;
								 aux_5187 = CAR(new_actuals_73_1913);
								 obj_3259 = (cop_t) (aux_5187);
							      }
							      {
								 cfail_t new1562_3260;
								 new1562_3260 = ((cfail_t) BREF(GC_MALLOC(sizeof(struct cfail))));
								 {
								    long arg1950_3261;
								    arg1950_3261 = class_num_218___object(cfail_cgen_cop);
								    {
								       obj_t obj_3266;
								       obj_3266 = (obj_t) (new1562_3260);
								       (((obj_t) CREF(obj_3266))->header = MAKE_HEADER(arg1950_3261, 0), BUNSPEC);
								    }
								 }
								 {
								    object_t aux_5194;
								    aux_5194 = (object_t) (new1562_3260);
								    OBJECT_WIDENING_SET(aux_5194, BFALSE);
								 }
								 ((((cfail_t) CREF(new1562_3260))->loc) = ((obj_t) arg2288_1952), BUNSPEC);
								 ((((cfail_t) CREF(new1562_3260))->proc) = ((cop_t) proc_3257), BUNSPEC);
								 ((((cfail_t) CREF(new1562_3260))->msg) = ((cop_t) msg_3258), BUNSPEC);
								 ((((cfail_t) CREF(new1562_3260))->obj) = ((cop_t) obj_3259), BUNSPEC);
								 res2677_3268 = new1562_3260;
							      }
							   }
							   arg2287_1951 = res2677_3268;
							}
						     }
						     arg2278_1943 = arg2287_1951;
						  }
						  {
						     obj_t list2279_1944;
						     {
							obj_t arg2280_1945;
							{
							   obj_t arg2281_1946;
							   {
							      obj_t aux_5201;
							      aux_5201 = (obj_t) (arg2278_1943);
							      arg2281_1946 = MAKE_PAIR(aux_5201, BNIL);
							   }
							   {
							      obj_t aux_5204;
							      aux_5204 = (obj_t) (arg2277_1942);
							      arg2280_1945 = MAKE_PAIR(aux_5204, arg2281_1946);
							   }
							}
							{
							   obj_t aux_5207;
							   aux_5207 = (obj_t) (arg2276_1941);
							   list2279_1944 = MAKE_PAIR(aux_5207, arg2280_1945);
							}
						     }
						     arg2275_1940 = list2279_1944;
						  }
					       }
					       {
						  csequence_t res2678_3281;
						  {
						     obj_t loc_3271;
						     loc_3271 = BFALSE;
						     {
							csequence_t new1501_3274;
							new1501_3274 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							{
							   long arg1972_3275;
							   arg1972_3275 = class_num_218___object(csequence_cgen_cop);
							   {
							      obj_t obj_3279;
							      obj_3279 = (obj_t) (new1501_3274);
							      (((obj_t) CREF(obj_3279))->header = MAKE_HEADER(arg1972_3275, 0), BUNSPEC);
							   }
							}
							{
							   object_t aux_5214;
							   aux_5214 = (object_t) (new1501_3274);
							   OBJECT_WIDENING_SET(aux_5214, loc_3271);
							}
							((((csequence_t) CREF(new1501_3274))->loc) = ((obj_t) loc_3271), BUNSPEC);
							((((csequence_t) CREF(new1501_3274))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							((((csequence_t) CREF(new1501_3274))->cops) = ((obj_t) arg2275_1940), BUNSPEC);
							res2678_3281 = new1501_3274;
						     }
						  }
						  arg2274_1939 = res2678_3281;
					       }
					    }
					    {
					       block_t res2679_3290;
					       {
						  cop_t body_3283;
						  body_3283 = (cop_t) (arg2274_1939);
						  {
						     block_t new1457_3284;
						     new1457_3284 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						     {
							long arg1987_3285;
							arg1987_3285 = class_num_218___object(block_cgen_cop);
							{
							   obj_t obj_3288;
							   obj_3288 = (obj_t) (new1457_3284);
							   (((obj_t) CREF(obj_3288))->header = MAKE_HEADER(arg1987_3285, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_5225;
							aux_5225 = (object_t) (new1457_3284);
							OBJECT_WIDENING_SET(aux_5225, BFALSE);
						     }
						     ((((block_t) CREF(new1457_3284))->loc) = ((obj_t) arg2273_1938), BUNSPEC);
						     ((((block_t) CREF(new1457_3284))->body) = ((cop_t) body_3283), BUNSPEC);
						     res2679_3290 = new1457_3284;
						  }
					       }
					       aux_4563 = (obj_t) (res2679_3290);
					    }
					 }
				    }
				  else
				    {
				       cop_t cop_1956;
				       {
					  setq_t arg2310_1973;
					  {
					     node_t aux_5231;
					     {
						obj_t aux_5233;
						aux_5233 = CAR(old_actuals_174_1912);
						aux_5231 = (node_t) (aux_5233);
					     }
					     arg2310_1973 = node_setq_243_cgen_cgen((variable_t) (aux_1914), aux_5231);
					  }
					  cop_1956 = node__cop_142_cgen_cgen((node_t) (arg2310_1973), _id_kont__126_cgen_cgen);
				       }
				       {
					  bool_t test2293_1957;
					  {
					     bool_t test2307_1970;
					     test2307_1970 = is_a__118___object((obj_t) (cop_1956), csetq_cgen_cop);
					     if (test2307_1970)
					       {
						  obj_t aux_5248;
						  obj_t aux_5242;
						  aux_5248 = (obj_t) (aux_1914);
						  {
						     variable_t aux_5243;
						     {
							varc_t arg2309_1972;
							{
							   csetq_t obj_3293;
							   obj_3293 = (csetq_t) (cop_1956);
							   arg2309_1972 = (((csetq_t) CREF(obj_3293))->var);
							}
							aux_5243 = (((varc_t) CREF(arg2309_1972))->variable);
						     }
						     aux_5242 = (obj_t) (aux_5243);
						  }
						  test2293_1957 = (aux_5242 == aux_5248);
					       }
					     else
					       {
						  test2293_1957 = ((bool_t) 0);
					       }
					  }
					  if (test2293_1957)
					    {
					       obj_t arg2294_1958;
					       obj_t arg2295_1959;
					       arg2294_1958 = CDR(old_actuals_174_1912);
					       {
						  obj_t aux_5253;
						  {
						     cop_t aux_5254;
						     {
							csetq_t obj_3298;
							obj_3298 = (csetq_t) (cop_1956);
							aux_5254 = (((csetq_t) CREF(obj_3298))->value);
						     }
						     aux_5253 = (obj_t) (aux_5254);
						  }
						  arg2295_1959 = MAKE_PAIR(aux_5253, new_actuals_73_1913);
					       }
					       {
						  obj_t new_actuals_73_5260;
						  obj_t old_actuals_174_5259;
						  old_actuals_174_5259 = arg2294_1958;
						  new_actuals_73_5260 = arg2295_1959;
						  new_actuals_73_1913 = new_actuals_73_5260;
						  old_actuals_174_1912 = old_actuals_174_5259;
						  goto loop_1917;
					       }
					    }
					  else
					    {
					       {
						  type_t val1093_3302;
						  val1093_3302 = (type_t) (_obj__252_type_cache);
						  ((((local_t) CREF(aux_1914))->type) = ((type_t) val1093_3302), BUNSPEC);
					       }
					       {
						  obj_t arg2298_1961;
						  obj_t arg2299_1962;
						  local_t arg2300_1963;
						  obj_t arg2301_1964;
						  obj_t arg2302_1965;
						  arg2298_1961 = CDR(old_actuals_174_1912);
						  {
						     varc_t arg2303_1966;
						     {
							obj_t arg2304_1967;
							arg2304_1967 = (((fail_t) CREF(node_1909))->loc);
							{
							   varc_t res2680_3313;
							   {
							      variable_t variable_3306;
							      variable_3306 = (variable_t) (aux_1914);
							      {
								 varc_t new1481_3307;
								 new1481_3307 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								 {
								    long arg1979_3308;
								    arg1979_3308 = class_num_218___object(varc_cgen_cop);
								    {
								       obj_t obj_3311;
								       obj_3311 = (obj_t) (new1481_3307);
								       (((obj_t) CREF(obj_3311))->header = MAKE_HEADER(arg1979_3308, 0), BUNSPEC);
								    }
								 }
								 {
								    object_t aux_5270;
								    aux_5270 = (object_t) (new1481_3307);
								    OBJECT_WIDENING_SET(aux_5270, BFALSE);
								 }
								 ((((varc_t) CREF(new1481_3307))->loc) = ((obj_t) arg2304_1967), BUNSPEC);
								 ((((varc_t) CREF(new1481_3307))->variable) = ((variable_t) variable_3306), BUNSPEC);
								 res2680_3313 = new1481_3307;
							      }
							   }
							   arg2303_1966 = res2680_3313;
							}
						     }
						     {
							obj_t aux_5275;
							aux_5275 = (obj_t) (arg2303_1966);
							arg2299_1962 = MAKE_PAIR(aux_5275, new_actuals_73_1913);
						     }
						  }
						  arg2300_1963 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (type_t) (_obj__252_type_cache));
						  {
						     obj_t aux_5281;
						     aux_5281 = (obj_t) (aux_1914);
						     arg2301_1964 = MAKE_PAIR(aux_5281, auxs_1915);
						  }
						  {
						     obj_t aux_5284;
						     aux_5284 = (obj_t) (cop_1956);
						     arg2302_1965 = MAKE_PAIR(aux_5284, exps_1916);
						  }
						  {
						     obj_t exps_5291;
						     obj_t auxs_5290;
						     local_t aux_5289;
						     obj_t new_actuals_73_5288;
						     obj_t old_actuals_174_5287;
						     old_actuals_174_5287 = arg2298_1961;
						     new_actuals_73_5288 = arg2299_1962;
						     aux_5289 = arg2300_1963;
						     auxs_5290 = arg2301_1964;
						     exps_5291 = arg2302_1965;
						     exps_1916 = exps_5291;
						     auxs_1915 = auxs_5290;
						     aux_1914 = aux_5289;
						     new_actuals_73_1913 = new_actuals_73_5288;
						     old_actuals_174_1912 = old_actuals_174_5287;
						     goto loop_1917;
						  }
					       }
					    }
				       }
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    select_t node_1975;
			    node_1975 = (select_t) (node_26);
			    {
			       obj_t l1691_1978;
			       l1691_1978 = (((select_t) CREF(node_1975))->clauses);
			     lname1692_1979:
			       if (PAIRP(l1691_1978))
				 {
				    {
				       obj_t clause_1982;
				       clause_1982 = CAR(l1691_1978);
				       {
					  cop_t arg2316_1983;
					  {
					     node_t aux_5296;
					     {
						obj_t aux_5297;
						aux_5297 = CDR(clause_1982);
						aux_5296 = (node_t) (aux_5297);
					     }
					     arg2316_1983 = node__cop_142_cgen_cgen(aux_5296, kont_27);
					  }
					  {
					     obj_t aux_5301;
					     aux_5301 = (obj_t) (arg2316_1983);
					     SET_CDR(clause_1982, aux_5301);
					  }
				       }
				    }
				    {
				       obj_t l1691_5304;
				       l1691_5304 = CDR(l1691_1978);
				       l1691_1978 = l1691_5304;
				       goto lname1692_1979;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       local_t aux_1986;
			       aux_1986 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (((select_t) CREF(node_1975))->item_type_130));
			       {
				  cop_t cop_1987;
				  {
				     setq_t arg2345_2012;
				     arg2345_2012 = node_setq_243_cgen_cgen((variable_t) (aux_1986), (((select_t) CREF(node_1975))->test));
				     cop_1987 = node__cop_142_cgen_cgen((node_t) (arg2345_2012), _id_kont__126_cgen_cgen);
				  }
				  {
				     bool_t test2321_1988;
				     {
					bool_t test2342_2009;
					test2342_2009 = is_a__118___object((obj_t) (cop_1987), csetq_cgen_cop);
					if (test2342_2009)
					  {
					     obj_t aux_5324;
					     obj_t aux_5318;
					     aux_5324 = (obj_t) (aux_1986);
					     {
						variable_t aux_5319;
						{
						   varc_t arg2344_2011;
						   {
						      csetq_t obj_3330;
						      obj_3330 = (csetq_t) (cop_1987);
						      arg2344_2011 = (((csetq_t) CREF(obj_3330))->var);
						   }
						   aux_5319 = (((varc_t) CREF(arg2344_2011))->variable);
						}
						aux_5318 = (obj_t) (aux_5319);
					     }
					     test2321_1988 = (aux_5318 == aux_5324);
					  }
					else
					  {
					     test2321_1988 = ((bool_t) 0);
					  }
				     }
				     if (test2321_1988)
				       {
					  obj_t arg2322_1989;
					  cop_t arg2323_1990;
					  obj_t arg2324_1991;
					  arg2322_1989 = (((select_t) CREF(node_1975))->loc);
					  {
					     csetq_t obj_3335;
					     obj_3335 = (csetq_t) (cop_1987);
					     arg2323_1990 = (((csetq_t) CREF(obj_3335))->value);
					  }
					  arg2324_1991 = (((select_t) CREF(node_1975))->clauses);
					  {
					     cswitch_t res2681_3347;
					     {
						cswitch_t new1570_3340;
						new1570_3340 = ((cswitch_t) BREF(GC_MALLOC(sizeof(struct cswitch))));
						{
						   long arg1948_3341;
						   arg1948_3341 = class_num_218___object(cswitch_cgen_cop);
						   {
						      obj_t obj_3345;
						      obj_3345 = (obj_t) (new1570_3340);
						      (((obj_t) CREF(obj_3345))->header = MAKE_HEADER(arg1948_3341, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_5336;
						   aux_5336 = (object_t) (new1570_3340);
						   OBJECT_WIDENING_SET(aux_5336, BFALSE);
						}
						((((cswitch_t) CREF(new1570_3340))->loc) = ((obj_t) arg2322_1989), BUNSPEC);
						((((cswitch_t) CREF(new1570_3340))->test) = ((cop_t) arg2323_1990), BUNSPEC);
						((((cswitch_t) CREF(new1570_3340))->clauses) = ((obj_t) arg2324_1991), BUNSPEC);
						res2681_3347 = new1570_3340;
					     }
					     aux_4563 = (obj_t) (res2681_3347);
					  }
				       }
				     else
				       {
					  csequence_t arg2325_1992;
					  {
					     obj_t arg2326_1993;
					     {
						local_var_164_t arg2327_1994;
						cswitch_t arg2328_1995;
						{
						   obj_t arg2333_2000;
						   obj_t arg2334_2001;
						   arg2333_2000 = (((select_t) CREF(node_1975))->loc);
						   {
						      obj_t list2335_2002;
						      {
							 obj_t aux_5344;
							 aux_5344 = (obj_t) (aux_1986);
							 list2335_2002 = MAKE_PAIR(aux_5344, BNIL);
						      }
						      arg2334_2001 = list2335_2002;
						   }
						   {
						      local_var_164_t res2682_3358;
						      {
							 local_var_164_t new1534_3352;
							 new1534_3352 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							 {
							    long arg1959_3353;
							    arg1959_3353 = class_num_218___object(local_var_164_cgen_cop);
							    {
							       obj_t obj_3356;
							       obj_3356 = (obj_t) (new1534_3352);
							       (((obj_t) CREF(obj_3356))->header = MAKE_HEADER(arg1959_3353, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_5351;
							    aux_5351 = (object_t) (new1534_3352);
							    OBJECT_WIDENING_SET(aux_5351, BFALSE);
							 }
							 ((((local_var_164_t) CREF(new1534_3352))->loc) = ((obj_t) arg2333_2000), BUNSPEC);
							 ((((local_var_164_t) CREF(new1534_3352))->vars) = ((obj_t) arg2334_2001), BUNSPEC);
							 res2682_3358 = new1534_3352;
						      }
						      arg2327_1994 = res2682_3358;
						   }
						}
						{
						   obj_t arg2337_2004;
						   varc_t arg2338_2005;
						   obj_t arg2339_2006;
						   arg2337_2004 = (((select_t) CREF(node_1975))->loc);
						   {
						      obj_t arg2340_2007;
						      arg2340_2007 = (((select_t) CREF(node_1975))->loc);
						      {
							 varc_t res2683_3369;
							 {
							    variable_t variable_3362;
							    variable_3362 = (variable_t) (aux_1986);
							    {
							       varc_t new1481_3363;
							       new1481_3363 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
							       {
								  long arg1979_3364;
								  arg1979_3364 = class_num_218___object(varc_cgen_cop);
								  {
								     obj_t obj_3367;
								     obj_3367 = (obj_t) (new1481_3363);
								     (((obj_t) CREF(obj_3367))->header = MAKE_HEADER(arg1979_3364, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_5363;
								  aux_5363 = (object_t) (new1481_3363);
								  OBJECT_WIDENING_SET(aux_5363, BFALSE);
							       }
							       ((((varc_t) CREF(new1481_3363))->loc) = ((obj_t) arg2340_2007), BUNSPEC);
							       ((((varc_t) CREF(new1481_3363))->variable) = ((variable_t) variable_3362), BUNSPEC);
							       res2683_3369 = new1481_3363;
							    }
							 }
							 arg2338_2005 = res2683_3369;
						      }
						   }
						   arg2339_2006 = (((select_t) CREF(node_1975))->clauses);
						   {
						      cswitch_t res2684_3381;
						      {
							 cop_t test_3372;
							 test_3372 = (cop_t) (arg2338_2005);
							 {
							    cswitch_t new1570_3374;
							    new1570_3374 = ((cswitch_t) BREF(GC_MALLOC(sizeof(struct cswitch))));
							    {
							       long arg1948_3375;
							       arg1948_3375 = class_num_218___object(cswitch_cgen_cop);
							       {
								  obj_t obj_3379;
								  obj_3379 = (obj_t) (new1570_3374);
								  (((obj_t) CREF(obj_3379))->header = MAKE_HEADER(arg1948_3375, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_5374;
							       aux_5374 = (object_t) (new1570_3374);
							       OBJECT_WIDENING_SET(aux_5374, BFALSE);
							    }
							    ((((cswitch_t) CREF(new1570_3374))->loc) = ((obj_t) arg2337_2004), BUNSPEC);
							    ((((cswitch_t) CREF(new1570_3374))->test) = ((cop_t) test_3372), BUNSPEC);
							    ((((cswitch_t) CREF(new1570_3374))->clauses) = ((obj_t) arg2339_2006), BUNSPEC);
							    res2684_3381 = new1570_3374;
							 }
						      }
						      arg2328_1995 = res2684_3381;
						   }
						}
						{
						   obj_t list2329_1996;
						   {
						      obj_t arg2330_1997;
						      {
							 obj_t arg2331_1998;
							 {
							    obj_t aux_5380;
							    aux_5380 = (obj_t) (arg2328_1995);
							    arg2331_1998 = MAKE_PAIR(aux_5380, BNIL);
							 }
							 {
							    obj_t aux_5383;
							    aux_5383 = (obj_t) (cop_1987);
							    arg2330_1997 = MAKE_PAIR(aux_5383, arg2331_1998);
							 }
						      }
						      {
							 obj_t aux_5386;
							 aux_5386 = (obj_t) (arg2327_1994);
							 list2329_1996 = MAKE_PAIR(aux_5386, arg2330_1997);
						      }
						   }
						   arg2326_1993 = list2329_1996;
						}
					     }
					     {
						csequence_t res2685_3393;
						{
						   obj_t loc_3383;
						   loc_3383 = BFALSE;
						   {
						      csequence_t new1501_3386;
						      new1501_3386 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						      {
							 long arg1972_3387;
							 arg1972_3387 = class_num_218___object(csequence_cgen_cop);
							 {
							    obj_t obj_3391;
							    obj_3391 = (obj_t) (new1501_3386);
							    (((obj_t) CREF(obj_3391))->header = MAKE_HEADER(arg1972_3387, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_5393;
							 aux_5393 = (object_t) (new1501_3386);
							 OBJECT_WIDENING_SET(aux_5393, loc_3383);
						      }
						      ((((csequence_t) CREF(new1501_3386))->loc) = ((obj_t) loc_3383), BUNSPEC);
						      ((((csequence_t) CREF(new1501_3386))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						      ((((csequence_t) CREF(new1501_3386))->cops) = ((obj_t) arg2326_1993), BUNSPEC);
						      res2685_3393 = new1501_3386;
						   }
						}
						arg2325_1992 = res2685_3393;
					     }
					  }
					  {
					     block_t res2686_3402;
					     {
						obj_t loc_3394;
						cop_t body_3395;
						loc_3394 = BFALSE;
						body_3395 = (cop_t) (arg2325_1992);
						{
						   block_t new1457_3396;
						   new1457_3396 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						   {
						      long arg1987_3397;
						      arg1987_3397 = class_num_218___object(block_cgen_cop);
						      {
							 obj_t obj_3400;
							 obj_3400 = (obj_t) (new1457_3396);
							 (((obj_t) CREF(obj_3400))->header = MAKE_HEADER(arg1987_3397, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_5404;
						      aux_5404 = (object_t) (new1457_3396);
						      OBJECT_WIDENING_SET(aux_5404, loc_3394);
						   }
						   ((((block_t) CREF(new1457_3396))->loc) = ((obj_t) loc_3394), BUNSPEC);
						   ((((block_t) CREF(new1457_3396))->body) = ((cop_t) body_3395), BUNSPEC);
						   res2686_3402 = new1457_3396;
						}
					     }
					     aux_4563 = (obj_t) (res2686_3402);
					  }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 11):
			 {
			    let_fun_218_t node_2016;
			    node_2016 = (let_fun_218_t) (node_26);
			    {
			       obj_t locals_2019;
			       obj_t all_formals_186_2020;
			       locals_2019 = (((let_fun_218_t) CREF(node_2016))->locals);
			       all_formals_186_2020 = BNIL;
			     loop_2021:
			       if (NULLP(locals_2019))
				 {
				    cop_t arg2352_2025;
				    {
				       csequence_t arg2353_2026;
				       obj_t arg2354_2027;
				       {
					  obj_t arg2355_2028;
					  {
					     local_var_164_t arg2356_2029;
					     cop_t arg2357_2030;
					     {
						obj_t arg2361_2034;
						arg2361_2034 = (((let_fun_218_t) CREF(node_2016))->loc);
						{
						   local_var_164_t res2687_3414;
						   {
						      local_var_164_t new1534_3408;
						      new1534_3408 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
						      {
							 long arg1959_3409;
							 arg1959_3409 = class_num_218___object(local_var_164_cgen_cop);
							 {
							    obj_t obj_3412;
							    obj_3412 = (obj_t) (new1534_3408);
							    (((obj_t) CREF(obj_3412))->header = MAKE_HEADER(arg1959_3409, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_5418;
							 aux_5418 = (object_t) (new1534_3408);
							 OBJECT_WIDENING_SET(aux_5418, BFALSE);
						      }
						      ((((local_var_164_t) CREF(new1534_3408))->loc) = ((obj_t) arg2361_2034), BUNSPEC);
						      ((((local_var_164_t) CREF(new1534_3408))->vars) = ((obj_t) all_formals_186_2020), BUNSPEC);
						      res2687_3414 = new1534_3408;
						   }
						   arg2356_2029 = res2687_3414;
						}
					     }
					     arg2357_2030 = node__cop_142_cgen_cgen((((let_fun_218_t) CREF(node_2016))->body), kont_27);
					     {
						obj_t list2358_2031;
						{
						   obj_t arg2359_2032;
						   {
						      obj_t aux_5425;
						      aux_5425 = (obj_t) (arg2357_2030);
						      arg2359_2032 = MAKE_PAIR(aux_5425, BNIL);
						   }
						   {
						      obj_t aux_5428;
						      aux_5428 = (obj_t) (arg2356_2029);
						      list2358_2031 = MAKE_PAIR(aux_5428, arg2359_2032);
						   }
						}
						arg2355_2028 = list2358_2031;
					     }
					  }
					  {
					     csequence_t res2688_3427;
					     {
						obj_t loc_3417;
						loc_3417 = BFALSE;
						{
						   csequence_t new1501_3420;
						   new1501_3420 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						   {
						      long arg1972_3421;
						      arg1972_3421 = class_num_218___object(csequence_cgen_cop);
						      {
							 obj_t obj_3425;
							 obj_3425 = (obj_t) (new1501_3420);
							 (((obj_t) CREF(obj_3425))->header = MAKE_HEADER(arg1972_3421, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_5435;
						      aux_5435 = (object_t) (new1501_3420);
						      OBJECT_WIDENING_SET(aux_5435, loc_3417);
						   }
						   ((((csequence_t) CREF(new1501_3420))->loc) = ((obj_t) loc_3417), BUNSPEC);
						   ((((csequence_t) CREF(new1501_3420))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						   ((((csequence_t) CREF(new1501_3420))->cops) = ((obj_t) arg2355_2028), BUNSPEC);
						   res2688_3427 = new1501_3420;
						}
					     }
					     arg2353_2026 = res2688_3427;
					  }
				       }
				       arg2354_2027 = (((let_fun_218_t) CREF(node_2016))->loc);
				       arg2352_2025 = bdb_let_var_254_cgen_cgen((cop_t) (arg2353_2026), arg2354_2027);
				    }
				    {
				       obj_t cop_3429;
				       obj_t loc_3430;
				       cop_3429 = (obj_t) (arg2352_2025);
				       loc_3430 = BFALSE;
				       {
					  bool_t test1897_3431;
					  test1897_3431 = is_a__118___object(cop_3429, block_cgen_cop);
					  if (test1897_3431)
					    {
					       aux_4563 = cop_3429;
					    }
					  else
					    {
					       {
						  block_t res2689_3443;
						  {
						     cop_t body_3436;
						     body_3436 = (cop_t) (cop_3429);
						     {
							block_t new1457_3437;
							new1457_3437 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
							{
							   long arg1987_3438;
							   arg1987_3438 = class_num_218___object(block_cgen_cop);
							   {
							      obj_t obj_3441;
							      obj_3441 = (obj_t) (new1457_3437);
							      (((obj_t) CREF(obj_3441))->header = MAKE_HEADER(arg1987_3438, 0), BUNSPEC);
							   }
							}
							{
							   object_t aux_5452;
							   aux_5452 = (object_t) (new1457_3437);
							   OBJECT_WIDENING_SET(aux_5452, loc_3430);
							}
							((((block_t) CREF(new1457_3437))->loc) = ((obj_t) loc_3430), BUNSPEC);
							((((block_t) CREF(new1457_3437))->body) = ((cop_t) body_3436), BUNSPEC);
							res2689_3443 = new1457_3437;
						     }
						  }
						  aux_4563 = (obj_t) (res2689_3443);
					       }
					    }
				       }
				    }
				 }
			       else
				 {
				    obj_t local_2037;
				    local_2037 = CAR(locals_2019);
				    set_variable_name__102_cgen_prototype(local_2037);
				    {
				       sfun_c_188_t fun_2038;
				       {
					  sfun_c_188_t obj1702_2047;
					  {
					     value_t aux_5460;
					     {
						local_t obj_3445;
						obj_3445 = (local_t) (local_2037);
						aux_5460 = (((local_t) CREF(obj_3445))->value);
					     }
					     obj1702_2047 = ((sfun_c_188_t) (aux_5460));
					  }
					  {
					     sfun_c_188_t arg2370_2048;
					     {
						clabel_t arg2371_2049;
						{
						   obj_t arg2373_2051;
						   obj_t arg2374_2052;
						   {
						      sfun_t obj_3447;
						      {
							 value_t aux_5464;
							 {
							    local_t obj_3446;
							    obj_3446 = (local_t) (local_2037);
							    aux_5464 = (((local_t) CREF(obj_3446))->value);
							 }
							 obj_3447 = (sfun_t) (aux_5464);
						      }
						      arg2373_2051 = (((sfun_t) CREF(obj_3447))->loc);
						   }
						   {
						      local_t obj_3448;
						      obj_3448 = (local_t) (local_2037);
						      arg2374_2052 = (((local_t) CREF(obj_3448))->name);
						   }
						   {
						      clabel_t res2690_3461;
						      {
							 clabel_t new1441_3453;
							 new1441_3453 = ((clabel_t) BREF(GC_MALLOC(sizeof(struct clabel))));
							 {
							    long arg1991_3454;
							    arg1991_3454 = class_num_218___object(clabel_cgen_cop);
							    {
							       obj_t obj_3459;
							       obj_3459 = (obj_t) (new1441_3453);
							       (((obj_t) CREF(obj_3459))->header = MAKE_HEADER(arg1991_3454, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_5475;
							    aux_5475 = (object_t) (new1441_3453);
							    OBJECT_WIDENING_SET(aux_5475, BFALSE);
							 }
							 ((((clabel_t) CREF(new1441_3453))->loc) = ((obj_t) arg2373_2051), BUNSPEC);
							 ((((clabel_t) CREF(new1441_3453))->name) = ((obj_t) arg2374_2052), BUNSPEC);
							 ((((clabel_t) CREF(new1441_3453))->used__226) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							 ((((clabel_t) CREF(new1441_3453))->body) = ((obj_t) BUNSPEC), BUNSPEC);
							 res2690_3461 = new1441_3453;
						      }
						      arg2371_2049 = res2690_3461;
						   }
						}
						{
						   sfun_c_188_t res2691_3467;
						   {
						      sfun_c_188_t new1611_3464;
						      new1611_3464 = ((sfun_c_188_t) BREF(GC_MALLOC(sizeof(struct sfun_c_188))));
						      ((((sfun_c_188_t) CREF(new1611_3464))->label) = ((clabel_t) arg2371_2049), BUNSPEC);
						      ((((sfun_c_188_t) CREF(new1611_3464))->integrated) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						      res2691_3467 = new1611_3464;
						   }
						   arg2370_2048 = res2691_3467;
						}
					     }
					     {
						obj_t aux_5487;
						object_t aux_5485;
						aux_5487 = (obj_t) (arg2370_2048);
						aux_5485 = (object_t) (obj1702_2047);
						OBJECT_WIDENING_SET(aux_5485, aux_5487);
					     }
					  }
					  {
					     long arg2376_2054;
					     arg2376_2054 = class_num_218___object(sfun_c_188_cgen_cop);
					     {
						obj_t obj_3468;
						obj_3468 = (obj_t) (obj1702_2047);
						(((obj_t) CREF(obj_3468))->header = MAKE_HEADER(arg2376_2054, 0), BUNSPEC);
					     }
					  }
					  fun_2038 = obj1702_2047;
				       }
				       {
					  obj_t formals_2039;
					  {
					     sfun_t obj_3470;
					     obj_3470 = (sfun_t) (fun_2038);
					     formals_2039 = (((sfun_t) CREF(obj_3470))->args);
					  }
					  {
					     {
						obj_t l1704_2040;
						l1704_2040 = formals_2039;
					      lname1705_2041:
						if (PAIRP(l1704_2040))
						  {
						     set_variable_name__102_cgen_prototype(CAR(l1704_2040));
						     {
							obj_t l1704_5499;
							l1704_5499 = CDR(l1704_2040);
							l1704_2040 = l1704_5499;
							goto lname1705_2041;
						     }
						  }
						else
						  {
						     ((bool_t) 1);
						  }
					     }
					     {
						obj_t all_formals_186_5503;
						obj_t locals_5501;
						locals_5501 = CDR(locals_2019);
						all_formals_186_5503 = append_2_18___r4_pairs_and_lists_6_3(formals_2039, all_formals_186_2020);
						all_formals_186_2020 = all_formals_186_5503;
						locals_2019 = locals_5501;
						goto loop_2021;
					     }
					  }
				       }
				    }
				 }
			    }
			 }
			 break;
		      case ((long) 12):
			 {
			    let_var_6_t node_2055;
			    node_2055 = (let_var_6_t) (node_26);
			    {
			       local_var_164_t decls_2058;
			       obj_t sets_2059;
			       stop_t body_2060;
			       {
				  obj_t arg2387_2070;
				  obj_t arg2388_2071;
				  arg2387_2070 = (((let_var_6_t) CREF(node_2055))->loc);
				  {
				     obj_t l1708_2072;
				     l1708_2072 = (((let_var_6_t) CREF(node_2055))->bindings);
				     if (NULLP(l1708_2072))
				       {
					  arg2388_2071 = BNIL;
				       }
				     else
				       {
					  obj_t head1710_2074;
					  {
					     obj_t aux_5511;
					     {
						obj_t aux_5512;
						aux_5512 = CAR(l1708_2072);
						aux_5511 = CAR(aux_5512);
					     }
					     head1710_2074 = MAKE_PAIR(aux_5511, BNIL);
					  }
					  {
					     obj_t l1708_2075;
					     obj_t tail1711_2076;
					     l1708_2075 = CDR(l1708_2072);
					     tail1711_2076 = head1710_2074;
					   lname1709_2077:
					     if (NULLP(l1708_2075))
					       {
						  arg2388_2071 = head1710_2074;
					       }
					     else
					       {
						  obj_t newtail1712_2080;
						  {
						     obj_t aux_5518;
						     {
							obj_t aux_5519;
							aux_5519 = CAR(l1708_2075);
							aux_5518 = CAR(aux_5519);
						     }
						     newtail1712_2080 = MAKE_PAIR(aux_5518, BNIL);
						  }
						  SET_CDR(tail1711_2076, newtail1712_2080);
						  {
						     obj_t tail1711_5526;
						     obj_t l1708_5524;
						     l1708_5524 = CDR(l1708_2075);
						     tail1711_5526 = newtail1712_2080;
						     tail1711_2076 = tail1711_5526;
						     l1708_2075 = l1708_5524;
						     goto lname1709_2077;
						  }
					       }
					  }
				       }
				  }
				  {
				     local_var_164_t res2692_3499;
				     {
					local_var_164_t new1534_3493;
					new1534_3493 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
					{
					   long arg1959_3494;
					   arg1959_3494 = class_num_218___object(local_var_164_cgen_cop);
					   {
					      obj_t obj_3497;
					      obj_3497 = (obj_t) (new1534_3493);
					      (((obj_t) CREF(obj_3497))->header = MAKE_HEADER(arg1959_3494, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_5532;
					   aux_5532 = (object_t) (new1534_3493);
					   OBJECT_WIDENING_SET(aux_5532, BFALSE);
					}
					((((local_var_164_t) CREF(new1534_3493))->loc) = ((obj_t) arg2387_2070), BUNSPEC);
					((((local_var_164_t) CREF(new1534_3493))->vars) = ((obj_t) arg2388_2071), BUNSPEC);
					res2692_3499 = new1534_3493;
				     }
				     decls_2058 = res2692_3499;
				  }
			       }
			       {
				  obj_t l1713_2088;
				  l1713_2088 = (((let_var_6_t) CREF(node_2055))->bindings);
				  if (NULLP(l1713_2088))
				    {
				       sets_2059 = BNIL;
				    }
				  else
				    {
				       obj_t head1715_2090;
				       head1715_2090 = MAKE_PAIR(BNIL, BNIL);
				       {
					  obj_t l1713_2091;
					  obj_t tail1716_2092;
					  l1713_2091 = l1713_2088;
					  tail1716_2092 = head1715_2090;
					lname1714_2093:
					  if (NULLP(l1713_2091))
					    {
					       sets_2059 = CDR(head1715_2090);
					    }
					  else
					    {
					       obj_t newtail1717_2095;
					       {
						  cop_t arg2406_2097;
						  {
						     obj_t x_2099;
						     x_2099 = CAR(l1713_2091);
						     set_variable_name__102_cgen_prototype(CAR(x_2099));
						     {
							setq_t arg2409_2101;
							{
							   node_t aux_5551;
							   variable_t aux_5547;
							   {
							      obj_t aux_5552;
							      aux_5552 = CDR(x_2099);
							      aux_5551 = (node_t) (aux_5552);
							   }
							   {
							      obj_t aux_5548;
							      aux_5548 = CAR(x_2099);
							      aux_5547 = (variable_t) (aux_5548);
							   }
							   arg2409_2101 = node_setq_243_cgen_cgen(aux_5547, aux_5551);
							}
							arg2406_2097 = node__cop_142_cgen_cgen((node_t) (arg2409_2101), _stop_kont__121_cgen_cgen);
						     }
						  }
						  {
						     obj_t aux_5558;
						     aux_5558 = (obj_t) (arg2406_2097);
						     newtail1717_2095 = MAKE_PAIR(aux_5558, BNIL);
						  }
					       }
					       SET_CDR(tail1716_2092, newtail1717_2095);
					       {
						  obj_t tail1716_5564;
						  obj_t l1713_5562;
						  l1713_5562 = CDR(l1713_2091);
						  tail1716_5564 = newtail1717_2095;
						  tail1716_2092 = tail1716_5564;
						  l1713_2091 = l1713_5562;
						  goto lname1714_2093;
					       }
					    }
				       }
				    }
			       }
			       {
				  cop_t cop_2106;
				  cop_2106 = node__cop_142_cgen_cgen((((let_var_6_t) CREF(node_2055))->body), kont_27);
				  {
				     stop_t res2693_3524;
				     {
					obj_t loc_3516;
					loc_3516 = BFALSE;
					{
					   stop_t new1513_3518;
					   new1513_3518 = ((stop_t) BREF(GC_MALLOC(sizeof(struct stop))));
					   {
					      long arg1965_3519;
					      arg1965_3519 = class_num_218___object(stop_cgen_cop);
					      {
						 obj_t obj_3522;
						 obj_3522 = (obj_t) (new1513_3518);
						 (((obj_t) CREF(obj_3522))->header = MAKE_HEADER(arg1965_3519, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_5571;
					      aux_5571 = (object_t) (new1513_3518);
					      OBJECT_WIDENING_SET(aux_5571, loc_3516);
					   }
					   ((((stop_t) CREF(new1513_3518))->loc) = ((obj_t) loc_3516), BUNSPEC);
					   ((((stop_t) CREF(new1513_3518))->value) = ((cop_t) cop_2106), BUNSPEC);
					   res2693_3524 = new1513_3518;
					}
				     }
				     body_2060 = res2693_3524;
				  }
			       }
			       {
				  cop_t arg2377_2061;
				  obj_t arg2378_2062;
				  {
				     csequence_t arg2379_2063;
				     obj_t arg2380_2064;
				     {
					obj_t arg2381_2065;
					{
					   obj_t arg2383_2066;
					   {
					      obj_t arg2384_2067;
					      {
						 obj_t list2385_2068;
						 {
						    obj_t aux_5576;
						    aux_5576 = (obj_t) (body_2060);
						    list2385_2068 = MAKE_PAIR(aux_5576, BNIL);
						 }
						 arg2384_2067 = list2385_2068;
					      }
					      arg2383_2066 = append_2_18___r4_pairs_and_lists_6_3(sets_2059, arg2384_2067);
					   }
					   {
					      obj_t aux_5580;
					      aux_5580 = (obj_t) (decls_2058);
					      arg2381_2065 = MAKE_PAIR(aux_5580, arg2383_2066);
					   }
					}
					{
					   csequence_t res2694_3538;
					   {
					      obj_t loc_3528;
					      loc_3528 = BFALSE;
					      {
						 csequence_t new1501_3531;
						 new1501_3531 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						 {
						    long arg1972_3532;
						    arg1972_3532 = class_num_218___object(csequence_cgen_cop);
						    {
						       obj_t obj_3536;
						       obj_3536 = (obj_t) (new1501_3531);
						       (((obj_t) CREF(obj_3536))->header = MAKE_HEADER(arg1972_3532, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_5587;
						    aux_5587 = (object_t) (new1501_3531);
						    OBJECT_WIDENING_SET(aux_5587, loc_3528);
						 }
						 ((((csequence_t) CREF(new1501_3531))->loc) = ((obj_t) loc_3528), BUNSPEC);
						 ((((csequence_t) CREF(new1501_3531))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						 ((((csequence_t) CREF(new1501_3531))->cops) = ((obj_t) arg2381_2065), BUNSPEC);
						 res2694_3538 = new1501_3531;
					      }
					   }
					   arg2379_2063 = res2694_3538;
					}
				     }
				     arg2380_2064 = (((let_var_6_t) CREF(node_2055))->loc);
				     arg2377_2061 = bdb_let_var_254_cgen_cgen((cop_t) (arg2379_2063), arg2380_2064);
				  }
				  arg2378_2062 = (((let_var_6_t) CREF(node_2055))->loc);
				  {
				     obj_t cop_3541;
				     cop_3541 = (obj_t) (arg2377_2061);
				     {
					bool_t test1897_3543;
					test1897_3543 = is_a__118___object(cop_3541, block_cgen_cop);
					if (test1897_3543)
					  {
					     aux_4563 = cop_3541;
					  }
					else
					  {
					     {
						block_t res2695_3555;
						{
						   cop_t body_3548;
						   body_3548 = (cop_t) (cop_3541);
						   {
						      block_t new1457_3549;
						      new1457_3549 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						      {
							 long arg1987_3550;
							 arg1987_3550 = class_num_218___object(block_cgen_cop);
							 {
							    obj_t obj_3553;
							    obj_3553 = (obj_t) (new1457_3549);
							    (((obj_t) CREF(obj_3553))->header = MAKE_HEADER(arg1987_3550, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_5605;
							 aux_5605 = (object_t) (new1457_3549);
							 OBJECT_WIDENING_SET(aux_5605, BFALSE);
						      }
						      ((((block_t) CREF(new1457_3549))->loc) = ((obj_t) arg2378_2062), BUNSPEC);
						      ((((block_t) CREF(new1457_3549))->body) = ((cop_t) body_3548), BUNSPEC);
						      res2695_3555 = new1457_3549;
						   }
						}
						aux_4563 = (obj_t) (res2695_3555);
					     }
					  }
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 13):
			 {
			    set_ex_it_116_t node_2109;
			    node_2109 = (set_ex_it_116_t) (node_26);
			    {
			       variable_t exit_2112;
			       {
				  var_t arg2468_2164;
				  arg2468_2164 = (((set_ex_it_116_t) CREF(node_2109))->var);
				  exit_2112 = (((var_t) CREF(arg2468_2164))->variable);
			       }
			       set_variable_name__102_cgen_prototype((obj_t) (exit_2112));
			       {
				  obj_t arg2416_2113;
				  {
				     cpragma_t arg2417_2114;
				     local_var_164_t arg2418_2115;
				     cset_ex_it_123_t arg2419_2116;
				     {
					obj_t arg2424_2121;
					arg2424_2121 = (((set_ex_it_116_t) CREF(node_2109))->loc);
					{
					   cpragma_t res2696_3569;
					   {
					      obj_t format_3560;
					      format_3560 = string2746_cgen_cgen;
					      {
						 cpragma_t new1487_3562;
						 new1487_3562 = ((cpragma_t) BREF(GC_MALLOC(sizeof(struct cpragma))));
						 {
						    long arg1977_3563;
						    arg1977_3563 = class_num_218___object(cpragma_cgen_cop);
						    {
						       obj_t obj_3567;
						       obj_3567 = (obj_t) (new1487_3562);
						       (((obj_t) CREF(obj_3567))->header = MAKE_HEADER(arg1977_3563, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_5621;
						    aux_5621 = (object_t) (new1487_3562);
						    OBJECT_WIDENING_SET(aux_5621, BFALSE);
						 }
						 ((((cpragma_t) CREF(new1487_3562))->loc) = ((obj_t) arg2424_2121), BUNSPEC);
						 ((((cpragma_t) CREF(new1487_3562))->format) = ((obj_t) format_3560), BUNSPEC);
						 ((((cpragma_t) CREF(new1487_3562))->args) = ((obj_t) BNIL), BUNSPEC);
						 res2696_3569 = new1487_3562;
					      }
					   }
					   arg2417_2114 = res2696_3569;
					}
				     }
				     {
					obj_t arg2427_2124;
					obj_t arg2428_2125;
					arg2427_2124 = (((set_ex_it_116_t) CREF(node_2109))->loc);
					{
					   obj_t list2430_2127;
					   {
					      obj_t aux_5628;
					      {
						 variable_t aux_5629;
						 {
						    var_t arg2432_2129;
						    arg2432_2129 = (((set_ex_it_116_t) CREF(node_2109))->var);
						    aux_5629 = (((var_t) CREF(arg2432_2129))->variable);
						 }
						 aux_5628 = (obj_t) (aux_5629);
					      }
					      list2430_2127 = MAKE_PAIR(aux_5628, BNIL);
					   }
					   arg2428_2125 = list2430_2127;
					}
					{
					   local_var_164_t res2697_3582;
					   {
					      local_var_164_t new1534_3576;
					      new1534_3576 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
					      {
						 long arg1959_3577;
						 arg1959_3577 = class_num_218___object(local_var_164_cgen_cop);
						 {
						    obj_t obj_3580;
						    obj_3580 = (obj_t) (new1534_3576);
						    (((obj_t) CREF(obj_3580))->header = MAKE_HEADER(arg1959_3577, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_5638;
						 aux_5638 = (object_t) (new1534_3576);
						 OBJECT_WIDENING_SET(aux_5638, BFALSE);
					      }
					      ((((local_var_164_t) CREF(new1534_3576))->loc) = ((obj_t) arg2427_2124), BUNSPEC);
					      ((((local_var_164_t) CREF(new1534_3576))->vars) = ((obj_t) arg2428_2125), BUNSPEC);
					      res2697_3582 = new1534_3576;
					   }
					   arg2418_2115 = res2697_3582;
					}
				     }
				     {
					obj_t arg2433_2130;
					varc_t arg2434_2131;
					cop_t arg2435_2132;
					csequence_t arg2436_2133;
					arg2433_2130 = (((set_ex_it_116_t) CREF(node_2109))->loc);
					{
					   varc_t res2698_3592;
					   {
					      obj_t loc_3584;
					      loc_3584 = BFALSE;
					      {
						 varc_t new1481_3586;
						 new1481_3586 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
						 {
						    long arg1979_3587;
						    arg1979_3587 = class_num_218___object(varc_cgen_cop);
						    {
						       obj_t obj_3590;
						       obj_3590 = (obj_t) (new1481_3586);
						       (((obj_t) CREF(obj_3590))->header = MAKE_HEADER(arg1979_3587, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_5648;
						    aux_5648 = (object_t) (new1481_3586);
						    OBJECT_WIDENING_SET(aux_5648, loc_3584);
						 }
						 ((((varc_t) CREF(new1481_3586))->loc) = ((obj_t) loc_3584), BUNSPEC);
						 ((((varc_t) CREF(new1481_3586))->variable) = ((variable_t) exit_2112), BUNSPEC);
						 res2698_3592 = new1481_3586;
					      }
					   }
					   arg2434_2131 = res2698_3592;
					}
					{
					   pragma_t arg2438_2135;
					   {
					      obj_t arg2439_2136;
					      obj_t arg2440_2137;
					      arg2439_2136 = (((set_ex_it_116_t) CREF(node_2109))->loc);
					      arg2440_2137 = ____74_type_cache;
					      {
						 pragma_t res2699_3610;
						 {
						    type_t type_3595;
						    obj_t key_3597;
						    obj_t format_3598;
						    type_3595 = (type_t) (arg2440_2137);
						    key_3597 = BINT(((long) -1));
						    format_3598 = string2747_cgen_cgen;
						    {
						       pragma_t new1279_3600;
						       new1279_3600 = ((pragma_t) BREF(GC_MALLOC(sizeof(struct pragma))));
						       {
							  long arg2026_3601;
							  arg2026_3601 = class_num_218___object(pragma_ast_node);
							  {
							     obj_t obj_3608;
							     obj_3608 = (obj_t) (new1279_3600);
							     (((obj_t) CREF(obj_3608))->header = MAKE_HEADER(arg2026_3601, 0), BUNSPEC);
							  }
						       }
						       {
							  object_t aux_5660;
							  aux_5660 = (object_t) (new1279_3600);
							  OBJECT_WIDENING_SET(aux_5660, BFALSE);
						       }
						       ((((pragma_t) CREF(new1279_3600))->loc) = ((obj_t) arg2439_2136), BUNSPEC);
						       ((((pragma_t) CREF(new1279_3600))->type) = ((type_t) type_3595), BUNSPEC);
						       ((((pragma_t) CREF(new1279_3600))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
						       ((((pragma_t) CREF(new1279_3600))->key) = ((obj_t) key_3597), BUNSPEC);
						       ((((pragma_t) CREF(new1279_3600))->format) = ((obj_t) format_3598), BUNSPEC);
						       ((((pragma_t) CREF(new1279_3600))->args) = ((obj_t) BNIL), BUNSPEC);
						       res2699_3610 = new1279_3600;
						    }
						 }
						 arg2438_2135 = res2699_3610;
					      }
					   }
					   arg2435_2132 = node__cop_142_cgen_cgen((node_t) (arg2438_2135), kont_27);
					}
					{
					   obj_t arg2444_2141;
					   {
					      cop_t arg2445_2142;
					      cop_t arg2446_2143;
					      {
						 setq_t arg2450_2147;
						 {
						    pragma_t arg2451_2148;
						    {
						       obj_t arg2452_2149;
						       obj_t arg2453_2150;
						       obj_t arg2455_2152;
						       arg2452_2149 = (((set_ex_it_116_t) CREF(node_2109))->loc);
						       arg2453_2150 = ____74_type_cache;
						       {
							  obj_t arg2458_2155;
							  {
							     obj_t aux_5672;
							     {
								type_t arg2466_2162;
								{
								   local_t obj_3612;
								   obj_3612 = (local_t) (exit_2112);
								   arg2466_2162 = (((local_t) CREF(obj_3612))->type);
								}
								aux_5672 = (((type_t) CREF(arg2466_2162))->name);
							     }
							     arg2458_2155 = string_sans___40_type_tools(aux_5672);
							  }
							  {
							     obj_t list2460_2157;
							     {
								obj_t arg2461_2158;
								{
								   obj_t arg2463_2159;
								   arg2463_2159 = MAKE_PAIR(string2748_cgen_cgen, BNIL);
								   arg2461_2158 = MAKE_PAIR(arg2458_2155, arg2463_2159);
								}
								list2460_2157 = MAKE_PAIR(string2749_cgen_cgen, arg2461_2158);
							     }
							     arg2455_2152 = string_append_106___r4_strings_6_7(list2460_2157);
							  }
						       }
						       {
							  pragma_t res2700_3630;
							  {
							     type_t type_3615;
							     obj_t key_3617;
							     type_3615 = (type_t) (arg2453_2150);
							     key_3617 = BINT(((long) -1));
							     {
								pragma_t new1279_3620;
								new1279_3620 = ((pragma_t) BREF(GC_MALLOC(sizeof(struct pragma))));
								{
								   long arg2026_3621;
								   arg2026_3621 = class_num_218___object(pragma_ast_node);
								   {
								      obj_t obj_3628;
								      obj_3628 = (obj_t) (new1279_3620);
								      (((obj_t) CREF(obj_3628))->header = MAKE_HEADER(arg2026_3621, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_5687;
								   aux_5687 = (object_t) (new1279_3620);
								   OBJECT_WIDENING_SET(aux_5687, BFALSE);
								}
								((((pragma_t) CREF(new1279_3620))->loc) = ((obj_t) arg2452_2149), BUNSPEC);
								((((pragma_t) CREF(new1279_3620))->type) = ((type_t) type_3615), BUNSPEC);
								((((pragma_t) CREF(new1279_3620))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								((((pragma_t) CREF(new1279_3620))->key) = ((obj_t) key_3617), BUNSPEC);
								((((pragma_t) CREF(new1279_3620))->format) = ((obj_t) arg2455_2152), BUNSPEC);
								((((pragma_t) CREF(new1279_3620))->args) = ((obj_t) BNIL), BUNSPEC);
								res2700_3630 = new1279_3620;
							     }
							  }
							  arg2451_2148 = res2700_3630;
						       }
						    }
						    arg2450_2147 = node_setq_243_cgen_cgen(exit_2112, (node_t) (arg2451_2148));
						 }
						 arg2445_2142 = node__cop_142_cgen_cgen((node_t) (arg2450_2147), _id_kont__126_cgen_cgen);
					      }
					      arg2446_2143 = node__cop_142_cgen_cgen((((set_ex_it_116_t) CREF(node_2109))->body), kont_27);
					      {
						 obj_t list2447_2144;
						 {
						    obj_t arg2448_2145;
						    {
						       obj_t aux_5702;
						       aux_5702 = (obj_t) (arg2446_2143);
						       arg2448_2145 = MAKE_PAIR(aux_5702, BNIL);
						    }
						    {
						       obj_t aux_5705;
						       aux_5705 = (obj_t) (arg2445_2142);
						       list2447_2144 = MAKE_PAIR(aux_5705, arg2448_2145);
						    }
						 }
						 arg2444_2141 = list2447_2144;
					      }
					   }
					   {
					      csequence_t res2701_3643;
					      {
						 obj_t loc_3633;
						 loc_3633 = BFALSE;
						 {
						    csequence_t new1501_3636;
						    new1501_3636 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						    {
						       long arg1972_3637;
						       arg1972_3637 = class_num_218___object(csequence_cgen_cop);
						       {
							  obj_t obj_3641;
							  obj_3641 = (obj_t) (new1501_3636);
							  (((obj_t) CREF(obj_3641))->header = MAKE_HEADER(arg1972_3637, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_5712;
						       aux_5712 = (object_t) (new1501_3636);
						       OBJECT_WIDENING_SET(aux_5712, loc_3633);
						    }
						    ((((csequence_t) CREF(new1501_3636))->loc) = ((obj_t) loc_3633), BUNSPEC);
						    ((((csequence_t) CREF(new1501_3636))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						    ((((csequence_t) CREF(new1501_3636))->cops) = ((obj_t) arg2444_2141), BUNSPEC);
						    res2701_3643 = new1501_3636;
						 }
					      }
					      arg2436_2133 = res2701_3643;
					   }
					}
					{
					   cset_ex_it_123_t res2702_3656;
					   {
					      cop_t exit_3645;
					      cop_t body_3647;
					      exit_3645 = (cop_t) (arg2434_2131);
					      body_3647 = (cop_t) (arg2436_2133);
					      {
						 cset_ex_it_123_t new1596_3648;
						 new1596_3648 = ((cset_ex_it_123_t) BREF(GC_MALLOC(sizeof(struct cset_ex_it_123))));
						 {
						    long arg1939_3649;
						    arg1939_3649 = class_num_218___object(cset_ex_it_123_cgen_cop);
						    {
						       obj_t obj_3654;
						       obj_3654 = (obj_t) (new1596_3648);
						       (((obj_t) CREF(obj_3654))->header = MAKE_HEADER(arg1939_3649, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_5724;
						    aux_5724 = (object_t) (new1596_3648);
						    OBJECT_WIDENING_SET(aux_5724, BFALSE);
						 }
						 ((((cset_ex_it_123_t) CREF(new1596_3648))->loc) = ((obj_t) arg2433_2130), BUNSPEC);
						 ((((cset_ex_it_123_t) CREF(new1596_3648))->exit) = ((cop_t) exit_3645), BUNSPEC);
						 ((((cset_ex_it_123_t) CREF(new1596_3648))->jump_value_221) = ((cop_t) arg2435_2132), BUNSPEC);
						 ((((cset_ex_it_123_t) CREF(new1596_3648))->body) = ((cop_t) body_3647), BUNSPEC);
						 res2702_3656 = new1596_3648;
					      }
					   }
					   arg2419_2116 = res2702_3656;
					}
				     }
				     {
					obj_t list2420_2117;
					{
					   obj_t arg2421_2118;
					   {
					      obj_t arg2422_2119;
					      {
						 obj_t aux_5731;
						 aux_5731 = (obj_t) (arg2419_2116);
						 arg2422_2119 = MAKE_PAIR(aux_5731, BNIL);
					      }
					      {
						 obj_t aux_5734;
						 aux_5734 = (obj_t) (arg2418_2115);
						 arg2421_2118 = MAKE_PAIR(aux_5734, arg2422_2119);
					      }
					   }
					   {
					      obj_t aux_5737;
					      aux_5737 = (obj_t) (arg2417_2114);
					      list2420_2117 = MAKE_PAIR(aux_5737, arg2421_2118);
					   }
					}
					arg2416_2113 = list2420_2117;
				     }
				  }
				  {
				     csequence_t res2703_3668;
				     {
					obj_t loc_3658;
					loc_3658 = BFALSE;
					{
					   csequence_t new1501_3661;
					   new1501_3661 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					   {
					      long arg1972_3662;
					      arg1972_3662 = class_num_218___object(csequence_cgen_cop);
					      {
						 obj_t obj_3666;
						 obj_3666 = (obj_t) (new1501_3661);
						 (((obj_t) CREF(obj_3666))->header = MAKE_HEADER(arg1972_3662, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_5744;
					      aux_5744 = (object_t) (new1501_3661);
					      OBJECT_WIDENING_SET(aux_5744, loc_3658);
					   }
					   ((((csequence_t) CREF(new1501_3661))->loc) = ((obj_t) loc_3658), BUNSPEC);
					   ((((csequence_t) CREF(new1501_3661))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					   ((((csequence_t) CREF(new1501_3661))->cops) = ((obj_t) arg2416_2113), BUNSPEC);
					   res2703_3668 = new1501_3661;
					}
				     }
				     aux_4563 = (obj_t) (res2703_3668);
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 14):
			 {
			    jump_ex_it_184_t node_2165;
			    node_2165 = (jump_ex_it_184_t) (node_26);
			    {
			       local_t vaux_2168;
			       vaux_2168 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (type_t) (_obj__252_type_cache));
			       {
				  cop_t vcop_2169;
				  {
				     setq_t arg2573_2266;
				     arg2573_2266 = node_setq_243_cgen_cgen((variable_t) (vaux_2168), (((jump_ex_it_184_t) CREF(node_2165))->value));
				     vcop_2169 = node__cop_142_cgen_cgen((node_t) (arg2573_2266), _id_kont__126_cgen_cgen);
				  }
				  {
				     node_t exit_2170;
				     exit_2170 = (((jump_ex_it_184_t) CREF(node_2165))->exit);
				     {
					local_t eaux_2171;
					eaux_2171 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 3)), (type_t) (_procedure__226_type_cache));
					{
					   cop_t ecop_2172;
					   {
					      setq_t arg2569_2264;
					      arg2569_2264 = node_setq_243_cgen_cgen((variable_t) (eaux_2171), exit_2170);
					      ecop_2172 = node__cop_142_cgen_cgen((node_t) (arg2569_2264), _id_kont__126_cgen_cgen);
					   }
					   {
					      {
						 bool_t test2469_2173;
						 {
						    bool_t test2560_2257;
						    test2560_2257 = is_a__118___object((obj_t) (vcop_2169), csetq_cgen_cop);
						    if (test2560_2257)
						      {
							 bool_t test_5771;
							 {
							    obj_t aux_5778;
							    obj_t aux_5772;
							    aux_5778 = (obj_t) (vaux_2168);
							    {
							       variable_t aux_5773;
							       {
								  varc_t arg2568_2263;
								  {
								     csetq_t obj_3672;
								     obj_3672 = (csetq_t) (vcop_2169);
								     arg2568_2263 = (((csetq_t) CREF(obj_3672))->var);
								  }
								  aux_5773 = (((varc_t) CREF(arg2568_2263))->variable);
							       }
							       aux_5772 = (obj_t) (aux_5773);
							    }
							    test_5771 = (aux_5772 == aux_5778);
							 }
							 if (test_5771)
							   {
							      bool_t test2562_2259;
							      test2562_2259 = is_a__118___object((obj_t) (ecop_2172), csetq_cgen_cop);
							      if (test2562_2259)
								{
								   obj_t aux_5790;
								   obj_t aux_5784;
								   aux_5790 = (obj_t) (eaux_2171);
								   {
								      variable_t aux_5785;
								      {
									 varc_t arg2565_2261;
									 {
									    csetq_t obj_3677;
									    obj_3677 = (csetq_t) (ecop_2172);
									    arg2565_2261 = (((csetq_t) CREF(obj_3677))->var);
									 }
									 aux_5785 = (((varc_t) CREF(arg2565_2261))->variable);
								      }
								      aux_5784 = (obj_t) (aux_5785);
								   }
								   test2469_2173 = (aux_5784 == aux_5790);
								}
							      else
								{
								   test2469_2173 = ((bool_t) 0);
								}
							   }
							 else
							   {
							      test2469_2173 = ((bool_t) 0);
							   }
						      }
						    else
						      {
							 test2469_2173 = ((bool_t) 0);
						      }
						 }
						 if (test2469_2173)
						   {
						      {
							 cjump_ex_it_131_t arg2470_2174;
							 {
							    obj_t arg2471_2175;
							    cop_t arg2472_2176;
							    cop_t arg2473_2177;
							    arg2471_2175 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
							    {
							       csetq_t obj_3682;
							       obj_3682 = (csetq_t) (ecop_2172);
							       arg2472_2176 = (((csetq_t) CREF(obj_3682))->value);
							    }
							    {
							       csetq_t obj_3683;
							       obj_3683 = (csetq_t) (vcop_2169);
							       arg2473_2177 = (((csetq_t) CREF(obj_3683))->value);
							    }
							    {
							       cjump_ex_it_131_t res2704_3694;
							       {
								  cjump_ex_it_131_t new1604_3687;
								  new1604_3687 = ((cjump_ex_it_131_t) BREF(GC_MALLOC(sizeof(struct cjump_ex_it_131))));
								  {
								     long arg1937_3688;
								     arg1937_3688 = class_num_218___object(cjump_ex_it_131_cgen_cop);
								     {
									obj_t obj_3692;
									obj_3692 = (obj_t) (new1604_3687);
									(((obj_t) CREF(obj_3692))->header = MAKE_HEADER(arg1937_3688, 0), BUNSPEC);
								     }
								  }
								  {
								     object_t aux_5803;
								     aux_5803 = (object_t) (new1604_3687);
								     OBJECT_WIDENING_SET(aux_5803, BFALSE);
								  }
								  ((((cjump_ex_it_131_t) CREF(new1604_3687))->loc) = ((obj_t) arg2471_2175), BUNSPEC);
								  ((((cjump_ex_it_131_t) CREF(new1604_3687))->exit) = ((cop_t) arg2472_2176), BUNSPEC);
								  ((((cjump_ex_it_131_t) CREF(new1604_3687))->value) = ((cop_t) arg2473_2177), BUNSPEC);
								  res2704_3694 = new1604_3687;
							       }
							       arg2470_2174 = res2704_3694;
							    }
							 }
							 aux_4563 = (obj_t) (arg2470_2174);
						      }
						   }
						 else
						   {
						      bool_t test2474_2178;
						      {
							 bool_t test2557_2254;
							 test2557_2254 = is_a__118___object((obj_t) (vcop_2169), csetq_cgen_cop);
							 if (test2557_2254)
							   {
							      obj_t aux_5819;
							      obj_t aux_5813;
							      aux_5819 = (obj_t) (vaux_2168);
							      {
								 variable_t aux_5814;
								 {
								    varc_t arg2559_2256;
								    {
								       csetq_t obj_3697;
								       obj_3697 = (csetq_t) (vcop_2169);
								       arg2559_2256 = (((csetq_t) CREF(obj_3697))->var);
								    }
								    aux_5814 = (((varc_t) CREF(arg2559_2256))->variable);
								 }
								 aux_5813 = (obj_t) (aux_5814);
							      }
							      test2474_2178 = (aux_5813 == aux_5819);
							   }
							 else
							   {
							      test2474_2178 = ((bool_t) 0);
							   }
						      }
						      if (test2474_2178)
							{
							   {
							      obj_t arg2475_2179;
							      csequence_t arg2476_2180;
							      arg2475_2179 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
							      {
								 obj_t arg2477_2181;
								 {
								    local_var_164_t arg2478_2182;
								    csequence_t arg2479_2183;
								    cjump_ex_it_131_t arg2480_2184;
								    {
								       obj_t arg2486_2189;
								       obj_t arg2487_2190;
								       arg2486_2189 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
								       {
									  obj_t list2488_2191;
									  {
									     obj_t aux_5825;
									     aux_5825 = (obj_t) (eaux_2171);
									     list2488_2191 = MAKE_PAIR(aux_5825, BNIL);
									  }
									  arg2487_2190 = list2488_2191;
								       }
								       {
									  local_var_164_t res2705_3712;
									  {
									     local_var_164_t new1534_3706;
									     new1534_3706 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
									     {
										long arg1959_3707;
										arg1959_3707 = class_num_218___object(local_var_164_cgen_cop);
										{
										   obj_t obj_3710;
										   obj_3710 = (obj_t) (new1534_3706);
										   (((obj_t) CREF(obj_3710))->header = MAKE_HEADER(arg1959_3707, 0), BUNSPEC);
										}
									     }
									     {
										object_t aux_5832;
										aux_5832 = (object_t) (new1534_3706);
										OBJECT_WIDENING_SET(aux_5832, BFALSE);
									     }
									     ((((local_var_164_t) CREF(new1534_3706))->loc) = ((obj_t) arg2486_2189), BUNSPEC);
									     ((((local_var_164_t) CREF(new1534_3706))->vars) = ((obj_t) arg2487_2190), BUNSPEC);
									     res2705_3712 = new1534_3706;
									  }
									  arg2478_2182 = res2705_3712;
								       }
								    }
								    {
								       obj_t arg2490_2193;
								       {
									  obj_t list2491_2194;
									  {
									     obj_t aux_5837;
									     aux_5837 = (obj_t) (ecop_2172);
									     list2491_2194 = MAKE_PAIR(aux_5837, BNIL);
									  }
									  arg2490_2193 = list2491_2194;
								       }
								       {
									  csequence_t res2706_3724;
									  {
									     obj_t loc_3714;
									     loc_3714 = BFALSE;
									     {
										csequence_t new1501_3717;
										new1501_3717 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
										{
										   long arg1972_3718;
										   arg1972_3718 = class_num_218___object(csequence_cgen_cop);
										   {
										      obj_t obj_3722;
										      obj_3722 = (obj_t) (new1501_3717);
										      (((obj_t) CREF(obj_3722))->header = MAKE_HEADER(arg1972_3718, 0), BUNSPEC);
										   }
										}
										{
										   object_t aux_5844;
										   aux_5844 = (object_t) (new1501_3717);
										   OBJECT_WIDENING_SET(aux_5844, loc_3714);
										}
										((((csequence_t) CREF(new1501_3717))->loc) = ((obj_t) loc_3714), BUNSPEC);
										((((csequence_t) CREF(new1501_3717))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
										((((csequence_t) CREF(new1501_3717))->cops) = ((obj_t) arg2490_2193), BUNSPEC);
										res2706_3724 = new1501_3717;
									     }
									  }
									  arg2479_2183 = res2706_3724;
								       }
								    }
								    {
								       cjump_ex_it_131_t arg2494_2196;
								       {
									  obj_t arg2495_2197;
									  varc_t arg2496_2198;
									  cop_t arg2497_2199;
									  arg2495_2197 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									  {
									     obj_t arg2498_2200;
									     arg2498_2200 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									     {
										varc_t res2707_3735;
										{
										   variable_t variable_3728;
										   variable_3728 = (variable_t) (eaux_2171);
										   {
										      varc_t new1481_3729;
										      new1481_3729 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
										      {
											 long arg1979_3730;
											 arg1979_3730 = class_num_218___object(varc_cgen_cop);
											 {
											    obj_t obj_3733;
											    obj_3733 = (obj_t) (new1481_3729);
											    (((obj_t) CREF(obj_3733))->header = MAKE_HEADER(arg1979_3730, 0), BUNSPEC);
											 }
										      }
										      {
											 object_t aux_5857;
											 aux_5857 = (object_t) (new1481_3729);
											 OBJECT_WIDENING_SET(aux_5857, BFALSE);
										      }
										      ((((varc_t) CREF(new1481_3729))->loc) = ((obj_t) arg2498_2200), BUNSPEC);
										      ((((varc_t) CREF(new1481_3729))->variable) = ((variable_t) variable_3728), BUNSPEC);
										      res2707_3735 = new1481_3729;
										   }
										}
										arg2496_2198 = res2707_3735;
									     }
									  }
									  {
									     csetq_t obj_3736;
									     obj_3736 = (csetq_t) (vcop_2169);
									     arg2497_2199 = (((csetq_t) CREF(obj_3736))->value);
									  }
									  {
									     cjump_ex_it_131_t res2708_3747;
									     {
										cop_t exit_3738;
										exit_3738 = (cop_t) (arg2496_2198);
										{
										   cjump_ex_it_131_t new1604_3740;
										   new1604_3740 = ((cjump_ex_it_131_t) BREF(GC_MALLOC(sizeof(struct cjump_ex_it_131))));
										   {
										      long arg1937_3741;
										      arg1937_3741 = class_num_218___object(cjump_ex_it_131_cgen_cop);
										      {
											 obj_t obj_3745;
											 obj_3745 = (obj_t) (new1604_3740);
											 (((obj_t) CREF(obj_3745))->header = MAKE_HEADER(arg1937_3741, 0), BUNSPEC);
										      }
										   }
										   {
										      object_t aux_5869;
										      aux_5869 = (object_t) (new1604_3740);
										      OBJECT_WIDENING_SET(aux_5869, BFALSE);
										   }
										   ((((cjump_ex_it_131_t) CREF(new1604_3740))->loc) = ((obj_t) arg2495_2197), BUNSPEC);
										   ((((cjump_ex_it_131_t) CREF(new1604_3740))->exit) = ((cop_t) exit_3738), BUNSPEC);
										   ((((cjump_ex_it_131_t) CREF(new1604_3740))->value) = ((cop_t) arg2497_2199), BUNSPEC);
										   res2708_3747 = new1604_3740;
										}
									     }
									     arg2494_2196 = res2708_3747;
									  }
								       }
								       arg2480_2184 = arg2494_2196;
								    }
								    {
								       obj_t list2481_2185;
								       {
									  obj_t arg2482_2186;
									  {
									     obj_t arg2484_2187;
									     {
										obj_t aux_5875;
										aux_5875 = (obj_t) (arg2480_2184);
										arg2484_2187 = MAKE_PAIR(aux_5875, BNIL);
									     }
									     {
										obj_t aux_5878;
										aux_5878 = (obj_t) (arg2479_2183);
										arg2482_2186 = MAKE_PAIR(aux_5878, arg2484_2187);
									     }
									  }
									  {
									     obj_t aux_5881;
									     aux_5881 = (obj_t) (arg2478_2182);
									     list2481_2185 = MAKE_PAIR(aux_5881, arg2482_2186);
									  }
								       }
								       arg2477_2181 = list2481_2185;
								    }
								 }
								 {
								    csequence_t res2709_3760;
								    {
								       obj_t loc_3750;
								       loc_3750 = BFALSE;
								       {
									  csequence_t new1501_3753;
									  new1501_3753 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
									  {
									     long arg1972_3754;
									     arg1972_3754 = class_num_218___object(csequence_cgen_cop);
									     {
										obj_t obj_3758;
										obj_3758 = (obj_t) (new1501_3753);
										(((obj_t) CREF(obj_3758))->header = MAKE_HEADER(arg1972_3754, 0), BUNSPEC);
									     }
									  }
									  {
									     object_t aux_5888;
									     aux_5888 = (object_t) (new1501_3753);
									     OBJECT_WIDENING_SET(aux_5888, loc_3750);
									  }
									  ((((csequence_t) CREF(new1501_3753))->loc) = ((obj_t) loc_3750), BUNSPEC);
									  ((((csequence_t) CREF(new1501_3753))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
									  ((((csequence_t) CREF(new1501_3753))->cops) = ((obj_t) arg2477_2181), BUNSPEC);
									  res2709_3760 = new1501_3753;
								       }
								    }
								    arg2476_2180 = res2709_3760;
								 }
							      }
							      {
								 block_t res2710_3769;
								 {
								    cop_t body_3762;
								    body_3762 = (cop_t) (arg2476_2180);
								    {
								       block_t new1457_3763;
								       new1457_3763 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
								       {
									  long arg1987_3764;
									  arg1987_3764 = class_num_218___object(block_cgen_cop);
									  {
									     obj_t obj_3767;
									     obj_3767 = (obj_t) (new1457_3763);
									     (((obj_t) CREF(obj_3767))->header = MAKE_HEADER(arg1987_3764, 0), BUNSPEC);
									  }
								       }
								       {
									  object_t aux_5899;
									  aux_5899 = (object_t) (new1457_3763);
									  OBJECT_WIDENING_SET(aux_5899, BFALSE);
								       }
								       ((((block_t) CREF(new1457_3763))->loc) = ((obj_t) arg2475_2179), BUNSPEC);
								       ((((block_t) CREF(new1457_3763))->body) = ((cop_t) body_3762), BUNSPEC);
								       res2710_3769 = new1457_3763;
								    }
								 }
								 aux_4563 = (obj_t) (res2710_3769);
							      }
							   }
							}
						      else
							{
							   bool_t test2500_2202;
							   {
							      bool_t test2554_2251;
							      test2554_2251 = is_a__118___object((obj_t) (ecop_2172), csetq_cgen_cop);
							      if (test2554_2251)
								{
								   obj_t aux_5914;
								   obj_t aux_5908;
								   aux_5914 = (obj_t) (eaux_2171);
								   {
								      variable_t aux_5909;
								      {
									 varc_t arg2556_2253;
									 {
									    csetq_t obj_3771;
									    obj_3771 = (csetq_t) (ecop_2172);
									    arg2556_2253 = (((csetq_t) CREF(obj_3771))->var);
									 }
									 aux_5909 = (((varc_t) CREF(arg2556_2253))->variable);
								      }
								      aux_5908 = (obj_t) (aux_5909);
								   }
								   test2500_2202 = (aux_5908 == aux_5914);
								}
							      else
								{
								   test2500_2202 = ((bool_t) 0);
								}
							   }
							   if (test2500_2202)
							     {
								{
								   obj_t arg2501_2203;
								   csequence_t arg2502_2204;
								   arg2501_2203 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
								   {
								      obj_t arg2503_2205;
								      {
									 local_var_164_t arg2504_2206;
									 csequence_t arg2506_2207;
									 cjump_ex_it_131_t arg2507_2208;
									 {
									    obj_t arg2514_2213;
									    obj_t arg2515_2214;
									    arg2514_2213 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									    {
									       obj_t list2516_2215;
									       {
										  obj_t aux_5920;
										  aux_5920 = (obj_t) (vaux_2168);
										  list2516_2215 = MAKE_PAIR(aux_5920, BNIL);
									       }
									       arg2515_2214 = list2516_2215;
									    }
									    {
									       local_var_164_t res2711_3786;
									       {
										  local_var_164_t new1534_3780;
										  new1534_3780 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
										  {
										     long arg1959_3781;
										     arg1959_3781 = class_num_218___object(local_var_164_cgen_cop);
										     {
											obj_t obj_3784;
											obj_3784 = (obj_t) (new1534_3780);
											(((obj_t) CREF(obj_3784))->header = MAKE_HEADER(arg1959_3781, 0), BUNSPEC);
										     }
										  }
										  {
										     object_t aux_5927;
										     aux_5927 = (object_t) (new1534_3780);
										     OBJECT_WIDENING_SET(aux_5927, BFALSE);
										  }
										  ((((local_var_164_t) CREF(new1534_3780))->loc) = ((obj_t) arg2514_2213), BUNSPEC);
										  ((((local_var_164_t) CREF(new1534_3780))->vars) = ((obj_t) arg2515_2214), BUNSPEC);
										  res2711_3786 = new1534_3780;
									       }
									       arg2504_2206 = res2711_3786;
									    }
									 }
									 {
									    obj_t arg2518_2217;
									    {
									       obj_t list2519_2218;
									       {
										  obj_t aux_5932;
										  aux_5932 = (obj_t) (vcop_2169);
										  list2519_2218 = MAKE_PAIR(aux_5932, BNIL);
									       }
									       arg2518_2217 = list2519_2218;
									    }
									    {
									       csequence_t res2712_3798;
									       {
										  obj_t loc_3788;
										  loc_3788 = BFALSE;
										  {
										     csequence_t new1501_3791;
										     new1501_3791 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
										     {
											long arg1972_3792;
											arg1972_3792 = class_num_218___object(csequence_cgen_cop);
											{
											   obj_t obj_3796;
											   obj_3796 = (obj_t) (new1501_3791);
											   (((obj_t) CREF(obj_3796))->header = MAKE_HEADER(arg1972_3792, 0), BUNSPEC);
											}
										     }
										     {
											object_t aux_5939;
											aux_5939 = (object_t) (new1501_3791);
											OBJECT_WIDENING_SET(aux_5939, loc_3788);
										     }
										     ((((csequence_t) CREF(new1501_3791))->loc) = ((obj_t) loc_3788), BUNSPEC);
										     ((((csequence_t) CREF(new1501_3791))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
										     ((((csequence_t) CREF(new1501_3791))->cops) = ((obj_t) arg2518_2217), BUNSPEC);
										     res2712_3798 = new1501_3791;
										  }
									       }
									       arg2506_2207 = res2712_3798;
									    }
									 }
									 {
									    cjump_ex_it_131_t arg2522_2220;
									    {
									       obj_t arg2523_2221;
									       cop_t arg2524_2222;
									       varc_t arg2525_2223;
									       arg2523_2221 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									       {
										  csetq_t obj_3800;
										  obj_3800 = (csetq_t) (ecop_2172);
										  arg2524_2222 = (((csetq_t) CREF(obj_3800))->value);
									       }
									       {
										  varc_t res2713_3809;
										  {
										     obj_t loc_3801;
										     variable_t variable_3802;
										     loc_3801 = BFALSE;
										     variable_3802 = (variable_t) (vaux_2168);
										     {
											varc_t new1481_3803;
											new1481_3803 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
											{
											   long arg1979_3804;
											   arg1979_3804 = class_num_218___object(varc_cgen_cop);
											   {
											      obj_t obj_3807;
											      obj_3807 = (obj_t) (new1481_3803);
											      (((obj_t) CREF(obj_3807))->header = MAKE_HEADER(arg1979_3804, 0), BUNSPEC);
											   }
											}
											{
											   object_t aux_5953;
											   aux_5953 = (object_t) (new1481_3803);
											   OBJECT_WIDENING_SET(aux_5953, loc_3801);
											}
											((((varc_t) CREF(new1481_3803))->loc) = ((obj_t) loc_3801), BUNSPEC);
											((((varc_t) CREF(new1481_3803))->variable) = ((variable_t) variable_3802), BUNSPEC);
											res2713_3809 = new1481_3803;
										     }
										  }
										  arg2525_2223 = res2713_3809;
									       }
									       {
										  cjump_ex_it_131_t res2714_3820;
										  {
										     cop_t value_3812;
										     value_3812 = (cop_t) (arg2525_2223);
										     {
											cjump_ex_it_131_t new1604_3813;
											new1604_3813 = ((cjump_ex_it_131_t) BREF(GC_MALLOC(sizeof(struct cjump_ex_it_131))));
											{
											   long arg1937_3814;
											   arg1937_3814 = class_num_218___object(cjump_ex_it_131_cgen_cop);
											   {
											      obj_t obj_3818;
											      obj_3818 = (obj_t) (new1604_3813);
											      (((obj_t) CREF(obj_3818))->header = MAKE_HEADER(arg1937_3814, 0), BUNSPEC);
											   }
											}
											{
											   object_t aux_5963;
											   aux_5963 = (object_t) (new1604_3813);
											   OBJECT_WIDENING_SET(aux_5963, BFALSE);
											}
											((((cjump_ex_it_131_t) CREF(new1604_3813))->loc) = ((obj_t) arg2523_2221), BUNSPEC);
											((((cjump_ex_it_131_t) CREF(new1604_3813))->exit) = ((cop_t) arg2524_2222), BUNSPEC);
											((((cjump_ex_it_131_t) CREF(new1604_3813))->value) = ((cop_t) value_3812), BUNSPEC);
											res2714_3820 = new1604_3813;
										     }
										  }
										  arg2522_2220 = res2714_3820;
									       }
									    }
									    arg2507_2208 = arg2522_2220;
									 }
									 {
									    obj_t list2508_2209;
									    {
									       obj_t arg2509_2210;
									       {
										  obj_t arg2511_2211;
										  {
										     obj_t aux_5969;
										     aux_5969 = (obj_t) (arg2507_2208);
										     arg2511_2211 = MAKE_PAIR(aux_5969, BNIL);
										  }
										  {
										     obj_t aux_5972;
										     aux_5972 = (obj_t) (arg2506_2207);
										     arg2509_2210 = MAKE_PAIR(aux_5972, arg2511_2211);
										  }
									       }
									       {
										  obj_t aux_5975;
										  aux_5975 = (obj_t) (arg2504_2206);
										  list2508_2209 = MAKE_PAIR(aux_5975, arg2509_2210);
									       }
									    }
									    arg2503_2205 = list2508_2209;
									 }
								      }
								      {
									 csequence_t res2715_3833;
									 {
									    obj_t loc_3823;
									    loc_3823 = BFALSE;
									    {
									       csequence_t new1501_3826;
									       new1501_3826 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
									       {
										  long arg1972_3827;
										  arg1972_3827 = class_num_218___object(csequence_cgen_cop);
										  {
										     obj_t obj_3831;
										     obj_3831 = (obj_t) (new1501_3826);
										     (((obj_t) CREF(obj_3831))->header = MAKE_HEADER(arg1972_3827, 0), BUNSPEC);
										  }
									       }
									       {
										  object_t aux_5982;
										  aux_5982 = (object_t) (new1501_3826);
										  OBJECT_WIDENING_SET(aux_5982, loc_3823);
									       }
									       ((((csequence_t) CREF(new1501_3826))->loc) = ((obj_t) loc_3823), BUNSPEC);
									       ((((csequence_t) CREF(new1501_3826))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
									       ((((csequence_t) CREF(new1501_3826))->cops) = ((obj_t) arg2503_2205), BUNSPEC);
									       res2715_3833 = new1501_3826;
									    }
									 }
									 arg2502_2204 = res2715_3833;
								      }
								   }
								   {
								      block_t res2716_3842;
								      {
									 cop_t body_3835;
									 body_3835 = (cop_t) (arg2502_2204);
									 {
									    block_t new1457_3836;
									    new1457_3836 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
									    {
									       long arg1987_3837;
									       arg1987_3837 = class_num_218___object(block_cgen_cop);
									       {
										  obj_t obj_3840;
										  obj_3840 = (obj_t) (new1457_3836);
										  (((obj_t) CREF(obj_3840))->header = MAKE_HEADER(arg1987_3837, 0), BUNSPEC);
									       }
									    }
									    {
									       object_t aux_5993;
									       aux_5993 = (object_t) (new1457_3836);
									       OBJECT_WIDENING_SET(aux_5993, BFALSE);
									    }
									    ((((block_t) CREF(new1457_3836))->loc) = ((obj_t) arg2501_2203), BUNSPEC);
									    ((((block_t) CREF(new1457_3836))->body) = ((cop_t) body_3835), BUNSPEC);
									    res2716_3842 = new1457_3836;
									 }
								      }
								      aux_4563 = (obj_t) (res2716_3842);
								   }
								}
							     }
							   else
							     {
								{
								   obj_t arg2527_2225;
								   csequence_t arg2528_2226;
								   arg2527_2225 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
								   {
								      obj_t arg2529_2227;
								      {
									 local_var_164_t arg2530_2228;
									 csequence_t arg2531_2229;
									 cjump_ex_it_131_t arg2532_2230;
									 {
									    obj_t arg2537_2235;
									    obj_t arg2538_2236;
									    arg2537_2235 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									    {
									       obj_t list2539_2237;
									       {
										  obj_t arg2540_2238;
										  {
										     obj_t aux_6001;
										     aux_6001 = (obj_t) (vaux_2168);
										     arg2540_2238 = MAKE_PAIR(aux_6001, BNIL);
										  }
										  {
										     obj_t aux_6004;
										     aux_6004 = (obj_t) (eaux_2171);
										     list2539_2237 = MAKE_PAIR(aux_6004, arg2540_2238);
										  }
									       }
									       arg2538_2236 = list2539_2237;
									    }
									    {
									       local_var_164_t res2717_3854;
									       {
										  local_var_164_t new1534_3848;
										  new1534_3848 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
										  {
										     long arg1959_3849;
										     arg1959_3849 = class_num_218___object(local_var_164_cgen_cop);
										     {
											obj_t obj_3852;
											obj_3852 = (obj_t) (new1534_3848);
											(((obj_t) CREF(obj_3852))->header = MAKE_HEADER(arg1959_3849, 0), BUNSPEC);
										     }
										  }
										  {
										     object_t aux_6011;
										     aux_6011 = (object_t) (new1534_3848);
										     OBJECT_WIDENING_SET(aux_6011, BFALSE);
										  }
										  ((((local_var_164_t) CREF(new1534_3848))->loc) = ((obj_t) arg2537_2235), BUNSPEC);
										  ((((local_var_164_t) CREF(new1534_3848))->vars) = ((obj_t) arg2538_2236), BUNSPEC);
										  res2717_3854 = new1534_3848;
									       }
									       arg2530_2228 = res2717_3854;
									    }
									 }
									 {
									    obj_t arg2542_2240;
									    obj_t arg2543_2241;
									    arg2542_2240 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									    {
									       obj_t list2544_2242;
									       {
										  obj_t arg2545_2243;
										  {
										     obj_t aux_6017;
										     aux_6017 = (obj_t) (vcop_2169);
										     arg2545_2243 = MAKE_PAIR(aux_6017, BNIL);
										  }
										  {
										     obj_t aux_6020;
										     aux_6020 = (obj_t) (ecop_2172);
										     list2544_2242 = MAKE_PAIR(aux_6020, arg2545_2243);
										  }
									       }
									       arg2543_2241 = list2544_2242;
									    }
									    {
									       csequence_t res2718_3867;
									       {
										  csequence_t new1501_3860;
										  new1501_3860 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
										  {
										     long arg1972_3861;
										     arg1972_3861 = class_num_218___object(csequence_cgen_cop);
										     {
											obj_t obj_3865;
											obj_3865 = (obj_t) (new1501_3860);
											(((obj_t) CREF(obj_3865))->header = MAKE_HEADER(arg1972_3861, 0), BUNSPEC);
										     }
										  }
										  {
										     object_t aux_6027;
										     aux_6027 = (object_t) (new1501_3860);
										     OBJECT_WIDENING_SET(aux_6027, BFALSE);
										  }
										  ((((csequence_t) CREF(new1501_3860))->loc) = ((obj_t) arg2542_2240), BUNSPEC);
										  ((((csequence_t) CREF(new1501_3860))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
										  ((((csequence_t) CREF(new1501_3860))->cops) = ((obj_t) arg2543_2241), BUNSPEC);
										  res2718_3867 = new1501_3860;
									       }
									       arg2531_2229 = res2718_3867;
									    }
									 }
									 {
									    cjump_ex_it_131_t arg2547_2245;
									    {
									       obj_t arg2548_2246;
									       varc_t arg2550_2247;
									       varc_t arg2551_2248;
									       arg2548_2246 = (((jump_ex_it_184_t) CREF(node_2165))->loc);
									       {
										  varc_t res2719_3877;
										  {
										     obj_t loc_3869;
										     variable_t variable_3870;
										     loc_3869 = BFALSE;
										     variable_3870 = (variable_t) (eaux_2171);
										     {
											varc_t new1481_3871;
											new1481_3871 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
											{
											   long arg1979_3872;
											   arg1979_3872 = class_num_218___object(varc_cgen_cop);
											   {
											      obj_t obj_3875;
											      obj_3875 = (obj_t) (new1481_3871);
											      (((obj_t) CREF(obj_3875))->header = MAKE_HEADER(arg1979_3872, 0), BUNSPEC);
											   }
											}
											{
											   object_t aux_6039;
											   aux_6039 = (object_t) (new1481_3871);
											   OBJECT_WIDENING_SET(aux_6039, loc_3869);
											}
											((((varc_t) CREF(new1481_3871))->loc) = ((obj_t) loc_3869), BUNSPEC);
											((((varc_t) CREF(new1481_3871))->variable) = ((variable_t) variable_3870), BUNSPEC);
											res2719_3877 = new1481_3871;
										     }
										  }
										  arg2550_2247 = res2719_3877;
									       }
									       {
										  varc_t res2720_3886;
										  {
										     obj_t loc_3878;
										     variable_t variable_3879;
										     loc_3878 = BFALSE;
										     variable_3879 = (variable_t) (vaux_2168);
										     {
											varc_t new1481_3880;
											new1481_3880 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
											{
											   long arg1979_3881;
											   arg1979_3881 = class_num_218___object(varc_cgen_cop);
											   {
											      obj_t obj_3884;
											      obj_3884 = (obj_t) (new1481_3880);
											      (((obj_t) CREF(obj_3884))->header = MAKE_HEADER(arg1979_3881, 0), BUNSPEC);
											   }
											}
											{
											   object_t aux_6049;
											   aux_6049 = (object_t) (new1481_3880);
											   OBJECT_WIDENING_SET(aux_6049, loc_3878);
											}
											((((varc_t) CREF(new1481_3880))->loc) = ((obj_t) loc_3878), BUNSPEC);
											((((varc_t) CREF(new1481_3880))->variable) = ((variable_t) variable_3879), BUNSPEC);
											res2720_3886 = new1481_3880;
										     }
										  }
										  arg2551_2248 = res2720_3886;
									       }
									       {
										  cjump_ex_it_131_t res2721_3897;
										  {
										     cop_t exit_3888;
										     cop_t value_3889;
										     exit_3888 = (cop_t) (arg2550_2247);
										     value_3889 = (cop_t) (arg2551_2248);
										     {
											cjump_ex_it_131_t new1604_3890;
											new1604_3890 = ((cjump_ex_it_131_t) BREF(GC_MALLOC(sizeof(struct cjump_ex_it_131))));
											{
											   long arg1937_3891;
											   arg1937_3891 = class_num_218___object(cjump_ex_it_131_cgen_cop);
											   {
											      obj_t obj_3895;
											      obj_3895 = (obj_t) (new1604_3890);
											      (((obj_t) CREF(obj_3895))->header = MAKE_HEADER(arg1937_3891, 0), BUNSPEC);
											   }
											}
											{
											   object_t aux_6060;
											   aux_6060 = (object_t) (new1604_3890);
											   OBJECT_WIDENING_SET(aux_6060, BFALSE);
											}
											((((cjump_ex_it_131_t) CREF(new1604_3890))->loc) = ((obj_t) arg2548_2246), BUNSPEC);
											((((cjump_ex_it_131_t) CREF(new1604_3890))->exit) = ((cop_t) exit_3888), BUNSPEC);
											((((cjump_ex_it_131_t) CREF(new1604_3890))->value) = ((cop_t) value_3889), BUNSPEC);
											res2721_3897 = new1604_3890;
										     }
										  }
										  arg2547_2245 = res2721_3897;
									       }
									    }
									    arg2532_2230 = arg2547_2245;
									 }
									 {
									    obj_t list2533_2231;
									    {
									       obj_t arg2534_2232;
									       {
										  obj_t arg2535_2233;
										  {
										     obj_t aux_6066;
										     aux_6066 = (obj_t) (arg2532_2230);
										     arg2535_2233 = MAKE_PAIR(aux_6066, BNIL);
										  }
										  {
										     obj_t aux_6069;
										     aux_6069 = (obj_t) (arg2531_2229);
										     arg2534_2232 = MAKE_PAIR(aux_6069, arg2535_2233);
										  }
									       }
									       {
										  obj_t aux_6072;
										  aux_6072 = (obj_t) (arg2530_2228);
										  list2533_2231 = MAKE_PAIR(aux_6072, arg2534_2232);
									       }
									    }
									    arg2529_2227 = list2533_2231;
									 }
								      }
								      {
									 csequence_t res2722_3910;
									 {
									    obj_t loc_3900;
									    loc_3900 = BFALSE;
									    {
									       csequence_t new1501_3903;
									       new1501_3903 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
									       {
										  long arg1972_3904;
										  arg1972_3904 = class_num_218___object(csequence_cgen_cop);
										  {
										     obj_t obj_3908;
										     obj_3908 = (obj_t) (new1501_3903);
										     (((obj_t) CREF(obj_3908))->header = MAKE_HEADER(arg1972_3904, 0), BUNSPEC);
										  }
									       }
									       {
										  object_t aux_6079;
										  aux_6079 = (object_t) (new1501_3903);
										  OBJECT_WIDENING_SET(aux_6079, loc_3900);
									       }
									       ((((csequence_t) CREF(new1501_3903))->loc) = ((obj_t) loc_3900), BUNSPEC);
									       ((((csequence_t) CREF(new1501_3903))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
									       ((((csequence_t) CREF(new1501_3903))->cops) = ((obj_t) arg2529_2227), BUNSPEC);
									       res2722_3910 = new1501_3903;
									    }
									 }
									 arg2528_2226 = res2722_3910;
								      }
								   }
								   {
								      block_t res2723_3919;
								      {
									 cop_t body_3912;
									 body_3912 = (cop_t) (arg2528_2226);
									 {
									    block_t new1457_3913;
									    new1457_3913 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
									    {
									       long arg1987_3914;
									       arg1987_3914 = class_num_218___object(block_cgen_cop);
									       {
										  obj_t obj_3917;
										  obj_3917 = (obj_t) (new1457_3913);
										  (((obj_t) CREF(obj_3917))->header = MAKE_HEADER(arg1987_3914, 0), BUNSPEC);
									       }
									    }
									    {
									       object_t aux_6090;
									       aux_6090 = (object_t) (new1457_3913);
									       OBJECT_WIDENING_SET(aux_6090, BFALSE);
									    }
									    ((((block_t) CREF(new1457_3913))->loc) = ((obj_t) arg2527_2225), BUNSPEC);
									    ((((block_t) CREF(new1457_3913))->body) = ((cop_t) body_3912), BUNSPEC);
									    res2723_3919 = new1457_3913;
									 }
								      }
								      aux_4563 = (obj_t) (res2723_3919);
								   }
								}
							     }
							}
						   }
					      }
					   }
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 15):
			 {
			    make_box_202_t node_2269;
			    node_2269 = (make_box_202_t) (node_26);
			    {
			       bool_t test2576_2272;
			       {
				  bool_t test2606_2304;
				  {
				     obj_t aux_6097;
				     {
					node_t aux_6098;
					aux_6098 = (((make_box_202_t) CREF(node_2269))->value);
					aux_6097 = (obj_t) (aux_6098);
				     }
				     test2606_2304 = is_a__118___object(aux_6097, var_ast_node);
				  }
				  if (test2606_2304)
				    {
				       test2576_2272 = ((bool_t) 1);
				    }
				  else
				    {
				       bool_t test2607_2305;
				       {
					  obj_t aux_6103;
					  {
					     node_t aux_6104;
					     aux_6104 = (((make_box_202_t) CREF(node_2269))->value);
					     aux_6103 = (obj_t) (aux_6104);
					  }
					  test2607_2305 = is_a__118___object(aux_6103, atom_ast_node);
				       }
				       if (test2607_2305)
					 {
					    test2576_2272 = ((bool_t) 1);
					 }
				       else
					 {
					    obj_t aux_6109;
					    {
					       node_t aux_6110;
					       aux_6110 = (((make_box_202_t) CREF(node_2269))->value);
					       aux_6109 = (obj_t) (aux_6110);
					    }
					    test2576_2272 = is_a__118___object(aux_6109, kwote_ast_node);
					 }
				    }
			       }
			       if (test2576_2272)
				 {
				    node_t arg2577_2273;
				    arg2577_2273 = (((make_box_202_t) CREF(node_2269))->value);
				    {
				       obj_t arg2578_4075;
				       arg2578_4075 = make_fx_procedure(arg2578_cgen_cgen, ((long) 1), ((long) 2));
				       {
					  obj_t aux_6117;
					  aux_6117 = (obj_t) (node_2269);
					  PROCEDURE_SET(arg2578_4075, ((long) 0), aux_6117);
				       }
				       PROCEDURE_SET(arg2578_4075, ((long) 1), kont_27);
				       {
					  cop_t aux_6121;
					  aux_6121 = node__cop_142_cgen_cgen(arg2577_2273, arg2578_4075);
					  aux_4563 = (obj_t) (aux_6121);
				       }
				    }
				 }
			       else
				 {
				    local_t aux_2281;
				    aux_2281 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 4)), (type_t) (_obj__252_type_cache));
				    {
				       cop_t cval_2282;
				       {
					  setq_t arg2602_2301;
					  arg2602_2301 = node_setq_243_cgen_cgen((variable_t) (aux_2281), (((make_box_202_t) CREF(node_2269))->value));
					  cval_2282 = node__cop_142_cgen_cgen((node_t) (arg2602_2301), _id_kont__126_cgen_cgen);
				       }
				       {
					  {
					     obj_t arg2584_2283;
					     csequence_t arg2585_2284;
					     arg2584_2283 = (((make_box_202_t) CREF(node_2269))->loc);
					     {
						obj_t arg2586_2285;
						{
						   local_var_164_t arg2587_2286;
						   obj_t arg2588_2287;
						   {
						      obj_t arg2593_2292;
						      obj_t arg2594_2293;
						      arg2593_2292 = (((make_box_202_t) CREF(node_2269))->loc);
						      {
							 obj_t list2595_2294;
							 {
							    obj_t aux_6134;
							    aux_6134 = (obj_t) (aux_2281);
							    list2595_2294 = MAKE_PAIR(aux_6134, BNIL);
							 }
							 arg2594_2293 = list2595_2294;
						      }
						      {
							 local_var_164_t res2725_3949;
							 {
							    local_var_164_t new1534_3943;
							    new1534_3943 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							    {
							       long arg1959_3944;
							       arg1959_3944 = class_num_218___object(local_var_164_cgen_cop);
							       {
								  obj_t obj_3947;
								  obj_3947 = (obj_t) (new1534_3943);
								  (((obj_t) CREF(obj_3947))->header = MAKE_HEADER(arg1959_3944, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_6141;
							       aux_6141 = (object_t) (new1534_3943);
							       OBJECT_WIDENING_SET(aux_6141, BFALSE);
							    }
							    ((((local_var_164_t) CREF(new1534_3943))->loc) = ((obj_t) arg2593_2292), BUNSPEC);
							    ((((local_var_164_t) CREF(new1534_3943))->vars) = ((obj_t) arg2594_2293), BUNSPEC);
							    res2725_3949 = new1534_3943;
							 }
							 arg2587_2286 = res2725_3949;
						      }
						   }
						   {
						      cmake_box_177_t arg2597_2296;
						      {
							 obj_t arg2598_2297;
							 varc_t arg2599_2298;
							 arg2598_2297 = (((make_box_202_t) CREF(node_2269))->loc);
							 {
							    obj_t arg2600_2299;
							    arg2600_2299 = (((make_box_202_t) CREF(node_2269))->loc);
							    {
							       varc_t res2726_3960;
							       {
								  variable_t variable_3953;
								  variable_3953 = (variable_t) (aux_2281);
								  {
								     varc_t new1481_3954;
								     new1481_3954 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								     {
									long arg1979_3955;
									arg1979_3955 = class_num_218___object(varc_cgen_cop);
									{
									   obj_t obj_3958;
									   obj_3958 = (obj_t) (new1481_3954);
									   (((obj_t) CREF(obj_3958))->header = MAKE_HEADER(arg1979_3955, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_6153;
									aux_6153 = (object_t) (new1481_3954);
									OBJECT_WIDENING_SET(aux_6153, BFALSE);
								     }
								     ((((varc_t) CREF(new1481_3954))->loc) = ((obj_t) arg2600_2299), BUNSPEC);
								     ((((varc_t) CREF(new1481_3954))->variable) = ((variable_t) variable_3953), BUNSPEC);
								     res2726_3960 = new1481_3954;
								  }
							       }
							       arg2599_2298 = res2726_3960;
							    }
							 }
							 {
							    cmake_box_177_t res2727_3969;
							    {
							       cop_t value_3962;
							       value_3962 = (cop_t) (arg2599_2298);
							       {
								  cmake_box_177_t new1577_3963;
								  new1577_3963 = ((cmake_box_177_t) BREF(GC_MALLOC(sizeof(struct cmake_box_177))));
								  {
								     long arg1945_3964;
								     arg1945_3964 = class_num_218___object(cmake_box_177_cgen_cop);
								     {
									obj_t obj_3967;
									obj_3967 = (obj_t) (new1577_3963);
									(((obj_t) CREF(obj_3967))->header = MAKE_HEADER(arg1945_3964, 0), BUNSPEC);
								     }
								  }
								  {
								     object_t aux_6163;
								     aux_6163 = (object_t) (new1577_3963);
								     OBJECT_WIDENING_SET(aux_6163, BFALSE);
								  }
								  ((((cmake_box_177_t) CREF(new1577_3963))->loc) = ((obj_t) arg2598_2297), BUNSPEC);
								  ((((cmake_box_177_t) CREF(new1577_3963))->value) = ((cop_t) value_3962), BUNSPEC);
								  res2727_3969 = new1577_3963;
							       }
							    }
							    arg2597_2296 = res2727_3969;
							 }
						      }
						      arg2588_2287 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2597_2296), BEOA);
						   }
						   {
						      obj_t list2589_2288;
						      {
							 obj_t arg2590_2289;
							 {
							    obj_t arg2591_2290;
							    arg2591_2290 = MAKE_PAIR(arg2588_2287, BNIL);
							    {
							       obj_t aux_6172;
							       aux_6172 = (obj_t) (cval_2282);
							       arg2590_2289 = MAKE_PAIR(aux_6172, arg2591_2290);
							    }
							 }
							 {
							    obj_t aux_6175;
							    aux_6175 = (obj_t) (arg2587_2286);
							    list2589_2288 = MAKE_PAIR(aux_6175, arg2590_2289);
							 }
						      }
						      arg2586_2285 = list2589_2288;
						   }
						}
						{
						   csequence_t res2728_3981;
						   {
						      obj_t loc_3971;
						      loc_3971 = BFALSE;
						      {
							 csequence_t new1501_3974;
							 new1501_3974 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							 {
							    long arg1972_3975;
							    arg1972_3975 = class_num_218___object(csequence_cgen_cop);
							    {
							       obj_t obj_3979;
							       obj_3979 = (obj_t) (new1501_3974);
							       (((obj_t) CREF(obj_3979))->header = MAKE_HEADER(arg1972_3975, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_6182;
							    aux_6182 = (object_t) (new1501_3974);
							    OBJECT_WIDENING_SET(aux_6182, loc_3971);
							 }
							 ((((csequence_t) CREF(new1501_3974))->loc) = ((obj_t) loc_3971), BUNSPEC);
							 ((((csequence_t) CREF(new1501_3974))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							 ((((csequence_t) CREF(new1501_3974))->cops) = ((obj_t) arg2586_2285), BUNSPEC);
							 res2728_3981 = new1501_3974;
						      }
						   }
						   arg2585_2284 = res2728_3981;
						}
					     }
					     {
						block_t res2729_3990;
						{
						   cop_t body_3983;
						   body_3983 = (cop_t) (arg2585_2284);
						   {
						      block_t new1457_3984;
						      new1457_3984 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						      {
							 long arg1987_3985;
							 arg1987_3985 = class_num_218___object(block_cgen_cop);
							 {
							    obj_t obj_3988;
							    obj_3988 = (obj_t) (new1457_3984);
							    (((obj_t) CREF(obj_3988))->header = MAKE_HEADER(arg1987_3985, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_6193;
							 aux_6193 = (object_t) (new1457_3984);
							 OBJECT_WIDENING_SET(aux_6193, BFALSE);
						      }
						      ((((block_t) CREF(new1457_3984))->loc) = ((obj_t) arg2584_2283), BUNSPEC);
						      ((((block_t) CREF(new1457_3984))->body) = ((cop_t) body_3983), BUNSPEC);
						      res2729_3990 = new1457_3984;
						   }
						}
						aux_4563 = (obj_t) (res2729_3990);
					     }
					  }
				       }
				    }
				 }
			    }
			 }
			 break;
		      case ((long) 16):
			 {
			    box_ref_242_t node_2309;
			    node_2309 = (box_ref_242_t) (node_26);
			    {
			       cop_t arg2611_2312;
			       {
				  var_t arg2612_2313;
				  arg2612_2313 = (((box_ref_242_t) CREF(node_2309))->var);
				  {
				     obj_t arg2613_4074;
				     arg2613_4074 = make_fx_procedure(arg2613_cgen_cgen, ((long) 1), ((long) 1));
				     {
					obj_t aux_6202;
					aux_6202 = (obj_t) (node_2309);
					PROCEDURE_SET(arg2613_4074, ((long) 0), aux_6202);
				     }
				     arg2611_2312 = node__cop_142_cgen_cgen((node_t) (arg2612_2313), arg2613_4074);
				  }
			       }
			       aux_4563 = PROCEDURE_ENTRY(kont_27) (kont_27, (obj_t) (arg2611_2312), BEOA);
			    }
			 }
			 break;
		      case ((long) 17):
			 {
			    box_set__221_t node_2320;
			    node_2320 = (box_set__221_t) (node_26);
			    {
			       variable_t v_2323;
			       {
				  var_t arg2626_2335;
				  arg2626_2335 = (((box_set__221_t) CREF(node_2320))->var);
				  v_2323 = (((var_t) CREF(arg2626_2335))->variable);
			       }
			       {
				  node_t arg2617_2324;
				  arg2617_2324 = (((box_set__221_t) CREF(node_2320))->value);
				  {
				     obj_t arg2618_4073;
				     arg2618_4073 = make_fx_procedure(arg2618_cgen_cgen, ((long) 1), ((long) 3));
				     {
					obj_t aux_6215;
					aux_6215 = (obj_t) (node_2320);
					PROCEDURE_SET(arg2618_4073, ((long) 0), aux_6215);
				     }
				     {
					obj_t aux_6218;
					aux_6218 = (obj_t) (v_2323);
					PROCEDURE_SET(arg2618_4073, ((long) 1), aux_6218);
				     }
				     PROCEDURE_SET(arg2618_4073, ((long) 2), kont_27);
				     {
					cop_t aux_6222;
					aux_6222 = node__cop_142_cgen_cgen(arg2617_2324, arg2618_4073);
					aux_4563 = (obj_t) (aux_6222);
				     }
				  }
			       }
			    }
			 }
			 break;
		      default:
		       case_else2083_1721:
			 if (PROCEDUREP(method2077_1717))
			   {
			      aux_4563 = PROCEDURE_ENTRY(method2077_1717) (method2077_1717, (obj_t) (node_26), kont_27, BEOA);
			   }
			 else
			   {
			      obj_t fun2074_1711;
			      fun2074_1711 = PROCEDURE_REF(node__cop_env_160_cgen_cgen, ((long) 0));
			      aux_4563 = PROCEDURE_ENTRY(fun2074_1711) (fun2074_1711, (obj_t) (node_26), kont_27, BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else2083_1721;
		 }
	    }
	    return (cop_t) (aux_4563);
	 }
      }
   }
}


/* _node->cop */ obj_t 
_node__cop_12_cgen_cgen(obj_t env_4067, obj_t node_4068, obj_t kont_4069)
{
   {
      cop_t aux_6237;
      aux_6237 = node__cop_142_cgen_cgen((node_t) (node_4068), kont_4069);
      return (obj_t) (aux_6237);
   }
}


/* arg2618 */ obj_t 
arg2618_cgen_cgen(obj_t env_4076, obj_t vl_4080)
{
   {
      obj_t instance1760_4077;
      obj_t v_4078;
      obj_t kont_4079;
      instance1760_4077 = PROCEDURE_REF(env_4076, ((long) 0));
      v_4078 = PROCEDURE_REF(env_4076, ((long) 1));
      kont_4079 = PROCEDURE_REF(env_4076, ((long) 2));
      {
	 obj_t vl_2326;
	 vl_2326 = vl_4080;
	 {
	    cbox_set__132_t arg2620_2328;
	    {
	       obj_t arg2621_2329;
	       varc_t arg2622_2330;
	       {
		  box_set__221_t obj_4007;
		  obj_4007 = (box_set__221_t) (instance1760_4077);
		  arg2621_2329 = (((box_set__221_t) CREF(obj_4007))->loc);
	       }
	       {
		  obj_t arg2624_2332;
		  {
		     box_set__221_t obj_4008;
		     obj_4008 = (box_set__221_t) (instance1760_4077);
		     arg2624_2332 = (((box_set__221_t) CREF(obj_4008))->loc);
		  }
		  {
		     varc_t res2731_4017;
		     {
			variable_t variable_4010;
			variable_4010 = (variable_t) (v_4078);
			{
			   varc_t new1481_4011;
			   new1481_4011 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
			   {
			      long arg1979_4012;
			      arg1979_4012 = class_num_218___object(varc_cgen_cop);
			      {
				 obj_t obj_4015;
				 obj_4015 = (obj_t) (new1481_4011);
				 (((obj_t) CREF(obj_4015))->header = MAKE_HEADER(arg1979_4012, 0), BUNSPEC);
			      }
			   }
			   {
			      object_t aux_6253;
			      aux_6253 = (object_t) (new1481_4011);
			      OBJECT_WIDENING_SET(aux_6253, BFALSE);
			   }
			   ((((varc_t) CREF(new1481_4011))->loc) = ((obj_t) arg2624_2332), BUNSPEC);
			   ((((varc_t) CREF(new1481_4011))->variable) = ((variable_t) variable_4010), BUNSPEC);
			   res2731_4017 = new1481_4011;
			}
		     }
		     arg2622_2330 = res2731_4017;
		  }
	       }
	       {
		  cbox_set__132_t res2732_4028;
		  {
		     cop_t var_4019;
		     cop_t value_4020;
		     var_4019 = (cop_t) (arg2622_2330);
		     value_4020 = (cop_t) (vl_2326);
		     {
			cbox_set__132_t new1589_4021;
			new1589_4021 = ((cbox_set__132_t) BREF(GC_MALLOC(sizeof(struct cbox_set__132))));
			{
			   long arg1941_4022;
			   arg1941_4022 = class_num_218___object(cbox_set__132_cgen_cop);
			   {
			      obj_t obj_4026;
			      obj_4026 = (obj_t) (new1589_4021);
			      (((obj_t) CREF(obj_4026))->header = MAKE_HEADER(arg1941_4022, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_6264;
			   aux_6264 = (object_t) (new1589_4021);
			   OBJECT_WIDENING_SET(aux_6264, BFALSE);
			}
			((((cbox_set__132_t) CREF(new1589_4021))->loc) = ((obj_t) arg2621_2329), BUNSPEC);
			((((cbox_set__132_t) CREF(new1589_4021))->var) = ((cop_t) var_4019), BUNSPEC);
			((((cbox_set__132_t) CREF(new1589_4021))->value) = ((cop_t) value_4020), BUNSPEC);
			res2732_4028 = new1589_4021;
		     }
		  }
		  arg2620_2328 = res2732_4028;
	       }
	    }
	    return PROCEDURE_ENTRY(kont_4079) (kont_4079, (obj_t) (arg2620_2328), BEOA);
	 }
      }
   }
}


/* arg2613 */ obj_t 
arg2613_cgen_cgen(obj_t env_4081, obj_t v_4083)
{
   {
      obj_t instance1758_4082;
      instance1758_4082 = PROCEDURE_REF(env_4081, ((long) 0));
      {
	 obj_t v_2315;
	 {
	    cbox_ref_44_t aux_6274;
	    v_2315 = v_4083;
	    {
	       obj_t arg2615_3992;
	       {
		  box_ref_242_t obj_3994;
		  obj_3994 = (box_ref_242_t) (instance1758_4082);
		  arg2615_3992 = (((box_ref_242_t) CREF(obj_3994))->loc);
	       }
	       {
		  cbox_ref_44_t res2730_4003;
		  {
		     cop_t var_3996;
		     var_3996 = (cop_t) (v_2315);
		     {
			cbox_ref_44_t new1583_3997;
			new1583_3997 = ((cbox_ref_44_t) BREF(GC_MALLOC(sizeof(struct cbox_ref_44))));
			{
			   long arg1943_3998;
			   arg1943_3998 = class_num_218___object(cbox_ref_44_cgen_cop);
			   {
			      obj_t obj_4001;
			      obj_4001 = (obj_t) (new1583_3997);
			      (((obj_t) CREF(obj_4001))->header = MAKE_HEADER(arg1943_3998, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_6282;
			   aux_6282 = (object_t) (new1583_3997);
			   OBJECT_WIDENING_SET(aux_6282, BFALSE);
			}
			((((cbox_ref_44_t) CREF(new1583_3997))->loc) = ((obj_t) arg2615_3992), BUNSPEC);
			((((cbox_ref_44_t) CREF(new1583_3997))->var) = ((cop_t) var_3996), BUNSPEC);
			res2730_4003 = new1583_3997;
		     }
		  }
		  aux_6274 = res2730_4003;
	       }
	    }
	    return (obj_t) (aux_6274);
	 }
      }
   }
}


/* arg2578 */ obj_t 
arg2578_cgen_cgen(obj_t env_4084, obj_t v_4087)
{
   {
      obj_t instance1751_4085;
      obj_t kont_4086;
      instance1751_4085 = PROCEDURE_REF(env_4084, ((long) 0));
      kont_4086 = PROCEDURE_REF(env_4084, ((long) 1));
      {
	 obj_t v_2275;
	 v_2275 = v_4087;
	 {
	    cmake_box_177_t arg2580_2277;
	    {
	       obj_t arg2582_2278;
	       {
		  make_box_202_t obj_3927;
		  obj_3927 = (make_box_202_t) (instance1751_4085);
		  arg2582_2278 = (((make_box_202_t) CREF(obj_3927))->loc);
	       }
	       {
		  cmake_box_177_t res2724_3936;
		  {
		     cop_t value_3929;
		     value_3929 = (cop_t) (v_2275);
		     {
			cmake_box_177_t new1577_3930;
			new1577_3930 = ((cmake_box_177_t) BREF(GC_MALLOC(sizeof(struct cmake_box_177))));
			{
			   long arg1945_3931;
			   arg1945_3931 = class_num_218___object(cmake_box_177_cgen_cop);
			   {
			      obj_t obj_3934;
			      obj_3934 = (obj_t) (new1577_3930);
			      (((obj_t) CREF(obj_3934))->header = MAKE_HEADER(arg1945_3931, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_6297;
			   aux_6297 = (object_t) (new1577_3930);
			   OBJECT_WIDENING_SET(aux_6297, BFALSE);
			}
			((((cmake_box_177_t) CREF(new1577_3930))->loc) = ((obj_t) arg2582_2278), BUNSPEC);
			((((cmake_box_177_t) CREF(new1577_3930))->value) = ((cop_t) value_3929), BUNSPEC);
			res2724_3936 = new1577_3930;
		     }
		  }
		  arg2580_2277 = res2724_3936;
	       }
	    }
	    return PROCEDURE_ENTRY(kont_4086) (kont_4086, (obj_t) (arg2580_2277), BEOA);
	 }
      }
   }
}


/* node->cop-default1765 */ cop_t 
node__cop_default1765_254_cgen_cgen(node_t node_28, obj_t kont_29)
{
   FAILURE(CNST_TABLE_REF(((long) 5)), string2750_cgen_cgen, (obj_t) (node_28));
}


/* _node->cop-default1765 */ obj_t 
_node__cop_default1765_105_cgen_cgen(obj_t env_4070, obj_t node_4071, obj_t kont_4072)
{
   {
      cop_t aux_6308;
      aux_6308 = node__cop_default1765_254_cgen_cgen((node_t) (node_4071), kont_4072);
      return (obj_t) (aux_6308);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_cgen()
{
   module_initialization_70_tools_trace(((long) 0), "CGEN_CGEN");
   module_initialization_70_tools_error(((long) 0), "CGEN_CGEN");
   module_initialization_70_tools_shape(((long) 0), "CGEN_CGEN");
   module_initialization_70_engine_param(((long) 0), "CGEN_CGEN");
   module_initialization_70_type_type(((long) 0), "CGEN_CGEN");
   module_initialization_70_type_tools(((long) 0), "CGEN_CGEN");
   module_initialization_70_type_cache(((long) 0), "CGEN_CGEN");
   module_initialization_70_ast_var(((long) 0), "CGEN_CGEN");
   module_initialization_70_ast_node(((long) 0), "CGEN_CGEN");
   module_initialization_70_ast_local(((long) 0), "CGEN_CGEN");
   module_initialization_70_effect_effect(((long) 0), "CGEN_CGEN");
   module_initialization_70_coerce_typeof(((long) 0), "CGEN_CGEN");
   module_initialization_70_cgen_emit(((long) 0), "CGEN_CGEN");
   module_initialization_70_cgen_cop(((long) 0), "CGEN_CGEN");
   module_initialization_70_cgen_emit_cop_239(((long) 0), "CGEN_CGEN");
   module_initialization_70_cgen_prototype(((long) 0), "CGEN_CGEN");
   return module_initialization_70_cgen_capp(((long) 0), "CGEN_CGEN");
}
