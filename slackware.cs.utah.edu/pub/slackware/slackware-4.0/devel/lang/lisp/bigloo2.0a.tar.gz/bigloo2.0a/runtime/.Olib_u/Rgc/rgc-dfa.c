/*===========================================================================*/
/*   (Rgc/rgc-dfa.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern char * number__string_214___r4_numbers_6_5(obj_t, obj_t);
extern bool_t state__130___rgc_dfa(obj_t);
extern obj_t rgcset_add__25___rgc_set(obj_t, int);
extern obj_t string_to_symbol(char *);
extern obj_t for_each_hash_105___hash(obj_t, obj_t);
extern obj_t state_positions_249___rgc_dfa(obj_t);
static obj_t _state_num__111___rgc_dfa = BUNSPEC;
static obj_t symbol1291___rgc_dfa = BUNSPEC;
static obj_t symbol1290___rgc_dfa = BUNSPEC;
static obj_t symbol1288___rgc_dfa = BUNSPEC;
static obj_t symbol1286___rgc_dfa = BUNSPEC;
static obj_t symbol1280___rgc_dfa = BUNSPEC;
static obj_t symbol1278___rgc_dfa = BUNSPEC;
static obj_t symbol1276___rgc_dfa = BUNSPEC;
static obj_t symbol1273___rgc_dfa = BUNSPEC;
extern obj_t newline___r4_output_6_10_3(obj_t);
static obj_t symbol1271___rgc_dfa = BUNSPEC;
static obj_t symbol1268___rgc_dfa = BUNSPEC;
static obj_t symbol1266___rgc_dfa = BUNSPEC;
static obj_t symbol1264___rgc_dfa = BUNSPEC;
static obj_t symbol1262___rgc_dfa = BUNSPEC;
static obj_t symbol1259___rgc_dfa = BUNSPEC;
static obj_t symbol1256___rgc_dfa = BUNSPEC;
static obj_t symbol1254___rgc_dfa = BUNSPEC;
static obj_t symbol1252___rgc_dfa = BUNSPEC;
static obj_t symbol1250___rgc_dfa = BUNSPEC;
static obj_t symbol1243___rgc_dfa = BUNSPEC;
static obj_t list1289___rgc_dfa = BUNSPEC;
static obj_t list1287___rgc_dfa = BUNSPEC;
static obj_t list1285___rgc_dfa = BUNSPEC;
static obj_t list1279___rgc_dfa = BUNSPEC;
static obj_t list1277___rgc_dfa = BUNSPEC;
static obj_t list1275___rgc_dfa = BUNSPEC;
static obj_t list1274___rgc_dfa = BUNSPEC;
static obj_t list1272___rgc_dfa = BUNSPEC;
static obj_t list1269___rgc_dfa = BUNSPEC;
static obj_t list1270___rgc_dfa = BUNSPEC;
static obj_t list1267___rgc_dfa = BUNSPEC;
static obj_t list1265___rgc_dfa = BUNSPEC;
static obj_t list1263___rgc_dfa = BUNSPEC;
static obj_t list1261___rgc_dfa = BUNSPEC;
static obj_t list1258___rgc_dfa = BUNSPEC;
static obj_t list1255___rgc_dfa = BUNSPEC;
static obj_t list1253___rgc_dfa = BUNSPEC;
static obj_t list1251___rgc_dfa = BUNSPEC;
static obj_t list1249___rgc_dfa = BUNSPEC;
static obj_t toplevel_init_63___rgc_dfa();
static obj_t _state__64___rgc_dfa(obj_t, obj_t);
extern obj_t tree_max_char_216___rgc_rules();
static obj_t _state_name_187___rgc_dfa(obj_t, obj_t);
extern obj_t print___r4_output_6_10_3(obj_t);
extern int rgcset__hash_57___rgc_set(obj_t);
extern obj_t put_hash__129___hash(obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
static obj_t _initial_state__234___rgc_dfa = BUNSPEC;
extern obj_t string_to_bstring(char *);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t rgcset_or__64___rgc_set(obj_t, obj_t);
static obj_t ___state_position_set_19___rgc_dfa(obj_t, obj_t);
extern obj_t get_hash_29___hash(obj_t, obj_t);
static obj_t states_list_224___rgc_dfa();
static obj_t _state_positions_121___rgc_dfa(obj_t, obj_t);
static obj_t _node__dfa_101___rgc_dfa(obj_t, obj_t, obj_t, obj_t);
static obj_t _reset_dfa__181___rgc_dfa(obj_t);
static obj_t _state_transitions_12___rgc_dfa(obj_t, obj_t);
static obj_t _print_dfa_87___rgc_dfa(obj_t, obj_t);
extern obj_t module_initialization_70___rgc_dfa(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___rgc_config(long, char *);
extern obj_t module_initialization_70___rgc_set(long, char *);
extern obj_t module_initialization_70___rgc_rules(long, char *);
extern obj_t state_name_114___rgc_dfa(obj_t);
extern obj_t state_transitions_152___rgc_dfa(obj_t);
static obj_t arg1083___rgc_dfa(obj_t, obj_t);
static obj_t arg1060___rgc_dfa(obj_t, obj_t);
static obj_t arg1057___rgc_dfa(obj_t, obj_t);
static obj_t _rgcset_equal__209___rgc_set(obj_t, obj_t, obj_t);
static obj_t arg1032___rgc_dfa(obj_t, obj_t);
static obj_t arg1029___rgc_dfa(obj_t, obj_t);
extern obj_t make_hash_table_174___hash(long, obj_t, obj_t, obj_t, obj_t);
static obj_t _states__60___rgc_dfa = BUNSPEC;
extern obj_t node__dfa_130___rgc_dfa(obj_t, obj_t, obj_t);
extern obj_t print_dfa_47___rgc_dfa(obj_t);
extern obj_t for_each_rgcset_171___rgc_set(obj_t, obj_t);
static obj_t _get_initial_state_188___rgc_dfa(obj_t);
static obj_t init_states__107___rgc_dfa();
static obj_t imported_modules_init_94___rgc_dfa();
extern obj_t reset_dfa__30___rgc_dfa();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t require_initialization_114___rgc_dfa = BUNSPEC;
static obj_t make_state_230___rgc_dfa(obj_t);
extern obj_t make_rgcset_69___rgc_set(int);
extern obj_t get_initial_state_58___rgc_dfa();
static obj_t cnst_init_137___rgc_dfa();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( get_initial_state_env_81___rgc_dfa, _get_initial_state_188___rgc_dfa1294, _get_initial_state_188___rgc_dfa, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( state_transitions_env_114___rgc_dfa, _state_transitions_12___rgc_dfa1295, _state_transitions_12___rgc_dfa, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( node__dfa_env_120___rgc_dfa, _node__dfa_101___rgc_dfa1296, _node__dfa_101___rgc_dfa, 0L, 3 );
extern obj_t rgcset_equal__env_103___rgc_set;
DEFINE_EXPORT_PROCEDURE( print_dfa_env_61___rgc_dfa, _print_dfa_87___rgc_dfa1297, _print_dfa_87___rgc_dfa, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( reset_dfa__env_193___rgc_dfa, _reset_dfa__181___rgc_dfa1298, _reset_dfa__181___rgc_dfa, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( state_name_env_16___rgc_dfa, _state_name_187___rgc_dfa1299, _state_name_187___rgc_dfa, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( state_positions_env_215___rgc_dfa, _state_positions_121___rgc_dfa1300, _state_positions_121___rgc_dfa, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( state__env_120___rgc_dfa, _state__64___rgc_dfa1301, _state__64___rgc_dfa, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1244___rgc_dfa, arg1060___rgc_dfa1302, arg1060___rgc_dfa, 0L, 1 );
DEFINE_STATIC_PROCEDURE( __state_position_set_env_155___rgc_dfa, ___state_position_set_19___rgc_dfa1303, ___state_position_set_19___rgc_dfa, 0L, 1 );
DEFINE_STRING( string1292___rgc_dfa, string1292___rgc_dfa1304, "==================================================", 50 );
DEFINE_STRING( string1284___rgc_dfa, string1284___rgc_dfa1305, "  -->  ", 7 );
DEFINE_STRING( string1283___rgc_dfa, string1283___rgc_dfa1306, "]", 1 );
DEFINE_STRING( string1282___rgc_dfa, string1282___rgc_dfa1307, "special", 7 );
DEFINE_STRING( string1281___rgc_dfa, string1281___rgc_dfa1308, "ascii", 5 );
DEFINE_STRING( string1260___rgc_dfa, string1260___rgc_dfa1309, " [", 2 );
DEFINE_STRING( string1257___rgc_dfa, string1257___rgc_dfa1310, "   ", 3 );
DEFINE_STRING( string1248___rgc_dfa, string1248___rgc_dfa1311, "state: ", 7 );
DEFINE_STRING( string1247___rgc_dfa, string1247___rgc_dfa1312, "========= DFA ====================================", 50 );
DEFINE_STRING( string1246___rgc_dfa, string1246___rgc_dfa1313, "STATE-", 6 );
DEFINE_STRING( string1245___rgc_dfa, string1245___rgc_dfa1314, "-", 1 );


/* module-initialization */obj_t module_initialization_70___rgc_dfa(long checksum_887, char * from_888)
{
if(CBOOL(require_initialization_114___rgc_dfa)){
require_initialization_114___rgc_dfa = BBOOL(((bool_t)0));
cnst_init_137___rgc_dfa();
imported_modules_init_94___rgc_dfa();
toplevel_init_63___rgc_dfa();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc_dfa()
{
symbol1243___rgc_dfa = string_to_symbol("__STATE");
symbol1250___rgc_dfa = string_to_symbol("FOR-EACH");
symbol1252___rgc_dfa = string_to_symbol("LAMBDA");
symbol1254___rgc_dfa = string_to_symbol("TRANS");
list1253___rgc_dfa = MAKE_PAIR(symbol1254___rgc_dfa, BNIL);
symbol1256___rgc_dfa = string_to_symbol("PRINT");
symbol1259___rgc_dfa = string_to_symbol("CAR");
{
obj_t aux_902;
aux_902 = MAKE_PAIR(symbol1254___rgc_dfa, BNIL);
list1258___rgc_dfa = MAKE_PAIR(symbol1259___rgc_dfa, aux_902);
}
symbol1262___rgc_dfa = string_to_symbol("IF");
symbol1264___rgc_dfa = string_to_symbol("AND");
symbol1266___rgc_dfa = string_to_symbol("<");
{
obj_t aux_908;
{
obj_t aux_909;
{
obj_t aux_910;
aux_910 = BINT(((long)256));
aux_909 = MAKE_PAIR(aux_910, BNIL);
}
aux_908 = MAKE_PAIR(list1258___rgc_dfa, aux_909);
}
list1265___rgc_dfa = MAKE_PAIR(symbol1266___rgc_dfa, aux_908);
}
symbol1268___rgc_dfa = string_to_symbol("LET");
symbol1271___rgc_dfa = string_to_symbol("C");
symbol1273___rgc_dfa = string_to_symbol("INTEGER->CHAR");
{
obj_t aux_918;
aux_918 = MAKE_PAIR(list1258___rgc_dfa, BNIL);
list1272___rgc_dfa = MAKE_PAIR(symbol1273___rgc_dfa, aux_918);
}
{
obj_t aux_921;
aux_921 = MAKE_PAIR(list1272___rgc_dfa, BNIL);
list1270___rgc_dfa = MAKE_PAIR(symbol1271___rgc_dfa, aux_921);
}
list1269___rgc_dfa = MAKE_PAIR(list1270___rgc_dfa, BNIL);
symbol1276___rgc_dfa = string_to_symbol("OR");
symbol1278___rgc_dfa = string_to_symbol("CHAR-ALPHABETIC?");
{
obj_t aux_927;
aux_927 = MAKE_PAIR(symbol1271___rgc_dfa, BNIL);
list1277___rgc_dfa = MAKE_PAIR(symbol1278___rgc_dfa, aux_927);
}
symbol1280___rgc_dfa = string_to_symbol("CHAR-NUMERIC?");
{
obj_t aux_931;
aux_931 = MAKE_PAIR(symbol1271___rgc_dfa, BNIL);
list1279___rgc_dfa = MAKE_PAIR(symbol1280___rgc_dfa, aux_931);
}
{
obj_t aux_934;
{
obj_t aux_935;
aux_935 = MAKE_PAIR(list1279___rgc_dfa, BNIL);
aux_934 = MAKE_PAIR(list1277___rgc_dfa, aux_935);
}
list1275___rgc_dfa = MAKE_PAIR(symbol1276___rgc_dfa, aux_934);
}
{
obj_t aux_939;
{
obj_t aux_940;
{
obj_t aux_941;
aux_941 = MAKE_PAIR(string1281___rgc_dfa, BNIL);
aux_940 = MAKE_PAIR(symbol1271___rgc_dfa, aux_941);
}
aux_939 = MAKE_PAIR(list1275___rgc_dfa, aux_940);
}
list1274___rgc_dfa = MAKE_PAIR(symbol1262___rgc_dfa, aux_939);
}
{
obj_t aux_946;
{
obj_t aux_947;
aux_947 = MAKE_PAIR(list1274___rgc_dfa, BNIL);
aux_946 = MAKE_PAIR(list1269___rgc_dfa, aux_947);
}
list1267___rgc_dfa = MAKE_PAIR(symbol1268___rgc_dfa, aux_946);
}
{
obj_t aux_951;
{
obj_t aux_952;
aux_952 = MAKE_PAIR(list1267___rgc_dfa, BNIL);
aux_951 = MAKE_PAIR(list1265___rgc_dfa, aux_952);
}
list1263___rgc_dfa = MAKE_PAIR(symbol1264___rgc_dfa, aux_951);
}
{
obj_t aux_956;
{
obj_t aux_957;
aux_957 = MAKE_PAIR(string1282___rgc_dfa, BNIL);
aux_956 = MAKE_PAIR(list1263___rgc_dfa, aux_957);
}
list1261___rgc_dfa = MAKE_PAIR(symbol1262___rgc_dfa, aux_956);
}
symbol1286___rgc_dfa = string_to_symbol("__STATE-NUMBER");
symbol1288___rgc_dfa = string_to_symbol("CDR");
{
obj_t aux_963;
aux_963 = MAKE_PAIR(symbol1254___rgc_dfa, BNIL);
list1287___rgc_dfa = MAKE_PAIR(symbol1288___rgc_dfa, aux_963);
}
{
obj_t aux_966;
aux_966 = MAKE_PAIR(list1287___rgc_dfa, BNIL);
list1285___rgc_dfa = MAKE_PAIR(symbol1286___rgc_dfa, aux_966);
}
{
obj_t aux_969;
{
obj_t aux_970;
{
obj_t aux_971;
{
obj_t aux_972;
{
obj_t aux_973;
{
obj_t aux_974;
{
obj_t aux_975;
aux_975 = MAKE_PAIR(list1285___rgc_dfa, BNIL);
aux_974 = MAKE_PAIR(string1284___rgc_dfa, aux_975);
}
aux_973 = MAKE_PAIR(string1283___rgc_dfa, aux_974);
}
aux_972 = MAKE_PAIR(list1261___rgc_dfa, aux_973);
}
aux_971 = MAKE_PAIR(string1260___rgc_dfa, aux_972);
}
aux_970 = MAKE_PAIR(list1258___rgc_dfa, aux_971);
}
aux_969 = MAKE_PAIR(string1257___rgc_dfa, aux_970);
}
list1255___rgc_dfa = MAKE_PAIR(symbol1256___rgc_dfa, aux_969);
}
{
obj_t aux_984;
{
obj_t aux_985;
aux_985 = MAKE_PAIR(list1255___rgc_dfa, BNIL);
aux_984 = MAKE_PAIR(list1253___rgc_dfa, aux_985);
}
list1251___rgc_dfa = MAKE_PAIR(symbol1252___rgc_dfa, aux_984);
}
symbol1290___rgc_dfa = string_to_symbol("__STATE-TRANSITIONS");
symbol1291___rgc_dfa = string_to_symbol("STATE");
{
obj_t aux_991;
aux_991 = MAKE_PAIR(symbol1291___rgc_dfa, BNIL);
list1289___rgc_dfa = MAKE_PAIR(symbol1290___rgc_dfa, aux_991);
}
{
obj_t aux_994;
{
obj_t aux_995;
aux_995 = MAKE_PAIR(list1289___rgc_dfa, BNIL);
aux_994 = MAKE_PAIR(list1251___rgc_dfa, aux_995);
}
return (list1249___rgc_dfa = MAKE_PAIR(symbol1250___rgc_dfa, aux_994),
BUNSPEC);
}
}


/* toplevel-init */obj_t toplevel_init_63___rgc_dfa()
{
_initial_state__234___rgc_dfa = BUNSPEC;
_states__60___rgc_dfa = BUNSPEC;
return (_state_num__111___rgc_dfa = BUNSPEC,
BUNSPEC);
}


/* node->dfa */obj_t node__dfa_130___rgc_dfa(obj_t root_15, obj_t followpos_16, obj_t positions_17)
{
init_states__107___rgc_dfa();
{
obj_t initial_state_64_381;
long positions_num_108_382;
initial_state_64_381 = make_state_230___rgc_dfa(STRUCT_REF(root_15, ((long)0)));
positions_num_108_382 = VECTOR_LENGTH(positions_17);
_initial_state__234___rgc_dfa = initial_state_64_381;
{
obj_t d_states_83_383;
{
obj_t arg1025_385;
{
obj_t list1026_386;
list1026_386 = MAKE_PAIR(initial_state_64_381, BNIL);
arg1025_385 = list1026_386;
}
d_states_83_383 = arg1025_385;
loop_384:
if(NULLP(d_states_83_383)){
return states_list_224___rgc_dfa();
}
 else {
obj_t new_d_states_114_389;
{
obj_t cellval_1007;
cellval_1007 = CDR(d_states_83_383);
new_d_states_114_389 = MAKE_CELL(cellval_1007);
}
{
obj_t t_390;
t_390 = CAR(d_states_83_383);
{
obj_t t_positions_229_391;
t_positions_229_391 = STRUCT_REF(t_390, ((long)3));
{
{
obj_t arg1030_393;
{
obj_t symbol_set_67_649;
{
obj_t arg1086_650;
arg1086_650 = tree_max_char_216___rgc_rules();
symbol_set_67_649 = make_rgcset_69___rgc_set(CINT(arg1086_650));
}
{
obj_t arg1083_832;
arg1083_832 = make_fx_procedure(arg1083___rgc_dfa, ((long)1), ((long)2));
PROCEDURE_SET(arg1083_832, ((long)0), positions_17);
PROCEDURE_SET(arg1083_832, ((long)1), symbol_set_67_649);
for_each_rgcset_171___rgc_set(arg1083_832, t_positions_229_391);
}
arg1030_393 = symbol_set_67_649;
}
{
obj_t arg1029_831;
arg1029_831 = make_fx_procedure(arg1029___rgc_dfa, ((long)1), ((long)6));
{
obj_t aux_1019;
aux_1019 = BINT(positions_num_108_382);
PROCEDURE_SET(arg1029_831, ((long)0), aux_1019);
}
PROCEDURE_SET(arg1029_831, ((long)1), positions_17);
PROCEDURE_SET(arg1029_831, ((long)2), followpos_16);
PROCEDURE_SET(arg1029_831, ((long)3), t_positions_229_391);
PROCEDURE_SET(arg1029_831, ((long)4), new_d_states_114_389);
PROCEDURE_SET(arg1029_831, ((long)5), t_390);
for_each_rgcset_171___rgc_set(arg1029_831, arg1030_393);
}
}
{
obj_t d_states_83_1028;
d_states_83_1028 = CELL_REF(new_d_states_114_389);
d_states_83_383 = d_states_83_1028;
goto loop_384;
}
}
}
}
}
}
}
}
}


/* _node->dfa */obj_t _node__dfa_101___rgc_dfa(obj_t env_833, obj_t root_834, obj_t followpos_835, obj_t positions_836)
{
return node__dfa_130___rgc_dfa(root_834, followpos_835, positions_836);
}


/* arg1029 */obj_t arg1029___rgc_dfa(obj_t env_837, obj_t a_844)
{
{
obj_t positions_num_108_838;
obj_t positions_839;
obj_t followpos_840;
obj_t t_positions_229_841;
obj_t new_d_states_114_842;
obj_t t_843;
positions_num_108_838 = PROCEDURE_REF(env_837, ((long)0));
positions_839 = PROCEDURE_REF(env_837, ((long)1));
followpos_840 = PROCEDURE_REF(env_837, ((long)2));
t_positions_229_841 = PROCEDURE_REF(env_837, ((long)3));
new_d_states_114_842 = PROCEDURE_REF(env_837, ((long)4));
t_843 = PROCEDURE_REF(env_837, ((long)5));
{
obj_t a_394;
a_394 = a_844;
{
obj_t u_396;
obj_t u_empty__50_397;
u_396 = make_rgcset_69___rgc_set(CINT(positions_num_108_838));
u_empty__50_397 = MAKE_CELL(BTRUE);
{
obj_t arg1032_830;
arg1032_830 = make_fx_procedure(arg1032___rgc_dfa, ((long)1), ((long)5));
PROCEDURE_SET(arg1032_830, ((long)0), positions_839);
PROCEDURE_SET(arg1032_830, ((long)1), a_394);
PROCEDURE_SET(arg1032_830, ((long)2), u_empty__50_397);
PROCEDURE_SET(arg1032_830, ((long)3), followpos_840);
PROCEDURE_SET(arg1032_830, ((long)4), u_396);
for_each_rgcset_171___rgc_set(arg1032_830, t_positions_229_841);
}
{
bool_t test_1045;
{
obj_t aux_1046;
aux_1046 = CELL_REF(u_empty__50_397);
test_1045 = CBOOL(aux_1046);
}
if(test_1045){
return BUNSPEC;
}
 else {
obj_t us_405;
{
obj_t old_state_192_406;
old_state_192_406 = get_hash_29___hash(u_396, _states__60___rgc_dfa);
{
bool_t test_1049;
if(STRUCTP(old_state_192_406)){
obj_t aux_1052;
aux_1052 = STRUCT_KEY(old_state_192_406);
test_1049 = (aux_1052==symbol1243___rgc_dfa);
}
 else {
test_1049 = ((bool_t)0);
}
if(test_1049){
us_405 = old_state_192_406;
}
 else {
obj_t new_state_138_408;
new_state_138_408 = make_state_230___rgc_dfa(u_396);
{
obj_t aux_845;
{
obj_t obj2_674;
obj2_674 = CELL_REF(new_d_states_114_842);
aux_845 = MAKE_PAIR(new_state_138_408, obj2_674);
}
CELL_SET(new_d_states_114_842, aux_845);
}
us_405 = new_state_138_408;
}
}
}
{
obj_t arg1080_678;
{
obj_t arg1081_679;
obj_t arg1082_680;
arg1081_679 = MAKE_PAIR(a_394, us_405);
arg1082_680 = STRUCT_REF(t_843, ((long)2));
arg1080_678 = MAKE_PAIR(arg1081_679, arg1082_680);
}
{
obj_t x_885;
x_885 = STRUCT_SET(t_843, ((long)2), arg1080_678);
return BUNSPEC;
}
}
}
}
}
}
}
}


/* arg1032 */obj_t arg1032___rgc_dfa(obj_t env_846, obj_t p_852)
{
{
obj_t positions_847;
obj_t a_848;
obj_t u_empty__50_849;
obj_t followpos_850;
obj_t u_851;
positions_847 = PROCEDURE_REF(env_846, ((long)0));
a_848 = PROCEDURE_REF(env_846, ((long)1));
u_empty__50_849 = PROCEDURE_REF(env_846, ((long)2));
followpos_850 = PROCEDURE_REF(env_846, ((long)3));
u_851 = PROCEDURE_REF(env_846, ((long)4));
{
obj_t p_399;
p_399 = p_852;
{
bool_t test_1066;
{
long aux_1069;
long aux_1067;
{
obj_t aux_1070;
{
long aux_1071;
aux_1071 = (long)CINT(p_399);
aux_1070 = VECTOR_REF(positions_847, aux_1071);
}
aux_1069 = (long)CINT(aux_1070);
}
aux_1067 = (long)CINT(a_848);
test_1066 = (aux_1067==aux_1069);
}
if(test_1066){
CELL_SET(u_empty__50_849, BFALSE);
{
obj_t aux_1076;
{
long aux_1077;
aux_1077 = (long)CINT(p_399);
aux_1076 = VECTOR_REF(followpos_850, aux_1077);
}
return rgcset_or__64___rgc_set(u_851, aux_1076);
}
}
 else {
return BUNSPEC;
}
}
}
}
}


/* arg1083 */obj_t arg1083___rgc_dfa(obj_t env_854, obj_t i_857)
{
{
obj_t positions_855;
obj_t symbol_set_67_856;
positions_855 = PROCEDURE_REF(env_854, ((long)0));
symbol_set_67_856 = PROCEDURE_REF(env_854, ((long)1));
{
obj_t i_652;
i_652 = i_857;
{
int aux_1083;
{
obj_t aux_1084;
{
long aux_1085;
aux_1085 = (long)CINT(i_652);
aux_1084 = VECTOR_REF(positions_855, aux_1085);
}
aux_1083 = CINT(aux_1084);
}
return rgcset_add__25___rgc_set(symbol_set_67_856, aux_1083);
}
}
}
}


/* reset-dfa! */obj_t reset_dfa__30___rgc_dfa()
{
_initial_state__234___rgc_dfa = BUNSPEC;
_states__60___rgc_dfa = BUNSPEC;
return (_state_num__111___rgc_dfa = BUNSPEC,
BUNSPEC);
}


/* _reset-dfa! */obj_t _reset_dfa__181___rgc_dfa(obj_t env_858)
{
return reset_dfa__30___rgc_dfa();
}


/* get-initial-state */obj_t get_initial_state_58___rgc_dfa()
{
return _initial_state__234___rgc_dfa;
}


/* _get-initial-state */obj_t _get_initial_state_188___rgc_dfa(obj_t env_859)
{
return _initial_state__234___rgc_dfa;
}


/* ___state-position-set */obj_t ___state_position_set_19___rgc_dfa(obj_t env_860, obj_t s_861)
{
{
obj_t s_886;
s_886 = s_861;
return STRUCT_REF(s_886, ((long)3));
}
}


/* states-list */obj_t states_list_224___rgc_dfa()
{
{
obj_t res_428;
res_428 = MAKE_CELL(BNIL);
{
obj_t arg1057_862;
arg1057_862 = make_fx_procedure(arg1057___rgc_dfa, ((long)1), ((long)1));
PROCEDURE_SET(arg1057_862, ((long)0), res_428);
for_each_hash_105___hash(arg1057_862, _states__60___rgc_dfa);
}
return CELL_REF(res_428);
}
}


/* arg1057 */obj_t arg1057___rgc_dfa(obj_t env_863, obj_t state_865)
{
{
obj_t res_864;
res_864 = PROCEDURE_REF(env_863, ((long)0));
{
obj_t state_430;
state_430 = state_865;
{
obj_t aux_866;
{
obj_t obj2_744;
obj2_744 = CELL_REF(res_864);
aux_866 = MAKE_PAIR(state_430, obj2_744);
}
return CELL_SET(res_864, aux_866);
}
}
}
}


/* init-states! */obj_t init_states__107___rgc_dfa()
{
_state_num__111___rgc_dfa = BINT(((long)-1));
{
obj_t arg1060_867;
arg1060_867 = proc1244___rgc_dfa;
{
obj_t list1062_436;
{
obj_t aux_1098;
aux_1098 = BINT(((long)64));
list1062_436 = MAKE_PAIR(aux_1098, BNIL);
}
return (_states__60___rgc_dfa = make_hash_table_174___hash(((long)1024), arg1060_867, __state_position_set_env_155___rgc_dfa, rgcset_equal__env_103___rgc_set, list1062_436),
BUNSPEC);
}
}
}


/* arg1060 */obj_t arg1060___rgc_dfa(obj_t env_868, obj_t set_869)
{
{
obj_t set_438;
{
long aux_1102;
set_438 = set_869;
{
int arg1065_745;
arg1065_745 = rgcset__hash_57___rgc_set(set_438);
{
long aux_1104;
aux_1104 = (long)(arg1065_745);
aux_1102 = (aux_1104%((long)1024));
}
}
return BINT(aux_1102);
}
}
}


/* make-state */obj_t make_state_230___rgc_dfa(obj_t positions_36)
{
{
obj_t num_443;
{
long z1_751;
z1_751 = (long)CINT(_state_num__111___rgc_dfa);
{
long aux_1109;
aux_1109 = (z1_751+((long)1));
_state_num__111___rgc_dfa = BINT(aux_1109);
}
}
num_443 = _state_num__111___rgc_dfa;
{
obj_t name_444;
{
obj_t arg1068_447;
{
char * arg1070_449;
arg1070_449 = number__string_214___r4_numbers_6_5(num_443, BNIL);
{
obj_t list1073_451;
{
obj_t arg1076_452;
{
obj_t arg1077_453;
arg1077_453 = MAKE_PAIR(string1245___rgc_dfa, BNIL);
{
obj_t aux_1114;
aux_1114 = string_to_bstring(arg1070_449);
arg1076_452 = MAKE_PAIR(aux_1114, arg1077_453);
}
}
list1073_451 = MAKE_PAIR(string1246___rgc_dfa, arg1076_452);
}
arg1068_447 = string_append_106___r4_strings_6_7(list1073_451);
}
}
name_444 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, arg1068_447, BEOA);
}
{
obj_t state_445;
{
obj_t new_757;
new_757 = create_struct(symbol1243___rgc_dfa, ((long)4));
STRUCT_SET(new_757, ((long)3), positions_36);
STRUCT_SET(new_757, ((long)2), BNIL);
STRUCT_SET(new_757, ((long)1), num_443);
STRUCT_SET(new_757, ((long)0), name_444);
state_445 = new_757;
}
{
put_hash__129___hash(state_445, _states__60___rgc_dfa);
return state_445;
}
}
}
}
}


/* state-positions */obj_t state_positions_249___rgc_dfa(obj_t state_38)
{
return STRUCT_REF(state_38, ((long)3));
}


/* _state-positions */obj_t _state_positions_121___rgc_dfa(obj_t env_873, obj_t state_874)
{
return state_positions_249___rgc_dfa(state_874);
}


/* state-name */obj_t state_name_114___rgc_dfa(obj_t state_39)
{
return STRUCT_REF(state_39, ((long)0));
}


/* _state-name */obj_t _state_name_187___rgc_dfa(obj_t env_875, obj_t state_876)
{
return state_name_114___rgc_dfa(state_876);
}


/* state-transitions */obj_t state_transitions_152___rgc_dfa(obj_t state_41)
{
return STRUCT_REF(state_41, ((long)2));
}


/* _state-transitions */obj_t _state_transitions_12___rgc_dfa(obj_t env_877, obj_t state_878)
{
return state_transitions_152___rgc_dfa(state_878);
}


/* state? */bool_t state__130___rgc_dfa(obj_t obj_42)
{
if(STRUCTP(obj_42)){
obj_t aux_1135;
aux_1135 = STRUCT_KEY(obj_42);
return (aux_1135==symbol1243___rgc_dfa);
}
 else {
return ((bool_t)0);
}
}


/* _state? */obj_t _state__64___rgc_dfa(obj_t env_879, obj_t obj_880)
{
{
bool_t aux_1138;
aux_1138 = state__130___rgc_dfa(obj_880);
return BBOOL(aux_1138);
}
}


/* print-dfa */obj_t print_dfa_47___rgc_dfa(obj_t dfa_48)
{
{
obj_t list1087_466;
list1087_466 = MAKE_PAIR(string1247___rgc_dfa, BNIL);
print___r4_output_6_10_3(list1087_466);
}
{
obj_t l1002_469;
l1002_469 = dfa_48;
lname1003_470:
if(PAIRP(l1002_469)){
{
obj_t list1093_475;
{
obj_t arg1094_476;
{
obj_t aux_1145;
{
obj_t aux_1146;
aux_1146 = CAR(l1002_469);
aux_1145 = STRUCT_REF(aux_1146, ((long)1));
}
arg1094_476 = MAKE_PAIR(aux_1145, BNIL);
}
list1093_475 = MAKE_PAIR(string1248___rgc_dfa, arg1094_476);
}
print___r4_output_6_10_3(list1093_475);
}
list1249___rgc_dfa;
{
obj_t l1002_1152;
l1002_1152 = CDR(l1002_469);
l1002_469 = l1002_1152;
goto lname1003_470;
}
}
 else {
((bool_t)1);
}
}
{
obj_t list1097_479;
list1097_479 = MAKE_PAIR(string1292___rgc_dfa, BNIL);
print___r4_output_6_10_3(list1097_479);
}
return newline___r4_output_6_10_3(BNIL);
}


/* _print-dfa */obj_t _print_dfa_87___rgc_dfa(obj_t env_881, obj_t dfa_882)
{
return print_dfa_47___rgc_dfa(dfa_882);
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc_dfa()
{
module_initialization_70___rgc_config(((long)0), "__RGC_DFA");
module_initialization_70___rgc_set(((long)0), "__RGC_DFA");
module_initialization_70___rgc_rules(((long)0), "__RGC_DFA");
return module_initialization_70___error(((long)0), "__RGC_DFA");
}

