/*===========================================================================*/
/*   (Effect/effect.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_effect_effect();
extern obj_t funcall_ast_node;
extern obj_t node_effect_213_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t var_ast_node;
static obj_t _side_effect_1564_211_effect_effect(obj_t, obj_t);
static obj_t _side_effect__default1437_242_effect_effect(obj_t, obj_t);
extern obj_t set_ex_it_116_ast_node;
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t side_effect__default1437_34_effect_effect(node_t);
extern obj_t node_ast_node;
static obj_t imported_modules_init_94_effect_effect();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t library_modules_init_112_effect_effect();
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_effect_effect();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern bool_t side_effect__165_effect_effect(node_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_effect_effect = BUNSPEC;
static obj_t cnst_init_137_effect_effect();
static obj_t __cnst[2];

DEFINE_EXPORT_GENERIC(side_effect__env_35_effect_effect, _side_effect_1564_211_effect_effect1572, _side_effect_1564_211_effect_effect, 0L, 1);
DEFINE_STATIC_PROCEDURE(side_effect__default1437_env_70_effect_effect, _side_effect__default1437_242_effect_effect1573, _side_effect__default1437_242_effect_effect, 0L, 1);
DEFINE_STRING(string1566_effect_effect, string1566_effect_effect1574, "SIDE-EFFECT?-DEFAULT1437 READ ", 30);
DEFINE_STRING(string1565_effect_effect, string1565_effect_effect1575, "No method for this object", 25);


/* module-initialization */ obj_t 
module_initialization_70_effect_effect(long checksum_1123, char *from_1124)
{
   if (CBOOL(require_initialization_114_effect_effect))
     {
	require_initialization_114_effect_effect = BBOOL(((bool_t) 0));
	library_modules_init_112_effect_effect();
	cnst_init_137_effect_effect();
	imported_modules_init_94_effect_effect();
	method_init_76_effect_effect();
	toplevel_init_63_effect_effect();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_effect_effect()
{
   module_initialization_70___object(((long) 0), "EFFECT_EFFECT");
   module_initialization_70___reader(((long) 0), "EFFECT_EFFECT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_effect_effect()
{
   {
      obj_t cnst_port_138_1115;
      cnst_port_138_1115 = open_input_string(string1566_effect_effect);
      {
	 long i_1116;
	 i_1116 = ((long) 1);
       loop_1117:
	 {
	    bool_t test1567_1118;
	    test1567_1118 = (i_1116 == ((long) -1));
	    if (test1567_1118)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1568_1119;
		    {
		       obj_t list1569_1120;
		       {
			  obj_t arg1570_1121;
			  arg1570_1121 = BNIL;
			  list1569_1120 = MAKE_PAIR(cnst_port_138_1115, arg1570_1121);
		       }
		       arg1568_1119 = read___reader(list1569_1120);
		    }
		    CNST_TABLE_SET(i_1116, arg1568_1119);
		 }
		 {
		    int aux_1122;
		    {
		       long aux_1141;
		       aux_1141 = (i_1116 - ((long) 1));
		       aux_1122 = (int) (aux_1141);
		    }
		    {
		       long i_1144;
		       i_1144 = (long) (aux_1122);
		       i_1116 = i_1144;
		       goto loop_1117;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_effect_effect()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_effect_effect()
{
   add_generic__110___object(side_effect__env_35_effect_effect, side_effect__default1437_env_70_effect_effect);
   add_inlined_method__244___object(side_effect__env_35_effect_effect, node_ast_node, ((long) 0));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, var_ast_node, ((long) 1));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, node_effect_213_ast_node, ((long) 2));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, setq_ast_node, ((long) 3));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, fail_ast_node, ((long) 4));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, set_ex_it_116_ast_node, ((long) 5));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, jump_ex_it_184_ast_node, ((long) 6));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, box_set__221_ast_node, ((long) 7));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, app_ly_162_ast_node, ((long) 8));
   add_inlined_method__244___object(side_effect__env_35_effect_effect, funcall_ast_node, ((long) 9));
   {
      long aux_1157;
      aux_1157 = add_inlined_method__244___object(side_effect__env_35_effect_effect, cast_ast_node, ((long) 10));
      return BINT(aux_1157);
   }
}


/* side-effect? */ bool_t 
side_effect__165_effect_effect(node_t node_1)
{
   {
      obj_t method1540_1036;
      obj_t class1545_1037;
      {
	 obj_t arg1548_1034;
	 obj_t arg1549_1035;
	 {
	    object_t obj_1071;
	    obj_1071 = (object_t) (node_1);
	    {
	       obj_t pre_method_105_1072;
	       pre_method_105_1072 = PROCEDURE_REF(side_effect__env_35_effect_effect, ((long) 2));
	       if (INTEGERP(pre_method_105_1072))
		 {
		    PROCEDURE_SET(side_effect__env_35_effect_effect, ((long) 2), BUNSPEC);
		    arg1548_1034 = pre_method_105_1072;
		 }
	       else
		 {
		    long obj_class_num_177_1077;
		    obj_class_num_177_1077 = TYPE(obj_1071);
		    {
		       obj_t arg1177_1078;
		       arg1177_1078 = PROCEDURE_REF(side_effect__env_35_effect_effect, ((long) 1));
		       {
			  long arg1178_1082;
			  {
			     long arg1179_1083;
			     arg1179_1083 = OBJECT_TYPE;
			     arg1178_1082 = (obj_class_num_177_1077 - arg1179_1083);
			  }
			  arg1548_1034 = VECTOR_REF(arg1177_1078, arg1178_1082);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1088;
	    object_1088 = (object_t) (node_1);
	    {
	       long arg1180_1089;
	       {
		  long arg1181_1090;
		  long arg1182_1091;
		  arg1181_1090 = TYPE(object_1088);
		  arg1182_1091 = OBJECT_TYPE;
		  arg1180_1089 = (arg1181_1090 - arg1182_1091);
	       }
	       {
		  obj_t vector_1095;
		  vector_1095 = _classes__134___object;
		  arg1549_1035 = VECTOR_REF(vector_1095, arg1180_1089);
	       }
	    }
	 }
	 {
	    obj_t aux_1175;
	    method1540_1036 = arg1548_1034;
	    class1545_1037 = arg1549_1035;
	    {
	       if (INTEGERP(method1540_1036))
		 {
		    switch ((long) CINT(method1540_1036))
		      {
		      case ((long) 0):
			 aux_1175 = BFALSE;
			 break;
		      case ((long) 1):
			 {
			    var_t node_1044;
			    node_1044 = (var_t) (node_1);
			    {
			       bool_t test_1179;
			       {
				  obj_t aux_1183;
				  obj_t aux_1180;
				  aux_1183 = CNST_TABLE_REF(((long) 0));
				  {
				     variable_t arg1555_1048;
				     arg1555_1048 = (((var_t) CREF(node_1044))->variable);
				     aux_1180 = (((variable_t) CREF(arg1555_1048))->access);
				  }
				  test_1179 = (aux_1180 == aux_1183);
			       }
			       if (test_1179)
				 {
				    aux_1175 = BFALSE;
				 }
			       else
				 {
				    aux_1175 = BTRUE;
				 }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    node_effect_213_t node_1049;
			    node_1049 = (node_effect_213_t) (node_1);
			    {
			       obj_t effect_1050;
			       effect_1050 = (((node_effect_213_t) CREF(node_1049))->side_effect__165);
			       if (BOOLEANP(effect_1050))
				 {
				    aux_1175 = effect_1050;
				 }
			       else
				 {
				    aux_1175 = BTRUE;
				 }
			    }
			 }
			 break;
		      case ((long) 3):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 4):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 5):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 6):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 7):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 8):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 9):
			 aux_1175 = BTRUE;
			 break;
		      case ((long) 10):
			 {
			    cast_t node_1059;
			    node_1059 = (cast_t) (node_1);
			    {
			       bool_t aux_1191;
			       aux_1191 = side_effect__165_effect_effect((((cast_t) CREF(node_1059))->arg));
			       aux_1175 = BBOOL(aux_1191);
			    }
			 }
			 break;
		      default:
		       case_else1546_1040:
			 if (PROCEDUREP(method1540_1036))
			   {
			      aux_1175 = PROCEDURE_ENTRY(method1540_1036) (method1540_1036, (obj_t) (node_1), BEOA);
			   }
			 else
			   {
			      obj_t fun1536_1030;
			      fun1536_1030 = PROCEDURE_REF(side_effect__env_35_effect_effect, ((long) 0));
			      aux_1175 = PROCEDURE_ENTRY(fun1536_1030) (fun1536_1030, (obj_t) (node_1), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1546_1040;
		 }
	    }
	    return CBOOL(aux_1175);
	 }
      }
   }
}


/* _side-effect?1564 */ obj_t 
_side_effect_1564_211_effect_effect(obj_t env_1111, obj_t node_1112)
{
   {
      bool_t aux_1207;
      aux_1207 = side_effect__165_effect_effect((node_t) (node_1112));
      return BBOOL(aux_1207);
   }
}


/* side-effect?-default1437 */ obj_t 
side_effect__default1437_34_effect_effect(node_t node_2)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1565_effect_effect, (obj_t) (node_2));
}


/* _side-effect?-default1437 */ obj_t 
_side_effect__default1437_242_effect_effect(obj_t env_1113, obj_t node_1114)
{
   return side_effect__default1437_34_effect_effect((node_t) (node_1114));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_effect_effect()
{
   module_initialization_70_type_type(((long) 0), "EFFECT_EFFECT");
   module_initialization_70_ast_var(((long) 0), "EFFECT_EFFECT");
   return module_initialization_70_ast_node(((long) 0), "EFFECT_EFFECT");
}
