/*===========================================================================*/
/*   (Llib/bigloo.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern bool_t bigloo_strcmp(obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
static obj_t toplevel_init_63___bigloo();
static obj_t _release__212___bigloo = BUNSPEC;
static obj_t _level__58___bigloo = BUNSPEC;
extern long closure_arity_107___bigloo(obj_t);
extern obj_t check_version__107___bigloo(obj_t, char *, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t string_to_bstring(char *);
static obj_t _modules__206___bigloo = BUNSPEC;
obj_t bprof_port = BUNSPEC;
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_substring(obj_t, long, long);
static obj_t _check_version_1152_2___bigloo(obj_t, obj_t, obj_t, obj_t);
static obj_t _unspecified___bigloo(obj_t);
extern obj_t unspecified___bigloo();
static obj_t _cnst__123___bigloo(obj_t, obj_t);
static obj_t imported_modules_init_94___bigloo();
extern long minfx___r4_numbers_6_5_fixnum(long, obj_t);
static obj_t require_initialization_114___bigloo = BUNSPEC;
extern bool_t cnst__120___bigloo(obj_t);
static obj_t _closure_arity1153_57___bigloo(obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( check_version__env_23___bigloo, _check_version_1152_2___bigloo1158, _check_version_1152_2___bigloo, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( closure_arity_env_23___bigloo, _closure_arity1153_57___bigloo1159, _closure_arity1153_57___bigloo, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cnst__env_192___bigloo, _cnst__123___bigloo1160, _cnst__123___bigloo, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( unspecified_env_163___bigloo, _unspecified___bigloo1161, _unspecified___bigloo, 0L, 0 );
DEFINE_STRING( string1156___bigloo, string1156___bigloo1162, "and other by: ", 14 );
DEFINE_STRING( string1155___bigloo, string1155___bigloo1163, "Some modules have been compiled by: ", 36 );
DEFINE_STRING( string1154___bigloo, string1154___bigloo1164, " (level 0)", 10 );


/* module-initialization */obj_t module_initialization_70___bigloo(long checksum_428, char * from_429)
{
if(CBOOL(require_initialization_114___bigloo)){
require_initialization_114___bigloo = BBOOL(((bool_t)0));
imported_modules_init_94___bigloo();
toplevel_init_63___bigloo();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* toplevel-init */obj_t toplevel_init_63___bigloo()
{
_release__212___bigloo = BFALSE;
_level__58___bigloo = BFALSE;
_modules__206___bigloo = BNIL;
return (bprof_port = BUNSPEC,
BUNSPEC);
}


/* check-version! */obj_t check_version__107___bigloo(obj_t module_1, char * release_2, obj_t level_3)
{
{
bool_t test1007_216;
{
obj_t obj_366;
obj_366 = _release__212___bigloo;
test1007_216 = STRINGP(obj_366);
}
if(test1007_216){
bool_t test1008_217;
{
bool_t test1018_232;
{
long min_236;
{
long arg1023_240;
{
long arg1026_242;
long arg1027_243;
{
obj_t aux_437;
aux_437 = string_to_bstring(release_2);
arg1026_242 = STRING_LENGTH(aux_437);
}
{
obj_t string_368;
string_368 = _release__212___bigloo;
arg1027_243 = STRING_LENGTH(string_368);
}
{
obj_t list1028_244;
{
obj_t aux_441;
aux_441 = BINT(arg1027_243);
list1028_244 = MAKE_PAIR(aux_441, BNIL);
}
arg1023_240 = minfx___r4_numbers_6_5_fixnum(arg1026_242, list1028_244);
}
}
min_236 = (arg1023_240-((long)1));
}
{
bool_t test1020_237;
{
obj_t arg1021_238;
obj_t arg1022_239;
{
obj_t aux_446;
aux_446 = string_to_bstring(release_2);
arg1021_238 = c_substring(aux_446, ((long)0), min_236);
}
{
obj_t string_374;
string_374 = _release__212___bigloo;
arg1022_239 = c_substring(string_374, ((long)0), min_236);
}
test1020_237 = bigloo_strcmp(arg1021_238, arg1022_239);
}
if(test1020_237){
test1018_232 = ((bool_t)0);
}
 else {
test1018_232 = ((bool_t)1);
}
}
}
if(test1018_232){
test1008_217 = ((bool_t)1);
}
 else {
if(CHARP(level_3)){
bool_t _andtest_1003_234;
{
obj_t obj_380;
obj_380 = _level__58___bigloo;
_andtest_1003_234 = CHARP(obj_380);
}
if(_andtest_1003_234){
bool_t test1019_235;
{
unsigned char char1_381;
unsigned char char2_382;
char1_381 = (unsigned char)CCHAR(_level__58___bigloo);
char2_382 = (unsigned char)CCHAR(level_3);
test1019_235 = (char1_381==char2_382);
}
if(test1019_235){
test1008_217 = ((bool_t)0);
}
 else {
test1008_217 = ((bool_t)1);
}
}
 else {
test1008_217 = ((bool_t)0);
}
}
 else {
test1008_217 = ((bool_t)0);
}
}
}
if(test1008_217){
{
obj_t arg1009_219;
obj_t arg1010_220;
obj_t arg1011_221;
{
obj_t arg1013_223;
{
obj_t release_383;
obj_t level_384;
release_383 = _release__212___bigloo;
level_384 = _level__58___bigloo;
if(CHARP(level_384)){
obj_t s_386;
{
char * aux_464;
aux_464 = BSTRING_TO_STRING(string1154___bigloo);
s_386 = string_to_bstring(aux_464);
}
{
unsigned char aux_467;
aux_467 = (unsigned char)CCHAR(level_384);
STRING_SET(s_386, ((long)8), aux_467);
}
arg1013_223 = string_append(release_383, s_386);
}
 else {
arg1013_223 = release_383;
}
}
arg1009_219 = string_append(string1155___bigloo, arg1013_223);
}
{
obj_t arg1015_225;
if(CHARP(level_3)){
obj_t s_395;
{
char * aux_474;
aux_474 = BSTRING_TO_STRING(string1154___bigloo);
s_395 = string_to_bstring(aux_474);
}
{
unsigned char aux_477;
aux_477 = (unsigned char)CCHAR(level_3);
STRING_SET(s_395, ((long)8), aux_477);
}
{
obj_t aux_480;
aux_480 = string_to_bstring(release_2);
arg1015_225 = string_append(aux_480, s_395);
}
}
 else {
arg1015_225 = string_to_bstring(release_2);
}
arg1010_220 = string_append(string1156___bigloo, arg1015_225);
}
{
obj_t obj2_402;
obj2_402 = _modules__206___bigloo;
arg1011_221 = MAKE_PAIR(module_1, obj2_402);
}
FAILURE(arg1009_219,arg1010_220,arg1011_221);}
}
 else {
{
obj_t obj2_414;
obj2_414 = _modules__206___bigloo;
return (_modules__206___bigloo = MAKE_PAIR(module_1, obj2_414),
BUNSPEC);
}
}
}
 else {
{
obj_t list1030_246;
list1030_246 = MAKE_PAIR(module_1, BNIL);
_modules__206___bigloo = list1030_246;
}
_release__212___bigloo = string_to_bstring(release_2);
return (_level__58___bigloo = level_3,
BUNSPEC);
}
}
}


/* _check-version!1152 */obj_t _check_version_1152_2___bigloo(obj_t env_416, obj_t module_417, obj_t release_418, obj_t level_419)
{
return check_version__107___bigloo(module_417, BSTRING_TO_STRING(release_418), level_419);
}


/* closure-arity */long closure_arity_107___bigloo(obj_t proc_4)
{
return PROCEDURE_ARITY(proc_4);
}


/* _closure-arity1153 */obj_t _closure_arity1153_57___bigloo(obj_t env_420, obj_t proc_421)
{
{
long aux_493;
{
obj_t proc_426;
proc_426 = proc_421;
aux_493 = PROCEDURE_ARITY(proc_426);
}
return BINT(aux_493);
}
}


/* unspecified */obj_t unspecified___bigloo()
{
return BUNSPEC;
}


/* _unspecified */obj_t _unspecified___bigloo(obj_t env_422)
{
return BUNSPEC;
}


/* cnst? */bool_t cnst__120___bigloo(obj_t obj_5)
{
return CNSTP(obj_5);
}


/* _cnst? */obj_t _cnst__123___bigloo(obj_t env_423, obj_t obj_424)
{
{
bool_t aux_497;
{
obj_t obj_427;
obj_427 = obj_424;
aux_497 = CNSTP(obj_427);
}
return BBOOL(aux_497);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___bigloo()
{
return module_initialization_70___error(((long)0), "__BIGLOO");
}

