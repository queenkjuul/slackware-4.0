/*===========================================================================*/
/*   (Object/wide-access.scm)                                                */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
extern obj_t make_struct__wide_object_7_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
static obj_t import_wide_class_make__56_object_wide_access_168(obj_t, obj_t, type_t, obj_t, obj_t, obj_t, obj_t);
static obj_t method_init_76_object_wide_access_168();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t _optim__89_engine_param;
static obj_t import_wide_class_makes__40_object_wide_access_168(obj_t, type_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t type_type_type;
extern obj_t make_class_makes__132_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t make_wide_class_makes__165_object_wide_access_168(obj_t, type_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_wide_object__struct_148_object_struct(obj_t, type_t, obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t make_class_pred__174_object_access(obj_t, class_t, obj_t, obj_t);
extern obj_t make_class_slots_205_object_slots(obj_t, obj_t, obj_t);
extern obj_t make_class_coercers_236_object_access(obj_t);
static obj_t _import_wide_class_accessors_1761_165_object_wide_access_168(obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_object_wide_access_168(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70_object_struct(long, char *);
extern obj_t module_initialization_70_object_slots(long, char *);
extern obj_t module_initialization_70_object_tools(long, char *);
extern obj_t module_initialization_70_object_access(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t make_class_make_typed_formals_184_object_access(obj_t);
extern bool_t wide_class__100_object_class(obj_t);
extern obj_t make_class_slots_access__80_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_object_wide_access_168();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t make_coercion_clause_209_object_access(obj_t, obj_t);
extern obj_t import_wide_class_accessors__236_object_wide_access_168(obj_t, type_t, obj_t, obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_parser_53_module_impuse(obj_t, obj_t);
static obj_t library_modules_init_112_object_wide_access_168();
extern obj_t import_class_slots_access__39_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _optim_stack___57_engine_param;
static obj_t toplevel_init_63_object_wide_access_168();
extern obj_t open_input_string(obj_t);
extern obj_t epairify_object_access(obj_t, obj_t);
extern obj_t import_class_pred__91_object_access(obj_t, class_t, obj_t, obj_t);
extern obj_t class_object_class;
static obj_t correct_wide_class__226_object_wide_access_168(type_t, obj_t);
static obj_t _make_wide_class_accessors_1760_4_object_wide_access_168(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t make_class_make_formals_23_object_access(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t make_wide_class_make__242_object_wide_access_168(obj_t, obj_t, type_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t _module__166_module_module;
extern obj_t _4dots_199_tools_misc;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_class_makes__192_object_access(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t make_wide_class_accessors__22_object_wide_access_168(obj_t, type_t, obj_t, obj_t);
extern obj_t make_class_allocate__44_object_access(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114_object_wide_access_168 = BUNSPEC;
extern bool_t final_class__126_object_class(obj_t);
extern obj_t find_class_constructors_231_object_class(class_t);
static obj_t cnst_init_137_object_wide_access_168();
static obj_t __cnst[22];

DEFINE_EXPORT_PROCEDURE(import_wide_class_accessors__env_94_object_wide_access_168, _import_wide_class_accessors_1761_165_object_wide_access_1681778, _import_wide_class_accessors_1761_165_object_wide_access_168, 0L, 4);
DEFINE_STRING(string1772_object_wide_access_168, string1772_object_wide_access_1681779, "OBJECT-WIDENING-SET! @ CLASS-NUM OBJECT-CLASS-NUM-SET! FREE-PRAGMA LET DEFINE DEFINE-INLINE (INLINE) NEW AUX MAKE -STACK- STACK-ALLOC PRAGMA - MAKE-STACK- MAKE- WIDENING FOREIGN STATIC (EXPORT STATIC) ", 201);
DEFINE_STRING(string1771_object_wide_access_168, string1771_object_wide_access_1681780, "((", 2);
DEFINE_STRING(string1769_object_wide_access_168, string1769_object_wide_access_1681781, "Should not be able to see a plain class here", 44);
DEFINE_STRING(string1770_object_wide_access_168, string1770_object_wide_access_1681782, ")($1))", 6);
DEFINE_STRING(string1768_object_wide_access_168, string1768_object_wide_access_1681783, "make-wide-class-accesses!", 25);
DEFINE_STRING(string1767_object_wide_access_168, string1767_object_wide_access_1681784, "super of wide class `", 21);
DEFINE_STRING(string1766_object_wide_access_168, string1766_object_wide_access_1681785, "' is not a final class", 22);
DEFINE_STRING(string1765_object_wide_access_168, string1765_object_wide_access_1681786, "A class can't be `wide' and `final'", 35);
DEFINE_STRING(string1764_object_wide_access_168, string1764_object_wide_access_1681787, "' is a wide class", 17);
DEFINE_STRING(string1763_object_wide_access_168, string1763_object_wide_access_1681788, "super of `", 10);
DEFINE_STRING(string1762_object_wide_access_168, string1762_object_wide_access_1681789, "' is not a class", 16);
DEFINE_EXPORT_PROCEDURE(make_wide_class_accessors__env_98_object_wide_access_168, _make_wide_class_accessors_1760_4_object_wide_access_1681790, _make_wide_class_accessors_1760_4_object_wide_access_168, 0L, 4);


/* module-initialization */ obj_t 
module_initialization_70_object_wide_access_168(long checksum_1294, char *from_1295)
{
   if (CBOOL(require_initialization_114_object_wide_access_168))
     {
	require_initialization_114_object_wide_access_168 = BBOOL(((bool_t) 0));
	library_modules_init_112_object_wide_access_168();
	cnst_init_137_object_wide_access_168();
	imported_modules_init_94_object_wide_access_168();
	method_init_76_object_wide_access_168();
	toplevel_init_63_object_wide_access_168();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_object_wide_access_168()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70___r4_symbols_6_4(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70___object(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70___r4_strings_6_7(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70___reader(((long) 0), "OBJECT_WIDE-ACCESS");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_object_wide_access_168()
{
   {
      obj_t cnst_port_138_1286;
      cnst_port_138_1286 = open_input_string(string1772_object_wide_access_168);
      {
	 long i_1287;
	 i_1287 = ((long) 21);
       loop_1288:
	 {
	    bool_t test1773_1289;
	    test1773_1289 = (i_1287 == ((long) -1));
	    if (test1773_1289)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1774_1290;
		    {
		       obj_t list1775_1291;
		       {
			  obj_t arg1776_1292;
			  arg1776_1292 = BNIL;
			  list1775_1291 = MAKE_PAIR(cnst_port_138_1286, arg1776_1292);
		       }
		       arg1774_1290 = read___reader(list1775_1291);
		    }
		    CNST_TABLE_SET(i_1287, arg1774_1290);
		 }
		 {
		    int aux_1293;
		    {
		       long aux_1315;
		       aux_1315 = (i_1287 - ((long) 1));
		       aux_1293 = (int) (aux_1315);
		    }
		    {
		       long i_1318;
		       i_1318 = (long) (aux_1293);
		       i_1287 = i_1318;
		       goto loop_1288;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_object_wide_access_168()
{
   return BUNSPEC;
}


/* make-wide-class-accessors! */ obj_t 
make_wide_class_accessors__22_object_wide_access_168(obj_t class_def_12_63, type_t class_64, obj_t src_def_101_65, obj_t import_66)
{
   {
      bool_t test1252_501;
      {
	 bool_t test1292_545;
	 test1292_545 = is_a__118___object((obj_t) (class_64), class_object_class);
	 if (test1292_545)
	   {
	      obj_t aux_1323;
	      {
		 class_t obj_1139;
		 obj_1139 = (class_t) (class_64);
		 {
		    obj_t aux_1325;
		    {
		       object_t aux_1326;
		       aux_1326 = (object_t) (obj_1139);
		       aux_1325 = OBJECT_WIDENING(aux_1326);
		    }
		    aux_1323 = (((class_t) CREF(aux_1325))->its_super_214);
		 }
	      }
	      test1252_501 = is_a__118___object(aux_1323, class_object_class);
	   }
	 else
	   {
	      test1252_501 = ((bool_t) 0);
	   }
      }
      if (test1252_501)
	{
	   bool_t test1253_502;
	   {
	      obj_t aux_1332;
	      aux_1332 = correct_wide_class__226_object_wide_access_168(class_64, src_def_101_65);
	      test1253_502 = CBOOL(aux_1332);
	   }
	   if (test1253_502)
	     {
		obj_t super_503;
		{
		   class_t obj_1141;
		   obj_1141 = (class_t) (class_64);
		   {
		      obj_t aux_1337;
		      {
			 object_t aux_1338;
			 aux_1338 = (object_t) (obj_1141);
			 aux_1337 = OBJECT_WIDENING(aux_1338);
		      }
		      super_503 = (((class_t) CREF(aux_1337))->its_super_214);
		   }
		}
		{
		   obj_t domestic__170_504;
		   domestic__170_504 = memq___r4_pairs_and_lists_6_3(import_66, CNST_TABLE_REF(((long) 0)));
		   {
		      obj_t sslots_505;
		      {
			 class_t obj_1142;
			 obj_1142 = (class_t) (super_503);
			 {
			    obj_t aux_1345;
			    {
			       object_t aux_1346;
			       aux_1346 = (object_t) (obj_1142);
			       aux_1345 = OBJECT_WIDENING(aux_1346);
			    }
			    sslots_505 = (((class_t) CREF(aux_1345))->slots);
			 }
		      }
		      {
			 obj_t cslots_507;
			 {
			    obj_t aux_1350;
			    {
			       obj_t aux_1351;
			       aux_1351 = CDR(class_def_12_63);
			       aux_1350 = CDR(aux_1351);
			    }
			    cslots_507 = make_class_slots_205_object_slots(aux_1350, BFALSE, src_def_101_65);
			 }
			 {
			    obj_t class_id_86_508;
			    class_id_86_508 = (((type_t) CREF(class_64))->id);
			    {
			       global_t holder_510;
			       {
				  class_t obj_1149;
				  obj_1149 = (class_t) (class_64);
				  {
				     obj_t aux_1357;
				     {
					object_t aux_1358;
					aux_1358 = (object_t) (obj_1149);
					aux_1357 = OBJECT_WIDENING(aux_1358);
				     }
				     holder_510 = (((class_t) CREF(aux_1357))->holder);
				  }
			       }
			       {
				  obj_t widening_512;
				  {
				     class_t obj_1151;
				     obj_1151 = (class_t) (class_64);
				     {
					obj_t aux_1363;
					{
					   object_t aux_1364;
					   aux_1364 = (object_t) (obj_1151);
					   aux_1363 = OBJECT_WIDENING(aux_1364);
					}
					widening_512 = (((class_t) CREF(aux_1363))->widening);
				     }
				  }
				  {
				     obj_t import_513;
				     if (CBOOL(domestic__170_504))
				       {
					  import_513 = import_66;
				       }
				     else
				       {
					  import_513 = CNST_TABLE_REF(((long) 1));
				       }
				     {
					{
					   obj_t arg1254_514;
					   arg1254_514 = make_coercion_clause_209_object_access(class_id_86_508, super_503);
					   produce_module_clause__172_module_module(arg1254_514);
					}
					{
					   class_t obj_1152;
					   obj_1152 = (class_t) (class_64);
					   {
					      obj_t aux_1374;
					      {
						 object_t aux_1375;
						 aux_1375 = (object_t) (obj_1152);
						 aux_1374 = OBJECT_WIDENING(aux_1375);
					      }
					      ((((class_t) CREF(aux_1374))->slots) = ((obj_t) cslots_507), BUNSPEC);
					   }
					}
					{
					   obj_t arg1255_515;
					   {
					      obj_t arg1256_516;
					      obj_t arg1257_517;
					      arg1256_516 = CNST_TABLE_REF(((long) 2));
					      {
						 obj_t arg1260_520;
						 obj_t arg1262_521;
						 arg1260_520 = make_class_coercers_236_object_access((obj_t) (class_64));
						 arg1262_521 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						 arg1257_517 = append_2_18___r4_pairs_and_lists_6_3(arg1260_520, arg1262_521);
					      }
					      {
						 obj_t list1258_518;
						 list1258_518 = MAKE_PAIR(arg1257_517, BNIL);
						 arg1255_515 = cons__138___r4_pairs_and_lists_6_3(arg1256_516, list1258_518);
					      }
					   }
					   produce_module_clause__172_module_module(arg1255_515);
					}
					{
					   obj_t accs_524;
					   {
					      obj_t arg1274_532;
					      obj_t arg1277_533;
					      obj_t arg1278_534;
					      obj_t arg1281_535;
					      obj_t arg1282_536;
					      arg1274_532 = make_class_pred__174_object_access(class_id_86_508, (class_t) (class_64), src_def_101_65, import_513);
					      arg1277_533 = make_class_makes__132_object_access(CNST_TABLE_REF(((long) 3)), widening_512, class_id_86_508, (obj_t) (class_64), cslots_507, src_def_101_65, import_513);
					      arg1278_534 = make_wide_class_makes__165_object_wide_access_168(class_id_86_508, class_64, cslots_507, sslots_505, src_def_101_65, import_513);
					      arg1281_535 = make_class_slots_access__80_object_access(class_id_86_508, super_503, sslots_505, BFALSE, src_def_101_65, import_513);
					      arg1282_536 = make_class_slots_access__80_object_access(class_id_86_508, (obj_t) (class_64), cslots_507, (obj_t) (class_64), src_def_101_65, import_513);
					      {
						 obj_t list1283_537;
						 {
						    obj_t arg1284_538;
						    {
						       obj_t arg1285_539;
						       {
							  obj_t arg1286_540;
							  {
							     obj_t arg1287_541;
							     arg1287_541 = MAKE_PAIR(arg1282_536, BNIL);
							     arg1286_540 = MAKE_PAIR(arg1281_535, arg1287_541);
							  }
							  arg1285_539 = MAKE_PAIR(arg1278_534, arg1286_540);
						       }
						       arg1284_538 = MAKE_PAIR(arg1277_533, arg1285_539);
						    }
						    list1283_537 = MAKE_PAIR(arg1274_532, arg1284_538);
						 }
						 accs_524 = append___r4_pairs_and_lists_6_3(list1283_537);
					      }
					   }
					   {
					      obj_t arg1265_525;
					      obj_t arg1267_526;
					      arg1265_525 = make_class_allocate__44_object_access(class_id_86_508, super_503, (obj_t) (holder_510), src_def_101_65, import_513);
					      if (CBOOL(domestic__170_504))
						{
						   obj_t arg1268_527;
						   obj_t arg1269_528;
						   arg1268_527 = make_wide_object__struct_148_object_struct(class_id_86_508, class_64, _module__166_module_module, cslots_507, src_def_101_65);
						   arg1269_528 = make_struct__wide_object_7_object_struct(class_id_86_508, class_64, _module__166_module_module, cslots_507, src_def_101_65);
						   {
						      obj_t list1270_529;
						      {
							 obj_t arg1272_530;
							 arg1272_530 = MAKE_PAIR(accs_524, BNIL);
							 list1270_529 = MAKE_PAIR(arg1269_528, arg1272_530);
						      }
						      arg1267_526 = cons__138___r4_pairs_and_lists_6_3(arg1268_527, list1270_529);
						   }
						}
					      else
						{
						   arg1267_526 = accs_524;
						}
					      return MAKE_PAIR(arg1265_525, arg1267_526);
					   }
					}
				     }
				  }
			       }
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
		return BUNSPEC;
	     }
	}
      else
	{
	   return BNIL;
	}
   }
}


/* _make-wide-class-accessors!1760 */ obj_t 
_make_wide_class_accessors_1760_4_object_wide_access_168(obj_t env_1275, obj_t class_def_12_1276, obj_t class_1277, obj_t src_def_101_1278, obj_t import_1279)
{
   return make_wide_class_accessors__22_object_wide_access_168(class_def_12_1276, (type_t) (class_1277), src_def_101_1278, import_1279);
}


/* import-wide-class-accessors! */ obj_t 
import_wide_class_accessors__236_object_wide_access_168(obj_t class_def_12_67, type_t class_68, obj_t src_def_101_69, obj_t module_70)
{
   {
      bool_t test1295_547;
      {
	 bool_t test1309_568;
	 test1309_568 = is_a__118___object((obj_t) (class_68), class_object_class);
	 if (test1309_568)
	   {
	      obj_t aux_1418;
	      {
		 class_t obj_1157;
		 obj_1157 = (class_t) (class_68);
		 {
		    obj_t aux_1420;
		    {
		       object_t aux_1421;
		       aux_1421 = (object_t) (obj_1157);
		       aux_1420 = OBJECT_WIDENING(aux_1421);
		    }
		    aux_1418 = (((class_t) CREF(aux_1420))->its_super_214);
		 }
	      }
	      test1295_547 = is_a__118___object(aux_1418, class_object_class);
	   }
	 else
	   {
	      test1295_547 = ((bool_t) 0);
	   }
      }
      if (test1295_547)
	{
	   bool_t test1296_548;
	   {
	      obj_t aux_1427;
	      aux_1427 = correct_wide_class__226_object_wide_access_168(class_68, src_def_101_69);
	      test1296_548 = CBOOL(aux_1427);
	   }
	   if (test1296_548)
	     {
		obj_t super_549;
		{
		   class_t obj_1159;
		   obj_1159 = (class_t) (class_68);
		   {
		      obj_t aux_1432;
		      {
			 object_t aux_1433;
			 aux_1433 = (object_t) (obj_1159);
			 aux_1432 = OBJECT_WIDENING(aux_1433);
		      }
		      super_549 = (((class_t) CREF(aux_1432))->its_super_214);
		   }
		}
		{
		   obj_t sslots_550;
		   {
		      class_t obj_1160;
		      obj_1160 = (class_t) (super_549);
		      {
			 obj_t aux_1438;
			 {
			    object_t aux_1439;
			    aux_1439 = (object_t) (obj_1160);
			    aux_1438 = OBJECT_WIDENING(aux_1439);
			 }
			 sslots_550 = (((class_t) CREF(aux_1438))->slots);
		      }
		   }
		   {
		      obj_t cslots_552;
		      {
			 obj_t aux_1443;
			 {
			    obj_t aux_1444;
			    aux_1444 = CDR(class_def_12_67);
			    aux_1443 = CDR(aux_1444);
			 }
			 cslots_552 = make_class_slots_205_object_slots(aux_1443, BFALSE, src_def_101_69);
		      }
		      {
			 obj_t class_id_86_553;
			 class_id_86_553 = (((type_t) CREF(class_68))->id);
			 {
			    global_t holder_555;
			    {
			       class_t obj_1167;
			       obj_1167 = (class_t) (class_68);
			       {
				  obj_t aux_1450;
				  {
				     object_t aux_1451;
				     aux_1451 = (object_t) (obj_1167);
				     aux_1450 = OBJECT_WIDENING(aux_1451);
				  }
				  holder_555 = (((class_t) CREF(aux_1450))->holder);
			       }
			    }
			    {
			       obj_t module_556;
			       module_556 = (((global_t) CREF(holder_555))->module);
			       {
				  obj_t widening_557;
				  {
				     class_t obj_1169;
				     obj_1169 = (class_t) (class_68);
				     {
					obj_t aux_1457;
					{
					   object_t aux_1458;
					   aux_1458 = (object_t) (obj_1169);
					   aux_1457 = OBJECT_WIDENING(aux_1458);
					}
					widening_557 = (((class_t) CREF(aux_1457))->widening);
				     }
				  }
				  {
				     {
					obj_t arg1297_558;
					arg1297_558 = make_coercion_clause_209_object_access(class_id_86_553, super_549);
					produce_module_clause__172_module_module(arg1297_558);
				     }
				     {
					class_t obj_1170;
					obj_1170 = (class_t) (class_68);
					{
					   obj_t aux_1465;
					   {
					      object_t aux_1466;
					      aux_1466 = (object_t) (obj_1170);
					      aux_1465 = OBJECT_WIDENING(aux_1466);
					   }
					   ((((class_t) CREF(aux_1465))->slots) = ((obj_t) cslots_552), BUNSPEC);
					}
				     }
				     {
					obj_t arg1298_559;
					{
					   obj_t arg1299_560;
					   obj_t arg1300_561;
					   arg1299_560 = CNST_TABLE_REF(((long) 2));
					   {
					      obj_t arg1303_564;
					      obj_t arg1304_565;
					      arg1303_564 = make_class_coercers_236_object_access((obj_t) (class_68));
					      arg1304_565 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					      arg1300_561 = append_2_18___r4_pairs_and_lists_6_3(arg1303_564, arg1304_565);
					   }
					   {
					      obj_t list1301_562;
					      list1301_562 = MAKE_PAIR(arg1300_561, BNIL);
					      arg1298_559 = cons__138___r4_pairs_and_lists_6_3(arg1299_560, list1301_562);
					   }
					}
					produce_module_clause__172_module_module(arg1298_559);
				     }
				     import_class_pred__91_object_access(class_id_86_553, (class_t) (class_68), src_def_101_69, module_556);
				     import_class_makes__192_object_access(widening_557, class_id_86_553, (obj_t) (class_68), cslots_552, src_def_101_69, module_556);
				     import_wide_class_makes__40_object_wide_access_168(class_id_86_553, class_68, cslots_552, sslots_550, src_def_101_69, module_556);
				     import_class_slots_access__39_object_access(class_id_86_553, super_549, sslots_550, src_def_101_69, module_556);
				     import_class_slots_access__39_object_access(class_id_86_553, (obj_t) (class_68), cslots_552, src_def_101_69, module_556);
				  }
			       }
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
		BUNSPEC;
	     }
	}
      else
	{
	   BUNSPEC;
	}
   }
   return BNIL;
}


/* _import-wide-class-accessors!1761 */ obj_t 
_import_wide_class_accessors_1761_165_object_wide_access_168(obj_t env_1280, obj_t class_def_12_1281, obj_t class_1282, obj_t src_def_101_1283, obj_t module_1284)
{
   return import_wide_class_accessors__236_object_wide_access_168(class_def_12_1281, (type_t) (class_1282), src_def_101_1283, module_1284);
}


/* correct-wide-class? */ obj_t 
correct_wide_class__226_object_wide_access_168(type_t class_71, obj_t src_def_101_72)
{
   {
      obj_t super_570;
      {
	 class_t obj_1172;
	 obj_1172 = (class_t) (class_71);
	 {
	    obj_t aux_1489;
	    {
	       object_t aux_1490;
	       aux_1490 = (object_t) (obj_1172);
	       aux_1489 = OBJECT_WIDENING(aux_1490);
	    }
	    super_570 = (((class_t) CREF(aux_1489))->its_super_214);
	 }
      }
      {
	 obj_t class_id_86_571;
	 class_id_86_571 = (((type_t) CREF(class_71))->id);
	 {
	    {
	       bool_t test1311_572;
	       {
		  bool_t test1365_612;
		  test1365_612 = is_a__118___object(super_570, type_type_type);
		  if (test1365_612)
		    {
		       bool_t test1366_613;
		       test1366_613 = is_a__118___object(super_570, class_object_class);
		       if (test1366_613)
			 {
			    test1311_572 = ((bool_t) 0);
			 }
		       else
			 {
			    test1311_572 = ((bool_t) 1);
			 }
		    }
		  else
		    {
		       test1311_572 = ((bool_t) 0);
		    }
	       }
	       if (test1311_572)
		 {
		    {
		       obj_t arg1313_573;
		       obj_t arg1315_574;
		       {
			  type_t obj_1176;
			  obj_1176 = (type_t) (super_570);
			  arg1313_573 = (((type_t) CREF(obj_1176))->id);
		       }
		       {
			  obj_t arg1322_578;
			  arg1322_578 = SYMBOL_TO_STRING(class_id_86_571);
			  {
			     obj_t list1324_580;
			     {
				obj_t arg1325_581;
				{
				   obj_t arg1326_582;
				   arg1326_582 = MAKE_PAIR(string1762_object_wide_access_168, BNIL);
				   arg1325_581 = MAKE_PAIR(arg1322_578, arg1326_582);
				}
				list1324_580 = MAKE_PAIR(string1763_object_wide_access_168, arg1325_581);
			     }
			     arg1315_574 = string_append_106___r4_strings_6_7(list1324_580);
			  }
		       }
		       {
			  obj_t list1316_575;
			  list1316_575 = MAKE_PAIR(type_type_type, BNIL);
			  return user_error_151_tools_error(arg1313_573, arg1315_574, src_def_101_72, list1316_575);
		       }
		    }
		 }
	       else
		 {
		    bool_t test1329_584;
		    test1329_584 = wide_class__100_object_class((obj_t) (class_71));
		    if (test1329_584)
		      {
			 bool_t test1330_585;
			 test1330_585 = wide_class__100_object_class(super_570);
			 if (test1330_585)
			   {
			      {
				 obj_t arg1331_586;
				 obj_t arg1332_587;
				 {
				    type_t obj_1178;
				    obj_1178 = (type_t) (super_570);
				    arg1331_586 = (((type_t) CREF(obj_1178))->id);
				 }
				 {
				    obj_t arg1339_591;
				    arg1339_591 = SYMBOL_TO_STRING(class_id_86_571);
				    {
				       obj_t list1341_593;
				       {
					  obj_t arg1342_594;
					  {
					     obj_t arg1343_595;
					     arg1343_595 = MAKE_PAIR(string1764_object_wide_access_168, BNIL);
					     arg1342_594 = MAKE_PAIR(arg1339_591, arg1343_595);
					  }
					  list1341_593 = MAKE_PAIR(string1763_object_wide_access_168, arg1342_594);
				       }
				       arg1332_587 = string_append_106___r4_strings_6_7(list1341_593);
				    }
				 }
				 {
				    obj_t list1333_588;
				    list1333_588 = MAKE_PAIR(type_type_type, BNIL);
				    return user_error_151_tools_error(arg1331_586, arg1332_587, src_def_101_72, list1333_588);
				 }
			      }
			   }
			 else
			   {
			      bool_t test1345_597;
			      test1345_597 = final_class__126_object_class(super_570);
			      if (test1345_597)
				{
				   bool_t test1346_598;
				   test1346_598 = final_class__126_object_class((obj_t) (class_71));
				   if (test1346_598)
				     {
					{
					   obj_t list1347_599;
					   list1347_599 = MAKE_PAIR(type_type_type, BNIL);
					   return user_error_151_tools_error(class_id_86_571, string1765_object_wide_access_168, src_def_101_72, list1347_599);
					}
				     }
				   else
				     {
					return BTRUE;
				     }
				}
			      else
				{
				   {
				      obj_t arg1350_601;
				      obj_t arg1351_602;
				      {
					 type_t obj_1180;
					 obj_1180 = (type_t) (super_570);
					 arg1350_601 = (((type_t) CREF(obj_1180))->id);
				      }
				      {
					 obj_t arg1356_606;
					 arg1356_606 = SYMBOL_TO_STRING(class_id_86_571);
					 {
					    obj_t list1358_608;
					    {
					       obj_t arg1361_609;
					       {
						  obj_t arg1363_610;
						  arg1363_610 = MAKE_PAIR(string1766_object_wide_access_168, BNIL);
						  arg1361_609 = MAKE_PAIR(arg1356_606, arg1363_610);
					       }
					       list1358_608 = MAKE_PAIR(string1767_object_wide_access_168, arg1361_609);
					    }
					    arg1351_602 = string_append_106___r4_strings_6_7(list1358_608);
					 }
				      }
				      {
					 obj_t list1352_603;
					 list1352_603 = MAKE_PAIR(type_type_type, BNIL);
					 return user_error_151_tools_error(arg1350_601, arg1351_602, src_def_101_72, list1352_603);
				      }
				   }
				}
			   }
		      }
		    else
		      {
			 return internal_error_43_tools_error(string1768_object_wide_access_168, string1769_object_wide_access_168, src_def_101_72);
		      }
		 }
	    }
	 }
      }
   }
}


/* make-wide-class-makes! */ obj_t 
make_wide_class_makes__165_object_wide_access_168(obj_t id_73, type_t type_74, obj_t slots_75, obj_t sslots_76, obj_t src_def_101_77, obj_t import_78)
{
   {
      obj_t mk_heap_id_73_614;
      obj_t mk_stack_id_29_615;
      {
	 obj_t arg1405_646;
	 arg1405_646 = CNST_TABLE_REF(((long) 4));
	 {
	    obj_t list1406_647;
	    {
	       obj_t arg1407_648;
	       arg1407_648 = MAKE_PAIR(id_73, BNIL);
	       list1406_647 = MAKE_PAIR(arg1405_646, arg1407_648);
	    }
	    mk_heap_id_73_614 = symbol_append_197___r4_symbols_6_4(list1406_647);
	 }
      }
      {
	 obj_t arg1410_650;
	 arg1410_650 = CNST_TABLE_REF(((long) 5));
	 {
	    obj_t list1411_651;
	    {
	       obj_t arg1413_652;
	       arg1413_652 = MAKE_PAIR(id_73, BNIL);
	       list1411_651 = MAKE_PAIR(arg1410_650, arg1413_652);
	    }
	    mk_stack_id_29_615 = symbol_append_197___r4_symbols_6_4(list1411_651);
	 }
      }
      {
	 bool_t test1367_616;
	 {
	    bool_t test1403_645;
	    {
	       long n1_1182;
	       n1_1182 = (long) CINT(_optim__89_engine_param);
	       test1403_645 = (n1_1182 < ((long) 2));
	    }
	    if (test1403_645)
	      {
		 test1367_616 = ((bool_t) 1);
	      }
	    else
	      {
		 if (CBOOL(_optim_stack___57_engine_param))
		   {
		      test1367_616 = ((bool_t) 0);
		   }
		 else
		   {
		      test1367_616 = ((bool_t) 1);
		   }
	      }
	 }
	 if (test1367_616)
	   {
	      obj_t arg1368_617;
	      arg1368_617 = make_wide_class_make__242_object_wide_access_168(CNST_TABLE_REF(((long) 6)), id_73, type_74, slots_75, sslots_76, src_def_101_77, import_78);
	      {
		 obj_t list1369_618;
		 list1369_618 = MAKE_PAIR(arg1368_617, BNIL);
		 return list1369_618;
	      }
	   }
	 else
	   {
	      {
		 obj_t arg1373_621;
		 {
		    obj_t arg1375_622;
		    obj_t arg1378_623;
		    arg1375_622 = CNST_TABLE_REF(((long) 7));
		    {
		       obj_t arg1384_628;
		       {
			  obj_t arg1389_633;
			  arg1389_633 = CNST_TABLE_REF(((long) 8));
			  {
			     obj_t list1391_635;
			     {
				obj_t arg1392_636;
				arg1392_636 = MAKE_PAIR(BNIL, BNIL);
				list1391_635 = MAKE_PAIR(mk_stack_id_29_615, arg1392_636);
			     }
			     arg1384_628 = cons__138___r4_pairs_and_lists_6_3(arg1389_633, list1391_635);
			  }
		       }
		       {
			  obj_t list1386_630;
			  {
			     obj_t arg1387_631;
			     arg1387_631 = MAKE_PAIR(BNIL, BNIL);
			     list1386_630 = MAKE_PAIR(arg1384_628, arg1387_631);
			  }
			  arg1378_623 = cons__138___r4_pairs_and_lists_6_3(mk_heap_id_73_614, list1386_630);
		       }
		    }
		    {
		       obj_t list1380_625;
		       {
			  obj_t arg1381_626;
			  arg1381_626 = MAKE_PAIR(BNIL, BNIL);
			  list1380_625 = MAKE_PAIR(arg1378_623, arg1381_626);
		       }
		       arg1373_621 = cons__138___r4_pairs_and_lists_6_3(arg1375_622, list1380_625);
		    }
		 }
		 produce_module_clause__172_module_module(arg1373_621);
	      }
	      {
		 obj_t arg1395_638;
		 obj_t arg1396_639;
		 arg1395_638 = make_wide_class_make__242_object_wide_access_168(CNST_TABLE_REF(((long) 6)), id_73, type_74, slots_75, sslots_76, src_def_101_77, import_78);
		 arg1396_639 = make_wide_class_make__242_object_wide_access_168(CNST_TABLE_REF(((long) 9)), id_73, type_74, slots_75, sslots_76, src_def_101_77, import_78);
		 {
		    obj_t list1397_640;
		    {
		       obj_t arg1398_641;
		       arg1398_641 = MAKE_PAIR(arg1396_639, BNIL);
		       list1397_640 = MAKE_PAIR(arg1395_638, arg1398_641);
		    }
		    return list1397_640;
		 }
	      }
	   }
      }
   }
}


/* make-wide-class-make! */ obj_t 
make_wide_class_make__242_object_wide_access_168(obj_t mk_region_180_79, obj_t id_80, type_t type_81, obj_t slots_82, obj_t sslots_83, obj_t src_def_101_84, obj_t import_85)
{
   {
      obj_t super_654;
      {
	 class_t obj_1186;
	 obj_1186 = (class_t) (type_81);
	 {
	    obj_t aux_1576;
	    {
	       object_t aux_1577;
	       aux_1577 = (object_t) (obj_1186);
	       aux_1576 = OBJECT_WIDENING(aux_1577);
	    }
	    super_654 = (((class_t) CREF(aux_1576))->its_super_214);
	 }
      }
      {
	 global_t holder_655;
	 {
	    class_t obj_1187;
	    obj_1187 = (class_t) (type_81);
	    {
	       obj_t aux_1582;
	       {
		  object_t aux_1583;
		  aux_1583 = (object_t) (obj_1187);
		  aux_1582 = OBJECT_WIDENING(aux_1583);
	       }
	       holder_655 = (((class_t) CREF(aux_1582))->holder);
	    }
	 }
	 {
	    obj_t constrs_656;
	    constrs_656 = find_class_constructors_231_object_class((class_t) (type_81));
	    {
	       obj_t tid_657;
	       tid_657 = (((type_t) CREF(type_81))->id);
	       {
		  obj_t stid_658;
		  {
		     type_t obj_1189;
		     obj_1189 = (type_t) (super_654);
		     stid_658 = (((type_t) CREF(obj_1189))->id);
		  }
		  {
		     obj_t mk_tid_99_659;
		     {
			obj_t arg1647_854;
			arg1647_854 = CNST_TABLE_REF(((long) 10));
			{
			   obj_t list1648_855;
			   {
			      obj_t arg1649_856;
			      {
				 obj_t arg1650_857;
				 {
				    obj_t arg1652_858;
				    {
				       obj_t arg1653_859;
				       arg1653_859 = MAKE_PAIR(tid_657, BNIL);
				       arg1652_858 = MAKE_PAIR(_4dots_199_tools_misc, arg1653_859);
				    }
				    arg1650_857 = MAKE_PAIR(id_80, arg1652_858);
				 }
				 arg1649_856 = MAKE_PAIR(mk_region_180_79, arg1650_857);
			      }
			      list1648_855 = MAKE_PAIR(arg1647_854, arg1649_856);
			   }
			   mk_tid_99_659 = symbol_append_197___r4_symbols_6_4(list1648_855);
			}
		     }
		     {
			obj_t f_ids_164_660;
			f_ids_164_660 = make_class_make_formals_23_object_access(slots_82);
			{
			   obj_t sf_ids_190_661;
			   sf_ids_190_661 = make_class_make_formals_23_object_access(sslots_83);
			   {
			      obj_t f_tids_193_662;
			      f_tids_193_662 = make_class_make_typed_formals_184_object_access(slots_82);
			      {
				 obj_t sf_tids_42_663;
				 sf_tids_42_663 = make_class_make_typed_formals_184_object_access(sslots_83);
				 {
				    obj_t widening_664;
				    {
				       obj_t arg1638_848;
				       {
					  class_t obj_1190;
					  obj_1190 = (class_t) (type_81);
					  {
					     obj_t aux_1604;
					     {
						object_t aux_1605;
						aux_1605 = (object_t) (obj_1190);
						aux_1604 = OBJECT_WIDENING(aux_1605);
					     }
					     arg1638_848 = (((class_t) CREF(aux_1604))->widening);
					  }
				       }
				       {
					  obj_t list1640_850;
					  {
					     obj_t arg1641_851;
					     {
						obj_t arg1645_852;
						{
						   obj_t aux_1609;
						   aux_1609 = (((type_t) CREF(type_81))->id);
						   arg1645_852 = MAKE_PAIR(aux_1609, BNIL);
						}
						arg1641_851 = MAKE_PAIR(mk_region_180_79, arg1645_852);
					     }
					     list1640_850 = MAKE_PAIR(arg1638_848, arg1641_851);
					  }
					  widening_664 = symbol_append_197___r4_symbols_6_4(list1640_850);
				       }
				    }
				    {
				       obj_t aux_665;
				       aux_665 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 11)), BEOA);
				       {
					  obj_t new_666;
					  new_666 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 12)), BEOA);
					  {
					     obj_t mk_class_id_234_667;
					     {
						obj_t arg1628_841;
						arg1628_841 = CNST_TABLE_REF(((long) 10));
						{
						   obj_t list1629_842;
						   {
						      obj_t arg1630_843;
						      {
							 obj_t arg1632_844;
							 arg1632_844 = MAKE_PAIR(stid_658, BNIL);
							 arg1630_843 = MAKE_PAIR(mk_region_180_79, arg1632_844);
						      }
						      list1629_842 = MAKE_PAIR(arg1628_841, arg1630_843);
						   }
						   mk_class_id_234_667 = symbol_append_197___r4_symbols_6_4(list1629_842);
						}
					     }
					     {
						{
						   obj_t arg1415_668;
						   {
						      obj_t arg1416_669;
						      {
							 obj_t arg1423_674;
							 {
							    obj_t arg1426_676;
							    obj_t arg1427_677;
							    {
							       bool_t test1428_678;
							       {
								  long n1_1192;
								  n1_1192 = (long) CINT(_optim__89_engine_param);
								  test1428_678 = (n1_1192 >= ((long) 2));
							       }
							       if (test1428_678)
								 {
								    arg1426_676 = CNST_TABLE_REF(((long) 13));
								 }
							       else
								 {
								    arg1426_676 = BNIL;
								 }
							    }
							    {
							       obj_t arg1431_679;
							       {
								  obj_t arg1436_682;
								  {
								     obj_t arg1437_683;
								     {
									obj_t arg1440_685;
									arg1440_685 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
									arg1437_683 = append_2_18___r4_pairs_and_lists_6_3(f_tids_193_662, arg1440_685);
								     }
								     arg1436_682 = cons__138___r4_pairs_and_lists_6_3(arg1437_683, BNIL);
								  }
								  arg1431_679 = append_2_18___r4_pairs_and_lists_6_3(sf_tids_42_663, arg1436_682);
							       }
							       {
								  obj_t list1432_680;
								  list1432_680 = MAKE_PAIR(arg1431_679, BNIL);
								  arg1427_677 = cons__138___r4_pairs_and_lists_6_3(mk_tid_99_659, list1432_680);
							       }
							    }
							    arg1423_674 = append_2_18___r4_pairs_and_lists_6_3(arg1426_676, arg1427_677);
							 }
							 arg1416_669 = cons__138___r4_pairs_and_lists_6_3(arg1423_674, BNIL);
						      }
						      {
							 obj_t list1418_671;
							 {
							    obj_t arg1419_672;
							    arg1419_672 = MAKE_PAIR(BNIL, BNIL);
							    list1418_671 = MAKE_PAIR(arg1416_669, arg1419_672);
							 }
							 arg1415_668 = cons__138___r4_pairs_and_lists_6_3(import_85, list1418_671);
						      }
						   }
						   produce_module_clause__172_module_module(arg1415_668);
						}
						{
						   obj_t arg1443_688;
						   {
						      obj_t arg1448_691;
						      obj_t arg1449_692;
						      obj_t arg1450_693;
						      {
							 bool_t test1459_699;
							 {
							    long n1_1194;
							    n1_1194 = (long) CINT(_optim__89_engine_param);
							    test1459_699 = (n1_1194 >= ((long) 2));
							 }
							 if (test1459_699)
							   {
							      arg1448_691 = CNST_TABLE_REF(((long) 14));
							   }
							 else
							   {
							      arg1448_691 = CNST_TABLE_REF(((long) 15));
							   }
						      }
						      {
							 obj_t arg1460_700;
							 {
							    obj_t arg1464_703;
							    {
							       obj_t arg1465_704;
							       {
								  obj_t arg1467_706;
								  arg1467_706 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
								  arg1465_704 = append_2_18___r4_pairs_and_lists_6_3(f_tids_193_662, arg1467_706);
							       }
							       arg1464_703 = cons__138___r4_pairs_and_lists_6_3(arg1465_704, BNIL);
							    }
							    arg1460_700 = append_2_18___r4_pairs_and_lists_6_3(sf_tids_42_663, arg1464_703);
							 }
							 {
							    obj_t list1461_701;
							    list1461_701 = MAKE_PAIR(arg1460_700, BNIL);
							    arg1449_692 = cons__138___r4_pairs_and_lists_6_3(mk_tid_99_659, list1461_701);
							 }
						      }
						      {
							 obj_t arg1470_709;
							 obj_t arg1471_710;
							 obj_t arg1473_711;
							 arg1470_709 = CNST_TABLE_REF(((long) 16));
							 {
							    obj_t arg1479_717;
							    {
							       obj_t arg1484_721;
							       obj_t arg1485_722;
							       {
								  obj_t list1490_727;
								  {
								     obj_t arg1491_728;
								     {
									obj_t arg1494_729;
									arg1494_729 = MAKE_PAIR(stid_658, BNIL);
									arg1491_728 = MAKE_PAIR(_4dots_199_tools_misc, arg1494_729);
								     }
								     list1490_727 = MAKE_PAIR(aux_665, arg1491_728);
								  }
								  arg1484_721 = symbol_append_197___r4_symbols_6_4(list1490_727);
							       }
							       {
								  obj_t arg1497_731;
								  {
								     obj_t arg1500_734;
								     arg1500_734 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
								     arg1497_731 = append_2_18___r4_pairs_and_lists_6_3(sf_ids_190_661, arg1500_734);
								  }
								  {
								     obj_t list1498_732;
								     list1498_732 = MAKE_PAIR(arg1497_731, BNIL);
								     arg1485_722 = cons__138___r4_pairs_and_lists_6_3(mk_class_id_234_667, list1498_732);
								  }
							       }
							       {
								  obj_t list1487_724;
								  {
								     obj_t arg1488_725;
								     arg1488_725 = MAKE_PAIR(BNIL, BNIL);
								     list1487_724 = MAKE_PAIR(arg1485_722, arg1488_725);
								  }
								  arg1479_717 = cons__138___r4_pairs_and_lists_6_3(arg1484_721, list1487_724);
							       }
							    }
							    {
							       obj_t list1481_719;
							       list1481_719 = MAKE_PAIR(BNIL, BNIL);
							       arg1471_710 = cons__138___r4_pairs_and_lists_6_3(arg1479_717, list1481_719);
							    }
							 }
							 {
							    obj_t arg1503_737;
							    obj_t arg1504_738;
							    obj_t arg1505_739;
							    obj_t arg1507_740;
							    obj_t arg1510_741;
							    arg1503_737 = CNST_TABLE_REF(((long) 16));
							    {
							       obj_t arg1517_747;
							       {
								  obj_t arg1524_751;
								  obj_t arg1525_752;
								  {
								     obj_t list1530_757;
								     {
									obj_t arg1531_758;
									{
									   obj_t arg1532_759;
									   arg1532_759 = MAKE_PAIR(tid_657, BNIL);
									   arg1531_758 = MAKE_PAIR(_4dots_199_tools_misc, arg1532_759);
									}
									list1530_757 = MAKE_PAIR(new_666, arg1531_758);
								     }
								     arg1524_751 = symbol_append_197___r4_symbols_6_4(list1530_757);
								  }
								  {
								     obj_t arg1534_761;
								     obj_t arg1535_762;
								     {
									obj_t arg1545_768;
									arg1545_768 = CNST_TABLE_REF(((long) 17));
									{
									   obj_t list1546_769;
									   {
									      obj_t arg1548_770;
									      {
										 obj_t arg1549_771;
										 arg1549_771 = MAKE_PAIR(tid_657, BNIL);
										 arg1548_770 = MAKE_PAIR(_4dots_199_tools_misc, arg1549_771);
									      }
									      list1546_769 = MAKE_PAIR(arg1545_768, arg1548_770);
									   }
									   arg1534_761 = symbol_append_197___r4_symbols_6_4(list1546_769);
									}
								     }
								     {
									obj_t arg1553_774;
									arg1553_774 = (((type_t) CREF(type_81))->name);
									{
									   obj_t list1555_776;
									   {
									      obj_t arg1556_777;
									      {
										 obj_t arg1557_778;
										 arg1557_778 = MAKE_PAIR(string1770_object_wide_access_168, BNIL);
										 arg1556_777 = MAKE_PAIR(arg1553_774, arg1557_778);
									      }
									      list1555_776 = MAKE_PAIR(string1771_object_wide_access_168, arg1556_777);
									   }
									   arg1535_762 = string_append_106___r4_strings_6_7(list1555_776);
									}
								     }
								     {
									obj_t list1537_764;
									{
									   obj_t arg1539_765;
									   {
									      obj_t arg1540_766;
									      arg1540_766 = MAKE_PAIR(BNIL, BNIL);
									      arg1539_765 = MAKE_PAIR(aux_665, arg1540_766);
									   }
									   list1537_764 = MAKE_PAIR(arg1535_762, arg1539_765);
									}
									arg1525_752 = cons__138___r4_pairs_and_lists_6_3(arg1534_761, list1537_764);
								     }
								  }
								  {
								     obj_t list1527_754;
								     {
									obj_t arg1528_755;
									arg1528_755 = MAKE_PAIR(BNIL, BNIL);
									list1527_754 = MAKE_PAIR(arg1525_752, arg1528_755);
								     }
								     arg1517_747 = cons__138___r4_pairs_and_lists_6_3(arg1524_751, list1527_754);
								  }
							       }
							       {
								  obj_t list1519_749;
								  list1519_749 = MAKE_PAIR(BNIL, BNIL);
								  arg1504_738 = cons__138___r4_pairs_and_lists_6_3(arg1517_747, list1519_749);
							       }
							    }
							    {
							       obj_t arg1559_780;
							       obj_t arg1560_781;
							       arg1559_780 = CNST_TABLE_REF(((long) 18));
							       {
								  obj_t arg1566_787;
								  obj_t arg1568_788;
								  arg1566_787 = CNST_TABLE_REF(((long) 19));
								  {
								     obj_t arg1575_793;
								     obj_t arg1578_794;
								     obj_t arg1580_795;
								     arg1575_793 = CNST_TABLE_REF(((long) 20));
								     arg1578_794 = (((global_t) CREF(holder_655))->id);
								     arg1580_795 = (((global_t) CREF(holder_655))->module);
								     {
									obj_t list1582_797;
									{
									   obj_t arg1583_798;
									   {
									      obj_t arg1584_799;
									      arg1584_799 = MAKE_PAIR(BNIL, BNIL);
									      arg1583_798 = MAKE_PAIR(arg1580_795, arg1584_799);
									   }
									   list1582_797 = MAKE_PAIR(arg1578_794, arg1583_798);
									}
									arg1568_788 = cons__138___r4_pairs_and_lists_6_3(arg1575_793, list1582_797);
								     }
								  }
								  {
								     obj_t list1570_790;
								     {
									obj_t arg1572_791;
									arg1572_791 = MAKE_PAIR(BNIL, BNIL);
									list1570_790 = MAKE_PAIR(arg1568_788, arg1572_791);
								     }
								     arg1560_781 = cons__138___r4_pairs_and_lists_6_3(arg1566_787, list1570_790);
								  }
							       }
							       {
								  obj_t list1562_783;
								  {
								     obj_t arg1563_784;
								     {
									obj_t arg1564_785;
									arg1564_785 = MAKE_PAIR(BNIL, BNIL);
									arg1563_784 = MAKE_PAIR(arg1560_781, arg1564_785);
								     }
								     list1562_783 = MAKE_PAIR(new_666, arg1563_784);
								  }
								  arg1505_739 = cons__138___r4_pairs_and_lists_6_3(arg1559_780, list1562_783);
							       }
							    }
							    {
							       obj_t arg1586_801;
							       obj_t arg1587_802;
							       arg1586_801 = CNST_TABLE_REF(((long) 21));
							       {
								  obj_t arg1595_808;
								  {
								     obj_t arg1600_811;
								     arg1600_811 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
								     arg1595_808 = append_2_18___r4_pairs_and_lists_6_3(f_ids_164_660, arg1600_811);
								  }
								  {
								     obj_t list1596_809;
								     list1596_809 = MAKE_PAIR(arg1595_808, BNIL);
								     arg1587_802 = cons__138___r4_pairs_and_lists_6_3(widening_664, list1596_809);
								  }
							       }
							       {
								  obj_t list1589_804;
								  {
								     obj_t arg1592_805;
								     {
									obj_t arg1593_806;
									arg1593_806 = MAKE_PAIR(BNIL, BNIL);
									arg1592_805 = MAKE_PAIR(arg1587_802, arg1593_806);
								     }
								     list1589_804 = MAKE_PAIR(new_666, arg1592_805);
								  }
								  arg1507_740 = cons__138___r4_pairs_and_lists_6_3(arg1586_801, list1589_804);
							       }
							    }
							    {
							       obj_t arg1605_814;
							       obj_t arg1606_815;
							       {
								  bool_t test_1716;
								  if (PAIRP(constrs_656))
								    {
								       bool_t test_1719;
								       {
									  obj_t aux_1720;
									  aux_1720 = CNST_TABLE_REF(((long) 3));
									  test_1719 = (widening_664 == aux_1720);
								       }
								       if (test_1719)
									 {
									    test_1716 = ((bool_t) 0);
									 }
								       else
									 {
									    test_1716 = ((bool_t) 1);
									 }
								    }
								  else
								    {
								       test_1716 = ((bool_t) 0);
								    }
								  if (test_1716)
								    {
								       if (NULLP(constrs_656))
									 {
									    arg1605_814 = BNIL;
									 }
								       else
									 {
									    obj_t head1219_819;
									    head1219_819 = MAKE_PAIR(BNIL, BNIL);
									    {
									       obj_t l1217_820;
									       obj_t tail1220_821;
									       l1217_820 = constrs_656;
									       tail1220_821 = head1219_819;
									     lname1218_822:
									       if (NULLP(l1217_820))
										 {
										    arg1605_814 = CDR(head1219_819);
										 }
									       else
										 {
										    obj_t newtail1221_824;
										    {
										       obj_t arg1612_826;
										       {
											  obj_t constr_828;
											  constr_828 = CAR(l1217_820);
											  {
											     obj_t list1616_830;
											     {
												obj_t arg1617_831;
												arg1617_831 = MAKE_PAIR(BNIL, BNIL);
												list1616_830 = MAKE_PAIR(new_666, arg1617_831);
											     }
											     arg1612_826 = cons__138___r4_pairs_and_lists_6_3(constr_828, list1616_830);
											  }
										       }
										       newtail1221_824 = MAKE_PAIR(arg1612_826, BNIL);
										    }
										    SET_CDR(tail1220_821, newtail1221_824);
										    {
										       obj_t tail1220_1737;
										       obj_t l1217_1735;
										       l1217_1735 = CDR(l1217_820);
										       tail1220_1737 = newtail1221_824;
										       tail1220_821 = tail1220_1737;
										       l1217_820 = l1217_1735;
										       goto lname1218_822;
										    }
										 }
									    }
									 }
								    }
								  else
								    {
								       arg1605_814 = BNIL;
								    }
							       }
							       {
								  obj_t list1626_839;
								  list1626_839 = MAKE_PAIR(BNIL, BNIL);
								  arg1606_815 = cons__138___r4_pairs_and_lists_6_3(new_666, list1626_839);
							       }
							       arg1510_741 = append_2_18___r4_pairs_and_lists_6_3(arg1605_814, arg1606_815);
							    }
							    {
							       obj_t list1511_742;
							       {
								  obj_t arg1513_743;
								  {
								     obj_t arg1514_744;
								     {
									obj_t arg1515_745;
									arg1515_745 = MAKE_PAIR(arg1510_741, BNIL);
									arg1514_744 = MAKE_PAIR(arg1507_740, arg1515_745);
								     }
								     arg1513_743 = MAKE_PAIR(arg1505_739, arg1514_744);
								  }
								  list1511_742 = MAKE_PAIR(arg1504_738, arg1513_743);
							       }
							       arg1473_711 = cons__138___r4_pairs_and_lists_6_3(arg1503_737, list1511_742);
							    }
							 }
							 {
							    obj_t list1475_713;
							    {
							       obj_t arg1476_714;
							       {
								  obj_t arg1477_715;
								  arg1477_715 = MAKE_PAIR(BNIL, BNIL);
								  arg1476_714 = MAKE_PAIR(arg1473_711, arg1477_715);
							       }
							       list1475_713 = MAKE_PAIR(arg1471_710, arg1476_714);
							    }
							    arg1450_693 = cons__138___r4_pairs_and_lists_6_3(arg1470_709, list1475_713);
							 }
						      }
						      {
							 obj_t list1454_695;
							 {
							    obj_t arg1455_696;
							    {
							       obj_t arg1456_697;
							       arg1456_697 = MAKE_PAIR(BNIL, BNIL);
							       arg1455_696 = MAKE_PAIR(arg1450_693, arg1456_697);
							    }
							    list1454_695 = MAKE_PAIR(arg1449_692, arg1455_696);
							 }
							 arg1443_688 = cons__138___r4_pairs_and_lists_6_3(arg1448_691, list1454_695);
						      }
						   }
						   {
						      obj_t list1444_689;
						      list1444_689 = MAKE_PAIR(src_def_101_84, BNIL);
						      return epairify_object_access(arg1443_688, list1444_689);
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* import-wide-class-makes! */ obj_t 
import_wide_class_makes__40_object_wide_access_168(obj_t id_86, type_t type_87, obj_t slots_88, obj_t sslots_89, obj_t src_def_101_90, obj_t module_91)
{
   {
      obj_t mk_heap_id_73_861;
      obj_t mk_stack_id_29_862;
      {
	 obj_t arg1659_867;
	 arg1659_867 = CNST_TABLE_REF(((long) 4));
	 {
	    obj_t list1660_868;
	    {
	       obj_t arg1661_869;
	       arg1661_869 = MAKE_PAIR(id_86, BNIL);
	       list1660_868 = MAKE_PAIR(arg1659_867, arg1661_869);
	    }
	    mk_heap_id_73_861 = symbol_append_197___r4_symbols_6_4(list1660_868);
	 }
      }
      {
	 obj_t arg1665_871;
	 arg1665_871 = CNST_TABLE_REF(((long) 5));
	 {
	    obj_t list1666_872;
	    {
	       obj_t arg1667_873;
	       arg1667_873 = MAKE_PAIR(id_86, BNIL);
	       list1666_872 = MAKE_PAIR(arg1665_871, arg1667_873);
	    }
	    mk_stack_id_29_862 = symbol_append_197___r4_symbols_6_4(list1666_872);
	 }
      }
      {
	 obj_t arg1655_863;
	 arg1655_863 = import_wide_class_make__56_object_wide_access_168(CNST_TABLE_REF(((long) 6)), id_86, type_87, slots_88, sslots_89, src_def_101_90, module_91);
	 {
	    obj_t list1656_864;
	    list1656_864 = MAKE_PAIR(arg1655_863, BNIL);
	    return list1656_864;
	 }
      }
   }
}


/* import-wide-class-make! */ obj_t 
import_wide_class_make__56_object_wide_access_168(obj_t mk_region_180_92, obj_t id_93, type_t type_94, obj_t slots_95, obj_t sslots_96, obj_t src_def_101_97, obj_t module_98)
{
   {
      obj_t mk_tid_99_876;
      {
	 obj_t arg1709_931;
	 arg1709_931 = CNST_TABLE_REF(((long) 10));
	 {
	    obj_t list1710_932;
	    {
	       obj_t arg1711_933;
	       {
		  obj_t arg1712_934;
		  {
		     obj_t arg1713_935;
		     {
			obj_t arg1714_936;
			{
			   obj_t aux_1768;
			   aux_1768 = (((type_t) CREF(type_94))->id);
			   arg1714_936 = MAKE_PAIR(aux_1768, BNIL);
			}
			arg1713_935 = MAKE_PAIR(_4dots_199_tools_misc, arg1714_936);
		     }
		     arg1712_934 = MAKE_PAIR(id_93, arg1713_935);
		  }
		  arg1711_933 = MAKE_PAIR(mk_region_180_92, arg1712_934);
	       }
	       list1710_932 = MAKE_PAIR(arg1709_931, arg1711_933);
	    }
	    mk_tid_99_876 = symbol_append_197___r4_symbols_6_4(list1710_932);
	 }
      }
      {
	 obj_t f_tids_193_877;
	 if (NULLP(slots_95))
	   {
	      f_tids_193_877 = BNIL;
	   }
	 else
	   {
	      obj_t head1224_912;
	      head1224_912 = MAKE_PAIR(BNIL, BNIL);
	      {
		 obj_t l1222_913;
		 obj_t tail1225_914;
		 l1222_913 = slots_95;
		 tail1225_914 = head1224_912;
	       lname1223_915:
		 if (NULLP(l1222_913))
		   {
		      f_tids_193_877 = CDR(head1224_912);
		   }
		 else
		   {
		      obj_t newtail1226_917;
		      {
			 obj_t arg1698_919;
			 {
			    obj_t slot_921;
			    slot_921 = CAR(l1222_913);
			    {
			       obj_t arg1700_922;
			       arg1700_922 = STRUCT_REF(slot_921, ((long) 0));
			       {
				  obj_t list1702_924;
				  {
				     obj_t arg1703_925;
				     {
					obj_t arg1704_926;
					{
					   obj_t aux_1784;
					   {
					      type_t obj_1227;
					      {
						 obj_t aux_1785;
						 aux_1785 = STRUCT_REF(slot_921, ((long) 2));
						 obj_1227 = (type_t) (aux_1785);
					      }
					      aux_1784 = (((type_t) CREF(obj_1227))->id);
					   }
					   arg1704_926 = MAKE_PAIR(aux_1784, BNIL);
					}
					arg1703_925 = MAKE_PAIR(_4dots_199_tools_misc, arg1704_926);
				     }
				     list1702_924 = MAKE_PAIR(arg1700_922, arg1703_925);
				  }
				  arg1698_919 = symbol_append_197___r4_symbols_6_4(list1702_924);
			       }
			    }
			 }
			 newtail1226_917 = MAKE_PAIR(arg1698_919, BNIL);
		      }
		      SET_CDR(tail1225_914, newtail1226_917);
		      {
			 obj_t tail1225_1797;
			 obj_t l1222_1795;
			 l1222_1795 = CDR(l1222_913);
			 tail1225_1797 = newtail1226_917;
			 tail1225_914 = tail1225_1797;
			 l1222_913 = l1222_1795;
			 goto lname1223_915;
		      }
		   }
	      }
	   }
	 {
	    obj_t sf_tids_42_878;
	    if (NULLP(sslots_96))
	      {
		 sf_tids_42_878 = BNIL;
	      }
	    else
	      {
		 obj_t head1229_891;
		 head1229_891 = MAKE_PAIR(BNIL, BNIL);
		 {
		    obj_t l1227_892;
		    obj_t tail1230_893;
		    l1227_892 = sslots_96;
		    tail1230_893 = head1229_891;
		  lname1228_894:
		    if (NULLP(l1227_892))
		      {
			 sf_tids_42_878 = CDR(head1229_891);
		      }
		    else
		      {
			 obj_t newtail1231_896;
			 {
			    obj_t arg1683_898;
			    {
			       obj_t slot_900;
			       slot_900 = CAR(l1227_892);
			       {
				  obj_t arg1685_901;
				  arg1685_901 = STRUCT_REF(slot_900, ((long) 0));
				  {
				     obj_t list1687_903;
				     {
					obj_t arg1688_904;
					{
					   obj_t arg1689_905;
					   {
					      obj_t aux_1806;
					      {
						 type_t obj_1245;
						 {
						    obj_t aux_1807;
						    aux_1807 = STRUCT_REF(slot_900, ((long) 2));
						    obj_1245 = (type_t) (aux_1807);
						 }
						 aux_1806 = (((type_t) CREF(obj_1245))->id);
					      }
					      arg1689_905 = MAKE_PAIR(aux_1806, BNIL);
					   }
					   arg1688_904 = MAKE_PAIR(_4dots_199_tools_misc, arg1689_905);
					}
					list1687_903 = MAKE_PAIR(arg1685_901, arg1688_904);
				     }
				     arg1683_898 = symbol_append_197___r4_symbols_6_4(list1687_903);
				  }
			       }
			    }
			    newtail1231_896 = MAKE_PAIR(arg1683_898, BNIL);
			 }
			 SET_CDR(tail1230_893, newtail1231_896);
			 {
			    obj_t tail1230_1819;
			    obj_t l1227_1817;
			    l1227_1817 = CDR(l1227_892);
			    tail1230_1819 = newtail1231_896;
			    tail1230_893 = tail1230_1819;
			    l1227_892 = l1227_1817;
			    goto lname1228_894;
			 }
		      }
		 }
	      }
	    {
	       {
		  obj_t arg1669_879;
		  {
		     obj_t arg1670_880;
		     {
			obj_t arg1673_883;
			{
			   obj_t arg1675_884;
			   {
			      obj_t arg1677_886;
			      arg1677_886 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
			      arg1675_884 = append_2_18___r4_pairs_and_lists_6_3(f_tids_193_877, arg1677_886);
			   }
			   arg1673_883 = cons__138___r4_pairs_and_lists_6_3(arg1675_884, BNIL);
			}
			arg1670_880 = append_2_18___r4_pairs_and_lists_6_3(sf_tids_42_878, arg1673_883);
		     }
		     {
			obj_t list1671_881;
			list1671_881 = MAKE_PAIR(arg1670_880, BNIL);
			arg1669_879 = cons__138___r4_pairs_and_lists_6_3(mk_tid_99_876, list1671_881);
		     }
		  }
		  return import_parser_53_module_impuse(module_98, arg1669_879);
	       }
	    }
	 }
      }
   }
}


/* method-init */ obj_t 
method_init_76_object_wide_access_168()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_object_wide_access_168()
{
   module_initialization_70_tools_trace(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_tools_error(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_tools_misc(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_type_type(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_type_env(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_type_tools(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_type_cache(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_ast_var(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_ast_ident(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_object_class(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_object_struct(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_object_slots(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_object_tools(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_object_access(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_module_module(((long) 0), "OBJECT_WIDE-ACCESS");
   module_initialization_70_module_impuse(((long) 0), "OBJECT_WIDE-ACCESS");
   return module_initialization_70_engine_param(((long) 0), "OBJECT_WIDE-ACCESS");
}
