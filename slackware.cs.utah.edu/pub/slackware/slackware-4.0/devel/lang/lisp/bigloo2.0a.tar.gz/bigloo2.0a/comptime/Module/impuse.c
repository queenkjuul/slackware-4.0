/*===========================================================================*/
/*   (Module/impuse.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;

typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t ccomp_module_module;
extern global_t declare_global_sfun__255_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t body1197_module_impuse(obj_t);
static obj_t method_init_76_module_impuse();
extern obj_t get_imported_modules_153_module_impuse();
static obj_t import_1_module_184_module_impuse(obj_t, obj_t, obj_t);
extern obj_t _access_table__91_engine_param;
static obj_t _import_parser_19_module_impuse(obj_t, obj_t, obj_t);
extern obj_t inline_finalizer_105_read_inline();
extern obj_t current_error_port;
extern obj_t exitd_top;
extern obj_t _load_path__54___eval;
static obj_t _make_use_compiler_39_module_impuse(obj_t);
extern obj_t type_type_type;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t make_use_compiler_106_module_impuse();
static obj_t handling_function1566_module_impuse(obj_t, obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t global_ast_var;
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t fast_id_of_id_130_ast_ident(obj_t);
extern obj_t import_with_module__247_module_impuse(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t read_imported_module_112_module_impuse(obj_t);
extern obj_t module_initialization_70_module_impuse(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_read_reader(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70_module_prototype(long, char *);
extern obj_t module_initialization_70_module_class(long, char *);
extern obj_t module_initialization_70_module_include(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_read_access(long, char *);
extern obj_t module_initialization_70_read_inline(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_find_gdefs_13(long, char *);
extern obj_t module_initialization_70_ast_glo_decl_237(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern obj_t consume_module__183_module_module(obj_t, obj_t);
static obj_t _make_import_compiler_114_module_impuse(obj_t);
static obj_t import_wanted_18_module_impuse(obj_t, obj_t, obj_t);
extern obj_t compiler_read_18_read_reader(obj_t);
static obj_t impuse_parser_37_module_impuse(obj_t, obj_t);
static obj_t _make_from_compiler_253_module_impuse(obj_t);
static obj_t _import_module_list__76_module_impuse = BUNSPEC;
extern long class_num_218___object(obj_t);
extern obj_t exit_bigloo_229_init_main(obj_t);
extern obj_t module_initialization_id_110_module_module(obj_t);
static obj_t imported_modules_init_94_module_impuse();
static obj_t _imported_module_list__84_module_impuse = BUNSPEC;
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t reset_include_consumed_code__8_module_include();
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
static obj_t import_all_module_109_module_impuse(obj_t, obj_t);
static obj_t rhandler1196_module_impuse(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t handler_module_impuse(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t get_include_consumed_code_244_module_include();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t import_parser_53_module_impuse(obj_t, obj_t);
static obj_t library_modules_init_112_module_impuse();
static obj_t import_everything_193_module_impuse(obj_t, obj_t);
extern global_t declare_global_svar__200_ast_glo_decl_237(obj_t, obj_t, obj_t, obj_t);
extern obj_t make_import_compiler_148_module_impuse();
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_module_impuse();
extern obj_t open_input_string(obj_t);
extern obj_t add_access__140_read_access(obj_t, obj_t);
extern obj_t sfun_ast_var;
extern obj_t get_include_consumed_directive_80_module_include();
extern obj_t look_for_inline_98_read_inline(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t remq__51___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _impuse_finalizer_29_module_impuse(obj_t);
static obj_t arg1569_module_impuse(obj_t);
static obj_t arg1568_module_impuse(obj_t);
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t declare_class__31_module_class(obj_t, obj_t, obj_t, bool_t, obj_t);
extern obj_t close_input_port(obj_t);
static obj_t impuse_producer_187_module_impuse(obj_t);
static obj_t _get_imported_modules_109_module_impuse(obj_t);
static obj_t arg1252_module_impuse(obj_t, obj_t, obj_t);
static obj_t arg1251_module_impuse(obj_t);
static obj_t arg1250_module_impuse(obj_t, obj_t, obj_t);
static obj_t arg1243_module_impuse(obj_t, obj_t, obj_t);
static obj_t arg1240_module_impuse(obj_t, obj_t, obj_t);
static obj_t arg1232_module_impuse(obj_t, obj_t, obj_t);
static obj_t arg1231_module_impuse(obj_t);
static obj_t arg1228_module_impuse(obj_t, obj_t, obj_t);
extern obj_t checksum_module_8_module_module(obj_t);
extern obj_t _module__166_module_module;
extern obj_t make_from_compiler_140_module_impuse();
extern obj_t remove_error_handler__102___error();
static obj_t import_finalizer_66_module_impuse();
static obj_t impuse_finalizer_42_module_impuse();
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t escape_module_impuse(obj_t, obj_t);
extern obj_t declare_wide_class__13_module_class(obj_t, obj_t, obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_module_impuse = BUNSPEC;
extern obj_t parse_prototype_143_module_prototype(obj_t);
static obj_t _impuse_producer_249_module_impuse(obj_t, obj_t);
static obj_t _import_with_module__232_module_impuse(obj_t, obj_t);
extern obj_t reset_include_consumed_directive__234_module_include();
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
static obj_t cnst_init_137_module_impuse();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[20];

DEFINE_STATIC_PROCEDURE(impuse_finalizer_env_73_module_impuse, _impuse_finalizer_29_module_impuse1730, _impuse_finalizer_29_module_impuse, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_use_compiler_env_17_module_impuse, _make_use_compiler_39_module_impuse1731, _make_use_compiler_39_module_impuse, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1709_module_impuse, arg1251_module_impuse1732, arg1251_module_impuse, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1710_module_impuse, arg1250_module_impuse1733, arg1250_module_impuse, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1708_module_impuse, arg1252_module_impuse1734, arg1252_module_impuse, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1707_module_impuse, arg1240_module_impuse1735, arg1240_module_impuse, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1706_module_impuse, arg1243_module_impuse1736, arg1243_module_impuse, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1705_module_impuse, arg1228_module_impuse1737, arg1228_module_impuse, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1704_module_impuse, arg1231_module_impuse1738, arg1231_module_impuse, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1703_module_impuse, arg1232_module_impuse1739, arg1232_module_impuse, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_import_compiler_env_82_module_impuse, _make_import_compiler_114_module_impuse1740, _make_import_compiler_114_module_impuse, 0L, 0);
DEFINE_EXPORT_PROCEDURE(import_parser_env_92_module_impuse, _import_parser_19_module_impuse1741, _import_parser_19_module_impuse, 0L, 2);
DEFINE_EXPORT_PROCEDURE(import_with_module__env_62_module_impuse, _import_with_module__232_module_impuse1742, _import_with_module__232_module_impuse, 0L, 1);
DEFINE_EXPORT_PROCEDURE(get_imported_modules_env_216_module_impuse, _get_imported_modules_109_module_impuse1743, _get_imported_modules_109_module_impuse, 0L, 0);
DEFINE_STRING(string1724_module_impuse, string1724_module_impuse1744, "SIFUN WIDE-CLASS FINAL-CLASS CLASS SVAR (SFUN SIFUN SGFUN) (IMPORT WITH FROM) @ FROM::STRING CHECKSUM::LONG UNIT IMPORTED-MODULES NOTHING WITH IMODE ALL FROM USE VOID IMPORT ", 174);
DEFINE_STRING(string1723_module_impuse, string1723_module_impuse1745, "Can't find exportation for these identifiers", 44);
DEFINE_STRING(string1722_module_impuse, string1722_module_impuse1746, "Can't find such module", 22);
DEFINE_STRING(string1721_module_impuse, string1721_module_impuse1747, "Can't open such file", 20);
DEFINE_STRING(string1719_module_impuse, string1719_module_impuse1748, "      [reading ", 15);
DEFINE_STRING(string1720_module_impuse, string1720_module_impuse1749, "read-imported-module", 20);
DEFINE_STRING(string1718_module_impuse, string1718_module_impuse1750, " module ", 8);
DEFINE_STRING(string1717_module_impuse, string1717_module_impuse1751, "]", 1);
DEFINE_STRING(string1716_module_impuse, string1716_module_impuse1752, "Illegal prototype", 17);
DEFINE_STRING(string1715_module_impuse, string1715_module_impuse1753, "Illegal `import/use' clause", 27);
DEFINE_STRING(string1714_module_impuse, string1714_module_impuse1754, "Illegal imported clause", 23);
DEFINE_STRING(string1713_module_impuse, string1713_module_impuse1755, "Parse error", 11);
DEFINE_STRING(string1712_module_impuse, string1712_module_impuse1756, "Illegal `", 9);
DEFINE_STRING(string1711_module_impuse, string1711_module_impuse1757, "' clause", 8);
DEFINE_EXPORT_PROCEDURE(make_from_compiler_env_143_module_impuse, _make_from_compiler_253_module_impuse1758, _make_from_compiler_253_module_impuse, 0L, 0);
DEFINE_STATIC_PROCEDURE(impuse_producer_env_151_module_impuse, _impuse_producer_249_module_impuse1759, _impuse_producer_249_module_impuse, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_module_impuse(long checksum_1723, char *from_1724)
{
   if (CBOOL(require_initialization_114_module_impuse))
     {
	require_initialization_114_module_impuse = BBOOL(((bool_t) 0));
	library_modules_init_112_module_impuse();
	cnst_init_137_module_impuse();
	imported_modules_init_94_module_impuse();
	method_init_76_module_impuse();
	toplevel_init_63_module_impuse();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_impuse()
{
   module_initialization_70___bexit(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___eval(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___object(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___error(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___r4_strings_6_7(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___r4_control_features_6_9(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___reader(((long) 0), "MODULE_IMPUSE");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "MODULE_IMPUSE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_impuse()
{
   {
      obj_t cnst_port_138_1715;
      cnst_port_138_1715 = open_input_string(string1724_module_impuse);
      {
	 long i_1716;
	 i_1716 = ((long) 19);
       loop_1717:
	 {
	    bool_t test1725_1718;
	    test1725_1718 = (i_1716 == ((long) -1));
	    if (test1725_1718)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1726_1719;
		    {
		       obj_t list1727_1720;
		       {
			  obj_t arg1728_1721;
			  arg1728_1721 = BNIL;
			  list1727_1720 = MAKE_PAIR(cnst_port_138_1715, arg1728_1721);
		       }
		       arg1726_1719 = read___reader(list1727_1720);
		    }
		    CNST_TABLE_SET(i_1716, arg1726_1719);
		 }
		 {
		    int aux_1722;
		    {
		       long aux_1748;
		       aux_1748 = (i_1716 - ((long) 1));
		       aux_1722 = (int) (aux_1748);
		    }
		    {
		       long i_1751;
		       i_1751 = (long) (aux_1722);
		       i_1716 = i_1751;
		       goto loop_1717;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_module_impuse()
{
   _import_module_list__76_module_impuse = BNIL;
   return (_imported_module_list__84_module_impuse = BNIL,
      BUNSPEC);
}


/* make-import-compiler */ obj_t 
make_import_compiler_148_module_impuse()
{
   {
      obj_t arg1225_382;
      arg1225_382 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t arg1232_1628;
	 obj_t arg1231_1629;
	 obj_t arg1228_1630;
	 arg1232_1628 = proc1703_module_impuse;
	 arg1231_1629 = proc1704_module_impuse;
	 arg1228_1630 = proc1705_module_impuse;
	 {
	    ccomp_t res1700_1090;
	    {
	       ccomp_t new1002_1081;
	       new1002_1081 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1697_1082;
		  arg1697_1082 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_1088;
		     obj_1088 = (obj_t) (new1002_1081);
		     (((obj_t) CREF(obj_1088))->header = MAKE_HEADER(arg1697_1082, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_1758;
		  aux_1758 = (object_t) (new1002_1081);
		  OBJECT_WIDENING_SET(aux_1758, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_1081))->id) = ((obj_t) arg1225_382), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1081))->producer) = ((obj_t) impuse_producer_env_151_module_impuse), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1081))->consumer) = ((obj_t) arg1228_1630), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1081))->finalizer) = ((obj_t) arg1231_1629), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1081))->checksummer) = ((obj_t) arg1232_1628), BUNSPEC);
	       res1700_1090 = new1002_1081;
	    }
	    return (obj_t) (res1700_1090);
	 }
      }
   }
}


/* _make-import-compiler */ obj_t 
_make_import_compiler_114_module_impuse(obj_t env_1631)
{
   return make_import_compiler_148_module_impuse();
}


/* arg1232 */ obj_t 
arg1232_module_impuse(obj_t env_1632, obj_t m_1633, obj_t c_1634)
{
   {
      obj_t m_391;
      obj_t c_392;
      m_391 = m_1633;
      c_392 = c_1634;
      return c_392;
   }
}


/* arg1231 */ obj_t 
arg1231_module_impuse(obj_t env_1635)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1228 */ obj_t 
arg1228_module_impuse(obj_t env_1636, obj_t m_1637, obj_t c_1638)
{
   {
      obj_t m_387;
      obj_t c_388;
      m_387 = m_1637;
      c_388 = c_1638;
      return BNIL;
   }
}


/* make-use-compiler */ obj_t 
make_use_compiler_106_module_impuse()
{
   {
      obj_t arg1236_397;
      arg1236_397 = CNST_TABLE_REF(((long) 2));
      {
	 obj_t arg1243_1641;
	 obj_t arg1240_1642;
	 arg1243_1641 = proc1706_module_impuse;
	 arg1240_1642 = proc1707_module_impuse;
	 {
	    ccomp_t res1701_1103;
	    {
	       ccomp_t new1002_1094;
	       new1002_1094 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1697_1095;
		  arg1697_1095 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_1101;
		     obj_1101 = (obj_t) (new1002_1094);
		     (((obj_t) CREF(obj_1101))->header = MAKE_HEADER(arg1697_1095, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_1774;
		  aux_1774 = (object_t) (new1002_1094);
		  OBJECT_WIDENING_SET(aux_1774, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_1094))->id) = ((obj_t) arg1236_397), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1094))->producer) = ((obj_t) impuse_producer_env_151_module_impuse), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1094))->consumer) = ((obj_t) arg1240_1642), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1094))->finalizer) = ((obj_t) impuse_finalizer_env_73_module_impuse), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1094))->checksummer) = ((obj_t) arg1243_1641), BUNSPEC);
	       res1701_1103 = new1002_1094;
	    }
	    return (obj_t) (res1701_1103);
	 }
      }
   }
}


/* _make-use-compiler */ obj_t 
_make_use_compiler_39_module_impuse(obj_t env_1643)
{
   return make_use_compiler_106_module_impuse();
}


/* arg1243 */ obj_t 
arg1243_module_impuse(obj_t env_1644, obj_t m_1645, obj_t c_1646)
{
   {
      obj_t m_405;
      obj_t c_406;
      m_405 = m_1645;
      c_406 = c_1646;
      return c_406;
   }
}


/* arg1240 */ obj_t 
arg1240_module_impuse(obj_t env_1647, obj_t m_1648, obj_t c_1649)
{
   {
      obj_t m_402;
      obj_t c_403;
      m_402 = m_1648;
      c_403 = c_1649;
      return BNIL;
   }
}


/* make-from-compiler */ obj_t 
make_from_compiler_140_module_impuse()
{
   {
      obj_t arg1247_410;
      arg1247_410 = CNST_TABLE_REF(((long) 3));
      {
	 obj_t arg1252_1651;
	 obj_t arg1251_1652;
	 obj_t arg1250_1653;
	 arg1252_1651 = proc1708_module_impuse;
	 arg1251_1652 = proc1709_module_impuse;
	 arg1250_1653 = proc1710_module_impuse;
	 {
	    ccomp_t res1702_1115;
	    {
	       ccomp_t new1002_1106;
	       new1002_1106 = ((ccomp_t) BREF(GC_MALLOC(sizeof(struct ccomp))));
	       {
		  long arg1697_1107;
		  arg1697_1107 = class_num_218___object(ccomp_module_module);
		  {
		     obj_t obj_1113;
		     obj_1113 = (obj_t) (new1002_1106);
		     (((obj_t) CREF(obj_1113))->header = MAKE_HEADER(arg1697_1107, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_1789;
		  aux_1789 = (object_t) (new1002_1106);
		  OBJECT_WIDENING_SET(aux_1789, BFALSE);
	       }
	       ((((ccomp_t) CREF(new1002_1106))->id) = ((obj_t) arg1247_410), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1106))->producer) = ((obj_t) impuse_producer_env_151_module_impuse), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1106))->consumer) = ((obj_t) arg1250_1653), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1106))->finalizer) = ((obj_t) arg1251_1652), BUNSPEC);
	       ((((ccomp_t) CREF(new1002_1106))->checksummer) = ((obj_t) arg1252_1651), BUNSPEC);
	       res1702_1115 = new1002_1106;
	    }
	    return (obj_t) (res1702_1115);
	 }
      }
   }
}


/* _make-from-compiler */ obj_t 
_make_from_compiler_253_module_impuse(obj_t env_1654)
{
   return make_from_compiler_140_module_impuse();
}


/* arg1252 */ obj_t 
arg1252_module_impuse(obj_t env_1655, obj_t m_1656, obj_t c_1657)
{
   {
      obj_t m_419;
      obj_t c_420;
      m_419 = m_1656;
      c_420 = c_1657;
      return c_420;
   }
}


/* arg1251 */ obj_t 
arg1251_module_impuse(obj_t env_1658)
{
   {
      return CNST_TABLE_REF(((long) 1));
   }
}


/* arg1250 */ obj_t 
arg1250_module_impuse(obj_t env_1659, obj_t module_1660, obj_t clause_1661)
{
   {
      obj_t module_415;
      obj_t clause_416;
      module_415 = module_1660;
      clause_416 = clause_1661;
      impuse_producer_187_module_impuse(clause_416);
      return BNIL;
   }
}


/* impuse-producer */ obj_t 
impuse_producer_187_module_impuse(obj_t clause_19)
{
   {
      obj_t mode_425;
      mode_425 = CAR(clause_19);
      {
	 obj_t protos_426;
	 if (PAIRP(clause_19))
	   {
	      bool_t aux_1804;
	      protos_426 = CDR(clause_19);
	      {
		 obj_t l1193_432;
		 l1193_432 = protos_426;
	       lname1194_433:
		 if (PAIRP(l1193_432))
		   {
		      impuse_parser_37_module_impuse(CAR(l1193_432), mode_425);
		      {
			 obj_t l1193_1809;
			 l1193_1809 = CDR(l1193_432);
			 l1193_432 = l1193_1809;
			 goto lname1194_433;
		      }
		   }
		 else
		   {
		      aux_1804 = ((bool_t) 1);
		   }
	      }
	      return BBOOL(aux_1804);
	   }
	 else
	   {
	      {
		 obj_t arg1262_438;
		 {
		    obj_t arg1268_443;
		    {
		       obj_t arg1277_449;
		       arg1277_449 = SYMBOL_TO_STRING(mode_425);
		       arg1268_443 = string_downcase_77___r4_strings_6_7(arg1277_449);
		    }
		    {
		       obj_t list1270_445;
		       {
			  obj_t arg1272_446;
			  {
			     obj_t arg1273_447;
			     arg1273_447 = MAKE_PAIR(string1711_module_impuse, BNIL);
			     arg1272_446 = MAKE_PAIR(arg1268_443, arg1273_447);
			  }
			  list1270_445 = MAKE_PAIR(string1712_module_impuse, arg1272_446);
		       }
		       arg1262_438 = string_append_106___r4_strings_6_7(list1270_445);
		    }
		 }
		 {
		    obj_t list1264_440;
		    list1264_440 = MAKE_PAIR(BNIL, BNIL);
		    return user_error_151_tools_error(string1713_module_impuse, arg1262_438, clause_19, list1264_440);
		 }
	      }
	   }
      }
   }
}


/* _impuse-producer */ obj_t 
_impuse_producer_249_module_impuse(obj_t env_1639, obj_t clause_1640)
{
   return impuse_producer_187_module_impuse(clause_1640);
}


/* import-all-module */ obj_t 
import_all_module_109_module_impuse(obj_t module_20, obj_t mode_21)
{
   {
      obj_t b_450;
      b_450 = assq___r4_pairs_and_lists_6_3(module_20, _import_module_list__76_module_impuse);
      if (PAIRP(b_450))
	{
	   obj_t x_1714;
	   {
	      obj_t aux_1827;
	      obj_t aux_1825;
	      aux_1827 = CNST_TABLE_REF(((long) 4));
	      aux_1825 = CDR(b_450);
	      x_1714 = STRUCT_SET(aux_1825, ((long) 2), aux_1827);
	   }
	   return BUNSPEC;
	}
      else
	{
	   obj_t arg1283_454;
	   {
	      obj_t arg1284_455;
	      {
		 obj_t arg1285_456;
		 arg1285_456 = CNST_TABLE_REF(((long) 4));
		 {
		    obj_t new_1134;
		    {
		       obj_t aux_1831;
		       aux_1831 = CNST_TABLE_REF(((long) 5));
		       new_1134 = create_struct(aux_1831, ((long) 4));
		    }
		    STRUCT_SET(new_1134, ((long) 3), BUNSPEC);
		    STRUCT_SET(new_1134, ((long) 2), arg1285_456);
		    STRUCT_SET(new_1134, ((long) 1), mode_21);
		    STRUCT_SET(new_1134, ((long) 0), module_20);
		    arg1284_455 = new_1134;
		 }
	      }
	      arg1283_454 = MAKE_PAIR(module_20, arg1284_455);
	   }
	   {
	      obj_t obj2_1160;
	      obj2_1160 = _import_module_list__76_module_impuse;
	      return (_import_module_list__76_module_impuse = MAKE_PAIR(arg1283_454, obj2_1160),
		 BUNSPEC);
	   }
	}
   }
}


/* import-1-module */ obj_t 
import_1_module_184_module_impuse(obj_t module_22, obj_t var_23, obj_t mode_24)
{
   {
      obj_t cell_457;
      cell_457 = assq___r4_pairs_and_lists_6_3(module_22, _import_module_list__76_module_impuse);
      if (PAIRP(cell_457))
	{
	   obj_t b_459;
	   b_459 = CDR(cell_457);
	   {
	      obj_t case_value_58_460;
	      case_value_58_460 = STRUCT_REF(b_459, ((long) 2));
	      {
		 bool_t test_1845;
		 {
		    obj_t aux_1846;
		    aux_1846 = CNST_TABLE_REF(((long) 6));
		    test_1845 = (case_value_58_460 == aux_1846);
		 }
		 if (test_1845)
		   {
		      STRUCT_SET(b_459, ((long) 1), mode_24);
		      {
			 obj_t arg1288_462;
			 {
			    obj_t list1289_463;
			    list1289_463 = MAKE_PAIR(var_23, BNIL);
			    arg1288_462 = list1289_463;
			 }
			 return STRUCT_SET(b_459, ((long) 2), arg1288_462);
		      }
		   }
		 else
		   {
		      bool_t test_1852;
		      {
			 obj_t aux_1853;
			 aux_1853 = CNST_TABLE_REF(((long) 4));
			 test_1852 = (case_value_58_460 == aux_1853);
		      }
		      if (test_1852)
			{
			   return CNST_TABLE_REF(((long) 7));
			}
		      else
			{
			   obj_t arg1292_466;
			   arg1292_466 = MAKE_PAIR(var_23, case_value_58_460);
			   return STRUCT_SET(b_459, ((long) 2), arg1292_466);
			}
		   }
	      }
	   }
	}
      else
	{
	   obj_t arg1297_470;
	   {
	      obj_t arg1298_471;
	      {
		 obj_t arg1299_472;
		 {
		    obj_t list1300_473;
		    list1300_473 = MAKE_PAIR(var_23, BNIL);
		    arg1299_472 = list1300_473;
		 }
		 {
		    obj_t new_1196;
		    {
		       obj_t aux_1860;
		       aux_1860 = CNST_TABLE_REF(((long) 5));
		       new_1196 = create_struct(aux_1860, ((long) 4));
		    }
		    STRUCT_SET(new_1196, ((long) 3), BUNSPEC);
		    STRUCT_SET(new_1196, ((long) 2), arg1299_472);
		    STRUCT_SET(new_1196, ((long) 1), mode_24);
		    STRUCT_SET(new_1196, ((long) 0), module_22);
		    arg1298_471 = new_1196;
		 }
	      }
	      arg1297_470 = MAKE_PAIR(module_22, arg1298_471);
	   }
	   {
	      obj_t obj2_1222;
	      obj2_1222 = _import_module_list__76_module_impuse;
	      return (_import_module_list__76_module_impuse = MAKE_PAIR(arg1297_470, obj2_1222),
		 BUNSPEC);
	   }
	}
   }
}


/* import-with-module! */ obj_t 
import_with_module__247_module_impuse(obj_t module_25)
{
   {
      obj_t b_475;
      b_475 = assq___r4_pairs_and_lists_6_3(module_25, _import_module_list__76_module_impuse);
      if (PAIRP(b_475))
	{
	   return BUNSPEC;
	}
      else
	{
	   obj_t arg1303_477;
	   {
	      obj_t arg1304_478;
	      {
		 obj_t arg1307_479;
		 arg1307_479 = CNST_TABLE_REF(((long) 6));
		 {
		    obj_t new_1228;
		    {
		       obj_t aux_1873;
		       aux_1873 = CNST_TABLE_REF(((long) 5));
		       new_1228 = create_struct(aux_1873, ((long) 4));
		    }
		    {
		       obj_t aux_1876;
		       aux_1876 = BINT(((long) 0));
		       STRUCT_SET(new_1228, ((long) 3), aux_1876);
		    }
		    STRUCT_SET(new_1228, ((long) 2), BNIL);
		    STRUCT_SET(new_1228, ((long) 1), arg1307_479);
		    STRUCT_SET(new_1228, ((long) 0), module_25);
		    arg1304_478 = new_1228;
		 }
	      }
	      arg1303_477 = MAKE_PAIR(module_25, arg1304_478);
	   }
	   {
	      obj_t obj2_1254;
	      obj2_1254 = _import_module_list__76_module_impuse;
	      return (_import_module_list__76_module_impuse = MAKE_PAIR(arg1303_477, obj2_1254),
		 BUNSPEC);
	   }
	}
   }
}


/* _import-with-module! */ obj_t 
_import_with_module__232_module_impuse(obj_t env_1662, obj_t module_1663)
{
   return import_with_module__247_module_impuse(module_1663);
}


/* impuse-parser */ obj_t 
impuse_parser_37_module_impuse(obj_t prototype_26, obj_t mode_27)
{
   {
      obj_t v_489;
      obj_t m_490;
      obj_t f_491;
      obj_t rest_492;
      obj_t module_482;
      obj_t fname_483;
      obj_t rest_484;
      if (PAIRP(prototype_26))
	{
	   obj_t car_144_227_499;
	   obj_t cdr_145_238_500;
	   car_144_227_499 = CAR(prototype_26);
	   cdr_145_238_500 = CDR(prototype_26);
	   if (SYMBOLP(car_144_227_499))
	     {
		if (PAIRP(cdr_145_238_500))
		  {
		     obj_t car_150_99_503;
		     car_150_99_503 = CAR(cdr_145_238_500);
		     if (STRINGP(car_150_99_503))
		       {
			  module_482 = car_144_227_499;
			  fname_483 = car_150_99_503;
			  rest_484 = CDR(cdr_145_238_500);
			  {
			     obj_t rest_612;
			     obj_t fnames_613;
			     {
				obj_t arg1391_615;
				{
				   obj_t list1392_616;
				   list1392_616 = MAKE_PAIR(fname_483, BNIL);
				   arg1391_615 = list1392_616;
				}
				rest_612 = rest_484;
				fnames_613 = arg1391_615;
			      loop_614:
				if (NULLP(rest_612))
				  {
				     {
					obj_t arg1395_619;
					arg1395_619 = reverse__39___r4_pairs_and_lists_6_3(fnames_613);
					add_access__140_read_access(module_482, arg1395_619);
				     }
				     return import_all_module_109_module_impuse(module_482, mode_27);
				  }
				else
				  {
				     bool_t test_1902;
				     {
					obj_t aux_1903;
					aux_1903 = CAR(rest_612);
					test_1902 = STRINGP(aux_1903);
				     }
				     if (test_1902)
				       {
					  {
					     obj_t arg1397_621;
					     obj_t arg1398_622;
					     arg1397_621 = CDR(rest_612);
					     {
						obj_t aux_1907;
						aux_1907 = CAR(rest_612);
						arg1398_622 = MAKE_PAIR(aux_1907, fnames_613);
					     }
					     {
						obj_t fnames_1911;
						obj_t rest_1910;
						rest_1910 = arg1397_621;
						fnames_1911 = arg1398_622;
						fnames_613 = fnames_1911;
						rest_612 = rest_1910;
						goto loop_614;
					     }
					  }
				       }
				     else
				       {
					  {
					     obj_t list1404_627;
					     list1404_627 = MAKE_PAIR(BNIL, BNIL);
					     return user_error_151_tools_error(string1713_module_impuse, string1714_module_impuse, prototype_26, list1404_627);
					  }
				       }
				  }
			     }
			  }
		       }
		     else
		       {
			  if (SYMBOLP(car_144_227_499))
			    {
			       obj_t car_173_126_509;
			       car_173_126_509 = CAR(cdr_145_238_500);
			       if (SYMBOLP(car_173_126_509))
				 {
				    bool_t test_1920;
				    {
				       obj_t aux_1921;
				       aux_1921 = CDR(cdr_145_238_500);
				       test_1920 = (aux_1921 == BNIL);
				    }
				    if (test_1920)
				      {
					 return import_1_module_184_module_impuse(car_173_126_509, car_144_227_499, mode_27);
				      }
				    else
				      {
					 if (SYMBOLP(car_144_227_499))
					   {
					      obj_t car_196_45_515;
					      obj_t cdr_197_63_516;
					      car_196_45_515 = CAR(cdr_145_238_500);
					      cdr_197_63_516 = CDR(cdr_145_238_500);
					      if (SYMBOLP(car_196_45_515))
						{
						   if (PAIRP(cdr_197_63_516))
						     {
							obj_t car_203_140_519;
							car_203_140_519 = CAR(cdr_197_63_516);
							if (STRINGP(car_203_140_519))
							  {
							     v_489 = car_144_227_499;
							     m_490 = car_196_45_515;
							     f_491 = car_203_140_519;
							     rest_492 = CDR(cdr_197_63_516);
							   tag_130_214_493:
							     {
								obj_t rest_630;
								obj_t fnames_631;
								{
								   obj_t arg1408_633;
								   {
								      obj_t list1409_634;
								      list1409_634 = MAKE_PAIR(f_491, BNIL);
								      arg1408_633 = list1409_634;
								   }
								   rest_630 = rest_492;
								   fnames_631 = arg1408_633;
								 loop_632:
								   if (NULLP(rest_630))
								     {
									{
									   obj_t arg1413_637;
									   arg1413_637 = reverse__39___r4_pairs_and_lists_6_3(fnames_631);
									   add_access__140_read_access(m_490, arg1413_637);
									}
									return import_1_module_184_module_impuse(m_490, v_489, mode_27);
								     }
								   else
								     {
									bool_t test_1942;
									{
									   obj_t aux_1943;
									   aux_1943 = CAR(rest_630);
									   test_1942 = STRINGP(aux_1943);
									}
									if (test_1942)
									  {
									     {
										obj_t arg1415_639;
										obj_t arg1416_640;
										arg1415_639 = CDR(rest_630);
										{
										   obj_t aux_1947;
										   aux_1947 = CAR(rest_630);
										   arg1416_640 = MAKE_PAIR(aux_1947, fnames_631);
										}
										{
										   obj_t fnames_1951;
										   obj_t rest_1950;
										   rest_1950 = arg1415_639;
										   fnames_1951 = arg1416_640;
										   fnames_631 = fnames_1951;
										   rest_630 = rest_1950;
										   goto loop_632;
										}
									     }
									  }
									else
									  {
									     {
										obj_t list1422_645;
										list1422_645 = MAKE_PAIR(BNIL, BNIL);
										return user_error_151_tools_error(string1713_module_impuse, string1714_module_impuse, prototype_26, list1422_645);
									     }
									  }
								     }
								}
							     }
							  }
							else
							  {
							     if (SYMBOLP(prototype_26))
							       {
								  return import_all_module_109_module_impuse(prototype_26, mode_27);
							       }
							     else
							       {
								tag_132_226_496:
								  {
								     obj_t list1432_651;
								     list1432_651 = MAKE_PAIR(BNIL, BNIL);
								     return user_error_151_tools_error(string1713_module_impuse, string1715_module_impuse, prototype_26, list1432_651);
								  }
							       }
							  }
						     }
						   else
						     {
							if (SYMBOLP(prototype_26))
							  {
							     return import_all_module_109_module_impuse(prototype_26, mode_27);
							  }
							else
							  {
							     goto tag_132_226_496;
							  }
						     }
						}
					      else
						{
						   if (SYMBOLP(prototype_26))
						     {
							return import_all_module_109_module_impuse(prototype_26, mode_27);
						     }
						   else
						     {
							goto tag_132_226_496;
						     }
						}
					   }
					 else
					   {
					      if (SYMBOLP(prototype_26))
						{
						   return import_all_module_109_module_impuse(prototype_26, mode_27);
						}
					      else
						{
						   goto tag_132_226_496;
						}
					   }
				      }
				 }
			       else
				 {
				    if (SYMBOLP(car_144_227_499))
				      {
					 obj_t car_237_172_531;
					 obj_t cdr_238_48_532;
					 car_237_172_531 = CAR(cdr_145_238_500);
					 cdr_238_48_532 = CDR(cdr_145_238_500);
					 if (SYMBOLP(car_237_172_531))
					   {
					      if (PAIRP(cdr_238_48_532))
						{
						   obj_t car_244_36_535;
						   car_244_36_535 = CAR(cdr_238_48_532);
						   if (STRINGP(car_244_36_535))
						     {
							obj_t rest_1983;
							obj_t f_1982;
							obj_t m_1981;
							obj_t v_1980;
							v_1980 = car_144_227_499;
							m_1981 = car_237_172_531;
							f_1982 = car_244_36_535;
							rest_1983 = CDR(cdr_238_48_532);
							rest_492 = rest_1983;
							f_491 = f_1982;
							m_490 = m_1981;
							v_489 = v_1980;
							goto tag_130_214_493;
						     }
						   else
						     {
							if (SYMBOLP(prototype_26))
							  {
							     return import_all_module_109_module_impuse(prototype_26, mode_27);
							  }
							else
							  {
							     goto tag_132_226_496;
							  }
						     }
						}
					      else
						{
						   if (SYMBOLP(prototype_26))
						     {
							return import_all_module_109_module_impuse(prototype_26, mode_27);
						     }
						   else
						     {
							goto tag_132_226_496;
						     }
						}
					   }
					 else
					   {
					      if (SYMBOLP(prototype_26))
						{
						   return import_all_module_109_module_impuse(prototype_26, mode_27);
						}
					      else
						{
						   goto tag_132_226_496;
						}
					   }
				      }
				    else
				      {
					 if (SYMBOLP(prototype_26))
					   {
					      return import_all_module_109_module_impuse(prototype_26, mode_27);
					   }
					 else
					   {
					      goto tag_132_226_496;
					   }
				      }
				 }
			    }
			  else
			    {
			       if (SYMBOLP(car_144_227_499))
				 {
				    obj_t car_280_133_545;
				    obj_t cdr_281_218_546;
				    car_280_133_545 = CAR(cdr_145_238_500);
				    cdr_281_218_546 = CDR(cdr_145_238_500);
				    if (SYMBOLP(car_280_133_545))
				      {
					 if (PAIRP(cdr_281_218_546))
					   {
					      obj_t car_289_221_549;
					      car_289_221_549 = CAR(cdr_281_218_546);
					      if (STRINGP(car_289_221_549))
						{
						   obj_t rest_2011;
						   obj_t f_2010;
						   obj_t m_2009;
						   obj_t v_2008;
						   v_2008 = car_144_227_499;
						   m_2009 = car_280_133_545;
						   f_2010 = car_289_221_549;
						   rest_2011 = CDR(cdr_281_218_546);
						   rest_492 = rest_2011;
						   f_491 = f_2010;
						   m_490 = m_2009;
						   v_489 = v_2008;
						   goto tag_130_214_493;
						}
					      else
						{
						   if (SYMBOLP(prototype_26))
						     {
							return import_all_module_109_module_impuse(prototype_26, mode_27);
						     }
						   else
						     {
							goto tag_132_226_496;
						     }
						}
					   }
					 else
					   {
					      if (SYMBOLP(prototype_26))
						{
						   return import_all_module_109_module_impuse(prototype_26, mode_27);
						}
					      else
						{
						   goto tag_132_226_496;
						}
					   }
				      }
				    else
				      {
					 if (SYMBOLP(prototype_26))
					   {
					      return import_all_module_109_module_impuse(prototype_26, mode_27);
					   }
					 else
					   {
					      goto tag_132_226_496;
					   }
				      }
				 }
			       else
				 {
				    if (SYMBOLP(prototype_26))
				      {
					 return import_all_module_109_module_impuse(prototype_26, mode_27);
				      }
				    else
				      {
					 goto tag_132_226_496;
				      }
				 }
			    }
		       }
		  }
		else
		  {
		     if (SYMBOLP(prototype_26))
		       {
			  return import_all_module_109_module_impuse(prototype_26, mode_27);
		       }
		     else
		       {
			  goto tag_132_226_496;
		       }
		  }
	     }
	   else
	     {
		if (SYMBOLP(car_144_227_499))
		  {
		     if (PAIRP(cdr_145_238_500))
		       {
			  obj_t car_344_246_561;
			  car_344_246_561 = CAR(cdr_145_238_500);
			  if (SYMBOLP(car_344_246_561))
			    {
			       bool_t test_2035;
			       {
				  obj_t aux_2036;
				  aux_2036 = CDR(cdr_145_238_500);
				  test_2035 = (aux_2036 == BNIL);
			       }
			       if (test_2035)
				 {
				    return import_1_module_184_module_impuse(car_344_246_561, car_144_227_499, mode_27);
				 }
			       else
				 {
				    if (SYMBOLP(car_144_227_499))
				      {
					 obj_t car_367_38_567;
					 obj_t cdr_368_205_568;
					 car_367_38_567 = CAR(cdr_145_238_500);
					 cdr_368_205_568 = CDR(cdr_145_238_500);
					 if (SYMBOLP(car_367_38_567))
					   {
					      if (PAIRP(cdr_368_205_568))
						{
						   obj_t car_376_57_571;
						   car_376_57_571 = CAR(cdr_368_205_568);
						   if (STRINGP(car_376_57_571))
						     {
							obj_t rest_2054;
							obj_t f_2053;
							obj_t m_2052;
							obj_t v_2051;
							v_2051 = car_144_227_499;
							m_2052 = car_367_38_567;
							f_2053 = car_376_57_571;
							rest_2054 = CDR(cdr_368_205_568);
							rest_492 = rest_2054;
							f_491 = f_2053;
							m_490 = m_2052;
							v_489 = v_2051;
							goto tag_130_214_493;
						     }
						   else
						     {
							if (SYMBOLP(prototype_26))
							  {
							     return import_all_module_109_module_impuse(prototype_26, mode_27);
							  }
							else
							  {
							     goto tag_132_226_496;
							  }
						     }
						}
					      else
						{
						   if (SYMBOLP(prototype_26))
						     {
							return import_all_module_109_module_impuse(prototype_26, mode_27);
						     }
						   else
						     {
							goto tag_132_226_496;
						     }
						}
					   }
					 else
					   {
					      if (SYMBOLP(prototype_26))
						{
						   return import_all_module_109_module_impuse(prototype_26, mode_27);
						}
					      else
						{
						   goto tag_132_226_496;
						}
					   }
				      }
				    else
				      {
					 if (SYMBOLP(prototype_26))
					   {
					      return import_all_module_109_module_impuse(prototype_26, mode_27);
					   }
					 else
					   {
					      goto tag_132_226_496;
					   }
				      }
				 }
			    }
			  else
			    {
			       if (SYMBOLP(car_144_227_499))
				 {
				    obj_t car_412_102_583;
				    obj_t cdr_413_22_584;
				    car_412_102_583 = CAR(cdr_145_238_500);
				    cdr_413_22_584 = CDR(cdr_145_238_500);
				    if (SYMBOLP(car_412_102_583))
				      {
					 if (PAIRP(cdr_413_22_584))
					   {
					      obj_t car_421_152_587;
					      car_421_152_587 = CAR(cdr_413_22_584);
					      if (STRINGP(car_421_152_587))
						{
						   obj_t rest_2082;
						   obj_t f_2081;
						   obj_t m_2080;
						   obj_t v_2079;
						   v_2079 = car_144_227_499;
						   m_2080 = car_412_102_583;
						   f_2081 = car_421_152_587;
						   rest_2082 = CDR(cdr_413_22_584);
						   rest_492 = rest_2082;
						   f_491 = f_2081;
						   m_490 = m_2080;
						   v_489 = v_2079;
						   goto tag_130_214_493;
						}
					      else
						{
						   if (SYMBOLP(prototype_26))
						     {
							return import_all_module_109_module_impuse(prototype_26, mode_27);
						     }
						   else
						     {
							goto tag_132_226_496;
						     }
						}
					   }
					 else
					   {
					      if (SYMBOLP(prototype_26))
						{
						   return import_all_module_109_module_impuse(prototype_26, mode_27);
						}
					      else
						{
						   goto tag_132_226_496;
						}
					   }
				      }
				    else
				      {
					 if (SYMBOLP(prototype_26))
					   {
					      return import_all_module_109_module_impuse(prototype_26, mode_27);
					   }
					 else
					   {
					      goto tag_132_226_496;
					   }
				      }
				 }
			       else
				 {
				    if (SYMBOLP(prototype_26))
				      {
					 return import_all_module_109_module_impuse(prototype_26, mode_27);
				      }
				    else
				      {
					 goto tag_132_226_496;
				      }
				 }
			    }
		       }
		     else
		       {
			  if (SYMBOLP(prototype_26))
			    {
			       return import_all_module_109_module_impuse(prototype_26, mode_27);
			    }
			  else
			    {
			       goto tag_132_226_496;
			    }
		       }
		  }
		else
		  {
		     if (SYMBOLP(car_144_227_499))
		       {
			  if (PAIRP(cdr_145_238_500))
			    {
			       obj_t car_467_136_599;
			       obj_t cdr_468_188_600;
			       car_467_136_599 = CAR(cdr_145_238_500);
			       cdr_468_188_600 = CDR(cdr_145_238_500);
			       if (SYMBOLP(car_467_136_599))
				 {
				    if (PAIRP(cdr_468_188_600))
				      {
					 obj_t car_474_202_603;
					 car_474_202_603 = CAR(cdr_468_188_600);
					 if (STRINGP(car_474_202_603))
					   {
					      obj_t rest_2115;
					      obj_t f_2114;
					      obj_t m_2113;
					      obj_t v_2112;
					      v_2112 = car_144_227_499;
					      m_2113 = car_467_136_599;
					      f_2114 = car_474_202_603;
					      rest_2115 = CDR(cdr_468_188_600);
					      rest_492 = rest_2115;
					      f_491 = f_2114;
					      m_490 = m_2113;
					      v_489 = v_2112;
					      goto tag_130_214_493;
					   }
					 else
					   {
					      if (SYMBOLP(prototype_26))
						{
						   return import_all_module_109_module_impuse(prototype_26, mode_27);
						}
					      else
						{
						   goto tag_132_226_496;
						}
					   }
				      }
				    else
				      {
					 if (SYMBOLP(prototype_26))
					   {
					      return import_all_module_109_module_impuse(prototype_26, mode_27);
					   }
					 else
					   {
					      goto tag_132_226_496;
					   }
				      }
				 }
			       else
				 {
				    if (SYMBOLP(prototype_26))
				      {
					 return import_all_module_109_module_impuse(prototype_26, mode_27);
				      }
				    else
				      {
					 goto tag_132_226_496;
				      }
				 }
			    }
			  else
			    {
			       if (SYMBOLP(prototype_26))
				 {
				    return import_all_module_109_module_impuse(prototype_26, mode_27);
				 }
			       else
				 {
				    goto tag_132_226_496;
				 }
			    }
		       }
		     else
		       {
			  if (SYMBOLP(prototype_26))
			    {
			       return import_all_module_109_module_impuse(prototype_26, mode_27);
			    }
			  else
			    {
			       goto tag_132_226_496;
			    }
		       }
		  }
	     }
	}
      else
	{
	   if (SYMBOLP(prototype_26))
	     {
		return import_all_module_109_module_impuse(prototype_26, mode_27);
	     }
	   else
	     {
		goto tag_132_226_496;
	     }
	}
   }
}


/* get-imported-modules */ obj_t 
get_imported_modules_153_module_impuse()
{
   return _imported_module_list__84_module_impuse;
}


/* _get-imported-modules */ obj_t 
_get_imported_modules_109_module_impuse(obj_t env_1664)
{
   return get_imported_modules_153_module_impuse();
}


/* import-finalizer */ obj_t 
import_finalizer_66_module_impuse()
{
   _import_module_list__76_module_impuse = reverse__39___r4_pairs_and_lists_6_3(_import_module_list__76_module_impuse);
   {
      obj_t init__202_670;
      init__202_670 = BNIL;
    loop_671:
      {
	 bool_t test1456_673;
	 {
	    obj_t obj_1460;
	    obj_1460 = _import_module_list__76_module_impuse;
	    test1456_673 = NULLP(obj_1460);
	 }
	 if (test1456_673)
	   {
	      if (PAIRP(init__202_670))
		{
		   obj_t init__202_675;
		   obj_t init_call__93_676;
		   init__202_675 = init__202_670;
		   init_call__93_676 = BNIL;
		 loop_677:
		   if (NULLP(init__202_675))
		     {
			obj_t arg1460_680;
			{
			   obj_t arg1464_683;
			   arg1464_683 = CNST_TABLE_REF(((long) 8));
			   {
			      obj_t new_1467;
			      {
				 obj_t aux_2144;
				 aux_2144 = CNST_TABLE_REF(((long) 9));
				 new_1467 = create_struct(aux_2144, ((long) 4));
			      }
			      STRUCT_SET(new_1467, ((long) 3), BTRUE);
			      STRUCT_SET(new_1467, ((long) 2), init_call__93_676);
			      {
				 obj_t aux_2149;
				 aux_2149 = BINT(((long) 12));
				 STRUCT_SET(new_1467, ((long) 1), aux_2149);
			      }
			      STRUCT_SET(new_1467, ((long) 0), arg1464_683);
			      arg1460_680 = new_1467;
			   }
			}
			{
			   obj_t list1461_681;
			   list1461_681 = MAKE_PAIR(arg1460_680, BNIL);
			   return list1461_681;
			}
		     }
		   else
		     {
			obj_t id_685;
			{
			   obj_t aux_2154;
			   aux_2154 = CAR(init__202_675);
			   id_685 = STRUCT_REF(aux_2154, ((long) 0));
			}
			{
			   obj_t checksum_686;
			   {
			      obj_t aux_2157;
			      aux_2157 = CAR(init__202_675);
			      checksum_686 = STRUCT_REF(aux_2157, ((long) 3));
			   }
			   {
			      obj_t init_fun_id_230_687;
			      init_fun_id_230_687 = module_initialization_id_110_module_module(id_685);
			      {
				 {
				    obj_t global_688;
				    {
				       obj_t arg1466_689;
				       {
					  obj_t arg1467_690;
					  arg1467_690 = CNST_TABLE_REF(((long) 10));
					  {
					     obj_t list1469_692;
					     {
						obj_t arg1470_693;
						{
						   obj_t arg1471_694;
						   {
						      obj_t aux_2162;
						      aux_2162 = CNST_TABLE_REF(((long) 11));
						      arg1471_694 = MAKE_PAIR(aux_2162, BNIL);
						   }
						   arg1470_693 = MAKE_PAIR(arg1467_690, arg1471_694);
						}
						list1469_692 = MAKE_PAIR(init_fun_id_230_687, arg1470_693);
					     }
					     arg1466_689 = list1469_692;
					  }
				       }
				       global_688 = import_parser_53_module_impuse(id_685, arg1466_689);
				    }
				    {
				       global_t obj_1500;
				       obj_1500 = (global_t) (global_688);
				       ((((global_t) CREF(obj_1500))->evaluable__248) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				    }
				 }
				 {
				    obj_t arg1474_696;
				    obj_t arg1475_697;
				    arg1474_696 = CDR(init__202_675);
				    {
				       obj_t arg1476_698;
				       {
					  obj_t arg1477_699;
					  obj_t arg1478_700;
					  {
					     obj_t arg1485_706;
					     arg1485_706 = CNST_TABLE_REF(((long) 12));
					     {
						obj_t list1487_708;
						{
						   obj_t arg1488_709;
						   {
						      obj_t arg1489_710;
						      arg1489_710 = MAKE_PAIR(BNIL, BNIL);
						      arg1488_709 = MAKE_PAIR(id_685, arg1489_710);
						   }
						   list1487_708 = MAKE_PAIR(init_fun_id_230_687, arg1488_709);
						}
						arg1477_699 = cons__138___r4_pairs_and_lists_6_3(arg1485_706, list1487_708);
					     }
					  }
					  {
					     obj_t symbol_1503;
					     symbol_1503 = _module__166_module_module;
					     arg1478_700 = SYMBOL_TO_STRING(symbol_1503);
					  }
					  {
					     obj_t list1480_702;
					     {
						obj_t arg1481_703;
						{
						   obj_t arg1483_704;
						   arg1483_704 = MAKE_PAIR(BNIL, BNIL);
						   arg1481_703 = MAKE_PAIR(arg1478_700, arg1483_704);
						}
						list1480_702 = MAKE_PAIR(checksum_686, arg1481_703);
					     }
					     arg1476_698 = cons__138___r4_pairs_and_lists_6_3(arg1477_699, list1480_702);
					  }
				       }
				       arg1475_697 = MAKE_PAIR(arg1476_698, init_call__93_676);
				    }
				    {
				       obj_t init_call__93_2183;
				       obj_t init__202_2182;
				       init__202_2182 = arg1474_696;
				       init_call__93_2183 = arg1475_697;
				       init_call__93_676 = init_call__93_2183;
				       init__202_675 = init__202_2182;
				       goto loop_677;
				    }
				 }
			      }
			   }
			}
		     }
		}
	      else
		{
		   return BNIL;
		}
	   }
	 else
	   {
	      obj_t module_714;
	      obj_t imode_715;
	      {
		 obj_t arg1502_723;
		 {
		    obj_t pair_1506;
		    pair_1506 = _import_module_list__76_module_impuse;
		    arg1502_723 = CAR(pair_1506);
		 }
		 module_714 = CAR(arg1502_723);
	      }
	      {
		 obj_t arg1503_724;
		 {
		    obj_t pair_1508;
		    pair_1508 = _import_module_list__76_module_impuse;
		    arg1503_724 = CAR(pair_1508);
		 }
		 imode_715 = CDR(arg1503_724);
	      }
	      {
		 obj_t pair_1510;
		 pair_1510 = _import_module_list__76_module_impuse;
		 _import_module_list__76_module_impuse = CDR(pair_1510);
	      }
	      {
		 obj_t obj2_1512;
		 obj2_1512 = _imported_module_list__84_module_impuse;
		 _imported_module_list__84_module_impuse = MAKE_PAIR(module_714, obj2_1512);
	      }
	      {
		 bool_t test_2190;
		 {
		    obj_t aux_2193;
		    obj_t aux_2191;
		    aux_2193 = CNST_TABLE_REF(((long) 6));
		    aux_2191 = STRUCT_REF(imode_715, ((long) 1));
		    test_2190 = (aux_2191 == aux_2193);
		 }
		 if (test_2190)
		   {
		      BUNSPEC;
		   }
		 else
		   {
		      read_imported_module_112_module_impuse(imode_715);
		   }
	      }
	      {
		 obj_t arg1498_719;
		 {
		    bool_t test_2197;
		    {
		       obj_t aux_2198;
		       aux_2198 = memq___r4_pairs_and_lists_6_3(STRUCT_REF(imode_715, ((long) 1)), CNST_TABLE_REF(((long) 13)));
		       test_2197 = CBOOL(aux_2198);
		    }
		    if (test_2197)
		      {
			 arg1498_719 = MAKE_PAIR(imode_715, init__202_670);
		      }
		    else
		      {
			 arg1498_719 = init__202_670;
		      }
		 }
		 {
		    obj_t init__202_2204;
		    init__202_2204 = arg1498_719;
		    init__202_670 = init__202_2204;
		    goto loop_671;
		 }
	      }
	   }
      }
   }
}


/* impuse-finalizer */ obj_t 
impuse_finalizer_42_module_impuse()
{
   {
      obj_t import_finalizer_66_725;
      import_finalizer_66_725 = import_finalizer_66_module_impuse();
      {
	 obj_t inline_finalizer_105_726;
	 inline_finalizer_105_726 = inline_finalizer_105_read_inline();
	 {
	    obj_t finalizers_727;
	    finalizers_727 = append_2_18___r4_pairs_and_lists_6_3(import_finalizer_66_725, inline_finalizer_105_726);
	    {
	       if (NULLP(finalizers_727))
		 {
		    return CNST_TABLE_REF(((long) 1));
		 }
	       else
		 {
		    return finalizers_727;
		 }
	    }
	 }
      }
   }
}


/* _impuse-finalizer */ obj_t 
_impuse_finalizer_29_module_impuse(obj_t env_1650)
{
   return impuse_finalizer_42_module_impuse();
}


/* import-parser */ obj_t 
import_parser_53_module_impuse(obj_t module_46, obj_t prototype_47)
{
   {
      obj_t proto_729;
      proto_729 = parse_prototype_143_module_prototype(prototype_47);
      if (PAIRP(proto_729))
	{
	   obj_t case_value_58_731;
	   case_value_58_731 = CAR(proto_729);
	   {
	      bool_t test_2216;
	      {
		 obj_t aux_2217;
		 aux_2217 = memq___r4_pairs_and_lists_6_3(case_value_58_731, CNST_TABLE_REF(((long) 14)));
		 test_2216 = CBOOL(aux_2217);
	      }
	      if (test_2216)
		{
		   global_t aux_2221;
		   {
		      obj_t aux_2226;
		      obj_t aux_2222;
		      {
			 obj_t aux_2227;
			 {
			    obj_t aux_2228;
			    aux_2228 = CDR(proto_729);
			    aux_2227 = CDR(aux_2228);
			 }
			 aux_2226 = CAR(aux_2227);
		      }
		      {
			 obj_t aux_2223;
			 aux_2223 = CDR(proto_729);
			 aux_2222 = CAR(aux_2223);
		      }
		      aux_2221 = declare_global_sfun__255_ast_glo_decl_237(aux_2222, aux_2226, module_46, CNST_TABLE_REF(((long) 0)), case_value_58_731, prototype_47);
		   }
		   return (obj_t) (aux_2221);
		}
	      else
		{
		   bool_t test_2235;
		   {
		      obj_t aux_2236;
		      aux_2236 = CNST_TABLE_REF(((long) 15));
		      test_2235 = (case_value_58_731 == aux_2236);
		   }
		   if (test_2235)
		     {
			global_t aux_2239;
			{
			   obj_t aux_2240;
			   {
			      obj_t aux_2241;
			      aux_2241 = CDR(proto_729);
			      aux_2240 = CAR(aux_2241);
			   }
			   aux_2239 = declare_global_svar__200_ast_glo_decl_237(aux_2240, module_46, CNST_TABLE_REF(((long) 0)), prototype_47);
			}
			return (obj_t) (aux_2239);
		     }
		   else
		     {
			bool_t test_2247;
			{
			   obj_t aux_2248;
			   aux_2248 = CNST_TABLE_REF(((long) 16));
			   test_2247 = (case_value_58_731 == aux_2248);
			}
			if (test_2247)
			  {
			     return declare_class__31_module_class(CDR(proto_729), module_46, CNST_TABLE_REF(((long) 0)), ((bool_t) 0), prototype_47);
			  }
			else
			  {
			     bool_t test_2254;
			     {
				obj_t aux_2255;
				aux_2255 = CNST_TABLE_REF(((long) 17));
				test_2254 = (case_value_58_731 == aux_2255);
			     }
			     if (test_2254)
			       {
				  return declare_class__31_module_class(CDR(proto_729), module_46, CNST_TABLE_REF(((long) 0)), ((bool_t) 1), prototype_47);
			       }
			     else
			       {
				  bool_t test_2261;
				  {
				     obj_t aux_2262;
				     aux_2262 = CNST_TABLE_REF(((long) 18));
				     test_2261 = (case_value_58_731 == aux_2262);
				  }
				  if (test_2261)
				    {
				       return declare_wide_class__13_module_class(CDR(proto_729), module_46, CNST_TABLE_REF(((long) 0)), prototype_47);
				    }
				  else
				    {
				       obj_t list1531_752;
				       list1531_752 = MAKE_PAIR(BNIL, BNIL);
				       return user_error_151_tools_error(string1713_module_impuse, string1716_module_impuse, prototype_47, list1531_752);
				    }
			       }
			  }
		     }
		}
	   }
	}
      else
	{
	   obj_t list1543_762;
	   list1543_762 = MAKE_PAIR(BNIL, BNIL);
	   return user_error_151_tools_error(string1713_module_impuse, string1716_module_impuse, prototype_47, list1543_762);
	}
   }
}


/* _import-parser */ obj_t 
_import_parser_19_module_impuse(obj_t env_1665, obj_t module_1666, obj_t prototype_1667)
{
   return import_parser_53_module_impuse(module_1666, prototype_1667);
}


/* read-imported-module */ obj_t 
read_imported_module_112_module_impuse(obj_t imode_48)
{
   {
      obj_t module_764;
      module_764 = STRUCT_REF(imode_48, ((long) 0));
      {
	 obj_t wanted_765;
	 wanted_765 = STRUCT_REF(imode_48, ((long) 2));
	 {
	    obj_t b_766;
	    b_766 = assq___r4_pairs_and_lists_6_3(module_764, _access_table__91_engine_param);
	    {
	       {
		  char *arg1550_769;
		  {
		     bool_t test_2276;
		     {
			obj_t aux_2279;
			obj_t aux_2277;
			aux_2279 = CNST_TABLE_REF(((long) 2));
			aux_2277 = STRUCT_REF(imode_48, ((long) 1));
			test_2276 = (aux_2277 == aux_2279);
		     }
		     if (test_2276)
		       {
			  arg1550_769 = "used";
		       }
		     else
		       {
			  arg1550_769 = "imported";
		       }
		  }
		  {
		     obj_t list1554_772;
		     {
			obj_t arg1555_773;
			{
			   obj_t arg1556_774;
			   {
			      obj_t arg1557_775;
			      {
				 obj_t arg1558_776;
				 {
				    obj_t arg1559_777;
				    {
				       obj_t aux_2282;
				       aux_2282 = BCHAR(((unsigned char) '\n'));
				       arg1559_777 = MAKE_PAIR(aux_2282, BNIL);
				    }
				    arg1558_776 = MAKE_PAIR(string1717_module_impuse, arg1559_777);
				 }
				 arg1557_775 = MAKE_PAIR(module_764, arg1558_776);
			      }
			      arg1556_774 = MAKE_PAIR(string1718_module_impuse, arg1557_775);
			   }
			   {
			      obj_t aux_2288;
			      aux_2288 = string_to_bstring(arg1550_769);
			      arg1555_773 = MAKE_PAIR(aux_2288, arg1556_774);
			   }
			}
			list1554_772 = MAKE_PAIR(string1719_module_impuse, arg1555_773);
		     }
		     verbose_tools_speek(BINT(((long) 2)), list1554_772);
		  }
	       }
	       if (CBOOL(b_766))
		 {
		    obj_t fnames_782;
		    fnames_782 = CDR(b_766);
		    {
		       obj_t fname_783;
		       fname_783 = find_file_path_55_tools_file(CAR(fnames_782), _load_path__54___eval);
		       {
			  if (STRINGP(fname_783))
			    {
			       obj_t port_785;
			       port_785 = open_input_file_61___r4_ports_6_10_1(fname_783, BNIL);
			       if (INPUT_PORTP(port_785))
				 {
				    obj_t handler_1673;
				    handler_1673 = make_fx_procedure(handler_module_impuse, ((long) 4), ((long) 1));
				    PROCEDURE_SET(handler_1673, ((long) 0), port_785);
				    {
				       obj_t armed1198_788;
				       obj_t handler1195_789;
				       armed1198_788 = MAKE_CELL(BUNSPEC);
				       handler1195_789 = MAKE_CELL(BUNSPEC);
				       {
					  obj_t body1197_1669;
					  obj_t rhandler1196_1671;
					  body1197_1669 = make_fx_procedure(body1197_module_impuse, ((long) 0), ((long) 5));
					  rhandler1196_1671 = make_fx_procedure(rhandler1196_module_impuse, ((long) 4), ((long) 2));
					  PROCEDURE_SET(body1197_1669, ((long) 0), port_785);
					  PROCEDURE_SET(body1197_1669, ((long) 1), module_764);
					  PROCEDURE_SET(body1197_1669, ((long) 2), imode_48);
					  PROCEDURE_SET(body1197_1669, ((long) 3), wanted_765);
					  PROCEDURE_SET(body1197_1669, ((long) 4), fnames_782);
					  PROCEDURE_SET(rhandler1196_1671, ((long) 0), armed1198_788);
					  PROCEDURE_SET(rhandler1196_1671, ((long) 1), handler1195_789);
					  CELL_SET(handler1195_789, handler_1673);
					  CELL_SET(armed1198_788, BTRUE);
					  return handling_function1566_module_impuse(body1197_1669, rhandler1196_1671, handler1195_789, armed1198_788);
				       }
				    }
				 }
			       else
				 {
				    obj_t arg1589_833;
				    arg1589_833 = CAR(fnames_782);
				    {
				       obj_t list1593_835;
				       list1593_835 = MAKE_PAIR(BNIL, BNIL);
				       return user_error_151_tools_error(string1720_module_impuse, string1721_module_impuse, arg1589_833, list1593_835);
				    }
				 }
			    }
			  else
			    {
			       obj_t arg1602_840;
			       arg1602_840 = CAR(fnames_782);
			       {
				  obj_t list1604_842;
				  list1604_842 = MAKE_PAIR(BNIL, BNIL);
				  return user_error_151_tools_error(string1720_module_impuse, string1721_module_impuse, arg1602_840, list1604_842);
			       }
			    }
		       }
		    }
		 }
	       else
		 {
		    obj_t list1610_848;
		    list1610_848 = MAKE_PAIR(BNIL, BNIL);
		    return user_error_151_tools_error(string1720_module_impuse, string1722_module_impuse, module_764, list1610_848);
		 }
	    }
	 }
      }
   }
}


/* handling_function1566 */ obj_t 
handling_function1566_module_impuse(obj_t body1197_1711, obj_t rhandler1196_1710, obj_t handler1195_1709, obj_t armed1198_1708)
{
   jmp_buf jmpbuf;
   obj_t an_exit1199_793;
   if (SET_EXIT(an_exit1199_793))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1199_793 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1199_793, ((bool_t) 1));
	   {
	      obj_t an_exitd1200_794;
	      an_exitd1200_794 = exitd_top;
	      {
		 obj_t escape_1670;
		 escape_1670 = make_fx_procedure(escape_module_impuse, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_1670, ((long) 0), an_exitd1200_794);
		 {
		    obj_t res1202_797;
		    {
		       obj_t arg1569_1668;
		       obj_t arg1568_1672;
		       arg1569_1668 = make_fx_procedure(arg1569_module_impuse, ((long) 0), ((long) 1));
		       arg1568_1672 = make_fx_procedure(arg1568_module_impuse, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1569_1668, ((long) 0), armed1198_1708);
		       PROCEDURE_SET(arg1568_1672, ((long) 0), an_exitd1200_794);
		       PROCEDURE_SET(arg1568_1672, ((long) 1), armed1198_1708);
		       PROCEDURE_SET(arg1568_1672, ((long) 2), handler1195_1709);
		       PROCEDURE_SET(arg1568_1672, ((long) 3), rhandler1196_1710);
		       PROCEDURE_SET(arg1568_1672, ((long) 4), escape_1670);
		       res1202_797 = dynamic_wind_31___r4_control_features_6_9(arg1568_1672, body1197_1711, arg1569_1668);
		    }
		    POP_EXIT();
		    return res1202_797;
		 }
	      }
	   }
	}
     }
}


/* arg1569 */ obj_t 
arg1569_module_impuse(obj_t env_1674)
{
   {
      obj_t armed1198_1675;
      armed1198_1675 = PROCEDURE_REF(env_1674, ((long) 0));
      {
	 {
	    bool_t test_2340;
	    {
	       obj_t aux_2341;
	       aux_2341 = CELL_REF(armed1198_1675);
	       test_2340 = CBOOL(aux_2341);
	    }
	    if (test_2340)
	      {
		 CELL_SET(armed1198_1675, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1197 */ obj_t 
body1197_module_impuse(obj_t env_1677)
{
   {
      obj_t port_1678;
      obj_t module_1679;
      obj_t imode_1680;
      obj_t wanted_1681;
      obj_t fnames_1682;
      port_1678 = PROCEDURE_REF(env_1677, ((long) 0));
      module_1679 = PROCEDURE_REF(env_1677, ((long) 1));
      imode_1680 = PROCEDURE_REF(env_1677, ((long) 2));
      wanted_1681 = PROCEDURE_REF(env_1677, ((long) 3));
      fnames_1682 = PROCEDURE_REF(env_1677, ((long) 4));
      {
	 {
	    obj_t mdecl_810;
	    {
	       obj_t list1582_819;
	       {
		  obj_t arg1583_820;
		  arg1583_820 = MAKE_PAIR(BTRUE, BNIL);
		  list1582_819 = MAKE_PAIR(port_1678, arg1583_820);
	       }
	       mdecl_810 = compiler_read_18_read_reader(list1582_819);
	    }
	    {
	       obj_t prov_811;
	       {
		  obj_t arg1580_817;
		  obj_t arg1581_818;
		  reset_include_consumed_directive__234_module_include();
		  reset_include_consumed_code__8_module_include();
		  arg1580_817 = consume_module__183_module_module(module_1679, mdecl_810);
		  arg1581_818 = get_include_consumed_directive_80_module_include();
		  prov_811 = append_2_18___r4_pairs_and_lists_6_3(arg1580_817, arg1581_818);
	       }
	       {
		  obj_t code_812;
		  code_812 = get_include_consumed_code_244_module_include();
		  {
		     obj_t check_813;
		     check_813 = checksum_module_8_module_module(mdecl_810);
		     {
			STRUCT_SET(imode_1680, ((long) 3), check_813);
			{
			   obj_t arg1575_814;
			   obj_t arg1578_815;
			   if (PAIRP(wanted_1681))
			     {
				arg1575_814 = import_wanted_18_module_impuse(prov_811, wanted_1681, module_1679);
			     }
			   else
			     {
				arg1575_814 = import_everything_193_module_impuse(prov_811, module_1679);
			     }
			   arg1578_815 = CDR(fnames_1682);
			   look_for_inline_98_read_inline(arg1575_814, code_812, port_1678, arg1578_815, module_1679);
			}
			return close_input_port(port_1678);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* arg1568 */ obj_t 
arg1568_module_impuse(obj_t env_1683)
{
   {
      obj_t rhandler1196_1687;
      obj_t escape_1688;
      rhandler1196_1687 = PROCEDURE_REF(env_1683, ((long) 3));
      escape_1688 = PROCEDURE_REF(env_1683, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1196_1687, escape_1688);
      }
   }
}


/* escape */ obj_t 
escape_module_impuse(obj_t env_1689, obj_t val1201_1691)
{
   {
      obj_t an_exitd1200_1690;
      an_exitd1200_1690 = PROCEDURE_REF(env_1689, ((long) 0));
      {
	 obj_t val1201_795;
	 val1201_795 = val1201_1691;
	 return unwind_until__178___bexit(an_exitd1200_1690, val1201_795);
      }
   }
}


/* rhandler1196 */ obj_t 
rhandler1196_module_impuse(obj_t env_1692, obj_t esc_1695, obj_t obj_1696, obj_t proc_1697, obj_t msg_1698)
{
   {
      obj_t armed1198_1693;
      obj_t handler1195_1694;
      armed1198_1693 = PROCEDURE_REF(env_1692, ((long) 0));
      handler1195_1694 = PROCEDURE_REF(env_1692, ((long) 1));
      {
	 obj_t esc_804;
	 obj_t obj_805;
	 obj_t proc_806;
	 obj_t msg_807;
	 esc_804 = esc_1695;
	 obj_805 = obj_1696;
	 proc_806 = proc_1697;
	 msg_807 = msg_1698;
	 CELL_SET(armed1198_1693, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_2376;
	    aux_2376 = CELL_REF(handler1195_1694);
	    return PROCEDURE_ENTRY(aux_2376) (CELL_REF(handler1195_1694), esc_804, obj_805, proc_806, msg_807, BEOA);
	 }
      }
   }
}


/* handler */ obj_t 
handler_module_impuse(obj_t env_1700, obj_t escape_1702, obj_t proc_1703, obj_t mes_1704, obj_t obj_1705)
{
   {
      obj_t port_1701;
      port_1701 = PROCEDURE_REF(env_1700, ((long) 0));
      {
	 obj_t escape_824;
	 obj_t proc_825;
	 obj_t mes_826;
	 obj_t obj_827;
	 escape_824 = escape_1702;
	 proc_825 = proc_1703;
	 mes_826 = mes_1704;
	 obj_827 = obj_1705;
	 notify_error_43___error(proc_825, mes_826, obj_827);
	 FLUSH_OUTPUT_PORT(current_error_port);
	 close_input_port(port_1701);
	 return exit_bigloo_229_init_main(BINT(((long) -7)));
      }
   }
}


/* import-everything */ obj_t 
import_everything_193_module_impuse(obj_t provided_49, obj_t module_50)
{
   {
      obj_t provided_850;
      obj_t inline_851;
      provided_850 = provided_49;
      inline_851 = BNIL;
    loop_852:
      if (NULLP(provided_850))
	{
	   return inline_851;
	}
      else
	{
	   obj_t p_855;
	   p_855 = import_parser_53_module_impuse(module_50, CAR(provided_850));
	   {
	      bool_t test1615_856;
	      test1615_856 = is_a__118___object(p_855, global_ast_var);
	      if (test1615_856)
		{
		   value_t val_857;
		   {
		      global_t obj_1583;
		      obj_1583 = (global_t) (p_855);
		      val_857 = (((global_t) CREF(obj_1583))->value);
		   }
		   {
		      obj_t arg1617_858;
		      obj_t arg1618_859;
		      arg1617_858 = CDR(provided_850);
		      {
			 bool_t test1619_860;
			 {
			    bool_t test1626_867;
			    test1626_867 = is_a__118___object(p_855, global_ast_var);
			    if (test1626_867)
			      {
				 bool_t test1627_868;
				 test1627_868 = is_a__118___object((obj_t) (val_857), sfun_ast_var);
				 if (test1627_868)
				   {
				      test1619_860 = ((bool_t) 0);
				   }
				 else
				   {
				      test1619_860 = ((bool_t) 1);
				   }
			      }
			    else
			      {
				 test1619_860 = ((bool_t) 1);
			      }
			 }
			 if (test1619_860)
			   {
			      arg1618_859 = inline_851;
			   }
			 else
			   {
			      bool_t test_2398;
			      {
				 obj_t aux_2402;
				 obj_t aux_2399;
				 aux_2402 = CNST_TABLE_REF(((long) 19));
				 {
				    sfun_t obj_1587;
				    obj_1587 = (sfun_t) (val_857);
				    aux_2399 = (((sfun_t) CREF(obj_1587))->class);
				 }
				 test_2398 = (aux_2399 == aux_2402);
			      }
			      if (test_2398)
				{
				   {
				      obj_t arg1621_862;
				      {
					 obj_t aux_2408;
					 obj_t aux_2405;
					 aux_2408 = CNST_TABLE_REF(((long) 19));
					 {
					    global_t obj_1590;
					    obj_1590 = (global_t) (p_855);
					    aux_2405 = (((global_t) CREF(obj_1590))->id);
					 }
					 arg1621_862 = MAKE_PAIR(aux_2405, aux_2408);
				      }
				      arg1618_859 = MAKE_PAIR(arg1621_862, inline_851);
				   }
				}
			      else
				{
				   arg1618_859 = inline_851;
				}
			   }
		      }
		      {
			 obj_t inline_2413;
			 obj_t provided_2412;
			 provided_2412 = arg1617_858;
			 inline_2413 = arg1618_859;
			 inline_851 = inline_2413;
			 provided_850 = provided_2412;
			 goto loop_852;
		      }
		   }
		}
	      else
		{
		   obj_t provided_2414;
		   provided_2414 = CDR(provided_850);
		   provided_850 = provided_2414;
		   goto loop_852;
		}
	   }
	}
   }
}


/* import-wanted */ obj_t 
import_wanted_18_module_impuse(obj_t provided_51, obj_t wanted_52, obj_t module_53)
{
   {
      obj_t provided_871;
      obj_t inline_872;
      obj_t wanted_873;
      provided_871 = provided_51;
      inline_872 = BNIL;
      wanted_873 = wanted_52;
    loop_874:
      if (NULLP(wanted_873))
	{
	   return inline_872;
	}
      else
	{
	   if (NULLP(provided_871))
	     {
		{
		   obj_t list1639_880;
		   list1639_880 = MAKE_PAIR(BNIL, BNIL);
		   return user_error_151_tools_error(module_53, string1723_module_impuse, wanted_873, list1639_880);
		}
	     }
	   else
	     {
		{
		   obj_t proto_882;
		   proto_882 = parse_prototype_143_module_prototype(CAR(provided_871));
		   if (PAIRP(proto_882))
		     {
			obj_t id_884;
			{
			   obj_t aux_2426;
			   {
			      obj_t aux_2427;
			      aux_2427 = CDR(proto_882);
			      aux_2426 = CAR(aux_2427);
			   }
			   id_884 = fast_id_of_id_130_ast_ident(aux_2426);
			}
			{
			   bool_t test_2431;
			   {
			      obj_t aux_2432;
			      aux_2432 = memq___r4_pairs_and_lists_6_3(id_884, wanted_873);
			      test_2431 = CBOOL(aux_2432);
			   }
			   if (test_2431)
			     {
				obj_t p_886;
				p_886 = import_parser_53_module_impuse(module_53, CAR(provided_871));
				{
				   bool_t test1643_887;
				   test1643_887 = is_a__118___object(p_886, global_ast_var);
				   if (test1643_887)
				     {
					{
					   obj_t arg1645_888;
					   obj_t arg1646_889;
					   obj_t arg1647_890;
					   arg1645_888 = CDR(provided_871);
					   {
					      bool_t test_2440;
					      {
						 obj_t aux_2443;
						 obj_t aux_2441;
						 aux_2443 = CNST_TABLE_REF(((long) 19));
						 aux_2441 = CAR(proto_882);
						 test_2440 = (aux_2441 == aux_2443);
					      }
					      if (test_2440)
						{
						   {
						      obj_t arg1649_892;
						      {
							 obj_t aux_2446;
							 aux_2446 = CNST_TABLE_REF(((long) 19));
							 arg1649_892 = MAKE_PAIR(id_884, aux_2446);
						      }
						      arg1646_889 = MAKE_PAIR(arg1649_892, inline_872);
						   }
						}
					      else
						{
						   arg1646_889 = inline_872;
						}
					   }
					   arg1647_890 = remq__51___r4_pairs_and_lists_6_3(id_884, wanted_873);
					   {
					      obj_t wanted_2453;
					      obj_t inline_2452;
					      obj_t provided_2451;
					      provided_2451 = arg1645_888;
					      inline_2452 = arg1646_889;
					      wanted_2453 = arg1647_890;
					      wanted_873 = wanted_2453;
					      inline_872 = inline_2452;
					      provided_871 = provided_2451;
					      goto loop_874;
					   }
					}
				     }
				   else
				     {
					bool_t test1654_896;
					test1654_896 = is_a__118___object(p_886, type_type_type);
					if (test1654_896)
					  {
					     {
						obj_t arg1655_897;
						obj_t arg1656_898;
						arg1655_897 = CDR(provided_871);
						arg1656_898 = remq__51___r4_pairs_and_lists_6_3(id_884, wanted_873);
						{
						   obj_t wanted_2459;
						   obj_t provided_2458;
						   provided_2458 = arg1655_897;
						   wanted_2459 = arg1656_898;
						   wanted_873 = wanted_2459;
						   provided_871 = provided_2458;
						   goto loop_874;
						}
					     }
					  }
					else
					  {
					     {
						obj_t arg1657_899;
						obj_t arg1658_900;
						arg1657_899 = CDR(provided_871);
						arg1658_900 = remq__51___r4_pairs_and_lists_6_3(id_884, wanted_873);
						{
						   obj_t wanted_2463;
						   obj_t provided_2462;
						   provided_2462 = arg1657_899;
						   wanted_2463 = arg1658_900;
						   wanted_873 = wanted_2463;
						   provided_871 = provided_2462;
						   goto loop_874;
						}
					     }
					  }
				     }
				}
			     }
			   else
			     {
				obj_t provided_2464;
				provided_2464 = CDR(provided_871);
				provided_871 = provided_2464;
				goto loop_874;
			     }
			}
		     }
		   else
		     {
			obj_t provided_2466;
			provided_2466 = CDR(provided_871);
			provided_871 = provided_2466;
			goto loop_874;
		     }
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_module_impuse()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_impuse()
{
   module_initialization_70_tools_trace(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_read_reader(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_module_module(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_module_prototype(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_module_class(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_module_include(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_tools_speek(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_tools_error(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_tools_file(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_type_type(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_read_access(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_read_inline(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_ast_var(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_ast_find_gdefs_13(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_ast_glo_decl_237(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_ast_ident(((long) 0), "MODULE_IMPUSE");
   module_initialization_70_engine_param(((long) 0), "MODULE_IMPUSE");
   return module_initialization_70_init_main(((long) 0), "MODULE_IMPUSE");
}
