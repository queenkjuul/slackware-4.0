/*===========================================================================*/
/*   (Rgc/rgc-set.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t rgcset_add__25___rgc_set(obj_t, int);
extern obj_t string_to_symbol(char *);
static obj_t _rgcset_or__213___rgc_set(obj_t, obj_t, obj_t);
static obj_t _rgcset_not_80___rgc_set(obj_t, obj_t);
static obj_t symbol1265___rgc_set = BUNSPEC;
static obj_t _rgcset__list_30___rgc_set(obj_t, obj_t);
extern obj_t rgcset_remove__162___rgc_set(obj_t, int);
static obj_t toplevel_init_63___rgc_set();
static obj_t _for_each_rgcset_131___rgc_set(obj_t, obj_t, obj_t);
extern int rgcset__hash_57___rgc_set(obj_t);
static obj_t _list__rgcset_118___rgc_set(obj_t, obj_t, obj_t);
extern obj_t create_struct(obj_t, long);
static obj_t _rgcset_or_0___rgc_set(obj_t, obj_t, obj_t);
extern obj_t rgcset_or__64___rgc_set(obj_t, obj_t);
extern int rgcset_length_163___rgc_set(obj_t);
extern obj_t rgcset_not_149___rgc_set(obj_t);
static obj_t _rgcset_member__53___rgc_set(obj_t, obj_t, obj_t);
static obj_t _rgcset_and__183___rgc_set(obj_t, obj_t, obj_t);
static obj_t _rgcset_length_140___rgc_set(obj_t, obj_t);
extern obj_t rgcset__list_240___rgc_set(obj_t);
extern obj_t module_initialization_70___rgc_set(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern bool_t rgcset_equal__214___rgc_set(obj_t, obj_t);
extern obj_t rgcset_or_160___rgc_set(obj_t, obj_t);
extern obj_t rgcset_and__23___rgc_set(obj_t, obj_t);
static obj_t arg1081___rgc_set(obj_t, obj_t);
static obj_t _rgcset_equal__209___rgc_set(obj_t, obj_t, obj_t);
static long bit_per_word_40___rgc_set;
static obj_t _rgcset_not__80___rgc_set(obj_t, obj_t);
static obj_t _make_rgcset_65___rgc_set(obj_t, obj_t);
extern obj_t list__rgcset_152___rgc_set(obj_t, int);
extern bool_t _2__116___r4_numbers_6_5(obj_t, obj_t);
static obj_t _rgcset_remove__52___rgc_set(obj_t, obj_t, obj_t);
extern obj_t _2__79___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
static obj_t _rgcset_but__134___rgc_set(obj_t, obj_t, obj_t);
extern obj_t for_each_rgcset_171___rgc_set(obj_t, obj_t);
extern bool_t rgcset_member__212___rgc_set(obj_t, int);
static obj_t imported_modules_init_94___rgc_set();
static obj_t _rgcset__hash_54___rgc_set(obj_t, obj_t);
static obj_t _rgcset_add__45___rgc_set(obj_t, obj_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern obj_t rgcset_not__199___rgc_set(obj_t);
static obj_t require_initialization_114___rgc_set = BUNSPEC;
extern obj_t make_rgcset_69___rgc_set(int);
extern obj_t rgcset_but__159___rgc_set(obj_t, obj_t);
static obj_t cnst_init_137___rgc_set();
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( rgcset_not_env_191___rgc_set, _rgcset_not_80___rgc_set1267, _rgcset_not_80___rgc_set, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgcset_not__env_206___rgc_set, _rgcset_not__80___rgc_set1268, _rgcset_not__80___rgc_set, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgcset_or_env_157___rgc_set, _rgcset_or_0___rgc_set1269, _rgcset_or_0___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( make_rgcset_env_84___rgc_set, _make_rgcset_65___rgc_set1270, _make_rgcset_65___rgc_set, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgcset_remove__env_197___rgc_set, _rgcset_remove__52___rgc_set1271, _rgcset_remove__52___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset_equal__env_103___rgc_set, _rgcset_equal__209___rgc_set1272, _rgcset_equal__209___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset_but__env_139___rgc_set, _rgcset_but__134___rgc_set1273, _rgcset_but__134___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset__list_env_95___rgc_set, _rgcset__list_30___rgc_set1274, _rgcset__list_30___rgc_set, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgcset_add__env_47___rgc_set, _rgcset_add__45___rgc_set1275, _rgcset_add__45___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset_or__env_41___rgc_set, _rgcset_or__213___rgc_set1276, _rgcset_or__213___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset__hash_env_240___rgc_set, _rgcset__hash_54___rgc_set1277, _rgcset__hash_54___rgc_set, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( rgcset_member__env_145___rgc_set, _rgcset_member__53___rgc_set1278, _rgcset_member__53___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset_and__env_241___rgc_set, _rgcset_and__183___rgc_set1279, _rgcset_and__183___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( rgcset_length_env_255___rgc_set, _rgcset_length_140___rgc_set1280, _rgcset_length_140___rgc_set, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( for_each_rgcset_env_115___rgc_set, _for_each_rgcset_131___rgc_set1281, _for_each_rgcset_131___rgc_set, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( list__rgcset_env_114___rgc_set, _list__rgcset_118___rgc_set1282, _list__rgcset_118___rgc_set, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___rgc_set(long checksum_1439, char * from_1440)
{
if(CBOOL(require_initialization_114___rgc_set)){
require_initialization_114___rgc_set = BBOOL(((bool_t)0));
cnst_init_137___rgc_set();
imported_modules_init_94___rgc_set();
toplevel_init_63___rgc_set();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc_set()
{
return (symbol1265___rgc_set = string_to_symbol("__RGCSET"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___rgc_set()
{
{
long ptr_align_30_389;
ptr_align_30_389 = PTR_ALIGNMENT;
{
long aux_1449;
{
long aux_1450;
aux_1450 = (ptr_align_30_389+((long)3));
aux_1449 = (((long)1) << aux_1450);
}
bit_per_word_40___rgc_set = (aux_1449-ptr_align_30_389);
}
}
return BUNSPEC;
}


/* make-rgcset */obj_t make_rgcset_69___rgc_set(int size_11)
{
{
obj_t arg1029_730;
{
obj_t aux_1465;
long aux_1454;
aux_1465 = BINT(((long)0));
{
obj_t aux_1455;
{
obj_t aux_1456;
{
long aux_1458;
{
long aux_1459;
aux_1459 = (long)(size_11);
aux_1458 = (aux_1459/bit_per_word_40___rgc_set);
}
aux_1456 = BINT(aux_1458);
}
aux_1455 = _2__168___r4_numbers_6_5(BINT(((long)1)), aux_1456);
}
aux_1454 = (long)CINT(aux_1455);
}
arg1029_730 = make_vector(aux_1454, aux_1465);
}
{
obj_t new_739;
new_739 = create_struct(symbol1265___rgc_set, ((long)2));
STRUCT_SET(new_739, ((long)1), arg1029_730);
{
obj_t aux_1470;
aux_1470 = BINT(size_11);
STRUCT_SET(new_739, ((long)0), aux_1470);
}
return new_739;
}
}
}


/* _make-rgcset */obj_t _make_rgcset_65___rgc_set(obj_t env_1391, obj_t size_1392)
{
return make_rgcset_69___rgc_set(CINT(size_1392));
}


/* rgcset-add! */obj_t rgcset_add__25___rgc_set(obj_t rgcset_18, int num_19)
{
{
long word_num_101_770;
{
long aux_1475;
aux_1475 = (long)(num_19);
word_num_101_770 = (aux_1475/bit_per_word_40___rgc_set);
}
{
long word_bit_99_771;
{
long aux_1478;
aux_1478 = (long)(num_19);
word_bit_99_771 = (aux_1478%bit_per_word_40___rgc_set);
}
{
{
obj_t aux_1483;
obj_t aux_1481;
{
long aux_1484;
{
long aux_1491;
long aux_1485;
aux_1491 = (((long)1) << word_bit_99_771);
{
obj_t aux_1486;
{
obj_t aux_1487;
aux_1487 = STRUCT_REF(rgcset_18, ((long)1));
aux_1486 = VECTOR_REF(aux_1487, word_num_101_770);
}
aux_1485 = (long)CINT(aux_1486);
}
aux_1484 = (aux_1485 | aux_1491);
}
aux_1483 = BINT(aux_1484);
}
aux_1481 = STRUCT_REF(rgcset_18, ((long)1));
return VECTOR_SET(aux_1481, word_num_101_770, aux_1483);
}
}
}
}
}


/* _rgcset-add! */obj_t _rgcset_add__45___rgc_set(obj_t env_1393, obj_t rgcset_1394, obj_t num_1395)
{
return rgcset_add__25___rgc_set(rgcset_1394, CINT(num_1395));
}


/* rgcset-member? */bool_t rgcset_member__212___rgc_set(obj_t set_20, int num_21)
{
{
long word_num_101_801;
{
long aux_1498;
aux_1498 = (long)(num_21);
word_num_101_801 = (aux_1498/bit_per_word_40___rgc_set);
}
{
long word_bit_99_802;
{
long aux_1501;
aux_1501 = (long)(num_21);
word_bit_99_802 = (aux_1501%bit_per_word_40___rgc_set);
}
{
long mask_804;
mask_804 = (((long)1) << word_bit_99_802);
{
{
long aux_1505;
{
long aux_1506;
{
obj_t aux_1507;
{
obj_t aux_1508;
aux_1508 = STRUCT_REF(set_20, ((long)1));
aux_1507 = VECTOR_REF(aux_1508, word_num_101_801);
}
aux_1506 = (long)CINT(aux_1507);
}
aux_1505 = (aux_1506 & mask_804);
}
return (mask_804==aux_1505);
}
}
}
}
}
}


/* _rgcset-member? */obj_t _rgcset_member__53___rgc_set(obj_t env_1396, obj_t set_1397, obj_t num_1398)
{
{
bool_t aux_1514;
aux_1514 = rgcset_member__212___rgc_set(set_1397, CINT(num_1398));
return BBOOL(aux_1514);
}
}


/* list->rgcset */obj_t list__rgcset_152___rgc_set(obj_t lst_22, int max_23)
{
{
obj_t set_824;
{
obj_t arg1029_831;
{
obj_t aux_1529;
long aux_1518;
aux_1529 = BINT(((long)0));
{
obj_t aux_1519;
{
obj_t aux_1520;
{
long aux_1522;
{
long aux_1523;
aux_1523 = (long)(max_23);
aux_1522 = (aux_1523/bit_per_word_40___rgc_set);
}
aux_1520 = BINT(aux_1522);
}
aux_1519 = _2__168___r4_numbers_6_5(BINT(((long)1)), aux_1520);
}
aux_1518 = (long)CINT(aux_1519);
}
arg1029_831 = make_vector(aux_1518, aux_1529);
}
{
obj_t new_840;
new_840 = create_struct(symbol1265___rgc_set, ((long)2));
STRUCT_SET(new_840, ((long)1), arg1029_831);
{
obj_t aux_1534;
aux_1534 = BINT(max_23);
STRUCT_SET(new_840, ((long)0), aux_1534);
}
set_824 = new_840;
}
}
{
obj_t l1002_854;
l1002_854 = lst_22;
lname1003_853:
if(PAIRP(l1002_854)){
{
int aux_1539;
{
obj_t aux_1540;
aux_1540 = CAR(l1002_854);
aux_1539 = CINT(aux_1540);
}
rgcset_add__25___rgc_set(set_824, aux_1539);
}
{
obj_t l1002_1544;
l1002_1544 = CDR(l1002_854);
l1002_854 = l1002_1544;
goto lname1003_853;
}
}
 else {
((bool_t)1);
}
}
return set_824;
}
}


/* _list->rgcset */obj_t _list__rgcset_118___rgc_set(obj_t env_1399, obj_t lst_1400, obj_t max_1401)
{
return list__rgcset_152___rgc_set(lst_1400, CINT(max_1401));
}


/* rgcset->list */obj_t rgcset__list_240___rgc_set(obj_t set_24)
{
{
obj_t max_434;
long maxmask_435;
max_434 = STRUCT_REF(set_24, ((long)0));
maxmask_435 = (((long)1) << bit_per_word_40___rgc_set);
{
long i_436;
long word_num_101_437;
obj_t word_438;
long mask_439;
obj_t res_440;
i_436 = ((long)0);
word_num_101_437 = ((long)0);
{
obj_t aux_1583;
aux_1583 = STRUCT_REF(set_24, ((long)1));
word_438 = VECTOR_REF(aux_1583, ((long)0));
}
mask_439 = ((long)1);
res_440 = BNIL;
loop_441:
{
bool_t test_1550;
{
long aux_1551;
aux_1551 = (long)CINT(max_434);
test_1550 = (i_436==aux_1551);
}
if(test_1550){
return res_440;
}
 else {
if((mask_439==maxmask_435)){
{
long mask_1564;
obj_t word_1558;
long word_num_101_1556;
word_num_101_1556 = (word_num_101_437+((long)1));
{
long aux_1561;
obj_t aux_1559;
aux_1561 = (word_num_101_437+((long)1));
aux_1559 = STRUCT_REF(set_24, ((long)1));
word_1558 = VECTOR_REF(aux_1559, aux_1561);
}
mask_1564 = ((long)1);
mask_439 = mask_1564;
word_438 = word_1558;
word_num_101_437 = word_num_101_1556;
goto loop_441;
}
}
 else {
bool_t test_1565;
{
long aux_1566;
{
long aux_1567;
aux_1567 = (long)CINT(word_438);
aux_1566 = (aux_1567 & mask_439);
}
test_1565 = (aux_1566==mask_439);
}
if(test_1565){
{
long arg1056_454;
long arg1057_455;
obj_t arg1058_456;
arg1056_454 = (i_436+((long)1));
arg1057_455 = (mask_439 << ((long)1));
{
obj_t aux_1573;
aux_1573 = BINT(i_436);
arg1058_456 = MAKE_PAIR(aux_1573, res_440);
}
{
obj_t res_1578;
long mask_1577;
long i_1576;
i_1576 = arg1056_454;
mask_1577 = arg1057_455;
res_1578 = arg1058_456;
res_440 = res_1578;
mask_439 = mask_1577;
i_436 = i_1576;
goto loop_441;
}
}
}
 else {
{
long mask_1581;
long i_1579;
i_1579 = (i_436+((long)1));
mask_1581 = (mask_439 << ((long)1));
mask_439 = mask_1581;
i_436 = i_1579;
goto loop_441;
}
}
}
}
}
}
}
}


/* _rgcset->list */obj_t _rgcset__list_30___rgc_set(obj_t env_1402, obj_t set_1403)
{
return rgcset__list_240___rgc_set(set_1403);
}


/* for-each-rgcset */obj_t for_each_rgcset_171___rgc_set(obj_t proc_25, obj_t set_26)
{
{
obj_t max_460;
long maxmask_461;
max_460 = STRUCT_REF(set_26, ((long)0));
maxmask_461 = (((long)1) << bit_per_word_40___rgc_set);
{
long i_462;
long word_num_101_463;
obj_t word_464;
long mask_465;
i_462 = ((long)0);
word_num_101_463 = ((long)0);
{
obj_t aux_1621;
aux_1621 = STRUCT_REF(set_26, ((long)1));
word_464 = VECTOR_REF(aux_1621, ((long)0));
}
mask_465 = ((long)1);
loop_466:
{
bool_t test_1589;
{
long aux_1590;
aux_1590 = (long)CINT(max_460);
test_1589 = (i_462==aux_1590);
}
if(test_1589){
return BUNSPEC;
}
 else {
if((mask_465==maxmask_461)){
{
long mask_1603;
obj_t word_1597;
long word_num_101_1595;
word_num_101_1595 = (word_num_101_463+((long)1));
{
long aux_1600;
obj_t aux_1598;
aux_1600 = (word_num_101_463+((long)1));
aux_1598 = STRUCT_REF(set_26, ((long)1));
word_1597 = VECTOR_REF(aux_1598, aux_1600);
}
mask_1603 = ((long)1);
mask_465 = mask_1603;
word_464 = word_1597;
word_num_101_463 = word_num_101_1595;
goto loop_466;
}
}
 else {
bool_t test_1604;
{
long aux_1605;
{
long aux_1606;
aux_1606 = (long)CINT(word_464);
aux_1605 = (aux_1606 & mask_465);
}
test_1604 = (aux_1605==mask_465);
}
if(test_1604){
PROCEDURE_ENTRY(proc_25)(proc_25, BINT(i_462), BEOA);
{
long mask_1615;
long i_1613;
i_1613 = (i_462+((long)1));
mask_1615 = (mask_465 << ((long)1));
mask_465 = mask_1615;
i_462 = i_1613;
goto loop_466;
}
}
 else {
{
long mask_1619;
long i_1617;
i_1617 = (i_462+((long)1));
mask_1619 = (mask_465 << ((long)1));
mask_465 = mask_1619;
i_462 = i_1617;
goto loop_466;
}
}
}
}
}
}
}
}


/* _for-each-rgcset */obj_t _for_each_rgcset_131___rgc_set(obj_t env_1404, obj_t proc_1405, obj_t set_1406)
{
return for_each_rgcset_171___rgc_set(proc_1405, set_1406);
}


/* rgcset-length */int rgcset_length_163___rgc_set(obj_t set_27)
{
{
obj_t num_994;
{
obj_t cellval_1625;
cellval_1625 = BINT(((long)0));
num_994 = MAKE_CELL(cellval_1625);
}
{
obj_t arg1081_1407;
arg1081_1407 = make_fx_procedure(arg1081___rgc_set, ((long)1), ((long)1));
PROCEDURE_SET(arg1081_1407, ((long)0), num_994);
for_each_rgcset_171___rgc_set(arg1081_1407, set_27);
}
{
obj_t aux_1630;
aux_1630 = CELL_REF(num_994);
return CINT(aux_1630);
}
}
}


/* _rgcset-length */obj_t _rgcset_length_140___rgc_set(obj_t env_1408, obj_t set_1409)
{
{
int aux_1632;
aux_1632 = rgcset_length_163___rgc_set(set_1409);
return BINT(aux_1632);
}
}


/* arg1081 */obj_t arg1081___rgc_set(obj_t env_1410, obj_t x_1412)
{
{
obj_t num_1411;
num_1411 = PROCEDURE_REF(env_1410, ((long)0));
{
obj_t x_996;
x_996 = x_1412;
{
obj_t aux_1413;
{
long z2_998;
{
obj_t aux_1636;
aux_1636 = CELL_REF(num_1411);
z2_998 = (long)CINT(aux_1636);
}
{
long aux_1638;
aux_1638 = (((long)1)+z2_998);
aux_1413 = BINT(aux_1638);
}
}
return CELL_SET(num_1411, aux_1413);
}
}
}
}


/* rgcset-not! */obj_t rgcset_not__199___rgc_set(obj_t set_28)
{
{
long len_488;
{
obj_t aux_1641;
aux_1641 = STRUCT_REF(set_28, ((long)1));
len_488 = VECTOR_LENGTH(aux_1641);
}
{
long i_489;
i_489 = ((long)0);
loop_490:
if(_2__116___r4_numbers_6_5(BINT(i_489), BINT(len_488))){
{
obj_t aux_1650;
obj_t aux_1648;
{
long aux_1651;
{
long aux_1652;
{
obj_t aux_1653;
{
obj_t aux_1654;
aux_1654 = STRUCT_REF(set_28, ((long)1));
aux_1653 = VECTOR_REF(aux_1654, i_489);
}
aux_1652 = (long)CINT(aux_1653);
}
aux_1651 = ~(aux_1652);
}
aux_1650 = BINT(aux_1651);
}
aux_1648 = STRUCT_REF(set_28, ((long)1));
VECTOR_SET(aux_1648, i_489, aux_1650);
}
{
long i_1661;
i_1661 = (i_489+((long)1));
i_489 = i_1661;
goto loop_490;
}
}
 else {
return BUNSPEC;
}
}
}
}


/* _rgcset-not! */obj_t _rgcset_not__80___rgc_set(obj_t env_1414, obj_t set_1415)
{
return rgcset_not__199___rgc_set(set_1415);
}


/* rgcset-not */obj_t rgcset_not_149___rgc_set(obj_t set_29)
{
{
long len_495;
obj_t new_496;
{
obj_t aux_1664;
aux_1664 = STRUCT_REF(set_29, ((long)1));
len_495 = VECTOR_LENGTH(aux_1664);
}
{
int size_1035;
{
obj_t aux_1667;
aux_1667 = STRUCT_REF(set_29, ((long)0));
size_1035 = CINT(aux_1667);
}
{
obj_t arg1029_1036;
{
obj_t aux_1681;
long aux_1670;
aux_1681 = BINT(((long)0));
{
obj_t aux_1671;
{
obj_t aux_1672;
{
long aux_1674;
{
long aux_1675;
aux_1675 = (long)(size_1035);
aux_1674 = (aux_1675/bit_per_word_40___rgc_set);
}
aux_1672 = BINT(aux_1674);
}
aux_1671 = _2__168___r4_numbers_6_5(BINT(((long)1)), aux_1672);
}
aux_1670 = (long)CINT(aux_1671);
}
arg1029_1036 = make_vector(aux_1670, aux_1681);
}
{
obj_t new_1045;
new_1045 = create_struct(symbol1265___rgc_set, ((long)2));
STRUCT_SET(new_1045, ((long)1), arg1029_1036);
{
obj_t aux_1686;
aux_1686 = BINT(size_1035);
STRUCT_SET(new_1045, ((long)0), aux_1686);
}
new_496 = new_1045;
}
}
}
{
long i_497;
i_497 = ((long)0);
loop_498:
if(_2__116___r4_numbers_6_5(BINT(i_497), BINT(len_495))){
{
obj_t aux_1695;
obj_t aux_1693;
{
long aux_1696;
{
long aux_1697;
{
obj_t aux_1698;
{
obj_t aux_1699;
aux_1699 = STRUCT_REF(set_29, ((long)1));
aux_1698 = VECTOR_REF(aux_1699, i_497);
}
aux_1697 = (long)CINT(aux_1698);
}
aux_1696 = ~(aux_1697);
}
aux_1695 = BINT(aux_1696);
}
aux_1693 = STRUCT_REF(new_496, ((long)1));
VECTOR_SET(aux_1693, i_497, aux_1695);
}
{
long i_1706;
i_1706 = (i_497+((long)1));
i_497 = i_1706;
goto loop_498;
}
}
 else {
return new_496;
}
}
}
}


/* _rgcset-not */obj_t _rgcset_not_80___rgc_set(obj_t env_1416, obj_t set_1417)
{
return rgcset_not_149___rgc_set(set_1417);
}


/* rgcset-and! */obj_t rgcset_and__23___rgc_set(obj_t set1_30, obj_t set2_31)
{
{
long len1_504;
long len2_505;
{
obj_t aux_1709;
aux_1709 = STRUCT_REF(set1_30, ((long)1));
len1_504 = VECTOR_LENGTH(aux_1709);
}
{
obj_t aux_1712;
aux_1712 = STRUCT_REF(set2_31, ((long)1));
len2_505 = VECTOR_LENGTH(aux_1712);
}
{
long i_506;
i_506 = ((long)0);
loop_507:
{
bool_t test_1715;
if(_2__116___r4_numbers_6_5(BINT(i_506), BINT(len1_504))){
test_1715 = _2__116___r4_numbers_6_5(BINT(i_506), BINT(len2_505));
}
 else {
test_1715 = ((bool_t)0);
}
if(test_1715){
{
obj_t aux_1725;
obj_t aux_1723;
{
long aux_1726;
{
long aux_1733;
long aux_1727;
{
obj_t aux_1734;
{
obj_t aux_1735;
aux_1735 = STRUCT_REF(set2_31, ((long)1));
aux_1734 = VECTOR_REF(aux_1735, i_506);
}
aux_1733 = (long)CINT(aux_1734);
}
{
obj_t aux_1728;
{
obj_t aux_1729;
aux_1729 = STRUCT_REF(set1_30, ((long)1));
aux_1728 = VECTOR_REF(aux_1729, i_506);
}
aux_1727 = (long)CINT(aux_1728);
}
aux_1726 = (aux_1727 & aux_1733);
}
aux_1725 = BINT(aux_1726);
}
aux_1723 = STRUCT_REF(set1_30, ((long)1));
VECTOR_SET(aux_1723, i_506, aux_1725);
}
{
long i_1742;
i_1742 = (i_506+((long)1));
i_506 = i_1742;
goto loop_507;
}
}
 else {
return BUNSPEC;
}
}
}
}
}


/* _rgcset-and! */obj_t _rgcset_and__183___rgc_set(obj_t env_1418, obj_t set1_1419, obj_t set2_1420)
{
return rgcset_and__23___rgc_set(set1_1419, set2_1420);
}


/* rgcset-or! */obj_t rgcset_or__64___rgc_set(obj_t set1_32, obj_t set2_33)
{
{
long len1_514;
{
obj_t aux_1745;
aux_1745 = STRUCT_REF(set1_32, ((long)1));
len1_514 = VECTOR_LENGTH(aux_1745);
}
{
long i_516;
i_516 = ((long)0);
loop_517:
if(_2__116___r4_numbers_6_5(BINT(i_516), BINT(len1_514))){
{
obj_t aux_1754;
obj_t aux_1752;
{
long aux_1755;
{
long aux_1762;
long aux_1756;
{
obj_t aux_1763;
{
obj_t aux_1764;
aux_1764 = STRUCT_REF(set2_33, ((long)1));
aux_1763 = VECTOR_REF(aux_1764, i_516);
}
aux_1762 = (long)CINT(aux_1763);
}
{
obj_t aux_1757;
{
obj_t aux_1758;
aux_1758 = STRUCT_REF(set1_32, ((long)1));
aux_1757 = VECTOR_REF(aux_1758, i_516);
}
aux_1756 = (long)CINT(aux_1757);
}
aux_1755 = (aux_1756 | aux_1762);
}
aux_1754 = BINT(aux_1755);
}
aux_1752 = STRUCT_REF(set1_32, ((long)1));
VECTOR_SET(aux_1752, i_516, aux_1754);
}
{
long i_1771;
i_1771 = (i_516+((long)1));
i_516 = i_1771;
goto loop_517;
}
}
 else {
return BUNSPEC;
}
}
}
}


/* _rgcset-or! */obj_t _rgcset_or__213___rgc_set(obj_t env_1421, obj_t set1_1422, obj_t set2_1423)
{
return rgcset_or__64___rgc_set(set1_1422, set2_1423);
}


/* rgcset-or */obj_t rgcset_or_160___rgc_set(obj_t set1_34, obj_t set2_35)
{
{
long len1_523;
{
obj_t aux_1774;
aux_1774 = STRUCT_REF(set1_34, ((long)1));
len1_523 = VECTOR_LENGTH(aux_1774);
}
{
obj_t new_525;
{
int size_1178;
{
obj_t aux_1777;
aux_1777 = STRUCT_REF(set1_34, ((long)0));
size_1178 = CINT(aux_1777);
}
{
obj_t arg1029_1179;
{
obj_t aux_1791;
long aux_1780;
aux_1791 = BINT(((long)0));
{
obj_t aux_1781;
{
obj_t aux_1782;
{
long aux_1784;
{
long aux_1785;
aux_1785 = (long)(size_1178);
aux_1784 = (aux_1785/bit_per_word_40___rgc_set);
}
aux_1782 = BINT(aux_1784);
}
aux_1781 = _2__168___r4_numbers_6_5(BINT(((long)1)), aux_1782);
}
aux_1780 = (long)CINT(aux_1781);
}
arg1029_1179 = make_vector(aux_1780, aux_1791);
}
{
obj_t new_1188;
new_1188 = create_struct(symbol1265___rgc_set, ((long)2));
STRUCT_SET(new_1188, ((long)1), arg1029_1179);
{
obj_t aux_1796;
aux_1796 = BINT(size_1178);
STRUCT_SET(new_1188, ((long)0), aux_1796);
}
new_525 = new_1188;
}
}
}
{
{
long i_526;
i_526 = ((long)0);
loop_527:
if(_2__116___r4_numbers_6_5(BINT(i_526), BINT(len1_523))){
{
obj_t aux_1805;
obj_t aux_1803;
{
long aux_1806;
{
long aux_1813;
long aux_1807;
{
obj_t aux_1814;
{
obj_t aux_1815;
aux_1815 = STRUCT_REF(set2_35, ((long)1));
aux_1814 = VECTOR_REF(aux_1815, i_526);
}
aux_1813 = (long)CINT(aux_1814);
}
{
obj_t aux_1808;
{
obj_t aux_1809;
aux_1809 = STRUCT_REF(set1_34, ((long)1));
aux_1808 = VECTOR_REF(aux_1809, i_526);
}
aux_1807 = (long)CINT(aux_1808);
}
aux_1806 = (aux_1807 | aux_1813);
}
aux_1805 = BINT(aux_1806);
}
aux_1803 = STRUCT_REF(new_525, ((long)1));
VECTOR_SET(aux_1803, i_526, aux_1805);
}
{
long i_1822;
i_1822 = (i_526+((long)1));
i_526 = i_1822;
goto loop_527;
}
}
 else {
return new_525;
}
}
}
}
}
}


/* _rgcset-or */obj_t _rgcset_or_0___rgc_set(obj_t env_1424, obj_t set1_1425, obj_t set2_1426)
{
return rgcset_or_160___rgc_set(set1_1425, set2_1426);
}


/* rgcset-but! */obj_t rgcset_but__159___rgc_set(obj_t set1_36, obj_t set2_37)
{
{
long len1_534;
{
obj_t aux_1825;
aux_1825 = STRUCT_REF(set1_36, ((long)1));
len1_534 = VECTOR_LENGTH(aux_1825);
}
{
long i_536;
i_536 = ((long)0);
loop_537:
if(_2__116___r4_numbers_6_5(BINT(i_536), BINT(len1_534))){
{
obj_t aux_1834;
obj_t aux_1832;
{
obj_t aux_1839;
obj_t aux_1835;
{
obj_t aux_1840;
aux_1840 = STRUCT_REF(set2_37, ((long)1));
aux_1839 = VECTOR_REF(aux_1840, i_536);
}
{
obj_t aux_1836;
aux_1836 = STRUCT_REF(set1_36, ((long)1));
aux_1835 = VECTOR_REF(aux_1836, i_536);
}
aux_1834 = _2__79___r4_numbers_6_5(aux_1835, aux_1839);
}
aux_1832 = STRUCT_REF(set1_36, ((long)1));
VECTOR_SET(aux_1832, i_536, aux_1834);
}
{
long i_1845;
i_1845 = (i_536+((long)1));
i_536 = i_1845;
goto loop_537;
}
}
 else {
return BUNSPEC;
}
}
}
}


/* _rgcset-but! */obj_t _rgcset_but__134___rgc_set(obj_t env_1427, obj_t set1_1428, obj_t set2_1429)
{
return rgcset_but__159___rgc_set(set1_1428, set2_1429);
}


/* rgcset-equal? */bool_t rgcset_equal__214___rgc_set(obj_t set1_38, obj_t set2_39)
{
return equal__25___r4_equivalence_6_2(STRUCT_REF(set1_38, ((long)1)), STRUCT_REF(set2_39, ((long)1)));
}


/* _rgcset-equal? */obj_t _rgcset_equal__209___rgc_set(obj_t env_1430, obj_t set1_1431, obj_t set2_1432)
{
{
bool_t aux_1851;
aux_1851 = rgcset_equal__214___rgc_set(set1_1431, set2_1432);
return BBOOL(aux_1851);
}
}


/* rgcset->hash */int rgcset__hash_57___rgc_set(obj_t set_40)
{
{
long len_545;
{
obj_t aux_1854;
aux_1854 = STRUCT_REF(set_40, ((long)1));
len_545 = VECTOR_LENGTH(aux_1854);
}
{
long i_1294;
obj_t res_1295;
{
obj_t aux_1857;
i_1294 = ((long)1);
{
obj_t aux_1874;
aux_1874 = STRUCT_REF(set_40, ((long)1));
res_1295 = VECTOR_REF(aux_1874, ((long)0));
}
loop_1293:
if((i_1294==len_545)){
aux_1857 = res_1295;
}
 else {
obj_t res_1862;
long i_1860;
i_1860 = (i_1294+((long)1));
{
long aux_1863;
{
long aux_1866;
long aux_1864;
{
obj_t aux_1867;
{
obj_t aux_1868;
aux_1868 = STRUCT_REF(set_40, ((long)1));
aux_1867 = VECTOR_REF(aux_1868, i_1294);
}
aux_1866 = (long)CINT(aux_1867);
}
aux_1864 = (long)CINT(res_1295);
aux_1863 = (aux_1864 ^ aux_1866);
}
res_1862 = BINT(aux_1863);
}
res_1295 = res_1862;
i_1294 = i_1860;
goto loop_1293;
}
return CINT(aux_1857);
}
}
}
}


/* _rgcset->hash */obj_t _rgcset__hash_54___rgc_set(obj_t env_1433, obj_t set_1434)
{
{
int aux_1878;
aux_1878 = rgcset__hash_57___rgc_set(set_1434);
return BINT(aux_1878);
}
}


/* rgcset-remove! */obj_t rgcset_remove__162___rgc_set(obj_t set_41, int num_42)
{
{
long word_num_101_1356;
{
long aux_1881;
aux_1881 = (long)(num_42);
word_num_101_1356 = (aux_1881/bit_per_word_40___rgc_set);
}
{
long word_bit_99_1357;
{
long aux_1884;
aux_1884 = (long)(num_42);
word_bit_99_1357 = (aux_1884%bit_per_word_40___rgc_set);
}
{
{
obj_t aux_1889;
obj_t aux_1887;
{
long aux_1890;
{
long aux_1897;
long aux_1891;
aux_1897 = (((long)1) << word_bit_99_1357);
{
obj_t aux_1892;
{
obj_t aux_1893;
aux_1893 = STRUCT_REF(set_41, ((long)1));
aux_1892 = VECTOR_REF(aux_1893, word_num_101_1356);
}
aux_1891 = (long)CINT(aux_1892);
}
aux_1890 = (aux_1891 ^ aux_1897);
}
aux_1889 = BINT(aux_1890);
}
aux_1887 = STRUCT_REF(set_41, ((long)1));
return VECTOR_SET(aux_1887, word_num_101_1356, aux_1889);
}
}
}
}
}


/* _rgcset-remove! */obj_t _rgcset_remove__52___rgc_set(obj_t env_1435, obj_t set_1436, obj_t num_1437)
{
return rgcset_remove__162___rgc_set(set_1436, CINT(num_1437));
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc_set()
{
return module_initialization_70___error(((long)0), "__RGC_SET");
}

