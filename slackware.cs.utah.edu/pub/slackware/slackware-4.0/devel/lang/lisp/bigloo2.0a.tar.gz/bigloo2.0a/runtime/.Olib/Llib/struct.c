/*===========================================================================*/
/*   (Llib/struct.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t make_struct_168___structure(obj_t, long, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t symbol1315___structure = BUNSPEC;
static obj_t symbol1314___structure = BUNSPEC;
static obj_t symbol1299___structure = BUNSPEC;
static obj_t symbol1309___structure = BUNSPEC;
static obj_t symbol1310___structure = BUNSPEC;
static obj_t symbol1298___structure = BUNSPEC;
static obj_t symbol1308___structure = BUNSPEC;
static obj_t symbol1297___structure = BUNSPEC;
static obj_t symbol1307___structure = BUNSPEC;
static obj_t symbol1306___structure = BUNSPEC;
static obj_t symbol1295___structure = BUNSPEC;
static obj_t symbol1305___structure = BUNSPEC;
static obj_t symbol1294___structure = BUNSPEC;
static obj_t symbol1304___structure = BUNSPEC;
static obj_t symbol1303___structure = BUNSPEC;
static obj_t symbol1302___structure = BUNSPEC;
static obj_t symbol1301___structure = BUNSPEC;
static obj_t symbol1289___structure = BUNSPEC;
static obj_t symbol1290___structure = BUNSPEC;
static obj_t symbol1300___structure = BUNSPEC;
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _poke_1169_107___structure(obj_t, obj_t, obj_t, obj_t);
extern bool_t struct__46___structure(obj_t);
static obj_t _struct_ref1173_158___structure(obj_t, obj_t, obj_t);
static obj_t _struct_set_1174_60___structure(obj_t, obj_t, obj_t, obj_t);
extern obj_t struct_update__184___structure(obj_t, obj_t);
static obj_t _make_struct1167_92___structure(obj_t, obj_t, obj_t, obj_t);
extern obj_t poke__136___structure(obj_t, long, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t peek___structure(obj_t, long);
static obj_t _struct_key_set_1171_36___structure(obj_t, obj_t, obj_t);
extern obj_t struct_set__199___structure(obj_t, long, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t struct_ref_25___structure(obj_t, long);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t struct_key_set__234___structure(obj_t, obj_t);
static obj_t _struct_length1172_49___structure(obj_t, obj_t);
static obj_t _peek1168___structure(obj_t, obj_t, obj_t);
static obj_t _struct_key1170_250___structure(obj_t, obj_t);
static obj_t _struct_update_1175_118___structure(obj_t, obj_t, obj_t);
extern obj_t struct_key_246___structure(obj_t);
static obj_t imported_modules_init_94___structure();
static obj_t require_initialization_114___structure = BUNSPEC;
static obj_t _struct__118___structure(obj_t, obj_t);
extern long struct_length_222___structure(obj_t);
static obj_t cnst_init_137___structure();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( struct_ref_env_47___structure, _struct_ref1173_158___structure1317, _struct_ref1173_158___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_update__env_161___structure, _struct_update_1175_118___structure1318, _struct_update_1175_118___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_set__env_206___structure, _struct_set_1174_60___structure1319, _struct_set_1174_60___structure, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( struct__env_28___structure, _struct__118___structure1320, _struct__118___structure, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( make_struct_env_132___structure, _make_struct1167_92___structure1321, _make_struct1167_92___structure, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( struct_length_env_97___structure, _struct_length1172_49___structure1322, _struct_length1172_49___structure, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( peek_env_54___structure, _peek1168___structure1323, _peek1168___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_key_set__env_144___structure, _struct_key_set_1171_36___structure1324, _struct_key_set_1171_36___structure, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( struct_key_env_50___structure, _struct_key1170_250___structure1325, _struct_key1170_250___structure, 0L, 1 );
DEFINE_STRING( string1313___structure, string1313___structure1326, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1312___structure, string1312___structure1327, "Incompatible structures", 23 );
DEFINE_STRING( string1311___structure, string1311___structure1328, "struct-update!", 14 );
DEFINE_STRING( string1296___structure, string1296___structure1329, "STRUCT", 6 );
DEFINE_STRING( string1293___structure, string1293___structure1330, "LONG", 4 );
DEFINE_STRING( string1292___structure, string1292___structure1331, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/struct.scm", 59 );
DEFINE_STRING( string1291___structure, string1291___structure1332, "SYMBOL", 6 );
DEFINE_EXPORT_PROCEDURE( poke__env_137___structure, _poke_1169_107___structure1333, _poke_1169_107___structure, 0L, 3 );


/* module-initialization */obj_t module_initialization_70___structure(long checksum_594, char * from_595)
{
if(CBOOL(require_initialization_114___structure)){
require_initialization_114___structure = BBOOL(((bool_t)0));
cnst_init_137___structure();
imported_modules_init_94___structure();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___structure()
{
symbol1289___structure = string_to_symbol("MAKE-STRUCT");
symbol1290___structure = string_to_symbol("_MAKE-STRUCT1167");
symbol1294___structure = string_to_symbol("PEEK");
symbol1295___structure = string_to_symbol("_PEEK1168");
symbol1297___structure = string_to_symbol("POKE!");
symbol1298___structure = string_to_symbol("_POKE!1169");
symbol1299___structure = string_to_symbol("STRUCT?");
symbol1300___structure = string_to_symbol("STRUCT-KEY");
symbol1301___structure = string_to_symbol("_STRUCT-KEY1170");
symbol1302___structure = string_to_symbol("STRUCT-KEY-SET!");
symbol1303___structure = string_to_symbol("_STRUCT-KEY-SET!1171");
symbol1304___structure = string_to_symbol("STRUCT-LENGTH");
symbol1305___structure = string_to_symbol("_STRUCT-LENGTH1172");
symbol1306___structure = string_to_symbol("STRUCT-REF");
symbol1307___structure = string_to_symbol("_STRUCT-REF1173");
symbol1308___structure = string_to_symbol("STRUCT-SET!");
symbol1309___structure = string_to_symbol("_STRUCT-SET!1174");
symbol1310___structure = string_to_symbol("STRUCT-UPDATE!");
symbol1314___structure = string_to_symbol("_STRUCT-UPDATE!1175");
return (symbol1315___structure = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* make-struct */obj_t make_struct_168___structure(obj_t key_1, long len_2, obj_t init_3)
{
{
obj_t symbol1146_540;
symbol1146_540 = symbol1289___structure;
{
PUSH_TRACE(symbol1146_540);
BUNSPEC;
{
obj_t aux1145_541;
aux1145_541 = make_struct(key_1, len_2, init_3);
POP_TRACE();
return aux1145_541;
}
}
}
}


/* _make-struct1167 */obj_t _make_struct1167_92___structure(obj_t env_414, obj_t key_415, obj_t len_416, obj_t init_417)
{
{
obj_t key_542;
long len_543;
obj_t init_544;
if(SYMBOLP(key_415)){
key_542 = key_415;
}
 else {
bigloo_type_error_location_103___error(symbol1290___structure, string1291___structure, key_415, string1292___structure, BINT(((long)3919)));
exit( -1 );}
{
obj_t aux_629;
if(INTEGERP(len_416)){
aux_629 = len_416;
}
 else {
bigloo_type_error_location_103___error(symbol1290___structure, string1293___structure, len_416, string1292___structure, BINT(((long)3919)));
exit( -1 );}
len_543 = (long)CINT(aux_629);
}
init_544 = init_417;
{
obj_t symbol1146_545;
symbol1146_545 = symbol1289___structure;
{
PUSH_TRACE(symbol1146_545);
BUNSPEC;
{
obj_t aux1145_546;
aux1145_546 = make_struct(key_542, len_543, init_544);
POP_TRACE();
return aux1145_546;
}
}
}
}
}


/* peek */obj_t peek___structure(obj_t struct_4, long offset_5)
{
{
obj_t symbol1148_547;
symbol1148_547 = symbol1294___structure;
{
PUSH_TRACE(symbol1148_547);
BUNSPEC;
{
obj_t aux1147_548;
aux1147_548 = PEEK(struct_4, offset_5);
POP_TRACE();
return aux1147_548;
}
}
}
}


/* _peek1168 */obj_t _peek1168___structure(obj_t env_418, obj_t struct_419, obj_t offset_420)
{
{
obj_t struct_116_549;
long offset_550;
if(STRUCTP(struct_419)){
struct_116_549 = struct_419;
}
 else {
bigloo_type_error_location_103___error(symbol1295___structure, string1296___structure, struct_419, string1292___structure, BINT(((long)4217)));
exit( -1 );}
{
obj_t aux_647;
if(INTEGERP(offset_420)){
aux_647 = offset_420;
}
 else {
bigloo_type_error_location_103___error(symbol1295___structure, string1293___structure, offset_420, string1292___structure, BINT(((long)4217)));
exit( -1 );}
offset_550 = (long)CINT(aux_647);
}
{
obj_t symbol1148_551;
symbol1148_551 = symbol1294___structure;
{
PUSH_TRACE(symbol1148_551);
BUNSPEC;
{
obj_t aux1147_552;
aux1147_552 = PEEK(struct_116_549, offset_550);
POP_TRACE();
return aux1147_552;
}
}
}
}
}


/* poke! */obj_t poke__136___structure(obj_t struct_6, long offset_7, obj_t value_8)
{
{
obj_t symbol1150_553;
symbol1150_553 = symbol1297___structure;
{
PUSH_TRACE(symbol1150_553);
BUNSPEC;
{
obj_t aux1149_554;
aux1149_554 = POKE(struct_6, offset_7, value_8);
POP_TRACE();
return aux1149_554;
}
}
}
}


/* _poke!1169 */obj_t _poke_1169_107___structure(obj_t env_421, obj_t struct_422, obj_t offset_423, obj_t value_424)
{
{
obj_t struct_116_555;
long offset_556;
obj_t value_557;
if(STRUCTP(struct_422)){
struct_116_555 = struct_422;
}
 else {
bigloo_type_error_location_103___error(symbol1298___structure, string1296___structure, struct_422, string1292___structure, BINT(((long)4503)));
exit( -1 );}
{
obj_t aux_665;
if(INTEGERP(offset_423)){
aux_665 = offset_423;
}
 else {
bigloo_type_error_location_103___error(symbol1298___structure, string1293___structure, offset_423, string1292___structure, BINT(((long)4503)));
exit( -1 );}
offset_556 = (long)CINT(aux_665);
}
value_557 = value_424;
{
obj_t symbol1150_558;
symbol1150_558 = symbol1297___structure;
{
PUSH_TRACE(symbol1150_558);
BUNSPEC;
{
obj_t aux1149_559;
aux1149_559 = POKE(struct_116_555, offset_556, value_557);
POP_TRACE();
return aux1149_559;
}
}
}
}
}


/* struct? */bool_t struct__46___structure(obj_t o_9)
{
{
obj_t symbol1152_560;
symbol1152_560 = symbol1299___structure;
{
PUSH_TRACE(symbol1152_560);
BUNSPEC;
{
bool_t aux1151_561;
aux1151_561 = STRUCTP(o_9);
POP_TRACE();
return aux1151_561;
}
}
}
}


/* _struct? */obj_t _struct__118___structure(obj_t env_425, obj_t o_426)
{
{
bool_t aux_678;
{
obj_t o_562;
o_562 = o_426;
{
obj_t symbol1152_563;
symbol1152_563 = symbol1299___structure;
{
PUSH_TRACE(symbol1152_563);
BUNSPEC;
{
bool_t aux1151_564;
aux1151_564 = STRUCTP(o_562);
POP_TRACE();
aux_678 = aux1151_564;
}
}
}
}
return BBOOL(aux_678);
}
}


/* struct-key */obj_t struct_key_246___structure(obj_t s_10)
{
{
obj_t symbol1154_565;
symbol1154_565 = symbol1300___structure;
{
PUSH_TRACE(symbol1154_565);
BUNSPEC;
{
obj_t aux1153_566;
aux1153_566 = STRUCT_KEY(s_10);
POP_TRACE();
return aux1153_566;
}
}
}
}


/* _struct-key1170 */obj_t _struct_key1170_250___structure(obj_t env_427, obj_t s_428)
{
{
obj_t s_567;
if(STRUCTP(s_428)){
s_567 = s_428;
}
 else {
bigloo_type_error_location_103___error(symbol1301___structure, string1296___structure, s_428, string1292___structure, BINT(((long)5071)));
exit( -1 );}
{
obj_t symbol1154_568;
symbol1154_568 = symbol1300___structure;
{
PUSH_TRACE(symbol1154_568);
BUNSPEC;
{
obj_t aux1153_569;
aux1153_569 = STRUCT_KEY(s_567);
POP_TRACE();
return aux1153_569;
}
}
}
}
}


/* struct-key-set! */obj_t struct_key_set__234___structure(obj_t s_11, obj_t k_12)
{
{
obj_t symbol1156_570;
symbol1156_570 = symbol1302___structure;
{
PUSH_TRACE(symbol1156_570);
BUNSPEC;
{
obj_t aux1155_571;
aux1155_571 = STRUCT_KEY_SET(s_11, k_12);
POP_TRACE();
return aux1155_571;
}
}
}
}


/* _struct-key-set!1171 */obj_t _struct_key_set_1171_36___structure(obj_t env_429, obj_t s_430, obj_t k_431)
{
{
obj_t s_572;
obj_t k_573;
if(STRUCTP(s_430)){
s_572 = s_430;
}
 else {
bigloo_type_error_location_103___error(symbol1303___structure, string1296___structure, s_430, string1292___structure, BINT(((long)5345)));
exit( -1 );}
if(SYMBOLP(k_431)){
k_573 = k_431;
}
 else {
bigloo_type_error_location_103___error(symbol1303___structure, string1291___structure, k_431, string1292___structure, BINT(((long)5345)));
exit( -1 );}
{
obj_t symbol1156_574;
symbol1156_574 = symbol1302___structure;
{
PUSH_TRACE(symbol1156_574);
BUNSPEC;
{
obj_t aux1155_575;
aux1155_575 = STRUCT_KEY_SET(s_572, k_573);
POP_TRACE();
return aux1155_575;
}
}
}
}
}


/* struct-length */long struct_length_222___structure(obj_t s_13)
{
{
obj_t symbol1158_576;
symbol1158_576 = symbol1304___structure;
{
PUSH_TRACE(symbol1158_576);
BUNSPEC;
{
long aux1157_577;
aux1157_577 = STRUCT_LENGTH(s_13);
POP_TRACE();
return aux1157_577;
}
}
}
}


/* _struct-length1172 */obj_t _struct_length1172_49___structure(obj_t env_432, obj_t s_433)
{
{
long aux_713;
{
obj_t s_578;
if(STRUCTP(s_433)){
s_578 = s_433;
}
 else {
bigloo_type_error_location_103___error(symbol1305___structure, string1296___structure, s_433, string1292___structure, BINT(((long)5633)));
exit( -1 );}
{
obj_t symbol1158_579;
symbol1158_579 = symbol1304___structure;
{
PUSH_TRACE(symbol1158_579);
BUNSPEC;
{
long aux1157_580;
aux1157_580 = STRUCT_LENGTH(s_578);
POP_TRACE();
aux_713 = aux1157_580;
}
}
}
}
return BINT(aux_713);
}
}


/* struct-ref */obj_t struct_ref_25___structure(obj_t s_14, long k_15)
{
{
obj_t symbol1160_581;
symbol1160_581 = symbol1306___structure;
{
PUSH_TRACE(symbol1160_581);
BUNSPEC;
{
obj_t aux1159_582;
aux1159_582 = STRUCT_REF(s_14, k_15);
POP_TRACE();
return aux1159_582;
}
}
}
}


/* _struct-ref1173 */obj_t _struct_ref1173_158___structure(obj_t env_434, obj_t s_435, obj_t k_436)
{
{
obj_t s_583;
long k_584;
if(STRUCTP(s_435)){
s_583 = s_435;
}
 else {
bigloo_type_error_location_103___error(symbol1307___structure, string1296___structure, s_435, string1292___structure, BINT(((long)5917)));
exit( -1 );}
{
obj_t aux_731;
if(INTEGERP(k_436)){
aux_731 = k_436;
}
 else {
bigloo_type_error_location_103___error(symbol1307___structure, string1293___structure, k_436, string1292___structure, BINT(((long)5917)));
exit( -1 );}
k_584 = (long)CINT(aux_731);
}
{
obj_t symbol1160_585;
symbol1160_585 = symbol1306___structure;
{
PUSH_TRACE(symbol1160_585);
BUNSPEC;
{
obj_t aux1159_586;
aux1159_586 = STRUCT_REF(s_583, k_584);
POP_TRACE();
return aux1159_586;
}
}
}
}
}


/* struct-set! */obj_t struct_set__199___structure(obj_t s_16, long k_17, obj_t o_18)
{
{
obj_t symbol1162_587;
symbol1162_587 = symbol1308___structure;
{
PUSH_TRACE(symbol1162_587);
BUNSPEC;
{
obj_t aux1161_588;
aux1161_588 = STRUCT_SET(s_16, k_17, o_18);
POP_TRACE();
return aux1161_588;
}
}
}
}


/* _struct-set!1174 */obj_t _struct_set_1174_60___structure(obj_t env_437, obj_t s_438, obj_t k_439, obj_t o_440)
{
{
obj_t s_589;
long k_590;
obj_t o_591;
if(STRUCTP(s_438)){
s_589 = s_438;
}
 else {
bigloo_type_error_location_103___error(symbol1309___structure, string1296___structure, s_438, string1292___structure, BINT(((long)6196)));
exit( -1 );}
{
obj_t aux_749;
if(INTEGERP(k_439)){
aux_749 = k_439;
}
 else {
bigloo_type_error_location_103___error(symbol1309___structure, string1293___structure, k_439, string1292___structure, BINT(((long)6196)));
exit( -1 );}
k_590 = (long)CINT(aux_749);
}
o_591 = o_440;
{
obj_t symbol1162_592;
symbol1162_592 = symbol1308___structure;
{
PUSH_TRACE(symbol1162_592);
BUNSPEC;
{
obj_t aux1161_593;
aux1161_593 = STRUCT_SET(s_589, k_590, o_591);
POP_TRACE();
return aux1161_593;
}
}
}
}
}


/* struct-update! */obj_t struct_update__184___structure(obj_t dst_19, obj_t src_20)
{
{
obj_t symbol1164_410;
symbol1164_410 = symbol1310___structure;
{
PUSH_TRACE(symbol1164_410);
BUNSPEC;
{
obj_t aux1163_411;
{
bool_t test_760;
{
bool_t test_761;
{
obj_t aux_764;
obj_t aux_762;
aux_764 = STRUCT_KEY(src_20);
aux_762 = STRUCT_KEY(dst_19);
test_761 = (aux_762==aux_764);
}
if(test_761){
long aux_769;
long aux_767;
aux_769 = STRUCT_LENGTH(src_20);
aux_767 = STRUCT_LENGTH(dst_19);
test_760 = (aux_767==aux_769);
}
 else {
test_760 = ((bool_t)0);
}
}
if(test_760){
long i_231;
{
long aux_779;
aux_779 = STRUCT_LENGTH(dst_19);
i_231 = (aux_779-((long)1));
}
loop_232:
if((i_231==((long)-1))){
aux1163_411 = dst_19;
}
 else {
{
obj_t aux_774;
aux_774 = STRUCT_REF(src_20, i_231);
STRUCT_SET(dst_19, i_231, aux_774);
}
{
long i_777;
i_777 = (i_231-((long)1));
i_231 = i_777;
goto loop_232;
}
}
}
 else {
obj_t arg1014_241;
{
obj_t list1015_242;
{
obj_t arg1016_243;
arg1016_243 = MAKE_PAIR(src_20, BNIL);
list1015_242 = MAKE_PAIR(dst_19, arg1016_243);
}
arg1014_241 = list1015_242;
}
aux1163_411 = debug_error_location_199___error(string1311___structure, string1312___structure, arg1014_241, string1313___structure, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1163_411;
}
}
}
}


/* _struct-update!1175 */obj_t _struct_update_1175_118___structure(obj_t env_441, obj_t dst_442, obj_t src_443)
{
{
obj_t aux_793;
obj_t aux_787;
if(STRUCTP(src_443)){
aux_793 = src_443;
}
 else {
bigloo_type_error_location_103___error(symbol1314___structure, string1296___structure, src_443, string1292___structure, BINT(((long)6481)));
exit( -1 );}
if(STRUCTP(dst_442)){
aux_787 = dst_442;
}
 else {
bigloo_type_error_location_103___error(symbol1314___structure, string1296___structure, dst_442, string1292___structure, BINT(((long)6481)));
exit( -1 );}
return struct_update__184___structure(aux_787, aux_793);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___structure()
{
{
obj_t symbol1166_412;
symbol1166_412 = symbol1315___structure;
{
PUSH_TRACE(symbol1166_412);
BUNSPEC;
{
obj_t aux1165_413;
aux1165_413 = module_initialization_70___error(((long)0), "__STRUCTURE");
POP_TRACE();
return aux1165_413;
}
}
}
}

