/*===========================================================================*/
/*   (Cfa/funcall.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_funcall();
extern obj_t user_warning_location_190_tools_error(obj_t, obj_t, obj_t, obj_t);
extern bool_t sound_arity__135_tools_args(obj_t, obj_t);
extern obj_t funcall_cinfo_75_cfa_info;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern approx_t make_empty_approx_131_cfa_approx();
static approx_t funcall_arity_error_199_cfa_funcall(obj_t, variable_t, long, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_cfa_funcall(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_app(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t funcall_type_error_218_cfa_funcall(funcall_cinfo_75_t, type_t);
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
static approx_t funcall__128_cfa_funcall(make_procedure_app_48_t, obj_t, obj_t);
extern long list_length(obj_t);
extern long class_num_218___object(obj_t);
static obj_t imported_modules_init_94_cfa_funcall();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t cfa__funcall_cinfo_215_cfa_funcall(obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
static obj_t library_modules_init_112_cfa_funcall();
extern approx_t cfa__102_cfa_cfa(node_t);
static obj_t arg2439_cfa_funcall(obj_t, obj_t);
static obj_t arg2432_cfa_funcall(obj_t, obj_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t toplevel_init_63_cfa_funcall();
extern obj_t open_input_string(obj_t);
extern approx_t app__231_cfa_app(fun_t, var_t, obj_t);
static obj_t _cfa_2464_2_cfa_cfa(obj_t, obj_t);
extern obj_t approx_set_type__239_cfa_approx(approx_t, type_t);
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t local_ast_var;
extern obj_t make_procedure_app_48_cfa_info;
extern obj_t shape_tools_shape(obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t read___reader(obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cfa_funcall = BUNSPEC;
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
static obj_t cnst_init_137_cfa_funcall();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[1];

DEFINE_STATIC_PROCEDURE(proc2470_cfa_funcall, cfa__funcall_cinfo_215_cfa_funcall2477, cfa__funcall_cinfo_215_cfa_funcall, 0L, 1);
extern obj_t cfa__env_153_cfa_cfa;
DEFINE_STRING(string2471_cfa_funcall, string2471_cfa_funcall2478, "ALL ", 4);
DEFINE_STRING(string2469_cfa_funcall, string2469_cfa_funcall2479, "Possible funcall arity error", 28);
DEFINE_STRING(string2468_cfa_funcall, string2468_cfa_funcall2480, " arg(s) expected, ", 18);
DEFINE_STRING(string2467_cfa_funcall, string2467_cfa_funcall2481, " provided", 9);
DEFINE_STRING(string2466_cfa_funcall, string2466_cfa_funcall2482, "Possible funcall type error", 27);
DEFINE_STRING(string2465_cfa_funcall, string2465_cfa_funcall2483, "cfa", 3);


/* module-initialization */ obj_t 
module_initialization_70_cfa_funcall(long checksum_3547, char *from_3548)
{
   if (CBOOL(require_initialization_114_cfa_funcall))
     {
	require_initialization_114_cfa_funcall = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_funcall();
	cnst_init_137_cfa_funcall();
	imported_modules_init_94_cfa_funcall();
	method_init_76_cfa_funcall();
	toplevel_init_63_cfa_funcall();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_funcall()
{
   module_initialization_70___object(((long) 0), "CFA_FUNCALL");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_FUNCALL");
   module_initialization_70___r4_strings_6_7(((long) 0), "CFA_FUNCALL");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "CFA_FUNCALL");
   module_initialization_70___reader(((long) 0), "CFA_FUNCALL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_funcall()
{
   {
      obj_t cnst_port_138_3539;
      cnst_port_138_3539 = open_input_string(string2471_cfa_funcall);
      {
	 long i_3540;
	 i_3540 = ((long) 0);
       loop_3541:
	 {
	    bool_t test2472_3542;
	    test2472_3542 = (i_3540 == ((long) -1));
	    if (test2472_3542)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2473_3543;
		    {
		       obj_t list2474_3544;
		       {
			  obj_t arg2475_3545;
			  arg2475_3545 = BNIL;
			  list2474_3544 = MAKE_PAIR(cnst_port_138_3539, arg2475_3545);
		       }
		       arg2473_3543 = read___reader(list2474_3544);
		    }
		    CNST_TABLE_SET(i_3540, arg2473_3543);
		 }
		 {
		    int aux_3546;
		    {
		       long aux_3568;
		       aux_3568 = (i_3540 - ((long) 1));
		       aux_3546 = (int) (aux_3568);
		    }
		    {
		       long i_3571;
		       i_3571 = (long) (aux_3546);
		       i_3540 = i_3571;
		       goto loop_3541;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_funcall()
{
   return BUNSPEC;
}


/* funcall! */ approx_t 
funcall__128_cfa_funcall(make_procedure_app_48_t alloc_2, obj_t args_approx_137_3, obj_t node_4)
{
   {
      obj_t callee_2107;
      {
	 obj_t aux_3573;
	 {
	    app_t obj_3009;
	    obj_3009 = (app_t) (alloc_2);
	    aux_3573 = (((app_t) CREF(obj_3009))->args);
	 }
	 callee_2107 = CAR(aux_3573);
      }
      {
	 variable_t v_2108;
	 {
	    var_t obj_3011;
	    obj_3011 = (var_t) (callee_2107);
	    v_2108 = (((var_t) CREF(obj_3011))->variable);
	 }
	 {
	    value_t fun_2109;
	    fun_2109 = (((variable_t) CREF(v_2108))->value);
	    {
	       long arity_2110;
	       {
		  fun_t obj_3013;
		  obj_3013 = (fun_t) (fun_2109);
		  arity_2110 = (((fun_t) CREF(obj_3013))->arity);
	       }
	       {
		  {
		     bool_t test2094_2111;
		     test2094_2111 = sound_arity__135_tools_args(BINT(arity_2110), args_approx_137_3);
		     if (test2094_2111)
		       {
			  if ((arity_2110 >= ((long) 0)))
			    {
			       return app__231_cfa_app((fun_t) (fun_2109), (var_t) (callee_2107), args_approx_137_3);
			    }
			  else
			    {
			       {
				  obj_t old_args_approx_165_2113;
				  obj_t new_args_approx_79_2114;
				  long arity_2115;
				  old_args_approx_165_2113 = args_approx_137_3;
				  new_args_approx_79_2114 = BNIL;
				  arity_2115 = arity_2110;
				loop_2116:
				  if ((arity_2115 == ((long) -1)))
				    {
				       {
					  obj_t l2085_2119;
					  l2085_2119 = old_args_approx_165_2113;
					lname2086_2120:
					  if (PAIRP(l2085_2119))
					    {
					       {
						  approx_t aux_3594;
						  {
						     obj_t aux_3595;
						     aux_3595 = CAR(l2085_2119);
						     aux_3594 = (approx_t) (aux_3595);
						  }
						  loose__226_cfa_loose(aux_3594, CNST_TABLE_REF(((long) 0)));
					       }
					       {
						  obj_t l2085_3600;
						  l2085_3600 = CDR(l2085_2119);
						  l2085_2119 = l2085_3600;
						  goto lname2086_2120;
					       }
					    }
					  else
					    {
					       ((bool_t) 1);
					    }
				       }
				       {
					  obj_t arg2101_2125;
					  {
					     obj_t arg2102_2126;
					     {
						obj_t aux_3602;
						{
						   approx_t aux_3603;
						   {
						      funcall_cinfo_75_t obj_3021;
						      obj_3021 = (funcall_cinfo_75_t) (node_4);
						      {
							 obj_t aux_3605;
							 {
							    object_t aux_3606;
							    aux_3606 = (object_t) (obj_3021);
							    aux_3605 = OBJECT_WIDENING(aux_3606);
							 }
							 aux_3603 = (((funcall_cinfo_75_t) CREF(aux_3605))->va_approx_63);
						      }
						   }
						   aux_3602 = (obj_t) (aux_3603);
						}
						arg2102_2126 = MAKE_PAIR(aux_3602, new_args_approx_79_2114);
					     }
					     arg2101_2125 = reverse__39___r4_pairs_and_lists_6_3(arg2102_2126);
					  }
					  return app__231_cfa_app((fun_t) (fun_2109), (var_t) (callee_2107), arg2101_2125);
				       }
				    }
				  else
				    {
				       obj_t arg2105_2128;
				       obj_t arg2106_2129;
				       long arg2107_2130;
				       arg2105_2128 = CDR(old_args_approx_165_2113);
				       {
					  obj_t aux_3617;
					  aux_3617 = CAR(old_args_approx_165_2113);
					  arg2106_2129 = MAKE_PAIR(aux_3617, new_args_approx_79_2114);
				       }
				       arg2107_2130 = (arity_2115 + ((long) 1));
				       {
					  long arity_3623;
					  obj_t new_args_approx_79_3622;
					  obj_t old_args_approx_165_3621;
					  old_args_approx_165_3621 = arg2105_2128;
					  new_args_approx_79_3622 = arg2106_2129;
					  arity_3623 = arg2107_2130;
					  arity_2115 = arity_3623;
					  new_args_approx_79_2114 = new_args_approx_79_3622;
					  old_args_approx_165_2113 = old_args_approx_165_3621;
					  goto loop_2116;
				       }
				    }
			       }
			    }
		       }
		     else
		       {
			  return funcall_arity_error_199_cfa_funcall(node_4, v_2108, arity_2110, args_approx_137_3);
		       }
		  }
	       }
	    }
	 }
      }
   }
}


/* funcall-type-error */ obj_t 
funcall_type_error_218_cfa_funcall(funcall_cinfo_75_t node_5, type_t type_6)
{
   {
      bool_t test_3625;
      {
	 obj_t aux_3626;
	 {
	    object_t aux_3627;
	    aux_3627 = (object_t) (node_5);
	    aux_3626 = OBJECT_WIDENING(aux_3627);
	 }
	 test_3625 = (((funcall_cinfo_75_t) CREF(aux_3626))->type_error_noticed__36);
      }
      if (test_3625)
	{
	   return BUNSPEC;
	}
      else
	{
	   {
	      obj_t aux_3631;
	      {
		 object_t aux_3632;
		 aux_3632 = (object_t) (node_5);
		 aux_3631 = OBJECT_WIDENING(aux_3632);
	      }
	      ((((funcall_cinfo_75_t) CREF(aux_3631))->type_error_noticed__36) = ((bool_t) ((bool_t) 1)), BUNSPEC);
	   }
	   {
	      obj_t arg2111_2135;
	      obj_t arg2114_2138;
	      {
		 funcall_t obj_3033;
		 obj_3033 = (funcall_t) (node_5);
		 arg2111_2135 = (((funcall_t) CREF(obj_3033))->loc);
	      }
	      arg2114_2138 = shape_tools_shape((obj_t) (type_6));
	      return user_warning_location_190_tools_error(arg2111_2135, string2465_cfa_funcall, string2466_cfa_funcall, arg2114_2138);
	   }
	}
   }
}


/* funcall-arity-error */ approx_t 
funcall_arity_error_199_cfa_funcall(obj_t node_7, variable_t v_8, long arity_9, obj_t args_approx_137_10)
{
   {
      bool_t test_3641;
      {
	 funcall_cinfo_75_t obj_3034;
	 obj_3034 = (funcall_cinfo_75_t) (node_7);
	 {
	    obj_t aux_3643;
	    {
	       object_t aux_3644;
	       aux_3644 = (object_t) (obj_3034);
	       aux_3643 = OBJECT_WIDENING(aux_3644);
	    }
	    test_3641 = (((funcall_cinfo_75_t) CREF(aux_3643))->arity_error_noticed__118);
	 }
      }
      if (test_3641)
	{
	   BUNSPEC;
	}
      else
	{
	   long len_prov_87_2141;
	   {
	      long aux_3648;
	      aux_3648 = list_length(args_approx_137_10);
	      len_prov_87_2141 = (aux_3648 - ((long) 1));
	   }
	   {
	      funcall_cinfo_75_t obj_3037;
	      obj_3037 = (funcall_cinfo_75_t) (node_7);
	      {
		 obj_t aux_3652;
		 {
		    object_t aux_3653;
		    aux_3653 = (object_t) (obj_3037);
		    aux_3652 = OBJECT_WIDENING(aux_3653);
		 }
		 ((((funcall_cinfo_75_t) CREF(aux_3652))->arity_error_noticed__118) = ((bool_t) ((bool_t) 1)), BUNSPEC);
	      }
	   }
	   {
	      obj_t arg2116_2142;
	      obj_t arg2117_2143;
	      obj_t arg2121_2145;
	      {
		 funcall_t obj_3039;
		 obj_3039 = (funcall_t) (node_7);
		 arg2116_2142 = (((funcall_t) CREF(obj_3039))->loc);
	      }
	      {
		 obj_t arg2122_2146;
		 {
		    bool_t test2123_2147;
		    test2123_2147 = is_a__118___object((obj_t) (v_8), local_ast_var);
		    if (test2123_2147)
		      {
			 {
			    local_t duplicated2089_2148;
			    duplicated2089_2148 = (local_t) (v_8);
			    {
			       local_t new2090_2149;
			       {
				  obj_t arg2124_2150;
				  obj_t arg2125_2151;
				  type_t arg2127_2152;
				  value_t arg2129_2153;
				  obj_t arg2131_2154;
				  obj_t arg2132_2155;
				  obj_t arg2133_2156;
				  long arg2134_2157;
				  bool_t arg2135_2158;
				  long arg2136_2159;
				  arg2124_2150 = (((local_t) CREF(duplicated2089_2148))->id);
				  arg2125_2151 = (((local_t) CREF(duplicated2089_2148))->name);
				  arg2127_2152 = (((local_t) CREF(duplicated2089_2148))->type);
				  arg2129_2153 = (((local_t) CREF(duplicated2089_2148))->value);
				  arg2131_2154 = (((local_t) CREF(duplicated2089_2148))->access);
				  arg2132_2155 = (((local_t) CREF(duplicated2089_2148))->fast_alpha_7);
				  arg2133_2156 = (((local_t) CREF(duplicated2089_2148))->removable);
				  arg2134_2157 = (((local_t) CREF(duplicated2089_2148))->occurrence);
				  arg2135_2158 = (((local_t) CREF(duplicated2089_2148))->user__32);
				  arg2136_2159 = (((local_t) CREF(duplicated2089_2148))->key);
				  {
				     local_t res2461_3075;
				     {
					local_t new1128_3061;
					new1128_3061 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
					{
					   long arg2411_3062;
					   arg2411_3062 = class_num_218___object(local_ast_var);
					   {
					      obj_t obj_3073;
					      obj_3073 = (obj_t) (new1128_3061);
					      (((obj_t) CREF(obj_3073))->header = MAKE_HEADER(arg2411_3062, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3677;
					   aux_3677 = (object_t) (new1128_3061);
					   OBJECT_WIDENING_SET(aux_3677, BFALSE);
					}
					((((local_t) CREF(new1128_3061))->id) = ((obj_t) arg2124_2150), BUNSPEC);
					((((local_t) CREF(new1128_3061))->name) = ((obj_t) arg2125_2151), BUNSPEC);
					((((local_t) CREF(new1128_3061))->type) = ((type_t) arg2127_2152), BUNSPEC);
					((((local_t) CREF(new1128_3061))->value) = ((value_t) arg2129_2153), BUNSPEC);
					((((local_t) CREF(new1128_3061))->access) = ((obj_t) arg2131_2154), BUNSPEC);
					((((local_t) CREF(new1128_3061))->fast_alpha_7) = ((obj_t) arg2132_2155), BUNSPEC);
					((((local_t) CREF(new1128_3061))->removable) = ((obj_t) arg2133_2156), BUNSPEC);
					((((local_t) CREF(new1128_3061))->occurrence) = ((long) arg2134_2157), BUNSPEC);
					((((local_t) CREF(new1128_3061))->user__32) = ((bool_t) arg2135_2158), BUNSPEC);
					((((local_t) CREF(new1128_3061))->key) = ((long) arg2136_2159), BUNSPEC);
					res2461_3075 = new1128_3061;
				     }
				     new2090_2149 = res2461_3075;
				  }
			       }
			       {
				  arg2122_2146 = (obj_t) (new2090_2149);
			       }
			    }
			 }
		      }
		    else
		      {
			 bool_t test2137_2160;
			 test2137_2160 = is_a__118___object((obj_t) (v_8), global_ast_var);
			 if (test2137_2160)
			   {
			      {
				 global_t duplicated2091_2161;
				 duplicated2091_2161 = (global_t) (v_8);
				 {
				    global_t new2092_2162;
				    {
				       obj_t arg2138_2163;
				       obj_t arg2139_2164;
				       type_t arg2140_2165;
				       value_t arg2141_2166;
				       obj_t arg2143_2167;
				       obj_t arg2144_2168;
				       obj_t arg2145_2169;
				       long arg2146_2170;
				       obj_t arg2147_2171;
				       obj_t arg2148_2172;
				       bool_t arg2149_2173;
				       bool_t arg2150_2174;
				       bool_t arg2151_2175;
				       obj_t arg2152_2176;
				       obj_t arg2153_2177;
				       arg2138_2163 = (((global_t) CREF(duplicated2091_2161))->id);
				       arg2139_2164 = (((global_t) CREF(duplicated2091_2161))->name);
				       arg2140_2165 = (((global_t) CREF(duplicated2091_2161))->type);
				       arg2141_2166 = (((global_t) CREF(duplicated2091_2161))->value);
				       arg2143_2167 = (((global_t) CREF(duplicated2091_2161))->access);
				       arg2144_2168 = (((global_t) CREF(duplicated2091_2161))->fast_alpha_7);
				       arg2145_2169 = (((global_t) CREF(duplicated2091_2161))->removable);
				       arg2146_2170 = (((global_t) CREF(duplicated2091_2161))->occurrence);
				       arg2147_2171 = (((global_t) CREF(duplicated2091_2161))->module);
				       arg2148_2172 = (((global_t) CREF(duplicated2091_2161))->import);
				       arg2149_2173 = (((global_t) CREF(duplicated2091_2161))->evaluable__248);
				       arg2150_2174 = (((global_t) CREF(duplicated2091_2161))->library__255);
				       arg2151_2175 = (((global_t) CREF(duplicated2091_2161))->user__32);
				       arg2152_2176 = (((global_t) CREF(duplicated2091_2161))->pragma);
				       arg2153_2177 = (((global_t) CREF(duplicated2091_2161))->src);
				       {
					  global_t res2462_3126;
					  {
					     global_t new1098_3107;
					     new1098_3107 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
					     {
						long arg2413_3108;
						arg2413_3108 = class_num_218___object(global_ast_var);
						{
						   obj_t obj_3124;
						   obj_3124 = (obj_t) (new1098_3107);
						   (((obj_t) CREF(obj_3124))->header = MAKE_HEADER(arg2413_3108, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_3714;
						aux_3714 = (object_t) (new1098_3107);
						OBJECT_WIDENING_SET(aux_3714, BFALSE);
					     }
					     ((((global_t) CREF(new1098_3107))->id) = ((obj_t) arg2138_2163), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->name) = ((obj_t) arg2139_2164), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->type) = ((type_t) arg2140_2165), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->value) = ((value_t) arg2141_2166), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->access) = ((obj_t) arg2143_2167), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->fast_alpha_7) = ((obj_t) arg2144_2168), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->removable) = ((obj_t) arg2145_2169), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->occurrence) = ((long) arg2146_2170), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->module) = ((obj_t) arg2147_2171), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->import) = ((obj_t) arg2148_2172), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->evaluable__248) = ((bool_t) arg2149_2173), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->library__255) = ((bool_t) arg2150_2174), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->user__32) = ((bool_t) arg2151_2175), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->pragma) = ((obj_t) arg2152_2176), BUNSPEC);
					     ((((global_t) CREF(new1098_3107))->src) = ((obj_t) arg2153_2177), BUNSPEC);
					     res2462_3126 = new1098_3107;
					  }
					  new2092_2162 = res2462_3126;
				       }
				    }
				    {
				       arg2122_2146 = (obj_t) (new2092_2162);
				    }
				 }
			      }
			   }
			 else
			   {
			      arg2122_2146 = (obj_t) (v_8);
			   }
		      }
		 }
		 arg2117_2143 = shape_tools_shape(arg2122_2146);
	      }
	      {
		 char *arg2154_2178;
		 char *arg2156_2180;
		 arg2154_2178 = integer__string_135___r4_numbers_6_5_fixnum((arity_9 - ((long) 1)), BNIL);
		 arg2156_2180 = integer__string_135___r4_numbers_6_5_fixnum(len_prov_87_2141, BNIL);
		 {
		    obj_t list2158_2182;
		    {
		       obj_t arg2159_2183;
		       {
			  obj_t arg2160_2184;
			  {
			     obj_t arg2161_2185;
			     arg2161_2185 = MAKE_PAIR(string2467_cfa_funcall, BNIL);
			     {
				obj_t aux_3739;
				aux_3739 = string_to_bstring(arg2156_2180);
				arg2160_2184 = MAKE_PAIR(aux_3739, arg2161_2185);
			     }
			  }
			  arg2159_2183 = MAKE_PAIR(string2468_cfa_funcall, arg2160_2184);
		       }
		       {
			  obj_t aux_3743;
			  aux_3743 = string_to_bstring(arg2154_2178);
			  list2158_2182 = MAKE_PAIR(aux_3743, arg2159_2183);
		       }
		    }
		    arg2121_2145 = string_append_106___r4_strings_6_7(list2158_2182);
		 }
	      }
	      user_warning_location_190_tools_error(arg2116_2142, arg2117_2143, string2469_cfa_funcall, arg2121_2145);
	   }
	}
   }
   return make_empty_approx_131_cfa_approx();
}


/* method-init */ obj_t 
method_init_76_cfa_funcall()
{
   {
      obj_t cfa__funcall_cinfo_215_3524;
      cfa__funcall_cinfo_215_3524 = proc2470_cfa_funcall;
      return add_method__1___object(cfa__env_153_cfa_cfa, funcall_cinfo_75_cfa_info, cfa__funcall_cinfo_215_3524);
   }
}


/* cfa!-funcall/cinfo */ obj_t 
cfa__funcall_cinfo_215_cfa_funcall(obj_t env_3525, obj_t node_3526)
{
   {
      funcall_cinfo_75_t node_2945;
      {
	 approx_t aux_3750;
	 node_2945 = (funcall_cinfo_75_t) (node_3526);
	 {
	    approx_t fun_approx_73_2949;
	    {
	       node_t aux_3751;
	       {
		  funcall_t obj_3476;
		  obj_3476 = (funcall_t) (node_2945);
		  aux_3751 = (((funcall_t) CREF(obj_3476))->fun);
	       }
	       fun_approx_73_2949 = cfa__102_cfa_cfa(aux_3751);
	    }
	    {
	       obj_t args_approx_137_2950;
	       {
		  obj_t l2078_2989;
		  {
		     obj_t aux_3755;
		     {
			funcall_t obj_3477;
			obj_3477 = (funcall_t) (node_2945);
			aux_3755 = (((funcall_t) CREF(obj_3477))->args);
		     }
		     l2078_2989 = CDR(aux_3755);
		  }
		  if (NULLP(l2078_2989))
		    {
		       args_approx_137_2950 = BNIL;
		    }
		  else
		    {
		       obj_t head2080_2991;
		       {
			  approx_t arg2455_3002;
			  {
			     node_t aux_3761;
			     {
				obj_t aux_3762;
				aux_3762 = CAR(l2078_2989);
				aux_3761 = (node_t) (aux_3762);
			     }
			     arg2455_3002 = cfa__102_cfa_cfa(aux_3761);
			  }
			  {
			     obj_t aux_3766;
			     aux_3766 = (obj_t) (arg2455_3002);
			     head2080_2991 = MAKE_PAIR(aux_3766, BNIL);
			  }
		       }
		       {
			  obj_t l2078_2992;
			  obj_t tail2081_2993;
			  l2078_2992 = CDR(l2078_2989);
			  tail2081_2993 = head2080_2991;
			lname2079_2994:
			  if (NULLP(l2078_2992))
			    {
			       args_approx_137_2950 = head2080_2991;
			    }
			  else
			    {
			       obj_t newtail2082_2997;
			       {
				  approx_t arg2452_2999;
				  {
				     node_t aux_3771;
				     {
					obj_t aux_3772;
					aux_3772 = CAR(l2078_2992);
					aux_3771 = (node_t) (aux_3772);
				     }
				     arg2452_2999 = cfa__102_cfa_cfa(aux_3771);
				  }
				  {
				     obj_t aux_3776;
				     aux_3776 = (obj_t) (arg2452_2999);
				     newtail2082_2997 = MAKE_PAIR(aux_3776, BNIL);
				  }
			       }
			       SET_CDR(tail2081_2993, newtail2082_2997);
			       {
				  obj_t tail2081_3782;
				  obj_t l2078_3780;
				  l2078_3780 = CDR(l2078_2992);
				  tail2081_3782 = newtail2082_2997;
				  tail2081_2993 = tail2081_3782;
				  l2078_2992 = l2078_3780;
				  goto lname2079_2994;
			       }
			    }
		       }
		    }
	       }
	       {
		  {
		     type_t fun_type_165_2951;
		     fun_type_165_2951 = (((approx_t) CREF(fun_approx_73_2949))->type);
		     {
			bool_t test2420_2952;
			{
			   bool_t test2421_2953;
			   {
			      obj_t obj2_3493;
			      obj2_3493 = ____74_type_cache;
			      {
				 obj_t aux_3785;
				 aux_3785 = (obj_t) (fun_type_165_2951);
				 test2421_2953 = (aux_3785 == obj2_3493);
			      }
			   }
			   if (test2421_2953)
			     {
				test2420_2952 = ((bool_t) 0);
			     }
			   else
			     {
				bool_t test2422_2954;
				{
				   obj_t obj2_3495;
				   obj2_3495 = _obj__252_type_cache;
				   {
				      obj_t aux_3789;
				      aux_3789 = (obj_t) (fun_type_165_2951);
				      test2422_2954 = (aux_3789 == obj2_3495);
				   }
				}
				if (test2422_2954)
				  {
				     test2420_2952 = ((bool_t) 0);
				  }
				else
				  {
				     bool_t test2423_2955;
				     {
					obj_t obj2_3497;
					obj2_3497 = _procedure__226_type_cache;
					{
					   obj_t aux_3793;
					   aux_3793 = (obj_t) (fun_type_165_2951);
					   test2423_2955 = (aux_3793 == obj2_3497);
					}
				     }
				     if (test2423_2955)
				       {
					  test2420_2952 = ((bool_t) 0);
				       }
				     else
				       {
					  test2420_2952 = ((bool_t) 1);
				       }
				  }
			     }
			}
			if (test2420_2952)
			  {
			     funcall_type_error_218_cfa_funcall(node_2945, fun_type_165_2951);
			  }
			else
			  {
			     BUNSPEC;
			  }
		     }
		  }
		  {
		     bool_t test2424_2956;
		     {
			bool_t test2426_2958;
			{
			   obj_t obj2_3500;
			   obj2_3500 = _procedure__226_type_cache;
			   {
			      obj_t aux_3799;
			      {
				 type_t aux_3800;
				 aux_3800 = (((approx_t) CREF(fun_approx_73_2949))->type);
				 aux_3799 = (obj_t) (aux_3800);
			      }
			      test2426_2958 = (aux_3799 == obj2_3500);
			   }
			}
			if (test2426_2958)
			  {
			     test2424_2956 = (((approx_t) CREF(fun_approx_73_2949))->top__138);
			  }
			else
			  {
			     test2424_2956 = ((bool_t) 1);
			  }
		     }
		     if (test2424_2956)
		       {
			  approx_t aux_3807;
			  {
			     obj_t aux_3808;
			     {
				object_t aux_3809;
				aux_3809 = (object_t) (node_2945);
				aux_3808 = OBJECT_WIDENING(aux_3809);
			     }
			     aux_3807 = (((funcall_cinfo_75_t) CREF(aux_3808))->approx);
			  }
			  approx_set_type__239_cfa_approx(aux_3807, (type_t) (_obj__252_type_cache));
		       }
		     else
		       {
			  BUNSPEC;
		       }
		  }
		  {
		     bool_t test2428_2960;
		     if ((((approx_t) CREF(fun_approx_73_2949))->top__138))
		       {
			  test2428_2960 = ((bool_t) 1);
		       }
		     else
		       {
			  bool_t test2446_2987;
			  {
			     obj_t obj2_3506;
			     obj2_3506 = _procedure__226_type_cache;
			     {
				obj_t aux_3817;
				{
				   type_t aux_3818;
				   aux_3818 = (((approx_t) CREF(fun_approx_73_2949))->type);
				   aux_3817 = (obj_t) (aux_3818);
				}
				test2446_2987 = (aux_3817 == obj2_3506);
			     }
			  }
			  if (test2446_2987)
			    {
			       test2428_2960 = ((bool_t) 0);
			    }
			  else
			    {
			       test2428_2960 = ((bool_t) 1);
			    }
		       }
		     if (test2428_2960)
		       {
			  {
			     obj_t l2083_2961;
			     l2083_2961 = args_approx_137_2950;
			   lname2084_2962:
			     if (PAIRP(l2083_2961))
			       {
				  {
				     approx_t aux_3826;
				     {
					obj_t aux_3827;
					aux_3827 = CAR(l2083_2961);
					aux_3826 = (approx_t) (aux_3827);
				     }
				     loose__226_cfa_loose(aux_3826, CNST_TABLE_REF(((long) 0)));
				  }
				  {
				     obj_t l2083_3832;
				     l2083_3832 = CDR(l2083_2961);
				     l2083_2961 = l2083_3832;
				     goto lname2084_2962;
				  }
			       }
			     else
			       {
				  ((bool_t) 1);
			       }
			  }
			  {
			     obj_t arg2432_3523;
			     arg2432_3523 = make_fx_procedure(arg2432_cfa_funcall, ((long) 1), ((long) 3));
			     {
				obj_t aux_3835;
				aux_3835 = (obj_t) (node_2945);
				PROCEDURE_SET(arg2432_3523, ((long) 0), aux_3835);
			     }
			     PROCEDURE_SET(arg2432_3523, ((long) 1), args_approx_137_2950);
			     {
				obj_t aux_3839;
				aux_3839 = (obj_t) (node_2945);
				PROCEDURE_SET(arg2432_3523, ((long) 2), aux_3839);
			     }
			     for_each_approx_alloc_83_cfa_approx(arg2432_3523, fun_approx_73_2949);
			  }
			  {
			     approx_t aux_3843;
			     {
				obj_t aux_3844;
				{
				   object_t aux_3845;
				   aux_3845 = (object_t) (node_2945);
				   aux_3844 = OBJECT_WIDENING(aux_3845);
				}
				aux_3843 = (((funcall_cinfo_75_t) CREF(aux_3844))->approx);
			     }
			     approx_set_top__187_cfa_approx(aux_3843);
			  }
		       }
		     else
		       {
			  obj_t arg2439_3522;
			  arg2439_3522 = make_fx_procedure(arg2439_cfa_funcall, ((long) 1), ((long) 3));
			  {
			     obj_t aux_3851;
			     aux_3851 = (obj_t) (node_2945);
			     PROCEDURE_SET(arg2439_3522, ((long) 0), aux_3851);
			  }
			  PROCEDURE_SET(arg2439_3522, ((long) 1), args_approx_137_2950);
			  {
			     obj_t aux_3855;
			     aux_3855 = (obj_t) (node_2945);
			     PROCEDURE_SET(arg2439_3522, ((long) 2), aux_3855);
			  }
			  for_each_approx_alloc_83_cfa_approx(arg2439_3522, fun_approx_73_2949);
		       }
		  }
		  {
		     obj_t aux_3859;
		     {
			object_t aux_3860;
			aux_3860 = (object_t) (node_2945);
			aux_3859 = OBJECT_WIDENING(aux_3860);
		     }
		     aux_3750 = (((funcall_cinfo_75_t) CREF(aux_3859))->approx);
		  }
	       }
	    }
	 }
	 return (obj_t) (aux_3750);
      }
   }
}


/* arg2432 */ obj_t 
arg2432_cfa_funcall(obj_t env_3527, obj_t alloc_3531)
{
   {
      obj_t instance2077_3528;
      obj_t args_approx_137_3529;
      obj_t node_3530;
      instance2077_3528 = PROCEDURE_REF(env_3527, ((long) 0));
      args_approx_137_3529 = PROCEDURE_REF(env_3527, ((long) 1));
      node_3530 = PROCEDURE_REF(env_3527, ((long) 2));
      {
	 obj_t alloc_2968;
	 {
	    approx_t aux_3869;
	    alloc_2968 = alloc_3531;
	    {
	       bool_t test2434_2970;
	       test2434_2970 = is_a__118___object(alloc_2968, make_procedure_app_48_cfa_info);
	       if (test2434_2970)
		 {
		    approx_t arg2435_2972;
		    approx_t arg2436_2973;
		    {
		       funcall_cinfo_75_t obj_3512;
		       obj_3512 = (funcall_cinfo_75_t) (instance2077_3528);
		       {
			  obj_t aux_3873;
			  {
			     object_t aux_3874;
			     aux_3874 = (object_t) (obj_3512);
			     aux_3873 = OBJECT_WIDENING(aux_3874);
			  }
			  arg2435_2972 = (((funcall_cinfo_75_t) CREF(aux_3873))->approx);
		       }
		    }
		    {
		       obj_t arg2437_2974;
		       {
			  obj_t aux_3878;
			  {
			     approx_t aux_3879;
			     {
				make_procedure_app_48_t obj_3511;
				obj_3511 = (make_procedure_app_48_t) (alloc_2968);
				{
				   obj_t aux_3881;
				   {
				      object_t aux_3882;
				      aux_3882 = (object_t) (obj_3511);
				      aux_3881 = OBJECT_WIDENING(aux_3882);
				   }
				   aux_3879 = (((make_procedure_app_48_t) CREF(aux_3881))->approx);
				}
			     }
			     aux_3878 = (obj_t) (aux_3879);
			  }
			  arg2437_2974 = MAKE_PAIR(aux_3878, args_approx_137_3529);
		       }
		       arg2436_2973 = funcall__128_cfa_funcall((make_procedure_app_48_t) (alloc_2968), arg2437_2974, node_3530);
		    }
		    aux_3869 = union_approx__241_cfa_approx(arg2435_2972, arg2436_2973);
		 }
	       else
		 {
		    aux_3869 = make_empty_approx_131_cfa_approx();
		 }
	    }
	    return (obj_t) (aux_3869);
	 }
      }
   }
}


/* arg2439 */ obj_t 
arg2439_cfa_funcall(obj_t env_3532, obj_t alloc_3536)
{
   {
      obj_t instance2077_3533;
      obj_t args_approx_137_3534;
      obj_t node_3535;
      instance2077_3533 = PROCEDURE_REF(env_3532, ((long) 0));
      args_approx_137_3534 = PROCEDURE_REF(env_3532, ((long) 1));
      node_3535 = PROCEDURE_REF(env_3532, ((long) 2));
      {
	 obj_t alloc_2978;
	 {
	    approx_t aux_3896;
	    alloc_2978 = alloc_3536;
	    {
	       bool_t test2441_2980;
	       test2441_2980 = is_a__118___object(alloc_2978, make_procedure_app_48_cfa_info);
	       if (test2441_2980)
		 {
		    approx_t arg2442_2982;
		    approx_t arg2443_2983;
		    {
		       funcall_cinfo_75_t obj_3518;
		       obj_3518 = (funcall_cinfo_75_t) (instance2077_3533);
		       {
			  obj_t aux_3900;
			  {
			     object_t aux_3901;
			     aux_3901 = (object_t) (obj_3518);
			     aux_3900 = OBJECT_WIDENING(aux_3901);
			  }
			  arg2442_2982 = (((funcall_cinfo_75_t) CREF(aux_3900))->approx);
		       }
		    }
		    {
		       obj_t arg2444_2984;
		       {
			  obj_t aux_3905;
			  {
			     approx_t aux_3906;
			     {
				make_procedure_app_48_t obj_3517;
				obj_3517 = (make_procedure_app_48_t) (alloc_2978);
				{
				   obj_t aux_3908;
				   {
				      object_t aux_3909;
				      aux_3909 = (object_t) (obj_3517);
				      aux_3908 = OBJECT_WIDENING(aux_3909);
				   }
				   aux_3906 = (((make_procedure_app_48_t) CREF(aux_3908))->approx);
				}
			     }
			     aux_3905 = (obj_t) (aux_3906);
			  }
			  arg2444_2984 = MAKE_PAIR(aux_3905, args_approx_137_3534);
		       }
		       arg2443_2983 = funcall__128_cfa_funcall((make_procedure_app_48_t) (alloc_2978), arg2444_2984, node_3535);
		    }
		    aux_3896 = union_approx__241_cfa_approx(arg2442_2982, arg2443_2983);
		 }
	       else
		 {
		    aux_3896 = make_empty_approx_131_cfa_approx();
		 }
	    }
	    return (obj_t) (aux_3896);
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_funcall()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_FUNCALL");
   module_initialization_70_tools_shape(((long) 0), "CFA_FUNCALL");
   module_initialization_70_tools_args(((long) 0), "CFA_FUNCALL");
   module_initialization_70_tools_error(((long) 0), "CFA_FUNCALL");
   module_initialization_70_type_type(((long) 0), "CFA_FUNCALL");
   module_initialization_70_type_cache(((long) 0), "CFA_FUNCALL");
   module_initialization_70_ast_var(((long) 0), "CFA_FUNCALL");
   module_initialization_70_ast_node(((long) 0), "CFA_FUNCALL");
   module_initialization_70_cfa_info(((long) 0), "CFA_FUNCALL");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_FUNCALL");
   module_initialization_70_cfa_loose(((long) 0), "CFA_FUNCALL");
   module_initialization_70_cfa_approx(((long) 0), "CFA_FUNCALL");
   return module_initialization_70_cfa_app(((long) 0), "CFA_FUNCALL");
}
