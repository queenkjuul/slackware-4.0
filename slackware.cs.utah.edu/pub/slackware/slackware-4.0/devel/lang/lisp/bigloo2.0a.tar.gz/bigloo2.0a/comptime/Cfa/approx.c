/*===========================================================================*/
/*   (Cfa/approx.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_approx();
extern obj_t declare_approx_sets__132_cfa_approx();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t disable_x_t__211_cfa_procedure(approx_t);
extern obj_t type_type_type;
extern obj_t var_ast_node;
static obj_t shape_approx_123_cfa_approx(obj_t, obj_t);
extern obj_t get_allocs_52_cfa_collect();
extern obj_t get_node_atom_value_135_cfa_approx(node_t);
static obj_t _make_empty_approx_139_cfa_approx(obj_t);
extern obj_t set_union__206_cfa_set(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t _obj__252_type_cache;
static obj_t _make_alloc_approx2439_146_cfa_approx(obj_t, obj_t);
static obj_t _alloc_set__27_cfa_approx = BUNSPEC;
extern approx_t make_type_approx_184_cfa_approx(type_t);
static obj_t _shape_tools_shape(obj_t, obj_t);
extern approx_t make_empty_approx_131_cfa_approx();
static obj_t _approx_set_top_2437_229_cfa_approx(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_collect(long, char *);
extern obj_t module_initialization_70_cfa_set(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_procedure(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern approx_t make_alloc_approx_89_cfa_approx(app_t);
extern long class_num_218___object(obj_t);
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern obj_t make_set__25_cfa_set(obj_t);
static obj_t _node_key2433_145_cfa_approx(obj_t, obj_t);
extern obj_t reshaped_local_224_cfa_info;
extern obj_t node_ast_node;
static obj_t imported_modules_init_94_cfa_approx();
extern obj_t set_extend__187_cfa_set(obj_t, obj_t);
static obj_t _union_approx_2435_107_cfa_approx(obj_t, obj_t, obj_t);
static obj_t _get_node_atom_value2443_147_cfa_approx(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t _approx_set_type_2436_206_cfa_approx(obj_t, obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
static obj_t library_modules_init_112_cfa_approx();
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t atom_ast_node;
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t toplevel_init_63_cfa_approx();
extern obj_t node_key_123_cfa_approx(node_effect_213_t);
extern obj_t open_input_string(obj_t);
extern obj_t approx_set_type__239_cfa_approx(approx_t, type_t);
static obj_t _make_type_alloc_approx2440_154_cfa_approx(obj_t, obj_t, obj_t);
extern obj_t set__vector_66_cfa_set(obj_t);
extern obj_t approx_cfa_info;
static obj_t _node_key_set_2434_158_cfa_approx(obj_t, obj_t, obj_t);
static obj_t _declare_approx_sets__161_cfa_approx(obj_t);
static obj_t _make_type_approx2438_195_cfa_approx(obj_t, obj_t);
static obj_t _get_node_atom_value_default2085_98_cfa_approx(obj_t, obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t _4dots_199_tools_misc;
extern obj_t _classes__134___object;
extern obj_t set_for_each_94_cfa_set(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t node_key_set__195_cfa_approx(node_effect_213_t, obj_t);
extern obj_t declare_set__41_cfa_set(obj_t);
static obj_t get_node_atom_value_default2085_2_cfa_approx(node_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_cfa_approx = BUNSPEC;
extern approx_t make_type_alloc_approx_134_cfa_approx(type_t, node_t);
static obj_t _for_each_approx_alloc2441_11_cfa_approx(obj_t, obj_t, obj_t);
extern obj_t continue_cfa__104_cfa_iterate();
static obj_t cnst_init_137_cfa_approx();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(union_approx__env_180_cfa_approx, _union_approx_2435_107_cfa_approx2451, _union_approx_2435_107_cfa_approx, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_empty_approx_env_91_cfa_approx, _make_empty_approx_139_cfa_approx2452, _make_empty_approx_139_cfa_approx, 0L, 0);
DEFINE_EXPORT_PROCEDURE(make_alloc_approx_env_133_cfa_approx, _make_alloc_approx2439_146_cfa_approx2453, _make_alloc_approx2439_146_cfa_approx, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2444_cfa_approx, shape_approx_123_cfa_approx2454, shape_approx_123_cfa_approx, 0L, 1);
DEFINE_EXPORT_PROCEDURE(approx_set_type__env_251_cfa_approx, _approx_set_type_2436_206_cfa_approx2455, _approx_set_type_2436_206_cfa_approx, 0L, 2);
DEFINE_EXPORT_PROCEDURE(node_key_set__env_57_cfa_approx, _node_key_set_2434_158_cfa_approx2456, _node_key_set_2434_158_cfa_approx, 0L, 2);
DEFINE_STATIC_PROCEDURE(get_node_atom_value_default2085_env_146_cfa_approx, _get_node_atom_value_default2085_98_cfa_approx2457, _get_node_atom_value_default2085_98_cfa_approx, 0L, 1);
DEFINE_EXPORT_GENERIC(get_node_atom_value_env_18_cfa_approx, _get_node_atom_value2443_147_cfa_approx2458, _get_node_atom_value2443_147_cfa_approx, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_type_alloc_approx_env_199_cfa_approx, _make_type_alloc_approx2440_154_cfa_approx2459, _make_type_alloc_approx2440_154_cfa_approx, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_type_approx_env_161_cfa_approx, _make_type_approx2438_195_cfa_approx2460, _make_type_approx2438_195_cfa_approx, 0L, 1);
DEFINE_EXPORT_PROCEDURE(node_key_env_229_cfa_approx, _node_key2433_145_cfa_approx2461, _node_key2433_145_cfa_approx, 0L, 1);
DEFINE_STRING(string2445_cfa_approx, string2445_cfa_approx2462, "(NO-ATOM-VALUE) TOP ", 20);
DEFINE_EXPORT_PROCEDURE(declare_approx_sets__env_104_cfa_approx, _declare_approx_sets__161_cfa_approx2463, _declare_approx_sets__161_cfa_approx, 0L, 0);
extern obj_t shape_env_98_tools_shape;
DEFINE_EXPORT_PROCEDURE(for_each_approx_alloc_env_245_cfa_approx, _for_each_approx_alloc2441_11_cfa_approx2464, _for_each_approx_alloc2441_11_cfa_approx, 0L, 2);
DEFINE_EXPORT_PROCEDURE(approx_set_top__env_151_cfa_approx, _approx_set_top_2437_229_cfa_approx2465, _approx_set_top_2437_229_cfa_approx, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_cfa_approx(long checksum_3528, char *from_3529)
{
   if (CBOOL(require_initialization_114_cfa_approx))
     {
	require_initialization_114_cfa_approx = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_approx();
	cnst_init_137_cfa_approx();
	imported_modules_init_94_cfa_approx();
	method_init_76_cfa_approx();
	toplevel_init_63_cfa_approx();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_approx()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "CFA_APPROX");
   module_initialization_70___object(((long) 0), "CFA_APPROX");
   module_initialization_70___r4_vectors_6_8(((long) 0), "CFA_APPROX");
   module_initialization_70___reader(((long) 0), "CFA_APPROX");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_approx()
{
   {
      obj_t cnst_port_138_3520;
      cnst_port_138_3520 = open_input_string(string2445_cfa_approx);
      {
	 long i_3521;
	 i_3521 = ((long) 1);
       loop_3522:
	 {
	    bool_t test2446_3523;
	    test2446_3523 = (i_3521 == ((long) -1));
	    if (test2446_3523)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2447_3524;
		    {
		       obj_t list2448_3525;
		       {
			  obj_t arg2449_3526;
			  arg2449_3526 = BNIL;
			  list2448_3525 = MAKE_PAIR(cnst_port_138_3520, arg2449_3526);
		       }
		       arg2447_3524 = read___reader(list2448_3525);
		    }
		    CNST_TABLE_SET(i_3521, arg2447_3524);
		 }
		 {
		    int aux_3527;
		    {
		       long aux_3548;
		       aux_3548 = (i_3521 - ((long) 1));
		       aux_3527 = (int) (aux_3548);
		    }
		    {
		       long i_3551;
		       i_3551 = (long) (aux_3527);
		       i_3521 = i_3551;
		       goto loop_3522;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_approx()
{
   _alloc_set__27_cfa_approx = BUNSPEC;
   return BUNSPEC;
}


/* declare-approx-sets! */ obj_t 
declare_approx_sets__132_cfa_approx()
{
   {
      obj_t arg2090_2113;
      {
	 obj_t arg2091_2114;
	 arg2091_2114 = get_allocs_52_cfa_collect();
	 arg2090_2113 = list__vector_101___r4_vectors_6_8(arg2091_2114);
      }
      return (_alloc_set__27_cfa_approx = declare_set__41_cfa_set(arg2090_2113),
	 BUNSPEC);
   }
}


/* _declare-approx-sets! */ obj_t 
_declare_approx_sets__161_cfa_approx(obj_t env_3486)
{
   return declare_approx_sets__132_cfa_approx();
}


/* node-key */ obj_t 
node_key_123_cfa_approx(node_effect_213_t node_1)
{
   return (((node_effect_213_t) CREF(node_1))->key);
}


/* _node-key2433 */ obj_t 
_node_key2433_145_cfa_approx(obj_t env_3487, obj_t node_3488)
{
   return node_key_123_cfa_approx((node_effect_213_t) (node_3488));
}


/* node-key-set! */ obj_t 
node_key_set__195_cfa_approx(node_effect_213_t node_2, obj_t key_3)
{
   return ((((node_effect_213_t) CREF(node_2))->key) = ((obj_t) key_3), BUNSPEC);
}


/* _node-key-set!2434 */ obj_t 
_node_key_set_2434_158_cfa_approx(obj_t env_3489, obj_t node_3490, obj_t key_3491)
{
   return node_key_set__195_cfa_approx((node_effect_213_t) (node_3490), key_3491);
}


/* union-approx! */ approx_t 
union_approx__241_cfa_approx(approx_t dst_4, approx_t src_5)
{
   approx_set_type__239_cfa_approx(dst_4, (((approx_t) CREF(src_5))->type));
   {
      bool_t test2093_2116;
      {
	 bool_t test2094_2117;
	 {
	    obj_t obj2_2975;
	    obj2_2975 = _procedure__226_type_cache;
	    {
	       obj_t aux_3565;
	       {
		  type_t aux_3566;
		  aux_3566 = (((approx_t) CREF(dst_4))->type);
		  aux_3565 = (obj_t) (aux_3566);
	       }
	       test2094_2117 = (aux_3565 == obj2_2975);
	    }
	 }
	 if (test2094_2117)
	   {
	      test2093_2116 = ((bool_t) 1);
	   }
	 else
	   {
	      obj_t obj2_2978;
	      obj2_2978 = ____74_type_cache;
	      {
		 obj_t aux_3571;
		 {
		    type_t aux_3572;
		    aux_3572 = (((approx_t) CREF(dst_4))->type);
		    aux_3571 = (obj_t) (aux_3572);
		 }
		 test2093_2116 = (aux_3571 == obj2_2978);
	      }
	   }
      }
      if (test2093_2116)
	{
	   BUNSPEC;
	}
      else
	{
	   disable_x_t__211_cfa_procedure(src_5);
	}
   }
   if ((((approx_t) CREF(src_5))->top__138))
     {
	approx_set_top__187_cfa_approx(dst_4);
     }
   else
     {
	BUNSPEC;
     }
   {
      bool_t test2098_2121;
      {
	 obj_t arg2099_2122;
	 arg2099_2122 = (((approx_t) CREF(dst_4))->allocs);
	 {
	    obj_t list2101_2124;
	    {
	       obj_t aux_3582;
	       aux_3582 = (((approx_t) CREF(src_5))->allocs);
	       list2101_2124 = MAKE_PAIR(aux_3582, BNIL);
	    }
	    {
	       obj_t aux_3585;
	       aux_3585 = set_union__206_cfa_set(arg2099_2122, list2101_2124);
	       test2098_2121 = CBOOL(aux_3585);
	    }
	 }
      }
      if (test2098_2121)
	{
	   continue_cfa__104_cfa_iterate();
	}
      else
	{
	   BUNSPEC;
	}
   }
   return dst_4;
}


/* _union-approx!2435 */ obj_t 
_union_approx_2435_107_cfa_approx(obj_t env_3492, obj_t dst_3493, obj_t src_3494)
{
   {
      approx_t aux_3590;
      aux_3590 = union_approx__241_cfa_approx((approx_t) (dst_3493), (approx_t) (src_3494));
      return (obj_t) (aux_3590);
   }
}


/* approx-set-type! */ obj_t 
approx_set_type__239_cfa_approx(approx_t dst_6, type_t type_7)
{
   if ((((approx_t) CREF(dst_6))->type_locked__184))
     {
	return BFALSE;
     }
   else
     {
	bool_t test2104_2127;
	{
	   obj_t obj2_2984;
	   obj2_2984 = ____74_type_cache;
	   {
	      obj_t aux_3597;
	      aux_3597 = (obj_t) (type_7);
	      test2104_2127 = (aux_3597 == obj2_2984);
	   }
	}
	if (test2104_2127)
	  {
	     return BFALSE;
	  }
	else
	  {
	     bool_t test_3601;
	     {
		obj_t aux_3606;
		obj_t aux_3602;
		aux_3606 = (obj_t) (type_7);
		{
		   type_t aux_3603;
		   aux_3603 = (((approx_t) CREF(dst_6))->type);
		   aux_3602 = (obj_t) (aux_3603);
		}
		test_3601 = (aux_3602 == aux_3606);
	     }
	     if (test_3601)
	       {
		  return BFALSE;
	       }
	     else
	       {
		  bool_t test2106_2129;
		  {
		     obj_t obj2_2990;
		     obj2_2990 = _obj__252_type_cache;
		     {
			obj_t aux_3609;
			{
			   type_t aux_3610;
			   aux_3610 = (((approx_t) CREF(dst_6))->type);
			   aux_3609 = (obj_t) (aux_3610);
			}
			test2106_2129 = (aux_3609 == obj2_2990);
		     }
		  }
		  if (test2106_2129)
		    {
		       return BFALSE;
		    }
		  else
		    {
		       bool_t test2107_2130;
		       {
			  obj_t obj2_2993;
			  obj2_2993 = ____74_type_cache;
			  {
			     obj_t aux_3615;
			     {
				type_t aux_3616;
				aux_3616 = (((approx_t) CREF(dst_6))->type);
				aux_3615 = (obj_t) (aux_3616);
			     }
			     test2107_2130 = (aux_3615 == obj2_2993);
			  }
		       }
		       if (test2107_2130)
			 {
			    ((((approx_t) CREF(dst_6))->type) = ((type_t) type_7), BUNSPEC);
			    return continue_cfa__104_cfa_iterate();
			 }
		       else
			 {
			    {
			       type_t val1491_2997;
			       val1491_2997 = (type_t) (_obj__252_type_cache);
			       ((((approx_t) CREF(dst_6))->type) = ((type_t) val1491_2997), BUNSPEC);
			    }
			    return continue_cfa__104_cfa_iterate();
			 }
		    }
	       }
	  }
     }
}


/* _approx-set-type!2436 */ obj_t 
_approx_set_type_2436_206_cfa_approx(obj_t env_3495, obj_t dst_3496, obj_t type_3497)
{
   return approx_set_type__239_cfa_approx((approx_t) (dst_3496), (type_t) (type_3497));
}


/* approx-set-top! */ obj_t 
approx_set_top__187_cfa_approx(approx_t dst_8)
{
   if ((((approx_t) CREF(dst_8))->top__138))
     {
	return BUNSPEC;
     }
   else
     {
	((((approx_t) CREF(dst_8))->top__138) = ((bool_t) ((bool_t) 1)), BUNSPEC);
	return continue_cfa__104_cfa_iterate();
     }
}


/* _approx-set-top!2437 */ obj_t 
_approx_set_top_2437_229_cfa_approx(obj_t env_3498, obj_t dst_3499)
{
   return approx_set_top__187_cfa_approx((approx_t) (dst_3499));
}


/* make-empty-approx */ approx_t 
make_empty_approx_131_cfa_approx()
{
   {
      obj_t allocs_2135;
      allocs_2135 = make_set__25_cfa_set(_alloc_set__27_cfa_approx);
      {
	 obj_t arg2113_2136;
	 arg2113_2136 = ____74_type_cache;
	 {
	    approx_t res2428_3015;
	    {
	       type_t type_3001;
	       type_3001 = (type_t) (arg2113_2136);
	       {
		  approx_t new1484_3006;
		  new1484_3006 = ((approx_t) BREF(GC_MALLOC(sizeof(struct approx))));
		  {
		     long arg2303_3007;
		     arg2303_3007 = class_num_218___object(approx_cfa_info);
		     {
			obj_t obj_3013;
			obj_3013 = (obj_t) (new1484_3006);
			(((obj_t) CREF(obj_3013))->header = MAKE_HEADER(arg2303_3007, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_3641;
		     aux_3641 = (object_t) (new1484_3006);
		     OBJECT_WIDENING_SET(aux_3641, BFALSE);
		  }
		  ((((approx_t) CREF(new1484_3006))->type) = ((type_t) type_3001), BUNSPEC);
		  ((((approx_t) CREF(new1484_3006))->type_locked__184) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		  ((((approx_t) CREF(new1484_3006))->allocs) = ((obj_t) allocs_2135), BUNSPEC);
		  ((((approx_t) CREF(new1484_3006))->top__138) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		  ((((approx_t) CREF(new1484_3006))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
		  res2428_3015 = new1484_3006;
	       }
	    }
	    return res2428_3015;
	 }
      }
   }
}


/* _make-empty-approx */ obj_t 
_make_empty_approx_139_cfa_approx(obj_t env_3500)
{
   {
      approx_t aux_3649;
      aux_3649 = make_empty_approx_131_cfa_approx();
      return (obj_t) (aux_3649);
   }
}


/* make-type-approx */ approx_t 
make_type_approx_184_cfa_approx(type_t type_9)
{
   {
      obj_t allocs_2139;
      allocs_2139 = make_set__25_cfa_set(_alloc_set__27_cfa_approx);
      {
	 bool_t arg2117_2141;
	 {
	    bool_t test2122_2144;
	    {
	       obj_t obj2_3017;
	       obj2_3017 = ____74_type_cache;
	       {
		  obj_t aux_3653;
		  aux_3653 = (obj_t) (type_9);
		  test2122_2144 = (aux_3653 == obj2_3017);
	       }
	    }
	    if (test2122_2144)
	      {
		 arg2117_2141 = ((bool_t) 0);
	      }
	    else
	      {
		 arg2117_2141 = ((bool_t) 1);
	      }
	 }
	 {
	    approx_t res2429_3032;
	    {
	       approx_t new1484_3023;
	       new1484_3023 = ((approx_t) BREF(GC_MALLOC(sizeof(struct approx))));
	       {
		  long arg2303_3024;
		  arg2303_3024 = class_num_218___object(approx_cfa_info);
		  {
		     obj_t obj_3030;
		     obj_3030 = (obj_t) (new1484_3023);
		     (((obj_t) CREF(obj_3030))->header = MAKE_HEADER(arg2303_3024, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_3661;
		  aux_3661 = (object_t) (new1484_3023);
		  OBJECT_WIDENING_SET(aux_3661, BFALSE);
	       }
	       ((((approx_t) CREF(new1484_3023))->type) = ((type_t) type_9), BUNSPEC);
	       ((((approx_t) CREF(new1484_3023))->type_locked__184) = ((bool_t) arg2117_2141), BUNSPEC);
	       ((((approx_t) CREF(new1484_3023))->allocs) = ((obj_t) allocs_2139), BUNSPEC);
	       ((((approx_t) CREF(new1484_3023))->top__138) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	       ((((approx_t) CREF(new1484_3023))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
	       res2429_3032 = new1484_3023;
	    }
	    return res2429_3032;
	 }
      }
   }
}


/* _make-type-approx2438 */ obj_t 
_make_type_approx2438_195_cfa_approx(obj_t env_3501, obj_t type_3502)
{
   {
      approx_t aux_3669;
      aux_3669 = make_type_approx_184_cfa_approx((type_t) (type_3502));
      return (obj_t) (aux_3669);
   }
}


/* make-alloc-approx */ approx_t 
make_alloc_approx_89_cfa_approx(app_t alloc_10)
{
   {
      obj_t allocs_2145;
      allocs_2145 = make_set__25_cfa_set(_alloc_set__27_cfa_approx);
      set_extend__187_cfa_set(allocs_2145, (obj_t) (alloc_10));
      {
	 obj_t arg2123_2146;
	 arg2123_2146 = type_type_type;
	 {
	    approx_t res2430_3047;
	    {
	       type_t type_3033;
	       type_3033 = (type_t) (arg2123_2146);
	       {
		  approx_t new1484_3038;
		  new1484_3038 = ((approx_t) BREF(GC_MALLOC(sizeof(struct approx))));
		  {
		     long arg2303_3039;
		     arg2303_3039 = class_num_218___object(approx_cfa_info);
		     {
			obj_t obj_3045;
			obj_3045 = (obj_t) (new1484_3038);
			(((obj_t) CREF(obj_3045))->header = MAKE_HEADER(arg2303_3039, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_3681;
		     aux_3681 = (object_t) (new1484_3038);
		     OBJECT_WIDENING_SET(aux_3681, BFALSE);
		  }
		  ((((approx_t) CREF(new1484_3038))->type) = ((type_t) type_3033), BUNSPEC);
		  ((((approx_t) CREF(new1484_3038))->type_locked__184) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		  ((((approx_t) CREF(new1484_3038))->allocs) = ((obj_t) allocs_2145), BUNSPEC);
		  ((((approx_t) CREF(new1484_3038))->top__138) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		  ((((approx_t) CREF(new1484_3038))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
		  res2430_3047 = new1484_3038;
	       }
	    }
	    return res2430_3047;
	 }
      }
   }
}


/* _make-alloc-approx2439 */ obj_t 
_make_alloc_approx2439_146_cfa_approx(obj_t env_3503, obj_t alloc_3504)
{
   {
      approx_t aux_3689;
      aux_3689 = make_alloc_approx_89_cfa_approx((app_t) (alloc_3504));
      return (obj_t) (aux_3689);
   }
}


/* make-type-alloc-approx */ approx_t 
make_type_alloc_approx_134_cfa_approx(type_t type_11, node_t alloc_12)
{
   {
      obj_t allocs_2149;
      allocs_2149 = make_set__25_cfa_set(_alloc_set__27_cfa_approx);
      set_extend__187_cfa_set(allocs_2149, (obj_t) (alloc_12));
      {
	 bool_t arg2129_2151;
	 {
	    bool_t test2133_2154;
	    {
	       obj_t obj2_3049;
	       obj2_3049 = ____74_type_cache;
	       {
		  obj_t aux_3696;
		  aux_3696 = (obj_t) (type_11);
		  test2133_2154 = (aux_3696 == obj2_3049);
	       }
	    }
	    if (test2133_2154)
	      {
		 arg2129_2151 = ((bool_t) 0);
	      }
	    else
	      {
		 arg2129_2151 = ((bool_t) 1);
	      }
	 }
	 {
	    approx_t res2431_3064;
	    {
	       approx_t new1484_3055;
	       new1484_3055 = ((approx_t) BREF(GC_MALLOC(sizeof(struct approx))));
	       {
		  long arg2303_3056;
		  arg2303_3056 = class_num_218___object(approx_cfa_info);
		  {
		     obj_t obj_3062;
		     obj_3062 = (obj_t) (new1484_3055);
		     (((obj_t) CREF(obj_3062))->header = MAKE_HEADER(arg2303_3056, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_3704;
		  aux_3704 = (object_t) (new1484_3055);
		  OBJECT_WIDENING_SET(aux_3704, BFALSE);
	       }
	       ((((approx_t) CREF(new1484_3055))->type) = ((type_t) type_11), BUNSPEC);
	       ((((approx_t) CREF(new1484_3055))->type_locked__184) = ((bool_t) arg2129_2151), BUNSPEC);
	       ((((approx_t) CREF(new1484_3055))->allocs) = ((obj_t) allocs_2149), BUNSPEC);
	       ((((approx_t) CREF(new1484_3055))->top__138) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	       ((((approx_t) CREF(new1484_3055))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
	       res2431_3064 = new1484_3055;
	    }
	    return res2431_3064;
	 }
      }
   }
}


/* _make-type-alloc-approx2440 */ obj_t 
_make_type_alloc_approx2440_154_cfa_approx(obj_t env_3505, obj_t type_3506, obj_t alloc_3507)
{
   {
      approx_t aux_3712;
      aux_3712 = make_type_alloc_approx_134_cfa_approx((type_t) (type_3506), (node_t) (alloc_3507));
      return (obj_t) (aux_3712);
   }
}


/* for-each-approx-alloc */ obj_t 
for_each_approx_alloc_83_cfa_approx(obj_t proc_14, approx_t approx_15)
{
   return set_for_each_94_cfa_set(proc_14, (((approx_t) CREF(approx_15))->allocs));
}


/* _for-each-approx-alloc2441 */ obj_t 
_for_each_approx_alloc2441_11_cfa_approx(obj_t env_3508, obj_t proc_3509, obj_t approx_3510)
{
   return for_each_approx_alloc_83_cfa_approx(proc_3509, (approx_t) (approx_3510));
}


/* method-init */ obj_t 
method_init_76_cfa_approx()
{
   {
      obj_t shape_approx_123_3511;
      shape_approx_123_3511 = proc2444_cfa_approx;
      add_method__1___object(shape_env_98_tools_shape, approx_cfa_info, shape_approx_123_3511);
   }
   add_generic__110___object(get_node_atom_value_env_18_cfa_approx, get_node_atom_value_default2085_env_146_cfa_approx);
   add_inlined_method__244___object(get_node_atom_value_env_18_cfa_approx, atom_ast_node, ((long) 0));
   {
      long aux_3724;
      aux_3724 = add_inlined_method__244___object(get_node_atom_value_env_18_cfa_approx, var_ast_node, ((long) 1));
      return BINT(aux_3724);
   }
}


/* shape-approx */ obj_t 
shape_approx_123_cfa_approx(obj_t env_3512, obj_t exp_3513)
{
   {
      approx_t exp_2910;
      exp_2910 = (approx_t) (exp_3513);
      {
	 obj_t type_id_229_2914;
	 {
	    obj_t list2401_2936;
	    {
	       obj_t arg2402_2937;
	       {
		  obj_t aux_3727;
		  {
		     type_t arg2404_2939;
		     arg2404_2939 = (((approx_t) CREF(exp_2910))->type);
		     aux_3727 = (((type_t) CREF(arg2404_2939))->id);
		  }
		  arg2402_2937 = MAKE_PAIR(aux_3727, BNIL);
	       }
	       list2401_2936 = MAKE_PAIR(_4dots_199_tools_misc, arg2402_2937);
	    }
	    type_id_229_2914 = symbol_append_197___r4_symbols_6_4(list2401_2936);
	 }
	 {
	    obj_t keys_2915;
	    keys_2915 = set__vector_66_cfa_set((((approx_t) CREF(exp_2910))->allocs));
	    {
	       long len_2916;
	       len_2916 = VECTOR_LENGTH(keys_2915);
	       {
		  obj_t struct_2918;
		  {
		     long aux_3736;
		     if ((((approx_t) CREF(exp_2910))->top__138))
		       {
			  aux_3736 = (len_2916 + ((long) 1));
		       }
		     else
		       {
			  aux_3736 = len_2916;
		       }
		     struct_2918 = make_struct(type_id_229_2914, aux_3736, BUNSPEC);
		  }
		  {
		     if ((((approx_t) CREF(exp_2910))->top__138))
		       {
			  obj_t aux_3743;
			  aux_3743 = CNST_TABLE_REF(((long) 0));
			  STRUCT_SET(struct_2918, ((long) 0), aux_3743);
		       }
		     else
		       {
			  BUNSPEC;
		       }
		     {
			long r_2922;
			long w_2923;
			if ((((approx_t) CREF(exp_2910))->top__138))
			  {
			     r_2922 = ((long) 1);
			  }
			else
			  {
			     r_2922 = ((long) 0);
			  }
			w_2923 = ((long) 0);
		      loop_2924:
			if ((w_2923 == len_2916))
			  {
			     return struct_2918;
			  }
			else
			  {
			     {
				obj_t aux_3748;
				{
				   node_effect_213_t node_3443;
				   {
				      obj_t aux_3749;
				      aux_3749 = VECTOR_REF(keys_2915, w_2923);
				      node_3443 = (node_effect_213_t) (aux_3749);
				   }
				   aux_3748 = (((node_effect_213_t) CREF(node_3443))->key);
				}
				STRUCT_SET(struct_2918, r_2922, aux_3748);
			     }
			     {
				long w_3756;
				long r_3754;
				r_3754 = (r_2922 + ((long) 1));
				w_3756 = (w_2923 + ((long) 1));
				w_2923 = w_3756;
				r_2922 = r_3754;
				goto loop_2924;
			     }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* get-node-atom-value */ obj_t 
get_node_atom_value_135_cfa_approx(node_t node_16)
{
 get_node_atom_value_135_cfa_approx:
   {
      obj_t method2407_2946;
      obj_t class2412_2947;
      {
	 obj_t arg2415_2944;
	 obj_t arg2416_2945;
	 {
	    object_t obj_3452;
	    obj_3452 = (object_t) (node_16);
	    {
	       obj_t pre_method_105_3453;
	       pre_method_105_3453 = PROCEDURE_REF(get_node_atom_value_env_18_cfa_approx, ((long) 2));
	       if (INTEGERP(pre_method_105_3453))
		 {
		    PROCEDURE_SET(get_node_atom_value_env_18_cfa_approx, ((long) 2), BUNSPEC);
		    arg2415_2944 = pre_method_105_3453;
		 }
	       else
		 {
		    long obj_class_num_177_3458;
		    obj_class_num_177_3458 = TYPE(obj_3452);
		    {
		       obj_t arg1177_3459;
		       arg1177_3459 = PROCEDURE_REF(get_node_atom_value_env_18_cfa_approx, ((long) 1));
		       {
			  long arg1178_3463;
			  {
			     long arg1179_3464;
			     arg1179_3464 = OBJECT_TYPE;
			     arg1178_3463 = (obj_class_num_177_3458 - arg1179_3464);
			  }
			  arg2415_2944 = VECTOR_REF(arg1177_3459, arg1178_3463);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3469;
	    object_3469 = (object_t) (node_16);
	    {
	       long arg1180_3470;
	       {
		  long arg1181_3471;
		  long arg1182_3472;
		  arg1181_3471 = TYPE(object_3469);
		  arg1182_3472 = OBJECT_TYPE;
		  arg1180_3470 = (arg1181_3471 - arg1182_3472);
	       }
	       {
		  obj_t vector_3476;
		  vector_3476 = _classes__134___object;
		  arg2416_2945 = VECTOR_REF(vector_3476, arg1180_3470);
	       }
	    }
	 }
	 method2407_2946 = arg2415_2944;
	 class2412_2947 = arg2416_2945;
	 {
	    if (INTEGERP(method2407_2946))
	      {
		 switch ((long) CINT(method2407_2946))
		   {
		   case ((long) 0):
		      {
			 atom_t node_2953;
			 node_2953 = (atom_t) (node_16);
			 return (((atom_t) CREF(node_2953))->value);
		      }
		      break;
		   case ((long) 1):
		      {
			 var_t node_2954;
			 node_2954 = (var_t) (node_16);
			 {
			    variable_t v_2955;
			    v_2955 = (((var_t) CREF(node_2954))->variable);
			    {
			       bool_t test2419_2956;
			       {
				  bool_t test2421_2958;
				  test2421_2958 = is_a__118___object((obj_t) (v_2955), reshaped_local_224_cfa_info);
				  if (test2421_2958)
				    {
				       obj_t aux_3785;
				       {
					  reshaped_local_224_t obj_3481;
					  obj_3481 = (reshaped_local_224_t) (v_2955);
					  {
					     obj_t aux_3787;
					     {
						object_t aux_3788;
						aux_3788 = (object_t) (obj_3481);
						aux_3787 = OBJECT_WIDENING(aux_3788);
					     }
					     aux_3785 = (((reshaped_local_224_t) CREF(aux_3787))->binding_value_3);
					  }
				       }
				       test2419_2956 = is_a__118___object(aux_3785, node_ast_node);
				    }
				  else
				    {
				       test2419_2956 = ((bool_t) 0);
				    }
			       }
			       if (test2419_2956)
				 {
				    node_t node_3794;
				    {
				       obj_t aux_3795;
				       {
					  reshaped_local_224_t obj_3483;
					  obj_3483 = (reshaped_local_224_t) (v_2955);
					  {
					     obj_t aux_3797;
					     {
						object_t aux_3798;
						aux_3798 = (object_t) (obj_3483);
						aux_3797 = OBJECT_WIDENING(aux_3798);
					     }
					     aux_3795 = (((reshaped_local_224_t) CREF(aux_3797))->binding_value_3);
					  }
				       }
				       node_3794 = (node_t) (aux_3795);
				    }
				    node_16 = node_3794;
				    goto get_node_atom_value_135_cfa_approx;
				 }
			       else
				 {
				    return CNST_TABLE_REF(((long) 1));
				 }
			    }
			 }
		      }
		      break;
		   default:
		    case_else2413_2950:
		      if (PROCEDUREP(method2407_2946))
			{
			   return PROCEDURE_ENTRY(method2407_2946) (method2407_2946, (obj_t) (node_16), BEOA);
			}
		      else
			{
			   obj_t fun2406_2942;
			   fun2406_2942 = PROCEDURE_REF(get_node_atom_value_env_18_cfa_approx, ((long) 0));
			   return PROCEDURE_ENTRY(fun2406_2942) (fun2406_2942, (obj_t) (node_16), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2413_2950;
	      }
	 }
      }
   }
}


/* _get-node-atom-value2443 */ obj_t 
_get_node_atom_value2443_147_cfa_approx(obj_t env_3516, obj_t node_3517)
{
   return get_node_atom_value_135_cfa_approx((node_t) (node_3517));
}


/* get-node-atom-value-default2085 */ obj_t 
get_node_atom_value_default2085_2_cfa_approx(node_t node_17)
{
   return CNST_TABLE_REF(((long) 1));
}


/* _get-node-atom-value-default2085 */ obj_t 
_get_node_atom_value_default2085_98_cfa_approx(obj_t env_3518, obj_t node_3519)
{
   return get_node_atom_value_default2085_2_cfa_approx((node_t) (node_3519));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_approx()
{
   module_initialization_70_type_type(((long) 0), "CFA_APPROX");
   module_initialization_70_type_cache(((long) 0), "CFA_APPROX");
   module_initialization_70_tools_shape(((long) 0), "CFA_APPROX");
   module_initialization_70_tools_error(((long) 0), "CFA_APPROX");
   module_initialization_70_tools_misc(((long) 0), "CFA_APPROX");
   module_initialization_70_ast_var(((long) 0), "CFA_APPROX");
   module_initialization_70_ast_node(((long) 0), "CFA_APPROX");
   module_initialization_70_cfa_info(((long) 0), "CFA_APPROX");
   module_initialization_70_cfa_collect(((long) 0), "CFA_APPROX");
   module_initialization_70_cfa_set(((long) 0), "CFA_APPROX");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_APPROX");
   module_initialization_70_cfa_loose(((long) 0), "CFA_APPROX");
   return module_initialization_70_cfa_procedure(((long) 0), "CFA_APPROX");
}
