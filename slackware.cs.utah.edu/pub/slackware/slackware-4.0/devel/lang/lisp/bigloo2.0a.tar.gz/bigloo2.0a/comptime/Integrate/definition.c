/*===========================================================================*/
/*   (Integrate/definition.scm)                                              */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t method_init_76_integrate_definition();
extern obj_t integrate_definition__136_integrate_definition(obj_t);
extern obj_t set_kaptured__104_integrate_kaptured(obj_t);
extern obj_t globalize__167_integrate_node(node_t, variable_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_definition(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_integrate_a(long, char *);
extern obj_t module_initialization_70_integrate_kk(long, char *);
extern obj_t module_initialization_70_integrate_u(long, char *);
extern obj_t module_initialization_70_integrate_ctn(long, char *);
extern obj_t module_initialization_70_integrate_g(long, char *);
extern obj_t module_initialization_70_integrate_kaptured(long, char *);
extern obj_t module_initialization_70_integrate_let_fun_158(long, char *);
extern obj_t module_initialization_70_integrate_node(long, char *);
extern obj_t module_initialization_70_integrate_local__global_163(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t local__global_40_integrate_local__global_163(local_t);
extern obj_t displace_let_fun__199_integrate_let_fun_158(obj_t);
extern obj_t k___139_integrate_kk(obj_t);
static obj_t imported_modules_init_94_integrate_definition();
static obj_t library_modules_init_112_integrate_definition();
static obj_t _integrate_definition__196_integrate_definition(obj_t, obj_t);
extern obj_t local_ast_var;
extern obj_t shape_tools_shape(obj_t);
extern obj_t u__31_integrate_u();
static bool_t verb_globalization_175_integrate_definition(obj_t);
extern obj_t k__48_integrate_kk(obj_t, global_t);
extern obj_t g__63_integrate_g(obj_t);
extern obj_t cn_ct__54_integrate_ctn(obj_t);
extern obj_t _phi__105_integrate_a;
static obj_t require_initialization_114_integrate_definition = BUNSPEC;
extern obj_t a_integrate_a(global_t, node_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(integrate_definition__env_137_integrate_definition, _integrate_definition__196_integrate_definition1685, _integrate_definition__196_integrate_definition, 0L, 1);
DEFINE_STRING(string1683_integrate_definition, string1683_integrate_definition1686, "           ", 11);
DEFINE_STRING(string1682_integrate_definition, string1682_integrate_definition1687, " -->", 4);


/* module-initialization */ obj_t 
module_initialization_70_integrate_definition(long checksum_1409, char *from_1410)
{
   if (CBOOL(require_initialization_114_integrate_definition))
     {
	require_initialization_114_integrate_definition = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_definition();
	imported_modules_init_94_integrate_definition();
	method_init_76_integrate_definition();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_definition()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_DEFINITION");
   return BUNSPEC;
}


/* integrate-definition! */ obj_t 
integrate_definition__136_integrate_definition(obj_t global_1)
{
   {
      value_t fun_880;
      {
	 global_t obj_1312;
	 obj_1312 = (global_t) (global_1);
	 fun_880 = (((global_t) CREF(obj_1312))->value);
      }
      {
	 obj_t body_881;
	 {
	    sfun_t obj_1313;
	    obj_1313 = (sfun_t) (fun_880);
	    body_881 = (((sfun_t) CREF(obj_1313))->body);
	 }
	 {
	    obj_t a_882;
	    a_882 = a_integrate_a((global_t) (global_1), (node_t) (body_881));
	    {
	       {
		  obj_t arg1528_883;
		  arg1528_883 = k__48_integrate_kk(a_882, (global_t) (global_1));
		  k___139_integrate_kk(arg1528_883);
	       }
	       u__31_integrate_u();
	       {
		  obj_t g_884;
		  {
		     obj_t arg1561_926;
		     arg1561_926 = cn_ct__54_integrate_ctn(a_882);
		     g_884 = g__63_integrate_g(arg1561_926);
		  }
		  if (NULLP(g_884))
		    {
		       obj_t list1530_886;
		       list1530_886 = MAKE_PAIR(global_1, BNIL);
		       return list1530_886;
		    }
		  else
		    {
		       verb_globalization_175_integrate_definition(g_884);
		       {
			  obj_t l1517_888;
			  l1517_888 = _phi__105_integrate_a;
			lname1518_889:
			  if (PAIRP(l1517_888))
			    {
			       {
				  obj_t f_891;
				  f_891 = CAR(l1517_888);
				  {
				     bool_t test1533_892;
				     {
					bool_t test1537_898;
					test1537_898 = is_a__118___object(f_891, local_ast_var);
					if (test1537_898)
					  {
					     bool_t test_1440;
					     {
						sfun_iinfo_105_t obj_1320;
						{
						   value_t aux_1441;
						   {
						      local_t obj_1319;
						      obj_1319 = (local_t) (f_891);
						      aux_1441 = (((local_t) CREF(obj_1319))->value);
						   }
						   obj_1320 = (sfun_iinfo_105_t) (aux_1441);
						}
						{
						   obj_t aux_1445;
						   {
						      object_t aux_1446;
						      aux_1446 = (object_t) (obj_1320);
						      aux_1445 = OBJECT_WIDENING(aux_1446);
						   }
						   test_1440 = (((sfun_iinfo_105_t) CREF(aux_1445))->g__219);
						}
					     }
					     if (test_1440)
					       {
						  test1533_892 = ((bool_t) 0);
					       }
					     else
					       {
						  test1533_892 = ((bool_t) 1);
					       }
					  }
					else
					  {
					     test1533_892 = ((bool_t) 0);
					  }
				     }
				     if (test1533_892)
				       {
					  value_t ifu_894;
					  {
					     variable_t obj_1323;
					     {
						obj_t aux_1451;
						{
						   sfun_iinfo_105_t obj_1322;
						   {
						      value_t aux_1452;
						      {
							 local_t obj_1321;
							 obj_1321 = (local_t) (f_891);
							 aux_1452 = (((local_t) CREF(obj_1321))->value);
						      }
						      obj_1322 = (sfun_iinfo_105_t) (aux_1452);
						   }
						   {
						      obj_t aux_1456;
						      {
							 object_t aux_1457;
							 aux_1457 = (object_t) (obj_1322);
							 aux_1456 = OBJECT_WIDENING(aux_1457);
						      }
						      aux_1451 = (((sfun_iinfo_105_t) CREF(aux_1456))->l);
						   }
						}
						obj_1323 = (variable_t) (aux_1451);
					     }
					     ifu_894 = (((variable_t) CREF(obj_1323))->value);
					  }
					  {
					     {
						obj_t arg1534_895;
						{
						   obj_t aux_1463;
						   {
						      sfun_iinfo_105_t obj_1324;
						      obj_1324 = (sfun_iinfo_105_t) (ifu_894);
						      {
							 obj_t aux_1465;
							 {
							    object_t aux_1466;
							    aux_1466 = (object_t) (obj_1324);
							    aux_1465 = OBJECT_WIDENING(aux_1466);
							 }
							 aux_1463 = (((sfun_iinfo_105_t) CREF(aux_1465))->led);
						      }
						   }
						   arg1534_895 = MAKE_PAIR(f_891, aux_1463);
						}
						{
						   sfun_iinfo_105_t obj_1327;
						   obj_1327 = (sfun_iinfo_105_t) (ifu_894);
						   {
						      obj_t aux_1472;
						      {
							 object_t aux_1473;
							 aux_1473 = (object_t) (obj_1327);
							 aux_1472 = OBJECT_WIDENING(aux_1473);
						      }
						      ((((sfun_iinfo_105_t) CREF(aux_1472))->led) = ((obj_t) arg1534_895), BUNSPEC);
						   }
						}
					     }
					  }
				       }
				     else
				       {
					  BUNSPEC;
				       }
				  }
			       }
			       {
				  obj_t l1517_1477;
				  l1517_1477 = CDR(l1517_888);
				  l1517_888 = l1517_1477;
				  goto lname1518_889;
			       }
			    }
			  else
			    {
			       ((bool_t) 1);
			    }
		       }
		       {
			  obj_t l1519_902;
			  l1519_902 = g_884;
			lname1520_903:
			  if (PAIRP(l1519_902))
			    {
			       displace_let_fun__199_integrate_let_fun_158(CAR(l1519_902));
			       {
				  obj_t l1519_1483;
				  l1519_1483 = CDR(l1519_902);
				  l1519_902 = l1519_1483;
				  goto lname1520_903;
			       }
			    }
			  else
			    {
			       ((bool_t) 1);
			    }
		       }
		       displace_let_fun__199_integrate_let_fun_158(global_1);
		       set_kaptured__104_integrate_kaptured(g_884);
		       {
			  obj_t new_g_67_907;
			  if (NULLP(g_884))
			    {
			       new_g_67_907 = BNIL;
			    }
			  else
			    {
			       obj_t head1523_912;
			       {
				  obj_t arg1558_923;
				  {
				     local_t aux_1489;
				     {
					obj_t aux_1490;
					aux_1490 = CAR(g_884);
					aux_1489 = (local_t) (aux_1490);
				     }
				     arg1558_923 = local__global_40_integrate_local__global_163(aux_1489);
				  }
				  head1523_912 = MAKE_PAIR(arg1558_923, BNIL);
			       }
			       {
				  obj_t l1521_913;
				  obj_t tail1524_914;
				  l1521_913 = CDR(g_884);
				  tail1524_914 = head1523_912;
				lname1522_915:
				  if (NULLP(l1521_913))
				    {
				       new_g_67_907 = head1523_912;
				    }
				  else
				    {
				       obj_t newtail1525_918;
				       {
					  obj_t arg1555_920;
					  {
					     local_t aux_1497;
					     {
						obj_t aux_1498;
						aux_1498 = CAR(l1521_913);
						aux_1497 = (local_t) (aux_1498);
					     }
					     arg1555_920 = local__global_40_integrate_local__global_163(aux_1497);
					  }
					  newtail1525_918 = MAKE_PAIR(arg1555_920, BNIL);
				       }
				       SET_CDR(tail1524_914, newtail1525_918);
				       {
					  obj_t tail1524_1506;
					  obj_t l1521_1504;
					  l1521_1504 = CDR(l1521_913);
					  tail1524_1506 = newtail1525_918;
					  tail1524_914 = tail1524_1506;
					  l1521_913 = l1521_1504;
					  goto lname1522_915;
				       }
				    }
			       }
			    }
			  {
			     obj_t arg1548_908;
			     arg1548_908 = globalize__167_integrate_node((node_t) (body_881), (variable_t) (global_1), BNIL);
			     {
				sfun_t obj_1345;
				obj_1345 = (sfun_t) (fun_880);
				((((sfun_t) CREF(obj_1345))->body) = ((obj_t) arg1548_908), BUNSPEC);
			     }
			  }
			  return MAKE_PAIR(global_1, new_g_67_907);
		       }
		    }
	       }
	    }
	 }
      }
   }
}


/* _integrate-definition! */ obj_t 
_integrate_definition__196_integrate_definition(obj_t env_1407, obj_t global_1408)
{
   return integrate_definition__136_integrate_definition(global_1408);
}


/* verb-globalization */ bool_t 
verb_globalization_175_integrate_definition(obj_t g_2)
{
   {
      obj_t l1526_927;
      l1526_927 = g_2;
    lname1527_928:
      if (PAIRP(l1526_927))
	{
	   {
	      obj_t arg1565_933;
	      arg1565_933 = shape_tools_shape(CAR(l1526_927));
	      {
		 obj_t list1567_935;
		 {
		    obj_t arg1568_936;
		    {
		       obj_t arg1569_937;
		       {
			  obj_t arg1570_938;
			  {
			     obj_t aux_1519;
			     aux_1519 = BCHAR(((unsigned char) '\n'));
			     arg1570_938 = MAKE_PAIR(aux_1519, BNIL);
			  }
			  arg1569_937 = MAKE_PAIR(string1682_integrate_definition, arg1570_938);
		       }
		       arg1568_936 = MAKE_PAIR(arg1565_933, arg1569_937);
		    }
		    list1567_935 = MAKE_PAIR(string1683_integrate_definition, arg1568_936);
		 }
		 verbose_tools_speek(BINT(((long) 3)), list1567_935);
	      }
	   }
	   {
	      obj_t l1526_1527;
	      l1526_1527 = CDR(l1526_927);
	      l1526_927 = l1526_1527;
	      goto lname1527_928;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_integrate_definition()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_definition()
{
   module_initialization_70_tools_trace(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_ast_node(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_tools_shape(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_tools_speek(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_info(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_a(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_kk(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_u(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_ctn(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_g(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_kaptured(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_let_fun_158(((long) 0), "INTEGRATE_DEFINITION");
   module_initialization_70_integrate_node(((long) 0), "INTEGRATE_DEFINITION");
   return module_initialization_70_integrate_local__global_163(((long) 0), "INTEGRATE_DEFINITION");
}
