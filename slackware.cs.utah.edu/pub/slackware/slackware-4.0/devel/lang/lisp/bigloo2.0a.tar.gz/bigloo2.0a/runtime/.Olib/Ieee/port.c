/*===========================================================================*/
/*   (Ieee/port.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t _open_input_string1254_138___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _with_output_to_port1250_24___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern obj_t call_with_input_file_94___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _call_with_output_file1246_210___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern bool_t reset_eof(obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_output_file_247___r4_ports_6_10_1(obj_t);
extern obj_t with_error_to_file_201___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t current_output_port;
static obj_t _close_input_port1257_162___r4_ports_6_10_1(obj_t, obj_t);
extern bool_t directoryp(char *);
extern bool_t reset_eof_236___r4_ports_6_10_1(obj_t);
extern obj_t call_with_output_file_65___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _append_output_file1264_138___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t current_error_port;
extern obj_t directory_to_list(char *);
static obj_t _input_port_position1261_156___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _delete_file1265_238___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t current_output_port_239___r4_ports_6_10_1();
extern obj_t with_error_to_port_5___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t current_error_port_17___r4_ports_6_10_1();
static obj_t _with_error_to_file1251_82___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern obj_t output_port__47___r4_ports_6_10_1(obj_t);
static obj_t _current_error_port_229___r4_ports_6_10_1(obj_t);
extern obj_t close_input_port_142___r4_ports_6_10_1(obj_t);
static obj_t _open_output_file1256_162___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _directory_1268_185___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _with_output_to_file1249_24___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern obj_t close_output_port(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t current_input_port;
static obj_t _close_output_port1258_204___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _input_port__169___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t open_input_file(obj_t, obj_t);
static obj_t _file_exists_1263_64___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t with_output_to_file_237___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t current_input_port_104___r4_ports_6_10_1();
extern obj_t close_input_port(obj_t);
extern long default_io_bufsiz;
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _input_port_name1262_241___r4_ports_6_10_1(obj_t, obj_t);
static obj_t handling_function1055___r4_ports_6_10_1(obj_t, obj_t);
static obj_t handling_function1050___r4_ports_6_10_1(obj_t, obj_t);
static obj_t handling_function1045___r4_ports_6_10_1(obj_t, obj_t);
static obj_t handling_function1041___r4_ports_6_10_1(obj_t, obj_t);
static obj_t handling_function1036___r4_ports_6_10_1(obj_t, obj_t);
static obj_t handling_function1031___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _rename_file1267_209___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern obj_t flush_output_port_36___r4_ports_6_10_1(obj_t);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _current_input_port_198___r4_ports_6_10_1(obj_t);
extern obj_t delete_file_114___r4_ports_6_10_1(char *);
extern obj_t open_output_string();
extern obj_t open_input_string_20___r4_ports_6_10_1(obj_t);
static obj_t _open_input_c_string1255_105___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t input_port__135___r4_ports_6_10_1(obj_t);
static obj_t _directory__list1269_16___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _with_input_from_port1248_1___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern bool_t directory__80___r4_ports_6_10_1(char *);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern bool_t fexists(char *);
extern obj_t with_output_to_port_151___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t open_output_file_240___r4_ports_6_10_1(obj_t);
extern obj_t rename_file_185___r4_ports_6_10_1(char *, char *);
extern obj_t open_output_string_81___r4_ports_6_10_1();
extern obj_t close_output_port_77___r4_ports_6_10_1(obj_t);
static obj_t _call_with_input_file1245_143___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern char * input_port_name_249___r4_ports_6_10_1(obj_t);
static obj_t _delete_directory1266_20___r4_ports_6_10_1(obj_t, obj_t);
static obj_t _current_output_port_118___r4_ports_6_10_1(obj_t);
static obj_t _reset_eof1260_237___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t with_input_from_file_180___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t open_input_c_string(char *);
static obj_t _open_output_string_243___r4_ports_6_10_1(obj_t);
static obj_t _flush_output_port1259_6___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t delete_directory_248___r4_ports_6_10_1(char *);
static obj_t _port__120___r4_ports_6_10_1(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_ports_6_10_1();
static obj_t _output_port__133___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t open_output_file(obj_t);
static obj_t symbol1824___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1823___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1822___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1821___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1819___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1820___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1818___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1817___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1816___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1815___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1814___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1813___r4_ports_6_10_1 = BUNSPEC;
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t symbol1812___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1811___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1799___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1809___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1810___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1798___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1808___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1797___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1807___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1796___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1806___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1795___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1805___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1794___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1804___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1803___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1792___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1802___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1791___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1801___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1789___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1790___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1800___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1788___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1785___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1784___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1782___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1781___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1779___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1777___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1776___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1774___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1773___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1771___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1769___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1768___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1766___r4_ports_6_10_1 = BUNSPEC;
static obj_t require_initialization_114___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1765___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1764___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1761___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1758___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1757___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1756___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1755___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1754___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1753___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1752___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1748___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1745___r4_ports_6_10_1 = BUNSPEC;
extern obj_t file_exists__238___r4_ports_6_10_1(char *);
static obj_t symbol1740___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1738___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1737___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1736___r4_ports_6_10_1 = BUNSPEC;
static obj_t symbol1733___r4_ports_6_10_1 = BUNSPEC;
extern obj_t open_input_c_string_190___r4_ports_6_10_1(char *);
extern obj_t with_input_from_port_242___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t append_output_file(obj_t);
static obj_t _with_error_to_port1252_161___r4_ports_6_10_1(obj_t, obj_t, obj_t);
extern bool_t port__25___r4_ports_6_10_1(obj_t);
static obj_t _with_input_from_file1247_95___r4_ports_6_10_1(obj_t, obj_t, obj_t);
static obj_t list1763___r4_ports_6_10_1 = BUNSPEC;
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
extern int input_port_position_149___r4_ports_6_10_1(obj_t);
extern obj_t directory__list_196___r4_ports_6_10_1(char *);
static obj_t cnst_init_137___r4_ports_6_10_1();
static obj_t _open_input_file1253_207___r4_ports_6_10_1(obj_t, obj_t, obj_t);
static obj_t list1735___r4_ports_6_10_1 = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( open_input_file_env_205___r4_ports_6_10_1, _open_input_file1253_207___r4_ports_6_10_11826, va_generic_entry, _open_input_file1253_207___r4_ports_6_10_1, -2 );
DEFINE_EXPORT_PROCEDURE( open_input_c_string_env_188___r4_ports_6_10_1, _open_input_c_string1255_105___r4_ports_6_10_11827, _open_input_c_string1255_105___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( flush_output_port_env_174___r4_ports_6_10_1, _flush_output_port1259_6___r4_ports_6_10_11828, _flush_output_port1259_6___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( close_input_port_env_160___r4_ports_6_10_1, _close_input_port1257_162___r4_ports_6_10_11829, _close_input_port1257_162___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( reset_eof_env_94___r4_ports_6_10_1, _reset_eof1260_237___r4_ports_6_10_11830, _reset_eof1260_237___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( file_exists__env_75___r4_ports_6_10_1, _file_exists_1263_64___r4_ports_6_10_11831, _file_exists_1263_64___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( directory__env_134___r4_ports_6_10_1, _directory_1268_185___r4_ports_6_10_11832, _directory_1268_185___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( delete_file_env_16___r4_ports_6_10_1, _delete_file1265_238___r4_ports_6_10_11833, _delete_file1265_238___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( current_error_port_env_195___r4_ports_6_10_1, _current_error_port_229___r4_ports_6_10_11834, _current_error_port_229___r4_ports_6_10_1, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( open_input_string_env_49___r4_ports_6_10_1, _open_input_string1254_138___r4_ports_6_10_11835, _open_input_string1254_138___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( open_output_file_env_95___r4_ports_6_10_1, _open_output_file1256_162___r4_ports_6_10_11836, _open_output_file1256_162___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( with_error_to_port_env_185___r4_ports_6_10_1, _with_error_to_port1252_161___r4_ports_6_10_11837, _with_error_to_port1252_161___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( with_input_from_port_env_200___r4_ports_6_10_1, _with_input_from_port1248_1___r4_ports_6_10_11838, _with_input_from_port1248_1___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( with_output_to_port_env_101___r4_ports_6_10_1, _with_output_to_port1250_24___r4_ports_6_10_11839, _with_output_to_port1250_24___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( call_with_output_file_env_32___r4_ports_6_10_1, _call_with_output_file1246_210___r4_ports_6_10_11840, _call_with_output_file1246_210___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( input_port_name_env_215___r4_ports_6_10_1, _input_port_name1262_241___r4_ports_6_10_11841, _input_port_name1262_241___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( call_with_input_file_env_0___r4_ports_6_10_1, _call_with_input_file1245_143___r4_ports_6_10_11842, _call_with_input_file1245_143___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( current_output_port_env_251___r4_ports_6_10_1, _current_output_port_118___r4_ports_6_10_11843, _current_output_port_118___r4_ports_6_10_1, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( input_port__env_18___r4_ports_6_10_1, _input_port__169___r4_ports_6_10_11844, _input_port__169___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( input_port_position_env_191___r4_ports_6_10_1, _input_port_position1261_156___r4_ports_6_10_11845, _input_port_position1261_156___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( directory__list_env_105___r4_ports_6_10_1, _directory__list1269_16___r4_ports_6_10_11846, _directory__list1269_16___r4_ports_6_10_1, 0L, 1 );
DEFINE_STRING( string1793___r4_ports_6_10_1, string1793___r4_ports_6_10_11847, "STRING", 6 );
DEFINE_STRING( string1787___r4_ports_6_10_1, string1787___r4_ports_6_10_11848, "not a number", 12 );
DEFINE_STRING( string1786___r4_ports_6_10_1, string1786___r4_ports_6_10_11849, "open-input-file", 15 );
DEFINE_STRING( string1783___r4_ports_6_10_1, string1783___r4_ports_6_10_11850, "HANDLING_FUNCTION1055:Wrong number of arguments", 47 );
DEFINE_STRING( string1780___r4_ports_6_10_1, string1780___r4_ports_6_10_11851, "HANDLING_FUNCTION1050:Wrong number of arguments", 47 );
DEFINE_STRING( string1778___r4_ports_6_10_1, string1778___r4_ports_6_10_11852, "with-error-to-file", 18 );
DEFINE_STRING( string1775___r4_ports_6_10_1, string1775___r4_ports_6_10_11853, "HANDLING_FUNCTION1045:Wrong number of arguments", 47 );
DEFINE_STRING( string1772___r4_ports_6_10_1, string1772___r4_ports_6_10_11854, "HANDLING_FUNCTION1041:Wrong number of arguments", 47 );
DEFINE_STRING( string1770___r4_ports_6_10_1, string1770___r4_ports_6_10_11855, "with-output-to-file", 19 );
DEFINE_STRING( string1767___r4_ports_6_10_1, string1767___r4_ports_6_10_11856, "HANDLING_FUNCTION1036:Wrong number of arguments", 47 );
DEFINE_STRING( string1762___r4_ports_6_10_1, string1762___r4_ports_6_10_11857, "HANDLING_FUNCTION1031:Wrong number of arguments", 47 );
DEFINE_STRING( string1759___r4_ports_6_10_1, string1759___r4_ports_6_10_11858, "PAIR", 4 );
DEFINE_STRING( string1760___r4_ports_6_10_1, string1760___r4_ports_6_10_11859, "with-input-from-file", 20 );
DEFINE_STRING( string1751___r4_ports_6_10_1, string1751___r4_ports_6_10_11860, "call-with-output-file", 21 );
DEFINE_STRING( string1749___r4_ports_6_10_1, string1749___r4_ports_6_10_11861, "CALL-WITH-OUTPUT-FILE:Wrong number of arguments", 47 );
DEFINE_STRING( string1750___r4_ports_6_10_1, string1750___r4_ports_6_10_11862, "OUTPUT-PORT", 11 );
DEFINE_STRING( string1747___r4_ports_6_10_1, string1747___r4_ports_6_10_11863, "PROCEDURE", 9 );
DEFINE_STRING( string1746___r4_ports_6_10_1, string1746___r4_ports_6_10_11864, "BSTRING", 7 );
DEFINE_STRING( string1744___r4_ports_6_10_1, string1744___r4_ports_6_10_11865, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1743___r4_ports_6_10_1, string1743___r4_ports_6_10_11866, "can't open file", 15 );
DEFINE_STRING( string1742___r4_ports_6_10_1, string1742___r4_ports_6_10_11867, "call-with-input-file", 20 );
DEFINE_STRING( string1741___r4_ports_6_10_1, string1741___r4_ports_6_10_11868, "INPUT-PORT", 10 );
DEFINE_STRING( string1739___r4_ports_6_10_1, string1739___r4_ports_6_10_11869, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/port.scm", 57 );
DEFINE_STRING( string1734___r4_ports_6_10_1, string1734___r4_ports_6_10_11870, "CALL-WITH-INPUT-FILE:Wrong number of arguments", 46 );
DEFINE_EXPORT_PROCEDURE( rename_file_env_203___r4_ports_6_10_1, _rename_file1267_209___r4_ports_6_10_11871, _rename_file1267_209___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( append_output_file_env_62___r4_ports_6_10_1, _append_output_file1264_138___r4_ports_6_10_11872, _append_output_file1264_138___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( close_output_port_env_169___r4_ports_6_10_1, _close_output_port1258_204___r4_ports_6_10_11873, _close_output_port1258_204___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( output_port__env_61___r4_ports_6_10_1, _output_port__133___r4_ports_6_10_11874, _output_port__133___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( delete_directory_env_124___r4_ports_6_10_1, _delete_directory1266_20___r4_ports_6_10_11875, _delete_directory1266_20___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( with_error_to_file_env_148___r4_ports_6_10_1, _with_error_to_file1251_82___r4_ports_6_10_11876, _with_error_to_file1251_82___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( with_input_from_file_env_154___r4_ports_6_10_1, _with_input_from_file1247_95___r4_ports_6_10_11877, _with_input_from_file1247_95___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( with_output_to_file_env_30___r4_ports_6_10_1, _with_output_to_file1249_24___r4_ports_6_10_11878, _with_output_to_file1249_24___r4_ports_6_10_1, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( current_input_port_env_5___r4_ports_6_10_1, _current_input_port_198___r4_ports_6_10_11879, _current_input_port_198___r4_ports_6_10_1, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( port__env_47___r4_ports_6_10_1, _port__120___r4_ports_6_10_11880, _port__120___r4_ports_6_10_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( open_output_string_env_226___r4_ports_6_10_1, _open_output_string_243___r4_ports_6_10_11881, _open_output_string_243___r4_ports_6_10_1, 0L, 0 );


/* module-initialization */obj_t module_initialization_70___r4_ports_6_10_1(long checksum_1155, char * from_1156)
{
if(CBOOL(require_initialization_114___r4_ports_6_10_1)){
require_initialization_114___r4_ports_6_10_1 = BBOOL(((bool_t)0));
cnst_init_137___r4_ports_6_10_1();
imported_modules_init_94___r4_ports_6_10_1();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_ports_6_10_1()
{
symbol1733___r4_ports_6_10_1 = string_to_symbol("CALL-WITH-INPUT-FILE");
symbol1736___r4_ports_6_10_1 = string_to_symbol("FUNCALL");
symbol1737___r4_ports_6_10_1 = string_to_symbol("proc");
symbol1738___r4_ports_6_10_1 = string_to_symbol("port");
{
obj_t aux_1166;
{
obj_t aux_1167;
{
obj_t aux_1168;
aux_1168 = MAKE_PAIR(symbol1738___r4_ports_6_10_1, BNIL);
aux_1167 = MAKE_PAIR(symbol1737___r4_ports_6_10_1, aux_1168);
}
aux_1166 = MAKE_PAIR(symbol1737___r4_ports_6_10_1, aux_1167);
}
list1735___r4_ports_6_10_1 = MAKE_PAIR(symbol1736___r4_ports_6_10_1, aux_1166);
}
symbol1740___r4_ports_6_10_1 = string_to_symbol("_");
symbol1745___r4_ports_6_10_1 = string_to_symbol("_CALL-WITH-INPUT-FILE1245");
symbol1748___r4_ports_6_10_1 = string_to_symbol("CALL-WITH-OUTPUT-FILE");
symbol1752___r4_ports_6_10_1 = string_to_symbol("_CALL-WITH-OUTPUT-FILE1246");
symbol1753___r4_ports_6_10_1 = string_to_symbol("INPUT-PORT?");
symbol1754___r4_ports_6_10_1 = string_to_symbol("OUTPUT-PORT?");
symbol1755___r4_ports_6_10_1 = string_to_symbol("CURRENT-INPUT-PORT");
symbol1756___r4_ports_6_10_1 = string_to_symbol("CURRENT-OUTPUT-PORT");
symbol1757___r4_ports_6_10_1 = string_to_symbol("CURRENT-ERROR-PORT");
symbol1758___r4_ports_6_10_1 = string_to_symbol("WITH-INPUT-FROM-FILE");
symbol1761___r4_ports_6_10_1 = string_to_symbol("HANDLING_FUNCTION1031");
symbol1764___r4_ports_6_10_1 = string_to_symbol("thunk");
{
obj_t aux_1185;
{
obj_t aux_1186;
aux_1186 = MAKE_PAIR(symbol1764___r4_ports_6_10_1, BNIL);
aux_1185 = MAKE_PAIR(symbol1764___r4_ports_6_10_1, aux_1186);
}
list1763___r4_ports_6_10_1 = MAKE_PAIR(symbol1736___r4_ports_6_10_1, aux_1185);
}
symbol1765___r4_ports_6_10_1 = string_to_symbol("_WITH-INPUT-FROM-FILE1247");
symbol1766___r4_ports_6_10_1 = string_to_symbol("WITH-INPUT-FROM-PORT");
symbol1768___r4_ports_6_10_1 = string_to_symbol("_WITH-INPUT-FROM-PORT1248");
symbol1769___r4_ports_6_10_1 = string_to_symbol("WITH-OUTPUT-TO-FILE");
symbol1771___r4_ports_6_10_1 = string_to_symbol("HANDLING_FUNCTION1041");
symbol1773___r4_ports_6_10_1 = string_to_symbol("_WITH-OUTPUT-TO-FILE1249");
symbol1774___r4_ports_6_10_1 = string_to_symbol("WITH-OUTPUT-TO-PORT");
symbol1776___r4_ports_6_10_1 = string_to_symbol("_WITH-OUTPUT-TO-PORT1250");
symbol1777___r4_ports_6_10_1 = string_to_symbol("WITH-ERROR-TO-FILE");
symbol1779___r4_ports_6_10_1 = string_to_symbol("HANDLING_FUNCTION1050");
symbol1781___r4_ports_6_10_1 = string_to_symbol("_WITH-ERROR-TO-FILE1251");
symbol1782___r4_ports_6_10_1 = string_to_symbol("WITH-ERROR-TO-PORT");
symbol1784___r4_ports_6_10_1 = string_to_symbol("_WITH-ERROR-TO-PORT1252");
symbol1785___r4_ports_6_10_1 = string_to_symbol("OPEN-INPUT-FILE");
symbol1788___r4_ports_6_10_1 = string_to_symbol("_OPEN-INPUT-FILE1253");
symbol1789___r4_ports_6_10_1 = string_to_symbol("OPEN-INPUT-STRING");
symbol1790___r4_ports_6_10_1 = string_to_symbol("_OPEN-INPUT-STRING1254");
symbol1791___r4_ports_6_10_1 = string_to_symbol("OPEN-INPUT-C-STRING");
symbol1792___r4_ports_6_10_1 = string_to_symbol("_OPEN-INPUT-C-STRING1255");
symbol1794___r4_ports_6_10_1 = string_to_symbol("OPEN-OUTPUT-FILE");
symbol1795___r4_ports_6_10_1 = string_to_symbol("_OPEN-OUTPUT-FILE1256");
symbol1796___r4_ports_6_10_1 = string_to_symbol("OPEN-OUTPUT-STRING");
symbol1797___r4_ports_6_10_1 = string_to_symbol("CLOSE-INPUT-PORT");
symbol1798___r4_ports_6_10_1 = string_to_symbol("_CLOSE-INPUT-PORT1257");
symbol1799___r4_ports_6_10_1 = string_to_symbol("CLOSE-OUTPUT-PORT");
symbol1800___r4_ports_6_10_1 = string_to_symbol("_CLOSE-OUTPUT-PORT1258");
symbol1801___r4_ports_6_10_1 = string_to_symbol("FLUSH-OUTPUT-PORT");
symbol1802___r4_ports_6_10_1 = string_to_symbol("_FLUSH-OUTPUT-PORT1259");
symbol1803___r4_ports_6_10_1 = string_to_symbol("RESET-EOF");
symbol1804___r4_ports_6_10_1 = string_to_symbol("_RESET-EOF1260");
symbol1805___r4_ports_6_10_1 = string_to_symbol("INPUT-PORT-POSITION");
symbol1806___r4_ports_6_10_1 = string_to_symbol("_INPUT-PORT-POSITION1261");
symbol1807___r4_ports_6_10_1 = string_to_symbol("INPUT-PORT-NAME");
symbol1808___r4_ports_6_10_1 = string_to_symbol("_INPUT-PORT-NAME1262");
symbol1809___r4_ports_6_10_1 = string_to_symbol("FILE-EXISTS?");
symbol1810___r4_ports_6_10_1 = string_to_symbol("_FILE-EXISTS?1263");
symbol1811___r4_ports_6_10_1 = string_to_symbol("APPEND-OUTPUT-FILE");
symbol1812___r4_ports_6_10_1 = string_to_symbol("_APPEND-OUTPUT-FILE1264");
symbol1813___r4_ports_6_10_1 = string_to_symbol("DELETE-FILE");
symbol1814___r4_ports_6_10_1 = string_to_symbol("_DELETE-FILE1265");
symbol1815___r4_ports_6_10_1 = string_to_symbol("DELETE-DIRECTORY");
symbol1816___r4_ports_6_10_1 = string_to_symbol("_DELETE-DIRECTORY1266");
symbol1817___r4_ports_6_10_1 = string_to_symbol("RENAME-FILE");
symbol1818___r4_ports_6_10_1 = string_to_symbol("_RENAME-FILE1267");
symbol1819___r4_ports_6_10_1 = string_to_symbol("PORT?");
symbol1820___r4_ports_6_10_1 = string_to_symbol("DIRECTORY?");
symbol1821___r4_ports_6_10_1 = string_to_symbol("_DIRECTORY?1268");
symbol1822___r4_ports_6_10_1 = string_to_symbol("DIRECTORY->LIST");
symbol1823___r4_ports_6_10_1 = string_to_symbol("_DIRECTORY->LIST1269");
return (symbol1824___r4_ports_6_10_1 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* call-with-input-file */obj_t call_with_input_file_94___r4_ports_6_10_1(obj_t string_1, obj_t proc_2)
{
{
obj_t symbol1180_495;
symbol1180_495 = symbol1733___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1180_495);
BUNSPEC;
{
obj_t aux1179_496;
{
obj_t port_251;
port_251 = open_input_file_61___r4_ports_6_10_1(string_1, BNIL);
{
bool_t test1024_252;
test1024_252 = INPUT_PORTP(port_251);
if(test1024_252){
obj_t res_253;
{
bool_t test1279_650;
test1279_650 = PROCEDURE_CORRECT_ARITYP(proc_2, ((long)1));
if(test1279_650){
res_253 = PROCEDURE_ENTRY(proc_2)(proc_2, port_251, BEOA);
}
 else {
error_location_112___error(string1734___r4_ports_6_10_1, list1735___r4_ports_6_10_1, proc_2, string1739___r4_ports_6_10_1, BINT(((long)5520)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
{
obj_t port_439;
if(test1024_252){
port_439 = port_251;
}
 else {
bigloo_type_error_location_103___error(symbol1733___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_251, string1739___r4_ports_6_10_1, BINT(((long)5541)));
exit( -1 );}
close_input_port(port_439);
}
aux1179_496 = res_253;
}
 else {
aux1179_496 = debug_error_location_199___error(string1742___r4_ports_6_10_1, string1743___r4_ports_6_10_1, string_1, string1744___r4_ports_6_10_1, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1179_496;
}
}
}
}


/* _call-with-input-file1245 */obj_t _call_with_input_file1245_143___r4_ports_6_10_1(obj_t env_561, obj_t string_562, obj_t proc_563)
{
{
obj_t aux_1265;
obj_t aux_1259;
if(PROCEDUREP(proc_563)){
aux_1265 = proc_563;
}
 else {
bigloo_type_error_location_103___error(symbol1745___r4_ports_6_10_1, string1747___r4_ports_6_10_1, proc_563, string1739___r4_ports_6_10_1, BINT(((long)5392)));
exit( -1 );}
if(STRINGP(string_562)){
aux_1259 = string_562;
}
 else {
bigloo_type_error_location_103___error(symbol1745___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_562, string1739___r4_ports_6_10_1, BINT(((long)5392)));
exit( -1 );}
return call_with_input_file_94___r4_ports_6_10_1(aux_1259, aux_1265);
}
}


/* call-with-output-file */obj_t call_with_output_file_65___r4_ports_6_10_1(obj_t string_3, obj_t proc_4)
{
{
obj_t symbol1182_497;
symbol1182_497 = symbol1748___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1182_497);
BUNSPEC;
{
obj_t aux1181_498;
{
obj_t port_443;
port_443 = open_output_file(string_3);
{
bool_t test1026_444;
test1026_444 = OUTPUT_PORTP(port_443);
if(test1026_444){
obj_t res_445;
{
bool_t test1305_676;
test1305_676 = PROCEDURE_CORRECT_ARITYP(proc_4, ((long)1));
if(test1305_676){
res_445 = PROCEDURE_ENTRY(proc_4)(proc_4, port_443, BEOA);
}
 else {
error_location_112___error(string1749___r4_ports_6_10_1, list1735___r4_ports_6_10_1, proc_4, string1739___r4_ports_6_10_1, BINT(((long)5992)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
{
obj_t port_448;
if(test1026_444){
port_448 = port_443;
}
 else {
bigloo_type_error_location_103___error(symbol1748___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_443, string1739___r4_ports_6_10_1, BINT(((long)6013)));
exit( -1 );}
close_output_port(port_448);
}
aux1181_498 = res_445;
}
 else {
aux1181_498 = debug_error_location_199___error(string1751___r4_ports_6_10_1, string1743___r4_ports_6_10_1, string_3, string1744___r4_ports_6_10_1, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1181_498;
}
}
}
}


/* _call-with-output-file1246 */obj_t _call_with_output_file1246_210___r4_ports_6_10_1(obj_t env_564, obj_t string_565, obj_t proc_566)
{
{
obj_t aux_1297;
obj_t aux_1291;
if(PROCEDUREP(proc_566)){
aux_1297 = proc_566;
}
 else {
bigloo_type_error_location_103___error(symbol1752___r4_ports_6_10_1, string1747___r4_ports_6_10_1, proc_566, string1739___r4_ports_6_10_1, BINT(((long)5860)));
exit( -1 );}
if(STRINGP(string_565)){
aux_1291 = string_565;
}
 else {
bigloo_type_error_location_103___error(symbol1752___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_565, string1739___r4_ports_6_10_1, BINT(((long)5860)));
exit( -1 );}
return call_with_output_file_65___r4_ports_6_10_1(aux_1291, aux_1297);
}
}


/* input-port? */obj_t input_port__135___r4_ports_6_10_1(obj_t obj_5)
{
{
obj_t symbol1184_1037;
symbol1184_1037 = symbol1753___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1184_1037);
BUNSPEC;
{
obj_t aux1183_1038;
{
bool_t aux_1305;
aux_1305 = INPUT_PORTP(obj_5);
aux1183_1038 = BBOOL(aux_1305);
}
POP_TRACE();
return aux1183_1038;
}
}
}
}


/* _input-port? */obj_t _input_port__169___r4_ports_6_10_1(obj_t env_567, obj_t obj_568)
{
{
obj_t obj_1039;
obj_1039 = obj_568;
{
obj_t symbol1184_1040;
symbol1184_1040 = symbol1753___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1184_1040);
BUNSPEC;
{
obj_t aux1183_1041;
{
bool_t aux_1310;
aux_1310 = INPUT_PORTP(obj_1039);
aux1183_1041 = BBOOL(aux_1310);
}
POP_TRACE();
return aux1183_1041;
}
}
}
}
}


/* output-port? */obj_t output_port__47___r4_ports_6_10_1(obj_t obj_6)
{
{
obj_t symbol1186_1042;
symbol1186_1042 = symbol1754___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1186_1042);
BUNSPEC;
{
obj_t aux1185_1043;
{
bool_t aux_1315;
aux_1315 = OUTPUT_PORTP(obj_6);
aux1185_1043 = BBOOL(aux_1315);
}
POP_TRACE();
return aux1185_1043;
}
}
}
}


/* _output-port? */obj_t _output_port__133___r4_ports_6_10_1(obj_t env_569, obj_t obj_570)
{
{
obj_t obj_1044;
obj_1044 = obj_570;
{
obj_t symbol1186_1045;
symbol1186_1045 = symbol1754___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1186_1045);
BUNSPEC;
{
obj_t aux1185_1046;
{
bool_t aux_1320;
aux_1320 = OUTPUT_PORTP(obj_1044);
aux1185_1046 = BBOOL(aux_1320);
}
POP_TRACE();
return aux1185_1046;
}
}
}
}
}


/* current-input-port */obj_t current_input_port_104___r4_ports_6_10_1()
{
{
obj_t symbol1188_1047;
symbol1188_1047 = symbol1755___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1188_1047);
BUNSPEC;
{
obj_t aux1187_1048;
aux1187_1048 = current_input_port;
POP_TRACE();
return aux1187_1048;
}
}
}
}


/* _current-input-port */obj_t _current_input_port_198___r4_ports_6_10_1(obj_t env_571)
{
{
obj_t symbol1188_1049;
symbol1188_1049 = symbol1755___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1188_1049);
BUNSPEC;
{
obj_t aux1187_1050;
aux1187_1050 = current_input_port;
POP_TRACE();
return aux1187_1050;
}
}
}
}


/* current-output-port */obj_t current_output_port_239___r4_ports_6_10_1()
{
{
obj_t symbol1190_1051;
symbol1190_1051 = symbol1756___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1190_1051);
BUNSPEC;
{
obj_t aux1189_1052;
aux1189_1052 = current_output_port;
POP_TRACE();
return aux1189_1052;
}
}
}
}


/* _current-output-port */obj_t _current_output_port_118___r4_ports_6_10_1(obj_t env_572)
{
{
obj_t symbol1190_1053;
symbol1190_1053 = symbol1756___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1190_1053);
BUNSPEC;
{
obj_t aux1189_1054;
aux1189_1054 = current_output_port;
POP_TRACE();
return aux1189_1054;
}
}
}
}


/* current-error-port */obj_t current_error_port_17___r4_ports_6_10_1()
{
{
obj_t symbol1192_1055;
symbol1192_1055 = symbol1757___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1192_1055);
BUNSPEC;
{
obj_t aux1191_1056;
aux1191_1056 = current_error_port;
POP_TRACE();
return aux1191_1056;
}
}
}
}


/* _current-error-port */obj_t _current_error_port_229___r4_ports_6_10_1(obj_t env_573)
{
{
obj_t symbol1192_1057;
symbol1192_1057 = symbol1757___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1192_1057);
BUNSPEC;
{
obj_t aux1191_1058;
aux1191_1058 = current_error_port;
POP_TRACE();
return aux1191_1058;
}
}
}
}


/* with-input-from-file */obj_t with_input_from_file_180___r4_ports_6_10_1(obj_t string_7, obj_t thunk_8)
{
{
obj_t symbol1194_509;
symbol1194_509 = symbol1758___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1194_509);
BUNSPEC;
{
obj_t aux1193_510;
{
obj_t port_258;
port_258 = open_input_file_61___r4_ports_6_10_1(string_7, BNIL);
{
bool_t test1027_259;
test1027_259 = INPUT_PORTP(port_258);
if(test1027_259){
obj_t old_input_port_89_260;
old_input_port_89_260 = current_input_port;
{
obj_t val1002_261;
val1002_261 = handling_function1031___r4_ports_6_10_1(thunk_8, port_258);
current_input_port = old_input_port_89_260;
{
obj_t port_453;
if(test1027_259){
port_453 = port_258;
}
 else {
bigloo_type_error_location_103___error(symbol1758___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_258, string1739___r4_ports_6_10_1, BINT(((long)8059)));
exit( -1 );}
close_input_port(port_453);
}
{
bool_t test1028_262;
{
obj_t aux_1346;
aux_1346 = val_from_exit__100___bexit(val1002_261);
test1028_262 = CBOOL(aux_1346);
}
if(test1028_262){
obj_t arg1029_263;
obj_t arg1030_264;
{
obj_t pair_454;
if(PAIRP(val1002_261)){
pair_454 = val1002_261;
}
 else {
bigloo_type_error_location_103___error(symbol1758___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1002_261, string1739___r4_ports_6_10_1, BINT(((long)8058)));
exit( -1 );}
arg1029_263 = CAR(pair_454);
}
{
obj_t pair_455;
if(PAIRP(val1002_261)){
pair_455 = val1002_261;
}
 else {
bigloo_type_error_location_103___error(symbol1758___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1002_261, string1739___r4_ports_6_10_1, BINT(((long)8058)));
exit( -1 );}
arg1030_264 = CDR(pair_455);
}
aux1193_510 = unwind_until__178___bexit(arg1029_263, arg1030_264);
}
 else {
aux1193_510 = val1002_261;
}
}
}
}
 else {
aux1193_510 = debug_error_location_199___error(string1760___r4_ports_6_10_1, string1743___r4_ports_6_10_1, string_7, string1744___r4_ports_6_10_1, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1193_510;
}
}
}
}


/* handling_function1031 */obj_t handling_function1031___r4_ports_6_10_1(obj_t thunk_642, obj_t port_641)
{
jmp_buf jmpbuf;
obj_t an_exit1003_266;
if( SET_EXIT(an_exit1003_266) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1003_266 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1003_266, ((bool_t)0));
{
obj_t val1004_267;
if(INPUT_PORTP(port_641)){
current_input_port = port_641;
}
 else {
bigloo_type_error_location_103___error(symbol1761___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_641, string1739___r4_ports_6_10_1, BINT(((long)7949)));
exit( -1 );}
{
bool_t test1368_726;
test1368_726 = PROCEDURE_CORRECT_ARITYP(thunk_642, ((long)0));
if(test1368_726){
val1004_267 = PROCEDURE_ENTRY(thunk_642)(thunk_642, BEOA);
}
 else {
error_location_112___error(string1762___r4_ports_6_10_1, list1763___r4_ports_6_10_1, thunk_642, string1739___r4_ports_6_10_1, BINT(((long)7987)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
POP_EXIT();
return val1004_267;
}
}
}
}


/* _with-input-from-file1247 */obj_t _with_input_from_file1247_95___r4_ports_6_10_1(obj_t env_574, obj_t string_575, obj_t thunk_576)
{
{
obj_t aux_1388;
obj_t aux_1382;
if(PROCEDUREP(thunk_576)){
aux_1388 = thunk_576;
}
 else {
bigloo_type_error_location_103___error(symbol1765___r4_ports_6_10_1, string1747___r4_ports_6_10_1, thunk_576, string1739___r4_ports_6_10_1, BINT(((long)7750)));
exit( -1 );}
if(STRINGP(string_575)){
aux_1382 = string_575;
}
 else {
bigloo_type_error_location_103___error(symbol1765___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_575, string1739___r4_ports_6_10_1, BINT(((long)7750)));
exit( -1 );}
return with_input_from_file_180___r4_ports_6_10_1(aux_1382, aux_1388);
}
}


/* with-input-from-port */obj_t with_input_from_port_242___r4_ports_6_10_1(obj_t port_9, obj_t thunk_10)
{
{
obj_t symbol1196_511;
symbol1196_511 = symbol1766___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1196_511);
BUNSPEC;
{
obj_t aux1195_512;
{
obj_t old_input_port_89_269;
old_input_port_89_269 = current_input_port;
{
obj_t val1005_270;
val1005_270 = handling_function1036___r4_ports_6_10_1(thunk_10, port_9);
current_input_port = old_input_port_89_269;
{
bool_t test1033_271;
{
obj_t aux_1397;
aux_1397 = val_from_exit__100___bexit(val1005_270);
test1033_271 = CBOOL(aux_1397);
}
if(test1033_271){
obj_t arg1034_272;
obj_t arg1035_273;
{
obj_t pair_459;
if(PAIRP(val1005_270)){
pair_459 = val1005_270;
}
 else {
bigloo_type_error_location_103___error(symbol1766___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1005_270, string1739___r4_ports_6_10_1, BINT(((long)8545)));
exit( -1 );}
arg1034_272 = CAR(pair_459);
}
{
obj_t pair_460;
if(PAIRP(val1005_270)){
pair_460 = val1005_270;
}
 else {
bigloo_type_error_location_103___error(symbol1766___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1005_270, string1739___r4_ports_6_10_1, BINT(((long)8545)));
exit( -1 );}
arg1035_273 = CDR(pair_460);
}
aux1195_512 = unwind_until__178___bexit(arg1034_272, arg1035_273);
}
 else {
aux1195_512 = val1005_270;
}
}
}
}
POP_TRACE();
return aux1195_512;
}
}
}
}


/* handling_function1036 */obj_t handling_function1036___r4_ports_6_10_1(obj_t thunk_640, obj_t port_639)
{
jmp_buf jmpbuf;
obj_t an_exit1006_275;
if( SET_EXIT(an_exit1006_275) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1006_275 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1006_275, ((bool_t)0));
{
obj_t val1007_276;
current_input_port = port_639;
{
bool_t test1408_758;
test1408_758 = PROCEDURE_CORRECT_ARITYP(thunk_640, ((long)0));
if(test1408_758){
val1007_276 = PROCEDURE_ENTRY(thunk_640)(thunk_640, BEOA);
}
 else {
error_location_112___error(string1767___r4_ports_6_10_1, list1763___r4_ports_6_10_1, thunk_640, string1739___r4_ports_6_10_1, BINT(((long)8534)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
POP_EXIT();
return val1007_276;
}
}
}
}


/* _with-input-from-port1248 */obj_t _with_input_from_port1248_1___r4_ports_6_10_1(obj_t env_577, obj_t port_578, obj_t thunk_579)
{
{
obj_t aux_1432;
obj_t aux_1426;
if(PROCEDUREP(thunk_579)){
aux_1432 = thunk_579;
}
 else {
bigloo_type_error_location_103___error(symbol1768___r4_ports_6_10_1, string1747___r4_ports_6_10_1, thunk_579, string1739___r4_ports_6_10_1, BINT(((long)8370)));
exit( -1 );}
if(INPUT_PORTP(port_578)){
aux_1426 = port_578;
}
 else {
bigloo_type_error_location_103___error(symbol1768___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_578, string1739___r4_ports_6_10_1, BINT(((long)8370)));
exit( -1 );}
return with_input_from_port_242___r4_ports_6_10_1(aux_1426, aux_1432);
}
}


/* with-output-to-file */obj_t with_output_to_file_237___r4_ports_6_10_1(obj_t string_11, obj_t thunk_12)
{
{
obj_t symbol1198_513;
symbol1198_513 = symbol1769___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1198_513);
BUNSPEC;
{
obj_t aux1197_514;
{
obj_t port_277;
port_277 = open_output_file(string_11);
{
bool_t test1037_278;
test1037_278 = OUTPUT_PORTP(port_277);
if(test1037_278){
obj_t old_output_port_232_279;
old_output_port_232_279 = current_output_port;
{
obj_t val1008_280;
val1008_280 = handling_function1041___r4_ports_6_10_1(thunk_12, port_277);
current_output_port = old_output_port_232_279;
{
obj_t port_463;
if(test1037_278){
port_463 = port_277;
}
 else {
bigloo_type_error_location_103___error(symbol1769___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_277, string1739___r4_ports_6_10_1, BINT(((long)9129)));
exit( -1 );}
close_output_port(port_463);
}
{
bool_t test1038_281;
{
obj_t aux_1449;
aux_1449 = val_from_exit__100___bexit(val1008_280);
test1038_281 = CBOOL(aux_1449);
}
if(test1038_281){
obj_t arg1039_282;
obj_t arg1040_283;
{
obj_t pair_464;
if(PAIRP(val1008_280)){
pair_464 = val1008_280;
}
 else {
bigloo_type_error_location_103___error(symbol1769___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1008_280, string1739___r4_ports_6_10_1, BINT(((long)9128)));
exit( -1 );}
arg1039_282 = CAR(pair_464);
}
{
obj_t pair_465;
if(PAIRP(val1008_280)){
pair_465 = val1008_280;
}
 else {
bigloo_type_error_location_103___error(symbol1769___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1008_280, string1739___r4_ports_6_10_1, BINT(((long)9128)));
exit( -1 );}
arg1040_283 = CDR(pair_465);
}
aux1197_514 = unwind_until__178___bexit(arg1039_282, arg1040_283);
}
 else {
aux1197_514 = val1008_280;
}
}
}
}
 else {
aux1197_514 = debug_error_location_199___error(string1770___r4_ports_6_10_1, string1743___r4_ports_6_10_1, string_11, string1744___r4_ports_6_10_1, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1197_514;
}
}
}
}


/* handling_function1041 */obj_t handling_function1041___r4_ports_6_10_1(obj_t thunk_638, obj_t port_637)
{
jmp_buf jmpbuf;
obj_t an_exit1009_285;
if( SET_EXIT(an_exit1009_285) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1009_285 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1009_285, ((bool_t)0));
{
obj_t val1010_286;
if(OUTPUT_PORTP(port_637)){
current_output_port = port_637;
}
 else {
bigloo_type_error_location_103___error(symbol1771___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_637, string1739___r4_ports_6_10_1, BINT(((long)9016)));
exit( -1 );}
{
bool_t test1465_802;
test1465_802 = PROCEDURE_CORRECT_ARITYP(thunk_638, ((long)0));
if(test1465_802){
val1010_286 = PROCEDURE_ENTRY(thunk_638)(thunk_638, BEOA);
}
 else {
error_location_112___error(string1772___r4_ports_6_10_1, list1763___r4_ports_6_10_1, thunk_638, string1739___r4_ports_6_10_1, BINT(((long)9055)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
POP_EXIT();
return val1010_286;
}
}
}
}


/* _with-output-to-file1249 */obj_t _with_output_to_file1249_24___r4_ports_6_10_1(obj_t env_580, obj_t string_581, obj_t thunk_582)
{
{
obj_t aux_1491;
obj_t aux_1485;
if(PROCEDUREP(thunk_582)){
aux_1491 = thunk_582;
}
 else {
bigloo_type_error_location_103___error(symbol1773___r4_ports_6_10_1, string1747___r4_ports_6_10_1, thunk_582, string1739___r4_ports_6_10_1, BINT(((long)8814)));
exit( -1 );}
if(STRINGP(string_581)){
aux_1485 = string_581;
}
 else {
bigloo_type_error_location_103___error(symbol1773___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_581, string1739___r4_ports_6_10_1, BINT(((long)8814)));
exit( -1 );}
return with_output_to_file_237___r4_ports_6_10_1(aux_1485, aux_1491);
}
}


/* with-output-to-port */obj_t with_output_to_port_151___r4_ports_6_10_1(obj_t port_13, obj_t thunk_14)
{
{
obj_t symbol1200_515;
symbol1200_515 = symbol1774___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1200_515);
BUNSPEC;
{
obj_t aux1199_516;
{
obj_t old_output_port_232_287;
old_output_port_232_287 = current_output_port;
{
obj_t val1011_288;
val1011_288 = handling_function1045___r4_ports_6_10_1(thunk_14, port_13);
current_output_port = old_output_port_232_287;
{
bool_t test1042_289;
{
obj_t aux_1500;
aux_1500 = val_from_exit__100___bexit(val1011_288);
test1042_289 = CBOOL(aux_1500);
}
if(test1042_289){
obj_t arg1043_290;
obj_t arg1044_291;
{
obj_t pair_469;
if(PAIRP(val1011_288)){
pair_469 = val1011_288;
}
 else {
bigloo_type_error_location_103___error(symbol1774___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1011_288, string1739___r4_ports_6_10_1, BINT(((long)9617)));
exit( -1 );}
arg1043_290 = CAR(pair_469);
}
{
obj_t pair_470;
if(PAIRP(val1011_288)){
pair_470 = val1011_288;
}
 else {
bigloo_type_error_location_103___error(symbol1774___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1011_288, string1739___r4_ports_6_10_1, BINT(((long)9617)));
exit( -1 );}
arg1044_291 = CDR(pair_470);
}
aux1199_516 = unwind_until__178___bexit(arg1043_290, arg1044_291);
}
 else {
aux1199_516 = val1011_288;
}
}
}
}
POP_TRACE();
return aux1199_516;
}
}
}
}


/* handling_function1045 */obj_t handling_function1045___r4_ports_6_10_1(obj_t thunk_636, obj_t port_635)
{
jmp_buf jmpbuf;
obj_t an_exit1012_293;
if( SET_EXIT(an_exit1012_293) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1012_293 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1012_293, ((bool_t)0));
{
obj_t val1013_294;
current_output_port = port_635;
{
bool_t test1500_834;
test1500_834 = PROCEDURE_CORRECT_ARITYP(thunk_636, ((long)0));
if(test1500_834){
val1013_294 = PROCEDURE_ENTRY(thunk_636)(thunk_636, BEOA);
}
 else {
error_location_112___error(string1775___r4_ports_6_10_1, list1763___r4_ports_6_10_1, thunk_636, string1739___r4_ports_6_10_1, BINT(((long)9606)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
POP_EXIT();
return val1013_294;
}
}
}
}


/* _with-output-to-port1250 */obj_t _with_output_to_port1250_24___r4_ports_6_10_1(obj_t env_583, obj_t port_584, obj_t thunk_585)
{
{
obj_t aux_1535;
obj_t aux_1529;
if(PROCEDUREP(thunk_585)){
aux_1535 = thunk_585;
}
 else {
bigloo_type_error_location_103___error(symbol1776___r4_ports_6_10_1, string1747___r4_ports_6_10_1, thunk_585, string1739___r4_ports_6_10_1, BINT(((long)9440)));
exit( -1 );}
if(OUTPUT_PORTP(port_584)){
aux_1529 = port_584;
}
 else {
bigloo_type_error_location_103___error(symbol1776___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_584, string1739___r4_ports_6_10_1, BINT(((long)9440)));
exit( -1 );}
return with_output_to_port_151___r4_ports_6_10_1(aux_1529, aux_1535);
}
}


/* with-error-to-file */obj_t with_error_to_file_201___r4_ports_6_10_1(obj_t string_15, obj_t thunk_16)
{
{
obj_t symbol1202_517;
symbol1202_517 = symbol1777___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1202_517);
BUNSPEC;
{
obj_t aux1201_518;
{
obj_t port_295;
port_295 = open_output_file(string_15);
{
bool_t test1046_296;
test1046_296 = OUTPUT_PORTP(port_295);
if(test1046_296){
obj_t old_output_port_232_297;
old_output_port_232_297 = current_error_port;
{
obj_t val1014_298;
val1014_298 = handling_function1050___r4_ports_6_10_1(thunk_16, port_295);
current_error_port = old_output_port_232_297;
{
obj_t port_473;
if(test1046_296){
port_473 = port_295;
}
 else {
bigloo_type_error_location_103___error(symbol1777___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_295, string1739___r4_ports_6_10_1, BINT(((long)10199)));
exit( -1 );}
close_output_port(port_473);
}
{
bool_t test1047_299;
{
obj_t aux_1552;
aux_1552 = val_from_exit__100___bexit(val1014_298);
test1047_299 = CBOOL(aux_1552);
}
if(test1047_299){
obj_t arg1048_300;
obj_t arg1049_301;
{
obj_t pair_474;
if(PAIRP(val1014_298)){
pair_474 = val1014_298;
}
 else {
bigloo_type_error_location_103___error(symbol1777___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1014_298, string1739___r4_ports_6_10_1, BINT(((long)10198)));
exit( -1 );}
arg1048_300 = CAR(pair_474);
}
{
obj_t pair_475;
if(PAIRP(val1014_298)){
pair_475 = val1014_298;
}
 else {
bigloo_type_error_location_103___error(symbol1777___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1014_298, string1739___r4_ports_6_10_1, BINT(((long)10198)));
exit( -1 );}
arg1049_301 = CDR(pair_475);
}
aux1201_518 = unwind_until__178___bexit(arg1048_300, arg1049_301);
}
 else {
aux1201_518 = val1014_298;
}
}
}
}
 else {
aux1201_518 = debug_error_location_199___error(string1778___r4_ports_6_10_1, string1743___r4_ports_6_10_1, string_15, string1744___r4_ports_6_10_1, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1201_518;
}
}
}
}


/* handling_function1050 */obj_t handling_function1050___r4_ports_6_10_1(obj_t thunk_634, obj_t port_633)
{
jmp_buf jmpbuf;
obj_t an_exit1015_303;
if( SET_EXIT(an_exit1015_303) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1015_303 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1015_303, ((bool_t)0));
{
obj_t val1016_304;
if(OUTPUT_PORTP(port_633)){
current_error_port = port_633;
}
 else {
bigloo_type_error_location_103___error(symbol1779___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_633, string1739___r4_ports_6_10_1, BINT(((long)10088)));
exit( -1 );}
{
bool_t test1553_878;
test1553_878 = PROCEDURE_CORRECT_ARITYP(thunk_634, ((long)0));
if(test1553_878){
val1016_304 = PROCEDURE_ENTRY(thunk_634)(thunk_634, BEOA);
}
 else {
error_location_112___error(string1780___r4_ports_6_10_1, list1763___r4_ports_6_10_1, thunk_634, string1739___r4_ports_6_10_1, BINT(((long)10126)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
POP_EXIT();
return val1016_304;
}
}
}
}


/* _with-error-to-file1251 */obj_t _with_error_to_file1251_82___r4_ports_6_10_1(obj_t env_586, obj_t string_587, obj_t thunk_588)
{
{
obj_t aux_1594;
obj_t aux_1588;
if(PROCEDUREP(thunk_588)){
aux_1594 = thunk_588;
}
 else {
bigloo_type_error_location_103___error(symbol1781___r4_ports_6_10_1, string1747___r4_ports_6_10_1, thunk_588, string1739___r4_ports_6_10_1, BINT(((long)9888)));
exit( -1 );}
if(STRINGP(string_587)){
aux_1588 = string_587;
}
 else {
bigloo_type_error_location_103___error(symbol1781___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_587, string1739___r4_ports_6_10_1, BINT(((long)9888)));
exit( -1 );}
return with_error_to_file_201___r4_ports_6_10_1(aux_1588, aux_1594);
}
}


/* with-error-to-port */obj_t with_error_to_port_5___r4_ports_6_10_1(obj_t port_17, obj_t thunk_18)
{
{
obj_t symbol1204_519;
symbol1204_519 = symbol1782___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1204_519);
BUNSPEC;
{
obj_t aux1203_520;
{
obj_t old_output_port_232_305;
old_output_port_232_305 = current_error_port;
{
obj_t val1017_306;
val1017_306 = handling_function1055___r4_ports_6_10_1(thunk_18, port_17);
current_error_port = old_output_port_232_305;
{
bool_t test1051_307;
{
obj_t aux_1603;
aux_1603 = val_from_exit__100___bexit(val1017_306);
test1051_307 = CBOOL(aux_1603);
}
if(test1051_307){
obj_t arg1053_308;
obj_t arg1054_309;
{
obj_t pair_479;
if(PAIRP(val1017_306)){
pair_479 = val1017_306;
}
 else {
bigloo_type_error_location_103___error(symbol1782___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1017_306, string1739___r4_ports_6_10_1, BINT(((long)10683)));
exit( -1 );}
arg1053_308 = CAR(pair_479);
}
{
obj_t pair_480;
if(PAIRP(val1017_306)){
pair_480 = val1017_306;
}
 else {
bigloo_type_error_location_103___error(symbol1782___r4_ports_6_10_1, string1759___r4_ports_6_10_1, val1017_306, string1739___r4_ports_6_10_1, BINT(((long)10683)));
exit( -1 );}
arg1054_309 = CDR(pair_480);
}
aux1203_520 = unwind_until__178___bexit(arg1053_308, arg1054_309);
}
 else {
aux1203_520 = val1017_306;
}
}
}
}
POP_TRACE();
return aux1203_520;
}
}
}
}


/* handling_function1055 */obj_t handling_function1055___r4_ports_6_10_1(obj_t thunk_632, obj_t port_631)
{
jmp_buf jmpbuf;
obj_t an_exit1018_311;
if( SET_EXIT(an_exit1018_311) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1018_311 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1018_311, ((bool_t)0));
{
obj_t val1019_312;
current_error_port = port_631;
{
bool_t test1588_910;
test1588_910 = PROCEDURE_CORRECT_ARITYP(thunk_632, ((long)0));
if(test1588_910){
val1019_312 = PROCEDURE_ENTRY(thunk_632)(thunk_632, BEOA);
}
 else {
error_location_112___error(string1783___r4_ports_6_10_1, list1763___r4_ports_6_10_1, thunk_632, string1739___r4_ports_6_10_1, BINT(((long)10672)));
FAILURE(symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1,symbol1740___r4_ports_6_10_1);}
}
POP_EXIT();
return val1019_312;
}
}
}
}


/* _with-error-to-port1252 */obj_t _with_error_to_port1252_161___r4_ports_6_10_1(obj_t env_589, obj_t port_590, obj_t thunk_591)
{
{
obj_t aux_1638;
obj_t aux_1632;
if(PROCEDUREP(thunk_591)){
aux_1638 = thunk_591;
}
 else {
bigloo_type_error_location_103___error(symbol1784___r4_ports_6_10_1, string1747___r4_ports_6_10_1, thunk_591, string1739___r4_ports_6_10_1, BINT(((long)10509)));
exit( -1 );}
if(OUTPUT_PORTP(port_590)){
aux_1632 = port_590;
}
 else {
bigloo_type_error_location_103___error(symbol1784___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_590, string1739___r4_ports_6_10_1, BINT(((long)10509)));
exit( -1 );}
return with_error_to_port_5___r4_ports_6_10_1(aux_1632, aux_1638);
}
}


/* open-input-file */obj_t open_input_file_61___r4_ports_6_10_1(obj_t string_19, obj_t bufsiz_20)
{
{
obj_t symbol1206_521;
symbol1206_521 = symbol1785___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1206_521);
BUNSPEC;
{
obj_t aux1205_522;
{
obj_t size_313;
if(NULLP(bufsiz_20)){
size_313 = BINT(default_io_bufsiz);
}
 else {
obj_t pair_482;
if(PAIRP(bufsiz_20)){
pair_482 = bufsiz_20;
}
 else {
bigloo_type_error_location_103___error(symbol1785___r4_ports_6_10_1, string1759___r4_ports_6_10_1, bufsiz_20, string1739___r4_ports_6_10_1, BINT(((long)11060)));
exit( -1 );}
size_313 = CAR(pair_482);
}
if(INTEGERP(size_313)){
aux1205_522 = open_input_file(string_19, size_313);
}
 else {
aux1205_522 = debug_error_location_199___error(string1786___r4_ports_6_10_1, string1787___r4_ports_6_10_1, size_313, string1744___r4_ports_6_10_1, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1205_522;
}
}
}
}


/* _open-input-file1253 */obj_t _open_input_file1253_207___r4_ports_6_10_1(obj_t env_592, obj_t string_593, obj_t bufsiz_594)
{
{
obj_t aux_1661;
if(STRINGP(string_593)){
aux_1661 = string_593;
}
 else {
bigloo_type_error_location_103___error(symbol1788___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_593, string1739___r4_ports_6_10_1, BINT(((long)10953)));
exit( -1 );}
return open_input_file_61___r4_ports_6_10_1(aux_1661, bufsiz_594);
}
}


/* open-input-string */obj_t open_input_string_20___r4_ports_6_10_1(obj_t string_21)
{
{
obj_t symbol1208_1059;
symbol1208_1059 = symbol1789___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1208_1059);
BUNSPEC;
{
obj_t aux1207_1060;
aux1207_1060 = open_input_string(string_21);
POP_TRACE();
return aux1207_1060;
}
}
}
}


/* _open-input-string1254 */obj_t _open_input_string1254_138___r4_ports_6_10_1(obj_t env_595, obj_t string_596)
{
{
obj_t string_1061;
if(STRINGP(string_596)){
string_1061 = string_596;
}
 else {
bigloo_type_error_location_103___error(symbol1790___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_596, string1739___r4_ports_6_10_1, BINT(((long)11417)));
exit( -1 );}
{
obj_t symbol1208_1062;
symbol1208_1062 = symbol1789___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1208_1062);
BUNSPEC;
{
obj_t aux1207_1063;
aux1207_1063 = open_input_string(string_1061);
POP_TRACE();
return aux1207_1063;
}
}
}
}
}


/* open-input-c-string */obj_t open_input_c_string_190___r4_ports_6_10_1(char * string_22)
{
{
obj_t symbol1210_1064;
symbol1210_1064 = symbol1791___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1210_1064);
BUNSPEC;
{
obj_t aux1209_1065;
aux1209_1065 = open_input_c_string(string_22);
POP_TRACE();
return aux1209_1065;
}
}
}
}


/* _open-input-c-string1255 */obj_t _open_input_c_string1255_105___r4_ports_6_10_1(obj_t env_597, obj_t string_598)
{
{
char * string_1066;
{
obj_t aux_1682;
if(STRINGP(string_598)){
aux_1682 = string_598;
}
 else {
bigloo_type_error_location_103___error(symbol1792___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string_598, string1739___r4_ports_6_10_1, BINT(((long)11715)));
exit( -1 );}
string_1066 = BSTRING_TO_STRING(aux_1682);
}
{
obj_t symbol1210_1067;
symbol1210_1067 = symbol1791___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1210_1067);
BUNSPEC;
{
obj_t aux1209_1068;
aux1209_1068 = open_input_c_string(string_1066);
POP_TRACE();
return aux1209_1068;
}
}
}
}
}


/* open-output-file */obj_t open_output_file_240___r4_ports_6_10_1(obj_t string_23)
{
{
obj_t symbol1212_1069;
symbol1212_1069 = symbol1794___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1212_1069);
BUNSPEC;
{
obj_t aux1211_1070;
aux1211_1070 = open_output_file(string_23);
POP_TRACE();
return aux1211_1070;
}
}
}
}


/* _open-output-file1256 */obj_t _open_output_file1256_162___r4_ports_6_10_1(obj_t env_599, obj_t string_600)
{
{
obj_t string_1071;
if(STRINGP(string_600)){
string_1071 = string_600;
}
 else {
bigloo_type_error_location_103___error(symbol1795___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_600, string1739___r4_ports_6_10_1, BINT(((long)12017)));
exit( -1 );}
{
obj_t symbol1212_1072;
symbol1212_1072 = symbol1794___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1212_1072);
BUNSPEC;
{
obj_t aux1211_1073;
aux1211_1073 = open_output_file(string_1071);
POP_TRACE();
return aux1211_1073;
}
}
}
}
}


/* open-output-string */obj_t open_output_string_81___r4_ports_6_10_1()
{
{
obj_t symbol1214_1074;
symbol1214_1074 = symbol1796___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1214_1074);
BUNSPEC;
{
obj_t aux1213_1075;
aux1213_1075 = open_output_string();
POP_TRACE();
return aux1213_1075;
}
}
}
}


/* _open-output-string */obj_t _open_output_string_243___r4_ports_6_10_1(obj_t env_601)
{
{
obj_t symbol1214_1076;
symbol1214_1076 = symbol1796___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1214_1076);
BUNSPEC;
{
obj_t aux1213_1077;
aux1213_1077 = open_output_string();
POP_TRACE();
return aux1213_1077;
}
}
}
}


/* close-input-port */obj_t close_input_port_142___r4_ports_6_10_1(obj_t port_24)
{
{
obj_t symbol1216_1078;
symbol1216_1078 = symbol1797___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1216_1078);
BUNSPEC;
{
obj_t aux1215_1079;
aux1215_1079 = close_input_port(port_24);
POP_TRACE();
return aux1215_1079;
}
}
}
}


/* _close-input-port1257 */obj_t _close_input_port1257_162___r4_ports_6_10_1(obj_t env_602, obj_t port_603)
{
{
obj_t port_1080;
if(INPUT_PORTP(port_603)){
port_1080 = port_603;
}
 else {
bigloo_type_error_location_103___error(symbol1798___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_603, string1739___r4_ports_6_10_1, BINT(((long)12599)));
exit( -1 );}
{
obj_t symbol1216_1081;
symbol1216_1081 = symbol1797___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1216_1081);
BUNSPEC;
{
obj_t aux1215_1082;
aux1215_1082 = close_input_port(port_1080);
POP_TRACE();
return aux1215_1082;
}
}
}
}
}


/* close-output-port */obj_t close_output_port_77___r4_ports_6_10_1(obj_t port_25)
{
{
obj_t symbol1218_1083;
symbol1218_1083 = symbol1799___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1218_1083);
BUNSPEC;
{
obj_t aux1217_1084;
aux1217_1084 = close_output_port(port_25);
POP_TRACE();
return aux1217_1084;
}
}
}
}


/* _close-output-port1258 */obj_t _close_output_port1258_204___r4_ports_6_10_1(obj_t env_604, obj_t port_605)
{
{
obj_t port_1085;
if(OUTPUT_PORTP(port_605)){
port_1085 = port_605;
}
 else {
bigloo_type_error_location_103___error(symbol1800___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_605, string1739___r4_ports_6_10_1, BINT(((long)12891)));
exit( -1 );}
{
obj_t symbol1218_1086;
symbol1218_1086 = symbol1799___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1218_1086);
BUNSPEC;
{
obj_t aux1217_1087;
aux1217_1087 = close_output_port(port_1085);
POP_TRACE();
return aux1217_1087;
}
}
}
}
}


/* flush-output-port */obj_t flush_output_port_36___r4_ports_6_10_1(obj_t port_26)
{
{
obj_t symbol1220_1088;
symbol1220_1088 = symbol1801___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1220_1088);
BUNSPEC;
{
obj_t aux1219_1089;
aux1219_1089 = FLUSH_OUTPUT_PORT(port_26);
POP_TRACE();
return aux1219_1089;
}
}
}
}


/* _flush-output-port1259 */obj_t _flush_output_port1259_6___r4_ports_6_10_1(obj_t env_606, obj_t port_607)
{
{
obj_t port_1090;
if(OUTPUT_PORTP(port_607)){
port_1090 = port_607;
}
 else {
bigloo_type_error_location_103___error(symbol1802___r4_ports_6_10_1, string1750___r4_ports_6_10_1, port_607, string1739___r4_ports_6_10_1, BINT(((long)13407)));
exit( -1 );}
{
obj_t symbol1220_1091;
symbol1220_1091 = symbol1801___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1220_1091);
BUNSPEC;
{
obj_t aux1219_1092;
aux1219_1092 = FLUSH_OUTPUT_PORT(port_1090);
POP_TRACE();
return aux1219_1092;
}
}
}
}
}


/* reset-eof */bool_t reset_eof_236___r4_ports_6_10_1(obj_t port_27)
{
{
obj_t symbol1222_1093;
symbol1222_1093 = symbol1803___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1222_1093);
BUNSPEC;
{
bool_t aux1221_1094;
aux1221_1094 = reset_eof(port_27);
POP_TRACE();
return aux1221_1094;
}
}
}
}


/* _reset-eof1260 */obj_t _reset_eof1260_237___r4_ports_6_10_1(obj_t env_608, obj_t port_609)
{
{
bool_t aux_1745;
{
obj_t port_1095;
if(INPUT_PORTP(port_609)){
port_1095 = port_609;
}
 else {
bigloo_type_error_location_103___error(symbol1804___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_609, string1739___r4_ports_6_10_1, BINT(((long)13701)));
exit( -1 );}
{
obj_t symbol1222_1096;
symbol1222_1096 = symbol1803___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1222_1096);
BUNSPEC;
{
bool_t aux1221_1097;
aux1221_1097 = reset_eof(port_1095);
POP_TRACE();
aux_1745 = aux1221_1097;
}
}
}
}
return BBOOL(aux_1745);
}
}


/* input-port-position */int input_port_position_149___r4_ports_6_10_1(obj_t port_28)
{
{
obj_t symbol1224_1098;
symbol1224_1098 = symbol1805___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1224_1098);
BUNSPEC;
{
int aux1223_1099;
{
long aux_1756;
aux_1756 = INPUT_PORT_FILEPOS(port_28);
aux1223_1099 = (int)(aux_1756);
}
POP_TRACE();
return aux1223_1099;
}
}
}
}


/* _input-port-position1261 */obj_t _input_port_position1261_156___r4_ports_6_10_1(obj_t env_610, obj_t port_611)
{
{
int aux_1760;
{
obj_t port_1100;
if(INPUT_PORTP(port_611)){
port_1100 = port_611;
}
 else {
bigloo_type_error_location_103___error(symbol1806___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_611, string1739___r4_ports_6_10_1, BINT(((long)13979)));
exit( -1 );}
{
obj_t symbol1224_1101;
symbol1224_1101 = symbol1805___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1224_1101);
BUNSPEC;
{
int aux1223_1102;
{
long aux_1767;
aux_1767 = INPUT_PORT_FILEPOS(port_1100);
aux1223_1102 = (int)(aux_1767);
}
POP_TRACE();
aux_1760 = aux1223_1102;
}
}
}
}
return BINT(aux_1760);
}
}


/* input-port-name */char * input_port_name_249___r4_ports_6_10_1(obj_t port_29)
{
{
obj_t symbol1226_1103;
symbol1226_1103 = symbol1807___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1226_1103);
BUNSPEC;
{
char * aux1225_1104;
aux1225_1104 = INPUT_PORT_NAME(port_29);
POP_TRACE();
return aux1225_1104;
}
}
}
}


/* _input-port-name1262 */obj_t _input_port_name1262_241___r4_ports_6_10_1(obj_t env_612, obj_t port_613)
{
{
char * aux_1775;
{
obj_t port_1105;
if(INPUT_PORTP(port_613)){
port_1105 = port_613;
}
 else {
bigloo_type_error_location_103___error(symbol1808___r4_ports_6_10_1, string1741___r4_ports_6_10_1, port_613, string1739___r4_ports_6_10_1, BINT(((long)14277)));
exit( -1 );}
{
obj_t symbol1226_1106;
symbol1226_1106 = symbol1807___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1226_1106);
BUNSPEC;
{
char * aux1225_1107;
aux1225_1107 = INPUT_PORT_NAME(port_1105);
POP_TRACE();
aux_1775 = aux1225_1107;
}
}
}
}
return string_to_bstring(aux_1775);
}
}


/* file-exists? */obj_t file_exists__238___r4_ports_6_10_1(char * name_30)
{
{
obj_t symbol1228_1108;
symbol1228_1108 = symbol1809___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1228_1108);
BUNSPEC;
{
obj_t aux1227_1109;
{
bool_t aux_1786;
aux_1786 = fexists(name_30);
aux1227_1109 = BBOOL(aux_1786);
}
POP_TRACE();
return aux1227_1109;
}
}
}
}


/* _file-exists?1263 */obj_t _file_exists_1263_64___r4_ports_6_10_1(obj_t env_614, obj_t name_615)
{
{
char * name_1110;
{
obj_t aux_1790;
if(STRINGP(name_615)){
aux_1790 = name_615;
}
 else {
bigloo_type_error_location_103___error(symbol1810___r4_ports_6_10_1, string1793___r4_ports_6_10_1, name_615, string1739___r4_ports_6_10_1, BINT(((long)14567)));
exit( -1 );}
name_1110 = BSTRING_TO_STRING(aux_1790);
}
{
obj_t symbol1228_1111;
symbol1228_1111 = symbol1809___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1228_1111);
BUNSPEC;
{
obj_t aux1227_1112;
{
bool_t aux_1798;
aux_1798 = fexists(name_1110);
aux1227_1112 = BBOOL(aux_1798);
}
POP_TRACE();
return aux1227_1112;
}
}
}
}
}


/* append-output-file */obj_t append_output_file_247___r4_ports_6_10_1(obj_t string_31)
{
{
obj_t symbol1230_1113;
symbol1230_1113 = symbol1811___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1230_1113);
BUNSPEC;
{
obj_t aux1229_1114;
aux1229_1114 = append_output_file(string_31);
POP_TRACE();
return aux1229_1114;
}
}
}
}


/* _append-output-file1264 */obj_t _append_output_file1264_138___r4_ports_6_10_1(obj_t env_616, obj_t string_617)
{
{
obj_t string_1115;
if(STRINGP(string_617)){
string_1115 = string_617;
}
 else {
bigloo_type_error_location_103___error(symbol1812___r4_ports_6_10_1, string1746___r4_ports_6_10_1, string_617, string1739___r4_ports_6_10_1, BINT(((long)14850)));
exit( -1 );}
{
obj_t symbol1230_1116;
symbol1230_1116 = symbol1811___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1230_1116);
BUNSPEC;
{
obj_t aux1229_1117;
aux1229_1117 = append_output_file(string_1115);
POP_TRACE();
return aux1229_1117;
}
}
}
}
}


/* delete-file */obj_t delete_file_114___r4_ports_6_10_1(char * string_32)
{
{
obj_t symbol1232_1118;
symbol1232_1118 = symbol1813___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1232_1118);
BUNSPEC;
{
obj_t aux1231_1119;
{
bool_t aux_1814;
aux_1814 = unlink(string_32);
aux1231_1119 = BBOOL(aux_1814);
}
POP_TRACE();
return aux1231_1119;
}
}
}
}


/* _delete-file1265 */obj_t _delete_file1265_238___r4_ports_6_10_1(obj_t env_618, obj_t string_619)
{
{
char * string_1120;
{
obj_t aux_1818;
if(STRINGP(string_619)){
aux_1818 = string_619;
}
 else {
bigloo_type_error_location_103___error(symbol1814___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string_619, string1739___r4_ports_6_10_1, BINT(((long)15150)));
exit( -1 );}
string_1120 = BSTRING_TO_STRING(aux_1818);
}
{
obj_t symbol1232_1121;
symbol1232_1121 = symbol1813___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1232_1121);
BUNSPEC;
{
obj_t aux1231_1122;
{
bool_t aux_1826;
aux_1826 = unlink(string_1120);
aux1231_1122 = BBOOL(aux_1826);
}
POP_TRACE();
return aux1231_1122;
}
}
}
}
}


/* delete-directory */obj_t delete_directory_248___r4_ports_6_10_1(char * string_33)
{
{
obj_t symbol1234_1123;
symbol1234_1123 = symbol1815___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1234_1123);
BUNSPEC;
{
obj_t aux1233_1124;
{
bool_t aux_1831;
aux_1831 = rmdir(string_33);
aux1233_1124 = BBOOL(aux_1831);
}
POP_TRACE();
return aux1233_1124;
}
}
}
}


/* _delete-directory1266 */obj_t _delete_directory1266_20___r4_ports_6_10_1(obj_t env_620, obj_t string_621)
{
{
char * string_1125;
{
obj_t aux_1835;
if(STRINGP(string_621)){
aux_1835 = string_621;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string_621, string1739___r4_ports_6_10_1, BINT(((long)15436)));
exit( -1 );}
string_1125 = BSTRING_TO_STRING(aux_1835);
}
{
obj_t symbol1234_1126;
symbol1234_1126 = symbol1815___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1234_1126);
BUNSPEC;
{
obj_t aux1233_1127;
{
bool_t aux_1843;
aux_1843 = rmdir(string_1125);
aux1233_1127 = BBOOL(aux_1843);
}
POP_TRACE();
return aux1233_1127;
}
}
}
}
}


/* rename-file */obj_t rename_file_185___r4_ports_6_10_1(char * string1_34, char * string2_35)
{
{
obj_t symbol1236_1128;
symbol1236_1128 = symbol1817___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1236_1128);
BUNSPEC;
{
obj_t aux1235_1129;
{
bool_t test1058_1130;
{
int arg1059_1131;
arg1059_1131 = rename(string1_34, string2_35);
{
obj_t aux_1851;
obj_t aux_1849;
aux_1851 = BINT(((long)0));
aux_1849 = BINT(arg1059_1131);
test1058_1130 = (aux_1849==aux_1851);
}
}
if(test1058_1130){
aux1235_1129 = BTRUE;
}
 else {
aux1235_1129 = BFALSE;
}
}
POP_TRACE();
return aux1235_1129;
}
}
}
}


/* _rename-file1267 */obj_t _rename_file1267_209___r4_ports_6_10_1(obj_t env_622, obj_t string1_623, obj_t string2_624)
{
{
char * string1_1132;
char * string2_1133;
{
obj_t aux_1856;
if(STRINGP(string1_623)){
aux_1856 = string1_623;
}
 else {
bigloo_type_error_location_103___error(symbol1818___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string1_623, string1739___r4_ports_6_10_1, BINT(((long)15732)));
exit( -1 );}
string1_1132 = BSTRING_TO_STRING(aux_1856);
}
{
obj_t aux_1863;
if(STRINGP(string2_624)){
aux_1863 = string2_624;
}
 else {
bigloo_type_error_location_103___error(symbol1818___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string2_624, string1739___r4_ports_6_10_1, BINT(((long)15732)));
exit( -1 );}
string2_1133 = BSTRING_TO_STRING(aux_1863);
}
{
obj_t symbol1236_1134;
symbol1236_1134 = symbol1817___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1236_1134);
BUNSPEC;
{
obj_t aux1235_1135;
{
bool_t test1058_1136;
{
int arg1059_1137;
arg1059_1137 = rename(string1_1132, string2_1133);
{
obj_t aux_1874;
obj_t aux_1872;
aux_1874 = BINT(((long)0));
aux_1872 = BINT(arg1059_1137);
test1058_1136 = (aux_1872==aux_1874);
}
}
if(test1058_1136){
aux1235_1135 = BTRUE;
}
 else {
aux1235_1135 = BFALSE;
}
}
POP_TRACE();
return aux1235_1135;
}
}
}
}
}


/* port? */bool_t port__25___r4_ports_6_10_1(obj_t obj_36)
{
{
obj_t symbol1238_1138;
symbol1238_1138 = symbol1819___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1238_1138);
BUNSPEC;
{
bool_t aux1237_1139;
{
bool_t _ortest_1020_1140;
_ortest_1020_1140 = OUTPUT_PORTP(obj_36);
if(_ortest_1020_1140){
aux1237_1139 = _ortest_1020_1140;
}
 else {
aux1237_1139 = INPUT_PORTP(obj_36);
}
}
POP_TRACE();
return aux1237_1139;
}
}
}
}


/* _port? */obj_t _port__120___r4_ports_6_10_1(obj_t env_625, obj_t obj_626)
{
{
bool_t aux_1884;
{
obj_t obj_1141;
obj_1141 = obj_626;
{
obj_t symbol1238_1142;
symbol1238_1142 = symbol1819___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1238_1142);
BUNSPEC;
{
bool_t aux1237_1143;
{
bool_t _ortest_1020_1144;
_ortest_1020_1144 = OUTPUT_PORTP(obj_1141);
if(_ortest_1020_1144){
aux1237_1143 = _ortest_1020_1144;
}
 else {
aux1237_1143 = INPUT_PORTP(obj_1141);
}
}
POP_TRACE();
aux_1884 = aux1237_1143;
}
}
}
}
return BBOOL(aux_1884);
}
}


/* directory? */bool_t directory__80___r4_ports_6_10_1(char * string_37)
{
{
obj_t symbol1240_1145;
symbol1240_1145 = symbol1820___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1240_1145);
BUNSPEC;
{
bool_t aux1239_1146;
aux1239_1146 = directoryp(string_37);
POP_TRACE();
return aux1239_1146;
}
}
}
}


/* _directory?1268 */obj_t _directory_1268_185___r4_ports_6_10_1(obj_t env_627, obj_t string_628)
{
{
bool_t aux_1894;
{
char * string_1147;
{
obj_t aux_1895;
if(STRINGP(string_628)){
aux_1895 = string_628;
}
 else {
bigloo_type_error_location_103___error(symbol1821___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string_628, string1739___r4_ports_6_10_1, BINT(((long)16365)));
exit( -1 );}
string_1147 = BSTRING_TO_STRING(aux_1895);
}
{
obj_t symbol1240_1148;
symbol1240_1148 = symbol1820___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1240_1148);
BUNSPEC;
{
bool_t aux1239_1149;
aux1239_1149 = directoryp(string_1147);
POP_TRACE();
aux_1894 = aux1239_1149;
}
}
}
}
return BBOOL(aux_1894);
}
}


/* directory->list */obj_t directory__list_196___r4_ports_6_10_1(char * string_38)
{
{
obj_t symbol1242_1150;
symbol1242_1150 = symbol1822___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1242_1150);
BUNSPEC;
{
obj_t aux1241_1151;
aux1241_1151 = directory_to_list(string_38);
POP_TRACE();
return aux1241_1151;
}
}
}
}


/* _directory->list1269 */obj_t _directory__list1269_16___r4_ports_6_10_1(obj_t env_629, obj_t string_630)
{
{
char * string_1152;
{
obj_t aux_1909;
if(STRINGP(string_630)){
aux_1909 = string_630;
}
 else {
bigloo_type_error_location_103___error(symbol1823___r4_ports_6_10_1, string1793___r4_ports_6_10_1, string_630, string1739___r4_ports_6_10_1, BINT(((long)16649)));
exit( -1 );}
string_1152 = BSTRING_TO_STRING(aux_1909);
}
{
obj_t symbol1242_1153;
symbol1242_1153 = symbol1822___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1242_1153);
BUNSPEC;
{
obj_t aux1241_1154;
aux1241_1154 = directory_to_list(string_1152);
POP_TRACE();
return aux1241_1154;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_ports_6_10_1()
{
{
obj_t symbol1244_559;
symbol1244_559 = symbol1824___r4_ports_6_10_1;
{
PUSH_TRACE(symbol1244_559);
BUNSPEC;
{
obj_t aux1243_560;
aux1243_560 = module_initialization_70___error(((long)0), "__R4_PORTS_6_10_1");
POP_TRACE();
return aux1243_560;
}
}
}
}

