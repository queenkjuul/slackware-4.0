/*===========================================================================*/
/*   (Expand/map.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_expand_map();
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t module_initialization_70_expand_map(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t expand_for_each_88_expand_map(obj_t, obj_t);
static obj_t imported_modules_init_94_expand_map();
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_map();
static obj_t _expand_for_each_126_expand_map(obj_t, obj_t, obj_t);
extern obj_t _unsafe_type__146_engine_param;
extern obj_t expand_map_185_expand_map(obj_t, obj_t);
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _expand_map_144_expand_map(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_expand_map = BUNSPEC;
static obj_t cnst_init_137_expand_map();
static obj_t __cnst[24];

DEFINE_EXPORT_PROCEDURE(expand_map_env_203_expand_map, _expand_map_144_expand_map3405, _expand_map_144_expand_map, 0L, 2);
DEFINE_STRING(string3399_expand_map, string3399_expand_map3406, "FOR-EACH BEGIN MAP LL __ERROR ERROR ELSE PAIR? COND SET-CDR! CDR CAR CONS QUOTE __R4_PAIRS_AND_LISTS_6_3 NULL? @ IF LET NEWTAIL TAIL HEAD LNAME L ", 146);
DEFINE_STRING(string3398_expand_map, string3398_expand_map3407, "Illegal `for-each' form", 23);
DEFINE_STRING(string3397_expand_map, string3397_expand_map3408, "for-each", 8);
DEFINE_STRING(string3396_expand_map, string3396_expand_map3409, "Illegal `map' form", 18);
DEFINE_STRING(string3395_expand_map, string3395_expand_map3410, "map", 3);
DEFINE_STRING(string3394_expand_map, string3394_expand_map3411, "argument not a list", 19);
DEFINE_EXPORT_PROCEDURE(expand_for_each_env_168_expand_map, _expand_for_each_126_expand_map3412, _expand_for_each_126_expand_map, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_expand_map(long checksum_2244, char *from_2245)
{
   if (CBOOL(require_initialization_114_expand_map))
     {
	require_initialization_114_expand_map = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_map();
	cnst_init_137_expand_map();
	imported_modules_init_94_expand_map();
	method_init_76_expand_map();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_map()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_MAP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_MAP");
   module_initialization_70___reader(((long) 0), "EXPAND_MAP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_map()
{
   {
      obj_t cnst_port_138_2236;
      cnst_port_138_2236 = open_input_string(string3399_expand_map);
      {
	 long i_2237;
	 i_2237 = ((long) 23);
       loop_2238:
	 {
	    bool_t test3400_2239;
	    test3400_2239 = (i_2237 == ((long) -1));
	    if (test3400_2239)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg3401_2240;
		    {
		       obj_t list3402_2241;
		       {
			  obj_t arg3403_2242;
			  arg3403_2242 = BNIL;
			  list3402_2241 = MAKE_PAIR(cnst_port_138_2236, arg3403_2242);
		       }
		       arg3401_2240 = read___reader(list3402_2241);
		    }
		    CNST_TABLE_SET(i_2237, arg3401_2240);
		 }
		 {
		    int aux_2243;
		    {
		       long aux_2262;
		       aux_2262 = (i_2237 - ((long) 1));
		       aux_2243 = (int) (aux_2262);
		    }
		    {
		       long i_2265;
		       i_2265 = (long) (aux_2243);
		       i_2237 = i_2265;
		       goto loop_2238;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-map */ obj_t 
expand_map_185_expand_map(obj_t x_1, obj_t e_2)
{
   {
      obj_t fun_59;
      obj_t lists_60;
      obj_t fun_55;
      obj_t l1_56;
      obj_t l2_57;
      obj_t fun_52;
      obj_t list_53;
      if (PAIRP(x_1))
	{
	   obj_t cdr_114_48_65;
	   cdr_114_48_65 = CDR(x_1);
	   if (PAIRP(cdr_114_48_65))
	     {
		obj_t cdr_118_57_67;
		cdr_118_57_67 = CDR(cdr_114_48_65);
		if (PAIRP(cdr_118_57_67))
		  {
		     bool_t test_2275;
		     {
			obj_t aux_2276;
			aux_2276 = CDR(cdr_118_57_67);
			test_2275 = (aux_2276 == BNIL);
		     }
		     if (test_2275)
		       {
			  fun_52 = CAR(cdr_114_48_65);
			  list_53 = CAR(cdr_118_57_67);
			  {
			     obj_t l_93;
			     {
				obj_t arg2388_1110;
				arg2388_1110 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
				l_93 = mark_symbol_non_user__17_ast_ident(arg2388_1110);
			     }
			     {
				obj_t lname_94;
				{
				   obj_t arg2386_1108;
				   arg2386_1108 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
				   lname_94 = mark_symbol_non_user__17_ast_ident(arg2386_1108);
				}
				{
				   obj_t head_95;
				   {
				      obj_t arg2384_1106;
				      arg2384_1106 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
				      head_95 = mark_symbol_non_user__17_ast_ident(arg2384_1106);
				   }
				   {
				      obj_t tail_96;
				      {
					 obj_t arg2381_1104;
					 arg2381_1104 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
					 tail_96 = mark_symbol_non_user__17_ast_ident(arg2381_1104);
				      }
				      {
					 obj_t ntail_97;
					 {
					    obj_t arg2379_1102;
					    arg2379_1102 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
					    ntail_97 = mark_symbol_non_user__17_ast_ident(arg2379_1102);
					 }
					 {
					    obj_t loop_98;
					    if (CBOOL(_unsafe_type__146_engine_param))
					      {
						 obj_t arg1190_100;
						 obj_t arg1191_101;
						 obj_t arg1192_102;
						 arg1190_100 = CNST_TABLE_REF(((long) 5));
						 {
						    obj_t arg1199_108;
						    {
						       obj_t list1204_113;
						       {
							  obj_t arg1205_114;
							  arg1205_114 = MAKE_PAIR(BNIL, BNIL);
							  list1204_113 = MAKE_PAIR(list_53, arg1205_114);
						       }
						       arg1199_108 = cons__138___r4_pairs_and_lists_6_3(l_93, list1204_113);
						    }
						    {
						       obj_t list1201_110;
						       list1201_110 = MAKE_PAIR(BNIL, BNIL);
						       arg1191_101 = cons__138___r4_pairs_and_lists_6_3(arg1199_108, list1201_110);
						    }
						 }
						 {
						    obj_t arg1207_116;
						    obj_t arg1209_117;
						    obj_t arg1210_118;
						    obj_t arg1211_119;
						    arg1207_116 = CNST_TABLE_REF(((long) 6));
						    {
						       obj_t arg1222_126;
						       {
							  obj_t arg1231_131;
							  obj_t arg1232_132;
							  obj_t arg1233_133;
							  arg1231_131 = CNST_TABLE_REF(((long) 7));
							  arg1232_132 = CNST_TABLE_REF(((long) 8));
							  arg1233_133 = CNST_TABLE_REF(((long) 9));
							  {
							     obj_t list1235_135;
							     {
								obj_t arg1236_136;
								{
								   obj_t arg1238_137;
								   arg1238_137 = MAKE_PAIR(BNIL, BNIL);
								   arg1236_136 = MAKE_PAIR(arg1233_133, arg1238_137);
								}
								list1235_135 = MAKE_PAIR(arg1232_132, arg1236_136);
							     }
							     arg1222_126 = cons__138___r4_pairs_and_lists_6_3(arg1231_131, list1235_135);
							  }
						       }
						       {
							  obj_t list1225_128;
							  {
							     obj_t arg1226_129;
							     arg1226_129 = MAKE_PAIR(BNIL, BNIL);
							     list1225_128 = MAKE_PAIR(l_93, arg1226_129);
							  }
							  arg1209_117 = cons__138___r4_pairs_and_lists_6_3(arg1222_126, list1225_128);
						       }
						    }
						    {
						       obj_t arg1241_139;
						       arg1241_139 = CNST_TABLE_REF(((long) 10));
						       {
							  obj_t list1245_142;
							  {
							     obj_t arg1247_143;
							     arg1247_143 = MAKE_PAIR(BNIL, BNIL);
							     list1245_142 = MAKE_PAIR(BNIL, arg1247_143);
							  }
							  arg1210_118 = cons__138___r4_pairs_and_lists_6_3(arg1241_139, list1245_142);
						       }
						    }
						    {
						       if (PAIRP(fun_52))
							 {
							    {
							       obj_t arg1518_357;
							       obj_t arg1519_358;
							       obj_t arg1522_359;
							       arg1518_357 = CNST_TABLE_REF(((long) 5));
							       {
								  obj_t arg1529_365;
								  {
								     obj_t arg1533_369;
								     {
									obj_t arg1539_374;
									obj_t arg1540_375;
									obj_t arg1542_376;
									{
									   obj_t arg1552_382;
									   obj_t arg1553_383;
									   obj_t arg1554_384;
									   arg1552_382 = CNST_TABLE_REF(((long) 7));
									   arg1553_383 = CNST_TABLE_REF(((long) 11));
									   arg1554_384 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1556_386;
									      {
										 obj_t arg1557_387;
										 {
										    obj_t arg1558_388;
										    arg1558_388 = MAKE_PAIR(BNIL, BNIL);
										    arg1557_387 = MAKE_PAIR(arg1554_384, arg1558_388);
										 }
										 list1556_386 = MAKE_PAIR(arg1553_383, arg1557_387);
									      }
									      arg1539_374 = cons__138___r4_pairs_and_lists_6_3(arg1552_382, list1556_386);
									   }
									}
									{
									   obj_t arg1560_390;
									   arg1560_390 = CNST_TABLE_REF(((long) 10));
									   {
									      obj_t list1563_393;
									      {
										 obj_t arg1564_394;
										 arg1564_394 = MAKE_PAIR(BNIL, BNIL);
										 list1563_393 = MAKE_PAIR(BNIL, arg1564_394);
									      }
									      arg1540_375 = cons__138___r4_pairs_and_lists_6_3(arg1560_390, list1563_393);
									   }
									}
									{
									   obj_t arg1566_396;
									   arg1566_396 = CNST_TABLE_REF(((long) 10));
									   {
									      obj_t list1570_399;
									      {
										 obj_t arg1572_400;
										 arg1572_400 = MAKE_PAIR(BNIL, BNIL);
										 list1570_399 = MAKE_PAIR(BNIL, arg1572_400);
									      }
									      arg1542_376 = cons__138___r4_pairs_and_lists_6_3(arg1566_396, list1570_399);
									   }
									}
									{
									   obj_t list1546_378;
									   {
									      obj_t arg1548_379;
									      {
										 obj_t arg1549_380;
										 arg1549_380 = MAKE_PAIR(BNIL, BNIL);
										 arg1548_379 = MAKE_PAIR(arg1542_376, arg1549_380);
									      }
									      list1546_378 = MAKE_PAIR(arg1540_375, arg1548_379);
									   }
									   arg1533_369 = cons__138___r4_pairs_and_lists_6_3(arg1539_374, list1546_378);
									}
								     }
								     {
									obj_t list1535_371;
									{
									   obj_t arg1536_372;
									   arg1536_372 = MAKE_PAIR(BNIL, BNIL);
									   list1535_371 = MAKE_PAIR(arg1533_369, arg1536_372);
									}
									arg1529_365 = cons__138___r4_pairs_and_lists_6_3(head_95, list1535_371);
								     }
								  }
								  {
								     obj_t list1531_367;
								     list1531_367 = MAKE_PAIR(BNIL, BNIL);
								     arg1519_358 = cons__138___r4_pairs_and_lists_6_3(arg1529_365, list1531_367);
								  }
							       }
							       {
								  obj_t arg1575_402;
								  obj_t arg1578_403;
								  obj_t arg1580_404;
								  arg1575_402 = CNST_TABLE_REF(((long) 5));
								  {
								     obj_t arg1587_411;
								     obj_t arg1588_412;
								     {
									obj_t list1595_418;
									{
									   obj_t arg1598_419;
									   arg1598_419 = MAKE_PAIR(BNIL, BNIL);
									   list1595_418 = MAKE_PAIR(l_93, arg1598_419);
									}
									arg1587_411 = cons__138___r4_pairs_and_lists_6_3(l_93, list1595_418);
								     }
								     {
									obj_t list1603_422;
									{
									   obj_t arg1605_423;
									   arg1605_423 = MAKE_PAIR(BNIL, BNIL);
									   list1603_422 = MAKE_PAIR(head_95, arg1605_423);
									}
									arg1588_412 = cons__138___r4_pairs_and_lists_6_3(tail_96, list1603_422);
								     }
								     {
									obj_t list1590_414;
									{
									   obj_t arg1592_415;
									   arg1592_415 = MAKE_PAIR(BNIL, BNIL);
									   list1590_414 = MAKE_PAIR(arg1588_412, arg1592_415);
									}
									arg1578_403 = cons__138___r4_pairs_and_lists_6_3(arg1587_411, list1590_414);
								     }
								  }
								  {
								     obj_t arg1607_425;
								     obj_t arg1608_426;
								     obj_t arg1609_427;
								     obj_t arg1610_428;
								     arg1607_425 = CNST_TABLE_REF(((long) 6));
								     {
									obj_t arg1621_435;
									{
									   obj_t arg1627_440;
									   obj_t arg1628_441;
									   obj_t arg1630_442;
									   arg1627_440 = CNST_TABLE_REF(((long) 7));
									   arg1628_441 = CNST_TABLE_REF(((long) 8));
									   arg1630_442 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1633_444;
									      {
										 obj_t arg1634_445;
										 {
										    obj_t arg1636_446;
										    arg1636_446 = MAKE_PAIR(BNIL, BNIL);
										    arg1634_445 = MAKE_PAIR(arg1630_442, arg1636_446);
										 }
										 list1633_444 = MAKE_PAIR(arg1628_441, arg1634_445);
									      }
									      arg1621_435 = cons__138___r4_pairs_and_lists_6_3(arg1627_440, list1633_444);
									   }
									}
									{
									   obj_t list1623_437;
									   {
									      obj_t arg1624_438;
									      arg1624_438 = MAKE_PAIR(BNIL, BNIL);
									      list1623_437 = MAKE_PAIR(l_93, arg1624_438);
									   }
									   arg1608_426 = cons__138___r4_pairs_and_lists_6_3(arg1621_435, list1623_437);
									}
								     }
								     {
									obj_t arg1639_448;
									{
									   obj_t arg1647_453;
									   obj_t arg1648_454;
									   obj_t arg1649_455;
									   arg1647_453 = CNST_TABLE_REF(((long) 7));
									   arg1648_454 = CNST_TABLE_REF(((long) 13));
									   arg1649_455 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1651_457;
									      {
										 obj_t arg1652_458;
										 {
										    obj_t arg1653_459;
										    arg1653_459 = MAKE_PAIR(BNIL, BNIL);
										    arg1652_458 = MAKE_PAIR(arg1649_455, arg1653_459);
										 }
										 list1651_457 = MAKE_PAIR(arg1648_454, arg1652_458);
									      }
									      arg1639_448 = cons__138___r4_pairs_and_lists_6_3(arg1647_453, list1651_457);
									   }
									}
									{
									   obj_t list1641_450;
									   {
									      obj_t arg1645_451;
									      arg1645_451 = MAKE_PAIR(BNIL, BNIL);
									      list1641_450 = MAKE_PAIR(head_95, arg1645_451);
									   }
									   arg1609_427 = cons__138___r4_pairs_and_lists_6_3(arg1639_448, list1641_450);
									}
								     }
								     {
									obj_t arg1655_461;
									obj_t arg1656_462;
									obj_t arg1657_463;
									obj_t arg1658_464;
									arg1655_461 = CNST_TABLE_REF(((long) 5));
									{
									   obj_t arg1667_471;
									   {
									      obj_t arg1672_475;
									      {
										 obj_t arg1677_480;
										 obj_t arg1678_481;
										 obj_t arg1679_482;
										 {
										    obj_t arg1685_488;
										    obj_t arg1686_489;
										    obj_t arg1688_490;
										    arg1685_488 = CNST_TABLE_REF(((long) 7));
										    arg1686_489 = CNST_TABLE_REF(((long) 11));
										    arg1688_490 = CNST_TABLE_REF(((long) 9));
										    {
										       obj_t list1690_492;
										       {
											  obj_t arg1691_493;
											  {
											     obj_t arg1692_494;
											     arg1692_494 = MAKE_PAIR(BNIL, BNIL);
											     arg1691_493 = MAKE_PAIR(arg1688_490, arg1692_494);
											  }
											  list1690_492 = MAKE_PAIR(arg1686_489, arg1691_493);
										       }
										       arg1677_480 = cons__138___r4_pairs_and_lists_6_3(arg1685_488, list1690_492);
										    }
										 }
										 {
										    obj_t arg1694_496;
										    {
										       obj_t arg1699_501;
										       {
											  obj_t arg1704_506;
											  obj_t arg1705_507;
											  obj_t arg1706_508;
											  arg1704_506 = CNST_TABLE_REF(((long) 7));
											  arg1705_507 = CNST_TABLE_REF(((long) 12));
											  arg1706_508 = CNST_TABLE_REF(((long) 9));
											  {
											     obj_t list1708_510;
											     {
												obj_t arg1709_511;
												{
												   obj_t arg1710_512;
												   arg1710_512 = MAKE_PAIR(BNIL, BNIL);
												   arg1709_511 = MAKE_PAIR(arg1706_508, arg1710_512);
												}
												list1708_510 = MAKE_PAIR(arg1705_507, arg1709_511);
											     }
											     arg1699_501 = cons__138___r4_pairs_and_lists_6_3(arg1704_506, list1708_510);
											  }
										       }
										       {
											  obj_t list1701_503;
											  {
											     obj_t arg1702_504;
											     arg1702_504 = MAKE_PAIR(BNIL, BNIL);
											     list1701_503 = MAKE_PAIR(l_93, arg1702_504);
											  }
											  arg1694_496 = cons__138___r4_pairs_and_lists_6_3(arg1699_501, list1701_503);
										       }
										    }
										    {
										       obj_t list1696_498;
										       {
											  obj_t arg1697_499;
											  arg1697_499 = MAKE_PAIR(BNIL, BNIL);
											  list1696_498 = MAKE_PAIR(arg1694_496, arg1697_499);
										       }
										       arg1678_481 = cons__138___r4_pairs_and_lists_6_3(fun_52, list1696_498);
										    }
										 }
										 {
										    obj_t arg1712_514;
										    arg1712_514 = CNST_TABLE_REF(((long) 10));
										    {
										       obj_t list1715_517;
										       {
											  obj_t arg1716_518;
											  arg1716_518 = MAKE_PAIR(BNIL, BNIL);
											  list1715_517 = MAKE_PAIR(BNIL, arg1716_518);
										       }
										       arg1679_482 = cons__138___r4_pairs_and_lists_6_3(arg1712_514, list1715_517);
										    }
										 }
										 {
										    obj_t list1681_484;
										    {
										       obj_t arg1682_485;
										       {
											  obj_t arg1683_486;
											  arg1683_486 = MAKE_PAIR(BNIL, BNIL);
											  arg1682_485 = MAKE_PAIR(arg1679_482, arg1683_486);
										       }
										       list1681_484 = MAKE_PAIR(arg1678_481, arg1682_485);
										    }
										    arg1672_475 = cons__138___r4_pairs_and_lists_6_3(arg1677_480, list1681_484);
										 }
									      }
									      {
										 obj_t list1674_477;
										 {
										    obj_t arg1675_478;
										    arg1675_478 = MAKE_PAIR(BNIL, BNIL);
										    list1674_477 = MAKE_PAIR(arg1672_475, arg1675_478);
										 }
										 arg1667_471 = cons__138___r4_pairs_and_lists_6_3(ntail_97, list1674_477);
									      }
									   }
									   {
									      obj_t list1669_473;
									      list1669_473 = MAKE_PAIR(BNIL, BNIL);
									      arg1656_462 = cons__138___r4_pairs_and_lists_6_3(arg1667_471, list1669_473);
									   }
									}
									{
									   obj_t arg1718_520;
									   {
									      obj_t arg1725_526;
									      obj_t arg1726_527;
									      obj_t arg1727_528;
									      arg1725_526 = CNST_TABLE_REF(((long) 7));
									      arg1726_527 = CNST_TABLE_REF(((long) 14));
									      arg1727_528 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list1729_530;
										 {
										    obj_t arg1730_531;
										    {
										       obj_t arg1731_532;
										       arg1731_532 = MAKE_PAIR(BNIL, BNIL);
										       arg1730_531 = MAKE_PAIR(arg1727_528, arg1731_532);
										    }
										    list1729_530 = MAKE_PAIR(arg1726_527, arg1730_531);
										 }
										 arg1718_520 = cons__138___r4_pairs_and_lists_6_3(arg1725_526, list1729_530);
									      }
									   }
									   {
									      obj_t list1721_522;
									      {
										 obj_t arg1722_523;
										 {
										    obj_t arg1723_524;
										    arg1723_524 = MAKE_PAIR(BNIL, BNIL);
										    arg1722_523 = MAKE_PAIR(ntail_97, arg1723_524);
										 }
										 list1721_522 = MAKE_PAIR(tail_96, arg1722_523);
									      }
									      arg1657_463 = cons__138___r4_pairs_and_lists_6_3(arg1718_520, list1721_522);
									   }
									}
									{
									   obj_t arg1733_534;
									   {
									      obj_t arg1745_540;
									      {
										 obj_t arg1753_545;
										 obj_t arg1755_546;
										 obj_t arg1758_547;
										 arg1753_545 = CNST_TABLE_REF(((long) 7));
										 arg1755_546 = CNST_TABLE_REF(((long) 13));
										 arg1758_547 = CNST_TABLE_REF(((long) 9));
										 {
										    obj_t list1760_549;
										    {
										       obj_t arg1761_550;
										       {
											  obj_t arg1762_551;
											  arg1762_551 = MAKE_PAIR(BNIL, BNIL);
											  arg1761_550 = MAKE_PAIR(arg1758_547, arg1762_551);
										       }
										       list1760_549 = MAKE_PAIR(arg1755_546, arg1761_550);
										    }
										    arg1745_540 = cons__138___r4_pairs_and_lists_6_3(arg1753_545, list1760_549);
										 }
									      }
									      {
										 obj_t list1747_542;
										 {
										    obj_t arg1748_543;
										    arg1748_543 = MAKE_PAIR(BNIL, BNIL);
										    list1747_542 = MAKE_PAIR(l_93, arg1748_543);
										 }
										 arg1733_534 = cons__138___r4_pairs_and_lists_6_3(arg1745_540, list1747_542);
									      }
									   }
									   {
									      obj_t list1739_536;
									      {
										 obj_t arg1740_537;
										 {
										    obj_t arg1743_538;
										    arg1743_538 = MAKE_PAIR(BNIL, BNIL);
										    arg1740_537 = MAKE_PAIR(ntail_97, arg1743_538);
										 }
										 list1739_536 = MAKE_PAIR(arg1733_534, arg1740_537);
									      }
									      arg1658_464 = cons__138___r4_pairs_and_lists_6_3(lname_94, list1739_536);
									   }
									}
									{
									   obj_t list1660_466;
									   {
									      obj_t arg1661_467;
									      {
										 obj_t arg1663_468;
										 {
										    obj_t arg1665_469;
										    arg1665_469 = MAKE_PAIR(BNIL, BNIL);
										    arg1663_468 = MAKE_PAIR(arg1658_464, arg1665_469);
										 }
										 arg1661_467 = MAKE_PAIR(arg1657_463, arg1663_468);
									      }
									      list1660_466 = MAKE_PAIR(arg1656_462, arg1661_467);
									   }
									   arg1610_428 = cons__138___r4_pairs_and_lists_6_3(arg1655_461, list1660_466);
									}
								     }
								     {
									obj_t list1613_430;
									{
									   obj_t arg1615_431;
									   {
									      obj_t arg1617_432;
									      {
										 obj_t arg1618_433;
										 arg1618_433 = MAKE_PAIR(BNIL, BNIL);
										 arg1617_432 = MAKE_PAIR(arg1610_428, arg1618_433);
									      }
									      arg1615_431 = MAKE_PAIR(arg1609_427, arg1617_432);
									   }
									   list1613_430 = MAKE_PAIR(arg1608_426, arg1615_431);
									}
									arg1580_404 = cons__138___r4_pairs_and_lists_6_3(arg1607_425, list1613_430);
								     }
								  }
								  {
								     obj_t list1582_406;
								     {
									obj_t arg1583_407;
									{
									   obj_t arg1584_408;
									   {
									      obj_t arg1585_409;
									      arg1585_409 = MAKE_PAIR(BNIL, BNIL);
									      arg1584_408 = MAKE_PAIR(arg1580_404, arg1585_409);
									   }
									   arg1583_407 = MAKE_PAIR(arg1578_403, arg1584_408);
									}
									list1582_406 = MAKE_PAIR(lname_94, arg1583_407);
								     }
								     arg1522_359 = cons__138___r4_pairs_and_lists_6_3(arg1575_402, list1582_406);
								  }
							       }
							       {
								  obj_t list1525_361;
								  {
								     obj_t arg1526_362;
								     {
									obj_t arg1527_363;
									arg1527_363 = MAKE_PAIR(BNIL, BNIL);
									arg1526_362 = MAKE_PAIR(arg1522_359, arg1527_363);
								     }
								     list1525_361 = MAKE_PAIR(arg1519_358, arg1526_362);
								  }
								  arg1211_119 = cons__138___r4_pairs_and_lists_6_3(arg1518_357, list1525_361);
							       }
							    }
							 }
						       else
							 {
							    {
							       obj_t arg1250_149;
							       obj_t arg1251_150;
							       obj_t arg1252_151;
							       arg1250_149 = CNST_TABLE_REF(((long) 5));
							       {
								  obj_t arg1258_157;
								  {
								     obj_t arg1263_161;
								     {
									obj_t arg1269_166;
									obj_t arg1270_167;
									obj_t arg1272_168;
									{
									   obj_t arg1282_174;
									   obj_t arg1283_175;
									   obj_t arg1284_176;
									   arg1282_174 = CNST_TABLE_REF(((long) 7));
									   arg1283_175 = CNST_TABLE_REF(((long) 11));
									   arg1284_176 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1286_178;
									      {
										 obj_t arg1287_179;
										 {
										    obj_t arg1288_180;
										    arg1288_180 = MAKE_PAIR(BNIL, BNIL);
										    arg1287_179 = MAKE_PAIR(arg1284_176, arg1288_180);
										 }
										 list1286_178 = MAKE_PAIR(arg1283_175, arg1287_179);
									      }
									      arg1269_166 = cons__138___r4_pairs_and_lists_6_3(arg1282_174, list1286_178);
									   }
									}
									{
									   obj_t arg1291_182;
									   {
									      obj_t arg1296_187;
									      {
										 obj_t arg1301_192;
										 obj_t arg1302_193;
										 obj_t arg1303_194;
										 arg1301_192 = CNST_TABLE_REF(((long) 7));
										 arg1302_193 = CNST_TABLE_REF(((long) 12));
										 arg1303_194 = CNST_TABLE_REF(((long) 9));
										 {
										    obj_t list1305_196;
										    {
										       obj_t arg1307_197;
										       {
											  obj_t arg1308_198;
											  arg1308_198 = MAKE_PAIR(BNIL, BNIL);
											  arg1307_197 = MAKE_PAIR(arg1303_194, arg1308_198);
										       }
										       list1305_196 = MAKE_PAIR(arg1302_193, arg1307_197);
										    }
										    arg1296_187 = cons__138___r4_pairs_and_lists_6_3(arg1301_192, list1305_196);
										 }
									      }
									      {
										 obj_t list1298_189;
										 {
										    obj_t arg1299_190;
										    arg1299_190 = MAKE_PAIR(BNIL, BNIL);
										    list1298_189 = MAKE_PAIR(l_93, arg1299_190);
										 }
										 arg1291_182 = cons__138___r4_pairs_and_lists_6_3(arg1296_187, list1298_189);
									      }
									   }
									   {
									      obj_t list1293_184;
									      {
										 obj_t arg1294_185;
										 arg1294_185 = MAKE_PAIR(BNIL, BNIL);
										 list1293_184 = MAKE_PAIR(arg1291_182, arg1294_185);
									      }
									      arg1270_167 = cons__138___r4_pairs_and_lists_6_3(fun_52, list1293_184);
									   }
									}
									{
									   obj_t arg1310_200;
									   arg1310_200 = CNST_TABLE_REF(((long) 10));
									   {
									      obj_t list1314_203;
									      {
										 obj_t arg1315_204;
										 arg1315_204 = MAKE_PAIR(BNIL, BNIL);
										 list1314_203 = MAKE_PAIR(BNIL, arg1315_204);
									      }
									      arg1272_168 = cons__138___r4_pairs_and_lists_6_3(arg1310_200, list1314_203);
									   }
									}
									{
									   obj_t list1274_170;
									   {
									      obj_t arg1277_171;
									      {
										 obj_t arg1278_172;
										 arg1278_172 = MAKE_PAIR(BNIL, BNIL);
										 arg1277_171 = MAKE_PAIR(arg1272_168, arg1278_172);
									      }
									      list1274_170 = MAKE_PAIR(arg1270_167, arg1277_171);
									   }
									   arg1263_161 = cons__138___r4_pairs_and_lists_6_3(arg1269_166, list1274_170);
									}
								     }
								     {
									obj_t list1266_163;
									{
									   obj_t arg1267_164;
									   arg1267_164 = MAKE_PAIR(BNIL, BNIL);
									   list1266_163 = MAKE_PAIR(arg1263_161, arg1267_164);
									}
									arg1258_157 = cons__138___r4_pairs_and_lists_6_3(head_95, list1266_163);
								     }
								  }
								  {
								     obj_t list1260_159;
								     list1260_159 = MAKE_PAIR(BNIL, BNIL);
								     arg1251_150 = cons__138___r4_pairs_and_lists_6_3(arg1258_157, list1260_159);
								  }
							       }
							       {
								  obj_t arg1319_206;
								  obj_t arg1321_207;
								  obj_t arg1322_208;
								  arg1319_206 = CNST_TABLE_REF(((long) 5));
								  {
								     obj_t arg1331_215;
								     obj_t arg1332_216;
								     {
									obj_t arg1340_221;
									{
									   obj_t arg1347_226;
									   {
									      obj_t arg1353_231;
									      obj_t arg1355_232;
									      obj_t arg1356_233;
									      arg1353_231 = CNST_TABLE_REF(((long) 7));
									      arg1355_232 = CNST_TABLE_REF(((long) 13));
									      arg1356_233 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list1358_235;
										 {
										    obj_t arg1361_236;
										    {
										       obj_t arg1363_237;
										       arg1363_237 = MAKE_PAIR(BNIL, BNIL);
										       arg1361_236 = MAKE_PAIR(arg1356_233, arg1363_237);
										    }
										    list1358_235 = MAKE_PAIR(arg1355_232, arg1361_236);
										 }
										 arg1347_226 = cons__138___r4_pairs_and_lists_6_3(arg1353_231, list1358_235);
									      }
									   }
									   {
									      obj_t list1350_228;
									      {
										 obj_t arg1351_229;
										 arg1351_229 = MAKE_PAIR(BNIL, BNIL);
										 list1350_228 = MAKE_PAIR(l_93, arg1351_229);
									      }
									      arg1340_221 = cons__138___r4_pairs_and_lists_6_3(arg1347_226, list1350_228);
									   }
									}
									{
									   obj_t list1343_223;
									   {
									      obj_t arg1344_224;
									      arg1344_224 = MAKE_PAIR(BNIL, BNIL);
									      list1343_223 = MAKE_PAIR(arg1340_221, arg1344_224);
									   }
									   arg1331_215 = cons__138___r4_pairs_and_lists_6_3(l_93, list1343_223);
									}
								     }
								     {
									obj_t list1366_240;
									{
									   obj_t arg1367_241;
									   arg1367_241 = MAKE_PAIR(BNIL, BNIL);
									   list1366_240 = MAKE_PAIR(head_95, arg1367_241);
									}
									arg1332_216 = cons__138___r4_pairs_and_lists_6_3(tail_96, list1366_240);
								     }
								     {
									obj_t list1334_218;
									{
									   obj_t arg1337_219;
									   arg1337_219 = MAKE_PAIR(BNIL, BNIL);
									   list1334_218 = MAKE_PAIR(arg1332_216, arg1337_219);
									}
									arg1321_207 = cons__138___r4_pairs_and_lists_6_3(arg1331_215, list1334_218);
								     }
								  }
								  {
								     obj_t arg1369_243;
								     obj_t arg1370_244;
								     obj_t arg1372_245;
								     arg1369_243 = CNST_TABLE_REF(((long) 6));
								     {
									obj_t arg1383_252;
									{
									   obj_t arg1389_257;
									   obj_t arg1390_258;
									   obj_t arg1391_259;
									   arg1389_257 = CNST_TABLE_REF(((long) 7));
									   arg1390_258 = CNST_TABLE_REF(((long) 8));
									   arg1391_259 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1393_261;
									      {
										 obj_t arg1395_262;
										 {
										    obj_t arg1396_263;
										    arg1396_263 = MAKE_PAIR(BNIL, BNIL);
										    arg1395_262 = MAKE_PAIR(arg1391_259, arg1396_263);
										 }
										 list1393_261 = MAKE_PAIR(arg1390_258, arg1395_262);
									      }
									      arg1383_252 = cons__138___r4_pairs_and_lists_6_3(arg1389_257, list1393_261);
									   }
									}
									{
									   obj_t list1385_254;
									   {
									      obj_t arg1387_255;
									      arg1387_255 = MAKE_PAIR(BNIL, BNIL);
									      list1385_254 = MAKE_PAIR(l_93, arg1387_255);
									   }
									   arg1370_244 = cons__138___r4_pairs_and_lists_6_3(arg1383_252, list1385_254);
									}
								     }
								     {
									obj_t arg1398_265;
									obj_t arg1399_266;
									obj_t arg1401_267;
									obj_t arg1402_268;
									arg1398_265 = CNST_TABLE_REF(((long) 5));
									{
									   obj_t arg1411_275;
									   {
									      obj_t arg1416_279;
									      {
										 obj_t arg1423_284;
										 obj_t arg1426_285;
										 obj_t arg1427_286;
										 {
										    obj_t arg1436_292;
										    obj_t arg1437_293;
										    obj_t arg1438_294;
										    arg1436_292 = CNST_TABLE_REF(((long) 7));
										    arg1437_293 = CNST_TABLE_REF(((long) 11));
										    arg1438_294 = CNST_TABLE_REF(((long) 9));
										    {
										       obj_t list1441_296;
										       {
											  obj_t arg1443_297;
											  {
											     obj_t arg1444_298;
											     arg1444_298 = MAKE_PAIR(BNIL, BNIL);
											     arg1443_297 = MAKE_PAIR(arg1438_294, arg1444_298);
											  }
											  list1441_296 = MAKE_PAIR(arg1437_293, arg1443_297);
										       }
										       arg1423_284 = cons__138___r4_pairs_and_lists_6_3(arg1436_292, list1441_296);
										    }
										 }
										 {
										    obj_t arg1448_300;
										    {
										       obj_t arg1455_305;
										       {
											  obj_t arg1461_310;
											  obj_t arg1463_311;
											  obj_t arg1464_312;
											  arg1461_310 = CNST_TABLE_REF(((long) 7));
											  arg1463_311 = CNST_TABLE_REF(((long) 12));
											  arg1464_312 = CNST_TABLE_REF(((long) 9));
											  {
											     obj_t list1466_314;
											     {
												obj_t arg1467_315;
												{
												   obj_t arg1468_316;
												   arg1468_316 = MAKE_PAIR(BNIL, BNIL);
												   arg1467_315 = MAKE_PAIR(arg1464_312, arg1468_316);
												}
												list1466_314 = MAKE_PAIR(arg1463_311, arg1467_315);
											     }
											     arg1455_305 = cons__138___r4_pairs_and_lists_6_3(arg1461_310, list1466_314);
											  }
										       }
										       {
											  obj_t list1457_307;
											  {
											     obj_t arg1458_308;
											     arg1458_308 = MAKE_PAIR(BNIL, BNIL);
											     list1457_307 = MAKE_PAIR(l_93, arg1458_308);
											  }
											  arg1448_300 = cons__138___r4_pairs_and_lists_6_3(arg1455_305, list1457_307);
										       }
										    }
										    {
										       obj_t list1450_302;
										       {
											  obj_t arg1453_303;
											  arg1453_303 = MAKE_PAIR(BNIL, BNIL);
											  list1450_302 = MAKE_PAIR(arg1448_300, arg1453_303);
										       }
										       arg1426_285 = cons__138___r4_pairs_and_lists_6_3(fun_52, list1450_302);
										    }
										 }
										 {
										    obj_t arg1470_318;
										    arg1470_318 = CNST_TABLE_REF(((long) 10));
										    {
										       obj_t list1474_321;
										       {
											  obj_t arg1475_322;
											  arg1475_322 = MAKE_PAIR(BNIL, BNIL);
											  list1474_321 = MAKE_PAIR(BNIL, arg1475_322);
										       }
										       arg1427_286 = cons__138___r4_pairs_and_lists_6_3(arg1470_318, list1474_321);
										    }
										 }
										 {
										    obj_t list1429_288;
										    {
										       obj_t arg1431_289;
										       {
											  obj_t arg1432_290;
											  arg1432_290 = MAKE_PAIR(BNIL, BNIL);
											  arg1431_289 = MAKE_PAIR(arg1427_286, arg1432_290);
										       }
										       list1429_288 = MAKE_PAIR(arg1426_285, arg1431_289);
										    }
										    arg1416_279 = cons__138___r4_pairs_and_lists_6_3(arg1423_284, list1429_288);
										 }
									      }
									      {
										 obj_t list1418_281;
										 {
										    obj_t arg1419_282;
										    arg1419_282 = MAKE_PAIR(BNIL, BNIL);
										    list1418_281 = MAKE_PAIR(arg1416_279, arg1419_282);
										 }
										 arg1411_275 = cons__138___r4_pairs_and_lists_6_3(ntail_97, list1418_281);
									      }
									   }
									   {
									      obj_t list1414_277;
									      list1414_277 = MAKE_PAIR(BNIL, BNIL);
									      arg1399_266 = cons__138___r4_pairs_and_lists_6_3(arg1411_275, list1414_277);
									   }
									}
									{
									   obj_t arg1477_324;
									   {
									      obj_t arg1484_330;
									      obj_t arg1485_331;
									      obj_t arg1486_332;
									      arg1484_330 = CNST_TABLE_REF(((long) 7));
									      arg1485_331 = CNST_TABLE_REF(((long) 14));
									      arg1486_332 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list1488_334;
										 {
										    obj_t arg1489_335;
										    {
										       obj_t arg1490_336;
										       arg1490_336 = MAKE_PAIR(BNIL, BNIL);
										       arg1489_335 = MAKE_PAIR(arg1486_332, arg1490_336);
										    }
										    list1488_334 = MAKE_PAIR(arg1485_331, arg1489_335);
										 }
										 arg1477_324 = cons__138___r4_pairs_and_lists_6_3(arg1484_330, list1488_334);
									      }
									   }
									   {
									      obj_t list1479_326;
									      {
										 obj_t arg1480_327;
										 {
										    obj_t arg1481_328;
										    arg1481_328 = MAKE_PAIR(BNIL, BNIL);
										    arg1480_327 = MAKE_PAIR(ntail_97, arg1481_328);
										 }
										 list1479_326 = MAKE_PAIR(tail_96, arg1480_327);
									      }
									      arg1401_267 = cons__138___r4_pairs_and_lists_6_3(arg1477_324, list1479_326);
									   }
									}
									{
									   obj_t arg1494_338;
									   {
									      obj_t arg1501_344;
									      {
										 obj_t arg1507_349;
										 obj_t arg1510_350;
										 obj_t arg1511_351;
										 arg1507_349 = CNST_TABLE_REF(((long) 7));
										 arg1510_350 = CNST_TABLE_REF(((long) 13));
										 arg1511_351 = CNST_TABLE_REF(((long) 9));
										 {
										    obj_t list1514_353;
										    {
										       obj_t arg1515_354;
										       {
											  obj_t arg1516_355;
											  arg1516_355 = MAKE_PAIR(BNIL, BNIL);
											  arg1515_354 = MAKE_PAIR(arg1511_351, arg1516_355);
										       }
										       list1514_353 = MAKE_PAIR(arg1510_350, arg1515_354);
										    }
										    arg1501_344 = cons__138___r4_pairs_and_lists_6_3(arg1507_349, list1514_353);
										 }
									      }
									      {
										 obj_t list1503_346;
										 {
										    obj_t arg1504_347;
										    arg1504_347 = MAKE_PAIR(BNIL, BNIL);
										    list1503_346 = MAKE_PAIR(l_93, arg1504_347);
										 }
										 arg1494_338 = cons__138___r4_pairs_and_lists_6_3(arg1501_344, list1503_346);
									      }
									   }
									   {
									      obj_t list1497_340;
									      {
										 obj_t arg1498_341;
										 {
										    obj_t arg1499_342;
										    arg1499_342 = MAKE_PAIR(BNIL, BNIL);
										    arg1498_341 = MAKE_PAIR(ntail_97, arg1499_342);
										 }
										 list1497_340 = MAKE_PAIR(arg1494_338, arg1498_341);
									      }
									      arg1402_268 = cons__138___r4_pairs_and_lists_6_3(lname_94, list1497_340);
									   }
									}
									{
									   obj_t list1404_270;
									   {
									      obj_t arg1405_271;
									      {
										 obj_t arg1407_272;
										 {
										    obj_t arg1408_273;
										    arg1408_273 = MAKE_PAIR(BNIL, BNIL);
										    arg1407_272 = MAKE_PAIR(arg1402_268, arg1408_273);
										 }
										 arg1405_271 = MAKE_PAIR(arg1401_267, arg1407_272);
									      }
									      list1404_270 = MAKE_PAIR(arg1399_266, arg1405_271);
									   }
									   arg1372_245 = cons__138___r4_pairs_and_lists_6_3(arg1398_265, list1404_270);
									}
								     }
								     {
									obj_t list1374_247;
									{
									   obj_t arg1375_248;
									   {
									      obj_t arg1378_249;
									      {
										 obj_t arg1379_250;
										 arg1379_250 = MAKE_PAIR(BNIL, BNIL);
										 arg1378_249 = MAKE_PAIR(arg1372_245, arg1379_250);
									      }
									      arg1375_248 = MAKE_PAIR(head_95, arg1378_249);
									   }
									   list1374_247 = MAKE_PAIR(arg1370_244, arg1375_248);
									}
									arg1322_208 = cons__138___r4_pairs_and_lists_6_3(arg1369_243, list1374_247);
								     }
								  }
								  {
								     obj_t list1324_210;
								     {
									obj_t arg1325_211;
									{
									   obj_t arg1326_212;
									   {
									      obj_t arg1328_213;
									      arg1328_213 = MAKE_PAIR(BNIL, BNIL);
									      arg1326_212 = MAKE_PAIR(arg1322_208, arg1328_213);
									   }
									   arg1325_211 = MAKE_PAIR(arg1321_207, arg1326_212);
									}
									list1324_210 = MAKE_PAIR(lname_94, arg1325_211);
								     }
								     arg1252_151 = cons__138___r4_pairs_and_lists_6_3(arg1319_206, list1324_210);
								  }
							       }
							       {
								  obj_t list1254_153;
								  {
								     obj_t arg1255_154;
								     {
									obj_t arg1256_155;
									arg1256_155 = MAKE_PAIR(BNIL, BNIL);
									arg1255_154 = MAKE_PAIR(arg1252_151, arg1256_155);
								     }
								     list1254_153 = MAKE_PAIR(arg1251_150, arg1255_154);
								  }
								  arg1211_119 = cons__138___r4_pairs_and_lists_6_3(arg1250_149, list1254_153);
							       }
							    }
							 }
						    }
						    {
						       obj_t list1214_121;
						       {
							  obj_t arg1216_122;
							  {
							     obj_t arg1219_123;
							     {
								obj_t arg1220_124;
								arg1220_124 = MAKE_PAIR(BNIL, BNIL);
								arg1219_123 = MAKE_PAIR(arg1211_119, arg1220_124);
							     }
							     arg1216_122 = MAKE_PAIR(arg1210_118, arg1219_123);
							  }
							  list1214_121 = MAKE_PAIR(arg1209_117, arg1216_122);
						       }
						       arg1192_102 = cons__138___r4_pairs_and_lists_6_3(arg1207_116, list1214_121);
						    }
						 }
						 {
						    obj_t list1194_104;
						    {
						       obj_t arg1195_105;
						       {
							  obj_t arg1196_106;
							  arg1196_106 = MAKE_PAIR(BNIL, BNIL);
							  arg1195_105 = MAKE_PAIR(arg1192_102, arg1196_106);
						       }
						       list1194_104 = MAKE_PAIR(arg1191_101, arg1195_105);
						    }
						    loop_98 = cons__138___r4_pairs_and_lists_6_3(arg1190_100, list1194_104);
						 }
					      }
					    else
					      {
						 obj_t arg1766_553;
						 obj_t arg1767_554;
						 obj_t arg1768_555;
						 arg1766_553 = CNST_TABLE_REF(((long) 5));
						 {
						    obj_t arg1774_561;
						    {
						       obj_t list1780_566;
						       {
							  obj_t arg1781_567;
							  arg1781_567 = MAKE_PAIR(BNIL, BNIL);
							  list1780_566 = MAKE_PAIR(list_53, arg1781_567);
						       }
						       arg1774_561 = cons__138___r4_pairs_and_lists_6_3(l_93, list1780_566);
						    }
						    {
						       obj_t list1777_563;
						       list1777_563 = MAKE_PAIR(BNIL, BNIL);
						       arg1767_554 = cons__138___r4_pairs_and_lists_6_3(arg1774_561, list1777_563);
						    }
						 }
						 {
						    obj_t arg1786_569;
						    obj_t arg1788_570;
						    obj_t arg1789_571;
						    obj_t arg1790_572;
						    arg1786_569 = CNST_TABLE_REF(((long) 6));
						    {
						       obj_t arg1797_579;
						       {
							  obj_t arg1804_584;
							  obj_t arg1805_585;
							  obj_t arg1806_586;
							  arg1804_584 = CNST_TABLE_REF(((long) 7));
							  arg1805_585 = CNST_TABLE_REF(((long) 8));
							  arg1806_586 = CNST_TABLE_REF(((long) 9));
							  {
							     obj_t list1808_588;
							     {
								obj_t arg1809_589;
								{
								   obj_t arg1810_590;
								   arg1810_590 = MAKE_PAIR(BNIL, BNIL);
								   arg1809_589 = MAKE_PAIR(arg1806_586, arg1810_590);
								}
								list1808_588 = MAKE_PAIR(arg1805_585, arg1809_589);
							     }
							     arg1797_579 = cons__138___r4_pairs_and_lists_6_3(arg1804_584, list1808_588);
							  }
						       }
						       {
							  obj_t list1800_581;
							  {
							     obj_t arg1802_582;
							     arg1802_582 = MAKE_PAIR(BNIL, BNIL);
							     list1800_581 = MAKE_PAIR(l_93, arg1802_582);
							  }
							  arg1788_570 = cons__138___r4_pairs_and_lists_6_3(arg1797_579, list1800_581);
						       }
						    }
						    {
						       obj_t arg1812_592;
						       arg1812_592 = CNST_TABLE_REF(((long) 10));
						       {
							  obj_t list1815_595;
							  {
							     obj_t arg1816_596;
							     arg1816_596 = MAKE_PAIR(BNIL, BNIL);
							     list1815_595 = MAKE_PAIR(BNIL, arg1816_596);
							  }
							  arg1789_571 = cons__138___r4_pairs_and_lists_6_3(arg1812_592, list1815_595);
						       }
						    }
						    {
						       if (PAIRP(fun_52))
							 {
							    {
							       obj_t arg2108_858;
							       obj_t arg2109_859;
							       obj_t arg2111_860;
							       arg2108_858 = CNST_TABLE_REF(((long) 5));
							       {
								  obj_t arg2117_866;
								  {
								     obj_t arg2123_870;
								     {
									obj_t arg2131_875;
									obj_t arg2132_876;
									obj_t arg2133_877;
									{
									   obj_t arg2139_883;
									   obj_t arg2140_884;
									   obj_t arg2141_885;
									   arg2139_883 = CNST_TABLE_REF(((long) 7));
									   arg2140_884 = CNST_TABLE_REF(((long) 11));
									   arg2141_885 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list2144_887;
									      {
										 obj_t arg2145_888;
										 {
										    obj_t arg2146_889;
										    arg2146_889 = MAKE_PAIR(BNIL, BNIL);
										    arg2145_888 = MAKE_PAIR(arg2141_885, arg2146_889);
										 }
										 list2144_887 = MAKE_PAIR(arg2140_884, arg2145_888);
									      }
									      arg2131_875 = cons__138___r4_pairs_and_lists_6_3(arg2139_883, list2144_887);
									   }
									}
									{
									   obj_t arg2148_891;
									   arg2148_891 = CNST_TABLE_REF(((long) 10));
									   {
									      obj_t list2151_894;
									      {
										 obj_t arg2152_895;
										 arg2152_895 = MAKE_PAIR(BNIL, BNIL);
										 list2151_894 = MAKE_PAIR(BNIL, arg2152_895);
									      }
									      arg2132_876 = cons__138___r4_pairs_and_lists_6_3(arg2148_891, list2151_894);
									   }
									}
									{
									   obj_t arg2154_897;
									   arg2154_897 = CNST_TABLE_REF(((long) 10));
									   {
									      obj_t list2157_900;
									      {
										 obj_t arg2158_901;
										 arg2158_901 = MAKE_PAIR(BNIL, BNIL);
										 list2157_900 = MAKE_PAIR(BNIL, arg2158_901);
									      }
									      arg2133_877 = cons__138___r4_pairs_and_lists_6_3(arg2154_897, list2157_900);
									   }
									}
									{
									   obj_t list2135_879;
									   {
									      obj_t arg2136_880;
									      {
										 obj_t arg2137_881;
										 arg2137_881 = MAKE_PAIR(BNIL, BNIL);
										 arg2136_880 = MAKE_PAIR(arg2133_877, arg2137_881);
									      }
									      list2135_879 = MAKE_PAIR(arg2132_876, arg2136_880);
									   }
									   arg2123_870 = cons__138___r4_pairs_and_lists_6_3(arg2131_875, list2135_879);
									}
								     }
								     {
									obj_t list2125_872;
									{
									   obj_t arg2127_873;
									   arg2127_873 = MAKE_PAIR(BNIL, BNIL);
									   list2125_872 = MAKE_PAIR(arg2123_870, arg2127_873);
									}
									arg2117_866 = cons__138___r4_pairs_and_lists_6_3(head_95, list2125_872);
								     }
								  }
								  {
								     obj_t list2121_868;
								     list2121_868 = MAKE_PAIR(BNIL, BNIL);
								     arg2109_859 = cons__138___r4_pairs_and_lists_6_3(arg2117_866, list2121_868);
								  }
							       }
							       {
								  obj_t arg2160_903;
								  obj_t arg2161_904;
								  obj_t arg2162_905;
								  arg2160_903 = CNST_TABLE_REF(((long) 5));
								  {
								     obj_t arg2170_912;
								     obj_t arg2172_913;
								     {
									obj_t list2179_919;
									{
									   obj_t arg2180_920;
									   arg2180_920 = MAKE_PAIR(BNIL, BNIL);
									   list2179_919 = MAKE_PAIR(l_93, arg2180_920);
									}
									arg2170_912 = cons__138___r4_pairs_and_lists_6_3(l_93, list2179_919);
								     }
								     {
									obj_t list2183_923;
									{
									   obj_t arg2184_924;
									   arg2184_924 = MAKE_PAIR(BNIL, BNIL);
									   list2183_923 = MAKE_PAIR(head_95, arg2184_924);
									}
									arg2172_913 = cons__138___r4_pairs_and_lists_6_3(tail_96, list2183_923);
								     }
								     {
									obj_t list2174_915;
									{
									   obj_t arg2175_916;
									   arg2175_916 = MAKE_PAIR(BNIL, BNIL);
									   list2174_915 = MAKE_PAIR(arg2172_913, arg2175_916);
									}
									arg2161_904 = cons__138___r4_pairs_and_lists_6_3(arg2170_912, list2174_915);
								     }
								  }
								  {
								     obj_t arg2186_926;
								     obj_t arg2187_927;
								     obj_t arg2188_928;
								     obj_t arg2189_929;
								     arg2186_926 = CNST_TABLE_REF(((long) 15));
								     {
									obj_t arg2197_936;
									obj_t arg2198_937;
									{
									   obj_t arg2204_942;
									   {
									      obj_t arg2209_947;
									      obj_t arg2210_948;
									      obj_t arg2211_949;
									      arg2209_947 = CNST_TABLE_REF(((long) 7));
									      arg2210_948 = CNST_TABLE_REF(((long) 16));
									      arg2211_949 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list2214_951;
										 {
										    obj_t arg2215_952;
										    {
										       obj_t arg2216_953;
										       arg2216_953 = MAKE_PAIR(BNIL, BNIL);
										       arg2215_952 = MAKE_PAIR(arg2211_949, arg2216_953);
										    }
										    list2214_951 = MAKE_PAIR(arg2210_948, arg2215_952);
										 }
										 arg2204_942 = cons__138___r4_pairs_and_lists_6_3(arg2209_947, list2214_951);
									      }
									   }
									   {
									      obj_t list2206_944;
									      {
										 obj_t arg2207_945;
										 arg2207_945 = MAKE_PAIR(BNIL, BNIL);
										 list2206_944 = MAKE_PAIR(l_93, arg2207_945);
									      }
									      arg2197_936 = cons__138___r4_pairs_and_lists_6_3(arg2204_942, list2206_944);
									   }
									}
									{
									   obj_t arg2219_955;
									   obj_t arg2220_956;
									   obj_t arg2221_957;
									   obj_t arg2222_958;
									   arg2219_955 = CNST_TABLE_REF(((long) 5));
									   {
									      obj_t arg2229_965;
									      {
										 obj_t arg2233_969;
										 {
										    obj_t arg2238_974;
										    obj_t arg2239_975;
										    obj_t arg2240_976;
										    {
										       obj_t arg2247_982;
										       obj_t arg2248_983;
										       obj_t arg2250_984;
										       arg2247_982 = CNST_TABLE_REF(((long) 7));
										       arg2248_983 = CNST_TABLE_REF(((long) 11));
										       arg2250_984 = CNST_TABLE_REF(((long) 9));
										       {
											  obj_t list2253_986;
											  {
											     obj_t arg2254_987;
											     {
												obj_t arg2256_988;
												arg2256_988 = MAKE_PAIR(BNIL, BNIL);
												arg2254_987 = MAKE_PAIR(arg2250_984, arg2256_988);
											     }
											     list2253_986 = MAKE_PAIR(arg2248_983, arg2254_987);
											  }
											  arg2238_974 = cons__138___r4_pairs_and_lists_6_3(arg2247_982, list2253_986);
										       }
										    }
										    {
										       obj_t arg2258_990;
										       {
											  obj_t arg2264_995;
											  {
											     obj_t arg2269_1000;
											     obj_t arg2270_1001;
											     obj_t arg2271_1002;
											     arg2269_1000 = CNST_TABLE_REF(((long) 7));
											     arg2270_1001 = CNST_TABLE_REF(((long) 12));
											     arg2271_1002 = CNST_TABLE_REF(((long) 9));
											     {
												obj_t list2273_1004;
												{
												   obj_t arg2274_1005;
												   {
												      obj_t arg2275_1006;
												      arg2275_1006 = MAKE_PAIR(BNIL, BNIL);
												      arg2274_1005 = MAKE_PAIR(arg2271_1002, arg2275_1006);
												   }
												   list2273_1004 = MAKE_PAIR(arg2270_1001, arg2274_1005);
												}
												arg2264_995 = cons__138___r4_pairs_and_lists_6_3(arg2269_1000, list2273_1004);
											     }
											  }
											  {
											     obj_t list2266_997;
											     {
												obj_t arg2267_998;
												arg2267_998 = MAKE_PAIR(BNIL, BNIL);
												list2266_997 = MAKE_PAIR(l_93, arg2267_998);
											     }
											     arg2258_990 = cons__138___r4_pairs_and_lists_6_3(arg2264_995, list2266_997);
											  }
										       }
										       {
											  obj_t list2260_992;
											  {
											     obj_t arg2261_993;
											     arg2261_993 = MAKE_PAIR(BNIL, BNIL);
											     list2260_992 = MAKE_PAIR(arg2258_990, arg2261_993);
											  }
											  arg2239_975 = cons__138___r4_pairs_and_lists_6_3(fun_52, list2260_992);
										       }
										    }
										    {
										       obj_t arg2277_1008;
										       arg2277_1008 = CNST_TABLE_REF(((long) 10));
										       {
											  obj_t list2280_1011;
											  {
											     obj_t arg2281_1012;
											     arg2281_1012 = MAKE_PAIR(BNIL, BNIL);
											     list2280_1011 = MAKE_PAIR(BNIL, arg2281_1012);
											  }
											  arg2240_976 = cons__138___r4_pairs_and_lists_6_3(arg2277_1008, list2280_1011);
										       }
										    }
										    {
										       obj_t list2242_978;
										       {
											  obj_t arg2243_979;
											  {
											     obj_t arg2244_980;
											     arg2244_980 = MAKE_PAIR(BNIL, BNIL);
											     arg2243_979 = MAKE_PAIR(arg2240_976, arg2244_980);
											  }
											  list2242_978 = MAKE_PAIR(arg2239_975, arg2243_979);
										       }
										       arg2233_969 = cons__138___r4_pairs_and_lists_6_3(arg2238_974, list2242_978);
										    }
										 }
										 {
										    obj_t list2235_971;
										    {
										       obj_t arg2236_972;
										       arg2236_972 = MAKE_PAIR(BNIL, BNIL);
										       list2235_971 = MAKE_PAIR(arg2233_969, arg2236_972);
										    }
										    arg2229_965 = cons__138___r4_pairs_and_lists_6_3(ntail_97, list2235_971);
										 }
									      }
									      {
										 obj_t list2231_967;
										 list2231_967 = MAKE_PAIR(BNIL, BNIL);
										 arg2220_956 = cons__138___r4_pairs_and_lists_6_3(arg2229_965, list2231_967);
									      }
									   }
									   {
									      obj_t arg2283_1014;
									      {
										 obj_t arg2289_1020;
										 obj_t arg2291_1021;
										 obj_t arg2292_1022;
										 arg2289_1020 = CNST_TABLE_REF(((long) 7));
										 arg2291_1021 = CNST_TABLE_REF(((long) 14));
										 arg2292_1022 = CNST_TABLE_REF(((long) 9));
										 {
										    obj_t list2294_1024;
										    {
										       obj_t arg2295_1025;
										       {
											  obj_t arg2297_1026;
											  arg2297_1026 = MAKE_PAIR(BNIL, BNIL);
											  arg2295_1025 = MAKE_PAIR(arg2292_1022, arg2297_1026);
										       }
										       list2294_1024 = MAKE_PAIR(arg2291_1021, arg2295_1025);
										    }
										    arg2283_1014 = cons__138___r4_pairs_and_lists_6_3(arg2289_1020, list2294_1024);
										 }
									      }
									      {
										 obj_t list2285_1016;
										 {
										    obj_t arg2286_1017;
										    {
										       obj_t arg2287_1018;
										       arg2287_1018 = MAKE_PAIR(BNIL, BNIL);
										       arg2286_1017 = MAKE_PAIR(ntail_97, arg2287_1018);
										    }
										    list2285_1016 = MAKE_PAIR(tail_96, arg2286_1017);
										 }
										 arg2221_957 = cons__138___r4_pairs_and_lists_6_3(arg2283_1014, list2285_1016);
									      }
									   }
									   {
									      obj_t arg2299_1028;
									      {
										 obj_t arg2305_1034;
										 {
										    obj_t arg2310_1039;
										    obj_t arg2311_1040;
										    obj_t arg2312_1041;
										    arg2310_1039 = CNST_TABLE_REF(((long) 7));
										    arg2311_1040 = CNST_TABLE_REF(((long) 13));
										    arg2312_1041 = CNST_TABLE_REF(((long) 9));
										    {
										       obj_t list2317_1043;
										       {
											  obj_t arg2319_1044;
											  {
											     obj_t arg2320_1045;
											     arg2320_1045 = MAKE_PAIR(BNIL, BNIL);
											     arg2319_1044 = MAKE_PAIR(arg2312_1041, arg2320_1045);
											  }
											  list2317_1043 = MAKE_PAIR(arg2311_1040, arg2319_1044);
										       }
										       arg2305_1034 = cons__138___r4_pairs_and_lists_6_3(arg2310_1039, list2317_1043);
										    }
										 }
										 {
										    obj_t list2307_1036;
										    {
										       obj_t arg2308_1037;
										       arg2308_1037 = MAKE_PAIR(BNIL, BNIL);
										       list2307_1036 = MAKE_PAIR(l_93, arg2308_1037);
										    }
										    arg2299_1028 = cons__138___r4_pairs_and_lists_6_3(arg2305_1034, list2307_1036);
										 }
									      }
									      {
										 obj_t list2301_1030;
										 {
										    obj_t arg2302_1031;
										    {
										       obj_t arg2303_1032;
										       arg2303_1032 = MAKE_PAIR(BNIL, BNIL);
										       arg2302_1031 = MAKE_PAIR(ntail_97, arg2303_1032);
										    }
										    list2301_1030 = MAKE_PAIR(arg2299_1028, arg2302_1031);
										 }
										 arg2222_958 = cons__138___r4_pairs_and_lists_6_3(lname_94, list2301_1030);
									      }
									   }
									   {
									      obj_t list2224_960;
									      {
										 obj_t arg2225_961;
										 {
										    obj_t arg2226_962;
										    {
										       obj_t arg2227_963;
										       arg2227_963 = MAKE_PAIR(BNIL, BNIL);
										       arg2226_962 = MAKE_PAIR(arg2222_958, arg2227_963);
										    }
										    arg2225_961 = MAKE_PAIR(arg2221_957, arg2226_962);
										 }
										 list2224_960 = MAKE_PAIR(arg2220_956, arg2225_961);
									      }
									      arg2198_937 = cons__138___r4_pairs_and_lists_6_3(arg2219_955, list2224_960);
									   }
									}
									{
									   obj_t list2200_939;
									   {
									      obj_t arg2201_940;
									      arg2201_940 = MAKE_PAIR(BNIL, BNIL);
									      list2200_939 = MAKE_PAIR(arg2198_937, arg2201_940);
									   }
									   arg2187_927 = cons__138___r4_pairs_and_lists_6_3(arg2197_936, list2200_939);
									}
								     }
								     {
									obj_t arg2323_1047;
									obj_t arg2324_1048;
									{
									   obj_t arg2329_1053;
									   {
									      obj_t arg2334_1058;
									      obj_t arg2335_1059;
									      obj_t arg2336_1060;
									      arg2334_1058 = CNST_TABLE_REF(((long) 7));
									      arg2335_1059 = CNST_TABLE_REF(((long) 8));
									      arg2336_1060 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list2338_1062;
										 {
										    obj_t arg2339_1063;
										    {
										       obj_t arg2340_1064;
										       arg2340_1064 = MAKE_PAIR(BNIL, BNIL);
										       arg2339_1063 = MAKE_PAIR(arg2336_1060, arg2340_1064);
										    }
										    list2338_1062 = MAKE_PAIR(arg2335_1059, arg2339_1063);
										 }
										 arg2329_1053 = cons__138___r4_pairs_and_lists_6_3(arg2334_1058, list2338_1062);
									      }
									   }
									   {
									      obj_t list2331_1055;
									      {
										 obj_t arg2332_1056;
										 arg2332_1056 = MAKE_PAIR(BNIL, BNIL);
										 list2331_1055 = MAKE_PAIR(l_93, arg2332_1056);
									      }
									      arg2323_1047 = cons__138___r4_pairs_and_lists_6_3(arg2329_1053, list2331_1055);
									   }
									}
									{
									   obj_t arg2342_1066;
									   {
									      obj_t arg2347_1071;
									      obj_t arg2348_1072;
									      obj_t arg2349_1073;
									      arg2347_1071 = CNST_TABLE_REF(((long) 7));
									      arg2348_1072 = CNST_TABLE_REF(((long) 13));
									      arg2349_1073 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list2351_1075;
										 {
										    obj_t arg2352_1076;
										    {
										       obj_t arg2353_1077;
										       arg2353_1077 = MAKE_PAIR(BNIL, BNIL);
										       arg2352_1076 = MAKE_PAIR(arg2349_1073, arg2353_1077);
										    }
										    list2351_1075 = MAKE_PAIR(arg2348_1072, arg2352_1076);
										 }
										 arg2342_1066 = cons__138___r4_pairs_and_lists_6_3(arg2347_1071, list2351_1075);
									      }
									   }
									   {
									      obj_t list2344_1068;
									      {
										 obj_t arg2345_1069;
										 arg2345_1069 = MAKE_PAIR(BNIL, BNIL);
										 list2344_1068 = MAKE_PAIR(head_95, arg2345_1069);
									      }
									      arg2324_1048 = cons__138___r4_pairs_and_lists_6_3(arg2342_1066, list2344_1068);
									   }
									}
									{
									   obj_t list2326_1050;
									   {
									      obj_t arg2327_1051;
									      arg2327_1051 = MAKE_PAIR(BNIL, BNIL);
									      list2326_1050 = MAKE_PAIR(arg2324_1048, arg2327_1051);
									   }
									   arg2188_928 = cons__138___r4_pairs_and_lists_6_3(arg2323_1047, list2326_1050);
									}
								     }
								     {
									obj_t arg2355_1079;
									obj_t arg2356_1080;
									arg2355_1079 = CNST_TABLE_REF(((long) 17));
									{
									   obj_t arg2361_1085;
									   {
									      obj_t arg2371_1094;
									      obj_t arg2372_1095;
									      obj_t arg2373_1096;
									      arg2371_1094 = CNST_TABLE_REF(((long) 7));
									      arg2372_1095 = CNST_TABLE_REF(((long) 18));
									      arg2373_1096 = CNST_TABLE_REF(((long) 19));
									      {
										 obj_t list2375_1098;
										 {
										    obj_t arg2376_1099;
										    {
										       obj_t arg2377_1100;
										       arg2377_1100 = MAKE_PAIR(BNIL, BNIL);
										       arg2376_1099 = MAKE_PAIR(arg2373_1096, arg2377_1100);
										    }
										    list2375_1098 = MAKE_PAIR(arg2372_1095, arg2376_1099);
										 }
										 arg2361_1085 = cons__138___r4_pairs_and_lists_6_3(arg2371_1094, list2375_1098);
									      }
									   }
									   {
									      obj_t list2366_1089;
									      {
										 obj_t arg2367_1090;
										 {
										    obj_t arg2368_1091;
										    {
										       obj_t arg2369_1092;
										       arg2369_1092 = MAKE_PAIR(BNIL, BNIL);
										       arg2368_1091 = MAKE_PAIR(l_93, arg2369_1092);
										    }
										    arg2367_1090 = MAKE_PAIR(string3394_expand_map, arg2368_1091);
										 }
										 list2366_1089 = MAKE_PAIR(string3395_expand_map, arg2367_1090);
									      }
									      arg2356_1080 = cons__138___r4_pairs_and_lists_6_3(arg2361_1085, list2366_1089);
									   }
									}
									{
									   obj_t list2358_1082;
									   {
									      obj_t arg2359_1083;
									      arg2359_1083 = MAKE_PAIR(BNIL, BNIL);
									      list2358_1082 = MAKE_PAIR(arg2356_1080, arg2359_1083);
									   }
									   arg2189_929 = cons__138___r4_pairs_and_lists_6_3(arg2355_1079, list2358_1082);
									}
								     }
								     {
									obj_t list2191_931;
									{
									   obj_t arg2192_932;
									   {
									      obj_t arg2193_933;
									      {
										 obj_t arg2194_934;
										 arg2194_934 = MAKE_PAIR(BNIL, BNIL);
										 arg2193_933 = MAKE_PAIR(arg2189_929, arg2194_934);
									      }
									      arg2192_932 = MAKE_PAIR(arg2188_928, arg2193_933);
									   }
									   list2191_931 = MAKE_PAIR(arg2187_927, arg2192_932);
									}
									arg2162_905 = cons__138___r4_pairs_and_lists_6_3(arg2186_926, list2191_931);
								     }
								  }
								  {
								     obj_t list2164_907;
								     {
									obj_t arg2165_908;
									{
									   obj_t arg2166_909;
									   {
									      obj_t arg2167_910;
									      arg2167_910 = MAKE_PAIR(BNIL, BNIL);
									      arg2166_909 = MAKE_PAIR(arg2162_905, arg2167_910);
									   }
									   arg2165_908 = MAKE_PAIR(arg2161_904, arg2166_909);
									}
									list2164_907 = MAKE_PAIR(lname_94, arg2165_908);
								     }
								     arg2111_860 = cons__138___r4_pairs_and_lists_6_3(arg2160_903, list2164_907);
								  }
							       }
							       {
								  obj_t list2113_862;
								  {
								     obj_t arg2114_863;
								     {
									obj_t arg2115_864;
									arg2115_864 = MAKE_PAIR(BNIL, BNIL);
									arg2114_863 = MAKE_PAIR(arg2111_860, arg2115_864);
								     }
								     list2113_862 = MAKE_PAIR(arg2109_859, arg2114_863);
								  }
								  arg1790_572 = cons__138___r4_pairs_and_lists_6_3(arg2108_858, list2113_862);
							       }
							    }
							 }
						       else
							 {
							    {
							       obj_t arg1820_602;
							       obj_t arg1821_603;
							       obj_t arg1822_604;
							       arg1820_602 = CNST_TABLE_REF(((long) 5));
							       {
								  obj_t arg1830_610;
								  {
								     obj_t arg1834_614;
								     {
									obj_t arg1839_619;
									obj_t arg1842_620;
									obj_t arg1843_621;
									{
									   obj_t arg1853_627;
									   obj_t arg1856_628;
									   obj_t arg1857_629;
									   arg1853_627 = CNST_TABLE_REF(((long) 7));
									   arg1856_628 = CNST_TABLE_REF(((long) 11));
									   arg1857_629 = CNST_TABLE_REF(((long) 9));
									   {
									      obj_t list1859_631;
									      {
										 obj_t arg1860_632;
										 {
										    obj_t arg1861_633;
										    arg1861_633 = MAKE_PAIR(BNIL, BNIL);
										    arg1860_632 = MAKE_PAIR(arg1857_629, arg1861_633);
										 }
										 list1859_631 = MAKE_PAIR(arg1856_628, arg1860_632);
									      }
									      arg1839_619 = cons__138___r4_pairs_and_lists_6_3(arg1853_627, list1859_631);
									   }
									}
									{
									   obj_t arg1863_635;
									   {
									      obj_t arg1868_640;
									      {
										 obj_t arg1875_645;
										 obj_t arg1876_646;
										 obj_t arg1877_647;
										 arg1875_645 = CNST_TABLE_REF(((long) 7));
										 arg1876_646 = CNST_TABLE_REF(((long) 12));
										 arg1877_647 = CNST_TABLE_REF(((long) 9));
										 {
										    obj_t list1879_649;
										    {
										       obj_t arg1880_650;
										       {
											  obj_t arg1881_651;
											  arg1881_651 = MAKE_PAIR(BNIL, BNIL);
											  arg1880_650 = MAKE_PAIR(arg1877_647, arg1881_651);
										       }
										       list1879_649 = MAKE_PAIR(arg1876_646, arg1880_650);
										    }
										    arg1868_640 = cons__138___r4_pairs_and_lists_6_3(arg1875_645, list1879_649);
										 }
									      }
									      {
										 obj_t list1870_642;
										 {
										    obj_t arg1871_643;
										    arg1871_643 = MAKE_PAIR(BNIL, BNIL);
										    list1870_642 = MAKE_PAIR(l_93, arg1871_643);
										 }
										 arg1863_635 = cons__138___r4_pairs_and_lists_6_3(arg1868_640, list1870_642);
									      }
									   }
									   {
									      obj_t list1865_637;
									      {
										 obj_t arg1866_638;
										 arg1866_638 = MAKE_PAIR(BNIL, BNIL);
										 list1865_637 = MAKE_PAIR(arg1863_635, arg1866_638);
									      }
									      arg1842_620 = cons__138___r4_pairs_and_lists_6_3(fun_52, list1865_637);
									   }
									}
									{
									   obj_t arg1884_653;
									   arg1884_653 = CNST_TABLE_REF(((long) 10));
									   {
									      obj_t list1887_656;
									      {
										 obj_t arg1888_657;
										 arg1888_657 = MAKE_PAIR(BNIL, BNIL);
										 list1887_656 = MAKE_PAIR(BNIL, arg1888_657);
									      }
									      arg1843_621 = cons__138___r4_pairs_and_lists_6_3(arg1884_653, list1887_656);
									   }
									}
									{
									   obj_t list1848_623;
									   {
									      obj_t arg1850_624;
									      {
										 obj_t arg1851_625;
										 arg1851_625 = MAKE_PAIR(BNIL, BNIL);
										 arg1850_624 = MAKE_PAIR(arg1843_621, arg1851_625);
									      }
									      list1848_623 = MAKE_PAIR(arg1842_620, arg1850_624);
									   }
									   arg1834_614 = cons__138___r4_pairs_and_lists_6_3(arg1839_619, list1848_623);
									}
								     }
								     {
									obj_t list1836_616;
									{
									   obj_t arg1837_617;
									   arg1837_617 = MAKE_PAIR(BNIL, BNIL);
									   list1836_616 = MAKE_PAIR(arg1834_614, arg1837_617);
									}
									arg1830_610 = cons__138___r4_pairs_and_lists_6_3(head_95, list1836_616);
								     }
								  }
								  {
								     obj_t list1832_612;
								     list1832_612 = MAKE_PAIR(BNIL, BNIL);
								     arg1821_603 = cons__138___r4_pairs_and_lists_6_3(arg1830_610, list1832_612);
								  }
							       }
							       {
								  obj_t arg1892_659;
								  obj_t arg1893_660;
								  obj_t arg1894_661;
								  arg1892_659 = CNST_TABLE_REF(((long) 5));
								  {
								     obj_t arg1901_668;
								     obj_t arg1902_669;
								     {
									obj_t arg1907_674;
									{
									   obj_t arg1913_679;
									   {
									      obj_t arg1918_684;
									      obj_t arg1919_685;
									      obj_t arg1920_686;
									      arg1918_684 = CNST_TABLE_REF(((long) 7));
									      arg1919_685 = CNST_TABLE_REF(((long) 13));
									      arg1920_686 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list1922_688;
										 {
										    obj_t arg1923_689;
										    {
										       obj_t arg1924_690;
										       arg1924_690 = MAKE_PAIR(BNIL, BNIL);
										       arg1923_689 = MAKE_PAIR(arg1920_686, arg1924_690);
										    }
										    list1922_688 = MAKE_PAIR(arg1919_685, arg1923_689);
										 }
										 arg1913_679 = cons__138___r4_pairs_and_lists_6_3(arg1918_684, list1922_688);
									      }
									   }
									   {
									      obj_t list1915_681;
									      {
										 obj_t arg1916_682;
										 arg1916_682 = MAKE_PAIR(BNIL, BNIL);
										 list1915_681 = MAKE_PAIR(l_93, arg1916_682);
									      }
									      arg1907_674 = cons__138___r4_pairs_and_lists_6_3(arg1913_679, list1915_681);
									   }
									}
									{
									   obj_t list1910_676;
									   {
									      obj_t arg1911_677;
									      arg1911_677 = MAKE_PAIR(BNIL, BNIL);
									      list1910_676 = MAKE_PAIR(arg1907_674, arg1911_677);
									   }
									   arg1901_668 = cons__138___r4_pairs_and_lists_6_3(l_93, list1910_676);
									}
								     }
								     {
									obj_t list1928_693;
									{
									   obj_t arg1929_694;
									   arg1929_694 = MAKE_PAIR(BNIL, BNIL);
									   list1928_693 = MAKE_PAIR(head_95, arg1929_694);
									}
									arg1902_669 = cons__138___r4_pairs_and_lists_6_3(tail_96, list1928_693);
								     }
								     {
									obj_t list1904_671;
									{
									   obj_t arg1905_672;
									   arg1905_672 = MAKE_PAIR(BNIL, BNIL);
									   list1904_671 = MAKE_PAIR(arg1902_669, arg1905_672);
									}
									arg1893_660 = cons__138___r4_pairs_and_lists_6_3(arg1901_668, list1904_671);
								     }
								  }
								  {
								     obj_t arg1931_696;
								     obj_t arg1932_697;
								     obj_t arg1933_698;
								     obj_t arg1934_699;
								     arg1931_696 = CNST_TABLE_REF(((long) 15));
								     {
									obj_t arg1941_706;
									obj_t arg1942_707;
									{
									   obj_t arg1948_712;
									   {
									      obj_t arg1953_717;
									      obj_t arg1954_718;
									      obj_t arg1956_719;
									      arg1953_717 = CNST_TABLE_REF(((long) 7));
									      arg1954_718 = CNST_TABLE_REF(((long) 16));
									      arg1956_719 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list1958_721;
										 {
										    obj_t arg1959_722;
										    {
										       obj_t arg1960_723;
										       arg1960_723 = MAKE_PAIR(BNIL, BNIL);
										       arg1959_722 = MAKE_PAIR(arg1956_719, arg1960_723);
										    }
										    list1958_721 = MAKE_PAIR(arg1954_718, arg1959_722);
										 }
										 arg1948_712 = cons__138___r4_pairs_and_lists_6_3(arg1953_717, list1958_721);
									      }
									   }
									   {
									      obj_t list1950_714;
									      {
										 obj_t arg1951_715;
										 arg1951_715 = MAKE_PAIR(BNIL, BNIL);
										 list1950_714 = MAKE_PAIR(l_93, arg1951_715);
									      }
									      arg1941_706 = cons__138___r4_pairs_and_lists_6_3(arg1948_712, list1950_714);
									   }
									}
									{
									   obj_t arg1962_725;
									   obj_t arg1963_726;
									   obj_t arg1964_727;
									   obj_t arg1965_728;
									   arg1962_725 = CNST_TABLE_REF(((long) 5));
									   {
									      obj_t arg1974_735;
									      {
										 obj_t arg1978_739;
										 {
										    obj_t arg1983_744;
										    obj_t arg1984_745;
										    obj_t arg1985_746;
										    {
										       obj_t arg1991_752;
										       obj_t arg1992_753;
										       obj_t arg1993_754;
										       arg1991_752 = CNST_TABLE_REF(((long) 7));
										       arg1992_753 = CNST_TABLE_REF(((long) 11));
										       arg1993_754 = CNST_TABLE_REF(((long) 9));
										       {
											  obj_t list1995_756;
											  {
											     obj_t arg1998_757;
											     {
												obj_t arg2000_758;
												arg2000_758 = MAKE_PAIR(BNIL, BNIL);
												arg1998_757 = MAKE_PAIR(arg1993_754, arg2000_758);
											     }
											     list1995_756 = MAKE_PAIR(arg1992_753, arg1998_757);
											  }
											  arg1983_744 = cons__138___r4_pairs_and_lists_6_3(arg1991_752, list1995_756);
										       }
										    }
										    {
										       obj_t arg2002_760;
										       {
											  obj_t arg2010_765;
											  {
											     obj_t arg2015_770;
											     obj_t arg2016_771;
											     obj_t arg2017_772;
											     arg2015_770 = CNST_TABLE_REF(((long) 7));
											     arg2016_771 = CNST_TABLE_REF(((long) 12));
											     arg2017_772 = CNST_TABLE_REF(((long) 9));
											     {
												obj_t list2019_774;
												{
												   obj_t arg2020_775;
												   {
												      obj_t arg2021_776;
												      arg2021_776 = MAKE_PAIR(BNIL, BNIL);
												      arg2020_775 = MAKE_PAIR(arg2017_772, arg2021_776);
												   }
												   list2019_774 = MAKE_PAIR(arg2016_771, arg2020_775);
												}
												arg2010_765 = cons__138___r4_pairs_and_lists_6_3(arg2015_770, list2019_774);
											     }
											  }
											  {
											     obj_t list2012_767;
											     {
												obj_t arg2013_768;
												arg2013_768 = MAKE_PAIR(BNIL, BNIL);
												list2012_767 = MAKE_PAIR(l_93, arg2013_768);
											     }
											     arg2002_760 = cons__138___r4_pairs_and_lists_6_3(arg2010_765, list2012_767);
											  }
										       }
										       {
											  obj_t list2004_762;
											  {
											     obj_t arg2006_763;
											     arg2006_763 = MAKE_PAIR(BNIL, BNIL);
											     list2004_762 = MAKE_PAIR(arg2002_760, arg2006_763);
											  }
											  arg1984_745 = cons__138___r4_pairs_and_lists_6_3(fun_52, list2004_762);
										       }
										    }
										    {
										       obj_t arg2023_778;
										       arg2023_778 = CNST_TABLE_REF(((long) 10));
										       {
											  obj_t list2027_781;
											  {
											     obj_t arg2028_782;
											     arg2028_782 = MAKE_PAIR(BNIL, BNIL);
											     list2027_781 = MAKE_PAIR(BNIL, arg2028_782);
											  }
											  arg1985_746 = cons__138___r4_pairs_and_lists_6_3(arg2023_778, list2027_781);
										       }
										    }
										    {
										       obj_t list1987_748;
										       {
											  obj_t arg1988_749;
											  {
											     obj_t arg1989_750;
											     arg1989_750 = MAKE_PAIR(BNIL, BNIL);
											     arg1988_749 = MAKE_PAIR(arg1985_746, arg1989_750);
											  }
											  list1987_748 = MAKE_PAIR(arg1984_745, arg1988_749);
										       }
										       arg1978_739 = cons__138___r4_pairs_and_lists_6_3(arg1983_744, list1987_748);
										    }
										 }
										 {
										    obj_t list1980_741;
										    {
										       obj_t arg1981_742;
										       arg1981_742 = MAKE_PAIR(BNIL, BNIL);
										       list1980_741 = MAKE_PAIR(arg1978_739, arg1981_742);
										    }
										    arg1974_735 = cons__138___r4_pairs_and_lists_6_3(ntail_97, list1980_741);
										 }
									      }
									      {
										 obj_t list1976_737;
										 list1976_737 = MAKE_PAIR(BNIL, BNIL);
										 arg1963_726 = cons__138___r4_pairs_and_lists_6_3(arg1974_735, list1976_737);
									      }
									   }
									   {
									      obj_t arg2030_784;
									      {
										 obj_t arg2038_790;
										 obj_t arg2039_791;
										 obj_t arg2040_792;
										 arg2038_790 = CNST_TABLE_REF(((long) 7));
										 arg2039_791 = CNST_TABLE_REF(((long) 14));
										 arg2040_792 = CNST_TABLE_REF(((long) 9));
										 {
										    obj_t list2042_794;
										    {
										       obj_t arg2043_795;
										       {
											  obj_t arg2044_796;
											  arg2044_796 = MAKE_PAIR(BNIL, BNIL);
											  arg2043_795 = MAKE_PAIR(arg2040_792, arg2044_796);
										       }
										       list2042_794 = MAKE_PAIR(arg2039_791, arg2043_795);
										    }
										    arg2030_784 = cons__138___r4_pairs_and_lists_6_3(arg2038_790, list2042_794);
										 }
									      }
									      {
										 obj_t list2032_786;
										 {
										    obj_t arg2033_787;
										    {
										       obj_t arg2035_788;
										       arg2035_788 = MAKE_PAIR(BNIL, BNIL);
										       arg2033_787 = MAKE_PAIR(ntail_97, arg2035_788);
										    }
										    list2032_786 = MAKE_PAIR(tail_96, arg2033_787);
										 }
										 arg1964_727 = cons__138___r4_pairs_and_lists_6_3(arg2030_784, list2032_786);
									      }
									   }
									   {
									      obj_t arg2046_798;
									      {
										 obj_t arg2052_804;
										 {
										    obj_t arg2057_809;
										    obj_t arg2058_810;
										    obj_t arg2059_811;
										    arg2057_809 = CNST_TABLE_REF(((long) 7));
										    arg2058_810 = CNST_TABLE_REF(((long) 13));
										    arg2059_811 = CNST_TABLE_REF(((long) 9));
										    {
										       obj_t list2061_813;
										       {
											  obj_t arg2062_814;
											  {
											     obj_t arg2063_815;
											     arg2063_815 = MAKE_PAIR(BNIL, BNIL);
											     arg2062_814 = MAKE_PAIR(arg2059_811, arg2063_815);
											  }
											  list2061_813 = MAKE_PAIR(arg2058_810, arg2062_814);
										       }
										       arg2052_804 = cons__138___r4_pairs_and_lists_6_3(arg2057_809, list2061_813);
										    }
										 }
										 {
										    obj_t list2054_806;
										    {
										       obj_t arg2055_807;
										       arg2055_807 = MAKE_PAIR(BNIL, BNIL);
										       list2054_806 = MAKE_PAIR(l_93, arg2055_807);
										    }
										    arg2046_798 = cons__138___r4_pairs_and_lists_6_3(arg2052_804, list2054_806);
										 }
									      }
									      {
										 obj_t list2048_800;
										 {
										    obj_t arg2049_801;
										    {
										       obj_t arg2050_802;
										       arg2050_802 = MAKE_PAIR(BNIL, BNIL);
										       arg2049_801 = MAKE_PAIR(ntail_97, arg2050_802);
										    }
										    list2048_800 = MAKE_PAIR(arg2046_798, arg2049_801);
										 }
										 arg1965_728 = cons__138___r4_pairs_and_lists_6_3(lname_94, list2048_800);
									      }
									   }
									   {
									      obj_t list1968_730;
									      {
										 obj_t arg1970_731;
										 {
										    obj_t arg1971_732;
										    {
										       obj_t arg1972_733;
										       arg1972_733 = MAKE_PAIR(BNIL, BNIL);
										       arg1971_732 = MAKE_PAIR(arg1965_728, arg1972_733);
										    }
										    arg1970_731 = MAKE_PAIR(arg1964_727, arg1971_732);
										 }
										 list1968_730 = MAKE_PAIR(arg1963_726, arg1970_731);
									      }
									      arg1942_707 = cons__138___r4_pairs_and_lists_6_3(arg1962_725, list1968_730);
									   }
									}
									{
									   obj_t list1944_709;
									   {
									      obj_t arg1945_710;
									      arg1945_710 = MAKE_PAIR(BNIL, BNIL);
									      list1944_709 = MAKE_PAIR(arg1942_707, arg1945_710);
									   }
									   arg1932_697 = cons__138___r4_pairs_and_lists_6_3(arg1941_706, list1944_709);
									}
								     }
								     {
									obj_t arg2065_817;
									{
									   obj_t arg2071_822;
									   {
									      obj_t arg2076_827;
									      obj_t arg2077_828;
									      obj_t arg2078_829;
									      arg2076_827 = CNST_TABLE_REF(((long) 7));
									      arg2077_828 = CNST_TABLE_REF(((long) 8));
									      arg2078_829 = CNST_TABLE_REF(((long) 9));
									      {
										 obj_t list2080_831;
										 {
										    obj_t arg2081_832;
										    {
										       obj_t arg2082_833;
										       arg2082_833 = MAKE_PAIR(BNIL, BNIL);
										       arg2081_832 = MAKE_PAIR(arg2078_829, arg2082_833);
										    }
										    list2080_831 = MAKE_PAIR(arg2077_828, arg2081_832);
										 }
										 arg2071_822 = cons__138___r4_pairs_and_lists_6_3(arg2076_827, list2080_831);
									      }
									   }
									   {
									      obj_t list2073_824;
									      {
										 obj_t arg2074_825;
										 arg2074_825 = MAKE_PAIR(BNIL, BNIL);
										 list2073_824 = MAKE_PAIR(l_93, arg2074_825);
									      }
									      arg2065_817 = cons__138___r4_pairs_and_lists_6_3(arg2071_822, list2073_824);
									   }
									}
									{
									   obj_t list2068_819;
									   {
									      obj_t arg2069_820;
									      arg2069_820 = MAKE_PAIR(BNIL, BNIL);
									      list2068_819 = MAKE_PAIR(head_95, arg2069_820);
									   }
									   arg1933_698 = cons__138___r4_pairs_and_lists_6_3(arg2065_817, list2068_819);
									}
								     }
								     {
									obj_t arg2084_835;
									obj_t arg2085_836;
									arg2084_835 = CNST_TABLE_REF(((long) 17));
									{
									   obj_t arg2090_841;
									   {
									      obj_t arg2099_850;
									      obj_t arg2100_851;
									      obj_t arg2101_852;
									      arg2099_850 = CNST_TABLE_REF(((long) 7));
									      arg2100_851 = CNST_TABLE_REF(((long) 18));
									      arg2101_852 = CNST_TABLE_REF(((long) 19));
									      {
										 obj_t list2103_854;
										 {
										    obj_t arg2105_855;
										    {
										       obj_t arg2106_856;
										       arg2106_856 = MAKE_PAIR(BNIL, BNIL);
										       arg2105_855 = MAKE_PAIR(arg2101_852, arg2106_856);
										    }
										    list2103_854 = MAKE_PAIR(arg2100_851, arg2105_855);
										 }
										 arg2090_841 = cons__138___r4_pairs_and_lists_6_3(arg2099_850, list2103_854);
									      }
									   }
									   {
									      obj_t list2094_845;
									      {
										 obj_t arg2095_846;
										 {
										    obj_t arg2096_847;
										    {
										       obj_t arg2097_848;
										       arg2097_848 = MAKE_PAIR(BNIL, BNIL);
										       arg2096_847 = MAKE_PAIR(l_93, arg2097_848);
										    }
										    arg2095_846 = MAKE_PAIR(string3394_expand_map, arg2096_847);
										 }
										 list2094_845 = MAKE_PAIR(string3395_expand_map, arg2095_846);
									      }
									      arg2085_836 = cons__138___r4_pairs_and_lists_6_3(arg2090_841, list2094_845);
									   }
									}
									{
									   obj_t list2087_838;
									   {
									      obj_t arg2088_839;
									      arg2088_839 = MAKE_PAIR(BNIL, BNIL);
									      list2087_838 = MAKE_PAIR(arg2085_836, arg2088_839);
									   }
									   arg1934_699 = cons__138___r4_pairs_and_lists_6_3(arg2084_835, list2087_838);
									}
								     }
								     {
									obj_t list1936_701;
									{
									   obj_t arg1937_702;
									   {
									      obj_t arg1938_703;
									      {
										 obj_t arg1939_704;
										 arg1939_704 = MAKE_PAIR(BNIL, BNIL);
										 arg1938_703 = MAKE_PAIR(arg1934_699, arg1939_704);
									      }
									      arg1937_702 = MAKE_PAIR(arg1933_698, arg1938_703);
									   }
									   list1936_701 = MAKE_PAIR(arg1932_697, arg1937_702);
									}
									arg1894_661 = cons__138___r4_pairs_and_lists_6_3(arg1931_696, list1936_701);
								     }
								  }
								  {
								     obj_t list1896_663;
								     {
									obj_t arg1897_664;
									{
									   obj_t arg1898_665;
									   {
									      obj_t arg1899_666;
									      arg1899_666 = MAKE_PAIR(BNIL, BNIL);
									      arg1898_665 = MAKE_PAIR(arg1894_661, arg1899_666);
									   }
									   arg1897_664 = MAKE_PAIR(arg1893_660, arg1898_665);
									}
									list1896_663 = MAKE_PAIR(lname_94, arg1897_664);
								     }
								     arg1822_604 = cons__138___r4_pairs_and_lists_6_3(arg1892_659, list1896_663);
								  }
							       }
							       {
								  obj_t list1824_606;
								  {
								     obj_t arg1826_607;
								     {
									obj_t arg1827_608;
									arg1827_608 = MAKE_PAIR(BNIL, BNIL);
									arg1826_607 = MAKE_PAIR(arg1822_604, arg1827_608);
								     }
								     list1824_606 = MAKE_PAIR(arg1821_603, arg1826_607);
								  }
								  arg1790_572 = cons__138___r4_pairs_and_lists_6_3(arg1820_602, list1824_606);
							       }
							    }
							 }
						    }
						    {
						       obj_t list1792_574;
						       {
							  obj_t arg1793_575;
							  {
							     obj_t arg1794_576;
							     {
								obj_t arg1795_577;
								arg1795_577 = MAKE_PAIR(BNIL, BNIL);
								arg1794_576 = MAKE_PAIR(arg1790_572, arg1795_577);
							     }
							     arg1793_575 = MAKE_PAIR(arg1789_571, arg1794_576);
							  }
							  list1792_574 = MAKE_PAIR(arg1788_570, arg1793_575);
						       }
						       arg1768_555 = cons__138___r4_pairs_and_lists_6_3(arg1786_569, list1792_574);
						    }
						 }
						 {
						    obj_t list1770_557;
						    {
						       obj_t arg1771_558;
						       {
							  obj_t arg1772_559;
							  arg1772_559 = MAKE_PAIR(BNIL, BNIL);
							  arg1771_558 = MAKE_PAIR(arg1768_555, arg1772_559);
						       }
						       list1770_557 = MAKE_PAIR(arg1767_554, arg1771_558);
						    }
						    loop_98 = cons__138___r4_pairs_and_lists_6_3(arg1766_553, list1770_557);
						 }
					      }
					    {
					       {
						  obj_t res_99;
						  res_99 = PROCEDURE_ENTRY(e_2) (e_2, loop_98, e_2, BEOA);
						  return replace__160_tools_misc(x_1, res_99);
					       }
					    }
					 }
				      }
				   }
				}
			     }
			  }
		       }
		     else
		       {
			  obj_t cdr_141_172_73;
			  cdr_141_172_73 = CDR(cdr_114_48_65);
			  {
			     obj_t cdr_148_78_74;
			     cdr_148_78_74 = CDR(cdr_141_172_73);
			     if (PAIRP(cdr_148_78_74))
			       {
				  bool_t test_2992;
				  {
				     obj_t aux_2993;
				     aux_2993 = CDR(cdr_148_78_74);
				     test_2992 = (aux_2993 == BNIL);
				  }
				  if (test_2992)
				    {
				       fun_55 = CAR(cdr_114_48_65);
				       l1_56 = CAR(cdr_141_172_73);
				       l2_57 = CAR(cdr_148_78_74);
				       {
					  obj_t ll1_1112;
					  obj_t ll2_1113;
					  obj_t head_1114;
					  obj_t tail_1115;
					  obj_t ntail_1116;
					  obj_t lname_1117;
					  {
					     obj_t arg2980_1680;
					     arg2980_1680 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 20)), BEOA);
					     ll1_1112 = mark_symbol_non_user__17_ast_ident(arg2980_1680);
					  }
					  {
					     obj_t arg2982_1682;
					     arg2982_1682 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 20)), BEOA);
					     ll2_1113 = mark_symbol_non_user__17_ast_ident(arg2982_1682);
					  }
					  {
					     obj_t arg2984_1684;
					     arg2984_1684 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
					     head_1114 = mark_symbol_non_user__17_ast_ident(arg2984_1684);
					  }
					  {
					     obj_t arg2986_1686;
					     arg2986_1686 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 3)), BEOA);
					     tail_1115 = mark_symbol_non_user__17_ast_ident(arg2986_1686);
					  }
					  {
					     obj_t arg2989_1688;
					     arg2989_1688 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
					     ntail_1116 = mark_symbol_non_user__17_ast_ident(arg2989_1688);
					  }
					  {
					     obj_t arg2993_1690;
					     arg2993_1690 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
					     lname_1117 = mark_symbol_non_user__17_ast_ident(arg2993_1690);
					  }
					  {
					     obj_t res_1118;
					     {
						obj_t arg2392_1119;
						{
						   obj_t arg2394_1120;
						   obj_t arg2396_1121;
						   obj_t arg2399_1122;
						   arg2394_1120 = CNST_TABLE_REF(((long) 5));
						   {
						      obj_t arg2405_1128;
						      obj_t arg2406_1129;
						      {
							 obj_t list2412_1135;
							 {
							    obj_t arg2413_1136;
							    arg2413_1136 = MAKE_PAIR(BNIL, BNIL);
							    list2412_1135 = MAKE_PAIR(l1_56, arg2413_1136);
							 }
							 arg2405_1128 = cons__138___r4_pairs_and_lists_6_3(ll1_1112, list2412_1135);
						      }
						      {
							 obj_t list2416_1139;
							 {
							    obj_t arg2417_1140;
							    arg2417_1140 = MAKE_PAIR(BNIL, BNIL);
							    list2416_1139 = MAKE_PAIR(l2_57, arg2417_1140);
							 }
							 arg2406_1129 = cons__138___r4_pairs_and_lists_6_3(ll2_1113, list2416_1139);
						      }
						      {
							 obj_t list2408_1131;
							 {
							    obj_t arg2409_1132;
							    arg2409_1132 = MAKE_PAIR(BNIL, BNIL);
							    list2408_1131 = MAKE_PAIR(arg2406_1129, arg2409_1132);
							 }
							 arg2396_1121 = cons__138___r4_pairs_and_lists_6_3(arg2405_1128, list2408_1131);
						      }
						   }
						   {
						      obj_t arg2419_1142;
						      obj_t arg2420_1143;
						      obj_t arg2421_1144;
						      obj_t arg2422_1145;
						      arg2419_1142 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t arg2429_1152;
							 {
							    obj_t arg2434_1157;
							    obj_t arg2435_1158;
							    obj_t arg2436_1159;
							    arg2434_1157 = CNST_TABLE_REF(((long) 7));
							    arg2435_1158 = CNST_TABLE_REF(((long) 8));
							    arg2436_1159 = CNST_TABLE_REF(((long) 9));
							    {
							       obj_t list2438_1161;
							       {
								  obj_t arg2439_1162;
								  {
								     obj_t arg2440_1163;
								     arg2440_1163 = MAKE_PAIR(BNIL, BNIL);
								     arg2439_1162 = MAKE_PAIR(arg2436_1159, arg2440_1163);
								  }
								  list2438_1161 = MAKE_PAIR(arg2435_1158, arg2439_1162);
							       }
							       arg2429_1152 = cons__138___r4_pairs_and_lists_6_3(arg2434_1157, list2438_1161);
							    }
							 }
							 {
							    obj_t list2431_1154;
							    {
							       obj_t arg2432_1155;
							       arg2432_1155 = MAKE_PAIR(BNIL, BNIL);
							       list2431_1154 = MAKE_PAIR(ll1_1112, arg2432_1155);
							    }
							    arg2420_1143 = cons__138___r4_pairs_and_lists_6_3(arg2429_1152, list2431_1154);
							 }
						      }
						      {
							 obj_t arg2442_1165;
							 arg2442_1165 = CNST_TABLE_REF(((long) 10));
							 {
							    obj_t list2445_1168;
							    {
							       obj_t arg2446_1169;
							       arg2446_1169 = MAKE_PAIR(BNIL, BNIL);
							       list2445_1168 = MAKE_PAIR(BNIL, arg2446_1169);
							    }
							    arg2421_1144 = cons__138___r4_pairs_and_lists_6_3(arg2442_1165, list2445_1168);
							 }
						      }
						      {
							 if (PAIRP(fun_55))
							   {
							      {
								 obj_t arg2743_1448;
								 obj_t arg2744_1449;
								 obj_t arg2745_1450;
								 arg2743_1448 = CNST_TABLE_REF(((long) 5));
								 {
								    obj_t arg2751_1456;
								    {
								       obj_t arg2755_1460;
								       {
									  obj_t arg2760_1465;
									  obj_t arg2761_1466;
									  obj_t arg2762_1467;
									  {
									     obj_t arg2768_1473;
									     obj_t arg2769_1474;
									     obj_t arg2770_1475;
									     arg2768_1473 = CNST_TABLE_REF(((long) 7));
									     arg2769_1474 = CNST_TABLE_REF(((long) 11));
									     arg2770_1475 = CNST_TABLE_REF(((long) 9));
									     {
										obj_t list2772_1477;
										{
										   obj_t arg2773_1478;
										   {
										      obj_t arg2774_1479;
										      arg2774_1479 = MAKE_PAIR(BNIL, BNIL);
										      arg2773_1478 = MAKE_PAIR(arg2770_1475, arg2774_1479);
										   }
										   list2772_1477 = MAKE_PAIR(arg2769_1474, arg2773_1478);
										}
										arg2760_1465 = cons__138___r4_pairs_and_lists_6_3(arg2768_1473, list2772_1477);
									     }
									  }
									  {
									     obj_t arg2776_1481;
									     arg2776_1481 = CNST_TABLE_REF(((long) 10));
									     {
										obj_t list2779_1484;
										{
										   obj_t arg2780_1485;
										   arg2780_1485 = MAKE_PAIR(BNIL, BNIL);
										   list2779_1484 = MAKE_PAIR(BNIL, arg2780_1485);
										}
										arg2761_1466 = cons__138___r4_pairs_and_lists_6_3(arg2776_1481, list2779_1484);
									     }
									  }
									  {
									     obj_t arg2782_1487;
									     arg2782_1487 = CNST_TABLE_REF(((long) 10));
									     {
										obj_t list2785_1490;
										{
										   obj_t arg2786_1491;
										   arg2786_1491 = MAKE_PAIR(BNIL, BNIL);
										   list2785_1490 = MAKE_PAIR(BNIL, arg2786_1491);
										}
										arg2762_1467 = cons__138___r4_pairs_and_lists_6_3(arg2782_1487, list2785_1490);
									     }
									  }
									  {
									     obj_t list2764_1469;
									     {
										obj_t arg2765_1470;
										{
										   obj_t arg2766_1471;
										   arg2766_1471 = MAKE_PAIR(BNIL, BNIL);
										   arg2765_1470 = MAKE_PAIR(arg2762_1467, arg2766_1471);
										}
										list2764_1469 = MAKE_PAIR(arg2761_1466, arg2765_1470);
									     }
									     arg2755_1460 = cons__138___r4_pairs_and_lists_6_3(arg2760_1465, list2764_1469);
									  }
								       }
								       {
									  obj_t list2757_1462;
									  {
									     obj_t arg2758_1463;
									     arg2758_1463 = MAKE_PAIR(BNIL, BNIL);
									     list2757_1462 = MAKE_PAIR(arg2755_1460, arg2758_1463);
									  }
									  arg2751_1456 = cons__138___r4_pairs_and_lists_6_3(head_1114, list2757_1462);
								       }
								    }
								    {
								       obj_t list2753_1458;
								       list2753_1458 = MAKE_PAIR(BNIL, BNIL);
								       arg2744_1449 = cons__138___r4_pairs_and_lists_6_3(arg2751_1456, list2753_1458);
								    }
								 }
								 {
								    obj_t arg2788_1493;
								    obj_t arg2789_1494;
								    obj_t arg2790_1495;
								    arg2788_1493 = CNST_TABLE_REF(((long) 5));
								    {
								       obj_t arg2797_1502;
								       obj_t arg2798_1503;
								       obj_t arg2799_1504;
								       {
									  obj_t list2806_1511;
									  {
									     obj_t arg2807_1512;
									     arg2807_1512 = MAKE_PAIR(BNIL, BNIL);
									     list2806_1511 = MAKE_PAIR(ll1_1112, arg2807_1512);
									  }
									  arg2797_1502 = cons__138___r4_pairs_and_lists_6_3(ll1_1112, list2806_1511);
								       }
								       {
									  obj_t list2810_1515;
									  {
									     obj_t arg2811_1516;
									     arg2811_1516 = MAKE_PAIR(BNIL, BNIL);
									     list2810_1515 = MAKE_PAIR(ll2_1113, arg2811_1516);
									  }
									  arg2798_1503 = cons__138___r4_pairs_and_lists_6_3(ll2_1113, list2810_1515);
								       }
								       {
									  obj_t list2814_1519;
									  {
									     obj_t arg2815_1520;
									     arg2815_1520 = MAKE_PAIR(BNIL, BNIL);
									     list2814_1519 = MAKE_PAIR(head_1114, arg2815_1520);
									  }
									  arg2799_1504 = cons__138___r4_pairs_and_lists_6_3(tail_1115, list2814_1519);
								       }
								       {
									  obj_t list2801_1506;
									  {
									     obj_t arg2802_1507;
									     {
										obj_t arg2803_1508;
										arg2803_1508 = MAKE_PAIR(BNIL, BNIL);
										arg2802_1507 = MAKE_PAIR(arg2799_1504, arg2803_1508);
									     }
									     list2801_1506 = MAKE_PAIR(arg2798_1503, arg2802_1507);
									  }
									  arg2789_1494 = cons__138___r4_pairs_and_lists_6_3(arg2797_1502, list2801_1506);
								       }
								    }
								    {
								       obj_t arg2817_1522;
								       obj_t arg2818_1523;
								       obj_t arg2819_1524;
								       obj_t arg2820_1525;
								       arg2817_1522 = CNST_TABLE_REF(((long) 6));
								       {
									  obj_t arg2827_1532;
									  {
									     obj_t arg2832_1537;
									     obj_t arg2833_1538;
									     obj_t arg2834_1539;
									     arg2832_1537 = CNST_TABLE_REF(((long) 7));
									     arg2833_1538 = CNST_TABLE_REF(((long) 8));
									     arg2834_1539 = CNST_TABLE_REF(((long) 9));
									     {
										obj_t list2836_1541;
										{
										   obj_t arg2837_1542;
										   {
										      obj_t arg2838_1543;
										      arg2838_1543 = MAKE_PAIR(BNIL, BNIL);
										      arg2837_1542 = MAKE_PAIR(arg2834_1539, arg2838_1543);
										   }
										   list2836_1541 = MAKE_PAIR(arg2833_1538, arg2837_1542);
										}
										arg2827_1532 = cons__138___r4_pairs_and_lists_6_3(arg2832_1537, list2836_1541);
									     }
									  }
									  {
									     obj_t list2829_1534;
									     {
										obj_t arg2830_1535;
										arg2830_1535 = MAKE_PAIR(BNIL, BNIL);
										list2829_1534 = MAKE_PAIR(ll1_1112, arg2830_1535);
									     }
									     arg2818_1523 = cons__138___r4_pairs_and_lists_6_3(arg2827_1532, list2829_1534);
									  }
								       }
								       {
									  obj_t arg2840_1545;
									  {
									     obj_t arg2845_1550;
									     obj_t arg2846_1551;
									     obj_t arg2847_1552;
									     arg2845_1550 = CNST_TABLE_REF(((long) 7));
									     arg2846_1551 = CNST_TABLE_REF(((long) 13));
									     arg2847_1552 = CNST_TABLE_REF(((long) 9));
									     {
										obj_t list2849_1554;
										{
										   obj_t arg2850_1555;
										   {
										      obj_t arg2851_1556;
										      arg2851_1556 = MAKE_PAIR(BNIL, BNIL);
										      arg2850_1555 = MAKE_PAIR(arg2847_1552, arg2851_1556);
										   }
										   list2849_1554 = MAKE_PAIR(arg2846_1551, arg2850_1555);
										}
										arg2840_1545 = cons__138___r4_pairs_and_lists_6_3(arg2845_1550, list2849_1554);
									     }
									  }
									  {
									     obj_t list2842_1547;
									     {
										obj_t arg2843_1548;
										arg2843_1548 = MAKE_PAIR(BNIL, BNIL);
										list2842_1547 = MAKE_PAIR(head_1114, arg2843_1548);
									     }
									     arg2819_1524 = cons__138___r4_pairs_and_lists_6_3(arg2840_1545, list2842_1547);
									  }
								       }
								       {
									  obj_t arg2853_1558;
									  obj_t arg2854_1559;
									  obj_t arg2855_1560;
									  obj_t arg2856_1561;
									  arg2853_1558 = CNST_TABLE_REF(((long) 5));
									  {
									     obj_t arg2863_1568;
									     {
										obj_t arg2867_1572;
										{
										   obj_t arg2872_1577;
										   obj_t arg2873_1578;
										   obj_t arg2874_1579;
										   {
										      obj_t arg2880_1585;
										      obj_t arg2882_1586;
										      obj_t arg2883_1587;
										      arg2880_1585 = CNST_TABLE_REF(((long) 7));
										      arg2882_1586 = CNST_TABLE_REF(((long) 11));
										      arg2883_1587 = CNST_TABLE_REF(((long) 9));
										      {
											 obj_t list2885_1589;
											 {
											    obj_t arg2886_1590;
											    {
											       obj_t arg2888_1591;
											       arg2888_1591 = MAKE_PAIR(BNIL, BNIL);
											       arg2886_1590 = MAKE_PAIR(arg2883_1587, arg2888_1591);
											    }
											    list2885_1589 = MAKE_PAIR(arg2882_1586, arg2886_1590);
											 }
											 arg2872_1577 = cons__138___r4_pairs_and_lists_6_3(arg2880_1585, list2885_1589);
										      }
										   }
										   {
										      obj_t arg2890_1593;
										      obj_t arg2891_1594;
										      {
											 obj_t arg2897_1600;
											 {
											    obj_t arg2902_1605;
											    obj_t arg2903_1606;
											    obj_t arg2905_1607;
											    arg2902_1605 = CNST_TABLE_REF(((long) 7));
											    arg2903_1606 = CNST_TABLE_REF(((long) 12));
											    arg2905_1607 = CNST_TABLE_REF(((long) 9));
											    {
											       obj_t list2907_1609;
											       {
												  obj_t arg2908_1610;
												  {
												     obj_t arg2909_1611;
												     arg2909_1611 = MAKE_PAIR(BNIL, BNIL);
												     arg2908_1610 = MAKE_PAIR(arg2905_1607, arg2909_1611);
												  }
												  list2907_1609 = MAKE_PAIR(arg2903_1606, arg2908_1610);
											       }
											       arg2897_1600 = cons__138___r4_pairs_and_lists_6_3(arg2902_1605, list2907_1609);
											    }
											 }
											 {
											    obj_t list2899_1602;
											    {
											       obj_t arg2900_1603;
											       arg2900_1603 = MAKE_PAIR(BNIL, BNIL);
											       list2899_1602 = MAKE_PAIR(ll1_1112, arg2900_1603);
											    }
											    arg2890_1593 = cons__138___r4_pairs_and_lists_6_3(arg2897_1600, list2899_1602);
											 }
										      }
										      {
											 obj_t arg2911_1613;
											 {
											    obj_t arg2916_1618;
											    obj_t arg2917_1619;
											    obj_t arg2918_1620;
											    arg2916_1618 = CNST_TABLE_REF(((long) 7));
											    arg2917_1619 = CNST_TABLE_REF(((long) 12));
											    arg2918_1620 = CNST_TABLE_REF(((long) 9));
											    {
											       obj_t list2920_1622;
											       {
												  obj_t arg2921_1623;
												  {
												     obj_t arg2922_1624;
												     arg2922_1624 = MAKE_PAIR(BNIL, BNIL);
												     arg2921_1623 = MAKE_PAIR(arg2918_1620, arg2922_1624);
												  }
												  list2920_1622 = MAKE_PAIR(arg2917_1619, arg2921_1623);
											       }
											       arg2911_1613 = cons__138___r4_pairs_and_lists_6_3(arg2916_1618, list2920_1622);
											    }
											 }
											 {
											    obj_t list2913_1615;
											    {
											       obj_t arg2914_1616;
											       arg2914_1616 = MAKE_PAIR(BNIL, BNIL);
											       list2913_1615 = MAKE_PAIR(ll2_1113, arg2914_1616);
											    }
											    arg2891_1594 = cons__138___r4_pairs_and_lists_6_3(arg2911_1613, list2913_1615);
											 }
										      }
										      {
											 obj_t list2893_1596;
											 {
											    obj_t arg2894_1597;
											    {
											       obj_t arg2895_1598;
											       arg2895_1598 = MAKE_PAIR(BNIL, BNIL);
											       arg2894_1597 = MAKE_PAIR(arg2891_1594, arg2895_1598);
											    }
											    list2893_1596 = MAKE_PAIR(arg2890_1593, arg2894_1597);
											 }
											 arg2873_1578 = cons__138___r4_pairs_and_lists_6_3(fun_55, list2893_1596);
										      }
										   }
										   {
										      obj_t arg2924_1626;
										      arg2924_1626 = CNST_TABLE_REF(((long) 10));
										      {
											 obj_t list2927_1629;
											 {
											    obj_t arg2928_1630;
											    arg2928_1630 = MAKE_PAIR(BNIL, BNIL);
											    list2927_1629 = MAKE_PAIR(BNIL, arg2928_1630);
											 }
											 arg2874_1579 = cons__138___r4_pairs_and_lists_6_3(arg2924_1626, list2927_1629);
										      }
										   }
										   {
										      obj_t list2876_1581;
										      {
											 obj_t arg2877_1582;
											 {
											    obj_t arg2878_1583;
											    arg2878_1583 = MAKE_PAIR(BNIL, BNIL);
											    arg2877_1582 = MAKE_PAIR(arg2874_1579, arg2878_1583);
											 }
											 list2876_1581 = MAKE_PAIR(arg2873_1578, arg2877_1582);
										      }
										      arg2867_1572 = cons__138___r4_pairs_and_lists_6_3(arg2872_1577, list2876_1581);
										   }
										}
										{
										   obj_t list2869_1574;
										   {
										      obj_t arg2870_1575;
										      arg2870_1575 = MAKE_PAIR(BNIL, BNIL);
										      list2869_1574 = MAKE_PAIR(arg2867_1572, arg2870_1575);
										   }
										   arg2863_1568 = cons__138___r4_pairs_and_lists_6_3(ntail_1116, list2869_1574);
										}
									     }
									     {
										obj_t list2865_1570;
										list2865_1570 = MAKE_PAIR(BNIL, BNIL);
										arg2854_1559 = cons__138___r4_pairs_and_lists_6_3(arg2863_1568, list2865_1570);
									     }
									  }
									  {
									     obj_t arg2930_1632;
									     {
										obj_t arg2937_1638;
										obj_t arg2938_1639;
										obj_t arg2939_1640;
										arg2937_1638 = CNST_TABLE_REF(((long) 7));
										arg2938_1639 = CNST_TABLE_REF(((long) 14));
										arg2939_1640 = CNST_TABLE_REF(((long) 9));
										{
										   obj_t list2941_1642;
										   {
										      obj_t arg2942_1643;
										      {
											 obj_t arg2943_1644;
											 arg2943_1644 = MAKE_PAIR(BNIL, BNIL);
											 arg2942_1643 = MAKE_PAIR(arg2939_1640, arg2943_1644);
										      }
										      list2941_1642 = MAKE_PAIR(arg2938_1639, arg2942_1643);
										   }
										   arg2930_1632 = cons__138___r4_pairs_and_lists_6_3(arg2937_1638, list2941_1642);
										}
									     }
									     {
										obj_t list2932_1634;
										{
										   obj_t arg2933_1635;
										   {
										      obj_t arg2935_1636;
										      arg2935_1636 = MAKE_PAIR(BNIL, BNIL);
										      arg2933_1635 = MAKE_PAIR(ntail_1116, arg2935_1636);
										   }
										   list2932_1634 = MAKE_PAIR(tail_1115, arg2933_1635);
										}
										arg2855_1560 = cons__138___r4_pairs_and_lists_6_3(arg2930_1632, list2932_1634);
									     }
									  }
									  {
									     obj_t arg2945_1646;
									     obj_t arg2946_1647;
									     {
										obj_t arg2953_1654;
										{
										   obj_t arg2959_1659;
										   obj_t arg2960_1660;
										   obj_t arg2961_1661;
										   arg2959_1659 = CNST_TABLE_REF(((long) 7));
										   arg2960_1660 = CNST_TABLE_REF(((long) 13));
										   arg2961_1661 = CNST_TABLE_REF(((long) 9));
										   {
										      obj_t list2963_1663;
										      {
											 obj_t arg2964_1664;
											 {
											    obj_t arg2965_1665;
											    arg2965_1665 = MAKE_PAIR(BNIL, BNIL);
											    arg2964_1664 = MAKE_PAIR(arg2961_1661, arg2965_1665);
											 }
											 list2963_1663 = MAKE_PAIR(arg2960_1660, arg2964_1664);
										      }
										      arg2953_1654 = cons__138___r4_pairs_and_lists_6_3(arg2959_1659, list2963_1663);
										   }
										}
										{
										   obj_t list2956_1656;
										   {
										      obj_t arg2957_1657;
										      arg2957_1657 = MAKE_PAIR(BNIL, BNIL);
										      list2956_1656 = MAKE_PAIR(ll1_1112, arg2957_1657);
										   }
										   arg2945_1646 = cons__138___r4_pairs_and_lists_6_3(arg2953_1654, list2956_1656);
										}
									     }
									     {
										obj_t arg2967_1667;
										{
										   obj_t arg2972_1672;
										   obj_t arg2973_1673;
										   obj_t arg2974_1674;
										   arg2972_1672 = CNST_TABLE_REF(((long) 7));
										   arg2973_1673 = CNST_TABLE_REF(((long) 13));
										   arg2974_1674 = CNST_TABLE_REF(((long) 9));
										   {
										      obj_t list2976_1676;
										      {
											 obj_t arg2977_1677;
											 {
											    obj_t arg2978_1678;
											    arg2978_1678 = MAKE_PAIR(BNIL, BNIL);
											    arg2977_1677 = MAKE_PAIR(arg2974_1674, arg2978_1678);
											 }
											 list2976_1676 = MAKE_PAIR(arg2973_1673, arg2977_1677);
										      }
										      arg2967_1667 = cons__138___r4_pairs_and_lists_6_3(arg2972_1672, list2976_1676);
										   }
										}
										{
										   obj_t list2969_1669;
										   {
										      obj_t arg2970_1670;
										      arg2970_1670 = MAKE_PAIR(BNIL, BNIL);
										      list2969_1669 = MAKE_PAIR(ll2_1113, arg2970_1670);
										   }
										   arg2946_1647 = cons__138___r4_pairs_and_lists_6_3(arg2967_1667, list2969_1669);
										}
									     }
									     {
										obj_t list2948_1649;
										{
										   obj_t arg2949_1650;
										   {
										      obj_t arg2950_1651;
										      {
											 obj_t arg2951_1652;
											 arg2951_1652 = MAKE_PAIR(BNIL, BNIL);
											 arg2950_1651 = MAKE_PAIR(ntail_1116, arg2951_1652);
										      }
										      arg2949_1650 = MAKE_PAIR(arg2946_1647, arg2950_1651);
										   }
										   list2948_1649 = MAKE_PAIR(arg2945_1646, arg2949_1650);
										}
										arg2856_1561 = cons__138___r4_pairs_and_lists_6_3(lname_1117, list2948_1649);
									     }
									  }
									  {
									     obj_t list2858_1563;
									     {
										obj_t arg2859_1564;
										{
										   obj_t arg2860_1565;
										   {
										      obj_t arg2861_1566;
										      arg2861_1566 = MAKE_PAIR(BNIL, BNIL);
										      arg2860_1565 = MAKE_PAIR(arg2856_1561, arg2861_1566);
										   }
										   arg2859_1564 = MAKE_PAIR(arg2855_1560, arg2860_1565);
										}
										list2858_1563 = MAKE_PAIR(arg2854_1559, arg2859_1564);
									     }
									     arg2820_1525 = cons__138___r4_pairs_and_lists_6_3(arg2853_1558, list2858_1563);
									  }
								       }
								       {
									  obj_t list2822_1527;
									  {
									     obj_t arg2823_1528;
									     {
										obj_t arg2824_1529;
										{
										   obj_t arg2825_1530;
										   arg2825_1530 = MAKE_PAIR(BNIL, BNIL);
										   arg2824_1529 = MAKE_PAIR(arg2820_1525, arg2825_1530);
										}
										arg2823_1528 = MAKE_PAIR(arg2819_1524, arg2824_1529);
									     }
									     list2822_1527 = MAKE_PAIR(arg2818_1523, arg2823_1528);
									  }
									  arg2790_1495 = cons__138___r4_pairs_and_lists_6_3(arg2817_1522, list2822_1527);
								       }
								    }
								    {
								       obj_t list2792_1497;
								       {
									  obj_t arg2793_1498;
									  {
									     obj_t arg2794_1499;
									     {
										obj_t arg2795_1500;
										arg2795_1500 = MAKE_PAIR(BNIL, BNIL);
										arg2794_1499 = MAKE_PAIR(arg2790_1495, arg2795_1500);
									     }
									     arg2793_1498 = MAKE_PAIR(arg2789_1494, arg2794_1499);
									  }
									  list2792_1497 = MAKE_PAIR(lname_1117, arg2793_1498);
								       }
								       arg2745_1450 = cons__138___r4_pairs_and_lists_6_3(arg2788_1493, list2792_1497);
								    }
								 }
								 {
								    obj_t list2747_1452;
								    {
								       obj_t arg2748_1453;
								       {
									  obj_t arg2749_1454;
									  arg2749_1454 = MAKE_PAIR(BNIL, BNIL);
									  arg2748_1453 = MAKE_PAIR(arg2745_1450, arg2749_1454);
								       }
								       list2747_1452 = MAKE_PAIR(arg2744_1449, arg2748_1453);
								    }
								    arg2422_1145 = cons__138___r4_pairs_and_lists_6_3(arg2743_1448, list2747_1452);
								 }
							      }
							   }
							 else
							   {
							      {
								 obj_t arg2449_1175;
								 obj_t arg2450_1176;
								 obj_t arg2451_1177;
								 arg2449_1175 = CNST_TABLE_REF(((long) 5));
								 {
								    obj_t arg2457_1183;
								    {
								       obj_t arg2461_1187;
								       {
									  obj_t arg2467_1192;
									  obj_t arg2468_1193;
									  obj_t arg2469_1194;
									  {
									     obj_t arg2475_1200;
									     obj_t arg2476_1201;
									     obj_t arg2477_1202;
									     arg2475_1200 = CNST_TABLE_REF(((long) 7));
									     arg2476_1201 = CNST_TABLE_REF(((long) 11));
									     arg2477_1202 = CNST_TABLE_REF(((long) 9));
									     {
										obj_t list2479_1204;
										{
										   obj_t arg2480_1205;
										   {
										      obj_t arg2481_1206;
										      arg2481_1206 = MAKE_PAIR(BNIL, BNIL);
										      arg2480_1205 = MAKE_PAIR(arg2477_1202, arg2481_1206);
										   }
										   list2479_1204 = MAKE_PAIR(arg2476_1201, arg2480_1205);
										}
										arg2467_1192 = cons__138___r4_pairs_and_lists_6_3(arg2475_1200, list2479_1204);
									     }
									  }
									  {
									     obj_t arg2484_1208;
									     obj_t arg2485_1209;
									     {
										obj_t arg2491_1215;
										{
										   obj_t arg2497_1220;
										   obj_t arg2498_1221;
										   obj_t arg2499_1222;
										   arg2497_1220 = CNST_TABLE_REF(((long) 7));
										   arg2498_1221 = CNST_TABLE_REF(((long) 12));
										   arg2499_1222 = CNST_TABLE_REF(((long) 9));
										   {
										      obj_t list2501_1224;
										      {
											 obj_t arg2502_1225;
											 {
											    obj_t arg2503_1226;
											    arg2503_1226 = MAKE_PAIR(BNIL, BNIL);
											    arg2502_1225 = MAKE_PAIR(arg2499_1222, arg2503_1226);
											 }
											 list2501_1224 = MAKE_PAIR(arg2498_1221, arg2502_1225);
										      }
										      arg2491_1215 = cons__138___r4_pairs_and_lists_6_3(arg2497_1220, list2501_1224);
										   }
										}
										{
										   obj_t list2494_1217;
										   {
										      obj_t arg2495_1218;
										      arg2495_1218 = MAKE_PAIR(BNIL, BNIL);
										      list2494_1217 = MAKE_PAIR(ll1_1112, arg2495_1218);
										   }
										   arg2484_1208 = cons__138___r4_pairs_and_lists_6_3(arg2491_1215, list2494_1217);
										}
									     }
									     {
										obj_t arg2506_1228;
										{
										   obj_t arg2512_1233;
										   obj_t arg2514_1234;
										   obj_t arg2515_1235;
										   arg2512_1233 = CNST_TABLE_REF(((long) 7));
										   arg2514_1234 = CNST_TABLE_REF(((long) 12));
										   arg2515_1235 = CNST_TABLE_REF(((long) 9));
										   {
										      obj_t list2517_1237;
										      {
											 obj_t arg2518_1238;
											 {
											    obj_t arg2519_1239;
											    arg2519_1239 = MAKE_PAIR(BNIL, BNIL);
											    arg2518_1238 = MAKE_PAIR(arg2515_1235, arg2519_1239);
											 }
											 list2517_1237 = MAKE_PAIR(arg2514_1234, arg2518_1238);
										      }
										      arg2506_1228 = cons__138___r4_pairs_and_lists_6_3(arg2512_1233, list2517_1237);
										   }
										}
										{
										   obj_t list2508_1230;
										   {
										      obj_t arg2509_1231;
										      arg2509_1231 = MAKE_PAIR(BNIL, BNIL);
										      list2508_1230 = MAKE_PAIR(ll2_1113, arg2509_1231);
										   }
										   arg2485_1209 = cons__138___r4_pairs_and_lists_6_3(arg2506_1228, list2508_1230);
										}
									     }
									     {
										obj_t list2487_1211;
										{
										   obj_t arg2488_1212;
										   {
										      obj_t arg2489_1213;
										      arg2489_1213 = MAKE_PAIR(BNIL, BNIL);
										      arg2488_1212 = MAKE_PAIR(arg2485_1209, arg2489_1213);
										   }
										   list2487_1211 = MAKE_PAIR(arg2484_1208, arg2488_1212);
										}
										arg2468_1193 = cons__138___r4_pairs_and_lists_6_3(fun_55, list2487_1211);
									     }
									  }
									  {
									     obj_t arg2522_1241;
									     arg2522_1241 = CNST_TABLE_REF(((long) 10));
									     {
										obj_t list2525_1244;
										{
										   obj_t arg2526_1245;
										   arg2526_1245 = MAKE_PAIR(BNIL, BNIL);
										   list2525_1244 = MAKE_PAIR(BNIL, arg2526_1245);
										}
										arg2469_1194 = cons__138___r4_pairs_and_lists_6_3(arg2522_1241, list2525_1244);
									     }
									  }
									  {
									     obj_t list2471_1196;
									     {
										obj_t arg2472_1197;
										{
										   obj_t arg2473_1198;
										   arg2473_1198 = MAKE_PAIR(BNIL, BNIL);
										   arg2472_1197 = MAKE_PAIR(arg2469_1194, arg2473_1198);
										}
										list2471_1196 = MAKE_PAIR(arg2468_1193, arg2472_1197);
									     }
									     arg2461_1187 = cons__138___r4_pairs_and_lists_6_3(arg2467_1192, list2471_1196);
									  }
								       }
								       {
									  obj_t list2464_1189;
									  {
									     obj_t arg2465_1190;
									     arg2465_1190 = MAKE_PAIR(BNIL, BNIL);
									     list2464_1189 = MAKE_PAIR(arg2461_1187, arg2465_1190);
									  }
									  arg2457_1183 = cons__138___r4_pairs_and_lists_6_3(head_1114, list2464_1189);
								       }
								    }
								    {
								       obj_t list2459_1185;
								       list2459_1185 = MAKE_PAIR(BNIL, BNIL);
								       arg2450_1176 = cons__138___r4_pairs_and_lists_6_3(arg2457_1183, list2459_1185);
								    }
								 }
								 {
								    obj_t arg2528_1247;
								    obj_t arg2529_1248;
								    obj_t arg2530_1249;
								    arg2528_1247 = CNST_TABLE_REF(((long) 5));
								    {
								       obj_t arg2537_1256;
								       obj_t arg2538_1257;
								       obj_t arg2539_1258;
								       {
									  obj_t arg2545_1264;
									  {
									     obj_t arg2551_1269;
									     {
										obj_t arg2557_1274;
										obj_t arg2558_1275;
										obj_t arg2559_1276;
										arg2557_1274 = CNST_TABLE_REF(((long) 7));
										arg2558_1275 = CNST_TABLE_REF(((long) 13));
										arg2559_1276 = CNST_TABLE_REF(((long) 9));
										{
										   obj_t list2561_1278;
										   {
										      obj_t arg2562_1279;
										      {
											 obj_t arg2563_1280;
											 arg2563_1280 = MAKE_PAIR(BNIL, BNIL);
											 arg2562_1279 = MAKE_PAIR(arg2559_1276, arg2563_1280);
										      }
										      list2561_1278 = MAKE_PAIR(arg2558_1275, arg2562_1279);
										   }
										   arg2551_1269 = cons__138___r4_pairs_and_lists_6_3(arg2557_1274, list2561_1278);
										}
									     }
									     {
										obj_t list2553_1271;
										{
										   obj_t arg2555_1272;
										   arg2555_1272 = MAKE_PAIR(BNIL, BNIL);
										   list2553_1271 = MAKE_PAIR(ll1_1112, arg2555_1272);
										}
										arg2545_1264 = cons__138___r4_pairs_and_lists_6_3(arg2551_1269, list2553_1271);
									     }
									  }
									  {
									     obj_t list2547_1266;
									     {
										obj_t arg2548_1267;
										arg2548_1267 = MAKE_PAIR(BNIL, BNIL);
										list2547_1266 = MAKE_PAIR(arg2545_1264, arg2548_1267);
									     }
									     arg2537_1256 = cons__138___r4_pairs_and_lists_6_3(ll1_1112, list2547_1266);
									  }
								       }
								       {
									  obj_t arg2567_1282;
									  {
									     obj_t arg2574_1287;
									     {
										obj_t arg2579_1292;
										obj_t arg2580_1293;
										obj_t arg2582_1294;
										arg2579_1292 = CNST_TABLE_REF(((long) 7));
										arg2580_1293 = CNST_TABLE_REF(((long) 13));
										arg2582_1294 = CNST_TABLE_REF(((long) 9));
										{
										   obj_t list2584_1296;
										   {
										      obj_t arg2585_1297;
										      {
											 obj_t arg2586_1298;
											 arg2586_1298 = MAKE_PAIR(BNIL, BNIL);
											 arg2585_1297 = MAKE_PAIR(arg2582_1294, arg2586_1298);
										      }
										      list2584_1296 = MAKE_PAIR(arg2580_1293, arg2585_1297);
										   }
										   arg2574_1287 = cons__138___r4_pairs_and_lists_6_3(arg2579_1292, list2584_1296);
										}
									     }
									     {
										obj_t list2576_1289;
										{
										   obj_t arg2577_1290;
										   arg2577_1290 = MAKE_PAIR(BNIL, BNIL);
										   list2576_1289 = MAKE_PAIR(ll2_1113, arg2577_1290);
										}
										arg2567_1282 = cons__138___r4_pairs_and_lists_6_3(arg2574_1287, list2576_1289);
									     }
									  }
									  {
									     obj_t list2569_1284;
									     {
										obj_t arg2570_1285;
										arg2570_1285 = MAKE_PAIR(BNIL, BNIL);
										list2569_1284 = MAKE_PAIR(arg2567_1282, arg2570_1285);
									     }
									     arg2538_1257 = cons__138___r4_pairs_and_lists_6_3(ll2_1113, list2569_1284);
									  }
								       }
								       {
									  obj_t list2589_1301;
									  {
									     obj_t arg2590_1302;
									     arg2590_1302 = MAKE_PAIR(BNIL, BNIL);
									     list2589_1301 = MAKE_PAIR(head_1114, arg2590_1302);
									  }
									  arg2539_1258 = cons__138___r4_pairs_and_lists_6_3(tail_1115, list2589_1301);
								       }
								       {
									  obj_t list2541_1260;
									  {
									     obj_t arg2542_1261;
									     {
										obj_t arg2543_1262;
										arg2543_1262 = MAKE_PAIR(BNIL, BNIL);
										arg2542_1261 = MAKE_PAIR(arg2539_1258, arg2543_1262);
									     }
									     list2541_1260 = MAKE_PAIR(arg2538_1257, arg2542_1261);
									  }
									  arg2529_1248 = cons__138___r4_pairs_and_lists_6_3(arg2537_1256, list2541_1260);
								       }
								    }
								    {
								       obj_t arg2592_1304;
								       obj_t arg2593_1305;
								       obj_t arg2594_1306;
								       arg2592_1304 = CNST_TABLE_REF(((long) 6));
								       {
									  obj_t arg2601_1313;
									  {
									     obj_t arg2607_1318;
									     obj_t arg2608_1319;
									     obj_t arg2609_1320;
									     arg2607_1318 = CNST_TABLE_REF(((long) 7));
									     arg2608_1319 = CNST_TABLE_REF(((long) 8));
									     arg2609_1320 = CNST_TABLE_REF(((long) 9));
									     {
										obj_t list2611_1322;
										{
										   obj_t arg2612_1323;
										   {
										      obj_t arg2613_1324;
										      arg2613_1324 = MAKE_PAIR(BNIL, BNIL);
										      arg2612_1323 = MAKE_PAIR(arg2609_1320, arg2613_1324);
										   }
										   list2611_1322 = MAKE_PAIR(arg2608_1319, arg2612_1323);
										}
										arg2601_1313 = cons__138___r4_pairs_and_lists_6_3(arg2607_1318, list2611_1322);
									     }
									  }
									  {
									     obj_t list2603_1315;
									     {
										obj_t arg2605_1316;
										arg2605_1316 = MAKE_PAIR(BNIL, BNIL);
										list2603_1315 = MAKE_PAIR(ll1_1112, arg2605_1316);
									     }
									     arg2593_1305 = cons__138___r4_pairs_and_lists_6_3(arg2601_1313, list2603_1315);
									  }
								       }
								       {
									  obj_t arg2615_1326;
									  obj_t arg2616_1327;
									  obj_t arg2617_1328;
									  obj_t arg2618_1329;
									  arg2615_1326 = CNST_TABLE_REF(((long) 5));
									  {
									     obj_t arg2625_1336;
									     {
										obj_t arg2629_1340;
										{
										   obj_t arg2634_1345;
										   obj_t arg2636_1346;
										   obj_t arg2637_1347;
										   {
										      obj_t arg2644_1353;
										      obj_t arg2645_1354;
										      obj_t arg2646_1355;
										      arg2644_1353 = CNST_TABLE_REF(((long) 7));
										      arg2645_1354 = CNST_TABLE_REF(((long) 11));
										      arg2646_1355 = CNST_TABLE_REF(((long) 9));
										      {
											 obj_t list2648_1357;
											 {
											    obj_t arg2649_1358;
											    {
											       obj_t arg2650_1359;
											       arg2650_1359 = MAKE_PAIR(BNIL, BNIL);
											       arg2649_1358 = MAKE_PAIR(arg2646_1355, arg2650_1359);
											    }
											    list2648_1357 = MAKE_PAIR(arg2645_1354, arg2649_1358);
											 }
											 arg2634_1345 = cons__138___r4_pairs_and_lists_6_3(arg2644_1353, list2648_1357);
										      }
										   }
										   {
										      obj_t arg2652_1361;
										      obj_t arg2653_1362;
										      {
											 obj_t arg2659_1368;
											 {
											    obj_t arg2664_1373;
											    obj_t arg2665_1374;
											    obj_t arg2666_1375;
											    arg2664_1373 = CNST_TABLE_REF(((long) 7));
											    arg2665_1374 = CNST_TABLE_REF(((long) 12));
											    arg2666_1375 = CNST_TABLE_REF(((long) 9));
											    {
											       obj_t list2668_1377;
											       {
												  obj_t arg2669_1378;
												  {
												     obj_t arg2670_1379;
												     arg2670_1379 = MAKE_PAIR(BNIL, BNIL);
												     arg2669_1378 = MAKE_PAIR(arg2666_1375, arg2670_1379);
												  }
												  list2668_1377 = MAKE_PAIR(arg2665_1374, arg2669_1378);
											       }
											       arg2659_1368 = cons__138___r4_pairs_and_lists_6_3(arg2664_1373, list2668_1377);
											    }
											 }
											 {
											    obj_t list2661_1370;
											    {
											       obj_t arg2662_1371;
											       arg2662_1371 = MAKE_PAIR(BNIL, BNIL);
											       list2661_1370 = MAKE_PAIR(ll1_1112, arg2662_1371);
											    }
											    arg2652_1361 = cons__138___r4_pairs_and_lists_6_3(arg2659_1368, list2661_1370);
											 }
										      }
										      {
											 obj_t arg2672_1381;
											 {
											    obj_t arg2677_1386;
											    obj_t arg2678_1387;
											    obj_t arg2679_1388;
											    arg2677_1386 = CNST_TABLE_REF(((long) 7));
											    arg2678_1387 = CNST_TABLE_REF(((long) 12));
											    arg2679_1388 = CNST_TABLE_REF(((long) 9));
											    {
											       obj_t list2681_1390;
											       {
												  obj_t arg2683_1391;
												  {
												     obj_t arg2684_1392;
												     arg2684_1392 = MAKE_PAIR(BNIL, BNIL);
												     arg2683_1391 = MAKE_PAIR(arg2679_1388, arg2684_1392);
												  }
												  list2681_1390 = MAKE_PAIR(arg2678_1387, arg2683_1391);
											       }
											       arg2672_1381 = cons__138___r4_pairs_and_lists_6_3(arg2677_1386, list2681_1390);
											    }
											 }
											 {
											    obj_t list2674_1383;
											    {
											       obj_t arg2675_1384;
											       arg2675_1384 = MAKE_PAIR(BNIL, BNIL);
											       list2674_1383 = MAKE_PAIR(ll2_1113, arg2675_1384);
											    }
											    arg2653_1362 = cons__138___r4_pairs_and_lists_6_3(arg2672_1381, list2674_1383);
											 }
										      }
										      {
											 obj_t list2655_1364;
											 {
											    obj_t arg2656_1365;
											    {
											       obj_t arg2657_1366;
											       arg2657_1366 = MAKE_PAIR(BNIL, BNIL);
											       arg2656_1365 = MAKE_PAIR(arg2653_1362, arg2657_1366);
											    }
											    list2655_1364 = MAKE_PAIR(arg2652_1361, arg2656_1365);
											 }
											 arg2636_1346 = cons__138___r4_pairs_and_lists_6_3(fun_55, list2655_1364);
										      }
										   }
										   {
										      obj_t arg2687_1394;
										      arg2687_1394 = CNST_TABLE_REF(((long) 10));
										      {
											 obj_t list2690_1397;
											 {
											    obj_t arg2691_1398;
											    arg2691_1398 = MAKE_PAIR(BNIL, BNIL);
											    list2690_1397 = MAKE_PAIR(BNIL, arg2691_1398);
											 }
											 arg2637_1347 = cons__138___r4_pairs_and_lists_6_3(arg2687_1394, list2690_1397);
										      }
										   }
										   {
										      obj_t list2639_1349;
										      {
											 obj_t arg2640_1350;
											 {
											    obj_t arg2642_1351;
											    arg2642_1351 = MAKE_PAIR(BNIL, BNIL);
											    arg2640_1350 = MAKE_PAIR(arg2637_1347, arg2642_1351);
											 }
											 list2639_1349 = MAKE_PAIR(arg2636_1346, arg2640_1350);
										      }
										      arg2629_1340 = cons__138___r4_pairs_and_lists_6_3(arg2634_1345, list2639_1349);
										   }
										}
										{
										   obj_t list2631_1342;
										   {
										      obj_t arg2632_1343;
										      arg2632_1343 = MAKE_PAIR(BNIL, BNIL);
										      list2631_1342 = MAKE_PAIR(arg2629_1340, arg2632_1343);
										   }
										   arg2625_1336 = cons__138___r4_pairs_and_lists_6_3(ntail_1116, list2631_1342);
										}
									     }
									     {
										obj_t list2627_1338;
										list2627_1338 = MAKE_PAIR(BNIL, BNIL);
										arg2616_1327 = cons__138___r4_pairs_and_lists_6_3(arg2625_1336, list2627_1338);
									     }
									  }
									  {
									     obj_t arg2693_1400;
									     {
										obj_t arg2699_1406;
										obj_t arg2700_1407;
										obj_t arg2701_1408;
										arg2699_1406 = CNST_TABLE_REF(((long) 7));
										arg2700_1407 = CNST_TABLE_REF(((long) 14));
										arg2701_1408 = CNST_TABLE_REF(((long) 9));
										{
										   obj_t list2703_1410;
										   {
										      obj_t arg2704_1411;
										      {
											 obj_t arg2705_1412;
											 arg2705_1412 = MAKE_PAIR(BNIL, BNIL);
											 arg2704_1411 = MAKE_PAIR(arg2701_1408, arg2705_1412);
										      }
										      list2703_1410 = MAKE_PAIR(arg2700_1407, arg2704_1411);
										   }
										   arg2693_1400 = cons__138___r4_pairs_and_lists_6_3(arg2699_1406, list2703_1410);
										}
									     }
									     {
										obj_t list2695_1402;
										{
										   obj_t arg2696_1403;
										   {
										      obj_t arg2697_1404;
										      arg2697_1404 = MAKE_PAIR(BNIL, BNIL);
										      arg2696_1403 = MAKE_PAIR(ntail_1116, arg2697_1404);
										   }
										   list2695_1402 = MAKE_PAIR(tail_1115, arg2696_1403);
										}
										arg2617_1328 = cons__138___r4_pairs_and_lists_6_3(arg2693_1400, list2695_1402);
									     }
									  }
									  {
									     obj_t arg2707_1414;
									     obj_t arg2708_1415;
									     {
										obj_t arg2715_1422;
										{
										   obj_t arg2721_1427;
										   obj_t arg2722_1428;
										   obj_t arg2724_1429;
										   arg2721_1427 = CNST_TABLE_REF(((long) 7));
										   arg2722_1428 = CNST_TABLE_REF(((long) 13));
										   arg2724_1429 = CNST_TABLE_REF(((long) 9));
										   {
										      obj_t list2726_1431;
										      {
											 obj_t arg2727_1432;
											 {
											    obj_t arg2728_1433;
											    arg2728_1433 = MAKE_PAIR(BNIL, BNIL);
											    arg2727_1432 = MAKE_PAIR(arg2724_1429, arg2728_1433);
											 }
											 list2726_1431 = MAKE_PAIR(arg2722_1428, arg2727_1432);
										      }
										      arg2715_1422 = cons__138___r4_pairs_and_lists_6_3(arg2721_1427, list2726_1431);
										   }
										}
										{
										   obj_t list2717_1424;
										   {
										      obj_t arg2718_1425;
										      arg2718_1425 = MAKE_PAIR(BNIL, BNIL);
										      list2717_1424 = MAKE_PAIR(ll1_1112, arg2718_1425);
										   }
										   arg2707_1414 = cons__138___r4_pairs_and_lists_6_3(arg2715_1422, list2717_1424);
										}
									     }
									     {
										obj_t arg2730_1435;
										{
										   obj_t arg2735_1440;
										   obj_t arg2736_1441;
										   obj_t arg2737_1442;
										   arg2735_1440 = CNST_TABLE_REF(((long) 7));
										   arg2736_1441 = CNST_TABLE_REF(((long) 13));
										   arg2737_1442 = CNST_TABLE_REF(((long) 9));
										   {
										      obj_t list2739_1444;
										      {
											 obj_t arg2740_1445;
											 {
											    obj_t arg2741_1446;
											    arg2741_1446 = MAKE_PAIR(BNIL, BNIL);
											    arg2740_1445 = MAKE_PAIR(arg2737_1442, arg2741_1446);
											 }
											 list2739_1444 = MAKE_PAIR(arg2736_1441, arg2740_1445);
										      }
										      arg2730_1435 = cons__138___r4_pairs_and_lists_6_3(arg2735_1440, list2739_1444);
										   }
										}
										{
										   obj_t list2732_1437;
										   {
										      obj_t arg2733_1438;
										      arg2733_1438 = MAKE_PAIR(BNIL, BNIL);
										      list2732_1437 = MAKE_PAIR(ll2_1113, arg2733_1438);
										   }
										   arg2708_1415 = cons__138___r4_pairs_and_lists_6_3(arg2730_1435, list2732_1437);
										}
									     }
									     {
										obj_t list2710_1417;
										{
										   obj_t arg2711_1418;
										   {
										      obj_t arg2712_1419;
										      {
											 obj_t arg2713_1420;
											 arg2713_1420 = MAKE_PAIR(BNIL, BNIL);
											 arg2712_1419 = MAKE_PAIR(ntail_1116, arg2713_1420);
										      }
										      arg2711_1418 = MAKE_PAIR(arg2708_1415, arg2712_1419);
										   }
										   list2710_1417 = MAKE_PAIR(arg2707_1414, arg2711_1418);
										}
										arg2618_1329 = cons__138___r4_pairs_and_lists_6_3(lname_1117, list2710_1417);
									     }
									  }
									  {
									     obj_t list2620_1331;
									     {
										obj_t arg2621_1332;
										{
										   obj_t arg2622_1333;
										   {
										      obj_t arg2623_1334;
										      arg2623_1334 = MAKE_PAIR(BNIL, BNIL);
										      arg2622_1333 = MAKE_PAIR(arg2618_1329, arg2623_1334);
										   }
										   arg2621_1332 = MAKE_PAIR(arg2617_1328, arg2622_1333);
										}
										list2620_1331 = MAKE_PAIR(arg2616_1327, arg2621_1332);
									     }
									     arg2594_1306 = cons__138___r4_pairs_and_lists_6_3(arg2615_1326, list2620_1331);
									  }
								       }
								       {
									  obj_t list2596_1308;
									  {
									     obj_t arg2597_1309;
									     {
										obj_t arg2598_1310;
										{
										   obj_t arg2599_1311;
										   arg2599_1311 = MAKE_PAIR(BNIL, BNIL);
										   arg2598_1310 = MAKE_PAIR(arg2594_1306, arg2599_1311);
										}
										arg2597_1309 = MAKE_PAIR(head_1114, arg2598_1310);
									     }
									     list2596_1308 = MAKE_PAIR(arg2593_1305, arg2597_1309);
									  }
									  arg2530_1249 = cons__138___r4_pairs_and_lists_6_3(arg2592_1304, list2596_1308);
								       }
								    }
								    {
								       obj_t list2532_1251;
								       {
									  obj_t arg2533_1252;
									  {
									     obj_t arg2534_1253;
									     {
										obj_t arg2535_1254;
										arg2535_1254 = MAKE_PAIR(BNIL, BNIL);
										arg2534_1253 = MAKE_PAIR(arg2530_1249, arg2535_1254);
									     }
									     arg2533_1252 = MAKE_PAIR(arg2529_1248, arg2534_1253);
									  }
									  list2532_1251 = MAKE_PAIR(lname_1117, arg2533_1252);
								       }
								       arg2451_1177 = cons__138___r4_pairs_and_lists_6_3(arg2528_1247, list2532_1251);
								    }
								 }
								 {
								    obj_t list2453_1179;
								    {
								       obj_t arg2454_1180;
								       {
									  obj_t arg2455_1181;
									  arg2455_1181 = MAKE_PAIR(BNIL, BNIL);
									  arg2454_1180 = MAKE_PAIR(arg2451_1177, arg2455_1181);
								       }
								       list2453_1179 = MAKE_PAIR(arg2450_1176, arg2454_1180);
								    }
								    arg2422_1145 = cons__138___r4_pairs_and_lists_6_3(arg2449_1175, list2453_1179);
								 }
							      }
							   }
						      }
						      {
							 obj_t list2424_1147;
							 {
							    obj_t arg2425_1148;
							    {
							       obj_t arg2426_1149;
							       {
								  obj_t arg2427_1150;
								  arg2427_1150 = MAKE_PAIR(BNIL, BNIL);
								  arg2426_1149 = MAKE_PAIR(arg2422_1145, arg2427_1150);
							       }
							       arg2425_1148 = MAKE_PAIR(arg2421_1144, arg2426_1149);
							    }
							    list2424_1147 = MAKE_PAIR(arg2420_1143, arg2425_1148);
							 }
							 arg2399_1122 = cons__138___r4_pairs_and_lists_6_3(arg2419_1142, list2424_1147);
						      }
						   }
						   {
						      obj_t list2401_1124;
						      {
							 obj_t arg2402_1125;
							 {
							    obj_t arg2403_1126;
							    arg2403_1126 = MAKE_PAIR(BNIL, BNIL);
							    arg2402_1125 = MAKE_PAIR(arg2399_1122, arg2403_1126);
							 }
							 list2401_1124 = MAKE_PAIR(arg2396_1121, arg2402_1125);
						      }
						      arg2392_1119 = cons__138___r4_pairs_and_lists_6_3(arg2394_1120, list2401_1124);
						   }
						}
						res_1118 = PROCEDURE_ENTRY(e_2) (e_2, arg2392_1119, e_2, BEOA);
					     }
					     return replace__160_tools_misc(x_1, res_1118);
					  }
				       }
				    }
				  else
				    {
				       fun_59 = CAR(cdr_114_48_65);
				       lists_60 = CDR(cdr_114_48_65);
				     tag_103_156_61:
				       {
					  obj_t res_1692;
					  {
					     obj_t arg2997_1693;
					     obj_t arg2999_1694;
					     obj_t arg3000_1695;
					     arg2997_1693 = CNST_TABLE_REF(((long) 21));
					     arg2999_1694 = PROCEDURE_ENTRY(e_2) (e_2, fun_59, e_2, BEOA);
					     {
						obj_t arg3004_1699;
						obj_t arg3005_1700;
						if (NULLP(lists_60))
						  {
						     arg3004_1699 = BNIL;
						  }
						else
						  {
						     obj_t head1030_1703;
						     head1030_1703 = MAKE_PAIR(BNIL, BNIL);
						     {
							obj_t l1028_1704;
							obj_t tail1031_1705;
							l1028_1704 = lists_60;
							tail1031_1705 = head1030_1703;
						      lname1029_1706:
							if (NULLP(l1028_1704))
							  {
							     arg3004_1699 = CDR(head1030_1703);
							  }
							else
							  {
							     obj_t newtail1032_1708;
							     {
								obj_t arg3009_1710;
								arg3009_1710 = PROCEDURE_ENTRY(e_2) (e_2, CAR(l1028_1704), e_2, BEOA);
								newtail1032_1708 = MAKE_PAIR(arg3009_1710, BNIL);
							     }
							     SET_CDR(tail1031_1705, newtail1032_1708);
							     {
								obj_t tail1031_3428;
								obj_t l1028_3426;
								l1028_3426 = CDR(l1028_1704);
								tail1031_3428 = newtail1032_1708;
								tail1031_1705 = tail1031_3428;
								l1028_1704 = l1028_3426;
								goto lname1029_1706;
							     }
							  }
						     }
						  }
						arg3005_1700 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg3000_1695 = append_2_18___r4_pairs_and_lists_6_3(arg3004_1699, arg3005_1700);
					     }
					     {
						obj_t list3001_1696;
						{
						   obj_t arg3002_1697;
						   arg3002_1697 = MAKE_PAIR(arg3000_1695, BNIL);
						   list3001_1696 = MAKE_PAIR(arg2999_1694, arg3002_1697);
						}
						res_1692 = cons__138___r4_pairs_and_lists_6_3(arg2997_1693, list3001_1696);
					     }
					  }
					  return replace__160_tools_misc(x_1, res_1692);
				       }
				    }
			       }
			     else
			       {
				  obj_t lists_3439;
				  obj_t fun_3437;
				  fun_3437 = CAR(cdr_114_48_65);
				  lists_3439 = CDR(cdr_114_48_65);
				  lists_60 = lists_3439;
				  fun_59 = fun_3437;
				  goto tag_103_156_61;
			       }
			  }
		       }
		  }
		else
		  {
		     obj_t lists_3443;
		     obj_t fun_3441;
		     fun_3441 = CAR(cdr_114_48_65);
		     lists_3443 = CDR(cdr_114_48_65);
		     lists_60 = lists_3443;
		     fun_59 = fun_3441;
		     goto tag_103_156_61;
		  }
	     }
	   else
	     {
	      tag_104_254_62:
		FAILURE(BFALSE, string3396_expand_map, x_1);
	     }
	}
      else
	{
	   goto tag_104_254_62;
	}
   }
}


/* _expand-map */ obj_t 
_expand_map_144_expand_map(obj_t env_2230, obj_t x_2231, obj_t e_2232)
{
   return expand_map_185_expand_map(x_2231, e_2232);
}


/* expand-for-each */ obj_t 
expand_for_each_88_expand_map(obj_t x_3, obj_t e_4)
{
   {
      obj_t fun_1724;
      obj_t lists_1725;
      obj_t fun_1720;
      obj_t l1_1721;
      obj_t l2_1722;
      obj_t fun_1717;
      obj_t list_1718;
      if (PAIRP(x_3))
	{
	   obj_t cdr_258_124_1730;
	   cdr_258_124_1730 = CDR(x_3);
	   if (PAIRP(cdr_258_124_1730))
	     {
		obj_t cdr_262_194_1732;
		cdr_262_194_1732 = CDR(cdr_258_124_1730);
		if (PAIRP(cdr_262_194_1732))
		  {
		     bool_t test_3455;
		     {
			obj_t aux_3456;
			aux_3456 = CDR(cdr_262_194_1732);
			test_3455 = (aux_3456 == BNIL);
		     }
		     if (test_3455)
		       {
			  fun_1717 = CAR(cdr_258_124_1730);
			  list_1718 = CAR(cdr_262_194_1732);
			  {
			     obj_t l_1758;
			     {
				obj_t arg3252_1976;
				arg3252_1976 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
				l_1758 = mark_symbol_non_user__17_ast_ident(arg3252_1976);
			     }
			     {
				obj_t lname_1759;
				{
				   obj_t arg3250_1974;
				   arg3250_1974 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
				   lname_1759 = mark_symbol_non_user__17_ast_ident(arg3250_1974);
				}
				{
				   obj_t loop_1760;
				   if (CBOOL(_unsafe_type__146_engine_param))
				     {
					obj_t arg3036_1762;
					obj_t arg3037_1763;
					obj_t arg3038_1764;
					arg3036_1762 = CNST_TABLE_REF(((long) 5));
					{
					   obj_t arg3045_1771;
					   {
					      obj_t list3050_1776;
					      {
						 obj_t arg3051_1777;
						 arg3051_1777 = MAKE_PAIR(BNIL, BNIL);
						 list3050_1776 = MAKE_PAIR(list_1718, arg3051_1777);
					      }
					      arg3045_1771 = cons__138___r4_pairs_and_lists_6_3(l_1758, list3050_1776);
					   }
					   {
					      obj_t list3047_1773;
					      list3047_1773 = MAKE_PAIR(BNIL, BNIL);
					      arg3037_1763 = cons__138___r4_pairs_and_lists_6_3(arg3045_1771, list3047_1773);
					   }
					}
					{
					   obj_t arg3053_1779;
					   obj_t arg3054_1780;
					   obj_t arg3055_1781;
					   arg3053_1779 = CNST_TABLE_REF(((long) 15));
					   {
					      obj_t arg3061_1787;
					      obj_t arg3062_1788;
					      obj_t arg3063_1789;
					      {
						 obj_t arg3069_1795;
						 {
						    obj_t arg3074_1800;
						    obj_t arg3075_1801;
						    obj_t arg3076_1802;
						    arg3074_1800 = CNST_TABLE_REF(((long) 7));
						    arg3075_1801 = CNST_TABLE_REF(((long) 16));
						    arg3076_1802 = CNST_TABLE_REF(((long) 9));
						    {
						       obj_t list3078_1804;
						       {
							  obj_t arg3079_1805;
							  {
							     obj_t arg3080_1806;
							     arg3080_1806 = MAKE_PAIR(BNIL, BNIL);
							     arg3079_1805 = MAKE_PAIR(arg3076_1802, arg3080_1806);
							  }
							  list3078_1804 = MAKE_PAIR(arg3075_1801, arg3079_1805);
						       }
						       arg3069_1795 = cons__138___r4_pairs_and_lists_6_3(arg3074_1800, list3078_1804);
						    }
						 }
						 {
						    obj_t list3071_1797;
						    {
						       obj_t arg3072_1798;
						       arg3072_1798 = MAKE_PAIR(BNIL, BNIL);
						       list3071_1797 = MAKE_PAIR(l_1758, arg3072_1798);
						    }
						    arg3061_1787 = cons__138___r4_pairs_and_lists_6_3(arg3069_1795, list3071_1797);
						 }
					      }
					      {
						 obj_t arg3082_1808;
						 {
						    obj_t arg3087_1813;
						    {
						       obj_t arg3092_1818;
						       obj_t arg3093_1819;
						       obj_t arg3094_1820;
						       arg3092_1818 = CNST_TABLE_REF(((long) 7));
						       arg3093_1819 = CNST_TABLE_REF(((long) 12));
						       arg3094_1820 = CNST_TABLE_REF(((long) 9));
						       {
							  obj_t list3096_1822;
							  {
							     obj_t arg3097_1823;
							     {
								obj_t arg3098_1824;
								arg3098_1824 = MAKE_PAIR(BNIL, BNIL);
								arg3097_1823 = MAKE_PAIR(arg3094_1820, arg3098_1824);
							     }
							     list3096_1822 = MAKE_PAIR(arg3093_1819, arg3097_1823);
							  }
							  arg3087_1813 = cons__138___r4_pairs_and_lists_6_3(arg3092_1818, list3096_1822);
						       }
						    }
						    {
						       obj_t list3089_1815;
						       {
							  obj_t arg3090_1816;
							  arg3090_1816 = MAKE_PAIR(BNIL, BNIL);
							  list3089_1815 = MAKE_PAIR(l_1758, arg3090_1816);
						       }
						       arg3082_1808 = cons__138___r4_pairs_and_lists_6_3(arg3087_1813, list3089_1815);
						    }
						 }
						 {
						    obj_t list3084_1810;
						    {
						       obj_t arg3085_1811;
						       arg3085_1811 = MAKE_PAIR(BNIL, BNIL);
						       list3084_1810 = MAKE_PAIR(arg3082_1808, arg3085_1811);
						    }
						    arg3062_1788 = cons__138___r4_pairs_and_lists_6_3(fun_1717, list3084_1810);
						 }
					      }
					      {
						 obj_t arg3100_1826;
						 {
						    obj_t arg3105_1831;
						    {
						       obj_t arg3110_1836;
						       obj_t arg3111_1837;
						       obj_t arg3112_1838;
						       arg3110_1836 = CNST_TABLE_REF(((long) 7));
						       arg3111_1837 = CNST_TABLE_REF(((long) 13));
						       arg3112_1838 = CNST_TABLE_REF(((long) 9));
						       {
							  obj_t list3114_1840;
							  {
							     obj_t arg3115_1841;
							     {
								obj_t arg3116_1842;
								arg3116_1842 = MAKE_PAIR(BNIL, BNIL);
								arg3115_1841 = MAKE_PAIR(arg3112_1838, arg3116_1842);
							     }
							     list3114_1840 = MAKE_PAIR(arg3111_1837, arg3115_1841);
							  }
							  arg3105_1831 = cons__138___r4_pairs_and_lists_6_3(arg3110_1836, list3114_1840);
						       }
						    }
						    {
						       obj_t list3107_1833;
						       {
							  obj_t arg3108_1834;
							  arg3108_1834 = MAKE_PAIR(BNIL, BNIL);
							  list3107_1833 = MAKE_PAIR(l_1758, arg3108_1834);
						       }
						       arg3100_1826 = cons__138___r4_pairs_and_lists_6_3(arg3105_1831, list3107_1833);
						    }
						 }
						 {
						    obj_t list3102_1828;
						    {
						       obj_t arg3103_1829;
						       arg3103_1829 = MAKE_PAIR(BNIL, BNIL);
						       list3102_1828 = MAKE_PAIR(arg3100_1826, arg3103_1829);
						    }
						    arg3063_1789 = cons__138___r4_pairs_and_lists_6_3(lname_1759, list3102_1828);
						 }
					      }
					      {
						 obj_t list3065_1791;
						 {
						    obj_t arg3066_1792;
						    {
						       obj_t arg3067_1793;
						       arg3067_1793 = MAKE_PAIR(BNIL, BNIL);
						       arg3066_1792 = MAKE_PAIR(arg3063_1789, arg3067_1793);
						    }
						    list3065_1791 = MAKE_PAIR(arg3062_1788, arg3066_1792);
						 }
						 arg3054_1780 = cons__138___r4_pairs_and_lists_6_3(arg3061_1787, list3065_1791);
					      }
					   }
					   {
					      obj_t arg3118_1844;
					      arg3118_1844 = CNST_TABLE_REF(((long) 17));
					      {
						 obj_t list3120_1846;
						 {
						    obj_t arg3121_1847;
						    arg3121_1847 = MAKE_PAIR(BNIL, BNIL);
						    list3120_1846 = MAKE_PAIR(BTRUE, arg3121_1847);
						 }
						 arg3055_1781 = cons__138___r4_pairs_and_lists_6_3(arg3118_1844, list3120_1846);
					      }
					   }
					   {
					      obj_t list3057_1783;
					      {
						 obj_t arg3058_1784;
						 {
						    obj_t arg3059_1785;
						    arg3059_1785 = MAKE_PAIR(BNIL, BNIL);
						    arg3058_1784 = MAKE_PAIR(arg3055_1781, arg3059_1785);
						 }
						 list3057_1783 = MAKE_PAIR(arg3054_1780, arg3058_1784);
					      }
					      arg3038_1764 = cons__138___r4_pairs_and_lists_6_3(arg3053_1779, list3057_1783);
					   }
					}
					{
					   obj_t list3040_1766;
					   {
					      obj_t arg3041_1767;
					      {
						 obj_t arg3042_1768;
						 {
						    obj_t arg3043_1769;
						    arg3043_1769 = MAKE_PAIR(BNIL, BNIL);
						    arg3042_1768 = MAKE_PAIR(arg3038_1764, arg3043_1769);
						 }
						 arg3041_1767 = MAKE_PAIR(arg3037_1763, arg3042_1768);
					      }
					      list3040_1766 = MAKE_PAIR(lname_1759, arg3041_1767);
					   }
					   loop_1760 = cons__138___r4_pairs_and_lists_6_3(arg3036_1762, list3040_1766);
					}
				     }
				   else
				     {
					obj_t arg3123_1849;
					obj_t arg3124_1850;
					obj_t arg3125_1851;
					arg3123_1849 = CNST_TABLE_REF(((long) 5));
					{
					   obj_t arg3133_1858;
					   {
					      obj_t list3138_1863;
					      {
						 obj_t arg3139_1864;
						 arg3139_1864 = MAKE_PAIR(BNIL, BNIL);
						 list3138_1863 = MAKE_PAIR(list_1718, arg3139_1864);
					      }
					      arg3133_1858 = cons__138___r4_pairs_and_lists_6_3(l_1758, list3138_1863);
					   }
					   {
					      obj_t list3135_1860;
					      list3135_1860 = MAKE_PAIR(BNIL, BNIL);
					      arg3124_1850 = cons__138___r4_pairs_and_lists_6_3(arg3133_1858, list3135_1860);
					   }
					}
					{
					   obj_t arg3141_1866;
					   obj_t arg3142_1867;
					   obj_t arg3143_1868;
					   obj_t arg3144_1869;
					   arg3141_1866 = CNST_TABLE_REF(((long) 15));
					   {
					      obj_t arg3151_1876;
					      obj_t arg3152_1877;
					      obj_t arg3153_1878;
					      {
						 obj_t arg3159_1884;
						 {
						    obj_t arg3164_1889;
						    obj_t arg3165_1890;
						    obj_t arg3166_1891;
						    arg3164_1889 = CNST_TABLE_REF(((long) 7));
						    arg3165_1890 = CNST_TABLE_REF(((long) 16));
						    arg3166_1891 = CNST_TABLE_REF(((long) 9));
						    {
						       obj_t list3168_1893;
						       {
							  obj_t arg3169_1894;
							  {
							     obj_t arg3170_1895;
							     arg3170_1895 = MAKE_PAIR(BNIL, BNIL);
							     arg3169_1894 = MAKE_PAIR(arg3166_1891, arg3170_1895);
							  }
							  list3168_1893 = MAKE_PAIR(arg3165_1890, arg3169_1894);
						       }
						       arg3159_1884 = cons__138___r4_pairs_and_lists_6_3(arg3164_1889, list3168_1893);
						    }
						 }
						 {
						    obj_t list3161_1886;
						    {
						       obj_t arg3162_1887;
						       arg3162_1887 = MAKE_PAIR(BNIL, BNIL);
						       list3161_1886 = MAKE_PAIR(l_1758, arg3162_1887);
						    }
						    arg3151_1876 = cons__138___r4_pairs_and_lists_6_3(arg3159_1884, list3161_1886);
						 }
					      }
					      {
						 obj_t arg3172_1897;
						 {
						    obj_t arg3177_1902;
						    {
						       obj_t arg3182_1907;
						       obj_t arg3183_1908;
						       obj_t arg3184_1909;
						       arg3182_1907 = CNST_TABLE_REF(((long) 7));
						       arg3183_1908 = CNST_TABLE_REF(((long) 12));
						       arg3184_1909 = CNST_TABLE_REF(((long) 9));
						       {
							  obj_t list3186_1911;
							  {
							     obj_t arg3187_1912;
							     {
								obj_t arg3188_1913;
								arg3188_1913 = MAKE_PAIR(BNIL, BNIL);
								arg3187_1912 = MAKE_PAIR(arg3184_1909, arg3188_1913);
							     }
							     list3186_1911 = MAKE_PAIR(arg3183_1908, arg3187_1912);
							  }
							  arg3177_1902 = cons__138___r4_pairs_and_lists_6_3(arg3182_1907, list3186_1911);
						       }
						    }
						    {
						       obj_t list3179_1904;
						       {
							  obj_t arg3180_1905;
							  arg3180_1905 = MAKE_PAIR(BNIL, BNIL);
							  list3179_1904 = MAKE_PAIR(l_1758, arg3180_1905);
						       }
						       arg3172_1897 = cons__138___r4_pairs_and_lists_6_3(arg3177_1902, list3179_1904);
						    }
						 }
						 {
						    obj_t list3174_1899;
						    {
						       obj_t arg3175_1900;
						       arg3175_1900 = MAKE_PAIR(BNIL, BNIL);
						       list3174_1899 = MAKE_PAIR(arg3172_1897, arg3175_1900);
						    }
						    arg3152_1877 = cons__138___r4_pairs_and_lists_6_3(fun_1717, list3174_1899);
						 }
					      }
					      {
						 obj_t arg3190_1915;
						 {
						    obj_t arg3195_1920;
						    {
						       obj_t arg3200_1925;
						       obj_t arg3201_1926;
						       obj_t arg3202_1927;
						       arg3200_1925 = CNST_TABLE_REF(((long) 7));
						       arg3201_1926 = CNST_TABLE_REF(((long) 13));
						       arg3202_1927 = CNST_TABLE_REF(((long) 9));
						       {
							  obj_t list3204_1929;
							  {
							     obj_t arg3205_1930;
							     {
								obj_t arg3206_1931;
								arg3206_1931 = MAKE_PAIR(BNIL, BNIL);
								arg3205_1930 = MAKE_PAIR(arg3202_1927, arg3206_1931);
							     }
							     list3204_1929 = MAKE_PAIR(arg3201_1926, arg3205_1930);
							  }
							  arg3195_1920 = cons__138___r4_pairs_and_lists_6_3(arg3200_1925, list3204_1929);
						       }
						    }
						    {
						       obj_t list3197_1922;
						       {
							  obj_t arg3198_1923;
							  arg3198_1923 = MAKE_PAIR(BNIL, BNIL);
							  list3197_1922 = MAKE_PAIR(l_1758, arg3198_1923);
						       }
						       arg3190_1915 = cons__138___r4_pairs_and_lists_6_3(arg3195_1920, list3197_1922);
						    }
						 }
						 {
						    obj_t list3192_1917;
						    {
						       obj_t arg3193_1918;
						       arg3193_1918 = MAKE_PAIR(BNIL, BNIL);
						       list3192_1917 = MAKE_PAIR(arg3190_1915, arg3193_1918);
						    }
						    arg3153_1878 = cons__138___r4_pairs_and_lists_6_3(lname_1759, list3192_1917);
						 }
					      }
					      {
						 obj_t list3155_1880;
						 {
						    obj_t arg3156_1881;
						    {
						       obj_t arg3157_1882;
						       arg3157_1882 = MAKE_PAIR(BNIL, BNIL);
						       arg3156_1881 = MAKE_PAIR(arg3153_1878, arg3157_1882);
						    }
						    list3155_1880 = MAKE_PAIR(arg3152_1877, arg3156_1881);
						 }
						 arg3142_1867 = cons__138___r4_pairs_and_lists_6_3(arg3151_1876, list3155_1880);
					      }
					   }
					   {
					      obj_t arg3208_1933;
					      {
						 obj_t arg3213_1938;
						 {
						    obj_t arg3218_1943;
						    obj_t arg3219_1944;
						    obj_t arg3220_1945;
						    arg3218_1943 = CNST_TABLE_REF(((long) 7));
						    arg3219_1944 = CNST_TABLE_REF(((long) 8));
						    arg3220_1945 = CNST_TABLE_REF(((long) 9));
						    {
						       obj_t list3222_1947;
						       {
							  obj_t arg3223_1948;
							  {
							     obj_t arg3224_1949;
							     arg3224_1949 = MAKE_PAIR(BNIL, BNIL);
							     arg3223_1948 = MAKE_PAIR(arg3220_1945, arg3224_1949);
							  }
							  list3222_1947 = MAKE_PAIR(arg3219_1944, arg3223_1948);
						       }
						       arg3213_1938 = cons__138___r4_pairs_and_lists_6_3(arg3218_1943, list3222_1947);
						    }
						 }
						 {
						    obj_t list3215_1940;
						    {
						       obj_t arg3216_1941;
						       arg3216_1941 = MAKE_PAIR(BNIL, BNIL);
						       list3215_1940 = MAKE_PAIR(l_1758, arg3216_1941);
						    }
						    arg3208_1933 = cons__138___r4_pairs_and_lists_6_3(arg3213_1938, list3215_1940);
						 }
					      }
					      {
						 obj_t list3210_1935;
						 {
						    obj_t arg3211_1936;
						    arg3211_1936 = MAKE_PAIR(BNIL, BNIL);
						    list3210_1935 = MAKE_PAIR(BTRUE, arg3211_1936);
						 }
						 arg3143_1868 = cons__138___r4_pairs_and_lists_6_3(arg3208_1933, list3210_1935);
					      }
					   }
					   {
					      obj_t arg3226_1951;
					      obj_t arg3227_1952;
					      arg3226_1951 = CNST_TABLE_REF(((long) 17));
					      {
						 obj_t arg3232_1957;
						 {
						    obj_t arg3242_1966;
						    obj_t arg3243_1967;
						    obj_t arg3244_1968;
						    arg3242_1966 = CNST_TABLE_REF(((long) 7));
						    arg3243_1967 = CNST_TABLE_REF(((long) 18));
						    arg3244_1968 = CNST_TABLE_REF(((long) 19));
						    {
						       obj_t list3246_1970;
						       {
							  obj_t arg3247_1971;
							  {
							     obj_t arg3248_1972;
							     arg3248_1972 = MAKE_PAIR(BNIL, BNIL);
							     arg3247_1971 = MAKE_PAIR(arg3244_1968, arg3248_1972);
							  }
							  list3246_1970 = MAKE_PAIR(arg3243_1967, arg3247_1971);
						       }
						       arg3232_1957 = cons__138___r4_pairs_and_lists_6_3(arg3242_1966, list3246_1970);
						    }
						 }
						 {
						    obj_t list3237_1961;
						    {
						       obj_t arg3238_1962;
						       {
							  obj_t arg3239_1963;
							  {
							     obj_t arg3240_1964;
							     arg3240_1964 = MAKE_PAIR(BNIL, BNIL);
							     arg3239_1963 = MAKE_PAIR(l_1758, arg3240_1964);
							  }
							  arg3238_1962 = MAKE_PAIR(string3394_expand_map, arg3239_1963);
						       }
						       list3237_1961 = MAKE_PAIR(string3397_expand_map, arg3238_1962);
						    }
						    arg3227_1952 = cons__138___r4_pairs_and_lists_6_3(arg3232_1957, list3237_1961);
						 }
					      }
					      {
						 obj_t list3229_1954;
						 {
						    obj_t arg3230_1955;
						    arg3230_1955 = MAKE_PAIR(BNIL, BNIL);
						    list3229_1954 = MAKE_PAIR(arg3227_1952, arg3230_1955);
						 }
						 arg3144_1869 = cons__138___r4_pairs_and_lists_6_3(arg3226_1951, list3229_1954);
					      }
					   }
					   {
					      obj_t list3146_1871;
					      {
						 obj_t arg3147_1872;
						 {
						    obj_t arg3148_1873;
						    {
						       obj_t arg3149_1874;
						       arg3149_1874 = MAKE_PAIR(BNIL, BNIL);
						       arg3148_1873 = MAKE_PAIR(arg3144_1869, arg3149_1874);
						    }
						    arg3147_1872 = MAKE_PAIR(arg3143_1868, arg3148_1873);
						 }
						 list3146_1871 = MAKE_PAIR(arg3142_1867, arg3147_1872);
					      }
					      arg3125_1851 = cons__138___r4_pairs_and_lists_6_3(arg3141_1866, list3146_1871);
					   }
					}
					{
					   obj_t list3127_1853;
					   {
					      obj_t arg3129_1854;
					      {
						 obj_t arg3130_1855;
						 {
						    obj_t arg3131_1856;
						    arg3131_1856 = MAKE_PAIR(BNIL, BNIL);
						    arg3130_1855 = MAKE_PAIR(arg3125_1851, arg3131_1856);
						 }
						 arg3129_1854 = MAKE_PAIR(arg3124_1850, arg3130_1855);
					      }
					      list3127_1853 = MAKE_PAIR(lname_1759, arg3129_1854);
					   }
					   loop_1760 = cons__138___r4_pairs_and_lists_6_3(arg3123_1849, list3127_1853);
					}
				     }
				   {
				      {
					 obj_t res_1761;
					 res_1761 = PROCEDURE_ENTRY(e_4) (e_4, loop_1760, e_4, BEOA);
					 return replace__160_tools_misc(x_3, res_1761);
				      }
				   }
				}
			     }
			  }
		       }
		     else
		       {
			  obj_t cdr_285_106_1738;
			  cdr_285_106_1738 = CDR(cdr_258_124_1730);
			  {
			     obj_t cdr_292_5_1739;
			     cdr_292_5_1739 = CDR(cdr_285_106_1738);
			     if (PAIRP(cdr_292_5_1739))
			       {
				  bool_t test_3624;
				  {
				     obj_t aux_3625;
				     aux_3625 = CDR(cdr_292_5_1739);
				     test_3624 = (aux_3625 == BNIL);
				  }
				  if (test_3624)
				    {
				       fun_1720 = CAR(cdr_258_124_1730);
				       l1_1721 = CAR(cdr_285_106_1738);
				       l2_1722 = CAR(cdr_292_5_1739);
				       {
					  obj_t ll1_1978;
					  {
					     obj_t arg3371_2098;
					     arg3371_2098 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 20)), BEOA);
					     ll1_1978 = mark_symbol_non_user__17_ast_ident(arg3371_2098);
					  }
					  {
					     obj_t ll2_1979;
					     {
						obj_t arg3369_2096;
						arg3369_2096 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 20)), BEOA);
						ll2_1979 = mark_symbol_non_user__17_ast_ident(arg3369_2096);
					     }
					     {
						obj_t lname_1980;
						{
						   obj_t arg3367_2094;
						   arg3367_2094 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
						   lname_1980 = mark_symbol_non_user__17_ast_ident(arg3367_2094);
						}
						{
						   obj_t loop_1981;
						   {
						      obj_t arg3254_1983;
						      obj_t arg3255_1984;
						      obj_t arg3256_1985;
						      arg3254_1983 = CNST_TABLE_REF(((long) 5));
						      {
							 obj_t arg3264_1992;
							 obj_t arg3265_1993;
							 {
							    obj_t list3271_1999;
							    {
							       obj_t arg3272_2000;
							       arg3272_2000 = MAKE_PAIR(BNIL, BNIL);
							       list3271_1999 = MAKE_PAIR(l1_1721, arg3272_2000);
							    }
							    arg3264_1992 = cons__138___r4_pairs_and_lists_6_3(ll1_1978, list3271_1999);
							 }
							 {
							    obj_t list3275_2003;
							    {
							       obj_t arg3276_2004;
							       arg3276_2004 = MAKE_PAIR(BNIL, BNIL);
							       list3275_2003 = MAKE_PAIR(l2_1722, arg3276_2004);
							    }
							    arg3265_1993 = cons__138___r4_pairs_and_lists_6_3(ll2_1979, list3275_2003);
							 }
							 {
							    obj_t list3267_1995;
							    {
							       obj_t arg3268_1996;
							       arg3268_1996 = MAKE_PAIR(BNIL, BNIL);
							       list3267_1995 = MAKE_PAIR(arg3265_1993, arg3268_1996);
							    }
							    arg3255_1984 = cons__138___r4_pairs_and_lists_6_3(arg3264_1992, list3267_1995);
							 }
						      }
						      {
							 obj_t arg3278_2006;
							 obj_t arg3279_2007;
							 obj_t arg3280_2008;
							 arg3278_2006 = CNST_TABLE_REF(((long) 6));
							 {
							    obj_t arg3287_2015;
							    {
							       obj_t arg3292_2020;
							       obj_t arg3293_2021;
							       obj_t arg3294_2022;
							       arg3292_2020 = CNST_TABLE_REF(((long) 7));
							       arg3293_2021 = CNST_TABLE_REF(((long) 8));
							       arg3294_2022 = CNST_TABLE_REF(((long) 9));
							       {
								  obj_t list3296_2024;
								  {
								     obj_t arg3297_2025;
								     {
									obj_t arg3298_2026;
									arg3298_2026 = MAKE_PAIR(BNIL, BNIL);
									arg3297_2025 = MAKE_PAIR(arg3294_2022, arg3298_2026);
								     }
								     list3296_2024 = MAKE_PAIR(arg3293_2021, arg3297_2025);
								  }
								  arg3287_2015 = cons__138___r4_pairs_and_lists_6_3(arg3292_2020, list3296_2024);
							       }
							    }
							    {
							       obj_t list3289_2017;
							       {
								  obj_t arg3290_2018;
								  arg3290_2018 = MAKE_PAIR(BNIL, BNIL);
								  list3289_2017 = MAKE_PAIR(ll1_1978, arg3290_2018);
							       }
							       arg3279_2007 = cons__138___r4_pairs_and_lists_6_3(arg3287_2015, list3289_2017);
							    }
							 }
							 {
							    obj_t arg3300_2028;
							    obj_t arg3301_2029;
							    obj_t arg3302_2030;
							    arg3300_2028 = CNST_TABLE_REF(((long) 22));
							    {
							       obj_t arg3308_2036;
							       obj_t arg3309_2037;
							       {
								  obj_t arg3315_2043;
								  {
								     obj_t arg3320_2048;
								     obj_t arg3321_2049;
								     obj_t arg3322_2050;
								     arg3320_2048 = CNST_TABLE_REF(((long) 7));
								     arg3321_2049 = CNST_TABLE_REF(((long) 12));
								     arg3322_2050 = CNST_TABLE_REF(((long) 9));
								     {
									obj_t list3324_2052;
									{
									   obj_t arg3325_2053;
									   {
									      obj_t arg3326_2054;
									      arg3326_2054 = MAKE_PAIR(BNIL, BNIL);
									      arg3325_2053 = MAKE_PAIR(arg3322_2050, arg3326_2054);
									   }
									   list3324_2052 = MAKE_PAIR(arg3321_2049, arg3325_2053);
									}
									arg3315_2043 = cons__138___r4_pairs_and_lists_6_3(arg3320_2048, list3324_2052);
								     }
								  }
								  {
								     obj_t list3317_2045;
								     {
									obj_t arg3318_2046;
									arg3318_2046 = MAKE_PAIR(BNIL, BNIL);
									list3317_2045 = MAKE_PAIR(ll1_1978, arg3318_2046);
								     }
								     arg3308_2036 = cons__138___r4_pairs_and_lists_6_3(arg3315_2043, list3317_2045);
								  }
							       }
							       {
								  obj_t arg3328_2056;
								  arg3328_2056 = CNST_TABLE_REF(((long) 12));
								  {
								     obj_t list3330_2058;
								     {
									obj_t arg3331_2059;
									arg3331_2059 = MAKE_PAIR(BNIL, BNIL);
									list3330_2058 = MAKE_PAIR(ll2_1979, arg3331_2059);
								     }
								     arg3309_2037 = cons__138___r4_pairs_and_lists_6_3(arg3328_2056, list3330_2058);
								  }
							       }
							       {
								  obj_t list3311_2039;
								  {
								     obj_t arg3312_2040;
								     {
									obj_t arg3313_2041;
									arg3313_2041 = MAKE_PAIR(BNIL, BNIL);
									arg3312_2040 = MAKE_PAIR(arg3309_2037, arg3313_2041);
								     }
								     list3311_2039 = MAKE_PAIR(arg3308_2036, arg3312_2040);
								  }
								  arg3301_2029 = cons__138___r4_pairs_and_lists_6_3(fun_1720, list3311_2039);
							       }
							    }
							    {
							       obj_t arg3333_2061;
							       obj_t arg3334_2062;
							       {
								  obj_t arg3340_2068;
								  {
								     obj_t arg3345_2073;
								     obj_t arg3346_2074;
								     obj_t arg3347_2075;
								     arg3345_2073 = CNST_TABLE_REF(((long) 7));
								     arg3346_2074 = CNST_TABLE_REF(((long) 13));
								     arg3347_2075 = CNST_TABLE_REF(((long) 9));
								     {
									obj_t list3349_2077;
									{
									   obj_t arg3350_2078;
									   {
									      obj_t arg3351_2079;
									      arg3351_2079 = MAKE_PAIR(BNIL, BNIL);
									      arg3350_2078 = MAKE_PAIR(arg3347_2075, arg3351_2079);
									   }
									   list3349_2077 = MAKE_PAIR(arg3346_2074, arg3350_2078);
									}
									arg3340_2068 = cons__138___r4_pairs_and_lists_6_3(arg3345_2073, list3349_2077);
								     }
								  }
								  {
								     obj_t list3342_2070;
								     {
									obj_t arg3343_2071;
									arg3343_2071 = MAKE_PAIR(BNIL, BNIL);
									list3342_2070 = MAKE_PAIR(ll1_1978, arg3343_2071);
								     }
								     arg3333_2061 = cons__138___r4_pairs_and_lists_6_3(arg3340_2068, list3342_2070);
								  }
							       }
							       {
								  obj_t arg3353_2081;
								  {
								     obj_t arg3358_2086;
								     obj_t arg3359_2087;
								     obj_t arg3360_2088;
								     arg3358_2086 = CNST_TABLE_REF(((long) 7));
								     arg3359_2087 = CNST_TABLE_REF(((long) 13));
								     arg3360_2088 = CNST_TABLE_REF(((long) 9));
								     {
									obj_t list3362_2090;
									{
									   obj_t arg3363_2091;
									   {
									      obj_t arg3364_2092;
									      arg3364_2092 = MAKE_PAIR(BNIL, BNIL);
									      arg3363_2091 = MAKE_PAIR(arg3360_2088, arg3364_2092);
									   }
									   list3362_2090 = MAKE_PAIR(arg3359_2087, arg3363_2091);
									}
									arg3353_2081 = cons__138___r4_pairs_and_lists_6_3(arg3358_2086, list3362_2090);
								     }
								  }
								  {
								     obj_t list3355_2083;
								     {
									obj_t arg3356_2084;
									arg3356_2084 = MAKE_PAIR(BNIL, BNIL);
									list3355_2083 = MAKE_PAIR(ll2_1979, arg3356_2084);
								     }
								     arg3334_2062 = cons__138___r4_pairs_and_lists_6_3(arg3353_2081, list3355_2083);
								  }
							       }
							       {
								  obj_t list3336_2064;
								  {
								     obj_t arg3337_2065;
								     {
									obj_t arg3338_2066;
									arg3338_2066 = MAKE_PAIR(BNIL, BNIL);
									arg3337_2065 = MAKE_PAIR(arg3334_2062, arg3338_2066);
								     }
								     list3336_2064 = MAKE_PAIR(arg3333_2061, arg3337_2065);
								  }
								  arg3302_2030 = cons__138___r4_pairs_and_lists_6_3(lname_1980, list3336_2064);
							       }
							    }
							    {
							       obj_t list3304_2032;
							       {
								  obj_t arg3305_2033;
								  {
								     obj_t arg3306_2034;
								     arg3306_2034 = MAKE_PAIR(BNIL, BNIL);
								     arg3305_2033 = MAKE_PAIR(arg3302_2030, arg3306_2034);
								  }
								  list3304_2032 = MAKE_PAIR(arg3301_2029, arg3305_2033);
							       }
							       arg3280_2008 = cons__138___r4_pairs_and_lists_6_3(arg3300_2028, list3304_2032);
							    }
							 }
							 {
							    obj_t list3282_2010;
							    {
							       obj_t arg3283_2011;
							       {
								  obj_t arg3284_2012;
								  {
								     obj_t arg3285_2013;
								     arg3285_2013 = MAKE_PAIR(BNIL, BNIL);
								     arg3284_2012 = MAKE_PAIR(arg3280_2008, arg3285_2013);
								  }
								  arg3283_2011 = MAKE_PAIR(BTRUE, arg3284_2012);
							       }
							       list3282_2010 = MAKE_PAIR(arg3279_2007, arg3283_2011);
							    }
							    arg3256_1985 = cons__138___r4_pairs_and_lists_6_3(arg3278_2006, list3282_2010);
							 }
						      }
						      {
							 obj_t list3258_1987;
							 {
							    obj_t arg3259_1988;
							    {
							       obj_t arg3261_1989;
							       {
								  obj_t arg3262_1990;
								  arg3262_1990 = MAKE_PAIR(BNIL, BNIL);
								  arg3261_1989 = MAKE_PAIR(arg3256_1985, arg3262_1990);
							       }
							       arg3259_1988 = MAKE_PAIR(arg3255_1984, arg3261_1989);
							    }
							    list3258_1987 = MAKE_PAIR(lname_1980, arg3259_1988);
							 }
							 loop_1981 = cons__138___r4_pairs_and_lists_6_3(arg3254_1983, list3258_1987);
						      }
						   }
						   {
						      {
							 obj_t res_1982;
							 res_1982 = PROCEDURE_ENTRY(e_4) (e_4, loop_1981, e_4, BEOA);
							 return replace__160_tools_misc(x_3, res_1982);
						      }
						   }
						}
					     }
					  }
				       }
				    }
				  else
				    {
				       fun_1724 = CAR(cdr_258_124_1730);
				       lists_1725 = CDR(cdr_258_124_1730);
				     tag_247_29_1726:
				       {
					  obj_t res_2100;
					  {
					     obj_t arg3373_2101;
					     obj_t arg3374_2102;
					     obj_t arg3375_2103;
					     arg3373_2101 = CNST_TABLE_REF(((long) 23));
					     arg3374_2102 = PROCEDURE_ENTRY(e_4) (e_4, fun_1724, e_4, BEOA);
					     {
						obj_t arg3381_2107;
						obj_t arg3382_2108;
						if (NULLP(lists_1725))
						  {
						     arg3381_2107 = BNIL;
						  }
						else
						  {
						     obj_t head1035_2111;
						     head1035_2111 = MAKE_PAIR(BNIL, BNIL);
						     {
							obj_t l1033_2112;
							obj_t tail1036_2113;
							l1033_2112 = lists_1725;
							tail1036_2113 = head1035_2111;
						      lname1034_2114:
							if (NULLP(l1033_2112))
							  {
							     arg3381_2107 = CDR(head1035_2111);
							  }
							else
							  {
							     obj_t newtail1037_2116;
							     {
								obj_t arg3386_2118;
								arg3386_2118 = PROCEDURE_ENTRY(e_4) (e_4, CAR(l1033_2112), e_4, BEOA);
								newtail1037_2116 = MAKE_PAIR(arg3386_2118, BNIL);
							     }
							     SET_CDR(tail1036_2113, newtail1037_2116);
							     {
								obj_t tail1036_3740;
								obj_t l1033_3738;
								l1033_3738 = CDR(l1033_2112);
								tail1036_3740 = newtail1037_2116;
								tail1036_2113 = tail1036_3740;
								l1033_2112 = l1033_3738;
								goto lname1034_2114;
							     }
							  }
						     }
						  }
						arg3382_2108 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg3375_2103 = append_2_18___r4_pairs_and_lists_6_3(arg3381_2107, arg3382_2108);
					     }
					     {
						obj_t list3376_2104;
						{
						   obj_t arg3377_2105;
						   arg3377_2105 = MAKE_PAIR(arg3375_2103, BNIL);
						   list3376_2104 = MAKE_PAIR(arg3374_2102, arg3377_2105);
						}
						res_2100 = cons__138___r4_pairs_and_lists_6_3(arg3373_2101, list3376_2104);
					     }
					  }
					  return replace__160_tools_misc(x_3, res_2100);
				       }
				    }
			       }
			     else
			       {
				  obj_t lists_3751;
				  obj_t fun_3749;
				  fun_3749 = CAR(cdr_258_124_1730);
				  lists_3751 = CDR(cdr_258_124_1730);
				  lists_1725 = lists_3751;
				  fun_1724 = fun_3749;
				  goto tag_247_29_1726;
			       }
			  }
		       }
		  }
		else
		  {
		     obj_t lists_3755;
		     obj_t fun_3753;
		     fun_3753 = CAR(cdr_258_124_1730);
		     lists_3755 = CDR(cdr_258_124_1730);
		     lists_1725 = lists_3755;
		     fun_1724 = fun_3753;
		     goto tag_247_29_1726;
		  }
	     }
	   else
	     {
	      tag_248_72_1727:
		FAILURE(BFALSE, string3398_expand_map, x_3);
	     }
	}
      else
	{
	   goto tag_248_72_1727;
	}
   }
}


/* _expand-for-each */ obj_t 
_expand_for_each_126_expand_map(obj_t env_2233, obj_t x_2234, obj_t e_2235)
{
   return expand_for_each_88_expand_map(x_2234, e_2235);
}


/* method-init */ obj_t 
method_init_76_expand_map()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_map()
{
   module_initialization_70_tools_misc(((long) 0), "EXPAND_MAP");
   module_initialization_70_engine_param(((long) 0), "EXPAND_MAP");
   module_initialization_70_type_type(((long) 0), "EXPAND_MAP");
   return module_initialization_70_ast_ident(((long) 0), "EXPAND_MAP");
}
