/*===========================================================================*/
/*   (Cfa/closure.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_cfa_closure();
extern obj_t closure_optimization__75_cfa_closure();
extern obj_t _optim__89_engine_param;
extern obj_t closure_optimization__48_cfa_closure();
static obj_t _make_procedure_list__56_cfa_closure = BUNSPEC;
static bool_t light_funcall__169_cfa_closure();
extern obj_t var_ast_node;
extern obj_t get_node_atom_value_135_cfa_approx(node_t);
static obj_t start_cache_11_cfa_closure();
extern obj_t global_ast_var;
static obj_t _add_procedure_ref_2594_23_cfa_closure(obj_t, obj_t);
static obj_t _procedure_ref__66_cfa_closure = BUNSPEC;
extern bool_t stack_optimization__133_cfa_stack();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _procedure_ref_list__19_cfa_closure = BUNSPEC;
extern obj_t module_initialization_70_cfa_closure(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_set(long, char *);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t add_procedure_ref__36_cfa_closure(node_t);
extern long class_num_218___object(obj_t);
extern obj_t scnst_ast_var;
extern obj_t add_funcall__195_cfa_closure(node_t);
static obj_t imported_modules_init_94_cfa_closure();
static obj_t _add_make_procedure_2593_203_cfa_closure(obj_t, obj_t);
static obj_t _make_l_procedure__54_cfa_closure = BUNSPEC;
static obj_t library_modules_init_112_cfa_closure();
static bool_t light_make_procedure__143_cfa_closure();
extern approx_t cfa__102_cfa_cfa(node_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
extern obj_t set_length_165_cfa_set(obj_t);
static bool_t light_access__52_cfa_closure();
static obj_t toplevel_init_63_cfa_closure();
extern obj_t _unsafe_type__146_engine_param;
static obj_t show_cfa_closure(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _funcall_list__139_cfa_closure = BUNSPEC;
static obj_t arg2139_cfa_closure(obj_t, obj_t);
static obj_t arg2134_cfa_closure(obj_t, obj_t);
static obj_t _procedure_1_el_ref__37_cfa_closure = BUNSPEC;
static obj_t show_x_t_233_cfa_closure(obj_t);
static obj_t _closure_optimization__187_cfa_closure(obj_t);
static obj_t _closure_optimization__207_cfa_closure(obj_t);
extern obj_t make_procedure_app_48_cfa_info;
extern obj_t add_make_procedure__219_cfa_closure(node_t);
static obj_t _procedure_l_ref__76_cfa_closure = BUNSPEC;
static obj_t _make_el_procedure__202_cfa_closure = BUNSPEC;
extern obj_t shape_tools_shape(obj_t);
static obj_t _procedure_l_set___202_cfa_closure = BUNSPEC;
static obj_t stop_cache_174_cfa_closure();
static bool_t x__157_cfa_closure(obj_t);
extern obj_t _procedure__226_type_cache;
extern node_t stack__132_cfa_stack(node_t);
static obj_t _procedure_1_el_set___97_cfa_closure = BUNSPEC;
static obj_t _procedure_el_ref__61_cfa_closure = BUNSPEC;
static obj_t _add_funcall_2592_213_cfa_closure(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _procedure_el_set___46_cfa_closure = BUNSPEC;
static obj_t require_initialization_114_cfa_closure = BUNSPEC;
static obj_t _procedure_set___197_cfa_closure = BUNSPEC;
static obj_t _make_el_procedure_1__141_cfa_closure = BUNSPEC;
static obj_t t_fix_point__90_cfa_closure(obj_t);
extern obj_t set__list_248_cfa_set(obj_t);
static obj_t cnst_init_137_cfa_closure();
static obj_t __cnst[21];

DEFINE_EXPORT_PROCEDURE(closure_optimization__env_164_cfa_closure, _closure_optimization__207_cfa_closure2607, _closure_optimization__207_cfa_closure, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc2597_cfa_closure, arg2139_cfa_closure2608, arg2139_cfa_closure, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2596_cfa_closure, arg2134_cfa_closure2609, arg2134_cfa_closure, 0L, 1);
DEFINE_EXPORT_PROCEDURE(add_procedure_ref__env_174_cfa_closure, _add_procedure_ref_2594_23_cfa_closure2610, _add_procedure_ref_2594_23_cfa_closure, 0L, 1);
DEFINE_EXPORT_PROCEDURE(add_make_procedure__env_11_cfa_closure, _add_make_procedure_2593_203_cfa_closure2611, _add_make_procedure_2593_203_cfa_closure, 0L, 1);
DEFINE_EXPORT_PROCEDURE(add_funcall__env_57_cfa_closure, _add_funcall_2592_213_cfa_closure2612, _add_funcall_2592_213_cfa_closure, 0L, 1);
DEFINE_STRING(string2599_cfa_closure, string2599_cfa_closure2613, "     ", 5);
DEFINE_STRING(string2598_cfa_closure, string2598_cfa_closure2614, ": ", 2);
DEFINE_STRING(string2595_cfa_closure, string2595_cfa_closure2615, "   . Light closures", 19);
DEFINE_STRING(string2601_cfa_closure, string2601_cfa_closure2616, "MAKE-L-PROCEDURE MAKE-EL-PROCEDURE-1 MAKE-EL-PROCEDURE PROCEDURE-1-EL-SET! PROCEDURE-1-EL-REF PROCEDURE-EL-SET! PROCEDURE-EL-REF PROCEDURE-L-SET! PROCEDURE-L-REF PROCEDURE-SET! FOREIGN PROCEDURE-REF T X LIGHT ELIGHT NOTHING-TO-DO SELFUN SEFUN DONE OK ", 251);
DEFINE_STRING(string2600_cfa_closure, string2600_cfa_closure2617, "        ", 8);
DEFINE_EXPORT_PROCEDURE(closure_optimization__env_163_cfa_closure, _closure_optimization__187_cfa_closure2618, _closure_optimization__187_cfa_closure, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_cfa_closure(long checksum_3801, char *from_3802)
{
   if (CBOOL(require_initialization_114_cfa_closure))
     {
	require_initialization_114_cfa_closure = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_closure();
	cnst_init_137_cfa_closure();
	imported_modules_init_94_cfa_closure();
	method_init_76_cfa_closure();
	toplevel_init_63_cfa_closure();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_closure()
{
   module_initialization_70___object(((long) 0), "CFA_CLOSURE");
   module_initialization_70___reader(((long) 0), "CFA_CLOSURE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_closure()
{
   {
      obj_t cnst_port_138_3793;
      cnst_port_138_3793 = open_input_string(string2601_cfa_closure);
      {
	 long i_3794;
	 i_3794 = ((long) 20);
       loop_3795:
	 {
	    bool_t test2602_3796;
	    test2602_3796 = (i_3794 == ((long) -1));
	    if (test2602_3796)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2603_3797;
		    {
		       obj_t list2604_3798;
		       {
			  obj_t arg2605_3799;
			  arg2605_3799 = BNIL;
			  list2604_3798 = MAKE_PAIR(cnst_port_138_3793, arg2605_3799);
		       }
		       arg2603_3797 = read___reader(list2604_3798);
		    }
		    CNST_TABLE_SET(i_3794, arg2603_3797);
		 }
		 {
		    int aux_3800;
		    {
		       long aux_3819;
		       aux_3819 = (i_3794 - ((long) 1));
		       aux_3800 = (int) (aux_3819);
		    }
		    {
		       long i_3822;
		       i_3822 = (long) (aux_3800);
		       i_3794 = i_3822;
		       goto loop_3795;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_closure()
{
   _funcall_list__139_cfa_closure = BNIL;
   _make_procedure_list__56_cfa_closure = BNIL;
   _procedure_ref_list__19_cfa_closure = BNIL;
   _procedure_ref__66_cfa_closure = BFALSE;
   _procedure_set___197_cfa_closure = BFALSE;
   _procedure_l_ref__76_cfa_closure = BFALSE;
   _procedure_l_set___202_cfa_closure = BFALSE;
   _procedure_el_ref__61_cfa_closure = BFALSE;
   _procedure_el_set___46_cfa_closure = BFALSE;
   _procedure_1_el_ref__37_cfa_closure = BFALSE;
   _procedure_1_el_set___97_cfa_closure = BFALSE;
   _make_el_procedure__202_cfa_closure = BFALSE;
   _make_el_procedure_1__141_cfa_closure = BFALSE;
   return (_make_l_procedure__54_cfa_closure = BFALSE,
      BUNSPEC);
}


/* closure-optimization? */ obj_t 
closure_optimization__75_cfa_closure()
{
   {
      long n1_3166;
      n1_3166 = (long) CINT(_optim__89_engine_param);
      {
	 bool_t aux_3825;
	 aux_3825 = (n1_3166 >= ((long) 2));
	 return BBOOL(aux_3825);
      }
   }
}


/* _closure-optimization? */ obj_t 
_closure_optimization__187_cfa_closure(obj_t env_3779)
{
   return closure_optimization__75_cfa_closure();
}


/* closure-optimization! */ obj_t 
closure_optimization__48_cfa_closure()
{
   {
      bool_t test2107_2104;
      {
	 long n1_3168;
	 n1_3168 = (long) CINT(_optim__89_engine_param);
	 test2107_2104 = (n1_3168 >= ((long) 2));
      }
      if (test2107_2104)
	{
	   {
	      obj_t list2108_2105;
	      {
		 obj_t arg2111_2107;
		 {
		    obj_t aux_3832;
		    aux_3832 = BCHAR(((unsigned char) '\n'));
		    arg2111_2107 = MAKE_PAIR(aux_3832, BNIL);
		 }
		 list2108_2105 = MAKE_PAIR(string2595_cfa_closure, arg2111_2107);
	      }
	      verbose_tools_speek(BINT(((long) 1)), list2108_2105);
	   }
	   start_cache_11_cfa_closure();
	   {
	      obj_t l2077_2109;
	      l2077_2109 = _make_procedure_list__56_cfa_closure;
	    lname2078_2110:
	      if (PAIRP(l2077_2109))
		{
		   {
		      obj_t app_2112;
		      app_2112 = CAR(l2077_2109);
		      {
			 variable_t fun_2114;
			 bool_t lost__227_2115;
			 obj_t size_2116;
			 {
			    var_t obj_3174;
			    {
			       obj_t aux_3842;
			       {
				  obj_t aux_3843;
				  {
				     app_t obj_3172;
				     obj_3172 = (app_t) (app_2112);
				     aux_3843 = (((app_t) CREF(obj_3172))->args);
				  }
				  aux_3842 = CAR(aux_3843);
			       }
			       obj_3174 = (var_t) (aux_3842);
			    }
			    fun_2114 = (((var_t) CREF(obj_3174))->variable);
			 }
			 {
			    long aux_3849;
			    {
			       make_procedure_app_48_t obj_3175;
			       obj_3175 = (make_procedure_app_48_t) (app_2112);
			       {
				  obj_t aux_3851;
				  {
				     object_t aux_3852;
				     aux_3852 = (object_t) (obj_3175);
				     aux_3851 = OBJECT_WIDENING(aux_3852);
				  }
				  aux_3849 = (((make_procedure_app_48_t) CREF(aux_3851))->lost_stamp_114);
			       }
			    }
			    lost__227_2115 = (aux_3849 > ((long) -1));
			 }
			 {
			    node_t aux_3857;
			    {
			       obj_t aux_3858;
			       {
				  obj_t aux_3859;
				  {
				     obj_t aux_3860;
				     {
					obj_t aux_3861;
					{
					   app_t obj_3178;
					   obj_3178 = (app_t) (app_2112);
					   aux_3861 = (((app_t) CREF(obj_3178))->args);
					}
					aux_3860 = CDR(aux_3861);
				     }
				     aux_3859 = CDR(aux_3860);
				  }
				  aux_3858 = CAR(aux_3859);
			       }
			       aux_3857 = (node_t) (aux_3858);
			    }
			    size_2116 = get_node_atom_value_135_cfa_approx(aux_3857);
			 }
			 {
			    bool_t test_3869;
			    if (lost__227_2115)
			      {
				 test_3869 = ((bool_t) 1);
			      }
			    else
			      {
				 bool_t test_3871;
				 {
				    make_procedure_app_48_t obj_3185;
				    obj_3185 = (make_procedure_app_48_t) (app_2112);
				    {
				       obj_t aux_3873;
				       {
					  object_t aux_3874;
					  aux_3874 = (object_t) (obj_3185);
					  aux_3873 = OBJECT_WIDENING(aux_3874);
				       }
				       test_3871 = (((make_procedure_app_48_t) CREF(aux_3873))->x_t__142);
				    }
				 }
				 if (test_3871)
				   {
				      bool_t test_3878;
				      {
					 long aux_3879;
					 {
					    sfun_t obj_3187;
					    {
					       value_t aux_3880;
					       {
						  global_t obj_3186;
						  obj_3186 = (global_t) (fun_2114);
						  aux_3880 = (((global_t) CREF(obj_3186))->value);
					       }
					       obj_3187 = (sfun_t) (aux_3880);
					    }
					    aux_3879 = (((sfun_t) CREF(obj_3187))->arity);
					 }
					 test_3878 = (aux_3879 < ((long) 0));
				      }
				      if (test_3878)
					{
					   test_3869 = ((bool_t) 1);
					}
				      else
					{
					   if (INTEGERP(size_2116))
					     {
						long aux_3888;
						aux_3888 = (long) CINT(size_2116);
						test_3869 = (aux_3888 == ((long) 0));
					     }
					   else
					     {
						test_3869 = ((bool_t) 1);
					     }
					}
				   }
				 else
				   {
				      test_3869 = ((bool_t) 1);
				   }
			      }
			    if (test_3869)
			      {
				 BUNSPEC;
			      }
			    else
			      {
				 {
				    make_procedure_app_48_t obj_3193;
				    obj_3193 = (make_procedure_app_48_t) (app_2112);
				    {
				       obj_t aux_3892;
				       {
					  object_t aux_3893;
					  aux_3893 = (object_t) (obj_3193);
					  aux_3892 = OBJECT_WIDENING(aux_3893);
				       }
				       ((((make_procedure_app_48_t) CREF(aux_3892))->x) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				    }
				 }
				 {
				    make_procedure_app_48_t obj_3195;
				    obj_3195 = (make_procedure_app_48_t) (app_2112);
				    {
				       obj_t aux_3898;
				       {
					  object_t aux_3899;
					  aux_3899 = (object_t) (obj_3195);
					  aux_3898 = OBJECT_WIDENING(aux_3899);
				       }
				       ((((make_procedure_app_48_t) CREF(aux_3898))->t) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				    }
				 }
			      }
			 }
		      }
		   }
		   {
		      obj_t l2077_3903;
		      l2077_3903 = CDR(l2077_2109);
		      l2077_2109 = l2077_3903;
		      goto lname2078_2110;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   x__157_cfa_closure(_funcall_list__139_cfa_closure);
	   t_fix_point__90_cfa_closure(_funcall_list__139_cfa_closure);
	   show_x_t_233_cfa_closure(_make_procedure_list__56_cfa_closure);
	   light_funcall__169_cfa_closure();
	   light_access__52_cfa_closure();
	   light_make_procedure__143_cfa_closure();
	   return stop_cache_174_cfa_closure();
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _closure-optimization! */ obj_t 
_closure_optimization__207_cfa_closure(obj_t env_3780)
{
   return closure_optimization__48_cfa_closure();
}


/* x! */ bool_t 
x__157_cfa_closure(obj_t funcall_list_16_1)
{
   {
      obj_t l2080_2131;
      l2080_2131 = funcall_list_16_1;
    lname2081_2132:
      if (PAIRP(l2080_2131))
	{
	   {
	      funcall_t app_2134;
	      {
		 obj_t aux_3915;
		 aux_3915 = CAR(l2080_2131);
		 app_2134 = (funcall_t) (aux_3915);
	      }
	      {
		 approx_t approx_2136;
		 approx_2136 = cfa__102_cfa_cfa((((funcall_t) CREF(app_2134))->fun));
		 {
		    obj_t alloc_2137;
		    alloc_2137 = (((approx_t) CREF(approx_2136))->allocs);
		    {
		       type_t type_2138;
		       type_2138 = (((approx_t) CREF(approx_2136))->type);
		       {
			  if ((((approx_t) CREF(approx_2136))->top__138))
			    {
			       {
				  obj_t arg2134_3781;
				  arg2134_3781 = proc2596_cfa_closure;
				  for_each_approx_alloc_83_cfa_approx(arg2134_3781, approx_2136);
			       }
			    }
			  else
			    {
			       bool_t test2137_2145;
			       {
				  obj_t arg2145_2156;
				  arg2145_2156 = set_length_165_cfa_set(alloc_2137);
				  {
				     long aux_3926;
				     aux_3926 = (long) CINT(arg2145_2156);
				     test2137_2145 = (aux_3926 == ((long) 0));
				  }
			       }
			       if (test2137_2145)
				 {
				    CNST_TABLE_REF(((long) 0));
				 }
			       else
				 {
				    bool_t test2138_2146;
				    {
				       bool_t test2142_2152;
				       {
					  obj_t arg2143_2154;
					  arg2143_2154 = set_length_165_cfa_set(alloc_2137);
					  {
					     long aux_3932;
					     aux_3932 = (long) CINT(arg2143_2154);
					     test2142_2152 = (aux_3932 == ((long) 1));
					  }
				       }
				       if (test2142_2152)
					 {
					    obj_t _ortest_2082_2153;
					    _ortest_2082_2153 = _unsafe_type__146_engine_param;
					    if (CBOOL(_ortest_2082_2153))
					      {
						 test2138_2146 = CBOOL(_ortest_2082_2153);
					      }
					    else
					      {
						 obj_t obj2_3214;
						 obj2_3214 = _procedure__226_type_cache;
						 {
						    obj_t aux_3939;
						    aux_3939 = (obj_t) (type_2138);
						    test2138_2146 = (aux_3939 == obj2_3214);
						 }
					      }
					 }
				       else
					 {
					    test2138_2146 = ((bool_t) 0);
					 }
				    }
				    if (test2138_2146)
				      {
					 CNST_TABLE_REF(((long) 0));
				      }
				    else
				      {
					 {
					    obj_t arg2139_3782;
					    arg2139_3782 = proc2597_cfa_closure;
					    for_each_approx_alloc_83_cfa_approx(arg2139_3782, approx_2136);
					 }
				      }
				 }
			    }
		       }
		    }
		 }
	      }
	   }
	   {
	      obj_t l2080_3945;
	      l2080_3945 = CDR(l2080_2131);
	      l2080_2131 = l2080_3945;
	      goto lname2081_2132;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* arg2134 */ obj_t 
arg2134_cfa_closure(obj_t env_3783, obj_t alloc_3784)
{
   {
      obj_t alloc_2141;
      alloc_2141 = alloc_3784;
      {
	 bool_t test2136_2143;
	 test2136_2143 = is_a__118___object(alloc_2141, make_procedure_app_48_cfa_info);
	 if (test2136_2143)
	   {
	      {
		 make_procedure_app_48_t obj_3205;
		 obj_3205 = (make_procedure_app_48_t) (alloc_2141);
		 {
		    obj_t aux_3950;
		    {
		       object_t aux_3951;
		       aux_3951 = (object_t) (obj_3205);
		       aux_3950 = OBJECT_WIDENING(aux_3951);
		    }
		    ((((make_procedure_app_48_t) CREF(aux_3950))->t) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		 }
	      }
	      {
		 make_procedure_app_48_t obj_3207;
		 obj_3207 = (make_procedure_app_48_t) (alloc_2141);
		 {
		    obj_t aux_3956;
		    {
		       object_t aux_3957;
		       aux_3957 = (object_t) (obj_3207);
		       aux_3956 = OBJECT_WIDENING(aux_3957);
		    }
		    return ((((make_procedure_app_48_t) CREF(aux_3956))->x) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		 }
	      }
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* arg2139 */ obj_t 
arg2139_cfa_closure(obj_t env_3785, obj_t alloc_3786)
{
   {
      obj_t alloc_2148;
      alloc_2148 = alloc_3786;
      {
	 bool_t test2141_2150;
	 test2141_2150 = is_a__118___object(alloc_2148, make_procedure_app_48_cfa_info);
	 if (test2141_2150)
	   {
	      {
		 make_procedure_app_48_t obj_3216;
		 obj_3216 = (make_procedure_app_48_t) (alloc_2148);
		 {
		    obj_t aux_3964;
		    {
		       object_t aux_3965;
		       aux_3965 = (object_t) (obj_3216);
		       aux_3964 = OBJECT_WIDENING(aux_3965);
		    }
		    return ((((make_procedure_app_48_t) CREF(aux_3964))->x) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		 }
	      }
	   }
	 else
	   {
	      return BUNSPEC;
	   }
      }
   }
}


/* t-fix-point! */ obj_t 
t_fix_point__90_cfa_closure(obj_t funcall_list_16_2)
{
   {
      bool_t continue__191_2159;
      continue__191_2159 = ((bool_t) 1);
    loop_2160:
      if (continue__191_2159)
	{
	   bool_t continue__191_2161;
	   continue__191_2161 = ((bool_t) 0);
	   {
	      obj_t l2083_2162;
	      l2083_2162 = funcall_list_16_2;
	    lname2084_2163:
	      if (PAIRP(l2083_2162))
		{
		   {
		      approx_t approx_2167;
		      {
			 node_t aux_3972;
			 {
			    funcall_t obj_3221;
			    {
			       obj_t aux_3973;
			       aux_3973 = CAR(l2083_2162);
			       obj_3221 = (funcall_t) (aux_3973);
			    }
			    aux_3972 = (((funcall_t) CREF(obj_3221))->fun);
			 }
			 approx_2167 = cfa__102_cfa_cfa(aux_3972);
		      }
		      {
			 obj_t alloc_2168;
			 alloc_2168 = set__list_248_cfa_set((((approx_t) CREF(approx_2167))->allocs));
			 {
			    bool_t t_init__227_2170;
			    {
			       bool_t _ortest_2085_2189;
			       _ortest_2085_2189 = (((approx_t) CREF(approx_2167))->top__138);
			       if (_ortest_2085_2189)
				 {
				    t_init__227_2170 = _ortest_2085_2189;
				 }
			       else
				 {
				    bool_t test2159_2190;
				    {
				       bool_t test2160_2191;
				       {
					  obj_t obj2_3226;
					  obj2_3226 = _procedure__226_type_cache;
					  {
					     obj_t aux_3982;
					     {
						type_t aux_3983;
						aux_3983 = (((approx_t) CREF(approx_2167))->type);
						aux_3982 = (obj_t) (aux_3983);
					     }
					     test2160_2191 = (aux_3982 == obj2_3226);
					  }
				       }
				       if (test2160_2191)
					 {
					    test2159_2190 = ((bool_t) 1);
					 }
				       else
					 {
					    test2159_2190 = CBOOL(_unsafe_type__146_engine_param);
					 }
				    }
				    if (test2159_2190)
				      {
					 t_init__227_2170 = ((bool_t) 0);
				      }
				    else
				      {
					 t_init__227_2170 = ((bool_t) 1);
				      }
				 }
			    }
			    {
			       {
				  bool_t one_non_t__209_2171;
				  obj_t allocs_2172;
				  one_non_t__209_2171 = t_init__227_2170;
				  allocs_2172 = alloc_2168;
				loop_2173:
				  if (NULLP(allocs_2172))
				    {
				       CNST_TABLE_REF(((long) 1));
				    }
				  else
				    {
				       if (one_non_t__209_2171)
					 {
					    {
					       obj_t l2086_2175;
					       {
						  bool_t aux_3994;
						  l2086_2175 = alloc_2168;
						lname2087_2176:
						  if (PAIRP(l2086_2175))
						    {
						       {
							  obj_t alloc_2178;
							  alloc_2178 = CAR(l2086_2175);
							  {
							     bool_t test2151_2179;
							     test2151_2179 = is_a__118___object(alloc_2178, make_procedure_app_48_cfa_info);
							     if (test2151_2179)
							       {
								  bool_t test_4000;
								  {
								     make_procedure_app_48_t obj_3231;
								     obj_3231 = (make_procedure_app_48_t) (alloc_2178);
								     {
									obj_t aux_4002;
									{
									   object_t aux_4003;
									   aux_4003 = (object_t) (obj_3231);
									   aux_4002 = OBJECT_WIDENING(aux_4003);
									}
									test_4000 = (((make_procedure_app_48_t) CREF(aux_4002))->t);
								     }
								  }
								  if (test_4000)
								    {
								       {
									  make_procedure_app_48_t obj_3232;
									  obj_3232 = (make_procedure_app_48_t) (alloc_2178);
									  {
									     obj_t aux_4008;
									     {
										object_t aux_4009;
										aux_4009 = (object_t) (obj_3232);
										aux_4008 = OBJECT_WIDENING(aux_4009);
									     }
									     ((((make_procedure_app_48_t) CREF(aux_4008))->t) = ((bool_t) ((bool_t) 0)), BUNSPEC);
									  }
								       }
								       continue__191_2161 = ((bool_t) 1);
								    }
								  else
								    {
								       BUNSPEC;
								    }
							       }
							     else
							       {
								  BUNSPEC;
							       }
							  }
						       }
						       {
							  obj_t l2086_4013;
							  l2086_4013 = CDR(l2086_2175);
							  l2086_2175 = l2086_4013;
							  goto lname2087_2176;
						       }
						    }
						  else
						    {
						       aux_3994 = ((bool_t) 1);
						    }
						  BBOOL(aux_3994);
					       }
					    }
					 }
				       else
					 {
					    bool_t test2154_2183;
					    test2154_2183 = is_a__118___object(CAR(allocs_2172), make_procedure_app_48_cfa_info);
					    if (test2154_2183)
					      {
						 {
						    bool_t test_4019;
						    {
						       make_procedure_app_48_t obj_3238;
						       {
							  obj_t aux_4020;
							  aux_4020 = CAR(allocs_2172);
							  obj_3238 = (make_procedure_app_48_t) (aux_4020);
						       }
						       {
							  obj_t aux_4023;
							  {
							     object_t aux_4024;
							     aux_4024 = (object_t) (obj_3238);
							     aux_4023 = OBJECT_WIDENING(aux_4024);
							  }
							  test_4019 = (((make_procedure_app_48_t) CREF(aux_4023))->t);
						       }
						    }
						    if (test_4019)
						      {
							 obj_t allocs_4028;
							 allocs_4028 = CDR(allocs_2172);
							 allocs_2172 = allocs_4028;
							 goto loop_2173;
						      }
						    else
						      {
							 bool_t one_non_t__209_4030;
							 one_non_t__209_4030 = ((bool_t) 1);
							 one_non_t__209_2171 = one_non_t__209_4030;
							 goto loop_2173;
						      }
						 }
					      }
					    else
					      {
						 if (CBOOL(_unsafe_type__146_engine_param))
						   {
						      obj_t allocs_4033;
						      allocs_4033 = CDR(allocs_2172);
						      allocs_2172 = allocs_4033;
						      goto loop_2173;
						   }
						 else
						   {
						      bool_t one_non_t__209_4035;
						      one_non_t__209_4035 = ((bool_t) 1);
						      one_non_t__209_2171 = one_non_t__209_4035;
						      goto loop_2173;
						   }
					      }
					 }
				    }
			       }
			    }
			 }
		      }
		   }
		   {
		      obj_t l2083_4036;
		      l2083_4036 = CDR(l2083_2162);
		      l2083_2162 = l2083_4036;
		      goto lname2084_2163;
		   }
		}
	      else
		{
		   ((bool_t) 1);
		}
	   }
	   {
	      bool_t continue__191_4038;
	      continue__191_4038 = continue__191_2161;
	      continue__191_2159 = continue__191_4038;
	      goto loop_2160;
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* light-make-procedure! */ bool_t 
light_make_procedure__143_cfa_closure()
{
   {
      obj_t app_2231;
      obj_t app_2207;
      {
	 obj_t l2093_2199;
	 l2093_2199 = _make_procedure_list__56_cfa_closure;
       lname2094_2200:
	 if (PAIRP(l2093_2199))
	   {
	      {
		 obj_t app_2202;
		 app_2202 = CAR(l2093_2199);
		 {
		    bool_t test_4042;
		    {
		       make_procedure_app_48_t obj_3244;
		       obj_3244 = (make_procedure_app_48_t) (app_2202);
		       {
			  obj_t aux_4044;
			  {
			     object_t aux_4045;
			     aux_4045 = (object_t) (obj_3244);
			     aux_4044 = OBJECT_WIDENING(aux_4045);
			  }
			  test_4042 = (((make_procedure_app_48_t) CREF(aux_4044))->x);
		       }
		    }
		    if (test_4042)
		      {
			 app_2231 = app_2202;
			 {
			    obj_t size_2234;
			    {
			       node_t aux_4049;
			       {
				  obj_t aux_4050;
				  {
				     obj_t aux_4051;
				     {
					obj_t aux_4052;
					{
					   obj_t aux_4053;
					   {
					      app_t obj_3279;
					      obj_3279 = (app_t) (app_2231);
					      aux_4053 = (((app_t) CREF(obj_3279))->args);
					   }
					   aux_4052 = CDR(aux_4053);
					}
					aux_4051 = CDR(aux_4052);
				     }
				     aux_4050 = CAR(aux_4051);
				  }
				  aux_4049 = (node_t) (aux_4050);
			       }
			       size_2234 = get_node_atom_value_135_cfa_approx(aux_4049);
			    }
			    {
			       variable_t ffun_2235;
			       {
				  var_t obj_3288;
				  {
				     obj_t aux_4061;
				     {
					obj_t aux_4062;
					{
					   app_t obj_3286;
					   obj_3286 = (app_t) (app_2231);
					   aux_4062 = (((app_t) CREF(obj_3286))->args);
					}
					aux_4061 = CAR(aux_4062);
				     }
				     obj_3288 = (var_t) (aux_4061);
				  }
				  ffun_2235 = (((var_t) CREF(obj_3288))->variable);
			       }
			       {
				  value_t sfun_2236;
				  sfun_2236 = (((variable_t) CREF(ffun_2235))->value);
				  {
				     {
					bool_t test_4069;
					{
					   long aux_4070;
					   aux_4070 = (long) CINT(size_2234);
					   test_4069 = (aux_4070 == ((long) 1));
					}
					if (test_4069)
					  {
					     {
						bool_t test2192_2238;
						{
						   bool_t test2197_2242;
						   test2197_2242 = is_a__118___object((obj_t) (ffun_2235), global_ast_var);
						   if (test2197_2242)
						     {
							bool_t test2198_2243;
							{
							   obj_t aux_4076;
							   {
							      sfun_t obj_3293;
							      obj_3293 = (sfun_t) (sfun_2236);
							      aux_4076 = (((sfun_t) CREF(obj_3293))->the_closure_238);
							   }
							   test2198_2243 = is_a__118___object(aux_4076, global_ast_var);
							}
							if (test2198_2243)
							  {
							     obj_t aux_4081;
							     {
								value_t aux_4082;
								{
								   global_t obj_3296;
								   {
								      obj_t aux_4083;
								      {
									 sfun_t obj_3295;
									 obj_3295 = (sfun_t) (sfun_2236);
									 aux_4083 = (((sfun_t) CREF(obj_3295))->the_closure_238);
								      }
								      obj_3296 = (global_t) (aux_4083);
								   }
								   aux_4082 = (((global_t) CREF(obj_3296))->value);
								}
								aux_4081 = (obj_t) (aux_4082);
							     }
							     test2192_2238 = is_a__118___object(aux_4081, scnst_ast_var);
							  }
							else
							  {
							     test2192_2238 = ((bool_t) 0);
							  }
						     }
						   else
						     {
							test2192_2238 = ((bool_t) 0);
						     }
						}
						if (test2192_2238)
						  {
						     obj_t arg2194_2240;
						     arg2194_2240 = CNST_TABLE_REF(((long) 3));
						     {
							scnst_t obj_3300;
							{
							   value_t aux_4092;
							   {
							      global_t obj_3299;
							      {
								 obj_t aux_4093;
								 {
								    sfun_t obj_3298;
								    obj_3298 = (sfun_t) (sfun_2236);
								    aux_4093 = (((sfun_t) CREF(obj_3298))->the_closure_238);
								 }
								 obj_3299 = (global_t) (aux_4093);
							      }
							      aux_4092 = (((global_t) CREF(obj_3299))->value);
							   }
							   obj_3300 = (scnst_t) (aux_4092);
							}
							((((scnst_t) CREF(obj_3300))->class) = ((obj_t) arg2194_2240), BUNSPEC);
						     }
						  }
						else
						  {
						     BUNSPEC;
						  }
					     }
					     {
						var_t arg2202_2247;
						{
						   app_t obj_3302;
						   obj_3302 = (app_t) (app_2231);
						   arg2202_2247 = (((app_t) CREF(obj_3302))->fun);
						}
						{
						   variable_t val1261_3304;
						   val1261_3304 = (variable_t) (_make_el_procedure_1__141_cfa_closure);
						   ((((var_t) CREF(arg2202_2247))->variable) = ((variable_t) val1261_3304), BUNSPEC);
						}
					     }
					  }
					else
					  {
					     {
						var_t arg2204_2248;
						{
						   app_t obj_3305;
						   obj_3305 = (app_t) (app_2231);
						   arg2204_2248 = (((app_t) CREF(obj_3305))->fun);
						}
						{
						   variable_t val1261_3307;
						   val1261_3307 = (variable_t) (_make_el_procedure__202_cfa_closure);
						   ((((var_t) CREF(arg2204_2248))->variable) = ((variable_t) val1261_3307), BUNSPEC);
						}
					     }
					  }
				     }
				  }
			       }
			    }
			 }
			 {
			    obj_t arg2209_2253;
			    {
			       obj_t aux_4108;
			       {
				  obj_t aux_4109;
				  {
				     app_t obj_3308;
				     obj_3308 = (app_t) (app_2231);
				     aux_4109 = (((app_t) CREF(obj_3308))->args);
				  }
				  aux_4108 = CDR(aux_4109);
			       }
			       arg2209_2253 = CDR(aux_4108);
			    }
			    {
			       app_t obj_3313;
			       obj_3313 = (app_t) (app_2231);
			       ((((app_t) CREF(obj_3313))->args) = ((obj_t) arg2209_2253), BUNSPEC);
			    }
			 }
			 {
			    bool_t test2211_2255;
			    test2211_2255 = stack_optimization__133_cfa_stack();
			    if (test2211_2255)
			      {
				 node_t aux_4118;
				 aux_4118 = stack__132_cfa_stack((node_t) (app_2231));
				 (obj_t) (aux_4118);
			      }
			    else
			      {
				 app_2231;
			      }
			 }
		      }
		    else
		      {
			 bool_t test_4122;
			 {
			    make_procedure_app_48_t obj_3245;
			    obj_3245 = (make_procedure_app_48_t) (app_2202);
			    {
			       obj_t aux_4124;
			       {
				  object_t aux_4125;
				  aux_4125 = (object_t) (obj_3245);
				  aux_4124 = OBJECT_WIDENING(aux_4125);
			       }
			       test_4122 = (((make_procedure_app_48_t) CREF(aux_4124))->t);
			    }
			 }
			 if (test_4122)
			   {
			      app_2207 = app_2202;
			      {
				 obj_t size_2210;
				 {
				    node_t aux_4129;
				    {
				       obj_t aux_4130;
				       {
					  obj_t aux_4131;
					  {
					     obj_t aux_4132;
					     {
						obj_t aux_4133;
						{
						   app_t obj_3247;
						   obj_3247 = (app_t) (app_2207);
						   aux_4133 = (((app_t) CREF(obj_3247))->args);
						}
						aux_4132 = CDR(aux_4133);
					     }
					     aux_4131 = CDR(aux_4132);
					  }
					  aux_4130 = CAR(aux_4131);
				       }
				       aux_4129 = (node_t) (aux_4130);
				    }
				    size_2210 = get_node_atom_value_135_cfa_approx(aux_4129);
				 }
				 {
				    variable_t ffun_2211;
				    {
				       var_t obj_3256;
				       {
					  obj_t aux_4141;
					  {
					     obj_t aux_4142;
					     {
						app_t obj_3254;
						obj_3254 = (app_t) (app_2207);
						aux_4142 = (((app_t) CREF(obj_3254))->args);
					     }
					     aux_4141 = CAR(aux_4142);
					  }
					  obj_3256 = (var_t) (aux_4141);
				       }
				       ffun_2211 = (((var_t) CREF(obj_3256))->variable);
				    }
				    {
				       value_t sfun_2212;
				       sfun_2212 = (((variable_t) CREF(ffun_2211))->value);
				       {
					  {
					     bool_t test2171_2213;
					     {
						bool_t test2175_2217;
						test2175_2217 = is_a__118___object((obj_t) (ffun_2211), global_ast_var);
						if (test2175_2217)
						  {
						     bool_t test2176_2218;
						     {
							obj_t aux_4152;
							{
							   sfun_t obj_3259;
							   obj_3259 = (sfun_t) (sfun_2212);
							   aux_4152 = (((sfun_t) CREF(obj_3259))->the_closure_238);
							}
							test2176_2218 = is_a__118___object(aux_4152, global_ast_var);
						     }
						     if (test2176_2218)
						       {
							  obj_t aux_4157;
							  {
							     value_t aux_4158;
							     {
								global_t obj_3262;
								{
								   obj_t aux_4159;
								   {
								      sfun_t obj_3261;
								      obj_3261 = (sfun_t) (sfun_2212);
								      aux_4159 = (((sfun_t) CREF(obj_3261))->the_closure_238);
								   }
								   obj_3262 = (global_t) (aux_4159);
								}
								aux_4158 = (((global_t) CREF(obj_3262))->value);
							     }
							     aux_4157 = (obj_t) (aux_4158);
							  }
							  test2171_2213 = is_a__118___object(aux_4157, scnst_ast_var);
						       }
						     else
						       {
							  test2171_2213 = ((bool_t) 0);
						       }
						  }
						else
						  {
						     test2171_2213 = ((bool_t) 0);
						  }
					     }
					     if (test2171_2213)
					       {
						  obj_t arg2173_2215;
						  arg2173_2215 = CNST_TABLE_REF(((long) 2));
						  {
						     scnst_t obj_3266;
						     {
							value_t aux_4168;
							{
							   global_t obj_3265;
							   {
							      obj_t aux_4169;
							      {
								 sfun_t obj_3264;
								 obj_3264 = (sfun_t) (sfun_2212);
								 aux_4169 = (((sfun_t) CREF(obj_3264))->the_closure_238);
							      }
							      obj_3265 = (global_t) (aux_4169);
							   }
							   aux_4168 = (((global_t) CREF(obj_3265))->value);
							}
							obj_3266 = (scnst_t) (aux_4168);
						     }
						     ((((scnst_t) CREF(obj_3266))->class) = ((obj_t) arg2173_2215), BUNSPEC);
						  }
					       }
					     else
					       {
						  BUNSPEC;
					       }
					  }
					  {
					     var_t arg2181_2222;
					     {
						app_t obj_3268;
						obj_3268 = (app_t) (app_2207);
						arg2181_2222 = (((app_t) CREF(obj_3268))->fun);
					     }
					     {
						variable_t val1261_3270;
						val1261_3270 = (variable_t) (_make_l_procedure__54_cfa_closure);
						((((var_t) CREF(arg2181_2222))->variable) = ((variable_t) val1261_3270), BUNSPEC);
					     }
					  }
					  {
					     obj_t aux_4183;
					     obj_t aux_4180;
					     {
						obj_t aux_4184;
						{
						   obj_t aux_4185;
						   {
						      app_t obj_3272;
						      obj_3272 = (app_t) (app_2207);
						      aux_4185 = (((app_t) CREF(obj_3272))->args);
						   }
						   aux_4184 = CDR(aux_4185);
						}
						aux_4183 = CDR(aux_4184);
					     }
					     {
						app_t obj_3271;
						obj_3271 = (app_t) (app_2207);
						aux_4180 = (((app_t) CREF(obj_3271))->args);
					     }
					     SET_CDR(aux_4180, aux_4183);
					  }
					  {
					     bool_t test2185_2226;
					     test2185_2226 = stack_optimization__133_cfa_stack();
					     if (test2185_2226)
					       {
						  node_t aux_4193;
						  aux_4193 = stack__132_cfa_stack((node_t) (app_2207));
						  (obj_t) (aux_4193);
					       }
					     else
					       {
						  app_2207;
					       }
					  }
				       }
				    }
				 }
			      }
			   }
			 else
			   {
			      BFALSE;
			   }
		      }
		 }
	      }
	      {
		 obj_t l2093_4197;
		 l2093_4197 = CDR(l2093_2199);
		 l2093_2199 = l2093_4197;
		 goto lname2094_2200;
	      }
	   }
	 else
	   {
	      return ((bool_t) 1);
	   }
      }
   }
}


/* light-funcall! */ bool_t 
light_funcall__169_cfa_closure()
{
   {
      obj_t l2096_2258;
      l2096_2258 = _funcall_list__139_cfa_closure;
    lname2097_2259:
      if (PAIRP(l2096_2258))
	{
	   {
	      funcall_t app_2261;
	      {
		 obj_t aux_4201;
		 aux_4201 = CAR(l2096_2258);
		 app_2261 = (funcall_t) (aux_4201);
	      }
	      {
		 approx_t approx_2263;
		 approx_2263 = cfa__102_cfa_cfa((((funcall_t) CREF(app_2261))->fun));
		 {
		    obj_t alloc_list_184_2264;
		    alloc_list_184_2264 = set__list_248_cfa_set((((approx_t) CREF(approx_2263))->allocs));
		    {
		       {
			  bool_t test2213_2265;
			  if (PAIRP(alloc_list_184_2264))
			    {
			       bool_t test2225_2280;
			       test2225_2280 = is_a__118___object(CAR(alloc_list_184_2264), make_procedure_app_48_cfa_info);
			       if (test2225_2280)
				 {
				    test2213_2265 = ((bool_t) 0);
				 }
			       else
				 {
				    test2213_2265 = ((bool_t) 1);
				 }
			    }
			  else
			    {
			       test2213_2265 = ((bool_t) 1);
			    }
			  if (test2213_2265)
			    {
			       CNST_TABLE_REF(((long) 4));
			    }
			  else
			    {
			       app_t alloc_2266;
			       {
				  obj_t aux_4215;
				  aux_4215 = CAR(alloc_list_184_2264);
				  alloc_2266 = (app_t) (aux_4215);
			       }
			       {
				  bool_t test_4218;
				  {
				     make_procedure_app_48_t obj_3323;
				     obj_3323 = (make_procedure_app_48_t) (alloc_2266);
				     {
					obj_t aux_4220;
					{
					   object_t aux_4221;
					   aux_4221 = (object_t) (obj_3323);
					   aux_4220 = OBJECT_WIDENING(aux_4221);
					}
					test_4218 = (((make_procedure_app_48_t) CREF(aux_4220))->x);
				     }
				  }
				  if (test_4218)
				    {
				       {
					  var_t arg2215_2269;
					  {
					     var_t duplicated2099_2270;
					     {
						obj_t aux_4225;
						{
						   obj_t aux_4226;
						   aux_4226 = (((app_t) CREF(alloc_2266))->args);
						   aux_4225 = CAR(aux_4226);
						}
						duplicated2099_2270 = (var_t) (aux_4225);
					     }
					     {
						var_t new2100_2271;
						{
						   obj_t arg2216_2272;
						   type_t arg2217_2273;
						   variable_t arg2219_2274;
						   arg2216_2272 = (((var_t) CREF(duplicated2099_2270))->loc);
						   arg2217_2273 = (((var_t) CREF(duplicated2099_2270))->type);
						   arg2219_2274 = (((var_t) CREF(duplicated2099_2270))->variable);
						   {
						      var_t res2591_3339;
						      {
							 var_t new1255_3332;
							 new1255_3332 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							 {
							    long arg2553_3333;
							    arg2553_3333 = class_num_218___object(var_ast_node);
							    {
							       obj_t obj_3337;
							       obj_3337 = (obj_t) (new1255_3332);
							       (((obj_t) CREF(obj_3337))->header = MAKE_HEADER(arg2553_3333, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_4237;
							    aux_4237 = (object_t) (new1255_3332);
							    OBJECT_WIDENING_SET(aux_4237, BFALSE);
							 }
							 ((((var_t) CREF(new1255_3332))->loc) = ((obj_t) arg2216_2272), BUNSPEC);
							 ((((var_t) CREF(new1255_3332))->type) = ((type_t) arg2217_2273), BUNSPEC);
							 ((((var_t) CREF(new1255_3332))->variable) = ((variable_t) arg2219_2274), BUNSPEC);
							 res2591_3339 = new1255_3332;
						      }
						      new2100_2271 = res2591_3339;
						   }
						}
						{
						   arg2215_2269 = new2100_2271;
						}
					     }
					  }
					  {
					     node_t val1323_3341;
					     val1323_3341 = (node_t) (arg2215_2269);
					     ((((funcall_t) CREF(app_2261))->fun) = ((node_t) val1323_3341), BUNSPEC);
					  }
				       }
				       {
					  obj_t arg2221_2276;
					  arg2221_2276 = CNST_TABLE_REF(((long) 5));
					  ((((funcall_t) CREF(app_2261))->strength) = ((obj_t) arg2221_2276), BUNSPEC);
				       }
				    }
				  else
				    {
				       bool_t test_4247;
				       {
					  make_procedure_app_48_t obj_3344;
					  obj_3344 = (make_procedure_app_48_t) (alloc_2266);
					  {
					     obj_t aux_4249;
					     {
						object_t aux_4250;
						aux_4250 = (object_t) (obj_3344);
						aux_4249 = OBJECT_WIDENING(aux_4250);
					     }
					     test_4247 = (((make_procedure_app_48_t) CREF(aux_4249))->t);
					  }
				       }
				       if (test_4247)
					 {
					    {
					       obj_t arg2223_2278;
					       arg2223_2278 = CNST_TABLE_REF(((long) 6));
					       ((((funcall_t) CREF(app_2261))->strength) = ((obj_t) arg2223_2278), BUNSPEC);
					    }
					 }
				       else
					 {
					    CNST_TABLE_REF(((long) 4));
					 }
				    }
			       }
			    }
		       }
		    }
		 }
	      }
	   }
	   {
	      obj_t l2096_4257;
	      l2096_4257 = CDR(l2096_2258);
	      l2096_2258 = l2096_4257;
	      goto lname2097_2259;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* light-access! */ bool_t 
light_access__52_cfa_closure()
{
   {
      obj_t l2101_2284;
      l2101_2284 = _procedure_ref_list__19_cfa_closure;
    lname2102_2285:
      if (PAIRP(l2101_2284))
	{
	   {
	      obj_t app_2287;
	      app_2287 = CAR(l2101_2284);
	      {
		 approx_t approx_2289;
		 {
		    node_t aux_4262;
		    {
		       obj_t aux_4263;
		       {
			  obj_t aux_4264;
			  {
			     app_t obj_3351;
			     obj_3351 = (app_t) (app_2287);
			     aux_4264 = (((app_t) CREF(obj_3351))->args);
			  }
			  aux_4263 = CAR(aux_4264);
		       }
		       aux_4262 = (node_t) (aux_4263);
		    }
		    approx_2289 = cfa__102_cfa_cfa(aux_4262);
		 }
		 {
		    obj_t alloc_list_184_2290;
		    alloc_list_184_2290 = set__list_248_cfa_set((((approx_t) CREF(approx_2289))->allocs));
		    {
		       var_t fun_2291;
		       {
			  app_t obj_3354;
			  obj_3354 = (app_t) (app_2287);
			  fun_2291 = (((app_t) CREF(obj_3354))->fun);
		       }
		       {
			  variable_t vfun_2292;
			  vfun_2292 = (((var_t) CREF(fun_2291))->variable);
			  {
			     {
				bool_t test2230_2293;
				if (PAIRP(alloc_list_184_2290))
				  {
				     bool_t test2242_2307;
				     test2242_2307 = is_a__118___object(CAR(alloc_list_184_2290), make_procedure_app_48_cfa_info);
				     if (test2242_2307)
				       {
					  test2230_2293 = ((bool_t) 0);
				       }
				     else
				       {
					  test2230_2293 = ((bool_t) 1);
				       }
				  }
				else
				  {
				     test2230_2293 = ((bool_t) 1);
				  }
				if (test2230_2293)
				  {
				     CNST_TABLE_REF(((long) 4));
				  }
				else
				  {
				     app_t alloc_2294;
				     {
					obj_t aux_4282;
					aux_4282 = CAR(alloc_list_184_2290);
					alloc_2294 = (app_t) (aux_4282);
				     }
				     {
					bool_t test_4285;
					{
					   make_procedure_app_48_t obj_3360;
					   obj_3360 = (make_procedure_app_48_t) (alloc_2294);
					   {
					      obj_t aux_4287;
					      {
						 object_t aux_4288;
						 aux_4288 = (object_t) (obj_3360);
						 aux_4287 = OBJECT_WIDENING(aux_4288);
					      }
					      test_4285 = (((make_procedure_app_48_t) CREF(aux_4287))->x);
					   }
					}
					if (test_4285)
					  {
					     {
						bool_t test2232_2297;
						{
						   obj_t arg2235_2300;
						   {
						      node_t aux_4292;
						      {
							 obj_t aux_4293;
							 {
							    obj_t aux_4294;
							    {
							       obj_t aux_4295;
							       {
								  obj_t aux_4296;
								  aux_4296 = (((app_t) CREF(alloc_2294))->args);
								  aux_4295 = CDR(aux_4296);
							       }
							       aux_4294 = CDR(aux_4295);
							    }
							    aux_4293 = CAR(aux_4294);
							 }
							 aux_4292 = (node_t) (aux_4293);
						      }
						      arg2235_2300 = get_node_atom_value_135_cfa_approx(aux_4292);
						   }
						   {
						      long aux_4303;
						      aux_4303 = (long) CINT(arg2235_2300);
						      test2232_2297 = (aux_4303 == ((long) 1));
						   }
						}
						if (test2232_2297)
						  {
						     bool_t test2233_2298;
						     {
							obj_t obj2_3371;
							obj2_3371 = _procedure_ref__66_cfa_closure;
							{
							   obj_t aux_4307;
							   aux_4307 = (obj_t) (vfun_2292);
							   test2233_2298 = (aux_4307 == obj2_3371);
							}
						     }
						     if (test2233_2298)
						       {
							  variable_t val1261_3373;
							  val1261_3373 = (variable_t) (_procedure_1_el_ref__37_cfa_closure);
							  ((((var_t) CREF(fun_2291))->variable) = ((variable_t) val1261_3373), BUNSPEC);
						       }
						     else
						       {
							  variable_t val1261_3375;
							  val1261_3375 = (variable_t) (_procedure_1_el_set___97_cfa_closure);
							  ((((var_t) CREF(fun_2291))->variable) = ((variable_t) val1261_3375), BUNSPEC);
						       }
						  }
						else
						  {
						     bool_t test2234_2299;
						     {
							obj_t obj2_3377;
							obj2_3377 = _procedure_ref__66_cfa_closure;
							{
							   obj_t aux_4315;
							   aux_4315 = (obj_t) (vfun_2292);
							   test2234_2299 = (aux_4315 == obj2_3377);
							}
						     }
						     if (test2234_2299)
						       {
							  variable_t val1261_3379;
							  val1261_3379 = (variable_t) (_procedure_el_ref__61_cfa_closure);
							  ((((var_t) CREF(fun_2291))->variable) = ((variable_t) val1261_3379), BUNSPEC);
						       }
						     else
						       {
							  variable_t val1261_3381;
							  val1261_3381 = (variable_t) (_procedure_el_set___46_cfa_closure);
							  ((((var_t) CREF(fun_2291))->variable) = ((variable_t) val1261_3381), BUNSPEC);
						       }
						  }
					     }
					  }
					else
					  {
					     bool_t test_4323;
					     {
						make_procedure_app_48_t obj_3382;
						obj_3382 = (make_procedure_app_48_t) (alloc_2294);
						{
						   obj_t aux_4325;
						   {
						      object_t aux_4326;
						      aux_4326 = (object_t) (obj_3382);
						      aux_4325 = OBJECT_WIDENING(aux_4326);
						   }
						   test_4323 = (((make_procedure_app_48_t) CREF(aux_4325))->t);
						}
					     }
					     if (test_4323)
					       {
						  {
						     bool_t test2240_2305;
						     {
							obj_t obj2_3384;
							obj2_3384 = _procedure_ref__66_cfa_closure;
							{
							   obj_t aux_4330;
							   aux_4330 = (obj_t) (vfun_2292);
							   test2240_2305 = (aux_4330 == obj2_3384);
							}
						     }
						     if (test2240_2305)
						       {
							  variable_t val1261_3386;
							  val1261_3386 = (variable_t) (_procedure_l_ref__76_cfa_closure);
							  ((((var_t) CREF(fun_2291))->variable) = ((variable_t) val1261_3386), BUNSPEC);
						       }
						     else
						       {
							  variable_t val1261_3388;
							  val1261_3388 = (variable_t) (_procedure_l_set___202_cfa_closure);
							  ((((var_t) CREF(fun_2291))->variable) = ((variable_t) val1261_3388), BUNSPEC);
						       }
						  }
					       }
					     else
					       {
						  BFALSE;
					       }
					  }
				     }
				  }
			     }
			  }
		       }
		    }
		 }
	      }
	   }
	   {
	      obj_t l2101_4338;
	      l2101_4338 = CDR(l2101_2284);
	      l2101_2284 = l2101_4338;
	      goto lname2102_2285;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* show-x-t */ obj_t 
show_x_t_233_cfa_closure(obj_t allocs_4)
{
   {
      obj_t xp_2314;
      obj_t tp_2315;
      obj_t allocs_2316;
      xp_2314 = BNIL;
      tp_2315 = BNIL;
      allocs_2316 = allocs_4;
    loop_2317:
      if (NULLP(allocs_2316))
	{
	   show_cfa_closure(CNST_TABLE_REF(((long) 7)), xp_2314);
	   show_cfa_closure(CNST_TABLE_REF(((long) 8)), tp_2315);
	   return BUNSPEC;
	}
      else
	{
	   obj_t instance2106_2323;
	   instance2106_2323 = CAR(allocs_2316);
	   {
	      bool_t test_4347;
	      {
		 make_procedure_app_48_t obj_3392;
		 obj_3392 = (make_procedure_app_48_t) (instance2106_2323);
		 {
		    obj_t aux_4349;
		    {
		       object_t aux_4350;
		       aux_4350 = (object_t) (obj_3392);
		       aux_4349 = OBJECT_WIDENING(aux_4350);
		    }
		    test_4347 = (((make_procedure_app_48_t) CREF(aux_4349))->x);
		 }
	      }
	      if (test_4347)
		{
		   {
		      obj_t arg2258_2325;
		      obj_t arg2259_2326;
		      {
			 obj_t aux_4354;
			 {
			    variable_t aux_4355;
			    {
			       var_t obj_3395;
			       {
				  obj_t aux_4356;
				  {
				     obj_t aux_4357;
				     {
					app_t obj_3393;
					obj_3393 = (app_t) (instance2106_2323);
					aux_4357 = (((app_t) CREF(obj_3393))->args);
				     }
				     aux_4356 = CAR(aux_4357);
				  }
				  obj_3395 = (var_t) (aux_4356);
			       }
			       aux_4355 = (((var_t) CREF(obj_3395))->variable);
			    }
			    aux_4354 = (obj_t) (aux_4355);
			 }
			 arg2258_2325 = MAKE_PAIR(aux_4354, xp_2314);
		      }
		      arg2259_2326 = CDR(allocs_2316);
		      {
			 obj_t allocs_4367;
			 obj_t xp_4366;
			 xp_4366 = arg2258_2325;
			 allocs_4367 = arg2259_2326;
			 allocs_2316 = allocs_4367;
			 xp_2314 = xp_4366;
			 goto loop_2317;
		      }
		   }
		}
	      else
		{
		   bool_t test_4368;
		   {
		      make_procedure_app_48_t obj_3399;
		      obj_3399 = (make_procedure_app_48_t) (instance2106_2323);
		      {
			 obj_t aux_4370;
			 {
			    object_t aux_4371;
			    aux_4371 = (object_t) (obj_3399);
			    aux_4370 = OBJECT_WIDENING(aux_4371);
			 }
			 test_4368 = (((make_procedure_app_48_t) CREF(aux_4370))->t);
		      }
		   }
		   if (test_4368)
		     {
			{
			   obj_t arg2265_2331;
			   obj_t arg2266_2332;
			   {
			      obj_t aux_4375;
			      {
				 variable_t aux_4376;
				 {
				    var_t obj_3402;
				    {
				       obj_t aux_4377;
				       {
					  obj_t aux_4378;
					  {
					     app_t obj_3400;
					     obj_3400 = (app_t) (instance2106_2323);
					     aux_4378 = (((app_t) CREF(obj_3400))->args);
					  }
					  aux_4377 = CAR(aux_4378);
				       }
				       obj_3402 = (var_t) (aux_4377);
				    }
				    aux_4376 = (((var_t) CREF(obj_3402))->variable);
				 }
				 aux_4375 = (obj_t) (aux_4376);
			      }
			      arg2265_2331 = MAKE_PAIR(aux_4375, tp_2315);
			   }
			   arg2266_2332 = CDR(allocs_2316);
			   {
			      obj_t allocs_4388;
			      obj_t tp_4387;
			      tp_4387 = arg2265_2331;
			      allocs_4388 = arg2266_2332;
			      allocs_2316 = allocs_4388;
			      tp_2315 = tp_4387;
			      goto loop_2317;
			   }
			}
		     }
		   else
		     {
			{
			   obj_t allocs_4389;
			   allocs_4389 = CDR(allocs_2316);
			   allocs_2316 = allocs_4389;
			   goto loop_2317;
			}
		     }
		}
	   }
	}
   }
}


/* show */ obj_t 
show_cfa_closure(obj_t prop_2337, obj_t l_2338)
{
   if (PAIRP(l_2338))
     {
	{
	   obj_t arg2276_2344;
	   arg2276_2344 = shape_tools_shape(CAR(l_2338));
	   {
	      obj_t list2277_2345;
	      {
		 obj_t arg2278_2346;
		 {
		    obj_t arg2279_2347;
		    {
		       obj_t arg2280_2348;
		       {
			  obj_t arg2281_2349;
			  {
			     obj_t aux_4395;
			     aux_4395 = BCHAR(((unsigned char) '\n'));
			     arg2281_2349 = MAKE_PAIR(aux_4395, BNIL);
			  }
			  arg2280_2348 = MAKE_PAIR(arg2276_2344, arg2281_2349);
		       }
		       arg2279_2347 = MAKE_PAIR(string2598_cfa_closure, arg2280_2348);
		    }
		    arg2278_2346 = MAKE_PAIR(prop_2337, arg2279_2347);
		 }
		 list2277_2345 = MAKE_PAIR(string2599_cfa_closure, arg2278_2346);
	      }
	      verbose_tools_speek(BINT(((long) 2)), list2277_2345);
	   }
	}
	{
	   obj_t l2104_2352;
	   {
	      bool_t aux_4404;
	      l2104_2352 = CDR(l_2338);
	    lname2105_2353:
	      if (PAIRP(l2104_2352))
		{
		   {
		      obj_t arg2288_2359;
		      arg2288_2359 = shape_tools_shape(CAR(l2104_2352));
		      {
			 obj_t list2289_2360;
			 {
			    obj_t arg2291_2361;
			    {
			       obj_t arg2292_2362;
			       {
				  obj_t aux_4409;
				  aux_4409 = BCHAR(((unsigned char) '\n'));
				  arg2292_2362 = MAKE_PAIR(aux_4409, BNIL);
			       }
			       arg2291_2361 = MAKE_PAIR(arg2288_2359, arg2292_2362);
			    }
			    list2289_2360 = MAKE_PAIR(string2600_cfa_closure, arg2291_2361);
			 }
			 verbose_tools_speek(BINT(((long) 2)), list2289_2360);
		      }
		   }
		   {
		      obj_t l2104_4416;
		      l2104_4416 = CDR(l2104_2352);
		      l2104_2352 = l2104_4416;
		      goto lname2105_2353;
		   }
		}
	      else
		{
		   aux_4404 = ((bool_t) 1);
		}
	      return BBOOL(aux_4404);
	   }
	}
     }
   else
     {
	return BUNSPEC;
     }
}


/* add-funcall! */ obj_t 
add_funcall__195_cfa_closure(node_t ast_5)
{
   {
      bool_t test2295_2366;
      {
	 long n1_3413;
	 n1_3413 = (long) CINT(_optim__89_engine_param);
	 test2295_2366 = (n1_3413 >= ((long) 2));
      }
      if (test2295_2366)
	{
	   obj_t obj2_3416;
	   obj2_3416 = _funcall_list__139_cfa_closure;
	   {
	      obj_t aux_4423;
	      aux_4423 = (obj_t) (ast_5);
	      return (_funcall_list__139_cfa_closure = MAKE_PAIR(aux_4423, obj2_3416),
		 BUNSPEC);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _add-funcall!2592 */ obj_t 
_add_funcall_2592_213_cfa_closure(obj_t env_3787, obj_t ast_3788)
{
   return add_funcall__195_cfa_closure((node_t) (ast_3788));
}


/* add-make-procedure! */ obj_t 
add_make_procedure__219_cfa_closure(node_t ast_6)
{
   {
      bool_t test2296_2367;
      {
	 long n1_3417;
	 n1_3417 = (long) CINT(_optim__89_engine_param);
	 test2296_2367 = (n1_3417 >= ((long) 2));
      }
      if (test2296_2367)
	{
	   obj_t obj2_3420;
	   obj2_3420 = _make_procedure_list__56_cfa_closure;
	   {
	      obj_t aux_4431;
	      aux_4431 = (obj_t) (ast_6);
	      return (_make_procedure_list__56_cfa_closure = MAKE_PAIR(aux_4431, obj2_3420),
		 BUNSPEC);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _add-make-procedure!2593 */ obj_t 
_add_make_procedure_2593_203_cfa_closure(obj_t env_3789, obj_t ast_3790)
{
   return add_make_procedure__219_cfa_closure((node_t) (ast_3790));
}


/* add-procedure-ref! */ obj_t 
add_procedure_ref__36_cfa_closure(node_t ast_7)
{
   {
      bool_t test2297_2368;
      {
	 long n1_3421;
	 n1_3421 = (long) CINT(_optim__89_engine_param);
	 test2297_2368 = (n1_3421 >= ((long) 2));
      }
      if (test2297_2368)
	{
	   obj_t obj2_3424;
	   obj2_3424 = _procedure_ref_list__19_cfa_closure;
	   {
	      obj_t aux_4439;
	      aux_4439 = (obj_t) (ast_7);
	      return (_procedure_ref_list__19_cfa_closure = MAKE_PAIR(aux_4439, obj2_3424),
		 BUNSPEC);
	   }
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _add-procedure-ref!2594 */ obj_t 
_add_procedure_ref_2594_23_cfa_closure(obj_t env_3791, obj_t ast_3792)
{
   return add_procedure_ref__36_cfa_closure((node_t) (ast_3792));
}


/* start-cache */ obj_t 
start_cache_11_cfa_closure()
{
   {
      obj_t arg2298_2369;
      arg2298_2369 = CNST_TABLE_REF(((long) 9));
      {
	 obj_t list2300_2371;
	 {
	    obj_t aux_4445;
	    aux_4445 = CNST_TABLE_REF(((long) 10));
	    list2300_2371 = MAKE_PAIR(aux_4445, BNIL);
	 }
	 _procedure_ref__66_cfa_closure = find_global_223_ast_env(arg2298_2369, list2300_2371);
      }
   }
   {
      obj_t arg2302_2373;
      arg2302_2373 = CNST_TABLE_REF(((long) 11));
      {
	 obj_t list2304_2375;
	 {
	    obj_t aux_4450;
	    aux_4450 = CNST_TABLE_REF(((long) 10));
	    list2304_2375 = MAKE_PAIR(aux_4450, BNIL);
	 }
	 _procedure_set___197_cfa_closure = find_global_223_ast_env(arg2302_2373, list2304_2375);
      }
   }
   {
      obj_t arg2306_2377;
      arg2306_2377 = CNST_TABLE_REF(((long) 12));
      {
	 obj_t list2308_2379;
	 {
	    obj_t aux_4455;
	    aux_4455 = CNST_TABLE_REF(((long) 10));
	    list2308_2379 = MAKE_PAIR(aux_4455, BNIL);
	 }
	 _procedure_l_ref__76_cfa_closure = find_global_223_ast_env(arg2306_2377, list2308_2379);
      }
   }
   {
      obj_t arg2310_2381;
      arg2310_2381 = CNST_TABLE_REF(((long) 13));
      {
	 obj_t list2312_2383;
	 {
	    obj_t aux_4460;
	    aux_4460 = CNST_TABLE_REF(((long) 10));
	    list2312_2383 = MAKE_PAIR(aux_4460, BNIL);
	 }
	 _procedure_l_set___202_cfa_closure = find_global_223_ast_env(arg2310_2381, list2312_2383);
      }
   }
   {
      obj_t arg2319_2385;
      arg2319_2385 = CNST_TABLE_REF(((long) 14));
      {
	 obj_t list2321_2387;
	 {
	    obj_t aux_4465;
	    aux_4465 = CNST_TABLE_REF(((long) 10));
	    list2321_2387 = MAKE_PAIR(aux_4465, BNIL);
	 }
	 _procedure_el_ref__61_cfa_closure = find_global_223_ast_env(arg2319_2385, list2321_2387);
      }
   }
   {
      obj_t arg2323_2389;
      arg2323_2389 = CNST_TABLE_REF(((long) 15));
      {
	 obj_t list2325_2391;
	 {
	    obj_t aux_4470;
	    aux_4470 = CNST_TABLE_REF(((long) 10));
	    list2325_2391 = MAKE_PAIR(aux_4470, BNIL);
	 }
	 _procedure_el_set___46_cfa_closure = find_global_223_ast_env(arg2323_2389, list2325_2391);
      }
   }
   {
      obj_t arg2327_2393;
      arg2327_2393 = CNST_TABLE_REF(((long) 16));
      {
	 obj_t list2329_2395;
	 {
	    obj_t aux_4475;
	    aux_4475 = CNST_TABLE_REF(((long) 10));
	    list2329_2395 = MAKE_PAIR(aux_4475, BNIL);
	 }
	 _procedure_1_el_ref__37_cfa_closure = find_global_223_ast_env(arg2327_2393, list2329_2395);
      }
   }
   {
      obj_t arg2331_2397;
      arg2331_2397 = CNST_TABLE_REF(((long) 17));
      {
	 obj_t list2333_2399;
	 {
	    obj_t aux_4480;
	    aux_4480 = CNST_TABLE_REF(((long) 10));
	    list2333_2399 = MAKE_PAIR(aux_4480, BNIL);
	 }
	 _procedure_1_el_set___97_cfa_closure = find_global_223_ast_env(arg2331_2397, list2333_2399);
      }
   }
   {
      obj_t arg2335_2401;
      arg2335_2401 = CNST_TABLE_REF(((long) 18));
      {
	 obj_t list2337_2403;
	 {
	    obj_t aux_4485;
	    aux_4485 = CNST_TABLE_REF(((long) 10));
	    list2337_2403 = MAKE_PAIR(aux_4485, BNIL);
	 }
	 _make_el_procedure__202_cfa_closure = find_global_223_ast_env(arg2335_2401, list2337_2403);
      }
   }
   {
      obj_t arg2339_2405;
      arg2339_2405 = CNST_TABLE_REF(((long) 19));
      {
	 obj_t list2341_2407;
	 {
	    obj_t aux_4490;
	    aux_4490 = CNST_TABLE_REF(((long) 10));
	    list2341_2407 = MAKE_PAIR(aux_4490, BNIL);
	 }
	 _make_el_procedure_1__141_cfa_closure = find_global_223_ast_env(arg2339_2405, list2341_2407);
      }
   }
   {
      obj_t arg2343_2409;
      arg2343_2409 = CNST_TABLE_REF(((long) 20));
      {
	 obj_t list2345_2411;
	 {
	    obj_t aux_4495;
	    aux_4495 = CNST_TABLE_REF(((long) 10));
	    list2345_2411 = MAKE_PAIR(aux_4495, BNIL);
	 }
	 return (_make_l_procedure__54_cfa_closure = find_global_223_ast_env(arg2343_2409, list2345_2411),
	    BUNSPEC);
      }
   }
}


/* stop-cache */ obj_t 
stop_cache_174_cfa_closure()
{
   _procedure_ref__66_cfa_closure = BFALSE;
   _procedure_set___197_cfa_closure = BFALSE;
   _procedure_l_ref__76_cfa_closure = BFALSE;
   _procedure_l_set___202_cfa_closure = BFALSE;
   _procedure_el_ref__61_cfa_closure = BFALSE;
   _procedure_el_set___46_cfa_closure = BFALSE;
   _procedure_1_el_ref__37_cfa_closure = BFALSE;
   _procedure_1_el_set___97_cfa_closure = BFALSE;
   _make_el_procedure__202_cfa_closure = BFALSE;
   _make_el_procedure_1__141_cfa_closure = BFALSE;
   return (_make_l_procedure__54_cfa_closure = BFALSE,
      BUNSPEC);
}


/* method-init */ obj_t 
method_init_76_cfa_closure()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_closure()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_CLOSURE");
   module_initialization_70_engine_param(((long) 0), "CFA_CLOSURE");
   module_initialization_70_type_type(((long) 0), "CFA_CLOSURE");
   module_initialization_70_type_cache(((long) 0), "CFA_CLOSURE");
   module_initialization_70_tools_shape(((long) 0), "CFA_CLOSURE");
   module_initialization_70_tools_speek(((long) 0), "CFA_CLOSURE");
   module_initialization_70_ast_var(((long) 0), "CFA_CLOSURE");
   module_initialization_70_ast_node(((long) 0), "CFA_CLOSURE");
   module_initialization_70_ast_env(((long) 0), "CFA_CLOSURE");
   module_initialization_70_cfa_info(((long) 0), "CFA_CLOSURE");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_CLOSURE");
   module_initialization_70_cfa_approx(((long) 0), "CFA_CLOSURE");
   module_initialization_70_cfa_set(((long) 0), "CFA_CLOSURE");
   return module_initialization_70_cfa_stack(((long) 0), "CFA_CLOSURE");
}
