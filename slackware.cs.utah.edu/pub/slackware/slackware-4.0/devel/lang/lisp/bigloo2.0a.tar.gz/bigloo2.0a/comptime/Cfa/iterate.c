/*===========================================================================*/
/*   (Cfa/iterate.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_iterate();
extern approx_t cfa_intern_sfun__162_cfa_iterate(intern_sfun_cinfo_192_t, obj_t);
extern obj_t cfa_export_var__93_cfa_iterate(value_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
static obj_t _cfa_intern_sfun_2395_21_cfa_iterate(obj_t, obj_t, obj_t);
static obj_t cfa_export_var__default2087_129_cfa_iterate(value_t, obj_t);
extern obj_t intern_sfun_cinfo_192_cfa_info;
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_unit(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern obj_t stack_intern_sfun_loose__226_cfa_loose(approx_t, obj_t);
extern obj_t unit_initializers_25_ast_unit();
extern obj_t cfa_iterate__222_cfa_iterate(obj_t);
static obj_t imported_modules_init_94_cfa_iterate();
static obj_t _cfa_continue___179_cfa_iterate = BUNSPEC;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
static obj_t _continue_cfa__96_cfa_iterate(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cfa_iterate();
extern approx_t cfa__102_cfa_cfa(node_t);
extern obj_t cfa_variable_value_approx_39_cfa_cfa(value_t);
static obj_t toplevel_init_63_cfa_iterate();
extern obj_t open_input_string(obj_t);
static obj_t _cfa_export_var_2396_236_cfa_iterate(obj_t, obj_t, obj_t);
extern obj_t sfun_ast_var;
static obj_t _cfa_iterate__24_cfa_iterate(obj_t, obj_t);
static obj_t _cfa_iterate_to_fixpoint__26_cfa_iterate(obj_t, obj_t);
static obj_t _cfa_export_var__default2087_48_cfa_iterate(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t cfa_iterate_to_fixpoint__166_cfa_iterate(obj_t);
extern obj_t svar_cinfo_166_cfa_info;
obj_t _cfa_stamp__16_cfa_iterate = BUNSPEC;
static obj_t require_initialization_114_cfa_iterate = BUNSPEC;
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
extern obj_t continue_cfa__104_cfa_iterate();
static obj_t cnst_init_137_cfa_iterate();
static obj_t __cnst[3];

DEFINE_EXPORT_GENERIC(cfa_export_var__env_209_cfa_iterate, _cfa_export_var_2396_236_cfa_iterate2404, _cfa_export_var_2396_236_cfa_iterate, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfa_iterate_to_fixpoint__env_242_cfa_iterate, _cfa_iterate_to_fixpoint__26_cfa_iterate2405, _cfa_iterate_to_fixpoint__26_cfa_iterate, 0L, 1);
DEFINE_EXPORT_PROCEDURE(continue_cfa__env_5_cfa_iterate, _continue_cfa__96_cfa_iterate2406, _continue_cfa__96_cfa_iterate, 0L, 0);
DEFINE_EXPORT_PROCEDURE(cfa_iterate__env_97_cfa_iterate, _cfa_iterate__24_cfa_iterate2407, _cfa_iterate__24_cfa_iterate, 0L, 1);
DEFINE_STRING(string2398_cfa_iterate, string2398_cfa_iterate2408, "CFA-EXPORT-VAR!-DEFAULT2087 ALL EXPORT ", 39);
DEFINE_STRING(string2397_cfa_iterate, string2397_cfa_iterate2409, "No method for this object", 25);
DEFINE_STATIC_PROCEDURE(cfa_export_var__default2087_env_10_cfa_iterate, _cfa_export_var__default2087_48_cfa_iterate2410, _cfa_export_var__default2087_48_cfa_iterate, 0L, 2);
DEFINE_EXPORT_PROCEDURE(cfa_intern_sfun__env_197_cfa_iterate, _cfa_intern_sfun_2395_21_cfa_iterate2411, _cfa_intern_sfun_2395_21_cfa_iterate, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_cfa_iterate(long checksum_3376, char *from_3377)
{
   if (CBOOL(require_initialization_114_cfa_iterate))
     {
	require_initialization_114_cfa_iterate = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_iterate();
	cnst_init_137_cfa_iterate();
	imported_modules_init_94_cfa_iterate();
	method_init_76_cfa_iterate();
	toplevel_init_63_cfa_iterate();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_iterate()
{
   module_initialization_70___object(((long) 0), "CFA_ITERATE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_ITERATE");
   module_initialization_70___reader(((long) 0), "CFA_ITERATE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_iterate()
{
   {
      obj_t cnst_port_138_3368;
      cnst_port_138_3368 = open_input_string(string2398_cfa_iterate);
      {
	 long i_3369;
	 i_3369 = ((long) 2);
       loop_3370:
	 {
	    bool_t test2399_3371;
	    test2399_3371 = (i_3369 == ((long) -1));
	    if (test2399_3371)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2400_3372;
		    {
		       obj_t list2401_3373;
		       {
			  obj_t arg2402_3374;
			  arg2402_3374 = BNIL;
			  list2401_3373 = MAKE_PAIR(cnst_port_138_3368, arg2402_3374);
		       }
		       arg2400_3372 = read___reader(list2401_3373);
		    }
		    CNST_TABLE_SET(i_3369, arg2400_3372);
		 }
		 {
		    int aux_3375;
		    {
		       long aux_3395;
		       aux_3395 = (i_3369 - ((long) 1));
		       aux_3375 = (int) (aux_3395);
		    }
		    {
		       long i_3398;
		       i_3398 = (long) (aux_3375);
		       i_3369 = i_3398;
		       goto loop_3370;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_iterate()
{
   _cfa_continue___179_cfa_iterate = BUNSPEC;
   return (_cfa_stamp__16_cfa_iterate = BINT(((long) -1)),
      BUNSPEC);
}


/* cfa-iterate-to-fixpoint! */ obj_t 
cfa_iterate_to_fixpoint__166_cfa_iterate(obj_t globals_1)
{
   _cfa_stamp__16_cfa_iterate = BINT(((long) -1));
   {
      obj_t glodefs_2109;
      glodefs_2109 = BNIL;
      {
	 obj_t l2077_2110;
	 l2077_2110 = globals_1;
       lname2078_2111:
	 if (PAIRP(l2077_2110))
	   {
	      {
		 obj_t g_2113;
		 g_2113 = CAR(l2077_2110);
		 {
		    bool_t test_3405;
		    {
		       obj_t aux_3409;
		       obj_t aux_3406;
		       aux_3409 = CNST_TABLE_REF(((long) 0));
		       {
			  global_t obj_2934;
			  obj_2934 = (global_t) (g_2113);
			  aux_3406 = (((global_t) CREF(obj_2934))->import);
		       }
		       test_3405 = (aux_3406 == aux_3409);
		    }
		    if (test_3405)
		      {
			 obj_t obj2_2938;
			 obj2_2938 = glodefs_2109;
			 glodefs_2109 = MAKE_PAIR(g_2113, obj2_2938);
		      }
		    else
		      {
			 BUNSPEC;
		      }
		 }
	      }
	      {
		 obj_t l2077_3413;
		 l2077_3413 = CDR(l2077_2110);
		 l2077_2110 = l2077_3413;
		 goto lname2078_2111;
	      }
	   }
	 else
	   {
	      ((bool_t) 1);
	   }
      }
      {
	 obj_t arg2095_2118;
	 arg2095_2118 = unit_initializers_25_ast_unit();
	 glodefs_2109 = append_2_18___r4_pairs_and_lists_6_3(arg2095_2118, glodefs_2109);
      }
      continue_cfa__104_cfa_iterate();
      {
       loop_2119:
	 {
	    bool_t test2096_2120;
	    test2096_2120 = CBOOL(_cfa_continue___179_cfa_iterate);
	    if (test2096_2120)
	      {
		 cfa_iterate__222_cfa_iterate(glodefs_2109);
		 goto loop_2119;
	      }
	    else
	      {
		 return glodefs_2109;
	      }
	 }
      }
   }
}


/* _cfa-iterate-to-fixpoint! */ obj_t 
_cfa_iterate_to_fixpoint__26_cfa_iterate(obj_t env_3354, obj_t globals_3355)
{
   return cfa_iterate_to_fixpoint__166_cfa_iterate(globals_3355);
}


/* cfa-iterate! */ obj_t 
cfa_iterate__222_cfa_iterate(obj_t globals_2)
{
   _cfa_continue___179_cfa_iterate = BFALSE;
   {
      long z2_2941;
      z2_2941 = (long) CINT(_cfa_stamp__16_cfa_iterate);
      {
	 long aux_3423;
	 aux_3423 = (((long) 1) + z2_2941);
	 _cfa_stamp__16_cfa_iterate = BINT(aux_3423);
      }
   }
   {
      obj_t l2079_2121;
      l2079_2121 = globals_2;
    lname2080_2122:
      if (PAIRP(l2079_2121))
	{
	   {
	      obj_t g_2124;
	      g_2124 = CAR(l2079_2121);
	      {
		 value_t aux_3429;
		 {
		    global_t obj_2944;
		    obj_2944 = (global_t) (g_2124);
		    aux_3429 = (((global_t) CREF(obj_2944))->value);
		 }
		 cfa_export_var__93_cfa_iterate(aux_3429, g_2124);
	      }
	      BUNSPEC;
	   }
	   {
	      obj_t l2079_3433;
	      l2079_3433 = CDR(l2079_2121);
	      l2079_2121 = l2079_3433;
	      goto lname2080_2122;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   return BUNSPEC;
}


/* _cfa-iterate! */ obj_t 
_cfa_iterate__24_cfa_iterate(obj_t env_3356, obj_t globals_3357)
{
   return cfa_iterate__222_cfa_iterate(globals_3357);
}


/* cfa-intern-sfun! */ approx_t 
cfa_intern_sfun__162_cfa_iterate(intern_sfun_cinfo_192_t sfun_11, obj_t owner_12)
{
   {
      bool_t test2100_2128;
      {
	 long arg2106_2133;
	 {
	    obj_t aux_3436;
	    {
	       object_t aux_3437;
	       aux_3437 = (object_t) (sfun_11);
	       aux_3436 = OBJECT_WIDENING(aux_3437);
	    }
	    arg2106_2133 = (((intern_sfun_cinfo_192_t) CREF(aux_3436))->stamp);
	 }
	 {
	    long n2_2948;
	    n2_2948 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	    test2100_2128 = (arg2106_2133 == n2_2948);
	 }
      }
      if (test2100_2128)
	{
	   obj_t aux_3444;
	   {
	      object_t aux_3445;
	      aux_3445 = (object_t) (sfun_11);
	      aux_3444 = OBJECT_WIDENING(aux_3445);
	   }
	   return (((intern_sfun_cinfo_192_t) CREF(aux_3444))->approx);
	}
      else
	{
	   {
	      long val1541_2951;
	      val1541_2951 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	      {
		 obj_t aux_3450;
		 {
		    object_t aux_3451;
		    aux_3451 = (object_t) (sfun_11);
		    aux_3450 = OBJECT_WIDENING(aux_3451);
		 }
		 ((((intern_sfun_cinfo_192_t) CREF(aux_3450))->stamp) = ((long) val1541_2951), BUNSPEC);
	      }
	   }
	   {
	      approx_t arg2101_2129;
	      approx_t arg2102_2130;
	      {
		 obj_t aux_3455;
		 {
		    object_t aux_3456;
		    aux_3456 = (object_t) (sfun_11);
		    aux_3455 = OBJECT_WIDENING(aux_3456);
		 }
		 arg2101_2129 = (((intern_sfun_cinfo_192_t) CREF(aux_3455))->approx);
	      }
	      {
		 node_t aux_3460;
		 {
		    obj_t aux_3461;
		    {
		       sfun_t obj_2953;
		       obj_2953 = (sfun_t) (sfun_11);
		       aux_3461 = (((sfun_t) CREF(obj_2953))->body);
		    }
		    aux_3460 = (node_t) (aux_3461);
		 }
		 arg2102_2130 = cfa__102_cfa_cfa(aux_3460);
	      }
	      union_approx__241_cfa_approx(arg2101_2129, arg2102_2130);
	   }
	   {
	      approx_t aux_3467;
	      {
		 obj_t aux_3468;
		 {
		    object_t aux_3469;
		    aux_3469 = (object_t) (sfun_11);
		    aux_3468 = OBJECT_WIDENING(aux_3469);
		 }
		 aux_3467 = (((intern_sfun_cinfo_192_t) CREF(aux_3468))->approx);
	      }
	      stack_intern_sfun_loose__226_cfa_loose(aux_3467, owner_12);
	   }
	   {
	      obj_t aux_3474;
	      {
		 object_t aux_3475;
		 aux_3475 = (object_t) (sfun_11);
		 aux_3474 = OBJECT_WIDENING(aux_3475);
	      }
	      return (((intern_sfun_cinfo_192_t) CREF(aux_3474))->approx);
	   }
	}
   }
}


/* _cfa-intern-sfun!2395 */ obj_t 
_cfa_intern_sfun_2395_21_cfa_iterate(obj_t env_3358, obj_t sfun_3359, obj_t owner_3360)
{
   {
      approx_t aux_3479;
      aux_3479 = cfa_intern_sfun__162_cfa_iterate((intern_sfun_cinfo_192_t) (sfun_3359), owner_3360);
      return (obj_t) (aux_3479);
   }
}


/* continue-cfa! */ obj_t 
continue_cfa__104_cfa_iterate()
{
   if (CBOOL(_cfa_continue___179_cfa_iterate))
     {
	BUNSPEC;
     }
   else
     {
	BUNSPEC;
     }
   return (_cfa_continue___179_cfa_iterate = BTRUE,
      BUNSPEC);
}


/* _continue-cfa! */ obj_t 
_continue_cfa__96_cfa_iterate(obj_t env_3361)
{
   return continue_cfa__104_cfa_iterate();
}


/* method-init */ obj_t 
method_init_76_cfa_iterate()
{
   add_generic__110___object(cfa_export_var__env_209_cfa_iterate, cfa_export_var__default2087_env_10_cfa_iterate);
   add_inlined_method__244___object(cfa_export_var__env_209_cfa_iterate, svar_cinfo_166_cfa_info, ((long) 0));
   {
      long aux_3488;
      aux_3488 = add_inlined_method__244___object(cfa_export_var__env_209_cfa_iterate, intern_sfun_cinfo_192_cfa_info, ((long) 1));
      return BINT(aux_3488);
   }
}


/* cfa-export-var! */ obj_t 
cfa_export_var__93_cfa_iterate(value_t value_3, obj_t owner_4)
{
   {
      obj_t method2361_2893;
      obj_t class2366_2894;
      {
	 obj_t arg2369_2891;
	 obj_t arg2370_2892;
	 {
	    object_t obj_3303;
	    obj_3303 = (object_t) (value_3);
	    {
	       obj_t pre_method_105_3304;
	       pre_method_105_3304 = PROCEDURE_REF(cfa_export_var__env_209_cfa_iterate, ((long) 2));
	       if (INTEGERP(pre_method_105_3304))
		 {
		    PROCEDURE_SET(cfa_export_var__env_209_cfa_iterate, ((long) 2), BUNSPEC);
		    arg2369_2891 = pre_method_105_3304;
		 }
	       else
		 {
		    long obj_class_num_177_3309;
		    obj_class_num_177_3309 = TYPE(obj_3303);
		    {
		       obj_t arg1177_3310;
		       arg1177_3310 = PROCEDURE_REF(cfa_export_var__env_209_cfa_iterate, ((long) 1));
		       {
			  long arg1178_3314;
			  {
			     long arg1179_3315;
			     arg1179_3315 = OBJECT_TYPE;
			     arg1178_3314 = (obj_class_num_177_3309 - arg1179_3315);
			  }
			  arg2369_2891 = VECTOR_REF(arg1177_3310, arg1178_3314);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_3320;
	    object_3320 = (object_t) (value_3);
	    {
	       long arg1180_3321;
	       {
		  long arg1181_3322;
		  long arg1182_3323;
		  arg1181_3322 = TYPE(object_3320);
		  arg1182_3323 = OBJECT_TYPE;
		  arg1180_3321 = (arg1181_3322 - arg1182_3323);
	       }
	       {
		  obj_t vector_3327;
		  vector_3327 = _classes__134___object;
		  arg2370_2892 = VECTOR_REF(vector_3327, arg1180_3321);
	       }
	    }
	 }
	 method2361_2893 = arg2369_2891;
	 class2366_2894 = arg2370_2892;
	 {
	    if (INTEGERP(method2361_2893))
	      {
		 switch ((long) CINT(method2361_2893))
		   {
		   case ((long) 0):
		      {
			 svar_cinfo_166_t value_2900;
			 value_2900 = (svar_cinfo_166_t) (value_3);
			 {
			    obj_t instance2081_2902;
			    instance2081_2902 = sfun_ast_var;
			    {
			       bool_t test2373_2903;
			       {
				  long arg2376_2906;
				  {
				     intern_sfun_cinfo_192_t obj_3329;
				     obj_3329 = (intern_sfun_cinfo_192_t) (instance2081_2902);
				     {
					obj_t aux_3510;
					{
					   object_t aux_3511;
					   aux_3511 = (object_t) (obj_3329);
					   aux_3510 = OBJECT_WIDENING(aux_3511);
					}
					arg2376_2906 = (((intern_sfun_cinfo_192_t) CREF(aux_3510))->stamp);
				     }
				  }
				  {
				     long n2_3331;
				     n2_3331 = (long) CINT(_cfa_stamp__16_cfa_iterate);
				     test2373_2903 = (arg2376_2906 == n2_3331);
				  }
			       }
			       if (test2373_2903)
				 {
				    return cfa_variable_value_approx_39_cfa_cfa((value_t) (value_2900));
				 }
			       else
				 {
				    {
				       intern_sfun_cinfo_192_t obj_3332;
				       long val1541_3333;
				       obj_3332 = (intern_sfun_cinfo_192_t) (instance2081_2902);
				       val1541_3333 = (long) CINT(_cfa_stamp__16_cfa_iterate);
				       {
					  obj_t aux_3522;
					  {
					     object_t aux_3523;
					     aux_3523 = (object_t) (obj_3332);
					     aux_3522 = OBJECT_WIDENING(aux_3523);
					  }
					  ((((intern_sfun_cinfo_192_t) CREF(aux_3522))->stamp) = ((long) val1541_3333), BUNSPEC);
				       }
				    }
				    {
				       obj_t arg2374_2904;
				       obj_t arg2375_2905;
				       arg2374_2904 = cfa_variable_value_approx_39_cfa_cfa((value_t) (value_2900));
				       arg2375_2905 = CNST_TABLE_REF(((long) 1));
				       {
					  approx_t aux_3530;
					  aux_3530 = loose__226_cfa_loose((approx_t) (arg2374_2904), arg2375_2905);
					  return (obj_t) (aux_3530);
				       }
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 intern_sfun_cinfo_192_t value_2907;
			 value_2907 = (intern_sfun_cinfo_192_t) (value_3);
			 {
			    bool_t test2377_2910;
			    {
			       long arg2386_2922;
			       {
				  obj_t aux_3535;
				  {
				     object_t aux_3536;
				     aux_3536 = (object_t) (value_2907);
				     aux_3535 = OBJECT_WIDENING(aux_3536);
				  }
				  arg2386_2922 = (((intern_sfun_cinfo_192_t) CREF(aux_3535))->stamp);
			       }
			       {
				  long n2_3336;
				  n2_3336 = (long) CINT(_cfa_stamp__16_cfa_iterate);
				  test2377_2910 = (arg2386_2922 == n2_3336);
			       }
			    }
			    if (test2377_2910)
			      {
				 {
				    long val1541_3338;
				    val1541_3338 = (long) CINT(_cfa_stamp__16_cfa_iterate);
				    {
				       obj_t aux_3544;
				       {
					  object_t aux_3545;
					  aux_3545 = (object_t) (value_2907);
					  aux_3544 = OBJECT_WIDENING(aux_3545);
				       }
				       ((((intern_sfun_cinfo_192_t) CREF(aux_3544))->stamp) = ((long) val1541_3338), BUNSPEC);
				    }
				 }
				 {
				    approx_t aux_3549;
				    {
				       obj_t aux_3550;
				       {
					  object_t aux_3551;
					  aux_3551 = (object_t) (value_2907);
					  aux_3550 = OBJECT_WIDENING(aux_3551);
				       }
				       aux_3549 = (((intern_sfun_cinfo_192_t) CREF(aux_3550))->approx);
				    }
				    return (obj_t) (aux_3549);
				 }
			      }
			    else
			      {
				 {
				    obj_t l2083_2911;
				    {
				       sfun_t obj_3340;
				       obj_3340 = (sfun_t) (value_2907);
				       l2083_2911 = (((sfun_t) CREF(obj_3340))->args);
				    }
				  lname2084_2912:
				    if (PAIRP(l2083_2911))
				      {
					 {
					    value_t val_2916;
					    {
					       local_t obj_3343;
					       {
						  obj_t aux_3558;
						  aux_3558 = CAR(l2083_2911);
						  obj_3343 = (local_t) (aux_3558);
					       }
					       val_2916 = (((local_t) CREF(obj_3343))->value);
					    }
					    {
					       bool_t test_3562;
					       {
						  svar_cinfo_166_t obj_3344;
						  obj_3344 = (svar_cinfo_166_t) (val_2916);
						  {
						     obj_t aux_3564;
						     {
							object_t aux_3565;
							aux_3565 = (object_t) (obj_3344);
							aux_3564 = OBJECT_WIDENING(aux_3565);
						     }
						     test_3562 = (((svar_cinfo_166_t) CREF(aux_3564))->clo_env__87);
						  }
					       }
					       if (test_3562)
						 {
						    BUNSPEC;
						 }
					       else
						 {
						    approx_t aux_3569;
						    {
						       svar_cinfo_166_t obj_3345;
						       obj_3345 = (svar_cinfo_166_t) (val_2916);
						       {
							  obj_t aux_3571;
							  {
							     object_t aux_3572;
							     aux_3572 = (object_t) (obj_3345);
							     aux_3571 = OBJECT_WIDENING(aux_3572);
							  }
							  aux_3569 = (((svar_cinfo_166_t) CREF(aux_3571))->approx);
						       }
						    }
						    approx_set_top__187_cfa_approx(aux_3569);
						 }
					    }
					 }
					 {
					    obj_t l2083_3577;
					    l2083_3577 = CDR(l2083_2911);
					    l2083_2911 = l2083_3577;
					    goto lname2084_2912;
					 }
				      }
				    else
				      {
					 ((bool_t) 1);
				      }
				 }
				 {
				    approx_t arg2384_2920;
				    obj_t arg2385_2921;
				    arg2384_2920 = cfa_intern_sfun__162_cfa_iterate(value_2907, owner_4);
				    arg2385_2921 = CNST_TABLE_REF(((long) 1));
				    {
				       approx_t aux_3583;
				       aux_3583 = loose__226_cfa_loose(arg2384_2920, arg2385_2921);
				       return (obj_t) (aux_3583);
				    }
				 }
			      }
			 }
		      }
		      break;
		   default:
		    case_else2367_2897:
		      if (PROCEDUREP(method2361_2893))
			{
			   return PROCEDURE_ENTRY(method2361_2893) (method2361_2893, (obj_t) (value_3), owner_4, BEOA);
			}
		      else
			{
			   obj_t fun2358_2887;
			   fun2358_2887 = PROCEDURE_REF(cfa_export_var__env_209_cfa_iterate, ((long) 0));
			   return PROCEDURE_ENTRY(fun2358_2887) (fun2358_2887, (obj_t) (value_3), owner_4, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2367_2897;
	      }
	 }
      }
   }
}


/* _cfa-export-var!2396 */ obj_t 
_cfa_export_var_2396_236_cfa_iterate(obj_t env_3362, obj_t value_3363, obj_t owner_3364)
{
   return cfa_export_var__93_cfa_iterate((value_t) (value_3363), owner_3364);
}


/* cfa-export-var!-default2087 */ obj_t 
cfa_export_var__default2087_129_cfa_iterate(value_t value_5, obj_t owner_6)
{
   FAILURE(CNST_TABLE_REF(((long) 2)), string2397_cfa_iterate, (obj_t) (value_5));
}


/* _cfa-export-var!-default2087 */ obj_t 
_cfa_export_var__default2087_48_cfa_iterate(obj_t env_3365, obj_t value_3366, obj_t owner_3367)
{
   return cfa_export_var__default2087_129_cfa_iterate((value_t) (value_3366), owner_3367);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_iterate()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_ITERATE");
   module_initialization_70_tools_shape(((long) 0), "CFA_ITERATE");
   module_initialization_70_type_type(((long) 0), "CFA_ITERATE");
   module_initialization_70_ast_var(((long) 0), "CFA_ITERATE");
   module_initialization_70_ast_node(((long) 0), "CFA_ITERATE");
   module_initialization_70_ast_unit(((long) 0), "CFA_ITERATE");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_ITERATE");
   module_initialization_70_cfa_info(((long) 0), "CFA_ITERATE");
   module_initialization_70_cfa_loose(((long) 0), "CFA_ITERATE");
   return module_initialization_70_cfa_approx(((long) 0), "CFA_ITERATE");
}
