/*===========================================================================*/
/*   (Read/reader.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t _reader_reset__157___reader(obj_t);
extern bool_t bigloo_strcmp(obj_t, obj_t);
extern bool_t reset_eof(obj_t);
extern obj_t string_to_symbol(char *);
extern long rgc_buffer_fixnum(obj_t);
static obj_t _vector_errors__150___reader = BUNSPEC;
extern obj_t rgc_buffer_substring(obj_t, int, int);
static obj_t _read_case_sensitive_11___reader(obj_t, obj_t);
obj_t bigloo_case_sensitive = BUNSPEC;
extern obj_t make_real(double);
static obj_t _dot_symbol__168___reader = BUNSPEC;
static obj_t _list_errors__215___reader = BUNSPEC;
static obj_t toplevel_init_63___reader();
extern obj_t string__llong_61___r4_numbers_6_5_fixnum(char *, obj_t);
extern obj_t rgc_buffer_keyword(obj_t);
extern obj_t create_vector(long);
extern obj_t escape_C_string(char *);
extern bool_t rgc_fill_buffer(obj_t);
static obj_t symbol3454___reader = BUNSPEC;
static obj_t symbol3453___reader = BUNSPEC;
static obj_t symbol3452___reader = BUNSPEC;
static obj_t symbol3451___reader = BUNSPEC;
static obj_t symbol3448___reader = BUNSPEC;
static obj_t symbol3447___reader = BUNSPEC;
static obj_t symbol3445___reader = BUNSPEC;
static obj_t symbol3444___reader = BUNSPEC;
static obj_t symbol3443___reader = BUNSPEC;
static obj_t symbol3442___reader = BUNSPEC;
static obj_t symbol3441___reader = BUNSPEC;
static obj_t symbol3436___reader = BUNSPEC;
static obj_t symbol3433___reader = BUNSPEC;
extern obj_t string_to_bstring(char *);
extern obj_t current_input_port;
extern ucs2_t integer__ucs2_47___ucs2(long);
static obj_t lambda1238___reader(obj_t, obj_t);
extern obj_t rgc_buffer_symbol(obj_t);
static obj_t _read___reader(obj_t, obj_t);
extern obj_t read_case_insensitive_39___reader(obj_t);
static obj_t ignore___reader(obj_t, obj_t);
static bool_t _position___179___reader;
static obj_t loop_tvector_229___reader(long, obj_t, obj_t, obj_t);
extern obj_t illegal_char_rep_197___r4_output_6_10_3(unsigned char);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t the_substring_151___reader(obj_t, long, obj_t);
extern obj_t escape_scheme_string(char *);
extern obj_t read_case_sensitive_72___reader(obj_t);
extern obj_t string__elong_120___r4_numbers_6_5_fixnum(char *, obj_t);
extern obj_t utf8_string_to_ucs2_string(obj_t);
extern double rgc_buffer_flonum(obj_t);
extern obj_t error_location_112___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static long _bra_open__30___reader;
static obj_t read_case_154___reader(obj_t, obj_t);
static obj_t loop_pair_11___reader(obj_t, obj_t, long, obj_t, int, obj_t);
static obj_t _read_case_insensitive_175___reader(obj_t, obj_t);
static long _list_error_level__27___reader;
extern obj_t read___reader(obj_t);
static obj_t handling_function3103___reader(obj_t);
static obj_t loop_struct_160___reader(long, obj_t, obj_t, obj_t);
static obj_t _line_number__80___reader = BUNSPEC;
extern long string__integer_39___r4_numbers_6_5_fixnum(char *, obj_t);
obj_t _bigloo_interpreter__95___reader = BUNSPEC;
extern obj_t string_upcase__158___r4_strings_6_7(obj_t);
static obj_t imported_modules_init_94___reader();
static obj_t _bigloo_grammar__71___reader = BUNSPEC;
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114___reader = BUNSPEC;
extern obj_t reader_reset__72___reader();
extern obj_t list__tvector_27___tvector(obj_t, obj_t);
static obj_t cnst_init_137___reader();
static long _par_open__203___reader;
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_STRING( string3464___reader, string3464___reader3466, "type `input-port' expected", 26 );
DEFINE_STRING( string3463___reader, string3463___reader3467, "Illegal range", 13 );
DEFINE_STRING( string3462___reader, string3462___reader3468, "the-substring", 13 );
DEFINE_STRING( string3461___reader, string3461___reader3469, "Illegal match", 13 );
DEFINE_STRING( string3459___reader, string3459___reader3470, "#!key", 5 );
DEFINE_STRING( string3460___reader, string3460___reader3471, "regular-grammar", 15 );
DEFINE_STRING( string3458___reader, string3458___reader3472, "#!rest", 6 );
DEFINE_STRING( string3457___reader, string3457___reader3473, "#!optional", 10 );
DEFINE_STRING( string3456___reader, string3456___reader3474, "Illegal ascii character", 23 );
DEFINE_STRING( string3455___reader, string3455___reader3475, "Illegal character", 17 );
DEFINE_STRING( string3449___reader, string3449___reader3476, "Illegal identifier", 18 );
DEFINE_STRING( string3450___reader, string3450___reader3477, "Illegal token", 13 );
DEFINE_STRING( string3446___reader, string3446___reader3478, "Illegal constant", 16 );
DEFINE_STRING( string3439___reader, string3439___reader3479, "Unclosed vector or structure", 28 );
DEFINE_STRING( string3440___reader, string3440___reader3480, "Illegal char", 12 );
DEFINE_STRING( string3438___reader, string3438___reader3481, "Unexpected end-of-file", 22 );
DEFINE_STRING( string3437___reader, string3437___reader3482, "Unclosed list", 13 );
DEFINE_STRING( string3435___reader, string3435___reader3483, "Illegal pair", 12 );
DEFINE_STRING( string3434___reader, string3434___reader3484, "read", 4 );
DEFINE_STRING( string3432___reader, string3432___reader3485, ";", 1 );
DEFINE_EXPORT_PROCEDURE( read_case_insensitive_env_230___reader, _read_case_insensitive_175___reader3486, va_generic_entry, _read_case_insensitive_175___reader, -1 );
DEFINE_EXPORT_PROCEDURE( reader_reset__env_13___reader, _reader_reset__157___reader3487, _reader_reset__157___reader, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( read_env_212___reader, _read___reader3488, va_generic_entry, _read___reader, -1 );
DEFINE_EXPORT_PROCEDURE( read_case_sensitive_env_13___reader, _read_case_sensitive_11___reader3489, va_generic_entry, _read_case_sensitive_11___reader, -1 );


/* module-initialization */obj_t module_initialization_70___reader(long checksum_6936, char * from_6937)
{
if(CBOOL(require_initialization_114___reader)){
require_initialization_114___reader = BBOOL(((bool_t)0));
cnst_init_137___reader();
imported_modules_init_94___reader();
toplevel_init_63___reader();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___reader()
{
symbol3433___reader = string_to_symbol("PAIR");
symbol3436___reader = string_to_symbol("AT");
symbol3441___reader = string_to_symbol("_STRUCTURE_");
symbol3442___reader = string_to_symbol("UNQUOTE-SPLICING");
symbol3443___reader = string_to_symbol("UNQUOTE");
symbol3444___reader = string_to_symbol("QUASIQUOTE");
symbol3445___reader = string_to_symbol("QUOTE");
symbol3447___reader = string_to_symbol("UNSPECIFIED");
symbol3448___reader = string_to_symbol("EOF-OBJECT");
symbol3451___reader = string_to_symbol("NEWLINE");
symbol3452___reader = string_to_symbol("TAB");
symbol3453___reader = string_to_symbol("SPACE");
return (symbol3454___reader = string_to_symbol("RETURN"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___reader()
{
BUNSPEC;
_bigloo_interpreter__95___reader = BFALSE;
_par_open__203___reader = ((long)0);
_bra_open__30___reader = ((long)0);
_list_error_level__27___reader = ((long)20);
_list_errors__215___reader = make_vector(((long)20), BUNSPEC);
_vector_errors__150___reader = make_vector(((long)20), BUNSPEC);
_position___179___reader = ((bool_t)0);
_line_number__80___reader = BINT(((long)1));
{
char * aux_6960;
aux_6960 = BSTRING_TO_STRING(string3432___reader);
_dot_symbol__168___reader = string_to_symbol(aux_6960);
}
{
obj_t the_rgc_context_46_430;
the_rgc_context_46_430 = MAKE_CELL(BUNSPEC);
{
obj_t lambda1238_6904;
lambda1238_6904 = make_fx_procedure(lambda1238___reader, ((long)1), ((long)1));
PROCEDURE_SET(lambda1238_6904, ((long)0), the_rgc_context_46_430);
return (_bigloo_grammar__71___reader = lambda1238_6904,
BUNSPEC);
}
}
}


/* lambda1238 */obj_t lambda1238___reader(obj_t env_6905, obj_t input_port_219_6907)
{
{
obj_t the_rgc_context_46_6906;
the_rgc_context_46_6906 = PROCEDURE_REF(env_6905, ((long)0));
{
obj_t input_port_219_431;
input_port_219_431 = input_port_219_6907;
return ignore___reader(the_rgc_context_46_6906, input_port_219_431);
}
}
}


/* loop-struct */obj_t loop_struct_160___reader(long open_key_66_6926, obj_t the_rgc_context_46_6925, obj_t input_port_219_6924, obj_t walk_3081)
{
{
bool_t test1285_3085;
{
long n2_3089;
n2_3089 = _bra_open__30___reader;
test1285_3085 = (open_key_66_6926==n2_3089);
}
if(test1285_3085){
return BNIL;
}
 else {
{
obj_t arg1286_3086;
{
obj_t arg1287_3087;
arg1287_3087 = ignore___reader(the_rgc_context_46_6925, input_port_219_6924);
arg1286_3086 = loop_struct_160___reader(open_key_66_6926, the_rgc_context_46_6925, input_port_219_6924, arg1287_3087);
}
return MAKE_PAIR(walk_3081, arg1286_3086);
}
}
}
}


/* loop-tvector */obj_t loop_tvector_229___reader(long open_key_66_6929, obj_t the_rgc_context_46_6928, obj_t input_port_219_6927, obj_t walk_3126)
{
{
bool_t test1295_3130;
{
long n2_3134;
n2_3134 = _par_open__203___reader;
test1295_3130 = (open_key_66_6929==n2_3134);
}
if(test1295_3130){
return BNIL;
}
 else {
{
obj_t arg1296_3131;
{
obj_t arg1297_3132;
arg1297_3132 = ignore___reader(the_rgc_context_46_6928, input_port_219_6927);
arg1296_3131 = loop_tvector_229___reader(open_key_66_6929, the_rgc_context_46_6928, input_port_219_6927, arg1297_3132);
}
return MAKE_PAIR(walk_3126, arg1296_3131);
}
}
}
}


/* loop-pair */obj_t loop_pair_11___reader(obj_t the_rgc_context_46_6932, obj_t input_port_219_6931, long open_key_66_6930, obj_t walk_651, int pos_652, obj_t line_653)
{
if((walk_651==_dot_symbol__168___reader)){
CELL_SET(the_rgc_context_46_6932, BUNSPEC);
{
obj_t cdr_657;
cdr_657 = ignore___reader(the_rgc_context_46_6932, input_port_219_6931);
ignore___reader(the_rgc_context_46_6932, input_port_219_6931);
{
bool_t test1334_658;
{
long n2_3241;
n2_3241 = _par_open__203___reader;
test1334_658 = (open_key_66_6930==n2_3241);
}
if(test1334_658){
{
obj_t list3083_2826;
list3083_2826 = MAKE_PAIR(symbol3433___reader, BNIL);
CELL_SET(the_rgc_context_46_6932, CAR(list3083_2826));
}
return cdr_657;
}
 else {
char * arg1342_662;
int arg1343_663;
arg1342_662 = INPUT_PORT_NAME(input_port_219_6931);
{
int res3290_3250;
{
long aux_6986;
aux_6986 = INPUT_PORT_FILEPOS(input_port_219_6931);
res3290_3250 = (int)(aux_6986);
}
arg1343_663 = res3290_3250;
}
return error_location_112___error(string3434___reader, string3435___reader, cdr_657, string_to_bstring(arg1342_662), BINT(arg1343_663));
}
}
}
}
 else {
bool_t test1346_666;
{
long n2_3252;
n2_3252 = _par_open__203___reader;
test1346_666 = (open_key_66_6930==n2_3252);
}
if(test1346_666){
if((open_key_66_6930==((long)0))){
CELL_SET(the_rgc_context_46_6932, BUNSPEC);
}
 else {
BUNSPEC;
}
return BNIL;
}
 else {
{
int new_pos_98_668;
obj_t new_line_171_669;
{
int res3292_3261;
{
long aux_6996;
aux_6996 = INPUT_PORT_FILEPOS(input_port_219_6931);
res3292_3261 = (int)(aux_6996);
}
new_pos_98_668 = res3292_3261;
}
new_line_171_669 = _line_number__80___reader;
if(_position___179___reader){
obj_t arg1349_670;
obj_t arg1350_671;
{
obj_t arg1351_672;
arg1351_672 = ignore___reader(the_rgc_context_46_6932, input_port_219_6931);
arg1349_670 = loop_pair_11___reader(the_rgc_context_46_6932, input_port_219_6931, open_key_66_6930, arg1351_672, new_pos_98_668, new_line_171_669);
}
{
obj_t arg1352_673;
char * arg1353_674;
arg1352_673 = symbol3436___reader;
arg1353_674 = INPUT_PORT_NAME(input_port_219_6931);
{
obj_t list1354_675;
{
obj_t arg1355_676;
{
obj_t arg1356_677;
{
obj_t arg1357_678;
arg1357_678 = MAKE_PAIR(line_653, BNIL);
{
obj_t aux_7004;
aux_7004 = BINT(pos_652);
arg1356_677 = MAKE_PAIR(aux_7004, arg1357_678);
}
}
{
obj_t aux_7007;
aux_7007 = string_to_bstring(arg1353_674);
arg1355_676 = MAKE_PAIR(aux_7007, arg1356_677);
}
}
list1354_675 = MAKE_PAIR(arg1352_673, arg1355_676);
}
arg1350_671 = list1354_675;
}
}
return MAKE_EXTENDED_PAIR(walk_651, arg1349_670, arg1350_671);
}
 else {
obj_t arg1364_681;
{
obj_t arg1365_682;
arg1365_682 = ignore___reader(the_rgc_context_46_6932, input_port_219_6931);
arg1364_681 = loop_pair_11___reader(the_rgc_context_46_6932, input_port_219_6931, open_key_66_6930, arg1365_682, new_pos_98_668, new_line_171_669);
}
return MAKE_PAIR(walk_651, arg1364_681);
}
}
}
}
}


/* ignore */obj_t ignore___reader(obj_t the_rgc_context_46_6934, obj_t input_port_219_6933)
{
ignore___reader:
{
long last_match_133_928;
long last_match_133_943;
long last_match_133_967;
long last_match_133_987;
long last_match_133_1002;
long last_match_133_1017;
long last_match_133_1037;
long last_match_133_1053;
long last_match_133_1069;
long last_match_133_1085;
long last_match_133_1092;
long last_match_133_1111;
long last_match_133_1131;
long last_match_133_1147;
long last_match_133_1172;
long last_match_133_1179;
long last_match_133_1186;
long last_match_133_1229;
long last_match_133_1276;
long last_match_133_1305;
long last_match_133_1352;
long last_match_133_1368;
long last_match_133_1397;
long last_match_133_1420;
long last_match_133_1439;
long last_match_133_1461;
long last_match_133_1491;
long last_match_133_1515;
long last_match_133_1531;
long last_match_133_1554;
long last_match_133_1587;
long last_match_133_1616;
long last_match_133_1635;
long last_match_133_1660;
long last_match_133_1676;
long last_match_133_1686;
long last_match_133_1712;
long last_match_133_1738;
long last_match_133_1762;
long last_match_133_1772;
long last_match_133_1790;
long last_match_133_1820;
long last_match_133_1840;
long last_match_133_1848;
long last_match_133_1870;
long last_match_133_1878;
long last_match_133_1903;
long last_match_133_1923;
long last_match_133_1945;
long last_match_133_1974;
long last_match_133_1993;
long last_match_133_2043;
long last_match_133_2090;
long last_match_133_2128;
long last_match_133_2166;
long last_match_133_2211;
long last_match_133_2218;
long last_match_133_2236;
long last_match_133_2247;
long last_match_133_2254;
long last_match_133_2281;
long last_match_133_2306;
long last_match_133_2322;
long last_match_133_2330;
long last_match_133_2348;
long last_match_133_2373;
long last_match_133_2391;
long last_match_133_2411;
long last_match_133_2429;
long last_match_133_2449;
long last_match_133_2456;
long last_match_133_2479;
long last_match_133_2510;
long last_match_133_2539;
long last_match_133_2562;
long last_match_133_2597;
long last_match_133_2604;
long last_match_133_2636;
long last_match_133_2656;
long last_match_133_2694;
long last_match_133_2704;
RGC_START_MATCH(input_port_219_6933);
{
int match_545;
{
long aux_7016;
last_match_133_1870 = ((long)38);
state_0_1002_0_2763:
{
int current_char_37_1872;
current_char_37_1872 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
switch ((long)(current_char_37_1872)){
case ((long)125) : 
{
long new_match_93_5313;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5313 = ((long)37);
aux_7016 = new_match_93_5313;
}
break;
case ((long)96) : 
{
long new_match_93_5316;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5316 = ((long)29);
aux_7016 = new_match_93_5316;
}
break;
case ((long)59) : 
last_match_133_2306 = last_match_133_1870;
state_15_1017_14_2742:
{
long new_match_93_2308;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2308 = ((long)2);
{
int current_char_37_2309;
current_char_37_2309 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7022;
{
long aux_7023;
aux_7023 = (long)(current_char_37_2309);
test_7022 = (aux_7023==((long)0));
}
if(test_7022){
{
bool_t test2781_2311;
test2781_2311 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(test2781_2311){
bool_t test2782_2312;
test2782_2312 = rgc_fill_buffer(input_port_219_6933);
if(test2782_2312){
goto state_15_1017_14_2742;
}
 else {
aux_7016 = new_match_93_2308;
}
}
 else {
last_match_133_2322 = new_match_93_2308;
state_19_1021_169_2738:
{
long new_match_93_2324;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2324 = ((long)2);
{
int current_char_37_2325;
current_char_37_2325 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7032;
{
long aux_7033;
aux_7033 = (long)(current_char_37_2325);
test_7032 = (aux_7033==((long)0));
}
if(test_7032){
{
bool_t test2789_2327;
test2789_2327 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(test2789_2327){
bool_t test2790_2328;
test2790_2328 = rgc_fill_buffer(input_port_219_6933);
if(test2790_2328){
goto state_19_1021_169_2738;
}
 else {
aux_7016 = new_match_93_2324;
}
}
 else {
long last_match_133_7040;
last_match_133_7040 = new_match_93_2324;
last_match_133_2322 = last_match_133_7040;
goto state_19_1021_169_2738;
}
}
}
 else {
bool_t test_7041;
{
long aux_7042;
aux_7042 = (long)(current_char_37_2325);
test_7041 = (aux_7042==((long)10));
}
if(test_7041){
aux_7016 = new_match_93_2324;
}
 else {
{
long last_match_133_7045;
last_match_133_7045 = new_match_93_2324;
last_match_133_2322 = last_match_133_7045;
goto state_19_1021_169_2738;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7046;
{
long aux_7047;
aux_7047 = (long)(current_char_37_2309);
test_7046 = (aux_7047==((long)10));
}
if(test_7046){
aux_7016 = new_match_93_2308;
}
 else {
{
long last_match_133_7050;
last_match_133_7050 = new_match_93_2308;
last_match_133_2322 = last_match_133_7050;
goto state_19_1021_169_2738;
}
}
}
}
}
}
break;
case ((long)58) : 
last_match_133_2281 = last_match_133_1870;
state_14_1016_254_2743:
{
long new_match_93_2283;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2283 = ((long)27);
{
int current_char_37_2284;
current_char_37_2284 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7053;
{
long aux_7054;
aux_7054 = (long)(current_char_37_2284);
test_7053 = (aux_7054==((long)0));
}
if(test_7053){
{
bool_t test2763_2286;
{
bool_t res3413_6111;
{
bool_t _andtest_1237_6108;
_andtest_1237_6108 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6108){
res3413_6111 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3413_6111 = ((bool_t)0);
}
}
test2763_2286 = res3413_6111;
}
if(test2763_2286){
goto state_14_1016_254_2743;
}
 else {
aux_7016 = new_match_93_2283;
}
}
}
 else {
bool_t test_7061;
{
bool_t test_7062;
{
long aux_7063;
aux_7063 = (long)(current_char_37_2284);
test_7062 = (aux_7063>=((long)48));
}
if(test_7062){
long aux_7066;
aux_7066 = (long)(current_char_37_2284);
test_7061 = (aux_7066<((long)58));
}
 else {
test_7061 = ((bool_t)0);
}
}
if(test_7061){
last_match_133_2348 = new_match_93_2283;
state_22_1024_168_2736:
{
long new_match_93_2350;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2350 = ((long)27);
{
int current_char_37_2351;
current_char_37_2351 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7071;
{
long aux_7072;
aux_7072 = (long)(current_char_37_2351);
test_7071 = (aux_7072==((long)0));
}
if(test_7071){
{
bool_t test2807_2353;
{
bool_t res3415_6205;
{
bool_t _andtest_1237_6202;
_andtest_1237_6202 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6202){
res3415_6205 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3415_6205 = ((bool_t)0);
}
}
test2807_2353 = res3415_6205;
}
if(test2807_2353){
goto state_22_1024_168_2736;
}
 else {
aux_7016 = new_match_93_2350;
}
}
}
 else {
bool_t test_7079;
{
bool_t test_7080;
{
long aux_7081;
aux_7081 = (long)(current_char_37_2351);
test_7080 = (aux_7081>=((long)48));
}
if(test_7080){
long aux_7084;
aux_7084 = (long)(current_char_37_2351);
test_7079 = (aux_7084<((long)58));
}
 else {
test_7079 = ((bool_t)0);
}
}
if(test_7079){
{
long last_match_133_7087;
last_match_133_7087 = new_match_93_2350;
last_match_133_2348 = last_match_133_7087;
goto state_22_1024_168_2736;
}
}
 else {
bool_t test_7088;
switch ((long)(current_char_37_2351)){
case ((long)39) : 
test_7088 = ((bool_t)1);
break;
case ((long)44) : 
test_7088 = ((bool_t)1);
break;
case ((long)58) : 
test_7088 = ((bool_t)1);
break;
default: 
{
long aux_7089;
aux_7089 = (long)(current_char_37_2351);
test_7088 = (aux_7089==((long)96));
}
}
if(test_7088){
last_match_133_928 = new_match_93_2350;
state_21_1023_217_2808:
{
long new_match_93_930;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_930 = ((long)27);
{
int current_char_37_931;
current_char_37_931 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7096;
{
long aux_7097;
aux_7097 = (long)(current_char_37_931);
test_7096 = (aux_7097==((long)0));
}
if(test_7096){
{
bool_t test1669_933;
{
bool_t res3357_3541;
{
bool_t _andtest_1237_3538;
_andtest_1237_3538 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3538){
res3357_3541 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3357_3541 = ((bool_t)0);
}
}
test1669_933 = res3357_3541;
}
if(test1669_933){
goto state_21_1023_217_2808;
}
 else {
aux_7016 = new_match_93_930;
}
}
}
 else {
bool_t test_7104;
{
bool_t test_7105;
{
long aux_7106;
aux_7106 = (long)(current_char_37_931);
test_7105 = (aux_7106<((long)33));
}
if(test_7105){
test_7104 = ((bool_t)1);
}
 else {
bool_t test_7109;
{
bool_t test_7110;
{
long aux_7111;
aux_7111 = (long)(current_char_37_931);
test_7110 = (aux_7111==((long)35));
}
if(test_7110){
test_7109 = ((bool_t)1);
}
 else {
long aux_7114;
aux_7114 = (long)(current_char_37_931);
test_7109 = (aux_7114==((long)34));
}
}
if(test_7109){
test_7104 = ((bool_t)1);
}
 else {
bool_t test_7117;
{
bool_t test_7118;
{
long aux_7119;
aux_7119 = (long)(current_char_37_931);
test_7118 = (aux_7119==((long)41));
}
if(test_7118){
test_7117 = ((bool_t)1);
}
 else {
long aux_7122;
aux_7122 = (long)(current_char_37_931);
test_7117 = (aux_7122==((long)40));
}
}
if(test_7117){
test_7104 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_931)){
case ((long)59) : 
test_7104 = ((bool_t)1);
break;
case ((long)91) : 
test_7104 = ((bool_t)1);
break;
case ((long)93) : 
test_7104 = ((bool_t)1);
break;
case ((long)123) : 
test_7104 = ((bool_t)1);
break;
case ((long)125) : 
test_7104 = ((bool_t)1);
break;
default: 
{
long aux_7125;
aux_7125 = (long)(current_char_37_931);
test_7104 = (aux_7125==((long)127));
}
}
}
}
}
}
if(test_7104){
aux_7016 = new_match_93_930;
}
 else {
{
long last_match_133_7130;
last_match_133_7130 = new_match_93_930;
last_match_133_928 = last_match_133_7130;
goto state_21_1023_217_2808;
}
}
}
}
}
}
}
 else {
bool_t test_7131;
{
bool_t test_7132;
{
long aux_7133;
aux_7133 = (long)(current_char_37_2351);
test_7132 = (aux_7133<((long)33));
}
if(test_7132){
test_7131 = ((bool_t)1);
}
 else {
bool_t test_7136;
{
bool_t test_7137;
{
long aux_7138;
aux_7138 = (long)(current_char_37_2351);
test_7137 = (aux_7138==((long)35));
}
if(test_7137){
test_7136 = ((bool_t)1);
}
 else {
long aux_7141;
aux_7141 = (long)(current_char_37_2351);
test_7136 = (aux_7141==((long)34));
}
}
if(test_7136){
test_7131 = ((bool_t)1);
}
 else {
bool_t test_7144;
{
bool_t test_7145;
{
long aux_7146;
aux_7146 = (long)(current_char_37_2351);
test_7145 = (aux_7146==((long)41));
}
if(test_7145){
test_7144 = ((bool_t)1);
}
 else {
bool_t test_7149;
{
long aux_7150;
aux_7150 = (long)(current_char_37_2351);
test_7149 = (aux_7150==((long)40));
}
if(test_7149){
test_7144 = ((bool_t)1);
}
 else {
long aux_7153;
aux_7153 = (long)(current_char_37_2351);
test_7144 = (aux_7153==((long)39));
}
}
}
if(test_7144){
test_7131 = ((bool_t)1);
}
 else {
bool_t test_7156;
{
long aux_7157;
aux_7157 = (long)(current_char_37_2351);
test_7156 = (aux_7157==((long)44));
}
if(test_7156){
test_7131 = ((bool_t)1);
}
 else {
bool_t test_7160;
{
bool_t test_7161;
{
long aux_7162;
aux_7162 = (long)(current_char_37_2351);
test_7161 = (aux_7162>=((long)48));
}
if(test_7161){
long aux_7165;
aux_7165 = (long)(current_char_37_2351);
test_7160 = (aux_7165<((long)60));
}
 else {
test_7160 = ((bool_t)0);
}
}
if(test_7160){
test_7131 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2351)){
case ((long)91) : 
test_7131 = ((bool_t)1);
break;
case ((long)93) : 
test_7131 = ((bool_t)1);
break;
case ((long)96) : 
test_7131 = ((bool_t)1);
break;
case ((long)123) : 
test_7131 = ((bool_t)1);
break;
case ((long)125) : 
test_7131 = ((bool_t)1);
break;
default: 
{
long aux_7168;
aux_7168 = (long)(current_char_37_2351);
test_7131 = (aux_7168==((long)127));
}
}
}
}
}
}
}
}
if(test_7131){
aux_7016 = new_match_93_2350;
}
 else {
last_match_133_2330 = new_match_93_2350;
state_20_1022_44_2737:
{
long new_match_93_2332;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2332 = ((long)26);
{
int current_char_37_2333;
current_char_37_2333 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7175;
{
long aux_7176;
aux_7176 = (long)(current_char_37_2333);
test_7175 = (aux_7176==((long)0));
}
if(test_7175){
{
bool_t test2794_2335;
{
bool_t res3414_6174;
{
bool_t _andtest_1237_6171;
_andtest_1237_6171 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6171){
res3414_6174 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3414_6174 = ((bool_t)0);
}
}
test2794_2335 = res3414_6174;
}
if(test2794_2335){
goto state_20_1022_44_2737;
}
 else {
aux_7016 = new_match_93_2332;
}
}
}
 else {
bool_t test2795_2336;
{
long aux_7183;
aux_7183 = (long)(current_char_37_2333);
test2795_2336 = (aux_7183==((long)58));
}
if(test2795_2336){
{
long last_match_133_7187;
last_match_133_7187 = new_match_93_2332;
last_match_133_928 = last_match_133_7187;
goto state_21_1023_217_2808;
}
}
 else {
bool_t test_7188;
{
bool_t test_7189;
{
long aux_7190;
aux_7190 = (long)(current_char_37_2333);
test_7189 = (aux_7190<((long)33));
}
if(test_7189){
test_7188 = ((bool_t)1);
}
 else {
bool_t test_7193;
{
bool_t test_7194;
{
long aux_7195;
aux_7195 = (long)(current_char_37_2333);
test_7194 = (aux_7195==((long)35));
}
if(test_7194){
test_7193 = ((bool_t)1);
}
 else {
long aux_7198;
aux_7198 = (long)(current_char_37_2333);
test_7193 = (aux_7198==((long)34));
}
}
if(test_7193){
test_7188 = ((bool_t)1);
}
 else {
bool_t test_7201;
{
bool_t test_7202;
{
long aux_7203;
aux_7203 = (long)(current_char_37_2333);
test_7202 = (aux_7203==((long)41));
}
if(test_7202){
test_7201 = ((bool_t)1);
}
 else {
long aux_7206;
aux_7206 = (long)(current_char_37_2333);
test_7201 = (aux_7206==((long)40));
}
}
if(test_7201){
test_7188 = ((bool_t)1);
}
 else {
bool_t test_7209;
{
bool_t test_7210;
{
long aux_7211;
aux_7211 = (long)(current_char_37_2333);
test_7210 = (aux_7211==((long)59));
}
if(test_7210){
test_7209 = ((bool_t)1);
}
 else {
test_7209 = test2795_2336;
}
}
if(test_7209){
test_7188 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2333)){
case ((long)91) : 
test_7188 = ((bool_t)1);
break;
case ((long)93) : 
test_7188 = ((bool_t)1);
break;
case ((long)123) : 
test_7188 = ((bool_t)1);
break;
case ((long)125) : 
test_7188 = ((bool_t)1);
break;
default: 
{
long aux_7214;
aux_7214 = (long)(current_char_37_2333);
test_7188 = (aux_7214==((long)127));
}
}
}
}
}
}
}
if(test_7188){
aux_7016 = new_match_93_2332;
}
 else {
{
long last_match_133_7219;
last_match_133_7219 = new_match_93_2332;
last_match_133_2330 = last_match_133_7219;
goto state_20_1022_44_2737;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7220;
switch ((long)(current_char_37_2284)){
case ((long)39) : 
test_7220 = ((bool_t)1);
break;
case ((long)44) : 
test_7220 = ((bool_t)1);
break;
case ((long)58) : 
test_7220 = ((bool_t)1);
break;
default: 
{
long aux_7221;
aux_7221 = (long)(current_char_37_2284);
test_7220 = (aux_7221==((long)96));
}
}
if(test_7220){
{
long last_match_133_7226;
last_match_133_7226 = new_match_93_2283;
last_match_133_928 = last_match_133_7226;
goto state_21_1023_217_2808;
}
}
 else {
bool_t test_7227;
{
bool_t test_7228;
{
long aux_7229;
aux_7229 = (long)(current_char_37_2284);
test_7228 = (aux_7229<((long)33));
}
if(test_7228){
test_7227 = ((bool_t)1);
}
 else {
bool_t test_7232;
{
bool_t test_7233;
{
long aux_7234;
aux_7234 = (long)(current_char_37_2284);
test_7233 = (aux_7234==((long)35));
}
if(test_7233){
test_7232 = ((bool_t)1);
}
 else {
long aux_7237;
aux_7237 = (long)(current_char_37_2284);
test_7232 = (aux_7237==((long)34));
}
}
if(test_7232){
test_7227 = ((bool_t)1);
}
 else {
bool_t test_7240;
{
bool_t test_7241;
{
long aux_7242;
aux_7242 = (long)(current_char_37_2284);
test_7241 = (aux_7242==((long)41));
}
if(test_7241){
test_7240 = ((bool_t)1);
}
 else {
bool_t test_7245;
{
long aux_7246;
aux_7246 = (long)(current_char_37_2284);
test_7245 = (aux_7246==((long)40));
}
if(test_7245){
test_7240 = ((bool_t)1);
}
 else {
long aux_7249;
aux_7249 = (long)(current_char_37_2284);
test_7240 = (aux_7249==((long)39));
}
}
}
if(test_7240){
test_7227 = ((bool_t)1);
}
 else {
bool_t test_7252;
{
long aux_7253;
aux_7253 = (long)(current_char_37_2284);
test_7252 = (aux_7253==((long)44));
}
if(test_7252){
test_7227 = ((bool_t)1);
}
 else {
bool_t test_7256;
{
bool_t test_7257;
{
long aux_7258;
aux_7258 = (long)(current_char_37_2284);
test_7257 = (aux_7258>=((long)48));
}
if(test_7257){
long aux_7261;
aux_7261 = (long)(current_char_37_2284);
test_7256 = (aux_7261<((long)60));
}
 else {
test_7256 = ((bool_t)0);
}
}
if(test_7256){
test_7227 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2284)){
case ((long)91) : 
test_7227 = ((bool_t)1);
break;
case ((long)93) : 
test_7227 = ((bool_t)1);
break;
case ((long)96) : 
test_7227 = ((bool_t)1);
break;
case ((long)123) : 
test_7227 = ((bool_t)1);
break;
case ((long)125) : 
test_7227 = ((bool_t)1);
break;
default: 
{
long aux_7264;
aux_7264 = (long)(current_char_37_2284);
test_7227 = (aux_7264==((long)127));
}
}
}
}
}
}
}
}
if(test_7227){
aux_7016 = new_match_93_2283;
}
 else {
{
long last_match_133_7269;
last_match_133_7269 = new_match_93_2283;
last_match_133_2330 = last_match_133_7269;
goto state_20_1022_44_2737;
}
}
}
}
}
}
}
}
break;
case ((long)57) : 
case ((long)56) : 
case ((long)55) : 
case ((long)54) : 
case ((long)53) : 
case ((long)52) : 
case ((long)51) : 
case ((long)50) : 
case ((long)49) : 
case ((long)48) : 
last_match_133_1686 = last_match_133_1870;
state_13_1015_64_2773:
{
long new_match_93_1688;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1688 = ((long)12);
{
int current_char_37_1689;
current_char_37_1689 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7272;
{
long aux_7273;
aux_7273 = (long)(current_char_37_1689);
test_7272 = (aux_7273==((long)0));
}
if(test_7272){
{
bool_t test2285_1691;
{
bool_t res3389_4984;
{
bool_t _andtest_1237_4981;
_andtest_1237_4981 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4981){
res3389_4984 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3389_4984 = ((bool_t)0);
}
}
test2285_1691 = res3389_4984;
}
if(test2285_1691){
goto state_13_1015_64_2773;
}
 else {
aux_7016 = new_match_93_1688;
}
}
}
 else {
bool_t test_7280;
{
bool_t test_7281;
{
long aux_7282;
aux_7282 = (long)(current_char_37_1689);
test_7281 = (aux_7282==((long)69));
}
if(test_7281){
test_7280 = ((bool_t)1);
}
 else {
long aux_7285;
aux_7285 = (long)(current_char_37_1689);
test_7280 = (aux_7285==((long)101));
}
}
if(test_7280){
last_match_133_943 = new_match_93_1688;
state_26_1028_128_2807:
{
long new_match_93_945;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_945 = ((long)27);
{
int current_char_37_946;
current_char_37_946 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7290;
{
long aux_7291;
aux_7291 = (long)(current_char_37_946);
test_7290 = (aux_7291==((long)0));
}
if(test_7290){
{
bool_t test1679_948;
{
bool_t res3358_3566;
{
bool_t _andtest_1237_3563;
_andtest_1237_3563 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3563){
res3358_3566 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3358_3566 = ((bool_t)0);
}
}
test1679_948 = res3358_3566;
}
if(test1679_948){
goto state_26_1028_128_2807;
}
 else {
aux_7016 = new_match_93_945;
}
}
}
 else {
bool_t test_7298;
{
long aux_7299;
aux_7299 = (long)(current_char_37_946);
test_7298 = (aux_7299==((long)58));
}
if(test_7298){
last_match_133_987 = new_match_93_945;
state_29_1031_68_2805:
{
long new_match_93_989;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_989 = ((long)26);
{
int current_char_37_990;
current_char_37_990 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7304;
{
long aux_7305;
aux_7305 = (long)(current_char_37_990);
test_7304 = (aux_7305==((long)0));
}
if(test_7304){
{
bool_t test1713_992;
{
bool_t res3360_3644;
{
bool_t _andtest_1237_3641;
_andtest_1237_3641 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3641){
res3360_3644 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3360_3644 = ((bool_t)0);
}
}
test1713_992 = res3360_3644;
}
if(test1713_992){
goto state_29_1031_68_2805;
}
 else {
aux_7016 = new_match_93_989;
}
}
}
 else {
bool_t test_7312;
{
bool_t test_7313;
{
long aux_7314;
aux_7314 = (long)(current_char_37_990);
test_7313 = (aux_7314<((long)33));
}
if(test_7313){
test_7312 = ((bool_t)1);
}
 else {
bool_t test_7317;
{
bool_t test_7318;
{
long aux_7319;
aux_7319 = (long)(current_char_37_990);
test_7318 = (aux_7319==((long)35));
}
if(test_7318){
test_7317 = ((bool_t)1);
}
 else {
long aux_7322;
aux_7322 = (long)(current_char_37_990);
test_7317 = (aux_7322==((long)34));
}
}
if(test_7317){
test_7312 = ((bool_t)1);
}
 else {
bool_t test_7325;
{
bool_t test_7326;
{
long aux_7327;
aux_7327 = (long)(current_char_37_990);
test_7326 = (aux_7327==((long)41));
}
if(test_7326){
test_7325 = ((bool_t)1);
}
 else {
long aux_7330;
aux_7330 = (long)(current_char_37_990);
test_7325 = (aux_7330==((long)40));
}
}
if(test_7325){
test_7312 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_990)){
case ((long)59) : 
test_7312 = ((bool_t)1);
break;
case ((long)91) : 
test_7312 = ((bool_t)1);
break;
case ((long)93) : 
test_7312 = ((bool_t)1);
break;
case ((long)123) : 
test_7312 = ((bool_t)1);
break;
case ((long)125) : 
test_7312 = ((bool_t)1);
break;
default: 
{
long aux_7333;
aux_7333 = (long)(current_char_37_990);
test_7312 = (aux_7333==((long)127));
}
}
}
}
}
}
if(test_7312){
aux_7016 = new_match_93_989;
}
 else {
{
long last_match_133_7338;
last_match_133_7338 = new_match_93_989;
last_match_133_928 = last_match_133_7338;
goto state_21_1023_217_2808;
}
}
}
}
}
}
}
 else {
bool_t test_7339;
{
bool_t test_7340;
{
long aux_7341;
aux_7341 = (long)(current_char_37_946);
test_7340 = (aux_7341>=((long)48));
}
if(test_7340){
long aux_7344;
aux_7344 = (long)(current_char_37_946);
test_7339 = (aux_7344<((long)58));
}
 else {
test_7339 = ((bool_t)0);
}
}
if(test_7339){
last_match_133_2391 = new_match_93_945;
state_28_1030_70_2734:
{
long new_match_93_2393;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2393 = ((long)18);
{
int current_char_37_2394;
current_char_37_2394 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7349;
{
long aux_7350;
aux_7350 = (long)(current_char_37_2394);
test_7349 = (aux_7350==((long)0));
}
if(test_7349){
{
bool_t test2838_2396;
{
bool_t res3417_6279;
{
bool_t _andtest_1237_6276;
_andtest_1237_6276 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6276){
res3417_6279 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3417_6279 = ((bool_t)0);
}
}
test2838_2396 = res3417_6279;
}
if(test2838_2396){
goto state_28_1030_70_2734;
}
 else {
aux_7016 = new_match_93_2393;
}
}
}
 else {
bool_t test_7357;
{
long aux_7358;
aux_7358 = (long)(current_char_37_2394);
test_7357 = (aux_7358==((long)58));
}
if(test_7357){
{
long last_match_133_7361;
last_match_133_7361 = new_match_93_2393;
last_match_133_987 = last_match_133_7361;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7362;
{
bool_t test_7363;
{
long aux_7364;
aux_7364 = (long)(current_char_37_2394);
test_7363 = (aux_7364>=((long)48));
}
if(test_7363){
long aux_7367;
aux_7367 = (long)(current_char_37_2394);
test_7362 = (aux_7367<((long)58));
}
 else {
test_7362 = ((bool_t)0);
}
}
if(test_7362){
{
long last_match_133_7370;
last_match_133_7370 = new_match_93_2393;
last_match_133_2391 = last_match_133_7370;
goto state_28_1030_70_2734;
}
}
 else {
bool_t test_7371;
{
bool_t test_7372;
{
long aux_7373;
aux_7373 = (long)(current_char_37_2394);
test_7372 = (aux_7373<((long)33));
}
if(test_7372){
test_7371 = ((bool_t)1);
}
 else {
bool_t test_7376;
{
bool_t test_7377;
{
long aux_7378;
aux_7378 = (long)(current_char_37_2394);
test_7377 = (aux_7378==((long)35));
}
if(test_7377){
test_7376 = ((bool_t)1);
}
 else {
long aux_7381;
aux_7381 = (long)(current_char_37_2394);
test_7376 = (aux_7381==((long)34));
}
}
if(test_7376){
test_7371 = ((bool_t)1);
}
 else {
bool_t test_7384;
{
bool_t test_7385;
{
long aux_7386;
aux_7386 = (long)(current_char_37_2394);
test_7385 = (aux_7386==((long)41));
}
if(test_7385){
test_7384 = ((bool_t)1);
}
 else {
long aux_7389;
aux_7389 = (long)(current_char_37_2394);
test_7384 = (aux_7389==((long)40));
}
}
if(test_7384){
test_7371 = ((bool_t)1);
}
 else {
bool_t test_7392;
{
bool_t test_7393;
{
long aux_7394;
aux_7394 = (long)(current_char_37_2394);
test_7393 = (aux_7394>=((long)48));
}
if(test_7393){
long aux_7397;
aux_7397 = (long)(current_char_37_2394);
test_7392 = (aux_7397<((long)60));
}
 else {
test_7392 = ((bool_t)0);
}
}
if(test_7392){
test_7371 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2394)){
case ((long)91) : 
test_7371 = ((bool_t)1);
break;
case ((long)93) : 
test_7371 = ((bool_t)1);
break;
case ((long)123) : 
test_7371 = ((bool_t)1);
break;
case ((long)125) : 
test_7371 = ((bool_t)1);
break;
default: 
{
long aux_7400;
aux_7400 = (long)(current_char_37_2394);
test_7371 = (aux_7400==((long)127));
}
}
}
}
}
}
}
if(test_7371){
aux_7016 = new_match_93_2393;
}
 else {
last_match_133_2373 = new_match_93_2393;
state_23_1025_82_2735:
{
long new_match_93_2375;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2375 = ((long)27);
{
int current_char_37_2376;
current_char_37_2376 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7407;
{
long aux_7408;
aux_7408 = (long)(current_char_37_2376);
test_7407 = (aux_7408==((long)0));
}
if(test_7407){
{
bool_t test2825_2378;
{
bool_t res3416_6248;
{
bool_t _andtest_1237_6245;
_andtest_1237_6245 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6245){
res3416_6248 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3416_6248 = ((bool_t)0);
}
}
test2825_2378 = res3416_6248;
}
if(test2825_2378){
goto state_23_1025_82_2735;
}
 else {
aux_7016 = new_match_93_2375;
}
}
}
 else {
bool_t test2826_2379;
{
long aux_7415;
aux_7415 = (long)(current_char_37_2376);
test2826_2379 = (aux_7415==((long)58));
}
if(test2826_2379){
{
long last_match_133_7419;
last_match_133_7419 = new_match_93_2375;
last_match_133_987 = last_match_133_7419;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7420;
{
bool_t test_7421;
{
long aux_7422;
aux_7422 = (long)(current_char_37_2376);
test_7421 = (aux_7422<((long)33));
}
if(test_7421){
test_7420 = ((bool_t)1);
}
 else {
bool_t test_7425;
{
bool_t test_7426;
{
long aux_7427;
aux_7427 = (long)(current_char_37_2376);
test_7426 = (aux_7427==((long)35));
}
if(test_7426){
test_7425 = ((bool_t)1);
}
 else {
long aux_7430;
aux_7430 = (long)(current_char_37_2376);
test_7425 = (aux_7430==((long)34));
}
}
if(test_7425){
test_7420 = ((bool_t)1);
}
 else {
bool_t test_7433;
{
bool_t test_7434;
{
long aux_7435;
aux_7435 = (long)(current_char_37_2376);
test_7434 = (aux_7435==((long)41));
}
if(test_7434){
test_7433 = ((bool_t)1);
}
 else {
long aux_7438;
aux_7438 = (long)(current_char_37_2376);
test_7433 = (aux_7438==((long)40));
}
}
if(test_7433){
test_7420 = ((bool_t)1);
}
 else {
bool_t test_7441;
{
bool_t test_7442;
{
long aux_7443;
aux_7443 = (long)(current_char_37_2376);
test_7442 = (aux_7443==((long)59));
}
if(test_7442){
test_7441 = ((bool_t)1);
}
 else {
test_7441 = test2826_2379;
}
}
if(test_7441){
test_7420 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2376)){
case ((long)91) : 
test_7420 = ((bool_t)1);
break;
case ((long)93) : 
test_7420 = ((bool_t)1);
break;
case ((long)123) : 
test_7420 = ((bool_t)1);
break;
case ((long)125) : 
test_7420 = ((bool_t)1);
break;
default: 
{
long aux_7446;
aux_7446 = (long)(current_char_37_2376);
test_7420 = (aux_7446==((long)127));
}
}
}
}
}
}
}
if(test_7420){
aux_7016 = new_match_93_2375;
}
 else {
{
long last_match_133_7451;
last_match_133_7451 = new_match_93_2375;
last_match_133_2373 = last_match_133_7451;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7452;
{
bool_t test_7453;
{
long aux_7454;
aux_7454 = (long)(current_char_37_946);
test_7453 = (aux_7454==((long)43));
}
if(test_7453){
test_7452 = ((bool_t)1);
}
 else {
long aux_7457;
aux_7457 = (long)(current_char_37_946);
test_7452 = (aux_7457==((long)45));
}
}
if(test_7452){
last_match_133_967 = new_match_93_945;
state_27_1029_171_2806:
{
long new_match_93_969;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_969 = ((long)27);
{
int current_char_37_970;
current_char_37_970 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7462;
{
long aux_7463;
aux_7463 = (long)(current_char_37_970);
test_7462 = (aux_7463==((long)0));
}
if(test_7462){
{
bool_t test1698_972;
{
bool_t res3359_3609;
{
bool_t _andtest_1237_3606;
_andtest_1237_3606 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3606){
res3359_3609 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3359_3609 = ((bool_t)0);
}
}
test1698_972 = res3359_3609;
}
if(test1698_972){
goto state_27_1029_171_2806;
}
 else {
aux_7016 = new_match_93_969;
}
}
}
 else {
bool_t test_7470;
{
long aux_7471;
aux_7471 = (long)(current_char_37_970);
test_7470 = (aux_7471==((long)58));
}
if(test_7470){
{
long last_match_133_7474;
last_match_133_7474 = new_match_93_969;
last_match_133_987 = last_match_133_7474;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7475;
{
bool_t test_7476;
{
long aux_7477;
aux_7477 = (long)(current_char_37_970);
test_7476 = (aux_7477>=((long)48));
}
if(test_7476){
long aux_7480;
aux_7480 = (long)(current_char_37_970);
test_7475 = (aux_7480<((long)58));
}
 else {
test_7475 = ((bool_t)0);
}
}
if(test_7475){
{
long last_match_133_7483;
last_match_133_7483 = new_match_93_969;
last_match_133_2391 = last_match_133_7483;
goto state_28_1030_70_2734;
}
}
 else {
bool_t test_7484;
{
bool_t test_7485;
{
long aux_7486;
aux_7486 = (long)(current_char_37_970);
test_7485 = (aux_7486<((long)33));
}
if(test_7485){
test_7484 = ((bool_t)1);
}
 else {
bool_t test_7489;
{
bool_t test_7490;
{
long aux_7491;
aux_7491 = (long)(current_char_37_970);
test_7490 = (aux_7491==((long)35));
}
if(test_7490){
test_7489 = ((bool_t)1);
}
 else {
long aux_7494;
aux_7494 = (long)(current_char_37_970);
test_7489 = (aux_7494==((long)34));
}
}
if(test_7489){
test_7484 = ((bool_t)1);
}
 else {
bool_t test_7497;
{
bool_t test_7498;
{
long aux_7499;
aux_7499 = (long)(current_char_37_970);
test_7498 = (aux_7499==((long)41));
}
if(test_7498){
test_7497 = ((bool_t)1);
}
 else {
long aux_7502;
aux_7502 = (long)(current_char_37_970);
test_7497 = (aux_7502==((long)40));
}
}
if(test_7497){
test_7484 = ((bool_t)1);
}
 else {
bool_t test_7505;
{
bool_t test_7506;
{
long aux_7507;
aux_7507 = (long)(current_char_37_970);
test_7506 = (aux_7507>=((long)48));
}
if(test_7506){
long aux_7510;
aux_7510 = (long)(current_char_37_970);
test_7505 = (aux_7510<((long)60));
}
 else {
test_7505 = ((bool_t)0);
}
}
if(test_7505){
test_7484 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_970)){
case ((long)91) : 
test_7484 = ((bool_t)1);
break;
case ((long)93) : 
test_7484 = ((bool_t)1);
break;
case ((long)123) : 
test_7484 = ((bool_t)1);
break;
case ((long)125) : 
test_7484 = ((bool_t)1);
break;
default: 
{
long aux_7513;
aux_7513 = (long)(current_char_37_970);
test_7484 = (aux_7513==((long)127));
}
}
}
}
}
}
}
if(test_7484){
aux_7016 = new_match_93_969;
}
 else {
{
long last_match_133_7518;
last_match_133_7518 = new_match_93_969;
last_match_133_2373 = last_match_133_7518;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7519;
{
bool_t test_7520;
{
long aux_7521;
aux_7521 = (long)(current_char_37_946);
test_7520 = (aux_7521<((long)33));
}
if(test_7520){
test_7519 = ((bool_t)1);
}
 else {
bool_t test_7524;
{
bool_t test_7525;
{
long aux_7526;
aux_7526 = (long)(current_char_37_946);
test_7525 = (aux_7526==((long)35));
}
if(test_7525){
test_7524 = ((bool_t)1);
}
 else {
long aux_7529;
aux_7529 = (long)(current_char_37_946);
test_7524 = (aux_7529==((long)34));
}
}
if(test_7524){
test_7519 = ((bool_t)1);
}
 else {
bool_t test_7532;
{
bool_t test_7533;
{
long aux_7534;
aux_7534 = (long)(current_char_37_946);
test_7533 = (aux_7534==((long)41));
}
if(test_7533){
test_7532 = ((bool_t)1);
}
 else {
long aux_7537;
aux_7537 = (long)(current_char_37_946);
test_7532 = (aux_7537==((long)40));
}
}
if(test_7532){
test_7519 = ((bool_t)1);
}
 else {
bool_t test_7540;
{
long aux_7541;
aux_7541 = (long)(current_char_37_946);
test_7540 = (aux_7541==((long)43));
}
if(test_7540){
test_7519 = ((bool_t)1);
}
 else {
bool_t test_7544;
{
long aux_7545;
aux_7545 = (long)(current_char_37_946);
test_7544 = (aux_7545==((long)45));
}
if(test_7544){
test_7519 = ((bool_t)1);
}
 else {
bool_t test_7548;
{
bool_t test_7549;
{
long aux_7550;
aux_7550 = (long)(current_char_37_946);
test_7549 = (aux_7550>=((long)48));
}
if(test_7549){
long aux_7553;
aux_7553 = (long)(current_char_37_946);
test_7548 = (aux_7553<((long)60));
}
 else {
test_7548 = ((bool_t)0);
}
}
if(test_7548){
test_7519 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_946)){
case ((long)91) : 
test_7519 = ((bool_t)1);
break;
case ((long)93) : 
test_7519 = ((bool_t)1);
break;
case ((long)123) : 
test_7519 = ((bool_t)1);
break;
case ((long)125) : 
test_7519 = ((bool_t)1);
break;
default: 
{
long aux_7556;
aux_7556 = (long)(current_char_37_946);
test_7519 = (aux_7556==((long)127));
}
}
}
}
}
}
}
}
}
if(test_7519){
aux_7016 = new_match_93_945;
}
 else {
{
long last_match_133_7561;
last_match_133_7561 = new_match_93_945;
last_match_133_2373 = last_match_133_7561;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7562;
{
long aux_7563;
aux_7563 = (long)(current_char_37_1689);
test_7562 = (aux_7563==((long)58));
}
if(test_7562){
{
long last_match_133_7566;
last_match_133_7566 = new_match_93_1688;
last_match_133_928 = last_match_133_7566;
goto state_21_1023_217_2808;
}
}
 else {
bool_t test_7567;
{
bool_t test_7568;
{
long aux_7569;
aux_7569 = (long)(current_char_37_1689);
test_7568 = (aux_7569>=((long)48));
}
if(test_7568){
long aux_7572;
aux_7572 = (long)(current_char_37_1689);
test_7567 = (aux_7572<((long)58));
}
 else {
test_7567 = ((bool_t)0);
}
}
if(test_7567){
last_match_133_1712 = new_match_93_1688;
state_25_1027_148_2772:
{
long new_match_93_1714;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1714 = ((long)12);
{
int current_char_37_1715;
current_char_37_1715 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7577;
{
long aux_7578;
aux_7578 = (long)(current_char_37_1715);
test_7577 = (aux_7578==((long)0));
}
if(test_7577){
{
bool_t test2306_1717;
{
bool_t res3390_5031;
{
bool_t _andtest_1237_5028;
_andtest_1237_5028 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5028){
res3390_5031 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3390_5031 = ((bool_t)0);
}
}
test2306_1717 = res3390_5031;
}
if(test2306_1717){
goto state_25_1027_148_2772;
}
 else {
aux_7016 = new_match_93_1714;
}
}
}
 else {
bool_t test_7585;
{
bool_t test_7586;
{
long aux_7587;
aux_7587 = (long)(current_char_37_1715);
test_7586 = (aux_7587==((long)69));
}
if(test_7586){
test_7585 = ((bool_t)1);
}
 else {
long aux_7590;
aux_7590 = (long)(current_char_37_1715);
test_7585 = (aux_7590==((long)101));
}
}
if(test_7585){
{
long last_match_133_7593;
last_match_133_7593 = new_match_93_1714;
last_match_133_943 = last_match_133_7593;
goto state_26_1028_128_2807;
}
}
 else {
bool_t test_7594;
{
long aux_7595;
aux_7595 = (long)(current_char_37_1715);
test_7594 = (aux_7595==((long)58));
}
if(test_7594){
{
long last_match_133_7598;
last_match_133_7598 = new_match_93_1714;
last_match_133_928 = last_match_133_7598;
goto state_21_1023_217_2808;
}
}
 else {
bool_t test_7599;
{
bool_t test_7600;
{
long aux_7601;
aux_7601 = (long)(current_char_37_1715);
test_7600 = (aux_7601>=((long)48));
}
if(test_7600){
long aux_7604;
aux_7604 = (long)(current_char_37_1715);
test_7599 = (aux_7604<((long)58));
}
 else {
test_7599 = ((bool_t)0);
}
}
if(test_7599){
{
long last_match_133_7607;
last_match_133_7607 = new_match_93_1714;
last_match_133_1712 = last_match_133_7607;
goto state_25_1027_148_2772;
}
}
 else {
bool_t test2310_1721;
{
long aux_7608;
aux_7608 = (long)(current_char_37_1715);
test2310_1721 = (aux_7608==((long)46));
}
if(test2310_1721){
last_match_133_1848 = new_match_93_1714;
state_24_1026_170_2764:
{
long new_match_93_1850;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1850 = ((long)18);
{
int current_char_37_1851;
current_char_37_1851 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7614;
{
long aux_7615;
aux_7615 = (long)(current_char_37_1851);
test_7614 = (aux_7615==((long)0));
}
if(test_7614){
{
bool_t test2409_1853;
{
bool_t res3397_5280;
{
bool_t _andtest_1237_5277;
_andtest_1237_5277 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5277){
res3397_5280 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3397_5280 = ((bool_t)0);
}
}
test2409_1853 = res3397_5280;
}
if(test2409_1853){
goto state_24_1026_170_2764;
}
 else {
aux_7016 = new_match_93_1850;
}
}
}
 else {
bool_t test_7622;
{
bool_t test_7623;
{
long aux_7624;
aux_7624 = (long)(current_char_37_1851);
test_7623 = (aux_7624==((long)69));
}
if(test_7623){
test_7622 = ((bool_t)1);
}
 else {
long aux_7627;
aux_7627 = (long)(current_char_37_1851);
test_7622 = (aux_7627==((long)101));
}
}
if(test_7622){
{
long last_match_133_7630;
last_match_133_7630 = new_match_93_1850;
last_match_133_943 = last_match_133_7630;
goto state_26_1028_128_2807;
}
}
 else {
bool_t test_7631;
{
long aux_7632;
aux_7632 = (long)(current_char_37_1851);
test_7631 = (aux_7632==((long)58));
}
if(test_7631){
{
long last_match_133_7635;
last_match_133_7635 = new_match_93_1850;
last_match_133_987 = last_match_133_7635;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7636;
{
bool_t test_7637;
{
long aux_7638;
aux_7638 = (long)(current_char_37_1851);
test_7637 = (aux_7638>=((long)48));
}
if(test_7637){
long aux_7641;
aux_7641 = (long)(current_char_37_1851);
test_7636 = (aux_7641<((long)58));
}
 else {
test_7636 = ((bool_t)0);
}
}
if(test_7636){
last_match_133_1878 = new_match_93_1850;
state_30_1032_198_2762:
{
long new_match_93_1880;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1880 = ((long)18);
{
int current_char_37_1881;
current_char_37_1881 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7646;
{
long aux_7647;
aux_7647 = (long)(current_char_37_1881);
test_7646 = (aux_7647==((long)0));
}
if(test_7646){
{
bool_t test2430_1883;
{
bool_t res3398_5343;
{
bool_t _andtest_1237_5340;
_andtest_1237_5340 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5340){
res3398_5343 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3398_5343 = ((bool_t)0);
}
}
test2430_1883 = res3398_5343;
}
if(test2430_1883){
goto state_30_1032_198_2762;
}
 else {
aux_7016 = new_match_93_1880;
}
}
}
 else {
bool_t test_7654;
{
bool_t test_7655;
{
long aux_7656;
aux_7656 = (long)(current_char_37_1881);
test_7655 = (aux_7656==((long)69));
}
if(test_7655){
test_7654 = ((bool_t)1);
}
 else {
long aux_7659;
aux_7659 = (long)(current_char_37_1881);
test_7654 = (aux_7659==((long)101));
}
}
if(test_7654){
{
long last_match_133_7662;
last_match_133_7662 = new_match_93_1880;
last_match_133_943 = last_match_133_7662;
goto state_26_1028_128_2807;
}
}
 else {
bool_t test_7663;
{
long aux_7664;
aux_7664 = (long)(current_char_37_1881);
test_7663 = (aux_7664==((long)58));
}
if(test_7663){
{
long last_match_133_7667;
last_match_133_7667 = new_match_93_1880;
last_match_133_987 = last_match_133_7667;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7668;
{
bool_t test_7669;
{
long aux_7670;
aux_7670 = (long)(current_char_37_1881);
test_7669 = (aux_7670>=((long)48));
}
if(test_7669){
long aux_7673;
aux_7673 = (long)(current_char_37_1881);
test_7668 = (aux_7673<((long)58));
}
 else {
test_7668 = ((bool_t)0);
}
}
if(test_7668){
{
long last_match_133_7676;
last_match_133_7676 = new_match_93_1880;
last_match_133_1878 = last_match_133_7676;
goto state_30_1032_198_2762;
}
}
 else {
bool_t test_7677;
{
bool_t test_7678;
{
long aux_7679;
aux_7679 = (long)(current_char_37_1881);
test_7678 = (aux_7679<((long)33));
}
if(test_7678){
test_7677 = ((bool_t)1);
}
 else {
bool_t test_7682;
{
bool_t test_7683;
{
long aux_7684;
aux_7684 = (long)(current_char_37_1881);
test_7683 = (aux_7684==((long)35));
}
if(test_7683){
test_7682 = ((bool_t)1);
}
 else {
long aux_7687;
aux_7687 = (long)(current_char_37_1881);
test_7682 = (aux_7687==((long)34));
}
}
if(test_7682){
test_7677 = ((bool_t)1);
}
 else {
bool_t test_7690;
{
bool_t test_7691;
{
long aux_7692;
aux_7692 = (long)(current_char_37_1881);
test_7691 = (aux_7692==((long)41));
}
if(test_7691){
test_7690 = ((bool_t)1);
}
 else {
long aux_7695;
aux_7695 = (long)(current_char_37_1881);
test_7690 = (aux_7695==((long)40));
}
}
if(test_7690){
test_7677 = ((bool_t)1);
}
 else {
bool_t test_7698;
{
bool_t test_7699;
{
long aux_7700;
aux_7700 = (long)(current_char_37_1881);
test_7699 = (aux_7700>=((long)48));
}
if(test_7699){
long aux_7703;
aux_7703 = (long)(current_char_37_1881);
test_7698 = (aux_7703<((long)60));
}
 else {
test_7698 = ((bool_t)0);
}
}
if(test_7698){
test_7677 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1881)){
case ((long)69) : 
test_7677 = ((bool_t)1);
break;
case ((long)91) : 
test_7677 = ((bool_t)1);
break;
case ((long)93) : 
test_7677 = ((bool_t)1);
break;
case ((long)101) : 
test_7677 = ((bool_t)1);
break;
case ((long)123) : 
test_7677 = ((bool_t)1);
break;
case ((long)125) : 
test_7677 = ((bool_t)1);
break;
default: 
{
long aux_7706;
aux_7706 = (long)(current_char_37_1881);
test_7677 = (aux_7706==((long)127));
}
}
}
}
}
}
}
if(test_7677){
aux_7016 = new_match_93_1880;
}
 else {
{
long last_match_133_7711;
last_match_133_7711 = new_match_93_1880;
last_match_133_2373 = last_match_133_7711;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7712;
{
bool_t test_7713;
{
long aux_7714;
aux_7714 = (long)(current_char_37_1851);
test_7713 = (aux_7714<((long)33));
}
if(test_7713){
test_7712 = ((bool_t)1);
}
 else {
bool_t test_7717;
{
bool_t test_7718;
{
long aux_7719;
aux_7719 = (long)(current_char_37_1851);
test_7718 = (aux_7719==((long)35));
}
if(test_7718){
test_7717 = ((bool_t)1);
}
 else {
long aux_7722;
aux_7722 = (long)(current_char_37_1851);
test_7717 = (aux_7722==((long)34));
}
}
if(test_7717){
test_7712 = ((bool_t)1);
}
 else {
bool_t test_7725;
{
bool_t test_7726;
{
long aux_7727;
aux_7727 = (long)(current_char_37_1851);
test_7726 = (aux_7727==((long)41));
}
if(test_7726){
test_7725 = ((bool_t)1);
}
 else {
long aux_7730;
aux_7730 = (long)(current_char_37_1851);
test_7725 = (aux_7730==((long)40));
}
}
if(test_7725){
test_7712 = ((bool_t)1);
}
 else {
bool_t test_7733;
{
bool_t test_7734;
{
long aux_7735;
aux_7735 = (long)(current_char_37_1851);
test_7734 = (aux_7735>=((long)48));
}
if(test_7734){
long aux_7738;
aux_7738 = (long)(current_char_37_1851);
test_7733 = (aux_7738<((long)60));
}
 else {
test_7733 = ((bool_t)0);
}
}
if(test_7733){
test_7712 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1851)){
case ((long)69) : 
test_7712 = ((bool_t)1);
break;
case ((long)91) : 
test_7712 = ((bool_t)1);
break;
case ((long)93) : 
test_7712 = ((bool_t)1);
break;
case ((long)101) : 
test_7712 = ((bool_t)1);
break;
case ((long)123) : 
test_7712 = ((bool_t)1);
break;
case ((long)125) : 
test_7712 = ((bool_t)1);
break;
default: 
{
long aux_7741;
aux_7741 = (long)(current_char_37_1851);
test_7712 = (aux_7741==((long)127));
}
}
}
}
}
}
}
if(test_7712){
aux_7016 = new_match_93_1850;
}
 else {
{
long last_match_133_7746;
last_match_133_7746 = new_match_93_1850;
last_match_133_2373 = last_match_133_7746;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_7747;
{
bool_t test_7748;
{
long aux_7749;
aux_7749 = (long)(current_char_37_1715);
test_7748 = (aux_7749<((long)33));
}
if(test_7748){
test_7747 = ((bool_t)1);
}
 else {
bool_t test_7752;
{
bool_t test_7753;
{
long aux_7754;
aux_7754 = (long)(current_char_37_1715);
test_7753 = (aux_7754==((long)35));
}
if(test_7753){
test_7752 = ((bool_t)1);
}
 else {
long aux_7757;
aux_7757 = (long)(current_char_37_1715);
test_7752 = (aux_7757==((long)34));
}
}
if(test_7752){
test_7747 = ((bool_t)1);
}
 else {
bool_t test_7760;
{
bool_t test_7761;
{
long aux_7762;
aux_7762 = (long)(current_char_37_1715);
test_7761 = (aux_7762==((long)41));
}
if(test_7761){
test_7760 = ((bool_t)1);
}
 else {
bool_t test_7765;
{
long aux_7766;
aux_7766 = (long)(current_char_37_1715);
test_7765 = (aux_7766==((long)40));
}
if(test_7765){
test_7760 = ((bool_t)1);
}
 else {
long aux_7769;
aux_7769 = (long)(current_char_37_1715);
test_7760 = (aux_7769==((long)39));
}
}
}
if(test_7760){
test_7747 = ((bool_t)1);
}
 else {
bool_t test_7772;
{
long aux_7773;
aux_7773 = (long)(current_char_37_1715);
test_7772 = (aux_7773==((long)44));
}
if(test_7772){
test_7747 = ((bool_t)1);
}
 else {
if(test2310_1721){
test_7747 = ((bool_t)1);
}
 else {
bool_t test_7777;
{
bool_t test_7778;
{
long aux_7779;
aux_7779 = (long)(current_char_37_1715);
test_7778 = (aux_7779>=((long)48));
}
if(test_7778){
long aux_7782;
aux_7782 = (long)(current_char_37_1715);
test_7777 = (aux_7782<((long)60));
}
 else {
test_7777 = ((bool_t)0);
}
}
if(test_7777){
test_7747 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1715)){
case ((long)69) : 
test_7747 = ((bool_t)1);
break;
case ((long)91) : 
test_7747 = ((bool_t)1);
break;
case ((long)93) : 
test_7747 = ((bool_t)1);
break;
case ((long)96) : 
test_7747 = ((bool_t)1);
break;
case ((long)101) : 
test_7747 = ((bool_t)1);
break;
case ((long)123) : 
test_7747 = ((bool_t)1);
break;
case ((long)125) : 
test_7747 = ((bool_t)1);
break;
default: 
{
long aux_7785;
aux_7785 = (long)(current_char_37_1715);
test_7747 = (aux_7785==((long)127));
}
}
}
}
}
}
}
}
}
if(test_7747){
aux_7016 = new_match_93_1714;
}
 else {
{
long last_match_133_7790;
last_match_133_7790 = new_match_93_1714;
last_match_133_2373 = last_match_133_7790;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test2289_1695;
{
long aux_7791;
aux_7791 = (long)(current_char_37_1689);
test2289_1695 = (aux_7791==((long)46));
}
if(test2289_1695){
{
long last_match_133_7795;
last_match_133_7795 = new_match_93_1688;
last_match_133_1848 = last_match_133_7795;
goto state_24_1026_170_2764;
}
}
 else {
bool_t test_7796;
{
bool_t test_7797;
{
long aux_7798;
aux_7798 = (long)(current_char_37_1689);
test_7797 = (aux_7798<((long)33));
}
if(test_7797){
test_7796 = ((bool_t)1);
}
 else {
bool_t test_7801;
{
bool_t test_7802;
{
long aux_7803;
aux_7803 = (long)(current_char_37_1689);
test_7802 = (aux_7803==((long)35));
}
if(test_7802){
test_7801 = ((bool_t)1);
}
 else {
long aux_7806;
aux_7806 = (long)(current_char_37_1689);
test_7801 = (aux_7806==((long)34));
}
}
if(test_7801){
test_7796 = ((bool_t)1);
}
 else {
bool_t test_7809;
{
bool_t test_7810;
{
long aux_7811;
aux_7811 = (long)(current_char_37_1689);
test_7810 = (aux_7811==((long)41));
}
if(test_7810){
test_7809 = ((bool_t)1);
}
 else {
bool_t test_7814;
{
long aux_7815;
aux_7815 = (long)(current_char_37_1689);
test_7814 = (aux_7815==((long)40));
}
if(test_7814){
test_7809 = ((bool_t)1);
}
 else {
long aux_7818;
aux_7818 = (long)(current_char_37_1689);
test_7809 = (aux_7818==((long)39));
}
}
}
if(test_7809){
test_7796 = ((bool_t)1);
}
 else {
bool_t test_7821;
{
long aux_7822;
aux_7822 = (long)(current_char_37_1689);
test_7821 = (aux_7822==((long)44));
}
if(test_7821){
test_7796 = ((bool_t)1);
}
 else {
if(test2289_1695){
test_7796 = ((bool_t)1);
}
 else {
bool_t test_7826;
{
bool_t test_7827;
{
long aux_7828;
aux_7828 = (long)(current_char_37_1689);
test_7827 = (aux_7828>=((long)48));
}
if(test_7827){
long aux_7831;
aux_7831 = (long)(current_char_37_1689);
test_7826 = (aux_7831<((long)60));
}
 else {
test_7826 = ((bool_t)0);
}
}
if(test_7826){
test_7796 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1689)){
case ((long)69) : 
test_7796 = ((bool_t)1);
break;
case ((long)91) : 
test_7796 = ((bool_t)1);
break;
case ((long)93) : 
test_7796 = ((bool_t)1);
break;
case ((long)96) : 
test_7796 = ((bool_t)1);
break;
case ((long)101) : 
test_7796 = ((bool_t)1);
break;
case ((long)123) : 
test_7796 = ((bool_t)1);
break;
case ((long)125) : 
test_7796 = ((bool_t)1);
break;
default: 
{
long aux_7834;
aux_7834 = (long)(current_char_37_1689);
test_7796 = (aux_7834==((long)127));
}
}
}
}
}
}
}
}
}
if(test_7796){
aux_7016 = new_match_93_1688;
}
 else {
{
long last_match_133_7839;
last_match_133_7839 = new_match_93_1688;
last_match_133_2373 = last_match_133_7839;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
break;
case ((long)46) : 
last_match_133_2254 = last_match_133_1870;
state_12_1014_137_2744:
{
long new_match_93_2256;
{
bool_t test2759_2279;
{
obj_t obj1_6047;
obj1_6047 = CELL_REF(the_rgc_context_46_6934);
test2759_2279 = (obj1_6047==symbol3433___reader);
}
if(test2759_2279){
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2256 = ((long)20);
}
 else {
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2256 = ((long)21);
}
}
{
int current_char_37_2257;
current_char_37_2257 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7845;
{
long aux_7846;
aux_7846 = (long)(current_char_37_2257);
test_7845 = (aux_7846==((long)0));
}
if(test_7845){
{
bool_t test2741_2259;
{
bool_t res3412_6058;
{
bool_t _andtest_1237_6055;
_andtest_1237_6055 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6055){
res3412_6058 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3412_6058 = ((bool_t)0);
}
}
test2741_2259 = res3412_6058;
}
if(test2741_2259){
goto state_12_1014_137_2744;
}
 else {
aux_7016 = new_match_93_2256;
}
}
}
 else {
bool_t test_7853;
{
long aux_7854;
aux_7854 = (long)(current_char_37_2257);
test_7853 = (aux_7854==((long)58));
}
if(test_7853){
{
long last_match_133_7857;
last_match_133_7857 = new_match_93_2256;
last_match_133_987 = last_match_133_7857;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7858;
{
bool_t test_7859;
{
long aux_7860;
aux_7860 = (long)(current_char_37_2257);
test_7859 = (aux_7860>=((long)48));
}
if(test_7859){
long aux_7863;
aux_7863 = (long)(current_char_37_2257);
test_7858 = (aux_7863<((long)58));
}
 else {
test_7858 = ((bool_t)0);
}
}
if(test_7858){
last_match_133_1923 = new_match_93_2256;
state_33_1035_172_2759:
{
long new_match_93_1925;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1925 = ((long)18);
{
int current_char_37_1926;
current_char_37_1926 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7868;
{
long aux_7869;
aux_7869 = (long)(current_char_37_1926);
test_7868 = (aux_7869==((long)0));
}
if(test_7868){
{
bool_t test2463_1928;
{
bool_t res3400_5422;
{
bool_t _andtest_1237_5419;
_andtest_1237_5419 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5419){
res3400_5422 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3400_5422 = ((bool_t)0);
}
}
test2463_1928 = res3400_5422;
}
if(test2463_1928){
goto state_33_1035_172_2759;
}
 else {
aux_7016 = new_match_93_1925;
}
}
}
 else {
bool_t test_7876;
{
bool_t test_7877;
{
long aux_7878;
aux_7878 = (long)(current_char_37_1926);
test_7877 = (aux_7878==((long)69));
}
if(test_7877){
test_7876 = ((bool_t)1);
}
 else {
long aux_7881;
aux_7881 = (long)(current_char_37_1926);
test_7876 = (aux_7881==((long)101));
}
}
if(test_7876){
{
long last_match_133_7884;
last_match_133_7884 = new_match_93_1925;
last_match_133_943 = last_match_133_7884;
goto state_26_1028_128_2807;
}
}
 else {
bool_t test_7885;
{
long aux_7886;
aux_7886 = (long)(current_char_37_1926);
test_7885 = (aux_7886==((long)58));
}
if(test_7885){
{
long last_match_133_7889;
last_match_133_7889 = new_match_93_1925;
last_match_133_987 = last_match_133_7889;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_7890;
{
bool_t test_7891;
{
long aux_7892;
aux_7892 = (long)(current_char_37_1926);
test_7891 = (aux_7892>=((long)48));
}
if(test_7891){
long aux_7895;
aux_7895 = (long)(current_char_37_1926);
test_7890 = (aux_7895<((long)58));
}
 else {
test_7890 = ((bool_t)0);
}
}
if(test_7890){
{
long last_match_133_7898;
last_match_133_7898 = new_match_93_1925;
last_match_133_1923 = last_match_133_7898;
goto state_33_1035_172_2759;
}
}
 else {
bool_t test_7899;
{
bool_t test_7900;
{
long aux_7901;
aux_7901 = (long)(current_char_37_1926);
test_7900 = (aux_7901<((long)33));
}
if(test_7900){
test_7899 = ((bool_t)1);
}
 else {
bool_t test_7904;
{
bool_t test_7905;
{
long aux_7906;
aux_7906 = (long)(current_char_37_1926);
test_7905 = (aux_7906==((long)35));
}
if(test_7905){
test_7904 = ((bool_t)1);
}
 else {
long aux_7909;
aux_7909 = (long)(current_char_37_1926);
test_7904 = (aux_7909==((long)34));
}
}
if(test_7904){
test_7899 = ((bool_t)1);
}
 else {
bool_t test_7912;
{
bool_t test_7913;
{
long aux_7914;
aux_7914 = (long)(current_char_37_1926);
test_7913 = (aux_7914==((long)41));
}
if(test_7913){
test_7912 = ((bool_t)1);
}
 else {
long aux_7917;
aux_7917 = (long)(current_char_37_1926);
test_7912 = (aux_7917==((long)40));
}
}
if(test_7912){
test_7899 = ((bool_t)1);
}
 else {
bool_t test_7920;
{
bool_t test_7921;
{
long aux_7922;
aux_7922 = (long)(current_char_37_1926);
test_7921 = (aux_7922>=((long)48));
}
if(test_7921){
long aux_7925;
aux_7925 = (long)(current_char_37_1926);
test_7920 = (aux_7925<((long)60));
}
 else {
test_7920 = ((bool_t)0);
}
}
if(test_7920){
test_7899 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1926)){
case ((long)69) : 
test_7899 = ((bool_t)1);
break;
case ((long)91) : 
test_7899 = ((bool_t)1);
break;
case ((long)93) : 
test_7899 = ((bool_t)1);
break;
case ((long)101) : 
test_7899 = ((bool_t)1);
break;
case ((long)123) : 
test_7899 = ((bool_t)1);
break;
case ((long)125) : 
test_7899 = ((bool_t)1);
break;
default: 
{
long aux_7928;
aux_7928 = (long)(current_char_37_1926);
test_7899 = (aux_7928==((long)127));
}
}
}
}
}
}
}
if(test_7899){
aux_7016 = new_match_93_1925;
}
 else {
{
long last_match_133_7933;
last_match_133_7933 = new_match_93_1925;
last_match_133_2373 = last_match_133_7933;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test2744_2262;
{
long aux_7934;
aux_7934 = (long)(current_char_37_2257);
test2744_2262 = (aux_7934==((long)41));
}
if(test2744_2262){
{
long new_match_93_6068;
{
bool_t test2860_6069;
{
obj_t obj1_6072;
obj1_6072 = CELL_REF(the_rgc_context_46_6934);
test2860_6069 = (obj1_6072==symbol3433___reader);
}
if(test2860_6069){
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6068 = ((long)19);
}
 else {
new_match_93_6068 = new_match_93_2256;
}
}
aux_7016 = new_match_93_6068;
}
}
 else {
bool_t test_7941;
{
bool_t test_7942;
{
long aux_7943;
aux_7943 = (long)(current_char_37_2257);
test_7942 = (aux_7943<((long)33));
}
if(test_7942){
test_7941 = ((bool_t)1);
}
 else {
bool_t test_7946;
{
bool_t test_7947;
{
long aux_7948;
aux_7948 = (long)(current_char_37_2257);
test_7947 = (aux_7948==((long)35));
}
if(test_7947){
test_7946 = ((bool_t)1);
}
 else {
long aux_7951;
aux_7951 = (long)(current_char_37_2257);
test_7946 = (aux_7951==((long)34));
}
}
if(test_7946){
test_7941 = ((bool_t)1);
}
 else {
bool_t test_7954;
if(test2744_2262){
test_7954 = ((bool_t)1);
}
 else {
long aux_7956;
aux_7956 = (long)(current_char_37_2257);
test_7954 = (aux_7956==((long)40));
}
if(test_7954){
test_7941 = ((bool_t)1);
}
 else {
bool_t test_7959;
{
bool_t test_7960;
{
long aux_7961;
aux_7961 = (long)(current_char_37_2257);
test_7960 = (aux_7961>=((long)48));
}
if(test_7960){
long aux_7964;
aux_7964 = (long)(current_char_37_2257);
test_7959 = (aux_7964<((long)60));
}
 else {
test_7959 = ((bool_t)0);
}
}
if(test_7959){
test_7941 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2257)){
case ((long)91) : 
test_7941 = ((bool_t)1);
break;
case ((long)93) : 
test_7941 = ((bool_t)1);
break;
case ((long)123) : 
test_7941 = ((bool_t)1);
break;
case ((long)125) : 
test_7941 = ((bool_t)1);
break;
default: 
{
long aux_7967;
aux_7967 = (long)(current_char_37_2257);
test_7941 = (aux_7967==((long)127));
}
}
}
}
}
}
}
if(test_7941){
bool_t test_7972;
{
bool_t test_7973;
{
long aux_7974;
aux_7974 = (long)(current_char_37_2257);
test_7973 = (aux_7974==((long)9));
}
if(test_7973){
test_7972 = ((bool_t)1);
}
 else {
bool_t test_7977;
{
bool_t test_7978;
{
long aux_7979;
aux_7979 = (long)(current_char_37_2257);
test_7978 = (aux_7979==((long)13));
}
if(test_7978){
test_7977 = ((bool_t)1);
}
 else {
long aux_7982;
aux_7982 = (long)(current_char_37_2257);
test_7977 = (aux_7982==((long)12));
}
}
if(test_7977){
test_7972 = ((bool_t)1);
}
 else {
long aux_7985;
aux_7985 = (long)(current_char_37_2257);
test_7972 = (aux_7985==((long)32));
}
}
}
if(test_7972){
last_match_133_2411 = new_match_93_2256;
state_31_1033_57_2733:
{
int current_char_37_2413;
current_char_37_2413 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_7989;
{
long aux_7990;
aux_7990 = (long)(current_char_37_2413);
test_7989 = (aux_7990==((long)0));
}
if(test_7989){
{
bool_t test2853_2415;
{
bool_t res3418_6313;
{
bool_t _andtest_1237_6310;
_andtest_1237_6310 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6310){
res3418_6313 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3418_6313 = ((bool_t)0);
}
}
test2853_2415 = res3418_6313;
}
if(test2853_2415){
goto state_31_1033_57_2733;
}
 else {
aux_7016 = last_match_133_2411;
}
}
}
 else {
bool_t test_7997;
{
long aux_7998;
aux_7998 = (long)(current_char_37_2413);
test_7997 = (aux_7998==((long)41));
}
if(test_7997){
{
long new_match_93_6317;
{
bool_t test2860_6318;
{
obj_t obj1_6321;
obj1_6321 = CELL_REF(the_rgc_context_46_6934);
test2860_6318 = (obj1_6321==symbol3433___reader);
}
if(test2860_6318){
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6317 = ((long)19);
}
 else {
new_match_93_6317 = last_match_133_2411;
}
}
aux_7016 = new_match_93_6317;
}
}
 else {
bool_t test_8004;
{
bool_t test_8005;
{
long aux_8006;
aux_8006 = (long)(current_char_37_2413);
test_8005 = (aux_8006==((long)9));
}
if(test_8005){
test_8004 = ((bool_t)1);
}
 else {
bool_t test_8009;
{
bool_t test_8010;
{
long aux_8011;
aux_8011 = (long)(current_char_37_2413);
test_8010 = (aux_8011==((long)13));
}
if(test_8010){
test_8009 = ((bool_t)1);
}
 else {
long aux_8014;
aux_8014 = (long)(current_char_37_2413);
test_8009 = (aux_8014==((long)12));
}
}
if(test_8009){
test_8004 = ((bool_t)1);
}
 else {
long aux_8017;
aux_8017 = (long)(current_char_37_2413);
test_8004 = (aux_8017==((long)32));
}
}
}
if(test_8004){
{
goto state_31_1033_57_2733;
}
}
 else {
aux_7016 = last_match_133_2411;
}
}
}
}
}
}
 else {
aux_7016 = new_match_93_2256;
}
}
 else {
{
long last_match_133_8020;
last_match_133_8020 = new_match_93_2256;
last_match_133_2373 = last_match_133_8020;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
break;
case ((long)44) : 
last_match_133_2247 = last_match_133_1870;
state_11_1013_10_2745:
{
long new_match_93_2249;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2249 = ((long)30);
{
int current_char_37_2250;
current_char_37_2250 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8023;
{
long aux_8024;
aux_8024 = (long)(current_char_37_2250);
test_8023 = (aux_8024==((long)0));
}
if(test_8023){
{
bool_t test2737_2252;
{
bool_t res3411_6040;
{
bool_t _andtest_1237_6037;
_andtest_1237_6037 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6037){
res3411_6040 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3411_6040 = ((bool_t)0);
}
}
test2737_2252 = res3411_6040;
}
if(test2737_2252){
goto state_11_1013_10_2745;
}
 else {
aux_7016 = new_match_93_2249;
}
}
}
 else {
bool_t test_8031;
{
long aux_8032;
aux_8032 = (long)(current_char_37_2250);
test_8031 = (aux_8032==((long)64));
}
if(test_8031){
{
long new_match_93_6044;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6044 = ((long)31);
aux_7016 = new_match_93_6044;
}
}
 else {
aux_7016 = new_match_93_2249;
}
}
}
}
}
break;
case ((long)45) : 
case ((long)43) : 
last_match_133_1439 = last_match_133_1870;
state_10_1012_87_2784:
{
long new_match_93_1441;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1441 = ((long)27);
{
int current_char_37_1442;
current_char_37_1442 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8038;
{
long aux_8039;
aux_8039 = (long)(current_char_37_1442);
test_8038 = (aux_8039==((long)0));
}
if(test_8038){
{
bool_t test2084_1444;
{
bool_t res3378_4505;
{
bool_t _andtest_1237_4502;
_andtest_1237_4502 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4502){
res3378_4505 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3378_4505 = ((bool_t)0);
}
}
test2084_1444 = res3378_4505;
}
if(test2084_1444){
goto state_10_1012_87_2784;
}
 else {
aux_7016 = new_match_93_1441;
}
}
}
 else {
bool_t test_8046;
{
long aux_8047;
aux_8047 = (long)(current_char_37_1442);
test_8046 = (aux_8047==((long)58));
}
if(test_8046){
{
long last_match_133_8050;
last_match_133_8050 = new_match_93_1441;
last_match_133_987 = last_match_133_8050;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_8051;
{
bool_t test_8052;
{
long aux_8053;
aux_8053 = (long)(current_char_37_1442);
test_8052 = (aux_8053>=((long)48));
}
if(test_8052){
long aux_8056;
aux_8056 = (long)(current_char_37_1442);
test_8051 = (aux_8056<((long)58));
}
 else {
test_8051 = ((bool_t)0);
}
}
if(test_8051){
last_match_133_1738 = new_match_93_1441;
state_36_1038_67_2771:
{
long new_match_93_1740;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1740 = ((long)12);
{
int current_char_37_1741;
current_char_37_1741 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8061;
{
long aux_8062;
aux_8062 = (long)(current_char_37_1741);
test_8061 = (aux_8062==((long)0));
}
if(test_8061){
{
bool_t test2327_1743;
{
bool_t res3391_5078;
{
bool_t _andtest_1237_5075;
_andtest_1237_5075 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5075){
res3391_5078 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3391_5078 = ((bool_t)0);
}
}
test2327_1743 = res3391_5078;
}
if(test2327_1743){
goto state_36_1038_67_2771;
}
 else {
aux_7016 = new_match_93_1740;
}
}
}
 else {
bool_t test_8069;
{
bool_t test_8070;
{
long aux_8071;
aux_8071 = (long)(current_char_37_1741);
test_8070 = (aux_8071==((long)69));
}
if(test_8070){
test_8069 = ((bool_t)1);
}
 else {
long aux_8074;
aux_8074 = (long)(current_char_37_1741);
test_8069 = (aux_8074==((long)101));
}
}
if(test_8069){
{
long last_match_133_8077;
last_match_133_8077 = new_match_93_1740;
last_match_133_943 = last_match_133_8077;
goto state_26_1028_128_2807;
}
}
 else {
bool_t test_8078;
{
long aux_8079;
aux_8079 = (long)(current_char_37_1741);
test_8078 = (aux_8079==((long)58));
}
if(test_8078){
{
long last_match_133_8082;
last_match_133_8082 = new_match_93_1740;
last_match_133_987 = last_match_133_8082;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_8083;
{
bool_t test_8084;
{
long aux_8085;
aux_8085 = (long)(current_char_37_1741);
test_8084 = (aux_8085>=((long)48));
}
if(test_8084){
long aux_8088;
aux_8088 = (long)(current_char_37_1741);
test_8083 = (aux_8088<((long)58));
}
 else {
test_8083 = ((bool_t)0);
}
}
if(test_8083){
{
long last_match_133_8091;
last_match_133_8091 = new_match_93_1740;
last_match_133_1738 = last_match_133_8091;
goto state_36_1038_67_2771;
}
}
 else {
bool_t test2331_1747;
{
long aux_8092;
aux_8092 = (long)(current_char_37_1741);
test2331_1747 = (aux_8092==((long)46));
}
if(test2331_1747){
{
long last_match_133_8096;
last_match_133_8096 = new_match_93_1740;
last_match_133_1848 = last_match_133_8096;
goto state_24_1026_170_2764;
}
}
 else {
bool_t test_8097;
{
bool_t test_8098;
{
long aux_8099;
aux_8099 = (long)(current_char_37_1741);
test_8098 = (aux_8099<((long)33));
}
if(test_8098){
test_8097 = ((bool_t)1);
}
 else {
bool_t test_8102;
{
bool_t test_8103;
{
long aux_8104;
aux_8104 = (long)(current_char_37_1741);
test_8103 = (aux_8104==((long)35));
}
if(test_8103){
test_8102 = ((bool_t)1);
}
 else {
long aux_8107;
aux_8107 = (long)(current_char_37_1741);
test_8102 = (aux_8107==((long)34));
}
}
if(test_8102){
test_8097 = ((bool_t)1);
}
 else {
bool_t test_8110;
{
bool_t test_8111;
{
long aux_8112;
aux_8112 = (long)(current_char_37_1741);
test_8111 = (aux_8112==((long)41));
}
if(test_8111){
test_8110 = ((bool_t)1);
}
 else {
long aux_8115;
aux_8115 = (long)(current_char_37_1741);
test_8110 = (aux_8115==((long)40));
}
}
if(test_8110){
test_8097 = ((bool_t)1);
}
 else {
if(test2331_1747){
test_8097 = ((bool_t)1);
}
 else {
bool_t test_8119;
{
bool_t test_8120;
{
long aux_8121;
aux_8121 = (long)(current_char_37_1741);
test_8120 = (aux_8121>=((long)48));
}
if(test_8120){
long aux_8124;
aux_8124 = (long)(current_char_37_1741);
test_8119 = (aux_8124<((long)60));
}
 else {
test_8119 = ((bool_t)0);
}
}
if(test_8119){
test_8097 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1741)){
case ((long)69) : 
test_8097 = ((bool_t)1);
break;
case ((long)91) : 
test_8097 = ((bool_t)1);
break;
case ((long)93) : 
test_8097 = ((bool_t)1);
break;
case ((long)101) : 
test_8097 = ((bool_t)1);
break;
case ((long)123) : 
test_8097 = ((bool_t)1);
break;
case ((long)125) : 
test_8097 = ((bool_t)1);
break;
default: 
{
long aux_8127;
aux_8127 = (long)(current_char_37_1741);
test_8097 = (aux_8127==((long)127));
}
}
}
}
}
}
}
}
if(test_8097){
aux_7016 = new_match_93_1740;
}
 else {
{
long last_match_133_8132;
last_match_133_8132 = new_match_93_1740;
last_match_133_2373 = last_match_133_8132;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test2087_1447;
{
long aux_8133;
aux_8133 = (long)(current_char_37_1442);
test2087_1447 = (aux_8133==((long)46));
}
if(test2087_1447){
last_match_133_2429 = new_match_93_1441;
state_35_1037_2_2730:
{
long new_match_93_2431;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2431 = ((long)27);
{
int current_char_37_2432;
current_char_37_2432 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8139;
{
long aux_8140;
aux_8140 = (long)(current_char_37_2432);
test_8139 = (aux_8140==((long)0));
}
if(test_8139){
{
bool_t test2865_2434;
{
bool_t res3419_6349;
{
bool_t _andtest_1237_6346;
_andtest_1237_6346 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6346){
res3419_6349 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3419_6349 = ((bool_t)0);
}
}
test2865_2434 = res3419_6349;
}
if(test2865_2434){
goto state_35_1037_2_2730;
}
 else {
aux_7016 = new_match_93_2431;
}
}
}
 else {
bool_t test_8147;
{
long aux_8148;
aux_8148 = (long)(current_char_37_2432);
test_8147 = (aux_8148==((long)58));
}
if(test_8147){
{
long last_match_133_8151;
last_match_133_8151 = new_match_93_2431;
last_match_133_987 = last_match_133_8151;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_8152;
{
bool_t test_8153;
{
long aux_8154;
aux_8154 = (long)(current_char_37_2432);
test_8153 = (aux_8154>=((long)48));
}
if(test_8153){
long aux_8157;
aux_8157 = (long)(current_char_37_2432);
test_8152 = (aux_8157<((long)58));
}
 else {
test_8152 = ((bool_t)0);
}
}
if(test_8152){
{
long last_match_133_8160;
last_match_133_8160 = new_match_93_2431;
last_match_133_1923 = last_match_133_8160;
goto state_33_1035_172_2759;
}
}
 else {
bool_t test_8161;
{
bool_t test_8162;
{
long aux_8163;
aux_8163 = (long)(current_char_37_2432);
test_8162 = (aux_8163<((long)33));
}
if(test_8162){
test_8161 = ((bool_t)1);
}
 else {
bool_t test_8166;
{
bool_t test_8167;
{
long aux_8168;
aux_8168 = (long)(current_char_37_2432);
test_8167 = (aux_8168==((long)35));
}
if(test_8167){
test_8166 = ((bool_t)1);
}
 else {
long aux_8171;
aux_8171 = (long)(current_char_37_2432);
test_8166 = (aux_8171==((long)34));
}
}
if(test_8166){
test_8161 = ((bool_t)1);
}
 else {
bool_t test_8174;
{
bool_t test_8175;
{
long aux_8176;
aux_8176 = (long)(current_char_37_2432);
test_8175 = (aux_8176==((long)41));
}
if(test_8175){
test_8174 = ((bool_t)1);
}
 else {
long aux_8179;
aux_8179 = (long)(current_char_37_2432);
test_8174 = (aux_8179==((long)40));
}
}
if(test_8174){
test_8161 = ((bool_t)1);
}
 else {
bool_t test_8182;
{
bool_t test_8183;
{
long aux_8184;
aux_8184 = (long)(current_char_37_2432);
test_8183 = (aux_8184>=((long)48));
}
if(test_8183){
long aux_8187;
aux_8187 = (long)(current_char_37_2432);
test_8182 = (aux_8187<((long)60));
}
 else {
test_8182 = ((bool_t)0);
}
}
if(test_8182){
test_8161 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2432)){
case ((long)91) : 
test_8161 = ((bool_t)1);
break;
case ((long)93) : 
test_8161 = ((bool_t)1);
break;
case ((long)123) : 
test_8161 = ((bool_t)1);
break;
case ((long)125) : 
test_8161 = ((bool_t)1);
break;
default: 
{
long aux_8190;
aux_8190 = (long)(current_char_37_2432);
test_8161 = (aux_8190==((long)127));
}
}
}
}
}
}
}
if(test_8161){
aux_7016 = new_match_93_2431;
}
 else {
{
long last_match_133_8195;
last_match_133_8195 = new_match_93_2431;
last_match_133_2373 = last_match_133_8195;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_8196;
{
bool_t test_8197;
{
long aux_8198;
aux_8198 = (long)(current_char_37_1442);
test_8197 = (aux_8198<((long)33));
}
if(test_8197){
test_8196 = ((bool_t)1);
}
 else {
bool_t test_8201;
{
bool_t test_8202;
{
long aux_8203;
aux_8203 = (long)(current_char_37_1442);
test_8202 = (aux_8203==((long)35));
}
if(test_8202){
test_8201 = ((bool_t)1);
}
 else {
long aux_8206;
aux_8206 = (long)(current_char_37_1442);
test_8201 = (aux_8206==((long)34));
}
}
if(test_8201){
test_8196 = ((bool_t)1);
}
 else {
bool_t test_8209;
{
bool_t test_8210;
{
long aux_8211;
aux_8211 = (long)(current_char_37_1442);
test_8210 = (aux_8211==((long)41));
}
if(test_8210){
test_8209 = ((bool_t)1);
}
 else {
long aux_8214;
aux_8214 = (long)(current_char_37_1442);
test_8209 = (aux_8214==((long)40));
}
}
if(test_8209){
test_8196 = ((bool_t)1);
}
 else {
if(test2087_1447){
test_8196 = ((bool_t)1);
}
 else {
bool_t test_8218;
{
bool_t test_8219;
{
long aux_8220;
aux_8220 = (long)(current_char_37_1442);
test_8219 = (aux_8220>=((long)48));
}
if(test_8219){
long aux_8223;
aux_8223 = (long)(current_char_37_1442);
test_8218 = (aux_8223<((long)60));
}
 else {
test_8218 = ((bool_t)0);
}
}
if(test_8218){
test_8196 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1442)){
case ((long)91) : 
test_8196 = ((bool_t)1);
break;
case ((long)93) : 
test_8196 = ((bool_t)1);
break;
case ((long)123) : 
test_8196 = ((bool_t)1);
break;
case ((long)125) : 
test_8196 = ((bool_t)1);
break;
default: 
{
long aux_8226;
aux_8226 = (long)(current_char_37_1442);
test_8196 = (aux_8226==((long)127));
}
}
}
}
}
}
}
}
if(test_8196){
aux_7016 = new_match_93_1441;
}
 else {
{
long last_match_133_8231;
last_match_133_8231 = new_match_93_1441;
last_match_133_2373 = last_match_133_8231;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
}
}
break;
case ((long)93) : 
case ((long)41) : 
{
long new_match_93_5319;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5319 = ((long)33);
aux_7016 = new_match_93_5319;
}
break;
case ((long)91) : 
case ((long)40) : 
{
long new_match_93_5322;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5322 = ((long)32);
aux_7016 = new_match_93_5322;
}
break;
case ((long)39) : 
{
long new_match_93_5325;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5325 = ((long)28);
aux_7016 = new_match_93_5325;
}
break;
case ((long)35) : 
last_match_133_1840 = last_match_133_1870;
state_6_1008_99_2765:
{
long new_match_93_1842;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1842 = ((long)38);
{
int current_char_37_1843;
current_char_37_1843 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
switch ((long)(current_char_37_1843)){
case ((long)123) : 
{
long new_match_93_5262;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5262 = ((long)36);
aux_7016 = new_match_93_5262;
}
break;
case ((long)120) : 
last_match_133_1554 = new_match_93_1842;
state_53_1055_121_2779:
{
int current_char_37_1556;
current_char_37_1556 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8239;
{
long aux_8240;
aux_8240 = (long)(current_char_37_1556);
test_8239 = (aux_8240==((long)0));
}
if(test_8239){
{
bool_t test2175_1558;
{
bool_t res3383_4723;
{
bool_t _andtest_1237_4720;
_andtest_1237_4720 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4720){
res3383_4723 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3383_4723 = ((bool_t)0);
}
}
test2175_1558 = res3383_4723;
}
if(test2175_1558){
goto state_53_1055_121_2779;
}
 else {
aux_7016 = last_match_133_1554;
}
}
}
 else {
bool_t test_8247;
{
bool_t test_8248;
{
bool_t test_8249;
{
long aux_8250;
aux_8250 = (long)(current_char_37_1556);
test_8249 = (aux_8250>=((long)48));
}
if(test_8249){
long aux_8253;
aux_8253 = (long)(current_char_37_1556);
test_8248 = (aux_8253<((long)58));
}
 else {
test_8248 = ((bool_t)0);
}
}
if(test_8248){
test_8247 = ((bool_t)1);
}
 else {
bool_t test_8256;
{
bool_t test_8257;
{
long aux_8258;
aux_8258 = (long)(current_char_37_1556);
test_8257 = (aux_8258>=((long)65));
}
if(test_8257){
long aux_8261;
aux_8261 = (long)(current_char_37_1556);
test_8256 = (aux_8261<((long)71));
}
 else {
test_8256 = ((bool_t)0);
}
}
if(test_8256){
test_8247 = ((bool_t)1);
}
 else {
bool_t test_8264;
{
long aux_8265;
aux_8265 = (long)(current_char_37_1556);
test_8264 = (aux_8265>=((long)97));
}
if(test_8264){
long aux_8268;
aux_8268 = (long)(current_char_37_1556);
test_8247 = (aux_8268<((long)103));
}
 else {
test_8247 = ((bool_t)0);
}
}
}
}
if(test_8247){
last_match_133_1790 = last_match_133_1554;
state_57_1059_102_2767:
{
long new_match_93_1792;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1792 = ((long)15);
{
int current_char_37_1793;
current_char_37_1793 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8273;
{
long aux_8274;
aux_8274 = (long)(current_char_37_1793);
test_8273 = (aux_8274==((long)0));
}
if(test_8273){
{
bool_t test2365_1795;
{
bool_t res3394_5169;
{
bool_t _andtest_1237_5166;
_andtest_1237_5166 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5166){
res3394_5169 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3394_5169 = ((bool_t)0);
}
}
test2365_1795 = res3394_5169;
}
if(test2365_1795){
goto state_57_1059_102_2767;
}
 else {
aux_7016 = new_match_93_1792;
}
}
}
 else {
bool_t test_8281;
{
bool_t test_8282;
{
bool_t test_8283;
{
long aux_8284;
aux_8284 = (long)(current_char_37_1793);
test_8283 = (aux_8284>=((long)48));
}
if(test_8283){
long aux_8287;
aux_8287 = (long)(current_char_37_1793);
test_8282 = (aux_8287<((long)58));
}
 else {
test_8282 = ((bool_t)0);
}
}
if(test_8282){
test_8281 = ((bool_t)1);
}
 else {
bool_t test_8290;
{
bool_t test_8291;
{
long aux_8292;
aux_8292 = (long)(current_char_37_1793);
test_8291 = (aux_8292>=((long)65));
}
if(test_8291){
long aux_8295;
aux_8295 = (long)(current_char_37_1793);
test_8290 = (aux_8295<((long)71));
}
 else {
test_8290 = ((bool_t)0);
}
}
if(test_8290){
test_8281 = ((bool_t)1);
}
 else {
bool_t test_8298;
{
long aux_8299;
aux_8299 = (long)(current_char_37_1793);
test_8298 = (aux_8299>=((long)97));
}
if(test_8298){
long aux_8302;
aux_8302 = (long)(current_char_37_1793);
test_8281 = (aux_8302<((long)103));
}
 else {
test_8281 = ((bool_t)0);
}
}
}
}
if(test_8281){
{
long last_match_133_8305;
last_match_133_8305 = new_match_93_1792;
last_match_133_1790 = last_match_133_8305;
goto state_57_1059_102_2767;
}
}
 else {
bool_t test2367_1797;
{
long aux_8306;
aux_8306 = (long)(current_char_37_1793);
test2367_1797 = (aux_8306==((long)40));
}
if(test2367_1797){
{
long new_match_93_5185;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5185 = ((long)35);
aux_7016 = new_match_93_5185;
}
}
 else {
bool_t test_8311;
{
bool_t test_8312;
{
long aux_8313;
aux_8313 = (long)(current_char_37_1793);
test_8312 = (aux_8313<((long)33));
}
if(test_8312){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8316;
{
bool_t test_8317;
{
long aux_8318;
aux_8318 = (long)(current_char_37_1793);
test_8317 = (aux_8318==((long)35));
}
if(test_8317){
test_8316 = ((bool_t)1);
}
 else {
long aux_8321;
aux_8321 = (long)(current_char_37_1793);
test_8316 = (aux_8321==((long)34));
}
}
if(test_8316){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8324;
{
bool_t test_8325;
{
long aux_8326;
aux_8326 = (long)(current_char_37_1793);
test_8325 = (aux_8326==((long)41));
}
if(test_8325){
test_8324 = ((bool_t)1);
}
 else {
test_8324 = test2367_1797;
}
}
if(test_8324){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8329;
{
bool_t test_8330;
{
long aux_8331;
aux_8331 = (long)(current_char_37_1793);
test_8330 = (aux_8331>=((long)48));
}
if(test_8330){
long aux_8334;
aux_8334 = (long)(current_char_37_1793);
test_8329 = (aux_8334<((long)58));
}
 else {
test_8329 = ((bool_t)0);
}
}
if(test_8329){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8337;
{
long aux_8338;
aux_8338 = (long)(current_char_37_1793);
test_8337 = (aux_8338==((long)59));
}
if(test_8337){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8341;
{
bool_t test_8342;
{
long aux_8343;
aux_8343 = (long)(current_char_37_1793);
test_8342 = (aux_8343>=((long)65));
}
if(test_8342){
long aux_8346;
aux_8346 = (long)(current_char_37_1793);
test_8341 = (aux_8346<((long)71));
}
 else {
test_8341 = ((bool_t)0);
}
}
if(test_8341){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8349;
{
long aux_8350;
aux_8350 = (long)(current_char_37_1793);
test_8349 = (aux_8350==((long)91));
}
if(test_8349){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8353;
{
long aux_8354;
aux_8354 = (long)(current_char_37_1793);
test_8353 = (aux_8354==((long)93));
}
if(test_8353){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8357;
{
bool_t test_8358;
{
long aux_8359;
aux_8359 = (long)(current_char_37_1793);
test_8358 = (aux_8359>=((long)97));
}
if(test_8358){
long aux_8362;
aux_8362 = (long)(current_char_37_1793);
test_8357 = (aux_8362<((long)103));
}
 else {
test_8357 = ((bool_t)0);
}
}
if(test_8357){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8365;
{
long aux_8366;
aux_8366 = (long)(current_char_37_1793);
test_8365 = (aux_8366==((long)123));
}
if(test_8365){
test_8311 = ((bool_t)1);
}
 else {
bool_t test_8369;
{
long aux_8370;
aux_8370 = (long)(current_char_37_1793);
test_8369 = (aux_8370==((long)125));
}
if(test_8369){
test_8311 = ((bool_t)1);
}
 else {
long aux_8373;
aux_8373 = (long)(current_char_37_1793);
test_8311 = (aux_8373==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_8311){
aux_7016 = new_match_93_1792;
}
 else {
last_match_133_1002 = new_match_93_1792;
state_39_1041_8_2804:
{
int current_char_37_1004;
current_char_37_1004 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8377;
{
long aux_8378;
aux_8378 = (long)(current_char_37_1004);
test_8377 = (aux_8378==((long)0));
}
if(test_8377){
{
bool_t test1723_1006;
{
bool_t res3361_3668;
{
bool_t _andtest_1237_3665;
_andtest_1237_3665 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3665){
res3361_3668 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3361_3668 = ((bool_t)0);
}
}
test1723_1006 = res3361_3668;
}
if(test1723_1006){
goto state_39_1041_8_2804;
}
 else {
aux_7016 = last_match_133_1002;
}
}
}
 else {
bool_t test1724_1007;
{
long aux_8385;
aux_8385 = (long)(current_char_37_1004);
test1724_1007 = (aux_8385==((long)40));
}
if(test1724_1007){
{
long new_match_93_3672;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3672 = ((long)35);
aux_7016 = new_match_93_3672;
}
}
 else {
bool_t test_8390;
{
bool_t test_8391;
{
long aux_8392;
aux_8392 = (long)(current_char_37_1004);
test_8391 = (aux_8392<((long)33));
}
if(test_8391){
test_8390 = ((bool_t)1);
}
 else {
bool_t test_8395;
{
bool_t test_8396;
{
long aux_8397;
aux_8397 = (long)(current_char_37_1004);
test_8396 = (aux_8397==((long)35));
}
if(test_8396){
test_8395 = ((bool_t)1);
}
 else {
long aux_8400;
aux_8400 = (long)(current_char_37_1004);
test_8395 = (aux_8400==((long)34));
}
}
if(test_8395){
test_8390 = ((bool_t)1);
}
 else {
bool_t test_8403;
{
bool_t test_8404;
{
long aux_8405;
aux_8405 = (long)(current_char_37_1004);
test_8404 = (aux_8405==((long)41));
}
if(test_8404){
test_8403 = ((bool_t)1);
}
 else {
test_8403 = test1724_1007;
}
}
if(test_8403){
test_8390 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1004)){
case ((long)59) : 
test_8390 = ((bool_t)1);
break;
case ((long)91) : 
test_8390 = ((bool_t)1);
break;
case ((long)93) : 
test_8390 = ((bool_t)1);
break;
case ((long)123) : 
test_8390 = ((bool_t)1);
break;
case ((long)125) : 
test_8390 = ((bool_t)1);
break;
default: 
{
long aux_8408;
aux_8408 = (long)(current_char_37_1004);
test_8390 = (aux_8408==((long)127));
}
}
}
}
}
}
if(test_8390){
aux_7016 = last_match_133_1002;
}
 else {
{
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_8413;
{
bool_t test_8414;
{
long aux_8415;
aux_8415 = (long)(current_char_37_1556);
test_8414 = (aux_8415==((long)43));
}
if(test_8414){
test_8413 = ((bool_t)1);
}
 else {
long aux_8418;
aux_8418 = (long)(current_char_37_1556);
test_8413 = (aux_8418==((long)45));
}
}
if(test_8413){
last_match_133_1587 = last_match_133_1554;
state_56_1058_30_2778:
{
int current_char_37_1589;
current_char_37_1589 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8422;
{
long aux_8423;
aux_8423 = (long)(current_char_37_1589);
test_8422 = (aux_8423==((long)0));
}
if(test_8422){
{
bool_t test2205_1591;
{
bool_t res3384_4790;
{
bool_t _andtest_1237_4787;
_andtest_1237_4787 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4787){
res3384_4790 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3384_4790 = ((bool_t)0);
}
}
test2205_1591 = res3384_4790;
}
if(test2205_1591){
goto state_56_1058_30_2778;
}
 else {
aux_7016 = last_match_133_1587;
}
}
}
 else {
bool_t test_8430;
{
bool_t test_8431;
{
bool_t test_8432;
{
long aux_8433;
aux_8433 = (long)(current_char_37_1589);
test_8432 = (aux_8433>=((long)48));
}
if(test_8432){
long aux_8436;
aux_8436 = (long)(current_char_37_1589);
test_8431 = (aux_8436<((long)58));
}
 else {
test_8431 = ((bool_t)0);
}
}
if(test_8431){
test_8430 = ((bool_t)1);
}
 else {
bool_t test_8439;
{
bool_t test_8440;
{
long aux_8441;
aux_8441 = (long)(current_char_37_1589);
test_8440 = (aux_8441>=((long)65));
}
if(test_8440){
long aux_8444;
aux_8444 = (long)(current_char_37_1589);
test_8439 = (aux_8444<((long)71));
}
 else {
test_8439 = ((bool_t)0);
}
}
if(test_8439){
test_8430 = ((bool_t)1);
}
 else {
bool_t test_8447;
{
long aux_8448;
aux_8448 = (long)(current_char_37_1589);
test_8447 = (aux_8448>=((long)97));
}
if(test_8447){
long aux_8451;
aux_8451 = (long)(current_char_37_1589);
test_8430 = (aux_8451<((long)103));
}
 else {
test_8430 = ((bool_t)0);
}
}
}
}
if(test_8430){
{
long last_match_133_8454;
last_match_133_8454 = last_match_133_1587;
last_match_133_1790 = last_match_133_8454;
goto state_57_1059_102_2767;
}
}
 else {
bool_t test2207_1593;
{
long aux_8455;
aux_8455 = (long)(current_char_37_1589);
test2207_1593 = (aux_8455==((long)40));
}
if(test2207_1593){
{
long new_match_93_4806;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4806 = ((long)35);
aux_7016 = new_match_93_4806;
}
}
 else {
bool_t test_8460;
{
bool_t test_8461;
{
long aux_8462;
aux_8462 = (long)(current_char_37_1589);
test_8461 = (aux_8462<((long)33));
}
if(test_8461){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8465;
{
bool_t test_8466;
{
long aux_8467;
aux_8467 = (long)(current_char_37_1589);
test_8466 = (aux_8467==((long)35));
}
if(test_8466){
test_8465 = ((bool_t)1);
}
 else {
long aux_8470;
aux_8470 = (long)(current_char_37_1589);
test_8465 = (aux_8470==((long)34));
}
}
if(test_8465){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8473;
{
bool_t test_8474;
{
long aux_8475;
aux_8475 = (long)(current_char_37_1589);
test_8474 = (aux_8475==((long)41));
}
if(test_8474){
test_8473 = ((bool_t)1);
}
 else {
test_8473 = test2207_1593;
}
}
if(test_8473){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8478;
{
bool_t test_8479;
{
long aux_8480;
aux_8480 = (long)(current_char_37_1589);
test_8479 = (aux_8480>=((long)48));
}
if(test_8479){
long aux_8483;
aux_8483 = (long)(current_char_37_1589);
test_8478 = (aux_8483<((long)58));
}
 else {
test_8478 = ((bool_t)0);
}
}
if(test_8478){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8486;
{
long aux_8487;
aux_8487 = (long)(current_char_37_1589);
test_8486 = (aux_8487==((long)59));
}
if(test_8486){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8490;
{
bool_t test_8491;
{
long aux_8492;
aux_8492 = (long)(current_char_37_1589);
test_8491 = (aux_8492>=((long)65));
}
if(test_8491){
long aux_8495;
aux_8495 = (long)(current_char_37_1589);
test_8490 = (aux_8495<((long)71));
}
 else {
test_8490 = ((bool_t)0);
}
}
if(test_8490){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8498;
{
long aux_8499;
aux_8499 = (long)(current_char_37_1589);
test_8498 = (aux_8499==((long)91));
}
if(test_8498){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8502;
{
long aux_8503;
aux_8503 = (long)(current_char_37_1589);
test_8502 = (aux_8503==((long)93));
}
if(test_8502){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8506;
{
bool_t test_8507;
{
long aux_8508;
aux_8508 = (long)(current_char_37_1589);
test_8507 = (aux_8508>=((long)97));
}
if(test_8507){
long aux_8511;
aux_8511 = (long)(current_char_37_1589);
test_8506 = (aux_8511<((long)103));
}
 else {
test_8506 = ((bool_t)0);
}
}
if(test_8506){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8514;
{
long aux_8515;
aux_8515 = (long)(current_char_37_1589);
test_8514 = (aux_8515==((long)123));
}
if(test_8514){
test_8460 = ((bool_t)1);
}
 else {
bool_t test_8518;
{
long aux_8519;
aux_8519 = (long)(current_char_37_1589);
test_8518 = (aux_8519==((long)125));
}
if(test_8518){
test_8460 = ((bool_t)1);
}
 else {
long aux_8522;
aux_8522 = (long)(current_char_37_1589);
test_8460 = (aux_8522==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_8460){
aux_7016 = last_match_133_1587;
}
 else {
{
long last_match_133_8525;
last_match_133_8525 = last_match_133_1587;
last_match_133_1002 = last_match_133_8525;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test2178_1561;
{
long aux_8526;
aux_8526 = (long)(current_char_37_1556);
test2178_1561 = (aux_8526==((long)40));
}
if(test2178_1561){
{
long new_match_93_4743;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4743 = ((long)35);
aux_7016 = new_match_93_4743;
}
}
 else {
bool_t test_8531;
{
bool_t test_8532;
{
long aux_8533;
aux_8533 = (long)(current_char_37_1556);
test_8532 = (aux_8533<((long)33));
}
if(test_8532){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8536;
{
bool_t test_8537;
{
long aux_8538;
aux_8538 = (long)(current_char_37_1556);
test_8537 = (aux_8538==((long)35));
}
if(test_8537){
test_8536 = ((bool_t)1);
}
 else {
long aux_8541;
aux_8541 = (long)(current_char_37_1556);
test_8536 = (aux_8541==((long)34));
}
}
if(test_8536){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8544;
{
bool_t test_8545;
{
long aux_8546;
aux_8546 = (long)(current_char_37_1556);
test_8545 = (aux_8546==((long)41));
}
if(test_8545){
test_8544 = ((bool_t)1);
}
 else {
test_8544 = test2178_1561;
}
}
if(test_8544){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8549;
{
long aux_8550;
aux_8550 = (long)(current_char_37_1556);
test_8549 = (aux_8550==((long)43));
}
if(test_8549){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8553;
{
long aux_8554;
aux_8554 = (long)(current_char_37_1556);
test_8553 = (aux_8554==((long)45));
}
if(test_8553){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8557;
{
bool_t test_8558;
{
long aux_8559;
aux_8559 = (long)(current_char_37_1556);
test_8558 = (aux_8559>=((long)48));
}
if(test_8558){
long aux_8562;
aux_8562 = (long)(current_char_37_1556);
test_8557 = (aux_8562<((long)58));
}
 else {
test_8557 = ((bool_t)0);
}
}
if(test_8557){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8565;
{
long aux_8566;
aux_8566 = (long)(current_char_37_1556);
test_8565 = (aux_8566==((long)59));
}
if(test_8565){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8569;
{
bool_t test_8570;
{
long aux_8571;
aux_8571 = (long)(current_char_37_1556);
test_8570 = (aux_8571>=((long)65));
}
if(test_8570){
long aux_8574;
aux_8574 = (long)(current_char_37_1556);
test_8569 = (aux_8574<((long)71));
}
 else {
test_8569 = ((bool_t)0);
}
}
if(test_8569){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8577;
{
long aux_8578;
aux_8578 = (long)(current_char_37_1556);
test_8577 = (aux_8578==((long)91));
}
if(test_8577){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8581;
{
long aux_8582;
aux_8582 = (long)(current_char_37_1556);
test_8581 = (aux_8582==((long)93));
}
if(test_8581){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8585;
{
bool_t test_8586;
{
long aux_8587;
aux_8587 = (long)(current_char_37_1556);
test_8586 = (aux_8587>=((long)97));
}
if(test_8586){
long aux_8590;
aux_8590 = (long)(current_char_37_1556);
test_8585 = (aux_8590<((long)103));
}
 else {
test_8585 = ((bool_t)0);
}
}
if(test_8585){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8593;
{
long aux_8594;
aux_8594 = (long)(current_char_37_1556);
test_8593 = (aux_8594==((long)123));
}
if(test_8593){
test_8531 = ((bool_t)1);
}
 else {
bool_t test_8597;
{
long aux_8598;
aux_8598 = (long)(current_char_37_1556);
test_8597 = (aux_8598==((long)125));
}
if(test_8597){
test_8531 = ((bool_t)1);
}
 else {
long aux_8601;
aux_8601 = (long)(current_char_37_1556);
test_8531 = (aux_8601==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_8531){
aux_7016 = last_match_133_1554;
}
 else {
{
long last_match_133_8604;
last_match_133_8604 = last_match_133_1554;
last_match_133_1002 = last_match_133_8604;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
break;
case ((long)117) : 
last_match_133_2043 = new_match_93_1842;
state_52_1054_53_2754:
{
int current_char_37_2045;
current_char_37_2045 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8606;
{
long aux_8607;
aux_8607 = (long)(current_char_37_2045);
test_8606 = (aux_8607==((long)0));
}
if(test_8606){
{
bool_t test2565_2047;
{
bool_t res3404_5652;
{
bool_t _andtest_1237_5649;
_andtest_1237_5649 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5649){
res3404_5652 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3404_5652 = ((bool_t)0);
}
}
test2565_2047 = res3404_5652;
}
if(test2565_2047){
goto state_52_1054_53_2754;
}
 else {
aux_7016 = last_match_133_2043;
}
}
}
 else {
bool_t test_8614;
{
bool_t test_8615;
{
long aux_8616;
aux_8616 = (long)(current_char_37_2045);
test_8615 = (aux_8616>=((long)98));
}
if(test_8615){
long aux_8619;
aux_8619 = (long)(current_char_37_2045);
test_8614 = (aux_8619<((long)103));
}
 else {
test_8614 = ((bool_t)0);
}
}
if(test_8614){
last_match_133_1993 = last_match_133_2043;
state_61_1063_199_2756:
{
long new_match_93_1995;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1995 = ((long)22);
{
int current_char_37_1996;
current_char_37_1996 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8624;
{
long aux_8625;
aux_8625 = (long)(current_char_37_1996);
test_8624 = (aux_8625==((long)0));
}
if(test_8624){
{
bool_t test2521_1998;
{
bool_t res3403_5557;
{
bool_t _andtest_1237_5554;
_andtest_1237_5554 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5554){
res3403_5557 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3403_5557 = ((bool_t)0);
}
}
test2521_1998 = res3403_5557;
}
if(test2521_1998){
goto state_61_1063_199_2756;
}
 else {
aux_7016 = new_match_93_1995;
}
}
}
 else {
bool_t test_8632;
{
bool_t test_8633;
{
long aux_8634;
aux_8634 = (long)(current_char_37_1996);
test_8633 = (aux_8634>=((long)98));
}
if(test_8633){
long aux_8637;
aux_8637 = (long)(current_char_37_1996);
test_8632 = (aux_8637<((long)103));
}
 else {
test_8632 = ((bool_t)0);
}
}
if(test_8632){
last_match_133_1305 = new_match_93_1995;
state_63_1065_132_2789:
{
long new_match_93_1307;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1307 = ((long)22);
{
int current_char_37_1308;
current_char_37_1308 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8642;
{
long aux_8643;
aux_8643 = (long)(current_char_37_1308);
test_8642 = (aux_8643==((long)0));
}
if(test_8642){
{
bool_t test1970_1310;
{
bool_t res3373_4240;
{
bool_t _andtest_1237_4237;
_andtest_1237_4237 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4237){
res3373_4240 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3373_4240 = ((bool_t)0);
}
}
test1970_1310 = res3373_4240;
}
if(test1970_1310){
goto state_63_1065_132_2789;
}
 else {
aux_7016 = new_match_93_1307;
}
}
}
 else {
bool_t test_8650;
{
bool_t test_8651;
{
long aux_8652;
aux_8652 = (long)(current_char_37_1308);
test_8651 = (aux_8652>=((long)98));
}
if(test_8651){
long aux_8655;
aux_8655 = (long)(current_char_37_1308);
test_8650 = (aux_8655<((long)103));
}
 else {
test_8650 = ((bool_t)0);
}
}
if(test_8650){
last_match_133_1229 = new_match_93_1307;
state_65_1067_75_2791:
{
long new_match_93_1231;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1231 = ((long)22);
{
int current_char_37_1232;
current_char_37_1232 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8660;
{
long aux_8661;
aux_8661 = (long)(current_char_37_1232);
test_8660 = (aux_8661==((long)0));
}
if(test_8660){
{
bool_t test1901_1234;
{
bool_t res3371_4087;
{
bool_t _andtest_1237_4084;
_andtest_1237_4084 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4084){
res3371_4087 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3371_4087 = ((bool_t)0);
}
}
test1901_1234 = res3371_4087;
}
if(test1901_1234){
goto state_65_1067_75_2791;
}
 else {
aux_7016 = new_match_93_1231;
}
}
}
 else {
bool_t test_8668;
{
bool_t test_8669;
{
long aux_8670;
aux_8670 = (long)(current_char_37_1232);
test_8669 = (aux_8670>=((long)98));
}
if(test_8669){
long aux_8673;
aux_8673 = (long)(current_char_37_1232);
test_8668 = (aux_8673<((long)103));
}
 else {
test_8668 = ((bool_t)0);
}
}
if(test_8668){
last_match_133_2128 = new_match_93_1231;
state_67_1069_63_2752:
{
long new_match_93_2130;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2130 = ((long)8);
{
int current_char_37_2131;
current_char_37_2131 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8678;
{
long aux_8679;
aux_8679 = (long)(current_char_37_2131);
test_8678 = (aux_8679==((long)0));
}
if(test_8678){
{
bool_t test2643_2133;
{
bool_t res3406_5824;
{
bool_t _andtest_1237_5821;
_andtest_1237_5821 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5821){
res3406_5824 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3406_5824 = ((bool_t)0);
}
}
test2643_2133 = res3406_5824;
}
if(test2643_2133){
goto state_67_1069_63_2752;
}
 else {
aux_7016 = new_match_93_2130;
}
}
}
 else {
bool_t test_8686;
{
bool_t test_8687;
{
long aux_8688;
aux_8688 = (long)(current_char_37_2131);
test_8687 = (aux_8688==((long)45));
}
if(test_8687){
test_8686 = ((bool_t)1);
}
 else {
bool_t test_8691;
{
bool_t test_8692;
{
long aux_8693;
aux_8693 = (long)(current_char_37_2131);
test_8692 = (aux_8693>=((long)98));
}
if(test_8692){
long aux_8696;
aux_8696 = (long)(current_char_37_2131);
test_8691 = (aux_8696<((long)103));
}
 else {
test_8691 = ((bool_t)0);
}
}
if(test_8691){
test_8686 = ((bool_t)1);
}
 else {
bool_t test_8699;
{
bool_t test_8700;
{
long aux_8701;
aux_8701 = (long)(current_char_37_2131);
test_8700 = (aux_8701==((long)106));
}
if(test_8700){
test_8699 = ((bool_t)1);
}
 else {
long aux_8704;
aux_8704 = (long)(current_char_37_2131);
test_8699 = (aux_8704==((long)105));
}
}
if(test_8699){
test_8686 = ((bool_t)1);
}
 else {
bool_t test_8707;
{
bool_t test_8708;
{
long aux_8709;
aux_8709 = (long)(current_char_37_2131);
test_8708 = (aux_8709==((long)112));
}
if(test_8708){
test_8707 = ((bool_t)1);
}
 else {
bool_t test_8712;
{
long aux_8713;
aux_8713 = (long)(current_char_37_2131);
test_8712 = (aux_8713==((long)111));
}
if(test_8712){
test_8707 = ((bool_t)1);
}
 else {
long aux_8716;
aux_8716 = (long)(current_char_37_2131);
test_8707 = (aux_8716==((long)110));
}
}
}
if(test_8707){
test_8686 = ((bool_t)1);
}
 else {
bool_t _ortest_1144_2161;
{
long aux_8719;
aux_8719 = (long)(current_char_37_2131);
_ortest_1144_2161 = (aux_8719==((long)116));
}
if(_ortest_1144_2161){
test_8686 = _ortest_1144_2161;
}
 else {
long aux_8723;
aux_8723 = (long)(current_char_37_2131);
test_8686 = (aux_8723==((long)115));
}
}
}
}
}
}
if(test_8686){
last_match_133_2090 = new_match_93_2130;
state_59_1061_245_2753:
{
long new_match_93_2092;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2092 = ((long)22);
{
int current_char_37_2093;
current_char_37_2093 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8728;
{
long aux_8729;
aux_8729 = (long)(current_char_37_2093);
test_8728 = (aux_8729==((long)0));
}
if(test_8728){
{
bool_t test2609_2095;
{
bool_t res3405_5748;
{
bool_t _andtest_1237_5745;
_andtest_1237_5745 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5745){
res3405_5748 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3405_5748 = ((bool_t)0);
}
}
test2609_2095 = res3405_5748;
}
if(test2609_2095){
goto state_59_1061_245_2753;
}
 else {
aux_7016 = new_match_93_2092;
}
}
}
 else {
bool_t test_8736;
{
bool_t test_8737;
{
long aux_8738;
aux_8738 = (long)(current_char_37_2093);
test_8737 = (aux_8738==((long)45));
}
if(test_8737){
test_8736 = ((bool_t)1);
}
 else {
bool_t test_8741;
{
bool_t test_8742;
{
long aux_8743;
aux_8743 = (long)(current_char_37_2093);
test_8742 = (aux_8743>=((long)98));
}
if(test_8742){
long aux_8746;
aux_8746 = (long)(current_char_37_2093);
test_8741 = (aux_8746<((long)103));
}
 else {
test_8741 = ((bool_t)0);
}
}
if(test_8741){
test_8736 = ((bool_t)1);
}
 else {
bool_t test_8749;
{
bool_t test_8750;
{
long aux_8751;
aux_8751 = (long)(current_char_37_2093);
test_8750 = (aux_8751==((long)106));
}
if(test_8750){
test_8749 = ((bool_t)1);
}
 else {
long aux_8754;
aux_8754 = (long)(current_char_37_2093);
test_8749 = (aux_8754==((long)105));
}
}
if(test_8749){
test_8736 = ((bool_t)1);
}
 else {
bool_t test_8757;
{
bool_t test_8758;
{
long aux_8759;
aux_8759 = (long)(current_char_37_2093);
test_8758 = (aux_8759==((long)112));
}
if(test_8758){
test_8757 = ((bool_t)1);
}
 else {
bool_t test_8762;
{
long aux_8763;
aux_8763 = (long)(current_char_37_2093);
test_8762 = (aux_8763==((long)111));
}
if(test_8762){
test_8757 = ((bool_t)1);
}
 else {
long aux_8766;
aux_8766 = (long)(current_char_37_2093);
test_8757 = (aux_8766==((long)110));
}
}
}
if(test_8757){
test_8736 = ((bool_t)1);
}
 else {
bool_t _ortest_1145_2123;
{
long aux_8769;
aux_8769 = (long)(current_char_37_2093);
_ortest_1145_2123 = (aux_8769==((long)116));
}
if(_ortest_1145_2123){
test_8736 = _ortest_1145_2123;
}
 else {
long aux_8773;
aux_8773 = (long)(current_char_37_2093);
test_8736 = (aux_8773==((long)115));
}
}
}
}
}
}
if(test_8736){
{
long last_match_133_8776;
last_match_133_8776 = new_match_93_2092;
last_match_133_2090 = last_match_133_8776;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test2611_2097;
{
long aux_8777;
aux_8777 = (long)(current_char_37_2093);
test2611_2097 = (aux_8777==((long)40));
}
if(test2611_2097){
{
long new_match_93_5772;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5772 = ((long)35);
aux_7016 = new_match_93_5772;
}
}
 else {
bool_t test_8782;
{
bool_t test_8783;
{
long aux_8784;
aux_8784 = (long)(current_char_37_2093);
test_8783 = (aux_8784<((long)33));
}
if(test_8783){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8787;
{
bool_t test_8788;
{
long aux_8789;
aux_8789 = (long)(current_char_37_2093);
test_8788 = (aux_8789==((long)35));
}
if(test_8788){
test_8787 = ((bool_t)1);
}
 else {
long aux_8792;
aux_8792 = (long)(current_char_37_2093);
test_8787 = (aux_8792==((long)34));
}
}
if(test_8787){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8795;
{
bool_t test_8796;
{
long aux_8797;
aux_8797 = (long)(current_char_37_2093);
test_8796 = (aux_8797==((long)41));
}
if(test_8796){
test_8795 = ((bool_t)1);
}
 else {
test_8795 = test2611_2097;
}
}
if(test_8795){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8800;
{
long aux_8801;
aux_8801 = (long)(current_char_37_2093);
test_8800 = (aux_8801==((long)45));
}
if(test_8800){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8804;
{
long aux_8805;
aux_8805 = (long)(current_char_37_2093);
test_8804 = (aux_8805==((long)59));
}
if(test_8804){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8808;
{
long aux_8809;
aux_8809 = (long)(current_char_37_2093);
test_8808 = (aux_8809==((long)91));
}
if(test_8808){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8812;
{
long aux_8813;
aux_8813 = (long)(current_char_37_2093);
test_8812 = (aux_8813==((long)93));
}
if(test_8812){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8816;
{
bool_t test_8817;
{
long aux_8818;
aux_8818 = (long)(current_char_37_2093);
test_8817 = (aux_8818>=((long)98));
}
if(test_8817){
long aux_8821;
aux_8821 = (long)(current_char_37_2093);
test_8816 = (aux_8821<((long)103));
}
 else {
test_8816 = ((bool_t)0);
}
}
if(test_8816){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8824;
{
bool_t test_8825;
{
long aux_8826;
aux_8826 = (long)(current_char_37_2093);
test_8825 = (aux_8826==((long)106));
}
if(test_8825){
test_8824 = ((bool_t)1);
}
 else {
long aux_8829;
aux_8829 = (long)(current_char_37_2093);
test_8824 = (aux_8829==((long)105));
}
}
if(test_8824){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8832;
{
bool_t test_8833;
{
long aux_8834;
aux_8834 = (long)(current_char_37_2093);
test_8833 = (aux_8834==((long)112));
}
if(test_8833){
test_8832 = ((bool_t)1);
}
 else {
bool_t test_8837;
{
long aux_8838;
aux_8838 = (long)(current_char_37_2093);
test_8837 = (aux_8838==((long)111));
}
if(test_8837){
test_8832 = ((bool_t)1);
}
 else {
long aux_8841;
aux_8841 = (long)(current_char_37_2093);
test_8832 = (aux_8841==((long)110));
}
}
}
if(test_8832){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8844;
{
bool_t test_8845;
{
long aux_8846;
aux_8846 = (long)(current_char_37_2093);
test_8845 = (aux_8846==((long)116));
}
if(test_8845){
test_8844 = ((bool_t)1);
}
 else {
long aux_8849;
aux_8849 = (long)(current_char_37_2093);
test_8844 = (aux_8849==((long)115));
}
}
if(test_8844){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8852;
{
long aux_8853;
aux_8853 = (long)(current_char_37_2093);
test_8852 = (aux_8853==((long)123));
}
if(test_8852){
test_8782 = ((bool_t)1);
}
 else {
bool_t test_8856;
{
long aux_8857;
aux_8857 = (long)(current_char_37_2093);
test_8856 = (aux_8857==((long)125));
}
if(test_8856){
test_8782 = ((bool_t)1);
}
 else {
long aux_8860;
aux_8860 = (long)(current_char_37_2093);
test_8782 = (aux_8860==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_8782){
aux_7016 = new_match_93_2092;
}
 else {
{
long last_match_133_8863;
last_match_133_8863 = new_match_93_2092;
last_match_133_1002 = last_match_133_8863;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test2645_2135;
{
long aux_8864;
aux_8864 = (long)(current_char_37_2131);
test2645_2135 = (aux_8864==((long)40));
}
if(test2645_2135){
{
long new_match_93_5848;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5848 = ((long)35);
aux_7016 = new_match_93_5848;
}
}
 else {
bool_t test_8869;
{
bool_t test_8870;
{
long aux_8871;
aux_8871 = (long)(current_char_37_2131);
test_8870 = (aux_8871<((long)33));
}
if(test_8870){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8874;
{
bool_t test_8875;
{
long aux_8876;
aux_8876 = (long)(current_char_37_2131);
test_8875 = (aux_8876==((long)35));
}
if(test_8875){
test_8874 = ((bool_t)1);
}
 else {
long aux_8879;
aux_8879 = (long)(current_char_37_2131);
test_8874 = (aux_8879==((long)34));
}
}
if(test_8874){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8882;
{
bool_t test_8883;
{
long aux_8884;
aux_8884 = (long)(current_char_37_2131);
test_8883 = (aux_8884==((long)41));
}
if(test_8883){
test_8882 = ((bool_t)1);
}
 else {
test_8882 = test2645_2135;
}
}
if(test_8882){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8887;
{
long aux_8888;
aux_8888 = (long)(current_char_37_2131);
test_8887 = (aux_8888==((long)45));
}
if(test_8887){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8891;
{
long aux_8892;
aux_8892 = (long)(current_char_37_2131);
test_8891 = (aux_8892==((long)59));
}
if(test_8891){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8895;
{
long aux_8896;
aux_8896 = (long)(current_char_37_2131);
test_8895 = (aux_8896==((long)91));
}
if(test_8895){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8899;
{
long aux_8900;
aux_8900 = (long)(current_char_37_2131);
test_8899 = (aux_8900==((long)93));
}
if(test_8899){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8903;
{
bool_t test_8904;
{
long aux_8905;
aux_8905 = (long)(current_char_37_2131);
test_8904 = (aux_8905>=((long)98));
}
if(test_8904){
long aux_8908;
aux_8908 = (long)(current_char_37_2131);
test_8903 = (aux_8908<((long)103));
}
 else {
test_8903 = ((bool_t)0);
}
}
if(test_8903){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8911;
{
bool_t test_8912;
{
long aux_8913;
aux_8913 = (long)(current_char_37_2131);
test_8912 = (aux_8913==((long)106));
}
if(test_8912){
test_8911 = ((bool_t)1);
}
 else {
long aux_8916;
aux_8916 = (long)(current_char_37_2131);
test_8911 = (aux_8916==((long)105));
}
}
if(test_8911){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8919;
{
bool_t test_8920;
{
long aux_8921;
aux_8921 = (long)(current_char_37_2131);
test_8920 = (aux_8921==((long)112));
}
if(test_8920){
test_8919 = ((bool_t)1);
}
 else {
bool_t test_8924;
{
long aux_8925;
aux_8925 = (long)(current_char_37_2131);
test_8924 = (aux_8925==((long)111));
}
if(test_8924){
test_8919 = ((bool_t)1);
}
 else {
long aux_8928;
aux_8928 = (long)(current_char_37_2131);
test_8919 = (aux_8928==((long)110));
}
}
}
if(test_8919){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8931;
{
bool_t test_8932;
{
long aux_8933;
aux_8933 = (long)(current_char_37_2131);
test_8932 = (aux_8933==((long)116));
}
if(test_8932){
test_8931 = ((bool_t)1);
}
 else {
long aux_8936;
aux_8936 = (long)(current_char_37_2131);
test_8931 = (aux_8936==((long)115));
}
}
if(test_8931){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8939;
{
long aux_8940;
aux_8940 = (long)(current_char_37_2131);
test_8939 = (aux_8940==((long)123));
}
if(test_8939){
test_8869 = ((bool_t)1);
}
 else {
bool_t test_8943;
{
long aux_8944;
aux_8944 = (long)(current_char_37_2131);
test_8943 = (aux_8944==((long)125));
}
if(test_8943){
test_8869 = ((bool_t)1);
}
 else {
long aux_8947;
aux_8947 = (long)(current_char_37_2131);
test_8869 = (aux_8947==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_8869){
aux_7016 = new_match_93_2130;
}
 else {
{
long last_match_133_8950;
last_match_133_8950 = new_match_93_2130;
last_match_133_1002 = last_match_133_8950;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_8951;
{
bool_t test_8952;
{
bool_t test_8953;
{
long aux_8954;
aux_8954 = (long)(current_char_37_1232);
test_8953 = (aux_8954>=((long)48));
}
if(test_8953){
long aux_8957;
aux_8957 = (long)(current_char_37_1232);
test_8952 = (aux_8957<((long)58));
}
 else {
test_8952 = ((bool_t)0);
}
}
if(test_8952){
test_8951 = ((bool_t)1);
}
 else {
bool_t test_8960;
{
bool_t test_8961;
{
long aux_8962;
aux_8962 = (long)(current_char_37_1232);
test_8961 = (aux_8962>=((long)65));
}
if(test_8961){
long aux_8965;
aux_8965 = (long)(current_char_37_1232);
test_8960 = (aux_8965<((long)71));
}
 else {
test_8960 = ((bool_t)0);
}
}
if(test_8960){
test_8951 = ((bool_t)1);
}
 else {
long aux_8968;
aux_8968 = (long)(current_char_37_1232);
test_8951 = (aux_8968==((long)97));
}
}
}
if(test_8951){
last_match_133_1069 = new_match_93_1231;
state_66_1068_31_2800:
{
long new_match_93_1071;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1071 = ((long)8);
{
int current_char_37_1072;
current_char_37_1072 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_8973;
{
long aux_8974;
aux_8974 = (long)(current_char_37_1072);
test_8973 = (aux_8974==((long)0));
}
if(test_8973){
{
bool_t test1772_1074;
{
bool_t res3365_3794;
{
bool_t _andtest_1237_3791;
_andtest_1237_3791 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3791){
res3365_3794 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3365_3794 = ((bool_t)0);
}
}
test1772_1074 = res3365_3794;
}
if(test1772_1074){
goto state_66_1068_31_2800;
}
 else {
aux_7016 = new_match_93_1071;
}
}
}
 else {
bool_t test1773_1075;
{
long aux_8981;
aux_8981 = (long)(current_char_37_1072);
test1773_1075 = (aux_8981==((long)40));
}
if(test1773_1075){
{
long new_match_93_3798;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3798 = ((long)35);
aux_7016 = new_match_93_3798;
}
}
 else {
bool_t test_8986;
{
bool_t test_8987;
{
long aux_8988;
aux_8988 = (long)(current_char_37_1072);
test_8987 = (aux_8988<((long)33));
}
if(test_8987){
test_8986 = ((bool_t)1);
}
 else {
bool_t test_8991;
{
bool_t test_8992;
{
long aux_8993;
aux_8993 = (long)(current_char_37_1072);
test_8992 = (aux_8993==((long)35));
}
if(test_8992){
test_8991 = ((bool_t)1);
}
 else {
long aux_8996;
aux_8996 = (long)(current_char_37_1072);
test_8991 = (aux_8996==((long)34));
}
}
if(test_8991){
test_8986 = ((bool_t)1);
}
 else {
bool_t test_8999;
{
bool_t test_9000;
{
long aux_9001;
aux_9001 = (long)(current_char_37_1072);
test_9000 = (aux_9001==((long)41));
}
if(test_9000){
test_8999 = ((bool_t)1);
}
 else {
test_8999 = test1773_1075;
}
}
if(test_8999){
test_8986 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1072)){
case ((long)59) : 
test_8986 = ((bool_t)1);
break;
case ((long)91) : 
test_8986 = ((bool_t)1);
break;
case ((long)93) : 
test_8986 = ((bool_t)1);
break;
case ((long)123) : 
test_8986 = ((bool_t)1);
break;
case ((long)125) : 
test_8986 = ((bool_t)1);
break;
default: 
{
long aux_9004;
aux_9004 = (long)(current_char_37_1072);
test_8986 = (aux_9004==((long)127));
}
}
}
}
}
}
if(test_8986){
aux_7016 = new_match_93_1071;
}
 else {
{
long last_match_133_9009;
last_match_133_9009 = new_match_93_1071;
last_match_133_1002 = last_match_133_9009;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test_9010;
{
bool_t test_9011;
{
long aux_9012;
aux_9012 = (long)(current_char_37_1232);
test_9011 = (aux_9012==((long)45));
}
if(test_9011){
test_9010 = ((bool_t)1);
}
 else {
bool_t test_9015;
{
bool_t test_9016;
{
long aux_9017;
aux_9017 = (long)(current_char_37_1232);
test_9016 = (aux_9017==((long)106));
}
if(test_9016){
test_9015 = ((bool_t)1);
}
 else {
long aux_9020;
aux_9020 = (long)(current_char_37_1232);
test_9015 = (aux_9020==((long)105));
}
}
if(test_9015){
test_9010 = ((bool_t)1);
}
 else {
bool_t test_9023;
{
bool_t test_9024;
{
long aux_9025;
aux_9025 = (long)(current_char_37_1232);
test_9024 = (aux_9025==((long)112));
}
if(test_9024){
test_9023 = ((bool_t)1);
}
 else {
bool_t test_9028;
{
long aux_9029;
aux_9029 = (long)(current_char_37_1232);
test_9028 = (aux_9029==((long)111));
}
if(test_9028){
test_9023 = ((bool_t)1);
}
 else {
long aux_9032;
aux_9032 = (long)(current_char_37_1232);
test_9023 = (aux_9032==((long)110));
}
}
}
if(test_9023){
test_9010 = ((bool_t)1);
}
 else {
bool_t _ortest_1201_1267;
{
long aux_9035;
aux_9035 = (long)(current_char_37_1232);
_ortest_1201_1267 = (aux_9035==((long)116));
}
if(_ortest_1201_1267){
test_9010 = _ortest_1201_1267;
}
 else {
long aux_9039;
aux_9039 = (long)(current_char_37_1232);
test_9010 = (aux_9039==((long)115));
}
}
}
}
}
if(test_9010){
{
long last_match_133_9042;
last_match_133_9042 = new_match_93_1231;
last_match_133_2090 = last_match_133_9042;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test1905_1238;
{
long aux_9043;
aux_9043 = (long)(current_char_37_1232);
test1905_1238 = (aux_9043==((long)40));
}
if(test1905_1238){
{
long new_match_93_4121;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4121 = ((long)35);
aux_7016 = new_match_93_4121;
}
}
 else {
bool_t test_9048;
{
bool_t test_9049;
{
long aux_9050;
aux_9050 = (long)(current_char_37_1232);
test_9049 = (aux_9050<((long)33));
}
if(test_9049){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9053;
{
bool_t test_9054;
{
long aux_9055;
aux_9055 = (long)(current_char_37_1232);
test_9054 = (aux_9055==((long)35));
}
if(test_9054){
test_9053 = ((bool_t)1);
}
 else {
long aux_9058;
aux_9058 = (long)(current_char_37_1232);
test_9053 = (aux_9058==((long)34));
}
}
if(test_9053){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9061;
{
bool_t test_9062;
{
long aux_9063;
aux_9063 = (long)(current_char_37_1232);
test_9062 = (aux_9063==((long)41));
}
if(test_9062){
test_9061 = ((bool_t)1);
}
 else {
test_9061 = test1905_1238;
}
}
if(test_9061){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9066;
{
long aux_9067;
aux_9067 = (long)(current_char_37_1232);
test_9066 = (aux_9067==((long)45));
}
if(test_9066){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9070;
{
bool_t test_9071;
{
long aux_9072;
aux_9072 = (long)(current_char_37_1232);
test_9071 = (aux_9072>=((long)48));
}
if(test_9071){
long aux_9075;
aux_9075 = (long)(current_char_37_1232);
test_9070 = (aux_9075<((long)58));
}
 else {
test_9070 = ((bool_t)0);
}
}
if(test_9070){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9078;
{
long aux_9079;
aux_9079 = (long)(current_char_37_1232);
test_9078 = (aux_9079==((long)59));
}
if(test_9078){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9082;
{
bool_t test_9083;
{
long aux_9084;
aux_9084 = (long)(current_char_37_1232);
test_9083 = (aux_9084>=((long)65));
}
if(test_9083){
long aux_9087;
aux_9087 = (long)(current_char_37_1232);
test_9082 = (aux_9087<((long)71));
}
 else {
test_9082 = ((bool_t)0);
}
}
if(test_9082){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9090;
{
long aux_9091;
aux_9091 = (long)(current_char_37_1232);
test_9090 = (aux_9091==((long)91));
}
if(test_9090){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9094;
{
long aux_9095;
aux_9095 = (long)(current_char_37_1232);
test_9094 = (aux_9095==((long)93));
}
if(test_9094){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9098;
{
bool_t test_9099;
{
long aux_9100;
aux_9100 = (long)(current_char_37_1232);
test_9099 = (aux_9100>=((long)97));
}
if(test_9099){
long aux_9103;
aux_9103 = (long)(current_char_37_1232);
test_9098 = (aux_9103<((long)103));
}
 else {
test_9098 = ((bool_t)0);
}
}
if(test_9098){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9106;
{
bool_t test_9107;
{
long aux_9108;
aux_9108 = (long)(current_char_37_1232);
test_9107 = (aux_9108==((long)106));
}
if(test_9107){
test_9106 = ((bool_t)1);
}
 else {
long aux_9111;
aux_9111 = (long)(current_char_37_1232);
test_9106 = (aux_9111==((long)105));
}
}
if(test_9106){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9114;
{
bool_t test_9115;
{
long aux_9116;
aux_9116 = (long)(current_char_37_1232);
test_9115 = (aux_9116==((long)112));
}
if(test_9115){
test_9114 = ((bool_t)1);
}
 else {
bool_t test_9119;
{
long aux_9120;
aux_9120 = (long)(current_char_37_1232);
test_9119 = (aux_9120==((long)111));
}
if(test_9119){
test_9114 = ((bool_t)1);
}
 else {
long aux_9123;
aux_9123 = (long)(current_char_37_1232);
test_9114 = (aux_9123==((long)110));
}
}
}
if(test_9114){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9126;
{
bool_t test_9127;
{
long aux_9128;
aux_9128 = (long)(current_char_37_1232);
test_9127 = (aux_9128==((long)116));
}
if(test_9127){
test_9126 = ((bool_t)1);
}
 else {
long aux_9131;
aux_9131 = (long)(current_char_37_1232);
test_9126 = (aux_9131==((long)115));
}
}
if(test_9126){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9134;
{
long aux_9135;
aux_9135 = (long)(current_char_37_1232);
test_9134 = (aux_9135==((long)123));
}
if(test_9134){
test_9048 = ((bool_t)1);
}
 else {
bool_t test_9138;
{
long aux_9139;
aux_9139 = (long)(current_char_37_1232);
test_9138 = (aux_9139==((long)125));
}
if(test_9138){
test_9048 = ((bool_t)1);
}
 else {
long aux_9142;
aux_9142 = (long)(current_char_37_1232);
test_9048 = (aux_9142==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9048){
aux_7016 = new_match_93_1231;
}
 else {
{
long last_match_133_9145;
last_match_133_9145 = new_match_93_1231;
last_match_133_1002 = last_match_133_9145;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_9146;
{
bool_t test_9147;
{
bool_t test_9148;
{
long aux_9149;
aux_9149 = (long)(current_char_37_1308);
test_9148 = (aux_9149>=((long)48));
}
if(test_9148){
long aux_9152;
aux_9152 = (long)(current_char_37_1308);
test_9147 = (aux_9152<((long)58));
}
 else {
test_9147 = ((bool_t)0);
}
}
if(test_9147){
test_9146 = ((bool_t)1);
}
 else {
bool_t test_9155;
{
bool_t test_9156;
{
long aux_9157;
aux_9157 = (long)(current_char_37_1308);
test_9156 = (aux_9157>=((long)65));
}
if(test_9156){
long aux_9160;
aux_9160 = (long)(current_char_37_1308);
test_9155 = (aux_9160<((long)71));
}
 else {
test_9155 = ((bool_t)0);
}
}
if(test_9155){
test_9146 = ((bool_t)1);
}
 else {
long aux_9163;
aux_9163 = (long)(current_char_37_1308);
test_9146 = (aux_9163==((long)97));
}
}
}
if(test_9146){
last_match_133_2604 = new_match_93_1307;
state_64_1066_225_2720:
{
int current_char_37_2606;
current_char_37_2606 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_9167;
{
long aux_9168;
aux_9168 = (long)(current_char_37_2606);
test_9167 = (aux_9168==((long)0));
}
if(test_9167){
{
bool_t test3002_2608;
{
bool_t res3427_6675;
{
bool_t _andtest_1237_6672;
_andtest_1237_6672 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6672){
res3427_6675 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3427_6675 = ((bool_t)0);
}
}
test3002_2608 = res3427_6675;
}
if(test3002_2608){
goto state_64_1066_225_2720;
}
 else {
aux_7016 = last_match_133_2604;
}
}
}
 else {
bool_t test_9175;
{
bool_t test_9176;
{
bool_t test_9177;
{
long aux_9178;
aux_9178 = (long)(current_char_37_2606);
test_9177 = (aux_9178>=((long)48));
}
if(test_9177){
long aux_9181;
aux_9181 = (long)(current_char_37_2606);
test_9176 = (aux_9181<((long)58));
}
 else {
test_9176 = ((bool_t)0);
}
}
if(test_9176){
test_9175 = ((bool_t)1);
}
 else {
bool_t test_9184;
{
bool_t test_9185;
{
long aux_9186;
aux_9186 = (long)(current_char_37_2606);
test_9185 = (aux_9186>=((long)65));
}
if(test_9185){
long aux_9189;
aux_9189 = (long)(current_char_37_2606);
test_9184 = (aux_9189<((long)71));
}
 else {
test_9184 = ((bool_t)0);
}
}
if(test_9184){
test_9175 = ((bool_t)1);
}
 else {
bool_t test_9192;
{
long aux_9193;
aux_9193 = (long)(current_char_37_2606);
test_9192 = (aux_9193>=((long)97));
}
if(test_9192){
long aux_9196;
aux_9196 = (long)(current_char_37_2606);
test_9175 = (aux_9196<((long)103));
}
 else {
test_9175 = ((bool_t)0);
}
}
}
}
if(test_9175){
{
long last_match_133_9199;
last_match_133_9199 = last_match_133_2604;
last_match_133_1069 = last_match_133_9199;
goto state_66_1068_31_2800;
}
}
 else {
bool_t test3004_2610;
{
long aux_9200;
aux_9200 = (long)(current_char_37_2606);
test3004_2610 = (aux_9200==((long)40));
}
if(test3004_2610){
{
long new_match_93_6691;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6691 = ((long)35);
aux_7016 = new_match_93_6691;
}
}
 else {
bool_t test_9205;
{
bool_t test_9206;
{
long aux_9207;
aux_9207 = (long)(current_char_37_2606);
test_9206 = (aux_9207<((long)33));
}
if(test_9206){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9210;
{
bool_t test_9211;
{
long aux_9212;
aux_9212 = (long)(current_char_37_2606);
test_9211 = (aux_9212==((long)35));
}
if(test_9211){
test_9210 = ((bool_t)1);
}
 else {
long aux_9215;
aux_9215 = (long)(current_char_37_2606);
test_9210 = (aux_9215==((long)34));
}
}
if(test_9210){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9218;
{
bool_t test_9219;
{
long aux_9220;
aux_9220 = (long)(current_char_37_2606);
test_9219 = (aux_9220==((long)41));
}
if(test_9219){
test_9218 = ((bool_t)1);
}
 else {
test_9218 = test3004_2610;
}
}
if(test_9218){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9223;
{
bool_t test_9224;
{
long aux_9225;
aux_9225 = (long)(current_char_37_2606);
test_9224 = (aux_9225>=((long)48));
}
if(test_9224){
long aux_9228;
aux_9228 = (long)(current_char_37_2606);
test_9223 = (aux_9228<((long)58));
}
 else {
test_9223 = ((bool_t)0);
}
}
if(test_9223){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9231;
{
long aux_9232;
aux_9232 = (long)(current_char_37_2606);
test_9231 = (aux_9232==((long)59));
}
if(test_9231){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9235;
{
bool_t test_9236;
{
long aux_9237;
aux_9237 = (long)(current_char_37_2606);
test_9236 = (aux_9237>=((long)65));
}
if(test_9236){
long aux_9240;
aux_9240 = (long)(current_char_37_2606);
test_9235 = (aux_9240<((long)71));
}
 else {
test_9235 = ((bool_t)0);
}
}
if(test_9235){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9243;
{
long aux_9244;
aux_9244 = (long)(current_char_37_2606);
test_9243 = (aux_9244==((long)91));
}
if(test_9243){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9247;
{
long aux_9248;
aux_9248 = (long)(current_char_37_2606);
test_9247 = (aux_9248==((long)93));
}
if(test_9247){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9251;
{
bool_t test_9252;
{
long aux_9253;
aux_9253 = (long)(current_char_37_2606);
test_9252 = (aux_9253>=((long)97));
}
if(test_9252){
long aux_9256;
aux_9256 = (long)(current_char_37_2606);
test_9251 = (aux_9256<((long)103));
}
 else {
test_9251 = ((bool_t)0);
}
}
if(test_9251){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9259;
{
long aux_9260;
aux_9260 = (long)(current_char_37_2606);
test_9259 = (aux_9260==((long)123));
}
if(test_9259){
test_9205 = ((bool_t)1);
}
 else {
bool_t test_9263;
{
long aux_9264;
aux_9264 = (long)(current_char_37_2606);
test_9263 = (aux_9264==((long)125));
}
if(test_9263){
test_9205 = ((bool_t)1);
}
 else {
long aux_9267;
aux_9267 = (long)(current_char_37_2606);
test_9205 = (aux_9267==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9205){
aux_7016 = last_match_133_2604;
}
 else {
{
long last_match_133_9270;
last_match_133_9270 = last_match_133_2604;
last_match_133_1002 = last_match_133_9270;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test_9271;
{
bool_t test_9272;
{
long aux_9273;
aux_9273 = (long)(current_char_37_1308);
test_9272 = (aux_9273==((long)45));
}
if(test_9272){
test_9271 = ((bool_t)1);
}
 else {
bool_t test_9276;
{
bool_t test_9277;
{
long aux_9278;
aux_9278 = (long)(current_char_37_1308);
test_9277 = (aux_9278==((long)106));
}
if(test_9277){
test_9276 = ((bool_t)1);
}
 else {
long aux_9281;
aux_9281 = (long)(current_char_37_1308);
test_9276 = (aux_9281==((long)105));
}
}
if(test_9276){
test_9271 = ((bool_t)1);
}
 else {
bool_t test_9284;
{
bool_t test_9285;
{
long aux_9286;
aux_9286 = (long)(current_char_37_1308);
test_9285 = (aux_9286==((long)112));
}
if(test_9285){
test_9284 = ((bool_t)1);
}
 else {
bool_t test_9289;
{
long aux_9290;
aux_9290 = (long)(current_char_37_1308);
test_9289 = (aux_9290==((long)111));
}
if(test_9289){
test_9284 = ((bool_t)1);
}
 else {
long aux_9293;
aux_9293 = (long)(current_char_37_1308);
test_9284 = (aux_9293==((long)110));
}
}
}
if(test_9284){
test_9271 = ((bool_t)1);
}
 else {
bool_t _ortest_1199_1343;
{
long aux_9296;
aux_9296 = (long)(current_char_37_1308);
_ortest_1199_1343 = (aux_9296==((long)116));
}
if(_ortest_1199_1343){
test_9271 = _ortest_1199_1343;
}
 else {
long aux_9300;
aux_9300 = (long)(current_char_37_1308);
test_9271 = (aux_9300==((long)115));
}
}
}
}
}
if(test_9271){
{
long last_match_133_9303;
last_match_133_9303 = new_match_93_1307;
last_match_133_2090 = last_match_133_9303;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test1974_1314;
{
long aux_9304;
aux_9304 = (long)(current_char_37_1308);
test1974_1314 = (aux_9304==((long)40));
}
if(test1974_1314){
{
long new_match_93_4274;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4274 = ((long)35);
aux_7016 = new_match_93_4274;
}
}
 else {
bool_t test_9309;
{
bool_t test_9310;
{
long aux_9311;
aux_9311 = (long)(current_char_37_1308);
test_9310 = (aux_9311<((long)33));
}
if(test_9310){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9314;
{
bool_t test_9315;
{
long aux_9316;
aux_9316 = (long)(current_char_37_1308);
test_9315 = (aux_9316==((long)35));
}
if(test_9315){
test_9314 = ((bool_t)1);
}
 else {
long aux_9319;
aux_9319 = (long)(current_char_37_1308);
test_9314 = (aux_9319==((long)34));
}
}
if(test_9314){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9322;
{
bool_t test_9323;
{
long aux_9324;
aux_9324 = (long)(current_char_37_1308);
test_9323 = (aux_9324==((long)41));
}
if(test_9323){
test_9322 = ((bool_t)1);
}
 else {
test_9322 = test1974_1314;
}
}
if(test_9322){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9327;
{
long aux_9328;
aux_9328 = (long)(current_char_37_1308);
test_9327 = (aux_9328==((long)45));
}
if(test_9327){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9331;
{
bool_t test_9332;
{
long aux_9333;
aux_9333 = (long)(current_char_37_1308);
test_9332 = (aux_9333>=((long)48));
}
if(test_9332){
long aux_9336;
aux_9336 = (long)(current_char_37_1308);
test_9331 = (aux_9336<((long)58));
}
 else {
test_9331 = ((bool_t)0);
}
}
if(test_9331){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9339;
{
long aux_9340;
aux_9340 = (long)(current_char_37_1308);
test_9339 = (aux_9340==((long)59));
}
if(test_9339){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9343;
{
bool_t test_9344;
{
long aux_9345;
aux_9345 = (long)(current_char_37_1308);
test_9344 = (aux_9345>=((long)65));
}
if(test_9344){
long aux_9348;
aux_9348 = (long)(current_char_37_1308);
test_9343 = (aux_9348<((long)71));
}
 else {
test_9343 = ((bool_t)0);
}
}
if(test_9343){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9351;
{
long aux_9352;
aux_9352 = (long)(current_char_37_1308);
test_9351 = (aux_9352==((long)91));
}
if(test_9351){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9355;
{
long aux_9356;
aux_9356 = (long)(current_char_37_1308);
test_9355 = (aux_9356==((long)93));
}
if(test_9355){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9359;
{
bool_t test_9360;
{
long aux_9361;
aux_9361 = (long)(current_char_37_1308);
test_9360 = (aux_9361>=((long)97));
}
if(test_9360){
long aux_9364;
aux_9364 = (long)(current_char_37_1308);
test_9359 = (aux_9364<((long)103));
}
 else {
test_9359 = ((bool_t)0);
}
}
if(test_9359){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9367;
{
bool_t test_9368;
{
long aux_9369;
aux_9369 = (long)(current_char_37_1308);
test_9368 = (aux_9369==((long)106));
}
if(test_9368){
test_9367 = ((bool_t)1);
}
 else {
long aux_9372;
aux_9372 = (long)(current_char_37_1308);
test_9367 = (aux_9372==((long)105));
}
}
if(test_9367){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9375;
{
bool_t test_9376;
{
long aux_9377;
aux_9377 = (long)(current_char_37_1308);
test_9376 = (aux_9377==((long)112));
}
if(test_9376){
test_9375 = ((bool_t)1);
}
 else {
bool_t test_9380;
{
long aux_9381;
aux_9381 = (long)(current_char_37_1308);
test_9380 = (aux_9381==((long)111));
}
if(test_9380){
test_9375 = ((bool_t)1);
}
 else {
long aux_9384;
aux_9384 = (long)(current_char_37_1308);
test_9375 = (aux_9384==((long)110));
}
}
}
if(test_9375){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9387;
{
bool_t test_9388;
{
long aux_9389;
aux_9389 = (long)(current_char_37_1308);
test_9388 = (aux_9389==((long)116));
}
if(test_9388){
test_9387 = ((bool_t)1);
}
 else {
long aux_9392;
aux_9392 = (long)(current_char_37_1308);
test_9387 = (aux_9392==((long)115));
}
}
if(test_9387){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9395;
{
long aux_9396;
aux_9396 = (long)(current_char_37_1308);
test_9395 = (aux_9396==((long)123));
}
if(test_9395){
test_9309 = ((bool_t)1);
}
 else {
bool_t test_9399;
{
long aux_9400;
aux_9400 = (long)(current_char_37_1308);
test_9399 = (aux_9400==((long)125));
}
if(test_9399){
test_9309 = ((bool_t)1);
}
 else {
long aux_9403;
aux_9403 = (long)(current_char_37_1308);
test_9309 = (aux_9403==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9309){
aux_7016 = new_match_93_1307;
}
 else {
{
long last_match_133_9406;
last_match_133_9406 = new_match_93_1307;
last_match_133_1002 = last_match_133_9406;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_9407;
{
bool_t test_9408;
{
bool_t test_9409;
{
long aux_9410;
aux_9410 = (long)(current_char_37_1996);
test_9409 = (aux_9410>=((long)48));
}
if(test_9409){
long aux_9413;
aux_9413 = (long)(current_char_37_1996);
test_9408 = (aux_9413<((long)58));
}
 else {
test_9408 = ((bool_t)0);
}
}
if(test_9408){
test_9407 = ((bool_t)1);
}
 else {
bool_t test_9416;
{
bool_t test_9417;
{
long aux_9418;
aux_9418 = (long)(current_char_37_1996);
test_9417 = (aux_9418>=((long)65));
}
if(test_9417){
long aux_9421;
aux_9421 = (long)(current_char_37_1996);
test_9416 = (aux_9421<((long)71));
}
 else {
test_9416 = ((bool_t)0);
}
}
if(test_9416){
test_9407 = ((bool_t)1);
}
 else {
long aux_9424;
aux_9424 = (long)(current_char_37_1996);
test_9407 = (aux_9424==((long)97));
}
}
}
if(test_9407){
last_match_133_1945 = new_match_93_1995;
state_62_1064_174_2758:
{
int current_char_37_1947;
current_char_37_1947 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_9428;
{
long aux_9429;
aux_9429 = (long)(current_char_37_1947);
test_9428 = (aux_9429==((long)0));
}
if(test_9428){
{
bool_t test2480_1949;
{
bool_t res3401_5460;
{
bool_t _andtest_1237_5457;
_andtest_1237_5457 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5457){
res3401_5460 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3401_5460 = ((bool_t)0);
}
}
test2480_1949 = res3401_5460;
}
if(test2480_1949){
goto state_62_1064_174_2758;
}
 else {
aux_7016 = last_match_133_1945;
}
}
}
 else {
bool_t test_9436;
{
bool_t test_9437;
{
bool_t test_9438;
{
long aux_9439;
aux_9439 = (long)(current_char_37_1947);
test_9438 = (aux_9439>=((long)48));
}
if(test_9438){
long aux_9442;
aux_9442 = (long)(current_char_37_1947);
test_9437 = (aux_9442<((long)58));
}
 else {
test_9437 = ((bool_t)0);
}
}
if(test_9437){
test_9436 = ((bool_t)1);
}
 else {
bool_t test_9445;
{
bool_t test_9446;
{
long aux_9447;
aux_9447 = (long)(current_char_37_1947);
test_9446 = (aux_9447>=((long)65));
}
if(test_9446){
long aux_9450;
aux_9450 = (long)(current_char_37_1947);
test_9445 = (aux_9450<((long)71));
}
 else {
test_9445 = ((bool_t)0);
}
}
if(test_9445){
test_9436 = ((bool_t)1);
}
 else {
bool_t test_9453;
{
long aux_9454;
aux_9454 = (long)(current_char_37_1947);
test_9453 = (aux_9454>=((long)97));
}
if(test_9453){
long aux_9457;
aux_9457 = (long)(current_char_37_1947);
test_9436 = (aux_9457<((long)103));
}
 else {
test_9436 = ((bool_t)0);
}
}
}
}
if(test_9436){
{
long last_match_133_9460;
last_match_133_9460 = last_match_133_1945;
last_match_133_2604 = last_match_133_9460;
goto state_64_1066_225_2720;
}
}
 else {
bool_t test2482_1951;
{
long aux_9461;
aux_9461 = (long)(current_char_37_1947);
test2482_1951 = (aux_9461==((long)40));
}
if(test2482_1951){
{
long new_match_93_5476;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5476 = ((long)35);
aux_7016 = new_match_93_5476;
}
}
 else {
bool_t test_9466;
{
bool_t test_9467;
{
long aux_9468;
aux_9468 = (long)(current_char_37_1947);
test_9467 = (aux_9468<((long)33));
}
if(test_9467){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9471;
{
bool_t test_9472;
{
long aux_9473;
aux_9473 = (long)(current_char_37_1947);
test_9472 = (aux_9473==((long)35));
}
if(test_9472){
test_9471 = ((bool_t)1);
}
 else {
long aux_9476;
aux_9476 = (long)(current_char_37_1947);
test_9471 = (aux_9476==((long)34));
}
}
if(test_9471){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9479;
{
bool_t test_9480;
{
long aux_9481;
aux_9481 = (long)(current_char_37_1947);
test_9480 = (aux_9481==((long)41));
}
if(test_9480){
test_9479 = ((bool_t)1);
}
 else {
test_9479 = test2482_1951;
}
}
if(test_9479){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9484;
{
bool_t test_9485;
{
long aux_9486;
aux_9486 = (long)(current_char_37_1947);
test_9485 = (aux_9486>=((long)48));
}
if(test_9485){
long aux_9489;
aux_9489 = (long)(current_char_37_1947);
test_9484 = (aux_9489<((long)58));
}
 else {
test_9484 = ((bool_t)0);
}
}
if(test_9484){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9492;
{
long aux_9493;
aux_9493 = (long)(current_char_37_1947);
test_9492 = (aux_9493==((long)59));
}
if(test_9492){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9496;
{
bool_t test_9497;
{
long aux_9498;
aux_9498 = (long)(current_char_37_1947);
test_9497 = (aux_9498>=((long)65));
}
if(test_9497){
long aux_9501;
aux_9501 = (long)(current_char_37_1947);
test_9496 = (aux_9501<((long)71));
}
 else {
test_9496 = ((bool_t)0);
}
}
if(test_9496){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9504;
{
long aux_9505;
aux_9505 = (long)(current_char_37_1947);
test_9504 = (aux_9505==((long)91));
}
if(test_9504){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9508;
{
long aux_9509;
aux_9509 = (long)(current_char_37_1947);
test_9508 = (aux_9509==((long)93));
}
if(test_9508){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9512;
{
bool_t test_9513;
{
long aux_9514;
aux_9514 = (long)(current_char_37_1947);
test_9513 = (aux_9514>=((long)97));
}
if(test_9513){
long aux_9517;
aux_9517 = (long)(current_char_37_1947);
test_9512 = (aux_9517<((long)103));
}
 else {
test_9512 = ((bool_t)0);
}
}
if(test_9512){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9520;
{
long aux_9521;
aux_9521 = (long)(current_char_37_1947);
test_9520 = (aux_9521==((long)123));
}
if(test_9520){
test_9466 = ((bool_t)1);
}
 else {
bool_t test_9524;
{
long aux_9525;
aux_9525 = (long)(current_char_37_1947);
test_9524 = (aux_9525==((long)125));
}
if(test_9524){
test_9466 = ((bool_t)1);
}
 else {
long aux_9528;
aux_9528 = (long)(current_char_37_1947);
test_9466 = (aux_9528==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9466){
aux_7016 = last_match_133_1945;
}
 else {
{
long last_match_133_9531;
last_match_133_9531 = last_match_133_1945;
last_match_133_1002 = last_match_133_9531;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test_9532;
{
bool_t test_9533;
{
long aux_9534;
aux_9534 = (long)(current_char_37_1996);
test_9533 = (aux_9534==((long)45));
}
if(test_9533){
test_9532 = ((bool_t)1);
}
 else {
bool_t test_9537;
{
bool_t test_9538;
{
long aux_9539;
aux_9539 = (long)(current_char_37_1996);
test_9538 = (aux_9539==((long)106));
}
if(test_9538){
test_9537 = ((bool_t)1);
}
 else {
long aux_9542;
aux_9542 = (long)(current_char_37_1996);
test_9537 = (aux_9542==((long)105));
}
}
if(test_9537){
test_9532 = ((bool_t)1);
}
 else {
bool_t test_9545;
{
bool_t test_9546;
{
long aux_9547;
aux_9547 = (long)(current_char_37_1996);
test_9546 = (aux_9547==((long)112));
}
if(test_9546){
test_9545 = ((bool_t)1);
}
 else {
bool_t test_9550;
{
long aux_9551;
aux_9551 = (long)(current_char_37_1996);
test_9550 = (aux_9551==((long)111));
}
if(test_9550){
test_9545 = ((bool_t)1);
}
 else {
long aux_9554;
aux_9554 = (long)(current_char_37_1996);
test_9545 = (aux_9554==((long)110));
}
}
}
if(test_9545){
test_9532 = ((bool_t)1);
}
 else {
bool_t _ortest_1147_2031;
{
long aux_9557;
aux_9557 = (long)(current_char_37_1996);
_ortest_1147_2031 = (aux_9557==((long)116));
}
if(_ortest_1147_2031){
test_9532 = _ortest_1147_2031;
}
 else {
long aux_9561;
aux_9561 = (long)(current_char_37_1996);
test_9532 = (aux_9561==((long)115));
}
}
}
}
}
if(test_9532){
{
long last_match_133_9564;
last_match_133_9564 = new_match_93_1995;
last_match_133_2090 = last_match_133_9564;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test2525_2002;
{
long aux_9565;
aux_9565 = (long)(current_char_37_1996);
test2525_2002 = (aux_9565==((long)40));
}
if(test2525_2002){
{
long new_match_93_5591;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5591 = ((long)35);
aux_7016 = new_match_93_5591;
}
}
 else {
bool_t test_9570;
{
bool_t test_9571;
{
long aux_9572;
aux_9572 = (long)(current_char_37_1996);
test_9571 = (aux_9572<((long)33));
}
if(test_9571){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9575;
{
bool_t test_9576;
{
long aux_9577;
aux_9577 = (long)(current_char_37_1996);
test_9576 = (aux_9577==((long)35));
}
if(test_9576){
test_9575 = ((bool_t)1);
}
 else {
long aux_9580;
aux_9580 = (long)(current_char_37_1996);
test_9575 = (aux_9580==((long)34));
}
}
if(test_9575){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9583;
{
bool_t test_9584;
{
long aux_9585;
aux_9585 = (long)(current_char_37_1996);
test_9584 = (aux_9585==((long)41));
}
if(test_9584){
test_9583 = ((bool_t)1);
}
 else {
test_9583 = test2525_2002;
}
}
if(test_9583){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9588;
{
long aux_9589;
aux_9589 = (long)(current_char_37_1996);
test_9588 = (aux_9589==((long)45));
}
if(test_9588){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9592;
{
bool_t test_9593;
{
long aux_9594;
aux_9594 = (long)(current_char_37_1996);
test_9593 = (aux_9594>=((long)48));
}
if(test_9593){
long aux_9597;
aux_9597 = (long)(current_char_37_1996);
test_9592 = (aux_9597<((long)58));
}
 else {
test_9592 = ((bool_t)0);
}
}
if(test_9592){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9600;
{
long aux_9601;
aux_9601 = (long)(current_char_37_1996);
test_9600 = (aux_9601==((long)59));
}
if(test_9600){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9604;
{
bool_t test_9605;
{
long aux_9606;
aux_9606 = (long)(current_char_37_1996);
test_9605 = (aux_9606>=((long)65));
}
if(test_9605){
long aux_9609;
aux_9609 = (long)(current_char_37_1996);
test_9604 = (aux_9609<((long)71));
}
 else {
test_9604 = ((bool_t)0);
}
}
if(test_9604){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9612;
{
long aux_9613;
aux_9613 = (long)(current_char_37_1996);
test_9612 = (aux_9613==((long)91));
}
if(test_9612){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9616;
{
long aux_9617;
aux_9617 = (long)(current_char_37_1996);
test_9616 = (aux_9617==((long)93));
}
if(test_9616){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9620;
{
bool_t test_9621;
{
long aux_9622;
aux_9622 = (long)(current_char_37_1996);
test_9621 = (aux_9622>=((long)97));
}
if(test_9621){
long aux_9625;
aux_9625 = (long)(current_char_37_1996);
test_9620 = (aux_9625<((long)103));
}
 else {
test_9620 = ((bool_t)0);
}
}
if(test_9620){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9628;
{
bool_t test_9629;
{
long aux_9630;
aux_9630 = (long)(current_char_37_1996);
test_9629 = (aux_9630==((long)106));
}
if(test_9629){
test_9628 = ((bool_t)1);
}
 else {
long aux_9633;
aux_9633 = (long)(current_char_37_1996);
test_9628 = (aux_9633==((long)105));
}
}
if(test_9628){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9636;
{
bool_t test_9637;
{
long aux_9638;
aux_9638 = (long)(current_char_37_1996);
test_9637 = (aux_9638==((long)112));
}
if(test_9637){
test_9636 = ((bool_t)1);
}
 else {
bool_t test_9641;
{
long aux_9642;
aux_9642 = (long)(current_char_37_1996);
test_9641 = (aux_9642==((long)111));
}
if(test_9641){
test_9636 = ((bool_t)1);
}
 else {
long aux_9645;
aux_9645 = (long)(current_char_37_1996);
test_9636 = (aux_9645==((long)110));
}
}
}
if(test_9636){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9648;
{
bool_t test_9649;
{
long aux_9650;
aux_9650 = (long)(current_char_37_1996);
test_9649 = (aux_9650==((long)116));
}
if(test_9649){
test_9648 = ((bool_t)1);
}
 else {
long aux_9653;
aux_9653 = (long)(current_char_37_1996);
test_9648 = (aux_9653==((long)115));
}
}
if(test_9648){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9656;
{
long aux_9657;
aux_9657 = (long)(current_char_37_1996);
test_9656 = (aux_9657==((long)123));
}
if(test_9656){
test_9570 = ((bool_t)1);
}
 else {
bool_t test_9660;
{
long aux_9661;
aux_9661 = (long)(current_char_37_1996);
test_9660 = (aux_9661==((long)125));
}
if(test_9660){
test_9570 = ((bool_t)1);
}
 else {
long aux_9664;
aux_9664 = (long)(current_char_37_1996);
test_9570 = (aux_9664==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9570){
aux_7016 = new_match_93_1995;
}
 else {
{
long last_match_133_9667;
last_match_133_9667 = new_match_93_1995;
last_match_133_1002 = last_match_133_9667;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test_9668;
{
bool_t test_9669;
{
bool_t test_9670;
{
long aux_9671;
aux_9671 = (long)(current_char_37_2045);
test_9670 = (aux_9671>=((long)48));
}
if(test_9670){
long aux_9674;
aux_9674 = (long)(current_char_37_2045);
test_9669 = (aux_9674<((long)58));
}
 else {
test_9669 = ((bool_t)0);
}
}
if(test_9669){
test_9668 = ((bool_t)1);
}
 else {
bool_t test_9677;
{
bool_t test_9678;
{
long aux_9679;
aux_9679 = (long)(current_char_37_2045);
test_9678 = (aux_9679>=((long)65));
}
if(test_9678){
long aux_9682;
aux_9682 = (long)(current_char_37_2045);
test_9677 = (aux_9682<((long)71));
}
 else {
test_9677 = ((bool_t)0);
}
}
if(test_9677){
test_9668 = ((bool_t)1);
}
 else {
long aux_9685;
aux_9685 = (long)(current_char_37_2045);
test_9668 = (aux_9685==((long)97));
}
}
}
if(test_9668){
last_match_133_1368 = last_match_133_2043;
state_60_1062_30_2787:
{
int current_char_37_1370;
current_char_37_1370 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_9689;
{
long aux_9690;
aux_9690 = (long)(current_char_37_1370);
test_9689 = (aux_9690==((long)0));
}
if(test_9689){
{
bool_t test2024_1372;
{
bool_t res3375_4363;
{
bool_t _andtest_1237_4360;
_andtest_1237_4360 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4360){
res3375_4363 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3375_4363 = ((bool_t)0);
}
}
test2024_1372 = res3375_4363;
}
if(test2024_1372){
goto state_60_1062_30_2787;
}
 else {
aux_7016 = last_match_133_1368;
}
}
}
 else {
bool_t test_9697;
{
bool_t test_9698;
{
bool_t test_9699;
{
long aux_9700;
aux_9700 = (long)(current_char_37_1370);
test_9699 = (aux_9700>=((long)48));
}
if(test_9699){
long aux_9703;
aux_9703 = (long)(current_char_37_1370);
test_9698 = (aux_9703<((long)58));
}
 else {
test_9698 = ((bool_t)0);
}
}
if(test_9698){
test_9697 = ((bool_t)1);
}
 else {
bool_t test_9706;
{
bool_t test_9707;
{
long aux_9708;
aux_9708 = (long)(current_char_37_1370);
test_9707 = (aux_9708>=((long)65));
}
if(test_9707){
long aux_9711;
aux_9711 = (long)(current_char_37_1370);
test_9706 = (aux_9711<((long)71));
}
 else {
test_9706 = ((bool_t)0);
}
}
if(test_9706){
test_9697 = ((bool_t)1);
}
 else {
bool_t test_9714;
{
long aux_9715;
aux_9715 = (long)(current_char_37_1370);
test_9714 = (aux_9715>=((long)97));
}
if(test_9714){
long aux_9718;
aux_9718 = (long)(current_char_37_1370);
test_9697 = (aux_9718<((long)103));
}
 else {
test_9697 = ((bool_t)0);
}
}
}
}
if(test_9697){
{
long last_match_133_9721;
last_match_133_9721 = last_match_133_1368;
last_match_133_1945 = last_match_133_9721;
goto state_62_1064_174_2758;
}
}
 else {
bool_t test2026_1374;
{
long aux_9722;
aux_9722 = (long)(current_char_37_1370);
test2026_1374 = (aux_9722==((long)40));
}
if(test2026_1374){
{
long new_match_93_4379;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4379 = ((long)35);
aux_7016 = new_match_93_4379;
}
}
 else {
bool_t test_9727;
{
bool_t test_9728;
{
long aux_9729;
aux_9729 = (long)(current_char_37_1370);
test_9728 = (aux_9729<((long)33));
}
if(test_9728){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9732;
{
bool_t test_9733;
{
long aux_9734;
aux_9734 = (long)(current_char_37_1370);
test_9733 = (aux_9734==((long)35));
}
if(test_9733){
test_9732 = ((bool_t)1);
}
 else {
long aux_9737;
aux_9737 = (long)(current_char_37_1370);
test_9732 = (aux_9737==((long)34));
}
}
if(test_9732){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9740;
{
bool_t test_9741;
{
long aux_9742;
aux_9742 = (long)(current_char_37_1370);
test_9741 = (aux_9742==((long)41));
}
if(test_9741){
test_9740 = ((bool_t)1);
}
 else {
test_9740 = test2026_1374;
}
}
if(test_9740){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9745;
{
bool_t test_9746;
{
long aux_9747;
aux_9747 = (long)(current_char_37_1370);
test_9746 = (aux_9747>=((long)48));
}
if(test_9746){
long aux_9750;
aux_9750 = (long)(current_char_37_1370);
test_9745 = (aux_9750<((long)58));
}
 else {
test_9745 = ((bool_t)0);
}
}
if(test_9745){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9753;
{
long aux_9754;
aux_9754 = (long)(current_char_37_1370);
test_9753 = (aux_9754==((long)59));
}
if(test_9753){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9757;
{
bool_t test_9758;
{
long aux_9759;
aux_9759 = (long)(current_char_37_1370);
test_9758 = (aux_9759>=((long)65));
}
if(test_9758){
long aux_9762;
aux_9762 = (long)(current_char_37_1370);
test_9757 = (aux_9762<((long)71));
}
 else {
test_9757 = ((bool_t)0);
}
}
if(test_9757){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9765;
{
long aux_9766;
aux_9766 = (long)(current_char_37_1370);
test_9765 = (aux_9766==((long)91));
}
if(test_9765){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9769;
{
long aux_9770;
aux_9770 = (long)(current_char_37_1370);
test_9769 = (aux_9770==((long)93));
}
if(test_9769){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9773;
{
bool_t test_9774;
{
long aux_9775;
aux_9775 = (long)(current_char_37_1370);
test_9774 = (aux_9775>=((long)97));
}
if(test_9774){
long aux_9778;
aux_9778 = (long)(current_char_37_1370);
test_9773 = (aux_9778<((long)103));
}
 else {
test_9773 = ((bool_t)0);
}
}
if(test_9773){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9781;
{
long aux_9782;
aux_9782 = (long)(current_char_37_1370);
test_9781 = (aux_9782==((long)123));
}
if(test_9781){
test_9727 = ((bool_t)1);
}
 else {
bool_t test_9785;
{
long aux_9786;
aux_9786 = (long)(current_char_37_1370);
test_9785 = (aux_9786==((long)125));
}
if(test_9785){
test_9727 = ((bool_t)1);
}
 else {
long aux_9789;
aux_9789 = (long)(current_char_37_1370);
test_9727 = (aux_9789==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9727){
aux_7016 = last_match_133_1368;
}
 else {
{
long last_match_133_9792;
last_match_133_9792 = last_match_133_1368;
last_match_133_1002 = last_match_133_9792;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test_9793;
{
bool_t test_9794;
{
long aux_9795;
aux_9795 = (long)(current_char_37_2045);
test_9794 = (aux_9795==((long)45));
}
if(test_9794){
test_9793 = ((bool_t)1);
}
 else {
bool_t test_9798;
{
bool_t test_9799;
{
long aux_9800;
aux_9800 = (long)(current_char_37_2045);
test_9799 = (aux_9800==((long)106));
}
if(test_9799){
test_9798 = ((bool_t)1);
}
 else {
long aux_9803;
aux_9803 = (long)(current_char_37_2045);
test_9798 = (aux_9803==((long)105));
}
}
if(test_9798){
test_9793 = ((bool_t)1);
}
 else {
bool_t test_9806;
{
bool_t test_9807;
{
long aux_9808;
aux_9808 = (long)(current_char_37_2045);
test_9807 = (aux_9808==((long)112));
}
if(test_9807){
test_9806 = ((bool_t)1);
}
 else {
bool_t test_9811;
{
long aux_9812;
aux_9812 = (long)(current_char_37_2045);
test_9811 = (aux_9812==((long)111));
}
if(test_9811){
test_9806 = ((bool_t)1);
}
 else {
long aux_9815;
aux_9815 = (long)(current_char_37_2045);
test_9806 = (aux_9815==((long)110));
}
}
}
if(test_9806){
test_9793 = ((bool_t)1);
}
 else {
bool_t _ortest_1146_2081;
{
long aux_9818;
aux_9818 = (long)(current_char_37_2045);
_ortest_1146_2081 = (aux_9818==((long)116));
}
if(_ortest_1146_2081){
test_9793 = _ortest_1146_2081;
}
 else {
long aux_9822;
aux_9822 = (long)(current_char_37_2045);
test_9793 = (aux_9822==((long)115));
}
}
}
}
}
if(test_9793){
{
long last_match_133_9825;
last_match_133_9825 = last_match_133_2043;
last_match_133_2090 = last_match_133_9825;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test2569_2051;
{
long aux_9826;
aux_9826 = (long)(current_char_37_2045);
test2569_2051 = (aux_9826==((long)40));
}
if(test2569_2051){
{
long new_match_93_5686;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5686 = ((long)35);
aux_7016 = new_match_93_5686;
}
}
 else {
bool_t test2570_2052;
{
long aux_9831;
aux_9831 = (long)(current_char_37_2045);
test2570_2052 = (aux_9831==((long)34));
}
if(test2570_2052){
last_match_133_2597 = last_match_133_2043;
state_58_1060_12_2721:
{
int current_char_37_2599;
current_char_37_2599 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
switch ((long)(current_char_37_2599)){
case ((long)0) : 
{
bool_t test2999_2603;
{
bool_t res3426_6664;
{
bool_t _andtest_1237_6661;
_andtest_1237_6661 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6661){
res3426_6664 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3426_6664 = ((bool_t)0);
}
}
test2999_2603 = res3426_6664;
}
if(test2999_2603){
goto state_58_1060_12_2721;
}
 else {
aux_7016 = last_match_133_2597;
}
}
break;
case ((long)92) : 
last_match_133_1085 = last_match_133_2597;
state_69_1071_122_2799:
{
int current_char_37_1087;
current_char_37_1087 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_9841;
{
long aux_9842;
aux_9842 = (long)(current_char_37_1087);
test_9841 = (aux_9842==((long)0));
}
if(test_9841){
{
bool_t test1783_1089;
test1783_1089 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(test1783_1089){
bool_t test1784_1090;
test1784_1090 = rgc_fill_buffer(input_port_219_6933);
if(test1784_1090){
goto state_69_1071_122_2799;
}
 else {
aux_7016 = last_match_133_1085;
}
}
 else {
long last_match_133_9849;
last_match_133_9849 = last_match_133_1085;
last_match_133_2597 = last_match_133_9849;
goto state_58_1060_12_2721;
}
}
}
 else {
bool_t test_9850;
{
long aux_9851;
aux_9851 = (long)(current_char_37_1087);
test_9850 = (aux_9851==((long)10));
}
if(test_9850){
aux_7016 = last_match_133_1085;
}
 else {
{
long last_match_133_9854;
last_match_133_9854 = last_match_133_1085;
last_match_133_2597 = last_match_133_9854;
goto state_58_1060_12_2721;
}
}
}
}
}
break;
case ((long)34) : 
{
long new_match_93_6666;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6666 = ((long)11);
aux_7016 = new_match_93_6666;
}
break;
default: 
{
goto state_58_1060_12_2721;
}
}
}
}
 else {
bool_t test_9858;
{
bool_t test_9859;
{
long aux_9860;
aux_9860 = (long)(current_char_37_2045);
test_9859 = (aux_9860<((long)33));
}
if(test_9859){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9863;
{
bool_t test_9864;
{
long aux_9865;
aux_9865 = (long)(current_char_37_2045);
test_9864 = (aux_9865==((long)35));
}
if(test_9864){
test_9863 = ((bool_t)1);
}
 else {
test_9863 = test2570_2052;
}
}
if(test_9863){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9868;
{
bool_t test_9869;
{
long aux_9870;
aux_9870 = (long)(current_char_37_2045);
test_9869 = (aux_9870==((long)41));
}
if(test_9869){
test_9868 = ((bool_t)1);
}
 else {
test_9868 = test2569_2051;
}
}
if(test_9868){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9873;
{
long aux_9874;
aux_9874 = (long)(current_char_37_2045);
test_9873 = (aux_9874==((long)45));
}
if(test_9873){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9877;
{
bool_t test_9878;
{
long aux_9879;
aux_9879 = (long)(current_char_37_2045);
test_9878 = (aux_9879>=((long)48));
}
if(test_9878){
long aux_9882;
aux_9882 = (long)(current_char_37_2045);
test_9877 = (aux_9882<((long)58));
}
 else {
test_9877 = ((bool_t)0);
}
}
if(test_9877){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9885;
{
long aux_9886;
aux_9886 = (long)(current_char_37_2045);
test_9885 = (aux_9886==((long)59));
}
if(test_9885){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9889;
{
bool_t test_9890;
{
long aux_9891;
aux_9891 = (long)(current_char_37_2045);
test_9890 = (aux_9891>=((long)65));
}
if(test_9890){
long aux_9894;
aux_9894 = (long)(current_char_37_2045);
test_9889 = (aux_9894<((long)71));
}
 else {
test_9889 = ((bool_t)0);
}
}
if(test_9889){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9897;
{
long aux_9898;
aux_9898 = (long)(current_char_37_2045);
test_9897 = (aux_9898==((long)91));
}
if(test_9897){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9901;
{
long aux_9902;
aux_9902 = (long)(current_char_37_2045);
test_9901 = (aux_9902==((long)93));
}
if(test_9901){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9905;
{
bool_t test_9906;
{
long aux_9907;
aux_9907 = (long)(current_char_37_2045);
test_9906 = (aux_9907>=((long)97));
}
if(test_9906){
long aux_9910;
aux_9910 = (long)(current_char_37_2045);
test_9905 = (aux_9910<((long)103));
}
 else {
test_9905 = ((bool_t)0);
}
}
if(test_9905){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9913;
{
bool_t test_9914;
{
long aux_9915;
aux_9915 = (long)(current_char_37_2045);
test_9914 = (aux_9915==((long)106));
}
if(test_9914){
test_9913 = ((bool_t)1);
}
 else {
long aux_9918;
aux_9918 = (long)(current_char_37_2045);
test_9913 = (aux_9918==((long)105));
}
}
if(test_9913){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9921;
{
bool_t test_9922;
{
long aux_9923;
aux_9923 = (long)(current_char_37_2045);
test_9922 = (aux_9923==((long)112));
}
if(test_9922){
test_9921 = ((bool_t)1);
}
 else {
bool_t test_9926;
{
long aux_9927;
aux_9927 = (long)(current_char_37_2045);
test_9926 = (aux_9927==((long)111));
}
if(test_9926){
test_9921 = ((bool_t)1);
}
 else {
long aux_9930;
aux_9930 = (long)(current_char_37_2045);
test_9921 = (aux_9930==((long)110));
}
}
}
if(test_9921){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9933;
{
bool_t test_9934;
{
long aux_9935;
aux_9935 = (long)(current_char_37_2045);
test_9934 = (aux_9935==((long)116));
}
if(test_9934){
test_9933 = ((bool_t)1);
}
 else {
long aux_9938;
aux_9938 = (long)(current_char_37_2045);
test_9933 = (aux_9938==((long)115));
}
}
if(test_9933){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9941;
{
long aux_9942;
aux_9942 = (long)(current_char_37_2045);
test_9941 = (aux_9942==((long)123));
}
if(test_9941){
test_9858 = ((bool_t)1);
}
 else {
bool_t test_9945;
{
long aux_9946;
aux_9946 = (long)(current_char_37_2045);
test_9945 = (aux_9946==((long)125));
}
if(test_9945){
test_9858 = ((bool_t)1);
}
 else {
long aux_9949;
aux_9949 = (long)(current_char_37_2045);
test_9858 = (aux_9949==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_9858){
aux_7016 = last_match_133_2043;
}
 else {
{
long last_match_133_9952;
last_match_133_9952 = last_match_133_2043;
last_match_133_1002 = last_match_133_9952;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
break;
case ((long)112) : 
last_match_133_2562 = new_match_93_1842;
state_51_1053_109_2724:
{
int current_char_37_2564;
current_char_37_2564 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_9954;
{
long aux_9955;
aux_9955 = (long)(current_char_37_2564);
test_9954 = (aux_9955==((long)0));
}
if(test_9954){
{
bool_t test2971_2566;
{
bool_t res3425_6603;
{
bool_t _andtest_1237_6600;
_andtest_1237_6600 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6600){
res3425_6603 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3425_6603 = ((bool_t)0);
}
}
test2971_2566 = res3425_6603;
}
if(test2971_2566){
goto state_51_1053_109_2724;
}
 else {
aux_7016 = last_match_133_2562;
}
}
}
 else {
bool_t test_9962;
{
bool_t test_9963;
{
bool_t test_9964;
{
long aux_9965;
aux_9965 = (long)(current_char_37_2564);
test_9964 = (aux_9965>=((long)48));
}
if(test_9964){
long aux_9968;
aux_9968 = (long)(current_char_37_2564);
test_9963 = (aux_9968<((long)58));
}
 else {
test_9963 = ((bool_t)0);
}
}
if(test_9963){
test_9962 = ((bool_t)1);
}
 else {
bool_t test_9971;
{
bool_t test_9972;
{
long aux_9973;
aux_9973 = (long)(current_char_37_2564);
test_9972 = (aux_9973>=((long)65));
}
if(test_9972){
long aux_9976;
aux_9976 = (long)(current_char_37_2564);
test_9971 = (aux_9976<((long)71));
}
 else {
test_9971 = ((bool_t)0);
}
}
if(test_9971){
test_9962 = ((bool_t)1);
}
 else {
bool_t test_9979;
{
long aux_9980;
aux_9980 = (long)(current_char_37_2564);
test_9979 = (aux_9980>=((long)97));
}
if(test_9979){
long aux_9983;
aux_9983 = (long)(current_char_37_2564);
test_9962 = (aux_9983<((long)103));
}
 else {
test_9962 = ((bool_t)0);
}
}
}
}
if(test_9962){
last_match_133_1461 = last_match_133_2562;
state_70_1072_190_2783:
{
long new_match_93_1463;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1463 = ((long)7);
{
int current_char_37_1464;
current_char_37_1464 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_9988;
{
long aux_9989;
aux_9989 = (long)(current_char_37_1464);
test_9988 = (aux_9989==((long)0));
}
if(test_9988){
{
bool_t test2101_1466;
{
bool_t res3379_4544;
{
bool_t _andtest_1237_4541;
_andtest_1237_4541 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4541){
res3379_4544 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3379_4544 = ((bool_t)0);
}
}
test2101_1466 = res3379_4544;
}
if(test2101_1466){
goto state_70_1072_190_2783;
}
 else {
aux_7016 = new_match_93_1463;
}
}
}
 else {
bool_t test_9996;
{
bool_t test_9997;
{
bool_t test_9998;
{
long aux_9999;
aux_9999 = (long)(current_char_37_1464);
test_9998 = (aux_9999>=((long)48));
}
if(test_9998){
long aux_10002;
aux_10002 = (long)(current_char_37_1464);
test_9997 = (aux_10002<((long)58));
}
 else {
test_9997 = ((bool_t)0);
}
}
if(test_9997){
test_9996 = ((bool_t)1);
}
 else {
bool_t test_10005;
{
bool_t test_10006;
{
long aux_10007;
aux_10007 = (long)(current_char_37_1464);
test_10006 = (aux_10007>=((long)65));
}
if(test_10006){
long aux_10010;
aux_10010 = (long)(current_char_37_1464);
test_10005 = (aux_10010<((long)71));
}
 else {
test_10005 = ((bool_t)0);
}
}
if(test_10005){
test_9996 = ((bool_t)1);
}
 else {
bool_t test_10013;
{
long aux_10014;
aux_10014 = (long)(current_char_37_1464);
test_10013 = (aux_10014>=((long)97));
}
if(test_10013){
long aux_10017;
aux_10017 = (long)(current_char_37_1464);
test_9996 = (aux_10017<((long)103));
}
 else {
test_9996 = ((bool_t)0);
}
}
}
}
if(test_9996){
{
long last_match_133_10020;
last_match_133_10020 = new_match_93_1463;
last_match_133_1461 = last_match_133_10020;
goto state_70_1072_190_2783;
}
}
 else {
bool_t test2103_1468;
{
long aux_10021;
aux_10021 = (long)(current_char_37_1464);
test2103_1468 = (aux_10021==((long)40));
}
if(test2103_1468){
{
long new_match_93_4560;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4560 = ((long)35);
aux_7016 = new_match_93_4560;
}
}
 else {
bool_t test_10026;
{
bool_t test_10027;
{
long aux_10028;
aux_10028 = (long)(current_char_37_1464);
test_10027 = (aux_10028<((long)33));
}
if(test_10027){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10031;
{
bool_t test_10032;
{
long aux_10033;
aux_10033 = (long)(current_char_37_1464);
test_10032 = (aux_10033==((long)35));
}
if(test_10032){
test_10031 = ((bool_t)1);
}
 else {
long aux_10036;
aux_10036 = (long)(current_char_37_1464);
test_10031 = (aux_10036==((long)34));
}
}
if(test_10031){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10039;
{
bool_t test_10040;
{
long aux_10041;
aux_10041 = (long)(current_char_37_1464);
test_10040 = (aux_10041==((long)41));
}
if(test_10040){
test_10039 = ((bool_t)1);
}
 else {
test_10039 = test2103_1468;
}
}
if(test_10039){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10044;
{
bool_t test_10045;
{
long aux_10046;
aux_10046 = (long)(current_char_37_1464);
test_10045 = (aux_10046>=((long)48));
}
if(test_10045){
long aux_10049;
aux_10049 = (long)(current_char_37_1464);
test_10044 = (aux_10049<((long)58));
}
 else {
test_10044 = ((bool_t)0);
}
}
if(test_10044){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10052;
{
long aux_10053;
aux_10053 = (long)(current_char_37_1464);
test_10052 = (aux_10053==((long)59));
}
if(test_10052){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10056;
{
bool_t test_10057;
{
long aux_10058;
aux_10058 = (long)(current_char_37_1464);
test_10057 = (aux_10058>=((long)65));
}
if(test_10057){
long aux_10061;
aux_10061 = (long)(current_char_37_1464);
test_10056 = (aux_10061<((long)71));
}
 else {
test_10056 = ((bool_t)0);
}
}
if(test_10056){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10064;
{
long aux_10065;
aux_10065 = (long)(current_char_37_1464);
test_10064 = (aux_10065==((long)91));
}
if(test_10064){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10068;
{
long aux_10069;
aux_10069 = (long)(current_char_37_1464);
test_10068 = (aux_10069==((long)93));
}
if(test_10068){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10072;
{
bool_t test_10073;
{
long aux_10074;
aux_10074 = (long)(current_char_37_1464);
test_10073 = (aux_10074>=((long)97));
}
if(test_10073){
long aux_10077;
aux_10077 = (long)(current_char_37_1464);
test_10072 = (aux_10077<((long)103));
}
 else {
test_10072 = ((bool_t)0);
}
}
if(test_10072){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10080;
{
long aux_10081;
aux_10081 = (long)(current_char_37_1464);
test_10080 = (aux_10081==((long)123));
}
if(test_10080){
test_10026 = ((bool_t)1);
}
 else {
bool_t test_10084;
{
long aux_10085;
aux_10085 = (long)(current_char_37_1464);
test_10084 = (aux_10085==((long)125));
}
if(test_10084){
test_10026 = ((bool_t)1);
}
 else {
long aux_10088;
aux_10088 = (long)(current_char_37_1464);
test_10026 = (aux_10088==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_10026){
aux_7016 = new_match_93_1463;
}
 else {
{
long last_match_133_10091;
last_match_133_10091 = new_match_93_1463;
last_match_133_1002 = last_match_133_10091;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test2973_2568;
{
long aux_10092;
aux_10092 = (long)(current_char_37_2564);
test2973_2568 = (aux_10092==((long)40));
}
if(test2973_2568){
{
long new_match_93_6619;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6619 = ((long)35);
aux_7016 = new_match_93_6619;
}
}
 else {
bool_t test_10097;
{
bool_t test_10098;
{
long aux_10099;
aux_10099 = (long)(current_char_37_2564);
test_10098 = (aux_10099<((long)33));
}
if(test_10098){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10102;
{
bool_t test_10103;
{
long aux_10104;
aux_10104 = (long)(current_char_37_2564);
test_10103 = (aux_10104==((long)35));
}
if(test_10103){
test_10102 = ((bool_t)1);
}
 else {
long aux_10107;
aux_10107 = (long)(current_char_37_2564);
test_10102 = (aux_10107==((long)34));
}
}
if(test_10102){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10110;
{
bool_t test_10111;
{
long aux_10112;
aux_10112 = (long)(current_char_37_2564);
test_10111 = (aux_10112==((long)41));
}
if(test_10111){
test_10110 = ((bool_t)1);
}
 else {
test_10110 = test2973_2568;
}
}
if(test_10110){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10115;
{
bool_t test_10116;
{
long aux_10117;
aux_10117 = (long)(current_char_37_2564);
test_10116 = (aux_10117>=((long)48));
}
if(test_10116){
long aux_10120;
aux_10120 = (long)(current_char_37_2564);
test_10115 = (aux_10120<((long)58));
}
 else {
test_10115 = ((bool_t)0);
}
}
if(test_10115){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10123;
{
long aux_10124;
aux_10124 = (long)(current_char_37_2564);
test_10123 = (aux_10124==((long)59));
}
if(test_10123){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10127;
{
bool_t test_10128;
{
long aux_10129;
aux_10129 = (long)(current_char_37_2564);
test_10128 = (aux_10129>=((long)65));
}
if(test_10128){
long aux_10132;
aux_10132 = (long)(current_char_37_2564);
test_10127 = (aux_10132<((long)71));
}
 else {
test_10127 = ((bool_t)0);
}
}
if(test_10127){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10135;
{
long aux_10136;
aux_10136 = (long)(current_char_37_2564);
test_10135 = (aux_10136==((long)91));
}
if(test_10135){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10139;
{
long aux_10140;
aux_10140 = (long)(current_char_37_2564);
test_10139 = (aux_10140==((long)93));
}
if(test_10139){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10143;
{
bool_t test_10144;
{
long aux_10145;
aux_10145 = (long)(current_char_37_2564);
test_10144 = (aux_10145>=((long)97));
}
if(test_10144){
long aux_10148;
aux_10148 = (long)(current_char_37_2564);
test_10143 = (aux_10148<((long)103));
}
 else {
test_10143 = ((bool_t)0);
}
}
if(test_10143){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10151;
{
long aux_10152;
aux_10152 = (long)(current_char_37_2564);
test_10151 = (aux_10152==((long)123));
}
if(test_10151){
test_10097 = ((bool_t)1);
}
 else {
bool_t test_10155;
{
long aux_10156;
aux_10156 = (long)(current_char_37_2564);
test_10155 = (aux_10156==((long)125));
}
if(test_10155){
test_10097 = ((bool_t)1);
}
 else {
long aux_10159;
aux_10159 = (long)(current_char_37_2564);
test_10097 = (aux_10159==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_10097){
aux_7016 = last_match_133_2562;
}
 else {
{
long last_match_133_10162;
last_match_133_10162 = last_match_133_2562;
last_match_133_1002 = last_match_133_10162;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
break;
case ((long)111) : 
last_match_133_1531 = new_match_93_1842;
state_50_1052_69_2780:
{
int current_char_37_1533;
current_char_37_1533 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10164;
{
long aux_10165;
aux_10165 = (long)(current_char_37_1533);
test_10164 = (aux_10165==((long)0));
}
if(test_10164){
{
bool_t test2156_1535;
{
bool_t res3382_4678;
{
bool_t _andtest_1237_4675;
_andtest_1237_4675 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4675){
res3382_4678 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3382_4678 = ((bool_t)0);
}
}
test2156_1535 = res3382_4678;
}
if(test2156_1535){
goto state_50_1052_69_2780;
}
 else {
aux_7016 = last_match_133_1531;
}
}
}
 else {
bool_t test2157_1536;
{
bool_t test_10172;
{
long aux_10173;
aux_10173 = (long)(current_char_37_1533);
test_10172 = (aux_10173>=((long)48));
}
if(test_10172){
long aux_10176;
aux_10176 = (long)(current_char_37_1533);
test2157_1536 = (aux_10176<((long)56));
}
 else {
test2157_1536 = ((bool_t)0);
}
}
if(test2157_1536){
last_match_133_1820 = last_match_133_1531;
state_72_1074_116_2766:
{
long new_match_93_1822;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1822 = ((long)13);
{
int current_char_37_1823;
current_char_37_1823 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10182;
{
long aux_10183;
aux_10183 = (long)(current_char_37_1823);
test_10182 = (aux_10183==((long)0));
}
if(test_10182){
{
bool_t test2391_1825;
{
bool_t res3395_5229;
{
bool_t _andtest_1237_5226;
_andtest_1237_5226 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5226){
res3395_5229 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3395_5229 = ((bool_t)0);
}
}
test2391_1825 = res3395_5229;
}
if(test2391_1825){
goto state_72_1074_116_2766;
}
 else {
aux_7016 = new_match_93_1822;
}
}
}
 else {
bool_t test2392_1826;
{
bool_t test_10190;
{
long aux_10191;
aux_10191 = (long)(current_char_37_1823);
test_10190 = (aux_10191>=((long)48));
}
if(test_10190){
long aux_10194;
aux_10194 = (long)(current_char_37_1823);
test2392_1826 = (aux_10194<((long)56));
}
 else {
test2392_1826 = ((bool_t)0);
}
}
if(test2392_1826){
{
long last_match_133_10198;
last_match_133_10198 = new_match_93_1822;
last_match_133_1820 = last_match_133_10198;
goto state_72_1074_116_2766;
}
}
 else {
bool_t test2393_1827;
{
long aux_10199;
aux_10199 = (long)(current_char_37_1823);
test2393_1827 = (aux_10199==((long)40));
}
if(test2393_1827){
{
long new_match_93_5237;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5237 = ((long)35);
aux_7016 = new_match_93_5237;
}
}
 else {
bool_t test_10204;
{
bool_t test_10205;
{
long aux_10206;
aux_10206 = (long)(current_char_37_1823);
test_10205 = (aux_10206<((long)33));
}
if(test_10205){
test_10204 = ((bool_t)1);
}
 else {
bool_t test_10209;
{
bool_t test_10210;
{
long aux_10211;
aux_10211 = (long)(current_char_37_1823);
test_10210 = (aux_10211==((long)35));
}
if(test_10210){
test_10209 = ((bool_t)1);
}
 else {
long aux_10214;
aux_10214 = (long)(current_char_37_1823);
test_10209 = (aux_10214==((long)34));
}
}
if(test_10209){
test_10204 = ((bool_t)1);
}
 else {
bool_t test_10217;
{
bool_t test_10218;
{
long aux_10219;
aux_10219 = (long)(current_char_37_1823);
test_10218 = (aux_10219==((long)41));
}
if(test_10218){
test_10217 = ((bool_t)1);
}
 else {
test_10217 = test2393_1827;
}
}
if(test_10217){
test_10204 = ((bool_t)1);
}
 else {
if(test2392_1826){
test_10204 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1823)){
case ((long)59) : 
test_10204 = ((bool_t)1);
break;
case ((long)91) : 
test_10204 = ((bool_t)1);
break;
case ((long)93) : 
test_10204 = ((bool_t)1);
break;
case ((long)123) : 
test_10204 = ((bool_t)1);
break;
case ((long)125) : 
test_10204 = ((bool_t)1);
break;
default: 
{
long aux_10223;
aux_10223 = (long)(current_char_37_1823);
test_10204 = (aux_10223==((long)127));
}
}
}
}
}
}
}
if(test_10204){
aux_7016 = new_match_93_1822;
}
 else {
{
long last_match_133_10228;
last_match_133_10228 = new_match_93_1822;
last_match_133_1002 = last_match_133_10228;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_10229;
{
bool_t test_10230;
{
long aux_10231;
aux_10231 = (long)(current_char_37_1533);
test_10230 = (aux_10231==((long)43));
}
if(test_10230){
test_10229 = ((bool_t)1);
}
 else {
long aux_10234;
aux_10234 = (long)(current_char_37_1533);
test_10229 = (aux_10234==((long)45));
}
}
if(test_10229){
last_match_133_1616 = last_match_133_1531;
state_71_1073_110_2777:
{
int current_char_37_1618;
current_char_37_1618 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10238;
{
long aux_10239;
aux_10239 = (long)(current_char_37_1618);
test_10238 = (aux_10239==((long)0));
}
if(test_10238){
{
bool_t test2231_1620;
{
bool_t res3385_4849;
{
bool_t _andtest_1237_4846;
_andtest_1237_4846 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4846){
res3385_4849 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3385_4849 = ((bool_t)0);
}
}
test2231_1620 = res3385_4849;
}
if(test2231_1620){
goto state_71_1073_110_2777;
}
 else {
aux_7016 = last_match_133_1616;
}
}
}
 else {
bool_t test2232_1621;
{
bool_t test_10246;
{
long aux_10247;
aux_10247 = (long)(current_char_37_1618);
test_10246 = (aux_10247>=((long)48));
}
if(test_10246){
long aux_10250;
aux_10250 = (long)(current_char_37_1618);
test2232_1621 = (aux_10250<((long)56));
}
 else {
test2232_1621 = ((bool_t)0);
}
}
if(test2232_1621){
{
long last_match_133_10254;
last_match_133_10254 = last_match_133_1616;
last_match_133_1820 = last_match_133_10254;
goto state_72_1074_116_2766;
}
}
 else {
bool_t test2233_1622;
{
long aux_10255;
aux_10255 = (long)(current_char_37_1618);
test2233_1622 = (aux_10255==((long)40));
}
if(test2233_1622){
{
long new_match_93_4857;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4857 = ((long)35);
aux_7016 = new_match_93_4857;
}
}
 else {
bool_t test_10260;
{
bool_t test_10261;
{
long aux_10262;
aux_10262 = (long)(current_char_37_1618);
test_10261 = (aux_10262<((long)33));
}
if(test_10261){
test_10260 = ((bool_t)1);
}
 else {
bool_t test_10265;
{
bool_t test_10266;
{
long aux_10267;
aux_10267 = (long)(current_char_37_1618);
test_10266 = (aux_10267==((long)35));
}
if(test_10266){
test_10265 = ((bool_t)1);
}
 else {
long aux_10270;
aux_10270 = (long)(current_char_37_1618);
test_10265 = (aux_10270==((long)34));
}
}
if(test_10265){
test_10260 = ((bool_t)1);
}
 else {
bool_t test_10273;
{
bool_t test_10274;
{
long aux_10275;
aux_10275 = (long)(current_char_37_1618);
test_10274 = (aux_10275==((long)41));
}
if(test_10274){
test_10273 = ((bool_t)1);
}
 else {
test_10273 = test2233_1622;
}
}
if(test_10273){
test_10260 = ((bool_t)1);
}
 else {
if(test2232_1621){
test_10260 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1618)){
case ((long)59) : 
test_10260 = ((bool_t)1);
break;
case ((long)91) : 
test_10260 = ((bool_t)1);
break;
case ((long)93) : 
test_10260 = ((bool_t)1);
break;
case ((long)123) : 
test_10260 = ((bool_t)1);
break;
case ((long)125) : 
test_10260 = ((bool_t)1);
break;
default: 
{
long aux_10279;
aux_10279 = (long)(current_char_37_1618);
test_10260 = (aux_10279==((long)127));
}
}
}
}
}
}
}
if(test_10260){
aux_7016 = last_match_133_1616;
}
 else {
{
long last_match_133_10284;
last_match_133_10284 = last_match_133_1616;
last_match_133_1002 = last_match_133_10284;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test2159_1538;
{
long aux_10285;
aux_10285 = (long)(current_char_37_1533);
test2159_1538 = (aux_10285==((long)40));
}
if(test2159_1538){
{
long new_match_93_4690;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4690 = ((long)35);
aux_7016 = new_match_93_4690;
}
}
 else {
bool_t test_10290;
{
bool_t test_10291;
{
long aux_10292;
aux_10292 = (long)(current_char_37_1533);
test_10291 = (aux_10292<((long)33));
}
if(test_10291){
test_10290 = ((bool_t)1);
}
 else {
bool_t test_10295;
{
bool_t test_10296;
{
long aux_10297;
aux_10297 = (long)(current_char_37_1533);
test_10296 = (aux_10297==((long)35));
}
if(test_10296){
test_10295 = ((bool_t)1);
}
 else {
long aux_10300;
aux_10300 = (long)(current_char_37_1533);
test_10295 = (aux_10300==((long)34));
}
}
if(test_10295){
test_10290 = ((bool_t)1);
}
 else {
bool_t test_10303;
{
bool_t test_10304;
{
long aux_10305;
aux_10305 = (long)(current_char_37_1533);
test_10304 = (aux_10305==((long)41));
}
if(test_10304){
test_10303 = ((bool_t)1);
}
 else {
test_10303 = test2159_1538;
}
}
if(test_10303){
test_10290 = ((bool_t)1);
}
 else {
bool_t test_10308;
{
long aux_10309;
aux_10309 = (long)(current_char_37_1533);
test_10308 = (aux_10309==((long)43));
}
if(test_10308){
test_10290 = ((bool_t)1);
}
 else {
bool_t test_10312;
{
long aux_10313;
aux_10313 = (long)(current_char_37_1533);
test_10312 = (aux_10313==((long)45));
}
if(test_10312){
test_10290 = ((bool_t)1);
}
 else {
if(test2157_1536){
test_10290 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1533)){
case ((long)59) : 
test_10290 = ((bool_t)1);
break;
case ((long)91) : 
test_10290 = ((bool_t)1);
break;
case ((long)93) : 
test_10290 = ((bool_t)1);
break;
case ((long)123) : 
test_10290 = ((bool_t)1);
break;
case ((long)125) : 
test_10290 = ((bool_t)1);
break;
default: 
{
long aux_10317;
aux_10317 = (long)(current_char_37_1533);
test_10290 = (aux_10317==((long)127));
}
}
}
}
}
}
}
}
}
if(test_10290){
aux_7016 = last_match_133_1531;
}
 else {
{
long last_match_133_10322;
last_match_133_10322 = last_match_133_1531;
last_match_133_1002 = last_match_133_10322;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
break;
case ((long)108) : 
last_match_133_1397 = new_match_93_1842;
state_49_1051_135_2786:
{
int current_char_37_1399;
current_char_37_1399 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10324;
{
long aux_10325;
aux_10325 = (long)(current_char_37_1399);
test_10324 = (aux_10325==((long)0));
}
if(test_10324){
{
bool_t test2050_1401;
{
bool_t res3376_4422;
{
bool_t _andtest_1237_4419;
_andtest_1237_4419 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4419){
res3376_4422 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3376_4422 = ((bool_t)0);
}
}
test2050_1401 = res3376_4422;
}
if(test2050_1401){
goto state_49_1051_135_2786;
}
 else {
aux_7016 = last_match_133_1397;
}
}
}
 else {
bool_t test2051_1402;
{
bool_t test_10332;
{
long aux_10333;
aux_10333 = (long)(current_char_37_1399);
test_10332 = (aux_10333>=((long)48));
}
if(test_10332){
long aux_10336;
aux_10336 = (long)(current_char_37_1399);
test2051_1402 = (aux_10336<((long)58));
}
 else {
test2051_1402 = ((bool_t)0);
}
}
if(test2051_1402){
last_match_133_1903 = last_match_133_1397;
state_74_1076_245_2760:
{
long new_match_93_1905;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1905 = ((long)17);
{
int current_char_37_1906;
current_char_37_1906 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10342;
{
long aux_10343;
aux_10343 = (long)(current_char_37_1906);
test_10342 = (aux_10343==((long)0));
}
if(test_10342){
{
bool_t test2448_1908;
{
bool_t res3399_5384;
{
bool_t _andtest_1237_5381;
_andtest_1237_5381 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5381){
res3399_5384 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3399_5384 = ((bool_t)0);
}
}
test2448_1908 = res3399_5384;
}
if(test2448_1908){
goto state_74_1076_245_2760;
}
 else {
aux_7016 = new_match_93_1905;
}
}
}
 else {
bool_t test2449_1909;
{
bool_t test_10350;
{
long aux_10351;
aux_10351 = (long)(current_char_37_1906);
test_10350 = (aux_10351>=((long)48));
}
if(test_10350){
long aux_10354;
aux_10354 = (long)(current_char_37_1906);
test2449_1909 = (aux_10354<((long)58));
}
 else {
test2449_1909 = ((bool_t)0);
}
}
if(test2449_1909){
{
long last_match_133_10358;
last_match_133_10358 = new_match_93_1905;
last_match_133_1903 = last_match_133_10358;
goto state_74_1076_245_2760;
}
}
 else {
bool_t test2450_1910;
{
long aux_10359;
aux_10359 = (long)(current_char_37_1906);
test2450_1910 = (aux_10359==((long)40));
}
if(test2450_1910){
{
long new_match_93_5392;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5392 = ((long)35);
aux_7016 = new_match_93_5392;
}
}
 else {
bool_t test_10364;
{
bool_t test_10365;
{
long aux_10366;
aux_10366 = (long)(current_char_37_1906);
test_10365 = (aux_10366<((long)33));
}
if(test_10365){
test_10364 = ((bool_t)1);
}
 else {
bool_t test_10369;
{
bool_t test_10370;
{
long aux_10371;
aux_10371 = (long)(current_char_37_1906);
test_10370 = (aux_10371==((long)35));
}
if(test_10370){
test_10369 = ((bool_t)1);
}
 else {
long aux_10374;
aux_10374 = (long)(current_char_37_1906);
test_10369 = (aux_10374==((long)34));
}
}
if(test_10369){
test_10364 = ((bool_t)1);
}
 else {
bool_t test_10377;
{
bool_t test_10378;
{
long aux_10379;
aux_10379 = (long)(current_char_37_1906);
test_10378 = (aux_10379==((long)41));
}
if(test_10378){
test_10377 = ((bool_t)1);
}
 else {
test_10377 = test2450_1910;
}
}
if(test_10377){
test_10364 = ((bool_t)1);
}
 else {
if(test2449_1909){
test_10364 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1906)){
case ((long)59) : 
test_10364 = ((bool_t)1);
break;
case ((long)91) : 
test_10364 = ((bool_t)1);
break;
case ((long)93) : 
test_10364 = ((bool_t)1);
break;
case ((long)123) : 
test_10364 = ((bool_t)1);
break;
case ((long)125) : 
test_10364 = ((bool_t)1);
break;
default: 
{
long aux_10383;
aux_10383 = (long)(current_char_37_1906);
test_10364 = (aux_10383==((long)127));
}
}
}
}
}
}
}
if(test_10364){
aux_7016 = new_match_93_1905;
}
 else {
{
long last_match_133_10388;
last_match_133_10388 = new_match_93_1905;
last_match_133_1002 = last_match_133_10388;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_10389;
{
bool_t test_10390;
{
long aux_10391;
aux_10391 = (long)(current_char_37_1399);
test_10390 = (aux_10391==((long)43));
}
if(test_10390){
test_10389 = ((bool_t)1);
}
 else {
long aux_10394;
aux_10394 = (long)(current_char_37_1399);
test_10389 = (aux_10394==((long)45));
}
}
if(test_10389){
last_match_133_1420 = last_match_133_1397;
state_73_1075_81_2785:
{
int current_char_37_1422;
current_char_37_1422 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10398;
{
long aux_10399;
aux_10399 = (long)(current_char_37_1422);
test_10398 = (aux_10399==((long)0));
}
if(test_10398){
{
bool_t test2069_1424;
{
bool_t res3377_4467;
{
bool_t _andtest_1237_4464;
_andtest_1237_4464 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4464){
res3377_4467 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3377_4467 = ((bool_t)0);
}
}
test2069_1424 = res3377_4467;
}
if(test2069_1424){
goto state_73_1075_81_2785;
}
 else {
aux_7016 = last_match_133_1420;
}
}
}
 else {
bool_t test2070_1425;
{
bool_t test_10406;
{
long aux_10407;
aux_10407 = (long)(current_char_37_1422);
test_10406 = (aux_10407>=((long)48));
}
if(test_10406){
long aux_10410;
aux_10410 = (long)(current_char_37_1422);
test2070_1425 = (aux_10410<((long)58));
}
 else {
test2070_1425 = ((bool_t)0);
}
}
if(test2070_1425){
{
long last_match_133_10414;
last_match_133_10414 = last_match_133_1420;
last_match_133_1903 = last_match_133_10414;
goto state_74_1076_245_2760;
}
}
 else {
bool_t test2071_1426;
{
long aux_10415;
aux_10415 = (long)(current_char_37_1422);
test2071_1426 = (aux_10415==((long)40));
}
if(test2071_1426){
{
long new_match_93_4475;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4475 = ((long)35);
aux_7016 = new_match_93_4475;
}
}
 else {
bool_t test_10420;
{
bool_t test_10421;
{
long aux_10422;
aux_10422 = (long)(current_char_37_1422);
test_10421 = (aux_10422<((long)33));
}
if(test_10421){
test_10420 = ((bool_t)1);
}
 else {
bool_t test_10425;
{
bool_t test_10426;
{
long aux_10427;
aux_10427 = (long)(current_char_37_1422);
test_10426 = (aux_10427==((long)35));
}
if(test_10426){
test_10425 = ((bool_t)1);
}
 else {
long aux_10430;
aux_10430 = (long)(current_char_37_1422);
test_10425 = (aux_10430==((long)34));
}
}
if(test_10425){
test_10420 = ((bool_t)1);
}
 else {
bool_t test_10433;
{
bool_t test_10434;
{
long aux_10435;
aux_10435 = (long)(current_char_37_1422);
test_10434 = (aux_10435==((long)41));
}
if(test_10434){
test_10433 = ((bool_t)1);
}
 else {
test_10433 = test2071_1426;
}
}
if(test_10433){
test_10420 = ((bool_t)1);
}
 else {
if(test2070_1425){
test_10420 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1422)){
case ((long)59) : 
test_10420 = ((bool_t)1);
break;
case ((long)91) : 
test_10420 = ((bool_t)1);
break;
case ((long)93) : 
test_10420 = ((bool_t)1);
break;
case ((long)123) : 
test_10420 = ((bool_t)1);
break;
case ((long)125) : 
test_10420 = ((bool_t)1);
break;
default: 
{
long aux_10439;
aux_10439 = (long)(current_char_37_1422);
test_10420 = (aux_10439==((long)127));
}
}
}
}
}
}
}
if(test_10420){
aux_7016 = last_match_133_1420;
}
 else {
{
long last_match_133_10444;
last_match_133_10444 = last_match_133_1420;
last_match_133_1002 = last_match_133_10444;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test2053_1404;
{
long aux_10445;
aux_10445 = (long)(current_char_37_1399);
test2053_1404 = (aux_10445==((long)40));
}
if(test2053_1404){
{
long new_match_93_4434;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4434 = ((long)35);
aux_7016 = new_match_93_4434;
}
}
 else {
bool_t test_10450;
{
bool_t test_10451;
{
long aux_10452;
aux_10452 = (long)(current_char_37_1399);
test_10451 = (aux_10452<((long)33));
}
if(test_10451){
test_10450 = ((bool_t)1);
}
 else {
bool_t test_10455;
{
bool_t test_10456;
{
long aux_10457;
aux_10457 = (long)(current_char_37_1399);
test_10456 = (aux_10457==((long)35));
}
if(test_10456){
test_10455 = ((bool_t)1);
}
 else {
long aux_10460;
aux_10460 = (long)(current_char_37_1399);
test_10455 = (aux_10460==((long)34));
}
}
if(test_10455){
test_10450 = ((bool_t)1);
}
 else {
bool_t test_10463;
{
bool_t test_10464;
{
long aux_10465;
aux_10465 = (long)(current_char_37_1399);
test_10464 = (aux_10465==((long)41));
}
if(test_10464){
test_10463 = ((bool_t)1);
}
 else {
test_10463 = test2053_1404;
}
}
if(test_10463){
test_10450 = ((bool_t)1);
}
 else {
bool_t test_10468;
{
long aux_10469;
aux_10469 = (long)(current_char_37_1399);
test_10468 = (aux_10469==((long)43));
}
if(test_10468){
test_10450 = ((bool_t)1);
}
 else {
bool_t test_10472;
{
long aux_10473;
aux_10473 = (long)(current_char_37_1399);
test_10472 = (aux_10473==((long)45));
}
if(test_10472){
test_10450 = ((bool_t)1);
}
 else {
if(test2051_1402){
test_10450 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1399)){
case ((long)59) : 
test_10450 = ((bool_t)1);
break;
case ((long)91) : 
test_10450 = ((bool_t)1);
break;
case ((long)93) : 
test_10450 = ((bool_t)1);
break;
case ((long)123) : 
test_10450 = ((bool_t)1);
break;
case ((long)125) : 
test_10450 = ((bool_t)1);
break;
default: 
{
long aux_10477;
aux_10477 = (long)(current_char_37_1399);
test_10450 = (aux_10477==((long)127));
}
}
}
}
}
}
}
}
}
if(test_10450){
aux_7016 = last_match_133_1397;
}
 else {
{
long last_match_133_10482;
last_match_133_10482 = last_match_133_1397;
last_match_133_1002 = last_match_133_10482;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
break;
case ((long)101) : 
last_match_133_1186 = new_match_93_1842;
state_48_1050_146_2792:
{
int current_char_37_1188;
current_char_37_1188 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10484;
{
long aux_10485;
aux_10485 = (long)(current_char_37_1188);
test_10484 = (aux_10485==((long)0));
}
if(test_10484){
{
bool_t test1861_1190;
{
bool_t res3370_3999;
{
bool_t _andtest_1237_3996;
_andtest_1237_3996 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3996){
res3370_3999 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3370_3999 = ((bool_t)0);
}
}
test1861_1190 = res3370_3999;
}
if(test1861_1190){
goto state_48_1050_146_2792;
}
 else {
aux_7016 = last_match_133_1186;
}
}
}
 else {
bool_t test_10492;
{
bool_t test_10493;
{
bool_t test_10494;
{
long aux_10495;
aux_10495 = (long)(current_char_37_1188);
test_10494 = (aux_10495>=((long)98));
}
if(test_10494){
long aux_10498;
aux_10498 = (long)(current_char_37_1188);
test_10493 = (aux_10498<((long)103));
}
 else {
test_10493 = ((bool_t)0);
}
}
if(test_10493){
test_10492 = ((bool_t)1);
}
 else {
bool_t test_10501;
{
bool_t test_10502;
{
long aux_10503;
aux_10503 = (long)(current_char_37_1188);
test_10502 = (aux_10503==((long)106));
}
if(test_10502){
test_10501 = ((bool_t)1);
}
 else {
long aux_10506;
aux_10506 = (long)(current_char_37_1188);
test_10501 = (aux_10506==((long)105));
}
}
if(test_10501){
test_10492 = ((bool_t)1);
}
 else {
bool_t test_10509;
{
bool_t test_10510;
{
long aux_10511;
aux_10511 = (long)(current_char_37_1188);
test_10510 = (aux_10511==((long)112));
}
if(test_10510){
test_10509 = ((bool_t)1);
}
 else {
bool_t test_10514;
{
long aux_10515;
aux_10515 = (long)(current_char_37_1188);
test_10514 = (aux_10515==((long)111));
}
if(test_10514){
test_10509 = ((bool_t)1);
}
 else {
long aux_10518;
aux_10518 = (long)(current_char_37_1188);
test_10509 = (aux_10518==((long)110));
}
}
}
if(test_10509){
test_10492 = ((bool_t)1);
}
 else {
bool_t _ortest_1202_1224;
{
long aux_10521;
aux_10521 = (long)(current_char_37_1188);
_ortest_1202_1224 = (aux_10521==((long)116));
}
if(_ortest_1202_1224){
test_10492 = _ortest_1202_1224;
}
 else {
long aux_10525;
aux_10525 = (long)(current_char_37_1188);
test_10492 = (aux_10525==((long)115));
}
}
}
}
}
if(test_10492){
{
long last_match_133_10528;
last_match_133_10528 = last_match_133_1186;
last_match_133_2090 = last_match_133_10528;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test1863_1192;
{
bool_t test_10529;
{
long aux_10530;
aux_10530 = (long)(current_char_37_1188);
test_10529 = (aux_10530>=((long)48));
}
if(test_10529){
long aux_10533;
aux_10533 = (long)(current_char_37_1188);
test1863_1192 = (aux_10533<((long)58));
}
 else {
test1863_1192 = ((bool_t)0);
}
}
if(test1863_1192){
last_match_133_2636 = last_match_133_1186;
state_77_1079_32_2718:
{
long new_match_93_2638;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2638 = ((long)16);
{
int current_char_37_2639;
current_char_37_2639 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10539;
{
long aux_10540;
aux_10540 = (long)(current_char_37_2639);
test_10539 = (aux_10540==((long)0));
}
if(test_10539){
{
bool_t test3029_2641;
{
bool_t res3428_6737;
{
bool_t _andtest_1237_6734;
_andtest_1237_6734 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6734){
res3428_6737 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3428_6737 = ((bool_t)0);
}
}
test3029_2641 = res3428_6737;
}
if(test3029_2641){
goto state_77_1079_32_2718;
}
 else {
aux_7016 = new_match_93_2638;
}
}
}
 else {
bool_t test3030_2642;
{
bool_t test_10547;
{
long aux_10548;
aux_10548 = (long)(current_char_37_2639);
test_10547 = (aux_10548>=((long)48));
}
if(test_10547){
long aux_10551;
aux_10551 = (long)(current_char_37_2639);
test3030_2642 = (aux_10551<((long)58));
}
 else {
test3030_2642 = ((bool_t)0);
}
}
if(test3030_2642){
{
long last_match_133_10555;
last_match_133_10555 = new_match_93_2638;
last_match_133_2636 = last_match_133_10555;
goto state_77_1079_32_2718;
}
}
 else {
bool_t test3031_2643;
{
long aux_10556;
aux_10556 = (long)(current_char_37_2639);
test3031_2643 = (aux_10556==((long)40));
}
if(test3031_2643){
{
long new_match_93_6745;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6745 = ((long)35);
aux_7016 = new_match_93_6745;
}
}
 else {
bool_t test_10561;
{
bool_t test_10562;
{
long aux_10563;
aux_10563 = (long)(current_char_37_2639);
test_10562 = (aux_10563<((long)33));
}
if(test_10562){
test_10561 = ((bool_t)1);
}
 else {
bool_t test_10566;
{
bool_t test_10567;
{
long aux_10568;
aux_10568 = (long)(current_char_37_2639);
test_10567 = (aux_10568==((long)35));
}
if(test_10567){
test_10566 = ((bool_t)1);
}
 else {
long aux_10571;
aux_10571 = (long)(current_char_37_2639);
test_10566 = (aux_10571==((long)34));
}
}
if(test_10566){
test_10561 = ((bool_t)1);
}
 else {
bool_t test_10574;
{
bool_t test_10575;
{
long aux_10576;
aux_10576 = (long)(current_char_37_2639);
test_10575 = (aux_10576==((long)41));
}
if(test_10575){
test_10574 = ((bool_t)1);
}
 else {
test_10574 = test3031_2643;
}
}
if(test_10574){
test_10561 = ((bool_t)1);
}
 else {
if(test3030_2642){
test_10561 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2639)){
case ((long)59) : 
test_10561 = ((bool_t)1);
break;
case ((long)91) : 
test_10561 = ((bool_t)1);
break;
case ((long)93) : 
test_10561 = ((bool_t)1);
break;
case ((long)123) : 
test_10561 = ((bool_t)1);
break;
case ((long)125) : 
test_10561 = ((bool_t)1);
break;
default: 
{
long aux_10580;
aux_10580 = (long)(current_char_37_2639);
test_10561 = (aux_10580==((long)127));
}
}
}
}
}
}
}
if(test_10561){
aux_7016 = new_match_93_2638;
}
 else {
{
long last_match_133_10585;
last_match_133_10585 = new_match_93_2638;
last_match_133_1002 = last_match_133_10585;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test1864_1193;
{
long aux_10586;
aux_10586 = (long)(current_char_37_1188);
test1864_1193 = (aux_10586==((long)45));
}
if(test1864_1193){
last_match_133_2166 = last_match_133_1186;
state_76_1078_105_2751:
{
long new_match_93_2168;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2168 = ((long)22);
{
int current_char_37_2169;
current_char_37_2169 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10592;
{
long aux_10593;
aux_10593 = (long)(current_char_37_2169);
test_10592 = (aux_10593==((long)0));
}
if(test_10592){
{
bool_t test2677_2171;
{
bool_t res3407_5900;
{
bool_t _andtest_1237_5897;
_andtest_1237_5897 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5897){
res3407_5900 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3407_5900 = ((bool_t)0);
}
}
test2677_2171 = res3407_5900;
}
if(test2677_2171){
goto state_76_1078_105_2751;
}
 else {
aux_7016 = new_match_93_2168;
}
}
}
 else {
bool_t test2678_2172;
{
bool_t test_10600;
{
long aux_10601;
aux_10601 = (long)(current_char_37_2169);
test_10600 = (aux_10601>=((long)48));
}
if(test_10600){
long aux_10604;
aux_10604 = (long)(current_char_37_2169);
test2678_2172 = (aux_10604<((long)58));
}
 else {
test2678_2172 = ((bool_t)0);
}
}
if(test2678_2172){
{
long last_match_133_10608;
last_match_133_10608 = new_match_93_2168;
last_match_133_2636 = last_match_133_10608;
goto state_77_1079_32_2718;
}
}
 else {
bool_t test_10609;
{
bool_t test_10610;
{
long aux_10611;
aux_10611 = (long)(current_char_37_2169);
test_10610 = (aux_10611==((long)45));
}
if(test_10610){
test_10609 = ((bool_t)1);
}
 else {
bool_t test_10614;
{
bool_t test_10615;
{
long aux_10616;
aux_10616 = (long)(current_char_37_2169);
test_10615 = (aux_10616>=((long)98));
}
if(test_10615){
long aux_10619;
aux_10619 = (long)(current_char_37_2169);
test_10614 = (aux_10619<((long)103));
}
 else {
test_10614 = ((bool_t)0);
}
}
if(test_10614){
test_10609 = ((bool_t)1);
}
 else {
bool_t test_10622;
{
bool_t test_10623;
{
long aux_10624;
aux_10624 = (long)(current_char_37_2169);
test_10623 = (aux_10624==((long)106));
}
if(test_10623){
test_10622 = ((bool_t)1);
}
 else {
long aux_10627;
aux_10627 = (long)(current_char_37_2169);
test_10622 = (aux_10627==((long)105));
}
}
if(test_10622){
test_10609 = ((bool_t)1);
}
 else {
bool_t test_10630;
{
bool_t test_10631;
{
long aux_10632;
aux_10632 = (long)(current_char_37_2169);
test_10631 = (aux_10632==((long)112));
}
if(test_10631){
test_10630 = ((bool_t)1);
}
 else {
bool_t test_10635;
{
long aux_10636;
aux_10636 = (long)(current_char_37_2169);
test_10635 = (aux_10636==((long)111));
}
if(test_10635){
test_10630 = ((bool_t)1);
}
 else {
long aux_10639;
aux_10639 = (long)(current_char_37_2169);
test_10630 = (aux_10639==((long)110));
}
}
}
if(test_10630){
test_10609 = ((bool_t)1);
}
 else {
bool_t _ortest_1143_2202;
{
long aux_10642;
aux_10642 = (long)(current_char_37_2169);
_ortest_1143_2202 = (aux_10642==((long)116));
}
if(_ortest_1143_2202){
test_10609 = _ortest_1143_2202;
}
 else {
long aux_10646;
aux_10646 = (long)(current_char_37_2169);
test_10609 = (aux_10646==((long)115));
}
}
}
}
}
}
if(test_10609){
{
long last_match_133_10649;
last_match_133_10649 = new_match_93_2168;
last_match_133_2090 = last_match_133_10649;
goto state_59_1061_245_2753;
}
}
 else {
bool_t test2680_2174;
{
long aux_10650;
aux_10650 = (long)(current_char_37_2169);
test2680_2174 = (aux_10650==((long)40));
}
if(test2680_2174){
{
long new_match_93_5928;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5928 = ((long)35);
aux_7016 = new_match_93_5928;
}
}
 else {
bool_t test_10655;
{
bool_t test_10656;
{
long aux_10657;
aux_10657 = (long)(current_char_37_2169);
test_10656 = (aux_10657<((long)33));
}
if(test_10656){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10660;
{
bool_t test_10661;
{
long aux_10662;
aux_10662 = (long)(current_char_37_2169);
test_10661 = (aux_10662==((long)35));
}
if(test_10661){
test_10660 = ((bool_t)1);
}
 else {
long aux_10665;
aux_10665 = (long)(current_char_37_2169);
test_10660 = (aux_10665==((long)34));
}
}
if(test_10660){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10668;
{
bool_t test_10669;
{
long aux_10670;
aux_10670 = (long)(current_char_37_2169);
test_10669 = (aux_10670==((long)41));
}
if(test_10669){
test_10668 = ((bool_t)1);
}
 else {
test_10668 = test2680_2174;
}
}
if(test_10668){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10673;
{
long aux_10674;
aux_10674 = (long)(current_char_37_2169);
test_10673 = (aux_10674==((long)45));
}
if(test_10673){
test_10655 = ((bool_t)1);
}
 else {
if(test2678_2172){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10678;
{
long aux_10679;
aux_10679 = (long)(current_char_37_2169);
test_10678 = (aux_10679==((long)59));
}
if(test_10678){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10682;
{
long aux_10683;
aux_10683 = (long)(current_char_37_2169);
test_10682 = (aux_10683==((long)91));
}
if(test_10682){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10686;
{
long aux_10687;
aux_10687 = (long)(current_char_37_2169);
test_10686 = (aux_10687==((long)93));
}
if(test_10686){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10690;
{
bool_t test_10691;
{
long aux_10692;
aux_10692 = (long)(current_char_37_2169);
test_10691 = (aux_10692>=((long)98));
}
if(test_10691){
long aux_10695;
aux_10695 = (long)(current_char_37_2169);
test_10690 = (aux_10695<((long)103));
}
 else {
test_10690 = ((bool_t)0);
}
}
if(test_10690){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10698;
{
bool_t test_10699;
{
long aux_10700;
aux_10700 = (long)(current_char_37_2169);
test_10699 = (aux_10700==((long)106));
}
if(test_10699){
test_10698 = ((bool_t)1);
}
 else {
long aux_10703;
aux_10703 = (long)(current_char_37_2169);
test_10698 = (aux_10703==((long)105));
}
}
if(test_10698){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10706;
{
bool_t test_10707;
{
long aux_10708;
aux_10708 = (long)(current_char_37_2169);
test_10707 = (aux_10708==((long)112));
}
if(test_10707){
test_10706 = ((bool_t)1);
}
 else {
bool_t test_10711;
{
long aux_10712;
aux_10712 = (long)(current_char_37_2169);
test_10711 = (aux_10712==((long)111));
}
if(test_10711){
test_10706 = ((bool_t)1);
}
 else {
long aux_10715;
aux_10715 = (long)(current_char_37_2169);
test_10706 = (aux_10715==((long)110));
}
}
}
if(test_10706){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10718;
{
bool_t test_10719;
{
long aux_10720;
aux_10720 = (long)(current_char_37_2169);
test_10719 = (aux_10720==((long)116));
}
if(test_10719){
test_10718 = ((bool_t)1);
}
 else {
long aux_10723;
aux_10723 = (long)(current_char_37_2169);
test_10718 = (aux_10723==((long)115));
}
}
if(test_10718){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10726;
{
long aux_10727;
aux_10727 = (long)(current_char_37_2169);
test_10726 = (aux_10727==((long)123));
}
if(test_10726){
test_10655 = ((bool_t)1);
}
 else {
bool_t test_10730;
{
long aux_10731;
aux_10731 = (long)(current_char_37_2169);
test_10730 = (aux_10731==((long)125));
}
if(test_10730){
test_10655 = ((bool_t)1);
}
 else {
long aux_10734;
aux_10734 = (long)(current_char_37_2169);
test_10655 = (aux_10734==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_10655){
aux_7016 = new_match_93_2168;
}
 else {
{
long last_match_133_10737;
last_match_133_10737 = new_match_93_2168;
last_match_133_1002 = last_match_133_10737;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
 else {
bool_t test1865_1194;
{
long aux_10738;
aux_10738 = (long)(current_char_37_1188);
test1865_1194 = (aux_10738==((long)43));
}
if(test1865_1194){
last_match_133_1092 = last_match_133_1186;
state_75_1077_114_2798:
{
int current_char_37_1094;
current_char_37_1094 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10743;
{
long aux_10744;
aux_10744 = (long)(current_char_37_1094);
test_10743 = (aux_10744==((long)0));
}
if(test_10743){
{
bool_t test1788_1096;
{
bool_t res3366_3830;
{
bool_t _andtest_1237_3827;
_andtest_1237_3827 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3827){
res3366_3830 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3366_3830 = ((bool_t)0);
}
}
test1788_1096 = res3366_3830;
}
if(test1788_1096){
goto state_75_1077_114_2798;
}
 else {
aux_7016 = last_match_133_1092;
}
}
}
 else {
bool_t test1789_1097;
{
bool_t test_10751;
{
long aux_10752;
aux_10752 = (long)(current_char_37_1094);
test_10751 = (aux_10752>=((long)48));
}
if(test_10751){
long aux_10755;
aux_10755 = (long)(current_char_37_1094);
test1789_1097 = (aux_10755<((long)58));
}
 else {
test1789_1097 = ((bool_t)0);
}
}
if(test1789_1097){
{
long last_match_133_10759;
last_match_133_10759 = last_match_133_1092;
last_match_133_2636 = last_match_133_10759;
goto state_77_1079_32_2718;
}
}
 else {
bool_t test1790_1098;
{
long aux_10760;
aux_10760 = (long)(current_char_37_1094);
test1790_1098 = (aux_10760==((long)40));
}
if(test1790_1098){
{
long new_match_93_3838;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3838 = ((long)35);
aux_7016 = new_match_93_3838;
}
}
 else {
bool_t test_10765;
{
bool_t test_10766;
{
long aux_10767;
aux_10767 = (long)(current_char_37_1094);
test_10766 = (aux_10767<((long)33));
}
if(test_10766){
test_10765 = ((bool_t)1);
}
 else {
bool_t test_10770;
{
bool_t test_10771;
{
long aux_10772;
aux_10772 = (long)(current_char_37_1094);
test_10771 = (aux_10772==((long)35));
}
if(test_10771){
test_10770 = ((bool_t)1);
}
 else {
long aux_10775;
aux_10775 = (long)(current_char_37_1094);
test_10770 = (aux_10775==((long)34));
}
}
if(test_10770){
test_10765 = ((bool_t)1);
}
 else {
bool_t test_10778;
{
bool_t test_10779;
{
long aux_10780;
aux_10780 = (long)(current_char_37_1094);
test_10779 = (aux_10780==((long)41));
}
if(test_10779){
test_10778 = ((bool_t)1);
}
 else {
test_10778 = test1790_1098;
}
}
if(test_10778){
test_10765 = ((bool_t)1);
}
 else {
if(test1789_1097){
test_10765 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1094)){
case ((long)59) : 
test_10765 = ((bool_t)1);
break;
case ((long)91) : 
test_10765 = ((bool_t)1);
break;
case ((long)93) : 
test_10765 = ((bool_t)1);
break;
case ((long)123) : 
test_10765 = ((bool_t)1);
break;
case ((long)125) : 
test_10765 = ((bool_t)1);
break;
default: 
{
long aux_10784;
aux_10784 = (long)(current_char_37_1094);
test_10765 = (aux_10784==((long)127));
}
}
}
}
}
}
}
if(test_10765){
aux_7016 = last_match_133_1092;
}
 else {
{
long last_match_133_10789;
last_match_133_10789 = last_match_133_1092;
last_match_133_1002 = last_match_133_10789;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test1866_1195;
{
long aux_10790;
aux_10790 = (long)(current_char_37_1188);
test1866_1195 = (aux_10790==((long)40));
}
if(test1866_1195){
{
long new_match_93_4029;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4029 = ((long)35);
aux_7016 = new_match_93_4029;
}
}
 else {
bool_t test_10795;
{
bool_t test_10796;
{
long aux_10797;
aux_10797 = (long)(current_char_37_1188);
test_10796 = (aux_10797<((long)33));
}
if(test_10796){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10800;
{
bool_t test_10801;
{
long aux_10802;
aux_10802 = (long)(current_char_37_1188);
test_10801 = (aux_10802==((long)35));
}
if(test_10801){
test_10800 = ((bool_t)1);
}
 else {
long aux_10805;
aux_10805 = (long)(current_char_37_1188);
test_10800 = (aux_10805==((long)34));
}
}
if(test_10800){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10808;
{
bool_t test_10809;
{
long aux_10810;
aux_10810 = (long)(current_char_37_1188);
test_10809 = (aux_10810==((long)41));
}
if(test_10809){
test_10808 = ((bool_t)1);
}
 else {
test_10808 = test1866_1195;
}
}
if(test_10808){
test_10795 = ((bool_t)1);
}
 else {
if(test1865_1194){
test_10795 = ((bool_t)1);
}
 else {
if(test1864_1193){
test_10795 = ((bool_t)1);
}
 else {
if(test1863_1192){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10816;
{
long aux_10817;
aux_10817 = (long)(current_char_37_1188);
test_10816 = (aux_10817==((long)59));
}
if(test_10816){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10820;
{
long aux_10821;
aux_10821 = (long)(current_char_37_1188);
test_10820 = (aux_10821==((long)91));
}
if(test_10820){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10824;
{
long aux_10825;
aux_10825 = (long)(current_char_37_1188);
test_10824 = (aux_10825==((long)93));
}
if(test_10824){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10828;
{
bool_t test_10829;
{
long aux_10830;
aux_10830 = (long)(current_char_37_1188);
test_10829 = (aux_10830>=((long)98));
}
if(test_10829){
long aux_10833;
aux_10833 = (long)(current_char_37_1188);
test_10828 = (aux_10833<((long)103));
}
 else {
test_10828 = ((bool_t)0);
}
}
if(test_10828){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10836;
{
bool_t test_10837;
{
long aux_10838;
aux_10838 = (long)(current_char_37_1188);
test_10837 = (aux_10838==((long)106));
}
if(test_10837){
test_10836 = ((bool_t)1);
}
 else {
long aux_10841;
aux_10841 = (long)(current_char_37_1188);
test_10836 = (aux_10841==((long)105));
}
}
if(test_10836){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10844;
{
bool_t test_10845;
{
long aux_10846;
aux_10846 = (long)(current_char_37_1188);
test_10845 = (aux_10846==((long)112));
}
if(test_10845){
test_10844 = ((bool_t)1);
}
 else {
bool_t test_10849;
{
long aux_10850;
aux_10850 = (long)(current_char_37_1188);
test_10849 = (aux_10850==((long)111));
}
if(test_10849){
test_10844 = ((bool_t)1);
}
 else {
long aux_10853;
aux_10853 = (long)(current_char_37_1188);
test_10844 = (aux_10853==((long)110));
}
}
}
if(test_10844){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10856;
{
bool_t test_10857;
{
long aux_10858;
aux_10858 = (long)(current_char_37_1188);
test_10857 = (aux_10858==((long)116));
}
if(test_10857){
test_10856 = ((bool_t)1);
}
 else {
long aux_10861;
aux_10861 = (long)(current_char_37_1188);
test_10856 = (aux_10861==((long)115));
}
}
if(test_10856){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10864;
{
long aux_10865;
aux_10865 = (long)(current_char_37_1188);
test_10864 = (aux_10865==((long)123));
}
if(test_10864){
test_10795 = ((bool_t)1);
}
 else {
bool_t test_10868;
{
long aux_10869;
aux_10869 = (long)(current_char_37_1188);
test_10868 = (aux_10869==((long)125));
}
if(test_10868){
test_10795 = ((bool_t)1);
}
 else {
long aux_10872;
aux_10872 = (long)(current_char_37_1188);
test_10795 = (aux_10872==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
if(test_10795){
aux_7016 = last_match_133_1186;
}
 else {
{
long last_match_133_10875;
last_match_133_10875 = last_match_133_1186;
last_match_133_1002 = last_match_133_10875;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
}
break;
case ((long)100) : 
last_match_133_2539 = new_match_93_1842;
state_47_1049_242_2725:
{
int current_char_37_2541;
current_char_37_2541 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10877;
{
long aux_10878;
aux_10878 = (long)(current_char_37_2541);
test_10877 = (aux_10878==((long)0));
}
if(test_10877){
{
bool_t test2952_2543;
{
bool_t res3424_6558;
{
bool_t _andtest_1237_6555;
_andtest_1237_6555 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6555){
res3424_6558 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3424_6558 = ((bool_t)0);
}
}
test2952_2543 = res3424_6558;
}
if(test2952_2543){
goto state_47_1049_242_2725;
}
 else {
aux_7016 = last_match_133_2539;
}
}
}
 else {
bool_t test2953_2544;
{
bool_t test_10885;
{
long aux_10886;
aux_10886 = (long)(current_char_37_2541);
test_10885 = (aux_10886>=((long)48));
}
if(test_10885){
long aux_10889;
aux_10889 = (long)(current_char_37_2541);
test2953_2544 = (aux_10889<((long)58));
}
 else {
test2953_2544 = ((bool_t)0);
}
}
if(test2953_2544){
last_match_133_1111 = last_match_133_2539;
state_79_1081_189_2797:
{
long new_match_93_1113;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1113 = ((long)14);
{
int current_char_37_1114;
current_char_37_1114 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10895;
{
long aux_10896;
aux_10896 = (long)(current_char_37_1114);
test_10895 = (aux_10896==((long)0));
}
if(test_10895){
{
bool_t test1804_1116;
{
bool_t res3367_3868;
{
bool_t _andtest_1237_3865;
_andtest_1237_3865 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3865){
res3367_3868 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3367_3868 = ((bool_t)0);
}
}
test1804_1116 = res3367_3868;
}
if(test1804_1116){
goto state_79_1081_189_2797;
}
 else {
aux_7016 = new_match_93_1113;
}
}
}
 else {
bool_t test1805_1117;
{
bool_t test_10903;
{
long aux_10904;
aux_10904 = (long)(current_char_37_1114);
test_10903 = (aux_10904>=((long)48));
}
if(test_10903){
long aux_10907;
aux_10907 = (long)(current_char_37_1114);
test1805_1117 = (aux_10907<((long)58));
}
 else {
test1805_1117 = ((bool_t)0);
}
}
if(test1805_1117){
{
long last_match_133_10911;
last_match_133_10911 = new_match_93_1113;
last_match_133_1111 = last_match_133_10911;
goto state_79_1081_189_2797;
}
}
 else {
bool_t test1806_1118;
{
long aux_10912;
aux_10912 = (long)(current_char_37_1114);
test1806_1118 = (aux_10912==((long)40));
}
if(test1806_1118){
{
long new_match_93_3876;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3876 = ((long)35);
aux_7016 = new_match_93_3876;
}
}
 else {
bool_t test_10917;
{
bool_t test_10918;
{
long aux_10919;
aux_10919 = (long)(current_char_37_1114);
test_10918 = (aux_10919<((long)33));
}
if(test_10918){
test_10917 = ((bool_t)1);
}
 else {
bool_t test_10922;
{
bool_t test_10923;
{
long aux_10924;
aux_10924 = (long)(current_char_37_1114);
test_10923 = (aux_10924==((long)35));
}
if(test_10923){
test_10922 = ((bool_t)1);
}
 else {
long aux_10927;
aux_10927 = (long)(current_char_37_1114);
test_10922 = (aux_10927==((long)34));
}
}
if(test_10922){
test_10917 = ((bool_t)1);
}
 else {
bool_t test_10930;
{
bool_t test_10931;
{
long aux_10932;
aux_10932 = (long)(current_char_37_1114);
test_10931 = (aux_10932==((long)41));
}
if(test_10931){
test_10930 = ((bool_t)1);
}
 else {
test_10930 = test1806_1118;
}
}
if(test_10930){
test_10917 = ((bool_t)1);
}
 else {
if(test1805_1117){
test_10917 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1114)){
case ((long)59) : 
test_10917 = ((bool_t)1);
break;
case ((long)91) : 
test_10917 = ((bool_t)1);
break;
case ((long)93) : 
test_10917 = ((bool_t)1);
break;
case ((long)123) : 
test_10917 = ((bool_t)1);
break;
case ((long)125) : 
test_10917 = ((bool_t)1);
break;
default: 
{
long aux_10936;
aux_10936 = (long)(current_char_37_1114);
test_10917 = (aux_10936==((long)127));
}
}
}
}
}
}
}
if(test_10917){
aux_7016 = new_match_93_1113;
}
 else {
{
long last_match_133_10941;
last_match_133_10941 = new_match_93_1113;
last_match_133_1002 = last_match_133_10941;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test_10942;
{
bool_t test_10943;
{
long aux_10944;
aux_10944 = (long)(current_char_37_2541);
test_10943 = (aux_10944==((long)43));
}
if(test_10943){
test_10942 = ((bool_t)1);
}
 else {
long aux_10947;
aux_10947 = (long)(current_char_37_2541);
test_10942 = (aux_10947==((long)45));
}
}
if(test_10942){
last_match_133_1974 = last_match_133_2539;
state_78_1080_218_2757:
{
int current_char_37_1976;
current_char_37_1976 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_10951;
{
long aux_10952;
aux_10952 = (long)(current_char_37_1976);
test_10951 = (aux_10952==((long)0));
}
if(test_10951){
{
bool_t test2506_1978;
{
bool_t res3402_5519;
{
bool_t _andtest_1237_5516;
_andtest_1237_5516 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5516){
res3402_5519 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3402_5519 = ((bool_t)0);
}
}
test2506_1978 = res3402_5519;
}
if(test2506_1978){
goto state_78_1080_218_2757;
}
 else {
aux_7016 = last_match_133_1974;
}
}
}
 else {
bool_t test2507_1979;
{
bool_t test_10959;
{
long aux_10960;
aux_10960 = (long)(current_char_37_1976);
test_10959 = (aux_10960>=((long)48));
}
if(test_10959){
long aux_10963;
aux_10963 = (long)(current_char_37_1976);
test2507_1979 = (aux_10963<((long)58));
}
 else {
test2507_1979 = ((bool_t)0);
}
}
if(test2507_1979){
{
long last_match_133_10967;
last_match_133_10967 = last_match_133_1974;
last_match_133_1111 = last_match_133_10967;
goto state_79_1081_189_2797;
}
}
 else {
bool_t test2508_1980;
{
long aux_10968;
aux_10968 = (long)(current_char_37_1976);
test2508_1980 = (aux_10968==((long)40));
}
if(test2508_1980){
{
long new_match_93_5527;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5527 = ((long)35);
aux_7016 = new_match_93_5527;
}
}
 else {
bool_t test_10973;
{
bool_t test_10974;
{
long aux_10975;
aux_10975 = (long)(current_char_37_1976);
test_10974 = (aux_10975<((long)33));
}
if(test_10974){
test_10973 = ((bool_t)1);
}
 else {
bool_t test_10978;
{
bool_t test_10979;
{
long aux_10980;
aux_10980 = (long)(current_char_37_1976);
test_10979 = (aux_10980==((long)35));
}
if(test_10979){
test_10978 = ((bool_t)1);
}
 else {
long aux_10983;
aux_10983 = (long)(current_char_37_1976);
test_10978 = (aux_10983==((long)34));
}
}
if(test_10978){
test_10973 = ((bool_t)1);
}
 else {
bool_t test_10986;
{
bool_t test_10987;
{
long aux_10988;
aux_10988 = (long)(current_char_37_1976);
test_10987 = (aux_10988==((long)41));
}
if(test_10987){
test_10986 = ((bool_t)1);
}
 else {
test_10986 = test2508_1980;
}
}
if(test_10986){
test_10973 = ((bool_t)1);
}
 else {
if(test2507_1979){
test_10973 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1976)){
case ((long)59) : 
test_10973 = ((bool_t)1);
break;
case ((long)91) : 
test_10973 = ((bool_t)1);
break;
case ((long)93) : 
test_10973 = ((bool_t)1);
break;
case ((long)123) : 
test_10973 = ((bool_t)1);
break;
case ((long)125) : 
test_10973 = ((bool_t)1);
break;
default: 
{
long aux_10992;
aux_10992 = (long)(current_char_37_1976);
test_10973 = (aux_10992==((long)127));
}
}
}
}
}
}
}
if(test_10973){
aux_7016 = last_match_133_1974;
}
 else {
{
long last_match_133_10997;
last_match_133_10997 = last_match_133_1974;
last_match_133_1002 = last_match_133_10997;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test2955_2546;
{
long aux_10998;
aux_10998 = (long)(current_char_37_2541);
test2955_2546 = (aux_10998==((long)40));
}
if(test2955_2546){
{
long new_match_93_6570;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6570 = ((long)35);
aux_7016 = new_match_93_6570;
}
}
 else {
bool_t test_11003;
{
bool_t test_11004;
{
long aux_11005;
aux_11005 = (long)(current_char_37_2541);
test_11004 = (aux_11005<((long)33));
}
if(test_11004){
test_11003 = ((bool_t)1);
}
 else {
bool_t test_11008;
{
bool_t test_11009;
{
long aux_11010;
aux_11010 = (long)(current_char_37_2541);
test_11009 = (aux_11010==((long)35));
}
if(test_11009){
test_11008 = ((bool_t)1);
}
 else {
long aux_11013;
aux_11013 = (long)(current_char_37_2541);
test_11008 = (aux_11013==((long)34));
}
}
if(test_11008){
test_11003 = ((bool_t)1);
}
 else {
bool_t test_11016;
{
bool_t test_11017;
{
long aux_11018;
aux_11018 = (long)(current_char_37_2541);
test_11017 = (aux_11018==((long)41));
}
if(test_11017){
test_11016 = ((bool_t)1);
}
 else {
test_11016 = test2955_2546;
}
}
if(test_11016){
test_11003 = ((bool_t)1);
}
 else {
bool_t test_11021;
{
long aux_11022;
aux_11022 = (long)(current_char_37_2541);
test_11021 = (aux_11022==((long)43));
}
if(test_11021){
test_11003 = ((bool_t)1);
}
 else {
bool_t test_11025;
{
long aux_11026;
aux_11026 = (long)(current_char_37_2541);
test_11025 = (aux_11026==((long)45));
}
if(test_11025){
test_11003 = ((bool_t)1);
}
 else {
if(test2953_2544){
test_11003 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2541)){
case ((long)59) : 
test_11003 = ((bool_t)1);
break;
case ((long)91) : 
test_11003 = ((bool_t)1);
break;
case ((long)93) : 
test_11003 = ((bool_t)1);
break;
case ((long)123) : 
test_11003 = ((bool_t)1);
break;
case ((long)125) : 
test_11003 = ((bool_t)1);
break;
default: 
{
long aux_11030;
aux_11030 = (long)(current_char_37_2541);
test_11003 = (aux_11030==((long)127));
}
}
}
}
}
}
}
}
}
if(test_11003){
aux_7016 = last_match_133_2539;
}
 else {
{
long last_match_133_11035;
last_match_133_11035 = last_match_133_2539;
last_match_133_1002 = last_match_133_11035;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
break;
case ((long)97) : 
last_match_133_2510 = new_match_93_1842;
state_46_1048_18_2726:
{
int current_char_37_2512;
current_char_37_2512 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11037;
{
long aux_11038;
aux_11038 = (long)(current_char_37_2512);
test_11037 = (aux_11038==((long)0));
}
if(test_11037){
{
bool_t test2926_2514;
{
bool_t res3423_6499;
{
bool_t _andtest_1237_6496;
_andtest_1237_6496 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6496){
res3423_6499 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3423_6499 = ((bool_t)0);
}
}
test2926_2514 = res3423_6499;
}
if(test2926_2514){
goto state_46_1048_18_2726;
}
 else {
aux_7016 = last_match_133_2510;
}
}
}
 else {
bool_t test_11045;
{
bool_t test_11046;
{
bool_t test_11047;
{
long aux_11048;
aux_11048 = (long)(current_char_37_2512);
test_11047 = (aux_11048>=((long)48));
}
if(test_11047){
long aux_11051;
aux_11051 = (long)(current_char_37_2512);
test_11046 = (aux_11051<((long)58));
}
 else {
test_11046 = ((bool_t)0);
}
}
if(test_11046){
test_11045 = ((bool_t)1);
}
 else {
bool_t test_11054;
{
bool_t test_11055;
{
long aux_11056;
aux_11056 = (long)(current_char_37_2512);
test_11055 = (aux_11056>=((long)65));
}
if(test_11055){
long aux_11059;
aux_11059 = (long)(current_char_37_2512);
test_11054 = (aux_11059<((long)71));
}
 else {
test_11054 = ((bool_t)0);
}
}
if(test_11054){
test_11045 = ((bool_t)1);
}
 else {
bool_t test_11062;
{
long aux_11063;
aux_11063 = (long)(current_char_37_2512);
test_11062 = (aux_11063>=((long)97));
}
if(test_11062){
long aux_11066;
aux_11066 = (long)(current_char_37_2512);
test_11045 = (aux_11066<((long)103));
}
 else {
test_11045 = ((bool_t)0);
}
}
}
}
if(test_11045){
last_match_133_2656 = last_match_133_2510;
state_80_1082_10_2717:
{
int current_char_37_2658;
current_char_37_2658 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11070;
{
long aux_11071;
aux_11071 = (long)(current_char_37_2658);
test_11070 = (aux_11071==((long)0));
}
if(test_11070){
{
bool_t test3044_2660;
{
bool_t res3429_6774;
{
bool_t _andtest_1237_6771;
_andtest_1237_6771 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6771){
res3429_6774 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3429_6774 = ((bool_t)0);
}
}
test3044_2660 = res3429_6774;
}
if(test3044_2660){
goto state_80_1082_10_2717;
}
 else {
aux_7016 = last_match_133_2656;
}
}
}
 else {
bool_t test_11078;
{
bool_t test_11079;
{
bool_t test_11080;
{
long aux_11081;
aux_11081 = (long)(current_char_37_2658);
test_11080 = (aux_11081>=((long)48));
}
if(test_11080){
long aux_11084;
aux_11084 = (long)(current_char_37_2658);
test_11079 = (aux_11084<((long)58));
}
 else {
test_11079 = ((bool_t)0);
}
}
if(test_11079){
test_11078 = ((bool_t)1);
}
 else {
bool_t test_11087;
{
bool_t test_11088;
{
long aux_11089;
aux_11089 = (long)(current_char_37_2658);
test_11088 = (aux_11089>=((long)65));
}
if(test_11088){
long aux_11092;
aux_11092 = (long)(current_char_37_2658);
test_11087 = (aux_11092<((long)71));
}
 else {
test_11087 = ((bool_t)0);
}
}
if(test_11087){
test_11078 = ((bool_t)1);
}
 else {
bool_t test_11095;
{
long aux_11096;
aux_11096 = (long)(current_char_37_2658);
test_11095 = (aux_11096>=((long)97));
}
if(test_11095){
long aux_11099;
aux_11099 = (long)(current_char_37_2658);
test_11078 = (aux_11099<((long)103));
}
 else {
test_11078 = ((bool_t)0);
}
}
}
}
if(test_11078){
last_match_133_1276 = last_match_133_2656;
state_81_1083_80_2790:
{
int current_char_37_1278;
current_char_37_1278 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11103;
{
long aux_11104;
aux_11104 = (long)(current_char_37_1278);
test_11103 = (aux_11104==((long)0));
}
if(test_11103){
{
bool_t test1944_1280;
{
bool_t res3372_4180;
{
bool_t _andtest_1237_4177;
_andtest_1237_4177 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4177){
res3372_4180 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3372_4180 = ((bool_t)0);
}
}
test1944_1280 = res3372_4180;
}
if(test1944_1280){
goto state_81_1083_80_2790;
}
 else {
aux_7016 = last_match_133_1276;
}
}
}
 else {
bool_t test_11111;
{
bool_t test_11112;
{
bool_t test_11113;
{
long aux_11114;
aux_11114 = (long)(current_char_37_1278);
test_11113 = (aux_11114>=((long)48));
}
if(test_11113){
long aux_11117;
aux_11117 = (long)(current_char_37_1278);
test_11112 = (aux_11117<((long)58));
}
 else {
test_11112 = ((bool_t)0);
}
}
if(test_11112){
test_11111 = ((bool_t)1);
}
 else {
bool_t test_11120;
{
bool_t test_11121;
{
long aux_11122;
aux_11122 = (long)(current_char_37_1278);
test_11121 = (aux_11122>=((long)65));
}
if(test_11121){
long aux_11125;
aux_11125 = (long)(current_char_37_1278);
test_11120 = (aux_11125<((long)71));
}
 else {
test_11120 = ((bool_t)0);
}
}
if(test_11120){
test_11111 = ((bool_t)1);
}
 else {
bool_t test_11128;
{
long aux_11129;
aux_11129 = (long)(current_char_37_1278);
test_11128 = (aux_11129>=((long)97));
}
if(test_11128){
long aux_11132;
aux_11132 = (long)(current_char_37_1278);
test_11111 = (aux_11132<((long)103));
}
 else {
test_11111 = ((bool_t)0);
}
}
}
}
if(test_11111){
last_match_133_1352 = last_match_133_1276;
state_82_1084_89_2788:
{
long new_match_93_1354;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1354 = ((long)4);
{
int current_char_37_1355;
current_char_37_1355 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11137;
{
long aux_11138;
aux_11138 = (long)(current_char_37_1355);
test_11137 = (aux_11138==((long)0));
}
if(test_11137){
{
bool_t test2013_1357;
{
bool_t res3374_4334;
{
bool_t _andtest_1237_4331;
_andtest_1237_4331 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4331){
res3374_4334 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3374_4334 = ((bool_t)0);
}
}
test2013_1357 = res3374_4334;
}
if(test2013_1357){
goto state_82_1084_89_2788;
}
 else {
aux_7016 = new_match_93_1354;
}
}
}
 else {
bool_t test2014_1358;
{
long aux_11145;
aux_11145 = (long)(current_char_37_1355);
test2014_1358 = (aux_11145==((long)40));
}
if(test2014_1358){
{
long new_match_93_4338;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4338 = ((long)35);
aux_7016 = new_match_93_4338;
}
}
 else {
bool_t test_11150;
{
bool_t test_11151;
{
long aux_11152;
aux_11152 = (long)(current_char_37_1355);
test_11151 = (aux_11152<((long)33));
}
if(test_11151){
test_11150 = ((bool_t)1);
}
 else {
bool_t test_11155;
{
bool_t test_11156;
{
long aux_11157;
aux_11157 = (long)(current_char_37_1355);
test_11156 = (aux_11157==((long)35));
}
if(test_11156){
test_11155 = ((bool_t)1);
}
 else {
long aux_11160;
aux_11160 = (long)(current_char_37_1355);
test_11155 = (aux_11160==((long)34));
}
}
if(test_11155){
test_11150 = ((bool_t)1);
}
 else {
bool_t test_11163;
{
bool_t test_11164;
{
long aux_11165;
aux_11165 = (long)(current_char_37_1355);
test_11164 = (aux_11165==((long)41));
}
if(test_11164){
test_11163 = ((bool_t)1);
}
 else {
test_11163 = test2014_1358;
}
}
if(test_11163){
test_11150 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1355)){
case ((long)59) : 
test_11150 = ((bool_t)1);
break;
case ((long)91) : 
test_11150 = ((bool_t)1);
break;
case ((long)93) : 
test_11150 = ((bool_t)1);
break;
case ((long)123) : 
test_11150 = ((bool_t)1);
break;
case ((long)125) : 
test_11150 = ((bool_t)1);
break;
default: 
{
long aux_11168;
aux_11168 = (long)(current_char_37_1355);
test_11150 = (aux_11168==((long)127));
}
}
}
}
}
}
if(test_11150){
aux_7016 = new_match_93_1354;
}
 else {
{
long last_match_133_11173;
last_match_133_11173 = new_match_93_1354;
last_match_133_1002 = last_match_133_11173;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test1946_1282;
{
long aux_11174;
aux_11174 = (long)(current_char_37_1278);
test1946_1282 = (aux_11174==((long)40));
}
if(test1946_1282){
{
long new_match_93_4196;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4196 = ((long)35);
aux_7016 = new_match_93_4196;
}
}
 else {
bool_t test_11179;
{
bool_t test_11180;
{
long aux_11181;
aux_11181 = (long)(current_char_37_1278);
test_11180 = (aux_11181<((long)33));
}
if(test_11180){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11184;
{
bool_t test_11185;
{
long aux_11186;
aux_11186 = (long)(current_char_37_1278);
test_11185 = (aux_11186==((long)35));
}
if(test_11185){
test_11184 = ((bool_t)1);
}
 else {
long aux_11189;
aux_11189 = (long)(current_char_37_1278);
test_11184 = (aux_11189==((long)34));
}
}
if(test_11184){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11192;
{
bool_t test_11193;
{
long aux_11194;
aux_11194 = (long)(current_char_37_1278);
test_11193 = (aux_11194==((long)41));
}
if(test_11193){
test_11192 = ((bool_t)1);
}
 else {
test_11192 = test1946_1282;
}
}
if(test_11192){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11197;
{
bool_t test_11198;
{
long aux_11199;
aux_11199 = (long)(current_char_37_1278);
test_11198 = (aux_11199>=((long)48));
}
if(test_11198){
long aux_11202;
aux_11202 = (long)(current_char_37_1278);
test_11197 = (aux_11202<((long)58));
}
 else {
test_11197 = ((bool_t)0);
}
}
if(test_11197){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11205;
{
long aux_11206;
aux_11206 = (long)(current_char_37_1278);
test_11205 = (aux_11206==((long)59));
}
if(test_11205){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11209;
{
bool_t test_11210;
{
long aux_11211;
aux_11211 = (long)(current_char_37_1278);
test_11210 = (aux_11211>=((long)65));
}
if(test_11210){
long aux_11214;
aux_11214 = (long)(current_char_37_1278);
test_11209 = (aux_11214<((long)71));
}
 else {
test_11209 = ((bool_t)0);
}
}
if(test_11209){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11217;
{
long aux_11218;
aux_11218 = (long)(current_char_37_1278);
test_11217 = (aux_11218==((long)91));
}
if(test_11217){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11221;
{
long aux_11222;
aux_11222 = (long)(current_char_37_1278);
test_11221 = (aux_11222==((long)93));
}
if(test_11221){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11225;
{
bool_t test_11226;
{
long aux_11227;
aux_11227 = (long)(current_char_37_1278);
test_11226 = (aux_11227>=((long)97));
}
if(test_11226){
long aux_11230;
aux_11230 = (long)(current_char_37_1278);
test_11225 = (aux_11230<((long)103));
}
 else {
test_11225 = ((bool_t)0);
}
}
if(test_11225){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11233;
{
long aux_11234;
aux_11234 = (long)(current_char_37_1278);
test_11233 = (aux_11234==((long)123));
}
if(test_11233){
test_11179 = ((bool_t)1);
}
 else {
bool_t test_11237;
{
long aux_11238;
aux_11238 = (long)(current_char_37_1278);
test_11237 = (aux_11238==((long)125));
}
if(test_11237){
test_11179 = ((bool_t)1);
}
 else {
long aux_11241;
aux_11241 = (long)(current_char_37_1278);
test_11179 = (aux_11241==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_11179){
aux_7016 = last_match_133_1276;
}
 else {
{
long last_match_133_11244;
last_match_133_11244 = last_match_133_1276;
last_match_133_1002 = last_match_133_11244;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test3046_2662;
{
long aux_11245;
aux_11245 = (long)(current_char_37_2658);
test3046_2662 = (aux_11245==((long)40));
}
if(test3046_2662){
{
long new_match_93_6790;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6790 = ((long)35);
aux_7016 = new_match_93_6790;
}
}
 else {
bool_t test_11250;
{
bool_t test_11251;
{
long aux_11252;
aux_11252 = (long)(current_char_37_2658);
test_11251 = (aux_11252<((long)33));
}
if(test_11251){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11255;
{
bool_t test_11256;
{
long aux_11257;
aux_11257 = (long)(current_char_37_2658);
test_11256 = (aux_11257==((long)35));
}
if(test_11256){
test_11255 = ((bool_t)1);
}
 else {
long aux_11260;
aux_11260 = (long)(current_char_37_2658);
test_11255 = (aux_11260==((long)34));
}
}
if(test_11255){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11263;
{
bool_t test_11264;
{
long aux_11265;
aux_11265 = (long)(current_char_37_2658);
test_11264 = (aux_11265==((long)41));
}
if(test_11264){
test_11263 = ((bool_t)1);
}
 else {
test_11263 = test3046_2662;
}
}
if(test_11263){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11268;
{
bool_t test_11269;
{
long aux_11270;
aux_11270 = (long)(current_char_37_2658);
test_11269 = (aux_11270>=((long)48));
}
if(test_11269){
long aux_11273;
aux_11273 = (long)(current_char_37_2658);
test_11268 = (aux_11273<((long)58));
}
 else {
test_11268 = ((bool_t)0);
}
}
if(test_11268){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11276;
{
long aux_11277;
aux_11277 = (long)(current_char_37_2658);
test_11276 = (aux_11277==((long)59));
}
if(test_11276){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11280;
{
bool_t test_11281;
{
long aux_11282;
aux_11282 = (long)(current_char_37_2658);
test_11281 = (aux_11282>=((long)65));
}
if(test_11281){
long aux_11285;
aux_11285 = (long)(current_char_37_2658);
test_11280 = (aux_11285<((long)71));
}
 else {
test_11280 = ((bool_t)0);
}
}
if(test_11280){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11288;
{
long aux_11289;
aux_11289 = (long)(current_char_37_2658);
test_11288 = (aux_11289==((long)91));
}
if(test_11288){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11292;
{
long aux_11293;
aux_11293 = (long)(current_char_37_2658);
test_11292 = (aux_11293==((long)93));
}
if(test_11292){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11296;
{
bool_t test_11297;
{
long aux_11298;
aux_11298 = (long)(current_char_37_2658);
test_11297 = (aux_11298>=((long)97));
}
if(test_11297){
long aux_11301;
aux_11301 = (long)(current_char_37_2658);
test_11296 = (aux_11301<((long)103));
}
 else {
test_11296 = ((bool_t)0);
}
}
if(test_11296){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11304;
{
long aux_11305;
aux_11305 = (long)(current_char_37_2658);
test_11304 = (aux_11305==((long)123));
}
if(test_11304){
test_11250 = ((bool_t)1);
}
 else {
bool_t test_11308;
{
long aux_11309;
aux_11309 = (long)(current_char_37_2658);
test_11308 = (aux_11309==((long)125));
}
if(test_11308){
test_11250 = ((bool_t)1);
}
 else {
long aux_11312;
aux_11312 = (long)(current_char_37_2658);
test_11250 = (aux_11312==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_11250){
aux_7016 = last_match_133_2656;
}
 else {
{
long last_match_133_11315;
last_match_133_11315 = last_match_133_2656;
last_match_133_1002 = last_match_133_11315;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test2928_2516;
{
long aux_11316;
aux_11316 = (long)(current_char_37_2512);
test2928_2516 = (aux_11316==((long)40));
}
if(test2928_2516){
{
long new_match_93_6515;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6515 = ((long)35);
aux_7016 = new_match_93_6515;
}
}
 else {
bool_t test_11321;
{
bool_t test_11322;
{
long aux_11323;
aux_11323 = (long)(current_char_37_2512);
test_11322 = (aux_11323<((long)33));
}
if(test_11322){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11326;
{
bool_t test_11327;
{
long aux_11328;
aux_11328 = (long)(current_char_37_2512);
test_11327 = (aux_11328==((long)35));
}
if(test_11327){
test_11326 = ((bool_t)1);
}
 else {
long aux_11331;
aux_11331 = (long)(current_char_37_2512);
test_11326 = (aux_11331==((long)34));
}
}
if(test_11326){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11334;
{
bool_t test_11335;
{
long aux_11336;
aux_11336 = (long)(current_char_37_2512);
test_11335 = (aux_11336==((long)41));
}
if(test_11335){
test_11334 = ((bool_t)1);
}
 else {
test_11334 = test2928_2516;
}
}
if(test_11334){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11339;
{
bool_t test_11340;
{
long aux_11341;
aux_11341 = (long)(current_char_37_2512);
test_11340 = (aux_11341>=((long)48));
}
if(test_11340){
long aux_11344;
aux_11344 = (long)(current_char_37_2512);
test_11339 = (aux_11344<((long)58));
}
 else {
test_11339 = ((bool_t)0);
}
}
if(test_11339){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11347;
{
long aux_11348;
aux_11348 = (long)(current_char_37_2512);
test_11347 = (aux_11348==((long)59));
}
if(test_11347){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11351;
{
bool_t test_11352;
{
long aux_11353;
aux_11353 = (long)(current_char_37_2512);
test_11352 = (aux_11353>=((long)65));
}
if(test_11352){
long aux_11356;
aux_11356 = (long)(current_char_37_2512);
test_11351 = (aux_11356<((long)71));
}
 else {
test_11351 = ((bool_t)0);
}
}
if(test_11351){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11359;
{
long aux_11360;
aux_11360 = (long)(current_char_37_2512);
test_11359 = (aux_11360==((long)91));
}
if(test_11359){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11363;
{
long aux_11364;
aux_11364 = (long)(current_char_37_2512);
test_11363 = (aux_11364==((long)93));
}
if(test_11363){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11367;
{
bool_t test_11368;
{
long aux_11369;
aux_11369 = (long)(current_char_37_2512);
test_11368 = (aux_11369>=((long)97));
}
if(test_11368){
long aux_11372;
aux_11372 = (long)(current_char_37_2512);
test_11367 = (aux_11372<((long)103));
}
 else {
test_11367 = ((bool_t)0);
}
}
if(test_11367){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11375;
{
long aux_11376;
aux_11376 = (long)(current_char_37_2512);
test_11375 = (aux_11376==((long)123));
}
if(test_11375){
test_11321 = ((bool_t)1);
}
 else {
bool_t test_11379;
{
long aux_11380;
aux_11380 = (long)(current_char_37_2512);
test_11379 = (aux_11380==((long)125));
}
if(test_11379){
test_11321 = ((bool_t)1);
}
 else {
long aux_11383;
aux_11383 = (long)(current_char_37_2512);
test_11321 = (aux_11383==((long)127));
}
}
}
}
}
}
}
}
}
}
}
}
if(test_11321){
aux_7016 = last_match_133_2510;
}
 else {
{
long last_match_133_11386;
last_match_133_11386 = last_match_133_2510;
last_match_133_1002 = last_match_133_11386;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
break;
case ((long)92) : 
last_match_133_2479 = new_match_93_1842;
state_45_1047_90_2727:
{
int current_char_37_2481;
current_char_37_2481 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11388;
{
long aux_11389;
aux_11389 = (long)(current_char_37_2481);
test_11388 = (aux_11389==((long)0));
}
if(test_11388){
{
bool_t test2900_2483;
{
bool_t res3422_6435;
{
bool_t _andtest_1237_6432;
_andtest_1237_6432 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6432){
res3422_6435 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3422_6435 = ((bool_t)0);
}
}
test2900_2483 = res3422_6435;
}
if(test2900_2483){
goto state_45_1047_90_2727;
}
 else {
aux_7016 = last_match_133_2479;
}
}
}
 else {
bool_t test_11396;
{
bool_t test_11397;
{
long aux_11398;
aux_11398 = (long)(current_char_37_2481);
test_11397 = (aux_11398<((long)65));
}
if(test_11397){
test_11396 = ((bool_t)1);
}
 else {
bool_t test_11401;
{
bool_t test_11402;
{
long aux_11403;
aux_11403 = (long)(current_char_37_2481);
test_11402 = (aux_11403>=((long)91));
}
if(test_11402){
long aux_11406;
aux_11406 = (long)(current_char_37_2481);
test_11401 = (aux_11406<((long)97));
}
 else {
test_11401 = ((bool_t)0);
}
}
if(test_11401){
test_11396 = ((bool_t)1);
}
 else {
bool_t test_11409;
{
long aux_11410;
aux_11410 = (long)(current_char_37_2481);
test_11409 = (aux_11410>=((long)123));
}
if(test_11409){
long aux_11413;
aux_11413 = (long)(current_char_37_2481);
test_11396 = (aux_11413<((long)128));
}
 else {
test_11396 = ((bool_t)0);
}
}
}
}
if(test_11396){
bool_t test_11416;
{
long aux_11417;
aux_11417 = (long)(current_char_37_2481);
test_11416 = (aux_11417==((long)40));
}
if(test_11416){
{
long new_match_93_6449;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6449 = ((long)5);
aux_7016 = new_match_93_6449;
}
}
 else {
bool_t test_11421;
{
bool_t test_11422;
{
long aux_11423;
aux_11423 = (long)(current_char_37_2481);
test_11422 = (aux_11423==((long)33));
}
if(test_11422){
test_11421 = ((bool_t)1);
}
 else {
bool_t test_11426;
{
bool_t test_11427;
{
long aux_11428;
aux_11428 = (long)(current_char_37_2481);
test_11427 = (aux_11428>=((long)36));
}
if(test_11427){
long aux_11431;
aux_11431 = (long)(current_char_37_2481);
test_11426 = (aux_11431<((long)40));
}
 else {
test_11426 = ((bool_t)0);
}
}
if(test_11426){
test_11421 = ((bool_t)1);
}
 else {
bool_t test_11434;
{
bool_t test_11435;
{
long aux_11436;
aux_11436 = (long)(current_char_37_2481);
test_11435 = (aux_11436>=((long)42));
}
if(test_11435){
long aux_11439;
aux_11439 = (long)(current_char_37_2481);
test_11434 = (aux_11439<((long)59));
}
 else {
test_11434 = ((bool_t)0);
}
}
if(test_11434){
test_11421 = ((bool_t)1);
}
 else {
bool_t test_11442;
{
bool_t test_11443;
{
long aux_11444;
aux_11444 = (long)(current_char_37_2481);
test_11443 = (aux_11444>=((long)60));
}
if(test_11443){
long aux_11447;
aux_11447 = (long)(current_char_37_2481);
test_11442 = (aux_11447<((long)65));
}
 else {
test_11442 = ((bool_t)0);
}
}
if(test_11442){
test_11421 = ((bool_t)1);
}
 else {
bool_t test_11450;
{
long aux_11451;
aux_11451 = (long)(current_char_37_2481);
test_11450 = (aux_11451==((long)92));
}
if(test_11450){
test_11421 = ((bool_t)1);
}
 else {
bool_t test_11454;
{
bool_t test_11455;
{
long aux_11456;
aux_11456 = (long)(current_char_37_2481);
test_11455 = (aux_11456==((long)96));
}
if(test_11455){
test_11454 = ((bool_t)1);
}
 else {
bool_t test_11459;
{
long aux_11460;
aux_11460 = (long)(current_char_37_2481);
test_11459 = (aux_11460==((long)95));
}
if(test_11459){
test_11454 = ((bool_t)1);
}
 else {
long aux_11463;
aux_11463 = (long)(current_char_37_2481);
test_11454 = (aux_11463==((long)94));
}
}
}
if(test_11454){
test_11421 = ((bool_t)1);
}
 else {
bool_t test_11466;
{
long aux_11467;
aux_11467 = (long)(current_char_37_2481);
test_11466 = (aux_11467==((long)124));
}
if(test_11466){
test_11421 = ((bool_t)1);
}
 else {
long aux_11470;
aux_11470 = (long)(current_char_37_2481);
test_11421 = (aux_11470==((long)126));
}
}
}
}
}
}
}
}
if(test_11421){
last_match_133_1131 = last_match_133_2479;
state_84_1086_36_2796:
{
long new_match_93_1133;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1133 = ((long)5);
{
int current_char_37_1134;
current_char_37_1134 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11475;
{
long aux_11476;
aux_11476 = (long)(current_char_37_1134);
test_11475 = (aux_11476==((long)0));
}
if(test_11475){
{
bool_t test1819_1136;
{
bool_t res3368_3906;
{
bool_t _andtest_1237_3903;
_andtest_1237_3903 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3903){
res3368_3906 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3368_3906 = ((bool_t)0);
}
}
test1819_1136 = res3368_3906;
}
if(test1819_1136){
goto state_84_1086_36_2796;
}
 else {
aux_7016 = new_match_93_1133;
}
}
}
 else {
bool_t test1820_1137;
{
long aux_11483;
aux_11483 = (long)(current_char_37_1134);
test1820_1137 = (aux_11483==((long)40));
}
if(test1820_1137){
{
long new_match_93_3910;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3910 = ((long)35);
aux_7016 = new_match_93_3910;
}
}
 else {
bool_t test_11488;
{
bool_t test_11489;
{
long aux_11490;
aux_11490 = (long)(current_char_37_1134);
test_11489 = (aux_11490<((long)33));
}
if(test_11489){
test_11488 = ((bool_t)1);
}
 else {
bool_t test_11493;
{
bool_t test_11494;
{
long aux_11495;
aux_11495 = (long)(current_char_37_1134);
test_11494 = (aux_11495==((long)35));
}
if(test_11494){
test_11493 = ((bool_t)1);
}
 else {
long aux_11498;
aux_11498 = (long)(current_char_37_1134);
test_11493 = (aux_11498==((long)34));
}
}
if(test_11493){
test_11488 = ((bool_t)1);
}
 else {
bool_t test_11501;
{
bool_t test_11502;
{
long aux_11503;
aux_11503 = (long)(current_char_37_1134);
test_11502 = (aux_11503==((long)41));
}
if(test_11502){
test_11501 = ((bool_t)1);
}
 else {
test_11501 = test1820_1137;
}
}
if(test_11501){
test_11488 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1134)){
case ((long)59) : 
test_11488 = ((bool_t)1);
break;
case ((long)91) : 
test_11488 = ((bool_t)1);
break;
case ((long)93) : 
test_11488 = ((bool_t)1);
break;
case ((long)123) : 
test_11488 = ((bool_t)1);
break;
case ((long)125) : 
test_11488 = ((bool_t)1);
break;
default: 
{
long aux_11506;
aux_11506 = (long)(current_char_37_1134);
test_11488 = (aux_11506==((long)127));
}
}
}
}
}
}
if(test_11488){
aux_7016 = new_match_93_1133;
}
 else {
{
long last_match_133_11511;
last_match_133_11511 = new_match_93_1133;
last_match_133_1002 = last_match_133_11511;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test_11512;
{
bool_t test_11513;
{
long aux_11514;
aux_11514 = (long)(current_char_37_2481);
test_11513 = (aux_11514==((long)32));
}
if(test_11513){
test_11512 = ((bool_t)1);
}
 else {
bool_t test_11517;
{
bool_t test_11518;
{
long aux_11519;
aux_11519 = (long)(current_char_37_2481);
test_11518 = (aux_11519==((long)35));
}
if(test_11518){
test_11517 = ((bool_t)1);
}
 else {
long aux_11522;
aux_11522 = (long)(current_char_37_2481);
test_11517 = (aux_11522==((long)34));
}
}
if(test_11517){
test_11512 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2481)){
case ((long)41) : 
test_11512 = ((bool_t)1);
break;
case ((long)59) : 
test_11512 = ((bool_t)1);
break;
case ((long)91) : 
test_11512 = ((bool_t)1);
break;
case ((long)93) : 
test_11512 = ((bool_t)1);
break;
case ((long)123) : 
test_11512 = ((bool_t)1);
break;
default: 
{
long aux_11525;
aux_11525 = (long)(current_char_37_2481);
test_11512 = (aux_11525==((long)125));
}
}
}
}
}
if(test_11512){
{
long new_match_93_6490;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6490 = ((long)5);
aux_7016 = new_match_93_6490;
}
}
 else {
aux_7016 = last_match_133_2479;
}
}
}
}
 else {
last_match_133_1147 = last_match_133_2479;
state_86_1088_98_2795:
{
long new_match_93_1149;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1149 = ((long)5);
{
int current_char_37_1150;
current_char_37_1150 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11533;
{
long aux_11534;
aux_11534 = (long)(current_char_37_1150);
test_11533 = (aux_11534==((long)0));
}
if(test_11533){
{
bool_t test1830_1152;
{
bool_t res3369_3936;
{
bool_t _andtest_1237_3933;
_andtest_1237_3933 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3933){
res3369_3936 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3369_3936 = ((bool_t)0);
}
}
test1830_1152 = res3369_3936;
}
if(test1830_1152){
goto state_86_1088_98_2795;
}
 else {
aux_7016 = new_match_93_1149;
}
}
}
 else {
bool_t test_11541;
{
bool_t test_11542;
{
long aux_11543;
aux_11543 = (long)(current_char_37_1150);
test_11542 = (aux_11543<((long)65));
}
if(test_11542){
test_11541 = ((bool_t)1);
}
 else {
bool_t test_11546;
{
bool_t test_11547;
{
long aux_11548;
aux_11548 = (long)(current_char_37_1150);
test_11547 = (aux_11548>=((long)91));
}
if(test_11547){
long aux_11551;
aux_11551 = (long)(current_char_37_1150);
test_11546 = (aux_11551<((long)97));
}
 else {
test_11546 = ((bool_t)0);
}
}
if(test_11546){
test_11541 = ((bool_t)1);
}
 else {
bool_t test_11554;
{
long aux_11555;
aux_11555 = (long)(current_char_37_1150);
test_11554 = (aux_11555>=((long)123));
}
if(test_11554){
long aux_11558;
aux_11558 = (long)(current_char_37_1150);
test_11541 = (aux_11558<((long)128));
}
 else {
test_11541 = ((bool_t)0);
}
}
}
}
if(test_11541){
bool_t test_11561;
{
long aux_11562;
aux_11562 = (long)(current_char_37_1150);
test_11561 = (aux_11562==((long)40));
}
if(test_11561){
{
long new_match_93_3950;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3950 = ((long)35);
aux_7016 = new_match_93_3950;
}
}
 else {
bool_t test_11566;
{
bool_t test_11567;
{
long aux_11568;
aux_11568 = (long)(current_char_37_1150);
test_11567 = (aux_11568==((long)33));
}
if(test_11567){
test_11566 = ((bool_t)1);
}
 else {
bool_t test_11571;
{
bool_t test_11572;
{
long aux_11573;
aux_11573 = (long)(current_char_37_1150);
test_11572 = (aux_11573>=((long)36));
}
if(test_11572){
long aux_11576;
aux_11576 = (long)(current_char_37_1150);
test_11571 = (aux_11576<((long)40));
}
 else {
test_11571 = ((bool_t)0);
}
}
if(test_11571){
test_11566 = ((bool_t)1);
}
 else {
bool_t test_11579;
{
bool_t test_11580;
{
long aux_11581;
aux_11581 = (long)(current_char_37_1150);
test_11580 = (aux_11581>=((long)42));
}
if(test_11580){
long aux_11584;
aux_11584 = (long)(current_char_37_1150);
test_11579 = (aux_11584<((long)59));
}
 else {
test_11579 = ((bool_t)0);
}
}
if(test_11579){
test_11566 = ((bool_t)1);
}
 else {
bool_t test_11587;
{
bool_t test_11588;
{
long aux_11589;
aux_11589 = (long)(current_char_37_1150);
test_11588 = (aux_11589>=((long)60));
}
if(test_11588){
long aux_11592;
aux_11592 = (long)(current_char_37_1150);
test_11587 = (aux_11592<((long)65));
}
 else {
test_11587 = ((bool_t)0);
}
}
if(test_11587){
test_11566 = ((bool_t)1);
}
 else {
bool_t test_11595;
{
long aux_11596;
aux_11596 = (long)(current_char_37_1150);
test_11595 = (aux_11596==((long)92));
}
if(test_11595){
test_11566 = ((bool_t)1);
}
 else {
bool_t test_11599;
{
bool_t test_11600;
{
long aux_11601;
aux_11601 = (long)(current_char_37_1150);
test_11600 = (aux_11601==((long)96));
}
if(test_11600){
test_11599 = ((bool_t)1);
}
 else {
bool_t test_11604;
{
long aux_11605;
aux_11605 = (long)(current_char_37_1150);
test_11604 = (aux_11605==((long)95));
}
if(test_11604){
test_11599 = ((bool_t)1);
}
 else {
long aux_11608;
aux_11608 = (long)(current_char_37_1150);
test_11599 = (aux_11608==((long)94));
}
}
}
if(test_11599){
test_11566 = ((bool_t)1);
}
 else {
bool_t test_11611;
{
long aux_11612;
aux_11612 = (long)(current_char_37_1150);
test_11611 = (aux_11612==((long)124));
}
if(test_11611){
test_11566 = ((bool_t)1);
}
 else {
long aux_11615;
aux_11615 = (long)(current_char_37_1150);
test_11566 = (aux_11615==((long)126));
}
}
}
}
}
}
}
}
if(test_11566){
{
long last_match_133_11618;
last_match_133_11618 = new_match_93_1149;
last_match_133_1002 = last_match_133_11618;
goto state_39_1041_8_2804;
}
}
 else {
aux_7016 = new_match_93_1149;
}
}
}
 else {
last_match_133_1635 = new_match_93_1149;
state_87_1089_212_2776:
{
long new_match_93_1637;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1637 = ((long)6);
{
int current_char_37_1638;
current_char_37_1638 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11621;
{
long aux_11622;
aux_11622 = (long)(current_char_37_1638);
test_11621 = (aux_11622==((long)0));
}
if(test_11621){
{
bool_t test2246_1640;
{
bool_t res3386_4887;
{
bool_t _andtest_1237_4884;
_andtest_1237_4884 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4884){
res3386_4887 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3386_4887 = ((bool_t)0);
}
}
test2246_1640 = res3386_4887;
}
if(test2246_1640){
goto state_87_1089_212_2776;
}
 else {
aux_7016 = new_match_93_1637;
}
}
}
 else {
bool_t test_11629;
{
bool_t test_11630;
{
long aux_11631;
aux_11631 = (long)(current_char_37_1638);
test_11630 = (aux_11631<((long)65));
}
if(test_11630){
test_11629 = ((bool_t)1);
}
 else {
bool_t test_11634;
{
bool_t test_11635;
{
long aux_11636;
aux_11636 = (long)(current_char_37_1638);
test_11635 = (aux_11636>=((long)91));
}
if(test_11635){
long aux_11639;
aux_11639 = (long)(current_char_37_1638);
test_11634 = (aux_11639<((long)97));
}
 else {
test_11634 = ((bool_t)0);
}
}
if(test_11634){
test_11629 = ((bool_t)1);
}
 else {
bool_t test_11642;
{
long aux_11643;
aux_11643 = (long)(current_char_37_1638);
test_11642 = (aux_11643>=((long)123));
}
if(test_11642){
long aux_11646;
aux_11646 = (long)(current_char_37_1638);
test_11629 = (aux_11646<((long)128));
}
 else {
test_11629 = ((bool_t)0);
}
}
}
}
if(test_11629){
bool_t test_11649;
{
long aux_11650;
aux_11650 = (long)(current_char_37_1638);
test_11649 = (aux_11650==((long)40));
}
if(test_11649){
{
long new_match_93_4901;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4901 = ((long)35);
aux_7016 = new_match_93_4901;
}
}
 else {
bool_t test_11654;
{
bool_t test_11655;
{
long aux_11656;
aux_11656 = (long)(current_char_37_1638);
test_11655 = (aux_11656==((long)33));
}
if(test_11655){
test_11654 = ((bool_t)1);
}
 else {
bool_t test_11659;
{
bool_t test_11660;
{
long aux_11661;
aux_11661 = (long)(current_char_37_1638);
test_11660 = (aux_11661>=((long)36));
}
if(test_11660){
long aux_11664;
aux_11664 = (long)(current_char_37_1638);
test_11659 = (aux_11664<((long)40));
}
 else {
test_11659 = ((bool_t)0);
}
}
if(test_11659){
test_11654 = ((bool_t)1);
}
 else {
bool_t test_11667;
{
bool_t test_11668;
{
long aux_11669;
aux_11669 = (long)(current_char_37_1638);
test_11668 = (aux_11669>=((long)42));
}
if(test_11668){
long aux_11672;
aux_11672 = (long)(current_char_37_1638);
test_11667 = (aux_11672<((long)59));
}
 else {
test_11667 = ((bool_t)0);
}
}
if(test_11667){
test_11654 = ((bool_t)1);
}
 else {
bool_t test_11675;
{
bool_t test_11676;
{
long aux_11677;
aux_11677 = (long)(current_char_37_1638);
test_11676 = (aux_11677>=((long)60));
}
if(test_11676){
long aux_11680;
aux_11680 = (long)(current_char_37_1638);
test_11675 = (aux_11680<((long)65));
}
 else {
test_11675 = ((bool_t)0);
}
}
if(test_11675){
test_11654 = ((bool_t)1);
}
 else {
bool_t test_11683;
{
long aux_11684;
aux_11684 = (long)(current_char_37_1638);
test_11683 = (aux_11684==((long)92));
}
if(test_11683){
test_11654 = ((bool_t)1);
}
 else {
bool_t test_11687;
{
bool_t test_11688;
{
long aux_11689;
aux_11689 = (long)(current_char_37_1638);
test_11688 = (aux_11689==((long)96));
}
if(test_11688){
test_11687 = ((bool_t)1);
}
 else {
bool_t test_11692;
{
long aux_11693;
aux_11693 = (long)(current_char_37_1638);
test_11692 = (aux_11693==((long)95));
}
if(test_11692){
test_11687 = ((bool_t)1);
}
 else {
long aux_11696;
aux_11696 = (long)(current_char_37_1638);
test_11687 = (aux_11696==((long)94));
}
}
}
if(test_11687){
test_11654 = ((bool_t)1);
}
 else {
bool_t test_11699;
{
long aux_11700;
aux_11700 = (long)(current_char_37_1638);
test_11699 = (aux_11700==((long)124));
}
if(test_11699){
test_11654 = ((bool_t)1);
}
 else {
long aux_11703;
aux_11703 = (long)(current_char_37_1638);
test_11654 = (aux_11703==((long)126));
}
}
}
}
}
}
}
}
if(test_11654){
{
long last_match_133_11706;
last_match_133_11706 = new_match_93_1637;
last_match_133_1002 = last_match_133_11706;
goto state_39_1041_8_2804;
}
}
 else {
aux_7016 = new_match_93_1637;
}
}
}
 else {
{
long last_match_133_11707;
last_match_133_11707 = new_match_93_1637;
last_match_133_1635 = last_match_133_11707;
goto state_87_1089_212_2776;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
break;
case ((long)116) : 
case ((long)84) : 
last_match_133_1053 = new_match_93_1842;
state_44_1046_246_2801:
{
long new_match_93_1055;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1055 = ((long)23);
{
int current_char_37_1056;
current_char_37_1056 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11710;
{
long aux_11711;
aux_11711 = (long)(current_char_37_1056);
test_11710 = (aux_11711==((long)0));
}
if(test_11710){
{
bool_t test1761_1058;
{
bool_t res3364_3764;
{
bool_t _andtest_1237_3761;
_andtest_1237_3761 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3761){
res3364_3764 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3364_3764 = ((bool_t)0);
}
}
test1761_1058 = res3364_3764;
}
if(test1761_1058){
goto state_44_1046_246_2801;
}
 else {
aux_7016 = new_match_93_1055;
}
}
}
 else {
bool_t test1762_1059;
{
long aux_11718;
aux_11718 = (long)(current_char_37_1056);
test1762_1059 = (aux_11718==((long)40));
}
if(test1762_1059){
{
long new_match_93_3768;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3768 = ((long)35);
aux_7016 = new_match_93_3768;
}
}
 else {
bool_t test_11723;
{
bool_t test_11724;
{
long aux_11725;
aux_11725 = (long)(current_char_37_1056);
test_11724 = (aux_11725<((long)33));
}
if(test_11724){
test_11723 = ((bool_t)1);
}
 else {
bool_t test_11728;
{
bool_t test_11729;
{
long aux_11730;
aux_11730 = (long)(current_char_37_1056);
test_11729 = (aux_11730==((long)35));
}
if(test_11729){
test_11728 = ((bool_t)1);
}
 else {
long aux_11733;
aux_11733 = (long)(current_char_37_1056);
test_11728 = (aux_11733==((long)34));
}
}
if(test_11728){
test_11723 = ((bool_t)1);
}
 else {
bool_t test_11736;
{
bool_t test_11737;
{
long aux_11738;
aux_11738 = (long)(current_char_37_1056);
test_11737 = (aux_11738==((long)41));
}
if(test_11737){
test_11736 = ((bool_t)1);
}
 else {
test_11736 = test1762_1059;
}
}
if(test_11736){
test_11723 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1056)){
case ((long)59) : 
test_11723 = ((bool_t)1);
break;
case ((long)91) : 
test_11723 = ((bool_t)1);
break;
case ((long)93) : 
test_11723 = ((bool_t)1);
break;
case ((long)123) : 
test_11723 = ((bool_t)1);
break;
case ((long)125) : 
test_11723 = ((bool_t)1);
break;
default: 
{
long aux_11741;
aux_11741 = (long)(current_char_37_1056);
test_11723 = (aux_11741==((long)127));
}
}
}
}
}
}
if(test_11723){
aux_7016 = new_match_93_1055;
}
 else {
{
long last_match_133_11746;
last_match_133_11746 = new_match_93_1055;
last_match_133_1002 = last_match_133_11746;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
break;
case ((long)102) : 
case ((long)70) : 
last_match_133_1037 = new_match_93_1842;
state_43_1045_31_2802:
{
long new_match_93_1039;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1039 = ((long)24);
{
int current_char_37_1040;
current_char_37_1040 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11749;
{
long aux_11750;
aux_11750 = (long)(current_char_37_1040);
test_11749 = (aux_11750==((long)0));
}
if(test_11749){
{
bool_t test1750_1042;
{
bool_t res3363_3734;
{
bool_t _andtest_1237_3731;
_andtest_1237_3731 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3731){
res3363_3734 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3363_3734 = ((bool_t)0);
}
}
test1750_1042 = res3363_3734;
}
if(test1750_1042){
goto state_43_1045_31_2802;
}
 else {
aux_7016 = new_match_93_1039;
}
}
}
 else {
bool_t test1751_1043;
{
long aux_11757;
aux_11757 = (long)(current_char_37_1040);
test1751_1043 = (aux_11757==((long)40));
}
if(test1751_1043){
{
long new_match_93_3738;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_3738 = ((long)35);
aux_7016 = new_match_93_3738;
}
}
 else {
bool_t test_11762;
{
bool_t test_11763;
{
long aux_11764;
aux_11764 = (long)(current_char_37_1040);
test_11763 = (aux_11764<((long)33));
}
if(test_11763){
test_11762 = ((bool_t)1);
}
 else {
bool_t test_11767;
{
bool_t test_11768;
{
long aux_11769;
aux_11769 = (long)(current_char_37_1040);
test_11768 = (aux_11769==((long)35));
}
if(test_11768){
test_11767 = ((bool_t)1);
}
 else {
long aux_11772;
aux_11772 = (long)(current_char_37_1040);
test_11767 = (aux_11772==((long)34));
}
}
if(test_11767){
test_11762 = ((bool_t)1);
}
 else {
bool_t test_11775;
{
bool_t test_11776;
{
long aux_11777;
aux_11777 = (long)(current_char_37_1040);
test_11776 = (aux_11777==((long)41));
}
if(test_11776){
test_11775 = ((bool_t)1);
}
 else {
test_11775 = test1751_1043;
}
}
if(test_11775){
test_11762 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1040)){
case ((long)59) : 
test_11762 = ((bool_t)1);
break;
case ((long)91) : 
test_11762 = ((bool_t)1);
break;
case ((long)93) : 
test_11762 = ((bool_t)1);
break;
case ((long)123) : 
test_11762 = ((bool_t)1);
break;
case ((long)125) : 
test_11762 = ((bool_t)1);
break;
default: 
{
long aux_11780;
aux_11780 = (long)(current_char_37_1040);
test_11762 = (aux_11780==((long)127));
}
}
}
}
}
}
if(test_11762){
aux_7016 = new_match_93_1039;
}
 else {
{
long last_match_133_11785;
last_match_133_11785 = new_match_93_1039;
last_match_133_1002 = last_match_133_11785;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
break;
case ((long)60) : 
last_match_133_2456 = new_match_93_1842;
state_42_1044_132_2728:
{
int current_char_37_2458;
current_char_37_2458 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11787;
{
long aux_11788;
aux_11788 = (long)(current_char_37_2458);
test_11787 = (aux_11788==((long)0));
}
if(test_11787){
{
bool_t test2883_2460;
{
bool_t res3421_6392;
{
bool_t _andtest_1237_6389;
_andtest_1237_6389 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6389){
res3421_6392 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3421_6392 = ((bool_t)0);
}
}
test2883_2460 = res3421_6392;
}
if(test2883_2460){
goto state_42_1044_132_2728;
}
 else {
aux_7016 = last_match_133_2456;
}
}
}
 else {
bool_t test_11795;
{
bool_t test_11796;
{
bool_t test_11797;
{
long aux_11798;
aux_11798 = (long)(current_char_37_2458);
test_11797 = (aux_11798>=((long)48));
}
if(test_11797){
long aux_11801;
aux_11801 = (long)(current_char_37_2458);
test_11796 = (aux_11801<((long)58));
}
 else {
test_11796 = ((bool_t)0);
}
}
if(test_11796){
test_11795 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2458)){
case ((long)65) : 
test_11795 = ((bool_t)1);
break;
case ((long)70) : 
test_11795 = ((bool_t)1);
break;
case ((long)97) : 
test_11795 = ((bool_t)1);
break;
default: 
{
long aux_11804;
aux_11804 = (long)(current_char_37_2458);
test_11795 = (aux_11804==((long)102));
}
}
}
}
if(test_11795){
last_match_133_1491 = last_match_133_2456;
state_88_1090_127_2782:
{
int current_char_37_1493;
current_char_37_1493 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11810;
{
long aux_11811;
aux_11811 = (long)(current_char_37_1493);
test_11810 = (aux_11811==((long)0));
}
if(test_11810){
{
bool_t test2127_1495;
{
bool_t res3380_4603;
{
bool_t _andtest_1237_4600;
_andtest_1237_4600 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4600){
res3380_4603 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3380_4603 = ((bool_t)0);
}
}
test2127_1495 = res3380_4603;
}
if(test2127_1495){
goto state_88_1090_127_2782;
}
 else {
aux_7016 = last_match_133_1491;
}
}
}
 else {
bool_t test_11818;
{
long aux_11819;
aux_11819 = (long)(current_char_37_1493);
test_11818 = (aux_11819==((long)62));
}
if(test_11818){
last_match_133_1515 = last_match_133_1491;
state_89_1091_108_2781:
{
long new_match_93_1517;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1517 = ((long)25);
{
int current_char_37_1518;
current_char_37_1518 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11824;
{
long aux_11825;
aux_11825 = (long)(current_char_37_1518);
test_11824 = (aux_11825==((long)0));
}
if(test_11824){
{
bool_t test2145_1520;
{
bool_t res3381_4649;
{
bool_t _andtest_1237_4646;
_andtest_1237_4646 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4646){
res3381_4649 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3381_4649 = ((bool_t)0);
}
}
test2145_1520 = res3381_4649;
}
if(test2145_1520){
goto state_89_1091_108_2781;
}
 else {
aux_7016 = new_match_93_1517;
}
}
}
 else {
bool_t test2146_1521;
{
long aux_11832;
aux_11832 = (long)(current_char_37_1518);
test2146_1521 = (aux_11832==((long)40));
}
if(test2146_1521){
{
long new_match_93_4653;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4653 = ((long)35);
aux_7016 = new_match_93_4653;
}
}
 else {
bool_t test_11837;
{
bool_t test_11838;
{
long aux_11839;
aux_11839 = (long)(current_char_37_1518);
test_11838 = (aux_11839<((long)33));
}
if(test_11838){
test_11837 = ((bool_t)1);
}
 else {
bool_t test_11842;
{
bool_t test_11843;
{
long aux_11844;
aux_11844 = (long)(current_char_37_1518);
test_11843 = (aux_11844==((long)35));
}
if(test_11843){
test_11842 = ((bool_t)1);
}
 else {
long aux_11847;
aux_11847 = (long)(current_char_37_1518);
test_11842 = (aux_11847==((long)34));
}
}
if(test_11842){
test_11837 = ((bool_t)1);
}
 else {
bool_t test_11850;
{
bool_t test_11851;
{
long aux_11852;
aux_11852 = (long)(current_char_37_1518);
test_11851 = (aux_11852==((long)41));
}
if(test_11851){
test_11850 = ((bool_t)1);
}
 else {
test_11850 = test2146_1521;
}
}
if(test_11850){
test_11837 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1518)){
case ((long)59) : 
test_11837 = ((bool_t)1);
break;
case ((long)91) : 
test_11837 = ((bool_t)1);
break;
case ((long)93) : 
test_11837 = ((bool_t)1);
break;
case ((long)123) : 
test_11837 = ((bool_t)1);
break;
case ((long)125) : 
test_11837 = ((bool_t)1);
break;
default: 
{
long aux_11855;
aux_11855 = (long)(current_char_37_1518);
test_11837 = (aux_11855==((long)127));
}
}
}
}
}
}
if(test_11837){
aux_7016 = new_match_93_1517;
}
 else {
{
long last_match_133_11860;
last_match_133_11860 = new_match_93_1517;
last_match_133_1002 = last_match_133_11860;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
 else {
bool_t test_11861;
{
bool_t test_11862;
{
bool_t test_11863;
{
long aux_11864;
aux_11864 = (long)(current_char_37_1493);
test_11863 = (aux_11864>=((long)48));
}
if(test_11863){
long aux_11867;
aux_11867 = (long)(current_char_37_1493);
test_11862 = (aux_11867<((long)58));
}
 else {
test_11862 = ((bool_t)0);
}
}
if(test_11862){
test_11861 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1493)){
case ((long)65) : 
test_11861 = ((bool_t)1);
break;
case ((long)70) : 
test_11861 = ((bool_t)1);
break;
case ((long)97) : 
test_11861 = ((bool_t)1);
break;
default: 
{
long aux_11870;
aux_11870 = (long)(current_char_37_1493);
test_11861 = (aux_11870==((long)102));
}
}
}
}
if(test_11861){
{
goto state_88_1090_127_2782;
}
}
 else {
bool_t test2130_1498;
{
long aux_11875;
aux_11875 = (long)(current_char_37_1493);
test2130_1498 = (aux_11875==((long)40));
}
if(test2130_1498){
{
long new_match_93_4619;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4619 = ((long)35);
aux_7016 = new_match_93_4619;
}
}
 else {
bool_t test_11880;
{
bool_t test_11881;
{
long aux_11882;
aux_11882 = (long)(current_char_37_1493);
test_11881 = (aux_11882<((long)33));
}
if(test_11881){
test_11880 = ((bool_t)1);
}
 else {
bool_t test_11885;
{
bool_t test_11886;
{
long aux_11887;
aux_11887 = (long)(current_char_37_1493);
test_11886 = (aux_11887==((long)35));
}
if(test_11886){
test_11885 = ((bool_t)1);
}
 else {
long aux_11890;
aux_11890 = (long)(current_char_37_1493);
test_11885 = (aux_11890==((long)34));
}
}
if(test_11885){
test_11880 = ((bool_t)1);
}
 else {
bool_t test_11893;
{
bool_t test_11894;
{
long aux_11895;
aux_11895 = (long)(current_char_37_1493);
test_11894 = (aux_11895==((long)41));
}
if(test_11894){
test_11893 = ((bool_t)1);
}
 else {
test_11893 = test2130_1498;
}
}
if(test_11893){
test_11880 = ((bool_t)1);
}
 else {
bool_t test_11898;
{
bool_t test_11899;
{
long aux_11900;
aux_11900 = (long)(current_char_37_1493);
test_11899 = (aux_11900>=((long)48));
}
if(test_11899){
long aux_11903;
aux_11903 = (long)(current_char_37_1493);
test_11898 = (aux_11903<((long)58));
}
 else {
test_11898 = ((bool_t)0);
}
}
if(test_11898){
test_11880 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1493)){
case ((long)59) : 
test_11880 = ((bool_t)1);
break;
case ((long)62) : 
test_11880 = ((bool_t)1);
break;
case ((long)65) : 
test_11880 = ((bool_t)1);
break;
case ((long)70) : 
test_11880 = ((bool_t)1);
break;
case ((long)91) : 
test_11880 = ((bool_t)1);
break;
case ((long)93) : 
test_11880 = ((bool_t)1);
break;
case ((long)97) : 
test_11880 = ((bool_t)1);
break;
case ((long)102) : 
test_11880 = ((bool_t)1);
break;
case ((long)123) : 
test_11880 = ((bool_t)1);
break;
case ((long)125) : 
test_11880 = ((bool_t)1);
break;
default: 
{
long aux_11906;
aux_11906 = (long)(current_char_37_1493);
test_11880 = (aux_11906==((long)127));
}
}
}
}
}
}
}
if(test_11880){
aux_7016 = last_match_133_1491;
}
 else {
{
long last_match_133_11911;
last_match_133_11911 = last_match_133_1491;
last_match_133_1002 = last_match_133_11911;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
}
}
 else {
bool_t test2885_2462;
{
long aux_11912;
aux_11912 = (long)(current_char_37_2458);
test2885_2462 = (aux_11912==((long)40));
}
if(test2885_2462){
{
long new_match_93_6406;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6406 = ((long)35);
aux_7016 = new_match_93_6406;
}
}
 else {
bool_t test_11917;
{
bool_t test_11918;
{
long aux_11919;
aux_11919 = (long)(current_char_37_2458);
test_11918 = (aux_11919<((long)33));
}
if(test_11918){
test_11917 = ((bool_t)1);
}
 else {
bool_t test_11922;
{
bool_t test_11923;
{
long aux_11924;
aux_11924 = (long)(current_char_37_2458);
test_11923 = (aux_11924==((long)35));
}
if(test_11923){
test_11922 = ((bool_t)1);
}
 else {
long aux_11927;
aux_11927 = (long)(current_char_37_2458);
test_11922 = (aux_11927==((long)34));
}
}
if(test_11922){
test_11917 = ((bool_t)1);
}
 else {
bool_t test_11930;
{
bool_t test_11931;
{
long aux_11932;
aux_11932 = (long)(current_char_37_2458);
test_11931 = (aux_11932==((long)41));
}
if(test_11931){
test_11930 = ((bool_t)1);
}
 else {
test_11930 = test2885_2462;
}
}
if(test_11930){
test_11917 = ((bool_t)1);
}
 else {
bool_t test_11935;
{
bool_t test_11936;
{
long aux_11937;
aux_11937 = (long)(current_char_37_2458);
test_11936 = (aux_11937>=((long)48));
}
if(test_11936){
long aux_11940;
aux_11940 = (long)(current_char_37_2458);
test_11935 = (aux_11940<((long)58));
}
 else {
test_11935 = ((bool_t)0);
}
}
if(test_11935){
test_11917 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2458)){
case ((long)59) : 
test_11917 = ((bool_t)1);
break;
case ((long)65) : 
test_11917 = ((bool_t)1);
break;
case ((long)70) : 
test_11917 = ((bool_t)1);
break;
case ((long)91) : 
test_11917 = ((bool_t)1);
break;
case ((long)93) : 
test_11917 = ((bool_t)1);
break;
case ((long)97) : 
test_11917 = ((bool_t)1);
break;
case ((long)102) : 
test_11917 = ((bool_t)1);
break;
case ((long)123) : 
test_11917 = ((bool_t)1);
break;
case ((long)125) : 
test_11917 = ((bool_t)1);
break;
default: 
{
long aux_11943;
aux_11943 = (long)(current_char_37_2458);
test_11917 = (aux_11943==((long)127));
}
}
}
}
}
}
}
if(test_11917){
aux_7016 = last_match_133_2456;
}
 else {
{
long last_match_133_11948;
last_match_133_11948 = last_match_133_2456;
last_match_133_1002 = last_match_133_11948;
goto state_39_1041_8_2804;
}
}
}
}
}
}
}
break;
case ((long)57) : 
case ((long)56) : 
case ((long)55) : 
case ((long)54) : 
case ((long)53) : 
case ((long)52) : 
case ((long)51) : 
case ((long)50) : 
case ((long)49) : 
case ((long)48) : 
last_match_133_1017 = new_match_93_1842;
state_41_1043_229_2803:
{
int current_char_37_1019;
current_char_37_1019 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_11950;
{
long aux_11951;
aux_11951 = (long)(current_char_37_1019);
test_11950 = (aux_11951==((long)0));
}
if(test_11950){
{
bool_t test1734_1021;
{
bool_t res3362_3697;
{
bool_t _andtest_1237_3694;
_andtest_1237_3694 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_3694){
res3362_3697 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3362_3697 = ((bool_t)0);
}
}
test1734_1021 = res3362_3697;
}
if(test1734_1021){
goto state_41_1043_229_2803;
}
 else {
aux_7016 = last_match_133_1017;
}
}
}
 else {
bool_t test1735_1022;
{
bool_t test_11958;
{
long aux_11959;
aux_11959 = (long)(current_char_37_1019);
test_11958 = (aux_11959>=((long)48));
}
if(test_11958){
long aux_11962;
aux_11962 = (long)(current_char_37_1019);
test1735_1022 = (aux_11962<((long)58));
}
 else {
test1735_1022 = ((bool_t)0);
}
}
if(test1735_1022){
{
goto state_41_1043_229_2803;
}
}
 else {
bool_t test_11966;
{
bool_t test_11967;
{
long aux_11968;
aux_11968 = (long)(current_char_37_1019);
test_11967 = (aux_11968<((long)33));
}
if(test_11967){
test_11966 = ((bool_t)1);
}
 else {
bool_t test_11971;
{
bool_t test_11972;
{
long aux_11973;
aux_11973 = (long)(current_char_37_1019);
test_11972 = (aux_11973==((long)35));
}
if(test_11972){
test_11971 = ((bool_t)1);
}
 else {
long aux_11976;
aux_11976 = (long)(current_char_37_1019);
test_11971 = (aux_11976==((long)34));
}
}
if(test_11971){
test_11966 = ((bool_t)1);
}
 else {
bool_t test_11979;
{
bool_t test_11980;
{
long aux_11981;
aux_11981 = (long)(current_char_37_1019);
test_11980 = (aux_11981==((long)41));
}
if(test_11980){
test_11979 = ((bool_t)1);
}
 else {
bool_t test_11984;
{
long aux_11985;
aux_11985 = (long)(current_char_37_1019);
test_11984 = (aux_11985==((long)40));
}
if(test_11984){
test_11979 = ((bool_t)1);
}
 else {
long aux_11988;
aux_11988 = (long)(current_char_37_1019);
test_11979 = (aux_11988==((long)39));
}
}
}
if(test_11979){
test_11966 = ((bool_t)1);
}
 else {
bool_t test_11991;
{
long aux_11992;
aux_11992 = (long)(current_char_37_1019);
test_11991 = (aux_11992==((long)44));
}
if(test_11991){
test_11966 = ((bool_t)1);
}
 else {
if(test1735_1022){
test_11966 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1019)){
case ((long)59) : 
test_11966 = ((bool_t)1);
break;
case ((long)91) : 
test_11966 = ((bool_t)1);
break;
case ((long)93) : 
test_11966 = ((bool_t)1);
break;
case ((long)96) : 
test_11966 = ((bool_t)1);
break;
case ((long)123) : 
test_11966 = ((bool_t)1);
break;
case ((long)125) : 
test_11966 = ((bool_t)1);
break;
default: 
{
long aux_11996;
aux_11996 = (long)(current_char_37_1019);
test_11966 = (aux_11996==((long)127));
}
}
}
}
}
}
}
}
if(test_11966){
aux_7016 = last_match_133_1017;
}
 else {
{
long last_match_133_12001;
last_match_133_12001 = last_match_133_1017;
last_match_133_1002 = last_match_133_12001;
goto state_39_1041_8_2804;
}
}
}
}
}
}
break;
case ((long)40) : 
{
long new_match_93_5265;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5265 = ((long)34);
aux_7016 = new_match_93_5265;
}
break;
case ((long)255) : 
case ((long)254) : 
case ((long)253) : 
case ((long)252) : 
case ((long)251) : 
case ((long)250) : 
case ((long)249) : 
case ((long)248) : 
case ((long)247) : 
case ((long)246) : 
case ((long)245) : 
case ((long)244) : 
case ((long)243) : 
case ((long)242) : 
case ((long)241) : 
case ((long)240) : 
case ((long)239) : 
case ((long)238) : 
case ((long)237) : 
case ((long)236) : 
case ((long)235) : 
case ((long)234) : 
case ((long)233) : 
case ((long)232) : 
case ((long)231) : 
case ((long)230) : 
case ((long)229) : 
case ((long)228) : 
case ((long)227) : 
case ((long)226) : 
case ((long)225) : 
case ((long)224) : 
case ((long)223) : 
case ((long)222) : 
case ((long)221) : 
case ((long)220) : 
case ((long)219) : 
case ((long)218) : 
case ((long)217) : 
case ((long)216) : 
case ((long)215) : 
case ((long)214) : 
case ((long)213) : 
case ((long)212) : 
case ((long)211) : 
case ((long)210) : 
case ((long)209) : 
case ((long)208) : 
case ((long)207) : 
case ((long)206) : 
case ((long)205) : 
case ((long)204) : 
case ((long)203) : 
case ((long)202) : 
case ((long)201) : 
case ((long)200) : 
case ((long)199) : 
case ((long)198) : 
case ((long)197) : 
case ((long)196) : 
case ((long)195) : 
case ((long)194) : 
case ((long)193) : 
case ((long)192) : 
case ((long)191) : 
case ((long)190) : 
case ((long)189) : 
case ((long)188) : 
case ((long)187) : 
case ((long)186) : 
case ((long)185) : 
case ((long)184) : 
case ((long)183) : 
case ((long)182) : 
case ((long)181) : 
case ((long)180) : 
case ((long)179) : 
case ((long)178) : 
case ((long)177) : 
case ((long)176) : 
case ((long)175) : 
case ((long)174) : 
case ((long)173) : 
case ((long)172) : 
case ((long)171) : 
case ((long)170) : 
case ((long)169) : 
case ((long)168) : 
case ((long)167) : 
case ((long)166) : 
case ((long)165) : 
case ((long)164) : 
case ((long)163) : 
case ((long)162) : 
case ((long)161) : 
case ((long)160) : 
case ((long)159) : 
case ((long)158) : 
case ((long)157) : 
case ((long)156) : 
case ((long)155) : 
case ((long)154) : 
case ((long)153) : 
case ((long)152) : 
case ((long)151) : 
case ((long)150) : 
case ((long)149) : 
case ((long)148) : 
case ((long)147) : 
case ((long)146) : 
case ((long)145) : 
case ((long)144) : 
case ((long)143) : 
case ((long)142) : 
case ((long)141) : 
case ((long)140) : 
case ((long)139) : 
case ((long)138) : 
case ((long)137) : 
case ((long)136) : 
case ((long)135) : 
case ((long)134) : 
case ((long)133) : 
case ((long)132) : 
case ((long)131) : 
case ((long)130) : 
case ((long)129) : 
case ((long)128) : 
case ((long)126) : 
case ((long)124) : 
case ((long)122) : 
case ((long)121) : 
case ((long)119) : 
case ((long)118) : 
case ((long)115) : 
case ((long)114) : 
case ((long)113) : 
case ((long)110) : 
case ((long)109) : 
case ((long)107) : 
case ((long)106) : 
case ((long)105) : 
case ((long)104) : 
case ((long)103) : 
case ((long)99) : 
case ((long)98) : 
case ((long)95) : 
case ((long)94) : 
case ((long)90) : 
case ((long)89) : 
case ((long)88) : 
case ((long)87) : 
case ((long)86) : 
case ((long)85) : 
case ((long)83) : 
case ((long)82) : 
case ((long)81) : 
case ((long)80) : 
case ((long)79) : 
case ((long)78) : 
case ((long)77) : 
case ((long)76) : 
case ((long)75) : 
case ((long)74) : 
case ((long)73) : 
case ((long)72) : 
case ((long)71) : 
case ((long)69) : 
case ((long)68) : 
case ((long)67) : 
case ((long)66) : 
case ((long)65) : 
case ((long)64) : 
case ((long)63) : 
case ((long)62) : 
case ((long)61) : 
case ((long)58) : 
case ((long)47) : 
case ((long)46) : 
case ((long)45) : 
case ((long)43) : 
case ((long)42) : 
case ((long)38) : 
case ((long)37) : 
case ((long)36) : 
{
long last_match_133_12003;
last_match_133_12003 = new_match_93_1842;
last_match_133_1002 = last_match_133_12003;
goto state_39_1041_8_2804;
}
break;
case ((long)34) : 
last_match_133_2449 = new_match_93_1842;
state_38_1040_54_2729:
{
int current_char_37_2451;
current_char_37_2451 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
switch ((long)(current_char_37_2451)){
case ((long)0) : 
{
bool_t test2880_2455;
{
bool_t res3420_6381;
{
bool_t _andtest_1237_6378;
_andtest_1237_6378 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6378){
res3420_6381 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3420_6381 = ((bool_t)0);
}
}
test2880_2455 = res3420_6381;
}
if(test2880_2455){
goto state_38_1040_54_2729;
}
 else {
aux_7016 = last_match_133_2449;
}
}
break;
case ((long)92) : 
last_match_133_1172 = last_match_133_2449;
state_91_1093_213_2794:
{
int current_char_37_1174;
current_char_37_1174 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12010;
{
long aux_12011;
aux_12011 = (long)(current_char_37_1174);
test_12010 = (aux_12011==((long)0));
}
if(test_12010){
{
bool_t test1851_1176;
test1851_1176 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(test1851_1176){
bool_t test1852_1177;
test1852_1177 = rgc_fill_buffer(input_port_219_6933);
if(test1852_1177){
goto state_91_1093_213_2794;
}
 else {
aux_7016 = last_match_133_1172;
}
}
 else {
long last_match_133_12018;
last_match_133_12018 = last_match_133_1172;
last_match_133_2449 = last_match_133_12018;
goto state_38_1040_54_2729;
}
}
}
 else {
bool_t test_12019;
{
long aux_12020;
aux_12020 = (long)(current_char_37_1174);
test_12019 = (aux_12020==((long)10));
}
if(test_12019){
aux_7016 = last_match_133_1172;
}
 else {
{
long last_match_133_12023;
last_match_133_12023 = last_match_133_1172;
last_match_133_2449 = last_match_133_12023;
goto state_38_1040_54_2729;
}
}
}
}
}
break;
case ((long)34) : 
{
long new_match_93_6383;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6383 = ((long)10);
aux_7016 = new_match_93_6383;
}
break;
default: 
{
goto state_38_1040_54_2729;
}
}
}
break;
case ((long)33) : 
last_match_133_1772 = new_match_93_1842;
state_37_1039_63_2769:
{
int current_char_37_1774;
current_char_37_1774 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12028;
{
long aux_12029;
aux_12029 = (long)(current_char_37_1774);
test_12028 = (aux_12029==((long)0));
}
if(test_12028){
{
bool_t test2353_1776;
{
bool_t res3393_5137;
{
bool_t _andtest_1237_5134;
_andtest_1237_5134 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5134){
res3393_5137 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3393_5137 = ((bool_t)0);
}
}
test2353_1776 = res3393_5137;
}
if(test2353_1776){
goto state_37_1039_63_2769;
}
 else {
aux_7016 = last_match_133_1772;
}
}
}
 else {
bool_t test2354_1777;
{
long aux_12036;
aux_12036 = (long)(current_char_37_1774);
test2354_1777 = (aux_12036==((long)40));
}
if(test2354_1777){
{
long new_match_93_5141;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5141 = ((long)35);
aux_7016 = new_match_93_5141;
}
}
 else {
bool_t test_12041;
{
bool_t test_12042;
{
long aux_12043;
aux_12043 = (long)(current_char_37_1774);
test_12042 = (aux_12043<((long)33));
}
if(test_12042){
test_12041 = ((bool_t)1);
}
 else {
bool_t test_12046;
{
bool_t test_12047;
{
long aux_12048;
aux_12048 = (long)(current_char_37_1774);
test_12047 = (aux_12048==((long)35));
}
if(test_12047){
test_12046 = ((bool_t)1);
}
 else {
long aux_12051;
aux_12051 = (long)(current_char_37_1774);
test_12046 = (aux_12051==((long)34));
}
}
if(test_12046){
test_12041 = ((bool_t)1);
}
 else {
bool_t test_12054;
{
bool_t test_12055;
{
long aux_12056;
aux_12056 = (long)(current_char_37_1774);
test_12055 = (aux_12056==((long)41));
}
if(test_12055){
test_12054 = ((bool_t)1);
}
 else {
test_12054 = test2354_1777;
}
}
if(test_12054){
test_12041 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1774)){
case ((long)59) : 
test_12041 = ((bool_t)1);
break;
case ((long)91) : 
test_12041 = ((bool_t)1);
break;
case ((long)93) : 
test_12041 = ((bool_t)1);
break;
case ((long)123) : 
test_12041 = ((bool_t)1);
break;
case ((long)125) : 
test_12041 = ((bool_t)1);
break;
default: 
{
long aux_12059;
aux_12059 = (long)(current_char_37_1774);
test_12041 = (aux_12059==((long)127));
}
}
}
}
}
}
if(test_12041){
aux_7016 = last_match_133_1772;
}
 else {
last_match_133_1660 = last_match_133_1772;
state_92_1094_228_2775:
{
long new_match_93_1662;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1662 = ((long)3);
{
int current_char_37_1663;
current_char_37_1663 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12066;
{
long aux_12067;
aux_12067 = (long)(current_char_37_1663);
test_12066 = (aux_12067==((long)0));
}
if(test_12066){
{
bool_t test2267_1665;
{
bool_t res3387_4937;
{
bool_t _andtest_1237_4934;
_andtest_1237_4934 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4934){
res3387_4937 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3387_4937 = ((bool_t)0);
}
}
test2267_1665 = res3387_4937;
}
if(test2267_1665){
goto state_92_1094_228_2775;
}
 else {
aux_7016 = new_match_93_1662;
}
}
}
 else {
bool_t test2268_1666;
{
long aux_12074;
aux_12074 = (long)(current_char_37_1663);
test2268_1666 = (aux_12074==((long)40));
}
if(test2268_1666){
{
long new_match_93_4941;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_4941 = ((long)35);
aux_7016 = new_match_93_4941;
}
}
 else {
bool_t test_12079;
{
bool_t test_12080;
{
long aux_12081;
aux_12081 = (long)(current_char_37_1663);
test_12080 = (aux_12081<((long)33));
}
if(test_12080){
test_12079 = ((bool_t)1);
}
 else {
bool_t test_12084;
{
bool_t test_12085;
{
long aux_12086;
aux_12086 = (long)(current_char_37_1663);
test_12085 = (aux_12086==((long)35));
}
if(test_12085){
test_12084 = ((bool_t)1);
}
 else {
long aux_12089;
aux_12089 = (long)(current_char_37_1663);
test_12084 = (aux_12089==((long)34));
}
}
if(test_12084){
test_12079 = ((bool_t)1);
}
 else {
bool_t test_12092;
{
bool_t test_12093;
{
long aux_12094;
aux_12094 = (long)(current_char_37_1663);
test_12093 = (aux_12094==((long)41));
}
if(test_12093){
test_12092 = ((bool_t)1);
}
 else {
test_12092 = test2268_1666;
}
}
if(test_12092){
test_12079 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_1663)){
case ((long)59) : 
test_12079 = ((bool_t)1);
break;
case ((long)91) : 
test_12079 = ((bool_t)1);
break;
case ((long)93) : 
test_12079 = ((bool_t)1);
break;
case ((long)123) : 
test_12079 = ((bool_t)1);
break;
case ((long)125) : 
test_12079 = ((bool_t)1);
break;
default: 
{
long aux_12097;
aux_12097 = (long)(current_char_37_1663);
test_12079 = (aux_12097==((long)127));
}
}
}
}
}
}
if(test_12079){
aux_7016 = new_match_93_1662;
}
 else {
{
long last_match_133_12102;
last_match_133_12102 = new_match_93_1662;
last_match_133_1660 = last_match_133_12102;
goto state_92_1094_228_2775;
}
}
}
}
}
}
}
}
}
}
}
}
break;
case ((long)0) : 
{
bool_t test2406_1847;
{
bool_t res3396_5271;
{
bool_t _andtest_1237_5268;
_andtest_1237_5268 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5268){
res3396_5271 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3396_5271 = ((bool_t)0);
}
}
test2406_1847 = res3396_5271;
}
if(test2406_1847){
goto state_6_1008_99_2765;
}
 else {
aux_7016 = new_match_93_1842;
}
}
break;
default: 
aux_7016 = new_match_93_1842;
}
}
}
break;
case ((long)34) : 
last_match_133_2236 = last_match_133_1870;
state_5_1007_102_2747:
{
long new_match_93_2238;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2238 = ((long)38);
{
int current_char_37_2239;
current_char_37_2239 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
switch ((long)(current_char_37_2239)){
case ((long)0) : 
{
bool_t test2733_2243;
{
bool_t res3410_6026;
{
bool_t _andtest_1237_6023;
_andtest_1237_6023 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6023){
res3410_6026 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3410_6026 = ((bool_t)0);
}
}
test2733_2243 = res3410_6026;
}
if(test2733_2243){
goto state_5_1007_102_2747;
}
 else {
aux_7016 = new_match_93_2238;
}
}
break;
case ((long)92) : 
last_match_133_1179 = new_match_93_2238;
state_95_1097_123_2793:
{
int current_char_37_1181;
current_char_37_1181 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12116;
{
long aux_12117;
aux_12117 = (long)(current_char_37_1181);
test_12116 = (aux_12117==((long)0));
}
if(test_12116){
{
bool_t test1856_1183;
test1856_1183 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(test1856_1183){
bool_t test1857_1184;
test1857_1184 = rgc_fill_buffer(input_port_219_6933);
if(test1857_1184){
goto state_95_1097_123_2793;
}
 else {
aux_7016 = last_match_133_1179;
}
}
 else {
last_match_133_2694 = last_match_133_1179;
state_93_1095_214_2713:
{
int current_char_37_2696;
current_char_37_2696 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
switch ((long)(current_char_37_2696)){
case ((long)0) : 
{
bool_t test3073_2700;
{
bool_t res3430_6837;
{
bool_t _andtest_1237_6834;
_andtest_1237_6834 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6834){
res3430_6837 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3430_6837 = ((bool_t)0);
}
}
test3073_2700 = res3430_6837;
}
if(test3073_2700){
goto state_93_1095_214_2713;
}
 else {
aux_7016 = last_match_133_2694;
}
}
break;
case ((long)92) : 
{
long last_match_133_12129;
last_match_133_12129 = last_match_133_2694;
last_match_133_1179 = last_match_133_12129;
goto state_95_1097_123_2793;
}
break;
case ((long)34) : 
{
long new_match_93_6839;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6839 = ((long)9);
aux_7016 = new_match_93_6839;
}
break;
default: 
{
goto state_93_1095_214_2713;
}
}
}
}
}
}
 else {
bool_t test_12133;
{
long aux_12134;
aux_12134 = (long)(current_char_37_1181);
test_12133 = (aux_12134==((long)10));
}
if(test_12133){
aux_7016 = last_match_133_1179;
}
 else {
{
long last_match_133_12137;
last_match_133_12137 = last_match_133_1179;
last_match_133_2694 = last_match_133_12137;
goto state_93_1095_214_2713;
}
}
}
}
}
break;
case ((long)34) : 
{
long new_match_93_6028;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_6028 = ((long)9);
aux_7016 = new_match_93_6028;
}
break;
default: 
{
long last_match_133_12139;
last_match_133_12139 = new_match_93_2238;
last_match_133_2694 = last_match_133_12139;
goto state_93_1095_214_2713;
}
}
}
}
break;
case ((long)255) : 
case ((long)254) : 
case ((long)253) : 
case ((long)252) : 
case ((long)251) : 
case ((long)250) : 
case ((long)249) : 
case ((long)248) : 
case ((long)247) : 
case ((long)246) : 
case ((long)245) : 
case ((long)244) : 
case ((long)243) : 
case ((long)242) : 
case ((long)241) : 
case ((long)240) : 
case ((long)239) : 
case ((long)238) : 
case ((long)237) : 
case ((long)236) : 
case ((long)235) : 
case ((long)234) : 
case ((long)233) : 
case ((long)232) : 
case ((long)231) : 
case ((long)230) : 
case ((long)229) : 
case ((long)228) : 
case ((long)227) : 
case ((long)226) : 
case ((long)225) : 
case ((long)224) : 
case ((long)223) : 
case ((long)222) : 
case ((long)221) : 
case ((long)220) : 
case ((long)219) : 
case ((long)218) : 
case ((long)217) : 
case ((long)216) : 
case ((long)215) : 
case ((long)214) : 
case ((long)213) : 
case ((long)212) : 
case ((long)211) : 
case ((long)210) : 
case ((long)209) : 
case ((long)208) : 
case ((long)207) : 
case ((long)206) : 
case ((long)205) : 
case ((long)204) : 
case ((long)203) : 
case ((long)202) : 
case ((long)201) : 
case ((long)200) : 
case ((long)199) : 
case ((long)198) : 
case ((long)197) : 
case ((long)196) : 
case ((long)195) : 
case ((long)194) : 
case ((long)193) : 
case ((long)192) : 
case ((long)191) : 
case ((long)190) : 
case ((long)189) : 
case ((long)188) : 
case ((long)187) : 
case ((long)186) : 
case ((long)185) : 
case ((long)184) : 
case ((long)183) : 
case ((long)182) : 
case ((long)181) : 
case ((long)180) : 
case ((long)179) : 
case ((long)178) : 
case ((long)177) : 
case ((long)176) : 
case ((long)175) : 
case ((long)174) : 
case ((long)173) : 
case ((long)172) : 
case ((long)171) : 
case ((long)170) : 
case ((long)169) : 
case ((long)168) : 
case ((long)167) : 
case ((long)166) : 
case ((long)165) : 
case ((long)164) : 
case ((long)163) : 
case ((long)162) : 
case ((long)161) : 
case ((long)160) : 
case ((long)159) : 
case ((long)158) : 
case ((long)157) : 
case ((long)156) : 
case ((long)155) : 
case ((long)154) : 
case ((long)153) : 
case ((long)152) : 
case ((long)151) : 
case ((long)150) : 
case ((long)149) : 
case ((long)148) : 
case ((long)147) : 
case ((long)146) : 
case ((long)145) : 
case ((long)144) : 
case ((long)143) : 
case ((long)142) : 
case ((long)141) : 
case ((long)140) : 
case ((long)139) : 
case ((long)138) : 
case ((long)137) : 
case ((long)136) : 
case ((long)135) : 
case ((long)134) : 
case ((long)133) : 
case ((long)132) : 
case ((long)131) : 
case ((long)130) : 
case ((long)129) : 
case ((long)128) : 
case ((long)126) : 
case ((long)124) : 
case ((long)122) : 
case ((long)121) : 
case ((long)120) : 
case ((long)119) : 
case ((long)118) : 
case ((long)117) : 
case ((long)116) : 
case ((long)115) : 
case ((long)114) : 
case ((long)113) : 
case ((long)112) : 
case ((long)111) : 
case ((long)110) : 
case ((long)109) : 
case ((long)108) : 
case ((long)107) : 
case ((long)106) : 
case ((long)105) : 
case ((long)104) : 
case ((long)103) : 
case ((long)102) : 
case ((long)101) : 
case ((long)100) : 
case ((long)99) : 
case ((long)98) : 
case ((long)97) : 
case ((long)95) : 
case ((long)94) : 
case ((long)92) : 
case ((long)90) : 
case ((long)89) : 
case ((long)88) : 
case ((long)87) : 
case ((long)86) : 
case ((long)85) : 
case ((long)84) : 
case ((long)83) : 
case ((long)82) : 
case ((long)81) : 
case ((long)80) : 
case ((long)79) : 
case ((long)78) : 
case ((long)77) : 
case ((long)76) : 
case ((long)75) : 
case ((long)74) : 
case ((long)73) : 
case ((long)72) : 
case ((long)71) : 
case ((long)70) : 
case ((long)69) : 
case ((long)68) : 
case ((long)67) : 
case ((long)66) : 
case ((long)65) : 
case ((long)64) : 
case ((long)63) : 
case ((long)62) : 
case ((long)61) : 
case ((long)60) : 
case ((long)47) : 
case ((long)42) : 
case ((long)38) : 
case ((long)37) : 
case ((long)36) : 
case ((long)33) : 
last_match_133_2218 = last_match_133_1870;
state_4_1006_132_2748:
{
long new_match_93_2220;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2220 = ((long)27);
{
int current_char_37_2221;
current_char_37_2221 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12144;
{
long aux_12145;
aux_12145 = (long)(current_char_37_2221);
test_12144 = (aux_12145==((long)0));
}
if(test_12144){
{
bool_t test2720_2223;
{
bool_t res3409_5997;
{
bool_t _andtest_1237_5994;
_andtest_1237_5994 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5994){
res3409_5997 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3409_5997 = ((bool_t)0);
}
}
test2720_2223 = res3409_5997;
}
if(test2720_2223){
goto state_4_1006_132_2748;
}
 else {
aux_7016 = new_match_93_2220;
}
}
}
 else {
bool_t test2721_2224;
{
long aux_12152;
aux_12152 = (long)(current_char_37_2221);
test2721_2224 = (aux_12152==((long)58));
}
if(test2721_2224){
{
long last_match_133_12156;
last_match_133_12156 = new_match_93_2220;
last_match_133_987 = last_match_133_12156;
goto state_29_1031_68_2805;
}
}
 else {
bool_t test_12157;
{
bool_t test_12158;
{
long aux_12159;
aux_12159 = (long)(current_char_37_2221);
test_12158 = (aux_12159<((long)33));
}
if(test_12158){
test_12157 = ((bool_t)1);
}
 else {
bool_t test_12162;
{
bool_t test_12163;
{
long aux_12164;
aux_12164 = (long)(current_char_37_2221);
test_12163 = (aux_12164==((long)35));
}
if(test_12163){
test_12162 = ((bool_t)1);
}
 else {
long aux_12167;
aux_12167 = (long)(current_char_37_2221);
test_12162 = (aux_12167==((long)34));
}
}
if(test_12162){
test_12157 = ((bool_t)1);
}
 else {
bool_t test_12170;
{
bool_t test_12171;
{
long aux_12172;
aux_12172 = (long)(current_char_37_2221);
test_12171 = (aux_12172==((long)41));
}
if(test_12171){
test_12170 = ((bool_t)1);
}
 else {
long aux_12175;
aux_12175 = (long)(current_char_37_2221);
test_12170 = (aux_12175==((long)40));
}
}
if(test_12170){
test_12157 = ((bool_t)1);
}
 else {
bool_t test_12178;
{
bool_t test_12179;
{
long aux_12180;
aux_12180 = (long)(current_char_37_2221);
test_12179 = (aux_12180==((long)59));
}
if(test_12179){
test_12178 = ((bool_t)1);
}
 else {
test_12178 = test2721_2224;
}
}
if(test_12178){
test_12157 = ((bool_t)1);
}
 else {
switch ((long)(current_char_37_2221)){
case ((long)91) : 
test_12157 = ((bool_t)1);
break;
case ((long)93) : 
test_12157 = ((bool_t)1);
break;
case ((long)123) : 
test_12157 = ((bool_t)1);
break;
case ((long)125) : 
test_12157 = ((bool_t)1);
break;
default: 
{
long aux_12183;
aux_12183 = (long)(current_char_37_2221);
test_12157 = (aux_12183==((long)127));
}
}
}
}
}
}
}
if(test_12157){
aux_7016 = new_match_93_2220;
}
 else {
{
long last_match_133_12188;
last_match_133_12188 = new_match_93_2220;
last_match_133_2373 = last_match_133_12188;
goto state_23_1025_82_2735;
}
}
}
}
}
}
}
break;
case ((long)10) : 
last_match_133_2211 = last_match_133_1870;
state_3_1005_168_2749:
{
long new_match_93_2213;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2213 = ((long)0);
{
int current_char_37_2214;
current_char_37_2214 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12191;
{
long aux_12192;
aux_12192 = (long)(current_char_37_2214);
test_12191 = (aux_12192==((long)0));
}
if(test_12191){
{
bool_t test2716_2216;
{
bool_t res3408_5986;
{
bool_t _andtest_1237_5983;
_andtest_1237_5983 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5983){
res3408_5986 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3408_5986 = ((bool_t)0);
}
}
test2716_2216 = res3408_5986;
}
if(test2716_2216){
goto state_3_1005_168_2749;
}
 else {
aux_7016 = new_match_93_2213;
}
}
}
 else {
bool_t test_12199;
{
long aux_12200;
aux_12200 = (long)(current_char_37_2214);
test_12199 = (aux_12200==((long)10));
}
if(test_12199){
last_match_133_2704 = new_match_93_2213;
state_96_1098_56_2711:
{
long new_match_93_2706;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_2706 = ((long)0);
{
int current_char_37_2707;
current_char_37_2707 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12205;
{
long aux_12206;
aux_12206 = (long)(current_char_37_2707);
test_12205 = (aux_12206==((long)0));
}
if(test_12205){
{
bool_t test3077_2709;
{
bool_t res3431_6851;
{
bool_t _andtest_1237_6848;
_andtest_1237_6848 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_6848){
res3431_6851 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3431_6851 = ((bool_t)0);
}
}
test3077_2709 = res3431_6851;
}
if(test3077_2709){
goto state_96_1098_56_2711;
}
 else {
aux_7016 = new_match_93_2706;
}
}
}
 else {
bool_t test_12213;
{
long aux_12214;
aux_12214 = (long)(current_char_37_2707);
test_12213 = (aux_12214==((long)10));
}
if(test_12213){
{
long last_match_133_12217;
last_match_133_12217 = new_match_93_2706;
last_match_133_2704 = last_match_133_12217;
goto state_96_1098_56_2711;
}
}
 else {
aux_7016 = new_match_93_2706;
}
}
}
}
}
}
 else {
aux_7016 = new_match_93_2213;
}
}
}
}
}
break;
case ((long)32) : 
case ((long)13) : 
case ((long)12) : 
case ((long)9) : 
last_match_133_1676 = last_match_133_1870;
state_2_1004_26_2774:
{
long new_match_93_1678;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1678 = ((long)1);
{
int current_char_37_1679;
current_char_37_1679 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12220;
{
long aux_12221;
aux_12221 = (long)(current_char_37_1679);
test_12220 = (aux_12221==((long)0));
}
if(test_12220){
{
bool_t test2278_1681;
{
bool_t res3388_4967;
{
bool_t _andtest_1237_4964;
_andtest_1237_4964 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_4964){
res3388_4967 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3388_4967 = ((bool_t)0);
}
}
test2278_1681 = res3388_4967;
}
if(test2278_1681){
goto state_2_1004_26_2774;
}
 else {
aux_7016 = new_match_93_1678;
}
}
}
 else {
bool_t test_12228;
{
bool_t test_12229;
{
long aux_12230;
aux_12230 = (long)(current_char_37_1679);
test_12229 = (aux_12230==((long)9));
}
if(test_12229){
test_12228 = ((bool_t)1);
}
 else {
bool_t test_12233;
{
bool_t test_12234;
{
long aux_12235;
aux_12235 = (long)(current_char_37_1679);
test_12234 = (aux_12235==((long)13));
}
if(test_12234){
test_12233 = ((bool_t)1);
}
 else {
long aux_12238;
aux_12238 = (long)(current_char_37_1679);
test_12233 = (aux_12238==((long)12));
}
}
if(test_12233){
test_12228 = ((bool_t)1);
}
 else {
long aux_12241;
aux_12241 = (long)(current_char_37_1679);
test_12228 = (aux_12241==((long)32));
}
}
}
if(test_12228){
last_match_133_1762 = new_match_93_1678;
state_97_1099_185_2770:
{
long new_match_93_1764;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_1764 = ((long)1);
{
int current_char_37_1765;
current_char_37_1765 = RGC_BUFFER_GET_CHAR(input_port_219_6933);
{
bool_t test_12246;
{
long aux_12247;
aux_12247 = (long)(current_char_37_1765);
test_12246 = (aux_12247==((long)0));
}
if(test_12246){
{
bool_t test2346_1767;
{
bool_t res3392_5121;
{
bool_t _andtest_1237_5118;
_andtest_1237_5118 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(_andtest_1237_5118){
res3392_5121 = rgc_fill_buffer(input_port_219_6933);
}
 else {
res3392_5121 = ((bool_t)0);
}
}
test2346_1767 = res3392_5121;
}
if(test2346_1767){
goto state_97_1099_185_2770;
}
 else {
aux_7016 = new_match_93_1764;
}
}
}
 else {
bool_t test_12254;
{
bool_t test_12255;
{
long aux_12256;
aux_12256 = (long)(current_char_37_1765);
test_12255 = (aux_12256==((long)9));
}
if(test_12255){
test_12254 = ((bool_t)1);
}
 else {
bool_t test_12259;
{
bool_t test_12260;
{
long aux_12261;
aux_12261 = (long)(current_char_37_1765);
test_12260 = (aux_12261==((long)13));
}
if(test_12260){
test_12259 = ((bool_t)1);
}
 else {
long aux_12264;
aux_12264 = (long)(current_char_37_1765);
test_12259 = (aux_12264==((long)12));
}
}
if(test_12259){
test_12254 = ((bool_t)1);
}
 else {
long aux_12267;
aux_12267 = (long)(current_char_37_1765);
test_12254 = (aux_12267==((long)32));
}
}
}
if(test_12254){
{
long last_match_133_12270;
last_match_133_12270 = new_match_93_1764;
last_match_133_1762 = last_match_133_12270;
goto state_97_1099_185_2770;
}
}
 else {
aux_7016 = new_match_93_1764;
}
}
}
}
}
}
 else {
aux_7016 = new_match_93_1678;
}
}
}
}
}
break;
case ((long)127) : 
case ((long)123) : 
case ((long)31) : 
case ((long)30) : 
case ((long)29) : 
case ((long)28) : 
case ((long)27) : 
case ((long)26) : 
case ((long)25) : 
case ((long)24) : 
case ((long)23) : 
case ((long)22) : 
case ((long)21) : 
case ((long)20) : 
case ((long)19) : 
case ((long)18) : 
case ((long)17) : 
case ((long)16) : 
case ((long)15) : 
case ((long)14) : 
case ((long)11) : 
case ((long)8) : 
case ((long)7) : 
case ((long)6) : 
case ((long)5) : 
case ((long)4) : 
case ((long)3) : 
case ((long)2) : 
case ((long)1) : 
{
long new_match_93_5328;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5328 = ((long)38);
aux_7016 = new_match_93_5328;
}
break;
case ((long)0) : 
{
bool_t test2426_1876;
test2426_1876 = RGC_BUFFER_EMPTY(input_port_219_6933);
if(test2426_1876){
bool_t test2427_1877;
test2427_1877 = rgc_fill_buffer(input_port_219_6933);
if(test2427_1877){
goto state_0_1002_0_2763;
}
 else {
aux_7016 = last_match_133_1870;
}
}
 else {
long new_match_93_5333;
RGC_STOP_MATCH(input_port_219_6933);
new_match_93_5333 = ((long)38);
aux_7016 = new_match_93_5333;
}
}
break;
default: 
aux_7016 = last_match_133_1870;
}
}
match_545 = (int)(aux_7016);
}
switch ((long)(match_545)){
case ((long)38) : 
{
obj_t char_549;
{
bool_t test1644_904;
{
int arg1647_907;
{
int res3352_3492;
{
long aux_12280;
aux_12280 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3352_3492 = (int)(aux_12280);
}
arg1647_907 = res3352_3492;
}
{
long aux_12283;
aux_12283 = (long)(arg1647_907);
test1644_904 = (aux_12283==((long)0));
}
}
if(test1644_904){
char_549 = BCNST(256);
}
 else {
obj_t arg1645_905;
{
obj_t res3354_3502;
{
int arg1665_3496;
{
int res3353_3498;
{
long aux_12287;
aux_12287 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3353_3498 = (int)(aux_12287);
}
arg1665_3496 = res3353_3498;
}
{
int aux_12290;
aux_12290 = (int)(((long)0));
res3354_3502 = rgc_buffer_substring(input_port_219_6933, aux_12290, arg1665_3496);
}
}
arg1645_905 = res3354_3502;
}
{
unsigned char aux_12293;
aux_12293 = STRING_REF(arg1645_905, ((long)0));
char_549 = BCHAR(aux_12293);
}
}
}
{
bool_t test1241_550;
test1241_550 = EOF_OBJECTP(char_549);
if(test1241_550){
bool_t test1242_551;
{
long n1_3034;
n1_3034 = _par_open__203___reader;
test1242_551 = (n1_3034>((long)0));
}
if(test1242_551){
{
long open_key_66_552;
{
long z1_3036;
z1_3036 = _par_open__203___reader;
open_key_66_552 = (z1_3036-((long)1));
}
reader_reset__72___reader();
{
bool_t test_12302;
{
bool_t test_12303;
{
long aux_12304;
aux_12304 = VECTOR_LENGTH(_list_errors__215___reader);
test_12303 = (open_key_66_552<aux_12304);
}
if(test_12303){
obj_t aux_12307;
aux_12307 = VECTOR_REF(_list_errors__215___reader, open_key_66_552);
test_12302 = INTEGERP(aux_12307);
}
 else {
test_12302 = ((bool_t)0);
}
}
if(test_12302){
char * arg1247_556;
obj_t arg1248_557;
arg1247_556 = INPUT_PORT_NAME(input_port_219_6933);
arg1248_557 = VECTOR_REF(_list_errors__215___reader, open_key_66_552);
return error_location_112___error(string3434___reader, string3437___reader, char_549, string_to_bstring(arg1247_556), arg1248_557);
}
 else {
FAILURE(string3434___reader,string3438___reader,string3437___reader);}
}
}
}
 else {
bool_t test1254_562;
{
long n1_3047;
n1_3047 = _bra_open__30___reader;
test1254_562 = (n1_3047>((long)0));
}
if(test1254_562){
{
long open_key_66_563;
{
long z1_3049;
z1_3049 = _bra_open__30___reader;
open_key_66_563 = (z1_3049-((long)1));
}
reader_reset__72___reader();
{
bool_t test_12319;
{
bool_t test_12320;
{
long aux_12321;
aux_12321 = VECTOR_LENGTH(_vector_errors__150___reader);
test_12320 = (open_key_66_563<aux_12321);
}
if(test_12320){
obj_t aux_12324;
aux_12324 = VECTOR_REF(_vector_errors__150___reader, open_key_66_563);
test_12319 = INTEGERP(aux_12324);
}
 else {
test_12319 = ((bool_t)0);
}
}
if(test_12319){
char * arg1258_567;
obj_t arg1259_568;
arg1258_567 = INPUT_PORT_NAME(input_port_219_6933);
arg1259_568 = VECTOR_REF(_vector_errors__150___reader, open_key_66_563);
return error_location_112___error(string3434___reader, string3439___reader, char_549, string_to_bstring(arg1258_567), arg1259_568);
}
 else {
FAILURE(string3434___reader,string3438___reader,string3439___reader);}
}
}
}
 else {
reset_eof(input_port_219_6933);
return char_549;
}
}
}
 else {
obj_t arg1269_576;
char * arg1270_577;
int arg1272_578;
arg1269_576 = illegal_char_rep_197___r4_output_6_10_3((unsigned char)CCHAR(char_549));
arg1270_577 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3278_3066;
{
long aux_12336;
aux_12336 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3278_3066 = (int)(aux_12336);
}
arg1272_578 = res3278_3066;
}
return error_location_112___error(string3434___reader, string3440___reader, arg1269_576, string_to_bstring(arg1270_577), BINT(arg1272_578));
}
}
}
break;
case ((long)37) : 
{
long z1_3067;
z1_3067 = _bra_open__30___reader;
_bra_open__30___reader = (z1_3067-((long)1));
}
{
bool_t test1275_581;
{
long n1_3069;
n1_3069 = _bra_open__30___reader;
test1275_581 = (n1_3069<((long)0));
}
if(test1275_581){
_bra_open__30___reader = ((long)0);
{
goto ignore___reader;
}
}
 else {
return BFALSE;
}
}
break;
case ((long)36) : 
{
long open_key_66_582;
open_key_66_582 = _bra_open__30___reader;
{
bool_t test_12345;
{
long aux_12346;
aux_12346 = VECTOR_LENGTH(_vector_errors__150___reader);
test_12345 = (open_key_66_582<aux_12346);
}
if(test_12345){
int pos_584;
{
int res3280_3077;
{
long aux_12349;
aux_12349 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3280_3077 = (int)(aux_12349);
}
pos_584 = res3280_3077;
}
{
obj_t aux_12352;
aux_12352 = BINT(pos_584);
VECTOR_SET(_vector_errors__150___reader, open_key_66_582, aux_12352);
}
}
 else {
BUNSPEC;
}
}
{
long z2_3079;
z2_3079 = _bra_open__30___reader;
_bra_open__30___reader = (((long)1)+z2_3079);
}
{
obj_t arg1282_588;
obj_t arg1283_589;
arg1282_588 = symbol3441___reader;
{
obj_t arg1284_592;
arg1284_592 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1283_589 = loop_struct_160___reader(open_key_66_582, the_rgc_context_46_6934, input_port_219_6933, arg1284_592);
}
return MAKE_PAIR(arg1282_588, arg1283_589);
}
}
break;
case ((long)35) : 
{
obj_t id_596;
long open_key_66_597;
{
obj_t str_610;
{
long arg1301_614;
{
int arg1302_615;
{
int res3281_3110;
{
long aux_12359;
aux_12359 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3281_3110 = (int)(aux_12359);
}
arg1302_615 = res3281_3110;
}
{
long aux_12362;
aux_12362 = (long)(arg1302_615);
arg1301_614 = (aux_12362-((long)1));
}
}
str_610 = the_substring_151___reader(input_port_219_6933, ((long)1), BINT(arg1301_614));
}
{
obj_t arg1298_611;
{
bool_t test1299_612;
{
obj_t obj1_3113;
obj1_3113 = bigloo_case_sensitive;
test1299_612 = (obj1_3113==BUNSPEC);
}
if(test1299_612){
arg1298_611 = string_upcase__158___r4_strings_6_7(str_610);
}
 else {
arg1298_611 = str_610;
}
}
{
char * aux_12370;
aux_12370 = BSTRING_TO_STRING(arg1298_611);
id_596 = string_to_symbol(aux_12370);
}
}
}
open_key_66_597 = _par_open__203___reader;
{
bool_t test_12373;
{
long aux_12374;
aux_12374 = VECTOR_LENGTH(_vector_errors__150___reader);
test_12373 = (open_key_66_597<aux_12374);
}
if(test_12373){
int pos_599;
{
int res3283_3122;
{
long aux_12377;
aux_12377 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3283_3122 = (int)(aux_12377);
}
pos_599 = res3283_3122;
}
{
obj_t aux_12380;
aux_12380 = BINT(pos_599);
VECTOR_SET(_vector_errors__150___reader, open_key_66_597, aux_12380);
}
}
 else {
BUNSPEC;
}
}
{
long z2_3124;
z2_3124 = _par_open__203___reader;
_par_open__203___reader = (((long)1)+z2_3124);
}
{
obj_t l_603;
{
obj_t arg1294_606;
arg1294_606 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
l_603 = loop_tvector_229___reader(open_key_66_597, the_rgc_context_46_6934, input_port_219_6933, arg1294_606);
}
return list__tvector_27___tvector(id_596, l_603);
}
}
break;
case ((long)34) : 
{
long open_key_66_617;
open_key_66_617 = _par_open__203___reader;
{
bool_t test_12387;
{
long aux_12388;
aux_12388 = VECTOR_LENGTH(_vector_errors__150___reader);
test_12387 = (open_key_66_617<aux_12388);
}
if(test_12387){
int pos_619;
{
int res3285_3158;
{
long aux_12391;
aux_12391 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3285_3158 = (int)(aux_12391);
}
pos_619 = res3285_3158;
}
{
obj_t aux_12394;
aux_12394 = BINT(pos_619);
VECTOR_SET(_vector_errors__150___reader, open_key_66_617, aux_12394);
}
}
 else {
BUNSPEC;
}
}
{
long z2_3160;
z2_3160 = _par_open__203___reader;
_par_open__203___reader = (((long)1)+z2_3160);
}
{
obj_t walk_623;
obj_t res_624;
long len_625;
{
obj_t arg1310_627;
arg1310_627 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
walk_623 = arg1310_627;
res_624 = BNIL;
len_625 = ((long)0);
loop_vector_232_626:
{
bool_t test1314_630;
{
long n2_3162;
n2_3162 = _par_open__203___reader;
test1314_630 = (open_key_66_617==n2_3162);
}
if(test1314_630){
{
obj_t vect_631;
vect_631 = create_vector(len_625);
{
long i_3166;
obj_t l_3167;
i_3166 = (len_625-((long)1));
l_3167 = res_624;
loop_vector_inner_219_3165:
if((i_3166==((long)-1))){
return vect_631;
}
 else {
{
obj_t aux_12404;
aux_12404 = CAR(l_3167);
VECTOR_SET(vect_631, i_3166, aux_12404);
}
{
obj_t l_12409;
long i_12407;
i_12407 = (i_3166-((long)1));
l_12409 = CDR(l_3167);
l_3167 = l_12409;
i_3166 = i_12407;
goto loop_vector_inner_219_3165;
}
}
}
}
}
 else {
{
obj_t arg1323_640;
obj_t arg1324_641;
long arg1325_642;
arg1323_640 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1324_641 = MAKE_PAIR(walk_623, res_624);
arg1325_642 = (((long)1)+len_625);
{
long len_12417;
obj_t res_12416;
obj_t walk_12415;
walk_12415 = arg1323_640;
res_12416 = arg1324_641;
len_12417 = arg1325_642;
len_625 = len_12417;
res_624 = res_12416;
walk_623 = walk_12415;
goto loop_vector_232_626;
}
}
}
}
}
}
}
break;
case ((long)33) : 
{
long z1_3217;
z1_3217 = _par_open__203___reader;
_par_open__203___reader = (z1_3217-((long)1));
}
{
bool_t test1326_643;
{
long n1_3219;
n1_3219 = _par_open__203___reader;
test1326_643 = (n1_3219<((long)0));
}
if(test1326_643){
_par_open__203___reader = ((long)0);
{
goto ignore___reader;
}
}
 else {
return BFALSE;
}
}
break;
case ((long)32) : 
{
long open_key_66_644;
int pos_645;
obj_t line_646;
open_key_66_644 = _par_open__203___reader;
{
int res3287_3223;
{
long aux_12421;
aux_12421 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3287_3223 = (int)(aux_12421);
}
pos_645 = res3287_3223;
}
line_646 = _line_number__80___reader;
{
bool_t test_12424;
{
long aux_12425;
aux_12425 = VECTOR_LENGTH(_list_errors__215___reader);
test_12424 = (open_key_66_644<aux_12425);
}
if(test_12424){
obj_t aux_12428;
aux_12428 = BINT(pos_645);
VECTOR_SET(_list_errors__215___reader, open_key_66_644, aux_12428);
}
 else {
BUNSPEC;
}
}
{
long z2_3229;
z2_3229 = _par_open__203___reader;
_par_open__203___reader = (((long)1)+z2_3229);
}
{
obj_t list3079_2822;
list3079_2822 = MAKE_PAIR(symbol3433___reader, BNIL);
CELL_SET(the_rgc_context_46_6934, CAR(list3079_2822));
}
{
obj_t arg1332_655;
arg1332_655 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
return loop_pair_11___reader(the_rgc_context_46_6934, input_port_219_6933, open_key_66_644, arg1332_655, pos_645, line_646);
}
}
break;
case ((long)31) : 
if(_position___179___reader){
obj_t arg1369_685;
obj_t arg1370_686;
obj_t arg1372_687;
arg1369_685 = symbol3442___reader;
{
obj_t arg1373_688;
arg1373_688 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1370_686 = MAKE_PAIR(arg1373_688, BNIL);
}
{
obj_t arg1378_690;
char * arg1379_691;
int arg1381_692;
arg1378_690 = symbol3436___reader;
arg1379_691 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3296_3276;
{
long aux_12440;
aux_12440 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3296_3276 = (int)(aux_12440);
}
arg1381_692 = res3296_3276;
}
{
obj_t list1382_693;
{
obj_t arg1383_694;
{
obj_t arg1384_695;
{
obj_t arg1385_696;
arg1385_696 = MAKE_PAIR(_line_number__80___reader, BNIL);
{
obj_t aux_12444;
aux_12444 = BINT(arg1381_692);
arg1384_695 = MAKE_PAIR(aux_12444, arg1385_696);
}
}
{
obj_t aux_12447;
aux_12447 = string_to_bstring(arg1379_691);
arg1383_694 = MAKE_PAIR(aux_12447, arg1384_695);
}
}
list1382_693 = MAKE_PAIR(arg1378_690, arg1383_694);
}
arg1372_687 = list1382_693;
}
}
return MAKE_EXTENDED_PAIR(arg1369_685, arg1370_686, arg1372_687);
}
 else {
obj_t arg1390_700;
obj_t arg1391_701;
arg1390_700 = symbol3442___reader;
{
obj_t arg1392_702;
arg1392_702 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1391_701 = MAKE_PAIR(arg1392_702, BNIL);
}
return MAKE_PAIR(arg1390_700, arg1391_701);
}
break;
case ((long)30) : 
if(_position___179___reader){
obj_t arg1395_704;
obj_t arg1396_705;
obj_t arg1397_706;
arg1395_704 = symbol3443___reader;
{
obj_t arg1398_707;
arg1398_707 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1396_705 = MAKE_PAIR(arg1398_707, BNIL);
}
{
obj_t arg1401_709;
char * arg1402_710;
int arg1403_711;
arg1401_709 = symbol3436___reader;
arg1402_710 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3299_3291;
{
long aux_12459;
aux_12459 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3299_3291 = (int)(aux_12459);
}
arg1403_711 = res3299_3291;
}
{
obj_t list1404_712;
{
obj_t arg1405_713;
{
obj_t arg1407_714;
{
obj_t arg1408_715;
arg1408_715 = MAKE_PAIR(_line_number__80___reader, BNIL);
{
obj_t aux_12463;
aux_12463 = BINT(arg1403_711);
arg1407_714 = MAKE_PAIR(aux_12463, arg1408_715);
}
}
{
obj_t aux_12466;
aux_12466 = string_to_bstring(arg1402_710);
arg1405_713 = MAKE_PAIR(aux_12466, arg1407_714);
}
}
list1404_712 = MAKE_PAIR(arg1401_709, arg1405_713);
}
arg1397_706 = list1404_712;
}
}
return MAKE_EXTENDED_PAIR(arg1395_704, arg1396_705, arg1397_706);
}
 else {
obj_t arg1414_719;
obj_t arg1415_720;
arg1414_719 = symbol3443___reader;
{
obj_t arg1416_721;
arg1416_721 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1415_720 = MAKE_PAIR(arg1416_721, BNIL);
}
return MAKE_PAIR(arg1414_719, arg1415_720);
}
break;
case ((long)29) : 
if(_position___179___reader){
obj_t arg1418_723;
obj_t arg1419_724;
obj_t arg1421_725;
arg1418_723 = symbol3444___reader;
{
obj_t arg1423_726;
arg1423_726 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1419_724 = MAKE_PAIR(arg1423_726, BNIL);
}
{
obj_t arg1427_728;
char * arg1428_729;
int arg1431_730;
arg1427_728 = symbol3436___reader;
arg1428_729 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3302_3306;
{
long aux_12478;
aux_12478 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3302_3306 = (int)(aux_12478);
}
arg1431_730 = res3302_3306;
}
{
obj_t list1432_731;
{
obj_t arg1433_732;
{
obj_t arg1436_733;
{
obj_t arg1437_734;
arg1437_734 = MAKE_PAIR(_line_number__80___reader, BNIL);
{
obj_t aux_12482;
aux_12482 = BINT(arg1431_730);
arg1436_733 = MAKE_PAIR(aux_12482, arg1437_734);
}
}
{
obj_t aux_12485;
aux_12485 = string_to_bstring(arg1428_729);
arg1433_732 = MAKE_PAIR(aux_12485, arg1436_733);
}
}
list1432_731 = MAKE_PAIR(arg1427_728, arg1433_732);
}
arg1421_725 = list1432_731;
}
}
return MAKE_EXTENDED_PAIR(arg1418_723, arg1419_724, arg1421_725);
}
 else {
obj_t arg1443_738;
obj_t arg1444_739;
arg1443_738 = symbol3444___reader;
{
obj_t arg1446_740;
arg1446_740 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1444_739 = MAKE_PAIR(arg1446_740, BNIL);
}
return MAKE_PAIR(arg1443_738, arg1444_739);
}
break;
case ((long)28) : 
if(_position___179___reader){
obj_t arg1449_742;
obj_t arg1450_743;
obj_t arg1453_744;
arg1449_742 = symbol3445___reader;
{
obj_t arg1454_745;
arg1454_745 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1450_743 = MAKE_PAIR(arg1454_745, BNIL);
}
{
obj_t arg1456_747;
char * arg1458_748;
int arg1460_749;
arg1456_747 = symbol3436___reader;
arg1458_748 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3305_3321;
{
long aux_12497;
aux_12497 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3305_3321 = (int)(aux_12497);
}
arg1460_749 = res3305_3321;
}
{
obj_t list1461_750;
{
obj_t arg1463_751;
{
obj_t arg1464_752;
{
obj_t arg1465_753;
arg1465_753 = MAKE_PAIR(_line_number__80___reader, BNIL);
{
obj_t aux_12501;
aux_12501 = BINT(arg1460_749);
arg1464_752 = MAKE_PAIR(aux_12501, arg1465_753);
}
}
{
obj_t aux_12504;
aux_12504 = string_to_bstring(arg1458_748);
arg1463_751 = MAKE_PAIR(aux_12504, arg1464_752);
}
}
list1461_750 = MAKE_PAIR(arg1456_747, arg1463_751);
}
arg1453_744 = list1461_750;
}
}
return MAKE_EXTENDED_PAIR(arg1449_742, arg1450_743, arg1453_744);
}
 else {
obj_t arg1469_757;
obj_t arg1470_758;
arg1469_757 = symbol3445___reader;
{
obj_t arg1471_759;
arg1471_759 = ignore___reader(the_rgc_context_46_6934, input_port_219_6933);
arg1470_758 = MAKE_PAIR(arg1471_759, BNIL);
}
return MAKE_PAIR(arg1469_757, arg1470_758);
}
break;
case ((long)27) : 
return rgc_buffer_symbol(input_port_219_6933);
break;
case ((long)26) : 
return rgc_buffer_keyword(input_port_219_6933);
break;
case ((long)25) : 
{
bool_t test1474_761;
{
int arg1488_774;
{
int res3306_3333;
{
long aux_12514;
aux_12514 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3306_3333 = (int)(aux_12514);
}
arg1488_774 = res3306_3333;
}
{
long aux_12517;
aux_12517 = (long)(arg1488_774);
test1474_761 = (aux_12517==((long)7));
}
}
if(test1474_761){
long arg1475_762;
{
obj_t arg1476_763;
arg1476_763 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(((long)6)));
{
obj_t list1478_765;
{
obj_t aux_12523;
aux_12523 = BINT(((long)16));
list1478_765 = MAKE_PAIR(aux_12523, BNIL);
}
arg1475_762 = string__integer_39___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1476_763), list1478_765);
}
}
return BCNST(arg1475_762);
}
 else {
obj_t arg1483_769;
char * arg1484_770;
int arg1485_771;
{
obj_t res3308_3343;
{
int arg1665_3337;
{
int res3307_3339;
{
long aux_12529;
aux_12529 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3307_3339 = (int)(aux_12529);
}
arg1665_3337 = res3307_3339;
}
{
int aux_12532;
aux_12532 = (int)(((long)0));
res3308_3343 = rgc_buffer_substring(input_port_219_6933, aux_12532, arg1665_3337);
}
}
arg1483_769 = res3308_3343;
}
arg1484_770 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3311_3348;
{
long aux_12536;
aux_12536 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3311_3348 = (int)(aux_12536);
}
arg1485_771 = res3311_3348;
}
return error_location_112___error(string3434___reader, string3446___reader, arg1483_769, string_to_bstring(arg1484_770), BINT(arg1485_771));
}
}
break;
case ((long)24) : 
return BFALSE;
break;
case ((long)23) : 
return BTRUE;
break;
case ((long)22) : 
{
obj_t symbol_776;
{
obj_t arg1503_788;
{
obj_t arg1504_789;
{
int arg1507_791;
{
int res3312_3350;
{
long aux_12542;
aux_12542 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3312_3350 = (int)(aux_12542);
}
arg1507_791 = res3312_3350;
}
arg1504_789 = the_substring_151___reader(input_port_219_6933, ((long)1), BINT(arg1507_791));
}
arg1503_788 = string_upcase__158___r4_strings_6_7(arg1504_789);
}
{
char * aux_12548;
aux_12548 = BSTRING_TO_STRING(arg1503_788);
symbol_776 = string_to_symbol(aux_12548);
}
}
if((symbol_776==symbol3447___reader)){
return BUNSPEC;
}
 else {
if((symbol_776==symbol3448___reader)){
return BEOF;
}
 else {
char * arg1497_782;
int arg1498_783;
arg1497_782 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3315_3360;
{
long aux_12556;
aux_12556 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3315_3360 = (int)(aux_12556);
}
arg1498_783 = res3315_3360;
}
return error_location_112___error(string3434___reader, string3449___reader, symbol_776, string_to_bstring(arg1497_782), BINT(arg1498_783));
}
}
}
break;
case ((long)21) : 
{
char * arg1513_794;
int arg1514_795;
arg1513_794 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3318_3365;
{
long aux_12563;
aux_12563 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3318_3365 = (int)(aux_12563);
}
arg1514_795 = res3318_3365;
}
return error_location_112___error(string3434___reader, string3450___reader, BCHAR(((unsigned char)'.')), string_to_bstring(arg1513_794), BINT(arg1514_795));
}
break;
case ((long)20) : 
return _dot_symbol__168___reader;
break;
case ((long)19) : 
{
obj_t arg1519_800;
char * arg1522_801;
int arg1524_802;
{
obj_t res3320_3373;
{
int arg1665_3367;
{
int res3319_3369;
{
long aux_12570;
aux_12570 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3319_3369 = (int)(aux_12570);
}
arg1665_3367 = res3319_3369;
}
{
int aux_12573;
aux_12573 = (int)(((long)0));
res3320_3373 = rgc_buffer_substring(input_port_219_6933, aux_12573, arg1665_3367);
}
}
arg1519_800 = res3320_3373;
}
arg1522_801 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3323_3378;
{
long aux_12577;
aux_12577 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3323_3378 = (int)(aux_12577);
}
arg1524_802 = res3323_3378;
}
return error_location_112___error(string3434___reader, string3435___reader, arg1519_800, string_to_bstring(arg1522_801), BINT(arg1524_802));
}
break;
case ((long)18) : 
{
obj_t res3324_3380;
{
double aux_12583;
aux_12583 = rgc_buffer_flonum(input_port_219_6933);
res3324_3380 = make_real(aux_12583);
}
return res3324_3380;
}
break;
case ((long)17) : 
{
obj_t arg1527_805;
{
int arg1532_810;
{
int res3325_3382;
{
long aux_12586;
aux_12586 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3325_3382 = (int)(aux_12586);
}
arg1532_810 = res3325_3382;
}
arg1527_805 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1532_810));
}
{
obj_t list1529_807;
{
obj_t aux_12591;
aux_12591 = BINT(((long)10));
list1529_807 = MAKE_PAIR(aux_12591, BNIL);
}
return string__llong_61___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1527_805), list1529_807);
}
}
break;
case ((long)16) : 
{
obj_t arg1533_811;
{
int arg1539_816;
{
int res3326_3384;
{
long aux_12596;
aux_12596 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3326_3384 = (int)(aux_12596);
}
arg1539_816 = res3326_3384;
}
arg1533_811 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1539_816));
}
{
obj_t list1535_813;
{
obj_t aux_12601;
aux_12601 = BINT(((long)10));
list1535_813 = MAKE_PAIR(aux_12601, BNIL);
}
return string__elong_120___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1533_811), list1535_813);
}
}
break;
case ((long)15) : 
{
obj_t arg1540_817;
{
int arg1549_822;
{
int res3327_3386;
{
long aux_12606;
aux_12606 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3327_3386 = (int)(aux_12606);
}
arg1549_822 = res3327_3386;
}
arg1540_817 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1549_822));
}
{
obj_t list1543_819;
{
obj_t aux_12611;
aux_12611 = BINT(((long)16));
list1543_819 = MAKE_PAIR(aux_12611, BNIL);
}
{
long aux_12614;
aux_12614 = string__integer_39___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1540_817), list1543_819);
return BINT(aux_12614);
}
}
}
break;
case ((long)14) : 
{
obj_t arg1550_823;
{
int arg1556_828;
{
int res3328_3388;
{
long aux_12618;
aux_12618 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3328_3388 = (int)(aux_12618);
}
arg1556_828 = res3328_3388;
}
arg1550_823 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1556_828));
}
{
obj_t list1553_825;
{
obj_t aux_12623;
aux_12623 = BINT(((long)10));
list1553_825 = MAKE_PAIR(aux_12623, BNIL);
}
{
long aux_12626;
aux_12626 = string__integer_39___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1550_823), list1553_825);
return BINT(aux_12626);
}
}
}
break;
case ((long)13) : 
{
obj_t arg1557_829;
{
int arg1562_834;
{
int res3329_3390;
{
long aux_12630;
aux_12630 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3329_3390 = (int)(aux_12630);
}
arg1562_834 = res3329_3390;
}
arg1557_829 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1562_834));
}
{
obj_t list1559_831;
{
obj_t aux_12635;
aux_12635 = BINT(((long)8));
list1559_831 = MAKE_PAIR(aux_12635, BNIL);
}
{
long aux_12638;
aux_12638 = string__integer_39___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1557_829), list1559_831);
return BINT(aux_12638);
}
}
}
break;
case ((long)12) : 
{
int res3330_3392;
{
long aux_12642;
aux_12642 = rgc_buffer_fixnum(input_port_219_6933);
res3330_3392 = (int)(aux_12642);
}
return BINT(res3330_3392);
}
break;
case ((long)11) : 
{
obj_t arg1563_835;
{
int arg1565_837;
{
int res3331_3394;
{
long aux_12646;
aux_12646 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3331_3394 = (int)(aux_12646);
}
arg1565_837 = res3331_3394;
}
arg1563_835 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1565_837));
}
return utf8_string_to_ucs2_string(arg1563_835);
}
break;
case ((long)10) : 
{
obj_t arg1566_838;
{
long arg1569_840;
{
int arg1570_841;
{
int res3332_3397;
{
long aux_12652;
aux_12652 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3332_3397 = (int)(aux_12652);
}
arg1570_841 = res3332_3397;
}
{
long aux_12655;
aux_12655 = (long)(arg1570_841);
arg1569_840 = (aux_12655-((long)1));
}
}
arg1566_838 = the_substring_151___reader(input_port_219_6933, ((long)1), BINT(arg1569_840));
}
{
char * aux_12660;
aux_12660 = BSTRING_TO_STRING(arg1566_838);
return escape_C_string(aux_12660);
}
}
break;
case ((long)9) : 
{
obj_t arg1573_843;
{
long arg1578_845;
{
int arg1580_846;
{
int res3333_3401;
{
long aux_12663;
aux_12663 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3333_3401 = (int)(aux_12663);
}
arg1580_846 = res3333_3401;
}
{
long aux_12666;
aux_12666 = (long)(arg1580_846);
arg1578_845 = (aux_12666-((long)1));
}
}
arg1573_843 = the_substring_151___reader(input_port_219_6933, ((long)1), BINT(arg1578_845));
}
{
char * aux_12671;
aux_12671 = BSTRING_TO_STRING(arg1573_843);
return escape_scheme_string(aux_12671);
}
}
break;
case ((long)8) : 
{
long arg1582_848;
{
obj_t arg1583_849;
arg1583_849 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(((long)6)));
{
obj_t list1585_851;
{
obj_t aux_12676;
aux_12676 = BINT(((long)16));
list1585_851 = MAKE_PAIR(aux_12676, BNIL);
}
arg1582_848 = string__integer_39___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1583_849), list1585_851);
}
}
{
ucs2_t aux_12681;
aux_12681 = integer__ucs2_47___ucs2(arg1582_848);
return BUCS2(aux_12681);
}
}
break;
case ((long)7) : 
{
obj_t address_853;
{
int arg1588_855;
{
int res3334_3405;
{
long aux_12684;
aux_12684 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3334_3405 = (int)(aux_12684);
}
arg1588_855 = res3334_3405;
}
address_853 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1588_855));
}
return (obj_t)(strtol(BSTRING_TO_STRING(address_853), 0, 16));
}
break;
case ((long)6) : 
{
obj_t char_name_197_856;
{
obj_t arg1609_873;
{
obj_t arg1610_874;
{
int arg1613_876;
{
int res3335_3407;
{
long aux_12690;
aux_12690 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3335_3407 = (int)(aux_12690);
}
arg1613_876 = res3335_3407;
}
arg1610_874 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(arg1613_876));
}
arg1609_873 = string_upcase__158___r4_strings_6_7(arg1610_874);
}
{
char * aux_12696;
aux_12696 = BSTRING_TO_STRING(arg1609_873);
char_name_197_856 = string_to_symbol(aux_12696);
}
}
if((char_name_197_856==symbol3451___reader)){
return BCHAR(((unsigned char)'\n'));
}
 else {
if((char_name_197_856==symbol3452___reader)){
return BCHAR(((unsigned char)'\t'));
}
 else {
if((char_name_197_856==symbol3453___reader)){
return BCHAR(((unsigned char)' '));
}
 else {
if((char_name_197_856==symbol3454___reader)){
unsigned char aux_12710;
aux_12710 = (((long)13));
return BCHAR(aux_12710);
}
 else {
obj_t arg1595_864;
char * arg1598_865;
int arg1600_866;
{
obj_t res3337_3425;
{
int arg1665_3419;
{
int res3336_3421;
{
long aux_12713;
aux_12713 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3336_3421 = (int)(aux_12713);
}
arg1665_3419 = res3336_3421;
}
{
int aux_12716;
aux_12716 = (int)(((long)0));
res3337_3425 = rgc_buffer_substring(input_port_219_6933, aux_12716, arg1665_3419);
}
}
arg1595_864 = res3337_3425;
}
arg1598_865 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3340_3430;
{
long aux_12720;
aux_12720 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3340_3430 = (int)(aux_12720);
}
arg1600_866 = res3340_3430;
}
return error_location_112___error(string3434___reader, string3455___reader, arg1595_864, string_to_bstring(arg1598_865), BINT(arg1600_866));
}
}
}
}
}
break;
case ((long)5) : 
{
obj_t arg1615_877;
{
obj_t res3342_3438;
{
int arg1665_3432;
{
int res3341_3434;
{
long aux_12726;
aux_12726 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3341_3434 = (int)(aux_12726);
}
arg1665_3432 = res3341_3434;
}
{
int aux_12729;
aux_12729 = (int)(((long)0));
res3342_3438 = rgc_buffer_substring(input_port_219_6933, aux_12729, arg1665_3432);
}
}
arg1615_877 = res3342_3438;
}
{
unsigned char aux_12732;
aux_12732 = STRING_REF(arg1615_877, ((long)2));
return BCHAR(aux_12732);
}
}
break;
case ((long)4) : 
{
obj_t string_879;
{
obj_t res3344_3448;
{
int arg1665_3442;
{
int res3343_3444;
{
long aux_12735;
aux_12735 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3343_3444 = (int)(aux_12735);
}
arg1665_3442 = res3343_3444;
}
{
int aux_12738;
aux_12738 = (int)(((long)0));
res3344_3448 = rgc_buffer_substring(input_port_219_6933, aux_12738, arg1665_3442);
}
}
string_879 = res3344_3448;
}
{
bool_t test1618_880;
{
int arg1632_890;
{
int res3345_3450;
{
long aux_12741;
aux_12741 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3345_3450 = (int)(aux_12741);
}
arg1632_890 = res3345_3450;
}
{
long aux_12744;
aux_12744 = (long)(arg1632_890);
test1618_880 = (aux_12744==((long)5));
}
}
if(test1618_880){
long arg1620_881;
{
obj_t arg1621_882;
arg1621_882 = the_substring_151___reader(input_port_219_6933, ((long)2), BINT(((long)5)));
arg1620_881 = string__integer_39___r4_numbers_6_5_fixnum(BSTRING_TO_STRING(arg1621_882), BNIL);
}
{
unsigned char aux_12752;
aux_12752 = (arg1620_881);
return BCHAR(aux_12752);
}
}
 else {
char * arg1625_886;
int arg1627_887;
arg1625_886 = INPUT_PORT_NAME(input_port_219_6933);
{
int res3348_3458;
{
long aux_12756;
aux_12756 = INPUT_PORT_FILEPOS(input_port_219_6933);
res3348_3458 = (int)(aux_12756);
}
arg1627_887 = res3348_3458;
}
return error_location_112___error(string3434___reader, string3456___reader, string_879, string_to_bstring(arg1625_886), BINT(arg1627_887));
}
}
}
break;
case ((long)3) : 
{
obj_t str_892;
{
obj_t res3350_3466;
{
int arg1665_3460;
{
int res3349_3462;
{
long aux_12762;
aux_12762 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3349_3462 = (int)(aux_12762);
}
arg1665_3460 = res3349_3462;
}
{
int aux_12765;
aux_12765 = (int)(((long)0));
res3350_3466 = rgc_buffer_substring(input_port_219_6933, aux_12765, arg1665_3460);
}
}
str_892 = res3350_3466;
}
{
{
bool_t test1634_893;
test1634_893 = bigloo_strcmp(str_892, string3457___reader);
if(test1634_893){
return BOPTIONAL;
}
 else {
bool_t test1635_894;
test1635_894 = bigloo_strcmp(str_892, string3458___reader);
if(test1635_894){
return BREST;
}
 else {
bool_t test1636_895;
test1636_895 = bigloo_strcmp(str_892, string3459___reader);
if(test1636_895){
return BKEY;
}
 else {
_bigloo_interpreter__95___reader = BTRUE;
{
goto ignore___reader;
}
}
}
}
}
}
}
break;
case ((long)2) : 
{
goto ignore___reader;
}
break;
case ((long)1) : 
{
goto ignore___reader;
}
break;
case ((long)0) : 
{
int arg1638_896;
{
int res3351_3474;
{
long aux_12774;
aux_12774 = RGC_BUFFER_LENGTH(input_port_219_6933);
res3351_3474 = (int)(aux_12774);
}
arg1638_896 = res3351_3474;
}
{
long z1_3475;
long z2_3476;
z1_3475 = (long)CINT(_line_number__80___reader);
z2_3476 = (long)(arg1638_896);
{
long aux_12779;
aux_12779 = (z1_3475+z2_3476);
_line_number__80___reader = BINT(aux_12779);
}
}
}
{
goto ignore___reader;
}
break;
default: 
FAILURE(string3460___reader,string3461___reader,BINT(match_545));}
}
}
}


/* the-substring */obj_t the_substring_151___reader(obj_t input_port_219_6935, long min_914, obj_t max_915)
{
{
bool_t test1655_917;
if((min_914>=((long)0))){
bool_t test1660_922;
{
int arg1661_923;
{
int res3355_3513;
{
long aux_12788;
aux_12788 = RGC_BUFFER_LENGTH(input_port_219_6935);
res3355_3513 = (int)(aux_12788);
}
arg1661_923 = res3355_3513;
}
{
long aux_12793;
long aux_12791;
aux_12793 = (long)(arg1661_923);
aux_12791 = (long)CINT(max_915);
test1660_922 = (aux_12791<=aux_12793);
}
}
if(test1660_922){
long aux_12797;
aux_12797 = (long)CINT(max_915);
test1655_917 = (aux_12797>=min_914);
}
 else {
test1655_917 = ((bool_t)0);
}
}
 else {
test1655_917 = ((bool_t)0);
}
if(test1655_917){
int aux_12803;
int aux_12801;
aux_12803 = CINT(max_915);
aux_12801 = (int)(min_914);
return rgc_buffer_substring(input_port_219_6935, aux_12801, aux_12803);
}
 else {
obj_t arg1658_920;
{
obj_t aux_12806;
aux_12806 = BINT(min_914);
arg1658_920 = MAKE_PAIR(aux_12806, max_915);
}
FAILURE(string3462___reader,string3463___reader,arg1658_920);}
}
}


/* reader-reset! */obj_t reader_reset__72___reader()
{
_line_number__80___reader = BINT(((long)1));
_par_open__203___reader = ((long)0);
return (_bra_open__30___reader = ((long)0),
BUNSPEC);
}


/* _reader-reset! */obj_t _reader_reset__157___reader(obj_t env_6916)
{
return reader_reset__72___reader();
}


/* read */obj_t read___reader(obj_t input_port_219_1)
{
_position___179___reader = ((bool_t)0);
if(NULLP(input_port_219_1)){
return PROCEDURE_ENTRY(_bigloo_grammar__71___reader)(_bigloo_grammar__71___reader, current_input_port, BEOA);
}
 else {
bool_t test_12816;
{
obj_t aux_12817;
aux_12817 = CAR(input_port_219_1);
test_12816 = INPUT_PORTP(aux_12817);
}
if(test_12816){
bool_t test_12820;
{
obj_t aux_12821;
aux_12821 = CDR(input_port_219_1);
test_12820 = NULLP(aux_12821);
}
if(test_12820){
return PROCEDURE_ENTRY(_bigloo_grammar__71___reader)(_bigloo_grammar__71___reader, CAR(input_port_219_1), BEOA);
}
 else {
_position___179___reader = ((bool_t)1);
{
bool_t test_12827;
{
obj_t aux_12828;
{
obj_t aux_12829;
aux_12829 = CDR(input_port_219_1);
aux_12828 = CAR(aux_12829);
}
test_12827 = INTEGERP(aux_12828);
}
if(test_12827){
obj_t aux_12833;
aux_12833 = CDR(input_port_219_1);
_line_number__80___reader = CAR(aux_12833);
}
 else {
BUNSPEC;
}
}
return PROCEDURE_ENTRY(_bigloo_grammar__71___reader)(_bigloo_grammar__71___reader, CAR(input_port_219_1), BEOA);
}
}
 else {
FAILURE(string3434___reader,string3464___reader,CAR(input_port_219_1));}
}
}


/* _read */obj_t _read___reader(obj_t env_6917, obj_t input_port_219_6918)
{
return read___reader(input_port_219_6918);
}


/* read/case */obj_t read_case_154___reader(obj_t case_2, obj_t input_port_219_3)
{
{
obj_t old_2843;
old_2843 = bigloo_case_sensitive;
bigloo_case_sensitive = case_2;
{
obj_t val1230_2844;
val1230_2844 = handling_function3103___reader(input_port_219_3);
bigloo_case_sensitive = old_2843;
{
bool_t test3100_2845;
{
obj_t aux_12843;
aux_12843 = val_from_exit__100___bexit(val1230_2844);
test3100_2845 = CBOOL(aux_12843);
}
if(test3100_2845){
return unwind_until__178___bexit(CAR(val1230_2844), CDR(val1230_2844));
}
 else {
return val1230_2844;
}
}
}
}
}


/* handling_function3103 */obj_t handling_function3103___reader(obj_t input_port_219_6923)
{
jmp_buf jmpbuf;
obj_t an_exit1231_2849;
if( SET_EXIT(an_exit1231_2849) ) {RESTORE_TRACE(); return _exit_value_;
} else {an_exit1231_2849 = (obj_t)jmpbuf;
{
PUSH_EXIT(an_exit1231_2849, ((bool_t)0));
{
obj_t val1232_2850;
val1232_2850 = read___reader(input_port_219_6923);
POP_EXIT();
return val1232_2850;
}
}
}
}


/* read-case-sensitive */obj_t read_case_sensitive_72___reader(obj_t input_port_219_4)
{
{
obj_t runner3106_6882;
runner3106_6882 = MAKE_PAIR(BTRUE, input_port_219_4);
{
obj_t aux3105_6883;
{
obj_t pair_6886;
pair_6886 = runner3106_6882;
aux3105_6883 = CAR(pair_6886);
}
{
obj_t pair_6887;
pair_6887 = runner3106_6882;
runner3106_6882 = CDR(pair_6887);
}
return read_case_154___reader(aux3105_6883, runner3106_6882);
}
}
}


/* _read-case-sensitive */obj_t _read_case_sensitive_11___reader(obj_t env_6919, obj_t input_port_219_6920)
{
return read_case_sensitive_72___reader(input_port_219_6920);
}


/* read-case-insensitive */obj_t read_case_insensitive_39___reader(obj_t input_port_219_5)
{
{
obj_t runner3108_6888;
runner3108_6888 = MAKE_PAIR(BFALSE, input_port_219_5);
{
obj_t aux3107_6889;
{
obj_t pair_6892;
pair_6892 = runner3108_6888;
aux3107_6889 = CAR(pair_6892);
}
{
obj_t pair_6893;
pair_6893 = runner3108_6888;
runner3108_6888 = CDR(pair_6893);
}
return read_case_154___reader(aux3107_6889, runner3108_6888);
}
}
}


/* _read-case-insensitive */obj_t _read_case_insensitive_175___reader(obj_t env_6921, obj_t input_port_219_6922)
{
return read_case_insensitive_39___reader(input_port_219_6922);
}


/* imported-modules-init */obj_t imported_modules_init_94___reader()
{
return module_initialization_70___error(((long)0), "__READER");
}

