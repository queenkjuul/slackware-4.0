/*===========================================================================*/
/*   (Lalr/rewrite.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

obj_t _symv__174___lalr_rewrite = BUNSPEC;
extern obj_t string_to_symbol(char *);
static obj_t set_sym_no__125___lalr_rewrite(obj_t);
static obj_t symbol1235___lalr_rewrite = BUNSPEC;
static obj_t symbol1234___lalr_rewrite = BUNSPEC;
static obj_t symbol1229___lalr_rewrite = BUNSPEC;
static obj_t symbol1230___lalr_rewrite = BUNSPEC;
static obj_t _max_term__209___lalr_rewrite = BUNSPEC;
static obj_t list1243___lalr_rewrite = BUNSPEC;
static obj_t list1233___lalr_rewrite = BUNSPEC;
static obj_t toplevel_init_63___lalr_rewrite();
extern obj_t nitems___lalr_global;
extern obj_t list__string_78___r4_strings_6_7(obj_t);
static obj_t make_sym_table_37___lalr_rewrite();
static obj_t _max_nt__109___lalr_rewrite = BUNSPEC;
extern obj_t remprop__243___r4_symbols_6_4(obj_t, obj_t);
static obj_t symbol__symbol_binding_162___lalr_rewrite(obj_t);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
extern obj_t reverse___r4_pairs_and_lists_6_3(obj_t);
static obj_t _clean_plist_92___lalr_rewrite(obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t nvars___lalr_global;
extern obj_t module_initialization_70___lalr_rewrite(long, char *);
extern obj_t module_initialization_70___lalr_global(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _plist__243___lalr_rewrite = BUNSPEC;
extern obj_t clean_plist_205___lalr_rewrite();
extern obj_t nsyms___lalr_global;
extern long list_length(obj_t);
static obj_t _rewrite_grammar__222___lalr_rewrite(obj_t, obj_t);
extern obj_t grammar___lalr_global;
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t nrules___lalr_global;
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t nterms___lalr_global;
extern bool_t list__240___r4_pairs_and_lists_6_3(obj_t);
static obj_t imported_modules_init_94___lalr_rewrite();
static obj_t require_initialization_114___lalr_rewrite = BUNSPEC;
extern obj_t string__list_125___r4_strings_6_7(obj_t);
extern obj_t rewrite_grammar__232___lalr_rewrite(obj_t);
static obj_t set_nt_no__177___lalr_rewrite(obj_t);
static obj_t cnst_init_137___lalr_rewrite();
extern obj_t make_vector(long, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( clean_plist_env_76___lalr_rewrite, _clean_plist_92___lalr_rewrite1248, _clean_plist_92___lalr_rewrite, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( rewrite_grammar__env_96___lalr_rewrite, _rewrite_grammar__222___lalr_rewrite1249, _rewrite_grammar__222___lalr_rewrite, 0L, 1 );
DEFINE_STRING( string1246___lalr_rewrite, string1246___lalr_rewrite1250, "Bad right-hand side", 19 );
DEFINE_STRING( string1245___lalr_rewrite, string1245___lalr_rewrite1251, "Invalid symbol in right-hand side", 33 );
DEFINE_STRING( string1244___lalr_rewrite, string1244___lalr_rewrite1252, "Undefined symbol", 16 );
DEFINE_STRING( string1242___lalr_rewrite, string1242___lalr_rewrite1253, "Invalid semantic action", 23 );
DEFINE_STRING( string1241___lalr_rewrite, string1241___lalr_rewrite1254, "Bad terminal definitions", 24 );
DEFINE_STRING( string1239___lalr_rewrite, string1239___lalr_rewrite1255, "Ill-formed grammar", 18 );
DEFINE_STRING( string1240___lalr_rewrite, string1240___lalr_rewrite1256, "Illegal terminal definition", 27 );
DEFINE_STRING( string1238___lalr_rewrite, string1238___lalr_rewrite1257, "Bad rule specification", 22 );
DEFINE_STRING( string1237___lalr_rewrite, string1237___lalr_rewrite1258, "LHS must be a symbol", 20 );
DEFINE_STRING( string1236___lalr_rewrite, string1236___lalr_rewrite1259, "Non-terminal defined twice", 26 );
DEFINE_STRING( string1232___lalr_rewrite, string1232___lalr_rewrite1260, "Grammar symbol already defined", 30 );
DEFINE_STRING( string1231___lalr_rewrite, string1231___lalr_rewrite1261, "lalr-grammar", 12 );


/* module-initialization */obj_t module_initialization_70___lalr_rewrite(long checksum_710, char * from_711)
{
if(CBOOL(require_initialization_114___lalr_rewrite)){
require_initialization_114___lalr_rewrite = BBOOL(((bool_t)0));
cnst_init_137___lalr_rewrite();
imported_modules_init_94___lalr_rewrite();
toplevel_init_63___lalr_rewrite();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___lalr_rewrite()
{
symbol1229___lalr_rewrite = string_to_symbol("NT?");
symbol1230___lalr_rewrite = string_to_symbol("SYM-NO");
symbol1234___lalr_rewrite = string_to_symbol("*EOI*");
symbol1235___lalr_rewrite = string_to_symbol("*START*");
{
obj_t aux_722;
aux_722 = MAKE_PAIR(symbol1235___lalr_rewrite, BNIL);
list1233___lalr_rewrite = MAKE_PAIR(symbol1234___lalr_rewrite, aux_722);
}
{
obj_t aux_725;
aux_725 = BBOOL(((bool_t)0));
return (list1243___lalr_rewrite = MAKE_PAIR(aux_725, BNIL),
BUNSPEC);
}
}


/* toplevel-init */obj_t toplevel_init_63___lalr_rewrite()
{
_plist__243___lalr_rewrite = BFALSE;
_symv__174___lalr_rewrite = BFALSE;
_max_term__209___lalr_rewrite = BINT(((long)0));
return (_max_nt__109___lalr_rewrite = BINT(((long)1)),
BUNSPEC);
}


/* clean-plist */obj_t clean_plist_205___lalr_rewrite()
{
{
obj_t l_321;
{
bool_t aux_730;
l_321 = _plist__243___lalr_rewrite;
loop_322:
if(PAIRP(l_321)){
obj_t sym_324;
sym_324 = CAR(l_321);
{
bool_t test_734;
{
obj_t aux_735;
aux_735 = getprop___r4_symbols_6_4(sym_324, symbol1229___lalr_rewrite);
test_734 = CBOOL(aux_735);
}
if(test_734){
remprop__243___r4_symbols_6_4(sym_324, symbol1229___lalr_rewrite);
}
 else {
BUNSPEC;
}
}
remprop__243___r4_symbols_6_4(sym_324, symbol1230___lalr_rewrite);
{
obj_t l_740;
l_740 = CDR(l_321);
l_321 = l_740;
goto loop_322;
}
}
 else {
aux_730 = ((bool_t)0);
}
return BBOOL(aux_730);
}
}
}


/* _clean-plist */obj_t _clean_plist_92___lalr_rewrite(obj_t env_707)
{
return clean_plist_205___lalr_rewrite();
}


/* make-sym-table */obj_t make_sym_table_37___lalr_rewrite()
{
{
long aux_744;
aux_744 = (long)CINT(_max_term__209___lalr_rewrite);
_symv__174___lalr_rewrite = make_vector(aux_744, BFALSE);
}
{
obj_t l_330;
l_330 = _plist__243___lalr_rewrite;
loop_331:
if(PAIRP(l_330)){
obj_t sym_333;
sym_333 = CAR(l_330);
{
obj_t vector_590;
vector_590 = _symv__174___lalr_rewrite;
{
long aux_750;
{
obj_t aux_751;
aux_751 = getprop___r4_symbols_6_4(sym_333, symbol1230___lalr_rewrite);
aux_750 = (long)CINT(aux_751);
}
VECTOR_SET(vector_590, aux_750, sym_333);
}
}
{
obj_t l_755;
l_755 = CDR(l_330);
l_330 = l_755;
goto loop_331;
}
}
 else {
return BUNSPEC;
}
}
}


/* set-nt-no! */obj_t set_nt_no__177___lalr_rewrite(obj_t sym_1)
{
{
obj_t x_337;
x_337 = _max_nt__109___lalr_rewrite;
putprop__88___r4_symbols_6_4(sym_1, symbol1229___lalr_rewrite, BTRUE);
putprop__88___r4_symbols_6_4(sym_1, symbol1230___lalr_rewrite, _max_nt__109___lalr_rewrite);
_max_nt__109___lalr_rewrite = _2__168___r4_numbers_6_5(_max_nt__109___lalr_rewrite, BINT(((long)1)));
{
obj_t obj2_595;
obj2_595 = _plist__243___lalr_rewrite;
_plist__243___lalr_rewrite = MAKE_PAIR(sym_1, obj2_595);
}
return x_337;
}
}


/* set-sym-no! */obj_t set_sym_no__125___lalr_rewrite(obj_t sym_2)
{
{
bool_t test_762;
{
obj_t aux_763;
aux_763 = getprop___r4_symbols_6_4(sym_2, symbol1230___lalr_rewrite);
test_762 = CBOOL(aux_763);
}
if(test_762){
FAILURE(string1231___lalr_rewrite,string1232___lalr_rewrite,sym_2);}
 else {
obj_t y_341;
y_341 = _max_term__209___lalr_rewrite;
putprop__88___r4_symbols_6_4(sym_2, symbol1230___lalr_rewrite, _max_term__209___lalr_rewrite);
{
obj_t obj2_600;
obj2_600 = _plist__243___lalr_rewrite;
_plist__243___lalr_rewrite = MAKE_PAIR(sym_2, obj2_600);
}
_max_term__209___lalr_rewrite = _2__168___r4_numbers_6_5(_max_term__209___lalr_rewrite, BINT(((long)1)));
return y_341;
}
}
}


/* symbol->symbol/binding */obj_t symbol__symbol_binding_162___lalr_rewrite(obj_t sym_4)
{
{
obj_t l_346;
obj_t prefix_347;
{
obj_t arg1022_349;
{
obj_t arg1025_351;
arg1025_351 = SYMBOL_TO_STRING(sym_4);
arg1022_349 = string__list_125___r4_strings_6_7(arg1025_351);
}
l_346 = arg1022_349;
prefix_347 = BNIL;
loop_348:
if(NULLP(l_346)){
return sym_4;
}
 else {
obj_t c_353;
obj_t r_354;
c_353 = CAR(l_346);
r_354 = CDR(l_346);
{
bool_t test_777;
{
unsigned char aux_778;
aux_778 = (unsigned char)CCHAR(c_353);
test_777 = (aux_778==((unsigned char)'@'));
}
if(test_777){
if(NULLP(r_354)){
return sym_4;
}
 else {
obj_t arg1029_357;
obj_t arg1030_358;
{
obj_t arg1031_359;
arg1031_359 = list__string_78___r4_strings_6_7(reverse___r4_pairs_and_lists_6_3(prefix_347));
{
char * aux_785;
aux_785 = BSTRING_TO_STRING(arg1031_359);
arg1029_357 = string_to_symbol(aux_785);
}
}
{
obj_t arg1033_361;
arg1033_361 = list__string_78___r4_strings_6_7(r_354);
{
char * aux_789;
aux_789 = BSTRING_TO_STRING(arg1033_361);
arg1030_358 = string_to_symbol(aux_789);
}
}
return MAKE_PAIR(arg1029_357, arg1030_358);
}
}
 else {
obj_t arg1034_362;
arg1034_362 = MAKE_PAIR(c_353, prefix_347);
{
obj_t prefix_795;
obj_t l_794;
l_794 = r_354;
prefix_795 = arg1034_362;
prefix_347 = prefix_795;
l_346 = l_794;
goto loop_348;
}
}
}
}
}
}
}


/* rewrite-grammar! */obj_t rewrite_grammar__232___lalr_rewrite(obj_t gram_5)
{
{
obj_t no_rules_183_363;
obj_t no_items_206_364;
obj_t terminals_365;
obj_t the_rules_255_366;
no_rules_183_363 = BUNSPEC;
no_items_206_364 = BUNSPEC;
terminals_365 = BUNSPEC;
the_rules_255_366 = BUNSPEC;
the_rules_255_366 = CDR(gram_5);
terminals_365 = CAR(gram_5);
no_items_206_364 = BINT(((long)0));
no_rules_183_363 = BINT(((long)0));
_plist__243___lalr_rewrite = list1233___lalr_rewrite;
_max_nt__109___lalr_rewrite = BINT(((long)1));
{
obj_t l_367;
l_367 = the_rules_255_366;
loop_368:
if(PAIRP(l_367)){
obj_t prods_370;
prods_370 = CAR(l_367);
if(PAIRP(prods_370)){
obj_t lhs_372;
lhs_372 = CAR(prods_370);
if(SYMBOLP(lhs_372)){
bool_t test_809;
{
obj_t aux_810;
aux_810 = getprop___r4_symbols_6_4(lhs_372, symbol1229___lalr_rewrite);
test_809 = CBOOL(aux_810);
}
if(test_809){
FAILURE(string1231___lalr_rewrite,string1236___lalr_rewrite,lhs_372);}
 else {
set_nt_no__177___lalr_rewrite(lhs_372);
{
obj_t l_815;
l_815 = CDR(l_367);
l_367 = l_815;
goto loop_368;
}
}
}
 else {
FAILURE(string1231___lalr_rewrite,string1237___lalr_rewrite,lhs_372);}
}
 else {
FAILURE(string1231___lalr_rewrite,string1238___lalr_rewrite,prods_370);}
}
 else {
if(NULLP(l_367)){
BUNSPEC;
}
 else {
FAILURE(string1231___lalr_rewrite,string1239___lalr_rewrite,l_367);}
}
}
_max_term__209___lalr_rewrite = _2__168___r4_numbers_6_5(_max_nt__109___lalr_rewrite, BINT(((long)1)));
putprop__88___r4_symbols_6_4(symbol1234___lalr_rewrite, symbol1230___lalr_rewrite, _max_nt__109___lalr_rewrite);
putprop__88___r4_symbols_6_4(symbol1235___lalr_rewrite, symbol1230___lalr_rewrite, BINT(((long)0)));
putprop__88___r4_symbols_6_4(symbol1235___lalr_rewrite, symbol1229___lalr_rewrite, BTRUE);
{
obj_t l_385;
l_385 = terminals_365;
loop_386:
if(PAIRP(l_385)){
{
obj_t term_388;
term_388 = CAR(l_385);
if(SYMBOLP(term_388)){
set_sym_no__125___lalr_rewrite(term_388);
}
 else {
FAILURE(string1231___lalr_rewrite,string1240___lalr_rewrite,term_388);}
{
obj_t l_835;
l_835 = CDR(l_385);
l_385 = l_835;
goto loop_386;
}
}
}
 else {
if(NULLP(l_385)){
BFALSE;
}
 else {
FAILURE(string1231___lalr_rewrite,string1241___lalr_rewrite,l_385);}
}
}
{
obj_t l_392;
l_392 = the_rules_255_366;
loop_393:
if(PAIRP(l_392)){
{
obj_t rhs_l_235_397;
{
obj_t aux_894;
aux_894 = CAR(l_392);
rhs_l_235_397 = CDR(aux_894);
}
loop_1_90_398:
if(NULLP(rhs_l_235_397)){
{
obj_t l_844;
l_844 = CDR(l_392);
l_392 = l_844;
goto loop_393;
}
}
 else {
if(PAIRP(rhs_l_235_397)){
{
obj_t rhs_action_56_403;
rhs_action_56_403 = CAR(rhs_l_235_397);
no_rules_183_363 = _2__168___r4_numbers_6_5(no_rules_183_363, BINT(((long)1)));
if(PAIRP(rhs_action_56_403)){
obj_t action_405;
action_405 = CDR(rhs_action_56_403);
if(list__240___r4_pairs_and_lists_6_3(action_405)){
BUNSPEC;
}
 else {
FAILURE(string1231___lalr_rewrite,string1242___lalr_rewrite,rhs_action_56_403);}
if(NULLP(action_405)){
SET_CDR(rhs_action_56_403, list1243___lalr_rewrite);
}
 else {
BUNSPEC;
}
{
obj_t rhs_409;
rhs_409 = CAR(rhs_action_56_403);
loop_2_217_410:
if(NULLP(rhs_409)){
{
obj_t aux_862;
{
obj_t aux_863;
{
long aux_864;
aux_864 = list_length(CAR(rhs_action_56_403));
aux_863 = BINT(aux_864);
}
aux_862 = _2__168___r4_numbers_6_5(aux_863, BINT(((long)1)));
}
no_items_206_364 = _2__168___r4_numbers_6_5(no_items_206_364, aux_862);
}
{
obj_t rhs_l_235_871;
rhs_l_235_871 = CDR(rhs_l_235_397);
rhs_l_235_397 = rhs_l_235_871;
goto loop_1_90_398;
}
}
 else {
if(PAIRP(rhs_409)){
{
obj_t sym_419;
sym_419 = CAR(rhs_409);
if(SYMBOLP(sym_419)){
obj_t sym_var_250_421;
sym_var_250_421 = symbol__symbol_binding_162___lalr_rewrite(sym_419);
{
obj_t the_sym_92_422;
if(SYMBOLP(sym_var_250_421)){
the_sym_92_422 = sym_var_250_421;
}
 else {
the_sym_92_422 = CAR(sym_var_250_421);
}
{
SET_CAR(rhs_409, sym_var_250_421);
{
bool_t test_883;
{
obj_t aux_884;
aux_884 = getprop___r4_symbols_6_4(the_sym_92_422, symbol1230___lalr_rewrite);
test_883 = CBOOL(aux_884);
}
if(test_883){
BUNSPEC;
}
 else {
FAILURE(string1231___lalr_rewrite,string1244___lalr_rewrite,the_sym_92_422);}
}
{
obj_t rhs_888;
rhs_888 = CDR(rhs_409);
rhs_409 = rhs_888;
goto loop_2_217_410;
}
}
}
}
 else {
FAILURE(string1231___lalr_rewrite,string1245___lalr_rewrite,rhs_409);}
}
}
 else {
FAILURE(string1231___lalr_rewrite,string1246___lalr_rewrite,rhs_409);}
}
}
}
 else {
BUNSPEC;
}
}
}
 else {
FAILURE(string1231___lalr_rewrite,string1238___lalr_rewrite,l_392);}
}
}
}
 else {
BUNSPEC;
}
}
make_sym_table_37___lalr_rewrite();
{
obj_t start_sym_203_425;
{
obj_t pair_694;
pair_694 = the_rules_255_366;
{
obj_t aux_898;
aux_898 = CAR(pair_694);
start_sym_203_425 = CAR(aux_898);
}
}
{
obj_t arg1076_426;
{
obj_t arg1077_427;
obj_t arg1078_428;
arg1077_427 = symbol1235___lalr_rewrite;
{
obj_t arg1083_433;
{
obj_t arg1088_438;
arg1088_438 = symbol1234___lalr_rewrite;
{
obj_t list1090_440;
{
obj_t arg1091_441;
arg1091_441 = MAKE_PAIR(BNIL, BNIL);
list1090_440 = MAKE_PAIR(arg1088_438, arg1091_441);
}
arg1083_433 = cons__138___r4_pairs_and_lists_6_3(start_sym_203_425, list1090_440);
}
}
{
obj_t list1085_435;
{
obj_t arg1086_436;
arg1086_436 = MAKE_PAIR(BNIL, BNIL);
list1085_435 = MAKE_PAIR(start_sym_203_425, arg1086_436);
}
arg1078_428 = cons__138___r4_pairs_and_lists_6_3(arg1083_433, list1085_435);
}
}
{
obj_t list1080_430;
{
obj_t arg1081_431;
arg1081_431 = MAKE_PAIR(BNIL, BNIL);
list1080_430 = MAKE_PAIR(arg1078_428, arg1081_431);
}
arg1076_426 = cons__138___r4_pairs_and_lists_6_3(arg1077_427, list1080_430);
}
}
{
obj_t obj2_699;
obj2_699 = the_rules_255_366;
grammar___lalr_global = MAKE_PAIR(arg1076_426, obj2_699);
}
}
}
nrules___lalr_global = _2__168___r4_numbers_6_5(no_rules_183_363, BINT(((long)2)));
nitems___lalr_global = _2__168___r4_numbers_6_5(no_items_206_364, BINT(((long)3)));
nterms___lalr_global = _max_term__209___lalr_rewrite;
nvars___lalr_global = _max_nt__109___lalr_rewrite;
return (nsyms___lalr_global = _2__168___r4_numbers_6_5(nterms___lalr_global, nvars___lalr_global),
BUNSPEC);
}
}


/* _rewrite-grammar! */obj_t _rewrite_grammar__222___lalr_rewrite(obj_t env_708, obj_t gram_709)
{
return rewrite_grammar__232___lalr_rewrite(gram_709);
}


/* imported-modules-init */obj_t imported_modules_init_94___lalr_rewrite()
{
module_initialization_70___error(((long)0), "__LALR_REWRITE");
return module_initialization_70___lalr_global(((long)0), "__LALR_REWRITE");
}

