/*===========================================================================*/
/*   (Expand/let.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t args___args_list_50_tools_args(obj_t);
extern obj_t module_initialization_70_expand_let(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_expand_lambda(long, char *);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t internal_begin_expander_196_expand_lambda(obj_t);
extern obj_t expand_labels_128_expand_let(obj_t, obj_t);
static obj_t tag_381_231_expand_let(obj_t);
static obj_t tag_380_71_expand_let(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_expand_let();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t expand_let__212_expand_let(obj_t, obj_t);
extern obj_t expand_letrec_249_expand_let(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_let();
static obj_t _expand_let_1468_26_expand_let(obj_t, obj_t, obj_t);
extern obj_t expand_let_145_expand_let(obj_t, obj_t);
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _expand_let1469_33_expand_let(obj_t, obj_t, obj_t);
extern obj_t with_lexical_22_expand_eps(obj_t, obj_t, obj_t);
static obj_t loop_expand_let(obj_t, obj_t, obj_t);
static obj_t _expand_labels1471_75_expand_let(obj_t, obj_t, obj_t);
static obj_t arg1454_expand_let(obj_t);
static obj_t arg1414_expand_let(obj_t);
static obj_t arg1357_expand_let(obj_t);
static obj_t arg1330_expand_let(obj_t);
static obj_t _expand_letrec1470_78_expand_let(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_expand_let = BUNSPEC;
static obj_t cnst_init_137_expand_let();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t internal_definition__7_expand_lambda;
static obj_t __cnst[6];

DEFINE_EXPORT_PROCEDURE(expand_labels_env_80_expand_let, _expand_labels1471_75_expand_let1482, _expand_labels1471_75_expand_let, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_let_env_1_expand_let, _expand_let1469_33_expand_let1483, _expand_let1469_33_expand_let, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_letrec_env_215_expand_let, _expand_letrec1470_78_expand_let1484, _expand_letrec1470_78_expand_let, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_let__env_145_expand_let, _expand_let_1468_26_expand_let1485, _expand_let_1468_26_expand_let, 0L, 2);
DEFINE_STRING(string1476_expand_let, string1476_expand_let1486, "LETREC _ (UNSPECIFIED) LABELS LET* LET ", 39);
DEFINE_STRING(string1475_expand_let, string1475_expand_let1487, "Illegal `labels' form", 21);
DEFINE_STRING(string1474_expand_let, string1474_expand_let1488, "Illegal `letrec' form", 21);
DEFINE_STRING(string1473_expand_let, string1473_expand_let1489, "Illegal `let' form", 18);
DEFINE_STRING(string1472_expand_let, string1472_expand_let1490, "Illegal `let*' form", 19);


/* module-initialization */ obj_t 
module_initialization_70_expand_let(long checksum_703, char *from_704)
{
   if (CBOOL(require_initialization_114_expand_let))
     {
	require_initialization_114_expand_let = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_let();
	cnst_init_137_expand_let();
	imported_modules_init_94_expand_let();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_let()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_LET");
   module_initialization_70___reader(((long) 0), "EXPAND_LET");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_let()
{
   {
      obj_t cnst_port_138_695;
      cnst_port_138_695 = open_input_string(string1476_expand_let);
      {
	 long i_696;
	 i_696 = ((long) 5);
       loop_697:
	 {
	    bool_t test1477_698;
	    test1477_698 = (i_696 == ((long) -1));
	    if (test1477_698)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1478_699;
		    {
		       obj_t list1479_700;
		       {
			  obj_t arg1480_701;
			  arg1480_701 = BNIL;
			  list1479_700 = MAKE_PAIR(cnst_port_138_695, arg1480_701);
		       }
		       arg1478_699 = read___reader(list1479_700);
		    }
		    CNST_TABLE_SET(i_696, arg1478_699);
		 }
		 {
		    int aux_702;
		    {
		       long aux_719;
		       aux_719 = (i_696 - ((long) 1));
		       aux_702 = (int) (aux_719);
		    }
		    {
		       long i_722;
		       i_722 = (long) (aux_702);
		       i_696 = i_722;
		       goto loop_697;
		    }
		 }
	      }
	 }
      }
   }
}


/* expand-let* */ obj_t 
expand_let__212_expand_let(obj_t x_1, obj_t e_2)
{
   {
      obj_t old_internal_68_9;
      old_internal_68_9 = internal_definition__7_expand_lambda;
      internal_definition__7_expand_lambda = BTRUE;
      {
	 obj_t e_10;
	 e_10 = internal_begin_expander_196_expand_lambda(e_2);
	 {
	    obj_t res_11;
	    {
	       obj_t bindings_14;
	       obj_t body_15;
	       obj_t body_12;
	       if (PAIRP(x_1))
		 {
		    obj_t cdr_109_69_20;
		    cdr_109_69_20 = CDR(x_1);
		    if (PAIRP(cdr_109_69_20))
		      {
			 obj_t cdr_112_210_22;
			 cdr_112_210_22 = CDR(cdr_109_69_20);
			 {
			    bool_t test_731;
			    {
			       obj_t aux_732;
			       aux_732 = CAR(cdr_109_69_20);
			       test_731 = (aux_732 == BNIL);
			    }
			    if (test_731)
			      {
				 if ((cdr_112_210_22 == BNIL))
				   {
				    tag_103_156_17:
				      FAILURE(BFALSE, string1472_expand_let, x_1);
				   }
				 else
				   {
				      body_12 = cdr_112_210_22;
				      {
					 obj_t arg1041_33;
					 {
					    obj_t arg1053_34;
					    obj_t arg1056_36;
					    arg1053_34 = CNST_TABLE_REF(((long) 0));
					    arg1056_36 = normalize_progn_143_tools_progn(body_12);
					    {
					       obj_t list1058_38;
					       {
						  obj_t arg1059_39;
						  {
						     obj_t arg1060_40;
						     arg1060_40 = MAKE_PAIR(BNIL, BNIL);
						     arg1059_39 = MAKE_PAIR(arg1056_36, arg1060_40);
						  }
						  list1058_38 = MAKE_PAIR(BNIL, arg1059_39);
					       }
					       arg1041_33 = cons__138___r4_pairs_and_lists_6_3(arg1053_34, list1058_38);
					    }
					 }
					 res_11 = PROCEDURE_ENTRY(e_10) (e_10, arg1041_33, e_10, BEOA);
				      }
				   }
			      }
			    else
			      {
				 obj_t cdr_128_145_27;
				 cdr_128_145_27 = CDR(cdr_109_69_20);
				 if ((cdr_128_145_27 == BNIL))
				   {
				      goto tag_103_156_17;
				   }
				 else
				   {
				      bindings_14 = CAR(cdr_109_69_20);
				      body_15 = cdr_128_145_27;
				      {
					 obj_t arg1062_42;
					 {
					    obj_t arg1063_43;
					    obj_t arg1065_44;
					    obj_t arg1066_45;
					    arg1063_43 = CNST_TABLE_REF(((long) 0));
					    {
					       obj_t arg1145_51;
					       arg1145_51 = CAR(bindings_14);
					       {
						  obj_t list1151_53;
						  list1151_53 = MAKE_PAIR(BNIL, BNIL);
						  arg1065_44 = cons__138___r4_pairs_and_lists_6_3(arg1145_51, list1151_53);
					       }
					    }
					    {
					       obj_t arg1161_55;
					       obj_t arg1163_56;
					       obj_t arg1175_57;
					       arg1161_55 = CNST_TABLE_REF(((long) 1));
					       arg1163_56 = CDR(bindings_14);
					       arg1175_57 = normalize_progn_143_tools_progn(body_15);
					       {
						  obj_t list1177_59;
						  {
						     obj_t arg1187_60;
						     {
							obj_t arg1188_61;
							arg1188_61 = MAKE_PAIR(BNIL, BNIL);
							arg1187_60 = MAKE_PAIR(arg1175_57, arg1188_61);
						     }
						     list1177_59 = MAKE_PAIR(arg1163_56, arg1187_60);
						  }
						  arg1066_45 = cons__138___r4_pairs_and_lists_6_3(arg1161_55, list1177_59);
					       }
					    }
					    {
					       obj_t list1078_47;
					       {
						  obj_t arg1137_48;
						  {
						     obj_t arg1142_49;
						     arg1142_49 = MAKE_PAIR(BNIL, BNIL);
						     arg1137_48 = MAKE_PAIR(arg1066_45, arg1142_49);
						  }
						  list1078_47 = MAKE_PAIR(arg1065_44, arg1137_48);
					       }
					       arg1062_42 = cons__138___r4_pairs_and_lists_6_3(arg1063_43, list1078_47);
					    }
					 }
					 res_11 = PROCEDURE_ENTRY(e_10) (e_10, arg1062_42, e_10, BEOA);
				      }
				   }
			      }
			 }
		      }
		    else
		      {
			 goto tag_103_156_17;
		      }
		 }
	       else
		 {
		    goto tag_103_156_17;
		 }
	    }
	    {
	       internal_definition__7_expand_lambda = old_internal_68_9;
	       return replace__160_tools_misc(x_1, res_11);
	    }
	 }
      }
   }
}


/* _expand-let*1468 */ obj_t 
_expand_let_1468_26_expand_let(obj_t env_650, obj_t x_651, obj_t e_652)
{
   return expand_let__212_expand_let(x_651, e_652);
}


/* expand-let */ obj_t 
expand_let_145_expand_let(obj_t x_3, obj_t e_4)
{
   {
      obj_t old_internal_68_63;
      old_internal_68_63 = internal_definition__7_expand_lambda;
      internal_definition__7_expand_lambda = BTRUE;
      {
	 obj_t e_64;
	 e_64 = internal_begin_expander_196_expand_lambda(e_4);
	 {
	    obj_t res_65;
	    {
	       obj_t bindings_72;
	       obj_t body_73;
	       obj_t loop_68;
	       obj_t bindings_69;
	       obj_t body_70;
	       obj_t body_66;
	       if (PAIRP(x_3))
		 {
		    obj_t cdr_150_103_78;
		    cdr_150_103_78 = CDR(x_3);
		    if (PAIRP(cdr_150_103_78))
		      {
			 obj_t cdr_153_181_80;
			 cdr_153_181_80 = CDR(cdr_150_103_78);
			 {
			    bool_t test_776;
			    {
			       obj_t aux_777;
			       aux_777 = CAR(cdr_150_103_78);
			       test_776 = (aux_777 == BNIL);
			    }
			    if (test_776)
			      {
				 if ((cdr_153_181_80 == BNIL))
				   {
				      obj_t car_167_57_84;
				      obj_t cdr_168_138_85;
				      car_167_57_84 = CAR(cdr_150_103_78);
				      cdr_168_138_85 = CDR(cdr_150_103_78);
				      if (SYMBOLP(car_167_57_84))
					{
					   if (PAIRP(cdr_168_138_85))
					     {
						obj_t cdr_175_128_88;
						cdr_175_128_88 = CDR(cdr_168_138_85);
						if ((cdr_175_128_88 == BNIL))
						  {
						     obj_t car_187_173_91;
						     car_187_173_91 = CAR(cdr_150_103_78);
						     if (PAIRP(car_187_173_91))
						       {
							  bindings_72 = car_187_173_91;
							  body_73 = CDR(cdr_150_103_78);
							tag_142_79_74:
							  {
							     obj_t arg1288_193;
							     obj_t arg1290_194;
							     obj_t arg1291_195;
							     arg1288_193 = CNST_TABLE_REF(((long) 0));
							     {
								obj_t bindings_201;
								obj_t acc_202;
								bindings_201 = bindings_72;
								acc_202 = BNIL;
							      loop_203:
								if (NULLP(bindings_201))
								  {
								     arg1290_194 = reverse__39___r4_pairs_and_lists_6_3(acc_202);
								  }
								else
								  {
								     obj_t pr_206;
								     pr_206 = CAR(bindings_201);
								     if (PAIRP(pr_206))
								       {
									  bool_t test_801;
									  {
									     bool_t test_802;
									     {
										obj_t aux_803;
										aux_803 = CDR(pr_206);
										test_802 = PAIRP(aux_803);
									     }
									     if (test_802)
									       {
										  obj_t aux_806;
										  {
										     obj_t aux_807;
										     aux_807 = CDR(pr_206);
										     aux_806 = CDR(aux_807);
										  }
										  test_801 = NULLP(aux_806);
									       }
									     else
									       {
										  test_801 = ((bool_t) 0);
									       }
									  }
									  if (test_801)
									    {
									       {
										  obj_t bd_209;
										  {
										     obj_t arg1303_212;
										     obj_t arg1304_213;
										     arg1303_212 = CAR(pr_206);
										     {
											obj_t arg1309_217;
											arg1309_217 = normalize_progn_143_tools_progn(CDR(pr_206));
											arg1304_213 = PROCEDURE_ENTRY(e_64) (e_64, arg1309_217, e_64, BEOA);
										     }
										     {
											obj_t list1305_214;
											{
											   obj_t arg1307_215;
											   arg1307_215 = MAKE_PAIR(arg1304_213, BNIL);
											   list1305_214 = MAKE_PAIR(arg1303_212, arg1307_215);
											}
											bd_209 = list1305_214;
										     }
										  }
										  replace__160_tools_misc(pr_206, bd_209);
										  {
										     obj_t arg1301_210;
										     obj_t arg1302_211;
										     arg1301_210 = CDR(bindings_201);
										     arg1302_211 = MAKE_PAIR(pr_206, acc_202);
										     {
											obj_t acc_822;
											obj_t bindings_821;
											bindings_821 = arg1301_210;
											acc_822 = arg1302_211;
											acc_202 = acc_822;
											bindings_201 = bindings_821;
											goto loop_203;
										     }
										  }
									       }
									    }
									  else
									    {
									       FAILURE(BFALSE, string1473_expand_let, x_3);
									    }
								       }
								     else
								       {
									  {
									     obj_t arg1316_222;
									     obj_t arg1319_223;
									     arg1316_222 = CDR(bindings_201);
									     {
										obj_t arg1321_224;
										{
										   obj_t list1323_226;
										   {
										      obj_t arg1324_227;
										      {
											 obj_t aux_825;
											 aux_825 = CNST_TABLE_REF(((long) 3));
											 arg1324_227 = MAKE_PAIR(aux_825, BNIL);
										      }
										      list1323_226 = MAKE_PAIR(pr_206, arg1324_227);
										   }
										   arg1321_224 = list1323_226;
										}
										arg1319_223 = MAKE_PAIR(arg1321_224, acc_202);
									     }
									     {
										obj_t acc_831;
										obj_t bindings_830;
										bindings_830 = arg1316_222;
										acc_831 = arg1319_223;
										acc_202 = acc_831;
										bindings_201 = bindings_830;
										goto loop_203;
									     }
									  }
								       }
								  }
							     }
							     {
								obj_t arg1326_229;
								obj_t arg1328_230;
								if (NULLP(bindings_72))
								  {
								     arg1326_229 = BNIL;
								  }
								else
								  {
								     obj_t head1014_234;
								     head1014_234 = MAKE_PAIR(BNIL, BNIL);
								     {
									obj_t l1012_235;
									obj_t tail1015_236;
									l1012_235 = bindings_72;
									tail1015_236 = head1014_234;
								      lname1013_237:
									if (NULLP(l1012_235))
									  {
									     arg1326_229 = CDR(head1014_234);
									  }
									else
									  {
									     obj_t newtail1016_239;
									     {
										obj_t aux_838;
										{
										   obj_t v_243;
										   v_243 = CAR(l1012_235);
										   if (PAIRP(v_243))
										     {
											aux_838 = CAR(v_243);
										     }
										   else
										     {
											aux_838 = v_243;
										     }
										}
										newtail1016_239 = MAKE_PAIR(aux_838, BNIL);
									     }
									     SET_CDR(tail1015_236, newtail1016_239);
									     {
										obj_t tail1015_847;
										obj_t l1012_845;
										l1012_845 = CDR(l1012_235);
										tail1015_847 = newtail1016_239;
										tail1015_236 = tail1015_847;
										l1012_235 = l1012_845;
										goto lname1013_237;
									     }
									  }
								     }
								  }
								arg1328_230 = CNST_TABLE_REF(((long) 4));
								{
								   obj_t arg1330_653;
								   arg1330_653 = make_fx_procedure(arg1330_expand_let, ((long) 0), ((long) 2));
								   PROCEDURE_SET(arg1330_653, ((long) 0), body_73);
								   PROCEDURE_SET(arg1330_653, ((long) 1), e_64);
								   arg1291_195 = with_lexical_22_expand_eps(arg1326_229, arg1328_230, arg1330_653);
								}
							     }
							     {
								obj_t list1293_197;
								{
								   obj_t arg1294_198;
								   {
								      obj_t arg1295_199;
								      arg1295_199 = MAKE_PAIR(BNIL, BNIL);
								      arg1294_198 = MAKE_PAIR(arg1291_195, arg1295_199);
								   }
								   list1293_197 = MAKE_PAIR(arg1290_194, arg1294_198);
								}
								res_65 = cons__138___r4_pairs_and_lists_6_3(arg1288_193, list1293_197);
							     }
							  }
						       }
						     else
						       {
							tag_143_46_75:
							  FAILURE(BFALSE, string1473_expand_let, x_3);
						       }
						  }
						else
						  {
						     loop_68 = car_167_57_84;
						     bindings_69 = CAR(cdr_168_138_85);
						     body_70 = cdr_175_128_88;
						   tag_141_241_71:
						     {
							bool_t test_859;
							if (NULLP(bindings_69))
							  {
							     test_859 = ((bool_t) 1);
							  }
							else
							  {
							     test_859 = PAIRP(bindings_69);
							  }
							if (test_859)
							  {
							     obj_t arg1235_134;
							     {
								obj_t arg1236_135;
								obj_t arg1238_136;
								obj_t arg1240_137;
								arg1236_135 = CNST_TABLE_REF(((long) 2));
								{
								   obj_t arg1247_143;
								   {
								      obj_t arg1251_147;
								      obj_t arg1252_148;
								      if (NULLP(bindings_69))
									{
									   arg1251_147 = BNIL;
									}
								      else
									{
									   obj_t head1004_154;
									   head1004_154 = MAKE_PAIR(BNIL, BNIL);
									   {
									      obj_t l1002_155;
									      obj_t tail1005_156;
									      l1002_155 = bindings_69;
									      tail1005_156 = head1004_154;
									    lname1003_157:
									      if (NULLP(l1002_155))
										{
										   arg1251_147 = CDR(head1004_154);
										}
									      else
										{
										   obj_t newtail1006_159;
										   {
										      obj_t arg1259_161;
										      {
											 obj_t b_163;
											 b_163 = CAR(l1002_155);
											 if (PAIRP(b_163))
											   {
											      arg1259_161 = CAR(b_163);
											   }
											 else
											   {
											      FAILURE(BFALSE, string1473_expand_let, x_3);
											   }
										      }
										      newtail1006_159 = MAKE_PAIR(arg1259_161, BNIL);
										   }
										   SET_CDR(tail1005_156, newtail1006_159);
										   {
										      obj_t tail1005_879;
										      obj_t l1002_877;
										      l1002_877 = CDR(l1002_155);
										      tail1005_879 = newtail1006_159;
										      tail1005_156 = tail1005_879;
										      l1002_155 = l1002_877;
										      goto lname1003_157;
										   }
										}
									   }
									}
								      {
									 obj_t arg1265_167;
									 arg1265_167 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
									 arg1252_148 = append_2_18___r4_pairs_and_lists_6_3(body_70, arg1265_167);
								      }
								      {
									 obj_t list1253_149;
									 {
									    obj_t arg1254_150;
									    arg1254_150 = MAKE_PAIR(arg1252_148, BNIL);
									    list1253_149 = MAKE_PAIR(arg1251_147, arg1254_150);
									 }
									 arg1247_143 = cons__138___r4_pairs_and_lists_6_3(loop_68, list1253_149);
								      }
								   }
								   {
								      obj_t list1249_145;
								      list1249_145 = MAKE_PAIR(BNIL, BNIL);
								      arg1238_136 = cons__138___r4_pairs_and_lists_6_3(arg1247_143, list1249_145);
								   }
								}
								{
								   obj_t arg1269_170;
								   {
								      obj_t arg1273_173;
								      obj_t arg1274_174;
								      if (NULLP(bindings_69))
									{
									   arg1273_173 = BNIL;
									}
								      else
									{
									   obj_t head1009_177;
									   head1009_177 = MAKE_PAIR(BNIL, BNIL);
									   {
									      obj_t l1007_178;
									      obj_t tail1010_179;
									      l1007_178 = bindings_69;
									      tail1010_179 = head1009_177;
									    lname1008_180:
									      if (NULLP(l1007_178))
										{
										   arg1273_173 = CDR(head1009_177);
										}
									      else
										{
										   obj_t newtail1011_182;
										   {
										      obj_t arg1278_184;
										      {
											 obj_t aux_893;
											 {
											    obj_t aux_894;
											    aux_894 = CAR(l1007_178);
											    aux_893 = CDR(aux_894);
											 }
											 arg1278_184 = normalize_progn_143_tools_progn(aux_893);
										      }
										      newtail1011_182 = MAKE_PAIR(arg1278_184, BNIL);
										   }
										   SET_CDR(tail1010_179, newtail1011_182);
										   {
										      obj_t tail1010_902;
										      obj_t l1007_900;
										      l1007_900 = CDR(l1007_178);
										      tail1010_902 = newtail1011_182;
										      tail1010_179 = tail1010_902;
										      l1007_178 = l1007_900;
										      goto lname1008_180;
										   }
										}
									   }
									}
								      arg1274_174 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
								      arg1269_170 = append_2_18___r4_pairs_and_lists_6_3(arg1273_173, arg1274_174);
								   }
								   {
								      obj_t list1270_171;
								      list1270_171 = MAKE_PAIR(arg1269_170, BNIL);
								      arg1240_137 = cons__138___r4_pairs_and_lists_6_3(loop_68, list1270_171);
								   }
								}
								{
								   obj_t list1242_139;
								   {
								      obj_t arg1243_140;
								      {
									 obj_t arg1244_141;
									 arg1244_141 = MAKE_PAIR(BNIL, BNIL);
									 arg1243_140 = MAKE_PAIR(arg1240_137, arg1244_141);
								      }
								      list1242_139 = MAKE_PAIR(arg1238_136, arg1243_140);
								   }
								   arg1235_134 = cons__138___r4_pairs_and_lists_6_3(arg1236_135, list1242_139);
								}
							     }
							     res_65 = PROCEDURE_ENTRY(e_64) (e_64, arg1235_134, e_64, BEOA);
							  }
							else
							  {
							     FAILURE(BFALSE, string1473_expand_let, x_3);
							  }
						     }
						  }
					     }
					   else
					     {
						goto tag_143_46_75;
					     }
					}
				      else
					{
					   goto tag_143_46_75;
					}
				   }
				 else
				   {
				      body_66 = cdr_153_181_80;
				      {
					 obj_t arg1221_124;
					 obj_t arg1224_126;
					 arg1221_124 = CNST_TABLE_REF(((long) 0));
					 {
					    obj_t arg1233_132;
					    arg1233_132 = normalize_progn_143_tools_progn(body_66);
					    arg1224_126 = PROCEDURE_ENTRY(e_64) (e_64, arg1233_132, e_64, BEOA);
					 }
					 {
					    obj_t list1226_128;
					    {
					       obj_t arg1228_129;
					       {
						  obj_t arg1231_130;
						  arg1231_130 = MAKE_PAIR(BNIL, BNIL);
						  arg1228_129 = MAKE_PAIR(arg1224_126, arg1231_130);
					       }
					       list1226_128 = MAKE_PAIR(BNIL, arg1228_129);
					    }
					    res_65 = cons__138___r4_pairs_and_lists_6_3(arg1221_124, list1226_128);
					 }
				      }
				   }
			      }
			    else
			      {
				 obj_t car_213_12_98;
				 obj_t cdr_214_210_99;
				 car_213_12_98 = CAR(cdr_150_103_78);
				 cdr_214_210_99 = CDR(cdr_150_103_78);
				 if (SYMBOLP(car_213_12_98))
				   {
				      if (PAIRP(cdr_214_210_99))
					{
					   obj_t cdr_221_6_102;
					   cdr_221_6_102 = CDR(cdr_214_210_99);
					   if ((cdr_221_6_102 == BNIL))
					     {
						obj_t car_235_124_105;
						car_235_124_105 = CAR(cdr_150_103_78);
						if (PAIRP(car_235_124_105))
						  {
						     obj_t body_936;
						     obj_t bindings_935;
						     bindings_935 = car_235_124_105;
						     body_936 = CDR(cdr_150_103_78);
						     body_73 = body_936;
						     bindings_72 = bindings_935;
						     goto tag_142_79_74;
						  }
						else
						  {
						     goto tag_143_46_75;
						  }
					     }
					   else
					     {
						obj_t body_941;
						obj_t bindings_939;
						obj_t loop_938;
						loop_938 = car_213_12_98;
						bindings_939 = CAR(cdr_214_210_99);
						body_941 = cdr_221_6_102;
						body_70 = body_941;
						bindings_69 = bindings_939;
						loop_68 = loop_938;
						goto tag_141_241_71;
					     }
					}
				      else
					{
					   obj_t car_254_112_111;
					   obj_t cdr_255_181_112;
					   car_254_112_111 = CAR(cdr_150_103_78);
					   cdr_255_181_112 = CDR(cdr_150_103_78);
					   if (PAIRP(car_254_112_111))
					     {
						if ((cdr_255_181_112 == BNIL))
						  {
						     goto tag_143_46_75;
						  }
						else
						  {
						     obj_t body_949;
						     obj_t bindings_948;
						     bindings_948 = car_254_112_111;
						     body_949 = cdr_255_181_112;
						     body_73 = body_949;
						     bindings_72 = bindings_948;
						     goto tag_142_79_74;
						  }
					     }
					   else
					     {
						goto tag_143_46_75;
					     }
					}
				   }
				 else
				   {
				      obj_t car_271_42_117;
				      obj_t cdr_272_238_118;
				      car_271_42_117 = CAR(cdr_150_103_78);
				      cdr_272_238_118 = CDR(cdr_150_103_78);
				      if (PAIRP(car_271_42_117))
					{
					   if ((cdr_272_238_118 == BNIL))
					     {
						goto tag_143_46_75;
					     }
					   else
					     {
						obj_t body_957;
						obj_t bindings_956;
						bindings_956 = car_271_42_117;
						body_957 = cdr_272_238_118;
						body_73 = body_957;
						bindings_72 = bindings_956;
						goto tag_142_79_74;
					     }
					}
				      else
					{
					   goto tag_143_46_75;
					}
				   }
			      }
			 }
		      }
		    else
		      {
			 goto tag_143_46_75;
		      }
		 }
	       else
		 {
		    goto tag_143_46_75;
		 }
	    }
	    {
	       internal_definition__7_expand_lambda = old_internal_68_63;
	       return replace__160_tools_misc(x_3, res_65);
	    }
	 }
      }
   }
}


/* _expand-let1469 */ obj_t 
_expand_let1469_33_expand_let(obj_t env_654, obj_t x_655, obj_t e_656)
{
   return expand_let_145_expand_let(x_655, e_656);
}


/* arg1330 */ obj_t 
arg1330_expand_let(obj_t env_657)
{
   {
      obj_t body_658;
      obj_t e_659;
      body_658 = PROCEDURE_REF(env_657, ((long) 0));
      e_659 = PROCEDURE_REF(env_657, ((long) 1));
      {
	 {
	    obj_t arg1342_248;
	    arg1342_248 = normalize_progn_143_tools_progn(body_658);
	    return PROCEDURE_ENTRY(e_659) (e_659, arg1342_248, e_659, BEOA);
	 }
      }
   }
}


/* expand-letrec */ obj_t 
expand_letrec_249_expand_let(obj_t x_5, obj_t e_6)
{
   {
      obj_t old_internal_68_250;
      old_internal_68_250 = internal_definition__7_expand_lambda;
      internal_definition__7_expand_lambda = BTRUE;
      {
	 obj_t e_251;
	 e_251 = internal_begin_expander_196_expand_lambda(e_6);
	 {
	    obj_t res_252;
	    {
	       obj_t bindings_255;
	       obj_t body_256;
	       obj_t body_253;
	       if (PAIRP(x_5))
		 {
		    obj_t cdr_306_55_261;
		    cdr_306_55_261 = CDR(x_5);
		    if (PAIRP(cdr_306_55_261))
		      {
			 obj_t cdr_309_130_263;
			 cdr_309_130_263 = CDR(cdr_306_55_261);
			 {
			    bool_t test_972;
			    {
			       obj_t aux_973;
			       aux_973 = CAR(cdr_306_55_261);
			       test_972 = (aux_973 == BNIL);
			    }
			    if (test_972)
			      {
				 if ((cdr_309_130_263 == BNIL))
				   {
				    tag_300_3_258:
				      FAILURE(BFALSE, string1474_expand_let, x_5);
				   }
				 else
				   {
				      body_253 = cdr_309_130_263;
				      {
					 obj_t aux_979;
					 aux_979 = CNST_TABLE_REF(((long) 0));
					 SET_CAR(x_5, aux_979);
				      }
				      res_252 = PROCEDURE_ENTRY(e_251) (e_251, x_5, e_251, BEOA);
				   }
			      }
			    else
			      {
				 obj_t car_324_234_268;
				 obj_t cdr_325_196_269;
				 car_324_234_268 = CAR(cdr_306_55_261);
				 cdr_325_196_269 = CDR(cdr_306_55_261);
				 if (PAIRP(car_324_234_268))
				   {
				      if ((cdr_325_196_269 == BNIL))
					{
					   goto tag_300_3_258;
					}
				      else
					{
					   bindings_255 = car_324_234_268;
					   body_256 = cdr_325_196_269;
					   {
					      obj_t arg1355_276;
					      obj_t arg1356_277;
					      if (NULLP(bindings_255))
						{
						   arg1355_276 = BNIL;
						}
					      else
						{
						   obj_t head1019_281;
						   head1019_281 = MAKE_PAIR(BNIL, BNIL);
						   {
						      obj_t l1017_282;
						      obj_t tail1020_283;
						      l1017_282 = bindings_255;
						      tail1020_283 = head1019_281;
						    lname1018_284:
						      if (NULLP(l1017_282))
							{
							   arg1355_276 = CDR(head1019_281);
							}
						      else
							{
							   obj_t newtail1021_286;
							   {
							      obj_t aux_996;
							      {
								 obj_t v_290;
								 v_290 = CAR(l1017_282);
								 if (PAIRP(v_290))
								   {
								      aux_996 = CAR(v_290);
								   }
								 else
								   {
								      aux_996 = v_290;
								   }
							      }
							      newtail1021_286 = MAKE_PAIR(aux_996, BNIL);
							   }
							   SET_CDR(tail1020_283, newtail1021_286);
							   {
							      obj_t tail1020_1005;
							      obj_t l1017_1003;
							      l1017_1003 = CDR(l1017_282);
							      tail1020_1005 = newtail1021_286;
							      tail1020_283 = tail1020_1005;
							      l1017_282 = l1017_1003;
							      goto lname1018_284;
							   }
							}
						   }
						}
					      arg1356_277 = CNST_TABLE_REF(((long) 4));
					      {
						 obj_t arg1357_660;
						 arg1357_660 = make_fx_procedure(arg1357_expand_let, ((long) 0), ((long) 4));
						 PROCEDURE_SET(arg1357_660, ((long) 0), x_5);
						 PROCEDURE_SET(arg1357_660, ((long) 1), e_251);
						 PROCEDURE_SET(arg1357_660, ((long) 2), bindings_255);
						 PROCEDURE_SET(arg1357_660, ((long) 3), body_256);
						 res_252 = with_lexical_22_expand_eps(arg1355_276, arg1356_277, arg1357_660);
					      }
					   }
					}
				   }
				 else
				   {
				      goto tag_300_3_258;
				   }
			      }
			 }
		      }
		    else
		      {
			 goto tag_300_3_258;
		      }
		 }
	       else
		 {
		    goto tag_300_3_258;
		 }
	    }
	    {
	       internal_definition__7_expand_lambda = old_internal_68_250;
	       return replace__160_tools_misc(x_5, res_252);
	    }
	 }
      }
   }
}


/* _expand-letrec1470 */ obj_t 
_expand_letrec1470_78_expand_let(obj_t env_661, obj_t x_662, obj_t e_663)
{
   return expand_letrec_249_expand_let(x_662, e_663);
}


/* arg1357 */ obj_t 
arg1357_expand_let(obj_t env_664)
{
   {
      obj_t x_665;
      obj_t e_666;
      obj_t bindings_667;
      obj_t body_668;
      x_665 = PROCEDURE_REF(env_664, ((long) 0));
      e_666 = PROCEDURE_REF(env_664, ((long) 1));
      bindings_667 = PROCEDURE_REF(env_664, ((long) 2));
      body_668 = PROCEDURE_REF(env_664, ((long) 3));
      {
	 {
	    obj_t arg1370_295;
	    obj_t arg1372_296;
	    obj_t arg1373_297;
	    arg1370_295 = CNST_TABLE_REF(((long) 5));
	    {
	       obj_t bindings_303;
	       obj_t acc_304;
	       bindings_303 = bindings_667;
	       acc_304 = BNIL;
	     loop_305:
	       if (NULLP(bindings_303))
		 {
		    arg1372_296 = reverse__39___r4_pairs_and_lists_6_3(acc_304);
		 }
	       else
		 {
		    obj_t pr_308;
		    pr_308 = CAR(bindings_303);
		    if (PAIRP(pr_308))
		      {
			 obj_t nb_310;
			 {
			    obj_t arg1389_313;
			    obj_t arg1390_314;
			    arg1389_313 = CAR(pr_308);
			    {
			       obj_t arg1395_318;
			       arg1395_318 = normalize_progn_143_tools_progn(CDR(pr_308));
			       arg1390_314 = PROCEDURE_ENTRY(e_666) (e_666, arg1395_318, e_666, BEOA);
			    }
			    {
			       obj_t list1391_315;
			       {
				  obj_t arg1392_316;
				  arg1392_316 = MAKE_PAIR(arg1390_314, BNIL);
				  list1391_315 = MAKE_PAIR(arg1389_313, arg1392_316);
			       }
			       nb_310 = list1391_315;
			    }
			 }
			 replace__160_tools_misc(pr_308, nb_310);
			 {
			    obj_t arg1387_311;
			    obj_t arg1388_312;
			    arg1387_311 = CDR(bindings_303);
			    arg1388_312 = MAKE_PAIR(pr_308, acc_304);
			    {
			       obj_t acc_1037;
			       obj_t bindings_1036;
			       bindings_1036 = arg1387_311;
			       acc_1037 = arg1388_312;
			       acc_304 = acc_1037;
			       bindings_303 = bindings_1036;
			       goto loop_305;
			    }
			 }
		      }
		    else
		      {
			 FAILURE(BFALSE, string1474_expand_let, x_665);
		      }
		 }
	    }
	    {
	       obj_t arg1397_320;
	       arg1397_320 = normalize_progn_143_tools_progn(body_668);
	       arg1373_297 = PROCEDURE_ENTRY(e_666) (e_666, arg1397_320, e_666, BEOA);
	    }
	    {
	       obj_t list1376_299;
	       {
		  obj_t arg1378_300;
		  {
		     obj_t arg1379_301;
		     arg1379_301 = MAKE_PAIR(BNIL, BNIL);
		     arg1378_300 = MAKE_PAIR(arg1373_297, arg1379_301);
		  }
		  list1376_299 = MAKE_PAIR(arg1372_296, arg1378_300);
	       }
	       return cons__138___r4_pairs_and_lists_6_3(arg1370_295, list1376_299);
	    }
	 }
      }
   }
}


/* expand-labels */ obj_t 
expand_labels_128_expand_let(obj_t x_7, obj_t e_8)
{
   {
      obj_t old_internal_68_322;
      old_internal_68_322 = internal_definition__7_expand_lambda;
      internal_definition__7_expand_lambda = BTRUE;
      {
	 obj_t e_323;
	 e_323 = internal_begin_expander_196_expand_lambda(e_8);
	 {
	    obj_t res_324;
	    {
	       obj_t bindings_327;
	       obj_t body_328;
	       obj_t body_325;
	       if (PAIRP(x_7))
		 {
		    obj_t cdr_347_27_333;
		    cdr_347_27_333 = CDR(x_7);
		    if (PAIRP(cdr_347_27_333))
		      {
			 obj_t cdr_350_16_335;
			 cdr_350_16_335 = CDR(cdr_347_27_333);
			 {
			    bool_t test_1053;
			    {
			       obj_t aux_1054;
			       aux_1054 = CAR(cdr_347_27_333);
			       test_1053 = (aux_1054 == BNIL);
			    }
			    if (test_1053)
			      {
				 if ((cdr_350_16_335 == BNIL))
				   {
				    tag_341_113_330:
				      FAILURE(BFALSE, string1475_expand_let, x_7);
				   }
				 else
				   {
				      body_325 = cdr_350_16_335;
				      {
					 obj_t aux_1060;
					 aux_1060 = CNST_TABLE_REF(((long) 0));
					 SET_CAR(x_7, aux_1060);
				      }
				      res_324 = PROCEDURE_ENTRY(e_323) (e_323, x_7, e_323, BEOA);
				   }
			      }
			    else
			      {
				 obj_t car_365_149_340;
				 obj_t cdr_366_96_341;
				 car_365_149_340 = CAR(cdr_347_27_333);
				 cdr_366_96_341 = CDR(cdr_347_27_333);
				 if (PAIRP(car_365_149_340))
				   {
				      if ((cdr_366_96_341 == BNIL))
					{
					   goto tag_341_113_330;
					}
				      else
					{
					   bindings_327 = car_365_149_340;
					   body_328 = cdr_366_96_341;
					   {
					      obj_t arg1411_348;
					      obj_t arg1413_349;
					      if (NULLP(bindings_327))
						{
						   arg1411_348 = BNIL;
						}
					      else
						{
						   obj_t head1024_353;
						   head1024_353 = MAKE_PAIR(BNIL, BNIL);
						   {
						      obj_t l1022_354;
						      obj_t tail1025_355;
						      l1022_354 = bindings_327;
						      tail1025_355 = head1024_353;
						    lname1023_356:
						      if (NULLP(l1022_354))
							{
							   arg1411_348 = CDR(head1024_353);
							}
						      else
							{
							   obj_t newtail1026_358;
							   {
							      obj_t arg1418_360;
							      {
								 obj_t b_362;
								 b_362 = CAR(l1022_354);
								 {
								    bool_t test_1078;
								    if (PAIRP(b_362))
								      {
									 bool_t test_1081;
									 {
									    obj_t aux_1082;
									    aux_1082 = CAR(b_362);
									    test_1081 = SYMBOLP(aux_1082);
									 }
									 if (test_1081)
									   {
									      test_1078 = ((bool_t) 0);
									   }
									 else
									   {
									      test_1078 = ((bool_t) 1);
									   }
								      }
								    else
								      {
									 test_1078 = ((bool_t) 1);
								      }
								    if (test_1078)
								      {
									 FAILURE(BFALSE, string1475_expand_let, x_7);
								      }
								    else
								      {
									 arg1418_360 = CAR(b_362);
								      }
								 }
							      }
							      newtail1026_358 = MAKE_PAIR(arg1418_360, BNIL);
							   }
							   SET_CDR(tail1025_355, newtail1026_358);
							   {
							      obj_t tail1025_1091;
							      obj_t l1022_1089;
							      l1022_1089 = CDR(l1022_354);
							      tail1025_1091 = newtail1026_358;
							      tail1025_355 = tail1025_1091;
							      l1022_354 = l1022_1089;
							      goto lname1023_356;
							   }
							}
						   }
						}
					      arg1413_349 = CNST_TABLE_REF(((long) 4));
					      {
						 obj_t arg1414_673;
						 arg1414_673 = make_fx_procedure(arg1414_expand_let, ((long) 0), ((long) 4));
						 PROCEDURE_SET(arg1414_673, ((long) 0), x_7);
						 PROCEDURE_SET(arg1414_673, ((long) 1), bindings_327);
						 PROCEDURE_SET(arg1414_673, ((long) 2), body_328);
						 PROCEDURE_SET(arg1414_673, ((long) 3), e_323);
						 res_324 = with_lexical_22_expand_eps(arg1411_348, arg1413_349, arg1414_673);
					      }
					   }
					}
				   }
				 else
				   {
				      goto tag_341_113_330;
				   }
			      }
			 }
		      }
		    else
		      {
			 goto tag_341_113_330;
		      }
		 }
	       else
		 {
		    goto tag_341_113_330;
		 }
	    }
	    {
	       internal_definition__7_expand_lambda = old_internal_68_322;
	       return replace__160_tools_misc(x_7, res_324);
	    }
	 }
      }
   }
}


/* _expand-labels1471 */ obj_t 
_expand_labels1471_75_expand_let(obj_t env_674, obj_t x_675, obj_t e_676)
{
   return expand_labels_128_expand_let(x_675, e_676);
}


/* loop */ obj_t 
loop_expand_let(obj_t x_678, obj_t e_677, obj_t bindings_379)
{
   if (NULLP(bindings_379))
     {
	return BNIL;
     }
   else
     {
	if (PAIRP(bindings_379))
	  {
	     {
		obj_t e_382_97_388;
		e_382_97_388 = CAR(bindings_379);
		if (PAIRP(e_382_97_388))
		  {
		     obj_t cdr_390_58_390;
		     cdr_390_58_390 = CDR(e_382_97_388);
		     if (PAIRP(cdr_390_58_390))
		       {
			  return tag_380_71_expand_let(bindings_379, e_677, x_678, CAR(e_382_97_388), CAR(cdr_390_58_390), CDR(cdr_390_58_390));
		       }
		     else
		       {
			  return tag_381_231_expand_let(x_678);
		       }
		  }
		else
		  {
		     return tag_381_231_expand_let(x_678);
		  }
	     }
	  }
	else
	  {
	     FAILURE(BFALSE, string1475_expand_let, x_678);
	  }
     }
}


/* tag-380 */ obj_t 
tag_380_71_expand_let(obj_t bindings_681, obj_t e_680, obj_t x_679, obj_t name_383, obj_t args_384, obj_t lbody_385)
{
   {
      obj_t arg1450_395;
      obj_t arg1453_396;
      arg1450_395 = args___args_list_50_tools_args(args_384);
      arg1453_396 = CNST_TABLE_REF(((long) 4));
      {
	 obj_t arg1454_669;
	 arg1454_669 = make_fx_procedure(arg1454_expand_let, ((long) 0), ((long) 6));
	 PROCEDURE_SET(arg1454_669, ((long) 0), x_679);
	 PROCEDURE_SET(arg1454_669, ((long) 1), lbody_385);
	 PROCEDURE_SET(arg1454_669, ((long) 2), e_680);
	 PROCEDURE_SET(arg1454_669, ((long) 3), args_384);
	 PROCEDURE_SET(arg1454_669, ((long) 4), name_383);
	 PROCEDURE_SET(arg1454_669, ((long) 5), bindings_681);
	 return with_lexical_22_expand_eps(arg1450_395, arg1453_396, arg1454_669);
      }
   }
}


/* tag-381 */ obj_t 
tag_381_231_expand_let(obj_t x_682)
{
   FAILURE(BFALSE, string1475_expand_let, x_682);
}


/* arg1414 */ obj_t 
arg1414_expand_let(obj_t env_683)
{
   {
      obj_t x_684;
      obj_t bindings_685;
      obj_t body_686;
      obj_t e_687;
      x_684 = PROCEDURE_REF(env_683, ((long) 0));
      bindings_685 = PROCEDURE_REF(env_683, ((long) 1));
      body_686 = PROCEDURE_REF(env_683, ((long) 2));
      e_687 = PROCEDURE_REF(env_683, ((long) 3));
      {
	 {
	    obj_t new_370;
	    new_370 = loop_expand_let(x_684, e_687, bindings_685);
	    {
	       obj_t arg1431_371;
	       obj_t arg1432_372;
	       arg1431_371 = CNST_TABLE_REF(((long) 2));
	       {
		  obj_t arg1440_378;
		  arg1440_378 = normalize_progn_143_tools_progn(body_686);
		  arg1432_372 = PROCEDURE_ENTRY(e_687) (e_687, arg1440_378, e_687, BEOA);
	       }
	       {
		  obj_t list1434_374;
		  {
		     obj_t arg1436_375;
		     {
			obj_t arg1437_376;
			arg1437_376 = MAKE_PAIR(BNIL, BNIL);
			arg1436_375 = MAKE_PAIR(arg1432_372, arg1437_376);
		     }
		     list1434_374 = MAKE_PAIR(new_370, arg1436_375);
		  }
		  return cons__138___r4_pairs_and_lists_6_3(arg1431_371, list1434_374);
	       }
	    }
	 }
      }
   }
}


/* arg1454 */ obj_t 
arg1454_expand_let(obj_t env_688)
{
   {
      obj_t x_689;
      obj_t lbody_690;
      obj_t e_691;
      obj_t args_692;
      obj_t name_693;
      obj_t bindings_694;
      x_689 = PROCEDURE_REF(env_688, ((long) 0));
      lbody_690 = PROCEDURE_REF(env_688, ((long) 1));
      e_691 = PROCEDURE_REF(env_688, ((long) 2));
      args_692 = PROCEDURE_REF(env_688, ((long) 3));
      name_693 = PROCEDURE_REF(env_688, ((long) 4));
      bindings_694 = PROCEDURE_REF(env_688, ((long) 5));
      {
	 {
	    obj_t arg1456_399;
	    obj_t arg1458_400;
	    {
	       obj_t arg1460_401;
	       {
		  obj_t arg1466_407;
		  arg1466_407 = normalize_progn_143_tools_progn(lbody_690);
		  arg1460_401 = PROCEDURE_ENTRY(e_691) (e_691, arg1466_407, e_691, BEOA);
	       }
	       {
		  obj_t list1462_403;
		  {
		     obj_t arg1463_404;
		     {
			obj_t arg1464_405;
			arg1464_405 = MAKE_PAIR(BNIL, BNIL);
			arg1463_404 = MAKE_PAIR(arg1460_401, arg1464_405);
		     }
		     list1462_403 = MAKE_PAIR(args_692, arg1463_404);
		  }
		  arg1456_399 = cons__138___r4_pairs_and_lists_6_3(name_693, list1462_403);
	       }
	    }
	    arg1458_400 = loop_expand_let(x_689, e_691, CDR(bindings_694));
	    return MAKE_PAIR(arg1456_399, arg1458_400);
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_let()
{
   module_initialization_70_tools_progn(((long) 0), "EXPAND_LET");
   module_initialization_70_tools_args(((long) 0), "EXPAND_LET");
   module_initialization_70_tools_misc(((long) 0), "EXPAND_LET");
   module_initialization_70_expand_lambda(((long) 0), "EXPAND_LET");
   return module_initialization_70_expand_eps(((long) 0), "EXPAND_LET");
}
