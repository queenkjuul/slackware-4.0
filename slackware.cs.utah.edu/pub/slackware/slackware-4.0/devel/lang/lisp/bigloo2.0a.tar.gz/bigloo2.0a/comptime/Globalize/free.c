/*===========================================================================*/
/*   (Globalize/free.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct sfun_ginfo_98
  {
     bool_t g__219;
     obj_t cfrom;
     obj_t cfrom__119;
     obj_t cto;
     obj_t cto__14;
     obj_t cfunction;
     obj_t integrator;
     obj_t integrated;
     obj_t plugged_in_15;
     long mark;
     obj_t free_mark_81;
     obj_t the_global_201;
     obj_t kaptured;
     obj_t new_body_215;
     long bmark;
     long umark;
     obj_t free;
     obj_t bound;
  }
             *sfun_ginfo_98_t;

typedef struct svar_ginfo_131
  {
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
     bool_t celled__113;
  }
              *svar_ginfo_131_t;

typedef struct sexit_ginfo_81
  {
     bool_t g__219;
     bool_t kaptured__204;
     long free_mark_81;
     long mark;
  }
              *sexit_ginfo_81_t;

typedef struct local_ginfo_108
  {
     bool_t escape__117;
  }
               *local_ginfo_108_t;

typedef struct global_ginfo_75
  {
     bool_t escape__117;
     obj_t global_closure_229;
  }
               *global_ginfo_75_t;


extern obj_t local_ginfo_108_globalize_ginfo;
static obj_t internal_get_free_vars__185_globalize_free(node_t, local_t);
static obj_t method_init_76_globalize_free();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _get_free_vars1960_254_globalize_free(obj_t, obj_t, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t the_closure_238_globalize_free(variable_t, obj_t);
static obj_t _node_free_default1594_29_globalize_free(obj_t, obj_t, obj_t);
extern global_t def_global_scnst__93_ast_glo_def_117(obj_t, obj_t, obj_t, obj_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static long _round__57_globalize_free;
extern obj_t closure_ast_node;
extern obj_t global_ast_var;
static obj_t node_free_158_globalize_free(node_t, obj_t);
extern obj_t pragma_ast_node;
static obj_t _integrator__235_globalize_free = BUNSPEC;
extern obj_t set_ex_it_116_ast_node;
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_globalize_free(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_glo_def_117(long, char *);
extern obj_t module_initialization_70_globalize_ginfo(long, char *);
extern obj_t module_initialization_70_globalize_node(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_globalize_global_closure_246(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t mark_variable__104_globalize_free(local_t);
extern global_t make_global_closure_44_globalize_global_closure_246(global_t);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_globalize_free();
extern obj_t sfun_ginfo_98_globalize_ginfo;
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t node_free_default1594_84_globalize_free(node_t, obj_t);
extern obj_t app_ast_node;
extern obj_t sexit_ginfo_81_globalize_ginfo;
static obj_t library_modules_init_112_globalize_free();
extern obj_t svar_ginfo_131_globalize_ginfo;
static obj_t _node_free1964_252_globalize_free(obj_t, obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_globalize_free();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static obj_t node_free__199_globalize_free(obj_t, obj_t);
static obj_t _the_global_closure1962_203_globalize_free(obj_t, obj_t, obj_t);
extern obj_t get_free_vars_244_globalize_free(node_t, local_t);
extern obj_t local_ast_var;
static obj_t free_variable__181_globalize_free(obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t _free_from1963_119_globalize_free(obj_t, obj_t, obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t the_global_closure_233_globalize_free(global_t, obj_t);
static obj_t _the_closure1961_10_globalize_free(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t free_from_222_globalize_free(obj_t, local_t);
static obj_t bind_variable__14_globalize_free(local_t, local_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_globalize_free = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t the_local_closure_213_globalize_free(obj_t, obj_t);
static obj_t cnst_init_137_globalize_free();
static obj_t __cnst[6];

DEFINE_EXPORT_PROCEDURE(the_closure_env_75_globalize_free, _the_closure1961_10_globalize_free1974, _the_closure1961_10_globalize_free, 0L, 2);
DEFINE_STATIC_GENERIC(node_free_env_48_globalize_free, _node_free1964_252_globalize_free1975, _node_free1964_252_globalize_free, 0L, 2);
DEFINE_EXPORT_PROCEDURE(get_free_vars_env_212_globalize_free, _get_free_vars1960_254_globalize_free1976, _get_free_vars1960_254_globalize_free, 0L, 2);
DEFINE_STATIC_PROCEDURE(node_free_default1594_env_72_globalize_free, _node_free_default1594_29_globalize_free1977, _node_free_default1594_29_globalize_free, 0L, 2);
DEFINE_EXPORT_PROCEDURE(the_global_closure_env_40_globalize_free, _the_global_closure1962_203_globalize_free1978, _the_global_closure1962_203_globalize_free, 0L, 2);
DEFINE_EXPORT_PROCEDURE(free_from_env_97_globalize_free, _free_from1963_119_globalize_free1979, _free_from1963_119_globalize_free, 0L, 2);
DEFINE_STRING(string1967_globalize_free, string1967_globalize_free1980, "SFUN SGFUN -ENV::PROCEDURE VALUE MAKE-FX-PROCEDURE MAKE-VA-PROCEDURE ", 69);
DEFINE_STRING(string1966_globalize_free, string1966_globalize_free1981, "Unknown variable type", 21);
DEFINE_STRING(string1965_globalize_free, string1965_globalize_free1982, "free-variable?", 14);


/* module-initialization */ obj_t 
module_initialization_70_globalize_free(long checksum_2164, char *from_2165)
{
   if (CBOOL(require_initialization_114_globalize_free))
     {
	require_initialization_114_globalize_free = BBOOL(((bool_t) 0));
	library_modules_init_112_globalize_free();
	cnst_init_137_globalize_free();
	imported_modules_init_94_globalize_free();
	method_init_76_globalize_free();
	toplevel_init_63_globalize_free();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_globalize_free()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70___object(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70___reader(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "GLOBALIZE_FREE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_globalize_free()
{
   {
      obj_t cnst_port_138_2156;
      cnst_port_138_2156 = open_input_string(string1967_globalize_free);
      {
	 long i_2157;
	 i_2157 = ((long) 5);
       loop_2158:
	 {
	    bool_t test1968_2159;
	    test1968_2159 = (i_2157 == ((long) -1));
	    if (test1968_2159)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1970_2160;
		    {
		       obj_t list1971_2161;
		       {
			  obj_t arg1972_2162;
			  arg1972_2162 = BNIL;
			  list1971_2161 = MAKE_PAIR(cnst_port_138_2156, arg1972_2162);
		       }
		       arg1970_2160 = read___reader(list1971_2161);
		    }
		    CNST_TABLE_SET(i_2157, arg1970_2160);
		 }
		 {
		    int aux_2163;
		    {
		       long aux_2184;
		       aux_2184 = (i_2157 - ((long) 1));
		       aux_2163 = (int) (aux_2184);
		    }
		    {
		       long i_2187;
		       i_2187 = (long) (aux_2163);
		       i_2157 = i_2187;
		       goto loop_2158;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_globalize_free()
{
   _round__57_globalize_free = ((long) 0);
   _integrator__235_globalize_free = BUNSPEC;
   return BUNSPEC;
}


/* mark-variable! */ obj_t 
mark_variable__104_globalize_free(local_t local_1)
{
   {
      value_t info_1050;
      info_1050 = (((local_t) CREF(local_1))->value);
      {
	 bool_t test1616_1051;
	 test1616_1051 = is_a__118___object((obj_t) (info_1050), svar_ginfo_131_globalize_ginfo);
	 if (test1616_1051)
	   {
	      {
		 svar_ginfo_131_t obj_1754;
		 long val1502_1755;
		 obj_1754 = (svar_ginfo_131_t) (info_1050);
		 val1502_1755 = _round__57_globalize_free;
		 {
		    obj_t aux_2194;
		    {
		       object_t aux_2195;
		       aux_2195 = (object_t) (obj_1754);
		       aux_2194 = OBJECT_WIDENING(aux_2195);
		    }
		    return ((((svar_ginfo_131_t) CREF(aux_2194))->free_mark_81) = ((long) val1502_1755), BUNSPEC);
		 }
	      }
	   }
	 else
	   {
	      bool_t test1617_1052;
	      test1617_1052 = is_a__118___object((obj_t) (info_1050), sfun_ginfo_98_globalize_ginfo);
	      if (test1617_1052)
		{
		   {
		      sfun_ginfo_98_t obj_1757;
		      obj_t val1483_1758;
		      obj_1757 = (sfun_ginfo_98_t) (info_1050);
		      val1483_1758 = BINT(_round__57_globalize_free);
		      {
			 obj_t aux_2204;
			 {
			    object_t aux_2205;
			    aux_2205 = (object_t) (obj_1757);
			    aux_2204 = OBJECT_WIDENING(aux_2205);
			 }
			 return ((((sfun_ginfo_98_t) CREF(aux_2204))->free_mark_81) = ((obj_t) val1483_1758), BUNSPEC);
		      }
		   }
		}
	      else
		{
		   bool_t test1618_1053;
		   test1618_1053 = is_a__118___object((obj_t) (info_1050), sexit_ginfo_81_globalize_ginfo);
		   if (test1618_1053)
		     {
			{
			   sexit_ginfo_81_t obj_1760;
			   long val1518_1761;
			   obj_1760 = (sexit_ginfo_81_t) (info_1050);
			   val1518_1761 = _round__57_globalize_free;
			   {
			      obj_t aux_2213;
			      {
				 object_t aux_2214;
				 aux_2214 = (object_t) (obj_1760);
				 aux_2213 = OBJECT_WIDENING(aux_2214);
			      }
			      return ((((sexit_ginfo_81_t) CREF(aux_2213))->free_mark_81) = ((long) val1518_1761), BUNSPEC);
			   }
			}
		     }
		   else
		     {
			return BFALSE;
		     }
		}
	   }
      }
   }
}


/* bind-variable! */ obj_t 
bind_variable__14_globalize_free(local_t local_2, local_t integrator_3)
{
   {
      value_t finfo_1054;
      finfo_1054 = (((local_t) CREF(integrator_3))->value);
      {
	 obj_t arg1620_1055;
	 {
	    obj_t aux_2221;
	    obj_t aux_2219;
	    {
	       sfun_ginfo_98_t obj_1763;
	       obj_1763 = (sfun_ginfo_98_t) (finfo_1054);
	       {
		  obj_t aux_2223;
		  {
		     object_t aux_2224;
		     aux_2224 = (object_t) (obj_1763);
		     aux_2223 = OBJECT_WIDENING(aux_2224);
		  }
		  aux_2221 = (((sfun_ginfo_98_t) CREF(aux_2223))->bound);
	       }
	    }
	    aux_2219 = (obj_t) (local_2);
	    arg1620_1055 = MAKE_PAIR(aux_2219, aux_2221);
	 }
	 {
	    sfun_ginfo_98_t obj_1766;
	    obj_1766 = (sfun_ginfo_98_t) (finfo_1054);
	    {
	       obj_t aux_2230;
	       {
		  object_t aux_2231;
		  aux_2231 = (object_t) (obj_1766);
		  aux_2230 = OBJECT_WIDENING(aux_2231);
	       }
	       ((((sfun_ginfo_98_t) CREF(aux_2230))->bound) = ((obj_t) arg1620_1055), BUNSPEC);
	    }
	 }
      }
      return mark_variable__104_globalize_free(local_2);
   }
}


/* free-variable? */ obj_t 
free_variable__181_globalize_free(obj_t local_4)
{
   {
      value_t info_1057;
      {
	 local_t obj_1768;
	 obj_1768 = (local_t) (local_4);
	 info_1057 = (((local_t) CREF(obj_1768))->value);
      }
      {
	 bool_t test1622_1058;
	 test1622_1058 = is_a__118___object((obj_t) (info_1057), svar_ginfo_131_globalize_ginfo);
	 if (test1622_1058)
	   {
	      {
		 bool_t test1623_1059;
		 {
		    obj_t obj1_1771;
		    obj_t obj2_1772;
		    {
		       long aux_2241;
		       {
			  svar_ginfo_131_t obj_1770;
			  obj_1770 = (svar_ginfo_131_t) (info_1057);
			  {
			     obj_t aux_2243;
			     {
				object_t aux_2244;
				aux_2244 = (object_t) (obj_1770);
				aux_2243 = OBJECT_WIDENING(aux_2244);
			     }
			     aux_2241 = (((svar_ginfo_131_t) CREF(aux_2243))->free_mark_81);
			  }
		       }
		       obj1_1771 = BINT(aux_2241);
		    }
		    obj2_1772 = BINT(_round__57_globalize_free);
		    test1623_1059 = (obj1_1771 == obj2_1772);
		 }
		 if (test1623_1059)
		   {
		      return BFALSE;
		   }
		 else
		   {
		      return BTRUE;
		   }
	      }
	   }
	 else
	   {
	      bool_t test1625_1061;
	      test1625_1061 = is_a__118___object((obj_t) (info_1057), sfun_ginfo_98_globalize_ginfo);
	      if (test1625_1061)
		{
		   {
		      bool_t test1626_1062;
		      {
			 obj_t arg1627_1063;
			 {
			    sfun_ginfo_98_t obj_1774;
			    obj_1774 = (sfun_ginfo_98_t) (info_1057);
			    {
			       obj_t aux_2256;
			       {
				  object_t aux_2257;
				  aux_2257 = (object_t) (obj_1774);
				  aux_2256 = OBJECT_WIDENING(aux_2257);
			       }
			       arg1627_1063 = (((sfun_ginfo_98_t) CREF(aux_2256))->free_mark_81);
			    }
			 }
			 {
			    obj_t obj2_1776;
			    obj2_1776 = BINT(_round__57_globalize_free);
			    test1626_1062 = (arg1627_1063 == obj2_1776);
			 }
		      }
		      if (test1626_1062)
			{
			   return BFALSE;
			}
		      else
			{
			   return BTRUE;
			}
		   }
		}
	      else
		{
		   bool_t test1628_1064;
		   test1628_1064 = is_a__118___object((obj_t) (info_1057), sexit_ginfo_81_globalize_ginfo);
		   if (test1628_1064)
		     {
			{
			   bool_t test1629_1065;
			   {
			      obj_t obj1_1779;
			      obj_t obj2_1780;
			      {
				 long aux_2267;
				 {
				    sexit_ginfo_81_t obj_1778;
				    obj_1778 = (sexit_ginfo_81_t) (info_1057);
				    {
				       obj_t aux_2269;
				       {
					  object_t aux_2270;
					  aux_2270 = (object_t) (obj_1778);
					  aux_2269 = OBJECT_WIDENING(aux_2270);
				       }
				       aux_2267 = (((sexit_ginfo_81_t) CREF(aux_2269))->free_mark_81);
				    }
				 }
				 obj1_1779 = BINT(aux_2267);
			      }
			      obj2_1780 = BINT(_round__57_globalize_free);
			      test1629_1065 = (obj1_1779 == obj2_1780);
			   }
			   if (test1629_1065)
			     {
				return BFALSE;
			     }
			   else
			     {
				return BTRUE;
			     }
			}
		     }
		   else
		     {
			{
			   obj_t arg1634_1069;
			   {
			      obj_t arg1636_1070;
			      arg1636_1070 = shape_tools_shape(local_4);
			      arg1634_1069 = MAKE_PAIR(local_4, arg1636_1070);
			   }
			   FAILURE(string1965_globalize_free, string1966_globalize_free, arg1634_1069);
			}
		     }
		}
	   }
      }
   }
}


/* get-free-vars */ obj_t 
get_free_vars_244_globalize_free(node_t node_5, local_t integrator_6)
{
   {
      obj_t free_1071;
      {
	 sfun_ginfo_98_t obj_1787;
	 {
	    value_t aux_2281;
	    aux_2281 = (((local_t) CREF(integrator_6))->value);
	    obj_1787 = (sfun_ginfo_98_t) (aux_2281);
	 }
	 {
	    obj_t aux_2284;
	    {
	       object_t aux_2285;
	       aux_2285 = (object_t) (obj_1787);
	       aux_2284 = OBJECT_WIDENING(aux_2285);
	    }
	    free_1071 = (((sfun_ginfo_98_t) CREF(aux_2284))->free);
	 }
      }
      {
	 bool_t test_2289;
	 if (NULLP(free_1071))
	   {
	      test_2289 = ((bool_t) 1);
	   }
	 else
	   {
	      test_2289 = PAIRP(free_1071);
	   }
	 if (test_2289)
	   {
	      return free_1071;
	   }
	 else
	   {
	      obj_t free_1073;
	      free_1073 = internal_get_free_vars__185_globalize_free(node_5, integrator_6);
	      {
		 sfun_ginfo_98_t obj_1791;
		 {
		    value_t aux_2294;
		    aux_2294 = (((local_t) CREF(integrator_6))->value);
		    obj_1791 = (sfun_ginfo_98_t) (aux_2294);
		 }
		 {
		    obj_t aux_2297;
		    {
		       object_t aux_2298;
		       aux_2298 = (object_t) (obj_1791);
		       aux_2297 = OBJECT_WIDENING(aux_2298);
		    }
		    ((((sfun_ginfo_98_t) CREF(aux_2297))->free) = ((obj_t) free_1073), BUNSPEC);
		 }
	      }
	      return free_1073;
	   }
      }
   }
}


/* _get-free-vars1960 */ obj_t 
_get_free_vars1960_254_globalize_free(obj_t env_2138, obj_t node_2139, obj_t integrator_2140)
{
   return get_free_vars_244_globalize_free((node_t) (node_2139), (local_t) (integrator_2140));
}


/* internal-get-free-vars! */ obj_t 
internal_get_free_vars__185_globalize_free(node_t node_7, local_t integrator_8)
{
   {
      long z1_1793;
      z1_1793 = _round__57_globalize_free;
      _round__57_globalize_free = (z1_1793 + ((long) 1));
   }
   _integrator__235_globalize_free = (obj_t) (integrator_8);
   bind_variable__14_globalize_free(integrator_8, integrator_8);
   {
      obj_t arg1641_1077;
      {
	 variable_t variable_1795;
	 obj_t loc_1796;
	 variable_1795 = (variable_t) (integrator_8);
	 loc_1796 = BFALSE;
	 {
	    bool_t test1655_1797;
	    test1655_1797 = is_a__118___object((obj_t) (variable_1795), global_ast_var);
	    if (test1655_1797)
	      {
		 arg1641_1077 = the_global_closure_233_globalize_free((global_t) (variable_1795), loc_1796);
	      }
	    else
	      {
		 arg1641_1077 = the_local_closure_213_globalize_free((obj_t) (variable_1795), loc_1796);
	      }
	 }
      }
      bind_variable__14_globalize_free((local_t) (arg1641_1077), integrator_8);
   }
   {
      obj_t l1557_1078;
      {
	 sfun_t obj_1800;
	 {
	    value_t aux_2327;
	    aux_2327 = (((local_t) CREF(integrator_8))->value);
	    obj_1800 = (sfun_t) (aux_2327);
	 }
	 l1557_1078 = (((sfun_t) CREF(obj_1800))->args);
      }
    lname1558_1079:
      if (PAIRP(l1557_1078))
	{
	   {
	      local_t aux_2320;
	      {
		 obj_t aux_2321;
		 aux_2321 = CAR(l1557_1078);
		 aux_2320 = (local_t) (aux_2321);
	      }
	      bind_variable__14_globalize_free(aux_2320, integrator_8);
	   }
	   {
	      obj_t l1557_2325;
	      l1557_2325 = CDR(l1557_1078);
	      l1557_1078 = l1557_2325;
	      goto lname1558_1079;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   return node_free_158_globalize_free(node_7, BNIL);
}


/* node-free* */ obj_t 
node_free__199_globalize_free(obj_t node__221_51, obj_t free_52)
{
   {
      obj_t node__221_1086;
      obj_t free_1087;
      node__221_1086 = node__221_51;
      free_1087 = free_52;
    loop_1088:
      if (NULLP(node__221_1086))
	{
	   return free_1087;
	}
      else
	{
	   obj_t arg1652_1090;
	   obj_t arg1653_1091;
	   arg1652_1090 = CDR(node__221_1086);
	   {
	      node_t aux_2335;
	      {
		 obj_t aux_2336;
		 aux_2336 = CAR(node__221_1086);
		 aux_2335 = (node_t) (aux_2336);
	      }
	      arg1653_1091 = node_free_158_globalize_free(aux_2335, free_1087);
	   }
	   {
	      obj_t free_2341;
	      obj_t node__221_2340;
	      node__221_2340 = arg1652_1090;
	      free_2341 = arg1653_1091;
	      free_1087 = free_2341;
	      node__221_1086 = node__221_2340;
	      goto loop_1088;
	   }
	}
   }
}


/* the-closure */ obj_t 
the_closure_238_globalize_free(variable_t variable_53, obj_t loc_54)
{
   {
      bool_t test1655_1807;
      test1655_1807 = is_a__118___object((obj_t) (variable_53), global_ast_var);
      if (test1655_1807)
	{
	   return the_global_closure_233_globalize_free((global_t) (variable_53), loc_54);
	}
      else
	{
	   return the_local_closure_213_globalize_free((obj_t) (variable_53), loc_54);
	}
   }
}


/* _the-closure1961 */ obj_t 
_the_closure1961_10_globalize_free(obj_t env_2141, obj_t variable_2142, obj_t loc_2143)
{
   return the_closure_238_globalize_free((variable_t) (variable_2142), loc_2143);
}


/* the-global-closure */ obj_t 
the_global_closure_233_globalize_free(global_t global_55, obj_t loc_56)
{
   {
      obj_t closure_1094;
      {
	 fun_t obj_1810;
	 {
	    value_t aux_2351;
	    aux_2351 = (((global_t) CREF(global_55))->value);
	    obj_1810 = (fun_t) (aux_2351);
	 }
	 closure_1094 = (((fun_t) CREF(obj_1810))->the_closure_238);
      }
      {
	 bool_t test1656_1095;
	 test1656_1095 = is_a__118___object(closure_1094, global_ast_var);
	 if (test1656_1095)
	   {
	      return closure_1094;
	   }
	 else
	   {
	      global_t gloclo_1096;
	      gloclo_1096 = make_global_closure_44_globalize_global_closure_246(global_55);
	      {
		 long arity_1097;
		 {
		    fun_t obj_1813;
		    {
		       value_t aux_2358;
		       aux_2358 = (((global_t) CREF(global_55))->value);
		       obj_1813 = (fun_t) (aux_2358);
		    }
		    arity_1097 = (((fun_t) CREF(obj_1813))->arity);
		 }
		 {
		    obj_t make_clo_34_1098;
		    if ((arity_1097 < ((long) 0)))
		      {
			 make_clo_34_1098 = CNST_TABLE_REF(((long) 0));
		      }
		    else
		      {
			 make_clo_34_1098 = CNST_TABLE_REF(((long) 1));
		      }
		    {
		       node_t node_1099;
		       {
			  obj_t arg1677_1118;
			  obj_t arg1679_1120;
			  {
			     var_t arg1680_1121;
			     atom_t arg1681_1122;
			     atom_t arg1682_1123;
			     {
				obj_t arg1692_1131;
				arg1692_1131 = ____74_type_cache;
				{
				   var_t res1954_1826;
				   {
				      type_t type_1817;
				      variable_t variable_1818;
				      type_1817 = (type_t) (arg1692_1131);
				      variable_1818 = (variable_t) (gloclo_1096);
				      {
					 var_t new1211_1819;
					 new1211_1819 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					 {
					    long arg1808_1820;
					    arg1808_1820 = class_num_218___object(var_ast_node);
					    {
					       obj_t obj_1824;
					       obj_1824 = (obj_t) (new1211_1819);
					       (((obj_t) CREF(obj_1824))->header = MAKE_HEADER(arg1808_1820, 0), BUNSPEC);
					    }
					 }
					 {
					    object_t aux_2372;
					    aux_2372 = (object_t) (new1211_1819);
					    OBJECT_WIDENING_SET(aux_2372, BFALSE);
					 }
					 ((((var_t) CREF(new1211_1819))->loc) = ((obj_t) loc_56), BUNSPEC);
					 ((((var_t) CREF(new1211_1819))->type) = ((type_t) type_1817), BUNSPEC);
					 ((((var_t) CREF(new1211_1819))->variable) = ((variable_t) variable_1818), BUNSPEC);
					 res1954_1826 = new1211_1819;
				      }
				   }
				   arg1680_1121 = res1954_1826;
				}
			     }
			     {
				obj_t arg1695_1134;
				arg1695_1134 = ____74_type_cache;
				{
				   atom_t res1955_1837;
				   {
				      type_t type_1828;
				      obj_t value_1829;
				      type_1828 = (type_t) (arg1695_1134);
				      value_1829 = BINT(arity_1097);
				      {
					 atom_t new1203_1830;
					 new1203_1830 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
					 {
					    long arg1810_1831;
					    arg1810_1831 = class_num_218___object(atom_ast_node);
					    {
					       obj_t obj_1835;
					       obj_1835 = (obj_t) (new1203_1830);
					       (((obj_t) CREF(obj_1835))->header = MAKE_HEADER(arg1810_1831, 0), BUNSPEC);
					    }
					 }
					 {
					    object_t aux_2384;
					    aux_2384 = (object_t) (new1203_1830);
					    OBJECT_WIDENING_SET(aux_2384, BFALSE);
					 }
					 ((((atom_t) CREF(new1203_1830))->loc) = ((obj_t) loc_56), BUNSPEC);
					 ((((atom_t) CREF(new1203_1830))->type) = ((type_t) type_1828), BUNSPEC);
					 ((((atom_t) CREF(new1203_1830))->value) = ((obj_t) value_1829), BUNSPEC);
					 res1955_1837 = new1203_1830;
				      }
				   }
				   arg1681_1122 = res1955_1837;
				}
			     }
			     {
				obj_t arg1699_1137;
				arg1699_1137 = ____74_type_cache;
				{
				   atom_t res1956_1848;
				   {
				      type_t type_1839;
				      obj_t value_1840;
				      type_1839 = (type_t) (arg1699_1137);
				      value_1840 = BINT(((long) 0));
				      {
					 atom_t new1203_1841;
					 new1203_1841 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
					 {
					    long arg1810_1842;
					    arg1810_1842 = class_num_218___object(atom_ast_node);
					    {
					       obj_t obj_1846;
					       obj_1846 = (obj_t) (new1203_1841);
					       (((obj_t) CREF(obj_1846))->header = MAKE_HEADER(arg1810_1842, 0), BUNSPEC);
					    }
					 }
					 {
					    object_t aux_2396;
					    aux_2396 = (object_t) (new1203_1841);
					    OBJECT_WIDENING_SET(aux_2396, BFALSE);
					 }
					 ((((atom_t) CREF(new1203_1841))->loc) = ((obj_t) loc_56), BUNSPEC);
					 ((((atom_t) CREF(new1203_1841))->type) = ((type_t) type_1839), BUNSPEC);
					 ((((atom_t) CREF(new1203_1841))->value) = ((obj_t) value_1840), BUNSPEC);
					 res1956_1848 = new1203_1841;
				      }
				   }
				   arg1682_1123 = res1956_1848;
				}
			     }
			     {
				obj_t list1684_1125;
				{
				   obj_t arg1685_1126;
				   {
				      obj_t arg1686_1127;
				      {
					 obj_t arg1688_1128;
					 arg1688_1128 = MAKE_PAIR(BNIL, BNIL);
					 {
					    obj_t aux_2403;
					    aux_2403 = (obj_t) (arg1682_1123);
					    arg1686_1127 = MAKE_PAIR(aux_2403, arg1688_1128);
					 }
				      }
				      {
					 obj_t aux_2406;
					 aux_2406 = (obj_t) (arg1681_1122);
					 arg1685_1126 = MAKE_PAIR(aux_2406, arg1686_1127);
				      }
				   }
				   {
				      obj_t aux_2409;
				      aux_2409 = (obj_t) (arg1680_1121);
				      list1684_1125 = MAKE_PAIR(aux_2409, arg1685_1126);
				   }
				}
				arg1677_1118 = cons__138___r4_pairs_and_lists_6_3(make_clo_34_1098, list1684_1125);
			     }
			  }
			  arg1679_1120 = CNST_TABLE_REF(((long) 2));
			  node_1099 = sexp__node_235_ast_sexp(arg1677_1118, BNIL, loc_56, arg1679_1120);
		       }
		       {
			  global_t closure_1100;
			  {
			     obj_t arg1661_1104;
			     obj_t arg1663_1105;
			     obj_t arg1665_1106;
			     {
				obj_t arg1666_1107;
				arg1666_1107 = (((global_t) CREF(global_55))->id);
				{
				   obj_t list1668_1109;
				   {
				      obj_t arg1669_1110;
				      {
					 obj_t aux_2416;
					 aux_2416 = CNST_TABLE_REF(((long) 3));
					 arg1669_1110 = MAKE_PAIR(aux_2416, BNIL);
				      }
				      list1668_1109 = MAKE_PAIR(arg1666_1107, arg1669_1110);
				   }
				   arg1661_1104 = symbol_append_197___r4_symbols_6_4(list1668_1109);
				}
			     }
			     arg1663_1105 = (((global_t) CREF(global_55))->module);
			     {
				bool_t test1671_1112;
				{
				   obj_t aux_2422;
				   {
				      value_t aux_2423;
				      aux_2423 = (((global_t) CREF(global_55))->value);
				      aux_2422 = (obj_t) (aux_2423);
				   }
				   test1671_1112 = is_a__118___object(aux_2422, sfun_ast_var);
				}
				if (test1671_1112)
				  {
				     bool_t test_2428;
				     {
					obj_t aux_2434;
					obj_t aux_2429;
					aux_2434 = CNST_TABLE_REF(((long) 4));
					{
					   sfun_t obj_1854;
					   {
					      value_t aux_2430;
					      aux_2430 = (((global_t) CREF(global_55))->value);
					      obj_1854 = (sfun_t) (aux_2430);
					   }
					   aux_2429 = (((sfun_t) CREF(obj_1854))->class);
					}
					test_2428 = (aux_2429 == aux_2434);
				     }
				     if (test_2428)
				       {
					  arg1665_1106 = CNST_TABLE_REF(((long) 4));
				       }
				     else
				       {
					  arg1665_1106 = CNST_TABLE_REF(((long) 5));
				       }
				  }
				else
				  {
				     arg1665_1106 = CNST_TABLE_REF(((long) 5));
				  }
			     }
			     closure_1100 = def_global_scnst__93_ast_glo_def_117(arg1661_1104, arg1663_1105, (obj_t) (node_1099), arg1665_1106);
			  }
			  {
			     {
				obj_t arg1657_1101;
				arg1657_1101 = (((global_t) CREF(global_55))->import);
				((((global_t) CREF(closure_1100))->import) = ((obj_t) arg1657_1101), BUNSPEC);
			     }
			     {
				fun_t obj_1861;
				obj_t val1117_1862;
				{
				   value_t aux_2444;
				   aux_2444 = (((global_t) CREF(global_55))->value);
				   obj_1861 = (fun_t) (aux_2444);
				}
				val1117_1862 = (obj_t) (closure_1100);
				((((fun_t) CREF(obj_1861))->the_closure_238) = ((obj_t) val1117_1862), BUNSPEC);
			     }
			     {
				fun_t obj_1864;
				obj_t val1117_1865;
				{
				   value_t aux_2449;
				   aux_2449 = (((global_t) CREF(gloclo_1096))->value);
				   obj_1864 = (fun_t) (aux_2449);
				}
				val1117_1865 = (obj_t) (closure_1100);
				((((fun_t) CREF(obj_1864))->the_closure_238) = ((obj_t) val1117_1865), BUNSPEC);
			     }
			     return (obj_t) (closure_1100);
			  }
		       }
		    }
		 }
	      }
	   }
      }
   }
}


/* _the-global-closure1962 */ obj_t 
_the_global_closure1962_203_globalize_free(obj_t env_2144, obj_t global_2145, obj_t loc_2146)
{
   return the_global_closure_233_globalize_free((global_t) (global_2145), loc_2146);
}


/* the-local-closure */ obj_t 
the_local_closure_213_globalize_free(obj_t local_57, obj_t loc_58)
{
   {
      value_t info_1142;
      {
	 local_t obj_1866;
	 obj_1866 = (local_t) (local_57);
	 info_1142 = (((local_t) CREF(obj_1866))->value);
      }
      {
	 bool_t test1704_1143;
	 {
	    obj_t aux_2459;
	    {
	       sfun_t obj_1867;
	       obj_1867 = (sfun_t) (info_1142);
	       aux_2459 = (((sfun_t) CREF(obj_1867))->the_closure_238);
	    }
	    test1704_1143 = is_a__118___object(aux_2459, local_ast_var);
	 }
	 if (test1704_1143)
	   {
	      sfun_t obj_1869;
	      obj_1869 = (sfun_t) (info_1142);
	      return (((sfun_t) CREF(obj_1869))->the_closure_238);
	   }
	 else
	   {
	      local_t closure_1144;
	      {
		 obj_t aux_2466;
		 {
		    local_t obj_1870;
		    obj_1870 = (local_t) (local_57);
		    aux_2466 = (((local_t) CREF(obj_1870))->id);
		 }
		 closure_1144 = make_local_svar_140_ast_local(aux_2466, (type_t) (_procedure__226_type_cache));
	      }
	      {
		 bool_t arg1705_1145;
		 {
		    local_t obj_1871;
		    obj_1871 = (local_t) (local_57);
		    arg1705_1145 = (((local_t) CREF(obj_1871))->user__32);
		 }
		 ((((local_t) CREF(closure_1144))->user__32) = ((bool_t) arg1705_1145), BUNSPEC);
	      }
	      {
		 svar_ginfo_131_t obj1585_1146;
		 obj1585_1146 = ((svar_ginfo_131_t) ((((local_t) CREF(closure_1144))->value)));
		 {
		    svar_ginfo_131_t arg1706_1147;
		    {
		       svar_ginfo_131_t res1957_1884;
		       {
			  svar_ginfo_131_t new1492_1879;
			  new1492_1879 = ((svar_ginfo_131_t) BREF(GC_MALLOC(sizeof(struct svar_ginfo_131))));
			  ((((svar_ginfo_131_t) CREF(new1492_1879))->kaptured__204) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  ((((svar_ginfo_131_t) CREF(new1492_1879))->free_mark_81) = ((long) ((long) -10)), BUNSPEC);
			  ((((svar_ginfo_131_t) CREF(new1492_1879))->mark) = ((long) ((long) -10)), BUNSPEC);
			  ((((svar_ginfo_131_t) CREF(new1492_1879))->celled__113) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  res1957_1884 = new1492_1879;
		       }
		       arg1706_1147 = res1957_1884;
		    }
		    {
		       obj_t aux_2483;
		       object_t aux_2481;
		       aux_2483 = (obj_t) (arg1706_1147);
		       aux_2481 = (object_t) (obj1585_1146);
		       OBJECT_WIDENING_SET(aux_2481, aux_2483);
		    }
		 }
		 {
		    long arg1707_1148;
		    arg1707_1148 = class_num_218___object(svar_ginfo_131_globalize_ginfo);
		    {
		       obj_t obj_1885;
		       obj_1885 = (obj_t) (obj1585_1146);
		       (((obj_t) CREF(obj_1885))->header = MAKE_HEADER(arg1707_1148, 0), BUNSPEC);
		    }
		 }
		 obj1585_1146;
	      }
	      {
		 local_ginfo_108_t obj1586_1149;
		 obj1586_1149 = ((local_ginfo_108_t) (closure_1144));
		 {
		    local_ginfo_108_t arg1708_1150;
		    {
		       local_ginfo_108_t res1958_1890;
		       {
			  local_ginfo_108_t new1521_1888;
			  new1521_1888 = ((local_ginfo_108_t) BREF(GC_MALLOC(sizeof(struct local_ginfo_108))));
			  ((((local_ginfo_108_t) CREF(new1521_1888))->escape__117) = ((bool_t) ((bool_t) 0)), BUNSPEC);
			  res1958_1890 = new1521_1888;
		       }
		       arg1708_1150 = res1958_1890;
		    }
		    {
		       obj_t aux_2494;
		       object_t aux_2492;
		       aux_2494 = (obj_t) (arg1708_1150);
		       aux_2492 = (object_t) (obj1586_1149);
		       OBJECT_WIDENING_SET(aux_2492, aux_2494);
		    }
		 }
		 {
		    long arg1709_1151;
		    arg1709_1151 = class_num_218___object(local_ginfo_108_globalize_ginfo);
		    {
		       obj_t obj_1891;
		       obj_1891 = (obj_t) (obj1586_1149);
		       (((obj_t) CREF(obj_1891))->header = MAKE_HEADER(arg1709_1151, 0), BUNSPEC);
		    }
		 }
		 obj1586_1149;
	      }
	      {
		 sfun_t obj_1893;
		 obj_t val1466_1894;
		 obj_1893 = (sfun_t) (info_1142);
		 val1466_1894 = (obj_t) (closure_1144);
		 ((((sfun_t) CREF(obj_1893))->the_closure_238) = ((obj_t) val1466_1894), BUNSPEC);
	      }
	      return (obj_t) (closure_1144);
	   }
      }
   }
}


/* free-from */ obj_t 
free_from_222_globalize_free(obj_t sets_59, local_t integrator_60)
{
   {
      long z1_1895;
      z1_1895 = _round__57_globalize_free;
      _round__57_globalize_free = (z1_1895 + ((long) 1));
   }
   {
      obj_t l1587_1155;
      {
	 sfun_ginfo_98_t obj_1898;
	 {
	    value_t aux_2514;
	    aux_2514 = (((local_t) CREF(integrator_60))->value);
	    obj_1898 = (sfun_ginfo_98_t) (aux_2514);
	 }
	 {
	    obj_t aux_2517;
	    {
	       object_t aux_2518;
	       aux_2518 = (object_t) (obj_1898);
	       aux_2517 = OBJECT_WIDENING(aux_2518);
	    }
	    l1587_1155 = (((sfun_ginfo_98_t) CREF(aux_2517))->bound);
	 }
      }
    lname1588_1156:
      if (PAIRP(l1587_1155))
	{
	   {
	      local_t aux_2507;
	      {
		 obj_t aux_2508;
		 aux_2508 = CAR(l1587_1155);
		 aux_2507 = (local_t) (aux_2508);
	      }
	      mark_variable__104_globalize_free(aux_2507);
	   }
	   {
	      obj_t l1587_2512;
	      l1587_2512 = CDR(l1587_1155);
	      l1587_1155 = l1587_2512;
	      goto lname1588_1156;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   if (NULLP(sets_59))
     {
	return BNIL;
     }
   else
     {
	obj_t head1591_1163;
	head1591_1163 = MAKE_PAIR(BNIL, BNIL);
	{
	   obj_t l1589_1164;
	   obj_t tail1592_1165;
	   l1589_1164 = sets_59;
	   tail1592_1165 = head1591_1163;
	 lname1590_1166:
	   if (NULLP(l1589_1164))
	     {
		return CDR(head1591_1163);
	     }
	   else
	     {
		obj_t newtail1593_1168;
		{
		   obj_t arg1721_1170;
		   {
		      obj_t set_1173;
		      obj_t res_1174;
		      set_1173 = CAR(l1589_1164);
		      res_1174 = BNIL;
		    loop_1175:
		      if (NULLP(set_1173))
			{
			   arg1721_1170 = res_1174;
			}
		      else
			{
			   bool_t test1725_1178;
			   {
			      obj_t aux_2530;
			      aux_2530 = free_variable__181_globalize_free(CAR(set_1173));
			      test1725_1178 = CBOOL(aux_2530);
			   }
			   if (test1725_1178)
			     {
				{
				   obj_t arg1726_1179;
				   obj_t arg1727_1180;
				   arg1726_1179 = CDR(set_1173);
				   {
				      obj_t aux_2536;
				      aux_2536 = CAR(set_1173);
				      arg1727_1180 = MAKE_PAIR(aux_2536, res_1174);
				   }
				   {
				      obj_t res_2540;
				      obj_t set_2539;
				      set_2539 = arg1726_1179;
				      res_2540 = arg1727_1180;
				      res_1174 = res_2540;
				      set_1173 = set_2539;
				      goto loop_1175;
				   }
				}
			     }
			   else
			     {
				{
				   obj_t set_2541;
				   set_2541 = CDR(set_1173);
				   set_1173 = set_2541;
				   goto loop_1175;
				}
			     }
			}
		   }
		   newtail1593_1168 = MAKE_PAIR(arg1721_1170, BNIL);
		}
		SET_CDR(tail1592_1165, newtail1593_1168);
		{
		   obj_t tail1592_2548;
		   obj_t l1589_2546;
		   l1589_2546 = CDR(l1589_1164);
		   tail1592_2548 = newtail1593_1168;
		   tail1592_1165 = tail1592_2548;
		   l1589_1164 = l1589_2546;
		   goto lname1590_1166;
		}
	     }
	}
     }
}


/* _free-from1963 */ obj_t 
_free_from1963_119_globalize_free(obj_t env_2147, obj_t sets_2148, obj_t integrator_2149)
{
   return free_from_222_globalize_free(sets_2148, (local_t) (integrator_2149));
}


/* method-init */ obj_t 
method_init_76_globalize_free()
{
   add_generic__110___object(node_free_env_48_globalize_free, node_free_default1594_env_72_globalize_free);
   add_inlined_method__244___object(node_free_env_48_globalize_free, var_ast_node, ((long) 0));
   add_inlined_method__244___object(node_free_env_48_globalize_free, closure_ast_node, ((long) 1));
   add_inlined_method__244___object(node_free_env_48_globalize_free, sequence_ast_node, ((long) 2));
   add_inlined_method__244___object(node_free_env_48_globalize_free, app_ast_node, ((long) 3));
   add_inlined_method__244___object(node_free_env_48_globalize_free, app_ly_162_ast_node, ((long) 4));
   add_inlined_method__244___object(node_free_env_48_globalize_free, funcall_ast_node, ((long) 5));
   add_inlined_method__244___object(node_free_env_48_globalize_free, pragma_ast_node, ((long) 6));
   add_inlined_method__244___object(node_free_env_48_globalize_free, cast_ast_node, ((long) 7));
   add_inlined_method__244___object(node_free_env_48_globalize_free, setq_ast_node, ((long) 8));
   add_inlined_method__244___object(node_free_env_48_globalize_free, conditional_ast_node, ((long) 9));
   add_inlined_method__244___object(node_free_env_48_globalize_free, fail_ast_node, ((long) 10));
   add_inlined_method__244___object(node_free_env_48_globalize_free, select_ast_node, ((long) 11));
   add_inlined_method__244___object(node_free_env_48_globalize_free, let_fun_218_ast_node, ((long) 12));
   add_inlined_method__244___object(node_free_env_48_globalize_free, let_var_6_ast_node, ((long) 13));
   add_inlined_method__244___object(node_free_env_48_globalize_free, set_ex_it_116_ast_node, ((long) 14));
   add_inlined_method__244___object(node_free_env_48_globalize_free, jump_ex_it_184_ast_node, ((long) 15));
   add_inlined_method__244___object(node_free_env_48_globalize_free, make_box_202_ast_node, ((long) 16));
   add_inlined_method__244___object(node_free_env_48_globalize_free, box_ref_242_ast_node, ((long) 17));
   {
      long aux_2570;
      aux_2570 = add_inlined_method__244___object(node_free_env_48_globalize_free, box_set__221_ast_node, ((long) 18));
      return BINT(aux_2570);
   }
}


/* node-free */ obj_t 
node_free_158_globalize_free(node_t node_9, obj_t free_10)
{
 node_free_158_globalize_free:
   {
      obj_t method1845_1579;
      obj_t class1850_1580;
      {
	 obj_t arg1853_1577;
	 obj_t arg1856_1578;
	 {
	    object_t obj_2028;
	    obj_2028 = (object_t) (node_9);
	    {
	       obj_t pre_method_105_2029;
	       pre_method_105_2029 = PROCEDURE_REF(node_free_env_48_globalize_free, ((long) 2));
	       if (INTEGERP(pre_method_105_2029))
		 {
		    PROCEDURE_SET(node_free_env_48_globalize_free, ((long) 2), BUNSPEC);
		    arg1853_1577 = pre_method_105_2029;
		 }
	       else
		 {
		    long obj_class_num_177_2034;
		    obj_class_num_177_2034 = TYPE(obj_2028);
		    {
		       obj_t arg1177_2035;
		       arg1177_2035 = PROCEDURE_REF(node_free_env_48_globalize_free, ((long) 1));
		       {
			  long arg1178_2039;
			  {
			     long arg1179_2040;
			     arg1179_2040 = OBJECT_TYPE;
			     arg1178_2039 = (obj_class_num_177_2034 - arg1179_2040);
			  }
			  arg1853_1577 = VECTOR_REF(arg1177_2035, arg1178_2039);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_2045;
	    object_2045 = (object_t) (node_9);
	    {
	       long arg1180_2046;
	       {
		  long arg1181_2047;
		  long arg1182_2048;
		  arg1181_2047 = TYPE(object_2045);
		  arg1182_2048 = OBJECT_TYPE;
		  arg1180_2046 = (arg1181_2047 - arg1182_2048);
	       }
	       {
		  obj_t vector_2052;
		  vector_2052 = _classes__134___object;
		  arg1856_1578 = VECTOR_REF(vector_2052, arg1180_2046);
	       }
	    }
	 }
	 method1845_1579 = arg1853_1577;
	 class1850_1580 = arg1856_1578;
	 {
	    if (INTEGERP(method1845_1579))
	      {
		 switch ((long) CINT(method1845_1579))
		   {
		   case ((long) 0):
		      {
			 var_t node_1586;
			 node_1586 = (var_t) (node_9);
			 {
			    bool_t test1859_1589;
			    {
			       obj_t aux_2591;
			       {
				  variable_t aux_2592;
				  aux_2592 = (((var_t) CREF(node_1586))->variable);
				  aux_2591 = (obj_t) (aux_2592);
			       }
			       test1859_1589 = is_a__118___object(aux_2591, global_ast_var);
			    }
			    if (test1859_1589)
			      {
				 return free_10;
			      }
			    else
			      {
				 bool_t test1860_1590;
				 {
				    obj_t aux_2597;
				    {
				       obj_t aux_2598;
				       {
					  variable_t aux_2599;
					  aux_2599 = (((var_t) CREF(node_1586))->variable);
					  aux_2598 = (obj_t) (aux_2599);
				       }
				       aux_2597 = free_variable__181_globalize_free(aux_2598);
				    }
				    test1860_1590 = CBOOL(aux_2597);
				 }
				 if (test1860_1590)
				   {
				      {
					 local_t aux_2605;
					 {
					    variable_t aux_2606;
					    aux_2606 = (((var_t) CREF(node_1586))->variable);
					    aux_2605 = (local_t) (aux_2606);
					 }
					 mark_variable__104_globalize_free(aux_2605);
				      }
				      {
					 obj_t aux_2610;
					 {
					    variable_t aux_2611;
					    aux_2611 = (((var_t) CREF(node_1586))->variable);
					    aux_2610 = (obj_t) (aux_2611);
					 }
					 return MAKE_PAIR(aux_2610, free_10);
				      }
				   }
				 else
				   {
				      return free_10;
				   }
			      }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 closure_t node_1595;
			 node_1595 = (closure_t) (node_9);
			 {
			    obj_t var_1598;
			    {
			       variable_t arg1867_1601;
			       arg1867_1601 = (((closure_t) CREF(node_1595))->variable);
			       {
				  obj_t loc_2063;
				  loc_2063 = BFALSE;
				  {
				     bool_t test1655_2064;
				     test1655_2064 = is_a__118___object((obj_t) (arg1867_1601), global_ast_var);
				     if (test1655_2064)
				       {
					  var_1598 = the_global_closure_233_globalize_free((global_t) (arg1867_1601), loc_2063);
				       }
				     else
				       {
					  var_1598 = the_local_closure_213_globalize_free((obj_t) (arg1867_1601), loc_2063);
				       }
				  }
			       }
			    }
			    {
			       bool_t test1865_1599;
			       test1865_1599 = is_a__118___object(var_1598, global_ast_var);
			       if (test1865_1599)
				 {
				    return free_10;
				 }
			       else
				 {
				    bool_t test1866_1600;
				    {
				       obj_t aux_2626;
				       aux_2626 = free_variable__181_globalize_free(var_1598);
				       test1866_1600 = CBOOL(aux_2626);
				    }
				    if (test1866_1600)
				      {
					 mark_variable__104_globalize_free((local_t) (var_1598));
					 return MAKE_PAIR(var_1598, free_10);
				      }
				    else
				      {
					 return free_10;
				      }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 sequence_t node_1602;
			 node_1602 = (sequence_t) (node_9);
			 return node_free__199_globalize_free((((sequence_t) CREF(node_1602))->nodes), free_10);
		      }
		      break;
		   case ((long) 3):
		      {
			 app_t node_1606;
			 node_1606 = (app_t) (node_9);
			 {
			    obj_t free_1609;
			    {
			       variable_t var_1611;
			       {
				  var_t arg1877_1617;
				  arg1877_1617 = (((app_t) CREF(node_1606))->fun);
				  var_1611 = (((var_t) CREF(arg1877_1617))->variable);
			       }
			       {
				  bool_t test1870_1612;
				  test1870_1612 = is_a__118___object((obj_t) (var_1611), global_ast_var);
				  if (test1870_1612)
				    {
				       free_1609 = free_10;
				    }
				  else
				    {
				       bool_t test1871_1613;
				       {
					  bool_t test_2642;
					  {
					     local_ginfo_108_t obj_2073;
					     obj_2073 = (local_ginfo_108_t) (var_1611);
					     {
						obj_t aux_2644;
						{
						   object_t aux_2645;
						   aux_2645 = (object_t) (obj_2073);
						   aux_2644 = OBJECT_WIDENING(aux_2645);
						}
						test_2642 = (((local_ginfo_108_t) CREF(aux_2644))->escape__117);
					     }
					  }
					  if (test_2642)
					    {
					       obj_t aux_2649;
					       aux_2649 = free_variable__181_globalize_free((obj_t) (var_1611));
					       test1871_1613 = CBOOL(aux_2649);
					    }
					  else
					    {
					       test1871_1613 = ((bool_t) 0);
					    }
				       }
				       if (test1871_1613)
					 {
					    mark_variable__104_globalize_free((local_t) (var_1611));
					    {
					       obj_t arg1874_1614;
					       {
						  obj_t arg1875_1615;
						  {
						     node_t obj_2074;
						     obj_2074 = (node_t) (node_1606);
						     arg1875_1615 = (((node_t) CREF(obj_2074))->loc);
						  }
						  {
						     bool_t test1655_2077;
						     test1655_2077 = is_a__118___object((obj_t) (var_1611), global_ast_var);
						     if (test1655_2077)
						       {
							  arg1874_1614 = the_global_closure_233_globalize_free((global_t) (var_1611), arg1875_1615);
						       }
						     else
						       {
							  arg1874_1614 = the_local_closure_213_globalize_free((obj_t) (var_1611), arg1875_1615);
						       }
						  }
					       }
					       free_1609 = MAKE_PAIR(arg1874_1614, free_10);
					    }
					 }
				       else
					 {
					    free_1609 = free_10;
					 }
				    }
			       }
			    }
			    return node_free__199_globalize_free((((app_t) CREF(node_1606))->args), free_1609);
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 app_ly_162_t node_1618;
			 node_1618 = (app_ly_162_t) (node_9);
			 {
			    node_t arg1878_1621;
			    obj_t arg1879_1622;
			    arg1878_1621 = (((app_ly_162_t) CREF(node_1618))->fun);
			    arg1879_1622 = node_free_158_globalize_free((((app_ly_162_t) CREF(node_1618))->arg), free_10);
			    {
			       obj_t free_2673;
			       node_t node_2672;
			       node_2672 = arg1878_1621;
			       free_2673 = arg1879_1622;
			       free_10 = free_2673;
			       node_9 = node_2672;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 funcall_t node_1624;
			 node_1624 = (funcall_t) (node_9);
			 {
			    node_t arg1881_1627;
			    obj_t arg1883_1628;
			    arg1881_1627 = (((funcall_t) CREF(node_1624))->fun);
			    arg1883_1628 = node_free__199_globalize_free((((funcall_t) CREF(node_1624))->args), free_10);
			    {
			       obj_t free_2679;
			       node_t node_2678;
			       node_2678 = arg1881_1627;
			       free_2679 = arg1883_1628;
			       free_10 = free_2679;
			       node_9 = node_2678;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 pragma_t node_1630;
			 node_1630 = (pragma_t) (node_9);
			 return node_free__199_globalize_free((((pragma_t) CREF(node_1630))->args), free_10);
		      }
		      break;
		   case ((long) 7):
		      {
			 cast_t node_1634;
			 node_1634 = (cast_t) (node_9);
			 {
			    node_t node_2684;
			    node_2684 = (((cast_t) CREF(node_1634))->arg);
			    node_9 = node_2684;
			    goto node_free_158_globalize_free;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 setq_t node_1638;
			 node_1638 = (setq_t) (node_9);
			 {
			    var_t arg1887_1641;
			    obj_t arg1888_1642;
			    arg1887_1641 = (((setq_t) CREF(node_1638))->var);
			    arg1888_1642 = node_free_158_globalize_free((((setq_t) CREF(node_1638))->value), free_10);
			    {
			       obj_t free_2692;
			       node_t node_2690;
			       node_2690 = (node_t) (arg1887_1641);
			       free_2692 = arg1888_1642;
			       free_10 = free_2692;
			       node_9 = node_2690;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 conditional_t node_1644;
			 node_1644 = (conditional_t) (node_9);
			 {
			    node_t arg1892_1647;
			    obj_t arg1893_1648;
			    arg1892_1647 = (((conditional_t) CREF(node_1644))->test);
			    {
			       node_t arg1894_1649;
			       obj_t arg1895_1650;
			       arg1894_1649 = (((conditional_t) CREF(node_1644))->true);
			       arg1895_1650 = node_free_158_globalize_free((((conditional_t) CREF(node_1644))->false), free_10);
			       arg1893_1648 = node_free_158_globalize_free(arg1894_1649, arg1895_1650);
			    }
			    {
			       obj_t free_2700;
			       node_t node_2699;
			       node_2699 = arg1892_1647;
			       free_2700 = arg1893_1648;
			       free_10 = free_2700;
			       node_9 = node_2699;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 fail_t node_1652;
			 node_1652 = (fail_t) (node_9);
			 {
			    node_t arg1897_1655;
			    obj_t arg1898_1656;
			    arg1897_1655 = (((fail_t) CREF(node_1652))->proc);
			    {
			       node_t arg1899_1657;
			       obj_t arg1900_1658;
			       arg1899_1657 = (((fail_t) CREF(node_1652))->msg);
			       arg1900_1658 = node_free_158_globalize_free((((fail_t) CREF(node_1652))->obj), free_10);
			       arg1898_1656 = node_free_158_globalize_free(arg1899_1657, arg1900_1658);
			    }
			    {
			       obj_t free_2708;
			       node_t node_2707;
			       node_2707 = arg1897_1655;
			       free_2708 = arg1898_1656;
			       free_10 = free_2708;
			       node_9 = node_2707;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 select_t node_1660;
			 node_1660 = (select_t) (node_9);
			 {
			    obj_t clauses_1663;
			    obj_t free_1664;
			    clauses_1663 = (((select_t) CREF(node_1660))->clauses);
			    free_1664 = free_10;
			  loop_1665:
			    if (NULLP(clauses_1663))
			      {
				 obj_t free_2714;
				 node_t node_2712;
				 node_2712 = (((select_t) CREF(node_1660))->test);
				 free_2714 = free_1664;
				 free_10 = free_2714;
				 node_9 = node_2712;
				 goto node_free_158_globalize_free;
			      }
			    else
			      {
				 obj_t arg1906_1669;
				 obj_t arg1907_1670;
				 arg1906_1669 = CDR(clauses_1663);
				 {
				    node_t aux_2716;
				    {
				       obj_t aux_2717;
				       {
					  obj_t aux_2718;
					  aux_2718 = CAR(clauses_1663);
					  aux_2717 = CDR(aux_2718);
				       }
				       aux_2716 = (node_t) (aux_2717);
				    }
				    arg1907_1670 = node_free_158_globalize_free(aux_2716, free_1664);
				 }
				 {
				    obj_t free_2724;
				    obj_t clauses_2723;
				    clauses_2723 = arg1906_1669;
				    free_2724 = arg1907_1670;
				    free_1664 = free_2724;
				    clauses_1663 = clauses_2723;
				    goto loop_1665;
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 let_fun_218_t node_1673;
			 node_1673 = (let_fun_218_t) (node_9);
			 {
			    obj_t l1572_1676;
			    l1572_1676 = (((let_fun_218_t) CREF(node_1673))->locals);
			  lname1573_1677:
			    if (PAIRP(l1572_1676))
			      {
				 {
				    obj_t f_1680;
				    f_1680 = CAR(l1572_1676);
				    bind_variable__14_globalize_free((local_t) (f_1680), (local_t) (_integrator__235_globalize_free));
				    {
				       bool_t test_2733;
				       {
					  local_ginfo_108_t obj_2105;
					  obj_2105 = (local_ginfo_108_t) (f_1680);
					  {
					     obj_t aux_2735;
					     {
						object_t aux_2736;
						aux_2736 = (object_t) (obj_2105);
						aux_2735 = OBJECT_WIDENING(aux_2736);
					     }
					     test_2733 = (((local_ginfo_108_t) CREF(aux_2735))->escape__117);
					  }
				       }
				       if (test_2733)
					 {
					    obj_t arg1914_1682;
					    {
					       obj_t aux_2740;
					       {
						  node_t obj_2106;
						  obj_2106 = (node_t) (node_1673);
						  aux_2740 = (((node_t) CREF(obj_2106))->loc);
					       }
					       arg1914_1682 = the_local_closure_213_globalize_free(f_1680, aux_2740);
					    }
					    bind_variable__14_globalize_free((local_t) (arg1914_1682), (local_t) (_integrator__235_globalize_free));
					 }
				       else
					 {
					    BUNSPEC;
					 }
				    }
				 }
				 {
				    obj_t l1572_2747;
				    l1572_2747 = CDR(l1572_1676);
				    l1572_1676 = l1572_2747;
				    goto lname1573_1677;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t lcls_1685;
			    obj_t free_1686;
			    lcls_1685 = (((let_fun_218_t) CREF(node_1673))->locals);
			    free_1686 = free_10;
			  liip_1687:
			    if (NULLP(lcls_1685))
			      {
				 obj_t free_2754;
				 node_t node_2752;
				 node_2752 = (((let_fun_218_t) CREF(node_1673))->body);
				 free_2754 = free_1686;
				 free_10 = free_2754;
				 node_9 = node_2752;
				 goto node_free_158_globalize_free;
			      }
			    else
			      {
				 value_t fun_1692;
				 {
				    local_t obj_2112;
				    {
				       obj_t aux_2755;
				       aux_2755 = CAR(lcls_1685);
				       obj_2112 = (local_t) (aux_2755);
				    }
				    fun_1692 = (((local_t) CREF(obj_2112))->value);
				 }
				 {
				    {
				       obj_t l1574_1693;
				       {
					  sfun_t obj_2113;
					  obj_2113 = (sfun_t) (fun_1692);
					  l1574_1693 = (((sfun_t) CREF(obj_2113))->args);
				       }
				     lname1575_1694:
				       if (PAIRP(l1574_1693))
					 {
					    {
					       local_t aux_2761;
					       {
						  obj_t aux_2762;
						  aux_2762 = CAR(l1574_1693);
						  aux_2761 = (local_t) (aux_2762);
					       }
					       bind_variable__14_globalize_free(aux_2761, (local_t) (_integrator__235_globalize_free));
					    }
					    {
					       obj_t l1574_2767;
					       l1574_2767 = CDR(l1574_1693);
					       l1574_1693 = l1574_2767;
					       goto lname1575_1694;
					    }
					 }
				       else
					 {
					    ((bool_t) 1);
					 }
				    }
				    {
				       obj_t arg1924_1699;
				       obj_t arg1925_1700;
				       arg1924_1699 = CDR(lcls_1685);
				       {
					  node_t aux_2772;
					  {
					     obj_t aux_2773;
					     {
						sfun_t obj_2118;
						obj_2118 = (sfun_t) (fun_1692);
						aux_2773 = (((sfun_t) CREF(obj_2118))->body);
					     }
					     aux_2772 = (node_t) (aux_2773);
					  }
					  arg1925_1700 = node_free_158_globalize_free(aux_2772, free_1686);
				       }
				       {
					  obj_t free_2779;
					  obj_t lcls_2778;
					  lcls_2778 = arg1924_1699;
					  free_2779 = arg1925_1700;
					  free_1686 = free_2779;
					  lcls_1685 = lcls_2778;
					  goto liip_1687;
				       }
				    }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 let_var_6_t node_1702;
			 node_1702 = (let_var_6_t) (node_9);
			 {
			    obj_t bindings_1705;
			    obj_t free_1706;
			    bindings_1705 = (((let_var_6_t) CREF(node_1702))->bindings);
			    free_1706 = free_10;
			  loop_1707:
			    if (NULLP(bindings_1705))
			      {
				 obj_t free_2786;
				 node_t node_2784;
				 node_2784 = (((let_var_6_t) CREF(node_1702))->body);
				 free_2786 = free_1706;
				 free_10 = free_2786;
				 node_9 = node_2784;
				 goto node_free_158_globalize_free;
			      }
			    else
			      {
				 {
				    local_t aux_2787;
				    {
				       obj_t aux_2788;
				       {
					  obj_t aux_2789;
					  aux_2789 = CAR(bindings_1705);
					  aux_2788 = CAR(aux_2789);
				       }
				       aux_2787 = (local_t) (aux_2788);
				    }
				    bind_variable__14_globalize_free(aux_2787, (local_t) (_integrator__235_globalize_free));
				 }
				 {
				    obj_t arg1933_1713;
				    obj_t arg1934_1714;
				    arg1933_1713 = CDR(bindings_1705);
				    {
				       node_t aux_2796;
				       {
					  obj_t aux_2797;
					  {
					     obj_t aux_2798;
					     aux_2798 = CAR(bindings_1705);
					     aux_2797 = CDR(aux_2798);
					  }
					  aux_2796 = (node_t) (aux_2797);
				       }
				       arg1934_1714 = node_free_158_globalize_free(aux_2796, free_1706);
				    }
				    {
				       obj_t free_2804;
				       obj_t bindings_2803;
				       bindings_2803 = arg1933_1713;
				       free_2804 = arg1934_1714;
				       free_1706 = free_2804;
				       bindings_1705 = bindings_2803;
				       goto loop_1707;
				    }
				 }
			      }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 set_ex_it_116_t node_1717;
			 node_1717 = (set_ex_it_116_t) (node_9);
			 {
			    local_t aux_2807;
			    {
			       variable_t aux_2808;
			       {
				  var_t arg1938_1721;
				  arg1938_1721 = (((set_ex_it_116_t) CREF(node_1717))->var);
				  aux_2808 = (((var_t) CREF(arg1938_1721))->variable);
			       }
			       aux_2807 = (local_t) (aux_2808);
			    }
			    bind_variable__14_globalize_free(aux_2807, (local_t) (_integrator__235_globalize_free));
			 }
			 {
			    node_t node_2814;
			    node_2814 = (((set_ex_it_116_t) CREF(node_1717))->body);
			    node_9 = node_2814;
			    goto node_free_158_globalize_free;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 jump_ex_it_184_t node_1723;
			 node_1723 = (jump_ex_it_184_t) (node_9);
			 {
			    node_t arg1940_1726;
			    obj_t arg1941_1727;
			    arg1940_1726 = (((jump_ex_it_184_t) CREF(node_1723))->exit);
			    arg1941_1727 = node_free_158_globalize_free((((jump_ex_it_184_t) CREF(node_1723))->value), free_10);
			    {
			       obj_t free_2821;
			       node_t node_2820;
			       node_2820 = arg1940_1726;
			       free_2821 = arg1941_1727;
			       free_10 = free_2821;
			       node_9 = node_2820;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 make_box_202_t node_1729;
			 node_1729 = (make_box_202_t) (node_9);
			 {
			    node_t node_2823;
			    node_2823 = (((make_box_202_t) CREF(node_1729))->value);
			    node_9 = node_2823;
			    goto node_free_158_globalize_free;
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 box_ref_242_t node_1733;
			 node_1733 = (box_ref_242_t) (node_9);
			 {
			    node_t node_2826;
			    {
			       var_t aux_2827;
			       aux_2827 = (((box_ref_242_t) CREF(node_1733))->var);
			       node_2826 = (node_t) (aux_2827);
			    }
			    node_9 = node_2826;
			    goto node_free_158_globalize_free;
			 }
		      }
		      break;
		   case ((long) 18):
		      {
			 box_set__221_t node_1737;
			 node_1737 = (box_set__221_t) (node_9);
			 {
			    var_t arg1945_1740;
			    obj_t arg1947_1741;
			    arg1945_1740 = (((box_set__221_t) CREF(node_1737))->var);
			    arg1947_1741 = node_free_158_globalize_free((((box_set__221_t) CREF(node_1737))->value), free_10);
			    {
			       obj_t free_2836;
			       node_t node_2834;
			       node_2834 = (node_t) (arg1945_1740);
			       free_2836 = arg1947_1741;
			       free_10 = free_2836;
			       node_9 = node_2834;
			       goto node_free_158_globalize_free;
			    }
			 }
		      }
		      break;
		   default:
		    case_else1851_1583:
		      if (PROCEDUREP(method1845_1579))
			{
			   return PROCEDURE_ENTRY(method1845_1579) (method1845_1579, (obj_t) (node_9), free_10, BEOA);
			}
		      else
			{
			   obj_t fun1844_1575;
			   fun1844_1575 = PROCEDURE_REF(node_free_env_48_globalize_free, ((long) 0));
			   return PROCEDURE_ENTRY(fun1844_1575) (fun1844_1575, (obj_t) (node_9), free_10, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1851_1583;
	      }
	 }
      }
   }
}


/* _node-free1964 */ obj_t 
_node_free1964_252_globalize_free(obj_t env_2150, obj_t node_2151, obj_t free_2152)
{
   return node_free_158_globalize_free((node_t) (node_2151), free_2152);
}


/* node-free-default1594 */ obj_t 
node_free_default1594_84_globalize_free(node_t node_11, obj_t free_12)
{
   return free_12;
}


/* _node-free-default1594 */ obj_t 
_node_free_default1594_29_globalize_free(obj_t env_2153, obj_t node_2154, obj_t free_2155)
{
   return node_free_default1594_84_globalize_free((node_t) (node_2154), free_2155);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_globalize_free()
{
   module_initialization_70_tools_trace(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_tools_shape(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_tools_speek(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_type_type(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_type_cache(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_ast_var(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_ast_local(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_ast_node(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_ast_sexp(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_ast_glo_def_117(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_globalize_ginfo(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_globalize_node(((long) 0), "GLOBALIZE_FREE");
   module_initialization_70_engine_param(((long) 0), "GLOBALIZE_FREE");
   return module_initialization_70_globalize_global_closure_246(((long) 0), "GLOBALIZE_FREE");
}
