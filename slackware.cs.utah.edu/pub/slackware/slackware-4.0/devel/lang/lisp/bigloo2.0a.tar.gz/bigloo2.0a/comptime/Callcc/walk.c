/*===========================================================================*/
/*   (Callcc/walk.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct local_cell_149
  {
     char dummy;
  }
              *local_cell_149_t;


static obj_t method_init_76_callcc_walk();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t current_error_port;
extern obj_t fail_ast_node;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t box_ref_242_ast_node;
static bool_t callcc_fun__197_callcc_walk(obj_t);
static obj_t _object__struct1902_152___object(obj_t, obj_t);
static local_t allocate_local_cell_184_callcc_walk();
static obj_t local_cell_149_callcc_walk = BUNSPEC;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t callcc_walk__209_callcc_walk(obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
static node_t callcc__192_callcc_walk(node_t);
extern obj_t set_ex_it_116_ast_node;
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_callcc_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_callcc_walk();
static obj_t struct_object__object_local_cell_0_callcc_walk(obj_t, obj_t, obj_t);
static obj_t _callcc_walk__182_callcc_walk(obj_t, obj_t);
static obj_t _struct_object__object1900_180___object(obj_t, obj_t, obj_t);
static bool_t celled__113_callcc_walk(variable_t);
static obj_t celled_bindings_3_callcc_walk(obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_callcc_walk();
static obj_t object__struct_local_cell_80_callcc_walk(obj_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t atom_ast_node;
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_callcc_walk();
static obj_t _callcc_1903_141_callcc_walk(obj_t, obj_t);
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static make_box_202_t a_make_cell_117_callcc_walk(node_t, variable_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t string_to_bstring(char *);
static obj_t _callcc__default1496_165_callcc_walk(obj_t, obj_t);
extern obj_t local_ast_var;
static obj_t callcc___127_callcc_walk(obj_t);
static node_t cell_formals_12_callcc_walk(obj_t, node_t);
extern obj_t _compiler_debug__134_engine_param;
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t object_init_111_callcc_walk();
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
static obj_t _allocate_local_cell_31_callcc_walk(obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t object__struct_50___object(object_t);
static node_t callcc__default1496_228_callcc_walk(node_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_callcc_walk = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_callcc_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[7];

DEFINE_STATIC_GENERIC(callcc__env_142_callcc_walk, _callcc_1903_141_callcc_walk1919, _callcc_1903_141_callcc_walk, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1911_callcc_walk, struct_object__object_local_cell_0_callcc_walk1920, struct_object__object_local_cell_0_callcc_walk, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1910_callcc_walk, object__struct_local_cell_80_callcc_walk1921, object__struct_local_cell_80_callcc_walk, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_STATIC_PROCEDURE(allocate_local_cell_env_161_callcc_walk, _allocate_local_cell_31_callcc_walk1922, _allocate_local_cell_31_callcc_walk, 0L, 0);
DEFINE_EXPORT_PROCEDURE(callcc_walk__env_78_callcc_walk, _callcc_walk__182_callcc_walk1923, _callcc_walk__182_callcc_walk, 0L, 1);
DEFINE_STATIC_PROCEDURE(callcc__default1496_env_140_callcc_walk, _callcc__default1496_165_callcc_walk1924, _callcc__default1496_165_callcc_walk, 0L, 1);
DEFINE_STRING(string1913_callcc_walk, string1913_callcc_walk1925, "CALLCC!-DEFAULT1496 AUX LOCAL/CELL DONE WRITE CELL-CALLCC PASS-STARTED ", 71);
DEFINE_STRING(string1912_callcc_walk, string1912_callcc_walk1926, "No method for this object", 25);
DEFINE_STRING(string1909_callcc_walk, string1909_callcc_walk1927, "failure during postlude hook", 28);
DEFINE_STRING(string1908_callcc_walk, string1908_callcc_walk1928, " error", 6);
DEFINE_STRING(string1907_callcc_walk, string1907_callcc_walk1929, " occured, ending ...", 20);
DEFINE_STRING(string1906_callcc_walk, string1906_callcc_walk1930, "failure during prelude hook", 27);
DEFINE_STRING(string1905_callcc_walk, string1905_callcc_walk1931, "   . ", 5);
DEFINE_STRING(string1904_callcc_walk, string1904_callcc_walk1932, "Callcc", 6);
extern obj_t object__struct_env_210___object;


/* module-initialization */ obj_t 
module_initialization_70_callcc_walk(long checksum_1860, char *from_1861)
{
   if (CBOOL(require_initialization_114_callcc_walk))
     {
	require_initialization_114_callcc_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_callcc_walk();
	cnst_init_137_callcc_walk();
	imported_modules_init_94_callcc_walk();
	object_init_111_callcc_walk();
	method_init_76_callcc_walk();
	toplevel_init_63_callcc_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_callcc_walk()
{
   module_initialization_70___object(((long) 0), "CALLCC_WALK");
   module_initialization_70___r4_output_6_10_3(((long) 0), "CALLCC_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "CALLCC_WALK");
   module_initialization_70___reader(((long) 0), "CALLCC_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_callcc_walk()
{
   {
      obj_t cnst_port_138_1852;
      cnst_port_138_1852 = open_input_string(string1913_callcc_walk);
      {
	 long i_1853;
	 i_1853 = ((long) 6);
       loop_1854:
	 {
	    bool_t test1914_1855;
	    test1914_1855 = (i_1853 == ((long) -1));
	    if (test1914_1855)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1915_1856;
		    {
		       obj_t list1916_1857;
		       {
			  obj_t arg1917_1858;
			  arg1917_1858 = BNIL;
			  list1916_1857 = MAKE_PAIR(cnst_port_138_1852, arg1917_1858);
		       }
		       arg1915_1856 = read___reader(list1916_1857);
		    }
		    CNST_TABLE_SET(i_1853, arg1915_1856);
		 }
		 {
		    int aux_1859;
		    {
		       long aux_1881;
		       aux_1881 = (i_1853 - ((long) 1));
		       aux_1859 = (int) (aux_1881);
		    }
		    {
		       long i_1884;
		       i_1884 = (long) (aux_1859);
		       i_1853 = i_1884;
		       goto loop_1854;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_callcc_walk()
{
   return BUNSPEC;
}


/* callcc-walk! */ obj_t 
callcc_walk__209_callcc_walk(obj_t globals_1)
{
   {
      obj_t list1522_763;
      {
	 obj_t arg1525_765;
	 {
	    obj_t arg1527_767;
	    {
	       obj_t aux_1886;
	       aux_1886 = BCHAR(((unsigned char) '\n'));
	       arg1527_767 = MAKE_PAIR(aux_1886, BNIL);
	    }
	    arg1525_765 = MAKE_PAIR(string1904_callcc_walk, arg1527_767);
	 }
	 list1522_763 = MAKE_PAIR(string1905_callcc_walk, arg1525_765);
      }
      verbose_tools_speek(BINT(((long) 1)), list1522_763);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1904_callcc_walk;
   {
      obj_t hooks_769;
      obj_t hnames_770;
      hooks_769 = BNIL;
      hnames_770 = BNIL;
    loop_771:
      if (NULLP(hooks_769))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1533_776;
	   {
	      obj_t fun1540_782;
	      fun1540_782 = CAR(hooks_769);
	      {
		 obj_t aux_1898;
		 aux_1898 = PROCEDURE_ENTRY(fun1540_782) (fun1540_782, BEOA);
		 test1533_776 = CBOOL(aux_1898);
	      }
	   }
	   if (test1533_776)
	     {
		{
		   obj_t hnames_1905;
		   obj_t hooks_1903;
		   hooks_1903 = CDR(hooks_769);
		   hnames_1905 = CDR(hnames_770);
		   hnames_770 = hnames_1905;
		   hooks_769 = hooks_1903;
		   goto loop_771;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1904_callcc_walk, string1906_callcc_walk, CAR(hnames_770));
	     }
	}
   }
   {
      bool_t test1541_783;
      {
	 long n1_1423;
	 n1_1423 = (long) CINT(_compiler_debug__134_engine_param);
	 test1541_783 = (n1_1423 > ((long) 2));
      }
      if (test1541_783)
	{
	   _compiler_debug__134_engine_param = BINT(((long) 2));
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      obj_t l1456_784;
      l1456_784 = globals_1;
    lname1457_785:
      if (PAIRP(l1456_784))
	{
	   callcc_fun__197_callcc_walk(CAR(l1456_784));
	   {
	      obj_t l1456_1917;
	      l1456_1917 = CDR(l1456_784);
	      l1456_784 = l1456_1917;
	      goto lname1457_785;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      bool_t test1549_790;
      {
	 long n1_1428;
	 n1_1428 = (long) CINT(_nb_error_on_pass__70_tools_error);
	 test1549_790 = (n1_1428 > ((long) 0));
      }
      if (test1549_790)
	{
	   {
	      char *arg1553_793;
	      {
		 bool_t test1560_800;
		 {
		    bool_t test1561_801;
		    {
		       obj_t obj_1430;
		       obj_1430 = _nb_error_on_pass__70_tools_error;
		       test1561_801 = INTEGERP(obj_1430);
		    }
		    if (test1561_801)
		      {
			 test1560_800 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
		      }
		    else
		      {
			 test1560_800 = ((bool_t) 0);
		      }
		 }
		 if (test1560_800)
		   {
		      arg1553_793 = "s";
		   }
		 else
		   {
		      arg1553_793 = "";
		   }
	      }
	      {
		 obj_t list1555_795;
		 {
		    obj_t arg1556_796;
		    {
		       obj_t arg1557_797;
		       {
			  obj_t arg1558_798;
			  arg1558_798 = MAKE_PAIR(string1907_callcc_walk, BNIL);
			  {
			     obj_t aux_1928;
			     aux_1928 = string_to_bstring(arg1553_793);
			     arg1557_797 = MAKE_PAIR(aux_1928, arg1558_798);
			  }
		       }
		       arg1556_796 = MAKE_PAIR(string1908_callcc_walk, arg1557_797);
		    }
		    list1555_795 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1556_796);
		 }
		 fprint___r4_output_6_10_3(current_error_port, list1555_795);
	      }
	   }
	   {
	      obj_t res1886_1432;
	      exit(((long) -1));
	      res1886_1432 = BINT(((long) -1));
	      return res1886_1432;
	   }
	}
      else
	{
	   obj_t hooks_802;
	   obj_t hnames_803;
	   hooks_802 = BNIL;
	   hnames_803 = BNIL;
	 loop_804:
	   if (NULLP(hooks_802))
	     {
		return globals_1;
	     }
	   else
	     {
		bool_t test1566_809;
		{
		   obj_t fun1573_814;
		   fun1573_814 = CAR(hooks_802);
		   {
		      obj_t aux_1939;
		      aux_1939 = PROCEDURE_ENTRY(fun1573_814) (fun1573_814, BEOA);
		      test1566_809 = CBOOL(aux_1939);
		   }
		}
		if (test1566_809)
		  {
		     {
			obj_t hnames_1946;
			obj_t hooks_1944;
			hooks_1944 = CDR(hooks_802);
			hnames_1946 = CDR(hnames_803);
			hnames_803 = hnames_1946;
			hooks_802 = hooks_1944;
			goto loop_804;
		     }
		  }
		else
		  {
		     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1909_callcc_walk, CAR(hnames_803));
		  }
	     }
	}
   }
}


/* _callcc-walk! */ obj_t 
_callcc_walk__182_callcc_walk(obj_t env_1833, obj_t globals_1834)
{
   return callcc_walk__209_callcc_walk(globals_1834);
}


/* callcc-fun! */ bool_t 
callcc_fun__197_callcc_walk(obj_t var_2)
{
   {
      value_t fun_815;
      {
	 variable_t obj_1439;
	 obj_1439 = (variable_t) (var_2);
	 fun_815 = (((variable_t) CREF(obj_1439))->value);
      }
      {
	 obj_t body_816;
	 {
	    sfun_t obj_1440;
	    obj_1440 = (sfun_t) (fun_815);
	    body_816 = (((sfun_t) CREF(obj_1440))->body);
	 }
	 {
	    obj_t celled_817;
	    {
	       obj_t aux_1955;
	       {
		  sfun_t obj_1441;
		  obj_1441 = (sfun_t) (fun_815);
		  aux_1955 = (((sfun_t) CREF(obj_1441))->args);
	       }
	       celled_817 = celled_bindings_3_callcc_walk(aux_1955);
	    }
	    {
	       {
		  obj_t l1458_818;
		  l1458_818 = celled_817;
		lname1459_819:
		  if (PAIRP(l1458_818))
		    {
		       {
			  obj_t w_b_127_821;
			  w_b_127_821 = CAR(l1458_818);
			  {
			     obj_t arg1578_823;
			     arg1578_823 = CDR(w_b_127_821);
			     {
				local_t obj_1446;
				{
				   obj_t aux_1963;
				   aux_1963 = CAR(w_b_127_821);
				   obj_1446 = (local_t) (aux_1963);
				}
				((((local_t) CREF(obj_1446))->fast_alpha_7) = ((obj_t) arg1578_823), BUNSPEC);
			     }
			  }
		       }
		       {
			  obj_t l1458_1967;
			  l1458_1967 = CDR(l1458_818);
			  l1458_818 = l1458_1967;
			  goto lname1459_819;
		       }
		    }
		  else
		    {
		       ((bool_t) 1);
		    }
	       }
	       {
		  node_t arg1581_825;
		  {
		     node_t arg1582_826;
		     arg1582_826 = callcc__192_callcc_walk((node_t) (body_816));
		     arg1581_825 = cell_formals_12_callcc_walk(celled_817, arg1582_826);
		  }
		  {
		     sfun_t obj_1449;
		     obj_t val1136_1450;
		     obj_1449 = (sfun_t) (fun_815);
		     val1136_1450 = (obj_t) (arg1581_825);
		     ((((sfun_t) CREF(obj_1449))->body) = ((obj_t) val1136_1450), BUNSPEC);
		  }
	       }
	       {
		  obj_t l1460_827;
		  l1460_827 = celled_817;
		lname1461_828:
		  if (PAIRP(l1460_827))
		    {
		       {
			  local_t obj_1454;
			  {
			     obj_t aux_1977;
			     {
				obj_t aux_1978;
				aux_1978 = CAR(l1460_827);
				aux_1977 = CAR(aux_1978);
			     }
			     obj_1454 = (local_t) (aux_1977);
			  }
			  ((((local_t) CREF(obj_1454))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
		       }
		       {
			  obj_t l1460_1983;
			  l1460_1983 = CDR(l1460_827);
			  l1460_827 = l1460_1983;
			  goto lname1461_828;
		       }
		    }
		  else
		    {
		       return ((bool_t) 1);
		    }
	       }
	    }
	 }
      }
   }
}


/* celled-bindings */ obj_t 
celled_bindings_3_callcc_walk(obj_t formals_3)
{
   {
      obj_t celled_834;
      obj_t formals_835;
      celled_834 = BNIL;
      formals_835 = formals_3;
    loop_836:
      if (NULLP(formals_835))
	{
	   return celled_834;
	}
      else
	{
	   bool_t test_1987;
	   {
	      variable_t aux_1988;
	      {
		 obj_t aux_1989;
		 aux_1989 = CAR(formals_835);
		 aux_1988 = (variable_t) (aux_1989);
	      }
	      test_1987 = celled__113_callcc_walk(aux_1988);
	   }
	   if (test_1987)
	     {
		{
		   local_t var_840;
		   {
		      obj_t aux_1993;
		      {
			 local_t obj_1460;
			 {
			    obj_t aux_1994;
			    aux_1994 = CAR(formals_835);
			    obj_1460 = (local_t) (aux_1994);
			 }
			 aux_1993 = (((local_t) CREF(obj_1460))->id);
		      }
		      var_840 = make_local_svar_140_ast_local(aux_1993, (type_t) (_obj__252_type_cache));
		   }
		   {
		      obj_t o_n_168_841;
		      {
			 obj_t aux_2002;
			 obj_t aux_2000;
			 aux_2002 = (obj_t) (var_840);
			 aux_2000 = CAR(formals_835);
			 o_n_168_841 = MAKE_PAIR(aux_2000, aux_2002);
		      }
		      {
			 {
			    local_cell_149_t obj1462_842;
			    obj1462_842 = ((local_cell_149_t) (var_840));
			    {
			       obj_t aux_2008;
			       object_t aux_2006;
			       {
				  local_cell_149_t aux_2009;
				  {
				     aux_2009 = ((local_cell_149_t) BREF(GC_MALLOC(sizeof(struct local_cell_149))));
				  }
				  aux_2008 = (obj_t) (aux_2009);
			       }
			       aux_2006 = (object_t) (obj1462_842);
			       OBJECT_WIDENING_SET(aux_2006, aux_2008);
			    }
			    {
			       long arg1593_844;
			       arg1593_844 = class_num_218___object(local_cell_149_callcc_walk);
			       {
				  obj_t obj_1466;
				  obj_1466 = (obj_t) (obj1462_842);
				  (((obj_t) CREF(obj_1466))->header = MAKE_HEADER(arg1593_844, 0), BUNSPEC);
			       }
			    }
			    obj1462_842;
			 }
			 {
			    obj_t arg1594_845;
			    obj_t arg1595_846;
			    arg1594_845 = MAKE_PAIR(o_n_168_841, celled_834);
			    arg1595_846 = CDR(formals_835);
			    {
			       obj_t formals_2019;
			       obj_t celled_2018;
			       celled_2018 = arg1594_845;
			       formals_2019 = arg1595_846;
			       formals_835 = formals_2019;
			       celled_834 = celled_2018;
			       goto loop_836;
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
		{
		   obj_t formals_2020;
		   formals_2020 = CDR(formals_835);
		   formals_835 = formals_2020;
		   goto loop_836;
		}
	     }
	}
   }
}


/* cell-formals */ node_t 
cell_formals_12_callcc_walk(obj_t celled_4, node_t body_5)
{
   {
      bool_t test1606_852;
      test1606_852 = NULLP(celled_4);
      if (test1606_852)
	{
	   return body_5;
	}
      else
	{
	   obj_t loc_853;
	   loc_853 = (((node_t) CREF(body_5))->loc);
	   {
	      obj_t arg1608_855;
	      obj_t arg1610_857;
	      arg1608_855 = ____74_type_cache;
	      if (test1606_852)
		{
		   arg1610_857 = BNIL;
		}
	      else
		{
		   obj_t head1466_861;
		   head1466_861 = MAKE_PAIR(BNIL, BNIL);
		   {
		      obj_t l1464_862;
		      obj_t tail1467_863;
		      l1464_862 = celled_4;
		      tail1467_863 = head1466_861;
		    lname1465_864:
		      if (NULLP(l1464_862))
			{
			   arg1610_857 = CDR(head1466_861);
			}
		      else
			{
			   obj_t newtail1468_866;
			   {
			      obj_t arg1617_868;
			      {
				 obj_t o_n_168_870;
				 o_n_168_870 = CAR(l1464_862);
				 {
				    obj_t arg1620_871;
				    make_box_202_t arg1621_872;
				    arg1620_871 = CDR(o_n_168_870);
				    {
				       var_t arg1622_873;
				       obj_t arg1623_874;
				       {
					  obj_t arg1625_876;
					  arg1625_876 = ____74_type_cache;
					  {
					     var_t res1888_1492;
					     {
						type_t type_1483;
						variable_t variable_1484;
						type_1483 = (type_t) (arg1625_876);
						{
						   obj_t aux_2033;
						   aux_2033 = CAR(o_n_168_870);
						   variable_1484 = (variable_t) (aux_2033);
						}
						{
						   var_t new1207_1485;
						   new1207_1485 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						   {
						      long arg1705_1486;
						      arg1705_1486 = class_num_218___object(var_ast_node);
						      {
							 obj_t obj_1490;
							 obj_1490 = (obj_t) (new1207_1485);
							 (((obj_t) CREF(obj_1490))->header = MAKE_HEADER(arg1705_1486, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_2040;
						      aux_2040 = (object_t) (new1207_1485);
						      OBJECT_WIDENING_SET(aux_2040, BFALSE);
						   }
						   ((((var_t) CREF(new1207_1485))->loc) = ((obj_t) loc_853), BUNSPEC);
						   ((((var_t) CREF(new1207_1485))->type) = ((type_t) type_1483), BUNSPEC);
						   ((((var_t) CREF(new1207_1485))->variable) = ((variable_t) variable_1484), BUNSPEC);
						   res1888_1492 = new1207_1485;
						}
					     }
					     arg1622_873 = res1888_1492;
					  }
				       }
				       arg1623_874 = CAR(o_n_168_870);
				       arg1621_872 = a_make_cell_117_callcc_walk((node_t) (arg1622_873), (variable_t) (arg1623_874));
				    }
				    {
				       obj_t aux_2050;
				       aux_2050 = (obj_t) (arg1621_872);
				       arg1617_868 = MAKE_PAIR(arg1620_871, aux_2050);
				    }
				 }
			      }
			      newtail1468_866 = MAKE_PAIR(arg1617_868, BNIL);
			   }
			   SET_CDR(tail1467_863, newtail1468_866);
			   {
			      obj_t tail1467_2057;
			      obj_t l1464_2055;
			      l1464_2055 = CDR(l1464_862);
			      tail1467_2057 = newtail1468_866;
			      tail1467_863 = tail1467_2057;
			      l1464_862 = l1464_2055;
			      goto lname1465_864;
			   }
			}
		   }
		}
	      {
		 let_var_6_t res1889_1519;
		 {
		    type_t type_1502;
		    obj_t key_1504;
		    type_1502 = (type_t) (arg1608_855);
		    key_1504 = BINT(((long) -1));
		    {
		       let_var_6_t new1366_1508;
		       new1366_1508 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		       {
			  long arg1673_1509;
			  arg1673_1509 = class_num_218___object(let_var_6_ast_node);
			  {
			     obj_t obj_1517;
			     obj_1517 = (obj_t) (new1366_1508);
			     (((obj_t) CREF(obj_1517))->header = MAKE_HEADER(arg1673_1509, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_2064;
			  aux_2064 = (object_t) (new1366_1508);
			  OBJECT_WIDENING_SET(aux_2064, BFALSE);
		       }
		       ((((let_var_6_t) CREF(new1366_1508))->loc) = ((obj_t) loc_853), BUNSPEC);
		       ((((let_var_6_t) CREF(new1366_1508))->type) = ((type_t) type_1502), BUNSPEC);
		       ((((let_var_6_t) CREF(new1366_1508))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((let_var_6_t) CREF(new1366_1508))->key) = ((obj_t) key_1504), BUNSPEC);
		       ((((let_var_6_t) CREF(new1366_1508))->bindings) = ((obj_t) arg1610_857), BUNSPEC);
		       ((((let_var_6_t) CREF(new1366_1508))->body) = ((node_t) body_5), BUNSPEC);
		       ((((let_var_6_t) CREF(new1366_1508))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		       res1889_1519 = new1366_1508;
		    }
		 }
		 return (node_t) (res1889_1519);
	      }
	   }
	}
   }
}


/* a-make-cell */ make_box_202_t 
a_make_cell_117_callcc_walk(node_t node_6, variable_t variable_7)
{
   {
      obj_t arg1632_881;
      arg1632_881 = CNST_TABLE_REF(((long) 1));
      {
	 local_t obj_1520;
	 obj_1520 = (local_t) (variable_7);
	 ((((local_t) CREF(obj_1520))->access) = ((obj_t) arg1632_881), BUNSPEC);
      }
   }
   {
      local_cell_149_t obj1472_882;
      obj1472_882 = ((local_cell_149_t) (variable_7));
      {
	 obj_t aux_2081;
	 object_t aux_2079;
	 {
	    local_cell_149_t aux_2082;
	    {
	       aux_2082 = ((local_cell_149_t) BREF(GC_MALLOC(sizeof(struct local_cell_149))));
	    }
	    aux_2081 = (obj_t) (aux_2082);
	 }
	 aux_2079 = (object_t) (obj1472_882);
	 OBJECT_WIDENING_SET(aux_2079, aux_2081);
      }
      {
	 long arg1634_884;
	 arg1634_884 = class_num_218___object(local_cell_149_callcc_walk);
	 {
	    obj_t obj_1524;
	    obj_1524 = (obj_t) (obj1472_882);
	    (((obj_t) CREF(obj_1524))->header = MAKE_HEADER(arg1634_884, 0), BUNSPEC);
	 }
      }
      obj1472_882;
   }
   {
      obj_t arg1636_885;
      obj_t arg1638_886;
      arg1636_885 = (((node_t) CREF(node_6))->loc);
      arg1638_886 = ____74_type_cache;
      {
	 make_box_202_t res1891_1541;
	 {
	    type_t type_1528;
	    obj_t key_1530;
	    type_1528 = (type_t) (arg1638_886);
	    key_1530 = BINT(((long) -1));
	    {
	       make_box_202_t new1402_1532;
	       new1402_1532 = ((make_box_202_t) BREF(GC_MALLOC(sizeof(struct make_box_202))));
	       {
		  long arg1666_1533;
		  arg1666_1533 = class_num_218___object(make_box_202_ast_node);
		  {
		     obj_t obj_1539;
		     obj_1539 = (obj_t) (new1402_1532);
		     (((obj_t) CREF(obj_1539))->header = MAKE_HEADER(arg1666_1533, 0), BUNSPEC);
		  }
	       }
	       {
		  object_t aux_2096;
		  aux_2096 = (object_t) (new1402_1532);
		  OBJECT_WIDENING_SET(aux_2096, BFALSE);
	       }
	       ((((make_box_202_t) CREF(new1402_1532))->loc) = ((obj_t) arg1636_885), BUNSPEC);
	       ((((make_box_202_t) CREF(new1402_1532))->type) = ((type_t) type_1528), BUNSPEC);
	       ((((make_box_202_t) CREF(new1402_1532))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
	       ((((make_box_202_t) CREF(new1402_1532))->key) = ((obj_t) key_1530), BUNSPEC);
	       ((((make_box_202_t) CREF(new1402_1532))->value) = ((node_t) node_6), BUNSPEC);
	       res1891_1541 = new1402_1532;
	    }
	 }
	 return res1891_1541;
      }
   }
}


/* celled? */ bool_t 
celled__113_callcc_walk(variable_t var_8)
{
   {
      bool_t _ortest_1474_889;
      _ortest_1474_889 = is_a__118___object((obj_t) (var_8), local_cell_149_callcc_walk);
      if (_ortest_1474_889)
	{
	   return _ortest_1474_889;
	}
      else
	{
	   obj_t aux_2110;
	   obj_t aux_2107;
	   aux_2110 = CNST_TABLE_REF(((long) 2));
	   {
	      local_t obj_1543;
	      obj_1543 = (local_t) (var_8);
	      aux_2107 = (((local_t) CREF(obj_1543))->access);
	   }
	   return (aux_2107 == aux_2110);
	}
   }
}


/* callcc*! */ obj_t 
callcc___127_callcc_walk(obj_t node__221_31)
{
 callcc___127_callcc_walk:
   if (NULLP(node__221_31))
     {
	return CNST_TABLE_REF(((long) 3));
     }
   else
     {
	{
	   node_t arg1647_893;
	   {
	      node_t aux_2116;
	      {
		 obj_t aux_2117;
		 aux_2117 = CAR(node__221_31);
		 aux_2116 = (node_t) (aux_2117);
	      }
	      arg1647_893 = callcc__192_callcc_walk(aux_2116);
	   }
	   {
	      obj_t aux_2121;
	      aux_2121 = (obj_t) (arg1647_893);
	      SET_CAR(node__221_31, aux_2121);
	   }
	}
	{
	   obj_t node__221_2124;
	   node__221_2124 = CDR(node__221_31);
	   node__221_31 = node__221_2124;
	   goto callcc___127_callcc_walk;
	}
     }
}


/* object-init */ obj_t 
object_init_111_callcc_walk()
{
   {
      obj_t arg1652_897;
      arg1652_897 = local_ast_var;
      local_cell_149_callcc_walk = add_class__117___object(CNST_TABLE_REF(((long) 4)), arg1652_897, allocate_local_cell_env_161_callcc_walk, ((long) 32234), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-local/cell */ local_t 
allocate_local_cell_184_callcc_walk()
{
   {
      local_t new1448_900;
      new1448_900 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1655_901;
	 arg1655_901 = class_num_218___object(local_cell_149_callcc_walk);
	 {
	    obj_t obj_1551;
	    obj_1551 = (obj_t) (new1448_900);
	    (((obj_t) CREF(obj_1551))->header = MAKE_HEADER(arg1655_901, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2132;
	 aux_2132 = (object_t) (new1448_900);
	 OBJECT_WIDENING_SET(aux_2132, BFALSE);
      }
      return new1448_900;
   }
}


/* _allocate-local/cell */ obj_t 
_allocate_local_cell_31_callcc_walk(obj_t env_1835)
{
   {
      local_t aux_2135;
      aux_2135 = allocate_local_cell_184_callcc_walk();
      return (obj_t) (aux_2135);
   }
}


/* method-init */ obj_t 
method_init_76_callcc_walk()
{
   add_generic__110___object(callcc__env_142_callcc_walk, callcc__default1496_env_140_callcc_walk);
   add_inlined_method__244___object(callcc__env_142_callcc_walk, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, var_ast_node, ((long) 2));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, app_ast_node, ((long) 4));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, select_ast_node, ((long) 12));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, box_ref_242_ast_node, ((long) 18));
   add_inlined_method__244___object(callcc__env_142_callcc_walk, box_set__221_ast_node, ((long) 19));
   {
      obj_t object__struct_local_cell_80_1840;
      object__struct_local_cell_80_1840 = proc1910_callcc_walk;
      add_method__1___object(object__struct_env_210___object, local_cell_149_callcc_walk, object__struct_local_cell_80_1840);
   }
   {
      obj_t struct_object__object_local_cell_0_1836;
      struct_object__object_local_cell_0_1836 = proc1911_callcc_walk;
      return add_method__1___object(struct_object__object_env_209___object, local_cell_149_callcc_walk, struct_object__object_local_cell_0_1836);
   }
}


/* struct+object->object-local/cell */ obj_t 
struct_object__object_local_cell_0_callcc_walk(obj_t env_1843, obj_t o_1844, obj_t s_1845)
{
   {
      local_cell_149_t o_1243;
      obj_t s_1244;
      {
	 local_cell_149_t aux_2161;
	 o_1243 = (local_cell_149_t) (o_1844);
	 s_1244 = s_1845;
	 {
	    {
	       obj_t old1453_1247;
	       {
		  obj_t next_method1521_78_1252;
		  next_method1521_78_1252 = find_super_class_method_167___object((object_t) (o_1243), struct_object__object_env_209___object, local_cell_149_callcc_walk);
		  if (PROCEDUREP(next_method1521_78_1252))
		    {
		       old1453_1247 = PROCEDURE_ENTRY(next_method1521_78_1252) (next_method1521_78_1252, (obj_t) (o_1243), s_1244, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1521_78_1252);
		       {
			  object_t aux_2170;
			  aux_2170 = struct_object__object_93___object((object_t) (o_1243), s_1244);
			  old1453_1247 = (obj_t) (aux_2170);
		       }
		    }
	       }
	       {
		  local_cell_149_t new1455_1249;
		  new1455_1249 = ((local_cell_149_t) (old1453_1247));
		  {
		     long arg1749_1250;
		     arg1749_1250 = class_num_218___object(local_cell_149_callcc_walk);
		     {
			obj_t obj_1627;
			obj_1627 = (obj_t) (new1455_1249);
			(((obj_t) CREF(obj_1627))->header = MAKE_HEADER(arg1749_1250, 0), BUNSPEC);
		     }
		  }
		  {
		     obj_t aux_2180;
		     object_t aux_2178;
		     {
			local_cell_149_t aux_2181;
			{
			   aux_2181 = ((local_cell_149_t) BREF(GC_MALLOC(sizeof(struct local_cell_149))));
			}
			aux_2180 = (obj_t) (aux_2181);
		     }
		     aux_2178 = (object_t) (new1455_1249);
		     OBJECT_WIDENING_SET(aux_2178, aux_2180);
		  }
		  aux_2161 = new1455_1249;
	       }
	    }
	 }
	 return (obj_t) (aux_2161);
      }
   }
}


/* object->struct-local/cell */ obj_t 
object__struct_local_cell_80_callcc_walk(obj_t env_1846, obj_t obj1450_1847)
{
   {
      local_cell_149_t obj1450_1232;
      obj1450_1232 = (local_cell_149_t) (obj1450_1847);
      {
	 {
	    obj_t res1451_1235;
	    {
	       obj_t next_method1520_75_1241;
	       next_method1520_75_1241 = find_super_class_method_167___object((object_t) (obj1450_1232), object__struct_env_210___object, local_cell_149_callcc_walk);
	       if (PROCEDUREP(next_method1520_75_1241))
		 {
		    res1451_1235 = PROCEDURE_ENTRY(next_method1520_75_1241) (next_method1520_75_1241, (obj_t) (obj1450_1232), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1520_75_1241);
		    res1451_1235 = object__struct_50___object((object_t) (obj1450_1232));
		 }
	    }
	    {
	       obj_t aux1452_1236;
	       {
		  obj_t aux_2197;
		  aux_2197 = CNST_TABLE_REF(((long) 4));
		  aux1452_1236 = make_struct(aux_2197, ((long) 0), BUNSPEC);
	       }
	       STRUCT_SET(res1451_1235, ((long) 0), aux1452_1236);
	       {
		  obj_t aux_2201;
		  aux_2201 = STRUCT_KEY(res1451_1235);
		  STRUCT_KEY_SET(aux1452_1236, aux_2201);
	       }
	       {
		  obj_t aux_2204;
		  aux_2204 = CNST_TABLE_REF(((long) 4));
		  STRUCT_KEY_SET(res1451_1235, aux_2204);
	       }
	       return res1451_1235;
	    }
	 }
      }
   }
}


/* callcc! */ node_t 
callcc__192_callcc_walk(node_t node_9)
{
   {
      obj_t method1760_1260;
      obj_t class1765_1261;
      {
	 obj_t arg1768_1258;
	 obj_t arg1769_1259;
	 {
	    object_t obj_1633;
	    obj_1633 = (object_t) (node_9);
	    {
	       obj_t pre_method_105_1634;
	       pre_method_105_1634 = PROCEDURE_REF(callcc__env_142_callcc_walk, ((long) 2));
	       if (INTEGERP(pre_method_105_1634))
		 {
		    PROCEDURE_SET(callcc__env_142_callcc_walk, ((long) 2), BUNSPEC);
		    arg1768_1258 = pre_method_105_1634;
		 }
	       else
		 {
		    long obj_class_num_177_1639;
		    obj_class_num_177_1639 = TYPE(obj_1633);
		    {
		       obj_t arg1177_1640;
		       arg1177_1640 = PROCEDURE_REF(callcc__env_142_callcc_walk, ((long) 1));
		       {
			  long arg1178_1644;
			  {
			     long arg1179_1645;
			     arg1179_1645 = OBJECT_TYPE;
			     arg1178_1644 = (obj_class_num_177_1639 - arg1179_1645);
			  }
			  arg1768_1258 = VECTOR_REF(arg1177_1640, arg1178_1644);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1650;
	    object_1650 = (object_t) (node_9);
	    {
	       long arg1180_1651;
	       {
		  long arg1181_1652;
		  long arg1182_1653;
		  arg1181_1652 = TYPE(object_1650);
		  arg1182_1653 = OBJECT_TYPE;
		  arg1180_1651 = (arg1181_1652 - arg1182_1653);
	       }
	       {
		  obj_t vector_1657;
		  vector_1657 = _classes__134___object;
		  arg1769_1259 = VECTOR_REF(vector_1657, arg1180_1651);
	       }
	    }
	 }
	 {
	    obj_t aux_2223;
	    method1760_1260 = arg1768_1258;
	    class1765_1261 = arg1769_1259;
	    {
	       if (INTEGERP(method1760_1260))
		 {
		    switch ((long) CINT(method1760_1260))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_2226;
			    aux_2226 = (atom_t) (node_9);
			    aux_2223 = (obj_t) (aux_2226);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_2229;
			    aux_2229 = (kwote_t) (node_9);
			    aux_2223 = (obj_t) (aux_2229);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1269;
			    node_1269 = (var_t) (node_9);
			    {
			       variable_t var_1270;
			       var_1270 = (((var_t) CREF(node_1269))->variable);
			       {
				  obj_t var_1271;
				  obj_t alpha_1272;
				  var_1271 = (obj_t) (var_1270);
				  alpha_1272 = (((variable_t) CREF(var_1270))->fast_alpha_7);
				loop_1273:
				  {
				     bool_t test1773_1275;
				     test1773_1275 = is_a__118___object(alpha_1272, local_ast_var);
				     if (test1773_1275)
				       {
					  {
					     variable_t val1213_1663;
					     val1213_1663 = (variable_t) (alpha_1272);
					     ((((var_t) CREF(node_1269))->variable) = ((variable_t) val1213_1663), BUNSPEC);
					  }
					  {
					     obj_t alpha_2239;
					     obj_t var_2238;
					     var_2238 = alpha_1272;
					     {
						variable_t obj_1664;
						obj_1664 = (variable_t) (alpha_1272);
						alpha_2239 = (((variable_t) CREF(obj_1664))->fast_alpha_7);
					     }
					     alpha_1272 = alpha_2239;
					     var_1271 = var_2238;
					     goto loop_1273;
					  }
				       }
				     else
				       {
					  bool_t test1775_1277;
					  test1775_1277 = is_a__118___object(alpha_1272, local_ast_var);
					  if (test1775_1277)
					    {
					       {
						  variable_t val1213_1667;
						  val1213_1667 = (variable_t) (alpha_1272);
						  ((((var_t) CREF(node_1269))->variable) = ((variable_t) val1213_1667), BUNSPEC);
					       }
					       {
						  node_t aux_2246;
						  aux_2246 = callcc__192_callcc_walk((node_t) (node_1269));
						  aux_2223 = (obj_t) (aux_2246);
					       }
					    }
					  else
					    {
					       bool_t test1776_1278;
					       test1776_1278 = is_a__118___object(var_1271, global_ast_var);
					       if (test1776_1278)
						 {
						    aux_2223 = (obj_t) (node_1269);
						 }
					       else
						 {
						    if (celled__113_callcc_walk((variable_t) (var_1271)))
						      {
							 {
							    obj_t arg1778_1280;
							    obj_t arg1779_1281;
							    {
							       node_t obj_1669;
							       obj_1669 = (node_t) (node_1269);
							       arg1778_1280 = (((node_t) CREF(obj_1669))->loc);
							    }
							    arg1779_1281 = ____74_type_cache;
							    {
							       box_ref_242_t res1893_1684;
							       {
								  type_t type_1671;
								  obj_t key_1673;
								  type_1671 = (type_t) (arg1779_1281);
								  key_1673 = BINT(((long) -1));
								  {
								     box_ref_242_t new1414_1675;
								     new1414_1675 = ((box_ref_242_t) BREF(GC_MALLOC(sizeof(struct box_ref_242))));
								     {
									long arg1663_1676;
									arg1663_1676 = class_num_218___object(box_ref_242_ast_node);
									{
									   obj_t obj_1682;
									   obj_1682 = (obj_t) (new1414_1675);
									   (((obj_t) CREF(obj_1682))->header = MAKE_HEADER(arg1663_1676, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_2264;
									aux_2264 = (object_t) (new1414_1675);
									OBJECT_WIDENING_SET(aux_2264, BFALSE);
								     }
								     ((((box_ref_242_t) CREF(new1414_1675))->loc) = ((obj_t) arg1778_1280), BUNSPEC);
								     ((((box_ref_242_t) CREF(new1414_1675))->type) = ((type_t) type_1671), BUNSPEC);
								     ((((box_ref_242_t) CREF(new1414_1675))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								     ((((box_ref_242_t) CREF(new1414_1675))->key) = ((obj_t) key_1673), BUNSPEC);
								     ((((box_ref_242_t) CREF(new1414_1675))->var) = ((var_t) node_1269), BUNSPEC);
								     res1893_1684 = new1414_1675;
								  }
							       }
							       aux_2223 = (obj_t) (res1893_1684);
							    }
							 }
						      }
						    else
						      {
							 aux_2223 = (obj_t) (node_1269);
						      }
						 }
					    }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1284;
			    node_1284 = (sequence_t) (node_9);
			    callcc___127_callcc_walk((((sequence_t) CREF(node_1284))->nodes));
			    aux_2223 = (obj_t) (node_1284);
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1286;
			    node_1286 = (app_t) (node_9);
			    callcc___127_callcc_walk((((app_t) CREF(node_1286))->args));
			    aux_2223 = (obj_t) (node_1286);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1289;
			    node_1289 = (app_ly_162_t) (node_9);
			    {
			       node_t arg1788_1291;
			       arg1788_1291 = callcc__192_callcc_walk((((app_ly_162_t) CREF(node_1289))->fun));
			       ((((app_ly_162_t) CREF(node_1289))->fun) = ((node_t) arg1788_1291), BUNSPEC);
			    }
			    {
			       node_t arg1790_1293;
			       arg1790_1293 = callcc__192_callcc_walk((((app_ly_162_t) CREF(node_1289))->arg));
			       ((((app_ly_162_t) CREF(node_1289))->arg) = ((node_t) arg1790_1293), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1289);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1295;
			    node_1295 = (funcall_t) (node_9);
			    {
			       node_t arg1792_1297;
			       arg1792_1297 = callcc__192_callcc_walk((((funcall_t) CREF(node_1295))->fun));
			       ((((funcall_t) CREF(node_1295))->fun) = ((node_t) arg1792_1297), BUNSPEC);
			    }
			    callcc___127_callcc_walk((((funcall_t) CREF(node_1295))->args));
			    aux_2223 = (obj_t) (node_1295);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1300;
			    node_1300 = (pragma_t) (node_9);
			    callcc___127_callcc_walk((((pragma_t) CREF(node_1300))->args));
			    aux_2223 = (obj_t) (node_1300);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1302;
			    node_1302 = (cast_t) (node_9);
			    callcc__192_callcc_walk((((cast_t) CREF(node_1302))->arg));
			    aux_2223 = (obj_t) (node_1302);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1304;
			    node_1304 = (setq_t) (node_9);
			    {
			       node_t arg1797_1305;
			       arg1797_1305 = callcc__192_callcc_walk((((setq_t) CREF(node_1304))->value));
			       ((((setq_t) CREF(node_1304))->value) = ((node_t) arg1797_1305), BUNSPEC);
			    }
			    {
			       variable_t var_1307;
			       {
				  var_t arg1824_1336;
				  arg1824_1336 = (((setq_t) CREF(node_1304))->var);
				  var_1307 = (((var_t) CREF(arg1824_1336))->variable);
			       }
			       {
				  obj_t var_1308;
				  obj_t alpha_1309;
				  var_1308 = (obj_t) (var_1307);
				  alpha_1309 = (((variable_t) CREF(var_1307))->fast_alpha_7);
				loop_1310:
				  {
				     bool_t test1801_1312;
				     test1801_1312 = is_a__118___object(alpha_1309, local_ast_var);
				     if (test1801_1312)
				       {
					  {
					     var_t arg1802_1313;
					     arg1802_1313 = (((setq_t) CREF(node_1304))->var);
					     {
						variable_t val1213_1708;
						val1213_1708 = (variable_t) (alpha_1309);
						((((var_t) CREF(arg1802_1313))->variable) = ((variable_t) val1213_1708), BUNSPEC);
					     }
					  }
					  {
					     obj_t alpha_2319;
					     obj_t var_2318;
					     var_2318 = alpha_1309;
					     {
						variable_t obj_1709;
						obj_1709 = (variable_t) (alpha_1309);
						alpha_2319 = (((variable_t) CREF(obj_1709))->fast_alpha_7);
					     }
					     alpha_1309 = alpha_2319;
					     var_1308 = var_2318;
					     goto loop_1310;
					  }
				       }
				     else
				       {
					  bool_t test1804_1315;
					  test1804_1315 = is_a__118___object(var_1308, global_ast_var);
					  if (test1804_1315)
					    {
					       aux_2223 = (obj_t) (node_1304);
					    }
					  else
					    {
					       if (celled__113_callcc_walk((variable_t) (var_1308)))
						 {
						    {
						       local_t a_var_30_1317;
						       obj_t loc_1318;
						       a_var_30_1317 = make_local_svar_140_ast_local(CNST_TABLE_REF(((long) 5)), (type_t) (_obj__252_type_cache));
						       {
							  node_t obj_1711;
							  obj_1711 = (node_t) (node_1304);
							  loc_1318 = (((node_t) CREF(obj_1711))->loc);
						       }
						       {
							  obj_t arg1807_1320;
							  obj_t arg1809_1322;
							  box_set__221_t arg1810_1323;
							  arg1807_1320 = ____74_type_cache;
							  {
							     obj_t arg1811_1324;
							     {
								obj_t aux_2335;
								obj_t aux_2333;
								{
								   node_t aux_2336;
								   aux_2336 = (((setq_t) CREF(node_1304))->value);
								   aux_2335 = (obj_t) (aux_2336);
								}
								aux_2333 = (obj_t) (a_var_30_1317);
								arg1811_1324 = MAKE_PAIR(aux_2333, aux_2335);
							     }
							     {
								obj_t list1812_1325;
								list1812_1325 = MAKE_PAIR(arg1811_1324, BNIL);
								arg1809_1322 = list1812_1325;
							     }
							  }
							  {
							     obj_t arg1816_1329;
							     var_t arg1817_1330;
							     var_t arg1818_1331;
							     arg1816_1329 = ____74_type_cache;
							     arg1817_1330 = (((setq_t) CREF(node_1304))->var);
							     {
								obj_t arg1821_1333;
								arg1821_1333 = ____74_type_cache;
								{
								   var_t res1894_1727;
								   {
								      type_t type_1718;
								      variable_t variable_1719;
								      type_1718 = (type_t) (arg1821_1333);
								      variable_1719 = (variable_t) (a_var_30_1317);
								      {
									 var_t new1207_1720;
									 new1207_1720 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
									 {
									    long arg1705_1721;
									    arg1705_1721 = class_num_218___object(var_ast_node);
									    {
									       obj_t obj_1725;
									       obj_1725 = (obj_t) (new1207_1720);
									       (((obj_t) CREF(obj_1725))->header = MAKE_HEADER(arg1705_1721, 0), BUNSPEC);
									    }
									 }
									 {
									    object_t aux_2348;
									    aux_2348 = (object_t) (new1207_1720);
									    OBJECT_WIDENING_SET(aux_2348, BFALSE);
									 }
									 ((((var_t) CREF(new1207_1720))->loc) = ((obj_t) loc_1318), BUNSPEC);
									 ((((var_t) CREF(new1207_1720))->type) = ((type_t) type_1718), BUNSPEC);
									 ((((var_t) CREF(new1207_1720))->variable) = ((variable_t) variable_1719), BUNSPEC);
									 res1894_1727 = new1207_1720;
								      }
								   }
								   arg1818_1331 = res1894_1727;
								}
							     }
							     {
								box_set__221_t res1895_1740;
								{
								   type_t type_1729;
								   node_t value_1731;
								   type_1729 = (type_t) (arg1816_1329);
								   value_1731 = (node_t) (arg1818_1331);
								   {
								      box_set__221_t new1426_1732;
								      new1426_1732 = ((box_set__221_t) BREF(GC_MALLOC(sizeof(struct box_set__221))));
								      {
									 long arg1659_1733;
									 arg1659_1733 = class_num_218___object(box_set__221_ast_node);
									 {
									    obj_t obj_1738;
									    obj_1738 = (obj_t) (new1426_1732);
									    (((obj_t) CREF(obj_1738))->header = MAKE_HEADER(arg1659_1733, 0), BUNSPEC);
									 }
								      }
								      {
									 object_t aux_2360;
									 aux_2360 = (object_t) (new1426_1732);
									 OBJECT_WIDENING_SET(aux_2360, BFALSE);
								      }
								      ((((box_set__221_t) CREF(new1426_1732))->loc) = ((obj_t) loc_1318), BUNSPEC);
								      ((((box_set__221_t) CREF(new1426_1732))->type) = ((type_t) type_1729), BUNSPEC);
								      ((((box_set__221_t) CREF(new1426_1732))->var) = ((var_t) arg1817_1330), BUNSPEC);
								      ((((box_set__221_t) CREF(new1426_1732))->value) = ((node_t) value_1731), BUNSPEC);
								      res1895_1740 = new1426_1732;
								   }
								}
								arg1810_1323 = res1895_1740;
							     }
							  }
							  {
							     let_var_6_t res1896_1759;
							     {
								type_t type_1742;
								obj_t key_1744;
								node_t body_1746;
								type_1742 = (type_t) (arg1807_1320);
								key_1744 = BINT(((long) -1));
								body_1746 = (node_t) (arg1810_1323);
								{
								   let_var_6_t new1366_1748;
								   new1366_1748 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
								   {
								      long arg1673_1749;
								      arg1673_1749 = class_num_218___object(let_var_6_ast_node);
								      {
									 obj_t obj_1757;
									 obj_1757 = (obj_t) (new1366_1748);
									 (((obj_t) CREF(obj_1757))->header = MAKE_HEADER(arg1673_1749, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_2374;
								      aux_2374 = (object_t) (new1366_1748);
								      OBJECT_WIDENING_SET(aux_2374, BFALSE);
								   }
								   ((((let_var_6_t) CREF(new1366_1748))->loc) = ((obj_t) loc_1318), BUNSPEC);
								   ((((let_var_6_t) CREF(new1366_1748))->type) = ((type_t) type_1742), BUNSPEC);
								   ((((let_var_6_t) CREF(new1366_1748))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
								   ((((let_var_6_t) CREF(new1366_1748))->key) = ((obj_t) key_1744), BUNSPEC);
								   ((((let_var_6_t) CREF(new1366_1748))->bindings) = ((obj_t) arg1809_1322), BUNSPEC);
								   ((((let_var_6_t) CREF(new1366_1748))->body) = ((node_t) body_1746), BUNSPEC);
								   ((((let_var_6_t) CREF(new1366_1748))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
								   res1896_1759 = new1366_1748;
								}
							     }
							     aux_2223 = (obj_t) (res1896_1759);
							  }
						       }
						    }
						 }
					       else
						 {
						    aux_2223 = (obj_t) (node_1304);
						 }
					    }
				       }
				  }
			       }
			    }
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1337;
			    node_1337 = (conditional_t) (node_9);
			    {
			       node_t arg1826_1339;
			       arg1826_1339 = callcc__192_callcc_walk((((conditional_t) CREF(node_1337))->test));
			       ((((conditional_t) CREF(node_1337))->test) = ((node_t) arg1826_1339), BUNSPEC);
			    }
			    {
			       node_t arg1829_1341;
			       arg1829_1341 = callcc__192_callcc_walk((((conditional_t) CREF(node_1337))->true));
			       ((((conditional_t) CREF(node_1337))->true) = ((node_t) arg1829_1341), BUNSPEC);
			    }
			    {
			       node_t arg1831_1343;
			       arg1831_1343 = callcc__192_callcc_walk((((conditional_t) CREF(node_1337))->false));
			       ((((conditional_t) CREF(node_1337))->false) = ((node_t) arg1831_1343), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1337);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1345;
			    node_1345 = (fail_t) (node_9);
			    {
			       node_t arg1833_1347;
			       arg1833_1347 = callcc__192_callcc_walk((((fail_t) CREF(node_1345))->proc));
			       ((((fail_t) CREF(node_1345))->proc) = ((node_t) arg1833_1347), BUNSPEC);
			    }
			    {
			       node_t arg1835_1349;
			       arg1835_1349 = callcc__192_callcc_walk((((fail_t) CREF(node_1345))->msg));
			       ((((fail_t) CREF(node_1345))->msg) = ((node_t) arg1835_1349), BUNSPEC);
			    }
			    {
			       node_t arg1837_1351;
			       arg1837_1351 = callcc__192_callcc_walk((((fail_t) CREF(node_1345))->obj));
			       ((((fail_t) CREF(node_1345))->obj) = ((node_t) arg1837_1351), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1345);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1353;
			    node_1353 = (select_t) (node_9);
			    {
			       node_t arg1839_1355;
			       arg1839_1355 = callcc__192_callcc_walk((((select_t) CREF(node_1353))->test));
			       ((((select_t) CREF(node_1353))->test) = ((node_t) arg1839_1355), BUNSPEC);
			    }
			    {
			       obj_t l1485_1357;
			       l1485_1357 = (((select_t) CREF(node_1353))->clauses);
			     lname1486_1358:
			       if (PAIRP(l1485_1357))
				 {
				    {
				       obj_t clause_1361;
				       clause_1361 = CAR(l1485_1357);
				       {
					  node_t arg1847_1362;
					  {
					     node_t aux_2417;
					     {
						obj_t aux_2418;
						aux_2418 = CDR(clause_1361);
						aux_2417 = (node_t) (aux_2418);
					     }
					     arg1847_1362 = callcc__192_callcc_walk(aux_2417);
					  }
					  {
					     obj_t aux_2422;
					     aux_2422 = (obj_t) (arg1847_1362);
					     SET_CDR(clause_1361, aux_2422);
					  }
				       }
				    }
				    {
				       obj_t l1485_2425;
				       l1485_2425 = CDR(l1485_1357);
				       l1485_1357 = l1485_2425;
				       goto lname1486_1358;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2223 = (obj_t) (node_1353);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1365;
			    node_1365 = (let_fun_218_t) (node_9);
			    {
			       obj_t l1488_1367;
			       l1488_1367 = (((let_fun_218_t) CREF(node_1365))->locals);
			     lname1489_1368:
			       if (PAIRP(l1488_1367))
				 {
				    callcc_fun__197_callcc_walk(CAR(l1488_1367));
				    {
				       obj_t l1488_2434;
				       l1488_2434 = CDR(l1488_1367);
				       l1488_1367 = l1488_2434;
				       goto lname1489_1368;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1857_1373;
			       arg1857_1373 = callcc__192_callcc_walk((((let_fun_218_t) CREF(node_1365))->body));
			       ((((let_fun_218_t) CREF(node_1365))->body) = ((node_t) arg1857_1373), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1365);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1375;
			    node_1375 = (let_var_6_t) (node_9);
			    {
			       node_t arg1859_1377;
			       arg1859_1377 = callcc__192_callcc_walk((((let_var_6_t) CREF(node_1375))->body));
			       ((((let_var_6_t) CREF(node_1375))->body) = ((node_t) arg1859_1377), BUNSPEC);
			    }
			    {
			       obj_t l1491_1379;
			       l1491_1379 = (((let_var_6_t) CREF(node_1375))->bindings);
			     lname1492_1380:
			       if (PAIRP(l1491_1379))
				 {
				    {
				       obj_t binding_1383;
				       binding_1383 = CAR(l1491_1379);
				       {
					  obj_t var_1384;
					  var_1384 = CAR(binding_1383);
					  {
					     node_t arg1863_1386;
					     {
						node_t aux_2449;
						{
						   obj_t aux_2450;
						   aux_2450 = CDR(binding_1383);
						   aux_2449 = (node_t) (aux_2450);
						}
						arg1863_1386 = callcc__192_callcc_walk(aux_2449);
					     }
					     {
						obj_t aux_2454;
						aux_2454 = (obj_t) (arg1863_1386);
						SET_CDR(binding_1383, aux_2454);
					     }
					  }
					  if (celled__113_callcc_walk((variable_t) (var_1384)))
					    {
					       {
						  local_t obj_1805;
						  type_t val1093_1806;
						  obj_1805 = (local_t) (var_1384);
						  val1093_1806 = (type_t) (_obj__252_type_cache);
						  ((((local_t) CREF(obj_1805))->type) = ((type_t) val1093_1806), BUNSPEC);
					       }
					       {
						  make_box_202_t arg1865_1388;
						  {
						     node_t aux_2463;
						     {
							obj_t aux_2464;
							aux_2464 = CDR(binding_1383);
							aux_2463 = (node_t) (aux_2464);
						     }
						     arg1865_1388 = a_make_cell_117_callcc_walk(aux_2463, (variable_t) (var_1384));
						  }
						  {
						     obj_t aux_2469;
						     aux_2469 = (obj_t) (arg1865_1388);
						     SET_CDR(binding_1383, aux_2469);
						  }
					       }
					    }
					  else
					    {
					       BUNSPEC;
					    }
				       }
				    }
				    {
				       obj_t l1491_2472;
				       l1491_2472 = CDR(l1491_1379);
				       l1491_1379 = l1491_2472;
				       goto lname1492_1380;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_2223 = (obj_t) (node_1375);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1391;
			    node_1391 = (set_ex_it_116_t) (node_9);
			    {
			       node_t arg1868_1392;
			       arg1868_1392 = callcc__192_callcc_walk((((set_ex_it_116_t) CREF(node_1391))->body));
			       ((((set_ex_it_116_t) CREF(node_1391))->body) = ((node_t) arg1868_1392), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1391);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1394;
			    node_1394 = (jump_ex_it_184_t) (node_9);
			    {
			       node_t arg1870_1396;
			       arg1870_1396 = callcc__192_callcc_walk((((jump_ex_it_184_t) CREF(node_1394))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1394))->exit) = ((node_t) arg1870_1396), BUNSPEC);
			    }
			    {
			       node_t arg1874_1398;
			       arg1874_1398 = callcc__192_callcc_walk((((jump_ex_it_184_t) CREF(node_1394))->value));
			       ((((jump_ex_it_184_t) CREF(node_1394))->value) = ((node_t) arg1874_1398), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1394);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1400;
			    node_1400 = (make_box_202_t) (node_9);
			    {
			       node_t arg1876_1401;
			       arg1876_1401 = callcc__192_callcc_walk((((make_box_202_t) CREF(node_1400))->value));
			       ((((make_box_202_t) CREF(node_1400))->value) = ((node_t) arg1876_1401), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1400);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_ref_242_t aux_2494;
			    aux_2494 = (box_ref_242_t) (node_9);
			    aux_2223 = (obj_t) (aux_2494);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_set__221_t node_1404;
			    node_1404 = (box_set__221_t) (node_9);
			    {
			       node_t arg1878_1406;
			       arg1878_1406 = callcc__192_callcc_walk((((box_set__221_t) CREF(node_1404))->value));
			       ((((box_set__221_t) CREF(node_1404))->value) = ((node_t) arg1878_1406), BUNSPEC);
			    }
			    aux_2223 = (obj_t) (node_1404);
			 }
			 break;
		      default:
		       case_else1766_1264:
			 if (PROCEDUREP(method1760_1260))
			   {
			      aux_2223 = PROCEDURE_ENTRY(method1760_1260) (method1760_1260, (obj_t) (node_9), BEOA);
			   }
			 else
			   {
			      obj_t fun1755_1254;
			      fun1755_1254 = PROCEDURE_REF(callcc__env_142_callcc_walk, ((long) 0));
			      aux_2223 = PROCEDURE_ENTRY(fun1755_1254) (fun1755_1254, (obj_t) (node_9), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1766_1264;
		 }
	    }
	    return (node_t) (aux_2223);
	 }
      }
   }
}


/* _callcc!1903 */ obj_t 
_callcc_1903_141_callcc_walk(obj_t env_1848, obj_t node_1849)
{
   {
      node_t aux_2514;
      aux_2514 = callcc__192_callcc_walk((node_t) (node_1849));
      return (obj_t) (aux_2514);
   }
}


/* callcc!-default1496 */ node_t 
callcc__default1496_228_callcc_walk(node_t node_10)
{
   FAILURE(CNST_TABLE_REF(((long) 6)), string1912_callcc_walk, (obj_t) (node_10));
}


/* _callcc!-default1496 */ obj_t 
_callcc__default1496_165_callcc_walk(obj_t env_1850, obj_t node_1851)
{
   {
      node_t aux_2521;
      aux_2521 = callcc__default1496_228_callcc_walk((node_t) (node_1851));
      return (obj_t) (aux_2521);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_callcc_walk()
{
   module_initialization_70_tools_speek(((long) 0), "CALLCC_WALK");
   module_initialization_70_tools_error(((long) 0), "CALLCC_WALK");
   module_initialization_70_engine_pass(((long) 0), "CALLCC_WALK");
   module_initialization_70_type_type(((long) 0), "CALLCC_WALK");
   module_initialization_70_ast_var(((long) 0), "CALLCC_WALK");
   module_initialization_70_ast_node(((long) 0), "CALLCC_WALK");
   module_initialization_70_tools_shape(((long) 0), "CALLCC_WALK");
   module_initialization_70_type_cache(((long) 0), "CALLCC_WALK");
   module_initialization_70_ast_local(((long) 0), "CALLCC_WALK");
   return module_initialization_70_engine_param(((long) 0), "CALLCC_WALK");
}
