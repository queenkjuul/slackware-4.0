/*===========================================================================*/
/*   (Ieee/equiv.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>


/* Object type definitions */

extern bool_t bigloo_strcmp(obj_t, obj_t);
static obj_t method_init_76___r4_equivalence_6_2();
static obj_t _equal__165___r4_equivalence_6_2(obj_t, obj_t, obj_t);
static obj_t _eq__190___r4_equivalence_6_2(obj_t, obj_t, obj_t);
static obj_t _eqv__158___r4_equivalence_6_2(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern bool_t eqv__112___r4_equivalence_6_2(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_equivalence_6_2();
extern bool_t ucs2_strcmp(obj_t, obj_t);
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
extern bool_t eq__100___r4_equivalence_6_2(obj_t, obj_t);
static obj_t require_initialization_114___r4_equivalence_6_2 = BUNSPEC;
extern bool_t object_equal__12___object(object_t, object_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( equal__env_47___r4_equivalence_6_2, _equal__165___r4_equivalence_6_21255, _equal__165___r4_equivalence_6_2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( eqv__env_202___r4_equivalence_6_2, _eqv__158___r4_equivalence_6_21256, _eqv__158___r4_equivalence_6_2, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( eq__env_189___r4_equivalence_6_2, _eq__190___r4_equivalence_6_21257, _eq__190___r4_equivalence_6_2, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___r4_equivalence_6_2(long checksum_764, char * from_765)
{
if(CBOOL(require_initialization_114___r4_equivalence_6_2)){
require_initialization_114___r4_equivalence_6_2 = BBOOL(((bool_t)0));
imported_modules_init_94___r4_equivalence_6_2();
method_init_76___r4_equivalence_6_2();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* eq? */bool_t eq__100___r4_equivalence_6_2(obj_t obj1_1, obj_t obj2_2)
{
return (obj1_1==obj2_2);
}


/* _eq? */obj_t _eq__190___r4_equivalence_6_2(obj_t env_753, obj_t obj1_754, obj_t obj2_755)
{
{
bool_t aux_772;
{
obj_t obj1_762;
obj_t obj2_763;
obj1_762 = obj1_754;
obj2_763 = obj2_755;
aux_772 = (obj1_762==obj2_763);
}
return BBOOL(aux_772);
}
}


/* eqv? */bool_t eqv__112___r4_equivalence_6_2(obj_t obj1_3, obj_t obj2_4)
{
if(INTEGERP(obj1_3)){
if(INTEGERP(obj2_4)){
return _2__95___r4_numbers_6_5(obj1_3, obj2_4);
}
 else {
return ((bool_t)0);
}
}
 else {
if(REALP(obj1_3)){
if(REALP(obj2_4)){
return _2__95___r4_numbers_6_5(obj1_3, obj2_4);
}
 else {
return ((bool_t)0);
}
}
 else {
if(SYMBOLP(obj1_3)){
if(SYMBOLP(obj2_4)){
obj_t arg1033_398;
obj_t arg1034_399;
arg1033_398 = SYMBOL_TO_STRING(obj1_3);
arg1034_399 = SYMBOL_TO_STRING(obj2_4);
return bigloo_strcmp(arg1033_398, arg1034_399);
}
 else {
return ((bool_t)0);
}
}
 else {
return (obj1_3==obj2_4);
}
}
}
}


/* _eqv? */obj_t _eqv__158___r4_equivalence_6_2(obj_t env_756, obj_t obj1_757, obj_t obj2_758)
{
{
bool_t aux_793;
aux_793 = eqv__112___r4_equivalence_6_2(obj1_757, obj2_758);
return BBOOL(aux_793);
}
}


/* equal? */bool_t equal__25___r4_equivalence_6_2(obj_t obj1_5, obj_t obj2_6)
{
equal__25___r4_equivalence_6_2:
if((obj1_5==obj2_6)){
return ((bool_t)1);
}
 else {
bool_t test1036_401;
test1036_401 = INTEGERP(obj1_5);
if(test1036_401){
return ((bool_t)0);
}
 else {
if(SYMBOLP(obj1_5)){
return ((bool_t)0);
}
 else {
if(UCS2P(obj1_5)){
return ((bool_t)0);
}
 else {
if(PAIRP(obj1_5)){
if(PAIRP(obj2_6)){
bool_t _andtest_1009_406;
_andtest_1009_406 = equal__25___r4_equivalence_6_2(CAR(obj1_5), CAR(obj2_6));
if(_andtest_1009_406){
obj_t obj2_814;
obj_t obj1_812;
obj1_812 = CDR(obj1_5);
obj2_814 = CDR(obj2_6);
obj2_6 = obj2_814;
obj1_5 = obj1_812;
goto equal__25___r4_equivalence_6_2;
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
 else {
if(VECTORP(obj1_5)){
{
long lobj1_412;
lobj1_412 = VECTOR_LENGTH(obj1_5);
if(VECTORP(obj2_6)){
bool_t test_821;
{
long aux_822;
aux_822 = VECTOR_LENGTH(obj2_6);
test_821 = (aux_822==lobj1_412);
}
if(test_821){
bool_t _andtest_1012_415;
{
long arg1049_424;
long arg1050_425;
arg1049_424 = VECTOR_TAG(obj1_5);
arg1050_425 = VECTOR_TAG(obj2_6);
_andtest_1012_415 = (arg1049_424==arg1050_425);
}
if(_andtest_1012_415){
long i_416;
i_416 = (lobj1_412-((long)1));
test_417:
{
bool_t _ortest_1013_419;
_ortest_1013_419 = (i_416==((long)-1));
if(_ortest_1013_419){
return _ortest_1013_419;
}
 else {
bool_t _andtest_1014_420;
_andtest_1014_420 = equal__25___r4_equivalence_6_2(VECTOR_REF(obj1_5, i_416), VECTOR_REF(obj2_6, i_416));
if(_andtest_1014_420){
long i_835;
i_835 = (i_416-((long)1));
i_416 = i_835;
goto test_417;
}
 else {
return ((bool_t)0);
}
}
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
if(STRINGP(obj1_5)){
if(STRINGP(obj2_6)){
return bigloo_strcmp(obj1_5, obj2_6);
}
 else {
return ((bool_t)0);
}
}
 else {
bool_t test1053_429;
test1053_429 = REALP(obj1_5);
if(test1053_429){
if(REALP(obj2_6)){
double aux_849;
double aux_847;
aux_849 = REAL_TO_DOUBLE(obj2_6);
aux_847 = REAL_TO_DOUBLE(obj1_5);
return (aux_847==aux_849);
}
 else {
return ((bool_t)0);
}
}
 else {
if(STRUCTP(obj1_5)){
{
long lobj1_432;
lobj1_432 = STRUCT_LENGTH(obj1_5);
if(STRUCTP(obj2_6)){
bool_t test_857;
{
long aux_858;
aux_858 = STRUCT_LENGTH(obj2_6);
test_857 = (aux_858==lobj1_432);
}
if(test_857){
long i_435;
i_435 = (lobj1_432-((long)1));
test_436:
{
bool_t _ortest_1019_438;
_ortest_1019_438 = (i_435==((long)-1));
if(_ortest_1019_438){
return _ortest_1019_438;
}
 else {
bool_t _andtest_1020_439;
_andtest_1020_439 = equal__25___r4_equivalence_6_2(STRUCT_REF(obj1_5, i_435), STRUCT_REF(obj2_6, i_435));
if(_andtest_1020_439){
long i_867;
i_867 = (i_435-((long)1));
i_435 = i_867;
goto test_436;
}
 else {
return ((bool_t)0);
}
}
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
}
 else {
if(CELLP(obj1_5)){
if(CELLP(obj2_6)){
obj_t arg1061_446;
obj_t arg1062_447;
arg1061_446 = CELL_REF(obj1_5);
arg1062_447 = CELL_REF(obj2_6);
{
obj_t obj2_877;
obj_t obj1_876;
obj1_876 = arg1061_446;
obj2_877 = arg1062_447;
obj2_6 = obj2_877;
obj1_5 = obj1_876;
goto equal__25___r4_equivalence_6_2;
}
}
 else {
return ((bool_t)0);
}
}
 else {
bool_t test_878;
if(test1036_401){
test_878 = ((bool_t)1);
}
 else {
test_878 = test1053_429;
}
if(test_878){
{
bool_t test_880;
if(INTEGERP(obj2_6)){
test_880 = ((bool_t)1);
}
 else {
test_880 = REALP(obj2_6);
}
if(test_880){
return _2__95___r4_numbers_6_5(obj1_5, obj2_6);
}
 else {
return ((bool_t)0);
}
}
}
 else {
bool_t test1064_450;
test1064_450 = (POINTERP( obj1_5 ) && (TYPE( obj1_5 ) >= OBJECT_TYPE));
if(test1064_450){
{
bool_t _andtest_1023_451;
_andtest_1023_451 = (POINTERP( obj2_6 ) && (TYPE( obj2_6 ) >= OBJECT_TYPE));
if(_andtest_1023_451){
return object_equal__12___object((object_t)(obj1_5), (object_t)(obj2_6));
}
 else {
return ((bool_t)0);
}
}
}
 else {
if(UCS2_STRINGP(obj1_5)){
if(UCS2_STRINGP(obj2_6)){
return ucs2_strcmp(obj1_5, obj2_6);
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
}
}
}
}
}
}
}
}
}
}
}
}


/* _equal? */obj_t _equal__165___r4_equivalence_6_2(obj_t env_759, obj_t obj1_760, obj_t obj2_761)
{
{
bool_t aux_897;
aux_897 = equal__25___r4_equivalence_6_2(obj1_760, obj2_761);
return BBOOL(aux_897);
}
}


/* method-init */obj_t method_init_76___r4_equivalence_6_2()
{
return BUNSPEC;
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_equivalence_6_2()
{
return module_initialization_70___error(((long)0), "__R4_EQUIVALENCE_6_2");
}

