/*===========================================================================*/
/*   (Ieee/flonum.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern double string__real_248___r4_numbers_6_5_flonum(char *);
static obj_t _positivefl_1233_38___r4_numbers_6_5_flonum(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t _atan_1fl1257_190___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double atan_2fl_180___r4_numbers_6_5_flonum(double, double);
extern double min_2fl_9___r4_numbers_6_5_flonum(double, double);
extern double atan_1fl_210___r4_numbers_6_5_flonum(double);
extern double expfl___r4_numbers_6_5_flonum(double);
static obj_t _negativefl_1234_197___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _logfl1250___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _expfl1249___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _sqrtfl_ur1261_237___r4_numbers_6_5_flonum(obj_t, obj_t);
extern obj_t make_real(double);
static obj_t _truncatefl1247___r4_numbers_6_5_flonum(obj_t, obj_t);
extern char * real__string_120___r4_numbers_6_5_flonum(double);
static obj_t __fl1235_145___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t __fl1236_168___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern bool_t __fl_116___r4_numbers_6_5_flonum(double, double);
static obj_t __fl1238_237___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern bool_t negativefl__17___r4_numbers_6_5_flonum(double);
extern bool_t _fl_187___r4_numbers_6_5_flonum(double, double);
extern double atanfl___r4_numbers_6_5_flonum(double, obj_t);
static obj_t _exptfl1262___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern bool_t _fl_139___r4_numbers_6_5_flonum(double, double);
extern double logfl___r4_numbers_6_5_flonum(double);
extern bool_t zerofl__232___r4_numbers_6_5_flonum(double);
extern double ceilingfl___r4_numbers_6_5_flonum(double);
extern bool_t _fl_236___r4_numbers_6_5_flonum(double, double);
static obj_t __fl1227_162___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern double tanfl___r4_numbers_6_5_flonum(double);
extern bool_t positivefl__131___r4_numbers_6_5_flonum(double);
static obj_t ___fl1230_58___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern double maxfl___r4_numbers_6_5_flonum(double, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _cosfl1252___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _minfl1243___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t _real__string1264_158___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _asinfl1254___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double negfl___r4_numbers_6_5_flonum(double);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _flonum__86___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double atan_2fl_ur_116___r4_numbers_6_5_flonum(double, double);
extern double floorfl___r4_numbers_6_5_flonum(double);
static obj_t _sqrtfl1260___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _min_2fl1242_179___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t ___fl1231_246___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern double exptfl___r4_numbers_6_5_flonum(double, double);
extern double acosfl___r4_numbers_6_5_flonum(double);
static obj_t _tanfl1253___r4_numbers_6_5_flonum(obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern double sqrtfl___r4_numbers_6_5_flonum(double);
static obj_t _atan_2fl1258_65___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern double asinfl___r4_numbers_6_5_flonum(double);
extern double cosfl___r4_numbers_6_5_flonum(double);
extern double absfl___r4_numbers_6_5_flonum(double);
static obj_t __fl1237_208___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t _ceilingfl1246___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _negfl1239___r4_numbers_6_5_flonum(obj_t, obj_t);
extern bool_t flonum__164___r4_numbers_6_5_flonum(obj_t);
static obj_t _floorfl1245___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double sinfl___r4_numbers_6_5_flonum(double);
static obj_t _max_2fl1241_245___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern double max_2fl_226___r4_numbers_6_5_flonum(double, double);
static obj_t _real__79___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double roundfl___r4_numbers_6_5_flonum(double);
static obj_t _zerofl_1232_54___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _roundfl1248___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t _string__real1263_20___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double sqrtfl_ur_118___r4_numbers_6_5_flonum(double);
static obj_t __fl1228_160___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern double _fl_4___r4_numbers_6_5_flonum(double, double);
static obj_t __fl1229_121___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
extern bool_t real__243___r4_numbers_6_5_flonum(obj_t);
static obj_t _absfl1244___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double truncatefl___r4_numbers_6_5_flonum(double);
static obj_t _acosfl1255___r4_numbers_6_5_flonum(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_numbers_6_5_flonum();
static obj_t symbol1866___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1865___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1864___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1862___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1861___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1859___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1860___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1858___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1857___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1856___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1854___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1853___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1852___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1851___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1849___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1850___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1848___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1847___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1842___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1841___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1839___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1840___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1838___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1837___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1836___r4_numbers_6_5_flonum = BUNSPEC;
extern double _fl_24___r4_numbers_6_5_flonum(double, double);
static obj_t symbol1835___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1834___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1833___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1832___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1831___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1829___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1830___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1828___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1827___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1826___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1825___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1824___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1823___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1822___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1821___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1819___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1820___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1818___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1817___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1816___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1815___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1814___r4_numbers_6_5_flonum = BUNSPEC;
extern bool_t __fl_135___r4_numbers_6_5_flonum(double, double);
static obj_t symbol1813___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1812___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1811___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1799___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1809___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1798___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1808___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1797___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1807___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1796___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1806___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1795___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1805___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1794___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1804___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1793___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1803___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1792___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1802___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1791___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1801___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1789___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1790___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1800___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1788___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1787___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1786___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1785___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1782___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1781___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t symbol1780___r4_numbers_6_5_flonum = BUNSPEC;
static obj_t require_initialization_114___r4_numbers_6_5_flonum = BUNSPEC;
extern double minfl___r4_numbers_6_5_flonum(double, obj_t);
static obj_t _maxfl1240___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t _sinfl1251___r4_numbers_6_5_flonum(obj_t, obj_t);
extern double _fl_172___r4_numbers_6_5_flonum(double, double);
extern char * real_to_string(double);
static obj_t _atanfl1256___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t _atan_2fl_ur1259_194___r4_numbers_6_5_flonum(obj_t, obj_t, obj_t);
static obj_t cnst_init_137___r4_numbers_6_5_flonum();
extern double _fl_93___r4_numbers_6_5_flonum(double, double);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( __fl_env_18___r4_numbers_6_5_flonum, ___fl1230_58___r4_numbers_6_5_flonum1868, ___fl1230_58___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( atan_1fl_env_38___r4_numbers_6_5_flonum, _atan_1fl1257_190___r4_numbers_6_5_flonum1869, _atan_1fl1257_190___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _fl_env_116___r4_numbers_6_5_flonum, __fl1227_162___r4_numbers_6_5_flonum1870, __fl1227_162___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( truncatefl_env_152___r4_numbers_6_5_flonum, _truncatefl1247___r4_numbers_6_5_flonum1871, _truncatefl1247___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( atan_2fl_ur_env_159___r4_numbers_6_5_flonum, _atan_2fl_ur1259_194___r4_numbers_6_5_flonum1872, _atan_2fl_ur1259_194___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( exptfl_env_131___r4_numbers_6_5_flonum, _exptfl1262___r4_numbers_6_5_flonum1873, _exptfl1262___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ceilingfl_env_56___r4_numbers_6_5_flonum, _ceilingfl1246___r4_numbers_6_5_flonum1874, _ceilingfl1246___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( positivefl__env_91___r4_numbers_6_5_flonum, _positivefl_1233_38___r4_numbers_6_5_flonum1875, _positivefl_1233_38___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __fl_env_159___r4_numbers_6_5_flonum, ___fl1231_246___r4_numbers_6_5_flonum1876, ___fl1231_246___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( flonum__env_208___r4_numbers_6_5_flonum, _flonum__86___r4_numbers_6_5_flonum1877, _flonum__86___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( min_2fl_env_107___r4_numbers_6_5_flonum, _min_2fl1242_179___r4_numbers_6_5_flonum1878, _min_2fl1242_179___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( real__string_env_192___r4_numbers_6_5_flonum, _real__string1264_158___r4_numbers_6_5_flonum1879, _real__string1264_158___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( cosfl_env_144___r4_numbers_6_5_flonum, _cosfl1252___r4_numbers_6_5_flonum1880, _cosfl1252___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( minfl_env_220___r4_numbers_6_5_flonum, _minfl1243___r4_numbers_6_5_flonum1881, va_generic_entry, _minfl1243___r4_numbers_6_5_flonum, -2 );
DEFINE_EXPORT_PROCEDURE( negativefl__env_195___r4_numbers_6_5_flonum, _negativefl_1234_197___r4_numbers_6_5_flonum1882, _negativefl_1234_197___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( asinfl_env_147___r4_numbers_6_5_flonum, _asinfl1254___r4_numbers_6_5_flonum1883, _asinfl1254___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( tanfl_env_187___r4_numbers_6_5_flonum, _tanfl1253___r4_numbers_6_5_flonum1884, _tanfl1253___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( sqrtfl_env_132___r4_numbers_6_5_flonum, _sqrtfl1260___r4_numbers_6_5_flonum1885, _sqrtfl1260___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( floorfl_env_65___r4_numbers_6_5_flonum, _floorfl1245___r4_numbers_6_5_flonum1886, _floorfl1245___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( max_2fl_env_222___r4_numbers_6_5_flonum, _max_2fl1241_245___r4_numbers_6_5_flonum1887, _max_2fl1241_245___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fl_env_209___r4_numbers_6_5_flonum, __fl1237_208___r4_numbers_6_5_flonum1888, __fl1237_208___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( zerofl__env_96___r4_numbers_6_5_flonum, _zerofl_1232_54___r4_numbers_6_5_flonum1889, _zerofl_1232_54___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( roundfl_env_120___r4_numbers_6_5_flonum, _roundfl1248___r4_numbers_6_5_flonum1890, _roundfl1248___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( real__env_20___r4_numbers_6_5_flonum, _real__79___r4_numbers_6_5_flonum1891, _real__79___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( negfl_env_102___r4_numbers_6_5_flonum, _negfl1239___r4_numbers_6_5_flonum1892, _negfl1239___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__real_env_124___r4_numbers_6_5_flonum, _string__real1263_20___r4_numbers_6_5_flonum1893, _string__real1263_20___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( atan_2fl_env_154___r4_numbers_6_5_flonum, _atan_2fl1258_65___r4_numbers_6_5_flonum1894, _atan_2fl1258_65___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fl_env_94___r4_numbers_6_5_flonum, __fl1228_160___r4_numbers_6_5_flonum1895, __fl1228_160___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fl_env_151___r4_numbers_6_5_flonum, __fl1229_121___r4_numbers_6_5_flonum1896, __fl1229_121___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( sqrtfl_ur_env_220___r4_numbers_6_5_flonum, _sqrtfl_ur1261_237___r4_numbers_6_5_flonum1897, _sqrtfl_ur1261_237___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_STRING( string1863___r4_numbers_6_5_flonum, string1863___r4_numbers_6_5_flonum1898, "STRING", 6 );
DEFINE_STRING( string1855___r4_numbers_6_5_flonum, string1855___r4_numbers_6_5_flonum1899, "sqrtfl", 6 );
DEFINE_STRING( string1846___r4_numbers_6_5_flonum, string1846___r4_numbers_6_5_flonum1900, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1844___r4_numbers_6_5_flonum, string1844___r4_numbers_6_5_flonum1901, "Domain error", 12 );
DEFINE_STRING( string1843___r4_numbers_6_5_flonum, string1843___r4_numbers_6_5_flonum1902, "atanfl", 6 );
DEFINE_EXPORT_PROCEDURE( absfl_env_6___r4_numbers_6_5_flonum, _absfl1244___r4_numbers_6_5_flonum1903, _absfl1244___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_STRING( string1810___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum1904, "PAIR", 4 );
DEFINE_STRING( string1784___r4_numbers_6_5_flonum, string1784___r4_numbers_6_5_flonum1905, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/flonum.scm", 59 );
DEFINE_STRING( string1783___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum1906, "DOUBLE", 6 );
DEFINE_EXPORT_PROCEDURE( maxfl_env_160___r4_numbers_6_5_flonum, _maxfl1240___r4_numbers_6_5_flonum1907, va_generic_entry, _maxfl1240___r4_numbers_6_5_flonum, -2 );
DEFINE_EXPORT_PROCEDURE( acosfl_env_181___r4_numbers_6_5_flonum, _acosfl1255___r4_numbers_6_5_flonum1908, _acosfl1255___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( sinfl_env_77___r4_numbers_6_5_flonum, _sinfl1251___r4_numbers_6_5_flonum1909, _sinfl1251___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( atanfl_env_100___r4_numbers_6_5_flonum, _atanfl1256___r4_numbers_6_5_flonum1910, va_generic_entry, _atanfl1256___r4_numbers_6_5_flonum, -2 );
DEFINE_REAL( real1845___r4_numbers_6_5_flonum, real1845___r4_numbers_6_5_flonum1911, 0.0 );
DEFINE_EXPORT_PROCEDURE( _fl_env_224___r4_numbers_6_5_flonum, __fl1235_145___r4_numbers_6_5_flonum1912, __fl1235_145___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( logfl_env_16___r4_numbers_6_5_flonum, _logfl1250___r4_numbers_6_5_flonum1913, _logfl1250___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( expfl_env_156___r4_numbers_6_5_flonum, _expfl1249___r4_numbers_6_5_flonum1914, _expfl1249___r4_numbers_6_5_flonum, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _fl_env_6___r4_numbers_6_5_flonum, __fl1236_168___r4_numbers_6_5_flonum1915, __fl1236_168___r4_numbers_6_5_flonum, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _fl_env_235___r4_numbers_6_5_flonum, __fl1238_237___r4_numbers_6_5_flonum1916, __fl1238_237___r4_numbers_6_5_flonum, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___r4_numbers_6_5_flonum(long checksum_1301, char * from_1302)
{
if(CBOOL(require_initialization_114___r4_numbers_6_5_flonum)){
require_initialization_114___r4_numbers_6_5_flonum = BBOOL(((bool_t)0));
cnst_init_137___r4_numbers_6_5_flonum();
imported_modules_init_94___r4_numbers_6_5_flonum();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_numbers_6_5_flonum()
{
symbol1780___r4_numbers_6_5_flonum = string_to_symbol("REAL?");
symbol1781___r4_numbers_6_5_flonum = string_to_symbol("=FL");
symbol1782___r4_numbers_6_5_flonum = string_to_symbol("_=FL1227");
symbol1785___r4_numbers_6_5_flonum = string_to_symbol("<FL");
symbol1786___r4_numbers_6_5_flonum = string_to_symbol("_<FL1228");
symbol1787___r4_numbers_6_5_flonum = string_to_symbol(">FL");
symbol1788___r4_numbers_6_5_flonum = string_to_symbol("_>FL1229");
symbol1789___r4_numbers_6_5_flonum = string_to_symbol("<=FL");
symbol1790___r4_numbers_6_5_flonum = string_to_symbol("_<=FL1230");
symbol1791___r4_numbers_6_5_flonum = string_to_symbol(">=FL");
symbol1792___r4_numbers_6_5_flonum = string_to_symbol("_>=FL1231");
symbol1793___r4_numbers_6_5_flonum = string_to_symbol("ZEROFL?");
symbol1794___r4_numbers_6_5_flonum = string_to_symbol("_ZEROFL?1232");
symbol1795___r4_numbers_6_5_flonum = string_to_symbol("POSITIVEFL?");
symbol1796___r4_numbers_6_5_flonum = string_to_symbol("_POSITIVEFL?1233");
symbol1797___r4_numbers_6_5_flonum = string_to_symbol("NEGATIVEFL?");
symbol1798___r4_numbers_6_5_flonum = string_to_symbol("_NEGATIVEFL?1234");
symbol1799___r4_numbers_6_5_flonum = string_to_symbol("+FL");
symbol1800___r4_numbers_6_5_flonum = string_to_symbol("_+FL1235");
symbol1801___r4_numbers_6_5_flonum = string_to_symbol("-FL");
symbol1802___r4_numbers_6_5_flonum = string_to_symbol("_-FL1236");
symbol1803___r4_numbers_6_5_flonum = string_to_symbol("*FL");
symbol1804___r4_numbers_6_5_flonum = string_to_symbol("_*FL1237");
symbol1805___r4_numbers_6_5_flonum = string_to_symbol("/FL");
symbol1806___r4_numbers_6_5_flonum = string_to_symbol("_/FL1238");
symbol1807___r4_numbers_6_5_flonum = string_to_symbol("NEGFL");
symbol1808___r4_numbers_6_5_flonum = string_to_symbol("_NEGFL1239");
symbol1809___r4_numbers_6_5_flonum = string_to_symbol("MAXFL");
symbol1811___r4_numbers_6_5_flonum = string_to_symbol("_MAXFL1240");
symbol1812___r4_numbers_6_5_flonum = string_to_symbol("MAX-2FL");
symbol1813___r4_numbers_6_5_flonum = string_to_symbol("_MAX-2FL1241");
symbol1814___r4_numbers_6_5_flonum = string_to_symbol("MIN-2FL");
symbol1815___r4_numbers_6_5_flonum = string_to_symbol("_MIN-2FL1242");
symbol1816___r4_numbers_6_5_flonum = string_to_symbol("MINFL");
symbol1817___r4_numbers_6_5_flonum = string_to_symbol("_MINFL1243");
symbol1818___r4_numbers_6_5_flonum = string_to_symbol("ABSFL");
symbol1819___r4_numbers_6_5_flonum = string_to_symbol("_ABSFL1244");
symbol1820___r4_numbers_6_5_flonum = string_to_symbol("FLOORFL");
symbol1821___r4_numbers_6_5_flonum = string_to_symbol("_FLOORFL1245");
symbol1822___r4_numbers_6_5_flonum = string_to_symbol("CEILINGFL");
symbol1823___r4_numbers_6_5_flonum = string_to_symbol("_CEILINGFL1246");
symbol1824___r4_numbers_6_5_flonum = string_to_symbol("TRUNCATEFL");
symbol1825___r4_numbers_6_5_flonum = string_to_symbol("_TRUNCATEFL1247");
symbol1826___r4_numbers_6_5_flonum = string_to_symbol("ROUNDFL");
symbol1827___r4_numbers_6_5_flonum = string_to_symbol("_ROUNDFL1248");
symbol1828___r4_numbers_6_5_flonum = string_to_symbol("EXPFL");
symbol1829___r4_numbers_6_5_flonum = string_to_symbol("_EXPFL1249");
symbol1830___r4_numbers_6_5_flonum = string_to_symbol("LOGFL");
symbol1831___r4_numbers_6_5_flonum = string_to_symbol("_LOGFL1250");
symbol1832___r4_numbers_6_5_flonum = string_to_symbol("SINFL");
symbol1833___r4_numbers_6_5_flonum = string_to_symbol("_SINFL1251");
symbol1834___r4_numbers_6_5_flonum = string_to_symbol("COSFL");
symbol1835___r4_numbers_6_5_flonum = string_to_symbol("_COSFL1252");
symbol1836___r4_numbers_6_5_flonum = string_to_symbol("TANFL");
symbol1837___r4_numbers_6_5_flonum = string_to_symbol("_TANFL1253");
symbol1838___r4_numbers_6_5_flonum = string_to_symbol("ASINFL");
symbol1839___r4_numbers_6_5_flonum = string_to_symbol("_ASINFL1254");
symbol1840___r4_numbers_6_5_flonum = string_to_symbol("ACOSFL");
symbol1841___r4_numbers_6_5_flonum = string_to_symbol("_ACOSFL1255");
symbol1842___r4_numbers_6_5_flonum = string_to_symbol("ATANFL");
symbol1847___r4_numbers_6_5_flonum = string_to_symbol("_ATANFL1256");
symbol1848___r4_numbers_6_5_flonum = string_to_symbol("ATAN-1FL");
symbol1849___r4_numbers_6_5_flonum = string_to_symbol("_ATAN-1FL1257");
symbol1850___r4_numbers_6_5_flonum = string_to_symbol("ATAN-2FL");
symbol1851___r4_numbers_6_5_flonum = string_to_symbol("_ATAN-2FL1258");
symbol1852___r4_numbers_6_5_flonum = string_to_symbol("ATAN-2FL-UR");
symbol1853___r4_numbers_6_5_flonum = string_to_symbol("_ATAN-2FL-UR1259");
symbol1854___r4_numbers_6_5_flonum = string_to_symbol("SQRTFL");
symbol1856___r4_numbers_6_5_flonum = string_to_symbol("_SQRTFL1260");
symbol1857___r4_numbers_6_5_flonum = string_to_symbol("SQRTFL-UR");
symbol1858___r4_numbers_6_5_flonum = string_to_symbol("_SQRTFL-UR1261");
symbol1859___r4_numbers_6_5_flonum = string_to_symbol("EXPTFL");
symbol1860___r4_numbers_6_5_flonum = string_to_symbol("_EXPTFL1262");
symbol1861___r4_numbers_6_5_flonum = string_to_symbol("STRING->REAL");
symbol1862___r4_numbers_6_5_flonum = string_to_symbol("_STRING->REAL1263");
symbol1864___r4_numbers_6_5_flonum = string_to_symbol("REAL->STRING");
symbol1865___r4_numbers_6_5_flonum = string_to_symbol("_REAL->STRING1264");
return (symbol1866___r4_numbers_6_5_flonum = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* real? */bool_t real__243___r4_numbers_6_5_flonum(obj_t obj_1)
{
{
obj_t symbol1148_1102;
symbol1148_1102 = symbol1780___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1148_1102);
BUNSPEC;
{
bool_t aux1147_1103;
if(INTEGERP(obj_1)){
aux1147_1103 = ((bool_t)1);
}
 else {
aux1147_1103 = REALP(obj_1);
}
POP_TRACE();
return aux1147_1103;
}
}
}
}


/* _real? */obj_t _real__79___r4_numbers_6_5_flonum(obj_t env_579, obj_t obj_580)
{
{
bool_t aux_1391;
{
obj_t obj_1104;
obj_1104 = obj_580;
{
obj_t symbol1148_1105;
symbol1148_1105 = symbol1780___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1148_1105);
BUNSPEC;
{
bool_t aux1147_1106;
if(INTEGERP(obj_1104)){
aux1147_1106 = ((bool_t)1);
}
 else {
aux1147_1106 = REALP(obj_1104);
}
POP_TRACE();
aux_1391 = aux1147_1106;
}
}
}
}
return BBOOL(aux_1391);
}
}


/* flonum? */bool_t flonum__164___r4_numbers_6_5_flonum(obj_t obj_2)
{
return REALP(obj_2);
}


/* _flonum? */obj_t _flonum__86___r4_numbers_6_5_flonum(obj_t env_581, obj_t obj_582)
{
{
bool_t aux_1399;
{
obj_t obj_1107;
obj_1107 = obj_582;
aux_1399 = REALP(obj_1107);
}
return BBOOL(aux_1399);
}
}


/* =fl */bool_t _fl_139___r4_numbers_6_5_flonum(double r1_3, double r2_4)
{
{
obj_t symbol1150_1108;
symbol1150_1108 = symbol1781___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1150_1108);
BUNSPEC;
{
bool_t aux1149_1109;
aux1149_1109 = (r1_3==r2_4);
POP_TRACE();
return aux1149_1109;
}
}
}
}


/* _=fl1227 */obj_t __fl1227_162___r4_numbers_6_5_flonum(obj_t env_583, obj_t r1_584, obj_t r2_585)
{
{
bool_t aux_1405;
{
double r1_1110;
double r2_1111;
{
obj_t aux_1406;
if(REALP(r1_584)){
aux_1406 = r1_584;
}
 else {
bigloo_type_error_location_103___error(symbol1782___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_584, string1784___r4_numbers_6_5_flonum, BINT(((long)7536)));
exit( -1 );}
r1_1110 = REAL_TO_DOUBLE(aux_1406);
}
{
obj_t aux_1413;
if(REALP(r2_585)){
aux_1413 = r2_585;
}
 else {
bigloo_type_error_location_103___error(symbol1782___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_585, string1784___r4_numbers_6_5_flonum, BINT(((long)7536)));
exit( -1 );}
r2_1111 = REAL_TO_DOUBLE(aux_1413);
}
{
obj_t symbol1150_1112;
symbol1150_1112 = symbol1781___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1150_1112);
BUNSPEC;
{
bool_t aux1149_1113;
aux1149_1113 = (r1_1110==r2_1111);
POP_TRACE();
aux_1405 = aux1149_1113;
}
}
}
}
return BBOOL(aux_1405);
}
}


/* <fl */bool_t _fl_236___r4_numbers_6_5_flonum(double r1_5, double r2_6)
{
{
obj_t symbol1152_1114;
symbol1152_1114 = symbol1785___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1152_1114);
BUNSPEC;
{
bool_t aux1151_1115;
aux1151_1115 = (r1_5<r2_6);
POP_TRACE();
return aux1151_1115;
}
}
}
}


/* _<fl1228 */obj_t __fl1228_160___r4_numbers_6_5_flonum(obj_t env_586, obj_t r1_587, obj_t r2_588)
{
{
bool_t aux_1427;
{
double r1_1116;
double r2_1117;
{
obj_t aux_1428;
if(REALP(r1_587)){
aux_1428 = r1_587;
}
 else {
bigloo_type_error_location_103___error(symbol1786___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_587, string1784___r4_numbers_6_5_flonum, BINT(((long)7804)));
exit( -1 );}
r1_1116 = REAL_TO_DOUBLE(aux_1428);
}
{
obj_t aux_1435;
if(REALP(r2_588)){
aux_1435 = r2_588;
}
 else {
bigloo_type_error_location_103___error(symbol1786___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_588, string1784___r4_numbers_6_5_flonum, BINT(((long)7804)));
exit( -1 );}
r2_1117 = REAL_TO_DOUBLE(aux_1435);
}
{
obj_t symbol1152_1118;
symbol1152_1118 = symbol1785___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1152_1118);
BUNSPEC;
{
bool_t aux1151_1119;
aux1151_1119 = (r1_1116<r2_1117);
POP_TRACE();
aux_1427 = aux1151_1119;
}
}
}
}
return BBOOL(aux_1427);
}
}


/* >fl */bool_t _fl_187___r4_numbers_6_5_flonum(double r1_7, double r2_8)
{
{
obj_t symbol1154_1120;
symbol1154_1120 = symbol1787___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1154_1120);
BUNSPEC;
{
bool_t aux1153_1121;
aux1153_1121 = (r1_7>r2_8);
POP_TRACE();
return aux1153_1121;
}
}
}
}


/* _>fl1229 */obj_t __fl1229_121___r4_numbers_6_5_flonum(obj_t env_589, obj_t r1_590, obj_t r2_591)
{
{
bool_t aux_1449;
{
double r1_1122;
double r2_1123;
{
obj_t aux_1450;
if(REALP(r1_590)){
aux_1450 = r1_590;
}
 else {
bigloo_type_error_location_103___error(symbol1788___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_590, string1784___r4_numbers_6_5_flonum, BINT(((long)8072)));
exit( -1 );}
r1_1122 = REAL_TO_DOUBLE(aux_1450);
}
{
obj_t aux_1457;
if(REALP(r2_591)){
aux_1457 = r2_591;
}
 else {
bigloo_type_error_location_103___error(symbol1788___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_591, string1784___r4_numbers_6_5_flonum, BINT(((long)8072)));
exit( -1 );}
r2_1123 = REAL_TO_DOUBLE(aux_1457);
}
{
obj_t symbol1154_1124;
symbol1154_1124 = symbol1787___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1154_1124);
BUNSPEC;
{
bool_t aux1153_1125;
aux1153_1125 = (r1_1122>r2_1123);
POP_TRACE();
aux_1449 = aux1153_1125;
}
}
}
}
return BBOOL(aux_1449);
}
}


/* <=fl */bool_t __fl_135___r4_numbers_6_5_flonum(double r1_9, double r2_10)
{
{
obj_t symbol1156_1126;
symbol1156_1126 = symbol1789___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1156_1126);
BUNSPEC;
{
bool_t aux1155_1127;
aux1155_1127 = (r1_9<=r2_10);
POP_TRACE();
return aux1155_1127;
}
}
}
}


/* _<=fl1230 */obj_t ___fl1230_58___r4_numbers_6_5_flonum(obj_t env_592, obj_t r1_593, obj_t r2_594)
{
{
bool_t aux_1471;
{
double r1_1128;
double r2_1129;
{
obj_t aux_1472;
if(REALP(r1_593)){
aux_1472 = r1_593;
}
 else {
bigloo_type_error_location_103___error(symbol1790___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_593, string1784___r4_numbers_6_5_flonum, BINT(((long)8340)));
exit( -1 );}
r1_1128 = REAL_TO_DOUBLE(aux_1472);
}
{
obj_t aux_1479;
if(REALP(r2_594)){
aux_1479 = r2_594;
}
 else {
bigloo_type_error_location_103___error(symbol1790___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_594, string1784___r4_numbers_6_5_flonum, BINT(((long)8340)));
exit( -1 );}
r2_1129 = REAL_TO_DOUBLE(aux_1479);
}
{
obj_t symbol1156_1130;
symbol1156_1130 = symbol1789___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1156_1130);
BUNSPEC;
{
bool_t aux1155_1131;
aux1155_1131 = (r1_1128<=r2_1129);
POP_TRACE();
aux_1471 = aux1155_1131;
}
}
}
}
return BBOOL(aux_1471);
}
}


/* >=fl */bool_t __fl_116___r4_numbers_6_5_flonum(double r1_11, double r2_12)
{
{
obj_t symbol1158_1132;
symbol1158_1132 = symbol1791___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1158_1132);
BUNSPEC;
{
bool_t aux1157_1133;
aux1157_1133 = (r1_11>=r2_12);
POP_TRACE();
return aux1157_1133;
}
}
}
}


/* _>=fl1231 */obj_t ___fl1231_246___r4_numbers_6_5_flonum(obj_t env_595, obj_t r1_596, obj_t r2_597)
{
{
bool_t aux_1493;
{
double r1_1134;
double r2_1135;
{
obj_t aux_1494;
if(REALP(r1_596)){
aux_1494 = r1_596;
}
 else {
bigloo_type_error_location_103___error(symbol1792___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_596, string1784___r4_numbers_6_5_flonum, BINT(((long)8610)));
exit( -1 );}
r1_1134 = REAL_TO_DOUBLE(aux_1494);
}
{
obj_t aux_1501;
if(REALP(r2_597)){
aux_1501 = r2_597;
}
 else {
bigloo_type_error_location_103___error(symbol1792___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_597, string1784___r4_numbers_6_5_flonum, BINT(((long)8610)));
exit( -1 );}
r2_1135 = REAL_TO_DOUBLE(aux_1501);
}
{
obj_t symbol1158_1136;
symbol1158_1136 = symbol1791___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1158_1136);
BUNSPEC;
{
bool_t aux1157_1137;
aux1157_1137 = (r1_1134>=r2_1135);
POP_TRACE();
aux_1493 = aux1157_1137;
}
}
}
}
return BBOOL(aux_1493);
}
}


/* zerofl? */bool_t zerofl__232___r4_numbers_6_5_flonum(double r_13)
{
{
obj_t symbol1160_1138;
symbol1160_1138 = symbol1793___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1160_1138);
BUNSPEC;
{
bool_t aux1159_1139;
aux1159_1139 = (r_13==((double)0.0));
POP_TRACE();
return aux1159_1139;
}
}
}
}


/* _zerofl?1232 */obj_t _zerofl_1232_54___r4_numbers_6_5_flonum(obj_t env_598, obj_t r_599)
{
{
bool_t aux_1515;
{
double r_1140;
{
obj_t aux_1516;
if(REALP(r_599)){
aux_1516 = r_599;
}
 else {
bigloo_type_error_location_103___error(symbol1794___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_599, string1784___r4_numbers_6_5_flonum, BINT(((long)8880)));
exit( -1 );}
r_1140 = REAL_TO_DOUBLE(aux_1516);
}
{
obj_t symbol1160_1141;
symbol1160_1141 = symbol1793___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1160_1141);
BUNSPEC;
{
bool_t aux1159_1142;
aux1159_1142 = (r_1140==((double)0.0));
POP_TRACE();
aux_1515 = aux1159_1142;
}
}
}
}
return BBOOL(aux_1515);
}
}


/* positivefl? */bool_t positivefl__131___r4_numbers_6_5_flonum(double r_14)
{
{
obj_t symbol1162_1143;
symbol1162_1143 = symbol1795___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1162_1143);
BUNSPEC;
{
bool_t aux1161_1144;
aux1161_1144 = (r_14>((double)0.0));
POP_TRACE();
return aux1161_1144;
}
}
}
}


/* _positivefl?1233 */obj_t _positivefl_1233_38___r4_numbers_6_5_flonum(obj_t env_600, obj_t r_601)
{
{
bool_t aux_1530;
{
double r_1145;
{
obj_t aux_1531;
if(REALP(r_601)){
aux_1531 = r_601;
}
 else {
bigloo_type_error_location_103___error(symbol1796___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_601, string1784___r4_numbers_6_5_flonum, BINT(((long)9146)));
exit( -1 );}
r_1145 = REAL_TO_DOUBLE(aux_1531);
}
{
obj_t symbol1162_1146;
symbol1162_1146 = symbol1795___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1162_1146);
BUNSPEC;
{
bool_t aux1161_1147;
aux1161_1147 = (r_1145>((double)0.0));
POP_TRACE();
aux_1530 = aux1161_1147;
}
}
}
}
return BBOOL(aux_1530);
}
}


/* negativefl? */bool_t negativefl__17___r4_numbers_6_5_flonum(double r_15)
{
{
obj_t symbol1164_1148;
symbol1164_1148 = symbol1797___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1164_1148);
BUNSPEC;
{
bool_t aux1163_1149;
aux1163_1149 = (r_15<((double)0.0));
POP_TRACE();
return aux1163_1149;
}
}
}
}


/* _negativefl?1234 */obj_t _negativefl_1234_197___r4_numbers_6_5_flonum(obj_t env_602, obj_t r_603)
{
{
bool_t aux_1545;
{
double r_1150;
{
obj_t aux_1546;
if(REALP(r_603)){
aux_1546 = r_603;
}
 else {
bigloo_type_error_location_103___error(symbol1798___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_603, string1784___r4_numbers_6_5_flonum, BINT(((long)9416)));
exit( -1 );}
r_1150 = REAL_TO_DOUBLE(aux_1546);
}
{
obj_t symbol1164_1151;
symbol1164_1151 = symbol1797___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1164_1151);
BUNSPEC;
{
bool_t aux1163_1152;
aux1163_1152 = (r_1150<((double)0.0));
POP_TRACE();
aux_1545 = aux1163_1152;
}
}
}
}
return BBOOL(aux_1545);
}
}


/* +fl */double _fl_172___r4_numbers_6_5_flonum(double r1_16, double r2_17)
{
{
obj_t symbol1166_1153;
symbol1166_1153 = symbol1799___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1166_1153);
BUNSPEC;
{
double aux1165_1154;
aux1165_1154 = (r1_16+r2_17);
POP_TRACE();
return aux1165_1154;
}
}
}
}


/* _+fl1235 */obj_t __fl1235_145___r4_numbers_6_5_flonum(obj_t env_604, obj_t r1_605, obj_t r2_606)
{
{
double aux_1560;
{
double r1_1155;
double r2_1156;
{
obj_t aux_1561;
if(REALP(r1_605)){
aux_1561 = r1_605;
}
 else {
bigloo_type_error_location_103___error(symbol1800___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_605, string1784___r4_numbers_6_5_flonum, BINT(((long)9686)));
exit( -1 );}
r1_1155 = REAL_TO_DOUBLE(aux_1561);
}
{
obj_t aux_1568;
if(REALP(r2_606)){
aux_1568 = r2_606;
}
 else {
bigloo_type_error_location_103___error(symbol1800___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_606, string1784___r4_numbers_6_5_flonum, BINT(((long)9686)));
exit( -1 );}
r2_1156 = REAL_TO_DOUBLE(aux_1568);
}
{
obj_t symbol1166_1157;
symbol1166_1157 = symbol1799___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1166_1157);
BUNSPEC;
{
double aux1165_1158;
aux1165_1158 = (r1_1155+r2_1156);
POP_TRACE();
aux_1560 = aux1165_1158;
}
}
}
}
return make_real(aux_1560);
}
}


/* -fl */double _fl_24___r4_numbers_6_5_flonum(double r1_18, double r2_19)
{
{
obj_t symbol1168_1159;
symbol1168_1159 = symbol1801___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1168_1159);
BUNSPEC;
{
double aux1167_1160;
aux1167_1160 = (r1_18-r2_19);
POP_TRACE();
return aux1167_1160;
}
}
}
}


/* _-fl1236 */obj_t __fl1236_168___r4_numbers_6_5_flonum(obj_t env_607, obj_t r1_608, obj_t r2_609)
{
{
double aux_1582;
{
double r1_1161;
double r2_1162;
{
obj_t aux_1583;
if(REALP(r1_608)){
aux_1583 = r1_608;
}
 else {
bigloo_type_error_location_103___error(symbol1802___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_608, string1784___r4_numbers_6_5_flonum, BINT(((long)9959)));
exit( -1 );}
r1_1161 = REAL_TO_DOUBLE(aux_1583);
}
{
obj_t aux_1590;
if(REALP(r2_609)){
aux_1590 = r2_609;
}
 else {
bigloo_type_error_location_103___error(symbol1802___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_609, string1784___r4_numbers_6_5_flonum, BINT(((long)9959)));
exit( -1 );}
r2_1162 = REAL_TO_DOUBLE(aux_1590);
}
{
obj_t symbol1168_1163;
symbol1168_1163 = symbol1801___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1168_1163);
BUNSPEC;
{
double aux1167_1164;
aux1167_1164 = (r1_1161-r2_1162);
POP_TRACE();
aux_1582 = aux1167_1164;
}
}
}
}
return make_real(aux_1582);
}
}


/* *fl */double _fl_93___r4_numbers_6_5_flonum(double r1_20, double r2_21)
{
{
obj_t symbol1170_1165;
symbol1170_1165 = symbol1803___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1170_1165);
BUNSPEC;
{
double aux1169_1166;
aux1169_1166 = (r1_20*r2_21);
POP_TRACE();
return aux1169_1166;
}
}
}
}


/* _*fl1237 */obj_t __fl1237_208___r4_numbers_6_5_flonum(obj_t env_610, obj_t r1_611, obj_t r2_612)
{
{
double aux_1604;
{
double r1_1167;
double r2_1168;
{
obj_t aux_1605;
if(REALP(r1_611)){
aux_1605 = r1_611;
}
 else {
bigloo_type_error_location_103___error(symbol1804___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_611, string1784___r4_numbers_6_5_flonum, BINT(((long)10227)));
exit( -1 );}
r1_1167 = REAL_TO_DOUBLE(aux_1605);
}
{
obj_t aux_1612;
if(REALP(r2_612)){
aux_1612 = r2_612;
}
 else {
bigloo_type_error_location_103___error(symbol1804___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_612, string1784___r4_numbers_6_5_flonum, BINT(((long)10227)));
exit( -1 );}
r2_1168 = REAL_TO_DOUBLE(aux_1612);
}
{
obj_t symbol1170_1169;
symbol1170_1169 = symbol1803___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1170_1169);
BUNSPEC;
{
double aux1169_1170;
aux1169_1170 = (r1_1167*r2_1168);
POP_TRACE();
aux_1604 = aux1169_1170;
}
}
}
}
return make_real(aux_1604);
}
}


/* /fl */double _fl_4___r4_numbers_6_5_flonum(double r1_22, double r2_23)
{
{
obj_t symbol1172_1171;
symbol1172_1171 = symbol1805___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1172_1171);
BUNSPEC;
{
double aux1171_1172;
aux1171_1172 = (r1_22/r2_23);
POP_TRACE();
return aux1171_1172;
}
}
}
}


/* _/fl1238 */obj_t __fl1238_237___r4_numbers_6_5_flonum(obj_t env_613, obj_t r1_614, obj_t r2_615)
{
{
double aux_1626;
{
double r1_1173;
double r2_1174;
{
obj_t aux_1627;
if(REALP(r1_614)){
aux_1627 = r1_614;
}
 else {
bigloo_type_error_location_103___error(symbol1806___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_614, string1784___r4_numbers_6_5_flonum, BINT(((long)10495)));
exit( -1 );}
r1_1173 = REAL_TO_DOUBLE(aux_1627);
}
{
obj_t aux_1634;
if(REALP(r2_615)){
aux_1634 = r2_615;
}
 else {
bigloo_type_error_location_103___error(symbol1806___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_615, string1784___r4_numbers_6_5_flonum, BINT(((long)10495)));
exit( -1 );}
r2_1174 = REAL_TO_DOUBLE(aux_1634);
}
{
obj_t symbol1172_1175;
symbol1172_1175 = symbol1805___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1172_1175);
BUNSPEC;
{
double aux1171_1176;
aux1171_1176 = (r1_1173/r2_1174);
POP_TRACE();
aux_1626 = aux1171_1176;
}
}
}
}
return make_real(aux_1626);
}
}


/* negfl */double negfl___r4_numbers_6_5_flonum(double r1_24)
{
{
obj_t symbol1174_1177;
symbol1174_1177 = symbol1807___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1174_1177);
BUNSPEC;
{
double aux1173_1178;
aux1173_1178 = NEG(r1_24);
POP_TRACE();
return aux1173_1178;
}
}
}
}


/* _negfl1239 */obj_t _negfl1239___r4_numbers_6_5_flonum(obj_t env_616, obj_t r1_617)
{
{
double aux_1648;
{
double r1_1179;
{
obj_t aux_1649;
if(REALP(r1_617)){
aux_1649 = r1_617;
}
 else {
bigloo_type_error_location_103___error(symbol1808___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_617, string1784___r4_numbers_6_5_flonum, BINT(((long)10763)));
exit( -1 );}
r1_1179 = REAL_TO_DOUBLE(aux_1649);
}
{
obj_t symbol1174_1180;
symbol1174_1180 = symbol1807___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1174_1180);
BUNSPEC;
{
double aux1173_1181;
aux1173_1181 = NEG(r1_1179);
POP_TRACE();
aux_1648 = aux1173_1181;
}
}
}
}
return make_real(aux_1648);
}
}


/* maxfl */double maxfl___r4_numbers_6_5_flonum(double r1_25, obj_t rn_26)
{
{
obj_t symbol1176_527;
symbol1176_527 = symbol1809___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1176_527);
BUNSPEC;
{
double aux1175_528;
{
obj_t max_266;
obj_t rn_267;
{
obj_t aux_1661;
{
obj_t aux1475_844;
max_266 = make_real(r1_25);
rn_267 = rn_26;
loop_268:
if(NULLP(rn_267)){
aux1475_844 = max_266;
}
 else {
bool_t test1007_270;
{
obj_t arg1011_274;
{
obj_t pair_426;
if(PAIRP(rn_267)){
pair_426 = rn_267;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_267, string1784___r4_numbers_6_5_flonum, BINT(((long)11138)));
exit( -1 );}
arg1011_274 = CAR(pair_426);
}
{
double r1_427;
double r2_428;
{
obj_t aux_1670;
if(REALP(arg1011_274)){
aux_1670 = arg1011_274;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, arg1011_274, string1784___r4_numbers_6_5_flonum, BINT(((long)11132)));
exit( -1 );}
r1_427 = REAL_TO_DOUBLE(aux_1670);
}
{
obj_t aux_1677;
if(REALP(max_266)){
aux_1677 = max_266;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, max_266, string1784___r4_numbers_6_5_flonum, BINT(((long)11132)));
exit( -1 );}
r2_428 = REAL_TO_DOUBLE(aux_1677);
}
test1007_270 = (r1_427>r2_428);
}
}
if(test1007_270){
obj_t arg1008_271;
obj_t arg1009_272;
{
obj_t pair_429;
if(PAIRP(rn_267)){
pair_429 = rn_267;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_267, string1784___r4_numbers_6_5_flonum, BINT(((long)11165)));
exit( -1 );}
arg1008_271 = CAR(pair_429);
}
{
obj_t pair_430;
if(PAIRP(rn_267)){
pair_430 = rn_267;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_267, string1784___r4_numbers_6_5_flonum, BINT(((long)11174)));
exit( -1 );}
arg1009_272 = CDR(pair_430);
}
{
obj_t rn_1699;
obj_t max_1698;
max_1698 = arg1008_271;
rn_1699 = arg1009_272;
rn_267 = rn_1699;
max_266 = max_1698;
goto loop_268;
}
}
 else {
obj_t arg1010_273;
{
obj_t pair_431;
if(PAIRP(rn_267)){
pair_431 = rn_267;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_267, string1784___r4_numbers_6_5_flonum, BINT(((long)11201)));
exit( -1 );}
arg1010_273 = CDR(pair_431);
}
{
obj_t rn_1706;
rn_1706 = arg1010_273;
rn_267 = rn_1706;
goto loop_268;
}
}
}
if(REALP(aux1475_844)){
aux_1661 = aux1475_844;
}
 else {
bigloo_type_error_location_103___error(symbol1809___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1475_844, string1784___r4_numbers_6_5_flonum, BINT(((long)11060)));
exit( -1 );}
}
aux1175_528 = REAL_TO_DOUBLE(aux_1661);
}
}
POP_TRACE();
return aux1175_528;
}
}
}
}


/* _maxfl1240 */obj_t _maxfl1240___r4_numbers_6_5_flonum(obj_t env_618, obj_t r1_619, obj_t rn_620)
{
{
double aux_1715;
{
double aux_1716;
{
obj_t aux_1717;
if(REALP(r1_619)){
aux_1717 = r1_619;
}
 else {
bigloo_type_error_location_103___error(symbol1811___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_619, string1784___r4_numbers_6_5_flonum, BINT(((long)11033)));
exit( -1 );}
aux_1716 = REAL_TO_DOUBLE(aux_1717);
}
aux_1715 = maxfl___r4_numbers_6_5_flonum(aux_1716, rn_620);
}
return make_real(aux_1715);
}
}


/* max-2fl */double max_2fl_226___r4_numbers_6_5_flonum(double r1_27, double r2_28)
{
{
obj_t symbol1178_1182;
symbol1178_1182 = symbol1812___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1178_1182);
BUNSPEC;
{
double aux1177_1183;
if((r1_27>r2_28)){
aux1177_1183 = r1_27;
}
 else {
aux1177_1183 = r2_28;
}
POP_TRACE();
return aux1177_1183;
}
}
}
}


/* _max-2fl1241 */obj_t _max_2fl1241_245___r4_numbers_6_5_flonum(obj_t env_621, obj_t r1_622, obj_t r2_623)
{
{
double aux_1730;
{
double r1_1184;
double r2_1185;
{
obj_t aux_1731;
if(REALP(r1_622)){
aux_1731 = r1_622;
}
 else {
bigloo_type_error_location_103___error(symbol1813___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_622, string1784___r4_numbers_6_5_flonum, BINT(((long)11437)));
exit( -1 );}
r1_1184 = REAL_TO_DOUBLE(aux_1731);
}
{
obj_t aux_1738;
if(REALP(r2_623)){
aux_1738 = r2_623;
}
 else {
bigloo_type_error_location_103___error(symbol1813___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_623, string1784___r4_numbers_6_5_flonum, BINT(((long)11437)));
exit( -1 );}
r2_1185 = REAL_TO_DOUBLE(aux_1738);
}
{
obj_t symbol1178_1186;
symbol1178_1186 = symbol1812___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1178_1186);
BUNSPEC;
{
double aux1177_1187;
if((r1_1184>r2_1185)){
aux1177_1187 = r1_1184;
}
 else {
aux1177_1187 = r2_1185;
}
POP_TRACE();
aux_1730 = aux1177_1187;
}
}
}
}
return make_real(aux_1730);
}
}


/* min-2fl */double min_2fl_9___r4_numbers_6_5_flonum(double r1_29, double r2_30)
{
{
obj_t symbol1180_1188;
symbol1180_1188 = symbol1814___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1180_1188);
BUNSPEC;
{
double aux1179_1189;
if((r1_29>r2_30)){
aux1179_1189 = r2_30;
}
 else {
aux1179_1189 = r1_29;
}
POP_TRACE();
return aux1179_1189;
}
}
}
}


/* _min-2fl1242 */obj_t _min_2fl1242_179___r4_numbers_6_5_flonum(obj_t env_624, obj_t r1_625, obj_t r2_626)
{
{
double aux_1754;
{
double r1_1190;
double r2_1191;
{
obj_t aux_1755;
if(REALP(r1_625)){
aux_1755 = r1_625;
}
 else {
bigloo_type_error_location_103___error(symbol1815___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_625, string1784___r4_numbers_6_5_flonum, BINT(((long)11732)));
exit( -1 );}
r1_1190 = REAL_TO_DOUBLE(aux_1755);
}
{
obj_t aux_1762;
if(REALP(r2_626)){
aux_1762 = r2_626;
}
 else {
bigloo_type_error_location_103___error(symbol1815___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_626, string1784___r4_numbers_6_5_flonum, BINT(((long)11732)));
exit( -1 );}
r2_1191 = REAL_TO_DOUBLE(aux_1762);
}
{
obj_t symbol1180_1192;
symbol1180_1192 = symbol1814___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1180_1192);
BUNSPEC;
{
double aux1179_1193;
if((r1_1190>r2_1191)){
aux1179_1193 = r2_1191;
}
 else {
aux1179_1193 = r1_1190;
}
POP_TRACE();
aux_1754 = aux1179_1193;
}
}
}
}
return make_real(aux_1754);
}
}


/* minfl */double minfl___r4_numbers_6_5_flonum(double r1_31, obj_t rn_32)
{
{
obj_t symbol1182_533;
symbol1182_533 = symbol1816___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1182_533);
BUNSPEC;
{
double aux1181_534;
{
obj_t min_277;
obj_t rn_278;
{
obj_t aux_1775;
{
obj_t aux1557_916;
min_277 = make_real(r1_31);
rn_278 = rn_32;
loop_279:
if(NULLP(rn_278)){
aux1557_916 = min_277;
}
 else {
bool_t test1015_281;
{
obj_t arg1019_285;
{
obj_t pair_439;
if(PAIRP(rn_278)){
pair_439 = rn_278;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_278, string1784___r4_numbers_6_5_flonum, BINT(((long)12135)));
exit( -1 );}
arg1019_285 = CAR(pair_439);
}
{
double r1_440;
double r2_441;
{
obj_t aux_1784;
if(REALP(arg1019_285)){
aux_1784 = arg1019_285;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, arg1019_285, string1784___r4_numbers_6_5_flonum, BINT(((long)12129)));
exit( -1 );}
r1_440 = REAL_TO_DOUBLE(aux_1784);
}
{
obj_t aux_1791;
if(REALP(min_277)){
aux_1791 = min_277;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, min_277, string1784___r4_numbers_6_5_flonum, BINT(((long)12129)));
exit( -1 );}
r2_441 = REAL_TO_DOUBLE(aux_1791);
}
test1015_281 = (r1_440<r2_441);
}
}
if(test1015_281){
obj_t arg1016_282;
obj_t arg1017_283;
{
obj_t pair_442;
if(PAIRP(rn_278)){
pair_442 = rn_278;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_278, string1784___r4_numbers_6_5_flonum, BINT(((long)12162)));
exit( -1 );}
arg1016_282 = CAR(pair_442);
}
{
obj_t pair_443;
if(PAIRP(rn_278)){
pair_443 = rn_278;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_278, string1784___r4_numbers_6_5_flonum, BINT(((long)12171)));
exit( -1 );}
arg1017_283 = CDR(pair_443);
}
{
obj_t rn_1813;
obj_t min_1812;
min_1812 = arg1016_282;
rn_1813 = arg1017_283;
rn_278 = rn_1813;
min_277 = min_1812;
goto loop_279;
}
}
 else {
obj_t arg1018_284;
{
obj_t pair_444;
if(PAIRP(rn_278)){
pair_444 = rn_278;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, rn_278, string1784___r4_numbers_6_5_flonum, BINT(((long)12198)));
exit( -1 );}
arg1018_284 = CDR(pair_444);
}
{
obj_t rn_1820;
rn_1820 = arg1018_284;
rn_278 = rn_1820;
goto loop_279;
}
}
}
if(REALP(aux1557_916)){
aux_1775 = aux1557_916;
}
 else {
bigloo_type_error_location_103___error(symbol1816___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1557_916, string1784___r4_numbers_6_5_flonum, BINT(((long)12057)));
exit( -1 );}
}
aux1181_534 = REAL_TO_DOUBLE(aux_1775);
}
}
POP_TRACE();
return aux1181_534;
}
}
}
}


/* _minfl1243 */obj_t _minfl1243___r4_numbers_6_5_flonum(obj_t env_627, obj_t r1_628, obj_t rn_629)
{
{
double aux_1829;
{
double aux_1830;
{
obj_t aux_1831;
if(REALP(r1_628)){
aux_1831 = r1_628;
}
 else {
bigloo_type_error_location_103___error(symbol1817___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_628, string1784___r4_numbers_6_5_flonum, BINT(((long)12030)));
exit( -1 );}
aux_1830 = REAL_TO_DOUBLE(aux_1831);
}
aux_1829 = minfl___r4_numbers_6_5_flonum(aux_1830, rn_629);
}
return make_real(aux_1829);
}
}


/* absfl */double absfl___r4_numbers_6_5_flonum(double r_33)
{
{
obj_t symbol1184_1194;
symbol1184_1194 = symbol1818___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1184_1194);
BUNSPEC;
{
double aux1183_1195;
if((r_33<((double)0.0))){
aux1183_1195 = NEG(r_33);
}
 else {
aux1183_1195 = r_33;
}
POP_TRACE();
return aux1183_1195;
}
}
}
}


/* _absfl1244 */obj_t _absfl1244___r4_numbers_6_5_flonum(obj_t env_630, obj_t r_631)
{
{
double aux_1845;
{
double r_1196;
{
obj_t aux_1846;
if(REALP(r_631)){
aux_1846 = r_631;
}
 else {
bigloo_type_error_location_103___error(symbol1819___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_631, string1784___r4_numbers_6_5_flonum, BINT(((long)12437)));
exit( -1 );}
r_1196 = REAL_TO_DOUBLE(aux_1846);
}
{
obj_t symbol1184_1197;
symbol1184_1197 = symbol1818___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1184_1197);
BUNSPEC;
{
double aux1183_1198;
if((r_1196<((double)0.0))){
aux1183_1198 = NEG(r_1196);
}
 else {
aux1183_1198 = r_1196;
}
POP_TRACE();
aux_1845 = aux1183_1198;
}
}
}
}
return make_real(aux_1845);
}
}


/* floorfl */double floorfl___r4_numbers_6_5_flonum(double r_34)
{
{
obj_t symbol1186_1199;
symbol1186_1199 = symbol1820___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1186_1199);
BUNSPEC;
{
double aux1185_1200;
aux1185_1200 = floor(r_34);
POP_TRACE();
return aux1185_1200;
}
}
}
}


/* _floorfl1245 */obj_t _floorfl1245___r4_numbers_6_5_flonum(obj_t env_632, obj_t r_633)
{
{
double aux_1862;
{
double r_1201;
{
obj_t aux_1863;
if(REALP(r_633)){
aux_1863 = r_633;
}
 else {
bigloo_type_error_location_103___error(symbol1821___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_633, string1784___r4_numbers_6_5_flonum, BINT(((long)12732)));
exit( -1 );}
r_1201 = REAL_TO_DOUBLE(aux_1863);
}
{
obj_t symbol1186_1202;
symbol1186_1202 = symbol1820___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1186_1202);
BUNSPEC;
{
double aux1185_1203;
aux1185_1203 = floor(r_1201);
POP_TRACE();
aux_1862 = aux1185_1203;
}
}
}
}
return make_real(aux_1862);
}
}


/* ceilingfl */double ceilingfl___r4_numbers_6_5_flonum(double r_35)
{
{
obj_t symbol1188_1204;
symbol1188_1204 = symbol1822___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1188_1204);
BUNSPEC;
{
double aux1187_1205;
aux1187_1205 = ceil(r_35);
POP_TRACE();
return aux1187_1205;
}
}
}
}


/* _ceilingfl1246 */obj_t _ceilingfl1246___r4_numbers_6_5_flonum(obj_t env_634, obj_t r_635)
{
{
double aux_1877;
{
double r_1206;
{
obj_t aux_1878;
if(REALP(r_635)){
aux_1878 = r_635;
}
 else {
bigloo_type_error_location_103___error(symbol1823___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_635, string1784___r4_numbers_6_5_flonum, BINT(((long)12998)));
exit( -1 );}
r_1206 = REAL_TO_DOUBLE(aux_1878);
}
{
obj_t symbol1188_1207;
symbol1188_1207 = symbol1822___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1188_1207);
BUNSPEC;
{
double aux1187_1208;
aux1187_1208 = ceil(r_1206);
POP_TRACE();
aux_1877 = aux1187_1208;
}
}
}
}
return make_real(aux_1877);
}
}


/* truncatefl */double truncatefl___r4_numbers_6_5_flonum(double r_36)
{
{
obj_t symbol1190_1209;
symbol1190_1209 = symbol1824___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1190_1209);
BUNSPEC;
{
double aux1189_1210;
if((r_36<((double)0.0))){
aux1189_1210 = ceil(r_36);
}
 else {
aux1189_1210 = floor(r_36);
}
POP_TRACE();
return aux1189_1210;
}
}
}
}


/* _truncatefl1247 */obj_t _truncatefl1247___r4_numbers_6_5_flonum(obj_t env_636, obj_t r_637)
{
{
double aux_1895;
{
double r_1211;
{
obj_t aux_1896;
if(REALP(r_637)){
aux_1896 = r_637;
}
 else {
bigloo_type_error_location_103___error(symbol1825___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_637, string1784___r4_numbers_6_5_flonum, BINT(((long)13268)));
exit( -1 );}
r_1211 = REAL_TO_DOUBLE(aux_1896);
}
{
obj_t symbol1190_1212;
symbol1190_1212 = symbol1824___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1190_1212);
BUNSPEC;
{
double aux1189_1213;
if((r_1211<((double)0.0))){
aux1189_1213 = ceil(r_1211);
}
 else {
aux1189_1213 = floor(r_1211);
}
POP_TRACE();
aux_1895 = aux1189_1213;
}
}
}
}
return make_real(aux_1895);
}
}


/* roundfl */double roundfl___r4_numbers_6_5_flonum(double r_37)
{
{
obj_t symbol1192_1214;
symbol1192_1214 = symbol1826___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1192_1214);
BUNSPEC;
{
double aux1191_1215;
{
double aux_1911;
aux_1911 = (r_37+((double)0.5));
aux1191_1215 = floor(aux_1911);
}
POP_TRACE();
return aux1191_1215;
}
}
}
}


/* _roundfl1248 */obj_t _roundfl1248___r4_numbers_6_5_flonum(obj_t env_638, obj_t r_639)
{
{
double aux_1915;
{
double r_1216;
{
obj_t aux_1916;
if(REALP(r_639)){
aux_1916 = r_639;
}
 else {
bigloo_type_error_location_103___error(symbol1827___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_639, string1784___r4_numbers_6_5_flonum, BINT(((long)13586)));
exit( -1 );}
r_1216 = REAL_TO_DOUBLE(aux_1916);
}
{
obj_t symbol1192_1217;
symbol1192_1217 = symbol1826___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1192_1217);
BUNSPEC;
{
double aux1191_1218;
{
double aux_1924;
aux_1924 = (r_1216+((double)0.5));
aux1191_1218 = floor(aux_1924);
}
POP_TRACE();
aux_1915 = aux1191_1218;
}
}
}
}
return make_real(aux_1915);
}
}


/* expfl */double expfl___r4_numbers_6_5_flonum(double x_38)
{
{
obj_t symbol1194_1219;
symbol1194_1219 = symbol1828___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1194_1219);
BUNSPEC;
{
double aux1193_1220;
aux1193_1220 = exp(x_38);
POP_TRACE();
return aux1193_1220;
}
}
}
}


/* _expfl1249 */obj_t _expfl1249___r4_numbers_6_5_flonum(obj_t env_640, obj_t x_641)
{
{
double aux_1932;
{
double x_1221;
{
obj_t aux_1933;
if(REALP(x_641)){
aux_1933 = x_641;
}
 else {
bigloo_type_error_location_103___error(symbol1829___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_641, string1784___r4_numbers_6_5_flonum, BINT(((long)13862)));
exit( -1 );}
x_1221 = REAL_TO_DOUBLE(aux_1933);
}
{
obj_t symbol1194_1222;
symbol1194_1222 = symbol1828___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1194_1222);
BUNSPEC;
{
double aux1193_1223;
aux1193_1223 = exp(x_1221);
POP_TRACE();
aux_1932 = aux1193_1223;
}
}
}
}
return make_real(aux_1932);
}
}


/* logfl */double logfl___r4_numbers_6_5_flonum(double x_39)
{
{
obj_t symbol1196_1224;
symbol1196_1224 = symbol1830___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1196_1224);
BUNSPEC;
{
double aux1195_1225;
aux1195_1225 = log(x_39);
POP_TRACE();
return aux1195_1225;
}
}
}
}


/* _logfl1250 */obj_t _logfl1250___r4_numbers_6_5_flonum(obj_t env_642, obj_t x_643)
{
{
double aux_1947;
{
double x_1226;
{
obj_t aux_1948;
if(REALP(x_643)){
aux_1948 = x_643;
}
 else {
bigloo_type_error_location_103___error(symbol1831___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_643, string1784___r4_numbers_6_5_flonum, BINT(((long)14124)));
exit( -1 );}
x_1226 = REAL_TO_DOUBLE(aux_1948);
}
{
obj_t symbol1196_1227;
symbol1196_1227 = symbol1830___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1196_1227);
BUNSPEC;
{
double aux1195_1228;
aux1195_1228 = log(x_1226);
POP_TRACE();
aux_1947 = aux1195_1228;
}
}
}
}
return make_real(aux_1947);
}
}


/* sinfl */double sinfl___r4_numbers_6_5_flonum(double x_40)
{
{
obj_t symbol1198_1229;
symbol1198_1229 = symbol1832___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1198_1229);
BUNSPEC;
{
double aux1197_1230;
aux1197_1230 = sin(x_40);
POP_TRACE();
return aux1197_1230;
}
}
}
}


/* _sinfl1251 */obj_t _sinfl1251___r4_numbers_6_5_flonum(obj_t env_644, obj_t x_645)
{
{
double aux_1962;
{
double x_1231;
{
obj_t aux_1963;
if(REALP(x_645)){
aux_1963 = x_645;
}
 else {
bigloo_type_error_location_103___error(symbol1833___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_645, string1784___r4_numbers_6_5_flonum, BINT(((long)14387)));
exit( -1 );}
x_1231 = REAL_TO_DOUBLE(aux_1963);
}
{
obj_t symbol1198_1232;
symbol1198_1232 = symbol1832___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1198_1232);
BUNSPEC;
{
double aux1197_1233;
aux1197_1233 = sin(x_1231);
POP_TRACE();
aux_1962 = aux1197_1233;
}
}
}
}
return make_real(aux_1962);
}
}


/* cosfl */double cosfl___r4_numbers_6_5_flonum(double x_41)
{
{
obj_t symbol1200_1234;
symbol1200_1234 = symbol1834___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1200_1234);
BUNSPEC;
{
double aux1199_1235;
aux1199_1235 = cos(x_41);
POP_TRACE();
return aux1199_1235;
}
}
}
}


/* _cosfl1252 */obj_t _cosfl1252___r4_numbers_6_5_flonum(obj_t env_646, obj_t x_647)
{
{
double aux_1977;
{
double x_1236;
{
obj_t aux_1978;
if(REALP(x_647)){
aux_1978 = x_647;
}
 else {
bigloo_type_error_location_103___error(symbol1835___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_647, string1784___r4_numbers_6_5_flonum, BINT(((long)14649)));
exit( -1 );}
x_1236 = REAL_TO_DOUBLE(aux_1978);
}
{
obj_t symbol1200_1237;
symbol1200_1237 = symbol1834___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1200_1237);
BUNSPEC;
{
double aux1199_1238;
aux1199_1238 = cos(x_1236);
POP_TRACE();
aux_1977 = aux1199_1238;
}
}
}
}
return make_real(aux_1977);
}
}


/* tanfl */double tanfl___r4_numbers_6_5_flonum(double x_42)
{
{
obj_t symbol1202_1239;
symbol1202_1239 = symbol1836___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1202_1239);
BUNSPEC;
{
double aux1201_1240;
aux1201_1240 = tan(x_42);
POP_TRACE();
return aux1201_1240;
}
}
}
}


/* _tanfl1253 */obj_t _tanfl1253___r4_numbers_6_5_flonum(obj_t env_648, obj_t x_649)
{
{
double aux_1992;
{
double x_1241;
{
obj_t aux_1993;
if(REALP(x_649)){
aux_1993 = x_649;
}
 else {
bigloo_type_error_location_103___error(symbol1837___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_649, string1784___r4_numbers_6_5_flonum, BINT(((long)14911)));
exit( -1 );}
x_1241 = REAL_TO_DOUBLE(aux_1993);
}
{
obj_t symbol1202_1242;
symbol1202_1242 = symbol1836___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1202_1242);
BUNSPEC;
{
double aux1201_1243;
aux1201_1243 = tan(x_1241);
POP_TRACE();
aux_1992 = aux1201_1243;
}
}
}
}
return make_real(aux_1992);
}
}


/* asinfl */double asinfl___r4_numbers_6_5_flonum(double x_43)
{
{
obj_t symbol1204_1244;
symbol1204_1244 = symbol1838___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1204_1244);
BUNSPEC;
{
double aux1203_1245;
aux1203_1245 = asin(x_43);
POP_TRACE();
return aux1203_1245;
}
}
}
}


/* _asinfl1254 */obj_t _asinfl1254___r4_numbers_6_5_flonum(obj_t env_650, obj_t x_651)
{
{
double aux_2007;
{
double x_1246;
{
obj_t aux_2008;
if(REALP(x_651)){
aux_2008 = x_651;
}
 else {
bigloo_type_error_location_103___error(symbol1839___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_651, string1784___r4_numbers_6_5_flonum, BINT(((long)15173)));
exit( -1 );}
x_1246 = REAL_TO_DOUBLE(aux_2008);
}
{
obj_t symbol1204_1247;
symbol1204_1247 = symbol1838___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1204_1247);
BUNSPEC;
{
double aux1203_1248;
aux1203_1248 = asin(x_1246);
POP_TRACE();
aux_2007 = aux1203_1248;
}
}
}
}
return make_real(aux_2007);
}
}


/* acosfl */double acosfl___r4_numbers_6_5_flonum(double x_44)
{
{
obj_t symbol1206_1249;
symbol1206_1249 = symbol1840___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1206_1249);
BUNSPEC;
{
double aux1205_1250;
aux1205_1250 = acos(x_44);
POP_TRACE();
return aux1205_1250;
}
}
}
}


/* _acosfl1255 */obj_t _acosfl1255___r4_numbers_6_5_flonum(obj_t env_652, obj_t x_653)
{
{
double aux_2022;
{
double x_1251;
{
obj_t aux_2023;
if(REALP(x_653)){
aux_2023 = x_653;
}
 else {
bigloo_type_error_location_103___error(symbol1841___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_653, string1784___r4_numbers_6_5_flonum, BINT(((long)15437)));
exit( -1 );}
x_1251 = REAL_TO_DOUBLE(aux_2023);
}
{
obj_t symbol1206_1252;
symbol1206_1252 = symbol1840___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1206_1252);
BUNSPEC;
{
double aux1205_1253;
aux1205_1253 = acos(x_1251);
POP_TRACE();
aux_2022 = aux1205_1253;
}
}
}
}
return make_real(aux_2022);
}
}


/* atanfl */double atanfl___r4_numbers_6_5_flonum(double x_45, obj_t y_46)
{
{
obj_t symbol1208_559;
symbol1208_559 = symbol1842___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1208_559);
BUNSPEC;
{
double aux1207_560;
if(NULLP(y_46)){
aux1207_560 = atan(x_45);
}
 else {
obj_t y_460;
{
obj_t pair_462;
if(PAIRP(y_46)){
pair_462 = y_46;
}
 else {
bigloo_type_error_location_103___error(symbol1842___r4_numbers_6_5_flonum, string1810___r4_numbers_6_5_flonum, y_46, string1784___r4_numbers_6_5_flonum, BINT(((long)15776)));
exit( -1 );}
y_460 = CAR(pair_462);
}
{
double res1146_477;
{
double y_464;
{
obj_t aux_2044;
if(REALP(y_460)){
aux_2044 = y_460;
}
 else {
bigloo_type_error_location_103___error(symbol1842___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, y_460, string1784___r4_numbers_6_5_flonum, BINT(((long)15788)));
exit( -1 );}
y_464 = REAL_TO_DOUBLE(aux_2044);
}
{
bool_t test_2051;
if((x_45==((double)0.0))){
test_2051 = (y_464==((double)0.0));
}
 else {
test_2051 = ((bool_t)0);
}
if(test_2051){
obj_t aux_2055;
{
obj_t aux1677_1012;
aux1677_1012 = debug_error_location_199___error(string1843___r4_numbers_6_5_flonum, string1844___r4_numbers_6_5_flonum, real1845___r4_numbers_6_5_flonum, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
if(REALP(aux1677_1012)){
aux_2055 = aux1677_1012;
}
 else {
bigloo_type_error_location_103___error(symbol1842___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1677_1012, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
exit( -1 );}
}
res1146_477 = REAL_TO_DOUBLE(aux_2055);
}
 else {
res1146_477 = atan2(x_45, y_464);
}
}
}
aux1207_560 = res1146_477;
}
}
POP_TRACE();
return aux1207_560;
}
}
}
}


/* _atanfl1256 */obj_t _atanfl1256___r4_numbers_6_5_flonum(obj_t env_654, obj_t x_655, obj_t y_656)
{
{
double aux_2066;
{
double aux_2067;
{
obj_t aux_2068;
if(REALP(x_655)){
aux_2068 = x_655;
}
 else {
bigloo_type_error_location_103___error(symbol1847___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_655, string1784___r4_numbers_6_5_flonum, BINT(((long)15701)));
exit( -1 );}
aux_2067 = REAL_TO_DOUBLE(aux_2068);
}
aux_2066 = atanfl___r4_numbers_6_5_flonum(aux_2067, y_656);
}
return make_real(aux_2066);
}
}


/* atan-1fl */double atan_1fl_210___r4_numbers_6_5_flonum(double x_47)
{
{
obj_t symbol1210_1254;
symbol1210_1254 = symbol1848___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1210_1254);
BUNSPEC;
{
double aux1209_1255;
aux1209_1255 = atan(x_47);
POP_TRACE();
return aux1209_1255;
}
}
}
}


/* _atan-1fl1257 */obj_t _atan_1fl1257_190___r4_numbers_6_5_flonum(obj_t env_657, obj_t x_658)
{
{
double aux_2080;
{
double x_1256;
{
obj_t aux_2081;
if(REALP(x_658)){
aux_2081 = x_658;
}
 else {
bigloo_type_error_location_103___error(symbol1849___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_658, string1784___r4_numbers_6_5_flonum, BINT(((long)16029)));
exit( -1 );}
x_1256 = REAL_TO_DOUBLE(aux_2081);
}
{
obj_t symbol1210_1257;
symbol1210_1257 = symbol1848___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1210_1257);
BUNSPEC;
{
double aux1209_1258;
aux1209_1258 = atan(x_1256);
POP_TRACE();
aux_2080 = aux1209_1258;
}
}
}
}
return make_real(aux_2080);
}
}


/* atan-2fl */double atan_2fl_180___r4_numbers_6_5_flonum(double x_48, double y_49)
{
{
obj_t symbol1212_1259;
symbol1212_1259 = symbol1850___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1212_1259);
BUNSPEC;
{
double aux1211_1260;
{
bool_t test_2093;
if((x_48==((double)0.0))){
test_2093 = (y_49==((double)0.0));
}
 else {
test_2093 = ((bool_t)0);
}
if(test_2093){
obj_t aux_2097;
{
obj_t aux1696_1261;
aux1696_1261 = debug_error_location_199___error(string1843___r4_numbers_6_5_flonum, string1844___r4_numbers_6_5_flonum, real1845___r4_numbers_6_5_flonum, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
if(REALP(aux1696_1261)){
aux_2097 = aux1696_1261;
}
 else {
bigloo_type_error_location_103___error(symbol1850___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1696_1261, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
exit( -1 );}
}
aux1211_1260 = REAL_TO_DOUBLE(aux_2097);
}
 else {
aux1211_1260 = atan2(x_48, y_49);
}
}
POP_TRACE();
return aux1211_1260;
}
}
}
}


/* _atan-2fl1258 */obj_t _atan_2fl1258_65___r4_numbers_6_5_flonum(obj_t env_659, obj_t x_660, obj_t y_661)
{
{
double aux_2108;
{
double x_1262;
double y_1263;
{
obj_t aux_2109;
if(REALP(x_660)){
aux_2109 = x_660;
}
 else {
bigloo_type_error_location_103___error(symbol1851___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_660, string1784___r4_numbers_6_5_flonum, BINT(((long)16295)));
exit( -1 );}
x_1262 = REAL_TO_DOUBLE(aux_2109);
}
{
obj_t aux_2116;
if(REALP(y_661)){
aux_2116 = y_661;
}
 else {
bigloo_type_error_location_103___error(symbol1851___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, y_661, string1784___r4_numbers_6_5_flonum, BINT(((long)16295)));
exit( -1 );}
y_1263 = REAL_TO_DOUBLE(aux_2116);
}
{
obj_t symbol1212_1264;
symbol1212_1264 = symbol1850___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1212_1264);
BUNSPEC;
{
double aux1211_1265;
{
bool_t test_2124;
if((x_1262==((double)0.0))){
test_2124 = (y_1263==((double)0.0));
}
 else {
test_2124 = ((bool_t)0);
}
if(test_2124){
obj_t aux_2128;
{
obj_t aux1696_1266;
aux1696_1266 = debug_error_location_199___error(string1843___r4_numbers_6_5_flonum, string1844___r4_numbers_6_5_flonum, real1845___r4_numbers_6_5_flonum, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
if(REALP(aux1696_1266)){
aux_2128 = aux1696_1266;
}
 else {
bigloo_type_error_location_103___error(symbol1850___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1696_1266, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
exit( -1 );}
}
aux1211_1265 = REAL_TO_DOUBLE(aux_2128);
}
 else {
aux1211_1265 = atan2(x_1262, y_1263);
}
}
POP_TRACE();
aux_2108 = aux1211_1265;
}
}
}
}
return make_real(aux_2108);
}
}


/* atan-2fl-ur */double atan_2fl_ur_116___r4_numbers_6_5_flonum(double x_50, double y_51)
{
{
obj_t symbol1214_1267;
symbol1214_1267 = symbol1852___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1214_1267);
BUNSPEC;
{
double aux1213_1268;
aux1213_1268 = atan2(x_50, y_51);
POP_TRACE();
return aux1213_1268;
}
}
}
}


/* _atan-2fl-ur1259 */obj_t _atan_2fl_ur1259_194___r4_numbers_6_5_flonum(obj_t env_662, obj_t x_663, obj_t y_664)
{
{
double aux_2143;
{
double x_1269;
double y_1270;
{
obj_t aux_2144;
if(REALP(x_663)){
aux_2144 = x_663;
}
 else {
bigloo_type_error_location_103___error(symbol1853___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, x_663, string1784___r4_numbers_6_5_flonum, BINT(((long)16785)));
exit( -1 );}
x_1269 = REAL_TO_DOUBLE(aux_2144);
}
{
obj_t aux_2151;
if(REALP(y_664)){
aux_2151 = y_664;
}
 else {
bigloo_type_error_location_103___error(symbol1853___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, y_664, string1784___r4_numbers_6_5_flonum, BINT(((long)16785)));
exit( -1 );}
y_1270 = REAL_TO_DOUBLE(aux_2151);
}
{
obj_t symbol1214_1271;
symbol1214_1271 = symbol1852___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1214_1271);
BUNSPEC;
{
double aux1213_1272;
aux1213_1272 = atan2(x_1269, y_1270);
POP_TRACE();
aux_2143 = aux1213_1272;
}
}
}
}
return make_real(aux_2143);
}
}


/* sqrtfl */double sqrtfl___r4_numbers_6_5_flonum(double r_52)
{
{
obj_t symbol1216_1273;
symbol1216_1273 = symbol1854___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1216_1273);
BUNSPEC;
{
double aux1215_1274;
if((r_52<((double)0.0))){
obj_t aux_2165;
{
obj_t aux1727_1275;
aux1727_1275 = debug_error_location_199___error(string1855___r4_numbers_6_5_flonum, string1844___r4_numbers_6_5_flonum, make_real(r_52), string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
if(REALP(aux1727_1275)){
aux_2165 = aux1727_1275;
}
 else {
bigloo_type_error_location_103___error(symbol1854___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1727_1275, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
exit( -1 );}
}
aux1215_1274 = REAL_TO_DOUBLE(aux_2165);
}
 else {
aux1215_1274 = sqrt(r_52);
}
POP_TRACE();
return aux1215_1274;
}
}
}
}


/* _sqrtfl1260 */obj_t _sqrtfl1260___r4_numbers_6_5_flonum(obj_t env_665, obj_t r_666)
{
{
double aux_2177;
{
double r_1276;
{
obj_t aux_2178;
if(REALP(r_666)){
aux_2178 = r_666;
}
 else {
bigloo_type_error_location_103___error(symbol1856___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_666, string1784___r4_numbers_6_5_flonum, BINT(((long)17059)));
exit( -1 );}
r_1276 = REAL_TO_DOUBLE(aux_2178);
}
{
obj_t symbol1216_1277;
symbol1216_1277 = symbol1854___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1216_1277);
BUNSPEC;
{
double aux1215_1278;
if((r_1276<((double)0.0))){
obj_t aux_2188;
{
obj_t aux1727_1279;
aux1727_1279 = debug_error_location_199___error(string1855___r4_numbers_6_5_flonum, string1844___r4_numbers_6_5_flonum, make_real(r_1276), string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
if(REALP(aux1727_1279)){
aux_2188 = aux1727_1279;
}
 else {
bigloo_type_error_location_103___error(symbol1854___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, aux1727_1279, string1846___r4_numbers_6_5_flonum, BINT(((long)7610)));
exit( -1 );}
}
aux1215_1278 = REAL_TO_DOUBLE(aux_2188);
}
 else {
aux1215_1278 = sqrt(r_1276);
}
POP_TRACE();
aux_2177 = aux1215_1278;
}
}
}
}
return make_real(aux_2177);
}
}


/* sqrtfl-ur */double sqrtfl_ur_118___r4_numbers_6_5_flonum(double r_53)
{
{
obj_t symbol1218_1280;
symbol1218_1280 = symbol1857___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1218_1280);
BUNSPEC;
{
double aux1217_1281;
aux1217_1281 = sqrt(r_53);
POP_TRACE();
return aux1217_1281;
}
}
}
}


/* _sqrtfl-ur1261 */obj_t _sqrtfl_ur1261_237___r4_numbers_6_5_flonum(obj_t env_667, obj_t r_668)
{
{
double aux_2204;
{
double r_1282;
{
obj_t aux_2205;
if(REALP(r_668)){
aux_2205 = r_668;
}
 else {
bigloo_type_error_location_103___error(symbol1858___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r_668, string1784___r4_numbers_6_5_flonum, BINT(((long)17509)));
exit( -1 );}
r_1282 = REAL_TO_DOUBLE(aux_2205);
}
{
obj_t symbol1218_1283;
symbol1218_1283 = symbol1857___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1218_1283);
BUNSPEC;
{
double aux1217_1284;
aux1217_1284 = sqrt(r_1282);
POP_TRACE();
aux_2204 = aux1217_1284;
}
}
}
}
return make_real(aux_2204);
}
}


/* exptfl */double exptfl___r4_numbers_6_5_flonum(double r1_54, double r2_55)
{
{
obj_t symbol1220_1285;
symbol1220_1285 = symbol1859___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1220_1285);
BUNSPEC;
{
double aux1219_1286;
aux1219_1286 = pow(r1_54, r2_55);
POP_TRACE();
return aux1219_1286;
}
}
}
}


/* _exptfl1262 */obj_t _exptfl1262___r4_numbers_6_5_flonum(obj_t env_669, obj_t r1_670, obj_t r2_671)
{
{
double aux_2219;
{
double r1_1287;
double r2_1288;
{
obj_t aux_2220;
if(REALP(r1_670)){
aux_2220 = r1_670;
}
 else {
bigloo_type_error_location_103___error(symbol1860___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r1_670, string1784___r4_numbers_6_5_flonum, BINT(((long)17776)));
exit( -1 );}
r1_1287 = REAL_TO_DOUBLE(aux_2220);
}
{
obj_t aux_2227;
if(REALP(r2_671)){
aux_2227 = r2_671;
}
 else {
bigloo_type_error_location_103___error(symbol1860___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, r2_671, string1784___r4_numbers_6_5_flonum, BINT(((long)17776)));
exit( -1 );}
r2_1288 = REAL_TO_DOUBLE(aux_2227);
}
{
obj_t symbol1220_1289;
symbol1220_1289 = symbol1859___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1220_1289);
BUNSPEC;
{
double aux1219_1290;
aux1219_1290 = pow(r1_1287, r2_1288);
POP_TRACE();
aux_2219 = aux1219_1290;
}
}
}
}
return make_real(aux_2219);
}
}


/* string->real */double string__real_248___r4_numbers_6_5_flonum(char * string_56)
{
{
obj_t symbol1222_1291;
symbol1222_1291 = symbol1861___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1222_1291);
BUNSPEC;
{
double aux1221_1292;
aux1221_1292 = strtod(string_56, ((long)0));
POP_TRACE();
return aux1221_1292;
}
}
}
}


/* _string->real1263 */obj_t _string__real1263_20___r4_numbers_6_5_flonum(obj_t env_672, obj_t string_673)
{
{
double aux_2241;
{
char * string_1293;
{
obj_t aux_2242;
if(STRINGP(string_673)){
aux_2242 = string_673;
}
 else {
bigloo_type_error_location_103___error(symbol1862___r4_numbers_6_5_flonum, string1863___r4_numbers_6_5_flonum, string_673, string1784___r4_numbers_6_5_flonum, BINT(((long)18047)));
exit( -1 );}
string_1293 = BSTRING_TO_STRING(aux_2242);
}
{
obj_t symbol1222_1294;
symbol1222_1294 = symbol1861___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1222_1294);
BUNSPEC;
{
double aux1221_1295;
aux1221_1295 = strtod(string_1293, ((long)0));
POP_TRACE();
aux_2241 = aux1221_1295;
}
}
}
}
return make_real(aux_2241);
}
}


/* real->string */char * real__string_120___r4_numbers_6_5_flonum(double real_57)
{
{
obj_t symbol1224_1296;
symbol1224_1296 = symbol1864___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1224_1296);
BUNSPEC;
{
char * aux1223_1297;
aux1223_1297 = real_to_string(real_57);
POP_TRACE();
return aux1223_1297;
}
}
}
}


/* _real->string1264 */obj_t _real__string1264_158___r4_numbers_6_5_flonum(obj_t env_674, obj_t real_675)
{
{
char * aux_2256;
{
double real_1298;
{
obj_t aux_2257;
if(REALP(real_675)){
aux_2257 = real_675;
}
 else {
bigloo_type_error_location_103___error(symbol1865___r4_numbers_6_5_flonum, string1783___r4_numbers_6_5_flonum, real_675, string1784___r4_numbers_6_5_flonum, BINT(((long)18329)));
exit( -1 );}
real_1298 = REAL_TO_DOUBLE(aux_2257);
}
{
obj_t symbol1224_1299;
symbol1224_1299 = symbol1864___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1224_1299);
BUNSPEC;
{
char * aux1223_1300;
aux1223_1300 = real_to_string(real_1298);
POP_TRACE();
aux_2256 = aux1223_1300;
}
}
}
}
return string_to_bstring(aux_2256);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_numbers_6_5_flonum()
{
{
obj_t symbol1226_577;
symbol1226_577 = symbol1866___r4_numbers_6_5_flonum;
{
PUSH_TRACE(symbol1226_577);
BUNSPEC;
{
obj_t aux1225_578;
aux1225_578 = module_initialization_70___error(((long)0), "__R4_NUMBERS_6_5_FLONUM");
POP_TRACE();
return aux1225_578;
}
}
}
}

