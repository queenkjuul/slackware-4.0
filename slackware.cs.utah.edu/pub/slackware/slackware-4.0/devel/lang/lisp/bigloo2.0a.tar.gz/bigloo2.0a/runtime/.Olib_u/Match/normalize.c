/*===========================================================================*/
/*   (Match/normalize.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t standardize_tree_variable_65___match_normalize(obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t standardize_vector_187___match_normalize(obj_t);
static obj_t standardize_lispish_segment_variable_230___match_normalize(obj_t, obj_t);
static obj_t standardize_real_cons_8___match_normalize(obj_t, obj_t);
static obj_t standardize_term_variable_242___match_normalize(obj_t);
static bool_t coherent_environment__29___match_normalize(obj_t, obj_t);
extern obj_t vector__list_155___r4_vectors_6_8(obj_t);
static obj_t lambda1821___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1802___match_normalize(obj_t, obj_t, obj_t);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___match_normalize();
static obj_t standardize_sexp_242___match_normalize();
static obj_t lambda1719___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1696___match_normalize(obj_t, obj_t, obj_t);
static obj_t r_macro_pattern_init_240___match_normalize = BUNSPEC;
static obj_t lambda1640___match_normalize(obj_t, obj_t, obj_t);
static obj_t standardize_hole_variable_41___match_normalize(obj_t);
static obj_t lambda1562___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1555___match_normalize(obj_t, obj_t, obj_t);
static obj_t standardize_segment_variable_235___match_normalize(obj_t, obj_t);
static obj_t lambda1540___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1532___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1518___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1499___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1491___match_normalize(obj_t, obj_t);
static obj_t lambda1478___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1441___match_normalize(obj_t, obj_t, obj_t);
static bool_t lispish_segment_variable__20___match_normalize(obj_t);
static obj_t arg1396_2059___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1396_2060___match_normalize(obj_t, obj_t, obj_t);
extern obj_t extend_r_macro_env_37___match_normalize(obj_t, obj_t);
static bool_t term_variable__31___match_normalize(obj_t);
extern obj_t atom__231___match_s2cfun(obj_t);
static obj_t standardize_repetition_54___match_normalize(obj_t, obj_t);
static obj_t lambda1253___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1720___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1223___match_normalize(obj_t, obj_t, obj_t);
static obj_t _extend_r_macro_env_245___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1209___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1199___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1185___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1649___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1645___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1158___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1625___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1125___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1093___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1565___match_normalize(obj_t, obj_t, obj_t);
static obj_t lambda1047___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1522___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1519___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1503___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1500___match_normalize(obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t arg1446___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1443___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1396___match_normalize(obj_t, obj_t, obj_t);
static obj_t pattern_length_193___match_normalize(obj_t);
static obj_t standardize_cons_143___match_normalize(obj_t, obj_t);
extern obj_t assoc___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t match_define_structure__81___match_normalize(obj_t);
extern obj_t module_initialization_70___match_normalize(long, char *);
extern obj_t module_initialization_70___match_s2cfun(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_substring(obj_t, long, long);
static obj_t arg1251___match_normalize(obj_t, obj_t);
static obj_t arg1221___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1207___match_normalize(obj_t, obj_t);
static obj_t arg1196___match_normalize(obj_t, obj_t);
static obj_t arg1186___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1183___match_normalize(obj_t, obj_t);
static obj_t arg1167___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1160___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1156___match_normalize(obj_t, obj_t, obj_t);
static obj_t vectorify___match_normalize(obj_t);
static obj_t arg1134___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1127___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1123___match_normalize(obj_t, obj_t, obj_t);
static obj_t _match_define_structure__210___match_normalize(obj_t, obj_t);
static obj_t arg1095___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1102___match_normalize(obj_t, obj_t, obj_t);
static obj_t make_toggle_157___match_normalize();
static obj_t arg1091___match_normalize(obj_t, obj_t, obj_t);
static obj_t standardize_quote_221___match_normalize(obj_t);
static obj_t arg1053___match_normalize(obj_t, obj_t, obj_t);
static obj_t arg1045___match_normalize(obj_t, obj_t, obj_t);
static bool_t tree_variable__170___match_normalize(obj_t);
static obj_t standardize_real_xcons_221___match_normalize(obj_t, obj_t);
static obj_t _normalize_pattern_154___match_normalize(obj_t, obj_t);
static bool_t segment_variable__200___match_normalize(obj_t);
static obj_t r_macro_pattern_117___match_normalize = BUNSPEC;
extern obj_t jim_gensym_58___match_s2cfun;
static obj_t standardize_any_179___match_normalize(obj_t);
static obj_t _match_structures__166___match_normalize = BUNSPEC;
static obj_t oc_count_222___match_normalize(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t normalize_pattern_10___match_normalize(obj_t);
static obj_t standardize_pattern_107___match_normalize(obj_t);
static bool_t hole_variable__247___match_normalize(obj_t);
static obj_t symbol2140___match_normalize = BUNSPEC;
static obj_t symbol2138___match_normalize = BUNSPEC;
static obj_t symbol2135___match_normalize = BUNSPEC;
static obj_t symbol2132___match_normalize = BUNSPEC;
static obj_t symbol2129___match_normalize = BUNSPEC;
static obj_t symbol2126___match_normalize = BUNSPEC;
static obj_t symbol2125___match_normalize = BUNSPEC;
static obj_t symbol2122___match_normalize = BUNSPEC;
static obj_t symbol2119___match_normalize = BUNSPEC;
static obj_t symbol2120___match_normalize = BUNSPEC;
static obj_t symbol2118___match_normalize = BUNSPEC;
static obj_t symbol2117___match_normalize = BUNSPEC;
static obj_t symbol2116___match_normalize = BUNSPEC;
static obj_t symbol2115___match_normalize = BUNSPEC;
static obj_t symbol2114___match_normalize = BUNSPEC;
static obj_t symbol2113___match_normalize = BUNSPEC;
static obj_t symbol2112___match_normalize = BUNSPEC;
static obj_t symbol2111___match_normalize = BUNSPEC;
static obj_t symbol2110___match_normalize = BUNSPEC;
static obj_t symbol2098___match_normalize = BUNSPEC;
static obj_t symbol2097___match_normalize = BUNSPEC;
static obj_t symbol2107___match_normalize = BUNSPEC;
static obj_t symbol2106___match_normalize = BUNSPEC;
static obj_t symbol2094___match_normalize = BUNSPEC;
static obj_t symbol2104___match_normalize = BUNSPEC;
static obj_t symbol2103___match_normalize = BUNSPEC;
static obj_t symbol2092___match_normalize = BUNSPEC;
static obj_t symbol2102___match_normalize = BUNSPEC;
static obj_t symbol2091___match_normalize = BUNSPEC;
static obj_t symbol2089___match_normalize = BUNSPEC;
static obj_t symbol2100___match_normalize = BUNSPEC;
static obj_t symbol2085___match_normalize = BUNSPEC;
static obj_t symbol2083___match_normalize = BUNSPEC;
static obj_t symbol2082___match_normalize = BUNSPEC;
static obj_t symbol2080___match_normalize = BUNSPEC;
static obj_t symbol2078___match_normalize = BUNSPEC;
static obj_t symbol2076___match_normalize = BUNSPEC;
static obj_t symbol2074___match_normalize = BUNSPEC;
static obj_t symbol2072___match_normalize = BUNSPEC;
static obj_t symbol2070___match_normalize = BUNSPEC;
static obj_t symbol2068___match_normalize = BUNSPEC;
extern obj_t bigloo_type_error_241___error(obj_t, obj_t, obj_t);
static obj_t _prefer_xcons__227___match_normalize = BUNSPEC;
static obj_t list2137___match_normalize = BUNSPEC;
static obj_t list2136___match_normalize = BUNSPEC;
static obj_t list2134___match_normalize = BUNSPEC;
static obj_t list2133___match_normalize = BUNSPEC;
static obj_t list2131___match_normalize = BUNSPEC;
static obj_t list2130___match_normalize = BUNSPEC;
static obj_t list2128___match_normalize = BUNSPEC;
static obj_t list2127___match_normalize = BUNSPEC;
static obj_t imported_modules_init_94___match_normalize();
static obj_t list2121___match_normalize = BUNSPEC;
extern bool_t equal__25___r4_equivalence_6_2(obj_t, obj_t);
static obj_t require_initialization_114___match_normalize = BUNSPEC;
static obj_t standardize_lispish_any_127___match_normalize(obj_t);
static obj_t standardize_patterns_30___match_normalize(obj_t);
static obj_t cnst_init_137___match_normalize();
static obj_t unbound_pattern_153___match_normalize = BUNSPEC;
extern obj_t __2___r4_numbers_6_5(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( normalize_pattern_env_71___match_normalize, _normalize_pattern_154___match_normalize2142, _normalize_pattern_154___match_normalize, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( extend_r_macro_env_env_121___match_normalize, _extend_r_macro_env_245___match_normalize2143, _extend_r_macro_env_245___match_normalize, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc2124___match_normalize, arg1396_2060___match_normalize2144, arg1396_2060___match_normalize, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc2123___match_normalize, lambda1802___match_normalize2145, lambda1802___match_normalize, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc2099___match_normalize, arg1396_2059___match_normalize2146, arg1396_2059___match_normalize, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc2109___match_normalize, lambda1478___match_normalize2147, lambda1478___match_normalize, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc2090___match_normalize, arg1396___match_normalize2148, arg1396___match_normalize, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc2086___match_normalize, arg1251___match_normalize2149, va_generic_entry, arg1251___match_normalize, -1 );
DEFINE_STATIC_PROCEDURE( proc2084___match_normalize, arg1221___match_normalize2150, va_generic_entry, arg1221___match_normalize, -2 );
DEFINE_STATIC_PROCEDURE( proc2081___match_normalize, arg1207___match_normalize2151, arg1207___match_normalize, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc2079___match_normalize, arg1196___match_normalize2152, arg1196___match_normalize, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc2077___match_normalize, arg1183___match_normalize2153, arg1183___match_normalize, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc2075___match_normalize, arg1156___match_normalize2154, va_generic_entry, arg1156___match_normalize, -2 );
DEFINE_STATIC_PROCEDURE( proc2073___match_normalize, arg1123___match_normalize2155, va_generic_entry, arg1123___match_normalize, -2 );
DEFINE_STATIC_PROCEDURE( proc2071___match_normalize, arg1091___match_normalize2156, va_generic_entry, arg1091___match_normalize, -2 );
DEFINE_STATIC_PROCEDURE( proc2069___match_normalize, arg1045___match_normalize2157, va_generic_entry, arg1045___match_normalize, -2 );
DEFINE_STRING( string2139___match_normalize, string2139___match_normalize2158, "Incorrect declaration: ", 23 );
DEFINE_STRING( string2108___match_normalize, string2108___match_normalize2159, "HOLE-", 5 );
DEFINE_STRING( string2096___match_normalize, string2096___match_normalize2160, "Too many patterns provided for atom", 35 );
DEFINE_STRING( string2095___match_normalize, string2095___match_normalize2161, "ERREUR: ", 8 );
DEFINE_STRING( string2105___match_normalize, string2105___match_normalize2162, "g", 1 );
DEFINE_STRING( string2093___match_normalize, string2093___match_normalize2163, "Incompatible alternative", 24 );
DEFINE_STRING( string2101___match_normalize, string2101___match_normalize2164, "PROCEDURE", 9 );
DEFINE_STRING( string2088___match_normalize, string2088___match_normalize2165, "No such structure ", 18 );
DEFINE_STRING( string2087___match_normalize, string2087___match_normalize2166, "No such structure: ", 19 );
DEFINE_EXPORT_PROCEDURE( match_define_structure__env_226___match_normalize, _match_define_structure__210___match_normalize2167, _match_define_structure__210___match_normalize, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___match_normalize(long checksum_2654, char * from_2655)
{
if(CBOOL(require_initialization_114___match_normalize)){
require_initialization_114___match_normalize = BBOOL(((bool_t)0));
cnst_init_137___match_normalize();
imported_modules_init_94___match_normalize();
toplevel_init_63___match_normalize();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___match_normalize()
{
symbol2068___match_normalize = string_to_symbol("ATOM");
symbol2070___match_normalize = string_to_symbol("OR");
symbol2072___match_normalize = string_to_symbol("T-OR");
symbol2074___match_normalize = string_to_symbol("AND");
symbol2076___match_normalize = string_to_symbol("NOT");
symbol2078___match_normalize = string_to_symbol("?");
symbol2080___match_normalize = string_to_symbol("KWOTE");
symbol2082___match_normalize = string_to_symbol("**BAD-LUCK096561123523452**");
symbol2083___match_normalize = string_to_symbol("STRUCT-PAT");
symbol2085___match_normalize = string_to_symbol("_STRUCTURE_");
symbol2089___match_normalize = string_to_symbol("?-");
symbol2091___match_normalize = string_to_symbol("QUOTE");
symbol2092___match_normalize = string_to_symbol("CHECK");
symbol2094___match_normalize = string_to_symbol("PATTERN-MATCHING");
symbol2097___match_normalize = string_to_symbol("CONS");
symbol2098___match_normalize = string_to_symbol("ANY");
symbol2100___match_normalize = string_to_symbol("STANDARDIZE-PATTERN");
symbol2102___match_normalize = string_to_symbol("STANDARDIZE-PATTERNS");
symbol2103___match_normalize = string_to_symbol("\077\077\055");
symbol2104___match_normalize = string_to_symbol("\077\077\077-");
symbol2106___match_normalize = string_to_symbol("TIMES");
symbol2107___match_normalize = string_to_symbol("HOLE");
symbol2110___match_normalize = string_to_symbol("...");
symbol2111___match_normalize = string_to_symbol("VALUE");
symbol2112___match_normalize = string_to_symbol("ON");
symbol2113___match_normalize = string_to_symbol("OFF");
symbol2114___match_normalize = string_to_symbol("XCONS");
symbol2115___match_normalize = string_to_symbol("VAR");
symbol2116___match_normalize = string_to_symbol("SEGMENT");
symbol2117___match_normalize = string_to_symbol("SSETQ-APPEND");
symbol2118___match_normalize = string_to_symbol("TREE");
symbol2119___match_normalize = string_to_symbol("END-SSETQ");
symbol2120___match_normalize = string_to_symbol("EVAL-APPEND");
symbol2122___match_normalize = string_to_symbol("TAGGED-OR");
{
obj_t aux_2696;
{
obj_t aux_2697;
{
obj_t aux_2698;
{
obj_t aux_2699;
{
obj_t aux_2700;
aux_2700 = MAKE_PAIR(symbol2076___match_normalize, BNIL);
aux_2699 = MAKE_PAIR(symbol2097___match_normalize, aux_2700);
}
aux_2698 = MAKE_PAIR(symbol2122___match_normalize, aux_2699);
}
aux_2697 = MAKE_PAIR(symbol2072___match_normalize, aux_2698);
}
aux_2696 = MAKE_PAIR(symbol2074___match_normalize, aux_2697);
}
list2121___match_normalize = MAKE_PAIR(symbol2070___match_normalize, aux_2696);
}
symbol2125___match_normalize = string_to_symbol("VECTOR-BEGIN");
symbol2126___match_normalize = string_to_symbol("VECTOR-CONS");
list2127___match_normalize = MAKE_PAIR(symbol2098___match_normalize, BNIL);
symbol2129___match_normalize = string_to_symbol("VECTOR-ANY");
list2128___match_normalize = MAKE_PAIR(symbol2129___match_normalize, BNIL);
{
obj_t aux_2712;
aux_2712 = MAKE_PAIR(BNIL, BNIL);
list2130___match_normalize = MAKE_PAIR(symbol2091___match_normalize, aux_2712);
}
symbol2132___match_normalize = string_to_symbol("VECTOR-END");
list2131___match_normalize = MAKE_PAIR(symbol2132___match_normalize, BNIL);
{
obj_t aux_2717;
{
obj_t aux_2718;
aux_2718 = MAKE_PAIR(symbol2076___match_normalize, BNIL);
aux_2717 = MAKE_PAIR(symbol2070___match_normalize, aux_2718);
}
list2133___match_normalize = MAKE_PAIR(symbol2074___match_normalize, aux_2717);
}
{
obj_t aux_2722;
aux_2722 = MAKE_PAIR(symbol2118___match_normalize, BNIL);
list2134___match_normalize = MAKE_PAIR(symbol2106___match_normalize, aux_2722);
}
symbol2135___match_normalize = string_to_symbol("VECTOR-TIMES");
{
obj_t aux_2726;
aux_2726 = MAKE_PAIR(symbol2104___match_normalize, BNIL);
list2136___match_normalize = MAKE_PAIR(symbol2103___match_normalize, aux_2726);
}
{
obj_t aux_2729;
{
obj_t aux_2730;
{
obj_t aux_2731;
aux_2731 = MAKE_PAIR(symbol2122___match_normalize, BNIL);
aux_2730 = MAKE_PAIR(symbol2072___match_normalize, aux_2731);
}
aux_2729 = MAKE_PAIR(symbol2074___match_normalize, aux_2730);
}
list2137___match_normalize = MAKE_PAIR(symbol2070___match_normalize, aux_2729);
}
symbol2138___match_normalize = string_to_symbol("DEFINE-STRUCT");
return (symbol2140___match_normalize = string_to_symbol("ABORTED"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___match_normalize()
{
_prefer_xcons__227___match_normalize = make_toggle_157___match_normalize();
r_macro_pattern_init_240___match_normalize = BNIL;
r_macro_pattern_117___match_normalize = BNIL;
{
obj_t arg1044_368;
arg1044_368 = symbol2068___match_normalize;
{
obj_t arg1045_2371;
arg1045_2371 = proc2069___match_normalize;
{
obj_t fn_1445;
fn_1445 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1447;
arg1809_1447 = MAKE_PAIR(arg1044_368, arg1045_2371);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1447, fn_1445);
}
}
}
}
symbol2068___match_normalize;
{
obj_t arg1090_417;
arg1090_417 = symbol2070___match_normalize;
{
obj_t arg1091_2368;
arg1091_2368 = proc2071___match_normalize;
{
obj_t fn_1459;
fn_1459 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1461;
arg1809_1461 = MAKE_PAIR(arg1090_417, arg1091_2368);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1461, fn_1459);
}
}
}
}
symbol2070___match_normalize;
{
obj_t arg1122_460;
arg1122_460 = symbol2072___match_normalize;
{
obj_t arg1123_2364;
arg1123_2364 = proc2073___match_normalize;
{
obj_t fn_1473;
fn_1473 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1475;
arg1809_1475 = MAKE_PAIR(arg1122_460, arg1123_2364);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1475, fn_1473);
}
}
}
}
symbol2072___match_normalize;
{
obj_t arg1155_503;
arg1155_503 = symbol2074___match_normalize;
{
obj_t arg1156_2360;
arg1156_2360 = proc2075___match_normalize;
{
obj_t fn_1487;
fn_1487 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1489;
arg1809_1489 = MAKE_PAIR(arg1155_503, arg1156_2360);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1489, fn_1487);
}
}
}
}
symbol2074___match_normalize;
{
obj_t arg1182_541;
arg1182_541 = symbol2076___match_normalize;
{
obj_t arg1183_2356;
arg1183_2356 = proc2077___match_normalize;
{
obj_t fn_1502;
fn_1502 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1504;
arg1809_1504 = MAKE_PAIR(arg1182_541, arg1183_2356);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1504, fn_1502);
}
}
}
}
symbol2076___match_normalize;
{
obj_t arg1195_561;
arg1195_561 = symbol2078___match_normalize;
{
obj_t arg1196_2353;
arg1196_2353 = proc2079___match_normalize;
{
obj_t fn_1525;
fn_1525 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1527;
arg1809_1527 = MAKE_PAIR(arg1195_561, arg1196_2353);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1527, fn_1525);
}
}
}
}
symbol2078___match_normalize;
{
obj_t arg1206_575;
arg1206_575 = symbol2080___match_normalize;
{
obj_t arg1207_2351;
arg1207_2351 = proc2081___match_normalize;
{
obj_t fn_1538;
fn_1538 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1540;
arg1809_1540 = MAKE_PAIR(arg1206_575, arg1207_2351);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1540, fn_1538);
}
}
}
}
symbol2080___match_normalize;
unbound_pattern_153___match_normalize = symbol2082___match_normalize;
_match_structures__166___match_normalize = BNIL;
{
obj_t arg1220_589;
arg1220_589 = symbol2083___match_normalize;
{
obj_t arg1221_2349;
arg1221_2349 = proc2084___match_normalize;
{
obj_t fn_1551;
fn_1551 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1553;
arg1809_1553 = MAKE_PAIR(arg1220_589, arg1221_2349);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1553, fn_1551);
}
}
}
}
symbol2083___match_normalize;
{
obj_t arg1250_624;
arg1250_624 = symbol2085___match_normalize;
{
obj_t arg1251_2346;
arg1251_2346 = proc2086___match_normalize;
{
obj_t fn_1623;
fn_1623 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_1625;
arg1809_1625 = MAKE_PAIR(arg1250_624, arg1251_2346);
r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_1625, fn_1623);
}
}
}
}
return symbol2085___match_normalize;
}


/* arg1251 */obj_t arg1251___match_normalize(obj_t env_2372, obj_t f_2373)
{
{
obj_t f_626;
f_626 = f_2373;
{
obj_t lambda1253_2345;
lambda1253_2345 = make_fx_procedure(lambda1253___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1253_2345, ((long)0), f_626);
return lambda1253_2345;
}
}
}


/* lambda1253 */obj_t lambda1253___match_normalize(obj_t env_2374, obj_t r_2376, obj_t c_2377)
{
{
obj_t f_2375;
f_2375 = PROCEDURE_REF(env_2374, ((long)0));
{
obj_t r_628;
obj_t c_629;
r_628 = r_2376;
c_629 = c_2377;
{
obj_t provided_fields_116_689;
{
obj_t structure_632;
{
bool_t test_2760;
{
obj_t aux_2761;
aux_2761 = CAR(f_2375);
test_2760 = PAIRP(aux_2761);
}
if(test_2760){
obj_t arg1287_668;
{
obj_t l1030_669;
l1030_669 = CDR(f_2375);
if(NULLP(l1030_669)){
arg1287_668 = BNIL;
}
 else {
obj_t head1032_671;
{
obj_t aux_2767;
{
obj_t aux_2768;
aux_2768 = CAR(l1030_669);
aux_2767 = CAR(aux_2768);
}
head1032_671 = MAKE_PAIR(aux_2767, BNIL);
}
{
obj_t l1030_1639;
obj_t tail1033_1640;
l1030_1639 = CDR(l1030_669);
tail1033_1640 = head1032_671;
lname1031_1638:
if(NULLP(l1030_1639)){
arg1287_668 = head1032_671;
}
 else {
obj_t newtail1034_1648;
{
obj_t aux_2774;
{
obj_t aux_2775;
aux_2775 = CAR(l1030_1639);
aux_2774 = CAR(aux_2775);
}
newtail1034_1648 = MAKE_PAIR(aux_2774, BNIL);
}
SET_CDR(tail1033_1640, newtail1034_1648);
{
obj_t tail1033_2782;
obj_t l1030_2780;
l1030_2780 = CDR(l1030_1639);
tail1033_2782 = newtail1034_1648;
tail1033_1640 = tail1033_2782;
l1030_1639 = l1030_2780;
goto lname1031_1638;
}
}
}
}
}
provided_fields_116_689 = arg1287_668;
{
obj_t s_691;
s_691 = _match_structures__166___match_normalize;
loop1_692:
{
obj_t p_f_44_693;
p_f_44_693 = provided_fields_116_689;
loop2_694:
if(NULLP(s_691)){
FAILURE(string2087___match_normalize,provided_fields_116_689,BNIL);}
 else {
if(NULLP(p_f_44_693)){
structure_632 = CAR(s_691);
}
 else {
bool_t test_2790;
{
obj_t aux_2791;
{
obj_t aux_2792;
{
obj_t aux_2794;
aux_2794 = CAR(s_691);
aux_2792 = CDR(aux_2794);
}
aux_2791 = memq___r4_pairs_and_lists_6_3(CAR(p_f_44_693), aux_2792);
}
test_2790 = CBOOL(aux_2791);
}
if(test_2790){
obj_t p_f_44_2799;
p_f_44_2799 = CDR(p_f_44_693);
p_f_44_693 = p_f_44_2799;
goto loop2_694;
}
 else {
obj_t s_2801;
s_2801 = CDR(s_691);
s_691 = s_2801;
goto loop1_692;
}
}
}
}
}
}
 else {
bool_t test1300_685;
{
obj_t aux_2803;
aux_2803 = assoc___r4_pairs_and_lists_6_3(CAR(f_2375), _match_structures__166___match_normalize);
test1300_685 = CBOOL(aux_2803);
}
if(test1300_685){
structure_632 = assoc___r4_pairs_and_lists_6_3(CAR(f_2375), _match_structures__166___match_normalize);
}
 else {
obj_t object_1695;
object_1695 = _match_structures__166___match_normalize;
FAILURE(string2088___match_normalize,f_2375,object_1695);}
}
}
{
obj_t name_633;
name_633 = CAR(structure_632);
{
obj_t fields_634;
fields_634 = CDR(structure_632);
{
obj_t provided_fields_116_635;
{
bool_t test_2813;
{
obj_t aux_2814;
aux_2814 = CAR(f_2375);
test_2813 = PAIRP(aux_2814);
}
if(test_2813){
provided_fields_116_635 = f_2375;
}
 else {
provided_fields_116_635 = CDR(f_2375);
}
}
{
obj_t pattern_636;
{
obj_t arg1257_638;
obj_t arg1258_639;
arg1257_638 = symbol2083___match_normalize;
{
obj_t arg1263_643;
obj_t arg1265_644;
{
bool_t test_2818;
{
obj_t aux_2819;
aux_2819 = CAR(f_2375);
test_2818 = PAIRP(aux_2819);
}
if(test_2818){
if(NULLP(fields_634)){
arg1263_643 = BNIL;
}
 else {
obj_t head1037_648;
head1037_648 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1035_649;
obj_t tail1038_650;
l1035_649 = fields_634;
tail1038_650 = head1037_648;
lname1036_651:
if(NULLP(l1035_649)){
arg1263_643 = CDR(head1037_648);
}
 else {
obj_t newtail1039_653;
{
obj_t aux_2828;
{
obj_t field_657;
field_657 = CAR(l1035_649);
{
bool_t test_2830;
{
obj_t aux_2831;
aux_2831 = assoc___r4_pairs_and_lists_6_3(field_657, provided_fields_116_635);
test_2830 = CBOOL(aux_2831);
}
if(test_2830){
obj_t aux_2834;
{
obj_t aux_2835;
aux_2835 = assoc___r4_pairs_and_lists_6_3(field_657, provided_fields_116_635);
aux_2834 = CDR(aux_2835);
}
aux_2828 = CAR(aux_2834);
}
 else {
aux_2828 = symbol2089___match_normalize;
}
}
}
newtail1039_653 = MAKE_PAIR(aux_2828, BNIL);
}
SET_CDR(tail1038_650, newtail1039_653);
{
obj_t tail1038_2843;
obj_t l1035_2841;
l1035_2841 = CDR(l1035_649);
tail1038_2843 = newtail1039_653;
tail1038_650 = tail1038_2843;
l1035_649 = l1035_2841;
goto lname1036_651;
}
}
}
}
}
 else {
arg1263_643 = CDR(f_2375);
}
}
arg1265_644 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1258_639 = append_2_18___r4_pairs_and_lists_6_3(arg1263_643, arg1265_644);
}
{
obj_t list1259_640;
{
obj_t arg1260_641;
arg1260_641 = MAKE_PAIR(arg1258_639, BNIL);
list1259_640 = MAKE_PAIR(name_633, arg1260_641);
}
pattern_636 = cons__138___r4_pairs_and_lists_6_3(arg1257_638, list1259_640);
}
}
{
{
obj_t fun1256_637;
fun1256_637 = standardize_pattern_107___match_normalize(pattern_636);
return PROCEDURE_ENTRY(fun1256_637)(fun1256_637, r_628, c_629, BEOA);
}
}
}
}
}
}
}
}
}
}
}


/* arg1221 */obj_t arg1221___match_normalize(obj_t env_2378, obj_t name_2379, obj_t e__176_2380)
{
{
obj_t name_591;
obj_t e__176_592;
name_591 = name_2379;
e__176_592 = e__176_2380;
{
obj_t lambda1223_2348;
lambda1223_2348 = make_fx_procedure(lambda1223___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1223_2348, ((long)0), e__176_592);
PROCEDURE_SET(lambda1223_2348, ((long)1), name_591);
return lambda1223_2348;
}
}
}


/* lambda1223 */obj_t lambda1223___match_normalize(obj_t env_2381, obj_t r_2384, obj_t c_2385)
{
{
obj_t e__176_2382;
obj_t name_2383;
e__176_2382 = PROCEDURE_REF(env_2381, ((long)0));
name_2383 = PROCEDURE_REF(env_2381, ((long)1));
{
obj_t r_594;
obj_t c_595;
r_594 = r_2384;
c_595 = c_2385;
{
obj_t arg1224_597;
{
obj_t arg1225_598;
obj_t arg1226_599;
arg1225_598 = symbol2083___match_normalize;
{
obj_t arg1232_603;
obj_t arg1233_604;
if(NULLP(e__176_2382)){
arg1232_603 = BNIL;
}
 else {
obj_t head1027_607;
{
obj_t arg1244_618;
{
obj_t fun1397_1560;
fun1397_1560 = standardize_pattern_107___match_normalize(CAR(e__176_2382));
{
obj_t arg1396_2347;
arg1396_2347 = proc2090___match_normalize;
arg1244_618 = PROCEDURE_ENTRY(fun1397_1560)(fun1397_1560, r_macro_pattern_117___match_normalize, arg1396_2347, BEOA);
}
}
head1027_607 = MAKE_PAIR(arg1244_618, BNIL);
}
{
obj_t l1025_1568;
obj_t tail1028_1569;
l1025_1568 = CDR(e__176_2382);
tail1028_1569 = head1027_607;
lname1026_1567:
if(NULLP(l1025_1568)){
arg1232_603 = head1027_607;
}
 else {
obj_t newtail1029_1577;
{
obj_t arg1240_1578;
arg1240_1578 = normalize_pattern_10___match_normalize(CAR(l1025_1568));
newtail1029_1577 = MAKE_PAIR(arg1240_1578, BNIL);
}
SET_CDR(tail1028_1569, newtail1029_1577);
{
obj_t tail1028_2873;
obj_t l1025_2871;
l1025_2871 = CDR(l1025_1568);
tail1028_2873 = newtail1029_1577;
tail1028_1569 = tail1028_2873;
l1025_1568 = l1025_2871;
goto lname1026_1567;
}
}
}
}
arg1233_604 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1226_599 = append_2_18___r4_pairs_and_lists_6_3(arg1232_603, arg1233_604);
}
{
obj_t list1227_600;
{
obj_t arg1228_601;
arg1228_601 = MAKE_PAIR(arg1226_599, BNIL);
list1227_600 = MAKE_PAIR(name_2383, arg1228_601);
}
arg1224_597 = cons__138___r4_pairs_and_lists_6_3(arg1225_598, list1227_600);
}
}
return PROCEDURE_ENTRY(c_595)(c_595, arg1224_597, r_594, BEOA);
}
}
}
}


/* arg1396 */obj_t arg1396___match_normalize(obj_t env_2386, obj_t pattern_2387, obj_t rr_2388)
{
{
obj_t pattern_2648;
pattern_2648 = pattern_2387;
return pattern_2648;
}
}


/* arg1207 */obj_t arg1207___match_normalize(obj_t env_2389, obj_t e_2390)
{
{
obj_t e_577;
e_577 = e_2390;
{
obj_t lambda1209_2350;
lambda1209_2350 = make_fx_procedure(lambda1209___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1209_2350, ((long)0), e_577);
return lambda1209_2350;
}
}
}


/* lambda1209 */obj_t lambda1209___match_normalize(obj_t env_2391, obj_t r_2393, obj_t c_2394)
{
{
obj_t e_2392;
e_2392 = PROCEDURE_REF(env_2391, ((long)0));
{
obj_t r_579;
obj_t c_580;
r_579 = r_2393;
c_580 = c_2394;
{
obj_t arg1210_1544;
{
obj_t arg1211_1545;
arg1211_1545 = symbol2091___match_normalize;
{
obj_t list1214_1547;
{
obj_t arg1216_1548;
arg1216_1548 = MAKE_PAIR(BNIL, BNIL);
list1214_1547 = MAKE_PAIR(e_2392, arg1216_1548);
}
arg1210_1544 = cons__138___r4_pairs_and_lists_6_3(arg1211_1545, list1214_1547);
}
}
return PROCEDURE_ENTRY(c_580)(c_580, arg1210_1544, r_579, BEOA);
}
}
}
}


/* arg1196 */obj_t arg1196___match_normalize(obj_t env_2395, obj_t e_2396)
{
{
obj_t e_563;
e_563 = e_2396;
{
obj_t lambda1199_2352;
lambda1199_2352 = make_fx_procedure(lambda1199___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1199_2352, ((long)0), e_563);
return lambda1199_2352;
}
}
}


/* lambda1199 */obj_t lambda1199___match_normalize(obj_t env_2397, obj_t r_2399, obj_t c_2400)
{
{
obj_t e_2398;
e_2398 = PROCEDURE_REF(env_2397, ((long)0));
{
obj_t r_565;
obj_t c_566;
r_565 = r_2399;
c_566 = c_2400;
{
obj_t arg1200_1531;
{
obj_t arg1201_1532;
arg1201_1532 = symbol2092___match_normalize;
{
obj_t list1203_1534;
{
obj_t arg1204_1535;
arg1204_1535 = MAKE_PAIR(BNIL, BNIL);
list1203_1534 = MAKE_PAIR(e_2398, arg1204_1535);
}
arg1200_1531 = cons__138___r4_pairs_and_lists_6_3(arg1201_1532, list1203_1534);
}
}
return PROCEDURE_ENTRY(c_566)(c_566, arg1200_1531, r_565, BEOA);
}
}
}
}


/* arg1183 */obj_t arg1183___match_normalize(obj_t env_2401, obj_t e_2402)
{
{
obj_t e_543;
e_543 = e_2402;
{
obj_t lambda1185_2355;
lambda1185_2355 = make_fx_procedure(lambda1185___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1185_2355, ((long)0), e_543);
return lambda1185_2355;
}
}
}


/* lambda1185 */obj_t lambda1185___match_normalize(obj_t env_2403, obj_t r_2405, obj_t c_2406)
{
{
obj_t e_2404;
e_2404 = PROCEDURE_REF(env_2403, ((long)0));
{
obj_t r_545;
obj_t c_546;
r_545 = r_2405;
c_546 = c_2406;
{
obj_t fun1187_1508;
fun1187_1508 = standardize_pattern_107___match_normalize(e_2404);
{
obj_t arg1186_2354;
arg1186_2354 = make_fx_procedure(arg1186___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1186_2354, ((long)0), c_546);
PROCEDURE_SET(arg1186_2354, ((long)1), r_545);
return PROCEDURE_ENTRY(fun1187_1508)(fun1187_1508, r_545, arg1186_2354, BEOA);
}
}
}
}
}


/* arg1186 */obj_t arg1186___match_normalize(obj_t env_2407, obj_t pattern_2410, obj_t rr_2411)
{
{
obj_t c_2408;
obj_t r_2409;
c_2408 = PROCEDURE_REF(env_2407, ((long)0));
r_2409 = PROCEDURE_REF(env_2407, ((long)1));
{
obj_t pattern_1510;
obj_t rr_1511;
pattern_1510 = pattern_2410;
rr_1511 = rr_2411;
{
obj_t arg1189_1518;
{
obj_t arg1190_1519;
arg1190_1519 = symbol2076___match_normalize;
{
obj_t list1192_1521;
{
obj_t arg1193_1522;
arg1193_1522 = MAKE_PAIR(BNIL, BNIL);
list1192_1521 = MAKE_PAIR(pattern_1510, arg1193_1522);
}
arg1189_1518 = cons__138___r4_pairs_and_lists_6_3(arg1190_1519, list1192_1521);
}
}
return PROCEDURE_ENTRY(c_2408)(c_2408, arg1189_1518, r_2409, BEOA);
}
}
}
}


/* arg1156 */obj_t arg1156___match_normalize(obj_t env_2412, obj_t e_2413, obj_t e__176_2414)
{
{
obj_t e_505;
obj_t e__176_506;
e_505 = e_2413;
e__176_506 = e__176_2414;
{
obj_t lambda1158_2359;
lambda1158_2359 = make_fx_procedure(lambda1158___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1158_2359, ((long)0), e__176_506);
PROCEDURE_SET(lambda1158_2359, ((long)1), e_505);
return lambda1158_2359;
}
}
}


/* lambda1158 */obj_t lambda1158___match_normalize(obj_t env_2415, obj_t r_2418, obj_t c_2419)
{
{
obj_t e__176_2416;
obj_t e_2417;
e__176_2416 = PROCEDURE_REF(env_2415, ((long)0));
e_2417 = PROCEDURE_REF(env_2415, ((long)1));
{
obj_t r_508;
obj_t c_509;
r_508 = r_2418;
c_509 = c_2419;
if(PAIRP(e__176_2416)){
obj_t fun1161_512;
fun1161_512 = standardize_pattern_107___match_normalize(e_2417);
{
obj_t arg1160_2358;
arg1160_2358 = make_fx_procedure(arg1160___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1160_2358, ((long)0), e__176_2416);
PROCEDURE_SET(arg1160_2358, ((long)1), c_509);
return PROCEDURE_ENTRY(fun1161_512)(fun1161_512, r_508, arg1160_2358, BEOA);
}
}
 else {
obj_t fun1181_539;
fun1181_539 = standardize_pattern_107___match_normalize(e_2417);
return PROCEDURE_ENTRY(fun1181_539)(fun1181_539, r_508, c_509, BEOA);
}
}
}
}


/* arg1160 */obj_t arg1160___match_normalize(obj_t env_2420, obj_t pattern1_2423, obj_t rr_2424)
{
{
obj_t e__176_2421;
obj_t c_2422;
e__176_2421 = PROCEDURE_REF(env_2420, ((long)0));
c_2422 = PROCEDURE_REF(env_2420, ((long)1));
{
obj_t pattern1_514;
obj_t rr_515;
pattern1_514 = pattern1_2423;
rr_515 = rr_2424;
{
obj_t fun1168_521;
{
obj_t arg1177_534;
{
obj_t arg1178_535;
arg1178_535 = symbol2074___match_normalize;
{
obj_t list1179_536;
list1179_536 = MAKE_PAIR(e__176_2421, BNIL);
arg1177_534 = cons__138___r4_pairs_and_lists_6_3(arg1178_535, list1179_536);
}
}
fun1168_521 = standardize_pattern_107___match_normalize(arg1177_534);
}
{
obj_t arg1167_2357;
arg1167_2357 = make_fx_procedure(arg1167___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1167_2357, ((long)0), pattern1_514);
PROCEDURE_SET(arg1167_2357, ((long)1), c_2422);
return PROCEDURE_ENTRY(fun1168_521)(fun1168_521, rr_515, arg1167_2357, BEOA);
}
}
}
}
}


/* arg1167 */obj_t arg1167___match_normalize(obj_t env_2425, obj_t pattern2_2428, obj_t rrr_2429)
{
{
obj_t pattern1_2426;
obj_t c_2427;
pattern1_2426 = PROCEDURE_REF(env_2425, ((long)0));
c_2427 = PROCEDURE_REF(env_2425, ((long)1));
{
obj_t pattern2_523;
obj_t rrr_524;
pattern2_523 = pattern2_2428;
rrr_524 = rrr_2429;
{
obj_t arg1170_1494;
{
obj_t arg1171_1495;
arg1171_1495 = symbol2074___match_normalize;
{
obj_t list1173_1497;
{
obj_t arg1174_1498;
{
obj_t arg1175_1499;
arg1175_1499 = MAKE_PAIR(BNIL, BNIL);
arg1174_1498 = MAKE_PAIR(pattern2_523, arg1175_1499);
}
list1173_1497 = MAKE_PAIR(pattern1_2426, arg1174_1498);
}
arg1170_1494 = cons__138___r4_pairs_and_lists_6_3(arg1171_1495, list1173_1497);
}
}
return PROCEDURE_ENTRY(c_2427)(c_2427, arg1170_1494, rrr_524, BEOA);
}
}
}
}


/* arg1123 */obj_t arg1123___match_normalize(obj_t env_2430, obj_t e_2431, obj_t e__176_2432)
{
{
obj_t e_462;
obj_t e__176_463;
e_462 = e_2431;
e__176_463 = e__176_2432;
{
obj_t lambda1125_2363;
lambda1125_2363 = make_fx_procedure(lambda1125___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1125_2363, ((long)0), e__176_463);
PROCEDURE_SET(lambda1125_2363, ((long)1), e_462);
return lambda1125_2363;
}
}
}


/* lambda1125 */obj_t lambda1125___match_normalize(obj_t env_2433, obj_t r_2436, obj_t c_2437)
{
{
obj_t e__176_2434;
obj_t e_2435;
e__176_2434 = PROCEDURE_REF(env_2433, ((long)0));
e_2435 = PROCEDURE_REF(env_2433, ((long)1));
{
obj_t r_465;
obj_t c_466;
r_465 = r_2436;
c_466 = c_2437;
if(PAIRP(e__176_2434)){
obj_t fun1128_469;
fun1128_469 = standardize_pattern_107___match_normalize(e_2435);
{
obj_t arg1127_2362;
arg1127_2362 = make_fx_procedure(arg1127___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(arg1127_2362, ((long)0), e__176_2434);
PROCEDURE_SET(arg1127_2362, ((long)1), c_466);
PROCEDURE_SET(arg1127_2362, ((long)2), r_465);
return PROCEDURE_ENTRY(fun1128_469)(fun1128_469, r_465, arg1127_2362, BEOA);
}
}
 else {
obj_t fun1154_501;
fun1154_501 = standardize_pattern_107___match_normalize(e_2435);
return PROCEDURE_ENTRY(fun1154_501)(fun1154_501, r_465, c_466, BEOA);
}
}
}
}


/* arg1127 */obj_t arg1127___match_normalize(obj_t env_2438, obj_t pattern1_2442, obj_t rr_2443)
{
{
obj_t e__176_2439;
obj_t c_2440;
obj_t r_2441;
e__176_2439 = PROCEDURE_REF(env_2438, ((long)0));
c_2440 = PROCEDURE_REF(env_2438, ((long)1));
r_2441 = PROCEDURE_REF(env_2438, ((long)2));
{
obj_t pattern1_471;
obj_t rr_472;
pattern1_471 = pattern1_2442;
rr_472 = rr_2443;
{
obj_t fun1135_478;
{
obj_t arg1150_496;
{
obj_t arg1151_497;
arg1151_497 = symbol2072___match_normalize;
{
obj_t list1152_498;
list1152_498 = MAKE_PAIR(e__176_2439, BNIL);
arg1150_496 = cons__138___r4_pairs_and_lists_6_3(arg1151_497, list1152_498);
}
}
fun1135_478 = standardize_pattern_107___match_normalize(arg1150_496);
}
{
obj_t arg1134_2361;
arg1134_2361 = make_fx_procedure(arg1134___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(arg1134_2361, ((long)0), rr_472);
PROCEDURE_SET(arg1134_2361, ((long)1), pattern1_471);
PROCEDURE_SET(arg1134_2361, ((long)2), c_2440);
return PROCEDURE_ENTRY(fun1135_478)(fun1135_478, r_2441, arg1134_2361, BEOA);
}
}
}
}
}


/* arg1134 */obj_t arg1134___match_normalize(obj_t env_2444, obj_t pattern2_2448, obj_t rrr_2449)
{
{
obj_t rr_2445;
obj_t pattern1_2446;
obj_t c_2447;
rr_2445 = PROCEDURE_REF(env_2444, ((long)0));
pattern1_2446 = PROCEDURE_REF(env_2444, ((long)1));
c_2447 = PROCEDURE_REF(env_2444, ((long)2));
{
obj_t pattern2_480;
obj_t rrr_481;
pattern2_480 = pattern2_2448;
rrr_481 = rrr_2449;
{
bool_t test1137_483;
{
bool_t test1149_494;
test1149_494 = coherent_environment__29___match_normalize(rr_2445, rrr_481);
if(test1149_494){
test1137_483 = coherent_environment__29___match_normalize(rrr_481, rr_2445);
}
 else {
test1137_483 = ((bool_t)0);
}
}
if(test1137_483){
obj_t arg1139_484;
{
obj_t arg1140_485;
arg1140_485 = symbol2072___match_normalize;
{
obj_t list1142_487;
{
obj_t arg1143_488;
{
obj_t arg1144_489;
arg1144_489 = MAKE_PAIR(BNIL, BNIL);
arg1143_488 = MAKE_PAIR(pattern2_480, arg1144_489);
}
list1142_487 = MAKE_PAIR(pattern1_2446, arg1143_488);
}
arg1139_484 = cons__138___r4_pairs_and_lists_6_3(arg1140_485, list1142_487);
}
}
return PROCEDURE_ENTRY(c_2447)(c_2447, arg1139_484, rrr_481, BEOA);
}
 else {
obj_t list1146_491;
list1146_491 = MAKE_PAIR(string2093___match_normalize, BNIL);
FAILURE(symbol2094___match_normalize,string2095___match_normalize,list1146_491);}
}
}
}
}


/* arg1091 */obj_t arg1091___match_normalize(obj_t env_2450, obj_t e_2451, obj_t e__176_2452)
{
{
obj_t e_419;
obj_t e__176_420;
e_419 = e_2451;
e__176_420 = e__176_2452;
{
obj_t lambda1093_2367;
lambda1093_2367 = make_fx_procedure(lambda1093___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1093_2367, ((long)0), e__176_420);
PROCEDURE_SET(lambda1093_2367, ((long)1), e_419);
return lambda1093_2367;
}
}
}


/* lambda1093 */obj_t lambda1093___match_normalize(obj_t env_2453, obj_t r_2456, obj_t c_2457)
{
{
obj_t e__176_2454;
obj_t e_2455;
e__176_2454 = PROCEDURE_REF(env_2453, ((long)0));
e_2455 = PROCEDURE_REF(env_2453, ((long)1));
{
obj_t r_422;
obj_t c_423;
r_422 = r_2456;
c_423 = c_2457;
if(PAIRP(e__176_2454)){
obj_t fun1096_426;
fun1096_426 = standardize_pattern_107___match_normalize(e_2455);
{
obj_t arg1095_2366;
arg1095_2366 = make_fx_procedure(arg1095___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(arg1095_2366, ((long)0), e__176_2454);
PROCEDURE_SET(arg1095_2366, ((long)1), c_423);
PROCEDURE_SET(arg1095_2366, ((long)2), r_422);
return PROCEDURE_ENTRY(fun1096_426)(fun1096_426, r_422, arg1095_2366, BEOA);
}
}
 else {
obj_t fun1121_458;
fun1121_458 = standardize_pattern_107___match_normalize(e_2455);
return PROCEDURE_ENTRY(fun1121_458)(fun1121_458, r_422, c_423, BEOA);
}
}
}
}


/* arg1095 */obj_t arg1095___match_normalize(obj_t env_2458, obj_t pattern1_2462, obj_t rr_2463)
{
{
obj_t e__176_2459;
obj_t c_2460;
obj_t r_2461;
e__176_2459 = PROCEDURE_REF(env_2458, ((long)0));
c_2460 = PROCEDURE_REF(env_2458, ((long)1));
r_2461 = PROCEDURE_REF(env_2458, ((long)2));
{
obj_t pattern1_428;
obj_t rr_429;
pattern1_428 = pattern1_2462;
rr_429 = rr_2463;
{
obj_t fun1103_435;
{
obj_t arg1117_453;
{
obj_t arg1118_454;
arg1118_454 = symbol2070___match_normalize;
{
obj_t list1119_455;
list1119_455 = MAKE_PAIR(e__176_2459, BNIL);
arg1117_453 = cons__138___r4_pairs_and_lists_6_3(arg1118_454, list1119_455);
}
}
fun1103_435 = standardize_pattern_107___match_normalize(arg1117_453);
}
{
obj_t arg1102_2365;
arg1102_2365 = make_fx_procedure(arg1102___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(arg1102_2365, ((long)0), rr_429);
PROCEDURE_SET(arg1102_2365, ((long)1), pattern1_428);
PROCEDURE_SET(arg1102_2365, ((long)2), c_2460);
return PROCEDURE_ENTRY(fun1103_435)(fun1103_435, r_2461, arg1102_2365, BEOA);
}
}
}
}
}


/* arg1102 */obj_t arg1102___match_normalize(obj_t env_2464, obj_t pattern2_2468, obj_t rrr_2469)
{
{
obj_t rr_2465;
obj_t pattern1_2466;
obj_t c_2467;
rr_2465 = PROCEDURE_REF(env_2464, ((long)0));
pattern1_2466 = PROCEDURE_REF(env_2464, ((long)1));
c_2467 = PROCEDURE_REF(env_2464, ((long)2));
{
obj_t pattern2_437;
obj_t rrr_438;
pattern2_437 = pattern2_2468;
rrr_438 = rrr_2469;
{
bool_t test1105_440;
{
bool_t test1116_451;
test1116_451 = coherent_environment__29___match_normalize(rr_2465, rrr_438);
if(test1116_451){
test1105_440 = coherent_environment__29___match_normalize(rrr_438, rr_2465);
}
 else {
test1105_440 = ((bool_t)0);
}
}
if(test1105_440){
obj_t arg1106_441;
{
obj_t arg1107_442;
arg1107_442 = symbol2070___match_normalize;
{
obj_t list1109_444;
{
obj_t arg1110_445;
{
obj_t arg1111_446;
arg1111_446 = MAKE_PAIR(BNIL, BNIL);
arg1110_445 = MAKE_PAIR(pattern2_437, arg1111_446);
}
list1109_444 = MAKE_PAIR(pattern1_2466, arg1110_445);
}
arg1106_441 = cons__138___r4_pairs_and_lists_6_3(arg1107_442, list1109_444);
}
}
return PROCEDURE_ENTRY(c_2467)(c_2467, arg1106_441, rrr_438, BEOA);
}
 else {
obj_t list1113_448;
list1113_448 = MAKE_PAIR(string2093___match_normalize, BNIL);
FAILURE(symbol2094___match_normalize,string2095___match_normalize,list1113_448);}
}
}
}
}


/* arg1045 */obj_t arg1045___match_normalize(obj_t env_2470, obj_t e_2471, obj_t e__176_2472)
{
{
obj_t e_370;
obj_t e__176_371;
e_370 = e_2471;
e__176_371 = e__176_2472;
{
obj_t lambda1047_2370;
lambda1047_2370 = make_fx_procedure(lambda1047___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1047_2370, ((long)0), e__176_371);
PROCEDURE_SET(lambda1047_2370, ((long)1), e_370);
return lambda1047_2370;
}
}
}


/* lambda1047 */obj_t lambda1047___match_normalize(obj_t env_2473, obj_t r_2476, obj_t c_2477)
{
{
obj_t e__176_2474;
obj_t e_2475;
e__176_2474 = PROCEDURE_REF(env_2473, ((long)0));
e_2475 = PROCEDURE_REF(env_2473, ((long)1));
{
obj_t r_373;
obj_t c_374;
r_373 = r_2476;
c_374 = c_2477;
if(PAIRP(e__176_2474)){
obj_t list1049_377;
list1049_377 = MAKE_PAIR(string2096___match_normalize, BNIL);
FAILURE(symbol2094___match_normalize,string2095___match_normalize,list1049_377);}
 else {
obj_t fun1054_380;
fun1054_380 = standardize_pattern_107___match_normalize(e_2475);
{
obj_t arg1053_2369;
arg1053_2369 = make_fx_procedure(arg1053___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(arg1053_2369, ((long)0), c_374);
return PROCEDURE_ENTRY(fun1054_380)(fun1054_380, r_373, arg1053_2369, BEOA);
}
}
}
}
}


/* arg1053 */obj_t arg1053___match_normalize(obj_t env_2478, obj_t pattern_2480, obj_t rr_2481)
{
{
obj_t c_2479;
c_2479 = PROCEDURE_REF(env_2478, ((long)0));
{
obj_t pattern_382;
obj_t rr_383;
pattern_382 = pattern_2480;
rr_383 = rr_2481;
{
obj_t arg1056_385;
{
obj_t arg1057_386;
obj_t arg1058_387;
arg1057_386 = symbol2074___match_normalize;
{
obj_t arg1065_393;
obj_t arg1066_394;
arg1065_393 = symbol2076___match_normalize;
{
obj_t arg1072_399;
obj_t arg1073_400;
obj_t arg1076_401;
arg1072_399 = symbol2097___match_normalize;
{
obj_t arg1082_407;
arg1082_407 = symbol2098___match_normalize;
{
obj_t list1084_409;
list1084_409 = MAKE_PAIR(BNIL, BNIL);
arg1073_400 = cons__138___r4_pairs_and_lists_6_3(arg1082_407, list1084_409);
}
}
{
obj_t arg1086_411;
arg1086_411 = symbol2098___match_normalize;
{
obj_t list1088_413;
list1088_413 = MAKE_PAIR(BNIL, BNIL);
arg1076_401 = cons__138___r4_pairs_and_lists_6_3(arg1086_411, list1088_413);
}
}
{
obj_t list1078_403;
{
obj_t arg1079_404;
{
obj_t arg1080_405;
arg1080_405 = MAKE_PAIR(BNIL, BNIL);
arg1079_404 = MAKE_PAIR(arg1076_401, arg1080_405);
}
list1078_403 = MAKE_PAIR(arg1073_400, arg1079_404);
}
arg1066_394 = cons__138___r4_pairs_and_lists_6_3(arg1072_399, list1078_403);
}
}
{
obj_t list1068_396;
{
obj_t arg1069_397;
arg1069_397 = MAKE_PAIR(BNIL, BNIL);
list1068_396 = MAKE_PAIR(arg1066_394, arg1069_397);
}
arg1058_387 = cons__138___r4_pairs_and_lists_6_3(arg1065_393, list1068_396);
}
}
{
obj_t list1060_389;
{
obj_t arg1061_390;
{
obj_t arg1062_391;
arg1062_391 = MAKE_PAIR(BNIL, BNIL);
arg1061_390 = MAKE_PAIR(pattern_382, arg1062_391);
}
list1060_389 = MAKE_PAIR(arg1058_387, arg1061_390);
}
arg1056_385 = cons__138___r4_pairs_and_lists_6_3(arg1057_386, list1060_389);
}
}
return PROCEDURE_ENTRY(c_2479)(c_2479, arg1056_385, rr_383, BEOA);
}
}
}
}


/* term-variable? */bool_t term_variable__31___match_normalize(obj_t e_1)
{
if(SYMBOLP(e_1)){
bool_t _andtest_1003_707;
{
long arg1323_711;
{
obj_t arg1325_713;
arg1325_713 = SYMBOL_TO_STRING(e_1);
arg1323_711 = STRING_LENGTH(arg1325_713);
}
_andtest_1003_707 = _2__206___r4_numbers_6_5(BINT(arg1323_711), BINT(((long)1)));
}
if(_andtest_1003_707){
unsigned char arg1319_708;
{
obj_t arg1321_709;
arg1321_709 = SYMBOL_TO_STRING(e_1);
arg1319_708 = STRING_REF(arg1321_709, ((long)0));
}
return (arg1319_708==((unsigned char)'?'));
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* segment-variable? */bool_t segment_variable__200___match_normalize(obj_t e_2)
{
if(SYMBOLP(e_2)){
bool_t _andtest_1005_715;
{
long arg1334_723;
{
obj_t arg1339_725;
arg1339_725 = SYMBOL_TO_STRING(e_2);
arg1334_723 = STRING_LENGTH(arg1339_725);
}
_andtest_1005_715 = _2__206___r4_numbers_6_5(BINT(arg1334_723), BINT(((long)2)));
}
if(_andtest_1005_715){
bool_t _andtest_1006_716;
{
unsigned char arg1331_720;
{
obj_t arg1332_721;
arg1332_721 = SYMBOL_TO_STRING(e_2);
arg1331_720 = STRING_REF(arg1332_721, ((long)0));
}
_andtest_1006_716 = (arg1331_720==((unsigned char)'?'));
}
if(_andtest_1006_716){
unsigned char arg1326_717;
{
obj_t arg1328_718;
arg1328_718 = SYMBOL_TO_STRING(e_2);
arg1326_717 = STRING_REF(arg1328_718, ((long)1));
}
return (arg1326_717==((unsigned char)'?'));
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* lispish-segment-variable? */bool_t lispish_segment_variable__20___match_normalize(obj_t e_3)
{
if(SYMBOLP(e_3)){
bool_t _andtest_1008_727;
{
long arg1352_739;
{
obj_t arg1355_741;
arg1355_741 = SYMBOL_TO_STRING(e_3);
arg1352_739 = STRING_LENGTH(arg1355_741);
}
_andtest_1008_727 = _2__206___r4_numbers_6_5(BINT(arg1352_739), BINT(((long)3)));
}
if(_andtest_1008_727){
bool_t _andtest_1009_728;
{
unsigned char arg1349_736;
{
obj_t arg1350_737;
arg1350_737 = SYMBOL_TO_STRING(e_3);
arg1349_736 = STRING_REF(arg1350_737, ((long)0));
}
_andtest_1009_728 = (arg1349_736==((unsigned char)'?'));
}
if(_andtest_1009_728){
bool_t _andtest_1010_729;
{
unsigned char arg1344_733;
{
obj_t arg1345_734;
arg1345_734 = SYMBOL_TO_STRING(e_3);
arg1344_733 = STRING_REF(arg1345_734, ((long)1));
}
_andtest_1010_729 = (arg1344_733==((unsigned char)'?'));
}
if(_andtest_1010_729){
unsigned char arg1340_730;
{
obj_t arg1342_731;
arg1342_731 = SYMBOL_TO_STRING(e_3);
arg1340_730 = STRING_REF(arg1342_731, ((long)2));
}
return (arg1340_730==((unsigned char)'?'));
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* tree-variable? */bool_t tree_variable__170___match_normalize(obj_t e_4)
{
if(SYMBOLP(e_4)){
bool_t _andtest_1012_743;
{
long arg1363_747;
{
obj_t arg1365_749;
arg1365_749 = SYMBOL_TO_STRING(e_4);
arg1363_747 = STRING_LENGTH(arg1365_749);
}
_andtest_1012_743 = _2__206___r4_numbers_6_5(BINT(arg1363_747), BINT(((long)1)));
}
if(_andtest_1012_743){
unsigned char arg1356_744;
{
obj_t arg1357_745;
arg1357_745 = SYMBOL_TO_STRING(e_4);
arg1356_744 = STRING_REF(arg1357_745, ((long)0));
}
return (arg1356_744==((unsigned char)'!'));
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* hole-variable? */bool_t hole_variable__247___match_normalize(obj_t e_5)
{
if(SYMBOLP(e_5)){
bool_t _andtest_1014_751;
{
long arg1370_755;
{
obj_t arg1373_757;
arg1373_757 = SYMBOL_TO_STRING(e_5);
arg1370_755 = STRING_LENGTH(arg1373_757);
}
_andtest_1014_751 = _2__206___r4_numbers_6_5(BINT(arg1370_755), BINT(((long)1)));
}
if(_andtest_1014_751){
unsigned char arg1367_752;
{
obj_t arg1368_753;
arg1368_753 = SYMBOL_TO_STRING(e_5);
arg1367_752 = STRING_REF(arg1368_753, ((long)0));
}
return (arg1367_752==((unsigned char)'^'));
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)0);
}
}


/* normalize-pattern */obj_t normalize_pattern_10___match_normalize(obj_t e_11)
{
{
obj_t fun1397_1837;
fun1397_1837 = standardize_pattern_107___match_normalize(e_11);
{
obj_t arg1396_2482;
arg1396_2482 = proc2099___match_normalize;
return PROCEDURE_ENTRY(fun1397_1837)(fun1397_1837, r_macro_pattern_117___match_normalize, arg1396_2482, BEOA);
}
}
}


/* _normalize-pattern */obj_t _normalize_pattern_154___match_normalize(obj_t env_2483, obj_t e_2484)
{
return normalize_pattern_10___match_normalize(e_2484);
}


/* arg1396_2059 */obj_t arg1396_2059___match_normalize(obj_t env_2485, obj_t pattern_2486, obj_t rr_2487)
{
{
obj_t pattern_2650;
pattern_2650 = pattern_2486;
return pattern_2650;
}
}


/* standardize-pattern */obj_t standardize_pattern_107___match_normalize(obj_t e_12)
{
{
bool_t test1399_784;
if(PAIRP(e_12)){
obj_t arg1812_1843;
arg1812_1843 = CAR(e_12);
{
obj_t r_1846;
r_1846 = r_macro_pattern_117___match_normalize;
{
bool_t test_3142;
{
obj_t aux_3143;
aux_3143 = assq___r4_pairs_and_lists_6_3(arg1812_1843, r_1846);
test_3142 = CBOOL(aux_3143);
}
if(test_3142){
obj_t aux_3146;
{
obj_t aux_3147;
aux_3147 = assq___r4_pairs_and_lists_6_3(arg1812_1843, r_1846);
aux_3146 = CDR(aux_3147);
}
test1399_784 = CBOOL(aux_3146);
}
 else {
test1399_784 = ((bool_t)0);
}
}
}
}
 else {
test1399_784 = ((bool_t)0);
}
if(test1399_784){
{
obj_t fun_2643;
{
obj_t arg1808_1852;
arg1808_1852 = CAR(e_12);
{
obj_t r_1854;
r_1854 = r_macro_pattern_117___match_normalize;
{
bool_t test_3153;
{
obj_t aux_3154;
aux_3154 = assq___r4_pairs_and_lists_6_3(arg1808_1852, r_1854);
test_3153 = CBOOL(aux_3154);
}
if(test_3153){
obj_t aux_3157;
aux_3157 = assq___r4_pairs_and_lists_6_3(arg1808_1852, r_1854);
fun_2643 = CDR(aux_3157);
}
 else {
bigloo_type_error_241___error(symbol2100___match_normalize, string2101___match_normalize, BFALSE);
exit( -1 );}
}
}
}
{
obj_t fun_3164;
{
obj_t arg1808_1852;
arg1808_1852 = CAR(e_12);
{
obj_t r_1854;
r_1854 = r_macro_pattern_117___match_normalize;
{
bool_t test_3166;
{
obj_t aux_3167;
aux_3167 = assq___r4_pairs_and_lists_6_3(arg1808_1852, r_1854);
test_3166 = CBOOL(aux_3167);
}
if(test_3166){
obj_t aux_3170;
aux_3170 = assq___r4_pairs_and_lists_6_3(arg1808_1852, r_1854);
fun_3164 = CDR(aux_3170);
}
 else {
bigloo_type_error_241___error(symbol2100___match_normalize, string2101___match_normalize, BFALSE);
exit( -1 );}
}
}
}
return apply(fun_3164, CDR(e_12));
}
}
}
 else {
if((e_12==symbol2089___match_normalize)){
return standardize_sexp_242___match_normalize();
}
 else {
bool_t test1401_786;
test1401_786 = term_variable__31___match_normalize(e_12);
if(test1401_786){
return standardize_term_variable_242___match_normalize(e_12);
}
 else {
bool_t test1402_787;
test1402_787 = hole_variable__247___match_normalize(e_12);
if(test1402_787){
return standardize_hole_variable_41___match_normalize(e_12);
}
 else {
if(VECTORP(e_12)){
return standardize_vector_187___match_normalize(e_12);
}
 else {
bool_t test1404_789;
{
obj_t aux_3187;
aux_3187 = atom__231___match_s2cfun(e_12);
test1404_789 = CBOOL(aux_3187);
}
if(test1404_789){
return standardize_quote_221___match_normalize(e_12);
}
 else {
return standardize_patterns_30___match_normalize(e_12);
}
}
}
}
}
}
}
}


/* standardize-patterns */obj_t standardize_patterns_30___match_normalize(obj_t e__176_13)
{
{
bool_t test1406_791;
test1406_791 = PAIRP(e__176_13);
if(test1406_791){
bool_t test1407_792;
if(test1406_791){
obj_t arg1812_1866;
arg1812_1866 = CAR(e__176_13);
{
obj_t r_1869;
r_1869 = r_macro_pattern_117___match_normalize;
{
bool_t test_3197;
{
obj_t aux_3198;
aux_3198 = assq___r4_pairs_and_lists_6_3(arg1812_1866, r_1869);
test_3197 = CBOOL(aux_3198);
}
if(test_3197){
obj_t aux_3201;
{
obj_t aux_3202;
aux_3202 = assq___r4_pairs_and_lists_6_3(arg1812_1866, r_1869);
aux_3201 = CDR(aux_3202);
}
test1407_792 = CBOOL(aux_3201);
}
 else {
test1407_792 = ((bool_t)0);
}
}
}
}
 else {
test1407_792 = ((bool_t)0);
}
if(test1407_792){
{
obj_t fun_2647;
{
obj_t arg1808_1875;
arg1808_1875 = CAR(e__176_13);
{
obj_t r_1877;
r_1877 = r_macro_pattern_117___match_normalize;
{
bool_t test_3208;
{
obj_t aux_3209;
aux_3209 = assq___r4_pairs_and_lists_6_3(arg1808_1875, r_1877);
test_3208 = CBOOL(aux_3209);
}
if(test_3208){
obj_t aux_3212;
aux_3212 = assq___r4_pairs_and_lists_6_3(arg1808_1875, r_1877);
fun_2647 = CDR(aux_3212);
}
 else {
bigloo_type_error_241___error(symbol2102___match_normalize, string2101___match_normalize, BFALSE);
exit( -1 );}
}
}
}
{
obj_t fun_3219;
{
obj_t arg1808_1875;
arg1808_1875 = CAR(e__176_13);
{
obj_t r_1877;
r_1877 = r_macro_pattern_117___match_normalize;
{
bool_t test_3221;
{
obj_t aux_3222;
aux_3222 = assq___r4_pairs_and_lists_6_3(arg1808_1875, r_1877);
test_3221 = CBOOL(aux_3222);
}
if(test_3221){
obj_t aux_3225;
aux_3225 = assq___r4_pairs_and_lists_6_3(arg1808_1875, r_1877);
fun_3219 = CDR(aux_3225);
}
 else {
bigloo_type_error_241___error(symbol2102___match_normalize, string2101___match_normalize, BFALSE);
exit( -1 );}
}
}
}
return apply(fun_3219, CDR(e__176_13));
}
}
}
 else {
bool_t test_3230;
{
obj_t aux_3231;
aux_3231 = CAR(e__176_13);
test_3230 = (aux_3231==symbol2103___match_normalize);
}
if(test_3230){
return standardize_any_179___match_normalize(CDR(e__176_13));
}
 else {
bool_t test_3236;
{
obj_t aux_3237;
aux_3237 = CAR(e__176_13);
test_3236 = (aux_3237==symbol2104___match_normalize);
}
if(test_3236){
return standardize_lispish_any_127___match_normalize(CDR(e__176_13));
}
 else {
bool_t test1414_797;
test1414_797 = lispish_segment_variable__20___match_normalize(CAR(e__176_13));
if(test1414_797){
return standardize_lispish_segment_variable_230___match_normalize(CAR(e__176_13), CDR(e__176_13));
}
 else {
bool_t test1417_800;
test1417_800 = segment_variable__200___match_normalize(CAR(e__176_13));
if(test1417_800){
return standardize_segment_variable_235___match_normalize(CAR(e__176_13), CDR(e__176_13));
}
 else {
bool_t test1420_803;
test1420_803 = tree_variable__170___match_normalize(CAR(e__176_13));
if(test1420_803){
{
obj_t aux_3262;
obj_t aux_3257;
{
obj_t aux_3263;
{
obj_t aux_3264;
aux_3264 = CDR(e__176_13);
aux_3263 = CDR(aux_3264);
}
aux_3262 = CAR(aux_3263);
}
{
obj_t aux_3259;
aux_3259 = CDR(e__176_13);
aux_3257 = CAR(aux_3259);
}
return standardize_tree_variable_65___match_normalize(CAR(e__176_13), aux_3257, aux_3262);
}
}
 else {
return standardize_cons_143___match_normalize(CAR(e__176_13), CDR(e__176_13));
}
}
}
}
}
}
}
 else {
return standardize_quote_221___match_normalize(e__176_13);
}
}
}


/* standardize-repetition */obj_t standardize_repetition_54___match_normalize(obj_t e_14, obj_t e__176_15)
{
{
obj_t lambda1441_2490;
lambda1441_2490 = make_fx_procedure(lambda1441___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1441_2490, ((long)0), e_14);
PROCEDURE_SET(lambda1441_2490, ((long)1), e__176_15);
return lambda1441_2490;
}
}


/* lambda1441 */obj_t lambda1441___match_normalize(obj_t env_2491, obj_t r_2494, obj_t c_2495)
{
{
obj_t e_2492;
obj_t e__176_2493;
e_2492 = PROCEDURE_REF(env_2491, ((long)0));
e__176_2493 = PROCEDURE_REF(env_2491, ((long)1));
{
obj_t r_816;
obj_t c_817;
r_816 = r_2494;
c_817 = c_2495;
{
obj_t fun1444_819;
fun1444_819 = standardize_pattern_107___match_normalize(e_2492);
{
obj_t arg1443_2489;
arg1443_2489 = make_fx_procedure(arg1443___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1443_2489, ((long)0), e__176_2493);
PROCEDURE_SET(arg1443_2489, ((long)1), c_817);
return PROCEDURE_ENTRY(fun1444_819)(fun1444_819, r_816, arg1443_2489, BEOA);
}
}
}
}
}


/* arg1443 */obj_t arg1443___match_normalize(obj_t env_2496, obj_t f_2499, obj_t rr_2500)
{
{
obj_t e__176_2497;
obj_t c_2498;
e__176_2497 = PROCEDURE_REF(env_2496, ((long)0));
c_2498 = PROCEDURE_REF(env_2496, ((long)1));
{
obj_t f_821;
obj_t rr_822;
f_821 = f_2499;
rr_822 = rr_2500;
{
obj_t fun1447_824;
fun1447_824 = standardize_patterns_30___match_normalize(e__176_2497);
{
obj_t arg1446_2488;
arg1446_2488 = make_fx_procedure(arg1446___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1446_2488, ((long)0), f_821);
PROCEDURE_SET(arg1446_2488, ((long)1), c_2498);
return PROCEDURE_ENTRY(fun1447_824)(fun1447_824, rr_822, arg1446_2488, BEOA);
}
}
}
}
}


/* arg1446 */obj_t arg1446___match_normalize(obj_t env_2501, obj_t f__199_2504, obj_t rrr_2505)
{
{
obj_t f_2502;
obj_t c_2503;
f_2502 = PROCEDURE_REF(env_2501, ((long)0));
c_2503 = PROCEDURE_REF(env_2501, ((long)1));
{
obj_t f__199_826;
obj_t rrr_827;
f__199_826 = f__199_2504;
rrr_827 = rrr_2505;
{
obj_t label_829;
label_829 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2105___match_normalize, BEOA);
{
obj_t arg1449_830;
{
obj_t arg1450_831;
obj_t arg1453_832;
arg1450_831 = symbol2106___match_normalize;
{
obj_t arg1463_839;
obj_t arg1464_840;
arg1463_839 = symbol2097___match_normalize;
{
obj_t arg1470_846;
obj_t arg1471_847;
arg1470_846 = symbol2107___match_normalize;
arg1471_847 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2108___match_normalize, BEOA);
{
obj_t list1474_849;
{
obj_t arg1475_850;
{
obj_t arg1476_851;
arg1476_851 = MAKE_PAIR(BNIL, BNIL);
arg1475_850 = MAKE_PAIR(arg1471_847, arg1476_851);
}
list1474_849 = MAKE_PAIR(label_829, arg1475_850);
}
arg1464_840 = cons__138___r4_pairs_and_lists_6_3(arg1470_846, list1474_849);
}
}
{
obj_t list1466_842;
{
obj_t arg1467_843;
{
obj_t arg1468_844;
arg1468_844 = MAKE_PAIR(BNIL, BNIL);
arg1467_843 = MAKE_PAIR(arg1464_840, arg1468_844);
}
list1466_842 = MAKE_PAIR(f_2502, arg1467_843);
}
arg1453_832 = cons__138___r4_pairs_and_lists_6_3(arg1463_839, list1466_842);
}
}
{
obj_t list1455_834;
{
obj_t arg1456_835;
{
obj_t arg1458_836;
{
obj_t arg1460_837;
arg1460_837 = MAKE_PAIR(BNIL, BNIL);
arg1458_836 = MAKE_PAIR(f__199_826, arg1460_837);
}
arg1456_835 = MAKE_PAIR(arg1453_832, arg1458_836);
}
list1455_834 = MAKE_PAIR(label_829, arg1456_835);
}
arg1449_830 = cons__138___r4_pairs_and_lists_6_3(arg1450_831, list1455_834);
}
}
return PROCEDURE_ENTRY(c_2503)(c_2503, arg1449_830, rrr_827, BEOA);
}
}
}
}
}


/* standardize-sexp */obj_t standardize_sexp_242___match_normalize()
{
{
obj_t lambda1478_2506;
lambda1478_2506 = proc2109___match_normalize;
return lambda1478_2506;
}
}


/* lambda1478 */obj_t lambda1478___match_normalize(obj_t env_2507, obj_t r_2508, obj_t c_2509)
{
{
obj_t r_855;
obj_t c_856;
r_855 = r_2508;
c_856 = c_2509;
{
obj_t arg1479_1911;
{
obj_t arg1480_1912;
arg1480_1912 = symbol2098___match_normalize;
{
obj_t list1482_1914;
list1482_1914 = MAKE_PAIR(BNIL, BNIL);
arg1479_1911 = cons__138___r4_pairs_and_lists_6_3(arg1480_1912, list1482_1914);
}
}
return PROCEDURE_ENTRY(c_856)(c_856, arg1479_1911, r_855, BEOA);
}
}
}


/* standardize-cons */obj_t standardize_cons_143___match_normalize(obj_t f_16, obj_t f__199_17)
{
{
bool_t test_3317;
if(PAIRP(f__199_17)){
obj_t aux_3320;
aux_3320 = CAR(f__199_17);
test_3317 = (aux_3320==symbol2110___match_normalize);
}
 else {
test_3317 = ((bool_t)0);
}
if(test_3317){
return standardize_repetition_54___match_normalize(f_16, CDR(f__199_17));
}
 else {
bool_t test1486_865;
{
obj_t aux_3325;
aux_3325 = PROCEDURE_ENTRY(_prefer_xcons__227___match_normalize)(_prefer_xcons__227___match_normalize, symbol2111___match_normalize, BEOA);
test1486_865 = CBOOL(aux_3325);
}
if(test1486_865){
return standardize_real_xcons_221___match_normalize(f_16, f__199_17);
}
 else {
return standardize_real_cons_8___match_normalize(f_16, f__199_17);
}
}
}
}


/* make-toggle */obj_t make_toggle_157___match_normalize()
{
{
obj_t value_870;
value_870 = MAKE_CELL(BFALSE);
{
obj_t lambda1491_2510;
lambda1491_2510 = make_fx_procedure(lambda1491___match_normalize, ((long)1), ((long)1));
PROCEDURE_SET(lambda1491_2510, ((long)0), value_870);
return lambda1491_2510;
}
}
}


/* lambda1491 */obj_t lambda1491___match_normalize(obj_t env_2511, obj_t msg_2513)
{
{
obj_t value_2512;
value_2512 = PROCEDURE_REF(env_2511, ((long)0));
{
obj_t msg_871;
msg_871 = msg_2513;
if((msg_871==symbol2111___match_normalize)){
return CELL_REF(value_2512);
}
 else {
if((msg_871==symbol2112___match_normalize)){
return CELL_SET(value_2512, BTRUE);
}
 else {
if((msg_871==symbol2113___match_normalize)){
return CELL_SET(value_2512, BFALSE);
}
 else {
return BFALSE;
}
}
}
}
}
}


/* standardize-real-cons */obj_t standardize_real_cons_8___match_normalize(obj_t f_18, obj_t f__199_19)
{
{
obj_t lambda1499_2518;
lambda1499_2518 = make_fx_procedure(lambda1499___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1499_2518, ((long)0), f_18);
PROCEDURE_SET(lambda1499_2518, ((long)1), f__199_19);
return lambda1499_2518;
}
}


/* lambda1499 */obj_t lambda1499___match_normalize(obj_t env_2519, obj_t r_2522, obj_t c_2523)
{
{
obj_t f_2520;
obj_t f__199_2521;
f_2520 = PROCEDURE_REF(env_2519, ((long)0));
f__199_2521 = PROCEDURE_REF(env_2519, ((long)1));
{
obj_t r_880;
obj_t c_881;
r_880 = r_2522;
c_881 = c_2523;
{
obj_t fun1501_883;
fun1501_883 = standardize_pattern_107___match_normalize(f_2520);
{
obj_t arg1500_2517;
arg1500_2517 = make_fx_procedure(arg1500___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1500_2517, ((long)0), f__199_2521);
PROCEDURE_SET(arg1500_2517, ((long)1), c_881);
return PROCEDURE_ENTRY(fun1501_883)(fun1501_883, r_880, arg1500_2517, BEOA);
}
}
}
}
}


/* arg1500 */obj_t arg1500___match_normalize(obj_t env_2524, obj_t pattern1_2527, obj_t rr_2528)
{
{
obj_t f__199_2525;
obj_t c_2526;
f__199_2525 = PROCEDURE_REF(env_2524, ((long)0));
c_2526 = PROCEDURE_REF(env_2524, ((long)1));
{
obj_t pattern1_885;
obj_t rr_886;
pattern1_885 = pattern1_2527;
rr_886 = rr_2528;
{
obj_t fun1506_888;
fun1506_888 = standardize_pattern_107___match_normalize(f__199_2525);
{
obj_t arg1503_2516;
arg1503_2516 = make_fx_procedure(arg1503___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1503_2516, ((long)0), pattern1_885);
PROCEDURE_SET(arg1503_2516, ((long)1), c_2526);
return PROCEDURE_ENTRY(fun1506_888)(fun1506_888, rr_886, arg1503_2516, BEOA);
}
}
}
}
}


/* arg1503 */obj_t arg1503___match_normalize(obj_t env_2529, obj_t pattern2_2532, obj_t rrr_2533)
{
{
obj_t pattern1_2530;
obj_t c_2531;
pattern1_2530 = PROCEDURE_REF(env_2529, ((long)0));
c_2531 = PROCEDURE_REF(env_2529, ((long)1));
{
obj_t pattern2_890;
obj_t rrr_891;
pattern2_890 = pattern2_2532;
rrr_891 = rrr_2533;
{
obj_t arg1510_1927;
{
obj_t arg1511_1928;
arg1511_1928 = symbol2097___match_normalize;
{
obj_t list1514_1930;
{
obj_t arg1515_1931;
{
obj_t arg1516_1932;
arg1516_1932 = MAKE_PAIR(BNIL, BNIL);
arg1515_1931 = MAKE_PAIR(pattern2_890, arg1516_1932);
}
list1514_1930 = MAKE_PAIR(pattern1_2530, arg1515_1931);
}
arg1510_1927 = cons__138___r4_pairs_and_lists_6_3(arg1511_1928, list1514_1930);
}
}
return PROCEDURE_ENTRY(c_2531)(c_2531, arg1510_1927, rrr_891, BEOA);
}
}
}
}


/* standardize-real-xcons */obj_t standardize_real_xcons_221___match_normalize(obj_t f_20, obj_t f__199_21)
{
{
obj_t lambda1518_2536;
lambda1518_2536 = make_fx_procedure(lambda1518___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1518_2536, ((long)0), f__199_21);
PROCEDURE_SET(lambda1518_2536, ((long)1), f_20);
return lambda1518_2536;
}
}


/* lambda1518 */obj_t lambda1518___match_normalize(obj_t env_2537, obj_t r_2540, obj_t c_2541)
{
{
obj_t f__199_2538;
obj_t f_2539;
f__199_2538 = PROCEDURE_REF(env_2537, ((long)0));
f_2539 = PROCEDURE_REF(env_2537, ((long)1));
{
obj_t r_902;
obj_t c_903;
r_902 = r_2540;
c_903 = c_2541;
{
obj_t fun1520_905;
fun1520_905 = standardize_patterns_30___match_normalize(f__199_2538);
{
obj_t arg1519_2535;
arg1519_2535 = make_fx_procedure(arg1519___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1519_2535, ((long)0), f_2539);
PROCEDURE_SET(arg1519_2535, ((long)1), c_903);
return PROCEDURE_ENTRY(fun1520_905)(fun1520_905, r_902, arg1519_2535, BEOA);
}
}
}
}
}


/* arg1519 */obj_t arg1519___match_normalize(obj_t env_2542, obj_t pattern1_2545, obj_t rr_2546)
{
{
obj_t f_2543;
obj_t c_2544;
f_2543 = PROCEDURE_REF(env_2542, ((long)0));
c_2544 = PROCEDURE_REF(env_2542, ((long)1));
{
obj_t pattern1_907;
obj_t rr_908;
pattern1_907 = pattern1_2545;
rr_908 = rr_2546;
{
obj_t fun1523_910;
fun1523_910 = standardize_pattern_107___match_normalize(f_2543);
{
obj_t arg1522_2534;
arg1522_2534 = make_fx_procedure(arg1522___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1522_2534, ((long)0), pattern1_907);
PROCEDURE_SET(arg1522_2534, ((long)1), c_2544);
return PROCEDURE_ENTRY(fun1523_910)(fun1523_910, rr_908, arg1522_2534, BEOA);
}
}
}
}
}


/* arg1522 */obj_t arg1522___match_normalize(obj_t env_2547, obj_t pattern2_2550, obj_t rrr_2551)
{
{
obj_t pattern1_2548;
obj_t c_2549;
pattern1_2548 = PROCEDURE_REF(env_2547, ((long)0));
c_2549 = PROCEDURE_REF(env_2547, ((long)1));
{
obj_t pattern2_912;
obj_t rrr_913;
pattern2_912 = pattern2_2550;
rrr_913 = rrr_2551;
{
obj_t arg1525_1934;
{
obj_t arg1526_1935;
arg1526_1935 = symbol2114___match_normalize;
{
obj_t list1528_1937;
{
obj_t arg1529_1938;
{
obj_t arg1530_1939;
arg1530_1939 = MAKE_PAIR(BNIL, BNIL);
arg1529_1938 = MAKE_PAIR(pattern1_2548, arg1530_1939);
}
list1528_1937 = MAKE_PAIR(pattern2_912, arg1529_1938);
}
arg1525_1934 = cons__138___r4_pairs_and_lists_6_3(arg1526_1935, list1528_1937);
}
}
return PROCEDURE_ENTRY(c_2549)(c_2549, arg1525_1934, rrr_913, BEOA);
}
}
}
}


/* standardize-term-variable */obj_t standardize_term_variable_242___match_normalize(obj_t e_22)
{
{
obj_t lambda1532_2552;
lambda1532_2552 = make_fx_procedure(lambda1532___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1532_2552, ((long)0), e_22);
return lambda1532_2552;
}
}


/* lambda1532 */obj_t lambda1532___match_normalize(obj_t env_2553, obj_t r_2555, obj_t c_2556)
{
{
obj_t e_2554;
e_2554 = PROCEDURE_REF(env_2553, ((long)0));
{
obj_t r_924;
obj_t c_925;
r_924 = r_2555;
c_925 = c_2556;
{
obj_t name_1941;
{
obj_t s_1949;
s_1949 = SYMBOL_TO_STRING(e_2554);
{
obj_t arg1375_1950;
{
long aux_3399;
aux_3399 = STRING_LENGTH(s_1949);
arg1375_1950 = c_substring(s_1949, ((long)1), aux_3399);
}
{
char * aux_3402;
aux_3402 = BSTRING_TO_STRING(arg1375_1950);
name_1941 = string_to_symbol(aux_3402);
}
}
}
{
obj_t arg1533_1942;
{
obj_t arg1534_1943;
arg1534_1943 = symbol2115___match_normalize;
{
obj_t list1536_1945;
{
obj_t arg1537_1946;
arg1537_1946 = MAKE_PAIR(BNIL, BNIL);
list1536_1945 = MAKE_PAIR(name_1941, arg1537_1946);
}
arg1533_1942 = cons__138___r4_pairs_and_lists_6_3(arg1534_1943, list1536_1945);
}
}
return PROCEDURE_ENTRY(c_925)(c_925, arg1533_1942, r_924, BEOA);
}
}
}
}
}


/* standardize-hole-variable */obj_t standardize_hole_variable_41___match_normalize(obj_t e_23)
{
{
obj_t lambda1540_2557;
lambda1540_2557 = make_fx_procedure(lambda1540___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1540_2557, ((long)0), e_23);
return lambda1540_2557;
}
}


/* lambda1540 */obj_t lambda1540___match_normalize(obj_t env_2558, obj_t r_2560, obj_t c_2561)
{
{
obj_t e_2559;
e_2559 = PROCEDURE_REF(env_2558, ((long)0));
{
obj_t r_934;
obj_t c_935;
r_934 = r_2560;
c_935 = c_2561;
{
obj_t name_937;
{
obj_t s_1960;
s_1960 = SYMBOL_TO_STRING(e_2559);
{
obj_t arg1389_1961;
{
long aux_3414;
aux_3414 = STRING_LENGTH(s_1960);
arg1389_1961 = c_substring(s_1960, ((long)1), aux_3414);
}
{
char * aux_3417;
aux_3417 = BSTRING_TO_STRING(arg1389_1961);
name_937 = string_to_symbol(aux_3417);
}
}
}
{
obj_t arg1542_938;
{
obj_t arg1545_939;
obj_t arg1548_940;
arg1545_939 = symbol2107___match_normalize;
arg1548_940 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2108___match_normalize, BEOA);
{
obj_t list1550_942;
{
obj_t arg1552_943;
{
obj_t arg1553_944;
arg1553_944 = MAKE_PAIR(BNIL, BNIL);
arg1552_943 = MAKE_PAIR(arg1548_940, arg1553_944);
}
list1550_942 = MAKE_PAIR(name_937, arg1552_943);
}
arg1542_938 = cons__138___r4_pairs_and_lists_6_3(arg1545_939, list1550_942);
}
}
return PROCEDURE_ENTRY(c_935)(c_935, arg1542_938, r_934, BEOA);
}
}
}
}
}


/* standardize-quote */obj_t standardize_quote_221___match_normalize(obj_t e_24)
{
{
obj_t lambda1555_2562;
lambda1555_2562 = make_fx_procedure(lambda1555___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1555_2562, ((long)0), e_24);
return lambda1555_2562;
}
}


/* lambda1555 */obj_t lambda1555___match_normalize(obj_t env_2563, obj_t r_2565, obj_t c_2566)
{
{
obj_t e_2564;
e_2564 = PROCEDURE_REF(env_2563, ((long)0));
{
obj_t r_946;
obj_t c_947;
r_946 = r_2565;
c_947 = c_2566;
{
obj_t arg1556_1970;
{
obj_t arg1557_1971;
arg1557_1971 = symbol2091___match_normalize;
{
obj_t list1559_1973;
{
obj_t arg1560_1974;
arg1560_1974 = MAKE_PAIR(BNIL, BNIL);
list1559_1973 = MAKE_PAIR(e_2564, arg1560_1974);
}
arg1556_1970 = cons__138___r4_pairs_and_lists_6_3(arg1557_1971, list1559_1973);
}
}
return PROCEDURE_ENTRY(c_947)(c_947, arg1556_1970, r_946, BEOA);
}
}
}
}


/* standardize-segment-variable */obj_t standardize_segment_variable_235___match_normalize(obj_t e_25, obj_t f__199_26)
{
{
obj_t lambda1562_2569;
lambda1562_2569 = make_fx_procedure(lambda1562___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1562_2569, ((long)0), e_25);
PROCEDURE_SET(lambda1562_2569, ((long)1), f__199_26);
return lambda1562_2569;
}
}


/* lambda1562 */obj_t lambda1562___match_normalize(obj_t env_2570, obj_t r_2573, obj_t c_2574)
{
{
obj_t e_2571;
obj_t f__199_2572;
e_2571 = PROCEDURE_REF(env_2570, ((long)0));
f__199_2572 = PROCEDURE_REF(env_2570, ((long)1));
{
obj_t r_955;
obj_t c_956;
r_955 = r_2573;
c_956 = c_2574;
{
obj_t name_958;
{
obj_t s_1977;
s_1977 = SYMBOL_TO_STRING(e_2571);
{
obj_t arg1381_1978;
{
long aux_3442;
aux_3442 = STRING_LENGTH(s_1977);
arg1381_1978 = c_substring(s_1977, ((long)2), aux_3442);
}
{
char * aux_3445;
aux_3445 = BSTRING_TO_STRING(arg1381_1978);
name_958 = string_to_symbol(aux_3445);
}
}
}
{
bool_t test_3448;
{
obj_t aux_3449;
{
bool_t test_3450;
{
obj_t aux_3451;
aux_3451 = assq___r4_pairs_and_lists_6_3(name_958, r_955);
test_3450 = CBOOL(aux_3451);
}
if(test_3450){
obj_t aux_3454;
aux_3454 = assq___r4_pairs_and_lists_6_3(name_958, r_955);
aux_3449 = CDR(aux_3454);
}
 else {
aux_3449 = BFALSE;
}
}
test_3448 = (aux_3449==unbound_pattern_153___match_normalize);
}
if(test_3448){
obj_t fun1567_960;
fun1567_960 = standardize_patterns_30___match_normalize(f__199_2572);
{
obj_t arg1564_961;
{
obj_t arg1809_1997;
arg1809_1997 = MAKE_PAIR(name_958, symbol2116___match_normalize);
arg1564_961 = MAKE_PAIR(arg1809_1997, r_955);
}
{
obj_t arg1565_2567;
arg1565_2567 = make_fx_procedure(arg1565___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1565_2567, ((long)0), name_958);
PROCEDURE_SET(arg1565_2567, ((long)1), c_956);
return PROCEDURE_ENTRY(fun1567_960)(fun1567_960, arg1564_961, arg1565_2567, BEOA);
}
}
}
 else {
obj_t fun1626_1011;
fun1626_1011 = standardize_patterns_30___match_normalize(f__199_2572);
{
obj_t arg1625_2568;
arg1625_2568 = make_fx_procedure(arg1625___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(arg1625_2568, ((long)0), name_958);
PROCEDURE_SET(arg1625_2568, ((long)1), c_956);
return PROCEDURE_ENTRY(fun1626_1011)(fun1626_1011, r_955, arg1625_2568, BEOA);
}
}
}
}
}
}
}


/* arg1565 */obj_t arg1565___match_normalize(obj_t env_2575, obj_t pattern_2578, obj_t rr_2579)
{
{
obj_t name_2576;
obj_t c_2577;
name_2576 = PROCEDURE_REF(env_2575, ((long)0));
c_2577 = PROCEDURE_REF(env_2575, ((long)1));
{
obj_t pattern_964;
obj_t rr_965;
pattern_964 = pattern_2578;
rr_965 = rr_2579;
{
obj_t label_967;
label_967 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2105___match_normalize, BEOA);
{
obj_t arg1570_968;
{
obj_t arg1572_969;
obj_t arg1573_970;
arg1572_969 = symbol2117___match_normalize;
{
obj_t arg1583_977;
obj_t arg1584_978;
obj_t arg1585_979;
arg1583_977 = symbol2118___match_normalize;
{
obj_t arg1594_986;
obj_t arg1595_987;
obj_t arg1598_988;
arg1594_986 = symbol2097___match_normalize;
{
obj_t arg1606_994;
arg1606_994 = symbol2098___match_normalize;
{
obj_t list1608_996;
list1608_996 = MAKE_PAIR(BNIL, BNIL);
arg1595_987 = cons__138___r4_pairs_and_lists_6_3(arg1606_994, list1608_996);
}
}
{
obj_t arg1610_998;
obj_t arg1612_999;
arg1610_998 = symbol2107___match_normalize;
arg1612_999 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2108___match_normalize, BEOA);
{
obj_t list1614_1001;
{
obj_t arg1615_1002;
{
obj_t arg1617_1003;
arg1617_1003 = MAKE_PAIR(BNIL, BNIL);
arg1615_1002 = MAKE_PAIR(arg1612_999, arg1617_1003);
}
list1614_1001 = MAKE_PAIR(label_967, arg1615_1002);
}
arg1598_988 = cons__138___r4_pairs_and_lists_6_3(arg1610_998, list1614_1001);
}
}
{
obj_t list1601_990;
{
obj_t arg1602_991;
{
obj_t arg1603_992;
arg1603_992 = MAKE_PAIR(BNIL, BNIL);
arg1602_991 = MAKE_PAIR(arg1598_988, arg1603_992);
}
list1601_990 = MAKE_PAIR(arg1595_987, arg1602_991);
}
arg1584_978 = cons__138___r4_pairs_and_lists_6_3(arg1594_986, list1601_990);
}
}
{
obj_t arg1620_1005;
arg1620_1005 = symbol2119___match_normalize;
{
obj_t list1622_1007;
{
obj_t arg1623_1008;
arg1623_1008 = MAKE_PAIR(BNIL, BNIL);
list1622_1007 = MAKE_PAIR(name_2576, arg1623_1008);
}
arg1585_979 = cons__138___r4_pairs_and_lists_6_3(arg1620_1005, list1622_1007);
}
}
{
obj_t list1587_981;
{
obj_t arg1588_982;
{
obj_t arg1589_983;
{
obj_t arg1592_984;
arg1592_984 = MAKE_PAIR(BNIL, BNIL);
arg1589_983 = MAKE_PAIR(arg1585_979, arg1592_984);
}
arg1588_982 = MAKE_PAIR(arg1584_978, arg1589_983);
}
list1587_981 = MAKE_PAIR(label_967, arg1588_982);
}
arg1573_970 = cons__138___r4_pairs_and_lists_6_3(arg1583_977, list1587_981);
}
}
{
obj_t list1576_972;
{
obj_t arg1578_973;
{
obj_t arg1580_974;
{
obj_t arg1581_975;
arg1581_975 = MAKE_PAIR(BNIL, BNIL);
arg1580_974 = MAKE_PAIR(pattern_964, arg1581_975);
}
arg1578_973 = MAKE_PAIR(arg1573_970, arg1580_974);
}
list1576_972 = MAKE_PAIR(name_2576, arg1578_973);
}
arg1570_968 = cons__138___r4_pairs_and_lists_6_3(arg1572_969, list1576_972);
}
}
return PROCEDURE_ENTRY(c_2577)(c_2577, arg1570_968, rr_965, BEOA);
}
}
}
}
}


/* arg1625 */obj_t arg1625___match_normalize(obj_t env_2580, obj_t pattern_2583, obj_t rr_2584)
{
{
obj_t name_2581;
obj_t c_2582;
name_2581 = PROCEDURE_REF(env_2580, ((long)0));
c_2582 = PROCEDURE_REF(env_2580, ((long)1));
{
obj_t pattern_1013;
obj_t rr_1014;
pattern_1013 = pattern_2583;
rr_1014 = rr_2584;
{
obj_t arg1628_2002;
{
obj_t arg1630_2003;
arg1630_2003 = symbol2120___match_normalize;
{
obj_t list1633_2005;
{
obj_t arg1634_2006;
{
obj_t arg1636_2007;
arg1636_2007 = MAKE_PAIR(BNIL, BNIL);
arg1634_2006 = MAKE_PAIR(pattern_1013, arg1636_2007);
}
list1633_2005 = MAKE_PAIR(name_2581, arg1634_2006);
}
arg1628_2002 = cons__138___r4_pairs_and_lists_6_3(arg1630_2003, list1633_2005);
}
}
return PROCEDURE_ENTRY(c_2582)(c_2582, arg1628_2002, rr_1014, BEOA);
}
}
}
}


/* standardize-tree-variable */obj_t standardize_tree_variable_65___match_normalize(obj_t e_27, obj_t f1_28, obj_t f2_29)
{
{
obj_t lambda1640_2587;
lambda1640_2587 = make_fx_procedure(lambda1640___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(lambda1640_2587, ((long)0), e_27);
PROCEDURE_SET(lambda1640_2587, ((long)1), f1_28);
PROCEDURE_SET(lambda1640_2587, ((long)2), f2_29);
return lambda1640_2587;
}
}


/* lambda1640 */obj_t lambda1640___match_normalize(obj_t env_2588, obj_t r_2592, obj_t c_2593)
{
{
obj_t e_2589;
obj_t f1_2590;
obj_t f2_2591;
e_2589 = PROCEDURE_REF(env_2588, ((long)0));
f1_2590 = PROCEDURE_REF(env_2588, ((long)1));
f2_2591 = PROCEDURE_REF(env_2588, ((long)2));
{
obj_t r_1025;
obj_t c_1026;
r_1025 = r_2592;
c_1026 = c_2593;
{
obj_t name_1028;
{
obj_t s_2010;
s_2010 = SYMBOL_TO_STRING(e_2589);
{
obj_t arg1385_2011;
{
long aux_3519;
aux_3519 = STRING_LENGTH(s_2010);
arg1385_2011 = c_substring(s_2010, ((long)1), aux_3519);
}
{
char * aux_3522;
aux_3522 = BSTRING_TO_STRING(arg1385_2011);
name_1028 = string_to_symbol(aux_3522);
}
}
}
{
obj_t fun1646_1029;
fun1646_1029 = standardize_pattern_107___match_normalize(f1_2590);
{
obj_t arg1641_1030;
{
obj_t arg1809_2023;
arg1809_2023 = MAKE_PAIR(name_1028, symbol2118___match_normalize);
arg1641_1030 = MAKE_PAIR(arg1809_2023, r_1025);
}
{
obj_t arg1645_2586;
arg1645_2586 = make_fx_procedure(arg1645___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(arg1645_2586, ((long)0), f2_2591);
PROCEDURE_SET(arg1645_2586, ((long)1), name_1028);
PROCEDURE_SET(arg1645_2586, ((long)2), c_1026);
return PROCEDURE_ENTRY(fun1646_1029)(fun1646_1029, arg1641_1030, arg1645_2586, BEOA);
}
}
}
}
}
}
}


/* arg1645 */obj_t arg1645___match_normalize(obj_t env_2594, obj_t hole_pattern_161_2598, obj_t rr_2599)
{
{
obj_t f2_2595;
obj_t name_2596;
obj_t c_2597;
f2_2595 = PROCEDURE_REF(env_2594, ((long)0));
name_2596 = PROCEDURE_REF(env_2594, ((long)1));
c_2597 = PROCEDURE_REF(env_2594, ((long)2));
{
obj_t hole_pattern_161_1033;
obj_t rr_1034;
hole_pattern_161_1033 = hole_pattern_161_2598;
rr_1034 = rr_2599;
{
obj_t fun1650_1036;
fun1650_1036 = standardize_pattern_107___match_normalize(f2_2595);
{
obj_t arg1649_2585;
arg1649_2585 = make_fx_procedure(arg1649___match_normalize, ((long)2), ((long)3));
PROCEDURE_SET(arg1649_2585, ((long)0), name_2596);
PROCEDURE_SET(arg1649_2585, ((long)1), hole_pattern_161_1033);
PROCEDURE_SET(arg1649_2585, ((long)2), c_2597);
return PROCEDURE_ENTRY(fun1650_1036)(fun1650_1036, rr_1034, arg1649_2585, BEOA);
}
}
}
}
}


/* arg1649 */obj_t arg1649___match_normalize(obj_t env_2600, obj_t patterns_2604, obj_t rrr_2605)
{
{
obj_t name_2601;
obj_t hole_pattern_161_2602;
obj_t c_2603;
name_2601 = PROCEDURE_REF(env_2600, ((long)0));
hole_pattern_161_2602 = PROCEDURE_REF(env_2600, ((long)1));
c_2603 = PROCEDURE_REF(env_2600, ((long)2));
{
obj_t patterns_1038;
obj_t rrr_1039;
patterns_1038 = patterns_2604;
rrr_1039 = rrr_2605;
{
bool_t test1652_1041;
{
obj_t arg1673_1058;
arg1673_1058 = oc_count_222___match_normalize(name_2601, patterns_1038);
test1652_1041 = _2__206___r4_numbers_6_5(arg1673_1058, BINT(((long)1)));
}
if(test1652_1041){
obj_t arg1653_1042;
{
obj_t arg1654_1043;
arg1654_1043 = symbol2118___match_normalize;
{
obj_t list1656_1045;
{
obj_t arg1657_1046;
{
obj_t arg1658_1047;
{
obj_t arg1659_1048;
arg1659_1048 = MAKE_PAIR(BNIL, BNIL);
arg1658_1047 = MAKE_PAIR(hole_pattern_161_2602, arg1659_1048);
}
arg1657_1046 = MAKE_PAIR(patterns_1038, arg1658_1047);
}
list1656_1045 = MAKE_PAIR(name_2601, arg1657_1046);
}
arg1653_1042 = cons__138___r4_pairs_and_lists_6_3(arg1654_1043, list1656_1045);
}
}
return PROCEDURE_ENTRY(c_2603)(c_2603, arg1653_1042, rrr_1039, BEOA);
}
 else {
obj_t arg1663_1050;
{
obj_t arg1665_1051;
arg1665_1051 = symbol2106___match_normalize;
{
obj_t list1667_1053;
{
obj_t arg1668_1054;
{
obj_t arg1669_1055;
{
obj_t arg1670_1056;
arg1670_1056 = MAKE_PAIR(BNIL, BNIL);
arg1669_1055 = MAKE_PAIR(hole_pattern_161_2602, arg1670_1056);
}
arg1668_1054 = MAKE_PAIR(patterns_1038, arg1669_1055);
}
list1667_1053 = MAKE_PAIR(name_2601, arg1668_1054);
}
arg1663_1050 = cons__138___r4_pairs_and_lists_6_3(arg1665_1051, list1667_1053);
}
}
return PROCEDURE_ENTRY(c_2603)(c_2603, arg1663_1050, rrr_1039, BEOA);
}
}
}
}
}


/* oc-count */obj_t oc_count_222___match_normalize(obj_t name_30, obj_t pattern_31)
{
if(NULLP(pattern_31)){
return BINT(((long)0));
}
 else {
bool_t test_3568;
{
obj_t aux_3569;
aux_3569 = CAR(pattern_31);
test_3568 = (aux_3569==symbol2107___match_normalize);
}
if(test_3568){
{
bool_t test_3572;
{
obj_t aux_3573;
{
obj_t aux_3574;
aux_3574 = CDR(pattern_31);
aux_3573 = CAR(aux_3574);
}
test_3572 = (aux_3573==name_30);
}
if(test_3572){
return BINT(((long)1));
}
 else {
return BINT(((long)0));
}
}
}
 else {
bool_t test_3580;
{
obj_t aux_3581;
aux_3581 = memq___r4_pairs_and_lists_6_3(CAR(pattern_31), list2121___match_normalize);
test_3580 = CBOOL(aux_3581);
}
if(test_3580){
{
obj_t runner1689_1081;
{
obj_t l1015_1067;
l1015_1067 = CDR(pattern_31);
if(NULLP(l1015_1067)){
runner1689_1081 = BNIL;
}
 else {
obj_t head1017_1069;
head1017_1069 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1015_2044;
obj_t tail1018_2045;
l1015_2044 = l1015_1067;
tail1018_2045 = head1017_1069;
lname1016_2043:
if(NULLP(l1015_2044)){
runner1689_1081 = CDR(head1017_1069);
}
 else {
obj_t newtail1019_2053;
{
obj_t arg1684_2054;
arg1684_2054 = oc_count_222___match_normalize(name_30, CAR(l1015_2044));
newtail1019_2053 = MAKE_PAIR(arg1684_2054, BNIL);
}
SET_CDR(tail1018_2045, newtail1019_2053);
{
obj_t tail1018_3598;
obj_t l1015_3596;
l1015_3596 = CDR(l1015_2044);
tail1018_3598 = newtail1019_2053;
tail1018_2045 = tail1018_3598;
l1015_2044 = l1015_3596;
goto lname1016_2043;
}
}
}
}
}
return __2___r4_numbers_6_5(runner1689_1081);
}
}
 else {
return BINT(((long)0));
}
}
}
}


/* standardize-lispish-segment-variable */obj_t standardize_lispish_segment_variable_230___match_normalize(obj_t e_32, obj_t f__199_33)
{
if(NULLP(f__199_33)){
obj_t lambda1696_2606;
lambda1696_2606 = make_fx_procedure(lambda1696___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1696_2606, ((long)0), e_32);
return lambda1696_2606;
}
 else {
return standardize_segment_variable_235___match_normalize(e_32, f__199_33);
}
}


/* lambda1696 */obj_t lambda1696___match_normalize(obj_t env_2607, obj_t r_2609, obj_t c_2610)
{
{
obj_t e_2608;
e_2608 = PROCEDURE_REF(env_2607, ((long)0));
{
obj_t r_1087;
obj_t c_1088;
r_1087 = r_2609;
c_1088 = c_2610;
{
obj_t name_1090;
{
obj_t s_2098;
s_2098 = SYMBOL_TO_STRING(e_2608);
{
obj_t arg1392_2099;
{
long aux_3608;
aux_3608 = STRING_LENGTH(s_2098);
arg1392_2099 = c_substring(s_2098, ((long)3), aux_3608);
}
{
char * aux_3611;
aux_3611 = BSTRING_TO_STRING(arg1392_2099);
name_1090 = string_to_symbol(aux_3611);
}
}
}
{
bool_t test_3614;
{
obj_t aux_3615;
{
bool_t test_3616;
{
obj_t aux_3617;
aux_3617 = assq___r4_pairs_and_lists_6_3(name_1090, r_1087);
test_3616 = CBOOL(aux_3617);
}
if(test_3616){
obj_t aux_3620;
aux_3620 = assq___r4_pairs_and_lists_6_3(name_1090, r_1087);
aux_3615 = CDR(aux_3620);
}
 else {
aux_3615 = BFALSE;
}
}
test_3614 = (aux_3615==unbound_pattern_153___match_normalize);
}
if(test_3614){
obj_t arg1698_1092;
obj_t arg1699_1093;
{
obj_t arg1700_1094;
obj_t arg1701_1095;
arg1700_1094 = symbol2115___match_normalize;
{
obj_t arg1707_1101;
arg1707_1101 = symbol2098___match_normalize;
{
obj_t list1709_1103;
list1709_1103 = MAKE_PAIR(BNIL, BNIL);
arg1701_1095 = cons__138___r4_pairs_and_lists_6_3(arg1707_1101, list1709_1103);
}
}
{
obj_t list1703_1097;
{
obj_t arg1704_1098;
{
obj_t arg1705_1099;
arg1705_1099 = MAKE_PAIR(BNIL, BNIL);
arg1704_1098 = MAKE_PAIR(arg1701_1095, arg1705_1099);
}
list1703_1097 = MAKE_PAIR(name_1090, arg1704_1098);
}
arg1698_1092 = cons__138___r4_pairs_and_lists_6_3(arg1700_1094, list1703_1097);
}
}
{
obj_t arg1809_2118;
arg1809_2118 = MAKE_PAIR(name_1090, symbol2116___match_normalize);
arg1699_1093 = MAKE_PAIR(arg1809_2118, r_1087);
}
return PROCEDURE_ENTRY(c_1088)(c_1088, arg1698_1092, arg1699_1093, BEOA);
}
 else {
obj_t arg1712_1106;
{
obj_t arg1713_1107;
arg1713_1107 = symbol2115___match_normalize;
{
obj_t list1715_1109;
{
obj_t arg1716_1110;
arg1716_1110 = MAKE_PAIR(BNIL, BNIL);
list1715_1109 = MAKE_PAIR(name_1090, arg1716_1110);
}
arg1712_1106 = cons__138___r4_pairs_and_lists_6_3(arg1713_1107, list1715_1109);
}
}
return PROCEDURE_ENTRY(c_1088)(c_1088, arg1712_1106, r_1087, BEOA);
}
}
}
}
}
}


/* standardize-any */obj_t standardize_any_179___match_normalize(obj_t f__199_34)
{
{
obj_t lambda1719_2612;
lambda1719_2612 = make_fx_procedure(lambda1719___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(lambda1719_2612, ((long)0), f__199_34);
return lambda1719_2612;
}
}


/* lambda1719 */obj_t lambda1719___match_normalize(obj_t env_2613, obj_t r_2615, obj_t c_2616)
{
{
obj_t f__199_2614;
f__199_2614 = PROCEDURE_REF(env_2613, ((long)0));
{
obj_t r_1113;
obj_t c_1114;
r_1113 = r_2615;
c_1114 = c_2616;
{
obj_t fun1722_1116;
fun1722_1116 = standardize_patterns_30___match_normalize(f__199_2614);
{
obj_t arg1720_2611;
arg1720_2611 = make_fx_procedure(arg1720___match_normalize, ((long)2), ((long)1));
PROCEDURE_SET(arg1720_2611, ((long)0), c_1114);
return PROCEDURE_ENTRY(fun1722_1116)(fun1722_1116, r_1113, arg1720_2611, BEOA);
}
}
}
}
}


/* arg1720 */obj_t arg1720___match_normalize(obj_t env_2617, obj_t pattern_2619, obj_t rr_2620)
{
{
obj_t c_2618;
c_2618 = PROCEDURE_REF(env_2617, ((long)0));
{
obj_t pattern_1118;
obj_t rr_1119;
pattern_1118 = pattern_2619;
rr_1119 = rr_2620;
{
obj_t label_1121;
label_1121 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2105___match_normalize, BEOA);
{
bool_t test1724_1122;
{
obj_t aux_3650;
aux_3650 = PROCEDURE_ENTRY(_prefer_xcons__227___match_normalize)(_prefer_xcons__227___match_normalize, symbol2111___match_normalize, BEOA);
test1724_1122 = CBOOL(aux_3650);
}
if(test1724_1122){
obj_t arg1725_1123;
{
obj_t arg1726_1124;
obj_t arg1727_1125;
arg1726_1124 = symbol2106___match_normalize;
{
obj_t arg1738_1132;
obj_t arg1739_1133;
obj_t arg1740_1134;
arg1738_1132 = symbol2114___match_normalize;
{
obj_t arg1748_1140;
arg1748_1140 = symbol2098___match_normalize;
{
obj_t list1750_1142;
list1750_1142 = MAKE_PAIR(BNIL, BNIL);
arg1739_1133 = cons__138___r4_pairs_and_lists_6_3(arg1748_1140, list1750_1142);
}
}
{
obj_t arg1755_1144;
obj_t arg1758_1145;
arg1755_1144 = symbol2107___match_normalize;
arg1758_1145 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2108___match_normalize, BEOA);
{
obj_t list1760_1147;
{
obj_t arg1761_1148;
{
obj_t arg1762_1149;
arg1762_1149 = MAKE_PAIR(BNIL, BNIL);
arg1761_1148 = MAKE_PAIR(arg1758_1145, arg1762_1149);
}
list1760_1147 = MAKE_PAIR(label_1121, arg1761_1148);
}
arg1740_1134 = cons__138___r4_pairs_and_lists_6_3(arg1755_1144, list1760_1147);
}
}
{
obj_t list1744_1136;
{
obj_t arg1745_1137;
{
obj_t arg1746_1138;
arg1746_1138 = MAKE_PAIR(BNIL, BNIL);
arg1745_1137 = MAKE_PAIR(arg1740_1134, arg1746_1138);
}
list1744_1136 = MAKE_PAIR(arg1739_1133, arg1745_1137);
}
arg1727_1125 = cons__138___r4_pairs_and_lists_6_3(arg1738_1132, list1744_1136);
}
}
{
obj_t list1729_1127;
{
obj_t arg1730_1128;
{
obj_t arg1731_1129;
{
obj_t arg1732_1130;
arg1732_1130 = MAKE_PAIR(BNIL, BNIL);
arg1731_1129 = MAKE_PAIR(pattern_1118, arg1732_1130);
}
arg1730_1128 = MAKE_PAIR(arg1727_1125, arg1731_1129);
}
list1729_1127 = MAKE_PAIR(label_1121, arg1730_1128);
}
arg1725_1123 = cons__138___r4_pairs_and_lists_6_3(arg1726_1124, list1729_1127);
}
}
return PROCEDURE_ENTRY(c_2618)(c_2618, arg1725_1123, rr_1119, BEOA);
}
 else {
obj_t arg1766_1151;
{
obj_t arg1767_1152;
obj_t arg1768_1153;
arg1767_1152 = symbol2106___match_normalize;
{
obj_t arg1776_1160;
obj_t arg1777_1161;
obj_t arg1778_1162;
arg1776_1160 = symbol2097___match_normalize;
{
obj_t arg1788_1168;
arg1788_1168 = symbol2098___match_normalize;
{
obj_t list1790_1170;
list1790_1170 = MAKE_PAIR(BNIL, BNIL);
arg1777_1161 = cons__138___r4_pairs_and_lists_6_3(arg1788_1168, list1790_1170);
}
}
{
obj_t arg1792_1172;
obj_t arg1793_1173;
arg1792_1172 = symbol2107___match_normalize;
arg1793_1173 = PROCEDURE_ENTRY(jim_gensym_58___match_s2cfun)(jim_gensym_58___match_s2cfun, string2108___match_normalize, BEOA);
{
obj_t list1795_1175;
{
obj_t arg1796_1176;
{
obj_t arg1797_1177;
arg1797_1177 = MAKE_PAIR(BNIL, BNIL);
arg1796_1176 = MAKE_PAIR(arg1793_1173, arg1797_1177);
}
list1795_1175 = MAKE_PAIR(label_1121, arg1796_1176);
}
arg1778_1162 = cons__138___r4_pairs_and_lists_6_3(arg1792_1172, list1795_1175);
}
}
{
obj_t list1780_1164;
{
obj_t arg1781_1165;
{
obj_t arg1783_1166;
arg1783_1166 = MAKE_PAIR(BNIL, BNIL);
arg1781_1165 = MAKE_PAIR(arg1778_1162, arg1783_1166);
}
list1780_1164 = MAKE_PAIR(arg1777_1161, arg1781_1165);
}
arg1768_1153 = cons__138___r4_pairs_and_lists_6_3(arg1776_1160, list1780_1164);
}
}
{
obj_t list1770_1155;
{
obj_t arg1771_1156;
{
obj_t arg1772_1157;
{
obj_t arg1773_1158;
arg1773_1158 = MAKE_PAIR(BNIL, BNIL);
arg1772_1157 = MAKE_PAIR(pattern_1118, arg1773_1158);
}
arg1771_1156 = MAKE_PAIR(arg1768_1153, arg1772_1157);
}
list1770_1155 = MAKE_PAIR(label_1121, arg1771_1156);
}
arg1766_1151 = cons__138___r4_pairs_and_lists_6_3(arg1767_1152, list1770_1155);
}
}
return PROCEDURE_ENTRY(c_2618)(c_2618, arg1766_1151, rr_1119, BEOA);
}
}
}
}
}
}


/* standardize-lispish-any */obj_t standardize_lispish_any_127___match_normalize(obj_t f__199_35)
{
if(NULLP(f__199_35)){
obj_t lambda1802_2621;
lambda1802_2621 = proc2123___match_normalize;
return lambda1802_2621;
}
 else {
return standardize_any_179___match_normalize(f__199_35);
}
}


/* lambda1802 */obj_t lambda1802___match_normalize(obj_t env_2622, obj_t r_2623, obj_t c_2624)
{
{
obj_t r_1182;
obj_t c_1183;
r_1182 = r_2623;
c_1183 = c_2624;
{
obj_t arg1803_2124;
{
obj_t arg1804_2125;
arg1804_2125 = symbol2098___match_normalize;
{
obj_t list1806_2127;
list1806_2127 = MAKE_PAIR(BNIL, BNIL);
arg1803_2124 = cons__138___r4_pairs_and_lists_6_3(arg1804_2125, list1806_2127);
}
}
return PROCEDURE_ENTRY(c_1183)(c_1183, arg1803_2124, r_1182, BEOA);
}
}
}


/* extend.r.macro-env */obj_t extend_r_macro_env_37___match_normalize(obj_t name_42, obj_t fun_43)
{
{
obj_t fn_2145;
fn_2145 = r_macro_pattern_117___match_normalize;
{
obj_t arg1809_2148;
arg1809_2148 = MAKE_PAIR(name_42, fun_43);
return (r_macro_pattern_117___match_normalize = MAKE_PAIR(arg1809_2148, fn_2145),
BUNSPEC);
}
}
}


/* _extend.r.macro-env */obj_t _extend_r_macro_env_245___match_normalize(obj_t env_2625, obj_t name_2626, obj_t fun_2627)
{
return extend_r_macro_env_37___match_normalize(name_2626, fun_2627);
}


/* coherent-environment? */bool_t coherent_environment__29___match_normalize(obj_t r_45, obj_t rr_46)
{
coherent_environment__29___match_normalize:
if(PAIRP(r_45)){
bool_t _andtest_1024_1200;
{
obj_t arg1815_1202;
{
obj_t aux_3705;
aux_3705 = CAR(r_45);
arg1815_1202 = CAR(aux_3705);
}
{
obj_t r_2168;
r_2168 = rr_46;
look_2167:
if(PAIRP(r_2168)){
bool_t _ortest_1023_2170;
{
obj_t aux_3710;
{
obj_t aux_3711;
aux_3711 = CAR(r_2168);
aux_3710 = CAR(aux_3711);
}
_ortest_1023_2170 = (aux_3710==arg1815_1202);
}
if(_ortest_1023_2170){
_andtest_1024_1200 = _ortest_1023_2170;
}
 else {
obj_t r_3716;
r_3716 = CDR(r_2168);
r_2168 = r_3716;
goto look_2167;
}
}
 else {
_andtest_1024_1200 = ((bool_t)0);
}
}
}
if(_andtest_1024_1200){
obj_t r_3719;
r_3719 = CDR(r_45);
r_45 = r_3719;
goto coherent_environment__29___match_normalize;
}
 else {
return ((bool_t)0);
}
}
 else {
return ((bool_t)1);
}
}


/* standardize-vector */obj_t standardize_vector_187___match_normalize(obj_t e_50)
{
{
obj_t tmp_1209;
{
obj_t arg1886_1268;
arg1886_1268 = vector__list_155___r4_vectors_6_8(e_50);
{
obj_t fun1397_2214;
fun1397_2214 = standardize_pattern_107___match_normalize(arg1886_1268);
{
obj_t arg1396_2629;
arg1396_2629 = proc2124___match_normalize;
tmp_1209 = PROCEDURE_ENTRY(fun1397_2214)(fun1397_2214, r_macro_pattern_117___match_normalize, arg1396_2629, BEOA);
}
}
}
{
obj_t lambda1821_2628;
lambda1821_2628 = make_fx_procedure(lambda1821___match_normalize, ((long)2), ((long)2));
PROCEDURE_SET(lambda1821_2628, ((long)0), e_50);
PROCEDURE_SET(lambda1821_2628, ((long)1), tmp_1209);
return lambda1821_2628;
}
}
}


/* lambda1821 */obj_t lambda1821___match_normalize(obj_t env_2630, obj_t r_2633, obj_t c_2634)
{
{
obj_t e_2631;
obj_t tmp_2632;
e_2631 = PROCEDURE_REF(env_2630, ((long)0));
tmp_2632 = PROCEDURE_REF(env_2630, ((long)1));
{
obj_t r_1212;
obj_t c_1213;
r_1212 = r_2633;
c_1213 = c_2634;
{
obj_t arg1822_1215;
{
obj_t arg1823_1216;
obj_t arg1824_1217;
obj_t arg1826_1218;
arg1823_1216 = symbol2125___match_normalize;
{
obj_t arg1832_1224;
arg1832_1224 = vector__list_155___r4_vectors_6_8(e_2631);
arg1824_1217 = pattern_length_193___match_normalize(arg1832_1224);
}
arg1826_1218 = vectorify___match_normalize(tmp_2632);
{
obj_t list1828_1220;
{
obj_t arg1829_1221;
{
obj_t arg1830_1222;
arg1830_1222 = MAKE_PAIR(BNIL, BNIL);
arg1829_1221 = MAKE_PAIR(arg1826_1218, arg1830_1222);
}
list1828_1220 = MAKE_PAIR(arg1824_1217, arg1829_1221);
}
arg1822_1215 = cons__138___r4_pairs_and_lists_6_3(arg1823_1216, list1828_1220);
}
}
return PROCEDURE_ENTRY(c_1213)(c_1213, arg1822_1215, r_1212, BEOA);
}
}
}
}


/* vectorify */obj_t vectorify___match_normalize(obj_t p_1210)
{
{
bool_t test_3739;
{
obj_t aux_3740;
aux_3740 = CAR(p_1210);
test_3739 = (aux_3740==symbol2097___match_normalize);
}
if(test_3739){
{
obj_t arg1834_1226;
obj_t arg1835_1227;
obj_t arg1836_1228;
arg1834_1226 = symbol2126___match_normalize;
{
obj_t aux_3743;
aux_3743 = CDR(p_1210);
arg1835_1227 = CAR(aux_3743);
}
{
bool_t test_3746;
{
obj_t aux_3747;
{
obj_t aux_3748;
{
obj_t aux_3749;
aux_3749 = CDR(p_1210);
aux_3748 = CDR(aux_3749);
}
aux_3747 = CAR(aux_3748);
}
test_3746 = equal__25___r4_equivalence_6_2(aux_3747, list2127___match_normalize);
}
if(test_3746){
arg1836_1228 = list2128___match_normalize;
}
 else {
obj_t aux_3754;
{
obj_t aux_3755;
{
obj_t aux_3756;
aux_3756 = CDR(p_1210);
aux_3755 = CDR(aux_3756);
}
aux_3754 = CAR(aux_3755);
}
arg1836_1228 = vectorify___match_normalize(aux_3754);
}
}
{
obj_t list1838_1230;
{
obj_t arg1839_1231;
{
obj_t arg1842_1232;
arg1842_1232 = MAKE_PAIR(BNIL, BNIL);
arg1839_1231 = MAKE_PAIR(arg1836_1228, arg1842_1232);
}
list1838_1230 = MAKE_PAIR(arg1835_1227, arg1839_1231);
}
return cons__138___r4_pairs_and_lists_6_3(arg1834_1226, list1838_1230);
}
}
}
 else {
if(equal__25___r4_equivalence_6_2(p_1210, list2130___match_normalize)){
return list2131___match_normalize;
}
 else {
bool_t test_3767;
{
obj_t aux_3768;
aux_3768 = memq___r4_pairs_and_lists_6_3(CAR(p_1210), list2133___match_normalize);
test_3767 = CBOOL(aux_3768);
}
if(test_3767){
{
obj_t arg1853_1240;
obj_t arg1856_1241;
obj_t arg1857_1242;
arg1853_1240 = CAR(p_1210);
{
obj_t aux_3773;
{
obj_t aux_3774;
aux_3774 = CDR(p_1210);
aux_3773 = CAR(aux_3774);
}
arg1856_1241 = vectorify___match_normalize(aux_3773);
}
{
obj_t aux_3778;
{
obj_t aux_3779;
{
obj_t aux_3780;
aux_3780 = CDR(p_1210);
aux_3779 = CDR(aux_3780);
}
aux_3778 = CAR(aux_3779);
}
arg1857_1242 = vectorify___match_normalize(aux_3778);
}
{
obj_t list1858_1243;
{
obj_t arg1859_1244;
{
obj_t arg1860_1245;
arg1860_1245 = MAKE_PAIR(arg1857_1242, BNIL);
arg1859_1244 = MAKE_PAIR(arg1856_1241, arg1860_1245);
}
list1858_1243 = MAKE_PAIR(arg1853_1240, arg1859_1244);
}
return list1858_1243;
}
}
}
 else {
bool_t test_3788;
{
obj_t aux_3789;
aux_3789 = memq___r4_pairs_and_lists_6_3(CAR(p_1210), list2134___match_normalize);
test_3788 = CBOOL(aux_3789);
}
if(test_3788){
{
obj_t arg1865_1250;
obj_t arg1866_1251;
obj_t arg1867_1252;
obj_t arg1868_1253;
arg1865_1250 = symbol2135___match_normalize;
{
obj_t aux_3793;
aux_3793 = CDR(p_1210);
arg1866_1251 = CAR(aux_3793);
}
{
obj_t aux_3796;
{
obj_t aux_3797;
{
obj_t aux_3798;
aux_3798 = CDR(p_1210);
aux_3797 = CDR(aux_3798);
}
aux_3796 = CAR(aux_3797);
}
arg1867_1252 = vectorify___match_normalize(aux_3796);
}
{
obj_t aux_3803;
{
obj_t aux_3804;
{
obj_t aux_3805;
{
obj_t aux_3806;
aux_3806 = CDR(p_1210);
aux_3805 = CDR(aux_3806);
}
aux_3804 = CDR(aux_3805);
}
aux_3803 = CAR(aux_3804);
}
arg1868_1253 = vectorify___match_normalize(aux_3803);
}
{
obj_t list1869_1254;
{
obj_t arg1870_1255;
{
obj_t arg1871_1256;
{
obj_t arg1874_1257;
arg1874_1257 = MAKE_PAIR(arg1868_1253, BNIL);
arg1871_1256 = MAKE_PAIR(arg1867_1252, arg1874_1257);
}
arg1870_1255 = MAKE_PAIR(arg1866_1251, arg1871_1256);
}
list1869_1254 = MAKE_PAIR(arg1865_1250, arg1870_1255);
}
return list1869_1254;
}
}
}
 else {
return p_1210;
}
}
}
}
}
}


/* arg1396_2060 */obj_t arg1396_2060___match_normalize(obj_t env_2635, obj_t pattern_2636, obj_t rr_2637)
{
{
obj_t pattern_2652;
pattern_2652 = pattern_2636;
return pattern_2652;
}
}


/* pattern-length */obj_t pattern_length_193___match_normalize(obj_t p_51)
{
pattern_length_193___match_normalize:
{
bool_t test1887_1269;
{
obj_t aux_3816;
aux_3816 = atom__231___match_s2cfun(p_51);
test1887_1269 = CBOOL(aux_3816);
}
if(test1887_1269){
return BINT(((long)0));
}
 else {
if(NULLP(p_51)){
return BINT(((long)0));
}
 else {
bool_t test_3824;
{
obj_t aux_3825;
aux_3825 = CAR(p_51);
test_3824 = (aux_3825==symbol2076___match_normalize);
}
if(test_3824){
return BINT(((long)1));
}
 else {
bool_t test1890_1272;
test1890_1272 = tree_variable__170___match_normalize(CAR(p_51));
if(test1890_1272){
return BINT(((long)0));
}
 else {
bool_t test_3833;
{
obj_t aux_3834;
aux_3834 = memq___r4_pairs_and_lists_6_3(CAR(p_51), list2136___match_normalize);
test_3833 = CBOOL(aux_3834);
}
if(test_3833){
return BINT(((long)0));
}
 else {
bool_t test_3839;
{
obj_t aux_3840;
aux_3840 = memq___r4_pairs_and_lists_6_3(CAR(p_51), list2137___match_normalize);
test_3839 = CBOOL(aux_3840);
}
if(test_3839){
{
obj_t p_3844;
{
obj_t aux_3845;
aux_3845 = CDR(p_51);
p_3844 = CAR(aux_3845);
}
p_51 = p_3844;
goto pattern_length_193___match_normalize;
}
}
 else {
{
obj_t arg1895_1277;
arg1895_1277 = pattern_length_193___match_normalize(CDR(p_51));
return _2__168___r4_numbers_6_5(BINT(((long)1)), arg1895_1277);
}
}
}
}
}
}
}
}
}


/* match-define-structure! */obj_t match_define_structure__81___match_normalize(obj_t exp_52)
{
if(PAIRP(exp_52)){
obj_t cdr_109_69_1292;
cdr_109_69_1292 = CDR(exp_52);
{
bool_t test_3855;
{
obj_t aux_3856;
aux_3856 = CAR(exp_52);
test_3855 = (aux_3856==symbol2138___match_normalize);
}
if(test_3855){
if(PAIRP(cdr_109_69_1292)){
obj_t obj2_2295;
obj2_2295 = _match_structures__166___match_normalize;
return (_match_structures__166___match_normalize = MAKE_PAIR(cdr_109_69_1292, obj2_2295),
BUNSPEC);
}
 else {
FAILURE(string2139___match_normalize,exp_52,symbol2140___match_normalize);}
}
 else {
FAILURE(string2139___match_normalize,exp_52,symbol2140___match_normalize);}
}
}
 else {
FAILURE(string2139___match_normalize,exp_52,symbol2140___match_normalize);}
}


/* _match-define-structure! */obj_t _match_define_structure__210___match_normalize(obj_t env_2638, obj_t exp_2639)
{
return match_define_structure__81___match_normalize(exp_2639);
}


/* imported-modules-init */obj_t imported_modules_init_94___match_normalize()
{
module_initialization_70___error(((long)0), "__MATCH_NORMALIZE");
return module_initialization_70___match_s2cfun(((long)0), "__MATCH_NORMALIZE");
}

