/*===========================================================================*/
/*   (Ast/app.scm)                                                           */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


extern char *number__string_214___r4_numbers_6_5(obj_t, obj_t);
static obj_t method_init_76_ast_app();
extern obj_t funcall_ast_node;
static node_t wrong_number_of_arguments_4_ast_app(obj_t, obj_t, node_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern node_t application__node_43_ast_app(obj_t, obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static long check_user_app_174_ast_app(node_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static node_t clean_user_node__130_ast_app(node_t);
extern obj_t module_initialization_70_ast_app(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t make_fx_app_node_213_ast_app(obj_t, var_t, obj_t);
extern long list_length(obj_t);
extern long class_num_218___object(obj_t);
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_ast_app();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern bool_t correct_arity_app__187_ast_app(variable_t, obj_t);
extern obj_t cfun_ast_var;
static obj_t _application__node1791_8_ast_app(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_app();
static node_t make_va_app_node_0_ast_app(long, obj_t, obj_t, var_t, obj_t);
extern obj_t atom_ast_node;
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern bool_t _fx_134___r4_numbers_6_5_fixnum(long, long);
static obj_t _correct_arity_app_1790_104_ast_app(obj_t, obj_t, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t _make_app_node1792_7_ast_app(obj_t, obj_t, obj_t, obj_t, obj_t);
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
static obj_t make_the_app_69_ast_app(obj_t, obj_t, obj_t);
static obj_t make_args_list_220_ast_app(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern node_t make_app_node_80_ast_app(obj_t, obj_t, var_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_app = BUNSPEC;
static obj_t cnst_init_137_ast_app();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[12];

DEFINE_EXPORT_PROCEDURE(make_app_node_env_134_ast_app, _make_app_node1792_7_ast_app1804, _make_app_node1792_7_ast_app, 0L, 4);
DEFINE_EXPORT_PROCEDURE(application__node_env_37_ast_app, _application__node1791_8_ast_app1805, _application__node1791_8_ast_app, 0L, 4);
DEFINE_EXPORT_PROCEDURE(correct_arity_app__env_151_ast_app, _correct_arity_app_1790_104_ast_app1806, _correct_arity_app_1790_104_ast_app, 0L, 2);
DEFINE_STRING(string1797_ast_app, string1797_ast_app1807, "FOREIGN C-CONS LIST \077\077\077 ARG (LAMBDA L L) LET FUN VALUE (QUOTE ()) APP @ ", 72);
DEFINE_STRING(string1796_ast_app, string1796_ast_app1808, "Illegal application: ", 21);
DEFINE_STRING(string1795_ast_app, string1795_ast_app1809, " provided", 9);
DEFINE_STRING(string1794_ast_app, string1794_ast_app1810, " or more arg(s) expected, ", 26);
DEFINE_STRING(string1793_ast_app, string1793_ast_app1811, " arg(s) expected, ", 18);


/* module-initialization */ obj_t 
module_initialization_70_ast_app(long checksum_1558, char *from_1559)
{
   if (CBOOL(require_initialization_114_ast_app))
     {
	require_initialization_114_ast_app = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_app();
	cnst_init_137_ast_app();
	imported_modules_init_94_ast_app();
	method_init_76_ast_app();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_app()
{
   module_initialization_70___r4_numbers_6_5(((long) 0), "AST_APP");
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_APP");
   module_initialization_70___object(((long) 0), "AST_APP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_APP");
   module_initialization_70___r4_strings_6_7(((long) 0), "AST_APP");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "AST_APP");
   module_initialization_70___reader(((long) 0), "AST_APP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_app()
{
   {
      obj_t cnst_port_138_1550;
      cnst_port_138_1550 = open_input_string(string1797_ast_app);
      {
	 long i_1551;
	 i_1551 = ((long) 11);
       loop_1552:
	 {
	    bool_t test1798_1553;
	    test1798_1553 = (i_1551 == ((long) -1));
	    if (test1798_1553)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1799_1554;
		    {
		       obj_t list1800_1555;
		       {
			  obj_t arg1802_1556;
			  arg1802_1556 = BNIL;
			  list1800_1555 = MAKE_PAIR(cnst_port_138_1550, arg1802_1556);
		       }
		       arg1799_1554 = read___reader(list1800_1555);
		    }
		    CNST_TABLE_SET(i_1551, arg1799_1554);
		 }
		 {
		    int aux_1557;
		    {
		       long aux_1580;
		       aux_1580 = (i_1551 - ((long) 1));
		       aux_1557 = (int) (aux_1580);
		    }
		    {
		       long i_1583;
		       i_1583 = (long) (aux_1557);
		       i_1551 = i_1583;
		       goto loop_1552;
		    }
		 }
	      }
	 }
      }
   }
}


/* correct-arity-app? */ bool_t 
correct_arity_app__187_ast_app(variable_t var_1, obj_t args_2)
{
   {
      long nb_args_51_718;
      nb_args_51_718 = list_length(args_2);
      {
	 long arity_719;
	 {
	    fun_t obj_1325;
	    {
	       value_t aux_1586;
	       aux_1586 = (((variable_t) CREF(var_1))->value);
	       obj_1325 = (fun_t) (aux_1586);
	    }
	    arity_719 = (((fun_t) CREF(obj_1325))->arity);
	 }
	 {
	    if ((arity_719 == ((long) -1)))
	      {
		 return ((bool_t) 1);
	      }
	    else
	      {
		 if ((arity_719 >= ((long) 0)))
		   {
		      return _fx_134___r4_numbers_6_5_fixnum(arity_719, nb_args_51_718);
		   }
		 else
		   {
		      {
			 long aux_1595;
			 {
			    long aux_1598;
			    long aux_1596;
			    aux_1598 = (nb_args_51_718 + ((long) 1));
			    aux_1596 = NEG(arity_719);
			    aux_1595 = (aux_1596 - aux_1598);
			 }
			 return (aux_1595 <= ((long) 0));
		      }
		   }
	      }
	 }
      }
   }
}


/* _correct-arity-app?1790 */ obj_t 
_correct_arity_app_1790_104_ast_app(obj_t env_1535, obj_t var_1536, obj_t args_1537)
{
   {
      bool_t aux_1602;
      aux_1602 = correct_arity_app__187_ast_app((variable_t) (var_1536), args_1537);
      return BBOOL(aux_1602);
   }
}


/* clean-user-node! */ node_t 
clean_user_node__130_ast_app(node_t node_3)
{
   {
      node_t walk_726;
      walk_726 = node_3;
    loop_727:
      {
	 bool_t test1450_728;
	 test1450_728 = is_a__118___object((obj_t) (walk_726), let_var_6_ast_node);
	 if (test1450_728)
	   {
	      {
		 obj_t l1435_729;
		 {
		    let_var_6_t obj_1338;
		    obj_1338 = (let_var_6_t) (walk_726);
		    l1435_729 = (((let_var_6_t) CREF(obj_1338))->bindings);
		 }
	       lname1436_730:
		 if (PAIRP(l1435_729))
		   {
		      {
			 local_t obj_1342;
			 {
			    obj_t aux_1611;
			    {
			       obj_t aux_1612;
			       aux_1612 = CAR(l1435_729);
			       aux_1611 = CAR(aux_1612);
			    }
			    obj_1342 = (local_t) (aux_1611);
			 }
			 ((((local_t) CREF(obj_1342))->user__32) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		      {
			 obj_t l1435_1617;
			 l1435_1617 = CDR(l1435_729);
			 l1435_729 = l1435_1617;
			 goto lname1436_730;
		      }
		   }
		 else
		   {
		      ((bool_t) 1);
		   }
	      }
	      {
		 node_t walk_1621;
		 {
		    let_var_6_t obj_1345;
		    obj_1345 = (let_var_6_t) (walk_726);
		    walk_1621 = (((let_var_6_t) CREF(obj_1345))->body);
		 }
		 walk_726 = walk_1621;
		 goto loop_727;
	      }
	   }
	 else
	   {
	      return node_3;
	   }
      }
   }
}


/* application->node */ node_t 
application__node_43_ast_app(obj_t exp_4, obj_t stack_5, obj_t loc_6, obj_t site_7)
{
   {
      obj_t exp_831;
      {
	 obj_t loc_738;
	 loc_738 = find_location_loc_243_tools_location(exp_4, loc_6);
	 {
	    obj_t err_nb_106_739;
	    err_nb_106_739 = _nb_error_on_pass__70_tools_error;
	    {
	       node_t fun_740;
	       fun_740 = sexp__node_235_ast_sexp(CAR(exp_4), stack_5, loc_738, CNST_TABLE_REF(((long) 1)));
	       {
		  bool_t fun_err__19_741;
		  {
		     long n1_1347;
		     long n2_1348;
		     n1_1347 = (long) CINT(_nb_error_on_pass__70_tools_error);
		     n2_1348 = (long) CINT(err_nb_106_739);
		     fun_err__19_741 = (n1_1347 > n2_1348);
		  }
		  {
		     {
			bool_t test1459_742;
			{
			   bool_t test_1631;
			   exp_831 = exp_4;
			   {
			      obj_t exp_833;
			      exp_833 = exp_831;
			    loop_834:
			      if (NULLP(exp_833))
				{
				   test_1631 = ((bool_t) 1);
				}
			      else
				{
				   {
				      obj_t e_104_34_839;
				      e_104_34_839 = CAR(exp_833);
				      if (PAIRP(e_104_34_839))
					{
					   obj_t cdr_108_37_841;
					   cdr_108_37_841 = CDR(e_104_34_839);
					   {
					      bool_t test_1638;
					      {
						 obj_t aux_1641;
						 obj_t aux_1639;
						 aux_1641 = CNST_TABLE_REF(((long) 0));
						 aux_1639 = CAR(e_104_34_839);
						 test_1638 = (aux_1639 == aux_1641);
					      }
					      if (test_1638)
						{
						   if (PAIRP(cdr_108_37_841))
						     {
							obj_t cdr_110_67_844;
							cdr_110_67_844 = CDR(cdr_108_37_841);
							{
							   bool_t test_1647;
							   {
							      obj_t aux_1648;
							      aux_1648 = CAR(cdr_108_37_841);
							      test_1647 = SYMBOLP(aux_1648);
							   }
							   if (test_1647)
							     {
								if (PAIRP(cdr_110_67_844))
								  {
								     bool_t test_1653;
								     {
									obj_t aux_1654;
									aux_1654 = CAR(cdr_110_67_844);
									test_1653 = SYMBOLP(aux_1654);
								     }
								     if (test_1653)
								       {
									  bool_t test_1657;
									  {
									     obj_t aux_1658;
									     aux_1658 = CDR(cdr_110_67_844);
									     test_1657 = (aux_1658 == BNIL);
									  }
									  if (test_1657)
									    {
									       {
										  obj_t exp_1661;
										  exp_1661 = CDR(exp_833);
										  exp_833 = exp_1661;
										  goto loop_834;
									       }
									    }
									  else
									    {
									     tag_103_156_838:
									       {
										  bool_t _ortest_1437_857;
										  _ortest_1437_857 = is_a__118___object(CAR(exp_833), atom_ast_node);
										  if (_ortest_1437_857)
										    {
										       test_1631 = _ortest_1437_857;
										    }
										  else
										    {
										       test_1631 = is_a__118___object(CAR(exp_833), var_ast_node);
										    }
									       }
									    }
								       }
								     else
								       {
									  goto tag_103_156_838;
								       }
								  }
								else
								  {
								     goto tag_103_156_838;
								  }
							     }
							   else
							     {
								goto tag_103_156_838;
							     }
							}
						     }
						   else
						     {
							goto tag_103_156_838;
						     }
						}
					      else
						{
						   goto tag_103_156_838;
						}
					   }
					}
				      else
					{
					   {
					      obj_t exp_1668;
					      exp_1668 = CDR(exp_833);
					      exp_833 = exp_1668;
					      goto loop_834;
					   }
					}
				   }
				}
			   }
			   if (test_1631)
			     {
				test1459_742 = is_a__118___object((obj_t) (fun_740), var_ast_node);
			     }
			   else
			     {
				test1459_742 = ((bool_t) 0);
			     }
			}
			if (test1459_742)
			  {
			     obj_t args_743;
			     args_743 = CDR(exp_4);
			     {
				long delta_744;
				delta_744 = check_user_app_174_ast_app(fun_740, args_743);
				{
				   {
				      bool_t test1460_745;
				      test1460_745 = is_a__118___object((obj_t) (fun_740), var_ast_node);
				      if (test1460_745)
					{
					   if ((delta_744 == ((long) 0)))
					     {
						return make_app_node_80_ast_app(stack_5, loc_738, (var_t) (fun_740), args_743);
					     }
					   else
					     {
						return wrong_number_of_arguments_4_ast_app(exp_4, loc_738, fun_740, args_743);
					     }
					}
				      else
					{
					   return sexp__node_235_ast_sexp(CNST_TABLE_REF(((long) 2)), stack_5, loc_738, CNST_TABLE_REF(((long) 3)));
					}
				   }
				}
			     }
			  }
			else
			  {
			     obj_t old_args_130_749;
			     obj_t new_args_235_750;
			     obj_t bindings_751;
			     old_args_130_749 = CDR(exp_4);
			     new_args_235_750 = BNIL;
			     bindings_751 = BNIL;
			   loop_752:
			     if (NULLP(old_args_130_749))
			       {
				  {
				     obj_t old_fun_147_757;
				     old_fun_147_757 = CAR(exp_4);
				     {
					bool_t test1469_759;
					test1469_759 = is_a__118___object((obj_t) (fun_740), var_ast_node);
					if (test1469_759)
					  {
					     node_t node_760;
					     {
						obj_t arg1470_761;
						arg1470_761 = make_the_app_69_ast_app(new_args_235_750, bindings_751, old_fun_147_757);
						node_760 = sexp__node_235_ast_sexp(arg1470_761, stack_5, loc_738, site_7);
					     }
					     return clean_user_node__130_ast_app(node_760);
					  }
					else
					  {
					     obj_t new_fun_115_762;
					     {
						obj_t arg1489_782;
						arg1489_782 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 4)), BEOA);
						new_fun_115_762 = mark_symbol_non_user__17_ast_ident(arg1489_782);
					     }
					     {
						obj_t lexp_763;
						{
						   obj_t arg1471_765;
						   obj_t arg1473_766;
						   obj_t arg1474_767;
						   arg1471_765 = CNST_TABLE_REF(((long) 5));
						   {
						      obj_t arg1480_773;
						      {
							 obj_t arg1484_777;
							 if (fun_err__19_741)
							   {
							      arg1484_777 = CNST_TABLE_REF(((long) 6));
							   }
							 else
							   {
							      arg1484_777 = old_fun_147_757;
							   }
							 {
							    obj_t list1486_779;
							    {
							       obj_t arg1487_780;
							       arg1487_780 = MAKE_PAIR(BNIL, BNIL);
							       list1486_779 = MAKE_PAIR(arg1484_777, arg1487_780);
							    }
							    arg1480_773 = cons__138___r4_pairs_and_lists_6_3(new_fun_115_762, list1486_779);
							 }
						      }
						      {
							 obj_t list1482_775;
							 list1482_775 = MAKE_PAIR(BNIL, BNIL);
							 arg1473_766 = cons__138___r4_pairs_and_lists_6_3(arg1480_773, list1482_775);
						      }
						   }
						   arg1474_767 = make_the_app_69_ast_app(new_args_235_750, bindings_751, new_fun_115_762);
						   {
						      obj_t list1476_769;
						      {
							 obj_t arg1477_770;
							 {
							    obj_t arg1478_771;
							    arg1478_771 = MAKE_PAIR(BNIL, BNIL);
							    arg1477_770 = MAKE_PAIR(arg1474_767, arg1478_771);
							 }
							 list1476_769 = MAKE_PAIR(arg1473_766, arg1477_770);
						      }
						      lexp_763 = cons__138___r4_pairs_and_lists_6_3(arg1471_765, list1476_769);
						   }
						}
						{
						   node_t node_764;
						   node_764 = sexp__node_235_ast_sexp(lexp_763, stack_5, loc_738, site_7);
						   {
						      return clean_user_node__130_ast_app(node_764);
						   }
						}
					     }
					  }
				     }
				  }
			       }
			     else
			       {
				  bool_t test_1714;
				  {
				     bool_t test_1715;
				     {
					obj_t aux_1716;
					aux_1716 = CAR(old_args_130_749);
					test_1715 = SYMBOLP(aux_1716);
				     }
				     if (test_1715)
				       {
					  test_1714 = ((bool_t) 1);
				       }
				     else
				       {
					  obj_t aux_1719;
					  aux_1719 = CAR(old_args_130_749);
					  test_1714 = CNSTP(aux_1719);
				       }
				  }
				  if (test_1714)
				    {
				       {
					  obj_t arg1522_811;
					  obj_t arg1524_812;
					  arg1522_811 = CDR(old_args_130_749);
					  {
					     obj_t aux_1723;
					     aux_1723 = CAR(old_args_130_749);
					     arg1524_812 = MAKE_PAIR(aux_1723, new_args_235_750);
					  }
					  {
					     obj_t new_args_235_1727;
					     obj_t old_args_130_1726;
					     old_args_130_1726 = arg1522_811;
					     new_args_235_1727 = arg1524_812;
					     new_args_235_750 = new_args_235_1727;
					     old_args_130_749 = old_args_130_1726;
					     goto loop_752;
					  }
				       }
				    }
				  else
				    {
				       {
					  obj_t new_arg_128_814;
					  {
					     obj_t arg1534_823;
					     arg1534_823 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 7)), BEOA);
					     new_arg_128_814 = mark_symbol_non_user__17_ast_ident(arg1534_823);
					  }
					  {
					     obj_t arg1526_815;
					     obj_t arg1527_816;
					     obj_t arg1528_817;
					     arg1526_815 = CDR(old_args_130_749);
					     arg1527_816 = MAKE_PAIR(new_arg_128_814, new_args_235_750);
					     {
						obj_t arg1529_818;
						{
						   obj_t list1531_820;
						   {
						      obj_t arg1532_821;
						      {
							 obj_t aux_1734;
							 aux_1734 = CAR(old_args_130_749);
							 arg1532_821 = MAKE_PAIR(aux_1734, BNIL);
						      }
						      list1531_820 = MAKE_PAIR(new_arg_128_814, arg1532_821);
						   }
						   arg1529_818 = list1531_820;
						}
						arg1528_817 = MAKE_PAIR(arg1529_818, bindings_751);
					     }
					     {
						obj_t bindings_1741;
						obj_t new_args_235_1740;
						obj_t old_args_130_1739;
						old_args_130_1739 = arg1526_815;
						new_args_235_1740 = arg1527_816;
						bindings_1741 = arg1528_817;
						bindings_751 = bindings_1741;
						new_args_235_750 = new_args_235_1740;
						old_args_130_749 = old_args_130_1739;
						goto loop_752;
					     }
					  }
				       }
				    }
			       }
			  }
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-the-app */ obj_t 
make_the_app_69_ast_app(obj_t new_args_235_1549, obj_t bindings_1548, obj_t fun_784)
{
   if (PAIRP(bindings_1548))
     {
	obj_t arg1494_787;
	obj_t arg1496_788;
	obj_t arg1497_789;
	arg1494_787 = CNST_TABLE_REF(((long) 5));
	arg1496_788 = reverse__39___r4_pairs_and_lists_6_3(bindings_1548);
	{
	   obj_t arg1503_795;
	   {
	      obj_t arg1507_798;
	      obj_t arg1510_799;
	      arg1507_798 = reverse__39___r4_pairs_and_lists_6_3(new_args_235_1549);
	      arg1510_799 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
	      arg1503_795 = append_2_18___r4_pairs_and_lists_6_3(arg1507_798, arg1510_799);
	   }
	   {
	      obj_t list1504_796;
	      list1504_796 = MAKE_PAIR(arg1503_795, BNIL);
	      arg1497_789 = cons__138___r4_pairs_and_lists_6_3(fun_784, list1504_796);
	   }
	}
	{
	   obj_t list1499_791;
	   {
	      obj_t arg1500_792;
	      {
		 obj_t arg1501_793;
		 arg1501_793 = MAKE_PAIR(BNIL, BNIL);
		 arg1500_792 = MAKE_PAIR(arg1497_789, arg1501_793);
	      }
	      list1499_791 = MAKE_PAIR(arg1496_788, arg1500_792);
	   }
	   return cons__138___r4_pairs_and_lists_6_3(arg1494_787, list1499_791);
	}
     }
   else
     {
	obj_t arg1513_802;
	{
	   obj_t arg1516_805;
	   obj_t arg1517_806;
	   arg1516_805 = reverse__39___r4_pairs_and_lists_6_3(new_args_235_1549);
	   arg1517_806 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
	   arg1513_802 = append_2_18___r4_pairs_and_lists_6_3(arg1516_805, arg1517_806);
	}
	{
	   obj_t list1514_803;
	   list1514_803 = MAKE_PAIR(arg1513_802, BNIL);
	   return cons__138___r4_pairs_and_lists_6_3(fun_784, list1514_803);
	}
     }
}


/* _application->node1791 */ obj_t 
_application__node1791_8_ast_app(obj_t env_1538, obj_t exp_1539, obj_t stack_1540, obj_t loc_1541, obj_t site_1542)
{
   {
      node_t aux_1761;
      aux_1761 = application__node_43_ast_app(exp_1539, stack_1540, loc_1541, site_1542);
      return (obj_t) (aux_1761);
   }
}


/* wrong-number-of-arguments */ node_t 
wrong_number_of_arguments_4_ast_app(obj_t exp_8, obj_t loc_9, node_t fun_10, obj_t args_11)
{
   {
      variable_t var_861;
      {
	 var_t obj_1397;
	 obj_1397 = (var_t) (fun_10);
	 var_861 = (((var_t) CREF(obj_1397))->variable);
      }
      {
	 value_t fun_862;
	 fun_862 = (((variable_t) CREF(var_861))->value);
	 {
	    long nb_args_51_863;
	    nb_args_51_863 = list_length(args_11);
	    {
	       long arity_864;
	       {
		  bool_t test1589_886;
		  test1589_886 = is_a__118___object((obj_t) (fun_862), fun_ast_var);
		  if (test1589_886)
		    {
		       {
			  fun_t obj_1400;
			  obj_1400 = (fun_t) (fun_862);
			  arity_864 = (((fun_t) CREF(obj_1400))->arity);
		       }
		    }
		  else
		    {
		       arity_864 = ((long) -1);
		    }
	       }
	       {
		  obj_t expect_865;
		  if ((arity_864 >= ((long) 0)))
		    {
		       {
			  obj_t aux_1775;
			  {
			     char *aux_1776;
			     aux_1776 = number__string_214___r4_numbers_6_5(BINT(arity_864), BNIL);
			     aux_1775 = string_to_bstring(aux_1776);
			  }
			  expect_865 = string_append(aux_1775, string1793_ast_app);
		       }
		    }
		  else
		    {
		       {
			  obj_t aux_1781;
			  {
			     char *aux_1782;
			     {
				obj_t aux_1783;
				{
				   long aux_1784;
				   {
				      long aux_1785;
				      aux_1785 = (arity_864 + ((long) 1));
				      aux_1784 = NEG(aux_1785);
				   }
				   aux_1783 = BINT(aux_1784);
				}
				aux_1782 = number__string_214___r4_numbers_6_5(aux_1783, BNIL);
			     }
			     aux_1781 = string_to_bstring(aux_1782);
			  }
			  expect_865 = string_append(aux_1781, string1794_ast_app);
		       }
		    }
		  {
		     obj_t provide_866;
		     {
			obj_t aux_1792;
			{
			   char *aux_1793;
			   aux_1793 = number__string_214___r4_numbers_6_5(BINT(nb_args_51_863), BNIL);
			   aux_1792 = string_to_bstring(aux_1793);
			}
			provide_866 = string_append(aux_1792, string1795_ast_app);
		     }
		     {
			{
			   obj_t arg1565_867;
			   {
			      obj_t list1566_868;
			      {
				 obj_t arg1569_870;
				 {
				    obj_t arg1570_871;
				    arg1570_871 = MAKE_PAIR(provide_866, BNIL);
				    arg1569_870 = MAKE_PAIR(expect_865, arg1570_871);
				 }
				 list1566_868 = MAKE_PAIR(string1796_ast_app, arg1569_870);
			      }
			      arg1565_867 = string_append_106___r4_strings_6_7(list1566_868);
			   }
			   return error_sexp__node_157_ast_sexp(arg1565_867, exp_8, loc_9);
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* make-app-node */ node_t 
make_app_node_80_ast_app(obj_t stack_12, obj_t loc_13, var_t var_14, obj_t args_15)
{
   {
      value_t fun_887;
      {
	 variable_t arg1607_906;
	 arg1607_906 = (((var_t) CREF(var_14))->variable);
	 fun_887 = (((variable_t) CREF(arg1607_906))->value);
      }
      {
	 bool_t test1590_888;
	 {
	    bool_t test1603_902;
	    test1603_902 = is_a__118___object((obj_t) (fun_887), fun_ast_var);
	    if (test1603_902)
	      {
		 bool_t test_1808;
		 {
		    long aux_1809;
		    {
		       fun_t obj_1409;
		       obj_1409 = (fun_t) (fun_887);
		       aux_1809 = (((fun_t) CREF(obj_1409))->arity);
		    }
		    test_1808 = (aux_1809 >= ((long) 0));
		 }
		 if (test_1808)
		   {
		      test1590_888 = ((bool_t) 1);
		   }
		 else
		   {
		      test1590_888 = is_a__118___object((obj_t) (fun_887), cfun_ast_var);
		   }
	      }
	    else
	      {
		 test1590_888 = ((bool_t) 1);
	      }
	 }
	 if (test1590_888)
	   {
	      obj_t args_889;
	      {
		 obj_t args_890;
		 obj_t res_891;
		 args_890 = args_15;
		 res_891 = BNIL;
	       loop_892:
		 if (NULLP(args_890))
		   {
		      args_889 = reverse__39___r4_pairs_and_lists_6_3(res_891);
		   }
		 else
		   {
		      obj_t a_895;
		      obj_t loc_896;
		      a_895 = CAR(args_890);
		      loc_896 = find_location_loc_243_tools_location(args_890, loc_13);
		      {
			 obj_t arg1594_897;
			 obj_t arg1595_898;
			 arg1594_897 = CDR(args_890);
			 {
			    node_t arg1598_899;
			    arg1598_899 = sexp__node_235_ast_sexp(a_895, stack_12, loc_896, CNST_TABLE_REF(((long) 3)));
			    {
			       obj_t aux_1824;
			       aux_1824 = (obj_t) (arg1598_899);
			       arg1595_898 = MAKE_PAIR(aux_1824, res_891);
			    }
			 }
			 {
			    obj_t res_1828;
			    obj_t args_1827;
			    args_1827 = arg1594_897;
			    res_1828 = arg1595_898;
			    res_891 = res_1828;
			    args_890 = args_1827;
			    goto loop_892;
			 }
		      }
		   }
	      }
	      {
		 obj_t aux_1829;
		 aux_1829 = make_fx_app_node_213_ast_app(loc_13, var_14, args_889);
		 return (node_t) (aux_1829);
	      }
	   }
	 else
	   {
	      long aux_1832;
	      {
		 fun_t obj_1418;
		 obj_1418 = (fun_t) (fun_887);
		 aux_1832 = (((fun_t) CREF(obj_1418))->arity);
	      }
	      return make_va_app_node_0_ast_app(aux_1832, stack_12, loc_13, var_14, args_15);
	   }
      }
   }
}


/* _make-app-node1792 */ obj_t 
_make_app_node1792_7_ast_app(obj_t env_1543, obj_t stack_1544, obj_t loc_1545, obj_t var_1546, obj_t args_1547)
{
   {
      node_t aux_1836;
      aux_1836 = make_app_node_80_ast_app(stack_1544, loc_1545, (var_t) (var_1546), args_1547);
      return (obj_t) (aux_1836);
   }
}


/* make-fx-app-node */ obj_t 
make_fx_app_node_213_ast_app(obj_t loc_16, var_t var_17, obj_t args_18)
{
   {
      variable_t v_907;
      v_907 = (((var_t) CREF(var_17))->variable);
      {
	 bool_t test1608_908;
	 {
	    obj_t aux_1841;
	    {
	       value_t aux_1842;
	       aux_1842 = (((variable_t) CREF(v_907))->value);
	       aux_1841 = (obj_t) (aux_1842);
	    }
	    test1608_908 = is_a__118___object(aux_1841, fun_ast_var);
	 }
	 if (test1608_908)
	   {
	      type_t arg1610_910;
	      var_t arg1613_912;
	      arg1610_910 = (((variable_t) CREF(v_907))->type);
	      {
		 bool_t test1616_914;
		 test1616_914 = is_a__118___object((obj_t) (var_17), closure_ast_node);
		 if (test1616_914)
		   {
		      var_t new1440_916;
		      {
			 obj_t arg1617_917;
			 type_t arg1618_918;
			 variable_t arg1620_919;
			 arg1617_917 = (((var_t) CREF(var_17))->loc);
			 arg1618_918 = (((var_t) CREF(var_17))->type);
			 arg1620_919 = (((var_t) CREF(var_17))->variable);
			 {
			    var_t res1787_1437;
			    {
			       var_t new1206_1430;
			       new1206_1430 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			       {
				  long arg1744_1431;
				  arg1744_1431 = class_num_218___object(var_ast_node);
				  {
				     obj_t obj_1435;
				     obj_1435 = (obj_t) (new1206_1430);
				     (((obj_t) CREF(obj_1435))->header = MAKE_HEADER(arg1744_1431, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_1858;
				  aux_1858 = (object_t) (new1206_1430);
				  OBJECT_WIDENING_SET(aux_1858, BFALSE);
			       }
			       ((((var_t) CREF(new1206_1430))->loc) = ((obj_t) arg1617_917), BUNSPEC);
			       ((((var_t) CREF(new1206_1430))->type) = ((type_t) arg1618_918), BUNSPEC);
			       ((((var_t) CREF(new1206_1430))->variable) = ((variable_t) arg1620_919), BUNSPEC);
			       res1787_1437 = new1206_1430;
			    }
			    new1440_916 = res1787_1437;
			 }
		      }
		      {
			 arg1613_912 = new1440_916;
		      }
		   }
		 else
		   {
		      arg1613_912 = var_17;
		   }
	      }
	      {
		 app_t res1788_1456;
		 {
		    obj_t key_1441;
		    key_1441 = BINT(((long) -1));
		    {
		       app_t new1240_1445;
		       new1240_1445 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
		       {
			  long arg1730_1446;
			  arg1730_1446 = class_num_218___object(app_ast_node);
			  {
			     obj_t obj_1454;
			     obj_1454 = (obj_t) (new1240_1445);
			     (((obj_t) CREF(obj_1454))->header = MAKE_HEADER(arg1730_1446, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_1869;
			  aux_1869 = (object_t) (new1240_1445);
			  OBJECT_WIDENING_SET(aux_1869, BFALSE);
		       }
		       ((((app_t) CREF(new1240_1445))->loc) = ((obj_t) loc_16), BUNSPEC);
		       ((((app_t) CREF(new1240_1445))->type) = ((type_t) arg1610_910), BUNSPEC);
		       ((((app_t) CREF(new1240_1445))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		       ((((app_t) CREF(new1240_1445))->key) = ((obj_t) key_1441), BUNSPEC);
		       ((((app_t) CREF(new1240_1445))->fun) = ((var_t) arg1613_912), BUNSPEC);
		       ((((app_t) CREF(new1240_1445))->args) = ((obj_t) args_18), BUNSPEC);
		       ((((app_t) CREF(new1240_1445))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
		       res1788_1456 = new1240_1445;
		    }
		 }
		 return (obj_t) (res1788_1456);
	      }
	   }
	 else
	   {
	      obj_t arg1622_921;
	      obj_t arg1624_923;
	      obj_t arg1625_924;
	      arg1622_921 = ____74_type_cache;
	      {
		 obj_t aux_1880;
		 aux_1880 = (obj_t) (var_17);
		 arg1624_923 = MAKE_PAIR(aux_1880, args_18);
	      }
	      arg1625_924 = CNST_TABLE_REF(((long) 8));
	      {
		 funcall_t res1789_1473;
		 {
		    type_t type_1460;
		    node_t fun_1461;
		    type_1460 = (type_t) (arg1622_921);
		    fun_1461 = (node_t) (var_17);
		    {
		       funcall_t new1266_1464;
		       new1266_1464 = ((funcall_t) BREF(GC_MALLOC(sizeof(struct funcall))));
		       {
			  long arg1726_1465;
			  arg1726_1465 = class_num_218___object(funcall_ast_node);
			  {
			     obj_t obj_1471;
			     obj_1471 = (obj_t) (new1266_1464);
			     (((obj_t) CREF(obj_1471))->header = MAKE_HEADER(arg1726_1465, 0), BUNSPEC);
			  }
		       }
		       {
			  object_t aux_1890;
			  aux_1890 = (object_t) (new1266_1464);
			  OBJECT_WIDENING_SET(aux_1890, BFALSE);
		       }
		       ((((funcall_t) CREF(new1266_1464))->loc) = ((obj_t) loc_16), BUNSPEC);
		       ((((funcall_t) CREF(new1266_1464))->type) = ((type_t) type_1460), BUNSPEC);
		       ((((funcall_t) CREF(new1266_1464))->fun) = ((node_t) fun_1461), BUNSPEC);
		       ((((funcall_t) CREF(new1266_1464))->args) = ((obj_t) arg1624_923), BUNSPEC);
		       ((((funcall_t) CREF(new1266_1464))->strength) = ((obj_t) arg1625_924), BUNSPEC);
		       res1789_1473 = new1266_1464;
		    }
		 }
		 return (obj_t) (res1789_1473);
	      }
	   }
      }
   }
}


/* make-va-app-node */ node_t 
make_va_app_node_0_ast_app(long arity_19, obj_t stack_20, obj_t loc_21, var_t var_22, obj_t args_23)
{
   {
      obj_t old_args_130_927;
      long arity_928;
      obj_t f_args_123_929;
      old_args_130_927 = args_23;
      arity_928 = arity_19;
      f_args_123_929 = BNIL;
    loop_930:
      if ((arity_928 == ((long) -1)))
	{
	   obj_t l_arg_48_933;
	   {
	      obj_t arg1656_957;
	      arg1656_957 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 9)), BEOA);
	      l_arg_48_933 = mark_symbol_non_user__17_ast_ident(arg1656_957);
	   }
	   {
	      obj_t l_exp_15_934;
	      {
		 obj_t arg1634_941;
		 obj_t arg1636_942;
		 arg1634_941 = CNST_TABLE_REF(((long) 5));
		 {
		    obj_t arg1646_948;
		    {
		       obj_t arg1650_952;
		       arg1650_952 = make_args_list_220_ast_app(old_args_130_927);
		       {
			  obj_t list1653_954;
			  {
			     obj_t arg1654_955;
			     arg1654_955 = MAKE_PAIR(BNIL, BNIL);
			     list1653_954 = MAKE_PAIR(arg1650_952, arg1654_955);
			  }
			  arg1646_948 = cons__138___r4_pairs_and_lists_6_3(l_arg_48_933, list1653_954);
		       }
		    }
		    {
		       obj_t list1648_950;
		       list1648_950 = MAKE_PAIR(BNIL, BNIL);
		       arg1636_942 = cons__138___r4_pairs_and_lists_6_3(arg1646_948, list1648_950);
		    }
		 }
		 {
		    obj_t list1639_944;
		    {
		       obj_t arg1640_945;
		       {
			  obj_t arg1641_946;
			  arg1641_946 = MAKE_PAIR(BNIL, BNIL);
			  arg1640_945 = MAKE_PAIR(l_arg_48_933, arg1641_946);
		       }
		       list1639_944 = MAKE_PAIR(arg1636_942, arg1640_945);
		    }
		    l_exp_15_934 = cons__138___r4_pairs_and_lists_6_3(arg1634_941, list1639_944);
		 }
	      }
	      {
		 node_t l_node_207_935;
		 l_node_207_935 = sexp__node_235_ast_sexp(l_exp_15_934, stack_20, loc_21, CNST_TABLE_REF(((long) 3)));
		 {
		    obj_t app_937;
		    {
		       obj_t arg1630_938;
		       {
			  obj_t arg1632_939;
			  {
			     obj_t aux_1918;
			     {
				node_t aux_1919;
				{
				   let_var_6_t obj_1476;
				   obj_1476 = (let_var_6_t) (l_node_207_935);
				   aux_1919 = (((let_var_6_t) CREF(obj_1476))->body);
				}
				aux_1918 = (obj_t) (aux_1919);
			     }
			     arg1632_939 = MAKE_PAIR(aux_1918, f_args_123_929);
			  }
			  arg1630_938 = reverse__39___r4_pairs_and_lists_6_3(arg1632_939);
		       }
		       app_937 = make_fx_app_node_213_ast_app(loc_21, var_22, arg1630_938);
		    }
		    {
		       {
			  let_var_6_t obj_1479;
			  node_t val1378_1480;
			  obj_1479 = (let_var_6_t) (l_node_207_935);
			  val1378_1480 = (node_t) (app_937);
			  ((((let_var_6_t) CREF(obj_1479))->body) = ((node_t) val1378_1480), BUNSPEC);
		       }
		       return clean_user_node__130_ast_app(l_node_207_935);
		    }
		 }
	      }
	   }
	}
      else
	{
	   obj_t arg1658_959;
	   long arg1659_960;
	   obj_t arg1661_961;
	   arg1658_959 = CDR(old_args_130_927);
	   arg1659_960 = (arity_928 + ((long) 1));
	   {
	      node_t arg1663_962;
	      arg1663_962 = sexp__node_235_ast_sexp(CAR(old_args_130_927), stack_20, loc_21, CNST_TABLE_REF(((long) 3)));
	      {
		 obj_t aux_1935;
		 aux_1935 = (obj_t) (arg1663_962);
		 arg1661_961 = MAKE_PAIR(aux_1935, f_args_123_929);
	      }
	   }
	   {
	      obj_t f_args_123_1940;
	      long arity_1939;
	      obj_t old_args_130_1938;
	      old_args_130_1938 = arg1658_959;
	      arity_1939 = arg1659_960;
	      f_args_123_1940 = arg1661_961;
	      f_args_123_929 = f_args_123_1940;
	      arity_928 = arity_1939;
	      old_args_130_927 = old_args_130_1938;
	      goto loop_930;
	   }
	}
   }
}


/* make-args-list */ obj_t 
make_args_list_220_ast_app(obj_t args_965)
{
   if (NULLP(args_965))
     {
	return CNST_TABLE_REF(((long) 2));
     }
   else
     {
	obj_t arg1669_968;
	obj_t arg1670_969;
	obj_t arg1672_970;
	{
	   obj_t arg1678_976;
	   obj_t arg1679_977;
	   obj_t arg1680_978;
	   arg1678_976 = CNST_TABLE_REF(((long) 0));
	   arg1679_977 = CNST_TABLE_REF(((long) 10));
	   arg1680_978 = CNST_TABLE_REF(((long) 11));
	   {
	      obj_t list1682_980;
	      {
		 obj_t arg1683_981;
		 {
		    obj_t arg1684_982;
		    arg1684_982 = MAKE_PAIR(BNIL, BNIL);
		    arg1683_981 = MAKE_PAIR(arg1680_978, arg1684_982);
		 }
		 list1682_980 = MAKE_PAIR(arg1679_977, arg1683_981);
	      }
	      arg1669_968 = cons__138___r4_pairs_and_lists_6_3(arg1678_976, list1682_980);
	   }
	}
	arg1670_969 = CAR(args_965);
	arg1672_970 = make_args_list_220_ast_app(CDR(args_965));
	{
	   obj_t list1674_972;
	   {
	      obj_t arg1675_973;
	      {
		 obj_t arg1676_974;
		 arg1676_974 = MAKE_PAIR(BNIL, BNIL);
		 arg1675_973 = MAKE_PAIR(arg1672_970, arg1676_974);
	      }
	      list1674_972 = MAKE_PAIR(arg1670_969, arg1675_973);
	   }
	   return cons__138___r4_pairs_and_lists_6_3(arg1669_968, list1674_972);
	}
     }
}


/* check-user-app */ long 
check_user_app_174_ast_app(node_t fun_24, obj_t args_25)
{
   {
      bool_t test1687_986;
      test1687_986 = is_a__118___object((obj_t) (fun_24), var_ast_node);
      if (test1687_986)
	{
	   variable_t var_987;
	   {
	      var_t obj_1491;
	      obj_1491 = (var_t) (fun_24);
	      var_987 = (((var_t) CREF(obj_1491))->variable);
	   }
	   {
	      value_t fun_988;
	      fun_988 = (((variable_t) CREF(var_987))->value);
	      {
		 long nb_args_51_989;
		 nb_args_51_989 = list_length(args_25);
		 {
		    long arity_990;
		    {
		       bool_t test1695_998;
		       test1695_998 = is_a__118___object((obj_t) (fun_988), fun_ast_var);
		       if (test1695_998)
			 {
			    {
			       fun_t obj_1494;
			       obj_1494 = (fun_t) (fun_988);
			       arity_990 = (((fun_t) CREF(obj_1494))->arity);
			    }
			 }
		       else
			 {
			    arity_990 = ((long) -1);
			 }
		    }
		    {
		       if ((arity_990 == ((long) -1)))
			 {
			    return ((long) 0);
			 }
		       else
			 {
			    if ((arity_990 >= ((long) 0)))
			      {
				 return (arity_990 - nb_args_51_989);
			      }
			    else
			      {
				 {
				    bool_t test_1975;
				    {
				       long aux_1976;
				       {
					  long aux_1979;
					  long aux_1977;
					  aux_1979 = (nb_args_51_989 + ((long) 1));
					  aux_1977 = NEG(arity_990);
					  aux_1976 = (aux_1977 - aux_1979);
				       }
				       test_1975 = (aux_1976 <= ((long) 0));
				    }
				    if (test_1975)
				      {
					 return ((long) 0);
				      }
				    else
				      {
					 return ((long) 1);
				      }
				 }
			      }
			 }
		    }
		 }
	      }
	   }
	}
      else
	{
	   return ((long) 0);
	}
   }
}


/* method-init */ obj_t 
method_init_76_ast_app()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_app()
{
   module_initialization_70_type_type(((long) 0), "AST_APP");
   module_initialization_70_ast_var(((long) 0), "AST_APP");
   module_initialization_70_ast_node(((long) 0), "AST_APP");
   module_initialization_70_tools_error(((long) 0), "AST_APP");
   module_initialization_70_tools_location(((long) 0), "AST_APP");
   module_initialization_70_tools_shape(((long) 0), "AST_APP");
   module_initialization_70_type_cache(((long) 0), "AST_APP");
   module_initialization_70_ast_sexp(((long) 0), "AST_APP");
   return module_initialization_70_ast_ident(((long) 0), "AST_APP");
}
