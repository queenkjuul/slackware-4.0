/*===========================================================================*/
/*   (Ieee/char.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t symbol1494___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1493___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1492___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1491___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1489___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1490___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1488___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1487___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1486___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1484___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1479___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1480___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1478___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1477___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1476___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1475___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1474___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1473___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1472___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1471___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1469___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1470___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1468___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1467___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1466___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1465___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1464___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1463___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1462___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1461___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1459___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1460___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1458___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1457___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1456___r4_characters_6_6 = BUNSPEC;
static obj_t _integer__char_ur1190_16___r4_characters_6_6(obj_t, obj_t);
static obj_t symbol1455___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1454___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1453___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1452___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1451___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1450___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1447___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1446___r4_characters_6_6 = BUNSPEC;
static obj_t symbol1445___r4_characters_6_6 = BUNSPEC;
extern obj_t string_to_symbol(char *);
static obj_t _char___1176_50___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char___1177_12___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _integer__char1189_110___r4_characters_6_6(obj_t, obj_t);
extern long char__integer_184___r4_characters_6_6(unsigned char);
extern unsigned char char_downcase_76___r4_characters_6_6(unsigned char);
extern bool_t char_alphabetic__208___r4_characters_6_6(unsigned char);
static obj_t _char_upper_case_1186_83___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_ci__1179_147___r4_characters_6_6(obj_t, obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern unsigned char char_or_106___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci____41___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci___21___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci___242___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_ci___112___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_numeric__32___r4_characters_6_6(unsigned char);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _char__1174_255___r4_characters_6_6(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t _char_ci__1178_185___r4_characters_6_6(obj_t, obj_t, obj_t);
extern unsigned char integer__char_ur_23___r4_characters_6_6(long);
extern bool_t char_ci____192___r4_characters_6_6(unsigned char, unsigned char);
static obj_t _char_or1193_37___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_ci___1181_226___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char_lower_case_1187_156___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_ci___1182_91___r4_characters_6_6(obj_t, obj_t, obj_t);
extern unsigned char integer__char_140___r4_characters_6_6(long);
static obj_t _char__134___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_upcase1191_99___r4_characters_6_6(obj_t, obj_t);
static obj_t _char__1173_33___r4_characters_6_6(obj_t, obj_t, obj_t);
extern bool_t char_lower_case__222___r4_characters_6_6(unsigned char);
static obj_t _char_ci__1180_102___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t _char__integer1188_179___r4_characters_6_6(obj_t, obj_t);
extern bool_t char__59___r4_characters_6_6(obj_t);
static obj_t _char_whitespace_1185_254___r4_characters_6_6(obj_t, obj_t);
static obj_t _char_downcase1192_24___r4_characters_6_6(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_characters_6_6();
static obj_t _char_numeric_1184_30___r4_characters_6_6(obj_t, obj_t);
extern bool_t char____252___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char___195___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char___215___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char___13___r4_characters_6_6(unsigned char, unsigned char);
extern bool_t char_whitespace__92___r4_characters_6_6(unsigned char);
static obj_t _char__1175_177___r4_characters_6_6(obj_t, obj_t, obj_t);
static obj_t require_initialization_114___r4_characters_6_6 = BUNSPEC;
extern bool_t char_upper_case__12___r4_characters_6_6(unsigned char);
static obj_t _char_alphabetic_1183_115___r4_characters_6_6(obj_t, obj_t);
extern bool_t char____152___r4_characters_6_6(unsigned char, unsigned char);
static obj_t cnst_init_137___r4_characters_6_6();
extern unsigned char char_upcase_134___r4_characters_6_6(unsigned char);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( char_ci___env_200___r4_characters_6_6, _char_ci__1178_185___r4_characters_6_61496, _char_ci__1178_185___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( integer__char_ur_env_241___r4_characters_6_6, _integer__char_ur1190_16___r4_characters_6_61497, _integer__char_ur1190_16___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ci___env_123___r4_characters_6_6, _char_ci__1180_102___r4_characters_6_61498, _char_ci__1180_102___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_or_env_17___r4_characters_6_6, _char_or1193_37___r4_characters_6_61499, _char_or1193_37___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_upper_case__env_74___r4_characters_6_6, _char_upper_case_1186_83___r4_characters_6_61500, _char_upper_case_1186_83___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char__integer_env_161___r4_characters_6_6, _char__integer1188_179___r4_characters_6_61501, _char__integer1188_179___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char___env_34___r4_characters_6_6, _char__1174_255___r4_characters_6_61502, _char__1174_255___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_downcase_env_22___r4_characters_6_6, _char_downcase1192_24___r4_characters_6_61503, _char_downcase1192_24___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_numeric__env_250___r4_characters_6_6, _char_numeric_1184_30___r4_characters_6_61504, _char_numeric_1184_30___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ci____env_142___r4_characters_6_6, _char_ci___1181_226___r4_characters_6_61505, _char_ci___1181_226___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_ci____env_66___r4_characters_6_6, _char_ci___1182_91___r4_characters_6_61506, _char_ci___1182_91___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char___env_167___r4_characters_6_6, _char__1173_33___r4_characters_6_61507, _char__1173_33___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_lower_case__env_97___r4_characters_6_6, _char_lower_case_1187_156___r4_characters_6_61508, _char_lower_case_1187_156___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( integer__char_env_143___r4_characters_6_6, _integer__char1189_110___r4_characters_6_61509, _integer__char1189_110___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char____env_114___r4_characters_6_6, _char___1176_50___r4_characters_6_61510, _char___1176_50___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char____env_175___r4_characters_6_6, _char___1177_12___r4_characters_6_61511, _char___1177_12___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char__env_119___r4_characters_6_6, _char__134___r4_characters_6_61512, _char__134___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char___env_57___r4_characters_6_6, _char__1175_177___r4_characters_6_61513, _char__1175_177___r4_characters_6_6, 0L, 2 );
DEFINE_STRING( string1485___r4_characters_6_6, string1485___r4_characters_6_61514, "LONG", 4 );
DEFINE_STRING( string1483___r4_characters_6_6, string1483___r4_characters_6_61515, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1482___r4_characters_6_6, string1482___r4_characters_6_61516, "integer out of range", 20 );
DEFINE_STRING( string1481___r4_characters_6_6, string1481___r4_characters_6_61517, "integer->char", 13 );
DEFINE_STRING( string1449___r4_characters_6_6, string1449___r4_characters_6_61518, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/char.scm", 57 );
DEFINE_STRING( string1448___r4_characters_6_6, string1448___r4_characters_6_61519, "UCHAR", 5 );
DEFINE_EXPORT_PROCEDURE( char_upcase_env_199___r4_characters_6_6, _char_upcase1191_99___r4_characters_6_61520, _char_upcase1191_99___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_whitespace__env_29___r4_characters_6_6, _char_whitespace_1185_254___r4_characters_6_61521, _char_whitespace_1185_254___r4_characters_6_6, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( char_ci___env_202___r4_characters_6_6, _char_ci__1179_147___r4_characters_6_61522, _char_ci__1179_147___r4_characters_6_6, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( char_alphabetic__env_54___r4_characters_6_6, _char_alphabetic_1183_115___r4_characters_6_61523, _char_alphabetic_1183_115___r4_characters_6_6, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_characters_6_6(long checksum_816, char * from_817)
{
if(CBOOL(require_initialization_114___r4_characters_6_6)){
require_initialization_114___r4_characters_6_6 = BBOOL(((bool_t)0));
cnst_init_137___r4_characters_6_6();
imported_modules_init_94___r4_characters_6_6();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_characters_6_6()
{
symbol1445___r4_characters_6_6 = string_to_symbol("CHAR?");
symbol1446___r4_characters_6_6 = string_to_symbol("CHAR=?");
symbol1447___r4_characters_6_6 = string_to_symbol("_CHAR=?1173");
symbol1450___r4_characters_6_6 = string_to_symbol("CHAR<?");
symbol1451___r4_characters_6_6 = string_to_symbol("_CHAR<?1174");
symbol1452___r4_characters_6_6 = string_to_symbol("CHAR>?");
symbol1453___r4_characters_6_6 = string_to_symbol("_CHAR>?1175");
symbol1454___r4_characters_6_6 = string_to_symbol("CHAR<=?");
symbol1455___r4_characters_6_6 = string_to_symbol("_CHAR<=?1176");
symbol1456___r4_characters_6_6 = string_to_symbol("CHAR>=?");
symbol1457___r4_characters_6_6 = string_to_symbol("_CHAR>=?1177");
symbol1458___r4_characters_6_6 = string_to_symbol("CHAR-CI=?");
symbol1459___r4_characters_6_6 = string_to_symbol("_CHAR-CI=?1178");
symbol1460___r4_characters_6_6 = string_to_symbol("CHAR-CI<?");
symbol1461___r4_characters_6_6 = string_to_symbol("_CHAR-CI<?1179");
symbol1462___r4_characters_6_6 = string_to_symbol("CHAR-CI>?");
symbol1463___r4_characters_6_6 = string_to_symbol("_CHAR-CI>?1180");
symbol1464___r4_characters_6_6 = string_to_symbol("CHAR-CI<=?");
symbol1465___r4_characters_6_6 = string_to_symbol("_CHAR-CI<=?1181");
symbol1466___r4_characters_6_6 = string_to_symbol("CHAR-CI>=?");
symbol1467___r4_characters_6_6 = string_to_symbol("_CHAR-CI>=?1182");
symbol1468___r4_characters_6_6 = string_to_symbol("CHAR-ALPHABETIC?");
symbol1469___r4_characters_6_6 = string_to_symbol("_CHAR-ALPHABETIC?1183");
symbol1470___r4_characters_6_6 = string_to_symbol("CHAR-NUMERIC?");
symbol1471___r4_characters_6_6 = string_to_symbol("_CHAR-NUMERIC?1184");
symbol1472___r4_characters_6_6 = string_to_symbol("CHAR-WHITESPACE?");
symbol1473___r4_characters_6_6 = string_to_symbol("_CHAR-WHITESPACE?1185");
symbol1474___r4_characters_6_6 = string_to_symbol("CHAR-UPPER-CASE?");
symbol1475___r4_characters_6_6 = string_to_symbol("_CHAR-UPPER-CASE?1186");
symbol1476___r4_characters_6_6 = string_to_symbol("CHAR-LOWER-CASE?");
symbol1477___r4_characters_6_6 = string_to_symbol("_CHAR-LOWER-CASE?1187");
symbol1478___r4_characters_6_6 = string_to_symbol("CHAR->INTEGER");
symbol1479___r4_characters_6_6 = string_to_symbol("_CHAR->INTEGER1188");
symbol1480___r4_characters_6_6 = string_to_symbol("INTEGER->CHAR");
symbol1484___r4_characters_6_6 = string_to_symbol("_INTEGER->CHAR1189");
symbol1486___r4_characters_6_6 = string_to_symbol("INTEGER->CHAR-UR");
symbol1487___r4_characters_6_6 = string_to_symbol("_INTEGER->CHAR-UR1190");
symbol1488___r4_characters_6_6 = string_to_symbol("CHAR-UPCASE");
symbol1489___r4_characters_6_6 = string_to_symbol("_CHAR-UPCASE1191");
symbol1490___r4_characters_6_6 = string_to_symbol("CHAR-DOWNCASE");
symbol1491___r4_characters_6_6 = string_to_symbol("_CHAR-DOWNCASE1192");
symbol1492___r4_characters_6_6 = string_to_symbol("CHAR-OR");
symbol1493___r4_characters_6_6 = string_to_symbol("_CHAR-OR1193");
return (symbol1494___r4_characters_6_6 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* char? */bool_t char__59___r4_characters_6_6(obj_t obj_1)
{
{
obj_t symbol1128_692;
symbol1128_692 = symbol1445___r4_characters_6_6;
{
PUSH_TRACE(symbol1128_692);
BUNSPEC;
{
bool_t aux1127_693;
aux1127_693 = CHARP(obj_1);
POP_TRACE();
return aux1127_693;
}
}
}
}


/* _char? */obj_t _char__134___r4_characters_6_6(obj_t env_439, obj_t obj_440)
{
{
bool_t aux_870;
{
obj_t obj_694;
obj_694 = obj_440;
{
obj_t symbol1128_695;
symbol1128_695 = symbol1445___r4_characters_6_6;
{
PUSH_TRACE(symbol1128_695);
BUNSPEC;
{
bool_t aux1127_696;
aux1127_696 = CHARP(obj_694);
POP_TRACE();
aux_870 = aux1127_696;
}
}
}
}
return BBOOL(aux_870);
}
}


/* char=? */bool_t char___215___r4_characters_6_6(unsigned char char1_2, unsigned char char2_3)
{
{
obj_t symbol1130_697;
symbol1130_697 = symbol1446___r4_characters_6_6;
{
PUSH_TRACE(symbol1130_697);
BUNSPEC;
{
bool_t aux1129_698;
aux1129_698 = (char1_2==char2_3);
POP_TRACE();
return aux1129_698;
}
}
}
}


/* _char=?1173 */obj_t _char__1173_33___r4_characters_6_6(obj_t env_441, obj_t char1_442, obj_t char2_443)
{
{
bool_t aux_878;
{
unsigned char char1_699;
unsigned char char2_700;
{
obj_t aux_879;
if(CHARP(char1_442)){
aux_879 = char1_442;
}
 else {
bigloo_type_error_location_103___error(symbol1447___r4_characters_6_6, string1448___r4_characters_6_6, char1_442, string1449___r4_characters_6_6, BINT(((long)5057)));
exit( -1 );}
char1_699 = (unsigned char)CCHAR(aux_879);
}
{
obj_t aux_886;
if(CHARP(char2_443)){
aux_886 = char2_443;
}
 else {
bigloo_type_error_location_103___error(symbol1447___r4_characters_6_6, string1448___r4_characters_6_6, char2_443, string1449___r4_characters_6_6, BINT(((long)5057)));
exit( -1 );}
char2_700 = (unsigned char)CCHAR(aux_886);
}
{
obj_t symbol1130_701;
symbol1130_701 = symbol1446___r4_characters_6_6;
{
PUSH_TRACE(symbol1130_701);
BUNSPEC;
{
bool_t aux1129_702;
aux1129_702 = (char1_699==char2_700);
POP_TRACE();
aux_878 = aux1129_702;
}
}
}
}
return BBOOL(aux_878);
}
}


/* char<? */bool_t char___13___r4_characters_6_6(unsigned char char1_4, unsigned char char2_5)
{
{
obj_t symbol1132_703;
symbol1132_703 = symbol1450___r4_characters_6_6;
{
PUSH_TRACE(symbol1132_703);
BUNSPEC;
{
bool_t aux1131_704;
aux1131_704 = (char1_4<char2_5);
POP_TRACE();
return aux1131_704;
}
}
}
}


/* _char<?1174 */obj_t _char__1174_255___r4_characters_6_6(obj_t env_444, obj_t char1_445, obj_t char2_446)
{
{
bool_t aux_900;
{
unsigned char char1_705;
unsigned char char2_706;
{
obj_t aux_901;
if(CHARP(char1_445)){
aux_901 = char1_445;
}
 else {
bigloo_type_error_location_103___error(symbol1451___r4_characters_6_6, string1448___r4_characters_6_6, char1_445, string1449___r4_characters_6_6, BINT(((long)5343)));
exit( -1 );}
char1_705 = (unsigned char)CCHAR(aux_901);
}
{
obj_t aux_908;
if(CHARP(char2_446)){
aux_908 = char2_446;
}
 else {
bigloo_type_error_location_103___error(symbol1451___r4_characters_6_6, string1448___r4_characters_6_6, char2_446, string1449___r4_characters_6_6, BINT(((long)5343)));
exit( -1 );}
char2_706 = (unsigned char)CCHAR(aux_908);
}
{
obj_t symbol1132_707;
symbol1132_707 = symbol1450___r4_characters_6_6;
{
PUSH_TRACE(symbol1132_707);
BUNSPEC;
{
bool_t aux1131_708;
aux1131_708 = (char1_705<char2_706);
POP_TRACE();
aux_900 = aux1131_708;
}
}
}
}
return BBOOL(aux_900);
}
}


/* char>? */bool_t char___195___r4_characters_6_6(unsigned char char1_6, unsigned char char2_7)
{
{
obj_t symbol1134_709;
symbol1134_709 = symbol1452___r4_characters_6_6;
{
PUSH_TRACE(symbol1134_709);
BUNSPEC;
{
bool_t aux1133_710;
aux1133_710 = (char1_6>char2_7);
POP_TRACE();
return aux1133_710;
}
}
}
}


/* _char>?1175 */obj_t _char__1175_177___r4_characters_6_6(obj_t env_447, obj_t char1_448, obj_t char2_449)
{
{
bool_t aux_922;
{
unsigned char char1_711;
unsigned char char2_712;
{
obj_t aux_923;
if(CHARP(char1_448)){
aux_923 = char1_448;
}
 else {
bigloo_type_error_location_103___error(symbol1453___r4_characters_6_6, string1448___r4_characters_6_6, char1_448, string1449___r4_characters_6_6, BINT(((long)5629)));
exit( -1 );}
char1_711 = (unsigned char)CCHAR(aux_923);
}
{
obj_t aux_930;
if(CHARP(char2_449)){
aux_930 = char2_449;
}
 else {
bigloo_type_error_location_103___error(symbol1453___r4_characters_6_6, string1448___r4_characters_6_6, char2_449, string1449___r4_characters_6_6, BINT(((long)5629)));
exit( -1 );}
char2_712 = (unsigned char)CCHAR(aux_930);
}
{
obj_t symbol1134_713;
symbol1134_713 = symbol1452___r4_characters_6_6;
{
PUSH_TRACE(symbol1134_713);
BUNSPEC;
{
bool_t aux1133_714;
aux1133_714 = (char1_711>char2_712);
POP_TRACE();
aux_922 = aux1133_714;
}
}
}
}
return BBOOL(aux_922);
}
}


/* char<=? */bool_t char____152___r4_characters_6_6(unsigned char char1_8, unsigned char char2_9)
{
{
obj_t symbol1136_715;
symbol1136_715 = symbol1454___r4_characters_6_6;
{
PUSH_TRACE(symbol1136_715);
BUNSPEC;
{
bool_t aux1135_716;
aux1135_716 = (char1_8<=char2_9);
POP_TRACE();
return aux1135_716;
}
}
}
}


/* _char<=?1176 */obj_t _char___1176_50___r4_characters_6_6(obj_t env_450, obj_t char1_451, obj_t char2_452)
{
{
bool_t aux_944;
{
unsigned char char1_717;
unsigned char char2_718;
{
obj_t aux_945;
if(CHARP(char1_451)){
aux_945 = char1_451;
}
 else {
bigloo_type_error_location_103___error(symbol1455___r4_characters_6_6, string1448___r4_characters_6_6, char1_451, string1449___r4_characters_6_6, BINT(((long)5916)));
exit( -1 );}
char1_717 = (unsigned char)CCHAR(aux_945);
}
{
obj_t aux_952;
if(CHARP(char2_452)){
aux_952 = char2_452;
}
 else {
bigloo_type_error_location_103___error(symbol1455___r4_characters_6_6, string1448___r4_characters_6_6, char2_452, string1449___r4_characters_6_6, BINT(((long)5916)));
exit( -1 );}
char2_718 = (unsigned char)CCHAR(aux_952);
}
{
obj_t symbol1136_719;
symbol1136_719 = symbol1454___r4_characters_6_6;
{
PUSH_TRACE(symbol1136_719);
BUNSPEC;
{
bool_t aux1135_720;
aux1135_720 = (char1_717<=char2_718);
POP_TRACE();
aux_944 = aux1135_720;
}
}
}
}
return BBOOL(aux_944);
}
}


/* char>=? */bool_t char____252___r4_characters_6_6(unsigned char char1_10, unsigned char char2_11)
{
{
obj_t symbol1138_721;
symbol1138_721 = symbol1456___r4_characters_6_6;
{
PUSH_TRACE(symbol1138_721);
BUNSPEC;
{
bool_t aux1137_722;
aux1137_722 = (char1_10>=char2_11);
POP_TRACE();
return aux1137_722;
}
}
}
}


/* _char>=?1177 */obj_t _char___1177_12___r4_characters_6_6(obj_t env_453, obj_t char1_454, obj_t char2_455)
{
{
bool_t aux_966;
{
unsigned char char1_723;
unsigned char char2_724;
{
obj_t aux_967;
if(CHARP(char1_454)){
aux_967 = char1_454;
}
 else {
bigloo_type_error_location_103___error(symbol1457___r4_characters_6_6, string1448___r4_characters_6_6, char1_454, string1449___r4_characters_6_6, BINT(((long)6204)));
exit( -1 );}
char1_723 = (unsigned char)CCHAR(aux_967);
}
{
obj_t aux_974;
if(CHARP(char2_455)){
aux_974 = char2_455;
}
 else {
bigloo_type_error_location_103___error(symbol1457___r4_characters_6_6, string1448___r4_characters_6_6, char2_455, string1449___r4_characters_6_6, BINT(((long)6204)));
exit( -1 );}
char2_724 = (unsigned char)CCHAR(aux_974);
}
{
obj_t symbol1138_725;
symbol1138_725 = symbol1456___r4_characters_6_6;
{
PUSH_TRACE(symbol1138_725);
BUNSPEC;
{
bool_t aux1137_726;
aux1137_726 = (char1_723>=char2_724);
POP_TRACE();
aux_966 = aux1137_726;
}
}
}
}
return BBOOL(aux_966);
}
}


/* char-ci=? */bool_t char_ci___242___r4_characters_6_6(unsigned char char1_12, unsigned char char2_13)
{
{
obj_t symbol1140_727;
symbol1140_727 = symbol1458___r4_characters_6_6;
{
PUSH_TRACE(symbol1140_727);
BUNSPEC;
{
bool_t aux1139_728;
{
unsigned char aux_988;
unsigned char aux_986;
aux_988 = toupper(char2_13);
aux_986 = toupper(char1_12);
aux1139_728 = (aux_986==aux_988);
}
POP_TRACE();
return aux1139_728;
}
}
}
}


/* _char-ci=?1178 */obj_t _char_ci__1178_185___r4_characters_6_6(obj_t env_456, obj_t char1_457, obj_t char2_458)
{
{
bool_t aux_992;
{
unsigned char char1_729;
unsigned char char2_730;
{
obj_t aux_993;
if(CHARP(char1_457)){
aux_993 = char1_457;
}
 else {
bigloo_type_error_location_103___error(symbol1459___r4_characters_6_6, string1448___r4_characters_6_6, char1_457, string1449___r4_characters_6_6, BINT(((long)6492)));
exit( -1 );}
char1_729 = (unsigned char)CCHAR(aux_993);
}
{
obj_t aux_1000;
if(CHARP(char2_458)){
aux_1000 = char2_458;
}
 else {
bigloo_type_error_location_103___error(symbol1459___r4_characters_6_6, string1448___r4_characters_6_6, char2_458, string1449___r4_characters_6_6, BINT(((long)6492)));
exit( -1 );}
char2_730 = (unsigned char)CCHAR(aux_1000);
}
{
obj_t symbol1140_731;
symbol1140_731 = symbol1458___r4_characters_6_6;
{
PUSH_TRACE(symbol1140_731);
BUNSPEC;
{
bool_t aux1139_732;
{
unsigned char aux_1010;
unsigned char aux_1008;
aux_1010 = toupper(char2_730);
aux_1008 = toupper(char1_729);
aux1139_732 = (aux_1008==aux_1010);
}
POP_TRACE();
aux_992 = aux1139_732;
}
}
}
}
return BBOOL(aux_992);
}
}


/* char-ci<? */bool_t char_ci___112___r4_characters_6_6(unsigned char char1_14, unsigned char char2_15)
{
{
obj_t symbol1142_733;
symbol1142_733 = symbol1460___r4_characters_6_6;
{
PUSH_TRACE(symbol1142_733);
BUNSPEC;
{
bool_t aux1141_734;
{
unsigned char aux_1018;
unsigned char aux_1016;
aux_1018 = toupper(char2_15);
aux_1016 = toupper(char1_14);
aux1141_734 = (aux_1016<aux_1018);
}
POP_TRACE();
return aux1141_734;
}
}
}
}


/* _char-ci<?1179 */obj_t _char_ci__1179_147___r4_characters_6_6(obj_t env_459, obj_t char1_460, obj_t char2_461)
{
{
bool_t aux_1022;
{
unsigned char char1_735;
unsigned char char2_736;
{
obj_t aux_1023;
if(CHARP(char1_460)){
aux_1023 = char1_460;
}
 else {
bigloo_type_error_location_103___error(symbol1461___r4_characters_6_6, string1448___r4_characters_6_6, char1_460, string1449___r4_characters_6_6, BINT(((long)6807)));
exit( -1 );}
char1_735 = (unsigned char)CCHAR(aux_1023);
}
{
obj_t aux_1030;
if(CHARP(char2_461)){
aux_1030 = char2_461;
}
 else {
bigloo_type_error_location_103___error(symbol1461___r4_characters_6_6, string1448___r4_characters_6_6, char2_461, string1449___r4_characters_6_6, BINT(((long)6807)));
exit( -1 );}
char2_736 = (unsigned char)CCHAR(aux_1030);
}
{
obj_t symbol1142_737;
symbol1142_737 = symbol1460___r4_characters_6_6;
{
PUSH_TRACE(symbol1142_737);
BUNSPEC;
{
bool_t aux1141_738;
{
unsigned char aux_1040;
unsigned char aux_1038;
aux_1040 = toupper(char2_736);
aux_1038 = toupper(char1_735);
aux1141_738 = (aux_1038<aux_1040);
}
POP_TRACE();
aux_1022 = aux1141_738;
}
}
}
}
return BBOOL(aux_1022);
}
}


/* char-ci>? */bool_t char_ci___21___r4_characters_6_6(unsigned char char1_16, unsigned char char2_17)
{
{
obj_t symbol1144_739;
symbol1144_739 = symbol1462___r4_characters_6_6;
{
PUSH_TRACE(symbol1144_739);
BUNSPEC;
{
bool_t aux1143_740;
{
unsigned char aux_1048;
unsigned char aux_1046;
aux_1048 = toupper(char2_17);
aux_1046 = toupper(char1_16);
aux1143_740 = (aux_1046>aux_1048);
}
POP_TRACE();
return aux1143_740;
}
}
}
}


/* _char-ci>?1180 */obj_t _char_ci__1180_102___r4_characters_6_6(obj_t env_462, obj_t char1_463, obj_t char2_464)
{
{
bool_t aux_1052;
{
unsigned char char1_741;
unsigned char char2_742;
{
obj_t aux_1053;
if(CHARP(char1_463)){
aux_1053 = char1_463;
}
 else {
bigloo_type_error_location_103___error(symbol1463___r4_characters_6_6, string1448___r4_characters_6_6, char1_463, string1449___r4_characters_6_6, BINT(((long)7125)));
exit( -1 );}
char1_741 = (unsigned char)CCHAR(aux_1053);
}
{
obj_t aux_1060;
if(CHARP(char2_464)){
aux_1060 = char2_464;
}
 else {
bigloo_type_error_location_103___error(symbol1463___r4_characters_6_6, string1448___r4_characters_6_6, char2_464, string1449___r4_characters_6_6, BINT(((long)7125)));
exit( -1 );}
char2_742 = (unsigned char)CCHAR(aux_1060);
}
{
obj_t symbol1144_743;
symbol1144_743 = symbol1462___r4_characters_6_6;
{
PUSH_TRACE(symbol1144_743);
BUNSPEC;
{
bool_t aux1143_744;
{
unsigned char aux_1070;
unsigned char aux_1068;
aux_1070 = toupper(char2_742);
aux_1068 = toupper(char1_741);
aux1143_744 = (aux_1068>aux_1070);
}
POP_TRACE();
aux_1052 = aux1143_744;
}
}
}
}
return BBOOL(aux_1052);
}
}


/* char-ci<=? */bool_t char_ci____192___r4_characters_6_6(unsigned char char1_18, unsigned char char2_19)
{
{
obj_t symbol1146_745;
symbol1146_745 = symbol1464___r4_characters_6_6;
{
PUSH_TRACE(symbol1146_745);
BUNSPEC;
{
bool_t aux1145_746;
{
unsigned char aux_1078;
unsigned char aux_1076;
aux_1078 = toupper(char2_19);
aux_1076 = toupper(char1_18);
aux1145_746 = (aux_1076<=aux_1078);
}
POP_TRACE();
return aux1145_746;
}
}
}
}


/* _char-ci<=?1181 */obj_t _char_ci___1181_226___r4_characters_6_6(obj_t env_465, obj_t char1_466, obj_t char2_467)
{
{
bool_t aux_1082;
{
unsigned char char1_747;
unsigned char char2_748;
{
obj_t aux_1083;
if(CHARP(char1_466)){
aux_1083 = char1_466;
}
 else {
bigloo_type_error_location_103___error(symbol1465___r4_characters_6_6, string1448___r4_characters_6_6, char1_466, string1449___r4_characters_6_6, BINT(((long)7443)));
exit( -1 );}
char1_747 = (unsigned char)CCHAR(aux_1083);
}
{
obj_t aux_1090;
if(CHARP(char2_467)){
aux_1090 = char2_467;
}
 else {
bigloo_type_error_location_103___error(symbol1465___r4_characters_6_6, string1448___r4_characters_6_6, char2_467, string1449___r4_characters_6_6, BINT(((long)7443)));
exit( -1 );}
char2_748 = (unsigned char)CCHAR(aux_1090);
}
{
obj_t symbol1146_749;
symbol1146_749 = symbol1464___r4_characters_6_6;
{
PUSH_TRACE(symbol1146_749);
BUNSPEC;
{
bool_t aux1145_750;
{
unsigned char aux_1100;
unsigned char aux_1098;
aux_1100 = toupper(char2_748);
aux_1098 = toupper(char1_747);
aux1145_750 = (aux_1098<=aux_1100);
}
POP_TRACE();
aux_1082 = aux1145_750;
}
}
}
}
return BBOOL(aux_1082);
}
}


/* char-ci>=? */bool_t char_ci____41___r4_characters_6_6(unsigned char char1_20, unsigned char char2_21)
{
{
obj_t symbol1148_751;
symbol1148_751 = symbol1466___r4_characters_6_6;
{
PUSH_TRACE(symbol1148_751);
BUNSPEC;
{
bool_t aux1147_752;
{
unsigned char aux_1108;
unsigned char aux_1106;
aux_1108 = toupper(char2_21);
aux_1106 = toupper(char1_20);
aux1147_752 = (aux_1106>=aux_1108);
}
POP_TRACE();
return aux1147_752;
}
}
}
}


/* _char-ci>=?1182 */obj_t _char_ci___1182_91___r4_characters_6_6(obj_t env_468, obj_t char1_469, obj_t char2_470)
{
{
bool_t aux_1112;
{
unsigned char char1_753;
unsigned char char2_754;
{
obj_t aux_1113;
if(CHARP(char1_469)){
aux_1113 = char1_469;
}
 else {
bigloo_type_error_location_103___error(symbol1467___r4_characters_6_6, string1448___r4_characters_6_6, char1_469, string1449___r4_characters_6_6, BINT(((long)7762)));
exit( -1 );}
char1_753 = (unsigned char)CCHAR(aux_1113);
}
{
obj_t aux_1120;
if(CHARP(char2_470)){
aux_1120 = char2_470;
}
 else {
bigloo_type_error_location_103___error(symbol1467___r4_characters_6_6, string1448___r4_characters_6_6, char2_470, string1449___r4_characters_6_6, BINT(((long)7762)));
exit( -1 );}
char2_754 = (unsigned char)CCHAR(aux_1120);
}
{
obj_t symbol1148_755;
symbol1148_755 = symbol1466___r4_characters_6_6;
{
PUSH_TRACE(symbol1148_755);
BUNSPEC;
{
bool_t aux1147_756;
{
unsigned char aux_1130;
unsigned char aux_1128;
aux_1130 = toupper(char2_754);
aux_1128 = toupper(char1_753);
aux1147_756 = (aux_1128>=aux_1130);
}
POP_TRACE();
aux_1112 = aux1147_756;
}
}
}
}
return BBOOL(aux_1112);
}
}


/* char-alphabetic? */bool_t char_alphabetic__208___r4_characters_6_6(unsigned char char_22)
{
{
obj_t symbol1150_757;
symbol1150_757 = symbol1468___r4_characters_6_6;
{
PUSH_TRACE(symbol1150_757);
BUNSPEC;
{
bool_t aux1149_758;
{
unsigned char c_759;
c_759 = toupper(char_22);
if((c_759>=((unsigned char)'A'))){
aux1149_758 = (c_759<=((unsigned char)'Z'));
}
 else {
aux1149_758 = ((bool_t)0);
}
}
POP_TRACE();
return aux1149_758;
}
}
}
}


/* _char-alphabetic?1183 */obj_t _char_alphabetic_1183_115___r4_characters_6_6(obj_t env_471, obj_t char_472)
{
{
bool_t aux_1141;
{
unsigned char char_166_760;
{
obj_t aux_1142;
if(CHARP(char_472)){
aux_1142 = char_472;
}
 else {
bigloo_type_error_location_103___error(symbol1469___r4_characters_6_6, string1448___r4_characters_6_6, char_472, string1449___r4_characters_6_6, BINT(((long)8081)));
exit( -1 );}
char_166_760 = (unsigned char)CCHAR(aux_1142);
}
{
obj_t symbol1150_761;
symbol1150_761 = symbol1468___r4_characters_6_6;
{
PUSH_TRACE(symbol1150_761);
BUNSPEC;
{
bool_t aux1149_762;
{
unsigned char c_763;
c_763 = toupper(char_166_760);
if((c_763>=((unsigned char)'A'))){
aux1149_762 = (c_763<=((unsigned char)'Z'));
}
 else {
aux1149_762 = ((bool_t)0);
}
}
POP_TRACE();
aux_1141 = aux1149_762;
}
}
}
}
return BBOOL(aux_1141);
}
}


/* char-numeric? */bool_t char_numeric__32___r4_characters_6_6(unsigned char char_23)
{
{
obj_t symbol1152_764;
symbol1152_764 = symbol1470___r4_characters_6_6;
{
PUSH_TRACE(symbol1152_764);
BUNSPEC;
{
bool_t aux1151_765;
if((char_23>=((unsigned char)'0'))){
aux1151_765 = (char_23<=((unsigned char)'9'));
}
 else {
aux1151_765 = ((bool_t)0);
}
POP_TRACE();
return aux1151_765;
}
}
}
}


/* _char-numeric?1184 */obj_t _char_numeric_1184_30___r4_characters_6_6(obj_t env_473, obj_t char_474)
{
{
bool_t aux_1161;
{
unsigned char char_166_766;
{
obj_t aux_1162;
if(CHARP(char_474)){
aux_1162 = char_474;
}
 else {
bigloo_type_error_location_103___error(symbol1471___r4_characters_6_6, string1448___r4_characters_6_6, char_474, string1449___r4_characters_6_6, BINT(((long)8430)));
exit( -1 );}
char_166_766 = (unsigned char)CCHAR(aux_1162);
}
{
obj_t symbol1152_767;
symbol1152_767 = symbol1470___r4_characters_6_6;
{
PUSH_TRACE(symbol1152_767);
BUNSPEC;
{
bool_t aux1151_768;
if((char_166_766>=((unsigned char)'0'))){
aux1151_768 = (char_166_766<=((unsigned char)'9'));
}
 else {
aux1151_768 = ((bool_t)0);
}
POP_TRACE();
aux_1161 = aux1151_768;
}
}
}
}
return BBOOL(aux_1161);
}
}


/* char-whitespace? */bool_t char_whitespace__92___r4_characters_6_6(unsigned char char_24)
{
{
obj_t symbol1154_769;
symbol1154_769 = symbol1472___r4_characters_6_6;
{
PUSH_TRACE(symbol1154_769);
BUNSPEC;
{
bool_t aux1153_770;
{
bool_t _ortest_1002_771;
_ortest_1002_771 = (char_24==((unsigned char)' '));
if(_ortest_1002_771){
aux1153_770 = _ortest_1002_771;
}
 else {
bool_t _ortest_1003_772;
_ortest_1003_772 = (char_24==((unsigned char)'\t'));
if(_ortest_1003_772){
aux1153_770 = _ortest_1003_772;
}
 else {
bool_t _ortest_1004_773;
_ortest_1004_773 = (char_24==((unsigned char)'\r'));
if(_ortest_1004_773){
aux1153_770 = _ortest_1004_773;
}
 else {
aux1153_770 = (char_24==((unsigned char)'\n'));
}
}
}
}
POP_TRACE();
return aux1153_770;
}
}
}
}


/* _char-whitespace?1185 */obj_t _char_whitespace_1185_254___r4_characters_6_6(obj_t env_475, obj_t char_476)
{
{
bool_t aux_1184;
{
unsigned char char_166_774;
{
obj_t aux_1185;
if(CHARP(char_476)){
aux_1185 = char_476;
}
 else {
bigloo_type_error_location_103___error(symbol1473___r4_characters_6_6, string1448___r4_characters_6_6, char_476, string1449___r4_characters_6_6, BINT(((long)8753)));
exit( -1 );}
char_166_774 = (unsigned char)CCHAR(aux_1185);
}
{
obj_t symbol1154_775;
symbol1154_775 = symbol1472___r4_characters_6_6;
{
PUSH_TRACE(symbol1154_775);
BUNSPEC;
{
bool_t aux1153_776;
{
bool_t _ortest_1002_777;
_ortest_1002_777 = (char_166_774==((unsigned char)' '));
if(_ortest_1002_777){
aux1153_776 = _ortest_1002_777;
}
 else {
bool_t _ortest_1003_778;
_ortest_1003_778 = (char_166_774==((unsigned char)'\t'));
if(_ortest_1003_778){
aux1153_776 = _ortest_1003_778;
}
 else {
bool_t _ortest_1004_779;
_ortest_1004_779 = (char_166_774==((unsigned char)'\r'));
if(_ortest_1004_779){
aux1153_776 = _ortest_1004_779;
}
 else {
aux1153_776 = (char_166_774==((unsigned char)'\n'));
}
}
}
}
POP_TRACE();
aux_1184 = aux1153_776;
}
}
}
}
return BBOOL(aux_1184);
}
}


/* char-upper-case? */bool_t char_upper_case__12___r4_characters_6_6(unsigned char char_25)
{
{
obj_t symbol1156_780;
symbol1156_780 = symbol1474___r4_characters_6_6;
{
PUSH_TRACE(symbol1156_780);
BUNSPEC;
{
bool_t aux1155_781;
if((char_25>=((unsigned char)'A'))){
aux1155_781 = (char_25<=((unsigned char)'Z'));
}
 else {
aux1155_781 = ((bool_t)0);
}
POP_TRACE();
return aux1155_781;
}
}
}
}


/* _char-upper-case?1186 */obj_t _char_upper_case_1186_83___r4_characters_6_6(obj_t env_477, obj_t char_478)
{
{
bool_t aux_1207;
{
unsigned char char_166_782;
{
obj_t aux_1208;
if(CHARP(char_478)){
aux_1208 = char_478;
}
 else {
bigloo_type_error_location_103___error(symbol1475___r4_characters_6_6, string1448___r4_characters_6_6, char_478, string1449___r4_characters_6_6, BINT(((long)9134)));
exit( -1 );}
char_166_782 = (unsigned char)CCHAR(aux_1208);
}
{
obj_t symbol1156_783;
symbol1156_783 = symbol1474___r4_characters_6_6;
{
PUSH_TRACE(symbol1156_783);
BUNSPEC;
{
bool_t aux1155_784;
if((char_166_782>=((unsigned char)'A'))){
aux1155_784 = (char_166_782<=((unsigned char)'Z'));
}
 else {
aux1155_784 = ((bool_t)0);
}
POP_TRACE();
aux_1207 = aux1155_784;
}
}
}
}
return BBOOL(aux_1207);
}
}


/* char-lower-case? */bool_t char_lower_case__222___r4_characters_6_6(unsigned char char_26)
{
{
obj_t symbol1158_785;
symbol1158_785 = symbol1476___r4_characters_6_6;
{
PUSH_TRACE(symbol1158_785);
BUNSPEC;
{
bool_t aux1157_786;
if((char_26>=((unsigned char)'a'))){
aux1157_786 = (char_26<=((unsigned char)'z'));
}
 else {
aux1157_786 = ((bool_t)0);
}
POP_TRACE();
return aux1157_786;
}
}
}
}


/* _char-lower-case?1187 */obj_t _char_lower_case_1187_156___r4_characters_6_6(obj_t env_479, obj_t char_480)
{
{
bool_t aux_1226;
{
unsigned char char_166_787;
{
obj_t aux_1227;
if(CHARP(char_480)){
aux_1227 = char_480;
}
 else {
bigloo_type_error_location_103___error(symbol1477___r4_characters_6_6, string1448___r4_characters_6_6, char_480, string1449___r4_characters_6_6, BINT(((long)9460)));
exit( -1 );}
char_166_787 = (unsigned char)CCHAR(aux_1227);
}
{
obj_t symbol1158_788;
symbol1158_788 = symbol1476___r4_characters_6_6;
{
PUSH_TRACE(symbol1158_788);
BUNSPEC;
{
bool_t aux1157_789;
if((char_166_787>=((unsigned char)'a'))){
aux1157_789 = (char_166_787<=((unsigned char)'z'));
}
 else {
aux1157_789 = ((bool_t)0);
}
POP_TRACE();
aux_1226 = aux1157_789;
}
}
}
}
return BBOOL(aux_1226);
}
}


/* char->integer */long char__integer_184___r4_characters_6_6(unsigned char char_27)
{
{
obj_t symbol1160_790;
symbol1160_790 = symbol1478___r4_characters_6_6;
{
PUSH_TRACE(symbol1160_790);
BUNSPEC;
{
long aux1159_791;
aux1159_791 = (char_27);
POP_TRACE();
return aux1159_791;
}
}
}
}


/* _char->integer1188 */obj_t _char__integer1188_179___r4_characters_6_6(obj_t env_481, obj_t char_482)
{
{
long aux_1243;
{
unsigned char char_166_792;
{
obj_t aux_1244;
if(CHARP(char_482)){
aux_1244 = char_482;
}
 else {
bigloo_type_error_location_103___error(symbol1479___r4_characters_6_6, string1448___r4_characters_6_6, char_482, string1449___r4_characters_6_6, BINT(((long)9786)));
exit( -1 );}
char_166_792 = (unsigned char)CCHAR(aux_1244);
}
{
obj_t symbol1160_793;
symbol1160_793 = symbol1478___r4_characters_6_6;
{
PUSH_TRACE(symbol1160_793);
BUNSPEC;
{
long aux1159_794;
aux1159_794 = (char_166_792);
POP_TRACE();
aux_1243 = aux1159_794;
}
}
}
}
return BINT(aux_1243);
}
}


/* integer->char */unsigned char integer__char_140___r4_characters_6_6(long int_28)
{
{
obj_t symbol1162_427;
symbol1162_427 = symbol1480___r4_characters_6_6;
{
PUSH_TRACE(symbol1162_427);
BUNSPEC;
{
unsigned char aux1161_428;
{
bool_t test_1256;
if((int_28>=((long)0))){
test_1256 = (int_28<=((long)255));
}
 else {
test_1256 = ((bool_t)0);
}
if(test_1256){
aux1161_428 = (int_28);
}
 else {
obj_t aux_1261;
{
obj_t aux1389_650;
aux1389_650 = debug_error_location_199___error(string1481___r4_characters_6_6, string1482___r4_characters_6_6, BINT(int_28), string1483___r4_characters_6_6, BINT(((long)7610)));
if(CHARP(aux1389_650)){
aux_1261 = aux1389_650;
}
 else {
bigloo_type_error_location_103___error(symbol1480___r4_characters_6_6, string1448___r4_characters_6_6, aux1389_650, string1483___r4_characters_6_6, BINT(((long)7610)));
exit( -1 );}
}
aux1161_428 = (unsigned char)CCHAR(aux_1261);
}
}
POP_TRACE();
return aux1161_428;
}
}
}
}


/* _integer->char1189 */obj_t _integer__char1189_110___r4_characters_6_6(obj_t env_483, obj_t int_484)
{
{
unsigned char aux_1272;
{
long aux_1273;
{
obj_t aux_1274;
if(INTEGERP(int_484)){
aux_1274 = int_484;
}
 else {
bigloo_type_error_location_103___error(symbol1484___r4_characters_6_6, string1485___r4_characters_6_6, int_484, string1449___r4_characters_6_6, BINT(((long)10072)));
exit( -1 );}
aux_1273 = (long)CINT(aux_1274);
}
aux_1272 = integer__char_140___r4_characters_6_6(aux_1273);
}
return BCHAR(aux_1272);
}
}


/* integer->char-ur */unsigned char integer__char_ur_23___r4_characters_6_6(long int_29)
{
{
obj_t symbol1164_795;
symbol1164_795 = symbol1486___r4_characters_6_6;
{
PUSH_TRACE(symbol1164_795);
BUNSPEC;
{
unsigned char aux1163_796;
aux1163_796 = (int_29);
POP_TRACE();
return aux1163_796;
}
}
}
}


/* _integer->char-ur1190 */obj_t _integer__char_ur1190_16___r4_characters_6_6(obj_t env_485, obj_t int_486)
{
{
unsigned char aux_1286;
{
long int_184_797;
{
obj_t aux_1287;
if(INTEGERP(int_486)){
aux_1287 = int_486;
}
 else {
bigloo_type_error_location_103___error(symbol1487___r4_characters_6_6, string1485___r4_characters_6_6, int_486, string1449___r4_characters_6_6, BINT(((long)10453)));
exit( -1 );}
int_184_797 = (long)CINT(aux_1287);
}
{
obj_t symbol1164_798;
symbol1164_798 = symbol1486___r4_characters_6_6;
{
PUSH_TRACE(symbol1164_798);
BUNSPEC;
{
unsigned char aux1163_799;
aux1163_799 = (int_184_797);
POP_TRACE();
aux_1286 = aux1163_799;
}
}
}
}
return BCHAR(aux_1286);
}
}


/* char-upcase */unsigned char char_upcase_134___r4_characters_6_6(unsigned char char_30)
{
{
obj_t symbol1166_800;
symbol1166_800 = symbol1488___r4_characters_6_6;
{
PUSH_TRACE(symbol1166_800);
BUNSPEC;
{
unsigned char aux1165_801;
aux1165_801 = toupper(char_30);
POP_TRACE();
return aux1165_801;
}
}
}
}


/* _char-upcase1191 */obj_t _char_upcase1191_99___r4_characters_6_6(obj_t env_487, obj_t char_488)
{
{
unsigned char aux_1301;
{
unsigned char char_166_802;
{
obj_t aux_1302;
if(CHARP(char_488)){
aux_1302 = char_488;
}
 else {
bigloo_type_error_location_103___error(symbol1489___r4_characters_6_6, string1448___r4_characters_6_6, char_488, string1449___r4_characters_6_6, BINT(((long)10740)));
exit( -1 );}
char_166_802 = (unsigned char)CCHAR(aux_1302);
}
{
obj_t symbol1166_803;
symbol1166_803 = symbol1488___r4_characters_6_6;
{
PUSH_TRACE(symbol1166_803);
BUNSPEC;
{
unsigned char aux1165_804;
aux1165_804 = toupper(char_166_802);
POP_TRACE();
aux_1301 = aux1165_804;
}
}
}
}
return BCHAR(aux_1301);
}
}


/* char-downcase */unsigned char char_downcase_76___r4_characters_6_6(unsigned char char_31)
{
{
obj_t symbol1168_805;
symbol1168_805 = symbol1490___r4_characters_6_6;
{
PUSH_TRACE(symbol1168_805);
BUNSPEC;
{
unsigned char aux1167_806;
aux1167_806 = tolower(char_31);
POP_TRACE();
return aux1167_806;
}
}
}
}


/* _char-downcase1192 */obj_t _char_downcase1192_24___r4_characters_6_6(obj_t env_489, obj_t char_490)
{
{
unsigned char aux_1316;
{
unsigned char char_166_807;
{
obj_t aux_1317;
if(CHARP(char_490)){
aux_1317 = char_490;
}
 else {
bigloo_type_error_location_103___error(symbol1491___r4_characters_6_6, string1448___r4_characters_6_6, char_490, string1449___r4_characters_6_6, BINT(((long)11023)));
exit( -1 );}
char_166_807 = (unsigned char)CCHAR(aux_1317);
}
{
obj_t symbol1168_808;
symbol1168_808 = symbol1490___r4_characters_6_6;
{
PUSH_TRACE(symbol1168_808);
BUNSPEC;
{
unsigned char aux1167_809;
aux1167_809 = tolower(char_166_807);
POP_TRACE();
aux_1316 = aux1167_809;
}
}
}
}
return BCHAR(aux_1316);
}
}


/* char-or */unsigned char char_or_106___r4_characters_6_6(unsigned char char1_32, unsigned char char2_33)
{
{
obj_t symbol1170_810;
symbol1170_810 = symbol1492___r4_characters_6_6;
{
PUSH_TRACE(symbol1170_810);
BUNSPEC;
{
unsigned char aux1169_811;
aux1169_811 = (char1_32|char2_33);
POP_TRACE();
return aux1169_811;
}
}
}
}


/* _char-or1193 */obj_t _char_or1193_37___r4_characters_6_6(obj_t env_491, obj_t char1_492, obj_t char2_493)
{
{
unsigned char aux_1331;
{
unsigned char char1_812;
unsigned char char2_813;
{
obj_t aux_1332;
if(CHARP(char1_492)){
aux_1332 = char1_492;
}
 else {
bigloo_type_error_location_103___error(symbol1493___r4_characters_6_6, string1448___r4_characters_6_6, char1_492, string1449___r4_characters_6_6, BINT(((long)11317)));
exit( -1 );}
char1_812 = (unsigned char)CCHAR(aux_1332);
}
{
obj_t aux_1339;
if(CHARP(char2_493)){
aux_1339 = char2_493;
}
 else {
bigloo_type_error_location_103___error(symbol1493___r4_characters_6_6, string1448___r4_characters_6_6, char2_493, string1449___r4_characters_6_6, BINT(((long)11317)));
exit( -1 );}
char2_813 = (unsigned char)CCHAR(aux_1339);
}
{
obj_t symbol1170_814;
symbol1170_814 = symbol1492___r4_characters_6_6;
{
PUSH_TRACE(symbol1170_814);
BUNSPEC;
{
unsigned char aux1169_815;
aux1169_815 = (char1_812|char2_813);
POP_TRACE();
aux_1331 = aux1169_815;
}
}
}
}
return BCHAR(aux_1331);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_characters_6_6()
{
{
obj_t symbol1172_437;
symbol1172_437 = symbol1494___r4_characters_6_6;
{
PUSH_TRACE(symbol1172_437);
BUNSPEC;
{
obj_t aux1171_438;
aux1171_438 = module_initialization_70___error(((long)0), "__R4_CHARACTERS_6_6");
POP_TRACE();
return aux1171_438;
}
}
}
}

