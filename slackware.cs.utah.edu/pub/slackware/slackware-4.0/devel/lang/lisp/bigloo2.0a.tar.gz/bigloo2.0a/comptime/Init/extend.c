/*===========================================================================*/
/*   (Init/extend.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
static obj_t _load_extend1002_97_init_extend(obj_t, obj_t);
extern obj_t module_initialization_70_init_extend(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
static obj_t imported_modules_init_94_init_extend();
static obj_t library_modules_init_112_init_extend();
extern obj_t _lib_dir__34_engine_param;
extern obj_t load_extend_232_init_extend(obj_t);
extern obj_t loadq___eval(obj_t);
static obj_t require_initialization_114_init_extend = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(load_extend_env_96_init_extend, _load_extend1002_97_init_extend1006, _load_extend1002_97_init_extend, 0L, 1);
DEFINE_STRING(string1004_init_extend, string1004_init_extend1007, "Can't find extend file", 22);
DEFINE_STRING(string1003_init_extend, string1003_init_extend1008, "parse-args", 10);


/* module-initialization */ obj_t 
module_initialization_70_init_extend(long checksum_8, char *from_9)
{
   if (CBOOL(require_initialization_114_init_extend))
     {
	require_initialization_114_init_extend = BBOOL(((bool_t) 0));
	library_modules_init_112_init_extend();
	imported_modules_init_94_init_extend();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_init_extend()
{
   module_initialization_70___eval(((long) 0), "INIT_EXTEND");
   return BUNSPEC;
}


/* load-extend */ obj_t 
load_extend_232_init_extend(obj_t extend_name_205_1)
{
   {
      obj_t fname_2;
      fname_2 = find_file_path_55_tools_file(extend_name_205_1, _lib_dir__34_engine_param);
      if (CBOOL(fname_2))
	{
	   return loadq___eval(fname_2);
	}
      else
	{
	   FAILURE(string1003_init_extend, string1004_init_extend, extend_name_205_1);
	}
   }
}


/* _load-extend1002 */ obj_t 
_load_extend1002_97_init_extend(obj_t env_6, obj_t extend_name_205_7)
{
   return load_extend_232_init_extend(extend_name_205_7);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_init_extend()
{
   module_initialization_70_engine_param(((long) 0), "INIT_EXTEND");
   return module_initialization_70_tools_file(((long) 0), "INIT_EXTEND");
}
