/*===========================================================================*/
/*   (Tools/file.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern bool_t fexists(char *);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t library_modules_init_112_tools_file();
static obj_t _find_file_path1015_62_tools_file(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_tools_file = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(find_file_path_env_231_tools_file, _find_file_path1015_62_tools_file1018, _find_file_path1015_62_tools_file, 0L, 2);
DEFINE_STRING(string1016_tools_file, string1016_tools_file1019, "/", 1);


/* module-initialization */ obj_t 
module_initialization_70_tools_file(long checksum_24, char *from_25)
{
   if (CBOOL(require_initialization_114_tools_file))
     {
	require_initialization_114_tools_file = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_file();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_file()
{
   module_initialization_70___r4_strings_6_7(((long) 0), "TOOLS_FILE");
   return BUNSPEC;
}


/* find-file/path */ obj_t 
find_file_path_55_tools_file(obj_t name_1, obj_t path_2)
{
   {
      bool_t test1002_3;
      {
	 char *aux_31;
	 aux_31 = BSTRING_TO_STRING(name_1);
	 test1002_3 = fexists(aux_31);
      }
      if (test1002_3)
	{
	   return name_1;
	}
      else
	{
	   obj_t path_4;
	   path_4 = path_2;
	 loop_5:
	   if (NULLP(path_4))
	     {
		return BFALSE;
	     }
	   else
	     {
		obj_t fname_7;
		{
		   obj_t arg1006_10;
		   arg1006_10 = CAR(path_4);
		   {
		      obj_t list1008_12;
		      {
			 obj_t arg1009_13;
			 {
			    obj_t arg1011_14;
			    arg1011_14 = MAKE_PAIR(name_1, BNIL);
			    arg1009_13 = MAKE_PAIR(string1016_tools_file, arg1011_14);
			 }
			 list1008_12 = MAKE_PAIR(arg1006_10, arg1009_13);
		      }
		      fname_7 = string_append_106___r4_strings_6_7(list1008_12);
		   }
		}
		{
		   bool_t test1004_8;
		   {
		      char *aux_42;
		      aux_42 = BSTRING_TO_STRING(fname_7);
		      test1004_8 = fexists(aux_42);
		   }
		   if (test1004_8)
		     {
			return fname_7;
		     }
		   else
		     {
			obj_t path_46;
			path_46 = CDR(path_4);
			path_4 = path_46;
			goto loop_5;
		     }
		}
	     }
	}
   }
}


/* _find-file/path1015 */ obj_t 
_find_file_path1015_62_tools_file(obj_t env_21, obj_t name_22, obj_t path_23)
{
   return find_file_path_55_tools_file(name_22, path_23);
}
