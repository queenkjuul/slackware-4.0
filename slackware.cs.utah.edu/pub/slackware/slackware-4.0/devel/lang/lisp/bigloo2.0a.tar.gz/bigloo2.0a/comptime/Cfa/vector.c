/*===========================================================================*/
/*   (Cfa/vector.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct approx
  {
     header_t header;
     obj_t widening;
     struct type *type;
     bool_t type_locked__184;
     obj_t allocs;
     bool_t top__138;
     long lost_stamp_114;
  }
      *approx_t;

typedef struct cfun_cinfo_200
  {
     struct approx *approx;
  }
              *cfun_cinfo_200_t;

typedef struct extern_sfun_cinfo_6
  {
     struct approx *approx;
  }
                   *extern_sfun_cinfo_6_t;

typedef struct intern_sfun_cinfo_192
  {
     struct approx *approx;
     long stamp;
  }
                     *intern_sfun_cinfo_192_t;

typedef struct scnst_cinfo_0
  {
     struct approx *approx;
  }
             *scnst_cinfo_0_t;

typedef struct pre_clo_env_191
  {
     char dummy;
  }
               *pre_clo_env_191_t;

typedef struct svar_cinfo_166
  {
     struct approx *approx;
     bool_t clo_env__87;
  }
              *svar_cinfo_166_t;

typedef struct cvar_cinfo_53
  {
     struct approx *approx;
  }
             *cvar_cinfo_53_t;

typedef struct sexit_cinfo_49
  {
     struct approx *approx;
  }
              *sexit_cinfo_49_t;

typedef struct reshaped_local_224
  {
     obj_t binding_value_3;
  }
                  *reshaped_local_224_t;

typedef struct reshaped_global_160
  {
     char dummy;
  }
                   *reshaped_global_160_t;

typedef struct atom_cinfo_155
  {
     struct approx *approx;
  }
              *atom_cinfo_155_t;

typedef struct kwote_node_102
  {
     struct node *node;
  }
              *kwote_node_102_t;

typedef struct kwote_cinfo_48
  {
     struct approx *approx;
  }
              *kwote_cinfo_48_t;

typedef struct app_ly_cinfo_234
  {
     struct approx *approx;
  }
                *app_ly_cinfo_234_t;

typedef struct funcall_cinfo_75
  {
     struct approx *approx;
     struct approx *va_approx_63;
     bool_t arity_error_noticed__118;
     bool_t type_error_noticed__36;
  }
                *funcall_cinfo_75_t;

typedef struct pragma_cinfo_220
  {
     struct approx *approx;
  }
                *pragma_cinfo_220_t;

typedef struct setq_cinfo_191
  {
     struct approx *approx;
  }
              *setq_cinfo_191_t;

typedef struct conditional_cinfo_212
  {
     struct approx *approx;
  }
                     *conditional_cinfo_212_t;

typedef struct fail_cinfo_75
  {
     struct approx *approx;
  }
             *fail_cinfo_75_t;

typedef struct select_cinfo_150
  {
     struct approx *approx;
  }
                *select_cinfo_150_t;

typedef struct set_ex_it_cinfo_168
  {
     struct approx *approx;
  }
                   *set_ex_it_cinfo_168_t;

typedef struct jump_ex_it_cinfo_139
  {
     struct approx *approx;
  }
                    *jump_ex_it_cinfo_139_t;

typedef struct pre_make_box_186
  {
     char dummy;
  }
                *pre_make_box_186_t;

typedef struct make_box_cinfo_127
  {
     struct approx *approx;
  }
                  *make_box_cinfo_127_t;

typedef struct make_box_o_cinfo_96
  {
     struct approx *approx;
     struct approx *value_approx_19;
  }
                   *make_box_o_cinfo_96_t;

typedef struct box_set__cinfo_94
  {
     struct approx *approx;
  }
                 *box_set__cinfo_94_t;

typedef struct box_ref_cinfo_214
  {
     struct approx *approx;
  }
                 *box_ref_cinfo_214_t;

typedef struct box_set__o_cinfo_6
  {
     struct approx *approx;
  }
                  *box_set__o_cinfo_6_t;

typedef struct box_ref_o_cinfo_98
  {
     struct approx *approx;
  }
                  *box_ref_o_cinfo_98_t;

typedef struct pre_make_procedure_app_60
  {
     struct variable *owner;
  }
                         *pre_make_procedure_app_60_t;

typedef struct pre_procedure_ref_app_85
  {
     char dummy;
  }
                        *pre_procedure_ref_app_85_t;

typedef struct pre_procedure_set__app_208
  {
     char dummy;
  }
                          *pre_procedure_set__app_208_t;

typedef struct make_procedure_app_48
  {
     struct approx *approx;
     long values_approx_len_106;
     struct approx **values_approx_79;
     long lost_stamp_114;
     bool_t x_t__142;
     bool_t x;
     bool_t t;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                     *make_procedure_app_48_t;

typedef struct procedure_ref_app_49
  {
     struct approx *approx;
  }
                    *procedure_ref_app_49_t;

typedef struct procedure_set__app_32
  {
     struct approx *approx;
  }
                     *procedure_set__app_32_t;

typedef struct pre_make_vector_app_251
  {
     struct variable *owner;
  }
                       *pre_make_vector_app_251_t;

typedef struct pre_create_vector_app_162
  {
     struct variable *owner;
  }
                         *pre_create_vector_app_162_t;

typedef struct pre_vector_ref_app_208
  {
     char dummy;
  }
                      *pre_vector_ref_app_208_t;

typedef struct pre_vector_set__app_211
  {
     char dummy;
  }
                       *pre_vector_set__app_211_t;

typedef struct make_vector_app_205
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                   *make_vector_app_205_t;

typedef struct create_vector_app_150
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
     bool_t seen__39;
  }
                     *create_vector_app_150_t;

typedef struct vector_ref_app_195
  {
     struct approx *approx;
  }
                  *vector_ref_app_195_t;

typedef struct vector_set__app_21
  {
     struct approx *approx;
  }
                  *vector_set__app_21_t;

typedef struct pre_make_struct_app_218
  {
     struct variable *owner;
  }
                       *pre_make_struct_app_218_t;

typedef struct pre_struct_ref_app_207
  {
     char dummy;
  }
                      *pre_struct_ref_app_207_t;

typedef struct pre_struct_set__app_116
  {
     char dummy;
  }
                       *pre_struct_set__app_116_t;

typedef struct make_struct_app_214
  {
     struct approx *approx;
     struct approx *value_approx_19;
     long lost_stamp_114;
     struct variable *owner;
     bool_t stackable__42;
     obj_t stack_stamp_31;
  }
                   *make_struct_app_214_t;

typedef struct struct_ref_app_73
  {
     struct approx *approx;
  }
                 *struct_ref_app_73_t;

typedef struct struct_set__app_162
  {
     struct approx *approx;
  }
                   *struct_set__app_162_t;


static obj_t method_init_76_cfa_vector();
static obj_t cfa__make_vector_app_74_cfa_vector(obj_t, obj_t);
extern obj_t pre_create_vector_app_162_cfa_info;
static obj_t cfa__vector_set__app_153_cfa_vector(obj_t, obj_t);
static obj_t loose_alloc__create_vector_app_169_cfa_vector(obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t _obj__252_type_cache;
extern approx_t make_type_approx_184_cfa_approx(type_t);
extern approx_t make_empty_approx_131_cfa_approx();
extern obj_t vector_ref_app_195_cfa_info;
static obj_t stack__make_vector_app_190_cfa_vector(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_cfa_vector(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_cfa_info(long, char *);
extern obj_t module_initialization_70_cfa_loose(long, char *);
extern obj_t module_initialization_70_cfa_iterate(long, char *);
extern obj_t module_initialization_70_cfa_cfa(long, char *);
extern obj_t module_initialization_70_cfa_setup(long, char *);
extern obj_t module_initialization_70_cfa_approx(long, char *);
extern obj_t module_initialization_70_cfa_tvector(long, char *);
extern obj_t module_initialization_70_cfa_stack(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern approx_t union_approx__241_cfa_approx(approx_t, approx_t);
extern long class_num_218___object(obj_t);
static obj_t cfa__create_vector_app_163_cfa_vector(obj_t, obj_t);
extern obj_t node_setup___185_cfa_setup(obj_t);
extern obj_t pre_make_vector_app_251_cfa_info;
static obj_t _stack_loose_alloc_2541_207_cfa_loose(obj_t, obj_t, obj_t);
static obj_t _loose_alloc_2534_56_cfa_loose(obj_t, obj_t);
static obj_t imported_modules_init_94_cfa_vector();
extern obj_t stack_loose_alloc__95_cfa_loose(node_t, obj_t);
extern obj_t pre_vector_set__app_211_cfa_info;
extern obj_t stack___129_cfa_stack(obj_t);
static obj_t node_setup__pre_make_vector_app_233_cfa_vector(obj_t, obj_t);
extern obj_t approx_set_top__187_cfa_approx(approx_t);
static obj_t stack_loose_alloc__make_vector_app_80_cfa_vector(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_cfa_vector();
static obj_t stack_loose_alloc__create_vector_app_171_cfa_vector(obj_t, obj_t, obj_t);
extern obj_t make_vector_app_205_cfa_info;
extern approx_t cfa__102_cfa_cfa(node_t);
static obj_t _node_setup_2536_112_cfa_setup(obj_t, obj_t);
static obj_t node_setup__pre_vector_set__app_35_cfa_vector(obj_t, obj_t);
extern node_t node_heap__stack__239_cfa_stack(app_t, bool_t);
static obj_t arg2509_cfa_vector(obj_t, obj_t);
static obj_t arg2504_cfa_vector(obj_t, obj_t);
static obj_t arg2491_cfa_vector(obj_t, obj_t);
static obj_t arg2487_cfa_vector(obj_t, obj_t);
static obj_t arg2460_cfa_vector(obj_t, obj_t);
static obj_t arg2437_cfa_vector(obj_t, obj_t);
extern obj_t for_each_approx_alloc_83_cfa_approx(obj_t, approx_t);
static obj_t toplevel_init_63_cfa_vector();
extern obj_t open_input_string(obj_t);
extern obj_t vector_set__app_21_cfa_info;
static obj_t _cfa_2538_215_cfa_cfa(obj_t, obj_t);
static obj_t node_setup__pre_vector_ref_app_36_cfa_vector(obj_t, obj_t);
extern obj_t approx_set_type__239_cfa_approx(approx_t, type_t);
extern obj_t variable_ast_var;
extern obj_t create_vector_app_150_cfa_info;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _stack_2543_0_cfa_stack(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t pre_vector_ref_app_208_cfa_info;
static obj_t loose_alloc__make_vector_app_71_cfa_vector(obj_t, obj_t);
static obj_t stack__create_vector_app_141_cfa_vector(obj_t, obj_t);
extern obj_t _cfa_stamp__16_cfa_iterate;
extern obj_t add_make_vector__104_cfa_tvector(node_t);
static obj_t require_initialization_114_cfa_vector = BUNSPEC;
extern approx_t make_type_alloc_approx_134_cfa_approx(type_t, node_t);
extern obj_t _vector__240_type_cache;
extern approx_t loose__226_cfa_loose(approx_t, obj_t);
static obj_t cfa__vector_ref_app_32_cfa_vector(obj_t, obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t cnst_init_137_cfa_vector();
static obj_t node_setup__pre_create_vector_app_101_cfa_vector(obj_t, obj_t);
static obj_t __cnst[1];

extern obj_t loose_alloc__env_83_cfa_loose;
DEFINE_STATIC_PROCEDURE(proc2559_cfa_vector, arg2487_cfa_vector2567, arg2487_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2558_cfa_vector, arg2504_cfa_vector2568, arg2504_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2557_cfa_vector, stack__create_vector_app_141_cfa_vector2569, stack__create_vector_app_141_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2556_cfa_vector, stack__make_vector_app_190_cfa_vector2570, stack__make_vector_app_190_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2555_cfa_vector, stack_loose_alloc__create_vector_app_171_cfa_vector2571, stack_loose_alloc__create_vector_app_171_cfa_vector, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2554_cfa_vector, stack_loose_alloc__make_vector_app_80_cfa_vector2572, stack_loose_alloc__make_vector_app_80_cfa_vector, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2553_cfa_vector, loose_alloc__create_vector_app_169_cfa_vector2573, loose_alloc__create_vector_app_169_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2552_cfa_vector, loose_alloc__make_vector_app_71_cfa_vector2574, loose_alloc__make_vector_app_71_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2551_cfa_vector, cfa__vector_set__app_153_cfa_vector2575, cfa__vector_set__app_153_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2549_cfa_vector, cfa__create_vector_app_163_cfa_vector2576, cfa__create_vector_app_163_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2550_cfa_vector, cfa__vector_ref_app_32_cfa_vector2577, cfa__vector_ref_app_32_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2548_cfa_vector, cfa__make_vector_app_74_cfa_vector2578, cfa__make_vector_app_74_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2547_cfa_vector, node_setup__pre_vector_set__app_35_cfa_vector2579, node_setup__pre_vector_set__app_35_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2546_cfa_vector, node_setup__pre_vector_ref_app_36_cfa_vector2580, node_setup__pre_vector_ref_app_36_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2545_cfa_vector, node_setup__pre_create_vector_app_101_cfa_vector2581, node_setup__pre_create_vector_app_101_cfa_vector, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc2544_cfa_vector, node_setup__pre_make_vector_app_233_cfa_vector2582, node_setup__pre_make_vector_app_233_cfa_vector, 0L, 1);
extern obj_t cfa__env_153_cfa_cfa;
extern obj_t stack_loose_alloc__env_147_cfa_loose;
DEFINE_STRING(string2560_cfa_vector, string2560_cfa_vector2583, "ALL ", 4);
extern obj_t node_setup__env_214_cfa_setup;
extern obj_t stack__env_104_cfa_stack;


/* module-initialization */ obj_t 
module_initialization_70_cfa_vector(long checksum_3795, char *from_3796)
{
   if (CBOOL(require_initialization_114_cfa_vector))
     {
	require_initialization_114_cfa_vector = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_vector();
	cnst_init_137_cfa_vector();
	imported_modules_init_94_cfa_vector();
	method_init_76_cfa_vector();
	toplevel_init_63_cfa_vector();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_vector()
{
   module_initialization_70___object(((long) 0), "CFA_VECTOR");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_VECTOR");
   module_initialization_70___reader(((long) 0), "CFA_VECTOR");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_vector()
{
   {
      obj_t cnst_port_138_3787;
      cnst_port_138_3787 = open_input_string(string2560_cfa_vector);
      {
	 long i_3788;
	 i_3788 = ((long) 0);
       loop_3789:
	 {
	    bool_t test2561_3790;
	    test2561_3790 = (i_3788 == ((long) -1));
	    if (test2561_3790)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2562_3791;
		    {
		       obj_t list2563_3792;
		       {
			  obj_t arg2565_3793;
			  arg2565_3793 = BNIL;
			  list2563_3792 = MAKE_PAIR(cnst_port_138_3787, arg2565_3793);
		       }
		       arg2562_3791 = read___reader(list2563_3792);
		    }
		    CNST_TABLE_SET(i_3788, arg2562_3791);
		 }
		 {
		    int aux_3794;
		    {
		       long aux_3814;
		       aux_3814 = (i_3788 - ((long) 1));
		       aux_3794 = (int) (aux_3814);
		    }
		    {
		       long i_3817;
		       i_3817 = (long) (aux_3794);
		       i_3788 = i_3817;
		       goto loop_3789;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_vector()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_cfa_vector()
{
   {
      obj_t node_setup__pre_make_vector_app_233_3731;
      node_setup__pre_make_vector_app_233_3731 = proc2544_cfa_vector;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_make_vector_app_251_cfa_info, node_setup__pre_make_vector_app_233_3731);
   }
   {
      obj_t node_setup__pre_create_vector_app_101_3730;
      node_setup__pre_create_vector_app_101_3730 = proc2545_cfa_vector;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_create_vector_app_162_cfa_info, node_setup__pre_create_vector_app_101_3730);
   }
   {
      obj_t node_setup__pre_vector_ref_app_36_3729;
      node_setup__pre_vector_ref_app_36_3729 = proc2546_cfa_vector;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_vector_ref_app_208_cfa_info, node_setup__pre_vector_ref_app_36_3729);
   }
   {
      obj_t node_setup__pre_vector_set__app_35_3728;
      node_setup__pre_vector_set__app_35_3728 = proc2547_cfa_vector;
      add_method__1___object(node_setup__env_214_cfa_setup, pre_vector_set__app_211_cfa_info, node_setup__pre_vector_set__app_35_3728);
   }
   {
      obj_t cfa__make_vector_app_74_3727;
      cfa__make_vector_app_74_3727 = proc2548_cfa_vector;
      add_method__1___object(cfa__env_153_cfa_cfa, make_vector_app_205_cfa_info, cfa__make_vector_app_74_3727);
   }
   {
      obj_t cfa__create_vector_app_163_3726;
      cfa__create_vector_app_163_3726 = proc2549_cfa_vector;
      add_method__1___object(cfa__env_153_cfa_cfa, create_vector_app_150_cfa_info, cfa__create_vector_app_163_3726);
   }
   {
      obj_t cfa__vector_ref_app_32_3725;
      cfa__vector_ref_app_32_3725 = proc2550_cfa_vector;
      add_method__1___object(cfa__env_153_cfa_cfa, vector_ref_app_195_cfa_info, cfa__vector_ref_app_32_3725);
   }
   {
      obj_t cfa__vector_set__app_153_3723;
      cfa__vector_set__app_153_3723 = proc2551_cfa_vector;
      add_method__1___object(cfa__env_153_cfa_cfa, vector_set__app_21_cfa_info, cfa__vector_set__app_153_3723);
   }
   {
      obj_t loose_alloc__make_vector_app_71_3721;
      loose_alloc__make_vector_app_71_3721 = proc2552_cfa_vector;
      add_method__1___object(loose_alloc__env_83_cfa_loose, make_vector_app_205_cfa_info, loose_alloc__make_vector_app_71_3721);
   }
   {
      obj_t loose_alloc__create_vector_app_169_3718;
      loose_alloc__create_vector_app_169_3718 = proc2553_cfa_vector;
      add_method__1___object(loose_alloc__env_83_cfa_loose, create_vector_app_150_cfa_info, loose_alloc__create_vector_app_169_3718);
   }
   {
      obj_t stack_loose_alloc__make_vector_app_80_3717;
      stack_loose_alloc__make_vector_app_80_3717 = proc2554_cfa_vector;
      add_method__1___object(stack_loose_alloc__env_147_cfa_loose, make_vector_app_205_cfa_info, stack_loose_alloc__make_vector_app_80_3717);
   }
   {
      obj_t stack_loose_alloc__create_vector_app_171_3714;
      stack_loose_alloc__create_vector_app_171_3714 = proc2555_cfa_vector;
      add_method__1___object(stack_loose_alloc__env_147_cfa_loose, create_vector_app_150_cfa_info, stack_loose_alloc__create_vector_app_171_3714);
   }
   {
      obj_t stack__make_vector_app_190_3711;
      stack__make_vector_app_190_3711 = proc2556_cfa_vector;
      add_method__1___object(stack__env_104_cfa_stack, make_vector_app_205_cfa_info, stack__make_vector_app_190_3711);
   }
   {
      obj_t stack__create_vector_app_141_3710;
      stack__create_vector_app_141_3710 = proc2557_cfa_vector;
      return add_method__1___object(stack__env_104_cfa_stack, create_vector_app_150_cfa_info, stack__create_vector_app_141_3710);
   }
}


/* stack!-create-vector-app */ obj_t 
stack__create_vector_app_141_cfa_vector(obj_t env_3732, obj_t node_3733)
{
   {
      create_vector_app_150_t node_3116;
      {
	 node_t aux_3833;
	 node_3116 = (create_vector_app_150_t) (node_3733);
	 {
	    obj_t aux_3834;
	    {
	       app_t obj_3705;
	       obj_3705 = (app_t) (node_3116);
	       aux_3834 = (((app_t) CREF(obj_3705))->args);
	    }
	    stack___129_cfa_stack(aux_3834);
	 }
	 {
	    bool_t aux_3838;
	    {
	       bool_t test_3840;
	       {
		  long aux_3841;
		  {
		     obj_t aux_3842;
		     {
			object_t aux_3843;
			aux_3843 = (object_t) (node_3116);
			aux_3842 = OBJECT_WIDENING(aux_3843);
		     }
		     aux_3841 = (((create_vector_app_150_t) CREF(aux_3842))->lost_stamp_114);
		  }
		  test_3840 = (aux_3841 == ((long) -1));
	       }
	       if (test_3840)
		 {
		    obj_t aux_3848;
		    {
		       object_t aux_3849;
		       aux_3849 = (object_t) (node_3116);
		       aux_3848 = OBJECT_WIDENING(aux_3849);
		    }
		    aux_3838 = (((create_vector_app_150_t) CREF(aux_3848))->stackable__42);
		 }
	       else
		 {
		    aux_3838 = ((bool_t) 0);
		 }
	    }
	    aux_3833 = node_heap__stack__239_cfa_stack((app_t) (node_3116), aux_3838);
	 }
	 return (obj_t) (aux_3833);
      }
   }
}


/* stack!-make-vector-app */ obj_t 
stack__make_vector_app_190_cfa_vector(obj_t env_3734, obj_t node_3735)
{
   {
      make_vector_app_205_t node_3105;
      {
	 node_t aux_3856;
	 node_3105 = (make_vector_app_205_t) (node_3735);
	 {
	    obj_t aux_3857;
	    {
	       app_t obj_3700;
	       obj_3700 = (app_t) (node_3105);
	       aux_3857 = (((app_t) CREF(obj_3700))->args);
	    }
	    stack___129_cfa_stack(aux_3857);
	 }
	 {
	    bool_t aux_3861;
	    {
	       bool_t test_3863;
	       {
		  long aux_3864;
		  {
		     obj_t aux_3865;
		     {
			object_t aux_3866;
			aux_3866 = (object_t) (node_3105);
			aux_3865 = OBJECT_WIDENING(aux_3866);
		     }
		     aux_3864 = (((make_vector_app_205_t) CREF(aux_3865))->lost_stamp_114);
		  }
		  test_3863 = (aux_3864 == ((long) -1));
	       }
	       if (test_3863)
		 {
		    obj_t aux_3871;
		    {
		       object_t aux_3872;
		       aux_3872 = (object_t) (node_3105);
		       aux_3871 = OBJECT_WIDENING(aux_3872);
		    }
		    aux_3861 = (((make_vector_app_205_t) CREF(aux_3871))->stackable__42);
		 }
	       else
		 {
		    aux_3861 = ((bool_t) 0);
		 }
	    }
	    aux_3856 = node_heap__stack__239_cfa_stack((app_t) (node_3105), aux_3861);
	 }
	 return (obj_t) (aux_3856);
      }
   }
}


/* stack-loose-alloc!-create-vector-app */ obj_t 
stack_loose_alloc__create_vector_app_171_cfa_vector(obj_t env_3736, obj_t alloc_3737, obj_t cowner_3738)
{
   {
      create_vector_app_150_t alloc_3079;
      obj_t cowner_3080;
      alloc_3079 = (create_vector_app_150_t) (alloc_3737);
      cowner_3080 = cowner_3738;
      {
	 bool_t test_3879;
	 {
	    bool_t test_3880;
	    {
	       obj_t aux_3881;
	       {
		  object_t aux_3882;
		  aux_3882 = (object_t) (alloc_3079);
		  aux_3881 = OBJECT_WIDENING(aux_3882);
	       }
	       test_3880 = (((create_vector_app_150_t) CREF(aux_3881))->stackable__42);
	    }
	    if (test_3880)
	      {
		 obj_t aux_3886;
		 {
		    obj_t aux_3887;
		    {
		       obj_t aux_3888;
		       {
			  object_t aux_3889;
			  aux_3889 = (object_t) (alloc_3079);
			  aux_3888 = OBJECT_WIDENING(aux_3889);
		       }
		       aux_3887 = (((create_vector_app_150_t) CREF(aux_3888))->stack_stamp_31);
		    }
		    aux_3886 = memq___r4_pairs_and_lists_6_3(cowner_3080, aux_3887);
		 }
		 test_3879 = CBOOL(aux_3886);
	      }
	    else
	      {
		 test_3879 = ((bool_t) 1);
	      }
	 }
	 if (test_3879)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 obj_t arg2501_3085;
		 {
		    obj_t aux_3895;
		    {
		       obj_t aux_3896;
		       {
			  object_t aux_3897;
			  aux_3897 = (object_t) (alloc_3079);
			  aux_3896 = OBJECT_WIDENING(aux_3897);
		       }
		       aux_3895 = (((create_vector_app_150_t) CREF(aux_3896))->stack_stamp_31);
		    }
		    arg2501_3085 = MAKE_PAIR(cowner_3080, aux_3895);
		 }
		 {
		    obj_t aux_3902;
		    {
		       object_t aux_3903;
		       aux_3903 = (object_t) (alloc_3079);
		       aux_3902 = OBJECT_WIDENING(aux_3903);
		    }
		    ((((create_vector_app_150_t) CREF(aux_3902))->stack_stamp_31) = ((obj_t) arg2501_3085), BUNSPEC);
		 }
	      }
	      {
		 bool_t test2503_3087;
		 {
		    bool_t test2513_3099;
		    test2513_3099 = is_a__118___object(cowner_3080, variable_ast_var);
		    if (test2513_3099)
		      {
			 obj_t aux_3909;
			 {
			    variable_t aux_3910;
			    {
			       obj_t aux_3911;
			       {
				  object_t aux_3912;
				  aux_3912 = (object_t) (alloc_3079);
				  aux_3911 = OBJECT_WIDENING(aux_3912);
			       }
			       aux_3910 = (((create_vector_app_150_t) CREF(aux_3911))->owner);
			    }
			    aux_3909 = (obj_t) (aux_3910);
			 }
			 test2503_3087 = (aux_3909 == cowner_3080);
		      }
		    else
		      {
			 test2503_3087 = ((bool_t) 1);
		      }
		 }
		 if (test2503_3087)
		   {
		      {
			 obj_t aux_3919;
			 {
			    object_t aux_3920;
			    aux_3920 = (object_t) (alloc_3079);
			    aux_3919 = OBJECT_WIDENING(aux_3920);
			 }
			 ((((create_vector_app_150_t) CREF(aux_3919))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		      {
			 approx_t arg2506_3089;
			 {
			    obj_t aux_3924;
			    {
			       object_t aux_3925;
			       aux_3925 = (object_t) (alloc_3079);
			       aux_3924 = OBJECT_WIDENING(aux_3925);
			    }
			    arg2506_3089 = (((create_vector_app_150_t) CREF(aux_3924))->value_approx_19);
			 }
			 {
			    obj_t arg2504_3712;
			    arg2504_3712 = proc2558_cfa_vector;
			    return for_each_approx_alloc_83_cfa_approx(arg2504_3712, arg2506_3089);
			 }
		      }
		   }
		 else
		   {
		      approx_t arg2511_3095;
		      {
			 obj_t aux_3930;
			 {
			    object_t aux_3931;
			    aux_3931 = (object_t) (alloc_3079);
			    aux_3930 = OBJECT_WIDENING(aux_3931);
			 }
			 arg2511_3095 = (((create_vector_app_150_t) CREF(aux_3930))->value_approx_19);
		      }
		      {
			 obj_t arg2509_3713;
			 arg2509_3713 = make_fx_procedure(arg2509_cfa_vector, ((long) 1), ((long) 1));
			 PROCEDURE_SET(arg2509_3713, ((long) 0), cowner_3080);
			 return for_each_approx_alloc_83_cfa_approx(arg2509_3713, arg2511_3095);
		      }
		   }
	      }
	   }
      }
   }
}


/* arg2504 */ obj_t 
arg2504_cfa_vector(obj_t env_3739, obj_t alloc_3740)
{
   {
      obj_t alloc_3090;
      alloc_3090 = alloc_3740;
      return stack_loose_alloc__95_cfa_loose((node_t) (alloc_3090), CNST_TABLE_REF(((long) 0)));
   }
}


/* arg2509 */ obj_t 
arg2509_cfa_vector(obj_t env_3741, obj_t alloc_3743)
{
   {
      obj_t cowner_3742;
      cowner_3742 = PROCEDURE_REF(env_3741, ((long) 0));
      {
	 obj_t alloc_3096;
	 alloc_3096 = alloc_3743;
	 return stack_loose_alloc__95_cfa_loose((node_t) (alloc_3096), cowner_3742);
      }
   }
}


/* stack-loose-alloc!-make-vector-app */ obj_t 
stack_loose_alloc__make_vector_app_80_cfa_vector(obj_t env_3744, obj_t alloc_3745, obj_t cowner_3746)
{
   {
      make_vector_app_205_t alloc_3053;
      obj_t cowner_3054;
      alloc_3053 = (make_vector_app_205_t) (alloc_3745);
      cowner_3054 = cowner_3746;
      {
	 bool_t test_3945;
	 {
	    bool_t test_3946;
	    {
	       obj_t aux_3947;
	       {
		  object_t aux_3948;
		  aux_3948 = (object_t) (alloc_3053);
		  aux_3947 = OBJECT_WIDENING(aux_3948);
	       }
	       test_3946 = (((make_vector_app_205_t) CREF(aux_3947))->stackable__42);
	    }
	    if (test_3946)
	      {
		 obj_t aux_3952;
		 {
		    obj_t aux_3953;
		    {
		       obj_t aux_3954;
		       {
			  object_t aux_3955;
			  aux_3955 = (object_t) (alloc_3053);
			  aux_3954 = OBJECT_WIDENING(aux_3955);
		       }
		       aux_3953 = (((make_vector_app_205_t) CREF(aux_3954))->stack_stamp_31);
		    }
		    aux_3952 = memq___r4_pairs_and_lists_6_3(cowner_3054, aux_3953);
		 }
		 test_3945 = CBOOL(aux_3952);
	      }
	    else
	      {
		 test_3945 = ((bool_t) 1);
	      }
	 }
	 if (test_3945)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 obj_t arg2484_3059;
		 {
		    obj_t aux_3961;
		    {
		       obj_t aux_3962;
		       {
			  object_t aux_3963;
			  aux_3963 = (object_t) (alloc_3053);
			  aux_3962 = OBJECT_WIDENING(aux_3963);
		       }
		       aux_3961 = (((make_vector_app_205_t) CREF(aux_3962))->stack_stamp_31);
		    }
		    arg2484_3059 = MAKE_PAIR(cowner_3054, aux_3961);
		 }
		 {
		    obj_t aux_3968;
		    {
		       object_t aux_3969;
		       aux_3969 = (object_t) (alloc_3053);
		       aux_3968 = OBJECT_WIDENING(aux_3969);
		    }
		    ((((make_vector_app_205_t) CREF(aux_3968))->stack_stamp_31) = ((obj_t) arg2484_3059), BUNSPEC);
		 }
	      }
	      {
		 bool_t test2486_3061;
		 {
		    bool_t test2495_3073;
		    test2495_3073 = is_a__118___object(cowner_3054, variable_ast_var);
		    if (test2495_3073)
		      {
			 obj_t aux_3975;
			 {
			    variable_t aux_3976;
			    {
			       obj_t aux_3977;
			       {
				  object_t aux_3978;
				  aux_3978 = (object_t) (alloc_3053);
				  aux_3977 = OBJECT_WIDENING(aux_3978);
			       }
			       aux_3976 = (((make_vector_app_205_t) CREF(aux_3977))->owner);
			    }
			    aux_3975 = (obj_t) (aux_3976);
			 }
			 test2486_3061 = (aux_3975 == cowner_3054);
		      }
		    else
		      {
			 test2486_3061 = ((bool_t) 1);
		      }
		 }
		 if (test2486_3061)
		   {
		      {
			 obj_t aux_3985;
			 {
			    object_t aux_3986;
			    aux_3986 = (object_t) (alloc_3053);
			    aux_3985 = OBJECT_WIDENING(aux_3986);
			 }
			 ((((make_vector_app_205_t) CREF(aux_3985))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
		      }
		      {
			 approx_t arg2488_3063;
			 {
			    obj_t aux_3990;
			    {
			       object_t aux_3991;
			       aux_3991 = (object_t) (alloc_3053);
			       aux_3990 = OBJECT_WIDENING(aux_3991);
			    }
			    arg2488_3063 = (((make_vector_app_205_t) CREF(aux_3990))->value_approx_19);
			 }
			 {
			    obj_t arg2487_3715;
			    arg2487_3715 = proc2559_cfa_vector;
			    return for_each_approx_alloc_83_cfa_approx(arg2487_3715, arg2488_3063);
			 }
		      }
		   }
		 else
		   {
		      approx_t arg2493_3069;
		      {
			 obj_t aux_3996;
			 {
			    object_t aux_3997;
			    aux_3997 = (object_t) (alloc_3053);
			    aux_3996 = OBJECT_WIDENING(aux_3997);
			 }
			 arg2493_3069 = (((make_vector_app_205_t) CREF(aux_3996))->value_approx_19);
		      }
		      {
			 obj_t arg2491_3716;
			 arg2491_3716 = make_fx_procedure(arg2491_cfa_vector, ((long) 1), ((long) 1));
			 PROCEDURE_SET(arg2491_3716, ((long) 0), cowner_3054);
			 return for_each_approx_alloc_83_cfa_approx(arg2491_3716, arg2493_3069);
		      }
		   }
	      }
	   }
      }
   }
}


/* arg2487 */ obj_t 
arg2487_cfa_vector(obj_t env_3747, obj_t alloc_3748)
{
   {
      obj_t alloc_3064;
      alloc_3064 = alloc_3748;
      return stack_loose_alloc__95_cfa_loose((node_t) (alloc_3064), CNST_TABLE_REF(((long) 0)));
   }
}


/* arg2491 */ obj_t 
arg2491_cfa_vector(obj_t env_3749, obj_t alloc_3751)
{
   {
      obj_t cowner_3750;
      cowner_3750 = PROCEDURE_REF(env_3749, ((long) 0));
      {
	 obj_t alloc_3070;
	 alloc_3070 = alloc_3751;
	 return stack_loose_alloc__95_cfa_loose((node_t) (alloc_3070), cowner_3750);
      }
   }
}


/* loose-alloc!-create-vector-app */ obj_t 
loose_alloc__create_vector_app_169_cfa_vector(obj_t env_3752, obj_t alloc_3753)
{
   {
      create_vector_app_150_t alloc_3042;
      alloc_3042 = (create_vector_app_150_t) (alloc_3753);
      {
	 bool_t test2477_3046;
	 {
	    long arg2481_3050;
	    {
	       obj_t aux_4011;
	       {
		  object_t aux_4012;
		  aux_4012 = (object_t) (alloc_3042);
		  aux_4011 = OBJECT_WIDENING(aux_4012);
	       }
	       arg2481_3050 = (((create_vector_app_150_t) CREF(aux_4011))->lost_stamp_114);
	    }
	    {
	       long n2_3660;
	       n2_3660 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	       test2477_3046 = (arg2481_3050 == n2_3660);
	    }
	 }
	 if (test2477_3046)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 long val1969_3662;
		 val1969_3662 = (long) CINT(_cfa_stamp__16_cfa_iterate);
		 {
		    obj_t aux_4020;
		    {
		       object_t aux_4021;
		       aux_4021 = (object_t) (alloc_3042);
		       aux_4020 = OBJECT_WIDENING(aux_4021);
		    }
		    ((((create_vector_app_150_t) CREF(aux_4020))->lost_stamp_114) = ((long) val1969_3662), BUNSPEC);
		 }
	      }
	      {
		 obj_t aux_4025;
		 {
		    object_t aux_4026;
		    aux_4026 = (object_t) (alloc_3042);
		    aux_4025 = OBJECT_WIDENING(aux_4026);
		 }
		 ((((create_vector_app_150_t) CREF(aux_4025))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	      }
	      {
		 approx_t aux_4030;
		 {
		    obj_t aux_4031;
		    {
		       object_t aux_4032;
		       aux_4032 = (object_t) (alloc_3042);
		       aux_4031 = OBJECT_WIDENING(aux_4032);
		    }
		    aux_4030 = (((create_vector_app_150_t) CREF(aux_4031))->value_approx_19);
		 }
		 for_each_approx_alloc_83_cfa_approx(loose_alloc__env_83_cfa_loose, aux_4030);
	      }
	      {
		 approx_t aux_4037;
		 {
		    obj_t aux_4038;
		    {
		       object_t aux_4039;
		       aux_4039 = (object_t) (alloc_3042);
		       aux_4038 = OBJECT_WIDENING(aux_4039);
		    }
		    aux_4037 = (((create_vector_app_150_t) CREF(aux_4038))->value_approx_19);
		 }
		 approx_set_type__239_cfa_approx(aux_4037, (type_t) (_obj__252_type_cache));
	      }
	      {
		 approx_t aux_4045;
		 {
		    obj_t aux_4046;
		    {
		       object_t aux_4047;
		       aux_4047 = (object_t) (alloc_3042);
		       aux_4046 = OBJECT_WIDENING(aux_4047);
		    }
		    aux_4045 = (((create_vector_app_150_t) CREF(aux_4046))->value_approx_19);
		 }
		 return approx_set_top__187_cfa_approx(aux_4045);
	      }
	   }
      }
   }
}


/* loose-alloc!-make-vector-app */ obj_t 
loose_alloc__make_vector_app_71_cfa_vector(obj_t env_3754, obj_t alloc_3755)
{
   {
      make_vector_app_205_t alloc_3031;
      alloc_3031 = (make_vector_app_205_t) (alloc_3755);
      {
	 bool_t test2471_3035;
	 {
	    long arg2475_3039;
	    {
	       obj_t aux_4053;
	       {
		  object_t aux_4054;
		  aux_4054 = (object_t) (alloc_3031);
		  aux_4053 = OBJECT_WIDENING(aux_4054);
	       }
	       arg2475_3039 = (((make_vector_app_205_t) CREF(aux_4053))->lost_stamp_114);
	    }
	    {
	       long n2_3650;
	       n2_3650 = (long) CINT(_cfa_stamp__16_cfa_iterate);
	       test2471_3035 = (arg2475_3039 == n2_3650);
	    }
	 }
	 if (test2471_3035)
	   {
	      return BUNSPEC;
	   }
	 else
	   {
	      {
		 long val1946_3652;
		 val1946_3652 = (long) CINT(_cfa_stamp__16_cfa_iterate);
		 {
		    obj_t aux_4062;
		    {
		       object_t aux_4063;
		       aux_4063 = (object_t) (alloc_3031);
		       aux_4062 = OBJECT_WIDENING(aux_4063);
		    }
		    ((((make_vector_app_205_t) CREF(aux_4062))->lost_stamp_114) = ((long) val1946_3652), BUNSPEC);
		 }
	      }
	      {
		 obj_t aux_4067;
		 {
		    object_t aux_4068;
		    aux_4068 = (object_t) (alloc_3031);
		    aux_4067 = OBJECT_WIDENING(aux_4068);
		 }
		 ((((make_vector_app_205_t) CREF(aux_4067))->stackable__42) = ((bool_t) ((bool_t) 0)), BUNSPEC);
	      }
	      {
		 approx_t aux_4072;
		 {
		    obj_t aux_4073;
		    {
		       object_t aux_4074;
		       aux_4074 = (object_t) (alloc_3031);
		       aux_4073 = OBJECT_WIDENING(aux_4074);
		    }
		    aux_4072 = (((make_vector_app_205_t) CREF(aux_4073))->value_approx_19);
		 }
		 for_each_approx_alloc_83_cfa_approx(loose_alloc__env_83_cfa_loose, aux_4072);
	      }
	      {
		 approx_t aux_4079;
		 {
		    obj_t aux_4080;
		    {
		       object_t aux_4081;
		       aux_4081 = (object_t) (alloc_3031);
		       aux_4080 = OBJECT_WIDENING(aux_4081);
		    }
		    aux_4079 = (((make_vector_app_205_t) CREF(aux_4080))->value_approx_19);
		 }
		 approx_set_type__239_cfa_approx(aux_4079, (type_t) (_obj__252_type_cache));
	      }
	      {
		 approx_t aux_4087;
		 {
		    obj_t aux_4088;
		    {
		       object_t aux_4089;
		       aux_4089 = (object_t) (alloc_3031);
		       aux_4088 = OBJECT_WIDENING(aux_4089);
		    }
		    aux_4087 = (((make_vector_app_205_t) CREF(aux_4088))->value_approx_19);
		 }
		 return approx_set_top__187_cfa_approx(aux_4087);
	      }
	   }
      }
   }
}


/* cfa!-vector-set!-app */ obj_t 
cfa__vector_set__app_153_cfa_vector(obj_t env_3756, obj_t node_3757)
{
   {
      vector_set__app_21_t node_3003;
      {
	 approx_t aux_4095;
	 node_3003 = (vector_set__app_21_t) (node_3757);
	 {
	    node_t aux_4096;
	    {
	       obj_t aux_4097;
	       {
		  obj_t aux_4098;
		  {
		     obj_t aux_4099;
		     {
			app_t obj_3621;
			obj_3621 = (app_t) (node_3003);
			aux_4099 = (((app_t) CREF(obj_3621))->args);
		     }
		     aux_4098 = CDR(aux_4099);
		  }
		  aux_4097 = CAR(aux_4098);
	       }
	       aux_4096 = (node_t) (aux_4097);
	    }
	    cfa__102_cfa_cfa(aux_4096);
	 }
	 {
	    approx_t vec_approx_215_3009;
	    approx_t val_approx_22_3010;
	    {
	       node_t aux_4106;
	       {
		  obj_t aux_4107;
		  {
		     obj_t aux_4108;
		     {
			app_t obj_3626;
			obj_3626 = (app_t) (node_3003);
			aux_4108 = (((app_t) CREF(obj_3626))->args);
		     }
		     aux_4107 = CAR(aux_4108);
		  }
		  aux_4106 = (node_t) (aux_4107);
	       }
	       vec_approx_215_3009 = cfa__102_cfa_cfa(aux_4106);
	    }
	    {
	       node_t aux_4114;
	       {
		  obj_t aux_4115;
		  {
		     obj_t aux_4116;
		     {
			obj_t aux_4117;
			{
			   obj_t aux_4118;
			   {
			      app_t obj_3628;
			      obj_3628 = (app_t) (node_3003);
			      aux_4118 = (((app_t) CREF(obj_3628))->args);
			   }
			   aux_4117 = CDR(aux_4118);
			}
			aux_4116 = CDR(aux_4117);
		     }
		     aux_4115 = CAR(aux_4116);
		  }
		  aux_4114 = (node_t) (aux_4115);
	       }
	       val_approx_22_3010 = cfa__102_cfa_cfa(aux_4114);
	    }
	    {
	       bool_t test2456_3011;
	       {
		  obj_t obj2_3637;
		  obj2_3637 = _vector__240_type_cache;
		  {
		     obj_t aux_4126;
		     {
			type_t aux_4127;
			aux_4127 = (((approx_t) CREF(vec_approx_215_3009))->type);
			aux_4126 = (obj_t) (aux_4127);
		     }
		     test2456_3011 = (aux_4126 == obj2_3637);
		  }
	       }
	       if (test2456_3011)
		 {
		    BUNSPEC;
		 }
	       else
		 {
		    approx_set_type__239_cfa_approx(val_approx_22_3010, (type_t) (_obj__252_type_cache));
		 }
	    }
	    if ((((approx_t) CREF(vec_approx_215_3009))->top__138))
	      {
		 approx_t aux_4136;
		 aux_4136 = loose__226_cfa_loose(val_approx_22_3010, CNST_TABLE_REF(((long) 0)));
		 (obj_t) (aux_4136);
	      }
	    else
	      {
		 obj_t arg2460_3722;
		 arg2460_3722 = make_fx_procedure(arg2460_cfa_vector, ((long) 1), ((long) 1));
		 {
		    obj_t aux_4141;
		    aux_4141 = (obj_t) (val_approx_22_3010);
		    PROCEDURE_SET(arg2460_3722, ((long) 0), aux_4141);
		 }
		 for_each_approx_alloc_83_cfa_approx(arg2460_3722, vec_approx_215_3009);
	      }
	 }
	 {
	    obj_t aux_4145;
	    {
	       object_t aux_4146;
	       aux_4146 = (object_t) (node_3003);
	       aux_4145 = OBJECT_WIDENING(aux_4146);
	    }
	    aux_4095 = (((vector_set__app_21_t) CREF(aux_4145))->approx);
	 }
	 return (obj_t) (aux_4095);
      }
   }
}


/* arg2460 */ obj_t 
arg2460_cfa_vector(obj_t env_3758, obj_t app_3760)
{
   {
      obj_t val_approx_22_3759;
      val_approx_22_3759 = PROCEDURE_REF(env_3758, ((long) 0));
      {
	 obj_t app_3016;
	 app_3016 = app_3760;
	 {
	    bool_t test2462_3018;
	    test2462_3018 = is_a__118___object(app_3016, make_vector_app_205_cfa_info);
	    if (test2462_3018)
	      {
		 {
		    make_vector_app_205_t obj_3640;
		    obj_3640 = (make_vector_app_205_t) (app_3016);
		    {
		       obj_t aux_4156;
		       {
			  object_t aux_4157;
			  aux_4157 = (object_t) (obj_3640);
			  aux_4156 = OBJECT_WIDENING(aux_4157);
		       }
		       ((((make_vector_app_205_t) CREF(aux_4156))->seen__39) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		    }
		 }
		 {
		    approx_t aux_4161;
		    {
		       approx_t aux_4162;
		       {
			  make_vector_app_205_t obj_3642;
			  obj_3642 = (make_vector_app_205_t) (app_3016);
			  {
			     obj_t aux_4164;
			     {
				object_t aux_4165;
				aux_4165 = (object_t) (obj_3642);
				aux_4164 = OBJECT_WIDENING(aux_4165);
			     }
			     aux_4162 = (((make_vector_app_205_t) CREF(aux_4164))->value_approx_19);
			  }
		       }
		       aux_4161 = union_approx__241_cfa_approx(aux_4162, (approx_t) (val_approx_22_3759));
		    }
		    return (obj_t) (aux_4161);
		 }
	      }
	    else
	      {
		 bool_t test2464_3021;
		 test2464_3021 = is_a__118___object(app_3016, create_vector_app_150_cfa_info);
		 if (test2464_3021)
		   {
		      {
			 create_vector_app_150_t obj_3644;
			 obj_3644 = (create_vector_app_150_t) (app_3016);
			 {
			    obj_t aux_4175;
			    {
			       object_t aux_4176;
			       aux_4176 = (object_t) (obj_3644);
			       aux_4175 = OBJECT_WIDENING(aux_4176);
			    }
			    ((((create_vector_app_150_t) CREF(aux_4175))->seen__39) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			 }
		      }
		      {
			 approx_t aux_4180;
			 {
			    approx_t aux_4181;
			    {
			       create_vector_app_150_t obj_3646;
			       obj_3646 = (create_vector_app_150_t) (app_3016);
			       {
				  obj_t aux_4183;
				  {
				     object_t aux_4184;
				     aux_4184 = (object_t) (obj_3646);
				     aux_4183 = OBJECT_WIDENING(aux_4184);
				  }
				  aux_4181 = (((create_vector_app_150_t) CREF(aux_4183))->value_approx_19);
			       }
			    }
			    aux_4180 = union_approx__241_cfa_approx(aux_4181, (approx_t) (val_approx_22_3759));
			 }
			 return (obj_t) (aux_4180);
		      }
		   }
		 else
		   {
		      return BFALSE;
		   }
	      }
	 }
      }
   }
}


/* cfa!-vector-ref-app */ obj_t 
cfa__vector_ref_app_32_cfa_vector(obj_t env_3761, obj_t node_3762)
{
   {
      vector_ref_app_195_t node_2968;
      {
	 approx_t aux_4191;
	 node_2968 = (vector_ref_app_195_t) (node_3762);
	 {
	    node_t aux_4192;
	    {
	       obj_t aux_4193;
	       {
		  obj_t aux_4194;
		  {
		     obj_t aux_4195;
		     {
			app_t obj_3590;
			obj_3590 = (app_t) (node_2968);
			aux_4195 = (((app_t) CREF(obj_3590))->args);
		     }
		     aux_4194 = CDR(aux_4195);
		  }
		  aux_4193 = CAR(aux_4194);
	       }
	       aux_4192 = (node_t) (aux_4193);
	    }
	    cfa__102_cfa_cfa(aux_4192);
	 }
	 {
	    approx_t vec_approx_215_2974;
	    {
	       node_t aux_4202;
	       {
		  obj_t aux_4203;
		  {
		     obj_t aux_4204;
		     {
			app_t obj_3595;
			obj_3595 = (app_t) (node_2968);
			aux_4204 = (((app_t) CREF(obj_3595))->args);
		     }
		     aux_4203 = CAR(aux_4204);
		  }
		  aux_4202 = (node_t) (aux_4203);
	       }
	       vec_approx_215_2974 = cfa__102_cfa_cfa(aux_4202);
	    }
	    {
	       bool_t test2431_2975;
	       {
		  bool_t test2433_2977;
		  {
		     obj_t obj2_3599;
		     obj2_3599 = _vector__240_type_cache;
		     {
			obj_t aux_4210;
			{
			   type_t aux_4211;
			   aux_4211 = (((approx_t) CREF(vec_approx_215_2974))->type);
			   aux_4210 = (obj_t) (aux_4211);
			}
			test2433_2977 = (aux_4210 == obj2_3599);
		     }
		  }
		  if (test2433_2977)
		    {
		       test2431_2975 = (((approx_t) CREF(vec_approx_215_2974))->top__138);
		    }
		  else
		    {
		       test2431_2975 = ((bool_t) 1);
		    }
	       }
	       if (test2431_2975)
		 {
		    approx_t aux_4218;
		    {
		       obj_t aux_4219;
		       {
			  object_t aux_4220;
			  aux_4220 = (object_t) (node_2968);
			  aux_4219 = OBJECT_WIDENING(aux_4220);
		       }
		       aux_4218 = (((vector_ref_app_195_t) CREF(aux_4219))->approx);
		    }
		    approx_set_type__239_cfa_approx(aux_4218, (type_t) (_obj__252_type_cache));
		 }
	       else
		 {
		    BUNSPEC;
		 }
	    }
	    if ((((approx_t) CREF(vec_approx_215_2974))->top__138))
	      {
		 approx_t aux_4228;
		 {
		    obj_t aux_4229;
		    {
		       object_t aux_4230;
		       aux_4230 = (object_t) (node_2968);
		       aux_4229 = OBJECT_WIDENING(aux_4230);
		    }
		    aux_4228 = (((vector_ref_app_195_t) CREF(aux_4229))->approx);
		 }
		 approx_set_top__187_cfa_approx(aux_4228);
	      }
	    else
	      {
		 BUNSPEC;
	      }
	    {
	       obj_t arg2437_3724;
	       arg2437_3724 = make_fx_procedure(arg2437_cfa_vector, ((long) 1), ((long) 1));
	       {
		  obj_t aux_4236;
		  aux_4236 = (obj_t) (node_2968);
		  PROCEDURE_SET(arg2437_3724, ((long) 0), aux_4236);
	       }
	       for_each_approx_alloc_83_cfa_approx(arg2437_3724, vec_approx_215_2974);
	    }
	 }
	 {
	    obj_t aux_4240;
	    {
	       object_t aux_4241;
	       aux_4241 = (object_t) (node_2968);
	       aux_4240 = OBJECT_WIDENING(aux_4241);
	    }
	    aux_4191 = (((vector_ref_app_195_t) CREF(aux_4240))->approx);
	 }
	 return (obj_t) (aux_4191);
      }
   }
}


/* arg2437 */ obj_t 
arg2437_cfa_vector(obj_t env_3763, obj_t app_3765)
{
   {
      obj_t instance2093_3764;
      instance2093_3764 = PROCEDURE_REF(env_3763, ((long) 0));
      {
	 obj_t app_2982;
	 app_2982 = app_3765;
	 {
	    bool_t test2439_2984;
	    test2439_2984 = is_a__118___object(app_2982, make_vector_app_205_cfa_info);
	    if (test2439_2984)
	      {
		 {
		    make_vector_app_205_t obj_3605;
		    obj_3605 = (make_vector_app_205_t) (app_2982);
		    {
		       obj_t aux_4251;
		       {
			  object_t aux_4252;
			  aux_4252 = (object_t) (obj_3605);
			  aux_4251 = OBJECT_WIDENING(aux_4252);
		       }
		       ((((make_vector_app_205_t) CREF(aux_4251))->seen__39) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		    }
		 }
		 {
		    approx_t aux_4263;
		    approx_t aux_4256;
		    {
		       make_vector_app_205_t obj_3608;
		       obj_3608 = (make_vector_app_205_t) (app_2982);
		       {
			  obj_t aux_4265;
			  {
			     object_t aux_4266;
			     aux_4266 = (object_t) (obj_3608);
			     aux_4265 = OBJECT_WIDENING(aux_4266);
			  }
			  aux_4263 = (((make_vector_app_205_t) CREF(aux_4265))->value_approx_19);
		       }
		    }
		    {
		       vector_ref_app_195_t obj_3607;
		       obj_3607 = (vector_ref_app_195_t) (instance2093_3764);
		       {
			  obj_t aux_4258;
			  {
			     object_t aux_4259;
			     aux_4259 = (object_t) (obj_3607);
			     aux_4258 = OBJECT_WIDENING(aux_4259);
			  }
			  aux_4256 = (((vector_ref_app_195_t) CREF(aux_4258))->approx);
		       }
		    }
		    union_approx__241_cfa_approx(aux_4256, aux_4263);
		 }
		 {
		    type_t aux_4278;
		    approx_t aux_4271;
		    {
		       approx_t arg2444_2990;
		       {
			  vector_ref_app_195_t obj_3610;
			  obj_3610 = (vector_ref_app_195_t) (instance2093_3764);
			  {
			     obj_t aux_4280;
			     {
				object_t aux_4281;
				aux_4281 = (object_t) (obj_3610);
				aux_4280 = OBJECT_WIDENING(aux_4281);
			     }
			     arg2444_2990 = (((vector_ref_app_195_t) CREF(aux_4280))->approx);
			  }
		       }
		       aux_4278 = (((approx_t) CREF(arg2444_2990))->type);
		    }
		    {
		       make_vector_app_205_t obj_3609;
		       obj_3609 = (make_vector_app_205_t) (app_2982);
		       {
			  obj_t aux_4273;
			  {
			     object_t aux_4274;
			     aux_4274 = (object_t) (obj_3609);
			     aux_4273 = OBJECT_WIDENING(aux_4274);
			  }
			  aux_4271 = (((make_vector_app_205_t) CREF(aux_4273))->value_approx_19);
		       }
		    }
		    return approx_set_type__239_cfa_approx(aux_4271, aux_4278);
		 }
	      }
	    else
	      {
		 bool_t test2445_2991;
		 test2445_2991 = is_a__118___object(app_2982, create_vector_app_150_cfa_info);
		 if (test2445_2991)
		   {
		      {
			 create_vector_app_150_t obj_3613;
			 obj_3613 = (create_vector_app_150_t) (app_2982);
			 {
			    obj_t aux_4290;
			    {
			       object_t aux_4291;
			       aux_4291 = (object_t) (obj_3613);
			       aux_4290 = OBJECT_WIDENING(aux_4291);
			    }
			    ((((create_vector_app_150_t) CREF(aux_4290))->seen__39) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			 }
		      }
		      {
			 approx_t aux_4302;
			 approx_t aux_4295;
			 {
			    create_vector_app_150_t obj_3616;
			    obj_3616 = (create_vector_app_150_t) (app_2982);
			    {
			       obj_t aux_4304;
			       {
				  object_t aux_4305;
				  aux_4305 = (object_t) (obj_3616);
				  aux_4304 = OBJECT_WIDENING(aux_4305);
			       }
			       aux_4302 = (((create_vector_app_150_t) CREF(aux_4304))->value_approx_19);
			    }
			 }
			 {
			    vector_ref_app_195_t obj_3615;
			    obj_3615 = (vector_ref_app_195_t) (instance2093_3764);
			    {
			       obj_t aux_4297;
			       {
				  object_t aux_4298;
				  aux_4298 = (object_t) (obj_3615);
				  aux_4297 = OBJECT_WIDENING(aux_4298);
			       }
			       aux_4295 = (((vector_ref_app_195_t) CREF(aux_4297))->approx);
			    }
			 }
			 union_approx__241_cfa_approx(aux_4295, aux_4302);
		      }
		      {
			 type_t aux_4317;
			 approx_t aux_4310;
			 {
			    approx_t arg2450_2997;
			    {
			       vector_ref_app_195_t obj_3618;
			       obj_3618 = (vector_ref_app_195_t) (instance2093_3764);
			       {
				  obj_t aux_4319;
				  {
				     object_t aux_4320;
				     aux_4320 = (object_t) (obj_3618);
				     aux_4319 = OBJECT_WIDENING(aux_4320);
				  }
				  arg2450_2997 = (((vector_ref_app_195_t) CREF(aux_4319))->approx);
			       }
			    }
			    aux_4317 = (((approx_t) CREF(arg2450_2997))->type);
			 }
			 {
			    create_vector_app_150_t obj_3617;
			    obj_3617 = (create_vector_app_150_t) (app_2982);
			    {
			       obj_t aux_4312;
			       {
				  object_t aux_4313;
				  aux_4313 = (object_t) (obj_3617);
				  aux_4312 = OBJECT_WIDENING(aux_4313);
			       }
			       aux_4310 = (((create_vector_app_150_t) CREF(aux_4312))->value_approx_19);
			    }
			 }
			 return approx_set_type__239_cfa_approx(aux_4310, aux_4317);
		      }
		   }
		 else
		   {
		      return BFALSE;
		   }
	      }
	 }
      }
   }
}


/* cfa!-create-vector-app */ obj_t 
cfa__create_vector_app_163_cfa_vector(obj_t env_3766, obj_t node_3767)
{
   {
      create_vector_app_150_t node_2956;
      {
	 approx_t aux_4326;
	 node_2956 = (create_vector_app_150_t) (node_3767);
	 {
	    obj_t l2091_2960;
	    {
	       app_t obj_3585;
	       obj_3585 = (app_t) (node_2956);
	       l2091_2960 = (((app_t) CREF(obj_3585))->args);
	    }
	  lname2092_2961:
	    if (PAIRP(l2091_2960))
	      {
		 {
		    node_t aux_4329;
		    {
		       obj_t aux_4330;
		       aux_4330 = CAR(l2091_2960);
		       aux_4329 = (node_t) (aux_4330);
		    }
		    cfa__102_cfa_cfa(aux_4329);
		 }
		 {
		    obj_t l2091_4334;
		    l2091_4334 = CDR(l2091_2960);
		    l2091_2960 = l2091_4334;
		    goto lname2092_2961;
		 }
	      }
	    else
	      {
		 ((bool_t) 1);
	      }
	 }
	 {
	    obj_t aux_4338;
	    {
	       object_t aux_4339;
	       aux_4339 = (object_t) (node_2956);
	       aux_4338 = OBJECT_WIDENING(aux_4339);
	    }
	    aux_4326 = (((create_vector_app_150_t) CREF(aux_4338))->approx);
	 }
	 return (obj_t) (aux_4326);
      }
   }
}


/* cfa!-make-vector-app */ obj_t 
cfa__make_vector_app_74_cfa_vector(obj_t env_3768, obj_t node_3769)
{
   {
      make_vector_app_205_t node_2944;
      {
	 approx_t aux_4345;
	 node_2944 = (make_vector_app_205_t) (node_3769);
	 {
	    node_t aux_4346;
	    {
	       obj_t aux_4347;
	       {
		  obj_t aux_4348;
		  {
		     app_t obj_3576;
		     obj_3576 = (app_t) (node_2944);
		     aux_4348 = (((app_t) CREF(obj_3576))->args);
		  }
		  aux_4347 = CAR(aux_4348);
	       }
	       aux_4346 = (node_t) (aux_4347);
	    }
	    cfa__102_cfa_cfa(aux_4346);
	 }
	 {
	    approx_t init_value_approx_9_2950;
	    {
	       node_t aux_4354;
	       {
		  obj_t aux_4355;
		  {
		     obj_t aux_4356;
		     {
			obj_t aux_4357;
			{
			   app_t obj_3578;
			   obj_3578 = (app_t) (node_2944);
			   aux_4357 = (((app_t) CREF(obj_3578))->args);
			}
			aux_4356 = CDR(aux_4357);
		     }
		     aux_4355 = CAR(aux_4356);
		  }
		  aux_4354 = (node_t) (aux_4355);
	       }
	       init_value_approx_9_2950 = cfa__102_cfa_cfa(aux_4354);
	    }
	    {
	       approx_t aux_4364;
	       {
		  obj_t aux_4365;
		  {
		     object_t aux_4366;
		     aux_4366 = (object_t) (node_2944);
		     aux_4365 = OBJECT_WIDENING(aux_4366);
		  }
		  aux_4364 = (((make_vector_app_205_t) CREF(aux_4365))->value_approx_19);
	       }
	       union_approx__241_cfa_approx(aux_4364, init_value_approx_9_2950);
	    }
	    {
	       obj_t aux_4371;
	       {
		  object_t aux_4372;
		  aux_4372 = (object_t) (node_2944);
		  aux_4371 = OBJECT_WIDENING(aux_4372);
	       }
	       aux_4345 = (((make_vector_app_205_t) CREF(aux_4371))->approx);
	    }
	 }
	 return (obj_t) (aux_4345);
      }
   }
}


/* node-setup!-pre-vector-set!-app */ obj_t 
node_setup__pre_vector_set__app_35_cfa_vector(obj_t env_3770, obj_t node_3771)
{
   {
      pre_vector_set__app_211_t node_2928;
      {
	 vector_set__app_21_t aux_4378;
	 node_2928 = (pre_vector_set__app_211_t) (node_3771);
	 {
	    obj_t aux_4379;
	    {
	       app_t obj_3558;
	       obj_3558 = (app_t) (node_2928);
	       aux_4379 = (((app_t) CREF(obj_3558))->args);
	    }
	    node_setup___185_cfa_setup(aux_4379);
	 }
	 {
	    pre_vector_set__app_211_t node_2933;
	    {
	       long arg2414_2939;
	       {
		  obj_t arg2415_2940;
		  {
		     obj_t arg2416_2941;
		     {
			object_t object_3559;
			object_3559 = (object_t) (node_2928);
			{
			   long arg1180_3560;
			   {
			      long arg1181_3561;
			      long arg1182_3562;
			      arg1181_3561 = TYPE(object_3559);
			      arg1182_3562 = OBJECT_TYPE;
			      arg1180_3560 = (arg1181_3561 - arg1182_3562);
			   }
			   {
			      obj_t vector_3566;
			      vector_3566 = _classes__134___object;
			      arg2416_2941 = VECTOR_REF(vector_3566, arg1180_3560);
			   }
			}
		     }
		     arg2415_2940 = class_super_145___object(arg2416_2941);
		  }
		  arg2414_2939 = class_num_218___object(arg2415_2940);
	       }
	       {
		  obj_t obj_3568;
		  obj_3568 = (obj_t) (node_2928);
		  (((obj_t) CREF(obj_3568))->header = MAKE_HEADER(arg2414_2939, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4392;
	       aux_4392 = (object_t) (node_2928);
	       OBJECT_WIDENING_SET(aux_4392, BFALSE);
	    }
	    node_2933 = node_2928;
	    {
	       vector_set__app_21_t obj2088_2934;
	       obj2088_2934 = ((vector_set__app_21_t) (node_2933));
	       {
		  vector_set__app_21_t arg2411_2935;
		  {
		     approx_t arg2412_2936;
		     arg2412_2936 = make_type_approx_184_cfa_approx((type_t) (_unspec__87_type_cache));
		     {
			vector_set__app_21_t res2532_3573;
			{
			   vector_set__app_21_t new1986_3571;
			   new1986_3571 = ((vector_set__app_21_t) BREF(GC_MALLOC(sizeof(struct vector_set__app_21))));
			   ((((vector_set__app_21_t) CREF(new1986_3571))->approx) = ((approx_t) arg2412_2936), BUNSPEC);
			   res2532_3573 = new1986_3571;
			}
			arg2411_2935 = res2532_3573;
		     }
		  }
		  {
		     obj_t aux_4402;
		     object_t aux_4400;
		     aux_4402 = (obj_t) (arg2411_2935);
		     aux_4400 = (object_t) (obj2088_2934);
		     OBJECT_WIDENING_SET(aux_4400, aux_4402);
		  }
	       }
	       {
		  long arg2413_2937;
		  arg2413_2937 = class_num_218___object(vector_set__app_21_cfa_info);
		  {
		     obj_t obj_3574;
		     obj_3574 = (obj_t) (obj2088_2934);
		     (((obj_t) CREF(obj_3574))->header = MAKE_HEADER(arg2413_2937, 0), BUNSPEC);
		  }
	       }
	       aux_4378 = obj2088_2934;
	    }
	 }
	 return (obj_t) (aux_4378);
      }
   }
}


/* node-setup!-pre-vector-ref-app */ obj_t 
node_setup__pre_vector_ref_app_36_cfa_vector(obj_t env_3772, obj_t node_3773)
{
   {
      pre_vector_ref_app_208_t node_2912;
      {
	 vector_ref_app_195_t aux_4410;
	 node_2912 = (pre_vector_ref_app_208_t) (node_3773);
	 {
	    obj_t aux_4411;
	    {
	       app_t obj_3540;
	       obj_3540 = (app_t) (node_2912);
	       aux_4411 = (((app_t) CREF(obj_3540))->args);
	    }
	    node_setup___185_cfa_setup(aux_4411);
	 }
	 {
	    pre_vector_ref_app_208_t node_2917;
	    {
	       long arg2406_2923;
	       {
		  obj_t arg2407_2924;
		  {
		     obj_t arg2408_2925;
		     {
			object_t object_3541;
			object_3541 = (object_t) (node_2912);
			{
			   long arg1180_3542;
			   {
			      long arg1181_3543;
			      long arg1182_3544;
			      arg1181_3543 = TYPE(object_3541);
			      arg1182_3544 = OBJECT_TYPE;
			      arg1180_3542 = (arg1181_3543 - arg1182_3544);
			   }
			   {
			      obj_t vector_3548;
			      vector_3548 = _classes__134___object;
			      arg2408_2925 = VECTOR_REF(vector_3548, arg1180_3542);
			   }
			}
		     }
		     arg2407_2924 = class_super_145___object(arg2408_2925);
		  }
		  arg2406_2923 = class_num_218___object(arg2407_2924);
	       }
	       {
		  obj_t obj_3550;
		  obj_3550 = (obj_t) (node_2912);
		  (((obj_t) CREF(obj_3550))->header = MAKE_HEADER(arg2406_2923, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4424;
	       aux_4424 = (object_t) (node_2912);
	       OBJECT_WIDENING_SET(aux_4424, BFALSE);
	    }
	    node_2917 = node_2912;
	    {
	       vector_ref_app_195_t obj2085_2918;
	       obj2085_2918 = ((vector_ref_app_195_t) (node_2917));
	       {
		  vector_ref_app_195_t arg2403_2919;
		  {
		     approx_t arg2404_2920;
		     arg2404_2920 = make_empty_approx_131_cfa_approx();
		     {
			vector_ref_app_195_t res2531_3555;
			{
			   vector_ref_app_195_t new1974_3553;
			   new1974_3553 = ((vector_ref_app_195_t) BREF(GC_MALLOC(sizeof(struct vector_ref_app_195))));
			   ((((vector_ref_app_195_t) CREF(new1974_3553))->approx) = ((approx_t) arg2404_2920), BUNSPEC);
			   res2531_3555 = new1974_3553;
			}
			arg2403_2919 = res2531_3555;
		     }
		  }
		  {
		     obj_t aux_4433;
		     object_t aux_4431;
		     aux_4433 = (obj_t) (arg2403_2919);
		     aux_4431 = (object_t) (obj2085_2918);
		     OBJECT_WIDENING_SET(aux_4431, aux_4433);
		  }
	       }
	       {
		  long arg2405_2921;
		  arg2405_2921 = class_num_218___object(vector_ref_app_195_cfa_info);
		  {
		     obj_t obj_3556;
		     obj_3556 = (obj_t) (obj2085_2918);
		     (((obj_t) CREF(obj_3556))->header = MAKE_HEADER(arg2405_2921, 0), BUNSPEC);
		  }
	       }
	       aux_4410 = obj2085_2918;
	    }
	 }
	 return (obj_t) (aux_4410);
      }
   }
}


/* node-setup!-pre-create-vector-app */ obj_t 
node_setup__pre_create_vector_app_101_cfa_vector(obj_t env_3774, obj_t node_3775)
{
   {
      pre_create_vector_app_162_t node_2889;
      node_2889 = (pre_create_vector_app_162_t) (node_3775);
      add_make_vector__104_cfa_tvector((node_t) (node_2889));
      {
	 obj_t aux_4443;
	 {
	    app_t obj_3507;
	    obj_3507 = (app_t) (node_2889);
	    aux_4443 = (((app_t) CREF(obj_3507))->args);
	 }
	 node_setup___185_cfa_setup(aux_4443);
      }
      {
	 variable_t owner_2894;
	 {
	    obj_t aux_4447;
	    {
	       object_t aux_4448;
	       aux_4448 = (object_t) (node_2889);
	       aux_4447 = OBJECT_WIDENING(aux_4448);
	    }
	    owner_2894 = (((pre_create_vector_app_162_t) CREF(aux_4447))->owner);
	 }
	 {
	    pre_create_vector_app_162_t node_2895;
	    {
	       long arg2396_2907;
	       {
		  obj_t arg2399_2908;
		  {
		     obj_t arg2400_2909;
		     {
			object_t object_3509;
			object_3509 = (object_t) (node_2889);
			{
			   long arg1180_3510;
			   {
			      long arg1181_3511;
			      long arg1182_3512;
			      arg1181_3511 = TYPE(object_3509);
			      arg1182_3512 = OBJECT_TYPE;
			      arg1180_3510 = (arg1181_3511 - arg1182_3512);
			   }
			   {
			      obj_t vector_3516;
			      vector_3516 = _classes__134___object;
			      arg2400_2909 = VECTOR_REF(vector_3516, arg1180_3510);
			   }
			}
		     }
		     arg2399_2908 = class_super_145___object(arg2400_2909);
		  }
		  arg2396_2907 = class_num_218___object(arg2399_2908);
	       }
	       {
		  obj_t obj_3518;
		  obj_3518 = (obj_t) (node_2889);
		  (((obj_t) CREF(obj_3518))->header = MAKE_HEADER(arg2396_2907, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4461;
	       aux_4461 = (object_t) (node_2889);
	       OBJECT_WIDENING_SET(aux_4461, BFALSE);
	    }
	    node_2895 = node_2889;
	    {
	       {
		  create_vector_app_150_t wnode_2896;
		  {
		     create_vector_app_150_t obj2082_2898;
		     obj2082_2898 = ((create_vector_app_150_t) (node_2895));
		     {
			create_vector_app_150_t arg2385_2899;
			{
			   approx_t arg2386_2900;
			   approx_t arg2387_2901;
			   arg2386_2900 = make_empty_approx_131_cfa_approx();
			   arg2387_2901 = make_empty_approx_131_cfa_approx();
			   {
			      create_vector_app_150_t res2530_3535;
			      {
				 create_vector_app_150_t new1951_3527;
				 new1951_3527 = ((create_vector_app_150_t) BREF(GC_MALLOC(sizeof(struct create_vector_app_150))));
				 ((((create_vector_app_150_t) CREF(new1951_3527))->approx) = ((approx_t) arg2386_2900), BUNSPEC);
				 ((((create_vector_app_150_t) CREF(new1951_3527))->value_approx_19) = ((approx_t) arg2387_2901), BUNSPEC);
				 ((((create_vector_app_150_t) CREF(new1951_3527))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
				 ((((create_vector_app_150_t) CREF(new1951_3527))->owner) = ((variable_t) owner_2894), BUNSPEC);
				 ((((create_vector_app_150_t) CREF(new1951_3527))->stackable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				 ((((create_vector_app_150_t) CREF(new1951_3527))->stack_stamp_31) = ((obj_t) BNIL), BUNSPEC);
				 ((((create_vector_app_150_t) CREF(new1951_3527))->seen__39) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				 res2530_3535 = new1951_3527;
			      }
			      arg2385_2899 = res2530_3535;
			   }
			}
			{
			   obj_t aux_4477;
			   object_t aux_4475;
			   aux_4477 = (obj_t) (arg2385_2899);
			   aux_4475 = (object_t) (obj2082_2898);
			   OBJECT_WIDENING_SET(aux_4475, aux_4477);
			}
		     }
		     {
			long arg2394_2905;
			arg2394_2905 = class_num_218___object(create_vector_app_150_cfa_info);
			{
			   obj_t obj_3536;
			   obj_3536 = (obj_t) (obj2082_2898);
			   (((obj_t) CREF(obj_3536))->header = MAKE_HEADER(arg2394_2905, 0), BUNSPEC);
			}
		     }
		     wnode_2896 = obj2082_2898;
		  }
		  {
		     approx_t arg2384_2897;
		     arg2384_2897 = make_type_alloc_approx_134_cfa_approx((type_t) (_vector__240_type_cache), (node_t) (node_2895));
		     {
			obj_t aux_4486;
			{
			   object_t aux_4487;
			   aux_4487 = (object_t) (wnode_2896);
			   aux_4486 = OBJECT_WIDENING(aux_4487);
			}
			return ((((create_vector_app_150_t) CREF(aux_4486))->approx) = ((approx_t) arg2384_2897), BUNSPEC);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* node-setup!-pre-make-vector-app */ obj_t 
node_setup__pre_make_vector_app_233_cfa_vector(obj_t env_3776, obj_t node_3777)
{
   {
      pre_make_vector_app_251_t node_2866;
      node_2866 = (pre_make_vector_app_251_t) (node_3777);
      add_make_vector__104_cfa_tvector((node_t) (node_2866));
      {
	 obj_t aux_4494;
	 {
	    app_t obj_3474;
	    obj_3474 = (app_t) (node_2866);
	    aux_4494 = (((app_t) CREF(obj_3474))->args);
	 }
	 node_setup___185_cfa_setup(aux_4494);
      }
      {
	 variable_t owner_2871;
	 {
	    obj_t aux_4498;
	    {
	       object_t aux_4499;
	       aux_4499 = (object_t) (node_2866);
	       aux_4498 = OBJECT_WIDENING(aux_4499);
	    }
	    owner_2871 = (((pre_make_vector_app_251_t) CREF(aux_4498))->owner);
	 }
	 {
	    pre_make_vector_app_251_t node_2872;
	    {
	       long arg2379_2884;
	       {
		  obj_t arg2380_2885;
		  {
		     obj_t arg2381_2886;
		     {
			object_t object_3476;
			object_3476 = (object_t) (node_2866);
			{
			   long arg1180_3477;
			   {
			      long arg1181_3478;
			      long arg1182_3479;
			      arg1181_3478 = TYPE(object_3476);
			      arg1182_3479 = OBJECT_TYPE;
			      arg1180_3477 = (arg1181_3478 - arg1182_3479);
			   }
			   {
			      obj_t vector_3483;
			      vector_3483 = _classes__134___object;
			      arg2381_2886 = VECTOR_REF(vector_3483, arg1180_3477);
			   }
			}
		     }
		     arg2380_2885 = class_super_145___object(arg2381_2886);
		  }
		  arg2379_2884 = class_num_218___object(arg2380_2885);
	       }
	       {
		  obj_t obj_3485;
		  obj_3485 = (obj_t) (node_2866);
		  (((obj_t) CREF(obj_3485))->header = MAKE_HEADER(arg2379_2884, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_4512;
	       aux_4512 = (object_t) (node_2866);
	       OBJECT_WIDENING_SET(aux_4512, BFALSE);
	    }
	    node_2872 = node_2866;
	    {
	       {
		  make_vector_app_205_t wnode_2873;
		  {
		     make_vector_app_205_t obj2079_2875;
		     obj2079_2875 = ((make_vector_app_205_t) (node_2872));
		     {
			make_vector_app_205_t arg2372_2876;
			{
			   approx_t arg2373_2877;
			   approx_t arg2374_2878;
			   arg2373_2877 = make_empty_approx_131_cfa_approx();
			   arg2374_2878 = make_empty_approx_131_cfa_approx();
			   {
			      make_vector_app_205_t res2529_3502;
			      {
				 make_vector_app_205_t new1928_3494;
				 new1928_3494 = ((make_vector_app_205_t) BREF(GC_MALLOC(sizeof(struct make_vector_app_205))));
				 ((((make_vector_app_205_t) CREF(new1928_3494))->approx) = ((approx_t) arg2373_2877), BUNSPEC);
				 ((((make_vector_app_205_t) CREF(new1928_3494))->value_approx_19) = ((approx_t) arg2374_2878), BUNSPEC);
				 ((((make_vector_app_205_t) CREF(new1928_3494))->lost_stamp_114) = ((long) ((long) -1)), BUNSPEC);
				 ((((make_vector_app_205_t) CREF(new1928_3494))->owner) = ((variable_t) owner_2871), BUNSPEC);
				 ((((make_vector_app_205_t) CREF(new1928_3494))->stackable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				 ((((make_vector_app_205_t) CREF(new1928_3494))->stack_stamp_31) = ((obj_t) BNIL), BUNSPEC);
				 ((((make_vector_app_205_t) CREF(new1928_3494))->seen__39) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				 res2529_3502 = new1928_3494;
			      }
			      arg2372_2876 = res2529_3502;
			   }
			}
			{
			   obj_t aux_4528;
			   object_t aux_4526;
			   aux_4528 = (obj_t) (arg2372_2876);
			   aux_4526 = (object_t) (obj2079_2875);
			   OBJECT_WIDENING_SET(aux_4526, aux_4528);
			}
		     }
		     {
			long arg2378_2882;
			arg2378_2882 = class_num_218___object(make_vector_app_205_cfa_info);
			{
			   obj_t obj_3503;
			   obj_3503 = (obj_t) (obj2079_2875);
			   (((obj_t) CREF(obj_3503))->header = MAKE_HEADER(arg2378_2882, 0), BUNSPEC);
			}
		     }
		     wnode_2873 = obj2079_2875;
		  }
		  {
		     approx_t arg2371_2874;
		     arg2371_2874 = make_type_alloc_approx_134_cfa_approx((type_t) (_vector__240_type_cache), (node_t) (node_2872));
		     {
			obj_t aux_4537;
			{
			   object_t aux_4538;
			   aux_4538 = (object_t) (wnode_2873);
			   aux_4537 = OBJECT_WIDENING(aux_4538);
			}
			return ((((make_vector_app_205_t) CREF(aux_4537))->approx) = ((approx_t) arg2371_2874), BUNSPEC);
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_vector()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_VECTOR");
   module_initialization_70_tools_error(((long) 0), "CFA_VECTOR");
   module_initialization_70_tools_shape(((long) 0), "CFA_VECTOR");
   module_initialization_70_type_type(((long) 0), "CFA_VECTOR");
   module_initialization_70_type_cache(((long) 0), "CFA_VECTOR");
   module_initialization_70_ast_var(((long) 0), "CFA_VECTOR");
   module_initialization_70_ast_node(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_info(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_loose(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_iterate(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_cfa(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_setup(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_approx(((long) 0), "CFA_VECTOR");
   module_initialization_70_cfa_tvector(((long) 0), "CFA_VECTOR");
   return module_initialization_70_cfa_stack(((long) 0), "CFA_VECTOR");
}
