/*===========================================================================*/
/*   (Rgc/rgc-compile.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern bool_t state__130___rgc_dfa(obj_t);
extern obj_t rgcset_add__25___rgc_set(obj_t, int);
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t compile_state_68___rgc_compile(obj_t, obj_t);
extern obj_t state_positions_249___rgc_dfa(obj_t);
static long _case_threshold__147___rgc_compile;
extern obj_t rgcset_remove__162___rgc_set(obj_t, int);
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63___rgc_compile();
extern obj_t _res1__155___r5_control_features_6_4;
static obj_t compile_case_regular_110___rgc_compile(obj_t, obj_t, obj_t);
extern obj_t _rgc_optim__189___rgc_config;
static obj_t insort___rgc_compile(int, obj_t);
static obj_t split_transitions_162___rgc_compile(obj_t);
static obj_t compile_match_32___rgc_compile(obj_t);
static obj_t _compile_dfa_161___rgc_compile(obj_t, obj_t, obj_t);
extern int rgcset_length_163___rgc_set(obj_t);
extern obj_t rgcset_not_149___rgc_set(obj_t);
static obj_t loop___rgc_compile(obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t compile_regular_76___rgc_compile(obj_t, obj_t, obj_t);
extern obj_t rgcset__list_240___rgc_set(obj_t);
extern obj_t module_initialization_70___rgc_compile(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___rgc_rules(long, char *);
extern obj_t module_initialization_70___rgc_dfa(long, char *);
extern obj_t module_initialization_70___rgc_set(long, char *);
extern obj_t module_initialization_70___rgc_config(long, char *);
extern obj_t compile_dfa_101___rgc_compile(obj_t, obj_t);
extern obj_t _res_number__75___r5_control_features_6_4;
extern obj_t state_name_114___rgc_dfa(obj_t);
extern bool_t special_char_match__17___rgc_rules(int);
extern obj_t state_transitions_152___rgc_dfa(obj_t);
static obj_t compile_range_test_13___rgc_compile(obj_t, obj_t);
extern long list_length(obj_t);
static obj_t state_transition_list_218___rgc_compile(obj_t);
static obj_t compile_cond_regular_182___rgc_compile(obj_t, obj_t, obj_t);
extern obj_t list__rgcset_152___rgc_set(obj_t, int);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t compile_case_transition_96___rgc_compile(obj_t, obj_t, obj_t);
static obj_t symbol1941___rgc_compile = BUNSPEC;
static obj_t symbol1939___rgc_compile = BUNSPEC;
static obj_t symbol1940___rgc_compile = BUNSPEC;
extern bool_t special_char__16___rgc_rules(int);
static obj_t symbol1938___rgc_compile = BUNSPEC;
static obj_t symbol1937___rgc_compile = BUNSPEC;
static obj_t symbol1936___rgc_compile = BUNSPEC;
static obj_t symbol1935___rgc_compile = BUNSPEC;
static obj_t symbol1934___rgc_compile = BUNSPEC;
static obj_t symbol1933___rgc_compile = BUNSPEC;
static obj_t symbol1932___rgc_compile = BUNSPEC;
static obj_t symbol1931___rgc_compile = BUNSPEC;
static obj_t symbol1929___rgc_compile = BUNSPEC;
static obj_t symbol1930___rgc_compile = BUNSPEC;
static obj_t symbol1928___rgc_compile = BUNSPEC;
static obj_t symbol1927___rgc_compile = BUNSPEC;
static obj_t symbol1926___rgc_compile = BUNSPEC;
static obj_t symbol1925___rgc_compile = BUNSPEC;
static obj_t symbol1924___rgc_compile = BUNSPEC;
static obj_t symbol1923___rgc_compile = BUNSPEC;
static obj_t symbol1922___rgc_compile = BUNSPEC;
static obj_t symbol1921___rgc_compile = BUNSPEC;
static obj_t symbol1919___rgc_compile = BUNSPEC;
static obj_t symbol1920___rgc_compile = BUNSPEC;
static obj_t symbol1918___rgc_compile = BUNSPEC;
static obj_t symbol1917___rgc_compile = BUNSPEC;
static obj_t symbol1916___rgc_compile = BUNSPEC;
extern bool_t rgcset_member__212___rgc_set(obj_t, int);
static obj_t compile_cond_test_218___rgc_compile(obj_t, obj_t, long);
static obj_t imported_modules_init_94___rgc_compile();
extern int special_match_char__rule_number_1___rgc_rules(int);
extern obj_t rgc_max_char_237___rgc_config();
static obj_t require_initialization_114___rgc_compile = BUNSPEC;
extern obj_t predicate_match_30___rgc_rules(int);
static obj_t cnst_init_137___rgc_compile();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t compile_submatches_51___rgc_compile(obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( compile_dfa_env_25___rgc_compile, _compile_dfa_161___rgc_compile1943, _compile_dfa_161___rgc_compile, 0L, 2 );


/* module-initialization */obj_t module_initialization_70___rgc_compile(long checksum_1601, char * from_1602)
{
if(CBOOL(require_initialization_114___rgc_compile)){
require_initialization_114___rgc_compile = BBOOL(((bool_t)0));
cnst_init_137___rgc_compile();
imported_modules_init_94___rgc_compile();
toplevel_init_63___rgc_compile();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___rgc_compile()
{
symbol1916___rgc_compile = string_to_symbol("DEFINE");
symbol1917___rgc_compile = string_to_symbol("LAST-MATCH");
symbol1918___rgc_compile = string_to_symbol("LET");
symbol1919___rgc_compile = string_to_symbol("NEW-MATCH");
symbol1920___rgc_compile = string_to_symbol("BEGIN");
symbol1921___rgc_compile = string_to_symbol("CURRENT-CHAR::INT");
symbol1922___rgc_compile = string_to_symbol("RGC-BUFFER-GET-CHAR");
symbol1923___rgc_compile = string_to_symbol("INPUT-PORT");
symbol1924___rgc_compile = string_to_symbol("IF");
symbol1925___rgc_compile = string_to_symbol("RGC-BUFFER-EMPTY?");
symbol1926___rgc_compile = string_to_symbol("RGC-FILL-BUFFER");
symbol1927___rgc_compile = string_to_symbol("RGC-FILL-BUFFER-IF-EMPTY");
symbol1928___rgc_compile = string_to_symbol("CASE");
symbol1929___rgc_compile = string_to_symbol("CURRENT-CHAR");
symbol1930___rgc_compile = string_to_symbol("ELSE");
symbol1931___rgc_compile = string_to_symbol("=FX");
symbol1932___rgc_compile = string_to_symbol("COND");
symbol1933___rgc_compile = string_to_symbol("NOT");
symbol1934___rgc_compile = string_to_symbol("OR");
symbol1935___rgc_compile = string_to_symbol(">=FX");
symbol1936___rgc_compile = string_to_symbol("<FX");
symbol1937___rgc_compile = string_to_symbol("AND");
symbol1938___rgc_compile = string_to_symbol("RGC-STOP-MATCH!");
symbol1939___rgc_compile = string_to_symbol("RGC-SUBMATCH-START*!");
symbol1940___rgc_compile = string_to_symbol("RGC-SUBMATCH-START!");
return (symbol1941___rgc_compile = string_to_symbol("RGC-SUBMATCH-STOP!"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___rgc_compile()
{
if(CBOOL(_rgc_optim__189___rgc_config)){
return (_case_threshold__147___rgc_compile = (((long)80)/((long)2)),
BUNSPEC);
}
 else {
return (_case_threshold__147___rgc_compile = ((long)80),
BUNSPEC);
}
}


/* compile-dfa */obj_t compile_dfa_101___rgc_compile(obj_t submatches_1, obj_t states_2)
{
if(NULLP(states_2)){
return BNIL;
}
 else {
obj_t head1004_339;
head1004_339 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1002_1231;
obj_t tail1005_1232;
l1002_1231 = states_2;
tail1005_1232 = head1004_339;
lname1003_1230:
if(NULLP(l1002_1231)){
return CDR(head1004_339);
}
 else {
obj_t newtail1006_1240;
{
obj_t arg1051_1241;
arg1051_1241 = compile_state_68___rgc_compile(submatches_1, CAR(l1002_1231));
newtail1006_1240 = MAKE_PAIR(arg1051_1241, BNIL);
}
SET_CDR(tail1005_1232, newtail1006_1240);
{
obj_t tail1005_1650;
obj_t l1002_1648;
l1002_1648 = CDR(l1002_1231);
tail1005_1650 = newtail1006_1240;
tail1005_1232 = tail1005_1650;
l1002_1231 = l1002_1648;
goto lname1003_1230;
}
}
}
}
}


/* _compile-dfa */obj_t _compile_dfa_161___rgc_compile(obj_t env_1593, obj_t submatches_1594, obj_t states_1595)
{
return compile_dfa_101___rgc_compile(submatches_1594, states_1595);
}


/* compile-state */obj_t compile_state_68___rgc_compile(obj_t submatches_3, obj_t state_4)
{
{
obj_t arg1056_351;
obj_t arg1057_352;
obj_t arg1058_353;
arg1056_351 = symbol1916___rgc_compile;
{
obj_t arg1065_359;
obj_t arg1066_360;
arg1065_359 = state_name_114___rgc_dfa(state_4);
arg1066_360 = symbol1917___rgc_compile;
{
obj_t list1068_362;
{
obj_t arg1069_363;
arg1069_363 = MAKE_PAIR(BNIL, BNIL);
list1068_362 = MAKE_PAIR(arg1066_360, arg1069_363);
}
arg1057_352 = cons__138___r4_pairs_and_lists_6_3(arg1065_359, list1068_362);
}
}
{
obj_t transitions_365;
obj_t positions_366;
transitions_365 = state_transitions_152___rgc_dfa(state_4);
positions_366 = state_positions_249___rgc_dfa(state_4);
if(NULLP(transitions_365)){
arg1058_353 = symbol1917___rgc_compile;
}
 else {
obj_t special_trans_74_368;
special_trans_74_368 = split_transitions_162___rgc_compile(transitions_365);
{
obj_t regular_trans_27_369;
regular_trans_27_369 = _res1__155___r5_control_features_6_4;
{
obj_t match_body_253_370;
match_body_253_370 = compile_match_32___rgc_compile(special_trans_74_368);
if(CBOOL(match_body_253_370)){
obj_t arg1072_371;
obj_t arg1073_372;
obj_t arg1076_373;
arg1072_371 = symbol1918___rgc_compile;
{
obj_t arg1080_377;
{
obj_t arg1084_381;
arg1084_381 = symbol1919___rgc_compile;
{
obj_t list1086_383;
{
obj_t arg1087_384;
arg1087_384 = MAKE_PAIR(BNIL, BNIL);
list1086_383 = MAKE_PAIR(match_body_253_370, arg1087_384);
}
arg1080_377 = cons__138___r4_pairs_and_lists_6_3(arg1084_381, list1086_383);
}
}
{
obj_t list1082_379;
list1082_379 = MAKE_PAIR(BNIL, BNIL);
arg1073_372 = cons__138___r4_pairs_and_lists_6_3(arg1080_377, list1082_379);
}
}
{
obj_t arg1089_386;
obj_t arg1090_387;
arg1089_386 = compile_submatches_51___rgc_compile(submatches_3, positions_366);
{
obj_t arg1091_388;
arg1091_388 = compile_regular_76___rgc_compile(state_4, regular_trans_27_369, symbol1919___rgc_compile);
{
obj_t list1093_390;
list1093_390 = MAKE_PAIR(BNIL, BNIL);
arg1090_387 = cons__138___r4_pairs_and_lists_6_3(arg1091_388, list1093_390);
}
}
arg1076_373 = append_2_18___r4_pairs_and_lists_6_3(arg1089_386, arg1090_387);
}
{
obj_t list1077_374;
{
obj_t arg1078_375;
arg1078_375 = MAKE_PAIR(arg1076_373, BNIL);
list1077_374 = MAKE_PAIR(arg1073_372, arg1078_375);
}
arg1058_353 = cons__138___r4_pairs_and_lists_6_3(arg1072_371, list1077_374);
}
}
 else {
obj_t arg1096_393;
obj_t arg1097_394;
arg1096_393 = symbol1920___rgc_compile;
{
obj_t arg1100_397;
obj_t arg1101_398;
arg1100_397 = compile_submatches_51___rgc_compile(submatches_3, positions_366);
{
obj_t arg1102_399;
arg1102_399 = compile_regular_76___rgc_compile(state_4, regular_trans_27_369, symbol1917___rgc_compile);
{
obj_t list1104_401;
list1104_401 = MAKE_PAIR(BNIL, BNIL);
arg1101_398 = cons__138___r4_pairs_and_lists_6_3(arg1102_399, list1104_401);
}
}
arg1097_394 = append_2_18___r4_pairs_and_lists_6_3(arg1100_397, arg1101_398);
}
{
obj_t list1098_395;
list1098_395 = MAKE_PAIR(arg1097_394, BNIL);
arg1058_353 = cons__138___r4_pairs_and_lists_6_3(arg1096_393, list1098_395);
}
}
}
}
}
}
{
obj_t list1060_355;
{
obj_t arg1061_356;
{
obj_t arg1062_357;
arg1062_357 = MAKE_PAIR(BNIL, BNIL);
arg1061_356 = MAKE_PAIR(arg1058_353, arg1062_357);
}
list1060_355 = MAKE_PAIR(arg1057_352, arg1061_356);
}
return cons__138___r4_pairs_and_lists_6_3(arg1056_351, list1060_355);
}
}
}


/* split-transitions */obj_t split_transitions_162___rgc_compile(obj_t transitions_5)
{
{
obj_t transitions_404;
obj_t specials_405;
obj_t regulars_406;
transitions_404 = transitions_5;
specials_405 = BNIL;
regulars_406 = BNIL;
loop_407:
if(NULLP(transitions_404)){
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = regulars_406;
return specials_405;
}
 else {
bool_t test1110_413;
{
int aux_1691;
{
obj_t aux_1692;
{
obj_t aux_1693;
aux_1693 = CAR(transitions_404);
aux_1692 = CAR(aux_1693);
}
aux_1691 = CINT(aux_1692);
}
test1110_413 = special_char__16___rgc_rules(aux_1691);
}
if(test1110_413){
{
obj_t arg1111_414;
obj_t arg1112_415;
arg1111_414 = CDR(transitions_404);
{
obj_t aux_1700;
aux_1700 = CAR(transitions_404);
arg1112_415 = MAKE_PAIR(aux_1700, specials_405);
}
{
obj_t specials_1704;
obj_t transitions_1703;
transitions_1703 = arg1111_414;
specials_1704 = arg1112_415;
specials_405 = specials_1704;
transitions_404 = transitions_1703;
goto loop_407;
}
}
}
 else {
{
obj_t arg1114_417;
obj_t arg1115_418;
arg1114_417 = CDR(transitions_404);
{
obj_t aux_1706;
aux_1706 = CAR(transitions_404);
arg1115_418 = MAKE_PAIR(aux_1706, regulars_406);
}
{
obj_t regulars_1710;
obj_t transitions_1709;
transitions_1709 = arg1114_417;
regulars_1710 = arg1115_418;
regulars_406 = regulars_1710;
transitions_404 = transitions_1709;
goto loop_407;
}
}
}
}
}
}


/* compile-regular */obj_t compile_regular_76___rgc_compile(obj_t current_state_117_6, obj_t transitions_7, obj_t last_match_133_8)
{
{
obj_t state_trans_188_422;
state_trans_188_422 = state_transition_list_218___rgc_compile(transitions_7);
if(NULLP(state_trans_188_422)){
return last_match_133_8;
}
 else {
obj_t arg1120_424;
obj_t arg1121_425;
obj_t arg1122_426;
arg1120_424 = symbol1918___rgc_compile;
{
obj_t arg1128_432;
{
obj_t arg1132_436;
obj_t arg1133_437;
arg1132_436 = symbol1921___rgc_compile;
{
obj_t arg1139_442;
obj_t arg1140_443;
arg1139_442 = symbol1922___rgc_compile;
arg1140_443 = symbol1923___rgc_compile;
{
obj_t list1142_445;
{
obj_t arg1143_446;
arg1143_446 = MAKE_PAIR(BNIL, BNIL);
list1142_445 = MAKE_PAIR(arg1140_443, arg1143_446);
}
arg1133_437 = cons__138___r4_pairs_and_lists_6_3(arg1139_442, list1142_445);
}
}
{
obj_t list1135_439;
{
obj_t arg1136_440;
arg1136_440 = MAKE_PAIR(BNIL, BNIL);
list1135_439 = MAKE_PAIR(arg1133_437, arg1136_440);
}
arg1128_432 = cons__138___r4_pairs_and_lists_6_3(arg1132_436, list1135_439);
}
}
{
obj_t list1130_434;
list1130_434 = MAKE_PAIR(BNIL, BNIL);
arg1121_425 = cons__138___r4_pairs_and_lists_6_3(arg1128_432, list1130_434);
}
}
{
bool_t test_1722;
{
long aux_1723;
aux_1723 = list_length(state_trans_188_422);
test_1722 = (aux_1723<=((long)12));
}
if(test_1722){
arg1122_426 = compile_cond_regular_182___rgc_compile(current_state_117_6, state_trans_188_422, last_match_133_8);
}
 else {
arg1122_426 = compile_case_regular_110___rgc_compile(current_state_117_6, state_trans_188_422, last_match_133_8);
}
}
{
obj_t list1124_428;
{
obj_t arg1125_429;
{
obj_t arg1126_430;
arg1126_430 = MAKE_PAIR(BNIL, BNIL);
arg1125_429 = MAKE_PAIR(arg1122_426, arg1126_430);
}
list1124_428 = MAKE_PAIR(arg1121_425, arg1125_429);
}
return cons__138___r4_pairs_and_lists_6_3(arg1120_424, list1124_428);
}
}
}
}


/* compile-case-regular */obj_t compile_case_regular_110___rgc_compile(obj_t current_state_117_9, obj_t state_trans_188_10, obj_t match_11)
{
{
obj_t sentinel_match_56_453;
sentinel_match_56_453 = MAKE_CELL(BUNSPEC);
{
CELL_SET(sentinel_match_56_453, BFALSE);
{
obj_t arg1148_454;
obj_t arg1150_455;
obj_t arg1151_456;
arg1148_454 = symbol1928___rgc_compile;
arg1150_455 = symbol1929___rgc_compile;
{
obj_t arg1155_460;
obj_t arg1156_461;
if(NULLP(state_trans_188_10)){
arg1155_460 = BNIL;
}
 else {
obj_t head1011_464;
{
obj_t arg1164_475;
arg1164_475 = compile_case_transition_96___rgc_compile(match_11, sentinel_match_56_453, CAR(state_trans_188_10));
head1011_464 = MAKE_PAIR(arg1164_475, BNIL);
}
{
obj_t l1009_1304;
obj_t tail1012_1305;
l1009_1304 = CDR(state_trans_188_10);
tail1012_1305 = head1011_464;
lname1010_1303:
if(NULLP(l1009_1304)){
arg1155_460 = head1011_464;
}
 else {
obj_t newtail1013_1313;
{
obj_t arg1161_1314;
arg1161_1314 = compile_case_transition_96___rgc_compile(match_11, sentinel_match_56_453, CAR(l1009_1304));
newtail1013_1313 = MAKE_PAIR(arg1161_1314, BNIL);
}
SET_CDR(tail1012_1305, newtail1013_1313);
{
obj_t tail1012_1745;
obj_t l1009_1743;
l1009_1743 = CDR(l1009_1304);
tail1012_1745 = newtail1013_1313;
tail1012_1305 = tail1012_1745;
l1009_1304 = l1009_1743;
goto lname1010_1303;
}
}
}
}
{
obj_t arg1167_478;
obj_t arg1168_479;
{
bool_t test1191_506;
test1191_506 = state__130___rgc_dfa(CELL_REF(sentinel_match_56_453));
if(test1191_506){
obj_t arg1192_507;
obj_t arg1193_508;
{
obj_t list1201_515;
list1201_515 = MAKE_PAIR(BNIL, BNIL);
arg1192_507 = cons__138___r4_pairs_and_lists_6_3(BINT(((long)0)), list1201_515);
}
{
obj_t arg1203_517;
obj_t arg1204_518;
obj_t arg1205_519;
obj_t arg1206_520;
arg1203_517 = symbol1924___rgc_compile;
{
obj_t arg1214_527;
obj_t arg1216_528;
arg1214_527 = symbol1925___rgc_compile;
arg1216_528 = symbol1923___rgc_compile;
{
obj_t list1220_530;
{
obj_t arg1221_531;
arg1221_531 = MAKE_PAIR(BNIL, BNIL);
list1220_530 = MAKE_PAIR(arg1216_528, arg1221_531);
}
arg1204_518 = cons__138___r4_pairs_and_lists_6_3(arg1214_527, list1220_530);
}
}
{
obj_t arg1224_533;
obj_t arg1225_534;
obj_t arg1226_535;
arg1224_533 = symbol1924___rgc_compile;
{
obj_t arg1235_542;
obj_t arg1236_543;
arg1235_542 = symbol1926___rgc_compile;
arg1236_543 = symbol1923___rgc_compile;
{
obj_t list1239_545;
{
obj_t arg1240_546;
arg1240_546 = MAKE_PAIR(BNIL, BNIL);
list1239_545 = MAKE_PAIR(arg1236_543, arg1240_546);
}
arg1225_534 = cons__138___r4_pairs_and_lists_6_3(arg1235_542, list1239_545);
}
}
{
obj_t arg1243_548;
obj_t arg1244_549;
arg1243_548 = state_name_114___rgc_dfa(current_state_117_9);
arg1244_549 = symbol1917___rgc_compile;
{
obj_t list1246_551;
{
obj_t arg1247_552;
arg1247_552 = MAKE_PAIR(BNIL, BNIL);
list1246_551 = MAKE_PAIR(arg1244_549, arg1247_552);
}
arg1226_535 = cons__138___r4_pairs_and_lists_6_3(arg1243_548, list1246_551);
}
}
{
obj_t list1229_537;
{
obj_t arg1231_538;
{
obj_t arg1232_539;
{
obj_t arg1233_540;
arg1233_540 = MAKE_PAIR(BNIL, BNIL);
arg1232_539 = MAKE_PAIR(match_11, arg1233_540);
}
arg1231_538 = MAKE_PAIR(arg1226_535, arg1232_539);
}
list1229_537 = MAKE_PAIR(arg1225_534, arg1231_538);
}
arg1205_519 = cons__138___r4_pairs_and_lists_6_3(arg1224_533, list1229_537);
}
}
{
obj_t arg1250_554;
arg1250_554 = state_name_114___rgc_dfa(CELL_REF(sentinel_match_56_453));
{
obj_t list1252_556;
{
obj_t arg1253_557;
arg1253_557 = MAKE_PAIR(BNIL, BNIL);
list1252_556 = MAKE_PAIR(match_11, arg1253_557);
}
arg1206_520 = cons__138___r4_pairs_and_lists_6_3(arg1250_554, list1252_556);
}
}
{
obj_t list1208_522;
{
obj_t arg1209_523;
{
obj_t arg1210_524;
{
obj_t arg1211_525;
arg1211_525 = MAKE_PAIR(BNIL, BNIL);
arg1210_524 = MAKE_PAIR(arg1206_520, arg1211_525);
}
arg1209_523 = MAKE_PAIR(arg1205_519, arg1210_524);
}
list1208_522 = MAKE_PAIR(arg1204_518, arg1209_523);
}
arg1193_508 = cons__138___r4_pairs_and_lists_6_3(arg1203_517, list1208_522);
}
}
{
obj_t list1195_510;
{
obj_t arg1196_511;
arg1196_511 = MAKE_PAIR(BNIL, BNIL);
list1195_510 = MAKE_PAIR(arg1193_508, arg1196_511);
}
arg1167_478 = cons__138___r4_pairs_and_lists_6_3(arg1192_507, list1195_510);
}
}
 else {
obj_t arg1255_559;
obj_t arg1256_560;
{
obj_t list1264_567;
list1264_567 = MAKE_PAIR(BNIL, BNIL);
arg1255_559 = cons__138___r4_pairs_and_lists_6_3(BINT(((long)0)), list1264_567);
}
{
obj_t arg1267_569;
obj_t arg1268_570;
obj_t arg1269_571;
arg1267_569 = symbol1924___rgc_compile;
{
obj_t arg1278_578;
obj_t arg1281_579;
arg1278_578 = symbol1927___rgc_compile;
arg1281_579 = symbol1923___rgc_compile;
{
obj_t list1283_581;
{
obj_t arg1284_582;
arg1284_582 = MAKE_PAIR(BNIL, BNIL);
list1283_581 = MAKE_PAIR(arg1281_579, arg1284_582);
}
arg1268_570 = cons__138___r4_pairs_and_lists_6_3(arg1278_578, list1283_581);
}
}
{
obj_t arg1286_584;
obj_t arg1287_585;
arg1286_584 = state_name_114___rgc_dfa(current_state_117_9);
arg1287_585 = symbol1917___rgc_compile;
{
obj_t list1289_587;
{
obj_t arg1290_588;
arg1290_588 = MAKE_PAIR(BNIL, BNIL);
list1289_587 = MAKE_PAIR(arg1287_585, arg1290_588);
}
arg1269_571 = cons__138___r4_pairs_and_lists_6_3(arg1286_584, list1289_587);
}
}
{
obj_t list1271_573;
{
obj_t arg1272_574;
{
obj_t arg1273_575;
{
obj_t arg1274_576;
arg1274_576 = MAKE_PAIR(BNIL, BNIL);
arg1273_575 = MAKE_PAIR(match_11, arg1274_576);
}
arg1272_574 = MAKE_PAIR(arg1269_571, arg1273_575);
}
list1271_573 = MAKE_PAIR(arg1268_570, arg1272_574);
}
arg1256_560 = cons__138___r4_pairs_and_lists_6_3(arg1267_569, list1271_573);
}
}
{
obj_t list1258_562;
{
obj_t arg1259_563;
arg1259_563 = MAKE_PAIR(BNIL, BNIL);
list1258_562 = MAKE_PAIR(arg1256_560, arg1259_563);
}
arg1167_478 = cons__138___r4_pairs_and_lists_6_3(arg1255_559, list1258_562);
}
}
}
{
obj_t arg1173_484;
arg1173_484 = symbol1930___rgc_compile;
{
obj_t list1175_486;
{
obj_t arg1176_487;
arg1176_487 = MAKE_PAIR(BNIL, BNIL);
list1175_486 = MAKE_PAIR(match_11, arg1176_487);
}
arg1168_479 = cons__138___r4_pairs_and_lists_6_3(arg1173_484, list1175_486);
}
}
{
obj_t list1170_481;
{
obj_t arg1171_482;
arg1171_482 = MAKE_PAIR(BNIL, BNIL);
list1170_481 = MAKE_PAIR(arg1168_479, arg1171_482);
}
arg1156_461 = cons__138___r4_pairs_and_lists_6_3(arg1167_478, list1170_481);
}
}
arg1151_456 = append_2_18___r4_pairs_and_lists_6_3(arg1155_460, arg1156_461);
}
{
obj_t list1152_457;
{
obj_t arg1153_458;
arg1153_458 = MAKE_PAIR(arg1151_456, BNIL);
list1152_457 = MAKE_PAIR(arg1150_455, arg1153_458);
}
return cons__138___r4_pairs_and_lists_6_3(arg1148_454, list1152_457);
}
}
}
}
}


/* compile-case-transition */obj_t compile_case_transition_96___rgc_compile(obj_t match_1598, obj_t sentinel_match_56_1597, obj_t state_trans_188_489)
{
{
obj_t set_491;
obj_t state_492;
set_491 = CDR(state_trans_188_489);
state_492 = CAR(state_trans_188_489);
{
bool_t test1179_493;
test1179_493 = rgcset_member__212___rgc_set(set_491, (int)(((long)0)));
if(test1179_493){
CELL_SET(sentinel_match_56_1597, state_492);
rgcset_remove__162___rgc_set(set_491, (int)(((long)0)));
}
 else {
BUNSPEC;
}
}
{
obj_t case_test_148_494;
case_test_148_494 = rgcset__list_240___rgc_set(set_491);
{
obj_t arg1180_495;
{
obj_t arg1185_500;
arg1185_500 = state_name_114___rgc_dfa(state_492);
{
obj_t list1187_502;
{
obj_t arg1188_503;
arg1188_503 = MAKE_PAIR(BNIL, BNIL);
list1187_502 = MAKE_PAIR(match_1598, arg1188_503);
}
arg1180_495 = cons__138___r4_pairs_and_lists_6_3(arg1185_500, list1187_502);
}
}
{
obj_t list1182_497;
{
obj_t arg1183_498;
arg1183_498 = MAKE_PAIR(BNIL, BNIL);
list1182_497 = MAKE_PAIR(arg1180_495, arg1183_498);
}
return cons__138___r4_pairs_and_lists_6_3(case_test_148_494, list1182_497);
}
}
}
}
}


/* compile-cond-regular */obj_t compile_cond_regular_182___rgc_compile(obj_t current_state_117_12, obj_t state_trans_188_13, obj_t match_14)
{
{
obj_t sentinel_match_56_594;
sentinel_match_56_594 = BUNSPEC;
{
obj_t state_trans_188_632;
long prev_test_len_237_633;
sentinel_match_56_594 = BFALSE;
{
obj_t trans_595;
obj_t tests_596;
long cost_597;
long prev_len_63_598;
trans_595 = state_trans_188_13;
tests_596 = BNIL;
cost_597 = ((long)0);
prev_len_63_598 = ((long)0);
loop_599:
if(NULLP(trans_595)){
if((cost_597>_case_threshold__147___rgc_compile)){
return compile_case_regular_110___rgc_compile(current_state_117_12, state_trans_188_13, match_14);
}
 else {
obj_t arg1298_605;
obj_t arg1299_606;
obj_t arg1300_607;
arg1298_605 = symbol1932___rgc_compile;
{
bool_t test1351_654;
test1351_654 = state__130___rgc_dfa(sentinel_match_56_594);
if(test1351_654){
obj_t arg1352_655;
obj_t arg1353_656;
{
obj_t arg1363_661;
obj_t arg1364_662;
arg1363_661 = symbol1931___rgc_compile;
arg1364_662 = symbol1929___rgc_compile;
{
obj_t list1368_665;
{
obj_t arg1369_666;
{
obj_t arg1370_667;
arg1370_667 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1830;
aux_1830 = BINT(((long)0));
arg1369_666 = MAKE_PAIR(aux_1830, arg1370_667);
}
}
list1368_665 = MAKE_PAIR(arg1364_662, arg1369_666);
}
arg1352_655 = cons__138___r4_pairs_and_lists_6_3(arg1363_661, list1368_665);
}
}
{
obj_t arg1373_669;
obj_t arg1375_670;
obj_t arg1378_671;
obj_t arg1379_672;
arg1373_669 = symbol1924___rgc_compile;
{
obj_t arg1388_679;
obj_t arg1389_680;
arg1388_679 = symbol1925___rgc_compile;
arg1389_680 = symbol1923___rgc_compile;
{
obj_t list1391_682;
{
obj_t arg1392_683;
arg1392_683 = MAKE_PAIR(BNIL, BNIL);
list1391_682 = MAKE_PAIR(arg1389_680, arg1392_683);
}
arg1375_670 = cons__138___r4_pairs_and_lists_6_3(arg1388_679, list1391_682);
}
}
{
obj_t arg1395_685;
obj_t arg1396_686;
obj_t arg1397_687;
arg1395_685 = symbol1924___rgc_compile;
{
obj_t arg1407_694;
obj_t arg1408_695;
arg1407_694 = symbol1926___rgc_compile;
arg1408_695 = symbol1923___rgc_compile;
{
obj_t list1411_697;
{
obj_t arg1413_698;
arg1413_698 = MAKE_PAIR(BNIL, BNIL);
list1411_697 = MAKE_PAIR(arg1408_695, arg1413_698);
}
arg1396_686 = cons__138___r4_pairs_and_lists_6_3(arg1407_694, list1411_697);
}
}
{
obj_t arg1415_700;
obj_t arg1416_701;
arg1415_700 = state_name_114___rgc_dfa(current_state_117_12);
arg1416_701 = symbol1917___rgc_compile;
{
obj_t list1418_703;
{
obj_t arg1419_704;
arg1419_704 = MAKE_PAIR(BNIL, BNIL);
list1418_703 = MAKE_PAIR(arg1416_701, arg1419_704);
}
arg1397_687 = cons__138___r4_pairs_and_lists_6_3(arg1415_700, list1418_703);
}
}
{
obj_t list1399_689;
{
obj_t arg1401_690;
{
obj_t arg1402_691;
{
obj_t arg1403_692;
arg1403_692 = MAKE_PAIR(BNIL, BNIL);
arg1402_691 = MAKE_PAIR(match_14, arg1403_692);
}
arg1401_690 = MAKE_PAIR(arg1397_687, arg1402_691);
}
list1399_689 = MAKE_PAIR(arg1396_686, arg1401_690);
}
arg1378_671 = cons__138___r4_pairs_and_lists_6_3(arg1395_685, list1399_689);
}
}
{
obj_t arg1423_706;
arg1423_706 = state_name_114___rgc_dfa(sentinel_match_56_594);
{
obj_t list1427_708;
{
obj_t arg1428_709;
arg1428_709 = MAKE_PAIR(BNIL, BNIL);
list1427_708 = MAKE_PAIR(match_14, arg1428_709);
}
arg1379_672 = cons__138___r4_pairs_and_lists_6_3(arg1423_706, list1427_708);
}
}
{
obj_t list1382_674;
{
obj_t arg1383_675;
{
obj_t arg1384_676;
{
obj_t arg1385_677;
arg1385_677 = MAKE_PAIR(BNIL, BNIL);
arg1384_676 = MAKE_PAIR(arg1379_672, arg1385_677);
}
arg1383_675 = MAKE_PAIR(arg1378_671, arg1384_676);
}
list1382_674 = MAKE_PAIR(arg1375_670, arg1383_675);
}
arg1353_656 = cons__138___r4_pairs_and_lists_6_3(arg1373_669, list1382_674);
}
}
{
obj_t list1356_658;
{
obj_t arg1357_659;
arg1357_659 = MAKE_PAIR(BNIL, BNIL);
list1356_658 = MAKE_PAIR(arg1353_656, arg1357_659);
}
arg1299_606 = cons__138___r4_pairs_and_lists_6_3(arg1352_655, list1356_658);
}
}
 else {
obj_t arg1432_711;
obj_t arg1433_712;
{
obj_t arg1441_717;
obj_t arg1443_718;
arg1441_717 = symbol1931___rgc_compile;
arg1443_718 = symbol1929___rgc_compile;
{
obj_t list1447_721;
{
obj_t arg1448_722;
{
obj_t arg1449_723;
arg1449_723 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1863;
aux_1863 = BINT(((long)0));
arg1448_722 = MAKE_PAIR(aux_1863, arg1449_723);
}
}
list1447_721 = MAKE_PAIR(arg1443_718, arg1448_722);
}
arg1432_711 = cons__138___r4_pairs_and_lists_6_3(arg1441_717, list1447_721);
}
}
{
obj_t arg1453_725;
obj_t arg1454_726;
obj_t arg1455_727;
arg1453_725 = symbol1924___rgc_compile;
{
obj_t arg1464_734;
obj_t arg1465_735;
arg1464_734 = symbol1927___rgc_compile;
arg1465_735 = symbol1923___rgc_compile;
{
obj_t list1467_737;
{
obj_t arg1468_738;
arg1468_738 = MAKE_PAIR(BNIL, BNIL);
list1467_737 = MAKE_PAIR(arg1465_735, arg1468_738);
}
arg1454_726 = cons__138___r4_pairs_and_lists_6_3(arg1464_734, list1467_737);
}
}
{
obj_t arg1470_740;
obj_t arg1471_741;
arg1470_740 = state_name_114___rgc_dfa(current_state_117_12);
arg1471_741 = symbol1917___rgc_compile;
{
obj_t list1474_743;
{
obj_t arg1475_744;
arg1475_744 = MAKE_PAIR(BNIL, BNIL);
list1474_743 = MAKE_PAIR(arg1471_741, arg1475_744);
}
arg1455_727 = cons__138___r4_pairs_and_lists_6_3(arg1470_740, list1474_743);
}
}
{
obj_t list1457_729;
{
obj_t arg1458_730;
{
obj_t arg1460_731;
{
obj_t arg1461_732;
arg1461_732 = MAKE_PAIR(BNIL, BNIL);
arg1460_731 = MAKE_PAIR(match_14, arg1461_732);
}
arg1458_730 = MAKE_PAIR(arg1455_727, arg1460_731);
}
list1457_729 = MAKE_PAIR(arg1454_726, arg1458_730);
}
arg1433_712 = cons__138___r4_pairs_and_lists_6_3(arg1453_725, list1457_729);
}
}
{
obj_t list1437_714;
{
obj_t arg1438_715;
arg1438_715 = MAKE_PAIR(BNIL, BNIL);
list1437_714 = MAKE_PAIR(arg1433_712, arg1438_715);
}
arg1299_606 = cons__138___r4_pairs_and_lists_6_3(arg1432_711, list1437_714);
}
}
}
{
obj_t arg1304_611;
obj_t arg1307_612;
arg1304_611 = reverse__39___r4_pairs_and_lists_6_3(tests_596);
{
obj_t arg1308_613;
{
obj_t arg1313_617;
arg1313_617 = symbol1930___rgc_compile;
{
obj_t list1316_619;
{
obj_t arg1319_620;
arg1319_620 = MAKE_PAIR(BNIL, BNIL);
list1316_619 = MAKE_PAIR(match_14, arg1319_620);
}
arg1308_613 = cons__138___r4_pairs_and_lists_6_3(arg1313_617, list1316_619);
}
}
{
obj_t list1310_615;
list1310_615 = MAKE_PAIR(BNIL, BNIL);
arg1307_612 = cons__138___r4_pairs_and_lists_6_3(arg1308_613, list1310_615);
}
}
arg1300_607 = append_2_18___r4_pairs_and_lists_6_3(arg1304_611, arg1307_612);
}
{
obj_t list1301_608;
{
obj_t arg1302_609;
arg1302_609 = MAKE_PAIR(arg1300_607, BNIL);
list1301_608 = MAKE_PAIR(arg1299_606, arg1302_609);
}
return cons__138___r4_pairs_and_lists_6_3(arg1298_605, list1301_608);
}
}
}
 else {
obj_t test_622;
state_trans_188_632 = CAR(trans_595);
prev_test_len_237_633 = prev_len_63_598;
{
obj_t set_635;
obj_t state_636;
set_635 = CDR(state_trans_188_632);
state_636 = CAR(state_trans_188_632);
{
bool_t test1333_637;
test1333_637 = rgcset_member__212___rgc_set(set_635, (int)(((long)0)));
if(test1333_637){
sentinel_match_56_594 = state_636;
rgcset_remove__162___rgc_set(set_635, (int)(((long)0)));
}
 else {
BUNSPEC;
}
}
{
obj_t cond_test_38_638;
cond_test_38_638 = compile_cond_test_218___rgc_compile(set_635, symbol1929___rgc_compile, prev_test_len_237_633);
{
obj_t cond_cost_121_639;
cond_cost_121_639 = _res1__155___r5_control_features_6_4;
{
obj_t val0_1014_640;
{
obj_t arg1334_642;
{
obj_t arg1342_647;
arg1342_647 = state_name_114___rgc_dfa(state_636);
{
obj_t list1344_649;
{
obj_t arg1345_650;
arg1345_650 = MAKE_PAIR(BNIL, BNIL);
list1344_649 = MAKE_PAIR(match_14, arg1345_650);
}
arg1334_642 = cons__138___r4_pairs_and_lists_6_3(arg1342_647, list1344_649);
}
}
{
obj_t list1338_644;
{
obj_t arg1339_645;
arg1339_645 = MAKE_PAIR(BNIL, BNIL);
list1338_644 = MAKE_PAIR(arg1334_642, arg1339_645);
}
val0_1014_640 = cons__138___r4_pairs_and_lists_6_3(cond_test_38_638, list1338_644);
}
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = cond_cost_121_639;
test_622 = val0_1014_640;
}
}
}
}
{
obj_t c_623;
c_623 = _res1__155___r5_control_features_6_4;
{
obj_t arg1322_624;
obj_t arg1323_625;
long arg1324_626;
long arg1325_627;
arg1322_624 = CDR(trans_595);
arg1323_625 = MAKE_PAIR(test_622, tests_596);
{
long aux_1912;
aux_1912 = (long)CINT(c_623);
arg1324_626 = (aux_1912+cost_597);
}
{
int arg1326_628;
{
obj_t aux_1915;
{
obj_t aux_1916;
aux_1916 = CAR(trans_595);
aux_1915 = CDR(aux_1916);
}
arg1326_628 = rgcset_length_163___rgc_set(aux_1915);
}
{
long aux_1920;
aux_1920 = (long)(arg1326_628);
arg1325_627 = (prev_len_63_598+aux_1920);
}
}
{
long prev_len_63_1926;
long cost_1925;
obj_t tests_1924;
obj_t trans_1923;
trans_1923 = arg1322_624;
tests_1924 = arg1323_625;
cost_1925 = arg1324_626;
prev_len_63_1926 = arg1325_627;
prev_len_63_598 = prev_len_63_1926;
cost_597 = cost_1925;
tests_596 = tests_1924;
trans_595 = trans_1923;
goto loop_599;
}
}
}
}
}
}
}
}


/* compile-cond-test */obj_t compile_cond_test_218___rgc_compile(obj_t set_15, obj_t var_16, long prev_test_len_237_17)
{
{
obj_t max_752;
int len_753;
max_752 = rgc_max_char_237___rgc_config();
len_753 = rgcset_length_163___rgc_set(set_15);
{
bool_t test1477_754;
{
obj_t arg1489_771;
long arg1490_772;
arg1489_771 = rgc_max_char_237___rgc_config();
{
long aux_1930;
{
long aux_1931;
aux_1931 = (long)(len_753);
aux_1930 = (aux_1931+prev_test_len_237_17);
}
arg1490_772 = (((long)1)+aux_1930);
}
{
long aux_1935;
aux_1935 = (long)CINT(arg1489_771);
test1477_754 = (aux_1935==arg1490_772);
}
}
if(test1477_754){
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(((long)0));
return symbol1930___rgc_compile;
}
 else {
bool_t test_1941;
{
long aux_1944;
long aux_1942;
{
long aux_1945;
{
long aux_1946;
aux_1946 = (long)CINT(max_752);
aux_1945 = (aux_1946/((long)2));
}
aux_1944 = (((long)2)+aux_1945);
}
aux_1942 = (long)(len_753);
test_1941 = (aux_1942>aux_1944);
}
if(test_1941){
{
obj_t test_758;
{
obj_t arg1485_767;
arg1485_767 = rgcset_not_149___rgc_set(set_15);
test_758 = compile_range_test_13___rgc_compile(var_16, arg1485_767);
}
{
obj_t cost_759;
cost_759 = _res1__155___r5_control_features_6_4;
{
obj_t val0_1032_760;
long val1_1033_761;
{
obj_t arg1479_762;
arg1479_762 = symbol1933___rgc_compile;
{
obj_t list1481_764;
{
obj_t arg1483_765;
arg1483_765 = MAKE_PAIR(BNIL, BNIL);
list1481_764 = MAKE_PAIR(test_758, arg1483_765);
}
val0_1032_760 = cons__138___r4_pairs_and_lists_6_3(arg1479_762, list1481_764);
}
}
{
long aux_1956;
aux_1956 = (long)CINT(cost_759);
val1_1033_761 = (((long)1)+aux_1956);
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(val1_1033_761);
return val0_1032_760;
}
}
}
}
 else {
return compile_range_test_13___rgc_compile(var_16, set_15);
}
}
}
}
}


/* compile-range-test */obj_t compile_range_test_13___rgc_compile(obj_t var_1596, obj_t set_775)
{
{
obj_t start_801;
obj_t stop_802;
obj_t set_803;
{
obj_t start_777;
obj_t tests_778;
long cost_779;
{
long arg1496_781;
{
obj_t max_1386;
max_1386 = rgc_max_char_237___rgc_config();
{
long i_1388;
i_1388 = ((long)1);
loop_1387:
{
bool_t test_1963;
{
long aux_1964;
aux_1964 = (long)CINT(max_1386);
test_1963 = (i_1388==aux_1964);
}
if(test_1963){
arg1496_781 = ((long)-1);
}
 else {
bool_t test1609_1390;
test1609_1390 = rgcset_member__212___rgc_set(set_775, (int)(i_1388));
if(test1609_1390){
arg1496_781 = i_1388;
}
 else {
{
long i_1970;
i_1970 = (i_1388+((long)1));
i_1388 = i_1970;
goto loop_1387;
}
}
}
}
}
}
start_777 = BINT(arg1496_781);
tests_778 = BNIL;
cost_779 = ((long)0);
loop_780:
{
bool_t test_1972;
{
long aux_1973;
aux_1973 = (long)CINT(start_777);
test_1972 = (aux_1973==((long)-1));
}
if(test_1972){
obj_t val0_1028_785;
{
obj_t arg1500_787;
obj_t arg1501_788;
arg1500_787 = symbol1934___rgc_compile;
{
obj_t arg1504_791;
obj_t arg1505_792;
arg1504_791 = reverse__39___r4_pairs_and_lists_6_3(tests_778);
arg1505_792 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1501_788 = append_2_18___r4_pairs_and_lists_6_3(arg1504_791, arg1505_792);
}
{
obj_t list1502_789;
list1502_789 = MAKE_PAIR(arg1501_788, BNIL);
val0_1028_785 = cons__138___r4_pairs_and_lists_6_3(arg1500_787, list1502_789);
}
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(cost_779);
return val0_1028_785;
}
 else {
obj_t stop_795;
{
obj_t max_1400;
max_1400 = rgc_max_char_237___rgc_config();
{
obj_t i_1402;
i_1402 = start_777;
loop_1401:
{
bool_t test_1984;
{
long aux_1987;
long aux_1985;
aux_1987 = (long)CINT(max_1400);
aux_1985 = (long)CINT(i_1402);
test_1984 = (aux_1985==aux_1987);
}
if(test_1984){
stop_795 = max_1400;
}
 else {
bool_t test1605_1404;
test1605_1404 = rgcset_member__212___rgc_set(set_775, CINT(i_1402));
if(test1605_1404){
{
obj_t i_1993;
{
long aux_1994;
{
long aux_1995;
aux_1995 = (long)CINT(i_1402);
aux_1994 = (aux_1995+((long)1));
}
i_1993 = BINT(aux_1994);
}
i_1402 = i_1993;
goto loop_1401;
}
}
 else {
stop_795 = i_1402;
}
}
}
}
}
{
obj_t test_796;
start_801 = start_777;
stop_802 = stop_795;
set_803 = set_775;
{
bool_t test_1999;
{
long aux_2004;
long aux_2000;
aux_2004 = (long)CINT(start_801);
{
long aux_2001;
aux_2001 = (long)CINT(stop_802);
aux_2000 = (aux_2001-((long)1));
}
test_1999 = (aux_2000==aux_2004);
}
if(test_1999){
{
obj_t val0_1016_806;
{
obj_t arg1516_808;
arg1516_808 = symbol1931___rgc_compile;
{
obj_t list1518_810;
{
obj_t arg1519_811;
{
obj_t arg1522_812;
arg1522_812 = MAKE_PAIR(BNIL, BNIL);
arg1519_811 = MAKE_PAIR(start_801, arg1522_812);
}
list1518_810 = MAKE_PAIR(var_1596, arg1519_811);
}
val0_1016_806 = cons__138___r4_pairs_and_lists_6_3(arg1516_808, list1518_810);
}
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(((long)1));
test_796 = val0_1016_806;
}
}
 else {
bool_t test_2013;
{
long aux_2014;
{
long aux_2017;
long aux_2015;
aux_2017 = (long)CINT(start_801);
aux_2015 = (long)CINT(stop_802);
aux_2014 = (aux_2015-aux_2017);
}
test_2013 = (aux_2014<((long)4));
}
if(test_2013){
{
obj_t val0_1018_815;
long val1_1019_816;
{
obj_t arg1526_817;
obj_t arg1527_818;
arg1526_817 = symbol1934___rgc_compile;
{
obj_t arg1530_821;
obj_t arg1531_822;
{
obj_t start_823;
obj_t res_824;
start_823 = start_801;
res_824 = BNIL;
loop_825:
{
bool_t test_2021;
{
long aux_2024;
long aux_2022;
aux_2024 = (long)CINT(stop_802);
aux_2022 = (long)CINT(start_823);
test_2021 = (aux_2022==aux_2024);
}
if(test_2021){
arg1530_821 = res_824;
}
 else {
long arg1534_828;
obj_t arg1535_829;
{
long aux_2027;
aux_2027 = (long)CINT(start_823);
arg1534_828 = (aux_2027+((long)1));
}
{
obj_t arg1536_830;
{
obj_t arg1537_831;
arg1537_831 = symbol1931___rgc_compile;
{
obj_t list1540_833;
{
obj_t arg1542_834;
{
obj_t arg1545_835;
arg1545_835 = MAKE_PAIR(BNIL, BNIL);
arg1542_834 = MAKE_PAIR(start_823, arg1545_835);
}
list1540_833 = MAKE_PAIR(var_1596, arg1542_834);
}
arg1536_830 = cons__138___r4_pairs_and_lists_6_3(arg1537_831, list1540_833);
}
}
arg1535_829 = MAKE_PAIR(arg1536_830, res_824);
}
{
obj_t res_2037;
obj_t start_2035;
start_2035 = BINT(arg1534_828);
res_2037 = arg1535_829;
res_824 = res_2037;
start_823 = start_2035;
goto loop_825;
}
}
}
}
arg1531_822 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1527_818 = append_2_18___r4_pairs_and_lists_6_3(arg1530_821, arg1531_822);
}
{
obj_t list1528_819;
list1528_819 = MAKE_PAIR(arg1527_818, BNIL);
val0_1018_815 = cons__138___r4_pairs_and_lists_6_3(arg1526_817, list1528_819);
}
}
{
long aux_2044;
long aux_2042;
aux_2044 = (long)CINT(start_801);
aux_2042 = (long)CINT(stop_802);
val1_1019_816 = (aux_2042-aux_2044);
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(val1_1019_816);
test_796 = val0_1018_815;
}
}
 else {
bool_t test1551_839;
{
bool_t test1594_883;
{
obj_t arg1595_884;
arg1595_884 = rgc_max_char_237___rgc_config();
{
long aux_2052;
long aux_2050;
aux_2052 = (long)CINT(arg1595_884);
aux_2050 = (long)CINT(stop_802);
test1594_883 = (aux_2050==aux_2052);
}
}
if(test1594_883){
long aux_2056;
aux_2056 = (long)CINT(start_801);
test1551_839 = (aux_2056==((long)1));
}
 else {
test1551_839 = ((bool_t)0);
}
}
if(test1551_839){
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(((long)0));
test_796 = BTRUE;
}
 else {
bool_t test1552_842;
{
obj_t arg1593_882;
arg1593_882 = rgc_max_char_237___rgc_config();
{
long aux_2065;
long aux_2063;
aux_2065 = (long)CINT(arg1593_882);
aux_2063 = (long)CINT(stop_802);
test1552_842 = (aux_2063==aux_2065);
}
}
if(test1552_842){
{
obj_t val0_1022_843;
{
obj_t arg1553_845;
arg1553_845 = symbol1935___rgc_compile;
{
obj_t list1555_847;
{
obj_t arg1556_848;
{
obj_t arg1557_849;
arg1557_849 = MAKE_PAIR(BNIL, BNIL);
arg1556_848 = MAKE_PAIR(start_801, arg1557_849);
}
list1555_847 = MAKE_PAIR(var_1596, arg1556_848);
}
val0_1022_843 = cons__138___r4_pairs_and_lists_6_3(arg1553_845, list1555_847);
}
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(((long)1));
test_796 = val0_1022_843;
}
}
 else {
bool_t test_2075;
{
long aux_2076;
aux_2076 = (long)CINT(start_801);
test_2075 = (aux_2076==((long)1));
}
if(test_2075){
{
obj_t val0_1024_852;
{
obj_t arg1560_854;
arg1560_854 = symbol1936___rgc_compile;
{
obj_t list1562_856;
{
obj_t arg1563_857;
{
obj_t arg1564_858;
arg1564_858 = MAKE_PAIR(BNIL, BNIL);
arg1563_857 = MAKE_PAIR(stop_802, arg1564_858);
}
list1562_856 = MAKE_PAIR(var_1596, arg1563_857);
}
val0_1024_852 = cons__138___r4_pairs_and_lists_6_3(arg1560_854, list1562_856);
}
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(((long)1));
test_796 = val0_1024_852;
}
}
 else {
{
obj_t val0_1026_860;
{
obj_t arg1566_862;
obj_t arg1568_863;
obj_t arg1569_864;
arg1566_862 = symbol1937___rgc_compile;
{
obj_t arg1578_870;
arg1578_870 = symbol1935___rgc_compile;
{
obj_t list1581_872;
{
obj_t arg1582_873;
{
obj_t arg1583_874;
arg1583_874 = MAKE_PAIR(BNIL, BNIL);
arg1582_873 = MAKE_PAIR(start_801, arg1583_874);
}
list1581_872 = MAKE_PAIR(var_1596, arg1582_873);
}
arg1568_863 = cons__138___r4_pairs_and_lists_6_3(arg1578_870, list1581_872);
}
}
{
obj_t arg1585_876;
arg1585_876 = symbol1936___rgc_compile;
{
obj_t list1587_878;
{
obj_t arg1588_879;
{
obj_t arg1589_880;
arg1589_880 = MAKE_PAIR(BNIL, BNIL);
arg1588_879 = MAKE_PAIR(stop_802, arg1589_880);
}
list1587_878 = MAKE_PAIR(var_1596, arg1588_879);
}
arg1569_864 = cons__138___r4_pairs_and_lists_6_3(arg1585_876, list1587_878);
}
}
{
obj_t list1571_866;
{
obj_t arg1572_867;
{
obj_t arg1573_868;
arg1573_868 = MAKE_PAIR(BNIL, BNIL);
arg1572_867 = MAKE_PAIR(arg1569_864, arg1573_868);
}
list1571_866 = MAKE_PAIR(arg1568_863, arg1572_867);
}
val0_1026_860 = cons__138___r4_pairs_and_lists_6_3(arg1566_862, list1571_866);
}
}
_res_number__75___r5_control_features_6_4 = BINT(((long)2));
_res1__155___r5_control_features_6_4 = BINT(((long)3));
test_796 = val0_1026_860;
}
}
}
}
}
}
}
{
obj_t c_797;
c_797 = _res1__155___r5_control_features_6_4;
{
obj_t arg1510_798;
obj_t arg1511_799;
long arg1513_800;
{
obj_t max_1412;
max_1412 = rgc_max_char_237___rgc_config();
{
obj_t i_1414;
i_1414 = stop_795;
loop_1413:
{
bool_t test_2100;
{
long aux_2103;
long aux_2101;
aux_2103 = (long)CINT(max_1412);
aux_2101 = (long)CINT(i_1414);
test_2100 = (aux_2101==aux_2103);
}
if(test_2100){
arg1510_798 = BINT(((long)-1));
}
 else {
bool_t test1609_1416;
test1609_1416 = rgcset_member__212___rgc_set(set_775, CINT(i_1414));
if(test1609_1416){
arg1510_798 = i_1414;
}
 else {
{
obj_t i_2110;
{
long aux_2111;
{
long aux_2112;
aux_2112 = (long)CINT(i_1414);
aux_2111 = (aux_2112+((long)1));
}
i_2110 = BINT(aux_2111);
}
i_1414 = i_2110;
goto loop_1413;
}
}
}
}
}
}
arg1511_799 = MAKE_PAIR(test_796, tests_778);
{
long aux_2117;
aux_2117 = (long)CINT(c_797);
arg1513_800 = (aux_2117+cost_779);
}
{
long cost_2122;
obj_t tests_2121;
obj_t start_2120;
start_2120 = arg1510_798;
tests_2121 = arg1511_799;
cost_2122 = arg1513_800;
cost_779 = cost_2122;
tests_778 = tests_2121;
start_777 = start_2120;
goto loop_780;
}
}
}
}
}
}
}
}
}
}


/* state-transition-list */obj_t state_transition_list_218___rgc_compile(obj_t transitions_18)
{
{
obj_t transitions_910;
obj_t res_911;
transitions_910 = transitions_18;
res_911 = BNIL;
loop_912:
if(NULLP(transitions_910)){
return res_911;
}
 else {
obj_t transition_915;
transition_915 = CAR(transitions_910);
{
obj_t char_916;
char_916 = CAR(transition_915);
{
obj_t state_917;
state_917 = CDR(transition_915);
{
{
obj_t cell_918;
cell_918 = assq___r4_pairs_and_lists_6_3(state_917, res_911);
if(PAIRP(cell_918)){
rgcset_add__25___rgc_set(CDR(cell_918), CINT(char_916));
{
obj_t transitions_2135;
transitions_2135 = CDR(transitions_910);
transitions_910 = transitions_2135;
goto loop_912;
}
}
 else {
obj_t set_922;
{
obj_t arg1622_926;
obj_t arg1623_927;
{
obj_t list1624_928;
list1624_928 = MAKE_PAIR(char_916, BNIL);
arg1622_926 = list1624_928;
}
arg1623_927 = rgc_max_char_237___rgc_config();
set_922 = list__rgcset_152___rgc_set(arg1622_926, CINT(arg1623_927));
}
{
obj_t arg1618_923;
obj_t arg1620_924;
arg1618_923 = CDR(transitions_910);
{
obj_t arg1621_925;
arg1621_925 = MAKE_PAIR(state_917, set_922);
arg1620_924 = MAKE_PAIR(arg1621_925, res_911);
}
{
obj_t res_2145;
obj_t transitions_2144;
transitions_2144 = arg1618_923;
res_2145 = arg1620_924;
res_911 = res_2145;
transitions_910 = transitions_2144;
goto loop_912;
}
}
}
}
}
}
}
}
}
}


/* insort */obj_t insort___rgc_compile(int el_19, obj_t lst_20)
{
if(NULLP(lst_20)){
{
obj_t list1627_931;
{
obj_t aux_2148;
aux_2148 = BINT(el_19);
list1627_931 = MAKE_PAIR(aux_2148, BNIL);
}
return list1627_931;
}
}
 else {
bool_t test_2151;
{
long aux_2154;
long aux_2152;
{
obj_t aux_2155;
aux_2155 = CAR(lst_20);
aux_2154 = (long)CINT(aux_2155);
}
aux_2152 = (long)(el_19);
test_2151 = (aux_2152<aux_2154);
}
if(test_2151){
{
obj_t aux_2159;
aux_2159 = BINT(el_19);
return MAKE_PAIR(aux_2159, lst_20);
}
}
 else {
bool_t test_2162;
{
long aux_2165;
long aux_2163;
{
obj_t aux_2166;
aux_2166 = CAR(lst_20);
aux_2165 = (long)CINT(aux_2166);
}
aux_2163 = (long)(el_19);
test_2162 = (aux_2163==aux_2165);
}
if(test_2162){
return lst_20;
}
 else {
{
obj_t arg1632_935;
obj_t arg1633_936;
arg1632_935 = CAR(lst_20);
arg1633_936 = insort___rgc_compile(el_19, CDR(lst_20));
return MAKE_PAIR(arg1632_935, arg1633_936);
}
}
}
}
}


/* compile-match */obj_t compile_match_32___rgc_compile(obj_t transitions_21)
{
{
obj_t matches_954;
{
obj_t transitions_941;
obj_t matches_942;
transitions_941 = transitions_21;
matches_942 = BNIL;
loop_943:
if(NULLP(transitions_941)){
matches_954 = matches_942;
if(NULLP(matches_954)){
return BFALSE;
}
 else {
return loop___rgc_compile(matches_954);
}
}
 else {
obj_t char_947;
{
obj_t aux_2179;
aux_2179 = CAR(transitions_941);
char_947 = CAR(aux_2179);
}
{
{
bool_t test1641_949;
test1641_949 = special_char_match__17___rgc_rules(CINT(char_947));
if(test1641_949){
obj_t arg1645_950;
obj_t arg1646_951;
arg1645_950 = CDR(transitions_941);
{
int arg1647_952;
arg1647_952 = special_match_char__rule_number_1___rgc_rules(CINT(char_947));
arg1646_951 = insort___rgc_compile(arg1647_952, matches_942);
}
{
obj_t matches_2190;
obj_t transitions_2189;
transitions_2189 = arg1645_950;
matches_2190 = arg1646_951;
matches_942 = matches_2190;
transitions_941 = transitions_2189;
goto loop_943;
}
}
 else {
obj_t transitions_2191;
transitions_2191 = CDR(transitions_941);
transitions_941 = transitions_2191;
goto loop_943;
}
}
}
}
}
}
}


/* loop */obj_t loop___rgc_compile(obj_t matches_957)
{
if(NULLP(matches_957)){
return symbol1917___rgc_compile;
}
 else {
obj_t match_960;
match_960 = CAR(matches_957);
{
obj_t preds_961;
preds_961 = predicate_match_30___rgc_rules(CINT(match_960));
{
if(PAIRP(preds_961)){
obj_t arg1653_963;
obj_t arg1654_964;
obj_t arg1655_965;
obj_t arg1656_966;
arg1653_963 = symbol1924___rgc_compile;
{
obj_t arg1666_973;
obj_t arg1667_974;
arg1666_973 = symbol1937___rgc_compile;
{
obj_t arg1670_977;
arg1670_977 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1667_974 = append_2_18___r4_pairs_and_lists_6_3(preds_961, arg1670_977);
}
{
obj_t list1668_975;
list1668_975 = MAKE_PAIR(arg1667_974, BNIL);
arg1654_964 = cons__138___r4_pairs_and_lists_6_3(arg1666_973, list1668_975);
}
}
{
obj_t arg1675_980;
obj_t arg1676_981;
arg1675_980 = symbol1920___rgc_compile;
{
obj_t arg1682_987;
obj_t arg1683_988;
arg1682_987 = symbol1938___rgc_compile;
arg1683_988 = symbol1923___rgc_compile;
{
obj_t list1685_990;
{
obj_t arg1686_991;
arg1686_991 = MAKE_PAIR(BNIL, BNIL);
list1685_990 = MAKE_PAIR(arg1683_988, arg1686_991);
}
arg1676_981 = cons__138___r4_pairs_and_lists_6_3(arg1682_987, list1685_990);
}
}
{
obj_t list1678_983;
{
obj_t arg1679_984;
{
obj_t arg1680_985;
arg1680_985 = MAKE_PAIR(BNIL, BNIL);
arg1679_984 = MAKE_PAIR(match_960, arg1680_985);
}
list1678_983 = MAKE_PAIR(arg1676_981, arg1679_984);
}
arg1655_965 = cons__138___r4_pairs_and_lists_6_3(arg1675_980, list1678_983);
}
}
arg1656_966 = loop___rgc_compile(CDR(matches_957));
{
obj_t list1658_968;
{
obj_t arg1659_969;
{
obj_t arg1661_970;
{
obj_t arg1663_971;
arg1663_971 = MAKE_PAIR(BNIL, BNIL);
arg1661_970 = MAKE_PAIR(arg1656_966, arg1663_971);
}
arg1659_969 = MAKE_PAIR(arg1655_965, arg1661_970);
}
list1658_968 = MAKE_PAIR(arg1654_964, arg1659_969);
}
return cons__138___r4_pairs_and_lists_6_3(arg1653_963, list1658_968);
}
}
 else {
obj_t arg1691_994;
obj_t arg1692_995;
arg1691_994 = symbol1920___rgc_compile;
{
obj_t arg1699_1001;
obj_t arg1700_1002;
arg1699_1001 = symbol1938___rgc_compile;
arg1700_1002 = symbol1923___rgc_compile;
{
obj_t list1702_1004;
{
obj_t arg1703_1005;
arg1703_1005 = MAKE_PAIR(BNIL, BNIL);
list1702_1004 = MAKE_PAIR(arg1700_1002, arg1703_1005);
}
arg1692_995 = cons__138___r4_pairs_and_lists_6_3(arg1699_1001, list1702_1004);
}
}
{
obj_t list1694_997;
{
obj_t arg1695_998;
{
obj_t arg1697_999;
arg1697_999 = MAKE_PAIR(BNIL, BNIL);
arg1695_998 = MAKE_PAIR(match_960, arg1697_999);
}
list1694_997 = MAKE_PAIR(arg1692_995, arg1695_998);
}
return cons__138___r4_pairs_and_lists_6_3(arg1691_994, list1694_997);
}
}
}
}
}
}


/* compile-submatches */obj_t compile_submatches_51___rgc_compile(obj_t submatches_22, obj_t positions_23)
{
{
obj_t positions_1008;
obj_t starts_1009;
obj_t stops_1010;
{
obj_t arg1705_1012;
arg1705_1012 = rgcset__list_240___rgc_set(positions_23);
positions_1008 = arg1705_1012;
starts_1009 = BNIL;
stops_1010 = BNIL;
loop_1011:
if(NULLP(positions_1008)){
obj_t arg1709_1016;
obj_t arg1710_1017;
if(NULLP(starts_1009)){
arg1709_1016 = BNIL;
}
 else {
obj_t head1036_1020;
head1036_1020 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1034_1021;
obj_t tail1037_1022;
l1034_1021 = starts_1009;
tail1037_1022 = head1036_1020;
lname1035_1023:
if(NULLP(l1034_1021)){
arg1709_1016 = CDR(head1036_1020);
}
 else {
obj_t newtail1038_1025;
{
obj_t arg1714_1027;
{
obj_t s_1030;
{
obj_t aux_2234;
aux_2234 = CAR(l1034_1021);
s_1030 = CAR(aux_2234);
}
{
bool_t test_2237;
{
obj_t aux_2238;
aux_2238 = CAR(s_1030);
test_2237 = CBOOL(aux_2238);
}
if(test_2237){
obj_t arg1718_1032;
obj_t arg1720_1033;
obj_t arg1721_1034;
arg1718_1032 = symbol1939___rgc_compile;
{
obj_t aux_2241;
aux_2241 = CDR(s_1030);
arg1720_1033 = CAR(aux_2241);
}
{
obj_t aux_2244;
{
obj_t aux_2245;
aux_2245 = CDR(s_1030);
aux_2244 = CDR(aux_2245);
}
arg1721_1034 = CAR(aux_2244);
}
{
obj_t list1723_1036;
{
obj_t arg1724_1037;
{
obj_t arg1725_1038;
arg1725_1038 = MAKE_PAIR(BNIL, BNIL);
arg1724_1037 = MAKE_PAIR(arg1721_1034, arg1725_1038);
}
list1723_1036 = MAKE_PAIR(arg1720_1033, arg1724_1037);
}
arg1714_1027 = cons__138___r4_pairs_and_lists_6_3(arg1718_1032, list1723_1036);
}
}
 else {
obj_t arg1727_1040;
obj_t arg1728_1041;
obj_t arg1729_1042;
arg1727_1040 = symbol1940___rgc_compile;
{
obj_t aux_2253;
aux_2253 = CDR(s_1030);
arg1728_1041 = CAR(aux_2253);
}
{
obj_t aux_2256;
{
obj_t aux_2257;
aux_2257 = CDR(s_1030);
aux_2256 = CDR(aux_2257);
}
arg1729_1042 = CAR(aux_2256);
}
{
obj_t list1731_1044;
{
obj_t arg1732_1045;
{
obj_t arg1733_1046;
arg1733_1046 = MAKE_PAIR(BNIL, BNIL);
arg1732_1045 = MAKE_PAIR(arg1729_1042, arg1733_1046);
}
list1731_1044 = MAKE_PAIR(arg1728_1041, arg1732_1045);
}
arg1714_1027 = cons__138___r4_pairs_and_lists_6_3(arg1727_1040, list1731_1044);
}
}
}
}
newtail1038_1025 = MAKE_PAIR(arg1714_1027, BNIL);
}
SET_CDR(tail1037_1022, newtail1038_1025);
{
obj_t tail1037_2269;
obj_t l1034_2267;
l1034_2267 = CDR(l1034_1021);
tail1037_2269 = newtail1038_1025;
tail1037_1022 = tail1037_2269;
l1034_1021 = l1034_2267;
goto lname1035_1023;
}
}
}
}
if(NULLP(stops_1010)){
arg1710_1017 = BNIL;
}
 else {
obj_t head1041_1052;
head1041_1052 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1039_1053;
obj_t tail1042_1054;
l1039_1053 = stops_1010;
tail1042_1054 = head1041_1052;
lname1040_1055:
if(NULLP(l1039_1053)){
arg1710_1017 = CDR(head1041_1052);
}
 else {
obj_t newtail1043_1057;
{
obj_t arg1744_1059;
{
obj_t stop_1061;
stop_1061 = CAR(l1039_1053);
{
obj_t arg1746_1062;
obj_t arg1747_1063;
obj_t arg1748_1064;
arg1746_1062 = symbol1941___rgc_compile;
{
obj_t aux_2277;
aux_2277 = CAR(stop_1061);
arg1747_1063 = CAR(aux_2277);
}
{
obj_t aux_2280;
aux_2280 = CAR(stop_1061);
arg1748_1064 = CDR(aux_2280);
}
{
obj_t list1750_1066;
{
obj_t arg1753_1067;
{
obj_t arg1755_1068;
arg1755_1068 = MAKE_PAIR(BNIL, BNIL);
arg1753_1067 = MAKE_PAIR(arg1748_1064, arg1755_1068);
}
list1750_1066 = MAKE_PAIR(arg1747_1063, arg1753_1067);
}
arg1744_1059 = cons__138___r4_pairs_and_lists_6_3(arg1746_1062, list1750_1066);
}
}
}
newtail1043_1057 = MAKE_PAIR(arg1744_1059, BNIL);
}
SET_CDR(tail1042_1054, newtail1043_1057);
{
obj_t tail1042_2291;
obj_t l1039_2289;
l1039_2289 = CDR(l1039_1053);
tail1042_2291 = newtail1043_1057;
tail1042_1054 = tail1042_2291;
l1039_1053 = l1039_2289;
goto lname1040_1055;
}
}
}
}
return append_2_18___r4_pairs_and_lists_6_3(arg1709_1016, arg1710_1017);
}
 else {
obj_t cell_1073;
{
long aux_2293;
{
obj_t aux_2294;
aux_2294 = CAR(positions_1008);
aux_2293 = (long)CINT(aux_2294);
}
cell_1073 = VECTOR_REF(submatches_22, aux_2293);
}
{
if(NULLP(cell_1073)){
obj_t positions_2300;
positions_2300 = CDR(positions_1008);
positions_1008 = positions_2300;
goto loop_1011;
}
 else {
obj_t start_1076;
start_1076 = CAR(cell_1073);
{
obj_t stop_1077;
stop_1077 = CDR(cell_1073);
{
obj_t new_starts_96_1078;
{
bool_t test_2304;
if(NULLP(start_1076)){
test_2304 = ((bool_t)1);
}
 else {
obj_t aux_2307;
aux_2307 = member___r4_pairs_and_lists_6_3(start_1076, starts_1009);
test_2304 = CBOOL(aux_2307);
}
if(test_2304){
new_starts_96_1078 = starts_1009;
}
 else {
new_starts_96_1078 = MAKE_PAIR(start_1076, starts_1009);
}
}
{
obj_t new_stops_100_1079;
{
bool_t test_2311;
if(NULLP(stop_1077)){
test_2311 = ((bool_t)1);
}
 else {
obj_t aux_2314;
aux_2314 = member___r4_pairs_and_lists_6_3(stop_1077, stops_1010);
test_2311 = CBOOL(aux_2314);
}
if(test_2311){
new_stops_100_1079 = stops_1010;
}
 else {
new_stops_100_1079 = MAKE_PAIR(stop_1077, stops_1010);
}
}
{
{
obj_t stops_2321;
obj_t starts_2320;
obj_t positions_2318;
positions_2318 = CDR(positions_1008);
starts_2320 = new_starts_96_1078;
stops_2321 = new_stops_100_1079;
stops_1010 = stops_2321;
starts_1009 = starts_2320;
positions_1008 = positions_2318;
goto loop_1011;
}
}
}
}
}
}
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___rgc_compile()
{
module_initialization_70___rgc_rules(((long)0), "__RGC_COMPILE");
module_initialization_70___rgc_dfa(((long)0), "__RGC_COMPILE");
module_initialization_70___rgc_set(((long)0), "__RGC_COMPILE");
module_initialization_70___rgc_config(((long)0), "__RGC_COMPILE");
return module_initialization_70___error(((long)0), "__RGC_COMPILE");
}

