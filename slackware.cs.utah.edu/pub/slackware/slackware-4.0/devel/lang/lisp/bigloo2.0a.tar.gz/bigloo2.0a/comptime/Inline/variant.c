/*===========================================================================*/
/*   (Inline/variant.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct local_variant_63
  {
     bool_t variant;
  }
                *local_variant_63_t;


static obj_t _local_variant_access_set_1714_178_inline_variant(obj_t, obj_t, obj_t);
static obj_t method_init_76_inline_variant();
extern obj_t local_variant_name_14_inline_variant(local_t);
extern obj_t local_variant_access_set__216_inline_variant(local_t, obj_t);
static obj_t object__struct_local_variant_205_inline_variant(obj_t, obj_t);
static obj_t _remove_invariant_args_1705_230_inline_variant(obj_t, obj_t);
static obj_t _object__struct1731_27___object(obj_t, obj_t);
static obj_t _local_variant_type1711_227_inline_variant(obj_t, obj_t);
extern obj_t var_ast_node;
extern obj_t local_variant_fast_alpha_set__19_inline_variant(local_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
static obj_t _local_variant_removable_set_1718_76_inline_variant(obj_t, obj_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
static obj_t _local_variant_key1724_169_inline_variant(obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern obj_t local_variant_access_191_inline_variant(local_t);
static obj_t _widening1002_local_variant_190_inline_variant(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_inline_variant(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _local_variant_name_set_1708_209_inline_variant(obj_t, obj_t, obj_t);
static obj_t struct_object__object_local_variant_223_inline_variant(obj_t, obj_t, obj_t);
extern obj_t local_variant_variant_set__103_inline_variant(local_variant_63_t, bool_t);
extern obj_t shrink_args__237_inline_variant(variable_t);
static obj_t _shrink_args_1704_180_inline_variant(obj_t, obj_t);
static obj_t _substitutions1703_inline_variant(obj_t, obj_t, obj_t, obj_t);
static obj_t _local_variant_variant1726_6_inline_variant(obj_t, obj_t);
extern long class_num_218___object(obj_t);
static obj_t _local_variant_user_1723_78_inline_variant(obj_t, obj_t);
static obj_t _local_variant_value_set_1712_42_inline_variant(obj_t, obj_t, obj_t);
extern value_t local_variant_value_31_inline_variant(local_t);
static obj_t imported_modules_init_94_inline_variant();
static obj_t _local_variant_occurrence_set_1720_88_inline_variant(obj_t, obj_t, obj_t);
static obj_t _local_variant_removable1719_117_inline_variant(obj_t, obj_t);
extern obj_t local_variant_user__set__143_inline_variant(local_t, bool_t);
static obj_t _struct_object__object1729_128___object(obj_t, obj_t, obj_t);
extern type_t local_variant_type_2_inline_variant(local_t);
static obj_t _local_variant_fast_alpha_set_1716_151_inline_variant(obj_t, obj_t, obj_t);
extern local_t allocate_local_variant_108_inline_variant();
extern local_variant_63_t widening1002_local_variant_160_inline_variant(bool_t);
static obj_t _local_variant_access1715_73_inline_variant(obj_t, obj_t);
static obj_t _local_variant__184_inline_variant(obj_t, obj_t);
static obj_t library_modules_init_112_inline_variant();
extern obj_t local_variant_removable_17_inline_variant(local_t);
extern obj_t local_variant_occurrence_set__206_inline_variant(local_t, long);
extern obj_t make_struct(obj_t, long, obj_t);
static obj_t _variant_args1702_188_inline_variant(obj_t, obj_t);
extern obj_t variant_args_126_inline_variant(variable_t);
extern long local_variant_occurrence_19_inline_variant(local_t);
static obj_t _local_variant_user__set_1722_238_inline_variant(obj_t, obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _local_variant_id1707_17_inline_variant(obj_t, obj_t);
static obj_t _local_variant_name1709_220_inline_variant(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t local_variant_type_set__179_inline_variant(local_t, type_t);
extern app_t remove_invariant_args__113_inline_variant(app_t);
static obj_t _local_variant_type_set_1710_118_inline_variant(obj_t, obj_t, obj_t);
extern obj_t invariant_args_254_inline_variant(variable_t, obj_t);
static obj_t _local_variant_occurrence1721_203_inline_variant(obj_t, obj_t);
extern local_variant_63_t make_local_variant_132_inline_variant(obj_t, obj_t, type_t, value_t, obj_t, obj_t, obj_t, long, bool_t, long, bool_t);
static obj_t _local_variant_variant_set_1725_214_inline_variant(obj_t, obj_t, obj_t);
extern obj_t local_ast_var;
extern long local_variant_key_71_inline_variant(local_t);
extern bool_t local_variant_variant_215_inline_variant(local_variant_63_t);
extern bool_t local_variant__1_inline_variant(obj_t);
static obj_t _local_variant_value1713_252_inline_variant(obj_t, obj_t);
extern obj_t substitutions_inline_variant(variable_t, obj_t, obj_t);
extern obj_t local_variant_id_153_inline_variant(local_t);
static obj_t _make_local_variant1706_130_inline_variant(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t local_variant_name_set__245_inline_variant(local_t, obj_t);
static obj_t object_init_111_inline_variant();
extern obj_t local_variant_value_set__67_inline_variant(local_t, value_t);
extern obj_t local_variant_fast_alpha_32_inline_variant(local_t);
extern obj_t _classes__134___object;
static obj_t _local_variant_fast_alpha1717_163_inline_variant(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t local_variant_removable_set__23_inline_variant(local_t, obj_t);
static obj_t _invariant_args1701_17_inline_variant(obj_t, obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
static obj_t require_initialization_114_inline_variant = BUNSPEC;
extern obj_t class_super_145___object(obj_t);
extern bool_t local_variant_user__42_inline_variant(local_t);
obj_t local_variant_63_inline_variant = BUNSPEC;
static obj_t cnst_init_137_inline_variant();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t _allocate_local_variant_45_inline_variant(obj_t);
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(variant_args_env_178_inline_variant, _variant_args1702_188_inline_variant1742, _variant_args1702_188_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_access_env_2_inline_variant, _local_variant_access1715_73_inline_variant1743, _local_variant_access1715_73_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_fast_alpha_env_250_inline_variant, _local_variant_fast_alpha1717_163_inline_variant1744, _local_variant_fast_alpha1717_163_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_name_set__env_113_inline_variant, _local_variant_name_set_1708_209_inline_variant1745, _local_variant_name_set_1708_209_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_variant_variant_env_167_inline_variant, _local_variant_variant1726_6_inline_variant1746, _local_variant_variant1726_6_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_user__env_73_inline_variant, _local_variant_user_1723_78_inline_variant1747, _local_variant_user_1723_78_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_id_env_216_inline_variant, _local_variant_id1707_17_inline_variant1748, _local_variant_id1707_17_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_removable_env_195_inline_variant, _local_variant_removable1719_117_inline_variant1749, _local_variant_removable1719_117_inline_variant, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1733_inline_variant, struct_object__object_local_variant_223_inline_variant1750, struct_object__object_local_variant_223_inline_variant, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1732_inline_variant, object__struct_local_variant_205_inline_variant1751, object__struct_local_variant_205_inline_variant, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(local_variant_type_set__env_112_inline_variant, _local_variant_type_set_1710_118_inline_variant1752, _local_variant_type_set_1710_118_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_variant_name_env_225_inline_variant, _local_variant_name1709_220_inline_variant1753, _local_variant_name1709_220_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1002_local_variant_env_157_inline_variant, _widening1002_local_variant_190_inline_variant1754, _widening1002_local_variant_190_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_value_set__env_109_inline_variant, _local_variant_value_set_1712_42_inline_variant1755, _local_variant_value_set_1712_42_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_variant_value_env_99_inline_variant, _local_variant_value1713_252_inline_variant1756, _local_variant_value1713_252_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_local_variant_env_104_inline_variant, _make_local_variant1706_130_inline_variant1757, _make_local_variant1706_130_inline_variant, 0L, 11);
DEFINE_EXPORT_PROCEDURE(local_variant_access_set__env_213_inline_variant, _local_variant_access_set_1714_178_inline_variant1758, _local_variant_access_set_1714_178_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_local_variant_env_26_inline_variant, _allocate_local_variant_45_inline_variant1759, _allocate_local_variant_45_inline_variant, 0L, 0);
DEFINE_EXPORT_PROCEDURE(local_variant_occurrence_set__env_227_inline_variant, _local_variant_occurrence_set_1720_88_inline_variant1760, _local_variant_occurrence_set_1720_88_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(substitutions_env_195_inline_variant, _substitutions1703_inline_variant1761, _substitutions1703_inline_variant, 0L, 3);
DEFINE_EXPORT_PROCEDURE(remove_invariant_args__env_39_inline_variant, _remove_invariant_args_1705_230_inline_variant1762, _remove_invariant_args_1705_230_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_fast_alpha_set__env_102_inline_variant, _local_variant_fast_alpha_set_1716_151_inline_variant1763, _local_variant_fast_alpha_set_1716_151_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_variant_removable_set__env_241_inline_variant, _local_variant_removable_set_1718_76_inline_variant1764, _local_variant_removable_set_1718_76_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_variant_user__set__env_42_inline_variant, _local_variant_user__set_1722_238_inline_variant1765, _local_variant_user__set_1722_238_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(invariant_args_env_85_inline_variant, _invariant_args1701_17_inline_variant1766, _invariant_args1701_17_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(shrink_args__env_30_inline_variant, _shrink_args_1704_180_inline_variant1767, _shrink_args_1704_180_inline_variant, 0L, 1);
DEFINE_STRING(string1734_inline_variant, string1734_inline_variant1768, "LOCAL/VARIANT DONE READ ", 24);
DEFINE_EXPORT_PROCEDURE(local_variant_variant_set__env_21_inline_variant, _local_variant_variant_set_1725_214_inline_variant1769, _local_variant_variant_set_1725_214_inline_variant, 0L, 2);
DEFINE_EXPORT_PROCEDURE(local_variant_occurrence_env_102_inline_variant, _local_variant_occurrence1721_203_inline_variant1770, _local_variant_occurrence1721_203_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_key_env_136_inline_variant, _local_variant_key1724_169_inline_variant1771, _local_variant_key1724_169_inline_variant, 0L, 1);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(local_variant__env_233_inline_variant, _local_variant__184_inline_variant1772, _local_variant__184_inline_variant, 0L, 1);
DEFINE_EXPORT_PROCEDURE(local_variant_type_env_146_inline_variant, _local_variant_type1711_227_inline_variant1773, _local_variant_type1711_227_inline_variant, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_inline_variant(long checksum_1533, char *from_1534)
{
   if (CBOOL(require_initialization_114_inline_variant))
     {
	require_initialization_114_inline_variant = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_variant();
	cnst_init_137_inline_variant();
	imported_modules_init_94_inline_variant();
	object_init_111_inline_variant();
	method_init_76_inline_variant();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_variant()
{
   module_initialization_70___object(((long) 0), "INLINE_VARIANT");
   module_initialization_70___reader(((long) 0), "INLINE_VARIANT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_VARIANT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_variant()
{
   {
      obj_t cnst_port_138_1525;
      cnst_port_138_1525 = open_input_string(string1734_inline_variant);
      {
	 long i_1526;
	 i_1526 = ((long) 2);
       loop_1527:
	 {
	    bool_t test1735_1528;
	    test1735_1528 = (i_1526 == ((long) -1));
	    if (test1735_1528)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1738_1529;
		    {
		       obj_t list1739_1530;
		       {
			  obj_t arg1740_1531;
			  arg1740_1531 = BNIL;
			  list1739_1530 = MAKE_PAIR(cnst_port_138_1525, arg1740_1531);
		       }
		       arg1738_1529 = read___reader(list1739_1530);
		    }
		    CNST_TABLE_SET(i_1526, arg1738_1529);
		 }
		 {
		    int aux_1532;
		    {
		       long aux_1552;
		       aux_1552 = (i_1526 - ((long) 1));
		       aux_1532 = (int) (aux_1552);
		    }
		    {
		       long i_1555;
		       i_1555 = (long) (aux_1532);
		       i_1526 = i_1555;
		       goto loop_1527;
		    }
		 }
	      }
	 }
      }
   }
}


/* invariant-args */ obj_t 
invariant_args_254_inline_variant(variable_t var_1, obj_t calls_2)
{
   {
      obj_t args_746;
      {
	 sfun_t obj_1234;
	 {
	    value_t aux_1557;
	    aux_1557 = (((variable_t) CREF(var_1))->value);
	    obj_1234 = (sfun_t) (aux_1557);
	 }
	 args_746 = (((sfun_t) CREF(obj_1234))->args);
      }
      {
	 {
	    obj_t l1460_747;
	    l1460_747 = args_746;
	  lname1461_748:
	    if (PAIRP(l1460_747))
	      {
		 {
		    obj_t local_750;
		    local_750 = CAR(l1460_747);
		    {
		       bool_t test_1564;
		       {
			  obj_t aux_1568;
			  obj_t aux_1565;
			  aux_1568 = CNST_TABLE_REF(((long) 0));
			  {
			     local_t obj_1237;
			     obj_1237 = (local_t) (local_750);
			     aux_1565 = (((local_t) CREF(obj_1237))->access);
			  }
			  test_1564 = (aux_1565 == aux_1568);
		       }
		       if (test_1564)
			 {
			    local_variant_63_t obj1462_752;
			    obj1462_752 = ((local_variant_63_t) (local_750));
			    {
			       local_variant_63_t arg1477_753;
			       {
				  local_variant_63_t res1695_1243;
				  {
				     local_variant_63_t new1436_1241;
				     new1436_1241 = ((local_variant_63_t) BREF(GC_MALLOC(sizeof(struct local_variant_63))));
				     ((((local_variant_63_t) CREF(new1436_1241))->variant) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				     res1695_1243 = new1436_1241;
				  }
				  arg1477_753 = res1695_1243;
			       }
			       {
				  obj_t aux_1576;
				  object_t aux_1574;
				  aux_1576 = (obj_t) (arg1477_753);
				  aux_1574 = (object_t) (obj1462_752);
				  OBJECT_WIDENING_SET(aux_1574, aux_1576);
			       }
			    }
			    {
			       long arg1479_755;
			       arg1479_755 = class_num_218___object(local_variant_63_inline_variant);
			       {
				  obj_t obj_1244;
				  obj_1244 = (obj_t) (obj1462_752);
				  (((obj_t) CREF(obj_1244))->header = MAKE_HEADER(arg1479_755, 0), BUNSPEC);
			       }
			    }
			    obj1462_752;
			 }
		       else
			 {
			    local_variant_63_t obj1463_756;
			    obj1463_756 = ((local_variant_63_t) (local_750));
			    {
			       local_variant_63_t arg1480_757;
			       {
				  local_variant_63_t res1696_1249;
				  {
				     local_variant_63_t new1436_1247;
				     new1436_1247 = ((local_variant_63_t) BREF(GC_MALLOC(sizeof(struct local_variant_63))));
				     ((((local_variant_63_t) CREF(new1436_1247))->variant) = ((bool_t) ((bool_t) 1)), BUNSPEC);
				     res1696_1249 = new1436_1247;
				  }
				  arg1480_757 = res1696_1249;
			       }
			       {
				  obj_t aux_1587;
				  object_t aux_1585;
				  aux_1587 = (obj_t) (arg1480_757);
				  aux_1585 = (object_t) (obj1463_756);
				  OBJECT_WIDENING_SET(aux_1585, aux_1587);
			       }
			    }
			    {
			       long arg1483_759;
			       arg1483_759 = class_num_218___object(local_variant_63_inline_variant);
			       {
				  obj_t obj_1250;
				  obj_1250 = (obj_t) (obj1463_756);
				  (((obj_t) CREF(obj_1250))->header = MAKE_HEADER(arg1483_759, 0), BUNSPEC);
			       }
			    }
			    obj1463_756;
			 }
		    }
		 }
		 {
		    obj_t l1460_1593;
		    l1460_1593 = CDR(l1460_747);
		    l1460_747 = l1460_1593;
		    goto lname1461_748;
		 }
	      }
	    else
	      {
		 ((bool_t) 1);
	      }
	 }
	 {
	    obj_t l1464_763;
	    l1464_763 = calls_2;
	  lname1465_764:
	    if (PAIRP(l1464_763))
	      {
		 {
		    app_t app_766;
		    {
		       obj_t aux_1597;
		       aux_1597 = CAR(l1464_763);
		       app_766 = (app_t) (aux_1597);
		    }
		    {
		       obj_t actuals_767;
		       obj_t args_768;
		       actuals_767 = (((app_t) CREF(app_766))->args);
		       args_768 = args_746;
		     loop_769:
		       if (NULLP(args_768))
			 {
			    CNST_TABLE_REF(((long) 1));
			 }
		       else
			 {
			    if (NULLP(actuals_767))
			      {
				 {
				    obj_t l1466_773;
				    {
				       bool_t aux_1605;
				       l1466_773 = args_768;
				     lname1467_774:
				       if (PAIRP(l1466_773))
					 {
					    {
					       local_variant_63_t obj_1260;
					       {
						  obj_t aux_1608;
						  aux_1608 = CAR(l1466_773);
						  obj_1260 = (local_variant_63_t) (aux_1608);
					       }
					       {
						  obj_t aux_1611;
						  {
						     object_t aux_1612;
						     aux_1612 = (object_t) (obj_1260);
						     aux_1611 = OBJECT_WIDENING(aux_1612);
						  }
						  ((((local_variant_63_t) CREF(aux_1611))->variant) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					       }
					    }
					    {
					       obj_t l1466_1616;
					       l1466_1616 = CDR(l1466_773);
					       l1466_773 = l1466_1616;
					       goto lname1467_774;
					    }
					 }
				       else
					 {
					    aux_1605 = ((bool_t) 1);
					 }
				       BBOOL(aux_1605);
				    }
				 }
			      }
			    else
			      {
				 bool_t test1495_778;
				 {
				    bool_t test1501_784;
				    test1501_784 = is_a__118___object(CAR(actuals_767), var_ast_node);
				    if (test1501_784)
				      {
					 obj_t aux_1629;
					 obj_t aux_1622;
					 aux_1629 = CAR(args_768);
					 {
					    variable_t aux_1623;
					    {
					       var_t obj_1266;
					       {
						  obj_t aux_1624;
						  aux_1624 = CAR(actuals_767);
						  obj_1266 = (var_t) (aux_1624);
					       }
					       aux_1623 = (((var_t) CREF(obj_1266))->variable);
					    }
					    aux_1622 = (obj_t) (aux_1623);
					 }
					 test1495_778 = (aux_1622 == aux_1629);
				      }
				    else
				      {
					 test1495_778 = ((bool_t) 0);
				      }
				 }
				 if (test1495_778)
				   {
				      {
					 obj_t args_1635;
					 obj_t actuals_1633;
					 actuals_1633 = CDR(actuals_767);
					 args_1635 = CDR(args_768);
					 args_768 = args_1635;
					 actuals_767 = actuals_1633;
					 goto loop_769;
				      }
				   }
				 else
				   {
				      {
					 local_variant_63_t obj_1273;
					 {
					    obj_t aux_1637;
					    aux_1637 = CAR(args_768);
					    obj_1273 = (local_variant_63_t) (aux_1637);
					 }
					 {
					    obj_t aux_1640;
					    {
					       object_t aux_1641;
					       aux_1641 = (object_t) (obj_1273);
					       aux_1640 = OBJECT_WIDENING(aux_1641);
					    }
					    ((((local_variant_63_t) CREF(aux_1640))->variant) = ((bool_t) ((bool_t) 1)), BUNSPEC);
					 }
				      }
				      {
					 obj_t args_1647;
					 obj_t actuals_1645;
					 actuals_1645 = CDR(actuals_767);
					 args_1647 = CDR(args_768);
					 args_768 = args_1647;
					 actuals_767 = actuals_1645;
					 goto loop_769;
				      }
				   }
			      }
			 }
		    }
		 }
		 {
		    obj_t l1464_1650;
		    l1464_1650 = CDR(l1464_763);
		    l1464_763 = l1464_1650;
		    goto lname1465_764;
		 }
	      }
	    else
	      {
		 ((bool_t) 1);
	      }
	 }
	 {
	    obj_t args_790;
	    obj_t invariant_791;
	    args_790 = args_746;
	    invariant_791 = BNIL;
	  loop_792:
	    if (NULLP(args_790))
	      {
		 return reverse__39___r4_pairs_and_lists_6_3(invariant_791);
	      }
	    else
	      {
		 obj_t arg1513_795;
		 obj_t arg1514_796;
		 arg1513_795 = CDR(args_790);
		 {
		    bool_t test_1656;
		    {
		       local_variant_63_t obj_1281;
		       {
			  obj_t aux_1657;
			  aux_1657 = CAR(args_790);
			  obj_1281 = (local_variant_63_t) (aux_1657);
		       }
		       {
			  obj_t aux_1660;
			  {
			     object_t aux_1661;
			     aux_1661 = (object_t) (obj_1281);
			     aux_1660 = OBJECT_WIDENING(aux_1661);
			  }
			  test_1656 = (((local_variant_63_t) CREF(aux_1660))->variant);
		       }
		    }
		    if (test_1656)
		      {
			 arg1514_796 = invariant_791;
		      }
		    else
		      {
			 obj_t aux_1665;
			 aux_1665 = CAR(args_790);
			 arg1514_796 = MAKE_PAIR(aux_1665, invariant_791);
		      }
		 }
		 {
		    obj_t invariant_1669;
		    obj_t args_1668;
		    args_1668 = arg1513_795;
		    invariant_1669 = arg1514_796;
		    invariant_791 = invariant_1669;
		    args_790 = args_1668;
		    goto loop_792;
		 }
	      }
	 }
      }
   }
}


/* _invariant-args1701 */ obj_t 
_invariant_args1701_17_inline_variant(obj_t env_1434, obj_t var_1435, obj_t calls_1436)
{
   return invariant_args_254_inline_variant((variable_t) (var_1435), calls_1436);
}


/* variant-args */ obj_t 
variant_args_126_inline_variant(variable_t var_3)
{
   {
      {
	 obj_t args_802;
	 obj_t variant_803;
	 {
	    sfun_t obj_1286;
	    {
	       value_t aux_1690;
	       aux_1690 = (((variable_t) CREF(var_3))->value);
	       obj_1286 = (sfun_t) (aux_1690);
	    }
	    args_802 = (((sfun_t) CREF(obj_1286))->args);
	 }
	 variant_803 = BNIL;
       loop_804:
	 if (NULLP(args_802))
	   {
	      return reverse__39___r4_pairs_and_lists_6_3(variant_803);
	   }
	 else
	   {
	      obj_t arg1522_807;
	      obj_t arg1524_808;
	      arg1522_807 = CDR(args_802);
	      {
		 bool_t test_1676;
		 {
		    local_variant_63_t obj_1290;
		    {
		       obj_t aux_1677;
		       aux_1677 = CAR(args_802);
		       obj_1290 = (local_variant_63_t) (aux_1677);
		    }
		    {
		       obj_t aux_1680;
		       {
			  object_t aux_1681;
			  aux_1681 = (object_t) (obj_1290);
			  aux_1680 = OBJECT_WIDENING(aux_1681);
		       }
		       test_1676 = (((local_variant_63_t) CREF(aux_1680))->variant);
		    }
		 }
		 if (test_1676)
		   {
		      obj_t aux_1685;
		      aux_1685 = CAR(args_802);
		      arg1524_808 = MAKE_PAIR(aux_1685, variant_803);
		   }
		 else
		   {
		      arg1524_808 = variant_803;
		   }
	      }
	      {
		 obj_t variant_1689;
		 obj_t args_1688;
		 args_1688 = arg1522_807;
		 variant_1689 = arg1524_808;
		 variant_803 = variant_1689;
		 args_802 = args_1688;
		 goto loop_804;
	      }
	   }
      }
   }
}


/* _variant-args1702 */ obj_t 
_variant_args1702_188_inline_variant(obj_t env_1437, obj_t var_1438)
{
   return variant_args_126_inline_variant((variable_t) (var_1438));
}


/* substitutions */ obj_t 
substitutions_inline_variant(variable_t var_4, obj_t actuals_5, obj_t var_args_195_6)
{
   {
      {
	 obj_t actuals_814;
	 obj_t all_args_251_815;
	 obj_t var_args_195_816;
	 obj_t substitutions_817;
	 actuals_814 = actuals_5;
	 {
	    sfun_t obj_1295;
	    {
	       value_t aux_1734;
	       aux_1734 = (((variable_t) CREF(var_4))->value);
	       obj_1295 = (sfun_t) (aux_1734);
	    }
	    all_args_251_815 = (((sfun_t) CREF(obj_1295))->args);
	 }
	 var_args_195_816 = var_args_195_6;
	 substitutions_817 = BNIL;
       loop_818:
	 if (NULLP(all_args_251_815))
	   {
	      return reverse__39___r4_pairs_and_lists_6_3(substitutions_817);
	   }
	 else
	   {
	      bool_t test_1699;
	      {
		 local_variant_63_t obj_1298;
		 {
		    obj_t aux_1700;
		    aux_1700 = CAR(all_args_251_815);
		    obj_1298 = (local_variant_63_t) (aux_1700);
		 }
		 {
		    obj_t aux_1703;
		    {
		       object_t aux_1704;
		       aux_1704 = (object_t) (obj_1298);
		       aux_1703 = OBJECT_WIDENING(aux_1704);
		    }
		    test_1699 = (((local_variant_63_t) CREF(aux_1703))->variant);
		 }
	      }
	      if (test_1699)
		{
		   {
		      obj_t arg1531_822;
		      obj_t arg1532_823;
		      obj_t arg1533_824;
		      obj_t arg1534_825;
		      arg1531_822 = CDR(actuals_814);
		      arg1532_823 = CDR(all_args_251_815);
		      arg1533_824 = CDR(var_args_195_816);
		      {
			 obj_t aux_1711;
			 aux_1711 = CAR(var_args_195_816);
			 arg1534_825 = MAKE_PAIR(aux_1711, substitutions_817);
		      }
		      {
			 obj_t substitutions_1717;
			 obj_t var_args_195_1716;
			 obj_t all_args_251_1715;
			 obj_t actuals_1714;
			 actuals_1714 = arg1531_822;
			 all_args_251_1715 = arg1532_823;
			 var_args_195_1716 = arg1533_824;
			 substitutions_1717 = arg1534_825;
			 substitutions_817 = substitutions_1717;
			 var_args_195_816 = var_args_195_1716;
			 all_args_251_815 = all_args_251_1715;
			 actuals_814 = actuals_1714;
			 goto loop_818;
		      }
		   }
		}
	      else
		{
		   {
		      obj_t arg1536_827;
		      obj_t arg1537_828;
		      obj_t arg1539_829;
		      arg1536_827 = CDR(actuals_814);
		      arg1537_828 = CDR(all_args_251_815);
		      {
			 obj_t arg1540_830;
			 {
			    bool_t test1541_831;
			    test1541_831 = is_a__118___object(CAR(actuals_814), var_ast_node);
			    if (test1541_831)
			      {
				 var_t obj_1310;
				 {
				    obj_t aux_1723;
				    aux_1723 = CAR(actuals_814);
				    obj_1310 = (var_t) (aux_1723);
				 }
				 {
				    variable_t aux_1726;
				    aux_1726 = (((var_t) CREF(obj_1310))->variable);
				    arg1540_830 = (obj_t) (aux_1726);
				 }
			      }
			    else
			      {
				 arg1540_830 = CAR(actuals_814);
			      }
			 }
			 arg1539_829 = MAKE_PAIR(arg1540_830, substitutions_817);
		      }
		      {
			 obj_t substitutions_1733;
			 obj_t all_args_251_1732;
			 obj_t actuals_1731;
			 actuals_1731 = arg1536_827;
			 all_args_251_1732 = arg1537_828;
			 substitutions_1733 = arg1539_829;
			 substitutions_817 = substitutions_1733;
			 all_args_251_815 = all_args_251_1732;
			 actuals_814 = actuals_1731;
			 goto loop_818;
		      }
		   }
		}
	   }
      }
   }
}


/* _substitutions1703 */ obj_t 
_substitutions1703_inline_variant(obj_t env_1439, obj_t var_1440, obj_t actuals_1441, obj_t var_args_195_1442)
{
   return substitutions_inline_variant((variable_t) (var_1440), actuals_1441, var_args_195_1442);
}


/* shrink-args! */ obj_t 
shrink_args__237_inline_variant(variable_t var_7)
{
   {
      {
	 obj_t l1468_837;
	 {
	    bool_t aux_1740;
	    {
	       sfun_t obj_1315;
	       {
		  value_t aux_1764;
		  aux_1764 = (((variable_t) CREF(var_7))->value);
		  obj_1315 = (sfun_t) (aux_1764);
	       }
	       l1468_837 = (((sfun_t) CREF(obj_1315))->args);
	    }
	  lname1469_838:
	    if (PAIRP(l1468_837))
	      {
		 {
		    obj_t a_840;
		    a_840 = CAR(l1468_837);
		    {
		       bool_t test_1744;
		       {
			  bool_t test_1745;
			  {
			     obj_t aux_1746;
			     {
				object_t aux_1747;
				aux_1747 = (object_t) (a_840);
				aux_1746 = OBJECT_WIDENING(aux_1747);
			     }
			     test_1745 = CBOOL(aux_1746);
			  }
			  if (test_1745)
			    {
			       test_1744 = ((bool_t) 1);
			    }
			  else
			    {
			       test_1744 = ((bool_t) 0);
			    }
		       }
		       if (test_1744)
			 {
			    {
			       long arg1552_843;
			       {
				  obj_t arg1553_844;
				  {
				     obj_t arg1554_845;
				     {
					object_t object_1321;
					object_1321 = (object_t) (a_840);
					{
					   long arg1180_1322;
					   {
					      long arg1181_1323;
					      long arg1182_1324;
					      arg1181_1323 = TYPE(object_1321);
					      arg1182_1324 = OBJECT_TYPE;
					      arg1180_1322 = (arg1181_1323 - arg1182_1324);
					   }
					   {
					      obj_t vector_1328;
					      vector_1328 = _classes__134___object;
					      arg1554_845 = VECTOR_REF(vector_1328, arg1180_1322);
					   }
					}
				     }
				     arg1553_844 = class_super_145___object(arg1554_845);
				  }
				  arg1552_843 = class_num_218___object(arg1553_844);
			       }
			       (((obj_t) CREF(a_840))->header = MAKE_HEADER(arg1552_843, 0), BUNSPEC);
			    }
			    {
			       object_t aux_1759;
			       aux_1759 = (object_t) (a_840);
			       OBJECT_WIDENING_SET(aux_1759, BFALSE);
			    }
			    a_840;
			 }
		       else
			 {
			    BUNSPEC;
			 }
		    }
		 }
		 {
		    obj_t l1468_1762;
		    l1468_1762 = CDR(l1468_837);
		    l1468_837 = l1468_1762;
		    goto lname1469_838;
		 }
	      }
	    else
	      {
		 aux_1740 = ((bool_t) 1);
	      }
	    return BBOOL(aux_1740);
	 }
      }
   }
}


/* _shrink-args!1704 */ obj_t 
_shrink_args_1704_180_inline_variant(obj_t env_1443, obj_t var_1444)
{
   return shrink_args__237_inline_variant((variable_t) (var_1444));
}


/* remove-invariant-args! */ app_t 
remove_invariant_args__113_inline_variant(app_t app_8)
{
   {
      obj_t formals_848;
      obj_t old_args_130_849;
      obj_t new_args_235_850;
      {
	 sfun_t obj_1336;
	 {
	    value_t aux_1800;
	    {
	       variable_t arg1560_856;
	       {
		  var_t arg1561_857;
		  arg1561_857 = (((app_t) CREF(app_8))->fun);
		  arg1560_856 = (((var_t) CREF(arg1561_857))->variable);
	       }
	       aux_1800 = (((variable_t) CREF(arg1560_856))->value);
	    }
	    obj_1336 = (sfun_t) (aux_1800);
	 }
	 formals_848 = (((sfun_t) CREF(obj_1336))->args);
      }
      old_args_130_849 = (((app_t) CREF(app_8))->args);
      new_args_235_850 = BNIL;
    loop_851:
      if (NULLP(old_args_130_849))
	{
	   {
	      obj_t arg1563_859;
	      arg1563_859 = reverse__39___r4_pairs_and_lists_6_3(new_args_235_850);
	      ((((app_t) CREF(app_8))->args) = ((obj_t) arg1563_859), BUNSPEC);
	   }
	   return app_8;
	}
      else
	{
	   bool_t test1564_860;
	   {
	      bool_t test1573_867;
	      test1573_867 = is_a__118___object(CAR(formals_848), local_variant_63_inline_variant);
	      if (test1573_867)
		{
		   bool_t test_1778;
		   {
		      local_variant_63_t obj_1344;
		      {
			 obj_t aux_1779;
			 aux_1779 = CAR(formals_848);
			 obj_1344 = (local_variant_63_t) (aux_1779);
		      }
		      {
			 obj_t aux_1782;
			 {
			    object_t aux_1783;
			    aux_1783 = (object_t) (obj_1344);
			    aux_1782 = OBJECT_WIDENING(aux_1783);
			 }
			 test_1778 = (((local_variant_63_t) CREF(aux_1782))->variant);
		      }
		   }
		   if (test_1778)
		     {
			test1564_860 = ((bool_t) 0);
		     }
		   else
		     {
			test1564_860 = ((bool_t) 1);
		     }
		}
	      else
		{
		   test1564_860 = ((bool_t) 0);
		}
	   }
	   if (test1564_860)
	     {
		{
		   obj_t old_args_130_1790;
		   obj_t formals_1788;
		   formals_1788 = CDR(formals_848);
		   old_args_130_1790 = CDR(old_args_130_849);
		   old_args_130_849 = old_args_130_1790;
		   formals_848 = formals_1788;
		   goto loop_851;
		}
	     }
	   else
	     {
		{
		   obj_t arg1568_863;
		   obj_t arg1569_864;
		   obj_t arg1570_865;
		   arg1568_863 = CDR(formals_848);
		   arg1569_864 = CDR(old_args_130_849);
		   {
		      obj_t aux_1794;
		      aux_1794 = CAR(old_args_130_849);
		      arg1570_865 = MAKE_PAIR(aux_1794, new_args_235_850);
		   }
		   {
		      obj_t new_args_235_1799;
		      obj_t old_args_130_1798;
		      obj_t formals_1797;
		      formals_1797 = arg1568_863;
		      old_args_130_1798 = arg1569_864;
		      new_args_235_1799 = arg1570_865;
		      new_args_235_850 = new_args_235_1799;
		      old_args_130_849 = old_args_130_1798;
		      formals_848 = formals_1797;
		      goto loop_851;
		   }
		}
	     }
	}
   }
}


/* _remove-invariant-args!1705 */ obj_t 
_remove_invariant_args_1705_230_inline_variant(obj_t env_1445, obj_t app_1446)
{
   {
      app_t aux_1807;
      aux_1807 = remove_invariant_args__113_inline_variant((app_t) (app_1446));
      return (obj_t) (aux_1807);
   }
}


/* object-init */ obj_t 
object_init_111_inline_variant()
{
   {
      obj_t arg1581_872;
      arg1581_872 = local_ast_var;
      local_variant_63_inline_variant = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1581_872, allocate_local_variant_env_26_inline_variant, ((long) 1562), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-local/variant */ local_t 
allocate_local_variant_108_inline_variant()
{
   {
      local_t new1450_875;
      new1450_875 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1584_876;
	 arg1584_876 = class_num_218___object(local_variant_63_inline_variant);
	 {
	    obj_t obj_1352;
	    obj_1352 = (obj_t) (new1450_875);
	    (((obj_t) CREF(obj_1352))->header = MAKE_HEADER(arg1584_876, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_1817;
	 aux_1817 = (object_t) (new1450_875);
	 OBJECT_WIDENING_SET(aux_1817, BFALSE);
      }
      return new1450_875;
   }
}


/* _allocate-local/variant */ obj_t 
_allocate_local_variant_45_inline_variant(obj_t env_1447)
{
   {
      local_t aux_1820;
      aux_1820 = allocate_local_variant_108_inline_variant();
      return (obj_t) (aux_1820);
   }
}


/* local/variant? */ bool_t 
local_variant__1_inline_variant(obj_t obj_12)
{
   return is_a__118___object(obj_12, local_variant_63_inline_variant);
}


/* _local/variant? */ obj_t 
_local_variant__184_inline_variant(obj_t env_1448, obj_t obj_1449)
{
   {
      bool_t aux_1824;
      aux_1824 = local_variant__1_inline_variant(obj_1449);
      return BBOOL(aux_1824);
   }
}


/* widening1002-local/variant */ local_variant_63_t 
widening1002_local_variant_160_inline_variant(bool_t variant_13)
{
   {
      local_variant_63_t new1436_1354;
      new1436_1354 = ((local_variant_63_t) BREF(GC_MALLOC(sizeof(struct local_variant_63))));
      ((((local_variant_63_t) CREF(new1436_1354))->variant) = ((bool_t) variant_13), BUNSPEC);
      return new1436_1354;
   }
}


/* _widening1002-local/variant */ obj_t 
_widening1002_local_variant_190_inline_variant(obj_t env_1450, obj_t variant_1451)
{
   {
      local_variant_63_t aux_1829;
      aux_1829 = widening1002_local_variant_160_inline_variant(CBOOL(variant_1451));
      return (obj_t) (aux_1829);
   }
}


/* make-local/variant */ local_variant_63_t 
make_local_variant_132_inline_variant(obj_t id_14, obj_t name_15, type_t type_16, value_t value_17, obj_t access_18, obj_t fast_alpha_7_19, obj_t removable_20, long occurrence_21, bool_t user__32_22, long key_23, bool_t variant_24)
{
   {
      local_t aux1439_1356;
      {
	 local_t res1698_1384;
	 {
	    local_t new1080_1370;
	    new1080_1370 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
	    {
	       long arg1672_1371;
	       arg1672_1371 = class_num_218___object(local_ast_var);
	       {
		  obj_t obj_1382;
		  obj_1382 = (obj_t) (new1080_1370);
		  (((obj_t) CREF(obj_1382))->header = MAKE_HEADER(arg1672_1371, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_1837;
	       aux_1837 = (object_t) (new1080_1370);
	       OBJECT_WIDENING_SET(aux_1837, BFALSE);
	    }
	    ((((local_t) CREF(new1080_1370))->id) = ((obj_t) id_14), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->name) = ((obj_t) name_15), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->type) = ((type_t) type_16), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->value) = ((value_t) value_17), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->access) = ((obj_t) access_18), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->fast_alpha_7) = ((obj_t) fast_alpha_7_19), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->removable) = ((obj_t) removable_20), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->occurrence) = ((long) occurrence_21), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->user__32) = ((bool_t) user__32_22), BUNSPEC);
	    ((((local_t) CREF(new1080_1370))->key) = ((long) key_23), BUNSPEC);
	    res1698_1384 = new1080_1370;
	 }
	 aux1439_1356 = res1698_1384;
      }
      {
	 local_variant_63_t new1440_1357;
	 new1440_1357 = ((local_variant_63_t) (aux1439_1356));
	 {
	    long arg1585_1358;
	    arg1585_1358 = class_num_218___object(local_variant_63_inline_variant);
	    {
	       obj_t obj_1385;
	       obj_1385 = (obj_t) (new1440_1357);
	       (((obj_t) CREF(obj_1385))->header = MAKE_HEADER(arg1585_1358, 0), BUNSPEC);
	    }
	 }
	 {
	    local_variant_63_t arg1586_1359;
	    {
	       local_variant_63_t res1699_1390;
	       {
		  local_variant_63_t new1436_1388;
		  new1436_1388 = ((local_variant_63_t) BREF(GC_MALLOC(sizeof(struct local_variant_63))));
		  ((((local_variant_63_t) CREF(new1436_1388))->variant) = ((bool_t) variant_24), BUNSPEC);
		  res1699_1390 = new1436_1388;
	       }
	       arg1586_1359 = res1699_1390;
	    }
	    {
	       obj_t aux_1858;
	       object_t aux_1856;
	       aux_1858 = (obj_t) (arg1586_1359);
	       aux_1856 = (object_t) (new1440_1357);
	       OBJECT_WIDENING_SET(aux_1856, aux_1858);
	    }
	 }
	 return new1440_1357;
      }
   }
}


/* _make-local/variant1706 */ obj_t 
_make_local_variant1706_130_inline_variant(obj_t env_1452, obj_t id_1453, obj_t name_1454, obj_t type_1455, obj_t value_1456, obj_t access_1457, obj_t fast_alpha_7_1458, obj_t removable_1459, obj_t occurrence_1460, obj_t user__32_1461, obj_t key_1462, obj_t variant_1463)
{
   {
      local_variant_63_t aux_1861;
      aux_1861 = make_local_variant_132_inline_variant(id_1453, name_1454, (type_t) (type_1455), (value_t) (value_1456), access_1457, fast_alpha_7_1458, removable_1459, (long) CINT(occurrence_1460), CBOOL(user__32_1461), (long) CINT(key_1462), CBOOL(variant_1463));
      return (obj_t) (aux_1861);
   }
}


/* local/variant-id */ obj_t 
local_variant_id_153_inline_variant(local_t obj_25)
{
   return (((local_t) CREF(obj_25))->id);
}


/* _local/variant-id1707 */ obj_t 
_local_variant_id1707_17_inline_variant(obj_t env_1464, obj_t obj_1465)
{
   return local_variant_id_153_inline_variant((local_t) (obj_1465));
}


/* local/variant-name-set! */ obj_t 
local_variant_name_set__245_inline_variant(local_t obj_26, obj_t val1441_27)
{
   return ((((local_t) CREF(obj_26))->name) = ((obj_t) val1441_27), BUNSPEC);
}


/* _local/variant-name-set!1708 */ obj_t 
_local_variant_name_set_1708_209_inline_variant(obj_t env_1466, obj_t obj_1467, obj_t val1441_1468)
{
   return local_variant_name_set__245_inline_variant((local_t) (obj_1467), val1441_1468);
}


/* local/variant-name */ obj_t 
local_variant_name_14_inline_variant(local_t obj_28)
{
   return (((local_t) CREF(obj_28))->name);
}


/* _local/variant-name1709 */ obj_t 
_local_variant_name1709_220_inline_variant(obj_t env_1469, obj_t obj_1470)
{
   return local_variant_name_14_inline_variant((local_t) (obj_1470));
}


/* local/variant-type-set! */ obj_t 
local_variant_type_set__179_inline_variant(local_t obj_29, type_t val1442_30)
{
   return ((((local_t) CREF(obj_29))->type) = ((type_t) val1442_30), BUNSPEC);
}


/* _local/variant-type-set!1710 */ obj_t 
_local_variant_type_set_1710_118_inline_variant(obj_t env_1471, obj_t obj_1472, obj_t val1442_1473)
{
   return local_variant_type_set__179_inline_variant((local_t) (obj_1472), (type_t) (val1442_1473));
}


/* local/variant-type */ type_t 
local_variant_type_2_inline_variant(local_t obj_31)
{
   return (((local_t) CREF(obj_31))->type);
}


/* _local/variant-type1711 */ obj_t 
_local_variant_type1711_227_inline_variant(obj_t env_1474, obj_t obj_1475)
{
   {
      type_t aux_1884;
      aux_1884 = local_variant_type_2_inline_variant((local_t) (obj_1475));
      return (obj_t) (aux_1884);
   }
}


/* local/variant-value-set! */ obj_t 
local_variant_value_set__67_inline_variant(local_t obj_32, value_t val1443_33)
{
   return ((((local_t) CREF(obj_32))->value) = ((value_t) val1443_33), BUNSPEC);
}


/* _local/variant-value-set!1712 */ obj_t 
_local_variant_value_set_1712_42_inline_variant(obj_t env_1476, obj_t obj_1477, obj_t val1443_1478)
{
   return local_variant_value_set__67_inline_variant((local_t) (obj_1477), (value_t) (val1443_1478));
}


/* local/variant-value */ value_t 
local_variant_value_31_inline_variant(local_t obj_34)
{
   return (((local_t) CREF(obj_34))->value);
}


/* _local/variant-value1713 */ obj_t 
_local_variant_value1713_252_inline_variant(obj_t env_1479, obj_t obj_1480)
{
   {
      value_t aux_1893;
      aux_1893 = local_variant_value_31_inline_variant((local_t) (obj_1480));
      return (obj_t) (aux_1893);
   }
}


/* local/variant-access-set! */ obj_t 
local_variant_access_set__216_inline_variant(local_t obj_35, obj_t val1444_36)
{
   return ((((local_t) CREF(obj_35))->access) = ((obj_t) val1444_36), BUNSPEC);
}


/* _local/variant-access-set!1714 */ obj_t 
_local_variant_access_set_1714_178_inline_variant(obj_t env_1481, obj_t obj_1482, obj_t val1444_1483)
{
   return local_variant_access_set__216_inline_variant((local_t) (obj_1482), val1444_1483);
}


/* local/variant-access */ obj_t 
local_variant_access_191_inline_variant(local_t obj_37)
{
   return (((local_t) CREF(obj_37))->access);
}


/* _local/variant-access1715 */ obj_t 
_local_variant_access1715_73_inline_variant(obj_t env_1484, obj_t obj_1485)
{
   return local_variant_access_191_inline_variant((local_t) (obj_1485));
}


/* local/variant-fast-alpha-set! */ obj_t 
local_variant_fast_alpha_set__19_inline_variant(local_t obj_38, obj_t val1445_39)
{
   return ((((local_t) CREF(obj_38))->fast_alpha_7) = ((obj_t) val1445_39), BUNSPEC);
}


/* _local/variant-fast-alpha-set!1716 */ obj_t 
_local_variant_fast_alpha_set_1716_151_inline_variant(obj_t env_1486, obj_t obj_1487, obj_t val1445_1488)
{
   return local_variant_fast_alpha_set__19_inline_variant((local_t) (obj_1487), val1445_1488);
}


/* local/variant-fast-alpha */ obj_t 
local_variant_fast_alpha_32_inline_variant(local_t obj_40)
{
   return (((local_t) CREF(obj_40))->fast_alpha_7);
}


/* _local/variant-fast-alpha1717 */ obj_t 
_local_variant_fast_alpha1717_163_inline_variant(obj_t env_1489, obj_t obj_1490)
{
   return local_variant_fast_alpha_32_inline_variant((local_t) (obj_1490));
}


/* local/variant-removable-set! */ obj_t 
local_variant_removable_set__23_inline_variant(local_t obj_41, obj_t val1446_42)
{
   return ((((local_t) CREF(obj_41))->removable) = ((obj_t) val1446_42), BUNSPEC);
}


/* _local/variant-removable-set!1718 */ obj_t 
_local_variant_removable_set_1718_76_inline_variant(obj_t env_1491, obj_t obj_1492, obj_t val1446_1493)
{
   return local_variant_removable_set__23_inline_variant((local_t) (obj_1492), val1446_1493);
}


/* local/variant-removable */ obj_t 
local_variant_removable_17_inline_variant(local_t obj_43)
{
   return (((local_t) CREF(obj_43))->removable);
}


/* _local/variant-removable1719 */ obj_t 
_local_variant_removable1719_117_inline_variant(obj_t env_1494, obj_t obj_1495)
{
   return local_variant_removable_17_inline_variant((local_t) (obj_1495));
}


/* local/variant-occurrence-set! */ obj_t 
local_variant_occurrence_set__206_inline_variant(local_t obj_44, long val1447_45)
{
   return ((((local_t) CREF(obj_44))->occurrence) = ((long) val1447_45), BUNSPEC);
}


/* _local/variant-occurrence-set!1720 */ obj_t 
_local_variant_occurrence_set_1720_88_inline_variant(obj_t env_1496, obj_t obj_1497, obj_t val1447_1498)
{
   return local_variant_occurrence_set__206_inline_variant((local_t) (obj_1497), (long) CINT(val1447_1498));
}


/* local/variant-occurrence */ long 
local_variant_occurrence_19_inline_variant(local_t obj_46)
{
   return (((local_t) CREF(obj_46))->occurrence);
}


/* _local/variant-occurrence1721 */ obj_t 
_local_variant_occurrence1721_203_inline_variant(obj_t env_1499, obj_t obj_1500)
{
   {
      long aux_1920;
      aux_1920 = local_variant_occurrence_19_inline_variant((local_t) (obj_1500));
      return BINT(aux_1920);
   }
}


/* local/variant-user?-set! */ obj_t 
local_variant_user__set__143_inline_variant(local_t obj_47, bool_t val1448_48)
{
   return ((((local_t) CREF(obj_47))->user__32) = ((bool_t) val1448_48), BUNSPEC);
}


/* _local/variant-user?-set!1722 */ obj_t 
_local_variant_user__set_1722_238_inline_variant(obj_t env_1501, obj_t obj_1502, obj_t val1448_1503)
{
   return local_variant_user__set__143_inline_variant((local_t) (obj_1502), CBOOL(val1448_1503));
}


/* local/variant-user? */ bool_t 
local_variant_user__42_inline_variant(local_t obj_49)
{
   return (((local_t) CREF(obj_49))->user__32);
}


/* _local/variant-user?1723 */ obj_t 
_local_variant_user_1723_78_inline_variant(obj_t env_1504, obj_t obj_1505)
{
   {
      bool_t aux_1929;
      aux_1929 = local_variant_user__42_inline_variant((local_t) (obj_1505));
      return BBOOL(aux_1929);
   }
}


/* local/variant-key */ long 
local_variant_key_71_inline_variant(local_t obj_50)
{
   return (((local_t) CREF(obj_50))->key);
}


/* _local/variant-key1724 */ obj_t 
_local_variant_key1724_169_inline_variant(obj_t env_1506, obj_t obj_1507)
{
   {
      long aux_1934;
      aux_1934 = local_variant_key_71_inline_variant((local_t) (obj_1507));
      return BINT(aux_1934);
   }
}


/* local/variant-variant-set! */ obj_t 
local_variant_variant_set__103_inline_variant(local_variant_63_t obj_51, bool_t val1449_52)
{
   {
      obj_t aux_1938;
      {
	 object_t aux_1939;
	 aux_1939 = (object_t) (obj_51);
	 aux_1938 = OBJECT_WIDENING(aux_1939);
      }
      return ((((local_variant_63_t) CREF(aux_1938))->variant) = ((bool_t) val1449_52), BUNSPEC);
   }
}


/* _local/variant-variant-set!1725 */ obj_t 
_local_variant_variant_set_1725_214_inline_variant(obj_t env_1508, obj_t obj_1509, obj_t val1449_1510)
{
   return local_variant_variant_set__103_inline_variant((local_variant_63_t) (obj_1509), CBOOL(val1449_1510));
}


/* local/variant-variant */ bool_t 
local_variant_variant_215_inline_variant(local_variant_63_t obj_53)
{
   {
      obj_t aux_1946;
      {
	 object_t aux_1947;
	 aux_1947 = (object_t) (obj_53);
	 aux_1946 = OBJECT_WIDENING(aux_1947);
      }
      return (((local_variant_63_t) CREF(aux_1946))->variant);
   }
}


/* _local/variant-variant1726 */ obj_t 
_local_variant_variant1726_6_inline_variant(obj_t env_1511, obj_t obj_1512)
{
   {
      bool_t aux_1951;
      aux_1951 = local_variant_variant_215_inline_variant((local_variant_63_t) (obj_1512));
      return BBOOL(aux_1951);
   }
}


/* method-init */ obj_t 
method_init_76_inline_variant()
{
   {
      obj_t object__struct_local_variant_205_1517;
      object__struct_local_variant_205_1517 = proc1732_inline_variant;
      add_method__1___object(object__struct_env_210___object, local_variant_63_inline_variant, object__struct_local_variant_205_1517);
   }
   {
      obj_t struct_object__object_local_variant_223_1513;
      struct_object__object_local_variant_223_1513 = proc1733_inline_variant;
      return add_method__1___object(struct_object__object_env_209___object, local_variant_63_inline_variant, struct_object__object_local_variant_223_1513);
   }
}


/* struct+object->object-local/variant */ obj_t 
struct_object__object_local_variant_223_inline_variant(obj_t env_1520, obj_t o_1521, obj_t s_1522)
{
   {
      local_variant_63_t o_1221;
      obj_t s_1222;
      {
	 local_variant_63_t aux_1957;
	 o_1221 = (local_variant_63_t) (o_1521);
	 s_1222 = s_1522;
	 {
	    {
	       obj_t old1457_1225;
	       obj_t aux1458_1226;
	       {
		  obj_t next_method1474_219_1231;
		  next_method1474_219_1231 = find_super_class_method_167___object((object_t) (o_1221), struct_object__object_env_209___object, local_variant_63_inline_variant);
		  if (PROCEDUREP(next_method1474_219_1231))
		    {
		       old1457_1225 = PROCEDURE_ENTRY(next_method1474_219_1231) (next_method1474_219_1231, (obj_t) (o_1221), s_1222, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1474_219_1231);
		       {
			  object_t aux_1966;
			  aux_1966 = struct_object__object_93___object((object_t) (o_1221), s_1222);
			  old1457_1225 = (obj_t) (aux_1966);
		       }
		    }
	       }
	       aux1458_1226 = STRUCT_REF(s_1222, ((long) 0));
	       {
		  local_variant_63_t new1459_1227;
		  new1459_1227 = ((local_variant_63_t) (old1457_1225));
		  {
		     long arg1691_1228;
		     arg1691_1228 = class_num_218___object(local_variant_63_inline_variant);
		     {
			obj_t obj_1424;
			obj_1424 = (obj_t) (new1459_1227);
			(((obj_t) CREF(obj_1424))->header = MAKE_HEADER(arg1691_1228, 0), BUNSPEC);
		     }
		  }
		  {
		     local_variant_63_t arg1692_1229;
		     {
			local_variant_63_t res1700_1431;
			{
			   bool_t variant_1428;
			   {
			      obj_t aux_1975;
			      aux_1975 = STRUCT_REF(aux1458_1226, ((long) 0));
			      variant_1428 = CBOOL(aux_1975);
			   }
			   {
			      local_variant_63_t new1436_1429;
			      new1436_1429 = ((local_variant_63_t) BREF(GC_MALLOC(sizeof(struct local_variant_63))));
			      ((((local_variant_63_t) CREF(new1436_1429))->variant) = ((bool_t) variant_1428), BUNSPEC);
			      res1700_1431 = new1436_1429;
			   }
			}
			arg1692_1229 = res1700_1431;
		     }
		     {
			obj_t aux_1982;
			object_t aux_1980;
			aux_1982 = (obj_t) (arg1692_1229);
			aux_1980 = (object_t) (new1459_1227);
			OBJECT_WIDENING_SET(aux_1980, aux_1982);
		     }
		  }
		  aux_1957 = new1459_1227;
	       }
	    }
	 }
	 return (obj_t) (aux_1957);
      }
   }
}


/* object->struct-local/variant */ obj_t 
object__struct_local_variant_205_inline_variant(obj_t env_1523, obj_t obj1454_1524)
{
   {
      local_variant_63_t obj1454_1208;
      obj1454_1208 = (local_variant_63_t) (obj1454_1524);
      {
	 {
	    obj_t res1455_1211;
	    {
	       obj_t next_method1473_200_1219;
	       next_method1473_200_1219 = find_super_class_method_167___object((object_t) (obj1454_1208), object__struct_env_210___object, local_variant_63_inline_variant);
	       if (PROCEDUREP(next_method1473_200_1219))
		 {
		    res1455_1211 = PROCEDURE_ENTRY(next_method1473_200_1219) (next_method1473_200_1219, (obj_t) (obj1454_1208), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1473_200_1219);
		    res1455_1211 = object__struct_50___object((object_t) (obj1454_1208));
		 }
	    }
	    {
	       obj_t aux1456_1212;
	       {
		  obj_t aux_1997;
		  aux_1997 = CNST_TABLE_REF(((long) 2));
		  aux1456_1212 = make_struct(aux_1997, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2000;
		  {
		     bool_t aux_2001;
		     {
			obj_t aux_2002;
			{
			   object_t aux_2003;
			   aux_2003 = (object_t) (obj1454_1208);
			   aux_2002 = OBJECT_WIDENING(aux_2003);
			}
			aux_2001 = (((local_variant_63_t) CREF(aux_2002))->variant);
		     }
		     aux_2000 = BBOOL(aux_2001);
		  }
		  STRUCT_SET(aux1456_1212, ((long) 0), aux_2000);
	       }
	       STRUCT_SET(res1455_1211, ((long) 0), aux1456_1212);
	       {
		  obj_t aux_2010;
		  aux_2010 = STRUCT_KEY(res1455_1211);
		  STRUCT_KEY_SET(aux1456_1212, aux_2010);
	       }
	       {
		  obj_t aux_2013;
		  aux_2013 = CNST_TABLE_REF(((long) 2));
		  STRUCT_KEY_SET(res1455_1211, aux_2013);
	       }
	       return res1455_1211;
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_variant()
{
   module_initialization_70_tools_trace(((long) 0), "INLINE_VARIANT");
   module_initialization_70_type_type(((long) 0), "INLINE_VARIANT");
   module_initialization_70_ast_var(((long) 0), "INLINE_VARIANT");
   return module_initialization_70_ast_node(((long) 0), "INLINE_VARIANT");
}
