/*===========================================================================*/
/*   (Tools/progn.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t imported_modules_init_94_tools_progn();
extern obj_t normalize_progn_143_tools_progn(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_tools_progn();
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _normalize_progn_158_tools_progn(obj_t, obj_t);
static obj_t loop_tools_progn(obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_tools_progn = BUNSPEC;
static obj_t cnst_init_137_tools_progn();
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(normalize_progn_env_42_tools_progn, _normalize_progn_158_tools_progn1139, _normalize_progn_158_tools_progn, 0L, 1);
DEFINE_STRING(string1062_tools_progn, string1062_tools_progn1140, "BEGIN ", 6);
DEFINE_STRING(string1061_tools_progn, string1061_tools_progn1141, "Illegal expression", 18);
DEFINE_STRING(string1060_tools_progn, string1060_tools_progn1142, "normalize-progn", 15);


/* module-initialization */ obj_t 
module_initialization_70_tools_progn(long checksum_78, char *from_79)
{
   if (CBOOL(require_initialization_114_tools_progn))
     {
	require_initialization_114_tools_progn = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_progn();
	cnst_init_137_tools_progn();
	imported_modules_init_94_tools_progn();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_progn()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "TOOLS_PROGN");
   module_initialization_70___reader(((long) 0), "TOOLS_PROGN");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_tools_progn()
{
   {
      obj_t cnst_port_138_70;
      cnst_port_138_70 = open_input_string(string1062_tools_progn);
      {
	 long i_71;
	 i_71 = ((long) 0);
       loop_72:
	 {
	    bool_t test1067_73;
	    test1067_73 = (i_71 == ((long) -1));
	    if (test1067_73)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1077_74;
		    {
		       obj_t list1078_75;
		       {
			  obj_t arg1137_76;
			  arg1137_76 = BNIL;
			  list1078_75 = MAKE_PAIR(cnst_port_138_70, arg1137_76);
		       }
		       arg1077_74 = read___reader(list1078_75);
		    }
		    CNST_TABLE_SET(i_71, arg1077_74);
		 }
		 {
		    int aux_77;
		    {
		       long aux_94;
		       aux_94 = (i_71 - ((long) 1));
		       aux_77 = (int) (aux_94);
		    }
		    {
		       long i_97;
		       i_97 = (long) (aux_77);
		       i_71 = i_97;
		       goto loop_72;
		    }
		 }
	      }
	 }
      }
   }
}


/* normalize-progn */ obj_t 
normalize_progn_143_tools_progn(obj_t body__68_1)
{
 normalize_progn_143_tools_progn:
   if (PAIRP(body__68_1))
     {
	bool_t test_101;
	{
	   obj_t aux_102;
	   aux_102 = CDR(body__68_1);
	   test_101 = NULLP(aux_102);
	}
	if (test_101)
	  {
	     {
		obj_t e_103_175_7;
		e_103_175_7 = CAR(body__68_1);
		if (PAIRP(e_103_175_7))
		  {
		     bool_t test_108;
		     {
			obj_t aux_111;
			obj_t aux_109;
			aux_111 = CNST_TABLE_REF(((long) 0));
			aux_109 = CAR(e_103_175_7);
			test_108 = (aux_109 == aux_111);
		     }
		     if (test_108)
		       {
			  obj_t body__68_114;
			  body__68_114 = CDR(e_103_175_7);
			  body__68_1 = body__68_114;
			  goto normalize_progn_143_tools_progn;
		       }
		     else
		       {
			  return e_103_175_7;
		       }
		  }
		else
		  {
		     return e_103_175_7;
		  }
	     }
	  }
	else
	  {
	     {
		obj_t res_13;
		{
		   obj_t arg1009_14;
		   obj_t arg1011_15;
		   arg1009_14 = CNST_TABLE_REF(((long) 0));
		   {
		      obj_t arg1016_18;
		      obj_t arg1018_19;
		      {
			 obj_t aux_117;
			 {
			    bool_t test_118;
			    {
			       obj_t aux_121;
			       obj_t aux_119;
			       aux_121 = CNST_TABLE_REF(((long) 0));
			       aux_119 = CAR(body__68_1);
			       test_118 = (aux_119 == aux_121);
			    }
			    if (test_118)
			      {
				 aux_117 = CDR(body__68_1);
			      }
			    else
			      {
				 aux_117 = body__68_1;
			      }
			 }
			 arg1016_18 = loop_tools_progn(aux_117);
		      }
		      arg1018_19 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		      arg1011_15 = append_2_18___r4_pairs_and_lists_6_3(arg1016_18, arg1018_19);
		   }
		   {
		      obj_t list1012_16;
		      list1012_16 = MAKE_PAIR(arg1011_15, BNIL);
		      res_13 = cons__138___r4_pairs_and_lists_6_3(arg1009_14, list1012_16);
		   }
		}
		return replace__160_tools_misc(body__68_1, res_13);
	     }
	  }
     }
   else
     {
	return internal_error_43_tools_error(string1060_tools_progn, string1061_tools_progn, body__68_1);
     }
}


/* loop */ obj_t 
loop_tools_progn(obj_t body__68_20)
{
   if (NULLP(body__68_20))
     {
	return BNIL;
     }
   else
     {
	obj_t expr_27;
	expr_27 = CAR(body__68_20);
	{
	   bool_t test_135;
	   if (PAIRP(expr_27))
	     {
		obj_t aux_140;
		obj_t aux_138;
		aux_140 = CNST_TABLE_REF(((long) 0));
		aux_138 = CAR(expr_27);
		test_135 = (aux_138 == aux_140);
	     }
	   else
	     {
		test_135 = ((bool_t) 0);
	     }
	   if (test_135)
	     {
		obj_t arg1038_29;
		obj_t arg1039_30;
		arg1038_29 = CDR(expr_27);
		arg1039_30 = loop_tools_progn(CDR(body__68_20));
		return append_2_18___r4_pairs_and_lists_6_3(arg1038_29, arg1039_30);
	     }
	   else
	     {
		obj_t arg1041_32;
		arg1041_32 = loop_tools_progn(CDR(body__68_20));
		return MAKE_PAIR(expr_27, arg1041_32);
	     }
	}
     }
}


/* _normalize-progn */ obj_t 
_normalize_progn_158_tools_progn(obj_t env_68, obj_t body__68_69)
{
   return normalize_progn_143_tools_progn(body__68_69);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_progn()
{
   module_initialization_70_tools_misc(((long) 0), "TOOLS_PROGN");
   return module_initialization_70_tools_error(((long) 0), "TOOLS_PROGN");
}
