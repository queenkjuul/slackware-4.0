/*===========================================================================*/
/*   (Ieee/symbol.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_keyword(char *);
extern obj_t string_to_symbol(char *);
static obj_t _symbol__string_243___r4_symbols_6_4(obj_t, obj_t);
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
static obj_t _symbol__231___r4_symbols_6_4(obj_t, obj_t);
static obj_t _getprop___r4_symbols_6_4(obj_t, obj_t, obj_t);
static obj_t _string__symbol_199___r4_symbols_6_4(obj_t, obj_t);
static obj_t _keyword__string_5___r4_symbols_6_4(obj_t, obj_t);
extern obj_t string_append(obj_t, obj_t);
static obj_t _symbol_append_205___r4_symbols_6_4(obj_t, obj_t);
static obj_t toplevel_init_63___r4_symbols_6_4();
static obj_t _remprop__183___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t symbol_plist_62___r4_symbols_6_4(obj_t);
extern obj_t remprop__243___r4_symbols_6_4(obj_t, obj_t);
extern bool_t symbol__177___r4_symbols_6_4(obj_t);
static obj_t _putprop__17___r4_symbols_6_4(obj_t, obj_t, obj_t, obj_t);
extern char * integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
obj_t gensym___r4_symbols_6_4 = BUNSPEC;
extern obj_t string_to_bstring(char *);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t loop___r4_symbols_6_4(obj_t);
extern obj_t symbol__string_118___r4_symbols_6_4(obj_t);
static obj_t lambda1005___r4_symbols_6_4(obj_t, obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t string__keyword_147___r4_symbols_6_4(obj_t);
extern obj_t string__symbol_93___r4_symbols_6_4(obj_t);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t keyword__string_162___r4_symbols_6_4(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _keyword__66___r4_symbols_6_4(obj_t, obj_t);
static obj_t _symbol_plist_91___r4_symbols_6_4(obj_t, obj_t);
static obj_t imported_modules_init_94___r4_symbols_6_4();
static obj_t require_initialization_114___r4_symbols_6_4 = BUNSPEC;
extern bool_t keyword__217___r4_symbols_6_4(obj_t);
static obj_t _string__keyword_72___r4_symbols_6_4(obj_t, obj_t);
static obj_t cnst_init_137___r4_symbols_6_4();
static obj_t symbol1559___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1558___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1557___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1555___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1554___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1553___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1552___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1551___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1549___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1550___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1548___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1545___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1542___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1541___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1539___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1538___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1537___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1536___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1535___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1534___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1525___r4_symbols_6_4 = BUNSPEC;
static obj_t symbol1523___r4_symbols_6_4 = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( symbol__env_7___r4_symbols_6_4, _symbol__231___r4_symbols_6_41561, _symbol__231___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( putprop__env_168___r4_symbols_6_4, _putprop__17___r4_symbols_6_41562, _putprop__17___r4_symbols_6_4, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( symbol_plist_env_3___r4_symbols_6_4, _symbol_plist_91___r4_symbols_6_41563, _symbol_plist_91___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__keyword_env_177___r4_symbols_6_4, _string__keyword_72___r4_symbols_6_41564, _string__keyword_72___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( remprop__env_20___r4_symbols_6_4, _remprop__183___r4_symbols_6_41565, _remprop__183___r4_symbols_6_4, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( keyword__string_env_197___r4_symbols_6_4, _keyword__string_5___r4_symbols_6_41566, _keyword__string_5___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( symbol_append_env_244___r4_symbols_6_4, _symbol_append_205___r4_symbols_6_41567, va_generic_entry, _symbol_append_205___r4_symbols_6_4, -1 );
DEFINE_STRING( string1556___r4_symbols_6_4, string1556___r4_symbols_6_41568, "KEYWORD", 7 );
DEFINE_STRING( string1547___r4_symbols_6_4, string1547___r4_symbols_6_41569, "getprop", 7 );
DEFINE_STRING( string1546___r4_symbols_6_4, string1546___r4_symbols_6_41570, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_STRING( string1544___r4_symbols_6_4, string1544___r4_symbols_6_41571, "argument is neither a symbol nor a keyword", 42 );
DEFINE_STRING( string1543___r4_symbols_6_4, string1543___r4_symbols_6_41572, "symbol-plist", 12 );
DEFINE_STRING( string1540___r4_symbols_6_4, string1540___r4_symbols_6_41573, "", 0 );
DEFINE_STRING( string1533___r4_symbols_6_4, string1533___r4_symbols_6_41574, "BSTRING", 7 );
DEFINE_STRING( string1532___r4_symbols_6_4, string1532___r4_symbols_6_41575, "LONG", 4 );
DEFINE_STRING( string1531___r4_symbols_6_4, string1531___r4_symbols_6_41576, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string1529___r4_symbols_6_4, string1529___r4_symbols_6_41577, "gensym", 6 );
DEFINE_STRING( string1530___r4_symbols_6_4, string1530___r4_symbols_6_41578, "Illegal argument", 16 );
DEFINE_STRING( string1528___r4_symbols_6_4, string1528___r4_symbols_6_41579, "SYMBOL", 6 );
DEFINE_STRING( string1527___r4_symbols_6_4, string1527___r4_symbols_6_41580, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/symbol.scm", 59 );
DEFINE_STRING( string1526___r4_symbols_6_4, string1526___r4_symbols_6_41581, "PAIR", 4 );
DEFINE_STRING( string1524___r4_symbols_6_4, string1524___r4_symbols_6_41582, "g", 1 );
DEFINE_EXPORT_PROCEDURE( getprop_env_136___r4_symbols_6_4, _getprop___r4_symbols_6_41583, _getprop___r4_symbols_6_4, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( symbol__string_env_220___r4_symbols_6_4, _symbol__string_243___r4_symbols_6_41584, _symbol__string_243___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( keyword__env_152___r4_symbols_6_4, _keyword__66___r4_symbols_6_41585, _keyword__66___r4_symbols_6_4, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( string__symbol_env_209___r4_symbols_6_4, _string__symbol_199___r4_symbols_6_41586, _string__symbol_199___r4_symbols_6_4, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_symbols_6_4(long checksum_878, char * from_879)
{
if(CBOOL(require_initialization_114___r4_symbols_6_4)){
require_initialization_114___r4_symbols_6_4 = BBOOL(((bool_t)0));
cnst_init_137___r4_symbols_6_4();
imported_modules_init_94___r4_symbols_6_4();
toplevel_init_63___r4_symbols_6_4();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_symbols_6_4()
{
symbol1523___r4_symbols_6_4 = string_to_symbol("TOPLEVEL-INIT");
symbol1525___r4_symbols_6_4 = string_to_symbol("LAMBDA1005");
symbol1534___r4_symbols_6_4 = string_to_symbol("SYMBOL?");
symbol1535___r4_symbols_6_4 = string_to_symbol("SYMBOL->STRING");
symbol1536___r4_symbols_6_4 = string_to_symbol("_SYMBOL->STRING");
symbol1537___r4_symbols_6_4 = string_to_symbol("STRING->SYMBOL");
symbol1538___r4_symbols_6_4 = string_to_symbol("_STRING->SYMBOL");
symbol1539___r4_symbols_6_4 = string_to_symbol("SYMBOL-APPEND");
symbol1541___r4_symbols_6_4 = string_to_symbol("LOOP");
symbol1542___r4_symbols_6_4 = string_to_symbol("SYMBOL-PLIST");
symbol1545___r4_symbols_6_4 = string_to_symbol("GETPROP");
symbol1548___r4_symbols_6_4 = string_to_symbol("_GETPROP");
symbol1549___r4_symbols_6_4 = string_to_symbol("PUTPROP!");
symbol1550___r4_symbols_6_4 = string_to_symbol("_PUTPROP!");
symbol1551___r4_symbols_6_4 = string_to_symbol("REMPROP!");
symbol1552___r4_symbols_6_4 = string_to_symbol("_REMPROP!");
symbol1553___r4_symbols_6_4 = string_to_symbol("KEYWORD?");
symbol1554___r4_symbols_6_4 = string_to_symbol("KEYWORD->STRING");
symbol1555___r4_symbols_6_4 = string_to_symbol("_KEYWORD->STRING");
symbol1557___r4_symbols_6_4 = string_to_symbol("STRING->KEYWORD");
symbol1558___r4_symbols_6_4 = string_to_symbol("_STRING->KEYWORD");
return (symbol1559___r4_symbols_6_4 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* toplevel-init */obj_t toplevel_init_63___r4_symbols_6_4()
{
{
obj_t symbol1179_534;
symbol1179_534 = symbol1523___r4_symbols_6_4;
{
PUSH_TRACE(symbol1179_534);
BUNSPEC;
{
obj_t aux1178_535;
{
obj_t counter_221;
{
obj_t cellval_909;
cellval_909 = BINT(((long)999));
counter_221 = MAKE_CELL(cellval_909);
}
{
obj_t lambda1005_560;
lambda1005_560 = make_va_procedure(lambda1005___r4_symbols_6_4, ((long)-1), ((long)1));
PROCEDURE_SET(lambda1005_560, ((long)0), counter_221);
aux1178_535 = (gensym___r4_symbols_6_4 = lambda1005_560,
BUNSPEC);
}
}
POP_TRACE();
return aux1178_535;
}
}
}
}


/* lambda1005 */obj_t lambda1005___r4_symbols_6_4(obj_t env_561, obj_t string_563)
{
{
obj_t counter_562;
counter_562 = PROCEDURE_REF(env_561, ((long)0));
{
obj_t string_222;
string_222 = string_563;
{
obj_t string_224;
if(NULLP(string_222)){
string_224 = string1524___r4_symbols_6_4;
}
 else {
bool_t test1010_231;
{
obj_t arg1017_238;
{
obj_t pair_408;
if(PAIRP(string_222)){
pair_408 = string_222;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1526___r4_symbols_6_4, string_222, string1527___r4_symbols_6_4, BINT(((long)4933)));
exit( -1 );}
arg1017_238 = CAR(pair_408);
}
test1010_231 = SYMBOLP(arg1017_238);
}
if(test1010_231){
{
obj_t arg1011_232;
{
obj_t pair_410;
if(PAIRP(string_222)){
pair_410 = string_222;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1526___r4_symbols_6_4, string_222, string1527___r4_symbols_6_4, BINT(((long)4969)));
exit( -1 );}
arg1011_232 = CAR(pair_410);
}
{
obj_t symbol_411;
if(SYMBOLP(arg1011_232)){
symbol_411 = arg1011_232;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1528___r4_symbols_6_4, arg1011_232, string1527___r4_symbols_6_4, BINT(((long)4952)));
exit( -1 );}
string_224 = SYMBOL_TO_STRING(symbol_411);
}
}
}
 else {
bool_t test1012_233;
{
obj_t arg1016_237;
{
obj_t pair_412;
if(PAIRP(string_222)){
pair_412 = string_222;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1526___r4_symbols_6_4, string_222, string1527___r4_symbols_6_4, BINT(((long)4999)));
exit( -1 );}
arg1016_237 = CAR(pair_412);
}
test1012_233 = STRINGP(arg1016_237);
}
if(test1012_233){
{
obj_t pair_414;
if(PAIRP(string_222)){
pair_414 = string_222;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1526___r4_symbols_6_4, string_222, string1527___r4_symbols_6_4, BINT(((long)5019)));
exit( -1 );}
string_224 = CAR(pair_414);
}
}
 else {
{
obj_t arg1015_236;
{
obj_t pair_415;
if(PAIRP(string_222)){
pair_415 = string_222;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1526___r4_symbols_6_4, string_222, string1527___r4_symbols_6_4, BINT(((long)5097)));
exit( -1 );}
arg1015_236 = CAR(pair_415);
}
string_224 = debug_error_location_199___error(string1529___r4_symbols_6_4, string1530___r4_symbols_6_4, arg1015_236, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
}
}
{
loop_225:
{
obj_t aux_564;
{
long z1_419;
{
obj_t aux_959;
{
obj_t aux1252_627;
aux1252_627 = CELL_REF(counter_562);
if(INTEGERP(aux1252_627)){
aux_959 = aux1252_627;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1532___r4_symbols_6_4, aux1252_627, string1527___r4_symbols_6_4, BINT(((long)5154)));
exit( -1 );}
}
z1_419 = (long)CINT(aux_959);
}
{
long aux_966;
aux_966 = (z1_419+((long)1));
aux_564 = BINT(aux_966);
}
}
CELL_SET(counter_562, aux_564);
}
{
obj_t name_226;
{
char * arg1007_228;
{
long aux_969;
{
obj_t aux_970;
{
obj_t aux1259_633;
aux1259_633 = CELL_REF(counter_562);
if(INTEGERP(aux1259_633)){
aux_970 = aux1259_633;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1532___r4_symbols_6_4, aux1259_633, string1527___r4_symbols_6_4, BINT(((long)5213)));
exit( -1 );}
}
aux_969 = (long)CINT(aux_970);
}
arg1007_228 = integer__string_135___r4_numbers_6_5_fixnum(aux_969, BNIL);
}
{
obj_t aux_984;
obj_t aux_978;
aux_984 = string_to_bstring(arg1007_228);
if(STRINGP(string_224)){
aux_978 = string_224;
}
 else {
bigloo_type_error_location_103___error(symbol1525___r4_symbols_6_4, string1533___r4_symbols_6_4, string_224, string1527___r4_symbols_6_4, BINT(((long)5191)));
exit( -1 );}
name_226 = string_append(aux_978, aux_984);
}
}
{
bool_t test1006_227;
{
char * aux_987;
aux_987 = BSTRING_TO_STRING(name_226);
test1006_227 = symbol_exists_p(aux_987);
}
if(test1006_227){
goto loop_225;
}
 else {
char * aux_991;
aux_991 = BSTRING_TO_STRING(name_226);
return string_to_symbol(aux_991);
}
}
}
}
}
}
}
}


/* symbol? */bool_t symbol__177___r4_symbols_6_4(obj_t obj_1)
{
{
obj_t symbol1181_843;
symbol1181_843 = symbol1534___r4_symbols_6_4;
{
PUSH_TRACE(symbol1181_843);
BUNSPEC;
{
bool_t aux1180_844;
aux1180_844 = SYMBOLP(obj_1);
POP_TRACE();
return aux1180_844;
}
}
}
}


/* _symbol? */obj_t _symbol__231___r4_symbols_6_4(obj_t env_565, obj_t obj_566)
{
{
bool_t aux_997;
{
obj_t obj_845;
obj_845 = obj_566;
{
obj_t symbol1181_846;
symbol1181_846 = symbol1534___r4_symbols_6_4;
{
PUSH_TRACE(symbol1181_846);
BUNSPEC;
{
bool_t aux1180_847;
aux1180_847 = SYMBOLP(obj_845);
POP_TRACE();
aux_997 = aux1180_847;
}
}
}
}
return BBOOL(aux_997);
}
}


/* symbol->string */obj_t symbol__string_118___r4_symbols_6_4(obj_t symbol_2)
{
{
obj_t symbol1183_848;
symbol1183_848 = symbol1535___r4_symbols_6_4;
{
PUSH_TRACE(symbol1183_848);
BUNSPEC;
{
obj_t aux1182_849;
aux1182_849 = SYMBOL_TO_STRING(symbol_2);
POP_TRACE();
return aux1182_849;
}
}
}
}


/* _symbol->string */obj_t _symbol__string_243___r4_symbols_6_4(obj_t env_567, obj_t symbol_568)
{
{
obj_t symbol_850;
if(SYMBOLP(symbol_568)){
symbol_850 = symbol_568;
}
 else {
bigloo_type_error_location_103___error(symbol1536___r4_symbols_6_4, string1528___r4_symbols_6_4, symbol_568, string1527___r4_symbols_6_4, BINT(((long)3729)));
exit( -1 );}
{
obj_t symbol1183_851;
symbol1183_851 = symbol1535___r4_symbols_6_4;
{
PUSH_TRACE(symbol1183_851);
BUNSPEC;
{
obj_t aux1182_852;
aux1182_852 = SYMBOL_TO_STRING(symbol_850);
POP_TRACE();
return aux1182_852;
}
}
}
}
}


/* string->symbol */obj_t string__symbol_93___r4_symbols_6_4(obj_t string_3)
{
{
obj_t symbol1185_853;
symbol1185_853 = symbol1537___r4_symbols_6_4;
{
PUSH_TRACE(symbol1185_853);
BUNSPEC;
{
obj_t aux1184_854;
{
char * aux_1014;
aux_1014 = BSTRING_TO_STRING(string_3);
aux1184_854 = string_to_symbol(aux_1014);
}
POP_TRACE();
return aux1184_854;
}
}
}
}


/* _string->symbol */obj_t _string__symbol_199___r4_symbols_6_4(obj_t env_569, obj_t string_570)
{
{
obj_t string_855;
if(STRINGP(string_570)){
string_855 = string_570;
}
 else {
bigloo_type_error_location_103___error(symbol1538___r4_symbols_6_4, string1533___r4_symbols_6_4, string_570, string1527___r4_symbols_6_4, BINT(((long)4021)));
exit( -1 );}
{
obj_t symbol1185_856;
symbol1185_856 = symbol1537___r4_symbols_6_4;
{
PUSH_TRACE(symbol1185_856);
BUNSPEC;
{
obj_t aux1184_857;
{
char * aux_1024;
aux_1024 = BSTRING_TO_STRING(string_855);
aux1184_857 = string_to_symbol(aux_1024);
}
POP_TRACE();
return aux1184_857;
}
}
}
}
}


/* symbol-append */obj_t symbol_append_197___r4_symbols_6_4(obj_t list_4)
{
{
obj_t symbol1187_542;
symbol1187_542 = symbol1539___r4_symbols_6_4;
{
PUSH_TRACE(symbol1187_542);
BUNSPEC;
{
obj_t aux1186_543;
{
obj_t arg1018_239;
if(NULLP(list_4)){
arg1018_239 = string1540___r4_symbols_6_4;
}
 else {
arg1018_239 = loop___r4_symbols_6_4(list_4);
}
{
obj_t string_430;
if(STRINGP(arg1018_239)){
string_430 = arg1018_239;
}
 else {
bigloo_type_error_location_103___error(symbol1539___r4_symbols_6_4, string1533___r4_symbols_6_4, arg1018_239, string1527___r4_symbols_6_4, BINT(((long)4347)));
exit( -1 );}
{
char * aux_1037;
aux_1037 = BSTRING_TO_STRING(string_430);
aux1186_543 = string_to_symbol(aux_1037);
}
}
}
POP_TRACE();
return aux1186_543;
}
}
}
}


/* loop */obj_t loop___r4_symbols_6_4(obj_t list_241)
{
{
bool_t test1020_243;
{
obj_t arg1027_249;
{
obj_t pair_423;
if(PAIRP(list_241)){
pair_423 = list_241;
}
 else {
bigloo_type_error_location_103___error(symbol1541___r4_symbols_6_4, string1526___r4_symbols_6_4, list_241, string1527___r4_symbols_6_4, BINT(((long)4442)));
exit( -1 );}
arg1027_249 = CDR(pair_423);
}
test1020_243 = NULLP(arg1027_249);
}
if(test1020_243){
obj_t arg1021_244;
{
obj_t pair_425;
if(PAIRP(list_241)){
pair_425 = list_241;
}
 else {
bigloo_type_error_location_103___error(symbol1541___r4_symbols_6_4, string1526___r4_symbols_6_4, list_241, string1527___r4_symbols_6_4, BINT(((long)4479)));
exit( -1 );}
arg1021_244 = CAR(pair_425);
}
{
obj_t symbol_426;
if(SYMBOLP(arg1021_244)){
symbol_426 = arg1021_244;
}
 else {
bigloo_type_error_location_103___error(symbol1541___r4_symbols_6_4, string1528___r4_symbols_6_4, arg1021_244, string1527___r4_symbols_6_4, BINT(((long)4462)));
exit( -1 );}
return SYMBOL_TO_STRING(symbol_426);
}
}
 else {
obj_t arg1022_245;
obj_t arg1023_246;
{
obj_t arg1025_247;
{
obj_t pair_427;
if(PAIRP(list_241)){
pair_427 = list_241;
}
 else {
bigloo_type_error_location_103___error(symbol1541___r4_symbols_6_4, string1526___r4_symbols_6_4, list_241, string1527___r4_symbols_6_4, BINT(((long)4533)));
exit( -1 );}
arg1025_247 = CAR(pair_427);
}
{
obj_t symbol_428;
if(SYMBOLP(arg1025_247)){
symbol_428 = arg1025_247;
}
 else {
bigloo_type_error_location_103___error(symbol1541___r4_symbols_6_4, string1528___r4_symbols_6_4, arg1025_247, string1527___r4_symbols_6_4, BINT(((long)4516)));
exit( -1 );}
arg1022_245 = SYMBOL_TO_STRING(symbol_428);
}
}
{
obj_t arg1026_248;
{
obj_t pair_429;
if(PAIRP(list_241)){
pair_429 = list_241;
}
 else {
bigloo_type_error_location_103___error(symbol1541___r4_symbols_6_4, string1526___r4_symbols_6_4, list_241, string1527___r4_symbols_6_4, BINT(((long)4563)));
exit( -1 );}
arg1026_248 = CDR(pair_429);
}
arg1023_246 = loop___r4_symbols_6_4(arg1026_248);
}
return string_append(arg1022_245, arg1023_246);
}
}
}


/* _symbol-append */obj_t _symbol_append_205___r4_symbols_6_4(obj_t env_571, obj_t list_572)
{
return symbol_append_197___r4_symbols_6_4(list_572);
}


/* symbol-plist */obj_t symbol_plist_62___r4_symbols_6_4(obj_t symbol_5)
{
{
obj_t symbol1189_858;
symbol1189_858 = symbol1542___r4_symbols_6_4;
{
PUSH_TRACE(symbol1189_858);
BUNSPEC;
{
obj_t aux1188_859;
{
bool_t test_1083;
if(SYMBOLP(symbol_5)){
test_1083 = ((bool_t)1);
}
 else {
test_1083 = KEYWORDP(symbol_5);
}
if(test_1083){
aux1188_859 = GET_SYMBOL_PLIST(symbol_5);
}
 else {
aux1188_859 = debug_error_location_199___error(string1543___r4_symbols_6_4, string1544___r4_symbols_6_4, symbol_5, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1188_859;
}
}
}
}


/* _symbol-plist */obj_t _symbol_plist_91___r4_symbols_6_4(obj_t env_573, obj_t symbol_574)
{
{
obj_t symbol_860;
symbol_860 = symbol_574;
{
obj_t symbol1189_861;
symbol1189_861 = symbol1542___r4_symbols_6_4;
{
PUSH_TRACE(symbol1189_861);
BUNSPEC;
{
obj_t aux1188_862;
{
bool_t test_1092;
if(SYMBOLP(symbol_860)){
test_1092 = ((bool_t)1);
}
 else {
test_1092 = KEYWORDP(symbol_860);
}
if(test_1092){
aux1188_862 = GET_SYMBOL_PLIST(symbol_860);
}
 else {
aux1188_862 = debug_error_location_199___error(string1543___r4_symbols_6_4, string1544___r4_symbols_6_4, symbol_860, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1188_862;
}
}
}
}
}


/* getprop */obj_t getprop___r4_symbols_6_4(obj_t symbol_6, obj_t key_7)
{
{
obj_t symbol1191_546;
symbol1191_546 = symbol1545___r4_symbols_6_4;
{
PUSH_TRACE(symbol1191_546);
BUNSPEC;
{
obj_t aux1190_547;
{
bool_t test1030_252;
if(SYMBOLP(symbol_6)){
test1030_252 = ((bool_t)1);
}
 else {
test1030_252 = KEYWORDP(symbol_6);
}
if(test1030_252){
obj_t pl_253;
{
obj_t arg1031_255;
if(test1030_252){
arg1031_255 = GET_SYMBOL_PLIST(symbol_6);
}
 else {
arg1031_255 = debug_error_location_199___error(string1543___r4_symbols_6_4, string1544___r4_symbols_6_4, symbol_6, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
pl_253 = arg1031_255;
loop_254:
if(NULLP(pl_253)){
aux1190_547 = BFALSE;
}
 else {
bool_t test1033_257;
{
obj_t arg1035_259;
{
obj_t pair_449;
if(PAIRP(pl_253)){
pair_449 = pl_253;
}
 else {
bigloo_type_error_location_103___error(symbol1545___r4_symbols_6_4, string1526___r4_symbols_6_4, pl_253, string1527___r4_symbols_6_4, BINT(((long)6162)));
exit( -1 );}
arg1035_259 = CAR(pair_449);
}
test1033_257 = (arg1035_259==key_7);
}
if(test1033_257){
{
obj_t pair_452;
if(PAIRP(pl_253)){
pair_452 = pl_253;
}
 else {
bigloo_type_error_location_103___error(symbol1545___r4_symbols_6_4, string1526___r4_symbols_6_4, pl_253, string1527___r4_symbols_6_4, BINT(((long)6183)));
exit( -1 );}
{
obj_t arg1154_453;
arg1154_453 = CDR(pair_452);
{
obj_t pair_455;
if(PAIRP(arg1154_453)){
pair_455 = arg1154_453;
}
 else {
bigloo_type_error_location_103___error(symbol1545___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1154_453, string1546___r4_symbols_6_4, BINT(((long)7991)));
exit( -1 );}
aux1190_547 = CAR(pair_455);
}
}
}
}
 else {
{
obj_t arg1034_258;
{
obj_t pair_456;
if(PAIRP(pl_253)){
pair_456 = pl_253;
}
 else {
bigloo_type_error_location_103___error(symbol1545___r4_symbols_6_4, string1526___r4_symbols_6_4, pl_253, string1527___r4_symbols_6_4, BINT(((long)6219)));
exit( -1 );}
{
obj_t arg1152_457;
arg1152_457 = CDR(pair_456);
{
obj_t pair_459;
if(PAIRP(arg1152_457)){
pair_459 = arg1152_457;
}
 else {
bigloo_type_error_location_103___error(symbol1545___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1152_457, string1546___r4_symbols_6_4, BINT(((long)8533)));
exit( -1 );}
arg1034_258 = CDR(pair_459);
}
}
}
{
obj_t pl_1143;
pl_1143 = arg1034_258;
pl_253 = pl_1143;
goto loop_254;
}
}
}
}
}
}
 else {
aux1190_547 = debug_error_location_199___error(string1547___r4_symbols_6_4, string1544___r4_symbols_6_4, key_7, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1190_547;
}
}
}
}


/* _getprop */obj_t _getprop___r4_symbols_6_4(obj_t env_575, obj_t symbol_576, obj_t key_577)
{
{
obj_t aux_1147;
if(SYMBOLP(key_577)){
aux_1147 = key_577;
}
 else {
bigloo_type_error_location_103___error(symbol1548___r4_symbols_6_4, string1528___r4_symbols_6_4, key_577, string1527___r4_symbols_6_4, BINT(((long)5989)));
exit( -1 );}
return getprop___r4_symbols_6_4(symbol_576, aux_1147);
}
}


/* putprop! */obj_t putprop__88___r4_symbols_6_4(obj_t symbol_8, obj_t key_9, obj_t val_10)
{
{
obj_t symbol1193_548;
symbol1193_548 = symbol1549___r4_symbols_6_4;
{
PUSH_TRACE(symbol1193_548);
BUNSPEC;
{
obj_t aux1192_549;
{
bool_t test1037_261;
if(SYMBOLP(symbol_8)){
test1037_261 = ((bool_t)1);
}
 else {
test1037_261 = KEYWORDP(symbol_8);
}
if(test1037_261){
obj_t pl_262;
{
obj_t arg1038_264;
if(test1037_261){
arg1038_264 = GET_SYMBOL_PLIST(symbol_8);
}
 else {
arg1038_264 = debug_error_location_199___error(string1543___r4_symbols_6_4, string1544___r4_symbols_6_4, symbol_8, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
pl_262 = arg1038_264;
loop_263:
if(NULLP(pl_262)){
{
obj_t new_266;
{
obj_t arg1040_267;
{
bool_t test_1165;
if(SYMBOLP(symbol_8)){
test_1165 = ((bool_t)1);
}
 else {
test_1165 = KEYWORDP(symbol_8);
}
if(test_1165){
arg1040_267 = GET_SYMBOL_PLIST(symbol_8);
}
 else {
arg1040_267 = debug_error_location_199___error(string1543___r4_symbols_6_4, string1544___r4_symbols_6_4, symbol_8, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
{
obj_t list1041_268;
{
obj_t arg1042_269;
arg1042_269 = MAKE_PAIR(arg1040_267, BNIL);
list1041_268 = MAKE_PAIR(val_10, arg1042_269);
}
new_266 = cons__138___r4_pairs_and_lists_6_3(key_9, list1041_268);
}
}
SET_SYMBOL_PLIST(symbol_8, new_266);
aux1192_549 = new_266;
}
}
 else {
bool_t test1044_271;
{
obj_t arg1047_274;
{
obj_t pair_482;
if(PAIRP(pl_262)){
pair_482 = pl_262;
}
 else {
bigloo_type_error_location_103___error(symbol1549___r4_symbols_6_4, string1526___r4_symbols_6_4, pl_262, string1527___r4_symbols_6_4, BINT(((long)6798)));
exit( -1 );}
arg1047_274 = CAR(pair_482);
}
test1044_271 = (arg1047_274==key_9);
}
if(test1044_271){
{
obj_t arg1045_272;
{
obj_t pair_485;
if(PAIRP(pl_262)){
pair_485 = pl_262;
}
 else {
bigloo_type_error_location_103___error(symbol1549___r4_symbols_6_4, string1526___r4_symbols_6_4, pl_262, string1527___r4_symbols_6_4, BINT(((long)6829)));
exit( -1 );}
arg1045_272 = CDR(pair_485);
}
{
obj_t pair_486;
if(PAIRP(arg1045_272)){
pair_486 = arg1045_272;
}
 else {
bigloo_type_error_location_103___error(symbol1549___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1045_272, string1527___r4_symbols_6_4, BINT(((long)6818)));
exit( -1 );}
aux1192_549 = SET_CAR(pair_486, val_10);
}
}
}
 else {
{
obj_t arg1046_273;
{
obj_t pair_488;
if(PAIRP(pl_262)){
pair_488 = pl_262;
}
 else {
bigloo_type_error_location_103___error(symbol1549___r4_symbols_6_4, string1526___r4_symbols_6_4, pl_262, string1527___r4_symbols_6_4, BINT(((long)6869)));
exit( -1 );}
{
obj_t arg1152_489;
arg1152_489 = CDR(pair_488);
{
obj_t pair_491;
if(PAIRP(arg1152_489)){
pair_491 = arg1152_489;
}
 else {
bigloo_type_error_location_103___error(symbol1549___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1152_489, string1546___r4_symbols_6_4, BINT(((long)8533)));
exit( -1 );}
arg1046_273 = CDR(pair_491);
}
}
}
{
obj_t pl_1208;
pl_1208 = arg1046_273;
pl_262 = pl_1208;
goto loop_263;
}
}
}
}
}
}
 else {
aux1192_549 = debug_error_location_199___error(string1547___r4_symbols_6_4, string1544___r4_symbols_6_4, key_9, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1192_549;
}
}
}
}


/* _putprop! */obj_t _putprop__17___r4_symbols_6_4(obj_t env_578, obj_t symbol_579, obj_t key_580, obj_t val_581)
{
{
obj_t aux_1212;
if(SYMBOLP(key_580)){
aux_1212 = key_580;
}
 else {
bigloo_type_error_location_103___error(symbol1550___r4_symbols_6_4, string1528___r4_symbols_6_4, key_580, string1527___r4_symbols_6_4, BINT(((long)6531)));
exit( -1 );}
return putprop__88___r4_symbols_6_4(symbol_579, aux_1212, val_581);
}
}


/* remprop! */obj_t remprop__243___r4_symbols_6_4(obj_t symbol_11, obj_t key_12)
{
{
obj_t symbol1195_550;
symbol1195_550 = symbol1551___r4_symbols_6_4;
{
PUSH_TRACE(symbol1195_550);
BUNSPEC;
{
obj_t aux1194_551;
{
bool_t test1049_276;
if(SYMBOLP(symbol_11)){
test1049_276 = ((bool_t)1);
}
 else {
test1049_276 = KEYWORDP(symbol_11);
}
if(test1049_276){
obj_t old_277;
obj_t l_278;
{
obj_t arg1051_281;
if(test1049_276){
arg1051_281 = GET_SYMBOL_PLIST(symbol_11);
}
 else {
arg1051_281 = debug_error_location_199___error(string1543___r4_symbols_6_4, string1544___r4_symbols_6_4, symbol_11, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
old_277 = BNIL;
l_278 = arg1051_281;
loop_279:
if(NULLP(l_278)){
aux1194_551 = BFALSE;
}
 else {
bool_t test1053_283;
{
obj_t arg1059_289;
{
obj_t pair_506;
if(PAIRP(l_278)){
pair_506 = l_278;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, l_278, string1527___r4_symbols_6_4, BINT(((long)7369)));
exit( -1 );}
arg1059_289 = CAR(pair_506);
}
test1053_283 = (arg1059_289==key_12);
}
if(test1053_283){
{
bool_t test1054_284;
test1054_284 = PAIRP(old_277);
if(test1054_284){
{
obj_t arg1055_285;
obj_t arg1056_286;
{
obj_t pair_510;
if(test1054_284){
pair_510 = old_277;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, old_277, string1527___r4_symbols_6_4, BINT(((long)7425)));
exit( -1 );}
arg1055_285 = CDR(pair_510);
}
{
obj_t pair_511;
if(PAIRP(l_278)){
pair_511 = l_278;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, l_278, string1527___r4_symbols_6_4, BINT(((long)7435)));
exit( -1 );}
{
obj_t arg1152_512;
arg1152_512 = CDR(pair_511);
{
obj_t pair_514;
if(PAIRP(arg1152_512)){
pair_514 = arg1152_512;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1152_512, string1546___r4_symbols_6_4, BINT(((long)8533)));
exit( -1 );}
arg1056_286 = CDR(pair_514);
}
}
}
{
obj_t pair_515;
if(PAIRP(arg1055_285)){
pair_515 = arg1055_285;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1055_285, string1527___r4_symbols_6_4, BINT(((long)7414)));
exit( -1 );}
aux1194_551 = SET_CDR(pair_515, arg1056_286);
}
}
}
 else {
{
obj_t arg1057_287;
{
obj_t pair_517;
if(PAIRP(l_278)){
pair_517 = l_278;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, l_278, string1527___r4_symbols_6_4, BINT(((long)7484)));
exit( -1 );}
{
obj_t arg1152_518;
arg1152_518 = CDR(pair_517);
{
obj_t pair_520;
if(PAIRP(arg1152_518)){
pair_520 = arg1152_518;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1152_518, string1546___r4_symbols_6_4, BINT(((long)8533)));
exit( -1 );}
arg1057_287 = CDR(pair_520);
}
}
}
aux1194_551 = SET_SYMBOL_PLIST(symbol_11, arg1057_287);
}
}
}
}
 else {
{
obj_t arg1058_288;
{
obj_t pair_521;
if(PAIRP(l_278)){
pair_521 = l_278;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, l_278, string1527___r4_symbols_6_4, BINT(((long)7524)));
exit( -1 );}
{
obj_t arg1152_522;
arg1152_522 = CDR(pair_521);
{
obj_t pair_524;
if(PAIRP(arg1152_522)){
pair_524 = arg1152_522;
}
 else {
bigloo_type_error_location_103___error(symbol1551___r4_symbols_6_4, string1526___r4_symbols_6_4, arg1152_522, string1546___r4_symbols_6_4, BINT(((long)8533)));
exit( -1 );}
arg1058_288 = CDR(pair_524);
}
}
}
{
obj_t l_1289;
obj_t old_1288;
old_1288 = l_278;
l_1289 = arg1058_288;
l_278 = l_1289;
old_277 = old_1288;
goto loop_279;
}
}
}
}
}
}
 else {
aux1194_551 = debug_error_location_199___error(string1547___r4_symbols_6_4, string1544___r4_symbols_6_4, key_12, string1531___r4_symbols_6_4, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1194_551;
}
}
}
}


/* _remprop! */obj_t _remprop__183___r4_symbols_6_4(obj_t env_582, obj_t symbol_583, obj_t key_584)
{
{
obj_t aux_1293;
if(SYMBOLP(key_584)){
aux_1293 = key_584;
}
 else {
bigloo_type_error_location_103___error(symbol1552___r4_symbols_6_4, string1528___r4_symbols_6_4, key_584, string1527___r4_symbols_6_4, BINT(((long)7181)));
exit( -1 );}
return remprop__243___r4_symbols_6_4(symbol_583, aux_1293);
}
}


/* keyword? */bool_t keyword__217___r4_symbols_6_4(obj_t obj_13)
{
{
obj_t symbol1197_863;
symbol1197_863 = symbol1553___r4_symbols_6_4;
{
PUSH_TRACE(symbol1197_863);
BUNSPEC;
{
bool_t aux1196_864;
aux1196_864 = KEYWORDP(obj_13);
POP_TRACE();
return aux1196_864;
}
}
}
}


/* _keyword? */obj_t _keyword__66___r4_symbols_6_4(obj_t env_585, obj_t obj_586)
{
{
bool_t aux_1303;
{
obj_t obj_865;
obj_865 = obj_586;
{
obj_t symbol1197_866;
symbol1197_866 = symbol1553___r4_symbols_6_4;
{
PUSH_TRACE(symbol1197_866);
BUNSPEC;
{
bool_t aux1196_867;
aux1196_867 = KEYWORDP(obj_865);
POP_TRACE();
aux_1303 = aux1196_867;
}
}
}
}
return BBOOL(aux_1303);
}
}


/* keyword->string */obj_t keyword__string_162___r4_symbols_6_4(obj_t keyword_14)
{
{
obj_t symbol1199_868;
symbol1199_868 = symbol1554___r4_symbols_6_4;
{
PUSH_TRACE(symbol1199_868);
BUNSPEC;
{
obj_t aux1198_869;
aux1198_869 = KEYWORD_TO_STRING(keyword_14);
POP_TRACE();
return aux1198_869;
}
}
}
}


/* _keyword->string */obj_t _keyword__string_5___r4_symbols_6_4(obj_t env_587, obj_t keyword_588)
{
{
obj_t keyword_870;
if(KEYWORDP(keyword_588)){
keyword_870 = keyword_588;
}
 else {
bigloo_type_error_location_103___error(symbol1555___r4_symbols_6_4, string1556___r4_symbols_6_4, keyword_588, string1527___r4_symbols_6_4, BINT(((long)8109)));
exit( -1 );}
{
obj_t symbol1199_871;
symbol1199_871 = symbol1554___r4_symbols_6_4;
{
PUSH_TRACE(symbol1199_871);
BUNSPEC;
{
obj_t aux1198_872;
aux1198_872 = KEYWORD_TO_STRING(keyword_870);
POP_TRACE();
return aux1198_872;
}
}
}
}
}


/* string->keyword */obj_t string__keyword_147___r4_symbols_6_4(obj_t string_15)
{
{
obj_t symbol1201_873;
symbol1201_873 = symbol1557___r4_symbols_6_4;
{
PUSH_TRACE(symbol1201_873);
BUNSPEC;
{
obj_t aux1200_874;
{
char * aux_1320;
aux_1320 = BSTRING_TO_STRING(string_15);
aux1200_874 = string_to_keyword(aux_1320);
}
POP_TRACE();
return aux1200_874;
}
}
}
}


/* _string->keyword */obj_t _string__keyword_72___r4_symbols_6_4(obj_t env_589, obj_t string_590)
{
{
obj_t string_875;
if(STRINGP(string_590)){
string_875 = string_590;
}
 else {
bigloo_type_error_location_103___error(symbol1558___r4_symbols_6_4, string1533___r4_symbols_6_4, string_590, string1527___r4_symbols_6_4, BINT(((long)8405)));
exit( -1 );}
{
obj_t symbol1201_876;
symbol1201_876 = symbol1557___r4_symbols_6_4;
{
PUSH_TRACE(symbol1201_876);
BUNSPEC;
{
obj_t aux1200_877;
{
char * aux_1330;
aux_1330 = BSTRING_TO_STRING(string_875);
aux1200_877 = string_to_keyword(aux_1330);
}
POP_TRACE();
return aux1200_877;
}
}
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_symbols_6_4()
{
{
obj_t symbol1203_558;
symbol1203_558 = symbol1559___r4_symbols_6_4;
{
PUSH_TRACE(symbol1203_558);
BUNSPEC;
{
obj_t aux1202_559;
aux1202_559 = module_initialization_70___error(((long)0), "__R4_SYMBOLS_6_4");
POP_TRACE();
return aux1202_559;
}
}
}
}

