/*===========================================================================*/
/*   (Cnst/walk.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t _old_unsafe_type__146_cnst_walk = BUNSPEC;
static obj_t _old_unsafe_struct__195_cnst_walk = BUNSPEC;
static obj_t method_init_76_cnst_walk();
static obj_t unsafe__47_cnst_walk();
static obj_t _cnst_walk__8_cnst_walk(obj_t, obj_t);
static obj_t _old_unsafe_arity__240_cnst_walk = BUNSPEC;
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
static obj_t _start_cnst_alloc__241_cnst_alloc(obj_t);
extern obj_t leave_function_170_tools_error();
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t _unsafe_struct__195_engine_param;
extern obj_t module_initialization_70_cnst_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_cnst_alloc(long, char *);
extern obj_t module_initialization_70_cnst_cache(long, char *);
extern obj_t module_initialization_70_cnst_node(long, char *);
extern obj_t module_initialization_70_cnst_initialize(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t _unsafe_arity__240_engine_param;
static obj_t _old_unsafe_version__81_cnst_walk = BUNSPEC;
extern obj_t _unsafe_version__81_engine_param;
static obj_t _safe__136_cnst_walk(obj_t);
static obj_t imported_modules_init_94_cnst_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_cnst_walk();
static obj_t toplevel_init_63_cnst_walk();
extern obj_t _unsafe_type__146_engine_param;
static obj_t _start_cnst_cache__252_cnst_cache(obj_t);
extern obj_t open_input_string(obj_t);
static obj_t _old_unsafe_range__218_cnst_walk = BUNSPEC;
extern obj_t initialize_ast_128_cnst_initialize();
extern obj_t string_to_bstring(char *);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t cnst_walk__13_cnst_walk(obj_t);
extern obj_t _init_mode__183_engine_param;
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern obj_t _unsafe_range__218_engine_param;
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _unsafe__49_cnst_walk(obj_t);
static obj_t safe__104_cnst_walk();
static obj_t require_initialization_114_cnst_walk = BUNSPEC;
extern node_t cnst__44_cnst_node(node_t);
static obj_t _stop_cnst_alloc__84_cnst_alloc(obj_t);
static obj_t cnst_init_137_cnst_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(cnst_walk__env_34_cnst_walk, _cnst_walk__8_cnst_walk1617, _cnst_walk__8_cnst_walk, 0L, 1);
extern obj_t start_cnst_cache__env_224_cnst_cache;
DEFINE_STATIC_PROCEDURE(safe__env_5_cnst_walk, _safe__136_cnst_walk1618, _safe__136_cnst_walk, 0L, 0);
DEFINE_STATIC_PROCEDURE(unsafe__env_61_cnst_walk, _unsafe__49_cnst_walk1619, _unsafe__49_cnst_walk, 0L, 0);
extern obj_t start_cnst_alloc__env_227_cnst_alloc;
extern obj_t stop_cnst_alloc__env_174_cnst_alloc;
DEFINE_STRING(string1611_cnst_walk, string1611_cnst_walk1620, "(STOP-CNST-ALLOC! SAFE!) CNST (START-CNST-CACHE! START-CNST-ALLOC! UNSAFE!) PASS-STARTED ", 89);
DEFINE_STRING(string1609_cnst_walk, string1609_cnst_walk1621, " error", 6);
DEFINE_STRING(string1610_cnst_walk, string1610_cnst_walk1622, "failure during postlude hook", 28);
DEFINE_STRING(string1608_cnst_walk, string1608_cnst_walk1623, " occured, ending ...", 20);
DEFINE_STRING(string1607_cnst_walk, string1607_cnst_walk1624, "      [", 7);
DEFINE_STRING(string1606_cnst_walk, string1606_cnst_walk1625, "failure during prelude hook", 27);
DEFINE_STRING(string1605_cnst_walk, string1605_cnst_walk1626, "   . ", 5);
DEFINE_STRING(string1604_cnst_walk, string1604_cnst_walk1627, "Cnst", 4);


/* module-initialization */ obj_t 
module_initialization_70_cnst_walk(long checksum_1127, char *from_1128)
{
   if (CBOOL(require_initialization_114_cnst_walk))
     {
	require_initialization_114_cnst_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_cnst_walk();
	cnst_init_137_cnst_walk();
	imported_modules_init_94_cnst_walk();
	method_init_76_cnst_walk();
	toplevel_init_63_cnst_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cnst_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "CNST_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CNST_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "CNST_WALK");
   module_initialization_70___reader(((long) 0), "CNST_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cnst_walk()
{
   {
      obj_t cnst_port_138_1119;
      cnst_port_138_1119 = open_input_string(string1611_cnst_walk);
      {
	 long i_1120;
	 i_1120 = ((long) 3);
       loop_1121:
	 {
	    bool_t test1612_1122;
	    test1612_1122 = (i_1120 == ((long) -1));
	    if (test1612_1122)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1613_1123;
		    {
		       obj_t list1614_1124;
		       {
			  obj_t arg1615_1125;
			  arg1615_1125 = BNIL;
			  list1614_1124 = MAKE_PAIR(cnst_port_138_1119, arg1615_1125);
		       }
		       arg1613_1123 = read___reader(list1614_1124);
		    }
		    CNST_TABLE_SET(i_1120, arg1613_1123);
		 }
		 {
		    int aux_1126;
		    {
		       long aux_1147;
		       aux_1147 = (i_1120 - ((long) 1));
		       aux_1126 = (int) (aux_1147);
		    }
		    {
		       long i_1150;
		       i_1150 = (long) (aux_1126);
		       i_1120 = i_1150;
		       goto loop_1121;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cnst_walk()
{
   _old_unsafe_type__146_cnst_walk = BFALSE;
   _old_unsafe_arity__240_cnst_walk = BFALSE;
   _old_unsafe_range__218_cnst_walk = BFALSE;
   _old_unsafe_struct__195_cnst_walk = BFALSE;
   return (_old_unsafe_version__81_cnst_walk = BFALSE,
      BUNSPEC);
}


/* cnst-walk! */ obj_t 
cnst_walk__13_cnst_walk(obj_t globals_1)
{
   {
      obj_t list1437_693;
      {
	 obj_t arg1440_695;
	 {
	    obj_t arg1443_697;
	    {
	       obj_t aux_1152;
	       aux_1152 = BCHAR(((unsigned char) '\n'));
	       arg1443_697 = MAKE_PAIR(aux_1152, BNIL);
	    }
	    arg1440_695 = MAKE_PAIR(string1604_cnst_walk, arg1443_697);
	 }
	 list1437_693 = MAKE_PAIR(string1605_cnst_walk, arg1440_695);
      }
      verbose_tools_speek(BINT(((long) 1)), list1437_693);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1604_cnst_walk;
   {
      obj_t hooks_699;
      obj_t hnames_700;
      {
	 obj_t arg1446_702;
	 obj_t arg1448_703;
	 {
	    obj_t list1449_704;
	    {
	       obj_t arg1450_705;
	       {
		  obj_t arg1453_706;
		  arg1453_706 = MAKE_PAIR(unsafe__env_61_cnst_walk, BNIL);
		  arg1450_705 = MAKE_PAIR(start_cnst_alloc__env_227_cnst_alloc, arg1453_706);
	       }
	       list1449_704 = MAKE_PAIR(start_cnst_cache__env_224_cnst_cache, arg1450_705);
	    }
	    arg1446_702 = list1449_704;
	 }
	 arg1448_703 = CNST_TABLE_REF(((long) 1));
	 hooks_699 = arg1446_702;
	 hnames_700 = arg1448_703;
       loop_701:
	 if (NULLP(hooks_699))
	   {
	      CNST_TABLE_REF(((long) 0));
	   }
	 else
	   {
	      bool_t test1456_709;
	      {
		 obj_t fun1465_715;
		 fun1465_715 = CAR(hooks_699);
		 {
		    obj_t aux_1168;
		    aux_1168 = PROCEDURE_ENTRY(fun1465_715) (fun1465_715, BEOA);
		    test1456_709 = CBOOL(aux_1168);
		 }
	      }
	      if (test1456_709)
		{
		   {
		      obj_t hnames_1175;
		      obj_t hooks_1173;
		      hooks_1173 = CDR(hooks_699);
		      hnames_1175 = CDR(hnames_700);
		      hnames_700 = hnames_1175;
		      hooks_699 = hooks_1173;
		      goto loop_701;
		   }
		}
	      else
		{
		   internal_error_43_tools_error(string1604_cnst_walk, string1606_cnst_walk, CAR(hnames_700));
		}
	   }
      }
   }
   {
      obj_t list1466_716;
      {
	 obj_t arg1468_718;
	 {
	    obj_t arg1469_719;
	    {
	       obj_t arg1470_720;
	       {
		  obj_t aux_1179;
		  aux_1179 = BCHAR(((unsigned char) '\n'));
		  arg1470_720 = MAKE_PAIR(aux_1179, BNIL);
	       }
	       {
		  obj_t aux_1182;
		  aux_1182 = BCHAR(((unsigned char) ']'));
		  arg1469_719 = MAKE_PAIR(aux_1182, arg1470_720);
	       }
	    }
	    arg1468_718 = MAKE_PAIR(_init_mode__183_engine_param, arg1469_719);
	 }
	 list1466_716 = MAKE_PAIR(string1607_cnst_walk, arg1468_718);
      }
      verbose_tools_speek(BINT(((long) 2)), list1466_716);
   }
   {
      obj_t l1435_722;
      l1435_722 = globals_1;
    lname1436_723:
      if (PAIRP(l1435_722))
	{
	   {
	      obj_t global_725;
	      global_725 = CAR(l1435_722);
	      {
		 obj_t aux_1192;
		 {
		    global_t obj_1095;
		    obj_1095 = (global_t) (global_725);
		    aux_1192 = (((global_t) CREF(obj_1095))->id);
		 }
		 enter_function_81_tools_error(aux_1192);
	      }
	      {
		 value_t fun_727;
		 {
		    global_t obj_1096;
		    obj_1096 = (global_t) (global_725);
		    fun_727 = (((global_t) CREF(obj_1096))->value);
		 }
		 {
		    node_t new_body_215_728;
		    {
		       node_t aux_1198;
		       {
			  obj_t aux_1199;
			  {
			     sfun_t obj_1097;
			     obj_1097 = (sfun_t) (fun_727);
			     aux_1199 = (((sfun_t) CREF(obj_1097))->body);
			  }
			  aux_1198 = (node_t) (aux_1199);
		       }
		       new_body_215_728 = cnst__44_cnst_node(aux_1198);
		    }
		    {
		       {
			  sfun_t obj_1098;
			  obj_t val1135_1099;
			  obj_1098 = (sfun_t) (fun_727);
			  val1135_1099 = (obj_t) (new_body_215_728);
			  ((((sfun_t) CREF(obj_1098))->body) = ((obj_t) val1135_1099), BUNSPEC);
		       }
		    }
		 }
	      }
	      leave_function_170_tools_error();
	   }
	   {
	      obj_t l1435_1208;
	      l1435_1208 = CDR(l1435_722);
	      l1435_722 = l1435_1208;
	      goto lname1436_723;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t value_731;
      {
	 obj_t arg1504_759;
	 obj_t arg1505_760;
	 arg1504_759 = CNST_TABLE_REF(((long) 2));
	 {
	    obj_t arg1507_761;
	    arg1507_761 = initialize_ast_128_cnst_initialize();
	    arg1505_760 = append_2_18___r4_pairs_and_lists_6_3(arg1507_761, globals_1);
	 }
	 value_731 = remove_var_123_ast_remove(arg1504_759, arg1505_760);
      }
      {
	 bool_t test1476_732;
	 {
	    long n1_1101;
	    n1_1101 = (long) CINT(_nb_error_on_pass__70_tools_error);
	    test1476_732 = (n1_1101 > ((long) 0));
	 }
	 if (test1476_732)
	   {
	      {
		 char *arg1479_735;
		 {
		    bool_t test1487_742;
		    {
		       bool_t test1488_743;
		       {
			  obj_t obj_1103;
			  obj_1103 = _nb_error_on_pass__70_tools_error;
			  test1488_743 = INTEGERP(obj_1103);
		       }
		       if (test1488_743)
			 {
			    test1487_742 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			 }
		       else
			 {
			    test1487_742 = ((bool_t) 0);
			 }
		    }
		    if (test1487_742)
		      {
			 arg1479_735 = "s";
		      }
		    else
		      {
			 arg1479_735 = "";
		      }
		 }
		 {
		    obj_t list1481_737;
		    {
		       obj_t arg1483_738;
		       {
			  obj_t arg1484_739;
			  {
			     obj_t arg1485_740;
			     arg1485_740 = MAKE_PAIR(string1608_cnst_walk, BNIL);
			     {
				obj_t aux_1223;
				aux_1223 = string_to_bstring(arg1479_735);
				arg1484_739 = MAKE_PAIR(aux_1223, arg1485_740);
			     }
			  }
			  arg1483_738 = MAKE_PAIR(string1609_cnst_walk, arg1484_739);
		       }
		       list1481_737 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1483_738);
		    }
		    fprint___r4_output_6_10_3(current_error_port, list1481_737);
		 }
	      }
	      {
		 obj_t res1603_1105;
		 exit(((long) -1));
		 res1603_1105 = BINT(((long) -1));
		 return res1603_1105;
	      }
	   }
	 else
	   {
	      obj_t hooks_744;
	      obj_t hnames_745;
	      {
		 obj_t arg1489_747;
		 obj_t arg1490_748;
		 {
		    obj_t list1491_749;
		    {
		       obj_t arg1494_750;
		       arg1494_750 = MAKE_PAIR(safe__env_5_cnst_walk, BNIL);
		       list1491_749 = MAKE_PAIR(stop_cnst_alloc__env_174_cnst_alloc, arg1494_750);
		    }
		    arg1489_747 = list1491_749;
		 }
		 arg1490_748 = CNST_TABLE_REF(((long) 3));
		 hooks_744 = arg1489_747;
		 hnames_745 = arg1490_748;
	       loop_746:
		 if (NULLP(hooks_744))
		   {
		      return value_731;
		   }
		 else
		   {
		      bool_t test1498_753;
		      {
			 obj_t fun1503_758;
			 fun1503_758 = CAR(hooks_744);
			 {
			    obj_t aux_1237;
			    aux_1237 = PROCEDURE_ENTRY(fun1503_758) (fun1503_758, BEOA);
			    test1498_753 = CBOOL(aux_1237);
			 }
		      }
		      if (test1498_753)
			{
			   {
			      obj_t hnames_1244;
			      obj_t hooks_1242;
			      hooks_1242 = CDR(hooks_744);
			      hnames_1244 = CDR(hnames_745);
			      hnames_745 = hnames_1244;
			      hooks_744 = hooks_1242;
			      goto loop_746;
			   }
			}
		      else
			{
			   return internal_error_43_tools_error(_current_pass__25_engine_pass, string1610_cnst_walk, CAR(hnames_745));
			}
		   }
	      }
	   }
      }
   }
}


/* _cnst-walk! */ obj_t 
_cnst_walk__8_cnst_walk(obj_t env_1112, obj_t globals_1113)
{
   return cnst_walk__13_cnst_walk(globals_1113);
}


/* unsafe! */ obj_t 
unsafe__47_cnst_walk()
{
   _old_unsafe_type__146_cnst_walk = _unsafe_type__146_engine_param;
   _unsafe_type__146_engine_param = BTRUE;
   _old_unsafe_arity__240_cnst_walk = _unsafe_arity__240_engine_param;
   _unsafe_arity__240_engine_param = BTRUE;
   _old_unsafe_range__218_cnst_walk = _unsafe_range__218_engine_param;
   _unsafe_range__218_engine_param = BTRUE;
   _old_unsafe_struct__195_cnst_walk = _unsafe_struct__195_engine_param;
   _unsafe_struct__195_engine_param = BTRUE;
   _old_unsafe_version__81_cnst_walk = _unsafe_version__81_engine_param;
   return (_unsafe_version__81_engine_param = BTRUE,
      BUNSPEC);
}


/* _unsafe! */ obj_t 
_unsafe__49_cnst_walk(obj_t env_1114)
{
   return unsafe__47_cnst_walk();
}


/* safe! */ obj_t 
safe__104_cnst_walk()
{
   _unsafe_type__146_engine_param = _old_unsafe_type__146_cnst_walk;
   _unsafe_arity__240_engine_param = _old_unsafe_arity__240_cnst_walk;
   _unsafe_range__218_engine_param = _old_unsafe_range__218_cnst_walk;
   _unsafe_struct__195_engine_param = _old_unsafe_struct__195_cnst_walk;
   return (_unsafe_version__81_engine_param = _old_unsafe_version__81_cnst_walk,
      BUNSPEC);
}


/* _safe! */ obj_t 
_safe__136_cnst_walk(obj_t env_1117)
{
   return safe__104_cnst_walk();
}


/* method-init */ obj_t 
method_init_76_cnst_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cnst_walk()
{
   module_initialization_70_tools_speek(((long) 0), "CNST_WALK");
   module_initialization_70_tools_error(((long) 0), "CNST_WALK");
   module_initialization_70_engine_pass(((long) 0), "CNST_WALK");
   module_initialization_70_tools_shape(((long) 0), "CNST_WALK");
   module_initialization_70_engine_param(((long) 0), "CNST_WALK");
   module_initialization_70_type_type(((long) 0), "CNST_WALK");
   module_initialization_70_ast_var(((long) 0), "CNST_WALK");
   module_initialization_70_ast_node(((long) 0), "CNST_WALK");
   module_initialization_70_ast_remove(((long) 0), "CNST_WALK");
   module_initialization_70_cnst_alloc(((long) 0), "CNST_WALK");
   module_initialization_70_cnst_cache(((long) 0), "CNST_WALK");
   module_initialization_70_cnst_node(((long) 0), "CNST_WALK");
   return module_initialization_70_cnst_initialize(((long) 0), "CNST_WALK");
}
