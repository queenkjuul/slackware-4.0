/*===========================================================================*/
/*   (Module/prototype.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_module_prototype();
extern obj_t dsssl_formals_skeleton_108_tools_dsssl(obj_t);
static obj_t parse_class_slot_207_module_prototype(obj_t);
static obj_t parse_class_slots_247_module_prototype(obj_t, obj_t);
static obj_t parse_variable_prototype_15_module_prototype(obj_t);
static obj_t _parse_prototype_185_module_prototype(obj_t, obj_t);
static bool_t correct_attribut__243_module_prototype(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_module_prototype(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
static obj_t imported_modules_init_94_module_prototype();
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_module_prototype();
extern obj_t open_input_string(obj_t);
static obj_t parse_function_prototype_96_module_prototype(obj_t, obj_t);
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
static obj_t parse_class_156_module_prototype(obj_t, obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_module_prototype = BUNSPEC;
extern obj_t parse_prototype_143_module_prototype(obj_t);
static obj_t cnst_init_137_module_prototype();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[17];

DEFINE_EXPORT_PROCEDURE(parse_prototype_env_42_module_prototype, _parse_prototype_185_module_prototype1440, _parse_prototype_185_module_prototype, 0L, 1);
DEFINE_STRING(string1433_module_prototype, string1433_module_prototype1441, "ASSERT DEFAULT SET GET (READ-ONLY) + * ID SVAR INLINE GENERIC WIDE-CLASS FINAL-CLASS CLASS SFUN SIFUN SGFUN ", 108);
DEFINE_STRING(string1432_module_prototype, string1432_module_prototype1442, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string1431_module_prototype, string1431_module_prototype1443, "cer", 3);
DEFINE_STRING(string1429_module_prototype, string1429_module_prototype1444, "Parse error", 11);
DEFINE_STRING(string1430_module_prototype, string1430_module_prototype1445, "Illegal class field definition", 30);


/* module-initialization */ obj_t 
module_initialization_70_module_prototype(long checksum_573, char *from_574)
{
   if (CBOOL(require_initialization_114_module_prototype))
     {
	require_initialization_114_module_prototype = BBOOL(((bool_t) 0));
	library_modules_init_112_module_prototype();
	cnst_init_137_module_prototype();
	imported_modules_init_94_module_prototype();
	method_init_76_module_prototype();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_module_prototype()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "MODULE_PROTOTYPE");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "MODULE_PROTOTYPE");
   module_initialization_70___reader(((long) 0), "MODULE_PROTOTYPE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_module_prototype()
{
   {
      obj_t cnst_port_138_565;
      cnst_port_138_565 = open_input_string(string1433_module_prototype);
      {
	 long i_566;
	 i_566 = ((long) 16);
       loop_567:
	 {
	    bool_t test1434_568;
	    test1434_568 = (i_566 == ((long) -1));
	    if (test1434_568)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1436_569;
		    {
		       obj_t list1437_570;
		       {
			  obj_t arg1438_571;
			  arg1438_571 = BNIL;
			  list1437_570 = MAKE_PAIR(cnst_port_138_565, arg1438_571);
		       }
		       arg1436_569 = read___reader(list1437_570);
		    }
		    CNST_TABLE_SET(i_566, arg1436_569);
		 }
		 {
		    int aux_572;
		    {
		       long aux_591;
		       aux_591 = (i_566 - ((long) 1));
		       aux_572 = (int) (aux_591);
		    }
		    {
		       long i_594;
		       i_594 = (long) (aux_572);
		       i_566 = i_594;
		       goto loop_567;
		    }
		 }
	      }
	 }
      }
   }
}


/* parse-prototype */ obj_t 
parse_prototype_143_module_prototype(obj_t prototype_1)
{
   {
      obj_t class_56;
      if (PAIRP(prototype_1))
	{
	   obj_t car_109_44_64;
	   car_109_44_64 = CAR(prototype_1);
	   {
	      bool_t test_599;
	      {
		 obj_t aux_600;
		 aux_600 = CNST_TABLE_REF(((long) 3));
		 test_599 = (car_109_44_64 == aux_600);
	      }
	      if (test_599)
		{
		   class_56 = car_109_44_64;
		 tag_101_79_57:
		   return parse_class_156_module_prototype(class_56, CDR(prototype_1));
		}
	      else
		{
		   bool_t test_605;
		   {
		      obj_t aux_606;
		      aux_606 = CNST_TABLE_REF(((long) 4));
		      test_605 = (car_109_44_64 == aux_606);
		   }
		   if (test_605)
		     {
			obj_t class_609;
			class_609 = car_109_44_64;
			class_56 = class_609;
			goto tag_101_79_57;
		     }
		   else
		     {
			bool_t test_610;
			{
			   obj_t aux_611;
			   aux_611 = CNST_TABLE_REF(((long) 5));
			   test_610 = (car_109_44_64 == aux_611);
			}
			if (test_610)
			  {
			     obj_t class_614;
			     class_614 = car_109_44_64;
			     class_56 = class_614;
			     goto tag_101_79_57;
			  }
			else
			  {
			     bool_t test_615;
			     {
				obj_t aux_616;
				aux_616 = CNST_TABLE_REF(((long) 6));
				test_615 = (car_109_44_64 == aux_616);
			     }
			     if (test_615)
			       {
				  return parse_function_prototype_96_module_prototype(CDR(prototype_1), CNST_TABLE_REF(((long) 0)));
			       }
			     else
			       {
				  bool_t test_622;
				  {
				     obj_t aux_623;
				     aux_623 = CNST_TABLE_REF(((long) 7));
				     test_622 = (car_109_44_64 == aux_623);
				  }
				  if (test_622)
				    {
				       return parse_function_prototype_96_module_prototype(CDR(prototype_1), CNST_TABLE_REF(((long) 1)));
				    }
				  else
				    {
				       return parse_function_prototype_96_module_prototype(prototype_1, CNST_TABLE_REF(((long) 2)));
				    }
			       }
			  }
		     }
		}
	   }
	}
      else
	{
	   return parse_variable_prototype_15_module_prototype(prototype_1);
	}
   }
}


/* _parse-prototype */ obj_t 
_parse_prototype_185_module_prototype(obj_t env_562, obj_t prototype_563)
{
   return parse_prototype_143_module_prototype(prototype_563);
}


/* parse-function-prototype */ obj_t 
parse_function_prototype_96_module_prototype(obj_t proto_2, obj_t class_3)
{
   {
      obj_t id_84;
      obj_t the_args_8_85;
      if (PAIRP(proto_2))
	{
	   obj_t car_128_220_90;
	   car_128_220_90 = CAR(proto_2);
	   if (SYMBOLP(car_128_220_90))
	     {
		id_84 = car_128_220_90;
		the_args_8_85 = CDR(proto_2);
		{
		   obj_t args_93;
		   args_93 = the_args_8_85;
		 loop_94:
		   if (NULLP(args_93))
		     {
			{
			   obj_t arg1137_96;
			   arg1137_96 = dsssl_formals_skeleton_108_tools_dsssl(the_args_8_85);
			   {
			      obj_t list1138_97;
			      {
				 obj_t arg1142_98;
				 {
				    obj_t arg1144_99;
				    arg1144_99 = MAKE_PAIR(arg1137_96, BNIL);
				    arg1142_98 = MAKE_PAIR(id_84, arg1144_99);
				 }
				 list1138_97 = MAKE_PAIR(class_3, arg1142_98);
			      }
			      return list1138_97;
			   }
			}
		     }
		   else
		     {
			if (SYMBOLP(args_93))
			  {
			     {
				obj_t list1147_102;
				{
				   obj_t arg1150_103;
				   {
				      obj_t arg1157_104;
				      arg1157_104 = MAKE_PAIR(the_args_8_85, BNIL);
				      arg1150_103 = MAKE_PAIR(id_84, arg1157_104);
				   }
				   list1147_102 = MAKE_PAIR(class_3, arg1150_103);
				}
				return list1147_102;
			     }
			  }
			else
			  {
			     bool_t test1162_106;
			     if (PAIRP(args_93))
			       {
				  bool_t _ortest_1028_109;
				  {
				     obj_t aux_651;
				     aux_651 = CAR(args_93);
				     _ortest_1028_109 = SYMBOLP(aux_651);
				  }
				  if (_ortest_1028_109)
				    {
				       test1162_106 = _ortest_1028_109;
				    }
				  else
				    {
				       obj_t aux_655;
				       aux_655 = dsssl_named_constant__188_tools_dsssl(CAR(args_93));
				       test1162_106 = CBOOL(aux_655);
				    }
			       }
			     else
			       {
				  test1162_106 = ((bool_t) 0);
			       }
			     if (test1162_106)
			       {
				  {
				     obj_t args_660;
				     args_660 = CDR(args_93);
				     args_93 = args_660;
				     goto loop_94;
				  }
			       }
			     else
			       {
				  return BFALSE;
			       }
			  }
		     }
		}
	     }
	   else
	     {
		return BFALSE;
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* parse-variable-prototype */ obj_t 
parse_variable_prototype_15_module_prototype(obj_t proto_4)
{
   if (SYMBOLP(proto_4))
     {
	obj_t arg1187_113;
	arg1187_113 = CNST_TABLE_REF(((long) 8));
	{
	   obj_t list1188_114;
	   {
	      obj_t arg1190_115;
	      arg1190_115 = MAKE_PAIR(proto_4, BNIL);
	      list1188_114 = MAKE_PAIR(arg1187_113, arg1190_115);
	   }
	   return list1188_114;
	}
     }
   else
     {
	return BFALSE;
     }
}


/* parse-class */ obj_t 
parse_class_156_module_prototype(obj_t class_5, obj_t class_def_12_6)
{
   {
      obj_t name_122;
      obj_t slots_123;
      if (PAIRP(class_def_12_6))
	{
	   obj_t car_143_62_128;
	   obj_t cdr_144_157_129;
	   car_143_62_128 = CAR(class_def_12_6);
	   cdr_144_157_129 = CDR(class_def_12_6);
	   if (SYMBOLP(car_143_62_128))
	     {
		if (PAIRP(cdr_144_157_129))
		  {
		     obj_t car_149_47_132;
		     car_149_47_132 = CAR(cdr_144_157_129);
		     if (PAIRP(car_149_47_132))
		       {
			  bool_t test_679;
			  {
			     obj_t aux_680;
			     aux_680 = CDR(car_149_47_132);
			     test_679 = (aux_680 == BNIL);
			  }
			  if (test_679)
			    {
			       obj_t arg1197_135;
			       arg1197_135 = CAR(car_149_47_132);
			       {
				  obj_t arg1210_439;
				  arg1210_439 = parse_class_slots_247_module_prototype(class_def_12_6, CDR(cdr_144_157_129));
				  {
				     obj_t list1211_440;
				     {
					obj_t arg1213_441;
					{
					   obj_t arg1214_442;
					   arg1214_442 = MAKE_PAIR(arg1210_439, BNIL);
					   arg1213_441 = MAKE_PAIR(arg1197_135, arg1214_442);
					}
					list1211_440 = MAKE_PAIR(car_143_62_128, arg1213_441);
				     }
				     return cons__138___r4_pairs_and_lists_6_3(class_5, list1211_440);
				  }
			       }
			    }
			  else
			    {
			       if (SYMBOLP(car_143_62_128))
				 {
				    name_122 = car_143_62_128;
				    slots_123 = cdr_144_157_129;
				  tag_134_32_124:
				    {
				       obj_t arg1219_156;
				       arg1219_156 = parse_class_slots_247_module_prototype(class_def_12_6, slots_123);
				       {
					  obj_t list1220_157;
					  {
					     obj_t arg1221_158;
					     {
						obj_t arg1222_159;
						arg1222_159 = MAKE_PAIR(arg1219_156, BNIL);
						arg1221_158 = MAKE_PAIR(BFALSE, arg1222_159);
					     }
					     list1220_157 = MAKE_PAIR(name_122, arg1221_158);
					  }
					  return cons__138___r4_pairs_and_lists_6_3(class_5, list1220_157);
				       }
				    }
				 }
			       else
				 {
				    return BFALSE;
				 }
			    }
		       }
		     else
		       {
			  if (SYMBOLP(car_143_62_128))
			    {
			       obj_t slots_700;
			       obj_t name_699;
			       name_699 = car_143_62_128;
			       slots_700 = cdr_144_157_129;
			       slots_123 = slots_700;
			       name_122 = name_699;
			       goto tag_134_32_124;
			    }
			  else
			    {
			       return BFALSE;
			    }
		       }
		  }
		else
		  {
		     if (SYMBOLP(car_143_62_128))
		       {
			  obj_t slots_704;
			  obj_t name_703;
			  name_703 = car_143_62_128;
			  slots_704 = cdr_144_157_129;
			  slots_123 = slots_704;
			  name_122 = name_703;
			  goto tag_134_32_124;
		       }
		     else
		       {
			  return BFALSE;
		       }
		  }
	     }
	   else
	     {
		if (SYMBOLP(car_143_62_128))
		  {
		     obj_t slots_708;
		     obj_t name_707;
		     name_707 = car_143_62_128;
		     slots_708 = cdr_144_157_129;
		     slots_123 = slots_708;
		     name_122 = name_707;
		     goto tag_134_32_124;
		  }
		else
		  {
		     return BFALSE;
		  }
	     }
	}
      else
	{
	   return BFALSE;
	}
   }
}


/* parse-class-slots */ obj_t 
parse_class_slots_247_module_prototype(obj_t class_def_12_564, obj_t slots_161)
{
   {
      obj_t slots_163;
      obj_t res_164;
      slots_163 = slots_161;
      res_164 = BNIL;
    loop_165:
      if (NULLP(slots_163))
	{
	   return reverse__39___r4_pairs_and_lists_6_3(res_164);
	}
      else
	{
	   if (PAIRP(slots_163))
	     {
		{
		   obj_t slot_169;
		   slot_169 = parse_class_slot_207_module_prototype(CAR(slots_163));
		   if (CBOOL(slot_169))
		     {
			obj_t arg1231_170;
			obj_t arg1232_171;
			arg1231_170 = CDR(slots_163);
			arg1232_171 = MAKE_PAIR(slot_169, res_164);
			{
			   obj_t res_721;
			   obj_t slots_720;
			   slots_720 = arg1231_170;
			   res_721 = arg1232_171;
			   res_164 = res_721;
			   slots_163 = slots_720;
			   goto loop_165;
			}
		     }
		   else
		     {
			return user_error_151_tools_error(string1429_module_prototype, string1430_module_prototype, class_def_12_564, BNIL);
		     }
		}
	     }
	   else
	     {
		return BFALSE;
	     }
	}
   }
}


/* parse-class-slot */ obj_t 
parse_class_slot_207_module_prototype(obj_t slot_7)
{
   {
      obj_t def_317;
      obj_t src_318;
      {
	 obj_t id_190;
	 obj_t att_191;
	 obj_t string_185;
	 obj_t len_186;
	 obj_t id_187;
	 obj_t att_188;
	 obj_t integer_180;
	 obj_t len_181;
	 obj_t id_182;
	 obj_t att_183;
	 obj_t id_177;
	 obj_t att_178;
	 if (SYMBOLP(slot_7))
	   {
	      {
		 obj_t arg1268_240;
		 {
		    obj_t arg1269_241;
		    obj_t arg1270_242;
		    arg1269_241 = CNST_TABLE_REF(((long) 9));
		    arg1270_242 = parse_id_241_ast_ident(slot_7);
		    {
		       obj_t list1273_244;
		       {
			  obj_t arg1274_245;
			  arg1274_245 = MAKE_PAIR(BNIL, BNIL);
			  list1273_244 = MAKE_PAIR(arg1270_242, arg1274_245);
		       }
		       arg1268_240 = cons__138___r4_pairs_and_lists_6_3(arg1269_241, list1273_244);
		    }
		 }
		 def_317 = arg1268_240;
		 src_318 = slot_7;
	       epairify_324:
		 {
		    bool_t test1373_320;
		    test1373_320 = EXTENDED_PAIRP(src_318);
		    if (test1373_320)
		      {
			 obj_t arg1375_321;
			 obj_t arg1378_322;
			 obj_t arg1379_323;
			 arg1375_321 = CAR(def_317);
			 arg1378_322 = CDR(def_317);
			 {
			    bool_t test1137_516;
			    test1137_516 = EXTENDED_PAIRP(src_318);
			    if (test1137_516)
			      {
				 arg1379_323 = CER(src_318);
			      }
			    else
			      {
				 FAILURE(string1431_module_prototype, string1432_module_prototype, src_318);
			      }
			 }
			 return MAKE_EXTENDED_PAIR(arg1375_321, arg1378_322, arg1379_323);
		      }
		    else
		      {
			 return def_317;
		      }
		 }
	      }
	   }
	 else
	   {
	      if (PAIRP(slot_7))
		{
		   obj_t cdr_228_151_197;
		   cdr_228_151_197 = CDR(slot_7);
		   {
		      bool_t test_742;
		      {
			 obj_t aux_745;
			 obj_t aux_743;
			 aux_745 = CNST_TABLE_REF(((long) 10));
			 aux_743 = CAR(slot_7);
			 test_742 = (aux_743 == aux_745);
		      }
		      if (test_742)
			{
			   if (PAIRP(cdr_228_151_197))
			     {
				obj_t car_231_183_200;
				car_231_183_200 = CAR(cdr_228_151_197);
				if (SYMBOLP(car_231_183_200))
				  {
				     id_177 = car_231_183_200;
				     att_178 = CDR(cdr_228_151_197);
				     if (correct_attribut__243_module_prototype(att_178))
				       {
					  obj_t arg1281_248;
					  {
					     obj_t arg1282_249;
					     obj_t arg1283_250;
					     obj_t arg1284_251;
					     arg1282_249 = CNST_TABLE_REF(((long) 10));
					     {
						obj_t arg1288_255;
						obj_t arg1290_256;
						arg1288_255 = CNST_TABLE_REF(((long) 9));
						arg1290_256 = parse_id_241_ast_ident(id_177);
						{
						   obj_t list1292_258;
						   {
						      obj_t arg1294_259;
						      arg1294_259 = MAKE_PAIR(BNIL, BNIL);
						      list1292_258 = MAKE_PAIR(arg1290_256, arg1294_259);
						   }
						   arg1283_250 = cons__138___r4_pairs_and_lists_6_3(arg1288_255, list1292_258);
						}
					     }
					     {
						obj_t arg1296_261;
						arg1296_261 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						arg1284_251 = append_2_18___r4_pairs_and_lists_6_3(att_178, arg1296_261);
					     }
					     {
						obj_t list1285_252;
						{
						   obj_t arg1286_253;
						   arg1286_253 = MAKE_PAIR(arg1284_251, BNIL);
						   list1285_252 = MAKE_PAIR(arg1283_250, arg1286_253);
						}
						arg1281_248 = cons__138___r4_pairs_and_lists_6_3(arg1282_249, list1285_252);
					     }
					  }
					  {
					     obj_t src_767;
					     obj_t def_766;
					     def_766 = arg1281_248;
					     src_767 = slot_7;
					     src_318 = src_767;
					     def_317 = def_766;
					     goto epairify_324;
					  }
				       }
				     else
				       {
					  return BFALSE;
				       }
				  }
				else
				  {
				     obj_t car_257_21_203;
				     car_257_21_203 = CAR(slot_7);
				     if (SYMBOLP(car_257_21_203))
				       {
					  id_190 = car_257_21_203;
					  att_191 = cdr_228_151_197;
					tag_212_158_192:
					  if (correct_attribut__243_module_prototype(att_191))
					    {
					       obj_t arg1352_303;
					       {
						  obj_t arg1353_304;
						  obj_t arg1355_305;
						  {
						     obj_t arg1361_308;
						     obj_t arg1363_309;
						     arg1361_308 = CNST_TABLE_REF(((long) 9));
						     arg1363_309 = parse_id_241_ast_ident(id_190);
						     {
							obj_t list1365_311;
							{
							   obj_t arg1367_312;
							   arg1367_312 = MAKE_PAIR(BNIL, BNIL);
							   list1365_311 = MAKE_PAIR(arg1363_309, arg1367_312);
							}
							arg1353_304 = cons__138___r4_pairs_and_lists_6_3(arg1361_308, list1365_311);
						     }
						  }
						  {
						     obj_t arg1369_314;
						     arg1369_314 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						     arg1355_305 = append_2_18___r4_pairs_and_lists_6_3(att_191, arg1369_314);
						  }
						  {
						     obj_t list1356_306;
						     list1356_306 = MAKE_PAIR(arg1355_305, BNIL);
						     arg1352_303 = cons__138___r4_pairs_and_lists_6_3(arg1353_304, list1356_306);
						  }
					       }
					       {
						  obj_t src_784;
						  obj_t def_783;
						  def_783 = arg1352_303;
						  src_784 = slot_7;
						  src_318 = src_784;
						  def_317 = def_783;
						  goto epairify_324;
					       }
					    }
					  else
					    {
					       return BFALSE;
					    }
				       }
				     else
				       {
					  return BFALSE;
				       }
				  }
			     }
			   else
			     {
				obj_t car_283_154_206;
				car_283_154_206 = CAR(slot_7);
				if (SYMBOLP(car_283_154_206))
				  {
				     obj_t att_789;
				     obj_t id_788;
				     id_788 = car_283_154_206;
				     att_789 = cdr_228_151_197;
				     att_191 = att_789;
				     id_190 = id_788;
				     goto tag_212_158_192;
				  }
				else
				  {
				     return BFALSE;
				  }
			     }
			}
		      else
			{
			   bool_t test_790;
			   {
			      obj_t aux_793;
			      obj_t aux_791;
			      aux_793 = CNST_TABLE_REF(((long) 11));
			      aux_791 = CAR(slot_7);
			      test_790 = (aux_791 == aux_793);
			   }
			   if (test_790)
			     {
				if (PAIRP(cdr_228_151_197))
				  {
				     obj_t car_303_143_212;
				     obj_t cdr_304_134_213;
				     car_303_143_212 = CAR(cdr_228_151_197);
				     cdr_304_134_213 = CDR(cdr_228_151_197);
				     if (PAIRP(cdr_304_134_213))
				       {
					  obj_t car_314_235_215;
					  car_314_235_215 = CAR(cdr_304_134_213);
					  if (SYMBOLP(car_314_235_215))
					    {
					       integer_180 = car_303_143_212;
					       len_181 = car_303_143_212;
					       id_182 = car_314_235_215;
					       att_183 = CDR(cdr_304_134_213);
					       if (correct_attribut__243_module_prototype(att_183))
						 {
						    obj_t arg1300_265;
						    {
						       obj_t arg1301_266;
						       char *arg1302_267;
						       obj_t arg1303_268;
						       obj_t arg1304_269;
						       arg1301_266 = CNST_TABLE_REF(((long) 11));
						       arg1302_267 = integer__string_135___r4_numbers_6_5_fixnum((long) CINT(len_181), BNIL);
						       {
							  obj_t arg1311_275;
							  obj_t arg1313_276;
							  arg1311_275 = CNST_TABLE_REF(((long) 9));
							  arg1313_276 = parse_id_241_ast_ident(id_182);
							  {
							     obj_t list1316_278;
							     {
								obj_t arg1319_279;
								arg1319_279 = MAKE_PAIR(BNIL, BNIL);
								list1316_278 = MAKE_PAIR(arg1313_276, arg1319_279);
							     }
							     arg1303_268 = cons__138___r4_pairs_and_lists_6_3(arg1311_275, list1316_278);
							  }
						       }
						       {
							  obj_t arg1322_281;
							  arg1322_281 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							  arg1304_269 = append_2_18___r4_pairs_and_lists_6_3(att_183, arg1322_281);
						       }
						       {
							  obj_t list1305_270;
							  {
							     obj_t arg1307_271;
							     {
								obj_t arg1308_272;
								arg1308_272 = MAKE_PAIR(arg1304_269, BNIL);
								arg1307_271 = MAKE_PAIR(arg1303_268, arg1308_272);
							     }
							     {
								obj_t aux_819;
								aux_819 = string_to_bstring(arg1302_267);
								list1305_270 = MAKE_PAIR(aux_819, arg1307_271);
							     }
							  }
							  arg1300_265 = cons__138___r4_pairs_and_lists_6_3(arg1301_266, list1305_270);
						       }
						    }
						    {
						       obj_t src_824;
						       obj_t def_823;
						       def_823 = arg1300_265;
						       src_824 = slot_7;
						       src_318 = src_824;
						       def_317 = def_823;
						       goto epairify_324;
						    }
						 }
					       else
						 {
						    return BFALSE;
						 }
					    }
					  else
					    {
					       obj_t car_335_183_219;
					       obj_t cdr_336_47_220;
					       car_335_183_219 = CAR(cdr_228_151_197);
					       cdr_336_47_220 = CDR(cdr_228_151_197);
					       {
						  obj_t car_346_62_221;
						  car_346_62_221 = CAR(cdr_336_47_220);
						  if (SYMBOLP(car_346_62_221))
						    {
						       string_185 = car_335_183_219;
						       len_186 = car_335_183_219;
						       id_187 = car_346_62_221;
						       att_188 = CDR(cdr_336_47_220);
						       if (correct_attribut__243_module_prototype(att_188))
							 {
							    obj_t arg1326_285;
							    {
							       obj_t arg1328_286;
							       obj_t arg1330_287;
							       obj_t arg1331_288;
							       arg1328_286 = CNST_TABLE_REF(((long) 11));
							       {
								  obj_t arg1339_293;
								  obj_t arg1340_294;
								  arg1339_293 = CNST_TABLE_REF(((long) 9));
								  arg1340_294 = parse_id_241_ast_ident(id_187);
								  {
								     obj_t list1343_296;
								     {
									obj_t arg1344_297;
									arg1344_297 = MAKE_PAIR(BNIL, BNIL);
									list1343_296 = MAKE_PAIR(arg1340_294, arg1344_297);
								     }
								     arg1330_287 = cons__138___r4_pairs_and_lists_6_3(arg1339_293, list1343_296);
								  }
							       }
							       {
								  obj_t arg1347_299;
								  arg1347_299 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
								  arg1331_288 = append_2_18___r4_pairs_and_lists_6_3(att_188, arg1347_299);
							       }
							       {
								  obj_t list1332_289;
								  {
								     obj_t arg1333_290;
								     {
									obj_t arg1334_291;
									arg1334_291 = MAKE_PAIR(arg1331_288, BNIL);
									arg1333_290 = MAKE_PAIR(arg1330_287, arg1334_291);
								     }
								     list1332_289 = MAKE_PAIR(len_186, arg1333_290);
								  }
								  arg1326_285 = cons__138___r4_pairs_and_lists_6_3(arg1328_286, list1332_289);
							       }
							    }
							    {
							       obj_t src_846;
							       obj_t def_845;
							       def_845 = arg1326_285;
							       src_846 = slot_7;
							       src_318 = src_846;
							       def_317 = def_845;
							       goto epairify_324;
							    }
							 }
						       else
							 {
							    return BFALSE;
							 }
						    }
						  else
						    {
						       obj_t car_357_240_224;
						       car_357_240_224 = CAR(slot_7);
						       if (SYMBOLP(car_357_240_224))
							 {
							    obj_t att_852;
							    obj_t id_851;
							    id_851 = car_357_240_224;
							    att_852 = cdr_228_151_197;
							    att_191 = att_852;
							    id_190 = id_851;
							    goto tag_212_158_192;
							 }
						       else
							 {
							    return BFALSE;
							 }
						    }
					       }
					    }
				       }
				     else
				       {
					  obj_t car_374_148_227;
					  car_374_148_227 = CAR(slot_7);
					  if (SYMBOLP(car_374_148_227))
					    {
					       obj_t att_857;
					       obj_t id_856;
					       id_856 = car_374_148_227;
					       att_857 = cdr_228_151_197;
					       att_191 = att_857;
					       id_190 = id_856;
					       goto tag_212_158_192;
					    }
					  else
					    {
					       return BFALSE;
					    }
				       }
				  }
				else
				  {
				     obj_t car_391_153_230;
				     car_391_153_230 = CAR(slot_7);
				     if (SYMBOLP(car_391_153_230))
				       {
					  obj_t att_862;
					  obj_t id_861;
					  id_861 = car_391_153_230;
					  att_862 = cdr_228_151_197;
					  att_191 = att_862;
					  id_190 = id_861;
					  goto tag_212_158_192;
				       }
				     else
				       {
					  return BFALSE;
				       }
				  }
			     }
			   else
			     {
				obj_t car_408_253_233;
				car_408_253_233 = CAR(slot_7);
				if (SYMBOLP(car_408_253_233))
				  {
				     obj_t att_867;
				     obj_t id_866;
				     id_866 = car_408_253_233;
				     att_867 = cdr_228_151_197;
				     att_191 = att_867;
				     id_190 = id_866;
				     goto tag_212_158_192;
				  }
				else
				  {
				     return BFALSE;
				  }
			     }
			}
		   }
		}
	      else
		{
		   return BFALSE;
		}
	   }
      }
   }
}


/* correct-attribut? */ bool_t 
correct_attribut__243_module_prototype(obj_t attribut_8)
{
   {
      obj_t attribut_325;
      attribut_325 = attribut_8;
    loop_326:
      if (NULLP(attribut_325))
	{
	   return ((bool_t) 1);
	}
      else
	{
	   bool_t test_870;
	   {
	      obj_t aux_871;
	      aux_871 = memq___r4_pairs_and_lists_6_3(CAR(attribut_325), CNST_TABLE_REF(((long) 12)));
	      test_870 = CBOOL(aux_871);
	   }
	   if (test_870)
	     {
		{
		   obj_t attribut_876;
		   attribut_876 = CDR(attribut_325);
		   attribut_325 = attribut_876;
		   goto loop_326;
		}
	     }
	   else
	     {
		{
		   {
		      obj_t e_439_141_335;
		      e_439_141_335 = CAR(attribut_325);
		      if (PAIRP(e_439_141_335))
			{
			   obj_t cdr_441_164_337;
			   cdr_441_164_337 = CDR(e_439_141_335);
			   {
			      bool_t test_882;
			      {
				 obj_t aux_885;
				 obj_t aux_883;
				 aux_885 = CNST_TABLE_REF(((long) 13));
				 aux_883 = CAR(e_439_141_335);
				 test_882 = (aux_883 == aux_885);
			      }
			      if (test_882)
				{
				   if (PAIRP(cdr_441_164_337))
				     {
					bool_t test_890;
					{
					   obj_t aux_891;
					   aux_891 = CDR(cdr_441_164_337);
					   test_890 = (aux_891 == BNIL);
					}
					if (test_890)
					  {
					     {
						obj_t attribut_894;
						attribut_894 = CDR(attribut_325);
						attribut_325 = attribut_894;
						goto loop_326;
					     }
					  }
					else
					  {
					     return ((bool_t) 0);
					  }
				     }
				   else
				     {
					return ((bool_t) 0);
				     }
				}
			      else
				{
				   bool_t test_896;
				   {
				      obj_t aux_899;
				      obj_t aux_897;
				      aux_899 = CNST_TABLE_REF(((long) 14));
				      aux_897 = CAR(e_439_141_335);
				      test_896 = (aux_897 == aux_899);
				   }
				   if (test_896)
				     {
					if (PAIRP(cdr_441_164_337))
					  {
					     bool_t test_904;
					     {
						obj_t aux_905;
						aux_905 = CDR(cdr_441_164_337);
						test_904 = (aux_905 == BNIL);
					     }
					     if (test_904)
					       {
						  {
						     obj_t attribut_908;
						     attribut_908 = CDR(attribut_325);
						     attribut_325 = attribut_908;
						     goto loop_326;
						  }
					       }
					     else
					       {
						  return ((bool_t) 0);
					       }
					  }
					else
					  {
					     return ((bool_t) 0);
					  }
				     }
				   else
				     {
					bool_t test_910;
					{
					   obj_t aux_913;
					   obj_t aux_911;
					   aux_913 = CNST_TABLE_REF(((long) 15));
					   aux_911 = CAR(e_439_141_335);
					   test_910 = (aux_911 == aux_913);
					}
					if (test_910)
					  {
					     if (PAIRP(cdr_441_164_337))
					       {
						  bool_t test_918;
						  {
						     obj_t aux_919;
						     aux_919 = CDR(cdr_441_164_337);
						     test_918 = (aux_919 == BNIL);
						  }
						  if (test_918)
						    {
						       {
							  obj_t attribut_922;
							  attribut_922 = CDR(attribut_325);
							  attribut_325 = attribut_922;
							  goto loop_326;
						       }
						    }
						  else
						    {
						       return ((bool_t) 0);
						    }
					       }
					     else
					       {
						  return ((bool_t) 0);
					       }
					  }
					else
					  {
					     bool_t test_924;
					     {
						obj_t aux_927;
						obj_t aux_925;
						aux_927 = CNST_TABLE_REF(((long) 16));
						aux_925 = CAR(e_439_141_335);
						test_924 = (aux_925 == aux_927);
					     }
					     if (test_924)
					       {
						  if (PAIRP(cdr_441_164_337))
						    {
						       {
							  obj_t attribut_932;
							  attribut_932 = CDR(attribut_325);
							  attribut_325 = attribut_932;
							  goto loop_326;
						       }
						    }
						  else
						    {
						       return ((bool_t) 0);
						    }
					       }
					     else
					       {
						  return ((bool_t) 0);
					       }
					  }
				     }
				}
			   }
			}
		      else
			{
			   return ((bool_t) 0);
			}
		   }
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_module_prototype()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_module_prototype()
{
   module_initialization_70_tools_error(((long) 0), "MODULE_PROTOTYPE");
   module_initialization_70_tools_dsssl(((long) 0), "MODULE_PROTOTYPE");
   module_initialization_70_type_type(((long) 0), "MODULE_PROTOTYPE");
   return module_initialization_70_ast_ident(((long) 0), "MODULE_PROTOTYPE");
}
