/*===========================================================================*/
/*   (Reduce/copy.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_reduce_copy();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static node_t node_copy__default1460_47_reduce_copy(node_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t reduce_copy__103_reduce_copy(obj_t);
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_copy(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_reduce_copy();
static obj_t _reduce_copy__94_reduce_copy(obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_reduce_copy();
static obj_t _node_copy__default1460_196_reduce_copy(obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_reduce_copy();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static node_t node_copy__175_reduce_copy(node_t);
static obj_t node_copy___108_reduce_copy(obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t _node_copy_1716_45_reduce_copy(obj_t, obj_t);
static obj_t require_initialization_114_reduce_copy = BUNSPEC;
extern obj_t conditional_ast_node;
static long _copy_removed__156_reduce_copy;
static obj_t cnst_init_137_reduce_copy();
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(reduce_copy__env_21_reduce_copy, _reduce_copy__94_reduce_copy1726, _reduce_copy__94_reduce_copy, 0L, 1);
DEFINE_STATIC_PROCEDURE(node_copy__default1460_env_61_reduce_copy, _node_copy__default1460_196_reduce_copy1727, _node_copy__default1460_196_reduce_copy, 0L, 1);
DEFINE_STATIC_GENERIC(node_copy__env_176_reduce_copy, _node_copy_1716_45_reduce_copy1728, _node_copy_1716_45_reduce_copy, 0L, 1);
DEFINE_STRING(string1719_reduce_copy, string1719_reduce_copy1729, "No method for this object", 25);
DEFINE_STRING(string1720_reduce_copy, string1720_reduce_copy1730, "NODE-COPY!-DEFAULT1460 READ DONE ", 33);
DEFINE_STRING(string1718_reduce_copy, string1718_reduce_copy1731, "(removed : ", 11);
DEFINE_STRING(string1717_reduce_copy, string1717_reduce_copy1732, "      copy propagation       ", 29);


/* module-initialization */ obj_t 
module_initialization_70_reduce_copy(long checksum_1400, char *from_1401)
{
   if (CBOOL(require_initialization_114_reduce_copy))
     {
	require_initialization_114_reduce_copy = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_copy();
	cnst_init_137_reduce_copy();
	imported_modules_init_94_reduce_copy();
	method_init_76_reduce_copy();
	toplevel_init_63_reduce_copy();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_copy()
{
   module_initialization_70___object(((long) 0), "REDUCE_COPY");
   module_initialization_70___reader(((long) 0), "REDUCE_COPY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_copy()
{
   {
      obj_t cnst_port_138_1392;
      cnst_port_138_1392 = open_input_string(string1720_reduce_copy);
      {
	 long i_1393;
	 i_1393 = ((long) 2);
       loop_1394:
	 {
	    bool_t test1721_1395;
	    test1721_1395 = (i_1393 == ((long) -1));
	    if (test1721_1395)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1722_1396;
		    {
		       obj_t list1723_1397;
		       {
			  obj_t arg1724_1398;
			  arg1724_1398 = BNIL;
			  list1723_1397 = MAKE_PAIR(cnst_port_138_1392, arg1724_1398);
		       }
		       arg1722_1396 = read___reader(list1723_1397);
		    }
		    CNST_TABLE_SET(i_1393, arg1722_1396);
		 }
		 {
		    int aux_1399;
		    {
		       long aux_1418;
		       aux_1418 = (i_1393 - ((long) 1));
		       aux_1399 = (int) (aux_1418);
		    }
		    {
		       long i_1421;
		       i_1421 = (long) (aux_1399);
		       i_1393 = i_1421;
		       goto loop_1394;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_reduce_copy()
{
   _copy_removed__156_reduce_copy = ((long) 0);
   return BUNSPEC;
}


/* reduce-copy! */ obj_t 
reduce_copy__103_reduce_copy(obj_t globals_1)
{
   {
      obj_t list1484_717;
      list1484_717 = MAKE_PAIR(string1717_reduce_copy, BNIL);
      verbose_tools_speek(BINT(((long) 2)), list1484_717);
   }
   _copy_removed__156_reduce_copy = ((long) 0);
   {
      obj_t l1435_720;
      l1435_720 = globals_1;
    lname1436_721:
      if (PAIRP(l1435_720))
	{
	   {
	      value_t fun_724;
	      {
		 global_t obj_1222;
		 {
		    obj_t aux_1428;
		    aux_1428 = CAR(l1435_720);
		    obj_1222 = (global_t) (aux_1428);
		 }
		 fun_724 = (((global_t) CREF(obj_1222))->value);
	      }
	      {
		 {
		    node_t arg1488_726;
		    {
		       node_t aux_1432;
		       {
			  obj_t aux_1433;
			  {
			     sfun_t obj_1223;
			     obj_1223 = (sfun_t) (fun_724);
			     aux_1433 = (((sfun_t) CREF(obj_1223))->body);
			  }
			  aux_1432 = (node_t) (aux_1433);
		       }
		       arg1488_726 = node_copy__175_reduce_copy(aux_1432);
		    }
		    {
		       sfun_t obj_1224;
		       obj_t val1135_1225;
		       obj_1224 = (sfun_t) (fun_724);
		       val1135_1225 = (obj_t) (arg1488_726);
		       ((((sfun_t) CREF(obj_1224))->body) = ((obj_t) val1135_1225), BUNSPEC);
		    }
		 }
		 BUNSPEC;
	      }
	   }
	   {
	      obj_t l1435_1441;
	      l1435_1441 = CDR(l1435_720);
	      l1435_720 = l1435_1441;
	      goto lname1436_721;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t list1490_728;
      {
	 obj_t arg1494_730;
	 {
	    obj_t arg1496_731;
	    {
	       obj_t arg1497_732;
	       {
		  obj_t aux_1443;
		  aux_1443 = BCHAR(((unsigned char) '\n'));
		  arg1497_732 = MAKE_PAIR(aux_1443, BNIL);
	       }
	       {
		  obj_t aux_1446;
		  aux_1446 = BCHAR(((unsigned char) ')'));
		  arg1496_731 = MAKE_PAIR(aux_1446, arg1497_732);
	       }
	    }
	    {
	       obj_t aux_1449;
	       aux_1449 = BINT(_copy_removed__156_reduce_copy);
	       arg1494_730 = MAKE_PAIR(aux_1449, arg1496_731);
	    }
	 }
	 list1490_728 = MAKE_PAIR(string1718_reduce_copy, arg1494_730);
      }
      verbose_tools_speek(BINT(((long) 2)), list1490_728);
   }
   return globals_1;
}


/* _reduce-copy! */ obj_t 
_reduce_copy__94_reduce_copy(obj_t env_1386, obj_t globals_1387)
{
   return reduce_copy__103_reduce_copy(globals_1387);
}


/* node-copy*! */ obj_t 
node_copy___108_reduce_copy(obj_t node__221_25)
{
   {
      obj_t node__221_734;
      node__221_734 = node__221_25;
    loop_735:
      if (NULLP(node__221_734))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   {
	      node_t arg1500_737;
	      {
		 node_t aux_1459;
		 {
		    obj_t aux_1460;
		    aux_1460 = CAR(node__221_734);
		    aux_1459 = (node_t) (aux_1460);
		 }
		 arg1500_737 = node_copy__175_reduce_copy(aux_1459);
	      }
	      {
		 obj_t aux_1464;
		 aux_1464 = (obj_t) (arg1500_737);
		 SET_CAR(node__221_734, aux_1464);
	      }
	   }
	   {
	      obj_t node__221_1467;
	      node__221_1467 = CDR(node__221_734);
	      node__221_734 = node__221_1467;
	      goto loop_735;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_reduce_copy()
{
   add_generic__110___object(node_copy__env_176_reduce_copy, node_copy__default1460_env_61_reduce_copy);
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, select_ast_node, ((long) 12));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, box_set__221_ast_node, ((long) 18));
   add_inlined_method__244___object(node_copy__env_176_reduce_copy, box_ref_242_ast_node, ((long) 19));
   {
      long aux_1490;
      aux_1490 = add_inlined_method__244___object(node_copy__env_176_reduce_copy, app_ast_node, ((long) 20));
      return BINT(aux_1490);
   }
}


/* node-copy! */ node_t 
node_copy__175_reduce_copy(node_t node_2)
{
   {
      obj_t method1601_1071;
      obj_t class1606_1072;
      {
	 obj_t arg1609_1069;
	 obj_t arg1610_1070;
	 {
	    object_t obj_1232;
	    obj_1232 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1233;
	       pre_method_105_1233 = PROCEDURE_REF(node_copy__env_176_reduce_copy, ((long) 2));
	       if (INTEGERP(pre_method_105_1233))
		 {
		    PROCEDURE_SET(node_copy__env_176_reduce_copy, ((long) 2), BUNSPEC);
		    arg1609_1069 = pre_method_105_1233;
		 }
	       else
		 {
		    long obj_class_num_177_1238;
		    obj_class_num_177_1238 = TYPE(obj_1232);
		    {
		       obj_t arg1177_1239;
		       arg1177_1239 = PROCEDURE_REF(node_copy__env_176_reduce_copy, ((long) 1));
		       {
			  long arg1178_1243;
			  {
			     long arg1179_1244;
			     arg1179_1244 = OBJECT_TYPE;
			     arg1178_1243 = (obj_class_num_177_1238 - arg1179_1244);
			  }
			  arg1609_1069 = VECTOR_REF(arg1177_1239, arg1178_1243);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1249;
	    object_1249 = (object_t) (node_2);
	    {
	       long arg1180_1250;
	       {
		  long arg1181_1251;
		  long arg1182_1252;
		  arg1181_1251 = TYPE(object_1249);
		  arg1182_1252 = OBJECT_TYPE;
		  arg1180_1250 = (arg1181_1251 - arg1182_1252);
	       }
	       {
		  obj_t vector_1256;
		  vector_1256 = _classes__134___object;
		  arg1610_1070 = VECTOR_REF(vector_1256, arg1180_1250);
	       }
	    }
	 }
	 {
	    obj_t aux_1508;
	    method1601_1071 = arg1609_1069;
	    class1606_1072 = arg1610_1070;
	    {
	       if (INTEGERP(method1601_1071))
		 {
		    switch ((long) CINT(method1601_1071))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_1511;
			    aux_1511 = (atom_t) (node_2);
			    aux_1508 = (obj_t) (aux_1511);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_1514;
			    aux_1514 = (kwote_t) (node_2);
			    aux_1508 = (obj_t) (aux_1514);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t node_1080;
			    node_1080 = (var_t) (node_2);
			    {
			       variable_t v_1081;
			       v_1081 = (((var_t) CREF(node_1080))->variable);
			       {
				  obj_t falpha_1082;
				  falpha_1082 = (((variable_t) CREF(v_1081))->fast_alpha_7);
				  if ((falpha_1082 == BUNSPEC))
				    {
				       aux_1508 = (obj_t) (node_1080);
				    }
				  else
				    {
				       node_t aux_1523;
				       aux_1523 = node_copy__175_reduce_copy((node_t) (falpha_1082));
				       aux_1508 = (obj_t) (aux_1523);
				    }
			       }
			    }
			 }
			 break;
		      case ((long) 3):
			 {
			    closure_t aux_1527;
			    aux_1527 = (closure_t) (node_2);
			    aux_1508 = (obj_t) (aux_1527);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1085;
			    node_1085 = (sequence_t) (node_2);
			    node_copy___108_reduce_copy((((sequence_t) CREF(node_1085))->nodes));
			    aux_1508 = (obj_t) (node_1085);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1088;
			    node_1088 = (app_ly_162_t) (node_2);
			    {
			       node_t arg1617_1090;
			       arg1617_1090 = node_copy__175_reduce_copy((((app_ly_162_t) CREF(node_1088))->fun));
			       ((((app_ly_162_t) CREF(node_1088))->fun) = ((node_t) arg1617_1090), BUNSPEC);
			    }
			    {
			       node_t arg1620_1092;
			       arg1620_1092 = node_copy__175_reduce_copy((((app_ly_162_t) CREF(node_1088))->arg));
			       ((((app_ly_162_t) CREF(node_1088))->arg) = ((node_t) arg1620_1092), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1088);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1094;
			    node_1094 = (funcall_t) (node_2);
			    {
			       node_t arg1622_1096;
			       arg1622_1096 = node_copy__175_reduce_copy((((funcall_t) CREF(node_1094))->fun));
			       ((((funcall_t) CREF(node_1094))->fun) = ((node_t) arg1622_1096), BUNSPEC);
			    }
			    node_copy___108_reduce_copy((((funcall_t) CREF(node_1094))->args));
			    aux_1508 = (obj_t) (node_1094);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1099;
			    node_1099 = (pragma_t) (node_2);
			    node_copy___108_reduce_copy((((pragma_t) CREF(node_1099))->args));
			    aux_1508 = (obj_t) (node_1099);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1102;
			    node_1102 = (cast_t) (node_2);
			    {
			       node_t arg1627_1104;
			       arg1627_1104 = node_copy__175_reduce_copy((((cast_t) CREF(node_1102))->arg));
			       ((((cast_t) CREF(node_1102))->arg) = ((node_t) arg1627_1104), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1102);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1106;
			    node_1106 = (setq_t) (node_2);
			    {
			       node_t arg1630_1108;
			       arg1630_1108 = node_copy__175_reduce_copy((((setq_t) CREF(node_1106))->value));
			       ((((setq_t) CREF(node_1106))->value) = ((node_t) arg1630_1108), BUNSPEC);
			    }
			    {
			       node_t arg1633_1110;
			       {
				  node_t aux_1562;
				  {
				     var_t aux_1563;
				     aux_1563 = (((setq_t) CREF(node_1106))->var);
				     aux_1562 = (node_t) (aux_1563);
				  }
				  arg1633_1110 = node_copy__175_reduce_copy(aux_1562);
			       }
			       {
				  var_t val1306_1282;
				  val1306_1282 = (var_t) (arg1633_1110);
				  ((((setq_t) CREF(node_1106))->var) = ((var_t) val1306_1282), BUNSPEC);
			       }
			    }
			    aux_1508 = (obj_t) (node_1106);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1112;
			    node_1112 = (conditional_t) (node_2);
			    {
			       node_t arg1636_1114;
			       arg1636_1114 = node_copy__175_reduce_copy((((conditional_t) CREF(node_1112))->test));
			       ((((conditional_t) CREF(node_1112))->test) = ((node_t) arg1636_1114), BUNSPEC);
			    }
			    {
			       node_t arg1639_1116;
			       arg1639_1116 = node_copy__175_reduce_copy((((conditional_t) CREF(node_1112))->true));
			       ((((conditional_t) CREF(node_1112))->true) = ((node_t) arg1639_1116), BUNSPEC);
			    }
			    {
			       node_t arg1641_1118;
			       arg1641_1118 = node_copy__175_reduce_copy((((conditional_t) CREF(node_1112))->false));
			       ((((conditional_t) CREF(node_1112))->false) = ((node_t) arg1641_1118), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1112);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1120;
			    node_1120 = (fail_t) (node_2);
			    {
			       node_t arg1646_1122;
			       arg1646_1122 = node_copy__175_reduce_copy((((fail_t) CREF(node_1120))->proc));
			       ((((fail_t) CREF(node_1120))->proc) = ((node_t) arg1646_1122), BUNSPEC);
			    }
			    {
			       node_t arg1648_1124;
			       arg1648_1124 = node_copy__175_reduce_copy((((fail_t) CREF(node_1120))->msg));
			       ((((fail_t) CREF(node_1120))->msg) = ((node_t) arg1648_1124), BUNSPEC);
			    }
			    {
			       node_t arg1650_1126;
			       arg1650_1126 = node_copy__175_reduce_copy((((fail_t) CREF(node_1120))->obj));
			       ((((fail_t) CREF(node_1120))->obj) = ((node_t) arg1650_1126), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1120);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1128;
			    node_1128 = (select_t) (node_2);
			    {
			       node_t arg1653_1130;
			       arg1653_1130 = node_copy__175_reduce_copy((((select_t) CREF(node_1128))->test));
			       ((((select_t) CREF(node_1128))->test) = ((node_t) arg1653_1130), BUNSPEC);
			    }
			    {
			       obj_t l1446_1132;
			       l1446_1132 = (((select_t) CREF(node_1128))->clauses);
			     lname1447_1133:
			       if (PAIRP(l1446_1132))
				 {
				    {
				       obj_t clause_1136;
				       clause_1136 = CAR(l1446_1132);
				       {
					  node_t arg1657_1137;
					  {
					     node_t aux_1599;
					     {
						obj_t aux_1600;
						aux_1600 = CDR(clause_1136);
						aux_1599 = (node_t) (aux_1600);
					     }
					     arg1657_1137 = node_copy__175_reduce_copy(aux_1599);
					  }
					  {
					     obj_t aux_1604;
					     aux_1604 = (obj_t) (arg1657_1137);
					     SET_CDR(clause_1136, aux_1604);
					  }
				       }
				    }
				    {
				       obj_t l1446_1607;
				       l1446_1607 = CDR(l1446_1132);
				       l1446_1132 = l1446_1607;
				       goto lname1447_1133;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1508 = (obj_t) (node_1128);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1140;
			    node_1140 = (let_fun_218_t) (node_2);
			    {
			       obj_t l1449_1142;
			       l1449_1142 = (((let_fun_218_t) CREF(node_1140))->locals);
			     lname1450_1143:
			       if (PAIRP(l1449_1142))
				 {
				    {
				       value_t fun_1147;
				       {
					  local_t obj_1314;
					  {
					     obj_t aux_1614;
					     aux_1614 = CAR(l1449_1142);
					     obj_1314 = (local_t) (aux_1614);
					  }
					  fun_1147 = (((local_t) CREF(obj_1314))->value);
				       }
				       {
					  node_t arg1663_1148;
					  {
					     node_t aux_1618;
					     {
						obj_t aux_1619;
						{
						   sfun_t obj_1315;
						   obj_1315 = (sfun_t) (fun_1147);
						   aux_1619 = (((sfun_t) CREF(obj_1315))->body);
						}
						aux_1618 = (node_t) (aux_1619);
					     }
					     arg1663_1148 = node_copy__175_reduce_copy(aux_1618);
					  }
					  {
					     sfun_t obj_1316;
					     obj_t val1135_1317;
					     obj_1316 = (sfun_t) (fun_1147);
					     val1135_1317 = (obj_t) (arg1663_1148);
					     ((((sfun_t) CREF(obj_1316))->body) = ((obj_t) val1135_1317), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l1449_1627;
				       l1449_1627 = CDR(l1449_1142);
				       l1449_1142 = l1449_1627;
				       goto lname1450_1143;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1667_1151;
			       arg1667_1151 = node_copy__175_reduce_copy((((let_fun_218_t) CREF(node_1140))->body));
			       ((((let_fun_218_t) CREF(node_1140))->body) = ((node_t) arg1667_1151), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1140);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1153;
			    node_1153 = (let_var_6_t) (node_2);
			    {
			       obj_t obindings_1155;
			       obj_t nbindings_1156;
			       obindings_1155 = (((let_var_6_t) CREF(node_1153))->bindings);
			       nbindings_1156 = BNIL;
			     loop_1157:
			       if (NULLP(obindings_1155))
				 {
				    bool_t test_1637;
				    if (NULLP(nbindings_1156))
				      {
					 test_1637 = (((let_var_6_t) CREF(node_1153))->removable__42);
				      }
				    else
				      {
					 test_1637 = ((bool_t) 0);
				      }
				    if (test_1637)
				      {
					 node_t aux_1641;
					 aux_1641 = node_copy__175_reduce_copy((((let_var_6_t) CREF(node_1153))->body));
					 aux_1508 = (obj_t) (aux_1641);
				      }
				    else
				      {
					 ((((let_var_6_t) CREF(node_1153))->bindings) = ((obj_t) nbindings_1156), BUNSPEC);
					 {
					    node_t arg1675_1163;
					    arg1675_1163 = node_copy__175_reduce_copy((((let_var_6_t) CREF(node_1153))->body));
					    ((((let_var_6_t) CREF(node_1153))->body) = ((node_t) arg1675_1163), BUNSPEC);
					 }
					 aux_1508 = (obj_t) (node_1153);
				      }
				 }
			       else
				 {
				    obj_t binding_1166;
				    binding_1166 = CAR(obindings_1155);
				    {
				       obj_t var_1167;
				       var_1167 = CAR(binding_1166);
				       {
					  node_t val_1168;
					  {
					     node_t aux_1652;
					     {
						obj_t aux_1653;
						aux_1653 = CDR(binding_1166);
						aux_1652 = (node_t) (aux_1653);
					     }
					     val_1168 = node_copy__175_reduce_copy(aux_1652);
					  }
					  {
					     {
						obj_t aux_1657;
						aux_1657 = (obj_t) (val_1168);
						SET_CDR(binding_1166, aux_1657);
					     }
					     {
						bool_t test1678_1169;
						{
						   bool_t test1682_1173;
						   {
						      bool_t test1685_1176;
						      test1685_1176 = is_a__118___object((obj_t) (val_1168), atom_ast_node);
						      if (test1685_1176)
							{
							   test1682_1173 = ((bool_t) 1);
							}
						      else
							{
							   bool_t _andtest_1452_1177;
							   _andtest_1452_1177 = is_a__118___object((obj_t) (val_1168), var_ast_node);
							   if (_andtest_1452_1177)
							     {
								obj_t aux_1670;
								obj_t aux_1666;
								aux_1670 = CNST_TABLE_REF(((long) 1));
								{
								   variable_t arg1689_1180;
								   {
								      var_t obj_1339;
								      obj_1339 = (var_t) (val_1168);
								      arg1689_1180 = (((var_t) CREF(obj_1339))->variable);
								   }
								   aux_1666 = (((variable_t) CREF(arg1689_1180))->access);
								}
								test1682_1173 = (aux_1666 == aux_1670);
							     }
							   else
							     {
								test1682_1173 = ((bool_t) 0);
							     }
							}
						   }
						   if (test1682_1173)
						     {
							obj_t aux_1677;
							obj_t aux_1674;
							aux_1677 = CNST_TABLE_REF(((long) 1));
							{
							   variable_t obj_1343;
							   obj_1343 = (variable_t) (var_1167);
							   aux_1674 = (((variable_t) CREF(obj_1343))->access);
							}
							test1678_1169 = (aux_1674 == aux_1677);
						     }
						   else
						     {
							test1678_1169 = ((bool_t) 0);
						     }
						}
						if (test1678_1169)
						  {
						     {
							long z1_1346;
							z1_1346 = _copy_removed__156_reduce_copy;
							_copy_removed__156_reduce_copy = (z1_1346 + ((long) 1));
						     }
						     {
							variable_t obj_1348;
							obj_t val1045_1349;
							obj_1348 = (variable_t) (var_1167);
							val1045_1349 = (obj_t) (val_1168);
							((((variable_t) CREF(obj_1348))->fast_alpha_7) = ((obj_t) val1045_1349), BUNSPEC);
						     }
						     {
							obj_t obindings_1685;
							obindings_1685 = CDR(obindings_1155);
							obindings_1155 = obindings_1685;
							goto loop_1157;
						     }
						  }
						else
						  {
						     obj_t arg1680_1171;
						     obj_t arg1681_1172;
						     arg1680_1171 = CDR(obindings_1155);
						     arg1681_1172 = MAKE_PAIR(binding_1166, nbindings_1156);
						     {
							obj_t nbindings_1690;
							obj_t obindings_1689;
							obindings_1689 = arg1680_1171;
							nbindings_1690 = arg1681_1172;
							nbindings_1156 = nbindings_1690;
							obindings_1155 = obindings_1689;
							goto loop_1157;
						     }
						  }
					     }
					  }
				       }
				    }
				 }
			    }
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1182;
			    node_1182 = (set_ex_it_116_t) (node_2);
			    {
			       node_t arg1692_1184;
			       arg1692_1184 = node_copy__175_reduce_copy((((set_ex_it_116_t) CREF(node_1182))->body));
			       ((((set_ex_it_116_t) CREF(node_1182))->body) = ((node_t) arg1692_1184), BUNSPEC);
			    }
			    {
			       node_t arg1694_1186;
			       {
				  node_t aux_1696;
				  {
				     var_t aux_1697;
				     aux_1697 = (((set_ex_it_116_t) CREF(node_1182))->var);
				     aux_1696 = (node_t) (aux_1697);
				  }
				  arg1694_1186 = node_copy__175_reduce_copy(aux_1696);
			       }
			       {
				  var_t val1388_1359;
				  val1388_1359 = (var_t) (arg1694_1186);
				  ((((set_ex_it_116_t) CREF(node_1182))->var) = ((var_t) val1388_1359), BUNSPEC);
			       }
			    }
			    aux_1508 = (obj_t) (node_1182);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1188;
			    node_1188 = (jump_ex_it_184_t) (node_2);
			    {
			       node_t arg1697_1190;
			       arg1697_1190 = node_copy__175_reduce_copy((((jump_ex_it_184_t) CREF(node_1188))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1188))->exit) = ((node_t) arg1697_1190), BUNSPEC);
			    }
			    {
			       node_t arg1699_1192;
			       arg1699_1192 = node_copy__175_reduce_copy((((jump_ex_it_184_t) CREF(node_1188))->value));
			       ((((jump_ex_it_184_t) CREF(node_1188))->value) = ((node_t) arg1699_1192), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1188);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1194;
			    node_1194 = (make_box_202_t) (node_2);
			    {
			       node_t arg1701_1196;
			       arg1701_1196 = node_copy__175_reduce_copy((((make_box_202_t) CREF(node_1194))->value));
			       ((((make_box_202_t) CREF(node_1194))->value) = ((node_t) arg1701_1196), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1194);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_set__221_t node_1198;
			    node_1198 = (box_set__221_t) (node_2);
			    {
			       node_t arg1703_1200;
			       {
				  node_t aux_1718;
				  {
				     var_t aux_1719;
				     aux_1719 = (((box_set__221_t) CREF(node_1198))->var);
				     aux_1718 = (node_t) (aux_1719);
				  }
				  arg1703_1200 = node_copy__175_reduce_copy(aux_1718);
			       }
			       {
				  var_t val1432_1371;
				  val1432_1371 = (var_t) (arg1703_1200);
				  ((((box_set__221_t) CREF(node_1198))->var) = ((var_t) val1432_1371), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1705_1202;
			       arg1705_1202 = node_copy__175_reduce_copy((((box_set__221_t) CREF(node_1198))->value));
			       ((((box_set__221_t) CREF(node_1198))->value) = ((node_t) arg1705_1202), BUNSPEC);
			    }
			    aux_1508 = (obj_t) (node_1198);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_ref_242_t node_1204;
			    node_1204 = (box_ref_242_t) (node_2);
			    {
			       node_t arg1707_1206;
			       {
				  node_t aux_1730;
				  {
				     var_t aux_1731;
				     aux_1731 = (((box_ref_242_t) CREF(node_1204))->var);
				     aux_1730 = (node_t) (aux_1731);
				  }
				  arg1707_1206 = node_copy__175_reduce_copy(aux_1730);
			       }
			       {
				  var_t val1423_1377;
				  val1423_1377 = (var_t) (arg1707_1206);
				  ((((box_ref_242_t) CREF(node_1204))->var) = ((var_t) val1423_1377), BUNSPEC);
			       }
			    }
			    aux_1508 = (obj_t) (node_1204);
			 }
			 break;
		      case ((long) 20):
			 {
			    app_t node_1208;
			    node_1208 = (app_t) (node_2);
			    node_copy___108_reduce_copy((((app_t) CREF(node_1208))->args));
			    aux_1508 = (obj_t) (node_1208);
			 }
			 break;
		      default:
		       case_else1607_1075:
			 if (PROCEDUREP(method1601_1071))
			   {
			      aux_1508 = PROCEDURE_ENTRY(method1601_1071) (method1601_1071, (obj_t) (node_2), BEOA);
			   }
			 else
			   {
			      obj_t fun1595_1065;
			      fun1595_1065 = PROCEDURE_REF(node_copy__env_176_reduce_copy, ((long) 0));
			      aux_1508 = PROCEDURE_ENTRY(fun1595_1065) (fun1595_1065, (obj_t) (node_2), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1607_1075;
		 }
	    }
	    return (node_t) (aux_1508);
	 }
      }
   }
}


/* _node-copy!1716 */ obj_t 
_node_copy_1716_45_reduce_copy(obj_t env_1388, obj_t node_1389)
{
   {
      node_t aux_1754;
      aux_1754 = node_copy__175_reduce_copy((node_t) (node_1389));
      return (obj_t) (aux_1754);
   }
}


/* node-copy!-default1460 */ node_t 
node_copy__default1460_47_reduce_copy(node_t node_3)
{
   FAILURE(CNST_TABLE_REF(((long) 2)), string1719_reduce_copy, (obj_t) (node_3));
}


/* _node-copy!-default1460 */ obj_t 
_node_copy__default1460_196_reduce_copy(obj_t env_1390, obj_t node_1391)
{
   {
      node_t aux_1761;
      aux_1761 = node_copy__default1460_47_reduce_copy((node_t) (node_1391));
      return (obj_t) (aux_1761);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_copy()
{
   module_initialization_70_tools_trace(((long) 0), "REDUCE_COPY");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_COPY");
   module_initialization_70_tools_speek(((long) 0), "REDUCE_COPY");
   module_initialization_70_tools_error(((long) 0), "REDUCE_COPY");
   module_initialization_70_type_type(((long) 0), "REDUCE_COPY");
   module_initialization_70_type_cache(((long) 0), "REDUCE_COPY");
   module_initialization_70_coerce_typeof(((long) 0), "REDUCE_COPY");
   module_initialization_70_coerce_coerce(((long) 0), "REDUCE_COPY");
   module_initialization_70_effect_effect(((long) 0), "REDUCE_COPY");
   module_initialization_70_ast_var(((long) 0), "REDUCE_COPY");
   module_initialization_70_ast_node(((long) 0), "REDUCE_COPY");
   return module_initialization_70_ast_lvtype(((long) 0), "REDUCE_COPY");
}
