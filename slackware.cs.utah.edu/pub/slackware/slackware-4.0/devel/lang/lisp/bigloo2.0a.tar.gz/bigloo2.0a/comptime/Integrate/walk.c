/*===========================================================================*/
/*   (Integrate/walk.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


static obj_t method_init_76_integrate_walk();
extern obj_t current_error_port;
extern obj_t _nb_error_on_pass__70_tools_error;
extern obj_t integrate_definition__136_integrate_definition(obj_t);
extern obj_t integrate_walk__134_integrate_walk(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern obj_t module_initialization_70_integrate_walk(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_engine_pass(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_remove(long, char *);
extern obj_t module_initialization_70_integrate_definition(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
static obj_t _integrate_walk__13_integrate_walk(obj_t, obj_t);
static obj_t imported_modules_init_94_integrate_walk();
extern obj_t fprint___r4_output_6_10_3(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_integrate_walk();
extern obj_t open_input_string(obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t enter_function_81_tools_error(obj_t);
extern obj_t remove_var_123_ast_remove(obj_t, obj_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_integrate_walk = BUNSPEC;
static obj_t cnst_init_137_integrate_walk();
extern obj_t _current_pass__25_engine_pass;
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(integrate_walk__env_199_integrate_walk, _integrate_walk__13_integrate_walk1287, _integrate_walk__13_integrate_walk, 0L, 1);
DEFINE_STRING(string1281_integrate_walk, string1281_integrate_walk1288, "(INTEGRATE CFA) PASS-STARTED ", 29);
DEFINE_STRING(string1279_integrate_walk, string1279_integrate_walk1289, " error", 6);
DEFINE_STRING(string1280_integrate_walk, string1280_integrate_walk1290, "failure during postlude hook", 28);
DEFINE_STRING(string1278_integrate_walk, string1278_integrate_walk1291, " occured, ending ...", 20);
DEFINE_STRING(string1277_integrate_walk, string1277_integrate_walk1292, "failure during prelude hook", 27);
DEFINE_STRING(string1276_integrate_walk, string1276_integrate_walk1293, "   . ", 5);
DEFINE_STRING(string1275_integrate_walk, string1275_integrate_walk1294, "Integration", 11);


/* module-initialization */ obj_t 
module_initialization_70_integrate_walk(long checksum_517, char *from_518)
{
   if (CBOOL(require_initialization_114_integrate_walk))
     {
	require_initialization_114_integrate_walk = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_walk();
	cnst_init_137_integrate_walk();
	imported_modules_init_94_integrate_walk();
	method_init_76_integrate_walk();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_walk()
{
   module_initialization_70___r4_output_6_10_3(((long) 0), "INTEGRATE_WALK");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INTEGRATE_WALK");
   module_initialization_70___r4_numbers_6_5(((long) 0), "INTEGRATE_WALK");
   module_initialization_70___reader(((long) 0), "INTEGRATE_WALK");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_walk()
{
   {
      obj_t cnst_port_138_509;
      cnst_port_138_509 = open_input_string(string1281_integrate_walk);
      {
	 long i_510;
	 i_510 = ((long) 1);
       loop_511:
	 {
	    bool_t test1282_512;
	    test1282_512 = (i_510 == ((long) -1));
	    if (test1282_512)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1283_513;
		    {
		       obj_t list1284_514;
		       {
			  obj_t arg1285_515;
			  arg1285_515 = BNIL;
			  list1284_514 = MAKE_PAIR(cnst_port_138_509, arg1285_515);
		       }
		       arg1283_513 = read___reader(list1284_514);
		    }
		    CNST_TABLE_SET(i_510, arg1283_513);
		 }
		 {
		    int aux_516;
		    {
		       long aux_536;
		       aux_536 = (i_510 - ((long) 1));
		       aux_516 = (int) (aux_536);
		    }
		    {
		       long i_539;
		       i_539 = (long) (aux_516);
		       i_510 = i_539;
		       goto loop_511;
		    }
		 }
	      }
	 }
      }
   }
}


/* integrate-walk! */ obj_t 
integrate_walk__134_integrate_walk(obj_t globals_1)
{
   {
      obj_t list1182_302;
      {
	 obj_t arg1188_304;
	 {
	    obj_t arg1191_306;
	    {
	       obj_t aux_541;
	       aux_541 = BCHAR(((unsigned char) '\n'));
	       arg1191_306 = MAKE_PAIR(aux_541, BNIL);
	    }
	    arg1188_304 = MAKE_PAIR(string1275_integrate_walk, arg1191_306);
	 }
	 list1182_302 = MAKE_PAIR(string1276_integrate_walk, arg1188_304);
      }
      verbose_tools_speek(BINT(((long) 1)), list1182_302);
   }
   _nb_error_on_pass__70_tools_error = BINT(((long) 0));
   _current_pass__25_engine_pass = string1275_integrate_walk;
   {
      obj_t hooks_308;
      obj_t hnames_309;
      hooks_308 = BNIL;
      hnames_309 = BNIL;
    loop_310:
      if (NULLP(hooks_308))
	{
	   CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1197_315;
	   {
	      obj_t fun1206_321;
	      fun1206_321 = CAR(hooks_308);
	      {
		 obj_t aux_553;
		 aux_553 = PROCEDURE_ENTRY(fun1206_321) (fun1206_321, BEOA);
		 test1197_315 = CBOOL(aux_553);
	      }
	   }
	   if (test1197_315)
	     {
		{
		   obj_t hnames_560;
		   obj_t hooks_558;
		   hooks_558 = CDR(hooks_308);
		   hnames_560 = CDR(hnames_309);
		   hnames_309 = hnames_560;
		   hooks_308 = hooks_558;
		   goto loop_310;
		}
	     }
	   else
	     {
		internal_error_43_tools_error(string1275_integrate_walk, string1277_integrate_walk, CAR(hnames_309));
	     }
	}
   }
   {
      obj_t old_322;
      obj_t new_323;
      old_322 = globals_1;
      new_323 = BNIL;
    loop_324:
      if (NULLP(old_322))
	{
	   obj_t value_327;
	   value_327 = remove_var_123_ast_remove(CNST_TABLE_REF(((long) 1)), new_323);
	   {
	      bool_t test1209_328;
	      {
		 long n1_493;
		 n1_493 = (long) CINT(_nb_error_on_pass__70_tools_error);
		 test1209_328 = (n1_493 > ((long) 0));
	      }
	      if (test1209_328)
		{
		   {
		      char *arg1213_331;
		      {
			 bool_t test1222_338;
			 {
			    bool_t test1223_339;
			    {
			       obj_t obj_495;
			       obj_495 = _nb_error_on_pass__70_tools_error;
			       test1223_339 = INTEGERP(obj_495);
			    }
			    if (test1223_339)
			      {
				 test1222_338 = _2__206___r4_numbers_6_5(_nb_error_on_pass__70_tools_error, BINT(((long) 1)));
			      }
			    else
			      {
				 test1222_338 = ((bool_t) 0);
			      }
			 }
			 if (test1222_338)
			   {
			      arg1213_331 = "s";
			   }
			 else
			   {
			      arg1213_331 = "";
			   }
		      }
		      {
			 obj_t list1215_333;
			 {
			    obj_t arg1216_334;
			    {
			       obj_t arg1219_335;
			       {
				  obj_t arg1220_336;
				  arg1220_336 = MAKE_PAIR(string1278_integrate_walk, BNIL);
				  {
				     obj_t aux_577;
				     aux_577 = string_to_bstring(arg1213_331);
				     arg1219_335 = MAKE_PAIR(aux_577, arg1220_336);
				  }
			       }
			       arg1216_334 = MAKE_PAIR(string1279_integrate_walk, arg1219_335);
			    }
			    list1215_333 = MAKE_PAIR(_nb_error_on_pass__70_tools_error, arg1216_334);
			 }
			 fprint___r4_output_6_10_3(current_error_port, list1215_333);
		      }
		   }
		   {
		      obj_t res1274_497;
		      exit(((long) -1));
		      res1274_497 = BINT(((long) -1));
		      return res1274_497;
		   }
		}
	      else
		{
		   obj_t hooks_340;
		   obj_t hnames_341;
		   hooks_340 = BNIL;
		   hnames_341 = BNIL;
		 loop_342:
		   if (NULLP(hooks_340))
		     {
			return value_327;
		     }
		   else
		     {
			bool_t test1228_347;
			{
			   obj_t fun1235_352;
			   fun1235_352 = CAR(hooks_340);
			   {
			      obj_t aux_588;
			      aux_588 = PROCEDURE_ENTRY(fun1235_352) (fun1235_352, BEOA);
			      test1228_347 = CBOOL(aux_588);
			   }
			}
			if (test1228_347)
			  {
			     {
				obj_t hnames_595;
				obj_t hooks_593;
				hooks_593 = CDR(hooks_340);
				hnames_595 = CDR(hnames_341);
				hnames_341 = hnames_595;
				hooks_340 = hooks_593;
				goto loop_342;
			     }
			  }
			else
			  {
			     return internal_error_43_tools_error(_current_pass__25_engine_pass, string1280_integrate_walk, CAR(hnames_341));
			  }
		     }
		}
	   }
	}
      else
	{
	   obj_t global_354;
	   global_354 = CAR(old_322);
	   {
	      obj_t aux_600;
	      {
		 global_t obj_505;
		 obj_505 = (global_t) (global_354);
		 aux_600 = (((global_t) CREF(obj_505))->id);
	      }
	      enter_function_81_tools_error(aux_600);
	   }
	   {
	      obj_t arg1240_356;
	      obj_t arg1241_357;
	      arg1240_356 = CDR(old_322);
	      {
		 obj_t arg1243_358;
		 arg1243_358 = integrate_definition__136_integrate_definition(global_354);
		 arg1241_357 = append_2_18___r4_pairs_and_lists_6_3(arg1243_358, new_323);
	      }
	      {
		 obj_t new_608;
		 obj_t old_607;
		 old_607 = arg1240_356;
		 new_608 = arg1241_357;
		 new_323 = new_608;
		 old_322 = old_607;
		 goto loop_324;
	      }
	   }
	}
   }
}


/* _integrate-walk! */ obj_t 
_integrate_walk__13_integrate_walk(obj_t env_507, obj_t globals_508)
{
   return integrate_walk__134_integrate_walk(globals_508);
}


/* method-init */ obj_t 
method_init_76_integrate_walk()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_walk()
{
   module_initialization_70_tools_speek(((long) 0), "INTEGRATE_WALK");
   module_initialization_70_tools_error(((long) 0), "INTEGRATE_WALK");
   module_initialization_70_engine_pass(((long) 0), "INTEGRATE_WALK");
   module_initialization_70_type_type(((long) 0), "INTEGRATE_WALK");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_WALK");
   module_initialization_70_ast_remove(((long) 0), "INTEGRATE_WALK");
   return module_initialization_70_integrate_definition(((long) 0), "INTEGRATE_WALK");
}
