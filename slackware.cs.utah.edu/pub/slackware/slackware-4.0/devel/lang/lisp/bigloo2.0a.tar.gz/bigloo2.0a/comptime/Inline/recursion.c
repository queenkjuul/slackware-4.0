/*===========================================================================*/
/*   (Inline/recursion.scm)                                                  */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;

typedef struct local_variant_63
  {
     bool_t variant;
  }
                *local_variant_63_t;


extern obj_t append___r4_pairs_and_lists_6_3(obj_t);
extern obj_t _inlining_reduce_kfactor__26_engine_param;
static obj_t method_init_76_inline_recursion();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t inline_sfun__229_inline_inline(variable_t, long, obj_t);
extern obj_t _optim_unroll_loop___80_engine_param;
extern node_t inline_app_recursive_121_inline_recursion(node_t, long, obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static let_fun_218_t plain_call_51_inline_recursion(variable_t, node_t, local_t, app_t, obj_t);
static obj_t find_recursive_calls__36_inline_recursion(obj_t, variable_t);
static obj_t find_recursive_calls_default1503_165_inline_recursion(node_t, variable_t);
extern obj_t box_ref_242_ast_node;
extern obj_t _res1__155___r5_control_features_6_4;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t global_ast_var;
extern obj_t pragma_ast_node;
static obj_t _is_recursive__21_inline_recursion(obj_t, obj_t);
extern local_t clone_local_230_ast_local(local_t, value_t);
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t current_function_76_tools_error();
extern obj_t module_initialization_70_inline_recursion(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_alphatize(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_simple(long, char *);
extern obj_t module_initialization_70_inline_variant(long, char *);
extern obj_t module_initialization_70_inline_loop(long, char *);
extern obj_t module_initialization_70_inline_app(long, char *);
extern obj_t module_initialization_70_reduce_cse(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r5_control_features_6_4(long, char *);
extern obj_t shrink_args__237_inline_variant(variable_t);
static obj_t inline_app_labels_34_inline_recursion(node_t, long, obj_t);
extern long list_length(obj_t);
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
extern obj_t let_fun_218_ast_node;
extern node_t inline_app_simple_198_inline_simple(node_t, long, obj_t, obj_t);
extern bool_t is_loop__232_inline_loop(variable_t);
static obj_t imported_modules_init_94_inline_recursion();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _find_recursive_calls_233_inline_recursion(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_inline_recursion();
extern obj_t variant_args_126_inline_variant(variable_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_inline_recursion();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern local_t make_local_sfun_184_ast_local(obj_t, type_t, sfun_t);
static obj_t unroll_call_164_inline_recursion(variable_t, node_t, local_t, obj_t, app_t, obj_t);
extern node_t alphatize_ast_alphatize(obj_t, obj_t, obj_t, node_t);
extern app_t remove_invariant_args__113_inline_variant(app_t);
extern obj_t sfun_ast_var;
extern bool_t inner_loop__79_inline_loop(variable_t);
extern obj_t setq_ast_node;
extern bool_t is_recursive__125_inline_recursion(variable_t);
extern obj_t box_set__221_ast_node;
extern obj_t invariant_args_254_inline_variant(variable_t, obj_t);
extern obj_t isfun_inline_inline;
extern obj_t node_cse__231_reduce_cse(node_t, obj_t);
static obj_t arg1639_inline_recursion(obj_t, obj_t);
extern obj_t local_ast_var;
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t substitutions_inline_variant(variable_t, obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t find_recursive_calls_52_inline_recursion(node_t, variable_t);
static obj_t _inline_app_recursive_184_inline_recursion(obj_t, obj_t, obj_t, obj_t);
extern bool_t inline_app__99_inline_app(variable_t, long, long, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t _find_recursive_calls_default1503_238_inline_recursion(obj_t, obj_t, obj_t);
static obj_t require_initialization_114_inline_recursion = BUNSPEC;
extern obj_t conditional_ast_node;
extern node_t nest_loop__92_inline_loop(node_t, local_t, obj_t);
static obj_t cnst_init_137_inline_recursion();
static obj_t __cnst[2];

DEFINE_STATIC_GENERIC(find_recursive_calls_env_59_inline_recursion, _find_recursive_calls_233_inline_recursion1904, _find_recursive_calls_233_inline_recursion, 0L, 2);
DEFINE_EXPORT_PROCEDURE(inline_app_recursive_env_100_inline_recursion, _inline_app_recursive_184_inline_recursion1905, _inline_app_recursive_184_inline_recursion, 0L, 3);
DEFINE_EXPORT_PROCEDURE(is_recursive__env_217_inline_recursion, _is_recursive__21_inline_recursion1906, _is_recursive__21_inline_recursion, 0L, 1);
DEFINE_STRING(string1898_inline_recursion, string1898_inline_recursion1907, "(SIFUN SGFUN) SFUN ", 19);
DEFINE_STRING(string1897_inline_recursion, string1897_inline_recursion1908, "unrolling", 9);
DEFINE_STRING(string1896_inline_recursion, string1896_inline_recursion1909, "         ", 9);
DEFINE_STRING(string1895_inline_recursion, string1895_inline_recursion1910, " --> ", 5);
DEFINE_STRING(string1894_inline_recursion, string1894_inline_recursion1911, " (recursive)", 12);
DEFINE_STRING(string1893_inline_recursion, string1893_inline_recursion1912, "simple", 6);
DEFINE_STATIC_PROCEDURE(find_recursive_calls_default1503_env_35_inline_recursion, _find_recursive_calls_default1503_238_inline_recursion1913, _find_recursive_calls_default1503_238_inline_recursion, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_inline_recursion(long checksum_1872, char *from_1873)
{
   if (CBOOL(require_initialization_114_inline_recursion))
     {
	require_initialization_114_inline_recursion = BBOOL(((bool_t) 0));
	library_modules_init_112_inline_recursion();
	cnst_init_137_inline_recursion();
	imported_modules_init_94_inline_recursion();
	method_init_76_inline_recursion();
	toplevel_init_63_inline_recursion();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_inline_recursion()
{
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INLINE_RECURSION");
   module_initialization_70___object(((long) 0), "INLINE_RECURSION");
   module_initialization_70___r5_control_features_6_4(((long) 0), "INLINE_RECURSION");
   module_initialization_70___reader(((long) 0), "INLINE_RECURSION");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_inline_recursion()
{
   {
      obj_t cnst_port_138_1864;
      cnst_port_138_1864 = open_input_string(string1898_inline_recursion);
      {
	 long i_1865;
	 i_1865 = ((long) 1);
       loop_1866:
	 {
	    bool_t test1899_1867;
	    test1899_1867 = (i_1865 == ((long) -1));
	    if (test1899_1867)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1900_1868;
		    {
		       obj_t list1901_1869;
		       {
			  obj_t arg1902_1870;
			  arg1902_1870 = BNIL;
			  list1901_1869 = MAKE_PAIR(cnst_port_138_1864, arg1902_1870);
		       }
		       arg1900_1868 = read___reader(list1901_1869);
		    }
		    CNST_TABLE_SET(i_1865, arg1900_1868);
		 }
		 {
		    int aux_1871;
		    {
		       long aux_1892;
		       aux_1892 = (i_1865 - ((long) 1));
		       aux_1871 = (int) (aux_1892);
		    }
		    {
		       long i_1895;
		       i_1895 = (long) (aux_1871);
		       i_1865 = i_1895;
		       goto loop_1866;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_inline_recursion()
{
   return BUNSPEC;
}


/* inline-app-recursive */ node_t 
inline_app_recursive_121_inline_recursion(node_t node_1, long kfactor_2, obj_t stack_3)
{
   {
      bool_t test_1897;
      {
	 obj_t aux_1898;
	 {
	    obj_t aux_1899;
	    {
	       variable_t aux_1900;
	       {
		  var_t arg1526_851;
		  {
		     app_t obj_1529;
		     obj_1529 = (app_t) (node_1);
		     arg1526_851 = (((app_t) CREF(obj_1529))->fun);
		  }
		  aux_1900 = (((var_t) CREF(arg1526_851))->variable);
	       }
	       aux_1899 = (obj_t) (aux_1900);
	    }
	    aux_1898 = memq___r4_pairs_and_lists_6_3(aux_1899, stack_3);
	 }
	 test_1897 = CBOOL(aux_1898);
      }
      if (test_1897)
	{
	   return inline_app_simple_198_inline_simple(node_1, kfactor_2, stack_3, string1893_inline_recursion);
	}
      else
	{
	   {
	      obj_t labels_node_100_850;
	      labels_node_100_850 = inline_app_labels_34_inline_recursion(node_1, kfactor_2, stack_3);
	      return (node_t) (labels_node_100_850);
	   }
	}
   }
}


/* _inline-app-recursive */ obj_t 
_inline_app_recursive_184_inline_recursion(obj_t env_1847, obj_t node_1848, obj_t kfactor_1849, obj_t stack_1850)
{
   {
      node_t aux_1910;
      aux_1910 = inline_app_recursive_121_inline_recursion((node_t) (node_1848), (long) CINT(kfactor_1849), stack_1850);
      return (obj_t) (aux_1910);
   }
}


/* inline-app-labels */ obj_t 
inline_app_labels_34_inline_recursion(node_t node_4, long kfactor_5, obj_t stack_6)
{
   {
      variable_t variable_852;
      {
	 var_t arg1620_971;
	 {
	    app_t obj_1531;
	    obj_1531 = (app_t) (node_4);
	    arg1620_971 = (((app_t) CREF(obj_1531))->fun);
	 }
	 variable_852 = (((var_t) CREF(arg1620_971))->variable);
      }
      {
	 long call_size_65_853;
	 {
	    long aux_1918;
	    {
	       obj_t aux_1919;
	       {
		  app_t obj_1533;
		  obj_1533 = (app_t) (node_4);
		  aux_1919 = (((app_t) CREF(obj_1533))->args);
	       }
	       aux_1918 = list_length(aux_1919);
	    }
	    call_size_65_853 = (((long) 1) + aux_1918);
	 }
	 {
	    local_t local_854;
	    {
	       sfun_t aux_1924;
	       {
		  value_t aux_1927;
		  aux_1927 = (((variable_t) CREF(variable_852))->value);
		  aux_1924 = (sfun_t) (aux_1927);
	       }
	       local_854 = make_local_sfun_184_ast_local((((variable_t) CREF(variable_852))->id), (((variable_t) CREF(variable_852))->type), aux_1924);
	    }
	    {
	       value_t old_sfun_249_855;
	       old_sfun_249_855 = (((variable_t) CREF(variable_852))->value);
	       {
		  obj_t rec_calls_225_856;
		  {
		     isfun_t obj_1540;
		     obj_1540 = (isfun_t) (old_sfun_249_855);
		     {
			obj_t aux_1933;
			{
			   object_t aux_1934;
			   aux_1934 = (object_t) (obj_1540);
			   aux_1933 = OBJECT_WIDENING(aux_1934);
			}
			rec_calls_225_856 = (((isfun_t) CREF(aux_1933))->recursive_calls_44);
		     }
		  }
		  {
		     obj_t old_args_130_857;
		     {
			sfun_t obj_1541;
			obj_1541 = (sfun_t) (old_sfun_249_855);
			old_args_130_857 = (((sfun_t) CREF(obj_1541))->args);
		     }
		     {
			obj_t inv_args_8_858;
			inv_args_8_858 = invariant_args_254_inline_variant(variable_852, rec_calls_225_856);
			{
			   obj_t var_args_195_859;
			   var_args_195_859 = variant_args_126_inline_variant(variable_852);
			   {
			      obj_t new_args_235_860;
			      if (NULLP(var_args_195_859))
				{
				   new_args_235_860 = BNIL;
				}
			      else
				{
				   obj_t head1473_949;
				   head1473_949 = MAKE_PAIR(BNIL, BNIL);
				   {
				      obj_t l1471_950;
				      obj_t tail1474_951;
				      l1471_950 = var_args_195_859;
				      tail1474_951 = head1473_949;
				    lname1472_952:
				      if (NULLP(l1471_950))
					{
					   new_args_235_860 = CDR(head1473_949);
					}
				      else
					{
					   obj_t newtail1475_954;
					   {
					      local_t arg1603_956;
					      {
						 obj_t l_958;
						 l_958 = CAR(l1471_950);
						 {
						    svar_t arg1606_959;
						    {
						       svar_t duplicated1476_960;
						       {
							  local_t obj_1548;
							  obj_1548 = (local_t) (l_958);
							  {
							     value_t aux_1950;
							     aux_1950 = (((local_t) CREF(obj_1548))->value);
							     duplicated1476_960 = (svar_t) (aux_1950);
							  }
						       }
						       {
							  svar_t new1477_961;
							  {
							     obj_t arg1607_962;
							     arg1607_962 = (((svar_t) CREF(duplicated1476_960))->loc);
							     {
								svar_t res1887_1556;
								{
								   svar_t new1160_1551;
								   new1160_1551 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
								   {
								      long arg1755_1552;
								      arg1755_1552 = class_num_218___object(svar_ast_var);
								      {
									 obj_t obj_1554;
									 obj_1554 = (obj_t) (new1160_1551);
									 (((obj_t) CREF(obj_1554))->header = MAKE_HEADER(arg1755_1552, 0), BUNSPEC);
								      }
								   }
								   {
								      object_t aux_1958;
								      aux_1958 = (object_t) (new1160_1551);
								      OBJECT_WIDENING_SET(aux_1958, BFALSE);
								   }
								   ((((svar_t) CREF(new1160_1551))->loc) = ((obj_t) arg1607_962), BUNSPEC);
								   res1887_1556 = new1160_1551;
								}
								new1477_961 = res1887_1556;
							     }
							  }
							  {
							     arg1606_959 = new1477_961;
							  }
						       }
						    }
						    arg1603_956 = clone_local_230_ast_local((local_t) (l_958), (value_t) (arg1606_959));
						 }
					      }
					      {
						 obj_t aux_1965;
						 aux_1965 = (obj_t) (arg1603_956);
						 newtail1475_954 = MAKE_PAIR(aux_1965, BNIL);
					      }
					   }
					   SET_CDR(tail1474_951, newtail1475_954);
					   {
					      obj_t tail1474_1971;
					      obj_t l1471_1969;
					      l1471_1969 = CDR(l1471_950);
					      tail1474_1971 = newtail1475_954;
					      tail1474_951 = tail1474_1971;
					      l1471_950 = l1471_1969;
					      goto lname1472_952;
					   }
					}
				   }
				}
			      {
				 obj_t substitute_861;
				 {
				    obj_t aux_1972;
				    {
				       app_t obj_1562;
				       obj_1562 = (app_t) (node_4);
				       aux_1972 = (((app_t) CREF(obj_1562))->args);
				    }
				    substitute_861 = substitutions_inline_variant(variable_852, aux_1972, new_args_235_860);
				 }
				 {
				    obj_t old_body_129_862;
				    {
				       bool_t test1595_945;
				       test1595_945 = is_a__118___object((obj_t) (old_sfun_249_855), isfun_inline_inline);
				       if (test1595_945)
					 {
					    isfun_t obj_1564;
					    obj_1564 = (isfun_t) (old_sfun_249_855);
					    {
					       node_t aux_1980;
					       {
						  obj_t aux_1981;
						  {
						     object_t aux_1982;
						     aux_1982 = (object_t) (obj_1564);
						     aux_1981 = OBJECT_WIDENING(aux_1982);
						  }
						  aux_1980 = (((isfun_t) CREF(aux_1981))->original_body_40);
					       }
					       old_body_129_862 = (obj_t) (aux_1980);
					    }
					 }
				       else
					 {
					    sfun_t obj_1565;
					    obj_1565 = (sfun_t) (old_sfun_249_855);
					    old_body_129_862 = (((sfun_t) CREF(obj_1565))->body);
					 }
				    }
				    {
				       obj_t svg_calls_args_120_863;
				       if (NULLP(rec_calls_225_856))
					 {
					    svg_calls_args_120_863 = BNIL;
					 }
				       else
					 {
					    obj_t head1480_933;
					    head1480_933 = MAKE_PAIR(BNIL, BNIL);
					    {
					       obj_t l1478_934;
					       obj_t tail1481_935;
					       l1478_934 = rec_calls_225_856;
					       tail1481_935 = head1480_933;
					     lname1479_936:
					       if (NULLP(l1478_934))
						 {
						    svg_calls_args_120_863 = CDR(head1480_933);
						 }
					       else
						 {
						    obj_t newtail1482_938;
						    {
						       obj_t aux_1995;
						       {
							  app_t obj_1572;
							  {
							     obj_t aux_1996;
							     aux_1996 = CAR(l1478_934);
							     obj_1572 = (app_t) (aux_1996);
							  }
							  aux_1995 = (((app_t) CREF(obj_1572))->args);
						       }
						       newtail1482_938 = MAKE_PAIR(aux_1995, BNIL);
						    }
						    SET_CDR(tail1481_935, newtail1482_938);
						    {
						       obj_t tail1481_2004;
						       obj_t l1478_2002;
						       l1478_2002 = CDR(l1478_934);
						       tail1481_2004 = newtail1482_938;
						       tail1481_935 = tail1481_2004;
						       l1478_934 = l1478_2002;
						       goto lname1479_936;
						    }
						 }
					    }
					 }
				       {
					  bool_t remove__21_864;
					  {
					     obj_t l1483_926;
					     l1483_926 = rec_calls_225_856;
					   lname1484_927:
					     if (PAIRP(l1483_926))
					       {
						  {
						     app_t aux_2007;
						     {
							obj_t aux_2008;
							aux_2008 = CAR(l1483_926);
							aux_2007 = (app_t) (aux_2008);
						     }
						     remove_invariant_args__113_inline_variant(aux_2007);
						  }
						  {
						     obj_t l1483_2012;
						     l1483_2012 = CDR(l1483_926);
						     l1483_926 = l1483_2012;
						     goto lname1484_927;
						  }
					       }
					     else
					       {
						  remove__21_864 = ((bool_t) 1);
					       }
					  }
					  {
					     node_t new_body_215_865;
					     {
						obj_t arg1580_923;
						obj_t arg1581_924;
						obj_t arg1582_925;
						{
						   obj_t aux_2014;
						   aux_2014 = (obj_t) (variable_852);
						   arg1580_923 = MAKE_PAIR(aux_2014, old_args_130_857);
						}
						{
						   obj_t aux_2017;
						   aux_2017 = (obj_t) (local_854);
						   arg1581_924 = MAKE_PAIR(aux_2017, substitute_861);
						}
						arg1582_925 = (((node_t) CREF(node_4))->loc);
						new_body_215_865 = alphatize_ast_alphatize(arg1580_923, arg1581_924, arg1582_925, (node_t) (old_body_129_862));
					     }
					     {
						bool_t restore__176_866;
						{
						   obj_t ll1485_915;
						   obj_t ll1486_916;
						   ll1485_915 = rec_calls_225_856;
						   ll1486_916 = svg_calls_args_120_863;
						 lname1487_917:
						   if (NULLP(ll1485_915))
						     {
							restore__176_866 = ((bool_t) 1);
						     }
						   else
						     {
							{
							   obj_t args_920;
							   args_920 = CAR(ll1486_916);
							   {
							      app_t obj_1589;
							      {
								 obj_t aux_2026;
								 aux_2026 = CAR(ll1485_915);
								 obj_1589 = (app_t) (aux_2026);
							      }
							      ((((app_t) CREF(obj_1589))->args) = ((obj_t) args_920), BUNSPEC);
							   }
							}
							{
							   obj_t ll1486_2032;
							   obj_t ll1485_2030;
							   ll1485_2030 = CDR(ll1485_915);
							   ll1486_2032 = CDR(ll1486_916);
							   ll1486_916 = ll1486_2032;
							   ll1485_915 = ll1485_2030;
							   goto lname1487_917;
							}
						     }
						}
						{
						   sfun_t new_sfun_134_867;
						   {
						      sfun_t duplicated1488_901;
						      duplicated1488_901 = (sfun_t) (old_sfun_249_855);
						      {
							 sfun_t new1489_902;
							 {
							    long arg1559_903;
							    obj_t arg1560_904;
							    obj_t arg1561_905;
							    obj_t arg1562_906;
							    bool_t arg1563_907;
							    obj_t arg1564_908;
							    obj_t arg1565_909;
							    obj_t arg1569_912;
							    obj_t arg1570_913;
							    obj_t arg1572_914;
							    arg1559_903 = (((sfun_t) CREF(duplicated1488_901))->arity);
							    arg1560_904 = (((sfun_t) CREF(duplicated1488_901))->side_effect__165);
							    arg1561_905 = (((sfun_t) CREF(duplicated1488_901))->predicate_of_78);
							    arg1562_906 = (((sfun_t) CREF(duplicated1488_901))->stack_allocator_172);
							    arg1563_907 = (((sfun_t) CREF(duplicated1488_901))->top__138);
							    arg1564_908 = (((sfun_t) CREF(duplicated1488_901))->the_closure_238);
							    arg1565_909 = (((sfun_t) CREF(duplicated1488_901))->property);
							    arg1569_912 = CNST_TABLE_REF(((long) 0));
							    arg1570_913 = (((sfun_t) CREF(duplicated1488_901))->dsssl_keywords_243);
							    arg1572_914 = (((sfun_t) CREF(duplicated1488_901))->loc);
							    {
							       sfun_t res1888_1630;
							       {
								  obj_t body_1610;
								  body_1610 = (obj_t) (new_body_215_865);
								  {
								     sfun_t new1116_1614;
								     new1116_1614 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
								     {
									long arg1761_1615;
									arg1761_1615 = class_num_218___object(sfun_ast_var);
									{
									   obj_t obj_1628;
									   obj_1628 = (obj_t) (new1116_1614);
									   (((obj_t) CREF(obj_1628))->header = MAKE_HEADER(arg1761_1615, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_2050;
									aux_2050 = (object_t) (new1116_1614);
									OBJECT_WIDENING_SET(aux_2050, BFALSE);
								     }
								     ((((sfun_t) CREF(new1116_1614))->arity) = ((long) arg1559_903), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->side_effect__165) = ((obj_t) arg1560_904), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->predicate_of_78) = ((obj_t) arg1561_905), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->stack_allocator_172) = ((obj_t) arg1562_906), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->top__138) = ((bool_t) arg1563_907), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->the_closure_238) = ((obj_t) arg1564_908), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->property) = ((obj_t) arg1565_909), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->args) = ((obj_t) new_args_235_860), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->body) = ((obj_t) body_1610), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->class) = ((obj_t) arg1569_912), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->dsssl_keywords_243) = ((obj_t) arg1570_913), BUNSPEC);
								     ((((sfun_t) CREF(new1116_1614))->loc) = ((obj_t) arg1572_914), BUNSPEC);
								     res1888_1630 = new1116_1614;
								  }
							       }
							       new1489_902 = res1888_1630;
							    }
							 }
							 {
							    new_sfun_134_867 = new1489_902;
							 }
						      }
						   }
						   {
						      obj_t new_kfactor_216_868;
						      new_kfactor_216_868 = PROCEDURE_ENTRY(_inlining_reduce_kfactor__26_engine_param) (_inlining_reduce_kfactor__26_engine_param, BINT(kfactor_5), BEOA);
						      {
							 {
							    obj_t ll1490_869;
							    obj_t ll1491_870;
							    ll1490_869 = new_args_235_860;
							    ll1491_870 = old_args_130_857;
							  lname1492_871:
							    if (NULLP(ll1490_869))
							      {
								 ((bool_t) 1);
							      }
							    else
							      {
								 {
								    bool_t arg1528_875;
								    {
								       local_t obj_1634;
								       {
									  obj_t aux_2070;
									  aux_2070 = CAR(ll1491_870);
									  obj_1634 = (local_t) (aux_2070);
								       }
								       arg1528_875 = (((local_t) CREF(obj_1634))->user__32);
								    }
								    {
								       local_t obj_1635;
								       {
									  obj_t aux_2074;
									  aux_2074 = CAR(ll1490_869);
									  obj_1635 = (local_t) (aux_2074);
								       }
								       ((((local_t) CREF(obj_1635))->user__32) = ((bool_t) arg1528_875), BUNSPEC);
								    }
								 }
								 {
								    obj_t ll1491_2080;
								    obj_t ll1490_2078;
								    ll1490_2078 = CDR(ll1490_869);
								    ll1491_2080 = CDR(ll1491_870);
								    ll1491_870 = ll1491_2080;
								    ll1490_869 = ll1490_2078;
								    goto lname1492_871;
								 }
							      }
							 }
							 {
							    bool_t arg1531_878;
							    {
							       bool_t test1532_879;
							       test1532_879 = is_a__118___object((obj_t) (variable_852), global_ast_var);
							       if (test1532_879)
								 {
								    {
								       global_t obj_1640;
								       obj_1640 = (global_t) (variable_852);
								       arg1531_878 = (((global_t) CREF(obj_1640))->user__32);
								    }
								 }
							       else
								 {
								    bool_t test1533_880;
								    test1533_880 = is_a__118___object((obj_t) (variable_852), local_ast_var);
								    if (test1533_880)
								      {
									 {
									    local_t obj_1642;
									    obj_1642 = (local_t) (variable_852);
									    arg1531_878 = (((local_t) CREF(obj_1642))->user__32);
									 }
								      }
								    else
								      {
									 arg1531_878 = ((bool_t) 0);
								      }
								 }
							    }
							    ((((local_t) CREF(local_854))->user__32) = ((bool_t) arg1531_878), BUNSPEC);
							 }
							 {
							    value_t val1095_1646;
							    val1095_1646 = (value_t) (new_sfun_134_867);
							    ((((local_t) CREF(local_854))->value) = ((value_t) val1095_1646), BUNSPEC);
							 }
							 {
							    bool_t test_2095;
							    {
							       obj_t aux_2096;
							       {
								  obj_t aux_2097;
								  {
								     sfun_t obj_1647;
								     obj_1647 = (sfun_t) (old_sfun_249_855);
								     aux_2097 = (((sfun_t) CREF(obj_1647))->class);
								  }
								  aux_2096 = memq___r4_pairs_and_lists_6_3(aux_2097, CNST_TABLE_REF(((long) 1)));
							       }
							       test_2095 = CBOOL(aux_2096);
							    }
							    if (test_2095)
							      {
								 BUNSPEC;
							      }
							    else
							      {
								 obj_t arg1537_884;
								 obj_t arg1540_886;
								 arg1537_884 = shape_tools_shape((obj_t) (variable_852));
								 arg1540_886 = current_function_76_tools_error();
								 {
								    obj_t list1543_888;
								    {
								       obj_t arg1545_889;
								       {
									  obj_t arg1548_890;
									  {
									     obj_t arg1549_891;
									     {
										obj_t arg1550_892;
										{
										   obj_t arg1552_893;
										   {
										      obj_t aux_2106;
										      aux_2106 = BCHAR(((unsigned char) '\n'));
										      arg1552_893 = MAKE_PAIR(aux_2106, BNIL);
										   }
										   arg1550_892 = MAKE_PAIR(string1894_inline_recursion, arg1552_893);
										}
										arg1549_891 = MAKE_PAIR(arg1540_886, arg1550_892);
									     }
									     arg1548_890 = MAKE_PAIR(string1895_inline_recursion, arg1549_891);
									  }
									  arg1545_889 = MAKE_PAIR(arg1537_884, arg1548_890);
								       }
								       list1543_888 = MAKE_PAIR(string1896_inline_recursion, arg1545_889);
								    }
								    verbose_tools_speek(BINT(((long) 3)), list1543_888);
								 }
							      }
							 }
							 inline_sfun__229_inline_inline((variable_t) (local_854), (long) CINT(new_kfactor_216_868), stack_6);
							 {
							    app_t new_call_202_897;
							    new_call_202_897 = remove_invariant_args__113_inline_variant((app_t) (node_4));
							    {
							       bool_t test1556_898;
							       if (CBOOL(_optim_unroll_loop___80_engine_param))
								 {
								    bool_t test1557_899;
								    test1557_899 = is_loop__232_inline_loop(variable_852);
								    if (test1557_899)
								      {
									 bool_t test1558_900;
									 test1558_900 = inner_loop__79_inline_loop(variable_852);
									 if (test1558_900)
									   {
									      test1556_898 = ((bool_t) 0);
									   }
									 else
									   {
									      test1556_898 = inline_app__99_inline_app((variable_t) (local_854), (long) CINT(new_kfactor_216_868), call_size_65_853, stack_6);
									   }
								      }
								    else
								      {
									 test1556_898 = ((bool_t) 0);
								      }
								 }
							       else
								 {
								    test1556_898 = ((bool_t) 0);
								 }
							       if (test1556_898)
								 {
								    return unroll_call_164_inline_recursion(variable_852, node_4, local_854, new_kfactor_216_868, new_call_202_897, stack_6);
								 }
							       else
								 {
								    let_fun_218_t aux_2132;
								    aux_2132 = plain_call_51_inline_recursion(variable_852, node_4, local_854, new_call_202_897, stack_6);
								    return (obj_t) (aux_2132);
								 }
							    }
							 }
						      }
						   }
						}
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* plain-call */ let_fun_218_t 
plain_call_51_inline_recursion(variable_t variable_7, node_t node_8, local_t local_9, app_t new_call_202_10, obj_t stack_11)
{
   shrink_args__237_inline_variant(variable_7);
   {
      obj_t loc_972;
      loc_972 = (((node_t) CREF(node_8))->loc);
      {
	 type_t arg1622_974;
	 obj_t arg1624_976;
	 node_t arg1625_977;
	 arg1622_974 = (((node_t) CREF(node_8))->type);
	 {
	    obj_t list1626_978;
	    {
	       obj_t aux_2138;
	       aux_2138 = (obj_t) (local_9);
	       list1626_978 = MAKE_PAIR(aux_2138, BNIL);
	    }
	    arg1624_976 = list1626_978;
	 }
	 {
	    obj_t arg1628_980;
	    obj_t arg1630_981;
	    {
	       obj_t list1631_982;
	       {
		  obj_t aux_2141;
		  aux_2141 = (obj_t) (variable_7);
		  list1631_982 = MAKE_PAIR(aux_2141, BNIL);
	       }
	       arg1628_980 = list1631_982;
	    }
	    {
	       obj_t list1633_984;
	       {
		  obj_t aux_2144;
		  aux_2144 = (obj_t) (local_9);
		  list1633_984 = MAKE_PAIR(aux_2144, BNIL);
	       }
	       arg1630_981 = list1633_984;
	    }
	    arg1625_977 = alphatize_ast_alphatize(arg1628_980, arg1630_981, loc_972, (node_t) (new_call_202_10));
	 }
	 {
	    let_fun_218_t res1889_1669;
	    {
	       obj_t key_1656;
	       key_1656 = BINT(((long) -1));
	       {
		  let_fun_218_t new1353_1659;
		  new1353_1659 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
		  {
		     long arg1703_1660;
		     arg1703_1660 = class_num_218___object(let_fun_218_ast_node);
		     {
			obj_t obj_1667;
			obj_1667 = (obj_t) (new1353_1659);
			(((obj_t) CREF(obj_1667))->header = MAKE_HEADER(arg1703_1660, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_2154;
		     aux_2154 = (object_t) (new1353_1659);
		     OBJECT_WIDENING_SET(aux_2154, BFALSE);
		  }
		  ((((let_fun_218_t) CREF(new1353_1659))->loc) = ((obj_t) loc_972), BUNSPEC);
		  ((((let_fun_218_t) CREF(new1353_1659))->type) = ((type_t) arg1622_974), BUNSPEC);
		  ((((let_fun_218_t) CREF(new1353_1659))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		  ((((let_fun_218_t) CREF(new1353_1659))->key) = ((obj_t) key_1656), BUNSPEC);
		  ((((let_fun_218_t) CREF(new1353_1659))->locals) = ((obj_t) arg1624_976), BUNSPEC);
		  ((((let_fun_218_t) CREF(new1353_1659))->body) = ((node_t) arg1625_977), BUNSPEC);
		  res1889_1669 = new1353_1659;
	       }
	    }
	    return res1889_1669;
	 }
      }
   }
}


/* unroll-call */ obj_t 
unroll_call_164_inline_recursion(variable_t variable_12, node_t node_13, local_t local_14, obj_t kfactor_15, app_t call_16, obj_t stack_17)
{
   {
      obj_t loc_986;
      {
	 node_t obj_1670;
	 obj_1670 = (node_t) (call_16);
	 loc_986 = (((node_t) CREF(obj_1670))->loc);
      }
      {
	 node_t new_call_202_987;
	 {
	    obj_t arg1655_1008;
	    obj_t arg1656_1009;
	    {
	       obj_t list1657_1010;
	       {
		  obj_t aux_2165;
		  aux_2165 = (obj_t) (variable_12);
		  list1657_1010 = MAKE_PAIR(aux_2165, BNIL);
	       }
	       arg1655_1008 = list1657_1010;
	    }
	    {
	       obj_t list1659_1012;
	       {
		  obj_t aux_2168;
		  aux_2168 = (obj_t) (local_14);
		  list1659_1012 = MAKE_PAIR(aux_2168, BNIL);
	       }
	       arg1656_1009 = list1659_1012;
	    }
	    new_call_202_987 = alphatize_ast_alphatize(arg1655_1008, arg1656_1009, loc_986, (node_t) (call_16));
	 }
	 {
	    node_t new_body_215_989;
	    {
	       obj_t arg1652_1005;
	       {
		  obj_t aux_2173;
		  aux_2173 = (obj_t) (local_14);
		  arg1652_1005 = MAKE_PAIR(aux_2173, stack_17);
	       }
	       new_body_215_989 = inline_app_simple_198_inline_simple(new_call_202_987, (long) CINT(kfactor_15), arg1652_1005, string1897_inline_recursion);
	    }
	    {
	       shrink_args__237_inline_variant(variable_12);
	       {
		  obj_t __990;
		  {
		     node_t arg1636_992;
		     {
			obj_t arg1639_1851;
			arg1639_1851 = make_fx_procedure(arg1639_inline_recursion, ((long) 1), ((long) 2));
			PROCEDURE_SET(arg1639_1851, ((long) 0), loc_986);
			{
			   obj_t aux_2181;
			   aux_2181 = (obj_t) (local_14);
			   PROCEDURE_SET(arg1639_1851, ((long) 1), aux_2181);
			}
			arg1636_992 = nest_loop__92_inline_loop(new_body_215_989, local_14, arg1639_1851);
		     }
		     __990 = node_cse__231_reduce_cse(arg1636_992, BNIL);
		  }
		  {
		     obj_t node_991;
		     node_991 = _res1__155___r5_control_features_6_4;
		     return node_991;
		  }
	       }
	    }
	 }
      }
   }
}


/* arg1639 */ obj_t 
arg1639_inline_recursion(obj_t env_1852, obj_t node_1855)
{
   {
      obj_t loc_1853;
      obj_t local_1854;
      loc_1853 = PROCEDURE_REF(env_1852, ((long) 0));
      local_1854 = PROCEDURE_REF(env_1852, ((long) 1));
      {
	 obj_t node_995;
	 {
	    let_fun_218_t aux_2188;
	    node_995 = node_1855;
	    {
	       type_t arg1645_998;
	       obj_t arg1647_1000;
	       {
		  node_t obj_1677;
		  obj_1677 = (node_t) (node_995);
		  arg1645_998 = (((node_t) CREF(obj_1677))->type);
	       }
	       {
		  obj_t list1649_1002;
		  list1649_1002 = MAKE_PAIR(local_1854, BNIL);
		  arg1647_1000 = list1649_1002;
	       }
	       {
		  let_fun_218_t res1890_1695;
		  {
		     obj_t key_1682;
		     node_t body_1684;
		     key_1682 = BINT(((long) -1));
		     body_1684 = (node_t) (node_995);
		     {
			let_fun_218_t new1353_1685;
			new1353_1685 = ((let_fun_218_t) BREF(GC_MALLOC(sizeof(struct let_fun_218))));
			{
			   long arg1703_1686;
			   arg1703_1686 = class_num_218___object(let_fun_218_ast_node);
			   {
			      obj_t obj_1693;
			      obj_1693 = (obj_t) (new1353_1685);
			      (((obj_t) CREF(obj_1693))->header = MAKE_HEADER(arg1703_1686, 0), BUNSPEC);
			   }
			}
			{
			   object_t aux_2198;
			   aux_2198 = (object_t) (new1353_1685);
			   OBJECT_WIDENING_SET(aux_2198, BFALSE);
			}
			((((let_fun_218_t) CREF(new1353_1685))->loc) = ((obj_t) loc_1853), BUNSPEC);
			((((let_fun_218_t) CREF(new1353_1685))->type) = ((type_t) arg1645_998), BUNSPEC);
			((((let_fun_218_t) CREF(new1353_1685))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
			((((let_fun_218_t) CREF(new1353_1685))->key) = ((obj_t) key_1682), BUNSPEC);
			((((let_fun_218_t) CREF(new1353_1685))->locals) = ((obj_t) arg1647_1000), BUNSPEC);
			((((let_fun_218_t) CREF(new1353_1685))->body) = ((node_t) body_1684), BUNSPEC);
			res1890_1695 = new1353_1685;
		     }
		  }
		  aux_2188 = res1890_1695;
	       }
	    }
	    return (obj_t) (aux_2188);
	 }
      }
   }
}


/* is-recursive? */ bool_t 
is_recursive__125_inline_recursion(variable_t var_18)
{
   {
      value_t sfun_1014;
      sfun_1014 = (((variable_t) CREF(var_18))->value);
      {
	 bool_t test1662_1015;
	 test1662_1015 = is_a__118___object((obj_t) (sfun_1014), isfun_inline_inline);
	 if (test1662_1015)
	   {
	      bool_t test_2212;
	      {
		 obj_t aux_2213;
		 {
		    isfun_t obj_1698;
		    obj_1698 = (isfun_t) (sfun_1014);
		    {
		       obj_t aux_2215;
		       {
			  object_t aux_2216;
			  aux_2216 = (object_t) (obj_1698);
			  aux_2215 = OBJECT_WIDENING(aux_2216);
		       }
		       aux_2213 = (((isfun_t) CREF(aux_2215))->recursive_calls_44);
		    }
		 }
		 test_2212 = PAIRP(aux_2213);
	      }
	      if (test_2212)
		{
		   return ((bool_t) 1);
		}
	      else
		{
		   bool_t test_2221;
		   {
		      obj_t aux_2222;
		      {
			 isfun_t obj_1700;
			 obj_1700 = (isfun_t) (sfun_1014);
			 {
			    obj_t aux_2224;
			    {
			       object_t aux_2225;
			       aux_2225 = (object_t) (obj_1700);
			       aux_2224 = OBJECT_WIDENING(aux_2225);
			    }
			    aux_2222 = (((isfun_t) CREF(aux_2224))->recursive_calls_44);
			 }
		      }
		      test_2221 = NULLP(aux_2222);
		   }
		   if (test_2221)
		     {
			return ((bool_t) 0);
		     }
		   else
		     {
			{
			   obj_t calls_1018;
			   {
			      node_t aux_2230;
			      {
				 isfun_t obj_1702;
				 obj_1702 = (isfun_t) (sfun_1014);
				 {
				    obj_t aux_2232;
				    {
				       object_t aux_2233;
				       aux_2233 = (object_t) (obj_1702);
				       aux_2232 = OBJECT_WIDENING(aux_2233);
				    }
				    aux_2230 = (((isfun_t) CREF(aux_2232))->original_body_40);
				 }
			      }
			      calls_1018 = find_recursive_calls_52_inline_recursion(aux_2230, var_18);
			   }
			   {
			      isfun_t obj_1703;
			      obj_1703 = (isfun_t) (sfun_1014);
			      {
				 obj_t aux_2239;
				 {
				    object_t aux_2240;
				    aux_2240 = (object_t) (obj_1703);
				    aux_2239 = OBJECT_WIDENING(aux_2240);
				 }
				 ((((isfun_t) CREF(aux_2239))->recursive_calls_44) = ((obj_t) calls_1018), BUNSPEC);
			      }
			   }
			   return PAIRP(calls_1018);
			}
		     }
		}
	   }
	 else
	   {
	      obj_t calls_1022;
	      {
		 node_t aux_2245;
		 {
		    obj_t aux_2246;
		    {
		       sfun_t obj_1706;
		       obj_1706 = (sfun_t) (sfun_1014);
		       aux_2246 = (((sfun_t) CREF(obj_1706))->body);
		    }
		    aux_2245 = (node_t) (aux_2246);
		 }
		 calls_1022 = find_recursive_calls_52_inline_recursion(aux_2245, var_18);
	      }
	      {
		 isfun_t obj1495_1023;
		 obj1495_1023 = ((isfun_t) (sfun_1014));
		 {
		    isfun_t arg1668_1024;
		    {
		       isfun_t res1891_1713;
		       {
			  node_t original_body_40_1708;
			  {
			     obj_t aux_2252;
			     {
				sfun_t obj_1707;
				obj_1707 = (sfun_t) (sfun_1014);
				aux_2252 = (((sfun_t) CREF(obj_1707))->body);
			     }
			     original_body_40_1708 = (node_t) (aux_2252);
			  }
			  {
			     isfun_t new1437_1710;
			     new1437_1710 = ((isfun_t) BREF(GC_MALLOC(sizeof(struct isfun))));
			     ((((isfun_t) CREF(new1437_1710))->original_body_40) = ((node_t) original_body_40_1708), BUNSPEC);
			     ((((isfun_t) CREF(new1437_1710))->recursive_calls_44) = ((obj_t) calls_1022), BUNSPEC);
			     res1891_1713 = new1437_1710;
			  }
		       }
		       arg1668_1024 = res1891_1713;
		    }
		    {
		       obj_t aux_2261;
		       object_t aux_2259;
		       aux_2261 = (obj_t) (arg1668_1024);
		       aux_2259 = (object_t) (obj1495_1023);
		       OBJECT_WIDENING_SET(aux_2259, aux_2261);
		    }
		 }
		 {
		    long arg1672_1027;
		    arg1672_1027 = class_num_218___object(isfun_inline_inline);
		    {
		       obj_t obj_1714;
		       obj_1714 = (obj_t) (obj1495_1023);
		       (((obj_t) CREF(obj_1714))->header = MAKE_HEADER(arg1672_1027, 0), BUNSPEC);
		    }
		 }
		 obj1495_1023;
	      }
	      return PAIRP(calls_1022);
	   }
      }
   }
}


/* _is-recursive? */ obj_t 
_is_recursive__21_inline_recursion(obj_t env_1856, obj_t var_1857)
{
   {
      bool_t aux_2268;
      aux_2268 = is_recursive__125_inline_recursion((variable_t) (var_1857));
      return BBOOL(aux_2268);
   }
}


/* find-recursive-calls* */ obj_t 
find_recursive_calls__36_inline_recursion(obj_t node__221_57, variable_t var_58)
{
   {
      obj_t node__221_1029;
      obj_t calls_1030;
      node__221_1029 = node__221_57;
      calls_1030 = BNIL;
    loop_1031:
      if (NULLP(node__221_1029))
	{
	   return calls_1030;
	}
      else
	{
	   obj_t arg1677_1034;
	   obj_t arg1678_1035;
	   arg1677_1034 = CDR(node__221_1029);
	   {
	      obj_t arg1679_1036;
	      {
		 node_t aux_2275;
		 {
		    obj_t aux_2276;
		    aux_2276 = CAR(node__221_1029);
		    aux_2275 = (node_t) (aux_2276);
		 }
		 arg1679_1036 = find_recursive_calls_52_inline_recursion(aux_2275, var_58);
	      }
	      arg1678_1035 = append_2_18___r4_pairs_and_lists_6_3(arg1679_1036, calls_1030);
	   }
	   {
	      obj_t calls_2282;
	      obj_t node__221_2281;
	      node__221_2281 = arg1677_1034;
	      calls_2282 = arg1678_1035;
	      calls_1030 = calls_2282;
	      node__221_1029 = node__221_2281;
	      goto loop_1031;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_inline_recursion()
{
   add_generic__110___object(find_recursive_calls_env_59_inline_recursion, find_recursive_calls_default1503_env_35_inline_recursion);
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, sequence_ast_node, ((long) 0));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, app_ast_node, ((long) 1));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, app_ly_162_ast_node, ((long) 2));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, funcall_ast_node, ((long) 3));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, pragma_ast_node, ((long) 4));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, cast_ast_node, ((long) 5));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, setq_ast_node, ((long) 6));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, conditional_ast_node, ((long) 7));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, fail_ast_node, ((long) 8));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, select_ast_node, ((long) 9));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, let_fun_218_ast_node, ((long) 10));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, let_var_6_ast_node, ((long) 11));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, set_ex_it_116_ast_node, ((long) 12));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, jump_ex_it_184_ast_node, ((long) 13));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, make_box_202_ast_node, ((long) 14));
   add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, box_ref_242_ast_node, ((long) 15));
   {
      long aux_2300;
      aux_2300 = add_inlined_method__244___object(find_recursive_calls_env_59_inline_recursion, box_set__221_ast_node, ((long) 16));
      return BINT(aux_2300);
   }
}


/* find-recursive-calls */ obj_t 
find_recursive_calls_52_inline_recursion(node_t node_19, variable_t var_20)
{
 find_recursive_calls_52_inline_recursion:
   {
      obj_t method1778_1384;
      obj_t class1783_1385;
      {
	 obj_t arg1786_1382;
	 obj_t arg1788_1383;
	 {
	    object_t obj_1770;
	    obj_1770 = (object_t) (node_19);
	    {
	       obj_t pre_method_105_1771;
	       pre_method_105_1771 = PROCEDURE_REF(find_recursive_calls_env_59_inline_recursion, ((long) 2));
	       if (INTEGERP(pre_method_105_1771))
		 {
		    PROCEDURE_SET(find_recursive_calls_env_59_inline_recursion, ((long) 2), BUNSPEC);
		    arg1786_1382 = pre_method_105_1771;
		 }
	       else
		 {
		    long obj_class_num_177_1776;
		    obj_class_num_177_1776 = TYPE(obj_1770);
		    {
		       obj_t arg1177_1777;
		       arg1177_1777 = PROCEDURE_REF(find_recursive_calls_env_59_inline_recursion, ((long) 1));
		       {
			  long arg1178_1781;
			  {
			     long arg1179_1782;
			     arg1179_1782 = OBJECT_TYPE;
			     arg1178_1781 = (obj_class_num_177_1776 - arg1179_1782);
			  }
			  arg1786_1382 = VECTOR_REF(arg1177_1777, arg1178_1781);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1787;
	    object_1787 = (object_t) (node_19);
	    {
	       long arg1180_1788;
	       {
		  long arg1181_1789;
		  long arg1182_1790;
		  arg1181_1789 = TYPE(object_1787);
		  arg1182_1790 = OBJECT_TYPE;
		  arg1180_1788 = (arg1181_1789 - arg1182_1790);
	       }
	       {
		  obj_t vector_1794;
		  vector_1794 = _classes__134___object;
		  arg1788_1383 = VECTOR_REF(vector_1794, arg1180_1788);
	       }
	    }
	 }
	 method1778_1384 = arg1786_1382;
	 class1783_1385 = arg1788_1383;
	 {
	    if (INTEGERP(method1778_1384))
	      {
		 switch ((long) CINT(method1778_1384))
		   {
		   case ((long) 0):
		      {
			 sequence_t node_1391;
			 node_1391 = (sequence_t) (node_19);
			 return find_recursive_calls__36_inline_recursion((((sequence_t) CREF(node_1391))->nodes), var_20);
		      }
		      break;
		   case ((long) 1):
		      {
			 app_t node_1394;
			 node_1394 = (app_t) (node_19);
			 {
			    obj_t args_calls_209_1397;
			    args_calls_209_1397 = find_recursive_calls__36_inline_recursion((((app_t) CREF(node_1394))->args), var_20);
			    {
			       bool_t test1792_1398;
			       {
				  bool_t test1793_1399;
				  {
				     obj_t aux_2326;
				     {
					var_t aux_2327;
					aux_2327 = (((app_t) CREF(node_1394))->fun);
					aux_2326 = (obj_t) (aux_2327);
				     }
				     test1793_1399 = is_a__118___object(aux_2326, var_ast_node);
				  }
				  if (test1793_1399)
				    {
				       obj_t aux_2337;
				       obj_t aux_2332;
				       aux_2337 = (obj_t) (var_20);
				       {
					  variable_t aux_2333;
					  {
					     var_t arg1795_1401;
					     arg1795_1401 = (((app_t) CREF(node_1394))->fun);
					     aux_2333 = (((var_t) CREF(arg1795_1401))->variable);
					  }
					  aux_2332 = (obj_t) (aux_2333);
				       }
				       test1792_1398 = (aux_2332 == aux_2337);
				    }
				  else
				    {
				       test1792_1398 = ((bool_t) 0);
				    }
			       }
			       if (test1792_1398)
				 {
				    obj_t aux_2341;
				    aux_2341 = (obj_t) (node_1394);
				    return MAKE_PAIR(aux_2341, args_calls_209_1397);
				 }
			       else
				 {
				    return args_calls_209_1397;
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 2):
		      {
			 app_ly_162_t node_1404;
			 node_1404 = (app_ly_162_t) (node_19);
			 {
			    obj_t arg1799_1407;
			    obj_t arg1800_1408;
			    arg1799_1407 = find_recursive_calls_52_inline_recursion((((app_ly_162_t) CREF(node_1404))->fun), var_20);
			    arg1800_1408 = find_recursive_calls_52_inline_recursion((((app_ly_162_t) CREF(node_1404))->arg), var_20);
			    return append_2_18___r4_pairs_and_lists_6_3(arg1799_1407, arg1800_1408);
			 }
		      }
		      break;
		   case ((long) 3):
		      {
			 funcall_t node_1411;
			 node_1411 = (funcall_t) (node_19);
			 {
			    obj_t arg1804_1414;
			    obj_t arg1805_1415;
			    arg1804_1414 = find_recursive_calls_52_inline_recursion((((funcall_t) CREF(node_1411))->fun), var_20);
			    arg1805_1415 = find_recursive_calls__36_inline_recursion((((funcall_t) CREF(node_1411))->args), var_20);
			    return append_2_18___r4_pairs_and_lists_6_3(arg1804_1414, arg1805_1415);
			 }
		      }
		      break;
		   case ((long) 4):
		      {
			 pragma_t node_1418;
			 node_1418 = (pragma_t) (node_19);
			 return find_recursive_calls__36_inline_recursion((((pragma_t) CREF(node_1418))->args), var_20);
		      }
		      break;
		   case ((long) 5):
		      {
			 cast_t node_1421;
			 node_1421 = (cast_t) (node_19);
			 {
			    node_t node_2360;
			    node_2360 = (((cast_t) CREF(node_1421))->arg);
			    node_19 = node_2360;
			    goto find_recursive_calls_52_inline_recursion;
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 setq_t node_1424;
			 node_1424 = (setq_t) (node_19);
			 {
			    node_t node_2363;
			    node_2363 = (((setq_t) CREF(node_1424))->value);
			    node_19 = node_2363;
			    goto find_recursive_calls_52_inline_recursion;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 conditional_t node_1427;
			 node_1427 = (conditional_t) (node_19);
			 {
			    obj_t arg1811_1430;
			    obj_t arg1812_1431;
			    obj_t arg1813_1432;
			    arg1811_1430 = find_recursive_calls_52_inline_recursion((((conditional_t) CREF(node_1427))->test), var_20);
			    arg1812_1431 = find_recursive_calls_52_inline_recursion((((conditional_t) CREF(node_1427))->true), var_20);
			    arg1813_1432 = find_recursive_calls_52_inline_recursion((((conditional_t) CREF(node_1427))->false), var_20);
			    {
			       obj_t list1814_1433;
			       {
				  obj_t arg1815_1434;
				  {
				     obj_t arg1816_1435;
				     arg1816_1435 = MAKE_PAIR(arg1813_1432, BNIL);
				     arg1815_1434 = MAKE_PAIR(arg1812_1431, arg1816_1435);
				  }
				  list1814_1433 = MAKE_PAIR(arg1811_1430, arg1815_1434);
			       }
			       return append___r4_pairs_and_lists_6_3(list1814_1433);
			    }
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 fail_t node_1440;
			 node_1440 = (fail_t) (node_19);
			 {
			    obj_t arg1822_1443;
			    obj_t arg1823_1444;
			    obj_t arg1824_1445;
			    arg1822_1443 = find_recursive_calls_52_inline_recursion((((fail_t) CREF(node_1440))->proc), var_20);
			    arg1823_1444 = find_recursive_calls_52_inline_recursion((((fail_t) CREF(node_1440))->msg), var_20);
			    arg1824_1445 = find_recursive_calls_52_inline_recursion((((fail_t) CREF(node_1440))->obj), var_20);
			    {
			       obj_t list1825_1446;
			       {
				  obj_t arg1826_1447;
				  {
				     obj_t arg1827_1448;
				     arg1827_1448 = MAKE_PAIR(arg1824_1445, BNIL);
				     arg1826_1447 = MAKE_PAIR(arg1823_1444, arg1827_1448);
				  }
				  list1825_1446 = MAKE_PAIR(arg1822_1443, arg1826_1447);
			       }
			       return append___r4_pairs_and_lists_6_3(list1825_1446);
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 select_t node_1453;
			 node_1453 = (select_t) (node_19);
			 {
			    obj_t clauses_1455;
			    obj_t calls_1456;
			    {
			       obj_t arg1833_1458;
			       obj_t arg1834_1459;
			       arg1833_1458 = (((select_t) CREF(node_1453))->clauses);
			       arg1834_1459 = find_recursive_calls_52_inline_recursion((((select_t) CREF(node_1453))->test), var_20);
			       clauses_1455 = arg1833_1458;
			       calls_1456 = arg1834_1459;
			     loop_1457:
			       if (NULLP(clauses_1455))
				 {
				    return calls_1456;
				 }
			       else
				 {
				    obj_t arg1837_1462;
				    obj_t arg1838_1463;
				    arg1837_1462 = CDR(clauses_1455);
				    {
				       obj_t arg1839_1464;
				       {
					  node_t aux_2394;
					  {
					     obj_t aux_2395;
					     {
						obj_t aux_2396;
						aux_2396 = CAR(clauses_1455);
						aux_2395 = CDR(aux_2396);
					     }
					     aux_2394 = (node_t) (aux_2395);
					  }
					  arg1839_1464 = find_recursive_calls_52_inline_recursion(aux_2394, var_20);
				       }
				       arg1838_1463 = append_2_18___r4_pairs_and_lists_6_3(arg1839_1464, calls_1456);
				    }
				    {
				       obj_t calls_2403;
				       obj_t clauses_2402;
				       clauses_2402 = arg1837_1462;
				       calls_2403 = arg1838_1463;
				       calls_1456 = calls_2403;
				       clauses_1455 = clauses_2402;
				       goto loop_1457;
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 let_fun_218_t node_1467;
			 node_1467 = (let_fun_218_t) (node_19);
			 {
			    obj_t locals_1469;
			    obj_t calls_1470;
			    {
			       obj_t arg1847_1472;
			       obj_t arg1848_1473;
			       arg1847_1472 = (((let_fun_218_t) CREF(node_1467))->locals);
			       arg1848_1473 = find_recursive_calls_52_inline_recursion((((let_fun_218_t) CREF(node_1467))->body), var_20);
			       locals_1469 = arg1847_1472;
			       calls_1470 = arg1848_1473;
			     loop_1471:
			       if (NULLP(locals_1469))
				 {
				    return calls_1470;
				 }
			       else
				 {
				    obj_t arg1852_1476;
				    obj_t arg1853_1477;
				    arg1852_1476 = CDR(locals_1469);
				    {
				       obj_t arg1856_1478;
				       {
					  node_t aux_2411;
					  {
					     obj_t aux_2412;
					     {
						sfun_t obj_1831;
						{
						   value_t aux_2413;
						   {
						      local_t obj_1830;
						      {
							 obj_t aux_2414;
							 aux_2414 = CAR(locals_1469);
							 obj_1830 = (local_t) (aux_2414);
						      }
						      aux_2413 = (((local_t) CREF(obj_1830))->value);
						   }
						   obj_1831 = (sfun_t) (aux_2413);
						}
						aux_2412 = (((sfun_t) CREF(obj_1831))->body);
					     }
					     aux_2411 = (node_t) (aux_2412);
					  }
					  arg1856_1478 = find_recursive_calls_52_inline_recursion(aux_2411, var_20);
				       }
				       arg1853_1477 = append_2_18___r4_pairs_and_lists_6_3(calls_1470, arg1856_1478);
				    }
				    {
				       obj_t calls_2424;
				       obj_t locals_2423;
				       locals_2423 = arg1852_1476;
				       calls_2424 = arg1853_1477;
				       calls_1470 = calls_2424;
				       locals_1469 = locals_2423;
				       goto loop_1471;
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 let_var_6_t node_1482;
			 node_1482 = (let_var_6_t) (node_19);
			 {
			    obj_t bindings_1484;
			    obj_t calls_1485;
			    {
			       obj_t arg1860_1487;
			       obj_t arg1861_1488;
			       arg1860_1487 = (((let_var_6_t) CREF(node_1482))->bindings);
			       arg1861_1488 = find_recursive_calls_52_inline_recursion((((let_var_6_t) CREF(node_1482))->body), var_20);
			       bindings_1484 = arg1860_1487;
			       calls_1485 = arg1861_1488;
			     loop_1486:
			       if (NULLP(bindings_1484))
				 {
				    return calls_1485;
				 }
			       else
				 {
				    obj_t arg1864_1491;
				    obj_t arg1865_1492;
				    arg1864_1491 = CDR(bindings_1484);
				    {
				       obj_t arg1866_1493;
				       {
					  node_t aux_2432;
					  {
					     obj_t aux_2433;
					     {
						obj_t aux_2434;
						aux_2434 = CAR(bindings_1484);
						aux_2433 = CDR(aux_2434);
					     }
					     aux_2432 = (node_t) (aux_2433);
					  }
					  arg1866_1493 = find_recursive_calls_52_inline_recursion(aux_2432, var_20);
				       }
				       arg1865_1492 = append_2_18___r4_pairs_and_lists_6_3(calls_1485, arg1866_1493);
				    }
				    {
				       obj_t calls_2441;
				       obj_t bindings_2440;
				       bindings_2440 = arg1864_1491;
				       calls_2441 = arg1865_1492;
				       calls_1485 = calls_2441;
				       bindings_1484 = bindings_2440;
				       goto loop_1486;
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 set_ex_it_116_t node_1496;
			 node_1496 = (set_ex_it_116_t) (node_19);
			 {
			    node_t node_2443;
			    node_2443 = (((set_ex_it_116_t) CREF(node_1496))->body);
			    node_19 = node_2443;
			    goto find_recursive_calls_52_inline_recursion;
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 jump_ex_it_184_t node_1499;
			 node_1499 = (jump_ex_it_184_t) (node_19);
			 {
			    obj_t arg1870_1502;
			    obj_t arg1871_1503;
			    arg1870_1502 = find_recursive_calls_52_inline_recursion((((jump_ex_it_184_t) CREF(node_1499))->exit), var_20);
			    arg1871_1503 = find_recursive_calls_52_inline_recursion((((jump_ex_it_184_t) CREF(node_1499))->value), var_20);
			    return append_2_18___r4_pairs_and_lists_6_3(arg1870_1502, arg1871_1503);
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 make_box_202_t node_1506;
			 node_1506 = (make_box_202_t) (node_19);
			 {
			    node_t node_2452;
			    node_2452 = (((make_box_202_t) CREF(node_1506))->value);
			    node_19 = node_2452;
			    goto find_recursive_calls_52_inline_recursion;
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 box_ref_242_t node_1509;
			 node_1509 = (box_ref_242_t) (node_19);
			 {
			    node_t node_2455;
			    {
			       var_t aux_2456;
			       aux_2456 = (((box_ref_242_t) CREF(node_1509))->var);
			       node_2455 = (node_t) (aux_2456);
			    }
			    node_19 = node_2455;
			    goto find_recursive_calls_52_inline_recursion;
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 box_set__221_t node_1512;
			 node_1512 = (box_set__221_t) (node_19);
			 {
			    obj_t arg1878_1515;
			    obj_t arg1879_1516;
			    {
			       node_t aux_2460;
			       {
				  var_t aux_2461;
				  aux_2461 = (((box_set__221_t) CREF(node_1512))->var);
				  aux_2460 = (node_t) (aux_2461);
			       }
			       arg1878_1515 = find_recursive_calls_52_inline_recursion(aux_2460, var_20);
			    }
			    arg1879_1516 = find_recursive_calls_52_inline_recursion((((box_set__221_t) CREF(node_1512))->value), var_20);
			    return append_2_18___r4_pairs_and_lists_6_3(arg1878_1515, arg1879_1516);
			 }
		      }
		      break;
		   default:
		    case_else1784_1388:
		      if (PROCEDUREP(method1778_1384))
			{
			   return PROCEDURE_ENTRY(method1778_1384) (method1778_1384, (obj_t) (node_19), (obj_t) (var_20), BEOA);
			}
		      else
			{
			   obj_t fun1777_1380;
			   fun1777_1380 = PROCEDURE_REF(find_recursive_calls_env_59_inline_recursion, ((long) 0));
			   return PROCEDURE_ENTRY(fun1777_1380) (fun1777_1380, (obj_t) (node_19), (obj_t) (var_20), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1784_1388;
	      }
	 }
      }
   }
}


/* _find-recursive-calls */ obj_t 
_find_recursive_calls_233_inline_recursion(obj_t env_1858, obj_t node_1859, obj_t var_1860)
{
   return find_recursive_calls_52_inline_recursion((node_t) (node_1859), (variable_t) (var_1860));
}


/* find-recursive-calls-default1503 */ obj_t 
find_recursive_calls_default1503_165_inline_recursion(node_t node_21, variable_t var_22)
{
   return BNIL;
}


/* _find-recursive-calls-default1503 */ obj_t 
_find_recursive_calls_default1503_238_inline_recursion(obj_t env_1861, obj_t node_1862, obj_t var_1863)
{
   return find_recursive_calls_default1503_165_inline_recursion((node_t) (node_1862), (variable_t) (var_1863));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_inline_recursion()
{
   module_initialization_70_tools_trace(((long) 0), "INLINE_RECURSION");
   module_initialization_70_engine_param(((long) 0), "INLINE_RECURSION");
   module_initialization_70_type_type(((long) 0), "INLINE_RECURSION");
   module_initialization_70_ast_var(((long) 0), "INLINE_RECURSION");
   module_initialization_70_ast_node(((long) 0), "INLINE_RECURSION");
   module_initialization_70_ast_local(((long) 0), "INLINE_RECURSION");
   module_initialization_70_ast_alphatize(((long) 0), "INLINE_RECURSION");
   module_initialization_70_ast_sexp(((long) 0), "INLINE_RECURSION");
   module_initialization_70_tools_speek(((long) 0), "INLINE_RECURSION");
   module_initialization_70_tools_shape(((long) 0), "INLINE_RECURSION");
   module_initialization_70_tools_error(((long) 0), "INLINE_RECURSION");
   module_initialization_70_inline_inline(((long) 0), "INLINE_RECURSION");
   module_initialization_70_inline_simple(((long) 0), "INLINE_RECURSION");
   module_initialization_70_inline_variant(((long) 0), "INLINE_RECURSION");
   module_initialization_70_inline_loop(((long) 0), "INLINE_RECURSION");
   module_initialization_70_inline_app(((long) 0), "INLINE_RECURSION");
   return module_initialization_70_reduce_cse(((long) 0), "INLINE_RECURSION");
}
