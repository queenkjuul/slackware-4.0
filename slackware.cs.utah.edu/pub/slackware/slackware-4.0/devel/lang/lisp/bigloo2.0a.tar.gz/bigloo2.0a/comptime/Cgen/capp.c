/*===========================================================================*/
/*   (Cgen/capp.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct cop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *cop_t;

typedef struct clabel
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t name;
     bool_t used__226;
     obj_t body;
  }
      *clabel_t;

typedef struct cgoto
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct clabel *label;
  }
     *cgoto_t;

typedef struct block
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
     *block_t;

typedef struct creturn
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
       *creturn_t;

typedef struct cvoid
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
     *cvoid_t;

typedef struct catom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t value;
  }
     *catom_t;

typedef struct varc
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct variable *variable;
  }
    *varc_t;

typedef struct cpragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t format;
     obj_t args;
  }
       *cpragma_t;

typedef struct ccast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct cop *arg;
  }
     *ccast_t;

typedef struct csequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     bool_t c_exp__163;
     obj_t cops;
  }
         *csequence_t;

typedef struct nop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
   *nop_t;

typedef struct stop
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
    *stop_t;

typedef struct csetq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct varc *var;
     struct cop *value;
  }
     *csetq_t;

typedef struct cif
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     struct cop *true;
     struct cop *false;
  }
   *cif_t;

typedef struct local_var_164
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     obj_t vars;
  }
             *local_var_164_t;

typedef struct cfuncall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
     obj_t strength;
  }
        *cfuncall_t;

typedef struct capply
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     struct cop *arg;
  }
      *capply_t;

typedef struct capp
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *fun;
     obj_t args;
  }
    *capp_t;

typedef struct cfail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *proc;
     struct cop *msg;
     struct cop *obj;
  }
     *cfail_t;

typedef struct cswitch
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *test;
     obj_t clauses;
  }
       *cswitch_t;

typedef struct cmake_box_177
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *value;
  }
             *cmake_box_177_t;

typedef struct cbox_ref_44
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
  }
           *cbox_ref_44_t;

typedef struct cbox_set__132
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *var;
     struct cop *value;
  }
             *cbox_set__132_t;

typedef struct cset_ex_it_123
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *jump_value_221;
     struct cop *body;
  }
              *cset_ex_it_123_t;

typedef struct cjump_ex_it_131
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *exit;
     struct cop *value;
  }
               *cjump_ex_it_131_t;

typedef struct sfun_c_188
  {
     struct clabel *label;
     bool_t integrated;
  }
          *sfun_c_188_t;

typedef struct bdb_block_21
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct cop *body;
  }
            *bdb_block_21_t;


static obj_t method_init_76_cgen_capp();
extern obj_t block_cgen_cop;
extern obj_t funcall_ast_node;
extern setq_t node_setq_243_cgen_cgen(variable_t, node_t);
extern obj_t var_ast_node;
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern local_t make_local_svar_name_219_cgen_cgen(obj_t, type_t);
extern obj_t _obj__252_type_cache;
extern obj_t block_kont_197_cgen_cgen(obj_t, obj_t);
static obj_t node_sfun_non_tail_app__cop_176_cgen_capp(variable_t, app_t, obj_t);
extern obj_t _id_kont__126_cgen_cgen;
extern obj_t varc_cgen_cop;
extern obj_t local_var_164_cgen_cop;
extern obj_t last_pair_93___r4_pairs_and_lists_6_3(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _node__cop_12_cgen_cgen(obj_t, obj_t, obj_t);
extern obj_t catom_cgen_cop;
extern obj_t cgoto_cgen_cop;
extern obj_t module_initialization_70_cgen_capp(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_cgen_emit(long, char *);
extern obj_t module_initialization_70_cgen_cop(long, char *);
extern obj_t module_initialization_70_cgen_cgen(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t node__cop_app_ly_235_cgen_capp(obj_t, obj_t, obj_t);
extern obj_t _the_global__73_cgen_cgen;
extern obj_t csetq_cgen_cop;
static obj_t node_cfun_non_tail_app__cop_38_cgen_capp(variable_t, app_t, obj_t);
extern obj_t _return_kont__110_cgen_cgen;
extern long class_num_218___object(obj_t);
extern obj_t stop_cgen_cop;
static obj_t node__cop_funcall_165_cgen_capp(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_cgen_capp();
extern obj_t app_ly_162_ast_node;
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cgen_capp();
static obj_t toplevel_init_63_cgen_capp();
extern obj_t capp_cgen_cop;
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
static obj_t node__cop_app_91_cgen_capp(obj_t, obj_t, obj_t);
static obj_t node_tail_app__cop_48_cgen_capp(variable_t, app_t, obj_t);
extern obj_t local_ast_var;
extern obj_t csequence_cgen_cop;
extern cop_t bdb_let_var_254_cgen_cgen(cop_t, obj_t);
extern obj_t _procedure__226_type_cache;
extern obj_t _stop_kont__121_cgen_cgen;
extern obj_t read___reader(obj_t);
extern cop_t node__cop_142_cgen_cgen(node_t, obj_t);
static obj_t require_initialization_114_cgen_capp = BUNSPEC;
extern obj_t capply_cgen_cop;
static obj_t cnst_init_137_cgen_capp();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t cfuncall_cgen_cop;
static obj_t __cnst[2];

DEFINE_STATIC_PROCEDURE(proc2339_cgen_capp, node__cop_funcall_165_cgen_capp2347, node__cop_funcall_165_cgen_capp, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2340_cgen_capp, node__cop_app_91_cgen_capp2348, node__cop_app_91_cgen_capp, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2338_cgen_capp, node__cop_app_ly_235_cgen_capp2349, node__cop_app_ly_235_cgen_capp, 0L, 2);
extern obj_t node__cop_env_160_cgen_cgen;
DEFINE_STRING(string2341_cgen_capp, string2341_cgen_capp2350, "FUN AUX ", 8);


/* module-initialization */ obj_t 
module_initialization_70_cgen_capp(long checksum_2907, char *from_2908)
{
   if (CBOOL(require_initialization_114_cgen_capp))
     {
	require_initialization_114_cgen_capp = BBOOL(((bool_t) 0));
	library_modules_init_112_cgen_capp();
	cnst_init_137_cgen_capp();
	imported_modules_init_94_cgen_capp();
	method_init_76_cgen_capp();
	toplevel_init_63_cgen_capp();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cgen_capp()
{
   module_initialization_70___object(((long) 0), "CGEN_CAPP");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CGEN_CAPP");
   module_initialization_70___reader(((long) 0), "CGEN_CAPP");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cgen_capp()
{
   {
      obj_t cnst_port_138_2899;
      cnst_port_138_2899 = open_input_string(string2341_cgen_capp);
      {
	 long i_2900;
	 i_2900 = ((long) 1);
       loop_2901:
	 {
	    bool_t test2342_2902;
	    test2342_2902 = (i_2900 == ((long) -1));
	    if (test2342_2902)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2343_2903;
		    {
		       obj_t list2344_2904;
		       {
			  obj_t arg2345_2905;
			  arg2345_2905 = BNIL;
			  list2344_2904 = MAKE_PAIR(cnst_port_138_2899, arg2345_2905);
		       }
		       arg2343_2903 = read___reader(list2344_2904);
		    }
		    CNST_TABLE_SET(i_2900, arg2343_2903);
		 }
		 {
		    int aux_2906;
		    {
		       long aux_2926;
		       aux_2926 = (i_2900 - ((long) 1));
		       aux_2906 = (int) (aux_2926);
		    }
		    {
		       long i_2929;
		       i_2929 = (long) (aux_2906);
		       i_2900 = i_2929;
		       goto loop_2901;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cgen_capp()
{
   return BUNSPEC;
}


/* node-sfun-non-tail-app->cop */ obj_t 
node_sfun_non_tail_app__cop_176_cgen_capp(variable_t var_10, app_t node_11, obj_t kont_12)
{
   {
      obj_t args_994;
      {
	 sfun_t obj_1976;
	 {
	    value_t aux_2931;
	    aux_2931 = (((variable_t) CREF(var_10))->value);
	    obj_1976 = (sfun_t) (aux_2931);
	 }
	 args_994 = (((sfun_t) CREF(obj_1976))->args);
      }
      {
	 obj_t args_type_205_995;
	 {
	    bool_t test1781_1064;
	    test1781_1064 = NULLP(args_994);
	    if (test1781_1064)
	      {
		 args_type_205_995 = BNIL;
	      }
	    else
	      {
		 bool_t test1782_1065;
		 test1782_1065 = is_a__118___object(CAR(args_994), local_ast_var);
		 if (test1782_1065)
		   {
		      if (test1781_1064)
			{
			   args_type_205_995 = BNIL;
			}
		      else
			{
			   obj_t head1675_1068;
			   {
			      obj_t aux_2941;
			      {
				 type_t aux_2942;
				 {
				    local_t obj_1982;
				    {
				       obj_t aux_2943;
				       aux_2943 = CAR(args_994);
				       obj_1982 = (local_t) (aux_2943);
				    }
				    aux_2942 = (((local_t) CREF(obj_1982))->type);
				 }
				 aux_2941 = (obj_t) (aux_2942);
			      }
			      head1675_1068 = MAKE_PAIR(aux_2941, BNIL);
			   }
			   {
			      obj_t l1673_1069;
			      obj_t tail1676_1070;
			      l1673_1069 = CDR(args_994);
			      tail1676_1070 = head1675_1068;
			    lname1674_1071:
			      if (NULLP(l1673_1069))
				{
				   args_type_205_995 = head1675_1068;
				}
			      else
				{
				   obj_t newtail1677_1074;
				   {
				      obj_t aux_2951;
				      {
					 type_t aux_2952;
					 {
					    local_t obj_1988;
					    {
					       obj_t aux_2953;
					       aux_2953 = CAR(l1673_1069);
					       obj_1988 = (local_t) (aux_2953);
					    }
					    aux_2952 = (((local_t) CREF(obj_1988))->type);
					 }
					 aux_2951 = (obj_t) (aux_2952);
				      }
				      newtail1677_1074 = MAKE_PAIR(aux_2951, BNIL);
				   }
				   SET_CDR(tail1676_1070, newtail1677_1074);
				   {
				      obj_t tail1676_2962;
				      obj_t l1673_2960;
				      l1673_2960 = CDR(l1673_1069);
				      tail1676_2962 = newtail1677_1074;
				      tail1676_1070 = tail1676_2962;
				      l1673_1069 = l1673_2960;
				      goto lname1674_1071;
				   }
				}
			   }
			}
		   }
		 else
		   {
		      args_type_205_995 = args_994;
		   }
	      }
	 }
	 {
	    cop_t cop_1057;
	    local_t aux_1058;
	    {
	       {
		  obj_t old_actuals_174_997;
		  obj_t args_type_205_998;
		  obj_t new_actuals_73_999;
		  local_t aux_1000;
		  obj_t auxs_1001;
		  obj_t exps_1002;
		  {
		     obj_t arg1710_1004;
		     local_t arg1712_1006;
		     arg1710_1004 = (((app_t) CREF(node_11))->args);
		     arg1712_1006 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
		     old_actuals_174_997 = arg1710_1004;
		     args_type_205_998 = args_type_205_995;
		     new_actuals_73_999 = BNIL;
		     aux_1000 = arg1712_1006;
		     auxs_1001 = BNIL;
		     exps_1002 = BNIL;
		   loop_1003:
		     if (NULLP(old_actuals_174_997))
		       {
			  if (NULLP(auxs_1001))
			    {
			       capp_t arg1720_1012;
			       {
				  obj_t arg1721_1013;
				  cop_t arg1722_1014;
				  obj_t arg1723_1015;
				  {
				     node_t obj_1997;
				     obj_1997 = (node_t) (node_11);
				     arg1721_1013 = (((node_t) CREF(obj_1997))->loc);
				  }
				  {
				     node_t aux_2974;
				     {
					var_t aux_2975;
					aux_2975 = (((app_t) CREF(node_11))->fun);
					aux_2974 = (node_t) (aux_2975);
				     }
				     arg1722_1014 = node__cop_142_cgen_cgen(aux_2974, _id_kont__126_cgen_cgen);
				  }
				  arg1723_1015 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_999);
				  {
				     capp_t res2280_2009;
				     {
					capp_t new1555_2002;
					new1555_2002 = ((capp_t) BREF(GC_MALLOC(sizeof(struct capp))));
					{
					   long arg1963_2003;
					   arg1963_2003 = class_num_218___object(capp_cgen_cop);
					   {
					      obj_t obj_2007;
					      obj_2007 = (obj_t) (new1555_2002);
					      (((obj_t) CREF(obj_2007))->header = MAKE_HEADER(arg1963_2003, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_2984;
					   aux_2984 = (object_t) (new1555_2002);
					   OBJECT_WIDENING_SET(aux_2984, BFALSE);
					}
					((((capp_t) CREF(new1555_2002))->loc) = ((obj_t) arg1721_1013), BUNSPEC);
					((((capp_t) CREF(new1555_2002))->fun) = ((cop_t) arg1722_1014), BUNSPEC);
					((((capp_t) CREF(new1555_2002))->args) = ((obj_t) arg1723_1015), BUNSPEC);
					res2280_2009 = new1555_2002;
				     }
				     arg1720_1012 = res2280_2009;
				  }
			       }
			       return PROCEDURE_ENTRY(kont_12) (kont_12, (obj_t) (arg1720_1012), BEOA);
			    }
			  else
			    {
			       obj_t loc_1017;
			       loc_1017 = (((app_t) CREF(node_11))->loc);
			       {
				  csequence_t arg1726_1019;
				  {
				     obj_t arg1727_1020;
				     {
					local_var_164_t arg1728_1021;
					csequence_t arg1729_1022;
					obj_t arg1730_1023;
					{
					   local_var_164_t res2281_2019;
					   {
					      local_var_164_t new1534_2013;
					      new1534_2013 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
					      {
						 long arg1972_2014;
						 arg1972_2014 = class_num_218___object(local_var_164_cgen_cop);
						 {
						    obj_t obj_2017;
						    obj_2017 = (obj_t) (new1534_2013);
						    (((obj_t) CREF(obj_2017))->header = MAKE_HEADER(arg1972_2014, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_2998;
						 aux_2998 = (object_t) (new1534_2013);
						 OBJECT_WIDENING_SET(aux_2998, BFALSE);
					      }
					      ((((local_var_164_t) CREF(new1534_2013))->loc) = ((obj_t) loc_1017), BUNSPEC);
					      ((((local_var_164_t) CREF(new1534_2013))->vars) = ((obj_t) auxs_1001), BUNSPEC);
					      res2281_2019 = new1534_2013;
					   }
					   arg1728_1021 = res2281_2019;
					}
					{
					   csequence_t res2282_2030;
					   {
					      obj_t loc_2020;
					      loc_2020 = BFALSE;
					      {
						 csequence_t new1501_2023;
						 new1501_2023 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						 {
						    long arg1983_2024;
						    arg1983_2024 = class_num_218___object(csequence_cgen_cop);
						    {
						       obj_t obj_2028;
						       obj_2028 = (obj_t) (new1501_2023);
						       (((obj_t) CREF(obj_2028))->header = MAKE_HEADER(arg1983_2024, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_3007;
						    aux_3007 = (object_t) (new1501_2023);
						    OBJECT_WIDENING_SET(aux_3007, loc_2020);
						 }
						 ((((csequence_t) CREF(new1501_2023))->loc) = ((obj_t) loc_2020), BUNSPEC);
						 ((((csequence_t) CREF(new1501_2023))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						 ((((csequence_t) CREF(new1501_2023))->cops) = ((obj_t) exps_1002), BUNSPEC);
						 res2282_2030 = new1501_2023;
					      }
					   }
					   arg1729_1022 = res2282_2030;
					}
					{
					   capp_t arg1744_1031;
					   {
					      cop_t arg1746_1033;
					      obj_t arg1747_1034;
					      {
						 node_t aux_3013;
						 {
						    var_t aux_3014;
						    aux_3014 = (((app_t) CREF(node_11))->fun);
						    aux_3013 = (node_t) (aux_3014);
						 }
						 arg1746_1033 = node__cop_142_cgen_cgen(aux_3013, _id_kont__126_cgen_cgen);
					      }
					      arg1747_1034 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_999);
					      {
						 capp_t res2283_2042;
						 {
						    capp_t new1555_2035;
						    new1555_2035 = ((capp_t) BREF(GC_MALLOC(sizeof(struct capp))));
						    {
						       long arg1963_2036;
						       arg1963_2036 = class_num_218___object(capp_cgen_cop);
						       {
							  obj_t obj_2040;
							  obj_2040 = (obj_t) (new1555_2035);
							  (((obj_t) CREF(obj_2040))->header = MAKE_HEADER(arg1963_2036, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3023;
						       aux_3023 = (object_t) (new1555_2035);
						       OBJECT_WIDENING_SET(aux_3023, BFALSE);
						    }
						    ((((capp_t) CREF(new1555_2035))->loc) = ((obj_t) loc_1017), BUNSPEC);
						    ((((capp_t) CREF(new1555_2035))->fun) = ((cop_t) arg1746_1033), BUNSPEC);
						    ((((capp_t) CREF(new1555_2035))->args) = ((obj_t) arg1747_1034), BUNSPEC);
						    res2283_2042 = new1555_2035;
						 }
						 arg1744_1031 = res2283_2042;
					      }
					   }
					   arg1730_1023 = PROCEDURE_ENTRY(kont_12) (kont_12, (obj_t) (arg1744_1031), BEOA);
					}
					{
					   obj_t list1731_1024;
					   {
					      obj_t arg1732_1025;
					      {
						 obj_t arg1733_1026;
						 arg1733_1026 = MAKE_PAIR(arg1730_1023, BNIL);
						 {
						    obj_t aux_3033;
						    aux_3033 = (obj_t) (arg1729_1022);
						    arg1732_1025 = MAKE_PAIR(aux_3033, arg1733_1026);
						 }
					      }
					      {
						 obj_t aux_3036;
						 aux_3036 = (obj_t) (arg1728_1021);
						 list1731_1024 = MAKE_PAIR(aux_3036, arg1732_1025);
					      }
					   }
					   arg1727_1020 = list1731_1024;
					}
				     }
				     {
					csequence_t res2284_2054;
					{
					   obj_t loc_2044;
					   loc_2044 = BFALSE;
					   {
					      csequence_t new1501_2047;
					      new1501_2047 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					      {
						 long arg1983_2048;
						 arg1983_2048 = class_num_218___object(csequence_cgen_cop);
						 {
						    obj_t obj_2052;
						    obj_2052 = (obj_t) (new1501_2047);
						    (((obj_t) CREF(obj_2052))->header = MAKE_HEADER(arg1983_2048, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_3043;
						 aux_3043 = (object_t) (new1501_2047);
						 OBJECT_WIDENING_SET(aux_3043, loc_2044);
					      }
					      ((((csequence_t) CREF(new1501_2047))->loc) = ((obj_t) loc_2044), BUNSPEC);
					      ((((csequence_t) CREF(new1501_2047))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					      ((((csequence_t) CREF(new1501_2047))->cops) = ((obj_t) arg1727_1020), BUNSPEC);
					      res2284_2054 = new1501_2047;
					   }
					}
					arg1726_1019 = res2284_2054;
				     }
				  }
				  {
				     block_t res2285_2063;
				     {
					cop_t body_2056;
					body_2056 = (cop_t) (arg1726_1019);
					{
					   block_t new1457_2057;
					   new1457_2057 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
					   {
					      long arg2000_2058;
					      arg2000_2058 = class_num_218___object(block_cgen_cop);
					      {
						 obj_t obj_2061;
						 obj_2061 = (obj_t) (new1457_2057);
						 (((obj_t) CREF(obj_2061))->header = MAKE_HEADER(arg2000_2058, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3054;
					      aux_3054 = (object_t) (new1457_2057);
					      OBJECT_WIDENING_SET(aux_3054, BFALSE);
					   }
					   ((((block_t) CREF(new1457_2057))->loc) = ((obj_t) loc_1017), BUNSPEC);
					   ((((block_t) CREF(new1457_2057))->body) = ((cop_t) body_2056), BUNSPEC);
					   res2285_2063 = new1457_2057;
					}
				     }
				     return (obj_t) (res2285_2063);
				  }
			       }
			    }
		       }
		     else
		       {
			  cop_t cop_1036;
			  {
			     setq_t arg1776_1055;
			     {
				node_t aux_3060;
				{
				   obj_t aux_3062;
				   aux_3062 = CAR(old_actuals_174_997);
				   aux_3060 = (node_t) (aux_3062);
				}
				arg1776_1055 = node_setq_243_cgen_cgen((variable_t) (aux_1000), aux_3060);
			     }
			     cop_1036 = node__cop_142_cgen_cgen((node_t) (arg1776_1055), _id_kont__126_cgen_cgen);
			  }
			  {
			     bool_t test_3068;
			     cop_1057 = cop_1036;
			     aux_1058 = aux_1000;
			     {
				bool_t _andtest_1678_1060;
				_andtest_1678_1060 = is_a__118___object((obj_t) (cop_1057), csetq_cgen_cop);
				if (_andtest_1678_1060)
				  {
				     obj_t aux_3078;
				     obj_t aux_3072;
				     aux_3078 = (obj_t) (aux_1058);
				     {
					variable_t aux_3073;
					{
					   varc_t arg1780_1062;
					   {
					      csetq_t obj_2094;
					      obj_2094 = (csetq_t) (cop_1057);
					      arg1780_1062 = (((csetq_t) CREF(obj_2094))->var);
					   }
					   aux_3073 = (((varc_t) CREF(arg1780_1062))->variable);
					}
					aux_3072 = (obj_t) (aux_3073);
				     }
				     test_3068 = (aux_3072 == aux_3078);
				  }
				else
				  {
				     test_3068 = ((bool_t) 0);
				  }
			     }
			     if (test_3068)
			       {
				  obj_t arg1753_1038;
				  obj_t arg1755_1039;
				  obj_t arg1758_1040;
				  arg1753_1038 = CDR(old_actuals_174_997);
				  arg1755_1039 = CDR(args_type_205_998);
				  {
				     obj_t aux_3083;
				     {
					cop_t aux_3084;
					{
					   csetq_t obj_2067;
					   obj_2067 = (csetq_t) (cop_1036);
					   aux_3084 = (((csetq_t) CREF(obj_2067))->value);
					}
					aux_3083 = (obj_t) (aux_3084);
				     }
				     arg1758_1040 = MAKE_PAIR(aux_3083, new_actuals_73_999);
				  }
				  {
				     obj_t new_actuals_73_3091;
				     obj_t args_type_205_3090;
				     obj_t old_actuals_174_3089;
				     old_actuals_174_3089 = arg1753_1038;
				     args_type_205_3090 = arg1755_1039;
				     new_actuals_73_3091 = arg1758_1040;
				     new_actuals_73_999 = new_actuals_73_3091;
				     args_type_205_998 = args_type_205_3090;
				     old_actuals_174_997 = old_actuals_174_3089;
				     goto loop_1003;
				  }
			       }
			     else
			       {
				  {
				     type_t val1093_2072;
				     {
					obj_t aux_3092;
					aux_3092 = CAR(args_type_205_998);
					val1093_2072 = (type_t) (aux_3092);
				     }
				     ((((local_t) CREF(aux_1000))->type) = ((type_t) val1093_2072), BUNSPEC);
				  }
				  {
				     obj_t arg1761_1043;
				     obj_t arg1762_1044;
				     obj_t arg1765_1045;
				     local_t arg1766_1046;
				     obj_t arg1767_1047;
				     obj_t arg1768_1048;
				     arg1761_1043 = CDR(old_actuals_174_997);
				     arg1762_1044 = CDR(args_type_205_998);
				     {
					varc_t arg1769_1049;
					{
					   obj_t arg1770_1050;
					   {
					      node_t obj_2076;
					      {
						 obj_t aux_3098;
						 aux_3098 = CAR(old_actuals_174_997);
						 obj_2076 = (node_t) (aux_3098);
					      }
					      arg1770_1050 = (((node_t) CREF(obj_2076))->loc);
					   }
					   {
					      varc_t res2286_2085;
					      {
						 variable_t variable_2078;
						 variable_2078 = (variable_t) (aux_1000);
						 {
						    varc_t new1481_2079;
						    new1481_2079 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
						    {
						       long arg1989_2080;
						       arg1989_2080 = class_num_218___object(varc_cgen_cop);
						       {
							  obj_t obj_2083;
							  obj_2083 = (obj_t) (new1481_2079);
							  (((obj_t) CREF(obj_2083))->header = MAKE_HEADER(arg1989_2080, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3107;
						       aux_3107 = (object_t) (new1481_2079);
						       OBJECT_WIDENING_SET(aux_3107, BFALSE);
						    }
						    ((((varc_t) CREF(new1481_2079))->loc) = ((obj_t) arg1770_1050), BUNSPEC);
						    ((((varc_t) CREF(new1481_2079))->variable) = ((variable_t) variable_2078), BUNSPEC);
						    res2286_2085 = new1481_2079;
						 }
					      }
					      arg1769_1049 = res2286_2085;
					   }
					}
					{
					   obj_t aux_3112;
					   aux_3112 = (obj_t) (arg1769_1049);
					   arg1765_1045 = MAKE_PAIR(aux_3112, new_actuals_73_999);
					}
				     }
				     {
					type_t aux_3115;
					{
					   obj_t aux_3117;
					   aux_3117 = CAR(args_type_205_998);
					   aux_3115 = (type_t) (aux_3117);
					}
					arg1766_1046 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), aux_3115);
				     }
				     {
					obj_t aux_3121;
					aux_3121 = (obj_t) (aux_1000);
					arg1767_1047 = MAKE_PAIR(aux_3121, auxs_1001);
				     }
				     {
					obj_t aux_3124;
					aux_3124 = (obj_t) (cop_1036);
					arg1768_1048 = MAKE_PAIR(aux_3124, exps_1002);
				     }
				     {
					obj_t exps_3132;
					obj_t auxs_3131;
					local_t aux_3130;
					obj_t new_actuals_73_3129;
					obj_t args_type_205_3128;
					obj_t old_actuals_174_3127;
					old_actuals_174_3127 = arg1761_1043;
					args_type_205_3128 = arg1762_1044;
					new_actuals_73_3129 = arg1765_1045;
					aux_3130 = arg1766_1046;
					auxs_3131 = arg1767_1047;
					exps_3132 = arg1768_1048;
					exps_1002 = exps_3132;
					auxs_1001 = auxs_3131;
					aux_1000 = aux_3130;
					new_actuals_73_999 = new_actuals_73_3129;
					args_type_205_998 = args_type_205_3128;
					old_actuals_174_997 = old_actuals_174_3127;
					goto loop_1003;
				     }
				  }
			       }
			  }
		       }
		  }
	       }
	    }
	 }
      }
   }
}


/* node-cfun-non-tail-app->cop */ obj_t 
node_cfun_non_tail_app__cop_38_cgen_capp(variable_t var_13, app_t node_14, obj_t kont_15)
{
   {
      obj_t args_type_205_1084;
      {
	 cfun_t obj_2099;
	 {
	    value_t aux_3133;
	    aux_3133 = (((variable_t) CREF(var_13))->value);
	    obj_2099 = (cfun_t) (aux_3133);
	 }
	 args_type_205_1084 = (((cfun_t) CREF(obj_2099))->args_type_205);
      }
      {
	 cop_t cop_1151;
	 local_t aux_1152;
	 {
	    obj_t old_actuals_174_1086;
	    obj_t args_type_205_1087;
	    obj_t new_actuals_73_1088;
	    local_t aux_1089;
	    obj_t auxs_1090;
	    obj_t exps_1091;
	    {
	       obj_t arg1797_1093;
	       local_t arg1800_1095;
	       arg1797_1093 = (((app_t) CREF(node_14))->args);
	       arg1800_1095 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
	       old_actuals_174_1086 = arg1797_1093;
	       args_type_205_1087 = args_type_205_1084;
	       new_actuals_73_1088 = BNIL;
	       aux_1089 = arg1800_1095;
	       auxs_1090 = BNIL;
	       exps_1091 = BNIL;
	     loop_1092:
	       if (NULLP(old_actuals_174_1086))
		 {
		    if (NULLP(auxs_1090))
		      {
			 capp_t arg1807_1101;
			 {
			    obj_t arg1808_1102;
			    cop_t arg1809_1103;
			    obj_t arg1810_1104;
			    {
			       node_t obj_2103;
			       obj_2103 = (node_t) (node_14);
			       arg1808_1102 = (((node_t) CREF(obj_2103))->loc);
			    }
			    {
			       node_t aux_3147;
			       {
				  var_t aux_3148;
				  aux_3148 = (((app_t) CREF(node_14))->fun);
				  aux_3147 = (node_t) (aux_3148);
			       }
			       arg1809_1103 = node__cop_142_cgen_cgen(aux_3147, _id_kont__126_cgen_cgen);
			    }
			    arg1810_1104 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1088);
			    {
			       capp_t res2287_2115;
			       {
				  capp_t new1555_2108;
				  new1555_2108 = ((capp_t) BREF(GC_MALLOC(sizeof(struct capp))));
				  {
				     long arg1963_2109;
				     arg1963_2109 = class_num_218___object(capp_cgen_cop);
				     {
					obj_t obj_2113;
					obj_2113 = (obj_t) (new1555_2108);
					(((obj_t) CREF(obj_2113))->header = MAKE_HEADER(arg1963_2109, 0), BUNSPEC);
				     }
				  }
				  {
				     object_t aux_3157;
				     aux_3157 = (object_t) (new1555_2108);
				     OBJECT_WIDENING_SET(aux_3157, BFALSE);
				  }
				  ((((capp_t) CREF(new1555_2108))->loc) = ((obj_t) arg1808_1102), BUNSPEC);
				  ((((capp_t) CREF(new1555_2108))->fun) = ((cop_t) arg1809_1103), BUNSPEC);
				  ((((capp_t) CREF(new1555_2108))->args) = ((obj_t) arg1810_1104), BUNSPEC);
				  res2287_2115 = new1555_2108;
			       }
			       arg1807_1101 = res2287_2115;
			    }
			 }
			 return PROCEDURE_ENTRY(kont_15) (kont_15, (obj_t) (arg1807_1101), BEOA);
		      }
		    else
		      {
			 obj_t loc_1106;
			 loc_1106 = (((app_t) CREF(node_14))->loc);
			 {
			    csequence_t arg1813_1108;
			    {
			       obj_t arg1814_1109;
			       {
				  local_var_164_t arg1815_1110;
				  csequence_t arg1816_1111;
				  obj_t arg1817_1112;
				  {
				     local_var_164_t res2288_2125;
				     {
					local_var_164_t new1534_2119;
					new1534_2119 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
					{
					   long arg1972_2120;
					   arg1972_2120 = class_num_218___object(local_var_164_cgen_cop);
					   {
					      obj_t obj_2123;
					      obj_2123 = (obj_t) (new1534_2119);
					      (((obj_t) CREF(obj_2123))->header = MAKE_HEADER(arg1972_2120, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3171;
					   aux_3171 = (object_t) (new1534_2119);
					   OBJECT_WIDENING_SET(aux_3171, BFALSE);
					}
					((((local_var_164_t) CREF(new1534_2119))->loc) = ((obj_t) loc_1106), BUNSPEC);
					((((local_var_164_t) CREF(new1534_2119))->vars) = ((obj_t) auxs_1090), BUNSPEC);
					res2288_2125 = new1534_2119;
				     }
				     arg1815_1110 = res2288_2125;
				  }
				  {
				     csequence_t res2289_2136;
				     {
					obj_t loc_2126;
					loc_2126 = BFALSE;
					{
					   csequence_t new1501_2129;
					   new1501_2129 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					   {
					      long arg1983_2130;
					      arg1983_2130 = class_num_218___object(csequence_cgen_cop);
					      {
						 obj_t obj_2134;
						 obj_2134 = (obj_t) (new1501_2129);
						 (((obj_t) CREF(obj_2134))->header = MAKE_HEADER(arg1983_2130, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3180;
					      aux_3180 = (object_t) (new1501_2129);
					      OBJECT_WIDENING_SET(aux_3180, loc_2126);
					   }
					   ((((csequence_t) CREF(new1501_2129))->loc) = ((obj_t) loc_2126), BUNSPEC);
					   ((((csequence_t) CREF(new1501_2129))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					   ((((csequence_t) CREF(new1501_2129))->cops) = ((obj_t) exps_1091), BUNSPEC);
					   res2289_2136 = new1501_2129;
					}
				     }
				     arg1816_1111 = res2289_2136;
				  }
				  {
				     capp_t arg1827_1120;
				     {
					cop_t arg1830_1122;
					obj_t arg1831_1123;
					{
					   node_t aux_3186;
					   {
					      var_t aux_3187;
					      aux_3187 = (((app_t) CREF(node_14))->fun);
					      aux_3186 = (node_t) (aux_3187);
					   }
					   arg1830_1122 = node__cop_142_cgen_cgen(aux_3186, _id_kont__126_cgen_cgen);
					}
					arg1831_1123 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1088);
					{
					   capp_t res2290_2148;
					   {
					      capp_t new1555_2141;
					      new1555_2141 = ((capp_t) BREF(GC_MALLOC(sizeof(struct capp))));
					      {
						 long arg1963_2142;
						 arg1963_2142 = class_num_218___object(capp_cgen_cop);
						 {
						    obj_t obj_2146;
						    obj_2146 = (obj_t) (new1555_2141);
						    (((obj_t) CREF(obj_2146))->header = MAKE_HEADER(arg1963_2142, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_3196;
						 aux_3196 = (object_t) (new1555_2141);
						 OBJECT_WIDENING_SET(aux_3196, BFALSE);
					      }
					      ((((capp_t) CREF(new1555_2141))->loc) = ((obj_t) loc_1106), BUNSPEC);
					      ((((capp_t) CREF(new1555_2141))->fun) = ((cop_t) arg1830_1122), BUNSPEC);
					      ((((capp_t) CREF(new1555_2141))->args) = ((obj_t) arg1831_1123), BUNSPEC);
					      res2290_2148 = new1555_2141;
					   }
					   arg1827_1120 = res2290_2148;
					}
				     }
				     arg1817_1112 = PROCEDURE_ENTRY(kont_15) (kont_15, (obj_t) (arg1827_1120), BEOA);
				  }
				  {
				     obj_t list1818_1113;
				     {
					obj_t arg1820_1114;
					{
					   obj_t arg1821_1115;
					   arg1821_1115 = MAKE_PAIR(arg1817_1112, BNIL);
					   {
					      obj_t aux_3206;
					      aux_3206 = (obj_t) (arg1816_1111);
					      arg1820_1114 = MAKE_PAIR(aux_3206, arg1821_1115);
					   }
					}
					{
					   obj_t aux_3209;
					   aux_3209 = (obj_t) (arg1815_1110);
					   list1818_1113 = MAKE_PAIR(aux_3209, arg1820_1114);
					}
				     }
				     arg1814_1109 = list1818_1113;
				  }
			       }
			       {
				  csequence_t res2291_2160;
				  {
				     obj_t loc_2150;
				     loc_2150 = BFALSE;
				     {
					csequence_t new1501_2153;
					new1501_2153 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					{
					   long arg1983_2154;
					   arg1983_2154 = class_num_218___object(csequence_cgen_cop);
					   {
					      obj_t obj_2158;
					      obj_2158 = (obj_t) (new1501_2153);
					      (((obj_t) CREF(obj_2158))->header = MAKE_HEADER(arg1983_2154, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3216;
					   aux_3216 = (object_t) (new1501_2153);
					   OBJECT_WIDENING_SET(aux_3216, loc_2150);
					}
					((((csequence_t) CREF(new1501_2153))->loc) = ((obj_t) loc_2150), BUNSPEC);
					((((csequence_t) CREF(new1501_2153))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					((((csequence_t) CREF(new1501_2153))->cops) = ((obj_t) arg1814_1109), BUNSPEC);
					res2291_2160 = new1501_2153;
				     }
				  }
				  arg1813_1108 = res2291_2160;
			       }
			    }
			    {
			       block_t res2292_2169;
			       {
				  cop_t body_2162;
				  body_2162 = (cop_t) (arg1813_1108);
				  {
				     block_t new1457_2163;
				     new1457_2163 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
				     {
					long arg2000_2164;
					arg2000_2164 = class_num_218___object(block_cgen_cop);
					{
					   obj_t obj_2167;
					   obj_2167 = (obj_t) (new1457_2163);
					   (((obj_t) CREF(obj_2167))->header = MAKE_HEADER(arg2000_2164, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_3227;
					aux_3227 = (object_t) (new1457_2163);
					OBJECT_WIDENING_SET(aux_3227, BFALSE);
				     }
				     ((((block_t) CREF(new1457_2163))->loc) = ((obj_t) loc_1106), BUNSPEC);
				     ((((block_t) CREF(new1457_2163))->body) = ((cop_t) body_2162), BUNSPEC);
				     res2292_2169 = new1457_2163;
				  }
			       }
			       return (obj_t) (res2292_2169);
			    }
			 }
		      }
		 }
	       else
		 {
		    cop_t cop_1125;
		    {
		       setq_t arg1863_1148;
		       {
			  node_t aux_3233;
			  {
			     obj_t aux_3235;
			     aux_3235 = CAR(old_actuals_174_1086);
			     aux_3233 = (node_t) (aux_3235);
			  }
			  arg1863_1148 = node_setq_243_cgen_cgen((variable_t) (aux_1089), aux_3233);
		       }
		       cop_1125 = node__cop_142_cgen_cgen((node_t) (arg1863_1148), _id_kont__126_cgen_cgen);
		    }
		    {
		       bool_t test_3241;
		       cop_1151 = cop_1125;
		       aux_1152 = aux_1089;
		       {
			  bool_t _andtest_1686_1154;
			  _andtest_1686_1154 = is_a__118___object((obj_t) (cop_1151), csetq_cgen_cop);
			  if (_andtest_1686_1154)
			    {
			       bool_t test_3245;
			       {
				  obj_t aux_3252;
				  obj_t aux_3246;
				  aux_3252 = (obj_t) (aux_1152);
				  {
				     variable_t aux_3247;
				     {
					varc_t arg1870_1160;
					{
					   csetq_t obj_2204;
					   obj_2204 = (csetq_t) (cop_1151);
					   arg1870_1160 = (((csetq_t) CREF(obj_2204))->var);
					}
					aux_3247 = (((varc_t) CREF(arg1870_1160))->variable);
				     }
				     aux_3246 = (obj_t) (aux_3247);
				  }
				  test_3245 = (aux_3246 == aux_3252);
			       }
			       if (test_3245)
				 {
				    bool_t _ortest_1688_1156;
				    {
				       obj_t aux_3255;
				       {
					  cop_t aux_3256;
					  {
					     csetq_t obj_2208;
					     obj_2208 = (csetq_t) (cop_1151);
					     aux_3256 = (((csetq_t) CREF(obj_2208))->value);
					  }
					  aux_3255 = (obj_t) (aux_3256);
				       }
				       _ortest_1688_1156 = is_a__118___object(aux_3255, catom_cgen_cop);
				    }
				    if (_ortest_1688_1156)
				      {
					 test_3241 = _ortest_1688_1156;
				      }
				    else
				      {
					 obj_t aux_3262;
					 {
					    cop_t aux_3263;
					    {
					       csetq_t obj_2210;
					       obj_2210 = (csetq_t) (cop_1151);
					       aux_3263 = (((csetq_t) CREF(obj_2210))->value);
					    }
					    aux_3262 = (obj_t) (aux_3263);
					 }
					 test_3241 = is_a__118___object(aux_3262, varc_cgen_cop);
				      }
				 }
			       else
				 {
				    test_3241 = ((bool_t) 0);
				 }
			    }
			  else
			    {
			       test_3241 = ((bool_t) 0);
			    }
		       }
		       if (test_3241)
			 {
			    obj_t arg1834_1127;
			    obj_t arg1835_1128;
			    obj_t arg1836_1129;
			    arg1834_1127 = CDR(old_actuals_174_1086);
			    {
			       bool_t test_3269;
			       {
				  obj_t aux_3270;
				  aux_3270 = CDR(args_type_205_1087);
				  test_3269 = NULLP(aux_3270);
			       }
			       if (test_3269)
				 {
				    arg1835_1128 = args_type_205_1087;
				 }
			       else
				 {
				    arg1835_1128 = CDR(args_type_205_1087);
				 }
			    }
			    {
			       obj_t aux_3274;
			       {
				  cop_t aux_3275;
				  {
				     csetq_t obj_2175;
				     obj_2175 = (csetq_t) (cop_1125);
				     aux_3275 = (((csetq_t) CREF(obj_2175))->value);
				  }
				  aux_3274 = (obj_t) (aux_3275);
			       }
			       arg1836_1129 = MAKE_PAIR(aux_3274, new_actuals_73_1088);
			    }
			    {
			       obj_t new_actuals_73_3282;
			       obj_t args_type_205_3281;
			       obj_t old_actuals_174_3280;
			       old_actuals_174_3280 = arg1834_1127;
			       args_type_205_3281 = arg1835_1128;
			       new_actuals_73_3282 = arg1836_1129;
			       new_actuals_73_1088 = new_actuals_73_3282;
			       args_type_205_1087 = args_type_205_3281;
			       old_actuals_174_1086 = old_actuals_174_3280;
			       goto loop_1092;
			    }
			 }
		       else
			 {
			    {
			       type_t val1093_2180;
			       {
				  obj_t aux_3283;
				  aux_3283 = CAR(args_type_205_1087);
				  val1093_2180 = (type_t) (aux_3283);
			       }
			       ((((local_t) CREF(aux_1089))->type) = ((type_t) val1093_2180), BUNSPEC);
			    }
			    {
			       obj_t arg1843_1134;
			       obj_t arg1847_1135;
			       obj_t arg1848_1136;
			       local_t arg1850_1137;
			       obj_t arg1851_1138;
			       obj_t arg1852_1139;
			       arg1843_1134 = CDR(old_actuals_174_1086);
			       {
				  bool_t test_3288;
				  {
				     obj_t aux_3289;
				     aux_3289 = CDR(args_type_205_1087);
				     test_3288 = NULLP(aux_3289);
				  }
				  if (test_3288)
				    {
				       arg1847_1135 = args_type_205_1087;
				    }
				  else
				    {
				       arg1847_1135 = CDR(args_type_205_1087);
				    }
			       }
			       {
				  varc_t arg1857_1142;
				  {
				     obj_t arg1858_1143;
				     {
					node_t obj_2186;
					{
					   obj_t aux_3293;
					   aux_3293 = CAR(old_actuals_174_1086);
					   obj_2186 = (node_t) (aux_3293);
					}
					arg1858_1143 = (((node_t) CREF(obj_2186))->loc);
				     }
				     {
					varc_t res2293_2195;
					{
					   variable_t variable_2188;
					   variable_2188 = (variable_t) (aux_1089);
					   {
					      varc_t new1481_2189;
					      new1481_2189 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
					      {
						 long arg1989_2190;
						 arg1989_2190 = class_num_218___object(varc_cgen_cop);
						 {
						    obj_t obj_2193;
						    obj_2193 = (obj_t) (new1481_2189);
						    (((obj_t) CREF(obj_2193))->header = MAKE_HEADER(arg1989_2190, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_3302;
						 aux_3302 = (object_t) (new1481_2189);
						 OBJECT_WIDENING_SET(aux_3302, BFALSE);
					      }
					      ((((varc_t) CREF(new1481_2189))->loc) = ((obj_t) arg1858_1143), BUNSPEC);
					      ((((varc_t) CREF(new1481_2189))->variable) = ((variable_t) variable_2188), BUNSPEC);
					      res2293_2195 = new1481_2189;
					   }
					}
					arg1857_1142 = res2293_2195;
				     }
				  }
				  {
				     obj_t aux_3307;
				     aux_3307 = (obj_t) (arg1857_1142);
				     arg1848_1136 = MAKE_PAIR(aux_3307, new_actuals_73_1088);
				  }
			       }
			       {
				  type_t aux_3310;
				  {
				     obj_t aux_3312;
				     aux_3312 = CAR(args_type_205_1087);
				     aux_3310 = (type_t) (aux_3312);
				  }
				  arg1850_1137 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), aux_3310);
			       }
			       {
				  obj_t aux_3316;
				  aux_3316 = (obj_t) (aux_1089);
				  arg1851_1138 = MAKE_PAIR(aux_3316, auxs_1090);
			       }
			       {
				  obj_t aux_3319;
				  aux_3319 = (obj_t) (cop_1125);
				  arg1852_1139 = MAKE_PAIR(aux_3319, exps_1091);
			       }
			       {
				  obj_t exps_3327;
				  obj_t auxs_3326;
				  local_t aux_3325;
				  obj_t new_actuals_73_3324;
				  obj_t args_type_205_3323;
				  obj_t old_actuals_174_3322;
				  old_actuals_174_3322 = arg1843_1134;
				  args_type_205_3323 = arg1847_1135;
				  new_actuals_73_3324 = arg1848_1136;
				  aux_3325 = arg1850_1137;
				  auxs_3326 = arg1851_1138;
				  exps_3327 = arg1852_1139;
				  exps_1091 = exps_3327;
				  auxs_1090 = auxs_3326;
				  aux_1089 = aux_3325;
				  new_actuals_73_1088 = new_actuals_73_3324;
				  args_type_205_1087 = args_type_205_3323;
				  old_actuals_174_1086 = old_actuals_174_3322;
				  goto loop_1092;
			       }
			    }
			 }
		    }
		 }
	    }
	 }
      }
   }
}


/* node-tail-app->cop */ obj_t 
node_tail_app__cop_48_cgen_capp(variable_t var_16, app_t node_17, obj_t kont_18)
{
   {
      clabel_t label_1162;
      obj_t args_1163;
      obj_t loc_1164;
      {
	 sfun_c_188_t obj_2213;
	 {
	    value_t aux_3328;
	    aux_3328 = (((variable_t) CREF(var_16))->value);
	    obj_2213 = (sfun_c_188_t) (aux_3328);
	 }
	 {
	    obj_t aux_3331;
	    {
	       object_t aux_3332;
	       aux_3332 = (object_t) (obj_2213);
	       aux_3331 = OBJECT_WIDENING(aux_3332);
	    }
	    label_1162 = (((sfun_c_188_t) CREF(aux_3331))->label);
	 }
      }
      {
	 sfun_t obj_2215;
	 {
	    value_t aux_3336;
	    aux_3336 = (((variable_t) CREF(var_16))->value);
	    obj_2215 = (sfun_t) (aux_3336);
	 }
	 args_1163 = (((sfun_t) CREF(obj_2215))->args);
      }
      {
	 node_t obj_2216;
	 obj_2216 = (node_t) (node_17);
	 loc_1164 = (((node_t) CREF(obj_2216))->loc);
      }
      {
	 bool_t test_3342;
	 {
	    sfun_c_188_t obj_2218;
	    {
	       value_t aux_3343;
	       aux_3343 = (((variable_t) CREF(var_16))->value);
	       obj_2218 = (sfun_c_188_t) (aux_3343);
	    }
	    {
	       obj_t aux_3346;
	       {
		  object_t aux_3347;
		  aux_3347 = (object_t) (obj_2218);
		  aux_3346 = OBJECT_WIDENING(aux_3347);
	       }
	       test_3342 = (((sfun_c_188_t) CREF(aux_3346))->integrated);
	    }
	 }
	 if (test_3342)
	   {
	      if (NULLP(args_1163))
		{
		   ((((clabel_t) CREF(label_1162))->used__226) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		   {
		      cgoto_t res2294_2230;
		      {
			 cgoto_t new1451_2224;
			 new1451_2224 = ((cgoto_t) BREF(GC_MALLOC(sizeof(struct cgoto))));
			 {
			    long arg2002_2225;
			    arg2002_2225 = class_num_218___object(cgoto_cgen_cop);
			    {
			       obj_t obj_2228;
			       obj_2228 = (obj_t) (new1451_2224);
			       (((obj_t) CREF(obj_2228))->header = MAKE_HEADER(arg2002_2225, 0), BUNSPEC);
			    }
			 }
			 {
			    object_t aux_3358;
			    aux_3358 = (object_t) (new1451_2224);
			    OBJECT_WIDENING_SET(aux_3358, BFALSE);
			 }
			 ((((cgoto_t) CREF(new1451_2224))->loc) = ((obj_t) loc_1164), BUNSPEC);
			 ((((cgoto_t) CREF(new1451_2224))->label) = ((clabel_t) label_1162), BUNSPEC);
			 res2294_2230 = new1451_2224;
		      }
		      return (obj_t) (res2294_2230);
		   }
		}
	      else
		{
		   obj_t args_1169;
		   obj_t actuals_1170;
		   obj_t auxs_1171;
		   obj_t seq1_1172;
		   obj_t seq2_1173;
		   {
		      obj_t arg1876_1175;
		      obj_t arg1879_1178;
		      arg1876_1175 = (((app_t) CREF(node_17))->args);
		      {
			 cgoto_t arg1880_1179;
			 ((((clabel_t) CREF(label_1162))->used__226) = ((bool_t) ((bool_t) 1)), BUNSPEC);
			 {
			    cgoto_t res2295_2242;
			    {
			       cgoto_t new1451_2236;
			       new1451_2236 = ((cgoto_t) BREF(GC_MALLOC(sizeof(struct cgoto))));
			       {
				  long arg2002_2237;
				  arg2002_2237 = class_num_218___object(cgoto_cgen_cop);
				  {
				     obj_t obj_2240;
				     obj_2240 = (obj_t) (new1451_2236);
				     (((obj_t) CREF(obj_2240))->header = MAKE_HEADER(arg2002_2237, 0), BUNSPEC);
				  }
			       }
			       {
				  object_t aux_3370;
				  aux_3370 = (object_t) (new1451_2236);
				  OBJECT_WIDENING_SET(aux_3370, BFALSE);
			       }
			       ((((cgoto_t) CREF(new1451_2236))->loc) = ((obj_t) loc_1164), BUNSPEC);
			       ((((cgoto_t) CREF(new1451_2236))->label) = ((clabel_t) label_1162), BUNSPEC);
			       res2295_2242 = new1451_2236;
			    }
			    arg1880_1179 = res2295_2242;
			 }
			 {
			    obj_t list1881_1180;
			    {
			       obj_t aux_3375;
			       aux_3375 = (obj_t) (arg1880_1179);
			       list1881_1180 = MAKE_PAIR(aux_3375, BNIL);
			    }
			    arg1879_1178 = list1881_1180;
			 }
		      }
		      args_1169 = args_1163;
		      actuals_1170 = arg1876_1175;
		      auxs_1171 = BNIL;
		      seq1_1172 = BNIL;
		      seq2_1173 = arg1879_1178;
		    loop_1174:
		      if (NULLP(args_1169))
			{
			   {
			      bool_t test1887_1185;
			      {
				 obj_t obj_2245;
				 obj_2245 = seq1_1172;
				 test1887_1185 = NULLP(obj_2245);
			      }
			      if (test1887_1185)
				{
				   seq1_1172 = seq2_1173;
				}
			      else
				{
				   seq1_1172 = reverse__39___r4_pairs_and_lists_6_3(seq1_1172);
				   {
				      obj_t arg1888_1186;
				      arg1888_1186 = last_pair_93___r4_pairs_and_lists_6_3(seq1_1172);
				      SET_CDR(arg1888_1186, seq2_1173);
				   }
				}
			   }
			   {
			      cop_t arg1890_1187;
			      {
				 csequence_t arg1892_1188;
				 {
				    obj_t arg1893_1189;
				    {
				       local_var_164_t arg1894_1190;
				       {
					  local_var_164_t res2296_2256;
					  {
					     local_var_164_t new1534_2250;
					     new1534_2250 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
					     {
						long arg1972_2251;
						arg1972_2251 = class_num_218___object(local_var_164_cgen_cop);
						{
						   obj_t obj_2254;
						   obj_2254 = (obj_t) (new1534_2250);
						   (((obj_t) CREF(obj_2254))->header = MAKE_HEADER(arg1972_2251, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_3389;
						aux_3389 = (object_t) (new1534_2250);
						OBJECT_WIDENING_SET(aux_3389, BFALSE);
					     }
					     ((((local_var_164_t) CREF(new1534_2250))->loc) = ((obj_t) loc_1164), BUNSPEC);
					     ((((local_var_164_t) CREF(new1534_2250))->vars) = ((obj_t) auxs_1171), BUNSPEC);
					     res2296_2256 = new1534_2250;
					  }
					  arg1894_1190 = res2296_2256;
				       }
				       {
					  obj_t obj2_2258;
					  obj2_2258 = seq1_1172;
					  {
					     obj_t aux_3394;
					     aux_3394 = (obj_t) (arg1894_1190);
					     arg1893_1189 = MAKE_PAIR(aux_3394, obj2_2258);
					  }
				       }
				    }
				    {
				       csequence_t res2297_2269;
				       {
					  obj_t loc_2259;
					  loc_2259 = BFALSE;
					  {
					     csequence_t new1501_2262;
					     new1501_2262 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					     {
						long arg1983_2263;
						arg1983_2263 = class_num_218___object(csequence_cgen_cop);
						{
						   obj_t obj_2267;
						   obj_2267 = (obj_t) (new1501_2262);
						   (((obj_t) CREF(obj_2267))->header = MAKE_HEADER(arg1983_2263, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_3401;
						aux_3401 = (object_t) (new1501_2262);
						OBJECT_WIDENING_SET(aux_3401, loc_2259);
					     }
					     ((((csequence_t) CREF(new1501_2262))->loc) = ((obj_t) loc_2259), BUNSPEC);
					     ((((csequence_t) CREF(new1501_2262))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					     ((((csequence_t) CREF(new1501_2262))->cops) = ((obj_t) arg1893_1189), BUNSPEC);
					     res2297_2269 = new1501_2262;
					  }
				       }
				       arg1892_1188 = res2297_2269;
				    }
				 }
				 arg1890_1187 = bdb_let_var_254_cgen_cgen((cop_t) (arg1892_1188), loc_1164);
			      }
			      return block_kont_197_cgen_cgen((obj_t) (arg1890_1187), BFALSE);
			   }
			}
		      else
			{
			   obj_t arg_1193;
			   obj_t act_1194;
			   arg_1193 = CAR(args_1169);
			   act_1194 = CAR(actuals_1170);
			   {
			      bool_t test1897_1195;
			      {
				 bool_t test1919_1216;
				 test1919_1216 = is_a__118___object(act_1194, var_ast_node);
				 if (test1919_1216)
				   {
				      obj_t aux_3415;
				      {
					 variable_t aux_3416;
					 {
					    var_t obj_2273;
					    obj_2273 = (var_t) (act_1194);
					    aux_3416 = (((var_t) CREF(obj_2273))->variable);
					 }
					 aux_3415 = (obj_t) (aux_3416);
				      }
				      test1897_1195 = (arg_1193 == aux_3415);
				   }
				 else
				   {
				      test1897_1195 = ((bool_t) 0);
				   }
			      }
			      if (test1897_1195)
				{
				   obj_t actuals_3424;
				   obj_t args_3422;
				   args_3422 = CDR(args_1169);
				   actuals_3424 = CDR(actuals_1170);
				   actuals_1170 = actuals_3424;
				   args_1169 = args_3422;
				   goto loop_1174;
				}
			      else
				{
				   local_t aux_1198;
				   {
				      type_t aux_3429;
				      obj_t aux_3426;
				      {
					 local_t obj_2279;
					 obj_2279 = (local_t) (arg_1193);
					 aux_3429 = (((local_t) CREF(obj_2279))->type);
				      }
				      {
					 local_t obj_2278;
					 obj_2278 = (local_t) (arg_1193);
					 aux_3426 = (((local_t) CREF(obj_2278))->id);
				      }
				      aux_1198 = make_local_svar_name_219_cgen_cgen(aux_3426, aux_3429);
				   }
				   {
				      obj_t arg1900_1199;
				      obj_t arg1901_1200;
				      obj_t arg1902_1201;
				      obj_t arg1903_1202;
				      obj_t arg1905_1203;
				      arg1900_1199 = CDR(args_1169);
				      arg1901_1200 = CDR(actuals_1170);
				      {
					 obj_t aux_3435;
					 aux_3435 = (obj_t) (aux_1198);
					 arg1902_1201 = MAKE_PAIR(aux_3435, auxs_1171);
				      }
				      {
					 cop_t arg1906_1204;
					 {
					    setq_t arg1907_1205;
					    arg1907_1205 = node_setq_243_cgen_cgen((variable_t) (aux_1198), (node_t) (act_1194));
					    arg1906_1204 = node__cop_142_cgen_cgen((node_t) (arg1907_1205), _stop_kont__121_cgen_cgen);
					 }
					 {
					    obj_t obj2_2285;
					    obj2_2285 = seq1_1172;
					    {
					       obj_t aux_3443;
					       aux_3443 = (obj_t) (arg1906_1204);
					       arg1903_1202 = MAKE_PAIR(aux_3443, obj2_2285);
					    }
					 }
				      }
				      {
					 stop_t arg1909_1206;
					 {
					    csetq_t arg1910_1207;
					    {
					       varc_t arg1912_1209;
					       varc_t arg1913_1210;
					       {
						  varc_t res2298_2294;
						  {
						     obj_t loc_2286;
						     variable_t variable_2287;
						     loc_2286 = BFALSE;
						     variable_2287 = (variable_t) (arg_1193);
						     {
							varc_t new1481_2288;
							new1481_2288 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
							{
							   long arg1989_2289;
							   arg1989_2289 = class_num_218___object(varc_cgen_cop);
							   {
							      obj_t obj_2292;
							      obj_2292 = (obj_t) (new1481_2288);
							      (((obj_t) CREF(obj_2292))->header = MAKE_HEADER(arg1989_2289, 0), BUNSPEC);
							   }
							}
							{
							   object_t aux_3451;
							   aux_3451 = (object_t) (new1481_2288);
							   OBJECT_WIDENING_SET(aux_3451, loc_2286);
							}
							((((varc_t) CREF(new1481_2288))->loc) = ((obj_t) loc_2286), BUNSPEC);
							((((varc_t) CREF(new1481_2288))->variable) = ((variable_t) variable_2287), BUNSPEC);
							res2298_2294 = new1481_2288;
						     }
						  }
						  arg1912_1209 = res2298_2294;
					       }
					       {
						  obj_t arg1915_1212;
						  {
						     node_t obj_2295;
						     obj_2295 = (node_t) (act_1194);
						     arg1915_1212 = (((node_t) CREF(obj_2295))->loc);
						  }
						  {
						     varc_t res2299_2304;
						     {
							variable_t variable_2297;
							variable_2297 = (variable_t) (aux_1198);
							{
							   varc_t new1481_2298;
							   new1481_2298 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
							   {
							      long arg1989_2299;
							      arg1989_2299 = class_num_218___object(varc_cgen_cop);
							      {
								 obj_t obj_2302;
								 obj_2302 = (obj_t) (new1481_2298);
								 (((obj_t) CREF(obj_2302))->header = MAKE_HEADER(arg1989_2299, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_3463;
							      aux_3463 = (object_t) (new1481_2298);
							      OBJECT_WIDENING_SET(aux_3463, BFALSE);
							   }
							   ((((varc_t) CREF(new1481_2298))->loc) = ((obj_t) arg1915_1212), BUNSPEC);
							   ((((varc_t) CREF(new1481_2298))->variable) = ((variable_t) variable_2297), BUNSPEC);
							   res2299_2304 = new1481_2298;
							}
						     }
						     arg1913_1210 = res2299_2304;
						  }
					       }
					       {
						  csetq_t res2300_2315;
						  {
						     cop_t value_2307;
						     value_2307 = (cop_t) (arg1913_1210);
						     {
							csetq_t new1519_2308;
							new1519_2308 = ((csetq_t) BREF(GC_MALLOC(sizeof(struct csetq))));
							{
							   long arg1977_2309;
							   arg1977_2309 = class_num_218___object(csetq_cgen_cop);
							   {
							      obj_t obj_2313;
							      obj_2313 = (obj_t) (new1519_2308);
							      (((obj_t) CREF(obj_2313))->header = MAKE_HEADER(arg1977_2309, 0), BUNSPEC);
							   }
							}
							{
							   object_t aux_3473;
							   aux_3473 = (object_t) (new1519_2308);
							   OBJECT_WIDENING_SET(aux_3473, BFALSE);
							}
							((((csetq_t) CREF(new1519_2308))->loc) = ((obj_t) loc_1164), BUNSPEC);
							((((csetq_t) CREF(new1519_2308))->var) = ((varc_t) arg1912_1209), BUNSPEC);
							((((csetq_t) CREF(new1519_2308))->value) = ((cop_t) value_2307), BUNSPEC);
							res2300_2315 = new1519_2308;
						     }
						  }
						  arg1910_1207 = res2300_2315;
					       }
					    }
					    {
					       stop_t res2301_2324;
					       {
						  obj_t loc_2316;
						  cop_t value_2317;
						  loc_2316 = BFALSE;
						  value_2317 = (cop_t) (arg1910_1207);
						  {
						     stop_t new1513_2318;
						     new1513_2318 = ((stop_t) BREF(GC_MALLOC(sizeof(struct stop))));
						     {
							long arg1979_2319;
							arg1979_2319 = class_num_218___object(stop_cgen_cop);
							{
							   obj_t obj_2322;
							   obj_2322 = (obj_t) (new1513_2318);
							   (((obj_t) CREF(obj_2322))->header = MAKE_HEADER(arg1979_2319, 0), BUNSPEC);
							}
						     }
						     {
							object_t aux_3484;
							aux_3484 = (object_t) (new1513_2318);
							OBJECT_WIDENING_SET(aux_3484, loc_2316);
						     }
						     ((((stop_t) CREF(new1513_2318))->loc) = ((obj_t) loc_2316), BUNSPEC);
						     ((((stop_t) CREF(new1513_2318))->value) = ((cop_t) value_2317), BUNSPEC);
						     res2301_2324 = new1513_2318;
						  }
					       }
					       arg1909_1206 = res2301_2324;
					    }
					 }
					 {
					    obj_t aux_3489;
					    aux_3489 = (obj_t) (arg1909_1206);
					    arg1905_1203 = MAKE_PAIR(aux_3489, seq2_1173);
					 }
				      }
				      {
					 obj_t seq2_3496;
					 obj_t seq1_3495;
					 obj_t auxs_3494;
					 obj_t actuals_3493;
					 obj_t args_3492;
					 args_3492 = arg1900_1199;
					 actuals_3493 = arg1901_1200;
					 auxs_3494 = arg1902_1201;
					 seq1_3495 = arg1903_1202;
					 seq2_3496 = arg1905_1203;
					 seq2_1173 = seq2_3496;
					 seq1_1172 = seq1_3495;
					 auxs_1171 = auxs_3494;
					 actuals_1170 = actuals_3493;
					 args_1169 = args_3492;
					 goto loop_1174;
				      }
				   }
				}
			   }
			}
		   }
		}
	   }
	 else
	   {
	      {
		 sfun_c_188_t obj_2328;
		 {
		    value_t aux_3497;
		    aux_3497 = (((variable_t) CREF(var_16))->value);
		    obj_2328 = (sfun_c_188_t) (aux_3497);
		 }
		 {
		    obj_t aux_3500;
		    {
		       object_t aux_3501;
		       aux_3501 = (object_t) (obj_2328);
		       aux_3500 = OBJECT_WIDENING(aux_3501);
		    }
		    ((((sfun_c_188_t) CREF(aux_3500))->integrated) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		 }
	      }
	      {
		 cop_t body_1219;
		 {
		    node_t aux_3505;
		    {
		       obj_t aux_3506;
		       {
			  sfun_t obj_2331;
			  {
			     value_t aux_3507;
			     {
				local_t obj_2330;
				obj_2330 = (local_t) (var_16);
				aux_3507 = (((local_t) CREF(obj_2330))->value);
			     }
			     obj_2331 = (sfun_t) (aux_3507);
			  }
			  aux_3506 = (((sfun_t) CREF(obj_2331))->body);
		       }
		       aux_3505 = (node_t) (aux_3506);
		    }
		    body_1219 = node__cop_142_cgen_cgen(aux_3505, kont_18);
		 }
		 {
		    obj_t val1449_2333;
		    val1449_2333 = (obj_t) (body_1219);
		    ((((clabel_t) CREF(label_1162))->body) = ((obj_t) val1449_2333), BUNSPEC);
		 }
		 if (NULLP(args_1163))
		   {
		      return (obj_t) (label_1162);
		   }
		 else
		   {
		      obj_t formals_1221;
		      obj_t actuals_1222;
		      obj_t seq_1223;
		      {
			 csequence_t aux_3519;
			 formals_1221 = args_1163;
			 actuals_1222 = (((app_t) CREF(node_17))->args);
			 seq_1223 = BNIL;
		       loop_1224:
			 if (NULLP(formals_1221))
			   {
			      obj_t arg1927_1228;
			      {
				 obj_t arg1928_1229;
				 {
				    obj_t aux_3522;
				    aux_3522 = (obj_t) (label_1162);
				    arg1928_1229 = MAKE_PAIR(aux_3522, seq_1223);
				 }
				 arg1927_1228 = reverse__39___r4_pairs_and_lists_6_3(arg1928_1229);
			      }
			      {
				 csequence_t res2302_2349;
				 {
				    obj_t loc_2339;
				    loc_2339 = BFALSE;
				    {
				       csequence_t new1501_2342;
				       new1501_2342 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
				       {
					  long arg1983_2343;
					  arg1983_2343 = class_num_218___object(csequence_cgen_cop);
					  {
					     obj_t obj_2347;
					     obj_2347 = (obj_t) (new1501_2342);
					     (((obj_t) CREF(obj_2347))->header = MAKE_HEADER(arg1983_2343, 0), BUNSPEC);
					  }
				       }
				       {
					  object_t aux_3530;
					  aux_3530 = (object_t) (new1501_2342);
					  OBJECT_WIDENING_SET(aux_3530, loc_2339);
				       }
				       ((((csequence_t) CREF(new1501_2342))->loc) = ((obj_t) loc_2339), BUNSPEC);
				       ((((csequence_t) CREF(new1501_2342))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
				       ((((csequence_t) CREF(new1501_2342))->cops) = ((obj_t) arg1927_1228), BUNSPEC);
				       res2302_2349 = new1501_2342;
				    }
				 }
				 aux_3519 = res2302_2349;
			      }
			   }
			 else
			   {
			      obj_t arg1929_1230;
			      obj_t arg1930_1231;
			      obj_t arg1931_1232;
			      arg1929_1230 = CDR(formals_1221);
			      arg1930_1231 = CDR(actuals_1222);
			      {
				 cop_t arg1932_1233;
				 {
				    setq_t arg1933_1234;
				    {
				       node_t aux_3542;
				       variable_t aux_3538;
				       {
					  obj_t aux_3543;
					  aux_3543 = CAR(actuals_1222);
					  aux_3542 = (node_t) (aux_3543);
				       }
				       {
					  obj_t aux_3539;
					  aux_3539 = CAR(formals_1221);
					  aux_3538 = (variable_t) (aux_3539);
				       }
				       arg1933_1234 = node_setq_243_cgen_cgen(aux_3538, aux_3542);
				    }
				    arg1932_1233 = node__cop_142_cgen_cgen((node_t) (arg1933_1234), _stop_kont__121_cgen_cgen);
				 }
				 {
				    obj_t aux_3549;
				    aux_3549 = (obj_t) (arg1932_1233);
				    arg1931_1232 = MAKE_PAIR(aux_3549, seq_1223);
				 }
			      }
			      {
				 obj_t seq_3554;
				 obj_t actuals_3553;
				 obj_t formals_3552;
				 formals_3552 = arg1929_1230;
				 actuals_3553 = arg1930_1231;
				 seq_3554 = arg1931_1232;
				 seq_1223 = seq_3554;
				 actuals_1222 = actuals_3553;
				 formals_1221 = formals_3552;
				 goto loop_1224;
			      }
			   }
			 return (obj_t) (aux_3519);
		      }
		   }
	      }
	   }
      }
   }
}


/* method-init */ obj_t 
method_init_76_cgen_capp()
{
   {
      obj_t node__cop_app_ly_235_2886;
      node__cop_app_ly_235_2886 = proc2338_cgen_capp;
      add_method__1___object(node__cop_env_160_cgen_cgen, app_ly_162_ast_node, node__cop_app_ly_235_2886);
   }
   {
      obj_t node__cop_funcall_165_2885;
      node__cop_funcall_165_2885 = proc2339_cgen_capp;
      add_method__1___object(node__cop_env_160_cgen_cgen, funcall_ast_node, node__cop_funcall_165_2885);
   }
   {
      obj_t node__cop_app_91_2884;
      node__cop_app_91_2884 = proc2340_cgen_capp;
      return add_method__1___object(node__cop_env_160_cgen_cgen, app_ast_node, node__cop_app_91_2884);
   }
}


/* node->cop-app */ obj_t 
node__cop_app_91_cgen_capp(obj_t env_2887, obj_t node_2888, obj_t kont_2889)
{
   {
      app_t node_1957;
      obj_t kont_1958;
      node_1957 = (app_t) (node_2888);
      kont_1958 = kont_2889;
      {
	 variable_t var_1962;
	 {
	    var_t arg2278_1968;
	    arg2278_1968 = (((app_t) CREF(node_1957))->fun);
	    var_1962 = (((var_t) CREF(arg2278_1968))->variable);
	 }
	 {
	    bool_t test2274_1963;
	    {
	       bool_t test2275_1964;
	       test2275_1964 = is_a__118___object((obj_t) (var_1962), global_ast_var);
	       if (test2275_1964)
		 {
		    bool_t _ortest_1672_1965;
		    {
		       bool_t test2277_1967;
		       {
			  obj_t obj2_2874;
			  obj2_2874 = _the_global__73_cgen_cgen;
			  {
			     obj_t aux_3565;
			     aux_3565 = (obj_t) (var_1962);
			     test2277_1967 = (aux_3565 == obj2_2874);
			  }
		       }
		       if (test2277_1967)
			 {
			    _ortest_1672_1965 = ((bool_t) 0);
			 }
		       else
			 {
			    _ortest_1672_1965 = ((bool_t) 1);
			 }
		    }
		    if (_ortest_1672_1965)
		      {
			 test2274_1963 = _ortest_1672_1965;
		      }
		    else
		      {
			 bool_t test2276_1966;
			 {
			    obj_t obj2_2876;
			    obj2_2876 = _return_kont__110_cgen_cgen;
			    test2276_1966 = (kont_1958 == obj2_2876);
			 }
			 if (test2276_1966)
			   {
			      test2274_1963 = ((bool_t) 0);
			   }
			 else
			   {
			      test2274_1963 = ((bool_t) 1);
			   }
		      }
		 }
	       else
		 {
		    test2274_1963 = ((bool_t) 0);
		 }
	    }
	    if (test2274_1963)
	      {
		 {
		    bool_t test1708_2880;
		    {
		       obj_t aux_3573;
		       {
			  value_t aux_3574;
			  aux_3574 = (((variable_t) CREF(var_1962))->value);
			  aux_3573 = (obj_t) (aux_3574);
		       }
		       test1708_2880 = is_a__118___object(aux_3573, sfun_ast_var);
		    }
		    if (test1708_2880)
		      {
			 return node_sfun_non_tail_app__cop_176_cgen_capp(var_1962, node_1957, kont_1958);
		      }
		    else
		      {
			 return node_cfun_non_tail_app__cop_38_cgen_capp(var_1962, node_1957, kont_1958);
		      }
		 }
	      }
	    else
	      {
		 return node_tail_app__cop_48_cgen_capp(var_1962, node_1957, kont_1958);
	      }
	 }
      }
   }
}


/* node->cop-funcall */ obj_t 
node__cop_funcall_165_cgen_capp(obj_t env_2890, obj_t node_2891, obj_t kont_2892)
{
   {
      funcall_t node_1861;
      obj_t kont_1862;
      node_1861 = (funcall_t) (node_2891);
      kont_1862 = kont_2892;
      {
	 obj_t old_actuals_174_1866;
	 obj_t new_actuals_73_1867;
	 local_t aux_1868;
	 obj_t auxs_1869;
	 obj_t exps_1870;
	 {
	    obj_t arg2187_1872;
	    local_t arg2189_1874;
	    arg2187_1872 = (((funcall_t) CREF(node_1861))->args);
	    arg2189_1874 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
	    old_actuals_174_1866 = arg2187_1872;
	    new_actuals_73_1867 = BNIL;
	    aux_1868 = arg2189_1874;
	    auxs_1869 = BNIL;
	    exps_1870 = BNIL;
	  loop_1871:
	    if (NULLP(old_actuals_174_1866))
	      {
		 local_t aux_1879;
		 aux_1879 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
		 {
		    cop_t cop_1880;
		    {
		       setq_t arg2247_1932;
		       arg2247_1932 = node_setq_243_cgen_cgen((variable_t) (aux_1879), (((funcall_t) CREF(node_1861))->fun));
		       cop_1880 = node__cop_142_cgen_cgen((node_t) (arg2247_1932), _id_kont__126_cgen_cgen);
		    }
		    {
		       {
			  bool_t test2194_1881;
			  {
			     bool_t test2241_1927;
			     test2241_1927 = is_a__118___object((obj_t) (cop_1880), csetq_cgen_cop);
			     if (test2241_1927)
			       {
				  bool_t test2242_1928;
				  {
				     obj_t aux_3600;
				     {
					node_t aux_3601;
					aux_3601 = (((funcall_t) CREF(node_1861))->fun);
					aux_3600 = (obj_t) (aux_3601);
				     }
				     test2242_1928 = is_a__118___object(aux_3600, var_ast_node);
				  }
				  if (test2242_1928)
				    {
				       obj_t aux_3612;
				       obj_t aux_3606;
				       aux_3612 = (obj_t) (aux_1879);
				       {
					  variable_t aux_3607;
					  {
					     varc_t arg2244_1930;
					     {
						csetq_t obj_2692;
						obj_2692 = (csetq_t) (cop_1880);
						arg2244_1930 = (((csetq_t) CREF(obj_2692))->var);
					     }
					     aux_3607 = (((varc_t) CREF(arg2244_1930))->variable);
					  }
					  aux_3606 = (obj_t) (aux_3607);
				       }
				       test2194_1881 = (aux_3606 == aux_3612);
				    }
				  else
				    {
				       test2194_1881 = ((bool_t) 0);
				    }
			       }
			     else
			       {
				  test2194_1881 = ((bool_t) 0);
			       }
			  }
			  if (test2194_1881)
			    {
			       cop_t cfun_1882;
			       {
				  csetq_t obj_2696;
				  obj_2696 = (csetq_t) (cop_1880);
				  cfun_1882 = (((csetq_t) CREF(obj_2696))->value);
			       }
			       if (NULLP(auxs_1869))
				 {
				    cfuncall_t arg2196_1884;
				    {
				       obj_t arg2197_1885;
				       obj_t arg2199_1887;
				       obj_t arg2200_1888;
				       arg2197_1885 = (((funcall_t) CREF(node_1861))->loc);
				       arg2199_1887 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1867);
				       arg2200_1888 = (((funcall_t) CREF(node_1861))->strength);
				       {
					  cfuncall_t res2323_2712;
					  {
					     cfuncall_t new1540_2704;
					     new1540_2704 = ((cfuncall_t) BREF(GC_MALLOC(sizeof(struct cfuncall))));
					     {
						long arg1970_2705;
						arg1970_2705 = class_num_218___object(cfuncall_cgen_cop);
						{
						   obj_t obj_2710;
						   obj_2710 = (obj_t) (new1540_2704);
						   (((obj_t) CREF(obj_2710))->header = MAKE_HEADER(arg1970_2705, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_3627;
						aux_3627 = (object_t) (new1540_2704);
						OBJECT_WIDENING_SET(aux_3627, BFALSE);
					     }
					     ((((cfuncall_t) CREF(new1540_2704))->loc) = ((obj_t) arg2197_1885), BUNSPEC);
					     ((((cfuncall_t) CREF(new1540_2704))->fun) = ((cop_t) cfun_1882), BUNSPEC);
					     ((((cfuncall_t) CREF(new1540_2704))->args) = ((obj_t) arg2199_1887), BUNSPEC);
					     ((((cfuncall_t) CREF(new1540_2704))->strength) = ((obj_t) arg2200_1888), BUNSPEC);
					     res2323_2712 = new1540_2704;
					  }
					  arg2196_1884 = res2323_2712;
				       }
				    }
				    return PROCEDURE_ENTRY(kont_1862) (kont_1862, (obj_t) (arg2196_1884), BEOA);
				 }
			       else
				 {
				    obj_t arg2201_1889;
				    csequence_t arg2202_1890;
				    arg2201_1889 = (((funcall_t) CREF(node_1861))->loc);
				    {
				       obj_t arg2204_1891;
				       {
					  local_var_164_t arg2205_1892;
					  csequence_t arg2206_1893;
					  obj_t arg2207_1894;
					  {
					     obj_t arg2213_1899;
					     arg2213_1899 = (((funcall_t) CREF(node_1861))->loc);
					     {
						local_var_164_t res2324_2723;
						{
						   local_var_164_t new1534_2717;
						   new1534_2717 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
						   {
						      long arg1972_2718;
						      arg1972_2718 = class_num_218___object(local_var_164_cgen_cop);
						      {
							 obj_t obj_2721;
							 obj_2721 = (obj_t) (new1534_2717);
							 (((obj_t) CREF(obj_2721))->header = MAKE_HEADER(arg1972_2718, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_3643;
						      aux_3643 = (object_t) (new1534_2717);
						      OBJECT_WIDENING_SET(aux_3643, BFALSE);
						   }
						   ((((local_var_164_t) CREF(new1534_2717))->loc) = ((obj_t) arg2213_1899), BUNSPEC);
						   ((((local_var_164_t) CREF(new1534_2717))->vars) = ((obj_t) auxs_1869), BUNSPEC);
						   res2324_2723 = new1534_2717;
						}
						arg2205_1892 = res2324_2723;
					     }
					  }
					  {
					     csequence_t res2325_2734;
					     {
						obj_t loc_2724;
						loc_2724 = BFALSE;
						{
						   csequence_t new1501_2727;
						   new1501_2727 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						   {
						      long arg1983_2728;
						      arg1983_2728 = class_num_218___object(csequence_cgen_cop);
						      {
							 obj_t obj_2732;
							 obj_2732 = (obj_t) (new1501_2727);
							 (((obj_t) CREF(obj_2732))->header = MAKE_HEADER(arg1983_2728, 0), BUNSPEC);
						      }
						   }
						   {
						      object_t aux_3652;
						      aux_3652 = (object_t) (new1501_2727);
						      OBJECT_WIDENING_SET(aux_3652, loc_2724);
						   }
						   ((((csequence_t) CREF(new1501_2727))->loc) = ((obj_t) loc_2724), BUNSPEC);
						   ((((csequence_t) CREF(new1501_2727))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						   ((((csequence_t) CREF(new1501_2727))->cops) = ((obj_t) exps_1870), BUNSPEC);
						   res2325_2734 = new1501_2727;
						}
					     }
					     arg2206_1893 = res2325_2734;
					  }
					  {
					     cfuncall_t arg2216_1902;
					     {
						obj_t arg2217_1903;
						obj_t arg2220_1905;
						obj_t arg2221_1906;
						arg2217_1903 = (((funcall_t) CREF(node_1861))->loc);
						arg2220_1905 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1867);
						arg2221_1906 = (((funcall_t) CREF(node_1861))->strength);
						{
						   cfuncall_t res2326_2749;
						   {
						      cfuncall_t new1540_2741;
						      new1540_2741 = ((cfuncall_t) BREF(GC_MALLOC(sizeof(struct cfuncall))));
						      {
							 long arg1970_2742;
							 arg1970_2742 = class_num_218___object(cfuncall_cgen_cop);
							 {
							    obj_t obj_2747;
							    obj_2747 = (obj_t) (new1540_2741);
							    (((obj_t) CREF(obj_2747))->header = MAKE_HEADER(arg1970_2742, 0), BUNSPEC);
							 }
						      }
						      {
							 object_t aux_3665;
							 aux_3665 = (object_t) (new1540_2741);
							 OBJECT_WIDENING_SET(aux_3665, BFALSE);
						      }
						      ((((cfuncall_t) CREF(new1540_2741))->loc) = ((obj_t) arg2217_1903), BUNSPEC);
						      ((((cfuncall_t) CREF(new1540_2741))->fun) = ((cop_t) cfun_1882), BUNSPEC);
						      ((((cfuncall_t) CREF(new1540_2741))->args) = ((obj_t) arg2220_1905), BUNSPEC);
						      ((((cfuncall_t) CREF(new1540_2741))->strength) = ((obj_t) arg2221_1906), BUNSPEC);
						      res2326_2749 = new1540_2741;
						   }
						   arg2216_1902 = res2326_2749;
						}
					     }
					     arg2207_1894 = PROCEDURE_ENTRY(kont_1862) (kont_1862, (obj_t) (arg2216_1902), BEOA);
					  }
					  {
					     obj_t list2208_1895;
					     {
						obj_t arg2209_1896;
						{
						   obj_t arg2210_1897;
						   arg2210_1897 = MAKE_PAIR(arg2207_1894, BNIL);
						   {
						      obj_t aux_3676;
						      aux_3676 = (obj_t) (arg2206_1893);
						      arg2209_1896 = MAKE_PAIR(aux_3676, arg2210_1897);
						   }
						}
						{
						   obj_t aux_3679;
						   aux_3679 = (obj_t) (arg2205_1892);
						   list2208_1895 = MAKE_PAIR(aux_3679, arg2209_1896);
						}
					     }
					     arg2204_1891 = list2208_1895;
					  }
				       }
				       {
					  csequence_t res2327_2761;
					  {
					     obj_t loc_2751;
					     loc_2751 = BFALSE;
					     {
						csequence_t new1501_2754;
						new1501_2754 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						{
						   long arg1983_2755;
						   arg1983_2755 = class_num_218___object(csequence_cgen_cop);
						   {
						      obj_t obj_2759;
						      obj_2759 = (obj_t) (new1501_2754);
						      (((obj_t) CREF(obj_2759))->header = MAKE_HEADER(arg1983_2755, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_3686;
						   aux_3686 = (object_t) (new1501_2754);
						   OBJECT_WIDENING_SET(aux_3686, loc_2751);
						}
						((((csequence_t) CREF(new1501_2754))->loc) = ((obj_t) loc_2751), BUNSPEC);
						((((csequence_t) CREF(new1501_2754))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						((((csequence_t) CREF(new1501_2754))->cops) = ((obj_t) arg2204_1891), BUNSPEC);
						res2327_2761 = new1501_2754;
					     }
					  }
					  arg2202_1890 = res2327_2761;
				       }
				    }
				    {
				       block_t res2328_2770;
				       {
					  cop_t body_2763;
					  body_2763 = (cop_t) (arg2202_1890);
					  {
					     block_t new1457_2764;
					     new1457_2764 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
					     {
						long arg2000_2765;
						arg2000_2765 = class_num_218___object(block_cgen_cop);
						{
						   obj_t obj_2768;
						   obj_2768 = (obj_t) (new1457_2764);
						   (((obj_t) CREF(obj_2768))->header = MAKE_HEADER(arg2000_2765, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_3697;
						aux_3697 = (object_t) (new1457_2764);
						OBJECT_WIDENING_SET(aux_3697, BFALSE);
					     }
					     ((((block_t) CREF(new1457_2764))->loc) = ((obj_t) arg2201_1889), BUNSPEC);
					     ((((block_t) CREF(new1457_2764))->body) = ((cop_t) body_2763), BUNSPEC);
					     res2328_2770 = new1457_2764;
					  }
				       }
				       return (obj_t) (res2328_2770);
				    }
				 }
			    }
			  else
			    {
			       obj_t arg2222_1908;
			       csequence_t arg2223_1909;
			       arg2222_1908 = (((funcall_t) CREF(node_1861))->loc);
			       {
				  obj_t arg2224_1910;
				  {
				     local_var_164_t arg2225_1911;
				     csequence_t arg2226_1912;
				     obj_t arg2227_1913;
				     {
					obj_t arg2232_1918;
					obj_t arg2233_1919;
					arg2232_1918 = (((funcall_t) CREF(node_1861))->loc);
					{
					   obj_t aux_3705;
					   aux_3705 = (obj_t) (aux_1879);
					   arg2233_1919 = MAKE_PAIR(aux_3705, auxs_1869);
					}
					{
					   local_var_164_t res2329_2783;
					   {
					      local_var_164_t new1534_2777;
					      new1534_2777 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
					      {
						 long arg1972_2778;
						 arg1972_2778 = class_num_218___object(local_var_164_cgen_cop);
						 {
						    obj_t obj_2781;
						    obj_2781 = (obj_t) (new1534_2777);
						    (((obj_t) CREF(obj_2781))->header = MAKE_HEADER(arg1972_2778, 0), BUNSPEC);
						 }
					      }
					      {
						 object_t aux_3712;
						 aux_3712 = (object_t) (new1534_2777);
						 OBJECT_WIDENING_SET(aux_3712, BFALSE);
					      }
					      ((((local_var_164_t) CREF(new1534_2777))->loc) = ((obj_t) arg2232_1918), BUNSPEC);
					      ((((local_var_164_t) CREF(new1534_2777))->vars) = ((obj_t) arg2233_1919), BUNSPEC);
					      res2329_2783 = new1534_2777;
					   }
					   arg2225_1911 = res2329_2783;
					}
				     }
				     {
					obj_t arg2234_1920;
					{
					   obj_t aux_3717;
					   aux_3717 = (obj_t) (cop_1880);
					   arg2234_1920 = MAKE_PAIR(aux_3717, exps_1870);
					}
					{
					   csequence_t res2330_2796;
					   {
					      obj_t loc_2786;
					      loc_2786 = BFALSE;
					      {
						 csequence_t new1501_2789;
						 new1501_2789 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						 {
						    long arg1983_2790;
						    arg1983_2790 = class_num_218___object(csequence_cgen_cop);
						    {
						       obj_t obj_2794;
						       obj_2794 = (obj_t) (new1501_2789);
						       (((obj_t) CREF(obj_2794))->header = MAKE_HEADER(arg1983_2790, 0), BUNSPEC);
						    }
						 }
						 {
						    object_t aux_3724;
						    aux_3724 = (object_t) (new1501_2789);
						    OBJECT_WIDENING_SET(aux_3724, loc_2786);
						 }
						 ((((csequence_t) CREF(new1501_2789))->loc) = ((obj_t) loc_2786), BUNSPEC);
						 ((((csequence_t) CREF(new1501_2789))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						 ((((csequence_t) CREF(new1501_2789))->cops) = ((obj_t) arg2234_1920), BUNSPEC);
						 res2330_2796 = new1501_2789;
					      }
					   }
					   arg2226_1912 = res2330_2796;
					}
				     }
				     {
					cfuncall_t arg2235_1921;
					{
					   obj_t arg2236_1922;
					   varc_t arg2237_1923;
					   obj_t arg2238_1924;
					   obj_t arg2239_1925;
					   arg2236_1922 = (((funcall_t) CREF(node_1861))->loc);
					   {
					      varc_t res2331_2806;
					      {
						 obj_t loc_2798;
						 variable_t variable_2799;
						 loc_2798 = BFALSE;
						 variable_2799 = (variable_t) (aux_1879);
						 {
						    varc_t new1481_2800;
						    new1481_2800 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
						    {
						       long arg1989_2801;
						       arg1989_2801 = class_num_218___object(varc_cgen_cop);
						       {
							  obj_t obj_2804;
							  obj_2804 = (obj_t) (new1481_2800);
							  (((obj_t) CREF(obj_2804))->header = MAKE_HEADER(arg1989_2801, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3736;
						       aux_3736 = (object_t) (new1481_2800);
						       OBJECT_WIDENING_SET(aux_3736, loc_2798);
						    }
						    ((((varc_t) CREF(new1481_2800))->loc) = ((obj_t) loc_2798), BUNSPEC);
						    ((((varc_t) CREF(new1481_2800))->variable) = ((variable_t) variable_2799), BUNSPEC);
						    res2331_2806 = new1481_2800;
						 }
					      }
					      arg2237_1923 = res2331_2806;
					   }
					   arg2238_1924 = reverse__39___r4_pairs_and_lists_6_3(new_actuals_73_1867);
					   arg2239_1925 = (((funcall_t) CREF(node_1861))->strength);
					   {
					      cfuncall_t res2332_2820;
					      {
						 cop_t fun_2809;
						 fun_2809 = (cop_t) (arg2237_1923);
						 {
						    cfuncall_t new1540_2812;
						    new1540_2812 = ((cfuncall_t) BREF(GC_MALLOC(sizeof(struct cfuncall))));
						    {
						       long arg1970_2813;
						       arg1970_2813 = class_num_218___object(cfuncall_cgen_cop);
						       {
							  obj_t obj_2818;
							  obj_2818 = (obj_t) (new1540_2812);
							  (((obj_t) CREF(obj_2818))->header = MAKE_HEADER(arg1970_2813, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3748;
						       aux_3748 = (object_t) (new1540_2812);
						       OBJECT_WIDENING_SET(aux_3748, BFALSE);
						    }
						    ((((cfuncall_t) CREF(new1540_2812))->loc) = ((obj_t) arg2236_1922), BUNSPEC);
						    ((((cfuncall_t) CREF(new1540_2812))->fun) = ((cop_t) fun_2809), BUNSPEC);
						    ((((cfuncall_t) CREF(new1540_2812))->args) = ((obj_t) arg2238_1924), BUNSPEC);
						    ((((cfuncall_t) CREF(new1540_2812))->strength) = ((obj_t) arg2239_1925), BUNSPEC);
						    res2332_2820 = new1540_2812;
						 }
					      }
					      arg2235_1921 = res2332_2820;
					   }
					}
					arg2227_1913 = PROCEDURE_ENTRY(kont_1862) (kont_1862, (obj_t) (arg2235_1921), BEOA);
				     }
				     {
					obj_t list2228_1914;
					{
					   obj_t arg2229_1915;
					   {
					      obj_t arg2230_1916;
					      arg2230_1916 = MAKE_PAIR(arg2227_1913, BNIL);
					      {
						 obj_t aux_3759;
						 aux_3759 = (obj_t) (arg2226_1912);
						 arg2229_1915 = MAKE_PAIR(aux_3759, arg2230_1916);
					      }
					   }
					   {
					      obj_t aux_3762;
					      aux_3762 = (obj_t) (arg2225_1911);
					      list2228_1914 = MAKE_PAIR(aux_3762, arg2229_1915);
					   }
					}
					arg2224_1910 = list2228_1914;
				     }
				  }
				  {
				     csequence_t res2333_2832;
				     {
					obj_t loc_2822;
					loc_2822 = BFALSE;
					{
					   csequence_t new1501_2825;
					   new1501_2825 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
					   {
					      long arg1983_2826;
					      arg1983_2826 = class_num_218___object(csequence_cgen_cop);
					      {
						 obj_t obj_2830;
						 obj_2830 = (obj_t) (new1501_2825);
						 (((obj_t) CREF(obj_2830))->header = MAKE_HEADER(arg1983_2826, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3769;
					      aux_3769 = (object_t) (new1501_2825);
					      OBJECT_WIDENING_SET(aux_3769, loc_2822);
					   }
					   ((((csequence_t) CREF(new1501_2825))->loc) = ((obj_t) loc_2822), BUNSPEC);
					   ((((csequence_t) CREF(new1501_2825))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
					   ((((csequence_t) CREF(new1501_2825))->cops) = ((obj_t) arg2224_1910), BUNSPEC);
					   res2333_2832 = new1501_2825;
					}
				     }
				     arg2223_1909 = res2333_2832;
				  }
			       }
			       {
				  block_t res2334_2841;
				  {
				     cop_t body_2834;
				     body_2834 = (cop_t) (arg2223_1909);
				     {
					block_t new1457_2835;
					new1457_2835 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
					{
					   long arg2000_2836;
					   arg2000_2836 = class_num_218___object(block_cgen_cop);
					   {
					      obj_t obj_2839;
					      obj_2839 = (obj_t) (new1457_2835);
					      (((obj_t) CREF(obj_2839))->header = MAKE_HEADER(arg2000_2836, 0), BUNSPEC);
					   }
					}
					{
					   object_t aux_3780;
					   aux_3780 = (object_t) (new1457_2835);
					   OBJECT_WIDENING_SET(aux_3780, BFALSE);
					}
					((((block_t) CREF(new1457_2835))->loc) = ((obj_t) arg2222_1908), BUNSPEC);
					((((block_t) CREF(new1457_2835))->body) = ((cop_t) body_2834), BUNSPEC);
					res2334_2841 = new1457_2835;
				     }
				  }
				  return (obj_t) (res2334_2841);
			       }
			    }
		       }
		    }
		 }
	      }
	    else
	      {
		 cop_t cop_1935;
		 {
		    setq_t arg2271_1953;
		    {
		       node_t aux_3786;
		       {
			  obj_t aux_3788;
			  aux_3788 = CAR(old_actuals_174_1866);
			  aux_3786 = (node_t) (aux_3788);
		       }
		       arg2271_1953 = node_setq_243_cgen_cgen((variable_t) (aux_1868), aux_3786);
		    }
		    cop_1935 = node__cop_142_cgen_cgen((node_t) (arg2271_1953), _id_kont__126_cgen_cgen);
		 }
		 {
		    bool_t test2251_1936;
		    {
		       bool_t test2268_1950;
		       test2268_1950 = is_a__118___object((obj_t) (cop_1935), csetq_cgen_cop);
		       if (test2268_1950)
			 {
			    obj_t aux_3803;
			    obj_t aux_3797;
			    aux_3803 = (obj_t) (aux_1868);
			    {
			       variable_t aux_3798;
			       {
				  varc_t arg2270_1952;
				  {
				     csetq_t obj_2844;
				     obj_2844 = (csetq_t) (cop_1935);
				     arg2270_1952 = (((csetq_t) CREF(obj_2844))->var);
				  }
				  aux_3798 = (((varc_t) CREF(arg2270_1952))->variable);
			       }
			       aux_3797 = (obj_t) (aux_3798);
			    }
			    test2251_1936 = (aux_3797 == aux_3803);
			 }
		       else
			 {
			    test2251_1936 = ((bool_t) 0);
			 }
		    }
		    if (test2251_1936)
		      {
			 obj_t arg2252_1937;
			 obj_t arg2254_1938;
			 arg2252_1937 = CDR(old_actuals_174_1866);
			 {
			    obj_t aux_3808;
			    {
			       cop_t aux_3809;
			       {
				  csetq_t obj_2849;
				  obj_2849 = (csetq_t) (cop_1935);
				  aux_3809 = (((csetq_t) CREF(obj_2849))->value);
			       }
			       aux_3808 = (obj_t) (aux_3809);
			    }
			    arg2254_1938 = MAKE_PAIR(aux_3808, new_actuals_73_1867);
			 }
			 {
			    obj_t new_actuals_73_3815;
			    obj_t old_actuals_174_3814;
			    old_actuals_174_3814 = arg2252_1937;
			    new_actuals_73_3815 = arg2254_1938;
			    new_actuals_73_1867 = new_actuals_73_3815;
			    old_actuals_174_1866 = old_actuals_174_3814;
			    goto loop_1871;
			 }
		      }
		    else
		      {
			 {
			    obj_t arg2257_1940;
			    obj_t arg2258_1941;
			    local_t arg2259_1942;
			    obj_t arg2260_1943;
			    obj_t arg2261_1944;
			    arg2257_1940 = CDR(old_actuals_174_1866);
			    {
			       varc_t arg2263_1945;
			       {
				  obj_t arg2264_1946;
				  {
				     node_t obj_2854;
				     {
					obj_t aux_3817;
					aux_3817 = CAR(old_actuals_174_1866);
					obj_2854 = (node_t) (aux_3817);
				     }
				     arg2264_1946 = (((node_t) CREF(obj_2854))->loc);
				  }
				  {
				     varc_t res2335_2863;
				     {
					variable_t variable_2856;
					variable_2856 = (variable_t) (aux_1868);
					{
					   varc_t new1481_2857;
					   new1481_2857 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
					   {
					      long arg1989_2858;
					      arg1989_2858 = class_num_218___object(varc_cgen_cop);
					      {
						 obj_t obj_2861;
						 obj_2861 = (obj_t) (new1481_2857);
						 (((obj_t) CREF(obj_2861))->header = MAKE_HEADER(arg1989_2858, 0), BUNSPEC);
					      }
					   }
					   {
					      object_t aux_3826;
					      aux_3826 = (object_t) (new1481_2857);
					      OBJECT_WIDENING_SET(aux_3826, BFALSE);
					   }
					   ((((varc_t) CREF(new1481_2857))->loc) = ((obj_t) arg2264_1946), BUNSPEC);
					   ((((varc_t) CREF(new1481_2857))->variable) = ((variable_t) variable_2856), BUNSPEC);
					   res2335_2863 = new1481_2857;
					}
				     }
				     arg2263_1945 = res2335_2863;
				  }
			       }
			       {
				  obj_t aux_3831;
				  aux_3831 = (obj_t) (arg2263_1945);
				  arg2258_1941 = MAKE_PAIR(aux_3831, new_actuals_73_1867);
			       }
			    }
			    arg2259_1942 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
			    {
			       obj_t aux_3837;
			       aux_3837 = (obj_t) (aux_1868);
			       arg2260_1943 = MAKE_PAIR(aux_3837, auxs_1869);
			    }
			    {
			       obj_t aux_3840;
			       aux_3840 = (obj_t) (cop_1935);
			       arg2261_1944 = MAKE_PAIR(aux_3840, exps_1870);
			    }
			    {
			       obj_t exps_3847;
			       obj_t auxs_3846;
			       local_t aux_3845;
			       obj_t new_actuals_73_3844;
			       obj_t old_actuals_174_3843;
			       old_actuals_174_3843 = arg2257_1940;
			       new_actuals_73_3844 = arg2258_1941;
			       aux_3845 = arg2259_1942;
			       auxs_3846 = arg2260_1943;
			       exps_3847 = arg2261_1944;
			       exps_1870 = exps_3847;
			       auxs_1869 = auxs_3846;
			       aux_1868 = aux_3845;
			       new_actuals_73_1867 = new_actuals_73_3844;
			       old_actuals_174_1866 = old_actuals_174_3843;
			       goto loop_1871;
			    }
			 }
		      }
		 }
	      }
	 }
      }
   }
}


/* node->cop-app-ly */ obj_t 
node__cop_app_ly_235_cgen_capp(obj_t env_2893, obj_t node_2894, obj_t kont_2895)
{
   {
      app_ly_162_t node_1755;
      obj_t kont_1756;
      node_1755 = (app_ly_162_t) (node_2894);
      kont_1756 = kont_2895;
      {
	 node_t value_1760;
	 value_1760 = (((app_ly_162_t) CREF(node_1755))->arg);
	 {
	    local_t vaux_1761;
	    vaux_1761 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 0)), (type_t) (_obj__252_type_cache));
	    {
	       cop_t vcop_1762;
	       {
		  setq_t arg2184_1857;
		  arg2184_1857 = node_setq_243_cgen_cgen((variable_t) (vaux_1761), value_1760);
		  vcop_1762 = node__cop_142_cgen_cgen((node_t) (arg2184_1857), _id_kont__126_cgen_cgen);
	       }
	       {
		  node_t fun_1763;
		  fun_1763 = (((app_ly_162_t) CREF(node_1755))->fun);
		  {
		     local_t faux_1764;
		     faux_1764 = make_local_svar_name_219_cgen_cgen(CNST_TABLE_REF(((long) 1)), (type_t) (_procedure__226_type_cache));
		     {
			cop_t fcop_1765;
			{
			   setq_t arg2182_1855;
			   arg2182_1855 = node_setq_243_cgen_cgen((variable_t) (faux_1764), fun_1763);
			   fcop_1765 = node__cop_142_cgen_cgen((node_t) (arg2182_1855), _id_kont__126_cgen_cgen);
			}
			{
			   {
			      bool_t test2084_1766;
			      {
				 bool_t test2174_1848;
				 test2174_1848 = is_a__118___object((obj_t) (vcop_1762), csetq_cgen_cop);
				 if (test2174_1848)
				   {
				      bool_t test_3868;
				      {
					 obj_t aux_3875;
					 obj_t aux_3869;
					 aux_3875 = (obj_t) (vaux_1761);
					 {
					    variable_t aux_3870;
					    {
					       varc_t arg2181_1854;
					       {
						  csetq_t obj_2444;
						  obj_2444 = (csetq_t) (vcop_1762);
						  arg2181_1854 = (((csetq_t) CREF(obj_2444))->var);
					       }
					       aux_3870 = (((varc_t) CREF(arg2181_1854))->variable);
					    }
					    aux_3869 = (obj_t) (aux_3870);
					 }
					 test_3868 = (aux_3869 == aux_3875);
				      }
				      if (test_3868)
					{
					   bool_t test2176_1850;
					   test2176_1850 = is_a__118___object((obj_t) (fcop_1765), csetq_cgen_cop);
					   if (test2176_1850)
					     {
						obj_t aux_3887;
						obj_t aux_3881;
						aux_3887 = (obj_t) (faux_1764);
						{
						   variable_t aux_3882;
						   {
						      varc_t arg2179_1852;
						      {
							 csetq_t obj_2449;
							 obj_2449 = (csetq_t) (fcop_1765);
							 arg2179_1852 = (((csetq_t) CREF(obj_2449))->var);
						      }
						      aux_3882 = (((varc_t) CREF(arg2179_1852))->variable);
						   }
						   aux_3881 = (obj_t) (aux_3882);
						}
						test2084_1766 = (aux_3881 == aux_3887);
					     }
					   else
					     {
						test2084_1766 = ((bool_t) 0);
					     }
					}
				      else
					{
					   test2084_1766 = ((bool_t) 0);
					}
				   }
				 else
				   {
				      test2084_1766 = ((bool_t) 0);
				   }
			      }
			      if (test2084_1766)
				{
				   {
				      capply_t arg2085_1767;
				      {
					 obj_t arg2086_1768;
					 cop_t arg2087_1769;
					 cop_t arg2088_1770;
					 arg2086_1768 = (((app_ly_162_t) CREF(node_1755))->loc);
					 {
					    csetq_t obj_2454;
					    obj_2454 = (csetq_t) (fcop_1765);
					    arg2087_1769 = (((csetq_t) CREF(obj_2454))->value);
					 }
					 {
					    csetq_t obj_2455;
					    obj_2455 = (csetq_t) (vcop_1762);
					    arg2088_1770 = (((csetq_t) CREF(obj_2455))->value);
					 }
					 {
					    capply_t res2303_2466;
					    {
					       capply_t new1548_2459;
					       new1548_2459 = ((capply_t) BREF(GC_MALLOC(sizeof(struct capply))));
					       {
						  long arg1965_2460;
						  arg1965_2460 = class_num_218___object(capply_cgen_cop);
						  {
						     obj_t obj_2464;
						     obj_2464 = (obj_t) (new1548_2459);
						     (((obj_t) CREF(obj_2464))->header = MAKE_HEADER(arg1965_2460, 0), BUNSPEC);
						  }
					       }
					       {
						  object_t aux_3900;
						  aux_3900 = (object_t) (new1548_2459);
						  OBJECT_WIDENING_SET(aux_3900, BFALSE);
					       }
					       ((((capply_t) CREF(new1548_2459))->loc) = ((obj_t) arg2086_1768), BUNSPEC);
					       ((((capply_t) CREF(new1548_2459))->fun) = ((cop_t) arg2087_1769), BUNSPEC);
					       ((((capply_t) CREF(new1548_2459))->arg) = ((cop_t) arg2088_1770), BUNSPEC);
					       res2303_2466 = new1548_2459;
					    }
					    arg2085_1767 = res2303_2466;
					 }
				      }
				      return PROCEDURE_ENTRY(kont_1756) (kont_1756, (obj_t) (arg2085_1767), BEOA);
				   }
				}
			      else
				{
				   bool_t test2089_1771;
				   {
				      bool_t test2171_1845;
				      test2171_1845 = is_a__118___object((obj_t) (vcop_1762), csetq_cgen_cop);
				      if (test2171_1845)
					{
					   obj_t aux_3918;
					   obj_t aux_3912;
					   aux_3918 = (obj_t) (vaux_1761);
					   {
					      variable_t aux_3913;
					      {
						 varc_t arg2173_1847;
						 {
						    csetq_t obj_2468;
						    obj_2468 = (csetq_t) (vcop_1762);
						    arg2173_1847 = (((csetq_t) CREF(obj_2468))->var);
						 }
						 aux_3913 = (((varc_t) CREF(arg2173_1847))->variable);
					      }
					      aux_3912 = (obj_t) (aux_3913);
					   }
					   test2089_1771 = (aux_3912 == aux_3918);
					}
				      else
					{
					   test2089_1771 = ((bool_t) 0);
					}
				   }
				   if (test2089_1771)
				     {
					{
					   obj_t arg2090_1772;
					   csequence_t arg2091_1773;
					   arg2090_1772 = (((app_ly_162_t) CREF(node_1755))->loc);
					   {
					      obj_t arg2092_1774;
					      {
						 local_var_164_t arg2093_1775;
						 csequence_t arg2094_1776;
						 obj_t arg2095_1777;
						 {
						    obj_t arg2100_1782;
						    obj_t arg2101_1783;
						    arg2100_1782 = (((app_ly_162_t) CREF(node_1755))->loc);
						    {
						       obj_t list2102_1784;
						       {
							  obj_t aux_3924;
							  aux_3924 = (obj_t) (faux_1764);
							  list2102_1784 = MAKE_PAIR(aux_3924, BNIL);
						       }
						       arg2101_1783 = list2102_1784;
						    }
						    {
						       local_var_164_t res2304_2483;
						       {
							  local_var_164_t new1534_2477;
							  new1534_2477 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							  {
							     long arg1972_2478;
							     arg1972_2478 = class_num_218___object(local_var_164_cgen_cop);
							     {
								obj_t obj_2481;
								obj_2481 = (obj_t) (new1534_2477);
								(((obj_t) CREF(obj_2481))->header = MAKE_HEADER(arg1972_2478, 0), BUNSPEC);
							     }
							  }
							  {
							     object_t aux_3931;
							     aux_3931 = (object_t) (new1534_2477);
							     OBJECT_WIDENING_SET(aux_3931, BFALSE);
							  }
							  ((((local_var_164_t) CREF(new1534_2477))->loc) = ((obj_t) arg2100_1782), BUNSPEC);
							  ((((local_var_164_t) CREF(new1534_2477))->vars) = ((obj_t) arg2101_1783), BUNSPEC);
							  res2304_2483 = new1534_2477;
						       }
						       arg2093_1775 = res2304_2483;
						    }
						 }
						 {
						    obj_t arg2105_1786;
						    {
						       obj_t list2106_1787;
						       {
							  obj_t aux_3936;
							  aux_3936 = (obj_t) (fcop_1765);
							  list2106_1787 = MAKE_PAIR(aux_3936, BNIL);
						       }
						       arg2105_1786 = list2106_1787;
						    }
						    {
						       csequence_t res2305_2495;
						       {
							  obj_t loc_2485;
							  loc_2485 = BFALSE;
							  {
							     csequence_t new1501_2488;
							     new1501_2488 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							     {
								long arg1983_2489;
								arg1983_2489 = class_num_218___object(csequence_cgen_cop);
								{
								   obj_t obj_2493;
								   obj_2493 = (obj_t) (new1501_2488);
								   (((obj_t) CREF(obj_2493))->header = MAKE_HEADER(arg1983_2489, 0), BUNSPEC);
								}
							     }
							     {
								object_t aux_3943;
								aux_3943 = (object_t) (new1501_2488);
								OBJECT_WIDENING_SET(aux_3943, loc_2485);
							     }
							     ((((csequence_t) CREF(new1501_2488))->loc) = ((obj_t) loc_2485), BUNSPEC);
							     ((((csequence_t) CREF(new1501_2488))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							     ((((csequence_t) CREF(new1501_2488))->cops) = ((obj_t) arg2105_1786), BUNSPEC);
							     res2305_2495 = new1501_2488;
							  }
						       }
						       arg2094_1776 = res2305_2495;
						    }
						 }
						 {
						    capply_t arg2108_1789;
						    {
						       obj_t arg2109_1790;
						       varc_t arg2111_1791;
						       cop_t arg2112_1792;
						       arg2109_1790 = (((app_ly_162_t) CREF(node_1755))->loc);
						       {
							  varc_t res2306_2505;
							  {
							     obj_t loc_2497;
							     variable_t variable_2498;
							     loc_2497 = BFALSE;
							     variable_2498 = (variable_t) (faux_1764);
							     {
								varc_t new1481_2499;
								new1481_2499 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								{
								   long arg1989_2500;
								   arg1989_2500 = class_num_218___object(varc_cgen_cop);
								   {
								      obj_t obj_2503;
								      obj_2503 = (obj_t) (new1481_2499);
								      (((obj_t) CREF(obj_2503))->header = MAKE_HEADER(arg1989_2500, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_3955;
								   aux_3955 = (object_t) (new1481_2499);
								   OBJECT_WIDENING_SET(aux_3955, loc_2497);
								}
								((((varc_t) CREF(new1481_2499))->loc) = ((obj_t) loc_2497), BUNSPEC);
								((((varc_t) CREF(new1481_2499))->variable) = ((variable_t) variable_2498), BUNSPEC);
								res2306_2505 = new1481_2499;
							     }
							  }
							  arg2111_1791 = res2306_2505;
						       }
						       {
							  csetq_t obj_2506;
							  obj_2506 = (csetq_t) (vcop_1762);
							  arg2112_1792 = (((csetq_t) CREF(obj_2506))->value);
						       }
						       {
							  capply_t res2307_2517;
							  {
							     cop_t fun_2508;
							     fun_2508 = (cop_t) (arg2111_1791);
							     {
								capply_t new1548_2510;
								new1548_2510 = ((capply_t) BREF(GC_MALLOC(sizeof(struct capply))));
								{
								   long arg1965_2511;
								   arg1965_2511 = class_num_218___object(capply_cgen_cop);
								   {
								      obj_t obj_2515;
								      obj_2515 = (obj_t) (new1548_2510);
								      (((obj_t) CREF(obj_2515))->header = MAKE_HEADER(arg1965_2511, 0), BUNSPEC);
								   }
								}
								{
								   object_t aux_3967;
								   aux_3967 = (object_t) (new1548_2510);
								   OBJECT_WIDENING_SET(aux_3967, BFALSE);
								}
								((((capply_t) CREF(new1548_2510))->loc) = ((obj_t) arg2109_1790), BUNSPEC);
								((((capply_t) CREF(new1548_2510))->fun) = ((cop_t) fun_2508), BUNSPEC);
								((((capply_t) CREF(new1548_2510))->arg) = ((cop_t) arg2112_1792), BUNSPEC);
								res2307_2517 = new1548_2510;
							     }
							  }
							  arg2108_1789 = res2307_2517;
						       }
						    }
						    arg2095_1777 = PROCEDURE_ENTRY(kont_1756) (kont_1756, (obj_t) (arg2108_1789), BEOA);
						 }
						 {
						    obj_t list2096_1778;
						    {
						       obj_t arg2097_1779;
						       {
							  obj_t arg2098_1780;
							  arg2098_1780 = MAKE_PAIR(arg2095_1777, BNIL);
							  {
							     obj_t aux_3977;
							     aux_3977 = (obj_t) (arg2094_1776);
							     arg2097_1779 = MAKE_PAIR(aux_3977, arg2098_1780);
							  }
						       }
						       {
							  obj_t aux_3980;
							  aux_3980 = (obj_t) (arg2093_1775);
							  list2096_1778 = MAKE_PAIR(aux_3980, arg2097_1779);
						       }
						    }
						    arg2092_1774 = list2096_1778;
						 }
					      }
					      {
						 csequence_t res2308_2529;
						 {
						    obj_t loc_2519;
						    loc_2519 = BFALSE;
						    {
						       csequence_t new1501_2522;
						       new1501_2522 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
						       {
							  long arg1983_2523;
							  arg1983_2523 = class_num_218___object(csequence_cgen_cop);
							  {
							     obj_t obj_2527;
							     obj_2527 = (obj_t) (new1501_2522);
							     (((obj_t) CREF(obj_2527))->header = MAKE_HEADER(arg1983_2523, 0), BUNSPEC);
							  }
						       }
						       {
							  object_t aux_3987;
							  aux_3987 = (object_t) (new1501_2522);
							  OBJECT_WIDENING_SET(aux_3987, loc_2519);
						       }
						       ((((csequence_t) CREF(new1501_2522))->loc) = ((obj_t) loc_2519), BUNSPEC);
						       ((((csequence_t) CREF(new1501_2522))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
						       ((((csequence_t) CREF(new1501_2522))->cops) = ((obj_t) arg2092_1774), BUNSPEC);
						       res2308_2529 = new1501_2522;
						    }
						 }
						 arg2091_1773 = res2308_2529;
					      }
					   }
					   {
					      block_t res2309_2538;
					      {
						 cop_t body_2531;
						 body_2531 = (cop_t) (arg2091_1773);
						 {
						    block_t new1457_2532;
						    new1457_2532 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
						    {
						       long arg2000_2533;
						       arg2000_2533 = class_num_218___object(block_cgen_cop);
						       {
							  obj_t obj_2536;
							  obj_2536 = (obj_t) (new1457_2532);
							  (((obj_t) CREF(obj_2536))->header = MAKE_HEADER(arg2000_2533, 0), BUNSPEC);
						       }
						    }
						    {
						       object_t aux_3998;
						       aux_3998 = (object_t) (new1457_2532);
						       OBJECT_WIDENING_SET(aux_3998, BFALSE);
						    }
						    ((((block_t) CREF(new1457_2532))->loc) = ((obj_t) arg2090_1772), BUNSPEC);
						    ((((block_t) CREF(new1457_2532))->body) = ((cop_t) body_2531), BUNSPEC);
						    res2309_2538 = new1457_2532;
						 }
					      }
					      return (obj_t) (res2309_2538);
					   }
					}
				     }
				   else
				     {
					bool_t test2114_1794;
					{
					   bool_t test2168_1842;
					   test2168_1842 = is_a__118___object((obj_t) (fcop_1765), csetq_cgen_cop);
					   if (test2168_1842)
					     {
						obj_t aux_4013;
						obj_t aux_4007;
						aux_4013 = (obj_t) (faux_1764);
						{
						   variable_t aux_4008;
						   {
						      varc_t arg2170_1844;
						      {
							 csetq_t obj_2540;
							 obj_2540 = (csetq_t) (fcop_1765);
							 arg2170_1844 = (((csetq_t) CREF(obj_2540))->var);
						      }
						      aux_4008 = (((varc_t) CREF(arg2170_1844))->variable);
						   }
						   aux_4007 = (obj_t) (aux_4008);
						}
						test2114_1794 = (aux_4007 == aux_4013);
					     }
					   else
					     {
						test2114_1794 = ((bool_t) 0);
					     }
					}
					if (test2114_1794)
					  {
					     {
						obj_t arg2115_1795;
						csequence_t arg2116_1796;
						arg2115_1795 = (((app_ly_162_t) CREF(node_1755))->loc);
						{
						   obj_t arg2117_1797;
						   {
						      local_var_164_t arg2120_1798;
						      csequence_t arg2121_1799;
						      obj_t arg2122_1800;
						      {
							 obj_t arg2129_1805;
							 obj_t arg2131_1806;
							 arg2129_1805 = (((app_ly_162_t) CREF(node_1755))->loc);
							 {
							    obj_t list2132_1807;
							    {
							       obj_t aux_4019;
							       aux_4019 = (obj_t) (vaux_1761);
							       list2132_1807 = MAKE_PAIR(aux_4019, BNIL);
							    }
							    arg2131_1806 = list2132_1807;
							 }
							 {
							    local_var_164_t res2310_2555;
							    {
							       local_var_164_t new1534_2549;
							       new1534_2549 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							       {
								  long arg1972_2550;
								  arg1972_2550 = class_num_218___object(local_var_164_cgen_cop);
								  {
								     obj_t obj_2553;
								     obj_2553 = (obj_t) (new1534_2549);
								     (((obj_t) CREF(obj_2553))->header = MAKE_HEADER(arg1972_2550, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_4026;
								  aux_4026 = (object_t) (new1534_2549);
								  OBJECT_WIDENING_SET(aux_4026, BFALSE);
							       }
							       ((((local_var_164_t) CREF(new1534_2549))->loc) = ((obj_t) arg2129_1805), BUNSPEC);
							       ((((local_var_164_t) CREF(new1534_2549))->vars) = ((obj_t) arg2131_1806), BUNSPEC);
							       res2310_2555 = new1534_2549;
							    }
							    arg2120_1798 = res2310_2555;
							 }
						      }
						      {
							 obj_t arg2134_1809;
							 {
							    obj_t list2135_1810;
							    {
							       obj_t aux_4031;
							       aux_4031 = (obj_t) (vcop_1762);
							       list2135_1810 = MAKE_PAIR(aux_4031, BNIL);
							    }
							    arg2134_1809 = list2135_1810;
							 }
							 {
							    csequence_t res2311_2567;
							    {
							       obj_t loc_2557;
							       loc_2557 = BFALSE;
							       {
								  csequence_t new1501_2560;
								  new1501_2560 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
								  {
								     long arg1983_2561;
								     arg1983_2561 = class_num_218___object(csequence_cgen_cop);
								     {
									obj_t obj_2565;
									obj_2565 = (obj_t) (new1501_2560);
									(((obj_t) CREF(obj_2565))->header = MAKE_HEADER(arg1983_2561, 0), BUNSPEC);
								     }
								  }
								  {
								     object_t aux_4038;
								     aux_4038 = (object_t) (new1501_2560);
								     OBJECT_WIDENING_SET(aux_4038, loc_2557);
								  }
								  ((((csequence_t) CREF(new1501_2560))->loc) = ((obj_t) loc_2557), BUNSPEC);
								  ((((csequence_t) CREF(new1501_2560))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
								  ((((csequence_t) CREF(new1501_2560))->cops) = ((obj_t) arg2134_1809), BUNSPEC);
								  res2311_2567 = new1501_2560;
							       }
							    }
							    arg2121_1799 = res2311_2567;
							 }
						      }
						      {
							 capply_t arg2137_1812;
							 {
							    obj_t arg2138_1813;
							    cop_t arg2139_1814;
							    varc_t arg2140_1815;
							    arg2138_1813 = (((app_ly_162_t) CREF(node_1755))->loc);
							    {
							       csetq_t obj_2569;
							       obj_2569 = (csetq_t) (fcop_1765);
							       arg2139_1814 = (((csetq_t) CREF(obj_2569))->value);
							    }
							    {
							       varc_t res2312_2578;
							       {
								  obj_t loc_2570;
								  variable_t variable_2571;
								  loc_2570 = BFALSE;
								  variable_2571 = (variable_t) (vaux_1761);
								  {
								     varc_t new1481_2572;
								     new1481_2572 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								     {
									long arg1989_2573;
									arg1989_2573 = class_num_218___object(varc_cgen_cop);
									{
									   obj_t obj_2576;
									   obj_2576 = (obj_t) (new1481_2572);
									   (((obj_t) CREF(obj_2576))->header = MAKE_HEADER(arg1989_2573, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_4052;
									aux_4052 = (object_t) (new1481_2572);
									OBJECT_WIDENING_SET(aux_4052, loc_2570);
								     }
								     ((((varc_t) CREF(new1481_2572))->loc) = ((obj_t) loc_2570), BUNSPEC);
								     ((((varc_t) CREF(new1481_2572))->variable) = ((variable_t) variable_2571), BUNSPEC);
								     res2312_2578 = new1481_2572;
								  }
							       }
							       arg2140_1815 = res2312_2578;
							    }
							    {
							       capply_t res2313_2589;
							       {
								  cop_t arg_2581;
								  arg_2581 = (cop_t) (arg2140_1815);
								  {
								     capply_t new1548_2582;
								     new1548_2582 = ((capply_t) BREF(GC_MALLOC(sizeof(struct capply))));
								     {
									long arg1965_2583;
									arg1965_2583 = class_num_218___object(capply_cgen_cop);
									{
									   obj_t obj_2587;
									   obj_2587 = (obj_t) (new1548_2582);
									   (((obj_t) CREF(obj_2587))->header = MAKE_HEADER(arg1965_2583, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_4062;
									aux_4062 = (object_t) (new1548_2582);
									OBJECT_WIDENING_SET(aux_4062, BFALSE);
								     }
								     ((((capply_t) CREF(new1548_2582))->loc) = ((obj_t) arg2138_1813), BUNSPEC);
								     ((((capply_t) CREF(new1548_2582))->fun) = ((cop_t) arg2139_1814), BUNSPEC);
								     ((((capply_t) CREF(new1548_2582))->arg) = ((cop_t) arg_2581), BUNSPEC);
								     res2313_2589 = new1548_2582;
								  }
							       }
							       arg2137_1812 = res2313_2589;
							    }
							 }
							 arg2122_1800 = PROCEDURE_ENTRY(kont_1756) (kont_1756, (obj_t) (arg2137_1812), BEOA);
						      }
						      {
							 obj_t list2123_1801;
							 {
							    obj_t arg2124_1802;
							    {
							       obj_t arg2125_1803;
							       arg2125_1803 = MAKE_PAIR(arg2122_1800, BNIL);
							       {
								  obj_t aux_4072;
								  aux_4072 = (obj_t) (arg2121_1799);
								  arg2124_1802 = MAKE_PAIR(aux_4072, arg2125_1803);
							       }
							    }
							    {
							       obj_t aux_4075;
							       aux_4075 = (obj_t) (arg2120_1798);
							       list2123_1801 = MAKE_PAIR(aux_4075, arg2124_1802);
							    }
							 }
							 arg2117_1797 = list2123_1801;
						      }
						   }
						   {
						      csequence_t res2314_2601;
						      {
							 obj_t loc_2591;
							 loc_2591 = BFALSE;
							 {
							    csequence_t new1501_2594;
							    new1501_2594 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							    {
							       long arg1983_2595;
							       arg1983_2595 = class_num_218___object(csequence_cgen_cop);
							       {
								  obj_t obj_2599;
								  obj_2599 = (obj_t) (new1501_2594);
								  (((obj_t) CREF(obj_2599))->header = MAKE_HEADER(arg1983_2595, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_4082;
							       aux_4082 = (object_t) (new1501_2594);
							       OBJECT_WIDENING_SET(aux_4082, loc_2591);
							    }
							    ((((csequence_t) CREF(new1501_2594))->loc) = ((obj_t) loc_2591), BUNSPEC);
							    ((((csequence_t) CREF(new1501_2594))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							    ((((csequence_t) CREF(new1501_2594))->cops) = ((obj_t) arg2117_1797), BUNSPEC);
							    res2314_2601 = new1501_2594;
							 }
						      }
						      arg2116_1796 = res2314_2601;
						   }
						}
						{
						   block_t res2315_2610;
						   {
						      cop_t body_2603;
						      body_2603 = (cop_t) (arg2116_1796);
						      {
							 block_t new1457_2604;
							 new1457_2604 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
							 {
							    long arg2000_2605;
							    arg2000_2605 = class_num_218___object(block_cgen_cop);
							    {
							       obj_t obj_2608;
							       obj_2608 = (obj_t) (new1457_2604);
							       (((obj_t) CREF(obj_2608))->header = MAKE_HEADER(arg2000_2605, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_4093;
							    aux_4093 = (object_t) (new1457_2604);
							    OBJECT_WIDENING_SET(aux_4093, BFALSE);
							 }
							 ((((block_t) CREF(new1457_2604))->loc) = ((obj_t) arg2115_1795), BUNSPEC);
							 ((((block_t) CREF(new1457_2604))->body) = ((cop_t) body_2603), BUNSPEC);
							 res2315_2610 = new1457_2604;
						      }
						   }
						   return (obj_t) (res2315_2610);
						}
					     }
					  }
					else
					  {
					     {
						obj_t arg2143_1817;
						csequence_t arg2144_1818;
						arg2143_1817 = (((app_ly_162_t) CREF(node_1755))->loc);
						{
						   obj_t arg2145_1819;
						   {
						      local_var_164_t arg2146_1820;
						      csequence_t arg2147_1821;
						      obj_t arg2148_1822;
						      {
							 obj_t arg2153_1827;
							 obj_t arg2154_1828;
							 arg2153_1827 = (((app_ly_162_t) CREF(node_1755))->loc);
							 {
							    obj_t list2155_1829;
							    {
							       obj_t arg2156_1830;
							       {
								  obj_t aux_4101;
								  aux_4101 = (obj_t) (vaux_1761);
								  arg2156_1830 = MAKE_PAIR(aux_4101, BNIL);
							       }
							       {
								  obj_t aux_4104;
								  aux_4104 = (obj_t) (faux_1764);
								  list2155_1829 = MAKE_PAIR(aux_4104, arg2156_1830);
							       }
							    }
							    arg2154_1828 = list2155_1829;
							 }
							 {
							    local_var_164_t res2316_2622;
							    {
							       local_var_164_t new1534_2616;
							       new1534_2616 = ((local_var_164_t) BREF(GC_MALLOC(sizeof(struct local_var_164))));
							       {
								  long arg1972_2617;
								  arg1972_2617 = class_num_218___object(local_var_164_cgen_cop);
								  {
								     obj_t obj_2620;
								     obj_2620 = (obj_t) (new1534_2616);
								     (((obj_t) CREF(obj_2620))->header = MAKE_HEADER(arg1972_2617, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_4111;
								  aux_4111 = (object_t) (new1534_2616);
								  OBJECT_WIDENING_SET(aux_4111, BFALSE);
							       }
							       ((((local_var_164_t) CREF(new1534_2616))->loc) = ((obj_t) arg2153_1827), BUNSPEC);
							       ((((local_var_164_t) CREF(new1534_2616))->vars) = ((obj_t) arg2154_1828), BUNSPEC);
							       res2316_2622 = new1534_2616;
							    }
							    arg2146_1820 = res2316_2622;
							 }
						      }
						      {
							 obj_t arg2158_1832;
							 {
							    obj_t list2159_1833;
							    {
							       obj_t arg2160_1834;
							       {
								  obj_t aux_4116;
								  aux_4116 = (obj_t) (vcop_1762);
								  arg2160_1834 = MAKE_PAIR(aux_4116, BNIL);
							       }
							       {
								  obj_t aux_4119;
								  aux_4119 = (obj_t) (fcop_1765);
								  list2159_1833 = MAKE_PAIR(aux_4119, arg2160_1834);
							       }
							    }
							    arg2158_1832 = list2159_1833;
							 }
							 {
							    csequence_t res2317_2634;
							    {
							       obj_t loc_2624;
							       loc_2624 = BFALSE;
							       {
								  csequence_t new1501_2627;
								  new1501_2627 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
								  {
								     long arg1983_2628;
								     arg1983_2628 = class_num_218___object(csequence_cgen_cop);
								     {
									obj_t obj_2632;
									obj_2632 = (obj_t) (new1501_2627);
									(((obj_t) CREF(obj_2632))->header = MAKE_HEADER(arg1983_2628, 0), BUNSPEC);
								     }
								  }
								  {
								     object_t aux_4126;
								     aux_4126 = (object_t) (new1501_2627);
								     OBJECT_WIDENING_SET(aux_4126, loc_2624);
								  }
								  ((((csequence_t) CREF(new1501_2627))->loc) = ((obj_t) loc_2624), BUNSPEC);
								  ((((csequence_t) CREF(new1501_2627))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
								  ((((csequence_t) CREF(new1501_2627))->cops) = ((obj_t) arg2158_1832), BUNSPEC);
								  res2317_2634 = new1501_2627;
							       }
							    }
							    arg2147_1821 = res2317_2634;
							 }
						      }
						      {
							 capply_t arg2162_1836;
							 {
							    obj_t arg2163_1837;
							    varc_t arg2164_1838;
							    varc_t arg2165_1839;
							    arg2163_1837 = (((app_ly_162_t) CREF(node_1755))->loc);
							    {
							       varc_t res2318_2644;
							       {
								  obj_t loc_2636;
								  variable_t variable_2637;
								  loc_2636 = BFALSE;
								  variable_2637 = (variable_t) (faux_1764);
								  {
								     varc_t new1481_2638;
								     new1481_2638 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								     {
									long arg1989_2639;
									arg1989_2639 = class_num_218___object(varc_cgen_cop);
									{
									   obj_t obj_2642;
									   obj_2642 = (obj_t) (new1481_2638);
									   (((obj_t) CREF(obj_2642))->header = MAKE_HEADER(arg1989_2639, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_4138;
									aux_4138 = (object_t) (new1481_2638);
									OBJECT_WIDENING_SET(aux_4138, loc_2636);
								     }
								     ((((varc_t) CREF(new1481_2638))->loc) = ((obj_t) loc_2636), BUNSPEC);
								     ((((varc_t) CREF(new1481_2638))->variable) = ((variable_t) variable_2637), BUNSPEC);
								     res2318_2644 = new1481_2638;
								  }
							       }
							       arg2164_1838 = res2318_2644;
							    }
							    {
							       varc_t res2319_2653;
							       {
								  obj_t loc_2645;
								  variable_t variable_2646;
								  loc_2645 = BFALSE;
								  variable_2646 = (variable_t) (vaux_1761);
								  {
								     varc_t new1481_2647;
								     new1481_2647 = ((varc_t) BREF(GC_MALLOC(sizeof(struct varc))));
								     {
									long arg1989_2648;
									arg1989_2648 = class_num_218___object(varc_cgen_cop);
									{
									   obj_t obj_2651;
									   obj_2651 = (obj_t) (new1481_2647);
									   (((obj_t) CREF(obj_2651))->header = MAKE_HEADER(arg1989_2648, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_4148;
									aux_4148 = (object_t) (new1481_2647);
									OBJECT_WIDENING_SET(aux_4148, loc_2645);
								     }
								     ((((varc_t) CREF(new1481_2647))->loc) = ((obj_t) loc_2645), BUNSPEC);
								     ((((varc_t) CREF(new1481_2647))->variable) = ((variable_t) variable_2646), BUNSPEC);
								     res2319_2653 = new1481_2647;
								  }
							       }
							       arg2165_1839 = res2319_2653;
							    }
							    {
							       capply_t res2320_2664;
							       {
								  cop_t fun_2655;
								  cop_t arg_2656;
								  fun_2655 = (cop_t) (arg2164_1838);
								  arg_2656 = (cop_t) (arg2165_1839);
								  {
								     capply_t new1548_2657;
								     new1548_2657 = ((capply_t) BREF(GC_MALLOC(sizeof(struct capply))));
								     {
									long arg1965_2658;
									arg1965_2658 = class_num_218___object(capply_cgen_cop);
									{
									   obj_t obj_2662;
									   obj_2662 = (obj_t) (new1548_2657);
									   (((obj_t) CREF(obj_2662))->header = MAKE_HEADER(arg1965_2658, 0), BUNSPEC);
									}
								     }
								     {
									object_t aux_4159;
									aux_4159 = (object_t) (new1548_2657);
									OBJECT_WIDENING_SET(aux_4159, BFALSE);
								     }
								     ((((capply_t) CREF(new1548_2657))->loc) = ((obj_t) arg2163_1837), BUNSPEC);
								     ((((capply_t) CREF(new1548_2657))->fun) = ((cop_t) fun_2655), BUNSPEC);
								     ((((capply_t) CREF(new1548_2657))->arg) = ((cop_t) arg_2656), BUNSPEC);
								     res2320_2664 = new1548_2657;
								  }
							       }
							       arg2162_1836 = res2320_2664;
							    }
							 }
							 arg2148_1822 = PROCEDURE_ENTRY(kont_1756) (kont_1756, (obj_t) (arg2162_1836), BEOA);
						      }
						      {
							 obj_t list2149_1823;
							 {
							    obj_t arg2150_1824;
							    {
							       obj_t arg2151_1825;
							       arg2151_1825 = MAKE_PAIR(arg2148_1822, BNIL);
							       {
								  obj_t aux_4169;
								  aux_4169 = (obj_t) (arg2147_1821);
								  arg2150_1824 = MAKE_PAIR(aux_4169, arg2151_1825);
							       }
							    }
							    {
							       obj_t aux_4172;
							       aux_4172 = (obj_t) (arg2146_1820);
							       list2149_1823 = MAKE_PAIR(aux_4172, arg2150_1824);
							    }
							 }
							 arg2145_1819 = list2149_1823;
						      }
						   }
						   {
						      csequence_t res2321_2676;
						      {
							 obj_t loc_2666;
							 loc_2666 = BFALSE;
							 {
							    csequence_t new1501_2669;
							    new1501_2669 = ((csequence_t) BREF(GC_MALLOC(sizeof(struct csequence))));
							    {
							       long arg1983_2670;
							       arg1983_2670 = class_num_218___object(csequence_cgen_cop);
							       {
								  obj_t obj_2674;
								  obj_2674 = (obj_t) (new1501_2669);
								  (((obj_t) CREF(obj_2674))->header = MAKE_HEADER(arg1983_2670, 0), BUNSPEC);
							       }
							    }
							    {
							       object_t aux_4179;
							       aux_4179 = (object_t) (new1501_2669);
							       OBJECT_WIDENING_SET(aux_4179, loc_2666);
							    }
							    ((((csequence_t) CREF(new1501_2669))->loc) = ((obj_t) loc_2666), BUNSPEC);
							    ((((csequence_t) CREF(new1501_2669))->c_exp__163) = ((bool_t) ((bool_t) 0)), BUNSPEC);
							    ((((csequence_t) CREF(new1501_2669))->cops) = ((obj_t) arg2145_1819), BUNSPEC);
							    res2321_2676 = new1501_2669;
							 }
						      }
						      arg2144_1818 = res2321_2676;
						   }
						}
						{
						   block_t res2322_2685;
						   {
						      cop_t body_2678;
						      body_2678 = (cop_t) (arg2144_1818);
						      {
							 block_t new1457_2679;
							 new1457_2679 = ((block_t) BREF(GC_MALLOC(sizeof(struct block))));
							 {
							    long arg2000_2680;
							    arg2000_2680 = class_num_218___object(block_cgen_cop);
							    {
							       obj_t obj_2683;
							       obj_2683 = (obj_t) (new1457_2679);
							       (((obj_t) CREF(obj_2683))->header = MAKE_HEADER(arg2000_2680, 0), BUNSPEC);
							    }
							 }
							 {
							    object_t aux_4190;
							    aux_4190 = (object_t) (new1457_2679);
							    OBJECT_WIDENING_SET(aux_4190, BFALSE);
							 }
							 ((((block_t) CREF(new1457_2679))->loc) = ((obj_t) arg2143_1817), BUNSPEC);
							 ((((block_t) CREF(new1457_2679))->body) = ((cop_t) body_2678), BUNSPEC);
							 res2322_2685 = new1457_2679;
						      }
						   }
						   return (obj_t) (res2322_2685);
						}
					     }
					  }
				     }
				}
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cgen_capp()
{
   module_initialization_70_tools_trace(((long) 0), "CGEN_CAPP");
   module_initialization_70_tools_error(((long) 0), "CGEN_CAPP");
   module_initialization_70_tools_shape(((long) 0), "CGEN_CAPP");
   module_initialization_70_type_type(((long) 0), "CGEN_CAPP");
   module_initialization_70_type_tools(((long) 0), "CGEN_CAPP");
   module_initialization_70_type_cache(((long) 0), "CGEN_CAPP");
   module_initialization_70_ast_var(((long) 0), "CGEN_CAPP");
   module_initialization_70_ast_node(((long) 0), "CGEN_CAPP");
   module_initialization_70_ast_local(((long) 0), "CGEN_CAPP");
   module_initialization_70_effect_effect(((long) 0), "CGEN_CAPP");
   module_initialization_70_cgen_emit(((long) 0), "CGEN_CAPP");
   module_initialization_70_cgen_cop(((long) 0), "CGEN_CAPP");
   return module_initialization_70_cgen_cgen(((long) 0), "CGEN_CAPP");
}
