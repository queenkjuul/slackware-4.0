/*===========================================================================*/
/*   (Reduce/typec.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


static obj_t _node_typec__214_reduce_typec(obj_t, obj_t);
static obj_t method_init_76_reduce_typec();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static node_t node_typec__103_reduce_typec(node_t);
extern obj_t type_type_type;
extern obj_t box_ref_242_ast_node;
static long _type_checks_remaining__47_reduce_typec;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t lvtype_node__58_ast_lvtype(node_t);
extern obj_t _obj__252_type_cache;
extern obj_t pragma_ast_node;
static node_t node_typec__default1489_123_reduce_typec(node_t);
extern obj_t set_ex_it_116_ast_node;
extern bool_t type_subclass__90_object_class(type_t, type_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_typec(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t _reduce_type_check__78_reduce_typec(obj_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_reduce_typec();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static long _type_checks_removed__34_reduce_typec;
extern node_t coerce__182_coerce_coerce(node_t, type_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_reduce_typec();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_reduce_typec();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern bool_t side_effect__165_effect_effect(node_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern type_t typeof_coerce_typeof(node_t);
static obj_t _node_typec__default1489_19_reduce_typec(obj_t, obj_t);
extern obj_t reduce_type_check__95_reduce_typec(obj_t);
static obj_t node_typec___130_reduce_typec(obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_reduce_typec = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_reduce_typec();
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(reduce_type_check__env_147_reduce_typec, _reduce_type_check__78_reduce_typec1781, _reduce_type_check__78_reduce_typec, 0L, 1);
DEFINE_STRING(string1775_reduce_typec, string1775_reduce_typec1782, "NODE-TYPEC!-DEFAULT1489 DONE ", 29);
DEFINE_STRING(string1774_reduce_typec, string1774_reduce_typec1783, "No method for this object", 25);
DEFINE_STRING(string1773_reduce_typec, string1773_reduce_typec1784, "(remaining : ", 13);
DEFINE_STRING(string1772_reduce_typec, string1772_reduce_typec1785, "(removed : ", 11);
DEFINE_STRING(string1771_reduce_typec, string1771_reduce_typec1786, ")\t", 2);
DEFINE_STRING(string1770_reduce_typec, string1770_reduce_typec1787, "      type check             ", 29);
DEFINE_STATIC_GENERIC(node_typec__env_21_reduce_typec, _node_typec__214_reduce_typec1788, _node_typec__214_reduce_typec, 0L, 1);
DEFINE_STATIC_PROCEDURE(node_typec__default1489_env_229_reduce_typec, _node_typec__default1489_19_reduce_typec1789, _node_typec__default1489_19_reduce_typec, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_reduce_typec(long checksum_1537, char *from_1538)
{
   if (CBOOL(require_initialization_114_reduce_typec))
     {
	require_initialization_114_reduce_typec = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_typec();
	cnst_init_137_reduce_typec();
	imported_modules_init_94_reduce_typec();
	method_init_76_reduce_typec();
	toplevel_init_63_reduce_typec();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_typec()
{
   module_initialization_70___object(((long) 0), "REDUCE_TYPEC");
   module_initialization_70___reader(((long) 0), "REDUCE_TYPEC");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_typec()
{
   {
      obj_t cnst_port_138_1529;
      cnst_port_138_1529 = open_input_string(string1775_reduce_typec);
      {
	 long i_1530;
	 i_1530 = ((long) 1);
       loop_1531:
	 {
	    bool_t test1776_1532;
	    test1776_1532 = (i_1530 == ((long) -1));
	    if (test1776_1532)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1777_1533;
		    {
		       obj_t list1778_1534;
		       {
			  obj_t arg1779_1535;
			  arg1779_1535 = BNIL;
			  list1778_1534 = MAKE_PAIR(cnst_port_138_1529, arg1779_1535);
		       }
		       arg1777_1533 = read___reader(list1778_1534);
		    }
		    CNST_TABLE_SET(i_1530, arg1777_1533);
		 }
		 {
		    int aux_1536;
		    {
		       long aux_1555;
		       aux_1555 = (i_1530 - ((long) 1));
		       aux_1536 = (int) (aux_1555);
		    }
		    {
		       long i_1558;
		       i_1558 = (long) (aux_1536);
		       i_1530 = i_1558;
		       goto loop_1531;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_reduce_typec()
{
   _type_checks_remaining__47_reduce_typec = ((long) 0);
   _type_checks_removed__34_reduce_typec = ((long) 0);
   return BUNSPEC;
}


/* reduce-type-check! */ obj_t 
reduce_type_check__95_reduce_typec(obj_t globals_1)
{
   {
      obj_t list1513_791;
      list1513_791 = MAKE_PAIR(string1770_reduce_typec, BNIL);
      verbose_tools_speek(BINT(((long) 2)), list1513_791);
   }
   {
      obj_t l1462_794;
      l1462_794 = globals_1;
    lname1463_795:
      if (PAIRP(l1462_794))
	{
	   {
	      value_t fun_798;
	      {
		 global_t obj_1322;
		 {
		    obj_t aux_1565;
		    aux_1565 = CAR(l1462_794);
		    obj_1322 = (global_t) (aux_1565);
		 }
		 fun_798 = (((global_t) CREF(obj_1322))->value);
	      }
	      {
		 {
		    node_t arg1517_800;
		    {
		       node_t aux_1569;
		       {
			  obj_t aux_1570;
			  {
			     sfun_t obj_1323;
			     obj_1323 = (sfun_t) (fun_798);
			     aux_1570 = (((sfun_t) CREF(obj_1323))->body);
			  }
			  aux_1569 = (node_t) (aux_1570);
		       }
		       arg1517_800 = node_typec__103_reduce_typec(aux_1569);
		    }
		    {
		       sfun_t obj_1324;
		       obj_t val1136_1325;
		       obj_1324 = (sfun_t) (fun_798);
		       val1136_1325 = (obj_t) (arg1517_800);
		       ((((sfun_t) CREF(obj_1324))->body) = ((obj_t) val1136_1325), BUNSPEC);
		    }
		 }
		 BUNSPEC;
	      }
	   }
	   {
	      obj_t l1462_1578;
	      l1462_1578 = CDR(l1462_794);
	      l1462_794 = l1462_1578;
	      goto lname1463_795;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t list1519_802;
      {
	 obj_t arg1524_804;
	 {
	    obj_t arg1525_805;
	    arg1525_805 = MAKE_PAIR(string1771_reduce_typec, BNIL);
	    {
	       obj_t aux_1581;
	       aux_1581 = BINT(_type_checks_removed__34_reduce_typec);
	       arg1524_804 = MAKE_PAIR(aux_1581, arg1525_805);
	    }
	 }
	 list1519_802 = MAKE_PAIR(string1772_reduce_typec, arg1524_804);
      }
      verbose_tools_speek(BINT(((long) 2)), list1519_802);
   }
   {
      obj_t list1528_808;
      {
	 obj_t arg1530_810;
	 {
	    obj_t arg1531_811;
	    {
	       obj_t arg1532_812;
	       {
		  obj_t aux_1587;
		  aux_1587 = BCHAR(((unsigned char) '\n'));
		  arg1532_812 = MAKE_PAIR(aux_1587, BNIL);
	       }
	       {
		  obj_t aux_1590;
		  aux_1590 = BCHAR(((unsigned char) ')'));
		  arg1531_811 = MAKE_PAIR(aux_1590, arg1532_812);
	       }
	    }
	    {
	       obj_t aux_1593;
	       aux_1593 = BINT(_type_checks_remaining__47_reduce_typec);
	       arg1530_810 = MAKE_PAIR(aux_1593, arg1531_811);
	    }
	 }
	 list1528_808 = MAKE_PAIR(string1773_reduce_typec, arg1530_810);
      }
      verbose_tools_speek(BINT(((long) 2)), list1528_808);
   }
   return globals_1;
}


/* _reduce-type-check! */ obj_t 
_reduce_type_check__78_reduce_typec(obj_t env_1523, obj_t globals_1524)
{
   return reduce_type_check__95_reduce_typec(globals_1524);
}


/* node-typec*! */ obj_t 
node_typec___130_reduce_typec(obj_t node__221_24)
{
   {
      obj_t node__221_814;
      node__221_814 = node__221_24;
    loop_815:
      if (NULLP(node__221_814))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   {
	      node_t arg1535_817;
	      {
		 node_t aux_1603;
		 {
		    obj_t aux_1604;
		    aux_1604 = CAR(node__221_814);
		    aux_1603 = (node_t) (aux_1604);
		 }
		 arg1535_817 = node_typec__103_reduce_typec(aux_1603);
	      }
	      {
		 obj_t aux_1608;
		 aux_1608 = (obj_t) (arg1535_817);
		 SET_CAR(node__221_814, aux_1608);
	      }
	   }
	   {
	      obj_t node__221_1611;
	      node__221_1611 = CDR(node__221_814);
	      node__221_814 = node__221_1611;
	      goto loop_815;
	   }
	}
   }
}


/* method-init */ obj_t 
method_init_76_reduce_typec()
{
   add_generic__110___object(node_typec__env_21_reduce_typec, node_typec__default1489_env_229_reduce_typec);
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, select_ast_node, ((long) 12));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, box_set__221_ast_node, ((long) 18));
   add_inlined_method__244___object(node_typec__env_21_reduce_typec, box_ref_242_ast_node, ((long) 19));
   {
      long aux_1634;
      aux_1634 = add_inlined_method__244___object(node_typec__env_21_reduce_typec, app_ast_node, ((long) 20));
      return BINT(aux_1634);
   }
}


/* node-typec! */ node_t 
node_typec__103_reduce_typec(node_t node_2)
{
   {
      obj_t method1646_1165;
      obj_t class1651_1166;
      {
	 obj_t arg1654_1163;
	 obj_t arg1655_1164;
	 {
	    object_t obj_1363;
	    obj_1363 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1364;
	       pre_method_105_1364 = PROCEDURE_REF(node_typec__env_21_reduce_typec, ((long) 2));
	       if (INTEGERP(pre_method_105_1364))
		 {
		    PROCEDURE_SET(node_typec__env_21_reduce_typec, ((long) 2), BUNSPEC);
		    arg1654_1163 = pre_method_105_1364;
		 }
	       else
		 {
		    long obj_class_num_177_1369;
		    obj_class_num_177_1369 = TYPE(obj_1363);
		    {
		       obj_t arg1177_1370;
		       arg1177_1370 = PROCEDURE_REF(node_typec__env_21_reduce_typec, ((long) 1));
		       {
			  long arg1178_1374;
			  {
			     long arg1179_1375;
			     arg1179_1375 = OBJECT_TYPE;
			     arg1178_1374 = (obj_class_num_177_1369 - arg1179_1375);
			  }
			  arg1654_1163 = VECTOR_REF(arg1177_1370, arg1178_1374);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1380;
	    object_1380 = (object_t) (node_2);
	    {
	       long arg1180_1381;
	       {
		  long arg1181_1382;
		  long arg1182_1383;
		  arg1181_1382 = TYPE(object_1380);
		  arg1182_1383 = OBJECT_TYPE;
		  arg1180_1381 = (arg1181_1382 - arg1182_1383);
	       }
	       {
		  obj_t vector_1387;
		  vector_1387 = _classes__134___object;
		  arg1655_1164 = VECTOR_REF(vector_1387, arg1180_1381);
	       }
	    }
	 }
	 {
	    obj_t aux_1652;
	    method1646_1165 = arg1654_1163;
	    class1651_1166 = arg1655_1164;
	    {
	       if (INTEGERP(method1646_1165))
		 {
		    switch ((long) CINT(method1646_1165))
		      {
		      case ((long) 0):
			 {
			    atom_t aux_1655;
			    aux_1655 = (atom_t) (node_2);
			    aux_1652 = (obj_t) (aux_1655);
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t aux_1658;
			    aux_1658 = (kwote_t) (node_2);
			    aux_1652 = (obj_t) (aux_1658);
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_1661;
			    aux_1661 = (var_t) (node_2);
			    aux_1652 = (obj_t) (aux_1661);
			 }
			 break;
		      case ((long) 3):
			 {
			    closure_t aux_1664;
			    aux_1664 = (closure_t) (node_2);
			    aux_1652 = (obj_t) (aux_1664);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1176;
			    node_1176 = (sequence_t) (node_2);
			    node_typec___130_reduce_typec((((sequence_t) CREF(node_1176))->nodes));
			    aux_1652 = (obj_t) (node_1176);
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1179;
			    node_1179 = (app_ly_162_t) (node_2);
			    {
			       node_t arg1659_1181;
			       arg1659_1181 = node_typec__103_reduce_typec((((app_ly_162_t) CREF(node_1179))->fun));
			       ((((app_ly_162_t) CREF(node_1179))->fun) = ((node_t) arg1659_1181), BUNSPEC);
			    }
			    {
			       node_t arg1663_1183;
			       arg1663_1183 = node_typec__103_reduce_typec((((app_ly_162_t) CREF(node_1179))->arg));
			       ((((app_ly_162_t) CREF(node_1179))->arg) = ((node_t) arg1663_1183), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1179);
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1185;
			    node_1185 = (funcall_t) (node_2);
			    {
			       node_t arg1666_1187;
			       arg1666_1187 = node_typec__103_reduce_typec((((funcall_t) CREF(node_1185))->fun));
			       ((((funcall_t) CREF(node_1185))->fun) = ((node_t) arg1666_1187), BUNSPEC);
			    }
			    node_typec___130_reduce_typec((((funcall_t) CREF(node_1185))->args));
			    aux_1652 = (obj_t) (node_1185);
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1190;
			    node_1190 = (pragma_t) (node_2);
			    node_typec___130_reduce_typec((((pragma_t) CREF(node_1190))->args));
			    aux_1652 = (obj_t) (node_1190);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1193;
			    node_1193 = (cast_t) (node_2);
			    node_typec__103_reduce_typec((((cast_t) CREF(node_1193))->arg));
			    aux_1652 = (obj_t) (node_1193);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1196;
			    node_1196 = (setq_t) (node_2);
			    {
			       node_t arg1672_1198;
			       arg1672_1198 = node_typec__103_reduce_typec((((setq_t) CREF(node_1196))->value));
			       ((((setq_t) CREF(node_1196))->value) = ((node_t) arg1672_1198), BUNSPEC);
			    }
			    {
			       node_t arg1675_1200;
			       {
				  node_t aux_1698;
				  {
				     var_t aux_1699;
				     aux_1699 = (((setq_t) CREF(node_1196))->var);
				     aux_1698 = (node_t) (aux_1699);
				  }
				  arg1675_1200 = node_typec__103_reduce_typec(aux_1698);
			       }
			       {
				  var_t val1307_1407;
				  val1307_1407 = (var_t) (arg1675_1200);
				  ((((setq_t) CREF(node_1196))->var) = ((var_t) val1307_1407), BUNSPEC);
			       }
			    }
			    aux_1652 = (obj_t) (node_1196);
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1202;
			    node_1202 = (conditional_t) (node_2);
			    {
			       node_t arg1677_1204;
			       arg1677_1204 = node_typec__103_reduce_typec((((conditional_t) CREF(node_1202))->test));
			       ((((conditional_t) CREF(node_1202))->test) = ((node_t) arg1677_1204), BUNSPEC);
			    }
			    {
			       node_t arg1679_1206;
			       arg1679_1206 = node_typec__103_reduce_typec((((conditional_t) CREF(node_1202))->true));
			       ((((conditional_t) CREF(node_1202))->true) = ((node_t) arg1679_1206), BUNSPEC);
			    }
			    {
			       node_t arg1681_1208;
			       arg1681_1208 = node_typec__103_reduce_typec((((conditional_t) CREF(node_1202))->false));
			       ((((conditional_t) CREF(node_1202))->false) = ((node_t) arg1681_1208), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1202);
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1210;
			    node_1210 = (fail_t) (node_2);
			    {
			       node_t arg1683_1212;
			       arg1683_1212 = node_typec__103_reduce_typec((((fail_t) CREF(node_1210))->proc));
			       ((((fail_t) CREF(node_1210))->proc) = ((node_t) arg1683_1212), BUNSPEC);
			    }
			    {
			       node_t arg1685_1214;
			       arg1685_1214 = node_typec__103_reduce_typec((((fail_t) CREF(node_1210))->msg));
			       ((((fail_t) CREF(node_1210))->msg) = ((node_t) arg1685_1214), BUNSPEC);
			    }
			    {
			       node_t arg1688_1216;
			       arg1688_1216 = node_typec__103_reduce_typec((((fail_t) CREF(node_1210))->obj));
			       ((((fail_t) CREF(node_1210))->obj) = ((node_t) arg1688_1216), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1210);
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1218;
			    node_1218 = (select_t) (node_2);
			    {
			       node_t arg1691_1220;
			       arg1691_1220 = node_typec__103_reduce_typec((((select_t) CREF(node_1218))->test));
			       ((((select_t) CREF(node_1218))->test) = ((node_t) arg1691_1220), BUNSPEC);
			    }
			    {
			       obj_t l1473_1222;
			       l1473_1222 = (((select_t) CREF(node_1218))->clauses);
			     lname1474_1223:
			       if (PAIRP(l1473_1222))
				 {
				    {
				       obj_t clause_1226;
				       clause_1226 = CAR(l1473_1222);
				       {
					  node_t arg1695_1227;
					  {
					     node_t aux_1735;
					     {
						obj_t aux_1736;
						aux_1736 = CDR(clause_1226);
						aux_1735 = (node_t) (aux_1736);
					     }
					     arg1695_1227 = node_typec__103_reduce_typec(aux_1735);
					  }
					  {
					     obj_t aux_1740;
					     aux_1740 = (obj_t) (arg1695_1227);
					     SET_CDR(clause_1226, aux_1740);
					  }
				       }
				    }
				    {
				       obj_t l1473_1743;
				       l1473_1743 = CDR(l1473_1222);
				       l1473_1222 = l1473_1743;
				       goto lname1474_1223;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1652 = (obj_t) (node_1218);
			 }
			 break;
		      case ((long) 13):
			 {
			    let_fun_218_t node_1230;
			    node_1230 = (let_fun_218_t) (node_2);
			    {
			       obj_t l1476_1232;
			       l1476_1232 = (((let_fun_218_t) CREF(node_1230))->locals);
			     lname1477_1233:
			       if (PAIRP(l1476_1232))
				 {
				    {
				       value_t fun_1237;
				       {
					  local_t obj_1439;
					  {
					     obj_t aux_1750;
					     aux_1750 = CAR(l1476_1232);
					     obj_1439 = (local_t) (aux_1750);
					  }
					  fun_1237 = (((local_t) CREF(obj_1439))->value);
				       }
				       {
					  node_t arg1701_1238;
					  {
					     node_t aux_1754;
					     {
						obj_t aux_1755;
						{
						   sfun_t obj_1440;
						   obj_1440 = (sfun_t) (fun_1237);
						   aux_1755 = (((sfun_t) CREF(obj_1440))->body);
						}
						aux_1754 = (node_t) (aux_1755);
					     }
					     arg1701_1238 = node_typec__103_reduce_typec(aux_1754);
					  }
					  {
					     sfun_t obj_1441;
					     obj_t val1136_1442;
					     obj_1441 = (sfun_t) (fun_1237);
					     val1136_1442 = (obj_t) (arg1701_1238);
					     ((((sfun_t) CREF(obj_1441))->body) = ((obj_t) val1136_1442), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l1476_1763;
				       l1476_1763 = CDR(l1476_1232);
				       l1476_1232 = l1476_1763;
				       goto lname1477_1233;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1704_1241;
			       arg1704_1241 = node_typec__103_reduce_typec((((let_fun_218_t) CREF(node_1230))->body));
			       ((((let_fun_218_t) CREF(node_1230))->body) = ((node_t) arg1704_1241), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1230);
			 }
			 break;
		      case ((long) 14):
			 {
			    let_var_6_t node_1243;
			    node_1243 = (let_var_6_t) (node_2);
			    {
			       obj_t l1479_1245;
			       l1479_1245 = (((let_var_6_t) CREF(node_1243))->bindings);
			     lname1480_1246:
			       if (PAIRP(l1479_1245))
				 {
				    {
				       obj_t binding_1249;
				       binding_1249 = CAR(l1479_1245);
				       {
					  node_t arg1708_1250;
					  {
					     node_t aux_1774;
					     {
						obj_t aux_1775;
						aux_1775 = CDR(binding_1249);
						aux_1774 = (node_t) (aux_1775);
					     }
					     arg1708_1250 = node_typec__103_reduce_typec(aux_1774);
					  }
					  {
					     obj_t aux_1779;
					     aux_1779 = (obj_t) (arg1708_1250);
					     SET_CDR(binding_1249, aux_1779);
					  }
				       }
				    }
				    {
				       obj_t l1479_1782;
				       l1479_1782 = CDR(l1479_1245);
				       l1479_1245 = l1479_1782;
				       goto lname1480_1246;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1711_1253;
			       arg1711_1253 = node_typec__103_reduce_typec((((let_var_6_t) CREF(node_1243))->body));
			       ((((let_var_6_t) CREF(node_1243))->body) = ((node_t) arg1711_1253), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1243);
			 }
			 break;
		      case ((long) 15):
			 {
			    set_ex_it_116_t node_1255;
			    node_1255 = (set_ex_it_116_t) (node_2);
			    {
			       node_t arg1713_1257;
			       arg1713_1257 = node_typec__103_reduce_typec((((set_ex_it_116_t) CREF(node_1255))->body));
			       ((((set_ex_it_116_t) CREF(node_1255))->body) = ((node_t) arg1713_1257), BUNSPEC);
			    }
			    {
			       node_t arg1716_1259;
			       {
				  node_t aux_1793;
				  {
				     var_t aux_1794;
				     aux_1794 = (((set_ex_it_116_t) CREF(node_1255))->var);
				     aux_1793 = (node_t) (aux_1794);
				  }
				  arg1716_1259 = node_typec__103_reduce_typec(aux_1793);
			       }
			       {
				  var_t val1389_1462;
				  val1389_1462 = (var_t) (arg1716_1259);
				  ((((set_ex_it_116_t) CREF(node_1255))->var) = ((var_t) val1389_1462), BUNSPEC);
			       }
			    }
			    aux_1652 = (obj_t) (node_1255);
			 }
			 break;
		      case ((long) 16):
			 {
			    jump_ex_it_184_t node_1261;
			    node_1261 = (jump_ex_it_184_t) (node_2);
			    {
			       node_t arg1718_1263;
			       arg1718_1263 = node_typec__103_reduce_typec((((jump_ex_it_184_t) CREF(node_1261))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1261))->exit) = ((node_t) arg1718_1263), BUNSPEC);
			    }
			    {
			       node_t arg1721_1265;
			       arg1721_1265 = node_typec__103_reduce_typec((((jump_ex_it_184_t) CREF(node_1261))->value));
			       ((((jump_ex_it_184_t) CREF(node_1261))->value) = ((node_t) arg1721_1265), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1261);
			 }
			 break;
		      case ((long) 17):
			 {
			    make_box_202_t node_1267;
			    node_1267 = (make_box_202_t) (node_2);
			    {
			       node_t arg1723_1269;
			       arg1723_1269 = node_typec__103_reduce_typec((((make_box_202_t) CREF(node_1267))->value));
			       ((((make_box_202_t) CREF(node_1267))->value) = ((node_t) arg1723_1269), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1267);
			 }
			 break;
		      case ((long) 18):
			 {
			    box_set__221_t node_1271;
			    node_1271 = (box_set__221_t) (node_2);
			    {
			       node_t arg1725_1273;
			       {
				  node_t aux_1815;
				  {
				     var_t aux_1816;
				     aux_1816 = (((box_set__221_t) CREF(node_1271))->var);
				     aux_1815 = (node_t) (aux_1816);
				  }
				  arg1725_1273 = node_typec__103_reduce_typec(aux_1815);
			       }
			       {
				  var_t val1433_1474;
				  val1433_1474 = (var_t) (arg1725_1273);
				  ((((box_set__221_t) CREF(node_1271))->var) = ((var_t) val1433_1474), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1727_1275;
			       arg1727_1275 = node_typec__103_reduce_typec((((box_set__221_t) CREF(node_1271))->value));
			       ((((box_set__221_t) CREF(node_1271))->value) = ((node_t) arg1727_1275), BUNSPEC);
			    }
			    aux_1652 = (obj_t) (node_1271);
			 }
			 break;
		      case ((long) 19):
			 {
			    box_ref_242_t node_1277;
			    node_1277 = (box_ref_242_t) (node_2);
			    {
			       node_t arg1729_1279;
			       {
				  node_t aux_1827;
				  {
				     var_t aux_1828;
				     aux_1828 = (((box_ref_242_t) CREF(node_1277))->var);
				     aux_1827 = (node_t) (aux_1828);
				  }
				  arg1729_1279 = node_typec__103_reduce_typec(aux_1827);
			       }
			       {
				  var_t val1424_1480;
				  val1424_1480 = (var_t) (arg1729_1279);
				  ((((box_ref_242_t) CREF(node_1277))->var) = ((var_t) val1424_1480), BUNSPEC);
			       }
			    }
			    aux_1652 = (obj_t) (node_1277);
			 }
			 break;
		      case ((long) 20):
			 {
			    app_t node_1281;
			    node_1281 = (app_t) (node_2);
			    node_typec___130_reduce_typec((((app_t) CREF(node_1281))->args));
			    {
			       variable_t var_1284;
			       {
				  var_t arg1762_1310;
				  arg1762_1310 = (((app_t) CREF(node_1281))->fun);
				  var_1284 = (((var_t) CREF(arg1762_1310))->variable);
			       }
			       {
				  obj_t typec_1285;
				  {
				     fun_t obj_1485;
				     {
					value_t aux_1840;
					aux_1840 = (((variable_t) CREF(var_1284))->value);
					obj_1485 = (fun_t) (aux_1840);
				     }
				     typec_1285 = (((fun_t) CREF(obj_1485))->predicate_of_78);
				  }
				  {
				     type_t type_1286;
				     type_1286 = typeof_coerce_typeof((node_t) (node_1281));
				     {
					{
					   bool_t test1732_1287;
					   {
					      bool_t test_1846;
					      {
						 obj_t aux_1847;
						 aux_1847 = (((app_t) CREF(node_1281))->args);
						 test_1846 = PAIRP(aux_1847);
					      }
					      if (test_1846)
						{
						   bool_t test_1850;
						   {
						      obj_t aux_1851;
						      {
							 obj_t aux_1852;
							 aux_1852 = (((app_t) CREF(node_1281))->args);
							 aux_1851 = CDR(aux_1852);
						      }
						      test_1850 = NULLP(aux_1851);
						   }
						   if (test_1850)
						     {
							bool_t test1749_1302;
							test1749_1302 = is_a__118___object(typec_1285, type_type_type);
							if (test1749_1302)
							  {
							     bool_t test1750_1303;
							     {
								node_t aux_1858;
								{
								   obj_t aux_1859;
								   {
								      obj_t aux_1860;
								      aux_1860 = (((app_t) CREF(node_1281))->args);
								      aux_1859 = CAR(aux_1860);
								   }
								   aux_1858 = (node_t) (aux_1859);
								}
								test1750_1303 = side_effect__165_effect_effect(aux_1858);
							     }
							     if (test1750_1303)
							       {
								  test1732_1287 = ((bool_t) 0);
							       }
							     else
							       {
								  test1732_1287 = ((bool_t) 1);
							       }
							  }
							else
							  {
							     test1732_1287 = ((bool_t) 0);
							  }
						     }
						   else
						     {
							test1732_1287 = ((bool_t) 0);
						     }
						}
					      else
						{
						   test1732_1287 = ((bool_t) 0);
						}
					   }
					   if (test1732_1287)
					     {
						type_t typep_1288;
						{
						   node_t aux_1867;
						   {
						      obj_t aux_1868;
						      {
							 obj_t aux_1869;
							 aux_1869 = (((app_t) CREF(node_1281))->args);
							 aux_1868 = CAR(aux_1869);
						      }
						      aux_1867 = (node_t) (aux_1868);
						   }
						   typep_1288 = typeof_coerce_typeof(aux_1867);
						}
						{
						   bool_t test1733_1289;
						   {
						      bool_t test1744_1297;
						      {
							 obj_t obj2_1497;
							 obj2_1497 = _obj__252_type_cache;
							 {
							    obj_t aux_1874;
							    aux_1874 = (obj_t) (typep_1288);
							    test1744_1297 = (aux_1874 == obj2_1497);
							 }
						      }
						      if (test1744_1297)
							{
							   test1733_1289 = ((bool_t) 1);
							}
						      else
							{
							   test1733_1289 = type_subclass__90_object_class((type_t) (typec_1285), typep_1288);
							}
						   }
						   if (test1733_1289)
						     {
							{
							   long z2_1499;
							   z2_1499 = _type_checks_remaining__47_reduce_typec;
							   _type_checks_remaining__47_reduce_typec = (((long) 1) + z2_1499);
							}
							aux_1652 = (obj_t) (node_1281);
						     }
						   else
						     {
							{
							   long z2_1501;
							   z2_1501 = _type_checks_removed__34_reduce_typec;
							   _type_checks_removed__34_reduce_typec = (((long) 1) + z2_1501);
							}
							{
							   bool_t check_val_123_1290;
							   {
							      bool_t _ortest_1487_1296;
							      {
								 obj_t aux_1884;
								 aux_1884 = (obj_t) (typep_1288);
								 _ortest_1487_1296 = (typec_1285 == aux_1884);
							      }
							      if (_ortest_1487_1296)
								{
								   check_val_123_1290 = _ortest_1487_1296;
								}
							      else
								{
								   check_val_123_1290 = type_subclass__90_object_class(typep_1288, (type_t) (typec_1285));
								}
							   }
							   {
							      node_t node_1291;
							      {
								 atom_t arg1738_1292;
								 {
								    obj_t arg1739_1293;
								    arg1739_1293 = (((app_t) CREF(node_1281))->loc);
								    {
								       atom_t res1768_1515;
								       {
									  obj_t value_1507;
									  value_1507 = BBOOL(check_val_123_1290);
									  {
									     atom_t new1199_1508;
									     new1199_1508 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
									     {
										long arg1600_1509;
										arg1600_1509 = class_num_218___object(atom_ast_node);
										{
										   obj_t obj_1513;
										   obj_1513 = (obj_t) (new1199_1508);
										   (((obj_t) CREF(obj_1513))->header = MAKE_HEADER(arg1600_1509, 0), BUNSPEC);
										}
									     }
									     {
										object_t aux_1896;
										aux_1896 = (object_t) (new1199_1508);
										OBJECT_WIDENING_SET(aux_1896, BFALSE);
									     }
									     ((((atom_t) CREF(new1199_1508))->loc) = ((obj_t) arg1739_1293), BUNSPEC);
									     ((((atom_t) CREF(new1199_1508))->type) = ((type_t) type_1286), BUNSPEC);
									     ((((atom_t) CREF(new1199_1508))->value) = ((obj_t) value_1507), BUNSPEC);
									     res1768_1515 = new1199_1508;
									  }
								       }
								       arg1738_1292 = res1768_1515;
								    }
								 }
								 node_1291 = coerce__182_coerce_coerce((node_t) (arg1738_1292), type_1286);
							      }
							      lvtype_node__58_ast_lvtype(node_1291);
							      aux_1652 = (obj_t) (node_1291);
							   }
							}
						     }
						}
					     }
					   else
					     {
						aux_1652 = (obj_t) (node_1281);
					     }
					}
				     }
				  }
			       }
			    }
			 }
			 break;
		      default:
		       case_else1652_1169:
			 if (PROCEDUREP(method1646_1165))
			   {
			      aux_1652 = PROCEDURE_ENTRY(method1646_1165) (method1646_1165, (obj_t) (node_2), BEOA);
			   }
			 else
			   {
			      obj_t fun1640_1159;
			      fun1640_1159 = PROCEDURE_REF(node_typec__env_21_reduce_typec, ((long) 0));
			      aux_1652 = PROCEDURE_ENTRY(fun1640_1159) (fun1640_1159, (obj_t) (node_2), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1652_1169;
		 }
	    }
	    return (node_t) (aux_1652);
	 }
      }
   }
}


/* _node-typec! */ obj_t 
_node_typec__214_reduce_typec(obj_t env_1525, obj_t node_1526)
{
   {
      node_t aux_1919;
      aux_1919 = node_typec__103_reduce_typec((node_t) (node_1526));
      return (obj_t) (aux_1919);
   }
}


/* node-typec!-default1489 */ node_t 
node_typec__default1489_123_reduce_typec(node_t node_3)
{
   FAILURE(CNST_TABLE_REF(((long) 1)), string1774_reduce_typec, (obj_t) (node_3));
}


/* _node-typec!-default1489 */ obj_t 
_node_typec__default1489_19_reduce_typec(obj_t env_1527, obj_t node_1528)
{
   {
      node_t aux_1926;
      aux_1926 = node_typec__default1489_123_reduce_typec((node_t) (node_1528));
      return (obj_t) (aux_1926);
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_typec()
{
   module_initialization_70_tools_trace(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_tools_speek(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_tools_error(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_type_type(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_type_cache(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_coerce_typeof(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_coerce_coerce(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_effect_effect(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_ast_var(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_ast_node(((long) 0), "REDUCE_TYPEC");
   module_initialization_70_ast_lvtype(((long) 0), "REDUCE_TYPEC");
   return module_initialization_70_object_class(((long) 0), "REDUCE_TYPEC");
}
