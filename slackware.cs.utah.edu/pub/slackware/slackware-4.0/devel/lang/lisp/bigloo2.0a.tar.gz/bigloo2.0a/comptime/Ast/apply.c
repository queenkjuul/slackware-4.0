/*===========================================================================*/
/*   (Ast/apply.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_apply();
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern node_t known_app_ly__node_26_ast_apply(obj_t, obj_t, node_t, node_t, obj_t);
extern obj_t find_location_loc_243_tools_location(obj_t, obj_t);
static obj_t make_fun_frame_37_ast_apply(fun_t);
extern obj_t type_type_type;
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern node_t application__node_43_ast_app(obj_t, obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t make_fun_frame_default1463_221_ast_apply(fun_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_ast_apply(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_location(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_sexp(long, char *);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_ast_app(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern node_t applycation__node_122_ast_apply(obj_t, obj_t, obj_t, obj_t);
extern obj_t _unsafe_arity__240_engine_param;
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t fun_ast_var;
static obj_t imported_modules_init_94_ast_apply();
extern obj_t app_ly_162_ast_node;
extern obj_t cfun_ast_var;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t loop_1940_ast_apply(obj_t, node_t, obj_t, obj_t, local_t, type_t, obj_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_ast_apply();
static obj_t toplevel_init_63_ast_apply();
extern node_t sexp__node_235_ast_sexp(obj_t, obj_t, obj_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t sfun_ast_var;
static obj_t _known_app_ly__node1938_240_ast_apply(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern node_t error_sexp__node_157_ast_sexp(obj_t, obj_t, obj_t);
static obj_t loop_ast_apply(node_t, obj_t, obj_t, local_t, type_t, obj_t, obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t _make_fun_frame1939_139_ast_apply(obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static let_var_6_t fx_known_app_ly__node_158_ast_apply(obj_t, obj_t, node_t, node_t, obj_t, obj_t);
extern obj_t ____74_type_cache;
static obj_t require_initialization_114_ast_apply = BUNSPEC;
static obj_t _make_fun_frame_default1463_46_ast_apply(obj_t, obj_t);
static obj_t _applycation__node1937_104_ast_apply(obj_t, obj_t, obj_t, obj_t, obj_t);
static let_var_6_t va_known_app_ly__node_104_ast_apply(obj_t, obj_t, node_t, node_t, obj_t, obj_t);
static obj_t cnst_init_137_ast_apply();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t __cnst[14];

DEFINE_EXPORT_PROCEDURE(known_app_ly__node_env_252_ast_apply, _known_app_ly__node1938_240_ast_apply1951, _known_app_ly__node1938_240_ast_apply, 0L, 5);
DEFINE_STATIC_GENERIC(make_fun_frame_env_121_ast_apply, _make_fun_frame1939_139_ast_apply1952, _make_fun_frame1939_139_ast_apply, 0L, 1);
DEFINE_EXPORT_PROCEDURE(applycation__node_env_238_ast_apply, _applycation__node1937_104_ast_apply1953, _applycation__node1937_104_ast_apply, 0L, 4);
DEFINE_STRING(string1945_ast_apply, string1945_ast_apply1954, "MAKE-FUN-FRAME-DEFAULT1463 AUX SET! BEGIN CAR QUOTE FAILURE CDR NULL? IF WRITE RUNNER VALUE APPLY ", 98);
DEFINE_STRING(string1944_ast_apply, string1944_ast_apply1955, "No method for this object", 25);
DEFINE_STRING(string1943_ast_apply, string1943_ast_apply1956, "apply", 5);
DEFINE_STRING(string1942_ast_apply, string1942_ast_apply1957, "Too many arguments provided", 27);
DEFINE_STRING(string1941_ast_apply, string1941_ast_apply1958, "Illegal `apply' form", 20);
DEFINE_STATIC_PROCEDURE(make_fun_frame_default1463_env_4_ast_apply, _make_fun_frame_default1463_46_ast_apply1959, _make_fun_frame_default1463_46_ast_apply, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_ast_apply(long checksum_1860, char *from_1861)
{
   if (CBOOL(require_initialization_114_ast_apply))
     {
	require_initialization_114_ast_apply = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_apply();
	cnst_init_137_ast_apply();
	imported_modules_init_94_ast_apply();
	method_init_76_ast_apply();
	toplevel_init_63_ast_apply();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_apply()
{
   module_initialization_70___object(((long) 0), "AST_APPLY");
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_APPLY");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_APPLY");
   module_initialization_70___reader(((long) 0), "AST_APPLY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_apply()
{
   {
      obj_t cnst_port_138_1852;
      cnst_port_138_1852 = open_input_string(string1945_ast_apply);
      {
	 long i_1853;
	 i_1853 = ((long) 13);
       loop_1854:
	 {
	    bool_t test1946_1855;
	    test1946_1855 = (i_1853 == ((long) -1));
	    if (test1946_1855)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1947_1856;
		    {
		       obj_t list1948_1857;
		       {
			  obj_t arg1949_1858;
			  arg1949_1858 = BNIL;
			  list1948_1857 = MAKE_PAIR(cnst_port_138_1852, arg1949_1858);
		       }
		       arg1947_1856 = read___reader(list1948_1857);
		    }
		    CNST_TABLE_SET(i_1853, arg1947_1856);
		 }
		 {
		    int aux_1859;
		    {
		       long aux_1880;
		       aux_1880 = (i_1853 - ((long) 1));
		       aux_1859 = (int) (aux_1880);
		    }
		    {
		       long i_1883;
		       i_1883 = (long) (aux_1859);
		       i_1853 = i_1883;
		       goto loop_1854;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_apply()
{
   return BUNSPEC;
}


/* applycation->node */ node_t 
applycation__node_122_ast_apply(obj_t exp_1, obj_t stack_2, obj_t loc_3, obj_t site_4)
{
   {
      obj_t proc_723;
      obj_t arg_724;
      if (PAIRP(exp_1))
	{
	   obj_t cdr_109_69_729;
	   cdr_109_69_729 = CDR(exp_1);
	   {
	      bool_t test_1888;
	      {
		 obj_t aux_1891;
		 obj_t aux_1889;
		 aux_1891 = CNST_TABLE_REF(((long) 0));
		 aux_1889 = CAR(exp_1);
		 test_1888 = (aux_1889 == aux_1891);
	      }
	      if (test_1888)
		{
		   if (PAIRP(cdr_109_69_729))
		     {
			obj_t cdr_113_28_732;
			cdr_113_28_732 = CDR(cdr_109_69_729);
			if (PAIRP(cdr_113_28_732))
			  {
			     bool_t test_1899;
			     {
				obj_t aux_1900;
				aux_1900 = CDR(cdr_113_28_732);
				test_1899 = (aux_1900 == BNIL);
			     }
			     if (test_1899)
			       {
				  obj_t aux_1903;
				  proc_723 = CAR(cdr_109_69_729);
				  arg_724 = CAR(cdr_113_28_732);
				  {
				     obj_t loc_741;
				     loc_741 = find_location_loc_243_tools_location(exp_1, loc_3);
				     {
					node_t proc_742;
					{
					   obj_t arg1489_754;
					   obj_t arg1490_755;
					   arg1489_754 = find_location_loc_243_tools_location(proc_723, loc_741);
					   arg1490_755 = CNST_TABLE_REF(((long) 0));
					   proc_742 = sexp__node_235_ast_sexp(proc_723, stack_2, arg1489_754, arg1490_755);
					}
					{
					   node_t arg_743;
					   {
					      obj_t arg1487_752;
					      obj_t arg1488_753;
					      arg1487_752 = find_location_loc_243_tools_location(arg_724, loc_741);
					      arg1488_753 = CNST_TABLE_REF(((long) 1));
					      arg_743 = sexp__node_235_ast_sexp(arg_724, stack_2, arg1487_752, arg1488_753);
					   }
					   {
					      {
						 bool_t test1478_744;
						 {
						    bool_t test1484_749;
						    test1484_749 = is_a__118___object((obj_t) (proc_742), var_ast_node);
						    if (test1484_749)
						      {
							 obj_t aux_1914;
							 {
							    value_t aux_1915;
							    {
							       variable_t arg1486_751;
							       {
								  var_t obj_1413;
								  obj_1413 = (var_t) (proc_742);
								  arg1486_751 = (((var_t) CREF(obj_1413))->variable);
							       }
							       aux_1915 = (((variable_t) CREF(arg1486_751))->value);
							    }
							    aux_1914 = (obj_t) (aux_1915);
							 }
							 test1478_744 = is_a__118___object(aux_1914, fun_ast_var);
						      }
						    else
						      {
							 test1478_744 = ((bool_t) 0);
						      }
						 }
						 if (test1478_744)
						   {
						      node_t aux_1922;
						      aux_1922 = known_app_ly__node_26_ast_apply(stack_2, loc_741, proc_742, arg_743, site_4);
						      aux_1903 = (obj_t) (aux_1922);
						   }
						 else
						   {
						      obj_t arg1480_746;
						      arg1480_746 = ____74_type_cache;
						      {
							 app_ly_162_t res1920_1428;
							 {
							    type_t type_1417;
							    type_1417 = (type_t) (arg1480_746);
							    {
							       app_ly_162_t new1256_1420;
							       new1256_1420 = ((app_ly_162_t) BREF(GC_MALLOC(sizeof(struct app_ly_162))));
							       {
								  long arg1813_1421;
								  arg1813_1421 = class_num_218___object(app_ly_162_ast_node);
								  {
								     obj_t obj_1426;
								     obj_1426 = (obj_t) (new1256_1420);
								     (((obj_t) CREF(obj_1426))->header = MAKE_HEADER(arg1813_1421, 0), BUNSPEC);
								  }
							       }
							       {
								  object_t aux_1930;
								  aux_1930 = (object_t) (new1256_1420);
								  OBJECT_WIDENING_SET(aux_1930, BFALSE);
							       }
							       ((((app_ly_162_t) CREF(new1256_1420))->loc) = ((obj_t) loc_741), BUNSPEC);
							       ((((app_ly_162_t) CREF(new1256_1420))->type) = ((type_t) type_1417), BUNSPEC);
							       ((((app_ly_162_t) CREF(new1256_1420))->fun) = ((node_t) proc_742), BUNSPEC);
							       ((((app_ly_162_t) CREF(new1256_1420))->arg) = ((node_t) arg_743), BUNSPEC);
							       res1920_1428 = new1256_1420;
							    }
							 }
							 aux_1903 = (obj_t) (res1920_1428);
						      }
						   }
					      }
					   }
					}
				     }
				  }
				  return (node_t) (aux_1903);
			       }
			     else
			       {
				tag_102_241_726:
				  {
				     obj_t arg1494_757;
				     arg1494_757 = find_location_loc_243_tools_location(exp_1, loc_3);
				     return error_sexp__node_157_ast_sexp(string1941_ast_apply, exp_1, arg1494_757);
				  }
			       }
			  }
			else
			  {
			     goto tag_102_241_726;
			  }
		     }
		   else
		     {
			goto tag_102_241_726;
		     }
		}
	      else
		{
		   goto tag_102_241_726;
		}
	   }
	}
      else
	{
	   goto tag_102_241_726;
	}
   }
}


/* _applycation->node1937 */ obj_t 
_applycation__node1937_104_ast_apply(obj_t env_1822, obj_t exp_1823, obj_t stack_1824, obj_t loc_1825, obj_t site_1826)
{
   {
      node_t aux_1943;
      aux_1943 = applycation__node_122_ast_apply(exp_1823, stack_1824, loc_1825, site_1826);
      return (obj_t) (aux_1943);
   }
}


/* known-app-ly->node */ node_t 
known_app_ly__node_26_ast_apply(obj_t stack_9, obj_t loc_10, node_t proc_11, node_t arg_12, obj_t site_13)
{
   {
      value_t fun_758;
      {
	 variable_t arg1497_763;
	 {
	    var_t obj_1429;
	    obj_1429 = (var_t) (proc_11);
	    arg1497_763 = (((var_t) CREF(obj_1429))->variable);
	 }
	 fun_758 = (((variable_t) CREF(arg1497_763))->value);
      }
      {
	 long arity_759;
	 {
	    fun_t obj_1431;
	    obj_1431 = (fun_t) (fun_758);
	    arity_759 = (((fun_t) CREF(obj_1431))->arity);
	 }
	 {
	    obj_t frame_760;
	    frame_760 = make_fun_frame_37_ast_apply((fun_t) (fun_758));
	    {
	       if ((arity_759 > ((long) 0)))
		 {
		    {
		       let_var_6_t aux_1955;
		       aux_1955 = fx_known_app_ly__node_158_ast_apply(stack_9, loc_10, proc_11, arg_12, frame_760, site_13);
		       return (node_t) (aux_1955);
		    }
		 }
	       else
		 {
		    if ((arity_759 == ((long) 0)))
		      {
			 {
			    obj_t arg1498_1442;
			    {
			       obj_t list1499_1443;
			       {
				  obj_t aux_1960;
				  aux_1960 = (obj_t) (proc_11);
				  list1499_1443 = MAKE_PAIR(aux_1960, BNIL);
			       }
			       arg1498_1442 = list1499_1443;
			    }
			    return sexp__node_235_ast_sexp(arg1498_1442, stack_9, loc_10, site_13);
			 }
		      }
		    else
		      {
			 {
			    let_var_6_t aux_1964;
			    aux_1964 = va_known_app_ly__node_104_ast_apply(stack_9, loc_10, proc_11, arg_12, frame_760, site_13);
			    return (node_t) (aux_1964);
			 }
		      }
		 }
	    }
	 }
      }
   }
}


/* _known-app-ly->node1938 */ obj_t 
_known_app_ly__node1938_240_ast_apply(obj_t env_1827, obj_t stack_1828, obj_t loc_1829, obj_t proc_1830, obj_t arg_1831, obj_t site_1832)
{
   {
      node_t aux_1967;
      aux_1967 = known_app_ly__node_26_ast_apply(stack_1828, loc_1829, (node_t) (proc_1830), (node_t) (arg_1831), site_1832);
      return (obj_t) (aux_1967);
   }
}


/* fx-known-app-ly->node */ let_var_6_t 
fx_known_app_ly__node_158_ast_apply(obj_t stack_20, obj_t loc_21, node_t proc_22, node_t arg_23, obj_t frame_24, obj_t site_25)
{
   {
      local_t runner_767;
      type_t type_768;
      {
	 obj_t arg1665_905;
	 {
	    obj_t arg1666_906;
	    arg1666_906 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
	    arg1665_905 = mark_symbol_non_user__17_ast_ident(arg1666_906);
	 }
	 runner_767 = make_local_svar_140_ast_local(arg1665_905, (type_t) (____74_type_cache));
      }
      type_768 = (((node_t) CREF(proc_22))->type);
      {
	 obj_t arg1501_769;
	 arg1501_769 = CNST_TABLE_REF(((long) 3));
	 ((((local_t) CREF(runner_767))->access) = ((obj_t) arg1501_769), BUNSPEC);
      }
      {
	 obj_t arg1505_773;
	 obj_t arg1507_774;
	 {
	    obj_t arg1510_775;
	    {
	       obj_t aux_1983;
	       obj_t aux_1981;
	       aux_1983 = (obj_t) (arg_23);
	       aux_1981 = (obj_t) (runner_767);
	       arg1510_775 = MAKE_PAIR(aux_1981, aux_1983);
	    }
	    {
	       obj_t list1511_776;
	       list1511_776 = MAKE_PAIR(arg1510_775, BNIL);
	       arg1505_773 = list1511_776;
	    }
	 }
	 arg1507_774 = loop_1940_ast_apply(site_25, proc_22, frame_24, stack_20, runner_767, type_768, loc_21, frame_24);
	 {
	    let_var_6_t res1927_1574;
	    {
	       obj_t key_1559;
	       node_t body_1561;
	       key_1559 = BINT(((long) -1));
	       body_1561 = (node_t) (arg1507_774);
	       {
		  let_var_6_t new1365_1563;
		  new1365_1563 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		  {
		     long arg1793_1564;
		     arg1793_1564 = class_num_218___object(let_var_6_ast_node);
		     {
			obj_t obj_1572;
			obj_1572 = (obj_t) (new1365_1563);
			(((obj_t) CREF(obj_1572))->header = MAKE_HEADER(arg1793_1564, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_1994;
		     aux_1994 = (object_t) (new1365_1563);
		     OBJECT_WIDENING_SET(aux_1994, BFALSE);
		  }
		  ((((let_var_6_t) CREF(new1365_1563))->loc) = ((obj_t) loc_21), BUNSPEC);
		  ((((let_var_6_t) CREF(new1365_1563))->type) = ((type_t) type_768), BUNSPEC);
		  ((((let_var_6_t) CREF(new1365_1563))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		  ((((let_var_6_t) CREF(new1365_1563))->key) = ((obj_t) key_1559), BUNSPEC);
		  ((((let_var_6_t) CREF(new1365_1563))->bindings) = ((obj_t) arg1505_773), BUNSPEC);
		  ((((let_var_6_t) CREF(new1365_1563))->body) = ((node_t) body_1561), BUNSPEC);
		  ((((let_var_6_t) CREF(new1365_1563))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		  res1927_1574 = new1365_1563;
	       }
	    }
	    return res1927_1574;
	 }
      }
   }
}


/* loop_1940 */ obj_t 
loop_1940_ast_apply(obj_t site_1851, node_t proc_1850, obj_t frame_1849, obj_t stack_1848, local_t runner_1847, type_t type_1846, obj_t loc_1845, obj_t locals_778)
{
   if (NULLP(locals_778))
     {
	node_t app_781;
	{
	   obj_t arg1566_824;
	   obj_t arg1568_825;
	   {
	      obj_t arg1569_826;
	      {
		 obj_t arg1573_829;
		 obj_t arg1575_830;
		 if (NULLP(frame_1849))
		   {
		      arg1573_829 = BNIL;
		   }
		 else
		   {
		      obj_t head1439_833;
		      head1439_833 = MAKE_PAIR(BNIL, BNIL);
		      {
			 obj_t l1437_834;
			 obj_t tail1440_835;
			 l1437_834 = frame_1849;
			 tail1440_835 = head1439_833;
		       lname1438_836:
			 if (NULLP(l1437_834))
			   {
			      arg1573_829 = CDR(head1439_833);
			   }
			 else
			   {
			      obj_t newtail1441_838;
			      {
				 var_t arg1580_840;
				 {
				    obj_t local_842;
				    local_842 = CAR(l1437_834);
				    {
				       type_t arg1583_844;
				       {
					  local_t obj_1463;
					  obj_1463 = (local_t) (local_842);
					  arg1583_844 = (((local_t) CREF(obj_1463))->type);
				       }
				       {
					  var_t res1921_1474;
					  {
					     variable_t variable_1466;
					     variable_1466 = (variable_t) (local_842);
					     {
						var_t new1206_1467;
						new1206_1467 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
						{
						   long arg1824_1468;
						   arg1824_1468 = class_num_218___object(var_ast_node);
						   {
						      obj_t obj_1472;
						      obj_1472 = (obj_t) (new1206_1467);
						      (((obj_t) CREF(obj_1472))->header = MAKE_HEADER(arg1824_1468, 0), BUNSPEC);
						   }
						}
						{
						   object_t aux_2020;
						   aux_2020 = (object_t) (new1206_1467);
						   OBJECT_WIDENING_SET(aux_2020, BFALSE);
						}
						((((var_t) CREF(new1206_1467))->loc) = ((obj_t) loc_1845), BUNSPEC);
						((((var_t) CREF(new1206_1467))->type) = ((type_t) arg1583_844), BUNSPEC);
						((((var_t) CREF(new1206_1467))->variable) = ((variable_t) variable_1466), BUNSPEC);
						res1921_1474 = new1206_1467;
					     }
					  }
					  arg1580_840 = res1921_1474;
				       }
				    }
				 }
				 {
				    obj_t aux_2026;
				    aux_2026 = (obj_t) (arg1580_840);
				    newtail1441_838 = MAKE_PAIR(aux_2026, BNIL);
				 }
			      }
			      SET_CDR(tail1440_835, newtail1441_838);
			      {
				 obj_t tail1440_2032;
				 obj_t l1437_2030;
				 l1437_2030 = CDR(l1437_834);
				 tail1440_2032 = newtail1441_838;
				 tail1440_835 = tail1440_2032;
				 l1437_834 = l1437_2030;
				 goto lname1438_836;
			      }
			   }
		      }
		   }
		 arg1575_830 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
		 arg1569_826 = append_2_18___r4_pairs_and_lists_6_3(arg1573_829, arg1575_830);
	      }
	      {
		 obj_t list1570_827;
		 list1570_827 = MAKE_PAIR(arg1569_826, BNIL);
		 arg1566_824 = cons__138___r4_pairs_and_lists_6_3((obj_t) (proc_1850), list1570_827);
	      }
	   }
	   arg1568_825 = CNST_TABLE_REF(((long) 1));
	   app_781 = application__node_43_ast_app(arg1566_824, stack_1848, loc_1845, arg1568_825);
	}
	if (CBOOL(_unsafe_arity__240_engine_param))
	  {
	     return (obj_t) (app_781);
	  }
	else
	  {
	     obj_t arg1515_782;
	     {
		obj_t arg1516_783;
		obj_t arg1517_784;
		obj_t arg1518_785;
		arg1516_783 = CNST_TABLE_REF(((long) 4));
		{
		   obj_t arg1527_792;
		   obj_t arg1528_793;
		   arg1527_792 = CNST_TABLE_REF(((long) 5));
		   {
		      obj_t arg1533_798;
		      var_t arg1534_799;
		      arg1533_798 = CNST_TABLE_REF(((long) 6));
		      {
			 type_t arg1542_805;
			 arg1542_805 = (((local_t) CREF(runner_1847))->type);
			 {
			    var_t res1922_1491;
			    {
			       variable_t variable_1483;
			       variable_1483 = (variable_t) (runner_1847);
			       {
				  var_t new1206_1484;
				  new1206_1484 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				  {
				     long arg1824_1485;
				     arg1824_1485 = class_num_218___object(var_ast_node);
				     {
					obj_t obj_1489;
					obj_1489 = (obj_t) (new1206_1484);
					(((obj_t) CREF(obj_1489))->header = MAKE_HEADER(arg1824_1485, 0), BUNSPEC);
				     }
				  }
				  {
				     object_t aux_2052;
				     aux_2052 = (object_t) (new1206_1484);
				     OBJECT_WIDENING_SET(aux_2052, BFALSE);
				  }
				  ((((var_t) CREF(new1206_1484))->loc) = ((obj_t) loc_1845), BUNSPEC);
				  ((((var_t) CREF(new1206_1484))->type) = ((type_t) arg1542_805), BUNSPEC);
				  ((((var_t) CREF(new1206_1484))->variable) = ((variable_t) variable_1483), BUNSPEC);
				  res1922_1491 = new1206_1484;
			       }
			    }
			    arg1534_799 = res1922_1491;
			 }
		      }
		      {
			 obj_t list1536_801;
			 {
			    obj_t arg1537_802;
			    arg1537_802 = MAKE_PAIR(BNIL, BNIL);
			    {
			       obj_t aux_2059;
			       aux_2059 = (obj_t) (arg1534_799);
			       list1536_801 = MAKE_PAIR(aux_2059, arg1537_802);
			    }
			 }
			 arg1528_793 = cons__138___r4_pairs_and_lists_6_3(arg1533_798, list1536_801);
		      }
		   }
		   {
		      obj_t list1530_795;
		      {
			 obj_t arg1531_796;
			 arg1531_796 = MAKE_PAIR(BNIL, BNIL);
			 list1530_795 = MAKE_PAIR(arg1528_793, arg1531_796);
		      }
		      arg1517_784 = cons__138___r4_pairs_and_lists_6_3(arg1527_792, list1530_795);
		   }
		}
		{
		   obj_t arg1548_807;
		   obj_t arg1552_810;
		   arg1548_807 = CNST_TABLE_REF(((long) 7));
		   {
		      obj_t arg1559_817;
		      obj_t arg1560_818;
		      arg1559_817 = CNST_TABLE_REF(((long) 8));
		      {
			 obj_t aux_2068;
			 {
			    variable_t aux_2069;
			    {
			       var_t obj_1492;
			       obj_1492 = (var_t) (proc_1850);
			       aux_2069 = (((var_t) CREF(obj_1492))->variable);
			    }
			    aux_2068 = (obj_t) (aux_2069);
			 }
			 arg1560_818 = shape_tools_shape(aux_2068);
		      }
		      {
			 obj_t list1562_820;
			 {
			    obj_t arg1563_821;
			    arg1563_821 = MAKE_PAIR(BNIL, BNIL);
			    list1562_820 = MAKE_PAIR(arg1560_818, arg1563_821);
			 }
			 arg1552_810 = cons__138___r4_pairs_and_lists_6_3(arg1559_817, list1562_820);
		      }
		   }
		   {
		      obj_t list1554_812;
		      {
			 obj_t arg1555_813;
			 {
			    obj_t arg1556_814;
			    {
			       obj_t arg1557_815;
			       arg1557_815 = MAKE_PAIR(BNIL, BNIL);
			       arg1556_814 = MAKE_PAIR(arg1552_810, arg1557_815);
			    }
			    arg1555_813 = MAKE_PAIR(string1942_ast_apply, arg1556_814);
			 }
			 list1554_812 = MAKE_PAIR(string1943_ast_apply, arg1555_813);
		      }
		      arg1518_785 = cons__138___r4_pairs_and_lists_6_3(arg1548_807, list1554_812);
		   }
		}
		{
		   obj_t list1520_787;
		   {
		      obj_t arg1522_788;
		      {
			 obj_t arg1524_789;
			 {
			    obj_t arg1525_790;
			    arg1525_790 = MAKE_PAIR(BNIL, BNIL);
			    arg1524_789 = MAKE_PAIR(arg1518_785, arg1525_790);
			 }
			 {
			    obj_t aux_2084;
			    aux_2084 = (obj_t) (app_781);
			    arg1522_788 = MAKE_PAIR(aux_2084, arg1524_789);
			 }
		      }
		      list1520_787 = MAKE_PAIR(arg1517_784, arg1522_788);
		   }
		   arg1515_782 = cons__138___r4_pairs_and_lists_6_3(arg1516_783, list1520_787);
		}
	     }
	     {
		node_t aux_2089;
		aux_2089 = sexp__node_235_ast_sexp(arg1515_782, stack_1848, loc_1845, site_1851);
		return (obj_t) (aux_2089);
	     }
	  }
     }
   else
     {
	obj_t arg1594_853;
	obj_t arg1595_854;
	{
	   obj_t arg1598_855;
	   {
	      obj_t arg1602_858;
	      node_t arg1603_859;
	      arg1602_858 = CAR(locals_778);
	      {
		 obj_t arg1605_860;
		 obj_t arg1606_861;
		 {
		    obj_t arg1607_862;
		    var_t arg1608_863;
		    arg1607_862 = CNST_TABLE_REF(((long) 9));
		    {
		       type_t arg1617_869;
		       arg1617_869 = (((local_t) CREF(runner_1847))->type);
		       {
			  var_t res1923_1505;
			  {
			     variable_t variable_1497;
			     variable_1497 = (variable_t) (runner_1847);
			     {
				var_t new1206_1498;
				new1206_1498 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				{
				   long arg1824_1499;
				   arg1824_1499 = class_num_218___object(var_ast_node);
				   {
				      obj_t obj_1503;
				      obj_1503 = (obj_t) (new1206_1498);
				      (((obj_t) CREF(obj_1503))->header = MAKE_HEADER(arg1824_1499, 0), BUNSPEC);
				   }
				}
				{
				   object_t aux_2100;
				   aux_2100 = (object_t) (new1206_1498);
				   OBJECT_WIDENING_SET(aux_2100, BFALSE);
				}
				((((var_t) CREF(new1206_1498))->loc) = ((obj_t) loc_1845), BUNSPEC);
				((((var_t) CREF(new1206_1498))->type) = ((type_t) arg1617_869), BUNSPEC);
				((((var_t) CREF(new1206_1498))->variable) = ((variable_t) variable_1497), BUNSPEC);
				res1923_1505 = new1206_1498;
			     }
			  }
			  arg1608_863 = res1923_1505;
		       }
		    }
		    {
		       obj_t list1610_865;
		       {
			  obj_t arg1612_866;
			  arg1612_866 = MAKE_PAIR(BNIL, BNIL);
			  {
			     obj_t aux_2107;
			     aux_2107 = (obj_t) (arg1608_863);
			     list1610_865 = MAKE_PAIR(aux_2107, arg1612_866);
			  }
		       }
		       arg1605_860 = cons__138___r4_pairs_and_lists_6_3(arg1607_862, list1610_865);
		    }
		 }
		 arg1606_861 = CNST_TABLE_REF(((long) 1));
		 arg1603_859 = sexp__node_235_ast_sexp(arg1605_860, stack_1848, loc_1845, arg1606_861);
	      }
	      {
		 obj_t aux_2113;
		 aux_2113 = (obj_t) (arg1603_859);
		 arg1598_855 = MAKE_PAIR(arg1602_858, aux_2113);
	      }
	   }
	   {
	      obj_t list1599_856;
	      list1599_856 = MAKE_PAIR(arg1598_855, BNIL);
	      arg1594_853 = list1599_856;
	   }
	}
	{
	   bool_t test_2117;
	   {
	      obj_t aux_2118;
	      aux_2118 = CDR(locals_778);
	      test_2117 = NULLP(aux_2118);
	   }
	   if (test_2117)
	     {
		arg1595_854 = loop_1940_ast_apply(site_1851, proc_1850, frame_1849, stack_1848, runner_1847, type_1846, loc_1845, CDR(locals_778));
	     }
	   else
	     {
		obj_t arg1621_873;
		obj_t arg1622_874;
		{
		   obj_t arg1623_875;
		   obj_t arg1624_876;
		   obj_t arg1625_877;
		   arg1623_875 = CNST_TABLE_REF(((long) 10));
		   {
		      obj_t arg1634_883;
		      var_t arg1636_884;
		      obj_t arg1638_885;
		      arg1634_883 = CNST_TABLE_REF(((long) 11));
		      {
			 type_t arg1648_892;
			 arg1648_892 = (((local_t) CREF(runner_1847))->type);
			 {
			    var_t res1924_1523;
			    {
			       variable_t variable_1515;
			       variable_1515 = (variable_t) (runner_1847);
			       {
				  var_t new1206_1516;
				  new1206_1516 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				  {
				     long arg1824_1517;
				     arg1824_1517 = class_num_218___object(var_ast_node);
				     {
					obj_t obj_1521;
					obj_1521 = (obj_t) (new1206_1516);
					(((obj_t) CREF(obj_1521))->header = MAKE_HEADER(arg1824_1517, 0), BUNSPEC);
				     }
				  }
				  {
				     object_t aux_2131;
				     aux_2131 = (object_t) (new1206_1516);
				     OBJECT_WIDENING_SET(aux_2131, BFALSE);
				  }
				  ((((var_t) CREF(new1206_1516))->loc) = ((obj_t) loc_1845), BUNSPEC);
				  ((((var_t) CREF(new1206_1516))->type) = ((type_t) arg1648_892), BUNSPEC);
				  ((((var_t) CREF(new1206_1516))->variable) = ((variable_t) variable_1515), BUNSPEC);
				  res1924_1523 = new1206_1516;
			       }
			    }
			    arg1636_884 = res1924_1523;
			 }
		      }
		      {
			 obj_t arg1650_894;
			 var_t arg1652_895;
			 arg1650_894 = CNST_TABLE_REF(((long) 6));
			 {
			    type_t arg1658_901;
			    arg1658_901 = (((local_t) CREF(runner_1847))->type);
			    {
			       var_t res1925_1535;
			       {
				  variable_t variable_1527;
				  variable_1527 = (variable_t) (runner_1847);
				  {
				     var_t new1206_1528;
				     new1206_1528 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				     {
					long arg1824_1529;
					arg1824_1529 = class_num_218___object(var_ast_node);
					{
					   obj_t obj_1533;
					   obj_1533 = (obj_t) (new1206_1528);
					   (((obj_t) CREF(obj_1533))->header = MAKE_HEADER(arg1824_1529, 0), BUNSPEC);
					}
				     }
				     {
					object_t aux_2144;
					aux_2144 = (object_t) (new1206_1528);
					OBJECT_WIDENING_SET(aux_2144, BFALSE);
				     }
				     ((((var_t) CREF(new1206_1528))->loc) = ((obj_t) loc_1845), BUNSPEC);
				     ((((var_t) CREF(new1206_1528))->type) = ((type_t) arg1658_901), BUNSPEC);
				     ((((var_t) CREF(new1206_1528))->variable) = ((variable_t) variable_1527), BUNSPEC);
				     res1925_1535 = new1206_1528;
				  }
			       }
			       arg1652_895 = res1925_1535;
			    }
			 }
			 {
			    obj_t list1654_897;
			    {
			       obj_t arg1655_898;
			       arg1655_898 = MAKE_PAIR(BNIL, BNIL);
			       {
				  obj_t aux_2151;
				  aux_2151 = (obj_t) (arg1652_895);
				  list1654_897 = MAKE_PAIR(aux_2151, arg1655_898);
			       }
			    }
			    arg1638_885 = cons__138___r4_pairs_and_lists_6_3(arg1650_894, list1654_897);
			 }
		      }
		      {
			 obj_t list1640_887;
			 {
			    obj_t arg1641_888;
			    {
			       obj_t arg1645_889;
			       arg1645_889 = MAKE_PAIR(BNIL, BNIL);
			       arg1641_888 = MAKE_PAIR(arg1638_885, arg1645_889);
			    }
			    {
			       obj_t aux_2157;
			       aux_2157 = (obj_t) (arg1636_884);
			       list1640_887 = MAKE_PAIR(aux_2157, arg1641_888);
			    }
			 }
			 arg1624_876 = cons__138___r4_pairs_and_lists_6_3(arg1634_883, list1640_887);
		      }
		   }
		   arg1625_877 = loop_1940_ast_apply(site_1851, proc_1850, frame_1849, stack_1848, runner_1847, type_1846, loc_1845, CDR(locals_778));
		   {
		      obj_t list1628_879;
		      {
			 obj_t arg1630_880;
			 {
			    obj_t arg1632_881;
			    arg1632_881 = MAKE_PAIR(BNIL, BNIL);
			    arg1630_880 = MAKE_PAIR(arg1625_877, arg1632_881);
			 }
			 list1628_879 = MAKE_PAIR(arg1624_876, arg1630_880);
		      }
		      arg1621_873 = cons__138___r4_pairs_and_lists_6_3(arg1623_875, list1628_879);
		   }
		}
		arg1622_874 = CNST_TABLE_REF(((long) 1));
		{
		   node_t aux_2168;
		   aux_2168 = sexp__node_235_ast_sexp(arg1621_873, stack_1848, loc_1845, arg1622_874);
		   arg1595_854 = (obj_t) (aux_2168);
		}
	     }
	}
	{
	   let_var_6_t res1926_1555;
	   {
	      obj_t key_1540;
	      node_t body_1542;
	      key_1540 = BINT(((long) -1));
	      body_1542 = (node_t) (arg1595_854);
	      {
		 let_var_6_t new1365_1544;
		 new1365_1544 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		 {
		    long arg1793_1545;
		    arg1793_1545 = class_num_218___object(let_var_6_ast_node);
		    {
		       obj_t obj_1553;
		       obj_1553 = (obj_t) (new1365_1544);
		       (((obj_t) CREF(obj_1553))->header = MAKE_HEADER(arg1793_1545, 0), BUNSPEC);
		    }
		 }
		 {
		    object_t aux_2177;
		    aux_2177 = (object_t) (new1365_1544);
		    OBJECT_WIDENING_SET(aux_2177, BFALSE);
		 }
		 ((((let_var_6_t) CREF(new1365_1544))->loc) = ((obj_t) loc_1845), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1544))->type) = ((type_t) type_1846), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1544))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1544))->key) = ((obj_t) key_1540), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1544))->bindings) = ((obj_t) arg1594_853), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1544))->body) = ((node_t) body_1542), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1544))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		 res1926_1555 = new1365_1544;
	      }
	   }
	   return (obj_t) (res1926_1555);
	}
     }
}


/* va-known-app-ly->node */ let_var_6_t 
va_known_app_ly__node_104_ast_apply(obj_t stack_26, obj_t loc_27, node_t proc_28, node_t arg_29, obj_t frame_30, obj_t site_31)
{
   {
      obj_t frame_1844;
      frame_1844 = MAKE_CELL(frame_30);
      {
	 local_t runner_908;
	 type_t type_909;
	 {
	    obj_t arg1774_1010;
	    {
	       obj_t arg1776_1011;
	       arg1776_1011 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 2)), BEOA);
	       arg1774_1010 = mark_symbol_non_user__17_ast_ident(arg1776_1011);
	    }
	    runner_908 = make_local_svar_140_ast_local(arg1774_1010, (type_t) (____74_type_cache));
	 }
	 type_909 = (((node_t) CREF(proc_28))->type);
	 {
	    bool_t test1668_910;
	    {
	       obj_t obj_1576;
	       obj_1576 = CELL_REF(frame_1844);
	       test1668_910 = PAIRP(obj_1576);
	    }
	    if (test1668_910)
	      {
		 obj_t arg1669_911;
		 arg1669_911 = CNST_TABLE_REF(((long) 3));
		 ((((local_t) CREF(runner_908))->access) = ((obj_t) arg1669_911), BUNSPEC);
	      }
	    else
	      {
		 BUNSPEC;
	      }
	 }
	 {
	    obj_t arg1675_915;
	    obj_t arg1676_916;
	    {
	       obj_t arg1677_917;
	       {
		  obj_t aux_2201;
		  obj_t aux_2199;
		  aux_2201 = (obj_t) (arg_29);
		  aux_2199 = (obj_t) (runner_908);
		  arg1677_917 = MAKE_PAIR(aux_2199, aux_2201);
	       }
	       {
		  obj_t list1678_918;
		  list1678_918 = MAKE_PAIR(arg1677_917, BNIL);
		  arg1675_915 = list1678_918;
	       }
	    }
	    arg1676_916 = loop_ast_apply(proc_28, frame_1844, stack_26, runner_908, type_909, loc_27, CELL_REF(frame_1844), BNIL);
	    {
	       let_var_6_t res1935_1725;
	       {
		  obj_t key_1710;
		  node_t body_1712;
		  key_1710 = BINT(((long) -1));
		  body_1712 = (node_t) (arg1676_916);
		  {
		     let_var_6_t new1365_1714;
		     new1365_1714 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		     {
			long arg1793_1715;
			arg1793_1715 = class_num_218___object(let_var_6_ast_node);
			{
			   obj_t obj_1723;
			   obj_1723 = (obj_t) (new1365_1714);
			   (((obj_t) CREF(obj_1723))->header = MAKE_HEADER(arg1793_1715, 0), BUNSPEC);
			}
		     }
		     {
			object_t aux_2212;
			aux_2212 = (object_t) (new1365_1714);
			OBJECT_WIDENING_SET(aux_2212, BFALSE);
		     }
		     ((((let_var_6_t) CREF(new1365_1714))->loc) = ((obj_t) loc_27), BUNSPEC);
		     ((((let_var_6_t) CREF(new1365_1714))->type) = ((type_t) type_909), BUNSPEC);
		     ((((let_var_6_t) CREF(new1365_1714))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		     ((((let_var_6_t) CREF(new1365_1714))->key) = ((obj_t) key_1710), BUNSPEC);
		     ((((let_var_6_t) CREF(new1365_1714))->bindings) = ((obj_t) arg1675_915), BUNSPEC);
		     ((((let_var_6_t) CREF(new1365_1714))->body) = ((node_t) body_1712), BUNSPEC);
		     ((((let_var_6_t) CREF(new1365_1714))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		     res1935_1725 = new1365_1714;
		  }
	       }
	       return res1935_1725;
	    }
	 }
      }
   }
}


/* loop */ obj_t 
loop_ast_apply(node_t proc_1842, obj_t frame_1841, obj_t stack_1840, local_t runner_1839, type_t type_1838, obj_t loc_1837, obj_t locals_920, obj_t old_921)
{
   if (NULLP(locals_920))
     {
	if (NULLP(old_921))
	  {
	     obj_t aux_1843;
	     {
		obj_t list1683_926;
		{
		   obj_t aux_2226;
		   aux_2226 = (obj_t) (runner_1839);
		   list1683_926 = MAKE_PAIR(aux_2226, BNIL);
		}
		aux_1843 = list1683_926;
	     }
	     CELL_SET(frame_1841, aux_1843);
	  }
	else
	  {
	     obj_t arg1685_928;
	     {
		obj_t aux_2229;
		aux_2229 = (obj_t) (runner_1839);
		arg1685_928 = MAKE_PAIR(aux_2229, BNIL);
	     }
	     SET_CDR(old_921, arg1685_928);
	  }
	{
	   type_t arg1689_931;
	   var_t arg1692_933;
	   obj_t arg1693_934;
	   {
	      variable_t arg1694_935;
	      {
		 var_t obj_1589;
		 obj_1589 = (var_t) (proc_1842);
		 arg1694_935 = (((var_t) CREF(obj_1589))->variable);
	      }
	      arg1689_931 = (((variable_t) CREF(arg1694_935))->type);
	   }
	   {
	      var_t duplicated1450_936;
	      duplicated1450_936 = (var_t) (proc_1842);
	      {
		 var_t new1451_937;
		 {
		    obj_t arg1695_938;
		    type_t arg1697_939;
		    variable_t arg1698_940;
		    arg1695_938 = (((var_t) CREF(duplicated1450_936))->loc);
		    arg1697_939 = (((var_t) CREF(duplicated1450_936))->type);
		    arg1698_940 = (((var_t) CREF(duplicated1450_936))->variable);
		    {
		       var_t res1928_1604;
		       {
			  var_t new1206_1597;
			  new1206_1597 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			  {
			     long arg1824_1598;
			     arg1824_1598 = class_num_218___object(var_ast_node);
			     {
				obj_t obj_1602;
				obj_1602 = (obj_t) (new1206_1597);
				(((obj_t) CREF(obj_1602))->header = MAKE_HEADER(arg1824_1598, 0), BUNSPEC);
			     }
			  }
			  {
			     object_t aux_2244;
			     aux_2244 = (object_t) (new1206_1597);
			     OBJECT_WIDENING_SET(aux_2244, BFALSE);
			  }
			  ((((var_t) CREF(new1206_1597))->loc) = ((obj_t) arg1695_938), BUNSPEC);
			  ((((var_t) CREF(new1206_1597))->type) = ((type_t) arg1697_939), BUNSPEC);
			  ((((var_t) CREF(new1206_1597))->variable) = ((variable_t) arg1698_940), BUNSPEC);
			  res1928_1604 = new1206_1597;
		       }
		       new1451_937 = res1928_1604;
		    }
		 }
		 {
		    arg1692_933 = new1451_937;
		 }
	      }
	   }
	   {
	      obj_t l1452_941;
	      l1452_941 = CELL_REF(frame_1841);
	      if (NULLP(l1452_941))
		{
		   arg1693_934 = BNIL;
		}
	      else
		{
		   obj_t head1454_943;
		   head1454_943 = MAKE_PAIR(BNIL, BNIL);
		   {
		      obj_t l1452_944;
		      obj_t tail1455_945;
		      l1452_944 = l1452_941;
		      tail1455_945 = head1454_943;
		    lname1453_946:
		      if (NULLP(l1452_944))
			{
			   arg1693_934 = CDR(head1454_943);
			}
		      else
			{
			   obj_t newtail1456_948;
			   {
			      var_t arg1702_950;
			      {
				 obj_t local_952;
				 local_952 = CAR(l1452_944);
				 {
				    type_t arg1705_954;
				    {
				       local_t obj_1611;
				       obj_1611 = (local_t) (local_952);
				       arg1705_954 = (((local_t) CREF(obj_1611))->type);
				    }
				    {
				       var_t res1929_1622;
				       {
					  variable_t variable_1614;
					  variable_1614 = (variable_t) (local_952);
					  {
					     var_t new1206_1615;
					     new1206_1615 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
					     {
						long arg1824_1616;
						arg1824_1616 = class_num_218___object(var_ast_node);
						{
						   obj_t obj_1620;
						   obj_1620 = (obj_t) (new1206_1615);
						   (((obj_t) CREF(obj_1620))->header = MAKE_HEADER(arg1824_1616, 0), BUNSPEC);
						}
					     }
					     {
						object_t aux_2264;
						aux_2264 = (object_t) (new1206_1615);
						OBJECT_WIDENING_SET(aux_2264, BFALSE);
					     }
					     ((((var_t) CREF(new1206_1615))->loc) = ((obj_t) loc_1837), BUNSPEC);
					     ((((var_t) CREF(new1206_1615))->type) = ((type_t) arg1705_954), BUNSPEC);
					     ((((var_t) CREF(new1206_1615))->variable) = ((variable_t) variable_1614), BUNSPEC);
					     res1929_1622 = new1206_1615;
					  }
				       }
				       arg1702_950 = res1929_1622;
				    }
				 }
			      }
			      {
				 obj_t aux_2270;
				 aux_2270 = (obj_t) (arg1702_950);
				 newtail1456_948 = MAKE_PAIR(aux_2270, BNIL);
			      }
			   }
			   SET_CDR(tail1455_945, newtail1456_948);
			   {
			      obj_t tail1455_2276;
			      obj_t l1452_2274;
			      l1452_2274 = CDR(l1452_944);
			      tail1455_2276 = newtail1456_948;
			      tail1455_945 = tail1455_2276;
			      l1452_944 = l1452_2274;
			      goto lname1453_946;
			   }
			}
		   }
		}
	   }
	   {
	      app_t res1930_1646;
	      {
		 obj_t key_1631;
		 key_1631 = BINT(((long) -1));
		 {
		    app_t new1240_1635;
		    new1240_1635 = ((app_t) BREF(GC_MALLOC(sizeof(struct app))));
		    {
		       long arg1815_1636;
		       arg1815_1636 = class_num_218___object(app_ast_node);
		       {
			  obj_t obj_1644;
			  obj_1644 = (obj_t) (new1240_1635);
			  (((obj_t) CREF(obj_1644))->header = MAKE_HEADER(arg1815_1636, 0), BUNSPEC);
		       }
		    }
		    {
		       object_t aux_2282;
		       aux_2282 = (object_t) (new1240_1635);
		       OBJECT_WIDENING_SET(aux_2282, BFALSE);
		    }
		    ((((app_t) CREF(new1240_1635))->loc) = ((obj_t) loc_1837), BUNSPEC);
		    ((((app_t) CREF(new1240_1635))->type) = ((type_t) arg1689_931), BUNSPEC);
		    ((((app_t) CREF(new1240_1635))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		    ((((app_t) CREF(new1240_1635))->key) = ((obj_t) key_1631), BUNSPEC);
		    ((((app_t) CREF(new1240_1635))->fun) = ((var_t) arg1692_933), BUNSPEC);
		    ((((app_t) CREF(new1240_1635))->args) = ((obj_t) arg1693_934), BUNSPEC);
		    ((((app_t) CREF(new1240_1635))->stack_info_255) = ((obj_t) BUNSPEC), BUNSPEC);
		    res1930_1646 = new1240_1635;
		 }
	      }
	      return (obj_t) (res1930_1646);
	   }
	}
     }
   else
     {
	obj_t arg1712_961;
	node_t arg1713_962;
	{
	   obj_t arg1714_963;
	   {
	      obj_t arg1717_966;
	      node_t arg1718_967;
	      arg1717_966 = CAR(locals_920);
	      {
		 obj_t arg1720_968;
		 obj_t arg1721_969;
		 {
		    obj_t arg1722_970;
		    var_t arg1723_971;
		    arg1722_970 = CNST_TABLE_REF(((long) 9));
		    {
		       type_t arg1729_977;
		       arg1729_977 = (((local_t) CREF(runner_1839))->type);
		       {
			  var_t res1931_1659;
			  {
			     variable_t variable_1651;
			     variable_1651 = (variable_t) (runner_1839);
			     {
				var_t new1206_1652;
				new1206_1652 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				{
				   long arg1824_1653;
				   arg1824_1653 = class_num_218___object(var_ast_node);
				   {
				      obj_t obj_1657;
				      obj_1657 = (obj_t) (new1206_1652);
				      (((obj_t) CREF(obj_1657))->header = MAKE_HEADER(arg1824_1653, 0), BUNSPEC);
				   }
				}
				{
				   object_t aux_2301;
				   aux_2301 = (object_t) (new1206_1652);
				   OBJECT_WIDENING_SET(aux_2301, BFALSE);
				}
				((((var_t) CREF(new1206_1652))->loc) = ((obj_t) loc_1837), BUNSPEC);
				((((var_t) CREF(new1206_1652))->type) = ((type_t) arg1729_977), BUNSPEC);
				((((var_t) CREF(new1206_1652))->variable) = ((variable_t) variable_1651), BUNSPEC);
				res1931_1659 = new1206_1652;
			     }
			  }
			  arg1723_971 = res1931_1659;
		       }
		    }
		    {
		       obj_t list1725_973;
		       {
			  obj_t arg1726_974;
			  arg1726_974 = MAKE_PAIR(BNIL, BNIL);
			  {
			     obj_t aux_2308;
			     aux_2308 = (obj_t) (arg1723_971);
			     list1725_973 = MAKE_PAIR(aux_2308, arg1726_974);
			  }
		       }
		       arg1720_968 = cons__138___r4_pairs_and_lists_6_3(arg1722_970, list1725_973);
		    }
		 }
		 arg1721_969 = CNST_TABLE_REF(((long) 1));
		 arg1718_967 = sexp__node_235_ast_sexp(arg1720_968, stack_1840, loc_1837, arg1721_969);
	      }
	      {
		 obj_t aux_2314;
		 aux_2314 = (obj_t) (arg1718_967);
		 arg1714_963 = MAKE_PAIR(arg1717_966, aux_2314);
	      }
	   }
	   {
	      obj_t list1715_964;
	      list1715_964 = MAKE_PAIR(arg1714_963, BNIL);
	      arg1712_961 = list1715_964;
	   }
	}
	{
	   obj_t arg1731_979;
	   obj_t arg1732_980;
	   {
	      obj_t arg1733_981;
	      obj_t arg1738_982;
	      obj_t arg1739_983;
	      arg1733_981 = CNST_TABLE_REF(((long) 10));
	      {
		 obj_t arg1746_989;
		 var_t arg1747_990;
		 obj_t arg1748_991;
		 arg1746_989 = CNST_TABLE_REF(((long) 11));
		 {
		    type_t arg1760_998;
		    arg1760_998 = (((local_t) CREF(runner_1839))->type);
		    {
		       var_t res1932_1674;
		       {
			  variable_t variable_1666;
			  variable_1666 = (variable_t) (runner_1839);
			  {
			     var_t new1206_1667;
			     new1206_1667 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
			     {
				long arg1824_1668;
				arg1824_1668 = class_num_218___object(var_ast_node);
				{
				   obj_t obj_1672;
				   obj_1672 = (obj_t) (new1206_1667);
				   (((obj_t) CREF(obj_1672))->header = MAKE_HEADER(arg1824_1668, 0), BUNSPEC);
				}
			     }
			     {
				object_t aux_2326;
				aux_2326 = (object_t) (new1206_1667);
				OBJECT_WIDENING_SET(aux_2326, BFALSE);
			     }
			     ((((var_t) CREF(new1206_1667))->loc) = ((obj_t) loc_1837), BUNSPEC);
			     ((((var_t) CREF(new1206_1667))->type) = ((type_t) arg1760_998), BUNSPEC);
			     ((((var_t) CREF(new1206_1667))->variable) = ((variable_t) variable_1666), BUNSPEC);
			     res1932_1674 = new1206_1667;
			  }
		       }
		       arg1747_990 = res1932_1674;
		    }
		 }
		 {
		    obj_t arg1762_1000;
		    var_t arg1765_1001;
		    arg1762_1000 = CNST_TABLE_REF(((long) 6));
		    {
		       type_t arg1771_1007;
		       arg1771_1007 = (((local_t) CREF(runner_1839))->type);
		       {
			  var_t res1933_1686;
			  {
			     variable_t variable_1678;
			     variable_1678 = (variable_t) (runner_1839);
			     {
				var_t new1206_1679;
				new1206_1679 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
				{
				   long arg1824_1680;
				   arg1824_1680 = class_num_218___object(var_ast_node);
				   {
				      obj_t obj_1684;
				      obj_1684 = (obj_t) (new1206_1679);
				      (((obj_t) CREF(obj_1684))->header = MAKE_HEADER(arg1824_1680, 0), BUNSPEC);
				   }
				}
				{
				   object_t aux_2339;
				   aux_2339 = (object_t) (new1206_1679);
				   OBJECT_WIDENING_SET(aux_2339, BFALSE);
				}
				((((var_t) CREF(new1206_1679))->loc) = ((obj_t) loc_1837), BUNSPEC);
				((((var_t) CREF(new1206_1679))->type) = ((type_t) arg1771_1007), BUNSPEC);
				((((var_t) CREF(new1206_1679))->variable) = ((variable_t) variable_1678), BUNSPEC);
				res1933_1686 = new1206_1679;
			     }
			  }
			  arg1765_1001 = res1933_1686;
		       }
		    }
		    {
		       obj_t list1767_1003;
		       {
			  obj_t arg1768_1004;
			  arg1768_1004 = MAKE_PAIR(BNIL, BNIL);
			  {
			     obj_t aux_2346;
			     aux_2346 = (obj_t) (arg1765_1001);
			     list1767_1003 = MAKE_PAIR(aux_2346, arg1768_1004);
			  }
		       }
		       arg1748_991 = cons__138___r4_pairs_and_lists_6_3(arg1762_1000, list1767_1003);
		    }
		 }
		 {
		    obj_t list1750_993;
		    {
		       obj_t arg1753_994;
		       {
			  obj_t arg1755_995;
			  arg1755_995 = MAKE_PAIR(BNIL, BNIL);
			  arg1753_994 = MAKE_PAIR(arg1748_991, arg1755_995);
		       }
		       {
			  obj_t aux_2352;
			  aux_2352 = (obj_t) (arg1747_990);
			  list1750_993 = MAKE_PAIR(aux_2352, arg1753_994);
		       }
		    }
		    arg1738_982 = cons__138___r4_pairs_and_lists_6_3(arg1746_989, list1750_993);
		 }
	      }
	      arg1739_983 = loop_ast_apply(proc_1842, frame_1841, stack_1840, runner_1839, type_1838, loc_1837, CDR(locals_920), locals_920);
	      {
		 obj_t list1741_985;
		 {
		    obj_t arg1743_986;
		    {
		       obj_t arg1744_987;
		       arg1744_987 = MAKE_PAIR(BNIL, BNIL);
		       arg1743_986 = MAKE_PAIR(arg1739_983, arg1744_987);
		    }
		    list1741_985 = MAKE_PAIR(arg1738_982, arg1743_986);
		 }
		 arg1731_979 = cons__138___r4_pairs_and_lists_6_3(arg1733_981, list1741_985);
	      }
	   }
	   arg1732_980 = CNST_TABLE_REF(((long) 1));
	   arg1713_962 = sexp__node_235_ast_sexp(arg1731_979, stack_1840, loc_1837, arg1732_980);
	}
	{
	   let_var_6_t res1934_1706;
	   {
	      obj_t key_1691;
	      key_1691 = BINT(((long) -1));
	      {
		 let_var_6_t new1365_1695;
		 new1365_1695 = ((let_var_6_t) BREF(GC_MALLOC(sizeof(struct let_var_6))));
		 {
		    long arg1793_1696;
		    arg1793_1696 = class_num_218___object(let_var_6_ast_node);
		    {
		       obj_t obj_1704;
		       obj_1704 = (obj_t) (new1365_1695);
		       (((obj_t) CREF(obj_1704))->header = MAKE_HEADER(arg1793_1696, 0), BUNSPEC);
		    }
		 }
		 {
		    object_t aux_2369;
		    aux_2369 = (object_t) (new1365_1695);
		    OBJECT_WIDENING_SET(aux_2369, BFALSE);
		 }
		 ((((let_var_6_t) CREF(new1365_1695))->loc) = ((obj_t) loc_1837), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1695))->type) = ((type_t) type_1838), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1695))->side_effect__165) = ((obj_t) BUNSPEC), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1695))->key) = ((obj_t) key_1691), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1695))->bindings) = ((obj_t) arg1712_961), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1695))->body) = ((node_t) arg1713_962), BUNSPEC);
		 ((((let_var_6_t) CREF(new1365_1695))->removable__42) = ((bool_t) ((bool_t) 1)), BUNSPEC);
		 res1934_1706 = new1365_1695;
	      }
	   }
	   return (obj_t) (res1934_1706);
	}
     }
}


/* method-init */ obj_t 
method_init_76_ast_apply()
{
   add_generic__110___object(make_fun_frame_env_121_ast_apply, make_fun_frame_default1463_env_4_ast_apply);
   add_inlined_method__244___object(make_fun_frame_env_121_ast_apply, sfun_ast_var, ((long) 0));
   {
      long aux_2382;
      aux_2382 = add_inlined_method__244___object(make_fun_frame_env_121_ast_apply, cfun_ast_var, ((long) 1));
      return BINT(aux_2382);
   }
}


/* make-fun-frame */ obj_t 
make_fun_frame_37_ast_apply(fun_t fun_5)
{
   {
      obj_t method1869_1344;
      obj_t class1874_1345;
      {
	 obj_t arg1877_1342;
	 obj_t arg1878_1343;
	 {
	    object_t obj_1763;
	    obj_1763 = (object_t) (fun_5);
	    {
	       obj_t pre_method_105_1764;
	       pre_method_105_1764 = PROCEDURE_REF(make_fun_frame_env_121_ast_apply, ((long) 2));
	       if (INTEGERP(pre_method_105_1764))
		 {
		    PROCEDURE_SET(make_fun_frame_env_121_ast_apply, ((long) 2), BUNSPEC);
		    arg1877_1342 = pre_method_105_1764;
		 }
	       else
		 {
		    long obj_class_num_177_1769;
		    obj_class_num_177_1769 = TYPE(obj_1763);
		    {
		       obj_t arg1177_1770;
		       arg1177_1770 = PROCEDURE_REF(make_fun_frame_env_121_ast_apply, ((long) 1));
		       {
			  long arg1178_1774;
			  {
			     long arg1179_1775;
			     arg1179_1775 = OBJECT_TYPE;
			     arg1178_1774 = (obj_class_num_177_1769 - arg1179_1775);
			  }
			  arg1877_1342 = VECTOR_REF(arg1177_1770, arg1178_1774);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1780;
	    object_1780 = (object_t) (fun_5);
	    {
	       long arg1180_1781;
	       {
		  long arg1181_1782;
		  long arg1182_1783;
		  arg1181_1782 = TYPE(object_1780);
		  arg1182_1783 = OBJECT_TYPE;
		  arg1180_1781 = (arg1181_1782 - arg1182_1783);
	       }
	       {
		  obj_t vector_1787;
		  vector_1787 = _classes__134___object;
		  arg1878_1343 = VECTOR_REF(vector_1787, arg1180_1781);
	       }
	    }
	 }
	 method1869_1344 = arg1877_1342;
	 class1874_1345 = arg1878_1343;
	 {
	    if (INTEGERP(method1869_1344))
	      {
		 switch ((long) CINT(method1869_1344))
		   {
		   case ((long) 0):
		      {
			 sfun_t fun_1351;
			 fun_1351 = (sfun_t) (fun_5);
			 {
			    long arity_1352;
			    arity_1352 = (((sfun_t) CREF(fun_1351))->arity);
			    {
			       obj_t formals_1353;
			       obj_t locals_1354;
			       formals_1353 = (((sfun_t) CREF(fun_1351))->args);
			       locals_1354 = BNIL;
			     loop_1355:
			       if (NULLP(formals_1353))
				 {
				    return reverse__39___r4_pairs_and_lists_6_3(locals_1354);
				 }
			       else
				 {
				    bool_t test_2407;
				    {
				       bool_t test_2408;
				       {
					  obj_t aux_2409;
					  aux_2409 = CDR(formals_1353);
					  test_2408 = NULLP(aux_2409);
				       }
				       if (test_2408)
					 {
					    test_2407 = (arity_1352 < ((long) 0));
					 }
				       else
					 {
					    test_2407 = ((bool_t) 0);
					 }
				    }
				    if (test_2407)
				      {
					 return reverse__39___r4_pairs_and_lists_6_3(locals_1354);
				      }
				    else
				      {
					 {
					    obj_t arg1886_1360;
					    obj_t arg1887_1361;
					    arg1886_1360 = CDR(formals_1353);
					    {
					       local_t arg1888_1362;
					       {
						  obj_t arg1890_1363;
						  obj_t arg1892_1364;
						  {
						     obj_t arg1893_1365;
						     arg1893_1365 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 12)), BEOA);
						     arg1890_1363 = mark_symbol_non_user__17_ast_ident(arg1893_1365);
						  }
						  {
						     bool_t test1895_1367;
						     test1895_1367 = is_a__118___object(CAR(formals_1353), type_type_type);
						     if (test1895_1367)
						       {
							  arg1892_1364 = CAR(formals_1353);
						       }
						     else
						       {
							  local_t obj_1801;
							  {
							     obj_t aux_2423;
							     aux_2423 = CAR(formals_1353);
							     obj_1801 = (local_t) (aux_2423);
							  }
							  {
							     type_t aux_2426;
							     aux_2426 = (((local_t) CREF(obj_1801))->type);
							     arg1892_1364 = (obj_t) (aux_2426);
							  }
						       }
						  }
						  arg1888_1362 = make_local_svar_140_ast_local(arg1890_1363, (type_t) (arg1892_1364));
					       }
					       {
						  obj_t aux_2431;
						  aux_2431 = (obj_t) (arg1888_1362);
						  arg1887_1361 = MAKE_PAIR(aux_2431, locals_1354);
					       }
					    }
					    {
					       obj_t locals_2435;
					       obj_t formals_2434;
					       formals_2434 = arg1886_1360;
					       locals_2435 = arg1887_1361;
					       locals_1354 = locals_2435;
					       formals_1353 = formals_2434;
					       goto loop_1355;
					    }
					 }
				      }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 1):
		      {
			 cfun_t fun_1372;
			 fun_1372 = (cfun_t) (fun_5);
			 {
			    long arity_1373;
			    arity_1373 = (((cfun_t) CREF(fun_1372))->arity);
			    {
			       obj_t types_1374;
			       obj_t locals_1375;
			       types_1374 = (((cfun_t) CREF(fun_1372))->args_type_205);
			       locals_1375 = BNIL;
			     loop_1376:
			       if (NULLP(types_1374))
				 {
				    return reverse__39___r4_pairs_and_lists_6_3(locals_1375);
				 }
			       else
				 {
				    bool_t test_2442;
				    {
				       bool_t test_2443;
				       {
					  obj_t aux_2444;
					  aux_2444 = CDR(types_1374);
					  test_2443 = NULLP(aux_2444);
				       }
				       if (test_2443)
					 {
					    test_2442 = (arity_1373 < ((long) 0));
					 }
				       else
					 {
					    test_2442 = ((bool_t) 0);
					 }
				    }
				    if (test_2442)
				      {
					 return reverse__39___r4_pairs_and_lists_6_3(locals_1375);
				      }
				    else
				      {
					 {
					    obj_t arg1905_1381;
					    obj_t arg1906_1382;
					    arg1905_1381 = CDR(types_1374);
					    {
					       local_t arg1907_1383;
					       {
						  obj_t arg1909_1384;
						  obj_t arg1910_1385;
						  {
						     obj_t arg1911_1386;
						     arg1911_1386 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 12)), BEOA);
						     arg1909_1384 = mark_symbol_non_user__17_ast_ident(arg1911_1386);
						  }
						  arg1910_1385 = CAR(types_1374);
						  arg1907_1383 = make_local_svar_140_ast_local(arg1909_1384, (type_t) (arg1910_1385));
					       }
					       {
						  obj_t aux_2457;
						  aux_2457 = (obj_t) (arg1907_1383);
						  arg1906_1382 = MAKE_PAIR(aux_2457, locals_1375);
					       }
					    }
					    {
					       obj_t locals_2461;
					       obj_t types_2460;
					       types_2460 = arg1905_1381;
					       locals_2461 = arg1906_1382;
					       locals_1375 = locals_2461;
					       types_1374 = types_2460;
					       goto loop_1376;
					    }
					 }
				      }
				 }
			    }
			 }
		      }
		      break;
		   default:
		    case_else1875_1348:
		      if (PROCEDUREP(method1869_1344))
			{
			   return PROCEDURE_ENTRY(method1869_1344) (method1869_1344, (obj_t) (fun_5), BEOA);
			}
		      else
			{
			   obj_t fun1865_1338;
			   fun1865_1338 = PROCEDURE_REF(make_fun_frame_env_121_ast_apply, ((long) 0));
			   return PROCEDURE_ENTRY(fun1865_1338) (fun1865_1338, (obj_t) (fun_5), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1875_1348;
	      }
	 }
      }
   }
}


/* _make-fun-frame1939 */ obj_t 
_make_fun_frame1939_139_ast_apply(obj_t env_1833, obj_t fun_1834)
{
   return make_fun_frame_37_ast_apply((fun_t) (fun_1834));
}


/* make-fun-frame-default1463 */ obj_t 
make_fun_frame_default1463_221_ast_apply(fun_t fun_6)
{
   FAILURE(CNST_TABLE_REF(((long) 13)), string1944_ast_apply, (obj_t) (fun_6));
}


/* _make-fun-frame-default1463 */ obj_t 
_make_fun_frame_default1463_46_ast_apply(obj_t env_1835, obj_t fun_1836)
{
   return make_fun_frame_default1463_221_ast_apply((fun_t) (fun_1836));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_apply()
{
   module_initialization_70_type_type(((long) 0), "AST_APPLY");
   module_initialization_70_ast_var(((long) 0), "AST_APPLY");
   module_initialization_70_ast_node(((long) 0), "AST_APPLY");
   module_initialization_70_engine_param(((long) 0), "AST_APPLY");
   module_initialization_70_tools_error(((long) 0), "AST_APPLY");
   module_initialization_70_tools_location(((long) 0), "AST_APPLY");
   module_initialization_70_tools_shape(((long) 0), "AST_APPLY");
   module_initialization_70_type_cache(((long) 0), "AST_APPLY");
   module_initialization_70_ast_sexp(((long) 0), "AST_APPLY");
   module_initialization_70_ast_local(((long) 0), "AST_APPLY");
   module_initialization_70_ast_app(((long) 0), "AST_APPLY");
   return module_initialization_70_ast_ident(((long) 0), "AST_APPLY");
}
