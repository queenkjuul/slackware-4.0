/*===========================================================================*/
/*   (Eval/expand.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t __identifier_eval_expander__130___expand(obj_t, obj_t, obj_t);
extern obj_t string_to_symbol(char *);
static obj_t initial_expander_162___expand(obj_t, obj_t);
static obj_t symbol1199___expand = BUNSPEC;
extern obj_t expand___expand(obj_t);
extern obj_t parse_formal_ident_54___expand(obj_t);
static obj_t _parse_formal_ident_255___expand(obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _expand___expand(obj_t, obj_t);
static obj_t loop___expand(obj_t, obj_t);
static obj_t _expand_once_110___expand(obj_t, obj_t);
extern obj_t get_eval_expander_232___macro(obj_t);
static obj_t __application_eval_expander__131___expand(obj_t, obj_t, obj_t);
static obj_t lambda1014___expand(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___expand(long, char *);
extern obj_t module_initialization_70___macro(long, char *);
extern obj_t module_initialization_70___type(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___os(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t c_substring(obj_t, long, long);
extern obj_t expand_once_95___expand(obj_t);
static obj_t _initial_expander1194_69___expand(obj_t, obj_t, obj_t);
static obj_t arg1006___expand(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___expand();
static obj_t require_initialization_114___expand = BUNSPEC;
static obj_t cnst_init_137___expand();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( expand_once_env_147___expand, _expand_once_110___expand1203, _expand_once_110___expand, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( expand_env_236___expand, _expand___expand1204, _expand___expand, 0L, 1 );
DEFINE_STATIC_PROCEDURE( _application_eval_expander__env_8___expand, __application_eval_expander__131___expand1205, __application_eval_expander__131___expand, 0L, 2 );
DEFINE_STATIC_PROCEDURE( _identifier_eval_expander__env_211___expand, __identifier_eval_expander__130___expand1206, __identifier_eval_expander__130___expand, 0L, 2 );
DEFINE_STATIC_PROCEDURE( initial_expander_env_197___expand, _initial_expander1194_69___expand1207, _initial_expander1194_69___expand, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( parse_formal_ident_env_19___expand, _parse_formal_ident_255___expand1208, _parse_formal_ident_255___expand, 0L, 1 );
DEFINE_STATIC_PROCEDURE( proc1196___expand, lambda1014___expand1209, lambda1014___expand, 0L, 2 );
DEFINE_STATIC_PROCEDURE( proc1195___expand, arg1006___expand1210, arg1006___expand, 0L, 2 );
DEFINE_STRING( string1198___expand, string1198___expand1211, "Illegal form", 12 );
DEFINE_STRING( string1197___expand, string1197___expand1212, "application", 11 );
DEFINE_STRING( string1201___expand, string1201___expand1213, "Illegal formal identifier", 25 );
DEFINE_STRING( string1200___expand, string1200___expand1214, "", 0 );


/* module-initialization */obj_t module_initialization_70___expand(long checksum_667, char * from_668)
{
if(CBOOL(require_initialization_114___expand)){
require_initialization_114___expand = BBOOL(((bool_t)0));
cnst_init_137___expand();
imported_modules_init_94___expand();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___expand()
{
return (symbol1199___expand = string_to_symbol("DSSSL"),
BUNSPEC);
}


/* expand */obj_t expand___expand(obj_t x_1)
{
return initial_expander_162___expand(x_1, initial_expander_env_197___expand);
}


/* _expand */obj_t _expand___expand(obj_t env_635, obj_t x_636)
{
return expand___expand(x_636);
}


/* expand-once */obj_t expand_once_95___expand(obj_t x_2)
{
{
obj_t arg1006_640;
arg1006_640 = proc1195___expand;
return initial_expander_162___expand(x_2, arg1006_640);
}
}


/* _expand-once */obj_t _expand_once_110___expand(obj_t env_641, obj_t x_642)
{
return expand_once_95___expand(x_642);
}


/* arg1006 */obj_t arg1006___expand(obj_t env_643, obj_t x_644, obj_t e_645)
{
{
obj_t x_659;
x_659 = x_644;
return x_659;
}
}


/* initial-expander */obj_t initial_expander_162___expand(obj_t x_3, obj_t e_4)
{
{
obj_t e1_333;
if(SYMBOLP(x_3)){
e1_333 = _identifier_eval_expander__env_211___expand;
}
 else {
if(PAIRP(x_3)){
bool_t test_683;
{
obj_t aux_684;
aux_684 = CAR(x_3);
test_683 = SYMBOLP(aux_684);
}
if(test_683){
{
obj_t id_337;
{
obj_t arg1011_339;
arg1011_339 = parse_formal_ident_54___expand(CAR(x_3));
id_337 = CAR(arg1011_339);
}
{
obj_t b_338;
b_338 = get_eval_expander_232___macro(id_337);
if(CBOOL(b_338)){
e1_333 = b_338;
}
 else {
e1_333 = _application_eval_expander__env_8___expand;
}
}
}
}
 else {
e1_333 = _application_eval_expander__env_8___expand;
}
}
 else {
{
obj_t lambda1014_646;
lambda1014_646 = proc1196___expand;
e1_333 = lambda1014_646;
}
}
}
return PROCEDURE_ENTRY(e1_333)(e1_333, x_3, e_4, BEOA);
}
}


/* _initial-expander1194 */obj_t _initial_expander1194_69___expand(obj_t env_637, obj_t x_638, obj_t e_639)
{
return initial_expander_162___expand(x_638, e_639);
}


/* lambda1014 */obj_t lambda1014___expand(obj_t env_647, obj_t x_648, obj_t e_649)
{
{
obj_t x_661;
x_661 = x_648;
return x_661;
}
}


/* _*identifier-eval-expander* */obj_t __identifier_eval_expander__130___expand(obj_t env_650, obj_t x_651, obj_t e_652)
{
{
obj_t x_663;
x_663 = x_651;
return x_663;
}
}


/* loop */obj_t loop___expand(obj_t e_658, obj_t x_345)
{
if(NULLP(x_345)){
return BNIL;
}
 else {
if(PAIRP(x_345)){
{
obj_t arg1017_349;
obj_t arg1018_350;
arg1017_349 = PROCEDURE_ENTRY(e_658)(e_658, CAR(x_345), e_658, BEOA);
arg1018_350 = loop___expand(e_658, CDR(x_345));
return MAKE_PAIR(arg1017_349, arg1018_350);
}
}
 else {
FAILURE(string1197___expand,string1198___expand,x_345);}
}
}


/* _*application-eval-expander* */obj_t __application_eval_expander__131___expand(obj_t env_653, obj_t x_654, obj_t e_655)
{
{
obj_t x_665;
obj_t e_666;
x_665 = x_654;
e_666 = e_655;
return loop___expand(e_666, x_665);
}
}


/* parse-formal-ident */obj_t parse_formal_ident_54___expand(obj_t ident_9)
{
{
bool_t test_708;
if((ident_9==BCNST(258))){
test_708 = ((bool_t)1);
}
 else {
if((ident_9==BCNST(259))){
test_708 = ((bool_t)1);
}
 else {
test_708 = (ident_9==BCNST(262));
}
}
if(test_708){
{
obj_t arg1022_354;
arg1022_354 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1199___expand, BEOA);
return MAKE_PAIR(arg1022_354, BNIL);
}
}
 else {
bool_t test_717;
if(PAIRP(ident_9)){
obj_t aux_720;
aux_720 = CAR(ident_9);
test_717 = SYMBOLP(aux_720);
}
 else {
test_717 = ((bool_t)0);
}
if(test_717){
return MAKE_PAIR(ident_9, BNIL);
}
 else {
if(SYMBOLP(ident_9)){
{
obj_t string_360;
string_360 = SYMBOL_TO_STRING(ident_9);
{
long len_361;
len_361 = STRING_LENGTH(string_360);
{
{
long walker_362;
long id_stop_141_363;
long type_start_90_364;
walker_362 = ((long)0);
id_stop_141_363 = ((long)0);
type_start_90_364 = ((long)0);
loop_365:
if((walker_362==len_361)){
{
bool_t test_730;
if((id_stop_141_363==((long)0))){
test_730 = (type_start_90_364>((long)0));
}
 else {
test_730 = ((bool_t)0);
}
if(test_730){
{
obj_t arg1031_368;
obj_t arg1032_369;
{
char * aux_734;
aux_734 = BSTRING_TO_STRING(string1200___expand);
arg1031_368 = string_to_symbol(aux_734);
}
{
obj_t arg1033_370;
arg1033_370 = c_substring(string_360, type_start_90_364, len_361);
{
char * aux_738;
aux_738 = BSTRING_TO_STRING(arg1033_370);
arg1032_369 = string_to_symbol(aux_738);
}
}
return MAKE_PAIR(arg1031_368, arg1032_369);
}
}
 else {
if((id_stop_141_363==((long)0))){
return MAKE_PAIR(ident_9, BNIL);
}
 else {
if((type_start_90_364==len_361)){
FAILURE(BFALSE,string1201___expand,ident_9);}
 else {
{
obj_t arg1037_374;
obj_t arg1038_375;
{
obj_t arg1039_376;
arg1039_376 = c_substring(string_360, ((long)0), id_stop_141_363);
{
char * aux_749;
aux_749 = BSTRING_TO_STRING(arg1039_376);
arg1037_374 = string_to_symbol(aux_749);
}
}
{
obj_t arg1040_377;
arg1040_377 = c_substring(string_360, type_start_90_364, len_361);
{
char * aux_753;
aux_753 = BSTRING_TO_STRING(arg1040_377);
arg1038_375 = string_to_symbol(aux_753);
}
}
return MAKE_PAIR(arg1037_374, arg1038_375);
}
}
}
}
}
}
 else {
bool_t test_757;
{
bool_t test_758;
{
unsigned char aux_759;
aux_759 = STRING_REF(string_360, walker_362);
test_758 = (aux_759==((unsigned char)':'));
}
if(test_758){
bool_t test_762;
{
long aux_763;
aux_763 = (len_361-((long)1));
test_762 = (walker_362<aux_763);
}
if(test_762){
unsigned char aux_766;
{
long aux_767;
aux_767 = (walker_362+((long)1));
aux_766 = STRING_REF(string_360, aux_767);
}
test_757 = (aux_766==((unsigned char)':'));
}
 else {
test_757 = ((bool_t)0);
}
}
 else {
test_757 = ((bool_t)0);
}
}
if(test_757){
if((type_start_90_364>((long)0))){
FAILURE(BFALSE,string1201___expand,ident_9);}
 else {
long type_start_90_777;
long id_stop_141_776;
long walker_774;
walker_774 = (walker_362+((long)2));
id_stop_141_776 = walker_362;
type_start_90_777 = (walker_362+((long)2));
type_start_90_364 = type_start_90_777;
id_stop_141_363 = id_stop_141_776;
walker_362 = walker_774;
goto loop_365;
}
}
 else {
{
long walker_779;
walker_779 = (walker_362+((long)1));
walker_362 = walker_779;
goto loop_365;
}
}
}
}
}
}
}
}
 else {
FAILURE(BFALSE,string1201___expand,ident_9);}
}
}
}
}


/* _parse-formal-ident */obj_t _parse_formal_ident_255___expand(obj_t env_656, obj_t ident_657)
{
return parse_formal_ident_54___expand(ident_657);
}


/* imported-modules-init */obj_t imported_modules_init_94___expand()
{
module_initialization_70___type(((long)0), "__EXPAND");
module_initialization_70___error(((long)0), "__EXPAND");
module_initialization_70___bigloo(((long)0), "__EXPAND");
module_initialization_70___tvector(((long)0), "__EXPAND");
module_initialization_70___structure(((long)0), "__EXPAND");
module_initialization_70___bexit(((long)0), "__EXPAND");
module_initialization_70___os(((long)0), "__EXPAND");
module_initialization_70___r4_numbers_6_5(((long)0), "__EXPAND");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__EXPAND");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__EXPAND");
module_initialization_70___r4_characters_6_6(((long)0), "__EXPAND");
module_initialization_70___r4_equivalence_6_2(((long)0), "__EXPAND");
module_initialization_70___r4_booleans_6_1(((long)0), "__EXPAND");
module_initialization_70___r4_symbols_6_4(((long)0), "__EXPAND");
module_initialization_70___r4_strings_6_7(((long)0), "__EXPAND");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__EXPAND");
module_initialization_70___r4_input_6_10_2(((long)0), "__EXPAND");
module_initialization_70___r4_control_features_6_9(((long)0), "__EXPAND");
module_initialization_70___r4_vectors_6_8(((long)0), "__EXPAND");
module_initialization_70___r4_ports_6_10_1(((long)0), "__EXPAND");
module_initialization_70___r4_output_6_10_3(((long)0), "__EXPAND");
module_initialization_70___evenv(((long)0), "__EXPAND");
return module_initialization_70___macro(((long)0), "__EXPAND");
}

