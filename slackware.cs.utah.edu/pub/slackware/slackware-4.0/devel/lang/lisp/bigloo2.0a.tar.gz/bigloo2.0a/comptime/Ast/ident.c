/*===========================================================================*/
/*   (Ast/ident.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


static obj_t method_init_76_ast_ident();
extern obj_t string_to_symbol(char *);
static obj_t _id_of_id_229_ast_ident(obj_t, obj_t);
extern long get_hash_number(char *);
extern obj_t string_append(obj_t, obj_t);
static obj_t _user_symbol_1333_186_ast_ident(obj_t, obj_t);
extern obj_t id_of_id_112_ast_ident(obj_t);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
extern bool_t user_symbol__147_ast_ident(obj_t);
extern obj_t gensym___r4_symbols_6_4;
extern obj_t _obj__252_type_cache;
extern obj_t dsssl_defaulted_formal__174_tools_dsssl(obj_t);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t remove___ast_ident(obj_t);
static obj_t _c_keyword_list__101_ast_ident = BUNSPEC;
extern obj_t fast_id_of_id_130_ast_ident(obj_t);
extern type_t type_of_id_183_ast_ident(obj_t);
extern type_t get_default_type_181_type_cache();
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_dsssl(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _local_id__name1330_244_ast_ident(obj_t, obj_t);
static obj_t _parse_dsssl_92_ast_ident(obj_t, obj_t);
static obj_t imported_modules_init_94_ast_ident();
static bool_t legal_c_starting_identifier_char__221_ast_ident(unsigned char);
static obj_t _mark_symbol_non_user_1332_134_ast_ident(obj_t, obj_t);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _id__name_37_ast_ident(obj_t, obj_t);
extern obj_t string_downcase_77___r4_strings_6_7(obj_t);
extern obj_t parse_dsssl_9_ast_ident(obj_t);
extern obj_t id__name_228_ast_ident(obj_t);
extern obj_t dsssl_named_constant__188_tools_dsssl(obj_t);
static obj_t library_modules_init_112_ast_ident();
static obj_t _type_of_id_93_ast_ident(obj_t, obj_t);
extern type_t use_type__231_type_env(obj_t);
static obj_t toplevel_init_63_ast_ident();
extern obj_t open_input_string(obj_t);
static obj_t _parse_id_64_ast_ident(obj_t, obj_t);
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
extern obj_t local_id__name_204_ast_ident(obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
static obj_t _fast_id_of_id_85_ast_ident(obj_t, obj_t);
extern obj_t check_id_6_ast_ident(obj_t, obj_t);
extern obj_t make_string(long, unsigned char);
extern obj_t c_substring(obj_t, long, long);
static obj_t _check_id1331_108_ast_ident(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_ast_ident = BUNSPEC;
static obj_t scheme_id__c_id_79_ast_ident(obj_t, obj_t);
static obj_t cnst_init_137_ast_ident();
static obj_t __cnst[4];

DEFINE_EXPORT_PROCEDURE(local_id__name_env_236_ast_ident, _local_id__name1330_244_ast_ident1349, _local_id__name1330_244_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(mark_symbol_non_user__env_195_ast_ident, _mark_symbol_non_user_1332_134_ast_ident1350, _mark_symbol_non_user_1332_134_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(parse_dsssl_env_107_ast_ident, _parse_dsssl_92_ast_ident1351, _parse_dsssl_92_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(parse_id_env_180_ast_ident, _parse_id_64_ast_ident1352, _parse_id_64_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(user_symbol__env_177_ast_ident, _user_symbol_1333_186_ast_ident1353, _user_symbol_1333_186_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(id__name_env_140_ast_ident, _id__name_37_ast_ident1354, _id__name_37_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(fast_id_of_id_env_120_ast_ident, _fast_id_of_id_85_ast_ident1355, _fast_id_of_id_85_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(type_of_id_env_122_ast_ident, _type_of_id_93_ast_ident1356, _type_of_id_93_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(id_of_id_env_202_ast_ident, _id_of_id_229_ast_ident1357, _id_of_id_229_ast_ident, 0L, 1);
DEFINE_EXPORT_PROCEDURE(check_id_env_15_ast_ident, _check_id1331_108_ast_ident1358, _check_id1331_108_ast_ident, 0L, 2);
DEFINE_STRING(string1343_ast_ident, string1343_ast_ident1359, "NON-USER ERROR-IDENT DSSSL (\"asm\" \"auto\" \"break\" \"case\" \"char\" \"const\" \"continue\" \"default\" \"do\" \"double\" \"else\" \"entry\" \"enum\" \"extern\" \"float\" \"for\" \"fortran\" \"goto\" \"if\" \"int\" \"long\" \"register\" \"return\" \"short\" \"signed\" \"sizeof\" \"static\" \"struct\" \"switch\" \"typedef\" \"union\" \"unsigned\" \"void\" \"volatile\" \"while\" \"main\") ", 322);
DEFINE_STRING(string1342_ast_ident, string1342_ast_ident1360, "Illegal formal parameter", 24);
DEFINE_STRING(string1341_ast_ident, string1341_ast_ident1361, "_n_o_f_u_c_k_i_n_g___init_or_fini", 33);
DEFINE_STRING(string1339_ast_ident, string1339_ast_ident1362, "Illegal formal identifier", 25);
DEFINE_STRING(string1340_ast_ident, string1340_ast_ident1363, "_", 1);
DEFINE_STRING(string1338_ast_ident, string1338_ast_ident1364, "type-of-id", 10);
DEFINE_STRING(string1337_ast_ident, string1337_ast_ident1365, "", 0);
DEFINE_STRING(string1336_ast_ident, string1336_ast_ident1366, "parse", 5);
DEFINE_STRING(string1335_ast_ident, string1335_ast_ident1367, "`'", 2);
DEFINE_STRING(string1334_ast_ident, string1334_ast_ident1368, "Illegal identifier", 18);


/* module-initialization */ obj_t 
module_initialization_70_ast_ident(long checksum_556, char *from_557)
{
   if (CBOOL(require_initialization_114_ast_ident))
     {
	require_initialization_114_ast_ident = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_ident();
	cnst_init_137_ast_ident();
	imported_modules_init_94_ast_ident();
	method_init_76_ast_ident();
	toplevel_init_63_ast_ident();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_ident()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "AST_IDENT");
   module_initialization_70___r4_strings_6_7(((long) 0), "AST_IDENT");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "AST_IDENT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "AST_IDENT");
   module_initialization_70___reader(((long) 0), "AST_IDENT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_ident()
{
   {
      obj_t cnst_port_138_548;
      cnst_port_138_548 = open_input_string(string1343_ast_ident);
      {
	 long i_549;
	 i_549 = ((long) 3);
       loop_550:
	 {
	    bool_t test1344_551;
	    test1344_551 = (i_549 == ((long) -1));
	    if (test1344_551)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1345_552;
		    {
		       obj_t list1346_553;
		       {
			  obj_t arg1347_554;
			  arg1347_554 = BNIL;
			  list1346_553 = MAKE_PAIR(cnst_port_138_548, arg1347_554);
		       }
		       arg1345_552 = read___reader(list1346_553);
		    }
		    CNST_TABLE_SET(i_549, arg1345_552);
		 }
		 {
		    int aux_555;
		    {
		       long aux_577;
		       aux_577 = (i_549 - ((long) 1));
		       aux_555 = (int) (aux_577);
		    }
		    {
		       long i_580;
		       i_580 = (long) (aux_555);
		       i_549 = i_580;
		       goto loop_550;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_ident()
{
   {
      obj_t l1028_62;
      l1028_62 = CNST_TABLE_REF(((long) 0));
      {
	 obj_t head1030_64;
	 {
	    obj_t arg1058_75;
	    {
	       char *aux_583;
	       {
		  obj_t aux_584;
		  aux_584 = CAR(l1028_62);
		  aux_583 = BSTRING_TO_STRING(aux_584);
	       }
	       arg1058_75 = string_to_symbol(aux_583);
	    }
	    head1030_64 = MAKE_PAIR(arg1058_75, BNIL);
	 }
	 {
	    obj_t l1028_65;
	    obj_t tail1031_66;
	    l1028_65 = CDR(l1028_62);
	    tail1031_66 = head1030_64;
	  lname1029_67:
	    if (NULLP(l1028_65))
	      {
		 return (_c_keyword_list__101_ast_ident = head1030_64,
		    BUNSPEC);
	      }
	    else
	      {
		 obj_t newtail1032_70;
		 {
		    obj_t arg1055_72;
		    {
		       char *aux_591;
		       {
			  obj_t aux_592;
			  aux_592 = CAR(l1028_65);
			  aux_591 = BSTRING_TO_STRING(aux_592);
		       }
		       arg1055_72 = string_to_symbol(aux_591);
		    }
		    newtail1032_70 = MAKE_PAIR(arg1055_72, BNIL);
		 }
		 SET_CDR(tail1031_66, newtail1032_70);
		 {
		    obj_t tail1031_600;
		    obj_t l1028_598;
		    l1028_598 = CDR(l1028_65);
		    tail1031_600 = newtail1032_70;
		    tail1031_66 = tail1031_600;
		    l1028_65 = l1028_598;
		    goto lname1029_67;
		 }
	      }
	 }
      }
   }
}


/* type-of-id */ type_t 
type_of_id_183_ast_ident(obj_t id_1)
{
   if (SYMBOLP(id_1))
     {
	obj_t arg1077_79;
	arg1077_79 = parse_id_241_ast_ident(id_1);
	{
	   obj_t aux_605;
	   aux_605 = CDR(arg1077_79);
	   return (type_t) (aux_605);
	}
     }
   else
     {
	obj_t aux_608;
	aux_608 = user_error_151_tools_error(string1334_ast_ident, string1335_ast_ident, id_1, BNIL);
	return (type_t) (aux_608);
     }
}


/* _type-of-id */ obj_t 
_type_of_id_93_ast_ident(obj_t env_527, obj_t id_528)
{
   {
      type_t aux_611;
      aux_611 = type_of_id_183_ast_ident(id_528);
      return (obj_t) (aux_611);
   }
}


/* id-of-id */ obj_t 
id_of_id_112_ast_ident(obj_t id_2)
{
   if (SYMBOLP(id_2))
     {
	obj_t arg1137_82;
	arg1137_82 = parse_id_241_ast_ident(id_2);
	return CAR(arg1137_82);
     }
   else
     {
	return user_error_151_tools_error(string1336_ast_ident, string1334_ast_ident, id_2, BNIL);
     }
}


/* _id-of-id */ obj_t 
_id_of_id_229_ast_ident(obj_t env_529, obj_t id_530)
{
   return id_of_id_112_ast_ident(id_530);
}


/* fast-id-of-id */ obj_t 
fast_id_of_id_130_ast_ident(obj_t id_3)
{
   {
      bool_t test1139_84;
      {
	 obj_t aux_620;
	 aux_620 = dsssl_named_constant__188_tools_dsssl(id_3);
	 test1139_84 = CBOOL(aux_620);
      }
      if (test1139_84)
	{
	   return PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 1)), BEOA);
	}
      else
	{
	   bool_t test_627;
	   if (PAIRP(id_3))
	     {
		obj_t aux_630;
		aux_630 = CAR(id_3);
		test_627 = SYMBOLP(aux_630);
	     }
	   else
	     {
		test_627 = ((bool_t) 0);
	     }
	   if (test_627)
	     {
		return CAR(id_3);
	     }
	   else
	     {
		if (SYMBOLP(id_3))
		  {
		     {
			obj_t string_88;
			string_88 = SYMBOL_TO_STRING(id_3);
			{
			   long len_89;
			   len_89 = STRING_LENGTH(string_88);
			   {
			      {
				 long walker_90;
				 walker_90 = ((long) 0);
			       loop_91:
				 if ((walker_90 == len_89))
				   {
				      return id_3;
				   }
				 else
				   {
				      bool_t test_640;
				      {
					 bool_t test_641;
					 {
					    unsigned char aux_642;
					    aux_642 = STRING_REF(string_88, walker_90);
					    test_641 = (aux_642 == ((unsigned char) ':'));
					 }
					 if (test_641)
					   {
					      bool_t test_645;
					      {
						 long aux_646;
						 aux_646 = (len_89 - ((long) 1));
						 test_645 = (walker_90 < aux_646);
					      }
					      if (test_645)
						{
						   unsigned char aux_649;
						   {
						      long aux_650;
						      aux_650 = (walker_90 + ((long) 1));
						      aux_649 = STRING_REF(string_88, aux_650);
						   }
						   test_640 = (aux_649 == ((unsigned char) ':'));
						}
					      else
						{
						   test_640 = ((bool_t) 0);
						}
					   }
					 else
					   {
					      test_640 = ((bool_t) 0);
					   }
				      }
				      if (test_640)
					{
					   {
					      obj_t arg1150_94;
					      arg1150_94 = c_substring(string_88, ((long) 0), walker_90);
					      {
						 char *aux_655;
						 aux_655 = BSTRING_TO_STRING(arg1150_94);
						 return string_to_symbol(aux_655);
					      }
					   }
					}
				      else
					{
					   {
					      long walker_658;
					      walker_658 = (walker_90 + ((long) 1));
					      walker_90 = walker_658;
					      goto loop_91;
					   }
					}
				   }
			      }
			   }
			}
		     }
		  }
		else
		  {
		     return user_error_151_tools_error(string1336_ast_ident, string1334_ast_ident, id_3, BNIL);
		  }
	     }
	}
   }
}


/* _fast-id-of-id */ obj_t 
_fast_id_of_id_85_ast_ident(obj_t env_531, obj_t id_532)
{
   return fast_id_of_id_130_ast_ident(id_532);
}


/* parse-id */ obj_t 
parse_id_241_ast_ident(obj_t id_4)
{
   if (SYMBOLP(id_4))
     {
	obj_t string_106;
	string_106 = SYMBOL_TO_STRING(id_4);
	{
	   long len_107;
	   len_107 = STRING_LENGTH(string_106);
	   {
	      {
		 long walker_108;
		 long id_stop_141_109;
		 long type_start_90_110;
		 walker_108 = ((long) 0);
		 id_stop_141_109 = ((long) 0);
		 type_start_90_110 = ((long) 0);
	       loop_111:
		 if ((walker_108 == len_107))
		   {
		      {
			 bool_t test_668;
			 if ((id_stop_141_109 == ((long) 0)))
			   {
			      test_668 = (type_start_90_110 > ((long) 0));
			   }
			 else
			   {
			      test_668 = ((bool_t) 0);
			   }
			 if (test_668)
			   {
			      {
				 obj_t id_114;
				 obj_t tid_115;
				 {
				    char *aux_672;
				    aux_672 = BSTRING_TO_STRING(string1337_ast_ident);
				    id_114 = string_to_symbol(aux_672);
				 }
				 {
				    obj_t arg1194_117;
				    arg1194_117 = c_substring(string_106, type_start_90_110, len_107);
				    {
				       char *aux_676;
				       aux_676 = BSTRING_TO_STRING(arg1194_117);
				       tid_115 = string_to_symbol(aux_676);
				    }
				 }
				 {
				    type_t arg1193_116;
				    arg1193_116 = use_type__231_type_env(tid_115);
				    {
				       obj_t aux_680;
				       aux_680 = (obj_t) (arg1193_116);
				       return MAKE_PAIR(id_114, aux_680);
				    }
				 }
			      }
			   }
			 else
			   {
			      if ((id_stop_141_109 == ((long) 0)))
				{
				   {
				      type_t arg1196_119;
				      arg1196_119 = get_default_type_181_type_cache();
				      {
					 obj_t aux_686;
					 aux_686 = (obj_t) (arg1196_119);
					 return MAKE_PAIR(id_4, aux_686);
				      }
				   }
				}
			      else
				{
				   if ((type_start_90_110 == len_107))
				     {
					{
					   obj_t arg1201_123;
					   {
					      obj_t arg1204_126;
					      type_t arg1205_127;
					      arg1204_126 = CNST_TABLE_REF(((long) 2));
					      arg1205_127 = get_default_type_181_type_cache();
					      {
						 obj_t aux_693;
						 aux_693 = (obj_t) (arg1205_127);
						 arg1201_123 = MAKE_PAIR(arg1204_126, aux_693);
					      }
					   }
					   {
					      obj_t list1202_124;
					      list1202_124 = MAKE_PAIR(arg1201_123, BNIL);
					      return user_error_151_tools_error(string1338_ast_ident, string1339_ast_ident, id_4, list1202_124);
					   }
					}
				     }
				   else
				     {
					{
					   obj_t id_128;
					   obj_t tid_129;
					   {
					      obj_t arg1207_131;
					      arg1207_131 = c_substring(string_106, ((long) 0), id_stop_141_109);
					      {
						 char *aux_699;
						 aux_699 = BSTRING_TO_STRING(arg1207_131);
						 id_128 = string_to_symbol(aux_699);
					      }
					   }
					   {
					      obj_t arg1209_132;
					      arg1209_132 = c_substring(string_106, type_start_90_110, len_107);
					      {
						 char *aux_703;
						 aux_703 = BSTRING_TO_STRING(arg1209_132);
						 tid_129 = string_to_symbol(aux_703);
					      }
					   }
					   {
					      type_t arg1206_130;
					      arg1206_130 = use_type__231_type_env(tid_129);
					      {
						 obj_t aux_707;
						 aux_707 = (obj_t) (arg1206_130);
						 return MAKE_PAIR(id_128, aux_707);
					      }
					   }
					}
				     }
				}
			   }
		      }
		   }
		 else
		   {
		      bool_t test_710;
		      {
			 bool_t test_711;
			 {
			    unsigned char aux_712;
			    aux_712 = STRING_REF(string_106, walker_108);
			    test_711 = (aux_712 == ((unsigned char) ':'));
			 }
			 if (test_711)
			   {
			      bool_t test_715;
			      {
				 long aux_716;
				 aux_716 = (len_107 - ((long) 1));
				 test_715 = (walker_108 < aux_716);
			      }
			      if (test_715)
				{
				   unsigned char aux_719;
				   {
				      long aux_720;
				      aux_720 = (walker_108 + ((long) 1));
				      aux_719 = STRING_REF(string_106, aux_720);
				   }
				   test_710 = (aux_719 == ((unsigned char) ':'));
				}
			      else
				{
				   test_710 = ((bool_t) 0);
				}
			   }
			 else
			   {
			      test_710 = ((bool_t) 0);
			   }
		      }
		      if (test_710)
			{
			   if ((type_start_90_110 > ((long) 0)))
			     {
				obj_t arg1216_138;
				{
				   obj_t arg1220_141;
				   type_t arg1221_142;
				   arg1220_141 = CNST_TABLE_REF(((long) 2));
				   arg1221_142 = get_default_type_181_type_cache();
				   {
				      obj_t aux_728;
				      aux_728 = (obj_t) (arg1221_142);
				      arg1216_138 = MAKE_PAIR(arg1220_141, aux_728);
				   }
				}
				{
				   obj_t list1217_139;
				   list1217_139 = MAKE_PAIR(arg1216_138, BNIL);
				   return user_error_151_tools_error(string1338_ast_ident, string1339_ast_ident, id_4, list1217_139);
				}
			     }
			   else
			     {
				long type_start_90_736;
				long id_stop_141_735;
				long walker_733;
				walker_733 = (walker_108 + ((long) 2));
				id_stop_141_735 = walker_108;
				type_start_90_736 = (walker_108 + ((long) 2));
				type_start_90_110 = type_start_90_736;
				id_stop_141_109 = id_stop_141_735;
				walker_108 = walker_733;
				goto loop_111;
			     }
			}
		      else
			{
			   {
			      long walker_738;
			      walker_738 = (walker_108 + ((long) 1));
			      walker_108 = walker_738;
			      goto loop_111;
			   }
			}
		   }
	      }
	   }
	}
     }
   else
     {
	return user_error_151_tools_error(string1336_ast_ident, string1334_ast_ident, id_4, BNIL);
     }
}


/* _parse-id */ obj_t 
_parse_id_64_ast_ident(obj_t env_533, obj_t id_534)
{
   return parse_id_241_ast_ident(id_534);
}


/* id->name */ obj_t 
id__name_228_ast_ident(obj_t id_5)
{
   if (SYMBOLP(id_5))
     {
	obj_t name_154;
	{
	   obj_t arg1240_157;
	   arg1240_157 = SYMBOL_TO_STRING(id_5);
	   name_154 = string_downcase_77___r4_strings_6_7(arg1240_157);
	}
	{
	   obj_t arg1236_155;
	   {
	      obj_t arg1238_156;
	      {
		 char *aux_746;
		 aux_746 = BSTRING_TO_STRING(name_154);
		 arg1238_156 = string_to_symbol(aux_746);
	      }
	      arg1236_155 = memq___r4_pairs_and_lists_6_3(arg1238_156, _c_keyword_list__101_ast_ident);
	   }
	   return scheme_id__c_id_79_ast_ident(name_154, arg1236_155);
	}
     }
   else
     {
	return user_error_151_tools_error(string1336_ast_ident, string1334_ast_ident, id_5, BNIL);
     }
}


/* _id->name */ obj_t 
_id__name_37_ast_ident(obj_t env_535, obj_t id_536)
{
   return id__name_228_ast_ident(id_536);
}


/* local-id->name */ obj_t 
local_id__name_204_ast_ident(obj_t id_6)
{
   {
      obj_t name_376;
      {
	 obj_t arg1243_377;
	 arg1243_377 = SYMBOL_TO_STRING(id_6);
	 name_376 = string_downcase_77___r4_strings_6_7(arg1243_377);
      }
      return scheme_id__c_id_79_ast_ident(name_376, BFALSE);
   }
}


/* _local-id->name1330 */ obj_t 
_local_id__name1330_244_ast_ident(obj_t env_537, obj_t id_538)
{
   return local_id__name_204_ast_ident(id_538);
}


/* scheme-id->c-id */ obj_t 
scheme_id__c_id_79_ast_ident(obj_t string_7, obj_t rg_8)
{
   {
      obj_t string_193;
      {
	 long len_163;
	 len_163 = STRING_LENGTH(string_7);
	 if ((len_163 == ((long) 0)))
	   {
	      return string1340_ast_ident;
	   }
	 else
	   {
	      bool_t test_760;
	      {
		 obj_t aux_761;
		 string_193 = string_7;
		 if (CBOOL(rg_8))
		   {
		      aux_761 = rg_8;
		   }
		 else
		   {
		      bool_t _ortest_1035_196;
		      if (legal_c_starting_identifier_char__221_ast_ident(STRING_REF(string_193, ((long) 0))))
			{
			   _ortest_1035_196 = ((bool_t) 0);
			}
		      else
			{
			   _ortest_1035_196 = ((bool_t) 1);
			}
		      if (_ortest_1035_196)
			{
			   aux_761 = BBOOL(_ortest_1035_196);
			}
		      else
			{
			   long len_197;
			   len_197 = STRING_LENGTH(string_193);
			   {
			      long i_198;
			      {
				 bool_t aux_770;
				 i_198 = ((long) 0);
			       loop_199:
				 if ((i_198 == len_197))
				   {
				      aux_770 = ((bool_t) 0);
				   }
				 else
				   {
				      unsigned char c_201;
				      c_201 = STRING_REF(string_193, i_198);
				      {
					 bool_t test_774;
					 {
					    bool_t test_775;
					    {
					       unsigned char c_441;
					       c_441 = toupper(c_201);
					       if ((c_441 >= ((unsigned char) 'A')))
						 {
						    test_775 = (c_441 <= ((unsigned char) 'Z'));
						 }
					       else
						 {
						    test_775 = ((bool_t) 0);
						 }
					    }
					    if (test_775)
					      {
						 test_774 = ((bool_t) 1);
					      }
					    else
					      {
						 bool_t test_780;
						 if ((c_201 >= ((unsigned char) '0')))
						   {
						      test_780 = (c_201 <= ((unsigned char) '9'));
						   }
						 else
						   {
						      test_780 = ((bool_t) 0);
						   }
						 if (test_780)
						   {
						      test_774 = ((bool_t) 1);
						   }
						 else
						   {
						      test_774 = (c_201 == ((unsigned char) '_'));
						   }
					      }
					 }
					 if (test_774)
					   {
					      long i_785;
					      i_785 = (i_198 + ((long) 1));
					      i_198 = i_785;
					      goto loop_199;
					   }
					 else
					   {
					      aux_770 = ((bool_t) 1);
					   }
				      }
				   }
				 aux_761 = BBOOL(aux_770);
			      }
			   }
			}
		   }
		 test_760 = CBOOL(aux_761);
	      }
	      if (test_760)
		{
		   {
		      obj_t res_167;
		      {
			 obj_t res1324_389;
			 {
			    long aux_789;
			    {
			       int aux_790;
			       aux_790 = (int) (len_163);
			       aux_789 = (long) (aux_790);
			    }
			    res1324_389 = make_string(aux_789, ((unsigned char) ' '));
			 }
			 res_167 = res1324_389;
		      }
		      {
			 {
			    long i_168;
			    i_168 = ((long) 0);
			  loop_169:
			    if ((i_168 == len_163))
			      {
				 obj_t str_171;
				 {
				    char *arg1251_176;
				    {
				       long arg1256_181;
				       {
					  char *aux_796;
					  aux_796 = BSTRING_TO_STRING(string_7);
					  arg1256_181 = get_hash_number(aux_796);
				       }
				       arg1251_176 = integer__string_135___r4_numbers_6_5_fixnum(arg1256_181, BNIL);
				    }
				    {
				       obj_t list1252_177;
				       {
					  obj_t arg1253_178;
					  {
					     obj_t arg1254_179;
					     {
						obj_t aux_800;
						aux_800 = string_to_bstring(arg1251_176);
						arg1254_179 = MAKE_PAIR(aux_800, BNIL);
					     }
					     arg1253_178 = MAKE_PAIR(string1340_ast_ident, arg1254_179);
					  }
					  list1252_177 = MAKE_PAIR(res_167, arg1253_178);
				       }
				       str_171 = string_append_106___r4_strings_6_7(list1252_177);
				    }
				 }
				 {
				    unsigned char cs_172;
				    cs_172 = STRING_REF(str_171, ((long) 0));
				    {
				       if ((cs_172 == ((unsigned char) '_')))
					 {
					    return remove___ast_ident(str_171);
					 }
				       else
					 {
					    if (legal_c_starting_identifier_char__221_ast_ident(cs_172))
					      {
						 return str_171;
					      }
					    else
					      {
						 return string_append(string1340_ast_ident, str_171);
					      }
					 }
				    }
				 }
			      }
			    else
			      {
				 unsigned char c_183;
				 c_183 = STRING_REF(string_7, i_168);
				 {
				    bool_t test_814;
				    {
				       bool_t test_815;
				       {
					  unsigned char c_400;
					  c_400 = toupper(c_183);
					  if ((c_400 >= ((unsigned char) 'A')))
					    {
					       test_815 = (c_400 <= ((unsigned char) 'Z'));
					    }
					  else
					    {
					       test_815 = ((bool_t) 0);
					    }
				       }
				       if (test_815)
					 {
					    test_814 = ((bool_t) 1);
					 }
				       else
					 {
					    bool_t test_820;
					    if ((c_183 >= ((unsigned char) '0')))
					      {
						 test_820 = (c_183 <= ((unsigned char) '9'));
					      }
					    else
					      {
						 test_820 = ((bool_t) 0);
					      }
					    if (test_820)
					      {
						 test_814 = ((bool_t) 1);
					      }
					    else
					      {
						 test_814 = (c_183 == ((unsigned char) '_'));
					      }
					 }
				    }
				    if (test_814)
				      {
					 STRING_SET(res_167, i_168, c_183);
					 {
					    long i_826;
					    i_826 = (i_168 + ((long) 1));
					    i_168 = i_826;
					    goto loop_169;
					 }
				      }
				    else
				      {
					 STRING_SET(res_167, i_168, ((unsigned char) '_'));
					 {
					    long i_829;
					    i_829 = (i_168 + ((long) 1));
					    i_168 = i_829;
					    goto loop_169;
					 }
				      }
				 }
			      }
			 }
		      }
		   }
		}
	      else
		{
		   {
		      bool_t test_831;
		      {
			 unsigned char aux_832;
			 aux_832 = STRING_REF(string_7, ((long) 0));
			 test_831 = (aux_832 == ((unsigned char) '_'));
		      }
		      if (test_831)
			{
			   return remove___ast_ident(string_7);
			}
		      else
			{
			   return string_7;
			}
		   }
		}
	   }
      }
   }
}


/* legal-c-starting-identifier-char? */ bool_t 
legal_c_starting_identifier_char__221_ast_ident(unsigned char c_208)
{
   {
      bool_t _ortest_1033_210;
      {
	 unsigned char c_461;
	 c_461 = toupper(c_208);
	 if ((c_461 >= ((unsigned char) 'A')))
	   {
	      _ortest_1033_210 = (c_461 <= ((unsigned char) 'Z'));
	   }
	 else
	   {
	      _ortest_1033_210 = ((bool_t) 0);
	   }
      }
      if (_ortest_1033_210)
	{
	   return _ortest_1033_210;
	}
      else
	{
	   return (c_208 == ((unsigned char) '_'));
	}
   }
}


/* remove__ */ obj_t 
remove___ast_ident(obj_t string_9)
{
   {
      bool_t test_842;
      {
	 long aux_843;
	 aux_843 = STRING_LENGTH(string_9);
	 test_842 = (aux_843 >= ((long) 6));
      }
      if (test_842)
	{
	   bool_t test_846;
	   {
	      unsigned char aux_847;
	      aux_847 = STRING_REF(string_9, ((long) 0));
	      test_846 = (aux_847 == ((unsigned char) '_'));
	   }
	   if (test_846)
	     {
		bool_t test_850;
		{
		   unsigned char aux_851;
		   aux_851 = STRING_REF(string_9, ((long) 1));
		   test_850 = (aux_851 == ((unsigned char) '_'));
		}
		if (test_850)
		  {
		     bool_t test_854;
		     {
			bool_t test_855;
			{
			   unsigned char aux_856;
			   aux_856 = STRING_REF(string_9, ((long) 2));
			   test_855 = (aux_856 == ((unsigned char) 'i'));
			}
			if (test_855)
			  {
			     test_854 = ((bool_t) 0);
			  }
			else
			  {
			     bool_t test_859;
			     {
				unsigned char aux_860;
				aux_860 = STRING_REF(string_9, ((long) 2));
				test_859 = (aux_860 == ((unsigned char) 'f'));
			     }
			     if (test_859)
			       {
				  test_854 = ((bool_t) 0);
			       }
			     else
			       {
				  test_854 = ((bool_t) 1);
			       }
			  }
		     }
		     if (test_854)
		       {
			  return string_9;
		       }
		     else
		       {
			  bool_t test_863;
			  {
			     bool_t test_864;
			     {
				unsigned char aux_865;
				aux_865 = STRING_REF(string_9, ((long) 3));
				test_864 = (aux_865 == ((unsigned char) 'n'));
			     }
			     if (test_864)
			       {
				  test_863 = ((bool_t) 0);
			       }
			     else
			       {
				  bool_t test_868;
				  {
				     unsigned char aux_869;
				     aux_869 = STRING_REF(string_9, ((long) 3));
				     test_868 = (aux_869 == ((unsigned char) 'i'));
				  }
				  if (test_868)
				    {
				       test_863 = ((bool_t) 0);
				    }
				  else
				    {
				       test_863 = ((bool_t) 1);
				    }
			       }
			  }
			  if (test_863)
			    {
			       return string_9;
			    }
			  else
			    {
			       bool_t test_872;
			       {
				  bool_t test_873;
				  {
				     unsigned char aux_874;
				     aux_874 = STRING_REF(string_9, ((long) 4));
				     test_873 = (aux_874 == ((unsigned char) 'i'));
				  }
				  if (test_873)
				    {
				       test_872 = ((bool_t) 0);
				    }
				  else
				    {
				       bool_t test_877;
				       {
					  unsigned char aux_878;
					  aux_878 = STRING_REF(string_9, ((long) 4));
					  test_877 = (aux_878 == ((unsigned char) 'n'));
				       }
				       if (test_877)
					 {
					    test_872 = ((bool_t) 0);
					 }
				       else
					 {
					    test_872 = ((bool_t) 1);
					 }
				    }
			       }
			       if (test_872)
				 {
				    return string_9;
				 }
			       else
				 {
				    bool_t test_881;
				    {
				       bool_t test_882;
				       {
					  unsigned char aux_883;
					  aux_883 = STRING_REF(string_9, ((long) 5));
					  test_882 = (aux_883 == ((unsigned char) 't'));
				       }
				       if (test_882)
					 {
					    test_881 = ((bool_t) 0);
					 }
				       else
					 {
					    bool_t test_886;
					    {
					       unsigned char aux_887;
					       aux_887 = STRING_REF(string_9, ((long) 5));
					       test_886 = (aux_887 == ((unsigned char) 'i'));
					    }
					    if (test_886)
					      {
						 test_881 = ((bool_t) 0);
					      }
					    else
					      {
						 test_881 = ((bool_t) 1);
					      }
					 }
				    }
				    if (test_881)
				      {
					 return string_9;
				      }
				    else
				      {
					 bool_t test_890;
					 {
					    unsigned char aux_891;
					    aux_891 = STRING_REF(string_9, ((long) 6));
					    test_890 = (aux_891 == ((unsigned char) '_'));
					 }
					 if (test_890)
					   {
					      return string_append(string1341_ast_ident, string_9);
					   }
					 else
					   {
					      return string_9;
					   }
				      }
				 }
			    }
		       }
		  }
		else
		  {
		     return string_9;
		  }
	     }
	   else
	     {
		return string_9;
	     }
	}
      else
	{
	   return string_9;
	}
   }
}


/* check-id */ obj_t 
check_id_6_ast_ident(obj_t id_10, obj_t src_11)
{
   {
      bool_t test1310_242;
      {
	 obj_t arg1313_244;
	 obj_t arg1315_245;
	 arg1313_244 = CAR(id_10);
	 {
	    char *aux_896;
	    aux_896 = BSTRING_TO_STRING(string1337_ast_ident);
	    arg1315_245 = string_to_symbol(aux_896);
	 }
	 test1310_242 = (arg1313_244 == arg1315_245);
      }
      if (test1310_242)
	{
	   return user_error_151_tools_error(string1334_ast_ident, string1335_ast_ident, src_11, BNIL);
	}
      else
	{
	   return id_10;
	}
   }
}


/* _check-id1331 */ obj_t 
_check_id1331_108_ast_ident(obj_t env_539, obj_t id_540, obj_t src_541)
{
   return check_id_6_ast_ident(id_540, src_541);
}


/* parse-dsssl */ obj_t 
parse_dsssl_9_ast_ident(obj_t obj_12)
{
   {
      bool_t test1316_246;
      {
	 obj_t aux_903;
	 aux_903 = dsssl_named_constant__188_tools_dsssl(obj_12);
	 test1316_246 = CBOOL(aux_903);
      }
      if (test1316_246)
	{
	   {
	      obj_t obj2_523;
	      obj2_523 = _obj__252_type_cache;
	      return MAKE_PAIR(obj_12, obj2_523);
	   }
	}
      else
	{
	   bool_t test1317_247;
	   {
	      obj_t aux_908;
	      aux_908 = dsssl_defaulted_formal__174_tools_dsssl(obj_12);
	      test1317_247 = CBOOL(aux_908);
	   }
	   if (test1317_247)
	     {
		{
		   obj_t obj2_525;
		   obj2_525 = _obj__252_type_cache;
		   return MAKE_PAIR(obj_12, obj2_525);
		}
	     }
	   else
	     {
		return user_error_151_tools_error(string1342_ast_ident, string1337_ast_ident, obj_12, BNIL);
	     }
	}
   }
}


/* _parse-dsssl */ obj_t 
_parse_dsssl_92_ast_ident(obj_t env_542, obj_t obj_543)
{
   return parse_dsssl_9_ast_ident(obj_543);
}


/* mark-symbol-non-user! */ obj_t 
mark_symbol_non_user__17_ast_ident(obj_t sym_13)
{
   putprop__88___r4_symbols_6_4(sym_13, CNST_TABLE_REF(((long) 3)), BTRUE);
   return sym_13;
}


/* _mark-symbol-non-user!1332 */ obj_t 
_mark_symbol_non_user_1332_134_ast_ident(obj_t env_544, obj_t sym_545)
{
   return mark_symbol_non_user__17_ast_ident(sym_545);
}


/* user-symbol? */ bool_t 
user_symbol__147_ast_ident(obj_t symbol_14)
{
   {
      bool_t test_918;
      {
	 obj_t aux_919;
	 aux_919 = getprop___r4_symbols_6_4(symbol_14, CNST_TABLE_REF(((long) 3)));
	 test_918 = CBOOL(aux_919);
      }
      if (test_918)
	{
	   return ((bool_t) 0);
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* _user-symbol?1333 */ obj_t 
_user_symbol_1333_186_ast_ident(obj_t env_546, obj_t symbol_547)
{
   {
      bool_t aux_923;
      aux_923 = user_symbol__147_ast_ident(symbol_547);
      return BBOOL(aux_923);
   }
}


/* method-init */ obj_t 
method_init_76_ast_ident()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_ident()
{
   module_initialization_70_tools_error(((long) 0), "AST_IDENT");
   module_initialization_70_tools_dsssl(((long) 0), "AST_IDENT");
   module_initialization_70_type_type(((long) 0), "AST_IDENT");
   module_initialization_70_type_env(((long) 0), "AST_IDENT");
   return module_initialization_70_type_cache(((long) 0), "AST_IDENT");
}
