/*===========================================================================*/
/*   (Foreign/cenum.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct calias
  {
     bool_t array__248;
  }
      *calias_t;

typedef struct cenum
  {
     struct type *btype;
     obj_t literals;
  }
     *cenum_t;

typedef struct cfunction
  {
     struct type *btype;
     long arity;
     struct type *type_res_48;
     obj_t type_args_244;
  }
         *cfunction_t;

typedef struct cptr
  {
     struct type *btype;
     struct type *point_to_164;
     bool_t array__248;
  }
    *cptr_t;

typedef struct cstruct
  {
     bool_t struct__46;
     obj_t fields;
     obj_t cstruct__170;
  }
       *cstruct_t;

typedef struct cstruct__170
  {
     struct type *btype;
     struct cstruct *cstruct;
  }
            *cstruct__170_t;

typedef struct ccomp
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t producer;
     obj_t consumer;
     obj_t finalizer;
     obj_t checksummer;
  }
     *ccomp_t;


static obj_t method_init_76_foreign_cenum();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t string_sans___40_type_tools(obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_foreign_cenum(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_tools(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_foreign_ctype(long, char *);
extern obj_t module_initialization_70_foreign_access(long, char *);
extern obj_t module_initialization_70_module_module(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
static obj_t _make_ctype_accesses_1498_88_foreign_access(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_foreign_cenum();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t produce_module_clause__172_module_module(obj_t);
static obj_t library_modules_init_112_foreign_cenum();
static obj_t toplevel_init_63_foreign_cenum();
extern obj_t open_input_string(obj_t);
extern obj_t cenum_foreign_ctype;
static obj_t make_ctype_accesses__cenum_245_foreign_cenum(obj_t, obj_t, obj_t);
extern obj_t _4dots_199_tools_misc;
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_foreign_cenum = BUNSPEC;
static obj_t cnst_init_137_foreign_cenum();
static obj_t __cnst[25];

DEFINE_STATIC_PROCEDURE(proc1499_foreign_cenum, make_ctype_accesses__cenum_245_foreign_cenum1512, make_ctype_accesses__cenum_245_foreign_cenum, 0L, 2);
extern obj_t make_ctype_accesses__env_11_foreign_access;
DEFINE_STRING(string1504_foreign_cenum, string1504_foreign_cenum1513, "PREDICATE-OF ::OBJ INLINE STATIC FOREIGN SYMBOL MACRO QUOTE FOREIGN-ID EQ? O FOREIGN? IF O::OBJ PRAGMA::BOOL O2 O1 ?::BOOL = PRAGMA DEFINE-INLINE - ::BOOL ? -> ", 160);
DEFINE_STRING(string1503_foreign_cenum, string1503_foreign_cenum1514, "cobj_to_foreign", 15);
DEFINE_STRING(string1502_foreign_cenum, string1502_foreign_cenum1515, "(", 1);
DEFINE_STRING(string1501_foreign_cenum, string1501_foreign_cenum1516, ")FOREIGN_TO_COBJ", 16);
DEFINE_STRING(string1500_foreign_cenum, string1500_foreign_cenum1517, "($1 == $2)", 10);


/* module-initialization */ obj_t 
module_initialization_70_foreign_cenum(long checksum_804, char *from_805)
{
   if (CBOOL(require_initialization_114_foreign_cenum))
     {
	require_initialization_114_foreign_cenum = BBOOL(((bool_t) 0));
	library_modules_init_112_foreign_cenum();
	cnst_init_137_foreign_cenum();
	imported_modules_init_94_foreign_cenum();
	method_init_76_foreign_cenum();
	toplevel_init_63_foreign_cenum();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_foreign_cenum()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "FOREIGN_CENUM");
   module_initialization_70___object(((long) 0), "FOREIGN_CENUM");
   module_initialization_70___r4_strings_6_7(((long) 0), "FOREIGN_CENUM");
   module_initialization_70___reader(((long) 0), "FOREIGN_CENUM");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "FOREIGN_CENUM");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_foreign_cenum()
{
   {
      obj_t cnst_port_138_796;
      cnst_port_138_796 = open_input_string(string1504_foreign_cenum);
      {
	 long i_797;
	 i_797 = ((long) 24);
       loop_798:
	 {
	    bool_t test1505_799;
	    test1505_799 = (i_797 == ((long) -1));
	    if (test1505_799)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1507_800;
		    {
		       obj_t list1508_801;
		       {
			  obj_t arg1510_802;
			  arg1510_802 = BNIL;
			  list1508_801 = MAKE_PAIR(cnst_port_138_796, arg1510_802);
		       }
		       arg1507_800 = read___reader(list1508_801);
		    }
		    CNST_TABLE_SET(i_797, arg1507_800);
		 }
		 {
		    int aux_803;
		    {
		       long aux_825;
		       aux_825 = (i_797 - ((long) 1));
		       aux_803 = (int) (aux_825);
		    }
		    {
		       long i_828;
		       i_828 = (long) (aux_803);
		       i_797 = i_828;
		       goto loop_798;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_foreign_cenum()
{
   return BUNSPEC;
}


/* method-init */ obj_t 
method_init_76_foreign_cenum()
{
   {
      obj_t make_ctype_accesses__cenum_245_789;
      make_ctype_accesses__cenum_245_789 = proc1499_foreign_cenum;
      return add_method__1___object(make_ctype_accesses__env_11_foreign_access, cenum_foreign_ctype, make_ctype_accesses__cenum_245_789);
   }
}


/* make-ctype-accesses!-cenum */ obj_t 
make_ctype_accesses__cenum_245_foreign_cenum(obj_t env_790, obj_t what_791, obj_t who_792)
{
   {
      cenum_t what_474;
      type_t who_475;
      what_474 = (cenum_t) (what_791);
      who_475 = (type_t) (who_792);
      {
	 type_t btype_478;
	 {
	    obj_t aux_831;
	    {
	       object_t aux_832;
	       aux_832 = (object_t) (what_474);
	       aux_831 = OBJECT_WIDENING(aux_832);
	    }
	    btype_478 = (((cenum_t) CREF(aux_831))->btype);
	 }
	 {
	    obj_t id_479;
	    id_479 = (((type_t) CREF(who_475))->id);
	    {
	       obj_t wid_480;
	       {
		  type_t obj_775;
		  obj_775 = (type_t) (what_474);
		  wid_480 = (((type_t) CREF(obj_775))->id);
	       }
	       {
		  obj_t bid_481;
		  bid_481 = (((type_t) CREF(btype_478))->id);
		  {
		     obj_t id__bid_132_482;
		     {
			obj_t arg1488_729;
			arg1488_729 = CNST_TABLE_REF(((long) 0));
			{
			   obj_t list1489_730;
			   {
			      obj_t arg1490_731;
			      {
				 obj_t arg1491_732;
				 arg1491_732 = MAKE_PAIR(bid_481, BNIL);
				 arg1490_731 = MAKE_PAIR(arg1488_729, arg1491_732);
			      }
			      list1489_730 = MAKE_PAIR(id_479, arg1490_731);
			   }
			   id__bid_132_482 = symbol_append_197___r4_symbols_6_4(list1489_730);
			}
		     }
		     {
			obj_t bid__id_105_483;
			{
			   obj_t arg1483_724;
			   arg1483_724 = CNST_TABLE_REF(((long) 0));
			   {
			      obj_t list1484_725;
			      {
				 obj_t arg1485_726;
				 {
				    obj_t arg1486_727;
				    arg1486_727 = MAKE_PAIR(id_479, BNIL);
				    arg1485_726 = MAKE_PAIR(arg1483_724, arg1486_727);
				 }
				 list1484_725 = MAKE_PAIR(bid_481, arg1485_726);
			      }
			      bid__id_105_483 = symbol_append_197___r4_symbols_6_4(list1484_725);
			   }
			}
			{
			   obj_t bid__101_484;
			   {
			      obj_t list1479_721;
			      {
				 obj_t arg1480_722;
				 {
				    obj_t aux_850;
				    aux_850 = CNST_TABLE_REF(((long) 1));
				    arg1480_722 = MAKE_PAIR(aux_850, BNIL);
				 }
				 list1479_721 = MAKE_PAIR(id_479, arg1480_722);
			      }
			      bid__101_484 = symbol_append_197___r4_symbols_6_4(list1479_721);
			   }
			   {
			      obj_t bid__bool_159_485;
			      {
				 obj_t list1475_717;
				 {
				    obj_t arg1476_718;
				    {
				       obj_t aux_855;
				       aux_855 = CNST_TABLE_REF(((long) 2));
				       arg1476_718 = MAKE_PAIR(aux_855, BNIL);
				    }
				    list1475_717 = MAKE_PAIR(bid__101_484, arg1476_718);
				 }
				 bid__bool_159_485 = symbol_append_197___r4_symbols_6_4(list1475_717);
			      }
			      {
				 obj_t name_sans___18_487;
				 name_sans___18_487 = string_sans___40_type_tools((((type_t) CREF(who_475))->name));
				 {
				    obj_t literals_488;
				    {
				       obj_t aux_862;
				       {
					  object_t aux_863;
					  aux_863 = (object_t) (what_474);
					  aux_862 = OBJECT_WIDENING(aux_863);
				       }
				       literals_488 = (((cenum_t) CREF(aux_862))->literals);
				    }
				    {
				       {
					  {
					     obj_t arg1206_494;
					     {
						obj_t arg1207_495;
						obj_t arg1209_496;
						obj_t arg1210_497;
						arg1207_495 = CNST_TABLE_REF(((long) 20));
						{
						   obj_t arg1456_696;
						   obj_t arg1458_697;
						   arg1456_696 = CNST_TABLE_REF(((long) 18));
						   {
						      obj_t arg1468_706;
						      arg1468_706 = CNST_TABLE_REF(((long) 19));
						      {
							 obj_t list1470_708;
							 {
							    obj_t arg1471_709;
							    arg1471_709 = MAKE_PAIR(BNIL, BNIL);
							    list1470_708 = MAKE_PAIR(id_479, arg1471_709);
							 }
							 arg1458_697 = cons__138___r4_pairs_and_lists_6_3(arg1468_706, list1470_708);
						      }
						   }
						   {
						      obj_t list1462_700;
						      {
							 obj_t arg1463_701;
							 {
							    obj_t arg1464_702;
							    {
							       obj_t arg1465_703;
							       {
								  obj_t arg1466_704;
								  arg1466_704 = MAKE_PAIR(BNIL, BNIL);
								  arg1465_703 = MAKE_PAIR(string1503_foreign_cenum, arg1466_704);
							       }
							       arg1464_702 = MAKE_PAIR(arg1458_697, arg1465_703);
							    }
							    arg1463_701 = MAKE_PAIR(id__bid_132_482, arg1464_702);
							 }
							 list1462_700 = MAKE_PAIR(bid_481, arg1463_701);
						      }
						      arg1209_496 = cons__138___r4_pairs_and_lists_6_3(arg1456_696, list1462_700);
						   }
						}
						{
						   obj_t mname_676;
						   {
						      obj_t list1447_689;
						      {
							 obj_t arg1449_691;
							 {
							    obj_t arg1450_692;
							    arg1450_692 = MAKE_PAIR(string1501_foreign_cenum, BNIL);
							    arg1449_691 = MAKE_PAIR(name_sans___18_487, arg1450_692);
							 }
							 list1447_689 = MAKE_PAIR(string1502_foreign_cenum, arg1449_691);
						      }
						      mname_676 = string_append_106___r4_strings_6_7(list1447_689);
						   }
						   {
						      obj_t arg1431_677;
						      obj_t arg1432_678;
						      arg1431_677 = CNST_TABLE_REF(((long) 18));
						      {
							 obj_t list1444_687;
							 list1444_687 = MAKE_PAIR(BNIL, BNIL);
							 arg1432_678 = cons__138___r4_pairs_and_lists_6_3(bid_481, list1444_687);
						      }
						      {
							 obj_t list1434_680;
							 {
							    obj_t arg1436_681;
							    {
							       obj_t arg1437_682;
							       {
								  obj_t arg1438_683;
								  {
								     obj_t arg1440_684;
								     arg1440_684 = MAKE_PAIR(BNIL, BNIL);
								     arg1438_683 = MAKE_PAIR(mname_676, arg1440_684);
								  }
								  arg1437_682 = MAKE_PAIR(arg1432_678, arg1438_683);
							       }
							       arg1436_681 = MAKE_PAIR(bid__id_105_483, arg1437_682);
							    }
							    list1434_680 = MAKE_PAIR(id_479, arg1436_681);
							 }
							 arg1210_497 = cons__138___r4_pairs_and_lists_6_3(arg1431_677, list1434_680);
						      }
						   }
						}
						{
						   obj_t list1212_499;
						   {
						      obj_t arg1213_500;
						      {
							 obj_t arg1214_501;
							 arg1214_501 = MAKE_PAIR(BNIL, BNIL);
							 arg1213_500 = MAKE_PAIR(arg1210_497, arg1214_501);
						      }
						      list1212_499 = MAKE_PAIR(arg1209_496, arg1213_500);
						   }
						   arg1206_494 = cons__138___r4_pairs_and_lists_6_3(arg1207_495, list1212_499);
						}
					     }
					     produce_module_clause__172_module_module(arg1206_494);
					  }
					  {
					     obj_t arg1219_503;
					     {
						obj_t arg1220_504;
						obj_t arg1221_505;
						arg1220_504 = CNST_TABLE_REF(((long) 21));
						{
						   obj_t arg1226_510;
						   obj_t arg1228_511;
						   arg1226_510 = CNST_TABLE_REF(((long) 22));
						   arg1228_511 = CNST_TABLE_REF(((long) 23));
						   {
						      obj_t list1232_513;
						      {
							 obj_t arg1233_514;
							 {
							    obj_t arg1234_515;
							    arg1234_515 = MAKE_PAIR(BNIL, BNIL);
							    arg1233_514 = MAKE_PAIR(arg1228_511, arg1234_515);
							 }
							 list1232_513 = MAKE_PAIR(bid__bool_159_485, arg1233_514);
						      }
						      arg1221_505 = cons__138___r4_pairs_and_lists_6_3(arg1226_510, list1232_513);
						   }
						}
						{
						   obj_t list1223_507;
						   {
						      obj_t arg1224_508;
						      arg1224_508 = MAKE_PAIR(BNIL, BNIL);
						      list1223_507 = MAKE_PAIR(arg1221_505, arg1224_508);
						   }
						   arg1219_503 = cons__138___r4_pairs_and_lists_6_3(arg1220_504, list1223_507);
						}
					     }
					     produce_module_clause__172_module_module(arg1219_503);
					  }
					  {
					     obj_t arg1236_517;
					     {
						obj_t arg1238_518;
						obj_t arg1240_519;
						arg1238_518 = CNST_TABLE_REF(((long) 5));
						{
						   obj_t arg1245_524;
						   {
						      obj_t arg1252_529;
						      arg1252_529 = CNST_TABLE_REF(((long) 24));
						      {
							 obj_t list1254_531;
							 {
							    obj_t arg1255_532;
							    arg1255_532 = MAKE_PAIR(BNIL, BNIL);
							    list1254_531 = MAKE_PAIR(wid_480, arg1255_532);
							 }
							 arg1245_524 = cons__138___r4_pairs_and_lists_6_3(arg1252_529, list1254_531);
						      }
						   }
						   {
						      obj_t list1248_526;
						      {
							 obj_t arg1250_527;
							 arg1250_527 = MAKE_PAIR(BNIL, BNIL);
							 list1248_526 = MAKE_PAIR(arg1245_524, arg1250_527);
						      }
						      arg1240_519 = cons__138___r4_pairs_and_lists_6_3(bid__101_484, list1248_526);
						   }
						}
						{
						   obj_t list1242_521;
						   {
						      obj_t arg1243_522;
						      arg1243_522 = MAKE_PAIR(BNIL, BNIL);
						      list1242_521 = MAKE_PAIR(arg1240_519, arg1243_522);
						   }
						   arg1236_517 = cons__138___r4_pairs_and_lists_6_3(arg1238_518, list1242_521);
						}
					     }
					     produce_module_clause__172_module_module(arg1236_517);
					  }
					  {
					     obj_t arg1257_534;
					     obj_t arg1258_535;
					     obj_t arg1259_536;
					     {
						obj_t arg1309_585;
						obj_t arg1310_586;
						obj_t arg1311_587;
						arg1309_585 = CNST_TABLE_REF(((long) 4));
						{
						   obj_t arg1321_593;
						   obj_t arg1322_594;
						   obj_t arg1323_595;
						   {
						      obj_t arg1331_601;
						      arg1331_601 = CNST_TABLE_REF(((long) 6));
						      {
							 obj_t list1333_603;
							 {
							    obj_t arg1334_604;
							    {
							       obj_t arg1337_605;
							       {
								  obj_t aux_922;
								  aux_922 = CNST_TABLE_REF(((long) 7));
								  arg1337_605 = MAKE_PAIR(aux_922, BNIL);
							       }
							       arg1334_604 = MAKE_PAIR(id_479, arg1337_605);
							    }
							    list1333_603 = MAKE_PAIR(arg1331_601, arg1334_604);
							 }
							 arg1321_593 = symbol_append_197___r4_symbols_6_4(list1333_603);
						      }
						   }
						   {
						      obj_t arg1340_607;
						      arg1340_607 = CNST_TABLE_REF(((long) 8));
						      {
							 obj_t list1341_608;
							 {
							    obj_t arg1342_609;
							    {
							       obj_t arg1343_610;
							       arg1343_610 = MAKE_PAIR(id_479, BNIL);
							       arg1342_609 = MAKE_PAIR(_4dots_199_tools_misc, arg1343_610);
							    }
							    list1341_608 = MAKE_PAIR(arg1340_607, arg1342_609);
							 }
							 arg1322_594 = symbol_append_197___r4_symbols_6_4(list1341_608);
						      }
						   }
						   {
						      obj_t arg1345_612;
						      arg1345_612 = CNST_TABLE_REF(((long) 9));
						      {
							 obj_t list1346_613;
							 {
							    obj_t arg1347_614;
							    {
							       obj_t arg1349_615;
							       arg1349_615 = MAKE_PAIR(id_479, BNIL);
							       arg1347_614 = MAKE_PAIR(_4dots_199_tools_misc, arg1349_615);
							    }
							    list1346_613 = MAKE_PAIR(arg1345_612, arg1347_614);
							 }
							 arg1323_595 = symbol_append_197___r4_symbols_6_4(list1346_613);
						      }
						   }
						   {
						      obj_t list1325_597;
						      {
							 obj_t arg1326_598;
							 {
							    obj_t arg1328_599;
							    arg1328_599 = MAKE_PAIR(BNIL, BNIL);
							    arg1326_598 = MAKE_PAIR(arg1323_595, arg1328_599);
							 }
							 list1325_597 = MAKE_PAIR(arg1322_594, arg1326_598);
						      }
						      arg1310_586 = cons__138___r4_pairs_and_lists_6_3(arg1321_593, list1325_597);
						   }
						}
						{
						   obj_t arg1351_617;
						   obj_t arg1353_619;
						   obj_t arg1355_620;
						   arg1351_617 = CNST_TABLE_REF(((long) 10));
						   arg1353_619 = CNST_TABLE_REF(((long) 8));
						   arg1355_620 = CNST_TABLE_REF(((long) 9));
						   {
						      obj_t list1357_622;
						      {
							 obj_t arg1361_623;
							 {
							    obj_t arg1363_624;
							    {
							       obj_t arg1364_625;
							       arg1364_625 = MAKE_PAIR(BNIL, BNIL);
							       arg1363_624 = MAKE_PAIR(arg1355_620, arg1364_625);
							    }
							    arg1361_623 = MAKE_PAIR(arg1353_619, arg1363_624);
							 }
							 list1357_622 = MAKE_PAIR(string1500_foreign_cenum, arg1361_623);
						      }
						      arg1311_587 = cons__138___r4_pairs_and_lists_6_3(arg1351_617, list1357_622);
						   }
						}
						{
						   obj_t list1314_589;
						   {
						      obj_t arg1315_590;
						      {
							 obj_t arg1316_591;
							 arg1316_591 = MAKE_PAIR(BNIL, BNIL);
							 arg1315_590 = MAKE_PAIR(arg1311_587, arg1316_591);
						      }
						      list1314_589 = MAKE_PAIR(arg1310_586, arg1315_590);
						   }
						   arg1257_534 = cons__138___r4_pairs_and_lists_6_3(arg1309_585, list1314_589);
						}
					     }
					     {
						obj_t arg1367_628;
						obj_t arg1368_629;
						obj_t arg1369_630;
						arg1367_628 = CNST_TABLE_REF(((long) 4));
						{
						   obj_t arg1378_636;
						   arg1378_636 = CNST_TABLE_REF(((long) 11));
						   {
						      obj_t list1380_638;
						      {
							 obj_t arg1381_639;
							 arg1381_639 = MAKE_PAIR(BNIL, BNIL);
							 list1380_638 = MAKE_PAIR(arg1378_636, arg1381_639);
						      }
						      arg1368_629 = cons__138___r4_pairs_and_lists_6_3(bid__bool_159_485, list1380_638);
						   }
						}
						{
						   obj_t arg1384_641;
						   obj_t arg1385_642;
						   obj_t arg1387_643;
						   arg1384_641 = CNST_TABLE_REF(((long) 12));
						   {
						      obj_t arg1395_650;
						      obj_t arg1396_651;
						      arg1395_650 = CNST_TABLE_REF(((long) 13));
						      arg1396_651 = CNST_TABLE_REF(((long) 14));
						      {
							 obj_t list1398_653;
							 {
							    obj_t arg1399_654;
							    arg1399_654 = MAKE_PAIR(BNIL, BNIL);
							    list1398_653 = MAKE_PAIR(arg1396_651, arg1399_654);
							 }
							 arg1385_642 = cons__138___r4_pairs_and_lists_6_3(arg1395_650, list1398_653);
						      }
						   }
						   {
						      obj_t arg1402_656;
						      obj_t arg1403_657;
						      obj_t arg1405_658;
						      arg1402_656 = CNST_TABLE_REF(((long) 15));
						      {
							 obj_t arg1414_664;
							 obj_t arg1415_665;
							 arg1414_664 = CNST_TABLE_REF(((long) 16));
							 arg1415_665 = CNST_TABLE_REF(((long) 14));
							 {
							    obj_t list1417_667;
							    {
							       obj_t arg1418_668;
							       arg1418_668 = MAKE_PAIR(BNIL, BNIL);
							       list1417_667 = MAKE_PAIR(arg1415_665, arg1418_668);
							    }
							    arg1403_657 = cons__138___r4_pairs_and_lists_6_3(arg1414_664, list1417_667);
							 }
						      }
						      {
							 obj_t arg1421_670;
							 arg1421_670 = CNST_TABLE_REF(((long) 17));
							 {
							    obj_t list1424_672;
							    {
							       obj_t arg1426_673;
							       arg1426_673 = MAKE_PAIR(BNIL, BNIL);
							       list1424_672 = MAKE_PAIR(bid_481, arg1426_673);
							    }
							    arg1405_658 = cons__138___r4_pairs_and_lists_6_3(arg1421_670, list1424_672);
							 }
						      }
						      {
							 obj_t list1408_660;
							 {
							    obj_t arg1410_661;
							    {
							       obj_t arg1411_662;
							       arg1411_662 = MAKE_PAIR(BNIL, BNIL);
							       arg1410_661 = MAKE_PAIR(arg1405_658, arg1411_662);
							    }
							    list1408_660 = MAKE_PAIR(arg1403_657, arg1410_661);
							 }
							 arg1387_643 = cons__138___r4_pairs_and_lists_6_3(arg1402_656, list1408_660);
						      }
						   }
						   {
						      obj_t list1389_645;
						      {
							 obj_t arg1390_646;
							 {
							    obj_t arg1391_647;
							    {
							       obj_t arg1392_648;
							       arg1392_648 = MAKE_PAIR(BNIL, BNIL);
							       arg1391_647 = MAKE_PAIR(BFALSE, arg1392_648);
							    }
							    arg1390_646 = MAKE_PAIR(arg1387_643, arg1391_647);
							 }
							 list1389_645 = MAKE_PAIR(arg1385_642, arg1390_646);
						      }
						      arg1369_630 = cons__138___r4_pairs_and_lists_6_3(arg1384_641, list1389_645);
						   }
						}
						{
						   obj_t list1371_632;
						   {
						      obj_t arg1372_633;
						      {
							 obj_t arg1373_634;
							 arg1373_634 = MAKE_PAIR(BNIL, BNIL);
							 arg1372_633 = MAKE_PAIR(arg1369_630, arg1373_634);
						      }
						      list1371_632 = MAKE_PAIR(arg1368_629, arg1372_633);
						   }
						   arg1258_535 = cons__138___r4_pairs_and_lists_6_3(arg1367_628, list1371_632);
						}
					     }
					     {
						obj_t literals_541;
						obj_t res_542;
						literals_541 = literals_488;
						res_542 = BNIL;
					      loop_543:
						if (NULLP(literals_541))
						  {
						     arg1259_536 = res_542;
						  }
						else
						  {
						     obj_t literal_546;
						     literal_546 = CAR(literals_541);
						     {
							obj_t literal_name_176_548;
							{
							   obj_t aux_991;
							   aux_991 = CDR(literal_546);
							   literal_name_176_548 = CAR(aux_991);
							}
							{
							   obj_t access_id_43_549;
							   {
							      obj_t arg1301_579;
							      arg1301_579 = CNST_TABLE_REF(((long) 3));
							      {
								 obj_t list1302_580;
								 {
								    obj_t arg1303_581;
								    {
								       obj_t arg1304_582;
								       {
									  obj_t aux_995;
									  aux_995 = CAR(literal_546);
									  arg1304_582 = MAKE_PAIR(aux_995, BNIL);
								       }
								       arg1303_581 = MAKE_PAIR(arg1301_579, arg1304_582);
								    }
								    list1302_580 = MAKE_PAIR(id_479, arg1303_581);
								 }
								 access_id_43_549 = symbol_append_197___r4_symbols_6_4(list1302_580);
							      }
							   }
							   {
							      obj_t access_550;
							      {
								 obj_t arg1269_553;
								 obj_t arg1270_554;
								 obj_t arg1272_555;
								 arg1269_553 = CNST_TABLE_REF(((long) 4));
								 {
								    obj_t arg1282_561;
								    {
								       obj_t list1286_565;
								       {
									  obj_t arg1287_566;
									  {
									     obj_t arg1288_567;
									     arg1288_567 = MAKE_PAIR(wid_480, BNIL);
									     arg1287_566 = MAKE_PAIR(_4dots_199_tools_misc, arg1288_567);
									  }
									  list1286_565 = MAKE_PAIR(access_id_43_549, arg1287_566);
								       }
								       arg1282_561 = symbol_append_197___r4_symbols_6_4(list1286_565);
								    }
								    {
								       obj_t list1284_563;
								       list1284_563 = MAKE_PAIR(BNIL, BNIL);
								       arg1270_554 = cons__138___r4_pairs_and_lists_6_3(arg1282_561, list1284_563);
								    }
								 }
								 {
								    obj_t arg1291_569;
								    {
								       obj_t arg1296_574;
								       arg1296_574 = CNST_TABLE_REF(((long) 5));
								       {
									  obj_t list1297_575;
									  {
									     obj_t arg1298_576;
									     {
										obj_t arg1299_577;
										arg1299_577 = MAKE_PAIR(wid_480, BNIL);
										arg1298_576 = MAKE_PAIR(_4dots_199_tools_misc, arg1299_577);
									     }
									     list1297_575 = MAKE_PAIR(arg1296_574, arg1298_576);
									  }
									  arg1291_569 = symbol_append_197___r4_symbols_6_4(list1297_575);
								       }
								    }
								    {
								       obj_t list1293_571;
								       {
									  obj_t arg1294_572;
									  arg1294_572 = MAKE_PAIR(BNIL, BNIL);
									  list1293_571 = MAKE_PAIR(literal_name_176_548, arg1294_572);
								       }
								       arg1272_555 = cons__138___r4_pairs_and_lists_6_3(arg1291_569, list1293_571);
								    }
								 }
								 {
								    obj_t list1274_557;
								    {
								       obj_t arg1277_558;
								       {
									  obj_t arg1278_559;
									  arg1278_559 = MAKE_PAIR(BNIL, BNIL);
									  arg1277_558 = MAKE_PAIR(arg1272_555, arg1278_559);
								       }
								       list1274_557 = MAKE_PAIR(arg1270_554, arg1277_558);
								    }
								    access_550 = cons__138___r4_pairs_and_lists_6_3(arg1269_553, list1274_557);
								 }
							      }
							      {
								 {
								    obj_t arg1267_551;
								    obj_t arg1268_552;
								    arg1267_551 = CDR(literals_541);
								    arg1268_552 = MAKE_PAIR(access_550, res_542);
								    {
								       obj_t res_1023;
								       obj_t literals_1022;
								       literals_1022 = arg1267_551;
								       res_1023 = arg1268_552;
								       res_542 = res_1023;
								       literals_541 = literals_1022;
								       goto loop_543;
								    }
								 }
							      }
							   }
							}
						     }
						  }
					     }
					     {
						obj_t list1260_537;
						{
						   obj_t arg1262_538;
						   arg1262_538 = MAKE_PAIR(arg1259_536, BNIL);
						   list1260_537 = MAKE_PAIR(arg1258_535, arg1262_538);
						}
						return cons__138___r4_pairs_and_lists_6_3(arg1257_534, list1260_537);
					     }
					  }
				       }
				    }
				 }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_foreign_cenum()
{
   module_initialization_70_tools_misc(((long) 0), "FOREIGN_CENUM");
   module_initialization_70_type_tools(((long) 0), "FOREIGN_CENUM");
   module_initialization_70_type_type(((long) 0), "FOREIGN_CENUM");
   module_initialization_70_foreign_ctype(((long) 0), "FOREIGN_CENUM");
   module_initialization_70_foreign_access(((long) 0), "FOREIGN_CENUM");
   return module_initialization_70_module_module(((long) 0), "FOREIGN_CENUM");
}
