/*===========================================================================*/
/*   (Lalr/gen.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t _symv__174___lalr_rewrite;
static obj_t symbol1468___lalr_gen = BUNSPEC;
static obj_t symbol1467___lalr_gen = BUNSPEC;
static obj_t symbol1466___lalr_gen = BUNSPEC;
static obj_t symbol1465___lalr_gen = BUNSPEC;
static obj_t symbol1464___lalr_gen = BUNSPEC;
static obj_t symbol1463___lalr_gen = BUNSPEC;
static obj_t symbol1462___lalr_gen = BUNSPEC;
static obj_t symbol1461___lalr_gen = BUNSPEC;
static obj_t symbol1459___lalr_gen = BUNSPEC;
static obj_t symbol1460___lalr_gen = BUNSPEC;
static obj_t symbol1458___lalr_gen = BUNSPEC;
static obj_t symbol1457___lalr_gen = BUNSPEC;
static obj_t symbol1456___lalr_gen = BUNSPEC;
static obj_t symbol1455___lalr_gen = BUNSPEC;
static obj_t symbol1454___lalr_gen = BUNSPEC;
static obj_t symbol1453___lalr_gen = BUNSPEC;
extern obj_t string_to_symbol(char *);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t gen_lalr_code_179___lalr_gen();
static obj_t gen_goto_table_30___lalr_gen();
static obj_t _gen_lalr_code_37___lalr_gen(obj_t);
static obj_t loop_p_143___lalr_gen(obj_t, obj_t, obj_t, long);
static obj_t loop_l_5___lalr_gen(obj_t, long);
static obj_t loop_g_139___lalr_gen(long);
static obj_t loop_a_59___lalr_gen(long);
static obj_t loop_1452___lalr_gen(obj_t);
static obj_t loop_1451___lalr_gen(obj_t);
extern obj_t acces_symbol_228___lalr_global;
extern obj_t action_table_22___lalr_global;
static obj_t loop___lalr_gen(long, obj_t);
static obj_t reductions___lalr_gen();
extern obj_t nvars___lalr_global;
extern obj_t module_initialization_70___lalr_gen(long, char *);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___lalr_global(long, char *);
extern obj_t module_initialization_70___lalr_rewrite(long, char *);
extern obj_t module_initialization_70___type(long, char *);
extern obj_t module_initialization_70___bigloo(long, char *);
extern obj_t module_initialization_70___tvector(long, char *);
extern obj_t module_initialization_70___structure(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_flonum(long, char *);
extern obj_t module_initialization_70___r4_characters_6_6(long, char *);
extern obj_t module_initialization_70___r4_equivalence_6_2(long, char *);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_input_6_10_2(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_vectors_6_8(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t module_initialization_70___r4_output_6_10_3(long, char *);
extern obj_t nstates___lalr_global;
static obj_t actions___lalr_gen();
extern long list_length(obj_t);
static obj_t gotos___lalr_gen();
extern obj_t grammar___lalr_global;
static obj_t gen_action_table_103___lalr_gen();
extern obj_t list__vector_101___r4_vectors_6_8(obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
static obj_t gen_reduction_table_195___lalr_gen();
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t shift_table_147___lalr_global;
static obj_t imported_modules_init_94___lalr_gen();
static obj_t require_initialization_114___lalr_gen = BUNSPEC;
static obj_t cnst_init_137___lalr_gen();
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( gen_lalr_code_env_112___lalr_gen, _gen_lalr_code_37___lalr_gen1470, _gen_lalr_code_37___lalr_gen, 0L, 0 );


/* module-initialization */obj_t module_initialization_70___lalr_gen(long checksum_821, char * from_822)
{
if(CBOOL(require_initialization_114___lalr_gen)){
require_initialization_114___lalr_gen = BBOOL(((bool_t)0));
cnst_init_137___lalr_gen();
imported_modules_init_94___lalr_gen();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___lalr_gen()
{
symbol1453___lalr_gen = string_to_symbol("LET*");
symbol1454___lalr_gen = string_to_symbol("__MAKE-PARSER");
symbol1455___lalr_gen = string_to_symbol("__ACTION-TABLE");
symbol1456___lalr_gen = string_to_symbol("__REDUCE");
symbol1457___lalr_gen = string_to_symbol("QUOTE");
symbol1458___lalr_gen = string_to_symbol("__GOTO-TABLE");
symbol1459___lalr_gen = string_to_symbol("LAMBDA");
symbol1460___lalr_gen = string_to_symbol("N");
symbol1461___lalr_gen = string_to_symbol("__STACK");
symbol1462___lalr_gen = string_to_symbol("__SP");
symbol1463___lalr_gen = string_to_symbol("CASE");
symbol1464___lalr_gen = string_to_symbol("*START*");
symbol1465___lalr_gen = string_to_symbol("__PUSH");
symbol1466___lalr_gen = string_to_symbol("-FX");
symbol1467___lalr_gen = string_to_symbol("LET");
return (symbol1468___lalr_gen = string_to_symbol("VECTOR-REF-UR"),
BUNSPEC);
}


/* gen-lalr-code */obj_t gen_lalr_code_179___lalr_gen()
{
{
obj_t arg1034_316;
obj_t arg1035_317;
obj_t arg1037_318;
arg1034_316 = symbol1453___lalr_gen;
{
obj_t arg1043_324;
obj_t arg1044_325;
obj_t arg1045_326;
arg1043_324 = gen_action_table_103___lalr_gen();
arg1044_325 = gen_goto_table_30___lalr_gen();
arg1045_326 = gen_reduction_table_195___lalr_gen();
{
obj_t list1047_328;
{
obj_t arg1048_329;
{
obj_t arg1049_330;
arg1049_330 = MAKE_PAIR(BNIL, BNIL);
arg1048_329 = MAKE_PAIR(arg1045_326, arg1049_330);
}
list1047_328 = MAKE_PAIR(arg1044_325, arg1048_329);
}
arg1035_317 = cons__138___r4_pairs_and_lists_6_3(arg1043_324, list1047_328);
}
}
{
obj_t arg1051_332;
obj_t arg1053_333;
obj_t arg1054_334;
arg1051_332 = symbol1454___lalr_gen;
arg1053_333 = symbol1455___lalr_gen;
arg1054_334 = symbol1456___lalr_gen;
{
obj_t list1056_336;
{
obj_t arg1057_337;
{
obj_t arg1058_338;
arg1058_338 = MAKE_PAIR(BNIL, BNIL);
arg1057_337 = MAKE_PAIR(arg1054_334, arg1058_338);
}
list1056_336 = MAKE_PAIR(arg1053_333, arg1057_337);
}
arg1037_318 = cons__138___r4_pairs_and_lists_6_3(arg1051_332, list1056_336);
}
}
{
obj_t list1039_320;
{
obj_t arg1040_321;
{
obj_t arg1041_322;
arg1041_322 = MAKE_PAIR(BNIL, BNIL);
arg1040_321 = MAKE_PAIR(arg1037_318, arg1041_322);
}
list1039_320 = MAKE_PAIR(arg1035_317, arg1040_321);
}
return cons__138___r4_pairs_and_lists_6_3(arg1034_316, list1039_320);
}
}
}


/* _gen-lalr-code */obj_t _gen_lalr_code_37___lalr_gen(obj_t env_815)
{
return gen_lalr_code_179___lalr_gen();
}


/* gen-action-table */obj_t gen_action_table_103___lalr_gen()
{
{
obj_t arg1060_341;
obj_t arg1061_342;
arg1060_341 = symbol1455___lalr_gen;
{
obj_t arg1067_347;
obj_t arg1068_348;
arg1067_347 = symbol1457___lalr_gen;
{
obj_t arg1076_353;
{
obj_t arg1077_354;
{
obj_t arg1079_356;
obj_t arg1080_357;
arg1079_356 = actions___lalr_gen();
arg1080_357 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1077_354 = append_2_18___r4_pairs_and_lists_6_3(arg1079_356, arg1080_357);
}
arg1076_353 = cons__138___r4_pairs_and_lists_6_3(arg1077_354, BNIL);
}
arg1068_348 = list__vector_101___r4_vectors_6_8(arg1076_353);
}
{
obj_t list1070_350;
{
obj_t arg1072_351;
arg1072_351 = MAKE_PAIR(BNIL, BNIL);
list1070_350 = MAKE_PAIR(arg1068_348, arg1072_351);
}
arg1061_342 = cons__138___r4_pairs_and_lists_6_3(arg1067_347, list1070_350);
}
}
{
obj_t list1063_344;
{
obj_t arg1065_345;
arg1065_345 = MAKE_PAIR(BNIL, BNIL);
list1063_344 = MAKE_PAIR(arg1061_342, arg1065_345);
}
return cons__138___r4_pairs_and_lists_6_3(arg1060_341, list1063_344);
}
}
}


/* loop_1452 */obj_t loop_1452___lalr_gen(obj_t l_366)
{
if(NULLP(l_366)){
return BNIL;
}
 else {
obj_t p_370;
p_370 = CAR(l_366);
{
obj_t x_371;
x_371 = CAR(p_370);
{
obj_t y_372;
y_372 = CDR(p_370);
{
{
obj_t arg1089_373;
obj_t arg1090_374;
{
obj_t arg1091_375;
if(INTEGERP(x_371)){
long arg1093_377;
{
long z1_732;
long z2_733;
z1_732 = (long)CINT(nvars___lalr_global);
z2_733 = (long)CINT(x_371);
arg1093_377 = (z1_732+z2_733);
}
{
obj_t vector_734;
vector_734 = _symv__174___lalr_rewrite;
arg1091_375 = VECTOR_REF(vector_734, arg1093_377);
}
}
 else {
arg1091_375 = x_371;
}
arg1089_373 = MAKE_PAIR(arg1091_375, y_372);
}
arg1090_374 = loop_1452___lalr_gen(CDR(l_366));
return MAKE_PAIR(arg1089_373, arg1090_374);
}
}
}
}
}
}


/* loop-a */obj_t loop_a_59___lalr_gen(long i_361)
{
{
bool_t test1084_363;
test1084_363 = _2__95___r4_numbers_6_5(BINT(i_361), nstates___lalr_global);
if(test1084_363){
return BNIL;
}
 else {
obj_t arg1085_364;
obj_t arg1086_365;
{
obj_t arg1087_368;
{
obj_t vector_725;
vector_725 = action_table_22___lalr_global;
arg1087_368 = VECTOR_REF(vector_725, i_361);
}
arg1085_364 = loop_1452___lalr_gen(arg1087_368);
}
arg1086_365 = loop_a_59___lalr_gen((i_361+((long)1)));
return MAKE_PAIR(arg1085_364, arg1086_365);
}
}
}


/* actions */obj_t actions___lalr_gen()
{
return loop_a_59___lalr_gen(((long)0));
}


/* gen-goto-table */obj_t gen_goto_table_30___lalr_gen()
{
{
obj_t arg1096_382;
obj_t arg1097_383;
arg1096_382 = symbol1458___lalr_gen;
{
obj_t arg1102_388;
obj_t arg1103_389;
arg1102_388 = symbol1457___lalr_gen;
{
obj_t arg1108_394;
{
obj_t arg1109_395;
{
obj_t arg1111_397;
obj_t arg1112_398;
arg1111_397 = gotos___lalr_gen();
arg1112_398 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1109_395 = append_2_18___r4_pairs_and_lists_6_3(arg1111_397, arg1112_398);
}
arg1108_394 = cons__138___r4_pairs_and_lists_6_3(arg1109_395, BNIL);
}
arg1103_389 = list__vector_101___r4_vectors_6_8(arg1108_394);
}
{
obj_t list1105_391;
{
obj_t arg1106_392;
arg1106_392 = MAKE_PAIR(BNIL, BNIL);
list1105_391 = MAKE_PAIR(arg1103_389, arg1106_392);
}
arg1097_383 = cons__138___r4_pairs_and_lists_6_3(arg1102_388, list1105_391);
}
}
{
obj_t list1099_385;
{
obj_t arg1100_386;
arg1100_386 = MAKE_PAIR(BNIL, BNIL);
list1099_385 = MAKE_PAIR(arg1097_383, arg1100_386);
}
return cons__138___r4_pairs_and_lists_6_3(arg1096_382, list1099_385);
}
}
}


/* loop_1451 */obj_t loop_1451___lalr_gen(obj_t l_408)
{
loop_1451___lalr_gen:
if(NULLP(l_408)){
return BNIL;
}
 else {
obj_t state_412;
state_412 = CAR(l_408);
{
obj_t symbol_413;
{
obj_t vector_751;
vector_751 = acces_symbol_228___lalr_global;
{
long aux_909;
aux_909 = (long)CINT(state_412);
symbol_413 = VECTOR_REF(vector_751, aux_909);
}
}
{
{
bool_t test1121_414;
{
long n1_753;
long n2_754;
n1_753 = (long)CINT(symbol_413);
n2_754 = (long)CINT(nvars___lalr_global);
test1121_414 = (n1_753<n2_754);
}
if(test1121_414){
obj_t arg1122_415;
obj_t arg1123_416;
{
obj_t arg1124_417;
{
obj_t vector_755;
vector_755 = _symv__174___lalr_rewrite;
{
long aux_916;
aux_916 = (long)CINT(symbol_413);
arg1124_417 = VECTOR_REF(vector_755, aux_916);
}
}
{
obj_t list1125_418;
list1125_418 = MAKE_PAIR(state_412, BNIL);
arg1122_415 = cons__138___r4_pairs_and_lists_6_3(arg1124_417, list1125_418);
}
}
arg1123_416 = loop_1451___lalr_gen(CDR(l_408));
return MAKE_PAIR(arg1122_415, arg1123_416);
}
 else {
obj_t l_924;
l_924 = CDR(l_408);
l_408 = l_924;
goto loop_1451___lalr_gen;
}
}
}
}
}
}


/* loop-g */obj_t loop_g_139___lalr_gen(long i_402)
{
{
bool_t test1116_404;
test1116_404 = _2__95___r4_numbers_6_5(BINT(i_402), nstates___lalr_global);
if(test1116_404){
return BNIL;
}
 else {
obj_t arg1117_405;
obj_t arg1118_406;
{
obj_t shifts_407;
{
obj_t vector_745;
vector_745 = shift_table_147___lalr_global;
shifts_407 = VECTOR_REF(vector_745, i_402);
}
if(CBOOL(shifts_407)){
arg1117_405 = loop_1451___lalr_gen(VECTOR_REF(shifts_407, ((long)2)));
}
 else {
arg1117_405 = BNIL;
}
}
arg1118_406 = loop_g_139___lalr_gen((i_402+((long)1)));
return MAKE_PAIR(arg1117_405, arg1118_406);
}
}
}


/* gotos */obj_t gotos___lalr_gen()
{
return loop_g_139___lalr_gen(((long)0));
}


/* gen-reduction-table */obj_t gen_reduction_table_195___lalr_gen()
{
{
obj_t arg1130_427;
obj_t arg1131_428;
arg1130_427 = symbol1456___lalr_gen;
{
obj_t arg1136_433;
obj_t arg1137_434;
obj_t arg1139_435;
arg1136_433 = symbol1459___lalr_gen;
{
obj_t arg1145_441;
obj_t arg1146_442;
obj_t arg1147_443;
arg1145_441 = symbol1460___lalr_gen;
arg1146_442 = symbol1461___lalr_gen;
arg1147_443 = symbol1462___lalr_gen;
{
obj_t list1149_445;
{
obj_t arg1150_446;
{
obj_t arg1151_447;
arg1151_447 = MAKE_PAIR(BNIL, BNIL);
arg1150_446 = MAKE_PAIR(arg1147_443, arg1151_447);
}
list1149_445 = MAKE_PAIR(arg1146_442, arg1150_446);
}
arg1137_434 = cons__138___r4_pairs_and_lists_6_3(arg1145_441, list1149_445);
}
}
{
obj_t arg1153_449;
obj_t arg1154_450;
obj_t arg1155_451;
arg1153_449 = symbol1463___lalr_gen;
arg1154_450 = symbol1460___lalr_gen;
{
obj_t arg1160_455;
obj_t arg1161_456;
arg1160_455 = reductions___lalr_gen();
arg1161_456 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1155_451 = append_2_18___r4_pairs_and_lists_6_3(arg1160_455, arg1161_456);
}
{
obj_t list1156_452;
{
obj_t arg1157_453;
arg1157_453 = MAKE_PAIR(arg1155_451, BNIL);
list1156_452 = MAKE_PAIR(arg1154_450, arg1157_453);
}
arg1139_435 = cons__138___r4_pairs_and_lists_6_3(arg1153_449, list1156_452);
}
}
{
obj_t list1141_437;
{
obj_t arg1142_438;
{
obj_t arg1143_439;
arg1143_439 = MAKE_PAIR(BNIL, BNIL);
arg1142_438 = MAKE_PAIR(arg1139_435, arg1143_439);
}
list1141_437 = MAKE_PAIR(arg1137_434, arg1142_438);
}
arg1131_428 = cons__138___r4_pairs_and_lists_6_3(arg1136_433, list1141_437);
}
}
{
obj_t list1133_430;
{
obj_t arg1134_431;
arg1134_431 = MAKE_PAIR(BNIL, BNIL);
list1133_430 = MAKE_PAIR(arg1131_428, arg1134_431);
}
return cons__138___r4_pairs_and_lists_6_3(arg1130_427, list1133_430);
}
}
}


/* loop-l */obj_t loop_l_5___lalr_gen(obj_t l_460, long no_461)
{
if(NULLP(l_460)){
return BNIL;
}
 else {
obj_t def_464;
def_464 = CAR(l_460);
{
return loop_p_143___lalr_gen(l_460, CAR(def_464), CDR(def_464), no_461);
}
}
}


/* loop-p */obj_t loop_p_143___lalr_gen(obj_t l_817, obj_t nt_816, obj_t prods_466, long no_467)
{
{
obj_t nt_500;
long n_501;
obj_t act_502;
if(NULLP(prods_466)){
return loop_l_5___lalr_gen(CDR(l_817), no_467);
}
 else {
obj_t rhs_472;
{
obj_t aux_965;
aux_965 = CAR(prods_466);
rhs_472 = CAR(aux_965);
}
{
obj_t act_473;
{
obj_t aux_968;
aux_968 = CAR(prods_466);
act_473 = CDR(aux_968);
}
{
long n_474;
n_474 = list_length(rhs_472);
{
{
obj_t arg1169_475;
obj_t arg1170_476;
{
obj_t arg1171_477;
obj_t arg1172_478;
{
obj_t list1176_482;
{
obj_t aux_972;
aux_972 = BINT(no_467);
list1176_482 = MAKE_PAIR(aux_972, BNIL);
}
arg1171_477 = list1176_482;
}
{
obj_t arg1178_484;
obj_t arg1179_485;
obj_t arg1180_486;
arg1178_484 = symbol1467___lalr_gen;
{
obj_t arg1186_492;
{
obj_t arg1188_494;
obj_t arg1189_495;
{
obj_t rhs_818;
long n_820;
rhs_818 = rhs_472;
n_820 = n_474;
arg1188_494 = loop___lalr_gen(n_820, rhs_818);
}
arg1189_495 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1186_492 = append_2_18___r4_pairs_and_lists_6_3(arg1188_494, arg1189_495);
}
arg1179_485 = cons__138___r4_pairs_and_lists_6_3(arg1186_492, BNIL);
}
nt_500 = nt_816;
n_501 = n_474;
act_502 = act_473;
if((nt_500==symbol1464___lalr_gen)){
obj_t vector_788;
vector_788 = _symv__174___lalr_rewrite;
arg1180_486 = VECTOR_REF(vector_788, ((long)1));
}
 else {
obj_t arg1196_505;
obj_t arg1197_506;
obj_t arg1199_507;
obj_t arg1200_508;
obj_t arg1201_509;
obj_t arg1202_510;
arg1196_505 = symbol1465___lalr_gen;
arg1197_506 = symbol1461___lalr_gen;
{
obj_t arg1213_519;
obj_t arg1214_520;
long arg1216_521;
arg1213_519 = symbol1466___lalr_gen;
arg1214_520 = symbol1462___lalr_gen;
arg1216_521 = (((long)2)*n_501);
{
obj_t list1220_523;
{
obj_t arg1221_524;
{
obj_t arg1222_525;
arg1222_525 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_984;
aux_984 = BINT(arg1216_521);
arg1221_524 = MAKE_PAIR(aux_984, arg1222_525);
}
}
list1220_523 = MAKE_PAIR(arg1214_520, arg1221_524);
}
arg1199_507 = cons__138___r4_pairs_and_lists_6_3(arg1213_519, list1220_523);
}
}
{
obj_t arg1225_527;
arg1225_527 = symbol1457___lalr_gen;
{
obj_t list1227_529;
{
obj_t arg1228_530;
arg1228_530 = MAKE_PAIR(BNIL, BNIL);
list1227_529 = MAKE_PAIR(nt_500, arg1228_530);
}
arg1200_508 = cons__138___r4_pairs_and_lists_6_3(arg1225_527, list1227_529);
}
}
arg1201_509 = symbol1458___lalr_gen;
{
obj_t arg1232_532;
obj_t arg1234_534;
arg1232_532 = symbol1467___lalr_gen;
{
obj_t arg1240_538;
arg1240_538 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
arg1234_534 = append_2_18___r4_pairs_and_lists_6_3(act_502, arg1240_538);
}
{
obj_t list1235_535;
{
obj_t arg1236_536;
arg1236_536 = MAKE_PAIR(arg1234_534, BNIL);
list1235_535 = MAKE_PAIR(BNIL, arg1236_536);
}
arg1202_510 = cons__138___r4_pairs_and_lists_6_3(arg1232_532, list1235_535);
}
}
{
obj_t list1204_512;
{
obj_t arg1205_513;
{
obj_t arg1206_514;
{
obj_t arg1207_515;
{
obj_t arg1209_516;
{
obj_t arg1210_517;
arg1210_517 = MAKE_PAIR(BNIL, BNIL);
arg1209_516 = MAKE_PAIR(arg1202_510, arg1210_517);
}
arg1207_515 = MAKE_PAIR(arg1201_509, arg1209_516);
}
arg1206_514 = MAKE_PAIR(arg1200_508, arg1207_515);
}
arg1205_513 = MAKE_PAIR(arg1199_507, arg1206_514);
}
list1204_512 = MAKE_PAIR(arg1197_506, arg1205_513);
}
arg1180_486 = cons__138___r4_pairs_and_lists_6_3(arg1196_505, list1204_512);
}
}
{
obj_t list1182_488;
{
obj_t arg1183_489;
{
obj_t arg1184_490;
arg1184_490 = MAKE_PAIR(BNIL, BNIL);
arg1183_489 = MAKE_PAIR(arg1180_486, arg1184_490);
}
list1182_488 = MAKE_PAIR(arg1179_485, arg1183_489);
}
arg1172_478 = cons__138___r4_pairs_and_lists_6_3(arg1178_484, list1182_488);
}
}
{
obj_t list1173_479;
{
obj_t arg1174_480;
arg1174_480 = MAKE_PAIR(arg1172_478, BNIL);
list1173_479 = MAKE_PAIR(arg1171_477, arg1174_480);
}
arg1169_475 = list1173_479;
}
}
arg1170_476 = loop_p_143___lalr_gen(l_817, nt_816, CDR(prods_466), (no_467+((long)1)));
return MAKE_PAIR(arg1169_475, arg1170_476);
}
}
}
}
}
}
}


/* loop */obj_t loop___lalr_gen(long i_546, obj_t l_547)
{
if(NULLP(l_547)){
return BNIL;
}
 else {
obj_t sym_550;
sym_550 = CAR(l_547);
{
obj_t arg1247_551;
obj_t arg1248_552;
{
obj_t arg1250_553;
obj_t arg1251_554;
if(PAIRP(sym_550)){
arg1250_553 = CDR(sym_550);
}
 else {
arg1250_553 = sym_550;
}
{
obj_t arg1257_560;
obj_t arg1258_561;
obj_t arg1259_562;
arg1257_560 = symbol1468___lalr_gen;
arg1258_561 = symbol1461___lalr_gen;
{
obj_t arg1267_568;
obj_t arg1268_569;
long arg1269_570;
arg1267_568 = symbol1466___lalr_gen;
arg1268_569 = symbol1462___lalr_gen;
{
long aux_1020;
aux_1020 = (i_546*((long)2));
arg1269_570 = (aux_1020-((long)1));
}
{
obj_t list1271_572;
{
obj_t arg1272_573;
{
obj_t arg1273_574;
arg1273_574 = MAKE_PAIR(BNIL, BNIL);
{
obj_t aux_1024;
aux_1024 = BINT(arg1269_570);
arg1272_573 = MAKE_PAIR(aux_1024, arg1273_574);
}
}
list1271_572 = MAKE_PAIR(arg1268_569, arg1272_573);
}
arg1259_562 = cons__138___r4_pairs_and_lists_6_3(arg1267_568, list1271_572);
}
}
{
obj_t list1261_564;
{
obj_t arg1262_565;
{
obj_t arg1263_566;
arg1263_566 = MAKE_PAIR(BNIL, BNIL);
arg1262_565 = MAKE_PAIR(arg1259_562, arg1263_566);
}
list1261_564 = MAKE_PAIR(arg1258_561, arg1262_565);
}
arg1251_554 = cons__138___r4_pairs_and_lists_6_3(arg1257_560, list1261_564);
}
}
{
obj_t list1253_556;
{
obj_t arg1254_557;
arg1254_557 = MAKE_PAIR(BNIL, BNIL);
list1253_556 = MAKE_PAIR(arg1251_554, arg1254_557);
}
arg1247_551 = cons__138___r4_pairs_and_lists_6_3(arg1250_553, list1253_556);
}
}
arg1248_552 = loop___lalr_gen((i_546-((long)1)), CDR(l_547));
return MAKE_PAIR(arg1247_551, arg1248_552);
}
}
}


/* reductions */obj_t reductions___lalr_gen()
{
return loop_l_5___lalr_gen(grammar___lalr_global, ((long)1));
}


/* imported-modules-init */obj_t imported_modules_init_94___lalr_gen()
{
module_initialization_70___error(((long)0), "__LALR_GEN");
module_initialization_70___lalr_global(((long)0), "__LALR_GEN");
module_initialization_70___lalr_rewrite(((long)0), "__LALR_GEN");
module_initialization_70___type(((long)0), "__LALR_GEN");
module_initialization_70___bigloo(((long)0), "__LALR_GEN");
module_initialization_70___tvector(((long)0), "__LALR_GEN");
module_initialization_70___structure(((long)0), "__LALR_GEN");
module_initialization_70___r4_numbers_6_5(((long)0), "__LALR_GEN");
module_initialization_70___r4_numbers_6_5_fixnum(((long)0), "__LALR_GEN");
module_initialization_70___r4_numbers_6_5_flonum(((long)0), "__LALR_GEN");
module_initialization_70___r4_characters_6_6(((long)0), "__LALR_GEN");
module_initialization_70___r4_equivalence_6_2(((long)0), "__LALR_GEN");
module_initialization_70___r4_booleans_6_1(((long)0), "__LALR_GEN");
module_initialization_70___r4_symbols_6_4(((long)0), "__LALR_GEN");
module_initialization_70___r4_strings_6_7(((long)0), "__LALR_GEN");
module_initialization_70___r4_pairs_and_lists_6_3(((long)0), "__LALR_GEN");
module_initialization_70___r4_input_6_10_2(((long)0), "__LALR_GEN");
module_initialization_70___r4_control_features_6_9(((long)0), "__LALR_GEN");
module_initialization_70___r4_vectors_6_8(((long)0), "__LALR_GEN");
module_initialization_70___r4_ports_6_10_1(((long)0), "__LALR_GEN");
module_initialization_70___r4_output_6_10_3(((long)0), "__LALR_GEN");
return module_initialization_70___evenv(((long)0), "__LALR_GEN");
}

