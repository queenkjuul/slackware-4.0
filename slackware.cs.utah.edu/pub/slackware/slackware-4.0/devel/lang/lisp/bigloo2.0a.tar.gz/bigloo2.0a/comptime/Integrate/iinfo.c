/*===========================================================================*/
/*   (Integrate/iinfo.scm)                                                   */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct svar_iinfo_76
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
             *svar_iinfo_76_t;

typedef struct sexit_iinfo_190
  {
     obj_t f_mark_181;
     obj_t u_mark_209;
     bool_t kaptured__204;
     bool_t celled__113;
  }
               *sexit_iinfo_190_t;

typedef struct sfun_iinfo_105
  {
     obj_t owner;
     obj_t free;
     obj_t bound;
     obj_t cfrom;
     obj_t cto;
     obj_t k;
     obj_t k__190;
     obj_t u;
     obj_t cn;
     obj_t ct;
     obj_t kont;
     bool_t g__219;
     obj_t l;
     obj_t led;
     obj_t istamp;
     obj_t global;
     obj_t kaptured;
  }
              *sfun_iinfo_105_t;


static obj_t _sfun_iinfo_l1850_161_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_g__set_1847_16_integrate_info(obj_t, obj_t, obj_t);
static obj_t method_init_76_integrate_info();
extern obj_t sfun_iinfo_body_set__218_integrate_info(sfun_t, obj_t);
static obj_t _sfun_iinfo_global1856_163_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_stack_allocator_set_1807_116_integrate_info(obj_t, obj_t, obj_t);
static obj_t object__struct_sexit_iinfo_21_integrate_info(obj_t, obj_t);
extern obj_t sexit_iinfo_f_mark_103_integrate_info(sexit_iinfo_190_t);
extern obj_t sfun_iinfo_side_effect__set__248_integrate_info(sfun_t, obj_t);
static obj_t _sfun_iinfo_kaptured1858_246_integrate_info(obj_t, obj_t);
extern bool_t sfun_iinfo__133_integrate_info(obj_t);
static obj_t _sfun_iinfo_body1818_212_integrate_info(obj_t, obj_t);
static obj_t _allocate_svar_iinfo_246_integrate_info(obj_t);
extern obj_t sfun_iinfo_owner_223_integrate_info(sfun_iinfo_105_t);
extern obj_t svar_iinfo_loc_set__64_integrate_info(svar_t, obj_t);
extern obj_t sfun_iinfo_g__set__207_integrate_info(sfun_iinfo_105_t, bool_t);
static obj_t _sfun_iinfo_cto_set_1833_248_integrate_info(obj_t, obj_t, obj_t);
static obj_t struct_object__object_sexit_iinfo_149_integrate_info(obj_t, obj_t, obj_t);
static obj_t _object__struct1885_66___object(obj_t, obj_t);
static obj_t _sfun_iinfo_owner1826_86_integrate_info(obj_t, obj_t);
extern sfun_iinfo_105_t widening1004_sfun_iinfo_11_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_kaptured_set_1857_94_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_loc_set_1823_203_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo_f_mark_set_1863_117_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo_handler1860_157_integrate_info(obj_t, obj_t);
static obj_t _svar_iinfo_celled__set_1879_24_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo__65_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_bound_208_integrate_info(sfun_iinfo_105_t);
extern bool_t sfun_iinfo_top__215_integrate_info(sfun_t);
static obj_t _sexit_iinfo_kaptured__set_1867_250_integrate_info(obj_t, obj_t, obj_t);
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t sexit_iinfo_f_mark_set__25_integrate_info(sexit_iinfo_190_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t svar_iinfo_celled__set__209_integrate_info(svar_iinfo_76_t, bool_t);
extern obj_t svar_iinfo_f_mark_86_integrate_info(svar_iinfo_76_t);
static obj_t _sfun_iinfo_bound1830_36_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_dsssl_keywords_229_integrate_info(sfun_t);
extern obj_t sfun_iinfo_the_closure_5_integrate_info(sfun_t);
static obj_t _svar_iinfo_u_mark1876_186_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_ct_set_1843_111_integrate_info(obj_t, obj_t, obj_t);
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern svar_iinfo_76_t widening1002_svar_iinfo_19_integrate_info(obj_t, obj_t, bool_t, bool_t);
extern obj_t sfun_iinfo_cfrom_145_integrate_info(sfun_iinfo_105_t);
extern sfun_t allocate_sfun_iinfo_8_integrate_info();
extern sexit_t allocate_sexit_iinfo_139_integrate_info();
obj_t sfun_iinfo_105_integrate_info = BUNSPEC;
extern obj_t sfun_iinfo_bound_set__116_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _sexit_iinfo_detached_1862_181_integrate_info(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _svar_iinfo_kaptured_1878_59_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_l_set__126_integrate_info(sfun_iinfo_105_t, obj_t);
extern obj_t sexit_iinfo_kaptured__set__138_integrate_info(sexit_iinfo_190_t, bool_t);
static obj_t _sfun_iinfo_led_set_1851_183_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_predicate_of_199_integrate_info(sfun_t);
static obj_t _sfun_iinfo_body_set_1817_123_integrate_info(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_integrate_info(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t _sfun_iinfo_istamp_set_1853_214_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo_u_mark1866_228_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_arity1802_164_integrate_info(obj_t, obj_t);
obj_t sexit_iinfo_190_integrate_info = BUNSPEC;
extern svar_t allocate_svar_iinfo_15_integrate_info();
obj_t svar_iinfo_76_integrate_info = BUNSPEC;
extern obj_t sfun_iinfo_ct_set__108_integrate_info(sfun_iinfo_105_t, obj_t);
extern obj_t sexit_iinfo_u_mark_set__37_integrate_info(sexit_iinfo_190_t, obj_t);
extern obj_t sfun_iinfo_dsssl_keywords_set__223_integrate_info(sfun_t, obj_t);
extern long class_num_218___object(obj_t);
extern obj_t sfun_iinfo_kaptured_239_integrate_info(sfun_iinfo_105_t);
static obj_t _sfun_iinfo_loc1824_181_integrate_info(obj_t, obj_t);
extern obj_t svar_ast_var;
extern obj_t svar_iinfo_f_mark_set__34_integrate_info(svar_iinfo_76_t, obj_t);
extern obj_t sfun_iinfo_side_effect__11_integrate_info(sfun_t);
extern obj_t sfun_iinfo_body_74_integrate_info(sfun_t);
extern bool_t sexit_iinfo_detached__106_integrate_info(sexit_t);
extern obj_t sfun_iinfo_cto_set__217_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _svar_iinfo_f_mark1874_4_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_loc_114_integrate_info(sfun_t);
static obj_t _sfun_iinfo_global_set_1855_184_integrate_info(obj_t, obj_t, obj_t);
extern sfun_iinfo_105_t make_sfun_iinfo_248_integrate_info(long, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, bool_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo_kaptured_1868_228_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_free_set_1827_109_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_led_56_integrate_info(sfun_iinfo_105_t);
static obj_t imported_modules_init_94_integrate_info();
static obj_t _struct_object__object1883_71___object(obj_t, obj_t, obj_t);
static obj_t _svar_iinfo_u_mark_set_1875_106_integrate_info(obj_t, obj_t, obj_t);
extern long sfun_iinfo_arity_150_integrate_info(sfun_t);
static obj_t _sfun_iinfo_kont_set_1845_82_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_istamp1854_225_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_side_effect__set_1803_33_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sexit_iinfo_celled__set__58_integrate_info(sexit_iinfo_190_t, bool_t);
static obj_t _sfun_iinfo_kont1846_202_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_cn1842_18_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_owner_set_1825_71_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_predicate_of_set__110_integrate_info(sfun_t, obj_t);
extern obj_t sfun_iinfo_owner_set__183_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _make_sfun_iinfo1801_162_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_class_146_integrate_info(sfun_t);
extern obj_t sfun_iinfo_global_63_integrate_info(sfun_iinfo_105_t);
static obj_t _sexit_iinfo_f_mark1864_138_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_args_84_integrate_info(sfun_t);
extern obj_t sfun_iinfo_u_set__118_integrate_info(sfun_iinfo_105_t, obj_t);
extern svar_iinfo_76_t make_svar_iinfo_142_integrate_info(obj_t, obj_t, obj_t, bool_t, bool_t);
static obj_t _sfun_iinfo_stack_allocator1808_249_integrate_info(obj_t, obj_t);
extern obj_t svar_iinfo_u_mark_set__220_integrate_info(svar_iinfo_76_t, obj_t);
static obj_t _svar_iinfo_kaptured__set_1877_134_integrate_info(obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_integrate_info();
static obj_t struct_object__object_sfun_iinfo_5_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_istamp_147_integrate_info(sfun_iinfo_105_t);
static obj_t _sfun_iinfo_l_set_1849_171_integrate_info(obj_t, obj_t, obj_t);
extern bool_t sexit_iinfo_kaptured__6_integrate_info(sexit_iinfo_190_t);
extern obj_t sfun_iinfo_u_241_integrate_info(sfun_iinfo_105_t);
extern obj_t sfun_iinfo_l_178_integrate_info(sfun_iinfo_105_t);
extern obj_t sfun_iinfo_k_88_integrate_info(sfun_iinfo_105_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t sfun_iinfo_kont_set__215_integrate_info(sfun_iinfo_105_t, obj_t);
extern obj_t sfun_iinfo_cto_152_integrate_info(sfun_iinfo_105_t);
static obj_t _sfun_iinfo_side_effect_1804_136_integrate_info(obj_t, obj_t);
static obj_t _widening1003_sexit_iinfo_67_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
static obj_t _sfun_iinfo_free1828_149_integrate_info(obj_t, obj_t);
extern bool_t sexit_iinfo_celled__92_integrate_info(sexit_iinfo_190_t);
static obj_t _sfun_iinfo_u1840_241_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_args_set__174_integrate_info(sfun_t, obj_t);
static obj_t toplevel_init_63_integrate_info();
extern obj_t sexit_iinfo_handler_249_integrate_info(sexit_t);
static obj_t _sfun_iinfo_cfrom1832_191_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_property_set_1813_230_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_the_closure1812_67_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_k1836_171_integrate_info(obj_t, obj_t);
extern obj_t sexit_iinfo_handler_set__83_integrate_info(sexit_t, obj_t);
extern obj_t open_input_string(obj_t);
extern obj_t sfun_iinfo_free_138_integrate_info(sfun_iinfo_105_t);
static obj_t _sfun_iinfo_k_set_1835_21_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_args_set_1815_13_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_ast_var;
extern obj_t sfun_iinfo_free_set__172_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _widening1004_sfun_iinfo_167_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t struct_object__object_svar_iinfo_213_integrate_info(obj_t, obj_t, obj_t);
static obj_t object__struct_sfun_iinfo_106_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_the_closure_set_1811_192_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_loc_set__90_integrate_info(sfun_t, obj_t);
extern obj_t sfun_iinfo_k_set__165_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _sexit_iinfo_celled_1870_59_integrate_info(obj_t, obj_t);
extern obj_t sexit_iinfo_detached__set__74_integrate_info(sexit_t, bool_t);
static obj_t _svar_iinfo_f_mark_set_1873_65_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_cn_set_1841_101_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_class1820_38_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_top__set_1809_158_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_led_set__27_integrate_info(sfun_iinfo_105_t, obj_t);
extern obj_t sfun_iinfo_property_7_integrate_info(sfun_t);
static obj_t _make_svar_iinfo_96_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo_handler_set_1859_68_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_top__set__103_integrate_info(sfun_t, bool_t);
static obj_t _sfun_iinfo_property1814_220_integrate_info(obj_t, obj_t);
extern sexit_iinfo_190_t widening1003_sexit_iinfo_102_integrate_info(obj_t, obj_t, bool_t, bool_t);
extern obj_t sfun_iinfo_stack_allocator_146_integrate_info(sfun_t);
static obj_t object__struct_svar_iinfo_184_integrate_info(obj_t, obj_t);
static obj_t _widening1002_svar_iinfo_40_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t svar_iinfo_loc_108_integrate_info(svar_t);
extern obj_t sfun_iinfo_kont_66_integrate_info(sfun_iinfo_105_t);
extern obj_t sfun_iinfo_istamp_set__89_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _svar_iinfo_loc_set_1871_21_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_cto1834_179_integrate_info(obj_t, obj_t);
extern bool_t svar_iinfo_celled__54_integrate_info(svar_iinfo_76_t);
static obj_t object_init_111_integrate_info();
static obj_t _sfun_iinfo_k_1838_61_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_k__set_1837_3_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sexit_iinfo_u_mark_184_integrate_info(sexit_iinfo_190_t);
static obj_t _sfun_iinfo_top_1810_65_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_u_set_1839_196_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_g_1848_202_integrate_info(obj_t, obj_t);
static obj_t _svar_iinfo_celled_1880_157_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_cn_set__18_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _sfun_iinfo_dsssl_keywords_set_1821_156_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_predicate_of1806_108_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_k__set__29_integrate_info(sfun_iinfo_105_t, obj_t);
extern obj_t sexit_ast_var;
static obj_t _sfun_iinfo_ct1844_118_integrate_info(obj_t, obj_t);
extern bool_t sexit_iinfo__64_integrate_info(obj_t);
static obj_t _make_sexit_iinfo_46_integrate_info(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _sexit_iinfo_u_mark_set_1865_41_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_class_set__53_integrate_info(sfun_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t _sfun_iinfo_class_set_1819_99_integrate_info(obj_t, obj_t, obj_t);
extern obj_t sfun_iinfo_property_set__178_integrate_info(sfun_t, obj_t);
extern obj_t sfun_iinfo_cfrom_set__158_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _svar_iinfo__104_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_kaptured_set__173_integrate_info(sfun_iinfo_105_t, obj_t);
static obj_t _sfun_iinfo_bound_set_1829_92_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_args1816_129_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_led1852_43_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_predicate_of_set_1805_210_integrate_info(obj_t, obj_t, obj_t);
static obj_t _sfun_iinfo_dsssl_keywords1822_238_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_the_closure_set__128_integrate_info(sfun_t, obj_t);
extern obj_t object__struct_50___object(object_t);
extern obj_t svar_iinfo_u_mark_255_integrate_info(svar_iinfo_76_t);
extern obj_t sfun_iinfo_stack_allocator_set__53_integrate_info(sfun_t, obj_t);
extern obj_t sfun_iinfo_k__50_integrate_info(sfun_iinfo_105_t);
extern bool_t sfun_iinfo_g__46_integrate_info(sfun_iinfo_105_t);
static obj_t require_initialization_114_integrate_info = BUNSPEC;
extern obj_t sfun_iinfo_global_set__36_integrate_info(sfun_iinfo_105_t, obj_t);
extern obj_t sfun_iinfo_ct_151_integrate_info(sfun_iinfo_105_t);
static obj_t _svar_iinfo_loc1872_189_integrate_info(obj_t, obj_t);
extern obj_t sfun_iinfo_cn_214_integrate_info(sfun_iinfo_105_t);
static obj_t _allocate_sexit_iinfo_189_integrate_info(obj_t);
static obj_t _sexit_iinfo_detached__set_1861_62_integrate_info(obj_t, obj_t, obj_t);
static obj_t _allocate_sfun_iinfo_52_integrate_info(obj_t);
extern bool_t svar_iinfo_kaptured__141_integrate_info(svar_iinfo_76_t);
extern bool_t svar_iinfo__34_integrate_info(obj_t);
extern obj_t svar_iinfo_kaptured__set__147_integrate_info(svar_iinfo_76_t, bool_t);
static obj_t _sfun_iinfo__181_integrate_info(obj_t, obj_t);
static obj_t _sfun_iinfo_cfrom_set_1831_147_integrate_info(obj_t, obj_t, obj_t);
extern sexit_iinfo_190_t make_sexit_iinfo_29_integrate_info(obj_t, bool_t, obj_t, obj_t, bool_t, bool_t);
static obj_t cnst_init_137_integrate_info();
static obj_t _sexit_iinfo_celled__set_1869_152_integrate_info(obj_t, obj_t, obj_t);
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(sfun_iinfo_kont_set__env_167_integrate_info, _sfun_iinfo_kont_set_1845_82_integrate_info1898, _sfun_iinfo_kont_set_1845_82_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_stack_allocator_set__env_92_integrate_info, _sfun_iinfo_stack_allocator_set_1807_116_integrate_info1899, _sfun_iinfo_stack_allocator_set_1807_116_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_side_effect__set__env_124_integrate_info, _sfun_iinfo_side_effect__set_1803_33_integrate_info1900, _sfun_iinfo_side_effect__set_1803_33_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_global_set__env_174_integrate_info, _sfun_iinfo_global_set_1855_184_integrate_info1901, _sfun_iinfo_global_set_1855_184_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_u_env_180_integrate_info, _sfun_iinfo_u1840_241_integrate_info1902, _sfun_iinfo_u1840_241_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_ct_set__env_26_integrate_info, _sfun_iinfo_ct_set_1843_111_integrate_info1903, _sfun_iinfo_ct_set_1843_111_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_kont_env_86_integrate_info, _sfun_iinfo_kont1846_202_integrate_info1904, _sfun_iinfo_kont1846_202_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_sfun_iinfo_env_124_integrate_info, _make_sfun_iinfo1801_162_integrate_info1905, _make_sfun_iinfo1801_162_integrate_info, 0L, 29);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_k_env_168_integrate_info, _sfun_iinfo_k1836_171_integrate_info1906, _sfun_iinfo_k1836_171_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_detached__env_17_integrate_info, _sexit_iinfo_detached_1862_181_integrate_info1907, _sexit_iinfo_detached_1862_181_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_u_mark_set__env_155_integrate_info, _svar_iinfo_u_mark_set_1875_106_integrate_info1908, _svar_iinfo_u_mark_set_1875_106_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_led_set__env_64_integrate_info, _sfun_iinfo_led_set_1851_183_integrate_info1909, _sfun_iinfo_led_set_1851_183_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_detached__set__env_52_integrate_info, _sexit_iinfo_detached__set_1861_62_integrate_info1910, _sexit_iinfo_detached__set_1861_62_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_the_closure_set__env_80_integrate_info, _sfun_iinfo_the_closure_set_1811_192_integrate_info1911, _sfun_iinfo_the_closure_set_1811_192_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_args_set__env_156_integrate_info, _sfun_iinfo_args_set_1815_13_integrate_info1912, _sfun_iinfo_args_set_1815_13_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_u_mark_env_161_integrate_info, _sexit_iinfo_u_mark1866_228_integrate_info1913, _sexit_iinfo_u_mark1866_228_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_f_mark_env_138_integrate_info, _svar_iinfo_f_mark1874_4_integrate_info1914, _svar_iinfo_f_mark1874_4_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_celled__set__env_81_integrate_info, _sexit_iinfo_celled__set_1869_152_integrate_info1915, _sexit_iinfo_celled__set_1869_152_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(widening1004_sfun_iinfo_env_186_integrate_info, _widening1004_sfun_iinfo_167_integrate_info1916, _widening1004_sfun_iinfo_167_integrate_info, 0L, 17);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_free_env_67_integrate_info, _sfun_iinfo_free1828_149_integrate_info1917, _sfun_iinfo_free1828_149_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_loc_env_16_integrate_info, _sfun_iinfo_loc1824_181_integrate_info1918, _sfun_iinfo_loc1824_181_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_istamp_env_177_integrate_info, _sfun_iinfo_istamp1854_225_integrate_info1919, _sfun_iinfo_istamp1854_225_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_kaptured__set__env_177_integrate_info, _svar_iinfo_kaptured__set_1877_134_integrate_info1920, _svar_iinfo_kaptured__set_1877_134_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo__env_41_integrate_info, _sexit_iinfo__65_integrate_info1921, _sexit_iinfo__65_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_k__env_210_integrate_info, _sfun_iinfo_k_1838_61_integrate_info1922, _sfun_iinfo_k_1838_61_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_cfrom_env_1_integrate_info, _sfun_iinfo_cfrom1832_191_integrate_info1923, _sfun_iinfo_cfrom1832_191_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_the_closure_env_185_integrate_info, _sfun_iinfo_the_closure1812_67_integrate_info1924, _sfun_iinfo_the_closure1812_67_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_top__set__env_21_integrate_info, _sfun_iinfo_top__set_1809_158_integrate_info1925, _sfun_iinfo_top__set_1809_158_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_sfun_iinfo_env_130_integrate_info, _allocate_sfun_iinfo_52_integrate_info1926, _allocate_sfun_iinfo_52_integrate_info, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1891_integrate_info, struct_object__object_svar_iinfo_213_integrate_info1927, struct_object__object_svar_iinfo_213_integrate_info, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1889_integrate_info, struct_object__object_sexit_iinfo_149_integrate_info1928, struct_object__object_sexit_iinfo_149_integrate_info, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1890_integrate_info, object__struct_svar_iinfo_184_integrate_info1929, object__struct_svar_iinfo_184_integrate_info, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1888_integrate_info, object__struct_sexit_iinfo_21_integrate_info1930, object__struct_sexit_iinfo_21_integrate_info, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1887_integrate_info, struct_object__object_sfun_iinfo_5_integrate_info1931, struct_object__object_sfun_iinfo_5_integrate_info, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc1886_integrate_info, object__struct_sfun_iinfo_106_integrate_info1932, object__struct_sfun_iinfo_106_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_g__env_28_integrate_info, _sfun_iinfo_g_1848_202_integrate_info1933, _sfun_iinfo_g_1848_202_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1003_sexit_iinfo_env_153_integrate_info, _widening1003_sexit_iinfo_67_integrate_info1934, _widening1003_sexit_iinfo_67_integrate_info, 0L, 4);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_dsssl_keywords_set__env_126_integrate_info, _sfun_iinfo_dsssl_keywords_set_1821_156_integrate_info1935, _sfun_iinfo_dsssl_keywords_set_1821_156_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_kaptured__env_15_integrate_info, _sexit_iinfo_kaptured_1868_228_integrate_info1936, _sexit_iinfo_kaptured_1868_228_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_ct_env_101_integrate_info, _sfun_iinfo_ct1844_118_integrate_info1937, _sfun_iinfo_ct1844_118_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_kaptured_set__env_56_integrate_info, _sfun_iinfo_kaptured_set_1857_94_integrate_info1938, _sfun_iinfo_kaptured_set_1857_94_integrate_info, 0L, 2);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_l_set__env_178_integrate_info, _sfun_iinfo_l_set_1849_171_integrate_info1939, _sfun_iinfo_l_set_1849_171_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_owner_set__env_122_integrate_info, _sfun_iinfo_owner_set_1825_71_integrate_info1940, _sfun_iinfo_owner_set_1825_71_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_class_env_211_integrate_info, _sfun_iinfo_class1820_38_integrate_info1941, _sfun_iinfo_class1820_38_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_f_mark_set__env_70_integrate_info, _svar_iinfo_f_mark_set_1873_65_integrate_info1942, _svar_iinfo_f_mark_set_1873_65_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_kaptured__set__env_67_integrate_info, _sexit_iinfo_kaptured__set_1867_250_integrate_info1943, _sexit_iinfo_kaptured__set_1867_250_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_side_effect__env_186_integrate_info, _sfun_iinfo_side_effect_1804_136_integrate_info1944, _sfun_iinfo_side_effect_1804_136_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_f_mark_env_21_integrate_info, _sexit_iinfo_f_mark1864_138_integrate_info1945, _sexit_iinfo_f_mark1864_138_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_k_set__env_35_integrate_info, _sfun_iinfo_k_set_1835_21_integrate_info1946, _sfun_iinfo_k_set_1835_21_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_top__env_167_integrate_info, _sfun_iinfo_top_1810_65_integrate_info1947, _sfun_iinfo_top_1810_65_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_svar_iinfo_env_160_integrate_info, _make_svar_iinfo_96_integrate_info1948, _make_svar_iinfo_96_integrate_info, 0L, 5);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo__env_248_integrate_info, _sfun_iinfo__181_integrate_info1949, _sfun_iinfo__181_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_l_env_204_integrate_info, _sfun_iinfo_l1850_161_integrate_info1950, _sfun_iinfo_l1850_161_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(make_sexit_iinfo_env_117_integrate_info, _make_sexit_iinfo_46_integrate_info1951, _make_sexit_iinfo_46_integrate_info, 0L, 6);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_predicate_of_set__env_128_integrate_info, _sfun_iinfo_predicate_of_set_1805_210_integrate_info1952, _sfun_iinfo_predicate_of_set_1805_210_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_celled__env_29_integrate_info, _sexit_iinfo_celled_1870_59_integrate_info1953, _sexit_iinfo_celled_1870_59_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_args_env_72_integrate_info, _sfun_iinfo_args1816_129_integrate_info1954, _sfun_iinfo_args1816_129_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_cn_set__env_90_integrate_info, _sfun_iinfo_cn_set_1841_101_integrate_info1955, _sfun_iinfo_cn_set_1841_101_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_property_env_183_integrate_info, _sfun_iinfo_property1814_220_integrate_info1956, _sfun_iinfo_property1814_220_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_u_set__env_220_integrate_info, _sfun_iinfo_u_set_1839_196_integrate_info1957, _sfun_iinfo_u_set_1839_196_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(allocate_svar_iinfo_env_27_integrate_info, _allocate_svar_iinfo_246_integrate_info1958, _allocate_svar_iinfo_246_integrate_info, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_dsssl_keywords_env_218_integrate_info, _sfun_iinfo_dsssl_keywords1822_238_integrate_info1959, _sfun_iinfo_dsssl_keywords1822_238_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_loc_set__env_41_integrate_info, _svar_iinfo_loc_set_1871_21_integrate_info1960, _svar_iinfo_loc_set_1871_21_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(svar_iinfo__env_70_integrate_info, _svar_iinfo__104_integrate_info1961, _svar_iinfo__104_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_cto_env_114_integrate_info, _sfun_iinfo_cto1834_179_integrate_info1962, _sfun_iinfo_cto1834_179_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_predicate_of_env_206_integrate_info, _sfun_iinfo_predicate_of1806_108_integrate_info1963, _sfun_iinfo_predicate_of1806_108_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(widening1002_svar_iinfo_env_102_integrate_info, _widening1002_svar_iinfo_40_integrate_info1964, _widening1002_svar_iinfo_40_integrate_info, 0L, 4);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_k__set__env_117_integrate_info, _sfun_iinfo_k__set_1837_3_integrate_info1965, _sfun_iinfo_k__set_1837_3_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_stack_allocator_env_211_integrate_info, _sfun_iinfo_stack_allocator1808_249_integrate_info1966, _sfun_iinfo_stack_allocator1808_249_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_u_mark_set__env_121_integrate_info, _sexit_iinfo_u_mark_set_1865_41_integrate_info1967, _sexit_iinfo_u_mark_set_1865_41_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_body_env_52_integrate_info, _sfun_iinfo_body1818_212_integrate_info1968, _sfun_iinfo_body1818_212_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_celled__env_19_integrate_info, _svar_iinfo_celled_1880_157_integrate_info1969, _svar_iinfo_celled_1880_157_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_class_set__env_92_integrate_info, _sfun_iinfo_class_set_1819_99_integrate_info1970, _sfun_iinfo_class_set_1819_99_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_owner_env_126_integrate_info, _sfun_iinfo_owner1826_86_integrate_info1971, _sfun_iinfo_owner1826_86_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_bound_set__env_159_integrate_info, _sfun_iinfo_bound_set_1829_92_integrate_info1972, _sfun_iinfo_bound_set_1829_92_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_led_env_88_integrate_info, _sfun_iinfo_led1852_43_integrate_info1973, _sfun_iinfo_led1852_43_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_property_set__env_204_integrate_info, _sfun_iinfo_property_set_1813_230_integrate_info1974, _sfun_iinfo_property_set_1813_230_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_global_env_111_integrate_info, _sfun_iinfo_global1856_163_integrate_info1975, _sfun_iinfo_global1856_163_integrate_info, 0L, 1);
DEFINE_STRING(string1892_integrate_info, string1892_integrate_info1976, "SFUN/IINFO SEXIT/IINFO SVAR/IINFO ", 34);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_kaptured__env_232_integrate_info, _svar_iinfo_kaptured_1878_59_integrate_info1977, _svar_iinfo_kaptured_1878_59_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_loc_env_26_integrate_info, _svar_iinfo_loc1872_189_integrate_info1978, _svar_iinfo_loc1872_189_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_body_set__env_12_integrate_info, _sfun_iinfo_body_set_1817_123_integrate_info1979, _sfun_iinfo_body_set_1817_123_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_bound_env_54_integrate_info, _sfun_iinfo_bound1830_36_integrate_info1980, _sfun_iinfo_bound1830_36_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_cfrom_set__env_48_integrate_info, _sfun_iinfo_cfrom_set_1831_147_integrate_info1981, _sfun_iinfo_cfrom_set_1831_147_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_g__set__env_8_integrate_info, _sfun_iinfo_g__set_1847_16_integrate_info1982, _sfun_iinfo_g__set_1847_16_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_cn_env_103_integrate_info, _sfun_iinfo_cn1842_18_integrate_info1983, _sfun_iinfo_cn1842_18_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_kaptured_env_251_integrate_info, _sfun_iinfo_kaptured1858_246_integrate_info1984, _sfun_iinfo_kaptured1858_246_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(allocate_sexit_iinfo_env_116_integrate_info, _allocate_sexit_iinfo_189_integrate_info1985, _allocate_sexit_iinfo_189_integrate_info, 0L, 0);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_handler_set__env_245_integrate_info, _sexit_iinfo_handler_set_1859_68_integrate_info1986, _sexit_iinfo_handler_set_1859_68_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_f_mark_set__env_47_integrate_info, _sexit_iinfo_f_mark_set_1863_117_integrate_info1987, _sexit_iinfo_f_mark_set_1863_117_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_cto_set__env_152_integrate_info, _sfun_iinfo_cto_set_1833_248_integrate_info1988, _sfun_iinfo_cto_set_1833_248_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_istamp_set__env_133_integrate_info, _sfun_iinfo_istamp_set_1853_214_integrate_info1989, _sfun_iinfo_istamp_set_1853_214_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_arity_env_9_integrate_info, _sfun_iinfo_arity1802_164_integrate_info1990, _sfun_iinfo_arity1802_164_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(svar_iinfo_celled__set__env_78_integrate_info, _svar_iinfo_celled__set_1879_24_integrate_info1991, _svar_iinfo_celled__set_1879_24_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_loc_set__env_237_integrate_info, _sfun_iinfo_loc_set_1823_203_integrate_info1992, _sfun_iinfo_loc_set_1823_203_integrate_info, 0L, 2);
DEFINE_EXPORT_PROCEDURE(sfun_iinfo_free_set__env_224_integrate_info, _sfun_iinfo_free_set_1827_109_integrate_info1993, _sfun_iinfo_free_set_1827_109_integrate_info, 0L, 2);
extern obj_t object__struct_env_210___object;
DEFINE_EXPORT_PROCEDURE(svar_iinfo_u_mark_env_194_integrate_info, _svar_iinfo_u_mark1876_186_integrate_info1994, _svar_iinfo_u_mark1876_186_integrate_info, 0L, 1);
DEFINE_EXPORT_PROCEDURE(sexit_iinfo_handler_env_215_integrate_info, _sexit_iinfo_handler1860_157_integrate_info1995, _sexit_iinfo_handler1860_157_integrate_info, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_integrate_info(long checksum_2165, char *from_2166)
{
   if (CBOOL(require_initialization_114_integrate_info))
     {
	require_initialization_114_integrate_info = BBOOL(((bool_t) 0));
	library_modules_init_112_integrate_info();
	cnst_init_137_integrate_info();
	imported_modules_init_94_integrate_info();
	object_init_111_integrate_info();
	method_init_76_integrate_info();
	toplevel_init_63_integrate_info();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_integrate_info()
{
   module_initialization_70___object(((long) 0), "INTEGRATE_INFO");
   module_initialization_70___reader(((long) 0), "INTEGRATE_INFO");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_integrate_info()
{
   {
      obj_t cnst_port_138_2157;
      cnst_port_138_2157 = open_input_string(string1892_integrate_info);
      {
	 long i_2158;
	 i_2158 = ((long) 2);
       loop_2159:
	 {
	    bool_t test1893_2160;
	    test1893_2160 = (i_2158 == ((long) -1));
	    if (test1893_2160)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1894_2161;
		    {
		       obj_t list1895_2162;
		       {
			  obj_t arg1896_2163;
			  arg1896_2163 = BNIL;
			  list1895_2162 = MAKE_PAIR(cnst_port_138_2157, arg1896_2163);
		       }
		       arg1894_2161 = read___reader(list1895_2162);
		    }
		    CNST_TABLE_SET(i_2158, arg1894_2161);
		 }
		 {
		    int aux_2164;
		    {
		       long aux_2184;
		       aux_2184 = (i_2158 - ((long) 1));
		       aux_2164 = (int) (aux_2184);
		    }
		    {
		       long i_2187;
		       i_2187 = (long) (aux_2164);
		       i_2158 = i_2187;
		       goto loop_2159;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_integrate_info()
{
   return BUNSPEC;
}


/* object-init */ obj_t 
object_init_111_integrate_info()
{
   {
      obj_t arg1549_888;
      arg1549_888 = svar_ast_var;
      svar_iinfo_76_integrate_info = add_class__117___object(CNST_TABLE_REF(((long) 0)), arg1549_888, allocate_svar_iinfo_env_27_integrate_info, ((long) 23564), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1554_892;
      arg1554_892 = sexit_ast_var;
      sexit_iinfo_190_integrate_info = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1554_892, allocate_sexit_iinfo_env_116_integrate_info, ((long) 7261), BUNSPEC, BFALSE);
   }
   {
      obj_t arg1558_896;
      arg1558_896 = sfun_ast_var;
      sfun_iinfo_105_integrate_info = add_class__117___object(CNST_TABLE_REF(((long) 2)), arg1558_896, allocate_sfun_iinfo_env_130_integrate_info, ((long) 8433), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-sfun/iinfo */ sfun_t 
allocate_sfun_iinfo_8_integrate_info()
{
   {
      sfun_t new1530_899;
      new1530_899 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
      {
	 long arg1561_900;
	 arg1561_900 = class_num_218___object(sfun_iinfo_105_integrate_info);
	 {
	    obj_t obj_1411;
	    obj_1411 = (obj_t) (new1530_899);
	    (((obj_t) CREF(obj_1411))->header = MAKE_HEADER(arg1561_900, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2199;
	 aux_2199 = (object_t) (new1530_899);
	 OBJECT_WIDENING_SET(aux_2199, BFALSE);
      }
      return new1530_899;
   }
}


/* _allocate-sfun/iinfo */ obj_t 
_allocate_sfun_iinfo_52_integrate_info(obj_t env_1856)
{
   {
      sfun_t aux_2202;
      aux_2202 = allocate_sfun_iinfo_8_integrate_info();
      return (obj_t) (aux_2202);
   }
}


/* sfun/iinfo? */ bool_t 
sfun_iinfo__133_integrate_info(obj_t obj_4)
{
   return is_a__118___object(obj_4, sfun_iinfo_105_integrate_info);
}


/* _sfun/iinfo? */ obj_t 
_sfun_iinfo__181_integrate_info(obj_t env_1857, obj_t obj_1858)
{
   {
      bool_t aux_2206;
      aux_2206 = sfun_iinfo__133_integrate_info(obj_1858);
      return BBOOL(aux_2206);
   }
}


/* widening1004-sfun/iinfo */ sfun_iinfo_105_t 
widening1004_sfun_iinfo_11_integrate_info(obj_t owner_5, obj_t free_6, obj_t bound_7, obj_t cfrom_8, obj_t cto_9, obj_t k_10, obj_t k__190_11, obj_t u_12, obj_t cn_13, obj_t ct_14, obj_t kont_15, bool_t g__219_16, obj_t l_17, obj_t led_18, obj_t istamp_19, obj_t global_20, obj_t kaptured_21)
{
   {
      sfun_iinfo_105_t new1481_1413;
      new1481_1413 = ((sfun_iinfo_105_t) BREF(GC_MALLOC(sizeof(struct sfun_iinfo_105))));
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->owner) = ((obj_t) owner_5), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->free) = ((obj_t) free_6), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->bound) = ((obj_t) bound_7), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->cfrom) = ((obj_t) cfrom_8), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->cto) = ((obj_t) cto_9), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->k) = ((obj_t) k_10), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->k__190) = ((obj_t) k__190_11), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->u) = ((obj_t) u_12), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->cn) = ((obj_t) cn_13), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->ct) = ((obj_t) ct_14), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->kont) = ((obj_t) kont_15), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->g__219) = ((bool_t) g__219_16), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->l) = ((obj_t) l_17), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->led) = ((obj_t) led_18), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->istamp) = ((obj_t) istamp_19), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->global) = ((obj_t) global_20), BUNSPEC);
      ((((sfun_iinfo_105_t) CREF(new1481_1413))->kaptured) = ((obj_t) kaptured_21), BUNSPEC);
      return new1481_1413;
   }
}


/* _widening1004-sfun/iinfo */ obj_t 
_widening1004_sfun_iinfo_167_integrate_info(obj_t env_1859, obj_t owner_1860, obj_t free_1861, obj_t bound_1862, obj_t cfrom_1863, obj_t cto_1864, obj_t k_1865, obj_t k__190_1866, obj_t u_1867, obj_t cn_1868, obj_t ct_1869, obj_t kont_1870, obj_t g__219_1871, obj_t l_1872, obj_t led_1873, obj_t istamp_1874, obj_t global_1875, obj_t kaptured_1876)
{
   {
      sfun_iinfo_105_t aux_2227;
      aux_2227 = widening1004_sfun_iinfo_11_integrate_info(owner_1860, free_1861, bound_1862, cfrom_1863, cto_1864, k_1865, k__190_1866, u_1867, cn_1868, ct_1869, kont_1870, CBOOL(g__219_1871), l_1872, led_1873, istamp_1874, global_1875, kaptured_1876);
      return (obj_t) (aux_2227);
   }
}


/* make-sfun/iinfo */ sfun_iinfo_105_t 
make_sfun_iinfo_248_integrate_info(long arity_22, obj_t side_effect__165_23, obj_t predicate_of_78_24, obj_t stack_allocator_172_25, bool_t top__138_26, obj_t the_closure_238_27, obj_t property_28, obj_t args_29, obj_t body_30, obj_t class_31, obj_t dsssl_keywords_243_32, obj_t loc_33, obj_t owner_34, obj_t free_35, obj_t bound_36, obj_t cfrom_37, obj_t cto_38, obj_t k_39, obj_t k__190_40, obj_t u_41, obj_t cn_42, obj_t ct_43, obj_t kont_44, bool_t g__219_45, obj_t l_46, obj_t led_47, obj_t istamp_48, obj_t global_49, obj_t kaptured_50)
{
   {
      sfun_t aux1500_1431;
      {
	 sfun_t res1792_1463;
	 {
	    sfun_t new1117_1447;
	    new1117_1447 = ((sfun_t) BREF(GC_MALLOC(sizeof(struct sfun))));
	    {
	       long arg1653_1448;
	       arg1653_1448 = class_num_218___object(sfun_ast_var);
	       {
		  obj_t obj_1461;
		  obj_1461 = (obj_t) (new1117_1447);
		  (((obj_t) CREF(obj_1461))->header = MAKE_HEADER(arg1653_1448, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2235;
	       aux_2235 = (object_t) (new1117_1447);
	       OBJECT_WIDENING_SET(aux_2235, BFALSE);
	    }
	    ((((sfun_t) CREF(new1117_1447))->arity) = ((long) arity_22), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->side_effect__165) = ((obj_t) side_effect__165_23), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->predicate_of_78) = ((obj_t) predicate_of_78_24), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->stack_allocator_172) = ((obj_t) stack_allocator_172_25), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->top__138) = ((bool_t) top__138_26), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->the_closure_238) = ((obj_t) the_closure_238_27), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->property) = ((obj_t) property_28), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->args) = ((obj_t) args_29), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->body) = ((obj_t) body_30), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->class) = ((obj_t) class_31), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->dsssl_keywords_243) = ((obj_t) dsssl_keywords_243_32), BUNSPEC);
	    ((((sfun_t) CREF(new1117_1447))->loc) = ((obj_t) loc_33), BUNSPEC);
	    res1792_1463 = new1117_1447;
	 }
	 aux1500_1431 = res1792_1463;
      }
      {
	 sfun_iinfo_105_t new1501_1432;
	 new1501_1432 = ((sfun_iinfo_105_t) (aux1500_1431));
	 {
	    long arg1562_1433;
	    arg1562_1433 = class_num_218___object(sfun_iinfo_105_integrate_info);
	    {
	       obj_t obj_1464;
	       obj_1464 = (obj_t) (new1501_1432);
	       (((obj_t) CREF(obj_1464))->header = MAKE_HEADER(arg1562_1433, 0), BUNSPEC);
	    }
	 }
	 {
	    sfun_iinfo_105_t arg1563_1434;
	    {
	       sfun_iinfo_105_t res1793_1501;
	       {
		  sfun_iinfo_105_t new1481_1483;
		  new1481_1483 = ((sfun_iinfo_105_t) BREF(GC_MALLOC(sizeof(struct sfun_iinfo_105))));
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->owner) = ((obj_t) owner_34), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->free) = ((obj_t) free_35), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->bound) = ((obj_t) bound_36), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->cfrom) = ((obj_t) cfrom_37), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->cto) = ((obj_t) cto_38), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->k) = ((obj_t) k_39), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->k__190) = ((obj_t) k__190_40), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->u) = ((obj_t) u_41), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->cn) = ((obj_t) cn_42), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->ct) = ((obj_t) ct_43), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->kont) = ((obj_t) kont_44), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->g__219) = ((bool_t) g__219_45), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->l) = ((obj_t) l_46), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->led) = ((obj_t) led_47), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->istamp) = ((obj_t) istamp_48), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->global) = ((obj_t) global_49), BUNSPEC);
		  ((((sfun_iinfo_105_t) CREF(new1481_1483))->kaptured) = ((obj_t) kaptured_50), BUNSPEC);
		  res1793_1501 = new1481_1483;
	       }
	       arg1563_1434 = res1793_1501;
	    }
	    {
	       obj_t aux_2274;
	       object_t aux_2272;
	       aux_2274 = (obj_t) (arg1563_1434);
	       aux_2272 = (object_t) (new1501_1432);
	       OBJECT_WIDENING_SET(aux_2272, aux_2274);
	    }
	 }
	 return new1501_1432;
      }
   }
}


/* _make-sfun/iinfo1801 */ obj_t 
_make_sfun_iinfo1801_162_integrate_info(obj_t env_1877, obj_t arity_1878, obj_t side_effect__165_1879, obj_t predicate_of_78_1880, obj_t stack_allocator_172_1881, obj_t top__138_1882, obj_t the_closure_238_1883, obj_t property_1884, obj_t args_1885, obj_t body_1886, obj_t class_1887, obj_t dsssl_keywords_243_1888, obj_t loc_1889, obj_t owner_1890, obj_t free_1891, obj_t bound_1892, obj_t cfrom_1893, obj_t cto_1894, obj_t k_1895, obj_t k__190_1896, obj_t u_1897, obj_t cn_1898, obj_t ct_1899, obj_t kont_1900, obj_t g__219_1901, obj_t l_1902, obj_t led_1903, obj_t istamp_1904, obj_t global_1905, obj_t kaptured_1906)
{
   {
      sfun_iinfo_105_t aux_2277;
      aux_2277 = make_sfun_iinfo_248_integrate_info((long) CINT(arity_1878), side_effect__165_1879, predicate_of_78_1880, stack_allocator_172_1881, CBOOL(top__138_1882), the_closure_238_1883, property_1884, args_1885, body_1886, class_1887, dsssl_keywords_243_1888, loc_1889, owner_1890, free_1891, bound_1892, cfrom_1893, cto_1894, k_1895, k__190_1896, u_1897, cn_1898, ct_1899, kont_1900, CBOOL(g__219_1901), l_1902, led_1903, istamp_1904, global_1905, kaptured_1906);
      return (obj_t) (aux_2277);
   }
}


/* sfun/iinfo-arity */ long 
sfun_iinfo_arity_150_integrate_info(sfun_t obj_51)
{
   return (((sfun_t) CREF(obj_51))->arity);
}


/* _sfun/iinfo-arity1802 */ obj_t 
_sfun_iinfo_arity1802_164_integrate_info(obj_t env_1907, obj_t obj_1908)
{
   {
      long aux_2284;
      aux_2284 = sfun_iinfo_arity_150_integrate_info((sfun_t) (obj_1908));
      return BINT(aux_2284);
   }
}


/* sfun/iinfo-side-effect?-set! */ obj_t 
sfun_iinfo_side_effect__set__248_integrate_info(sfun_t obj_52, obj_t val1502_53)
{
   return ((((sfun_t) CREF(obj_52))->side_effect__165) = ((obj_t) val1502_53), BUNSPEC);
}


/* _sfun/iinfo-side-effect?-set!1803 */ obj_t 
_sfun_iinfo_side_effect__set_1803_33_integrate_info(obj_t env_1909, obj_t obj_1910, obj_t val1502_1911)
{
   return sfun_iinfo_side_effect__set__248_integrate_info((sfun_t) (obj_1910), val1502_1911);
}


/* sfun/iinfo-side-effect? */ obj_t 
sfun_iinfo_side_effect__11_integrate_info(sfun_t obj_54)
{
   return (((sfun_t) CREF(obj_54))->side_effect__165);
}


/* _sfun/iinfo-side-effect?1804 */ obj_t 
_sfun_iinfo_side_effect_1804_136_integrate_info(obj_t env_1912, obj_t obj_1913)
{
   return sfun_iinfo_side_effect__11_integrate_info((sfun_t) (obj_1913));
}


/* sfun/iinfo-predicate-of-set! */ obj_t 
sfun_iinfo_predicate_of_set__110_integrate_info(sfun_t obj_55, obj_t val1503_56)
{
   return ((((sfun_t) CREF(obj_55))->predicate_of_78) = ((obj_t) val1503_56), BUNSPEC);
}


/* _sfun/iinfo-predicate-of-set!1805 */ obj_t 
_sfun_iinfo_predicate_of_set_1805_210_integrate_info(obj_t env_1914, obj_t obj_1915, obj_t val1503_1916)
{
   return sfun_iinfo_predicate_of_set__110_integrate_info((sfun_t) (obj_1915), val1503_1916);
}


/* sfun/iinfo-predicate-of */ obj_t 
sfun_iinfo_predicate_of_199_integrate_info(sfun_t obj_57)
{
   return (((sfun_t) CREF(obj_57))->predicate_of_78);
}


/* _sfun/iinfo-predicate-of1806 */ obj_t 
_sfun_iinfo_predicate_of1806_108_integrate_info(obj_t env_1917, obj_t obj_1918)
{
   return sfun_iinfo_predicate_of_199_integrate_info((sfun_t) (obj_1918));
}


/* sfun/iinfo-stack-allocator-set! */ obj_t 
sfun_iinfo_stack_allocator_set__53_integrate_info(sfun_t obj_58, obj_t val1504_59)
{
   return ((((sfun_t) CREF(obj_58))->stack_allocator_172) = ((obj_t) val1504_59), BUNSPEC);
}


/* _sfun/iinfo-stack-allocator-set!1807 */ obj_t 
_sfun_iinfo_stack_allocator_set_1807_116_integrate_info(obj_t env_1919, obj_t obj_1920, obj_t val1504_1921)
{
   return sfun_iinfo_stack_allocator_set__53_integrate_info((sfun_t) (obj_1920), val1504_1921);
}


/* sfun/iinfo-stack-allocator */ obj_t 
sfun_iinfo_stack_allocator_146_integrate_info(sfun_t obj_60)
{
   return (((sfun_t) CREF(obj_60))->stack_allocator_172);
}


/* _sfun/iinfo-stack-allocator1808 */ obj_t 
_sfun_iinfo_stack_allocator1808_249_integrate_info(obj_t env_1922, obj_t obj_1923)
{
   return sfun_iinfo_stack_allocator_146_integrate_info((sfun_t) (obj_1923));
}


/* sfun/iinfo-top?-set! */ obj_t 
sfun_iinfo_top__set__103_integrate_info(sfun_t obj_61, bool_t val1505_62)
{
   return ((((sfun_t) CREF(obj_61))->top__138) = ((bool_t) val1505_62), BUNSPEC);
}


/* _sfun/iinfo-top?-set!1809 */ obj_t 
_sfun_iinfo_top__set_1809_158_integrate_info(obj_t env_1924, obj_t obj_1925, obj_t val1505_1926)
{
   return sfun_iinfo_top__set__103_integrate_info((sfun_t) (obj_1925), CBOOL(val1505_1926));
}


/* sfun/iinfo-top? */ bool_t 
sfun_iinfo_top__215_integrate_info(sfun_t obj_63)
{
   return (((sfun_t) CREF(obj_63))->top__138);
}


/* _sfun/iinfo-top?1810 */ obj_t 
_sfun_iinfo_top_1810_65_integrate_info(obj_t env_1927, obj_t obj_1928)
{
   {
      bool_t aux_2311;
      aux_2311 = sfun_iinfo_top__215_integrate_info((sfun_t) (obj_1928));
      return BBOOL(aux_2311);
   }
}


/* sfun/iinfo-the-closure-set! */ obj_t 
sfun_iinfo_the_closure_set__128_integrate_info(sfun_t obj_64, obj_t val1506_65)
{
   return ((((sfun_t) CREF(obj_64))->the_closure_238) = ((obj_t) val1506_65), BUNSPEC);
}


/* _sfun/iinfo-the-closure-set!1811 */ obj_t 
_sfun_iinfo_the_closure_set_1811_192_integrate_info(obj_t env_1929, obj_t obj_1930, obj_t val1506_1931)
{
   return sfun_iinfo_the_closure_set__128_integrate_info((sfun_t) (obj_1930), val1506_1931);
}


/* sfun/iinfo-the-closure */ obj_t 
sfun_iinfo_the_closure_5_integrate_info(sfun_t obj_66)
{
   return (((sfun_t) CREF(obj_66))->the_closure_238);
}


/* _sfun/iinfo-the-closure1812 */ obj_t 
_sfun_iinfo_the_closure1812_67_integrate_info(obj_t env_1932, obj_t obj_1933)
{
   return sfun_iinfo_the_closure_5_integrate_info((sfun_t) (obj_1933));
}


/* sfun/iinfo-property-set! */ obj_t 
sfun_iinfo_property_set__178_integrate_info(sfun_t obj_67, obj_t val1507_68)
{
   return ((((sfun_t) CREF(obj_67))->property) = ((obj_t) val1507_68), BUNSPEC);
}


/* _sfun/iinfo-property-set!1813 */ obj_t 
_sfun_iinfo_property_set_1813_230_integrate_info(obj_t env_1934, obj_t obj_1935, obj_t val1507_1936)
{
   return sfun_iinfo_property_set__178_integrate_info((sfun_t) (obj_1935), val1507_1936);
}


/* sfun/iinfo-property */ obj_t 
sfun_iinfo_property_7_integrate_info(sfun_t obj_69)
{
   return (((sfun_t) CREF(obj_69))->property);
}


/* _sfun/iinfo-property1814 */ obj_t 
_sfun_iinfo_property1814_220_integrate_info(obj_t env_1937, obj_t obj_1938)
{
   return sfun_iinfo_property_7_integrate_info((sfun_t) (obj_1938));
}


/* sfun/iinfo-args-set! */ obj_t 
sfun_iinfo_args_set__174_integrate_info(sfun_t obj_70, obj_t val1508_71)
{
   return ((((sfun_t) CREF(obj_70))->args) = ((obj_t) val1508_71), BUNSPEC);
}


/* _sfun/iinfo-args-set!1815 */ obj_t 
_sfun_iinfo_args_set_1815_13_integrate_info(obj_t env_1939, obj_t obj_1940, obj_t val1508_1941)
{
   return sfun_iinfo_args_set__174_integrate_info((sfun_t) (obj_1940), val1508_1941);
}


/* sfun/iinfo-args */ obj_t 
sfun_iinfo_args_84_integrate_info(sfun_t obj_72)
{
   return (((sfun_t) CREF(obj_72))->args);
}


/* _sfun/iinfo-args1816 */ obj_t 
_sfun_iinfo_args1816_129_integrate_info(obj_t env_1942, obj_t obj_1943)
{
   return sfun_iinfo_args_84_integrate_info((sfun_t) (obj_1943));
}


/* sfun/iinfo-body-set! */ obj_t 
sfun_iinfo_body_set__218_integrate_info(sfun_t obj_73, obj_t val1509_74)
{
   return ((((sfun_t) CREF(obj_73))->body) = ((obj_t) val1509_74), BUNSPEC);
}


/* _sfun/iinfo-body-set!1817 */ obj_t 
_sfun_iinfo_body_set_1817_123_integrate_info(obj_t env_1944, obj_t obj_1945, obj_t val1509_1946)
{
   return sfun_iinfo_body_set__218_integrate_info((sfun_t) (obj_1945), val1509_1946);
}


/* sfun/iinfo-body */ obj_t 
sfun_iinfo_body_74_integrate_info(sfun_t obj_75)
{
   return (((sfun_t) CREF(obj_75))->body);
}


/* _sfun/iinfo-body1818 */ obj_t 
_sfun_iinfo_body1818_212_integrate_info(obj_t env_1947, obj_t obj_1948)
{
   return sfun_iinfo_body_74_integrate_info((sfun_t) (obj_1948));
}


/* sfun/iinfo-class-set! */ obj_t 
sfun_iinfo_class_set__53_integrate_info(sfun_t obj_76, obj_t val1510_77)
{
   return ((((sfun_t) CREF(obj_76))->class) = ((obj_t) val1510_77), BUNSPEC);
}


/* _sfun/iinfo-class-set!1819 */ obj_t 
_sfun_iinfo_class_set_1819_99_integrate_info(obj_t env_1949, obj_t obj_1950, obj_t val1510_1951)
{
   return sfun_iinfo_class_set__53_integrate_info((sfun_t) (obj_1950), val1510_1951);
}


/* sfun/iinfo-class */ obj_t 
sfun_iinfo_class_146_integrate_info(sfun_t obj_78)
{
   return (((sfun_t) CREF(obj_78))->class);
}


/* _sfun/iinfo-class1820 */ obj_t 
_sfun_iinfo_class1820_38_integrate_info(obj_t env_1952, obj_t obj_1953)
{
   return sfun_iinfo_class_146_integrate_info((sfun_t) (obj_1953));
}


/* sfun/iinfo-dsssl-keywords-set! */ obj_t 
sfun_iinfo_dsssl_keywords_set__223_integrate_info(sfun_t obj_79, obj_t val1511_80)
{
   return ((((sfun_t) CREF(obj_79))->dsssl_keywords_243) = ((obj_t) val1511_80), BUNSPEC);
}


/* _sfun/iinfo-dsssl-keywords-set!1821 */ obj_t 
_sfun_iinfo_dsssl_keywords_set_1821_156_integrate_info(obj_t env_1954, obj_t obj_1955, obj_t val1511_1956)
{
   return sfun_iinfo_dsssl_keywords_set__223_integrate_info((sfun_t) (obj_1955), val1511_1956);
}


/* sfun/iinfo-dsssl-keywords */ obj_t 
sfun_iinfo_dsssl_keywords_229_integrate_info(sfun_t obj_81)
{
   return (((sfun_t) CREF(obj_81))->dsssl_keywords_243);
}


/* _sfun/iinfo-dsssl-keywords1822 */ obj_t 
_sfun_iinfo_dsssl_keywords1822_238_integrate_info(obj_t env_1957, obj_t obj_1958)
{
   return sfun_iinfo_dsssl_keywords_229_integrate_info((sfun_t) (obj_1958));
}


/* sfun/iinfo-loc-set! */ obj_t 
sfun_iinfo_loc_set__90_integrate_info(sfun_t obj_82, obj_t val1512_83)
{
   return ((((sfun_t) CREF(obj_82))->loc) = ((obj_t) val1512_83), BUNSPEC);
}


/* _sfun/iinfo-loc-set!1823 */ obj_t 
_sfun_iinfo_loc_set_1823_203_integrate_info(obj_t env_1959, obj_t obj_1960, obj_t val1512_1961)
{
   return sfun_iinfo_loc_set__90_integrate_info((sfun_t) (obj_1960), val1512_1961);
}


/* sfun/iinfo-loc */ obj_t 
sfun_iinfo_loc_114_integrate_info(sfun_t obj_84)
{
   return (((sfun_t) CREF(obj_84))->loc);
}


/* _sfun/iinfo-loc1824 */ obj_t 
_sfun_iinfo_loc1824_181_integrate_info(obj_t env_1962, obj_t obj_1963)
{
   return sfun_iinfo_loc_114_integrate_info((sfun_t) (obj_1963));
}


/* sfun/iinfo-owner-set! */ obj_t 
sfun_iinfo_owner_set__183_integrate_info(sfun_iinfo_105_t obj_85, obj_t val1513_86)
{
   {
      obj_t aux_2357;
      {
	 object_t aux_2358;
	 aux_2358 = (object_t) (obj_85);
	 aux_2357 = OBJECT_WIDENING(aux_2358);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2357))->owner) = ((obj_t) val1513_86), BUNSPEC);
   }
}


/* _sfun/iinfo-owner-set!1825 */ obj_t 
_sfun_iinfo_owner_set_1825_71_integrate_info(obj_t env_1964, obj_t obj_1965, obj_t val1513_1966)
{
   return sfun_iinfo_owner_set__183_integrate_info((sfun_iinfo_105_t) (obj_1965), val1513_1966);
}


/* sfun/iinfo-owner */ obj_t 
sfun_iinfo_owner_223_integrate_info(sfun_iinfo_105_t obj_87)
{
   {
      obj_t aux_2364;
      {
	 object_t aux_2365;
	 aux_2365 = (object_t) (obj_87);
	 aux_2364 = OBJECT_WIDENING(aux_2365);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2364))->owner);
   }
}


/* _sfun/iinfo-owner1826 */ obj_t 
_sfun_iinfo_owner1826_86_integrate_info(obj_t env_1967, obj_t obj_1968)
{
   return sfun_iinfo_owner_223_integrate_info((sfun_iinfo_105_t) (obj_1968));
}


/* sfun/iinfo-free-set! */ obj_t 
sfun_iinfo_free_set__172_integrate_info(sfun_iinfo_105_t obj_88, obj_t val1514_89)
{
   {
      obj_t aux_2371;
      {
	 object_t aux_2372;
	 aux_2372 = (object_t) (obj_88);
	 aux_2371 = OBJECT_WIDENING(aux_2372);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2371))->free) = ((obj_t) val1514_89), BUNSPEC);
   }
}


/* _sfun/iinfo-free-set!1827 */ obj_t 
_sfun_iinfo_free_set_1827_109_integrate_info(obj_t env_1969, obj_t obj_1970, obj_t val1514_1971)
{
   return sfun_iinfo_free_set__172_integrate_info((sfun_iinfo_105_t) (obj_1970), val1514_1971);
}


/* sfun/iinfo-free */ obj_t 
sfun_iinfo_free_138_integrate_info(sfun_iinfo_105_t obj_90)
{
   {
      obj_t aux_2378;
      {
	 object_t aux_2379;
	 aux_2379 = (object_t) (obj_90);
	 aux_2378 = OBJECT_WIDENING(aux_2379);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2378))->free);
   }
}


/* _sfun/iinfo-free1828 */ obj_t 
_sfun_iinfo_free1828_149_integrate_info(obj_t env_1972, obj_t obj_1973)
{
   return sfun_iinfo_free_138_integrate_info((sfun_iinfo_105_t) (obj_1973));
}


/* sfun/iinfo-bound-set! */ obj_t 
sfun_iinfo_bound_set__116_integrate_info(sfun_iinfo_105_t obj_91, obj_t val1515_92)
{
   {
      obj_t aux_2385;
      {
	 object_t aux_2386;
	 aux_2386 = (object_t) (obj_91);
	 aux_2385 = OBJECT_WIDENING(aux_2386);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2385))->bound) = ((obj_t) val1515_92), BUNSPEC);
   }
}


/* _sfun/iinfo-bound-set!1829 */ obj_t 
_sfun_iinfo_bound_set_1829_92_integrate_info(obj_t env_1974, obj_t obj_1975, obj_t val1515_1976)
{
   return sfun_iinfo_bound_set__116_integrate_info((sfun_iinfo_105_t) (obj_1975), val1515_1976);
}


/* sfun/iinfo-bound */ obj_t 
sfun_iinfo_bound_208_integrate_info(sfun_iinfo_105_t obj_93)
{
   {
      obj_t aux_2392;
      {
	 object_t aux_2393;
	 aux_2393 = (object_t) (obj_93);
	 aux_2392 = OBJECT_WIDENING(aux_2393);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2392))->bound);
   }
}


/* _sfun/iinfo-bound1830 */ obj_t 
_sfun_iinfo_bound1830_36_integrate_info(obj_t env_1977, obj_t obj_1978)
{
   return sfun_iinfo_bound_208_integrate_info((sfun_iinfo_105_t) (obj_1978));
}


/* sfun/iinfo-cfrom-set! */ obj_t 
sfun_iinfo_cfrom_set__158_integrate_info(sfun_iinfo_105_t obj_94, obj_t val1516_95)
{
   {
      obj_t aux_2399;
      {
	 object_t aux_2400;
	 aux_2400 = (object_t) (obj_94);
	 aux_2399 = OBJECT_WIDENING(aux_2400);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2399))->cfrom) = ((obj_t) val1516_95), BUNSPEC);
   }
}


/* _sfun/iinfo-cfrom-set!1831 */ obj_t 
_sfun_iinfo_cfrom_set_1831_147_integrate_info(obj_t env_1979, obj_t obj_1980, obj_t val1516_1981)
{
   return sfun_iinfo_cfrom_set__158_integrate_info((sfun_iinfo_105_t) (obj_1980), val1516_1981);
}


/* sfun/iinfo-cfrom */ obj_t 
sfun_iinfo_cfrom_145_integrate_info(sfun_iinfo_105_t obj_96)
{
   {
      obj_t aux_2406;
      {
	 object_t aux_2407;
	 aux_2407 = (object_t) (obj_96);
	 aux_2406 = OBJECT_WIDENING(aux_2407);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2406))->cfrom);
   }
}


/* _sfun/iinfo-cfrom1832 */ obj_t 
_sfun_iinfo_cfrom1832_191_integrate_info(obj_t env_1982, obj_t obj_1983)
{
   return sfun_iinfo_cfrom_145_integrate_info((sfun_iinfo_105_t) (obj_1983));
}


/* sfun/iinfo-cto-set! */ obj_t 
sfun_iinfo_cto_set__217_integrate_info(sfun_iinfo_105_t obj_97, obj_t val1517_98)
{
   {
      obj_t aux_2413;
      {
	 object_t aux_2414;
	 aux_2414 = (object_t) (obj_97);
	 aux_2413 = OBJECT_WIDENING(aux_2414);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2413))->cto) = ((obj_t) val1517_98), BUNSPEC);
   }
}


/* _sfun/iinfo-cto-set!1833 */ obj_t 
_sfun_iinfo_cto_set_1833_248_integrate_info(obj_t env_1984, obj_t obj_1985, obj_t val1517_1986)
{
   return sfun_iinfo_cto_set__217_integrate_info((sfun_iinfo_105_t) (obj_1985), val1517_1986);
}


/* sfun/iinfo-cto */ obj_t 
sfun_iinfo_cto_152_integrate_info(sfun_iinfo_105_t obj_99)
{
   {
      obj_t aux_2420;
      {
	 object_t aux_2421;
	 aux_2421 = (object_t) (obj_99);
	 aux_2420 = OBJECT_WIDENING(aux_2421);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2420))->cto);
   }
}


/* _sfun/iinfo-cto1834 */ obj_t 
_sfun_iinfo_cto1834_179_integrate_info(obj_t env_1987, obj_t obj_1988)
{
   return sfun_iinfo_cto_152_integrate_info((sfun_iinfo_105_t) (obj_1988));
}


/* sfun/iinfo-k-set! */ obj_t 
sfun_iinfo_k_set__165_integrate_info(sfun_iinfo_105_t obj_100, obj_t val1518_101)
{
   {
      obj_t aux_2427;
      {
	 object_t aux_2428;
	 aux_2428 = (object_t) (obj_100);
	 aux_2427 = OBJECT_WIDENING(aux_2428);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2427))->k) = ((obj_t) val1518_101), BUNSPEC);
   }
}


/* _sfun/iinfo-k-set!1835 */ obj_t 
_sfun_iinfo_k_set_1835_21_integrate_info(obj_t env_1989, obj_t obj_1990, obj_t val1518_1991)
{
   return sfun_iinfo_k_set__165_integrate_info((sfun_iinfo_105_t) (obj_1990), val1518_1991);
}


/* sfun/iinfo-k */ obj_t 
sfun_iinfo_k_88_integrate_info(sfun_iinfo_105_t obj_102)
{
   {
      obj_t aux_2434;
      {
	 object_t aux_2435;
	 aux_2435 = (object_t) (obj_102);
	 aux_2434 = OBJECT_WIDENING(aux_2435);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2434))->k);
   }
}


/* _sfun/iinfo-k1836 */ obj_t 
_sfun_iinfo_k1836_171_integrate_info(obj_t env_1992, obj_t obj_1993)
{
   return sfun_iinfo_k_88_integrate_info((sfun_iinfo_105_t) (obj_1993));
}


/* sfun/iinfo-k*-set! */ obj_t 
sfun_iinfo_k__set__29_integrate_info(sfun_iinfo_105_t obj_103, obj_t val1519_104)
{
   {
      obj_t aux_2441;
      {
	 object_t aux_2442;
	 aux_2442 = (object_t) (obj_103);
	 aux_2441 = OBJECT_WIDENING(aux_2442);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2441))->k__190) = ((obj_t) val1519_104), BUNSPEC);
   }
}


/* _sfun/iinfo-k*-set!1837 */ obj_t 
_sfun_iinfo_k__set_1837_3_integrate_info(obj_t env_1994, obj_t obj_1995, obj_t val1519_1996)
{
   return sfun_iinfo_k__set__29_integrate_info((sfun_iinfo_105_t) (obj_1995), val1519_1996);
}


/* sfun/iinfo-k* */ obj_t 
sfun_iinfo_k__50_integrate_info(sfun_iinfo_105_t obj_105)
{
   {
      obj_t aux_2448;
      {
	 object_t aux_2449;
	 aux_2449 = (object_t) (obj_105);
	 aux_2448 = OBJECT_WIDENING(aux_2449);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2448))->k__190);
   }
}


/* _sfun/iinfo-k*1838 */ obj_t 
_sfun_iinfo_k_1838_61_integrate_info(obj_t env_1997, obj_t obj_1998)
{
   return sfun_iinfo_k__50_integrate_info((sfun_iinfo_105_t) (obj_1998));
}


/* sfun/iinfo-u-set! */ obj_t 
sfun_iinfo_u_set__118_integrate_info(sfun_iinfo_105_t obj_106, obj_t val1520_107)
{
   {
      obj_t aux_2455;
      {
	 object_t aux_2456;
	 aux_2456 = (object_t) (obj_106);
	 aux_2455 = OBJECT_WIDENING(aux_2456);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2455))->u) = ((obj_t) val1520_107), BUNSPEC);
   }
}


/* _sfun/iinfo-u-set!1839 */ obj_t 
_sfun_iinfo_u_set_1839_196_integrate_info(obj_t env_1999, obj_t obj_2000, obj_t val1520_2001)
{
   return sfun_iinfo_u_set__118_integrate_info((sfun_iinfo_105_t) (obj_2000), val1520_2001);
}


/* sfun/iinfo-u */ obj_t 
sfun_iinfo_u_241_integrate_info(sfun_iinfo_105_t obj_108)
{
   {
      obj_t aux_2462;
      {
	 object_t aux_2463;
	 aux_2463 = (object_t) (obj_108);
	 aux_2462 = OBJECT_WIDENING(aux_2463);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2462))->u);
   }
}


/* _sfun/iinfo-u1840 */ obj_t 
_sfun_iinfo_u1840_241_integrate_info(obj_t env_2002, obj_t obj_2003)
{
   return sfun_iinfo_u_241_integrate_info((sfun_iinfo_105_t) (obj_2003));
}


/* sfun/iinfo-cn-set! */ obj_t 
sfun_iinfo_cn_set__18_integrate_info(sfun_iinfo_105_t obj_109, obj_t val1521_110)
{
   {
      obj_t aux_2469;
      {
	 object_t aux_2470;
	 aux_2470 = (object_t) (obj_109);
	 aux_2469 = OBJECT_WIDENING(aux_2470);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2469))->cn) = ((obj_t) val1521_110), BUNSPEC);
   }
}


/* _sfun/iinfo-cn-set!1841 */ obj_t 
_sfun_iinfo_cn_set_1841_101_integrate_info(obj_t env_2004, obj_t obj_2005, obj_t val1521_2006)
{
   return sfun_iinfo_cn_set__18_integrate_info((sfun_iinfo_105_t) (obj_2005), val1521_2006);
}


/* sfun/iinfo-cn */ obj_t 
sfun_iinfo_cn_214_integrate_info(sfun_iinfo_105_t obj_111)
{
   {
      obj_t aux_2476;
      {
	 object_t aux_2477;
	 aux_2477 = (object_t) (obj_111);
	 aux_2476 = OBJECT_WIDENING(aux_2477);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2476))->cn);
   }
}


/* _sfun/iinfo-cn1842 */ obj_t 
_sfun_iinfo_cn1842_18_integrate_info(obj_t env_2007, obj_t obj_2008)
{
   return sfun_iinfo_cn_214_integrate_info((sfun_iinfo_105_t) (obj_2008));
}


/* sfun/iinfo-ct-set! */ obj_t 
sfun_iinfo_ct_set__108_integrate_info(sfun_iinfo_105_t obj_112, obj_t val1522_113)
{
   {
      obj_t aux_2483;
      {
	 object_t aux_2484;
	 aux_2484 = (object_t) (obj_112);
	 aux_2483 = OBJECT_WIDENING(aux_2484);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2483))->ct) = ((obj_t) val1522_113), BUNSPEC);
   }
}


/* _sfun/iinfo-ct-set!1843 */ obj_t 
_sfun_iinfo_ct_set_1843_111_integrate_info(obj_t env_2009, obj_t obj_2010, obj_t val1522_2011)
{
   return sfun_iinfo_ct_set__108_integrate_info((sfun_iinfo_105_t) (obj_2010), val1522_2011);
}


/* sfun/iinfo-ct */ obj_t 
sfun_iinfo_ct_151_integrate_info(sfun_iinfo_105_t obj_114)
{
   {
      obj_t aux_2490;
      {
	 object_t aux_2491;
	 aux_2491 = (object_t) (obj_114);
	 aux_2490 = OBJECT_WIDENING(aux_2491);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2490))->ct);
   }
}


/* _sfun/iinfo-ct1844 */ obj_t 
_sfun_iinfo_ct1844_118_integrate_info(obj_t env_2012, obj_t obj_2013)
{
   return sfun_iinfo_ct_151_integrate_info((sfun_iinfo_105_t) (obj_2013));
}


/* sfun/iinfo-kont-set! */ obj_t 
sfun_iinfo_kont_set__215_integrate_info(sfun_iinfo_105_t obj_115, obj_t val1523_116)
{
   {
      obj_t aux_2497;
      {
	 object_t aux_2498;
	 aux_2498 = (object_t) (obj_115);
	 aux_2497 = OBJECT_WIDENING(aux_2498);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2497))->kont) = ((obj_t) val1523_116), BUNSPEC);
   }
}


/* _sfun/iinfo-kont-set!1845 */ obj_t 
_sfun_iinfo_kont_set_1845_82_integrate_info(obj_t env_2014, obj_t obj_2015, obj_t val1523_2016)
{
   return sfun_iinfo_kont_set__215_integrate_info((sfun_iinfo_105_t) (obj_2015), val1523_2016);
}


/* sfun/iinfo-kont */ obj_t 
sfun_iinfo_kont_66_integrate_info(sfun_iinfo_105_t obj_117)
{
   {
      obj_t aux_2504;
      {
	 object_t aux_2505;
	 aux_2505 = (object_t) (obj_117);
	 aux_2504 = OBJECT_WIDENING(aux_2505);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2504))->kont);
   }
}


/* _sfun/iinfo-kont1846 */ obj_t 
_sfun_iinfo_kont1846_202_integrate_info(obj_t env_2017, obj_t obj_2018)
{
   return sfun_iinfo_kont_66_integrate_info((sfun_iinfo_105_t) (obj_2018));
}


/* sfun/iinfo-g?-set! */ obj_t 
sfun_iinfo_g__set__207_integrate_info(sfun_iinfo_105_t obj_118, bool_t val1524_119)
{
   {
      obj_t aux_2511;
      {
	 object_t aux_2512;
	 aux_2512 = (object_t) (obj_118);
	 aux_2511 = OBJECT_WIDENING(aux_2512);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2511))->g__219) = ((bool_t) val1524_119), BUNSPEC);
   }
}


/* _sfun/iinfo-g?-set!1847 */ obj_t 
_sfun_iinfo_g__set_1847_16_integrate_info(obj_t env_2019, obj_t obj_2020, obj_t val1524_2021)
{
   return sfun_iinfo_g__set__207_integrate_info((sfun_iinfo_105_t) (obj_2020), CBOOL(val1524_2021));
}


/* sfun/iinfo-g? */ bool_t 
sfun_iinfo_g__46_integrate_info(sfun_iinfo_105_t obj_120)
{
   {
      obj_t aux_2519;
      {
	 object_t aux_2520;
	 aux_2520 = (object_t) (obj_120);
	 aux_2519 = OBJECT_WIDENING(aux_2520);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2519))->g__219);
   }
}


/* _sfun/iinfo-g?1848 */ obj_t 
_sfun_iinfo_g_1848_202_integrate_info(obj_t env_2022, obj_t obj_2023)
{
   {
      bool_t aux_2524;
      aux_2524 = sfun_iinfo_g__46_integrate_info((sfun_iinfo_105_t) (obj_2023));
      return BBOOL(aux_2524);
   }
}


/* sfun/iinfo-l-set! */ obj_t 
sfun_iinfo_l_set__126_integrate_info(sfun_iinfo_105_t obj_121, obj_t val1525_122)
{
   {
      obj_t aux_2528;
      {
	 object_t aux_2529;
	 aux_2529 = (object_t) (obj_121);
	 aux_2528 = OBJECT_WIDENING(aux_2529);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2528))->l) = ((obj_t) val1525_122), BUNSPEC);
   }
}


/* _sfun/iinfo-l-set!1849 */ obj_t 
_sfun_iinfo_l_set_1849_171_integrate_info(obj_t env_2024, obj_t obj_2025, obj_t val1525_2026)
{
   return sfun_iinfo_l_set__126_integrate_info((sfun_iinfo_105_t) (obj_2025), val1525_2026);
}


/* sfun/iinfo-l */ obj_t 
sfun_iinfo_l_178_integrate_info(sfun_iinfo_105_t obj_123)
{
   {
      obj_t aux_2535;
      {
	 object_t aux_2536;
	 aux_2536 = (object_t) (obj_123);
	 aux_2535 = OBJECT_WIDENING(aux_2536);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2535))->l);
   }
}


/* _sfun/iinfo-l1850 */ obj_t 
_sfun_iinfo_l1850_161_integrate_info(obj_t env_2027, obj_t obj_2028)
{
   return sfun_iinfo_l_178_integrate_info((sfun_iinfo_105_t) (obj_2028));
}


/* sfun/iinfo-led-set! */ obj_t 
sfun_iinfo_led_set__27_integrate_info(sfun_iinfo_105_t obj_124, obj_t val1526_125)
{
   {
      obj_t aux_2542;
      {
	 object_t aux_2543;
	 aux_2543 = (object_t) (obj_124);
	 aux_2542 = OBJECT_WIDENING(aux_2543);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2542))->led) = ((obj_t) val1526_125), BUNSPEC);
   }
}


/* _sfun/iinfo-led-set!1851 */ obj_t 
_sfun_iinfo_led_set_1851_183_integrate_info(obj_t env_2029, obj_t obj_2030, obj_t val1526_2031)
{
   return sfun_iinfo_led_set__27_integrate_info((sfun_iinfo_105_t) (obj_2030), val1526_2031);
}


/* sfun/iinfo-led */ obj_t 
sfun_iinfo_led_56_integrate_info(sfun_iinfo_105_t obj_126)
{
   {
      obj_t aux_2549;
      {
	 object_t aux_2550;
	 aux_2550 = (object_t) (obj_126);
	 aux_2549 = OBJECT_WIDENING(aux_2550);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2549))->led);
   }
}


/* _sfun/iinfo-led1852 */ obj_t 
_sfun_iinfo_led1852_43_integrate_info(obj_t env_2032, obj_t obj_2033)
{
   return sfun_iinfo_led_56_integrate_info((sfun_iinfo_105_t) (obj_2033));
}


/* sfun/iinfo-istamp-set! */ obj_t 
sfun_iinfo_istamp_set__89_integrate_info(sfun_iinfo_105_t obj_127, obj_t val1527_128)
{
   {
      obj_t aux_2556;
      {
	 object_t aux_2557;
	 aux_2557 = (object_t) (obj_127);
	 aux_2556 = OBJECT_WIDENING(aux_2557);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2556))->istamp) = ((obj_t) val1527_128), BUNSPEC);
   }
}


/* _sfun/iinfo-istamp-set!1853 */ obj_t 
_sfun_iinfo_istamp_set_1853_214_integrate_info(obj_t env_2034, obj_t obj_2035, obj_t val1527_2036)
{
   return sfun_iinfo_istamp_set__89_integrate_info((sfun_iinfo_105_t) (obj_2035), val1527_2036);
}


/* sfun/iinfo-istamp */ obj_t 
sfun_iinfo_istamp_147_integrate_info(sfun_iinfo_105_t obj_129)
{
   {
      obj_t aux_2563;
      {
	 object_t aux_2564;
	 aux_2564 = (object_t) (obj_129);
	 aux_2563 = OBJECT_WIDENING(aux_2564);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2563))->istamp);
   }
}


/* _sfun/iinfo-istamp1854 */ obj_t 
_sfun_iinfo_istamp1854_225_integrate_info(obj_t env_2037, obj_t obj_2038)
{
   return sfun_iinfo_istamp_147_integrate_info((sfun_iinfo_105_t) (obj_2038));
}


/* sfun/iinfo-global-set! */ obj_t 
sfun_iinfo_global_set__36_integrate_info(sfun_iinfo_105_t obj_130, obj_t val1528_131)
{
   {
      obj_t aux_2570;
      {
	 object_t aux_2571;
	 aux_2571 = (object_t) (obj_130);
	 aux_2570 = OBJECT_WIDENING(aux_2571);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2570))->global) = ((obj_t) val1528_131), BUNSPEC);
   }
}


/* _sfun/iinfo-global-set!1855 */ obj_t 
_sfun_iinfo_global_set_1855_184_integrate_info(obj_t env_2039, obj_t obj_2040, obj_t val1528_2041)
{
   return sfun_iinfo_global_set__36_integrate_info((sfun_iinfo_105_t) (obj_2040), val1528_2041);
}


/* sfun/iinfo-global */ obj_t 
sfun_iinfo_global_63_integrate_info(sfun_iinfo_105_t obj_132)
{
   {
      obj_t aux_2577;
      {
	 object_t aux_2578;
	 aux_2578 = (object_t) (obj_132);
	 aux_2577 = OBJECT_WIDENING(aux_2578);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2577))->global);
   }
}


/* _sfun/iinfo-global1856 */ obj_t 
_sfun_iinfo_global1856_163_integrate_info(obj_t env_2042, obj_t obj_2043)
{
   return sfun_iinfo_global_63_integrate_info((sfun_iinfo_105_t) (obj_2043));
}


/* sfun/iinfo-kaptured-set! */ obj_t 
sfun_iinfo_kaptured_set__173_integrate_info(sfun_iinfo_105_t obj_133, obj_t val1529_134)
{
   {
      obj_t aux_2584;
      {
	 object_t aux_2585;
	 aux_2585 = (object_t) (obj_133);
	 aux_2584 = OBJECT_WIDENING(aux_2585);
      }
      return ((((sfun_iinfo_105_t) CREF(aux_2584))->kaptured) = ((obj_t) val1529_134), BUNSPEC);
   }
}


/* _sfun/iinfo-kaptured-set!1857 */ obj_t 
_sfun_iinfo_kaptured_set_1857_94_integrate_info(obj_t env_2044, obj_t obj_2045, obj_t val1529_2046)
{
   return sfun_iinfo_kaptured_set__173_integrate_info((sfun_iinfo_105_t) (obj_2045), val1529_2046);
}


/* sfun/iinfo-kaptured */ obj_t 
sfun_iinfo_kaptured_239_integrate_info(sfun_iinfo_105_t obj_135)
{
   {
      obj_t aux_2591;
      {
	 object_t aux_2592;
	 aux_2592 = (object_t) (obj_135);
	 aux_2591 = OBJECT_WIDENING(aux_2592);
      }
      return (((sfun_iinfo_105_t) CREF(aux_2591))->kaptured);
   }
}


/* _sfun/iinfo-kaptured1858 */ obj_t 
_sfun_iinfo_kaptured1858_246_integrate_info(obj_t env_2047, obj_t obj_2048)
{
   return sfun_iinfo_kaptured_239_integrate_info((sfun_iinfo_105_t) (obj_2048));
}


/* allocate-sexit/iinfo */ sexit_t 
allocate_sexit_iinfo_139_integrate_info()
{
   {
      sexit_t new1474_923;
      new1474_923 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
      {
	 long arg1564_924;
	 arg1564_924 = class_num_218___object(sexit_iinfo_190_integrate_info);
	 {
	    obj_t obj_1502;
	    obj_1502 = (obj_t) (new1474_923);
	    (((obj_t) CREF(obj_1502))->header = MAKE_HEADER(arg1564_924, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2602;
	 aux_2602 = (object_t) (new1474_923);
	 OBJECT_WIDENING_SET(aux_2602, BFALSE);
      }
      return new1474_923;
   }
}


/* _allocate-sexit/iinfo */ obj_t 
_allocate_sexit_iinfo_189_integrate_info(obj_t env_1855)
{
   {
      sexit_t aux_2605;
      aux_2605 = allocate_sexit_iinfo_139_integrate_info();
      return (obj_t) (aux_2605);
   }
}


/* sexit/iinfo? */ bool_t 
sexit_iinfo__64_integrate_info(obj_t obj_139)
{
   return is_a__118___object(obj_139, sexit_iinfo_190_integrate_info);
}


/* _sexit/iinfo? */ obj_t 
_sexit_iinfo__65_integrate_info(obj_t env_2049, obj_t obj_2050)
{
   {
      bool_t aux_2609;
      aux_2609 = sexit_iinfo__64_integrate_info(obj_2050);
      return BBOOL(aux_2609);
   }
}


/* widening1003-sexit/iinfo */ sexit_iinfo_190_t 
widening1003_sexit_iinfo_102_integrate_info(obj_t f_mark_181_140, obj_t u_mark_209_141, bool_t kaptured__204_142, bool_t celled__113_143)
{
   {
      sexit_iinfo_190_t new1460_1504;
      new1460_1504 = ((sexit_iinfo_190_t) BREF(GC_MALLOC(sizeof(struct sexit_iinfo_190))));
      ((((sexit_iinfo_190_t) CREF(new1460_1504))->f_mark_181) = ((obj_t) f_mark_181_140), BUNSPEC);
      ((((sexit_iinfo_190_t) CREF(new1460_1504))->u_mark_209) = ((obj_t) u_mark_209_141), BUNSPEC);
      ((((sexit_iinfo_190_t) CREF(new1460_1504))->kaptured__204) = ((bool_t) kaptured__204_142), BUNSPEC);
      ((((sexit_iinfo_190_t) CREF(new1460_1504))->celled__113) = ((bool_t) celled__113_143), BUNSPEC);
      return new1460_1504;
   }
}


/* _widening1003-sexit/iinfo */ obj_t 
_widening1003_sexit_iinfo_67_integrate_info(obj_t env_2051, obj_t f_mark_181_2052, obj_t u_mark_209_2053, obj_t kaptured__204_2054, obj_t celled__113_2055)
{
   {
      sexit_iinfo_190_t aux_2617;
      aux_2617 = widening1003_sexit_iinfo_102_integrate_info(f_mark_181_2052, u_mark_209_2053, CBOOL(kaptured__204_2054), CBOOL(celled__113_2055));
      return (obj_t) (aux_2617);
   }
}


/* make-sexit/iinfo */ sexit_iinfo_190_t 
make_sexit_iinfo_29_integrate_info(obj_t handler_144, bool_t detached__120_145, obj_t f_mark_181_146, obj_t u_mark_209_147, bool_t kaptured__204_148, bool_t celled__113_149)
{
   {
      sexit_t aux1466_1509;
      {
	 sexit_t res1794_1521;
	 {
	    sexit_t new1178_1515;
	    new1178_1515 = ((sexit_t) BREF(GC_MALLOC(sizeof(struct sexit))));
	    {
	       long arg1639_1516;
	       arg1639_1516 = class_num_218___object(sexit_ast_var);
	       {
		  obj_t obj_1519;
		  obj_1519 = (obj_t) (new1178_1515);
		  (((obj_t) CREF(obj_1519))->header = MAKE_HEADER(arg1639_1516, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2626;
	       aux_2626 = (object_t) (new1178_1515);
	       OBJECT_WIDENING_SET(aux_2626, BFALSE);
	    }
	    ((((sexit_t) CREF(new1178_1515))->handler) = ((obj_t) handler_144), BUNSPEC);
	    ((((sexit_t) CREF(new1178_1515))->detached__120) = ((bool_t) detached__120_145), BUNSPEC);
	    res1794_1521 = new1178_1515;
	 }
	 aux1466_1509 = res1794_1521;
      }
      {
	 sexit_iinfo_190_t new1467_1510;
	 new1467_1510 = ((sexit_iinfo_190_t) (aux1466_1509));
	 {
	    long arg1565_1511;
	    arg1565_1511 = class_num_218___object(sexit_iinfo_190_integrate_info);
	    {
	       obj_t obj_1522;
	       obj_1522 = (obj_t) (new1467_1510);
	       (((obj_t) CREF(obj_1522))->header = MAKE_HEADER(arg1565_1511, 0), BUNSPEC);
	    }
	 }
	 {
	    sexit_iinfo_190_t arg1566_1512;
	    {
	       sexit_iinfo_190_t res1795_1533;
	       {
		  sexit_iinfo_190_t new1460_1528;
		  new1460_1528 = ((sexit_iinfo_190_t) BREF(GC_MALLOC(sizeof(struct sexit_iinfo_190))));
		  ((((sexit_iinfo_190_t) CREF(new1460_1528))->f_mark_181) = ((obj_t) f_mark_181_146), BUNSPEC);
		  ((((sexit_iinfo_190_t) CREF(new1460_1528))->u_mark_209) = ((obj_t) u_mark_209_147), BUNSPEC);
		  ((((sexit_iinfo_190_t) CREF(new1460_1528))->kaptured__204) = ((bool_t) kaptured__204_148), BUNSPEC);
		  ((((sexit_iinfo_190_t) CREF(new1460_1528))->celled__113) = ((bool_t) celled__113_149), BUNSPEC);
		  res1795_1533 = new1460_1528;
	       }
	       arg1566_1512 = res1795_1533;
	    }
	    {
	       obj_t aux_2642;
	       object_t aux_2640;
	       aux_2642 = (obj_t) (arg1566_1512);
	       aux_2640 = (object_t) (new1467_1510);
	       OBJECT_WIDENING_SET(aux_2640, aux_2642);
	    }
	 }
	 return new1467_1510;
      }
   }
}


/* _make-sexit/iinfo */ obj_t 
_make_sexit_iinfo_46_integrate_info(obj_t env_2056, obj_t handler_2057, obj_t detached__120_2058, obj_t f_mark_181_2059, obj_t u_mark_209_2060, obj_t kaptured__204_2061, obj_t celled__113_2062)
{
   {
      sexit_iinfo_190_t aux_2645;
      aux_2645 = make_sexit_iinfo_29_integrate_info(handler_2057, CBOOL(detached__120_2058), f_mark_181_2059, u_mark_209_2060, CBOOL(kaptured__204_2061), CBOOL(celled__113_2062));
      return (obj_t) (aux_2645);
   }
}


/* sexit/iinfo-handler-set! */ obj_t 
sexit_iinfo_handler_set__83_integrate_info(sexit_t obj_150, obj_t val1468_151)
{
   return ((((sexit_t) CREF(obj_150))->handler) = ((obj_t) val1468_151), BUNSPEC);
}


/* _sexit/iinfo-handler-set!1859 */ obj_t 
_sexit_iinfo_handler_set_1859_68_integrate_info(obj_t env_2063, obj_t obj_2064, obj_t val1468_2065)
{
   return sexit_iinfo_handler_set__83_integrate_info((sexit_t) (obj_2064), val1468_2065);
}


/* sexit/iinfo-handler */ obj_t 
sexit_iinfo_handler_249_integrate_info(sexit_t obj_152)
{
   return (((sexit_t) CREF(obj_152))->handler);
}


/* _sexit/iinfo-handler1860 */ obj_t 
_sexit_iinfo_handler1860_157_integrate_info(obj_t env_2066, obj_t obj_2067)
{
   return sexit_iinfo_handler_249_integrate_info((sexit_t) (obj_2067));
}


/* sexit/iinfo-detached?-set! */ obj_t 
sexit_iinfo_detached__set__74_integrate_info(sexit_t obj_153, bool_t val1469_154)
{
   return ((((sexit_t) CREF(obj_153))->detached__120) = ((bool_t) val1469_154), BUNSPEC);
}


/* _sexit/iinfo-detached?-set!1861 */ obj_t 
_sexit_iinfo_detached__set_1861_62_integrate_info(obj_t env_2068, obj_t obj_2069, obj_t val1469_2070)
{
   return sexit_iinfo_detached__set__74_integrate_info((sexit_t) (obj_2069), CBOOL(val1469_2070));
}


/* sexit/iinfo-detached? */ bool_t 
sexit_iinfo_detached__106_integrate_info(sexit_t obj_155)
{
   return (((sexit_t) CREF(obj_155))->detached__120);
}


/* _sexit/iinfo-detached?1862 */ obj_t 
_sexit_iinfo_detached_1862_181_integrate_info(obj_t env_2071, obj_t obj_2072)
{
   {
      bool_t aux_2662;
      aux_2662 = sexit_iinfo_detached__106_integrate_info((sexit_t) (obj_2072));
      return BBOOL(aux_2662);
   }
}


/* sexit/iinfo-f-mark-set! */ obj_t 
sexit_iinfo_f_mark_set__25_integrate_info(sexit_iinfo_190_t obj_156, obj_t val1470_157)
{
   {
      obj_t aux_2666;
      {
	 object_t aux_2667;
	 aux_2667 = (object_t) (obj_156);
	 aux_2666 = OBJECT_WIDENING(aux_2667);
      }
      return ((((sexit_iinfo_190_t) CREF(aux_2666))->f_mark_181) = ((obj_t) val1470_157), BUNSPEC);
   }
}


/* _sexit/iinfo-f-mark-set!1863 */ obj_t 
_sexit_iinfo_f_mark_set_1863_117_integrate_info(obj_t env_2073, obj_t obj_2074, obj_t val1470_2075)
{
   return sexit_iinfo_f_mark_set__25_integrate_info((sexit_iinfo_190_t) (obj_2074), val1470_2075);
}


/* sexit/iinfo-f-mark */ obj_t 
sexit_iinfo_f_mark_103_integrate_info(sexit_iinfo_190_t obj_158)
{
   {
      obj_t aux_2673;
      {
	 object_t aux_2674;
	 aux_2674 = (object_t) (obj_158);
	 aux_2673 = OBJECT_WIDENING(aux_2674);
      }
      return (((sexit_iinfo_190_t) CREF(aux_2673))->f_mark_181);
   }
}


/* _sexit/iinfo-f-mark1864 */ obj_t 
_sexit_iinfo_f_mark1864_138_integrate_info(obj_t env_2076, obj_t obj_2077)
{
   return sexit_iinfo_f_mark_103_integrate_info((sexit_iinfo_190_t) (obj_2077));
}


/* sexit/iinfo-u-mark-set! */ obj_t 
sexit_iinfo_u_mark_set__37_integrate_info(sexit_iinfo_190_t obj_159, obj_t val1471_160)
{
   {
      obj_t aux_2680;
      {
	 object_t aux_2681;
	 aux_2681 = (object_t) (obj_159);
	 aux_2680 = OBJECT_WIDENING(aux_2681);
      }
      return ((((sexit_iinfo_190_t) CREF(aux_2680))->u_mark_209) = ((obj_t) val1471_160), BUNSPEC);
   }
}


/* _sexit/iinfo-u-mark-set!1865 */ obj_t 
_sexit_iinfo_u_mark_set_1865_41_integrate_info(obj_t env_2078, obj_t obj_2079, obj_t val1471_2080)
{
   return sexit_iinfo_u_mark_set__37_integrate_info((sexit_iinfo_190_t) (obj_2079), val1471_2080);
}


/* sexit/iinfo-u-mark */ obj_t 
sexit_iinfo_u_mark_184_integrate_info(sexit_iinfo_190_t obj_161)
{
   {
      obj_t aux_2687;
      {
	 object_t aux_2688;
	 aux_2688 = (object_t) (obj_161);
	 aux_2687 = OBJECT_WIDENING(aux_2688);
      }
      return (((sexit_iinfo_190_t) CREF(aux_2687))->u_mark_209);
   }
}


/* _sexit/iinfo-u-mark1866 */ obj_t 
_sexit_iinfo_u_mark1866_228_integrate_info(obj_t env_2081, obj_t obj_2082)
{
   return sexit_iinfo_u_mark_184_integrate_info((sexit_iinfo_190_t) (obj_2082));
}


/* sexit/iinfo-kaptured?-set! */ obj_t 
sexit_iinfo_kaptured__set__138_integrate_info(sexit_iinfo_190_t obj_162, bool_t val1472_163)
{
   {
      obj_t aux_2694;
      {
	 object_t aux_2695;
	 aux_2695 = (object_t) (obj_162);
	 aux_2694 = OBJECT_WIDENING(aux_2695);
      }
      return ((((sexit_iinfo_190_t) CREF(aux_2694))->kaptured__204) = ((bool_t) val1472_163), BUNSPEC);
   }
}


/* _sexit/iinfo-kaptured?-set!1867 */ obj_t 
_sexit_iinfo_kaptured__set_1867_250_integrate_info(obj_t env_2083, obj_t obj_2084, obj_t val1472_2085)
{
   return sexit_iinfo_kaptured__set__138_integrate_info((sexit_iinfo_190_t) (obj_2084), CBOOL(val1472_2085));
}


/* sexit/iinfo-kaptured? */ bool_t 
sexit_iinfo_kaptured__6_integrate_info(sexit_iinfo_190_t obj_164)
{
   {
      obj_t aux_2702;
      {
	 object_t aux_2703;
	 aux_2703 = (object_t) (obj_164);
	 aux_2702 = OBJECT_WIDENING(aux_2703);
      }
      return (((sexit_iinfo_190_t) CREF(aux_2702))->kaptured__204);
   }
}


/* _sexit/iinfo-kaptured?1868 */ obj_t 
_sexit_iinfo_kaptured_1868_228_integrate_info(obj_t env_2086, obj_t obj_2087)
{
   {
      bool_t aux_2707;
      aux_2707 = sexit_iinfo_kaptured__6_integrate_info((sexit_iinfo_190_t) (obj_2087));
      return BBOOL(aux_2707);
   }
}


/* sexit/iinfo-celled?-set! */ obj_t 
sexit_iinfo_celled__set__58_integrate_info(sexit_iinfo_190_t obj_165, bool_t val1473_166)
{
   {
      obj_t aux_2711;
      {
	 object_t aux_2712;
	 aux_2712 = (object_t) (obj_165);
	 aux_2711 = OBJECT_WIDENING(aux_2712);
      }
      return ((((sexit_iinfo_190_t) CREF(aux_2711))->celled__113) = ((bool_t) val1473_166), BUNSPEC);
   }
}


/* _sexit/iinfo-celled?-set!1869 */ obj_t 
_sexit_iinfo_celled__set_1869_152_integrate_info(obj_t env_2088, obj_t obj_2089, obj_t val1473_2090)
{
   return sexit_iinfo_celled__set__58_integrate_info((sexit_iinfo_190_t) (obj_2089), CBOOL(val1473_2090));
}


/* sexit/iinfo-celled? */ bool_t 
sexit_iinfo_celled__92_integrate_info(sexit_iinfo_190_t obj_167)
{
   {
      obj_t aux_2719;
      {
	 object_t aux_2720;
	 aux_2720 = (object_t) (obj_167);
	 aux_2719 = OBJECT_WIDENING(aux_2720);
      }
      return (((sexit_iinfo_190_t) CREF(aux_2719))->celled__113);
   }
}


/* _sexit/iinfo-celled?1870 */ obj_t 
_sexit_iinfo_celled_1870_59_integrate_info(obj_t env_2091, obj_t obj_2092)
{
   {
      bool_t aux_2724;
      aux_2724 = sexit_iinfo_celled__92_integrate_info((sexit_iinfo_190_t) (obj_2092));
      return BBOOL(aux_2724);
   }
}


/* allocate-svar/iinfo */ svar_t 
allocate_svar_iinfo_15_integrate_info()
{
   {
      svar_t new1451_934;
      new1451_934 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
      {
	 long arg1568_935;
	 arg1568_935 = class_num_218___object(svar_iinfo_76_integrate_info);
	 {
	    obj_t obj_1534;
	    obj_1534 = (obj_t) (new1451_934);
	    (((obj_t) CREF(obj_1534))->header = MAKE_HEADER(arg1568_935, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2732;
	 aux_2732 = (object_t) (new1451_934);
	 OBJECT_WIDENING_SET(aux_2732, BFALSE);
      }
      return new1451_934;
   }
}


/* _allocate-svar/iinfo */ obj_t 
_allocate_svar_iinfo_246_integrate_info(obj_t env_1854)
{
   {
      svar_t aux_2735;
      aux_2735 = allocate_svar_iinfo_15_integrate_info();
      return (obj_t) (aux_2735);
   }
}


/* svar/iinfo? */ bool_t 
svar_iinfo__34_integrate_info(obj_t obj_171)
{
   return is_a__118___object(obj_171, svar_iinfo_76_integrate_info);
}


/* _svar/iinfo? */ obj_t 
_svar_iinfo__104_integrate_info(obj_t env_2093, obj_t obj_2094)
{
   {
      bool_t aux_2739;
      aux_2739 = svar_iinfo__34_integrate_info(obj_2094);
      return BBOOL(aux_2739);
   }
}


/* widening1002-svar/iinfo */ svar_iinfo_76_t 
widening1002_svar_iinfo_19_integrate_info(obj_t f_mark_181_172, obj_t u_mark_209_173, bool_t kaptured__204_174, bool_t celled__113_175)
{
   {
      svar_iinfo_76_t new1438_1536;
      new1438_1536 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
      ((((svar_iinfo_76_t) CREF(new1438_1536))->f_mark_181) = ((obj_t) f_mark_181_172), BUNSPEC);
      ((((svar_iinfo_76_t) CREF(new1438_1536))->u_mark_209) = ((obj_t) u_mark_209_173), BUNSPEC);
      ((((svar_iinfo_76_t) CREF(new1438_1536))->kaptured__204) = ((bool_t) kaptured__204_174), BUNSPEC);
      ((((svar_iinfo_76_t) CREF(new1438_1536))->celled__113) = ((bool_t) celled__113_175), BUNSPEC);
      return new1438_1536;
   }
}


/* _widening1002-svar/iinfo */ obj_t 
_widening1002_svar_iinfo_40_integrate_info(obj_t env_2095, obj_t f_mark_181_2096, obj_t u_mark_209_2097, obj_t kaptured__204_2098, obj_t celled__113_2099)
{
   {
      svar_iinfo_76_t aux_2747;
      aux_2747 = widening1002_svar_iinfo_19_integrate_info(f_mark_181_2096, u_mark_209_2097, CBOOL(kaptured__204_2098), CBOOL(celled__113_2099));
      return (obj_t) (aux_2747);
   }
}


/* make-svar/iinfo */ svar_iinfo_76_t 
make_svar_iinfo_142_integrate_info(obj_t loc_176, obj_t f_mark_181_177, obj_t u_mark_209_178, bool_t kaptured__204_179, bool_t celled__113_180)
{
   {
      svar_t aux1444_1541;
      {
	 svar_t res1796_1551;
	 {
	    svar_t new1161_1546;
	    new1161_1546 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
	    {
	       long arg1648_1547;
	       arg1648_1547 = class_num_218___object(svar_ast_var);
	       {
		  obj_t obj_1549;
		  obj_1549 = (obj_t) (new1161_1546);
		  (((obj_t) CREF(obj_1549))->header = MAKE_HEADER(arg1648_1547, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_2756;
	       aux_2756 = (object_t) (new1161_1546);
	       OBJECT_WIDENING_SET(aux_2756, BFALSE);
	    }
	    ((((svar_t) CREF(new1161_1546))->loc) = ((obj_t) loc_176), BUNSPEC);
	    res1796_1551 = new1161_1546;
	 }
	 aux1444_1541 = res1796_1551;
      }
      {
	 svar_iinfo_76_t new1445_1542;
	 new1445_1542 = ((svar_iinfo_76_t) (aux1444_1541));
	 {
	    long arg1569_1543;
	    arg1569_1543 = class_num_218___object(svar_iinfo_76_integrate_info);
	    {
	       obj_t obj_1552;
	       obj_1552 = (obj_t) (new1445_1542);
	       (((obj_t) CREF(obj_1552))->header = MAKE_HEADER(arg1569_1543, 0), BUNSPEC);
	    }
	 }
	 {
	    svar_iinfo_76_t arg1570_1544;
	    {
	       svar_iinfo_76_t res1797_1563;
	       {
		  svar_iinfo_76_t new1438_1558;
		  new1438_1558 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
		  ((((svar_iinfo_76_t) CREF(new1438_1558))->f_mark_181) = ((obj_t) f_mark_181_177), BUNSPEC);
		  ((((svar_iinfo_76_t) CREF(new1438_1558))->u_mark_209) = ((obj_t) u_mark_209_178), BUNSPEC);
		  ((((svar_iinfo_76_t) CREF(new1438_1558))->kaptured__204) = ((bool_t) kaptured__204_179), BUNSPEC);
		  ((((svar_iinfo_76_t) CREF(new1438_1558))->celled__113) = ((bool_t) celled__113_180), BUNSPEC);
		  res1797_1563 = new1438_1558;
	       }
	       arg1570_1544 = res1797_1563;
	    }
	    {
	       obj_t aux_2771;
	       object_t aux_2769;
	       aux_2771 = (obj_t) (arg1570_1544);
	       aux_2769 = (object_t) (new1445_1542);
	       OBJECT_WIDENING_SET(aux_2769, aux_2771);
	    }
	 }
	 return new1445_1542;
      }
   }
}


/* _make-svar/iinfo */ obj_t 
_make_svar_iinfo_96_integrate_info(obj_t env_2100, obj_t loc_2101, obj_t f_mark_181_2102, obj_t u_mark_209_2103, obj_t kaptured__204_2104, obj_t celled__113_2105)
{
   {
      svar_iinfo_76_t aux_2774;
      aux_2774 = make_svar_iinfo_142_integrate_info(loc_2101, f_mark_181_2102, u_mark_209_2103, CBOOL(kaptured__204_2104), CBOOL(celled__113_2105));
      return (obj_t) (aux_2774);
   }
}


/* svar/iinfo-loc-set! */ obj_t 
svar_iinfo_loc_set__64_integrate_info(svar_t obj_181, obj_t val1446_182)
{
   return ((((svar_t) CREF(obj_181))->loc) = ((obj_t) val1446_182), BUNSPEC);
}


/* _svar/iinfo-loc-set!1871 */ obj_t 
_svar_iinfo_loc_set_1871_21_integrate_info(obj_t env_2106, obj_t obj_2107, obj_t val1446_2108)
{
   return svar_iinfo_loc_set__64_integrate_info((svar_t) (obj_2107), val1446_2108);
}


/* svar/iinfo-loc */ obj_t 
svar_iinfo_loc_108_integrate_info(svar_t obj_183)
{
   return (((svar_t) CREF(obj_183))->loc);
}


/* _svar/iinfo-loc1872 */ obj_t 
_svar_iinfo_loc1872_189_integrate_info(obj_t env_2109, obj_t obj_2110)
{
   return svar_iinfo_loc_108_integrate_info((svar_t) (obj_2110));
}


/* svar/iinfo-f-mark-set! */ obj_t 
svar_iinfo_f_mark_set__34_integrate_info(svar_iinfo_76_t obj_184, obj_t val1447_185)
{
   {
      obj_t aux_2785;
      {
	 object_t aux_2786;
	 aux_2786 = (object_t) (obj_184);
	 aux_2785 = OBJECT_WIDENING(aux_2786);
      }
      return ((((svar_iinfo_76_t) CREF(aux_2785))->f_mark_181) = ((obj_t) val1447_185), BUNSPEC);
   }
}


/* _svar/iinfo-f-mark-set!1873 */ obj_t 
_svar_iinfo_f_mark_set_1873_65_integrate_info(obj_t env_2111, obj_t obj_2112, obj_t val1447_2113)
{
   return svar_iinfo_f_mark_set__34_integrate_info((svar_iinfo_76_t) (obj_2112), val1447_2113);
}


/* svar/iinfo-f-mark */ obj_t 
svar_iinfo_f_mark_86_integrate_info(svar_iinfo_76_t obj_186)
{
   {
      obj_t aux_2792;
      {
	 object_t aux_2793;
	 aux_2793 = (object_t) (obj_186);
	 aux_2792 = OBJECT_WIDENING(aux_2793);
      }
      return (((svar_iinfo_76_t) CREF(aux_2792))->f_mark_181);
   }
}


/* _svar/iinfo-f-mark1874 */ obj_t 
_svar_iinfo_f_mark1874_4_integrate_info(obj_t env_2114, obj_t obj_2115)
{
   return svar_iinfo_f_mark_86_integrate_info((svar_iinfo_76_t) (obj_2115));
}


/* svar/iinfo-u-mark-set! */ obj_t 
svar_iinfo_u_mark_set__220_integrate_info(svar_iinfo_76_t obj_187, obj_t val1448_188)
{
   {
      obj_t aux_2799;
      {
	 object_t aux_2800;
	 aux_2800 = (object_t) (obj_187);
	 aux_2799 = OBJECT_WIDENING(aux_2800);
      }
      return ((((svar_iinfo_76_t) CREF(aux_2799))->u_mark_209) = ((obj_t) val1448_188), BUNSPEC);
   }
}


/* _svar/iinfo-u-mark-set!1875 */ obj_t 
_svar_iinfo_u_mark_set_1875_106_integrate_info(obj_t env_2116, obj_t obj_2117, obj_t val1448_2118)
{
   return svar_iinfo_u_mark_set__220_integrate_info((svar_iinfo_76_t) (obj_2117), val1448_2118);
}


/* svar/iinfo-u-mark */ obj_t 
svar_iinfo_u_mark_255_integrate_info(svar_iinfo_76_t obj_189)
{
   {
      obj_t aux_2806;
      {
	 object_t aux_2807;
	 aux_2807 = (object_t) (obj_189);
	 aux_2806 = OBJECT_WIDENING(aux_2807);
      }
      return (((svar_iinfo_76_t) CREF(aux_2806))->u_mark_209);
   }
}


/* _svar/iinfo-u-mark1876 */ obj_t 
_svar_iinfo_u_mark1876_186_integrate_info(obj_t env_2119, obj_t obj_2120)
{
   return svar_iinfo_u_mark_255_integrate_info((svar_iinfo_76_t) (obj_2120));
}


/* svar/iinfo-kaptured?-set! */ obj_t 
svar_iinfo_kaptured__set__147_integrate_info(svar_iinfo_76_t obj_190, bool_t val1449_191)
{
   {
      obj_t aux_2813;
      {
	 object_t aux_2814;
	 aux_2814 = (object_t) (obj_190);
	 aux_2813 = OBJECT_WIDENING(aux_2814);
      }
      return ((((svar_iinfo_76_t) CREF(aux_2813))->kaptured__204) = ((bool_t) val1449_191), BUNSPEC);
   }
}


/* _svar/iinfo-kaptured?-set!1877 */ obj_t 
_svar_iinfo_kaptured__set_1877_134_integrate_info(obj_t env_2121, obj_t obj_2122, obj_t val1449_2123)
{
   return svar_iinfo_kaptured__set__147_integrate_info((svar_iinfo_76_t) (obj_2122), CBOOL(val1449_2123));
}


/* svar/iinfo-kaptured? */ bool_t 
svar_iinfo_kaptured__141_integrate_info(svar_iinfo_76_t obj_192)
{
   {
      obj_t aux_2821;
      {
	 object_t aux_2822;
	 aux_2822 = (object_t) (obj_192);
	 aux_2821 = OBJECT_WIDENING(aux_2822);
      }
      return (((svar_iinfo_76_t) CREF(aux_2821))->kaptured__204);
   }
}


/* _svar/iinfo-kaptured?1878 */ obj_t 
_svar_iinfo_kaptured_1878_59_integrate_info(obj_t env_2124, obj_t obj_2125)
{
   {
      bool_t aux_2826;
      aux_2826 = svar_iinfo_kaptured__141_integrate_info((svar_iinfo_76_t) (obj_2125));
      return BBOOL(aux_2826);
   }
}


/* svar/iinfo-celled?-set! */ obj_t 
svar_iinfo_celled__set__209_integrate_info(svar_iinfo_76_t obj_193, bool_t val1450_194)
{
   {
      obj_t aux_2830;
      {
	 object_t aux_2831;
	 aux_2831 = (object_t) (obj_193);
	 aux_2830 = OBJECT_WIDENING(aux_2831);
      }
      return ((((svar_iinfo_76_t) CREF(aux_2830))->celled__113) = ((bool_t) val1450_194), BUNSPEC);
   }
}


/* _svar/iinfo-celled?-set!1879 */ obj_t 
_svar_iinfo_celled__set_1879_24_integrate_info(obj_t env_2126, obj_t obj_2127, obj_t val1450_2128)
{
   return svar_iinfo_celled__set__209_integrate_info((svar_iinfo_76_t) (obj_2127), CBOOL(val1450_2128));
}


/* svar/iinfo-celled? */ bool_t 
svar_iinfo_celled__54_integrate_info(svar_iinfo_76_t obj_195)
{
   {
      obj_t aux_2838;
      {
	 object_t aux_2839;
	 aux_2839 = (object_t) (obj_195);
	 aux_2838 = OBJECT_WIDENING(aux_2839);
      }
      return (((svar_iinfo_76_t) CREF(aux_2838))->celled__113);
   }
}


/* _svar/iinfo-celled?1880 */ obj_t 
_svar_iinfo_celled_1880_157_integrate_info(obj_t env_2129, obj_t obj_2130)
{
   {
      bool_t aux_2843;
      aux_2843 = svar_iinfo_celled__54_integrate_info((svar_iinfo_76_t) (obj_2130));
      return BBOOL(aux_2843);
   }
}


/* method-init */ obj_t 
method_init_76_integrate_info()
{
   {
      obj_t object__struct_sfun_iinfo_106_2141;
      object__struct_sfun_iinfo_106_2141 = proc1886_integrate_info;
      add_method__1___object(object__struct_env_210___object, sfun_iinfo_105_integrate_info, object__struct_sfun_iinfo_106_2141);
   }
   {
      obj_t struct_object__object_sfun_iinfo_5_2140;
      struct_object__object_sfun_iinfo_5_2140 = proc1887_integrate_info;
      add_method__1___object(struct_object__object_env_209___object, sfun_iinfo_105_integrate_info, struct_object__object_sfun_iinfo_5_2140);
   }
   {
      obj_t object__struct_sexit_iinfo_21_2139;
      object__struct_sexit_iinfo_21_2139 = proc1888_integrate_info;
      add_method__1___object(object__struct_env_210___object, sexit_iinfo_190_integrate_info, object__struct_sexit_iinfo_21_2139);
   }
   {
      obj_t struct_object__object_sexit_iinfo_149_2138;
      struct_object__object_sexit_iinfo_149_2138 = proc1889_integrate_info;
      add_method__1___object(struct_object__object_env_209___object, sexit_iinfo_190_integrate_info, struct_object__object_sexit_iinfo_149_2138);
   }
   {
      obj_t object__struct_svar_iinfo_184_2135;
      object__struct_svar_iinfo_184_2135 = proc1890_integrate_info;
      add_method__1___object(object__struct_env_210___object, svar_iinfo_76_integrate_info, object__struct_svar_iinfo_184_2135);
   }
   {
      obj_t struct_object__object_svar_iinfo_213_2131;
      struct_object__object_svar_iinfo_213_2131 = proc1891_integrate_info;
      return add_method__1___object(struct_object__object_env_209___object, svar_iinfo_76_integrate_info, struct_object__object_svar_iinfo_213_2131);
   }
}


/* struct+object->object-svar/iinfo */ obj_t 
struct_object__object_svar_iinfo_213_integrate_info(obj_t env_2142, obj_t o_2143, obj_t s_2144)
{
   {
      svar_iinfo_76_t o_1396;
      obj_t s_1397;
      {
	 svar_iinfo_76_t aux_2853;
	 o_1396 = (svar_iinfo_76_t) (o_2143);
	 s_1397 = s_2144;
	 {
	    {
	       obj_t old1457_1400;
	       obj_t aux1458_1401;
	       {
		  obj_t next_method1546_155_1409;
		  next_method1546_155_1409 = find_super_class_method_167___object((object_t) (o_1396), struct_object__object_env_209___object, svar_iinfo_76_integrate_info);
		  if (PROCEDUREP(next_method1546_155_1409))
		    {
		       old1457_1400 = PROCEDURE_ENTRY(next_method1546_155_1409) (next_method1546_155_1409, (obj_t) (o_1396), s_1397, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1546_155_1409);
		       {
			  object_t aux_2862;
			  aux_2862 = struct_object__object_93___object((object_t) (o_1396), s_1397);
			  old1457_1400 = (obj_t) (aux_2862);
		       }
		    }
	       }
	       aux1458_1401 = STRUCT_REF(s_1397, ((long) 0));
	       {
		  svar_iinfo_76_t new1459_1402;
		  new1459_1402 = ((svar_iinfo_76_t) (old1457_1400));
		  {
		     long arg1781_1403;
		     arg1781_1403 = class_num_218___object(svar_iinfo_76_integrate_info);
		     {
			obj_t obj_1832;
			obj_1832 = (obj_t) (new1459_1402);
			(((obj_t) CREF(obj_1832))->header = MAKE_HEADER(arg1781_1403, 0), BUNSPEC);
		     }
		  }
		  {
		     svar_iinfo_76_t arg1783_1404;
		     {
			obj_t arg1786_1405;
			obj_t arg1788_1406;
			arg1786_1405 = STRUCT_REF(aux1458_1401, ((long) 0));
			arg1788_1406 = STRUCT_REF(aux1458_1401, ((long) 1));
			{
			   svar_iinfo_76_t res1800_1851;
			   {
			      bool_t kaptured__204_1844;
			      bool_t celled__113_1845;
			      {
				 obj_t aux_2873;
				 aux_2873 = STRUCT_REF(aux1458_1401, ((long) 2));
				 kaptured__204_1844 = CBOOL(aux_2873);
			      }
			      {
				 obj_t aux_2876;
				 aux_2876 = STRUCT_REF(aux1458_1401, ((long) 3));
				 celled__113_1845 = CBOOL(aux_2876);
			      }
			      {
				 svar_iinfo_76_t new1438_1846;
				 new1438_1846 = ((svar_iinfo_76_t) BREF(GC_MALLOC(sizeof(struct svar_iinfo_76))));
				 ((((svar_iinfo_76_t) CREF(new1438_1846))->f_mark_181) = ((obj_t) arg1786_1405), BUNSPEC);
				 ((((svar_iinfo_76_t) CREF(new1438_1846))->u_mark_209) = ((obj_t) arg1788_1406), BUNSPEC);
				 ((((svar_iinfo_76_t) CREF(new1438_1846))->kaptured__204) = ((bool_t) kaptured__204_1844), BUNSPEC);
				 ((((svar_iinfo_76_t) CREF(new1438_1846))->celled__113) = ((bool_t) celled__113_1845), BUNSPEC);
				 res1800_1851 = new1438_1846;
			      }
			   }
			   arg1783_1404 = res1800_1851;
			}
		     }
		     {
			obj_t aux_2886;
			object_t aux_2884;
			aux_2886 = (obj_t) (arg1783_1404);
			aux_2884 = (object_t) (new1459_1402);
			OBJECT_WIDENING_SET(aux_2884, aux_2886);
		     }
		  }
		  aux_2853 = new1459_1402;
	       }
	    }
	 }
	 return (obj_t) (aux_2853);
      }
   }
}


/* object->struct-svar/iinfo */ obj_t 
object__struct_svar_iinfo_184_integrate_info(obj_t env_2145, obj_t obj1454_2146)
{
   {
      svar_iinfo_76_t obj1454_1377;
      obj1454_1377 = (svar_iinfo_76_t) (obj1454_2146);
      {
	 {
	    obj_t res1455_1380;
	    {
	       obj_t next_method1545_159_1394;
	       next_method1545_159_1394 = find_super_class_method_167___object((object_t) (obj1454_1377), object__struct_env_210___object, svar_iinfo_76_integrate_info);
	       if (PROCEDUREP(next_method1545_159_1394))
		 {
		    res1455_1380 = PROCEDURE_ENTRY(next_method1545_159_1394) (next_method1545_159_1394, (obj_t) (obj1454_1377), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1545_159_1394);
		    res1455_1380 = object__struct_50___object((object_t) (obj1454_1377));
		 }
	    }
	    {
	       obj_t aux1456_1381;
	       {
		  obj_t aux_2901;
		  aux_2901 = CNST_TABLE_REF(((long) 0));
		  aux1456_1381 = make_struct(aux_2901, ((long) 4), BUNSPEC);
	       }
	       {
		  obj_t aux_2904;
		  {
		     obj_t aux_2905;
		     {
			object_t aux_2906;
			aux_2906 = (object_t) (obj1454_1377);
			aux_2905 = OBJECT_WIDENING(aux_2906);
		     }
		     aux_2904 = (((svar_iinfo_76_t) CREF(aux_2905))->f_mark_181);
		  }
		  STRUCT_SET(aux1456_1381, ((long) 0), aux_2904);
	       }
	       {
		  obj_t aux_2911;
		  {
		     obj_t aux_2912;
		     {
			object_t aux_2913;
			aux_2913 = (object_t) (obj1454_1377);
			aux_2912 = OBJECT_WIDENING(aux_2913);
		     }
		     aux_2911 = (((svar_iinfo_76_t) CREF(aux_2912))->u_mark_209);
		  }
		  STRUCT_SET(aux1456_1381, ((long) 1), aux_2911);
	       }
	       {
		  obj_t aux_2918;
		  {
		     bool_t aux_2919;
		     {
			obj_t aux_2920;
			{
			   object_t aux_2921;
			   aux_2921 = (object_t) (obj1454_1377);
			   aux_2920 = OBJECT_WIDENING(aux_2921);
			}
			aux_2919 = (((svar_iinfo_76_t) CREF(aux_2920))->kaptured__204);
		     }
		     aux_2918 = BBOOL(aux_2919);
		  }
		  STRUCT_SET(aux1456_1381, ((long) 2), aux_2918);
	       }
	       {
		  obj_t aux_2927;
		  {
		     bool_t aux_2928;
		     {
			obj_t aux_2929;
			{
			   object_t aux_2930;
			   aux_2930 = (object_t) (obj1454_1377);
			   aux_2929 = OBJECT_WIDENING(aux_2930);
			}
			aux_2928 = (((svar_iinfo_76_t) CREF(aux_2929))->celled__113);
		     }
		     aux_2927 = BBOOL(aux_2928);
		  }
		  STRUCT_SET(aux1456_1381, ((long) 3), aux_2927);
	       }
	       STRUCT_SET(res1455_1380, ((long) 0), aux1456_1381);
	       {
		  obj_t aux_2937;
		  aux_2937 = STRUCT_KEY(res1455_1380);
		  STRUCT_KEY_SET(aux1456_1381, aux_2937);
	       }
	       {
		  obj_t aux_2940;
		  aux_2940 = CNST_TABLE_REF(((long) 0));
		  STRUCT_KEY_SET(res1455_1380, aux_2940);
	       }
	       return res1455_1380;
	    }
	 }
      }
   }
}


/* struct+object->object-sexit/iinfo */ obj_t 
struct_object__object_sexit_iinfo_149_integrate_info(obj_t env_2147, obj_t o_2148, obj_t s_2149)
{
   {
      sexit_iinfo_190_t o_1362;
      obj_t s_1363;
      {
	 sexit_iinfo_190_t aux_2944;
	 o_1362 = (sexit_iinfo_190_t) (o_2148);
	 s_1363 = s_2149;
	 {
	    {
	       obj_t old1478_1366;
	       obj_t aux1479_1367;
	       {
		  obj_t next_method1544_93_1375;
		  next_method1544_93_1375 = find_super_class_method_167___object((object_t) (o_1362), struct_object__object_env_209___object, sexit_iinfo_190_integrate_info);
		  if (PROCEDUREP(next_method1544_93_1375))
		    {
		       old1478_1366 = PROCEDURE_ENTRY(next_method1544_93_1375) (next_method1544_93_1375, (obj_t) (o_1362), s_1363, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1544_93_1375);
		       {
			  object_t aux_2953;
			  aux_2953 = struct_object__object_93___object((object_t) (o_1362), s_1363);
			  old1478_1366 = (obj_t) (aux_2953);
		       }
		    }
	       }
	       aux1479_1367 = STRUCT_REF(s_1363, ((long) 0));
	       {
		  sexit_iinfo_190_t new1480_1368;
		  new1480_1368 = ((sexit_iinfo_190_t) (old1478_1366));
		  {
		     long arg1758_1369;
		     arg1758_1369 = class_num_218___object(sexit_iinfo_190_integrate_info);
		     {
			obj_t obj_1779;
			obj_1779 = (obj_t) (new1480_1368);
			(((obj_t) CREF(obj_1779))->header = MAKE_HEADER(arg1758_1369, 0), BUNSPEC);
		     }
		  }
		  {
		     sexit_iinfo_190_t arg1759_1370;
		     {
			obj_t arg1760_1371;
			obj_t arg1761_1372;
			arg1760_1371 = STRUCT_REF(aux1479_1367, ((long) 0));
			arg1761_1372 = STRUCT_REF(aux1479_1367, ((long) 1));
			{
			   sexit_iinfo_190_t res1799_1798;
			   {
			      bool_t kaptured__204_1791;
			      bool_t celled__113_1792;
			      {
				 obj_t aux_2964;
				 aux_2964 = STRUCT_REF(aux1479_1367, ((long) 2));
				 kaptured__204_1791 = CBOOL(aux_2964);
			      }
			      {
				 obj_t aux_2967;
				 aux_2967 = STRUCT_REF(aux1479_1367, ((long) 3));
				 celled__113_1792 = CBOOL(aux_2967);
			      }
			      {
				 sexit_iinfo_190_t new1460_1793;
				 new1460_1793 = ((sexit_iinfo_190_t) BREF(GC_MALLOC(sizeof(struct sexit_iinfo_190))));
				 ((((sexit_iinfo_190_t) CREF(new1460_1793))->f_mark_181) = ((obj_t) arg1760_1371), BUNSPEC);
				 ((((sexit_iinfo_190_t) CREF(new1460_1793))->u_mark_209) = ((obj_t) arg1761_1372), BUNSPEC);
				 ((((sexit_iinfo_190_t) CREF(new1460_1793))->kaptured__204) = ((bool_t) kaptured__204_1791), BUNSPEC);
				 ((((sexit_iinfo_190_t) CREF(new1460_1793))->celled__113) = ((bool_t) celled__113_1792), BUNSPEC);
				 res1799_1798 = new1460_1793;
			      }
			   }
			   arg1759_1370 = res1799_1798;
			}
		     }
		     {
			obj_t aux_2977;
			object_t aux_2975;
			aux_2977 = (obj_t) (arg1759_1370);
			aux_2975 = (object_t) (new1480_1368);
			OBJECT_WIDENING_SET(aux_2975, aux_2977);
		     }
		  }
		  aux_2944 = new1480_1368;
	       }
	    }
	 }
	 return (obj_t) (aux_2944);
      }
   }
}


/* object->struct-sexit/iinfo */ obj_t 
object__struct_sexit_iinfo_21_integrate_info(obj_t env_2150, obj_t obj1475_2151)
{
   {
      sexit_iinfo_190_t obj1475_1343;
      obj1475_1343 = (sexit_iinfo_190_t) (obj1475_2151);
      {
	 {
	    obj_t res1476_1346;
	    {
	       obj_t next_method1543_61_1360;
	       next_method1543_61_1360 = find_super_class_method_167___object((object_t) (obj1475_1343), object__struct_env_210___object, sexit_iinfo_190_integrate_info);
	       if (PROCEDUREP(next_method1543_61_1360))
		 {
		    res1476_1346 = PROCEDURE_ENTRY(next_method1543_61_1360) (next_method1543_61_1360, (obj_t) (obj1475_1343), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1543_61_1360);
		    res1476_1346 = object__struct_50___object((object_t) (obj1475_1343));
		 }
	    }
	    {
	       obj_t aux1477_1347;
	       {
		  obj_t aux_2992;
		  aux_2992 = CNST_TABLE_REF(((long) 1));
		  aux1477_1347 = make_struct(aux_2992, ((long) 4), BUNSPEC);
	       }
	       {
		  obj_t aux_2995;
		  {
		     obj_t aux_2996;
		     {
			object_t aux_2997;
			aux_2997 = (object_t) (obj1475_1343);
			aux_2996 = OBJECT_WIDENING(aux_2997);
		     }
		     aux_2995 = (((sexit_iinfo_190_t) CREF(aux_2996))->f_mark_181);
		  }
		  STRUCT_SET(aux1477_1347, ((long) 0), aux_2995);
	       }
	       {
		  obj_t aux_3002;
		  {
		     obj_t aux_3003;
		     {
			object_t aux_3004;
			aux_3004 = (object_t) (obj1475_1343);
			aux_3003 = OBJECT_WIDENING(aux_3004);
		     }
		     aux_3002 = (((sexit_iinfo_190_t) CREF(aux_3003))->u_mark_209);
		  }
		  STRUCT_SET(aux1477_1347, ((long) 1), aux_3002);
	       }
	       {
		  obj_t aux_3009;
		  {
		     bool_t aux_3010;
		     {
			obj_t aux_3011;
			{
			   object_t aux_3012;
			   aux_3012 = (object_t) (obj1475_1343);
			   aux_3011 = OBJECT_WIDENING(aux_3012);
			}
			aux_3010 = (((sexit_iinfo_190_t) CREF(aux_3011))->kaptured__204);
		     }
		     aux_3009 = BBOOL(aux_3010);
		  }
		  STRUCT_SET(aux1477_1347, ((long) 2), aux_3009);
	       }
	       {
		  obj_t aux_3018;
		  {
		     bool_t aux_3019;
		     {
			obj_t aux_3020;
			{
			   object_t aux_3021;
			   aux_3021 = (object_t) (obj1475_1343);
			   aux_3020 = OBJECT_WIDENING(aux_3021);
			}
			aux_3019 = (((sexit_iinfo_190_t) CREF(aux_3020))->celled__113);
		     }
		     aux_3018 = BBOOL(aux_3019);
		  }
		  STRUCT_SET(aux1477_1347, ((long) 3), aux_3018);
	       }
	       STRUCT_SET(res1476_1346, ((long) 0), aux1477_1347);
	       {
		  obj_t aux_3028;
		  aux_3028 = STRUCT_KEY(res1476_1346);
		  STRUCT_KEY_SET(aux1477_1347, aux_3028);
	       }
	       {
		  obj_t aux_3031;
		  aux_3031 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1476_1346, aux_3031);
	       }
	       return res1476_1346;
	    }
	 }
      }
   }
}


/* struct+object->object-sfun/iinfo */ obj_t 
struct_object__object_sfun_iinfo_5_integrate_info(obj_t env_2152, obj_t o_2153, obj_t s_2154)
{
   {
      sfun_iinfo_105_t o_1315;
      obj_t s_1316;
      {
	 sfun_iinfo_105_t aux_3035;
	 o_1315 = (sfun_iinfo_105_t) (o_2153);
	 s_1316 = s_2154;
	 {
	    {
	       obj_t old1534_1319;
	       obj_t aux1535_1320;
	       {
		  obj_t next_method1542_3_1341;
		  next_method1542_3_1341 = find_super_class_method_167___object((object_t) (o_1315), struct_object__object_env_209___object, sfun_iinfo_105_integrate_info);
		  if (PROCEDUREP(next_method1542_3_1341))
		    {
		       old1534_1319 = PROCEDURE_ENTRY(next_method1542_3_1341) (next_method1542_3_1341, (obj_t) (o_1315), s_1316, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1542_3_1341);
		       {
			  object_t aux_3044;
			  aux_3044 = struct_object__object_93___object((object_t) (o_1315), s_1316);
			  old1534_1319 = (obj_t) (aux_3044);
		       }
		    }
	       }
	       aux1535_1320 = STRUCT_REF(s_1316, ((long) 0));
	       {
		  sfun_iinfo_105_t new1536_1321;
		  new1536_1321 = ((sfun_iinfo_105_t) (old1534_1319));
		  {
		     long arg1713_1322;
		     arg1713_1322 = class_num_218___object(sfun_iinfo_105_integrate_info);
		     {
			obj_t obj_1674;
			obj_1674 = (obj_t) (new1536_1321);
			(((obj_t) CREF(obj_1674))->header = MAKE_HEADER(arg1713_1322, 0), BUNSPEC);
		     }
		  }
		  {
		     sfun_iinfo_105_t arg1714_1323;
		     {
			obj_t arg1716_1324;
			obj_t arg1717_1325;
			obj_t arg1718_1326;
			obj_t arg1720_1327;
			obj_t arg1721_1328;
			obj_t arg1722_1329;
			obj_t arg1723_1330;
			obj_t arg1724_1331;
			obj_t arg1725_1332;
			obj_t arg1726_1333;
			obj_t arg1727_1334;
			obj_t arg1729_1336;
			obj_t arg1730_1337;
			obj_t arg1731_1338;
			obj_t arg1732_1339;
			obj_t arg1733_1340;
			arg1716_1324 = STRUCT_REF(aux1535_1320, ((long) 0));
			arg1717_1325 = STRUCT_REF(aux1535_1320, ((long) 1));
			arg1718_1326 = STRUCT_REF(aux1535_1320, ((long) 2));
			arg1720_1327 = STRUCT_REF(aux1535_1320, ((long) 3));
			arg1721_1328 = STRUCT_REF(aux1535_1320, ((long) 4));
			arg1722_1329 = STRUCT_REF(aux1535_1320, ((long) 5));
			arg1723_1330 = STRUCT_REF(aux1535_1320, ((long) 6));
			arg1724_1331 = STRUCT_REF(aux1535_1320, ((long) 7));
			arg1725_1332 = STRUCT_REF(aux1535_1320, ((long) 8));
			arg1726_1333 = STRUCT_REF(aux1535_1320, ((long) 9));
			arg1727_1334 = STRUCT_REF(aux1535_1320, ((long) 10));
			arg1729_1336 = STRUCT_REF(aux1535_1320, ((long) 12));
			arg1730_1337 = STRUCT_REF(aux1535_1320, ((long) 13));
			arg1731_1338 = STRUCT_REF(aux1535_1320, ((long) 14));
			arg1732_1339 = STRUCT_REF(aux1535_1320, ((long) 15));
			arg1733_1340 = STRUCT_REF(aux1535_1320, ((long) 16));
			{
			   sfun_iinfo_105_t res1798_1745;
			   {
			      bool_t g__219_1721;
			      {
				 obj_t aux_3069;
				 aux_3069 = STRUCT_REF(aux1535_1320, ((long) 11));
				 g__219_1721 = CBOOL(aux_3069);
			      }
			      {
				 sfun_iinfo_105_t new1481_1727;
				 new1481_1727 = ((sfun_iinfo_105_t) BREF(GC_MALLOC(sizeof(struct sfun_iinfo_105))));
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->owner) = ((obj_t) arg1716_1324), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->free) = ((obj_t) arg1717_1325), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->bound) = ((obj_t) arg1718_1326), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->cfrom) = ((obj_t) arg1720_1327), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->cto) = ((obj_t) arg1721_1328), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->k) = ((obj_t) arg1722_1329), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->k__190) = ((obj_t) arg1723_1330), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->u) = ((obj_t) arg1724_1331), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->cn) = ((obj_t) arg1725_1332), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->ct) = ((obj_t) arg1726_1333), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->kont) = ((obj_t) arg1727_1334), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->g__219) = ((bool_t) g__219_1721), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->l) = ((obj_t) arg1729_1336), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->led) = ((obj_t) arg1730_1337), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->istamp) = ((obj_t) arg1731_1338), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->global) = ((obj_t) arg1732_1339), BUNSPEC);
				 ((((sfun_iinfo_105_t) CREF(new1481_1727))->kaptured) = ((obj_t) arg1733_1340), BUNSPEC);
				 res1798_1745 = new1481_1727;
			      }
			   }
			   arg1714_1323 = res1798_1745;
			}
		     }
		     {
			obj_t aux_3092;
			object_t aux_3090;
			aux_3092 = (obj_t) (arg1714_1323);
			aux_3090 = (object_t) (new1536_1321);
			OBJECT_WIDENING_SET(aux_3090, aux_3092);
		     }
		  }
		  aux_3035 = new1536_1321;
	       }
	    }
	 }
	 return (obj_t) (aux_3035);
      }
   }
}


/* object->struct-sfun/iinfo */ obj_t 
object__struct_sfun_iinfo_106_integrate_info(obj_t env_2155, obj_t obj1531_2156)
{
   {
      sfun_iinfo_105_t obj1531_1270;
      obj1531_1270 = (sfun_iinfo_105_t) (obj1531_2156);
      {
	 {
	    obj_t res1532_1273;
	    {
	       obj_t next_method1541_89_1313;
	       next_method1541_89_1313 = find_super_class_method_167___object((object_t) (obj1531_1270), object__struct_env_210___object, sfun_iinfo_105_integrate_info);
	       if (PROCEDUREP(next_method1541_89_1313))
		 {
		    res1532_1273 = PROCEDURE_ENTRY(next_method1541_89_1313) (next_method1541_89_1313, (obj_t) (obj1531_1270), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1541_89_1313);
		    res1532_1273 = object__struct_50___object((object_t) (obj1531_1270));
		 }
	    }
	    {
	       obj_t aux1533_1274;
	       {
		  obj_t aux_3107;
		  aux_3107 = CNST_TABLE_REF(((long) 2));
		  aux1533_1274 = make_struct(aux_3107, ((long) 17), BUNSPEC);
	       }
	       {
		  obj_t aux_3110;
		  {
		     obj_t aux_3111;
		     {
			object_t aux_3112;
			aux_3112 = (object_t) (obj1531_1270);
			aux_3111 = OBJECT_WIDENING(aux_3112);
		     }
		     aux_3110 = (((sfun_iinfo_105_t) CREF(aux_3111))->owner);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 0), aux_3110);
	       }
	       {
		  obj_t aux_3117;
		  {
		     obj_t aux_3118;
		     {
			object_t aux_3119;
			aux_3119 = (object_t) (obj1531_1270);
			aux_3118 = OBJECT_WIDENING(aux_3119);
		     }
		     aux_3117 = (((sfun_iinfo_105_t) CREF(aux_3118))->free);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 1), aux_3117);
	       }
	       {
		  obj_t aux_3124;
		  {
		     obj_t aux_3125;
		     {
			object_t aux_3126;
			aux_3126 = (object_t) (obj1531_1270);
			aux_3125 = OBJECT_WIDENING(aux_3126);
		     }
		     aux_3124 = (((sfun_iinfo_105_t) CREF(aux_3125))->bound);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 2), aux_3124);
	       }
	       {
		  obj_t aux_3131;
		  {
		     obj_t aux_3132;
		     {
			object_t aux_3133;
			aux_3133 = (object_t) (obj1531_1270);
			aux_3132 = OBJECT_WIDENING(aux_3133);
		     }
		     aux_3131 = (((sfun_iinfo_105_t) CREF(aux_3132))->cfrom);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 3), aux_3131);
	       }
	       {
		  obj_t aux_3138;
		  {
		     obj_t aux_3139;
		     {
			object_t aux_3140;
			aux_3140 = (object_t) (obj1531_1270);
			aux_3139 = OBJECT_WIDENING(aux_3140);
		     }
		     aux_3138 = (((sfun_iinfo_105_t) CREF(aux_3139))->cto);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 4), aux_3138);
	       }
	       {
		  obj_t aux_3145;
		  {
		     obj_t aux_3146;
		     {
			object_t aux_3147;
			aux_3147 = (object_t) (obj1531_1270);
			aux_3146 = OBJECT_WIDENING(aux_3147);
		     }
		     aux_3145 = (((sfun_iinfo_105_t) CREF(aux_3146))->k);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 5), aux_3145);
	       }
	       {
		  obj_t aux_3152;
		  {
		     obj_t aux_3153;
		     {
			object_t aux_3154;
			aux_3154 = (object_t) (obj1531_1270);
			aux_3153 = OBJECT_WIDENING(aux_3154);
		     }
		     aux_3152 = (((sfun_iinfo_105_t) CREF(aux_3153))->k__190);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 6), aux_3152);
	       }
	       {
		  obj_t aux_3159;
		  {
		     obj_t aux_3160;
		     {
			object_t aux_3161;
			aux_3161 = (object_t) (obj1531_1270);
			aux_3160 = OBJECT_WIDENING(aux_3161);
		     }
		     aux_3159 = (((sfun_iinfo_105_t) CREF(aux_3160))->u);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 7), aux_3159);
	       }
	       {
		  obj_t aux_3166;
		  {
		     obj_t aux_3167;
		     {
			object_t aux_3168;
			aux_3168 = (object_t) (obj1531_1270);
			aux_3167 = OBJECT_WIDENING(aux_3168);
		     }
		     aux_3166 = (((sfun_iinfo_105_t) CREF(aux_3167))->cn);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 8), aux_3166);
	       }
	       {
		  obj_t aux_3173;
		  {
		     obj_t aux_3174;
		     {
			object_t aux_3175;
			aux_3175 = (object_t) (obj1531_1270);
			aux_3174 = OBJECT_WIDENING(aux_3175);
		     }
		     aux_3173 = (((sfun_iinfo_105_t) CREF(aux_3174))->ct);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 9), aux_3173);
	       }
	       {
		  obj_t aux_3180;
		  {
		     obj_t aux_3181;
		     {
			object_t aux_3182;
			aux_3182 = (object_t) (obj1531_1270);
			aux_3181 = OBJECT_WIDENING(aux_3182);
		     }
		     aux_3180 = (((sfun_iinfo_105_t) CREF(aux_3181))->kont);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 10), aux_3180);
	       }
	       {
		  obj_t aux_3187;
		  {
		     bool_t aux_3188;
		     {
			obj_t aux_3189;
			{
			   object_t aux_3190;
			   aux_3190 = (object_t) (obj1531_1270);
			   aux_3189 = OBJECT_WIDENING(aux_3190);
			}
			aux_3188 = (((sfun_iinfo_105_t) CREF(aux_3189))->g__219);
		     }
		     aux_3187 = BBOOL(aux_3188);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 11), aux_3187);
	       }
	       {
		  obj_t aux_3196;
		  {
		     obj_t aux_3197;
		     {
			object_t aux_3198;
			aux_3198 = (object_t) (obj1531_1270);
			aux_3197 = OBJECT_WIDENING(aux_3198);
		     }
		     aux_3196 = (((sfun_iinfo_105_t) CREF(aux_3197))->l);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 12), aux_3196);
	       }
	       {
		  obj_t aux_3203;
		  {
		     obj_t aux_3204;
		     {
			object_t aux_3205;
			aux_3205 = (object_t) (obj1531_1270);
			aux_3204 = OBJECT_WIDENING(aux_3205);
		     }
		     aux_3203 = (((sfun_iinfo_105_t) CREF(aux_3204))->led);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 13), aux_3203);
	       }
	       {
		  obj_t aux_3210;
		  {
		     obj_t aux_3211;
		     {
			object_t aux_3212;
			aux_3212 = (object_t) (obj1531_1270);
			aux_3211 = OBJECT_WIDENING(aux_3212);
		     }
		     aux_3210 = (((sfun_iinfo_105_t) CREF(aux_3211))->istamp);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 14), aux_3210);
	       }
	       {
		  obj_t aux_3217;
		  {
		     obj_t aux_3218;
		     {
			object_t aux_3219;
			aux_3219 = (object_t) (obj1531_1270);
			aux_3218 = OBJECT_WIDENING(aux_3219);
		     }
		     aux_3217 = (((sfun_iinfo_105_t) CREF(aux_3218))->global);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 15), aux_3217);
	       }
	       {
		  obj_t aux_3224;
		  {
		     obj_t aux_3225;
		     {
			object_t aux_3226;
			aux_3226 = (object_t) (obj1531_1270);
			aux_3225 = OBJECT_WIDENING(aux_3226);
		     }
		     aux_3224 = (((sfun_iinfo_105_t) CREF(aux_3225))->kaptured);
		  }
		  STRUCT_SET(aux1533_1274, ((long) 16), aux_3224);
	       }
	       STRUCT_SET(res1532_1273, ((long) 0), aux1533_1274);
	       {
		  obj_t aux_3232;
		  aux_3232 = STRUCT_KEY(res1532_1273);
		  STRUCT_KEY_SET(aux1533_1274, aux_3232);
	       }
	       {
		  obj_t aux_3235;
		  aux_3235 = CNST_TABLE_REF(((long) 2));
		  STRUCT_KEY_SET(res1532_1273, aux_3235);
	       }
	       return res1532_1273;
	    }
	 }
      }
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_integrate_info()
{
   module_initialization_70_type_type(((long) 0), "INTEGRATE_INFO");
   module_initialization_70_ast_var(((long) 0), "INTEGRATE_INFO");
   return module_initialization_70_ast_node(((long) 0), "INTEGRATE_INFO");
}
