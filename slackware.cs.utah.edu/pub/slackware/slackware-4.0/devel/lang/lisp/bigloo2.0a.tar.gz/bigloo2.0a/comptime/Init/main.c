/*===========================================================================*/
/*   (Init/main.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t engine_engine_engine();
extern obj_t exitd_top;
static obj_t _main1021_init_main(obj_t, obj_t);
extern obj_t parse_args_143_init_parse_args_215(obj_t);
extern obj_t member___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t handling_function1017_init_main(obj_t);
static obj_t handling_function1011_init_main(obj_t);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70_init_setrc(long, char *);
extern obj_t module_initialization_70_init_parse_args_215(long, char *);
extern obj_t module_initialization_70_engine_engine(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t _exit_bigloo__25_init_main = BUNSPEC;
static obj_t _exit_bigloo_108_init_main(obj_t, obj_t);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t imported_modules_init_94_init_main();
static obj_t library_modules_init_112_init_main();
extern obj_t stop_trace_98_tools_trace();
static obj_t toplevel_init_63_init_main();
static obj_t lambda1009_init_main(obj_t, obj_t);
static obj_t exit_init_main(obj_t, obj_t);
extern obj_t main_109_init_main(obj_t);
extern obj_t val_from_exit__100___bexit(obj_t);
extern obj_t setup_default_values_46_init_setrc();
static obj_t require_initialization_114_init_main = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(main_env_45_init_main, _main1021_init_main1026, _main1021_init_main, 0L, 1);
DEFINE_EXPORT_PROCEDURE(exit_bigloo_env_218_init_main, _exit_bigloo_108_init_main1027, _exit_bigloo_108_init_main, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1022_init_main, lambda1009_init_main1028, lambda1009_init_main, 0L, 1);
DEFINE_STRING(string1023_init_main, string1023_init_main1029, "-q", 2);

extern int _bigloo_main();

int 
BIGLOO_MAIN(int argc, char *argv[])
{
   _bigloo_main(argc, argv);
}


/* module-initialization */ obj_t 
module_initialization_70_init_main(long checksum_37, char *from_38)
{
   if (CBOOL(require_initialization_114_init_main))
     {
	require_initialization_114_init_main = BBOOL(((bool_t) 0));
	library_modules_init_112_init_main();
	imported_modules_init_94_init_main();
	toplevel_init_63_init_main();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* bigloo_main */ obj_t 
bigloo_main(obj_t argv_39)
{
   module_initialization_70_init_main(((long) 0), "INIT_MAIN");
   {
      obj_t arg1025_40;
      arg1025_40 = main_109_init_main(argv_39);
      return BIGLOO_EXIT(arg1025_40);
   }
}


/* library-modules-init */ obj_t 
library_modules_init_112_init_main()
{
   module_initialization_70___bexit(((long) 0), "INIT_MAIN");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "INIT_MAIN");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_init_main()
{
   {
      obj_t lambda1009_24;
      lambda1009_24 = proc1022_init_main;
      return (_exit_bigloo__25_init_main = lambda1009_24,
	 BUNSPEC);
   }
}


/* lambda1009 */ obj_t 
lambda1009_init_main(obj_t env_25, obj_t x_26)
{
   {
      obj_t x_3;
      x_3 = x_26;
      {
	 obj_t res1020_21;
	 {
	    long n_20;
	    n_20 = (long) CINT(x_3);
	    exit(n_20);
	    res1020_21 = BINT(n_20);
	 }
	 return res1020_21;
      }
   }
}


/* main */ obj_t 
main_109_init_main(obj_t argv_1)
{
   {
      bool_t test_55;
      {
	 obj_t aux_56;
	 aux_56 = member___r4_pairs_and_lists_6_3(string1023_init_main, argv_1);
	 test_55 = CBOOL(aux_56);
      }
      if (test_55)
	{
	   BUNSPEC;
	}
      else
	{
	   setup_default_values_46_init_setrc();
	}
   }
   return handling_function1011_init_main(argv_1);
}


/* handling_function1011 */ obj_t 
handling_function1011_init_main(obj_t argv_35)
{
   jmp_buf jmpbuf;
   obj_t an_exit1002_7;
   if (SET_EXIT(an_exit1002_7))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1002_7 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1002_7, ((bool_t) 1));
	   {
	      obj_t an_exitd1003_8;
	      an_exitd1003_8 = exitd_top;
	      {
		 obj_t exit_27;
		 exit_27 = make_fx_procedure(exit_init_main, ((long) 1), ((long) 1));
		 PROCEDURE_SET(exit_27, ((long) 0), an_exitd1003_8);
		 {
		    obj_t res1005_11;
		    _exit_bigloo__25_init_main = exit_27;
		    {
		       obj_t val1006_12;
		       val1006_12 = handling_function1017_init_main(argv_35);
		       stop_trace_98_tools_trace();
		       {
			  bool_t test1012_13;
			  {
			     obj_t aux_68;
			     aux_68 = val_from_exit__100___bexit(val1006_12);
			     test1012_13 = CBOOL(aux_68);
			  }
			  if (test1012_13)
			    {
			       res1005_11 = unwind_until__178___bexit(CAR(val1006_12), CDR(val1006_12));
			    }
			  else
			    {
			       res1005_11 = val1006_12;
			    }
		       }
		    }
		    POP_EXIT();
		    return res1005_11;
		 }
	      }
	   }
	}
     }
}


/* handling_function1017 */ obj_t 
handling_function1017_init_main(obj_t argv_36)
{
   jmp_buf jmpbuf;
   obj_t an_exit1007_17;
   if (SET_EXIT(an_exit1007_17))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1007_17 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1007_17, ((bool_t) 0));
	   {
	      obj_t val1008_18;
	      {
		 bool_t test1019_19;
		 {
		    obj_t aux_79;
		    aux_79 = parse_args_143_init_parse_args_215(argv_36);
		    test1019_19 = CBOOL(aux_79);
		 }
		 if (test1019_19)
		   {
		      val1008_18 = engine_engine_engine();
		   }
		 else
		   {
		      val1008_18 = BINT(((long) -1));
		   }
	      }
	      POP_EXIT();
	      return val1008_18;
	   }
	}
     }
}


/* _main1021 */ obj_t 
_main1021_init_main(obj_t env_28, obj_t argv_29)
{
   return main_109_init_main(argv_29);
}


/* exit */ obj_t 
exit_init_main(obj_t env_30, obj_t val1004_32)
{
   {
      obj_t an_exitd1003_31;
      an_exitd1003_31 = PROCEDURE_REF(env_30, ((long) 0));
      {
	 obj_t val1004_9;
	 val1004_9 = val1004_32;
	 return unwind_until__178___bexit(an_exitd1003_31, val1004_9);
      }
   }
}


/* exit-bigloo */ obj_t 
exit_bigloo_229_init_main(obj_t value_2)
{
   return PROCEDURE_ENTRY(_exit_bigloo__25_init_main) (_exit_bigloo__25_init_main, value_2, BEOA);
}


/* _exit-bigloo */ obj_t 
_exit_bigloo_108_init_main(obj_t env_33, obj_t value_34)
{
   return exit_bigloo_229_init_main(value_34);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_init_main()
{
   module_initialization_70_init_setrc(((long) 0), "INIT_MAIN");
   module_initialization_70_init_parse_args_215(((long) 0), "INIT_MAIN");
   module_initialization_70_engine_engine(((long) 0), "INIT_MAIN");
   return module_initialization_70_tools_trace(((long) 0), "INIT_MAIN");
}
