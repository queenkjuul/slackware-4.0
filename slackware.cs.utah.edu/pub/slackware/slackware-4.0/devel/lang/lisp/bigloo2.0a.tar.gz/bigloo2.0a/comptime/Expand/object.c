/*===========================================================================*/
/*   (Expand/object.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct class
  {
     obj_t its_super_214;
     obj_t slots;
     struct global *holder;
     obj_t widening;
     long depth;
     bool_t final__12;
     obj_t constructor;
  }
     *class_t;


static obj_t make_widening_107_expand_object(obj_t, type_t, obj_t, obj_t);
static obj_t method_init_76_expand_object();
extern obj_t symbol_append_197___r4_symbols_6_4(obj_t);
extern obj_t string_append(obj_t, obj_t);
extern obj_t list_ref_194___r4_pairs_and_lists_6_3(obj_t, long);
extern obj_t mark_symbol_non_user__17_ast_ident(obj_t);
static obj_t _expand_instantiate2443_96_expand_object(obj_t, obj_t, obj_t);
static obj_t make_virtual_set_218_expand_object(obj_t, obj_t, obj_t, obj_t, obj_t, char *);
extern obj_t gensym___r4_symbols_6_4;
static obj_t make_a_shrink__124_expand_object(obj_t, obj_t);
extern type_t type_of_id_183_ast_ident(obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_expand_object(long, char *);
extern obj_t module_initialization_70_tools_args(long, char *);
extern obj_t module_initialization_70_tools_progn(long, char *);
extern obj_t module_initialization_70_tools_misc(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_env(long, char *);
extern obj_t module_initialization_70_expand_eps(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_object_class(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern long list_length(obj_t);
static obj_t _expand_duplicate2444_215_expand_object(obj_t, obj_t, obj_t);
static obj_t instantiate__make_36_expand_object(obj_t, type_t, obj_t);
static obj_t imported_modules_init_94_expand_object();
static obj_t find_slot_offset_103_expand_object(obj_t, obj_t, obj_t);
extern obj_t string_append_106___r4_strings_6_7(obj_t);
extern obj_t normalize_progn_143_tools_progn(obj_t);
static obj_t duplicate__make_94_expand_object(obj_t, obj_t, obj_t, obj_t);
extern obj_t expand_duplicate_139_expand_object(obj_t, obj_t);
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_expand_object();
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_expand_object();
extern obj_t _unsafe_type__146_engine_param;
extern obj_t replace__160_tools_misc(obj_t, obj_t);
extern obj_t open_input_string(obj_t);
static obj_t epairify_expand_object(obj_t, obj_t);
extern obj_t expand_widen__163_expand_object(obj_t, obj_t);
extern obj_t lexical_stack_189_expand_eps();
extern obj_t with_lexical_22_expand_eps(obj_t, obj_t, obj_t);
extern obj_t class_object_class;
extern obj_t string_to_bstring(char *);
static obj_t lambda1274_expand_object(obj_t, obj_t, obj_t);
extern obj_t parse_id_241_ast_ident(obj_t);
static obj_t find_slot_offset_2448_137_expand_object(obj_t, obj_t, obj_t);
static obj_t find_slot_offset_2447_171_expand_object(obj_t, obj_t, obj_t);
static obj_t with_access_expander_113_expand_object(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
extern obj_t expand_shrink__128_expand_object(obj_t, obj_t);
static obj_t _expand_shrink_2446_35_expand_object(obj_t, obj_t, obj_t);
static obj_t arg1244_expand_object(obj_t);
extern obj_t _4dots_199_tools_misc;
static obj_t _expand_with_access2442_83_expand_object(obj_t, obj_t, obj_t);
static obj_t _expand_widen_2445_225_expand_object(obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t require_initialization_114_expand_object = BUNSPEC;
extern obj_t expand_with_access_221_expand_object(obj_t, obj_t);
extern obj_t expand_instantiate_150_expand_object(obj_t, obj_t);
static obj_t cnst_init_137_expand_object();
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
extern obj_t make_vector(long, obj_t);
static obj_t __cnst[30];

DEFINE_EXPORT_PROCEDURE(expand_duplicate_env_116_expand_object, _expand_duplicate2444_215_expand_object2478, _expand_duplicate2444_215_expand_object, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_instantiate_env_9_expand_object, _expand_instantiate2443_96_expand_object2479, _expand_instantiate2443_96_expand_object, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_widen__env_255_expand_object, _expand_widen_2445_225_expand_object2480, _expand_widen_2445_225_expand_object, 0L, 2);
DEFINE_STRING(string2472_expand_object, string2472_expand_object2481, "OBJECT? O ERROR BEGIN OBJECT-CLASS CLASS-SUPER EQ? SHRINK! OBJECT-WIDENING IF CLASS-NUM __OBJECT OBJECT-CLASS-NUM-SET! @ OBJECT-WIDENING-SET! PRAGMA OBJ LET* -REF NOTHING DUPLICATED MAKE- OK DONE NEW SET! -SET! - LET INSTANCE ", 226);
DEFINE_STRING(string2471_expand_object, string2471_expand_object2482, "Type `extended pair' expected for expression", 44);
DEFINE_STRING(string2469_expand_object, string2469_expand_object2483, "Illegal `", 9);
DEFINE_STRING(string2470_expand_object, string2470_expand_object2484, "cer", 3);
DEFINE_STRING(string2468_expand_object, string2468_expand_object2485, "' form (read-only slot ", 23);
DEFINE_STRING(string2467_expand_object, string2467_expand_object2486, "shrink!", 7);
DEFINE_STRING(string2466_expand_object, string2466_expand_object2487, "Not a wide object", 17);
DEFINE_STRING(string2465_expand_object, string2465_expand_object2488, "Illegal `shrink!' form", 22);
DEFINE_STRING(string2464_expand_object, string2464_expand_object2489, "Illegal `widen!' form (unknown slot ", 36);
DEFINE_STRING(string2463_expand_object, string2463_expand_object2490, "widen!", 6);
DEFINE_STRING(string2462_expand_object, string2462_expand_object2491, "This object can't be widened to the wanted class", 48);
DEFINE_STRING(string2461_expand_object, string2461_expand_object2492, "Illegal `widening!' form (missing arguments for slot ", 53);
DEFINE_STRING(string2459_expand_object, string2459_expand_object2493, ")($1))", 6);
DEFINE_STRING(string2460_expand_object, string2460_expand_object2494, "((", 2);
DEFINE_STRING(string2458_expand_object, string2458_expand_object2495, "Illegal `widen!' form", 21);
DEFINE_STRING(string2457_expand_object, string2457_expand_object2496, "widen!:Illegal class type:", 26);
DEFINE_STRING(string2456_expand_object, string2456_expand_object2497, "Illegal `duplicate' form (unknown slot ", 39);
DEFINE_STRING(string2455_expand_object, string2455_expand_object2498, "Illegal `duplicate' form", 24);
DEFINE_STRING(string2454_expand_object, string2454_expand_object2499, "duplicate:Illegal class type:", 29);
DEFINE_STRING(string2453_expand_object, string2453_expand_object2500, "Illegal `instantiate' form (unknown slot ", 41);
DEFINE_STRING(string2452_expand_object, string2452_expand_object2501, "Illegal `instantiate' form (missing arguments for slot ", 55);
DEFINE_STRING(string2451_expand_object, string2451_expand_object2502, ")", 1);
DEFINE_STRING(string2449_expand_object, string2449_expand_object2503, "Illegal `with-access' form", 26);
DEFINE_STRING(string2450_expand_object, string2450_expand_object2504, "Illegal `instantiate' form", 26);
DEFINE_EXPORT_PROCEDURE(expand_shrink__env_80_expand_object, _expand_shrink_2446_35_expand_object2505, _expand_shrink_2446_35_expand_object, 0L, 2);
DEFINE_EXPORT_PROCEDURE(expand_with_access_env_4_expand_object, _expand_with_access2442_83_expand_object2506, _expand_with_access2442_83_expand_object, 0L, 2);


/* module-initialization */ obj_t 
module_initialization_70_expand_object(long checksum_2506, char *from_2507)
{
   if (CBOOL(require_initialization_114_expand_object))
     {
	require_initialization_114_expand_object = BBOOL(((bool_t) 0));
	library_modules_init_112_expand_object();
	cnst_init_137_expand_object();
	imported_modules_init_94_expand_object();
	method_init_76_expand_object();
	toplevel_init_63_expand_object();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_expand_object()
{
   module_initialization_70___r4_symbols_6_4(((long) 0), "EXPAND_OBJECT");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "EXPAND_OBJECT");
   module_initialization_70___object(((long) 0), "EXPAND_OBJECT");
   module_initialization_70___r4_strings_6_7(((long) 0), "EXPAND_OBJECT");
   module_initialization_70___reader(((long) 0), "EXPAND_OBJECT");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_expand_object()
{
   {
      obj_t cnst_port_138_2498;
      cnst_port_138_2498 = open_input_string(string2472_expand_object);
      {
	 long i_2499;
	 i_2499 = ((long) 29);
       loop_2500:
	 {
	    bool_t test2473_2501;
	    test2473_2501 = (i_2499 == ((long) -1));
	    if (test2473_2501)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2474_2502;
		    {
		       obj_t list2475_2503;
		       {
			  obj_t arg2476_2504;
			  arg2476_2504 = BNIL;
			  list2475_2503 = MAKE_PAIR(cnst_port_138_2498, arg2476_2504);
		       }
		       arg2474_2502 = read___reader(list2475_2503);
		    }
		    CNST_TABLE_SET(i_2499, arg2474_2502);
		 }
		 {
		    int aux_2505;
		    {
		       long aux_2527;
		       aux_2527 = (i_2499 - ((long) 1));
		       aux_2505 = (int) (aux_2527);
		    }
		    {
		       long i_2530;
		       i_2530 = (long) (aux_2505);
		       i_2499 = i_2530;
		       goto loop_2500;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_expand_object()
{
   return BUNSPEC;
}


/* expand-with-access */ obj_t 
expand_with_access_221_expand_object(obj_t x_63, obj_t e_64)
{
   {
      obj_t with_access_173_490;
      obj_t instance_491;
      obj_t slots_492;
      obj_t body_493;
      if (PAIRP(x_63))
	{
	   obj_t cdr_113_28_498;
	   cdr_113_28_498 = CDR(x_63);
	   if (PAIRP(cdr_113_28_498))
	     {
		obj_t cdr_119_211_500;
		cdr_119_211_500 = CDR(cdr_113_28_498);
		if (PAIRP(cdr_119_211_500))
		  {
		     obj_t car_123_18_502;
		     obj_t cdr_124_99_503;
		     car_123_18_502 = CAR(cdr_119_211_500);
		     cdr_124_99_503 = CDR(cdr_119_211_500);
		     if (PAIRP(car_123_18_502))
		       {
			  if (PAIRP(cdr_124_99_503))
			    {
			       with_access_173_490 = CAR(x_63);
			       instance_491 = CAR(cdr_113_28_498);
			       slots_492 = car_123_18_502;
			       body_493 = cdr_124_99_503;
			       {
				  type_t class_508;
				  class_508 = type_of_id_183_ast_ident(with_access_173_490);
				  {
				     bool_t test1241_509;
				     test1241_509 = is_a__118___object((obj_t) (class_508), class_object_class);
				     if (test1241_509)
				       {
					  obj_t s_510;
					  s_510 = slots_492;
					loop_511:
					  if (NULLP(s_510))
					    {
					       {
						  obj_t aux_513;
						  {
						     obj_t arg1268_539;
						     arg1268_539 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 0)), BEOA);
						     aux_513 = mark_symbol_non_user__17_ast_ident(arg1268_539);
						  }
						  {
						     obj_t instance_515;
						     instance_515 = PROCEDURE_ENTRY(e_64) (e_64, instance_491, e_64, BEOA);
						     {
							{
							   obj_t arg1243_516;
							   {
							      obj_t arg1244_2453;
							      arg1244_2453 = make_fx_procedure(arg1244_expand_object, ((long) 0), ((long) 7));
							      {
								 obj_t aux_2559;
								 aux_2559 = (obj_t) (class_508);
								 PROCEDURE_SET(arg1244_2453, ((long) 0), aux_2559);
							      }
							      PROCEDURE_SET(arg1244_2453, ((long) 1), e_64);
							      PROCEDURE_SET(arg1244_2453, ((long) 2), aux_513);
							      PROCEDURE_SET(arg1244_2453, ((long) 3), aux_513);
							      PROCEDURE_SET(arg1244_2453, ((long) 4), slots_492);
							      PROCEDURE_SET(arg1244_2453, ((long) 5), instance_515);
							      PROCEDURE_SET(arg1244_2453, ((long) 6), body_493);
							      arg1243_516 = with_lexical_22_expand_eps(slots_492, aux_513, arg1244_2453);
							   }
							   return replace__160_tools_misc(x_63, arg1243_516);
							}
						     }
						  }
					       }
					    }
					  else
					    {
					       if (PAIRP(s_510))
						 {
						    bool_t test_2572;
						    {
						       obj_t aux_2573;
						       aux_2573 = CAR(s_510);
						       test_2572 = SYMBOLP(aux_2573);
						    }
						    if (test_2572)
						      {
							 {
							    obj_t s_2576;
							    s_2576 = CDR(s_510);
							    s_510 = s_2576;
							    goto loop_511;
							 }
						      }
						    else
						      {
							 FAILURE(BFALSE, string2449_expand_object, x_63);
						      }
						 }
					       else
						 {
						    FAILURE(BFALSE, string2449_expand_object, x_63);
						 }
					    }
				       }
				     else
				       {
					  FAILURE(BFALSE, string2449_expand_object, x_63);
				       }
				  }
			       }
			    }
			  else
			    {
			     tag_102_241_495:
			       FAILURE(BFALSE, string2449_expand_object, x_63);
			    }
		       }
		     else
		       {
			  goto tag_102_241_495;
		       }
		  }
		else
		  {
		     goto tag_102_241_495;
		  }
	     }
	   else
	     {
		goto tag_102_241_495;
	     }
	}
      else
	{
	   goto tag_102_241_495;
	}
   }
}


/* _expand-with-access2442 */ obj_t 
_expand_with_access2442_83_expand_object(obj_t env_2454, obj_t x_2455, obj_t e_2456)
{
   return expand_with_access_221_expand_object(x_2455, e_2456);
}


/* arg1244 */ obj_t 
arg1244_expand_object(obj_t env_2457)
{
   {
      obj_t class_2458;
      obj_t e_2459;
      obj_t mark_2460;
      obj_t aux_2461;
      obj_t slots_2462;
      obj_t instance_2463;
      obj_t body_2464;
      class_2458 = PROCEDURE_REF(env_2457, ((long) 0));
      e_2459 = PROCEDURE_REF(env_2457, ((long) 1));
      mark_2460 = PROCEDURE_REF(env_2457, ((long) 2));
      aux_2461 = PROCEDURE_REF(env_2457, ((long) 3));
      slots_2462 = PROCEDURE_REF(env_2457, ((long) 4));
      instance_2463 = PROCEDURE_REF(env_2457, ((long) 5));
      body_2464 = PROCEDURE_REF(env_2457, ((long) 6));
      {
	 {
	    obj_t e_519;
	    {
	       obj_t aux_2592;
	       {
		  type_t obj_1901;
		  obj_1901 = (type_t) (class_2458);
		  aux_2592 = (((type_t) CREF(obj_1901))->id);
	       }
	       e_519 = with_access_expander_113_expand_object(e_2459, mark_2460, aux_2461, aux_2592, slots_2462);
	    }
	    {
	       obj_t arg1247_520;
	       obj_t arg1248_521;
	       obj_t arg1250_522;
	       arg1247_520 = CNST_TABLE_REF(((long) 1));
	       {
		  obj_t arg1256_528;
		  {
		     obj_t list1261_533;
		     {
			obj_t arg1262_534;
			arg1262_534 = MAKE_PAIR(BNIL, BNIL);
			list1261_533 = MAKE_PAIR(instance_2463, arg1262_534);
		     }
		     arg1256_528 = cons__138___r4_pairs_and_lists_6_3(aux_2461, list1261_533);
		  }
		  {
		     obj_t list1258_530;
		     list1258_530 = MAKE_PAIR(BNIL, BNIL);
		     arg1248_521 = cons__138___r4_pairs_and_lists_6_3(arg1256_528, list1258_530);
		  }
	       }
	       {
		  obj_t arg1265_536;
		  arg1265_536 = normalize_progn_143_tools_progn(body_2464);
		  arg1250_522 = PROCEDURE_ENTRY(e_519) (e_519, arg1265_536, e_519, BEOA);
	       }
	       {
		  obj_t list1252_524;
		  {
		     obj_t arg1253_525;
		     {
			obj_t arg1254_526;
			arg1254_526 = MAKE_PAIR(BNIL, BNIL);
			arg1253_525 = MAKE_PAIR(arg1250_522, arg1254_526);
		     }
		     list1252_524 = MAKE_PAIR(arg1248_521, arg1253_525);
		  }
		  return cons__138___r4_pairs_and_lists_6_3(arg1247_520, list1252_524);
	       }
	    }
	 }
      }
   }
}


/* with-access-expander */ obj_t 
with_access_expander_113_expand_object(obj_t old_expander_200_65, obj_t mark_66, obj_t instance_67, obj_t class_68, obj_t slots_69)
{
   {
      obj_t lambda1274_2465;
      lambda1274_2465 = make_fx_procedure(lambda1274_expand_object, ((long) 2), ((long) 5));
      PROCEDURE_SET(lambda1274_2465, ((long) 0), old_expander_200_65);
      PROCEDURE_SET(lambda1274_2465, ((long) 1), slots_69);
      PROCEDURE_SET(lambda1274_2465, ((long) 2), mark_66);
      PROCEDURE_SET(lambda1274_2465, ((long) 3), class_68);
      PROCEDURE_SET(lambda1274_2465, ((long) 4), instance_67);
      return lambda1274_2465;
   }
}


/* lambda1274 */ obj_t 
lambda1274_expand_object(obj_t env_2466, obj_t x_2472, obj_t e_2473)
{
   {
      obj_t old_expander_200_2467;
      obj_t slots_2468;
      obj_t mark_2469;
      obj_t class_2470;
      obj_t instance_2471;
      old_expander_200_2467 = PROCEDURE_REF(env_2466, ((long) 0));
      slots_2468 = PROCEDURE_REF(env_2466, ((long) 1));
      mark_2469 = PROCEDURE_REF(env_2466, ((long) 2));
      class_2470 = PROCEDURE_REF(env_2466, ((long) 3));
      instance_2471 = PROCEDURE_REF(env_2466, ((long) 4));
      {
	 obj_t x_545;
	 obj_t e_546;
	 x_545 = x_2472;
	 e_546 = e_2473;
	 {
	    obj_t var_550;
	    obj_t val_551;
	    obj_t var_548;
	    if (SYMBOLP(x_545))
	      {
		 var_548 = x_545;
		 {
		    bool_t test1287_570;
		    {
		       bool_t test_2622;
		       {
			  obj_t aux_2623;
			  aux_2623 = memq___r4_pairs_and_lists_6_3(var_548, slots_2468);
			  test_2622 = CBOOL(aux_2623);
		       }
		       if (test_2622)
			 {
			    obj_t cell_582;
			    {
			       obj_t arg1302_585;
			       arg1302_585 = lexical_stack_189_expand_eps();
			       cell_582 = assq___r4_pairs_and_lists_6_3(var_548, arg1302_585);
			    }
			    if (PAIRP(cell_582))
			      {
				 obj_t aux_2630;
				 aux_2630 = CDR(cell_582);
				 test1287_570 = (aux_2630 == mark_2469);
			      }
			    else
			      {
				 test1287_570 = ((bool_t) 0);
			      }
			 }
		       else
			 {
			    test1287_570 = ((bool_t) 0);
			 }
		    }
		    if (test1287_570)
		      {
			 obj_t arg1288_571;
			 {
			    obj_t arg1295_576;
			    arg1295_576 = CNST_TABLE_REF(((long) 2));
			    {
			       obj_t list1296_577;
			       {
				  obj_t arg1297_578;
				  {
				     obj_t arg1298_579;
				     arg1298_579 = MAKE_PAIR(var_548, BNIL);
				     arg1297_578 = MAKE_PAIR(arg1295_576, arg1298_579);
				  }
				  list1296_577 = MAKE_PAIR(class_2470, arg1297_578);
			       }
			       arg1288_571 = symbol_append_197___r4_symbols_6_4(list1296_577);
			    }
			 }
			 {
			    obj_t list1291_573;
			    {
			       obj_t arg1292_574;
			       arg1292_574 = MAKE_PAIR(BNIL, BNIL);
			       list1291_573 = MAKE_PAIR(instance_2471, arg1292_574);
			    }
			    return cons__138___r4_pairs_and_lists_6_3(arg1288_571, list1291_573);
			 }
		      }
		    else
		      {
			 return PROCEDURE_ENTRY(old_expander_200_2467) (old_expander_200_2467, var_548, old_expander_200_2467, BEOA);
		      }
		 }
	      }
	    else
	      {
		 if (PAIRP(x_545))
		   {
		      obj_t cdr_144_157_557;
		      cdr_144_157_557 = CDR(x_545);
		      {
			 bool_t test_2647;
			 {
			    obj_t aux_2650;
			    obj_t aux_2648;
			    aux_2650 = CNST_TABLE_REF(((long) 4));
			    aux_2648 = CAR(x_545);
			    test_2647 = (aux_2648 == aux_2650);
			 }
			 if (test_2647)
			   {
			      if (PAIRP(cdr_144_157_557))
				{
				   obj_t car_147_230_560;
				   obj_t cdr_148_78_561;
				   car_147_230_560 = CAR(cdr_144_157_557);
				   cdr_148_78_561 = CDR(cdr_144_157_557);
				   if (SYMBOLP(car_147_230_560))
				     {
					if (PAIRP(cdr_148_78_561))
					  {
					     bool_t test_2661;
					     {
						obj_t aux_2662;
						aux_2662 = CDR(cdr_148_78_561);
						test_2661 = (aux_2662 == BNIL);
					     }
					     if (test_2661)
					       {
						  var_550 = car_147_230_560;
						  val_551 = CAR(cdr_148_78_561);
						  {
						     obj_t val_586;
						     val_586 = PROCEDURE_ENTRY(e_546) (e_546, val_551, e_546, BEOA);
						     {
							bool_t test1303_587;
							{
							   bool_t test_2667;
							   {
							      obj_t aux_2668;
							      aux_2668 = memq___r4_pairs_and_lists_6_3(var_550, slots_2468);
							      test_2667 = CBOOL(aux_2668);
							   }
							   if (test_2667)
							     {
								obj_t cell_604;
								{
								   obj_t arg1328_607;
								   arg1328_607 = lexical_stack_189_expand_eps();
								   cell_604 = assq___r4_pairs_and_lists_6_3(var_550, arg1328_607);
								}
								if (PAIRP(cell_604))
								  {
								     obj_t aux_2675;
								     aux_2675 = CDR(cell_604);
								     test1303_587 = (aux_2675 == mark_2469);
								  }
								else
								  {
								     test1303_587 = ((bool_t) 0);
								  }
							     }
							   else
							     {
								test1303_587 = ((bool_t) 0);
							     }
							}
							if (test1303_587)
							  {
							     obj_t arg1304_588;
							     {
								obj_t arg1307_589;
								{
								   obj_t arg1315_595;
								   arg1315_595 = CNST_TABLE_REF(((long) 2));
								   {
								      obj_t list1317_597;
								      {
									 obj_t arg1319_598;
									 {
									    obj_t arg1321_599;
									    {
									       obj_t arg1322_600;
									       {
										  obj_t aux_2680;
										  aux_2680 = CNST_TABLE_REF(((long) 3));
										  arg1322_600 = MAKE_PAIR(aux_2680, BNIL);
									       }
									       arg1321_599 = MAKE_PAIR(var_550, arg1322_600);
									    }
									    arg1319_598 = MAKE_PAIR(arg1315_595, arg1321_599);
									 }
									 list1317_597 = MAKE_PAIR(class_2470, arg1319_598);
								      }
								      arg1307_589 = symbol_append_197___r4_symbols_6_4(list1317_597);
								   }
								}
								{
								   obj_t list1309_591;
								   {
								      obj_t arg1310_592;
								      {
									 obj_t arg1311_593;
									 arg1311_593 = MAKE_PAIR(BNIL, BNIL);
									 arg1310_592 = MAKE_PAIR(val_586, arg1311_593);
								      }
								      list1309_591 = MAKE_PAIR(instance_2471, arg1310_592);
								   }
								   arg1304_588 = cons__138___r4_pairs_and_lists_6_3(arg1307_589, list1309_591);
								}
							     }
							     return epairify_expand_object(arg1304_588, x_545);
							  }
							else
							  {
							     {
								obj_t aux_2692;
								{
								   obj_t aux_2693;
								   aux_2693 = CDR(x_545);
								   aux_2692 = CDR(aux_2693);
								}
								SET_CAR(aux_2692, val_586);
							     }
							     return PROCEDURE_ENTRY(old_expander_200_2467) (old_expander_200_2467, x_545, old_expander_200_2467, BEOA);
							  }
						     }
						  }
					       }
					     else
					       {
						tag_133_84_553:
						  return PROCEDURE_ENTRY(old_expander_200_2467) (old_expander_200_2467, x_545, e_546, BEOA);
					       }
					  }
					else
					  {
					     goto tag_133_84_553;
					  }
				     }
				   else
				     {
					goto tag_133_84_553;
				     }
				}
			      else
				{
				   goto tag_133_84_553;
				}
			   }
			 else
			   {
			      goto tag_133_84_553;
			   }
		      }
		   }
		 else
		   {
		      goto tag_133_84_553;
		   }
	      }
	 }
      }
   }
}


/* expand-instantiate */ obj_t 
expand_instantiate_150_expand_object(obj_t x_70, obj_t e_71)
{
   {
      obj_t instantiate_608;
      obj_t provided_609;
      if (PAIRP(x_70))
	{
	   instantiate_608 = CAR(x_70);
	   provided_609 = CDR(x_70);
	   {
	      type_t class_616;
	      class_616 = type_of_id_183_ast_ident(instantiate_608);
	      {
		 bool_t test1332_617;
		 test1332_617 = is_a__118___object((obj_t) (class_616), class_object_class);
		 if (test1332_617)
		   {
		      obj_t arg1333_618;
		      {
			 obj_t arg1334_619;
			 arg1334_619 = instantiate__make_36_expand_object(x_70, class_616, provided_609);
			 arg1333_618 = PROCEDURE_ENTRY(e_71) (e_71, arg1334_619, e_71, BEOA);
		      }
		      return replace__160_tools_misc(x_70, arg1333_618);
		   }
		 else
		   {
		      FAILURE(BFALSE, string2450_expand_object, x_70);
		   }
	      }
	   }
	}
      else
	{
	   FAILURE(BFALSE, string2450_expand_object, x_70);
	}
   }
}


/* _expand-instantiate2443 */ obj_t 
_expand_instantiate2443_96_expand_object(obj_t env_2474, obj_t x_2475, obj_t e_2476)
{
   return expand_instantiate_150_expand_object(x_2475, e_2476);
}


/* instantiate->make */ obj_t 
instantiate__make_36_expand_object(obj_t form_72, type_t class_73, obj_t provided_74)
{
   {
      obj_t slots_620;
      {
	 bool_t test_2717;
	 {
	    class_t obj_1957;
	    obj_1957 = (class_t) (class_73);
	    {
	       obj_t aux_2719;
	       {
		  obj_t aux_2720;
		  {
		     object_t aux_2721;
		     aux_2721 = (object_t) (obj_1957);
		     aux_2720 = OBJECT_WIDENING(aux_2721);
		  }
		  aux_2719 = (((class_t) CREF(aux_2720))->widening);
	       }
	       test_2717 = CBOOL(aux_2719);
	    }
	 }
	 if (test_2717)
	   {
	      obj_t aux_2740;
	      obj_t aux_2726;
	      {
		 class_t obj_1960;
		 obj_1960 = (class_t) (class_73);
		 {
		    obj_t aux_2742;
		    {
		       object_t aux_2743;
		       aux_2743 = (object_t) (obj_1960);
		       aux_2742 = OBJECT_WIDENING(aux_2743);
		    }
		    aux_2740 = (((class_t) CREF(aux_2742))->slots);
		 }
	      }
	      {
		 class_t obj_1959;
		 {
		    obj_t aux_2727;
		    {
		       class_t obj_1958;
		       obj_1958 = (class_t) (class_73);
		       {
			  obj_t aux_2729;
			  {
			     object_t aux_2730;
			     aux_2730 = (object_t) (obj_1958);
			     aux_2729 = OBJECT_WIDENING(aux_2730);
			  }
			  aux_2727 = (((class_t) CREF(aux_2729))->its_super_214);
		       }
		    }
		    obj_1959 = (class_t) (aux_2727);
		 }
		 {
		    obj_t aux_2735;
		    {
		       object_t aux_2736;
		       aux_2736 = (object_t) (obj_1959);
		       aux_2735 = OBJECT_WIDENING(aux_2736);
		    }
		    aux_2726 = (((class_t) CREF(aux_2735))->slots);
		 }
	      }
	      slots_620 = append_2_18___r4_pairs_and_lists_6_3(aux_2726, aux_2740);
	   }
	 else
	   {
	      class_t obj_1961;
	      obj_1961 = (class_t) (class_73);
	      {
		 obj_t aux_2749;
		 {
		    object_t aux_2750;
		    aux_2750 = (object_t) (obj_1961);
		    aux_2749 = OBJECT_WIDENING(aux_2750);
		 }
		 slots_620 = (((class_t) CREF(aux_2749))->slots);
	      }
	   }
      }
      {
	 long len_621;
	 len_621 = list_length(slots_620);
	 {
	    obj_t vargs_622;
	    vargs_622 = make_vector(len_621, BUNSPEC);
	    {
	       obj_t new_623;
	       new_623 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
	       {
		  {
		     long i_625;
		     obj_t slots_626;
		     i_625 = ((long) 0);
		     slots_626 = slots_620;
		   loop_627:
		     if (NULLP(slots_626))
		       {
			  CNST_TABLE_REF(((long) 6));
		       }
		     else
		       {
			  obj_t s_629;
			  s_629 = CAR(slots_626);
			  {
			     bool_t test_2763;
			     {
				obj_t aux_2764;
				aux_2764 = STRUCT_REF(s_629, ((long) 8));
				test_2763 = CBOOL(aux_2764);
			     }
			     if (test_2763)
			       {
				  {
				     obj_t arg1337_631;
				     {
					obj_t aux_2767;
					aux_2767 = STRUCT_REF(s_629, ((long) 9));
					arg1337_631 = MAKE_PAIR(BTRUE, aux_2767);
				     }
				     VECTOR_SET(vargs_622, i_625, arg1337_631);
				  }
			       }
			     else
			       {
				  {
				     obj_t arg1340_633;
				     arg1340_633 = MAKE_PAIR(BFALSE, BUNSPEC);
				     VECTOR_SET(vargs_622, i_625, arg1340_633);
				  }
			       }
			  }
			  {
			     obj_t slots_2775;
			     long i_2773;
			     i_2773 = (i_625 + ((long) 1));
			     slots_2775 = CDR(slots_626);
			     slots_626 = slots_2775;
			     i_625 = i_2773;
			     goto loop_627;
			  }
		       }
		  }
		  {
		     obj_t provided_636;
		     provided_636 = provided_74;
		   loop_637:
		     if (NULLP(provided_636))
		       {
			  CNST_TABLE_REF(((long) 6));
		       }
		     else
		       {
			  obj_t p_639;
			  p_639 = CAR(provided_636);
			  {
			     obj_t s_name_91_640;
			     obj_t value_641;
			     obj_t s_name_91_643;
			     obj_t len_644;
			     obj_t value_645;
			     if (PAIRP(p_639))
			       {
				  obj_t cdr_177_60_650;
				  cdr_177_60_650 = CDR(p_639);
				  if (PAIRP(cdr_177_60_650))
				    {
				       bool_t test_2786;
				       {
					  obj_t aux_2787;
					  aux_2787 = CDR(cdr_177_60_650);
					  test_2786 = (aux_2787 == BNIL);
				       }
				       if (test_2786)
					 {
					    s_name_91_640 = CAR(p_639);
					    value_641 = CAR(cdr_177_60_650);
					    {
					       obj_t pval_666;
					       {
						  obj_t arg1367_668;
						  arg1367_668 = find_slot_offset_2448_137_expand_object(slots_620, form_72, s_name_91_640);
						  {
						     long aux_2791;
						     aux_2791 = (long) CINT(arg1367_668);
						     pval_666 = VECTOR_REF(vargs_622, aux_2791);
						  }
					       }
					       SET_CAR(pval_666, BTRUE);
					       {
						  obj_t arg1365_667;
						  arg1365_667 = epairify_expand_object(value_641, p_639);
						  SET_CDR(pval_666, arg1365_667);
					       }
					    }
					 }
				       else
					 {
					    obj_t cdr_199_216_656;
					    cdr_199_216_656 = CDR(cdr_177_60_650);
					    if (PAIRP(cdr_199_216_656))
					      {
						 bool_t test_2802;
						 {
						    obj_t aux_2803;
						    aux_2803 = CDR(cdr_199_216_656);
						    test_2802 = (aux_2803 == BNIL);
						 }
						 if (test_2802)
						   {
						      s_name_91_643 = CAR(p_639);
						      len_644 = CAR(cdr_177_60_650);
						      value_645 = CAR(cdr_199_216_656);
						      {
							 obj_t snum_669;
							 snum_669 = find_slot_offset_2448_137_expand_object(slots_620, form_72, s_name_91_643);
							 {
							    {
							       bool_t test_2807;
							       {
								  obj_t aux_2808;
								  {
								     obj_t aux_2809;
								     aux_2809 = list_ref_194___r4_pairs_and_lists_6_3(slots_620, (long) CINT(snum_669));
								     aux_2808 = STRUCT_REF(aux_2809, ((long) 5));
								  }
								  test_2807 = CBOOL(aux_2808);
							       }
							       if (test_2807)
								 {
								    obj_t pval_672;
								    {
								       long aux_2814;
								       aux_2814 = (long) CINT(snum_669);
								       pval_672 = VECTOR_REF(vargs_622, aux_2814);
								    }
								    {
								       obj_t plen_673;
								       {
									  long aux_2817;
									  {
									     long aux_2818;
									     aux_2818 = (long) CINT(snum_669);
									     aux_2817 = (aux_2818 - ((long) 1));
									  }
									  plen_673 = VECTOR_REF(vargs_622, aux_2817);
								       }
								       {
									  SET_CAR(pval_672, BTRUE);
									  {
									     obj_t arg1369_674;
									     arg1369_674 = epairify_expand_object(value_645, p_639);
									     SET_CDR(pval_672, arg1369_674);
									  }
									  SET_CAR(plen_673, BTRUE);
									  SET_CDR(plen_673, len_644);
								       }
								    }
								 }
							       else
								 {
								    FAILURE(BFALSE, string2450_expand_object, form_72);
								 }
							    }
							 }
						      }
						   }
						 else
						   {
						    tag_169_222_647:
						      FAILURE(BFALSE, string2450_expand_object, form_72);
						   }
					      }
					    else
					      {
						 goto tag_169_222_647;
					      }
					 }
				    }
				  else
				    {
				       goto tag_169_222_647;
				    }
			       }
			     else
			       {
				  goto tag_169_222_647;
			       }
			  }
			  {
			     obj_t provided_2832;
			     provided_2832 = CDR(provided_636);
			     provided_636 = provided_2832;
			     goto loop_637;
			  }
		       }
		  }
		  {
		     long i_677;
		     obj_t s_678;
		     i_677 = ((long) 0);
		     s_678 = slots_620;
		   loop_679:
		     if ((i_677 == len_621))
		       {
			  CNST_TABLE_REF(((long) 7));
		       }
		     else
		       {
			  bool_t test_2837;
			  {
			     bool_t test_2838;
			     {
				obj_t aux_2839;
				{
				   obj_t aux_2840;
				   aux_2840 = VECTOR_REF(vargs_622, i_677);
				   aux_2839 = CAR(aux_2840);
				}
				test_2838 = CBOOL(aux_2839);
			     }
			     if (test_2838)
			       {
				  test_2837 = ((bool_t) 0);
			       }
			     else
			       {
				  bool_t test_2844;
				  {
				     obj_t aux_2845;
				     {
					obj_t aux_2846;
					aux_2846 = CAR(s_678);
					aux_2845 = STRUCT_REF(aux_2846, ((long) 11));
				     }
				     test_2844 = CBOOL(aux_2845);
				  }
				  if (test_2844)
				    {
				       test_2837 = ((bool_t) 0);
				    }
				  else
				    {
				       test_2837 = ((bool_t) 1);
				    }
			       }
			  }
			  if (test_2837)
			    {
			       {
				  obj_t arg1375_682;
				  {
				     obj_t arg1379_684;
				     {
					obj_t aux_2850;
					{
					   obj_t aux_2851;
					   aux_2851 = CAR(s_678);
					   aux_2850 = STRUCT_REF(aux_2851, ((long) 0));
					}
					arg1379_684 = SYMBOL_TO_STRING(aux_2850);
				     }
				     {
					obj_t list1382_686;
					{
					   obj_t arg1383_687;
					   {
					      obj_t arg1384_688;
					      arg1384_688 = MAKE_PAIR(string2451_expand_object, BNIL);
					      arg1383_687 = MAKE_PAIR(arg1379_684, arg1384_688);
					   }
					   list1382_686 = MAKE_PAIR(string2452_expand_object, arg1383_687);
					}
					arg1375_682 = string_append_106___r4_strings_6_7(list1382_686);
				     }
				  }
				  FAILURE(BFALSE, arg1375_682, form_72);
			       }
			    }
			  else
			    {
			       {
				  obj_t s_2862;
				  long i_2860;
				  i_2860 = (i_677 + ((long) 1));
				  s_2862 = CDR(s_678);
				  s_678 = s_2862;
				  i_677 = i_2860;
				  goto loop_679;
			       }
			    }
		       }
		  }
		  {
		     long i_698;
		     obj_t slots_699;
		     obj_t largs_700;
		     obj_t virtuals_701;
		     i_698 = ((long) 0);
		     slots_699 = slots_620;
		     largs_700 = BNIL;
		     virtuals_701 = BNIL;
		   loop_702:
		     if ((i_698 == len_621))
		       {
			  obj_t make_name_208_707;
			  {
			     obj_t arg1433_735;
			     arg1433_735 = CNST_TABLE_REF(((long) 8));
			     {
				obj_t list1437_737;
				{
				   obj_t arg1438_738;
				   {
				      obj_t aux_2867;
				      aux_2867 = (((type_t) CREF(class_73))->id);
				      arg1438_738 = MAKE_PAIR(aux_2867, BNIL);
				   }
				   list1437_737 = MAKE_PAIR(arg1433_735, arg1438_738);
				}
				make_name_208_707 = symbol_append_197___r4_symbols_6_4(list1437_737);
			     }
			  }
			  {
			     obj_t alloc_708;
			     {
				obj_t arg1423_728;
				{
				   obj_t arg1427_731;
				   obj_t arg1428_732;
				   arg1427_731 = reverse__39___r4_pairs_and_lists_6_3(largs_700);
				   arg1428_732 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
				   arg1423_728 = append_2_18___r4_pairs_and_lists_6_3(arg1427_731, arg1428_732);
				}
				{
				   obj_t list1424_729;
				   list1424_729 = MAKE_PAIR(arg1423_728, BNIL);
				   alloc_708 = cons__138___r4_pairs_and_lists_6_3(make_name_208_707, list1424_729);
				}
			     }
			     {
				if (NULLP(virtuals_701))
				  {
				     return alloc_708;
				  }
				else
				  {
				     obj_t arg1401_710;
				     obj_t arg1402_711;
				     obj_t arg1403_712;
				     arg1401_710 = CNST_TABLE_REF(((long) 1));
				     {
					obj_t arg1408_716;
					{
					   obj_t list1415_721;
					   {
					      obj_t arg1416_722;
					      arg1416_722 = MAKE_PAIR(BNIL, BNIL);
					      list1415_721 = MAKE_PAIR(alloc_708, arg1416_722);
					   }
					   arg1408_716 = cons__138___r4_pairs_and_lists_6_3(new_623, list1415_721);
					}
					{
					   obj_t list1411_718;
					   list1411_718 = MAKE_PAIR(BNIL, BNIL);
					   arg1402_711 = cons__138___r4_pairs_and_lists_6_3(arg1408_716, list1411_718);
					}
				     }
				     {
					obj_t arg1418_724;
					{
					   obj_t list1420_726;
					   list1420_726 = MAKE_PAIR(BNIL, BNIL);
					   arg1418_724 = cons__138___r4_pairs_and_lists_6_3(new_623, list1420_726);
					}
					arg1403_712 = append_2_18___r4_pairs_and_lists_6_3(virtuals_701, arg1418_724);
				     }
				     {
					obj_t list1404_713;
					{
					   obj_t arg1405_714;
					   arg1405_714 = MAKE_PAIR(arg1403_712, BNIL);
					   list1404_713 = MAKE_PAIR(arg1402_711, arg1405_714);
					}
					return cons__138___r4_pairs_and_lists_6_3(arg1401_710, list1404_713);
				     }
				  }
			     }
			  }
		       }
		     else
		       {
			  obj_t value_740;
			  {
			     obj_t aux_2891;
			     aux_2891 = VECTOR_REF(vargs_622, i_698);
			     value_740 = CDR(aux_2891);
			  }
			  {
			     bool_t test_2894;
			     {
				obj_t aux_2895;
				{
				   obj_t aux_2896;
				   aux_2896 = CAR(slots_699);
				   aux_2895 = STRUCT_REF(aux_2896, ((long) 11));
				}
				test_2894 = CBOOL(aux_2895);
			     }
			     if (test_2894)
			       {
				  {
				     long arg1443_742;
				     obj_t arg1444_743;
				     obj_t arg1446_744;
				     arg1443_742 = (i_698 + ((long) 1));
				     arg1444_743 = CDR(slots_699);
				     if ((value_740 == BUNSPEC))
				       {
					  arg1446_744 = virtuals_701;
				       }
				     else
				       {
					  obj_t arg1448_746;
					  arg1448_746 = make_virtual_set_218_expand_object(CAR(slots_699), value_740, new_623, (obj_t) (class_73), form_72, "instantiate");
					  arg1446_744 = MAKE_PAIR(arg1448_746, virtuals_701);
				       }
				     {
					obj_t virtuals_2910;
					obj_t slots_2909;
					long i_2908;
					i_2908 = arg1443_742;
					slots_2909 = arg1444_743;
					virtuals_2910 = arg1446_744;
					virtuals_701 = virtuals_2910;
					slots_699 = slots_2909;
					i_698 = i_2908;
					goto loop_702;
				     }
				  }
			       }
			     else
			       {
				  {
				     long arg1453_749;
				     obj_t arg1454_750;
				     obj_t arg1455_751;
				     arg1453_749 = (i_698 + ((long) 1));
				     arg1454_750 = CDR(slots_699);
				     arg1455_751 = MAKE_PAIR(value_740, largs_700);
				     {
					obj_t largs_2916;
					obj_t slots_2915;
					long i_2914;
					i_2914 = arg1453_749;
					slots_2915 = arg1454_750;
					largs_2916 = arg1455_751;
					largs_700 = largs_2916;
					slots_699 = slots_2915;
					i_698 = i_2914;
					goto loop_702;
				     }
				  }
			       }
			  }
		       }
		  }
	       }
	    }
	 }
      }
   }
}


/* find-slot-offset_2448 */ obj_t 
find_slot_offset_2448_137_expand_object(obj_t slots_2491, obj_t form_2490, obj_t s_name_91_754)
{
   {
      obj_t slots_756;
      long i_757;
      slots_756 = slots_2491;
      i_757 = ((long) 0);
    loop_758:
      if (NULLP(slots_756))
	{
	   {
	      obj_t arg1461_760;
	      {
		 obj_t arg1464_762;
		 arg1464_762 = SYMBOL_TO_STRING(s_name_91_754);
		 {
		    obj_t list1466_764;
		    {
		       obj_t arg1467_765;
		       {
			  obj_t arg1468_766;
			  arg1468_766 = MAKE_PAIR(string2451_expand_object, BNIL);
			  arg1467_765 = MAKE_PAIR(arg1464_762, arg1468_766);
		       }
		       list1466_764 = MAKE_PAIR(string2453_expand_object, arg1467_765);
		    }
		    arg1461_760 = string_append_106___r4_strings_6_7(list1466_764);
		 }
	      }
	      FAILURE(BFALSE, arg1461_760, form_2490);
	   }
	}
      else
	{
	   bool_t test_2925;
	   {
	      obj_t aux_2926;
	      {
		 obj_t aux_2927;
		 aux_2927 = CAR(slots_756);
		 aux_2926 = STRUCT_REF(aux_2927, ((long) 0));
	      }
	      test_2925 = (aux_2926 == s_name_91_754);
	   }
	   if (test_2925)
	     {
		return BINT(i_757);
	     }
	   else
	     {
		{
		   long i_2934;
		   obj_t slots_2932;
		   slots_2932 = CDR(slots_756);
		   i_2934 = (i_757 + ((long) 1));
		   i_757 = i_2934;
		   slots_756 = slots_2932;
		   goto loop_758;
		}
	     }
	}
   }
}


/* expand-duplicate */ obj_t 
expand_duplicate_139_expand_object(obj_t x_75, obj_t e_76)
{
   {
      obj_t duplicate_781;
      obj_t dup_782;
      obj_t prov_783;
      if (PAIRP(x_75))
	{
	   obj_t cdr_229_251_788;
	   cdr_229_251_788 = CDR(x_75);
	   if (PAIRP(cdr_229_251_788))
	     {
		duplicate_781 = CAR(x_75);
		dup_782 = CAR(cdr_229_251_788);
		prov_783 = CDR(cdr_229_251_788);
		{
		   obj_t id_type_89_793;
		   id_type_89_793 = parse_id_241_ast_ident(duplicate_781);
		   {
		      obj_t id_794;
		      id_794 = CAR(id_type_89_793);
		      {
			 obj_t class_795;
			 class_795 = CDR(id_type_89_793);
			 {
			    {
			       bool_t test1489_796;
			       test1489_796 = is_a__118___object(class_795, class_object_class);
			       if (test1489_796)
				 {
				    obj_t arg1490_797;
				    {
				       obj_t arg1491_798;
				       arg1491_798 = duplicate__make_94_expand_object(x_75, class_795, dup_782, prov_783);
				       arg1490_797 = PROCEDURE_ENTRY(e_76) (e_76, arg1491_798, e_76, BEOA);
				    }
				    return replace__160_tools_misc(x_75, arg1490_797);
				 }
			       else
				 {
				    obj_t arg1494_799;
				    {
				       obj_t arg1497_801;
				       arg1497_801 = SYMBOL_TO_STRING(id_794);
				       arg1494_799 = string_append(string2454_expand_object, arg1497_801);
				    }
				    FAILURE(BFALSE, arg1494_799, x_75);
				 }
			    }
			 }
		      }
		   }
		}
	     }
	   else
	     {
	      tag_220_216_785:
		FAILURE(BFALSE, string2455_expand_object, x_75);
	     }
	}
      else
	{
	   goto tag_220_216_785;
	}
   }
}


/* _expand-duplicate2444 */ obj_t 
_expand_duplicate2444_215_expand_object(obj_t env_2477, obj_t x_2478, obj_t e_2479)
{
   return expand_duplicate_139_expand_object(x_2478, e_2479);
}


/* duplicate->make */ obj_t 
duplicate__make_94_expand_object(obj_t form_77, obj_t class_78, obj_t duplicated_79, obj_t provided_80)
{
   {
      obj_t slots_802;
      {
	 bool_t test_2958;
	 {
	    class_t obj_2107;
	    obj_2107 = (class_t) (class_78);
	    {
	       obj_t aux_2960;
	       {
		  obj_t aux_2961;
		  {
		     object_t aux_2962;
		     aux_2962 = (object_t) (obj_2107);
		     aux_2961 = OBJECT_WIDENING(aux_2962);
		  }
		  aux_2960 = (((class_t) CREF(aux_2961))->widening);
	       }
	       test_2958 = CBOOL(aux_2960);
	    }
	 }
	 if (test_2958)
	   {
	      obj_t aux_2981;
	      obj_t aux_2967;
	      {
		 class_t obj_2110;
		 obj_2110 = (class_t) (class_78);
		 {
		    obj_t aux_2983;
		    {
		       object_t aux_2984;
		       aux_2984 = (object_t) (obj_2110);
		       aux_2983 = OBJECT_WIDENING(aux_2984);
		    }
		    aux_2981 = (((class_t) CREF(aux_2983))->slots);
		 }
	      }
	      {
		 class_t obj_2109;
		 {
		    obj_t aux_2968;
		    {
		       class_t obj_2108;
		       obj_2108 = (class_t) (class_78);
		       {
			  obj_t aux_2970;
			  {
			     object_t aux_2971;
			     aux_2971 = (object_t) (obj_2108);
			     aux_2970 = OBJECT_WIDENING(aux_2971);
			  }
			  aux_2968 = (((class_t) CREF(aux_2970))->its_super_214);
		       }
		    }
		    obj_2109 = (class_t) (aux_2968);
		 }
		 {
		    obj_t aux_2976;
		    {
		       object_t aux_2977;
		       aux_2977 = (object_t) (obj_2109);
		       aux_2976 = OBJECT_WIDENING(aux_2977);
		    }
		    aux_2967 = (((class_t) CREF(aux_2976))->slots);
		 }
	      }
	      slots_802 = append_2_18___r4_pairs_and_lists_6_3(aux_2967, aux_2981);
	   }
	 else
	   {
	      class_t obj_2111;
	      obj_2111 = (class_t) (class_78);
	      {
		 obj_t aux_2990;
		 {
		    object_t aux_2991;
		    aux_2991 = (object_t) (obj_2111);
		    aux_2990 = OBJECT_WIDENING(aux_2991);
		 }
		 slots_802 = (((class_t) CREF(aux_2990))->slots);
	      }
	   }
      }
      {
	 long len_803;
	 len_803 = list_length(slots_802);
	 {
	    obj_t dup_var_35_804;
	    {
	       obj_t arg1676_982;
	       arg1676_982 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 9)), BEOA);
	       dup_var_35_804 = mark_symbol_non_user__17_ast_ident(arg1676_982);
	    }
	    {
	       obj_t dup_var_typed_156_805;
	       {
		  obj_t list1670_978;
		  {
		     obj_t arg1672_979;
		     {
			obj_t arg1673_980;
			{
			   obj_t aux_3000;
			   {
			      type_t obj_2112;
			      obj_2112 = (type_t) (class_78);
			      aux_3000 = (((type_t) CREF(obj_2112))->id);
			   }
			   arg1673_980 = MAKE_PAIR(aux_3000, BNIL);
			}
			arg1672_979 = MAKE_PAIR(_4dots_199_tools_misc, arg1673_980);
		     }
		     list1670_978 = MAKE_PAIR(dup_var_35_804, arg1672_979);
		  }
		  dup_var_typed_156_805 = symbol_append_197___r4_symbols_6_4(list1670_978);
	       }
	       {
		  obj_t new_806;
		  new_806 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 5)), BEOA);
		  {
		     obj_t vargs_807;
		     vargs_807 = make_vector(len_803, BUNSPEC);
		     {
			{
			   obj_t provided_809;
			   provided_809 = provided_80;
			 loop_810:
			   if (NULLP(provided_809))
			     {
				CNST_TABLE_REF(((long) 6));
			     }
			   else
			     {
				obj_t p_812;
				p_812 = CAR(provided_809);
				{
				   obj_t s_name_91_813;
				   obj_t value_814;
				   obj_t s_name_91_816;
				   obj_t len_817;
				   obj_t value_818;
				   if (PAIRP(p_812))
				     {
					obj_t cdr_247_56_823;
					cdr_247_56_823 = CDR(p_812);
					if (PAIRP(cdr_247_56_823))
					  {
					     bool_t test_3020;
					     {
						obj_t aux_3021;
						aux_3021 = CDR(cdr_247_56_823);
						test_3020 = (aux_3021 == BNIL);
					     }
					     if (test_3020)
					       {
						  s_name_91_813 = CAR(p_812);
						  value_814 = CAR(cdr_247_56_823);
						  {
						     obj_t arg1517_839;
						     obj_t arg1518_840;
						     arg1517_839 = find_slot_offset_2447_171_expand_object(slots_802, form_77, s_name_91_813);
						     {
							obj_t arg1519_841;
							arg1519_841 = epairify_expand_object(value_814, p_812);
							arg1518_840 = MAKE_PAIR(BTRUE, arg1519_841);
						     }
						     {
							obj_t x_2495;
							{
							   long aux_3027;
							   aux_3027 = (long) CINT(arg1517_839);
							   x_2495 = VECTOR_SET(vargs_807, aux_3027, arg1518_840);
							}
							BUNSPEC;
						     }
						  }
					       }
					     else
					       {
						  obj_t cdr_269_208_829;
						  cdr_269_208_829 = CDR(cdr_247_56_823);
						  if (PAIRP(cdr_269_208_829))
						    {
						       bool_t test_3035;
						       {
							  obj_t aux_3036;
							  aux_3036 = CDR(cdr_269_208_829);
							  test_3035 = (aux_3036 == BNIL);
						       }
						       if (test_3035)
							 {
							    s_name_91_816 = CAR(p_812);
							    len_817 = CAR(cdr_247_56_823);
							    value_818 = CAR(cdr_269_208_829);
							    {
							       obj_t snum_842;
							       snum_842 = find_slot_offset_2447_171_expand_object(slots_802, form_77, s_name_91_816);
							       {
								  obj_t slot_843;
								  slot_843 = list_ref_194___r4_pairs_and_lists_6_3(slots_802, (long) CINT(snum_842));
								  {
								     {
									bool_t test_3042;
									{
									   bool_t test_3043;
									   {
									      obj_t aux_3044;
									      aux_3044 = STRUCT_REF(slot_843, ((long) 3));
									      test_3043 = CBOOL(aux_3044);
									   }
									   if (test_3043)
									     {
										test_3042 = ((bool_t) 1);
									     }
									   else
									     {
										obj_t aux_3047;
										aux_3047 = STRUCT_REF(slot_843, ((long) 5));
										test_3042 = CBOOL(aux_3047);
									     }
									}
									if (test_3042)
									  {
									     {
										obj_t arg1522_845;
										{
										   obj_t arg1524_846;
										   arg1524_846 = epairify_expand_object(value_818, p_812);
										   arg1522_845 = MAKE_PAIR(BTRUE, arg1524_846);
										}
										{
										   long aux_3052;
										   aux_3052 = (long) CINT(snum_842);
										   VECTOR_SET(vargs_807, aux_3052, arg1522_845);
										}
									     }
									     {
										long arg1525_847;
										obj_t arg1526_848;
										{
										   long aux_3055;
										   aux_3055 = (long) CINT(snum_842);
										   arg1525_847 = (aux_3055 - ((long) 1));
										}
										arg1526_848 = MAKE_PAIR(BFALSE, len_817);
										VECTOR_SET(vargs_807, arg1525_847, arg1526_848);
									     }
									  }
									else
									  {
									     FAILURE(BFALSE, string2455_expand_object, form_77);
									  }
								     }
								  }
							       }
							    }
							 }
						       else
							 {
							  tag_239_2_820:
							    FAILURE(BFALSE, string2455_expand_object, form_77);
							 }
						    }
						  else
						    {
						       goto tag_239_2_820;
						    }
					       }
					  }
					else
					  {
					     goto tag_239_2_820;
					  }
				     }
				   else
				     {
					goto tag_239_2_820;
				     }
				}
				{
				   obj_t provided_3065;
				   provided_3065 = CDR(provided_809);
				   provided_809 = provided_3065;
				   goto loop_810;
				}
			     }
			}
			{
			   long i_851;
			   obj_t slots_852;
			   i_851 = ((long) 0);
			   slots_852 = slots_802;
			 loop_853:
			   if (NULLP(slots_852))
			     {
				CNST_TABLE_REF(((long) 6));
			     }
			   else
			     {
				{
				   bool_t test_3070;
				   {
				      obj_t aux_3071;
				      aux_3071 = VECTOR_REF(vargs_807, i_851);
				      test_3070 = PAIRP(aux_3071);
				   }
				   if (test_3070)
				     {
					CNST_TABLE_REF(((long) 10));
				     }
				   else
				     {
					obj_t slot_857;
					slot_857 = CAR(slots_852);
					{
					   bool_t test_3076;
					   {
					      bool_t test_3077;
					      {
						 obj_t aux_3078;
						 aux_3078 = STRUCT_REF(slot_857, ((long) 5));
						 test_3077 = CBOOL(aux_3078);
					      }
					      if (test_3077)
						{
						   test_3076 = ((bool_t) 1);
						}
					      else
						{
						   obj_t aux_3081;
						   aux_3081 = STRUCT_REF(slot_857, ((long) 3));
						   test_3076 = CBOOL(aux_3081);
						}
					   }
					   if (test_3076)
					     {
						obj_t a_name_201_859;
						{
						   obj_t arg1542_868;
						   obj_t arg1545_869;
						   obj_t arg1548_870;
						   {
						      type_t obj_2174;
						      obj_2174 = (type_t) (class_78);
						      arg1542_868 = (((type_t) CREF(obj_2174))->id);
						   }
						   arg1545_869 = CNST_TABLE_REF(((long) 2));
						   arg1548_870 = STRUCT_REF(slot_857, ((long) 0));
						   {
						      obj_t list1550_872;
						      {
							 obj_t arg1552_873;
							 {
							    obj_t arg1553_874;
							    {
							       obj_t arg1554_875;
							       {
								  obj_t aux_3088;
								  aux_3088 = CNST_TABLE_REF(((long) 11));
								  arg1554_875 = MAKE_PAIR(aux_3088, BNIL);
							       }
							       arg1553_874 = MAKE_PAIR(arg1548_870, arg1554_875);
							    }
							    arg1552_873 = MAKE_PAIR(arg1545_869, arg1553_874);
							 }
							 list1550_872 = MAKE_PAIR(arg1542_868, arg1552_873);
						      }
						      a_name_201_859 = symbol_append_197___r4_symbols_6_4(list1550_872);
						   }
						}
						{
						   obj_t arg1532_860;
						   {
						      obj_t arg1533_861;
						      {
							 obj_t list1536_864;
							 {
							    obj_t arg1537_865;
							    {
							       obj_t arg1539_866;
							       arg1539_866 = MAKE_PAIR(BNIL, BNIL);
							       {
								  obj_t aux_3096;
								  aux_3096 = BINT(((long) 0));
								  arg1537_865 = MAKE_PAIR(aux_3096, arg1539_866);
							       }
							    }
							    list1536_864 = MAKE_PAIR(dup_var_35_804, arg1537_865);
							 }
							 arg1533_861 = cons__138___r4_pairs_and_lists_6_3(a_name_201_859, list1536_864);
						      }
						      arg1532_860 = MAKE_PAIR(BTRUE, arg1533_861);
						   }
						   VECTOR_SET(vargs_807, i_851, arg1532_860);
						}
					     }
					   else
					     {
						obj_t a_name_201_877;
						{
						   obj_t arg1562_884;
						   obj_t arg1563_885;
						   {
						      type_t obj_2183;
						      obj_2183 = (type_t) (class_78);
						      arg1562_884 = (((type_t) CREF(obj_2183))->id);
						   }
						   arg1563_885 = CNST_TABLE_REF(((long) 2));
						   {
						      obj_t list1565_887;
						      {
							 obj_t arg1566_888;
							 {
							    obj_t arg1568_889;
							    {
							       obj_t aux_3106;
							       aux_3106 = STRUCT_REF(slot_857, ((long) 0));
							       arg1568_889 = MAKE_PAIR(aux_3106, BNIL);
							    }
							    arg1566_888 = MAKE_PAIR(arg1563_885, arg1568_889);
							 }
							 list1565_887 = MAKE_PAIR(arg1562_884, arg1566_888);
						      }
						      a_name_201_877 = symbol_append_197___r4_symbols_6_4(list1565_887);
						   }
						}
						{
						   obj_t arg1556_878;
						   {
						      obj_t arg1557_879;
						      {
							 obj_t list1559_881;
							 {
							    obj_t arg1560_882;
							    arg1560_882 = MAKE_PAIR(BNIL, BNIL);
							    list1559_881 = MAKE_PAIR(dup_var_35_804, arg1560_882);
							 }
							 arg1557_879 = cons__138___r4_pairs_and_lists_6_3(a_name_201_877, list1559_881);
						      }
						      arg1556_878 = MAKE_PAIR(BTRUE, arg1557_879);
						   }
						   VECTOR_SET(vargs_807, i_851, arg1556_878);
						}
					     }
					}
				     }
				}
				{
				   obj_t slots_3119;
				   long i_3117;
				   i_3117 = (i_851 + ((long) 1));
				   slots_3119 = CDR(slots_852);
				   slots_852 = slots_3119;
				   i_851 = i_3117;
				   goto loop_853;
				}
			     }
			}
			{
			   long i_894;
			   obj_t slots_895;
			   obj_t largs_896;
			   obj_t virtuals_897;
			   i_894 = ((long) 0);
			   slots_895 = slots_802;
			   largs_896 = BNIL;
			   virtuals_897 = BNIL;
			 loop_898:
			   if ((i_894 == len_803))
			     {
				obj_t make_name_208_903;
				{
				   obj_t arg1622_936;
				   arg1622_936 = CNST_TABLE_REF(((long) 8));
				   {
				      obj_t list1624_938;
				      {
					 obj_t arg1625_939;
					 {
					    obj_t aux_3124;
					    {
					       type_t obj_2197;
					       obj_2197 = (type_t) (class_78);
					       aux_3124 = (((type_t) CREF(obj_2197))->id);
					    }
					    arg1625_939 = MAKE_PAIR(aux_3124, BNIL);
					 }
					 list1624_938 = MAKE_PAIR(arg1622_936, arg1625_939);
				      }
				      make_name_208_903 = symbol_append_197___r4_symbols_6_4(list1624_938);
				   }
				}
				{
				   obj_t alloc_904;
				   {
				      obj_t arg1612_929;
				      {
					 obj_t arg1617_932;
					 obj_t arg1618_933;
					 arg1617_932 = reverse__39___r4_pairs_and_lists_6_3(largs_896);
					 arg1618_933 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
					 arg1612_929 = append_2_18___r4_pairs_and_lists_6_3(arg1617_932, arg1618_933);
				      }
				      {
					 obj_t list1613_930;
					 list1613_930 = MAKE_PAIR(arg1612_929, BNIL);
					 alloc_904 = cons__138___r4_pairs_and_lists_6_3(make_name_208_903, list1613_930);
				      }
				   }
				   {
				      {
					 obj_t arg1582_905;
					 obj_t arg1583_906;
					 obj_t arg1584_907;
					 arg1582_905 = CNST_TABLE_REF(((long) 12));
					 {
					    obj_t arg1588_911;
					    obj_t arg1589_912;
					    {
					       obj_t list1599_918;
					       {
						  obj_t arg1600_919;
						  arg1600_919 = MAKE_PAIR(BNIL, BNIL);
						  list1599_918 = MAKE_PAIR(duplicated_79, arg1600_919);
					       }
					       arg1588_911 = cons__138___r4_pairs_and_lists_6_3(dup_var_typed_156_805, list1599_918);
					    }
					    {
					       obj_t list1604_922;
					       {
						  obj_t arg1605_923;
						  arg1605_923 = MAKE_PAIR(BNIL, BNIL);
						  list1604_922 = MAKE_PAIR(alloc_904, arg1605_923);
					       }
					       arg1589_912 = cons__138___r4_pairs_and_lists_6_3(new_806, list1604_922);
					    }
					    {
					       obj_t list1593_914;
					       {
						  obj_t arg1594_915;
						  arg1594_915 = MAKE_PAIR(BNIL, BNIL);
						  list1593_914 = MAKE_PAIR(arg1589_912, arg1594_915);
					       }
					       arg1583_906 = cons__138___r4_pairs_and_lists_6_3(arg1588_911, list1593_914);
					    }
					 }
					 {
					    obj_t arg1607_925;
					    {
					       obj_t list1609_927;
					       list1609_927 = MAKE_PAIR(BNIL, BNIL);
					       arg1607_925 = cons__138___r4_pairs_and_lists_6_3(new_806, list1609_927);
					    }
					    arg1584_907 = append_2_18___r4_pairs_and_lists_6_3(virtuals_897, arg1607_925);
					 }
					 {
					    obj_t list1585_908;
					    {
					       obj_t arg1586_909;
					       arg1586_909 = MAKE_PAIR(arg1584_907, BNIL);
					       list1585_908 = MAKE_PAIR(arg1583_906, arg1586_909);
					    }
					    return cons__138___r4_pairs_and_lists_6_3(arg1582_905, list1585_908);
					 }
				      }
				   }
				}
			     }
			   else
			     {
				obj_t value_941;
				{
				   obj_t aux_3151;
				   aux_3151 = VECTOR_REF(vargs_807, i_894);
				   value_941 = CDR(aux_3151);
				}
				{
				   bool_t test_3154;
				   {
				      obj_t aux_3155;
				      {
					 obj_t aux_3156;
					 aux_3156 = CAR(slots_895);
					 aux_3155 = STRUCT_REF(aux_3156, ((long) 11));
				      }
				      test_3154 = CBOOL(aux_3155);
				   }
				   if (test_3154)
				     {
					{
					   long arg1630_943;
					   obj_t arg1632_944;
					   obj_t arg1633_945;
					   arg1630_943 = (i_894 + ((long) 1));
					   arg1632_944 = CDR(slots_895);
					   {
					      obj_t arg1634_946;
					      arg1634_946 = make_virtual_set_218_expand_object(CAR(slots_895), value_941, new_806, class_78, form_77, "duplicate");
					      arg1633_945 = MAKE_PAIR(arg1634_946, virtuals_897);
					   }
					   {
					      obj_t virtuals_3167;
					      obj_t slots_3166;
					      long i_3165;
					      i_3165 = arg1630_943;
					      slots_3166 = arg1632_944;
					      virtuals_3167 = arg1633_945;
					      virtuals_897 = virtuals_3167;
					      slots_895 = slots_3166;
					      i_894 = i_3165;
					      goto loop_898;
					   }
					}
				     }
				   else
				     {
					{
					   long arg1639_949;
					   obj_t arg1640_950;
					   obj_t arg1641_951;
					   arg1639_949 = (i_894 + ((long) 1));
					   arg1640_950 = CDR(slots_895);
					   arg1641_951 = MAKE_PAIR(value_941, largs_896);
					   {
					      obj_t largs_3173;
					      obj_t slots_3172;
					      long i_3171;
					      i_3171 = arg1639_949;
					      slots_3172 = arg1640_950;
					      largs_3173 = arg1641_951;
					      largs_896 = largs_3173;
					      slots_895 = slots_3172;
					      i_894 = i_3171;
					      goto loop_898;
					   }
					}
				     }
				}
			     }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* find-slot-offset_2447 */ obj_t 
find_slot_offset_2447_171_expand_object(obj_t slots_2489, obj_t form_2488, obj_t s_name_91_954)
{
   {
      obj_t slots_956;
      long i_957;
      slots_956 = slots_2489;
      i_957 = ((long) 0);
    loop_958:
      if (NULLP(slots_956))
	{
	   {
	      obj_t arg1649_960;
	      {
		 obj_t arg1652_962;
		 arg1652_962 = SYMBOL_TO_STRING(s_name_91_954);
		 {
		    obj_t list1654_964;
		    {
		       obj_t arg1655_965;
		       {
			  obj_t arg1656_966;
			  arg1656_966 = MAKE_PAIR(string2451_expand_object, BNIL);
			  arg1655_965 = MAKE_PAIR(arg1652_962, arg1656_966);
		       }
		       list1654_964 = MAKE_PAIR(string2456_expand_object, arg1655_965);
		    }
		    arg1649_960 = string_append_106___r4_strings_6_7(list1654_964);
		 }
	      }
	      FAILURE(BFALSE, arg1649_960, form_2488);
	   }
	}
      else
	{
	   bool_t test_3182;
	   {
	      obj_t aux_3183;
	      {
		 obj_t aux_3184;
		 aux_3184 = CAR(slots_956);
		 aux_3183 = STRUCT_REF(aux_3184, ((long) 0));
	      }
	      test_3182 = (aux_3183 == s_name_91_954);
	   }
	   if (test_3182)
	     {
		return BINT(i_957);
	     }
	   else
	     {
		{
		   long i_3191;
		   obj_t slots_3189;
		   slots_3189 = CDR(slots_956);
		   i_3191 = (i_957 + ((long) 1));
		   i_957 = i_3191;
		   slots_956 = slots_3189;
		   goto loop_958;
		}
	     }
	}
   }
}


/* expand-widen! */ obj_t 
expand_widen__163_expand_object(obj_t x_81, obj_t e_82)
{
   {
      obj_t widen__231_988;
      obj_t obj_989;
      obj_t provided_990;
      if (PAIRP(x_81))
	{
	   obj_t cdr_299_139_995;
	   cdr_299_139_995 = CDR(x_81);
	   if (PAIRP(cdr_299_139_995))
	     {
		widen__231_988 = CAR(x_81);
		obj_989 = CAR(cdr_299_139_995);
		provided_990 = CDR(cdr_299_139_995);
		{
		   type_t class_1000;
		   class_1000 = type_of_id_183_ast_ident(widen__231_988);
		   {
		      bool_t test1687_1001;
		      {
			 bool_t test1695_1008;
			 test1695_1008 = is_a__118___object((obj_t) (class_1000), class_object_class);
			 if (test1695_1008)
			   {
			      class_t obj_2237;
			      obj_2237 = (class_t) (class_1000);
			      {
				 obj_t aux_3203;
				 {
				    obj_t aux_3204;
				    {
				       object_t aux_3205;
				       aux_3205 = (object_t) (obj_2237);
				       aux_3204 = OBJECT_WIDENING(aux_3205);
				    }
				    aux_3203 = (((class_t) CREF(aux_3204))->widening);
				 }
				 test1687_1001 = CBOOL(aux_3203);
			      }
			   }
			 else
			   {
			      test1687_1001 = ((bool_t) 0);
			   }
		      }
		      if (test1687_1001)
			{
			   obj_t arg1688_1002;
			   {
			      obj_t arg1689_1003;
			      arg1689_1003 = make_widening_107_expand_object(x_81, class_1000, obj_989, provided_990);
			      arg1688_1002 = PROCEDURE_ENTRY(e_82) (e_82, arg1689_1003, e_82, BEOA);
			   }
			   return replace__160_tools_misc(x_81, arg1688_1002);
			}
		      else
			{
			   obj_t arg1691_1004;
			   {
			      obj_t arg1693_1006;
			      {
				 obj_t aux_3215;
				 aux_3215 = (((type_t) CREF(class_1000))->id);
				 arg1693_1006 = SYMBOL_TO_STRING(aux_3215);
			      }
			      arg1691_1004 = string_append(string2457_expand_object, arg1693_1006);
			   }
			   FAILURE(BFALSE, arg1691_1004, x_81);
			}
		   }
		}
	     }
	   else
	     {
	      tag_290_159_992:
		FAILURE(BFALSE, string2458_expand_object, x_81);
	     }
	}
      else
	{
	   goto tag_290_159_992;
	}
   }
}


/* _expand-widen!2445 */ obj_t 
_expand_widen_2445_225_expand_object(obj_t env_2480, obj_t x_2481, obj_t e_2482)
{
   return expand_widen__163_expand_object(x_2481, e_2482);
}


/* make-widening */ obj_t 
make_widening_107_expand_object(obj_t form_83, type_t class_84, obj_t obj_85, obj_t provided_86)
{
   {
      obj_t slots_1009;
      {
	 class_t obj_2246;
	 obj_2246 = (class_t) (class_84);
	 {
	    obj_t aux_3226;
	    {
	       object_t aux_3227;
	       aux_3227 = (object_t) (obj_2246);
	       aux_3226 = OBJECT_WIDENING(aux_3227);
	    }
	    slots_1009 = (((class_t) CREF(aux_3226))->slots);
	 }
      }
      {
	 global_t holder_1010;
	 {
	    class_t obj_2247;
	    obj_2247 = (class_t) (class_84);
	    {
	       obj_t aux_3232;
	       {
		  object_t aux_3233;
		  aux_3233 = (object_t) (obj_2247);
		  aux_3232 = OBJECT_WIDENING(aux_3233);
	       }
	       holder_1010 = (((class_t) CREF(aux_3232))->holder);
	    }
	 }
	 {
	    long len_1011;
	    len_1011 = list_length(slots_1009);
	    {
	       obj_t vargs_1012;
	       vargs_1012 = make_vector(len_1011, BUNSPEC);
	       {
		  obj_t dup_var_35_1013;
		  {
		     obj_t arg2105_1407;
		     arg2105_1407 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 13)), BEOA);
		     dup_var_35_1013 = mark_symbol_non_user__17_ast_ident(arg2105_1407);
		  }
		  {
		     obj_t dup_var_typed_156_1014;
		     {
			obj_t list2100_1403;
			{
			   obj_t arg2101_1404;
			   {
			      obj_t arg2102_1405;
			      {
				 obj_t aux_3243;
				 aux_3243 = (((type_t) CREF(class_84))->id);
				 arg2102_1405 = MAKE_PAIR(aux_3243, BNIL);
			      }
			      arg2101_1404 = MAKE_PAIR(_4dots_199_tools_misc, arg2102_1405);
			   }
			   list2100_1403 = MAKE_PAIR(dup_var_35_1013, arg2101_1404);
			}
			dup_var_typed_156_1014 = symbol_append_197___r4_symbols_6_4(list2100_1403);
		     }
		     {
			obj_t pragma_typed_60_1015;
			{
			   obj_t arg2093_1396;
			   arg2093_1396 = CNST_TABLE_REF(((long) 14));
			   {
			      obj_t list2095_1398;
			      {
				 obj_t arg2096_1399;
				 {
				    obj_t arg2097_1400;
				    {
				       obj_t aux_3250;
				       aux_3250 = (((type_t) CREF(class_84))->id);
				       arg2097_1400 = MAKE_PAIR(aux_3250, BNIL);
				    }
				    arg2096_1399 = MAKE_PAIR(_4dots_199_tools_misc, arg2097_1400);
				 }
				 list2095_1398 = MAKE_PAIR(arg2093_1396, arg2096_1399);
			      }
			      pragma_typed_60_1015 = symbol_append_197___r4_symbols_6_4(list2095_1398);
			   }
			}
			{
			   obj_t pragma_format_172_1016;
			   {
			      obj_t arg2087_1390;
			      arg2087_1390 = (((type_t) CREF(class_84))->name);
			      {
				 obj_t list2089_1392;
				 {
				    obj_t arg2090_1393;
				    {
				       obj_t arg2091_1394;
				       arg2091_1394 = MAKE_PAIR(string2459_expand_object, BNIL);
				       arg2090_1393 = MAKE_PAIR(arg2087_1390, arg2091_1394);
				    }
				    list2089_1392 = MAKE_PAIR(string2460_expand_object, arg2090_1393);
				 }
				 pragma_format_172_1016 = string_append_106___r4_strings_6_7(list2089_1392);
			      }
			   }
			   {
			      {
				 long i_1018;
				 obj_t slots_1019;
				 i_1018 = ((long) 0);
				 slots_1019 = slots_1009;
			       loop_1020:
				 if (NULLP(slots_1019))
				   {
				      CNST_TABLE_REF(((long) 6));
				   }
				 else
				   {
				      obj_t s_1022;
				      s_1022 = CAR(slots_1019);
				      {
					 bool_t test_3265;
					 {
					    obj_t aux_3266;
					    aux_3266 = STRUCT_REF(s_1022, ((long) 8));
					    test_3265 = CBOOL(aux_3266);
					 }
					 if (test_3265)
					   {
					      obj_t arg1698_1024;
					      {
						 obj_t aux_3269;
						 aux_3269 = STRUCT_REF(s_1022, ((long) 9));
						 arg1698_1024 = MAKE_PAIR(BTRUE, aux_3269);
					      }
					      VECTOR_SET(vargs_1012, i_1018, arg1698_1024);
					   }
					 else
					   {
					      obj_t arg1700_1026;
					      arg1700_1026 = MAKE_PAIR(BFALSE, BUNSPEC);
					      VECTOR_SET(vargs_1012, i_1018, arg1700_1026);
					   }
				      }
				      {
					 obj_t slots_3277;
					 long i_3275;
					 i_3275 = (i_1018 + ((long) 1));
					 slots_3277 = CDR(slots_1019);
					 slots_1019 = slots_3277;
					 i_1018 = i_3275;
					 goto loop_1020;
				      }
				   }
			      }
			      {
				 obj_t provided_1029;
				 provided_1029 = provided_86;
			       loop_1030:
				 if (NULLP(provided_1029))
				   {
				      CNST_TABLE_REF(((long) 6));
				   }
				 else
				   {
				      obj_t p_1032;
				      p_1032 = CAR(provided_1029);
				      {
					 obj_t s_name_91_1033;
					 obj_t value_1034;
					 obj_t s_name_91_1036;
					 obj_t len_1037;
					 obj_t value_1038;
					 if (PAIRP(p_1032))
					   {
					      obj_t cdr_317_116_1043;
					      cdr_317_116_1043 = CDR(p_1032);
					      if (PAIRP(cdr_317_116_1043))
						{
						   bool_t test_3288;
						   {
						      obj_t aux_3289;
						      aux_3289 = CDR(cdr_317_116_1043);
						      test_3288 = (aux_3289 == BNIL);
						   }
						   if (test_3288)
						     {
							s_name_91_1033 = CAR(p_1032);
							value_1034 = CAR(cdr_317_116_1043);
							{
							   obj_t arg1720_1059;
							   obj_t arg1721_1060;
							   arg1720_1059 = find_slot_offset_103_expand_object(slots_1009, form_83, s_name_91_1033);
							   {
							      obj_t arg1722_1061;
							      arg1722_1061 = epairify_expand_object(value_1034, p_1032);
							      arg1721_1060 = MAKE_PAIR(BTRUE, arg1722_1061);
							   }
							   {
							      obj_t x_2497;
							      {
								 long aux_3295;
								 aux_3295 = (long) CINT(arg1720_1059);
								 x_2497 = VECTOR_SET(vargs_1012, aux_3295, arg1721_1060);
							      }
							      BUNSPEC;
							   }
							}
						     }
						   else
						     {
							obj_t cdr_339_142_1049;
							cdr_339_142_1049 = CDR(cdr_317_116_1043);
							if (PAIRP(cdr_339_142_1049))
							  {
							     bool_t test_3303;
							     {
								obj_t aux_3304;
								aux_3304 = CDR(cdr_339_142_1049);
								test_3303 = (aux_3304 == BNIL);
							     }
							     if (test_3303)
							       {
								  s_name_91_1036 = CAR(p_1032);
								  len_1037 = CAR(cdr_317_116_1043);
								  value_1038 = CAR(cdr_339_142_1049);
								  {
								     obj_t snum_1062;
								     snum_1062 = find_slot_offset_103_expand_object(slots_1009, form_83, s_name_91_1036);
								     {
									obj_t slot_1063;
									slot_1063 = list_ref_194___r4_pairs_and_lists_6_3(slots_1009, (long) CINT(snum_1062));
									{
									   {
									      bool_t test_3310;
									      {
										 bool_t test_3311;
										 {
										    obj_t aux_3312;
										    aux_3312 = STRUCT_REF(slot_1063, ((long) 3));
										    test_3311 = CBOOL(aux_3312);
										 }
										 if (test_3311)
										   {
										      test_3310 = ((bool_t) 1);
										   }
										 else
										   {
										      obj_t aux_3315;
										      aux_3315 = STRUCT_REF(slot_1063, ((long) 5));
										      test_3310 = CBOOL(aux_3315);
										   }
									      }
									      if (test_3310)
										{
										   {
										      obj_t arg1724_1065;
										      {
											 obj_t arg1725_1066;
											 arg1725_1066 = epairify_expand_object(value_1038, p_1032);
											 arg1724_1065 = MAKE_PAIR(BTRUE, arg1725_1066);
										      }
										      {
											 long aux_3320;
											 aux_3320 = (long) CINT(snum_1062);
											 VECTOR_SET(vargs_1012, aux_3320, arg1724_1065);
										      }
										   }
										   {
										      long arg1726_1067;
										      obj_t arg1727_1068;
										      {
											 long aux_3323;
											 aux_3323 = (long) CINT(snum_1062);
											 arg1726_1067 = (aux_3323 - ((long) 1));
										      }
										      arg1727_1068 = MAKE_PAIR(BFALSE, len_1037);
										      VECTOR_SET(vargs_1012, arg1726_1067, arg1727_1068);
										   }
										}
									      else
										{
										   FAILURE(BFALSE, string2458_expand_object, form_83);
										}
									   }
									}
								     }
								  }
							       }
							     else
							       {
								tag_309_102_1040:
								  FAILURE(BFALSE, string2458_expand_object, form_83);
							       }
							  }
							else
							  {
							     goto tag_309_102_1040;
							  }
						     }
						}
					      else
						{
						   goto tag_309_102_1040;
						}
					   }
					 else
					   {
					      goto tag_309_102_1040;
					   }
				      }
				      {
					 obj_t provided_3333;
					 provided_3333 = CDR(provided_1029);
					 provided_1029 = provided_3333;
					 goto loop_1030;
				      }
				   }
			      }
			      {
				 long i_1071;
				 obj_t s_1072;
				 i_1071 = ((long) 0);
				 s_1072 = slots_1009;
			       loop_1073:
				 if ((i_1071 == len_1011))
				   {
				      CNST_TABLE_REF(((long) 7));
				   }
				 else
				   {
				      bool_t test_3338;
				      {
					 bool_t test_3339;
					 {
					    obj_t aux_3340;
					    {
					       obj_t aux_3341;
					       aux_3341 = VECTOR_REF(vargs_1012, i_1071);
					       aux_3340 = CAR(aux_3341);
					    }
					    test_3339 = CBOOL(aux_3340);
					 }
					 if (test_3339)
					   {
					      test_3338 = ((bool_t) 0);
					   }
					 else
					   {
					      bool_t test_3345;
					      {
						 obj_t aux_3346;
						 {
						    obj_t aux_3347;
						    aux_3347 = CAR(s_1072);
						    aux_3346 = STRUCT_REF(aux_3347, ((long) 11));
						 }
						 test_3345 = CBOOL(aux_3346);
					      }
					      if (test_3345)
						{
						   test_3338 = ((bool_t) 0);
						}
					      else
						{
						   test_3338 = ((bool_t) 1);
						}
					   }
				      }
				      if (test_3338)
					{
					   {
					      obj_t arg1732_1076;
					      {
						 obj_t arg1738_1078;
						 {
						    obj_t aux_3351;
						    {
						       obj_t aux_3352;
						       aux_3352 = CAR(s_1072);
						       aux_3351 = STRUCT_REF(aux_3352, ((long) 0));
						    }
						    arg1738_1078 = SYMBOL_TO_STRING(aux_3351);
						 }
						 {
						    obj_t list1740_1080;
						    {
						       obj_t arg1743_1081;
						       {
							  obj_t arg1744_1082;
							  arg1744_1082 = MAKE_PAIR(string2451_expand_object, BNIL);
							  arg1743_1081 = MAKE_PAIR(arg1738_1078, arg1744_1082);
						       }
						       list1740_1080 = MAKE_PAIR(string2461_expand_object, arg1743_1081);
						    }
						    arg1732_1076 = string_append_106___r4_strings_6_7(list1740_1080);
						 }
					      }
					      FAILURE(BFALSE, arg1732_1076, form_83);
					   }
					}
				      else
					{
					   {
					      obj_t s_3363;
					      long i_3361;
					      i_3361 = (i_1071 + ((long) 1));
					      s_3363 = CDR(s_1072);
					      s_1072 = s_3363;
					      i_1071 = i_3361;
					      goto loop_1073;
					   }
					}
				   }
			      }
			      {
				 long i_1092;
				 obj_t slots_1093;
				 obj_t largs_1094;
				 obj_t virtuals_1095;
				 i_1092 = ((long) 0);
				 slots_1093 = slots_1009;
				 largs_1094 = BNIL;
				 virtuals_1095 = BNIL;
			       loop_1096:
				 if ((i_1092 == len_1011))
				   {
				      obj_t widening_1101;
				      {
					 obj_t arg2050_1348;
					 obj_t arg2051_1349;
					 {
					    class_t obj_2344;
					    obj_2344 = (class_t) (class_84);
					    {
					       obj_t aux_3368;
					       {
						  object_t aux_3369;
						  aux_3369 = (object_t) (obj_2344);
						  aux_3368 = OBJECT_WIDENING(aux_3369);
					       }
					       arg2050_1348 = (((class_t) CREF(aux_3368))->widening);
					    }
					 }
					 arg2051_1349 = CNST_TABLE_REF(((long) 2));
					 {
					    obj_t list2053_1351;
					    {
					       obj_t arg2054_1352;
					       {
						  obj_t arg2055_1353;
						  {
						     obj_t aux_3374;
						     aux_3374 = (((type_t) CREF(class_84))->id);
						     arg2055_1353 = MAKE_PAIR(aux_3374, BNIL);
						  }
						  arg2054_1352 = MAKE_PAIR(arg2051_1349, arg2055_1353);
					       }
					       list2053_1351 = MAKE_PAIR(arg2050_1348, arg2054_1352);
					    }
					    widening_1101 = symbol_append_197___r4_symbols_6_4(list2053_1351);
					 }
				      }
				      if (CBOOL(_unsafe_type__146_engine_param))
					{
					   obj_t arg1762_1102;
					   obj_t arg1765_1103;
					   obj_t arg1766_1104;
					   obj_t arg1767_1105;
					   obj_t arg1768_1106;
					   arg1762_1102 = CNST_TABLE_REF(((long) 1));
					   {
					      obj_t arg1774_1112;
					      {
						 obj_t arg1779_1116;
						 {
						    obj_t list1789_1122;
						    {
						       obj_t arg1790_1123;
						       {
							  obj_t arg1791_1124;
							  arg1791_1124 = MAKE_PAIR(BNIL, BNIL);
							  arg1790_1123 = MAKE_PAIR(obj_85, arg1791_1124);
						       }
						       list1789_1122 = MAKE_PAIR(pragma_format_172_1016, arg1790_1123);
						    }
						    arg1779_1116 = cons__138___r4_pairs_and_lists_6_3(pragma_typed_60_1015, list1789_1122);
						 }
						 {
						    obj_t list1781_1118;
						    {
						       obj_t arg1783_1119;
						       arg1783_1119 = MAKE_PAIR(BNIL, BNIL);
						       list1781_1118 = MAKE_PAIR(arg1779_1116, arg1783_1119);
						    }
						    arg1774_1112 = cons__138___r4_pairs_and_lists_6_3(dup_var_typed_156_1014, list1781_1118);
						 }
					      }
					      {
						 obj_t list1777_1114;
						 list1777_1114 = MAKE_PAIR(BNIL, BNIL);
						 arg1765_1103 = cons__138___r4_pairs_and_lists_6_3(arg1774_1112, list1777_1114);
					      }
					   }
					   {
					      obj_t arg1793_1126;
					      obj_t arg1794_1127;
					      arg1793_1126 = CNST_TABLE_REF(((long) 15));
					      {
						 obj_t arg1802_1133;
						 {
						    obj_t arg1805_1136;
						    obj_t arg1806_1137;
						    arg1805_1136 = reverse__39___r4_pairs_and_lists_6_3(largs_1094);
						    arg1806_1137 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
						    arg1802_1133 = append_2_18___r4_pairs_and_lists_6_3(arg1805_1136, arg1806_1137);
						 }
						 {
						    obj_t list1803_1134;
						    list1803_1134 = MAKE_PAIR(arg1802_1133, BNIL);
						    arg1794_1127 = cons__138___r4_pairs_and_lists_6_3(widening_1101, list1803_1134);
						 }
					      }
					      {
						 obj_t list1796_1129;
						 {
						    obj_t arg1797_1130;
						    {
						       obj_t arg1799_1131;
						       arg1799_1131 = MAKE_PAIR(BNIL, BNIL);
						       arg1797_1130 = MAKE_PAIR(arg1794_1127, arg1799_1131);
						    }
						    list1796_1129 = MAKE_PAIR(dup_var_35_1013, arg1797_1130);
						 }
						 arg1766_1104 = cons__138___r4_pairs_and_lists_6_3(arg1793_1126, list1796_1129);
					      }
					   }
					   {
					      obj_t arg1809_1140;
					      obj_t arg1810_1141;
					      {
						 obj_t arg1816_1147;
						 obj_t arg1817_1148;
						 obj_t arg1818_1149;
						 arg1816_1147 = CNST_TABLE_REF(((long) 16));
						 arg1817_1148 = CNST_TABLE_REF(((long) 17));
						 arg1818_1149 = CNST_TABLE_REF(((long) 18));
						 {
						    obj_t list1821_1151;
						    {
						       obj_t arg1822_1152;
						       {
							  obj_t arg1823_1153;
							  arg1823_1153 = MAKE_PAIR(BNIL, BNIL);
							  arg1822_1152 = MAKE_PAIR(arg1818_1149, arg1823_1153);
						       }
						       list1821_1151 = MAKE_PAIR(arg1817_1148, arg1822_1152);
						    }
						    arg1809_1140 = cons__138___r4_pairs_and_lists_6_3(arg1816_1147, list1821_1151);
						 }
					      }
					      {
						 obj_t arg1826_1155;
						 obj_t arg1827_1156;
						 {
						    obj_t arg1833_1161;
						    obj_t arg1834_1162;
						    obj_t arg1835_1163;
						    arg1833_1161 = CNST_TABLE_REF(((long) 16));
						    arg1834_1162 = CNST_TABLE_REF(((long) 19));
						    arg1835_1163 = CNST_TABLE_REF(((long) 18));
						    {
						       obj_t list1837_1165;
						       {
							  obj_t arg1838_1166;
							  {
							     obj_t arg1839_1167;
							     arg1839_1167 = MAKE_PAIR(BNIL, BNIL);
							     arg1838_1166 = MAKE_PAIR(arg1835_1163, arg1839_1167);
							  }
							  list1837_1165 = MAKE_PAIR(arg1834_1162, arg1838_1166);
						       }
						       arg1826_1155 = cons__138___r4_pairs_and_lists_6_3(arg1833_1161, list1837_1165);
						    }
						 }
						 {
						    obj_t arg1843_1169;
						    obj_t arg1847_1170;
						    obj_t arg1848_1171;
						    arg1843_1169 = CNST_TABLE_REF(((long) 16));
						    arg1847_1170 = (((global_t) CREF(holder_1010))->id);
						    arg1848_1171 = (((global_t) CREF(holder_1010))->module);
						    {
						       obj_t list1851_1173;
						       {
							  obj_t arg1852_1174;
							  {
							     obj_t arg1853_1175;
							     arg1853_1175 = MAKE_PAIR(BNIL, BNIL);
							     arg1852_1174 = MAKE_PAIR(arg1848_1171, arg1853_1175);
							  }
							  list1851_1173 = MAKE_PAIR(arg1847_1170, arg1852_1174);
						       }
						       arg1827_1156 = cons__138___r4_pairs_and_lists_6_3(arg1843_1169, list1851_1173);
						    }
						 }
						 {
						    obj_t list1830_1158;
						    {
						       obj_t arg1831_1159;
						       arg1831_1159 = MAKE_PAIR(BNIL, BNIL);
						       list1830_1158 = MAKE_PAIR(arg1827_1156, arg1831_1159);
						    }
						    arg1810_1141 = cons__138___r4_pairs_and_lists_6_3(arg1826_1155, list1830_1158);
						 }
					      }
					      {
						 obj_t list1812_1143;
						 {
						    obj_t arg1813_1144;
						    {
						       obj_t arg1814_1145;
						       arg1814_1145 = MAKE_PAIR(BNIL, BNIL);
						       arg1813_1144 = MAKE_PAIR(arg1810_1141, arg1814_1145);
						    }
						    list1812_1143 = MAKE_PAIR(dup_var_35_1013, arg1813_1144);
						 }
						 arg1767_1105 = cons__138___r4_pairs_and_lists_6_3(arg1809_1140, list1812_1143);
					      }
					   }
					   {
					      obj_t arg1857_1177;
					      {
						 obj_t list1859_1179;
						 list1859_1179 = MAKE_PAIR(BNIL, BNIL);
						 arg1857_1177 = cons__138___r4_pairs_and_lists_6_3(dup_var_35_1013, list1859_1179);
					      }
					      arg1768_1106 = append_2_18___r4_pairs_and_lists_6_3(virtuals_1095, arg1857_1177);
					   }
					   {
					      obj_t list1769_1107;
					      {
						 obj_t arg1770_1108;
						 {
						    obj_t arg1771_1109;
						    {
						       obj_t arg1772_1110;
						       arg1772_1110 = MAKE_PAIR(arg1768_1106, BNIL);
						       arg1771_1109 = MAKE_PAIR(arg1767_1105, arg1772_1110);
						    }
						    arg1770_1108 = MAKE_PAIR(arg1766_1104, arg1771_1109);
						 }
						 list1769_1107 = MAKE_PAIR(arg1765_1103, arg1770_1108);
					      }
					      return cons__138___r4_pairs_and_lists_6_3(arg1762_1102, list1769_1107);
					   }
					}
				      else
					{
					   obj_t arg1861_1181;
					   obj_t arg1862_1182;
					   obj_t arg1863_1183;
					   obj_t arg1864_1184;
					   arg1861_1181 = CNST_TABLE_REF(((long) 1));
					   {
					      obj_t arg1871_1191;
					      {
						 obj_t arg1877_1195;
						 {
						    obj_t list1884_1201;
						    {
						       obj_t arg1885_1202;
						       {
							  obj_t arg1886_1203;
							  arg1886_1203 = MAKE_PAIR(BNIL, BNIL);
							  arg1885_1202 = MAKE_PAIR(obj_85, arg1886_1203);
						       }
						       list1884_1201 = MAKE_PAIR(pragma_format_172_1016, arg1885_1202);
						    }
						    arg1877_1195 = cons__138___r4_pairs_and_lists_6_3(pragma_typed_60_1015, list1884_1201);
						 }
						 {
						    obj_t list1879_1197;
						    {
						       obj_t arg1880_1198;
						       arg1880_1198 = MAKE_PAIR(BNIL, BNIL);
						       list1879_1197 = MAKE_PAIR(arg1877_1195, arg1880_1198);
						    }
						    arg1871_1191 = cons__138___r4_pairs_and_lists_6_3(dup_var_typed_156_1014, list1879_1197);
						 }
					      }
					      {
						 obj_t list1875_1193;
						 list1875_1193 = MAKE_PAIR(BNIL, BNIL);
						 arg1862_1182 = cons__138___r4_pairs_and_lists_6_3(arg1871_1191, list1875_1193);
					      }
					   }
					   {
					      obj_t arg1888_1205;
					      obj_t arg1890_1206;
					      obj_t arg1892_1207;
					      arg1888_1205 = CNST_TABLE_REF(((long) 20));
					      {
						 obj_t arg1898_1213;
						 arg1898_1213 = CNST_TABLE_REF(((long) 21));
						 {
						    obj_t list1900_1215;
						    {
						       obj_t arg1901_1216;
						       arg1901_1216 = MAKE_PAIR(BNIL, BNIL);
						       list1900_1215 = MAKE_PAIR(dup_var_35_1013, arg1901_1216);
						    }
						    arg1890_1206 = cons__138___r4_pairs_and_lists_6_3(arg1898_1213, list1900_1215);
						 }
					      }
					      {
						 obj_t arg1903_1218;
						 arg1903_1218 = CNST_TABLE_REF(((long) 22));
						 {
						    obj_t list1906_1220;
						    {
						       obj_t arg1907_1221;
						       arg1907_1221 = MAKE_PAIR(BNIL, BNIL);
						       list1906_1220 = MAKE_PAIR(dup_var_35_1013, arg1907_1221);
						    }
						    arg1892_1207 = cons__138___r4_pairs_and_lists_6_3(arg1903_1218, list1906_1220);
						 }
					      }
					      {
						 obj_t list1894_1209;
						 {
						    obj_t arg1895_1210;
						    {
						       obj_t arg1896_1211;
						       arg1896_1211 = MAKE_PAIR(BNIL, BNIL);
						       arg1895_1210 = MAKE_PAIR(arg1892_1207, arg1896_1211);
						    }
						    list1894_1209 = MAKE_PAIR(arg1890_1206, arg1895_1210);
						 }
						 arg1863_1183 = cons__138___r4_pairs_and_lists_6_3(arg1888_1205, list1894_1209);
					      }
					   }
					   {
					      obj_t arg1910_1223;
					      obj_t arg1911_1224;
					      obj_t arg1912_1225;
					      obj_t arg1913_1226;
					      arg1910_1223 = CNST_TABLE_REF(((long) 20));
					      {
						 obj_t arg1920_1233;
						 obj_t arg1921_1234;
						 obj_t arg1923_1235;
						 arg1920_1233 = CNST_TABLE_REF(((long) 23));
						 {
						    obj_t arg1930_1241;
						    obj_t arg1931_1242;
						    {
						       obj_t arg1936_1247;
						       obj_t arg1937_1248;
						       obj_t arg1938_1249;
						       arg1936_1247 = CNST_TABLE_REF(((long) 16));
						       arg1937_1248 = CNST_TABLE_REF(((long) 24));
						       arg1938_1249 = CNST_TABLE_REF(((long) 18));
						       {
							  obj_t list1940_1251;
							  {
							     obj_t arg1941_1252;
							     {
								obj_t arg1942_1253;
								arg1942_1253 = MAKE_PAIR(BNIL, BNIL);
								arg1941_1252 = MAKE_PAIR(arg1938_1249, arg1942_1253);
							     }
							     list1940_1251 = MAKE_PAIR(arg1937_1248, arg1941_1252);
							  }
							  arg1930_1241 = cons__138___r4_pairs_and_lists_6_3(arg1936_1247, list1940_1251);
						       }
						    }
						    {
						       obj_t arg1944_1255;
						       obj_t arg1945_1256;
						       obj_t arg1947_1257;
						       arg1944_1255 = CNST_TABLE_REF(((long) 16));
						       arg1945_1256 = (((global_t) CREF(holder_1010))->id);
						       arg1947_1257 = (((global_t) CREF(holder_1010))->module);
						       {
							  obj_t list1949_1259;
							  {
							     obj_t arg1950_1260;
							     {
								obj_t arg1951_1261;
								arg1951_1261 = MAKE_PAIR(BNIL, BNIL);
								arg1950_1260 = MAKE_PAIR(arg1947_1257, arg1951_1261);
							     }
							     list1949_1259 = MAKE_PAIR(arg1945_1256, arg1950_1260);
							  }
							  arg1931_1242 = cons__138___r4_pairs_and_lists_6_3(arg1944_1255, list1949_1259);
						       }
						    }
						    {
						       obj_t list1933_1244;
						       {
							  obj_t arg1934_1245;
							  arg1934_1245 = MAKE_PAIR(BNIL, BNIL);
							  list1933_1244 = MAKE_PAIR(arg1931_1242, arg1934_1245);
						       }
						       arg1921_1234 = cons__138___r4_pairs_and_lists_6_3(arg1930_1241, list1933_1244);
						    }
						 }
						 {
						    obj_t arg1953_1263;
						    {
						       obj_t arg1958_1268;
						       obj_t arg1959_1269;
						       obj_t arg1960_1270;
						       arg1958_1268 = CNST_TABLE_REF(((long) 16));
						       arg1959_1269 = CNST_TABLE_REF(((long) 25));
						       arg1960_1270 = CNST_TABLE_REF(((long) 18));
						       {
							  obj_t list1962_1272;
							  {
							     obj_t arg1963_1273;
							     {
								obj_t arg1964_1274;
								arg1964_1274 = MAKE_PAIR(BNIL, BNIL);
								arg1963_1273 = MAKE_PAIR(arg1960_1270, arg1964_1274);
							     }
							     list1962_1272 = MAKE_PAIR(arg1959_1269, arg1963_1273);
							  }
							  arg1953_1263 = cons__138___r4_pairs_and_lists_6_3(arg1958_1268, list1962_1272);
						       }
						    }
						    {
						       obj_t list1955_1265;
						       {
							  obj_t arg1956_1266;
							  arg1956_1266 = MAKE_PAIR(BNIL, BNIL);
							  list1955_1265 = MAKE_PAIR(dup_var_35_1013, arg1956_1266);
						       }
						       arg1923_1235 = cons__138___r4_pairs_and_lists_6_3(arg1953_1263, list1955_1265);
						    }
						 }
						 {
						    obj_t list1925_1237;
						    {
						       obj_t arg1927_1238;
						       {
							  obj_t arg1928_1239;
							  arg1928_1239 = MAKE_PAIR(BNIL, BNIL);
							  arg1927_1238 = MAKE_PAIR(arg1923_1235, arg1928_1239);
						       }
						       list1925_1237 = MAKE_PAIR(arg1921_1234, arg1927_1238);
						    }
						    arg1911_1224 = cons__138___r4_pairs_and_lists_6_3(arg1920_1233, list1925_1237);
						 }
					      }
					      {
						 obj_t arg1967_1276;
						 obj_t arg1970_1277;
						 obj_t arg1971_1278;
						 obj_t arg1972_1279;
						 arg1967_1276 = CNST_TABLE_REF(((long) 26));
						 {
						    obj_t arg1978_1284;
						    obj_t arg1979_1285;
						    arg1978_1284 = CNST_TABLE_REF(((long) 15));
						    {
						       obj_t arg1985_1291;
						       {
							  obj_t arg1988_1294;
							  obj_t arg1989_1295;
							  arg1988_1294 = reverse__39___r4_pairs_and_lists_6_3(largs_1094);
							  arg1989_1295 = cons__138___r4_pairs_and_lists_6_3(BNIL, BNIL);
							  arg1985_1291 = append_2_18___r4_pairs_and_lists_6_3(arg1988_1294, arg1989_1295);
						       }
						       {
							  obj_t list1986_1292;
							  list1986_1292 = MAKE_PAIR(arg1985_1291, BNIL);
							  arg1979_1285 = cons__138___r4_pairs_and_lists_6_3(widening_1101, list1986_1292);
						       }
						    }
						    {
						       obj_t list1981_1287;
						       {
							  obj_t arg1982_1288;
							  {
							     obj_t arg1983_1289;
							     arg1983_1289 = MAKE_PAIR(BNIL, BNIL);
							     arg1982_1288 = MAKE_PAIR(arg1979_1285, arg1983_1289);
							  }
							  list1981_1287 = MAKE_PAIR(dup_var_35_1013, arg1982_1288);
						       }
						       arg1970_1277 = cons__138___r4_pairs_and_lists_6_3(arg1978_1284, list1981_1287);
						    }
						 }
						 {
						    obj_t arg1992_1298;
						    obj_t arg1993_1299;
						    {
						       obj_t arg2002_1305;
						       obj_t arg2003_1306;
						       obj_t arg2004_1307;
						       arg2002_1305 = CNST_TABLE_REF(((long) 16));
						       arg2003_1306 = CNST_TABLE_REF(((long) 17));
						       arg2004_1307 = CNST_TABLE_REF(((long) 18));
						       {
							  obj_t list2007_1309;
							  {
							     obj_t arg2008_1310;
							     {
								obj_t arg2010_1311;
								arg2010_1311 = MAKE_PAIR(BNIL, BNIL);
								arg2008_1310 = MAKE_PAIR(arg2004_1307, arg2010_1311);
							     }
							     list2007_1309 = MAKE_PAIR(arg2003_1306, arg2008_1310);
							  }
							  arg1992_1298 = cons__138___r4_pairs_and_lists_6_3(arg2002_1305, list2007_1309);
						       }
						    }
						    {
						       obj_t arg2012_1313;
						       obj_t arg2013_1314;
						       {
							  obj_t arg2018_1319;
							  obj_t arg2019_1320;
							  obj_t arg2020_1321;
							  arg2018_1319 = CNST_TABLE_REF(((long) 16));
							  arg2019_1320 = CNST_TABLE_REF(((long) 19));
							  arg2020_1321 = CNST_TABLE_REF(((long) 18));
							  {
							     obj_t list2022_1323;
							     {
								obj_t arg2023_1324;
								{
								   obj_t arg2024_1325;
								   arg2024_1325 = MAKE_PAIR(BNIL, BNIL);
								   arg2023_1324 = MAKE_PAIR(arg2020_1321, arg2024_1325);
								}
								list2022_1323 = MAKE_PAIR(arg2019_1320, arg2023_1324);
							     }
							     arg2012_1313 = cons__138___r4_pairs_and_lists_6_3(arg2018_1319, list2022_1323);
							  }
						       }
						       {
							  obj_t arg2027_1327;
							  obj_t arg2028_1328;
							  obj_t arg2029_1329;
							  arg2027_1327 = CNST_TABLE_REF(((long) 16));
							  arg2028_1328 = (((global_t) CREF(holder_1010))->id);
							  arg2029_1329 = (((global_t) CREF(holder_1010))->module);
							  {
							     obj_t list2031_1331;
							     {
								obj_t arg2032_1332;
								{
								   obj_t arg2033_1333;
								   arg2033_1333 = MAKE_PAIR(BNIL, BNIL);
								   arg2032_1332 = MAKE_PAIR(arg2029_1329, arg2033_1333);
								}
								list2031_1331 = MAKE_PAIR(arg2028_1328, arg2032_1332);
							     }
							     arg2013_1314 = cons__138___r4_pairs_and_lists_6_3(arg2027_1327, list2031_1331);
							  }
						       }
						       {
							  obj_t list2015_1316;
							  {
							     obj_t arg2016_1317;
							     arg2016_1317 = MAKE_PAIR(BNIL, BNIL);
							     list2015_1316 = MAKE_PAIR(arg2013_1314, arg2016_1317);
							  }
							  arg1993_1299 = cons__138___r4_pairs_and_lists_6_3(arg2012_1313, list2015_1316);
						       }
						    }
						    {
						       obj_t list1995_1301;
						       {
							  obj_t arg1998_1302;
							  {
							     obj_t arg2000_1303;
							     arg2000_1303 = MAKE_PAIR(BNIL, BNIL);
							     arg1998_1302 = MAKE_PAIR(arg1993_1299, arg2000_1303);
							  }
							  list1995_1301 = MAKE_PAIR(dup_var_35_1013, arg1998_1302);
						       }
						       arg1971_1278 = cons__138___r4_pairs_and_lists_6_3(arg1992_1298, list1995_1301);
						    }
						 }
						 {
						    obj_t arg2037_1335;
						    {
						       obj_t list2039_1337;
						       list2039_1337 = MAKE_PAIR(BNIL, BNIL);
						       arg2037_1335 = cons__138___r4_pairs_and_lists_6_3(dup_var_35_1013, list2039_1337);
						    }
						    arg1972_1279 = append_2_18___r4_pairs_and_lists_6_3(virtuals_1095, arg2037_1335);
						 }
						 {
						    obj_t list1973_1280;
						    {
						       obj_t arg1974_1281;
						       {
							  obj_t arg1975_1282;
							  arg1975_1282 = MAKE_PAIR(arg1972_1279, BNIL);
							  arg1974_1281 = MAKE_PAIR(arg1971_1278, arg1975_1282);
						       }
						       list1973_1280 = MAKE_PAIR(arg1970_1277, arg1974_1281);
						    }
						    arg1912_1225 = cons__138___r4_pairs_and_lists_6_3(arg1967_1276, list1973_1280);
						 }
					      }
					      {
						 obj_t arg2041_1339;
						 arg2041_1339 = CNST_TABLE_REF(((long) 27));
						 {
						    obj_t list2045_1343;
						    {
						       obj_t arg2046_1344;
						       {
							  obj_t arg2047_1345;
							  {
							     obj_t arg2048_1346;
							     arg2048_1346 = MAKE_PAIR(BNIL, BNIL);
							     arg2047_1345 = MAKE_PAIR(dup_var_35_1013, arg2048_1346);
							  }
							  arg2046_1344 = MAKE_PAIR(string2462_expand_object, arg2047_1345);
						       }
						       list2045_1343 = MAKE_PAIR(string2463_expand_object, arg2046_1344);
						    }
						    arg1913_1226 = cons__138___r4_pairs_and_lists_6_3(arg2041_1339, list2045_1343);
						 }
					      }
					      {
						 obj_t list1915_1228;
						 {
						    obj_t arg1916_1229;
						    {
						       obj_t arg1917_1230;
						       {
							  obj_t arg1918_1231;
							  arg1918_1231 = MAKE_PAIR(BNIL, BNIL);
							  arg1917_1230 = MAKE_PAIR(arg1913_1226, arg1918_1231);
						       }
						       arg1916_1229 = MAKE_PAIR(arg1912_1225, arg1917_1230);
						    }
						    list1915_1228 = MAKE_PAIR(arg1911_1224, arg1916_1229);
						 }
						 arg1864_1184 = cons__138___r4_pairs_and_lists_6_3(arg1910_1223, list1915_1228);
					      }
					   }
					   {
					      obj_t list1866_1186;
					      {
						 obj_t arg1867_1187;
						 {
						    obj_t arg1868_1188;
						    {
						       obj_t arg1869_1189;
						       arg1869_1189 = MAKE_PAIR(BNIL, BNIL);
						       arg1868_1188 = MAKE_PAIR(arg1864_1184, arg1869_1189);
						    }
						    arg1867_1187 = MAKE_PAIR(arg1863_1183, arg1868_1188);
						 }
						 list1866_1186 = MAKE_PAIR(arg1862_1182, arg1867_1187);
					      }
					      return cons__138___r4_pairs_and_lists_6_3(arg1861_1181, list1866_1186);
					   }
					}
				   }
				 else
				   {
				      obj_t value_1355;
				      {
					 obj_t aux_3556;
					 aux_3556 = VECTOR_REF(vargs_1012, i_1092);
					 value_1355 = CDR(aux_3556);
				      }
				      {
					 bool_t test_3559;
					 {
					    obj_t aux_3560;
					    {
					       obj_t aux_3561;
					       aux_3561 = CAR(slots_1093);
					       aux_3560 = STRUCT_REF(aux_3561, ((long) 11));
					    }
					    test_3559 = CBOOL(aux_3560);
					 }
					 if (test_3559)
					   {
					      {
						 long arg2058_1357;
						 obj_t arg2059_1358;
						 obj_t arg2060_1359;
						 arg2058_1357 = (i_1092 + ((long) 1));
						 arg2059_1358 = CDR(slots_1093);
						 if ((value_1355 == BUNSPEC))
						   {
						      arg2060_1359 = virtuals_1095;
						   }
						 else
						   {
						      obj_t arg2062_1361;
						      arg2062_1361 = make_virtual_set_218_expand_object(CAR(slots_1093), value_1355, dup_var_35_1013, (obj_t) (class_84), form_83, "widen!");
						      arg2060_1359 = MAKE_PAIR(arg2062_1361, virtuals_1095);
						   }
						 {
						    obj_t virtuals_3575;
						    obj_t slots_3574;
						    long i_3573;
						    i_3573 = arg2058_1357;
						    slots_3574 = arg2059_1358;
						    virtuals_3575 = arg2060_1359;
						    virtuals_1095 = virtuals_3575;
						    slots_1093 = slots_3574;
						    i_1092 = i_3573;
						    goto loop_1096;
						 }
					      }
					   }
					 else
					   {
					      {
						 long arg2065_1364;
						 obj_t arg2067_1365;
						 obj_t arg2068_1366;
						 arg2065_1364 = (i_1092 + ((long) 1));
						 arg2067_1365 = CDR(slots_1093);
						 arg2068_1366 = MAKE_PAIR(value_1355, largs_1094);
						 {
						    obj_t largs_3581;
						    obj_t slots_3580;
						    long i_3579;
						    i_3579 = arg2065_1364;
						    slots_3580 = arg2067_1365;
						    largs_3581 = arg2068_1366;
						    largs_1094 = largs_3581;
						    slots_1093 = slots_3580;
						    i_1092 = i_3579;
						    goto loop_1096;
						 }
					      }
					   }
				      }
				   }
			      }
			   }
			}
		     }
		  }
	       }
	    }
	 }
      }
   }
}


/* find-slot-offset */ obj_t 
find_slot_offset_103_expand_object(obj_t slots_2487, obj_t form_2486, obj_t s_name_91_1369)
{
   {
      obj_t slots_1371;
      long i_1372;
      slots_1371 = slots_2487;
      i_1372 = ((long) 0);
    loop_1373:
      if (NULLP(slots_1371))
	{
	   {
	      obj_t arg2073_1375;
	      {
		 obj_t arg2075_1377;
		 arg2075_1377 = SYMBOL_TO_STRING(s_name_91_1369);
		 {
		    obj_t list2077_1379;
		    {
		       obj_t arg2078_1380;
		       {
			  obj_t arg2079_1381;
			  arg2079_1381 = MAKE_PAIR(string2451_expand_object, BNIL);
			  arg2078_1380 = MAKE_PAIR(arg2075_1377, arg2079_1381);
		       }
		       list2077_1379 = MAKE_PAIR(string2464_expand_object, arg2078_1380);
		    }
		    arg2073_1375 = string_append_106___r4_strings_6_7(list2077_1379);
		 }
	      }
	      FAILURE(BFALSE, arg2073_1375, form_2486);
	   }
	}
      else
	{
	   bool_t test_3590;
	   {
	      obj_t aux_3591;
	      {
		 obj_t aux_3592;
		 aux_3592 = CAR(slots_1371);
		 aux_3591 = STRUCT_REF(aux_3592, ((long) 0));
	      }
	      test_3590 = (aux_3591 == s_name_91_1369);
	   }
	   if (test_3590)
	     {
		return BINT(i_1372);
	     }
	   else
	     {
		{
		   long i_3599;
		   obj_t slots_3597;
		   slots_3597 = CDR(slots_1371);
		   i_3599 = (i_1372 + ((long) 1));
		   i_1372 = i_3599;
		   slots_1371 = slots_3597;
		   goto loop_1373;
		}
	     }
	}
   }
}


/* expand-shrink! */ obj_t 
expand_shrink__128_expand_object(obj_t x_87, obj_t e_88)
{
   {
      if (PAIRP(x_87))
	{
	   obj_t cdr_365_142_1416;
	   cdr_365_142_1416 = CDR(x_87);
	   {
	      bool_t test_3604;
	      {
		 obj_t aux_3607;
		 obj_t aux_3605;
		 aux_3607 = CNST_TABLE_REF(((long) 22));
		 aux_3605 = CAR(x_87);
		 test_3604 = (aux_3605 == aux_3607);
	      }
	      if (test_3604)
		{
		   if (PAIRP(cdr_365_142_1416))
		     {
			bool_t test_3612;
			{
			   obj_t aux_3613;
			   aux_3613 = CDR(cdr_365_142_1416);
			   test_3612 = (aux_3613 == BNIL);
			}
			if (test_3612)
			  {
			     obj_t arg2120_2397;
			     arg2120_2397 = make_a_shrink__124_expand_object(e_88, CAR(cdr_365_142_1416));
			     return replace__160_tools_misc(x_87, arg2120_2397);
			  }
			else
			  {
			   tag_360_173_1413:
			     FAILURE(BFALSE, string2465_expand_object, x_87);
			  }
		     }
		   else
		     {
			goto tag_360_173_1413;
		     }
		}
	      else
		{
		   goto tag_360_173_1413;
		}
	   }
	}
      else
	{
	   goto tag_360_173_1413;
	}
   }
}


/* _expand-shrink!2446 */ obj_t 
_expand_shrink_2446_35_expand_object(obj_t env_2483, obj_t x_2484, obj_t e_2485)
{
   return expand_shrink__128_expand_object(x_2484, e_2485);
}


/* make-a-shrink! */ obj_t 
make_a_shrink__124_expand_object(obj_t e_89, obj_t o_90)
{
   {
      obj_t newo_1426;
      {
	 obj_t arg2363_1645;
	 arg2363_1645 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4) (gensym___r4_symbols_6_4, CNST_TABLE_REF(((long) 28)), BEOA);
	 newo_1426 = mark_symbol_non_user__17_ast_ident(arg2363_1645);
      }
      if (CBOOL(_unsafe_type__146_engine_param))
	{
	   obj_t arg2121_1427;
	   obj_t arg2122_1428;
	   obj_t arg2123_1429;
	   obj_t arg2124_1430;
	   arg2121_1427 = CNST_TABLE_REF(((long) 1));
	   {
	      obj_t arg2134_1438;
	      {
		 obj_t arg2138_1442;
		 arg2138_1442 = PROCEDURE_ENTRY(e_89) (e_89, o_90, e_89, BEOA);
		 {
		    obj_t list2140_1444;
		    {
		       obj_t arg2141_1445;
		       arg2141_1445 = MAKE_PAIR(BNIL, BNIL);
		       list2140_1444 = MAKE_PAIR(arg2138_1442, arg2141_1445);
		    }
		    arg2134_1438 = cons__138___r4_pairs_and_lists_6_3(newo_1426, list2140_1444);
		 }
	      }
	      {
		 obj_t list2136_1440;
		 list2136_1440 = MAKE_PAIR(BNIL, BNIL);
		 arg2122_1428 = cons__138___r4_pairs_and_lists_6_3(arg2134_1438, list2136_1440);
	      }
	   }
	   {
	      obj_t arg2144_1447;
	      obj_t arg2145_1448;
	      {
		 obj_t arg2151_1454;
		 obj_t arg2152_1455;
		 obj_t arg2153_1456;
		 arg2151_1454 = CNST_TABLE_REF(((long) 16));
		 arg2152_1455 = CNST_TABLE_REF(((long) 17));
		 arg2153_1456 = CNST_TABLE_REF(((long) 18));
		 {
		    obj_t list2155_1458;
		    {
		       obj_t arg2156_1459;
		       {
			  obj_t arg2157_1460;
			  arg2157_1460 = MAKE_PAIR(BNIL, BNIL);
			  arg2156_1459 = MAKE_PAIR(arg2153_1456, arg2157_1460);
		       }
		       list2155_1458 = MAKE_PAIR(arg2152_1455, arg2156_1459);
		    }
		    arg2144_1447 = cons__138___r4_pairs_and_lists_6_3(arg2151_1454, list2155_1458);
		 }
	      }
	      {
		 obj_t arg2159_1462;
		 obj_t arg2160_1463;
		 {
		    obj_t arg2165_1468;
		    obj_t arg2166_1469;
		    obj_t arg2167_1470;
		    arg2165_1468 = CNST_TABLE_REF(((long) 16));
		    arg2166_1469 = CNST_TABLE_REF(((long) 19));
		    arg2167_1470 = CNST_TABLE_REF(((long) 18));
		    {
		       obj_t list2170_1472;
		       {
			  obj_t arg2172_1473;
			  {
			     obj_t arg2173_1474;
			     arg2173_1474 = MAKE_PAIR(BNIL, BNIL);
			     arg2172_1473 = MAKE_PAIR(arg2167_1470, arg2173_1474);
			  }
			  list2170_1472 = MAKE_PAIR(arg2166_1469, arg2172_1473);
		       }
		       arg2159_1462 = cons__138___r4_pairs_and_lists_6_3(arg2165_1468, list2170_1472);
		    }
		 }
		 {
		    obj_t arg2175_1476;
		    obj_t arg2176_1477;
		    {
		       obj_t arg2182_1482;
		       obj_t arg2183_1483;
		       obj_t arg2184_1484;
		       arg2182_1482 = CNST_TABLE_REF(((long) 16));
		       arg2183_1483 = CNST_TABLE_REF(((long) 24));
		       arg2184_1484 = CNST_TABLE_REF(((long) 18));
		       {
			  obj_t list2186_1486;
			  {
			     obj_t arg2187_1487;
			     {
				obj_t arg2188_1488;
				arg2188_1488 = MAKE_PAIR(BNIL, BNIL);
				arg2187_1487 = MAKE_PAIR(arg2184_1484, arg2188_1488);
			     }
			     list2186_1486 = MAKE_PAIR(arg2183_1483, arg2187_1487);
			  }
			  arg2175_1476 = cons__138___r4_pairs_and_lists_6_3(arg2182_1482, list2186_1486);
		       }
		    }
		    {
		       obj_t arg2190_1490;
		       {
			  obj_t arg2196_1495;
			  obj_t arg2197_1496;
			  obj_t arg2198_1497;
			  arg2196_1495 = CNST_TABLE_REF(((long) 16));
			  arg2197_1496 = CNST_TABLE_REF(((long) 25));
			  arg2198_1497 = CNST_TABLE_REF(((long) 18));
			  {
			     obj_t list2200_1499;
			     {
				obj_t arg2201_1500;
				{
				   obj_t arg2202_1501;
				   arg2202_1501 = MAKE_PAIR(BNIL, BNIL);
				   arg2201_1500 = MAKE_PAIR(arg2198_1497, arg2202_1501);
				}
				list2200_1499 = MAKE_PAIR(arg2197_1496, arg2201_1500);
			     }
			     arg2190_1490 = cons__138___r4_pairs_and_lists_6_3(arg2196_1495, list2200_1499);
			  }
		       }
		       {
			  obj_t list2192_1492;
			  {
			     obj_t arg2193_1493;
			     arg2193_1493 = MAKE_PAIR(BNIL, BNIL);
			     list2192_1492 = MAKE_PAIR(newo_1426, arg2193_1493);
			  }
			  arg2176_1477 = cons__138___r4_pairs_and_lists_6_3(arg2190_1490, list2192_1492);
		       }
		    }
		    {
		       obj_t list2179_1479;
		       {
			  obj_t arg2180_1480;
			  arg2180_1480 = MAKE_PAIR(BNIL, BNIL);
			  list2179_1479 = MAKE_PAIR(arg2176_1477, arg2180_1480);
		       }
		       arg2160_1463 = cons__138___r4_pairs_and_lists_6_3(arg2175_1476, list2179_1479);
		    }
		 }
		 {
		    obj_t list2162_1465;
		    {
		       obj_t arg2163_1466;
		       arg2163_1466 = MAKE_PAIR(BNIL, BNIL);
		       list2162_1465 = MAKE_PAIR(arg2160_1463, arg2163_1466);
		    }
		    arg2145_1448 = cons__138___r4_pairs_and_lists_6_3(arg2159_1462, list2162_1465);
		 }
	      }
	      {
		 obj_t list2147_1450;
		 {
		    obj_t arg2148_1451;
		    {
		       obj_t arg2149_1452;
		       arg2149_1452 = MAKE_PAIR(BNIL, BNIL);
		       arg2148_1451 = MAKE_PAIR(arg2145_1448, arg2149_1452);
		    }
		    list2147_1450 = MAKE_PAIR(newo_1426, arg2148_1451);
		 }
		 arg2123_1429 = cons__138___r4_pairs_and_lists_6_3(arg2144_1447, list2147_1450);
	      }
	   }
	   {
	      obj_t arg2205_1503;
	      arg2205_1503 = CNST_TABLE_REF(((long) 15));
	      {
		 obj_t list2207_1505;
		 {
		    obj_t arg2208_1506;
		    {
		       obj_t arg2209_1507;
		       arg2209_1507 = MAKE_PAIR(BNIL, BNIL);
		       arg2208_1506 = MAKE_PAIR(BFALSE, arg2209_1507);
		    }
		    list2207_1505 = MAKE_PAIR(newo_1426, arg2208_1506);
		 }
		 arg2124_1430 = cons__138___r4_pairs_and_lists_6_3(arg2205_1503, list2207_1505);
	      }
	   }
	   {
	      obj_t list2126_1432;
	      {
		 obj_t arg2127_1433;
		 {
		    obj_t arg2129_1434;
		    {
		       obj_t arg2131_1435;
		       {
			  obj_t arg2132_1436;
			  arg2132_1436 = MAKE_PAIR(BNIL, BNIL);
			  arg2131_1435 = MAKE_PAIR(newo_1426, arg2132_1436);
		       }
		       arg2129_1434 = MAKE_PAIR(arg2124_1430, arg2131_1435);
		    }
		    arg2127_1433 = MAKE_PAIR(arg2123_1429, arg2129_1434);
		 }
		 list2126_1432 = MAKE_PAIR(arg2122_1428, arg2127_1433);
	      }
	      return cons__138___r4_pairs_and_lists_6_3(arg2121_1427, list2126_1432);
	   }
	}
      else
	{
	   obj_t arg2211_1509;
	   obj_t arg2213_1510;
	   obj_t arg2214_1511;
	   arg2211_1509 = CNST_TABLE_REF(((long) 1));
	   {
	      obj_t arg2221_1517;
	      {
		 obj_t arg2225_1521;
		 arg2225_1521 = PROCEDURE_ENTRY(e_89) (e_89, o_90, e_89, BEOA);
		 {
		    obj_t list2227_1523;
		    {
		       obj_t arg2228_1524;
		       arg2228_1524 = MAKE_PAIR(BNIL, BNIL);
		       list2227_1523 = MAKE_PAIR(arg2225_1521, arg2228_1524);
		    }
		    arg2221_1517 = cons__138___r4_pairs_and_lists_6_3(newo_1426, list2227_1523);
		 }
	      }
	      {
		 obj_t list2223_1519;
		 list2223_1519 = MAKE_PAIR(BNIL, BNIL);
		 arg2213_1510 = cons__138___r4_pairs_and_lists_6_3(arg2221_1517, list2223_1519);
	      }
	   }
	   {
	      obj_t arg2230_1526;
	      obj_t arg2231_1527;
	      obj_t arg2232_1528;
	      obj_t arg2233_1529;
	      arg2230_1526 = CNST_TABLE_REF(((long) 20));
	      {
		 obj_t arg2240_1536;
		 arg2240_1536 = CNST_TABLE_REF(((long) 29));
		 {
		    obj_t list2242_1538;
		    {
		       obj_t arg2243_1539;
		       arg2243_1539 = MAKE_PAIR(BNIL, BNIL);
		       list2242_1538 = MAKE_PAIR(newo_1426, arg2243_1539);
		    }
		    arg2231_1527 = cons__138___r4_pairs_and_lists_6_3(arg2240_1536, list2242_1538);
		 }
	      }
	      {
		 obj_t arg2246_1541;
		 obj_t arg2247_1542;
		 obj_t arg2248_1543;
		 obj_t arg2250_1544;
		 arg2246_1541 = CNST_TABLE_REF(((long) 20));
		 {
		    obj_t arg2259_1551;
		    arg2259_1551 = CNST_TABLE_REF(((long) 21));
		    {
		       obj_t list2261_1553;
		       {
			  obj_t arg2263_1554;
			  arg2263_1554 = MAKE_PAIR(BNIL, BNIL);
			  list2261_1553 = MAKE_PAIR(newo_1426, arg2263_1554);
		       }
		       arg2247_1542 = cons__138___r4_pairs_and_lists_6_3(arg2259_1551, list2261_1553);
		    }
		 }
		 {
		    obj_t arg2265_1556;
		    obj_t arg2266_1557;
		    obj_t arg2267_1558;
		    arg2265_1556 = CNST_TABLE_REF(((long) 26));
		    {
		       obj_t arg2274_1565;
		       obj_t arg2275_1566;
		       {
			  obj_t arg2281_1572;
			  obj_t arg2282_1573;
			  obj_t arg2283_1574;
			  arg2281_1572 = CNST_TABLE_REF(((long) 16));
			  arg2282_1573 = CNST_TABLE_REF(((long) 17));
			  arg2283_1574 = CNST_TABLE_REF(((long) 18));
			  {
			     obj_t list2285_1576;
			     {
				obj_t arg2286_1577;
				{
				   obj_t arg2287_1578;
				   arg2287_1578 = MAKE_PAIR(BNIL, BNIL);
				   arg2286_1577 = MAKE_PAIR(arg2283_1574, arg2287_1578);
				}
				list2285_1576 = MAKE_PAIR(arg2282_1573, arg2286_1577);
			     }
			     arg2274_1565 = cons__138___r4_pairs_and_lists_6_3(arg2281_1572, list2285_1576);
			  }
		       }
		       {
			  obj_t arg2289_1580;
			  obj_t arg2291_1581;
			  {
			     obj_t arg2297_1586;
			     obj_t arg2298_1587;
			     obj_t arg2299_1588;
			     arg2297_1586 = CNST_TABLE_REF(((long) 16));
			     arg2298_1587 = CNST_TABLE_REF(((long) 19));
			     arg2299_1588 = CNST_TABLE_REF(((long) 18));
			     {
				obj_t list2301_1590;
				{
				   obj_t arg2302_1591;
				   {
				      obj_t arg2303_1592;
				      arg2303_1592 = MAKE_PAIR(BNIL, BNIL);
				      arg2302_1591 = MAKE_PAIR(arg2299_1588, arg2303_1592);
				   }
				   list2301_1590 = MAKE_PAIR(arg2298_1587, arg2302_1591);
				}
				arg2289_1580 = cons__138___r4_pairs_and_lists_6_3(arg2297_1586, list2301_1590);
			     }
			  }
			  {
			     obj_t arg2305_1594;
			     obj_t arg2306_1595;
			     {
				obj_t arg2311_1600;
				obj_t arg2312_1601;
				obj_t arg2316_1602;
				arg2311_1600 = CNST_TABLE_REF(((long) 16));
				arg2312_1601 = CNST_TABLE_REF(((long) 24));
				arg2316_1602 = CNST_TABLE_REF(((long) 18));
				{
				   obj_t list2320_1604;
				   {
				      obj_t arg2322_1605;
				      {
					 obj_t arg2323_1606;
					 arg2323_1606 = MAKE_PAIR(BNIL, BNIL);
					 arg2322_1605 = MAKE_PAIR(arg2316_1602, arg2323_1606);
				      }
				      list2320_1604 = MAKE_PAIR(arg2312_1601, arg2322_1605);
				   }
				   arg2305_1594 = cons__138___r4_pairs_and_lists_6_3(arg2311_1600, list2320_1604);
				}
			     }
			     {
				obj_t arg2325_1608;
				{
				   obj_t arg2330_1613;
				   obj_t arg2331_1614;
				   obj_t arg2332_1615;
				   arg2330_1613 = CNST_TABLE_REF(((long) 16));
				   arg2331_1614 = CNST_TABLE_REF(((long) 25));
				   arg2332_1615 = CNST_TABLE_REF(((long) 18));
				   {
				      obj_t list2334_1617;
				      {
					 obj_t arg2335_1618;
					 {
					    obj_t arg2336_1619;
					    arg2336_1619 = MAKE_PAIR(BNIL, BNIL);
					    arg2335_1618 = MAKE_PAIR(arg2332_1615, arg2336_1619);
					 }
					 list2334_1617 = MAKE_PAIR(arg2331_1614, arg2335_1618);
				      }
				      arg2325_1608 = cons__138___r4_pairs_and_lists_6_3(arg2330_1613, list2334_1617);
				   }
				}
				{
				   obj_t list2327_1610;
				   {
				      obj_t arg2328_1611;
				      arg2328_1611 = MAKE_PAIR(BNIL, BNIL);
				      list2327_1610 = MAKE_PAIR(newo_1426, arg2328_1611);
				   }
				   arg2306_1595 = cons__138___r4_pairs_and_lists_6_3(arg2325_1608, list2327_1610);
				}
			     }
			     {
				obj_t list2308_1597;
				{
				   obj_t arg2309_1598;
				   arg2309_1598 = MAKE_PAIR(BNIL, BNIL);
				   list2308_1597 = MAKE_PAIR(arg2306_1595, arg2309_1598);
				}
				arg2291_1581 = cons__138___r4_pairs_and_lists_6_3(arg2305_1594, list2308_1597);
			     }
			  }
			  {
			     obj_t list2293_1583;
			     {
				obj_t arg2294_1584;
				arg2294_1584 = MAKE_PAIR(BNIL, BNIL);
				list2293_1583 = MAKE_PAIR(arg2291_1581, arg2294_1584);
			     }
			     arg2275_1566 = cons__138___r4_pairs_and_lists_6_3(arg2289_1580, list2293_1583);
			  }
		       }
		       {
			  obj_t list2277_1568;
			  {
			     obj_t arg2278_1569;
			     {
				obj_t arg2279_1570;
				arg2279_1570 = MAKE_PAIR(BNIL, BNIL);
				arg2278_1569 = MAKE_PAIR(arg2275_1566, arg2279_1570);
			     }
			     list2277_1568 = MAKE_PAIR(newo_1426, arg2278_1569);
			  }
			  arg2266_1557 = cons__138___r4_pairs_and_lists_6_3(arg2274_1565, list2277_1568);
		       }
		    }
		    {
		       obj_t arg2338_1621;
		       arg2338_1621 = CNST_TABLE_REF(((long) 15));
		       {
			  obj_t list2340_1623;
			  {
			     obj_t arg2341_1624;
			     {
				obj_t arg2342_1625;
				arg2342_1625 = MAKE_PAIR(BNIL, BNIL);
				arg2341_1624 = MAKE_PAIR(BFALSE, arg2342_1625);
			     }
			     list2340_1623 = MAKE_PAIR(newo_1426, arg2341_1624);
			  }
			  arg2267_1558 = cons__138___r4_pairs_and_lists_6_3(arg2338_1621, list2340_1623);
		       }
		    }
		    {
		       obj_t list2269_1560;
		       {
			  obj_t arg2270_1561;
			  {
			     obj_t arg2271_1562;
			     {
				obj_t arg2272_1563;
				arg2272_1563 = MAKE_PAIR(BNIL, BNIL);
				arg2271_1562 = MAKE_PAIR(newo_1426, arg2272_1563);
			     }
			     arg2270_1561 = MAKE_PAIR(arg2267_1558, arg2271_1562);
			  }
			  list2269_1560 = MAKE_PAIR(arg2266_1557, arg2270_1561);
		       }
		       arg2248_1543 = cons__138___r4_pairs_and_lists_6_3(arg2265_1556, list2269_1560);
		    }
		 }
		 {
		    obj_t arg2344_1627;
		    arg2344_1627 = CNST_TABLE_REF(((long) 27));
		    {
		       obj_t list2348_1631;
		       {
			  obj_t arg2349_1632;
			  {
			     obj_t arg2350_1633;
			     {
				obj_t arg2351_1634;
				arg2351_1634 = MAKE_PAIR(BNIL, BNIL);
				arg2350_1633 = MAKE_PAIR(newo_1426, arg2351_1634);
			     }
			     arg2349_1632 = MAKE_PAIR(string2466_expand_object, arg2350_1633);
			  }
			  list2348_1631 = MAKE_PAIR(string2467_expand_object, arg2349_1632);
		       }
		       arg2250_1544 = cons__138___r4_pairs_and_lists_6_3(arg2344_1627, list2348_1631);
		    }
		 }
		 {
		    obj_t list2253_1546;
		    {
		       obj_t arg2254_1547;
		       {
			  obj_t arg2256_1548;
			  {
			     obj_t arg2257_1549;
			     arg2257_1549 = MAKE_PAIR(BNIL, BNIL);
			     arg2256_1548 = MAKE_PAIR(arg2250_1544, arg2257_1549);
			  }
			  arg2254_1547 = MAKE_PAIR(arg2248_1543, arg2256_1548);
		       }
		       list2253_1546 = MAKE_PAIR(arg2247_1542, arg2254_1547);
		    }
		    arg2232_1528 = cons__138___r4_pairs_and_lists_6_3(arg2246_1541, list2253_1546);
		 }
	      }
	      {
		 obj_t arg2353_1636;
		 arg2353_1636 = CNST_TABLE_REF(((long) 27));
		 {
		    obj_t list2357_1640;
		    {
		       obj_t arg2358_1641;
		       {
			  obj_t arg2359_1642;
			  {
			     obj_t arg2360_1643;
			     arg2360_1643 = MAKE_PAIR(BNIL, BNIL);
			     arg2359_1642 = MAKE_PAIR(newo_1426, arg2360_1643);
			  }
			  arg2358_1641 = MAKE_PAIR(string2466_expand_object, arg2359_1642);
		       }
		       list2357_1640 = MAKE_PAIR(string2467_expand_object, arg2358_1641);
		    }
		    arg2233_1529 = cons__138___r4_pairs_and_lists_6_3(arg2353_1636, list2357_1640);
		 }
	      }
	      {
		 obj_t list2235_1531;
		 {
		    obj_t arg2236_1532;
		    {
		       obj_t arg2237_1533;
		       {
			  obj_t arg2238_1534;
			  arg2238_1534 = MAKE_PAIR(BNIL, BNIL);
			  arg2237_1533 = MAKE_PAIR(arg2233_1529, arg2238_1534);
		       }
		       arg2236_1532 = MAKE_PAIR(arg2232_1528, arg2237_1533);
		    }
		    list2235_1531 = MAKE_PAIR(arg2231_1527, arg2236_1532);
		 }
		 arg2214_1511 = cons__138___r4_pairs_and_lists_6_3(arg2230_1526, list2235_1531);
	      }
	   }
	   {
	      obj_t list2216_1513;
	      {
		 obj_t arg2217_1514;
		 {
		    obj_t arg2219_1515;
		    arg2219_1515 = MAKE_PAIR(BNIL, BNIL);
		    arg2217_1514 = MAKE_PAIR(arg2214_1511, arg2219_1515);
		 }
		 list2216_1513 = MAKE_PAIR(arg2213_1510, arg2217_1514);
	      }
	      return cons__138___r4_pairs_and_lists_6_3(arg2211_1509, list2216_1513);
	   }
	}
   }
}


/* make-virtual-set */ obj_t 
make_virtual_set_218_expand_object(obj_t slot_91, obj_t value_92, obj_t var_93, obj_t class_94, obj_t form_95, char *alloc_kind_252_96)
{
   {
      bool_t test_3783;
      {
	 obj_t aux_3784;
	 aux_3784 = STRUCT_REF(slot_91, ((long) 7));
	 test_3783 = CBOOL(aux_3784);
      }
      if (test_3783)
	{
	   obj_t arg2366_1648;
	   {
	      obj_t arg2369_1651;
	      {
		 obj_t aux_3787;
		 aux_3787 = STRUCT_REF(slot_91, ((long) 0));
		 arg2369_1651 = SYMBOL_TO_STRING(aux_3787);
	      }
	      {
		 obj_t list2371_1653;
		 {
		    obj_t arg2372_1654;
		    {
		       obj_t arg2373_1655;
		       {
			  obj_t arg2374_1656;
			  {
			     obj_t arg2375_1657;
			     arg2375_1657 = MAKE_PAIR(string2451_expand_object, BNIL);
			     arg2374_1656 = MAKE_PAIR(arg2369_1651, arg2375_1657);
			  }
			  arg2373_1655 = MAKE_PAIR(string2468_expand_object, arg2374_1656);
		       }
		       {
			  obj_t aux_3793;
			  aux_3793 = string_to_bstring(alloc_kind_252_96);
			  arg2372_1654 = MAKE_PAIR(aux_3793, arg2373_1655);
		       }
		    }
		    list2371_1653 = MAKE_PAIR(string2469_expand_object, arg2372_1654);
		 }
		 arg2366_1648 = string_append_106___r4_strings_6_7(list2371_1653);
	      }
	   }
	   FAILURE(BFALSE, arg2366_1648, form_95);
	}
      else
	{
	   obj_t arg2378_1660;
	   {
	      obj_t arg2379_1661;
	      {
		 obj_t arg2386_1667;
		 obj_t arg2387_1668;
		 obj_t arg2388_1669;
		 {
		    type_t obj_2412;
		    obj_2412 = (type_t) (class_94);
		    arg2386_1667 = (((type_t) CREF(obj_2412))->id);
		 }
		 arg2387_1668 = CNST_TABLE_REF(((long) 2));
		 arg2388_1669 = STRUCT_REF(slot_91, ((long) 0));
		 {
		    obj_t list2391_1671;
		    {
		       obj_t arg2392_1672;
		       {
			  obj_t arg2394_1673;
			  {
			     obj_t arg2396_1674;
			     {
				obj_t aux_3803;
				aux_3803 = CNST_TABLE_REF(((long) 3));
				arg2396_1674 = MAKE_PAIR(aux_3803, BNIL);
			     }
			     arg2394_1673 = MAKE_PAIR(arg2388_1669, arg2396_1674);
			  }
			  arg2392_1672 = MAKE_PAIR(arg2387_1668, arg2394_1673);
		       }
		       list2391_1671 = MAKE_PAIR(arg2386_1667, arg2392_1672);
		    }
		    arg2379_1661 = symbol_append_197___r4_symbols_6_4(list2391_1671);
		 }
	      }
	      {
		 obj_t list2381_1663;
		 {
		    obj_t arg2383_1664;
		    {
		       obj_t arg2384_1665;
		       arg2384_1665 = MAKE_PAIR(BNIL, BNIL);
		       arg2383_1664 = MAKE_PAIR(value_92, arg2384_1665);
		    }
		    list2381_1663 = MAKE_PAIR(var_93, arg2383_1664);
		 }
		 arg2378_1660 = cons__138___r4_pairs_and_lists_6_3(arg2379_1661, list2381_1663);
	      }
	   }
	   return epairify_expand_object(arg2378_1660, value_92);
	}
   }
}


/* epairify */ obj_t 
epairify_expand_object(obj_t obj_97, obj_t epair_98)
{
 epairify_expand_object:
   {
      bool_t test2400_1676;
      test2400_1676 = EXTENDED_PAIRP(epair_98);
      if (test2400_1676)
	{
	   if (PAIRP(obj_97))
	     {
		obj_t arg2402_1678;
		obj_t arg2403_1679;
		obj_t arg2404_1680;
		arg2402_1678 = CAR(obj_97);
		arg2403_1679 = CDR(obj_97);
		{
		   bool_t test1137_2421;
		   test1137_2421 = EXTENDED_PAIRP(epair_98);
		   if (test1137_2421)
		     {
			arg2404_1680 = CER(epair_98);
		     }
		   else
		     {
			FAILURE(string2470_expand_object, string2471_expand_object, epair_98);
		     }
		}
		return MAKE_EXTENDED_PAIR(arg2402_1678, arg2403_1679, arg2404_1680);
	     }
	   else
	     {
		obj_t arg2405_1681;
		{
		   obj_t arg2406_1682;
		   arg2406_1682 = CNST_TABLE_REF(((long) 26));
		   {
		      obj_t list2408_1684;
		      {
			 obj_t arg2409_1685;
			 arg2409_1685 = MAKE_PAIR(BNIL, BNIL);
			 list2408_1684 = MAKE_PAIR(obj_97, arg2409_1685);
		      }
		      arg2405_1681 = cons__138___r4_pairs_and_lists_6_3(arg2406_1682, list2408_1684);
		   }
		}
		{
		   obj_t obj_3830;
		   obj_3830 = arg2405_1681;
		   obj_97 = obj_3830;
		   goto epairify_expand_object;
		}
	     }
	}
      else
	{
	   return obj_97;
	}
   }
}


/* method-init */ obj_t 
method_init_76_expand_object()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_expand_object()
{
   module_initialization_70_tools_args(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_tools_progn(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_tools_misc(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_type_type(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_type_env(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_expand_eps(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_engine_param(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_ast_var(((long) 0), "EXPAND_OBJECT");
   module_initialization_70_ast_ident(((long) 0), "EXPAND_OBJECT");
   return module_initialization_70_object_class(((long) 0), "EXPAND_OBJECT");
}
