/*===========================================================================*/
/*   (Ast/local.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


static obj_t method_init_76_ast_local();
static obj_t _clone_local_106_ast_local(obj_t, obj_t, obj_t);
static local_t make_new_local_222_ast_local(obj_t, type_t, obj_t, bool_t);
extern local_t clone_local_230_ast_local(local_t, value_t);
extern obj_t module_initialization_70_ast_local(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_numbers_6_5_fixnum(long, char *);
extern obj_t module_initialization_70___r4_strings_6_7(long, char *);
extern local_t make_local_svar_140_ast_local(obj_t, type_t);
extern long class_num_218___object(obj_t);
extern obj_t svar_ast_var;
static obj_t imported_modules_init_94_ast_local();
extern obj_t string_append_106___r4_strings_6_7(obj_t);
static obj_t _make_user_local_svar_52_ast_local(obj_t, obj_t, obj_t);
extern obj_t id__name_228_ast_ident(obj_t);
static long _local_key__223_ast_local;
static obj_t library_modules_init_112_ast_local();
static obj_t _make_local_svar_141_ast_local(obj_t, obj_t, obj_t);
static obj_t toplevel_init_63_ast_local();
extern obj_t open_input_string(obj_t);
extern local_t make_local_sfun_184_ast_local(obj_t, type_t, sfun_t);
static obj_t _make_local_sexit_250_ast_local(obj_t, obj_t, obj_t, obj_t);
extern char *integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t string_to_bstring(char *);
extern obj_t local_id__name_204_ast_ident(obj_t);
extern obj_t local_ast_var;
extern local_t make_user_local_svar_134_ast_local(obj_t, type_t);
static obj_t _make_user_local_sfun_30_ast_local(obj_t, obj_t, obj_t, obj_t);
extern local_t make_local_sexit_184_ast_local(obj_t, type_t, sexit_t);
static long get_new_key_51_ast_local();
static obj_t _make_local_sfun_99_ast_local(obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_ast_local = BUNSPEC;
static obj_t cnst_init_137_ast_local();
extern local_t make_user_local_sfun_221_ast_local(obj_t, type_t, sfun_t);
static obj_t __cnst[2];

DEFINE_EXPORT_PROCEDURE(make_local_svar_env_143_ast_local, _make_local_svar_141_ast_local1283, _make_local_svar_141_ast_local, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_local_sfun_env_161_ast_local, _make_local_sfun_99_ast_local1284, _make_local_sfun_99_ast_local, 0L, 3);
DEFINE_EXPORT_PROCEDURE(make_local_sexit_env_161_ast_local, _make_local_sexit_250_ast_local1285, _make_local_sexit_250_ast_local, 0L, 3);
DEFINE_EXPORT_PROCEDURE(clone_local_env_253_ast_local, _clone_local_106_ast_local1286, _clone_local_106_ast_local, 0L, 2);
DEFINE_STRING(string1274_ast_local, string1274_ast_local1287, "NOW READ ", 9);
DEFINE_STRING(string1273_ast_local, string1273_ast_local1288, "_", 1);
DEFINE_EXPORT_PROCEDURE(make_user_local_svar_env_199_ast_local, _make_user_local_svar_52_ast_local1289, _make_user_local_svar_52_ast_local, 0L, 2);
DEFINE_EXPORT_PROCEDURE(make_user_local_sfun_env_4_ast_local, _make_user_local_sfun_30_ast_local1290, _make_user_local_sfun_30_ast_local, 0L, 3);


/* module-initialization */ obj_t 
module_initialization_70_ast_local(long checksum_614, char *from_615)
{
   if (CBOOL(require_initialization_114_ast_local))
     {
	require_initialization_114_ast_local = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_local();
	cnst_init_137_ast_local();
	imported_modules_init_94_ast_local();
	method_init_76_ast_local();
	toplevel_init_63_ast_local();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_local()
{
   module_initialization_70___object(((long) 0), "AST_LOCAL");
   module_initialization_70___r4_strings_6_7(((long) 0), "AST_LOCAL");
   module_initialization_70___r4_numbers_6_5_fixnum(((long) 0), "AST_LOCAL");
   module_initialization_70___reader(((long) 0), "AST_LOCAL");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_local()
{
   {
      obj_t cnst_port_138_606;
      cnst_port_138_606 = open_input_string(string1274_ast_local);
      {
	 long i_607;
	 i_607 = ((long) 1);
       loop_608:
	 {
	    bool_t test1275_609;
	    test1275_609 = (i_607 == ((long) -1));
	    if (test1275_609)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1277_610;
		    {
		       obj_t list1278_611;
		       {
			  obj_t arg1281_612;
			  arg1281_612 = BNIL;
			  list1278_611 = MAKE_PAIR(cnst_port_138_606, arg1281_612);
		       }
		       arg1277_610 = read___reader(list1278_611);
		    }
		    CNST_TABLE_SET(i_607, arg1277_610);
		 }
		 {
		    int aux_613;
		    {
		       long aux_634;
		       aux_634 = (i_607 - ((long) 1));
		       aux_613 = (int) (aux_634);
		    }
		    {
		       long i_637;
		       i_637 = (long) (aux_613);
		       i_607 = i_637;
		       goto loop_608;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_local()
{
   return (_local_key__223_ast_local = ((long) 0),
      BUNSPEC);
}


/* get-new-key */ long 
get_new_key_51_ast_local()
{
   {
      long z1_490;
      z1_490 = _local_key__223_ast_local;
      _local_key__223_ast_local = (z1_490 + ((long) 1));
   }
   return _local_key__223_ast_local;
}


/* make-new-local */ local_t 
make_new_local_222_ast_local(obj_t id_1, type_t type_2, obj_t value_3, bool_t user__32_4)
{
   {
      long key_320;
      key_320 = get_new_key_51_ast_local();
      {
	 obj_t arg1190_322;
	 obj_t arg1193_325;
	 obj_t arg1194_326;
	 {
	    obj_t arg1199_330;
	    char *arg1201_332;
	    arg1199_330 = local_id__name_204_ast_ident(id_1);
	    arg1201_332 = integer__string_135___r4_numbers_6_5_fixnum(key_320, BNIL);
	    {
	       obj_t list1202_333;
	       {
		  obj_t arg1203_334;
		  {
		     obj_t arg1204_335;
		     {
			obj_t aux_643;
			aux_643 = string_to_bstring(arg1201_332);
			arg1204_335 = MAKE_PAIR(aux_643, BNIL);
		     }
		     arg1203_334 = MAKE_PAIR(string1273_ast_local, arg1204_335);
		  }
		  list1202_333 = MAKE_PAIR(arg1199_330, arg1203_334);
	       }
	       arg1190_322 = string_append_106___r4_strings_6_7(list1202_333);
	    }
	 }
	 arg1193_325 = CNST_TABLE_REF(((long) 0));
	 arg1194_326 = CNST_TABLE_REF(((long) 1));
	 {
	    local_t res1269_516;
	    {
	       value_t value_495;
	       value_495 = (value_t) (value_3);
	       {
		  local_t new1079_502;
		  new1079_502 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
		  {
		     long arg1257_503;
		     arg1257_503 = class_num_218___object(local_ast_var);
		     {
			obj_t obj_514;
			obj_514 = (obj_t) (new1079_502);
			(((obj_t) CREF(obj_514))->header = MAKE_HEADER(arg1257_503, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_656;
		     aux_656 = (object_t) (new1079_502);
		     OBJECT_WIDENING_SET(aux_656, BFALSE);
		  }
		  ((((local_t) CREF(new1079_502))->id) = ((obj_t) id_1), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->name) = ((obj_t) arg1190_322), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->type) = ((type_t) type_2), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->value) = ((value_t) value_495), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->access) = ((obj_t) arg1193_325), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->fast_alpha_7) = ((obj_t) BUNSPEC), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->removable) = ((obj_t) arg1194_326), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->occurrence) = ((long) ((long) 0)), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->user__32) = ((bool_t) user__32_4), BUNSPEC);
		  ((((local_t) CREF(new1079_502))->key) = ((long) key_320), BUNSPEC);
		  res1269_516 = new1079_502;
	       }
	    }
	    return res1269_516;
	 }
      }
   }
}


/* clone-local */ local_t 
clone_local_230_ast_local(local_t local_5, value_t value_6)
{
   {
      long key_338;
      key_338 = get_new_key_51_ast_local();
      {
	 local_t new1185_341;
	 {
	    obj_t arg1207_342;
	    obj_t arg1209_343;
	    type_t arg1210_344;
	    obj_t arg1213_346;
	    obj_t arg1214_347;
	    obj_t arg1216_348;
	    long arg1219_349;
	    bool_t arg1220_350;
	    arg1207_342 = (((local_t) CREF(local_5))->id);
	    {
	       obj_t arg1222_352;
	       char *arg1225_354;
	       arg1222_352 = id__name_228_ast_ident((((local_t) CREF(local_5))->id));
	       arg1225_354 = integer__string_135___r4_numbers_6_5_fixnum(key_338, BNIL);
	       {
		  obj_t list1226_355;
		  {
		     obj_t arg1228_356;
		     {
			obj_t arg1231_357;
			{
			   obj_t aux_674;
			   aux_674 = string_to_bstring(arg1225_354);
			   arg1231_357 = MAKE_PAIR(aux_674, BNIL);
			}
			arg1228_356 = MAKE_PAIR(string1273_ast_local, arg1231_357);
		     }
		     list1226_355 = MAKE_PAIR(arg1222_352, arg1228_356);
		  }
		  arg1209_343 = string_append_106___r4_strings_6_7(list1226_355);
	       }
	    }
	    arg1210_344 = (((local_t) CREF(local_5))->type);
	    arg1213_346 = (((local_t) CREF(local_5))->access);
	    arg1214_347 = (((local_t) CREF(local_5))->fast_alpha_7);
	    arg1216_348 = (((local_t) CREF(local_5))->removable);
	    arg1219_349 = (((local_t) CREF(local_5))->occurrence);
	    arg1220_350 = (((local_t) CREF(local_5))->user__32);
	    {
	       local_t res1270_549;
	       {
		  local_t new1079_535;
		  new1079_535 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
		  {
		     long arg1257_536;
		     arg1257_536 = class_num_218___object(local_ast_var);
		     {
			obj_t obj_547;
			obj_547 = (obj_t) (new1079_535);
			(((obj_t) CREF(obj_547))->header = MAKE_HEADER(arg1257_536, 0), BUNSPEC);
		     }
		  }
		  {
		     object_t aux_690;
		     aux_690 = (object_t) (new1079_535);
		     OBJECT_WIDENING_SET(aux_690, BFALSE);
		  }
		  ((((local_t) CREF(new1079_535))->id) = ((obj_t) arg1207_342), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->name) = ((obj_t) arg1209_343), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->type) = ((type_t) arg1210_344), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->value) = ((value_t) value_6), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->access) = ((obj_t) arg1213_346), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->fast_alpha_7) = ((obj_t) arg1214_347), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->removable) = ((obj_t) arg1216_348), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->occurrence) = ((long) arg1219_349), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->user__32) = ((bool_t) arg1220_350), BUNSPEC);
		  ((((local_t) CREF(new1079_535))->key) = ((long) key_338), BUNSPEC);
		  res1270_549 = new1079_535;
	       }
	       new1185_341 = res1270_549;
	    }
	 }
	 {
	    return new1185_341;
	 }
      }
   }
}


/* _clone-local */ obj_t 
_clone_local_106_ast_local(obj_t env_585, obj_t local_586, obj_t value_587)
{
   {
      local_t aux_703;
      aux_703 = clone_local_230_ast_local((local_t) (local_586), (value_t) (value_587));
      return (obj_t) (aux_703);
   }
}


/* make-local-svar */ local_t 
make_local_svar_140_ast_local(obj_t id_7, type_t type_8)
{
   {
      svar_t arg1235_550;
      {
	 svar_t res1271_557;
	 {
	    svar_t new1158_552;
	    new1158_552 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
	    {
	       long arg1248_553;
	       arg1248_553 = class_num_218___object(svar_ast_var);
	       {
		  obj_t obj_555;
		  obj_555 = (obj_t) (new1158_552);
		  (((obj_t) CREF(obj_555))->header = MAKE_HEADER(arg1248_553, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_712;
	       aux_712 = (object_t) (new1158_552);
	       OBJECT_WIDENING_SET(aux_712, BFALSE);
	    }
	    ((((svar_t) CREF(new1158_552))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
	    res1271_557 = new1158_552;
	 }
	 arg1235_550 = res1271_557;
      }
      return make_new_local_222_ast_local(id_7, type_8, (obj_t) (arg1235_550), ((bool_t) 0));
   }
}


/* _make-local-svar */ obj_t 
_make_local_svar_141_ast_local(obj_t env_588, obj_t id_589, obj_t type_590)
{
   {
      local_t aux_718;
      aux_718 = make_local_svar_140_ast_local(id_589, (type_t) (type_590));
      return (obj_t) (aux_718);
   }
}


/* make-user-local-svar */ local_t 
make_user_local_svar_134_ast_local(obj_t id_9, type_t type_10)
{
   {
      svar_t arg1236_558;
      {
	 svar_t res1272_565;
	 {
	    svar_t new1158_560;
	    new1158_560 = ((svar_t) BREF(GC_MALLOC(sizeof(struct svar))));
	    {
	       long arg1248_561;
	       arg1248_561 = class_num_218___object(svar_ast_var);
	       {
		  obj_t obj_563;
		  obj_563 = (obj_t) (new1158_560);
		  (((obj_t) CREF(obj_563))->header = MAKE_HEADER(arg1248_561, 0), BUNSPEC);
	       }
	    }
	    {
	       object_t aux_726;
	       aux_726 = (object_t) (new1158_560);
	       OBJECT_WIDENING_SET(aux_726, BFALSE);
	    }
	    ((((svar_t) CREF(new1158_560))->loc) = ((obj_t) BUNSPEC), BUNSPEC);
	    res1272_565 = new1158_560;
	 }
	 arg1236_558 = res1272_565;
      }
      return make_new_local_222_ast_local(id_9, type_10, (obj_t) (arg1236_558), ((bool_t) 1));
   }
}


/* _make-user-local-svar */ obj_t 
_make_user_local_svar_52_ast_local(obj_t env_591, obj_t id_592, obj_t type_593)
{
   {
      local_t aux_732;
      aux_732 = make_user_local_svar_134_ast_local(id_592, (type_t) (type_593));
      return (obj_t) (aux_732);
   }
}


/* make-local-sexit */ local_t 
make_local_sexit_184_ast_local(obj_t id_11, type_t type_12, sexit_t sexit_13)
{
   return make_new_local_222_ast_local(id_11, type_12, (obj_t) (sexit_13), ((bool_t) 0));
}


/* _make-local-sexit */ obj_t 
_make_local_sexit_250_ast_local(obj_t env_594, obj_t id_595, obj_t type_596, obj_t sexit_597)
{
   {
      local_t aux_738;
      aux_738 = make_local_sexit_184_ast_local(id_595, (type_t) (type_596), (sexit_t) (sexit_597));
      return (obj_t) (aux_738);
   }
}


/* make-local-sfun */ local_t 
make_local_sfun_184_ast_local(obj_t id_14, type_t type_15, sfun_t sfun_16)
{
   return make_new_local_222_ast_local(id_14, type_15, (obj_t) (sfun_16), ((bool_t) 0));
}


/* _make-local-sfun */ obj_t 
_make_local_sfun_99_ast_local(obj_t env_598, obj_t id_599, obj_t type_600, obj_t sfun_601)
{
   {
      local_t aux_745;
      aux_745 = make_local_sfun_184_ast_local(id_599, (type_t) (type_600), (sfun_t) (sfun_601));
      return (obj_t) (aux_745);
   }
}


/* make-user-local-sfun */ local_t 
make_user_local_sfun_221_ast_local(obj_t id_17, type_t type_18, sfun_t sfun_19)
{
   return make_new_local_222_ast_local(id_17, type_18, (obj_t) (sfun_19), ((bool_t) 1));
}


/* _make-user-local-sfun */ obj_t 
_make_user_local_sfun_30_ast_local(obj_t env_602, obj_t id_603, obj_t type_604, obj_t sfun_605)
{
   {
      local_t aux_752;
      aux_752 = make_user_local_sfun_221_ast_local(id_603, (type_t) (type_604), (sfun_t) (sfun_605));
      return (obj_t) (aux_752);
   }
}


/* method-init */ obj_t 
method_init_76_ast_local()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_local()
{
   module_initialization_70_type_type(((long) 0), "AST_LOCAL");
   module_initialization_70_type_cache(((long) 0), "AST_LOCAL");
   module_initialization_70_engine_param(((long) 0), "AST_LOCAL");
   module_initialization_70_ast_var(((long) 0), "AST_LOCAL");
   return module_initialization_70_ast_ident(((long) 0), "AST_LOCAL");
}
