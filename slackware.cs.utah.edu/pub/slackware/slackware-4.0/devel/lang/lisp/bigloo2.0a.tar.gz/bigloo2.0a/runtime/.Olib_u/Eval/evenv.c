/*===========================================================================*/
/*   (Eval/evenv.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_symbol(char *);
static obj_t _eval_global_value_217___evenv(obj_t, obj_t);
static obj_t symbol1154___evenv = BUNSPEC;
static obj_t symbol1153___evenv = BUNSPEC;
extern obj_t eval_global_value_117___evenv(obj_t);
extern obj_t eval_global__95___evenv(obj_t);
extern obj_t create_vector(long);
extern obj_t init_the_global_environment__144___evenv();
static obj_t _eval_lookup_224___evenv(obj_t, obj_t);
static obj_t _define_primop__215___evenv(obj_t, obj_t, obj_t);
extern obj_t remprop__243___r4_symbols_6_4(obj_t, obj_t);
extern obj_t getprop___r4_symbols_6_4(obj_t, obj_t);
extern obj_t eval_global_tag_85___evenv(obj_t);
extern obj_t eval_lookup_172___evenv(obj_t);
static obj_t _unbind_primop__162___evenv(obj_t, obj_t);
extern obj_t putprop__88___r4_symbols_6_4(obj_t, obj_t, obj_t);
static obj_t _bind_eval_global__60___evenv(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___evenv(long, char *);
extern obj_t module_initialization_70___r4_symbols_6_4(long, char *);
static obj_t _init_the_global_environment__212___evenv(obj_t);
extern obj_t bind_eval_global__246___evenv(obj_t, obj_t);
extern obj_t set_eval_global_value__218___evenv(obj_t, obj_t);
static obj_t _set_eval_global_value__159___evenv(obj_t, obj_t, obj_t);
extern obj_t define_primop__185___evenv(obj_t, obj_t);
static obj_t _eval_global__27___evenv(obj_t, obj_t);
static obj_t _eval_global_name_41___evenv(obj_t, obj_t);
extern obj_t define_primop_ref__105___evenv(obj_t, obj_t);
static obj_t _define_primop_ref__78___evenv(obj_t, obj_t, obj_t);
static obj_t _eval_global_tag_208___evenv(obj_t, obj_t);
static obj_t imported_modules_init_94___evenv();
extern obj_t unbind_primop__163___evenv(obj_t);
static obj_t require_initialization_114___evenv = BUNSPEC;
static obj_t cnst_init_137___evenv();
extern obj_t eval_global_name_0___evenv(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( unbind_primop__env_255___evenv, _unbind_primop__162___evenv1156, _unbind_primop__162___evenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( define_primop__env_203___evenv, _define_primop__215___evenv1157, _define_primop__215___evenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( eval_global_name_env_93___evenv, _eval_global_name_41___evenv1158, _eval_global_name_41___evenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( eval_lookup_env_224___evenv, _eval_lookup_224___evenv1159, _eval_lookup_224___evenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( bind_eval_global__env_50___evenv, _bind_eval_global__60___evenv1160, _bind_eval_global__60___evenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( define_primop_ref__env_166___evenv, _define_primop_ref__78___evenv1161, _define_primop_ref__78___evenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( init_the_global_environment__env_243___evenv, _init_the_global_environment__212___evenv1162, _init_the_global_environment__212___evenv, 0L, 0 );
DEFINE_EXPORT_PROCEDURE( eval_global_value_env_135___evenv, _eval_global_value_217___evenv1163, _eval_global_value_217___evenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( eval_global_tag_env_171___evenv, _eval_global_tag_208___evenv1164, _eval_global_tag_208___evenv, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( set_eval_global_value__env_12___evenv, _set_eval_global_value__159___evenv1165, _set_eval_global_value__159___evenv, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( eval_global__env_147___evenv, _eval_global__27___evenv1166, _eval_global__27___evenv, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___evenv(long checksum_582, char * from_583)
{
if(CBOOL(require_initialization_114___evenv)){
require_initialization_114___evenv = BBOOL(((bool_t)0));
cnst_init_137___evenv();
imported_modules_init_94___evenv();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___evenv()
{
symbol1153___evenv = string_to_symbol("NOTHING");
return (symbol1154___evenv = string_to_symbol("_0000"),
BUNSPEC);
}


/* init-the-global-environment! */obj_t init_the_global_environment__144___evenv()
{
return symbol1153___evenv;
}


/* _init-the-global-environment! */obj_t _init_the_global_environment__212___evenv(obj_t env_551)
{
return symbol1153___evenv;
}


/* bind-eval-global! */obj_t bind_eval_global__246___evenv(obj_t name_1, obj_t var_2)
{
return putprop__88___r4_symbols_6_4(name_1, symbol1154___evenv, var_2);
}


/* _bind-eval-global! */obj_t _bind_eval_global__60___evenv(obj_t env_552, obj_t name_553, obj_t var_554)
{
return bind_eval_global__246___evenv(name_553, var_554);
}


/* unbind-primop! */obj_t unbind_primop__163___evenv(obj_t name_3)
{
return remprop__243___r4_symbols_6_4(name_3, symbol1154___evenv);
}


/* _unbind-primop! */obj_t _unbind_primop__162___evenv(obj_t env_555, obj_t name_556)
{
return unbind_primop__163___evenv(name_556);
}


/* define-primop! */obj_t define_primop__185___evenv(obj_t var_4, obj_t val_5)
{
{
obj_t cell_329;
{
obj_t prop_484;
prop_484 = getprop___r4_symbols_6_4(var_4, symbol1154___evenv);
if(CBOOL(prop_484)){
cell_329 = prop_484;
}
 else {
cell_329 = BFALSE;
}
}
{
bool_t test_598;
if(VECTORP(cell_329)){
long aux_601;
aux_601 = VECTOR_LENGTH(cell_329);
test_598 = (aux_601==((long)3));
}
 else {
test_598 = ((bool_t)0);
}
if(test_598){
return VECTOR_SET(cell_329, ((long)2), val_5);
}
 else {
obj_t arg1011_331;
{
obj_t v1002_332;
v1002_332 = create_vector(((long)3));
VECTOR_SET(v1002_332, ((long)2), val_5);
VECTOR_SET(v1002_332, ((long)1), var_4);
{
obj_t aux_608;
aux_608 = BINT(((long)0));
VECTOR_SET(v1002_332, ((long)0), aux_608);
}
arg1011_331 = v1002_332;
}
return putprop__88___r4_symbols_6_4(var_4, symbol1154___evenv, arg1011_331);
}
}
}
}


/* _define-primop! */obj_t _define_primop__215___evenv(obj_t env_557, obj_t var_558, obj_t val_559)
{
return define_primop__185___evenv(var_558, val_559);
}


/* define-primop-ref! */obj_t define_primop_ref__105___evenv(obj_t var_6, obj_t addr_7)
{
{
bool_t test_613;
{
obj_t prop_515;
prop_515 = getprop___r4_symbols_6_4(var_6, symbol1154___evenv);
if(CBOOL(prop_515)){
test_613 = CBOOL(prop_515);
}
 else {
test_613 = ((bool_t)0);
}
}
if(test_613){
return BUNSPEC;
}
 else {
obj_t arg1013_512;
{
obj_t v1003_513;
v1003_513 = create_vector(((long)3));
VECTOR_SET(v1003_513, ((long)2), addr_7);
VECTOR_SET(v1003_513, ((long)1), var_6);
{
obj_t aux_621;
aux_621 = BINT(((long)1));
VECTOR_SET(v1003_513, ((long)0), aux_621);
}
arg1013_512 = v1003_513;
}
return putprop__88___r4_symbols_6_4(var_6, symbol1154___evenv, arg1013_512);
}
}
}


/* _define-primop-ref! */obj_t _define_primop_ref__78___evenv(obj_t env_560, obj_t var_561, obj_t addr_562)
{
return define_primop_ref__105___evenv(var_561, addr_562);
}


/* eval-lookup */obj_t eval_lookup_172___evenv(obj_t var_8)
{
{
obj_t prop_529;
prop_529 = getprop___r4_symbols_6_4(var_8, symbol1154___evenv);
if(CBOOL(prop_529)){
return prop_529;
}
 else {
return BFALSE;
}
}
}


/* _eval-lookup */obj_t _eval_lookup_224___evenv(obj_t env_563, obj_t var_564)
{
return eval_lookup_172___evenv(var_564);
}


/* eval-global? */obj_t eval_global__95___evenv(obj_t variable_9)
{
if(VECTORP(variable_9)){
bool_t aux_632;
{
long aux_633;
aux_633 = VECTOR_LENGTH(variable_9);
aux_632 = (aux_633==((long)3));
}
return BBOOL(aux_632);
}
 else {
return BFALSE;
}
}


/* _eval-global? */obj_t _eval_global__27___evenv(obj_t env_565, obj_t variable_566)
{
{
obj_t variable_576;
variable_576 = variable_566;
if(VECTORP(variable_576)){
bool_t aux_639;
{
long aux_640;
aux_640 = VECTOR_LENGTH(variable_576);
aux_639 = (aux_640==((long)3));
}
return BBOOL(aux_639);
}
 else {
return BFALSE;
}
}
}


/* eval-global-tag */obj_t eval_global_tag_85___evenv(obj_t eval_global_101_10)
{
return VECTOR_REF(eval_global_101_10, ((long)0));
}


/* _eval-global-tag */obj_t _eval_global_tag_208___evenv(obj_t env_567, obj_t eval_global_101_568)
{
{
obj_t eval_global_101_577;
eval_global_101_577 = eval_global_101_568;
return VECTOR_REF(eval_global_101_577, ((long)0));
}
}


/* eval-global-name */obj_t eval_global_name_0___evenv(obj_t eval_global_101_11)
{
return VECTOR_REF(eval_global_101_11, ((long)1));
}


/* _eval-global-name */obj_t _eval_global_name_41___evenv(obj_t env_569, obj_t eval_global_101_570)
{
{
obj_t eval_global_101_578;
eval_global_101_578 = eval_global_101_570;
return VECTOR_REF(eval_global_101_578, ((long)1));
}
}


/* eval-global-value */obj_t eval_global_value_117___evenv(obj_t eval_global_101_12)
{
return VECTOR_REF(eval_global_101_12, ((long)2));
}


/* _eval-global-value */obj_t _eval_global_value_217___evenv(obj_t env_571, obj_t eval_global_101_572)
{
{
obj_t eval_global_101_579;
eval_global_101_579 = eval_global_101_572;
return VECTOR_REF(eval_global_101_579, ((long)2));
}
}


/* set-eval-global-value! */obj_t set_eval_global_value__218___evenv(obj_t eval_global_101_13, obj_t value_14)
{
return VECTOR_SET(eval_global_101_13, ((long)2), value_14);
}


/* _set-eval-global-value! */obj_t _set_eval_global_value__159___evenv(obj_t env_573, obj_t eval_global_101_574, obj_t value_575)
{
{
obj_t eval_global_101_580;
obj_t value_581;
eval_global_101_580 = eval_global_101_574;
value_581 = value_575;
return VECTOR_SET(eval_global_101_580, ((long)2), value_581);
}
}


/* imported-modules-init */obj_t imported_modules_init_94___evenv()
{
return module_initialization_70___r4_symbols_6_4(((long)0), "__EVENV");
}

