/*===========================================================================*/
/*   (Tools/trace.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

static obj_t _trace_satisfy__93_tools_trace(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t trace_satisfy__215_tools_trace(obj_t, obj_t);
static obj_t imported_modules_init_94_tools_trace();
static obj_t _print_trace_65_tools_trace(obj_t, obj_t);
static obj_t library_modules_init_112_tools_trace();
extern obj_t print_trace_107_tools_trace(obj_t);
extern obj_t stop_trace_98_tools_trace();
static obj_t toplevel_init_63_tools_trace();
extern obj_t open_input_string(obj_t);
static obj_t _level__58_tools_trace = BUNSPEC;
obj_t _trace_port__84_tools_trace = BUNSPEC;
static bool_t _trace_mode__16_tools_trace;
extern obj_t read___reader(obj_t);
static obj_t _start_trace_123_tools_trace(obj_t, obj_t, obj_t);
static obj_t _stop_trace_117_tools_trace(obj_t);
static obj_t require_initialization_114_tools_trace = BUNSPEC;
extern obj_t start_trace_17_tools_trace(obj_t, obj_t);
static obj_t _pass__125_tools_trace = BUNSPEC;
static obj_t cnst_init_137_tools_trace();
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(stop_trace_env_65_tools_trace, _stop_trace_117_tools_trace1034, _stop_trace_117_tools_trace, 0L, 0);
DEFINE_EXPORT_PROCEDURE(start_trace_env_195_tools_trace, _start_trace_123_tools_trace1035, _start_trace_123_tools_trace, 0L, 2);
DEFINE_EXPORT_PROCEDURE(trace_satisfy__env_167_tools_trace, _trace_satisfy__93_tools_trace1036, _trace_satisfy__93_tools_trace, 0L, 2);
DEFINE_EXPORT_PROCEDURE(print_trace_env_23_tools_trace, _print_trace_65_tools_trace1037, va_generic_entry, _print_trace_65_tools_trace, -1);
DEFINE_STRING(string1019_tools_trace, string1019_tools_trace1038, "NONE ", 5);


/* module-initialization */ obj_t 
module_initialization_70_tools_trace(long checksum_49, char *from_50)
{
   if (CBOOL(require_initialization_114_tools_trace))
     {
	require_initialization_114_tools_trace = BBOOL(((bool_t) 0));
	library_modules_init_112_tools_trace();
	cnst_init_137_tools_trace();
	imported_modules_init_94_tools_trace();
	toplevel_init_63_tools_trace();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_tools_trace()
{
   module_initialization_70___reader(((long) 0), "TOOLS_TRACE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_tools_trace()
{
   {
      obj_t cnst_port_138_41;
      cnst_port_138_41 = open_input_string(string1019_tools_trace);
      {
	 long i_42;
	 i_42 = ((long) 0);
       loop_43:
	 {
	    bool_t test1021_44;
	    test1021_44 = (i_42 == ((long) -1));
	    if (test1021_44)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1025_45;
		    {
		       obj_t list1026_46;
		       {
			  obj_t arg1032_47;
			  arg1032_47 = BNIL;
			  list1026_46 = MAKE_PAIR(cnst_port_138_41, arg1032_47);
		       }
		       arg1025_45 = read___reader(list1026_46);
		    }
		    CNST_TABLE_SET(i_42, arg1025_45);
		 }
		 {
		    int aux_48;
		    {
		       long aux_65;
		       aux_65 = (i_42 - ((long) 1));
		       aux_48 = (int) (aux_65);
		    }
		    {
		       long i_68;
		       i_68 = (long) (aux_48);
		       i_42 = i_68;
		       goto loop_43;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_tools_trace()
{
   _trace_port__84_tools_trace = BFALSE;
   _pass__125_tools_trace = CNST_TABLE_REF(((long) 0));
   _level__58_tools_trace = BINT(((long) 0));
   return (_trace_mode__16_tools_trace = ((bool_t) 0),
      BUNSPEC);
}


/* start-trace */ obj_t 
start_trace_17_tools_trace(obj_t level_1, obj_t pass_2)
{
   return BUNSPEC;
}


/* _start-trace */ obj_t 
_start_trace_123_tools_trace(obj_t env_32, obj_t level_33, obj_t pass_34)
{
   return start_trace_17_tools_trace(level_33, pass_34);
}


/* stop-trace */ obj_t 
stop_trace_98_tools_trace()
{
   return BUNSPEC;
}


/* _stop-trace */ obj_t 
_stop_trace_117_tools_trace(obj_t env_35)
{
   return stop_trace_98_tools_trace();
}


/* trace-satisfy? */ obj_t 
trace_satisfy__215_tools_trace(obj_t pass_3, obj_t level_4)
{
   return BFALSE;
}


/* _trace-satisfy? */ obj_t 
_trace_satisfy__93_tools_trace(obj_t env_36, obj_t pass_37, obj_t level_38)
{
   return trace_satisfy__215_tools_trace(pass_37, level_38);
}


/* print-trace */ obj_t 
print_trace_107_tools_trace(obj_t exp_5)
{
   return BUNSPEC;
}


/* _print-trace */ obj_t 
_print_trace_65_tools_trace(obj_t env_39, obj_t exp_40)
{
   return print_trace_107_tools_trace(exp_40);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_tools_trace()
{
   module_initialization_70_engine_param(((long) 0), "TOOLS_TRACE");
   return module_initialization_70_tools_error(((long) 0), "TOOLS_TRACE");
}
