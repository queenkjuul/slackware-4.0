/*===========================================================================*/
/*   (Reduce/cse.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_reduce_cse();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
static long _cse_removed__19_reduce_cse;
extern obj_t _res1__155___r5_control_features_6_4;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t closure_ast_node;
extern obj_t create_struct(obj_t, long);
static obj_t node_cse__default1517_194_reduce_cse(node_t, obj_t);
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_reduce_cse(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_coerce_coerce(long, char *);
extern obj_t module_initialization_70_effect_effect(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_lvtype(long, char *);
extern obj_t module_initialization_70_reduce_same(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r5_control_features_6_4(long, char *);
extern long class_num_218___object(obj_t);
static obj_t node_cse___11_reduce_cse(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_reduce_cse();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t find_stack_136_reduce_cse(node_t, obj_t);
extern obj_t app_ast_node;
extern obj_t append_2_18___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t library_modules_init_112_reduce_cse();
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_reduce_cse();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
extern bool_t side_effect__165_effect_effect(node_t);
static obj_t _node_cse_1800_180_reduce_cse(obj_t, obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern obj_t variable_ast_var;
extern obj_t node_cse__231_reduce_cse(node_t, obj_t);
static obj_t _reduce_cse__182_reduce_cse(obj_t, obj_t);
extern obj_t _res_number__75___r5_control_features_6_4;
static obj_t _node_cse__default1517_95_reduce_cse(obj_t, obj_t, obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t reduce_cse__211_reduce_cse(obj_t);
extern obj_t read___reader(obj_t);
extern bool_t same_node__38_reduce_same(node_t, node_t, obj_t);
static obj_t require_initialization_114_reduce_cse = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t cnst_init_137_reduce_cse();
static obj_t __cnst[3];

DEFINE_EXPORT_PROCEDURE(reduce_cse__env_219_reduce_cse, _reduce_cse__182_reduce_cse1810, _reduce_cse__182_reduce_cse, 0L, 1);
DEFINE_EXPORT_GENERIC(node_cse__env_198_reduce_cse, _node_cse_1800_180_reduce_cse1811, _node_cse_1800_180_reduce_cse, 0L, 2);
DEFINE_STATIC_PROCEDURE(node_cse__default1517_env_246_reduce_cse, _node_cse__default1517_95_reduce_cse1812, _node_cse__default1517_95_reduce_cse, 0L, 2);
DEFINE_STRING(string1804_reduce_cse, string1804_reduce_cse1813, "NODE-CSE!-DEFAULT1517 CALL READ ", 32);
DEFINE_STRING(string1803_reduce_cse, string1803_reduce_cse1814, "No method for this object", 25);
DEFINE_STRING(string1802_reduce_cse, string1802_reduce_cse1815, "(removed : ", 11);
DEFINE_STRING(string1801_reduce_cse, string1801_reduce_cse1816, "      cse                    ", 29);


/* module-initialization */ obj_t 
module_initialization_70_reduce_cse(long checksum_1660, char *from_1661)
{
   if (CBOOL(require_initialization_114_reduce_cse))
     {
	require_initialization_114_reduce_cse = BBOOL(((bool_t) 0));
	library_modules_init_112_reduce_cse();
	cnst_init_137_reduce_cse();
	imported_modules_init_94_reduce_cse();
	method_init_76_reduce_cse();
	toplevel_init_63_reduce_cse();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_reduce_cse()
{
   module_initialization_70___object(((long) 0), "REDUCE_CSE");
   module_initialization_70___r5_control_features_6_4(((long) 0), "REDUCE_CSE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "REDUCE_CSE");
   module_initialization_70___reader(((long) 0), "REDUCE_CSE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_reduce_cse()
{
   {
      obj_t cnst_port_138_1652;
      cnst_port_138_1652 = open_input_string(string1804_reduce_cse);
      {
	 long i_1653;
	 i_1653 = ((long) 2);
       loop_1654:
	 {
	    bool_t test1805_1655;
	    test1805_1655 = (i_1653 == ((long) -1));
	    if (test1805_1655)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1806_1656;
		    {
		       obj_t list1807_1657;
		       {
			  obj_t arg1808_1658;
			  arg1808_1658 = BNIL;
			  list1807_1657 = MAKE_PAIR(cnst_port_138_1652, arg1808_1658);
		       }
		       arg1806_1656 = read___reader(list1807_1657);
		    }
		    CNST_TABLE_SET(i_1653, arg1806_1656);
		 }
		 {
		    int aux_1659;
		    {
		       long aux_1680;
		       aux_1680 = (i_1653 - ((long) 1));
		       aux_1659 = (int) (aux_1680);
		    }
		    {
		       long i_1683;
		       i_1683 = (long) (aux_1659);
		       i_1653 = i_1683;
		       goto loop_1654;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_reduce_cse()
{
   _cse_removed__19_reduce_cse = ((long) 0);
   return BUNSPEC;
}


/* reduce-cse! */ obj_t 
reduce_cse__211_reduce_cse(obj_t globals_1)
{
   {
      obj_t list1548_753;
      list1548_753 = MAKE_PAIR(string1801_reduce_cse, BNIL);
      verbose_tools_speek(BINT(((long) 2)), list1548_753);
   }
   _cse_removed__19_reduce_cse = ((long) 0);
   {
      obj_t l1435_756;
      l1435_756 = globals_1;
    lname1436_757:
      if (PAIRP(l1435_756))
	{
	   {
	      value_t fun_760;
	      {
		 global_t obj_1416;
		 {
		    obj_t aux_1690;
		    aux_1690 = CAR(l1435_756);
		    obj_1416 = (global_t) (aux_1690);
		 }
		 fun_760 = (((global_t) CREF(obj_1416))->value);
	      }
	      {
		 {
		    obj_t arg1552_762;
		    {
		       obj_t __763;
		       {
			  node_t aux_1694;
			  {
			     obj_t aux_1695;
			     {
				sfun_t obj_1417;
				obj_1417 = (sfun_t) (fun_760);
				aux_1695 = (((sfun_t) CREF(obj_1417))->body);
			     }
			     aux_1694 = (node_t) (aux_1695);
			  }
			  __763 = node_cse__231_reduce_cse(aux_1694, BNIL);
		       }
		       {
			  obj_t node_764;
			  node_764 = _res1__155___r5_control_features_6_4;
			  arg1552_762 = node_764;
		       }
		    }
		    {
		       sfun_t obj_1418;
		       obj_1418 = (sfun_t) (fun_760);
		       ((((sfun_t) CREF(obj_1418))->body) = ((obj_t) arg1552_762), BUNSPEC);
		    }
		 }
		 BUNSPEC;
	      }
	   }
	   {
	      obj_t l1435_1702;
	      l1435_1702 = CDR(l1435_756);
	      l1435_756 = l1435_1702;
	      goto lname1436_757;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   {
      obj_t list1555_767;
      {
	 obj_t arg1557_769;
	 {
	    obj_t arg1558_770;
	    {
	       obj_t arg1559_771;
	       {
		  obj_t aux_1704;
		  aux_1704 = BCHAR(((unsigned char) '\n'));
		  arg1559_771 = MAKE_PAIR(aux_1704, BNIL);
	       }
	       {
		  obj_t aux_1707;
		  aux_1707 = BCHAR(((unsigned char) ')'));
		  arg1558_770 = MAKE_PAIR(aux_1707, arg1559_771);
	       }
	    }
	    {
	       obj_t aux_1710;
	       aux_1710 = BINT(_cse_removed__19_reduce_cse);
	       arg1557_769 = MAKE_PAIR(aux_1710, arg1558_770);
	    }
	 }
	 list1555_767 = MAKE_PAIR(string1802_reduce_cse, arg1557_769);
      }
      verbose_tools_speek(BINT(((long) 2)), list1555_767);
   }
   return globals_1;
}


/* _reduce-cse! */ obj_t 
_reduce_cse__182_reduce_cse(obj_t env_1643, obj_t globals_1644)
{
   return reduce_cse__211_reduce_cse(globals_1644);
}


/* node-cse*! */ obj_t 
node_cse___11_reduce_cse(obj_t node__221_48, obj_t stack_49)
{
   {
      obj_t node__221_773;
      bool_t reset_774;
      obj_t stack_775;
      node__221_773 = node__221_48;
      reset_774 = ((bool_t) 0);
      stack_775 = stack_49;
    loop_776:
      if (NULLP(node__221_773))
	{
	   return BBOOL(reset_774);
	}
      else
	{
	   bool_t test_1720;
	   {
	      obj_t aux_1721;
	      aux_1721 = CDR(node__221_773);
	      test_1720 = NULLP(aux_1721);
	   }
	   if (test_1720)
	     {
		{
		   obj_t reset__69_779;
		   {
		      node_t aux_1724;
		      {
			 obj_t aux_1725;
			 aux_1725 = CAR(node__221_773);
			 aux_1724 = (node_t) (aux_1725);
		      }
		      reset__69_779 = node_cse__231_reduce_cse(aux_1724, stack_775);
		   }
		   {
		      obj_t node_780;
		      node_780 = _res1__155___r5_control_features_6_4;
		      SET_CAR(node__221_773, node_780);
		      if (reset_774)
			{
			   return BBOOL(reset_774);
			}
		      else
			{
			   return reset__69_779;
			}
		   }
		}
	     }
	   else
	     {
		{
		   obj_t reset__69_783;
		   {
		      node_t aux_1732;
		      {
			 obj_t aux_1733;
			 aux_1733 = CAR(node__221_773);
			 aux_1732 = (node_t) (aux_1733);
		      }
		      reset__69_783 = node_cse__231_reduce_cse(aux_1732, stack_775);
		   }
		   {
		      obj_t node_784;
		      node_784 = _res1__155___r5_control_features_6_4;
		      SET_CAR(node__221_773, node_784);
		      {
			 bool_t test_1738;
			 if (reset_774)
			   {
			      test_1738 = ((bool_t) 1);
			   }
			 else
			   {
			      test_1738 = CBOOL(reset__69_783);
			   }
			 if (test_1738)
			   {
			      obj_t stack_1744;
			      bool_t reset_1743;
			      obj_t node__221_1741;
			      node__221_1741 = CDR(node__221_773);
			      reset_1743 = ((bool_t) 1);
			      stack_1744 = BNIL;
			      stack_775 = stack_1744;
			      reset_774 = reset_1743;
			      node__221_773 = node__221_1741;
			      goto loop_776;
			   }
			 else
			   {
			      bool_t reset_1747;
			      obj_t node__221_1745;
			      node__221_1745 = CDR(node__221_773);
			      reset_1747 = ((bool_t) 0);
			      reset_774 = reset_1747;
			      node__221_773 = node__221_1745;
			      goto loop_776;
			   }
		      }
		   }
		}
	     }
	}
   }
}


/* find-stack */ obj_t 
find_stack_136_reduce_cse(node_t node_60, obj_t stack_61)
{
   {
      obj_t stack_808;
      stack_808 = stack_61;
    loop_809:
      if (NULLP(stack_808))
	{
	   return BFALSE;
	}
      else
	{
	   bool_t test1594_811;
	   {
	      node_t aux_1750;
	      {
		 obj_t aux_1751;
		 {
		    obj_t aux_1752;
		    aux_1752 = CAR(stack_808);
		    aux_1751 = STRUCT_REF(aux_1752, ((long) 0));
		 }
		 aux_1750 = (node_t) (aux_1751);
	      }
	      test1594_811 = same_node__38_reduce_same(node_60, aux_1750, BNIL);
	   }
	   if (test1594_811)
	     {
		{
		   obj_t aux_1758;
		   aux_1758 = CAR(stack_808);
		   return STRUCT_REF(aux_1758, ((long) 1));
		}
	     }
	   else
	     {
		{
		   obj_t stack_1761;
		   stack_1761 = CDR(stack_808);
		   stack_808 = stack_1761;
		   goto loop_809;
		}
	     }
	}
   }
}


/* method-init */ obj_t 
method_init_76_reduce_cse()
{
   add_generic__110___object(node_cse__env_198_reduce_cse, node_cse__default1517_env_246_reduce_cse);
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, var_ast_node, ((long) 2));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, select_ast_node, ((long) 12));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, set_ex_it_116_ast_node, ((long) 14));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, jump_ex_it_184_ast_node, ((long) 15));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, make_box_202_ast_node, ((long) 16));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, box_set__221_ast_node, ((long) 17));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, box_ref_242_ast_node, ((long) 18));
   add_inlined_method__244___object(node_cse__env_198_reduce_cse, app_ast_node, ((long) 19));
   {
      long aux_1784;
      aux_1784 = add_inlined_method__244___object(node_cse__env_198_reduce_cse, let_var_6_ast_node, ((long) 20));
      return BINT(aux_1784);
   }
}


/* node-cse! */ obj_t 
node_cse__231_reduce_cse(node_t node_2, obj_t stack_3)
{
   {
      obj_t method1699_1148;
      obj_t class1704_1149;
      {
	 obj_t arg1707_1146;
	 obj_t arg1708_1147;
	 {
	    object_t obj_1472;
	    obj_1472 = (object_t) (node_2);
	    {
	       obj_t pre_method_105_1473;
	       pre_method_105_1473 = PROCEDURE_REF(node_cse__env_198_reduce_cse, ((long) 2));
	       if (INTEGERP(pre_method_105_1473))
		 {
		    PROCEDURE_SET(node_cse__env_198_reduce_cse, ((long) 2), BUNSPEC);
		    arg1707_1146 = pre_method_105_1473;
		 }
	       else
		 {
		    long obj_class_num_177_1478;
		    obj_class_num_177_1478 = TYPE(obj_1472);
		    {
		       obj_t arg1177_1479;
		       arg1177_1479 = PROCEDURE_REF(node_cse__env_198_reduce_cse, ((long) 1));
		       {
			  long arg1178_1483;
			  {
			     long arg1179_1484;
			     arg1179_1484 = OBJECT_TYPE;
			     arg1178_1483 = (obj_class_num_177_1478 - arg1179_1484);
			  }
			  arg1707_1146 = VECTOR_REF(arg1177_1479, arg1178_1483);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1489;
	    object_1489 = (object_t) (node_2);
	    {
	       long arg1180_1490;
	       {
		  long arg1181_1491;
		  long arg1182_1492;
		  arg1181_1491 = TYPE(object_1489);
		  arg1182_1492 = OBJECT_TYPE;
		  arg1180_1490 = (arg1181_1491 - arg1182_1492);
	       }
	       {
		  obj_t vector_1496;
		  vector_1496 = _classes__134___object;
		  arg1708_1147 = VECTOR_REF(vector_1496, arg1180_1490);
	       }
	    }
	 }
	 method1699_1148 = arg1707_1146;
	 class1704_1149 = arg1708_1147;
	 {
	    if (INTEGERP(method1699_1148))
	      {
		 switch ((long) CINT(method1699_1148))
		   {
		   case ((long) 0):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 atom_t aux_1805;
			 aux_1805 = (atom_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1805);
		      }
		      return BFALSE;
		      break;
		   case ((long) 1):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 kwote_t aux_1809;
			 aux_1809 = (kwote_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1809);
		      }
		      return BFALSE;
		      break;
		   case ((long) 2):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 var_t aux_1813;
			 aux_1813 = (var_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1813);
		      }
		      return BFALSE;
		      break;
		   case ((long) 3):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 closure_t aux_1817;
			 aux_1817 = (closure_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1817);
		      }
		      return BFALSE;
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1171;
			 node_1171 = (sequence_t) (node_2);
			 {
			    obj_t val0_1446_1174;
			    val0_1446_1174 = node_cse___11_reduce_cse((((sequence_t) CREF(node_1171))->nodes), stack_3);
			    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			    _res1__155___r5_control_features_6_4 = (obj_t) (node_1171);
			    return val0_1446_1174;
			 }
		      }
		      break;
		   case ((long) 5):
		      {
			 app_ly_162_t node_1177;
			 node_1177 = (app_ly_162_t) (node_2);
			 {
			    obj_t reset_1180;
			    reset_1180 = node_cse__231_reduce_cse((((app_ly_162_t) CREF(node_1177))->fun), stack_3);
			    {
			       obj_t nfun_1181;
			       nfun_1181 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1263_1501;
				  val1263_1501 = (node_t) (nfun_1181);
				  ((((app_ly_162_t) CREF(node_1177))->fun) = ((node_t) val1263_1501), BUNSPEC);
			       }
			       {
				  obj_t reset__69_1182;
				  {
				     obj_t aux_1830;
				     if (CBOOL(reset_1180))
				       {
					  aux_1830 = BNIL;
				       }
				     else
				       {
					  aux_1830 = stack_3;
				       }
				     reset__69_1182 = node_cse__231_reduce_cse((((app_ly_162_t) CREF(node_1177))->arg), aux_1830);
				  }
				  {
				     obj_t narg_1183;
				     narg_1183 = _res1__155___r5_control_features_6_4;
				     {
					node_t val1264_1504;
					val1264_1504 = (node_t) (narg_1183);
					((((app_ly_162_t) CREF(node_1177))->arg) = ((node_t) val1264_1504), BUNSPEC);
				     }
				     _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				     _res1__155___r5_control_features_6_4 = (obj_t) (node_1177);
				     if (CBOOL(reset_1180))
				       {
					  return reset_1180;
				       }
				     else
				       {
					  return reset__69_1182;
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 6):
		      {
			 funcall_t node_1190;
			 node_1190 = (funcall_t) (node_2);
			 {
			    obj_t reset__69_1193;
			    reset__69_1193 = node_cse___11_reduce_cse((((funcall_t) CREF(node_1190))->args), stack_3);
			    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			    _res1__155___r5_control_features_6_4 = (obj_t) (node_1190);
			    return reset__69_1193;
			 }
		      }
		      break;
		   case ((long) 7):
		      {
			 pragma_t node_1197;
			 node_1197 = (pragma_t) (node_2);
			 {
			    obj_t reset__69_1200;
			    reset__69_1200 = node_cse___11_reduce_cse((((pragma_t) CREF(node_1197))->args), stack_3);
			    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			    _res1__155___r5_control_features_6_4 = (obj_t) (node_1197);
			    return reset__69_1200;
			 }
		      }
		      break;
		   case ((long) 8):
		      {
			 cast_t node_1204;
			 node_1204 = (cast_t) (node_2);
			 {
			    obj_t reset_1207;
			    reset_1207 = node_cse__231_reduce_cse((((cast_t) CREF(node_1204))->arg), stack_3);
			    {
			       obj_t narg_1208;
			       narg_1208 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1297_1509;
				  val1297_1509 = (node_t) (narg_1208);
				  ((((cast_t) CREF(node_1204))->arg) = ((node_t) val1297_1509), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1204);
			       return reset_1207;
			    }
			 }
		      }
		      break;
		   case ((long) 9):
		      {
			 setq_t node_1212;
			 node_1212 = (setq_t) (node_2);
			 {
			    obj_t reset_1215;
			    reset_1215 = node_cse__231_reduce_cse((((setq_t) CREF(node_1212))->value), stack_3);
			    {
			       obj_t nvalue_1216;
			       nvalue_1216 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1307_1512;
				  val1307_1512 = (node_t) (nvalue_1216);
				  ((((setq_t) CREF(node_1212))->value) = ((node_t) val1307_1512), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1212);
			       return reset_1215;
			    }
			 }
		      }
		      break;
		   case ((long) 10):
		      {
			 conditional_t node_1220;
			 node_1220 = (conditional_t) (node_2);
			 {
			    obj_t reset_1223;
			    reset_1223 = node_cse__231_reduce_cse((((conditional_t) CREF(node_1220))->test), stack_3);
			    {
			       obj_t ntest_1224;
			       ntest_1224 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1321_1515;
				  val1321_1515 = (node_t) (ntest_1224);
				  ((((conditional_t) CREF(node_1220))->test) = ((node_t) val1321_1515), BUNSPEC);
			       }
			       {
				  obj_t stack__1_1225;
				  if (CBOOL(reset_1223))
				    {
				       stack__1_1225 = BNIL;
				    }
				  else
				    {
				       stack__1_1225 = stack_3;
				    }
				  {
				     obj_t reset__69_1226;
				     reset__69_1226 = node_cse__231_reduce_cse((((conditional_t) CREF(node_1220))->true), stack__1_1225);
				     {
					obj_t ntrue_1227;
					ntrue_1227 = _res1__155___r5_control_features_6_4;
					{
					   node_t val1322_1518;
					   val1322_1518 = (node_t) (ntrue_1227);
					   ((((conditional_t) CREF(node_1220))->true) = ((node_t) val1322_1518), BUNSPEC);
					}
					{
					   obj_t reset___255_1228;
					   reset___255_1228 = node_cse__231_reduce_cse((((conditional_t) CREF(node_1220))->false), stack__1_1225);
					   {
					      obj_t nfalse_1229;
					      nfalse_1229 = _res1__155___r5_control_features_6_4;
					      {
						 node_t val1323_1521;
						 val1323_1521 = (node_t) (nfalse_1229);
						 ((((conditional_t) CREF(node_1220))->false) = ((node_t) val1323_1521), BUNSPEC);
					      }
					      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					      _res1__155___r5_control_features_6_4 = (obj_t) (node_1220);
					      if (CBOOL(reset_1223))
						{
						   return reset_1223;
						}
					      else
						{
						   if (CBOOL(reset__69_1226))
						     {
							return reset__69_1226;
						     }
						   else
						     {
							return reset___255_1228;
						     }
						}
					   }
					}
				     }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 11):
		      {
			 fail_t node_1237;
			 node_1237 = (fail_t) (node_2);
			 {
			    obj_t reset_1240;
			    reset_1240 = node_cse__231_reduce_cse((((fail_t) CREF(node_1237))->proc), stack_3);
			    {
			       obj_t nproc_1241;
			       nproc_1241 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1333_1524;
				  val1333_1524 = (node_t) (nproc_1241);
				  ((((fail_t) CREF(node_1237))->proc) = ((node_t) val1333_1524), BUNSPEC);
			       }
			       {
				  obj_t stack__1_1242;
				  if (CBOOL(reset_1240))
				    {
				       stack__1_1242 = BNIL;
				    }
				  else
				    {
				       stack__1_1242 = stack_3;
				    }
				  {
				     obj_t reset__69_1243;
				     reset__69_1243 = node_cse__231_reduce_cse((((fail_t) CREF(node_1237))->msg), stack__1_1242);
				     {
					obj_t nmsg_1244;
					nmsg_1244 = _res1__155___r5_control_features_6_4;
					{
					   node_t val1334_1527;
					   val1334_1527 = (node_t) (nmsg_1244);
					   ((((fail_t) CREF(node_1237))->msg) = ((node_t) val1334_1527), BUNSPEC);
					}
					{
					   obj_t reset___255_1246;
					   {
					      obj_t aux_1897;
					      if (CBOOL(reset__69_1243))
						{
						   aux_1897 = BNIL;
						}
					      else
						{
						   aux_1897 = stack__1_1242;
						}
					      reset___255_1246 = node_cse__231_reduce_cse((((fail_t) CREF(node_1237))->obj), aux_1897);
					   }
					   {
					      obj_t nobj_1247;
					      nobj_1247 = _res1__155___r5_control_features_6_4;
					      {
						 node_t val1335_1530;
						 val1335_1530 = (node_t) (nobj_1247);
						 ((((fail_t) CREF(node_1237))->obj) = ((node_t) val1335_1530), BUNSPEC);
					      }
					      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					      _res1__155___r5_control_features_6_4 = (obj_t) (node_1237);
					      if (CBOOL(reset_1240))
						{
						   return reset_1240;
						}
					      else
						{
						   if (CBOOL(reset__69_1243))
						     {
							return reset__69_1243;
						     }
						   else
						     {
							return reset___255_1246;
						     }
						}
					   }
					}
				     }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 12):
		      {
			 select_t node_1255;
			 node_1255 = (select_t) (node_2);
			 {
			    obj_t reset_1258;
			    reset_1258 = node_cse__231_reduce_cse((((select_t) CREF(node_1255))->test), stack_3);
			    {
			       obj_t ntest_1259;
			       ntest_1259 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1349_1533;
				  val1349_1533 = (node_t) (ntest_1259);
				  ((((select_t) CREF(node_1255))->test) = ((node_t) val1349_1533), BUNSPEC);
			       }
			       {
				  obj_t clauses_1261;
				  obj_t reset_1262;
				  clauses_1261 = (((select_t) CREF(node_1255))->clauses);
				  reset_1262 = reset_1258;
				loop_1263:
				  if (NULLP(clauses_1261))
				    {
				       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				       _res1__155___r5_control_features_6_4 = (obj_t) (node_1255);
				       return reset_1262;
				    }
				  else
				    {
				       obj_t clause_1268;
				       clause_1268 = CAR(clauses_1261);
				       {
					  obj_t reset__69_1269;
					  {
					     node_t aux_1920;
					     {
						obj_t aux_1921;
						aux_1921 = CDR(clause_1268);
						aux_1920 = (node_t) (aux_1921);
					     }
					     reset__69_1269 = node_cse__231_reduce_cse(aux_1920, stack_3);
					  }
					  {
					     obj_t nclause_1270;
					     nclause_1270 = _res1__155___r5_control_features_6_4;
					     SET_CDR(clause_1268, nclause_1270);
					     {
						obj_t reset_1928;
						obj_t clauses_1926;
						clauses_1926 = CDR(clauses_1261);
						if (CBOOL(reset_1262))
						  {
						     reset_1928 = reset_1262;
						  }
						else
						  {
						     reset_1928 = reset__69_1269;
						  }
						reset_1262 = reset_1928;
						clauses_1261 = clauses_1926;
						goto loop_1263;
					     }
					  }
				       }
				    }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 13):
		      {
			 let_fun_218_t node_1276;
			 node_1276 = (let_fun_218_t) (node_2);
			 {
			    obj_t reset_1279;
			    reset_1279 = node_cse__231_reduce_cse((((let_fun_218_t) CREF(node_1276))->body), stack_3);
			    {
			       obj_t nbody_1280;
			       nbody_1280 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1363_1543;
				  val1363_1543 = (node_t) (nbody_1280);
				  ((((let_fun_218_t) CREF(node_1276))->body) = ((node_t) val1363_1543), BUNSPEC);
			       }
			       {
				  obj_t locals_1281;
				  obj_t reset_1282;
				  locals_1281 = (((let_fun_218_t) CREF(node_1276))->locals);
				  reset_1282 = reset_1279;
				loop_1283:
				  if (NULLP(locals_1281))
				    {
				       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				       _res1__155___r5_control_features_6_4 = (obj_t) (node_1276);
				       return reset_1282;
				    }
				  else
				    {
				       value_t sfun_1289;
				       {
					  local_t obj_1547;
					  {
					     obj_t aux_1941;
					     aux_1941 = CAR(locals_1281);
					     obj_1547 = (local_t) (aux_1941);
					  }
					  sfun_1289 = (((local_t) CREF(obj_1547))->value);
				       }
				       {
					  {
					     obj_t reset__69_1290;
					     {
						node_t aux_1945;
						{
						   obj_t aux_1946;
						   {
						      sfun_t obj_1548;
						      obj_1548 = (sfun_t) (sfun_1289);
						      aux_1946 = (((sfun_t) CREF(obj_1548))->body);
						   }
						   aux_1945 = (node_t) (aux_1946);
						}
						reset__69_1290 = node_cse__231_reduce_cse(aux_1945, BNIL);
					     }
					     {
						obj_t nbody_1291;
						nbody_1291 = _res1__155___r5_control_features_6_4;
						{
						   sfun_t obj_1549;
						   obj_1549 = (sfun_t) (sfun_1289);
						   ((((sfun_t) CREF(obj_1549))->body) = ((obj_t) nbody_1291), BUNSPEC);
						}
						{
						   obj_t reset_1955;
						   obj_t locals_1953;
						   locals_1953 = CDR(locals_1281);
						   if (CBOOL(reset_1282))
						     {
							reset_1955 = reset_1282;
						     }
						   else
						     {
							reset_1955 = reset__69_1290;
						     }
						   reset_1282 = reset_1955;
						   locals_1281 = locals_1953;
						   goto loop_1283;
						}
					     }
					  }
				       }
				    }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 14):
		      {
			 set_ex_it_116_t node_1298;
			 node_1298 = (set_ex_it_116_t) (node_2);
			 {
			    obj_t reset_1301;
			    reset_1301 = node_cse__231_reduce_cse((((set_ex_it_116_t) CREF(node_1298))->body), BNIL);
			    {
			       obj_t nbody_1302;
			       nbody_1302 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1389_1554;
				  val1389_1554 = (node_t) (nbody_1302);
				  ((((set_ex_it_116_t) CREF(node_1298))->body) = ((node_t) val1389_1554), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1298);
			       return reset_1301;
			    }
			 }
		      }
		      break;
		   case ((long) 15):
		      {
			 jump_ex_it_184_t node_1307;
			 node_1307 = (jump_ex_it_184_t) (node_2);
			 {
			    obj_t reset_1310;
			    reset_1310 = node_cse__231_reduce_cse((((jump_ex_it_184_t) CREF(node_1307))->exit), stack_3);
			    {
			       obj_t nexit_1311;
			       nexit_1311 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1398_1557;
				  val1398_1557 = (node_t) (nexit_1311);
				  ((((jump_ex_it_184_t) CREF(node_1307))->exit) = ((node_t) val1398_1557), BUNSPEC);
			       }
			       {
				  obj_t reset__69_1313;
				  {
				     obj_t aux_1971;
				     if (CBOOL(reset_1310))
				       {
					  aux_1971 = BNIL;
				       }
				     else
				       {
					  aux_1971 = stack_3;
				       }
				     reset__69_1313 = node_cse__231_reduce_cse((((jump_ex_it_184_t) CREF(node_1307))->value), aux_1971);
				  }
				  {
				     obj_t nvalue_1314;
				     nvalue_1314 = _res1__155___r5_control_features_6_4;
				     {
					node_t val1399_1560;
					val1399_1560 = (node_t) (nvalue_1314);
					((((jump_ex_it_184_t) CREF(node_1307))->value) = ((node_t) val1399_1560), BUNSPEC);
				     }
				     _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				     _res1__155___r5_control_features_6_4 = (obj_t) (node_1307);
				     if (CBOOL(reset_1310))
				       {
					  return reset_1310;
				       }
				     else
				       {
					  return reset__69_1313;
				       }
				  }
			       }
			    }
			 }
		      }
		      break;
		   case ((long) 16):
		      {
			 make_box_202_t node_1320;
			 node_1320 = (make_box_202_t) (node_2);
			 {
			    obj_t reset_1323;
			    reset_1323 = node_cse__231_reduce_cse((((make_box_202_t) CREF(node_1320))->value), stack_3);
			    {
			       obj_t nvalue_1324;
			       nvalue_1324 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1411_1563;
				  val1411_1563 = (node_t) (nvalue_1324);
				  ((((make_box_202_t) CREF(node_1320))->value) = ((node_t) val1411_1563), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1320);
			       return reset_1323;
			    }
			 }
		      }
		      break;
		   case ((long) 17):
		      {
			 box_set__221_t node_1328;
			 node_1328 = (box_set__221_t) (node_2);
			 {
			    obj_t reset_1331;
			    reset_1331 = node_cse__231_reduce_cse((((box_set__221_t) CREF(node_1328))->value), stack_3);
			    {
			       obj_t nvalue_1332;
			       nvalue_1332 = _res1__155___r5_control_features_6_4;
			       {
				  node_t val1433_1566;
				  val1433_1566 = (node_t) (nvalue_1332);
				  ((((box_set__221_t) CREF(node_1328))->value) = ((node_t) val1433_1566), BUNSPEC);
			       }
			       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
			       _res1__155___r5_control_features_6_4 = (obj_t) (node_1328);
			       return reset_1331;
			    }
			 }
		      }
		      break;
		   case ((long) 18):
		      _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
		      {
			 box_ref_242_t aux_1997;
			 aux_1997 = (box_ref_242_t) (node_2);
			 _res1__155___r5_control_features_6_4 = (obj_t) (aux_1997);
		      }
		      return BFALSE;
		      break;
		   case ((long) 19):
		      {
			 app_t node_1340;
			 node_1340 = (app_t) (node_2);
			 {
			    obj_t reset_1343;
			    reset_1343 = node_cse___11_reduce_cse((((app_t) CREF(node_1340))->args), stack_3);
			    {
			       bool_t test1754_1344;
			       if (CBOOL(reset_1343))
				 {
				    test1754_1344 = ((bool_t) 1);
				 }
			       else
				 {
				    test1754_1344 = side_effect__165_effect_effect((node_t) (node_1340));
				 }
			       if (test1754_1344)
				 {
				    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
				    _res1__155___r5_control_features_6_4 = (obj_t) (node_1340);
				    return BTRUE;
				 }
			       else
				 {
				    obj_t previous_1347;
				    previous_1347 = find_stack_136_reduce_cse((node_t) (node_1340), stack_3);
				    {
				       bool_t test1755_1348;
				       test1755_1348 = is_a__118___object(previous_1347, variable_ast_var);
				       if (test1755_1348)
					 {
					    {
					       long z2_1570;
					       z2_1570 = _cse_removed__19_reduce_cse;
					       _cse_removed__19_reduce_cse = (((long) 1) + z2_1570);
					    }
					    {
					       var_t val1_1501_1350;
					       {
						  obj_t arg1758_1351;
						  type_t arg1759_1352;
						  arg1758_1351 = (((app_t) CREF(node_1340))->loc);
						  arg1759_1352 = (((app_t) CREF(node_1340))->type);
						  {
						     var_t res1797_1583;
						     {
							variable_t variable_1575;
							variable_1575 = (variable_t) (previous_1347);
							{
							   var_t new1206_1576;
							   new1206_1576 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
							   {
							      long arg1657_1577;
							      arg1657_1577 = class_num_218___object(var_ast_node);
							      {
								 obj_t obj_1581;
								 obj_1581 = (obj_t) (new1206_1576);
								 (((obj_t) CREF(obj_1581))->header = MAKE_HEADER(arg1657_1577, 0), BUNSPEC);
							      }
							   }
							   {
							      object_t aux_2022;
							      aux_2022 = (object_t) (new1206_1576);
							      OBJECT_WIDENING_SET(aux_2022, BFALSE);
							   }
							   ((((var_t) CREF(new1206_1576))->loc) = ((obj_t) arg1758_1351), BUNSPEC);
							   ((((var_t) CREF(new1206_1576))->type) = ((type_t) arg1759_1352), BUNSPEC);
							   ((((var_t) CREF(new1206_1576))->variable) = ((variable_t) variable_1575), BUNSPEC);
							   res1797_1583 = new1206_1576;
							}
						     }
						     val1_1501_1350 = res1797_1583;
						  }
					       }
					       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					       _res1__155___r5_control_features_6_4 = (obj_t) (val1_1501_1350);
					       return stack_3;
					    }
					 }
				       else
					 {
					    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					    _res1__155___r5_control_features_6_4 = (obj_t) (node_1340);
					    return BFALSE;
					 }
				    }
				 }
			    }
			 }
		      }
		      break;
		   case ((long) 20):
		      {
			 let_var_6_t node_1357;
			 node_1357 = (let_var_6_t) (node_2);
			 {
			    obj_t bindings_1360;
			    bool_t reset_1361;
			    obj_t extend_1362;
			    bindings_1360 = (((let_var_6_t) CREF(node_1357))->bindings);
			    reset_1361 = ((bool_t) 0);
			    extend_1362 = BNIL;
			  loop_1363:
			    if (NULLP(bindings_1360))
			      {
				 obj_t stack__1_1367;
				 if (reset_1361)
				   {
				      stack__1_1367 = BNIL;
				   }
				 else
				   {
				      stack__1_1367 = append_2_18___r4_pairs_and_lists_6_3(extend_1362, stack_3);
				   }
				 {
				    obj_t reset__69_1368;
				    reset__69_1368 = node_cse__231_reduce_cse((((let_var_6_t) CREF(node_1357))->body), stack__1_1367);
				    {
				       obj_t nbody_1369;
				       nbody_1369 = _res1__155___r5_control_features_6_4;
				       {
					  node_t val1378_1588;
					  val1378_1588 = (node_t) (nbody_1369);
					  ((((let_var_6_t) CREF(node_1357))->body) = ((node_t) val1378_1588), BUNSPEC);
				       }
				       {
					  bool_t test_2041;
					  if (reset_1361)
					    {
					       test_2041 = ((bool_t) 1);
					    }
					  else
					    {
					       test_2041 = CBOOL(reset__69_1368);
					    }
					  if (test_2041)
					    {
					       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
					       _res1__155___r5_control_features_6_4 = (obj_t) (node_1357);
					       return BTRUE;
					    }
					  else
					    {
					       bool_t test1768_1373;
					       test1768_1373 = side_effect__165_effect_effect((node_t) (node_1357));
					       if (test1768_1373)
						 {
						    _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
						    _res1__155___r5_control_features_6_4 = (obj_t) (node_1357);
						    return BFALSE;
						 }
					       else
						 {
						    {
						       obj_t previous_1376;
						       previous_1376 = find_stack_136_reduce_cse((node_t) (node_1357), stack_3);
						       {
							  bool_t test1769_1377;
							  test1769_1377 = is_a__118___object(previous_1376, variable_ast_var);
							  if (test1769_1377)
							    {
							       {
								  long z2_1591;
								  z2_1591 = _cse_removed__19_reduce_cse;
								  _cse_removed__19_reduce_cse = (((long) 1) + z2_1591);
							       }
							       {
								  var_t val1_1511_1379;
								  {
								     obj_t arg1770_1380;
								     type_t arg1771_1381;
								     arg1770_1380 = (((let_var_6_t) CREF(node_1357))->loc);
								     arg1771_1381 = (((let_var_6_t) CREF(node_1357))->type);
								     {
									var_t res1798_1604;
									{
									   variable_t variable_1596;
									   variable_1596 = (variable_t) (previous_1376);
									   {
									      var_t new1206_1597;
									      new1206_1597 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
									      {
										 long arg1657_1598;
										 arg1657_1598 = class_num_218___object(var_ast_node);
										 {
										    obj_t obj_1602;
										    obj_1602 = (obj_t) (new1206_1597);
										    (((obj_t) CREF(obj_1602))->header = MAKE_HEADER(arg1657_1598, 0), BUNSPEC);
										 }
									      }
									      {
										 object_t aux_2063;
										 aux_2063 = (object_t) (new1206_1597);
										 OBJECT_WIDENING_SET(aux_2063, BFALSE);
									      }
									      ((((var_t) CREF(new1206_1597))->loc) = ((obj_t) arg1770_1380), BUNSPEC);
									      ((((var_t) CREF(new1206_1597))->type) = ((type_t) arg1771_1381), BUNSPEC);
									      ((((var_t) CREF(new1206_1597))->variable) = ((variable_t) variable_1596), BUNSPEC);
									      res1798_1604 = new1206_1597;
									   }
									}
									val1_1511_1379 = res1798_1604;
								     }
								  }
								  _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
								  _res1__155___r5_control_features_6_4 = (obj_t) (val1_1511_1379);
								  return stack__1_1367;
							       }
							    }
							  else
							    {
							       _res_number__75___r5_control_features_6_4 = BINT(((long) 2));
							       _res1__155___r5_control_features_6_4 = (obj_t) (node_1357);
							       return BFALSE;
							    }
						       }
						    }
						 }
					    }
				       }
				    }
				 }
			      }
			    else
			      {
				 obj_t binding_1386;
				 binding_1386 = CAR(bindings_1360);
				 {
				    obj_t var_1387;
				    obj_t val_1388;
				    var_1387 = CAR(binding_1386);
				    val_1388 = CDR(binding_1386);
				    {
				       obj_t reset__69_1389;
				       reset__69_1389 = node_cse__231_reduce_cse((node_t) (val_1388), stack_3);
				       {
					  obj_t nval_1390;
					  nval_1390 = _res1__155___r5_control_features_6_4;
					  SET_CDR(binding_1386, nval_1390);
					  {
					     bool_t test_2079;
					     if (reset_1361)
					       {
						  test_2079 = ((bool_t) 1);
					       }
					     else
					       {
						  test_2079 = CBOOL(reset__69_1389);
					       }
					     if (test_2079)
					       {
						  {
						     obj_t extend_2084;
						     obj_t bindings_2082;
						     bindings_2082 = CDR(bindings_1360);
						     extend_2084 = BNIL;
						     extend_1362 = extend_2084;
						     bindings_1360 = bindings_2082;
						     goto loop_1363;
						  }
					       }
					     else
					       {
						  bool_t test_2085;
						  {
						     obj_t aux_2089;
						     obj_t aux_2086;
						     aux_2089 = CNST_TABLE_REF(((long) 0));
						     {
							local_t obj_1611;
							obj_1611 = (local_t) (var_1387);
							aux_2086 = (((local_t) CREF(obj_1611))->access);
						     }
						     test_2085 = (aux_2086 == aux_2089);
						  }
						  if (test_2085)
						    {
						       bool_t test1779_1395;
						       {
							  bool_t test1787_1400;
							  test1787_1400 = is_a__118___object(val_1388, app_ast_node);
							  if (test1787_1400)
							    {
							       test1779_1395 = ((bool_t) 1);
							    }
							  else
							    {
							       test1779_1395 = is_a__118___object(val_1388, let_var_6_ast_node);
							    }
						       }
						       if (test1779_1395)
							 {
							    {
							       obj_t arg1780_1396;
							       obj_t arg1781_1397;
							       arg1780_1396 = CDR(bindings_1360);
							       {
								  obj_t arg1783_1398;
								  {
								     obj_t new_1619;
								     {
									obj_t aux_2097;
									aux_2097 = CNST_TABLE_REF(((long) 1));
									new_1619 = create_struct(aux_2097, ((long) 2));
								     }
								     STRUCT_SET(new_1619, ((long) 1), var_1387);
								     STRUCT_SET(new_1619, ((long) 0), val_1388);
								     arg1783_1398 = new_1619;
								  }
								  arg1781_1397 = MAKE_PAIR(arg1783_1398, extend_1362);
							       }
							       {
								  obj_t extend_2105;
								  bool_t reset_2104;
								  obj_t bindings_2103;
								  bindings_2103 = arg1780_1396;
								  reset_2104 = ((bool_t) 0);
								  extend_2105 = arg1781_1397;
								  extend_1362 = extend_2105;
								  reset_1361 = reset_2104;
								  bindings_1360 = bindings_2103;
								  goto loop_1363;
							       }
							    }
							 }
						       else
							 {
							    {
							       bool_t reset_2108;
							       obj_t bindings_2106;
							       bindings_2106 = CDR(bindings_1360);
							       reset_2108 = ((bool_t) 0);
							       reset_1361 = reset_2108;
							       bindings_1360 = bindings_2106;
							       goto loop_1363;
							    }
							 }
						    }
						  else
						    {
						       {
							  bool_t reset_2111;
							  obj_t bindings_2109;
							  bindings_2109 = CDR(bindings_1360);
							  reset_2111 = ((bool_t) 0);
							  reset_1361 = reset_2111;
							  bindings_1360 = bindings_2109;
							  goto loop_1363;
						       }
						    }
					       }
					  }
				       }
				    }
				 }
			      }
			 }
		      }
		      break;
		   default:
		    case_else1705_1152:
		      if (PROCEDUREP(method1699_1148))
			{
			   return PROCEDURE_ENTRY(method1699_1148) (method1699_1148, (obj_t) (node_2), stack_3, BEOA);
			}
		      else
			{
			   obj_t fun1695_1142;
			   fun1695_1142 = PROCEDURE_REF(node_cse__env_198_reduce_cse, ((long) 0));
			   return PROCEDURE_ENTRY(fun1695_1142) (fun1695_1142, (obj_t) (node_2), stack_3, BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1705_1152;
	      }
	 }
      }
   }
}


/* _node-cse!1800 */ obj_t 
_node_cse_1800_180_reduce_cse(obj_t env_1645, obj_t node_1646, obj_t stack_1647)
{
   return node_cse__231_reduce_cse((node_t) (node_1646), stack_1647);
}


/* node-cse!-default1517 */ obj_t 
node_cse__default1517_194_reduce_cse(node_t node_4, obj_t stack_5)
{
   FAILURE(CNST_TABLE_REF(((long) 2)), string1803_reduce_cse, (obj_t) (node_4));
}


/* _node-cse!-default1517 */ obj_t 
_node_cse__default1517_95_reduce_cse(obj_t env_1648, obj_t node_1649, obj_t stack_1650)
{
   return node_cse__default1517_194_reduce_cse((node_t) (node_1649), stack_1650);
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_reduce_cse()
{
   module_initialization_70_tools_trace(((long) 0), "REDUCE_CSE");
   module_initialization_70_tools_shape(((long) 0), "REDUCE_CSE");
   module_initialization_70_tools_speek(((long) 0), "REDUCE_CSE");
   module_initialization_70_tools_error(((long) 0), "REDUCE_CSE");
   module_initialization_70_type_type(((long) 0), "REDUCE_CSE");
   module_initialization_70_type_cache(((long) 0), "REDUCE_CSE");
   module_initialization_70_coerce_typeof(((long) 0), "REDUCE_CSE");
   module_initialization_70_coerce_coerce(((long) 0), "REDUCE_CSE");
   module_initialization_70_effect_effect(((long) 0), "REDUCE_CSE");
   module_initialization_70_ast_var(((long) 0), "REDUCE_CSE");
   module_initialization_70_ast_node(((long) 0), "REDUCE_CSE");
   module_initialization_70_ast_lvtype(((long) 0), "REDUCE_CSE");
   return module_initialization_70_reduce_same(((long) 0), "REDUCE_CSE");
}
