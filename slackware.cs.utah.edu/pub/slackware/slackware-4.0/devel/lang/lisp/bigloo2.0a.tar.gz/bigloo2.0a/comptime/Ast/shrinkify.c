/*===========================================================================*/
/*   (Ast/shrinkify.scm)                                                     */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;


static obj_t method_init_76_ast_shrinkify();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static bool_t shrink_node___235_ast_shrinkify(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t _shrink_node__default1463_68_ast_shrinkify(obj_t, obj_t);
extern obj_t box_ref_242_ast_node;
static obj_t shrink_node__211_ast_shrinkify(node_t);
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t shrinkify__187_ast_shrinkify(obj_t);
static obj_t shrink_node__default1463_65_ast_shrinkify(node_t);
extern obj_t module_initialization_70_ast_shrinkify(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t shrink_variable__88_ast_shrinkify(variable_t);
extern long class_num_218___object(obj_t);
static obj_t _shrink_variable_1736_81_ast_shrinkify(obj_t, obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_ast_shrinkify();
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern obj_t app_ast_node;
static obj_t shrink_variable__default1462_238_ast_shrinkify(variable_t);
static obj_t library_modules_init_112_ast_shrinkify();
static obj_t _shrinkify__38_ast_shrinkify(obj_t, obj_t);
extern obj_t atom_ast_node;
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_ast_shrinkify();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t _shrink_node_1737_186_ast_shrinkify(obj_t, obj_t);
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
static obj_t _shrink_variable__default1462_217_ast_shrinkify(obj_t, obj_t);
extern obj_t for_each_global__88_ast_env(obj_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
static obj_t require_initialization_114_ast_shrinkify = BUNSPEC;
extern obj_t conditional_ast_node;
extern obj_t class_super_145___object(obj_t);
static obj_t cnst_init_137_ast_shrinkify();
static obj_t __cnst[1];

DEFINE_STATIC_GENERIC(shrink_variable__env_168_ast_shrinkify, _shrink_variable_1736_81_ast_shrinkify1747, _shrink_variable_1736_81_ast_shrinkify, 0L, 1);
DEFINE_STATIC_GENERIC(shrink_node__env_219_ast_shrinkify, _shrink_node_1737_186_ast_shrinkify1748, _shrink_node_1737_186_ast_shrinkify, 0L, 1);
DEFINE_STATIC_PROCEDURE(shrink_node__default1463_env_32_ast_shrinkify, _shrink_node__default1463_68_ast_shrinkify1749, _shrink_node__default1463_68_ast_shrinkify, 0L, 1);
DEFINE_STATIC_PROCEDURE(shrink_variable__default1462_env_75_ast_shrinkify, _shrink_variable__default1462_217_ast_shrinkify1750, _shrink_variable__default1462_217_ast_shrinkify, 0L, 1);
DEFINE_STRING(string1739_ast_shrinkify, string1739_ast_shrinkify1751, "SHRINK-NODE!-DEFAULT1463 ", 25);
DEFINE_STRING(string1738_ast_shrinkify, string1738_ast_shrinkify1752, "No method for this object", 25);
DEFINE_EXPORT_PROCEDURE(shrinkify__env_151_ast_shrinkify, _shrinkify__38_ast_shrinkify1753, _shrinkify__38_ast_shrinkify, 0L, 1);


/* module-initialization */ obj_t 
module_initialization_70_ast_shrinkify(long checksum_1496, char *from_1497)
{
   if (CBOOL(require_initialization_114_ast_shrinkify))
     {
	require_initialization_114_ast_shrinkify = BBOOL(((bool_t) 0));
	library_modules_init_112_ast_shrinkify();
	cnst_init_137_ast_shrinkify();
	imported_modules_init_94_ast_shrinkify();
	method_init_76_ast_shrinkify();
	toplevel_init_63_ast_shrinkify();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_ast_shrinkify()
{
   module_initialization_70___object(((long) 0), "AST_SHRINKIFY");
   module_initialization_70___reader(((long) 0), "AST_SHRINKIFY");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_ast_shrinkify()
{
   {
      obj_t cnst_port_138_1488;
      cnst_port_138_1488 = open_input_string(string1739_ast_shrinkify);
      {
	 long i_1489;
	 i_1489 = ((long) 0);
       loop_1490:
	 {
	    bool_t test1740_1491;
	    test1740_1491 = (i_1489 == ((long) -1));
	    if (test1740_1491)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1743_1492;
		    {
		       obj_t list1744_1493;
		       {
			  obj_t arg1745_1494;
			  arg1745_1494 = BNIL;
			  list1744_1493 = MAKE_PAIR(cnst_port_138_1488, arg1745_1494);
		       }
		       arg1743_1492 = read___reader(list1744_1493);
		    }
		    CNST_TABLE_SET(i_1489, arg1743_1492);
		 }
		 {
		    int aux_1495;
		    {
		       long aux_1514;
		       aux_1514 = (i_1489 - ((long) 1));
		       aux_1495 = (int) (aux_1514);
		    }
		    {
		       long i_1517;
		       i_1517 = (long) (aux_1495);
		       i_1489 = i_1517;
		       goto loop_1490;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_ast_shrinkify()
{
   return BUNSPEC;
}


/* shrinkify! */ obj_t 
shrinkify__187_ast_shrinkify(obj_t globals_1)
{
   for_each_global__88_ast_env(shrink_variable__env_168_ast_shrinkify);
   {
      obj_t l1435_718;
      l1435_718 = globals_1;
    lname1436_719:
      if (PAIRP(l1435_718))
	{
	   {
	      obj_t global_721;
	      global_721 = CAR(l1435_718);
	      {
		 obj_t l1437_723;
		 {
		    sfun_t obj_1230;
		    {
		       value_t aux_1532;
		       {
			  global_t obj_1229;
			  obj_1229 = (global_t) (global_721);
			  aux_1532 = (((global_t) CREF(obj_1229))->value);
		       }
		       obj_1230 = (sfun_t) (aux_1532);
		    }
		    l1437_723 = (((sfun_t) CREF(obj_1230))->args);
		 }
	       lname1438_724:
		 if (PAIRP(l1437_723))
		   {
		      {
			 variable_t aux_1525;
			 {
			    obj_t aux_1526;
			    aux_1526 = CAR(l1437_723);
			    aux_1525 = (variable_t) (aux_1526);
			 }
			 shrink_variable__88_ast_shrinkify(aux_1525);
		      }
		      {
			 obj_t l1437_1530;
			 l1437_1530 = CDR(l1437_723);
			 l1437_723 = l1437_1530;
			 goto lname1438_724;
		      }
		   }
		 else
		   {
		      ((bool_t) 1);
		   }
	      }
	      {
		 node_t aux_1537;
		 {
		    obj_t aux_1538;
		    {
		       sfun_t obj_1235;
		       {
			  value_t aux_1539;
			  {
			     global_t obj_1234;
			     obj_1234 = (global_t) (global_721);
			     aux_1539 = (((global_t) CREF(obj_1234))->value);
			  }
			  obj_1235 = (sfun_t) (aux_1539);
		       }
		       aux_1538 = (((sfun_t) CREF(obj_1235))->body);
		    }
		    aux_1537 = (node_t) (aux_1538);
		 }
		 shrink_node__211_ast_shrinkify(aux_1537);
	      }
	   }
	   {
	      obj_t l1435_1546;
	      l1435_1546 = CDR(l1435_718);
	      l1435_718 = l1435_1546;
	      goto lname1436_719;
	   }
	}
      else
	{
	   ((bool_t) 1);
	}
   }
   return globals_1;
}


/* _shrinkify! */ obj_t 
_shrinkify__38_ast_shrinkify(obj_t env_1477, obj_t globals_1478)
{
   return shrinkify__187_ast_shrinkify(globals_1478);
}


/* shrink-node*! */ bool_t 
shrink_node___235_ast_shrinkify(obj_t node__221_26)
{
   {
      obj_t l1459_732;
      l1459_732 = node__221_26;
    lname1460_733:
      if (PAIRP(l1459_732))
	{
	   {
	      node_t aux_1551;
	      {
		 obj_t aux_1552;
		 aux_1552 = CAR(l1459_732);
		 aux_1551 = (node_t) (aux_1552);
	      }
	      shrink_node__211_ast_shrinkify(aux_1551);
	   }
	   {
	      obj_t l1459_1556;
	      l1459_1556 = CDR(l1459_732);
	      l1459_732 = l1459_1556;
	      goto lname1460_733;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* method-init */ obj_t 
method_init_76_ast_shrinkify()
{
   add_generic__110___object(shrink_variable__env_168_ast_shrinkify, shrink_variable__default1462_env_75_ast_shrinkify);
   add_generic__110___object(shrink_node__env_219_ast_shrinkify, shrink_node__default1463_env_32_ast_shrinkify);
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, var_ast_node, ((long) 1));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, kwote_ast_node, ((long) 2));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, sequence_ast_node, ((long) 3));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, app_ast_node, ((long) 4));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, select_ast_node, ((long) 12));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, make_box_202_ast_node, ((long) 13));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, box_ref_242_ast_node, ((long) 14));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, box_set__221_ast_node, ((long) 15));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, let_fun_218_ast_node, ((long) 16));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, let_var_6_ast_node, ((long) 17));
   add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, set_ex_it_116_ast_node, ((long) 18));
   {
      long aux_1579;
      aux_1579 = add_inlined_method__244___object(shrink_node__env_219_ast_shrinkify, jump_ex_it_184_ast_node, ((long) 19));
      return BINT(aux_1579);
   }
}


/* shrink-variable! */ obj_t 
shrink_variable__88_ast_shrinkify(variable_t variable_2)
{
   {
      obj_t method1711_1213;
      obj_t class1716_1214;
      {
	 obj_t arg1717_1211;
	 obj_t arg1718_1212;
	 {
	    object_t obj_1240;
	    obj_1240 = (object_t) (variable_2);
	    {
	       obj_t pre_method_105_1241;
	       pre_method_105_1241 = PROCEDURE_REF(shrink_variable__env_168_ast_shrinkify, ((long) 2));
	       if (INTEGERP(pre_method_105_1241))
		 {
		    PROCEDURE_SET(shrink_variable__env_168_ast_shrinkify, ((long) 2), BUNSPEC);
		    arg1717_1211 = pre_method_105_1241;
		 }
	       else
		 {
		    long obj_class_num_177_1246;
		    obj_class_num_177_1246 = TYPE(obj_1240);
		    {
		       obj_t arg1177_1247;
		       arg1177_1247 = PROCEDURE_REF(shrink_variable__env_168_ast_shrinkify, ((long) 1));
		       {
			  long arg1178_1251;
			  {
			     long arg1179_1252;
			     arg1179_1252 = OBJECT_TYPE;
			     arg1178_1251 = (obj_class_num_177_1246 - arg1179_1252);
			  }
			  arg1717_1211 = VECTOR_REF(arg1177_1247, arg1178_1251);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1257;
	    object_1257 = (object_t) (variable_2);
	    {
	       long arg1180_1258;
	       {
		  long arg1181_1259;
		  long arg1182_1260;
		  arg1181_1259 = TYPE(object_1257);
		  arg1182_1260 = OBJECT_TYPE;
		  arg1180_1258 = (arg1181_1259 - arg1182_1260);
	       }
	       {
		  obj_t vector_1264;
		  vector_1264 = _classes__134___object;
		  arg1718_1212 = VECTOR_REF(vector_1264, arg1180_1258);
	       }
	    }
	 }
	 method1711_1213 = arg1717_1211;
	 class1716_1214 = arg1718_1212;
	 if (PROCEDUREP(method1711_1213))
	   {
	      return PROCEDURE_ENTRY(method1711_1213) (method1711_1213, (obj_t) (variable_2), BEOA);
	   }
	 else
	   {
	      obj_t fun1590_1062;
	      fun1590_1062 = PROCEDURE_REF(shrink_variable__env_168_ast_shrinkify, ((long) 0));
	      return PROCEDURE_ENTRY(fun1590_1062) (fun1590_1062, (obj_t) (variable_2), BEOA);
	   }
      }
   }
}


/* _shrink-variable!1736 */ obj_t 
_shrink_variable_1736_81_ast_shrinkify(obj_t env_1479, obj_t variable_1480)
{
   return shrink_variable__88_ast_shrinkify((variable_t) (variable_1480));
}


/* shrink-variable!-default1462 */ obj_t 
shrink_variable__default1462_238_ast_shrinkify(variable_t variable_3)
{
   {
      bool_t test_1608;
      {
	 bool_t test_1609;
	 {
	    obj_t aux_1610;
	    {
	       object_t aux_1611;
	       aux_1611 = (object_t) (variable_3);
	       aux_1610 = OBJECT_WIDENING(aux_1611);
	    }
	    test_1609 = CBOOL(aux_1610);
	 }
	 if (test_1609)
	   {
	      test_1608 = ((bool_t) 1);
	   }
	 else
	   {
	      test_1608 = ((bool_t) 0);
	   }
      }
      if (test_1608)
	{
	   {
	      long arg1592_1065;
	      {
		 obj_t arg1593_1066;
		 {
		    obj_t arg1594_1067;
		    {
		       object_t object_1271;
		       object_1271 = (object_t) (variable_3);
		       {
			  long arg1180_1272;
			  {
			     long arg1181_1273;
			     long arg1182_1274;
			     arg1181_1273 = TYPE(object_1271);
			     arg1182_1274 = OBJECT_TYPE;
			     arg1180_1272 = (arg1181_1273 - arg1182_1274);
			  }
			  {
			     obj_t vector_1278;
			     vector_1278 = _classes__134___object;
			     arg1594_1067 = VECTOR_REF(vector_1278, arg1180_1272);
			  }
		       }
		    }
		    arg1593_1066 = class_super_145___object(arg1594_1067);
		 }
		 arg1592_1065 = class_num_218___object(arg1593_1066);
	      }
	      {
		 obj_t obj_1280;
		 obj_1280 = (obj_t) (variable_3);
		 (((obj_t) CREF(obj_1280))->header = MAKE_HEADER(arg1592_1065, 0), BUNSPEC);
	      }
	   }
	   {
	      object_t aux_1624;
	      aux_1624 = (object_t) (variable_3);
	      OBJECT_WIDENING_SET(aux_1624, BFALSE);
	   }
	   (obj_t) (variable_3);
	}
      else
	{
	   BUNSPEC;
	}
   }
   {
      bool_t test_1628;
      {
	 bool_t test_1629;
	 {
	    obj_t aux_1630;
	    {
	       object_t aux_1631;
	       {
		  value_t aux_1632;
		  aux_1632 = (((variable_t) CREF(variable_3))->value);
		  aux_1631 = (object_t) (aux_1632);
	       }
	       aux_1630 = OBJECT_WIDENING(aux_1631);
	    }
	    test_1629 = CBOOL(aux_1630);
	 }
	 if (test_1629)
	   {
	      test_1628 = ((bool_t) 1);
	   }
	 else
	   {
	      test_1628 = ((bool_t) 0);
	   }
      }
      if (test_1628)
	{
	   value_t o1440_1069;
	   o1440_1069 = (((variable_t) CREF(variable_3))->value);
	   {
	      long arg1598_1070;
	      {
		 obj_t arg1600_1071;
		 {
		    obj_t arg1602_1072;
		    {
		       object_t object_1287;
		       object_1287 = (object_t) (o1440_1069);
		       {
			  long arg1180_1288;
			  {
			     long arg1181_1289;
			     long arg1182_1290;
			     arg1181_1289 = TYPE(object_1287);
			     arg1182_1290 = OBJECT_TYPE;
			     arg1180_1288 = (arg1181_1289 - arg1182_1290);
			  }
			  {
			     obj_t vector_1294;
			     vector_1294 = _classes__134___object;
			     arg1602_1072 = VECTOR_REF(vector_1294, arg1180_1288);
			  }
		       }
		    }
		    arg1600_1071 = class_super_145___object(arg1602_1072);
		 }
		 arg1598_1070 = class_num_218___object(arg1600_1071);
	      }
	      {
		 obj_t obj_1296;
		 obj_1296 = (obj_t) (o1440_1069);
		 (((obj_t) CREF(obj_1296))->header = MAKE_HEADER(arg1598_1070, 0), BUNSPEC);
	      }
	   }
	   {
	      object_t aux_1647;
	      aux_1647 = (object_t) (o1440_1069);
	      OBJECT_WIDENING_SET(aux_1647, BFALSE);
	   }
	   return (obj_t) (o1440_1069);
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* _shrink-variable!-default1462 */ obj_t 
_shrink_variable__default1462_217_ast_shrinkify(obj_t env_1481, obj_t variable_1482)
{
   return shrink_variable__default1462_238_ast_shrinkify((variable_t) (variable_1482));
}


/* shrink-node! */ obj_t 
shrink_node__211_ast_shrinkify(node_t node_4)
{
   {
      obj_t method1607_1080;
      obj_t class1612_1081;
      {
	 obj_t arg1615_1078;
	 obj_t arg1617_1079;
	 {
	    object_t obj_1298;
	    obj_1298 = (object_t) (node_4);
	    {
	       obj_t pre_method_105_1299;
	       pre_method_105_1299 = PROCEDURE_REF(shrink_node__env_219_ast_shrinkify, ((long) 2));
	       if (INTEGERP(pre_method_105_1299))
		 {
		    PROCEDURE_SET(shrink_node__env_219_ast_shrinkify, ((long) 2), BUNSPEC);
		    arg1615_1078 = pre_method_105_1299;
		 }
	       else
		 {
		    long obj_class_num_177_1304;
		    obj_class_num_177_1304 = TYPE(obj_1298);
		    {
		       obj_t arg1177_1305;
		       arg1177_1305 = PROCEDURE_REF(shrink_node__env_219_ast_shrinkify, ((long) 1));
		       {
			  long arg1178_1309;
			  {
			     long arg1179_1310;
			     arg1179_1310 = OBJECT_TYPE;
			     arg1178_1309 = (obj_class_num_177_1304 - arg1179_1310);
			  }
			  arg1615_1078 = VECTOR_REF(arg1177_1305, arg1178_1309);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1315;
	    object_1315 = (object_t) (node_4);
	    {
	       long arg1180_1316;
	       {
		  long arg1181_1317;
		  long arg1182_1318;
		  arg1181_1317 = TYPE(object_1315);
		  arg1182_1318 = OBJECT_TYPE;
		  arg1180_1316 = (arg1181_1317 - arg1182_1318);
	       }
	       {
		  obj_t vector_1322;
		  vector_1322 = _classes__134___object;
		  arg1617_1079 = VECTOR_REF(vector_1322, arg1180_1316);
	       }
	    }
	 }
	 {
	    obj_t x_1487;
	    method1607_1080 = arg1615_1078;
	    class1612_1081 = arg1617_1079;
	    {
	       if (INTEGERP(method1607_1080))
		 {
		    switch ((long) CINT(method1607_1080))
		      {
		      case ((long) 0):
			 x_1487 = BUNSPEC;
			 break;
		      case ((long) 1):
			 x_1487 = BUNSPEC;
			 break;
		      case ((long) 2):
			 x_1487 = BUNSPEC;
			 break;
		      case ((long) 3):
			 {
			    sequence_t node_1090;
			    node_1090 = (sequence_t) (node_4);
			    shrink_node___235_ast_shrinkify((((sequence_t) CREF(node_1090))->nodes));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 4):
			 {
			    app_t node_1092;
			    node_1092 = (app_t) (node_4);
			    {
			       bool_t test_1674;
			       {
				  bool_t test_1675;
				  {
				     obj_t aux_1676;
				     {
					object_t aux_1677;
					aux_1677 = (object_t) (node_1092);
					aux_1676 = OBJECT_WIDENING(aux_1677);
				     }
				     test_1675 = CBOOL(aux_1676);
				  }
				  if (test_1675)
				    {
				       test_1674 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1674 = ((bool_t) 0);
				    }
			       }
			       if (test_1674)
				 {
				    {
				       long arg1622_1095;
				       {
					  obj_t arg1623_1096;
					  {
					     obj_t arg1624_1097;
					     {
						object_t object_1328;
						object_1328 = (object_t) (node_1092);
						{
						   long arg1180_1329;
						   {
						      long arg1181_1330;
						      long arg1182_1331;
						      arg1181_1330 = TYPE(object_1328);
						      arg1182_1331 = OBJECT_TYPE;
						      arg1180_1329 = (arg1181_1330 - arg1182_1331);
						   }
						   {
						      obj_t vector_1335;
						      vector_1335 = _classes__134___object;
						      arg1624_1097 = VECTOR_REF(vector_1335, arg1180_1329);
						   }
						}
					     }
					     arg1623_1096 = class_super_145___object(arg1624_1097);
					  }
					  arg1622_1095 = class_num_218___object(arg1623_1096);
				       }
				       {
					  obj_t obj_1337;
					  obj_1337 = (obj_t) (node_1092);
					  (((obj_t) CREF(obj_1337))->header = MAKE_HEADER(arg1622_1095, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1690;
				       aux_1690 = (object_t) (node_1092);
				       OBJECT_WIDENING_SET(aux_1690, BFALSE);
				    }
				    (obj_t) (node_1092);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       node_t aux_1694;
			       {
				  var_t aux_1695;
				  aux_1695 = (((app_t) CREF(node_1092))->fun);
				  aux_1694 = (node_t) (aux_1695);
			       }
			       shrink_node__211_ast_shrinkify(aux_1694);
			    }
			    shrink_node___235_ast_shrinkify((((app_t) CREF(node_1092))->args));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 5):
			 {
			    app_ly_162_t node_1100;
			    node_1100 = (app_ly_162_t) (node_4);
			    {
			       bool_t test_1702;
			       {
				  bool_t test_1703;
				  {
				     obj_t aux_1704;
				     {
					object_t aux_1705;
					aux_1705 = (object_t) (node_1100);
					aux_1704 = OBJECT_WIDENING(aux_1705);
				     }
				     test_1703 = CBOOL(aux_1704);
				  }
				  if (test_1703)
				    {
				       test_1702 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1702 = ((bool_t) 0);
				    }
			       }
			       if (test_1702)
				 {
				    {
				       long arg1630_1103;
				       {
					  obj_t arg1632_1104;
					  {
					     obj_t arg1633_1105;
					     {
						object_t object_1344;
						object_1344 = (object_t) (node_1100);
						{
						   long arg1180_1345;
						   {
						      long arg1181_1346;
						      long arg1182_1347;
						      arg1181_1346 = TYPE(object_1344);
						      arg1182_1347 = OBJECT_TYPE;
						      arg1180_1345 = (arg1181_1346 - arg1182_1347);
						   }
						   {
						      obj_t vector_1351;
						      vector_1351 = _classes__134___object;
						      arg1633_1105 = VECTOR_REF(vector_1351, arg1180_1345);
						   }
						}
					     }
					     arg1632_1104 = class_super_145___object(arg1633_1105);
					  }
					  arg1630_1103 = class_num_218___object(arg1632_1104);
				       }
				       {
					  obj_t obj_1353;
					  obj_1353 = (obj_t) (node_1100);
					  (((obj_t) CREF(obj_1353))->header = MAKE_HEADER(arg1630_1103, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1718;
				       aux_1718 = (object_t) (node_1100);
				       OBJECT_WIDENING_SET(aux_1718, BFALSE);
				    }
				    (obj_t) (node_1100);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    shrink_node__211_ast_shrinkify((((app_ly_162_t) CREF(node_1100))->fun));
			    shrink_node__211_ast_shrinkify((((app_ly_162_t) CREF(node_1100))->arg));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 6):
			 {
			    funcall_t node_1108;
			    node_1108 = (funcall_t) (node_4);
			    {
			       bool_t test_1727;
			       {
				  bool_t test_1728;
				  {
				     obj_t aux_1729;
				     {
					object_t aux_1730;
					aux_1730 = (object_t) (node_1108);
					aux_1729 = OBJECT_WIDENING(aux_1730);
				     }
				     test_1728 = CBOOL(aux_1729);
				  }
				  if (test_1728)
				    {
				       test_1727 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1727 = ((bool_t) 0);
				    }
			       }
			       if (test_1727)
				 {
				    {
				       long arg1638_1111;
				       {
					  obj_t arg1639_1112;
					  {
					     obj_t arg1640_1113;
					     {
						object_t object_1360;
						object_1360 = (object_t) (node_1108);
						{
						   long arg1180_1361;
						   {
						      long arg1181_1362;
						      long arg1182_1363;
						      arg1181_1362 = TYPE(object_1360);
						      arg1182_1363 = OBJECT_TYPE;
						      arg1180_1361 = (arg1181_1362 - arg1182_1363);
						   }
						   {
						      obj_t vector_1367;
						      vector_1367 = _classes__134___object;
						      arg1640_1113 = VECTOR_REF(vector_1367, arg1180_1361);
						   }
						}
					     }
					     arg1639_1112 = class_super_145___object(arg1640_1113);
					  }
					  arg1638_1111 = class_num_218___object(arg1639_1112);
				       }
				       {
					  obj_t obj_1369;
					  obj_1369 = (obj_t) (node_1108);
					  (((obj_t) CREF(obj_1369))->header = MAKE_HEADER(arg1638_1111, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1743;
				       aux_1743 = (object_t) (node_1108);
				       OBJECT_WIDENING_SET(aux_1743, BFALSE);
				    }
				    (obj_t) (node_1108);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    shrink_node__211_ast_shrinkify((((funcall_t) CREF(node_1108))->fun));
			    shrink_node___235_ast_shrinkify((((funcall_t) CREF(node_1108))->args));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 7):
			 {
			    pragma_t node_1116;
			    node_1116 = (pragma_t) (node_4);
			    {
			       bool_t test_1752;
			       {
				  bool_t test_1753;
				  {
				     obj_t aux_1754;
				     {
					object_t aux_1755;
					aux_1755 = (object_t) (node_1116);
					aux_1754 = OBJECT_WIDENING(aux_1755);
				     }
				     test_1753 = CBOOL(aux_1754);
				  }
				  if (test_1753)
				    {
				       test_1752 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1752 = ((bool_t) 0);
				    }
			       }
			       if (test_1752)
				 {
				    {
				       long arg1647_1119;
				       {
					  obj_t arg1648_1120;
					  {
					     obj_t arg1649_1121;
					     {
						object_t object_1376;
						object_1376 = (object_t) (node_1116);
						{
						   long arg1180_1377;
						   {
						      long arg1181_1378;
						      long arg1182_1379;
						      arg1181_1378 = TYPE(object_1376);
						      arg1182_1379 = OBJECT_TYPE;
						      arg1180_1377 = (arg1181_1378 - arg1182_1379);
						   }
						   {
						      obj_t vector_1383;
						      vector_1383 = _classes__134___object;
						      arg1649_1121 = VECTOR_REF(vector_1383, arg1180_1377);
						   }
						}
					     }
					     arg1648_1120 = class_super_145___object(arg1649_1121);
					  }
					  arg1647_1119 = class_num_218___object(arg1648_1120);
				       }
				       {
					  obj_t obj_1385;
					  obj_1385 = (obj_t) (node_1116);
					  (((obj_t) CREF(obj_1385))->header = MAKE_HEADER(arg1647_1119, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1768;
				       aux_1768 = (object_t) (node_1116);
				       OBJECT_WIDENING_SET(aux_1768, BFALSE);
				    }
				    (obj_t) (node_1116);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    shrink_node___235_ast_shrinkify((((pragma_t) CREF(node_1116))->args));
			    x_1487 = (obj_t) (node_1116);
			 }
			 break;
		      case ((long) 8):
			 {
			    cast_t node_1123;
			    node_1123 = (cast_t) (node_4);
			    shrink_node__211_ast_shrinkify((((cast_t) CREF(node_1123))->arg));
			    x_1487 = (obj_t) (node_1123);
			 }
			 break;
		      case ((long) 9):
			 {
			    setq_t node_1125;
			    node_1125 = (setq_t) (node_4);
			    shrink_node__211_ast_shrinkify((((setq_t) CREF(node_1125))->value));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 10):
			 {
			    conditional_t node_1127;
			    node_1127 = (conditional_t) (node_4);
			    shrink_node__211_ast_shrinkify((((conditional_t) CREF(node_1127))->test));
			    shrink_node__211_ast_shrinkify((((conditional_t) CREF(node_1127))->true));
			    shrink_node__211_ast_shrinkify((((conditional_t) CREF(node_1127))->false));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 11):
			 {
			    fail_t node_1131;
			    node_1131 = (fail_t) (node_4);
			    shrink_node__211_ast_shrinkify((((fail_t) CREF(node_1131))->proc));
			    shrink_node__211_ast_shrinkify((((fail_t) CREF(node_1131))->msg));
			    shrink_node__211_ast_shrinkify((((fail_t) CREF(node_1131))->obj));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 12):
			 {
			    select_t node_1135;
			    node_1135 = (select_t) (node_4);
			    shrink_node__211_ast_shrinkify((((select_t) CREF(node_1135))->test));
			    {
			       obj_t l1445_1137;
			       l1445_1137 = (((select_t) CREF(node_1135))->clauses);
			     lname1446_1138:
			       if (PAIRP(l1445_1137))
				 {
				    {
				       node_t aux_1801;
				       {
					  obj_t aux_1802;
					  {
					     obj_t aux_1803;
					     aux_1803 = CAR(l1445_1137);
					     aux_1802 = CDR(aux_1803);
					  }
					  aux_1801 = (node_t) (aux_1802);
				       }
				       shrink_node__211_ast_shrinkify(aux_1801);
				    }
				    {
				       obj_t l1445_1808;
				       l1445_1808 = CDR(l1445_1137);
				       l1445_1137 = l1445_1808;
				       goto lname1446_1138;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 13):
			 {
			    make_box_202_t node_1144;
			    node_1144 = (make_box_202_t) (node_4);
			    {
			       bool_t test_1812;
			       {
				  bool_t test_1813;
				  {
				     obj_t aux_1814;
				     {
					object_t aux_1815;
					aux_1815 = (object_t) (node_1144);
					aux_1814 = OBJECT_WIDENING(aux_1815);
				     }
				     test_1813 = CBOOL(aux_1814);
				  }
				  if (test_1813)
				    {
				       test_1812 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1812 = ((bool_t) 0);
				    }
			       }
			       if (test_1812)
				 {
				    {
				       long arg1668_1147;
				       {
					  obj_t arg1669_1148;
					  {
					     obj_t arg1670_1149;
					     {
						object_t object_1405;
						object_1405 = (object_t) (node_1144);
						{
						   long arg1180_1406;
						   {
						      long arg1181_1407;
						      long arg1182_1408;
						      arg1181_1407 = TYPE(object_1405);
						      arg1182_1408 = OBJECT_TYPE;
						      arg1180_1406 = (arg1181_1407 - arg1182_1408);
						   }
						   {
						      obj_t vector_1412;
						      vector_1412 = _classes__134___object;
						      arg1670_1149 = VECTOR_REF(vector_1412, arg1180_1406);
						   }
						}
					     }
					     arg1669_1148 = class_super_145___object(arg1670_1149);
					  }
					  arg1668_1147 = class_num_218___object(arg1669_1148);
				       }
				       {
					  obj_t obj_1414;
					  obj_1414 = (obj_t) (node_1144);
					  (((obj_t) CREF(obj_1414))->header = MAKE_HEADER(arg1668_1147, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1828;
				       aux_1828 = (object_t) (node_1144);
				       OBJECT_WIDENING_SET(aux_1828, BFALSE);
				    }
				    (obj_t) (node_1144);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    shrink_node__211_ast_shrinkify((((make_box_202_t) CREF(node_1144))->value));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 14):
			 {
			    box_ref_242_t node_1151;
			    node_1151 = (box_ref_242_t) (node_4);
			    {
			       bool_t test_1835;
			       {
				  bool_t test_1836;
				  {
				     obj_t aux_1837;
				     {
					object_t aux_1838;
					aux_1838 = (object_t) (node_1151);
					aux_1837 = OBJECT_WIDENING(aux_1838);
				     }
				     test_1836 = CBOOL(aux_1837);
				  }
				  if (test_1836)
				    {
				       test_1835 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1835 = ((bool_t) 0);
				    }
			       }
			       if (test_1835)
				 {
				    {
				       long arg1675_1154;
				       {
					  obj_t arg1676_1155;
					  {
					     obj_t arg1677_1156;
					     {
						object_t object_1420;
						object_1420 = (object_t) (node_1151);
						{
						   long arg1180_1421;
						   {
						      long arg1181_1422;
						      long arg1182_1423;
						      arg1181_1422 = TYPE(object_1420);
						      arg1182_1423 = OBJECT_TYPE;
						      arg1180_1421 = (arg1181_1422 - arg1182_1423);
						   }
						   {
						      obj_t vector_1427;
						      vector_1427 = _classes__134___object;
						      arg1677_1156 = VECTOR_REF(vector_1427, arg1180_1421);
						   }
						}
					     }
					     arg1676_1155 = class_super_145___object(arg1677_1156);
					  }
					  arg1675_1154 = class_num_218___object(arg1676_1155);
				       }
				       {
					  obj_t obj_1429;
					  obj_1429 = (obj_t) (node_1151);
					  (((obj_t) CREF(obj_1429))->header = MAKE_HEADER(arg1675_1154, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1851;
				       aux_1851 = (object_t) (node_1151);
				       OBJECT_WIDENING_SET(aux_1851, BFALSE);
				    }
				    (obj_t) (node_1151);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       node_t aux_1855;
			       {
				  var_t aux_1856;
				  aux_1856 = (((box_ref_242_t) CREF(node_1151))->var);
				  aux_1855 = (node_t) (aux_1856);
			       }
			       shrink_node__211_ast_shrinkify(aux_1855);
			    }
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 15):
			 {
			    box_set__221_t node_1158;
			    node_1158 = (box_set__221_t) (node_4);
			    {
			       bool_t test_1861;
			       {
				  bool_t test_1862;
				  {
				     obj_t aux_1863;
				     {
					object_t aux_1864;
					aux_1864 = (object_t) (node_1158);
					aux_1863 = OBJECT_WIDENING(aux_1864);
				     }
				     test_1862 = CBOOL(aux_1863);
				  }
				  if (test_1862)
				    {
				       test_1861 = ((bool_t) 1);
				    }
				  else
				    {
				       test_1861 = ((bool_t) 0);
				    }
			       }
			       if (test_1861)
				 {
				    {
				       long arg1680_1161;
				       {
					  obj_t arg1681_1162;
					  {
					     obj_t arg1682_1163;
					     {
						object_t object_1435;
						object_1435 = (object_t) (node_1158);
						{
						   long arg1180_1436;
						   {
						      long arg1181_1437;
						      long arg1182_1438;
						      arg1181_1437 = TYPE(object_1435);
						      arg1182_1438 = OBJECT_TYPE;
						      arg1180_1436 = (arg1181_1437 - arg1182_1438);
						   }
						   {
						      obj_t vector_1442;
						      vector_1442 = _classes__134___object;
						      arg1682_1163 = VECTOR_REF(vector_1442, arg1180_1436);
						   }
						}
					     }
					     arg1681_1162 = class_super_145___object(arg1682_1163);
					  }
					  arg1680_1161 = class_num_218___object(arg1681_1162);
				       }
				       {
					  obj_t obj_1444;
					  obj_1444 = (obj_t) (node_1158);
					  (((obj_t) CREF(obj_1444))->header = MAKE_HEADER(arg1680_1161, 0), BUNSPEC);
				       }
				    }
				    {
				       object_t aux_1877;
				       aux_1877 = (object_t) (node_1158);
				       OBJECT_WIDENING_SET(aux_1877, BFALSE);
				    }
				    (obj_t) (node_1158);
				 }
			       else
				 {
				    BUNSPEC;
				 }
			    }
			    {
			       node_t aux_1881;
			       {
				  var_t aux_1882;
				  aux_1882 = (((box_set__221_t) CREF(node_1158))->var);
				  aux_1881 = (node_t) (aux_1882);
			       }
			       shrink_node__211_ast_shrinkify(aux_1881);
			    }
			    shrink_node__211_ast_shrinkify((((box_set__221_t) CREF(node_1158))->value));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 16):
			 {
			    let_fun_218_t node_1166;
			    node_1166 = (let_fun_218_t) (node_4);
			    shrink_node__211_ast_shrinkify((((let_fun_218_t) CREF(node_1166))->body));
			    {
			       obj_t l1451_1169;
			       l1451_1169 = (((let_fun_218_t) CREF(node_1166))->locals);
			     lname1452_1170:
			       if (PAIRP(l1451_1169))
				 {
				    {
				       obj_t local_1173;
				       local_1173 = CAR(l1451_1169);
				       {
					  value_t sfun_1174;
					  {
					     local_t obj_1452;
					     obj_1452 = (local_t) (local_1173);
					     sfun_1174 = (((local_t) CREF(obj_1452))->value);
					  }
					  shrink_variable__88_ast_shrinkify((variable_t) (local_1173));
					  {
					     obj_t l1453_1175;
					     {
						sfun_t obj_1453;
						obj_1453 = (sfun_t) (sfun_1174);
						l1453_1175 = (((sfun_t) CREF(obj_1453))->args);
					     }
					   lname1454_1176:
					     if (PAIRP(l1453_1175))
					       {
						  {
						     variable_t aux_1900;
						     {
							obj_t aux_1901;
							aux_1901 = CAR(l1453_1175);
							aux_1900 = (variable_t) (aux_1901);
						     }
						     shrink_variable__88_ast_shrinkify(aux_1900);
						  }
						  {
						     obj_t l1453_1905;
						     l1453_1905 = CDR(l1453_1175);
						     l1453_1175 = l1453_1905;
						     goto lname1454_1176;
						  }
					       }
					     else
					       {
						  ((bool_t) 1);
					       }
					  }
					  {
					     node_t aux_1909;
					     {
						obj_t aux_1910;
						{
						   sfun_t obj_1457;
						   obj_1457 = (sfun_t) (sfun_1174);
						   aux_1910 = (((sfun_t) CREF(obj_1457))->body);
						}
						aux_1909 = (node_t) (aux_1910);
					     }
					     shrink_node__211_ast_shrinkify(aux_1909);
					  }
				       }
				    }
				    {
				       obj_t l1451_1915;
				       l1451_1915 = CDR(l1451_1169);
				       l1451_1169 = l1451_1915;
				       goto lname1452_1170;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 17):
			 {
			    let_var_6_t node_1183;
			    node_1183 = (let_var_6_t) (node_4);
			    shrink_node__211_ast_shrinkify((((let_var_6_t) CREF(node_1183))->body));
			    {
			       obj_t l1456_1186;
			       l1456_1186 = (((let_var_6_t) CREF(node_1183))->bindings);
			     lname1457_1187:
			       if (PAIRP(l1456_1186))
				 {
				    {
				       obj_t binding_1190;
				       binding_1190 = CAR(l1456_1186);
				       {
					  variable_t aux_1924;
					  {
					     obj_t aux_1925;
					     aux_1925 = CAR(binding_1190);
					     aux_1924 = (variable_t) (aux_1925);
					  }
					  shrink_variable__88_ast_shrinkify(aux_1924);
				       }
				       {
					  node_t aux_1929;
					  {
					     obj_t aux_1930;
					     aux_1930 = CDR(binding_1190);
					     aux_1929 = (node_t) (aux_1930);
					  }
					  shrink_node__211_ast_shrinkify(aux_1929);
				       }
				    }
				    {
				       obj_t l1456_1934;
				       l1456_1934 = CDR(l1456_1186);
				       l1456_1186 = l1456_1934;
				       goto lname1457_1187;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 18):
			 {
			    set_ex_it_116_t node_1194;
			    node_1194 = (set_ex_it_116_t) (node_4);
			    {
			       node_t aux_1938;
			       {
				  var_t aux_1939;
				  aux_1939 = (((set_ex_it_116_t) CREF(node_1194))->var);
				  aux_1938 = (node_t) (aux_1939);
			       }
			       shrink_node__211_ast_shrinkify(aux_1938);
			    }
			    shrink_node__211_ast_shrinkify((((set_ex_it_116_t) CREF(node_1194))->body));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      case ((long) 19):
			 {
			    jump_ex_it_184_t node_1198;
			    node_1198 = (jump_ex_it_184_t) (node_4);
			    shrink_node__211_ast_shrinkify((((jump_ex_it_184_t) CREF(node_1198))->exit));
			    shrink_node__211_ast_shrinkify((((jump_ex_it_184_t) CREF(node_1198))->value));
			    x_1487 = BUNSPEC;
			 }
			 break;
		      default:
		       case_else1613_1084:
			 if (PROCEDUREP(method1607_1080))
			   {
			      x_1487 = PROCEDURE_ENTRY(method1607_1080) (method1607_1080, (obj_t) (node_4), BEOA);
			   }
			 else
			   {
			      obj_t fun1604_1074;
			      fun1604_1074 = PROCEDURE_REF(shrink_node__env_219_ast_shrinkify, ((long) 0));
			      x_1487 = PROCEDURE_ENTRY(fun1604_1074) (fun1604_1074, (obj_t) (node_4), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1613_1084;
		 }
	    }
	    return BUNSPEC;
	 }
      }
   }
}


/* _shrink-node!1737 */ obj_t 
_shrink_node_1737_186_ast_shrinkify(obj_t env_1483, obj_t node_1484)
{
   return shrink_node__211_ast_shrinkify((node_t) (node_1484));
}


/* shrink-node!-default1463 */ obj_t 
shrink_node__default1463_65_ast_shrinkify(node_t node_5)
{
   FAILURE(CNST_TABLE_REF(((long) 0)), string1738_ast_shrinkify, (obj_t) (node_5));
}


/* _shrink-node!-default1463 */ obj_t 
_shrink_node__default1463_68_ast_shrinkify(obj_t env_1485, obj_t node_1486)
{
   return shrink_node__default1463_65_ast_shrinkify((node_t) (node_1486));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_ast_shrinkify()
{
   module_initialization_70_type_type(((long) 0), "AST_SHRINKIFY");
   module_initialization_70_ast_var(((long) 0), "AST_SHRINKIFY");
   module_initialization_70_ast_node(((long) 0), "AST_SHRINKIFY");
   return module_initialization_70_ast_env(((long) 0), "AST_SHRINKIFY");
}
