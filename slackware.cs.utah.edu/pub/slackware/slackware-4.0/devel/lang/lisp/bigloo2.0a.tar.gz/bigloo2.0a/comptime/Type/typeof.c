/*===========================================================================*/
/*   (Type/typeof.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;


extern obj_t _long__149_type_cache;
static obj_t method_init_76_type_typeof();
extern obj_t _symbol__163_type_cache;
extern obj_t _pair__244_type_cache;
extern obj_t _obj__252_type_cache;
extern obj_t _unspec__87_type_cache;
extern obj_t module_initialization_70_type_typeof(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t _bnil__15_type_cache;
extern obj_t _real__144_type_cache;
static obj_t imported_modules_init_94_type_typeof();
extern type_t typeof_kwote_49_type_typeof(obj_t);
static obj_t library_modules_init_112_type_typeof();
static obj_t toplevel_init_63_type_typeof();
extern obj_t open_input_string(obj_t);
static obj_t _typeof_atom_103_type_typeof(obj_t, obj_t);
static obj_t _typeof_kwote_63_type_typeof(obj_t, obj_t);
extern type_t typeof_atom_134_type_typeof(obj_t);
extern obj_t read___reader(obj_t);
extern obj_t _char__84_type_cache;
extern obj_t _string__3_type_cache;
static obj_t require_initialization_114_type_typeof = BUNSPEC;
extern obj_t _vector__240_type_cache;
static obj_t cnst_init_137_type_typeof();
extern obj_t _bool__149_type_cache;
static obj_t __cnst[1];

DEFINE_EXPORT_PROCEDURE(typeof_atom_env_199_type_typeof, _typeof_atom_103_type_typeof1189, _typeof_atom_103_type_typeof, 0L, 1);
DEFINE_EXPORT_PROCEDURE(typeof_kwote_env_110_type_typeof, _typeof_kwote_63_type_typeof1190, _typeof_kwote_63_type_typeof, 0L, 1);
DEFINE_STRING(string1164_type_typeof, string1164_type_typeof1191, "A-TVECTOR ", 10);


/* module-initialization */ obj_t 
module_initialization_70_type_typeof(long checksum_159, char *from_160)
{
   if (CBOOL(require_initialization_114_type_typeof))
     {
	require_initialization_114_type_typeof = BBOOL(((bool_t) 0));
	library_modules_init_112_type_typeof();
	cnst_init_137_type_typeof();
	imported_modules_init_94_type_typeof();
	method_init_76_type_typeof();
	toplevel_init_63_type_typeof();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_type_typeof()
{
   module_initialization_70___reader(((long) 0), "TYPE_TYPEOF");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_type_typeof()
{
   {
      obj_t cnst_port_138_151;
      cnst_port_138_151 = open_input_string(string1164_type_typeof);
      {
	 long i_152;
	 i_152 = ((long) 0);
       loop_153:
	 {
	    bool_t test1165_154;
	    test1165_154 = (i_152 == ((long) -1));
	    if (test1165_154)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1175_155;
		    {
		       obj_t list1176_156;
		       {
			  obj_t arg1187_157;
			  arg1187_157 = BNIL;
			  list1176_156 = MAKE_PAIR(cnst_port_138_151, arg1187_157);
		       }
		       arg1175_155 = read___reader(list1176_156);
		    }
		    CNST_TABLE_SET(i_152, arg1175_155);
		 }
		 {
		    int aux_158;
		    {
		       long aux_176;
		       aux_176 = (i_152 - ((long) 1));
		       aux_158 = (int) (aux_176);
		    }
		    {
		       long i_179;
		       i_179 = (long) (aux_158);
		       i_152 = i_179;
		       goto loop_153;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_type_typeof()
{
   return BUNSPEC;
}


/* typeof-atom */ type_t 
typeof_atom_134_type_typeof(obj_t atom_11)
{
   if (NULLP(atom_11))
     {
	return (type_t) (_bnil__15_type_cache);
     }
   else
     {
	bool_t test1140_78;
	test1140_78 = INTEGERP(atom_11);
	if (test1140_78)
	  {
	     return (type_t) (_long__149_type_cache);
	  }
	else
	  {
	     bool_t test_187;
	     if (test1140_78)
	       {
		  test_187 = ((bool_t) 1);
	       }
	     else
	       {
		  test_187 = REALP(atom_11);
	       }
	     if (test_187)
	       {
		  return (type_t) (_real__144_type_cache);
	       }
	     else
	       {
		  if (BOOLEANP(atom_11))
		    {
		       return (type_t) (_bool__149_type_cache);
		    }
		  else
		    {
		       if (CHARP(atom_11))
			 {
			    return (type_t) (_char__84_type_cache);
			 }
		       else
			 {
			    if (STRINGP(atom_11))
			      {
				 return (type_t) (_string__3_type_cache);
			      }
			    else
			      {
				 if ((atom_11 == BUNSPEC))
				   {
				      return (type_t) (_unspec__87_type_cache);
				   }
				 else
				   {
				      return (type_t) (_obj__252_type_cache);
				   }
			      }
			 }
		    }
	       }
	  }
     }
}


/* _typeof-atom */ obj_t 
_typeof_atom_103_type_typeof(obj_t env_146, obj_t atom_147)
{
   {
      type_t aux_204;
      aux_204 = typeof_atom_134_type_typeof(atom_147);
      return (obj_t) (aux_204);
   }
}


/* typeof-kwote */ type_t 
typeof_kwote_49_type_typeof(obj_t kwote_12)
{
   if (SYMBOLP(kwote_12))
     {
	return (type_t) (_symbol__163_type_cache);
     }
   else
     {
	if (PAIRP(kwote_12))
	  {
	     return (type_t) (_pair__244_type_cache);
	  }
	else
	  {
	     if (NULLP(kwote_12))
	       {
		  return (type_t) (_bnil__15_type_cache);
	       }
	     else
	       {
		  if (VECTORP(kwote_12))
		    {
		       return (type_t) (_vector__240_type_cache);
		    }
		  else
		    {
		       bool_t test_219;
		       if (STRUCTP(kwote_12))
			 {
			    obj_t aux_224;
			    obj_t aux_222;
			    aux_224 = CNST_TABLE_REF(((long) 0));
			    aux_222 = STRUCT_KEY(kwote_12);
			    test_219 = (aux_222 == aux_224);
			 }
		       else
			 {
			    test_219 = ((bool_t) 0);
			 }
		       if (test_219)
			 {
			    {
			       obj_t aux_227;
			       aux_227 = STRUCT_REF(kwote_12, ((long) 0));
			       return (type_t) (aux_227);
			    }
			 }
		       else
			 {
			    return (type_t) (_obj__252_type_cache);
			 }
		    }
	       }
	  }
     }
}


/* _typeof-kwote */ obj_t 
_typeof_kwote_63_type_typeof(obj_t env_148, obj_t kwote_149)
{
   {
      type_t aux_231;
      aux_231 = typeof_kwote_49_type_typeof(kwote_149);
      return (obj_t) (aux_231);
   }
}


/* method-init */ obj_t 
method_init_76_type_typeof()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_type_typeof()
{
   module_initialization_70_type_type(((long) 0), "TYPE_TYPEOF");
   return module_initialization_70_type_cache(((long) 0), "TYPE_TYPEOF");
}
