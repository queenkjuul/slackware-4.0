/*===========================================================================*/
/*   (Llib/dsssl.scm)                                                        */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern obj_t string_to_keyword(char *);
static obj_t list1582___dsssl = BUNSPEC;
extern obj_t string_to_symbol(char *);
extern obj_t string_append(obj_t, obj_t);
extern obj_t dsssl_formals__scheme_formals_201___dsssl(obj_t, obj_t);
extern obj_t dsssl_check_key_args__153___dsssl(obj_t, obj_t);
static obj_t _dsssl_formals__scheme_formals1561_222___dsssl(obj_t, obj_t, obj_t);
static obj_t optional_state_215___dsssl(obj_t, obj_t, obj_t);
extern obj_t gensym___r4_symbols_6_4;
static obj_t _dsssl_check_key_args__61___dsssl(obj_t, obj_t, obj_t);
static obj_t loop___dsssl(obj_t, obj_t, obj_t, bool_t);
static obj_t exit_rest_state_151___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t memq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t optional_state_1562_79___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___dsssl(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t c_substring(obj_t, long, long);
static obj_t id_sans_type_130___dsssl(obj_t);
static obj_t no_rest_key_state_212___dsssl(obj_t, obj_t, obj_t);
static obj_t rest_key_state_46___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rest_state_87___dsssl(obj_t, obj_t, obj_t);
static obj_t _dsssl_get_key_arg1560_49___dsssl(obj_t, obj_t, obj_t, obj_t);
static obj_t one_key_arg_10___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _make_dsssl_function_prelude1559_73___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t dsssl_get_key_arg_157___dsssl(obj_t, obj_t, obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t tag_141_241___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94___dsssl();
extern obj_t make_dsssl_function_prelude_58___dsssl(obj_t, obj_t, obj_t, obj_t);
static obj_t require_initialization_114___dsssl = BUNSPEC;
static obj_t key_state_193___dsssl(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t cnst_init_137___dsssl();
static obj_t symbol1578___dsssl = BUNSPEC;
static obj_t symbol1577___dsssl = BUNSPEC;
static obj_t symbol1576___dsssl = BUNSPEC;
static obj_t symbol1575___dsssl = BUNSPEC;
static obj_t symbol1574___dsssl = BUNSPEC;
static obj_t symbol__keyword_174___dsssl(obj_t);
static obj_t symbol1573___dsssl = BUNSPEC;
static obj_t symbol1572___dsssl = BUNSPEC;
static obj_t symbol1571___dsssl = BUNSPEC;
static obj_t symbol1570___dsssl = BUNSPEC;
static obj_t symbol1567___dsssl = BUNSPEC;
static obj_t symbol1564___dsssl = BUNSPEC;
static obj_t symbol1563___dsssl = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( dsssl_check_key_args__env_216___dsssl, _dsssl_check_key_args__61___dsssl1589, _dsssl_check_key_args__61___dsssl, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( dsssl_get_key_arg_env_24___dsssl, _dsssl_get_key_arg1560_49___dsssl1590, _dsssl_get_key_arg1560_49___dsssl, 0L, 3 );
DEFINE_EXPORT_PROCEDURE( make_dsssl_function_prelude_env_81___dsssl, _make_dsssl_function_prelude1559_73___dsssl1591, _make_dsssl_function_prelude1559_73___dsssl, 0L, 4 );
DEFINE_EXPORT_PROCEDURE( dsssl_formals__scheme_formals_env_148___dsssl, _dsssl_formals__scheme_formals1561_222___dsssl1592, _dsssl_formals__scheme_formals1561_222___dsssl, 0L, 2 );
DEFINE_STRING( string1587___dsssl, string1587___dsssl1593, "and `.' notation", 16 );
DEFINE_STRING( string1586___dsssl, string1586___dsssl1594, "Can't use both DSSSL named constant", 35 );
DEFINE_STRING( string1585___dsssl, string1585___dsssl1595, "symbol expected", 15 );
DEFINE_STRING( string1584___dsssl, string1584___dsssl1596, "symbol or named constant expected", 33 );
DEFINE_STRING( string1583___dsssl, string1583___dsssl1597, "Illegal formal parameter", 24 );
DEFINE_STRING( string1581___dsssl, string1581___dsssl1598, "Illegal #!keys parameters", 25 );
DEFINE_STRING( string1579___dsssl, string1579___dsssl1599, "Illegal Dsssl formal list (#!optional)", 38 );
DEFINE_STRING( string1580___dsssl, string1580___dsssl1600, "dsssl formal parsing", 20 );
DEFINE_STRING( string1569___dsssl, string1569___dsssl1601, "Illegal Dsssl formal list (#!rest)", 34 );
DEFINE_STRING( string1568___dsssl, string1568___dsssl1602, ":", 1 );
DEFINE_STRING( string1566___dsssl, string1566___dsssl1603, "Illegal Dsssl formal list (#!key)", 33 );
DEFINE_STRING( string1565___dsssl, string1565___dsssl1604, "Illegal formal list", 19 );


/* module-initialization */obj_t module_initialization_70___dsssl(long checksum_1148, char * from_1149)
{
if(CBOOL(require_initialization_114___dsssl)){
require_initialization_114___dsssl = BBOOL(((bool_t)0));
cnst_init_137___dsssl();
imported_modules_init_94___dsssl();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___dsssl()
{
symbol1563___dsssl = string_to_symbol("DSSSL");
symbol1564___dsssl = string_to_symbol("LET");
symbol1567___dsssl = string_to_symbol("DSSSL-GET-KEY-ARG");
symbol1570___dsssl = string_to_symbol("BEGIN");
symbol1571___dsssl = string_to_symbol("DSSSL-CHECK-KEY-ARGS!");
symbol1572___dsssl = string_to_symbol("QUOTE");
symbol1573___dsssl = string_to_symbol("TMP");
symbol1574___dsssl = string_to_symbol("IF");
symbol1575___dsssl = string_to_symbol("NULL?");
symbol1576___dsssl = string_to_symbol("CAR");
symbol1577___dsssl = string_to_symbol("SET!");
symbol1578___dsssl = string_to_symbol("CDR");
{
obj_t aux_1167;
{
obj_t aux_1168;
aux_1168 = MAKE_PAIR(BCNST(262), BNIL);
aux_1167 = MAKE_PAIR(BCNST(259), aux_1168);
}
return (list1582___dsssl = MAKE_PAIR(BCNST(258), aux_1167),
BUNSPEC);
}
}


/* make-dsssl-function-prelude */obj_t make_dsssl_function_prelude_58___dsssl(obj_t where_1, obj_t formals_2, obj_t body_3, obj_t err_4)
{
{
obj_t optional_state_215_1079;
obj_t rest_state_87_1078;
obj_t no_rest_key_state_212_1077;
optional_state_215_1079 = make_fx_procedure(optional_state_215___dsssl, ((long)2), ((long)5));
rest_state_87_1078 = make_fx_procedure(rest_state_87___dsssl, ((long)2), ((long)4));
no_rest_key_state_212_1077 = make_fx_procedure(no_rest_key_state_212___dsssl, ((long)2), ((long)4));
PROCEDURE_SET(optional_state_215_1079, ((long)0), err_4);
PROCEDURE_SET(optional_state_215_1079, ((long)1), where_1);
PROCEDURE_SET(optional_state_215_1079, ((long)2), formals_2);
PROCEDURE_SET(optional_state_215_1079, ((long)3), rest_state_87_1078);
PROCEDURE_SET(optional_state_215_1079, ((long)4), body_3);
PROCEDURE_SET(rest_state_87_1078, ((long)0), body_3);
PROCEDURE_SET(rest_state_87_1078, ((long)1), err_4);
PROCEDURE_SET(rest_state_87_1078, ((long)2), where_1);
PROCEDURE_SET(rest_state_87_1078, ((long)3), formals_2);
PROCEDURE_SET(no_rest_key_state_212_1077, ((long)0), err_4);
PROCEDURE_SET(no_rest_key_state_212_1077, ((long)1), where_1);
PROCEDURE_SET(no_rest_key_state_212_1077, ((long)2), formals_2);
PROCEDURE_SET(no_rest_key_state_212_1077, ((long)3), body_3);
{
obj_t args_587;
obj_t args_523;
obj_t next_state_161_524;
args_587 = formals_2;
scheme_state_248_604:
if(PAIRP(args_587)){
bool_t test_1190;
{
bool_t test_1191;
{
obj_t aux_1192;
aux_1192 = CAR(args_587);
test_1191 = SYMBOLP(aux_1192);
}
if(test_1191){
test_1190 = ((bool_t)0);
}
 else {
bool_t test_1195;
{
obj_t aux_1196;
aux_1196 = CAR(args_587);
test_1195 = PAIRP(aux_1196);
}
if(test_1195){
test_1190 = ((bool_t)0);
}
 else {
test_1190 = ((bool_t)1);
}
}
}
if(test_1190){
{
long aux1004_592;
{
obj_t aux1002_597;
aux1002_597 = CAR(args_587);
if(CNSTP(aux1002_597)){
aux1004_592 = CCNST(aux1002_597);
}
 else {
aux1004_592 = ((long)-1);
}
}
switch (aux1004_592){
case ((long)258) : 
args_523 = CDR(args_587);
next_state_161_524 = optional_state_215_1079;
enter_dsssl_state_31_605:
{
obj_t as_526;
as_526 = args_523;
loop_527:
if(NULLP(as_526)){
return PROCEDURE_ENTRY(next_state_161_524)(next_state_161_524, args_523, BUNSPEC, BEOA);
}
 else {
if(PAIRP(as_526)){
bool_t test_1209;
{
bool_t test_1210;
{
obj_t aux_1211;
aux_1211 = CAR(as_526);
test_1210 = SYMBOLP(aux_1211);
}
if(test_1210){
test_1209 = ((bool_t)0);
}
 else {
bool_t test_1214;
{
obj_t aux_1215;
aux_1215 = CAR(as_526);
test_1214 = PAIRP(aux_1215);
}
if(test_1214){
test_1209 = ((bool_t)0);
}
 else {
test_1209 = ((bool_t)1);
}
}
}
if(test_1209){
{
obj_t as_1218;
as_1218 = CDR(as_526);
as_526 = as_1218;
goto loop_527;
}
}
 else {
{
{
obj_t e_103_175_534;
e_103_175_534 = CAR(as_526);
if(SYMBOLP(e_103_175_534)){
{
obj_t dsssl_arg_196_544;
dsssl_arg_196_544 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1563___dsssl, BEOA);
{
obj_t arg1281_545;
obj_t arg1282_546;
obj_t arg1283_547;
arg1281_545 = symbol1564___dsssl;
{
obj_t arg1290_553;
{
obj_t arg1295_557;
arg1295_557 = CAR(as_526);
{
obj_t list1297_559;
{
obj_t arg1298_560;
arg1298_560 = MAKE_PAIR(BNIL, BNIL);
list1297_559 = MAKE_PAIR(arg1295_557, arg1298_560);
}
arg1290_553 = cons__138___r4_pairs_and_lists_6_3(dsssl_arg_196_544, list1297_559);
}
}
{
obj_t list1292_555;
list1292_555 = MAKE_PAIR(BNIL, BNIL);
arg1282_546 = cons__138___r4_pairs_and_lists_6_3(arg1290_553, list1292_555);
}
}
arg1283_547 = PROCEDURE_ENTRY(next_state_161_524)(next_state_161_524, args_523, dsssl_arg_196_544, BEOA);
{
obj_t list1285_549;
{
obj_t arg1286_550;
{
obj_t arg1287_551;
arg1287_551 = MAKE_PAIR(BNIL, BNIL);
arg1286_550 = MAKE_PAIR(arg1283_547, arg1287_551);
}
list1285_549 = MAKE_PAIR(arg1282_546, arg1286_550);
}
return cons__138___r4_pairs_and_lists_6_3(arg1281_545, list1285_549);
}
}
}
}
 else {
if(PAIRP(e_103_175_534)){
obj_t cdr_105_52_537;
cdr_105_52_537 = CDR(e_103_175_534);
{
bool_t test_1240;
{
obj_t aux_1241;
aux_1241 = CAR(e_103_175_534);
test_1240 = SYMBOLP(aux_1241);
}
if(test_1240){
if(PAIRP(cdr_105_52_537)){
bool_t test_1246;
{
obj_t aux_1247;
aux_1247 = CDR(cdr_105_52_537);
test_1246 = (aux_1247==BNIL);
}
if(test_1246){
{
obj_t dsssl_arg_196_563;
dsssl_arg_196_563 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1563___dsssl, BEOA);
{
obj_t arg1301_564;
obj_t arg1302_565;
obj_t arg1303_566;
arg1301_564 = symbol1564___dsssl;
{
obj_t arg1310_572;
{
obj_t arg1315_576;
{
obj_t aux_1252;
aux_1252 = CAR(as_526);
arg1315_576 = CAR(aux_1252);
}
{
obj_t list1317_578;
{
obj_t arg1319_579;
arg1319_579 = MAKE_PAIR(BNIL, BNIL);
list1317_578 = MAKE_PAIR(arg1315_576, arg1319_579);
}
arg1310_572 = cons__138___r4_pairs_and_lists_6_3(dsssl_arg_196_563, list1317_578);
}
}
{
obj_t list1312_574;
list1312_574 = MAKE_PAIR(BNIL, BNIL);
arg1302_565 = cons__138___r4_pairs_and_lists_6_3(arg1310_572, list1312_574);
}
}
arg1303_566 = PROCEDURE_ENTRY(next_state_161_524)(next_state_161_524, args_523, dsssl_arg_196_563, BEOA);
{
obj_t list1305_568;
{
obj_t arg1307_569;
{
obj_t arg1308_570;
arg1308_570 = MAKE_PAIR(BNIL, BNIL);
arg1307_569 = MAKE_PAIR(arg1303_566, arg1308_570);
}
list1305_568 = MAKE_PAIR(arg1302_565, arg1307_569);
}
return cons__138___r4_pairs_and_lists_6_3(arg1301_564, list1305_568);
}
}
}
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
 else {
return BFALSE;
}
}
}
 else {
return BFALSE;
}
}
}
}
}
}
 else {
return PROCEDURE_ENTRY(err_4)(err_4, where_1, string1565___dsssl, formals_2, BEOA);
}
}
}
break;
case ((long)259) : 
{
obj_t next_state_161_1271;
obj_t args_1269;
args_1269 = CDR(args_587);
next_state_161_1271 = rest_state_87_1078;
next_state_161_524 = next_state_161_1271;
args_523 = args_1269;
goto enter_dsssl_state_31_605;
}
break;
case ((long)262) : 
{
obj_t next_state_161_1274;
obj_t args_1272;
args_1272 = CDR(args_587);
next_state_161_1274 = no_rest_key_state_212_1077;
next_state_161_524 = next_state_161_1274;
args_523 = args_1272;
goto enter_dsssl_state_31_605;
}
break;
default: 
return PROCEDURE_ENTRY(err_4)(err_4, where_1, string1565___dsssl, formals_2, BEOA);
}
}
}
 else {
{
obj_t args_1278;
args_1278 = CDR(args_587);
args_587 = args_1278;
goto scheme_state_248_604;
}
}
}
 else {
return body_3;
}
}
}
}


/* _make-dsssl-function-prelude1559 */obj_t _make_dsssl_function_prelude1559_73___dsssl(obj_t env_1080, obj_t where_1081, obj_t formals_1082, obj_t body_1083, obj_t err_1084)
{
return make_dsssl_function_prelude_58___dsssl(where_1081, formals_1082, body_1083, err_1084);
}


/* key-state */obj_t key_state_193___dsssl(obj_t body_1088, obj_t formals_1087, obj_t where_1086, obj_t err_1085, obj_t args_234, obj_t dsssl_arg_196_235)
{
if(NULLP(args_234)){
return body_1088;
}
 else {
if(PAIRP(args_234)){
bool_t test_1285;
{
bool_t test_1286;
{
obj_t aux_1287;
aux_1287 = CAR(args_234);
test_1286 = SYMBOLP(aux_1287);
}
if(test_1286){
test_1285 = ((bool_t)0);
}
 else {
bool_t test_1290;
{
obj_t aux_1291;
aux_1291 = CAR(args_234);
test_1290 = PAIRP(aux_1291);
}
if(test_1290){
test_1285 = ((bool_t)0);
}
 else {
test_1285 = ((bool_t)1);
}
}
}
if(test_1285){
return PROCEDURE_ENTRY(err_1085)(err_1085, where_1086, string1566___dsssl, formals_1087, BEOA);
}
 else {
{
obj_t e_168_255_247;
e_168_255_247 = CAR(args_234);
if(PAIRP(e_168_255_247)){
obj_t car_173_126_249;
obj_t cdr_174_83_250;
car_173_126_249 = CAR(e_168_255_247);
cdr_174_83_250 = CDR(e_168_255_247);
if(SYMBOLP(car_173_126_249)){
if(PAIRP(cdr_174_83_250)){
bool_t test_1305;
{
obj_t aux_1306;
aux_1306 = CDR(cdr_174_83_250);
test_1305 = (aux_1306==BNIL);
}
if(test_1305){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1088, formals_1087, where_1086, err_1085, car_173_126_249, CAR(cdr_174_83_250));
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1088, formals_1087, where_1086, err_1085, e_168_255_247, BFALSE);
}
 else {
return PROCEDURE_ENTRY(err_1085)(err_1085, where_1086, string1566___dsssl, formals_1087, BEOA);
}
}
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1088, formals_1087, where_1086, err_1085, e_168_255_247, BFALSE);
}
 else {
return PROCEDURE_ENTRY(err_1085)(err_1085, where_1086, string1566___dsssl, formals_1087, BEOA);
}
}
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1088, formals_1087, where_1086, err_1085, e_168_255_247, BFALSE);
}
 else {
return PROCEDURE_ENTRY(err_1085)(err_1085, where_1086, string1566___dsssl, formals_1087, BEOA);
}
}
}
 else {
if(SYMBOLP(e_168_255_247)){
return one_key_arg_10___dsssl(args_234, dsssl_arg_196_235, body_1088, formals_1087, where_1086, err_1085, e_168_255_247, BFALSE);
}
 else {
return PROCEDURE_ENTRY(err_1085)(err_1085, where_1086, string1566___dsssl, formals_1087, BEOA);
}
}
}
}
}
 else {
return PROCEDURE_ENTRY(err_1085)(err_1085, where_1086, string1566___dsssl, formals_1087, BEOA);
}
}
}


/* one-key-arg */obj_t one_key_arg_10___dsssl(obj_t args_1094, obj_t dsssl_arg_196_1093, obj_t body_1092, obj_t formals_1091, obj_t where_1090, obj_t err_1089, obj_t arg_265, obj_t initializer_266)
{
{
obj_t arg1037_268;
obj_t arg1038_269;
obj_t arg1039_270;
arg1037_268 = symbol1564___dsssl;
{
obj_t arg1045_276;
{
obj_t arg1049_280;
{
obj_t arg1055_285;
obj_t arg1056_286;
arg1055_285 = symbol1567___dsssl;
{
obj_t arg1411_845;
{
obj_t arg1413_846;
arg1413_846 = SYMBOL_TO_STRING(arg_265);
arg1411_845 = string_append(arg1413_846, string1568___dsssl);
}
{
char * aux_1335;
aux_1335 = BSTRING_TO_STRING(arg1411_845);
arg1056_286 = string_to_keyword(aux_1335);
}
}
{
obj_t list1058_288;
{
obj_t arg1059_289;
{
obj_t arg1060_290;
{
obj_t arg1061_291;
arg1061_291 = MAKE_PAIR(BNIL, BNIL);
arg1060_290 = MAKE_PAIR(initializer_266, arg1061_291);
}
arg1059_289 = MAKE_PAIR(arg1056_286, arg1060_290);
}
list1058_288 = MAKE_PAIR(dsssl_arg_196_1093, arg1059_289);
}
arg1049_280 = cons__138___r4_pairs_and_lists_6_3(arg1055_285, list1058_288);
}
}
{
obj_t list1051_282;
{
obj_t arg1053_283;
arg1053_283 = MAKE_PAIR(BNIL, BNIL);
list1051_282 = MAKE_PAIR(arg1049_280, arg1053_283);
}
arg1045_276 = cons__138___r4_pairs_and_lists_6_3(arg_265, list1051_282);
}
}
{
obj_t list1047_278;
list1047_278 = MAKE_PAIR(BNIL, BNIL);
arg1038_269 = cons__138___r4_pairs_and_lists_6_3(arg1045_276, list1047_278);
}
}
arg1039_270 = key_state_193___dsssl(body_1092, formals_1091, where_1090, err_1089, CDR(args_1094), dsssl_arg_196_1093);
{
obj_t list1041_272;
{
obj_t arg1042_273;
{
obj_t arg1043_274;
arg1043_274 = MAKE_PAIR(BNIL, BNIL);
arg1042_273 = MAKE_PAIR(arg1039_270, arg1043_274);
}
list1041_272 = MAKE_PAIR(arg1038_269, arg1042_273);
}
return cons__138___r4_pairs_and_lists_6_3(arg1037_268, list1041_272);
}
}
}


/* tag-141 */obj_t tag_141_241___dsssl(obj_t args_1100, obj_t dsssl_arg_196_1099, obj_t body_1098, obj_t formals_1097, obj_t where_1096, obj_t err_1095, obj_t id_390)
{
{
obj_t arg1137_395;
obj_t arg1139_396;
obj_t arg1140_397;
arg1137_395 = symbol1564___dsssl;
{
obj_t arg1146_403;
{
obj_t list1152_408;
{
obj_t arg1153_409;
arg1153_409 = MAKE_PAIR(BNIL, BNIL);
list1152_408 = MAKE_PAIR(dsssl_arg_196_1099, arg1153_409);
}
arg1146_403 = cons__138___r4_pairs_and_lists_6_3(id_390, list1152_408);
}
{
obj_t list1148_405;
list1148_405 = MAKE_PAIR(BNIL, BNIL);
arg1139_396 = cons__138___r4_pairs_and_lists_6_3(arg1146_403, list1148_405);
}
}
arg1140_397 = exit_rest_state_151___dsssl(body_1098, formals_1097, where_1096, err_1095, CDR(args_1100), dsssl_arg_196_1099);
{
obj_t list1142_399;
{
obj_t arg1143_400;
{
obj_t arg1144_401;
arg1144_401 = MAKE_PAIR(BNIL, BNIL);
arg1143_400 = MAKE_PAIR(arg1140_397, arg1144_401);
}
list1142_399 = MAKE_PAIR(arg1139_396, arg1143_400);
}
return cons__138___r4_pairs_and_lists_6_3(arg1137_395, list1142_399);
}
}
}


/* exit-rest-state */obj_t exit_rest_state_151___dsssl(obj_t body_1104, obj_t formals_1103, obj_t where_1102, obj_t err_1101, obj_t args_378, obj_t dsssl_arg_196_379)
{
if(NULLP(args_378)){
return body_1104;
}
 else {
if(PAIRP(args_378)){
bool_t test_1369;
{
obj_t aux_1370;
aux_1370 = CAR(args_378);
test_1369 = (aux_1370==BCNST(262));
}
if(test_1369){
return rest_key_state_46___dsssl(body_1104, formals_1103, where_1102, err_1101, CDR(args_378), dsssl_arg_196_379);
}
 else {
return PROCEDURE_ENTRY(err_1101)(err_1101, where_1102, string1569___dsssl, formals_1103, BEOA);
}
}
 else {
return PROCEDURE_ENTRY(err_1101)(err_1101, where_1102, string1569___dsssl, formals_1103, BEOA);
}
}
}


/* rest-key-state */obj_t rest_key_state_46___dsssl(obj_t body_1108, obj_t formals_1107, obj_t where_1106, obj_t err_1105, obj_t args_353, obj_t dsssl_arg_196_354)
{
if(NULLP(args_353)){
return body_1108;
}
 else {
{
obj_t arg1107_357;
obj_t arg1108_358;
obj_t arg1109_359;
arg1107_357 = symbol1570___dsssl;
{
obj_t arg1115_365;
obj_t arg1116_366;
arg1115_365 = symbol1571___dsssl;
{
obj_t arg1122_372;
arg1122_372 = symbol1572___dsssl;
{
obj_t list1125_375;
{
obj_t arg1126_376;
arg1126_376 = MAKE_PAIR(BNIL, BNIL);
list1125_375 = MAKE_PAIR(BNIL, arg1126_376);
}
arg1116_366 = cons__138___r4_pairs_and_lists_6_3(arg1122_372, list1125_375);
}
}
{
obj_t list1118_368;
{
obj_t arg1119_369;
{
obj_t arg1120_370;
arg1120_370 = MAKE_PAIR(BNIL, BNIL);
arg1119_369 = MAKE_PAIR(arg1116_366, arg1120_370);
}
list1118_368 = MAKE_PAIR(dsssl_arg_196_354, arg1119_369);
}
arg1108_358 = cons__138___r4_pairs_and_lists_6_3(arg1115_365, list1118_368);
}
}
arg1109_359 = key_state_193___dsssl(body_1108, formals_1107, where_1106, err_1105, args_353, dsssl_arg_196_354);
{
obj_t list1111_361;
{
obj_t arg1112_362;
{
obj_t arg1113_363;
arg1113_363 = MAKE_PAIR(BNIL, BNIL);
arg1112_362 = MAKE_PAIR(arg1109_359, arg1113_363);
}
list1111_361 = MAKE_PAIR(arg1108_358, arg1112_362);
}
return cons__138___r4_pairs_and_lists_6_3(arg1107_357, list1111_361);
}
}
}
}


/* no-rest-key-state */obj_t no_rest_key_state_212___dsssl(obj_t env_1109, obj_t args_1114, obj_t dsssl_arg_196_1115)
{
{
obj_t err_1110;
obj_t where_1111;
obj_t formals_1112;
obj_t body_1113;
err_1110 = PROCEDURE_REF(env_1109, ((long)0));
where_1111 = PROCEDURE_REF(env_1109, ((long)1));
formals_1112 = PROCEDURE_REF(env_1109, ((long)2));
body_1113 = PROCEDURE_REF(env_1109, ((long)3));
{
obj_t args_295;
obj_t dsssl_arg_196_296;
args_295 = args_1114;
dsssl_arg_196_296 = dsssl_arg_196_1115;
{
obj_t args_321;
if(NULLP(args_295)){
return body_1113;
}
 else {
{
obj_t arg1066_300;
obj_t arg1067_301;
obj_t arg1068_302;
arg1066_300 = symbol1570___dsssl;
{
obj_t arg1077_308;
obj_t arg1078_309;
arg1077_308 = symbol1571___dsssl;
{
obj_t arg1084_315;
obj_t arg1085_316;
arg1084_315 = symbol1572___dsssl;
args_321 = args_295;
if(NULLP(args_321)){
arg1085_316 = BNIL;
}
 else {
obj_t head1010_325;
head1010_325 = MAKE_PAIR(BNIL, BNIL);
{
obj_t l1008_326;
obj_t tail1011_327;
l1008_326 = args_321;
tail1011_327 = head1010_325;
lname1009_328:
if(NULLP(l1008_326)){
arg1085_316 = CDR(head1010_325);
}
 else {
obj_t newtail1012_330;
{
obj_t arg1094_332;
{
obj_t arg_334;
arg_334 = CAR(l1008_326);
if(SYMBOLP(arg_334)){
arg1094_332 = symbol__keyword_174___dsssl(arg_334);
}
 else {
if(PAIRP(arg_334)){
obj_t car_158_189_343;
obj_t cdr_159_157_344;
car_158_189_343 = CAR(arg_334);
cdr_159_157_344 = CDR(arg_334);
if(SYMBOLP(car_158_189_343)){
if(PAIRP(cdr_159_157_344)){
bool_t test_1417;
{
obj_t aux_1418;
aux_1418 = CDR(cdr_159_157_344);
test_1417 = (aux_1418==BNIL);
}
if(test_1417){
arg1094_332 = symbol__keyword_174___dsssl(car_158_189_343);
}
 else {
arg1094_332 = PROCEDURE_ENTRY(err_1110)(err_1110, where_1111, string1566___dsssl, formals_1112, BEOA);
}
}
 else {
arg1094_332 = PROCEDURE_ENTRY(err_1110)(err_1110, where_1111, string1566___dsssl, formals_1112, BEOA);
}
}
 else {
arg1094_332 = PROCEDURE_ENTRY(err_1110)(err_1110, where_1111, string1566___dsssl, formals_1112, BEOA);
}
}
 else {
arg1094_332 = PROCEDURE_ENTRY(err_1110)(err_1110, where_1111, string1566___dsssl, formals_1112, BEOA);
}
}
}
newtail1012_330 = MAKE_PAIR(arg1094_332, BNIL);
}
SET_CDR(tail1011_327, newtail1012_330);
{
obj_t tail1011_1434;
obj_t l1008_1432;
l1008_1432 = CDR(l1008_326);
tail1011_1434 = newtail1012_330;
tail1011_327 = tail1011_1434;
l1008_326 = l1008_1432;
goto lname1009_328;
}
}
}
}
{
obj_t list1087_318;
{
obj_t arg1088_319;
arg1088_319 = MAKE_PAIR(BNIL, BNIL);
list1087_318 = MAKE_PAIR(arg1085_316, arg1088_319);
}
arg1078_309 = cons__138___r4_pairs_and_lists_6_3(arg1084_315, list1087_318);
}
}
{
obj_t list1080_311;
{
obj_t arg1081_312;
{
obj_t arg1082_313;
arg1082_313 = MAKE_PAIR(BNIL, BNIL);
arg1081_312 = MAKE_PAIR(arg1078_309, arg1082_313);
}
list1080_311 = MAKE_PAIR(dsssl_arg_196_296, arg1081_312);
}
arg1067_301 = cons__138___r4_pairs_and_lists_6_3(arg1077_308, list1080_311);
}
}
arg1068_302 = key_state_193___dsssl(body_1113, formals_1112, where_1111, err_1110, args_295, dsssl_arg_196_296);
{
obj_t list1070_304;
{
obj_t arg1072_305;
{
obj_t arg1073_306;
arg1073_306 = MAKE_PAIR(BNIL, BNIL);
arg1072_305 = MAKE_PAIR(arg1068_302, arg1073_306);
}
list1070_304 = MAKE_PAIR(arg1067_301, arg1072_305);
}
return cons__138___r4_pairs_and_lists_6_3(arg1066_300, list1070_304);
}
}
}
}
}
}
}


/* rest-state */obj_t rest_state_87___dsssl(obj_t env_1116, obj_t args_1121, obj_t dsssl_arg_196_1122)
{
{
obj_t body_1117;
obj_t err_1118;
obj_t where_1119;
obj_t formals_1120;
body_1117 = PROCEDURE_REF(env_1116, ((long)0));
err_1118 = PROCEDURE_REF(env_1116, ((long)1));
where_1119 = PROCEDURE_REF(env_1116, ((long)2));
formals_1120 = PROCEDURE_REF(env_1116, ((long)3));
{
obj_t args_386;
obj_t dsssl_arg_196_387;
args_386 = args_1121;
dsssl_arg_196_387 = dsssl_arg_196_1122;
if(PAIRP(args_386)){
{
obj_t e_143_131_393;
e_143_131_393 = CAR(args_386);
if(SYMBOLP(e_143_131_393)){
return tag_141_241___dsssl(args_386, dsssl_arg_196_387, body_1117, formals_1120, where_1119, err_1118, e_143_131_393);
}
 else {
FAILURE(where_1119,string1569___dsssl,formals_1120);}
}
}
 else {
return PROCEDURE_ENTRY(err_1118)(err_1118, where_1119, string1569___dsssl, formals_1120, BEOA);
}
}
}
}


/* optional-state */obj_t optional_state_215___dsssl(obj_t env_1123, obj_t args_1129, obj_t dsssl_arg_196_1130)
{
return optional_state_1562_79___dsssl(PROCEDURE_REF(env_1123, ((long)4)), PROCEDURE_REF(env_1123, ((long)3)), PROCEDURE_REF(env_1123, ((long)2)), PROCEDURE_REF(env_1123, ((long)1)), PROCEDURE_REF(env_1123, ((long)0)), args_1129, dsssl_arg_196_1130);
}


/* optional-state_1562 */obj_t optional_state_1562_79___dsssl(obj_t body_1147, obj_t rest_state_87_1146, obj_t formals_1145, obj_t where_1144, obj_t err_1143, obj_t args_412, obj_t dsssl_arg_196_413)
{
{
obj_t arg_450;
obj_t initializer_451;
if(NULLP(args_412)){
return body_1147;
}
 else {
if(PAIRP(args_412)){
bool_t test_1470;
{
bool_t test_1471;
{
obj_t aux_1472;
aux_1472 = CAR(args_412);
test_1471 = SYMBOLP(aux_1472);
}
if(test_1471){
test_1470 = ((bool_t)0);
}
 else {
bool_t test_1475;
{
obj_t aux_1476;
aux_1476 = CAR(args_412);
test_1475 = PAIRP(aux_1476);
}
if(test_1475){
test_1470 = ((bool_t)0);
}
 else {
test_1470 = ((bool_t)1);
}
}
}
if(test_1470){
{
long aux1007_420;
{
obj_t aux1005_424;
aux1005_424 = CAR(args_412);
if(CNSTP(aux1005_424)){
aux1007_420 = CCNST(aux1005_424);
}
 else {
aux1007_420 = ((long)-1);
}
}
switch (aux1007_420){
case ((long)259) : 
return rest_state_87___dsssl(rest_state_87_1146, CDR(args_412), dsssl_arg_196_413);
break;
case ((long)262) : 
return rest_state_87___dsssl(rest_state_87_1146, CDR(args_412), dsssl_arg_196_413);
break;
default: 
return PROCEDURE_ENTRY(err_1143)(err_1143, where_1144, string1579___dsssl, formals_1145, BEOA);
}
}
}
 else {
{
obj_t e_111_246_432;
e_111_246_432 = CAR(args_412);
if(PAIRP(e_111_246_432)){
obj_t car_116_203_434;
obj_t cdr_117_2_435;
car_116_203_434 = CAR(e_111_246_432);
cdr_117_2_435 = CDR(e_111_246_432);
if(SYMBOLP(car_116_203_434)){
if(PAIRP(cdr_117_2_435)){
bool_t test_1499;
{
obj_t aux_1500;
aux_1500 = CDR(cdr_117_2_435);
test_1499 = (aux_1500==BNIL);
}
if(test_1499){
arg_450 = car_116_203_434;
initializer_451 = CAR(cdr_117_2_435);
one_optional_arg_34_522:
{
obj_t tmp_453;
tmp_453 = PROCEDURE_ENTRY(gensym___r4_symbols_6_4)(gensym___r4_symbols_6_4, symbol1573___dsssl, BEOA);
{
obj_t arg1180_454;
obj_t arg1181_455;
obj_t arg1182_456;
arg1180_454 = symbol1564___dsssl;
{
obj_t arg1188_462;
{
obj_t arg1192_466;
{
obj_t arg1197_471;
obj_t arg1199_472;
obj_t arg1200_473;
arg1197_471 = symbol1574___dsssl;
{
obj_t arg1207_480;
arg1207_480 = symbol1575___dsssl;
{
obj_t list1210_482;
{
obj_t arg1211_483;
arg1211_483 = MAKE_PAIR(BNIL, BNIL);
list1210_482 = MAKE_PAIR(dsssl_arg_196_413, arg1211_483);
}
arg1199_472 = cons__138___r4_pairs_and_lists_6_3(arg1207_480, list1210_482);
}
}
{
obj_t arg1214_485;
obj_t arg1216_486;
obj_t arg1219_487;
arg1214_485 = symbol1564___dsssl;
{
obj_t arg1228_494;
{
obj_t arg1234_498;
{
obj_t arg1241_503;
arg1241_503 = symbol1576___dsssl;
{
obj_t list1244_505;
{
obj_t arg1245_506;
arg1245_506 = MAKE_PAIR(BNIL, BNIL);
list1244_505 = MAKE_PAIR(dsssl_arg_196_413, arg1245_506);
}
arg1234_498 = cons__138___r4_pairs_and_lists_6_3(arg1241_503, list1244_505);
}
}
{
obj_t list1236_500;
{
obj_t arg1238_501;
arg1238_501 = MAKE_PAIR(BNIL, BNIL);
list1236_500 = MAKE_PAIR(arg1234_498, arg1238_501);
}
arg1228_494 = cons__138___r4_pairs_and_lists_6_3(tmp_453, list1236_500);
}
}
{
obj_t list1232_496;
list1232_496 = MAKE_PAIR(BNIL, BNIL);
arg1216_486 = cons__138___r4_pairs_and_lists_6_3(arg1228_494, list1232_496);
}
}
{
obj_t arg1248_508;
obj_t arg1250_509;
arg1248_508 = symbol1577___dsssl;
{
obj_t arg1256_515;
arg1256_515 = symbol1578___dsssl;
{
obj_t list1258_517;
{
obj_t arg1259_518;
arg1259_518 = MAKE_PAIR(BNIL, BNIL);
list1258_517 = MAKE_PAIR(dsssl_arg_196_413, arg1259_518);
}
arg1250_509 = cons__138___r4_pairs_and_lists_6_3(arg1256_515, list1258_517);
}
}
{
obj_t list1252_511;
{
obj_t arg1253_512;
{
obj_t arg1254_513;
arg1254_513 = MAKE_PAIR(BNIL, BNIL);
arg1253_512 = MAKE_PAIR(arg1250_509, arg1254_513);
}
list1252_511 = MAKE_PAIR(dsssl_arg_196_413, arg1253_512);
}
arg1219_487 = cons__138___r4_pairs_and_lists_6_3(arg1248_508, list1252_511);
}
}
{
obj_t list1221_489;
{
obj_t arg1222_490;
{
obj_t arg1224_491;
{
obj_t arg1225_492;
arg1225_492 = MAKE_PAIR(BNIL, BNIL);
arg1224_491 = MAKE_PAIR(tmp_453, arg1225_492);
}
arg1222_490 = MAKE_PAIR(arg1219_487, arg1224_491);
}
list1221_489 = MAKE_PAIR(arg1216_486, arg1222_490);
}
arg1200_473 = cons__138___r4_pairs_and_lists_6_3(arg1214_485, list1221_489);
}
}
{
obj_t list1202_475;
{
obj_t arg1203_476;
{
obj_t arg1204_477;
{
obj_t arg1205_478;
arg1205_478 = MAKE_PAIR(BNIL, BNIL);
arg1204_477 = MAKE_PAIR(arg1200_473, arg1205_478);
}
arg1203_476 = MAKE_PAIR(initializer_451, arg1204_477);
}
list1202_475 = MAKE_PAIR(arg1199_472, arg1203_476);
}
arg1192_466 = cons__138___r4_pairs_and_lists_6_3(arg1197_471, list1202_475);
}
}
{
obj_t list1194_468;
{
obj_t arg1195_469;
arg1195_469 = MAKE_PAIR(BNIL, BNIL);
list1194_468 = MAKE_PAIR(arg1192_466, arg1195_469);
}
arg1188_462 = cons__138___r4_pairs_and_lists_6_3(arg_450, list1194_468);
}
}
{
obj_t list1190_464;
list1190_464 = MAKE_PAIR(BNIL, BNIL);
arg1181_455 = cons__138___r4_pairs_and_lists_6_3(arg1188_462, list1190_464);
}
}
arg1182_456 = optional_state_1562_79___dsssl(body_1147, rest_state_87_1146, formals_1145, where_1144, err_1143, CDR(args_412), dsssl_arg_196_413);
{
obj_t list1184_458;
{
obj_t arg1185_459;
{
obj_t arg1186_460;
arg1186_460 = MAKE_PAIR(BNIL, BNIL);
arg1185_459 = MAKE_PAIR(arg1182_456, arg1186_460);
}
list1184_458 = MAKE_PAIR(arg1181_455, arg1185_459);
}
return cons__138___r4_pairs_and_lists_6_3(arg1180_454, list1184_458);
}
}
}
}
 else {
if(SYMBOLP(e_111_246_432)){
obj_t initializer_1548;
obj_t arg_1547;
arg_1547 = e_111_246_432;
initializer_1548 = BFALSE;
initializer_451 = initializer_1548;
arg_450 = arg_1547;
goto one_optional_arg_34_522;
}
 else {
return PROCEDURE_ENTRY(err_1143)(err_1143, where_1144, string1579___dsssl, formals_1145, BEOA);
}
}
}
 else {
if(SYMBOLP(e_111_246_432)){
obj_t initializer_1554;
obj_t arg_1553;
arg_1553 = e_111_246_432;
initializer_1554 = BFALSE;
initializer_451 = initializer_1554;
arg_450 = arg_1553;
goto one_optional_arg_34_522;
}
 else {
return PROCEDURE_ENTRY(err_1143)(err_1143, where_1144, string1579___dsssl, formals_1145, BEOA);
}
}
}
 else {
if(SYMBOLP(e_111_246_432)){
obj_t initializer_1560;
obj_t arg_1559;
arg_1559 = e_111_246_432;
initializer_1560 = BFALSE;
initializer_451 = initializer_1560;
arg_450 = arg_1559;
goto one_optional_arg_34_522;
}
 else {
return PROCEDURE_ENTRY(err_1143)(err_1143, where_1144, string1579___dsssl, formals_1145, BEOA);
}
}
}
 else {
if(SYMBOLP(e_111_246_432)){
obj_t initializer_1566;
obj_t arg_1565;
arg_1565 = e_111_246_432;
initializer_1566 = BFALSE;
initializer_451 = initializer_1566;
arg_450 = arg_1565;
goto one_optional_arg_34_522;
}
 else {
return PROCEDURE_ENTRY(err_1143)(err_1143, where_1144, string1579___dsssl, formals_1145, BEOA);
}
}
}
}
}
 else {
return PROCEDURE_ENTRY(err_1143)(err_1143, where_1144, string1579___dsssl, formals_1145, BEOA);
}
}
}
}


/* dsssl-check-key-args! */obj_t dsssl_check_key_args__153___dsssl(obj_t dsssl_args_32_5, obj_t key_list_141_6)
{
if(NULLP(key_list_141_6)){
obj_t args_613;
args_613 = dsssl_args_32_5;
loop_614:
if(NULLP(args_613)){
return BTRUE;
}
 else {
bool_t test_1575;
if(PAIRP(args_613)){
bool_t test_1578;
{
obj_t aux_1579;
aux_1579 = CDR(args_613);
test_1578 = NULLP(aux_1579);
}
if(test_1578){
test_1575 = ((bool_t)1);
}
 else {
bool_t test_1582;
{
obj_t aux_1583;
aux_1583 = CAR(args_613);
test_1582 = KEYWORDP(aux_1583);
}
if(test_1582){
test_1575 = ((bool_t)0);
}
 else {
test_1575 = ((bool_t)1);
}
}
}
 else {
test_1575 = ((bool_t)1);
}
if(test_1575){
FAILURE(string1580___dsssl,string1581___dsssl,dsssl_args_32_5);}
 else {
{
obj_t args_1587;
{
obj_t aux_1588;
aux_1588 = CDR(args_613);
args_1587 = CDR(aux_1588);
}
args_613 = args_1587;
goto loop_614;
}
}
}
}
 else {
obj_t args_623;
args_623 = dsssl_args_32_5;
loop_624:
if(NULLP(args_623)){
return BTRUE;
}
 else {
bool_t test_1593;
if(PAIRP(args_623)){
bool_t test_1596;
{
obj_t aux_1597;
aux_1597 = CDR(args_623);
test_1596 = NULLP(aux_1597);
}
if(test_1596){
test_1593 = ((bool_t)1);
}
 else {
bool_t test_1600;
{
obj_t aux_1601;
aux_1601 = CAR(args_623);
test_1600 = KEYWORDP(aux_1601);
}
if(test_1600){
bool_t test_1604;
{
obj_t aux_1605;
aux_1605 = memq___r4_pairs_and_lists_6_3(CAR(args_623), key_list_141_6);
test_1604 = CBOOL(aux_1605);
}
if(test_1604){
test_1593 = ((bool_t)0);
}
 else {
test_1593 = ((bool_t)1);
}
}
 else {
test_1593 = ((bool_t)1);
}
}
}
 else {
test_1593 = ((bool_t)1);
}
if(test_1593){
FAILURE(string1580___dsssl,string1581___dsssl,dsssl_args_32_5);}
 else {
{
obj_t args_1610;
{
obj_t aux_1611;
aux_1611 = CDR(args_623);
args_1610 = CDR(aux_1611);
}
args_623 = args_1610;
goto loop_624;
}
}
}
}
}


/* _dsssl-check-key-args! */obj_t _dsssl_check_key_args__61___dsssl(obj_t env_1131, obj_t dsssl_args_32_1132, obj_t key_list_141_1133)
{
return dsssl_check_key_args__153___dsssl(dsssl_args_32_1132, key_list_141_1133);
}


/* dsssl-get-key-arg */obj_t dsssl_get_key_arg_157___dsssl(obj_t dsssl_args_32_7, obj_t keyword_8, obj_t initializer_9)
{
{
obj_t args_994;
args_994 = dsssl_args_32_7;
loop_993:
if(NULLP(args_994)){
return initializer_9;
}
 else {
bool_t test_1617;
{
obj_t aux_1618;
aux_1618 = CAR(args_994);
test_1617 = (aux_1618==keyword_8);
}
if(test_1617){
{
obj_t aux_1621;
aux_1621 = CDR(args_994);
return CAR(aux_1621);
}
}
 else {
{
obj_t args_1624;
{
obj_t aux_1625;
aux_1625 = CDR(args_994);
args_1624 = CDR(aux_1625);
}
args_994 = args_1624;
goto loop_993;
}
}
}
}
}


/* _dsssl-get-key-arg1560 */obj_t _dsssl_get_key_arg1560_49___dsssl(obj_t env_1134, obj_t dsssl_args_32_1135, obj_t keyword_1136, obj_t initializer_1137)
{
return dsssl_get_key_arg_157___dsssl(dsssl_args_32_1135, keyword_1136, initializer_1137);
}


/* id-sans-type */obj_t id_sans_type_130___dsssl(obj_t id_10)
{
{
obj_t string_641;
string_641 = SYMBOL_TO_STRING(id_10);
{
long len_642;
len_642 = STRING_LENGTH(string_641);
{
{
long walker_643;
walker_643 = ((long)0);
loop_644:
if((walker_643==len_642)){
return id_10;
}
 else {
bool_t test_1633;
{
bool_t test_1634;
{
unsigned char aux_1635;
aux_1635 = STRING_REF(string_641, walker_643);
test_1634 = (aux_1635==((unsigned char)':'));
}
if(test_1634){
bool_t test_1638;
{
long aux_1639;
aux_1639 = (len_642-((long)1));
test_1638 = (walker_643<aux_1639);
}
if(test_1638){
unsigned char aux_1642;
{
long aux_1643;
aux_1643 = (walker_643+((long)1));
aux_1642 = STRING_REF(string_641, aux_1643);
}
test_1633 = (aux_1642==((unsigned char)':'));
}
 else {
test_1633 = ((bool_t)0);
}
}
 else {
test_1633 = ((bool_t)0);
}
}
if(test_1633){
{
obj_t arg1372_647;
arg1372_647 = c_substring(string_641, ((long)0), walker_643);
{
char * aux_1648;
aux_1648 = BSTRING_TO_STRING(arg1372_647);
return string_to_symbol(aux_1648);
}
}
}
 else {
{
long walker_1651;
walker_1651 = (walker_643+((long)1));
walker_643 = walker_1651;
goto loop_644;
}
}
}
}
}
}
}
}


/* dsssl-formals->scheme-formals */obj_t dsssl_formals__scheme_formals_201___dsssl(obj_t formals_11, obj_t err_12)
{
return loop___dsssl(formals_11, err_12, formals_11, ((bool_t)0));
}


/* loop */obj_t loop___dsssl(obj_t formals_1142, obj_t err_1141, obj_t args_658, bool_t dsssl_659)
{
loop___dsssl:
{
obj_t obj_680;
if(NULLP(args_658)){
return BNIL;
}
 else {
if(PAIRP(args_658)){
bool_t test_1658;
{
obj_t aux_1659;
aux_1659 = CAR(args_658);
test_1658 = SYMBOLP(aux_1659);
}
if(test_1658){
if(dsssl_659){
return id_sans_type_130___dsssl(CAR(args_658));
}
 else {
{
obj_t arg1388_665;
obj_t arg1389_666;
arg1388_665 = id_sans_type_130___dsssl(CAR(args_658));
arg1389_666 = loop___dsssl(formals_1142, err_1141, CDR(args_658), ((bool_t)0));
return MAKE_PAIR(arg1388_665, arg1389_666);
}
}
}
 else {
{
bool_t test_1670;
{
obj_t aux_1671;
aux_1671 = memq___r4_pairs_and_lists_6_3(CAR(args_658), list1582___dsssl);
test_1670 = CBOOL(aux_1671);
}
if(test_1670){
{
bool_t dsssl_1677;
obj_t args_1675;
args_1675 = CDR(args_658);
dsssl_1677 = ((bool_t)1);
dsssl_659 = dsssl_1677;
args_658 = args_1675;
goto loop___dsssl;
}
}
 else {
if(dsssl_659){
bool_t test_1679;
obj_680 = CAR(args_658);
if(PAIRP(obj_680)){
obj_t cdr_202_127_686;
cdr_202_127_686 = CDR(obj_680);
if(PAIRP(cdr_202_127_686)){
bool_t test_1685;
{
obj_t aux_1686;
aux_1686 = CDR(cdr_202_127_686);
test_1685 = (aux_1686==BNIL);
}
if(test_1685){
test_1679 = ((bool_t)1);
}
 else {
test_1679 = ((bool_t)0);
}
}
 else {
test_1679 = ((bool_t)0);
}
}
 else {
test_1679 = ((bool_t)0);
}
if(test_1679){
{
obj_t aux_1690;
{
obj_t aux_1691;
aux_1691 = CAR(args_658);
aux_1690 = CAR(aux_1691);
}
return id_sans_type_130___dsssl(aux_1690);
}
}
 else {
return PROCEDURE_ENTRY(err_1141)(err_1141, string1583___dsssl, string1584___dsssl, formals_1142, BEOA);
}
}
 else {
return PROCEDURE_ENTRY(err_1141)(err_1141, string1583___dsssl, string1585___dsssl, formals_1142, BEOA);
}
}
}
}
}
 else {
if(dsssl_659){
return PROCEDURE_ENTRY(err_1141)(err_1141, string1586___dsssl, string1587___dsssl, formals_1142, BEOA);
}
 else {
if(SYMBOLP(args_658)){
return id_sans_type_130___dsssl(args_658);
}
 else {
return PROCEDURE_ENTRY(err_1141)(err_1141, string1583___dsssl, string1585___dsssl, formals_1142, BEOA);
}
}
}
}
}
}


/* _dsssl-formals->scheme-formals1561 */obj_t _dsssl_formals__scheme_formals1561_222___dsssl(obj_t env_1138, obj_t formals_1139, obj_t err_1140)
{
return dsssl_formals__scheme_formals_201___dsssl(formals_1139, err_1140);
}


/* symbol->keyword */obj_t symbol__keyword_174___dsssl(obj_t symbol_13)
{
{
obj_t arg1411_1061;
{
obj_t arg1413_1062;
arg1413_1062 = SYMBOL_TO_STRING(symbol_13);
arg1411_1061 = string_append(arg1413_1062, string1568___dsssl);
}
{
char * aux_1710;
aux_1710 = BSTRING_TO_STRING(arg1411_1061);
return string_to_keyword(aux_1710);
}
}
}


/* imported-modules-init */obj_t imported_modules_init_94___dsssl()
{
return module_initialization_70___error(((long)0), "__DSSSL");
}

