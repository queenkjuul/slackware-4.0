/*===========================================================================*/
/*   (Cfa/specialize.scm)                                                    */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct isfun
  {
     struct node *original_body_40;
     obj_t recursive_calls_44;
  }
     *isfun_t;

typedef struct specialized_global_131
  {
     obj_t fix;
  }
                      *specialized_global_131_t;


extern obj_t find_global_223_ast_env(obj_t, obj_t);
static obj_t method_init_76_cfa_specialize();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
extern obj_t specialize__184_cfa_specialize(obj_t);
extern obj_t _optim__89_engine_param;
static obj_t add_specialized_type__70_cfa_specialize(type_t);
static obj_t _allocate_specialized_global_95_cfa_specialize(obj_t);
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
static obj_t _object__struct2121_147___object(obj_t, obj_t);
static bool_t show_specialize_223_cfa_specialize();
extern obj_t box_ref_242_ast_node;
extern obj_t sequence_ast_node;
extern obj_t let_var_6_ast_node;
static obj_t _specialized_types__137_cfa_specialize = BUNSPEC;
extern obj_t var_ast_node;
static obj_t patch__227_cfa_specialize(node_t);
extern obj_t warning___error(obj_t);
extern obj_t closure_ast_node;
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t global_ast_var;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
static obj_t patch___72_cfa_specialize(obj_t);
extern obj_t verbose_tools_speek(obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
static obj_t _patch__default1515_1_cfa_specialize(obj_t, obj_t);
extern obj_t module_initialization_70_cfa_specialize(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_coerce_typeof(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_inline_inline(long, char *);
extern obj_t module_initialization_70_inline_walk(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
static obj_t install_specialize__168_cfa_specialize(obj_t, obj_t, obj_t);
static node_t specialize_app__163_cfa_specialize(app_t);
extern long class_num_218___object(obj_t);
static obj_t _patch_2122_210_cfa_specialize(obj_t, obj_t);
static bool_t uninstall_specializes__251_cfa_specialize();
extern obj_t let_fun_218_ast_node;
static obj_t _struct_object__object2119_207___object(obj_t, obj_t, obj_t);
static obj_t imported_modules_init_94_cfa_specialize();
static bool_t specialize_optimization__103_cfa_specialize();
extern obj_t app_ly_162_ast_node;
static global_t allocate_specialized_global_107_cfa_specialize();
extern obj_t add_generic__110___object(obj_t, obj_t);
static obj_t struct_object__object_specialized_global_181_cfa_specialize(obj_t, obj_t, obj_t);
static obj_t patch_fun__141_cfa_specialize(obj_t);
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cfa_specialize();
static obj_t specialized_global_131_cfa_specialize = BUNSPEC;
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t atom_ast_node;
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern obj_t cast_ast_node;
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_cfa_specialize();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t object__struct_specialized_global_35_cfa_specialize(obj_t, obj_t);
extern obj_t sfun_ast_var;
extern obj_t setq_ast_node;
extern obj_t box_set__221_ast_node;
extern type_t typeof_coerce_typeof(node_t);
static bool_t patch_tree__164_cfa_specialize(obj_t);
static obj_t patch__default1515_36_cfa_specialize(node_t);
extern obj_t shape_tools_shape(obj_t);
static obj_t _specialize__50_cfa_specialize = BUNSPEC;
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t object_init_111_cfa_specialize();
static obj_t install_specialized_type__228_cfa_specialize(type_t);
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t read___reader(obj_t);
extern obj_t _lib_mode__85_engine_param;
extern obj_t object__struct_50___object(object_t);
static obj_t require_initialization_114_cfa_specialize = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t _specialize__238_cfa_specialize(obj_t, obj_t);
extern obj_t class_super_145___object(obj_t);
static obj_t cnst_init_137_cfa_specialize();
static obj_t __cnst[60];

DEFINE_STATIC_PROCEDURE(allocate_specialized_global_env_23_cfa_specialize, _allocate_specialized_global_95_cfa_specialize2145, _allocate_specialized_global_95_cfa_specialize, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc2134_cfa_specialize, struct_object__object_specialized_global_181_cfa_specialize2146, struct_object__object_specialized_global_181_cfa_specialize, 0L, 2);
DEFINE_STATIC_PROCEDURE(proc2133_cfa_specialize, object__struct_specialized_global_35_cfa_specialize2147, object__struct_specialized_global_35_cfa_specialize, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_PROCEDURE(specialize__env_161_cfa_specialize, _specialize__238_cfa_specialize2148, _specialize__238_cfa_specialize, 0L, 1);
DEFINE_STATIC_GENERIC(patch__env_129_cfa_specialize, _patch_2122_210_cfa_specialize2149, _patch_2122_210_cfa_specialize, 0L, 1);
DEFINE_STATIC_PROCEDURE(patch__default1515_env_174_cfa_specialize, _patch__default1515_1_cfa_specialize2150, _patch__default1515_1_cfa_specialize, 0L, 1);
DEFINE_STRING(string2138_cfa_specialize, string2138_cfa_specialize2151, "PATCH!-DEFAULT1515 SPECIALIZED-GLOBAL DONE SQRTFL SQRT ACOSFL ACOS ASINFL ASIN TANFL TAN COSFL COS SINFL SIN EXPFL EXP LOGFL LOG ABSFL ABSFX ABS /FL 2/ *FL *FX 2* -FL -FX 2- +FL +FX 2+ NEGATIVEFL? NEGATIVEFX? NEGATIVE? POSITIVEFL? POSITIVEFX? POSITIVE? ZEROFL? ZEROFX? ZERO? >=FL >=FX 2>= <=FL <=FX 2<= >FL >FX 2> <FL <FX 2< __R4_NUMBERS_6_5_FLONUM =FL __R4_NUMBERS_6_5_FIXNUM =FX __R4_NUMBERS_6_5 2= ", 401);
DEFINE_STRING(string2137_cfa_specialize, string2137_cfa_specialize2152, "No method for this object", 25);
DEFINE_STRING(string2136_cfa_specialize, string2136_cfa_specialize2153, "Unexpected closure", 18);
DEFINE_STRING(string2135_cfa_specialize, string2135_cfa_specialize2154, "patch!", 6);
DEFINE_STRING(string2132_cfa_specialize, string2132_cfa_specialize2155, "Can't fund global", 17);
DEFINE_STRING(string2131_cfa_specialize, string2131_cfa_specialize2156, "install-specialize!", 19);
DEFINE_STRING(string2129_cfa_specialize, string2129_cfa_specialize2157, " -- ", 4);
DEFINE_STRING(string2130_cfa_specialize, string2130_cfa_specialize2158, "Can't find global", 17);
DEFINE_STRING(string2128_cfa_specialize, string2128_cfa_specialize2159, "Unspecialized type", 18);
DEFINE_STRING(string2127_cfa_specialize, string2127_cfa_specialize2160, "add-specialized-type!", 21);
DEFINE_STRING(string2126_cfa_specialize, string2126_cfa_specialize2161, "        (-> ", 12);
DEFINE_STRING(string2125_cfa_specialize, string2125_cfa_specialize2162, ": ", 2);
DEFINE_STRING(string2124_cfa_specialize, string2124_cfa_specialize2163, ")\n", 2);
DEFINE_STRING(string2123_cfa_specialize, string2123_cfa_specialize2164, "   . specializing", 17);
extern obj_t object__struct_env_210___object;


/* module-initialization */ obj_t 
module_initialization_70_cfa_specialize(long checksum_2010, char *from_2011)
{
   if (CBOOL(require_initialization_114_cfa_specialize))
     {
	require_initialization_114_cfa_specialize = BBOOL(((bool_t) 0));
	library_modules_init_112_cfa_specialize();
	cnst_init_137_cfa_specialize();
	imported_modules_init_94_cfa_specialize();
	object_init_111_cfa_specialize();
	method_init_76_cfa_specialize();
	toplevel_init_63_cfa_specialize();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cfa_specialize()
{
   module_initialization_70___object(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70___error(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70___reader(((long) 0), "CFA_SPECIALIZE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cfa_specialize()
{
   {
      obj_t cnst_port_138_2002;
      cnst_port_138_2002 = open_input_string(string2138_cfa_specialize);
      {
	 long i_2003;
	 i_2003 = ((long) 59);
       loop_2004:
	 {
	    bool_t test2139_2005;
	    test2139_2005 = (i_2003 == ((long) -1));
	    if (test2139_2005)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg2140_2006;
		    {
		       obj_t list2141_2007;
		       {
			  obj_t arg2143_2008;
			  arg2143_2008 = BNIL;
			  list2141_2007 = MAKE_PAIR(cnst_port_138_2002, arg2143_2008);
		       }
		       arg2140_2006 = read___reader(list2141_2007);
		    }
		    CNST_TABLE_SET(i_2003, arg2140_2006);
		 }
		 {
		    int aux_2009;
		    {
		       long aux_2031;
		       aux_2031 = (i_2003 - ((long) 1));
		       aux_2009 = (int) (aux_2031);
		    }
		    {
		       long i_2034;
		       i_2034 = (long) (aux_2009);
		       i_2003 = i_2034;
		       goto loop_2004;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cfa_specialize()
{
   _specialize__50_cfa_specialize = BNIL;
   _specialized_types__137_cfa_specialize = BNIL;
   return BUNSPEC;
}


/* specialize-optimization? */ bool_t 
specialize_optimization__103_cfa_specialize()
{
   {
      bool_t _andtest_1481_841;
      {
	 long n1_1677;
	 n1_1677 = (long) CINT(_optim__89_engine_param);
	 _andtest_1481_841 = (n1_1677 >= ((long) 1));
      }
      if (_andtest_1481_841)
	{
	   if (CBOOL(_lib_mode__85_engine_param))
	     {
		return ((bool_t) 0);
	     }
	   else
	     {
		return ((bool_t) 1);
	     }
	}
      else
	{
	   return ((bool_t) 0);
	}
   }
}


/* show-specialize */ bool_t 
show_specialize_223_cfa_specialize()
{
   {
      obj_t list1549_842;
      {
	 obj_t arg1552_844;
	 {
	    obj_t aux_2041;
	    aux_2041 = BCHAR(((unsigned char) '\n'));
	    arg1552_844 = MAKE_PAIR(aux_2041, BNIL);
	 }
	 list1549_842 = MAKE_PAIR(string2123_cfa_specialize, arg1552_844);
      }
      verbose_tools_speek(BINT(((long) 1)), list1549_842);
   }
   {
      obj_t l1482_846;
      l1482_846 = _specialized_types__137_cfa_specialize;
    lname1483_847:
      if (PAIRP(l1482_846))
	{
	   {
	      obj_t type_num_186_849;
	      type_num_186_849 = CAR(l1482_846);
	      {
		 bool_t test_2050;
		 {
		    long aux_2051;
		    {
		       obj_t aux_2052;
		       aux_2052 = CDR(type_num_186_849);
		       aux_2051 = (long) CINT(aux_2052);
		    }
		    test_2050 = (aux_2051 > ((long) 0));
		 }
		 if (test_2050)
		   {
		      obj_t arg1558_853;
		      obj_t arg1560_855;
		      arg1558_853 = shape_tools_shape(CAR(type_num_186_849));
		      arg1560_855 = CDR(type_num_186_849);
		      {
			 obj_t list1562_857;
			 {
			    obj_t arg1563_858;
			    {
			       obj_t arg1564_859;
			       {
				  obj_t arg1565_860;
				  {
				     obj_t arg1566_861;
				     arg1566_861 = MAKE_PAIR(string2124_cfa_specialize, BNIL);
				     arg1565_860 = MAKE_PAIR(arg1560_855, arg1566_861);
				  }
				  arg1564_859 = MAKE_PAIR(string2125_cfa_specialize, arg1565_860);
			       }
			       arg1563_858 = MAKE_PAIR(arg1558_853, arg1564_859);
			    }
			    list1562_857 = MAKE_PAIR(string2126_cfa_specialize, arg1563_858);
			 }
			 verbose_tools_speek(BINT(((long) 2)), list1562_857);
		      }
		   }
		 else
		   {
		      BUNSPEC;
		   }
	      }
	   }
	   {
	      obj_t l1482_2066;
	      l1482_2066 = CDR(l1482_846);
	      l1482_846 = l1482_2066;
	      goto lname1483_847;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* install-specialized-type! */ obj_t 
install_specialized_type__228_cfa_specialize(type_t type_1)
{
   {
      bool_t test1574_867;
      {
	 obj_t arg1578_869;
	 arg1578_869 = assq___r4_pairs_and_lists_6_3((obj_t) (type_1), _specialized_types__137_cfa_specialize);
	 test1574_867 = PAIRP(arg1578_869);
      }
      if (test1574_867)
	{
	   return BUNSPEC;
	}
      else
	{
	   obj_t arg1575_868;
	   {
	      obj_t aux_2074;
	      obj_t aux_2072;
	      aux_2074 = BINT(((long) 0));
	      aux_2072 = (obj_t) (type_1);
	      arg1575_868 = MAKE_PAIR(aux_2072, aux_2074);
	   }
	   {
	      obj_t obj2_1691;
	      obj2_1691 = _specialized_types__137_cfa_specialize;
	      return (_specialized_types__137_cfa_specialize = MAKE_PAIR(arg1575_868, obj2_1691),
		 BUNSPEC);
	   }
	}
   }
}


/* add-specialized-type! */ obj_t 
add_specialized_type__70_cfa_specialize(type_t type_2)
{
   {
      obj_t cell_870;
      cell_870 = assq___r4_pairs_and_lists_6_3((obj_t) (type_2), _specialized_types__137_cfa_specialize);
      if (PAIRP(cell_870))
	{
	   obj_t aux_2082;
	   {
	      long aux_2083;
	      {
		 long aux_2084;
		 {
		    obj_t aux_2085;
		    aux_2085 = CDR(cell_870);
		    aux_2084 = (long) CINT(aux_2085);
		 }
		 aux_2083 = (((long) 1) + aux_2084);
	      }
	      aux_2082 = BINT(aux_2083);
	   }
	   return SET_CDR(cell_870, aux_2082);
	}
      else
	{
	   obj_t arg1585_877;
	   arg1585_877 = shape_tools_shape((obj_t) (type_2));
	   return internal_error_43_tools_error(string2127_cfa_specialize, string2128_cfa_specialize, arg1585_877);
	}
   }
}


/* install-specialize! */ obj_t 
install_specialize__168_cfa_specialize(obj_t gen_id_29_3, obj_t gen_mod_247_4, obj_t fixes_5)
{
   {
      obj_t generic_878;
      {
	 obj_t list1640_926;
	 list1640_926 = MAKE_PAIR(gen_mod_247_4, BNIL);
	 generic_878 = find_global_223_ast_env(gen_id_29_3, list1640_926);
      }
      {
	 bool_t test1586_879;
	 test1586_879 = is_a__118___object(generic_878, global_ast_var);
	 if (test1586_879)
	   {
	      obj_t fixes_880;
	      obj_t res_881;
	      fixes_880 = fixes_5;
	      res_881 = BNIL;
	    loop_882:
	      if (NULLP(fixes_880))
		{
		   {
		      specialized_global_131_t obj1484_885;
		      obj1484_885 = ((specialized_global_131_t) (generic_878));
		      {
			 specialized_global_131_t arg1589_886;
			 {
			    specialized_global_131_t res2114_1703;
			    {
			       specialized_global_131_t new1456_1701;
			       new1456_1701 = ((specialized_global_131_t) BREF(GC_MALLOC(sizeof(struct specialized_global_131))));
			       ((((specialized_global_131_t) CREF(new1456_1701))->fix) = ((obj_t) res_881), BUNSPEC);
			       res2114_1703 = new1456_1701;
			    }
			    arg1589_886 = res2114_1703;
			 }
			 {
			    obj_t aux_2105;
			    object_t aux_2103;
			    aux_2105 = (obj_t) (arg1589_886);
			    aux_2103 = (object_t) (obj1484_885);
			    OBJECT_WIDENING_SET(aux_2103, aux_2105);
			 }
		      }
		      {
			 long arg1593_888;
			 arg1593_888 = class_num_218___object(specialized_global_131_cfa_specialize);
			 {
			    obj_t obj_1704;
			    obj_1704 = (obj_t) (obj1484_885);
			    (((obj_t) CREF(obj_1704))->header = MAKE_HEADER(arg1593_888, 0), BUNSPEC);
			 }
		      }
		      obj1484_885;
		   }
		   {
		      obj_t obj2_1707;
		      obj2_1707 = _specialize__50_cfa_specialize;
		      return (_specialize__50_cfa_specialize = MAKE_PAIR(generic_878, obj2_1707),
			 BUNSPEC);
		   }
		}
	      else
		{
		   obj_t id_889;
		   id_889 = CAR(fixes_880);
		   {
		      obj_t mod_890;
		      {
			 obj_t aux_2113;
			 aux_2113 = CDR(fixes_880);
			 mod_890 = CAR(aux_2113);
		      }
		      {
			 obj_t global_891;
			 {
			    obj_t list1624_915;
			    list1624_915 = MAKE_PAIR(mod_890, BNIL);
			    global_891 = find_global_223_ast_env(id_889, list1624_915);
			 }
			 {
			    {
			       bool_t test1594_892;
			       {
				  bool_t test1619_910;
				  test1619_910 = is_a__118___object(global_891, global_ast_var);
				  if (test1619_910)
				    {
				       bool_t test1620_911;
				       {
					  obj_t aux_2120;
					  {
					     value_t aux_2121;
					     {
						global_t obj_1714;
						obj_1714 = (global_t) (global_891);
						aux_2121 = (((global_t) CREF(obj_1714))->value);
					     }
					     aux_2120 = (obj_t) (aux_2121);
					  }
					  test1620_911 = is_a__118___object(aux_2120, sfun_ast_var);
				       }
				       if (test1620_911)
					 {
					    obj_t aux_2127;
					    {
					       sfun_t obj_1717;
					       {
						  value_t aux_2128;
						  {
						     global_t obj_1716;
						     obj_1716 = (global_t) (global_891);
						     aux_2128 = (((global_t) CREF(obj_1716))->value);
						  }
						  obj_1717 = (sfun_t) (aux_2128);
					       }
					       aux_2127 = (((sfun_t) CREF(obj_1717))->args);
					    }
					    test1594_892 = PAIRP(aux_2127);
					 }
				       else
					 {
					    test1594_892 = ((bool_t) 0);
					 }
				    }
				  else
				    {
				       test1594_892 = ((bool_t) 0);
				    }
			       }
			       if (test1594_892)
				 {
				    type_t type_893;
				    {
				       local_t obj_1722;
				       {
					  obj_t aux_2135;
					  {
					     obj_t aux_2136;
					     {
						sfun_t obj_1720;
						{
						   value_t aux_2137;
						   {
						      global_t obj_1719;
						      obj_1719 = (global_t) (global_891);
						      aux_2137 = (((global_t) CREF(obj_1719))->value);
						   }
						   obj_1720 = (sfun_t) (aux_2137);
						}
						aux_2136 = (((sfun_t) CREF(obj_1720))->args);
					     }
					     aux_2135 = CAR(aux_2136);
					  }
					  obj_1722 = (local_t) (aux_2135);
				       }
				       type_893 = (((local_t) CREF(obj_1722))->type);
				    }
				    install_specialized_type__228_cfa_specialize(type_893);
				    {
				       obj_t arg1595_894;
				       obj_t arg1598_895;
				       {
					  obj_t aux_2146;
					  aux_2146 = CDR(fixes_880);
					  arg1595_894 = CDR(aux_2146);
				       }
				       {
					  obj_t arg1600_896;
					  {
					     obj_t aux_2149;
					     aux_2149 = (obj_t) (type_893);
					     arg1600_896 = MAKE_PAIR(aux_2149, global_891);
					  }
					  arg1598_895 = MAKE_PAIR(arg1600_896, res_881);
				       }
				       {
					  obj_t res_2154;
					  obj_t fixes_2153;
					  fixes_2153 = arg1595_894;
					  res_2154 = arg1598_895;
					  res_881 = res_2154;
					  fixes_880 = fixes_2153;
					  goto loop_882;
				       }
				    }
				 }
			       else
				 {
				    {
				       obj_t arg1609_903;
				       arg1609_903 = MAKE_PAIR(id_889, mod_890);
				       {
					  obj_t list1610_904;
					  {
					     obj_t arg1612_905;
					     {
						obj_t arg1613_906;
						{
						   obj_t arg1615_907;
						   arg1615_907 = MAKE_PAIR(arg1609_903, BNIL);
						   arg1613_906 = MAKE_PAIR(string2129_cfa_specialize, arg1615_907);
						}
						arg1612_905 = MAKE_PAIR(string2130_cfa_specialize, arg1613_906);
					     }
					     list1610_904 = MAKE_PAIR(string2131_cfa_specialize, arg1612_905);
					  }
					  warning___error(list1610_904);
				       }
				    }
				    {
				       obj_t fixes_2161;
				       {
					  obj_t aux_2162;
					  aux_2162 = CDR(fixes_880);
					  fixes_2161 = CDR(aux_2162);
				       }
				       fixes_880 = fixes_2161;
				       goto loop_882;
				    }
				 }
			    }
			 }
		      }
		   }
		}
	   }
	 else
	   {
	      obj_t arg1632_920;
	      arg1632_920 = MAKE_PAIR(gen_id_29_3, gen_mod_247_4);
	      {
		 obj_t list1633_921;
		 {
		    obj_t arg1634_922;
		    {
		       obj_t arg1636_923;
		       {
			  obj_t arg1638_924;
			  arg1638_924 = MAKE_PAIR(arg1632_920, BNIL);
			  arg1636_923 = MAKE_PAIR(string2129_cfa_specialize, arg1638_924);
		       }
		       arg1634_922 = MAKE_PAIR(string2132_cfa_specialize, arg1636_923);
		    }
		    list1633_921 = MAKE_PAIR(string2131_cfa_specialize, arg1634_922);
		 }
		 return warning___error(list1633_921);
	      }
	   }
      }
   }
}


/* uninstall-specializes! */ bool_t 
uninstall_specializes__251_cfa_specialize()
{
   _specialized_types__137_cfa_specialize = BNIL;
   {
      obj_t l1485_928;
      l1485_928 = _specialize__50_cfa_specialize;
    lname1486_929:
      if (PAIRP(l1485_928))
	{
	   {
	      obj_t o1487_931;
	      o1487_931 = CAR(l1485_928);
	      {
		 long arg1645_932;
		 {
		    obj_t arg1646_933;
		    {
		       obj_t arg1647_934;
		       {
			  object_t object_1741;
			  object_1741 = (object_t) (o1487_931);
			  {
			     long arg1180_1742;
			     {
				long arg1181_1743;
				long arg1182_1744;
				arg1181_1743 = TYPE(object_1741);
				arg1182_1744 = OBJECT_TYPE;
				arg1180_1742 = (arg1181_1743 - arg1182_1744);
			     }
			     {
				obj_t vector_1748;
				vector_1748 = _classes__134___object;
				arg1647_934 = VECTOR_REF(vector_1748, arg1180_1742);
			     }
			  }
		       }
		       arg1646_933 = class_super_145___object(arg1647_934);
		    }
		    arg1645_932 = class_num_218___object(arg1646_933);
		 }
		 (((obj_t) CREF(o1487_931))->header = MAKE_HEADER(arg1645_932, 0), BUNSPEC);
	      }
	      {
		 object_t aux_2182;
		 aux_2182 = (object_t) (o1487_931);
		 OBJECT_WIDENING_SET(aux_2182, BFALSE);
	      }
	      o1487_931;
	   }
	   {
	      obj_t l1485_2185;
	      l1485_2185 = CDR(l1485_928);
	      l1485_928 = l1485_2185;
	      goto lname1486_929;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* specialize! */ obj_t 
specialize__184_cfa_specialize(obj_t globals_6)
{
   if (specialize_optimization__103_cfa_specialize())
     {
	{
	   obj_t arg1650_937;
	   obj_t arg1652_938;
	   obj_t arg1653_939;
	   obj_t arg1654_940;
	   obj_t arg1655_941;
	   arg1650_937 = CNST_TABLE_REF(((long) 0));
	   arg1652_938 = CNST_TABLE_REF(((long) 1));
	   arg1653_939 = CNST_TABLE_REF(((long) 2));
	   arg1654_940 = CNST_TABLE_REF(((long) 3));
	   arg1655_941 = CNST_TABLE_REF(((long) 4));
	   {
	      obj_t list1657_943;
	      {
		 obj_t arg1658_944;
		 {
		    obj_t arg1659_945;
		    {
		       obj_t arg1661_946;
		       {
			  obj_t aux_2194;
			  aux_2194 = CNST_TABLE_REF(((long) 5));
			  arg1661_946 = MAKE_PAIR(aux_2194, BNIL);
		       }
		       arg1659_945 = MAKE_PAIR(arg1655_941, arg1661_946);
		    }
		    arg1658_944 = MAKE_PAIR(arg1654_940, arg1659_945);
		 }
		 list1657_943 = MAKE_PAIR(arg1653_939, arg1658_944);
	      }
	      install_specialize__168_cfa_specialize(arg1650_937, arg1652_938, list1657_943);
	   }
	}
	{
	   obj_t arg1665_948;
	   obj_t arg1666_949;
	   obj_t arg1667_950;
	   obj_t arg1668_951;
	   obj_t arg1669_952;
	   arg1665_948 = CNST_TABLE_REF(((long) 6));
	   arg1666_949 = CNST_TABLE_REF(((long) 1));
	   arg1667_950 = CNST_TABLE_REF(((long) 7));
	   arg1668_951 = CNST_TABLE_REF(((long) 3));
	   arg1669_952 = CNST_TABLE_REF(((long) 8));
	   {
	      obj_t list1671_954;
	      {
		 obj_t arg1672_955;
		 {
		    obj_t arg1673_956;
		    {
		       obj_t arg1675_957;
		       {
			  obj_t aux_2206;
			  aux_2206 = CNST_TABLE_REF(((long) 5));
			  arg1675_957 = MAKE_PAIR(aux_2206, BNIL);
		       }
		       arg1673_956 = MAKE_PAIR(arg1669_952, arg1675_957);
		    }
		    arg1672_955 = MAKE_PAIR(arg1668_951, arg1673_956);
		 }
		 list1671_954 = MAKE_PAIR(arg1667_950, arg1672_955);
	      }
	      install_specialize__168_cfa_specialize(arg1665_948, arg1666_949, list1671_954);
	   }
	}
	{
	   obj_t arg1677_959;
	   obj_t arg1678_960;
	   obj_t arg1679_961;
	   obj_t arg1680_962;
	   obj_t arg1681_963;
	   arg1677_959 = CNST_TABLE_REF(((long) 9));
	   arg1678_960 = CNST_TABLE_REF(((long) 1));
	   arg1679_961 = CNST_TABLE_REF(((long) 10));
	   arg1680_962 = CNST_TABLE_REF(((long) 3));
	   arg1681_963 = CNST_TABLE_REF(((long) 11));
	   {
	      obj_t list1683_965;
	      {
		 obj_t arg1684_966;
		 {
		    obj_t arg1685_967;
		    {
		       obj_t arg1686_968;
		       {
			  obj_t aux_2218;
			  aux_2218 = CNST_TABLE_REF(((long) 5));
			  arg1686_968 = MAKE_PAIR(aux_2218, BNIL);
		       }
		       arg1685_967 = MAKE_PAIR(arg1681_963, arg1686_968);
		    }
		    arg1684_966 = MAKE_PAIR(arg1680_962, arg1685_967);
		 }
		 list1683_965 = MAKE_PAIR(arg1679_961, arg1684_966);
	      }
	      install_specialize__168_cfa_specialize(arg1677_959, arg1678_960, list1683_965);
	   }
	}
	{
	   obj_t arg1689_970;
	   obj_t arg1691_971;
	   obj_t arg1692_972;
	   obj_t arg1693_973;
	   obj_t arg1694_974;
	   arg1689_970 = CNST_TABLE_REF(((long) 12));
	   arg1691_971 = CNST_TABLE_REF(((long) 1));
	   arg1692_972 = CNST_TABLE_REF(((long) 13));
	   arg1693_973 = CNST_TABLE_REF(((long) 3));
	   arg1694_974 = CNST_TABLE_REF(((long) 14));
	   {
	      obj_t list1696_976;
	      {
		 obj_t arg1697_977;
		 {
		    obj_t arg1698_978;
		    {
		       obj_t arg1699_979;
		       {
			  obj_t aux_2230;
			  aux_2230 = CNST_TABLE_REF(((long) 5));
			  arg1699_979 = MAKE_PAIR(aux_2230, BNIL);
		       }
		       arg1698_978 = MAKE_PAIR(arg1694_974, arg1699_979);
		    }
		    arg1697_977 = MAKE_PAIR(arg1693_973, arg1698_978);
		 }
		 list1696_976 = MAKE_PAIR(arg1692_972, arg1697_977);
	      }
	      install_specialize__168_cfa_specialize(arg1689_970, arg1691_971, list1696_976);
	   }
	}
	{
	   obj_t arg1701_981;
	   obj_t arg1702_982;
	   obj_t arg1703_983;
	   obj_t arg1704_984;
	   obj_t arg1705_985;
	   arg1701_981 = CNST_TABLE_REF(((long) 15));
	   arg1702_982 = CNST_TABLE_REF(((long) 1));
	   arg1703_983 = CNST_TABLE_REF(((long) 16));
	   arg1704_984 = CNST_TABLE_REF(((long) 3));
	   arg1705_985 = CNST_TABLE_REF(((long) 17));
	   {
	      obj_t list1707_987;
	      {
		 obj_t arg1708_988;
		 {
		    obj_t arg1709_989;
		    {
		       obj_t arg1710_990;
		       {
			  obj_t aux_2242;
			  aux_2242 = CNST_TABLE_REF(((long) 5));
			  arg1710_990 = MAKE_PAIR(aux_2242, BNIL);
		       }
		       arg1709_989 = MAKE_PAIR(arg1705_985, arg1710_990);
		    }
		    arg1708_988 = MAKE_PAIR(arg1704_984, arg1709_989);
		 }
		 list1707_987 = MAKE_PAIR(arg1703_983, arg1708_988);
	      }
	      install_specialize__168_cfa_specialize(arg1701_981, arg1702_982, list1707_987);
	   }
	}
	{
	   obj_t arg1712_992;
	   obj_t arg1713_993;
	   obj_t arg1714_994;
	   obj_t arg1716_995;
	   obj_t arg1717_996;
	   arg1712_992 = CNST_TABLE_REF(((long) 18));
	   arg1713_993 = CNST_TABLE_REF(((long) 1));
	   arg1714_994 = CNST_TABLE_REF(((long) 19));
	   arg1716_995 = CNST_TABLE_REF(((long) 3));
	   arg1717_996 = CNST_TABLE_REF(((long) 20));
	   {
	      obj_t list1719_998;
	      {
		 obj_t arg1720_999;
		 {
		    obj_t arg1721_1000;
		    {
		       obj_t arg1722_1001;
		       {
			  obj_t aux_2254;
			  aux_2254 = CNST_TABLE_REF(((long) 5));
			  arg1722_1001 = MAKE_PAIR(aux_2254, BNIL);
		       }
		       arg1721_1000 = MAKE_PAIR(arg1717_996, arg1722_1001);
		    }
		    arg1720_999 = MAKE_PAIR(arg1716_995, arg1721_1000);
		 }
		 list1719_998 = MAKE_PAIR(arg1714_994, arg1720_999);
	      }
	      install_specialize__168_cfa_specialize(arg1712_992, arg1713_993, list1719_998);
	   }
	}
	{
	   obj_t arg1724_1003;
	   obj_t arg1725_1004;
	   obj_t arg1726_1005;
	   obj_t arg1727_1006;
	   obj_t arg1728_1007;
	   arg1724_1003 = CNST_TABLE_REF(((long) 21));
	   arg1725_1004 = CNST_TABLE_REF(((long) 1));
	   arg1726_1005 = CNST_TABLE_REF(((long) 22));
	   arg1727_1006 = CNST_TABLE_REF(((long) 3));
	   arg1728_1007 = CNST_TABLE_REF(((long) 23));
	   {
	      obj_t list1730_1009;
	      {
		 obj_t arg1731_1010;
		 {
		    obj_t arg1732_1011;
		    {
		       obj_t arg1733_1012;
		       {
			  obj_t aux_2266;
			  aux_2266 = CNST_TABLE_REF(((long) 5));
			  arg1733_1012 = MAKE_PAIR(aux_2266, BNIL);
		       }
		       arg1732_1011 = MAKE_PAIR(arg1728_1007, arg1733_1012);
		    }
		    arg1731_1010 = MAKE_PAIR(arg1727_1006, arg1732_1011);
		 }
		 list1730_1009 = MAKE_PAIR(arg1726_1005, arg1731_1010);
	      }
	      install_specialize__168_cfa_specialize(arg1724_1003, arg1725_1004, list1730_1009);
	   }
	}
	{
	   obj_t arg1739_1014;
	   obj_t arg1740_1015;
	   obj_t arg1743_1016;
	   obj_t arg1744_1017;
	   obj_t arg1745_1018;
	   arg1739_1014 = CNST_TABLE_REF(((long) 24));
	   arg1740_1015 = CNST_TABLE_REF(((long) 1));
	   arg1743_1016 = CNST_TABLE_REF(((long) 25));
	   arg1744_1017 = CNST_TABLE_REF(((long) 3));
	   arg1745_1018 = CNST_TABLE_REF(((long) 26));
	   {
	      obj_t list1747_1020;
	      {
		 obj_t arg1748_1021;
		 {
		    obj_t arg1749_1022;
		    {
		       obj_t arg1753_1023;
		       {
			  obj_t aux_2278;
			  aux_2278 = CNST_TABLE_REF(((long) 5));
			  arg1753_1023 = MAKE_PAIR(aux_2278, BNIL);
		       }
		       arg1749_1022 = MAKE_PAIR(arg1745_1018, arg1753_1023);
		    }
		    arg1748_1021 = MAKE_PAIR(arg1744_1017, arg1749_1022);
		 }
		 list1747_1020 = MAKE_PAIR(arg1743_1016, arg1748_1021);
	      }
	      install_specialize__168_cfa_specialize(arg1739_1014, arg1740_1015, list1747_1020);
	   }
	}
	{
	   obj_t arg1758_1025;
	   obj_t arg1759_1026;
	   obj_t arg1760_1027;
	   obj_t arg1761_1028;
	   obj_t arg1762_1029;
	   arg1758_1025 = CNST_TABLE_REF(((long) 27));
	   arg1759_1026 = CNST_TABLE_REF(((long) 1));
	   arg1760_1027 = CNST_TABLE_REF(((long) 28));
	   arg1761_1028 = CNST_TABLE_REF(((long) 3));
	   arg1762_1029 = CNST_TABLE_REF(((long) 29));
	   {
	      obj_t list1766_1031;
	      {
		 obj_t arg1767_1032;
		 {
		    obj_t arg1768_1033;
		    {
		       obj_t arg1769_1034;
		       {
			  obj_t aux_2290;
			  aux_2290 = CNST_TABLE_REF(((long) 5));
			  arg1769_1034 = MAKE_PAIR(aux_2290, BNIL);
		       }
		       arg1768_1033 = MAKE_PAIR(arg1762_1029, arg1769_1034);
		    }
		    arg1767_1032 = MAKE_PAIR(arg1761_1028, arg1768_1033);
		 }
		 list1766_1031 = MAKE_PAIR(arg1760_1027, arg1767_1032);
	      }
	      install_specialize__168_cfa_specialize(arg1758_1025, arg1759_1026, list1766_1031);
	   }
	}
	{
	   obj_t arg1771_1036;
	   obj_t arg1772_1037;
	   obj_t arg1773_1038;
	   obj_t arg1774_1039;
	   obj_t arg1776_1040;
	   arg1771_1036 = CNST_TABLE_REF(((long) 30));
	   arg1772_1037 = CNST_TABLE_REF(((long) 1));
	   arg1773_1038 = CNST_TABLE_REF(((long) 31));
	   arg1774_1039 = CNST_TABLE_REF(((long) 3));
	   arg1776_1040 = CNST_TABLE_REF(((long) 32));
	   {
	      obj_t list1778_1042;
	      {
		 obj_t arg1779_1043;
		 {
		    obj_t arg1780_1044;
		    {
		       obj_t arg1781_1045;
		       {
			  obj_t aux_2302;
			  aux_2302 = CNST_TABLE_REF(((long) 5));
			  arg1781_1045 = MAKE_PAIR(aux_2302, BNIL);
		       }
		       arg1780_1044 = MAKE_PAIR(arg1776_1040, arg1781_1045);
		    }
		    arg1779_1043 = MAKE_PAIR(arg1774_1039, arg1780_1044);
		 }
		 list1778_1042 = MAKE_PAIR(arg1773_1038, arg1779_1043);
	      }
	      install_specialize__168_cfa_specialize(arg1771_1036, arg1772_1037, list1778_1042);
	   }
	}
	{
	   obj_t arg1786_1047;
	   obj_t arg1788_1048;
	   obj_t arg1789_1049;
	   obj_t arg1790_1050;
	   obj_t arg1791_1051;
	   arg1786_1047 = CNST_TABLE_REF(((long) 33));
	   arg1788_1048 = CNST_TABLE_REF(((long) 1));
	   arg1789_1049 = CNST_TABLE_REF(((long) 34));
	   arg1790_1050 = CNST_TABLE_REF(((long) 3));
	   arg1791_1051 = CNST_TABLE_REF(((long) 35));
	   {
	      obj_t list1793_1053;
	      {
		 obj_t arg1794_1054;
		 {
		    obj_t arg1795_1055;
		    {
		       obj_t arg1796_1056;
		       {
			  obj_t aux_2314;
			  aux_2314 = CNST_TABLE_REF(((long) 5));
			  arg1796_1056 = MAKE_PAIR(aux_2314, BNIL);
		       }
		       arg1795_1055 = MAKE_PAIR(arg1791_1051, arg1796_1056);
		    }
		    arg1794_1054 = MAKE_PAIR(arg1790_1050, arg1795_1055);
		 }
		 list1793_1053 = MAKE_PAIR(arg1789_1049, arg1794_1054);
	      }
	      install_specialize__168_cfa_specialize(arg1786_1047, arg1788_1048, list1793_1053);
	   }
	}
	{
	   obj_t arg1799_1058;
	   obj_t arg1800_1059;
	   obj_t arg1802_1060;
	   arg1799_1058 = CNST_TABLE_REF(((long) 36));
	   arg1800_1059 = CNST_TABLE_REF(((long) 1));
	   arg1802_1060 = CNST_TABLE_REF(((long) 37));
	   {
	      obj_t list1804_1062;
	      {
		 obj_t arg1805_1063;
		 {
		    obj_t aux_2324;
		    aux_2324 = CNST_TABLE_REF(((long) 5));
		    arg1805_1063 = MAKE_PAIR(aux_2324, BNIL);
		 }
		 list1804_1062 = MAKE_PAIR(arg1802_1060, arg1805_1063);
	      }
	      install_specialize__168_cfa_specialize(arg1799_1058, arg1800_1059, list1804_1062);
	   }
	}
	{
	   obj_t arg1807_1065;
	   obj_t arg1808_1066;
	   obj_t arg1809_1067;
	   obj_t arg1810_1068;
	   obj_t arg1811_1069;
	   arg1807_1065 = CNST_TABLE_REF(((long) 38));
	   arg1808_1066 = CNST_TABLE_REF(((long) 1));
	   arg1809_1067 = CNST_TABLE_REF(((long) 39));
	   arg1810_1068 = CNST_TABLE_REF(((long) 3));
	   arg1811_1069 = CNST_TABLE_REF(((long) 40));
	   {
	      obj_t list1813_1071;
	      {
		 obj_t arg1814_1072;
		 {
		    obj_t arg1815_1073;
		    {
		       obj_t arg1816_1074;
		       {
			  obj_t aux_2334;
			  aux_2334 = CNST_TABLE_REF(((long) 5));
			  arg1816_1074 = MAKE_PAIR(aux_2334, BNIL);
		       }
		       arg1815_1073 = MAKE_PAIR(arg1811_1069, arg1816_1074);
		    }
		    arg1814_1072 = MAKE_PAIR(arg1810_1068, arg1815_1073);
		 }
		 list1813_1071 = MAKE_PAIR(arg1809_1067, arg1814_1072);
	      }
	      install_specialize__168_cfa_specialize(arg1807_1065, arg1808_1066, list1813_1071);
	   }
	}
	{
	   obj_t arg1818_1076;
	   obj_t arg1820_1077;
	   obj_t arg1821_1078;
	   arg1818_1076 = CNST_TABLE_REF(((long) 41));
	   arg1820_1077 = CNST_TABLE_REF(((long) 1));
	   arg1821_1078 = CNST_TABLE_REF(((long) 42));
	   {
	      obj_t list1823_1080;
	      {
		 obj_t arg1824_1081;
		 {
		    obj_t aux_2344;
		    aux_2344 = CNST_TABLE_REF(((long) 5));
		    arg1824_1081 = MAKE_PAIR(aux_2344, BNIL);
		 }
		 list1823_1080 = MAKE_PAIR(arg1821_1078, arg1824_1081);
	      }
	      install_specialize__168_cfa_specialize(arg1818_1076, arg1820_1077, list1823_1080);
	   }
	}
	{
	   obj_t arg1827_1083;
	   obj_t arg1829_1084;
	   obj_t arg1830_1085;
	   arg1827_1083 = CNST_TABLE_REF(((long) 43));
	   arg1829_1084 = CNST_TABLE_REF(((long) 1));
	   arg1830_1085 = CNST_TABLE_REF(((long) 44));
	   {
	      obj_t list1832_1087;
	      {
		 obj_t arg1833_1088;
		 {
		    obj_t aux_2352;
		    aux_2352 = CNST_TABLE_REF(((long) 5));
		    arg1833_1088 = MAKE_PAIR(aux_2352, BNIL);
		 }
		 list1832_1087 = MAKE_PAIR(arg1830_1085, arg1833_1088);
	      }
	      install_specialize__168_cfa_specialize(arg1827_1083, arg1829_1084, list1832_1087);
	   }
	}
	{
	   obj_t arg1835_1090;
	   obj_t arg1836_1091;
	   obj_t arg1837_1092;
	   arg1835_1090 = CNST_TABLE_REF(((long) 45));
	   arg1836_1091 = CNST_TABLE_REF(((long) 1));
	   arg1837_1092 = CNST_TABLE_REF(((long) 46));
	   {
	      obj_t list1839_1094;
	      {
		 obj_t arg1842_1095;
		 {
		    obj_t aux_2360;
		    aux_2360 = CNST_TABLE_REF(((long) 5));
		    arg1842_1095 = MAKE_PAIR(aux_2360, BNIL);
		 }
		 list1839_1094 = MAKE_PAIR(arg1837_1092, arg1842_1095);
	      }
	      install_specialize__168_cfa_specialize(arg1835_1090, arg1836_1091, list1839_1094);
	   }
	}
	{
	   obj_t arg1847_1097;
	   obj_t arg1848_1098;
	   obj_t arg1850_1099;
	   arg1847_1097 = CNST_TABLE_REF(((long) 47));
	   arg1848_1098 = CNST_TABLE_REF(((long) 1));
	   arg1850_1099 = CNST_TABLE_REF(((long) 48));
	   {
	      obj_t list1852_1101;
	      {
		 obj_t arg1853_1102;
		 {
		    obj_t aux_2368;
		    aux_2368 = CNST_TABLE_REF(((long) 5));
		    arg1853_1102 = MAKE_PAIR(aux_2368, BNIL);
		 }
		 list1852_1101 = MAKE_PAIR(arg1850_1099, arg1853_1102);
	      }
	      install_specialize__168_cfa_specialize(arg1847_1097, arg1848_1098, list1852_1101);
	   }
	}
	{
	   obj_t arg1857_1104;
	   obj_t arg1858_1105;
	   obj_t arg1859_1106;
	   arg1857_1104 = CNST_TABLE_REF(((long) 49));
	   arg1858_1105 = CNST_TABLE_REF(((long) 1));
	   arg1859_1106 = CNST_TABLE_REF(((long) 50));
	   {
	      obj_t list1861_1108;
	      {
		 obj_t arg1862_1109;
		 {
		    obj_t aux_2376;
		    aux_2376 = CNST_TABLE_REF(((long) 5));
		    arg1862_1109 = MAKE_PAIR(aux_2376, BNIL);
		 }
		 list1861_1108 = MAKE_PAIR(arg1859_1106, arg1862_1109);
	      }
	      install_specialize__168_cfa_specialize(arg1857_1104, arg1858_1105, list1861_1108);
	   }
	}
	{
	   obj_t arg1864_1111;
	   obj_t arg1865_1112;
	   obj_t arg1866_1113;
	   arg1864_1111 = CNST_TABLE_REF(((long) 51));
	   arg1865_1112 = CNST_TABLE_REF(((long) 1));
	   arg1866_1113 = CNST_TABLE_REF(((long) 52));
	   {
	      obj_t list1868_1115;
	      {
		 obj_t arg1869_1116;
		 {
		    obj_t aux_2384;
		    aux_2384 = CNST_TABLE_REF(((long) 5));
		    arg1869_1116 = MAKE_PAIR(aux_2384, BNIL);
		 }
		 list1868_1115 = MAKE_PAIR(arg1866_1113, arg1869_1116);
	      }
	      install_specialize__168_cfa_specialize(arg1864_1111, arg1865_1112, list1868_1115);
	   }
	}
	{
	   obj_t arg1871_1118;
	   obj_t arg1874_1119;
	   obj_t arg1875_1120;
	   arg1871_1118 = CNST_TABLE_REF(((long) 53));
	   arg1874_1119 = CNST_TABLE_REF(((long) 1));
	   arg1875_1120 = CNST_TABLE_REF(((long) 54));
	   {
	      obj_t list1877_1122;
	      {
		 obj_t arg1878_1123;
		 {
		    obj_t aux_2392;
		    aux_2392 = CNST_TABLE_REF(((long) 5));
		    arg1878_1123 = MAKE_PAIR(aux_2392, BNIL);
		 }
		 list1877_1122 = MAKE_PAIR(arg1875_1120, arg1878_1123);
	      }
	      install_specialize__168_cfa_specialize(arg1871_1118, arg1874_1119, list1877_1122);
	   }
	}
	{
	   obj_t arg1880_1125;
	   obj_t arg1881_1126;
	   obj_t arg1883_1127;
	   arg1880_1125 = CNST_TABLE_REF(((long) 55));
	   arg1881_1126 = CNST_TABLE_REF(((long) 1));
	   arg1883_1127 = CNST_TABLE_REF(((long) 56));
	   {
	      obj_t list1885_1129;
	      {
		 obj_t arg1886_1130;
		 {
		    obj_t aux_2400;
		    aux_2400 = CNST_TABLE_REF(((long) 5));
		    arg1886_1130 = MAKE_PAIR(aux_2400, BNIL);
		 }
		 list1885_1129 = MAKE_PAIR(arg1883_1127, arg1886_1130);
	      }
	      install_specialize__168_cfa_specialize(arg1880_1125, arg1881_1126, list1885_1129);
	   }
	}
	patch_tree__164_cfa_specialize(globals_6);
	show_specialize_223_cfa_specialize();
	{
	   bool_t aux_2407;
	   aux_2407 = uninstall_specializes__251_cfa_specialize();
	   BBOOL(aux_2407);
	}
     }
   else
     {
	BUNSPEC;
     }
   return globals_6;
}


/* _specialize! */ obj_t 
_specialize__238_cfa_specialize(obj_t env_1983, obj_t globals_1984)
{
   return specialize__184_cfa_specialize(globals_1984);
}


/* patch-tree! */ bool_t 
patch_tree__164_cfa_specialize(obj_t globals_7)
{
   {
      obj_t l1488_1132;
      l1488_1132 = globals_7;
    lname1489_1133:
      if (PAIRP(l1488_1132))
	{
	   patch_fun__141_cfa_specialize(CAR(l1488_1132));
	   {
	      obj_t l1488_2415;
	      l1488_2415 = CDR(l1488_1132);
	      l1488_1132 = l1488_2415;
	      goto lname1489_1133;
	   }
	}
      else
	{
	   return ((bool_t) 1);
	}
   }
}


/* patch-fun! */ obj_t 
patch_fun__141_cfa_specialize(obj_t variable_8)
{
   {
      value_t fun_1137;
      {
	 variable_t obj_1756;
	 obj_1756 = (variable_t) (variable_8);
	 fun_1137 = (((variable_t) CREF(obj_1756))->value);
      }
      {
	 obj_t arg1893_1138;
	 {
	    node_t aux_2419;
	    {
	       obj_t aux_2420;
	       {
		  sfun_t obj_1757;
		  obj_1757 = (sfun_t) (fun_1137);
		  aux_2420 = (((sfun_t) CREF(obj_1757))->body);
	       }
	       aux_2419 = (node_t) (aux_2420);
	    }
	    arg1893_1138 = patch__227_cfa_specialize(aux_2419);
	 }
	 {
	    sfun_t obj_1758;
	    obj_1758 = (sfun_t) (fun_1137);
	    return ((((sfun_t) CREF(obj_1758))->body) = ((obj_t) arg1893_1138), BUNSPEC);
	 }
      }
   }
}


/* patch*! */ obj_t 
patch___72_cfa_specialize(obj_t node__221_31)
{
   {
      obj_t node__221_1140;
      node__221_1140 = node__221_31;
    loop_1141:
      if (NULLP(node__221_1140))
	{
	   return CNST_TABLE_REF(((long) 57));
	}
      else
	{
	   {
	      obj_t arg1896_1143;
	      {
		 node_t aux_2430;
		 {
		    obj_t aux_2431;
		    aux_2431 = CAR(node__221_1140);
		    aux_2430 = (node_t) (aux_2431);
		 }
		 arg1896_1143 = patch__227_cfa_specialize(aux_2430);
	      }
	      SET_CAR(node__221_1140, arg1896_1143);
	   }
	   {
	      obj_t node__221_2436;
	      node__221_2436 = CDR(node__221_1140);
	      node__221_1140 = node__221_2436;
	      goto loop_1141;
	   }
	}
   }
}


/* specialize-app! */ node_t 
specialize_app__163_cfa_specialize(app_t node_33)
{
   {
      bool_t test_2438;
      {
	 obj_t aux_2439;
	 aux_2439 = (((app_t) CREF(node_33))->args);
	 test_2438 = NULLP(aux_2439);
      }
      if (test_2438)
	{
	   return (node_t) (node_33);
	}
      else
	{
	   type_t type_1148;
	   {
	      node_t aux_2443;
	      {
		 obj_t aux_2444;
		 {
		    obj_t aux_2445;
		    aux_2445 = (((app_t) CREF(node_33))->args);
		    aux_2444 = CAR(aux_2445);
		 }
		 aux_2443 = (node_t) (aux_2444);
	      }
	      type_1148 = typeof_coerce_typeof(aux_2443);
	   }
	   {
	      obj_t spec_1150;
	      {
		 obj_t aux_2450;
		 {
		    specialized_global_131_t obj_1771;
		    {
		       variable_t aux_2452;
		       {
			  var_t arg1913_1164;
			  arg1913_1164 = (((app_t) CREF(node_33))->fun);
			  aux_2452 = (((var_t) CREF(arg1913_1164))->variable);
		       }
		       obj_1771 = (specialized_global_131_t) (aux_2452);
		    }
		    {
		       obj_t aux_2456;
		       {
			  object_t aux_2457;
			  aux_2457 = (object_t) (obj_1771);
			  aux_2456 = OBJECT_WIDENING(aux_2457);
		       }
		       aux_2450 = (((specialized_global_131_t) CREF(aux_2456))->fix);
		    }
		 }
		 spec_1150 = assq___r4_pairs_and_lists_6_3((obj_t) (type_1148), aux_2450);
	      }
	      {
		 if (PAIRP(spec_1150))
		   {
		      obj_t args_1152;
		      {
			 app_t aux_2464;
			 {
			    obj_t aux_2488;
			    aux_2488 = (((app_t) CREF(node_33))->args);
			    args_1152 = CDR(aux_2488);
			 }
		       loop_1153:
			 if (NULLP(args_1152))
			   {
			      add_specialized_type__70_cfa_specialize(type_1148);
			      {
				 var_t arg1905_1157;
				 arg1905_1157 = (((app_t) CREF(node_33))->fun);
				 {
				    variable_t val1214_1779;
				    {
				       obj_t aux_2469;
				       aux_2469 = CDR(spec_1150);
				       val1214_1779 = (variable_t) (aux_2469);
				    }
				    ((((var_t) CREF(arg1905_1157))->variable) = ((variable_t) val1214_1779), BUNSPEC);
				 }
			      }
			      {
				 node_t obj_1780;
				 obj_1780 = (node_t) (node_33);
				 ((((node_t) CREF(obj_1780))->type) = ((type_t) type_1148), BUNSPEC);
			      }
			      aux_2464 = node_33;
			   }
			 else
			   {
			      bool_t test1907_1159;
			      {
				 type_t arg1910_1161;
				 {
				    node_t aux_2475;
				    {
				       obj_t aux_2476;
				       aux_2476 = CAR(args_1152);
				       aux_2475 = (node_t) (aux_2476);
				    }
				    arg1910_1161 = typeof_coerce_typeof(aux_2475);
				 }
				 {
				    obj_t aux_2482;
				    obj_t aux_2480;
				    aux_2482 = (obj_t) (type_1148);
				    aux_2480 = (obj_t) (arg1910_1161);
				    test1907_1159 = (aux_2480 == aux_2482);
				 }
			      }
			      if (test1907_1159)
				{
				   {
				      obj_t args_2486;
				      args_2486 = CDR(args_1152);
				      args_1152 = args_2486;
				      goto loop_1153;
				   }
				}
			      else
				{
				   aux_2464 = node_33;
				}
			   }
			 return (node_t) (aux_2464);
		      }
		   }
		 else
		   {
		      return (node_t) (node_33);
		   }
	      }
	   }
	}
   }
}


/* object-init */ obj_t 
object_init_111_cfa_specialize()
{
   {
      obj_t arg1918_1169;
      arg1918_1169 = global_ast_var;
      specialized_global_131_cfa_specialize = add_class__117___object(CNST_TABLE_REF(((long) 58)), arg1918_1169, allocate_specialized_global_env_23_cfa_specialize, ((long) 7812), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-specialized-global */ global_t 
allocate_specialized_global_107_cfa_specialize()
{
   {
      global_t new1473_1172;
      new1473_1172 = ((global_t) BREF(GC_MALLOC(sizeof(struct global))));
      {
	 long arg1921_1173;
	 arg1921_1173 = class_num_218___object(specialized_global_131_cfa_specialize);
	 {
	    obj_t obj_1786;
	    obj_1786 = (obj_t) (new1473_1172);
	    (((obj_t) CREF(obj_1786))->header = MAKE_HEADER(arg1921_1173, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_2499;
	 aux_2499 = (object_t) (new1473_1172);
	 OBJECT_WIDENING_SET(aux_2499, BFALSE);
      }
      return new1473_1172;
   }
}


/* _allocate-specialized-global */ obj_t 
_allocate_specialized_global_95_cfa_specialize(obj_t env_1985)
{
   {
      global_t aux_2502;
      aux_2502 = allocate_specialized_global_107_cfa_specialize();
      return (obj_t) (aux_2502);
   }
}


/* method-init */ obj_t 
method_init_76_cfa_specialize()
{
   add_generic__110___object(patch__env_129_cfa_specialize, patch__default1515_env_174_cfa_specialize);
   add_inlined_method__244___object(patch__env_129_cfa_specialize, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, var_ast_node, ((long) 2));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, app_ly_162_ast_node, ((long) 5));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, funcall_ast_node, ((long) 6));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, pragma_ast_node, ((long) 7));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, cast_ast_node, ((long) 8));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, setq_ast_node, ((long) 9));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, conditional_ast_node, ((long) 10));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, fail_ast_node, ((long) 11));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, select_ast_node, ((long) 12));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, let_fun_218_ast_node, ((long) 13));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, let_var_6_ast_node, ((long) 14));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, set_ex_it_116_ast_node, ((long) 15));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, jump_ex_it_184_ast_node, ((long) 16));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, make_box_202_ast_node, ((long) 17));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, box_set__221_ast_node, ((long) 18));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, box_ref_242_ast_node, ((long) 19));
   add_inlined_method__244___object(patch__env_129_cfa_specialize, app_ast_node, ((long) 20));
   {
      obj_t object__struct_specialized_global_35_1990;
      object__struct_specialized_global_35_1990 = proc2133_cfa_specialize;
      add_method__1___object(object__struct_env_210___object, specialized_global_131_cfa_specialize, object__struct_specialized_global_35_1990);
   }
   {
      obj_t struct_object__object_specialized_global_181_1986;
      struct_object__object_specialized_global_181_1986 = proc2134_cfa_specialize;
      return add_method__1___object(struct_object__object_env_209___object, specialized_global_131_cfa_specialize, struct_object__object_specialized_global_181_1986);
   }
}


/* struct+object->object-specialized-global */ obj_t 
struct_object__object_specialized_global_181_cfa_specialize(obj_t env_1993, obj_t o_1994, obj_t s_1995)
{
   {
      specialized_global_131_t o_1527;
      obj_t s_1528;
      {
	 specialized_global_131_t aux_2529;
	 o_1527 = (specialized_global_131_t) (o_1994);
	 s_1528 = s_1995;
	 {
	    {
	       obj_t old1478_1531;
	       obj_t aux1479_1532;
	       {
		  obj_t next_method1548_240_1537;
		  next_method1548_240_1537 = find_super_class_method_167___object((object_t) (o_1527), struct_object__object_env_209___object, specialized_global_131_cfa_specialize);
		  if (PROCEDUREP(next_method1548_240_1537))
		    {
		       old1478_1531 = PROCEDURE_ENTRY(next_method1548_240_1537) (next_method1548_240_1537, (obj_t) (o_1527), s_1528, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1548_240_1537);
		       {
			  object_t aux_2538;
			  aux_2538 = struct_object__object_93___object((object_t) (o_1527), s_1528);
			  old1478_1531 = (obj_t) (aux_2538);
		       }
		    }
	       }
	       aux1479_1532 = STRUCT_REF(s_1528, ((long) 0));
	       {
		  specialized_global_131_t new1480_1533;
		  new1480_1533 = ((specialized_global_131_t) (old1478_1531));
		  {
		     long arg2018_1534;
		     arg2018_1534 = class_num_218___object(specialized_global_131_cfa_specialize);
		     {
			obj_t obj_1847;
			obj_1847 = (obj_t) (new1480_1533);
			(((obj_t) CREF(obj_1847))->header = MAKE_HEADER(arg2018_1534, 0), BUNSPEC);
		     }
		  }
		  {
		     specialized_global_131_t arg2019_1535;
		     {
			obj_t arg2020_1536;
			arg2020_1536 = STRUCT_REF(aux1479_1532, ((long) 0));
			{
			   specialized_global_131_t res2115_1854;
			   {
			      specialized_global_131_t new1456_1852;
			      new1456_1852 = ((specialized_global_131_t) BREF(GC_MALLOC(sizeof(struct specialized_global_131))));
			      ((((specialized_global_131_t) CREF(new1456_1852))->fix) = ((obj_t) arg2020_1536), BUNSPEC);
			      res2115_1854 = new1456_1852;
			   }
			   arg2019_1535 = res2115_1854;
			}
		     }
		     {
			obj_t aux_2552;
			object_t aux_2550;
			aux_2552 = (obj_t) (arg2019_1535);
			aux_2550 = (object_t) (new1480_1533);
			OBJECT_WIDENING_SET(aux_2550, aux_2552);
		     }
		  }
		  aux_2529 = new1480_1533;
	       }
	    }
	 }
	 return (obj_t) (aux_2529);
      }
   }
}


/* object->struct-specialized-global */ obj_t 
object__struct_specialized_global_35_cfa_specialize(obj_t env_1996, obj_t obj1475_1997)
{
   {
      specialized_global_131_t obj1475_1514;
      obj1475_1514 = (specialized_global_131_t) (obj1475_1997);
      {
	 {
	    obj_t res1476_1517;
	    {
	       obj_t next_method1547_42_1525;
	       next_method1547_42_1525 = find_super_class_method_167___object((object_t) (obj1475_1514), object__struct_env_210___object, specialized_global_131_cfa_specialize);
	       if (PROCEDUREP(next_method1547_42_1525))
		 {
		    res1476_1517 = PROCEDURE_ENTRY(next_method1547_42_1525) (next_method1547_42_1525, (obj_t) (obj1475_1514), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1547_42_1525);
		    res1476_1517 = object__struct_50___object((object_t) (obj1475_1514));
		 }
	    }
	    {
	       obj_t aux1477_1518;
	       {
		  obj_t aux_2567;
		  aux_2567 = CNST_TABLE_REF(((long) 58));
		  aux1477_1518 = make_struct(aux_2567, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_2570;
		  {
		     obj_t aux_2571;
		     {
			object_t aux_2572;
			aux_2572 = (object_t) (obj1475_1514);
			aux_2571 = OBJECT_WIDENING(aux_2572);
		     }
		     aux_2570 = (((specialized_global_131_t) CREF(aux_2571))->fix);
		  }
		  STRUCT_SET(aux1477_1518, ((long) 0), aux_2570);
	       }
	       STRUCT_SET(res1476_1517, ((long) 0), aux1477_1518);
	       {
		  obj_t aux_2578;
		  aux_2578 = STRUCT_KEY(res1476_1517);
		  STRUCT_KEY_SET(aux1477_1518, aux_2578);
	       }
	       {
		  obj_t aux_2581;
		  aux_2581 = CNST_TABLE_REF(((long) 58));
		  STRUCT_KEY_SET(res1476_1517, aux_2581);
	       }
	       return res1476_1517;
	    }
	 }
      }
   }
}


/* patch! */ obj_t 
patch__227_cfa_specialize(node_t node_9)
{
   {
      obj_t method2025_1545;
      obj_t class2030_1546;
      {
	 obj_t arg2033_1543;
	 obj_t arg2035_1544;
	 {
	    object_t obj_1857;
	    obj_1857 = (object_t) (node_9);
	    {
	       obj_t pre_method_105_1858;
	       pre_method_105_1858 = PROCEDURE_REF(patch__env_129_cfa_specialize, ((long) 2));
	       if (INTEGERP(pre_method_105_1858))
		 {
		    PROCEDURE_SET(patch__env_129_cfa_specialize, ((long) 2), BUNSPEC);
		    arg2033_1543 = pre_method_105_1858;
		 }
	       else
		 {
		    long obj_class_num_177_1863;
		    obj_class_num_177_1863 = TYPE(obj_1857);
		    {
		       obj_t arg1177_1864;
		       arg1177_1864 = PROCEDURE_REF(patch__env_129_cfa_specialize, ((long) 1));
		       {
			  long arg1178_1868;
			  {
			     long arg1179_1869;
			     arg1179_1869 = OBJECT_TYPE;
			     arg1178_1868 = (obj_class_num_177_1863 - arg1179_1869);
			  }
			  arg2033_1543 = VECTOR_REF(arg1177_1864, arg1178_1868);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1874;
	    object_1874 = (object_t) (node_9);
	    {
	       long arg1180_1875;
	       {
		  long arg1181_1876;
		  long arg1182_1877;
		  arg1181_1876 = TYPE(object_1874);
		  arg1182_1877 = OBJECT_TYPE;
		  arg1180_1875 = (arg1181_1876 - arg1182_1877);
	       }
	       {
		  obj_t vector_1881;
		  vector_1881 = _classes__134___object;
		  arg2035_1544 = VECTOR_REF(vector_1881, arg1180_1875);
	       }
	    }
	 }
	 method2025_1545 = arg2033_1543;
	 class2030_1546 = arg2035_1544;
	 {
	    if (INTEGERP(method2025_1545))
	      {
		 switch ((long) CINT(method2025_1545))
		   {
		   case ((long) 0):
		      {
			 atom_t aux_2602;
			 aux_2602 = (atom_t) (node_9);
			 return (obj_t) (aux_2602);
		      }
		      break;
		   case ((long) 1):
		      {
			 kwote_t aux_2605;
			 aux_2605 = (kwote_t) (node_9);
			 return (obj_t) (aux_2605);
		      }
		      break;
		   case ((long) 2):
		      {
			 var_t aux_2608;
			 aux_2608 = (var_t) (node_9);
			 return (obj_t) (aux_2608);
		      }
		      break;
		   case ((long) 3):
		      {
			 obj_t arg2040_1558;
			 {
			    obj_t aux_2611;
			    {
			       closure_t aux_2612;
			       aux_2612 = (closure_t) (node_9);
			       aux_2611 = (obj_t) (aux_2612);
			    }
			    arg2040_1558 = shape_tools_shape(aux_2611);
			 }
			 return internal_error_43_tools_error(string2135_cfa_specialize, string2136_cfa_specialize, arg2040_1558);
		      }
		      break;
		   case ((long) 4):
		      {
			 sequence_t node_1559;
			 node_1559 = (sequence_t) (node_9);
			 patch___72_cfa_specialize((((sequence_t) CREF(node_1559))->nodes));
			 return (obj_t) (node_1559);
		      }
		      break;
		   case ((long) 5):
		      {
			 app_ly_162_t node_1562;
			 node_1562 = (app_ly_162_t) (node_9);
			 {
			    obj_t arg2042_1564;
			    arg2042_1564 = patch__227_cfa_specialize((((app_ly_162_t) CREF(node_1562))->fun));
			    {
			       node_t val1265_1886;
			       val1265_1886 = (node_t) (arg2042_1564);
			       ((((app_ly_162_t) CREF(node_1562))->fun) = ((node_t) val1265_1886), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2044_1566;
			    arg2044_1566 = patch__227_cfa_specialize((((app_ly_162_t) CREF(node_1562))->arg));
			    {
			       node_t val1266_1889;
			       val1266_1889 = (node_t) (arg2044_1566);
			       ((((app_ly_162_t) CREF(node_1562))->arg) = ((node_t) val1266_1889), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1562);
		      }
		      break;
		   case ((long) 6):
		      {
			 funcall_t node_1568;
			 node_1568 = (funcall_t) (node_9);
			 {
			    obj_t arg2046_1570;
			    arg2046_1570 = patch__227_cfa_specialize((((funcall_t) CREF(node_1568))->fun));
			    {
			       node_t val1276_1892;
			       val1276_1892 = (node_t) (arg2046_1570);
			       ((((funcall_t) CREF(node_1568))->fun) = ((node_t) val1276_1892), BUNSPEC);
			    }
			 }
			 patch___72_cfa_specialize((((funcall_t) CREF(node_1568))->args));
			 return (obj_t) (node_1568);
		      }
		      break;
		   case ((long) 7):
		      {
			 pragma_t node_1573;
			 node_1573 = (pragma_t) (node_9);
			 patch___72_cfa_specialize((((pragma_t) CREF(node_1573))->args));
			 return (obj_t) (node_1573);
		      }
		      break;
		   case ((long) 8):
		      {
			 cast_t node_1576;
			 node_1576 = (cast_t) (node_9);
			 patch__227_cfa_specialize((((cast_t) CREF(node_1576))->arg));
			 return (obj_t) (node_1576);
		      }
		      break;
		   case ((long) 9):
		      {
			 setq_t node_1579;
			 node_1579 = (setq_t) (node_9);
			 {
			    obj_t arg2051_1581;
			    arg2051_1581 = patch__227_cfa_specialize((((setq_t) CREF(node_1579))->value));
			    {
			       node_t val1309_1898;
			       val1309_1898 = (node_t) (arg2051_1581);
			       ((((setq_t) CREF(node_1579))->value) = ((node_t) val1309_1898), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2053_1583;
			    {
			       node_t aux_2652;
			       {
				  var_t aux_2653;
				  aux_2653 = (((setq_t) CREF(node_1579))->var);
				  aux_2652 = (node_t) (aux_2653);
			       }
			       arg2053_1583 = patch__227_cfa_specialize(aux_2652);
			    }
			    {
			       var_t val1308_1901;
			       val1308_1901 = (var_t) (arg2053_1583);
			       ((((setq_t) CREF(node_1579))->var) = ((var_t) val1308_1901), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1579);
		      }
		      break;
		   case ((long) 10):
		      {
			 conditional_t node_1585;
			 node_1585 = (conditional_t) (node_9);
			 {
			    obj_t arg2055_1587;
			    arg2055_1587 = patch__227_cfa_specialize((((conditional_t) CREF(node_1585))->test));
			    {
			       node_t val1323_1904;
			       val1323_1904 = (node_t) (arg2055_1587);
			       ((((conditional_t) CREF(node_1585))->test) = ((node_t) val1323_1904), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2057_1589;
			    arg2057_1589 = patch__227_cfa_specialize((((conditional_t) CREF(node_1585))->true));
			    {
			       node_t val1324_1907;
			       val1324_1907 = (node_t) (arg2057_1589);
			       ((((conditional_t) CREF(node_1585))->true) = ((node_t) val1324_1907), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2059_1591;
			    arg2059_1591 = patch__227_cfa_specialize((((conditional_t) CREF(node_1585))->false));
			    {
			       node_t val1325_1910;
			       val1325_1910 = (node_t) (arg2059_1591);
			       ((((conditional_t) CREF(node_1585))->false) = ((node_t) val1325_1910), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1585);
		      }
		      break;
		   case ((long) 11):
		      {
			 fail_t node_1593;
			 node_1593 = (fail_t) (node_9);
			 {
			    obj_t arg2061_1595;
			    arg2061_1595 = patch__227_cfa_specialize((((fail_t) CREF(node_1593))->proc));
			    {
			       node_t val1335_1913;
			       val1335_1913 = (node_t) (arg2061_1595);
			       ((((fail_t) CREF(node_1593))->proc) = ((node_t) val1335_1913), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2063_1597;
			    arg2063_1597 = patch__227_cfa_specialize((((fail_t) CREF(node_1593))->msg));
			    {
			       node_t val1336_1916;
			       val1336_1916 = (node_t) (arg2063_1597);
			       ((((fail_t) CREF(node_1593))->msg) = ((node_t) val1336_1916), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2065_1599;
			    arg2065_1599 = patch__227_cfa_specialize((((fail_t) CREF(node_1593))->obj));
			    {
			       node_t val1337_1919;
			       val1337_1919 = (node_t) (arg2065_1599);
			       ((((fail_t) CREF(node_1593))->obj) = ((node_t) val1337_1919), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1593);
		      }
		      break;
		   case ((long) 12):
		      {
			 select_t node_1601;
			 node_1601 = (select_t) (node_9);
			 {
			    obj_t arg2068_1603;
			    arg2068_1603 = patch__227_cfa_specialize((((select_t) CREF(node_1601))->test));
			    {
			       node_t val1351_1922;
			       val1351_1922 = (node_t) (arg2068_1603);
			       ((((select_t) CREF(node_1601))->test) = ((node_t) val1351_1922), BUNSPEC);
			    }
			 }
			 {
			    obj_t l1499_1605;
			    l1499_1605 = (((select_t) CREF(node_1601))->clauses);
			  lname1500_1606:
			    if (PAIRP(l1499_1605))
			      {
				 {
				    obj_t clause_1609;
				    clause_1609 = CAR(l1499_1605);
				    {
				       obj_t arg2072_1610;
				       {
					  node_t aux_2696;
					  {
					     obj_t aux_2697;
					     aux_2697 = CDR(clause_1609);
					     aux_2696 = (node_t) (aux_2697);
					  }
					  arg2072_1610 = patch__227_cfa_specialize(aux_2696);
				       }
				       SET_CDR(clause_1609, arg2072_1610);
				    }
				 }
				 {
				    obj_t l1499_2702;
				    l1499_2702 = CDR(l1499_1605);
				    l1499_1605 = l1499_2702;
				    goto lname1500_1606;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 return (obj_t) (node_1601);
		      }
		      break;
		   case ((long) 13):
		      {
			 let_fun_218_t node_1613;
			 node_1613 = (let_fun_218_t) (node_9);
			 {
			    obj_t l1502_1615;
			    l1502_1615 = (((let_fun_218_t) CREF(node_1613))->locals);
			  lname1503_1616:
			    if (PAIRP(l1502_1615))
			      {
				 patch_fun__141_cfa_specialize(CAR(l1502_1615));
				 {
				    obj_t l1502_2711;
				    l1502_2711 = CDR(l1502_1615);
				    l1502_1615 = l1502_2711;
				    goto lname1503_1616;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t arg2079_1621;
			    arg2079_1621 = patch__227_cfa_specialize((((let_fun_218_t) CREF(node_1613))->body));
			    {
			       node_t val1365_1936;
			       val1365_1936 = (node_t) (arg2079_1621);
			       ((((let_fun_218_t) CREF(node_1613))->body) = ((node_t) val1365_1936), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1613);
		      }
		      break;
		   case ((long) 14):
		      {
			 let_var_6_t node_1623;
			 node_1623 = (let_var_6_t) (node_9);
			 {
			    obj_t l1505_1625;
			    l1505_1625 = (((let_var_6_t) CREF(node_1623))->bindings);
			  lname1506_1626:
			    if (PAIRP(l1505_1625))
			      {
				 {
				    obj_t binding_1629;
				    binding_1629 = CAR(l1505_1625);
				    {
				       obj_t arg2083_1631;
				       {
					  node_t aux_2723;
					  {
					     obj_t aux_2724;
					     aux_2724 = CDR(binding_1629);
					     aux_2723 = (node_t) (aux_2724);
					  }
					  arg2083_1631 = patch__227_cfa_specialize(aux_2723);
				       }
				       SET_CDR(binding_1629, arg2083_1631);
				    }
				 }
				 {
				    obj_t l1505_2729;
				    l1505_2729 = CDR(l1505_1625);
				    l1505_1625 = l1505_2729;
				    goto lname1506_1626;
				 }
			      }
			    else
			      {
				 ((bool_t) 1);
			      }
			 }
			 {
			    obj_t arg2085_1633;
			    arg2085_1633 = patch__227_cfa_specialize((((let_var_6_t) CREF(node_1623))->body));
			    {
			       node_t val1380_1946;
			       val1380_1946 = (node_t) (arg2085_1633);
			       ((((let_var_6_t) CREF(node_1623))->body) = ((node_t) val1380_1946), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1623);
		      }
		      break;
		   case ((long) 15):
		      {
			 set_ex_it_116_t node_1635;
			 node_1635 = (set_ex_it_116_t) (node_9);
			 {
			    obj_t arg2087_1637;
			    arg2087_1637 = patch__227_cfa_specialize((((set_ex_it_116_t) CREF(node_1635))->body));
			    {
			       node_t val1391_1949;
			       val1391_1949 = (node_t) (arg2087_1637);
			       ((((set_ex_it_116_t) CREF(node_1635))->body) = ((node_t) val1391_1949), BUNSPEC);
			    }
			 }
			 {
			    node_t aux_2742;
			    {
			       var_t aux_2743;
			       aux_2743 = (((set_ex_it_116_t) CREF(node_1635))->var);
			       aux_2742 = (node_t) (aux_2743);
			    }
			    patch__227_cfa_specialize(aux_2742);
			 }
			 return (obj_t) (node_1635);
		      }
		      break;
		   case ((long) 16):
		      {
			 jump_ex_it_184_t node_1640;
			 node_1640 = (jump_ex_it_184_t) (node_9);
			 {
			    obj_t arg2090_1642;
			    arg2090_1642 = patch__227_cfa_specialize((((jump_ex_it_184_t) CREF(node_1640))->exit));
			    {
			       node_t val1400_1953;
			       val1400_1953 = (node_t) (arg2090_1642);
			       ((((jump_ex_it_184_t) CREF(node_1640))->exit) = ((node_t) val1400_1953), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2092_1644;
			    arg2092_1644 = patch__227_cfa_specialize((((jump_ex_it_184_t) CREF(node_1640))->value));
			    {
			       node_t val1401_1956;
			       val1401_1956 = (node_t) (arg2092_1644);
			       ((((jump_ex_it_184_t) CREF(node_1640))->value) = ((node_t) val1401_1956), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1640);
		      }
		      break;
		   case ((long) 17):
		      {
			 make_box_202_t node_1646;
			 node_1646 = (make_box_202_t) (node_9);
			 {
			    obj_t arg2094_1648;
			    arg2094_1648 = patch__227_cfa_specialize((((make_box_202_t) CREF(node_1646))->value));
			    {
			       node_t val1413_1959;
			       val1413_1959 = (node_t) (arg2094_1648);
			       ((((make_box_202_t) CREF(node_1646))->value) = ((node_t) val1413_1959), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1646);
		      }
		      break;
		   case ((long) 18):
		      {
			 box_set__221_t node_1650;
			 node_1650 = (box_set__221_t) (node_9);
			 {
			    obj_t arg2096_1652;
			    {
			       node_t aux_2765;
			       {
				  var_t aux_2766;
				  aux_2766 = (((box_set__221_t) CREF(node_1650))->var);
				  aux_2765 = (node_t) (aux_2766);
			       }
			       arg2096_1652 = patch__227_cfa_specialize(aux_2765);
			    }
			    {
			       var_t val1434_1962;
			       val1434_1962 = (var_t) (arg2096_1652);
			       ((((box_set__221_t) CREF(node_1650))->var) = ((var_t) val1434_1962), BUNSPEC);
			    }
			 }
			 {
			    obj_t arg2098_1654;
			    arg2098_1654 = patch__227_cfa_specialize((((box_set__221_t) CREF(node_1650))->value));
			    {
			       node_t val1435_1965;
			       val1435_1965 = (node_t) (arg2098_1654);
			       ((((box_set__221_t) CREF(node_1650))->value) = ((node_t) val1435_1965), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1650);
		      }
		      break;
		   case ((long) 19):
		      {
			 box_ref_242_t node_1656;
			 node_1656 = (box_ref_242_t) (node_9);
			 {
			    obj_t arg2100_1658;
			    {
			       node_t aux_2778;
			       {
				  var_t aux_2779;
				  aux_2779 = (((box_ref_242_t) CREF(node_1656))->var);
				  aux_2778 = (node_t) (aux_2779);
			       }
			       arg2100_1658 = patch__227_cfa_specialize(aux_2778);
			    }
			    {
			       var_t val1425_1968;
			       val1425_1968 = (var_t) (arg2100_1658);
			       ((((box_ref_242_t) CREF(node_1656))->var) = ((var_t) val1425_1968), BUNSPEC);
			    }
			 }
			 return (obj_t) (node_1656);
		      }
		      break;
		   case ((long) 20):
		      {
			 app_t node_1660;
			 node_1660 = (app_t) (node_9);
			 patch___72_cfa_specialize((((app_t) CREF(node_1660))->args));
			 {
			    obj_t arg2103_1663;
			    {
			       node_t aux_2789;
			       {
				  var_t aux_2790;
				  aux_2790 = (((app_t) CREF(node_1660))->fun);
				  aux_2789 = (node_t) (aux_2790);
			       }
			       arg2103_1663 = patch__227_cfa_specialize(aux_2789);
			    }
			    {
			       var_t val1254_1972;
			       val1254_1972 = (var_t) (arg2103_1663);
			       ((((app_t) CREF(node_1660))->fun) = ((var_t) val1254_1972), BUNSPEC);
			    }
			 }
			 {
			    bool_t test_2796;
			    {
			       obj_t aux_2797;
			       {
				  variable_t aux_2798;
				  {
				     var_t arg2107_1667;
				     arg2107_1667 = (((app_t) CREF(node_1660))->fun);
				     aux_2798 = (((var_t) CREF(arg2107_1667))->variable);
				  }
				  aux_2797 = (obj_t) (aux_2798);
			       }
			       test_2796 = is_a__118___object(aux_2797, specialized_global_131_cfa_specialize);
			    }
			    if (test_2796)
			      {
				 node_t aux_2803;
				 aux_2803 = specialize_app__163_cfa_specialize(node_1660);
				 return (obj_t) (aux_2803);
			      }
			    else
			      {
				 return (obj_t) (node_1660);
			      }
			 }
		      }
		      break;
		   default:
		    case_else2031_1549:
		      if (PROCEDUREP(method2025_1545))
			{
			   return PROCEDURE_ENTRY(method2025_1545) (method2025_1545, (obj_t) (node_9), BEOA);
			}
		      else
			{
			   obj_t fun2022_1539;
			   fun2022_1539 = PROCEDURE_REF(patch__env_129_cfa_specialize, ((long) 0));
			   return PROCEDURE_ENTRY(fun2022_1539) (fun2022_1539, (obj_t) (node_9), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else2031_1549;
	      }
	 }
      }
   }
}


/* _patch!2122 */ obj_t 
_patch_2122_210_cfa_specialize(obj_t env_1998, obj_t node_1999)
{
   return patch__227_cfa_specialize((node_t) (node_1999));
}


/* patch!-default1515 */ obj_t 
patch__default1515_36_cfa_specialize(node_t node_10)
{
   FAILURE(CNST_TABLE_REF(((long) 59)), string2137_cfa_specialize, (obj_t) (node_10));
}


/* _patch!-default1515 */ obj_t 
_patch__default1515_1_cfa_specialize(obj_t env_2000, obj_t node_2001)
{
   return patch__default1515_36_cfa_specialize((node_t) (node_2001));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cfa_specialize()
{
   module_initialization_70_tools_trace(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_engine_param(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_type_type(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_type_cache(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_tools_shape(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_tools_speek(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_tools_error(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_coerce_typeof(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_ast_var(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_ast_node(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_ast_env(((long) 0), "CFA_SPECIALIZE");
   module_initialization_70_inline_inline(((long) 0), "CFA_SPECIALIZE");
   return module_initialization_70_inline_walk(((long) 0), "CFA_SPECIALIZE");
}
