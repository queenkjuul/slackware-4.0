/*===========================================================================*/
/*   (Cnst/node.scm)                                                         */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;

typedef struct node
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
  }
    *node_t;

typedef struct node_effect_213
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
  }
               *node_effect_213_t;

typedef struct atom
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
    *atom_t;

typedef struct var
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
   *var_t;

typedef struct closure
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct variable *variable;
  }
       *closure_t;

typedef struct kwote
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t value;
  }
     *kwote_t;

typedef struct sequence
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t nodes;
  }
        *sequence_t;

typedef struct app
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *fun;
     obj_t args;
     obj_t stack_info_255;
  }
   *app_t;

typedef struct app_ly_162
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     struct node *arg;
  }
          *app_ly_162_t;

typedef struct funcall
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *fun;
     obj_t args;
     obj_t strength;
  }
       *funcall_t;

typedef struct pragma
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t format;
     obj_t args;
  }
      *pragma_t;

typedef struct cast
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *arg;
  }
    *cast_t;

typedef struct setq
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
    *setq_t;

typedef struct conditional
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     struct node *true;
     struct node *false;
  }
           *conditional_t;

typedef struct fail
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *proc;
     struct node *msg;
     struct node *obj;
  }
    *fail_t;

typedef struct select
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *test;
     obj_t clauses;
     struct type *item_type_130;
  }
      *select_t;

typedef struct let_fun_218
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t locals;
     struct node *body;
  }
           *let_fun_218_t;

typedef struct let_var_6
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     obj_t bindings;
     struct node *body;
     bool_t removable__42;
  }
         *let_var_6_t;

typedef struct set_ex_it_116
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *body;
  }
             *set_ex_it_116_t;

typedef struct jump_ex_it_184
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct node *exit;
     struct node *value;
  }
              *jump_ex_it_184_t;

typedef struct make_box_202
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct node *value;
  }
            *make_box_202_t;

typedef struct box_ref_242
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     obj_t side_effect__165;
     obj_t key;
     struct var *var;
  }
           *box_ref_242_t;

typedef struct box_set__221
  {
     header_t header;
     obj_t widening;
     obj_t loc;
     struct type *type;
     struct var *var;
     struct node *value;
  }
            *box_set__221_t;

typedef struct local_bvalue_105
  {
     struct node *binding_value_3;
  }
                *local_bvalue_105_t;


static obj_t method_init_76_cnst_node();
extern obj_t make_box_202_ast_node;
extern obj_t funcall_ast_node;
static obj_t get_node_atom_value_default1510_6_cnst_node(node_t);
extern obj_t _bfalse__69_cnst_cache;
extern obj_t _string__bstring__114_cnst_cache;
extern long add_inlined_method__244___object(obj_t, obj_t, long);
extern obj_t fail_ast_node;
extern obj_t box_ref_242_ast_node;
static obj_t _object__struct1886_128___object(obj_t, obj_t);
extern obj_t _make_fx_procedure__51_cnst_cache;
extern obj_t sequence_ast_node;
extern node_t cnst_alloc_procedure_240_cnst_alloc(node_t, obj_t);
extern obj_t let_var_6_ast_node;
extern obj_t var_ast_node;
static obj_t get_node_atom_value_135_cnst_node(node_t);
extern obj_t closure_ast_node;
extern object_t struct_object__object_93___object(object_t, obj_t);
extern obj_t add_method__1___object(obj_t, obj_t, obj_t);
extern obj_t _btrue__29_cnst_cache;
extern obj_t pragma_ast_node;
extern obj_t set_ex_it_116_ast_node;
extern obj_t find_super_class_method_167___object(object_t, obj_t, obj_t);
extern bool_t is_a__118___object(obj_t, obj_t);
extern obj_t module_initialization_70_cnst_node(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_type_cache(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70_ast_node(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_cnst_cache(long, char *);
extern obj_t module_initialization_70_cnst_alloc(long, char *);
extern obj_t module_initialization_70___object(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
static obj_t _allocate_local_bvalue_102_cnst_node(obj_t);
static obj_t _cnst_1887_206_cnst_node(obj_t, obj_t);
extern obj_t _double__real__21_cnst_cache;
extern long class_num_218___object(obj_t);
extern obj_t let_fun_218_ast_node;
static obj_t imported_modules_init_94_cnst_node();
extern node_t cnst_alloc_list_56_cnst_alloc(obj_t, obj_t);
static obj_t _struct_object__object1884_129___object(obj_t, obj_t, obj_t);
extern obj_t app_ly_162_ast_node;
extern obj_t add_generic__110___object(obj_t, obj_t);
extern node_t cnst_alloc_real_118_cnst_alloc(obj_t, obj_t);
static obj_t local_bvalue_105_cnst_node = BUNSPEC;
extern obj_t app_ast_node;
static obj_t library_modules_init_112_cnst_node();
static obj_t struct_object__object_local_bvalue_206_cnst_node(obj_t, obj_t, obj_t);
static obj_t _get_node_atom_value1888_155_cnst_node(obj_t, obj_t);
extern obj_t make_struct(obj_t, long, obj_t);
extern obj_t atom_ast_node;
extern obj_t add_class__117___object(obj_t, obj_t, obj_t, long, obj_t, obj_t);
extern obj_t cast_ast_node;
static obj_t toplevel_init_63_cnst_node();
extern obj_t jump_ex_it_184_ast_node;
extern obj_t open_input_string(obj_t);
extern obj_t kwote_ast_node;
static obj_t cnst___82_cnst_node(obj_t);
extern obj_t setq_ast_node;
extern obj_t _bbool__55_type_cache;
extern node_t cnst_alloc_tvector_190_cnst_alloc(obj_t, obj_t);
static local_t allocate_local_bvalue_47_cnst_node();
extern obj_t box_set__221_ast_node;
static obj_t _cnst__default1486_239_cnst_node(obj_t, obj_t);
extern obj_t local_ast_var;
extern node_t cnst_alloc_string_41_cnst_alloc(obj_t, obj_t);
extern node_t cnst_alloc_symbol_123_cnst_alloc(obj_t, obj_t);
extern obj_t shape_tools_shape(obj_t);
static node_t cnst__default1486_169_cnst_node(node_t);
extern obj_t internal_error_43_tools_error(obj_t, obj_t, obj_t);
static obj_t object_init_111_cnst_node();
extern obj_t _bool__bbool__85_cnst_cache;
extern obj_t _classes__134___object;
extern obj_t select_ast_node;
extern obj_t _make_va_procedure__53_cnst_cache;
extern obj_t read___reader(obj_t);
static obj_t _get_node_atom_value_default1510_92_cnst_node(obj_t, obj_t);
extern obj_t object__struct_50___object(object_t);
extern node_t cnst_alloc_vector_65_cnst_alloc(obj_t, obj_t);
static obj_t require_initialization_114_cnst_node = BUNSPEC;
extern obj_t conditional_ast_node;
static obj_t object__struct_local_bvalue_224_cnst_node(obj_t, obj_t);
extern node_t cnst_alloc_keyword_47_cnst_alloc(obj_t, obj_t);
extern node_t cnst__44_cnst_node(node_t);
static obj_t cnst_init_137_cnst_node();
static obj_t __cnst[6];

DEFINE_STATIC_PROCEDURE(proc1889_cnst_node, object__struct_local_bvalue_224_cnst_node1902, object__struct_local_bvalue_224_cnst_node, 0L, 1);
DEFINE_STATIC_PROCEDURE(proc1890_cnst_node, struct_object__object_local_bvalue_206_cnst_node1903, struct_object__object_local_bvalue_206_cnst_node, 0L, 2);
DEFINE_STATIC_PROCEDURE(get_node_atom_value_default1510_env_15_cnst_node, _get_node_atom_value_default1510_92_cnst_node1904, _get_node_atom_value_default1510_92_cnst_node, 0L, 1);
extern obj_t struct_object__object_env_209___object;
DEFINE_EXPORT_GENERIC(cnst__env_43_cnst_node, _cnst_1887_206_cnst_node1905, _cnst_1887_206_cnst_node, 0L, 1);
DEFINE_STATIC_GENERIC(get_node_atom_value_env_18_cnst_node, _get_node_atom_value1888_155_cnst_node1906, _get_node_atom_value1888_155_cnst_node, 0L, 1);
DEFINE_STRING(string1896_cnst_node, string1896_cnst_node1907, "(NO-ATOM-VALUE) CNST!-DEFAULT1486 READ A-TVECTOR LOCAL/BVALUE DONE ", 67);
DEFINE_STRING(string1895_cnst_node, string1895_cnst_node1908, "No method for this object", 25);
DEFINE_STRING(string1894_cnst_node, string1894_cnst_node1909, "Unexepected `closure' node", 26);
DEFINE_STRING(string1893_cnst_node, string1893_cnst_node1910, "cnst!", 5);
DEFINE_STRING(string1892_cnst_node, string1892_cnst_node1911, "Illegal expression", 18);
DEFINE_STRING(string1891_cnst_node, string1891_cnst_node1912, "cnst-quote", 10);
DEFINE_STATIC_PROCEDURE(cnst__default1486_env_182_cnst_node, _cnst__default1486_239_cnst_node1913, _cnst__default1486_239_cnst_node, 0L, 1);
extern obj_t object__struct_env_210___object;
DEFINE_STATIC_PROCEDURE(allocate_local_bvalue_env_61_cnst_node, _allocate_local_bvalue_102_cnst_node1914, _allocate_local_bvalue_102_cnst_node, 0L, 0);


/* module-initialization */ obj_t 
module_initialization_70_cnst_node(long checksum_1792, char *from_1793)
{
   if (CBOOL(require_initialization_114_cnst_node))
     {
	require_initialization_114_cnst_node = BBOOL(((bool_t) 0));
	library_modules_init_112_cnst_node();
	cnst_init_137_cnst_node();
	imported_modules_init_94_cnst_node();
	object_init_111_cnst_node();
	method_init_76_cnst_node();
	toplevel_init_63_cnst_node();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_cnst_node()
{
   module_initialization_70___object(((long) 0), "CNST_NODE");
   module_initialization_70___reader(((long) 0), "CNST_NODE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_cnst_node()
{
   {
      obj_t cnst_port_138_1784;
      cnst_port_138_1784 = open_input_string(string1896_cnst_node);
      {
	 long i_1785;
	 i_1785 = ((long) 5);
       loop_1786:
	 {
	    bool_t test1897_1787;
	    test1897_1787 = (i_1785 == ((long) -1));
	    if (test1897_1787)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1898_1788;
		    {
		       obj_t list1899_1789;
		       {
			  obj_t arg1900_1790;
			  arg1900_1790 = BNIL;
			  list1899_1789 = MAKE_PAIR(cnst_port_138_1784, arg1900_1790);
		       }
		       arg1898_1788 = read___reader(list1899_1789);
		    }
		    CNST_TABLE_SET(i_1785, arg1898_1788);
		 }
		 {
		    int aux_1791;
		    {
		       long aux_1811;
		       aux_1811 = (i_1785 - ((long) 1));
		       aux_1791 = (int) (aux_1811);
		    }
		    {
		       long i_1814;
		       i_1814 = (long) (aux_1791);
		       i_1785 = i_1814;
		       goto loop_1786;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_cnst_node()
{
   return BUNSPEC;
}


/* cnst*! */ obj_t 
cnst___82_cnst_node(obj_t nodes_33)
{
   {
      obj_t hook_790;
      hook_790 = nodes_33;
    loop_791:
      if (NULLP(hook_790))
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   {
	      node_t arg1535_793;
	      {
		 node_t aux_1819;
		 {
		    obj_t aux_1820;
		    aux_1820 = CAR(hook_790);
		    aux_1819 = (node_t) (aux_1820);
		 }
		 arg1535_793 = cnst__44_cnst_node(aux_1819);
	      }
	      {
		 obj_t aux_1824;
		 aux_1824 = (obj_t) (arg1535_793);
		 SET_CAR(hook_790, aux_1824);
	      }
	   }
	   {
	      obj_t hook_1827;
	      hook_1827 = CDR(hook_790);
	      hook_790 = hook_1827;
	      goto loop_791;
	   }
	}
   }
}


/* object-init */ obj_t 
object_init_111_cnst_node()
{
   {
      obj_t arg1540_797;
      arg1540_797 = local_ast_var;
      local_bvalue_105_cnst_node = add_class__117___object(CNST_TABLE_REF(((long) 1)), arg1540_797, allocate_local_bvalue_env_61_cnst_node, ((long) 36702), BUNSPEC, BFALSE);
   }
   return BUNSPEC;
}


/* allocate-local/bvalue */ local_t 
allocate_local_bvalue_47_cnst_node()
{
   {
      local_t new1449_800;
      new1449_800 = ((local_t) BREF(GC_MALLOC(sizeof(struct local))));
      {
	 long arg1548_801;
	 arg1548_801 = class_num_218___object(local_bvalue_105_cnst_node);
	 {
	    obj_t obj_1419;
	    obj_1419 = (obj_t) (new1449_800);
	    (((obj_t) CREF(obj_1419))->header = MAKE_HEADER(arg1548_801, 0), BUNSPEC);
	 }
      }
      {
	 object_t aux_1835;
	 aux_1835 = (object_t) (new1449_800);
	 OBJECT_WIDENING_SET(aux_1835, BFALSE);
      }
      return new1449_800;
   }
}


/* _allocate-local/bvalue */ obj_t 
_allocate_local_bvalue_102_cnst_node(obj_t env_1762)
{
   {
      local_t aux_1838;
      aux_1838 = allocate_local_bvalue_47_cnst_node();
      return (obj_t) (aux_1838);
   }
}


/* method-init */ obj_t 
method_init_76_cnst_node()
{
   add_generic__110___object(cnst__env_43_cnst_node, cnst__default1486_env_182_cnst_node);
   add_inlined_method__244___object(cnst__env_43_cnst_node, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(cnst__env_43_cnst_node, kwote_ast_node, ((long) 1));
   add_inlined_method__244___object(cnst__env_43_cnst_node, var_ast_node, ((long) 2));
   add_inlined_method__244___object(cnst__env_43_cnst_node, closure_ast_node, ((long) 3));
   add_inlined_method__244___object(cnst__env_43_cnst_node, sequence_ast_node, ((long) 4));
   add_inlined_method__244___object(cnst__env_43_cnst_node, pragma_ast_node, ((long) 5));
   add_inlined_method__244___object(cnst__env_43_cnst_node, cast_ast_node, ((long) 6));
   add_inlined_method__244___object(cnst__env_43_cnst_node, setq_ast_node, ((long) 7));
   add_inlined_method__244___object(cnst__env_43_cnst_node, conditional_ast_node, ((long) 8));
   add_inlined_method__244___object(cnst__env_43_cnst_node, fail_ast_node, ((long) 9));
   add_inlined_method__244___object(cnst__env_43_cnst_node, select_ast_node, ((long) 10));
   add_inlined_method__244___object(cnst__env_43_cnst_node, let_fun_218_ast_node, ((long) 11));
   add_inlined_method__244___object(cnst__env_43_cnst_node, let_var_6_ast_node, ((long) 12));
   add_inlined_method__244___object(cnst__env_43_cnst_node, set_ex_it_116_ast_node, ((long) 13));
   add_inlined_method__244___object(cnst__env_43_cnst_node, jump_ex_it_184_ast_node, ((long) 14));
   add_inlined_method__244___object(cnst__env_43_cnst_node, make_box_202_ast_node, ((long) 15));
   add_inlined_method__244___object(cnst__env_43_cnst_node, box_ref_242_ast_node, ((long) 16));
   add_inlined_method__244___object(cnst__env_43_cnst_node, box_set__221_ast_node, ((long) 17));
   add_inlined_method__244___object(cnst__env_43_cnst_node, app_ly_162_ast_node, ((long) 18));
   add_inlined_method__244___object(cnst__env_43_cnst_node, funcall_ast_node, ((long) 19));
   add_inlined_method__244___object(cnst__env_43_cnst_node, app_ast_node, ((long) 20));
   add_generic__110___object(get_node_atom_value_env_18_cnst_node, get_node_atom_value_default1510_env_15_cnst_node);
   add_inlined_method__244___object(get_node_atom_value_env_18_cnst_node, atom_ast_node, ((long) 0));
   add_inlined_method__244___object(get_node_atom_value_env_18_cnst_node, var_ast_node, ((long) 1));
   {
      obj_t object__struct_local_bvalue_224_1767;
      object__struct_local_bvalue_224_1767 = proc1889_cnst_node;
      add_method__1___object(object__struct_env_210___object, local_bvalue_105_cnst_node, object__struct_local_bvalue_224_1767);
   }
   {
      obj_t struct_object__object_local_bvalue_206_1763;
      struct_object__object_local_bvalue_206_1763 = proc1890_cnst_node;
      return add_method__1___object(struct_object__object_env_209___object, local_bvalue_105_cnst_node, struct_object__object_local_bvalue_206_1763);
   }
}


/* struct+object->object-local/bvalue */ obj_t 
struct_object__object_local_bvalue_206_cnst_node(obj_t env_1770, obj_t o_1771, obj_t s_1772)
{
   {
      local_bvalue_105_t o_1146;
      obj_t s_1147;
      {
	 local_bvalue_105_t aux_1868;
	 o_1146 = (local_bvalue_105_t) (o_1771);
	 s_1147 = s_1772;
	 {
	    {
	       obj_t old1453_1150;
	       obj_t aux1454_1151;
	       {
		  obj_t next_method1514_49_1156;
		  next_method1514_49_1156 = find_super_class_method_167___object((object_t) (o_1146), struct_object__object_env_209___object, local_bvalue_105_cnst_node);
		  if (PROCEDUREP(next_method1514_49_1156))
		    {
		       old1453_1150 = PROCEDURE_ENTRY(next_method1514_49_1156) (next_method1514_49_1156, (obj_t) (o_1146), s_1147, BEOA);
		    }
		  else
		    {
		       PROCEDURE_SET(struct_object__object_env_209___object, ((long) 2), next_method1514_49_1156);
		       {
			  object_t aux_1877;
			  aux_1877 = struct_object__object_93___object((object_t) (o_1146), s_1147);
			  old1453_1150 = (obj_t) (aux_1877);
		       }
		    }
	       }
	       aux1454_1151 = STRUCT_REF(s_1147, ((long) 0));
	       {
		  local_bvalue_105_t new1455_1152;
		  new1455_1152 = ((local_bvalue_105_t) (old1453_1150));
		  {
		     long arg1655_1153;
		     arg1655_1153 = class_num_218___object(local_bvalue_105_cnst_node);
		     {
			obj_t obj_1470;
			obj_1470 = (obj_t) (new1455_1152);
			(((obj_t) CREF(obj_1470))->header = MAKE_HEADER(arg1655_1153, 0), BUNSPEC);
		     }
		  }
		  {
		     local_bvalue_105_t arg1656_1154;
		     {
			local_bvalue_105_t res1873_1477;
			{
			   node_t binding_value_3_1474;
			   {
			      obj_t aux_1886;
			      aux_1886 = STRUCT_REF(aux1454_1151, ((long) 0));
			      binding_value_3_1474 = (node_t) (aux_1886);
			   }
			   {
			      local_bvalue_105_t new1436_1475;
			      new1436_1475 = ((local_bvalue_105_t) BREF(GC_MALLOC(sizeof(struct local_bvalue_105))));
			      ((((local_bvalue_105_t) CREF(new1436_1475))->binding_value_3) = ((node_t) binding_value_3_1474), BUNSPEC);
			      res1873_1477 = new1436_1475;
			   }
			}
			arg1656_1154 = res1873_1477;
		     }
		     {
			obj_t aux_1893;
			object_t aux_1891;
			aux_1893 = (obj_t) (arg1656_1154);
			aux_1891 = (object_t) (new1455_1152);
			OBJECT_WIDENING_SET(aux_1891, aux_1893);
		     }
		  }
		  aux_1868 = new1455_1152;
	       }
	    }
	 }
	 return (obj_t) (aux_1868);
      }
   }
}


/* object->struct-local/bvalue */ obj_t 
object__struct_local_bvalue_224_cnst_node(obj_t env_1773, obj_t obj1450_1774)
{
   {
      local_bvalue_105_t obj1450_1133;
      obj1450_1133 = (local_bvalue_105_t) (obj1450_1774);
      {
	 {
	    obj_t res1451_1136;
	    {
	       obj_t next_method1513_223_1144;
	       next_method1513_223_1144 = find_super_class_method_167___object((object_t) (obj1450_1133), object__struct_env_210___object, local_bvalue_105_cnst_node);
	       if (PROCEDUREP(next_method1513_223_1144))
		 {
		    res1451_1136 = PROCEDURE_ENTRY(next_method1513_223_1144) (next_method1513_223_1144, (obj_t) (obj1450_1133), BEOA);
		 }
	       else
		 {
		    PROCEDURE_SET(object__struct_env_210___object, ((long) 2), next_method1513_223_1144);
		    res1451_1136 = object__struct_50___object((object_t) (obj1450_1133));
		 }
	    }
	    {
	       obj_t aux1452_1137;
	       {
		  obj_t aux_1908;
		  aux_1908 = CNST_TABLE_REF(((long) 1));
		  aux1452_1137 = make_struct(aux_1908, ((long) 1), BUNSPEC);
	       }
	       {
		  obj_t aux_1911;
		  {
		     node_t aux_1912;
		     {
			obj_t aux_1913;
			{
			   object_t aux_1914;
			   aux_1914 = (object_t) (obj1450_1133);
			   aux_1913 = OBJECT_WIDENING(aux_1914);
			}
			aux_1912 = (((local_bvalue_105_t) CREF(aux_1913))->binding_value_3);
		     }
		     aux_1911 = (obj_t) (aux_1912);
		  }
		  STRUCT_SET(aux1452_1137, ((long) 0), aux_1911);
	       }
	       STRUCT_SET(res1451_1136, ((long) 0), aux1452_1137);
	       {
		  obj_t aux_1921;
		  aux_1921 = STRUCT_KEY(res1451_1136);
		  STRUCT_KEY_SET(aux1452_1137, aux_1921);
	       }
	       {
		  obj_t aux_1924;
		  aux_1924 = CNST_TABLE_REF(((long) 1));
		  STRUCT_KEY_SET(res1451_1136, aux_1924);
	       }
	       return res1451_1136;
	    }
	 }
      }
   }
}


/* cnst! */ node_t 
cnst__44_cnst_node(node_t node_11)
{
   {
      obj_t method1686_1189;
      obj_t class1691_1190;
      {
	 obj_t arg1694_1187;
	 obj_t arg1695_1188;
	 {
	    object_t obj_1480;
	    obj_1480 = (object_t) (node_11);
	    {
	       obj_t pre_method_105_1481;
	       pre_method_105_1481 = PROCEDURE_REF(cnst__env_43_cnst_node, ((long) 2));
	       if (INTEGERP(pre_method_105_1481))
		 {
		    PROCEDURE_SET(cnst__env_43_cnst_node, ((long) 2), BUNSPEC);
		    arg1694_1187 = pre_method_105_1481;
		 }
	       else
		 {
		    long obj_class_num_177_1486;
		    obj_class_num_177_1486 = TYPE(obj_1480);
		    {
		       obj_t arg1177_1487;
		       arg1177_1487 = PROCEDURE_REF(cnst__env_43_cnst_node, ((long) 1));
		       {
			  long arg1178_1491;
			  {
			     long arg1179_1492;
			     arg1179_1492 = OBJECT_TYPE;
			     arg1178_1491 = (obj_class_num_177_1486 - arg1179_1492);
			  }
			  arg1694_1187 = VECTOR_REF(arg1177_1487, arg1178_1491);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1497;
	    object_1497 = (object_t) (node_11);
	    {
	       long arg1180_1498;
	       {
		  long arg1181_1499;
		  long arg1182_1500;
		  arg1181_1499 = TYPE(object_1497);
		  arg1182_1500 = OBJECT_TYPE;
		  arg1180_1498 = (arg1181_1499 - arg1182_1500);
	       }
	       {
		  obj_t vector_1504;
		  vector_1504 = _classes__134___object;
		  arg1695_1188 = VECTOR_REF(vector_1504, arg1180_1498);
	       }
	    }
	 }
	 {
	    obj_t aux_1943;
	    method1686_1189 = arg1694_1187;
	    class1691_1190 = arg1695_1188;
	    {
	       if (INTEGERP(method1686_1189))
		 {
		    switch ((long) CINT(method1686_1189))
		      {
		      case ((long) 0):
			 {
			    atom_t node_1196;
			    node_1196 = (atom_t) (node_11);
			    {
			       bool_t test_1947;
			       {
				  obj_t aux_1948;
				  aux_1948 = (((atom_t) CREF(node_1196))->value);
				  test_1947 = KEYWORDP(aux_1948);
			       }
			       if (test_1947)
				 {
				    {
				       node_t aux_1951;
				       aux_1951 = cnst_alloc_keyword_47_cnst_alloc((((atom_t) CREF(node_1196))->value), (((atom_t) CREF(node_1196))->loc));
				       aux_1943 = (obj_t) (aux_1951);
				    }
				 }
			       else
				 {
				    aux_1943 = (obj_t) (node_1196);
				 }
			    }
			 }
			 break;
		      case ((long) 1):
			 {
			    kwote_t node_1202;
			    node_1202 = (kwote_t) (node_11);
			    {
			       bool_t test_1958;
			       {
				  obj_t aux_1959;
				  aux_1959 = (((kwote_t) CREF(node_1202))->value);
				  test_1958 = SYMBOLP(aux_1959);
			       }
			       if (test_1958)
				 {
				    {
				       node_t aux_1962;
				       aux_1962 = cnst_alloc_symbol_123_cnst_alloc((((kwote_t) CREF(node_1202))->value), (((kwote_t) CREF(node_1202))->loc));
				       aux_1943 = (obj_t) (aux_1962);
				    }
				 }
			       else
				 {
				    bool_t test_1967;
				    {
				       obj_t aux_1968;
				       aux_1968 = (((kwote_t) CREF(node_1202))->value);
				       test_1967 = KEYWORDP(aux_1968);
				    }
				    if (test_1967)
				      {
					 {
					    node_t aux_1971;
					    aux_1971 = cnst_alloc_keyword_47_cnst_alloc((((kwote_t) CREF(node_1202))->value), (((kwote_t) CREF(node_1202))->loc));
					    aux_1943 = (obj_t) (aux_1971);
					 }
				      }
				    else
				      {
					 bool_t test_1976;
					 {
					    obj_t aux_1977;
					    aux_1977 = (((kwote_t) CREF(node_1202))->value);
					    test_1976 = PAIRP(aux_1977);
					 }
					 if (test_1976)
					   {
					      {
						 node_t aux_1980;
						 aux_1980 = cnst_alloc_list_56_cnst_alloc((((kwote_t) CREF(node_1202))->value), (((kwote_t) CREF(node_1202))->loc));
						 aux_1943 = (obj_t) (aux_1980);
					      }
					   }
					 else
					   {
					      bool_t test_1985;
					      {
						 obj_t aux_1986;
						 aux_1986 = (((kwote_t) CREF(node_1202))->value);
						 test_1985 = VECTORP(aux_1986);
					      }
					      if (test_1985)
						{
						   {
						      node_t aux_1989;
						      aux_1989 = cnst_alloc_vector_65_cnst_alloc((((kwote_t) CREF(node_1202))->value), (((kwote_t) CREF(node_1202))->loc));
						      aux_1943 = (obj_t) (aux_1989);
						   }
						}
					      else
						{
						   bool_t test_1994;
						   {
						      obj_t aux_1995;
						      aux_1995 = (((kwote_t) CREF(node_1202))->value);
						      test_1994 = STRINGP(aux_1995);
						   }
						   if (test_1994)
						     {
							{
							   node_t aux_1998;
							   aux_1998 = cnst_alloc_string_41_cnst_alloc((((kwote_t) CREF(node_1202))->value), (((kwote_t) CREF(node_1202))->loc));
							   aux_1943 = (obj_t) (aux_1998);
							}
						     }
						   else
						     {
							bool_t test_2003;
							{
							   obj_t arg1744_1238;
							   arg1744_1238 = (((kwote_t) CREF(node_1202))->value);
							   if (STRUCTP(arg1744_1238))
							     {
								obj_t aux_2009;
								obj_t aux_2007;
								aux_2009 = CNST_TABLE_REF(((long) 2));
								aux_2007 = STRUCT_KEY(arg1744_1238);
								test_2003 = (aux_2007 == aux_2009);
							     }
							   else
							     {
								test_2003 = ((bool_t) 0);
							     }
							}
							if (test_2003)
							  {
							     {
								node_t aux_2012;
								aux_2012 = cnst_alloc_tvector_190_cnst_alloc((((kwote_t) CREF(node_1202))->value), (((kwote_t) CREF(node_1202))->loc));
								aux_1943 = (obj_t) (aux_2012);
							     }
							  }
							else
							  {
							     bool_t test_2017;
							     {
								bool_t test_2018;
								{
								   obj_t aux_2019;
								   aux_2019 = (((kwote_t) CREF(node_1202))->value);
								   test_2018 = CHARP(aux_2019);
								}
								if (test_2018)
								  {
								     test_2017 = ((bool_t) 1);
								  }
								else
								  {
								     bool_t test_2022;
								     {
									obj_t aux_2023;
									aux_2023 = (((kwote_t) CREF(node_1202))->value);
									test_2022 = INTEGERP(aux_2023);
								     }
								     if (test_2022)
								       {
									  test_2017 = ((bool_t) 1);
								       }
								     else
								       {
									  bool_t test_2026;
									  {
									     obj_t aux_2027;
									     aux_2027 = (((kwote_t) CREF(node_1202))->value);
									     test_2026 = BOOLEANP(aux_2027);
									  }
									  if (test_2026)
									    {
									       test_2017 = ((bool_t) 1);
									    }
									  else
									    {
									       bool_t test_2030;
									       {
										  obj_t arg1738_1234;
										  arg1738_1234 = (((kwote_t) CREF(node_1202))->value);
										  if (INTEGERP(arg1738_1234))
										    {
										       test_2030 = ((bool_t) 1);
										    }
										  else
										    {
										       test_2030 = REALP(arg1738_1234);
										    }
									       }
									       if (test_2030)
										 {
										    test_2017 = ((bool_t) 1);
										 }
									       else
										 {
										    obj_t aux_2035;
										    aux_2035 = (((kwote_t) CREF(node_1202))->value);
										    test_2017 = CNSTP(aux_2035);
										 }
									    }
								       }
								  }
							     }
							     if (test_2017)
							       {
								  {
								     obj_t arg1723_1223;
								     type_t arg1724_1224;
								     obj_t arg1725_1225;
								     arg1723_1223 = (((kwote_t) CREF(node_1202))->loc);
								     arg1724_1224 = (((kwote_t) CREF(node_1202))->type);
								     arg1725_1225 = (((kwote_t) CREF(node_1202))->value);
								     {
									atom_t res1875_1566;
									{
									   atom_t new1199_1559;
									   new1199_1559 = ((atom_t) BREF(GC_MALLOC(sizeof(struct atom))));
									   {
									      long arg1606_1560;
									      arg1606_1560 = class_num_218___object(atom_ast_node);
									      {
										 obj_t obj_1564;
										 obj_1564 = (obj_t) (new1199_1559);
										 (((obj_t) CREF(obj_1564))->header = MAKE_HEADER(arg1606_1560, 0), BUNSPEC);
									      }
									   }
									   {
									      object_t aux_2045;
									      aux_2045 = (object_t) (new1199_1559);
									      OBJECT_WIDENING_SET(aux_2045, BFALSE);
									   }
									   ((((atom_t) CREF(new1199_1559))->loc) = ((obj_t) arg1723_1223), BUNSPEC);
									   ((((atom_t) CREF(new1199_1559))->type) = ((type_t) arg1724_1224), BUNSPEC);
									   ((((atom_t) CREF(new1199_1559))->value) = ((obj_t) arg1725_1225), BUNSPEC);
									   res1875_1566 = new1199_1559;
									}
									aux_1943 = (obj_t) (res1875_1566);
								     }
								  }
							       }
							     else
							       {
								  {
								     obj_t arg1728_1228;
								     arg1728_1228 = shape_tools_shape((obj_t) (node_1202));
								     aux_1943 = internal_error_43_tools_error(string1891_cnst_node, string1892_cnst_node, arg1728_1228);
								  }
							       }
							  }
						     }
						}
					   }
				      }
				 }
			    }
			 }
			 break;
		      case ((long) 2):
			 {
			    var_t aux_2055;
			    aux_2055 = (var_t) (node_11);
			    aux_1943 = (obj_t) (aux_2055);
			 }
			 break;
		      case ((long) 3):
			 {
			    obj_t arg1758_1248;
			    {
			       obj_t aux_2058;
			       {
				  closure_t aux_2059;
				  aux_2059 = (closure_t) (node_11);
				  aux_2058 = (obj_t) (aux_2059);
			       }
			       arg1758_1248 = shape_tools_shape(aux_2058);
			    }
			    aux_1943 = internal_error_43_tools_error(string1893_cnst_node, string1894_cnst_node, arg1758_1248);
			 }
			 break;
		      case ((long) 4):
			 {
			    sequence_t node_1249;
			    node_1249 = (sequence_t) (node_11);
			    cnst___82_cnst_node((((sequence_t) CREF(node_1249))->nodes));
			    aux_1943 = (obj_t) (node_1249);
			 }
			 break;
		      case ((long) 5):
			 {
			    pragma_t node_1252;
			    node_1252 = (pragma_t) (node_11);
			    cnst___82_cnst_node((((pragma_t) CREF(node_1252))->args));
			    aux_1943 = (obj_t) (node_1252);
			 }
			 break;
		      case ((long) 6):
			 {
			    cast_t node_1255;
			    node_1255 = (cast_t) (node_11);
			    cnst__44_cnst_node((((cast_t) CREF(node_1255))->arg));
			    aux_1943 = (obj_t) (node_1255);
			 }
			 break;
		      case ((long) 7):
			 {
			    setq_t node_1258;
			    node_1258 = (setq_t) (node_11);
			    {
			       node_t arg1762_1260;
			       arg1762_1260 = cnst__44_cnst_node((((setq_t) CREF(node_1258))->value));
			       ((((setq_t) CREF(node_1258))->value) = ((node_t) arg1762_1260), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1258);
			 }
			 break;
		      case ((long) 8):
			 {
			    conditional_t node_1262;
			    node_1262 = (conditional_t) (node_11);
			    {
			       node_t arg1766_1264;
			       arg1766_1264 = cnst__44_cnst_node((((conditional_t) CREF(node_1262))->test));
			       ((((conditional_t) CREF(node_1262))->test) = ((node_t) arg1766_1264), BUNSPEC);
			    }
			    {
			       node_t arg1768_1266;
			       arg1768_1266 = cnst__44_cnst_node((((conditional_t) CREF(node_1262))->true));
			       ((((conditional_t) CREF(node_1262))->true) = ((node_t) arg1768_1266), BUNSPEC);
			    }
			    {
			       node_t arg1770_1268;
			       arg1770_1268 = cnst__44_cnst_node((((conditional_t) CREF(node_1262))->false));
			       ((((conditional_t) CREF(node_1262))->false) = ((node_t) arg1770_1268), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1262);
			 }
			 break;
		      case ((long) 9):
			 {
			    fail_t node_1270;
			    node_1270 = (fail_t) (node_11);
			    {
			       node_t arg1772_1272;
			       arg1772_1272 = cnst__44_cnst_node((((fail_t) CREF(node_1270))->proc));
			       ((((fail_t) CREF(node_1270))->proc) = ((node_t) arg1772_1272), BUNSPEC);
			    }
			    {
			       node_t arg1774_1274;
			       arg1774_1274 = cnst__44_cnst_node((((fail_t) CREF(node_1270))->msg));
			       ((((fail_t) CREF(node_1270))->msg) = ((node_t) arg1774_1274), BUNSPEC);
			    }
			    {
			       node_t arg1777_1276;
			       arg1777_1276 = cnst__44_cnst_node((((fail_t) CREF(node_1270))->obj));
			       ((((fail_t) CREF(node_1270))->obj) = ((node_t) arg1777_1276), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1270);
			 }
			 break;
		      case ((long) 10):
			 {
			    select_t node_1278;
			    node_1278 = (select_t) (node_11);
			    {
			       node_t arg1779_1280;
			       arg1779_1280 = cnst__44_cnst_node((((select_t) CREF(node_1278))->test));
			       ((((select_t) CREF(node_1278))->test) = ((node_t) arg1779_1280), BUNSPEC);
			    }
			    {
			       obj_t l1466_1282;
			       l1466_1282 = (((select_t) CREF(node_1278))->clauses);
			     lname1467_1283:
			       if (PAIRP(l1466_1282))
				 {
				    {
				       obj_t clause_1286;
				       clause_1286 = CAR(l1466_1282);
				       {
					  node_t arg1783_1287;
					  {
					     node_t aux_2110;
					     {
						obj_t aux_2111;
						aux_2111 = CDR(clause_1286);
						aux_2110 = (node_t) (aux_2111);
					     }
					     arg1783_1287 = cnst__44_cnst_node(aux_2110);
					  }
					  {
					     obj_t aux_2115;
					     aux_2115 = (obj_t) (arg1783_1287);
					     SET_CDR(clause_1286, aux_2115);
					  }
				       }
				    }
				    {
				       obj_t l1466_2118;
				       l1466_2118 = CDR(l1466_1282);
				       l1466_1282 = l1466_2118;
				       goto lname1467_1283;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    aux_1943 = (obj_t) (node_1278);
			 }
			 break;
		      case ((long) 11):
			 {
			    let_fun_218_t node_1290;
			    node_1290 = (let_fun_218_t) (node_11);
			    {
			       obj_t l1469_1292;
			       l1469_1292 = (((let_fun_218_t) CREF(node_1290))->locals);
			     lname1470_1293:
			       if (PAIRP(l1469_1292))
				 {
				    {
				       value_t fun_1297;
				       {
					  local_t obj_1604;
					  {
					     obj_t aux_2125;
					     aux_2125 = CAR(l1469_1292);
					     obj_1604 = (local_t) (aux_2125);
					  }
					  fun_1297 = (((local_t) CREF(obj_1604))->value);
				       }
				       {
					  node_t arg1791_1298;
					  {
					     node_t aux_2129;
					     {
						obj_t aux_2130;
						{
						   sfun_t obj_1605;
						   obj_1605 = (sfun_t) (fun_1297);
						   aux_2130 = (((sfun_t) CREF(obj_1605))->body);
						}
						aux_2129 = (node_t) (aux_2130);
					     }
					     arg1791_1298 = cnst__44_cnst_node(aux_2129);
					  }
					  {
					     sfun_t obj_1606;
					     obj_t val1136_1607;
					     obj_1606 = (sfun_t) (fun_1297);
					     val1136_1607 = (obj_t) (arg1791_1298);
					     ((((sfun_t) CREF(obj_1606))->body) = ((obj_t) val1136_1607), BUNSPEC);
					  }
				       }
				    }
				    {
				       obj_t l1469_2138;
				       l1469_2138 = CDR(l1469_1292);
				       l1469_1292 = l1469_2138;
				       goto lname1470_1293;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1794_1301;
			       arg1794_1301 = cnst__44_cnst_node((((let_fun_218_t) CREF(node_1290))->body));
			       ((((let_fun_218_t) CREF(node_1290))->body) = ((node_t) arg1794_1301), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1290);
			 }
			 break;
		      case ((long) 12):
			 {
			    let_var_6_t node_1303;
			    node_1303 = (let_var_6_t) (node_11);
			    {
			       obj_t l1472_1305;
			       l1472_1305 = (((let_var_6_t) CREF(node_1303))->bindings);
			     lname1473_1306:
			       if (PAIRP(l1472_1305))
				 {
				    {
				       obj_t binding_1309;
				       binding_1309 = CAR(l1472_1305);
				       {
					  obj_t var_1310;
					  var_1310 = CAR(binding_1309);
					  {
					     node_t arg1799_1311;
					     {
						node_t aux_2150;
						{
						   obj_t aux_2151;
						   aux_2151 = CDR(binding_1309);
						   aux_2150 = (node_t) (aux_2151);
						}
						arg1799_1311 = cnst__44_cnst_node(aux_2150);
					     }
					     {
						obj_t aux_2155;
						aux_2155 = (obj_t) (arg1799_1311);
						SET_CDR(binding_1309, aux_2155);
					     }
					  }
					  {
					     bool_t test_2158;
					     {
						obj_t aux_2162;
						obj_t aux_2159;
						aux_2162 = CNST_TABLE_REF(((long) 3));
						{
						   local_t obj_1619;
						   obj_1619 = (local_t) (var_1310);
						   aux_2159 = (((local_t) CREF(obj_1619))->access);
						}
						test_2158 = (aux_2159 == aux_2162);
					     }
					     if (test_2158)
					       {
						  local_bvalue_105_t obj1475_1314;
						  obj1475_1314 = ((local_bvalue_105_t) (var_1310));
						  {
						     local_bvalue_105_t arg1802_1315;
						     {
							local_bvalue_105_t res1876_1626;
							{
							   node_t binding_value_3_1623;
							   {
							      obj_t aux_2166;
							      aux_2166 = CDR(binding_1309);
							      binding_value_3_1623 = (node_t) (aux_2166);
							   }
							   {
							      local_bvalue_105_t new1436_1624;
							      new1436_1624 = ((local_bvalue_105_t) BREF(GC_MALLOC(sizeof(struct local_bvalue_105))));
							      ((((local_bvalue_105_t) CREF(new1436_1624))->binding_value_3) = ((node_t) binding_value_3_1623), BUNSPEC);
							      res1876_1626 = new1436_1624;
							   }
							}
							arg1802_1315 = res1876_1626;
						     }
						     {
							obj_t aux_2173;
							object_t aux_2171;
							aux_2173 = (obj_t) (arg1802_1315);
							aux_2171 = (object_t) (obj1475_1314);
							OBJECT_WIDENING_SET(aux_2171, aux_2173);
						     }
						  }
						  {
						     long arg1804_1317;
						     arg1804_1317 = class_num_218___object(local_bvalue_105_cnst_node);
						     {
							obj_t obj_1627;
							obj_1627 = (obj_t) (obj1475_1314);
							(((obj_t) CREF(obj_1627))->header = MAKE_HEADER(arg1804_1317, 0), BUNSPEC);
						     }
						  }
						  (obj_t) (obj1475_1314);
					       }
					     else
					       {
						  BUNSPEC;
					       }
					  }
				       }
				    }
				    {
				       obj_t l1472_2180;
				       l1472_2180 = CDR(l1472_1305);
				       l1472_1305 = l1472_2180;
				       goto lname1473_1306;
				    }
				 }
			       else
				 {
				    ((bool_t) 1);
				 }
			    }
			    {
			       node_t arg1808_1321;
			       arg1808_1321 = cnst__44_cnst_node((((let_var_6_t) CREF(node_1303))->body));
			       ((((let_var_6_t) CREF(node_1303))->body) = ((node_t) arg1808_1321), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1303);
			 }
			 break;
		      case ((long) 13):
			 {
			    set_ex_it_116_t node_1323;
			    node_1323 = (set_ex_it_116_t) (node_11);
			    {
			       node_t arg1810_1325;
			       arg1810_1325 = cnst__44_cnst_node((((set_ex_it_116_t) CREF(node_1323))->body));
			       ((((set_ex_it_116_t) CREF(node_1323))->body) = ((node_t) arg1810_1325), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1323);
			 }
			 break;
		      case ((long) 14):
			 {
			    jump_ex_it_184_t node_1327;
			    node_1327 = (jump_ex_it_184_t) (node_11);
			    {
			       node_t arg1812_1329;
			       arg1812_1329 = cnst__44_cnst_node((((jump_ex_it_184_t) CREF(node_1327))->exit));
			       ((((jump_ex_it_184_t) CREF(node_1327))->exit) = ((node_t) arg1812_1329), BUNSPEC);
			    }
			    {
			       node_t arg1814_1331;
			       arg1814_1331 = cnst__44_cnst_node((((jump_ex_it_184_t) CREF(node_1327))->value));
			       ((((jump_ex_it_184_t) CREF(node_1327))->value) = ((node_t) arg1814_1331), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1327);
			 }
			 break;
		      case ((long) 15):
			 {
			    make_box_202_t node_1333;
			    node_1333 = (make_box_202_t) (node_11);
			    {
			       node_t arg1816_1335;
			       arg1816_1335 = cnst__44_cnst_node((((make_box_202_t) CREF(node_1333))->value));
			       ((((make_box_202_t) CREF(node_1333))->value) = ((node_t) arg1816_1335), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1333);
			 }
			 break;
		      case ((long) 16):
			 {
			    box_ref_242_t node_1337;
			    node_1337 = (box_ref_242_t) (node_11);
			    {
			       node_t arg1818_1339;
			       {
				  node_t aux_2206;
				  {
				     var_t aux_2207;
				     aux_2207 = (((box_ref_242_t) CREF(node_1337))->var);
				     aux_2206 = (node_t) (aux_2207);
				  }
				  arg1818_1339 = cnst__44_cnst_node(aux_2206);
			       }
			       {
				  var_t val1424_1647;
				  val1424_1647 = (var_t) (arg1818_1339);
				  ((((box_ref_242_t) CREF(node_1337))->var) = ((var_t) val1424_1647), BUNSPEC);
			       }
			    }
			    aux_1943 = (obj_t) (node_1337);
			 }
			 break;
		      case ((long) 17):
			 {
			    box_set__221_t node_1341;
			    node_1341 = (box_set__221_t) (node_11);
			    {
			       node_t arg1821_1343;
			       {
				  node_t aux_2215;
				  {
				     var_t aux_2216;
				     aux_2216 = (((box_set__221_t) CREF(node_1341))->var);
				     aux_2215 = (node_t) (aux_2216);
				  }
				  arg1821_1343 = cnst__44_cnst_node(aux_2215);
			       }
			       {
				  var_t val1433_1650;
				  val1433_1650 = (var_t) (arg1821_1343);
				  ((((box_set__221_t) CREF(node_1341))->var) = ((var_t) val1433_1650), BUNSPEC);
			       }
			    }
			    {
			       node_t arg1823_1345;
			       arg1823_1345 = cnst__44_cnst_node((((box_set__221_t) CREF(node_1341))->value));
			       ((((box_set__221_t) CREF(node_1341))->value) = ((node_t) arg1823_1345), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1341);
			 }
			 break;
		      case ((long) 18):
			 {
			    app_ly_162_t node_1347;
			    node_1347 = (app_ly_162_t) (node_11);
			    {
			       node_t arg1826_1349;
			       arg1826_1349 = cnst__44_cnst_node((((app_ly_162_t) CREF(node_1347))->fun));
			       ((((app_ly_162_t) CREF(node_1347))->fun) = ((node_t) arg1826_1349), BUNSPEC);
			    }
			    {
			       node_t arg1829_1351;
			       arg1829_1351 = cnst__44_cnst_node((((app_ly_162_t) CREF(node_1347))->arg));
			       ((((app_ly_162_t) CREF(node_1347))->arg) = ((node_t) arg1829_1351), BUNSPEC);
			    }
			    aux_1943 = (obj_t) (node_1347);
			 }
			 break;
		      case ((long) 19):
			 {
			    funcall_t node_1353;
			    node_1353 = (funcall_t) (node_11);
			    {
			       node_t arg1831_1355;
			       arg1831_1355 = cnst__44_cnst_node((((funcall_t) CREF(node_1353))->fun));
			       ((((funcall_t) CREF(node_1353))->fun) = ((node_t) arg1831_1355), BUNSPEC);
			    }
			    cnst___82_cnst_node((((funcall_t) CREF(node_1353))->args));
			    aux_1943 = (obj_t) (node_1353);
			 }
			 break;
		      case ((long) 20):
			 {
			    app_t node_1358;
			    node_1358 = (app_t) (node_11);
			    cnst___82_cnst_node((((app_t) CREF(node_1358))->args));
			    {
			       bool_t test_2244;
			       {
				  obj_t aux_2245;
				  aux_2245 = (((app_t) CREF(node_1358))->args);
				  test_2244 = NULLP(aux_2245);
			       }
			       if (test_2244)
				 {
				    aux_1943 = (obj_t) (node_1358);
				 }
			       else
				 {
				    variable_t fun_1362;
				    {
				       var_t arg1865_1389;
				       arg1865_1389 = (((app_t) CREF(node_1358))->fun);
				       fun_1362 = (((var_t) CREF(arg1865_1389))->variable);
				    }
				    {
				       obj_t actual_value_16_1364;
				       {
					  node_t aux_2251;
					  {
					     obj_t aux_2252;
					     {
						obj_t aux_2253;
						aux_2253 = (((app_t) CREF(node_1358))->args);
						aux_2252 = CAR(aux_2253);
					     }
					     aux_2251 = (node_t) (aux_2252);
					  }
					  actual_value_16_1364 = get_node_atom_value_135_cnst_node(aux_2251);
				       }
				       {
					  {
					     bool_t test1836_1365;
					     {
						obj_t obj2_1672;
						obj2_1672 = _string__bstring__114_cnst_cache;
						{
						   obj_t aux_2258;
						   aux_2258 = (obj_t) (fun_1362);
						   test1836_1365 = (aux_2258 == obj2_1672);
						}
					     }
					     if (test1836_1365)
					       {
						  if (STRINGP(actual_value_16_1364))
						    {
						       node_t r_1367;
						       r_1367 = cnst_alloc_string_41_cnst_alloc(actual_value_16_1364, (((app_t) CREF(node_1358))->loc));
						       aux_1943 = (obj_t) (r_1367);
						    }
						  else
						    {
						       aux_1943 = (obj_t) (node_1358);
						    }
					       }
					     else
					       {
						  bool_t test1839_1369;
						  {
						     obj_t obj2_1676;
						     obj2_1676 = _bool__bbool__85_cnst_cache;
						     {
							obj_t aux_2268;
							aux_2268 = (obj_t) (fun_1362);
							test1839_1369 = (aux_2268 == obj2_1676);
						     }
						  }
						  if (test1839_1369)
						    {
						       if (BOOLEANP(actual_value_16_1364))
							 {
							    if (CBOOL(actual_value_16_1364))
							      {
								 obj_t arg1842_1371;
								 obj_t arg1843_1372;
								 obj_t arg1847_1373;
								 arg1842_1371 = (((app_t) CREF(node_1358))->loc);
								 arg1843_1372 = _bbool__55_type_cache;
								 arg1847_1373 = _btrue__29_cnst_cache;
								 {
								    var_t res1877_1689;
								    {
								       type_t type_1680;
								       variable_t variable_1681;
								       type_1680 = (type_t) (arg1843_1372);
								       variable_1681 = (variable_t) (arg1847_1373);
								       {
									  var_t new1207_1682;
									  new1207_1682 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
									  {
									     long arg1603_1683;
									     arg1603_1683 = class_num_218___object(var_ast_node);
									     {
										obj_t obj_1687;
										obj_1687 = (obj_t) (new1207_1682);
										(((obj_t) CREF(obj_1687))->header = MAKE_HEADER(arg1603_1683, 0), BUNSPEC);
									     }
									  }
									  {
									     object_t aux_2283;
									     aux_2283 = (object_t) (new1207_1682);
									     OBJECT_WIDENING_SET(aux_2283, BFALSE);
									  }
									  ((((var_t) CREF(new1207_1682))->loc) = ((obj_t) arg1842_1371), BUNSPEC);
									  ((((var_t) CREF(new1207_1682))->type) = ((type_t) type_1680), BUNSPEC);
									  ((((var_t) CREF(new1207_1682))->variable) = ((variable_t) variable_1681), BUNSPEC);
									  res1877_1689 = new1207_1682;
								       }
								    }
								    aux_1943 = (obj_t) (res1877_1689);
								 }
							      }
							    else
							      {
								 obj_t arg1848_1374;
								 obj_t arg1850_1375;
								 obj_t arg1851_1376;
								 arg1848_1374 = (((app_t) CREF(node_1358))->loc);
								 arg1850_1375 = _bbool__55_type_cache;
								 arg1851_1376 = _bfalse__69_cnst_cache;
								 {
								    var_t res1878_1701;
								    {
								       type_t type_1692;
								       variable_t variable_1693;
								       type_1692 = (type_t) (arg1850_1375);
								       variable_1693 = (variable_t) (arg1851_1376);
								       {
									  var_t new1207_1694;
									  new1207_1694 = ((var_t) BREF(GC_MALLOC(sizeof(struct var))));
									  {
									     long arg1603_1695;
									     arg1603_1695 = class_num_218___object(var_ast_node);
									     {
										obj_t obj_1699;
										obj_1699 = (obj_t) (new1207_1694);
										(((obj_t) CREF(obj_1699))->header = MAKE_HEADER(arg1603_1695, 0), BUNSPEC);
									     }
									  }
									  {
									     object_t aux_2297;
									     aux_2297 = (object_t) (new1207_1694);
									     OBJECT_WIDENING_SET(aux_2297, BFALSE);
									  }
									  ((((var_t) CREF(new1207_1694))->loc) = ((obj_t) arg1848_1374), BUNSPEC);
									  ((((var_t) CREF(new1207_1694))->type) = ((type_t) type_1692), BUNSPEC);
									  ((((var_t) CREF(new1207_1694))->variable) = ((variable_t) variable_1693), BUNSPEC);
									  res1878_1701 = new1207_1694;
								       }
								    }
								    aux_1943 = (obj_t) (res1878_1701);
								 }
							      }
							 }
						       else
							 {
							    aux_1943 = (obj_t) (node_1358);
							 }
						    }
						  else
						    {
						       bool_t test1852_1377;
						       {
							  bool_t test1863_1387;
							  {
							     obj_t obj2_1703;
							     obj2_1703 = _make_fx_procedure__51_cnst_cache;
							     {
								obj_t aux_2305;
								aux_2305 = (obj_t) (fun_1362);
								test1863_1387 = (aux_2305 == obj2_1703);
							     }
							  }
							  if (test1863_1387)
							    {
							       test1852_1377 = ((bool_t) 1);
							    }
							  else
							    {
							       obj_t obj2_1705;
							       obj2_1705 = _make_va_procedure__53_cnst_cache;
							       {
								  obj_t aux_2309;
								  aux_2309 = (obj_t) (fun_1362);
								  test1852_1377 = (aux_2309 == obj2_1705);
							       }
							    }
						       }
						       if (test1852_1377)
							 {
							    {
							       obj_t size_value_33_1378;
							       {
								  node_t aux_2313;
								  {
								     obj_t aux_2314;
								     {
									obj_t aux_2315;
									{
									   obj_t aux_2316;
									   {
									      obj_t aux_2317;
									      aux_2317 = (((app_t) CREF(node_1358))->args);
									      aux_2316 = CDR(aux_2317);
									   }
									   aux_2315 = CDR(aux_2316);
									}
									aux_2314 = CAR(aux_2315);
								     }
								     aux_2313 = (node_t) (aux_2314);
								  }
								  size_value_33_1378 = get_node_atom_value_135_cnst_node(aux_2313);
							       }
							       {
								  bool_t test_2324;
								  if (INTEGERP(size_value_33_1378))
								    {
								       long aux_2327;
								       aux_2327 = (long) CINT(size_value_33_1378);
								       test_2324 = (aux_2327 == ((long) 0));
								    }
								  else
								    {
								       test_2324 = ((bool_t) 0);
								    }
								  if (test_2324)
								    {
								       node_t aux_2330;
								       aux_2330 = cnst_alloc_procedure_240_cnst_alloc((node_t) (node_1358), (((app_t) CREF(node_1358))->loc));
								       aux_1943 = (obj_t) (aux_2330);
								    }
								  else
								    {
								       aux_1943 = (obj_t) (node_1358);
								    }
							       }
							    }
							 }
						       else
							 {
							    bool_t test1860_1384;
							    {
							       obj_t obj2_1718;
							       obj2_1718 = _double__real__21_cnst_cache;
							       {
								  obj_t aux_2336;
								  aux_2336 = (obj_t) (fun_1362);
								  test1860_1384 = (aux_2336 == obj2_1718);
							       }
							    }
							    if (test1860_1384)
							      {
								 {
								    bool_t test_2340;
								    if (INTEGERP(actual_value_16_1364))
								      {
									 test_2340 = ((bool_t) 1);
								      }
								    else
								      {
									 test_2340 = REALP(actual_value_16_1364);
								      }
								    if (test_2340)
								      {
									 node_t aux_2344;
									 aux_2344 = cnst_alloc_real_118_cnst_alloc(actual_value_16_1364, (((app_t) CREF(node_1358))->loc));
									 aux_1943 = (obj_t) (aux_2344);
								      }
								    else
								      {
									 aux_1943 = (obj_t) (node_1358);
								      }
								 }
							      }
							    else
							      {
								 aux_1943 = (obj_t) (node_1358);
							      }
							 }
						    }
					       }
					  }
				       }
				    }
				 }
			    }
			 }
			 break;
		      default:
		       case_else1692_1193:
			 if (PROCEDUREP(method1686_1189))
			   {
			      aux_1943 = PROCEDURE_ENTRY(method1686_1189) (method1686_1189, (obj_t) (node_11), BEOA);
			   }
			 else
			   {
			      obj_t fun1659_1158;
			      fun1659_1158 = PROCEDURE_REF(cnst__env_43_cnst_node, ((long) 0));
			      aux_1943 = PROCEDURE_ENTRY(fun1659_1158) (fun1659_1158, (obj_t) (node_11), BEOA);
			   }
		      }
		 }
	       else
		 {
		    goto case_else1692_1193;
		 }
	    }
	    return (node_t) (aux_1943);
	 }
      }
   }
}


/* _cnst!1887 */ obj_t 
_cnst_1887_206_cnst_node(obj_t env_1775, obj_t node_1776)
{
   {
      node_t aux_2362;
      aux_2362 = cnst__44_cnst_node((node_t) (node_1776));
      return (obj_t) (aux_2362);
   }
}


/* cnst!-default1486 */ node_t 
cnst__default1486_169_cnst_node(node_t node_12)
{
   FAILURE(CNST_TABLE_REF(((long) 4)), string1895_cnst_node, (obj_t) (node_12));
}


/* _cnst!-default1486 */ obj_t 
_cnst__default1486_239_cnst_node(obj_t env_1777, obj_t node_1778)
{
   {
      node_t aux_2369;
      aux_2369 = cnst__default1486_169_cnst_node((node_t) (node_1778));
      return (obj_t) (aux_2369);
   }
}


/* get-node-atom-value */ obj_t 
get_node_atom_value_135_cnst_node(node_t node_35)
{
 get_node_atom_value_135_cnst_node:
   {
      obj_t method1666_1165;
      obj_t class1671_1166;
      {
	 obj_t arg1675_1163;
	 obj_t arg1676_1164;
	 {
	    object_t obj_1730;
	    obj_1730 = (object_t) (node_35);
	    {
	       obj_t pre_method_105_1731;
	       pre_method_105_1731 = PROCEDURE_REF(get_node_atom_value_env_18_cnst_node, ((long) 2));
	       if (INTEGERP(pre_method_105_1731))
		 {
		    PROCEDURE_SET(get_node_atom_value_env_18_cnst_node, ((long) 2), BUNSPEC);
		    arg1675_1163 = pre_method_105_1731;
		 }
	       else
		 {
		    long obj_class_num_177_1736;
		    obj_class_num_177_1736 = TYPE(obj_1730);
		    {
		       obj_t arg1177_1737;
		       arg1177_1737 = PROCEDURE_REF(get_node_atom_value_env_18_cnst_node, ((long) 1));
		       {
			  long arg1178_1741;
			  {
			     long arg1179_1742;
			     arg1179_1742 = OBJECT_TYPE;
			     arg1178_1741 = (obj_class_num_177_1736 - arg1179_1742);
			  }
			  arg1675_1163 = VECTOR_REF(arg1177_1737, arg1178_1741);
		       }
		    }
		 }
	    }
	 }
	 {
	    object_t object_1747;
	    object_1747 = (object_t) (node_35);
	    {
	       long arg1180_1748;
	       {
		  long arg1181_1749;
		  long arg1182_1750;
		  arg1181_1749 = TYPE(object_1747);
		  arg1182_1750 = OBJECT_TYPE;
		  arg1180_1748 = (arg1181_1749 - arg1182_1750);
	       }
	       {
		  obj_t vector_1754;
		  vector_1754 = _classes__134___object;
		  arg1676_1164 = VECTOR_REF(vector_1754, arg1180_1748);
	       }
	    }
	 }
	 method1666_1165 = arg1675_1163;
	 class1671_1166 = arg1676_1164;
	 {
	    if (INTEGERP(method1666_1165))
	      {
		 switch ((long) CINT(method1666_1165))
		   {
		   case ((long) 0):
		      {
			 atom_t node_1172;
			 node_1172 = (atom_t) (node_35);
			 return (((atom_t) CREF(node_1172))->value);
		      }
		      break;
		   case ((long) 1):
		      {
			 var_t node_1173;
			 node_1173 = (var_t) (node_35);
			 {
			    variable_t v_1174;
			    v_1174 = (((var_t) CREF(node_1173))->variable);
			    if (is_a__118___object((obj_t) (v_1174), local_bvalue_105_cnst_node))
			      {
				 node_t node_2397;
				 {
				    local_bvalue_105_t obj_1759;
				    obj_1759 = (local_bvalue_105_t) (v_1174);
				    {
				       obj_t aux_2399;
				       {
					  object_t aux_2400;
					  aux_2400 = (object_t) (obj_1759);
					  aux_2399 = OBJECT_WIDENING(aux_2400);
				       }
				       node_2397 = (((local_bvalue_105_t) CREF(aux_2399))->binding_value_3);
				    }
				 }
				 node_35 = node_2397;
				 goto get_node_atom_value_135_cnst_node;
			      }
			    else
			      {
				 return CNST_TABLE_REF(((long) 5));
			      }
			 }
		      }
		      break;
		   default:
		    case_else1672_1169:
		      if (PROCEDUREP(method1666_1165))
			{
			   return PROCEDURE_ENTRY(method1666_1165) (method1666_1165, (obj_t) (node_35), BEOA);
			}
		      else
			{
			   obj_t fun1664_1161;
			   fun1664_1161 = PROCEDURE_REF(get_node_atom_value_env_18_cnst_node, ((long) 0));
			   return PROCEDURE_ENTRY(fun1664_1161) (fun1664_1161, (obj_t) (node_35), BEOA);
			}
		   }
	      }
	    else
	      {
		 goto case_else1672_1169;
	      }
	 }
      }
   }
}


/* _get-node-atom-value1888 */ obj_t 
_get_node_atom_value1888_155_cnst_node(obj_t env_1779, obj_t node_1780)
{
   return get_node_atom_value_135_cnst_node((node_t) (node_1780));
}


/* get-node-atom-value-default1510 */ obj_t 
get_node_atom_value_default1510_6_cnst_node(node_t node_36)
{
   return CNST_TABLE_REF(((long) 5));
}


/* _get-node-atom-value-default1510 */ obj_t 
_get_node_atom_value_default1510_92_cnst_node(obj_t env_1781, obj_t node_1782)
{
   return get_node_atom_value_default1510_6_cnst_node((node_t) (node_1782));
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_cnst_node()
{
   module_initialization_70_tools_trace(((long) 0), "CNST_NODE");
   module_initialization_70_tools_shape(((long) 0), "CNST_NODE");
   module_initialization_70_tools_speek(((long) 0), "CNST_NODE");
   module_initialization_70_tools_error(((long) 0), "CNST_NODE");
   module_initialization_70_type_type(((long) 0), "CNST_NODE");
   module_initialization_70_type_cache(((long) 0), "CNST_NODE");
   module_initialization_70_ast_var(((long) 0), "CNST_NODE");
   module_initialization_70_ast_node(((long) 0), "CNST_NODE");
   module_initialization_70_ast_env(((long) 0), "CNST_NODE");
   module_initialization_70_cnst_cache(((long) 0), "CNST_NODE");
   return module_initialization_70_cnst_alloc(((long) 0), "CNST_NODE");
}
