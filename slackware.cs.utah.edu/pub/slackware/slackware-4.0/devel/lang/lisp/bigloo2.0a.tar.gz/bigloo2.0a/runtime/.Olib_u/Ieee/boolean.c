/*===========================================================================*/
/*   (Ieee/boolean.scm)                                                      */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>
#include <signal.h>

extern bool_t not___r4_booleans_6_1(obj_t);
static obj_t _boolean__157___r4_booleans_6_1(obj_t, obj_t);
extern obj_t module_initialization_70___r4_booleans_6_1(long, char *);
extern bool_t boolean__35___r4_booleans_6_1(obj_t);
static obj_t _not___r4_booleans_6_1(obj_t, obj_t);
static obj_t require_initialization_114___r4_booleans_6_1 = BUNSPEC;
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( boolean__env_44___r4_booleans_6_1, _boolean__157___r4_booleans_6_11092, _boolean__157___r4_booleans_6_1, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( not_env_16___r4_booleans_6_1, _not___r4_booleans_6_11093, _not___r4_booleans_6_1, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_booleans_6_1(long checksum_210, char * from_211)
{
if(CBOOL(require_initialization_114___r4_booleans_6_1)){
require_initialization_114___r4_booleans_6_1 = BBOOL(((bool_t)0));
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* not */bool_t not___r4_booleans_6_1(obj_t obj_1)
{
if(CBOOL(obj_1)){
return ((bool_t)0);
}
 else {
return ((bool_t)1);
}
}


/* _not */obj_t _not___r4_booleans_6_1(obj_t env_204, obj_t obj_205)
{
{
bool_t aux_217;
{
obj_t obj_208;
obj_208 = obj_205;
if(CBOOL(obj_208)){
aux_217 = ((bool_t)0);
}
 else {
aux_217 = ((bool_t)1);
}
}
return BBOOL(aux_217);
}
}


/* boolean? */bool_t boolean__35___r4_booleans_6_1(obj_t obj_2)
{
return BOOLEANP(obj_2);
}


/* _boolean? */obj_t _boolean__157___r4_booleans_6_1(obj_t env_206, obj_t obj_207)
{
{
bool_t aux_222;
{
obj_t obj_209;
obj_209 = obj_207;
aux_222 = BOOLEANP(obj_209);
}
return BBOOL(aux_222);
}
}

