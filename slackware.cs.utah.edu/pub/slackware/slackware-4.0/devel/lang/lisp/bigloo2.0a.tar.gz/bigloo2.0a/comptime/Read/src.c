/*===========================================================================*/
/*   (Read/src.scm)                                                          */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>

extern obj_t unwind_until__178___bexit(obj_t, obj_t);
extern obj_t _src_files__222_engine_param;
static obj_t escape_1188_read_src(obj_t, obj_t);
static obj_t body1012_read_src(obj_t);
static obj_t body1004_read_src(obj_t);
static obj_t _read_handler_97_read_src(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t exitd_top;
extern obj_t _load_path__54___eval;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
static obj_t handling_function1063_read_src(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1041_read_src(obj_t, obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_read_src(long, char *);
extern obj_t module_initialization_70_read_reader(long, char *);
extern obj_t module_initialization_70_engine_param(long, char *);
extern obj_t module_initialization_70_engine_engine(long, char *);
extern obj_t module_initialization_70_init_main(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70___error(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_control_features_6_9(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t notify_error_43___error(obj_t, obj_t, obj_t);
extern obj_t compiler_read_18_read_reader(obj_t);
extern bool_t fexists(char *);
static obj_t open_src_file_153_read_src(obj_t);
extern obj_t exit_bigloo_229_init_main(obj_t);
static obj_t read_module_clause_73_read_src();
static obj_t imported_modules_init_94_read_src();
extern obj_t reader_reset__72___reader();
static obj_t _port__108_read_src = BUNSPEC;
static obj_t rhandler1011_read_src(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t rhandler1003_read_src(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t library_modules_init_112_read_src();
extern obj_t hello_world_248_engine_engine();
static obj_t close_src_port_211_read_src();
static obj_t toplevel_init_63_read_src();
extern obj_t current_input_port;
extern obj_t dynamic_wind_31___r4_control_features_6_9(obj_t, obj_t, obj_t);
extern obj_t close_input_port(obj_t);
static obj_t read_handler_125_read_src(obj_t, obj_t, obj_t, obj_t);
static obj_t _read_src_237_read_src(obj_t);
static obj_t arg1066_read_src(obj_t);
static obj_t arg1065_read_src(obj_t);
static obj_t arg1055_read_src(obj_t);
static obj_t arg1053_read_src(obj_t);
extern obj_t remove_error_handler__102___error();
static obj_t read_src_port_61_read_src();
extern obj_t read_src_204_read_src();
extern obj_t _bigloo_interpreter__95___reader;
static obj_t escape_read_src(obj_t, obj_t);
extern obj_t add_error_handler__155___error(obj_t, obj_t);
static obj_t require_initialization_114_read_src = BUNSPEC;
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
extern obj_t reverse__39___r4_pairs_and_lists_6_3(obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE(read_src_env_236_read_src, _read_src_237_read_src1194, _read_src_237_read_src, 0L, 0);
DEFINE_STATIC_PROCEDURE(proc1189_read_src, body1004_read_src1195, body1004_read_src, 0L, 0);
DEFINE_STATIC_PROCEDURE(read_handler_env_217_read_src, _read_handler_97_read_src1196, _read_handler_97_read_src, 0L, 4);
DEFINE_STRING(string1192_read_src, string1192_read_src1197, "Can't find such file", 20);
DEFINE_STRING(string1191_read_src, string1191_read_src1198, "Can't open such file", 20);
DEFINE_STRING(string1190_read_src, string1190_read_src1199, "src-file->memory", 16);


/* module-initialization */ obj_t 
module_initialization_70_read_src(long checksum_195, char *from_196)
{
   if (CBOOL(require_initialization_114_read_src))
     {
	require_initialization_114_read_src = BBOOL(((bool_t) 0));
	library_modules_init_112_read_src();
	imported_modules_init_94_read_src();
	toplevel_init_63_read_src();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_read_src()
{
   module_initialization_70___bexit(((long) 0), "READ_SRC");
   module_initialization_70___eval(((long) 0), "READ_SRC");
   module_initialization_70___error(((long) 0), "READ_SRC");
   module_initialization_70___reader(((long) 0), "READ_SRC");
   module_initialization_70___r4_control_features_6_9(((long) 0), "READ_SRC");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "READ_SRC");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "READ_SRC");
   return BUNSPEC;
}


/* toplevel-init */ obj_t 
toplevel_init_63_read_src()
{
   return (_port__108_read_src = BFALSE,
      BUNSPEC);
}


/* read-src */ obj_t 
read_src_204_read_src()
{
   {
      obj_t module_7;
      module_7 = read_module_clause_73_read_src();
      if (PAIRP(module_7))
	{
	   obj_t src_9;
	   obj_t sfiles_10;
	   {
	      obj_t arg1020_12;
	      obj_t arg1025_13;
	      arg1020_12 = read_src_port_61_read_src();
	      {
		 obj_t pair_98;
		 pair_98 = _src_files__222_engine_param;
		 arg1025_13 = CDR(pair_98);
	      }
	      src_9 = arg1020_12;
	      sfiles_10 = arg1025_13;
	    loop_11:
	      if (NULLP(sfiles_10))
		{
		   obj_t arg1032_15;
		   arg1032_15 = reverse__39___r4_pairs_and_lists_6_3(src_9);
		   return MAKE_PAIR(module_7, arg1032_15);
		}
	      else
		{
		   obj_t arg1034_16;
		   obj_t arg1038_17;
		   {
		      obj_t arg1175_104;
		      arg1175_104 = find_file_path_55_tools_file(CAR(sfiles_10), _load_path__54___eval);
		      open_src_file_153_read_src(arg1175_104);
		   }
		   arg1034_16 = read_src_port_61_read_src();
		   arg1038_17 = CDR(sfiles_10);
		   {
		      obj_t sfiles_225;
		      obj_t src_224;
		      src_224 = arg1034_16;
		      sfiles_225 = arg1038_17;
		      sfiles_10 = sfiles_225;
		      src_9 = src_224;
		      goto loop_11;
		   }
		}
	   }
	}
      else
	{
	   return module_7;
	}
   }
}


/* _read-src */ obj_t 
_read_src_237_read_src(obj_t env_124)
{
   return read_src_204_read_src();
}


/* read-handler */ obj_t 
read_handler_125_read_src(obj_t escape_1, obj_t proc_2, obj_t mes_3, obj_t obj_4)
{
   hello_world_248_engine_engine();
   notify_error_43___error(proc_2, mes_3, obj_4);
   close_src_port_211_read_src();
   return exit_bigloo_229_init_main(BINT(((long) -3)));
}


/* _read-handler */ obj_t 
_read_handler_97_read_src(obj_t env_125, obj_t escape_126, obj_t proc_127, obj_t mes_128, obj_t obj_129)
{
   return read_handler_125_read_src(escape_126, proc_127, mes_128, obj_129);
}


/* read-module-clause */ obj_t 
read_module_clause_73_read_src()
{
   {
      obj_t arg1040_19;
      {
	 obj_t pair_106;
	 pair_106 = _src_files__222_engine_param;
	 arg1040_19 = CAR(pair_106);
      }
      open_src_file_153_read_src(arg1040_19);
   }
   {
      obj_t module_20;
      {
	 obj_t armed1005_21;
	 obj_t handler1002_22;
	 armed1005_21 = MAKE_CELL(BUNSPEC);
	 handler1002_22 = MAKE_CELL(BUNSPEC);
	 {
	    obj_t body1004_131;
	    obj_t rhandler1003_133;
	    body1004_131 = proc1189_read_src;
	    rhandler1003_133 = make_fx_procedure(rhandler1003_read_src, ((long) 4), ((long) 2));
	    PROCEDURE_SET(rhandler1003_133, ((long) 0), armed1005_21);
	    PROCEDURE_SET(rhandler1003_133, ((long) 1), handler1002_22);
	    CELL_SET(handler1002_22, read_handler_env_217_read_src);
	    CELL_SET(armed1005_21, BTRUE);
	    module_20 = handling_function1041_read_src(body1004_131, rhandler1003_133, handler1002_22, armed1005_21);
	 }
      }
      if (CBOOL(_bigloo_interpreter__95___reader))
	{
	   return BFALSE;
	}
      else
	{
	   return module_20;
	}
   }
}


/* handling_function1041 */ obj_t 
handling_function1041_read_src(obj_t body1004_194, obj_t rhandler1003_193, obj_t handler1002_192, obj_t armed1005_191)
{
   jmp_buf jmpbuf;
   obj_t an_exit1006_26;
   if (SET_EXIT(an_exit1006_26))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1006_26 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1006_26, ((bool_t) 1));
	   {
	      obj_t an_exitd1007_27;
	      an_exitd1007_27 = exitd_top;
	      {
		 obj_t escape_132;
		 escape_132 = make_fx_procedure(escape_read_src, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_132, ((long) 0), an_exitd1007_27);
		 {
		    obj_t res1009_30;
		    {
		       obj_t arg1055_130;
		       obj_t arg1053_134;
		       arg1055_130 = make_fx_procedure(arg1055_read_src, ((long) 0), ((long) 1));
		       arg1053_134 = make_fx_procedure(arg1053_read_src, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1055_130, ((long) 0), armed1005_191);
		       PROCEDURE_SET(arg1053_134, ((long) 0), an_exitd1007_27);
		       PROCEDURE_SET(arg1053_134, ((long) 1), armed1005_191);
		       PROCEDURE_SET(arg1053_134, ((long) 2), handler1002_192);
		       PROCEDURE_SET(arg1053_134, ((long) 3), rhandler1003_193);
		       PROCEDURE_SET(arg1053_134, ((long) 4), escape_132);
		       res1009_30 = dynamic_wind_31___r4_control_features_6_9(arg1053_134, body1004_194, arg1055_130);
		    }
		    POP_EXIT();
		    return res1009_30;
		 }
	      }
	   }
	}
     }
}


/* arg1055 */ obj_t 
arg1055_read_src(obj_t env_135)
{
   {
      obj_t armed1005_136;
      armed1005_136 = PROCEDURE_REF(env_135, ((long) 0));
      {
	 {
	    bool_t test_257;
	    {
	       obj_t aux_258;
	       aux_258 = CELL_REF(armed1005_136);
	       test_257 = CBOOL(aux_258);
	    }
	    if (test_257)
	      {
		 CELL_SET(armed1005_136, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1004 */ obj_t 
body1004_read_src(obj_t env_138)
{
   {
      {
	 obj_t list1060_43;
	 {
	    obj_t arg1061_44;
	    arg1061_44 = MAKE_PAIR(BTRUE, BNIL);
	    list1060_43 = MAKE_PAIR(_port__108_read_src, arg1061_44);
	 }
	 return compiler_read_18_read_reader(list1060_43);
      }
   }
}


/* arg1053 */ obj_t 
arg1053_read_src(obj_t env_139)
{
   {
      obj_t rhandler1003_143;
      obj_t escape_144;
      rhandler1003_143 = PROCEDURE_REF(env_139, ((long) 3));
      escape_144 = PROCEDURE_REF(env_139, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1003_143, escape_144);
      }
   }
}


/* escape */ obj_t 
escape_read_src(obj_t env_145, obj_t val1008_147)
{
   {
      obj_t an_exitd1007_146;
      an_exitd1007_146 = PROCEDURE_REF(env_145, ((long) 0));
      {
	 obj_t val1008_28;
	 val1008_28 = val1008_147;
	 return unwind_until__178___bexit(an_exitd1007_146, val1008_28);
      }
   }
}


/* rhandler1003 */ obj_t 
rhandler1003_read_src(obj_t env_148, obj_t esc_151, obj_t obj_152, obj_t proc_153, obj_t msg_154)
{
   {
      obj_t armed1005_149;
      obj_t handler1002_150;
      armed1005_149 = PROCEDURE_REF(env_148, ((long) 0));
      handler1002_150 = PROCEDURE_REF(env_148, ((long) 1));
      {
	 obj_t esc_37;
	 obj_t obj_38;
	 obj_t proc_39;
	 obj_t msg_40;
	 esc_37 = esc_151;
	 obj_38 = obj_152;
	 proc_39 = proc_153;
	 msg_40 = msg_154;
	 CELL_SET(armed1005_149, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_273;
	    aux_273 = CELL_REF(handler1002_150);
	    return PROCEDURE_ENTRY(aux_273) (CELL_REF(handler1002_150), esc_37, obj_38, proc_39, msg_40, BEOA);
	 }
      }
   }
}


/* read-src/port */ obj_t 
read_src_port_61_read_src()
{
   {
      obj_t port_48;
      port_48 = _port__108_read_src;
      {
	 obj_t armed1013_49;
	 obj_t handler1010_50;
	 armed1013_49 = MAKE_CELL(BUNSPEC);
	 handler1010_50 = MAKE_CELL(BUNSPEC);
	 {
	    obj_t body1012_159;
	    obj_t rhandler1011_161;
	    body1012_159 = make_fx_procedure(body1012_read_src, ((long) 0), ((long) 1));
	    rhandler1011_161 = make_fx_procedure(rhandler1011_read_src, ((long) 4), ((long) 2));
	    PROCEDURE_SET(body1012_159, ((long) 0), port_48);
	    PROCEDURE_SET(rhandler1011_161, ((long) 0), armed1013_49);
	    PROCEDURE_SET(rhandler1011_161, ((long) 1), handler1010_50);
	    CELL_SET(handler1010_50, read_handler_env_217_read_src);
	    CELL_SET(armed1013_49, BTRUE);
	    return handling_function1063_read_src(body1012_159, rhandler1011_161, handler1010_50, armed1013_49);
	 }
      }
   }
}


/* handling_function1063 */ obj_t 
handling_function1063_read_src(obj_t body1012_190, obj_t rhandler1011_189, obj_t handler1010_188, obj_t armed1013_187)
{
   jmp_buf jmpbuf;
   obj_t an_exit1014_54;
   if (SET_EXIT(an_exit1014_54))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1014_54 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1014_54, ((bool_t) 1));
	   {
	      obj_t an_exitd1015_55;
	      an_exitd1015_55 = exitd_top;
	      {
		 obj_t escape_160;
		 escape_160 = make_fx_procedure(escape_1188_read_src, ((long) 1), ((long) 1));
		 PROCEDURE_SET(escape_160, ((long) 0), an_exitd1015_55);
		 {
		    obj_t res1017_58;
		    {
		       obj_t arg1066_158;
		       obj_t arg1065_162;
		       arg1066_158 = make_fx_procedure(arg1066_read_src, ((long) 0), ((long) 1));
		       arg1065_162 = make_fx_procedure(arg1065_read_src, ((long) 0), ((long) 5));
		       PROCEDURE_SET(arg1066_158, ((long) 0), armed1013_187);
		       PROCEDURE_SET(arg1065_162, ((long) 0), an_exitd1015_55);
		       PROCEDURE_SET(arg1065_162, ((long) 1), armed1013_187);
		       PROCEDURE_SET(arg1065_162, ((long) 2), handler1010_188);
		       PROCEDURE_SET(arg1065_162, ((long) 3), rhandler1011_189);
		       PROCEDURE_SET(arg1065_162, ((long) 4), escape_160);
		       res1017_58 = dynamic_wind_31___r4_control_features_6_9(arg1065_162, body1012_190, arg1066_158);
		    }
		    POP_EXIT();
		    return res1017_58;
		 }
	      }
	   }
	}
     }
}


/* arg1066 */ obj_t 
arg1066_read_src(obj_t env_163)
{
   {
      obj_t armed1013_164;
      armed1013_164 = PROCEDURE_REF(env_163, ((long) 0));
      {
	 {
	    bool_t test_296;
	    {
	       obj_t aux_297;
	       aux_297 = CELL_REF(armed1013_164);
	       test_296 = CBOOL(aux_297);
	    }
	    if (test_296)
	      {
		 CELL_SET(armed1013_164, BFALSE);
		 return remove_error_handler__102___error();
	      }
	    else
	      {
		 return BUNSPEC;
	      }
	 }
      }
   }
}


/* body1012 */ obj_t 
body1012_read_src(obj_t env_166)
{
   {
      obj_t port_167;
      port_167 = PROCEDURE_REF(env_166, ((long) 0));
      {
	 {
	    obj_t r_71;
	    obj_t acc_72;
	    {
	       obj_t arg1077_74;
	       {
		  obj_t list1138_76;
		  {
		     obj_t arg1142_77;
		     arg1142_77 = MAKE_PAIR(BTRUE, BNIL);
		     list1138_76 = MAKE_PAIR(port_167, arg1142_77);
		  }
		  arg1077_74 = compiler_read_18_read_reader(list1138_76);
	       }
	       r_71 = arg1077_74;
	       acc_72 = BNIL;
	     loop_73:
	       {
		  bool_t test1146_79;
		  test1146_79 = EOF_OBJECTP(r_71);
		  if (test1146_79)
		    {
		       close_src_port_211_read_src();
		       return acc_72;
		    }
		  else
		    {
		       obj_t arg1150_80;
		       obj_t arg1157_81;
		       {
			  obj_t list1158_82;
			  {
			     obj_t arg1161_83;
			     arg1161_83 = MAKE_PAIR(BTRUE, BNIL);
			     list1158_82 = MAKE_PAIR(port_167, arg1161_83);
			  }
			  arg1150_80 = compiler_read_18_read_reader(list1158_82);
		       }
		       arg1157_81 = MAKE_PAIR(r_71, acc_72);
		       {
			  obj_t acc_312;
			  obj_t r_311;
			  r_311 = arg1150_80;
			  acc_312 = arg1157_81;
			  acc_72 = acc_312;
			  r_71 = r_311;
			  goto loop_73;
		       }
		    }
	       }
	    }
	 }
      }
   }
}


/* arg1065 */ obj_t 
arg1065_read_src(obj_t env_168)
{
   {
      obj_t rhandler1011_172;
      obj_t escape_173;
      rhandler1011_172 = PROCEDURE_REF(env_168, ((long) 3));
      escape_173 = PROCEDURE_REF(env_168, ((long) 4));
      {
	 return add_error_handler__155___error(rhandler1011_172, escape_173);
      }
   }
}


/* escape_1188 */ obj_t 
escape_1188_read_src(obj_t env_174, obj_t val1016_176)
{
   {
      obj_t an_exitd1015_175;
      an_exitd1015_175 = PROCEDURE_REF(env_174, ((long) 0));
      {
	 obj_t val1016_56;
	 val1016_56 = val1016_176;
	 return unwind_until__178___bexit(an_exitd1015_175, val1016_56);
      }
   }
}


/* rhandler1011 */ obj_t 
rhandler1011_read_src(obj_t env_177, obj_t esc_180, obj_t obj_181, obj_t proc_182, obj_t msg_183)
{
   {
      obj_t armed1013_178;
      obj_t handler1010_179;
      armed1013_178 = PROCEDURE_REF(env_177, ((long) 0));
      handler1010_179 = PROCEDURE_REF(env_177, ((long) 1));
      {
	 obj_t esc_65;
	 obj_t obj_66;
	 obj_t proc_67;
	 obj_t msg_68;
	 esc_65 = esc_180;
	 obj_66 = obj_181;
	 proc_67 = proc_182;
	 msg_68 = msg_183;
	 CELL_SET(armed1013_178, BFALSE);
	 remove_error_handler__102___error();
	 {
	    obj_t aux_322;
	    aux_322 = CELL_REF(handler1010_179);
	    return PROCEDURE_ENTRY(aux_322) (CELL_REF(handler1010_179), esc_65, obj_66, proc_67, msg_68, BEOA);
	 }
      }
   }
}


/* open-src-file */ obj_t 
open_src_file_153_read_src(obj_t sfile_6)
{
   if (STRINGP(sfile_6))
     {
	bool_t test1178_89;
	{
	   char *aux_325;
	   aux_325 = BSTRING_TO_STRING(sfile_6);
	   test1178_89 = fexists(aux_325);
	}
	if (test1178_89)
	  {
	     obj_t port_90;
	     port_90 = open_input_file_61___r4_ports_6_10_1(sfile_6, BNIL);
	     if (INPUT_PORTP(port_90))
	       {
		  reader_reset__72___reader();
		  return (_port__108_read_src = port_90,
		     BUNSPEC);
	       }
	     else
	       {
		  FAILURE(string1190_read_src, string1191_read_src, sfile_6);
	       }
	  }
	else
	  {
	     FAILURE(string1190_read_src, string1192_read_src, sfile_6);
	  }
     }
   else
     {
	return (_port__108_read_src = current_input_port,
	   BUNSPEC);
     }
}


/* close-src-port */ obj_t 
close_src_port_211_read_src()
{
   {
      bool_t test1181_93;
      {
	 bool_t test1182_94;
	 {
	    obj_t obj_120;
	    obj_120 = _port__108_read_src;
	    test1182_94 = INPUT_PORTP(obj_120);
	 }
	 if (test1182_94)
	   {
	      bool_t test1183_95;
	      {
		 obj_t obj1_121;
		 obj1_121 = _port__108_read_src;
		 test1183_95 = (obj1_121 == current_input_port);
	      }
	      if (test1183_95)
		{
		   test1181_93 = ((bool_t) 0);
		}
	      else
		{
		   test1181_93 = ((bool_t) 1);
		}
	   }
	 else
	   {
	      test1181_93 = ((bool_t) 0);
	   }
      }
      if (test1181_93)
	{
	   obj_t port_123;
	   port_123 = _port__108_read_src;
	   return close_input_port(port_123);
	}
      else
	{
	   return BUNSPEC;
	}
   }
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_read_src()
{
   module_initialization_70_read_reader(((long) 0), "READ_SRC");
   module_initialization_70_engine_param(((long) 0), "READ_SRC");
   module_initialization_70_engine_engine(((long) 0), "READ_SRC");
   module_initialization_70_init_main(((long) 0), "READ_SRC");
   return module_initialization_70_tools_file(((long) 0), "READ_SRC");
}
