/*===========================================================================*/
/*   (Ieee/number.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*    --------------------------------------------------------------------   */
/*      A pratical implementation for the Scheme programming language        */
/*                                                                           */
/*                                       ,--^,                               */
/*                                 _ ___/ /|/                                */
/*                             ,;'( )__, ) '                                 */
/*                            ;;  //   L__.                                  */
/*                            '   \   /  '                                   */
/*                                 ^   ^                                     */
/*                                                                           */
/*      Copyright (c) 1992-1999 Manuel Serrano                               */
/*                                                                           */
/*        Bug descriptions, use reports, comments or suggestions are         */
/*        welcome. Send them to                                              */
/*          bigloo-request@kaolin.unice.fr                                   */
/*          http://kaolin.unice.fr/bigloo                                    */
/*                                                                           */
/*      This program is free software; you can redistribute it               */
/*      and/or modify it under the terms of the GNU General Public           */
/*      License as published by the Free Software Foundation; either         */
/*      version 2 of the License, or (at your option) any later version.     */
/*                                                                           */
/*      This program is distributed in the hope that it will be useful,      */
/*      but WITHOUT ANY WARRANTY; without even the implied warranty of       */
/*      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        */
/*      GNU General Public License for more details.                         */
/*                                                                           */
/*      You should have received a copy of the GNU General Public            */
/*      License along with this program; if not, write to the Free           */
/*      Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,      */
/*      MA 02111-1307, USA.                                                  */
/*   --------------------------------------------------------------------    */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

/* debug mode */
#define BIGLOO_DEBUG 1

#include <bigloo2.0a.h>
#include <signal.h>

static obj_t _2__171___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2__242___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern char * number__string_214___r4_numbers_6_5(obj_t, obj_t);
static obj_t _2__101___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _exp___r4_numbers_6_5(obj_t, obj_t);
extern obj_t string_to_symbol(char *);
extern obj_t exact__inexact_122___r4_numbers_6_5(obj_t);
static obj_t _inexact__exact_215___r4_numbers_6_5(obj_t, obj_t);
static obj_t _floor___r4_numbers_6_5(obj_t, obj_t);
extern obj_t abs___r4_numbers_6_5(obj_t);
static obj_t _ceiling___r4_numbers_6_5(obj_t, obj_t);
extern obj_t make_real(double);
static obj_t _negative__187___r4_numbers_6_5(obj_t, obj_t);
static obj_t _cos___r4_numbers_6_5(obj_t, obj_t);
static obj_t _string__number_250___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern obj_t floor___r4_numbers_6_5(obj_t);
extern long flonum__fixnum_11___r4_numbers_6_5(obj_t);
static obj_t _inexact__53___r4_numbers_6_5(obj_t, obj_t);
extern double atan___r4_numbers_6_5(obj_t, obj_t);
extern double asin___r4_numbers_6_5(obj_t);
static obj_t _expt___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _rational__24___r4_numbers_6_5(obj_t, obj_t);
static obj_t _complex__176___r4_numbers_6_5(obj_t, obj_t);
static obj_t _number__137___r4_numbers_6_5(obj_t, obj_t);
static obj_t _abs___r4_numbers_6_5(obj_t, obj_t);
extern bool_t inexact__139___r4_numbers_6_5(obj_t);
extern double tan___r4_numbers_6_5(obj_t);
static obj_t _round___r4_numbers_6_5(obj_t, obj_t);
extern double sin___r4_numbers_6_5(obj_t);
extern char * integer__string_135___r4_numbers_6_5_fixnum(long, obj_t);
extern obj_t ceiling___r4_numbers_6_5(obj_t);
extern obj_t string_to_bstring(char *);
extern bool_t complex__118___r4_numbers_6_5(obj_t);
static obj_t _zero__222___r4_numbers_6_5(obj_t, obj_t);
extern bool_t negative__33___r4_numbers_6_5(obj_t);
extern obj_t bigloo_type_error_location_103___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _positive__177___r4_numbers_6_5(obj_t, obj_t);
extern obj_t round___r4_numbers_6_5(obj_t);
extern bool_t exact__189___r4_numbers_6_5(obj_t);
extern obj_t inexact__exact_80___r4_numbers_6_5(obj_t);
static obj_t _acos___r4_numbers_6_5(obj_t, obj_t);
static obj_t symbol2925___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2924___r4_numbers_6_5 = BUNSPEC;
extern bool_t rational__51___r4_numbers_6_5(obj_t);
static obj_t symbol2916___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2912___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2911___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2899___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2910___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2897___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2907___r4_numbers_6_5 = BUNSPEC;
extern bool_t zero__228___r4_numbers_6_5(obj_t);
static obj_t symbol2895___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2904___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2893___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2891___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2889___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2887___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2885___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2883___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2881___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2879___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2877___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2875___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2874___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2872___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2871___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2869___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2868___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2866___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2865___r4_numbers_6_5 = BUNSPEC;
static obj_t _sqrt___r4_numbers_6_5(obj_t, obj_t);
static obj_t symbol2863___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2862___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2861___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2859___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2857___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2855___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2854___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2852___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2851___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2849___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2848___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2846___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2845___r4_numbers_6_5 = BUNSPEC;
extern bool_t number__102___r4_numbers_6_5(obj_t);
static obj_t symbol2843___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2841___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2837___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2835___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2832___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2831___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2829___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2830___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2828___r4_numbers_6_5 = BUNSPEC;
static obj_t symbol2827___r4_numbers_6_5 = BUNSPEC;
extern obj_t debug_error_location_199___error(obj_t, obj_t, obj_t, obj_t, obj_t);
static obj_t _truncate___r4_numbers_6_5(obj_t, obj_t);
static obj_t _tan___r4_numbers_6_5(obj_t, obj_t);
static obj_t _sin___r4_numbers_6_5(obj_t, obj_t);
static obj_t ___149___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ___44___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ___38___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ___222___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t ___163___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70___r4_numbers_6_5(long, char *);
extern obj_t module_initialization_70___error(long, char *);
static obj_t ___219___r4_numbers_6_5(obj_t, obj_t);
static obj_t ___10___r4_numbers_6_5(obj_t, obj_t);
extern obj_t string__number_104___r4_numbers_6_5(obj_t, obj_t);
extern obj_t expt___r4_numbers_6_5(obj_t, obj_t);
extern obj_t min___r4_numbers_6_5(obj_t, obj_t);
static obj_t _fixnum__flonum_153___r4_numbers_6_5(obj_t, obj_t);
static obj_t _number__string_61___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern double log___r4_numbers_6_5(obj_t);
extern obj_t max___r4_numbers_6_5(obj_t, obj_t);
static obj_t _exact__208___r4_numbers_6_5(obj_t, obj_t);
static obj_t _exact__inexact_16___r4_numbers_6_5(obj_t, obj_t);
extern obj_t truncate___r4_numbers_6_5(obj_t);
extern bool_t positive__57___r4_numbers_6_5(obj_t);
extern bool_t ___239___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t ___161___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t _2___235___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2___241___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__206___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__95___r4_numbers_6_5(obj_t, obj_t);
extern bool_t _2__116___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__156___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__79___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__168___r4_numbers_6_5(obj_t, obj_t);
extern obj_t _2__198___r4_numbers_6_5(obj_t, obj_t);
static obj_t _min___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _flonum__fixnum_24___r4_numbers_6_5(obj_t, obj_t);
static obj_t _log___r4_numbers_6_5(obj_t, obj_t);
static obj_t _max___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern long string__integer_39___r4_numbers_6_5_fixnum(char *, obj_t);
extern double acos___r4_numbers_6_5(obj_t);
extern double exp___r4_numbers_6_5(obj_t);
extern double sqrt___r4_numbers_6_5(obj_t);
static obj_t imported_modules_init_94___r4_numbers_6_5();
static obj_t _atan___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _asin___r4_numbers_6_5(obj_t, obj_t);
static obj_t require_initialization_114___r4_numbers_6_5 = BUNSPEC;
static obj_t _2___43___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2___117___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t ____251___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
static obj_t ____73___r4_numbers_6_5(obj_t, obj_t, obj_t, obj_t);
extern char * real_to_string(double);
extern double cos___r4_numbers_6_5(obj_t);
extern bool_t __172___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t __147___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern bool_t __124___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t cnst_init_137___r4_numbers_6_5();
extern obj_t __28___r4_numbers_6_5(obj_t, obj_t);
extern obj_t __186___r4_numbers_6_5(obj_t, obj_t);
extern obj_t __2___r4_numbers_6_5(obj_t);
extern obj_t __15___r4_numbers_6_5(obj_t);
static obj_t _2__130___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2__245___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t _2__208___r4_numbers_6_5(obj_t, obj_t, obj_t);
extern double fixnum__flonum_13___r4_numbers_6_5(obj_t);
static obj_t _2__11___r4_numbers_6_5(obj_t, obj_t, obj_t);
static obj_t *__cnst;

DEFINE_EXPORT_PROCEDURE( exact__env_214___r4_numbers_6_5, _exact__208___r4_numbers_6_52927, _exact__208___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( floor_env_50___r4_numbers_6_5, _floor___r4_numbers_6_52928, _floor___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2__env_159___r4_numbers_6_5, _2__208___r4_numbers_6_52929, _2__208___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _2__env_141___r4_numbers_6_5, _2__171___r4_numbers_6_52930, _2__171___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( asin_env_88___r4_numbers_6_5, _asin___r4_numbers_6_52931, _asin___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_146___r4_numbers_6_5, ___219___r4_numbers_6_52932, va_generic_entry, ___219___r4_numbers_6_5, -1 );
DEFINE_EXPORT_PROCEDURE( cos_env_114___r4_numbers_6_5, _cos___r4_numbers_6_52933, _cos___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2___env_201___r4_numbers_6_5, _2___43___r4_numbers_6_52934, _2___43___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( log_env_219___r4_numbers_6_5, _log___r4_numbers_6_52935, _log___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_224___r4_numbers_6_5, ___149___r4_numbers_6_52936, va_generic_entry, ___149___r4_numbers_6_5, -3 );
DEFINE_STRING( string2923___r4_numbers_6_5, string2923___r4_numbers_6_52937, "Too many arguments provided", 27 );
DEFINE_STRING( string2922___r4_numbers_6_5, string2922___r4_numbers_6_52938, "apply", 5 );
DEFINE_STRING( string2921___r4_numbers_6_5, string2921___r4_numbers_6_52939, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/pair-list.scm", 62 );
DEFINE_STRING( string2919___r4_numbers_6_5, string2919___r4_numbers_6_52940, "index out of range", 18 );
DEFINE_STRING( string2920___r4_numbers_6_5, string2920___r4_numbers_6_52941, "UCHAR", 5 );
DEFINE_STRING( string2918___r4_numbers_6_5, string2918___r4_numbers_6_52942, "string-ref", 10 );
DEFINE_STRING( string2917___r4_numbers_6_5, string2917___r4_numbers_6_52943, "BSTRING", 7 );
DEFINE_STRING( string2915___r4_numbers_6_5, string2915___r4_numbers_6_52944, "STRING", 6 );
DEFINE_STRING( string2914___r4_numbers_6_5, string2914___r4_numbers_6_52945, "Argument not a number", 21 );
DEFINE_STRING( string2913___r4_numbers_6_5, string2913___r4_numbers_6_52946, "number->string", 14 );
DEFINE_STRING( string2909___r4_numbers_6_5, string2909___r4_numbers_6_52947, "expt", 4 );
DEFINE_STRING( string2898___r4_numbers_6_5, string2898___r4_numbers_6_52948, "acos", 4 );
DEFINE_EXPORT_PROCEDURE( fixnum__flonum_env_34___r4_numbers_6_5, _fixnum__flonum_153___r4_numbers_6_52949, _fixnum__flonum_153___r4_numbers_6_5, 0L, 1 );
DEFINE_STRING( string2896___r4_numbers_6_5, string2896___r4_numbers_6_52950, "asin", 4 );
DEFINE_STRING( string2906___r4_numbers_6_5, string2906___r4_numbers_6_52951, "sqrt", 4 );
DEFINE_STRING( string2905___r4_numbers_6_5, string2905___r4_numbers_6_52952, "sqrtfl", 6 );
DEFINE_STRING( string2894___r4_numbers_6_5, string2894___r4_numbers_6_52953, "tan", 3 );
DEFINE_STRING( string2892___r4_numbers_6_5, string2892___r4_numbers_6_52954, "cos", 3 );
DEFINE_STRING( string2902___r4_numbers_6_5, string2902___r4_numbers_6_52955, "Domain error", 12 );
DEFINE_STRING( string2901___r4_numbers_6_5, string2901___r4_numbers_6_52956, "atanfl", 6 );
DEFINE_STRING( string2890___r4_numbers_6_5, string2890___r4_numbers_6_52957, "sin", 3 );
DEFINE_STRING( string2900___r4_numbers_6_5, string2900___r4_numbers_6_52958, "atan", 4 );
DEFINE_STRING( string2888___r4_numbers_6_5, string2888___r4_numbers_6_52959, "log", 3 );
DEFINE_STRING( string2886___r4_numbers_6_5, string2886___r4_numbers_6_52960, "exp", 3 );
DEFINE_STRING( string2884___r4_numbers_6_5, string2884___r4_numbers_6_52961, "round", 5 );
DEFINE_STRING( string2882___r4_numbers_6_5, string2882___r4_numbers_6_52962, "truncate", 8 );
DEFINE_STRING( string2880___r4_numbers_6_5, string2880___r4_numbers_6_52963, "ceiling", 7 );
DEFINE_STRING( string2878___r4_numbers_6_5, string2878___r4_numbers_6_52964, "floor", 5 );
DEFINE_STRING( string2876___r4_numbers_6_5, string2876___r4_numbers_6_52965, "abs", 3 );
DEFINE_STRING( string2873___r4_numbers_6_5, string2873___r4_numbers_6_52966, "/", 1 );
DEFINE_STRING( string2870___r4_numbers_6_5, string2870___r4_numbers_6_52967, "-", 1 );
DEFINE_STRING( string2867___r4_numbers_6_5, string2867___r4_numbers_6_52968, "*", 1 );
DEFINE_STRING( string2864___r4_numbers_6_5, string2864___r4_numbers_6_52969, "+", 1 );
DEFINE_EXPORT_PROCEDURE( atan_env_187___r4_numbers_6_5, _atan___r4_numbers_6_52970, va_generic_entry, _atan___r4_numbers_6_5, -2 );
DEFINE_STRING( string2860___r4_numbers_6_5, string2860___r4_numbers_6_52971, "negative", 8 );
DEFINE_STRING( string2858___r4_numbers_6_5, string2858___r4_numbers_6_52972, "positive", 8 );
DEFINE_STRING( string2856___r4_numbers_6_5, string2856___r4_numbers_6_52973, "zero", 4 );
DEFINE_EXPORT_PROCEDURE( min_env_72___r4_numbers_6_5, _min___r4_numbers_6_52974, va_generic_entry, _min___r4_numbers_6_5, -2 );
DEFINE_STRING( string2853___r4_numbers_6_5, string2853___r4_numbers_6_52975, ">=", 2 );
DEFINE_EXPORT_PROCEDURE( rational__env_181___r4_numbers_6_5, _rational__24___r4_numbers_6_52976, _rational__24___r4_numbers_6_5, 0L, 1 );
DEFINE_STRING( string2850___r4_numbers_6_5, string2850___r4_numbers_6_52977, "<=", 2 );
DEFINE_STRING( string2847___r4_numbers_6_5, string2847___r4_numbers_6_52978, ">", 1 );
DEFINE_STRING( string2844___r4_numbers_6_5, string2844___r4_numbers_6_52979, "<", 1 );
DEFINE_STRING( string2842___r4_numbers_6_5, string2842___r4_numbers_6_52980, "PAIR", 4 );
DEFINE_STRING( string2839___r4_numbers_6_5, string2839___r4_numbers_6_52981, "not a number", 12 );
DEFINE_STRING( string2840___r4_numbers_6_5, string2840___r4_numbers_6_52982, "/home/tahoe/serrano/trashcan/bigloo/runtime/Llib/error.scm", 58 );
DEFINE_STRING( string2838___r4_numbers_6_5, string2838___r4_numbers_6_52983, "=", 1 );
DEFINE_STRING( string2836___r4_numbers_6_5, string2836___r4_numbers_6_52984, "LONG", 4 );
DEFINE_STRING( string2834___r4_numbers_6_5, string2834___r4_numbers_6_52985, "/home/tahoe/serrano/trashcan/bigloo/runtime/Ieee/number.scm", 59 );
DEFINE_STRING( string2833___r4_numbers_6_5, string2833___r4_numbers_6_52986, "DOUBLE", 6 );
DEFINE_EXPORT_PROCEDURE( __env_131___r4_numbers_6_5, ___222___r4_numbers_6_52987, va_generic_entry, ___222___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( zero__env_140___r4_numbers_6_5, _zero__222___r4_numbers_6_52988, _zero__222___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_27___r4_numbers_6_5, ___10___r4_numbers_6_52989, va_generic_entry, ___10___r4_numbers_6_5, -1 );
DEFINE_EXPORT_PROCEDURE( sin_env_239___r4_numbers_6_5, _sin___r4_numbers_6_52990, _sin___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( exp_env_94___r4_numbers_6_5, _exp___r4_numbers_6_52991, _exp___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( inexact__env_116___r4_numbers_6_5, _inexact__53___r4_numbers_6_52992, _inexact__53___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ceiling_env_45___r4_numbers_6_5, _ceiling___r4_numbers_6_52993, _ceiling___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( flonum__fixnum_env_186___r4_numbers_6_5, _flonum__fixnum_24___r4_numbers_6_52994, _flonum__fixnum_24___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_177___r4_numbers_6_5, ___44___r4_numbers_6_52995, va_generic_entry, ___44___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( string__number_env_5___r4_numbers_6_5, _string__number_250___r4_numbers_6_52996, va_generic_entry, _string__number_250___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( _2__env_132___r4_numbers_6_5, _2__242___r4_numbers_6_52997, _2__242___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( tan_env_231___r4_numbers_6_5, _tan___r4_numbers_6_52998, _tan___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( ___env_53___r4_numbers_6_5, ____73___r4_numbers_6_52999, va_generic_entry, ____73___r4_numbers_6_5, -3 );
DEFINE_REAL( real2908___r4_numbers_6_5, real2908___r4_numbers_6_53000, 1.0 );
DEFINE_REAL( real2903___r4_numbers_6_5, real2903___r4_numbers_6_53001, 0.0 );
DEFINE_EXPORT_PROCEDURE( sqrt_env_78___r4_numbers_6_5, _sqrt___r4_numbers_6_53002, _sqrt___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( round_env_16___r4_numbers_6_5, _round___r4_numbers_6_53003, _round___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2__env_227___r4_numbers_6_5, _2__130___r4_numbers_6_53004, _2__130___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( inexact__exact_env_134___r4_numbers_6_5, _inexact__exact_215___r4_numbers_6_53005, _inexact__exact_215___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( __env_55___r4_numbers_6_5, ___38___r4_numbers_6_53006, va_generic_entry, ___38___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( _2__env_108___r4_numbers_6_5, _2__11___r4_numbers_6_53007, _2__11___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( _2__env_207___r4_numbers_6_5, _2__101___r4_numbers_6_53008, _2__101___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( __env_196___r4_numbers_6_5, ___163___r4_numbers_6_53009, va_generic_entry, ___163___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( truncate_env_98___r4_numbers_6_5, _truncate___r4_numbers_6_53010, _truncate___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2__env_147___r4_numbers_6_5, _2__245___r4_numbers_6_53011, _2__245___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( ___env_251___r4_numbers_6_5, ____251___r4_numbers_6_53012, va_generic_entry, ____251___r4_numbers_6_5, -3 );
DEFINE_EXPORT_PROCEDURE( complex__env_220___r4_numbers_6_5, _complex__176___r4_numbers_6_53013, _complex__176___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( expt_env_52___r4_numbers_6_5, _expt___r4_numbers_6_53014, _expt___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( exact__inexact_env_238___r4_numbers_6_5, _exact__inexact_16___r4_numbers_6_53015, _exact__inexact_16___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( _2___env_180___r4_numbers_6_5, _2___117___r4_numbers_6_53016, _2___117___r4_numbers_6_5, 0L, 2 );
DEFINE_EXPORT_PROCEDURE( negative__env_63___r4_numbers_6_5, _negative__187___r4_numbers_6_53017, _negative__187___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( number__env_153___r4_numbers_6_5, _number__137___r4_numbers_6_53018, _number__137___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( number__string_env_103___r4_numbers_6_5, _number__string_61___r4_numbers_6_53019, va_generic_entry, _number__string_61___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( positive__env_240___r4_numbers_6_5, _positive__177___r4_numbers_6_53020, _positive__177___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( max_env_47___r4_numbers_6_5, _max___r4_numbers_6_53021, va_generic_entry, _max___r4_numbers_6_5, -2 );
DEFINE_EXPORT_PROCEDURE( acos_env_195___r4_numbers_6_5, _acos___r4_numbers_6_53022, _acos___r4_numbers_6_5, 0L, 1 );
DEFINE_EXPORT_PROCEDURE( abs_env_196___r4_numbers_6_5, _abs___r4_numbers_6_53023, _abs___r4_numbers_6_5, 0L, 1 );


/* module-initialization */obj_t module_initialization_70___r4_numbers_6_5(long checksum_3052, char * from_3053)
{
if(CBOOL(require_initialization_114___r4_numbers_6_5)){
require_initialization_114___r4_numbers_6_5 = BBOOL(((bool_t)0));
cnst_init_137___r4_numbers_6_5();
imported_modules_init_94___r4_numbers_6_5();
return BUNSPEC;
}
 else {
return BUNSPEC;
}
}


/* cnst-init */obj_t cnst_init_137___r4_numbers_6_5()
{
symbol2827___r4_numbers_6_5 = string_to_symbol("NUMBER?");
symbol2828___r4_numbers_6_5 = string_to_symbol("EXACT?");
symbol2829___r4_numbers_6_5 = string_to_symbol("INEXACT?");
symbol2830___r4_numbers_6_5 = string_to_symbol("COMPLEX?");
symbol2831___r4_numbers_6_5 = string_to_symbol("RATIONAL?");
symbol2832___r4_numbers_6_5 = string_to_symbol("FLONUM->FIXNUM");
symbol2835___r4_numbers_6_5 = string_to_symbol("FIXNUM->FLONUM");
symbol2837___r4_numbers_6_5 = string_to_symbol("2=");
symbol2841___r4_numbers_6_5 = string_to_symbol("=");
symbol2843___r4_numbers_6_5 = string_to_symbol("2<");
symbol2845___r4_numbers_6_5 = string_to_symbol("<");
symbol2846___r4_numbers_6_5 = string_to_symbol("2>");
symbol2848___r4_numbers_6_5 = string_to_symbol(">");
symbol2849___r4_numbers_6_5 = string_to_symbol("2<=");
symbol2851___r4_numbers_6_5 = string_to_symbol("<=");
symbol2852___r4_numbers_6_5 = string_to_symbol("2>=");
symbol2854___r4_numbers_6_5 = string_to_symbol(">=");
symbol2855___r4_numbers_6_5 = string_to_symbol("ZERO?");
symbol2857___r4_numbers_6_5 = string_to_symbol("POSITIVE?");
symbol2859___r4_numbers_6_5 = string_to_symbol("NEGATIVE?");
symbol2861___r4_numbers_6_5 = string_to_symbol("MAX");
symbol2862___r4_numbers_6_5 = string_to_symbol("MIN");
symbol2863___r4_numbers_6_5 = string_to_symbol("2+");
symbol2865___r4_numbers_6_5 = string_to_symbol("+");
symbol2866___r4_numbers_6_5 = string_to_symbol("2*");
symbol2868___r4_numbers_6_5 = string_to_symbol("*");
symbol2869___r4_numbers_6_5 = string_to_symbol("2-");
symbol2871___r4_numbers_6_5 = string_to_symbol("-");
symbol2872___r4_numbers_6_5 = string_to_symbol("2/");
symbol2874___r4_numbers_6_5 = string_to_symbol("/");
symbol2875___r4_numbers_6_5 = string_to_symbol("ABS");
symbol2877___r4_numbers_6_5 = string_to_symbol("FLOOR");
symbol2879___r4_numbers_6_5 = string_to_symbol("CEILING");
symbol2881___r4_numbers_6_5 = string_to_symbol("TRUNCATE");
symbol2883___r4_numbers_6_5 = string_to_symbol("ROUND");
symbol2885___r4_numbers_6_5 = string_to_symbol("EXP");
symbol2887___r4_numbers_6_5 = string_to_symbol("LOG");
symbol2889___r4_numbers_6_5 = string_to_symbol("SIN");
symbol2891___r4_numbers_6_5 = string_to_symbol("COS");
symbol2893___r4_numbers_6_5 = string_to_symbol("TAN");
symbol2895___r4_numbers_6_5 = string_to_symbol("ASIN");
symbol2897___r4_numbers_6_5 = string_to_symbol("ACOS");
symbol2899___r4_numbers_6_5 = string_to_symbol("ATAN");
symbol2904___r4_numbers_6_5 = string_to_symbol("SQRT");
symbol2907___r4_numbers_6_5 = string_to_symbol("EXPT");
symbol2910___r4_numbers_6_5 = string_to_symbol("EXACT->INEXACT");
symbol2911___r4_numbers_6_5 = string_to_symbol("INEXACT->EXACT");
symbol2912___r4_numbers_6_5 = string_to_symbol("NUMBER->STRING");
symbol2916___r4_numbers_6_5 = string_to_symbol("STRING->NUMBER");
symbol2924___r4_numbers_6_5 = string_to_symbol("string->real");
return (symbol2925___r4_numbers_6_5 = string_to_symbol("IMPORTED-MODULES-INIT"),
BUNSPEC);
}


/* number? */bool_t number__102___r4_numbers_6_5(obj_t obj_1)
{
{
obj_t symbol1447_3013;
symbol1447_3013 = symbol2827___r4_numbers_6_5;
{
PUSH_TRACE(symbol1447_3013);
BUNSPEC;
{
bool_t aux1446_3014;
if(INTEGERP(obj_1)){
aux1446_3014 = ((bool_t)1);
}
 else {
aux1446_3014 = REALP(obj_1);
}
POP_TRACE();
return aux1446_3014;
}
}
}
}


/* _number? */obj_t _number__137___r4_numbers_6_5(obj_t env_1724, obj_t obj_1725)
{
{
bool_t aux_3115;
{
obj_t obj_3015;
obj_3015 = obj_1725;
{
obj_t symbol1447_3016;
symbol1447_3016 = symbol2827___r4_numbers_6_5;
{
PUSH_TRACE(symbol1447_3016);
BUNSPEC;
{
bool_t aux1446_3017;
if(INTEGERP(obj_3015)){
aux1446_3017 = ((bool_t)1);
}
 else {
aux1446_3017 = REALP(obj_3015);
}
POP_TRACE();
aux_3115 = aux1446_3017;
}
}
}
}
return BBOOL(aux_3115);
}
}


/* exact? */bool_t exact__189___r4_numbers_6_5(obj_t z_2)
{
{
obj_t symbol1449_3018;
symbol1449_3018 = symbol2828___r4_numbers_6_5;
{
PUSH_TRACE(symbol1449_3018);
BUNSPEC;
{
bool_t aux1448_3019;
aux1448_3019 = INTEGERP(z_2);
POP_TRACE();
return aux1448_3019;
}
}
}
}


/* _exact? */obj_t _exact__208___r4_numbers_6_5(obj_t env_1726, obj_t z_1727)
{
{
bool_t aux_3125;
{
obj_t z_3020;
z_3020 = z_1727;
{
obj_t symbol1449_3021;
symbol1449_3021 = symbol2828___r4_numbers_6_5;
{
PUSH_TRACE(symbol1449_3021);
BUNSPEC;
{
bool_t aux1448_3022;
aux1448_3022 = INTEGERP(z_3020);
POP_TRACE();
aux_3125 = aux1448_3022;
}
}
}
}
return BBOOL(aux_3125);
}
}


/* inexact? */bool_t inexact__139___r4_numbers_6_5(obj_t z_3)
{
{
obj_t symbol1451_3023;
symbol1451_3023 = symbol2829___r4_numbers_6_5;
{
PUSH_TRACE(symbol1451_3023);
BUNSPEC;
{
bool_t aux1450_3024;
aux1450_3024 = REALP(z_3);
POP_TRACE();
return aux1450_3024;
}
}
}
}


/* _inexact? */obj_t _inexact__53___r4_numbers_6_5(obj_t env_1728, obj_t z_1729)
{
{
bool_t aux_3133;
{
obj_t z_3025;
z_3025 = z_1729;
{
obj_t symbol1451_3026;
symbol1451_3026 = symbol2829___r4_numbers_6_5;
{
PUSH_TRACE(symbol1451_3026);
BUNSPEC;
{
bool_t aux1450_3027;
aux1450_3027 = REALP(z_3025);
POP_TRACE();
aux_3133 = aux1450_3027;
}
}
}
}
return BBOOL(aux_3133);
}
}


/* complex? */bool_t complex__118___r4_numbers_6_5(obj_t x_4)
{
{
obj_t symbol1453_1630;
symbol1453_1630 = symbol2830___r4_numbers_6_5;
{
PUSH_TRACE(symbol1453_1630);
BUNSPEC;
{
bool_t aux1452_1631;
if(INTEGERP(x_4)){
aux1452_1631 = ((bool_t)1);
}
 else {
aux1452_1631 = REALP(x_4);
}
POP_TRACE();
return aux1452_1631;
}
}
}
}


/* _complex? */obj_t _complex__176___r4_numbers_6_5(obj_t env_1730, obj_t x_1731)
{
{
bool_t aux_3143;
aux_3143 = complex__118___r4_numbers_6_5(x_1731);
return BBOOL(aux_3143);
}
}


/* rational? */bool_t rational__51___r4_numbers_6_5(obj_t x_5)
{
{
obj_t symbol1455_1632;
symbol1455_1632 = symbol2831___r4_numbers_6_5;
{
PUSH_TRACE(symbol1455_1632);
BUNSPEC;
{
bool_t aux1454_1633;
if(INTEGERP(x_5)){
aux1454_1633 = ((bool_t)1);
}
 else {
aux1454_1633 = REALP(x_5);
}
POP_TRACE();
return aux1454_1633;
}
}
}
}


/* _rational? */obj_t _rational__24___r4_numbers_6_5(obj_t env_1732, obj_t x_1733)
{
{
bool_t aux_3151;
aux_3151 = rational__51___r4_numbers_6_5(x_1733);
return BBOOL(aux_3151);
}
}


/* flonum->fixnum */long flonum__fixnum_11___r4_numbers_6_5(obj_t x_6)
{
{
obj_t symbol1457_3028;
symbol1457_3028 = symbol2832___r4_numbers_6_5;
{
PUSH_TRACE(symbol1457_3028);
BUNSPEC;
{
long aux1456_3029;
{
double aux_3155;
{
obj_t aux_3156;
if(REALP(x_6)){
aux_3156 = x_6;
}
 else {
bigloo_type_error_location_103___error(symbol2832___r4_numbers_6_5, string2833___r4_numbers_6_5, x_6, string2834___r4_numbers_6_5, BINT(((long)6711)));
exit( -1 );}
aux_3155 = REAL_TO_DOUBLE(aux_3156);
}
aux1456_3029 = (long)(aux_3155);
}
POP_TRACE();
return aux1456_3029;
}
}
}
}


/* _flonum->fixnum */obj_t _flonum__fixnum_24___r4_numbers_6_5(obj_t env_1734, obj_t x_1735)
{
{
long aux_3165;
{
obj_t x_3030;
x_3030 = x_1735;
{
obj_t symbol1457_3031;
symbol1457_3031 = symbol2832___r4_numbers_6_5;
{
PUSH_TRACE(symbol1457_3031);
BUNSPEC;
{
long aux1456_3032;
{
double aux_3167;
{
obj_t aux_3168;
if(REALP(x_3030)){
aux_3168 = x_3030;
}
 else {
bigloo_type_error_location_103___error(symbol2832___r4_numbers_6_5, string2833___r4_numbers_6_5, x_3030, string2834___r4_numbers_6_5, BINT(((long)6711)));
exit( -1 );}
aux_3167 = REAL_TO_DOUBLE(aux_3168);
}
aux1456_3032 = (long)(aux_3167);
}
POP_TRACE();
aux_3165 = aux1456_3032;
}
}
}
}
return BINT(aux_3165);
}
}


/* fixnum->flonum */double fixnum__flonum_13___r4_numbers_6_5(obj_t x_7)
{
{
obj_t symbol1459_3033;
symbol1459_3033 = symbol2835___r4_numbers_6_5;
{
PUSH_TRACE(symbol1459_3033);
BUNSPEC;
{
double aux1458_3034;
{
long aux_3179;
{
obj_t aux_3180;
if(INTEGERP(x_7)){
aux_3180 = x_7;
}
 else {
bigloo_type_error_location_103___error(symbol2835___r4_numbers_6_5, string2836___r4_numbers_6_5, x_7, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3179 = (long)CINT(aux_3180);
}
aux1458_3034 = (double)(aux_3179);
}
POP_TRACE();
return aux1458_3034;
}
}
}
}


/* _fixnum->flonum */obj_t _fixnum__flonum_153___r4_numbers_6_5(obj_t env_1736, obj_t x_1737)
{
{
double aux_3189;
{
obj_t x_3035;
x_3035 = x_1737;
{
obj_t symbol1459_3036;
symbol1459_3036 = symbol2835___r4_numbers_6_5;
{
PUSH_TRACE(symbol1459_3036);
BUNSPEC;
{
double aux1458_3037;
{
long aux_3191;
{
obj_t aux_3192;
if(INTEGERP(x_3035)){
aux_3192 = x_3035;
}
 else {
bigloo_type_error_location_103___error(symbol2835___r4_numbers_6_5, string2836___r4_numbers_6_5, x_3035, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3191 = (long)CINT(aux_3192);
}
aux1458_3037 = (double)(aux_3191);
}
POP_TRACE();
aux_3189 = aux1458_3037;
}
}
}
}
return make_real(aux_3189);
}
}


/* 2= */bool_t _2__95___r4_numbers_6_5(obj_t x_8, obj_t y_9)
{
{
obj_t symbol1461_1638;
symbol1461_1638 = symbol2837___r4_numbers_6_5;
{
PUSH_TRACE(symbol1461_1638);
BUNSPEC;
{
bool_t aux1460_1639;
{
bool_t test1011_338;
test1011_338 = INTEGERP(x_8);
if(test1011_338){
{
bool_t test1012_339;
test1012_339 = INTEGERP(y_9);
if(test1012_339){
{
long n1_779;
long n2_780;
{
obj_t aux_3207;
if(test1011_338){
aux_3207 = x_8;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2836___r4_numbers_6_5, x_8, string2834___r4_numbers_6_5, BINT(((long)7325)));
exit( -1 );}
n1_779 = (long)CINT(aux_3207);
}
{
obj_t aux_3213;
if(test1012_339){
aux_3213 = y_9;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2836___r4_numbers_6_5, y_9, string2834___r4_numbers_6_5, BINT(((long)7329)));
exit( -1 );}
n2_780 = (long)CINT(aux_3213);
}
aux1460_1639 = (n1_779==n2_780);
}
}
 else {
bool_t test1013_340;
test1013_340 = REALP(y_9);
if(test1013_340){
{
double arg1014_341;
{
long aux_3222;
{
obj_t aux_3223;
if(test1011_338){
aux_3223 = x_8;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2836___r4_numbers_6_5, x_8, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3222 = (long)CINT(aux_3223);
}
arg1014_341 = (double)(aux_3222);
}
{
double r2_784;
{
obj_t aux_3230;
if(test1013_340){
aux_3230 = y_9;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2833___r4_numbers_6_5, y_9, string2834___r4_numbers_6_5, BINT(((long)7355)));
exit( -1 );}
r2_784 = REAL_TO_DOUBLE(aux_3230);
}
aux1460_1639 = (arg1014_341==r2_784);
}
}
}
 else {
{
obj_t aux_3237;
aux_3237 = debug_error_location_199___error(string2838___r4_numbers_6_5, string2839___r4_numbers_6_5, y_9, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1460_1639 = CBOOL(aux_3237);
}
}
}
}
}
 else {
bool_t test1015_342;
test1015_342 = REALP(x_8);
if(test1015_342){
{
bool_t test1016_343;
test1016_343 = REALP(y_9);
if(test1016_343){
{
double r1_790;
double r2_791;
{
obj_t aux_3245;
if(test1015_342){
aux_3245 = x_8;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2833___r4_numbers_6_5, x_8, string2834___r4_numbers_6_5, BINT(((long)7481)));
exit( -1 );}
r1_790 = REAL_TO_DOUBLE(aux_3245);
}
{
obj_t aux_3251;
if(test1016_343){
aux_3251 = y_9;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2833___r4_numbers_6_5, y_9, string2834___r4_numbers_6_5, BINT(((long)7485)));
exit( -1 );}
r2_791 = REAL_TO_DOUBLE(aux_3251);
}
aux1460_1639 = (r1_790==r2_791);
}
}
 else {
bool_t test1017_344;
test1017_344 = INTEGERP(y_9);
if(test1017_344){
{
double arg1018_345;
{
long aux_3260;
{
obj_t aux_3261;
if(test1017_344){
aux_3261 = y_9;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2836___r4_numbers_6_5, y_9, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3260 = (long)CINT(aux_3261);
}
arg1018_345 = (double)(aux_3260);
}
{
double r1_794;
{
obj_t aux_3268;
if(test1015_342){
aux_3268 = x_8;
}
 else {
bigloo_type_error_location_103___error(symbol2837___r4_numbers_6_5, string2833___r4_numbers_6_5, x_8, string2834___r4_numbers_6_5, BINT(((long)7511)));
exit( -1 );}
r1_794 = REAL_TO_DOUBLE(aux_3268);
}
aux1460_1639 = (r1_794==arg1018_345);
}
}
}
 else {
{
obj_t aux_3275;
aux_3275 = debug_error_location_199___error(string2838___r4_numbers_6_5, string2839___r4_numbers_6_5, y_9, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1460_1639 = CBOOL(aux_3275);
}
}
}
}
}
 else {
{
obj_t aux_3279;
aux_3279 = debug_error_location_199___error(string2838___r4_numbers_6_5, string2839___r4_numbers_6_5, x_8, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1460_1639 = CBOOL(aux_3279);
}
}
}
}
POP_TRACE();
return aux1460_1639;
}
}
}
}


/* _2= */obj_t _2__245___r4_numbers_6_5(obj_t env_1738, obj_t x_1739, obj_t y_1740)
{
{
bool_t aux_3284;
aux_3284 = _2__95___r4_numbers_6_5(x_1739, y_1740);
return BBOOL(aux_3284);
}
}


/* = */bool_t __147___r4_numbers_6_5(obj_t x_10, obj_t y_11, obj_t z_12)
{
{
obj_t symbol1463_1640;
symbol1463_1640 = symbol2841___r4_numbers_6_5;
{
PUSH_TRACE(symbol1463_1640);
BUNSPEC;
{
bool_t aux1462_1641;
{
obj_t x_348;
obj_t z_349;
{
bool_t _andtest_1002_347;
_andtest_1002_347 = _2__95___r4_numbers_6_5(x_10, y_11);
if(_andtest_1002_347){
x_348 = y_11;
z_349 = z_12;
__list_168_355:
if(NULLP(z_349)){
aux1462_1641 = ((bool_t)1);
}
 else {
bool_t test1021_352;
{
obj_t arg1023_354;
{
obj_t pair_803;
if(PAIRP(z_349)){
pair_803 = z_349;
}
 else {
bigloo_type_error_location_103___error(symbol2841___r4_numbers_6_5, string2842___r4_numbers_6_5, z_349, string2834___r4_numbers_6_5, BINT(((long)7952)));
exit( -1 );}
arg1023_354 = CAR(pair_803);
}
test1021_352 = _2__95___r4_numbers_6_5(x_348, arg1023_354);
}
if(test1021_352){
{
obj_t arg1022_353;
{
obj_t pair_804;
if(PAIRP(z_349)){
pair_804 = z_349;
}
 else {
bigloo_type_error_location_103___error(symbol2841___r4_numbers_6_5, string2842___r4_numbers_6_5, z_349, string2834___r4_numbers_6_5, BINT(((long)7973)));
exit( -1 );}
arg1022_353 = CDR(pair_804);
}
{
obj_t z_3306;
z_3306 = arg1022_353;
z_349 = z_3306;
goto __list_168_355;
}
}
}
 else {
aux1462_1641 = ((bool_t)0);
}
}
}
 else {
aux1462_1641 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1462_1641;
}
}
}
}


/* _= */obj_t ___44___r4_numbers_6_5(obj_t env_1741, obj_t x_1742, obj_t y_1743, obj_t z_1744)
{
{
bool_t aux_3308;
aux_3308 = __147___r4_numbers_6_5(x_1742, y_1743, z_1744);
return BBOOL(aux_3308);
}
}


/* 2< */bool_t _2__116___r4_numbers_6_5(obj_t x_13, obj_t y_14)
{
{
obj_t symbol1465_1642;
symbol1465_1642 = symbol2843___r4_numbers_6_5;
{
PUSH_TRACE(symbol1465_1642);
BUNSPEC;
{
bool_t aux1464_1643;
{
bool_t test1024_356;
test1024_356 = INTEGERP(x_13);
if(test1024_356){
{
bool_t test1025_357;
test1025_357 = INTEGERP(y_14);
if(test1025_357){
{
long n1_807;
long n2_808;
{
obj_t aux_3316;
if(test1024_356){
aux_3316 = x_13;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2836___r4_numbers_6_5, x_13, string2834___r4_numbers_6_5, BINT(((long)8337)));
exit( -1 );}
n1_807 = (long)CINT(aux_3316);
}
{
obj_t aux_3322;
if(test1025_357){
aux_3322 = y_14;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2836___r4_numbers_6_5, y_14, string2834___r4_numbers_6_5, BINT(((long)8341)));
exit( -1 );}
n2_808 = (long)CINT(aux_3322);
}
aux1464_1643 = (n1_807<n2_808);
}
}
 else {
bool_t test1026_358;
test1026_358 = REALP(y_14);
if(test1026_358){
{
double arg1027_359;
{
long aux_3331;
{
obj_t aux_3332;
if(test1024_356){
aux_3332 = x_13;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2836___r4_numbers_6_5, x_13, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3331 = (long)CINT(aux_3332);
}
arg1027_359 = (double)(aux_3331);
}
{
double r2_812;
{
obj_t aux_3339;
if(test1026_358){
aux_3339 = y_14;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2833___r4_numbers_6_5, y_14, string2834___r4_numbers_6_5, BINT(((long)8367)));
exit( -1 );}
r2_812 = REAL_TO_DOUBLE(aux_3339);
}
aux1464_1643 = (arg1027_359<r2_812);
}
}
}
 else {
{
obj_t aux_3346;
aux_3346 = debug_error_location_199___error(string2844___r4_numbers_6_5, string2839___r4_numbers_6_5, y_14, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1464_1643 = CBOOL(aux_3346);
}
}
}
}
}
 else {
bool_t test1028_360;
test1028_360 = REALP(x_13);
if(test1028_360){
{
bool_t test1029_361;
test1029_361 = REALP(y_14);
if(test1029_361){
{
double r1_818;
double r2_819;
{
obj_t aux_3354;
if(test1028_360){
aux_3354 = x_13;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2833___r4_numbers_6_5, x_13, string2834___r4_numbers_6_5, BINT(((long)8493)));
exit( -1 );}
r1_818 = REAL_TO_DOUBLE(aux_3354);
}
{
obj_t aux_3360;
if(test1029_361){
aux_3360 = y_14;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2833___r4_numbers_6_5, y_14, string2834___r4_numbers_6_5, BINT(((long)8497)));
exit( -1 );}
r2_819 = REAL_TO_DOUBLE(aux_3360);
}
aux1464_1643 = (r1_818<r2_819);
}
}
 else {
bool_t test1030_362;
test1030_362 = INTEGERP(y_14);
if(test1030_362){
{
double arg1031_363;
{
long aux_3369;
{
obj_t aux_3370;
if(test1030_362){
aux_3370 = y_14;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2836___r4_numbers_6_5, y_14, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3369 = (long)CINT(aux_3370);
}
arg1031_363 = (double)(aux_3369);
}
{
double r1_822;
{
obj_t aux_3377;
if(test1028_360){
aux_3377 = x_13;
}
 else {
bigloo_type_error_location_103___error(symbol2843___r4_numbers_6_5, string2833___r4_numbers_6_5, x_13, string2834___r4_numbers_6_5, BINT(((long)8523)));
exit( -1 );}
r1_822 = REAL_TO_DOUBLE(aux_3377);
}
aux1464_1643 = (r1_822<arg1031_363);
}
}
}
 else {
{
obj_t aux_3384;
aux_3384 = debug_error_location_199___error(string2844___r4_numbers_6_5, string2839___r4_numbers_6_5, y_14, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1464_1643 = CBOOL(aux_3384);
}
}
}
}
}
 else {
{
obj_t aux_3388;
aux_3388 = debug_error_location_199___error(string2844___r4_numbers_6_5, string2839___r4_numbers_6_5, x_13, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1464_1643 = CBOOL(aux_3388);
}
}
}
}
POP_TRACE();
return aux1464_1643;
}
}
}
}


/* _2< */obj_t _2__208___r4_numbers_6_5(obj_t env_1745, obj_t x_1746, obj_t y_1747)
{
{
bool_t aux_3393;
aux_3393 = _2__116___r4_numbers_6_5(x_1746, y_1747);
return BBOOL(aux_3393);
}
}


/* < */bool_t __124___r4_numbers_6_5(obj_t x_15, obj_t y_16, obj_t z_17)
{
{
obj_t symbol1467_1644;
symbol1467_1644 = symbol2845___r4_numbers_6_5;
{
PUSH_TRACE(symbol1467_1644);
BUNSPEC;
{
bool_t aux1466_1645;
{
obj_t x_366;
obj_t z_367;
{
bool_t _andtest_1003_365;
_andtest_1003_365 = _2__116___r4_numbers_6_5(x_15, y_16);
if(_andtest_1003_365){
x_366 = y_16;
z_367 = z_17;
__list_80_374:
if(NULLP(z_367)){
aux1466_1645 = ((bool_t)1);
}
 else {
bool_t test1034_370;
{
obj_t arg1038_373;
{
obj_t pair_831;
if(PAIRP(z_367)){
pair_831 = z_367;
}
 else {
bigloo_type_error_location_103___error(symbol2845___r4_numbers_6_5, string2842___r4_numbers_6_5, z_367, string2834___r4_numbers_6_5, BINT(((long)8964)));
exit( -1 );}
arg1038_373 = CAR(pair_831);
}
test1034_370 = _2__116___r4_numbers_6_5(x_366, arg1038_373);
}
if(test1034_370){
{
obj_t arg1035_371;
obj_t arg1037_372;
{
obj_t pair_832;
if(PAIRP(z_367)){
pair_832 = z_367;
}
 else {
bigloo_type_error_location_103___error(symbol2845___r4_numbers_6_5, string2842___r4_numbers_6_5, z_367, string2834___r4_numbers_6_5, BINT(((long)8983)));
exit( -1 );}
arg1035_371 = CAR(pair_832);
}
{
obj_t pair_833;
if(PAIRP(z_367)){
pair_833 = z_367;
}
 else {
bigloo_type_error_location_103___error(symbol2845___r4_numbers_6_5, string2842___r4_numbers_6_5, z_367, string2834___r4_numbers_6_5, BINT(((long)8991)));
exit( -1 );}
arg1037_372 = CDR(pair_833);
}
{
obj_t z_3422;
obj_t x_3421;
x_3421 = arg1035_371;
z_3422 = arg1037_372;
z_367 = z_3422;
x_366 = x_3421;
goto __list_80_374;
}
}
}
 else {
aux1466_1645 = ((bool_t)0);
}
}
}
 else {
aux1466_1645 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1466_1645;
}
}
}
}


/* _< */obj_t ___38___r4_numbers_6_5(obj_t env_1748, obj_t x_1749, obj_t y_1750, obj_t z_1751)
{
{
bool_t aux_3424;
aux_3424 = __124___r4_numbers_6_5(x_1749, y_1750, z_1751);
return BBOOL(aux_3424);
}
}


/* 2> */bool_t _2__206___r4_numbers_6_5(obj_t x_18, obj_t y_19)
{
{
obj_t symbol1469_1646;
symbol1469_1646 = symbol2846___r4_numbers_6_5;
{
PUSH_TRACE(symbol1469_1646);
BUNSPEC;
{
bool_t aux1468_1647;
{
bool_t test1039_375;
test1039_375 = INTEGERP(x_18);
if(test1039_375){
{
bool_t test1040_376;
test1040_376 = INTEGERP(y_19);
if(test1040_376){
{
long n1_836;
long n2_837;
{
obj_t aux_3432;
if(test1039_375){
aux_3432 = x_18;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2836___r4_numbers_6_5, x_18, string2834___r4_numbers_6_5, BINT(((long)9359)));
exit( -1 );}
n1_836 = (long)CINT(aux_3432);
}
{
obj_t aux_3438;
if(test1040_376){
aux_3438 = y_19;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2836___r4_numbers_6_5, y_19, string2834___r4_numbers_6_5, BINT(((long)9363)));
exit( -1 );}
n2_837 = (long)CINT(aux_3438);
}
aux1468_1647 = (n1_836>n2_837);
}
}
 else {
bool_t test1041_377;
test1041_377 = REALP(y_19);
if(test1041_377){
{
double arg1042_378;
{
long aux_3447;
{
obj_t aux_3448;
if(test1039_375){
aux_3448 = x_18;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2836___r4_numbers_6_5, x_18, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3447 = (long)CINT(aux_3448);
}
arg1042_378 = (double)(aux_3447);
}
{
double r2_841;
{
obj_t aux_3455;
if(test1041_377){
aux_3455 = y_19;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2833___r4_numbers_6_5, y_19, string2834___r4_numbers_6_5, BINT(((long)9389)));
exit( -1 );}
r2_841 = REAL_TO_DOUBLE(aux_3455);
}
aux1468_1647 = (arg1042_378>r2_841);
}
}
}
 else {
{
obj_t aux_3462;
aux_3462 = debug_error_location_199___error(string2847___r4_numbers_6_5, string2839___r4_numbers_6_5, y_19, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1468_1647 = CBOOL(aux_3462);
}
}
}
}
}
 else {
bool_t test1043_379;
test1043_379 = REALP(x_18);
if(test1043_379){
{
bool_t test1044_380;
test1044_380 = REALP(y_19);
if(test1044_380){
{
double r1_847;
double r2_848;
{
obj_t aux_3470;
if(test1043_379){
aux_3470 = x_18;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2833___r4_numbers_6_5, x_18, string2834___r4_numbers_6_5, BINT(((long)9515)));
exit( -1 );}
r1_847 = REAL_TO_DOUBLE(aux_3470);
}
{
obj_t aux_3476;
if(test1044_380){
aux_3476 = y_19;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2833___r4_numbers_6_5, y_19, string2834___r4_numbers_6_5, BINT(((long)9519)));
exit( -1 );}
r2_848 = REAL_TO_DOUBLE(aux_3476);
}
aux1468_1647 = (r1_847>r2_848);
}
}
 else {
bool_t test1045_381;
test1045_381 = INTEGERP(y_19);
if(test1045_381){
{
double arg1046_382;
{
long aux_3485;
{
obj_t aux_3486;
if(test1045_381){
aux_3486 = y_19;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2836___r4_numbers_6_5, y_19, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3485 = (long)CINT(aux_3486);
}
arg1046_382 = (double)(aux_3485);
}
{
double r1_851;
{
obj_t aux_3493;
if(test1043_379){
aux_3493 = x_18;
}
 else {
bigloo_type_error_location_103___error(symbol2846___r4_numbers_6_5, string2833___r4_numbers_6_5, x_18, string2834___r4_numbers_6_5, BINT(((long)9545)));
exit( -1 );}
r1_851 = REAL_TO_DOUBLE(aux_3493);
}
aux1468_1647 = (r1_851>arg1046_382);
}
}
}
 else {
{
obj_t aux_3500;
aux_3500 = debug_error_location_199___error(string2847___r4_numbers_6_5, string2839___r4_numbers_6_5, y_19, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1468_1647 = CBOOL(aux_3500);
}
}
}
}
}
 else {
{
obj_t aux_3504;
aux_3504 = debug_error_location_199___error(string2847___r4_numbers_6_5, string2839___r4_numbers_6_5, x_18, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1468_1647 = CBOOL(aux_3504);
}
}
}
}
POP_TRACE();
return aux1468_1647;
}
}
}
}


/* _2> */obj_t _2__130___r4_numbers_6_5(obj_t env_1752, obj_t x_1753, obj_t y_1754)
{
{
bool_t aux_3509;
aux_3509 = _2__206___r4_numbers_6_5(x_1753, y_1754);
return BBOOL(aux_3509);
}
}


/* > */bool_t __172___r4_numbers_6_5(obj_t x_20, obj_t y_21, obj_t z_22)
{
{
obj_t symbol1471_1648;
symbol1471_1648 = symbol2848___r4_numbers_6_5;
{
PUSH_TRACE(symbol1471_1648);
BUNSPEC;
{
bool_t aux1470_1649;
{
obj_t x_385;
obj_t z_386;
{
bool_t _andtest_1004_384;
_andtest_1004_384 = _2__206___r4_numbers_6_5(x_20, y_21);
if(_andtest_1004_384){
x_385 = y_21;
z_386 = z_22;
__list_166_393:
if(NULLP(z_386)){
aux1470_1649 = ((bool_t)1);
}
 else {
bool_t test1049_389;
{
obj_t arg1053_392;
{
obj_t pair_860;
if(PAIRP(z_386)){
pair_860 = z_386;
}
 else {
bigloo_type_error_location_103___error(symbol2848___r4_numbers_6_5, string2842___r4_numbers_6_5, z_386, string2834___r4_numbers_6_5, BINT(((long)9986)));
exit( -1 );}
arg1053_392 = CAR(pair_860);
}
test1049_389 = _2__206___r4_numbers_6_5(x_385, arg1053_392);
}
if(test1049_389){
{
obj_t arg1050_390;
obj_t arg1051_391;
{
obj_t pair_861;
if(PAIRP(z_386)){
pair_861 = z_386;
}
 else {
bigloo_type_error_location_103___error(symbol2848___r4_numbers_6_5, string2842___r4_numbers_6_5, z_386, string2834___r4_numbers_6_5, BINT(((long)10005)));
exit( -1 );}
arg1050_390 = CAR(pair_861);
}
{
obj_t pair_862;
if(PAIRP(z_386)){
pair_862 = z_386;
}
 else {
bigloo_type_error_location_103___error(symbol2848___r4_numbers_6_5, string2842___r4_numbers_6_5, z_386, string2834___r4_numbers_6_5, BINT(((long)10013)));
exit( -1 );}
arg1051_391 = CDR(pair_862);
}
{
obj_t z_3538;
obj_t x_3537;
x_3537 = arg1050_390;
z_3538 = arg1051_391;
z_386 = z_3538;
x_385 = x_3537;
goto __list_166_393;
}
}
}
 else {
aux1470_1649 = ((bool_t)0);
}
}
}
 else {
aux1470_1649 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1470_1649;
}
}
}
}


/* _> */obj_t ___149___r4_numbers_6_5(obj_t env_1755, obj_t x_1756, obj_t y_1757, obj_t z_1758)
{
{
bool_t aux_3540;
aux_3540 = __172___r4_numbers_6_5(x_1756, y_1757, z_1758);
return BBOOL(aux_3540);
}
}


/* 2<= */bool_t _2___241___r4_numbers_6_5(obj_t x_23, obj_t y_24)
{
{
obj_t symbol1473_1650;
symbol1473_1650 = symbol2849___r4_numbers_6_5;
{
PUSH_TRACE(symbol1473_1650);
BUNSPEC;
{
bool_t aux1472_1651;
{
bool_t test1054_394;
test1054_394 = INTEGERP(x_23);
if(test1054_394){
{
bool_t test1055_395;
test1055_395 = INTEGERP(y_24);
if(test1055_395){
{
long n1_865;
long n2_866;
{
obj_t aux_3548;
if(test1054_394){
aux_3548 = x_23;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2836___r4_numbers_6_5, x_23, string2834___r4_numbers_6_5, BINT(((long)10379)));
exit( -1 );}
n1_865 = (long)CINT(aux_3548);
}
{
obj_t aux_3554;
if(test1055_395){
aux_3554 = y_24;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2836___r4_numbers_6_5, y_24, string2834___r4_numbers_6_5, BINT(((long)10384)));
exit( -1 );}
n2_866 = (long)CINT(aux_3554);
}
aux1472_1651 = (n1_865<=n2_866);
}
}
 else {
bool_t test1056_396;
test1056_396 = REALP(y_24);
if(test1056_396){
{
double arg1057_397;
{
long aux_3563;
{
obj_t aux_3564;
if(test1054_394){
aux_3564 = x_23;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2836___r4_numbers_6_5, x_23, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3563 = (long)CINT(aux_3564);
}
arg1057_397 = (double)(aux_3563);
}
{
double r2_870;
{
obj_t aux_3571;
if(test1056_396){
aux_3571 = y_24;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2833___r4_numbers_6_5, y_24, string2834___r4_numbers_6_5, BINT(((long)10410)));
exit( -1 );}
r2_870 = REAL_TO_DOUBLE(aux_3571);
}
aux1472_1651 = (arg1057_397<=r2_870);
}
}
}
 else {
{
obj_t aux_3578;
aux_3578 = debug_error_location_199___error(string2850___r4_numbers_6_5, string2839___r4_numbers_6_5, y_24, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1472_1651 = CBOOL(aux_3578);
}
}
}
}
}
 else {
bool_t test1058_398;
test1058_398 = REALP(x_23);
if(test1058_398){
{
bool_t test1059_399;
test1059_399 = REALP(y_24);
if(test1059_399){
{
double r1_876;
double r2_877;
{
obj_t aux_3586;
if(test1058_398){
aux_3586 = x_23;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2833___r4_numbers_6_5, x_23, string2834___r4_numbers_6_5, BINT(((long)10538)));
exit( -1 );}
r1_876 = REAL_TO_DOUBLE(aux_3586);
}
{
obj_t aux_3592;
if(test1059_399){
aux_3592 = y_24;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2833___r4_numbers_6_5, y_24, string2834___r4_numbers_6_5, BINT(((long)10543)));
exit( -1 );}
r2_877 = REAL_TO_DOUBLE(aux_3592);
}
aux1472_1651 = (r1_876<=r2_877);
}
}
 else {
bool_t test1060_400;
test1060_400 = INTEGERP(y_24);
if(test1060_400){
{
double arg1061_401;
{
long aux_3601;
{
obj_t aux_3602;
if(test1060_400){
aux_3602 = y_24;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2836___r4_numbers_6_5, y_24, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3601 = (long)CINT(aux_3602);
}
arg1061_401 = (double)(aux_3601);
}
{
double r1_880;
{
obj_t aux_3609;
if(test1058_398){
aux_3609 = x_23;
}
 else {
bigloo_type_error_location_103___error(symbol2849___r4_numbers_6_5, string2833___r4_numbers_6_5, x_23, string2834___r4_numbers_6_5, BINT(((long)10569)));
exit( -1 );}
r1_880 = REAL_TO_DOUBLE(aux_3609);
}
aux1472_1651 = (r1_880<=arg1061_401);
}
}
}
 else {
{
obj_t aux_3616;
aux_3616 = debug_error_location_199___error(string2850___r4_numbers_6_5, string2839___r4_numbers_6_5, y_24, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1472_1651 = CBOOL(aux_3616);
}
}
}
}
}
 else {
{
obj_t aux_3620;
aux_3620 = debug_error_location_199___error(string2850___r4_numbers_6_5, string2839___r4_numbers_6_5, x_23, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1472_1651 = CBOOL(aux_3620);
}
}
}
}
POP_TRACE();
return aux1472_1651;
}
}
}
}


/* _2<= */obj_t _2___117___r4_numbers_6_5(obj_t env_1759, obj_t x_1760, obj_t y_1761)
{
{
bool_t aux_3625;
aux_3625 = _2___241___r4_numbers_6_5(x_1760, y_1761);
return BBOOL(aux_3625);
}
}


/* <= */bool_t ___161___r4_numbers_6_5(obj_t x_25, obj_t y_26, obj_t z_27)
{
{
obj_t symbol1475_1652;
symbol1475_1652 = symbol2851___r4_numbers_6_5;
{
PUSH_TRACE(symbol1475_1652);
BUNSPEC;
{
bool_t aux1474_1653;
{
obj_t x_404;
obj_t z_405;
{
bool_t _andtest_1005_403;
_andtest_1005_403 = _2___241___r4_numbers_6_5(x_25, y_26);
if(_andtest_1005_403){
x_404 = y_26;
z_405 = z_27;
___list_79_412:
if(NULLP(z_405)){
aux1474_1653 = ((bool_t)1);
}
 else {
bool_t test1064_408;
{
obj_t arg1067_411;
{
obj_t pair_889;
if(PAIRP(z_405)){
pair_889 = z_405;
}
 else {
bigloo_type_error_location_103___error(symbol2851___r4_numbers_6_5, string2842___r4_numbers_6_5, z_405, string2834___r4_numbers_6_5, BINT(((long)11005)));
exit( -1 );}
arg1067_411 = CAR(pair_889);
}
test1064_408 = _2___241___r4_numbers_6_5(x_404, arg1067_411);
}
if(test1064_408){
{
obj_t arg1065_409;
obj_t arg1066_410;
{
obj_t pair_890;
if(PAIRP(z_405)){
pair_890 = z_405;
}
 else {
bigloo_type_error_location_103___error(symbol2851___r4_numbers_6_5, string2842___r4_numbers_6_5, z_405, string2834___r4_numbers_6_5, BINT(((long)11026)));
exit( -1 );}
arg1065_409 = CAR(pair_890);
}
{
obj_t pair_891;
if(PAIRP(z_405)){
pair_891 = z_405;
}
 else {
bigloo_type_error_location_103___error(symbol2851___r4_numbers_6_5, string2842___r4_numbers_6_5, z_405, string2834___r4_numbers_6_5, BINT(((long)11034)));
exit( -1 );}
arg1066_410 = CDR(pair_891);
}
{
obj_t z_3654;
obj_t x_3653;
x_3653 = arg1065_409;
z_3654 = arg1066_410;
z_405 = z_3654;
x_404 = x_3653;
goto ___list_79_412;
}
}
}
 else {
aux1474_1653 = ((bool_t)0);
}
}
}
 else {
aux1474_1653 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1474_1653;
}
}
}
}


/* _<= */obj_t ____73___r4_numbers_6_5(obj_t env_1762, obj_t x_1763, obj_t y_1764, obj_t z_1765)
{
{
bool_t aux_3656;
aux_3656 = ___161___r4_numbers_6_5(x_1763, y_1764, z_1765);
return BBOOL(aux_3656);
}
}


/* 2>= */bool_t _2___235___r4_numbers_6_5(obj_t x_28, obj_t y_29)
{
{
obj_t symbol1477_1654;
symbol1477_1654 = symbol2852___r4_numbers_6_5;
{
PUSH_TRACE(symbol1477_1654);
BUNSPEC;
{
bool_t aux1476_1655;
{
bool_t test1068_413;
test1068_413 = INTEGERP(x_28);
if(test1068_413){
{
bool_t test1069_414;
test1069_414 = INTEGERP(y_29);
if(test1069_414){
{
long n1_894;
long n2_895;
{
obj_t aux_3664;
if(test1068_413){
aux_3664 = x_28;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2836___r4_numbers_6_5, x_28, string2834___r4_numbers_6_5, BINT(((long)11395)));
exit( -1 );}
n1_894 = (long)CINT(aux_3664);
}
{
obj_t aux_3670;
if(test1069_414){
aux_3670 = y_29;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2836___r4_numbers_6_5, y_29, string2834___r4_numbers_6_5, BINT(((long)11400)));
exit( -1 );}
n2_895 = (long)CINT(aux_3670);
}
aux1476_1655 = (n1_894>=n2_895);
}
}
 else {
bool_t test1070_415;
test1070_415 = REALP(y_29);
if(test1070_415){
{
double arg1072_416;
{
long aux_3679;
{
obj_t aux_3680;
if(test1068_413){
aux_3680 = x_28;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2836___r4_numbers_6_5, x_28, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3679 = (long)CINT(aux_3680);
}
arg1072_416 = (double)(aux_3679);
}
{
double r2_899;
{
obj_t aux_3687;
if(test1070_415){
aux_3687 = y_29;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2833___r4_numbers_6_5, y_29, string2834___r4_numbers_6_5, BINT(((long)11426)));
exit( -1 );}
r2_899 = REAL_TO_DOUBLE(aux_3687);
}
aux1476_1655 = (arg1072_416>=r2_899);
}
}
}
 else {
{
obj_t aux_3694;
aux_3694 = debug_error_location_199___error(string2853___r4_numbers_6_5, string2839___r4_numbers_6_5, y_29, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1476_1655 = CBOOL(aux_3694);
}
}
}
}
}
 else {
bool_t test1073_417;
test1073_417 = REALP(x_28);
if(test1073_417){
{
bool_t test1074_418;
test1074_418 = REALP(y_29);
if(test1074_418){
{
double r1_905;
double r2_906;
{
obj_t aux_3702;
if(test1073_417){
aux_3702 = x_28;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2833___r4_numbers_6_5, x_28, string2834___r4_numbers_6_5, BINT(((long)11554)));
exit( -1 );}
r1_905 = REAL_TO_DOUBLE(aux_3702);
}
{
obj_t aux_3708;
if(test1074_418){
aux_3708 = y_29;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2833___r4_numbers_6_5, y_29, string2834___r4_numbers_6_5, BINT(((long)11559)));
exit( -1 );}
r2_906 = REAL_TO_DOUBLE(aux_3708);
}
aux1476_1655 = (r1_905>=r2_906);
}
}
 else {
bool_t test1075_419;
test1075_419 = INTEGERP(y_29);
if(test1075_419){
{
double arg1076_420;
{
long aux_3717;
{
obj_t aux_3718;
if(test1075_419){
aux_3718 = y_29;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2836___r4_numbers_6_5, y_29, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3717 = (long)CINT(aux_3718);
}
arg1076_420 = (double)(aux_3717);
}
{
double r1_909;
{
obj_t aux_3725;
if(test1073_417){
aux_3725 = x_28;
}
 else {
bigloo_type_error_location_103___error(symbol2852___r4_numbers_6_5, string2833___r4_numbers_6_5, x_28, string2834___r4_numbers_6_5, BINT(((long)11585)));
exit( -1 );}
r1_909 = REAL_TO_DOUBLE(aux_3725);
}
aux1476_1655 = (r1_909>=arg1076_420);
}
}
}
 else {
{
obj_t aux_3732;
aux_3732 = debug_error_location_199___error(string2853___r4_numbers_6_5, string2839___r4_numbers_6_5, y_29, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1476_1655 = CBOOL(aux_3732);
}
}
}
}
}
 else {
{
obj_t aux_3736;
aux_3736 = debug_error_location_199___error(string2853___r4_numbers_6_5, string2839___r4_numbers_6_5, x_28, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1476_1655 = CBOOL(aux_3736);
}
}
}
}
POP_TRACE();
return aux1476_1655;
}
}
}
}


/* _2>= */obj_t _2___43___r4_numbers_6_5(obj_t env_1766, obj_t x_1767, obj_t y_1768)
{
{
bool_t aux_3741;
aux_3741 = _2___235___r4_numbers_6_5(x_1767, y_1768);
return BBOOL(aux_3741);
}
}


/* >= */bool_t ___239___r4_numbers_6_5(obj_t x_30, obj_t y_31, obj_t z_32)
{
{
obj_t symbol1479_1656;
symbol1479_1656 = symbol2854___r4_numbers_6_5;
{
PUSH_TRACE(symbol1479_1656);
BUNSPEC;
{
bool_t aux1478_1657;
{
obj_t x_423;
obj_t z_424;
{
bool_t _andtest_1006_422;
_andtest_1006_422 = _2___235___r4_numbers_6_5(x_30, y_31);
if(_andtest_1006_422){
x_423 = y_31;
z_424 = z_32;
___list_225_431:
if(NULLP(z_424)){
aux1478_1657 = ((bool_t)1);
}
 else {
bool_t test1079_427;
{
obj_t arg1082_430;
{
obj_t pair_918;
if(PAIRP(z_424)){
pair_918 = z_424;
}
 else {
bigloo_type_error_location_103___error(symbol2854___r4_numbers_6_5, string2842___r4_numbers_6_5, z_424, string2834___r4_numbers_6_5, BINT(((long)12032)));
exit( -1 );}
arg1082_430 = CAR(pair_918);
}
test1079_427 = _2___235___r4_numbers_6_5(x_423, arg1082_430);
}
if(test1079_427){
{
obj_t arg1080_428;
obj_t arg1081_429;
{
obj_t pair_919;
if(PAIRP(z_424)){
pair_919 = z_424;
}
 else {
bigloo_type_error_location_103___error(symbol2854___r4_numbers_6_5, string2842___r4_numbers_6_5, z_424, string2834___r4_numbers_6_5, BINT(((long)12052)));
exit( -1 );}
arg1080_428 = CAR(pair_919);
}
{
obj_t pair_920;
if(PAIRP(z_424)){
pair_920 = z_424;
}
 else {
bigloo_type_error_location_103___error(symbol2854___r4_numbers_6_5, string2842___r4_numbers_6_5, z_424, string2834___r4_numbers_6_5, BINT(((long)12060)));
exit( -1 );}
arg1081_429 = CDR(pair_920);
}
{
obj_t z_3770;
obj_t x_3769;
x_3769 = arg1080_428;
z_3770 = arg1081_429;
z_424 = z_3770;
x_423 = x_3769;
goto ___list_225_431;
}
}
}
 else {
aux1478_1657 = ((bool_t)0);
}
}
}
 else {
aux1478_1657 = ((bool_t)0);
}
}
}
POP_TRACE();
return aux1478_1657;
}
}
}
}


/* _>= */obj_t ____251___r4_numbers_6_5(obj_t env_1769, obj_t x_1770, obj_t y_1771, obj_t z_1772)
{
{
bool_t aux_3772;
aux_3772 = ___239___r4_numbers_6_5(x_1770, y_1771, z_1772);
return BBOOL(aux_3772);
}
}


/* zero? */bool_t zero__228___r4_numbers_6_5(obj_t x_33)
{
{
obj_t symbol1481_1658;
symbol1481_1658 = symbol2855___r4_numbers_6_5;
{
PUSH_TRACE(symbol1481_1658);
BUNSPEC;
{
bool_t aux1480_1659;
{
bool_t test1083_432;
test1083_432 = INTEGERP(x_33);
if(test1083_432){
{
long n_922;
{
obj_t aux_3778;
if(test1083_432){
aux_3778 = x_33;
}
 else {
bigloo_type_error_location_103___error(symbol2855___r4_numbers_6_5, string2836___r4_numbers_6_5, x_33, string2834___r4_numbers_6_5, BINT(((long)12401)));
exit( -1 );}
n_922 = (long)CINT(aux_3778);
}
aux1480_1659 = (n_922==((long)0));
}
}
 else {
bool_t test1084_433;
test1084_433 = REALP(x_33);
if(test1084_433){
{
double r_926;
{
obj_t aux_3787;
if(test1084_433){
aux_3787 = x_33;
}
 else {
bigloo_type_error_location_103___error(symbol2855___r4_numbers_6_5, string2833___r4_numbers_6_5, x_33, string2834___r4_numbers_6_5, BINT(((long)12440)));
exit( -1 );}
r_926 = REAL_TO_DOUBLE(aux_3787);
}
aux1480_1659 = (r_926==((double)0.0));
}
}
 else {
{
obj_t aux_3794;
aux_3794 = debug_error_location_199___error(string2856___r4_numbers_6_5, string2839___r4_numbers_6_5, x_33, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1480_1659 = CBOOL(aux_3794);
}
}
}
}
POP_TRACE();
return aux1480_1659;
}
}
}
}


/* _zero? */obj_t _zero__222___r4_numbers_6_5(obj_t env_1773, obj_t x_1774)
{
{
bool_t aux_3799;
aux_3799 = zero__228___r4_numbers_6_5(x_1774);
return BBOOL(aux_3799);
}
}


/* positive? */bool_t positive__57___r4_numbers_6_5(obj_t x_34)
{
{
obj_t symbol1483_1660;
symbol1483_1660 = symbol2857___r4_numbers_6_5;
{
PUSH_TRACE(symbol1483_1660);
BUNSPEC;
{
bool_t aux1482_1661;
{
bool_t test1085_434;
test1085_434 = INTEGERP(x_34);
if(test1085_434){
{
long n_933;
{
obj_t aux_3805;
if(test1085_434){
aux_3805 = x_34;
}
 else {
bigloo_type_error_location_103___error(symbol2857___r4_numbers_6_5, string2836___r4_numbers_6_5, x_34, string2834___r4_numbers_6_5, BINT(((long)12787)));
exit( -1 );}
n_933 = (long)CINT(aux_3805);
}
aux1482_1661 = (n_933>((long)0));
}
}
 else {
bool_t test1086_435;
test1086_435 = REALP(x_34);
if(test1086_435){
{
double r_937;
{
obj_t aux_3814;
if(test1086_435){
aux_3814 = x_34;
}
 else {
bigloo_type_error_location_103___error(symbol2857___r4_numbers_6_5, string2833___r4_numbers_6_5, x_34, string2834___r4_numbers_6_5, BINT(((long)12830)));
exit( -1 );}
r_937 = REAL_TO_DOUBLE(aux_3814);
}
aux1482_1661 = (r_937>((double)0.0));
}
}
 else {
{
obj_t aux_3821;
aux_3821 = debug_error_location_199___error(string2858___r4_numbers_6_5, string2839___r4_numbers_6_5, x_34, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1482_1661 = CBOOL(aux_3821);
}
}
}
}
POP_TRACE();
return aux1482_1661;
}
}
}
}


/* _positive? */obj_t _positive__177___r4_numbers_6_5(obj_t env_1775, obj_t x_1776)
{
{
bool_t aux_3826;
aux_3826 = positive__57___r4_numbers_6_5(x_1776);
return BBOOL(aux_3826);
}
}


/* negative? */bool_t negative__33___r4_numbers_6_5(obj_t x_35)
{
{
obj_t symbol1485_1662;
symbol1485_1662 = symbol2859___r4_numbers_6_5;
{
PUSH_TRACE(symbol1485_1662);
BUNSPEC;
{
bool_t aux1484_1663;
{
bool_t test1087_436;
test1087_436 = INTEGERP(x_35);
if(test1087_436){
{
long n_944;
{
obj_t aux_3832;
if(test1087_436){
aux_3832 = x_35;
}
 else {
bigloo_type_error_location_103___error(symbol2859___r4_numbers_6_5, string2836___r4_numbers_6_5, x_35, string2834___r4_numbers_6_5, BINT(((long)13185)));
exit( -1 );}
n_944 = (long)CINT(aux_3832);
}
aux1484_1663 = (n_944<((long)0));
}
}
 else {
bool_t test1088_437;
test1088_437 = REALP(x_35);
if(test1088_437){
{
double r_948;
{
obj_t aux_3841;
if(test1088_437){
aux_3841 = x_35;
}
 else {
bigloo_type_error_location_103___error(symbol2859___r4_numbers_6_5, string2833___r4_numbers_6_5, x_35, string2834___r4_numbers_6_5, BINT(((long)13228)));
exit( -1 );}
r_948 = REAL_TO_DOUBLE(aux_3841);
}
aux1484_1663 = (r_948<((double)0.0));
}
}
 else {
{
obj_t aux_3848;
aux_3848 = debug_error_location_199___error(string2860___r4_numbers_6_5, string2839___r4_numbers_6_5, x_35, string2840___r4_numbers_6_5, BINT(((long)7610)));
aux1484_1663 = CBOOL(aux_3848);
}
}
}
}
POP_TRACE();
return aux1484_1663;
}
}
}
}


/* _negative? */obj_t _negative__187___r4_numbers_6_5(obj_t env_1777, obj_t x_1778)
{
{
bool_t aux_3853;
aux_3853 = negative__33___r4_numbers_6_5(x_1778);
return BBOOL(aux_3853);
}
}


/* max */obj_t max___r4_numbers_6_5(obj_t x_36, obj_t y_37)
{
{
obj_t symbol1487_1664;
symbol1487_1664 = symbol2861___r4_numbers_6_5;
{
PUSH_TRACE(symbol1487_1664);
BUNSPEC;
{
obj_t aux1486_1665;
{
obj_t x_438;
obj_t y_439;
x_438 = x_36;
y_439 = y_37;
loop_440:
{
bool_t test1089_441;
test1089_441 = PAIRP(y_439);
if(test1089_441){
obj_t arg1090_442;
obj_t arg1091_443;
{
bool_t test1092_444;
{
obj_t arg1093_445;
{
obj_t pair_955;
if(test1089_441){
pair_955 = y_439;
}
 else {
bigloo_type_error_location_103___error(symbol2861___r4_numbers_6_5, string2842___r4_numbers_6_5, y_439, string2834___r4_numbers_6_5, BINT(((long)13618)));
exit( -1 );}
arg1093_445 = CAR(pair_955);
}
test1092_444 = _2__206___r4_numbers_6_5(x_438, arg1093_445);
}
if(test1092_444){
arg1090_442 = x_438;
}
 else {
obj_t pair_956;
if(test1089_441){
pair_956 = y_439;
}
 else {
bigloo_type_error_location_103___error(symbol2861___r4_numbers_6_5, string2842___r4_numbers_6_5, y_439, string2834___r4_numbers_6_5, BINT(((long)13641)));
exit( -1 );}
arg1090_442 = CAR(pair_956);
}
}
{
obj_t pair_957;
if(test1089_441){
pair_957 = y_439;
}
 else {
bigloo_type_error_location_103___error(symbol2861___r4_numbers_6_5, string2842___r4_numbers_6_5, y_439, string2834___r4_numbers_6_5, BINT(((long)13652)));
exit( -1 );}
arg1091_443 = CDR(pair_957);
}
{
obj_t y_3877;
obj_t x_3876;
x_3876 = arg1090_442;
y_3877 = arg1091_443;
y_439 = y_3877;
x_438 = x_3876;
goto loop_440;
}
}
 else {
aux1486_1665 = x_438;
}
}
}
POP_TRACE();
return aux1486_1665;
}
}
}
}


/* _max */obj_t _max___r4_numbers_6_5(obj_t env_1779, obj_t x_1780, obj_t y_1781)
{
return max___r4_numbers_6_5(x_1780, y_1781);
}


/* min */obj_t min___r4_numbers_6_5(obj_t x_38, obj_t y_39)
{
{
obj_t symbol1489_1666;
symbol1489_1666 = symbol2862___r4_numbers_6_5;
{
PUSH_TRACE(symbol1489_1666);
BUNSPEC;
{
obj_t aux1488_1667;
{
obj_t x_446;
obj_t y_447;
x_446 = x_38;
y_447 = y_39;
loop_448:
{
bool_t test1094_449;
test1094_449 = PAIRP(y_447);
if(test1094_449){
obj_t arg1095_450;
obj_t arg1096_451;
{
bool_t test1097_452;
{
obj_t arg1098_453;
{
obj_t pair_959;
if(test1094_449){
pair_959 = y_447;
}
 else {
bigloo_type_error_location_103___error(symbol2862___r4_numbers_6_5, string2842___r4_numbers_6_5, y_447, string2834___r4_numbers_6_5, BINT(((long)13984)));
exit( -1 );}
arg1098_453 = CAR(pair_959);
}
test1097_452 = _2__116___r4_numbers_6_5(x_446, arg1098_453);
}
if(test1097_452){
arg1095_450 = x_446;
}
 else {
obj_t pair_960;
if(test1094_449){
pair_960 = y_447;
}
 else {
bigloo_type_error_location_103___error(symbol2862___r4_numbers_6_5, string2842___r4_numbers_6_5, y_447, string2834___r4_numbers_6_5, BINT(((long)14007)));
exit( -1 );}
arg1095_450 = CAR(pair_960);
}
}
{
obj_t pair_961;
if(test1094_449){
pair_961 = y_447;
}
 else {
bigloo_type_error_location_103___error(symbol2862___r4_numbers_6_5, string2842___r4_numbers_6_5, y_447, string2834___r4_numbers_6_5, BINT(((long)14018)));
exit( -1 );}
arg1096_451 = CDR(pair_961);
}
{
obj_t y_3901;
obj_t x_3900;
x_3900 = arg1095_450;
y_3901 = arg1096_451;
y_447 = y_3901;
x_446 = x_3900;
goto loop_448;
}
}
 else {
aux1488_1667 = x_446;
}
}
}
POP_TRACE();
return aux1488_1667;
}
}
}
}


/* _min */obj_t _min___r4_numbers_6_5(obj_t env_1782, obj_t x_1783, obj_t y_1784)
{
return min___r4_numbers_6_5(x_1783, y_1784);
}


/* 2+ */obj_t _2__168___r4_numbers_6_5(obj_t x_40, obj_t y_41)
{
{
obj_t symbol1491_1668;
symbol1491_1668 = symbol2863___r4_numbers_6_5;
{
PUSH_TRACE(symbol1491_1668);
BUNSPEC;
{
obj_t aux1490_1669;
{
bool_t test1099_454;
test1099_454 = INTEGERP(x_40);
if(test1099_454){
{
bool_t test1100_455;
test1100_455 = INTEGERP(y_41);
if(test1100_455){
{
long z1_964;
long z2_965;
{
obj_t aux_3909;
if(test1099_454){
aux_3909 = x_40;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2836___r4_numbers_6_5, x_40, string2834___r4_numbers_6_5, BINT(((long)14335)));
exit( -1 );}
z1_964 = (long)CINT(aux_3909);
}
{
obj_t aux_3915;
if(test1100_455){
aux_3915 = y_41;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2836___r4_numbers_6_5, y_41, string2834___r4_numbers_6_5, BINT(((long)14335)));
exit( -1 );}
z2_965 = (long)CINT(aux_3915);
}
{
long aux_3921;
aux_3921 = (z1_964+z2_965);
aux1490_1669 = BINT(aux_3921);
}
}
}
 else {
bool_t test1101_456;
test1101_456 = REALP(y_41);
if(test1101_456){
{
double arg1102_457;
{
long aux_3926;
{
obj_t aux_3927;
if(test1099_454){
aux_3927 = x_40;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2836___r4_numbers_6_5, x_40, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3926 = (long)CINT(aux_3927);
}
arg1102_457 = (double)(aux_3926);
}
{
double r2_969;
{
obj_t aux_3934;
if(test1101_456){
aux_3934 = y_41;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2833___r4_numbers_6_5, y_41, string2834___r4_numbers_6_5, BINT(((long)14366)));
exit( -1 );}
r2_969 = REAL_TO_DOUBLE(aux_3934);
}
{
double aux_3940;
aux_3940 = (arg1102_457+r2_969);
aux1490_1669 = make_real(aux_3940);
}
}
}
}
 else {
aux1490_1669 = debug_error_location_199___error(string2864___r4_numbers_6_5, string2839___r4_numbers_6_5, y_41, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
bool_t test1103_458;
test1103_458 = REALP(x_40);
if(test1103_458){
{
bool_t test1104_459;
test1104_459 = REALP(y_41);
if(test1104_459){
{
double r1_975;
double r2_976;
{
obj_t aux_3949;
if(test1103_458){
aux_3949 = x_40;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2833___r4_numbers_6_5, x_40, string2834___r4_numbers_6_5, BINT(((long)14492)));
exit( -1 );}
r1_975 = REAL_TO_DOUBLE(aux_3949);
}
{
obj_t aux_3955;
if(test1104_459){
aux_3955 = y_41;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2833___r4_numbers_6_5, y_41, string2834___r4_numbers_6_5, BINT(((long)14496)));
exit( -1 );}
r2_976 = REAL_TO_DOUBLE(aux_3955);
}
{
double aux_3961;
aux_3961 = (r1_975+r2_976);
aux1490_1669 = make_real(aux_3961);
}
}
}
 else {
bool_t test1105_460;
test1105_460 = INTEGERP(y_41);
if(test1105_460){
{
double arg1106_461;
{
long aux_3966;
{
obj_t aux_3967;
if(test1105_460){
aux_3967 = y_41;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2836___r4_numbers_6_5, y_41, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_3966 = (long)CINT(aux_3967);
}
arg1106_461 = (double)(aux_3966);
}
{
double r1_979;
{
obj_t aux_3974;
if(test1103_458){
aux_3974 = x_40;
}
 else {
bigloo_type_error_location_103___error(symbol2863___r4_numbers_6_5, string2833___r4_numbers_6_5, x_40, string2834___r4_numbers_6_5, BINT(((long)14522)));
exit( -1 );}
r1_979 = REAL_TO_DOUBLE(aux_3974);
}
{
double aux_3980;
aux_3980 = (r1_979+arg1106_461);
aux1490_1669 = make_real(aux_3980);
}
}
}
}
 else {
aux1490_1669 = debug_error_location_199___error(string2864___r4_numbers_6_5, string2839___r4_numbers_6_5, y_41, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
aux1490_1669 = debug_error_location_199___error(string2864___r4_numbers_6_5, string2839___r4_numbers_6_5, x_40, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1490_1669;
}
}
}
}


/* _2+ */obj_t _2__242___r4_numbers_6_5(obj_t env_1785, obj_t x_1786, obj_t y_1787)
{
return _2__168___r4_numbers_6_5(x_1786, y_1787);
}


/* + */obj_t __2___r4_numbers_6_5(obj_t x_42)
{
{
obj_t symbol1493_1670;
symbol1493_1670 = symbol2865___r4_numbers_6_5;
{
PUSH_TRACE(symbol1493_1670);
BUNSPEC;
{
obj_t aux1492_1671;
{
obj_t sum_988;
obj_t x_989;
sum_988 = BINT(((long)0));
x_989 = x_42;
loop_987:
{
bool_t test1107_994;
test1107_994 = PAIRP(x_989);
if(test1107_994){
obj_t arg1108_995;
obj_t arg1109_996;
{
obj_t arg1110_997;
{
obj_t pair_999;
if(test1107_994){
pair_999 = x_989;
}
 else {
bigloo_type_error_location_103___error(symbol2865___r4_numbers_6_5, string2842___r4_numbers_6_5, x_989, string2834___r4_numbers_6_5, BINT(((long)14960)));
exit( -1 );}
arg1110_997 = CAR(pair_999);
}
arg1108_995 = _2__168___r4_numbers_6_5(sum_988, arg1110_997);
}
{
obj_t pair_1000;
if(test1107_994){
pair_1000 = x_989;
}
 else {
bigloo_type_error_location_103___error(symbol2865___r4_numbers_6_5, string2842___r4_numbers_6_5, x_989, string2834___r4_numbers_6_5, BINT(((long)14971)));
exit( -1 );}
arg1109_996 = CDR(pair_1000);
}
{
obj_t x_4004;
obj_t sum_4003;
sum_4003 = arg1108_995;
x_4004 = arg1109_996;
x_989 = x_4004;
sum_988 = sum_4003;
goto loop_987;
}
}
 else {
aux1492_1671 = sum_988;
}
}
}
POP_TRACE();
return aux1492_1671;
}
}
}
}


/* _+ */obj_t ___219___r4_numbers_6_5(obj_t env_1788, obj_t x_1789)
{
return __2___r4_numbers_6_5(x_1789);
}


/* 2* */obj_t _2__198___r4_numbers_6_5(obj_t x_43, obj_t y_44)
{
{
obj_t symbol1495_1672;
symbol1495_1672 = symbol2866___r4_numbers_6_5;
{
PUSH_TRACE(symbol1495_1672);
BUNSPEC;
{
obj_t aux1494_1673;
{
bool_t test1111_469;
test1111_469 = INTEGERP(x_43);
if(test1111_469){
{
bool_t test1112_470;
test1112_470 = INTEGERP(y_44);
if(test1112_470){
{
long z1_1019;
long z2_1020;
{
obj_t aux_4013;
if(test1111_469){
aux_4013 = x_43;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2836___r4_numbers_6_5, x_43, string2834___r4_numbers_6_5, BINT(((long)15291)));
exit( -1 );}
z1_1019 = (long)CINT(aux_4013);
}
{
obj_t aux_4019;
if(test1112_470){
aux_4019 = y_44;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2836___r4_numbers_6_5, y_44, string2834___r4_numbers_6_5, BINT(((long)15295)));
exit( -1 );}
z2_1020 = (long)CINT(aux_4019);
}
{
long aux_4025;
aux_4025 = (z1_1019*z2_1020);
aux1494_1673 = BINT(aux_4025);
}
}
}
 else {
bool_t test1113_471;
test1113_471 = REALP(y_44);
if(test1113_471){
{
double arg1114_472;
{
long aux_4030;
{
obj_t aux_4031;
if(test1111_469){
aux_4031 = x_43;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2836___r4_numbers_6_5, x_43, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4030 = (long)CINT(aux_4031);
}
arg1114_472 = (double)(aux_4030);
}
{
double r2_1024;
{
obj_t aux_4038;
if(test1113_471){
aux_4038 = y_44;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2833___r4_numbers_6_5, y_44, string2834___r4_numbers_6_5, BINT(((long)15321)));
exit( -1 );}
r2_1024 = REAL_TO_DOUBLE(aux_4038);
}
{
double aux_4044;
aux_4044 = (arg1114_472*r2_1024);
aux1494_1673 = make_real(aux_4044);
}
}
}
}
 else {
aux1494_1673 = debug_error_location_199___error(string2867___r4_numbers_6_5, string2839___r4_numbers_6_5, y_44, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
bool_t test1115_473;
test1115_473 = REALP(x_43);
if(test1115_473){
{
bool_t test1116_474;
test1116_474 = REALP(y_44);
if(test1116_474){
{
double r1_1030;
double r2_1031;
{
obj_t aux_4053;
if(test1115_473){
aux_4053 = x_43;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2833___r4_numbers_6_5, x_43, string2834___r4_numbers_6_5, BINT(((long)15447)));
exit( -1 );}
r1_1030 = REAL_TO_DOUBLE(aux_4053);
}
{
obj_t aux_4059;
if(test1116_474){
aux_4059 = y_44;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2833___r4_numbers_6_5, y_44, string2834___r4_numbers_6_5, BINT(((long)15451)));
exit( -1 );}
r2_1031 = REAL_TO_DOUBLE(aux_4059);
}
{
double aux_4065;
aux_4065 = (r1_1030*r2_1031);
aux1494_1673 = make_real(aux_4065);
}
}
}
 else {
bool_t test1117_475;
test1117_475 = INTEGERP(y_44);
if(test1117_475){
{
double arg1118_476;
{
long aux_4070;
{
obj_t aux_4071;
if(test1117_475){
aux_4071 = y_44;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2836___r4_numbers_6_5, y_44, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4070 = (long)CINT(aux_4071);
}
arg1118_476 = (double)(aux_4070);
}
{
double r1_1034;
{
obj_t aux_4078;
if(test1115_473){
aux_4078 = x_43;
}
 else {
bigloo_type_error_location_103___error(symbol2866___r4_numbers_6_5, string2833___r4_numbers_6_5, x_43, string2834___r4_numbers_6_5, BINT(((long)15477)));
exit( -1 );}
r1_1034 = REAL_TO_DOUBLE(aux_4078);
}
{
double aux_4084;
aux_4084 = (r1_1034*arg1118_476);
aux1494_1673 = make_real(aux_4084);
}
}
}
}
 else {
aux1494_1673 = debug_error_location_199___error(string2867___r4_numbers_6_5, string2839___r4_numbers_6_5, y_44, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
aux1494_1673 = debug_error_location_199___error(string2867___r4_numbers_6_5, string2839___r4_numbers_6_5, x_43, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1494_1673;
}
}
}
}


/* _2* */obj_t _2__101___r4_numbers_6_5(obj_t env_1790, obj_t x_1791, obj_t y_1792)
{
return _2__198___r4_numbers_6_5(x_1791, y_1792);
}


/* * */obj_t __15___r4_numbers_6_5(obj_t x_45)
{
{
obj_t symbol1497_1674;
symbol1497_1674 = symbol2868___r4_numbers_6_5;
{
PUSH_TRACE(symbol1497_1674);
BUNSPEC;
{
obj_t aux1496_1675;
{
obj_t product_1043;
obj_t x_1044;
product_1043 = BINT(((long)1));
x_1044 = x_45;
loop_1042:
{
bool_t test1119_1049;
test1119_1049 = PAIRP(x_1044);
if(test1119_1049){
obj_t arg1120_1050;
obj_t arg1121_1051;
{
obj_t arg1122_1052;
{
obj_t pair_1054;
if(test1119_1049){
pair_1054 = x_1044;
}
 else {
bigloo_type_error_location_103___error(symbol2868___r4_numbers_6_5, string2842___r4_numbers_6_5, x_1044, string2834___r4_numbers_6_5, BINT(((long)15923)));
exit( -1 );}
arg1122_1052 = CAR(pair_1054);
}
arg1120_1050 = _2__198___r4_numbers_6_5(product_1043, arg1122_1052);
}
{
obj_t pair_1055;
if(test1119_1049){
pair_1055 = x_1044;
}
 else {
bigloo_type_error_location_103___error(symbol2868___r4_numbers_6_5, string2842___r4_numbers_6_5, x_1044, string2834___r4_numbers_6_5, BINT(((long)15932)));
exit( -1 );}
arg1121_1051 = CDR(pair_1055);
}
{
obj_t x_4108;
obj_t product_4107;
product_4107 = arg1120_1050;
x_4108 = arg1121_1051;
x_1044 = x_4108;
product_1043 = product_4107;
goto loop_1042;
}
}
 else {
aux1496_1675 = product_1043;
}
}
}
POP_TRACE();
return aux1496_1675;
}
}
}
}


/* _* */obj_t ___10___r4_numbers_6_5(obj_t env_1793, obj_t x_1794)
{
return __15___r4_numbers_6_5(x_1794);
}


/* 2- */obj_t _2__79___r4_numbers_6_5(obj_t x_46, obj_t y_47)
{
{
obj_t symbol1499_1676;
symbol1499_1676 = symbol2869___r4_numbers_6_5;
{
PUSH_TRACE(symbol1499_1676);
BUNSPEC;
{
obj_t aux1498_1677;
{
bool_t test1123_484;
test1123_484 = INTEGERP(x_46);
if(test1123_484){
{
bool_t test1124_485;
test1124_485 = INTEGERP(y_47);
if(test1124_485){
{
long z1_1074;
long z2_1075;
{
obj_t aux_4117;
if(test1123_484){
aux_4117 = x_46;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2836___r4_numbers_6_5, x_46, string2834___r4_numbers_6_5, BINT(((long)16255)));
exit( -1 );}
z1_1074 = (long)CINT(aux_4117);
}
{
obj_t aux_4123;
if(test1124_485){
aux_4123 = y_47;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2836___r4_numbers_6_5, y_47, string2834___r4_numbers_6_5, BINT(((long)16255)));
exit( -1 );}
z2_1075 = (long)CINT(aux_4123);
}
{
long aux_4129;
aux_4129 = (z1_1074-z2_1075);
aux1498_1677 = BINT(aux_4129);
}
}
}
 else {
bool_t test1125_486;
test1125_486 = REALP(y_47);
if(test1125_486){
{
double arg1126_487;
{
long aux_4134;
{
obj_t aux_4135;
if(test1123_484){
aux_4135 = x_46;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2836___r4_numbers_6_5, x_46, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4134 = (long)CINT(aux_4135);
}
arg1126_487 = (double)(aux_4134);
}
{
double r2_1079;
{
obj_t aux_4142;
if(test1125_486){
aux_4142 = y_47;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2833___r4_numbers_6_5, y_47, string2834___r4_numbers_6_5, BINT(((long)16286)));
exit( -1 );}
r2_1079 = REAL_TO_DOUBLE(aux_4142);
}
{
double aux_4148;
aux_4148 = (arg1126_487-r2_1079);
aux1498_1677 = make_real(aux_4148);
}
}
}
}
 else {
aux1498_1677 = debug_error_location_199___error(string2870___r4_numbers_6_5, string2839___r4_numbers_6_5, y_47, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
bool_t test1127_488;
test1127_488 = REALP(x_46);
if(test1127_488){
{
bool_t test1128_489;
test1128_489 = REALP(y_47);
if(test1128_489){
{
double r1_1085;
double r2_1086;
{
obj_t aux_4157;
if(test1127_488){
aux_4157 = x_46;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2833___r4_numbers_6_5, x_46, string2834___r4_numbers_6_5, BINT(((long)16412)));
exit( -1 );}
r1_1085 = REAL_TO_DOUBLE(aux_4157);
}
{
obj_t aux_4163;
if(test1128_489){
aux_4163 = y_47;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2833___r4_numbers_6_5, y_47, string2834___r4_numbers_6_5, BINT(((long)16416)));
exit( -1 );}
r2_1086 = REAL_TO_DOUBLE(aux_4163);
}
{
double aux_4169;
aux_4169 = (r1_1085-r2_1086);
aux1498_1677 = make_real(aux_4169);
}
}
}
 else {
bool_t test1129_490;
test1129_490 = INTEGERP(y_47);
if(test1129_490){
{
double arg1130_491;
{
long aux_4174;
{
obj_t aux_4175;
if(test1129_490){
aux_4175 = y_47;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2836___r4_numbers_6_5, y_47, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4174 = (long)CINT(aux_4175);
}
arg1130_491 = (double)(aux_4174);
}
{
double r1_1089;
{
obj_t aux_4182;
if(test1127_488){
aux_4182 = x_46;
}
 else {
bigloo_type_error_location_103___error(symbol2869___r4_numbers_6_5, string2833___r4_numbers_6_5, x_46, string2834___r4_numbers_6_5, BINT(((long)16442)));
exit( -1 );}
r1_1089 = REAL_TO_DOUBLE(aux_4182);
}
{
double aux_4188;
aux_4188 = (r1_1089-arg1130_491);
aux1498_1677 = make_real(aux_4188);
}
}
}
}
 else {
aux1498_1677 = debug_error_location_199___error(string2870___r4_numbers_6_5, string2839___r4_numbers_6_5, y_47, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
aux1498_1677 = debug_error_location_199___error(string2870___r4_numbers_6_5, string2839___r4_numbers_6_5, x_46, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1498_1677;
}
}
}
}


/* _2- */obj_t _2__171___r4_numbers_6_5(obj_t env_1795, obj_t x_1796, obj_t y_1797)
{
return _2__79___r4_numbers_6_5(x_1796, y_1797);
}


/* - */obj_t __186___r4_numbers_6_5(obj_t x_48, obj_t y_49)
{
{
obj_t symbol1501_1678;
symbol1501_1678 = symbol2871___r4_numbers_6_5;
{
PUSH_TRACE(symbol1501_1678);
BUNSPEC;
{
obj_t aux1500_1679;
{
bool_t test1131_492;
test1131_492 = PAIRP(y_49);
if(test1131_492){
obj_t arg1132_496;
obj_t arg1133_497;
{
obj_t arg1134_498;
{
obj_t pair_1098;
if(test1131_492){
pair_1098 = y_49;
}
 else {
bigloo_type_error_location_103___error(symbol2871___r4_numbers_6_5, string2842___r4_numbers_6_5, y_49, string2834___r4_numbers_6_5, BINT(((long)16852)));
exit( -1 );}
arg1134_498 = CAR(pair_1098);
}
arg1132_496 = _2__79___r4_numbers_6_5(x_48, arg1134_498);
}
{
obj_t pair_1099;
if(test1131_492){
pair_1099 = y_49;
}
 else {
bigloo_type_error_location_103___error(symbol2871___r4_numbers_6_5, string2842___r4_numbers_6_5, y_49, string2834___r4_numbers_6_5, BINT(((long)16873)));
exit( -1 );}
arg1133_497 = CDR(pair_1099);
}
{
obj_t result_1101;
obj_t args_1102;
result_1101 = arg1132_496;
args_1102 = arg1133_497;
loop_1100:
{
bool_t test1135_1107;
test1135_1107 = PAIRP(args_1102);
if(test1135_1107){
obj_t arg1136_1108;
obj_t arg1137_1109;
{
obj_t arg1139_1110;
{
obj_t pair_1112;
if(test1135_1107){
pair_1112 = args_1102;
}
 else {
bigloo_type_error_location_103___error(symbol2871___r4_numbers_6_5, string2842___r4_numbers_6_5, args_1102, string2834___r4_numbers_6_5, BINT(((long)16929)));
exit( -1 );}
arg1139_1110 = CAR(pair_1112);
}
arg1136_1108 = _2__79___r4_numbers_6_5(result_1101, arg1139_1110);
}
{
obj_t pair_1113;
if(test1135_1107){
pair_1113 = args_1102;
}
 else {
bigloo_type_error_location_103___error(symbol2871___r4_numbers_6_5, string2842___r4_numbers_6_5, args_1102, string2834___r4_numbers_6_5, BINT(((long)16941)));
exit( -1 );}
arg1137_1109 = CDR(pair_1113);
}
{
obj_t args_4225;
obj_t result_4224;
result_4224 = arg1136_1108;
args_4225 = arg1137_1109;
args_1102 = args_4225;
result_1101 = result_4224;
goto loop_1100;
}
}
 else {
aux1500_1679 = result_1101;
}
}
}
}
 else {
aux1500_1679 = _2__79___r4_numbers_6_5(BINT(((long)0)), x_48);
}
}
POP_TRACE();
return aux1500_1679;
}
}
}
}


/* _- */obj_t ___163___r4_numbers_6_5(obj_t env_1798, obj_t x_1799, obj_t y_1800)
{
return __186___r4_numbers_6_5(x_1799, y_1800);
}


/* 2/ */obj_t _2__156___r4_numbers_6_5(obj_t x_50, obj_t y_51)
{
{
obj_t symbol1503_1680;
symbol1503_1680 = symbol2872___r4_numbers_6_5;
{
PUSH_TRACE(symbol1503_1680);
BUNSPEC;
{
obj_t aux1502_1681;
{
bool_t test1140_503;
test1140_503 = INTEGERP(x_50);
if(test1140_503){
{
bool_t test1141_504;
test1141_504 = INTEGERP(y_51);
if(test1141_504){
{
bool_t test1142_505;
{
long arg1145_508;
{
long n1_1132;
long n2_1133;
{
obj_t aux_4235;
if(test1140_503){
aux_4235 = x_50;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, x_50, string2834___r4_numbers_6_5, BINT(((long)17292)));
exit( -1 );}
n1_1132 = (long)CINT(aux_4235);
}
{
obj_t aux_4241;
if(test1141_504){
aux_4241 = y_51;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, y_51, string2834___r4_numbers_6_5, BINT(((long)17302)));
exit( -1 );}
n2_1133 = (long)CINT(aux_4241);
}
arg1145_508 = (n1_1132%n2_1133);
}
test1142_505 = (arg1145_508==((long)0));
}
if(test1142_505){
long z1_1136;
long z2_1137;
{
obj_t aux_4250;
if(test1140_503){
aux_4250 = x_50;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, x_50, string2834___r4_numbers_6_5, BINT(((long)17319)));
exit( -1 );}
z1_1136 = (long)CINT(aux_4250);
}
{
obj_t aux_4256;
if(test1141_504){
aux_4256 = y_51;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, y_51, string2834___r4_numbers_6_5, BINT(((long)17323)));
exit( -1 );}
z2_1137 = (long)CINT(aux_4256);
}
{
long aux_4262;
aux_4262 = (z1_1136/z2_1137);
aux1502_1681 = BINT(aux_4262);
}
}
 else {
double arg1143_506;
double arg1144_507;
{
long aux_4265;
{
obj_t aux_4266;
if(test1140_503){
aux_4266 = x_50;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, x_50, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4265 = (long)CINT(aux_4266);
}
arg1143_506 = (double)(aux_4265);
}
{
long aux_4273;
{
obj_t aux_4274;
if(test1141_504){
aux_4274 = y_51;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, y_51, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4273 = (long)CINT(aux_4274);
}
arg1144_507 = (double)(aux_4273);
}
{
double aux_4281;
aux_4281 = (arg1143_506/arg1144_507);
aux1502_1681 = make_real(aux_4281);
}
}
}
}
 else {
bool_t test1147_510;
test1147_510 = REALP(y_51);
if(test1147_510){
{
double arg1148_511;
{
long aux_4286;
{
obj_t aux_4287;
if(test1140_503){
aux_4287 = x_50;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, x_50, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4286 = (long)CINT(aux_4287);
}
arg1148_511 = (double)(aux_4286);
}
{
double r2_1145;
{
obj_t aux_4294;
if(test1147_510){
aux_4294 = y_51;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2833___r4_numbers_6_5, y_51, string2834___r4_numbers_6_5, BINT(((long)17402)));
exit( -1 );}
r2_1145 = REAL_TO_DOUBLE(aux_4294);
}
{
double aux_4300;
aux_4300 = (arg1148_511/r2_1145);
aux1502_1681 = make_real(aux_4300);
}
}
}
}
 else {
aux1502_1681 = debug_error_location_199___error(string2873___r4_numbers_6_5, string2839___r4_numbers_6_5, y_51, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
bool_t test1149_512;
test1149_512 = REALP(x_50);
if(test1149_512){
{
bool_t test1150_513;
test1150_513 = REALP(y_51);
if(test1150_513){
{
double r1_1151;
double r2_1152;
{
obj_t aux_4309;
if(test1149_512){
aux_4309 = x_50;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2833___r4_numbers_6_5, x_50, string2834___r4_numbers_6_5, BINT(((long)17528)));
exit( -1 );}
r1_1151 = REAL_TO_DOUBLE(aux_4309);
}
{
obj_t aux_4315;
if(test1150_513){
aux_4315 = y_51;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2833___r4_numbers_6_5, y_51, string2834___r4_numbers_6_5, BINT(((long)17532)));
exit( -1 );}
r2_1152 = REAL_TO_DOUBLE(aux_4315);
}
{
double aux_4321;
aux_4321 = (r1_1151/r2_1152);
aux1502_1681 = make_real(aux_4321);
}
}
}
 else {
bool_t test1151_514;
test1151_514 = INTEGERP(y_51);
if(test1151_514){
{
double arg1152_515;
{
long aux_4326;
{
obj_t aux_4327;
if(test1151_514){
aux_4327 = y_51;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2836___r4_numbers_6_5, y_51, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4326 = (long)CINT(aux_4327);
}
arg1152_515 = (double)(aux_4326);
}
{
double r1_1155;
{
obj_t aux_4334;
if(test1149_512){
aux_4334 = x_50;
}
 else {
bigloo_type_error_location_103___error(symbol2872___r4_numbers_6_5, string2833___r4_numbers_6_5, x_50, string2834___r4_numbers_6_5, BINT(((long)17558)));
exit( -1 );}
r1_1155 = REAL_TO_DOUBLE(aux_4334);
}
{
double aux_4340;
aux_4340 = (r1_1155/arg1152_515);
aux1502_1681 = make_real(aux_4340);
}
}
}
}
 else {
aux1502_1681 = debug_error_location_199___error(string2873___r4_numbers_6_5, string2839___r4_numbers_6_5, y_51, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
aux1502_1681 = debug_error_location_199___error(string2873___r4_numbers_6_5, string2839___r4_numbers_6_5, x_50, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1502_1681;
}
}
}
}


/* _2/ */obj_t _2__11___r4_numbers_6_5(obj_t env_1801, obj_t x_1802, obj_t y_1803)
{
return _2__156___r4_numbers_6_5(x_1802, y_1803);
}


/* / */obj_t __28___r4_numbers_6_5(obj_t x_52, obj_t y_53)
{
{
obj_t symbol1505_1682;
symbol1505_1682 = symbol2874___r4_numbers_6_5;
{
PUSH_TRACE(symbol1505_1682);
BUNSPEC;
{
obj_t aux1504_1683;
{
bool_t test1153_516;
test1153_516 = PAIRP(y_53);
if(test1153_516){
obj_t arg1154_520;
obj_t arg1155_521;
{
obj_t arg1156_522;
{
obj_t pair_1164;
if(test1153_516){
pair_1164 = y_53;
}
 else {
bigloo_type_error_location_103___error(symbol2874___r4_numbers_6_5, string2842___r4_numbers_6_5, y_53, string2834___r4_numbers_6_5, BINT(((long)17968)));
exit( -1 );}
arg1156_522 = CAR(pair_1164);
}
arg1154_520 = _2__156___r4_numbers_6_5(x_52, arg1156_522);
}
{
obj_t pair_1165;
if(test1153_516){
pair_1165 = y_53;
}
 else {
bigloo_type_error_location_103___error(symbol2874___r4_numbers_6_5, string2842___r4_numbers_6_5, y_53, string2834___r4_numbers_6_5, BINT(((long)17986)));
exit( -1 );}
arg1155_521 = CDR(pair_1165);
}
{
obj_t result_1167;
obj_t z_1168;
result_1167 = arg1154_520;
z_1168 = arg1155_521;
loop_1166:
{
bool_t test1157_1173;
test1157_1173 = PAIRP(z_1168);
if(test1157_1173){
obj_t arg1158_1174;
obj_t arg1160_1175;
{
obj_t arg1161_1176;
{
obj_t pair_1178;
if(test1157_1173){
pair_1178 = z_1168;
}
 else {
bigloo_type_error_location_103___error(symbol2874___r4_numbers_6_5, string2842___r4_numbers_6_5, z_1168, string2834___r4_numbers_6_5, BINT(((long)18036)));
exit( -1 );}
arg1161_1176 = CAR(pair_1178);
}
arg1158_1174 = _2__156___r4_numbers_6_5(result_1167, arg1161_1176);
}
{
obj_t pair_1179;
if(test1157_1173){
pair_1179 = z_1168;
}
 else {
bigloo_type_error_location_103___error(symbol2874___r4_numbers_6_5, string2842___r4_numbers_6_5, z_1168, string2834___r4_numbers_6_5, BINT(((long)18054)));
exit( -1 );}
arg1160_1175 = CDR(pair_1179);
}
{
obj_t z_4377;
obj_t result_4376;
result_4376 = arg1158_1174;
z_4377 = arg1160_1175;
z_1168 = z_4377;
result_1167 = result_4376;
goto loop_1166;
}
}
 else {
aux1504_1683 = result_1167;
}
}
}
}
 else {
aux1504_1683 = _2__156___r4_numbers_6_5(BINT(((long)1)), x_52);
}
}
POP_TRACE();
return aux1504_1683;
}
}
}
}


/* _/ */obj_t ___222___r4_numbers_6_5(obj_t env_1804, obj_t x_1805, obj_t y_1806)
{
return __28___r4_numbers_6_5(x_1805, y_1806);
}


/* abs */obj_t abs___r4_numbers_6_5(obj_t x_54)
{
{
obj_t symbol1507_1684;
symbol1507_1684 = symbol2875___r4_numbers_6_5;
{
PUSH_TRACE(symbol1507_1684);
BUNSPEC;
{
obj_t aux1506_1685;
{
bool_t test1162_527;
test1162_527 = INTEGERP(x_54);
if(test1162_527){
{
long res1427_1202;
{
long n_1197;
{
obj_t aux_4385;
if(test1162_527){
aux_4385 = x_54;
}
 else {
bigloo_type_error_location_103___error(symbol2875___r4_numbers_6_5, string2836___r4_numbers_6_5, x_54, string2834___r4_numbers_6_5, BINT(((long)18361)));
exit( -1 );}
n_1197 = (long)CINT(aux_4385);
}
if((n_1197<((long)0))){
res1427_1202 = NEG(n_1197);
}
 else {
res1427_1202 = n_1197;
}
}
aux1506_1685 = BINT(res1427_1202);
}
}
 else {
bool_t test1163_528;
test1163_528 = REALP(x_54);
if(test1163_528){
{
double res1428_1209;
{
double r_1204;
{
obj_t aux_4397;
if(test1163_528){
aux_4397 = x_54;
}
 else {
bigloo_type_error_location_103___error(symbol2875___r4_numbers_6_5, string2833___r4_numbers_6_5, x_54, string2834___r4_numbers_6_5, BINT(((long)18398)));
exit( -1 );}
r_1204 = REAL_TO_DOUBLE(aux_4397);
}
if((r_1204<((double)0.0))){
res1428_1209 = NEG(r_1204);
}
 else {
res1428_1209 = r_1204;
}
}
aux1506_1685 = make_real(res1428_1209);
}
}
 else {
aux1506_1685 = debug_error_location_199___error(string2876___r4_numbers_6_5, string2839___r4_numbers_6_5, x_54, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
POP_TRACE();
return aux1506_1685;
}
}
}
}


/* _abs */obj_t _abs___r4_numbers_6_5(obj_t env_1807, obj_t x_1808)
{
return abs___r4_numbers_6_5(x_1808);
}


/* floor */obj_t floor___r4_numbers_6_5(obj_t x_55)
{
{
obj_t symbol1509_1686;
symbol1509_1686 = symbol2877___r4_numbers_6_5;
{
PUSH_TRACE(symbol1509_1686);
BUNSPEC;
{
obj_t aux1508_1687;
if(INTEGERP(x_55)){
aux1508_1687 = x_55;
}
 else {
bool_t test1165_530;
test1165_530 = REALP(x_55);
if(test1165_530){
{
double r_1215;
{
obj_t aux_4416;
if(test1165_530){
aux_4416 = x_55;
}
 else {
bigloo_type_error_location_103___error(symbol2877___r4_numbers_6_5, string2833___r4_numbers_6_5, x_55, string2834___r4_numbers_6_5, BINT(((long)18767)));
exit( -1 );}
r_1215 = REAL_TO_DOUBLE(aux_4416);
}
{
double aux_4422;
aux_4422 = floor(r_1215);
aux1508_1687 = make_real(aux_4422);
}
}
}
 else {
aux1508_1687 = debug_error_location_199___error(string2878___r4_numbers_6_5, string2839___r4_numbers_6_5, x_55, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1508_1687;
}
}
}
}


/* _floor */obj_t _floor___r4_numbers_6_5(obj_t env_1809, obj_t x_1810)
{
return floor___r4_numbers_6_5(x_1810);
}


/* ceiling */obj_t ceiling___r4_numbers_6_5(obj_t x_56)
{
{
obj_t symbol1511_1688;
symbol1511_1688 = symbol2879___r4_numbers_6_5;
{
PUSH_TRACE(symbol1511_1688);
BUNSPEC;
{
obj_t aux1510_1689;
if(INTEGERP(x_56)){
aux1510_1689 = x_56;
}
 else {
bool_t test1167_532;
test1167_532 = REALP(x_56);
if(test1167_532){
{
double r_1221;
{
obj_t aux_4434;
if(test1167_532){
aux_4434 = x_56;
}
 else {
bigloo_type_error_location_103___error(symbol2879___r4_numbers_6_5, string2833___r4_numbers_6_5, x_56, string2834___r4_numbers_6_5, BINT(((long)19142)));
exit( -1 );}
r_1221 = REAL_TO_DOUBLE(aux_4434);
}
{
double aux_4440;
aux_4440 = ceil(r_1221);
aux1510_1689 = make_real(aux_4440);
}
}
}
 else {
aux1510_1689 = debug_error_location_199___error(string2880___r4_numbers_6_5, string2839___r4_numbers_6_5, x_56, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1510_1689;
}
}
}
}


/* _ceiling */obj_t _ceiling___r4_numbers_6_5(obj_t env_1811, obj_t x_1812)
{
return ceiling___r4_numbers_6_5(x_1812);
}


/* truncate */obj_t truncate___r4_numbers_6_5(obj_t x_57)
{
{
obj_t symbol1513_1690;
symbol1513_1690 = symbol2881___r4_numbers_6_5;
{
PUSH_TRACE(symbol1513_1690);
BUNSPEC;
{
obj_t aux1512_1691;
if(INTEGERP(x_57)){
aux1512_1691 = x_57;
}
 else {
bool_t test1169_534;
test1169_534 = REALP(x_57);
if(test1169_534){
{
double res1429_1234;
{
double r_1227;
{
obj_t aux_4452;
if(test1169_534){
aux_4452 = x_57;
}
 else {
bigloo_type_error_location_103___error(symbol2881___r4_numbers_6_5, string2833___r4_numbers_6_5, x_57, string2834___r4_numbers_6_5, BINT(((long)19522)));
exit( -1 );}
r_1227 = REAL_TO_DOUBLE(aux_4452);
}
if((r_1227<((double)0.0))){
res1429_1234 = ceil(r_1227);
}
 else {
res1429_1234 = floor(r_1227);
}
}
aux1512_1691 = make_real(res1429_1234);
}
}
 else {
aux1512_1691 = debug_error_location_199___error(string2882___r4_numbers_6_5, string2839___r4_numbers_6_5, x_57, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1512_1691;
}
}
}
}


/* _truncate */obj_t _truncate___r4_numbers_6_5(obj_t env_1813, obj_t x_1814)
{
return truncate___r4_numbers_6_5(x_1814);
}


/* round */obj_t round___r4_numbers_6_5(obj_t x_58)
{
{
obj_t symbol1515_1692;
symbol1515_1692 = symbol2883___r4_numbers_6_5;
{
PUSH_TRACE(symbol1515_1692);
BUNSPEC;
{
obj_t aux1514_1693;
if(INTEGERP(x_58)){
aux1514_1693 = x_58;
}
 else {
bool_t test1171_536;
test1171_536 = REALP(x_58);
if(test1171_536){
{
double res1430_1245;
{
double r_1240;
{
obj_t aux_4472;
if(test1171_536){
aux_4472 = x_58;
}
 else {
bigloo_type_error_location_103___error(symbol2883___r4_numbers_6_5, string2833___r4_numbers_6_5, x_58, string2834___r4_numbers_6_5, BINT(((long)19901)));
exit( -1 );}
r_1240 = REAL_TO_DOUBLE(aux_4472);
}
{
double aux_4478;
aux_4478 = (r_1240+((double)0.5));
res1430_1245 = floor(aux_4478);
}
}
aux1514_1693 = make_real(res1430_1245);
}
}
 else {
aux1514_1693 = debug_error_location_199___error(string2884___r4_numbers_6_5, string2839___r4_numbers_6_5, x_58, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
POP_TRACE();
return aux1514_1693;
}
}
}
}


/* _round */obj_t _round___r4_numbers_6_5(obj_t env_1815, obj_t x_1816)
{
return round___r4_numbers_6_5(x_1816);
}


/* exp */double exp___r4_numbers_6_5(obj_t x_59)
{
{
obj_t symbol1517_1694;
symbol1517_1694 = symbol2885___r4_numbers_6_5;
{
PUSH_TRACE(symbol1517_1694);
BUNSPEC;
{
double aux1516_1695;
{
bool_t test1172_537;
test1172_537 = INTEGERP(x_59);
if(test1172_537){
{
double arg1173_538;
{
long aux_4489;
{
obj_t aux_4490;
if(test1172_537){
aux_4490 = x_59;
}
 else {
bigloo_type_error_location_103___error(symbol2885___r4_numbers_6_5, string2836___r4_numbers_6_5, x_59, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4489 = (long)CINT(aux_4490);
}
arg1173_538 = (double)(aux_4489);
}
aux1516_1695 = exp(arg1173_538);
}
}
 else {
bool_t test1174_539;
test1174_539 = REALP(x_59);
if(test1174_539){
{
double x_1253;
{
obj_t aux_4500;
if(test1174_539){
aux_4500 = x_59;
}
 else {
bigloo_type_error_location_103___error(symbol2885___r4_numbers_6_5, string2833___r4_numbers_6_5, x_59, string2834___r4_numbers_6_5, BINT(((long)20297)));
exit( -1 );}
x_1253 = REAL_TO_DOUBLE(aux_4500);
}
aux1516_1695 = exp(x_1253);
}
}
 else {
{
obj_t aux_4507;
{
obj_t aux2385_2593;
aux2385_2593 = debug_error_location_199___error(string2886___r4_numbers_6_5, string2839___r4_numbers_6_5, x_59, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2385_2593)){
aux_4507 = aux2385_2593;
}
 else {
bigloo_type_error_location_103___error(symbol2885___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2385_2593, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1516_1695 = REAL_TO_DOUBLE(aux_4507);
}
}
}
}
POP_TRACE();
return aux1516_1695;
}
}
}
}


/* _exp */obj_t _exp___r4_numbers_6_5(obj_t env_1817, obj_t x_1818)
{
{
double aux_4517;
aux_4517 = exp___r4_numbers_6_5(x_1818);
return make_real(aux_4517);
}
}


/* log */double log___r4_numbers_6_5(obj_t x_60)
{
{
obj_t symbol1519_1696;
symbol1519_1696 = symbol2887___r4_numbers_6_5;
{
PUSH_TRACE(symbol1519_1696);
BUNSPEC;
{
double aux1518_1697;
{
bool_t test1175_540;
test1175_540 = INTEGERP(x_60);
if(test1175_540){
{
double arg1176_541;
{
long aux_4523;
{
obj_t aux_4524;
if(test1175_540){
aux_4524 = x_60;
}
 else {
bigloo_type_error_location_103___error(symbol2887___r4_numbers_6_5, string2836___r4_numbers_6_5, x_60, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4523 = (long)CINT(aux_4524);
}
arg1176_541 = (double)(aux_4523);
}
aux1518_1697 = log(arg1176_541);
}
}
 else {
bool_t test1177_542;
test1177_542 = REALP(x_60);
if(test1177_542){
{
double x_1261;
{
obj_t aux_4534;
if(test1177_542){
aux_4534 = x_60;
}
 else {
bigloo_type_error_location_103___error(symbol2887___r4_numbers_6_5, string2833___r4_numbers_6_5, x_60, string2834___r4_numbers_6_5, BINT(((long)20689)));
exit( -1 );}
x_1261 = REAL_TO_DOUBLE(aux_4534);
}
aux1518_1697 = log(x_1261);
}
}
 else {
{
obj_t aux_4541;
{
obj_t aux2408_2611;
aux2408_2611 = debug_error_location_199___error(string2888___r4_numbers_6_5, string2839___r4_numbers_6_5, x_60, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2408_2611)){
aux_4541 = aux2408_2611;
}
 else {
bigloo_type_error_location_103___error(symbol2887___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2408_2611, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1518_1697 = REAL_TO_DOUBLE(aux_4541);
}
}
}
}
POP_TRACE();
return aux1518_1697;
}
}
}
}


/* _log */obj_t _log___r4_numbers_6_5(obj_t env_1819, obj_t x_1820)
{
{
double aux_4551;
aux_4551 = log___r4_numbers_6_5(x_1820);
return make_real(aux_4551);
}
}


/* sin */double sin___r4_numbers_6_5(obj_t x_61)
{
{
obj_t symbol1521_1698;
symbol1521_1698 = symbol2889___r4_numbers_6_5;
{
PUSH_TRACE(symbol1521_1698);
BUNSPEC;
{
double aux1520_1699;
{
bool_t test1178_543;
test1178_543 = INTEGERP(x_61);
if(test1178_543){
{
double arg1179_544;
{
long aux_4557;
{
obj_t aux_4558;
if(test1178_543){
aux_4558 = x_61;
}
 else {
bigloo_type_error_location_103___error(symbol2889___r4_numbers_6_5, string2836___r4_numbers_6_5, x_61, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4557 = (long)CINT(aux_4558);
}
arg1179_544 = (double)(aux_4557);
}
aux1520_1699 = sin(arg1179_544);
}
}
 else {
bool_t test1180_545;
test1180_545 = REALP(x_61);
if(test1180_545){
{
double x_1269;
{
obj_t aux_4568;
if(test1180_545){
aux_4568 = x_61;
}
 else {
bigloo_type_error_location_103___error(symbol2889___r4_numbers_6_5, string2833___r4_numbers_6_5, x_61, string2834___r4_numbers_6_5, BINT(((long)21081)));
exit( -1 );}
x_1269 = REAL_TO_DOUBLE(aux_4568);
}
aux1520_1699 = sin(x_1269);
}
}
 else {
{
obj_t aux_4575;
{
obj_t aux2426_2629;
aux2426_2629 = debug_error_location_199___error(string2890___r4_numbers_6_5, string2839___r4_numbers_6_5, x_61, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2426_2629)){
aux_4575 = aux2426_2629;
}
 else {
bigloo_type_error_location_103___error(symbol2889___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2426_2629, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1520_1699 = REAL_TO_DOUBLE(aux_4575);
}
}
}
}
POP_TRACE();
return aux1520_1699;
}
}
}
}


/* _sin */obj_t _sin___r4_numbers_6_5(obj_t env_1821, obj_t x_1822)
{
{
double aux_4585;
aux_4585 = sin___r4_numbers_6_5(x_1822);
return make_real(aux_4585);
}
}


/* cos */double cos___r4_numbers_6_5(obj_t x_62)
{
{
obj_t symbol1523_1700;
symbol1523_1700 = symbol2891___r4_numbers_6_5;
{
PUSH_TRACE(symbol1523_1700);
BUNSPEC;
{
double aux1522_1701;
{
bool_t test1181_546;
test1181_546 = INTEGERP(x_62);
if(test1181_546){
{
double arg1182_547;
{
long aux_4591;
{
obj_t aux_4592;
if(test1181_546){
aux_4592 = x_62;
}
 else {
bigloo_type_error_location_103___error(symbol2891___r4_numbers_6_5, string2836___r4_numbers_6_5, x_62, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4591 = (long)CINT(aux_4592);
}
arg1182_547 = (double)(aux_4591);
}
aux1522_1701 = cos(arg1182_547);
}
}
 else {
bool_t test1183_548;
test1183_548 = REALP(x_62);
if(test1183_548){
{
double x_1277;
{
obj_t aux_4602;
if(test1183_548){
aux_4602 = x_62;
}
 else {
bigloo_type_error_location_103___error(symbol2891___r4_numbers_6_5, string2833___r4_numbers_6_5, x_62, string2834___r4_numbers_6_5, BINT(((long)21473)));
exit( -1 );}
x_1277 = REAL_TO_DOUBLE(aux_4602);
}
aux1522_1701 = cos(x_1277);
}
}
 else {
{
obj_t aux_4609;
{
obj_t aux2444_2647;
aux2444_2647 = debug_error_location_199___error(string2892___r4_numbers_6_5, string2839___r4_numbers_6_5, x_62, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2444_2647)){
aux_4609 = aux2444_2647;
}
 else {
bigloo_type_error_location_103___error(symbol2891___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2444_2647, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1522_1701 = REAL_TO_DOUBLE(aux_4609);
}
}
}
}
POP_TRACE();
return aux1522_1701;
}
}
}
}


/* _cos */obj_t _cos___r4_numbers_6_5(obj_t env_1823, obj_t x_1824)
{
{
double aux_4619;
aux_4619 = cos___r4_numbers_6_5(x_1824);
return make_real(aux_4619);
}
}


/* tan */double tan___r4_numbers_6_5(obj_t x_63)
{
{
obj_t symbol1525_1702;
symbol1525_1702 = symbol2893___r4_numbers_6_5;
{
PUSH_TRACE(symbol1525_1702);
BUNSPEC;
{
double aux1524_1703;
{
bool_t test1184_549;
test1184_549 = INTEGERP(x_63);
if(test1184_549){
{
double arg1185_550;
{
long aux_4625;
{
obj_t aux_4626;
if(test1184_549){
aux_4626 = x_63;
}
 else {
bigloo_type_error_location_103___error(symbol2893___r4_numbers_6_5, string2836___r4_numbers_6_5, x_63, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4625 = (long)CINT(aux_4626);
}
arg1185_550 = (double)(aux_4625);
}
aux1524_1703 = tan(arg1185_550);
}
}
 else {
bool_t test1186_551;
test1186_551 = REALP(x_63);
if(test1186_551){
{
double x_1285;
{
obj_t aux_4636;
if(test1186_551){
aux_4636 = x_63;
}
 else {
bigloo_type_error_location_103___error(symbol2893___r4_numbers_6_5, string2833___r4_numbers_6_5, x_63, string2834___r4_numbers_6_5, BINT(((long)21865)));
exit( -1 );}
x_1285 = REAL_TO_DOUBLE(aux_4636);
}
aux1524_1703 = tan(x_1285);
}
}
 else {
{
obj_t aux_4643;
{
obj_t aux2462_2665;
aux2462_2665 = debug_error_location_199___error(string2894___r4_numbers_6_5, string2839___r4_numbers_6_5, x_63, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2462_2665)){
aux_4643 = aux2462_2665;
}
 else {
bigloo_type_error_location_103___error(symbol2893___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2462_2665, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1524_1703 = REAL_TO_DOUBLE(aux_4643);
}
}
}
}
POP_TRACE();
return aux1524_1703;
}
}
}
}


/* _tan */obj_t _tan___r4_numbers_6_5(obj_t env_1825, obj_t x_1826)
{
{
double aux_4653;
aux_4653 = tan___r4_numbers_6_5(x_1826);
return make_real(aux_4653);
}
}


/* asin */double asin___r4_numbers_6_5(obj_t x_64)
{
{
obj_t symbol1527_1704;
symbol1527_1704 = symbol2895___r4_numbers_6_5;
{
PUSH_TRACE(symbol1527_1704);
BUNSPEC;
{
double aux1526_1705;
{
bool_t test1187_552;
test1187_552 = INTEGERP(x_64);
if(test1187_552){
{
double arg1188_553;
{
long aux_4659;
{
obj_t aux_4660;
if(test1187_552){
aux_4660 = x_64;
}
 else {
bigloo_type_error_location_103___error(symbol2895___r4_numbers_6_5, string2836___r4_numbers_6_5, x_64, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4659 = (long)CINT(aux_4660);
}
arg1188_553 = (double)(aux_4659);
}
aux1526_1705 = asin(arg1188_553);
}
}
 else {
bool_t test1189_554;
test1189_554 = REALP(x_64);
if(test1189_554){
{
double x_1293;
{
obj_t aux_4670;
if(test1189_554){
aux_4670 = x_64;
}
 else {
bigloo_type_error_location_103___error(symbol2895___r4_numbers_6_5, string2833___r4_numbers_6_5, x_64, string2834___r4_numbers_6_5, BINT(((long)22259)));
exit( -1 );}
x_1293 = REAL_TO_DOUBLE(aux_4670);
}
aux1526_1705 = asin(x_1293);
}
}
 else {
{
obj_t aux_4677;
{
obj_t aux2480_2683;
aux2480_2683 = debug_error_location_199___error(string2896___r4_numbers_6_5, string2839___r4_numbers_6_5, x_64, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2480_2683)){
aux_4677 = aux2480_2683;
}
 else {
bigloo_type_error_location_103___error(symbol2895___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2480_2683, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1526_1705 = REAL_TO_DOUBLE(aux_4677);
}
}
}
}
POP_TRACE();
return aux1526_1705;
}
}
}
}


/* _asin */obj_t _asin___r4_numbers_6_5(obj_t env_1827, obj_t x_1828)
{
{
double aux_4687;
aux_4687 = asin___r4_numbers_6_5(x_1828);
return make_real(aux_4687);
}
}


/* acos */double acos___r4_numbers_6_5(obj_t x_65)
{
{
obj_t symbol1529_1706;
symbol1529_1706 = symbol2897___r4_numbers_6_5;
{
PUSH_TRACE(symbol1529_1706);
BUNSPEC;
{
double aux1528_1707;
{
bool_t test1190_555;
test1190_555 = INTEGERP(x_65);
if(test1190_555){
{
double arg1191_556;
{
long aux_4693;
{
obj_t aux_4694;
if(test1190_555){
aux_4694 = x_65;
}
 else {
bigloo_type_error_location_103___error(symbol2897___r4_numbers_6_5, string2836___r4_numbers_6_5, x_65, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4693 = (long)CINT(aux_4694);
}
arg1191_556 = (double)(aux_4693);
}
aux1528_1707 = acos(arg1191_556);
}
}
 else {
bool_t test1192_557;
test1192_557 = REALP(x_65);
if(test1192_557){
{
double x_1301;
{
obj_t aux_4704;
if(test1192_557){
aux_4704 = x_65;
}
 else {
bigloo_type_error_location_103___error(symbol2897___r4_numbers_6_5, string2833___r4_numbers_6_5, x_65, string2834___r4_numbers_6_5, BINT(((long)22655)));
exit( -1 );}
x_1301 = REAL_TO_DOUBLE(aux_4704);
}
aux1528_1707 = acos(x_1301);
}
}
 else {
{
obj_t aux_4711;
{
obj_t aux2500_2701;
aux2500_2701 = debug_error_location_199___error(string2898___r4_numbers_6_5, string2839___r4_numbers_6_5, x_65, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2500_2701)){
aux_4711 = aux2500_2701;
}
 else {
bigloo_type_error_location_103___error(symbol2897___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2500_2701, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1528_1707 = REAL_TO_DOUBLE(aux_4711);
}
}
}
}
POP_TRACE();
return aux1528_1707;
}
}
}
}


/* _acos */obj_t _acos___r4_numbers_6_5(obj_t env_1829, obj_t x_1830)
{
{
double aux_4721;
aux_4721 = acos___r4_numbers_6_5(x_1830);
return make_real(aux_4721);
}
}


/* atan */double atan___r4_numbers_6_5(obj_t x_66, obj_t y_67)
{
{
obj_t symbol1531_1708;
symbol1531_1708 = symbol2899___r4_numbers_6_5;
{
PUSH_TRACE(symbol1531_1708);
BUNSPEC;
{
double aux1530_1709;
{
obj_t y_558;
{
bool_t test1198_567;
test1198_567 = PAIRP(y_67);
if(test1198_567){
obj_t y_568;
{
obj_t pair_1306;
if(test1198_567){
pair_1306 = y_67;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2842___r4_numbers_6_5, y_67, string2834___r4_numbers_6_5, BINT(((long)23002)));
exit( -1 );}
y_568 = CAR(pair_1306);
}
{
bool_t test1199_569;
test1199_569 = INTEGERP(y_568);
if(test1199_569){
{
double aux_4734;
{
long aux_4735;
{
obj_t aux_4736;
if(test1199_569){
aux_4736 = y_568;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2836___r4_numbers_6_5, y_568, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4735 = (long)CINT(aux_4736);
}
aux_4734 = (double)(aux_4735);
}
y_558 = make_real(aux_4734);
}
}
 else {
if(REALP(y_568)){
y_558 = y_568;
}
 else {
y_558 = debug_error_location_199___error(string2900___r4_numbers_6_5, string2839___r4_numbers_6_5, y_568, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
y_558 = BFALSE;
}
}
{
bool_t test1193_560;
test1193_560 = INTEGERP(x_66);
if(test1193_560){
{
double arg1194_561;
{
long aux_4750;
{
obj_t aux_4751;
if(test1193_560){
aux_4751 = x_66;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2836___r4_numbers_6_5, x_66, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4750 = (long)CINT(aux_4751);
}
arg1194_561 = (double)(aux_4750);
}
{
bool_t test_4758;
if(INTEGERP(y_558)){
test_4758 = ((bool_t)1);
}
 else {
test_4758 = REALP(y_558);
}
if(test_4758){
double res1432_1336;
{
double y_1323;
{
obj_t aux_4762;
if(REALP(y_558)){
aux_4762 = y_558;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, y_558, string2834___r4_numbers_6_5, BINT(((long)23224)));
exit( -1 );}
y_1323 = REAL_TO_DOUBLE(aux_4762);
}
{
bool_t test_4769;
if((arg1194_561==((double)0.0))){
test_4769 = (y_1323==((double)0.0));
}
 else {
test_4769 = ((bool_t)0);
}
if(test_4769){
obj_t aux_4773;
{
obj_t aux2533_2731;
aux2533_2731 = debug_error_location_199___error(string2901___r4_numbers_6_5, string2902___r4_numbers_6_5, real2903___r4_numbers_6_5, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2533_2731)){
aux_4773 = aux2533_2731;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2533_2731, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1432_1336 = REAL_TO_DOUBLE(aux_4773);
}
 else {
res1432_1336 = atan2(arg1194_561, y_1323);
}
}
}
aux1530_1709 = res1432_1336;
}
 else {
aux1530_1709 = atan(arg1194_561);
}
}
}
}
 else {
bool_t test1195_562;
test1195_562 = REALP(x_66);
if(test1195_562){
{
bool_t test_4786;
if(INTEGERP(y_558)){
test_4786 = ((bool_t)1);
}
 else {
test_4786 = REALP(y_558);
}
if(test_4786){
double res1434_1360;
{
double x_1346;
double y_1347;
{
obj_t aux_4790;
if(test1195_562){
aux_4790 = x_66;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, x_66, string2834___r4_numbers_6_5, BINT(((long)23224)));
exit( -1 );}
x_1346 = REAL_TO_DOUBLE(aux_4790);
}
{
obj_t aux_4796;
if(REALP(y_558)){
aux_4796 = y_558;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, y_558, string2834___r4_numbers_6_5, BINT(((long)23224)));
exit( -1 );}
y_1347 = REAL_TO_DOUBLE(aux_4796);
}
{
bool_t test_4803;
if((x_1346==((double)0.0))){
test_4803 = (y_1347==((double)0.0));
}
 else {
test_4803 = ((bool_t)0);
}
if(test_4803){
obj_t aux_4807;
{
obj_t aux2552_2749;
aux2552_2749 = debug_error_location_199___error(string2901___r4_numbers_6_5, string2902___r4_numbers_6_5, real2903___r4_numbers_6_5, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2552_2749)){
aux_4807 = aux2552_2749;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2552_2749, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1434_1360 = REAL_TO_DOUBLE(aux_4807);
}
 else {
res1434_1360 = atan2(x_1346, y_1347);
}
}
}
aux1530_1709 = res1434_1360;
}
 else {
double x_1361;
{
obj_t aux_4817;
if(test1195_562){
aux_4817 = x_66;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, x_66, string2834___r4_numbers_6_5, BINT(((long)23243)));
exit( -1 );}
x_1361 = REAL_TO_DOUBLE(aux_4817);
}
aux1530_1709 = atan(x_1361);
}
}
}
 else {
{
obj_t aux_4824;
{
obj_t aux2566_2761;
aux2566_2761 = debug_error_location_199___error(string2900___r4_numbers_6_5, string2839___r4_numbers_6_5, x_66, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2566_2761)){
aux_4824 = aux2566_2761;
}
 else {
bigloo_type_error_location_103___error(symbol2899___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2566_2761, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1530_1709 = REAL_TO_DOUBLE(aux_4824);
}
}
}
}
}
POP_TRACE();
return aux1530_1709;
}
}
}
}


/* _atan */obj_t _atan___r4_numbers_6_5(obj_t env_1831, obj_t x_1832, obj_t y_1833)
{
{
double aux_4834;
aux_4834 = atan___r4_numbers_6_5(x_1832, y_1833);
return make_real(aux_4834);
}
}


/* sqrt */double sqrt___r4_numbers_6_5(obj_t x_68)
{
{
obj_t symbol1533_1710;
symbol1533_1710 = symbol2904___r4_numbers_6_5;
{
PUSH_TRACE(symbol1533_1710);
BUNSPEC;
{
double aux1532_1711;
{
bool_t test1201_571;
test1201_571 = INTEGERP(x_68);
if(test1201_571){
{
double arg1202_572;
{
long aux_4840;
{
obj_t aux_4841;
if(test1201_571){
aux_4841 = x_68;
}
 else {
bigloo_type_error_location_103___error(symbol2904___r4_numbers_6_5, string2836___r4_numbers_6_5, x_68, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4840 = (long)CINT(aux_4841);
}
arg1202_572 = (double)(aux_4840);
}
{
double res1437_1399;
if((arg1202_572<((double)0.0))){
obj_t aux_4850;
{
obj_t aux2580_2773;
aux2580_2773 = debug_error_location_199___error(string2905___r4_numbers_6_5, string2902___r4_numbers_6_5, make_real(arg1202_572), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2580_2773)){
aux_4850 = aux2580_2773;
}
 else {
bigloo_type_error_location_103___error(symbol2904___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2580_2773, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1437_1399 = REAL_TO_DOUBLE(aux_4850);
}
 else {
res1437_1399 = sqrt(arg1202_572);
}
aux1532_1711 = res1437_1399;
}
}
}
 else {
bool_t test1203_573;
test1203_573 = REALP(x_68);
if(test1203_573){
{
double res1438_1411;
{
double r_1401;
{
obj_t aux_4863;
if(test1203_573){
aux_4863 = x_68;
}
 else {
bigloo_type_error_location_103___error(symbol2904___r4_numbers_6_5, string2833___r4_numbers_6_5, x_68, string2834___r4_numbers_6_5, BINT(((long)23728)));
exit( -1 );}
r_1401 = REAL_TO_DOUBLE(aux_4863);
}
if((r_1401<((double)0.0))){
obj_t aux_4871;
{
obj_t aux2593_2785;
aux2593_2785 = debug_error_location_199___error(string2905___r4_numbers_6_5, string2902___r4_numbers_6_5, make_real(r_1401), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2593_2785)){
aux_4871 = aux2593_2785;
}
 else {
bigloo_type_error_location_103___error(symbol2904___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2593_2785, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1438_1411 = REAL_TO_DOUBLE(aux_4871);
}
 else {
res1438_1411 = sqrt(r_1401);
}
}
aux1532_1711 = res1438_1411;
}
}
 else {
{
obj_t aux_4882;
{
obj_t aux2599_2791;
aux2599_2791 = debug_error_location_199___error(string2906___r4_numbers_6_5, string2839___r4_numbers_6_5, x_68, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(REALP(aux2599_2791)){
aux_4882 = aux2599_2791;
}
 else {
bigloo_type_error_location_103___error(symbol2904___r4_numbers_6_5, string2833___r4_numbers_6_5, aux2599_2791, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1532_1711 = REAL_TO_DOUBLE(aux_4882);
}
}
}
}
POP_TRACE();
return aux1532_1711;
}
}
}
}


/* _sqrt */obj_t _sqrt___r4_numbers_6_5(obj_t env_1834, obj_t x_1835)
{
{
double aux_4892;
aux_4892 = sqrt___r4_numbers_6_5(x_1835);
return make_real(aux_4892);
}
}


/* expt */obj_t expt___r4_numbers_6_5(obj_t x_69, obj_t y_70)
{
{
obj_t symbol1535_1712;
symbol1535_1712 = symbol2907___r4_numbers_6_5;
{
PUSH_TRACE(symbol1535_1712);
BUNSPEC;
{
obj_t aux1534_1713;
{
bool_t test1204_574;
{
bool_t test1221_587;
test1221_587 = REALP(x_69);
if(test1221_587){
bool_t test1222_588;
test1222_588 = REALP(y_70);
if(test1222_588){
bool_t test1223_589;
{
double r1_1417;
{
obj_t aux_4900;
if(test1221_587){
aux_4900 = x_69;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, x_69, string2834___r4_numbers_6_5, BINT(((long)24073)));
exit( -1 );}
r1_1417 = REAL_TO_DOUBLE(aux_4900);
}
test1223_589 = (r1_1417==((double)0.0));
}
if(test1223_589){
double r1_1419;
{
obj_t aux_4908;
if(test1222_588){
aux_4908 = y_70;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, y_70, string2834___r4_numbers_6_5, BINT(((long)24085)));
exit( -1 );}
r1_1419 = REAL_TO_DOUBLE(aux_4908);
}
test1204_574 = (r1_1419==((double)0.0));
}
 else {
test1204_574 = ((bool_t)0);
}
}
 else {
test1204_574 = ((bool_t)0);
}
}
 else {
test1204_574 = ((bool_t)0);
}
}
if(test1204_574){
aux1534_1713 = real2908___r4_numbers_6_5;
}
 else {
bool_t test_4916;
if(INTEGERP(x_69)){
test_4916 = INTEGERP(y_70);
}
 else {
test_4916 = ((bool_t)0);
}
if(test_4916){
{
double arg1206_576;
{
double arg1207_577;
double arg1209_578;
{
long aux_4920;
{
obj_t aux_4921;
if(INTEGERP(x_69)){
aux_4921 = x_69;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2836___r4_numbers_6_5, x_69, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4920 = (long)CINT(aux_4921);
}
arg1207_577 = (double)(aux_4920);
}
{
long aux_4929;
{
obj_t aux_4930;
if(INTEGERP(y_70)){
aux_4930 = y_70;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2836___r4_numbers_6_5, y_70, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4929 = (long)CINT(aux_4930);
}
arg1209_578 = (double)(aux_4929);
}
arg1206_576 = pow(arg1207_577, arg1209_578);
}
{
obj_t x_1427;
x_1427 = make_real(arg1206_576);
{
long aux_4940;
{
double aux_4941;
{
obj_t aux_4942;
if(REALP(x_1427)){
aux_4942 = x_1427;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, x_1427, string2834___r4_numbers_6_5, BINT(((long)6711)));
exit( -1 );}
aux_4941 = REAL_TO_DOUBLE(aux_4942);
}
aux_4940 = (long)(aux_4941);
}
aux1534_1713 = BINT(aux_4940);
}
}
}
}
 else {
bool_t test1210_579;
test1210_579 = INTEGERP(x_69);
if(test1210_579){
{
bool_t test1211_580;
test1211_580 = REALP(y_70);
if(test1211_580){
{
double arg1213_581;
{
long aux_4955;
{
obj_t aux_4956;
if(test1210_579){
aux_4956 = x_69;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2836___r4_numbers_6_5, x_69, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4955 = (long)CINT(aux_4956);
}
arg1213_581 = (double)(aux_4955);
}
{
double r2_1432;
{
obj_t aux_4963;
if(test1211_580){
aux_4963 = y_70;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, y_70, string2834___r4_numbers_6_5, BINT(((long)24281)));
exit( -1 );}
r2_1432 = REAL_TO_DOUBLE(aux_4963);
}
{
double aux_4969;
aux_4969 = pow(arg1213_581, r2_1432);
aux1534_1713 = make_real(aux_4969);
}
}
}
}
 else {
aux1534_1713 = debug_error_location_199___error(string2909___r4_numbers_6_5, string2839___r4_numbers_6_5, y_70, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
 else {
bool_t test1214_582;
test1214_582 = REALP(x_69);
if(test1214_582){
{
bool_t test1215_583;
test1215_583 = REALP(y_70);
if(test1215_583){
{
double r1_1438;
double r2_1439;
{
obj_t aux_4978;
if(test1214_582){
aux_4978 = x_69;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, x_69, string2834___r4_numbers_6_5, BINT(((long)24423)));
exit( -1 );}
r1_1438 = REAL_TO_DOUBLE(aux_4978);
}
{
obj_t aux_4984;
if(test1215_583){
aux_4984 = y_70;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, y_70, string2834___r4_numbers_6_5, BINT(((long)24430)));
exit( -1 );}
r2_1439 = REAL_TO_DOUBLE(aux_4984);
}
{
double aux_4990;
aux_4990 = pow(r1_1438, r2_1439);
aux1534_1713 = make_real(aux_4990);
}
}
}
 else {
bool_t test1216_584;
test1216_584 = INTEGERP(y_70);
if(test1216_584){
{
double arg1219_585;
{
long aux_4995;
{
obj_t aux_4996;
if(test1216_584){
aux_4996 = y_70;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2836___r4_numbers_6_5, y_70, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_4995 = (long)CINT(aux_4996);
}
arg1219_585 = (double)(aux_4995);
}
{
double r1_1442;
{
obj_t aux_5003;
if(test1214_582){
aux_5003 = x_69;
}
 else {
bigloo_type_error_location_103___error(symbol2907___r4_numbers_6_5, string2833___r4_numbers_6_5, x_69, string2834___r4_numbers_6_5, BINT(((long)24464)));
exit( -1 );}
r1_1442 = REAL_TO_DOUBLE(aux_5003);
}
{
double aux_5009;
aux_5009 = pow(r1_1442, arg1219_585);
aux1534_1713 = make_real(aux_5009);
}
}
}
}
 else {
aux1534_1713 = debug_error_location_199___error(string2909___r4_numbers_6_5, string2839___r4_numbers_6_5, y_70, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
 else {
aux1534_1713 = debug_error_location_199___error(string2909___r4_numbers_6_5, string2839___r4_numbers_6_5, x_69, string2840___r4_numbers_6_5, BINT(((long)7610)));
}
}
}
}
}
POP_TRACE();
return aux1534_1713;
}
}
}
}


/* _expt */obj_t _expt___r4_numbers_6_5(obj_t env_1836, obj_t x_1837, obj_t y_1838)
{
return expt___r4_numbers_6_5(x_1837, y_1838);
}


/* exact->inexact */obj_t exact__inexact_122___r4_numbers_6_5(obj_t z_71)
{
{
obj_t symbol1537_3038;
symbol1537_3038 = symbol2910___r4_numbers_6_5;
{
PUSH_TRACE(symbol1537_3038);
BUNSPEC;
{
obj_t aux1536_3039;
{
bool_t test1224_3040;
test1224_3040 = INTEGERP(z_71);
if(test1224_3040){
double aux_5021;
{
long aux_5022;
{
obj_t aux_5023;
if(test1224_3040){
aux_5023 = z_71;
}
 else {
bigloo_type_error_location_103___error(symbol2910___r4_numbers_6_5, string2836___r4_numbers_6_5, z_71, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_5022 = (long)CINT(aux_5023);
}
aux_5021 = (double)(aux_5022);
}
aux1536_3039 = make_real(aux_5021);
}
 else {
aux1536_3039 = z_71;
}
}
POP_TRACE();
return aux1536_3039;
}
}
}
}


/* _exact->inexact */obj_t _exact__inexact_16___r4_numbers_6_5(obj_t env_1839, obj_t z_1840)
{
{
obj_t z_3041;
z_3041 = z_1840;
{
obj_t symbol1537_3042;
symbol1537_3042 = symbol2910___r4_numbers_6_5;
{
PUSH_TRACE(symbol1537_3042);
BUNSPEC;
{
obj_t aux1536_3043;
{
bool_t test1224_3044;
test1224_3044 = INTEGERP(z_3041);
if(test1224_3044){
double aux_5035;
{
long aux_5036;
{
obj_t aux_5037;
if(test1224_3044){
aux_5037 = z_3041;
}
 else {
bigloo_type_error_location_103___error(symbol2910___r4_numbers_6_5, string2836___r4_numbers_6_5, z_3041, string2834___r4_numbers_6_5, BINT(((long)6993)));
exit( -1 );}
aux_5036 = (long)CINT(aux_5037);
}
aux_5035 = (double)(aux_5036);
}
aux1536_3043 = make_real(aux_5035);
}
 else {
aux1536_3043 = z_3041;
}
}
POP_TRACE();
return aux1536_3043;
}
}
}
}
}


/* inexact->exact */obj_t inexact__exact_80___r4_numbers_6_5(obj_t z_72)
{
{
obj_t symbol1539_3045;
symbol1539_3045 = symbol2911___r4_numbers_6_5;
{
PUSH_TRACE(symbol1539_3045);
BUNSPEC;
{
obj_t aux1538_3046;
{
bool_t test1225_3047;
test1225_3047 = REALP(z_72);
if(test1225_3047){
long aux_5049;
{
double aux_5050;
{
obj_t aux_5051;
if(test1225_3047){
aux_5051 = z_72;
}
 else {
bigloo_type_error_location_103___error(symbol2911___r4_numbers_6_5, string2833___r4_numbers_6_5, z_72, string2834___r4_numbers_6_5, BINT(((long)6711)));
exit( -1 );}
aux_5050 = REAL_TO_DOUBLE(aux_5051);
}
aux_5049 = (long)(aux_5050);
}
aux1538_3046 = BINT(aux_5049);
}
 else {
aux1538_3046 = z_72;
}
}
POP_TRACE();
return aux1538_3046;
}
}
}
}


/* _inexact->exact */obj_t _inexact__exact_215___r4_numbers_6_5(obj_t env_1841, obj_t z_1842)
{
{
obj_t z_3048;
z_3048 = z_1842;
{
obj_t symbol1539_3049;
symbol1539_3049 = symbol2911___r4_numbers_6_5;
{
PUSH_TRACE(symbol1539_3049);
BUNSPEC;
{
obj_t aux1538_3050;
{
bool_t test1225_3051;
test1225_3051 = REALP(z_3048);
if(test1225_3051){
long aux_5063;
{
double aux_5064;
{
obj_t aux_5065;
if(test1225_3051){
aux_5065 = z_3048;
}
 else {
bigloo_type_error_location_103___error(symbol2911___r4_numbers_6_5, string2833___r4_numbers_6_5, z_3048, string2834___r4_numbers_6_5, BINT(((long)6711)));
exit( -1 );}
aux_5064 = REAL_TO_DOUBLE(aux_5065);
}
aux_5063 = (long)(aux_5064);
}
aux1538_3050 = BINT(aux_5063);
}
 else {
aux1538_3050 = z_3048;
}
}
POP_TRACE();
return aux1538_3050;
}
}
}
}
}


/* number->string */char * number__string_214___r4_numbers_6_5(obj_t x_73, obj_t radix_74)
{
{
obj_t symbol1541_1718;
symbol1541_1718 = symbol2912___r4_numbers_6_5;
{
PUSH_TRACE(symbol1541_1718);
BUNSPEC;
{
char * aux1540_1719;
{
bool_t test1226_592;
{
obj_t obj_1458;
obj_1458 = radix_74;
test1226_592 = NULLP(obj_1458);
}
if(test1226_592){
radix_74 = BINT(((long)10));
}
 else {
obj_t pair_1459;
{
obj_t aux2688_2875;
aux2688_2875 = radix_74;
if(PAIRP(aux2688_2875)){
pair_1459 = aux2688_2875;
}
 else {
bigloo_type_error_location_103___error(symbol2912___r4_numbers_6_5, string2842___r4_numbers_6_5, aux2688_2875, string2834___r4_numbers_6_5, BINT(((long)25549)));
exit( -1 );}
}
radix_74 = CAR(pair_1459);
}
}
{
bool_t test1227_593;
test1227_593 = INTEGERP(x_73);
if(test1227_593){
{
obj_t list1228_594;
list1228_594 = MAKE_PAIR(radix_74, BNIL);
{
long aux_5087;
{
obj_t aux_5088;
if(test1227_593){
aux_5088 = x_73;
}
 else {
bigloo_type_error_location_103___error(symbol2912___r4_numbers_6_5, string2836___r4_numbers_6_5, x_73, string2834___r4_numbers_6_5, BINT(((long)25597)));
exit( -1 );}
aux_5087 = (long)CINT(aux_5088);
}
aux1540_1719 = integer__string_135___r4_numbers_6_5_fixnum(aux_5087, list1228_594);
}
}
}
 else {
bool_t test1232_596;
test1232_596 = REALP(x_73);
if(test1232_596){
{
double real_1462;
{
obj_t aux_5097;
if(test1232_596){
aux_5097 = x_73;
}
 else {
bigloo_type_error_location_103___error(symbol2912___r4_numbers_6_5, string2833___r4_numbers_6_5, x_73, string2834___r4_numbers_6_5, BINT(((long)25651)));
exit( -1 );}
real_1462 = REAL_TO_DOUBLE(aux_5097);
}
aux1540_1719 = real_to_string(real_1462);
}
}
 else {
{
obj_t aux_5104;
{
obj_t aux2706_2893;
aux2706_2893 = debug_error_location_199___error(string2913___r4_numbers_6_5, string2914___r4_numbers_6_5, x_73, string2840___r4_numbers_6_5, BINT(((long)7610)));
if(STRINGP(aux2706_2893)){
aux_5104 = aux2706_2893;
}
 else {
bigloo_type_error_location_103___error(symbol2912___r4_numbers_6_5, string2915___r4_numbers_6_5, aux2706_2893, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
aux1540_1719 = BSTRING_TO_STRING(aux_5104);
}
}
}
}
POP_TRACE();
return aux1540_1719;
}
}
}
}


/* _number->string */obj_t _number__string_61___r4_numbers_6_5(obj_t env_1843, obj_t x_1844, obj_t radix_1845)
{
{
char * aux_5114;
aux_5114 = number__string_214___r4_numbers_6_5(x_1844, radix_1845);
return string_to_bstring(aux_5114);
}
}


/* string->number */obj_t string__number_104___r4_numbers_6_5(obj_t x_75, obj_t radix_76)
{
{
obj_t symbol1543_1720;
symbol1543_1720 = symbol2916___r4_numbers_6_5;
{
PUSH_TRACE(symbol1543_1720);
BUNSPEC;
{
obj_t aux1542_1721;
{
obj_t x_605;
{
bool_t test1233_598;
x_605 = x_75;
{
long i_607;
{
long arg1243_609;
{
long arg1244_610;
{
obj_t string_1476;
if(STRINGP(x_605)){
string_1476 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26055)));
exit( -1 );}
arg1244_610 = STRING_LENGTH(string_1476);
}
arg1243_609 = (arg1244_610-((long)1));
}
i_607 = arg1243_609;
loop_608:
if((i_607==((long)-1))){
test1233_598 = ((bool_t)1);
}
 else {
bool_t test1247_613;
{
unsigned char arg1265_629;
{
unsigned char res1439_1489;
{
obj_t string_1481;
if(STRINGP(x_605)){
string_1481 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26127)));
exit( -1 );}
{
bool_t test_5132;
{
long aux_5133;
aux_5133 = STRING_LENGTH(string_1481);
test_5132 = BOUND_CHECK(i_607, aux_5133);
}
if(test_5132){
res1439_1489 = STRING_REF(string_1481, i_607);
}
 else {
obj_t aux_5137;
{
obj_t aux2718_2905;
aux2718_2905 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2718_2905)){
aux_5137 = aux2718_2905;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2718_2905, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1439_1489 = (unsigned char)CCHAR(aux_5137);
}
}
}
arg1265_629 = res1439_1489;
}
test1247_613 = (arg1265_629==((unsigned char)'-'));
}
if(test1247_613){
test1233_598 = (i_607==((long)0));
}
 else {
bool_t test1248_614;
{
bool_t test1261_626;
{
unsigned char arg1263_628;
{
unsigned char res1440_1502;
{
obj_t string_1494;
if(STRINGP(x_605)){
string_1494 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26186)));
exit( -1 );}
{
bool_t test_5155;
{
long aux_5156;
aux_5156 = STRING_LENGTH(string_1494);
test_5155 = BOUND_CHECK(i_607, aux_5156);
}
if(test_5155){
res1440_1502 = STRING_REF(string_1494, i_607);
}
 else {
obj_t aux_5160;
{
obj_t aux2731_2917;
aux2731_2917 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2731_2917)){
aux_5160 = aux2731_2917;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2731_2917, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1440_1502 = (unsigned char)CCHAR(aux_5160);
}
}
}
arg1263_628 = res1440_1502;
}
test1261_626 = (arg1263_628>=((unsigned char)'0'));
}
if(test1261_626){
unsigned char arg1262_627;
{
unsigned char res1441_1513;
{
obj_t string_1505;
if(STRINGP(x_605)){
string_1505 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26221)));
exit( -1 );}
{
bool_t test_5177;
{
long aux_5178;
aux_5178 = STRING_LENGTH(string_1505);
test_5177 = BOUND_CHECK(i_607, aux_5178);
}
if(test_5177){
res1441_1513 = STRING_REF(string_1505, i_607);
}
 else {
obj_t aux_5182;
{
obj_t aux2743_2929;
aux2743_2929 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2743_2929)){
aux_5182 = aux2743_2929;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2743_2929, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1441_1513 = (unsigned char)CCHAR(aux_5182);
}
}
}
arg1262_627 = res1441_1513;
}
test1248_614 = (arg1262_627<=((unsigned char)'9'));
}
 else {
test1248_614 = ((bool_t)0);
}
}
if(test1248_614){
{
long i_5194;
i_5194 = (i_607-((long)1));
i_607 = i_5194;
goto loop_608;
}
}
 else {
bool_t test1251_616;
{
bool_t test1258_623;
{
unsigned char arg1260_625;
{
unsigned char res1442_1526;
{
obj_t string_1518;
if(STRINGP(x_605)){
string_1518 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26288)));
exit( -1 );}
{
bool_t test_5201;
{
long aux_5202;
aux_5202 = STRING_LENGTH(string_1518);
test_5201 = BOUND_CHECK(i_607, aux_5202);
}
if(test_5201){
res1442_1526 = STRING_REF(string_1518, i_607);
}
 else {
obj_t aux_5206;
{
obj_t aux2755_2941;
aux2755_2941 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2755_2941)){
aux_5206 = aux2755_2941;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2755_2941, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1442_1526 = (unsigned char)CCHAR(aux_5206);
}
}
}
arg1260_625 = res1442_1526;
}
test1258_623 = (arg1260_625>=((unsigned char)'a'));
}
if(test1258_623){
unsigned char arg1259_624;
{
unsigned char res1443_1537;
{
obj_t string_1529;
if(STRINGP(x_605)){
string_1529 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26323)));
exit( -1 );}
{
bool_t test_5223;
{
long aux_5224;
aux_5224 = STRING_LENGTH(string_1529);
test_5223 = BOUND_CHECK(i_607, aux_5224);
}
if(test_5223){
res1443_1537 = STRING_REF(string_1529, i_607);
}
 else {
obj_t aux_5228;
{
obj_t aux2767_2953;
aux2767_2953 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2767_2953)){
aux_5228 = aux2767_2953;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2767_2953, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1443_1537 = (unsigned char)CCHAR(aux_5228);
}
}
}
arg1259_624 = res1443_1537;
}
test1251_616 = (arg1259_624<=((unsigned char)'f'));
}
 else {
test1251_616 = ((bool_t)0);
}
}
if(test1251_616){
{
long i_5240;
i_5240 = (i_607-((long)1));
i_607 = i_5240;
goto loop_608;
}
}
 else {
bool_t test1253_618;
{
bool_t test1255_620;
{
unsigned char arg1257_622;
{
unsigned char res1444_1550;
{
obj_t string_1542;
if(STRINGP(x_605)){
string_1542 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26390)));
exit( -1 );}
{
bool_t test_5247;
{
long aux_5248;
aux_5248 = STRING_LENGTH(string_1542);
test_5247 = BOUND_CHECK(i_607, aux_5248);
}
if(test_5247){
res1444_1550 = STRING_REF(string_1542, i_607);
}
 else {
obj_t aux_5252;
{
obj_t aux2779_2965;
aux2779_2965 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2779_2965)){
aux_5252 = aux2779_2965;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2779_2965, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1444_1550 = (unsigned char)CCHAR(aux_5252);
}
}
}
arg1257_622 = res1444_1550;
}
test1255_620 = (arg1257_622>=((unsigned char)'A'));
}
if(test1255_620){
unsigned char arg1256_621;
{
unsigned char res1445_1561;
{
obj_t string_1553;
if(STRINGP(x_605)){
string_1553 = x_605;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2917___r4_numbers_6_5, x_605, string2834___r4_numbers_6_5, BINT(((long)26425)));
exit( -1 );}
{
bool_t test_5269;
{
long aux_5270;
aux_5270 = STRING_LENGTH(string_1553);
test_5269 = BOUND_CHECK(i_607, aux_5270);
}
if(test_5269){
res1445_1561 = STRING_REF(string_1553, i_607);
}
 else {
obj_t aux_5274;
{
obj_t aux2791_2977;
aux2791_2977 = debug_error_location_199___error(string2918___r4_numbers_6_5, string2919___r4_numbers_6_5, BINT(i_607), string2840___r4_numbers_6_5, BINT(((long)7610)));
if(CHARP(aux2791_2977)){
aux_5274 = aux2791_2977;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2920___r4_numbers_6_5, aux2791_2977, string2840___r4_numbers_6_5, BINT(((long)7610)));
exit( -1 );}
}
res1445_1561 = (unsigned char)CCHAR(aux_5274);
}
}
}
arg1256_621 = res1445_1561;
}
test1253_618 = (arg1256_621<=((unsigned char)'F'));
}
 else {
test1253_618 = ((bool_t)0);
}
}
if(test1253_618){
{
long i_5286;
i_5286 = (i_607-((long)1));
i_607 = i_5286;
goto loop_608;
}
}
 else {
test1233_598 = ((bool_t)0);
}
}
}
}
}
}
}
if(test1233_598){
obj_t runner1235_600;
runner1235_600 = MAKE_PAIR(x_75, radix_76);
{
char * aux1234_599;
{
obj_t pair_1468;
{
obj_t aux2803_2989;
aux2803_2989 = runner1235_600;
if(PAIRP(aux2803_2989)){
pair_1468 = aux2803_2989;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2842___r4_numbers_6_5, aux2803_2989, string2834___r4_numbers_6_5, BINT(((long)26530)));
exit( -1 );}
}
{
obj_t aux_5295;
{
obj_t aux2809_2995;
aux2809_2995 = CAR(pair_1468);
if(STRINGP(aux2809_2995)){
aux_5295 = aux2809_2995;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2915___r4_numbers_6_5, aux2809_2995, string2921___r4_numbers_6_5, BINT(((long)6826)));
exit( -1 );}
}
aux1234_599 = BSTRING_TO_STRING(aux_5295);
}
}
{
obj_t pair_1469;
{
obj_t aux2815_3001;
aux2815_3001 = runner1235_600;
if(PAIRP(aux2815_3001)){
pair_1469 = aux2815_3001;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2842___r4_numbers_6_5, aux2815_3001, string2834___r4_numbers_6_5, BINT(((long)26530)));
exit( -1 );}
}
runner1235_600 = CDR(pair_1469);
}
{
long aux_5309;
aux_5309 = string__integer_39___r4_numbers_6_5_fixnum(aux1234_599, runner1235_600);
aux1542_1721 = BINT(aux_5309);
}
}
}
 else {
obj_t runner1237_602;
runner1237_602 = MAKE_PAIR(x_75, radix_76);
{
char * aux1236_601;
{
obj_t pair_1472;
pair_1472 = runner1237_602;
{
obj_t aux_5313;
{
obj_t aux2821_3007;
aux2821_3007 = CAR(pair_1472);
if(STRINGP(aux2821_3007)){
aux_5313 = aux2821_3007;
}
 else {
bigloo_type_error_location_103___error(symbol2916___r4_numbers_6_5, string2915___r4_numbers_6_5, aux2821_3007, string2921___r4_numbers_6_5, BINT(((long)6826)));
exit( -1 );}
}
aux1236_601 = BSTRING_TO_STRING(aux_5313);
}
}
{
bool_t test1238_603;
{
obj_t arg1240_604;
{
obj_t pair_1473;
pair_1473 = runner1237_602;
arg1240_604 = CDR(pair_1473);
}
test1238_603 = NULLP(arg1240_604);
}
if(test1238_603){
double aux_5324;
aux_5324 = strtod(aux1236_601, ((long)0));
aux1542_1721 = make_real(aux_5324);
}
 else {
aux1542_1721 = debug_error_location_199___error(string2922___r4_numbers_6_5, string2923___r4_numbers_6_5, symbol2924___r4_numbers_6_5, string2834___r4_numbers_6_5, BINT(((long)26576)));
}
}
}
}
}
}
POP_TRACE();
return aux1542_1721;
}
}
}
}


/* _string->number */obj_t _string__number_250___r4_numbers_6_5(obj_t env_1846, obj_t x_1847, obj_t radix_1848)
{
return string__number_104___r4_numbers_6_5(x_1847, radix_1848);
}


/* imported-modules-init */obj_t imported_modules_init_94___r4_numbers_6_5()
{
{
obj_t symbol1545_1722;
symbol1545_1722 = symbol2925___r4_numbers_6_5;
{
PUSH_TRACE(symbol1545_1722);
BUNSPEC;
{
obj_t aux1544_1723;
aux1544_1723 = module_initialization_70___error(((long)0), "__R4_NUMBERS_6_5");
POP_TRACE();
return aux1544_1723;
}
}
}
}

