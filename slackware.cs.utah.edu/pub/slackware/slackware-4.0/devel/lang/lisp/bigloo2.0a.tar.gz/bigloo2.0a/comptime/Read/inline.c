/*===========================================================================*/
/*   (Read/inline.scm)                                                       */
/*   Bigloo (2.0)                                                            */
/*   Manuel Serrano (c)       Thu Feb 11 22:46:22 CET 1999                   */
/*===========================================================================*/

/* GC selection */
#define THE_GC BOEHM_GC

#include <bigloo2.0a.h>


/* Object type definitions */
typedef struct type
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     obj_t size;
     obj_t class;
     obj_t coerce_to_204;
     obj_t parents;
     bool_t init__47;
     bool_t magic__53;
     obj_t __57;
     obj_t alias;
     obj_t pointed_to_by_76;
     obj_t tvector;
  }
    *type_t;

typedef struct value
  {
     header_t header;
     obj_t widening;
  }
     *value_t;

typedef struct variable
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
  }
        *variable_t;

typedef struct global
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     obj_t module;
     obj_t import;
     bool_t evaluable__248;
     bool_t library__255;
     bool_t user__32;
     obj_t pragma;
     obj_t src;
  }
      *global_t;

typedef struct local
  {
     header_t header;
     obj_t widening;
     obj_t id;
     obj_t name;
     struct type *type;
     struct value *value;
     obj_t access;
     obj_t fast_alpha_7;
     obj_t removable;
     long occurrence;
     bool_t user__32;
     long key;
  }
     *local_t;

typedef struct fun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
  }
   *fun_t;

typedef struct sfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t property;
     obj_t args;
     obj_t body;
     obj_t class;
     obj_t dsssl_keywords_243;
     obj_t loc;
  }
    *sfun_t;

typedef struct cfun
  {
     header_t header;
     obj_t widening;
     long arity;
     obj_t side_effect__165;
     obj_t predicate_of_78;
     obj_t stack_allocator_172;
     bool_t top__138;
     obj_t the_closure_238;
     obj_t args_type_205;
     bool_t macro__33;
     bool_t infix__163;
  }
    *cfun_t;

typedef struct svar
  {
     header_t header;
     obj_t widening;
     obj_t loc;
  }
    *svar_t;

typedef struct scnst
  {
     header_t header;
     obj_t widening;
     obj_t node;
     obj_t class;
     obj_t loc;
  }
     *scnst_t;

typedef struct cvar
  {
     header_t header;
     obj_t widening;
     bool_t macro__33;
  }
    *cvar_t;

typedef struct sexit
  {
     header_t header;
     obj_t widening;
     obj_t handler;
     bool_t detached__120;
  }
     *sexit_t;


extern obj_t unwind_until__178___bexit(obj_t, obj_t);
static obj_t method_init_76_read_inline();
static obj_t _inline_definitions__29_read_inline = BUNSPEC;
extern obj_t inline_finalizer_105_read_inline();
extern obj_t _load_path__54___eval;
extern obj_t find_file_path_55_tools_file(obj_t, obj_t);
extern obj_t id_of_id_112_ast_ident(obj_t);
extern obj_t create_struct(obj_t, long);
extern obj_t user_error_151_tools_error(obj_t, obj_t, obj_t, obj_t);
static obj_t handling_function1242_read_inline(obj_t, obj_t, obj_t, obj_t);
static obj_t look_for_inline_exp_95_read_inline(obj_t, obj_t, obj_t);
extern obj_t module_initialization_70_read_inline(long, char *);
extern obj_t module_initialization_70_tools_trace(long, char *);
extern obj_t module_initialization_70_read_reader(long, char *);
extern obj_t module_initialization_70_tools_error(long, char *);
extern obj_t module_initialization_70_tools_speek(long, char *);
extern obj_t module_initialization_70_tools_shape(long, char *);
extern obj_t module_initialization_70_tools_file(long, char *);
extern obj_t module_initialization_70_ast_ident(long, char *);
extern obj_t module_initialization_70_ast_env(long, char *);
extern obj_t module_initialization_70_type_type(long, char *);
extern obj_t module_initialization_70_ast_var(long, char *);
extern obj_t module_initialization_70___bexit(long, char *);
extern obj_t module_initialization_70___reader(long, char *);
extern obj_t module_initialization_70___eval(long, char *);
extern obj_t module_initialization_70___r4_pairs_and_lists_6_3(long, char *);
extern obj_t module_initialization_70___r4_ports_6_10_1(long, char *);
extern obj_t compiler_read_18_read_reader(obj_t);
static obj_t imported_modules_init_94_read_inline();
static obj_t library_modules_init_112_read_inline();
extern obj_t assq___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t toplevel_init_63_read_inline();
extern obj_t open_input_string(obj_t);
extern obj_t look_for_inline_98_read_inline(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t remq__51___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t loop_read_inline(obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t close_input_port(obj_t);
static obj_t _look_for_inline_143_read_inline(obj_t, obj_t, obj_t, obj_t, obj_t, obj_t);
extern obj_t read___reader(obj_t);
extern obj_t cons__138___r4_pairs_and_lists_6_3(obj_t, obj_t);
static obj_t _inline_finalizer_140_read_inline(obj_t);
extern obj_t val_from_exit__100___bexit(obj_t);
static obj_t require_initialization_114_read_inline = BUNSPEC;
extern obj_t open_input_file_61___r4_ports_6_10_1(obj_t, obj_t);
static obj_t cnst_init_137_read_inline();
static obj_t __cnst[7];

DEFINE_EXPORT_PROCEDURE(look_for_inline_env_65_read_inline, _look_for_inline_143_read_inline1344, _look_for_inline_143_read_inline, 0L, 5);
DEFINE_EXPORT_PROCEDURE(inline_finalizer_env_166_read_inline, _inline_finalizer_140_read_inline1345, _inline_finalizer_140_read_inline, 0L, 0);
DEFINE_STRING(string1336_read_inline, string1336_read_inline1346, "UNIT IMPORTED-INLINES BEGIN DEFINE-INLINE @ SIFUN DONE ", 55);
DEFINE_STRING(string1335_read_inline, string1335_read_inline1347, "Can't find file", 15);
DEFINE_STRING(string1334_read_inline, string1334_read_inline1348, "Can't find inline/generic definition(s)", 39);
DEFINE_STRING(string1333_read_inline, string1333_read_inline1349, "import", 6);


/* module-initialization */ obj_t 
module_initialization_70_read_inline(long checksum_717, char *from_718)
{
   if (CBOOL(require_initialization_114_read_inline))
     {
	require_initialization_114_read_inline = BBOOL(((bool_t) 0));
	library_modules_init_112_read_inline();
	cnst_init_137_read_inline();
	imported_modules_init_94_read_inline();
	method_init_76_read_inline();
	toplevel_init_63_read_inline();
	return BUNSPEC;
     }
   else
     {
	return BUNSPEC;
     }
}


/* library-modules-init */ obj_t 
library_modules_init_112_read_inline()
{
   module_initialization_70___bexit(((long) 0), "READ_INLINE");
   module_initialization_70___eval(((long) 0), "READ_INLINE");
   module_initialization_70___r4_pairs_and_lists_6_3(((long) 0), "READ_INLINE");
   module_initialization_70___reader(((long) 0), "READ_INLINE");
   module_initialization_70___r4_ports_6_10_1(((long) 0), "READ_INLINE");
   return BUNSPEC;
}


/* cnst-init */ obj_t 
cnst_init_137_read_inline()
{
   {
      obj_t cnst_port_138_709;
      cnst_port_138_709 = open_input_string(string1336_read_inline);
      {
	 long i_710;
	 i_710 = ((long) 6);
       loop_711:
	 {
	    bool_t test1337_712;
	    test1337_712 = (i_710 == ((long) -1));
	    if (test1337_712)
	      {
		 return BUNSPEC;
	      }
	    else
	      {
		 {
		    obj_t arg1339_713;
		    {
		       obj_t list1340_714;
		       {
			  obj_t arg1342_715;
			  arg1342_715 = BNIL;
			  list1340_714 = MAKE_PAIR(cnst_port_138_709, arg1342_715);
		       }
		       arg1339_713 = read___reader(list1340_714);
		    }
		    CNST_TABLE_SET(i_710, arg1339_713);
		 }
		 {
		    int aux_716;
		    {
		       long aux_738;
		       aux_738 = (i_710 - ((long) 1));
		       aux_716 = (int) (aux_738);
		    }
		    {
		       long i_741;
		       i_741 = (long) (aux_716);
		       i_710 = i_741;
		       goto loop_711;
		    }
		 }
	      }
	 }
      }
   }
}


/* toplevel-init */ obj_t 
toplevel_init_63_read_inline()
{
   return (_inline_definitions__29_read_inline = BNIL,
      BUNSPEC);
}


/* look-for-inline */ obj_t 
look_for_inline_98_read_inline(obj_t inlines_19, obj_t code_20, obj_t port_21, obj_t fnames_22, obj_t module_23)
{
   {
      obj_t arg1209_349;
      obj_t arg1210_350;
      arg1209_349 = look_for_inline_exp_95_read_inline(inlines_19, code_20, module_23);
      {
	 obj_t list1211_351;
	 {
	    obj_t arg1213_352;
	    arg1213_352 = MAKE_PAIR(BTRUE, BNIL);
	    list1211_351 = MAKE_PAIR(port_21, arg1213_352);
	 }
	 arg1210_350 = compiler_read_18_read_reader(list1211_351);
      }
      return loop_read_inline(module_23, arg1209_349, arg1210_350, fnames_22, port_21);
   }
}


/* loop */ obj_t 
loop_read_inline(obj_t module_703, obj_t inlines_344, obj_t exp_345, obj_t fnames_346, obj_t port_347)
{
 loop_read_inline:
   {
      bool_t test1215_354;
      test1215_354 = NULLP(inlines_344);
      if (test1215_354)
	{
	   return CNST_TABLE_REF(((long) 0));
	}
      else
	{
	   bool_t test1216_355;
	   test1216_355 = EOF_OBJECTP(exp_345);
	   if (test1216_355)
	     {
		if (NULLP(fnames_346))
		  {
		     obj_t arg1221_359;
		     if (test1215_354)
		       {
			  arg1221_359 = BNIL;
		       }
		     else
		       {
			  obj_t head1184_363;
			  {
			     obj_t aux_756;
			     {
				obj_t aux_757;
				aux_757 = CAR(inlines_344);
				aux_756 = CAR(aux_757);
			     }
			     head1184_363 = MAKE_PAIR(aux_756, BNIL);
			  }
			  {
			     obj_t l1182_364;
			     obj_t tail1185_365;
			     l1182_364 = CDR(inlines_344);
			     tail1185_365 = head1184_363;
			   lname1183_366:
			     if (NULLP(l1182_364))
			       {
				  arg1221_359 = head1184_363;
			       }
			     else
			       {
				  obj_t newtail1186_369;
				  {
				     obj_t aux_763;
				     {
					obj_t aux_764;
					aux_764 = CAR(l1182_364);
					aux_763 = CAR(aux_764);
				     }
				     newtail1186_369 = MAKE_PAIR(aux_763, BNIL);
				  }
				  SET_CDR(tail1185_365, newtail1186_369);
				  {
				     obj_t tail1185_771;
				     obj_t l1182_769;
				     l1182_769 = CDR(l1182_364);
				     tail1185_771 = newtail1186_369;
				     tail1185_365 = tail1185_771;
				     l1182_364 = l1182_769;
				     goto lname1183_366;
				  }
			       }
			  }
		       }
		     return user_error_151_tools_error(string1333_read_inline, string1334_read_inline, arg1221_359, BNIL);
		  }
		else
		  {
		     obj_t fname_377;
		     fname_377 = find_file_path_55_tools_file(CAR(fnames_346), _load_path__54___eval);
		     if (STRINGP(fname_377))
		       {
			  obj_t port_379;
			  port_379 = open_input_file_61___r4_ports_6_10_1(fname_377, BNIL);
			  {
			     obj_t val1187_380;
			     val1187_380 = handling_function1242_read_inline(inlines_344, fnames_346, port_379, module_703);
			     if (INPUT_PORTP(port_379))
			       {
				  close_input_port(port_379);
			       }
			     else
			       {
				  BUNSPEC;
			       }
			     {
				bool_t test1238_382;
				{
				   obj_t aux_783;
				   aux_783 = val_from_exit__100___bexit(val1187_380);
				   test1238_382 = CBOOL(aux_783);
				}
				if (test1238_382)
				  {
				     return unwind_until__178___bexit(CAR(val1187_380), CDR(val1187_380));
				  }
				else
				  {
				     return val1187_380;
				  }
			     }
			  }
		       }
		     else
		       {
			  return user_error_151_tools_error(string1333_read_inline, string1335_read_inline, CAR(fnames_346), BNIL);
		       }
		  }
	     }
	   else
	     {
		{
		   obj_t arg1255_399;
		   obj_t arg1256_400;
		   arg1255_399 = look_for_inline_exp_95_read_inline(inlines_344, exp_345, module_703);
		   {
		      obj_t list1257_401;
		      {
			 obj_t arg1258_402;
			 arg1258_402 = MAKE_PAIR(BTRUE, BNIL);
			 list1257_401 = MAKE_PAIR(port_347, arg1258_402);
		      }
		      arg1256_400 = compiler_read_18_read_reader(list1257_401);
		   }
		   {
		      obj_t exp_797;
		      obj_t inlines_796;
		      inlines_796 = arg1255_399;
		      exp_797 = arg1256_400;
		      exp_345 = exp_797;
		      inlines_344 = inlines_796;
		      goto loop_read_inline;
		   }
		}
	     }
	}
   }
}


/* handling_function1242 */ obj_t 
handling_function1242_read_inline(obj_t inlines_707, obj_t fnames_706, obj_t port_705, obj_t module_704)
{
   jmp_buf jmpbuf;
   obj_t an_exit1188_386;
   if (SET_EXIT(an_exit1188_386))
     {
	RESTORE_TRACE();
	return _exit_value_;
     }
   else
     {
	an_exit1188_386 = (obj_t) jmpbuf;
	{
	   PUSH_EXIT(an_exit1188_386, ((bool_t) 0));
	   {
	      obj_t val1189_387;
	      {
		 obj_t arg1243_388;
		 obj_t arg1244_389;
		 {
		    obj_t list1245_390;
		    {
		       obj_t arg1247_391;
		       arg1247_391 = MAKE_PAIR(BTRUE, BNIL);
		       list1245_390 = MAKE_PAIR(port_705, arg1247_391);
		    }
		    arg1243_388 = compiler_read_18_read_reader(list1245_390);
		 }
		 arg1244_389 = CDR(fnames_706);
		 val1189_387 = loop_read_inline(module_704, inlines_707, arg1243_388, arg1244_389, port_705);
	      }
	      POP_EXIT();
	      return val1189_387;
	   }
	}
     }
}


/* _look-for-inline */ obj_t 
_look_for_inline_143_read_inline(obj_t env_696, obj_t inlines_697, obj_t code_698, obj_t port_699, obj_t fnames_700, obj_t module_701)
{
   return look_for_inline_98_read_inline(inlines_697, code_698, port_699, fnames_700, module_701);
}


/* look-for-inline/exp */ obj_t 
look_for_inline_exp_95_read_inline(obj_t inlines_24, obj_t exp_25, obj_t module_26)
{
   if (NULLP(inlines_24))
     {
	return BNIL;
     }
   else
     {
	obj_t exp__153_409;
	obj_t proto_405;
	obj_t name_406;
	obj_t body_407;
	if (PAIRP(exp_25))
	  {
	     obj_t cdr_132_143_414;
	     cdr_132_143_414 = CDR(exp_25);
	     {
		bool_t test_813;
		{
		   obj_t aux_816;
		   obj_t aux_814;
		   aux_816 = CNST_TABLE_REF(((long) 3));
		   aux_814 = CAR(exp_25);
		   test_813 = (aux_814 == aux_816);
		}
		if (test_813)
		  {
		     if (PAIRP(cdr_132_143_414))
		       {
			  obj_t car_136_42_417;
			  car_136_42_417 = CAR(cdr_132_143_414);
			  if (PAIRP(car_136_42_417))
			    {
			       proto_405 = car_136_42_417;
			       name_406 = CAR(car_136_42_417);
			       body_407 = CDR(cdr_132_143_414);
			       {
				  obj_t id_427;
				  id_427 = id_of_id_112_ast_ident(name_406);
				  {
				     obj_t cell_428;
				     cell_428 = assq___r4_pairs_and_lists_6_3(id_427, inlines_24);
				     {
					{
					   bool_t test_826;
					   if (PAIRP(cell_428))
					     {
						obj_t aux_831;
						obj_t aux_829;
						aux_831 = CNST_TABLE_REF(((long) 1));
						aux_829 = CDR(cell_428);
						test_826 = (aux_829 == aux_831);
					     }
					   else
					     {
						test_826 = ((bool_t) 0);
					     }
					   if (test_826)
					     {
						{
						   obj_t arg1277_430;
						   {
						      obj_t arg1278_431;
						      arg1278_431 = CNST_TABLE_REF(((long) 2));
						      {
							 obj_t list1282_433;
							 {
							    obj_t arg1283_434;
							    {
							       obj_t arg1284_435;
							       arg1284_435 = MAKE_PAIR(BNIL, BNIL);
							       arg1283_434 = MAKE_PAIR(module_26, arg1284_435);
							    }
							    list1282_433 = MAKE_PAIR(id_427, arg1283_434);
							 }
							 arg1277_430 = cons__138___r4_pairs_and_lists_6_3(arg1278_431, list1282_433);
						      }
						   }
						   SET_CAR(proto_405, arg1277_430);
						}
						{
						   obj_t obj2_663;
						   obj2_663 = _inline_definitions__29_read_inline;
						   _inline_definitions__29_read_inline = MAKE_PAIR(exp_25, obj2_663);
						}
						return remq__51___r4_pairs_and_lists_6_3(cell_428, inlines_24);
					     }
					   else
					     {
						return inlines_24;
					     }
					}
				     }
				  }
			       }
			    }
			  else
			    {
			       return inlines_24;
			    }
		       }
		     else
		       {
			  return inlines_24;
		       }
		  }
		else
		  {
		     bool_t test_844;
		     {
			obj_t aux_847;
			obj_t aux_845;
			aux_847 = CNST_TABLE_REF(((long) 4));
			aux_845 = CAR(exp_25);
			test_844 = (aux_845 == aux_847);
		     }
		     if (test_844)
		       {
			  exp__153_409 = cdr_132_143_414;
			  {
			     obj_t inlines_440;
			     obj_t exp__153_441;
			     inlines_440 = inlines_24;
			     exp__153_441 = exp__153_409;
			   loop_442:
			     if (NULLP(exp__153_441))
			       {
				  return inlines_440;
			       }
			     else
			       {
				  obj_t arg1290_444;
				  obj_t arg1291_445;
				  arg1290_444 = look_for_inline_exp_95_read_inline(inlines_440, CAR(exp__153_441), module_26);
				  arg1291_445 = CDR(exp__153_441);
				  {
				     obj_t exp__153_856;
				     obj_t inlines_855;
				     inlines_855 = arg1290_444;
				     exp__153_856 = arg1291_445;
				     exp__153_441 = exp__153_856;
				     inlines_440 = inlines_855;
				     goto loop_442;
				  }
			       }
			  }
		       }
		     else
		       {
			  return inlines_24;
		       }
		  }
	     }
	  }
	else
	  {
	     return inlines_24;
	  }
     }
}


/* inline-finalizer */ obj_t 
inline_finalizer_105_read_inline()
{
   {
      bool_t test1293_447;
      {
	 obj_t obj_667;
	 obj_667 = _inline_definitions__29_read_inline;
	 test1293_447 = NULLP(obj_667);
      }
      if (test1293_447)
	{
	   return BNIL;
	}
      else
	{
	   obj_t arg1294_448;
	   {
	      obj_t arg1297_451;
	      arg1297_451 = CNST_TABLE_REF(((long) 5));
	      {
		 obj_t sexp__30_670;
		 sexp__30_670 = _inline_definitions__29_read_inline;
		 {
		    obj_t new_672;
		    {
		       obj_t aux_860;
		       aux_860 = CNST_TABLE_REF(((long) 6));
		       new_672 = create_struct(aux_860, ((long) 4));
		    }
		    STRUCT_SET(new_672, ((long) 3), BTRUE);
		    STRUCT_SET(new_672, ((long) 2), sexp__30_670);
		    {
		       obj_t aux_865;
		       aux_865 = BINT(((long) 0));
		       STRUCT_SET(new_672, ((long) 1), aux_865);
		    }
		    STRUCT_SET(new_672, ((long) 0), arg1297_451);
		    arg1294_448 = new_672;
		 }
	      }
	   }
	   {
	      obj_t list1295_449;
	      list1295_449 = MAKE_PAIR(arg1294_448, BNIL);
	      return list1295_449;
	   }
	}
   }
}


/* _inline-finalizer */ obj_t 
_inline_finalizer_140_read_inline(obj_t env_702)
{
   return inline_finalizer_105_read_inline();
}


/* method-init */ obj_t 
method_init_76_read_inline()
{
   return BUNSPEC;
}


/* imported-modules-init */ obj_t 
imported_modules_init_94_read_inline()
{
   module_initialization_70_tools_trace(((long) 0), "READ_INLINE");
   module_initialization_70_read_reader(((long) 0), "READ_INLINE");
   module_initialization_70_tools_error(((long) 0), "READ_INLINE");
   module_initialization_70_tools_speek(((long) 0), "READ_INLINE");
   module_initialization_70_tools_shape(((long) 0), "READ_INLINE");
   module_initialization_70_tools_file(((long) 0), "READ_INLINE");
   module_initialization_70_ast_ident(((long) 0), "READ_INLINE");
   module_initialization_70_ast_env(((long) 0), "READ_INLINE");
   module_initialization_70_type_type(((long) 0), "READ_INLINE");
   return module_initialization_70_ast_var(((long) 0), "READ_INLINE");
}
